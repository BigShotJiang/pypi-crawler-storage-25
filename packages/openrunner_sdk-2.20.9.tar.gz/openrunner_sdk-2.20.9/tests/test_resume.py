"""Tests for run resume and sender offline branch."""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from openrunner.run import Run


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_client(**overrides):
    """Create a mock APIClient with sensible defaults."""
    client = MagicMock()
    client.create_run.return_value = {"id": "new12345", "state": "running"}
    client.get_run.return_value = None
    client.get_run_max_step.return_value = 0
    for k, v in overrides.items():
        setattr(client, k, v if not callable(v) else v)
    return client


# ---------------------------------------------------------------------------
# Resume: creates new run with resumed_from_id
# ---------------------------------------------------------------------------


class TestResumeAllow:
    def test_resume_allow_creates_new_run_with_resumed_from_id(self):
        """resume='allow' with existing parent creates new run linked to parent."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "child123", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {"lr": 0.01},
                "state": "finished",
            }
            mock_client.get_run_max_step.return_value = 100

            run = Run(
                project="test",
                run_id="parent12",
                resume="allow",
            )

            # Should have called get_run to fetch parent
            mock_client.get_run.assert_called_once_with("parent12")

            # Should have called create_run with resumed_from_id
            call_args = mock_client.create_run.call_args[0][0]
            assert call_args["resumed_from_id"] == "parent12"

            # Run ID should NOT be the parent ID (new ID generated)
            assert run.id != "parent12"

            run._sender.stop(timeout=2.0)

    def test_resume_allow_creates_fresh_when_parent_not_found(self):
        """resume='allow' with missing parent creates a fresh run."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "fresh123", "state": "running"}
            mock_client.get_run.return_value = None

            run = Run(
                project="test",
                run_id="nonexist",
                resume="allow",
            )

            # Should create a fresh run (no error, no resumed_from_id)
            call_args = mock_client.create_run.call_args[0][0]
            assert "resumed_from_id" not in call_args or call_args.get("resumed_from_id") is None

            run._sender.stop(timeout=2.0)


class TestResumeMust:
    def test_resume_must_raises_when_parent_not_found(self):
        """resume='must' with missing parent should raise RuntimeError."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.get_run.return_value = None

            with pytest.raises(RuntimeError, match="Cannot resume"):
                Run(
                    project="test",
                    run_id="nonexist",
                    resume="must",
                )


# ---------------------------------------------------------------------------
# Resume: config merge
# ---------------------------------------------------------------------------


class TestResumeConfigMerge:
    def test_resume_merges_parent_config_with_new_config(self):
        """New config should override parent config values."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "merged12", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {"lr": 0.01, "epochs": 10},
                "state": "finished",
            }
            mock_client.get_run_max_step.return_value = 0

            run = Run(
                project="test",
                run_id="parent12",
                config_dict={"lr": 0.001},  # override lr
                resume="allow",
            )

            # Config should be merged: parent + new (new overrides)
            call_args = mock_client.create_run.call_args[0][0]
            assert call_args["config"]["lr"] == 0.001  # new overrides
            assert call_args["config"]["epochs"] == 10  # parent preserved

            run._sender.stop(timeout=2.0)


# ---------------------------------------------------------------------------
# Resume: step offset
# ---------------------------------------------------------------------------


class TestResumeStepOffset:
    def test_resume_sets_step_counter_to_parent_max_plus_one(self):
        """Step counter should start at parent max_step + 1."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "offset12", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {},
                "state": "finished",
            }
            mock_client.get_run_max_step.return_value = 50

            run = Run(
                project="test",
                run_id="parent12",
                resume="allow",
            )

            assert run._step == 51

            run._sender.stop(timeout=2.0)


# ---------------------------------------------------------------------------
# Sender: offline branch
# ---------------------------------------------------------------------------


class TestSenderOffline:
    def test_flush_writes_to_offline_storage_not_http(self, tmp_path: Path):
        """When offline_storage is set, flush writes to disk, not HTTP."""
        from openrunner.buffer import WriteBuffer
        from openrunner.offline import OfflineStorage
        from openrunner.sender import Sender

        buf = WriteBuffer()
        client = MagicMock()
        storage = OfflineStorage("run_off", base_dir=tmp_path)

        sender = Sender(
            buffer=buf,
            client=client,
            run_id="run_off",
            offline_storage=storage,
            system_metrics_enabled=False,
        )

        # Put some metrics
        buf.put({"key": "loss", "value": 0.5, "step": 0})
        buf.put({"key": "loss", "value": 0.3, "step": 1})

        # Manually flush
        sender._flush()

        # HTTP client should NOT have been called
        client.post_metrics.assert_not_called()

        # Offline storage should have the records
        records = storage.read_metrics()
        assert len(records) == 2

        storage.close()

    def test_stop_closes_offline_storage(self, tmp_path: Path):
        """stop() should close offline storage if present."""
        from openrunner.buffer import WriteBuffer
        from openrunner.offline import OfflineStorage
        from openrunner.sender import Sender

        buf = WriteBuffer()
        client = MagicMock()
        storage = OfflineStorage("run_cls", base_dir=tmp_path)

        sender = Sender(
            buffer=buf,
            client=client,
            run_id="run_cls",
            offline_storage=storage,
            system_metrics_enabled=False,
        )

        sender.start()
        sender.stop(timeout=5.0)

        # metrics file handle should be closed (None after close)
        assert storage._metrics_fh is None


# ---------------------------------------------------------------------------
# openrunner.init(resume=True) end-to-end
# ---------------------------------------------------------------------------


class TestInitResume:
    def test_init_with_resume_true(self):
        """openrunner.init(resume=True, id='parent') works end-to-end."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "e2e12345", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {"lr": 0.01},
                "state": "finished",
            }
            mock_client.get_run_max_step.return_value = 25

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(
                project="test",
                id="parent12",
                resume=True,
            )

            assert run is not None
            assert run._step == 26  # parent max + 1

            openrunner.finish(quiet=True)
