"""Tests for openrunner.media -- Image, Table, Audio, Video, Histogram, Plotly, Embedding, BoundingBoxes2D."""

from __future__ import annotations

import pytest
import io
import json
import struct
import wave

import numpy as np
from PIL import Image as PILImage

from openrunner.media import (
    Audio,
    BoundingBoxes2D,
    Embedding,
    Histogram,
    Html,
    Image,
    MatplotlibFigure,
    Plotly,
    PlotlyChart,
    PointCloud3D,
    Table,
    Video,
)


def _is_png(data: bytes) -> bool:
    """Check if bytes start with the PNG magic number."""
    return data[:8] == b"\x89PNG\r\n\x1a\n"


class TestImage:
    """Tests for the Image class."""

    def test_image_from_numpy(self) -> None:
        """Image from uint8 numpy array serializes to valid PNG bytes."""
        arr = np.zeros((10, 10, 3), dtype=np.uint8)
        arr[5, 5] = [255, 0, 0]  # red pixel
        img = Image(arr)
        data, content_type = img._serialize()
        assert _is_png(data)
        assert content_type == "image/png"
        # Verify round-trip: load the PNG and check dimensions
        pil = PILImage.open(io.BytesIO(data))
        assert pil.size == (10, 10)

    def test_image_from_file(self, tmp_path) -> None:
        """Image from file path returns the file bytes."""
        # Create a small PNG on disk
        pil = PILImage.new("RGB", (4, 4), color=(128, 64, 32))
        png_path = tmp_path / "test.png"
        pil.save(str(png_path))

        img = Image(str(png_path))
        data, content_type = img._serialize()
        assert _is_png(data)
        assert content_type == "image/png"
        assert data == png_path.read_bytes()

    def test_image_from_pil(self) -> None:
        """Image from PIL.Image serializes to valid PNG bytes."""
        pil = PILImage.new("RGB", (8, 8), color=(0, 255, 0))
        img = Image(pil)
        data, content_type = img._serialize()
        assert _is_png(data)
        assert content_type == "image/png"

    def test_image_caption(self) -> None:
        """Caption attribute is stored correctly."""
        arr = np.zeros((2, 2, 3), dtype=np.uint8)
        img = Image(arr, caption="test caption")
        assert img.caption == "test caption"

    def test_image_no_caption(self) -> None:
        """Caption defaults to None."""
        arr = np.zeros((2, 2, 3), dtype=np.uint8)
        img = Image(arr)
        assert img.caption is None

    def test_image_float_array(self) -> None:
        """Float 0-1 array is normalized to uint8 and serialized as PNG."""
        arr = np.random.rand(10, 10, 3).astype(np.float32)
        img = Image(arr)
        data, content_type = img._serialize()
        assert _is_png(data)
        assert content_type == "image/png"
        # Verify it's loadable
        pil = PILImage.open(io.BytesIO(data))
        assert pil.size == (10, 10)

    def test_image_grayscale_array(self) -> None:
        """2D grayscale array is serialized as PNG."""
        arr = np.zeros((8, 8), dtype=np.uint8)
        img = Image(arr)
        data, content_type = img._serialize()
        assert _is_png(data)

    def test_image_jpeg_file(self, tmp_path) -> None:
        """JPEG file returns correct content type."""
        pil = PILImage.new("RGB", (4, 4), color=(100, 100, 100))
        jpg_path = tmp_path / "test.jpg"
        pil.save(str(jpg_path), format="JPEG")

        img = Image(str(jpg_path))
        data, content_type = img._serialize()
        assert content_type == "image/jpeg"
        assert data == jpg_path.read_bytes()

    def test_image_with_masks(self) -> None:
        """Image with segmentation masks stores mask data correctly."""
        arr = np.zeros((10, 10, 3), dtype=np.uint8)
        mask = np.zeros((10, 10), dtype=np.int32)
        mask[0:5, :] = 1  # top half = class 1
        mask[5:10, :] = 2  # bottom half = class 2

        img = Image(
            arr,
            masks={
                "predictions": {
                    "mask_data": mask,
                    "class_labels": {0: "background", 1: "car", 2: "person"},
                }
            },
        )

        # Verify mask data is stored
        assert img._masks is not None
        assert "predictions" in img._masks
        pred = img._masks["predictions"]
        assert pred["class_labels"] == {0: "background", 1: "car", 2: "person"}
        # mask_data should be converted from numpy to list
        assert isinstance(pred["mask_data"], list)
        assert len(pred["mask_data"]) == 10
        assert len(pred["mask_data"][0]) == 10

    def test_image_with_boxes(self) -> None:
        """Image with bounding box overlays stores box data correctly."""
        arr = np.zeros((10, 10, 3), dtype=np.uint8)
        img = Image(
            arr,
            boxes={
                "detections": {
                    "box_data": [
                        {
                            "position": {"minX": 1, "minY": 2, "maxX": 5, "maxY": 6},
                            "class_id": 1,
                            "scores": {"confidence": 0.95},
                        }
                    ],
                    "class_labels": {1: "car"},
                }
            },
        )

        assert img._boxes is not None
        assert "detections" in img._boxes
        det = img._boxes["detections"]
        assert len(det["box_data"]) == 1
        assert det["class_labels"] == {1: "car"}

    def test_image_overlay_data_with_masks(self) -> None:
        """_get_overlay_data returns masks when present."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        mask = np.ones((4, 4), dtype=np.int32)
        img = Image(arr, masks={"seg": {"mask_data": mask, "class_labels": {1: "fg"}}})

        overlay = img._get_overlay_data()
        assert overlay is not None
        assert "masks" in overlay
        assert "seg" in overlay["masks"]

    def test_image_overlay_data_with_boxes(self) -> None:
        """_get_overlay_data returns boxes when present."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        img = Image(
            arr,
            boxes={"det": {"box_data": [], "class_labels": {}}},
        )

        overlay = img._get_overlay_data()
        assert overlay is not None
        assert "boxes" in overlay

    def test_image_overlay_data_with_both(self) -> None:
        """_get_overlay_data returns both masks and boxes."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        mask = np.zeros((4, 4), dtype=np.int32)
        img = Image(
            arr,
            masks={"seg": {"mask_data": mask, "class_labels": {}}},
            boxes={"det": {"box_data": [], "class_labels": {}}},
        )

        overlay = img._get_overlay_data()
        assert overlay is not None
        assert "masks" in overlay
        assert "boxes" in overlay

    def test_image_overlay_data_none_when_empty(self) -> None:
        """_get_overlay_data returns None when no masks or boxes."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        img = Image(arr)
        assert img._get_overlay_data() is None

    def test_image_mode_parameter(self) -> None:
        """Mode parameter is stored on the image object."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        img = Image(arr, mode="RGB")
        assert img._mode == "RGB"

    def test_image_masks_numpy_conversion(self) -> None:
        """Numpy mask arrays are properly converted to nested lists."""
        arr = np.zeros((2, 2, 3), dtype=np.uint8)
        mask = np.array([[0, 1], [2, 3]], dtype=np.int64)
        img = Image(arr, masks={"m": {"mask_data": mask}})

        data = img._masks["m"]["mask_data"]
        assert data == [[0, 1], [2, 3]]
        assert isinstance(data[0][0], int)


class TestTable:
    """Tests for the Table class."""

    def test_table_basic(self) -> None:
        """Table with columns and data serializes correctly."""
        table = Table(
            columns=["name", "score"],
            data=[["alice", 95], ["bob", 87]],
        )
        result = table._serialize()
        assert result == {
            "columns": ["name", "score"],
            "data": [["alice", 95], ["bob", 87]],
        }

    def test_table_add_data(self) -> None:
        """Adding data incrementally works correctly."""
        table = Table(columns=["x", "y"])
        table.add_data(1, 2)
        table.add_data(3, 4)
        result = table._serialize()
        assert result == {
            "columns": ["x", "y"],
            "data": [[1, 2], [3, 4]],
        }

    def test_table_empty(self) -> None:
        """Empty table serializes with empty columns and data."""
        table = Table()
        result = table._serialize()
        assert result == {"columns": [], "data": []}


# ---------------------------------------------------------------------------
# Audio tests
# ---------------------------------------------------------------------------

class TestAudio:
    """Tests for the Audio class."""

    def test_audio_from_numpy_mono(self) -> None:
        """Mono numpy array serializes to valid WAV bytes."""
        # 0.1s of 440Hz sine wave at 44100 Hz
        sr = 44100
        t = np.linspace(0, 0.1, int(sr * 0.1), endpoint=False)
        arr = np.sin(2 * np.pi * 440 * t).astype(np.float32)

        audio = Audio(arr, sample_rate=sr)
        data, ct = audio._serialize()
        assert ct == "audio/wav"
        # Validate WAV header
        assert data[:4] == b"RIFF"
        assert data[8:12] == b"WAVE"

        # Verify round-trip via wave module
        wf = wave.open(io.BytesIO(data), "rb")
        assert wf.getnchannels() == 1
        assert wf.getsampwidth() == 2
        assert wf.getframerate() == sr
        wf.close()

    def test_audio_from_numpy_stereo(self) -> None:
        """Stereo (samples, 2) numpy array serializes to stereo WAV."""
        sr = 22050
        samples = np.zeros((1000, 2), dtype=np.float32)
        audio = Audio(samples, sample_rate=sr)
        data, ct = audio._serialize()
        assert ct == "audio/wav"

        wf = wave.open(io.BytesIO(data), "rb")
        assert wf.getnchannels() == 2
        assert wf.getframerate() == sr
        wf.close()

    def test_audio_from_file(self, tmp_path) -> None:
        """Audio from file path returns the file bytes."""
        # Create a minimal WAV file
        wav_path = tmp_path / "test.wav"
        with wave.open(str(wav_path), "wb") as wf:
            wf.setnchannels(1)
            wf.setsampwidth(2)
            wf.setframerate(8000)
            wf.writeframes(b"\x00\x00" * 100)

        audio = Audio(str(wav_path))
        data, ct = audio._serialize()
        assert ct == "audio/wav"
        assert data == wav_path.read_bytes()

    def test_audio_from_mp3_file(self, tmp_path) -> None:
        """MP3 file returns correct content type."""
        mp3_path = tmp_path / "test.mp3"
        mp3_path.write_bytes(b"fake mp3 content")
        audio = Audio(str(mp3_path))
        data, ct = audio._serialize()
        assert ct == "audio/mpeg"

    def test_audio_from_bytes(self) -> None:
        """Audio from raw bytes returns them as-is with audio/wav content type."""
        raw = b"RIFF" + b"\x00" * 100
        audio = Audio(raw)
        data, ct = audio._serialize()
        assert ct == "audio/wav"
        assert data == raw

    def test_audio_caption(self) -> None:
        """Caption attribute is stored correctly."""
        audio = Audio(b"data", caption="test audio")
        assert audio.caption == "test audio"

    def test_audio_sample_rate(self) -> None:
        """Custom sample rate is used during serialization."""
        sr = 16000
        arr = np.zeros(100, dtype=np.float32)
        audio = Audio(arr, sample_rate=sr)
        data, ct = audio._serialize()

        wf = wave.open(io.BytesIO(data), "rb")
        assert wf.getframerate() == sr
        wf.close()

    def test_audio_int16_array(self) -> None:
        """int16 numpy array is serialized directly without conversion."""
        arr = np.array([0, 1000, -1000, 32767, -32768], dtype=np.int16)
        audio = Audio(arr, sample_rate=8000)
        data, ct = audio._serialize()
        assert ct == "audio/wav"
        wf = wave.open(io.BytesIO(data), "rb")
        assert wf.getnframes() == 5
        wf.close()


# ---------------------------------------------------------------------------
# Video tests
# ---------------------------------------------------------------------------

class TestVideo:
    """Tests for the Video class."""

    def test_video_from_file(self, tmp_path) -> None:
        """Video from file path returns the file bytes."""
        mp4_path = tmp_path / "test.mp4"
        mp4_path.write_bytes(b"fake mp4 content")
        video = Video(str(mp4_path))
        data, ct = video._serialize()
        assert ct == "video/mp4"
        assert data == b"fake mp4 content"

    def test_video_webm_file(self, tmp_path) -> None:
        """WebM file returns correct content type."""
        webm_path = tmp_path / "test.webm"
        webm_path.write_bytes(b"fake webm")
        video = Video(str(webm_path))
        data, ct = video._serialize()
        assert ct == "video/webm"

    def test_video_numpy_fallback(self) -> None:
        """Numpy array without imageio falls back to raw frame bundle."""
        arr = np.zeros((5, 4, 4, 3), dtype=np.uint8)
        video = Video(arr, fps=15)
        data, ct = video._serialize()
        # Without imageio/pyav, should get raw fallback
        # (could be video/mp4 if imageio is available)
        assert len(data) > 0

    def test_video_caption(self) -> None:
        """Caption and fps attributes are stored correctly."""
        video = Video("path.mp4", caption="test video", fps=60)
        assert video.caption == "test video"
        assert video.fps == 60

    def test_video_bad_ndim(self) -> None:
        """3D array raises ValueError."""
        arr = np.zeros((10, 10, 3), dtype=np.uint8)
        video = Video(arr)
        try:
            video._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "4D" in str(e)


# ---------------------------------------------------------------------------
# Histogram tests
# ---------------------------------------------------------------------------

class TestHistogram:
    """Tests for the Histogram class."""

    def test_histogram_basic(self) -> None:
        """Histogram from numpy array produces correct bins and counts."""
        values = np.random.randn(1000)
        hist = Histogram(values, num_bins=10)
        result = hist._serialize()

        assert len(result["bins"]) == 11  # num_bins + 1 edges
        assert len(result["counts"]) == 10
        assert sum(result["counts"]) == 1000
        assert result["num_bins"] == 10
        assert "min" in result
        assert "max" in result
        assert "mean" in result
        assert "std" in result
        assert result["count"] == 1000

    def test_histogram_list(self) -> None:
        """Histogram accepts plain Python list."""
        values = [1.0, 2.0, 3.0, 4.0, 5.0]
        hist = Histogram(values, num_bins=5)
        result = hist._serialize()

        assert len(result["bins"]) == 6
        assert len(result["counts"]) == 5
        assert sum(result["counts"]) == 5

    def test_histogram_empty(self) -> None:
        """Empty values produce empty histogram."""
        hist = Histogram([], num_bins=10)
        result = hist._serialize()
        assert result["bins"] == []
        assert result["counts"] == []

    def test_histogram_with_nan(self) -> None:
        """NaN values are filtered out."""
        values = np.array([1.0, np.nan, 3.0, np.inf, 5.0])
        hist = Histogram(values, num_bins=4)
        result = hist._serialize()
        # Only 3 finite values (1, 3, 5)
        assert result["count"] == 3

    def test_histogram_caption(self) -> None:
        """Caption attribute is stored."""
        hist = Histogram([1, 2, 3], caption="loss distribution")
        assert hist.caption == "loss distribution"

    def test_histogram_single_value(self) -> None:
        """Single-value histogram doesn't crash."""
        hist = Histogram([5.0])
        result = hist._serialize()
        assert result["count"] == 1
        assert result["min"] == 5.0


# ---------------------------------------------------------------------------
# Plotly tests
# ---------------------------------------------------------------------------

class TestPlotly:
    """Tests for the Plotly class."""

    def test_plotly_from_dict(self) -> None:
        """Plotly from dict returns the dict as-is."""
        fig = {
            "data": [{"type": "scatter", "x": [1, 2, 3], "y": [4, 5, 6]}],
            "layout": {"title": "Test"},
        }
        p = Plotly(fig)
        result = p._serialize()
        assert result == fig

    def test_plotly_from_object_with_to_json(self) -> None:
        """Plotly from object with to_json() method serializes correctly."""

        class FakeFigure:
            def to_json(self):
                return '{"data": [{"type": "bar"}], "layout": {}}'

        p = Plotly(FakeFigure())
        result = p._serialize()
        assert result == {"data": [{"type": "bar"}], "layout": {}}

    def test_plotly_from_object_with_to_dict(self) -> None:
        """Plotly from object with to_dict() method serializes correctly."""

        class FakeFigure:
            def to_dict(self):
                return {"data": [{"type": "pie"}], "layout": {"title": "Pie"}}

        p = Plotly(FakeFigure())
        result = p._serialize()
        assert result["data"][0]["type"] == "pie"

    def test_plotly_caption(self) -> None:
        """Caption attribute is stored."""
        p = Plotly({}, caption="my chart")
        assert p.caption == "my chart"

    def test_plotly_unsupported_type(self) -> None:
        """Unsupported type raises TypeError."""
        p = Plotly(42)
        try:
            p._serialize()
            assert False, "Should have raised"
        except TypeError as e:
            assert "int" in str(e)


# ---------------------------------------------------------------------------
# BoundingBoxes2D tests
# ---------------------------------------------------------------------------

class TestBoundingBoxes2D:
    """Tests for the BoundingBoxes2D class."""

    def test_bbox_basic(self) -> None:
        """BoundingBoxes2D serializes image and box data."""
        arr = np.zeros((10, 10, 3), dtype=np.uint8)
        img = Image(arr)
        boxes = [
            {
                "position": {"minX": 1, "minY": 2, "maxX": 5, "maxY": 6},
                "class_id": 0,
                "scores": {"confidence": 0.95},
            },
            {
                "position": {"minX": 3, "minY": 4, "maxX": 8, "maxY": 9},
                "class_id": 1,
            },
        ]
        labels = {0: "cat", 1: "dog"}
        bbox = BoundingBoxes2D(img, boxes, class_labels=labels)

        # Image serialization
        img_bytes, ct = bbox._serialize_image()
        assert _is_png(img_bytes)
        assert ct == "image/png"

        # Box serialization
        box_data = bbox._serialize_boxes()
        assert len(box_data["boxes"]) == 2
        assert box_data["class_labels"] == {0: "cat", 1: "dog"}

    def test_bbox_no_labels(self) -> None:
        """BoundingBoxes2D without class_labels defaults to empty dict."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        img = Image(arr)
        boxes = [{"position": {"minX": 0, "minY": 0, "maxX": 2, "maxY": 2}}]
        bbox = BoundingBoxes2D(img, boxes)
        box_data = bbox._serialize_boxes()
        assert box_data["class_labels"] == {}

    def test_bbox_caption(self) -> None:
        """Caption attribute is stored."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        img = Image(arr)
        bbox = BoundingBoxes2D(img, [], caption="detection results")
        assert bbox.caption == "detection results"

    def test_bbox_empty_boxes(self) -> None:
        """Empty box list serializes correctly."""
        arr = np.zeros((4, 4, 3), dtype=np.uint8)
        img = Image(arr)
        bbox = BoundingBoxes2D(img, [])
        box_data = bbox._serialize_boxes()
        assert box_data["boxes"] == []


# ---------------------------------------------------------------------------
# Html tests
# ---------------------------------------------------------------------------

class TestHtml:
    """Tests for the Html class."""

    def test_html_basic(self) -> None:
        """Html with raw string serializes correctly (inject=True prepends style)."""
        html = Html("<div>Hello World</div>")
        result = html._serialize()
        assert result["html"].endswith("<div>Hello World</div>")
        assert "<style>" in result["html"]

    def test_html_with_caption(self) -> None:
        """Html with caption includes it in serialized output."""
        html = Html("<p>Report</p>", caption="Training Report")
        result = html._serialize()
        assert result["html"].endswith("<p>Report</p>")
        assert result["caption"] == "Training Report"
        assert html.caption == "Training Report"

    def test_html_no_caption(self) -> None:
        """Caption defaults to None and is omitted from serialization."""
        html = Html("<span>data</span>")
        assert html.caption is None
        result = html._serialize()
        assert "caption" not in result

    def test_html_complex_content(self) -> None:
        """Html with complex nested content serializes correctly."""
        content = (
            '<div style="color: red;">'
            "<h1>Results</h1>"
            "<table><tr><td>Loss</td><td>0.01</td></tr></table>"
            "<script>alert('xss')</script>"
            "</div>"
        )
        html = Html(content, caption="complex")
        result = html._serialize()
        assert result["html"].endswith(content)
        assert result["caption"] == "complex"


# ---------------------------------------------------------------------------
# MatplotlibFigure tests
# ---------------------------------------------------------------------------

class TestMatplotlibFigure:
    """Tests for the MatplotlibFigure class."""

    pytestmark = pytest.mark.skipif(
        not __import__("importlib").util.find_spec("matplotlib"),
        reason="matplotlib not installed",
    )

    def test_matplotlib_explicit_figure(self) -> None:
        """MatplotlibFigure from explicit figure serializes to PNG bytes."""
        import matplotlib
        matplotlib.use("Agg")  # non-interactive backend
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [4, 5, 6])
        mf = MatplotlibFigure(fig)
        data, content_type = mf._serialize()
        assert _is_png(data)
        assert content_type == "image/png"
        assert len(data) > 100  # non-trivial PNG
        plt.close(fig)

    def test_matplotlib_gcf(self) -> None:
        """MatplotlibFigure with no fig arg captures gcf()."""
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        plt.figure()
        plt.plot([0, 1], [0, 1])
        mf = MatplotlibFigure()
        data, content_type = mf._serialize()
        assert _is_png(data)
        assert content_type == "image/png"
        plt.close("all")

    def test_matplotlib_caption(self) -> None:
        """Caption attribute is stored correctly."""
        mf = MatplotlibFigure(caption="loss curve")
        assert mf.caption == "loss curve"

    def test_matplotlib_custom_dpi(self) -> None:
        """Custom DPI produces larger PNG than low DPI."""
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots()
        ax.plot([1, 2, 3], [4, 5, 6])

        mf_low = MatplotlibFigure(fig, dpi=50)
        data_low, _ = mf_low._serialize()

        mf_high = MatplotlibFigure(fig, dpi=300)
        data_high, _ = mf_high._serialize()

        assert len(data_high) > len(data_low)
        plt.close(fig)

    def test_matplotlib_roundtrip(self) -> None:
        """PNG output is a valid image loadable by PIL."""
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt

        fig, ax = plt.subplots(figsize=(4, 3))
        ax.bar([1, 2, 3], [10, 20, 15])
        mf = MatplotlibFigure(fig)
        data, _ = mf._serialize()

        pil = PILImage.open(io.BytesIO(data))
        assert pil.size[0] > 0
        assert pil.size[1] > 0
        plt.close(fig)


# ---------------------------------------------------------------------------
# PlotlyChart tests
# ---------------------------------------------------------------------------

class TestPlotlyChart:
    """Tests for the PlotlyChart class (enhanced Plotly)."""

    def test_plotly_chart_from_dict(self) -> None:
        """PlotlyChart from dict returns data/layout with _static_image."""
        fig = {
            "data": [{"type": "scatter", "x": [1, 2], "y": [3, 4]}],
            "layout": {"title": "Test"},
        }
        pc = PlotlyChart(fig)
        result = pc._serialize()
        assert result["data"] == fig["data"]
        assert result["layout"] == fig["layout"]
        # Dict input has no to_image method, so static_image should be None
        assert result["_static_image"] is None

    def test_plotly_chart_from_object_with_to_json(self) -> None:
        """PlotlyChart from object with to_json() serializes correctly."""

        class FakeFigure:
            def to_json(self):
                return '{"data": [{"type": "bar"}], "layout": {}}'

        pc = PlotlyChart(FakeFigure())
        result = pc._serialize()
        assert result["data"] == [{"type": "bar"}]
        assert "_static_image" in result

    def test_plotly_chart_from_object_with_to_dict(self) -> None:
        """PlotlyChart from object with to_dict() serializes correctly."""

        class FakeFigure:
            def to_dict(self):
                return {"data": [{"type": "pie"}], "layout": {"title": "Pie"}}

        pc = PlotlyChart(FakeFigure())
        result = pc._serialize()
        assert result["data"][0]["type"] == "pie"

    def test_plotly_chart_caption(self) -> None:
        """Caption attribute is stored."""
        pc = PlotlyChart({}, caption="interactive chart")
        assert pc.caption == "interactive chart"

    def test_plotly_chart_static_image_with_to_image(self) -> None:
        """When to_image() is available, _static_image is populated."""
        import base64

        class FakeFigure:
            def to_json(self):
                return '{"data": [], "layout": {}}'

            def to_image(self, format="png", width=800, height=500):
                # Return fake PNG bytes
                return b"\x89PNG\r\n\x1a\n" + b"\x00" * 50

        pc = PlotlyChart(FakeFigure())
        result = pc._serialize()
        assert result["_static_image"] is not None
        # Verify it's valid base64
        decoded = base64.b64decode(result["_static_image"])
        assert decoded[:8] == b"\x89PNG\r\n\x1a\n"

    def test_plotly_chart_unsupported_type(self) -> None:
        """Unsupported type raises TypeError."""
        pc = PlotlyChart(42)
        try:
            pc._serialize()
            assert False, "Should have raised"
        except TypeError as e:
            assert "int" in str(e)


# ---------------------------------------------------------------------------
# PointCloud3D tests
# ---------------------------------------------------------------------------

class TestPointCloud3D:
    """Tests for the PointCloud3D class."""

    def test_point_cloud_basic(self) -> None:
        """PointCloud3D with xyz points serializes correctly."""
        pts = np.array([[1.0, 2.0, 3.0], [4.0, 5.0, 6.0]])
        pc = PointCloud3D(pts)
        result = pc._serialize()

        assert result["num_points"] == 2
        assert len(result["points"]) == 2
        assert result["points"][0] == [1.0, 2.0, 3.0]
        assert result["points"][1] == [4.0, 5.0, 6.0]
        assert result["colors"] is None
        assert result["labels"] is None
        assert result["bounds"]["min"] == [1.0, 2.0, 3.0]
        assert result["bounds"]["max"] == [4.0, 5.0, 6.0]

    def test_point_cloud_with_colors(self) -> None:
        """PointCloud3D with per-point colors serializes correctly."""
        pts = np.array([[0.0, 0.0, 0.0], [1.0, 1.0, 1.0]])
        colors = np.array([[255, 0, 0], [0, 255, 0]], dtype=np.uint8)
        pc = PointCloud3D(pts, colors=colors)
        result = pc._serialize()

        assert result["colors"] is not None
        assert result["colors"][0] == [255, 0, 0]
        assert result["colors"][1] == [0, 255, 0]

    def test_point_cloud_float_colors(self) -> None:
        """Float colors (0-1) are normalized to int (0-255)."""
        pts = np.array([[0.0, 0.0, 0.0]])
        colors = np.array([[1.0, 0.5, 0.0]])
        pc = PointCloud3D(pts, colors=colors)
        result = pc._serialize()

        assert result["colors"][0] == [255, 127, 0] or result["colors"][0] == [255, 128, 0]

    def test_point_cloud_with_labels(self) -> None:
        """PointCloud3D with per-point labels serializes correctly."""
        pts = np.array([[0.0, 0.0, 0.0], [1.0, 1.0, 1.0]])
        labels = ["origin", "corner"]
        pc = PointCloud3D(pts, labels=labels)
        result = pc._serialize()

        assert result["labels"] == ["origin", "corner"]

    def test_point_cloud_caption(self) -> None:
        """Caption attribute is stored correctly."""
        pts = np.zeros((1, 3))
        pc = PointCloud3D(pts, caption="lidar scan")
        assert pc.caption == "lidar scan"

    def test_point_cloud_wrong_shape(self) -> None:
        """Non-(N,3) array raises ValueError."""
        pts = np.zeros((5, 2))
        pc = PointCloud3D(pts)
        try:
            pc._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "(N, 3)" in str(e)

    def test_point_cloud_color_shape_mismatch(self) -> None:
        """Mismatched colors shape raises ValueError."""
        pts = np.zeros((3, 3))
        colors = np.zeros((2, 3))
        pc = PointCloud3D(pts, colors=colors)
        try:
            pc._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "colors shape" in str(e)

    def test_point_cloud_label_length_mismatch(self) -> None:
        """Mismatched labels length raises ValueError."""
        pts = np.zeros((3, 3))
        pc = PointCloud3D(pts, labels=["a", "b"])
        try:
            pc._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "labels length" in str(e)

    def test_point_cloud_empty(self) -> None:
        """Empty point cloud (0 points) serializes correctly."""
        pts = np.zeros((0, 3))
        pc = PointCloud3D(pts)
        result = pc._serialize()
        assert result["num_points"] == 0
        assert result["points"] == []
        assert result["bounds"]["min"] == [0, 0, 0]
        assert result["bounds"]["max"] == [0, 0, 0]

    def test_point_cloud_large(self) -> None:
        """Large point cloud (1000 points) serializes without error."""
        pts = np.random.randn(1000, 3)
        colors = np.random.randint(0, 255, (1000, 3), dtype=np.uint8)
        labels = [f"pt_{i}" for i in range(1000)]
        pc = PointCloud3D(pts, colors=colors, labels=labels)
        result = pc._serialize()
        assert result["num_points"] == 1000
        assert len(result["points"]) == 1000
        assert len(result["colors"]) == 1000
        assert len(result["labels"]) == 1000


# ---------------------------------------------------------------------------
# Embedding tests
# ---------------------------------------------------------------------------

class TestEmbedding:
    """Tests for the Embedding class."""

    def test_embedding_basic_shape(self) -> None:
        """Embedding with (N, D) vectors serializes with correct dim and count."""
        vecs = np.random.randn(50, 128)
        emb = Embedding(vecs)
        result = emb._serialize()

        assert result["count"] == 50
        assert result["dim"] == 128
        assert len(result["vectors"]) == 50
        assert len(result["vectors"][0]) == 128
        assert result["labels"] is None
        assert result["metadata"] is None

    def test_embedding_with_labels(self) -> None:
        """Embedding with per-point labels serializes correctly."""
        vecs = np.random.randn(3, 10)
        labels = ["cat", "dog", "bird"]
        emb = Embedding(vecs, labels=labels)
        result = emb._serialize()

        assert result["labels"] == ["cat", "dog", "bird"]
        assert result["count"] == 3

    def test_embedding_with_metadata(self) -> None:
        """Embedding with metadata columns serializes correctly."""
        vecs = np.random.randn(4, 8)
        metadata = {
            "species": ["cat", "dog", "cat", "bird"],
            "weight": [4.5, 25.0, 3.8, 0.5],
        }
        emb = Embedding(vecs, metadata=metadata)
        result = emb._serialize()

        assert result["metadata"] is not None
        assert result["metadata"]["species"] == ["cat", "dog", "cat", "bird"]
        assert result["metadata"]["weight"] == [4.5, 25.0, 3.8, 0.5]

    def test_embedding_label_length_mismatch(self) -> None:
        """Mismatched labels length raises ValueError."""
        vecs = np.random.randn(5, 10)
        emb = Embedding(vecs, labels=["a", "b"])
        try:
            emb._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "labels length" in str(e)

    def test_embedding_metadata_length_mismatch(self) -> None:
        """Mismatched metadata column length raises ValueError."""
        vecs = np.random.randn(3, 10)
        metadata = {"col": [1, 2]}  # only 2, need 3
        emb = Embedding(vecs, metadata=metadata)
        try:
            emb._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "metadata column" in str(e)

    def test_embedding_wrong_ndim(self) -> None:
        """1D vector raises ValueError."""
        vecs = np.random.randn(50)
        emb = Embedding(vecs)
        try:
            emb._serialize()
            assert False, "Should have raised"
        except ValueError as e:
            assert "2D" in str(e)

    def test_embedding_caption(self) -> None:
        """Caption attribute is stored correctly."""
        vecs = np.zeros((2, 4))
        emb = Embedding(vecs, caption="word embeddings")
        assert emb.caption == "word embeddings"

    def test_embedding_serialization_roundtrip(self) -> None:
        """Serialized embedding can be JSON-encoded and decoded."""
        vecs = np.array([[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]])
        labels = ["a", "b", "c"]
        metadata = {"group": ["x", "x", "y"]}
        emb = Embedding(vecs, labels=labels, metadata=metadata, caption="test")
        result = emb._serialize()

        # Verify JSON round-trip
        json_str = json.dumps(result)
        loaded = json.loads(json_str)
        assert loaded["vectors"] == [[1.0, 2.0], [3.0, 4.0], [5.0, 6.0]]
        assert loaded["labels"] == ["a", "b", "c"]
        assert loaded["metadata"]["group"] == ["x", "x", "y"]
        assert loaded["dim"] == 2
        assert loaded["count"] == 3
