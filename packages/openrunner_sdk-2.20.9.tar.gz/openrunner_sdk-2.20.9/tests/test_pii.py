"""Tests for client-side PII redaction module."""

import re

import pytest

from openrunner.pii import (
    _config,
    configure_pii,
    is_pii_enabled,
    redact,
    redact_dict,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


@pytest.fixture(autouse=True)
def reset_pii_config():
    """Reset PII config between tests."""
    configure_pii(enabled=False)
    yield
    configure_pii(enabled=False)


# ---------------------------------------------------------------------------
# configure_pii
# ---------------------------------------------------------------------------


class TestConfigurePII:
    def test_enable(self):
        configure_pii(enabled=True)
        assert is_pii_enabled() is True

    def test_disable(self):
        configure_pii(enabled=True)
        configure_pii(enabled=False)
        assert is_pii_enabled() is False

    def test_custom_entity_types(self):
        configure_pii(enabled=True, entity_types=["EMAIL", "SSN"])
        assert _config.entity_types == ["EMAIL", "SSN"]

    def test_default_entity_types_when_none(self):
        configure_pii(enabled=True, entity_types=None)
        assert "EMAIL" in _config.entity_types
        assert "PHONE" in _config.entity_types
        assert "SSN" in _config.entity_types

    def test_custom_patterns(self):
        configure_pii(
            enabled=True,
            custom_patterns={"EMPLOYEE_ID": r"EMP-\d{6}"},
        )
        assert "EMPLOYEE_ID" in _config.custom_patterns
        assert isinstance(_config.custom_patterns["EMPLOYEE_ID"], re.Pattern)

    def test_invalid_custom_pattern_is_skipped(self):
        configure_pii(
            enabled=True,
            custom_patterns={"BAD": r"[invalid"},
        )
        assert "BAD" not in _config.custom_patterns


# ---------------------------------------------------------------------------
# redact - EMAIL
# ---------------------------------------------------------------------------


class TestRedactEmail:
    def test_simple_email(self):
        result = redact("Contact: user@example.com", entity_types=["EMAIL"])
        assert result == "Contact: [EMAIL_REDACTED]"

    def test_email_with_plus(self):
        result = redact("send to user+tag@gmail.com ok", entity_types=["EMAIL"])
        assert result == "send to [EMAIL_REDACTED] ok"

    def test_multiple_emails(self):
        text = "a@b.com and c@d.org"
        result = redact(text, entity_types=["EMAIL"])
        assert "[EMAIL_REDACTED]" in result
        assert "@" not in result

    def test_no_email(self):
        result = redact("no email here", entity_types=["EMAIL"])
        assert result == "no email here"


# ---------------------------------------------------------------------------
# redact - PHONE
# ---------------------------------------------------------------------------


class TestRedactPhone:
    def test_us_format(self):
        result = redact("Call 555-123-4567", entity_types=["PHONE"])
        assert "555-123-4567" not in result
        assert "[PHONE_REDACTED]" in result

    def test_with_country_code(self):
        result = redact("Phone: +1 555 123 4567", entity_types=["PHONE"])
        assert "[PHONE_REDACTED]" in result

    def test_parens_format(self):
        result = redact("Call (555) 123-4567", entity_types=["PHONE"])
        assert "[PHONE_REDACTED]" in result


# ---------------------------------------------------------------------------
# redact - SSN
# ---------------------------------------------------------------------------


class TestRedactSSN:
    def test_ssn(self):
        result = redact("SSN: 123-45-6789", entity_types=["SSN"])
        assert result == "SSN: [SSN_REDACTED]"

    def test_not_ssn(self):
        result = redact("ID: 12345", entity_types=["SSN"])
        assert result == "ID: 12345"


# ---------------------------------------------------------------------------
# redact - CREDIT_CARD
# ---------------------------------------------------------------------------


class TestRedactCreditCard:
    def test_visa(self):
        result = redact("Card: 4111111111111111", entity_types=["CREDIT_CARD"])
        assert "[CREDIT_CARD_REDACTED]" in result

    def test_with_spaces(self):
        result = redact("Card: 4111 1111 1111 1111", entity_types=["CREDIT_CARD"])
        assert "[CREDIT_CARD_REDACTED]" in result

    def test_with_dashes(self):
        result = redact("Card: 4111-1111-1111-1111", entity_types=["CREDIT_CARD"])
        assert "[CREDIT_CARD_REDACTED]" in result


# ---------------------------------------------------------------------------
# redact - IP_ADDRESS
# ---------------------------------------------------------------------------


class TestRedactIPAddress:
    def test_ipv4(self):
        result = redact("Server at 192.168.1.100", entity_types=["IP_ADDRESS"])
        assert result == "Server at [IP_ADDRESS_REDACTED]"

    def test_invalid_ip_not_matched(self):
        result = redact("Version 999.999.999.999", entity_types=["IP_ADDRESS"])
        # 999 is > 255, so should NOT match the IP pattern
        assert result == "Version 999.999.999.999"

    def test_localhost(self):
        result = redact("Connect to 127.0.0.1", entity_types=["IP_ADDRESS"])
        assert result == "Connect to [IP_ADDRESS_REDACTED]"


# ---------------------------------------------------------------------------
# redact - AWS_KEY
# ---------------------------------------------------------------------------


class TestRedactAWSKey:
    def test_akia_key(self):
        result = redact("Key: AKIAIOSFODNN7EXAMPLE", entity_types=["AWS_KEY"])
        assert result == "Key: [AWS_KEY_REDACTED]"

    def test_asia_key(self):
        result = redact("Key: ASIAIOSFODNN7EXAMPLE", entity_types=["AWS_KEY"])
        assert result == "Key: [AWS_KEY_REDACTED]"

    def test_short_key_not_matched(self):
        result = redact("Key: AKIA12345", entity_types=["AWS_KEY"])
        assert result == "Key: AKIA12345"


# ---------------------------------------------------------------------------
# redact - API_KEY
# ---------------------------------------------------------------------------


class TestRedactAPIKey:
    def test_api_key_in_text(self):
        result = redact(
            "api_key=sk-abc123def456ghi789jkl012mno",
            entity_types=["API_KEY"],
        )
        assert "[API_KEY_REDACTED]" in result
        assert "sk-abc123def456ghi789jkl012mno" not in result

    def test_bearer_token(self):
        result = redact(
            "bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9",
            entity_types=["API_KEY"],
        )
        assert "[API_KEY_REDACTED]" in result

    def test_secret_key_quoted(self):
        result = redact(
            'secret_key="my-long-secret-value-12345678"',
            entity_types=["API_KEY"],
        )
        assert "[API_KEY_REDACTED]" in result


# ---------------------------------------------------------------------------
# redact - custom patterns
# ---------------------------------------------------------------------------


class TestRedactCustomPatterns:
    def test_custom_pattern(self):
        configure_pii(
            enabled=True,
            entity_types=["EMPLOYEE_ID"],
            custom_patterns={"EMPLOYEE_ID": r"EMP-\d{6}"},
        )
        result = redact("Employee: EMP-123456")
        assert result == "Employee: [EMPLOYEE_ID_REDACTED]"

    def test_custom_pattern_with_builtins(self):
        configure_pii(
            enabled=True,
            entity_types=["EMAIL", "EMPLOYEE_ID"],
            custom_patterns={"EMPLOYEE_ID": r"EMP-\d{6}"},
        )
        text = "user@test.com is EMP-654321"
        result = redact(text)
        assert "[EMAIL_REDACTED]" in result
        assert "[EMPLOYEE_ID_REDACTED]" in result


# ---------------------------------------------------------------------------
# redact - edge cases
# ---------------------------------------------------------------------------


class TestRedactEdgeCases:
    def test_none_input(self):
        assert redact(None) is None

    def test_empty_string(self):
        assert redact("") == ""

    def test_non_string_passthrough(self):
        assert redact(42) == 42

    def test_all_types_at_once(self):
        text = (
            "Email: user@example.com, "
            "SSN: 123-45-6789, "
            "IP: 10.0.0.1"
        )
        result = redact(text, entity_types=["EMAIL", "SSN", "IP_ADDRESS"])
        assert "user@example.com" not in result
        assert "123-45-6789" not in result
        assert "10.0.0.1" not in result

    def test_uses_global_config_when_no_types_specified(self):
        configure_pii(enabled=True, entity_types=["EMAIL"])
        result = redact("user@test.com and 123-45-6789")
        # Only EMAIL should be redacted (SSN not in entity_types)
        assert "[EMAIL_REDACTED]" in result
        assert "123-45-6789" in result


# ---------------------------------------------------------------------------
# redact_dict
# ---------------------------------------------------------------------------


class TestRedactDict:
    def test_disabled_passthrough(self):
        configure_pii(enabled=False)
        data = {"prompt": "email user@test.com"}
        assert redact_dict(data) == data

    def test_enabled_redacts_strings(self):
        configure_pii(enabled=True, entity_types=["EMAIL"])
        data = {"prompt": "email user@test.com"}
        result = redact_dict(data)
        assert result["prompt"] == "email [EMAIL_REDACTED]"

    def test_nested_dict(self):
        configure_pii(enabled=True, entity_types=["EMAIL"])
        data = {"outer": {"inner": "alice@acme.com"}}
        result = redact_dict(data)
        assert result["outer"]["inner"] == "[EMAIL_REDACTED]"

    def test_list_values(self):
        configure_pii(enabled=True, entity_types=["EMAIL"])
        data = {"messages": ["hello", "reply to bob@test.org"]}
        result = redact_dict(data)
        assert result["messages"][0] == "hello"
        assert "[EMAIL_REDACTED]" in result["messages"][1]

    def test_non_string_values_preserved(self):
        configure_pii(enabled=True, entity_types=["EMAIL"])
        data = {"count": 42, "ratio": 0.5, "flag": True}
        result = redact_dict(data)
        assert result == data

    def test_none_value(self):
        configure_pii(enabled=True)
        assert redact_dict(None) is None

    def test_primitive_passthrough(self):
        configure_pii(enabled=True)
        assert redact_dict(42) == 42
        assert redact_dict(True) is True
