"""Tests for openrunner.config.Config object."""

from __future__ import annotations

import pytest

from openrunner.config import Config


class TestConfigBasicAccess:
    """Test dict-style and dot notation access."""

    def test_dict_style_get_set(self) -> None:
        config = Config()
        config["lr"] = 0.01
        assert config["lr"] == 0.01

    def test_dot_notation_get_set(self) -> None:
        config = Config()
        config.lr = 0.01
        assert config.lr == 0.01

    def test_dict_and_dot_are_same(self) -> None:
        config = Config()
        config["lr"] = 0.01
        assert config.lr == 0.01
        config.epochs = 10
        assert config["epochs"] == 10

    def test_contains(self) -> None:
        config = Config({"lr": 0.01})
        assert "lr" in config
        assert "missing" not in config


class TestConfigInit:
    """Test initialization with initial dict."""

    def test_init_with_flat_dict(self) -> None:
        config = Config({"lr": 0.01, "epochs": 10})
        assert config["lr"] == 0.01
        assert config["epochs"] == 10

    def test_init_with_nested_dict(self) -> None:
        config = Config({"optimizer": {"lr": 0.01, "weight_decay": 0.0001}})
        assert config["optimizer.lr"] == 0.01
        assert config["optimizer.weight_decay"] == 0.0001


class TestConfigNestedFlattening:
    """Test nested dict flattening and sub-config access."""

    def test_update_flattens_nested(self) -> None:
        config = Config()
        config.update({"optimizer": {"lr": 0.01, "beta1": 0.9}})
        assert config["optimizer.lr"] == 0.01
        assert config["optimizer.beta1"] == 0.9

    def test_deeply_nested_flattening(self) -> None:
        config = Config()
        config.update({"model": {"encoder": {"layers": 12}}})
        assert config["model.encoder.layers"] == 12

    def test_dot_notation_for_nested(self) -> None:
        config = Config({"optimizer": {"lr": 0.01}})
        sub = config.optimizer
        assert sub.lr == 0.01

    def test_nested_prefix_returns_sub_config(self) -> None:
        config = Config({"opt.lr": 0.01, "opt.wd": 0.001, "epochs": 10})
        sub = config.opt
        assert isinstance(sub, Config)
        assert sub.lr == 0.01
        assert sub.wd == 0.001

    def test_update_merge(self) -> None:
        config = Config({"lr": 0.01})
        config.update({"epochs": 10})
        assert config["lr"] == 0.01
        assert config["epochs"] == 10


class TestConfigAsDict:
    """Test as_dict() output."""

    def test_as_dict_returns_flat_copy(self) -> None:
        config = Config({"optimizer": {"lr": 0.01}})
        d = config.as_dict()
        assert d == {"optimizer.lr": 0.01}
        # Verify it's a copy
        d["extra"] = True
        assert "extra" not in config

    def test_as_dict_empty(self) -> None:
        config = Config()
        assert config.as_dict() == {}


class TestConfigIteration:
    """Test dict-like iteration methods."""

    def test_keys(self) -> None:
        config = Config({"a": 1, "b": 2})
        assert set(config.keys()) == {"a", "b"}

    def test_values(self) -> None:
        config = Config({"a": 1, "b": 2})
        assert set(config.values()) == {1, 2}

    def test_items(self) -> None:
        config = Config({"a": 1, "b": 2})
        assert set(config.items()) == {("a", 1), ("b", 2)}


class TestConfigRepr:
    """Test string representation."""

    def test_repr_contains_data(self) -> None:
        config = Config({"lr": 0.01})
        r = repr(config)
        assert "lr" in r
        assert "0.01" in r


class TestConfigMissingKey:
    """Test error handling for missing keys."""

    def test_missing_getattr_raises(self) -> None:
        config = Config()
        with pytest.raises(AttributeError, match="no key"):
            _ = config.nonexistent

    def test_missing_getitem_raises(self) -> None:
        config = Config()
        with pytest.raises(KeyError):
            _ = config["nonexistent"]
