"""Tests for the W&B migration tool.

Tests the migrate CLI command and the migrate_from_wandb function
using mocked W&B and OpenRunner API clients.
"""

from __future__ import annotations

import io
import json
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
from click.testing import CliRunner

from openrunner.cli import main


@pytest.fixture
def runner():
    return CliRunner()


@pytest.fixture
def settings_dir(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    """Redirect ~/.openrunner/ to tmp_path/.openrunner for test isolation."""
    openrunner_dir = tmp_path / ".openrunner"
    openrunner_dir.mkdir()
    monkeypatch.setattr(
        "openrunner.cli._settings_dir",
        lambda: openrunner_dir,
    )
    return openrunner_dir


def _make_wb_run(
    name: str = "run-1",
    run_id: str = "abc123",
    state: str = "finished",
    config: dict | None = None,
    summary: dict | None = None,
    tags: list[str] | None = None,
    notes: str | None = None,
    group: str | None = None,
    job_type: str | None = None,
    history_rows: list[dict] | None = None,
) -> MagicMock:
    """Create a mock W&B run object."""
    wb_run = MagicMock()
    wb_run.name = name
    wb_run.id = run_id
    wb_run.state = state
    wb_run.config = config or {"lr": 0.01, "epochs": 10}
    wb_run.summary = summary or {"loss": 0.5, "accuracy": 0.9, "_runtime": 100}
    wb_run.tags = tags or ["baseline"]
    wb_run.notes = notes or "test run"
    wb_run.group = group
    wb_run.job_type = job_type

    # scan_history returns an iterator of rows
    rows = history_rows or [
        {"_step": 0, "loss": 1.0, "accuracy": 0.1},
        {"_step": 1, "loss": 0.5, "accuracy": 0.5},
        {"_step": 2, "loss": 0.3, "accuracy": 0.9},
    ]
    wb_run.scan_history.return_value = iter(rows)

    # history() returns a DataFrame-like for dry run
    history_df = MagicMock()
    history_df.columns = ["loss", "accuracy", "_step"]
    wb_run.history.return_value = history_df

    return wb_run


def _capture_migrate(func, **kwargs) -> str:
    """Call migrate_from_wandb and capture stdout output."""
    captured = io.StringIO()
    old_stdout = sys.stdout
    sys.stdout = captured
    try:
        func(**kwargs)
    finally:
        sys.stdout = old_stdout
    return captured.getvalue()


class TestMigrateCLI:
    """Tests for the migrate CLI command."""

    def test_migrate_requires_from_wandb(self, runner, settings_dir):
        """Without --from-wandb, prints help message."""
        result = runner.invoke(
            main,
            ["migrate", "--entity", "team", "--project", "proj"],
        )
        assert result.exit_code == 0
        assert "only --from-wandb is supported" in result.output

    def test_migrate_missing_entity(self, runner, settings_dir):
        """--entity is required."""
        result = runner.invoke(
            main,
            ["migrate", "--from-wandb", "--project", "proj"],
        )
        assert result.exit_code != 0

    def test_migrate_missing_project(self, runner, settings_dir):
        """--project is required."""
        result = runner.invoke(
            main,
            ["migrate", "--from-wandb", "--entity", "team"],
        )
        assert result.exit_code != 0

    def test_migrate_help_lists_migrate(self, runner, settings_dir):
        """The migrate command appears in CLI help output."""
        result = runner.invoke(main, ["--help"])
        assert result.exit_code == 0
        assert "migrate" in result.output


class TestMigrateFromWandB:
    """Tests for the migrate_from_wandb function."""

    def test_dry_run_prints_runs(self):
        """Dry run lists discovered runs without importing."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = [
            _make_wb_run(name="run-1", run_id="r1"),
            _make_wb_run(name="run-2", run_id="r2"),
        ]

        with patch.dict("sys.modules", {"wandb": mock_wandb}):
            from openrunner.migrate import migrate_from_wandb

            output = _capture_migrate(
                migrate_from_wandb,
                entity="myteam",
                project="myproject",
                dry_run=True,
            )

        assert "Found 2 runs" in output
        assert "run-1" in output
        assert "run-2" in output
        assert "Dry run complete" in output

    def test_imports_single_run(self):
        """Imports a single run with config, metrics, and state."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        wb_run = _make_wb_run(name="train-v1", run_id="abc123", state="finished")
        mock_api.runs.return_value = [wb_run]

        mock_client = MagicMock()
        mock_client.create_run.return_value = {"id": "new-run-id"}
        mock_client.post_metrics.return_value = 6
        mock_client.update_run.return_value = {"id": "new-run-id"}

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            output = _capture_migrate(
                migrate_from_wandb,
                entity="myteam",
                project="myproject",
            )

        assert "1 imported" in output
        assert "0 failed" in output

        # Verify create_run was called with correct payload
        create_call = mock_client.create_run.call_args[0][0]
        assert create_call["project"] == "myteam/myproject"
        assert create_call["display_name"] == "train-v1"
        assert create_call["config"]["lr"] == 0.01

        # Verify metrics were posted
        mock_client.post_metrics.assert_called()

        # Verify state was updated
        update_call = mock_client.update_run.call_args
        assert update_call[0][0] == "new-run-id"
        assert update_call[0][1]["state"] == "finished"

    def test_limit_restricts_runs(self):
        """--limit restricts the number of runs imported."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = [
            _make_wb_run(name=f"run-{i}", run_id=f"r{i}") for i in range(10)
        ]

        mock_client = MagicMock()
        mock_client.create_run.return_value = {"id": "new-id"}
        mock_client.post_metrics.return_value = 0
        mock_client.update_run.return_value = {}

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            output = _capture_migrate(
                migrate_from_wandb,
                entity="myteam",
                project="myproject",
                limit=3,
            )

        assert "Found 3 runs" in output
        assert mock_client.create_run.call_count == 3

    def test_target_project_override(self):
        """--target-project overrides the default project name."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = [_make_wb_run()]

        mock_client = MagicMock()
        mock_client.create_run.return_value = {"id": "new-id"}
        mock_client.post_metrics.return_value = 0
        mock_client.update_run.return_value = {}

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            _capture_migrate(
                migrate_from_wandb,
                entity="myteam",
                project="myproject",
                target_project="custom/project",
            )

        create_call = mock_client.create_run.call_args[0][0]
        assert create_call["project"] == "custom/project"

    def test_state_mapping(self):
        """W&B run states are mapped correctly to OpenRunner states."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = [
            _make_wb_run(name="crashed-run", run_id="c1", state="crashed"),
        ]

        mock_client = MagicMock()
        mock_client.create_run.return_value = {"id": "new-id"}
        mock_client.post_metrics.return_value = 0
        mock_client.update_run.return_value = {}

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            _capture_migrate(migrate_from_wandb, entity="t", project="p")

        update_call = mock_client.update_run.call_args[0][1]
        assert update_call["state"] == "crashed"

    def test_summary_filters_internal_keys(self):
        """W&B internal keys (starting with _) are filtered from summary."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = [
            _make_wb_run(
                summary={
                    "loss": 0.5,
                    "_runtime": 100,
                    "_wandb": {"internal": True},
                    "accuracy": 0.95,
                }
            ),
        ]

        mock_client = MagicMock()
        mock_client.create_run.return_value = {"id": "new-id"}
        mock_client.post_metrics.return_value = 0
        mock_client.update_run.return_value = {}

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            _capture_migrate(migrate_from_wandb, entity="t", project="p")

        update_call = mock_client.update_run.call_args[0][1]
        summary = update_call["summary"]
        assert "loss" in summary
        assert "accuracy" in summary
        assert "_runtime" not in summary
        assert "_wandb" not in summary

    def test_handles_create_run_failure(self):
        """If create_run returns None, the run is counted as failed."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = [_make_wb_run()]

        mock_client = MagicMock()
        mock_client.create_run.return_value = None  # Simulate failure

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            output = _capture_migrate(
                migrate_from_wandb, entity="t", project="p"
            )

        assert "0 imported" in output
        assert "1 failed" in output

    def test_uses_custom_wandb_api_key(self):
        """Custom wandb_api_key is passed to wandb.Api()."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = []

        mock_client = MagicMock()

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            _capture_migrate(
                migrate_from_wandb,
                entity="t",
                project="p",
                wandb_api_key="custom-key-123",
            )

        mock_wandb.Api.assert_called_once_with(api_key="custom-key-123")

    def test_metric_batching(self):
        """Metrics are flushed in batches when count exceeds 5000."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api

        # Create a run with enough rows to trigger batching
        # Each row has 2 metric keys, so 2500+ rows should trigger a batch
        rows = [
            {"_step": i, "loss": float(i), "accuracy": float(i) / 3000}
            for i in range(3000)
        ]
        wb_run = _make_wb_run(history_rows=rows)
        mock_api.runs.return_value = [wb_run]

        mock_client = MagicMock()
        mock_client.create_run.return_value = {"id": "new-id"}
        mock_client.post_metrics.return_value = 0
        mock_client.update_run.return_value = {}

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            _capture_migrate(migrate_from_wandb, entity="t", project="p")

        # Should have been called at least twice (batch flush + remainder)
        assert mock_client.post_metrics.call_count >= 2

    def test_wandb_not_installed(self):
        """ImportError is raised with helpful message when wandb is not installed."""
        from openrunner.migrate import migrate_from_wandb

        with patch.dict("sys.modules", {"wandb": None}):
            with pytest.raises(ImportError, match="pip install wandb"):
                migrate_from_wandb(entity="t", project="p")

    def test_client_closed_after_import(self):
        """APIClient.close() is called after migration completes."""
        mock_wandb = MagicMock()
        mock_api = MagicMock()
        mock_wandb.Api.return_value = mock_api
        mock_api.runs.return_value = []

        mock_client = MagicMock()

        with patch.dict("sys.modules", {"wandb": mock_wandb}), \
             patch("openrunner.api_client.APIClient", return_value=mock_client), \
             patch("openrunner.settings.SDKSettings") as mock_settings_cls:
            mock_settings = MagicMock()
            mock_settings.base_url = "http://localhost:8000"
            mock_settings.api_key = "test-key"
            mock_settings_cls.return_value = mock_settings

            from openrunner.migrate import migrate_from_wandb

            _capture_migrate(migrate_from_wandb, entity="t", project="p")

        mock_client.close.assert_called_once()
