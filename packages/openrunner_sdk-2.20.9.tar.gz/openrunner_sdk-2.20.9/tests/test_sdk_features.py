"""Tests for SDK feature additions: fork_from, resume_from, reinit, mark_preempting,
run properties, status/join, model methods, and public API query methods."""

from __future__ import annotations

import json
import os
import logging
from datetime import datetime, timezone
from pathlib import Path
from unittest.mock import MagicMock, patch, call

import httpx
import pytest

from openrunner.run import Run, _parse_fork_spec


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _mock_transport(status_code: int = 200, json_data: dict | None = None):
    """Build an httpx.MockTransport that returns *json_data*."""
    body = json.dumps(json_data or {}).encode()

    def _handler(request: httpx.Request) -> httpx.Response:
        return httpx.Response(status_code, content=body)

    return httpx.MockTransport(_handler)


# ---------------------------------------------------------------------------
# _parse_fork_spec
# ---------------------------------------------------------------------------


class TestParseForkSpec:
    def test_parse_run_id_only(self):
        """Parses plain run_id with no step."""
        run_id, step = _parse_fork_spec("abc12345")
        assert run_id == "abc12345"
        assert step is None

    def test_parse_run_id_with_step(self):
        """Parses run_id?_step=N format."""
        run_id, step = _parse_fork_spec("abc12345?_step=42")
        assert run_id == "abc12345"
        assert step == 42

    def test_parse_step_zero(self):
        """Step 0 should be valid."""
        run_id, step = _parse_fork_spec("myrun123?_step=0")
        assert run_id == "myrun123"
        assert step == 0


# ---------------------------------------------------------------------------
# fork_from
# ---------------------------------------------------------------------------


class TestForkFrom:
    def test_fork_from_creates_new_run_linked_to_parent(self):
        """fork_from should create a new run and set resumed_from_id."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "forked12", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {"lr": 0.01},
                "state": "finished",
            }
            mock_client.fork_run.return_value = {"new_run_id": "fork1234", "step": 50}
            mock_client.get_run_max_step.return_value = 100

            run = Run(
                project="test",
                fork_from="parent12?_step=50",
            )

            # Should have called fork_run on the client
            mock_client.fork_run.assert_called_once_with("parent12", 50)

            # Step should be fork_step + 1
            assert run._step == 51

            # The new run ID should come from fork_run response
            assert run.id == "fork1234"

            # Create run payload should have resumed_from_id
            call_args = mock_client.create_run.call_args[0][0]
            assert call_args["resumed_from_id"] == "parent12"

            run._sender.stop(timeout=2.0)

    def test_fork_from_without_step_uses_max(self):
        """fork_from without step copies all metrics and uses max_step + 1."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "forked12", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {},
                "state": "finished",
            }
            mock_client.fork_run.return_value = None  # fork_run returns None
            mock_client.get_run_max_step.return_value = 75

            run = Run(
                project="test",
                fork_from="parent12",
            )

            assert run._step == 76
            mock_client.fork_run.assert_called_once_with("parent12", None)

            run._sender.stop(timeout=2.0)

    def test_fork_from_raises_if_parent_not_found(self):
        """fork_from should raise RuntimeError if parent run doesn't exist."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.get_run.return_value = None

            with pytest.raises(RuntimeError, match="Cannot fork"):
                Run(project="test", fork_from="nonexist")


# ---------------------------------------------------------------------------
# resume_from
# ---------------------------------------------------------------------------


class TestResumeFrom:
    def test_resume_from_continues_as_same_run(self):
        """resume_from should keep the same run ID and truncate history."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "parent12", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "parent12",
                "config": {"lr": 0.01},
                "state": "finished",
            }
            mock_client.truncate_run_history.return_value = {
                "run_id": "parent12",
                "truncated_at": 30,
                "deleted_count": 20,
            }

            run = Run(
                project="test",
                resume_from="parent12?_step=30",
            )

            # Should keep the parent run ID
            assert run.id == "parent12"

            # Should call truncate
            mock_client.truncate_run_history.assert_called_once_with("parent12", 30)

            # Step should be resume_step + 1
            assert run._step == 31

            run._sender.stop(timeout=2.0)

    def test_resume_from_raises_if_parent_not_found(self):
        """resume_from should raise RuntimeError if parent doesn't exist."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.get_run.return_value = None

            with pytest.raises(RuntimeError, match="Cannot resume_from"):
                Run(project="test", resume_from="nonexist")


# ---------------------------------------------------------------------------
# reinit
# ---------------------------------------------------------------------------


class TestReinit:
    def test_reinit_finishes_existing_run(self):
        """reinit=True should finish the existing active run."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "run12345", "state": "running"}

            import openrunner
            openrunner._active_run = None

            # Create first run
            run1 = openrunner.init(project="test", name="run-1")
            assert run1 is not None

            # Create second run with reinit=True
            run2 = openrunner.init(project="test", name="run-2", reinit=True)
            assert run2 is not None
            assert run2 is not run1

            openrunner.finish(quiet=True)

    def test_no_reinit_returns_existing_run(self, caplog):
        """reinit=False with existing run should warn and return existing run."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "run12345", "state": "running"}

            import openrunner
            openrunner._active_run = None

            run1 = openrunner.init(project="test", name="run-1")
            assert run1 is not None

            with caplog.at_level(logging.WARNING, logger="openrunner"):
                run2 = openrunner.init(project="test", name="run-2")

            # Should return the same run
            assert run2 is run1
            assert "reinit=True" in caplog.text

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# mark_preempting
# ---------------------------------------------------------------------------


class TestMarkPreempting:
    def test_mark_preempting_sends_state_update(self):
        """mark_preempting() should update run state to 'preempting'."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "pre12345", "state": "running"}

            run = Run(project="test")
            run.mark_preempting()

            mock_client.update_run.assert_called_with(
                run.id, {"state": "preempting"}
            )

            run._sender.stop(timeout=2.0)


# ---------------------------------------------------------------------------
# Run properties
# ---------------------------------------------------------------------------


class TestRunProperties:
    def _make_run(self):
        """Create a test run with mocked client."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "prop1234", "state": "running"}
            run = Run(project="myorg/myproject")
            return run

    def test_start_time_is_utc(self):
        run = self._make_run()
        assert isinstance(run.start_time, datetime)
        assert run.start_time.tzinfo is not None
        run._sender.stop(timeout=2.0)

    def test_sweep_id_default_none(self):
        run = self._make_run()
        assert run.sweep_id is None
        run._sender.stop(timeout=2.0)

    def test_dir_includes_run_id(self):
        run = self._make_run()
        assert run.id in run.dir
        assert ".openrunner" in run.dir
        run._sender.stop(timeout=2.0)

    def test_path_tuple(self):
        run = self._make_run()
        entity, project, run_id = run.path
        assert entity == "myorg"
        assert project == "myproject"
        assert run_id == run.id
        run._sender.stop(timeout=2.0)

    def test_get_url(self):
        run = self._make_run()
        url = run.get_url()
        assert "/myorg/myproject/runs/" in url
        assert run.id in url
        run._sender.stop(timeout=2.0)

    def test_get_project_url(self):
        run = self._make_run()
        url = run.get_project_url()
        assert "/myorg/myproject/runs" in url
        run._sender.stop(timeout=2.0)


# ---------------------------------------------------------------------------
# status() and join()
# ---------------------------------------------------------------------------


class TestStatusAndJoin:
    def test_status_returns_server_data(self):
        """status() should return server-side run data."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "stat1234", "state": "running"}
            mock_client.get_run.return_value = {
                "id": "stat1234",
                "state": "running",
                "config": {"lr": 0.01},
            }

            run = Run(project="test")
            result = run.status()
            assert result["state"] == "running"

            run._sender.stop(timeout=2.0)

    def test_status_returns_empty_dict_on_failure(self):
        """status() should return empty dict when server call fails."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "stat1234", "state": "running"}
            mock_client.get_run.return_value = None

            run = Run(project="test")
            result = run.status()
            assert result == {}

            run._sender.stop(timeout=2.0)

    def test_join_calls_sender_stop(self):
        """join() should call sender.stop() with the given timeout."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "join1234", "state": "running"}

            run = Run(project="test")
            # join with a short timeout
            run.join(timeout=1.0)
            # After join, the sender should be stopped
            # (thread joined, not running)
            assert not run._sender._thread.is_alive()


# ---------------------------------------------------------------------------
# Model convenience methods
# ---------------------------------------------------------------------------


class TestModelMethods:
    def test_log_model_creates_and_logs_artifact(self, tmp_path):
        """log_model() should create an artifact and call log_artifact."""
        model_file = tmp_path / "model.pt"
        model_file.write_bytes(b"fake model data")

        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "mdl12345", "state": "running"}
            mock_client.create_artifact_version.return_value = {
                "version_id": "v1",
                "version": 1,
                "upload_urls": [],
            }
            mock_client.confirm_artifact_version.return_value = {"status": "ok"}

            run = Run(project="test")
            run.log_model(str(model_file), name="my-model")

            # Should have called create_artifact_version
            mock_client.create_artifact_version.assert_called_once()
            call_args = mock_client.create_artifact_version.call_args
            assert call_args[1].get("type") or call_args[0][2] == "model"

            run._sender.stop(timeout=2.0)

    def test_use_model_delegates_to_use_artifact(self):
        """use_model() should call use_artifact."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "use12345", "state": "running"}

            run = Run(project="test")
            with patch.object(run, "use_artifact", return_value=Path("/tmp/model")) as mock_use:
                result = run.use_model("my-model", version=3)
                mock_use.assert_called_once_with("my-model", version=3, alias=None)
                assert result == Path("/tmp/model")

            run._sender.stop(timeout=2.0)

    def test_link_model_defaults_to_latest_alias(self, tmp_path):
        """link_model() should default to ['latest'] alias."""
        model_file = tmp_path / "model.pt"
        model_file.write_bytes(b"fake model")

        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "lnk12345", "state": "running"}

            run = Run(project="test")
            with patch.object(run, "log_model") as mock_log:
                run.link_model(str(model_file), name="my-model")
                mock_log.assert_called_once_with(
                    str(model_file), name="my-model", aliases=["latest"]
                )

            run._sender.stop(timeout=2.0)


# ---------------------------------------------------------------------------
# API client: fork_run, truncate_run_history, scan_history, list_run_files
# ---------------------------------------------------------------------------


class TestAPIClientNewMethods:
    def test_fork_run_sends_post(self):
        """fork_run should POST to /runs/{id}/fork."""
        from openrunner.api_client import APIClient

        resp_data = {"new_run_id": "fork1234", "step": 50}
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.fork_run("parent12", step=50)
        assert result == resp_data

    def test_truncate_run_history_sends_post(self):
        """truncate_run_history should POST to /runs/{id}/truncate."""
        from openrunner.api_client import APIClient

        resp_data = {"run_id": "parent12", "truncated_at": 30, "deleted_count": 20}
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.truncate_run_history("parent12", 30)
        assert result == resp_data

    def test_scan_history_returns_metrics(self):
        """scan_history should return metric points list."""
        from openrunner.api_client import APIClient

        resp_data = {"metrics": [{"key": "loss", "step": 0, "value": 0.5}]}
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.scan_history("run123")
        assert len(result) == 1
        assert result[0]["key"] == "loss"

    def test_list_run_files_returns_list(self):
        """list_run_files should return file list."""
        from openrunner.api_client import APIClient

        resp_data = [{"name": "model.pt", "size": 1000}]
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.list_run_files("run123")
        assert len(result) == 1
        assert result[0]["name"] == "model.pt"

    def test_get_run_logged_artifacts(self):
        """get_run_logged_artifacts should return artifact list."""
        from openrunner.api_client import APIClient

        resp_data = [{"name": "my-model", "type": "model"}]
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.get_run_logged_artifacts("run123")
        assert len(result) == 1

    def test_get_run_used_artifacts(self):
        """get_run_used_artifacts should return artifact list."""
        from openrunner.api_client import APIClient

        resp_data = [{"name": "my-dataset", "type": "dataset"}]
        transport = _mock_transport(200, resp_data)
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.get_run_used_artifacts("run123")
        assert len(result) == 1

    def test_scan_history_handles_failure(self):
        """scan_history should return empty list on failure."""
        from openrunner.api_client import APIClient

        transport = _mock_transport(500, {"error": "internal"})
        client = APIClient("http://localhost:8000", "key", transport=transport)

        result = client.scan_history("run123")
        assert result == []
