"""Shared test fixtures for the OpenRunner SDK test suite."""

from __future__ import annotations

import os
import subprocess
import tempfile
from pathlib import Path
from typing import Generator
from unittest.mock import MagicMock

import pytest


@pytest.fixture
def clean_env(monkeypatch: pytest.MonkeyPatch) -> pytest.MonkeyPatch:
    """Clear all OPENRUNNER_*, OPENRUN_*, and WANDB_* env vars for a clean test environment."""
    for var in list(os.environ):
        if var.startswith(("OPENRUNNER_", "OPENRUN_", "WANDB_")):
            monkeypatch.delenv(var, raising=False)
    return monkeypatch


@pytest.fixture
def temp_git_repo(tmp_path: Path) -> Generator[Path, None, None]:
    """Create a temporary git repo with an initial commit.

    Yields the path to the repo directory.
    """
    repo_dir = tmp_path / "test-repo"
    repo_dir.mkdir()

    # Initialize repo
    subprocess.run(
        ["git", "init"],
        cwd=repo_dir,
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.email", "test@example.com"],
        cwd=repo_dir,
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "config", "user.name", "Test User"],
        cwd=repo_dir,
        capture_output=True,
        check=True,
    )

    # Create a file and make initial commit
    (repo_dir / "README.md").write_text("# Test Repo\n")
    subprocess.run(
        ["git", "add", "."],
        cwd=repo_dir,
        capture_output=True,
        check=True,
    )
    subprocess.run(
        ["git", "commit", "-m", "Initial commit"],
        cwd=repo_dir,
        capture_output=True,
        check=True,
    )

    yield repo_dir


@pytest.fixture
def block_import(monkeypatch: pytest.MonkeyPatch):
    """Return a helper that blocks a module from being imported.

    Usage:
        def test_foo(block_import):
            block_import("torch")
            with pytest.raises(ImportError):
                import openrunner.integration.pytorch
    """
    import builtins
    import sys

    real_import = builtins.__import__
    blocked: set[str] = set()

    def mock_import(name, *args, **kwargs):
        for pkg in blocked:
            if name == pkg or name.startswith(pkg + "."):
                raise ImportError(f"No module named '{name}'")
        return real_import(name, *args, **kwargs)

    monkeypatch.setattr(builtins, "__import__", mock_import)

    def _block(module_name: str):
        blocked.add(module_name)
        # Remove from sys.modules
        to_remove = [k for k in sys.modules if k == module_name or k.startswith(module_name + ".")]
        for k in to_remove:
            monkeypatch.delitem(sys.modules, k, raising=False)

    return _block


@pytest.fixture
def mock_http_transport() -> MagicMock:
    """Create a mock HTTP transport for testing API client without real network calls."""
    transport = MagicMock()
    transport.handle_request.return_value = MagicMock(
        status_code=200,
        json=lambda: {"ok": True},
    )
    return transport
