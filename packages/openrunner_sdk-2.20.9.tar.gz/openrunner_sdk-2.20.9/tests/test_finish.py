"""Tests for openrunner.finish() -- run completion and cleanup."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# test_finish_stops_sender
# ---------------------------------------------------------------------------

class TestFinishStopsSender:
    def test_finish_calls_sender_stop(self):
        """finish() should stop the background sender thread."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x", "state": "running"}
            mock_client.update_run.return_value = {"id": "x", "state": "finished"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            sender = run._sender

            openrunner.finish(quiet=True)

            # Sender's stop event should be set
            assert sender._stop_event.is_set()


# ---------------------------------------------------------------------------
# test_finish_sends_summary
# ---------------------------------------------------------------------------

class TestFinishSendsSummary:
    def test_finish_sends_summary_in_update(self):
        """finish() should send the summary dict via update_run."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x", "state": "running"}
            mock_client.update_run.return_value = {"id": "x", "state": "finished"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            openrunner.log({"loss": 0.5})
            openrunner.finish(quiet=True)

            # update_run should have been called with summary
            call_args = mock_client.update_run.call_args
            payload = call_args[0][1] if len(call_args[0]) > 1 else call_args[1].get("data", {})
            assert "summary" in payload
            assert payload["summary"]["loss"] == 0.5


# ---------------------------------------------------------------------------
# test_finish_sets_state_finished
# ---------------------------------------------------------------------------

class TestFinishSetsState:
    def test_finish_sets_state_to_finished(self):
        """finish() should mark the run state as 'finished' on the server."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x", "state": "running"}
            mock_client.update_run.return_value = {"id": "x", "state": "finished"}

            import openrunner
            openrunner._active_run = None

            openrunner.init(project="test")
            openrunner.finish(quiet=True)

            call_args = mock_client.update_run.call_args
            payload = call_args[0][1] if len(call_args[0]) > 1 else call_args[1].get("data", {})
            assert payload["state"] == "finished"


# ---------------------------------------------------------------------------
# test_finish_clears_active_run
# ---------------------------------------------------------------------------

class TestFinishClearsRun:
    def test_finish_clears_active_run(self):
        """finish() should set _active_run to None."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x", "state": "running"}
            mock_client.update_run.return_value = {"id": "x", "state": "finished"}

            import openrunner
            openrunner._active_run = None

            openrunner.init(project="test")
            assert openrunner._active_run is not None

            openrunner.finish(quiet=True)
            assert openrunner._active_run is None


# ---------------------------------------------------------------------------
# test_finish_with_exit_code
# ---------------------------------------------------------------------------

class TestFinishExitCode:
    def test_exit_code_passed_in_update(self):
        """finish(exit_code=1) should include exit_code in the update payload."""
        with patch("openrunner.run.APIClient") as MockClient:
            mock_client = MockClient.return_value
            mock_client.create_run.return_value = {"id": "x", "state": "running"}
            mock_client.update_run.return_value = {"id": "x", "state": "finished"}

            import openrunner
            openrunner._active_run = None

            openrunner.init(project="test")
            openrunner.finish(exit_code=1, quiet=True)

            call_args = mock_client.update_run.call_args
            payload = call_args[0][1] if len(call_args[0]) > 1 else call_args[1].get("data", {})
            assert payload["exit_code"] == 1
