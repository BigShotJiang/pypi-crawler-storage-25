"""Tests for run.log_code() and openrunner.init(save_code=...) source capture."""

from __future__ import annotations

import os
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest


# ---------------------------------------------------------------------------
# log_code tests
# ---------------------------------------------------------------------------


class TestLogCode:
    """Tests for Run.log_code() method."""

    def test_log_code_captures_py_files(self, tmp_path):
        """log_code() captures .py files from the given directory."""
        # Create some test files
        (tmp_path / "train.py").write_text("print('train')")
        (tmp_path / "model.py").write_text("class Model: pass")
        (tmp_path / "data.csv").write_text("a,b\n1,2")
        (tmp_path / "README.md").write_text("# Readme")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            result = run.log_code(root=str(tmp_path))

            # Should have created an artifact with .py files only
            assert result is not None
            create_call = MockClient.return_value.create_artifact_version.call_args
            manifest = create_call[0][3]  # fourth positional arg is manifest (run_id, name, type, files)
            names = [entry["name"] for entry in manifest]
            assert "train.py" in names
            assert "model.py" in names
            assert "data.csv" not in names
            assert "README.md" not in names

            # Artifact type should be "code" (third positional arg)
            assert create_call[0][2] == "code"

            openrunner.finish(quiet=True)

    def test_log_code_with_custom_name(self, tmp_path):
        """log_code() uses custom artifact name when provided."""
        (tmp_path / "app.py").write_text("app = True")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            result = run.log_code(root=str(tmp_path), name="my-code")

            assert result is not None
            create_call = MockClient.return_value.create_artifact_version.call_args
            # second positional arg is artifact name
            assert create_call[0][0] != ""  # run_id
            artifact_name = create_call[0][0]  # This is run_id actually
            # Check the name argument -- it's passed as the second positional arg
            assert "my-code" in str(create_call)

            openrunner.finish(quiet=True)

    def test_log_code_with_include_fn(self, tmp_path):
        """log_code() respects include_fn filter."""
        (tmp_path / "train.py").write_text("train")
        (tmp_path / "test_train.py").write_text("test")
        (tmp_path / "utils.py").write_text("utils")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            # Only include files starting with "train"
            result = run.log_code(
                root=str(tmp_path),
                include_fn=lambda p: p.startswith("train"),
            )

            assert result is not None
            create_call = MockClient.return_value.create_artifact_version.call_args
            manifest = create_call[0][3]
            names = [entry["name"] for entry in manifest]
            assert "train.py" in names
            assert "test_train.py" not in names
            assert "utils.py" not in names

            openrunner.finish(quiet=True)

    def test_log_code_with_exclude_fn(self, tmp_path):
        """log_code() respects exclude_fn filter."""
        (tmp_path / "train.py").write_text("train")
        (tmp_path / "test_train.py").write_text("test")
        (tmp_path / "utils.py").write_text("utils")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            # Exclude test files
            result = run.log_code(
                root=str(tmp_path),
                exclude_fn=lambda p: p.startswith("test_"),
            )

            assert result is not None
            create_call = MockClient.return_value.create_artifact_version.call_args
            manifest = create_call[0][3]
            names = [entry["name"] for entry in manifest]
            assert "train.py" in names
            assert "utils.py" in names
            assert "test_train.py" not in names

            openrunner.finish(quiet=True)

    def test_log_code_skips_pycache(self, tmp_path):
        """log_code() skips __pycache__ directories."""
        (tmp_path / "app.py").write_text("app")
        pycache = tmp_path / "__pycache__"
        pycache.mkdir()
        (pycache / "app.cpython-312.pyc").write_text("compiled")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            result = run.log_code(root=str(tmp_path))

            assert result is not None
            create_call = MockClient.return_value.create_artifact_version.call_args
            manifest = create_call[0][3]
            names = [entry["name"] for entry in manifest]
            assert "app.py" in names
            assert not any("__pycache__" in n for n in names)

            openrunner.finish(quiet=True)

    def test_log_code_empty_dir_returns_none(self, tmp_path):
        """log_code() returns None when no matching files found."""
        # Empty directory -- no .py files
        (tmp_path / "data.csv").write_text("a,b")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            result = run.log_code(root=str(tmp_path))
            assert result is None

            openrunner.finish(quiet=True)

    def test_log_code_invalid_root_returns_none(self):
        """log_code() returns None for non-existent root directory."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            result = run.log_code(root="/nonexistent/path/12345")
            assert result is None

            openrunner.finish(quiet=True)

    def test_log_code_captures_subdirs(self, tmp_path):
        """log_code() recursively captures .py files in subdirectories."""
        (tmp_path / "main.py").write_text("main")
        sub = tmp_path / "src"
        sub.mkdir()
        (sub / "model.py").write_text("model")
        nested = sub / "layers"
        nested.mkdir()
        (nested / "attention.py").write_text("attention")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test")
            assert run is not None

            result = run.log_code(root=str(tmp_path))

            assert result is not None
            create_call = MockClient.return_value.create_artifact_version.call_args
            manifest = create_call[0][3]
            names = [entry["name"] for entry in manifest]
            assert "main.py" in names
            assert os.path.join("src", "model.py") in names
            assert os.path.join("src", "layers", "attention.py") in names

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# save_code init parameter tests
# ---------------------------------------------------------------------------


class TestSaveCode:
    """Tests for openrunner.init(save_code=...) parameter."""

    def test_save_code_true_calls_log_code(self, tmp_path):
        """init(save_code=True) calls log_code after run creation."""
        (tmp_path / "train.py").write_text("train")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            # We need to be in the tmp_path for save_code=True to find files
            original_cwd = os.getcwd()
            try:
                os.chdir(tmp_path)
                run = openrunner.init(project="test", save_code=True)
                assert run is not None
                # Verify create_artifact_version was called (code artifact was uploaded)
                assert MockClient.return_value.create_artifact_version.called
            finally:
                os.chdir(original_cwd)
                openrunner.finish(quiet=True)

    def test_save_code_string_path(self, tmp_path):
        """init(save_code='/path/to/src') captures code from that path."""
        src_dir = tmp_path / "src"
        src_dir.mkdir()
        (src_dir / "model.py").write_text("model")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test", save_code=str(src_dir))
            assert run is not None
            # Verify create_artifact_version was called
            assert MockClient.return_value.create_artifact_version.called

            openrunner.finish(quiet=True)

    def test_save_code_false_does_not_call_log_code(self):
        """init(save_code=False) does not capture code."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test", save_code=False)
            assert run is not None
            # create_artifact_version should NOT be called
            assert not MockClient.return_value.create_artifact_version.called

            openrunner.finish(quiet=True)

    def test_save_code_false_does_not_call_log_code(self):
        """init(save_code=False) does not capture code."""
        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}

            import openrunner
            openrunner._active_run = None

            run = openrunner.init(project="test", save_code=False)
            assert run is not None
            assert not MockClient.return_value.create_artifact_version.called

            openrunner.finish(quiet=True)


# ---------------------------------------------------------------------------
# Module-level log_code tests
# ---------------------------------------------------------------------------


class TestModuleLevelLogCode:
    """Tests for openrunner.log_code() module-level function."""

    def test_log_code_no_active_run(self):
        """openrunner.log_code() returns None when no active run."""
        import openrunner
        openrunner._active_run = None

        result = openrunner.log_code()
        assert result is None

    def test_log_code_delegates_to_run(self, tmp_path):
        """openrunner.log_code() delegates to active run's log_code."""
        (tmp_path / "app.py").write_text("app")

        with patch("openrunner.run.APIClient") as MockClient:
            MockClient.return_value.create_run.return_value = {"id": "test1234"}
            MockClient.return_value.create_artifact_version.return_value = {
                "version_id": "v1",
                "upload_urls": [],
            }
            MockClient.return_value.confirm_artifact_version.return_value = None

            import openrunner
            openrunner._active_run = None

            openrunner.init(project="test")

            result = openrunner.log_code(root=str(tmp_path))
            assert result is not None

            openrunner.finish(quiet=True)
