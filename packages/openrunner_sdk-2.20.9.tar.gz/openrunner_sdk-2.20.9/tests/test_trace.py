"""Tests for the @openrunner.trace decorator and tracing infrastructure."""

from __future__ import annotations

import asyncio
import time
import threading
from unittest.mock import patch

import pytest

from openrunner.trace import (
    SpanData,
    TraceData,
    _active_traces,
    _capture_inputs,
    _capture_output,
    _compute_op_version,
    _finish_trace,
    _get_parent_span_id,
    _get_trace_id,
    _register_span,
    _safe_serialize,
    _set_parent_span_id,
    _set_trace_id,
    _start_trace,
    set_thread_id,
    set_session_id,
    trace,
)


# ---------------------------------------------------------------------------
# _safe_serialize
# ---------------------------------------------------------------------------


class TestSafeSerialize:
    def test_primitives(self):
        assert _safe_serialize(42) == 42
        assert _safe_serialize(3.14) == 3.14
        assert _safe_serialize("hello") == "hello"
        assert _safe_serialize(True) is True
        assert _safe_serialize(None) is None

    def test_dict(self):
        result = _safe_serialize({"a": 1, "b": "two"})
        assert result == {"a": 1, "b": "two"}

    def test_list(self):
        result = _safe_serialize([1, 2, 3])
        assert result == [1, 2, 3]

    def test_nested_dict(self):
        result = _safe_serialize({"a": {"b": [1, 2]}})
        assert result == {"a": {"b": [1, 2]}}

    def test_non_serializable_falls_back_to_str(self):
        obj = object()
        result = _safe_serialize(obj)
        assert isinstance(result, str)

    def test_large_list_capped(self):
        big_list = list(range(200))
        result = _safe_serialize(big_list)
        assert len(result) == 100  # capped at 100

    def test_large_dict_capped(self):
        big_dict = {f"key_{i}": i for i in range(100)}
        result = _safe_serialize(big_dict)
        assert len(result) == 50  # capped at 50


# ---------------------------------------------------------------------------
# Context management
# ---------------------------------------------------------------------------


class TestContextManagement:
    def test_trace_id_get_set(self):
        _set_trace_id(None)
        assert _get_trace_id() is None
        _set_trace_id("trace-123")
        assert _get_trace_id() == "trace-123"
        _set_trace_id(None)

    def test_parent_span_id_get_set(self):
        _set_parent_span_id(None)
        assert _get_parent_span_id() is None
        _set_parent_span_id("span-456")
        assert _get_parent_span_id() == "span-456"
        _set_parent_span_id(None)


# ---------------------------------------------------------------------------
# SpanData / TraceData
# ---------------------------------------------------------------------------


class TestSpanData:
    def test_to_dict(self):
        span = SpanData(
            id="span-1",
            trace_id="trace-1",
            parent_id=None,
            name="test_func",
            inputs={"x": 1},
            outputs={"result": 2},
            status="success",
            duration_ms=10.5,
        )
        d = span.to_dict()
        assert d["id"] == "span-1"
        assert d["name"] == "test_func"
        assert d["inputs"] == {"x": 1}
        assert d["outputs"] == {"result": 2}
        assert d["duration_ms"] == 10.5
        assert d["parent_id"] is None

    def test_error_span(self):
        span = SpanData(
            id="span-2",
            trace_id="trace-1",
            parent_id="span-1",
            name="failing_func",
            status="error",
            error="ValueError: bad input",
            duration_ms=5.0,
        )
        d = span.to_dict()
        assert d["status"] == "error"
        assert d["error"] == "ValueError: bad input"
        assert d["parent_id"] == "span-1"


class TestTraceData:
    def test_to_dict(self):
        trace_data = TraceData(
            id="trace-1",
            name="my_trace",
        )
        span = SpanData(
            id="span-1",
            trace_id="trace-1",
            parent_id=None,
            name="root",
            duration_ms=100.0,
        )
        trace_data.spans.append(span)

        d = trace_data.to_dict()
        assert d["id"] == "trace-1"
        assert d["name"] == "my_trace"
        assert len(d["spans"]) == 1
        assert d["spans"][0]["name"] == "root"


# ---------------------------------------------------------------------------
# Trace lifecycle (_start_trace, _register_span, _finish_trace)
# ---------------------------------------------------------------------------


class TestTraceLifecycle:
    def setup_method(self):
        _active_traces.clear()

    def test_start_and_finish_trace(self):
        trace_data = _start_trace("test")
        assert trace_data.id in _active_traces

        finished = _finish_trace(trace_data.id)
        assert finished is not None
        assert finished.id == trace_data.id
        assert trace_data.id not in _active_traces

    def test_finish_nonexistent_returns_none(self):
        assert _finish_trace("nonexistent") is None

    def test_register_span(self):
        trace_data = _start_trace("test")
        span = SpanData(
            id="span-1",
            trace_id=trace_data.id,
            parent_id=None,
            name="my_span",
            duration_ms=50.0,
        )
        _register_span(span)
        assert len(_active_traces[trace_data.id].spans) == 1
        _finish_trace(trace_data.id)


# ---------------------------------------------------------------------------
# @trace decorator -- sync
# ---------------------------------------------------------------------------


class TestTraceDecoratorSync:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)

    def test_basic_sync_trace(self):
        """@trace preserves function return value."""
        @trace
        def add(a, b):
            return a + b

        # Suppress sender
        with patch("openrunner.trace._send_trace"):
            result = add(3, 4)
        assert result == 7

    def test_sync_trace_preserves_name(self):
        """Decorated function preserves __name__."""
        @trace
        def my_function(x):
            return x

        assert my_function.__name__ == "my_function"

    def test_sync_trace_captures_error(self):
        """@trace re-raises exceptions."""
        @trace
        def fail():
            raise ValueError("boom")

        with patch("openrunner.trace._send_trace"):
            with pytest.raises(ValueError, match="boom"):
                fail()

    def test_sync_nested_spans(self):
        """Nested @trace calls create parent-child spans."""
        collected_traces = []

        def mock_send(t):
            collected_traces.append(t)

        @trace
        def outer(x):
            return inner(x + 1)

        @trace
        def inner(y):
            return y * 2

        with patch("openrunner.trace._send_trace", side_effect=mock_send):
            result = outer(3)

        assert result == 8
        assert len(collected_traces) == 1
        t = collected_traces[0]
        assert len(t.spans) == 2

        # One should be root (no parent), one should be child
        root_spans = [s for s in t.spans if s.parent_id is None]
        child_spans = [s for s in t.spans if s.parent_id is not None]
        assert len(root_spans) == 1
        assert len(child_spans) == 1
        assert child_spans[0].parent_id == root_spans[0].id

    def test_sync_trace_measures_duration(self):
        """@trace captures duration > 0."""
        collected_traces = []

        @trace
        def slow():
            time.sleep(0.01)
            return "done"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            slow()

        assert len(collected_traces) == 1
        span = collected_traces[0].spans[0]
        assert span.duration_ms > 5  # at least 5ms for 10ms sleep

    def test_custom_name(self):
        """@trace(name=...) uses custom span name."""
        collected_traces = []

        @trace(name="custom_operation")
        def my_func():
            return 42

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            my_func()

        assert collected_traces[0].spans[0].name == "custom_operation"


# ---------------------------------------------------------------------------
# @trace decorator -- async
# ---------------------------------------------------------------------------


class TestTraceDecoratorAsync:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)

    def test_basic_async_trace(self):
        """@trace works with async functions."""
        @trace
        async def async_add(a, b):
            return a + b

        with patch("openrunner.trace._send_trace"):
            result = asyncio.run(async_add(5, 6))
        assert result == 11

    def test_async_trace_preserves_name(self):
        """Async decorated function preserves __name__."""
        @trace
        async def my_async_func(x):
            return x

        assert my_async_func.__name__ == "my_async_func"

    def test_async_trace_captures_error(self):
        """@trace re-raises async exceptions."""
        @trace
        async def async_fail():
            raise RuntimeError("async boom")

        with patch("openrunner.trace._send_trace"):
            with pytest.raises(RuntimeError, match="async boom"):
                asyncio.run(async_fail())

    def test_async_nested_spans(self):
        """Nested async @trace calls create parent-child spans."""
        collected_traces = []

        @trace
        async def outer(x):
            return await inner(x + 1)

        @trace
        async def inner(y):
            return y * 2

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            result = asyncio.run(outer(3))

        assert result == 8
        assert len(collected_traces) == 1
        t = collected_traces[0]
        assert len(t.spans) == 2

        root_spans = [s for s in t.spans if s.parent_id is None]
        child_spans = [s for s in t.spans if s.parent_id is not None]
        assert len(root_spans) == 1
        assert len(child_spans) == 1


# ---------------------------------------------------------------------------
# Input/output capture
# ---------------------------------------------------------------------------


class TestInputOutputCapture:
    def test_capture_inputs(self):
        def func(a, b, c=10):
            pass

        result = _capture_inputs(func, (1, 2), {"c": 3})
        assert result == {"a": 1, "b": 2, "c": 3}

    def test_capture_inputs_defaults(self):
        def func(a, b=5):
            pass

        result = _capture_inputs(func, (1,), {})
        assert result == {"a": 1, "b": 5}

    def test_capture_output(self):
        result = _capture_output(42)
        assert result == {"result": 42}

    def test_capture_output_dict(self):
        result = _capture_output({"key": "value"})
        assert result == {"result": {"key": "value"}}

    def test_capture_output_none(self):
        result = _capture_output(None)
        assert result == {"result": None}


# ---------------------------------------------------------------------------
# Op versioning (Gap #1)
# ---------------------------------------------------------------------------


class TestOpVersioning:
    def test_compute_op_version_returns_hex_string(self):
        def my_func(x):
            return x + 1

        version = _compute_op_version(my_func)
        assert isinstance(version, str)
        assert len(version) == 12
        # Should be valid hex
        int(version, 16)

    def test_same_function_same_version(self):
        def my_func(x):
            return x + 1

        v1 = _compute_op_version(my_func)
        v2 = _compute_op_version(my_func)
        assert v1 == v2

    def test_different_functions_different_versions(self):
        def func_a(x):
            return x + 1

        def func_b(x):
            return x + 2

        assert _compute_op_version(func_a) != _compute_op_version(func_b)

    def test_op_version_in_span_data(self):
        """@trace includes op_version in the span."""
        collected_traces = []

        @trace
        def add(a, b):
            return a + b

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            add(1, 2)

        span = collected_traces[0].spans[0]
        assert span.op_version is not None
        assert len(span.op_version) == 12

    def test_op_version_in_to_dict(self):
        """op_version appears in to_dict() when set."""
        span = SpanData(
            id="s1", trace_id="t1", parent_id=None, name="f",
            op_version="abc123def456",
        )
        d = span.to_dict()
        assert d["op_version"] == "abc123def456"

    def test_op_version_absent_when_none(self):
        """op_version is omitted from to_dict() when None."""
        span = SpanData(id="s1", trace_id="t1", parent_id=None, name="f")
        d = span.to_dict()
        assert "op_version" not in d

    def test_builtin_function_does_not_crash(self):
        """_compute_op_version handles built-ins gracefully."""
        version = _compute_op_version(len)
        assert isinstance(version, str)
        assert len(version) == 12


# ---------------------------------------------------------------------------
# Op display customization (Gap #2)
# ---------------------------------------------------------------------------


class TestOpDisplayCustomization:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)

    def test_kind_and_color_in_span(self):
        collected_traces = []

        @trace(kind="llm", color="blue")
        def call_model(prompt):
            return "response"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            call_model("hello")

        span = collected_traces[0].spans[0]
        assert span.kind == "llm"
        assert span.color == "blue"

    def test_kind_and_color_in_to_dict(self):
        span = SpanData(
            id="s1", trace_id="t1", parent_id=None, name="f",
            kind="agent", color="green",
        )
        d = span.to_dict()
        assert d["kind"] == "agent"
        assert d["color"] == "green"

    def test_kind_and_color_absent_when_none(self):
        span = SpanData(id="s1", trace_id="t1", parent_id=None, name="f")
        d = span.to_dict()
        assert "kind" not in d
        assert "color" not in d

    def test_invalid_kind_raises(self):
        with pytest.raises(ValueError, match="Invalid kind"):
            @trace(kind="invalid_kind")
            def bad():
                pass

    def test_invalid_color_raises(self):
        with pytest.raises(ValueError, match="Invalid color"):
            @trace(color="pink")
            def bad():
                pass

    def test_all_valid_kinds(self):
        """All documented kind values are accepted."""
        for k in ("agent", "llm", "tool", "search", "chain", "embedding", "retriever", "parser", None):
            @trace(kind=k)
            def f():
                pass

    def test_all_valid_colors(self):
        """All documented color values are accepted."""
        for c in ("red", "orange", "yellow", "green", "blue", "purple", None):
            @trace(color=c)
            def f():
                pass


# ---------------------------------------------------------------------------
# Op postprocess hooks (Gap #4)
# ---------------------------------------------------------------------------


class TestPostprocessHooks:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)

    def test_postprocess_inputs_redaction(self):
        """postprocess_inputs can redact sensitive data."""
        collected_traces = []

        def redact(inputs):
            return {k: "***" if "secret" in k else v for k, v in inputs.items()}

        @trace(postprocess_inputs=redact)
        def login(username, secret_key):
            return "ok"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            login("alice", "my-api-key")

        span = collected_traces[0].spans[0]
        assert span.inputs["username"] == "alice"
        assert span.inputs["secret_key"] == "***"

    def test_postprocess_output_transform(self):
        """postprocess_output transforms logged output."""
        collected_traces = []

        def summarize(result):
            return f"len={len(result)}"

        @trace(postprocess_output=summarize)
        def get_data():
            return [1, 2, 3, 4, 5]

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            result = get_data()

        # Original return value is untouched
        assert result == [1, 2, 3, 4, 5]
        # Logged output is transformed
        span = collected_traces[0].spans[0]
        assert span.outputs["result"] == "len=5"

    def test_postprocess_inputs_error_is_swallowed(self):
        """Failing postprocess_inputs does not crash the function."""
        collected_traces = []

        def bad_pp(inputs):
            raise RuntimeError("pp failed")

        @trace(postprocess_inputs=bad_pp)
        def add(a, b):
            return a + b

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            result = add(1, 2)

        assert result == 3
        # Inputs should still be the original (unprocessed)
        span = collected_traces[0].spans[0]
        assert span.inputs["a"] == 1

    def test_postprocess_output_error_is_swallowed(self):
        """Failing postprocess_output does not crash the function."""
        collected_traces = []

        def bad_pp(result):
            raise RuntimeError("pp failed")

        @trace(postprocess_output=bad_pp)
        def add(a, b):
            return a + b

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            result = add(1, 2)

        assert result == 3
        # Output should be the original (unprocessed)
        span = collected_traces[0].spans[0]
        assert span.outputs["result"] == 3

    def test_postprocess_async(self):
        """Postprocess hooks work with async functions."""
        collected_traces = []

        @trace(
            postprocess_inputs=lambda d: {k: "REDACTED" for k in d},
            postprocess_output=lambda r: "SUMMARY",
        )
        async def async_func(secret):
            return {"data": secret}

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            result = asyncio.run(async_func("password"))

        assert result == {"data": "password"}
        span = collected_traces[0].spans[0]
        assert span.inputs["secret"] == "REDACTED"
        assert span.outputs["result"] == "SUMMARY"


# ---------------------------------------------------------------------------
# Thread/session grouping (Gap #5)
# ---------------------------------------------------------------------------


class TestThreadSessionGrouping:
    def setup_method(self):
        _active_traces.clear()
        _set_trace_id(None)
        _set_parent_span_id(None)
        set_thread_id(None)
        set_session_id(None)

    def test_module_level_thread_id(self):
        """set_thread_id propagates to span data."""
        collected_traces = []

        @trace
        def greet(name):
            return f"hi {name}"

        set_thread_id("thread-abc")
        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            greet("alice")

        span = collected_traces[0].spans[0]
        assert span.thread_id == "thread-abc"
        set_thread_id(None)

    def test_module_level_session_id(self):
        """set_session_id propagates to span data."""
        collected_traces = []

        @trace
        def greet(name):
            return f"hi {name}"

        set_session_id("session-xyz")
        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            greet("bob")

        span = collected_traces[0].spans[0]
        assert span.session_id == "session-xyz"
        set_session_id(None)

    def test_decorator_param_overrides_module_level(self):
        """thread_id/session_id on @trace override module-level."""
        collected_traces = []

        set_thread_id("global-thread")
        set_session_id("global-session")

        @trace(thread_id="local-thread", session_id="local-session")
        def greet(name):
            return f"hi {name}"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            greet("carol")

        span = collected_traces[0].spans[0]
        assert span.thread_id == "local-thread"
        assert span.session_id == "local-session"
        set_thread_id(None)
        set_session_id(None)

    def test_thread_session_absent_when_not_set(self):
        """thread_id/session_id omitted from to_dict when None."""
        span = SpanData(id="s1", trace_id="t1", parent_id=None, name="f")
        d = span.to_dict()
        assert "thread_id" not in d
        assert "session_id" not in d

    def test_thread_session_in_to_dict(self):
        """thread_id/session_id appear in to_dict when set."""
        span = SpanData(
            id="s1", trace_id="t1", parent_id=None, name="f",
            thread_id="t-1", session_id="s-1",
        )
        d = span.to_dict()
        assert d["thread_id"] == "t-1"
        assert d["session_id"] == "s-1"

    def test_thread_session_async(self):
        """Thread/session IDs work with async functions."""
        collected_traces = []

        set_thread_id("async-thread")
        set_session_id("async-session")

        @trace
        async def async_greet(name):
            return f"hi {name}"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            asyncio.run(async_greet("dave"))

        span = collected_traces[0].spans[0]
        assert span.thread_id == "async-thread"
        assert span.session_id == "async-session"
        set_thread_id(None)
        set_session_id(None)

    def test_clearing_thread_session(self):
        """Setting thread/session to None clears them."""
        collected_traces = []

        set_thread_id("temp-thread")
        set_thread_id(None)

        @trace
        def greet():
            return "hi"

        with patch("openrunner.trace._send_trace", side_effect=collected_traces.append):
            greet()

        span = collected_traces[0].spans[0]
        assert span.thread_id is None


# ---------------------------------------------------------------------------
# Public API exports
# ---------------------------------------------------------------------------


class TestPublicExports:
    def test_set_thread_id_importable_from_package(self):
        import openrunner
        assert hasattr(openrunner, "set_thread_id")
        assert callable(openrunner.set_thread_id)

    def test_set_session_id_importable_from_package(self):
        import openrunner
        assert hasattr(openrunner, "set_session_id")
        assert callable(openrunner.set_session_id)
