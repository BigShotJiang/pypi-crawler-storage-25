"""Tests for openrunner.cache -- ArtifactCache with LRU eviction."""

from __future__ import annotations

import os
import time

from openrunner.cache import ArtifactCache


class TestArtifactCache:
    """Tests for the ArtifactCache class."""

    def test_cache_put_get(self, tmp_path) -> None:
        """Put data and get returns correct path with existing file."""
        cache = ArtifactCache(cache_dir=str(tmp_path), max_size_gb=1.0)
        data = b"hello world"
        content_hash = "abc123"

        path = cache.put(content_hash, data)
        assert path.exists()
        assert path.read_bytes() == data

        retrieved = cache.get(content_hash)
        assert retrieved is not None
        assert retrieved.read_bytes() == data

    def test_cache_miss(self, tmp_path) -> None:
        """Get for nonexistent hash returns None."""
        cache = ArtifactCache(cache_dir=str(tmp_path), max_size_gb=1.0)
        result = cache.get("nonexistent_hash")
        assert result is None

    def test_cache_eviction(self, tmp_path) -> None:
        """When cache exceeds max size, oldest files are evicted."""
        # Set max size to ~50 bytes (very low)
        cache = ArtifactCache(
            cache_dir=str(tmp_path),
            max_size_gb=50 / (1024**3),  # 50 bytes
        )

        # Add file 1 (20 bytes) -- set old access time
        cache.put("file1", b"a" * 20)
        file1_path = tmp_path / "file1"
        os.utime(file1_path, (1000.0, 1000.0))

        # Add file 2 (20 bytes) -- slightly newer
        cache.put("file2", b"b" * 20)
        file2_path = tmp_path / "file2"
        os.utime(file2_path, (2000.0, 2000.0))

        # Add file 3 (20 bytes) -- newest, should trigger eviction
        # Total would be 60 > 50, so evict oldest until at 40 (80% of 50)
        cache.put("file3", b"c" * 20)

        # file1 should be evicted (oldest atime)
        assert not file1_path.exists()
        # file3 should exist (newest)
        assert (tmp_path / "file3").exists()

    def test_cache_touch_on_get(self, tmp_path) -> None:
        """Get updates atime for LRU ordering."""
        cache = ArtifactCache(cache_dir=str(tmp_path), max_size_gb=1.0)
        cache.put("touchtest", b"data")

        # Set an old atime
        path = tmp_path / "touchtest"
        old_time = 1000.0
        os.utime(path, (old_time, old_time))

        # Get should touch (update) atime
        cache.get("touchtest")

        stat = path.stat()
        # atime should now be much more recent than 1000
        assert stat.st_atime > old_time

    def test_cache_creates_directory(self, tmp_path) -> None:
        """Cache creates its directory if it doesn't exist."""
        cache_dir = tmp_path / "nested" / "cache" / "dir"
        cache = ArtifactCache(cache_dir=str(cache_dir), max_size_gb=1.0)
        assert cache_dir.exists()
