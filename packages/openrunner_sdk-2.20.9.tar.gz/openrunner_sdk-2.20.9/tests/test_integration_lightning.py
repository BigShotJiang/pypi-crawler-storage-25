"""Tests for the PyTorch Lightning integration (OpenRunnerLogger)."""

from __future__ import annotations

import sys
import types
from unittest.mock import MagicMock, patch, call

import pytest


# ---------------------------------------------------------------------------
# Mock lightning before importing the integration module
# ---------------------------------------------------------------------------

@pytest.fixture(autouse=True)
def _mock_lightning(monkeypatch):
    """Inject a fake lightning module hierarchy so lightning.py imports cleanly."""
    # Build: lightning -> lightning.pytorch -> lightning.pytorch.loggers
    lightning = types.ModuleType("lightning")
    lightning_pytorch = types.ModuleType("lightning.pytorch")
    lightning_pytorch_loggers = types.ModuleType("lightning.pytorch.loggers")

    class _Logger:
        """Fake base Logger class (no ABC enforcement)."""
        pass

    lightning_pytorch_loggers.Logger = _Logger
    lightning_pytorch.loggers = lightning_pytorch_loggers
    lightning.pytorch = lightning_pytorch

    monkeypatch.setitem(sys.modules, "lightning", lightning)
    monkeypatch.setitem(sys.modules, "lightning.pytorch", lightning_pytorch)
    monkeypatch.setitem(sys.modules, "lightning.pytorch.loggers", lightning_pytorch_loggers)
    yield
    # Clean up cached module
    sys.modules.pop("openrunner.integration.lightning", None)


# ---------------------------------------------------------------------------
# Tests
# ---------------------------------------------------------------------------

class TestOpenRunnerLogger:
    """Tests for OpenRunnerLogger."""

    def test_log_hyperparams_calls_init_and_config_update(self, monkeypatch):
        """Test 1: log_hyperparams calls openrunner.init() and openrunner.config.update()."""
        from openrunner.integration.lightning import OpenRunnerLogger
        import openrunner

        mock_run = MagicMock()
        mock_init = MagicMock(return_value=mock_run)
        mock_config = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner.config", mock_config)
        monkeypatch.setattr("openrunner._active_run", None)

        logger = OpenRunnerLogger(project="test-project", name="run-1")
        logger.log_hyperparams({"lr": 0.01, "batch_size": 32})

        mock_init.assert_called_once()
        call_kwargs = mock_init.call_args[1]
        assert call_kwargs["project"] == "test-project"
        assert call_kwargs["name"] == "run-1"
        mock_config.update.assert_called_once_with({"lr": 0.01, "batch_size": 32})

    def test_log_metrics_calls_openrunner_log(self, monkeypatch):
        """Test 2: log_metrics calls openrunner.log() with metrics dict and step."""
        from openrunner.integration.lightning import OpenRunnerLogger
        import openrunner

        mock_run = MagicMock()
        mock_init = MagicMock(return_value=mock_run)
        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        logger = OpenRunnerLogger(project="p")
        # First call lazy-inits the run
        logger.log_metrics({"loss": 0.5, "acc": 0.9}, step=100)

        mock_log.assert_called_once_with({"loss": 0.5, "acc": 0.9}, step=100)

    def test_finalize_calls_finish(self, monkeypatch):
        """Test 3: finalize() calls openrunner.finish()."""
        from openrunner.integration.lightning import OpenRunnerLogger
        import openrunner

        mock_finish = MagicMock()
        monkeypatch.setattr("openrunner.finish", mock_finish)

        logger = OpenRunnerLogger()
        logger.finalize("success")

        mock_finish.assert_called_once()

    def test_name_returns_project(self):
        """Test 4: name property returns project name."""
        from openrunner.integration.lightning import OpenRunnerLogger

        logger = OpenRunnerLogger(project="my-project")
        assert logger.name == "my-project"

    def test_version_returns_run_id_or_empty(self, monkeypatch):
        """Test 5: version returns run ID or empty string if no run."""
        from openrunner.integration.lightning import OpenRunnerLogger
        import openrunner

        logger = OpenRunnerLogger()
        assert logger.version == ""

        # After init, should return run ID
        mock_run = MagicMock()
        mock_run.id = "abc12345"
        mock_init = MagicMock(return_value=mock_run)
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner._active_run", None)

        logger2 = OpenRunnerLogger(project="p")
        logger2.log_metrics({"x": 1.0})  # triggers lazy init
        assert logger2.version == "abc12345"

    def test_lazy_init_on_log_metrics(self, monkeypatch):
        """Test 6: lazy-initializes run on first log_metrics call."""
        from openrunner.integration.lightning import OpenRunnerLogger
        import openrunner

        mock_run = MagicMock()
        mock_init = MagicMock(return_value=mock_run)
        mock_log = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner.log", mock_log)
        monkeypatch.setattr("openrunner._active_run", None)

        logger = OpenRunnerLogger(project="lazy-project", tags=["exp1"])
        # init should NOT have been called yet
        mock_init.assert_not_called()

        logger.log_metrics({"val_loss": 0.3}, step=10)
        mock_init.assert_called_once()
        assert mock_init.call_args[1]["project"] == "lazy-project"
        assert mock_init.call_args[1]["tags"] == ["exp1"]

    def test_log_hyperparams_handles_namespace(self, monkeypatch):
        """Test 7: handles namespace objects (argparse.Namespace-style)."""
        from openrunner.integration.lightning import OpenRunnerLogger
        import openrunner

        mock_run = MagicMock()
        mock_init = MagicMock(return_value=mock_run)
        mock_config = MagicMock()
        monkeypatch.setattr("openrunner.init", mock_init)
        monkeypatch.setattr("openrunner.config", mock_config)
        monkeypatch.setattr("openrunner._active_run", None)

        logger = OpenRunnerLogger(project="ns-project")

        # Simulate argparse.Namespace-like object
        class Namespace:
            def __init__(self):
                self.lr = 0.01
                self.epochs = 10

        ns = Namespace()
        logger.log_hyperparams(ns)

        # Should convert to dict and pass to config.update
        call_args = mock_config.update.call_args[0][0]
        assert call_args["lr"] == 0.01
        assert call_args["epochs"] == 10


class TestLightningImportError:
    """Test 8: clear ImportError when lightning is missing."""

    def test_import_error_when_lightning_missing(self, monkeypatch, block_import):
        block_import("lightning")
        block_import("pytorch_lightning")
        import sys
        sys.modules.pop("openrunner.integration.lightning", None)

        with pytest.raises(ImportError, match="pip install openrunner"):
            import openrunner.integration.lightning  # noqa: F401
