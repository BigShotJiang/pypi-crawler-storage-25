"""Tests for openrunner.buffer.WriteBuffer."""

from __future__ import annotations

import threading

from openrunner.buffer import WriteBuffer


class TestBufferPutDrain:
    """Test basic put and drain operations."""

    def test_put_and_drain(self) -> None:
        buf = WriteBuffer()
        buf.put({"key": "loss", "value": 0.5})
        buf.put({"key": "acc", "value": 0.9})
        items = buf.drain()
        assert len(items) == 2
        assert items[0]["key"] == "loss"
        assert items[1]["key"] == "acc"

    def test_drain_empty_returns_list(self) -> None:
        buf = WriteBuffer()
        items = buf.drain()
        assert items == []

    def test_drain_max_items(self) -> None:
        buf = WriteBuffer()
        for i in range(10):
            buf.put({"key": "m", "value": i})
        items = buf.drain(max_items=5)
        assert len(items) == 5
        # Remaining items still in buffer
        assert buf.size == 5

    def test_drain_respects_limit(self) -> None:
        buf = WriteBuffer(max_size=50)
        for i in range(3):
            buf.put({"key": "m", "value": i})
        items = buf.drain(max_items=100)
        assert len(items) == 3  # Only 3 available


class TestBufferSize:
    """Test size and is_full properties."""

    def test_size_tracks_count(self) -> None:
        buf = WriteBuffer()
        assert buf.size == 0
        buf.put({"key": "loss", "value": 0.5})
        assert buf.size == 1
        buf.put({"key": "acc", "value": 0.9})
        assert buf.size == 2
        buf.drain()
        assert buf.size == 0

    def test_is_full(self) -> None:
        buf = WriteBuffer(max_size=3)
        assert not buf.is_full
        buf.put({"a": 1})
        buf.put({"b": 2})
        buf.put({"c": 3})
        assert buf.is_full


class TestBufferThreadSafety:
    """Test thread safety with concurrent puts."""

    def test_concurrent_puts(self) -> None:
        buf = WriteBuffer(max_size=10000)
        num_threads = 10
        items_per_thread = 100

        def producer(thread_id: int) -> None:
            for i in range(items_per_thread):
                buf.put({"thread": thread_id, "idx": i})

        threads = [
            threading.Thread(target=producer, args=(t,))
            for t in range(num_threads)
        ]
        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # All items should be present
        items = buf.drain(max_items=num_threads * items_per_thread + 100)
        assert len(items) == num_threads * items_per_thread

    def test_concurrent_put_and_drain(self) -> None:
        buf = WriteBuffer(max_size=10000)
        total_items = 500
        drained: list[dict] = []
        stop = threading.Event()

        def producer() -> None:
            for i in range(total_items):
                buf.put({"value": i})

        def consumer() -> None:
            while not stop.is_set() or buf.size > 0:
                batch = buf.drain(max_items=50)
                drained.extend(batch)

        prod = threading.Thread(target=producer)
        cons = threading.Thread(target=consumer)
        prod.start()
        cons.start()
        prod.join()
        stop.set()
        cons.join()

        # All items should have been drained
        assert len(drained) == total_items
