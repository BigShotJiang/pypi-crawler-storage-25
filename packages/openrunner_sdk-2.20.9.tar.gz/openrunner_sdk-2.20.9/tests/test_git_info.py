"""Tests for openrunner.git_info.capture_git_info."""

from __future__ import annotations

import os
import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from openrunner.git_info import capture_git_info


class TestGitInfoInRepo:
    """Test capture_git_info inside a real git repo."""

    def test_captures_sha(self, temp_git_repo: Path) -> None:
        info = capture_git_info(cwd=temp_git_repo)
        assert info is not None
        assert "sha" in info
        assert len(info["sha"]) == 40  # Full SHA

    def test_captures_branch(self, temp_git_repo: Path) -> None:
        info = capture_git_info(cwd=temp_git_repo)
        assert info is not None
        assert info["branch"] in ("main", "master")

    def test_captures_dirty_status(self, temp_git_repo: Path) -> None:
        info = capture_git_info(cwd=temp_git_repo)
        assert info is not None
        assert info["dirty"] is False

        # Make repo dirty
        (temp_git_repo / "new_file.txt").write_text("dirty\n")
        info = capture_git_info(cwd=temp_git_repo)
        assert info is not None
        assert info["dirty"] is True

    def test_remote_url_none_without_remote(self, temp_git_repo: Path) -> None:
        info = capture_git_info(cwd=temp_git_repo)
        assert info is not None
        assert info["remote_url"] is None

    def test_remote_url_captured(self, temp_git_repo: Path) -> None:
        subprocess.run(
            ["git", "remote", "add", "origin", "https://github.com/test/repo.git"],
            cwd=temp_git_repo,
            capture_output=True,
            check=True,
        )
        info = capture_git_info(cwd=temp_git_repo)
        assert info is not None
        assert info["remote_url"] == "https://github.com/test/repo.git"


class TestGitInfoNotInRepo:
    """Test capture_git_info outside a git repo."""

    def test_returns_none_outside_repo(self, tmp_path: Path) -> None:
        info = capture_git_info(cwd=tmp_path)
        assert info is None


class TestGitInfoMissingBinary:
    """Test capture_git_info handles missing git binary."""

    def test_returns_none_when_git_missing(self, tmp_path: Path) -> None:
        with patch(
            "openrunner.git_info.subprocess.run",
            side_effect=FileNotFoundError("git not found"),
        ):
            info = capture_git_info(cwd=tmp_path)
            assert info is None
