"""Tests for the wandb compatibility shim."""

from __future__ import annotations

import pytest


# ---------------------------------------------------------------------------
# test_compat_imports
# ---------------------------------------------------------------------------

class TestCompatImports:
    def test_can_import_init_log_finish(self):
        """wandb_compat should export init, log, finish."""
        from openrunner.wandb_compat import init, log, finish
        assert callable(init)
        assert callable(log)
        assert callable(finish)

    def test_can_import_config_summary_run(self):
        """wandb_compat should export config, summary, run."""
        from openrunner.wandb_compat import config, summary, run
        # These are proxy objects or references -- just verify they exist
        assert config is not None
        assert summary is not None


# ---------------------------------------------------------------------------
# test_compat_same_functions
# ---------------------------------------------------------------------------

class TestCompatSameObjects:
    def test_init_is_same_as_openrunner_init(self):
        """wandb_compat.init should be the same function as openrunner.init."""
        import openrunner
        from openrunner.wandb_compat import init
        assert init is openrunner.init

    def test_log_is_same_as_openrunner_log(self):
        """wandb_compat.log should be the same function as openrunner.log."""
        import openrunner
        from openrunner.wandb_compat import log
        assert log is openrunner.log

    def test_finish_is_same_as_openrunner_finish(self):
        """wandb_compat.finish should be the same function as openrunner.finish."""
        import openrunner
        from openrunner.wandb_compat import finish
        assert finish is openrunner.finish
