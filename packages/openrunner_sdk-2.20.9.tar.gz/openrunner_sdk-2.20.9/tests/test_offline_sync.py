"""Tests for the OfflineSync class.

Validates idempotent sync of offline JSONL data to the server:
- Full sync: read meta, config, create run, sync metrics
- Position tracking: .sync_position tracks byte offset
- Idempotent re-sync: running sync twice doesn't re-send metrics
- Resume from partial position: interrupted sync resumes correctly
- 409 Conflict on run creation: fall back to PATCH
- Corrupt JSONL line: gracefully skipped
"""

from __future__ import annotations

import json
from pathlib import Path
from unittest.mock import MagicMock, call, patch

import pytest

from openrunner.offline import OfflineSync


def _create_offline_run(
    tmp_path: Path,
    run_id: str = "abc12345",
    meta: dict | None = None,
    config: dict | None = None,
    metrics: list[dict] | None = None,
    summary: dict | None = None,
) -> Path:
    """Create an offline run directory with standard files."""
    run_dir = tmp_path / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    if meta is None:
        meta = {"id": run_id, "project_id": "00000000-0000-0000-0000-000000000001"}
    (run_dir / "meta.json").write_text(json.dumps(meta), encoding="utf-8")

    if config is None:
        config = {"lr": 0.001, "epochs": 10}
    (run_dir / "config.json").write_text(json.dumps(config), encoding="utf-8")

    if metrics is not None:
        lines = [json.dumps(m) + "\n" for m in metrics]
        (run_dir / "metrics.jsonl").write_text("".join(lines), encoding="utf-8")

    if summary is not None:
        (run_dir / "summary.json").write_text(
            json.dumps(summary), encoding="utf-8"
        )

    return run_dir


class TestOfflineSyncFull:
    """Test 1: Full sync reads meta, config, creates run, syncs metrics."""

    def test_full_sync_creates_run_and_sends_metrics(self, tmp_path: Path):
        metrics = [
            {"key": "loss", "value": 0.5, "step": 0},
            {"key": "loss", "value": 0.3, "step": 1},
        ]
        run_dir = _create_offline_run(tmp_path, metrics=metrics)

        client = MagicMock()
        client.create_run.return_value = {"id": "abc12345"}
        client.sync_metrics.return_value = 2
        client.update_run.return_value = {"id": "abc12345"}

        syncer = OfflineSync(run_dir, client)
        result = syncer.sync()

        assert result is True
        client.create_run.assert_called_once()
        client.sync_metrics.assert_called()

    def test_full_sync_sends_summary_if_present(self, tmp_path: Path):
        summary = {"loss": {"min": 0.1, "max": 0.5}}
        run_dir = _create_offline_run(
            tmp_path, metrics=[], summary=summary
        )

        client = MagicMock()
        client.create_run.return_value = {"id": "abc12345"}
        client.update_run.return_value = {"id": "abc12345"}

        syncer = OfflineSync(run_dir, client)
        syncer.sync()

        # update_run should be called with summary
        update_calls = client.update_run.call_args_list
        summary_call = [c for c in update_calls if "summary" in str(c)]
        assert len(summary_call) > 0


class TestOfflineSyncPosition:
    """Test 2: sync tracks byte position in .sync_position file."""

    def test_sync_creates_position_file(self, tmp_path: Path):
        metrics = [
            {"key": "loss", "value": 0.5, "step": 0},
            {"key": "loss", "value": 0.3, "step": 1},
        ]
        run_dir = _create_offline_run(tmp_path, metrics=metrics)

        client = MagicMock()
        client.create_run.return_value = {"id": "abc12345"}
        client.sync_metrics.return_value = 2

        syncer = OfflineSync(run_dir, client)
        syncer.sync()

        pos_file = run_dir / ".sync_position"
        assert pos_file.exists()
        pos = int(pos_file.read_text().strip())
        # Position should be at end of metrics.jsonl
        metrics_size = (run_dir / "metrics.jsonl").stat().st_size
        assert pos == metrics_size


class TestOfflineSyncIdempotent:
    """Test 3: Re-syncing after full sync does not re-send metrics."""

    def test_resync_does_not_resend(self, tmp_path: Path):
        metrics = [
            {"key": "loss", "value": 0.5, "step": 0},
            {"key": "loss", "value": 0.3, "step": 1},
        ]
        run_dir = _create_offline_run(tmp_path, metrics=metrics)

        client = MagicMock()
        client.create_run.return_value = {"id": "abc12345"}
        client.sync_metrics.return_value = 2
        client.update_run.return_value = {"id": "abc12345"}

        syncer = OfflineSync(run_dir, client)
        syncer.sync()

        # Reset mock call counts
        client.sync_metrics.reset_mock()

        # Second sync should not re-send metrics
        syncer2 = OfflineSync(run_dir, client)
        syncer2.sync()

        client.sync_metrics.assert_not_called()


class TestOfflineSyncResume:
    """Test 4: Interrupted sync resumes from correct byte offset."""

    def test_resume_from_partial_position(self, tmp_path: Path):
        metrics = [
            {"key": "loss", "value": 0.5, "step": 0},
            {"key": "loss", "value": 0.3, "step": 1},
            {"key": "loss", "value": 0.1, "step": 2},
        ]
        run_dir = _create_offline_run(tmp_path, metrics=metrics)

        # Simulate interrupted sync: position after first line only
        first_line = json.dumps(metrics[0]) + "\n"
        (run_dir / ".sync_position").write_text(
            str(len(first_line.encode("utf-8"))), encoding="utf-8"
        )

        client = MagicMock()
        client.create_run.return_value = {"id": "abc12345"}
        client.sync_metrics.return_value = 2
        client.update_run.return_value = {"id": "abc12345"}

        syncer = OfflineSync(run_dir, client)
        syncer.sync()

        # Should have synced only remaining 2 metrics (not all 3)
        synced_metrics = []
        for c in client.sync_metrics.call_args_list:
            synced_metrics.extend(c[0][1])  # second arg is the metrics list
        assert len(synced_metrics) == 2
        assert synced_metrics[0]["step"] == 1
        assert synced_metrics[1]["step"] == 2


class TestOfflineSync409:
    """Test 5: 409 Conflict on run creation falls back to PATCH."""

    def test_409_fallback_to_patch(self, tmp_path: Path):
        run_dir = _create_offline_run(tmp_path, metrics=[])

        client = MagicMock()
        client.create_run.return_value = None  # simulate failure (409)
        client.update_run.return_value = {"id": "abc12345"}

        syncer = OfflineSync(run_dir, client)
        result = syncer.sync()

        assert result is True
        client.create_run.assert_called_once()
        # update_run called as fallback with config
        client.update_run.assert_called()


class TestOfflineSyncCorruptLine:
    """Test 6: Last-line JSONL corruption is skipped gracefully."""

    def test_corrupt_last_line_skipped(self, tmp_path: Path):
        run_dir = _create_offline_run(tmp_path)

        # Write metrics with a corrupt last line
        lines = [
            json.dumps({"key": "loss", "value": 0.5, "step": 0}) + "\n",
            json.dumps({"key": "loss", "value": 0.3, "step": 1}) + "\n",
            '{"key": "loss", "value": CORRUPT\n',  # corrupt
        ]
        (run_dir / "metrics.jsonl").write_text("".join(lines), encoding="utf-8")

        client = MagicMock()
        client.create_run.return_value = {"id": "abc12345"}
        client.sync_metrics.return_value = 2
        client.update_run.return_value = {"id": "abc12345"}

        syncer = OfflineSync(run_dir, client)
        result = syncer.sync()

        assert result is True
        # Should have synced the 2 valid metrics
        synced_metrics = []
        for c in client.sync_metrics.call_args_list:
            synced_metrics.extend(c[0][1])
        assert len(synced_metrics) == 2
