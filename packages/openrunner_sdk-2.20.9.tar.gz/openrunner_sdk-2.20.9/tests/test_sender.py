"""Tests for the OpenRunner background sender thread."""

from __future__ import annotations

import logging
import time
from unittest.mock import MagicMock, patch

import pytest

from openrunner.buffer import WriteBuffer
from openrunner.sender import Sender


def _make_sender(
    buffer: WriteBuffer | None = None,
    client: MagicMock | None = None,
    run_id: str = "test1234",
    flush_interval: float = 0.3,
    flush_threshold: int = 5,
    heartbeat_interval: float = 0.5,
    system_metrics_enabled: bool = False,
) -> tuple[Sender, WriteBuffer, MagicMock]:
    """Create a Sender with short intervals for test speed."""
    buf = buffer or WriteBuffer()
    cli = client or MagicMock()
    sender = Sender(
        buffer=buf,
        client=cli,
        run_id=run_id,
        flush_interval=flush_interval,
        flush_threshold=flush_threshold,
        heartbeat_interval=heartbeat_interval,
        system_metrics_enabled=system_metrics_enabled,
    )
    return sender, buf, cli


# ---------------------------------------------------------------------------
# Flush on threshold
# ---------------------------------------------------------------------------

class TestFlushThreshold:
    def test_flushes_when_threshold_reached(self):
        sender, buf, cli = _make_sender(flush_threshold=3)

        # Put 3 items (at threshold)
        for i in range(3):
            buf.put({"key": "loss", "value": float(i), "step": i})

        sender.start()
        time.sleep(1.5)  # Give sender time to process
        sender.stop(timeout=5.0)

        # post_metrics should have been called at least once
        assert cli.post_metrics.call_count >= 1
        # All 3 metrics should have been sent
        total_sent = sum(
            len(call.args[1]) for call in cli.post_metrics.call_args_list
        )
        assert total_sent == 3


# ---------------------------------------------------------------------------
# Flush on interval
# ---------------------------------------------------------------------------

class TestFlushInterval:
    def test_flushes_on_interval(self):
        sender, buf, cli = _make_sender(flush_interval=0.3, flush_threshold=1000)

        # Add fewer items than threshold
        buf.put({"key": "loss", "value": 0.5, "step": 0})

        sender.start()
        time.sleep(1.5)  # Wait for at least one flush interval
        sender.stop(timeout=5.0)

        assert cli.post_metrics.call_count >= 1


# ---------------------------------------------------------------------------
# Heartbeat
# ---------------------------------------------------------------------------

class TestHeartbeat:
    def test_sends_heartbeat_on_interval(self):
        sender, buf, cli = _make_sender(heartbeat_interval=0.3)

        sender.start()
        time.sleep(1.5)  # Wait for at least one heartbeat
        sender.stop(timeout=5.0)

        assert cli.post_heartbeat.call_count >= 1
        cli.post_heartbeat.assert_called_with("test1234")


# ---------------------------------------------------------------------------
# Stop drains buffer
# ---------------------------------------------------------------------------

class TestStopDrains:
    def test_stop_drains_remaining_buffer(self):
        sender, buf, cli = _make_sender(
            flush_interval=999.0,  # Very long -- won't trigger interval flush
            flush_threshold=9999,  # Very high -- won't trigger threshold flush
        )

        sender.start()
        # Add items AFTER start but before stop
        for i in range(5):
            buf.put({"key": "x", "value": float(i), "step": i})

        time.sleep(0.2)  # Brief pause
        sender.stop(timeout=5.0)

        # Final drain should have sent them
        assert cli.post_metrics.call_count >= 1
        total_sent = sum(
            len(call.args[1]) for call in cli.post_metrics.call_args_list
        )
        assert total_sent == 5


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------

class TestErrorHandling:
    def test_flush_failure_is_caught_and_logged(self, caplog):
        sender, buf, cli = _make_sender(flush_interval=0.2)
        cli.post_metrics.side_effect = Exception("Network error")

        buf.put({"key": "loss", "value": 0.5, "step": 0})

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            sender.start()
            time.sleep(1.0)
            sender.stop(timeout=5.0)

        # Should NOT have raised -- sender thread should still be alive
        # Warning should have been logged
        assert "flush" in caplog.text.lower() or "metric" in caplog.text.lower() or "failed" in caplog.text.lower()

    def test_heartbeat_failure_is_caught_and_logged(self, caplog):
        sender, buf, cli = _make_sender(heartbeat_interval=0.2)
        cli.post_heartbeat.side_effect = Exception("Heartbeat error")

        with caplog.at_level(logging.WARNING, logger="openrunner"):
            sender.start()
            time.sleep(1.0)
            sender.stop(timeout=5.0)

        # Should NOT have raised
        assert "heartbeat" in caplog.text.lower() or "failed" in caplog.text.lower()


# ---------------------------------------------------------------------------
# Thread is daemon
# ---------------------------------------------------------------------------

class TestDaemonThread:
    def test_sender_thread_is_daemon(self):
        sender, buf, cli = _make_sender()
        assert sender._thread.daemon is True
