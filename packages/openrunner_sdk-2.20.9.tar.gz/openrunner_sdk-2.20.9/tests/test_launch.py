"""Tests for SDK launch functionality -- job creation and management."""

from __future__ import annotations

from unittest.mock import MagicMock, patch

import pytest

from openrunner.launch import LaunchJob, launch, from_run


# ---------------------------------------------------------------------------
# LaunchJob tests
# ---------------------------------------------------------------------------


class TestLaunchJob:
    """Tests for the LaunchJob class."""

    def test_launchjob_basic_attributes(self):
        """LaunchJob exposes id, state, name, image, command."""
        mock_client = MagicMock()
        data = {
            "id": "job-123",
            "state": "queued",
            "name": "test-job",
            "image": "python:3.12",
            "command": "python train.py",
        }
        job = LaunchJob(data, mock_client)

        assert job.id == "job-123"
        assert job.state == "queued"
        assert job.name == "test-job"
        assert job.image == "python:3.12"
        assert job.command == "python train.py"

    def test_launchjob_refresh(self):
        """LaunchJob.refresh() updates state from server."""
        mock_client = MagicMock()
        mock_client.get_job.return_value = {
            "id": "job-123",
            "state": "running",
            "name": "test-job",
        }
        data = {
            "id": "job-123",
            "state": "queued",
            "name": "test-job",
        }
        job = LaunchJob(data, mock_client)
        assert job.state == "queued"

        job.refresh()

        assert job.state == "running"
        mock_client.get_job.assert_called_once_with("job-123")

    def test_launchjob_refresh_failure_keeps_state(self):
        """LaunchJob.refresh() keeps current state on failure."""
        mock_client = MagicMock()
        mock_client.get_job.return_value = None
        data = {
            "id": "job-123",
            "state": "queued",
            "name": "test-job",
        }
        job = LaunchJob(data, mock_client)
        job.refresh()

        assert job.state == "queued"

    def test_launchjob_cancel(self):
        """LaunchJob.cancel() sends cancel request."""
        mock_client = MagicMock()
        mock_client.cancel_job.return_value = {"state": "canceled"}
        data = {
            "id": "job-123",
            "state": "queued",
            "name": "test-job",
        }
        job = LaunchJob(data, mock_client)
        result = job.cancel()

        assert result is True
        assert job.state == "canceled"
        mock_client.cancel_job.assert_called_once_with("job-123")

    def test_launchjob_cancel_failure(self):
        """LaunchJob.cancel() returns False on failure."""
        mock_client = MagicMock()
        mock_client.cancel_job.return_value = None
        data = {
            "id": "job-123",
            "state": "queued",
            "name": "test-job",
        }
        job = LaunchJob(data, mock_client)
        result = job.cancel()

        assert result is False
        assert job.state == "queued"

    def test_launchjob_wait_already_finished(self):
        """LaunchJob.wait() returns immediately if already in terminal state."""
        mock_client = MagicMock()
        data = {
            "id": "job-123",
            "state": "finished",
            "name": "test-job",
        }
        job = LaunchJob(data, mock_client)
        result = job.wait(poll_interval=0.01)

        assert result == "finished"
        mock_client.get_job.assert_not_called()

    def test_launchjob_repr(self):
        """LaunchJob repr shows id, state, name."""
        mock_client = MagicMock()
        data = {
            "id": "job-123",
            "state": "queued",
            "name": "test-job",
        }
        job = LaunchJob(data, mock_client)
        r = repr(job)

        assert "job-123" in r
        assert "queued" in r
        assert "test-job" in r


# ---------------------------------------------------------------------------
# launch() tests
# ---------------------------------------------------------------------------


class TestLaunch:
    """Tests for the launch() function."""

    def test_launch_no_api_key(self, clean_env):
        """launch() returns None without API key."""
        result = launch(
            project="test",
            image="python:3.12",
            command="python train.py",
        )
        assert result is None

    @patch("openrunner.launch.APIClient")
    def test_launch_creates_job(self, MockClient, clean_env):
        """launch() creates a job and returns LaunchJob."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        mock_client.list_projects.return_value = [
            {"id": "proj-123", "name": "my-project"}
        ]
        mock_client.create_job.return_value = {
            "id": "job-abc-123",
            "state": "queued",
            "name": "pytorch",
            "image": "pytorch/pytorch:latest",
            "command": "python train.py",
        }

        result = launch(
            project="my-project",
            image="pytorch/pytorch:latest",
            command="python train.py",
            env={"LR": "0.001"},
            resources={"gpu_count": 2},
        )

        assert result is not None
        assert isinstance(result, LaunchJob)
        assert result.id == "job-abc-123"
        assert result.state == "queued"

        # Verify create_job was called with correct data
        call_args = mock_client.create_job.call_args
        assert call_args[0][0] == "proj-123"
        body = call_args[0][1]
        assert body["image"] == "pytorch/pytorch:latest"
        assert body["command"] == "python train.py"
        assert body["env_vars"] == {"LR": "0.001"}
        assert body["resource_config"] == {"gpu_count": 2}

    @patch("openrunner.launch.APIClient")
    def test_launch_project_not_found(self, MockClient, clean_env):
        """launch() returns None when project not found."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client
        mock_client.list_projects.return_value = []

        result = launch(
            project="nonexistent",
            image="python:3.12",
            command="echo hello",
        )

        assert result is None

    @patch("openrunner.launch.APIClient")
    def test_launch_with_uuid_project(self, MockClient, clean_env):
        """launch() uses UUID directly without resolving."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client
        mock_client.create_job.return_value = {
            "id": "job-xyz",
            "state": "queued",
            "name": "test",
            "image": "alpine",
            "command": "echo hello",
        }

        project_uuid = "12345678-1234-1234-1234-123456789012"
        result = launch(
            project=project_uuid,
            image="alpine",
            command="echo hello",
        )

        assert result is not None
        # Should NOT call list_projects for UUID
        mock_client.list_projects.assert_not_called()

    @patch("openrunner.launch.APIClient")
    def test_launch_auto_generates_name(self, MockClient, clean_env):
        """launch() generates job name from image if not provided."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client
        mock_client.create_job.return_value = {
            "id": "job-xyz",
            "state": "queued",
            "name": "pytorch",
        }

        project_uuid = "12345678-1234-1234-1234-123456789012"
        launch(
            project=project_uuid,
            image="nvidia/pytorch:2.0",
            command="python train.py",
        )

        call_args = mock_client.create_job.call_args
        body = call_args[0][1]
        assert body["name"] == "pytorch"  # extracted from image


# ---------------------------------------------------------------------------
# from_run() tests
# ---------------------------------------------------------------------------


class TestFromRun:
    """Tests for the from_run() function."""

    def test_from_run_no_api_key(self, clean_env):
        """from_run() returns None without API key."""
        result = from_run(
            run_id="run-123",
            image="python:3.12",
            command="python train.py",
        )
        assert result is None

    @patch("openrunner.launch.APIClient")
    def test_from_run_creates_linked_job(self, MockClient, clean_env):
        """from_run() creates a job linked to the run with config as env."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client

        mock_client.get_run.return_value = {
            "id": "run-abc",
            "project_id": "proj-123",
            "config": {"lr": 0.001, "epochs": 10},
        }
        mock_client.create_job.return_value = {
            "id": "job-xyz",
            "state": "queued",
            "name": "rerun-run-abc",
            "image": "pytorch/pytorch:latest",
            "command": "python train.py",
        }

        result = from_run(
            run_id="run-abc",
            image="pytorch/pytorch:latest",
            command="python train.py",
            env={"EXTRA": "value"},
        )

        assert result is not None
        assert result.id == "job-xyz"

        # Verify create_job was called with merged env vars
        call_args = mock_client.create_job.call_args
        assert call_args[0][0] == "proj-123"
        body = call_args[0][1]
        assert body["run_id"] == "run-abc"
        assert body["env_vars"]["lr"] == "0.001"
        assert body["env_vars"]["epochs"] == "10"
        assert body["env_vars"]["EXTRA"] == "value"

    @patch("openrunner.launch.APIClient")
    def test_from_run_run_not_found(self, MockClient, clean_env):
        """from_run() returns None when run not found."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client
        mock_client.get_run.return_value = None

        result = from_run(
            run_id="nonexistent",
            image="python:3.12",
            command="echo hello",
        )

        assert result is None

    @patch("openrunner.launch.APIClient")
    def test_from_run_auto_generates_name(self, MockClient, clean_env):
        """from_run() generates name as rerun-{run_id}."""
        clean_env.setenv("OPENRUNNER_API_KEY", "or_testkey")
        clean_env.setenv("OPENRUNNER_BASE_URL", "http://localhost:8000")

        mock_client = MagicMock()
        MockClient.return_value = mock_client
        mock_client.get_run.return_value = {
            "id": "run-abc",
            "project_id": "proj-123",
            "config": {},
        }
        mock_client.create_job.return_value = {
            "id": "job-xyz",
            "state": "queued",
            "name": "rerun-run-abc",
        }

        from_run(
            run_id="run-abc",
            image="python:3.12",
            command="echo hello",
        )

        call_args = mock_client.create_job.call_args
        body = call_args[0][1]
        assert body["name"] == "rerun-run-abc"
