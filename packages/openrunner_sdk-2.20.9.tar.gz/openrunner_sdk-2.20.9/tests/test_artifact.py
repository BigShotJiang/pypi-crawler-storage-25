"""Tests for openrunner.artifact -- Artifact class with SHA-256 hashing."""

from __future__ import annotations

import hashlib

import pytest

from openrunner.artifact import Artifact, _sha256_file


class TestSHA256:
    """Tests for the _sha256_file utility."""

    def test_sha256_known_vector(self, tmp_path) -> None:
        """SHA-256 matches known test vector for 'hello world'."""
        path = tmp_path / "hello.txt"
        path.write_bytes(b"hello world")
        expected = hashlib.sha256(b"hello world").hexdigest()
        assert _sha256_file(path) == expected

    def test_sha256_empty_file(self, tmp_path) -> None:
        """SHA-256 of empty file matches known empty digest."""
        path = tmp_path / "empty.bin"
        path.write_bytes(b"")
        expected = hashlib.sha256(b"").hexdigest()
        assert _sha256_file(path) == expected


class TestArtifact:
    """Tests for the Artifact class."""

    def test_artifact_add_file(self, tmp_path) -> None:
        """add_file records correct hash, size, and name."""
        path = tmp_path / "data.csv"
        content = b"col1,col2\n1,2\n3,4\n"
        path.write_bytes(content)

        artifact = Artifact("my-data", type="dataset")
        artifact.add_file(str(path))

        assert len(artifact._files) == 1
        entry = artifact._files[0]
        assert entry["name"] == "data.csv"
        assert entry["size"] == len(content)
        assert entry["content_hash"] == hashlib.sha256(content).hexdigest()
        assert entry["local_path"] == str(path.resolve())

    def test_artifact_add_file_custom_name(self, tmp_path) -> None:
        """add_file with custom name uses that name."""
        path = tmp_path / "data.csv"
        path.write_bytes(b"data")

        artifact = Artifact("test", type="dataset")
        artifact.add_file(str(path), name="custom/name.csv")
        assert artifact._files[0]["name"] == "custom/name.csv"

    def test_artifact_add_dir(self, tmp_path) -> None:
        """add_dir includes all files with relative paths prefixed by dir name."""
        # Create directory structure
        sub = tmp_path / "mydir"
        sub.mkdir()
        (sub / "a.txt").write_bytes(b"aaa")
        nested = sub / "nested"
        nested.mkdir()
        (nested / "b.txt").write_bytes(b"bbb")

        artifact = Artifact("dir-artifact", type="dataset")
        artifact.add_dir(str(sub))

        names = [f["name"] for f in artifact._files]
        assert "mydir/a.txt" in names
        assert "mydir/nested/b.txt" in names
        assert len(artifact._files) == 2

    def test_artifact_add_dir_custom_prefix(self, tmp_path) -> None:
        """add_dir with custom name uses that as prefix."""
        sub = tmp_path / "data"
        sub.mkdir()
        (sub / "file.txt").write_bytes(b"content")

        artifact = Artifact("test", type="dataset")
        artifact.add_dir(str(sub), name="custom_prefix")
        assert artifact._files[0]["name"] == "custom_prefix/file.txt"

    def test_artifact_missing_file(self) -> None:
        """add_file with nonexistent path raises FileNotFoundError."""
        artifact = Artifact("test", type="dataset")
        with pytest.raises(FileNotFoundError, match="Artifact file not found"):
            artifact.add_file("/nonexistent/path/file.txt")

    def test_artifact_not_a_directory(self, tmp_path) -> None:
        """add_dir with a file path raises NotADirectoryError."""
        path = tmp_path / "file.txt"
        path.write_bytes(b"data")

        artifact = Artifact("test", type="dataset")
        with pytest.raises(NotADirectoryError, match="Not a directory"):
            artifact.add_dir(str(path))

    def test_artifact_metadata(self) -> None:
        """Metadata is stored correctly."""
        artifact = Artifact(
            "test", type="model",
            description="A test artifact",
            metadata={"version": "1.0", "accuracy": 0.95},
        )
        assert artifact.name == "test"
        assert artifact.type == "model"
        assert artifact.description == "A test artifact"
        assert artifact.metadata == {"version": "1.0", "accuracy": 0.95}
