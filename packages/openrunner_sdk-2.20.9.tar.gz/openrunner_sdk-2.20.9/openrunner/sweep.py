"""Sweep support for hyperparameter optimization.

Public API:
    openrunner.sweep(config, project=...) -> sweep_id
    openrunner.agent(sweep_id, function)  -> None (runs loop)

The sweep config follows a W&B-compatible format:

    sweep_config = {
        "method": "bayes",
        "name": "my-sweep",
        "metric": {"name": "val_loss", "goal": "minimize"},
        "parameters": {
            "lr": {"min": 0.0001, "max": 0.1, "distribution": "log_uniform_values"},
            "batch_size": {"values": [16, 32, 64]},
            "epochs": {"value": 10},
        },
        "early_terminate": {"type": "hyperband", "min_iter": 3, "eta": 3},
    }
"""

from __future__ import annotations

import logging
from typing import Any, Callable

import httpx

from openrunner.settings import SDKSettings

logger = logging.getLogger("openrunner")


def sweep(
    config: dict[str, Any],
    project: str | None = None,
) -> str | None:
    """Create a sweep on the server.

    Args:
        config: Sweep configuration dict (W&B-compatible format).
        project: Project name. If None, uses OPENRUNNER_PROJECT env var.

    Returns:
        The sweep ID string, or None on failure.
    """
    try:
        settings = SDKSettings()
        api_key = settings.api_key
        base_url = settings.base_url
        resolved_project = project or settings.project

        if not api_key:
            logger.warning("openrunner.sweep(): no API key set")
            return None

        if not resolved_project:
            logger.warning("openrunner.sweep(): no project specified")
            return None

        # Resolve project name to ID
        client = httpx.Client(
            base_url=f"{base_url.rstrip('/')}/api/v1",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

        try:
            # Find the project ID
            resp = client.get("/projects")
            resp.raise_for_status()
            projects = resp.json()
            if isinstance(projects, dict):
                projects = projects.get("projects", projects.get("items", []))

            project_id = None
            for p in projects:
                pname = p.get("name", p.get("slug", ""))
                if pname == resolved_project:
                    project_id = p.get("id")
                    break

            if project_id is None:
                logger.warning(
                    "openrunner.sweep(): project '%s' not found",
                    resolved_project,
                )
                return None

            # Build sweep payload
            payload: dict[str, Any] = {
                "name": config.get("name", f"{resolved_project}-sweep"),
                "method": config.get("method", "random"),
                "parameters": config.get("parameters", {}),
            }

            if "metric" in config:
                payload["metric"] = config["metric"]

            if "early_terminate" in config:
                payload["early_terminate"] = config["early_terminate"]

            if "run_cap" in config:
                payload["run_cap"] = config["run_cap"]

            # Create sweep
            resp = client.post(
                f"/projects/{project_id}/sweeps",
                json=payload,
            )
            resp.raise_for_status()
            sweep_data = resp.json()
            sweep_id = sweep_data.get("id")
            logger.info("Created sweep %s", sweep_id)
            return sweep_id

        finally:
            client.close()

    except Exception as e:
        logger.warning("openrunner.sweep() failed: %s", e)
        return None


def agent(
    sweep_id: str,
    function: Callable[[dict[str, Any]], Any] | None = None,
    count: int | None = None,
) -> None:
    """Run a sweep agent that repeatedly gets params and calls function.

    The agent loop:
    1. POST /sweeps/{sweep_id}/suggest to get next params
    2. Call function(params) -- function should call openrunner.init/log/finish
    3. If function returns a numeric value, POST /sweeps/{sweep_id}/report
    4. Repeat until sweep is finished, count is reached, or early_stop

    Args:
        sweep_id: The sweep ID returned by openrunner.sweep().
        function: Training function that accepts a dict of hyperparameters.
            Should return a metric value (float) or None.
        count: Maximum number of runs. None for unlimited.
    """
    if function is None:
        logger.warning("openrunner.agent(): no function provided")
        return

    try:
        settings = SDKSettings()
        api_key = settings.api_key
        base_url = settings.base_url

        if not api_key:
            logger.warning("openrunner.agent(): no API key set")
            return

        client = httpx.Client(
            base_url=f"{base_url.rstrip('/')}/api/v1",
            headers={"Authorization": f"Bearer {api_key}"},
            timeout=30.0,
        )

        runs_completed = 0

        try:
            while True:
                # Check count limit
                if count is not None and runs_completed >= count:
                    logger.info("Sweep agent: reached count limit %d", count)
                    break

                # Get next params
                resp = client.post(f"/sweeps/{sweep_id}/suggest")
                resp.raise_for_status()
                suggestion = resp.json()

                if suggestion.get("finished", False):
                    logger.info("Sweep %s finished (all combinations tried)", sweep_id)
                    break

                params = suggestion.get("params", {})
                logger.info("Sweep agent: running with params %s", params)

                # Call the training function
                try:
                    result = function(params)
                except Exception as e:
                    logger.warning("Sweep agent: function raised error: %s", e)
                    result = None

                # Report result if numeric
                if result is not None and isinstance(result, (int, float)):
                    try:
                        report_resp = client.post(
                            f"/sweeps/{sweep_id}/report",
                            json={
                                "run_id": f"sweep-{sweep_id[:8]}-{runs_completed}",
                                "metric_value": float(result),
                                "params": params,
                            },
                        )
                        report_resp.raise_for_status()
                        report_data = report_resp.json()

                        if report_data.get("early_stop", False):
                            logger.info(
                                "Sweep agent: early stop triggered"
                            )
                            break

                        if report_data.get("is_best", False):
                            logger.info(
                                "Sweep agent: new best! metric=%.6f",
                                result,
                            )
                    except Exception as e:
                        logger.warning("Sweep agent: report failed: %s", e)

                runs_completed += 1

        finally:
            client.close()

        logger.info(
            "Sweep agent completed: %d runs", runs_completed
        )

    except Exception as e:
        logger.warning("openrunner.agent() failed: %s", e)
