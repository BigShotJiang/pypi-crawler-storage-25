"""Git repo info capture via subprocess.

Captures SHA, branch, remote URL, and dirty status at ``init()`` time.
Returns ``None`` when not inside a git repository or when the ``git``
binary is not available.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any


def capture_git_info(cwd: str | Path | None = None) -> dict[str, Any] | None:
    """Capture git repo metadata.

    Returns a dict with keys ``sha``, ``branch``, ``remote_url``, ``dirty``,
    or ``None`` if *cwd* is not inside a git repo (or git is not installed).

    All subprocess calls use ``timeout=5`` and the function never raises.
    """
    try:
        subprocess.run(
            ["git", "rev-parse", "--git-dir"],
            cwd=cwd,
            capture_output=True,
            check=True,
            timeout=5,
        )
    except (subprocess.CalledProcessError, FileNotFoundError, subprocess.TimeoutExpired):
        return None

    def _git(*args: str) -> str:
        result = subprocess.run(
            ["git", *args],
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=5,
        )
        return result.stdout.strip()

    try:
        sha = _git("rev-parse", "HEAD")
        branch = _git("rev-parse", "--abbrev-ref", "HEAD")
        # Use status --porcelain to detect both tracked changes and untracked files
        porcelain = _git("status", "--porcelain")
        dirty = bool(porcelain)

        # remote URL may not exist (no remote configured)
        remote_url: str | None = None
        try:
            url = _git("remote", "get-url", "origin")
            if url:
                remote_url = url
        except Exception:
            pass

        # Dirty files list (paths of modified/untracked files)
        dirty_files: list[str] = []
        if porcelain:
            for line in porcelain.splitlines():
                # Porcelain format: "XY filename" -- skip the 2-char status + space
                if len(line) > 3:
                    dirty_files.append(line[3:].strip())

        # Git diff (truncated to avoid huge payloads)
        diff: str | None = None
        try:
            raw_diff = _git("diff", "--stat")
            if raw_diff:
                # Also get a compact patch diff, truncated
                patch = _git("diff", "--no-color")
                if len(patch) > 10000:
                    patch = patch[:10000] + "\n... (truncated)"
                diff = patch
        except Exception:
            pass

        return {
            "sha": sha,
            "branch": branch,
            "remote_url": remote_url,
            "dirty": dirty,
            "dirty_files": dirty_files,
            "diff": diff,
        }
    except Exception:
        return None
