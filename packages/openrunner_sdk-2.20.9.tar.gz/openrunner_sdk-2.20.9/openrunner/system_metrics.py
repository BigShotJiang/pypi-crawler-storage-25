"""System metrics collector for CPU, memory, and GPU.

Collects hardware metrics with the ``system.`` prefix so the dashboard
can separate them from training metrics. All operations are non-blocking
and gracefully handle missing psutil or pynvml.
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("openrunner")

try:
    import psutil

    HAS_PSUTIL = True
except ImportError:
    HAS_PSUTIL = False

try:
    from pynvml import (
        nvmlDeviceGetCount,
        nvmlDeviceGetHandleByIndex,
        nvmlDeviceGetMemoryInfo,
        nvmlDeviceGetName,
        nvmlDeviceGetPowerUsage,
        nvmlDeviceGetTemperature,
        nvmlDeviceGetUtilizationRates,
        nvmlInit,
        nvmlShutdown,
        NVML_TEMPERATURE_GPU,
    )

    HAS_NVML = True
except ImportError:
    HAS_NVML = False


class SystemMetrics:
    """Collects CPU, memory, and GPU metrics.

    Gracefully handles missing psutil or pynvml by returning
    empty dicts. All operations are non-blocking.
    """

    def __init__(self) -> None:
        self._gpu_initialized = False
        self._gpu_count = 0
        self._gpu_names: list[str] = []
        if HAS_NVML:
            try:
                nvmlInit()
                self._gpu_count = nvmlDeviceGetCount()
                for i in range(self._gpu_count):
                    try:
                        handle = nvmlDeviceGetHandleByIndex(i)
                        name = nvmlDeviceGetName(handle)
                        if isinstance(name, bytes):
                            name = name.decode("utf-8")
                        self._gpu_names.append(name)
                    except Exception:
                        self._gpu_names.append(f"GPU {i}")
                self._gpu_initialized = True
                logger.info(
                    "GPU metrics enabled: %d GPU(s) - %s",
                    self._gpu_count,
                    ", ".join(self._gpu_names),
                )
            except Exception:
                logger.debug("NVML init failed, GPU metrics disabled")

    @property
    def gpu_info(self) -> dict[str, Any]:
        """Return GPU info dict for run config."""
        if not self._gpu_initialized:
            return {}
        return {
            "gpu_count": self._gpu_count,
            "gpu_names": self._gpu_names,
        }

    def sample(self) -> dict[str, float]:
        """Collect a snapshot of system metrics.

        Returns dict with system.* prefixed keys.
        Uses interval=None for cpu_percent (non-blocking).
        """
        metrics: dict[str, float] = {}

        if HAS_PSUTIL:
            metrics["system.cpu"] = psutil.cpu_percent(interval=None)
            metrics["system.cpu_count"] = float(psutil.cpu_count() or 1)
            mem = psutil.virtual_memory()
            metrics["system.memory_percent"] = mem.percent
            metrics["system.memory_usedMB"] = mem.used / (1024 * 1024)
            metrics["system.memory_totalMB"] = mem.total / (1024 * 1024)
            try:
                proc = psutil.Process()
                metrics["system.proc.memory.rssMB"] = (
                    proc.memory_info().rss / (1024 * 1024)
                )
                metrics["system.proc.cpu_percent"] = proc.cpu_percent(interval=None)
            except Exception:
                pass
            try:
                disk = psutil.disk_usage("/")
                metrics["system.disk_percent"] = disk.percent
                metrics["system.disk_usedGB"] = disk.used / (1024 ** 3)
            except Exception:
                pass
            try:
                net = psutil.net_io_counters()
                if net:
                    metrics["system.network.sentMB"] = net.bytes_sent / (1024 * 1024)
                    metrics["system.network.recvMB"] = net.bytes_recv / (1024 * 1024)
            except Exception:
                pass

        if self._gpu_initialized:
            for i in range(self._gpu_count):
                try:
                    handle = nvmlDeviceGetHandleByIndex(i)
                    util = nvmlDeviceGetUtilizationRates(handle)
                    mem_info = nvmlDeviceGetMemoryInfo(handle)
                    metrics[f"system.gpu.{i}.gpu"] = float(util.gpu)
                    metrics[f"system.gpu.{i}.memory"] = float(util.memory)
                    metrics[f"system.gpu.{i}.memoryAllocatedMB"] = float(
                        mem_info.used
                    ) / (1024 * 1024)
                    metrics[f"system.gpu.{i}.memoryTotalMB"] = float(
                        mem_info.total
                    ) / (1024 * 1024)
                except Exception:
                    pass
                try:
                    temp = nvmlDeviceGetTemperature(handle, NVML_TEMPERATURE_GPU)
                    metrics[f"system.gpu.{i}.temp"] = float(temp)
                except Exception:
                    pass
                try:
                    power = nvmlDeviceGetPowerUsage(handle)  # milliwatts
                    metrics[f"system.gpu.{i}.powerW"] = float(power) / 1000.0
                except Exception:
                    pass

        return metrics

    def shutdown(self) -> None:
        """Clean up NVML resources."""
        if self._gpu_initialized:
            try:
                nvmlShutdown()
            except Exception:
                pass
            self._gpu_initialized = False
