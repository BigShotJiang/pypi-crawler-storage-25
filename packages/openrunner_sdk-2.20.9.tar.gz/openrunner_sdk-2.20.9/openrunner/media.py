"""Media types for rich experiment logging.

Image wraps numpy arrays, PIL Images, or file paths for lazy PNG serialization.
Table wraps columnar data for structured logging.
Audio wraps numpy arrays, file paths, or bytes for WAV serialization.
Video wraps file paths or numpy arrays for video media.
Histogram computes bin edges/counts from numeric arrays.
Plotly wraps plotly.graph_objects.Figure for JSON serialization.
Embedding wraps (N, D) vectors for t-SNE/PCA/UMAP projection visualization.
BoundingBoxes2D overlays bounding box annotations on images.

Serialization is deferred to the sender thread to keep log() non-blocking.
"""

from __future__ import annotations

import io
import json
import struct
import wave
from pathlib import Path
from typing import Any


class Classes:
    """Label set for consistent class naming across masks and boxes.

    Provides a reusable mapping from integer class IDs to human-readable
    names, so that multiple images can share the same label set without
    repeating it in every call.

    Usage::

        classes = Classes([{"id": 0, "name": "bg"}, {"id": 1, "name": "car"}])
        img = openrunner.Image(arr, classes=classes,
                               masks={"pred": {"mask_data": mask}})
    """

    def __init__(self, class_set: list[dict]) -> None:
        """
        Args:
            class_set: List of ``{"id": int, "name": str}`` dicts.
        """
        self._classes: dict[int, str] = {c["id"]: c["name"] for c in class_set}

    def to_dict(self) -> dict[int, str]:
        """Return a copy of the id-to-name mapping."""
        return dict(self._classes)


class Image:
    """An image for experiment logging.

    Accepts a numpy array, PIL Image, or file path (str/Path).
    Serialization to PNG bytes is lazy -- only called by the sender thread,
    not in the ``log()`` call, keeping the main thread non-blocking.

    Args:
        data: Image data (numpy array, PIL Image, matplotlib figure, or file path).
        caption: Optional caption string.
        mode: Optional color mode override (e.g., ``"L"``, ``"RGB"``).
        masks: Optional dict of segmentation mask overlays::

            {"predictions": {
                "mask_data": np.array,  # 2D int array (H, W) with class IDs as values
                "class_labels": {0: "background", 1: "car", 2: "person"}
            }}

        boxes: Optional dict of bounding box overlays::

            {"predictions": {
                "box_data": [
                    {"position": {"minX": .., "maxX": .., "minY": .., "maxY": ..},
                     "class_id": 1, "scores": {"confidence": 0.95}}
                ],
                "class_labels": {1: "car", 2: "person"}
            }}

    Masks and boxes are serialized as JSONB metadata alongside the image
    binary data, stored in the server's ``data`` column.
    """

    def __init__(
        self,
        data: Any,
        caption: str | None = None,
        mode: str | None = None,
        masks: dict[str, Any] | None = None,
        boxes: dict[str, Any] | None = None,
        classes: "Classes | None" = None,
        grouping: int | None = None,
        file_type: str = "png",
        normalize: bool = True,
    ) -> None:
        self._data = data
        self.caption = caption
        self._mode = mode
        self._grouping = grouping
        self._file_type = file_type
        self._normalize = normalize
        self._masks: dict[str, Any] | None = None
        self._boxes: dict[str, Any] | None = None

        # Resolve shared class labels from a Classes object
        shared_labels: dict[int, str] = classes.to_dict() if classes is not None else {}

        # Process mask overlays
        if masks:
            self._masks = {}
            for name, mask_def in masks.items():
                mask_data = mask_def.get("mask_data")
                if hasattr(mask_data, "tolist"):
                    mask_data = mask_data.tolist()  # numpy -> list
                # Merge: per-mask class_labels override shared labels
                merged_labels = {**shared_labels, **mask_def.get("class_labels", {})}
                self._masks[name] = {
                    "mask_data": mask_data,
                    "class_labels": merged_labels,
                }

        # Process bounding box overlays
        if boxes:
            self._boxes = {}
            for name, box_def in boxes.items():
                # Merge: per-box class_labels override shared labels
                merged_labels = {**shared_labels, **box_def.get("class_labels", {})}
                self._boxes[name] = {
                    "box_data": box_def.get("box_data", []),
                    "class_labels": merged_labels,
                }

    def _get_overlay_data(self) -> dict[str, Any] | None:
        """Return mask/box overlay metadata for JSONB storage, or None."""
        overlay: dict[str, Any] = {}
        if self._masks:
            overlay["masks"] = self._masks
        if self._boxes:
            overlay["boxes"] = self._boxes
        if self._grouping is not None:
            overlay["grouping"] = self._grouping
        return overlay if overlay else None

    def _output_format(self) -> tuple[str, str]:
        """Return (PIL format string, MIME content type) based on file_type."""
        ft = self._file_type.lower()
        if ft in ("jpg", "jpeg"):
            return "JPEG", "image/jpeg"
        elif ft == "webp":
            return "WEBP", "image/webp"
        else:
            return "PNG", "image/png"

    def _serialize(self) -> tuple[bytes, str]:
        """Convert to image bytes. Returns (bytes, content_type).

        - File path (str/Path): read raw bytes, infer content type
        - PIL Image: save to BytesIO in configured file_type format
        - numpy array: convert via PIL.Image.fromarray() then save

        The output format is controlled by ``file_type`` (png/jpg/webp).
        Float-to-uint8 normalization can be disabled via ``normalize=False``.
        """
        # File path -- always pass through as-is
        if isinstance(self._data, (str, Path)):
            path = Path(self._data)
            raw = path.read_bytes()
            suffix = path.suffix.lower()
            ct_map = {
                ".png": "image/png",
                ".jpg": "image/jpeg",
                ".jpeg": "image/jpeg",
                ".gif": "image/gif",
                ".bmp": "image/bmp",
                ".webp": "image/webp",
            }
            content_type = ct_map.get(suffix, "image/png")
            return raw, content_type

        fmt, ct = self._output_format()

        # PIL Image
        try:
            from PIL import Image as PILImage

            if isinstance(self._data, PILImage.Image):
                pil_img = self._data
                # JPEG does not support alpha; convert RGBA -> RGB
                if fmt == "JPEG" and pil_img.mode in ("RGBA", "LA", "PA"):
                    pil_img = pil_img.convert("RGB")
                buf = io.BytesIO()
                save_kw: dict[str, Any] = {"format": fmt}
                if fmt == "JPEG":
                    save_kw["quality"] = 95
                pil_img.save(buf, **save_kw)
                return buf.getvalue(), ct
        except ImportError:
            pass

        # numpy array
        try:
            import numpy as np

            if isinstance(self._data, np.ndarray):
                from PIL import Image as PILImage

                arr = self._data
                # Handle float arrays: normalize 0-1 to 0-255 uint8 (unless disabled)
                if arr.dtype.kind == "f":
                    if self._normalize:
                        arr = (arr.clip(0.0, 1.0) * 255).astype(np.uint8)
                    else:
                        arr = arr.astype(np.uint8)
                elif arr.dtype != np.uint8:
                    arr = arr.astype(np.uint8)

                # Handle grayscale (2D) vs RGB (3D)
                if arr.ndim == 2:
                    pil_img = PILImage.fromarray(arr, mode="L")
                elif arr.ndim == 3 and arr.shape[2] == 1:
                    pil_img = PILImage.fromarray(arr[:, :, 0], mode="L")
                elif arr.ndim == 3 and arr.shape[2] == 3:
                    pil_img = PILImage.fromarray(arr, mode="RGB")
                elif arr.ndim == 3 and arr.shape[2] == 4:
                    pil_img = PILImage.fromarray(arr, mode="RGBA")
                else:
                    pil_img = PILImage.fromarray(arr)

                # JPEG does not support alpha; convert RGBA -> RGB
                if fmt == "JPEG" and pil_img.mode in ("RGBA", "LA", "PA"):
                    pil_img = pil_img.convert("RGB")
                buf = io.BytesIO()
                save_kw_np: dict[str, Any] = {"format": fmt}
                if fmt == "JPEG":
                    save_kw_np["quality"] = 95
                pil_img.save(buf, **save_kw_np)
                return buf.getvalue(), ct
        except ImportError:
            pass

        raise TypeError(
            f"Image: unsupported data type {type(self._data).__name__}. "
            "Expected numpy array, PIL Image, or file path."
        )


class Table:
    """A table for structured data logging.

    Stores columnar data that is serialized inline as JSON (no S3 upload needed).
    """

    def __init__(
        self,
        columns: list[str] | None = None,
        data: list[list[Any]] | None = None,
        dataframe: Any | None = None,
    ) -> None:
        if dataframe is not None:
            self.columns: list[str] = list(dataframe.columns)
            self._data: list[list[Any]] = dataframe.values.tolist()
        else:
            self.columns = columns or []
            self._data = data or []

    def add_data(self, *row: Any) -> None:
        """Add a row of data to the table."""
        self._data.append(list(row))

    def add_column(self, name: str, data: list) -> None:
        """Append a column to the table.

        Args:
            name: Column name
            data: Column values (must match number of rows)
        """
        if len(data) != len(self._data):
            raise ValueError(
                f"Column data length {len(data)} != row count {len(self._data)}"
            )
        self.columns.append(name)
        for i, val in enumerate(data):
            self._data[i].append(val)

    def get_column(self, name: str, convert_to: str | None = None) -> Any:
        """Retrieve a column's values.

        Args:
            name: Column name
            convert_to: Optional ``"numpy"`` to return a numpy array
        Returns:
            list or numpy array of column values
        """
        idx = self.columns.index(name)
        values = [row[idx] for row in self._data]
        if convert_to == "numpy":
            import numpy as np

            return np.array(values)
        return values

    def iterrows(self):
        """Iterate over rows as dicts."""
        for row in self._data:
            yield dict(zip(self.columns, row))

    @classmethod
    def from_dataframe(cls, df: Any) -> "Table":
        """Create a Table from a pandas DataFrame."""
        columns = list(df.columns)
        data = df.values.tolist()
        return cls(columns=columns, data=data)

    def set_reference_column(self, column: str = "sample_id") -> None:
        """Mark a column as the dataset reference/sample ID.

        This tells the UI to treat this column as a link back to the
        original dataset, enabling sample traceability.

        Args:
            column: Name of the column containing sample IDs/references.
                    Must already exist in the table.
        """
        if column not in self.columns:
            raise ValueError(f"Column '{column}' not in table. Columns: {self.columns}")
        self._reference_column = column

    @classmethod
    def from_predictions(
        cls,
        *,
        sample_ids: list[str],
        references: list[str],
        hypotheses: list[str],
        audio_paths: list[str] | None = None,
        metadata: dict[str, list] | None = None,
        extra_columns: dict[str, list] | None = None,
    ) -> "Table":
        """Create a predictions table with sample traceability.

        Convenience constructor for evaluation results. Ensures consistent
        column naming (sample_id, ref, hyp, audio) that the UI recognizes
        for diff highlighting and audio playback.

        Args:
            sample_ids: Unique IDs linking each row to the source dataset
            references: Ground truth transcriptions
            hypotheses: Model predictions
            audio_paths: Optional audio file paths for inline playback
            metadata: Optional per-sample metadata dict (e.g. {"speaker": [...], "duration": [...], "language": [...]})
            extra_columns: Alias for metadata (deprecated, use metadata)

        Example:
            table = Table.from_predictions(
                sample_ids=["file_001", "file_002"],
                references=["hello world", "press one"],
                hypotheses=["hello word", "press 1"],
                audio_paths=["audio/001.wav", "audio/002.wav"],
                metadata={
                    "duration_s": [3.2, 1.8],
                    "speaker": ["agent", "ivr"],
                    "language": ["en", "es"],
                    "source_file": ["call_123.wav", "call_456.wav"],
                },
            )
            openrunner.log({"predictions": table})
        """
        columns = ["sample_id"]
        n = len(sample_ids)
        data: list[list[Any]] = [[sid] for sid in sample_ids]

        if audio_paths:
            columns.append("audio")
            for i, p in enumerate(audio_paths):
                data[i].append(p)

        columns.append("hyp")
        for i, h in enumerate(hypotheses):
            data[i].append(h)

        columns.append("ref")
        for i, r in enumerate(references):
            data[i].append(r)

        # Merge metadata and extra_columns
        all_extra = {}
        if metadata:
            all_extra.update(metadata)
        if extra_columns:
            all_extra.update(extra_columns)

        for col_name, col_data in all_extra.items():
            columns.append(col_name)
            for i, v in enumerate(col_data[:n]):
                data[i].append(v)

        t = cls(columns=columns, data=data)
        t._reference_column = "sample_id"
        return t

    def _serialize(self) -> dict[str, Any]:
        """Serialize to a dict for JSON transmission."""
        result: dict[str, Any] = {"columns": self.columns, "data": self._data}
        if hasattr(self, "_reference_column"):
            result["reference_column"] = self._reference_column
        return result


class Audio:
    """An audio clip for experiment logging.

    Accepts a numpy array (mono or stereo), file path (str/Path), or raw bytes.
    Serialization to WAV bytes is lazy -- only called by the sender thread.
    """

    def __init__(
        self,
        data: Any,
        caption: str | None = None,
        sample_rate: int = 44100,
    ) -> None:
        self._data = data
        self.caption = caption
        self.sample_rate = sample_rate

    def _serialize(self) -> tuple[bytes, str]:
        """Convert to WAV bytes. Returns (bytes, content_type).

        - File path (str/Path): read raw bytes, return as-is
        - bytes: return as-is (assumed WAV)
        - numpy array: encode as WAV (int16) via stdlib wave module
        """
        # File path
        if isinstance(self._data, (str, Path)):
            path = Path(self._data)
            raw = path.read_bytes()
            suffix = path.suffix.lower()
            ct_map = {
                ".wav": "audio/wav",
                ".mp3": "audio/mpeg",
                ".ogg": "audio/ogg",
                ".flac": "audio/flac",
            }
            content_type = ct_map.get(suffix, "audio/wav")
            return raw, content_type

        # Raw bytes
        if isinstance(self._data, (bytes, bytearray)):
            return bytes(self._data), "audio/wav"

        # numpy array
        try:
            import numpy as np

            if isinstance(self._data, np.ndarray):
                arr = self._data
                # Normalize float arrays to int16
                if arr.dtype.kind == "f":
                    arr = (arr.clip(-1.0, 1.0) * 32767).astype(np.int16)
                elif arr.dtype != np.int16:
                    arr = arr.astype(np.int16)

                # Determine channels: 1D = mono, 2D = (samples, channels)
                if arr.ndim == 1:
                    n_channels = 1
                    samples = arr
                elif arr.ndim == 2:
                    n_channels = arr.shape[1]
                    samples = arr.flatten()
                else:
                    raise ValueError(
                        f"Audio: expected 1D or 2D array, got {arr.ndim}D"
                    )

                buf = io.BytesIO()
                with wave.open(buf, "wb") as wf:
                    wf.setnchannels(n_channels)
                    wf.setsampwidth(2)  # 16-bit
                    wf.setframerate(self.sample_rate)
                    wf.writeframes(samples.tobytes())
                return buf.getvalue(), "audio/wav"
        except ImportError:
            pass

        raise TypeError(
            f"Audio: unsupported data type {type(self._data).__name__}. "
            "Expected numpy array, file path, or bytes."
        )

    @classmethod
    def durations(cls, audio_list: list["Audio"]) -> list[float]:
        """Get durations (in seconds) of a list of Audio objects.

        Duration is computed from numpy array length and sample rate.
        For file-backed or bytes-backed Audio, duration is estimated
        from raw byte length (assumes 16-bit mono WAV).
        Audio objects that cannot be measured are skipped.
        """
        results: list[float] = []
        for a in audio_list:
            try:
                import numpy as np

                if isinstance(a._data, np.ndarray):
                    n_samples = a._data.shape[0]
                    results.append(n_samples / a.sample_rate)
                    continue
            except (ImportError, AttributeError):
                pass
            # Fallback: if the audio has a byte length, approximate
            if isinstance(a._data, (bytes, bytearray)):
                # Approximate: assume 16-bit mono WAV (2 bytes per sample)
                results.append(len(a._data) / (2 * a.sample_rate))
        return results

    @classmethod
    def sample_rates(cls, audio_list: list["Audio"]) -> list[int]:
        """Get sample rates of a list of Audio objects."""
        return [a.sample_rate for a in audio_list if hasattr(a, "sample_rate")]


class Video:
    """A video for experiment logging.

    Accepts a file path (str/Path) for MP4/WebM files, or a numpy array
    with shape (T, H, W, C) which is stored as raw frames.
    """

    _FORMAT_MAP = {
        "mp4": ("video/mp4", ".mp4", "libx264"),
        "webm": ("video/webm", ".webm", "libvpx-vp9"),
        "gif": ("image/gif", ".gif", None),
    }

    def __init__(
        self,
        data: Any,
        caption: str | None = None,
        fps: int = 30,
        format: str | None = None,
    ) -> None:
        self._data = data
        self.caption = caption
        self.fps = fps
        self._format = format  # "mp4", "gif", "webm", or None (auto)

    def _resolve_format(self) -> tuple[str, str, str | None]:
        """Return (content_type, extension, codec) for the target format."""
        fmt = (self._format or "mp4").lower()
        if fmt in self._FORMAT_MAP:
            return self._FORMAT_MAP[fmt]
        return "video/mp4", ".mp4", "libx264"

    def _serialize(self) -> tuple[bytes, str]:
        """Convert to video bytes. Returns (bytes, content_type).

        - File path (str/Path): read raw bytes, infer content type
        - numpy array (T,H,W,C): encode frames via imageio if available,
          otherwise store as raw frame data with metadata

        The output format is controlled by the ``format`` parameter
        (``"mp4"``, ``"gif"``, ``"webm"``).
        """
        # File path
        if isinstance(self._data, (str, Path)):
            path = Path(self._data)
            raw = path.read_bytes()
            suffix = path.suffix.lower()
            ct_map = {
                ".mp4": "video/mp4",
                ".webm": "video/webm",
                ".avi": "video/x-msvideo",
                ".mov": "video/quicktime",
                ".gif": "image/gif",
            }
            content_type = ct_map.get(suffix, "video/mp4")
            return raw, content_type

        target_ct, target_ext, target_codec = self._resolve_format()

        # numpy array (T, H, W, C)
        try:
            import numpy as np

            if isinstance(self._data, np.ndarray):
                arr = self._data
                if arr.ndim != 4:
                    raise ValueError(
                        f"Video: expected 4D array (T,H,W,C), got {arr.ndim}D"
                    )

                if arr.dtype.kind == "f":
                    arr = (arr.clip(0.0, 1.0) * 255).astype(np.uint8)
                elif arr.dtype != np.uint8:
                    arr = arr.astype(np.uint8)

                # Try imageio for encoding
                try:
                    import imageio.v3 as iio

                    buf = io.BytesIO()
                    write_kwargs: dict[str, Any] = {
                        "extension": target_ext,
                        "fps": self.fps,
                    }
                    if target_ext == ".gif":
                        write_kwargs["loop"] = 0
                    else:
                        write_kwargs["plugin"] = "pyav"
                        if target_codec:
                            write_kwargs["codec"] = target_codec
                    iio.imwrite(buf, arr, **write_kwargs)
                    return buf.getvalue(), target_ct
                except (ImportError, Exception):
                    pass

                # Fallback: store as raw frame bundle (JSON metadata + raw bytes)
                # This allows the server to at least store the data
                meta = json.dumps({
                    "frames": arr.shape[0],
                    "height": arr.shape[1],
                    "width": arr.shape[2],
                    "channels": arr.shape[3],
                    "fps": self.fps,
                    "format": "raw_uint8",
                    "target_format": self._format or "mp4",
                }).encode()
                meta_len = struct.pack("<I", len(meta))
                return meta_len + meta + arr.tobytes(), "application/octet-stream"
        except ImportError:
            pass

        raise TypeError(
            f"Video: unsupported data type {type(self._data).__name__}. "
            "Expected file path or numpy array (T,H,W,C)."
        )


class Histogram:
    """A histogram for numeric distribution logging.

    Accepts a list or numpy array of values. Computes bin edges and counts.
    Stores as JSON (no S3 upload needed).
    """

    def __init__(
        self,
        values: Any = None,
        num_bins: int = 64,
        caption: str | None = None,
        np_histogram: tuple[Any, Any] | None = None,
    ) -> None:
        self._values = values
        self.num_bins = num_bins
        self.caption = caption
        self._np_histogram = np_histogram

    def _serialize(self) -> dict[str, Any]:
        """Compute histogram bins and counts. Returns dict for JSON.

        When ``np_histogram`` is provided, uses pre-computed (counts, bin_edges)
        directly instead of computing from raw values.
        """
        # Pre-computed histogram from np.histogram()
        if self._np_histogram is not None:
            counts_raw, bin_edges_raw = self._np_histogram
            counts_list = list(counts_raw) if hasattr(counts_raw, "tolist") else list(counts_raw)
            bins_list = list(bin_edges_raw) if hasattr(bin_edges_raw, "tolist") else list(bin_edges_raw)
            result: dict[str, Any] = {
                "bins": bins_list,
                "counts": counts_list,
                "num_bins": len(counts_list),
            }
            # Compute stats from bin edges/counts
            if counts_list:
                total = sum(counts_list)
                if total > 0:
                    bin_centers = [(bins_list[i] + bins_list[i + 1]) / 2 for i in range(len(counts_list))]
                    mean_val = sum(c * bc for c, bc in zip(counts_list, bin_centers)) / total
                    var_val = sum(c * (bc - mean_val) ** 2 for c, bc in zip(counts_list, bin_centers)) / total
                    result["min"] = float(bins_list[0])
                    result["max"] = float(bins_list[-1])
                    result["mean"] = float(mean_val)
                    result["std"] = float(var_val ** 0.5)
                    result["count"] = int(total)
            return result

        if self._values is None:
            return {"bins": [], "counts": [], "num_bins": self.num_bins}

        try:
            import numpy as np

            arr = np.asarray(self._values, dtype=np.float64)
            arr = arr.ravel()
            # Remove NaN/Inf
            arr = arr[np.isfinite(arr)]

            if len(arr) == 0:
                return {
                    "bins": [],
                    "counts": [],
                    "num_bins": self.num_bins,
                }

            counts, bin_edges = np.histogram(arr, bins=self.num_bins)
            return {
                "bins": bin_edges.tolist(),
                "counts": counts.tolist(),
                "num_bins": self.num_bins,
                "min": float(arr.min()),
                "max": float(arr.max()),
                "mean": float(arr.mean()),
                "std": float(arr.std()),
                "count": int(len(arr)),
            }
        except ImportError:
            # Fallback without numpy: simple binning
            values = [float(v) for v in self._values if v is not None]
            values = [v for v in values if v == v and abs(v) != float("inf")]
            if not values:
                return {"bins": [], "counts": [], "num_bins": self.num_bins}

            mn, mx = min(values), max(values)
            if mn == mx:
                return {
                    "bins": [mn, mx + 1],
                    "counts": [len(values)],
                    "num_bins": self.num_bins,
                    "min": mn,
                    "max": mx,
                    "mean": mn,
                    "std": 0.0,
                    "count": len(values),
                }

            width = (mx - mn) / self.num_bins
            bins = [mn + i * width for i in range(self.num_bins + 1)]
            counts = [0] * self.num_bins
            for v in values:
                idx = min(int((v - mn) / width), self.num_bins - 1)
                counts[idx] += 1

            mean = sum(values) / len(values)
            std = (sum((v - mean) ** 2 for v in values) / len(values)) ** 0.5
            return {
                "bins": bins,
                "counts": counts,
                "num_bins": self.num_bins,
                "min": mn,
                "max": mx,
                "mean": mean,
                "std": std,
                "count": len(values),
            }


class Plotly:
    """A Plotly figure for interactive chart logging.

    Accepts a plotly.graph_objects.Figure. Serializes to JSON via fig.to_json().
    Stores as JSON (no S3 upload needed).
    """

    def __init__(
        self,
        figure: Any,
        caption: str | None = None,
    ) -> None:
        self._figure = figure
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize Plotly figure to dict. Returns dict for JSON."""
        # Try to use figure's built-in JSON serialization
        if hasattr(self._figure, "to_json"):
            json_str = self._figure.to_json()
            return json.loads(json_str)
        elif hasattr(self._figure, "to_dict"):
            return self._figure.to_dict()
        elif isinstance(self._figure, dict):
            return self._figure
        else:
            raise TypeError(
                f"Plotly: unsupported figure type {type(self._figure).__name__}. "
                "Expected plotly.graph_objects.Figure or dict."
            )


class MatplotlibFigure:
    """Capture a Matplotlib figure as a PNG image for experiment logging.

    Accepts an optional ``matplotlib.figure.Figure``.  When *fig* is ``None``
    the current active figure (``pyplot.gcf()``) is used, making the
    common pattern ``openrunner.log({"chart": openrunner.MatplotlibFigure()})``
    a one-liner.

    Serialization is lazy -- the PNG bytes are produced only when the sender
    thread calls ``_serialize()``.
    """

    def __init__(
        self,
        fig: Any | None = None,
        caption: str | None = None,
        dpi: int = 150,
    ) -> None:
        self._fig = fig
        self.caption = caption
        self.dpi = dpi

    def _serialize(self) -> tuple[bytes, str]:
        """Render figure to PNG bytes. Returns (bytes, content_type)."""
        import matplotlib.pyplot as plt  # lazy import

        fig = self._fig if self._fig is not None else plt.gcf()
        buf = io.BytesIO()
        fig.savefig(buf, format="png", dpi=self.dpi, bbox_inches="tight")
        buf.seek(0)
        return buf.getvalue(), "image/png"


class PlotlyChart:
    """Enhanced Plotly figure that stores both interactive JSON and static PNG.

    Stores the full Plotly JSON for interactive rendering in the frontend,
    and optionally generates a static PNG fallback via ``fig.to_image()``
    (requires the ``kaleido`` package).

    Use ``Plotly`` for JSON-only storage, ``PlotlyChart`` when you also
    want a static image fallback.
    """

    def __init__(
        self,
        figure: Any,
        caption: str | None = None,
    ) -> None:
        self._figure = figure
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize Plotly figure to dict with optional static PNG.

        Returns a dict with keys:
        - ``data``, ``layout`` (standard Plotly JSON)
        - ``static_image`` (base64-encoded PNG string, or None if kaleido
          is not available)
        """
        import base64

        # Get the JSON representation
        if hasattr(self._figure, "to_json"):
            json_str = self._figure.to_json()
            result = json.loads(json_str)
        elif hasattr(self._figure, "to_dict"):
            result = self._figure.to_dict()
        elif isinstance(self._figure, dict):
            result = dict(self._figure)
        else:
            raise TypeError(
                f"PlotlyChart: unsupported figure type {type(self._figure).__name__}. "
                "Expected plotly.graph_objects.Figure or dict."
            )

        # Try to generate a static PNG fallback
        static_image: str | None = None
        if hasattr(self._figure, "to_image"):
            try:
                png_bytes = self._figure.to_image(format="png", width=800, height=500)
                static_image = base64.b64encode(png_bytes).decode("ascii")
            except Exception:
                pass  # kaleido not installed or failed -- skip

        result["_static_image"] = static_image
        return result


class PointCloud3D:
    """A 3D point cloud for experiment logging.

    Accepts XYZ coordinates as a numpy array of shape (N, 3), with optional
    per-point RGB colors and string labels.  Data is serialized inline as
    JSON (no S3 upload needed).

    Usage::

        pts = np.random.randn(1000, 3)
        colors = np.random.randint(0, 255, (1000, 3))
        openrunner.log({"cloud": openrunner.PointCloud3D(pts, colors=colors)})
    """

    def __init__(
        self,
        points: Any,
        colors: Any | None = None,
        labels: list[str] | None = None,
        caption: str | None = None,
        vectors: Any | None = None,
        normals: Any | None = None,
    ) -> None:
        self._points = points
        self._colors = colors
        self._labels = labels
        self.caption = caption
        self._vectors = vectors
        self._normals = normals

    @classmethod
    def from_file(cls, path: str, **kwargs) -> "PointCloud3D":
        """Load a 3D model from file (OBJ, PLY, STL, glTF).

        The file is uploaded as a binary artifact and rendered
        using three.js loaders in the frontend.

        Args:
            path: Path to a 3D model file.
            **kwargs: Passed through (e.g., ``caption``).

        Returns:
            A PointCloud3D instance backed by file data.

        Raises:
            ValueError: If the file extension is not supported.
            FileNotFoundError: If the file does not exist.
        """
        import os

        ext = os.path.splitext(path)[1].lower()
        if ext not in (".obj", ".ply", ".stl", ".gltf", ".glb"):
            raise ValueError(f"Unsupported 3D file format: {ext}")

        with open(path, "rb") as f:
            data = f.read()

        instance = cls.__new__(cls)
        instance._points = None
        instance._colors = None
        instance._labels = None
        instance.caption = kwargs.get("caption")
        instance._file_data = data
        instance._file_ext = ext
        return instance

    def _serialize(self) -> dict[str, Any]:
        """Serialize point cloud data to dict for JSON transmission.

        Returns a dict with:
        - ``points``: list of [x, y, z] lists
        - ``colors``: list of [r, g, b] lists (or None)
        - ``labels``: list of strings (or None)
        - ``num_points``: total point count
        - ``bounds``: {min: [x,y,z], max: [x,y,z]}

        When constructed via ``from_file()``, returns a dict with:
        - ``file_data``: base64-encoded file bytes
        - ``file_ext``: file extension (e.g., ``.ply``)
        """
        # File-backed point cloud
        if hasattr(self, "_file_data"):
            import base64

            result: dict[str, Any] = {
                "file_data": base64.b64encode(self._file_data).decode("ascii"),
                "file_ext": self._file_ext,
                "num_points": 0,
            }
            if self.caption is not None:
                result["caption"] = self.caption
            return result

        import numpy as np

        pts = np.asarray(self._points, dtype=np.float64)
        if pts.ndim != 2 or pts.shape[1] != 3:
            raise ValueError(
                f"PointCloud3D: expected array of shape (N, 3), "
                f"got {pts.shape}"
            )

        result: dict[str, Any] = {
            "points": pts.tolist(),
            "num_points": int(pts.shape[0]),
        }

        # Bounds for frontend camera setup
        if pts.shape[0] > 0:
            result["bounds"] = {
                "min": pts.min(axis=0).tolist(),
                "max": pts.max(axis=0).tolist(),
            }
        else:
            result["bounds"] = {"min": [0, 0, 0], "max": [0, 0, 0]}

        # Colors
        if self._colors is not None:
            clr = np.asarray(self._colors)
            if clr.shape != pts.shape:
                raise ValueError(
                    f"PointCloud3D: colors shape {clr.shape} does not match "
                    f"points shape {pts.shape}"
                )
            # Normalize float colors (0-1) to int (0-255)
            if clr.dtype.kind == "f":
                clr = (clr.clip(0.0, 1.0) * 255).astype(np.uint8)
            result["colors"] = clr.tolist()
        else:
            result["colors"] = None

        # Labels
        if self._labels is not None:
            if len(self._labels) != pts.shape[0]:
                raise ValueError(
                    f"PointCloud3D: labels length {len(self._labels)} does not "
                    f"match points count {pts.shape[0]}"
                )
            result["labels"] = list(self._labels)
        else:
            result["labels"] = None

        # Vectors (per-point direction vectors, shape (N, 3))
        if self._vectors is not None:
            vecs = np.asarray(self._vectors, dtype=np.float64)
            if vecs.shape != pts.shape:
                raise ValueError(
                    f"PointCloud3D: vectors shape {vecs.shape} does not match "
                    f"points shape {pts.shape}"
                )
            result["vectors"] = vecs.tolist()
        else:
            result["vectors"] = None

        # Normals (per-point normal vectors, shape (N, 3))
        if self._normals is not None:
            nrm = np.asarray(self._normals, dtype=np.float64)
            if nrm.shape != pts.shape:
                raise ValueError(
                    f"PointCloud3D: normals shape {nrm.shape} does not match "
                    f"points shape {pts.shape}"
                )
            result["normals"] = nrm.tolist()
        else:
            result["normals"] = None

        return result


class Html:
    """Raw HTML content for rich experiment logging.

    Accepts an HTML string which is stored inline as JSONB (no S3 upload needed).
    Useful for custom reports, formatted output, or embedded visualizations.

    When ``inject=True`` (the default), a minimal default stylesheet is
    prepended to the HTML for consistent rendering across browsers.
    Set ``inject=False`` to pass raw HTML without any modifications.
    """

    _DEFAULT_STYLE = '<style>body{font-family:sans-serif;color:#333;padding:1rem}</style>'

    def __init__(
        self,
        data: str,
        caption: str | None = None,
        inject: bool = True,
    ) -> None:
        if inject:
            data = self._DEFAULT_STYLE + data
        self._data = data
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize to a dict for JSON transmission."""
        result: dict[str, Any] = {"html": self._data}
        if self.caption is not None:
            result["caption"] = self.caption
        return result


class Embedding:
    """An embedding projection for experiment logging.

    Accepts an (N, D) array of vectors (N points in D dimensions) with optional
    per-point labels and metadata columns.  Data is serialized inline as JSON
    (no S3 upload needed), following the same pattern as Table.

    Usage::

        vecs = np.random.randn(200, 128)
        labels = ["cat"] * 100 + ["dog"] * 100
        openrunner.log({"emb": openrunner.Embedding(vecs, labels=labels)})
    """

    def __init__(
        self,
        vectors: Any,
        labels: list[str] | None = None,
        metadata: dict[str, list[Any]] | None = None,
        caption: str | None = None,
    ) -> None:
        self._vectors = vectors
        self._labels = labels
        self._metadata = metadata
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize embedding data to dict for JSON transmission.

        Returns a dict with:
        - ``vectors``: list of lists (N x D)
        - ``labels``: list of strings (or None)
        - ``metadata``: dict of lists (or None)
        - ``dim``: dimensionality D
        - ``count``: number of points N
        """
        import numpy as np

        vecs = np.asarray(self._vectors, dtype=np.float64)
        if vecs.ndim != 2:
            raise ValueError(
                f"Embedding: expected 2D array (N, D), got {vecs.ndim}D"
            )

        n, d = vecs.shape

        # Validate labels length
        if self._labels is not None:
            if len(self._labels) != n:
                raise ValueError(
                    f"Embedding: labels length {len(self._labels)} does not "
                    f"match vector count {n}"
                )

        # Validate metadata column lengths
        if self._metadata is not None:
            for col_name, col_values in self._metadata.items():
                if len(col_values) != n:
                    raise ValueError(
                        f"Embedding: metadata column '{col_name}' length "
                        f"{len(col_values)} does not match vector count {n}"
                    )

        result: dict[str, Any] = {
            "vectors": vecs.tolist(),
            "dim": int(d),
            "count": int(n),
        }

        result["labels"] = list(self._labels) if self._labels is not None else None

        if self._metadata is not None:
            result["metadata"] = {
                k: list(v) for k, v in self._metadata.items()
            }
        else:
            result["metadata"] = None

        return result


class Transcript:
    """Speech-to-text transcript with word-level timestamps.

    Stores transcription output from STT models (Whisper, wav2vec2, etc.)
    with optional word-level timing segments and linked source audio.

    Usage::

        transcript = openrunner.Transcript(
            text="Hello world",
            segments=[
                {"start": 0.0, "end": 0.5, "text": "Hello", "confidence": 0.98},
                {"start": 0.6, "end": 1.0, "text": "world", "confidence": 0.95},
            ],
            language="en",
            audio=openrunner.Audio(audio_array, sample_rate=16000),
        )
        openrunner.log({"stt_output": transcript})
    """

    def __init__(
        self,
        text: str,
        segments: list[dict[str, Any]] | None = None,
        language: str | None = None,
        audio: "Audio | None" = None,
        model: str | None = None,
        duration: float | None = None,
        confidence: float | None = None,
    ) -> None:
        self._text = text
        self._segments = segments or []
        self._language = language
        self._audio = audio
        self._model = model
        self._duration = duration
        self._confidence = confidence

    def _serialize(self) -> dict[str, Any]:
        """Serialize transcript data to dict for JSON transmission."""
        data: dict[str, Any] = {
            "text": self._text,
            "segments": self._segments,
            "language": self._language,
            "model": self._model,
            "duration": self._duration,
            "confidence": self._confidence,
        }
        return {k: v for k, v in data.items() if v is not None}


class AudioComparison:
    """Compare audio inputs/outputs side by side.

    Perfect for TTS quality comparison, voice cloning evaluation,
    or audio enhancement before/after.

    Usage::

        comp = openrunner.AudioComparison(
            reference=openrunner.Audio("reference.wav"),
            synthesized=openrunner.Audio("synthesized.wav"),
            metrics={"pesq": 3.5, "stoi": 0.92, "mos": 4.1},
            text="The quick brown fox",
        )
        openrunner.log({"tts_eval": comp})
    """

    def __init__(
        self,
        reference: "Audio | None" = None,
        synthesized: "Audio | None" = None,
        metrics: dict[str, Any] | None = None,
        text: str | None = None,
        caption: str | None = None,
    ) -> None:
        self._reference = reference
        self._synthesized = synthesized
        self._metrics = metrics or {}
        self._text = text
        self.caption = caption

    def _serialize(self) -> dict[str, Any]:
        """Serialize comparison metadata to dict for JSON transmission."""
        return {
            "metrics": self._metrics,
            "text": self._text,
            "caption": self.caption,
            "has_reference": self._reference is not None,
            "has_synthesized": self._synthesized is not None,
        }


class SpectrogramImage:
    """Log a spectrogram (mel, STFT, etc.) as a structured media type.

    Accepts a 2D numpy array and renders it as a spectrogram image using
    matplotlib.  The resulting image is stored as a PNG via the Image type.

    Usage::

        spec = openrunner.SpectrogramImage(
            mel_spectrogram,  # 2D numpy array [freq_bins x time_frames]
            sample_rate=22050,
            hop_length=256,
            caption="Mel spectrogram epoch 5",
            spec_type="mel",  # "mel", "stft", "mfcc", "cqt"
        )
        openrunner.log({"spectrogram": spec})
    """

    def __init__(
        self,
        data: Any,
        sample_rate: int = 22050,
        hop_length: int = 256,
        caption: str | None = None,
        spec_type: str = "mel",
        n_fft: int | None = None,
    ) -> None:
        self.caption = caption
        self._spec_type = spec_type
        self._sample_rate = sample_rate
        self._hop_length = hop_length

        try:
            import matplotlib
            matplotlib.use("Agg")
            import matplotlib.pyplot as plt
            import numpy as np

            fig, ax = plt.subplots(figsize=(10, 4))

            if hasattr(data, "numpy"):
                data = data.numpy()  # torch tensor
            data = np.array(data)

            im = ax.imshow(
                data, aspect="auto", origin="lower",
                cmap="magma", interpolation="nearest",
            )

            n_frames = data.shape[1] if data.ndim > 1 else data.shape[0]
            time_max = n_frames * hop_length / sample_rate
            ax.set_xlabel("Time (s)")
            ax.set_xticks(np.linspace(0, n_frames, 5))
            ax.set_xticklabels([f"{t:.1f}" for t in np.linspace(0, time_max, 5)])

            if spec_type == "mel":
                ax.set_ylabel("Mel bin")
            else:
                ax.set_ylabel("Frequency bin")

            ax.set_title(f"{spec_type.upper()} Spectrogram")
            plt.colorbar(im, ax=ax, label="dB")
            fig.tight_layout()

            self._image = Image(fig, caption=caption)
            plt.close(fig)
        except ImportError:
            raise ImportError("SpectrogramImage requires matplotlib and numpy")

    def _get_image(self) -> "Image":
        """Return the rendered Image object."""
        return self._image


class BoundingBoxes2D:
    """Bounding box annotations overlaid on an image.

    Accepts an Image and a list of bounding box dicts with format:

    **minX/maxX format (default):**

    .. code-block:: python

        {"position": {"minX": float, "minY": float, "maxX": float, "maxY": float},
         "class_id": int,  # optional
         "scores": {"confidence": float}}  # optional

    **middle/width/height format:**

    .. code-block:: python

        {"middle": [cx, cy], "width": w, "height": h,
         "class_id": int, "scores": {"confidence": float}}

    Both formats are normalized to minX/maxX internally.

    The optional ``domain`` parameter indicates how coordinates should be
    interpreted:
    - ``"pixel"`` (default): values are in pixel coordinates
    - ``"fractional"``: values are 0-1 fractions of image dimensions
    """

    def __init__(
        self,
        image: Image,
        boxes: list[dict[str, Any]],
        class_labels: dict[int, str] | None = None,
        caption: str | None = None,
        domain: str = "pixel",
    ) -> None:
        self._image = image
        self._boxes = self._normalize_boxes(boxes)
        self.class_labels = class_labels or {}
        self.caption = caption
        self.domain = domain

    @staticmethod
    def _normalize_boxes(boxes: list[dict[str, Any]]) -> list[dict[str, Any]]:
        """Convert middle/width/height format to minX/maxX format."""
        normalized: list[dict[str, Any]] = []
        for box in boxes:
            box = dict(box)  # shallow copy
            if "middle" in box:
                cx, cy = box.pop("middle")
                w = box.pop("width")
                h = box.pop("height")
                box["position"] = {
                    "minX": cx - w / 2,
                    "maxX": cx + w / 2,
                    "minY": cy - h / 2,
                    "maxY": cy + h / 2,
                }
            normalized.append(box)
        return normalized

    def _serialize_image(self) -> tuple[bytes, str]:
        """Serialize the underlying image. Returns (bytes, content_type)."""
        return self._image._serialize()

    def _serialize_boxes(self) -> dict[str, Any]:
        """Serialize bounding box data to dict for JSON."""
        return {
            "boxes": self._boxes,
            "class_labels": self.class_labels,
            "domain": self.domain,
        }


class Molecule:
    """3D molecular structure visualization.

    Supports PDB, SDF, MOL2, MMCIF, CIF file formats,
    SMILES string conversion, and RDKit molecule objects.

    Usage::

        # From file
        openrunner.log({"protein": openrunner.Molecule("structure.pdb")})

        # From SMILES
        mol = openrunner.Molecule.from_smiles("CC(=O)O")
        openrunner.log({"acetic_acid": mol})

        # From RDKit
        mol = openrunner.Molecule.from_rdkit(rdkit_mol)
        openrunner.log({"compound": mol})
    """

    SUPPORTED_FORMATS = {
        ".pdb", ".pqr", ".mmcif", ".mcif", ".cif",
        ".sdf", ".sd", ".gro", ".mol2", ".mmtf",
    }

    def __init__(
        self,
        data_or_path: str,
        caption: str | None = None,
    ) -> None:
        """
        Args:
            data_or_path: File path (str) or raw molecular data string.
            caption: Optional caption.
        """
        self.caption = caption

        if isinstance(data_or_path, str):
            import os

            if os.path.isfile(data_or_path):
                ext = os.path.splitext(data_or_path)[1].lower()
                if ext not in self.SUPPORTED_FORMATS:
                    raise ValueError(
                        f"Unsupported format: {ext}. "
                        f"Supported: {self.SUPPORTED_FORMATS}"
                    )
                with open(data_or_path, "r") as f:
                    self._data = f.read()
                self._format = ext.lstrip(".")
            else:
                # Assume raw data string (e.g., PDB content)
                self._data = data_or_path
                self._format = "pdb"  # default
        else:
            raise TypeError(
                "Expected file path string or molecular data string"
            )

    @classmethod
    def from_smiles(cls, smiles: str, caption: str | None = None) -> "Molecule":
        """Create a molecule from a SMILES string.

        Requires rdkit for 3D coordinate generation.
        """
        try:
            from rdkit import Chem
            from rdkit.Chem import AllChem

            mol = Chem.MolFromSmiles(smiles)
            if mol is None:
                raise ValueError(f"Invalid SMILES: {smiles}")
            mol = Chem.AddHs(mol)
            AllChem.EmbedMolecule(mol, randomSeed=42)
            AllChem.MMFFOptimizeMolecule(mol)
            pdb_block = Chem.MolToPDBBlock(mol)
            instance = cls.__new__(cls)
            instance._data = pdb_block
            instance._format = "pdb"
            instance.caption = caption or smiles
            return instance
        except ImportError:
            raise ImportError(
                "Molecule.from_smiles() requires rdkit. "
                "Install with: pip install rdkit"
            )

    @classmethod
    def from_rdkit(cls, mol: Any, caption: str | None = None) -> "Molecule":
        """Create from an RDKit Mol object."""
        try:
            from rdkit import Chem

            pdb_block = Chem.MolToPDBBlock(mol)
            instance = cls.__new__(cls)
            instance._data = pdb_block
            instance._format = "pdb"
            instance.caption = caption
            return instance
        except ImportError:
            raise ImportError(
                "Molecule.from_rdkit() requires rdkit. "
                "Install with: pip install rdkit"
            )

    def _serialize(self) -> dict[str, Any]:
        """Serialize molecule data for logging."""
        return {
            "mol_data": self._data,
            "format": self._format,
            "caption": self.caption,
        }


class JoinedTable:
    """Merge two Tables on a common column using an inner join.

    The result is a new Table containing all columns from both input tables
    (the join key column appears once).

    Usage::

        t1 = Table(columns=["id", "name"], data=[[1, "a"], [2, "b"]])
        t2 = Table(columns=["id", "score"], data=[[1, 0.9], [2, 0.7]])
        jt = JoinedTable(t1, t2, join_key="id")
        jt.table  # Table with columns ["id", "name", "score"]
    """

    def __init__(
        self,
        table_1: Table,
        table_2: Table,
        join_key: str,
    ) -> None:
        key_idx_1 = table_1.columns.index(join_key)
        key_idx_2 = table_2.columns.index(join_key)

        # Build lookup from table_2 keyed by the join column value
        t2_lookup: dict[Any, list[Any]] = {}
        for row in table_2._data:
            t2_lookup[row[key_idx_2]] = row

        # Merged columns: all from t1 + non-key columns from t2
        t2_cols = [c for i, c in enumerate(table_2.columns) if i != key_idx_2]
        merged_cols = list(table_1.columns) + t2_cols
        merged_data: list[list[Any]] = []

        for row1 in table_1._data:
            key = row1[key_idx_1]
            if key in t2_lookup:
                row2 = t2_lookup[key]
                extra = [v for i, v in enumerate(row2) if i != key_idx_2]
                merged_data.append(list(row1) + extra)

        self._table = Table(columns=merged_cols, data=merged_data)

    @property
    def table(self) -> Table:
        """Return the merged Table."""
        return self._table
