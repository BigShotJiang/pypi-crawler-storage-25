"""LLM-based transcript formatting and normalization.

Post-processes STT output to fix punctuation and formatting without
changing meaning or numbers. Rules:
- Fix punctuation and capitalization
- Never change the meaning or actual numbers
- Confirmation/enumeration sequences → hyphenated (1123445 → 1-1-2-3-4-4-5)
- All monetary balances must include cents ($50 → $50.00)
- Phone menu options must be digits (press one → press 1)
"""

from typing import Optional

FORMATTING_PROMPT = """You are a transcript formatting assistant. Your job is to clean up speech-to-text output by fixing punctuation and formatting ONLY.

## STRICT RULES:
1. NEVER change the meaning of any sentence
2. NEVER change any number values — only their FORMAT
3. NEVER add or remove information
4. NEVER translate or paraphrase

## FORMATTING RULES:

### Confirmation/Verification Numbers
When someone reads a number digit-by-digit for confirmation or verification, format with hyphens between each digit.
- "one one two three four four five" → "1-1-2-3-4-4-5"
- "your confirmation number is 5 5 8 9 2 1" → "your confirmation number is 5-5-8-9-2-1"
- "that's 1123445 for confirmation" → "that's 1-1-2-3-4-4-5 for confirmation"
- Account numbers, SSN last digits, verification codes — all hyphenated when read digit-by-digit

### Money/Balances
ALL monetary amounts MUST show cents, even if zero.
- "$50" → "$50.00"
- "fifty dollars" → "$50.00"
- "your balance is 1250" (in money context) → "your balance is $1,250.00"
- "three hundred and twenty two dollars and five cents" → "$322.05"
- "two thousand" (in money context) → "$2,000.00"

### Phone Menu Options
ALL phone menu prompts must use digits, not words.
- "press one" → "press 1"
- "oprima uno" → "oprima 1"
- "appuyez sur le deux" → "appuyez sur le 2"
- "press star" → "press *"
- "press pound" → "press #"

### General Punctuation
- Add periods at end of sentences
- Add commas for natural pauses and lists
- Capitalize first word of sentences and proper nouns
- Add question marks for questions
- Fix run-on sentences with proper punctuation
- "um", "uh", "like" (filler words) — keep them, they're part of the transcript

### Do NOT Change
- Speaker labels or timestamps
- The actual content/meaning
- Language (don't translate)
- Names or proper nouns (even if misspelled — that's how STT heard it)
- Technical terms

## INPUT:
{transcript}

## OUTPUT:
Return ONLY the formatted transcript. No explanations, no commentary."""


AVAILABLE_MODELS = [
    "gpt-5.4-nano",   # fastest, cheapest — default
    "gpt-5.4-mini",   # balanced
    "gpt-5.4",        # high quality
    "gpt-5.5",        # best quality
]


def format_transcript(
    transcript: str,
    *,
    model: str = "gpt-5.4-nano",
    client=None,
    temperature: float = 0.1,
) -> str:
    """Format a transcript using LLM for punctuation/formatting cleanup.

    Args:
        transcript: Raw STT output text
        model: LLM model to use. Options: gpt-5.4-nano (default), gpt-5.4-mini, gpt-5.4, gpt-5.5
        client: OpenAI client instance (auto-creates if None)
        temperature: Low temp for consistent formatting

    Returns:
        Formatted transcript string
    """
    if not transcript or not transcript.strip():
        return transcript

    if client is None:
        try:
            import openai
            client = openai.OpenAI()
        except ImportError:
            raise ImportError(
                "openai package required for transcript formatting. "
                "Install with: pip install openai"
            )

    response = client.chat.completions.create(
        model=model,
        temperature=temperature,
        messages=[
            {"role": "user", "content": FORMATTING_PROMPT.format(transcript=transcript)},
        ],
    )

    return response.choices[0].message.content.strip()


def format_transcript_batch(
    transcripts: list[str],
    *,
    model: str = "gpt-5.4-nano",
    client=None,
    temperature: float = 0.1,
) -> list[str]:
    """Format multiple transcripts. Processes sequentially."""
    if client is None:
        try:
            import openai
            client = openai.OpenAI()
        except ImportError:
            raise ImportError("openai package required. pip install openai")

    return [
        format_transcript(t, model=model, client=client, temperature=temperature)
        for t in transcripts
    ]
