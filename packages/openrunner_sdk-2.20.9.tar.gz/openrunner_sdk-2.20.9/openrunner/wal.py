"""Write-ahead log for crash recovery.

Persists API requests to a local JSONL file before sending.
On startup, replays any un-acked entries.
"""

from __future__ import annotations

import json
import logging
import os
import threading
from typing import Any

logger = logging.getLogger("openrunner")


class WriteAheadLog:
    """Simple WAL that persists metric/trace data to disk before sending.

    Each entry is assigned a monotonically increasing sequence number.
    Successfully sent entries are acknowledged by writing their seq to
    a separate ``.acked`` file.  On startup, ``replay()`` returns all
    entries whose seq has not been acked.

    Args:
        run_id: The run identifier (used for file naming).
        base_dir: Directory for WAL files. Defaults to ``~/.openrunner/wal``.
    """

    def __init__(self, run_id: str, base_dir: str | None = None) -> None:
        self._dir = base_dir or os.path.join(
            os.path.expanduser("~"), ".openrunner", "wal"
        )
        os.makedirs(self._dir, exist_ok=True)
        self._path = os.path.join(self._dir, f"{run_id}.jsonl")
        self._acked_path = os.path.join(self._dir, f"{run_id}.acked")
        self._lock = threading.Lock()
        self._seq = 0

    def write(self, entry_type: str, data: Any) -> int:
        """Write an entry to the WAL. Returns sequence number."""
        with self._lock:
            self._seq += 1
            entry = {"seq": self._seq, "type": entry_type, "data": data}
            with open(self._path, "a") as f:
                f.write(json.dumps(entry, default=str) + "\n")
            return self._seq

    def ack(self, seq: int) -> None:
        """Mark a sequence number as successfully sent."""
        with self._lock:
            with open(self._acked_path, "a") as f:
                f.write(f"{seq}\n")

    def replay(self) -> list[dict]:
        """Read un-acked entries for replay.

        Returns a list of entry dicts (each with ``seq``, ``type``, ``data``)
        that were written but never acknowledged.  Corrupt lines are silently
        skipped.
        """
        if not os.path.exists(self._path):
            return []

        acked: set[int] = set()
        if os.path.exists(self._acked_path):
            with open(self._acked_path) as f:
                for line in f:
                    try:
                        acked.add(int(line.strip()))
                    except ValueError:
                        pass

        entries: list[dict] = []
        with open(self._path) as f:
            for line in f:
                try:
                    entry = json.loads(line)
                    if entry["seq"] not in acked:
                        entries.append(entry)
                except (json.JSONDecodeError, KeyError):
                    pass
        return entries

    def cleanup(self) -> None:
        """Remove WAL files after run finishes successfully."""
        for path in [self._path, self._acked_path]:
            try:
                os.remove(path)
            except OSError:
                pass
