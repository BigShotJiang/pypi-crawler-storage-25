"""HTTP client for OpenRunner server communication.

Uses httpx.Client (synchronous, thread-safe) with defensive error handling.
All methods log warnings on failure and never raise exceptions to the caller.

Includes automatic retry with exponential backoff + jitter for transient
server errors (5xx) and network exceptions.
"""

from __future__ import annotations

import logging
import random
import time
from collections.abc import Iterator
from typing import Any

import httpx

logger = logging.getLogger("openrunner")

# -- Retry configuration ------------------------------------------------------

MAX_RETRIES = 3
INITIAL_DELAY = 1.0  # seconds
MAX_DELAY = 30.0


def _retry_request(fn, *args, **kwargs):
    """Execute an HTTP request with exponential backoff retry.

    Retries on server errors (5xx status codes) and network exceptions.
    Client errors (4xx) are returned immediately without retry.

    Returns the httpx.Response on success or raises the last exception
    after all retries are exhausted.
    """
    last_error = None
    for attempt in range(MAX_RETRIES + 1):
        try:
            response = fn(*args, **kwargs)
            if response.status_code < 500:
                return response
            # Server error -- retry
            last_error = Exception(f"Server error: {response.status_code}")
        except Exception as e:
            last_error = e

        if attempt < MAX_RETRIES:
            delay = min(INITIAL_DELAY * (2 ** attempt), MAX_DELAY)
            # Add jitter (0.5x -- 1.5x)
            delay *= 0.5 + random.random()
            logger.warning(
                "Request failed (attempt %d/%d), retrying in %.1fs: %s",
                attempt + 1,
                MAX_RETRIES + 1,
                delay,
                last_error,
            )
            time.sleep(delay)

    logger.error("Request failed after %d retries: %s", MAX_RETRIES + 1, last_error)
    raise last_error


class APIClient:
    """HTTP client for the OpenRunner server API.

    All methods are defensive -- they catch exceptions, log warnings,
    and return None/0 rather than propagating errors to the caller.
    This ensures SDK failures never crash training code.
    """

    def __init__(
        self,
        base_url: str,
        api_key: str,
        transport: httpx.BaseTransport | None = None,
    ) -> None:
        kwargs: dict[str, Any] = {
            "base_url": f"{base_url.rstrip('/')}/api/v1",
            "headers": {"Authorization": f"Bearer {api_key}"},
            "timeout": 30.0,
        }
        if transport is not None:
            kwargs["transport"] = transport

        self._client = httpx.Client(**kwargs)

    def _request(self, method: str, path: str, **kwargs) -> httpx.Response:
        """Make an HTTP request with automatic retry on transient failures."""
        return _retry_request(getattr(self._client, method), path, **kwargs)

    def create_run(self, data: dict[str, Any]) -> dict[str, Any] | None:
        """POST /runs -- create a new run on the server.

        Returns the response JSON dict, or None on failure.
        """
        try:
            response = self._request("post","/runs", json=data)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_run failed: %s", e)
            return None

    def update_run(self, run_id: str, data: dict[str, Any]) -> dict[str, Any] | None:
        """PATCH /runs/{run_id} -- update run state/summary/config.

        Returns the response JSON dict, or None on failure.
        """
        try:
            response = self._request("patch",f"/runs/{run_id}", json=data)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("update_run failed: %s", e)
            return None

    def post_metrics(self, run_id: str, metrics: list[dict[str, Any]]) -> int:
        """POST /runs/{run_id}/metrics -- send a batch of metric records.

        Returns the count of metrics accepted, or 0 on failure.
        """
        try:
            response = self._request("post",
                f"/runs/{run_id}/metrics",
                json={"metrics": metrics},
            )
            response.raise_for_status()
            return response.json().get("count", 0)
        except Exception as e:
            logger.warning("post_metrics failed: %s", e)
            return 0

    def get_run(self, run_id: str) -> dict[str, Any] | None:
        """GET /runs/{run_id} -- fetch run data.

        Returns the response JSON dict, or None on failure/not-found.
        """
        try:
            response = self._request("get",f"/runs/{run_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_run failed: %s", e)
            return None

    def get_run_max_step(self, run_id: str) -> int:
        """GET /runs/{run_id}/metrics -- return max step across all metric keys.

        Fetches a small sample of metrics and finds the maximum step value.
        Returns 0 if no metrics exist or on failure.
        """
        try:
            response = self._request("get",
                f"/runs/{run_id}/metrics", params={"max_points": 10}
            )
            if response.status_code == 404:
                return 0
            response.raise_for_status()
            data = response.json()
            max_step = 0
            # data is a dict of metric_key -> list of {step, value, ...}
            if isinstance(data, dict):
                for key, series in data.items():
                    if isinstance(series, list):
                        for point in series:
                            step = point.get("step", 0)
                            if step > max_step:
                                max_step = step
            return max_step
        except Exception as e:
            logger.warning("get_run_max_step failed: %s", e)
            return 0

    def fork_run(
        self, run_id: str, step: int | None = None
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/fork -- fork a run at a specific step.

        Creates a new run and copies metrics up to the given step.
        Returns {new_run_id, step}, or None on failure.
        """
        try:
            body: dict[str, Any] = {}
            if step is not None:
                body["step"] = step
            response = self._request("post",f"/runs/{run_id}/fork", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("fork_run failed: %s", e)
            return None

    def truncate_run_history(
        self, run_id: str, step: int
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/truncate -- truncate metrics after a step.

        Deletes metric points with step > given step.
        Returns {run_id, truncated_at}, or None on failure.
        """
        try:
            response = self._request("post",
                f"/runs/{run_id}/truncate",
                json={"step": step},
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("truncate_run_history failed: %s", e)
            return None

    def sync_metrics(self, run_id: str, metrics: list[dict[str, Any]]) -> int:
        """POST /runs/{run_id}/sync-metrics -- idempotent metric sync.

        Calls the sync-metrics endpoint which uses ON CONFLICT DO NOTHING
        to handle duplicate metric points. Returns count or 0 on failure.
        """
        try:
            response = self._request("post",
                f"/runs/{run_id}/sync-metrics",
                json={"metrics": metrics},
            )
            response.raise_for_status()
            return response.json().get("count", 0)
        except Exception as e:
            logger.warning("sync_metrics failed: %s", e)
            return 0

    def post_heartbeat(self, run_id: str) -> dict[str, Any] | None:
        """POST /runs/{run_id}/heartbeat -- send a heartbeat signal.

        Returns the response dict (includes stop_requested), or None on failure.
        """
        try:
            response = self._request("post",f"/runs/{run_id}/heartbeat")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("post_heartbeat failed: %s", e)
            return None

    def post_logs(self, run_id: str, lines: list[dict[str, Any]]) -> int:
        """POST /runs/{run_id}/logs -- send a batch of console log lines.

        Returns the count of lines accepted, or 0 on failure.
        """
        try:
            response = self._request("post",
                f"/runs/{run_id}/logs",
                json={"lines": lines},
            )
            response.raise_for_status()
            return response.json().get("count", 0)
        except Exception as e:
            logger.warning("post_logs failed: %s", e)
            return 0

    # -- Listing methods -------------------------------------------------------

    def list_projects(self) -> list[dict[str, Any]]:
        """GET /projects -- list all projects the user has access to.

        Returns a list of project dicts, or empty list on failure.
        """
        try:
            response = self._request("get","/projects")
            response.raise_for_status()
            data = response.json()
            # Server may return {projects: [...]} or [...]
            if isinstance(data, list):
                return data
            return data.get("projects", data.get("items", []))
        except Exception as e:
            logger.warning("list_projects failed: %s", e)
            return []

    def list_runs(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/runs -- list runs in a project.

        Returns a list of run dicts, or empty list on failure.
        """
        try:
            response = self._request("get",f"/projects/{project_id}/runs")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("runs", data.get("items", []))
        except Exception as e:
            logger.warning("list_runs failed: %s", e)
            return []

    def iter_runs(
        self,
        project_id: str,
        per_page: int = 50,
        **filters: Any,
    ) -> Iterator[dict[str, Any]]:
        """Lazily iterate over all runs in a project with pagination.

        Yields Run dicts one at a time, fetching pages as needed.
        This avoids loading the full run list into memory for large projects.

        Args:
            project_id: Project to list runs from.
            per_page: Number of runs to fetch per page (default 50).
            **filters: Additional query parameters forwarded to the API.

        Yields:
            Individual run dicts.
        """
        offset = 0
        while True:
            try:
                params: dict[str, Any] = {
                    "offset": offset,
                    "limit": per_page,
                    **filters,
                }
                response = self._request("get",
                    f"/projects/{project_id}/runs", params=params
                )
                if not response.is_success:
                    break
                data = response.json()
                # Handle both {runs: [...], total: N} and [...] formats
                if isinstance(data, list):
                    runs = data
                    total = len(data)
                else:
                    runs = data.get("runs", data.get("items", []))
                    total = data.get("total", len(runs))
                if not runs:
                    break
                yield from runs
                offset += per_page
                if offset >= total:
                    break
            except Exception as e:
                logger.warning("iter_runs failed at offset %d: %s", offset, e)
                break

    def iter_history(
        self,
        run_id: str,
        keys: list[str] | None = None,
        page_size: int = 5000,
    ) -> Iterator[dict[str, Any]]:
        """Stream metric history without loading all into memory.

        Yields dicts of ``{_step: N, key1: value1, key2: value2, ...}`` per step,
        merging all metric keys into a single row per step number.

        Args:
            run_id: Run ID to fetch history for.
            keys: Optional list of metric keys to filter.
            page_size: Max number of data points per request.

        Yields:
            Row dicts with ``_step`` and metric key/value pairs.
        """
        try:
            params: dict[str, Any] = {
                "offset": 0,
                "limit": page_size,
                "max_points": 100000,
            }
            if keys:
                params["keys"] = keys
            response = self._request("get",
                f"/runs/{run_id}/metrics", params=params
            )
            if not response.is_success:
                return
            data = response.json()
            if not data or not isinstance(data, dict):
                return

            # data is {key: [{step, value, wall_time}, ...]}
            # Collect all unique steps
            all_steps: set[int] = set()
            for points in data.values():
                if isinstance(points, list):
                    for p in points:
                        all_steps.add(p["step"])

            # Build per-step lookup for efficient access
            step_index: dict[int, dict[str, Any]] = {
                step: {"_step": step} for step in sorted(all_steps)
            }
            for key, points in data.items():
                if isinstance(points, list):
                    for p in points:
                        step_index[p["step"]][key] = p["value"]

            # Yield rows in step order
            for step in sorted(all_steps):
                yield step_index[step]

        except Exception as e:
            logger.warning("iter_history failed for run %s: %s", run_id, e)

    # -- Artifact methods ------------------------------------------------------

    def create_artifact_version(
        self,
        run_id: str,
        name: str,
        type: str,
        files: list[dict[str, Any]],
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
        base_version_id: str | None = None,
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/artifacts -- create a new artifact version.

        When base_version_id is provided, the server reuses storage keys
        for files marked with reuse=True in the manifest, enabling
        incremental artifact updates.

        Returns {version_id, version, upload_urls}, or None on failure.
        """
        try:
            body: dict[str, Any] = {
                "name": name,
                "type": type,
                "files": files,
            }
            if description is not None:
                body["description"] = description
            if metadata is not None:
                body["metadata"] = metadata
            if base_version_id is not None:
                body["base_version_id"] = base_version_id
            response = self._request("post",f"/runs/{run_id}/artifacts", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_artifact_version failed: %s", e)
            return None

    def confirm_artifact_version(
        self, version_id: str
    ) -> dict[str, Any] | None:
        """POST /artifacts/versions/{version_id}/confirm -- confirm upload.

        Returns {status, version}, or None on failure.
        """
        try:
            response = self._request("post",
                f"/artifacts/versions/{version_id}/confirm"
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("confirm_artifact_version failed: %s", e)
            return None

    def use_artifact(
        self,
        run_id: str,
        artifact_name: str,
        version: int | None = None,
        alias: str | None = None,
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/use-artifact -- get download URLs.

        Supports alias-based lookup: provide alias instead of version, or
        use "name:alias" syntax in artifact_name.

        Returns download info dict, or None on failure.
        """
        try:
            body: dict[str, Any] = {"artifact_name": artifact_name}
            if version is not None:
                body["version"] = version
            if alias is not None:
                body["alias"] = alias
            response = self._request("post",
                f"/runs/{run_id}/use-artifact", json=body
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("use_artifact failed: %s", e)
            return None

    def download_artifact(
        self,
        run_id: str,
        artifact_name: str,
        dest_dir: str = ".",
        version: int | None = None,
        alias: str | None = None,
    ) -> str | None:
        """Download all files from an artifact version to a local directory.

        Args:
            run_id: Run ID that used/created the artifact
            artifact_name: Artifact name (or "name:alias")
            dest_dir: Local directory to save files (created if needed)
            version: Specific version number (optional)
            alias: Alias name like "latest", "best" (optional)

        Returns:
            Path to the download directory, or None on failure.

        Example:
            path = client.download_artifact(run_id, "model-checkpoint", "./models")
            # Files saved to ./models/model-checkpoint/v3/...
        """
        import os
        from pathlib import Path

        info = self.use_artifact(run_id, artifact_name, version=version, alias=alias)
        if not info:
            logger.warning("download_artifact: use_artifact returned no data")
            return None

        # Extract version info and files
        ver = info.get("version", version or 1)
        files = info.get("files", [])
        if not files:
            logger.warning("download_artifact: no files in artifact")
            return None

        # Create destination directory
        name_clean = artifact_name.split(":")[0].replace("/", "_")
        out_dir = Path(dest_dir) / name_clean / f"v{ver}"
        out_dir.mkdir(parents=True, exist_ok=True)

        downloaded = 0
        for f in files:
            url = f.get("presigned_url") or f.get("url") or f.get("download_url")
            fname = f.get("name") or f.get("path") or f"file_{downloaded}"
            if not url:
                continue

            # Try presigned URL first, fall back to proxy
            if url.startswith("/"):
                # Relative proxy URL — use authenticated client
                api_path = url.replace("/api/v1/", "/", 1) if url.startswith("/api/v1/") else url
                try:
                    resp = self._request("get", api_path)
                    if resp.status_code == 200:
                        data = resp.content
                except Exception:
                    pass
            else:
                data = self.download_file_from_presigned_url(url)
                if data is None:
                    # Try proxy with storage_key
                    key = f.get("storage_key") or f.get("key")
                    if key:
                        try:
                            resp = self._request("get", f"/storage/download?key={key}")
                            if resp.status_code == 200:
                                data = resp.content
                        except Exception:
                            pass

            if data:
                file_path = out_dir / fname
                file_path.parent.mkdir(parents=True, exist_ok=True)
                file_path.write_bytes(data)
                downloaded += 1
                logger.info("downloaded: %s (%d bytes)", fname, len(data))
            else:
                logger.warning("failed to download: %s", fname)

        if downloaded == 0:
            logger.warning("download_artifact: no files downloaded")
            return None

        logger.info("artifact downloaded: %d files → %s", downloaded, out_dir)
        return str(out_dir)

    def set_alias(
        self,
        artifact_id: str,
        alias_name: str,
        version_id: str,
    ) -> dict[str, Any] | None:
        """PUT /artifacts/{artifact_id}/aliases/{alias_name} -- set an alias.

        Returns alias response dict, or None on failure.
        """
        try:
            response = self._request("put",
                f"/artifacts/{artifact_id}/aliases/{alias_name}",
                json={"version_id": version_id},
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("set_alias failed: %s", e)
            return None

    def list_aliases(
        self,
        artifact_id: str,
    ) -> list[dict[str, Any]]:
        """GET /artifacts/{artifact_id}/aliases -- list all aliases.

        Returns list of alias dicts, or empty list on failure.
        """
        try:
            response = self._request("get",f"/artifacts/{artifact_id}/aliases")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("list_aliases failed: %s", e)
            return []

    def list_artifacts(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/artifacts -- list artifacts in a project.

        Returns a list of artifact dicts, or empty list on failure.
        """
        try:
            response = self._request("get",f"/projects/{project_id}/artifacts")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("artifacts", data.get("items", []))
        except Exception as e:
            logger.warning("list_artifacts failed: %s", e)
            return []

    def get_artifact_detail(self, artifact_id: str) -> dict[str, Any] | None:
        """GET /artifacts/{artifact_id} -- get artifact detail with versions.

        Returns the artifact detail dict, or None on failure.
        """
        try:
            response = self._request("get",f"/artifacts/{artifact_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_artifact_detail failed: %s", e)
            return None

    def get_artifact_download_urls(
        self, version_id: str
    ) -> dict[str, Any] | None:
        """GET /artifacts/versions/{version_id}/download -- get download URLs.

        Returns {version_id, version, files: [{path, presigned_url, size_bytes}]}.
        """
        try:
            response = self._request("get",
                f"/artifacts/versions/{version_id}/download"
            )
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_artifact_download_urls failed: %s", e)
            return None

    def list_artifact_files(self, version_id: str) -> list[dict[str, Any]]:
        """GET /artifacts/versions/{version_id}/files -- list files in a version.

        Returns a list of file dicts, or empty list on failure.
        """
        try:
            response = self._request("get",
                f"/artifacts/versions/{version_id}/files"
            )
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else []
        except Exception as e:
            logger.warning("list_artifact_files failed: %s", e)
            return []

    def upload_file_to_presigned_url(
        self, presigned_url: str, file_path: str, run_id: str = ""
    ) -> bool:
        """PUT raw file bytes to a presigned URL.

        Handles three cases:
        1. Relative proxy URL (/api/v1/runs/...) — use authenticated client
        2. Absolute URL — try direct PUT, fall back to proxy on ConnectError
        3. ConnectError fallback — PUT via /runs/{run_id}/files/{name}
        """
        import os

        try:
            file_size = os.path.getsize(file_path)
            # Use streaming for large files, read into memory for small ones
            if file_size > 50 * 1024 * 1024:  # 50 MB
                data = open(file_path, "rb")  # noqa: SIM115
            else:
                with open(file_path, "rb") as f:
                    data = f.read()

            # Scale timeout by file size (minimum 60s, ~30s per 100MB)
            upload_timeout = max(60.0, file_size / (3 * 1024 * 1024))

            # Case 1: relative proxy URL from server
            if presigned_url.startswith("/"):
                api_path = presigned_url.replace("/api/v1/", "/", 1) if presigned_url.startswith("/api/v1/") else presigned_url
                resp = self._client.put(api_path, content=data, timeout=upload_timeout)
                return resp.status_code == 200

            # Case 2: absolute presigned URL (direct to S3)
            try:
                resp = httpx.put(presigned_url, content=data, timeout=upload_timeout)
                resp.raise_for_status()
                return True
            except (httpx.ConnectError, httpx.ConnectTimeout):
                # Case 3: fallback to API proxy
                if run_id:
                    fname = os.path.basename(file_path)
                    proxy_resp = self._client.put(
                        f"/runs/{run_id}/files/{fname}", content=data, timeout=upload_timeout
                    )
                    return proxy_resp.status_code == 200
                return False
        except Exception as e:
            logger.warning("upload_file_to_presigned_url failed: %s", e)
            return False

    def download_file_from_presigned_url(
        self, presigned_url: str
    ) -> bytes | None:
        """GET file bytes from a presigned URL.

        Uses httpx directly (not self._client) because presigned URLs
        are absolute and should not have a base_url prefix.
        """
        try:
            resp = httpx.get(presigned_url, timeout=300.0)
            resp.raise_for_status()
            return resp.content
        except Exception as e:
            logger.warning("download_file_from_presigned_url failed: %s", e)
            return None

    # -- Media methods -------------------------------------------------------

    def create_media_file(
        self,
        run_id: str,
        key: str,
        media_type: str,
        step: int | None = None,
        caption: str | None = None,
        content_type: str | None = None,
        width: int | None = None,
        height: int | None = None,
        data: dict[str, Any] | None = None,
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/media -- create a media file record.

        Returns {id, storage_key, presigned_url}, or None on failure.
        """
        try:
            body: dict[str, Any] = {
                "key": key,
                "media_type": media_type,
            }
            if step is not None:
                body["step"] = step
            if caption is not None:
                body["caption"] = caption
            if content_type is not None:
                body["content_type"] = content_type
            if width is not None:
                body["width"] = width
            if height is not None:
                body["height"] = height
            if data is not None:
                body["data"] = data
            response = self._request("post",f"/runs/{run_id}/media", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_media_file failed: %s", e)
            return None

    def upload_media_bytes(
        self,
        presigned_url: str,
        data_bytes: bytes,
        content_type: str = "image/png",
        run_id: str = "",
        key: str = "",
    ) -> bool:
        """PUT bytes to a presigned URL with Content-Type header.

        Falls back to API proxy upload if presigned URL is unreachable
        (e.g., MinIO not exposed publicly).
        """
        try:
            try:
                resp = httpx.put(
                    presigned_url,
                    content=data_bytes,
                    headers={"Content-Type": content_type},
                    timeout=300.0,
                )
                resp.raise_for_status()
                return True
            except (httpx.ConnectError, httpx.ConnectTimeout):
                # Presigned URL unreachable — use API proxy
                if run_id and key:
                    import os
                    fname = os.path.basename(key) or key.replace("/", "_")
                    proxy_resp = self._request(
                        "PUT",
                        f"/runs/{run_id}/files/media/{fname}",
                        content=data_bytes,
                        headers={"Content-Type": content_type},
                    )
                    return proxy_resp.status_code == 200
                return False
        except Exception as e:
            logger.warning("upload_media_bytes failed: %s", e)
            return False

    # -- Alert methods -------------------------------------------------------

    def create_alert(
        self,
        run_id: str,
        title: str,
        text: str | None = None,
        level: str = "INFO",
    ) -> dict[str, Any] | None:
        """POST /runs/{run_id}/alerts -- create an alert for a run.

        Returns the alert response dict, or None on failure.
        """
        try:
            body: dict[str, Any] = {"title": title, "level": level}
            if text is not None:
                body["text"] = text
            response = self._request("post",f"/runs/{run_id}/alerts", json=body)
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_alert failed: %s", e)
            return None

    # -- Job methods ---------------------------------------------------------

    def create_job(
        self,
        project_id: str,
        data: dict[str, Any],
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/jobs -- create a new job.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/projects/{project_id}/jobs", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_job failed: %s", e)
            return None

    def get_job(self, job_id: str) -> dict[str, Any] | None:
        """GET /jobs/{job_id} -- fetch job data.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._request("get",f"/jobs/{job_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_job failed: %s", e)
            return None

    def list_jobs(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/jobs -- list jobs in a project.

        Returns a list of job dicts, or empty list on failure.
        """
        try:
            response = self._request("get",f"/projects/{project_id}/jobs")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("jobs", data.get("items", []))
        except Exception as e:
            logger.warning("list_jobs failed: %s", e)
            return []

    def cancel_job(self, job_id: str) -> dict[str, Any] | None:
        """DELETE /jobs/{job_id} -- cancel a job.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._request("delete",f"/jobs/{job_id}")
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("cancel_job failed: %s", e)
            return None

    # -- Launch Queue methods ------------------------------------------------

    def list_queues(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/queues -- list launch queues.

        Returns a list of queue dicts, or empty list on failure.
        """
        try:
            response = self._request("get",f"/projects/{project_id}/queues")
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else []
        except Exception as e:
            logger.warning("list_queues failed: %s", e)
            return []

    def create_queue(
        self, project_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/queues -- create a launch queue.

        Returns the queue response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/projects/{project_id}/queues", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_queue failed: %s", e)
            return None

    def submit_launch_job(
        self, queue_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """POST /queues/{queue_id}/jobs -- submit a job to a queue.

        Returns the job response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/queues/{queue_id}/jobs", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("submit_launch_job failed: %s", e)
            return None

    def list_launch_jobs(
        self, queue_id: str, state: str | None = None
    ) -> list[dict[str, Any]]:
        """GET /queues/{queue_id}/jobs -- list jobs in a queue.

        Returns a list of job dicts, or empty list on failure.
        """
        try:
            params: dict[str, Any] = {}
            if state:
                params["state"] = state
            response = self._request("get",
                f"/queues/{queue_id}/jobs", params=params
            )
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else []
        except Exception as e:
            logger.warning("list_launch_jobs failed: %s", e)
            return []

    # -- Chart Preset methods ------------------------------------------------

    def list_chart_presets(
        self, project_id: str
    ) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/chart-presets -- list chart presets.

        Returns a list of preset dicts, or empty list on failure.
        """
        try:
            response = self._request("get",
                f"/projects/{project_id}/chart-presets"
            )
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else []
        except Exception as e:
            logger.warning("list_chart_presets failed: %s", e)
            return []

    def create_chart_preset(
        self, project_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/chart-presets -- save a preset.

        Returns the preset response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/projects/{project_id}/chart-presets", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_chart_preset failed: %s", e)
            return None

    # -- Trace methods -------------------------------------------------------

    def post_trace(
        self,
        project_id: str,
        trace_data: dict[str, Any],
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/traces -- send a completed trace.

        Returns the trace response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/projects/{project_id}/traces", json=trace_data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("post_trace failed: %s", e)
            return None

    # -- Registry methods ----------------------------------------------------

    def list_registries(self) -> list[dict[str, Any]]:
        """GET /registry/models -- list all registered models.

        Returns a list of model dicts, or empty list on failure.
        """
        try:
            response = self._request("get","/registry/models")
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("models", data.get("items", []))
        except Exception as e:
            logger.warning("list_registries failed: %s", e)
            return []

    def get_registry_model(self, name: str) -> dict[str, Any] | None:
        """GET /registry/models/{name} -- get a registered model by name.

        Returns the model dict, or None on failure/not-found.
        """
        try:
            response = self._request("get",f"/registry/models/{name}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_registry_model failed: %s", e)
            return None

    # -- Automation methods ---------------------------------------------------

    def list_automations(self, project_id: str) -> list[dict[str, Any]]:
        """GET /projects/{project_id}/automations -- list automations.

        Returns a list of automation dicts, or empty list on failure.
        """
        try:
            response = self._request("get",
                f"/projects/{project_id}/automations"
            )
            response.raise_for_status()
            data = response.json()
            if isinstance(data, list):
                return data
            return data.get("automations", data.get("items", []))
        except Exception as e:
            logger.warning("list_automations failed: %s", e)
            return []

    def create_automation(
        self, project_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/automations -- create an automation.

        Returns the automation response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/projects/{project_id}/automations", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_automation failed: %s", e)
            return None

    def update_automation(
        self, automation_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """PATCH /automations/{automation_id} -- update an automation.

        Returns the updated automation dict, or None on failure.
        """
        try:
            response = self._request("patch",
                f"/automations/{automation_id}", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("update_automation failed: %s", e)
            return None

    def delete_automation(self, automation_id: str) -> None:
        """DELETE /automations/{automation_id} -- delete an automation.

        Silently ignores failures.
        """
        try:
            response = self._request("delete",f"/automations/{automation_id}")
            response.raise_for_status()
        except Exception as e:
            logger.warning("delete_automation failed: %s", e)

    # -- Public API / query methods -------------------------------------------

    def scan_history(
        self,
        run_id: str,
        keys: list[str] | None = None,
        page_size: int = 1000,
    ) -> list[dict[str, Any]]:
        """Stream full metric history without sampling.

        Uses the export endpoint to get all metric data points.

        Args:
            run_id: Run ID to fetch history for.
            keys: Optional list of metric keys to filter.
            page_size: Number of records per page (hint to server).

        Returns:
            List of metric point dicts with key, step, value, wall_time.
        """
        try:
            params: dict[str, Any] = {"page_size": page_size}
            if keys:
                params["keys"] = keys
            response = self._request("get",
                f"/export/runs/{run_id}/metrics.json",
                params=params,
            )
            response.raise_for_status()
            data = response.json()
            return data.get("metrics", [])
        except Exception as e:
            logger.warning("scan_history failed: %s", e)
            return []

    def list_run_files(self, run_id: str) -> list[dict[str, Any]]:
        """List files associated with a run.

        Returns a list of file dicts (media files, artifacts, etc.).
        """
        try:
            response = self._request("get",f"/runs/{run_id}/files")
            if response.status_code == 404:
                return []
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else data.get("files", [])
        except Exception as e:
            logger.warning("list_run_files failed: %s", e)
            return []

    def get_run_logged_artifacts(self, run_id: str) -> list[dict[str, Any]]:
        """List artifacts produced (logged) by a run.

        Returns a list of artifact dicts.
        """
        try:
            response = self._request("get",f"/runs/{run_id}/artifacts/logged")
            if response.status_code == 404:
                return []
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else data.get("artifacts", [])
        except Exception as e:
            logger.warning("get_run_logged_artifacts failed: %s", e)
            return []

    def get_run_used_artifacts(self, run_id: str) -> list[dict[str, Any]]:
        """List artifacts consumed (used) by a run.

        Returns a list of artifact dicts.
        """
        try:
            response = self._request("get",f"/runs/{run_id}/artifacts/used")
            if response.status_code == 404:
                return []
            response.raise_for_status()
            data = response.json()
            return data if isinstance(data, list) else data.get("artifacts", [])
        except Exception as e:
            logger.warning("get_run_used_artifacts failed: %s", e)
            return []

    # -- Sweep / Project / Run creation (public API) -------------------------

    def get_sweep(self, sweep_id: str) -> dict[str, Any] | None:
        """GET /sweeps/{sweep_id} -- fetch sweep data.

        Returns the sweep dict, or None on failure/not-found.
        """
        try:
            response = self._request("get",f"/sweeps/{sweep_id}")
            if response.status_code == 404:
                return None
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("get_sweep failed: %s", e)
            return None

    def create_run_api(
        self, project_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """POST /projects/{project_id}/runs -- create a run via the public API.

        This is the project-scoped run creation endpoint, distinct from the
        internal ``create_run()`` used by the SDK init flow.

        Returns the run response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/projects/{project_id}/runs", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_run_api failed: %s", e)
            return None

    def create_project_api(
        self, org_id: str, data: dict[str, Any]
    ) -> dict[str, Any] | None:
        """POST /organizations/{org_id}/projects -- create a project.

        Returns the project response dict, or None on failure.
        """
        try:
            response = self._request("post",
                f"/organizations/{org_id}/projects", json=data
            )
            response.raise_for_status()
            return response.json()
        except Exception as e:
            logger.warning("create_project_api failed: %s", e)
            return None

    # -- Utility methods -----------------------------------------------------

    def flush(self) -> None:
        """Clear any local caches. Currently a no-op since we don't cache."""
        pass

    def from_path(self, path: str) -> dict[str, Any] | None:
        """Parse a universal path like 'team/project/runs/run_id'.

        Returns:
            A run dict if the path contains a run ID, or a dict with
            ``entity`` and ``project`` keys, or None if the path
            cannot be parsed.
        """
        parts = path.strip("/").split("/")
        if len(parts) >= 4 and parts[2] == "runs":
            return self.get_run(parts[3])
        elif len(parts) >= 2:
            return {"entity": parts[0], "project": parts[1]}
        return None

    # -- Lifecycle -----------------------------------------------------------

    def close(self) -> None:
        """Close the underlying httpx client."""
        try:
            self._client.close()
        except Exception:
            pass
