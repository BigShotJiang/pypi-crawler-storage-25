"""Prompt management SDK client and template classes.

Provides:

1. **Server-side prompt management** -- fetch, render, and publish
   versioned prompt templates via the OpenRunner API.

2. **Client-side prompt templates**:

   * ``StringPrompt`` -- simple string template with ``format(**kwargs)``
   * ``MessagesPrompt`` -- multi-turn chat prompt (list of role/content dicts)

Both template classes inherit from ``PromptBase`` and support publishing
to the server.

Usage::

    from openrunner import Prompt, StringPrompt, MessagesPrompt

    # Server client (unchanged API)
    template = Prompt.get("my-prompt")
    rendered = Prompt.render("my-prompt", {"name": "Alice"})
    Prompt.publish("my-prompt", "Hello {{name}}")

    # Client-side string template
    sp = StringPrompt("Hello, {{name}}! Welcome to {{place}}.")
    rendered = sp.format(name="Alice", place="Wonderland")
    sp.publish("greeting", description="A greeting template")

    # Client-side messages template
    mp = MessagesPrompt([
        {"role": "system", "content": "You are a helpful assistant named {{name}}."},
        {"role": "user", "content": "{{question}}"},
    ])
    messages = mp.format(name="Claude", question="What is ML?")
    mp.publish("chat-prompt", description="Chat prompt template")
"""

from __future__ import annotations

import copy
import hashlib
import logging
import os
import re
from typing import Any

import httpx

logger = logging.getLogger("openrunner")


# ---------------------------------------------------------------------------
# HTTP client helpers (shared by Prompt server client and publish methods)
# ---------------------------------------------------------------------------


def _get_client() -> httpx.Client:
    """Create an httpx client configured for the OpenRunner server."""
    base_url = os.environ.get(
        "OPENRUNNER_BASE_URL",
        os.environ.get("WANDB_BASE_URL", "http://localhost:8000"),
    )
    api_key = os.environ.get(
        "OPENRUNNER_API_KEY",
        os.environ.get("WANDB_API_KEY", ""),
    )
    return httpx.Client(
        base_url=f"{base_url.rstrip('/')}/api/v1",
        headers={"Authorization": f"Bearer {api_key}"},
        timeout=30.0,
    )


def _resolve_project_id(client: httpx.Client, project: str | None = None) -> str | None:
    """Resolve a project name to its UUID.

    If project is already a UUID-like string, return as-is.
    Otherwise, list projects and find by name or slug.
    """
    resolved_project = project or os.environ.get(
        "OPENRUNNER_PROJECT",
        os.environ.get("WANDB_PROJECT", "uncategorized"),
    )

    # Check if it looks like a UUID already
    if len(resolved_project) == 36 and resolved_project.count("-") == 4:
        return resolved_project

    try:
        response = client.get("/projects")
        response.raise_for_status()
        projects = response.json()
        if isinstance(projects, dict):
            projects = projects.get("projects", projects.get("items", []))
        for p in projects:
            if p.get("name") == resolved_project or p.get("slug") == resolved_project:
                return p["id"]
    except Exception as e:
        logger.warning("Failed to resolve project '%s': %s", resolved_project, e)

    return None


def _find_or_create_prompt(
    client: httpx.Client,
    project_id: str,
    name: str,
    description: str | None = None,
) -> str | None:
    """Find a prompt by name in a project, or create it.

    Returns the prompt UUID, or None on failure.
    """
    try:
        response = client.get(f"/projects/{project_id}/prompts")
        response.raise_for_status()
        prompts = response.json()
        for p in prompts:
            if p.get("name") == name:
                return p["id"]

        # Create the prompt
        body: dict[str, Any] = {"name": name}
        if description is not None:
            body["description"] = description
        response = client.post(f"/projects/{project_id}/prompts", json=body)
        response.raise_for_status()
        return response.json()["id"]

    except Exception as e:
        logger.warning("Failed to find/create prompt '%s': %s", name, e)
        return None


# ---------------------------------------------------------------------------
# Template variable substitution
# ---------------------------------------------------------------------------

_VAR_PATTERN = re.compile(r"\{\{(\w+)\}\}")


def _substitute(template: str, variables: dict[str, str]) -> str:
    """Replace ``{{var}}`` placeholders in a template string.

    Unknown variables are left as-is.
    """
    def _replace(match: re.Match) -> str:
        key = match.group(1)
        return str(variables[key]) if key in variables else match.group(0)

    return _VAR_PATTERN.sub(_replace, template)


# ---------------------------------------------------------------------------
# PromptBase -- abstract base for client-side templates
# ---------------------------------------------------------------------------


class PromptBase:
    """Base class for client-side prompt templates.

    Subclasses must implement ``format(**kwargs)`` and ``_to_template()``.
    Provides version tracking via content hashing and a ``publish()``
    method to save templates to the OpenRunner server.
    """

    def __init__(self) -> None:
        self._version: int = 0
        self._version_hash: str = ""
        self._update_version()

    def _to_template(self) -> str:
        """Return a serializable string representation of the template.

        Used for hashing (version tracking) and server publishing.
        Must be implemented by subclasses.
        """
        raise NotImplementedError

    def _update_version(self) -> None:
        """Recompute the version hash from the current template content."""
        content = self._to_template()
        new_hash = hashlib.sha256(content.encode()).hexdigest()[:12]
        if new_hash != self._version_hash:
            self._version += 1
            self._version_hash = new_hash

    @property
    def version(self) -> int:
        """Current version number (increments on content change)."""
        return self._version

    @property
    def version_hash(self) -> str:
        """SHA-256 prefix of the current template content."""
        return self._version_hash

    def format(self, **kwargs: Any) -> Any:
        """Render the template with the given variables.

        Must be implemented by subclasses.
        """
        raise NotImplementedError

    def publish(
        self,
        name: str,
        description: str | None = None,
        model_config: dict[str, Any] | None = None,
        project: str | None = None,
    ) -> dict[str, Any] | None:
        """Publish this template to the OpenRunner server.

        Creates the prompt if it doesn't exist, then creates a new
        version with the current template content.

        Args:
            name: Prompt name within the project.
            description: Prompt description (used when creating).
            model_config: Optional model configuration metadata.
            project: Project name/slug/ID.

        Returns:
            Version info dict from the server, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("publish: could not resolve project")
                return None

            prompt_id = _find_or_create_prompt(
                client, project_id, name, description
            )
            if prompt_id is None:
                return None

            version_body: dict[str, Any] = {"template": self._to_template()}
            if model_config is not None:
                version_body["model_config"] = model_config

            response = client.post(
                f"/prompts/{prompt_id}/versions", json=version_body
            )
            response.raise_for_status()
            return response.json()

        except Exception as e:
            logger.warning("publish failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass


# ---------------------------------------------------------------------------
# StringPrompt
# ---------------------------------------------------------------------------


class StringPrompt(PromptBase):
    """Simple string prompt template with ``{{variable}}`` placeholders.

    Usage::

        prompt = StringPrompt("Hello, {{name}}! You are {{role}}.")
        rendered = prompt.format(name="Alice", role="an engineer")
        # "Hello, Alice! You are an engineer."
    """

    def __init__(self, template: str) -> None:
        self.template = template
        super().__init__()

    def _to_template(self) -> str:
        return self.template

    def format(self, **kwargs: Any) -> str:
        """Render the template by substituting ``{{key}}`` placeholders.

        Args:
            **kwargs: Variable values to substitute.

        Returns:
            The rendered string.
        """
        return _substitute(self.template, kwargs)

    def __repr__(self) -> str:
        preview = self.template[:60] + "..." if len(self.template) > 60 else self.template
        return f"StringPrompt({preview!r}, version={self._version})"


# ---------------------------------------------------------------------------
# MessagesPrompt
# ---------------------------------------------------------------------------


class MessagesPrompt(PromptBase):
    """Multi-turn chat prompt template.

    Stores a list of ``{"role": ..., "content": ...}`` message dicts
    with ``{{variable}}`` placeholders in the content fields.

    Usage::

        prompt = MessagesPrompt([
            {"role": "system", "content": "You are {{persona}}."},
            {"role": "user", "content": "{{question}}"},
        ])
        messages = prompt.format(persona="a pirate", question="What is ML?")
        # [
        #     {"role": "system", "content": "You are a pirate."},
        #     {"role": "user", "content": "What is ML?"},
        # ]
    """

    def __init__(self, messages: list[dict[str, str]]) -> None:
        self.messages = messages
        super().__init__()

    def _to_template(self) -> str:
        """Serialize messages to a stable string for hashing/publishing."""
        import json

        return json.dumps(self.messages, sort_keys=True)

    def format(self, **kwargs: Any) -> list[dict[str, str]]:
        """Render all message contents with the given variables.

        Args:
            **kwargs: Variable values to substitute in all message
                ``content`` fields.

        Returns:
            A new list of message dicts with substituted content.
        """
        result = []
        for msg in self.messages:
            rendered_msg = copy.copy(msg)
            if "content" in rendered_msg:
                rendered_msg["content"] = _substitute(
                    rendered_msg["content"], kwargs
                )
            result.append(rendered_msg)
        return result

    def add_message(self, role: str, content: str) -> None:
        """Append a message to the template.

        Args:
            role: Message role (e.g., ``"system"``, ``"user"``, ``"assistant"``).
            content: Message content, may contain ``{{variable}}`` placeholders.
        """
        self.messages.append({"role": role, "content": content})
        self._update_version()

    def __repr__(self) -> str:
        return (
            f"MessagesPrompt({len(self.messages)} messages, "
            f"version={self._version})"
        )


# ---------------------------------------------------------------------------
# Prompt -- server-side client (backward-compatible)
# ---------------------------------------------------------------------------


class Prompt:
    """SDK client for versioned prompt management.

    All methods are class methods that create short-lived HTTP connections.
    Methods are defensive -- they log warnings and return None on failure.

    This class also serves as the namespace for server-side prompt
    operations (get, render, publish).
    """

    @classmethod
    def get(
        cls,
        name: str,
        version: int | None = None,
        project: str | None = None,
    ) -> str | None:
        """Fetch a prompt template from the server.

        Args:
            name: Prompt name within the project.
            version: Specific version number, or None for latest.
            project: Project name/slug/ID. Defaults to OPENRUNNER_PROJECT env.

        Returns:
            The template string, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("Prompt.get: could not resolve project")
                return None

            # List prompts to find by name
            response = client.get(f"/projects/{project_id}/prompts")
            response.raise_for_status()
            prompts = response.json()

            prompt_id = None
            for p in prompts:
                if p.get("name") == name:
                    prompt_id = p["id"]
                    break

            if prompt_id is None:
                logger.warning("Prompt.get: prompt '%s' not found", name)
                return None

            # Get specific version or latest
            if version is not None:
                response = client.get(f"/prompts/{prompt_id}/versions/{version}")
                response.raise_for_status()
                return response.json().get("template")
            else:
                # Get prompt detail which includes versions
                response = client.get(f"/prompts/{prompt_id}")
                response.raise_for_status()
                data = response.json()
                versions = data.get("versions", [])
                if not versions:
                    logger.warning("Prompt.get: no versions for '%s'", name)
                    return None
                # Versions are sorted descending, first is latest
                return versions[0].get("template")

        except Exception as e:
            logger.warning("Prompt.get failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass

    @classmethod
    def render(
        cls,
        name: str,
        variables: dict[str, str],
        version: int | None = None,
        project: str | None = None,
    ) -> str | None:
        """Fetch a prompt template and render it with variables.

        Args:
            name: Prompt name within the project.
            variables: Variable values to substitute in the template.
            version: Specific version number, or None for latest.
            project: Project name/slug/ID.

        Returns:
            The rendered string, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("Prompt.render: could not resolve project")
                return None

            # Find prompt by name
            response = client.get(f"/projects/{project_id}/prompts")
            response.raise_for_status()
            prompts = response.json()

            prompt_id = None
            for p in prompts:
                if p.get("name") == name:
                    prompt_id = p["id"]
                    break

            if prompt_id is None:
                logger.warning("Prompt.render: prompt '%s' not found", name)
                return None

            # Call render endpoint
            body: dict[str, Any] = {"variables": variables}
            if version is not None:
                body["version"] = version
            response = client.post(f"/prompts/{prompt_id}/render", json=body)
            response.raise_for_status()
            return response.json().get("rendered")

        except Exception as e:
            logger.warning("Prompt.render failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass

    @classmethod
    def publish(
        cls,
        name: str,
        template: str,
        model_config: dict[str, Any] | None = None,
        description: str | None = None,
        project: str | None = None,
    ) -> dict[str, Any] | None:
        """Create or update a prompt version.

        If the prompt doesn't exist, creates it first.
        Always creates a new version with the provided template.

        Args:
            name: Prompt name within the project.
            template: The prompt template text with {{variable}} placeholders.
            model_config: Optional model configuration (model, temperature, etc.).
            description: Prompt description (used only if creating new prompt).
            project: Project name/slug/ID.

        Returns:
            Version info dict, or None on failure.
        """
        try:
            client = _get_client()
            project_id = _resolve_project_id(client, project)
            if project_id is None:
                logger.warning("Prompt.publish: could not resolve project")
                return None

            prompt_id = _find_or_create_prompt(
                client, project_id, name, description
            )
            if prompt_id is None:
                return None

            # Create a new version
            version_body: dict[str, Any] = {"template": template}
            if model_config is not None:
                version_body["model_config"] = model_config
            response = client.post(
                f"/prompts/{prompt_id}/versions", json=version_body
            )
            response.raise_for_status()
            return response.json()

        except Exception as e:
            logger.warning("Prompt.publish failed: %s", e)
            return None
        finally:
            try:
                client.close()
            except Exception:
                pass
