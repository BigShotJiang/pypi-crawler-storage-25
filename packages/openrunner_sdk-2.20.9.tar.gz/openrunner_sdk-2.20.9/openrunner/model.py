"""Weave Model class for versioned, serveable ML models.

Provides a ``Model`` base class that tracks model versions via source
code hashing, supports saving/loading as artifacts, and can serve
predictions via a simple HTTP endpoint.

Usage::

    import openrunner
    from openrunner.model import Model

    class MyClassifier(Model):
        def __init__(self, threshold: float = 0.5):
            self.threshold = threshold

        def predict(self, text: str) -> dict:
            score = some_model(text)
            return {"label": "positive" if score > self.threshold else "negative",
                    "score": score}

    # Save and version
    clf = MyClassifier(threshold=0.7)
    clf.save("my-classifier")

    # Load a specific version
    clf2 = MyClassifier.load("my-classifier", version=1)

    # Serve as HTTP endpoint
    clf.serve(port=8000)  # POST /predict with JSON body

Requires: ``pip install openrunner`` (``fastapi`` and ``uvicorn`` optional
for ``serve()``).
"""

from __future__ import annotations

import hashlib
import inspect
import json
import logging
import os
import pickle
import tempfile
from pathlib import Path
from typing import Any

import openrunner
from openrunner.artifact import Artifact

logger = logging.getLogger("openrunner")


def _source_hash(cls: type) -> str:
    """Compute a SHA-256 hash of a class's source code.

    Used for auto-versioning: if the source changes, the hash changes.
    Falls back to the class name hash if source is unavailable (e.g.,
    interactive interpreter, compiled code).
    """
    try:
        source = inspect.getsource(cls)
    except (OSError, TypeError):
        # Source not available -- fall back to class name + module
        source = f"{cls.__module__}.{cls.__qualname__}"
    return hashlib.sha256(source.encode()).hexdigest()[:16]


class Model:
    """Base class for versioned, serveable ML models.

    Subclass ``Model`` and implement ``predict(**kwargs)`` to create a
    trackable model. The class source code is hashed for auto-versioning,
    and instances can be saved/loaded as OpenRunner artifacts.

    Attributes:
        _source_hash: Auto-computed hash of the subclass source code.
    """

    def __init_subclass__(cls, **kwargs: Any) -> None:
        """Automatically compute the source hash when a subclass is defined."""
        super().__init_subclass__(**kwargs)
        cls._source_hash = _source_hash(cls)

    def predict(self, **kwargs: Any) -> Any:
        """Run a prediction. Must be implemented by subclasses.

        Args:
            **kwargs: Model-specific input parameters.

        Returns:
            Prediction result (any JSON-serializable type).

        Raises:
            NotImplementedError: If the subclass does not override this method.
        """
        raise NotImplementedError(
            f"{type(self).__name__} must implement predict()"
        )

    @property
    def version_hash(self) -> str:
        """Return the source code hash for this model class."""
        return getattr(self.__class__, "_source_hash", "unknown")

    def _get_config(self) -> dict[str, Any]:
        """Extract model configuration from ``__init__`` arguments.

        Inspects the instance ``__dict__`` for serializable attributes
        set during ``__init__``. This provides automatic config tracking.

        Returns:
            Dict of config key-value pairs.
        """
        config: dict[str, Any] = {}
        for key, value in self.__dict__.items():
            if key.startswith("_"):
                continue
            # Only include JSON-serializable values
            try:
                json.dumps(value)
                config[key] = value
            except (TypeError, ValueError):
                config[key] = repr(value)
        return config

    def save(self, name: str, project: str | None = None) -> dict[str, Any] | None:
        """Save this model instance as a versioned artifact.

        Serializes the model with pickle and uploads it as an OpenRunner
        artifact of type ``"model"``. The artifact metadata includes the
        source hash, class name, and config.

        Args:
            name: Artifact name for the model.
            project: Optional project name override.

        Returns:
            Server response dict with version info, or None on failure.
        """
        try:
            # Ensure a run is active
            if openrunner._active_run is None:
                openrunner.init(project=project)

            # Serialize model to a temp file
            with tempfile.TemporaryDirectory() as tmpdir:
                model_path = os.path.join(tmpdir, "model.pkl")
                config_path = os.path.join(tmpdir, "config.json")

                # Save pickled model
                with open(model_path, "wb") as f:
                    pickle.dump(self, f)

                # Save config metadata
                config = {
                    "class": type(self).__qualname__,
                    "module": type(self).__module__,
                    "source_hash": self.version_hash,
                    "config": self._get_config(),
                }
                with open(config_path, "w") as f:
                    json.dump(config, f, indent=2)

                # Create and upload artifact
                artifact = Artifact(
                    name=name,
                    type="model",
                    metadata={
                        "source_hash": self.version_hash,
                        "class": type(self).__qualname__,
                    },
                )
                artifact.add_file(model_path, name="model.pkl")
                artifact.add_file(config_path, name="config.json")

                result = openrunner.log_artifact(artifact)
                if result:
                    logger.info(
                        "Model '%s' saved (source_hash=%s)",
                        name,
                        self.version_hash,
                    )
                return result

        except Exception as e:
            logger.warning("Model.save() failed: %s", e)
            return None

    @classmethod
    def load(
        cls,
        name: str,
        version: int | None = None,
        project: str | None = None,
    ) -> "Model | None":
        """Load a model instance from a saved artifact.

        Downloads the artifact and unpickles the model. The returned
        object is an instance of the original subclass (assuming the
        class is importable in the current environment).

        Args:
            name: Artifact name of the saved model.
            version: Specific version number, or None for latest.
            project: Optional project name override.

        Returns:
            The deserialized Model instance, or None on failure.
        """
        try:
            # Ensure a run is active
            if openrunner._active_run is None:
                openrunner.init(project=project)

            artifact_path = openrunner.use_artifact(name, version=version)
            if artifact_path is None:
                logger.warning("Model.load: artifact '%s' not found", name)
                return None

            model_file = Path(artifact_path) / "model.pkl"
            if not model_file.exists():
                logger.warning("Model.load: model.pkl not found in artifact")
                return None

            with open(model_file, "rb") as f:
                model = pickle.load(f)

            if not isinstance(model, Model):
                logger.warning(
                    "Model.load: loaded object is not a Model subclass"
                )
                return None

            logger.info(
                "Model '%s' loaded (source_hash=%s)",
                name,
                model.version_hash,
            )
            return model

        except Exception as e:
            logger.warning("Model.load() failed: %s", e)
            return None

    def serve(self, port: int = 8000, host: str = "0.0.0.0") -> None:
        """Serve the model as an HTTP API with a ``/predict`` endpoint.

        Launches a FastAPI server with:
        - ``POST /predict`` -- accepts JSON body, calls ``self.predict(**body)``
        - ``GET /health`` -- health check
        - ``GET /info`` -- model metadata (class, source hash, config)

        Args:
            port: Port to listen on (default: 8000).
            host: Host to bind to (default: "0.0.0.0").

        Raises:
            ImportError: If ``fastapi`` or ``uvicorn`` is not installed.
        """
        try:
            from fastapi import FastAPI
            from fastapi.responses import JSONResponse
            import uvicorn
        except ImportError:
            raise ImportError(
                "Model.serve() requires fastapi and uvicorn. "
                "Install with: pip install fastapi uvicorn"
            )

        app = FastAPI(
            title=f"{type(self).__qualname__} Model Server",
            version=self.version_hash,
        )

        model = self  # Capture reference for closures

        @app.get("/health")
        def health() -> dict:
            return {"status": "healthy"}

        @app.get("/info")
        def info() -> dict:
            return {
                "class": type(model).__qualname__,
                "module": type(model).__module__,
                "source_hash": model.version_hash,
                "config": model._get_config(),
            }

        @app.post("/predict")
        async def predict(body: dict[str, Any]) -> Any:
            try:
                result = model.predict(**body)
                # Ensure the result is JSON-serializable
                if isinstance(result, dict):
                    return result
                return {"result": result}
            except Exception as e:
                return JSONResponse(
                    status_code=500,
                    content={"error": str(e)},
                )

        logger.info(
            "Serving %s on %s:%d (source_hash=%s)",
            type(self).__qualname__,
            host,
            port,
            self.version_hash,
        )
        uvicorn.run(app, host=host, port=port)
