"""Keras / TensorFlow integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- a Keras ``Callback`` that automatically
initialises an OpenRunner run at the start of training, logs metrics on
every epoch end, and finishes the run when training ends.

Works with both standalone Keras (``keras >= 3.0``) and the legacy
``tf.keras`` bundled with TensorFlow.

Usage::

    from openrunner.integration.keras import OpenRunnerCallback

    model.fit(
        x_train, y_train,
        callbacks=[OpenRunnerCallback()],
    )

Requires: ``pip install openrunner[keras]``
"""

from __future__ import annotations

from typing import Any

try:
    import keras  # noqa: F401
    from keras.callbacks import Callback as _KerasCallback
except ImportError:
    try:
        import tensorflow.keras as keras  # noqa: F401
        from tensorflow.keras.callbacks import Callback as _KerasCallback
    except ImportError:
        raise ImportError(
            "Keras integration requires keras or tensorflow. "
            "Install with: pip install openrunner[keras]"
        )

import openrunner


class OpenRunnerCallback(_KerasCallback):
    """Keras ``Callback`` that logs training to OpenRunner.

    * **on_train_begin** -- initialises a run if none is active.
    * **on_epoch_end** -- logs loss and all metrics from the ``logs`` dict.
    * **on_train_end** -- calls ``openrunner.finish()``.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._project = project
        self._config = config

    def on_train_begin(self, logs: dict | None = None) -> None:
        """Start a new run if one isn't already active."""
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if self._project:
                kwargs["project"] = self._project
            if self._config:
                kwargs["config"] = self._config
            openrunner.init(**kwargs)

    def on_epoch_end(self, epoch: int, logs: dict | None = None) -> None:
        """Log numeric metrics at the end of each epoch."""
        if logs and openrunner._active_run is not None:
            metrics = {
                k: v
                for k, v in logs.items()
                if isinstance(v, (int, float))
            }
            if metrics:
                openrunner.log(metrics, step=epoch)

    def on_train_end(self, logs: dict | None = None) -> None:
        """Finish the active run."""
        openrunner.finish()
