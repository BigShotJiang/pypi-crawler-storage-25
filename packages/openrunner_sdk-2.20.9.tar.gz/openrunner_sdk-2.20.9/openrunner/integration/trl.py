"""Hugging Face TRL (RLHF/DPO) integration for OpenRunner.

Provides a callback for TRL trainers (SFTTrainer, DPOTrainer, PPOTrainer).

Usage::

    from openrunner.integration.trl import OpenRunnerCallback
    from trl import SFTTrainer

    trainer = SFTTrainer(
        model=model,
        args=training_args,
        train_dataset=dataset,
        callbacks=[OpenRunnerCallback()],
    )

Requires: ``pip install openrunner[trl]``
"""

from __future__ import annotations
from typing import Any

try:
    from transformers import TrainerCallback, TrainerControl, TrainerState, TrainingArguments
except ImportError:
    raise ImportError(
        "TRL integration requires transformers. "
        "Install with: pip install trl transformers"
    )

import openrunner


class OpenRunnerCallback(TrainerCallback):
    """TRL Trainer callback that logs RLHF/DPO/SFT metrics to OpenRunner.

    Extends the base HuggingFace callback with TRL-specific metric handling
    (reward, kl divergence, policy loss, etc.)
    """

    def on_train_begin(self, args, state, control, **kwargs):
        if openrunner._active_run is None:
            config = args.to_dict() if hasattr(args, 'to_dict') else {}
            # Add TRL-specific config
            model = kwargs.get("model")
            if model and hasattr(model, 'config'):
                mc = model.config
                config["model_name"] = getattr(mc, '_name_or_path', str(type(model).__name__))
            openrunner.init(config=config)
        else:
            config = args.to_dict() if hasattr(args, 'to_dict') else {}
            openrunner.config.update(config)

    def on_log(self, args, state, control, logs=None, **kwargs):
        if logs and openrunner._active_run is not None:
            metrics = {}
            for k, v in logs.items():
                if isinstance(v, (int, float)):
                    # Prefix TRL-specific metrics
                    if k in ("rewards/chosen", "rewards/rejected", "rewards/margins",
                             "logps/chosen", "logps/rejected", "kl", "loss"):
                        metrics[f"trl/{k}"] = float(v)
                    else:
                        metrics[k] = float(v)
            if metrics:
                openrunner.log(metrics, step=state.global_step)

    def on_train_end(self, args, state, control, **kwargs):
        openrunner.finish()
