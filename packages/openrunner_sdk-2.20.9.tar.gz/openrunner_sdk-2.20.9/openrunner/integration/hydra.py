"""Hydra config management integration for OpenRunner.

Automatically logs the Hydra-composed config to OpenRunner.

Usage::

    from openrunner.integration.hydra import openrunner_hydra_callback

    @hydra.main(config_path="conf", config_name="config")
    def train(cfg):
        openrunner_hydra_callback(cfg)
        # ... training code

Requires: ``pip install openrunner[hydra]``
"""

from __future__ import annotations
from typing import Any

import openrunner


def openrunner_hydra_callback(cfg: Any, project: str | None = None):
    """Initialize OpenRunner with a Hydra config.

    Converts the OmegaConf DictConfig to a plain dict and passes
    it to openrunner.init().

    Args:
        cfg: Hydra DictConfig
        project: Optional project name
    """
    try:
        from omegaconf import OmegaConf
        config_dict = OmegaConf.to_container(cfg, resolve=True, throw_on_missing=False)
    except ImportError:
        # Fallback: try to convert directly
        if hasattr(cfg, '__dict__'):
            config_dict = dict(cfg)
        else:
            config_dict = {"hydra_config": str(cfg)}

    if not isinstance(config_dict, dict):
        config_dict = {"config": config_dict}

    kwargs: dict[str, Any] = {"config": config_dict}
    if project:
        kwargs["project"] = project

    openrunner.init(**kwargs)


class OpenRunnerHydraCallback:
    """Hydra callback class for automatic OpenRunner integration.

    Add to your Hydra config::

        hydra:
          callbacks:
            openrunner:
              _target_: openrunner.integration.hydra.OpenRunnerHydraCallback
    """

    def on_run_start(self, config: Any, **kwargs: Any) -> None:
        openrunner_hydra_callback(config)

    def on_run_end(self, config: Any, **kwargs: Any) -> None:
        openrunner.finish()

    def on_multirun_start(self, config: Any, **kwargs: Any) -> None:
        pass  # Each sub-run handles its own init

    def on_multirun_end(self, config: Any, **kwargs: Any) -> None:
        pass
