"""TTS (Text-to-Speech) integration for OpenRunner.

Tracks TTS model training and evaluation with audio comparison.

Usage::

    from openrunner.integration.tts import log_synthesis, TTSCallback

    # Log a single synthesis
    log_synthesis(
        text="Hello world",
        audio_path="output.wav",
        reference_path="reference.wav",
        metrics={"pesq": 3.5, "mel_cepstral_distortion": 4.2},
    )
"""

from __future__ import annotations

from typing import Any, Callable

import openrunner
from openrunner.media import Audio, AudioComparison, SpectrogramImage


def log_synthesis(
    text: str,
    audio_path: str | None = None,
    audio_array: Any = None,
    sample_rate: int = 22050,
    reference_path: str | None = None,
    reference_array: Any = None,
    metrics: dict[str, Any] | None = None,
    spectrogram: Any = None,
    key: str = "tts",
    step: int | None = None,
) -> None:
    """Log a TTS synthesis result with optional comparison.

    Args:
        text: Input text that was synthesized.
        audio_path: Path to synthesized audio file.
        audio_array: Or numpy array of synthesized audio.
        sample_rate: Sample rate of audio.
        reference_path: Optional path to reference/ground-truth audio.
        reference_array: Or numpy array of reference audio.
        metrics: Dict of evaluation metrics (PESQ, STOI, MOS, MCD, etc.).
        spectrogram: Optional 2D numpy array of mel spectrogram.
        key: Metric key prefix.
        step: Optional step number.
    """
    if openrunner._active_run is None:
        return

    # Log synthesized audio
    synth_audio: Audio | None = None
    if audio_path:
        synth_audio = Audio(audio_path, caption=f"TTS: {text[:50]}")
        openrunner.log({f"{key}/audio": synth_audio}, step=step, commit=False)
    elif audio_array is not None:
        synth_audio = Audio(
            audio_array, sample_rate=sample_rate, caption=f"TTS: {text[:50]}",
        )
        openrunner.log({f"{key}/audio": synth_audio}, step=step, commit=False)

    # Log reference audio if provided
    ref_audio: Audio | None = None
    if reference_path:
        ref_audio = Audio(reference_path, caption="Reference")
        openrunner.log({f"{key}/reference": ref_audio}, step=step, commit=False)
    elif reference_array is not None:
        ref_audio = Audio(
            reference_array, sample_rate=sample_rate, caption="Reference",
        )
        openrunner.log({f"{key}/reference": ref_audio}, step=step, commit=False)

    # Log comparison
    if synth_audio and ref_audio:
        comp = AudioComparison(
            reference=ref_audio,
            synthesized=synth_audio,
            metrics=metrics or {},
            text=text,
        )
        openrunner.log({f"{key}/comparison": comp}, step=step, commit=False)

    # Log spectrogram
    if spectrogram is not None:
        spec_img = SpectrogramImage(
            spectrogram, sample_rate=sample_rate,
            caption=f"Mel spec: {text[:30]}",
        )
        openrunner.log({f"{key}/spectrogram": spec_img}, step=step, commit=False)

    # Log metrics
    if metrics:
        prefixed = {
            f"{key}/{k}": v
            for k, v in metrics.items()
            if isinstance(v, (int, float))
        }
        openrunner.log(prefixed, step=step, commit=False)

    # Commit the step
    openrunner.log({}, step=step, commit=True)


class TTSCallback:
    """Callback for TTS model training (VITS, Tacotron, etc.).

    Usage::

        cb = TTSCallback(project="tts-training", sample_rate=22050)
        cb.on_train_step(step=100, loss_dict={"total_loss": 2.3})
        cb.on_evaluate(step=100, synthesize_fn=model.synthesize)
    """

    def __init__(
        self,
        project: str | None = None,
        eval_texts: list[str] | None = None,
        sample_rate: int = 22050,
    ) -> None:
        self._project = project
        self._eval_texts = eval_texts or [
            "The quick brown fox jumps over the lazy dog.",
        ]
        self._sample_rate = sample_rate

    def on_train_step(self, step: int, loss_dict: dict[str, float]) -> None:
        """Log training losses.

        Args:
            step: Current training step.
            loss_dict: Dict of loss values.
        """
        if openrunner._active_run is None:
            openrunner.init(project=self._project)
        openrunner.log(loss_dict, step=step)

    def on_evaluate(
        self,
        step: int,
        synthesize_fn: Callable[[str], Any],
        metrics: dict[str, Any] | None = None,
        mel_fn: Callable[[str], Any] | None = None,
    ) -> None:
        """Synthesize eval texts and log results.

        Args:
            step: Current training step.
            synthesize_fn: Function that takes text and returns audio array.
            metrics: Optional evaluation metrics dict.
            mel_fn: Optional function that takes text and returns mel array.
        """
        for i, text in enumerate(self._eval_texts):
            audio = synthesize_fn(text)
            mel = mel_fn(text) if mel_fn else None
            log_synthesis(
                text=text,
                audio_array=audio,
                sample_rate=self._sample_rate,
                spectrogram=mel,
                metrics=metrics,
                key=f"eval/{i}",
                step=step,
            )
