"""CatBoost integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- a CatBoost-compatible callback that
logs evaluation metrics after each boosting iteration.

Usage::

    from openrunner.integration.catboost import OpenRunnerCallback

    model = CatBoostClassifier(iterations=100)
    model.fit(X_train, y_train, callbacks=[OpenRunnerCallback()])

Requires: ``pip install openrunner[catboost]``
"""

from __future__ import annotations

from typing import Any

try:
    from catboost import CatBoost  # noqa: F401
except ImportError:
    raise ImportError(
        "CatBoost integration requires catboost. "
        "Install with: pip install openrunner[catboost]"
    )

import openrunner


class OpenRunnerCallback:
    """CatBoost callback that logs metrics to OpenRunner.

    * **after_iteration** -- logs evaluation metrics for each dataset
      and metric combination.

    The callback automatically initialises an OpenRunner run if none is
    active when the first iteration completes.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        self._project = project
        self._config = config

    def after_iteration(self, info: Any) -> bool:
        """Log metrics after each boosting iteration.

        Args:
            info: CatBoost callback info object containing ``iteration``
                and ``metrics`` attributes.

        Returns:
            ``True`` to continue training.
        """
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if self._project:
                kwargs["project"] = self._project
            if self._config:
                kwargs["config"] = self._config
            openrunner.init(**kwargs)

        metrics: dict[str, float] = {}
        if hasattr(info, "metrics") and info.metrics:
            for dataset_name, dataset_metrics in info.metrics.items():
                for metric_name, values in dataset_metrics.items():
                    if values:
                        metrics[f"{dataset_name}/{metric_name}"] = float(
                            values[-1]
                        )

        if metrics:
            openrunner.log(metrics, step=info.iteration)

        return True  # continue training
