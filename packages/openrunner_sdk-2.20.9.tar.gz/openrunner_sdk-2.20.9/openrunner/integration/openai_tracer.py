"""OpenAI SDK integration for OpenRunner.

Wraps OpenAI API calls to log token usage, latency, and model info.

Usage::

    from openrunner.integration.openai_tracer import patch_openai

    patch_openai()  # monkey-patches the openai client

    # All subsequent OpenAI calls are traced
    response = client.chat.completions.create(...)

Requires: ``pip install openrunner[openai]``
"""

from __future__ import annotations
import time
import logging
from typing import Any

import openrunner

logger = logging.getLogger("openrunner")

_original_create = None


def patch_openai():
    """Monkey-patch the OpenAI client to trace all API calls."""
    try:
        import openai
    except ImportError:
        raise ImportError("OpenAI integration requires openai. Install with: pip install openai")

    global _original_create

    if _original_create is not None:
        return  # already patched

    _original_create = openai.resources.chat.completions.Completions.create

    def traced_create(self, *args, **kwargs):
        start = time.monotonic()
        try:
            result = _original_create(self, *args, **kwargs)
            elapsed = time.monotonic() - start

            if openrunner._active_run is not None:
                metrics = {
                    "llm/latency_s": elapsed,
                    "llm/model": str(kwargs.get("model", "")),
                }

                if hasattr(result, 'usage') and result.usage:
                    prompt_tokens = result.usage.prompt_tokens
                    completion_tokens = result.usage.completion_tokens
                    metrics["llm/prompt_tokens"] = float(prompt_tokens)
                    metrics["llm/completion_tokens"] = float(completion_tokens)
                    metrics["llm/total_tokens"] = float(result.usage.total_tokens)

                    # Compute and log cost
                    from openrunner.cost import compute_cost
                    model = str(kwargs.get("model", ""))
                    cost = compute_cost(model, prompt_tokens, completion_tokens)
                    if cost is not None:
                        metrics["llm/cost_usd"] = cost

                # Log numeric metrics only
                numeric = {k: v for k, v in metrics.items() if isinstance(v, (int, float))}
                if numeric:
                    openrunner.log(numeric)

            return result
        except Exception as e:
            elapsed = time.monotonic() - start
            if openrunner._active_run is not None:
                openrunner.log({"llm/error": 1, "llm/latency_s": elapsed})
            raise

    openai.resources.chat.completions.Completions.create = traced_create


def unpatch_openai():
    """Remove the monkey-patch."""
    global _original_create
    if _original_create is not None:
        try:
            import openai
            openai.resources.chat.completions.Completions.create = _original_create
            _original_create = None
        except ImportError:
            pass
