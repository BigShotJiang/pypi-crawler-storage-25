"""Gymnasium (OpenAI Gym successor) integration for OpenRunner.

Provides ``monitor()`` -- a wrapper that auto-logs episode rewards,
lengths, and optionally captures video frames from a Gymnasium
environment.

Usage::

    import gymnasium as gym
    from openrunner.integration.gymnasium import monitor, autolog

    # Option 1: wrap an individual environment
    env = gym.make("CartPole-v1", render_mode="rgb_array")
    env = monitor(env, video=True, video_freq=10)

    # Option 2: auto-log with autolog()
    autolog(project="rl-experiments")
    env = gym.make("CartPole-v1")
    # ... training loop; metrics logged automatically

Requires: ``pip install openrunner[gymnasium]``
"""

from __future__ import annotations

import time
from typing import Any

try:
    import gymnasium as gym
    from gymnasium import Env
    from gymnasium.core import ActType, ObsType
except ImportError:
    raise ImportError(
        "Gymnasium integration requires gymnasium. "
        "Install with: pip install openrunner[gymnasium]"
    )

import numpy as np

import openrunner
from openrunner.media import Video


class _MonitorWrapper(gym.Wrapper):
    """Gymnasium wrapper that logs episode metrics to OpenRunner.

    Wraps an environment and automatically tracks:
    - Episode reward (cumulative)
    - Episode length (step count)
    - Episode wall-clock time
    - Optionally: video frames captured as ``openrunner.Video``

    Args:
        env: The Gymnasium environment to wrap.
        video: If True, capture RGB frames for video logging.
        video_freq: Log video every N episodes (default: 0, disabled).
            Requires ``video=True`` and the environment to have
            ``render_mode="rgb_array"``.
        video_fps: Frames per second for logged videos (default: 30).
    """

    def __init__(
        self,
        env: Env,
        video: bool = False,
        video_freq: int = 0,
        video_fps: int = 30,
    ) -> None:
        super().__init__(env)
        self._video = video
        self._video_freq = video_freq
        self._video_fps = video_fps

        # Episode tracking state
        self._episode_count = 0
        self._episode_reward = 0.0
        self._episode_length = 0
        self._episode_start_time = 0.0
        self._frames: list[Any] = []
        self._total_steps = 0

    def reset(
        self, *, seed: int | None = None, options: dict[str, Any] | None = None
    ) -> tuple[ObsType, dict[str, Any]]:
        """Reset the environment and start a new episode.

        If a previous episode was active, its metrics are logged before
        resetting.
        """
        # Log previous episode if there was one
        if self._episode_length > 0:
            self._log_episode()

        obs, info = self.env.reset(seed=seed, options=options)

        self._episode_reward = 0.0
        self._episode_length = 0
        self._episode_start_time = time.monotonic()
        self._frames = []

        # Capture initial frame
        if self._should_capture_video():
            self._capture_frame()

        return obs, info

    def step(self, action: ActType) -> tuple[ObsType, float, bool, bool, dict[str, Any]]:
        """Take a step in the environment and accumulate metrics."""
        obs, reward, terminated, truncated, info = self.env.step(action)

        self._episode_reward += float(reward)
        self._episode_length += 1
        self._total_steps += 1

        # Capture frame for video
        if self._should_capture_video():
            self._capture_frame()

        # Log episode when done
        if terminated or truncated:
            self._log_episode()

        return obs, reward, terminated, truncated, info

    def _should_capture_video(self) -> bool:
        """Check if we should capture video frames for this episode."""
        if not self._video:
            return False
        if self._video_freq <= 0:
            return False
        return self._episode_count % self._video_freq == 0

    def _capture_frame(self) -> None:
        """Capture an RGB frame from the environment."""
        try:
            frame = self.env.render()
            if frame is not None and isinstance(frame, np.ndarray):
                self._frames.append(frame)
        except Exception:
            pass  # Silently skip if render fails

    def _log_episode(self) -> None:
        """Log episode metrics to OpenRunner."""
        if openrunner._active_run is None:
            self._episode_count += 1
            return

        elapsed = time.monotonic() - self._episode_start_time
        metrics: dict[str, Any] = {
            "episode/reward": self._episode_reward,
            "episode/length": self._episode_length,
            "episode/time_s": round(elapsed, 3),
            "episode/number": self._episode_count,
            "global_step": self._total_steps,
        }

        # Log video if we captured frames
        if self._frames and len(self._frames) > 1:
            try:
                video_array = np.stack(self._frames)  # (T, H, W, C)
                metrics["episode/video"] = Video(
                    video_array,
                    fps=self._video_fps,
                    caption=f"Episode {self._episode_count}",
                )
            except Exception:
                pass  # Skip video if stacking fails

        openrunner.log(metrics, step=self._total_steps)
        self._episode_count += 1
        self._frames = []


def monitor(
    env: Env,
    video: bool = False,
    video_freq: int = 0,
    video_fps: int = 30,
) -> _MonitorWrapper:
    """Wrap a Gymnasium environment with OpenRunner monitoring.

    Returns a wrapped environment that automatically logs episode
    rewards, lengths, and optionally video to OpenRunner.

    Args:
        env: The Gymnasium environment to wrap.
        video: If True, capture RGB frames for video logging.
            Requires the environment to use ``render_mode="rgb_array"``.
        video_freq: Log video every N episodes (0 = disabled).
        video_fps: Frames per second for logged videos (default: 30).

    Returns:
        A wrapped Gymnasium environment.

    Example::

        env = gym.make("CartPole-v1", render_mode="rgb_array")
        env = monitor(env, video=True, video_freq=10)
    """
    return _MonitorWrapper(
        env,
        video=video,
        video_freq=video_freq,
        video_fps=video_fps,
    )


# Store original gym.make for autolog patching
_original_gym_make = gym.make
_autolog_active = False
_autolog_video = False
_autolog_video_freq = 0
_autolog_video_fps = 30


def _patched_gym_make(
    id: str, *args: Any, **kwargs: Any
) -> Env:
    """Patched ``gym.make`` that auto-wraps environments with monitoring."""
    env = _original_gym_make(id, *args, **kwargs)
    return monitor(
        env,
        video=_autolog_video,
        video_freq=_autolog_video_freq,
        video_fps=_autolog_video_fps,
    )


def autolog(
    project: str | None = None,
    video: bool = False,
    video_freq: int = 0,
    video_fps: int = 30,
) -> None:
    """Enable automatic logging for all Gymnasium environments.

    Monkey-patches ``gymnasium.make`` so that every new environment is
    automatically wrapped with the OpenRunner monitor. Also initializes
    an OpenRunner run if none is active.

    Args:
        project: Project name for ``openrunner.init()``.
        video: Enable video capture (default: False).
        video_freq: Log video every N episodes (default: 0, disabled).
        video_fps: Frames per second for videos (default: 30).

    Example::

        from openrunner.integration.gymnasium import autolog
        autolog(project="rl-experiments", video=True, video_freq=5)

        import gymnasium as gym
        env = gym.make("CartPole-v1", render_mode="rgb_array")
        # env is now auto-monitored
    """
    global _autolog_active, _autolog_video, _autolog_video_freq, _autolog_video_fps

    # Initialize run if needed
    if openrunner._active_run is None:
        openrunner.init(project=project)

    _autolog_video = video
    _autolog_video_freq = video_freq
    _autolog_video_fps = video_fps

    if not _autolog_active:
        gym.make = _patched_gym_make  # type: ignore[assignment]
        _autolog_active = True
