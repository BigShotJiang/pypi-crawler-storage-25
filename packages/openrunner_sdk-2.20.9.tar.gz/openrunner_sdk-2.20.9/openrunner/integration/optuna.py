"""Optuna integration for OpenRunner.

Provides ``OpenRunnerCallback`` for logging Optuna study trials.
Each trial creates a new metric log entry with the trial's params
and objective value.

Usage::

    import optuna
    from openrunner.integration.optuna import OpenRunnerCallback

    def objective(trial):
        lr = trial.suggest_float("lr", 1e-5, 1e-1, log=True)
        ...
        return accuracy

    study = optuna.create_study(direction="maximize")
    study.optimize(objective, n_trials=100,
                   callbacks=[OpenRunnerCallback()])

Requires: ``pip install openrunner[optuna]``
"""

from __future__ import annotations

from typing import Any

try:
    import optuna
except ImportError:
    raise ImportError(
        "Optuna integration requires optuna. "
        "Install with: pip install openrunner[optuna]"
    )

import openrunner


class OpenRunnerCallback:
    """Optuna callback that logs each trial to OpenRunner.

    Each trial creates a new metric log entry with the trial's
    params and objective value.

    * **__call__** -- invoked after each trial completes; logs
      trial params and objective value, and updates config with
      best trial info when a new best is found.

    Args:
        project: Project name passed to ``openrunner.init()``.
        metric_name: Name for the objective metric (default: ``"objective"``).
        log_params: Whether to log trial params as metrics for charting
            (default: ``True``).
    """

    def __init__(
        self,
        project: str | None = None,
        metric_name: str = "objective",
        log_params: bool = True,
    ) -> None:
        self._project = project
        self._metric_name = metric_name
        self._log_params = log_params

    def __call__(
        self, study: optuna.Study, trial: optuna.trial.FrozenTrial
    ) -> None:
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if self._project:
                kwargs["project"] = self._project
            openrunner.init(**kwargs)

        # Log trial params and value
        metrics: dict[str, float] = {
            self._metric_name: trial.value if trial.value is not None else 0.0,
            "trial_number": float(trial.number),
        }

        # Log params as metrics too (for charting)
        if self._log_params and trial.params:
            for k, v in trial.params.items():
                if isinstance(v, (int, float)):
                    metrics[f"param/{k}"] = float(v)

        openrunner.log(metrics, step=trial.number)

        # Update config with best trial info
        if study.best_trial.number == trial.number:
            openrunner.summary["best_value"] = trial.value
            openrunner.summary["best_trial"] = trial.number
            if trial.params:
                openrunner.config.update(
                    {f"best/{k}": v for k, v in trial.params.items()}
                )
