"""FastAI integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- a FastAI ``Callback`` that logs
training and validation losses and metrics after each epoch, and
finishes the run when training ends.

Usage::

    from openrunner.integration.fastai import OpenRunnerCallback

    learn = cnn_learner(dls, resnet34, cbs=[OpenRunnerCallback()])
    learn.fit(10)

Requires: ``pip install openrunner[fastai]``
"""

from __future__ import annotations

from typing import Any

try:
    from fastai.callback.core import Callback as _FastAICallback
except ImportError:
    raise ImportError(
        "FastAI integration requires fastai. "
        "Install with: pip install openrunner[fastai]"
    )

import openrunner


class OpenRunnerCallback(_FastAICallback):
    """FastAI ``Callback`` that logs training to OpenRunner.

    * **before_fit** -- initialises a run if none is active.
    * **after_epoch** -- logs train/valid loss and all recorder metrics.
    * **after_fit** -- calls ``openrunner.finish()``.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._project = project
        self._config = config

    def before_fit(self) -> None:
        """Start a new run if one isn't already active."""
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if self._project:
                kwargs["project"] = self._project
            if self._config:
                kwargs["config"] = self._config
            openrunner.init(**kwargs)

    def after_epoch(self) -> None:
        """Log train/valid loss and metrics at the end of each epoch."""
        if openrunner._active_run is None:
            return

        metrics: dict[str, float] = {}

        # Log train and valid loss from the recorder
        if hasattr(self, "recorder"):
            recorder = self.recorder
            if hasattr(recorder, "log") and recorder.log:
                # recorder.log is a list: [train_loss, valid_loss, *metric_values]
                log_values = recorder.log

                # Get metric names from recorder
                metric_names = ["train_loss", "valid_loss"]
                if hasattr(recorder, "metric_names"):
                    # metric_names typically = ['epoch', 'train_loss', 'valid_loss', ...]
                    names = list(recorder.metric_names)
                    # Skip 'epoch' and 'time' if present
                    names = [n for n in names if n not in ("epoch", "time")]
                    if names:
                        metric_names = names

                for i, val in enumerate(log_values):
                    if i < len(metric_names) and isinstance(val, (int, float)):
                        metrics[metric_names[i]] = float(val)

        # Determine current epoch
        epoch = getattr(self, "epoch", 0)

        if metrics:
            openrunner.log(metrics, step=epoch)

    def after_fit(self) -> None:
        """Finish the active run."""
        openrunner.finish()
