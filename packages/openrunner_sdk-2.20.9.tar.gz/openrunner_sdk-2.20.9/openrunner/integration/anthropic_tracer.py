"""Anthropic SDK integration for OpenRunner.

Wraps Anthropic API calls to log token usage, latency, and model info.

Usage::

    from openrunner.integration.anthropic_tracer import patch_anthropic

    patch_anthropic()
    response = client.messages.create(...)

Requires: ``pip install openrunner[anthropic]``
"""

from __future__ import annotations
import time
import logging
from typing import Any

import openrunner

logger = logging.getLogger("openrunner")

_original_create = None


def patch_anthropic():
    """Monkey-patch the Anthropic client to trace all API calls."""
    try:
        import anthropic
    except ImportError:
        raise ImportError("Anthropic integration requires anthropic. Install with: pip install anthropic")

    global _original_create
    if _original_create is not None:
        return

    _original_create = anthropic.resources.messages.Messages.create

    def traced_create(self, *args, **kwargs):
        start = time.monotonic()
        try:
            result = _original_create(self, *args, **kwargs)
            elapsed = time.monotonic() - start

            if openrunner._active_run is not None:
                metrics: dict[str, float] = {
                    "llm/latency_s": elapsed,
                }

                if hasattr(result, 'usage') and result.usage:
                    input_tokens = result.usage.input_tokens
                    output_tokens = result.usage.output_tokens
                    metrics["llm/input_tokens"] = float(input_tokens)
                    metrics["llm/output_tokens"] = float(output_tokens)

                    # Compute and log cost
                    from openrunner.cost import compute_cost
                    model = str(kwargs.get("model", ""))
                    cost = compute_cost(model, input_tokens, output_tokens)
                    if cost is not None:
                        metrics["llm/cost_usd"] = cost

                openrunner.log(metrics)

            return result
        except Exception as e:
            elapsed = time.monotonic() - start
            if openrunner._active_run is not None:
                openrunner.log({"llm/error": 1, "llm/latency_s": elapsed})
            raise

    anthropic.resources.messages.Messages.create = traced_create


def unpatch_anthropic():
    """Remove the monkey-patch."""
    global _original_create
    if _original_create is not None:
        try:
            import anthropic
            anthropic.resources.messages.Messages.create = _original_create
            _original_create = None
        except ImportError:
            pass
