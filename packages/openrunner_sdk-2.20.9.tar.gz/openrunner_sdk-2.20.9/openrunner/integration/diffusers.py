"""HuggingFace Diffusers integration for OpenRunner.

Auto-logs Stable Diffusion pipeline runs with prompts,
generated images, and pipeline configs.

Usage:
    from openrunner.integration.diffusers import autolog

    autolog()  # patches pipeline __call__

    pipe = StableDiffusionPipeline.from_pretrained("...")
    images = pipe("a cat on mars")  # auto-logged
"""

from __future__ import annotations
import time
from typing import Any

import openrunner

_original_call = None


def autolog():
    """Monkey-patch Diffusers pipelines to auto-log to OpenRunner."""
    global _original_call

    try:
        from diffusers import DiffusionPipeline
    except ImportError:
        raise ImportError("Diffusers integration requires diffusers. pip install diffusers")

    if _original_call is not None:
        return

    _original_call = DiffusionPipeline.__call__

    def traced_call(self, *args, **kwargs):
        start = time.monotonic()
        result = _original_call(self, *args, **kwargs)
        elapsed = time.monotonic() - start

        if openrunner._active_run is not None:
            # Log prompt
            prompt = args[0] if args else kwargs.get("prompt", "")
            neg_prompt = kwargs.get("negative_prompt", "")

            metrics: dict[str, Any] = {
                "diffusion/latency_s": elapsed,
                "diffusion/num_inference_steps": kwargs.get("num_inference_steps", 50),
                "diffusion/guidance_scale": kwargs.get("guidance_scale", 7.5),
            }
            openrunner.log(metrics)

            # Log generated images
            if hasattr(result, "images") and result.images:
                for i, img in enumerate(result.images[:4]):  # max 4
                    caption = f"{prompt[:60]}" if isinstance(prompt, str) else "generated"
                    openrunner.log({
                        f"diffusion/image_{i}": openrunner.Image(img, caption=caption)
                    })

            # Log config
            openrunner.config.update({
                "diffusion/model": getattr(self, "name_or_path", type(self).__name__),
                "diffusion/prompt": prompt[:200] if isinstance(prompt, str) else str(prompt)[:200],
            })

        return result

    DiffusionPipeline.__call__ = traced_call
