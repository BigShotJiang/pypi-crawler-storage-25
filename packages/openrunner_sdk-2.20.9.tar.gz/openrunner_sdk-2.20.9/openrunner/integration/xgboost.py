"""XGBoost integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- an XGBoost ``TrainingCallback`` that
logs evaluation metrics after each boosting iteration and records the
best iteration/score when training completes.

Usage::

    from openrunner.integration.xgboost import OpenRunnerCallback

    xgb.train(
        params, dtrain,
        evals=[(dtest, "test")],
        callbacks=[OpenRunnerCallback()],
    )

Requires: ``pip install openrunner[xgboost]``
"""

from __future__ import annotations

from typing import Any

try:
    import xgboost as xgb  # noqa: F401
    from xgboost.callback import TrainingCallback as _XGBCallback
except ImportError:
    raise ImportError(
        "XGBoost integration requires xgboost. "
        "Install with: pip install openrunner[xgboost]"
    )

import openrunner


class OpenRunnerCallback(_XGBCallback):
    """XGBoost ``TrainingCallback`` that logs to OpenRunner.

    * **before_training** -- initialises a run if none is active.
    * **after_iteration** -- logs evaluation metrics from each eval set.
    * **after_training** -- logs best iteration and best score, then
      calls ``openrunner.finish()``.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.
        finish_on_end: Whether to call ``openrunner.finish()`` after
            training. Defaults to ``True``.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
        finish_on_end: bool = True,
    ) -> None:
        self._project = project
        self._config = config
        self._finish_on_end = finish_on_end

    def before_training(self, model: Any) -> Any:
        """Start a new run if one isn't already active."""
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if self._project:
                kwargs["project"] = self._project
            if self._config:
                kwargs["config"] = self._config
            openrunner.init(**kwargs)
        return model

    def after_iteration(self, model: Any, epoch: int, evals_log: dict) -> bool:
        """Log evaluation metrics after each boosting iteration.

        The ``evals_log`` dict has the structure::

            {"eval_set_name": {"metric_name": [values...]}}

        Logs each metric as ``{eval_set}/{metric}`` at the current
        iteration step.

        Returns ``False`` to continue training.
        """
        if openrunner._active_run is not None and evals_log:
            metrics: dict[str, float] = {}
            for eval_name, eval_metrics in evals_log.items():
                for metric_name, values in eval_metrics.items():
                    if values:
                        # values is a list; last entry is the current iteration
                        val = values[-1]
                        if isinstance(val, (int, float)):
                            metrics[f"{eval_name}/{metric_name}"] = val
            if metrics:
                openrunner.log(metrics, step=epoch)
        return False

    def after_training(self, model: Any) -> Any:
        """Log best iteration/score and finish the run."""
        if openrunner._active_run is not None:
            summary: dict[str, Any] = {}
            if hasattr(model, "best_iteration"):
                summary["best_iteration"] = model.best_iteration
            if hasattr(model, "best_score"):
                summary["best_score"] = model.best_score
            if summary:
                openrunner.log(summary)

        if self._finish_on_end:
            openrunner.finish()
        return model
