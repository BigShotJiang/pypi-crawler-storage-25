"""PyTorch Ignite integration for OpenRunner.

Provides ``OpenRunnerLogger`` -- a PyTorch Ignite ``BaseLogger`` that
logs metrics and engine events to OpenRunner. Also provides an
``attach()`` helper for quick one-line setup.

Usage::

    from pytorch_ignite import Events
    from ignite.engine import Engine
    from openrunner.integration.ignite import OpenRunnerLogger

    trainer = Engine(train_step)
    logger = OpenRunnerLogger(project="my-project")
    logger.attach(
        trainer,
        event_name=Events.ITERATION_COMPLETED(every=100),
        output_transform=lambda x: {"loss": x},
    )
    trainer.run(dataloader, max_epochs=10)

Requires: ``pip install openrunner[ignite]``
"""

from __future__ import annotations

from typing import Any, Callable

try:
    from ignite.engine import Engine, Events
    from ignite.handlers import BaseLogger, global_step_from_engine
except ImportError:
    raise ImportError(
        "Ignite integration requires pytorch-ignite. "
        "Install with: pip install openrunner[ignite]"
    )

import openrunner


class GradientTracker:
    """Mixin for tracking gradient norms during training.

    Attach to an engine to log per-parameter gradient L2 norms.
    Useful for detecting vanishing/exploding gradients.

    Usage::

        tracker = GradientTracker()
        tracker.attach(trainer, model, log_every=100)
    """

    def __init__(self) -> None:
        self._step_count = 0

    def attach(
        self,
        engine: Engine,
        model: Any,
        log_every: int = 100,
        event_name: Any = None,
    ) -> None:
        """Attach gradient tracking to an engine.

        Args:
            engine: Ignite Engine to attach to.
            model: A ``torch.nn.Module`` whose gradients to track.
            log_every: Log gradient norms every N events (default: 100).
            event_name: Ignite event to attach to. Defaults to
                ``Events.ITERATION_COMPLETED``.
        """
        if event_name is None:
            event_name = Events.ITERATION_COMPLETED

        @engine.on(event_name)
        def _log_gradients(_engine: Engine) -> None:
            self._step_count += 1
            if self._step_count % log_every != 0:
                return
            if openrunner._active_run is None:
                return
            step = _engine.state.iteration
            for name, param in model.named_parameters():
                if param.grad is not None:
                    norm = param.grad.norm().item()
                    openrunner.log(
                        {f"gradients/{name}": norm},
                        step=step,
                        commit=False,
                    )
            openrunner.log({}, step=step, commit=True)


class OpenRunnerLogger(BaseLogger):
    """PyTorch Ignite logger that sends metrics to OpenRunner.

    Supports the Ignite ``BaseLogger`` interface and can be attached to
    any Ignite ``Engine`` using ``attach()`` or ``attach_output_handler()``.

    An OpenRunner run is lazily initialized on the first logging call,
    and finished when ``close()`` is called.

    Args:
        project: Project name passed to ``openrunner.init()``.
        name: Run display name.
        config: Optional config dict.
        tags: Optional list of tags.
    """

    def __init__(
        self,
        project: str | None = None,
        name: str | None = None,
        config: dict[str, Any] | None = None,
        tags: list[str] | None = None,
    ) -> None:
        self._project = project
        self._name = name
        self._config = config
        self._tags = tags
        self._run: Any = None

    def _ensure_run(self) -> None:
        """Lazily initialize a run if one is not active."""
        if self._run is None:
            self._run = openrunner.init(
                project=self._project,
                name=self._name,
                config=self._config,
                tags=self._tags,
            )

    # -- BaseLogger protocol ---------------------------------------------------

    def attach(
        self,
        engine: Engine,
        event_name: Any = None,
        output_transform: Callable | None = None,
        global_step_transform: Callable | None = None,
        tag: str | None = None,
    ) -> None:
        """Attach the logger to an engine.

        This is the primary method for connecting the logger to training
        or evaluation engines. Metrics are logged at the specified event.

        Args:
            engine: The Ignite Engine to attach to.
            event_name: Ignite event that triggers logging. Defaults to
                ``Events.EPOCH_COMPLETED``.
            output_transform: Callable to extract metrics dict from
                engine output. Default: identity (engine.state.output
                is used as-is if it's a dict).
            global_step_transform: Callable ``(engine, event_name) -> int``
                for the step value. Defaults to
                ``global_step_from_engine(engine)``.
            tag: Optional prefix for metric keys (e.g., ``"train"``).
        """
        if event_name is None:
            event_name = Events.EPOCH_COMPLETED

        if global_step_transform is None:
            global_step_transform = global_step_from_engine(engine)

        @engine.on(event_name)
        def _log_handler(_engine: Engine) -> None:
            self._ensure_run()
            step = global_step_transform(_engine, event_name)
            metrics = self._extract_metrics(_engine, output_transform, tag)
            if metrics:
                openrunner.log(metrics, step=step)

        # Also attach init/finish handlers
        @engine.on(Events.STARTED)
        def _on_started(_engine: Engine) -> None:
            self._ensure_run()

        @engine.on(Events.COMPLETED)
        def _on_completed(_engine: Engine) -> None:
            self.close()

    def attach_output_handler(
        self,
        engine: Engine,
        event_name: Any,
        tag: str,
        output_transform: Callable | None = None,
        metric_names: list[str] | str | None = None,
        global_step_transform: Callable | None = None,
    ) -> None:
        """Attach a handler that logs engine output metrics.

        Compatible with the Ignite ``BaseLogger.attach_output_handler``
        interface.

        Args:
            engine: The Ignite Engine to attach to.
            event_name: Ignite event that triggers logging.
            tag: Prefix for metric keys (e.g., ``"train"``, ``"val"``).
            output_transform: Callable to extract a dict from
                ``engine.state.output``.
            metric_names: List of metric names from ``engine.state.metrics``
                to log, or ``"all"`` for everything.
            global_step_transform: Callable for step value.
        """
        if global_step_transform is None:
            global_step_transform = global_step_from_engine(engine)

        @engine.on(event_name)
        def _handler(_engine: Engine) -> None:
            self._ensure_run()
            step = global_step_transform(_engine, event_name)
            metrics: dict[str, Any] = {}

            # Collect from engine.state.metrics
            if metric_names == "all":
                for k, v in _engine.state.metrics.items():
                    if isinstance(v, (int, float)):
                        key = f"{tag}/{k}" if tag else k
                        metrics[key] = v
            elif isinstance(metric_names, list):
                for k in metric_names:
                    v = _engine.state.metrics.get(k)
                    if v is not None and isinstance(v, (int, float)):
                        key = f"{tag}/{k}" if tag else k
                        metrics[key] = v

            # Collect from output_transform
            if output_transform is not None and _engine.state.output is not None:
                output = output_transform(_engine.state.output)
                if isinstance(output, dict):
                    for k, v in output.items():
                        if isinstance(v, (int, float)):
                            key = f"{tag}/{k}" if tag else k
                            metrics[key] = v

            if metrics:
                openrunner.log(metrics, step=step)

    def _extract_metrics(
        self,
        engine: Engine,
        output_transform: Callable | None,
        tag: str | None,
    ) -> dict[str, Any]:
        """Extract metrics from engine state and/or output transform.

        Args:
            engine: The Ignite Engine.
            output_transform: Optional callable to extract dict from output.
            tag: Optional prefix for metric keys.

        Returns:
            Dict of metric key-value pairs.
        """
        metrics: dict[str, Any] = {}

        # From engine.state.metrics (populated by Ignite metric objects)
        if hasattr(engine.state, "metrics") and engine.state.metrics:
            for k, v in engine.state.metrics.items():
                if isinstance(v, (int, float)):
                    key = f"{tag}/{k}" if tag else k
                    metrics[key] = v

        # From output transform
        if output_transform is not None and hasattr(engine.state, "output"):
            output = output_transform(engine.state.output)
            if isinstance(output, dict):
                for k, v in output.items():
                    if isinstance(v, (int, float)):
                        key = f"{tag}/{k}" if tag else k
                        metrics[key] = v
        elif hasattr(engine.state, "output") and isinstance(
            engine.state.output, dict
        ):
            for k, v in engine.state.output.items():
                if isinstance(v, (int, float)):
                    key = f"{tag}/{k}" if tag else k
                    metrics[key] = v

        return metrics

    def close(self) -> None:
        """Finish the active run."""
        openrunner.finish()
        self._run = None
