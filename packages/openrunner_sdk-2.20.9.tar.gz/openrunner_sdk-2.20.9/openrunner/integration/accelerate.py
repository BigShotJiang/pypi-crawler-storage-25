"""HuggingFace Accelerate integration for OpenRunner.

Usage:
    from accelerate import Accelerator
    from openrunner.integration.accelerate import OpenRunnerTracker

    accelerator = Accelerator(log_with=[OpenRunnerTracker])
    accelerator.init_trackers("my-project", config={"lr": 1e-3})
    accelerator.log({"loss": 0.5}, step=1)
    accelerator.end_training()
"""

from __future__ import annotations
from typing import Any

try:
    from accelerate.tracking import GeneralTracker
except ImportError:
    raise ImportError(
        "Accelerate integration requires accelerate. "
        "Install with: pip install accelerate"
    )

import openrunner


class OpenRunnerTracker(GeneralTracker):
    """HuggingFace Accelerate tracker backed by OpenRunner."""

    name = "openrunner"
    requires_logging_directory = False

    def __init__(self, run_name: str | None = None, **kwargs):
        super().__init__()
        self._run_name = run_name

    @property
    def tracker(self):
        return openrunner._active_run

    def store_init_configuration(self, values: dict):
        if openrunner._active_run is None:
            openrunner.init(name=self._run_name, config=values)
        else:
            openrunner.config.update(values)

    def log(self, values: dict, step: int | None = None, **kwargs):
        metrics = {k: v for k, v in values.items() if isinstance(v, (int, float))}
        if metrics:
            openrunner.log(metrics, step=step)

    def finish(self):
        openrunner.finish()
