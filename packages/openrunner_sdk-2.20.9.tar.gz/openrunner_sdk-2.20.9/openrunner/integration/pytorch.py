"""PyTorch integration for OpenRunner.

Provides a ``log_gradients`` utility that logs gradient norms for all
model parameters via ``openrunner.log()``.

Usage::

    from openrunner.integration.pytorch import log_gradients

    for batch in dataloader:
        loss = model(batch)
        loss.backward()
        log_gradients(model, step=step)
        optimizer.step()

Requires: ``pip install openrunner[pytorch]``
"""

from __future__ import annotations

try:
    import torch  # noqa: F401
except ImportError:
    raise ImportError(
        "PyTorch integration requires torch. "
        "Install with: pip install openrunner[pytorch]"
    )

import openrunner


def watch(
    model: torch.nn.Module,
    log: str = "gradients",
    log_freq: int = 100,
    log_graph: bool = False,
) -> None:
    """Automatically log gradients and/or parameters of a model.

    Registers a backward hook that logs gradient norms every
    ``log_freq`` backward passes. Similar to ``wandb.watch()``.

    Args:
        model: A PyTorch ``nn.Module`` to watch.
        log: What to log -- ``"gradients"``, ``"parameters"``, or ``"all"``.
        log_freq: Log every N backward passes.
        log_graph: Ignored (kept for W&B API compatibility).
    """
    _counter = {"n": 0}
    log_grads = log in ("gradients", "all")
    log_params = log in ("parameters", "all")

    def _hook(module: torch.nn.Module, grad_input, grad_output) -> None:
        _counter["n"] += 1
        if _counter["n"] % log_freq != 0:
            return
        step = _counter["n"]
        if log_grads:
            for name, param in module.named_parameters():
                if param.grad is not None:
                    openrunner.log(
                        {f"gradients/{name}.norm": param.grad.norm().item()},
                        step=step,
                        commit=False,
                    )
        if log_params:
            for name, param in module.named_parameters():
                openrunner.log(
                    {f"parameters/{name}.norm": param.norm().item()},
                    step=step,
                    commit=False,
                )
        openrunner.log({}, step=step, commit=True)

    model.register_full_backward_hook(_hook)


def log_gradients(model: torch.nn.Module, step: int | None = None) -> None:
    """Log gradient norms for all model parameters.

    For each named parameter that has a gradient, logs the L2 norm
    as ``gradients/{name}``.  Parameters whose ``.grad`` is ``None``
    (e.g., frozen layers) are silently skipped.

    Args:
        model: A PyTorch ``nn.Module`` whose ``.backward()`` has been called.
        step: Optional explicit step value passed to ``openrunner.log()``.
    """
    for name, param in model.named_parameters():
        if param.grad is not None:
            norm = param.grad.norm().item()
            openrunner.log({f"gradients/{name}": norm}, step=step, commit=False)

    # Commit the step after all gradient norms have been logged.
    openrunner.log({}, step=step, commit=True)
