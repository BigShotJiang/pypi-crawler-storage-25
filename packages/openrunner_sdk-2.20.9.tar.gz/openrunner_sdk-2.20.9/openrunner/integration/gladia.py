"""Gladia STT integration for OpenRunner.

Tracks Gladia API transcription results with word-level timestamps,
speaker diarization, audio intelligence features, and latency metrics.

Usage::

    from openrunner.integration.gladia import log_gladia_result, GladiaTracer

    # Simple: log a single transcription result
    result = gladia_client.transcribe(audio_url="https://...")
    log_gladia_result(result)

    # Advanced: trace streaming/real-time sessions
    tracer = GladiaTracer(project="gladia/asr-eval")
    tracer.start_session(audio_url="https://...", config={"language": "en"})
    # ... receive streaming results ...
    tracer.log_utterance(utterance)
    tracer.end_session(metrics={"wer": 0.05})

Requires: ``pip install openrunner-sdk``
"""

from __future__ import annotations

import time
from typing import Any

import openrunner
from openrunner.media import Audio, Table, Transcript


def log_gladia_result(
    result: dict[str, Any],
    audio_path: str | None = None,
    audio_url: str | None = None,
    key: str = "gladia",
    step: int | None = None,
    log_audio: bool = True,
):
    """Log a Gladia API transcription result.

    Accepts the JSON response from Gladia's ``/v2/transcription`` endpoint
    or the ``/v2/pre-recorded`` endpoint.

    Args:
        result: Gladia API response dict.
        audio_path: Optional local path to the source audio file.
        audio_url: Optional URL of the source audio (for reference).
        key: Metric key prefix.
        step: Optional step number.
        log_audio: Whether to log the audio file alongside the transcript.
    """
    if openrunner._active_run is None:
        return

    # --- Extract transcript text ---
    transcription = result.get("result", result)
    full_text = ""
    segments: list[dict[str, Any]] = []

    # Handle Gladia v2 response format
    utterances = transcription.get("transcription", {}).get("utterances", [])
    if not utterances:
        # Try alternative format
        utterances = transcription.get("utterances", [])

    for utt in utterances:
        text = utt.get("text", "")
        full_text += text + " "
        seg: dict[str, Any] = {
            "start": utt.get("start", 0),
            "end": utt.get("end", 0),
            "text": text,
            "confidence": utt.get("confidence"),
        }
        if "speaker" in utt:
            seg["speaker"] = utt["speaker"]
        if "channel" in utt:
            seg["channel"] = utt["channel"]
        if "words" in utt:
            seg["words"] = [
                {
                    "word": w.get("word", ""),
                    "start": w.get("start", 0),
                    "end": w.get("end", 0),
                    "confidence": w.get("confidence"),
                }
                for w in utt["words"]
            ]
        segments.append(seg)

    full_text = full_text.strip()
    if not full_text:
        full_text = transcription.get("transcription", {}).get("full_transcript", "")

    # --- Log transcript ---
    language = (
        transcription.get("transcription", {}).get("languages", [{}])
    )
    lang_code = language[0].get("language") if isinstance(language, list) and language else None

    transcript = Transcript(
        text=full_text,
        segments=segments,
        language=lang_code,
        model="gladia",
        duration=transcription.get("metadata", {}).get("audio_duration"),
        confidence=transcription.get("metadata", {}).get("confidence"),
    )
    openrunner.log({f"{key}/transcript": transcript}, step=step, commit=False)

    # --- Log audio ---
    if log_audio and audio_path:
        openrunner.log(
            {f"{key}/audio": Audio(audio_path, caption=full_text[:80])},
            step=step,
            commit=False,
        )

    # --- Log metrics ---
    metrics: dict[str, float] = {}

    metadata = transcription.get("metadata", {})
    if "audio_duration" in metadata:
        metrics[f"{key}/audio_duration_s"] = float(metadata["audio_duration"])
    if "billing_time" in metadata:
        metrics[f"{key}/billing_time_s"] = float(metadata["billing_time"])
    if "number_of_distinct_channels" in metadata:
        metrics[f"{key}/channels"] = float(metadata["number_of_distinct_channels"])

    # Processing time (real-time factor)
    processing_time = metadata.get("processing_time")
    audio_duration = metadata.get("audio_duration")
    if processing_time and audio_duration:
        metrics[f"{key}/processing_time_s"] = float(processing_time)
        metrics[f"{key}/rtf"] = float(processing_time) / max(float(audio_duration), 0.001)

    # Utterance stats
    if segments:
        metrics[f"{key}/num_utterances"] = float(len(segments))
        confs = [s["confidence"] for s in segments if s.get("confidence") is not None]
        if confs:
            metrics[f"{key}/avg_confidence"] = sum(confs) / len(confs)
            metrics[f"{key}/min_confidence"] = min(confs)

    # Speaker count (diarization)
    speakers = {s.get("speaker") for s in segments if "speaker" in s}
    if speakers:
        metrics[f"{key}/num_speakers"] = float(len(speakers))

    # Word count
    word_count = sum(len(s.get("text", "").split()) for s in segments)
    if word_count:
        metrics[f"{key}/word_count"] = float(word_count)

    if metrics:
        openrunner.log(metrics, step=step, commit=False)

    # --- Log word-level table ---
    all_words: list[list[Any]] = []
    for seg in segments:
        for w in seg.get("words", []):
            all_words.append([
                w.get("word", ""),
                round(w.get("start", 0), 3),
                round(w.get("end", 0), 3),
                round(w.get("end", 0) - w.get("start", 0), 3),
                w.get("confidence"),
                seg.get("speaker"),
            ])

    if all_words:
        word_table = Table(
            columns=["word", "start", "end", "duration", "confidence", "speaker"],
            data=all_words,
        )
        openrunner.log({f"{key}/words": word_table}, step=step, commit=False)

    # --- Log speaker timeline table ---
    if speakers and len(speakers) > 1:
        speaker_rows: list[list[Any]] = []
        for seg in segments:
            speaker_rows.append([
                seg.get("speaker", "?"),
                round(seg.get("start", 0), 3),
                round(seg.get("end", 0), 3),
                round(seg.get("end", 0) - seg.get("start", 0), 3),
                seg.get("text", "")[:80],
            ])
        speaker_table = Table(
            columns=["speaker", "start", "end", "duration", "text"],
            data=speaker_rows,
        )
        openrunner.log({f"{key}/speakers": speaker_table}, step=step, commit=False)

    # --- Log audio intelligence results ---
    ai_results = transcription.get("transcription", {})

    # Sentiment
    sentiment = ai_results.get("sentiment")
    if sentiment and isinstance(sentiment, list):
        for s in sentiment:
            if isinstance(s, dict) and "sentiment" in s:
                openrunner.log(
                    {f"{key}/sentiment": s["sentiment"]},
                    step=step,
                    commit=False,
                )
                break

    # Summarization
    summary = ai_results.get("summarization")
    if summary:
        openrunner.summary[f"{key}/summary"] = (
            summary if isinstance(summary, str) else str(summary)
        )

    # Named entities
    entities = ai_results.get("named_entities")
    if entities and isinstance(entities, list) and len(entities) > 0:
        ent_rows = [
            [e.get("entity", ""), e.get("label", ""), e.get("start", ""), e.get("end", "")]
            for e in entities
            if isinstance(e, dict)
        ]
        if ent_rows:
            openrunner.log(
                {
                    f"{key}/entities": Table(
                        columns=["entity", "label", "start", "end"],
                        data=ent_rows,
                    )
                },
                step=step,
                commit=False,
            )

    openrunner.log({}, step=step, commit=True)


class GladiaTracer:
    """Trace Gladia streaming/real-time transcription sessions.

    Tracks per-utterance results, cumulative metrics, and session-level
    summaries for real-time STT quality evaluation.
    """

    def __init__(self, project: str | None = None, config: dict | None = None):
        self._project = project
        self._config = config
        self._session_start: float = 0
        self._utterances: list[dict] = []
        self._utterance_count = 0

    def start_session(
        self,
        audio_url: str | None = None,
        audio_path: str | None = None,
        config: dict | None = None,
    ) -> None:
        """Start a new transcription tracing session."""
        if openrunner._active_run is None:
            init_config = dict(self._config or {})
            if config:
                init_config.update(config)
            if audio_url:
                init_config["audio_url"] = audio_url
            kwargs: dict[str, Any] = {"config": init_config}
            if self._project:
                kwargs["project"] = self._project
            openrunner.init(**kwargs)

        self._session_start = time.monotonic()
        self._utterances = []
        self._utterance_count = 0

    def log_utterance(
        self,
        utterance: dict[str, Any],
        is_final: bool = True,
        latency: float | None = None,
    ) -> None:
        """Log a single utterance from the streaming API.

        Args:
            utterance: Gladia utterance dict with text, start, end, words, etc.
            is_final: Whether this is a final (vs interim) result.
            latency: End-to-end latency in seconds for this utterance.
        """
        if not is_final:
            return  # Skip interim results

        self._utterance_count += 1
        step = self._utterance_count

        text = utterance.get("text", "")
        self._utterances.append(utterance)

        metrics: dict[str, float] = {
            "stream/utterance": float(step),
        }

        if latency is not None:
            metrics["stream/latency_s"] = latency

        conf = utterance.get("confidence")
        if conf is not None:
            metrics["stream/confidence"] = float(conf)

        duration = (utterance.get("end", 0) or 0) - (utterance.get("start", 0) or 0)
        if duration > 0:
            metrics["stream/utterance_duration_s"] = duration

        openrunner.log(metrics, step=step)

    def end_session(self, metrics: dict[str, float] | None = None) -> None:
        """End the session and log summary."""
        elapsed = time.monotonic() - self._session_start

        summary: dict[str, float] = {
            "stream/total_utterances": float(self._utterance_count),
            "stream/session_duration_s": elapsed,
        }
        if metrics:
            summary.update({f"stream/{k}": v for k, v in metrics.items()
                          if isinstance(v, (int, float))})

        openrunner.log(summary)

        # Log full conversation table
        if self._utterances:
            rows = []
            for u in self._utterances:
                rows.append([
                    round(u.get("start", 0), 3),
                    round(u.get("end", 0), 3),
                    u.get("speaker", ""),
                    u.get("text", ""),
                    u.get("confidence"),
                ])
            openrunner.log({
                "stream/conversation": Table(
                    columns=["start", "end", "speaker", "text", "confidence"],
                    data=rows,
                )
            })

        openrunner.summary["total_utterances"] = self._utterance_count
        openrunner.summary["session_duration"] = round(elapsed, 2)
