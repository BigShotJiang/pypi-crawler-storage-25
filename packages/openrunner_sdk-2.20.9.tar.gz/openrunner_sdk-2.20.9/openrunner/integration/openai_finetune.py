"""OpenAI fine-tuning sync for OpenRunner.

Polls an OpenAI fine-tuning job and logs metrics to OpenRunner.

Usage:
    from openrunner.integration.openai_finetune import sync_finetune

    sync_finetune(job_id="ftjob-abc123", project="my-finetune")
"""

import time
import logging
from typing import Any

import openrunner

logger = logging.getLogger("openrunner")


def sync_finetune(
    job_id: str,
    project: str | None = None,
    poll_interval: int = 30,
    openai_api_key: str | None = None,
):
    """Poll an OpenAI fine-tuning job and log metrics.

    Args:
        job_id: OpenAI fine-tuning job ID (e.g., "ftjob-abc123")
        project: OpenRunner project name
        poll_interval: Seconds between polls
        openai_api_key: OpenAI API key (defaults to OPENAI_API_KEY env)
    """
    try:
        import openai
    except ImportError:
        raise ImportError("OpenAI fine-tune sync requires openai. pip install openai")

    client = openai.OpenAI(api_key=openai_api_key) if openai_api_key else openai.OpenAI()

    job = client.fine_tuning.jobs.retrieve(job_id)

    config = {
        "model": job.model,
        "training_file": job.training_file,
        "validation_file": job.validation_file,
        "hyperparameters": dict(job.hyperparameters) if job.hyperparameters else {},
        "fine_tuned_model": job.fine_tuned_model,
        "job_id": job_id,
    }

    run = openrunner.init(project=project or "openai-finetune", config=config)

    print(f"Syncing fine-tuning job {job_id} (model: {job.model})...")

    # Poll for events
    seen_events = set()
    step = 0

    while True:
        events = client.fine_tuning.jobs.list_events(job_id, limit=100)

        for event in reversed(list(events)):
            if event.id in seen_events:
                continue
            seen_events.add(event.id)

            if event.data and isinstance(event.data, dict):
                metrics = {}
                for k, v in event.data.items():
                    if isinstance(v, (int, float)):
                        metrics[f"finetune/{k}"] = v
                if metrics:
                    openrunner.log(metrics, step=step)
                    step += 1

        # Check job status
        job = client.fine_tuning.jobs.retrieve(job_id)
        if job.status in ("succeeded", "failed", "cancelled"):
            openrunner.summary["status"] = job.status
            if job.fine_tuned_model:
                openrunner.summary["fine_tuned_model"] = job.fine_tuned_model
            break

        time.sleep(poll_interval)

    openrunner.finish()
    print(f"Fine-tuning {job.status}: {job.fine_tuned_model or 'no model'}")
