"""LlamaIndex integration for OpenRunner.

Provides a callback handler for tracing LlamaIndex queries.

Usage::

    from openrunner.integration.llamaindex import OpenRunnerCallbackHandler
    from llama_index.core import Settings

    Settings.callback_manager.add_handler(OpenRunnerCallbackHandler())

Requires: ``pip install openrunner[llamaindex]``
"""

from __future__ import annotations
import time
from typing import Any

try:
    from llama_index.core.callbacks.base_handler import BaseCallbackHandler
    from llama_index.core.callbacks.schema import CBEventType
except ImportError:
    raise ImportError(
        "LlamaIndex integration requires llama-index-core. "
        "Install with: pip install llama-index-core"
    )

import openrunner


class OpenRunnerCallbackHandler(BaseCallbackHandler):
    """LlamaIndex callback handler that logs to OpenRunner.

    Traces LLM calls, retrieval, embedding, and query events.
    """

    def __init__(self, project: str | None = None):
        super().__init__(event_starts_to_ignore=[], event_ends_to_ignore=[])
        self._project = project
        self._event_starts: dict[str, float] = {}
        self._query_count = 0
        self._llm_count = 0
        self._retrieval_count = 0

    def on_event_start(
        self,
        event_type: CBEventType,
        payload: dict | None = None,
        event_id: str = "",
        parent_id: str = "",
        **kwargs: Any,
    ) -> str:
        if openrunner._active_run is None and self._project:
            openrunner.init(project=self._project)

        self._event_starts[event_id] = time.monotonic()
        return event_id

    def on_event_end(
        self,
        event_type: CBEventType,
        payload: dict | None = None,
        event_id: str = "",
        **kwargs: Any,
    ) -> None:
        if openrunner._active_run is None:
            return

        start_time = self._event_starts.pop(event_id, None)
        elapsed = (time.monotonic() - start_time) if start_time else 0

        metrics: dict[str, float] = {}

        if event_type == CBEventType.LLM:
            self._llm_count += 1
            metrics["llamaindex/llm_calls"] = float(self._llm_count)
            metrics["llamaindex/llm_latency_s"] = elapsed

            if payload:
                # Extract token usage if available
                response = payload.get("response")
                if response and hasattr(response, "raw") and hasattr(response.raw, "usage"):
                    usage = response.raw.usage
                    if hasattr(usage, "total_tokens"):
                        metrics["llamaindex/total_tokens"] = float(usage.total_tokens)

        elif event_type == CBEventType.RETRIEVE:
            self._retrieval_count += 1
            metrics["llamaindex/retrieval_calls"] = float(self._retrieval_count)
            metrics["llamaindex/retrieval_latency_s"] = elapsed

            if payload and "nodes" in payload:
                metrics["llamaindex/nodes_retrieved"] = float(len(payload["nodes"]))

        elif event_type == CBEventType.QUERY:
            self._query_count += 1
            metrics["llamaindex/query_calls"] = float(self._query_count)
            metrics["llamaindex/query_latency_s"] = elapsed

        if metrics:
            openrunner.log(metrics)

    def start_trace(self, trace_id: str | None = None) -> None:
        pass

    def end_trace(
        self,
        trace_id: str | None = None,
        trace_map: dict[str, list[str]] | None = None,
    ) -> None:
        pass
