"""Voice AI Agent integration for OpenRunner.

Tracks voice agent conversations with turn-level metrics.

Usage::

    from openrunner.integration.voice_agent import VoiceAgentTracer

    tracer = VoiceAgentTracer(project="voice-bot")

    tracer.start_conversation(session_id="abc123")
    tracer.log_turn(
        role="user",
        audio=user_audio,
        text="What's the weather?",
        stt_latency=0.3,
    )
    tracer.log_turn(
        role="assistant",
        text="It's sunny today.",
        audio=response_audio,
        tts_latency=0.5,
        llm_latency=0.8,
    )
    tracer.end_conversation(metrics={"satisfaction": 4.5})
"""

from __future__ import annotations

import time
from typing import Any

import openrunner
from openrunner.media import Audio, Table, Transcript


class VoiceAgentTracer:
    """Traces voice agent conversations with per-turn metrics.

    Logs audio, transcripts, latencies, intents, and tool calls
    for each conversation turn.  Produces a summary table at
    conversation end.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        self._project = project
        self._config = config
        self._turn_count = 0
        self._conversation_start: float | None = None
        self._session_id: str | None = None
        self._turns: list[dict[str, Any]] = []

    def start_conversation(
        self,
        session_id: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Start tracing a new conversation.

        Args:
            session_id: Optional conversation session ID.
            metadata: Optional metadata to add to the run config.
        """
        if openrunner._active_run is None:
            openrunner.init(project=self._project, config=self._config)

        self._session_id = session_id or str(int(time.time()))
        self._conversation_start = time.monotonic()
        self._turn_count = 0
        self._turns = []

        if metadata:
            openrunner.config.update(metadata)

    def log_turn(
        self,
        role: str,
        text: str | None = None,
        audio: Any = None,
        audio_array: Any = None,
        sample_rate: int = 16000,
        stt_latency: float | None = None,
        tts_latency: float | None = None,
        llm_latency: float | None = None,
        transcript_segments: list[dict[str, Any]] | None = None,
        intent: str | None = None,
        entities: list[dict[str, Any]] | None = None,
        tool_calls: list[dict[str, Any]] | None = None,
    ) -> None:
        """Log a single conversation turn.

        Args:
            role: Speaker role (``"user"`` or ``"assistant"``).
            text: Text content of the turn.
            audio: Audio data -- path string or Audio object.
            audio_array: Numpy array of audio samples.
            sample_rate: Sample rate for ``audio_array``.
            stt_latency: STT processing time in seconds.
            tts_latency: TTS processing time in seconds.
            llm_latency: LLM inference time in seconds.
            transcript_segments: Word-level timing segments.
            intent: Detected intent string.
            entities: Detected entities.
            tool_calls: Tool/function calls made in this turn.
        """
        self._turn_count += 1
        step = self._turn_count

        metrics: dict[str, float] = {
            "voice/turn": float(step),
        }

        # Log audio
        if audio is not None:
            if isinstance(audio, str):
                audio_obj = Audio(
                    audio, caption=f"{role}: {(text or '')[:50]}",
                )
            else:
                audio_obj = audio
            openrunner.log(
                {f"voice/{role}_audio": audio_obj}, step=step, commit=False,
            )
        elif audio_array is not None:
            audio_obj = Audio(
                audio_array, sample_rate=sample_rate,
                caption=f"{role}: {(text or '')[:50]}",
            )
            openrunner.log(
                {f"voice/{role}_audio": audio_obj}, step=step, commit=False,
            )

        # Log transcript
        if text and transcript_segments:
            t = Transcript(text=text, segments=transcript_segments)
            openrunner.log(
                {f"voice/{role}_transcript": t}, step=step, commit=False,
            )

        # Log latencies
        if stt_latency is not None:
            metrics["voice/stt_latency"] = stt_latency
        if tts_latency is not None:
            metrics["voice/tts_latency"] = tts_latency
        if llm_latency is not None:
            metrics["voice/llm_latency"] = llm_latency
        if stt_latency and tts_latency and llm_latency:
            metrics["voice/total_latency"] = (
                stt_latency + tts_latency + llm_latency
            )

        # Store turn data for conversation table
        turn_data: dict[str, Any] = {
            "turn": step,
            "role": role,
            "text": text or "",
            "stt_ms": round(stt_latency * 1000) if stt_latency else None,
            "tts_ms": round(tts_latency * 1000) if tts_latency else None,
            "llm_ms": round(llm_latency * 1000) if llm_latency else None,
            "intent": intent,
        }
        self._turns.append(turn_data)

        openrunner.log(metrics, step=step)

    def end_conversation(
        self, metrics: dict[str, Any] | None = None,
    ) -> None:
        """End the conversation and log summary.

        Args:
            metrics: Optional summary metrics (e.g., satisfaction score).
        """
        duration = (
            time.monotonic() - self._conversation_start
            if self._conversation_start
            else 0
        )

        summary_metrics: dict[str, float] = {
            "voice/total_turns": float(self._turn_count),
            "voice/conversation_duration_s": duration,
        }
        if metrics:
            summary_metrics.update({
                f"voice/{k}": v
                for k, v in metrics.items()
                if isinstance(v, (int, float))
            })

        openrunner.log(summary_metrics)

        # Log conversation as a table
        if self._turns:
            columns = [
                "turn", "role", "text",
                "stt_ms", "tts_ms", "llm_ms", "intent",
            ]
            data = [[t.get(c) for c in columns] for t in self._turns]
            table = Table(columns=columns, data=data)
            openrunner.log({"voice/conversation": table})

        # Update run summary
        openrunner.summary["total_turns"] = self._turn_count
        openrunner.summary["conversation_duration"] = round(duration, 2)
