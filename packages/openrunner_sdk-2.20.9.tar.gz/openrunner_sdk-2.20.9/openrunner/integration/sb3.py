"""Stable Baselines 3 integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- a Stable Baselines 3 ``BaseCallback``
that logs RL training metrics (reward, episode length, loss, etc.) to
OpenRunner at configurable intervals.

Usage::

    from stable_baselines3 import PPO
    from openrunner.integration.sb3 import OpenRunnerCallback

    model = PPO("MlpPolicy", "CartPole-v1")
    model.learn(total_timesteps=10000,
                callback=OpenRunnerCallback())

Requires: ``pip install openrunner[sb3]``
"""

from __future__ import annotations

from typing import Any

try:
    from stable_baselines3.common.callbacks import BaseCallback
except ImportError:
    raise ImportError(
        "SB3 integration requires stable-baselines3. "
        "Install with: pip install openrunner[sb3]"
    )

import openrunner


class OpenRunnerCallback(BaseCallback):
    """Stable Baselines 3 callback that logs to OpenRunner.

    Logs training metrics (reward, episode length, loss, etc.)
    at configurable intervals.

    * **_on_training_start** -- initialises a run with algorithm config.
    * **_on_step** -- logs metrics every ``log_interval`` steps.
    * **_on_training_end** -- finishes the run.

    Args:
        project: Project name passed to ``openrunner.init()``.
        log_interval: Log every N steps (default: ``100``).
        config: Optional config dict passed to ``openrunner.init()``.
        verbose: Verbosity level (default: ``0``).
    """

    def __init__(
        self,
        project: str | None = None,
        log_interval: int = 100,
        config: dict[str, Any] | None = None,
        verbose: int = 0,
    ) -> None:
        super().__init__(verbose)
        self._project = project
        self._log_interval = log_interval
        self._config = config

    def _on_training_start(self) -> None:
        if openrunner._active_run is None:
            init_config: dict[str, Any] = dict(self._config or {})
            # Extract algorithm config
            if hasattr(self.model, "learning_rate"):
                init_config["learning_rate"] = self.model.learning_rate
            if hasattr(self.model, "n_steps"):
                init_config["n_steps"] = self.model.n_steps
            if hasattr(self.model, "batch_size"):
                init_config["batch_size"] = self.model.batch_size
            init_config["algorithm"] = type(self.model).__name__

            kwargs: dict[str, Any] = {"config": init_config}
            if self._project:
                kwargs["project"] = self._project
            openrunner.init(**kwargs)

    def _on_step(self) -> bool:
        if self.n_calls % self._log_interval != 0:
            return True

        if openrunner._active_run is None:
            return True

        metrics: dict[str, float] = {
            "timesteps": float(self.num_timesteps),
        }

        # Log from the logger's name_to_value
        if hasattr(self.model, "logger") and self.model.logger is not None:
            for key, value in self.model.logger.name_to_value.items():
                if isinstance(value, (int, float)):
                    metrics[key] = float(value)

        # Log episode info from infos
        if self.locals.get("infos"):
            for info in self.locals["infos"]:
                if "episode" in info:
                    metrics["episode/reward"] = float(info["episode"]["r"])
                    metrics["episode/length"] = float(info["episode"]["l"])

        if metrics:
            openrunner.log(metrics, step=self.num_timesteps)

        return True

    def _on_training_end(self) -> None:
        openrunner.finish()
