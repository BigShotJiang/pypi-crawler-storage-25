"""Scikit-learn integration for OpenRunner.

Provides utility functions to log scikit-learn model information,
classification reports, confusion matrices, and feature importances
to an active OpenRunner run.

Usage::

    from openrunner.integration.sklearn import (
        log_model,
        log_classification_report,
        log_confusion_matrix,
        log_feature_importance,
    )

    model = RandomForestClassifier().fit(X_train, y_train)
    log_model(model)
    log_classification_report(y_test, y_pred)
    log_confusion_matrix(y_test, y_pred)
    log_feature_importance(model, feature_names=["f1", "f2", "f3"])

Requires: ``pip install openrunner[sklearn]``
"""

from __future__ import annotations

from typing import Any, Sequence

try:
    import sklearn  # noqa: F401
except ImportError:
    raise ImportError(
        "Scikit-learn integration requires scikit-learn. "
        "Install with: pip install openrunner[sklearn]"
    )

import openrunner


def log_model(model: Any, name: str | None = None) -> None:
    """Log model hyperparameters via ``get_params()``.

    Logs all parameters returned by the model's ``get_params()`` method
    into the run config under ``model/`` prefix.

    Args:
        model: A fitted scikit-learn estimator.
        name: Optional model name stored in config.
    """
    if openrunner._active_run is None:
        return

    params = model.get_params()
    prefixed = {f"model/{k}": v for k, v in params.items() if _is_loggable(v)}
    if name:
        prefixed["model/name"] = name
    prefixed["model/class"] = type(model).__name__
    if prefixed:
        openrunner.config.update(prefixed)


def log_classification_report(
    y_true: Sequence,
    y_pred: Sequence,
    labels: Sequence | None = None,
    target_names: Sequence[str] | None = None,
) -> None:
    """Log a classification report as a Table.

    Uses ``sklearn.metrics.classification_report`` to compute precision,
    recall, f1-score and support, then logs the result as an
    ``openrunner.Table``.

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted labels.
        labels: Optional list of label indices to include.
        target_names: Optional display names for each label.
    """
    if openrunner._active_run is None:
        return

    from sklearn.metrics import classification_report as _cr

    report = _cr(
        y_true,
        y_pred,
        labels=labels,
        target_names=target_names,
        output_dict=True,
    )

    columns = ["class", "precision", "recall", "f1-score", "support"]
    data: list[list[Any]] = []
    for cls_name, metrics in report.items():
        if isinstance(metrics, dict):
            data.append([
                cls_name,
                round(metrics.get("precision", 0), 4),
                round(metrics.get("recall", 0), 4),
                round(metrics.get("f1-score", 0), 4),
                metrics.get("support", 0),
            ])
        else:
            # scalar like "accuracy"
            data.append([cls_name, metrics, None, None, None])

    table = openrunner.Table(columns=columns, data=data)
    openrunner.log({"classification_report": table})


def log_confusion_matrix(
    y_true: Sequence,
    y_pred: Sequence,
    labels: Sequence | None = None,
    class_names: Sequence[str] | None = None,
) -> None:
    """Log a confusion matrix as an Image (matplotlib heatmap).

    Generates a heatmap using ``matplotlib`` and logs it as an
    ``openrunner.Image``.

    Args:
        y_true: Ground-truth labels.
        y_pred: Predicted labels.
        labels: Optional list of label values for ordering.
        class_names: Optional display names for the axes.
    """
    if openrunner._active_run is None:
        return

    from sklearn.metrics import confusion_matrix as _cm

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "log_confusion_matrix requires matplotlib. "
            "Install with: pip install matplotlib"
        )

    cm = _cm(y_true, y_pred, labels=labels)

    fig, ax = plt.subplots(figsize=(6, 5))
    im = ax.imshow(cm, interpolation="nearest", cmap="Blues")
    fig.colorbar(im, ax=ax)

    if class_names is not None:
        tick_marks = list(range(len(class_names)))
        ax.set_xticks(tick_marks)
        ax.set_xticklabels(class_names, rotation=45, ha="right")
        ax.set_yticks(tick_marks)
        ax.set_yticklabels(class_names)

    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
    ax.set_title("Confusion Matrix")
    fig.tight_layout()

    openrunner.log({"confusion_matrix": openrunner.Image(fig)})
    plt.close(fig)


def log_feature_importance(
    model: Any,
    feature_names: Sequence[str] | None = None,
) -> None:
    """Log feature importances as a Table.

    Extracts ``feature_importances_`` from the model and logs them
    as a sorted ``openrunner.Table`` (most important first).

    Args:
        model: A fitted scikit-learn estimator with
            ``feature_importances_`` attribute.
        feature_names: Optional list of feature names. If not
            provided, uses ``feature_0``, ``feature_1``, etc.
    """
    if openrunner._active_run is None:
        return

    if not hasattr(model, "feature_importances_"):
        return

    importances = model.feature_importances_
    if feature_names is None:
        feature_names = [f"feature_{i}" for i in range(len(importances))]

    # Sort by importance descending
    pairs = sorted(
        zip(feature_names, importances),
        key=lambda x: x[1],
        reverse=True,
    )

    columns = ["feature", "importance"]
    data = [[name, round(float(imp), 6)] for name, imp in pairs]

    table = openrunner.Table(columns=columns, data=data)
    openrunner.log({"feature_importance": table})


def log_learning_curve(
    model: Any,
    X: Any,
    y: Any,
    cv: int = 5,
    scoring: str = "accuracy",
) -> None:
    """Log a learning curve as an Image.

    Uses ``sklearn.model_selection.learning_curve`` and plots train/val
    scores vs training set size.

    Args:
        model: A scikit-learn estimator.
        X: Training features.
        y: Training labels.
        cv: Number of cross-validation folds.
        scoring: Scoring metric name.
    """
    if openrunner._active_run is None:
        return

    from sklearn.model_selection import learning_curve as _lc

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "log_learning_curve requires matplotlib. "
            "Install with: pip install matplotlib"
        )

    import numpy as np

    train_sizes, train_scores, val_scores = _lc(
        model, X, y, cv=cv, scoring=scoring,
        train_sizes=np.linspace(0.1, 1.0, 8),
    )

    fig, ax = plt.subplots(figsize=(6, 4))
    ax.plot(train_sizes, train_scores.mean(axis=1), "o-", label="Train")
    ax.fill_between(
        train_sizes,
        train_scores.mean(axis=1) - train_scores.std(axis=1),
        train_scores.mean(axis=1) + train_scores.std(axis=1),
        alpha=0.15,
    )
    ax.plot(train_sizes, val_scores.mean(axis=1), "o-", label="Validation")
    ax.fill_between(
        train_sizes,
        val_scores.mean(axis=1) - val_scores.std(axis=1),
        val_scores.mean(axis=1) + val_scores.std(axis=1),
        alpha=0.15,
    )
    ax.set_xlabel("Training Set Size")
    ax.set_ylabel(scoring.capitalize())
    ax.set_title("Learning Curve")
    ax.legend(loc="best")
    fig.tight_layout()

    openrunner.log({"learning_curve": openrunner.Image(fig)})
    plt.close(fig)


def log_roc(
    y_true: Sequence,
    y_probas: Any,
    labels: Sequence[str] | None = None,
) -> None:
    """Log ROC curves as an Image.

    Computes per-class ROC curves using one-vs-rest strategy and
    logs the plot as an ``openrunner.Image``.

    Args:
        y_true: Ground-truth labels.
        y_probas: Predicted probabilities (shape: n_samples x n_classes).
        labels: Optional class names for the legend.
    """
    if openrunner._active_run is None:
        return

    from sklearn.metrics import roc_curve, auc
    from sklearn.preprocessing import label_binarize

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "log_roc requires matplotlib. Install with: pip install matplotlib"
        )

    import numpy as np

    classes = np.unique(y_true)
    n_classes = len(classes)

    if n_classes == 2:
        # Binary classification
        fpr, tpr, _ = roc_curve(y_true, y_probas[:, 1] if y_probas.ndim > 1 else y_probas)
        roc_auc = auc(fpr, tpr)
        fig, ax = plt.subplots(figsize=(6, 5))
        label_name = labels[1] if labels and len(labels) > 1 else "Positive"
        ax.plot(fpr, tpr, label=f"{label_name} (AUC={roc_auc:.3f})")
    else:
        # Multi-class: one-vs-rest
        y_bin = label_binarize(y_true, classes=classes)
        fig, ax = plt.subplots(figsize=(6, 5))
        for i in range(n_classes):
            fpr, tpr, _ = roc_curve(y_bin[:, i], y_probas[:, i])
            roc_auc = auc(fpr, tpr)
            name = labels[i] if labels and i < len(labels) else str(classes[i])
            ax.plot(fpr, tpr, label=f"{name} (AUC={roc_auc:.3f})")

    ax.plot([0, 1], [0, 1], "k--", alpha=0.3)
    ax.set_xlabel("False Positive Rate")
    ax.set_ylabel("True Positive Rate")
    ax.set_title("ROC Curve")
    ax.legend(loc="lower right", fontsize=9)
    fig.tight_layout()

    openrunner.log({"roc_curve": openrunner.Image(fig)})
    plt.close(fig)


def log_precision_recall(
    y_true: Sequence,
    y_probas: Any,
    labels: Sequence[str] | None = None,
) -> None:
    """Log precision-recall curves as an Image.

    Args:
        y_true: Ground-truth labels.
        y_probas: Predicted probabilities (shape: n_samples x n_classes).
        labels: Optional class names for the legend.
    """
    if openrunner._active_run is None:
        return

    from sklearn.metrics import precision_recall_curve, average_precision_score
    from sklearn.preprocessing import label_binarize

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
    except ImportError:
        raise ImportError(
            "log_precision_recall requires matplotlib. "
            "Install with: pip install matplotlib"
        )

    import numpy as np

    classes = np.unique(y_true)
    n_classes = len(classes)

    fig, ax = plt.subplots(figsize=(6, 5))

    if n_classes == 2:
        probs = y_probas[:, 1] if y_probas.ndim > 1 else y_probas
        precision, recall, _ = precision_recall_curve(y_true, probs)
        ap = average_precision_score(y_true, probs)
        name = labels[1] if labels and len(labels) > 1 else "Positive"
        ax.plot(recall, precision, label=f"{name} (AP={ap:.3f})")
    else:
        y_bin = label_binarize(y_true, classes=classes)
        for i in range(n_classes):
            precision, recall, _ = precision_recall_curve(y_bin[:, i], y_probas[:, i])
            ap = average_precision_score(y_bin[:, i], y_probas[:, i])
            name = labels[i] if labels and i < len(labels) else str(classes[i])
            ax.plot(recall, precision, label=f"{name} (AP={ap:.3f})")

    ax.set_xlabel("Recall")
    ax.set_ylabel("Precision")
    ax.set_title("Precision-Recall Curve")
    ax.legend(loc="best", fontsize=9)
    fig.tight_layout()

    openrunner.log({"precision_recall": openrunner.Image(fig)})
    plt.close(fig)


def log_class_proportions(
    y_train: Sequence,
    y_test: Sequence,
    labels: Sequence[str] | None = None,
) -> None:
    """Log class distribution as a Table.

    Args:
        y_train: Training labels.
        y_test: Test labels.
        labels: Optional class names.
    """
    if openrunner._active_run is None:
        return

    import numpy as np

    classes = np.unique(np.concatenate([y_train, y_test]))
    columns = ["class", "train_count", "test_count", "train_%", "test_%"]
    data = []
    for i, cls in enumerate(classes):
        name = labels[i] if labels and i < len(labels) else str(cls)
        train_ct = int(np.sum(np.array(y_train) == cls))
        test_ct = int(np.sum(np.array(y_test) == cls))
        data.append([
            name,
            train_ct,
            test_ct,
            round(train_ct / len(y_train) * 100, 1),
            round(test_ct / len(y_test) * 100, 1),
        ])

    table = openrunner.Table(columns=columns, data=data)
    openrunner.log({"class_proportions": table})


def _is_loggable(value: Any) -> bool:
    """Check if a value can be logged as a metric (numeric or string)."""
    return isinstance(value, (int, float, str, bool))
