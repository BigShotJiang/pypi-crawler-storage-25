"""Ultralytics YOLO integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- a collection of static callback
methods for YOLO training that log metrics to OpenRunner.

Usage::

    from ultralytics import YOLO
    from openrunner.integration.ultralytics import OpenRunnerCallback

    model = YOLO("yolov8n.pt")
    model.add_callback("on_pretrain_routine_start",
                        OpenRunnerCallback.on_pretrain_routine_start)
    model.add_callback("on_train_epoch_end",
                        OpenRunnerCallback.on_train_epoch_end)
    model.add_callback("on_fit_epoch_end",
                        OpenRunnerCallback.on_fit_epoch_end)
    model.add_callback("on_train_end", OpenRunnerCallback.on_train_end)
    model.train(data="coco8.yaml", epochs=10)

Requires: ``pip install openrunner[ultralytics]``
"""

from __future__ import annotations

from typing import Any

import openrunner


class OpenRunnerCallback:
    """Ultralytics YOLO callbacks for OpenRunner logging.

    All methods are static and designed to be registered individually
    via ``model.add_callback(event_name, method)``.

    * **on_pretrain_routine_start** -- initialises a run with training args.
    * **on_train_epoch_end** -- logs training losses (box, cls, dfl).
    * **on_fit_epoch_end** -- logs validation metrics and fitness.
    * **on_train_end** -- logs best fitness and finishes the run.
    """

    _initialized = False

    @staticmethod
    def on_pretrain_routine_start(trainer: Any) -> None:
        """Initialize OpenRunner run at the start of training."""
        if openrunner._active_run is None:
            config: dict[str, Any] = {}
            if hasattr(trainer, "args"):
                args = trainer.args
                for attr in [
                    "epochs",
                    "batch",
                    "imgsz",
                    "lr0",
                    "lrf",
                    "momentum",
                    "weight_decay",
                    "warmup_epochs",
                    "model",
                    "data",
                    "device",
                ]:
                    val = getattr(args, attr, None)
                    if val is not None:
                        config[attr] = val
            openrunner.init(config=config)
            OpenRunnerCallback._initialized = True

    @staticmethod
    def on_train_epoch_end(trainer: Any) -> None:
        """Log training metrics at end of each epoch."""
        if openrunner._active_run is None:
            return

        metrics: dict[str, float] = {}
        if hasattr(trainer, "loss_items") and trainer.loss_items is not None:
            loss_names = ["box_loss", "cls_loss", "dfl_loss"]
            for i, name in enumerate(loss_names):
                try:
                    metrics[f"train/{name}"] = float(trainer.loss_items[i])
                except (IndexError, TypeError):
                    pass

        if hasattr(trainer, "epoch"):
            metrics["epoch"] = float(trainer.epoch)

        if metrics:
            openrunner.log(metrics, step=getattr(trainer, "epoch", 0))

    @staticmethod
    def on_fit_epoch_end(trainer: Any) -> None:
        """Log validation metrics at end of each fit epoch."""
        if openrunner._active_run is None:
            return

        metrics: dict[str, float] = {}
        if hasattr(trainer, "metrics") and trainer.metrics:
            for k, v in trainer.metrics.items():
                if isinstance(v, (int, float)):
                    metrics[f"val/{k}"] = float(v)

        if hasattr(trainer, "fitness") and trainer.fitness is not None:
            metrics["val/fitness"] = float(trainer.fitness)

        if metrics:
            openrunner.log(metrics, step=getattr(trainer, "epoch", 0))

    @staticmethod
    def on_train_end(trainer: Any) -> None:
        """Finish the run at end of training."""
        if OpenRunnerCallback._initialized:
            # Log final metrics to summary
            if (
                hasattr(trainer, "best_fitness")
                and trainer.best_fitness is not None
            ):
                openrunner.summary["best_fitness"] = float(
                    trainer.best_fitness
                )
            openrunner.finish()
            OpenRunnerCallback._initialized = False
