# Integration modules for popular ML frameworks.
# Each module must be imported explicitly -- no framework code is imported here.
#
# Available integrations:
#   openrunner.integration.pytorch      - PyTorch gradient logging + watch()
#   openrunner.integration.huggingface  - HuggingFace Transformers TrainerCallback
#   openrunner.integration.lightning    - PyTorch Lightning Logger
#   openrunner.integration.keras        - Keras / TensorFlow Callback
#   openrunner.integration.tensorflow   - TensorFlow 2.x / tf.keras
#   openrunner.integration.xgboost      - XGBoost TrainingCallback
#   openrunner.integration.catboost     - CatBoost callback
#   openrunner.integration.lightgbm     - LightGBM callback
#   openrunner.integration.sklearn      - Scikit-learn utility functions
#   openrunner.integration.fastai       - FastAI Callback
#   openrunner.integration.jax          - JAX/Flax utilities
#   openrunner.integration.langchain    - LangChain CallbackHandler
#   openrunner.integration.optuna       - Optuna hyperparameter optimization
#   openrunner.integration.ultralytics  - Ultralytics YOLO training
#   openrunner.integration.sb3          - Stable Baselines 3 RL training
#   openrunner.integration.openai_tracer - OpenAI SDK monkey-patch tracer
#   openrunner.integration.anthropic_tracer - Anthropic SDK monkey-patch tracer
#   openrunner.integration.llamaindex   - LlamaIndex CallbackHandler
#   openrunner.integration.hydra        - Hydra config management callback
#   openrunner.integration.trl          - Hugging Face TRL (RLHF/DPO/SFT) callback
#   openrunner.integration.whisper      - OpenAI Whisper STT transcription logging
#   openrunner.integration.tts          - TTS model training and evaluation
#   openrunner.integration.voice_agent  - Voice AI agent conversation tracing
#   openrunner.integration.accelerate      - HuggingFace Accelerate tracker
#   openrunner.integration.diffusers       - HuggingFace Diffusers auto-logging
#   openrunner.integration.openai_finetune - OpenAI fine-tuning sync
#   openrunner.integration.forced_alignment - Forced alignment logging
#   openrunner.integration.ignite          - PyTorch Ignite event-based logging
#   openrunner.integration.gymnasium       - Gymnasium (OpenAI Gym) RL monitoring
