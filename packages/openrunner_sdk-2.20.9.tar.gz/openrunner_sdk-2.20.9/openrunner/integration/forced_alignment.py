"""Forced alignment integration for OpenRunner.

Tracks forced alignment model training and evaluation.

Usage::

    from openrunner.integration.forced_alignment import log_alignment

    log_alignment(
        audio_path="speech.wav",
        text="hello world",
        alignments=[
            {"word": "hello", "start": 0.1, "end": 0.5},
            {"word": "world", "start": 0.6, "end": 1.0},
        ],
        metrics={"boundary_f1": 0.95, "phone_error_rate": 0.03},
    )
"""

from __future__ import annotations

from typing import Any

import openrunner
from openrunner.media import Audio, SpectrogramImage, Table, Transcript


def log_alignment(
    audio_path: str | None = None,
    audio_array: Any = None,
    sample_rate: int = 16000,
    text: str | None = None,
    alignments: list[dict[str, Any]] | None = None,
    phone_alignments: list[dict[str, Any]] | None = None,
    metrics: dict[str, Any] | None = None,
    spectrogram: Any = None,
    key: str = "alignment",
    step: int | None = None,
) -> None:
    """Log a forced alignment result.

    Args:
        audio_path: Path to audio file.
        audio_array: Or numpy array.
        sample_rate: Audio sample rate.
        text: Full text transcript.
        alignments: Word-level alignments
            ``[{word, start, end, confidence?}]``.
        phone_alignments: Phone-level alignments
            ``[{phone, start, end}]``.
        metrics: Evaluation metrics dict.
        spectrogram: Optional mel spectrogram array.
        key: Metric key prefix.
        step: Step number.
    """
    if openrunner._active_run is None:
        return

    # Log audio
    if audio_path:
        openrunner.log(
            {f"{key}/audio": Audio(audio_path)}, step=step, commit=False,
        )
    elif audio_array is not None:
        openrunner.log(
            {f"{key}/audio": Audio(audio_array, sample_rate=sample_rate)},
            step=step, commit=False,
        )

    # Log as transcript with segments
    if text and alignments:
        segments = [
            {
                "start": a["start"],
                "end": a["end"],
                "text": a["word"],
                "confidence": a.get("confidence"),
            }
            for a in alignments
        ]
        t = Transcript(text=text, segments=segments)
        openrunner.log({f"{key}/transcript": t}, step=step, commit=False)

    # Log word alignment table
    if alignments:
        cols = ["word", "start", "end", "duration"]
        has_confidence = any("confidence" in a for a in alignments)
        if has_confidence:
            cols.append("confidence")
        data = []
        for a in alignments:
            row: list[Any] = [
                a["word"],
                round(a["start"], 3),
                round(a["end"], 3),
                round(a["end"] - a["start"], 3),
            ]
            if has_confidence:
                row.append(a.get("confidence"))
            data.append(row)
        openrunner.log(
            {f"{key}/word_table": Table(columns=cols, data=data)},
            step=step, commit=False,
        )

    # Log phone alignments
    if phone_alignments:
        phone_cols = ["phone", "start", "end", "duration"]
        phone_data = [
            [
                p["phone"],
                round(p["start"], 3),
                round(p["end"], 3),
                round(p["end"] - p["start"], 3),
            ]
            for p in phone_alignments
        ]
        openrunner.log(
            {f"{key}/phone_table": Table(columns=phone_cols, data=phone_data)},
            step=step, commit=False,
        )

    # Log spectrogram
    if spectrogram is not None:
        spec = SpectrogramImage(
            spectrogram, sample_rate=sample_rate, caption=text,
        )
        openrunner.log(
            {f"{key}/spectrogram": spec}, step=step, commit=False,
        )

    # Log metrics
    if metrics:
        prefixed = {
            f"{key}/{k}": v
            for k, v in metrics.items()
            if isinstance(v, (int, float))
        }
        openrunner.log(prefixed, step=step, commit=False)

    openrunner.log({}, step=step, commit=True)
