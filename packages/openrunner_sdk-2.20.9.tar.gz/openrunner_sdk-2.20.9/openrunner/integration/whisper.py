"""OpenAI Whisper integration for OpenRunner.

Auto-logs transcription results with word timestamps.

Usage::

    from openrunner.integration.whisper import log_transcription

    result = model.transcribe("audio.wav")
    log_transcription(result, audio_path="audio.wav")
"""

from __future__ import annotations

from typing import Any

import openrunner
from openrunner.media import Audio, Transcript


def log_transcription(
    result: dict[str, Any],
    audio_path: str | None = None,
    key: str = "transcription",
    step: int | None = None,
) -> None:
    """Log a Whisper transcription result.

    Args:
        result: Whisper result dict with ``text``, ``segments``, ``language``.
        audio_path: Optional path to the source audio file.
        key: Metric key name.
        step: Optional step number.
    """
    segments: list[dict[str, Any]] = []
    for seg in result.get("segments", []):
        segments.append({
            "start": seg.get("start", 0),
            "end": seg.get("end", 0),
            "text": seg.get("text", ""),
            "confidence": seg.get("avg_logprob", None),
        })

    audio = Audio(audio_path) if audio_path else None

    transcript = Transcript(
        text=result.get("text", ""),
        segments=segments,
        language=result.get("language"),
        audio=audio,
    )

    openrunner.log({key: transcript}, step=step)

    # Also log scalar metrics
    metrics: dict[str, float] = {}
    if "language" in result:
        # Language is a string -- log as metadata, not a metric
        pass
    if segments:
        confidences = [s.get("confidence", 0) or 0 for s in segments]
        avg_conf = sum(confidences) / len(confidences)
        metrics[f"{key}/avg_confidence"] = avg_conf
        metrics[f"{key}/num_segments"] = float(len(segments))
        if segments[-1].get("end", 0):
            metrics[f"{key}/duration"] = segments[-1]["end"]
    if metrics:
        openrunner.log(metrics, step=step, commit=False)


class WhisperCallback:
    """Callback for tracking Whisper model fine-tuning.

    Logs evaluation metrics and sample transcriptions at each eval step.

    Usage::

        cb = WhisperCallback(project="whisper-finetune")
        cb.on_evaluate(metrics, samples=samples, step=100)
    """

    def __init__(
        self,
        project: str | None = None,
        log_audio_samples: bool = True,
        max_samples: int = 5,
    ) -> None:
        self._project = project
        self._log_audio_samples = log_audio_samples
        self._max_samples = max_samples

    def on_evaluate(
        self,
        metrics: dict[str, Any],
        samples: list[dict[str, Any]] | None = None,
        step: int | None = None,
    ) -> None:
        """Log evaluation metrics and sample transcriptions.

        Args:
            metrics: Dict of eval metrics (WER, CER, etc.).
            samples: List of dicts with ``text``, ``segments``,
                and optionally ``audio_path`` keys.
            step: Current training step.
        """
        if openrunner._active_run is None:
            openrunner.init(project=self._project)

        openrunner.log(metrics, step=step)

        if self._log_audio_samples and samples:
            for i, sample in enumerate(samples[: self._max_samples]):
                if "text" in sample:
                    log_transcription(
                        {
                            "text": sample["text"],
                            "segments": sample.get("segments", []),
                        },
                        audio_path=sample.get("audio_path"),
                        key=f"eval_sample_{i}",
                        step=step,
                    )
