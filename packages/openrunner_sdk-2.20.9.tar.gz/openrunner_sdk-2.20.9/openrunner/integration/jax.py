"""JAX/Flax integration for OpenRunner.

Provides utilities for logging JAX training metrics.  Handles
conversion of JAX arrays and NumPy arrays to Python floats
automatically.

Usage::

    from openrunner.integration.jax import TrainStateLogger

    logger = TrainStateLogger(project="my-project")
    for step in range(num_steps):
        state, metrics = train_step(state, batch)
        logger.log(metrics, step=step)
    logger.finish()

Requires: ``pip install openrunner[jax]``
"""

from __future__ import annotations

from typing import Any

import openrunner


def log_metrics(
    metrics: dict[str, Any],
    step: int | None = None,
    prefix: str = "",
) -> None:
    """Log a JAX metrics dict to OpenRunner.

    Converts JAX arrays, NumPy arrays, and other numeric types to
    Python floats.  NaN values are silently skipped.

    Args:
        metrics: Dict of metric values (can be JAX arrays).
        step: Training step.
        prefix: Optional prefix for metric keys.
    """
    converted: dict[str, float] = {}
    for k, v in metrics.items():
        key = f"{prefix}{k}" if prefix else k
        try:
            # Handle JAX arrays, numpy arrays, etc.
            val = float(v)
            if not (val != val):  # skip NaN
                converted[key] = val
        except (TypeError, ValueError):
            pass

    if converted:
        openrunner.log(converted, step=step)


class TrainStateLogger:
    """Wrapper for logging Flax TrainState metrics.

    Initialises an OpenRunner run on construction and provides a
    simple ``log`` / ``finish`` interface for JAX training loops.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        kwargs: dict[str, Any] = {}
        if project:
            kwargs["project"] = project
        if config:
            kwargs["config"] = config
        self._run = openrunner.init(**kwargs)

    def log(
        self,
        metrics: dict[str, Any],
        step: int | None = None,
        prefix: str = "",
    ) -> None:
        """Log metrics for the current step.

        Args:
            metrics: Dict of metric values.
            step: Training step.
            prefix: Optional prefix for metric keys.
        """
        log_metrics(metrics, step=step, prefix=prefix)

    def finish(self) -> None:
        """Finish the active run."""
        openrunner.finish()
