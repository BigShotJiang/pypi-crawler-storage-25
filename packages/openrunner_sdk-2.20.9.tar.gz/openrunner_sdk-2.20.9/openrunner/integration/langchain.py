"""LangChain integration for OpenRunner.

Provides ``OpenRunnerCallbackHandler`` -- a LangChain
``BaseCallbackHandler`` that logs LLM calls (prompts, responses,
token counts, latency), chain executions, and tool invocations
to an active OpenRunner run.

Usage::

    from openrunner.integration.langchain import OpenRunnerCallbackHandler

    handler = OpenRunnerCallbackHandler()
    llm = ChatOpenAI(callbacks=[handler])
    chain = prompt | llm
    chain.invoke({"input": "Hello"})

Requires: ``pip install openrunner[langchain]``
"""

from __future__ import annotations

import time
from typing import Any
from uuid import UUID

try:
    from langchain_core.callbacks import BaseCallbackHandler
except ImportError:
    try:
        from langchain.callbacks.base import BaseCallbackHandler
    except ImportError:
        raise ImportError(
            "LangChain integration requires langchain-core or langchain. "
            "Install with: pip install openrunner[langchain]"
        )

import openrunner


class OpenRunnerCallbackHandler(BaseCallbackHandler):
    """LangChain ``BaseCallbackHandler`` that logs to OpenRunner.

    Tracks:
    - **LLM calls**: prompt, response text, token usage, latency
    - **Chain executions**: chain type, inputs/outputs
    - **Tool calls**: tool name, input, output

    All metrics are logged with a ``langchain/`` prefix. A running
    counter tracks the total number of LLM calls, chain runs, and
    tool invocations.
    """

    def __init__(self) -> None:
        super().__init__()
        self._llm_call_count: int = 0
        self._chain_call_count: int = 0
        self._tool_call_count: int = 0
        self._llm_start_times: dict[str, float] = {}
        self._chain_start_times: dict[str, float] = {}
        self._tool_start_times: dict[str, float] = {}

    # -- LLM callbacks -------------------------------------------------------

    def on_llm_start(
        self,
        serialized: dict[str, Any],
        prompts: list[str],
        *,
        run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Log the prompt when an LLM call starts."""
        if openrunner._active_run is None:
            return

        self._llm_call_count += 1
        run_key = str(run_id) if run_id else str(self._llm_call_count)
        self._llm_start_times[run_key] = time.monotonic()

        # Log prompt (first prompt only for brevity)
        metrics: dict[str, Any] = {
            "langchain/llm_calls": self._llm_call_count,
        }
        openrunner.log(metrics, commit=False)

    def on_llm_end(
        self,
        response: Any,
        *,
        run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Log response, token usage, and latency when an LLM call ends."""
        if openrunner._active_run is None:
            return

        run_key = str(run_id) if run_id else str(self._llm_call_count)
        metrics: dict[str, Any] = {}

        # Latency
        start_time = self._llm_start_times.pop(run_key, None)
        if start_time is not None:
            latency = time.monotonic() - start_time
            metrics["langchain/llm_latency_s"] = round(latency, 4)

        # Token usage from llm_output
        if hasattr(response, "llm_output") and response.llm_output:
            llm_output = response.llm_output
            token_usage = llm_output.get("token_usage", {})
            if token_usage:
                if "prompt_tokens" in token_usage:
                    metrics["langchain/prompt_tokens"] = token_usage["prompt_tokens"]
                if "completion_tokens" in token_usage:
                    metrics["langchain/completion_tokens"] = token_usage["completion_tokens"]
                if "total_tokens" in token_usage:
                    metrics["langchain/total_tokens"] = token_usage["total_tokens"]

        if metrics:
            openrunner.log(metrics)

    # -- Chain callbacks ------------------------------------------------------

    def on_chain_start(
        self,
        serialized: dict[str, Any],
        inputs: dict[str, Any],
        *,
        run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Log chain start information."""
        if openrunner._active_run is None:
            return

        self._chain_call_count += 1
        run_key = str(run_id) if run_id else str(self._chain_call_count)
        self._chain_start_times[run_key] = time.monotonic()

        metrics: dict[str, Any] = {
            "langchain/chain_calls": self._chain_call_count,
        }
        openrunner.log(metrics, commit=False)

    def on_chain_end(
        self,
        outputs: dict[str, Any],
        *,
        run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Log chain completion with latency."""
        if openrunner._active_run is None:
            return

        run_key = str(run_id) if run_id else str(self._chain_call_count)
        metrics: dict[str, Any] = {}

        start_time = self._chain_start_times.pop(run_key, None)
        if start_time is not None:
            latency = time.monotonic() - start_time
            metrics["langchain/chain_latency_s"] = round(latency, 4)

        if metrics:
            openrunner.log(metrics)

    # -- Tool callbacks -------------------------------------------------------

    def on_tool_start(
        self,
        serialized: dict[str, Any],
        input_str: str,
        *,
        run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Log tool invocation start."""
        if openrunner._active_run is None:
            return

        self._tool_call_count += 1
        run_key = str(run_id) if run_id else str(self._tool_call_count)
        self._tool_start_times[run_key] = time.monotonic()

        metrics: dict[str, Any] = {
            "langchain/tool_calls": self._tool_call_count,
        }
        openrunner.log(metrics, commit=False)

    def on_tool_end(
        self,
        output: str,
        *,
        run_id: UUID | None = None,
        **kwargs: Any,
    ) -> None:
        """Log tool completion with latency."""
        if openrunner._active_run is None:
            return

        run_key = str(run_id) if run_id else str(self._tool_call_count)
        metrics: dict[str, Any] = {}

        start_time = self._tool_start_times.pop(run_key, None)
        if start_time is not None:
            latency = time.monotonic() - start_time
            metrics["langchain/tool_latency_s"] = round(latency, 4)

        if metrics:
            openrunner.log(metrics)
