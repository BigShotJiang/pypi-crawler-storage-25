"""HuggingFace Transformers integration for OpenRunner.

Provides ``OpenRunnerCallback`` -- a ``TrainerCallback`` that automatically
initialises an OpenRunner run at the start of training, logs metrics on
every ``on_log`` event, and finishes the run when training ends.

Usage::

    from openrunner.integration.huggingface import OpenRunnerCallback

    trainer = Trainer(
        model=model,
        args=training_args,
        callbacks=[OpenRunnerCallback()],
    )
    trainer.train()

Requires: ``pip install openrunner[huggingface]``
"""

from __future__ import annotations

try:
    from transformers import (  # noqa: F401
        TrainerCallback,
        TrainerControl,
        TrainerState,
        TrainingArguments,
    )
except ImportError:
    raise ImportError(
        "HuggingFace integration requires transformers. "
        "Install with: pip install openrunner[huggingface]"
    )

import openrunner


class OpenRunnerCallback(TrainerCallback):
    """HuggingFace ``TrainerCallback`` that logs to OpenRunner.

    * **on_train_begin** -- initialises a run (if none active) with the
      training arguments as config.
    * **on_log** -- forwards numeric metrics to ``openrunner.log()``.
    * **on_train_end** -- calls ``openrunner.finish()``.
    """

    def on_train_begin(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs,
    ) -> None:
        """Start a new run if one isn't already active.

        If the user has already called ``openrunner.init()``, merges
        training args into the existing config instead of creating
        a new run.
        """
        if openrunner._active_run is None:
            openrunner.init(config=args.to_dict())
        else:
            # Merge trainer args into existing run config
            openrunner.config.update(args.to_dict())

    def on_log(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        logs: dict | None = None,
        **kwargs,
    ) -> None:
        """Log numeric metrics from the trainer."""
        if logs and openrunner._active_run is not None:
            metrics = {
                k: v for k, v in logs.items() if isinstance(v, (int, float))
            }
            if metrics:
                openrunner.log(metrics, step=state.global_step)

    def on_train_end(
        self,
        args: TrainingArguments,
        state: TrainerState,
        control: TrainerControl,
        **kwargs,
    ) -> None:
        """Finish the active run."""
        openrunner.finish()
