"""TensorFlow/Keras integration for OpenRunner.

Provides ``OpenRunnerCallback`` for ``tf.keras`` training loops.  Also
works with standalone TensorFlow 2.x training loops.

Unlike the ``keras`` integration (which targets standalone Keras 3.x),
this module imports directly from ``tensorflow.keras`` and is intended
for codebases that use the TensorFlow-bundled Keras API.

Usage::

    from openrunner.integration.tensorflow import OpenRunnerCallback

    model.fit(
        x_train, y_train,
        callbacks=[OpenRunnerCallback()],
    )

Requires: ``pip install openrunner[tensorflow]``
"""

from __future__ import annotations

from typing import Any

try:
    import tensorflow as tf  # noqa: F401
    from tensorflow.keras.callbacks import Callback as _TFCallback
except ImportError:
    raise ImportError(
        "TensorFlow integration requires tensorflow. "
        "Install with: pip install openrunner[tensorflow]"
    )

import openrunner


class OpenRunnerCallback(_TFCallback):
    """TensorFlow/Keras callback that logs to OpenRunner.

    * **on_train_begin** -- initialises a run if none is active.
    * **on_epoch_end** -- logs loss and all metrics from the ``logs`` dict.
    * **on_train_end** -- calls ``openrunner.finish()``.

    Also captures the current learning rate if available in the
    optimizer.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.
    """

    def __init__(
        self,
        project: str | None = None,
        config: dict[str, Any] | None = None,
    ) -> None:
        super().__init__()
        self._project = project
        self._config = config

    def on_train_begin(self, logs: dict | None = None) -> None:
        """Start a new run if one isn't already active."""
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if self._project:
                kwargs["project"] = self._project
            if self._config:
                kwargs["config"] = self._config
            openrunner.init(**kwargs)

    def on_epoch_end(self, epoch: int, logs: dict | None = None) -> None:
        """Log numeric metrics at the end of each epoch."""
        if logs and openrunner._active_run is not None:
            metrics = {
                k: float(v)
                for k, v in logs.items()
                if isinstance(v, (int, float))
            }
            if metrics:
                openrunner.log(metrics, step=epoch)

    def on_train_end(self, logs: dict | None = None) -> None:
        """Finish the active run."""
        openrunner.finish()


def log_model(model: Any, name: str = "tf-model") -> None:
    """Log a TensorFlow SavedModel as an artifact.

    Saves the model to a temporary directory using ``model.save()``
    and uploads it as an OpenRunner artifact.

    Args:
        model: A ``tf.keras.Model`` or ``tf.Module`` with a ``save``
            method.
        name: Artifact name.  Defaults to ``"tf-model"``.
    """
    import os
    import tempfile

    if openrunner._active_run is None:
        return

    with tempfile.TemporaryDirectory() as tmpdir:
        save_path = os.path.join(tmpdir, name)
        model.save(save_path)
        artifact = openrunner.Artifact(name=name, type="model")
        artifact.add_dir(save_path)
        openrunner._active_run.log_artifact(artifact)
