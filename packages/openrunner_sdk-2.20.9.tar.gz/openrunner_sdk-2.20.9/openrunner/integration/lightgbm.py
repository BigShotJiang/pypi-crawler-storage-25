"""LightGBM integration for OpenRunner.

Provides ``openrunner_callback`` -- a factory function that returns a
LightGBM-compatible callback for logging evaluation metrics.

Usage::

    from openrunner.integration.lightgbm import openrunner_callback

    lgb.train(
        params, dtrain,
        valid_sets=[dtest],
        callbacks=[openrunner_callback()],
    )

Requires: ``pip install openrunner[lightgbm]``
"""

from __future__ import annotations

from typing import Any, Callable

try:
    import lightgbm as lgb  # noqa: F401
except ImportError:
    raise ImportError(
        "LightGBM integration requires lightgbm. "
        "Install with: pip install openrunner[lightgbm]"
    )

import openrunner


def openrunner_callback(
    project: str | None = None,
    config: dict[str, Any] | None = None,
) -> Callable:
    """Create a LightGBM callback function for logging metrics.

    The returned callback initialises an OpenRunner run if none is
    active and logs evaluation metrics (dataset/metric pairs) after
    each boosting iteration.

    Args:
        project: Project name passed to ``openrunner.init()``.
        config: Optional config dict passed to ``openrunner.init()``.

    Returns:
        A LightGBM-compatible callback function.
    """

    def _callback(env: Any) -> None:
        if openrunner._active_run is None:
            kwargs: dict[str, Any] = {}
            if project:
                kwargs["project"] = project
            if config:
                kwargs["config"] = config
            openrunner.init(**kwargs)

        metrics: dict[str, float] = {}
        if env.evaluation_result_list:
            for dataset_name, metric_name, value, _is_higher_better in (
                env.evaluation_result_list
            ):
                metrics[f"{dataset_name}/{metric_name}"] = float(value)

        if metrics:
            openrunner.log(metrics, step=env.iteration)

    _callback.order = 10  # run after other callbacks
    return _callback
