"""Client-side guardrail checks for OpenRunner.

Provides local guardrail evaluation that mirrors the server-side
guardrail scorers. Users can add guardrails and check text locally
before sending to the LLM, or verify LLM outputs post-hoc.

Usage::

    from openrunner.guardrails import add_guardrail, check_guardrails

    # Add guardrails
    add_guardrail("no_pii", scorer="pii_check", threshold=0.5, action="block")
    add_guardrail("length", scorer="length_limit", threshold=0.5,
                  action="warn", config={"max_length": 5000})
    add_guardrail("banned_words", scorer="keyword_block", threshold=0.5,
                  action="block", config={"keywords": ["forbidden"]})

    # Check text against all guardrails
    result = check_guardrails("Some LLM output text here")
    if not result.all_passed:
        for r in result.results:
            if not r.passed:
                print(f"BLOCKED by {r.guardrail_name}: {r.reason}")
"""

from __future__ import annotations

import json
import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("openrunner.guardrails")


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class GuardrailResult:
    """Result of evaluating a single guardrail."""

    guardrail_name: str
    passed: bool
    score: float
    action_taken: str | None = None
    reason: str | None = None


@dataclass
class GuardrailCheckResult:
    """Aggregate result of checking all guardrails."""

    results: list[GuardrailResult] = field(default_factory=list)
    all_passed: bool = True


@dataclass
class _GuardrailDef:
    """Internal guardrail definition."""

    name: str
    scorer: str
    threshold: float
    action: str
    config: dict[str, Any] = field(default_factory=dict)


# ---------------------------------------------------------------------------
# Built-in scorers (client-side mirrors of server-side)
# ---------------------------------------------------------------------------


_PII_PATTERNS = {
    "email": re.compile(
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
    ),
    "phone": re.compile(
        r"(?<!\d)"
        r"(?:\+?\d{1,3}[\s\-.]?)?"
        r"(?:\(?\d{2,4}\)?[\s\-.]?)?"
        r"\d{3}[\s\-.]?\d{4}"
        r"(?!\d)"
    ),
    "ssn": re.compile(r"\b\d{3}-\d{2}-\d{4}\b"),
    "credit_card": re.compile(r"\b(?:\d[ \-]?){12,18}\d\b"),
}

_TOXIC_KEYWORDS = {
    "hate", "kill", "violence", "threat", "abuse",
    "slur", "racist", "sexist", "discriminat",
}


def _score_toxicity(text: str, config: dict[str, Any]) -> tuple[float, str]:
    """Score text for toxicity using keyword matching."""
    keywords = config.get("keywords", list(_TOXIC_KEYWORDS))
    text_lower = text.lower()
    matches = [kw for kw in keywords if kw.lower() in text_lower]

    if not matches:
        return 0.0, "No toxic content detected"

    score = min(len(matches) / 3.0, 1.0)
    return score, f"Toxic keywords found: {', '.join(matches)}"


def _score_pii(text: str, config: dict[str, Any]) -> tuple[float, str]:
    """Score text for PII presence."""
    entity_types = config.get("entity_types", list(_PII_PATTERNS.keys()))
    found_types = []

    for entity_type in entity_types:
        pattern = _PII_PATTERNS.get(entity_type)
        if pattern and pattern.search(text):
            found_types.append(entity_type)

    if not found_types:
        return 0.0, "No PII detected"

    score = min(len(found_types) / 2.0, 1.0)
    return score, f"PII types found: {', '.join(found_types)}"


def _score_length(text: str, config: dict[str, Any]) -> tuple[float, str]:
    """Score text based on length limits."""
    max_length = config.get("max_length", 10000)
    min_length = config.get("min_length", 0)
    text_len = len(text)

    if text_len > max_length:
        return 1.0, f"Text length {text_len} exceeds maximum {max_length}"
    if text_len < min_length:
        return 1.0, f"Text length {text_len} below minimum {min_length}"

    return 0.0, f"Text length {text_len} within limits [{min_length}, {max_length}]"


def _score_keyword_block(text: str, config: dict[str, Any]) -> tuple[float, str]:
    """Score text for blocked keywords."""
    blocked = config.get("keywords", [])
    case_sensitive = config.get("case_sensitive", False)

    if not blocked:
        return 0.0, "No blocked keywords configured"

    check_text = text if case_sensitive else text.lower()
    matches = []

    for kw in blocked:
        check_kw = kw if case_sensitive else kw.lower()
        if check_kw in check_text:
            matches.append(kw)

    if not matches:
        return 0.0, "No blocked keywords found"

    return 1.0, f"Blocked keywords found: {', '.join(matches)}"


def _score_regex_match(text: str, config: dict[str, Any]) -> tuple[float, str]:
    """Score text using regex pattern matching."""
    pattern_str = config.get("pattern", "")
    if not pattern_str:
        return 0.0, "No regex pattern configured"

    try:
        flags = 0 if config.get("case_sensitive") else re.IGNORECASE
        pattern = re.compile(pattern_str, flags)
        match = pattern.search(text)
        if match:
            return 1.0, f"Regex pattern matched: '{match.group()}'"
        return 0.0, "Regex pattern did not match"
    except re.error as e:
        return 0.0, f"Invalid regex pattern: {e}"


def _score_json_schema(text: str, config: dict[str, Any]) -> tuple[float, str]:
    """Score whether text is valid JSON."""
    try:
        json.loads(text)
        return 0.0, "Valid JSON"
    except (json.JSONDecodeError, TypeError, ValueError) as e:
        return 1.0, f"Invalid JSON: {e}"


_SCORER_REGISTRY: dict[str, Any] = {
    "toxicity_check": _score_toxicity,
    "pii_check": _score_pii,
    "length_limit": _score_length,
    "keyword_block": _score_keyword_block,
    "regex_match": _score_regex_match,
    "json_schema": _score_json_schema,
}


# ---------------------------------------------------------------------------
# Global guardrail registry
# ---------------------------------------------------------------------------

_guardrails: list[_GuardrailDef] = []


def add_guardrail(
    name: str,
    scorer: str,
    threshold: float = 0.5,
    action: str = "block",
    config: dict[str, Any] | None = None,
) -> None:
    """Register a guardrail for local checking.

    Args:
        name: Human-readable name for the guardrail.
        scorer: Scorer type. Built-in types: ``toxicity_check``,
            ``pii_check``, ``length_limit``, ``keyword_block``,
            ``regex_match``, ``json_schema``.
        threshold: Score threshold (0.0-1.0). Scores at or above this
            value trigger the guardrail's action.
        action: Action to take on violation: ``"block"``, ``"warn"``,
            or ``"log"``. Default ``"block"``.
        config: Scorer-specific configuration dict.

    Example::

        add_guardrail("no_pii", scorer="pii_check", threshold=0.5)
        add_guardrail("max_len", scorer="length_limit", threshold=0.5,
                      config={"max_length": 2000})
    """
    if scorer not in _SCORER_REGISTRY:
        raise ValueError(
            f"Unknown scorer type '{scorer}'. "
            f"Available: {list(_SCORER_REGISTRY.keys())}"
        )

    _guardrails.append(
        _GuardrailDef(
            name=name,
            scorer=scorer,
            threshold=threshold,
            action=action,
            config=config or {},
        )
    )
    logger.info("Guardrail registered: %s (scorer=%s, action=%s)", name, scorer, action)


def remove_guardrail(name: str) -> bool:
    """Remove a registered guardrail by name.

    Args:
        name: Name of the guardrail to remove.

    Returns:
        True if removed, False if not found.
    """
    global _guardrails
    before = len(_guardrails)
    _guardrails = [g for g in _guardrails if g.name != name]
    return len(_guardrails) < before


def clear_guardrails() -> None:
    """Remove all registered guardrails."""
    _guardrails.clear()


def list_guardrails() -> list[dict[str, Any]]:
    """List all registered guardrails.

    Returns:
        List of guardrail definitions as dicts.
    """
    return [
        {
            "name": g.name,
            "scorer": g.scorer,
            "threshold": g.threshold,
            "action": g.action,
            "config": g.config,
        }
        for g in _guardrails
    ]


def check_guardrails(text: str) -> GuardrailCheckResult:
    """Check text against all registered guardrails.

    Evaluates each guardrail's scorer against the text and returns
    aggregate results. The ``all_passed`` field is False if any
    guardrail with action ``"block"`` was triggered.

    Args:
        text: The text to evaluate.

    Returns:
        GuardrailCheckResult with individual results and overall pass/fail.
    """
    results: list[GuardrailResult] = []
    all_passed = True

    for guardrail in _guardrails:
        scorer_fn = _SCORER_REGISTRY.get(guardrail.scorer)
        if scorer_fn is None:
            results.append(
                GuardrailResult(
                    guardrail_name=guardrail.name,
                    passed=True,
                    score=0.0,
                    reason=f"Unknown scorer: {guardrail.scorer}",
                )
            )
            continue

        try:
            score, reason = scorer_fn(text, guardrail.config)
            passed = score < guardrail.threshold
            action_taken = None if passed else guardrail.action

            results.append(
                GuardrailResult(
                    guardrail_name=guardrail.name,
                    passed=passed,
                    score=score,
                    action_taken=action_taken,
                    reason=reason,
                )
            )

            if not passed and guardrail.action == "block":
                all_passed = False

            if not passed:
                if guardrail.action == "warn":
                    logger.warning(
                        "Guardrail '%s' triggered (warn): %s",
                        guardrail.name,
                        reason,
                    )
                elif guardrail.action == "log":
                    logger.info(
                        "Guardrail '%s' triggered (log): %s",
                        guardrail.name,
                        reason,
                    )

        except Exception as e:
            logger.warning(
                "Error evaluating guardrail '%s': %s", guardrail.name, e
            )
            results.append(
                GuardrailResult(
                    guardrail_name=guardrail.name,
                    passed=True,
                    score=0.0,
                    reason=f"Evaluation error: {e}",
                )
            )

    return GuardrailCheckResult(results=results, all_passed=all_passed)
