"""Programmatic query API for OpenRunner -- equivalent to wandb.Api().

Provides read-only access to projects, runs, and artifacts without
requiring an active training run. Uses httpx.Client for HTTP requests.

Usage::

    import openrunner

    api = openrunner.Api()  # Uses OPENRUNNER_API_KEY + OPENRUNNER_BASE_URL

    # List projects
    projects = api.projects()

    # List runs with filters
    runs = api.runs("my-project")
    runs = api.runs("my-project", filters={"state": "finished"})
    runs = api.runs("my-project", order="-summary.accuracy")

    # Get a single run
    run = api.run("my-project/run_id")
    print(run.config)
    print(run.summary)
    print(run.history())  # Returns list of dicts

    # Get artifacts
    artifact = api.artifact("my-model:latest")
    artifact = api.artifact("my-model:v3")

    # Export run data
    df = run.history(pandas=True)  # Returns pandas DataFrame
"""

from __future__ import annotations

import logging
import os
from typing import Any

import httpx

logger = logging.getLogger("openrunner")


class RunResult:
    """Wrapper around run data returned by the query API.

    Attributes:
        id: Run identifier (8-char string).
        name: Display name of the run.
        state: Run state (running, finished, crashed, etc.).
        config: Hyperparameter configuration dict.
        summary: Summary metrics dict.
        tags: List of tags.
        notes: Run notes/description.
        group: Group name.
        job_type: Job type label.
        created_at: ISO timestamp of run creation.
        finished_at: ISO timestamp of run finish (or None).
        project_id: UUID string of the parent project.
        user_id: UUID string of the run owner.
    """

    def __init__(self, data: dict[str, Any], client: httpx.Client) -> None:
        self._data = data
        self._client = client
        self.id: str = data.get("id", "")
        self.name: str | None = data.get("display_name")
        self.state: str = data.get("state", "unknown")
        self.config: dict[str, Any] = data.get("config", {})
        self.summary: dict[str, Any] = data.get("summary", {})
        self.tags: list[str] = data.get("tags") or []
        self.notes: str | None = data.get("notes")
        self.group: str | None = data.get("group_name")
        self.job_type: str | None = data.get("job_type")
        self.created_at: str | None = data.get("created_at")
        self.finished_at: str | None = data.get("finished_at")
        self.project_id: str | None = data.get("project_id")
        self.user_id: str | None = data.get("user_id")

    def history(
        self, pandas: bool = False, keys: list[str] | None = None
    ) -> list[dict[str, Any]] | Any:
        """Fetch the full metric history for this run.

        Returns all metric data points (no downsampling) as a list of
        dicts, where each dict represents one step with keys for each
        metric plus a ``_step`` field.

        Args:
            pandas: If True, return a pandas DataFrame instead of a list.
            keys: Optional list of metric keys to filter.

        Returns:
            List of dicts (or DataFrame if pandas=True). Each dict has
            ``_step`` plus one key per metric recorded at that step.
        """
        try:
            params: dict[str, Any] = {}
            if keys:
                params["keys"] = keys
            response = self._client.get(
                f"/export/runs/{self.id}/metrics.json",
                params=params,
            )
            response.raise_for_status()
            payload = response.json()
        except Exception as e:
            logger.warning("RunResult.history() failed: %s", e)
            return [] if not pandas else None

        # The export endpoint returns:
        # {"run_id": "...", "metrics": [{"run_id": ..., "key": ..., "step": ..., "value": ..., "wall_time": ...}]}
        raw_metrics = payload.get("metrics", [])

        # Reshape: group by step, each step becomes a dict with metric keys
        steps: dict[int, dict[str, Any]] = {}
        for point in raw_metrics:
            step = point.get("step", 0)
            if step not in steps:
                steps[step] = {"_step": step}
            steps[step][point["key"]] = point["value"]

        result = [steps[s] for s in sorted(steps.keys())]

        if pandas:
            try:
                import pandas as pd

                return pd.DataFrame(result)
            except ImportError:
                logger.warning(
                    "pandas is required for history(pandas=True). "
                    "Install it with: pip install pandas"
                )
                return result

        return result

    def __repr__(self) -> str:
        return f"RunResult(id={self.id!r}, name={self.name!r}, state={self.state!r})"


class ArtifactResult:
    """Wrapper around artifact data returned by the query API.

    Attributes:
        id: Artifact UUID string.
        name: Artifact name.
        type: Artifact type (dataset, model, etc.).
        description: Optional description.
        project_id: UUID string of the parent project.
        versions: List of version dicts.
    """

    def __init__(self, data: dict[str, Any]) -> None:
        self._data = data
        self.id: str = str(data.get("id", ""))
        self.name: str = data.get("name", "")
        self.type: str = data.get("type", "")
        self.description: str | None = data.get("description")
        self.project_id: str | None = str(data.get("project_id", ""))
        self.versions: list[dict[str, Any]] = data.get("versions", [])
        self.aliases: list[dict[str, Any]] = data.get("aliases", [])

    @property
    def latest_version(self) -> int | None:
        """Return the highest confirmed version number, or None."""
        confirmed = [
            v["version"]
            for v in self.versions
            if v.get("state", "confirmed") == "confirmed"
        ]
        return max(confirmed) if confirmed else None

    def __repr__(self) -> str:
        return f"ArtifactResult(name={self.name!r}, type={self.type!r})"


class Api:
    """Programmatic query API for OpenRunner.

    Equivalent to ``wandb.Api()`` -- provides read-only access to
    projects, runs, and artifacts without requiring an active run.

    Args:
        api_key: API key for authentication. If not provided, reads from
            ``OPENRUNNER_API_KEY`` or ``OPENRUN_API_KEY`` or ``WANDB_API_KEY``.
        base_url: Server base URL. If not provided, reads from
            ``OPENRUNNER_BASE_URL`` or ``OPENRUN_BASE_URL`` or ``WANDB_BASE_URL``,
            defaulting to ``http://localhost:8000``.
        timeout: Request timeout in seconds (default 30).
    """

    def __init__(
        self,
        api_key: str | None = None,
        base_url: str | None = None,
        timeout: float = 30.0,
    ) -> None:
        resolved_key = api_key or (
            os.environ.get("OPENRUNNER_API_KEY")
            or os.environ.get("OPENRUN_API_KEY")
            or os.environ.get("WANDB_API_KEY")
        )
        resolved_url = base_url or (
            os.environ.get("OPENRUNNER_BASE_URL")
            or os.environ.get("OPENRUN_BASE_URL")
            or os.environ.get("WANDB_BASE_URL")
            or "http://localhost:8000"
        )

        if not resolved_key:
            raise ValueError(
                "API key required. Pass api_key= or set OPENRUNNER_API_KEY env var."
            )

        self._base_url = resolved_url.rstrip("/")
        self._client = httpx.Client(
            base_url=f"{self._base_url}/api/v1",
            headers={"Authorization": f"Bearer {resolved_key}"},
            timeout=timeout,
        )

    # ------------------------------------------------------------------
    # Projects
    # ------------------------------------------------------------------

    def projects(self) -> list[dict[str, Any]]:
        """List all projects the authenticated user has access to.

        Fetches the user's organizations, then lists projects for each.

        Returns:
            List of project dicts with keys: id, org_id, name, slug, created_at.
        """
        try:
            # Get user's organizations
            resp = self._client.get("/organizations")
            resp.raise_for_status()
            orgs = resp.json()

            all_projects: list[dict[str, Any]] = []
            for org in orgs:
                org_id = org.get("id")
                if not org_id:
                    continue
                resp = self._client.get(f"/organizations/{org_id}/projects")
                resp.raise_for_status()
                projects = resp.json()
                if isinstance(projects, list):
                    all_projects.extend(projects)
                else:
                    all_projects.extend(
                        projects.get("projects", projects.get("items", []))
                    )

            return all_projects
        except Exception as e:
            logger.warning("Api.projects() failed: %s", e)
            raise

    # ------------------------------------------------------------------
    # Runs
    # ------------------------------------------------------------------

    def runs(
        self,
        project: str,
        filters: dict[str, Any] | None = None,
        order: str | None = None,
    ) -> list[RunResult]:
        """List runs in a project with optional filtering and ordering.

        Args:
            project: Project name or slug to list runs from.
            filters: Dict of filters. Supported keys:
                - ``state``: Filter by run state (running, finished, crashed).
                - ``config.<key>``: Filter by config value (planned).
                - ``tags``: Filter by tag list.
                - ``search``: Free-text search on run name.
            order: Sort order string. Prefix with ``-`` for descending.
                Examples: ``"created_at"``, ``"-summary.accuracy"``,
                ``"-created_at"`` (default).

        Returns:
            List of RunResult objects.
        """
        try:
            # Resolve project name to project ID
            project_id = self._resolve_project_id(project)
            if project_id is None:
                logger.warning("Project %r not found", project)
                return []

            # Build query params
            params: dict[str, Any] = {"limit": 200}

            if filters:
                if "state" in filters:
                    params["state"] = filters["state"]
                if "search" in filters:
                    params["search"] = filters["search"]
                if "tags" in filters:
                    params["tags"] = filters["tags"]

            if order:
                # Parse order string: "-created_at" -> sort_by=created_at, sort_dir=desc
                if order.startswith("-"):
                    params["sort_by"] = order[1:]
                    params["sort_dir"] = "desc"
                else:
                    params["sort_by"] = order
                    params["sort_dir"] = "asc"

            resp = self._client.get(
                f"/projects/{project_id}/runs", params=params
            )
            resp.raise_for_status()
            data = resp.json()

            run_list = data.get("runs", data) if isinstance(data, dict) else data
            if not isinstance(run_list, list):
                run_list = []

            return [RunResult(r, self._client) for r in run_list]
        except Exception as e:
            logger.warning("Api.runs() failed: %s", e)
            raise

    def run(self, path: str) -> RunResult:
        """Get a single run by path.

        Args:
            path: Run path in format ``"project/run_id"`` or just ``"run_id"``.

        Returns:
            RunResult object.

        Raises:
            ValueError: If run not found.
        """
        # Parse path: "project/run_id" or just "run_id"
        parts = path.split("/")
        if len(parts) == 2:
            run_id = parts[1]
        elif len(parts) == 1:
            run_id = parts[0]
        else:
            raise ValueError(
                f"Invalid run path {path!r}. Use 'project/run_id' or 'run_id'."
            )

        try:
            resp = self._client.get(f"/runs/{run_id}")
            resp.raise_for_status()
            data = resp.json()
            return RunResult(data, self._client)
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                raise ValueError(f"Run {run_id!r} not found") from e
            raise

    # ------------------------------------------------------------------
    # Artifacts
    # ------------------------------------------------------------------

    def artifact(self, name_and_alias: str) -> ArtifactResult:
        """Get an artifact by name and version alias.

        Args:
            name_and_alias: Artifact reference in format ``"name:alias"``.
                Alias can be ``"latest"`` or ``"vN"`` (e.g., ``"v3"``).
                If no alias is given, ``"latest"`` is assumed.

        Returns:
            ArtifactResult object.

        Raises:
            ValueError: If artifact not found.
        """
        # Parse name:alias
        if ":" in name_and_alias:
            name, alias = name_and_alias.rsplit(":", 1)
        else:
            name = name_and_alias
            alias = "latest"

        try:
            # Search through all projects for the artifact
            all_projects = self.projects()
            for proj in all_projects:
                proj_id = proj.get("id")
                if not proj_id:
                    continue

                resp = self._client.get(f"/projects/{proj_id}/artifacts")
                if resp.status_code != 200:
                    continue

                artifacts = resp.json()
                for art in artifacts:
                    if art.get("name") == name:
                        # Found the artifact -- get details with versions
                        art_id = art.get("id")
                        resp = self._client.get(f"/artifacts/{art_id}")
                        resp.raise_for_status()
                        detail = resp.json()

                        # Fetch aliases for the artifact
                        try:
                            alias_resp = self._client.get(
                                f"/artifacts/{art_id}/aliases"
                            )
                            if alias_resp.status_code == 200:
                                detail["aliases"] = alias_resp.json()
                        except Exception:
                            pass

                        result = ArtifactResult(detail)

                        # Resolve alias to version
                        if alias != "latest" and alias.startswith("v"):
                            try:
                                target_version = int(alias[1:])
                                # Verify the version exists
                                matching = [
                                    v
                                    for v in result.versions
                                    if v.get("version") == target_version
                                ]
                                if not matching:
                                    raise ValueError(
                                        f"Artifact {name!r} version {alias!r} not found"
                                    )
                            except (ValueError, IndexError):
                                pass

                        return result

            raise ValueError(f"Artifact {name!r} not found")
        except ValueError:
            raise
        except Exception as e:
            logger.warning("Api.artifact() failed: %s", e)
            raise

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _resolve_project_id(self, project_name: str) -> str | None:
        """Resolve a project name/slug to its UUID.

        Searches through all orgs the user belongs to and returns
        the first matching project ID.
        """
        try:
            resp = self._client.get("/organizations")
            resp.raise_for_status()
            orgs = resp.json()

            for org in orgs:
                org_id = org.get("id")
                if not org_id:
                    continue
                resp = self._client.get(f"/organizations/{org_id}/projects")
                if resp.status_code != 200:
                    continue
                projects = resp.json()
                if not isinstance(projects, list):
                    projects = projects.get("projects", projects.get("items", []))

                for proj in projects:
                    if (
                        proj.get("name") == project_name
                        or proj.get("slug") == project_name
                    ):
                        return str(proj["id"])

            return None
        except Exception as e:
            logger.warning("_resolve_project_id failed: %s", e)
            return None

    def close(self) -> None:
        """Close the underlying httpx client."""
        try:
            self._client.close()
        except Exception:
            pass

    def __enter__(self) -> Api:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    def __repr__(self) -> str:
        return f"Api(base_url={self._base_url!r})"
