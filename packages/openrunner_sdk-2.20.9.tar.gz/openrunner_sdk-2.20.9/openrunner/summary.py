"""W&B-compatible Summary object with auto-update and explicit set support.

Supports aggregation modes set via ``define_metric(summary=...)``:
  - "last"  (default) -- store the most recent value
  - "min"   -- store the minimum value seen
  - "max"   -- store the maximum value seen
  - "mean"  -- store the running average
  - "best"  -- min or max depending on ``goal`` ("minimize" / "maximize")
  - "copy"  -- same as "last"
  - "none"  -- do not auto-update summary for this key
"""

from __future__ import annotations

from typing import Any


class Summary:
    """W&B-compatible summary that auto-tracks last logged values.

    * ``_auto_update(data)`` is called by ``log()`` to record the last value
      for each metric key.
    * Explicit set (``summary["key"] = val`` or ``summary.key = val``) takes
      priority -- once a key is explicitly set, auto-update will NOT override it.
    * ``_get_update_payload()`` returns keys that changed since the last call
      (used by the sender to push delta updates to the server).
    * Aggregation modes can be set via ``_set_aggregation(key, mode, goal)``
      to override the default "last" behavior.
    """

    def __init__(self) -> None:
        object.__setattr__(self, "_data", {})
        object.__setattr__(self, "_explicit_keys", set())
        object.__setattr__(self, "_dirty_keys", set())
        # Aggregation state: key -> {"mode": str, "goal": str|None, "count": int, "sum": float}
        object.__setattr__(self, "_aggregation", {})

    # -- aggregation configuration -------------------------------------------

    def _set_aggregation(
        self,
        key: str,
        mode: str,
        goal: str | None = None,
    ) -> None:
        """Set the aggregation mode for a summary key.

        Args:
            key: Metric key name.
            mode: One of "min", "max", "mean", "last", "best", "copy", "none".
            goal: "minimize" or "maximize" -- only used with mode="best".
        """
        self._aggregation[key] = {
            "mode": mode,
            "goal": goal,
            "count": 0,
            "sum": 0.0,
        }

    # -- auto-update (called by log()) ----------------------------------------

    def _auto_update(self, data: dict[str, Any]) -> None:
        """Merge *data* into the summary, skipping explicitly set keys.

        When an aggregation mode is configured for a key, the value is
        aggregated accordingly instead of simply storing the last value.
        """
        for k, v in data.items():
            if k in self._explicit_keys:
                continue

            agg = self._aggregation.get(k)
            if agg is not None:
                mode = agg["mode"]

                if mode == "none":
                    continue

                if not isinstance(v, (int, float)):
                    # Non-numeric values fall back to "last"
                    self._data[k] = v
                    self._dirty_keys.add(k)
                    continue

                if mode == "min":
                    if k not in self._data or v < self._data[k]:
                        self._data[k] = v
                        self._dirty_keys.add(k)
                elif mode == "max":
                    if k not in self._data or v > self._data[k]:
                        self._data[k] = v
                        self._dirty_keys.add(k)
                elif mode == "mean":
                    agg["count"] += 1
                    agg["sum"] += v
                    self._data[k] = agg["sum"] / agg["count"]
                    self._dirty_keys.add(k)
                elif mode == "best":
                    goal = agg.get("goal")
                    if goal == "minimize":
                        if k not in self._data or v < self._data[k]:
                            self._data[k] = v
                            self._dirty_keys.add(k)
                    elif goal == "maximize":
                        if k not in self._data or v > self._data[k]:
                            self._data[k] = v
                            self._dirty_keys.add(k)
                    else:
                        # No goal specified -- fall back to "last"
                        self._data[k] = v
                        self._dirty_keys.add(k)
                else:
                    # "last", "copy", or unknown -- store latest value
                    self._data[k] = v
                    self._dirty_keys.add(k)
            else:
                # Default behavior: store last value
                self._data[k] = v
                self._dirty_keys.add(k)

    # -- explicit set ---------------------------------------------------------

    def __setitem__(self, key: str, value: Any) -> None:
        self._data[key] = value
        self._explicit_keys.add(key)
        self._dirty_keys.add(key)

    def __setattr__(self, name: str, value: Any) -> None:
        self.__setitem__(name, value)

    # -- access ---------------------------------------------------------------

    def __getitem__(self, key: str) -> Any:
        return self._data[key]

    def __getattr__(self, name: str) -> Any:
        try:
            return self._data[name]
        except KeyError:
            raise AttributeError(f"Summary has no key '{name}'") from None

    def __contains__(self, key: object) -> bool:
        return key in self._data

    # -- introspection --------------------------------------------------------

    def as_dict(self) -> dict[str, Any]:
        """Return a copy of the current summary state."""
        return dict(self._data)

    def _get_update_payload(self) -> dict[str, Any]:
        """Return keys that changed since the last call, then clear dirty set."""
        payload = {k: self._data[k] for k in self._dirty_keys if k in self._data}
        self._dirty_keys.clear()
        return payload

    def __repr__(self) -> str:
        return f"Summary({self._data!r})"
