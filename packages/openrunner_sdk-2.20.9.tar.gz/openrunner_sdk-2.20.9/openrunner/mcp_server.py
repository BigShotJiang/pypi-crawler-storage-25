"""OpenRunner MCP Server -- exposes tools for AI coding assistants.

Run: openrunner mcp serve
Or configure in Claude Code: ~/.claude/claude_desktop_config.json

This server implements the Model Context Protocol (MCP) over stdio,
allowing AI coding tools like Claude Code and Codex to search and
query AI sessions, runs, and artifacts as native tools.
"""

from __future__ import annotations

import json
import logging
from pathlib import Path
from typing import Any

logger = logging.getLogger("openrunner.mcp")


# ---------------------------------------------------------------------------
# Settings / API client helpers
# ---------------------------------------------------------------------------


def _load_settings() -> dict[str, Any]:
    """Load settings from ~/.openrunner/settings.json."""
    settings_file = Path.home() / ".openrunner" / "settings.json"
    if not settings_file.exists():
        return {}
    try:
        return json.loads(settings_file.read_text(encoding="utf-8"))
    except (json.JSONDecodeError, OSError):
        return {}


def _get_api_config() -> tuple[str, str]:
    """Return (base_url, api_key) from settings or raise."""
    settings = _load_settings()
    base_url = settings.get("base_url", "")
    api_key = settings.get("api_key", "")
    if not base_url or not api_key:
        raise RuntimeError(
            "OpenRunner not configured. Run 'openrunner login' first."
        )
    return base_url.rstrip("/"), api_key


async def _api_get(path: str, params: dict | None = None) -> dict[str, Any]:
    """Make a GET request to the OpenRunner API."""
    import httpx

    base_url, api_key = _get_api_config()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.get(
            f"{base_url}/api/v1{path}",
            params=params,
            headers={"Authorization": f"Bearer {api_key}"},
        )
        resp.raise_for_status()
        return resp.json()


async def _api_post(path: str, data: dict | None = None) -> dict[str, Any]:
    """Make a POST request to the OpenRunner API."""
    import httpx

    base_url, api_key = _get_api_config()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.post(
            f"{base_url}/api/v1{path}",
            json=data or {},
            headers={"Authorization": f"Bearer {api_key}"},
        )
        resp.raise_for_status()
        return resp.json()


async def _api_patch(path: str, data: dict | None = None) -> dict[str, Any]:
    """Make a PATCH request to the OpenRunner API."""
    import httpx

    base_url, api_key = _get_api_config()
    async with httpx.AsyncClient(timeout=30.0) as client:
        resp = await client.patch(
            f"{base_url}/api/v1{path}",
            json=data or {},
            headers={"Authorization": f"Bearer {api_key}"},
        )
        resp.raise_for_status()
        return resp.json()


# ---------------------------------------------------------------------------
# MCP Server definition
# ---------------------------------------------------------------------------


def create_server():
    """Create and configure the MCP server with all OpenRunner tools."""
    from mcp.server import Server
    from mcp.types import TextContent, Tool

    server = Server("openrunner")

    @server.list_tools()
    async def list_tools() -> list[Tool]:
        """Return the list of available tools."""
        return [
            Tool(
                name="openrunner_search_sessions",
                description=(
                    "Search across all AI coding sessions (Claude Code, Codex, ChatGPT, etc.) "
                    "in your OpenRunner projects. Searches titles, summaries, notes, and message content."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query (min 2 characters)",
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Optional: scope to a specific project UUID",
                        },
                        "source": {
                            "type": "string",
                            "description": "Optional: filter by source (claude-code, codex, chatgpt, qwen, opencode)",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max results to return (default: 20, max: 100)",
                            "default": 20,
                        },
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="openrunner_get_session",
                description="Get full details of an AI coding session by its ID.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "session_id": {
                            "type": "string",
                            "description": "The UUID of the AI session to retrieve",
                        },
                    },
                    "required": ["session_id"],
                },
            ),
            Tool(
                name="openrunner_list_runs",
                description="List recent experiment runs in a project.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project": {
                            "type": "string",
                            "description": "Project name or slug (format: entity/project or just project)",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max results (default: 20)",
                            "default": 20,
                        },
                        "state": {
                            "type": "string",
                            "description": "Filter by state (running, finished, crashed, failed)",
                        },
                    },
                    "required": ["project"],
                },
            ),
            Tool(
                name="openrunner_get_run_metrics",
                description="Get metrics (loss, accuracy, etc.) for a specific run.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "run_id": {
                            "type": "string",
                            "description": "The run ID to get metrics for",
                        },
                        "keys": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Optional: specific metric keys to retrieve",
                        },
                    },
                    "required": ["run_id"],
                },
            ),
            Tool(
                name="openrunner_search_code",
                description="Search in code artifacts stored in OpenRunner.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search query for code content",
                        },
                        "project_id": {
                            "type": "string",
                            "description": "Optional: scope to a specific project UUID",
                        },
                        "limit": {
                            "type": "integer",
                            "description": "Max results (default: 20)",
                            "default": 20,
                        },
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="openrunner_log_note",
                description=(
                    "Log a quick research note to OpenRunner. "
                    "Useful for recording findings, decisions, or observations during development."
                ),
                inputSchema={
                    "type": "object",
                    "properties": {
                        "note": {
                            "type": "string",
                            "description": "The note content to log",
                        },
                        "project": {
                            "type": "string",
                            "description": "Optional: target project name or slug",
                        },
                        "tags": {
                            "type": "array",
                            "items": {"type": "string"},
                            "description": "Optional: tags for the note",
                        },
                    },
                    "required": ["note"],
                },
            ),
            Tool(
                name="openrunner_list_artifacts",
                description="List all artifacts (models, datasets, code) in a project.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "project": {
                            "type": "string",
                            "description": "Project name (format: org/project or just project)",
                        },
                    },
                    "required": [],
                },
            ),
            Tool(
                name="openrunner_search_runs",
                description="Search experiment runs by name, tags, or notes.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search term (matches run name, tags, notes)",
                        },
                        "project": {
                            "type": "string",
                            "description": "Optional: project name (format: org/project)",
                        },
                    },
                    "required": [],
                },
            ),
            Tool(
                name="openrunner_search_papers",
                description="Search papers by title, abstract, or section content.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search term (matches title, abstract, section content)",
                        },
                        "project": {
                            "type": "string",
                            "description": "Optional: project name",
                        },
                    },
                    "required": ["query"],
                },
            ),
            Tool(
                name="openrunner_watch_run",
                description="Get latest metrics for a run and render as ASCII chart. Use to monitor training progress.",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "run_id": {"type": "string", "description": "Run ID to watch"},
                        "metric": {"type": "string", "description": "Metric key (default: train/loss)", "default": "train/loss"},
                        "width": {"type": "integer", "description": "Chart width in chars (default: 60)", "default": 60},
                    },
                    "required": ["run_id"],
                },
            ),
            Tool(
                name="openrunner_update_paper",
                description="Update a paper's title, abstract, or section content (LaTeX).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "paper_id": {"type": "string", "description": "Paper UUID"},
                        "project": {"type": "string", "description": "Project name (org/project)"},
                        "title": {"type": "string", "description": "New title (optional)"},
                        "abstract": {"type": "string", "description": "New abstract (optional)"},
                        "section_key": {"type": "string", "description": "Section key to update (e.g. 'introduction')"},
                        "section_content": {"type": "string", "description": "New LaTeX content for the section"},
                    },
                    "required": ["paper_id"],
                },
            ),
            Tool(
                name="openrunner_search_research",
                description="Search research plans (literature, SOTA analysis, gaps, experiments, protocols).",
                inputSchema={
                    "type": "object",
                    "properties": {
                        "query": {
                            "type": "string",
                            "description": "Search term (matches domain, SOTA, gaps, experiments)",
                        },
                        "project": {
                            "type": "string",
                            "description": "Optional: project name",
                        },
                    },
                    "required": ["query"],
                },
            ),
        ]

    @server.call_tool()
    async def call_tool(name: str, arguments: dict) -> list[TextContent]:
        """Handle tool calls."""
        try:
            if name == "openrunner_search_sessions":
                result = await _tool_search_sessions(arguments)
            elif name == "openrunner_get_session":
                result = await _tool_get_session(arguments)
            elif name == "openrunner_list_runs":
                result = await _tool_list_runs(arguments)
            elif name == "openrunner_get_run_metrics":
                result = await _tool_get_run_metrics(arguments)
            elif name == "openrunner_search_code":
                result = await _tool_search_code(arguments)
            elif name == "openrunner_log_note":
                result = await _tool_log_note(arguments)
            elif name == "openrunner_list_artifacts":
                result = await _tool_list_artifacts(arguments)
            elif name == "openrunner_search_runs":
                result = await _tool_search_runs(arguments)
            elif name == "openrunner_search_papers":
                result = await _tool_search_papers(arguments)
            elif name == "openrunner_update_paper":
                result = await _tool_update_paper(arguments)
            elif name == "openrunner_watch_run":
                result = await _tool_watch_run(arguments)
            elif name == "openrunner_search_research":
                result = await _tool_search_research(arguments)
            else:
                result = f"Unknown tool: {name}"
        except RuntimeError as e:
            result = f"Configuration error: {e}"
        except Exception as e:
            result = f"Error: {type(e).__name__}: {e}"

        return [TextContent(type="text", text=result)]

    return server


# ---------------------------------------------------------------------------
# Tool implementations
# ---------------------------------------------------------------------------


async def _tool_search_sessions(args: dict) -> str:
    """Search AI sessions."""
    params: dict[str, Any] = {"q": args["query"]}
    if args.get("project_id"):
        params["project_id"] = args["project_id"]
    if args.get("source"):
        params["source"] = args["source"]
    if args.get("limit"):
        params["limit"] = args["limit"]

    data = await _api_get("/search/ai-sessions", params=params)

    results = data.get("results", [])
    if not results:
        return f"No sessions found matching '{args['query']}'"

    lines = [f"Found {data.get('total', len(results))} session(s):\n"]
    for r in results:
        lines.append(f"- [{r['source']}] {r.get('title') or 'Untitled'}")
        lines.append(f"  ID: {r['session_id']}")
        lines.append(f"  Match in: {r['match_field']} (score: {r['score']})")
        if r.get("excerpt"):
            excerpt = r["excerpt"][:200]
            lines.append(f"  Excerpt: {excerpt}")
        lines.append(f"  Created: {r['created_at']}")
        lines.append("")

    return "\n".join(lines)


async def _tool_get_session(args: dict) -> str:
    """Get full session detail."""
    session_id = args["session_id"]

    # Try to find the session via search first, then use direct endpoint
    # The sessions endpoint is per-project, so we search to find it
    try:
        data = await _api_get(f"/ai-sessions/{session_id}")
    except Exception:
        # Fall back to search
        return f"Could not retrieve session {session_id}. It may not exist or you may not have access."

    lines = [f"Session: {data.get('title') or 'Untitled'}"]
    lines.append(f"ID: {data.get('id', session_id)}")
    lines.append(f"Source: {data.get('source', 'unknown')}")
    lines.append(f"Messages: {data.get('message_count', 0)}")
    lines.append(f"Tokens: {data.get('total_tokens', 0)}")

    if data.get("summary"):
        lines.append(f"\nSummary:\n{data['summary']}")
    if data.get("notes"):
        lines.append(f"\nNotes:\n{data['notes']}")
    if data.get("first_message"):
        lines.append(f"\nFirst message:\n{data['first_message'][:500]}")
    if data.get("tools_used"):
        lines.append(f"\nTools used: {', '.join(data['tools_used'])}")
    if data.get("files_touched"):
        lines.append(f"\nFiles touched: {', '.join(data['files_touched'][:20])}")
    if data.get("tags"):
        lines.append(f"\nTags: {', '.join(data['tags'])}")

    lines.append(f"\nCreated: {data.get('created_at', 'unknown')}")
    if data.get("started_at"):
        lines.append(f"Started: {data['started_at']}")
    if data.get("ended_at"):
        lines.append(f"Ended: {data['ended_at']}")

    return "\n".join(lines)


async def _tool_list_runs(args: dict) -> str:
    """List recent runs in a project."""
    project = args["project"]
    params: dict[str, Any] = {"limit": args.get("limit", 20)}
    if args.get("state"):
        params["state"] = args["state"]

    # Resolve project path (entity/project format)
    parts = project.split("/")
    if len(parts) == 2:
        path = f"/projects/{parts[0]}/{parts[1]}/runs"
    else:
        # Try as slug directly
        path = f"/projects/{project}/runs"

    try:
        data = await _api_get(path, params=params)
    except Exception as e:
        return f"Could not list runs for project '{project}': {e}"

    runs = data.get("runs", data) if isinstance(data, dict) else data
    if not runs:
        return f"No runs found in project '{project}'"

    if isinstance(runs, list):
        lines = [f"Runs in {project} ({len(runs)} shown):\n"]
        for r in runs:
            name = r.get("display_name") or r.get("name") or r.get("id", "?")
            state = r.get("state", "unknown")
            created = r.get("created_at", "")
            lines.append(f"- {name} [{state}] (ID: {r.get('id', '?')})")
            if created:
                lines.append(f"  Created: {created}")
        return "\n".join(lines)

    return json.dumps(data, indent=2, default=str)


async def _tool_get_run_metrics(args: dict) -> str:
    """Get metrics for a run."""
    run_id = args["run_id"]

    try:
        data = await _api_get(f"/runs/{run_id}/metrics")
    except Exception as e:
        return f"Could not get metrics for run '{run_id}': {e}"

    if not data:
        return f"No metrics found for run '{run_id}'"

    keys_filter = args.get("keys")

    if isinstance(data, dict):
        metrics = data.get("metrics", data)
        if keys_filter and isinstance(metrics, dict):
            metrics = {k: v for k, v in metrics.items() if k in keys_filter}

        lines = [f"Metrics for run {run_id}:\n"]
        if isinstance(metrics, dict):
            for key, value in metrics.items():
                if isinstance(value, list):
                    # Show last few values
                    recent = value[-5:] if len(value) > 5 else value
                    lines.append(f"  {key}: {recent} (last {len(recent)} of {len(value)})")
                else:
                    lines.append(f"  {key}: {value}")
        else:
            lines.append(json.dumps(metrics, indent=2, default=str))
        return "\n".join(lines)

    return json.dumps(data, indent=2, default=str)


async def _tool_search_code(args: dict) -> str:
    """Search in code artifacts."""
    params: dict[str, Any] = {"q": args["query"], "type": "artifacts"}
    if args.get("project_id"):
        params["project_id"] = args["project_id"]
    params["limit"] = args.get("limit", 20)

    try:
        data = await _api_get("/search", params=params)
    except Exception as e:
        return f"Search failed: {e}"

    artifacts = data.get("artifacts", [])
    if not artifacts:
        return f"No code artifacts found matching '{args['query']}'"

    lines = [f"Found {data.get('total_artifacts', len(artifacts))} artifact(s):\n"]
    for a in artifacts:
        lines.append(f"- {a.get('name', 'Unnamed')} ({a.get('type', 'unknown')})")
        lines.append(f"  ID: {a.get('id', '?')}")
        if a.get("description"):
            lines.append(f"  Description: {a['description'][:100]}")
        lines.append(f"  Project: {a.get('project_name', '?')}")
        lines.append("")

    return "\n".join(lines)


async def _tool_log_note(args: dict) -> str:
    """Log a research note."""
    note = args["note"]
    project = args.get("project")
    tags = args.get("tags", [])

    # Determine project from settings if not specified
    settings = _load_settings()
    if not project:
        project = settings.get("project")

    if not project:
        return "Error: No project specified and none configured. Pass a project name or run 'openrunner init'."

    payload = {
        "title": note[:80] if len(note) > 80 else note,
        "source": "mcp",
        "notes": note,
        "message_count": 0,
        "user_message_count": 0,
        "total_tokens": 0,
        "visibility": "private",
        "tags": tags or ["note", "mcp"],
    }

    # Resolve project
    parts = project.split("/")
    if len(parts) == 2:
        project_path = f"/projects/{parts[0]}/{parts[1]}"
    else:
        project_path = f"/projects/{project}"

    # Get project ID first
    try:
        proj_data = await _api_get(project_path)
        project_id = proj_data.get("id")
        if not project_id:
            return f"Could not resolve project '{project}'"
    except Exception as e:
        return f"Could not find project '{project}': {e}"

    try:
        result = await _api_post(f"/projects/{project_id}/ai-sessions", data=payload)
        return f"Note logged successfully (session ID: {result.get('id', 'unknown')})"
    except Exception as e:
        return f"Failed to log note: {e}"


async def _tool_list_artifacts(args: dict) -> str:
    """List artifacts in a project."""
    project = args.get("project")
    settings = _load_settings()
    if not project:
        project = settings.get("project")
    if not project:
        return "Error: No project specified."

    try:
        data = await _api_get("/projects", params={})
        projects = data if isinstance(data, list) else []
        project_id = None
        for p in projects:
            org = p.get("org_name", "")
            name = p.get("name", "")
            slug = p.get("slug", "")
            if f"{org}/{name}" == project or f"{org}/{slug}" == project or name == project:
                project_id = p.get("id")
                break
        if not project_id:
            return f"Project '{project}' not found"

        arts = await _api_get(f"/projects/{project_id}/artifacts")
        artifacts = arts if isinstance(arts, list) else arts.get("artifacts", [])
        if not artifacts:
            return "No artifacts found."

        lines = [f"Artifacts in {project}:\n"]
        for a in artifacts:
            lines.append(f"- {a.get('name', '?')} (type: {a.get('type', '?')}, versions: {a.get('version_count', '?')})")
        return "\n".join(lines)
    except Exception as e:
        return f"Error: {e}"


async def _tool_search_runs(args: dict) -> str:
    """Search runs by name, tags, or config values."""
    query = args.get("query", "")
    project = args.get("project")
    settings = _load_settings()
    if not project:
        project = settings.get("project")
    if not project:
        return "Error: No project specified."

    try:
        data = await _api_get("/projects", params={})
        projects = data if isinstance(data, list) else []
        project_id = None
        for p in projects:
            org = p.get("org_name", "")
            name = p.get("name", "")
            slug = p.get("slug", "")
            if f"{org}/{name}" == project or f"{org}/{slug}" == project or name == project:
                project_id = p.get("id")
                break
        if not project_id:
            return f"Project '{project}' not found"

        runs_data = await _api_get(f"/projects/{project_id}/runs", params={"limit": 50})
        runs = runs_data.get("runs", []) if isinstance(runs_data, dict) else []

        # Filter by query in name, tags, notes
        if query:
            q_lower = query.lower()
            runs = [r for r in runs if (
                q_lower in (r.get("display_name") or "").lower() or
                q_lower in str(r.get("tags") or []).lower() or
                q_lower in (r.get("notes") or "").lower()
            )]

        if not runs:
            return f"No runs matching '{query}'" if query else "No runs found."

        lines = [f"{'Matching' if query else 'Recent'} runs ({len(runs)}):\n"]
        for r in runs[:20]:
            name = r.get("display_name") or r.get("id", "?")
            state = r.get("state", "?")
            tags = ", ".join(r.get("tags") or [])
            lines.append(f"- {name} [{state}] {f'tags: {tags}' if tags else ''}")
            if r.get("summary"):
                metrics = [f"{k}={v}" for k, v in list(r["summary"].items())[:5]]
                lines.append(f"  metrics: {', '.join(metrics)}")
        return "\n".join(lines)
    except Exception as e:
        return f"Error: {e}"


async def _tool_search_papers(args: dict) -> str:
    """Search papers by title, abstract, section content."""
    query = args["query"].lower()
    project = args.get("project")
    settings = _load_settings()
    if not project:
        project = settings.get("project")
    if not project:
        return "Error: No project specified."

    try:
        data = await _api_get("/projects", params={})
        projects = data if isinstance(data, list) else []
        project_id = None
        for p in projects:
            org = p.get("org_name", "")
            name = p.get("name", "")
            slug = p.get("slug", "")
            if f"{org}/{name}" == project or f"{org}/{slug}" == project or name == project:
                project_id = p.get("id")
                break
        if not project_id:
            return f"Project '{project}' not found"

        papers_data = await _api_get(f"/projects/{project_id}/papers")
        papers = papers_data.get("papers", []) if isinstance(papers_data, dict) else []

        results = []
        for paper in papers:
            matches = []
            if query in (paper.get("title") or "").lower():
                matches.append("title")
            if query in (paper.get("abstract") or "").lower():
                matches.append("abstract")
            for section in (paper.get("sections") or []):
                if query in (section.get("content") or "").lower():
                    matches.append(f"section:{section.get('title', '?')}")
            if matches:
                results.append((paper, matches))

        if not results:
            return f"No papers matching '{args['query']}'"

        lines = [f"Found {len(results)} paper(s):\n"]
        for paper, matches in results:
            lines.append(f"- **{paper.get('title', 'Untitled')}** (status: {paper.get('status', '?')})")
            lines.append(f"  Matched in: {', '.join(matches)}")
            if paper.get("abstract"):
                lines.append(f"  Abstract: {paper['abstract'][:150]}...")
            lines.append(f"  ID: {paper.get('id')}")
            lines.append("")
        return "\n".join(lines)
    except Exception as e:
        return f"Error: {e}"


async def _tool_watch_run(args: dict) -> str:
    """Get metrics for a run and render ASCII sparkline chart."""
    run_id = args["run_id"]
    metric_key = args.get("metric", "train/loss")
    width = args.get("width", 60)

    try:
        data = await _api_get(f"/runs/{run_id}/metrics", params={"keys": metric_key})
        points = data.get("metrics", {}).get(metric_key, [])
        if not points:
            # Try without namespace
            all_metrics = data.get("metrics", {})
            if all_metrics:
                # Show available keys
                keys = list(all_metrics.keys())
                return f"No '{metric_key}' data. Available: {', '.join(keys[:20])}"
            return f"No metrics yet for run {run_id}. Training may still be starting."

        # Extract values
        values = [p.get("value", p) if isinstance(p, dict) else p for p in points]
        steps = [p.get("step", i) if isinstance(p, dict) else i for i, p in enumerate(points)]

        if not values:
            return "No numeric values found."

        # ASCII chart
        min_v = min(values)
        max_v = max(values)
        range_v = max_v - min_v or 1
        height = 10
        chart_width = min(width, len(values))

        # Sample if too many points
        if len(values) > chart_width:
            step_size = len(values) / chart_width
            sampled = [values[int(i * step_size)] for i in range(chart_width)]
        else:
            sampled = values

        # Build chart
        bars = "▁▂▃▄▅▆▇█"
        sparkline = ""
        for v in sampled:
            idx = int((v - min_v) / range_v * (len(bars) - 1))
            sparkline += bars[idx]

        lines = []
        lines.append(f"📊 {metric_key} — run {run_id}")
        lines.append(f"   Steps: {steps[0]}→{steps[-1]} ({len(values)} points)")
        lines.append(f"   Range: {min_v:.4f} → {max_v:.4f} (latest: {values[-1]:.4f})")
        lines.append(f"   {sparkline}")
        lines.append(f"   {'↑' if values[-1] > values[0] else '↓'} {'rising' if values[-1] > values[0] else 'falling'} ({((values[-1] - values[0]) / (values[0] or 1)) * 100:.1f}%)")

        return "\n".join(lines)
    except Exception as e:
        return f"Error fetching metrics: {e}"


async def _tool_update_paper(args: dict) -> str:
    """Update a paper's title, abstract, or section content."""
    paper_id = args["paper_id"]
    project = args.get("project")
    settings = _load_settings()
    if not project:
        project = settings.get("project")
    if not project:
        return "Error: No project specified."

    try:
        # Resolve project_id
        data = await _api_get("/projects", params={})
        projects = data if isinstance(data, list) else []
        project_id = None
        for p in projects:
            org = p.get("org_name", "")
            name = p.get("name", "")
            slug = p.get("slug", "")
            if f"{org}/{name}" == project or f"{org}/{slug}" == project or name == project:
                project_id = p.get("id")
                break
        if not project_id:
            return f"Project '{project}' not found"

        # Build patch payload
        patch: dict = {}
        if args.get("title"):
            patch["title"] = args["title"]
        if args.get("abstract"):
            patch["abstract"] = args["abstract"]

        # Update section content if specified
        if args.get("section_key") and args.get("section_content"):
            # Get current paper to update sections array
            paper = await _api_get(f"/projects/{project_id}/papers/{paper_id}")
            sections = paper.get("sections", [])
            for s in sections:
                if s.get("key") == args["section_key"]:
                    s["content"] = args["section_content"]
                    break
            patch["sections"] = sections

        if not patch:
            return "Nothing to update. Provide title, abstract, or section_key + section_content."

        result = await _api_patch(f"/projects/{project_id}/papers/{paper_id}", data=patch)
        return f"Paper updated: {result.get('title', paper_id)}"
    except Exception as e:
        return f"Error: {e}"


async def _tool_search_research(args: dict) -> str:
    """Search research plans (literature, SOTA, gaps, experiments, protocols)."""
    query = args["query"].lower()
    project = args.get("project")
    settings = _load_settings()
    if not project:
        project = settings.get("project")
    if not project:
        return "Error: No project specified."

    try:
        data = await _api_get("/projects", params={})
        projects = data if isinstance(data, list) else []
        project_id = None
        for p in projects:
            org = p.get("org_name", "")
            name = p.get("name", "")
            slug = p.get("slug", "")
            if f"{org}/{name}" == project or f"{org}/{slug}" == project or name == project:
                project_id = p.get("id")
                break
        if not project_id:
            return f"Project '{project}' not found"

        research_data = await _api_get(f"/projects/{project_id}/research")
        plans = research_data.get("plans", []) if isinstance(research_data, dict) else []

        results = []
        for plan in plans:
            matches = []
            if query in (plan.get("domain") or "").lower():
                matches.append("domain")
            if query in (plan.get("sota_analysis") or "").lower():
                matches.append("sota")
            if query in str(plan.get("gaps") or []).lower():
                matches.append("gaps")
            if query in str(plan.get("proposed_experiments") or []).lower():
                matches.append("experiments")
            if query in (plan.get("protocol") or "").lower():
                matches.append("protocol")
            if query in (plan.get("title") or "").lower():
                matches.append("title")
            if matches:
                results.append((plan, matches))

        if not results:
            return f"No research plans matching '{args['query']}'"

        lines = [f"Found {len(results)} research plan(s):\n"]
        for plan, matches in results:
            lines.append(f"- **{plan.get('title', 'Untitled')}** (domain: {plan.get('domain', '?')}, status: {plan.get('status', '?')})")
            lines.append(f"  Matched in: {', '.join(matches)}")
            if plan.get("sota_analysis"):
                lines.append(f"  SOTA: {plan['sota_analysis'][:150]}...")
            lines.append(f"  ID: {plan.get('id')}")
            lines.append("")
        return "\n".join(lines)
    except Exception as e:
        return f"Error: {e}"


# ---------------------------------------------------------------------------
# Server runner
# ---------------------------------------------------------------------------


def run_server() -> None:
    """Run the MCP server over stdio transport."""
    import asyncio

    from mcp.server.stdio import stdio_server

    server = create_server()

    async def _run():
        async with stdio_server() as (read_stream, write_stream):
            await server.run(read_stream, write_stream, server.create_initialization_options())

    asyncio.run(_run())


if __name__ == "__main__":
    run_server()
