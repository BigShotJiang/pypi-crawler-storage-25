"""Thread-safe metric write buffer wrapping ``queue.Queue``."""

from __future__ import annotations

import queue
from typing import Any


class WriteBuffer:
    """Thread-safe metric buffer with batch extraction.

    ``put()`` never blocks -- it uses ``put_nowait()``.
    ``drain()`` extracts up to *max_items* in a non-blocking loop.
    """

    def __init__(self, max_size: int = 100) -> None:
        self._queue: queue.Queue[dict[str, Any]] = queue.Queue()
        self._max_size = max_size

    def put(self, record: dict[str, Any]) -> None:
        """Add a metric record to the buffer. Never blocks."""
        self._queue.put_nowait(record)

    def drain(self, max_items: int | None = None) -> list[dict[str, Any]]:
        """Extract up to *max_items* from the buffer. Non-blocking.

        Returns an empty list when the buffer is empty.
        """
        items: list[dict[str, Any]] = []
        limit = max_items if max_items is not None else self._max_size
        while len(items) < limit:
            try:
                items.append(self._queue.get_nowait())
            except queue.Empty:
                break
        return items

    @property
    def size(self) -> int:
        """Current number of items in the buffer."""
        return self._queue.qsize()

    @property
    def is_full(self) -> bool:
        """Whether the buffer has reached its max size."""
        return self._queue.qsize() >= self._max_size
