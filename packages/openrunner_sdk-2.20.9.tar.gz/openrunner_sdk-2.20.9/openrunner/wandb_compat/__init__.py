"""W&B compatibility shim -- re-exports the OpenRunner public API.

Usage:
    import openrunner.wandb_compat as wandb
    wandb.init(project="my-project")
    wandb.log({"loss": 0.5})
    wandb.finish()

Or more simply:
    import openrunner as wandb
    wandb.init(...)

This module re-exports all public API functions and objects from openrunner
so that existing W&B code can switch with minimal changes.
"""

from openrunner import init, log, finish, config, summary
from openrunner import Image, Table, Artifact, log_artifact, use_artifact
from openrunner import __version__
from openrunner import _active_run as run

__all__ = [
    "init", "log", "finish", "config", "summary", "run", "__version__",
    "Image", "Table", "Artifact", "log_artifact", "use_artifact",
]
