"""Artifact class for versioned file collections with content-hash deduplication.

An Artifact represents a named collection of files (e.g., a dataset or model
checkpoint). Files are hashed with SHA-256 for server-side deduplication --
identical content is only uploaded once.
"""

from __future__ import annotations

import hashlib
from pathlib import Path
from typing import Any


def _sha256_file(path: Path, chunk_size: int = 8192) -> str:
    """Compute the SHA-256 hex digest of a file."""
    h = hashlib.sha256()
    with open(path, "rb") as f:
        while True:
            chunk = f.read(chunk_size)
            if not chunk:
                break
            h.update(chunk)
    return h.hexdigest()


class Artifact:
    """A versioned collection of files for experiment tracking.

    Usage::

        artifact = Artifact("my-dataset", type="dataset")
        artifact.add_file("data/train.csv")
        artifact.add_dir("data/images/")
        run.log_artifact(artifact)
    """

    def __init__(
        self,
        name: str,
        type: str,
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        self.name = name
        self.type = type
        self.description = description
        self.metadata: dict[str, Any] = metadata or {}
        self._files: list[dict[str, Any]] = []
        # Draft mode fields (set by from_version)
        self._base_version: int | None = None
        self._base_version_id: str | None = None
        self._base_files: dict[str, dict[str, Any]] = {}
        self._removed_files: set[str] = set()

    @classmethod
    def from_version(
        cls,
        name: str,
        type: str,
        base_version_id: str,
        base_version: int,
        base_files: list[dict[str, Any]],
        description: str | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> "Artifact":
        """Create a new draft from an existing artifact version.

        Allows incremental updates: add new files, remove files, or update files
        without re-uploading unchanged content.

        Args:
            name: Artifact name.
            type: Artifact type (inherited from base).
            base_version_id: UUID of the base version.
            base_version: Version number of the base.
            base_files: List of file dicts from the base version
                        (each with path, size_bytes, content_hash, storage_key).
            description: Optional description override.
            metadata: Optional metadata override.

        Returns:
            A new Artifact instance in draft mode.
        """
        artifact = cls(name=name, type=type, description=description, metadata=metadata)
        artifact._base_version = base_version
        artifact._base_version_id = base_version_id
        artifact._base_files = {f["path"]: f for f in base_files}
        return artifact

    def remove_file(self, path: str) -> None:
        """Remove a file from the draft (only for drafts created with from_version).

        Args:
            path: Logical path of the file to remove from the base version.

        Raises:
            ValueError: If this artifact was not created with from_version().
            KeyError: If the path is not in the base files.
        """
        if not self._base_version_id:
            raise ValueError("remove_file() only works on drafts created with from_version()")
        if path not in self._base_files:
            raise KeyError(f"File '{path}' not found in base version files")
        self._removed_files.add(path)

    def add_file(self, local_path: str, name: str | None = None) -> None:
        """Add a single file to the artifact manifest.

        Args:
            local_path: Path to the file on disk.
            name: Logical name within the artifact. Defaults to the filename.

        Raises:
            FileNotFoundError: If the file does not exist.
        """
        path = Path(local_path)
        if not path.exists():
            raise FileNotFoundError(f"Artifact file not found: {local_path}")
        self._files.append({
            "name": name or path.name,
            "local_path": str(path.resolve()),
            "size": path.stat().st_size,
            "content_hash": _sha256_file(path),
        })

    def add_reference(self, uri: str, name: str | None = None) -> None:
        """Add a reference to an external file (S3, GCS, Azure, HTTP).

        Reference artifacts point to external storage without copying data.
        The URI is stored as metadata; no file upload occurs.

        Args:
            uri: External URI (s3://bucket/key, gs://bucket/key, https://...).
            name: Display name/path in artifact. Defaults to URI filename.
        """
        if name is None:
            name = uri.rsplit("/", 1)[-1]
        self._files.append({
            "name": name,
            "local_path": None,
            "size": 0,
            "content_hash": f"ref:{uri}",
            "is_reference": True,
            "reference_uri": uri,
        })

    def add_dir(self, local_path: str, name: str | None = None) -> None:
        """Add all files in a directory recursively.

        Args:
            local_path: Path to the directory.
            name: Prefix for file names within the artifact. Defaults to dir name.

        Raises:
            NotADirectoryError: If the path is not a directory.
        """
        base = Path(local_path)
        if not base.is_dir():
            raise NotADirectoryError(f"Not a directory: {local_path}")
        prefix = name or base.name
        for f in sorted(base.rglob("*")):
            if f.is_file():
                rel = f.relative_to(base)
                self.add_file(str(f), name=f"{prefix}/{rel}")
