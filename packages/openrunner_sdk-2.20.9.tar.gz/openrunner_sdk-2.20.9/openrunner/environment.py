"""Environment capture: Python, OS, GPU, packages, and git info.

Collects a comprehensive snapshot of the runtime environment at
``init()`` time for reproducibility and debugging. All capture
functions are defensive and never raise exceptions.
"""

from __future__ import annotations

import logging
import os
import platform
import socket
import subprocess
import sys
from typing import Any

logger = logging.getLogger("openrunner")


def capture_environment() -> dict[str, Any]:
    """Capture a full environment snapshot.

    Returns a dict with keys:
    - ``python``: Python version and executable path
    - ``os``: Platform, hostname, architecture
    - ``packages``: Installed Python packages (pip freeze equivalent)
    - ``gpu``: NVIDIA GPU info if available (None otherwise)
    - ``cuda``: CUDA version if available (None otherwise)

    All sections are best-effort; failures produce None values
    rather than exceptions.
    """
    env: dict[str, Any] = {}

    env["python"] = _capture_python_info()
    env["os"] = _capture_os_info()
    env["packages"] = _capture_packages()
    env["gpu"] = _capture_gpu_info()
    env["cuda"] = _capture_cuda_version()

    return env


def _capture_python_info() -> dict[str, Any]:
    """Capture Python runtime details."""
    return {
        "version": platform.python_version(),
        "version_full": sys.version,
        "executable": sys.executable,
        "implementation": platform.python_implementation(),
    }


def _capture_os_info() -> dict[str, Any]:
    """Capture operating system and host details."""
    info: dict[str, Any] = {
        "platform": platform.platform(),
        "system": platform.system(),
        "release": platform.release(),
        "machine": platform.machine(),
        "hostname": socket.gethostname(),
    }
    # CPU count
    try:
        info["cpu_count"] = os.cpu_count()
    except Exception:
        info["cpu_count"] = None

    return info


def _capture_packages() -> dict[str, str] | None:
    """Capture installed Python packages as a name->version dict.

    Uses importlib.metadata for an in-process read (no subprocess).
    Falls back to pip freeze if importlib.metadata is unavailable.
    """
    try:
        from importlib.metadata import distributions

        pkgs: dict[str, str] = {}
        for dist in distributions():
            name = dist.metadata.get("Name")
            version = dist.metadata.get("Version")
            if name and version:
                pkgs[name] = version
        return pkgs
    except Exception:
        pass

    # Fallback: pip freeze via subprocess
    try:
        result = subprocess.run(
            [sys.executable, "-m", "pip", "freeze", "--local"],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode == 0:
            pkgs = {}
            for line in result.stdout.strip().splitlines():
                if "==" in line:
                    name, version = line.split("==", 1)
                    pkgs[name.strip()] = version.strip()
            return pkgs
    except Exception:
        pass

    return None


def _capture_gpu_info() -> list[dict[str, str]] | None:
    """Capture NVIDIA GPU info via nvidia-smi.

    Returns a list of dicts with name, memory, driver_version,
    or None if nvidia-smi is not available.
    """
    try:
        result = subprocess.run(
            [
                "nvidia-smi",
                "--query-gpu=name,memory.total,driver_version,gpu_uuid",
                "--format=csv,noheader,nounits",
            ],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None

        gpus: list[dict[str, str]] = []
        for line in result.stdout.strip().splitlines():
            parts = [p.strip() for p in line.split(",")]
            if len(parts) >= 4:
                gpus.append({
                    "name": parts[0],
                    "memory_mb": parts[1],
                    "driver_version": parts[2],
                    "uuid": parts[3],
                })
            elif len(parts) >= 3:
                gpus.append({
                    "name": parts[0],
                    "memory_mb": parts[1],
                    "driver_version": parts[2],
                })
        return gpus if gpus else None
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    except Exception:
        return None


def _capture_cuda_version() -> str | None:
    """Capture the CUDA toolkit version.

    Checks nvcc first, then falls back to nvidia-smi CUDA version.
    """
    # Try nvcc
    try:
        result = subprocess.run(
            ["nvcc", "--version"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if "release" in line.lower():
                    # e.g., "Cuda compilation tools, release 12.1, V12.1.66"
                    parts = line.split("release")
                    if len(parts) > 1:
                        ver = parts[1].strip().rstrip(",").strip()
                        return ver
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    except Exception:
        pass

    # Fallback: nvidia-smi reports CUDA version
    try:
        result = subprocess.run(
            ["nvidia-smi"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode == 0:
            for line in result.stdout.splitlines():
                if "CUDA Version" in line:
                    # e.g., "| CUDA Version: 12.1     |"
                    idx = line.index("CUDA Version:")
                    ver_str = line[idx + len("CUDA Version:"):].strip()
                    ver_str = ver_str.rstrip("|").strip()
                    return ver_str
    except (FileNotFoundError, subprocess.TimeoutExpired):
        pass
    except Exception:
        pass

    return None
