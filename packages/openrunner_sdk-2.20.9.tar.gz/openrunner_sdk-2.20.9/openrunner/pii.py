"""Client-side PII redaction for OpenRunner traces.

Provides regex-based detection and redaction of personally identifiable
information (PII) before trace data leaves the SDK. No external
dependencies are required -- all patterns use the standard ``re`` module.

Usage::

    from openrunner.pii import configure_pii, redact

    # Enable PII redaction globally
    configure_pii(enabled=True)

    # Redact specific entity types
    text = redact("Email me at user@example.com", entity_types=["EMAIL"])
    # -> "Email me at [EMAIL_REDACTED]"

    # Add custom patterns
    configure_pii(
        enabled=True,
        custom_patterns={"EMPLOYEE_ID": r"EMP-\\d{6}"},
    )

Integration with ``openrunner.trace``:
    When PII redaction is enabled via ``configure_pii(enabled=True)``,
    the trace decorator automatically redacts span inputs and outputs
    before sending to the server.
"""

from __future__ import annotations

import logging
import re
from dataclasses import dataclass, field
from typing import Any

logger = logging.getLogger("openrunner.pii")

# ---------------------------------------------------------------------------
# Built-in PII patterns
# ---------------------------------------------------------------------------

# Each pattern maps a human-readable entity type to a compiled regex.
# Patterns are intentionally permissive to catch common formats while
# avoiding false negatives.

_BUILTIN_PATTERNS: dict[str, re.Pattern[str]] = {
    # Standard email addresses
    "EMAIL": re.compile(
        r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
    ),
    # US/international phone numbers (various formats)
    "PHONE": re.compile(
        r"(?<!\d)"                      # not preceded by digit
        r"(?:\+?\d{1,3}[\s\-.]?)?"      # optional country code
        r"(?:\(?\d{2,4}\)?[\s\-.]?)?"   # optional area code
        r"\d{3}[\s\-.]?\d{4}"           # main number
        r"(?!\d)"                       # not followed by digit
    ),
    # US Social Security numbers (XXX-XX-XXXX)
    "SSN": re.compile(
        r"\b\d{3}-\d{2}-\d{4}\b"
    ),
    # Credit card numbers (13-19 digits, with optional separators)
    "CREDIT_CARD": re.compile(
        r"\b"
        r"(?:\d[ \-]?){12,18}\d"
        r"\b"
    ),
    # IPv4 addresses
    "IP_ADDRESS": re.compile(
        r"\b(?:(?:25[0-5]|2[0-4]\d|1?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|1?\d\d?)\b"
    ),
    # AWS access key IDs (start with AKIA, 20 chars)
    "AWS_KEY": re.compile(
        r"\b(?:AKIA|ASIA)[A-Z0-9]{16}\b"
    ),
    # Generic API keys / secrets (long hex or alphanumeric strings preceded
    # by common key-like identifiers)
    "API_KEY": re.compile(
        r"(?i)"
        r"(?:api[_\-]?key|api[_\-]?secret|secret[_\-]?key|access[_\-]?token"
        r"|auth[_\-]?token|bearer)"
        r"[\s:=]*['\"]?"
        r"([A-Za-z0-9\-_./+]{20,})"
        r"['\"]?"
    ),
}

# Default entity types to redact when no explicit list is given
_DEFAULT_ENTITY_TYPES = list(_BUILTIN_PATTERNS.keys())


# ---------------------------------------------------------------------------
# Global configuration
# ---------------------------------------------------------------------------

@dataclass
class _PIIConfig:
    """Internal mutable config singleton."""

    enabled: bool = False
    entity_types: list[str] = field(default_factory=lambda: list(_DEFAULT_ENTITY_TYPES))
    custom_patterns: dict[str, re.Pattern[str]] = field(default_factory=dict)


_config = _PIIConfig()


def configure_pii(
    enabled: bool,
    entity_types: list[str] | None = None,
    custom_patterns: dict[str, str] | None = None,
) -> None:
    """Configure global PII redaction settings.

    Args:
        enabled: If ``True``, PII redaction is applied to trace span
            inputs and outputs before data is sent to the server.
        entity_types: List of entity type names to redact. If ``None``,
            all built-in types are used. Built-in types:
            ``EMAIL``, ``PHONE``, ``SSN``, ``CREDIT_CARD``,
            ``IP_ADDRESS``, ``AWS_KEY``, ``API_KEY``.
        custom_patterns: Dict mapping custom entity type names to regex
            pattern strings. These are compiled and added alongside
            the built-in patterns.

    Example::

        configure_pii(
            enabled=True,
            entity_types=["EMAIL", "SSN"],
            custom_patterns={"EMPLOYEE_ID": r"EMP-\\d{6}"},
        )
    """
    _config.enabled = enabled

    if entity_types is not None:
        _config.entity_types = list(entity_types)
    else:
        _config.entity_types = list(_DEFAULT_ENTITY_TYPES)

    _config.custom_patterns = {}
    if custom_patterns:
        for name, pattern in custom_patterns.items():
            try:
                _config.custom_patterns[name] = re.compile(pattern)
            except re.error as e:
                logger.warning("pii: invalid custom pattern %r: %s", name, e)


def is_pii_enabled() -> bool:
    """Return whether PII redaction is currently enabled."""
    return _config.enabled


# ---------------------------------------------------------------------------
# Redaction
# ---------------------------------------------------------------------------


def redact(
    text: str,
    entity_types: list[str] | None = None,
) -> str:
    """Redact PII from a text string.

    Scans the input for matches against configured patterns and replaces
    each match with a ``[TYPE_REDACTED]`` placeholder.

    Args:
        text: The input text to redact.
        entity_types: Optional list of entity types to check. If ``None``,
            uses the globally configured types (from ``configure_pii``).

    Returns:
        The text with PII replaced by redaction placeholders.

    Example::

        >>> redact("email me at alice@acme.com", entity_types=["EMAIL"])
        'email me at [EMAIL_REDACTED]'
    """
    if not text or not isinstance(text, str):
        return text

    types_to_check = entity_types or _config.entity_types

    for entity_type in types_to_check:
        pattern = _config.custom_patterns.get(entity_type) or _BUILTIN_PATTERNS.get(entity_type)
        if pattern is None:
            continue

        placeholder = f"[{entity_type}_REDACTED]"

        # API_KEY pattern uses a capture group -- redact only the key portion
        if entity_type == "API_KEY":
            text = _redact_api_key(text, pattern, placeholder)
        else:
            text = pattern.sub(placeholder, text)

    return text


def _redact_api_key(text: str, pattern: re.Pattern[str], placeholder: str) -> str:
    """Redact API key values while preserving the key name prefix."""
    def _replacer(match: re.Match[str]) -> str:
        full = match.group(0)
        key_value = match.group(1)
        return full.replace(key_value, placeholder)

    return pattern.sub(_replacer, text)


# ---------------------------------------------------------------------------
# Deep redaction for dicts (used by trace integration)
# ---------------------------------------------------------------------------


def redact_dict(data: dict[str, Any] | Any) -> dict[str, Any] | Any:
    """Recursively redact PII from string values in a dict.

    Non-string, non-dict, non-list values are returned unchanged.
    Only operates when PII redaction is globally enabled.

    Args:
        data: A dict, list, or primitive value to redact.

    Returns:
        A new structure with string values redacted.
    """
    if not _config.enabled:
        return data

    return _deep_redact(data)


def _deep_redact(obj: Any) -> Any:
    """Recursively walk a data structure and redact string values."""
    if isinstance(obj, str):
        return redact(obj)
    if isinstance(obj, dict):
        return {k: _deep_redact(v) for k, v in obj.items()}
    if isinstance(obj, (list, tuple)):
        return type(obj)(_deep_redact(item) for item in obj)
    return obj
