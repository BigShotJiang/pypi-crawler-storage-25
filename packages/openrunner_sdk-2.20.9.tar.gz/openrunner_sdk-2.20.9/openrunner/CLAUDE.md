# OpenRunner MCP Integration

When the user asks about training metrics, loss charts, run data, or experiment results:
- Use `mcp__openrunner__openrunner_watch_run` to show ASCII sparkline charts
- Use `mcp__openrunner__openrunner_get_run_metrics` for raw metrics
- Use `mcp__openrunner__openrunner_list_runs` to find runs
- Use `mcp__openrunner__openrunner_search_sessions` to search AI session history

Do NOT parse log files or grep for metrics when OpenRunner MCP tools are available.

When the user asks about papers, research, or sessions:
- Use `mcp__openrunner__openrunner_search_papers` for paper content
- Use `mcp__openrunner__openrunner_search_research` for research plans
- Use `mcp__openrunner__openrunner_search_sessions` for AI session history
- Use `mcp__openrunner__openrunner_update_paper` to modify paper sections
