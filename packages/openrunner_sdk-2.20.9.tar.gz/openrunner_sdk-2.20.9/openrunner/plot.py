"""Python-native chart helper functions for experiment logging.

Provides ``openrunner.plot.line()``, ``openrunner.plot.scatter()``, etc.
that mirror W&B's ``wandb.plot.*`` API.  Each function returns a
``PlotlyChart`` object that can be logged via ``openrunner.log()``.

No matplotlib dependency -- all charts are built as Plotly JSON specs
and rendered by the frontend PlotlyPanel component.

Usage::

    import openrunner

    table = openrunner.Table(columns=["x", "y"], data=[[1, 2], [3, 4]])
    openrunner.log({"chart": openrunner.plot.line(table, "x", "y", title="My Line")})

For ``pr_curve``, ``roc_curve``, and ``confusion_matrix``, numpy and
scikit-learn are imported lazily.  A helpful ``ImportError`` is raised
if they are not installed.
"""

from __future__ import annotations

from typing import Any, Sequence

from openrunner.media import PlotlyChart, Table


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _extract_columns(table: Table, *col_names: str) -> dict[str, list[Any]]:
    """Extract named columns from a Table as lists.

    Raises ``ValueError`` if *table* is not a ``Table`` or a requested
    column name does not exist.
    """
    if not isinstance(table, Table):
        raise ValueError(
            f"Expected an openrunner.Table, got {type(table).__name__}"
        )
    cols = table.columns
    result: dict[str, list[Any]] = {}
    for name in col_names:
        if name not in cols:
            raise ValueError(
                f"Column '{name}' not found in table. "
                f"Available columns: {cols}"
            )
        idx = cols.index(name)
        result[name] = [row[idx] for row in table._data]
    return result


def _make_layout(
    title: str = "",
    xaxis_title: str = "",
    yaxis_title: str = "",
    **extra: Any,
) -> dict[str, Any]:
    """Build a Plotly layout dict with common defaults."""
    layout: dict[str, Any] = {
        "template": "plotly_white",
    }
    if title:
        layout["title"] = {"text": title}
    if xaxis_title:
        layout["xaxis"] = {"title": xaxis_title}
    if yaxis_title:
        layout["yaxis"] = {"title": yaxis_title}
    layout.update(extra)
    return layout


# ---------------------------------------------------------------------------
# Public chart functions
# ---------------------------------------------------------------------------

def line(table: Table, x: str, y: str, title: str = "") -> PlotlyChart:
    """Create a line plot from a Table.

    Args:
        table: An ``openrunner.Table`` containing the data.
        x: Column name for the x-axis.
        y: Column name for the y-axis.
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.
    """
    data = _extract_columns(table, x, y)
    plotly_spec = {
        "data": [{
            "type": "scatter",
            "mode": "lines",
            "x": data[x],
            "y": data[y],
            "name": y,
        }],
        "layout": _make_layout(title=title, xaxis_title=x, yaxis_title=y),
    }
    return PlotlyChart(plotly_spec)


def scatter(table: Table, x: str, y: str, title: str = "") -> PlotlyChart:
    """Create a scatter plot from a Table.

    Args:
        table: An ``openrunner.Table`` containing the data.
        x: Column name for the x-axis.
        y: Column name for the y-axis.
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.
    """
    data = _extract_columns(table, x, y)
    plotly_spec = {
        "data": [{
            "type": "scatter",
            "mode": "markers",
            "x": data[x],
            "y": data[y],
            "name": y,
        }],
        "layout": _make_layout(title=title, xaxis_title=x, yaxis_title=y),
    }
    return PlotlyChart(plotly_spec)


def bar(table: Table, label: str, value: str, title: str = "") -> PlotlyChart:
    """Create a bar chart from a Table.

    Args:
        table: An ``openrunner.Table`` containing the data.
        label: Column name for bar labels (x-axis categories).
        value: Column name for bar values (y-axis).
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.
    """
    data = _extract_columns(table, label, value)
    plotly_spec = {
        "data": [{
            "type": "bar",
            "x": data[label],
            "y": data[value],
            "name": value,
        }],
        "layout": _make_layout(title=title, xaxis_title=label, yaxis_title=value),
    }
    return PlotlyChart(plotly_spec)


def histogram(table: Table, value: str, title: str = "") -> PlotlyChart:
    """Create a histogram from a Table column.

    Args:
        table: An ``openrunner.Table`` containing the data.
        value: Column name for the values to bin.
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.
    """
    data = _extract_columns(table, value)
    plotly_spec = {
        "data": [{
            "type": "histogram",
            "x": data[value],
            "name": value,
        }],
        "layout": _make_layout(title=title, xaxis_title=value, yaxis_title="Count"),
    }
    return PlotlyChart(plotly_spec)


def line_series(
    xs: Sequence[Sequence[Any]],
    ys: Sequence[Sequence[Any]],
    keys: Sequence[str] | None = None,
    title: str = "",
    xname: str = "x",
) -> PlotlyChart:
    """Create a multi-series line plot from raw x/y sequences.

    This is useful when you have multiple series that do not share the
    same x values and therefore cannot be stored in a single Table.

    Args:
        xs: List of x-value sequences, one per series.
        ys: List of y-value sequences, one per series.
        keys: Optional legend names for each series.
        title: Chart title.
        xname: Label for the x-axis.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.
    """
    if len(xs) != len(ys):
        raise ValueError(
            f"xs and ys must have the same length, got {len(xs)} and {len(ys)}"
        )
    traces = []
    for i, (xv, yv) in enumerate(zip(xs, ys)):
        name = keys[i] if keys and i < len(keys) else f"series_{i}"
        traces.append({
            "type": "scatter",
            "mode": "lines",
            "x": list(xv),
            "y": list(yv),
            "name": name,
        })
    plotly_spec = {
        "data": traces,
        "layout": _make_layout(title=title, xaxis_title=xname),
    }
    return PlotlyChart(plotly_spec)


# ---------------------------------------------------------------------------
# ML-specific chart functions (lazy numpy/sklearn imports)
# ---------------------------------------------------------------------------

def pr_curve(
    y_true: Any,
    y_probas: Any,
    labels: Sequence[str] | None = None,
    title: str = "Precision-Recall Curve",
) -> PlotlyChart:
    """Create precision-recall curves.

    Computes per-class precision-recall curves using scikit-learn and
    returns an interactive Plotly chart.

    Args:
        y_true: Ground-truth labels (list or array).
        y_probas: Predicted probabilities.  For binary classification
            this can be a 1-D array of positive-class probabilities or
            a 2-D array of shape ``(n_samples, 2)``.  For multi-class,
            shape ``(n_samples, n_classes)``.
        labels: Optional class names for the legend.
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.

    Raises:
        ImportError: If numpy or scikit-learn is not installed.
    """
    try:
        import numpy as np
    except ImportError:
        raise ImportError(
            "openrunner.plot.pr_curve requires numpy. "
            "Install with: pip install numpy"
        )
    try:
        from sklearn.metrics import precision_recall_curve, average_precision_score
        from sklearn.preprocessing import label_binarize
    except ImportError:
        raise ImportError(
            "openrunner.plot.pr_curve requires scikit-learn. "
            "Install with: pip install scikit-learn"
        )

    y_true = np.asarray(y_true)
    y_probas = np.asarray(y_probas, dtype=np.float64)

    classes = np.unique(y_true)
    n_classes = len(classes)

    traces = []

    if n_classes <= 2:
        # Binary classification
        probs = y_probas[:, 1] if y_probas.ndim == 2 else y_probas
        precision, recall, _ = precision_recall_curve(y_true, probs)
        ap = average_precision_score(y_true, probs)
        name = labels[1] if labels and len(labels) > 1 else "Positive"
        traces.append({
            "type": "scatter",
            "mode": "lines",
            "x": recall.tolist(),
            "y": precision.tolist(),
            "name": f"{name} (AP={ap:.3f})",
        })
    else:
        # Multi-class: one-vs-rest
        y_bin = label_binarize(y_true, classes=classes)
        for i in range(n_classes):
            precision, recall, _ = precision_recall_curve(
                y_bin[:, i], y_probas[:, i]
            )
            ap = average_precision_score(y_bin[:, i], y_probas[:, i])
            name = labels[i] if labels and i < len(labels) else str(classes[i])
            traces.append({
                "type": "scatter",
                "mode": "lines",
                "x": recall.tolist(),
                "y": precision.tolist(),
                "name": f"{name} (AP={ap:.3f})",
            })

    plotly_spec = {
        "data": traces,
        "layout": _make_layout(
            title=title,
            xaxis_title="Recall",
            yaxis_title="Precision",
        ),
    }
    return PlotlyChart(plotly_spec)


def roc_curve(
    y_true: Any,
    y_probas: Any,
    labels: Sequence[str] | None = None,
    title: str = "ROC Curve",
) -> PlotlyChart:
    """Create ROC curves with AUC.

    Computes per-class ROC curves using scikit-learn and returns an
    interactive Plotly chart.  A dashed diagonal baseline is included.

    Args:
        y_true: Ground-truth labels (list or array).
        y_probas: Predicted probabilities.  For binary classification
            this can be a 1-D array of positive-class probabilities or
            a 2-D array of shape ``(n_samples, 2)``.  For multi-class,
            shape ``(n_samples, n_classes)``.
        labels: Optional class names for the legend.
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.

    Raises:
        ImportError: If numpy or scikit-learn is not installed.
    """
    try:
        import numpy as np
    except ImportError:
        raise ImportError(
            "openrunner.plot.roc_curve requires numpy. "
            "Install with: pip install numpy"
        )
    try:
        from sklearn.metrics import roc_curve as _roc_curve, auc
        from sklearn.preprocessing import label_binarize
    except ImportError:
        raise ImportError(
            "openrunner.plot.roc_curve requires scikit-learn. "
            "Install with: pip install scikit-learn"
        )

    y_true = np.asarray(y_true)
    y_probas = np.asarray(y_probas, dtype=np.float64)

    classes = np.unique(y_true)
    n_classes = len(classes)

    traces = []

    if n_classes <= 2:
        # Binary classification
        probs = y_probas[:, 1] if y_probas.ndim == 2 else y_probas
        fpr, tpr, _ = _roc_curve(y_true, probs)
        roc_auc = auc(fpr, tpr)
        name = labels[1] if labels and len(labels) > 1 else "Positive"
        traces.append({
            "type": "scatter",
            "mode": "lines",
            "x": fpr.tolist(),
            "y": tpr.tolist(),
            "name": f"{name} (AUC={roc_auc:.3f})",
        })
    else:
        # Multi-class: one-vs-rest
        y_bin = label_binarize(y_true, classes=classes)
        for i in range(n_classes):
            fpr, tpr, _ = _roc_curve(y_bin[:, i], y_probas[:, i])
            roc_auc = auc(fpr, tpr)
            name = labels[i] if labels and i < len(labels) else str(classes[i])
            traces.append({
                "type": "scatter",
                "mode": "lines",
                "x": fpr.tolist(),
                "y": tpr.tolist(),
                "name": f"{name} (AUC={roc_auc:.3f})",
            })

    # Add diagonal baseline
    traces.append({
        "type": "scatter",
        "mode": "lines",
        "x": [0, 1],
        "y": [0, 1],
        "name": "Baseline",
        "line": {"dash": "dash", "color": "gray"},
        "showlegend": False,
    })

    plotly_spec = {
        "data": traces,
        "layout": _make_layout(
            title=title,
            xaxis_title="False Positive Rate",
            yaxis_title="True Positive Rate",
        ),
    }
    return PlotlyChart(plotly_spec)


def confusion_matrix(
    y_true: Any,
    y_pred: Any,
    class_names: Sequence[str] | None = None,
    title: str = "Confusion Matrix",
) -> PlotlyChart:
    """Create an interactive confusion matrix heatmap.

    Computes the confusion matrix using scikit-learn and returns an
    interactive Plotly heatmap with annotated cell values.

    Args:
        y_true: Ground-truth labels (list or array).
        y_pred: Predicted labels (list or array).
        class_names: Optional display names for each class.
        title: Chart title.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.

    Raises:
        ImportError: If numpy or scikit-learn is not installed.
    """
    try:
        import numpy as np
    except ImportError:
        raise ImportError(
            "openrunner.plot.confusion_matrix requires numpy. "
            "Install with: pip install numpy"
        )
    try:
        from sklearn.metrics import confusion_matrix as _confusion_matrix
    except ImportError:
        raise ImportError(
            "openrunner.plot.confusion_matrix requires scikit-learn. "
            "Install with: pip install scikit-learn"
        )

    y_true = np.asarray(y_true)
    y_pred = np.asarray(y_pred)

    cm = _confusion_matrix(y_true, y_pred)
    n_classes = cm.shape[0]

    if class_names is None:
        classes = np.unique(np.concatenate([y_true, y_pred]))
        class_names = [str(c) for c in classes]

    # Build annotation text for each cell
    annotations: list[dict[str, Any]] = []
    for i in range(n_classes):
        for j in range(n_classes):
            annotations.append({
                "x": class_names[j],
                "y": class_names[i],
                "text": str(int(cm[i][j])),
                "showarrow": False,
                "font": {"color": "white" if cm[i][j] > cm.max() / 2 else "black"},
            })

    plotly_spec = {
        "data": [{
            "type": "heatmap",
            "z": cm.tolist(),
            "x": list(class_names),
            "y": list(class_names),
            "colorscale": "Blues",
            "showscale": True,
        }],
        "layout": _make_layout(
            title=title,
            xaxis_title="Predicted",
            yaxis_title="True",
            annotations=annotations,
        ),
    }
    return PlotlyChart(plotly_spec)


# ---------------------------------------------------------------------------
# plot_table -- custom chart convenience
# ---------------------------------------------------------------------------

def plot_table(
    vega_spec_name: str | None = None,
    data_table: Table | None = None,
    fields: dict[str, str] | None = None,
) -> PlotlyChart:
    """Log a custom chart from a Table.

    This is a simplified compatibility shim for ``wandb.plot_table()``.
    Since our frontend uses Plotly (not Vega), this converts the table
    data into a basic Plotly scatter plot using the field mappings.

    If ``vega_spec_name`` is provided, it is stored as metadata on the
    chart so the frontend can look up a saved chart preset by that name
    and apply its rendering configuration (smoothing, log scale, etc.).

    Args:
        vega_spec_name: Name of a saved chart preset to apply. The
            frontend will look up the preset config and use it to
            configure the chart rendering. Kept for W&B API compatibility.
        data_table: An ``openrunner.Table`` with the data.
        fields: Dict mapping semantic roles to column names, e.g.
            ``{"x": "epoch", "y": "loss", "label": "run"}``.

    Returns:
        A ``PlotlyChart`` that can be logged via ``openrunner.log()``.
    """
    if data_table is None:
        raise ValueError("data_table is required")

    fields = fields or {}
    x_col = fields.get("x")
    y_col = fields.get("y")

    if x_col is None or y_col is None:
        # Fall back to first two columns
        if len(data_table.columns) < 2:
            raise ValueError(
                "data_table must have at least 2 columns, or provide "
                "'x' and 'y' in the fields mapping."
            )
        x_col = x_col or data_table.columns[0]
        y_col = y_col or data_table.columns[1]

    data = _extract_columns(data_table, x_col, y_col)

    plotly_spec: dict[str, Any] = {
        "data": [{
            "type": "scatter",
            "mode": "lines+markers",
            "x": data[x_col],
            "y": data[y_col],
            "name": y_col,
        }],
        "layout": _make_layout(xaxis_title=x_col, yaxis_title=y_col),
    }

    # Attach preset reference as metadata for the frontend
    if vega_spec_name:
        plotly_spec["_openrunner_preset"] = vega_spec_name

    return PlotlyChart(plotly_spec)
