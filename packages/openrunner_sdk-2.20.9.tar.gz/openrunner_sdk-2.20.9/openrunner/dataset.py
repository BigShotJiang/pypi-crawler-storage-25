"""Dataset management for evaluations.

Provides a versioned Dataset class that integrates with the
evaluation framework and artifact storage.
"""

from __future__ import annotations

import json
import logging
import os
import tempfile
from typing import Any

logger = logging.getLogger("openrunner")


class Dataset:
    """A versioned collection of examples for evaluation.

    Usage::

        import openrunner

        ds = openrunner.Dataset(
            name="my-eval-set",
            rows=[
                {"input": "Hello", "expected": "Hi there"},
                {"input": "Bye", "expected": "Goodbye"},
            ],
        )

        # Or from pandas
        ds = openrunner.Dataset.from_pandas(df, name="my-dataset")

        # Use in evaluation
        results = openrunner.evaluate(model_fn, dataset=ds, scorers=[...])

    Args:
        name: Name for the dataset (used as artifact name when saving).
        rows: Optional list of example dicts.
    """

    def __init__(self, name: str, rows: list[dict] | None = None) -> None:
        self.name = name
        self._rows: list[dict] = rows or []

    @classmethod
    def from_pandas(cls, df: Any, name: str = "dataset") -> Dataset:
        """Create a Dataset from a pandas DataFrame.

        Args:
            df: A pandas DataFrame.
            name: Name for the dataset.

        Returns:
            A new Dataset instance.
        """
        rows = df.to_dict(orient="records")
        return cls(name=name, rows=rows)

    @classmethod
    def from_list(cls, data: list[dict], name: str = "dataset") -> Dataset:
        """Create a Dataset from a list of dicts.

        Args:
            data: List of example dicts.
            name: Name for the dataset.

        Returns:
            A new Dataset instance.
        """
        return cls(name=name, rows=data)

    def __len__(self) -> int:
        return len(self._rows)

    def __iter__(self):
        return iter(self._rows)

    def __getitem__(self, idx: int) -> dict:
        return self._rows[idx]

    def add(self, row: dict) -> None:
        """Add a single example row to the dataset.

        Args:
            row: A dict representing one example.
        """
        self._rows.append(row)

    def to_table(self):
        """Convert the dataset to a Table for logging.

        Returns:
            An openrunner.Table instance.
        """
        from openrunner.media import Table

        if not self._rows:
            return Table(columns=[], data=[])
        columns = list(self._rows[0].keys())
        data = [[row.get(c) for c in columns] for row in self._rows]
        return Table(columns=columns, data=data)

    def save(self) -> None:
        """Save dataset as a versioned artifact.

        Requires an active OpenRunner run. The dataset is stored as a
        JSONL artifact of type ``"dataset"``.
        """
        import openrunner
        from openrunner.artifact import Artifact

        if openrunner._active_run is None:
            logger.warning("Dataset.save(): no active run -- call openrunner.init() first")
            return

        artifact = Artifact(
            name=self.name,
            type="dataset",
            metadata={"row_count": len(self._rows)},
        )

        # Save as JSONL temp file
        fd, temp_path = tempfile.mkstemp(suffix=".jsonl")
        try:
            with os.fdopen(fd, "w") as f:
                for row in self._rows:
                    f.write(json.dumps(row, default=str) + "\n")

            artifact.add_file(temp_path, name="data.jsonl")
            openrunner._active_run.log_artifact(artifact)
        finally:
            try:
                os.unlink(temp_path)
            except OSError:
                pass
