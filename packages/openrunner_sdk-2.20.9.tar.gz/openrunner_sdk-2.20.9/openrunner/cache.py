"""LRU artifact cache with configurable size limit.

Downloaded artifact files are cached locally by content hash.
When the cache exceeds its size limit, the oldest-accessed files
are evicted until the cache is at 80% capacity.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path

logger = logging.getLogger("openrunner")


class ArtifactCache:
    """Local file cache for downloaded artifact files, keyed by content hash.

    Uses access time (atime) for LRU ordering and evicts oldest files
    when the cache exceeds the configured maximum size.
    """

    def __init__(
        self,
        cache_dir: str | None = None,
        max_size_gb: float = 10.0,
    ) -> None:
        self._dir = Path(cache_dir or os.path.expanduser("~/.openrunner/artifacts"))
        self._dir.mkdir(parents=True, exist_ok=True)
        self._max_size = int(max_size_gb * 1024**3)

    def get(self, content_hash: str) -> Path | None:
        """Return the cached file path if it exists, or None.

        Touches the file's access time to mark it as recently used.
        """
        path = self._dir / content_hash
        if path.exists():
            # Touch atime for LRU ordering
            try:
                os.utime(path)
            except OSError:
                pass
            return path
        return None

    def put(self, content_hash: str, data: bytes) -> Path:
        """Write data to the cache and return the file path.

        May trigger eviction if the cache exceeds its size limit.
        """
        path = self._dir / content_hash
        path.write_bytes(data)
        self._maybe_evict()
        return path

    def _current_size(self) -> int:
        """Compute total size of all cached files in bytes."""
        total = 0
        for f in self._dir.iterdir():
            if f.is_file():
                total += f.stat().st_size
        return total

    def _maybe_evict(self) -> None:
        """Evict oldest-accessed files until cache is at 80% of max capacity."""
        current = self._current_size()
        if current <= self._max_size:
            return

        target = int(self._max_size * 0.8)

        # Collect files with their access times
        files: list[tuple[float, int, Path]] = []
        for f in self._dir.iterdir():
            if f.is_file():
                stat = f.stat()
                files.append((stat.st_atime, stat.st_size, f))

        # Sort by access time ascending (oldest first)
        files.sort(key=lambda x: x[0])

        for _atime, size, path in files:
            if current <= target:
                break
            try:
                path.unlink()
                current -= size
                logger.debug("Evicted cached artifact: %s (%d bytes)", path.name, size)
            except OSError as e:
                logger.warning("Failed to evict cached file %s: %s", path, e)
