"""TensorBoard log importer for OpenRunner.

Reads TensorBoard event files and uploads them as OpenRunner metrics.
"""

import os
import logging
from typing import Any

logger = logging.getLogger("openrunner")


def sync_tensorboard(
    logdir: str,
    run: Any = None,
    root_logdir: str | None = None,
    project: str | None = None,
) -> Any:
    """Import TensorBoard event files into an OpenRunner run.

    Reads scalar metrics from TensorBoard event files and logs them
    to an OpenRunner run. Creates a new run if one is not provided.

    Args:
        logdir: Path to TensorBoard log directory containing event files.
        run: Optional active OpenRunner run. Creates one if ``None``.
        root_logdir: Root directory for relative path computation
            (unused, reserved for future multi-run import).
        project: Project name (used when creating a new run).

    Returns:
        The OpenRunner run object (existing or newly created).

    Raises:
        ImportError: If ``tensorboard`` is not installed.
        FileNotFoundError: If ``logdir`` does not exist.
    """
    try:
        from tensorboard.backend.event_processing.event_accumulator import EventAccumulator
    except ImportError:
        raise ImportError(
            "sync_tensorboard requires tensorboard. "
            "Install with: pip install tensorboard"
        )

    if not os.path.isdir(logdir):
        raise FileNotFoundError(f"TensorBoard log directory not found: {logdir}")

    import openrunner

    if run is None:
        run = openrunner.init(project=project or "tensorboard-import")

    ea = EventAccumulator(logdir)
    ea.Reload()

    scalar_tags = ea.Tags().get("scalars", [])

    # Import scalar metrics
    for tag in scalar_tags:
        events = ea.Scalars(tag)
        for event in events:
            openrunner.log(
                {tag: event.value},
                step=event.step,
                commit=False,
            )

    # Commit final step
    openrunner.log({}, commit=True)

    logger.info(
        "Imported %d scalar tags from %s",
        len(scalar_tags),
        logdir,
    )
    return run
