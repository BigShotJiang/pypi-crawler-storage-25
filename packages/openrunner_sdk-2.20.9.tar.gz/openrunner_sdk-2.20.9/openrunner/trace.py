"""LLM call tracing -- @openrunner.trace decorator.

Provides the ``@trace`` decorator for capturing function inputs, outputs,
timing, and errors. Supports sync and async functions with automatic span
nesting via thread-local/contextvars context.

Usage:
    import openrunner

    @openrunner.trace
    def my_llm_call(prompt: str) -> str:
        return openai.chat.completions.create(...)

    @openrunner.trace
    async def my_async_call(prompt: str) -> str:
        return await openai.chat.completions.create(...)

    # Auto-patch OpenAI
    openrunner.trace.patch_openai()
"""

from __future__ import annotations

import asyncio
import contextvars
import functools
import hashlib
import inspect
import json
import logging
import threading
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Callable, Literal, TypeVar

logger = logging.getLogger("openrunner")

F = TypeVar("F", bound=Callable[..., Any])

# ---------------------------------------------------------------------------
# Context management for span nesting
# ---------------------------------------------------------------------------

# Context var for async span nesting
_current_trace_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_current_trace_id", default=None
)
_current_span_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_current_span_id", default=None
)

# Thread/session grouping context vars (Gap #5)
_current_thread_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_current_thread_id", default=None
)
_current_session_id: contextvars.ContextVar[str | None] = contextvars.ContextVar(
    "_current_session_id", default=None
)

# Thread-local fallback for sync functions
_thread_local = threading.local()


def _get_trace_id() -> str | None:
    """Get the current trace ID from context or thread-local."""
    val = _current_trace_id.get(None)
    if val is not None:
        return val
    return getattr(_thread_local, "trace_id", None)


def _set_trace_id(trace_id: str | None) -> None:
    """Set the current trace ID in both context and thread-local."""
    _current_trace_id.set(trace_id)
    _thread_local.trace_id = trace_id


def _get_parent_span_id() -> str | None:
    """Get the current parent span ID from context or thread-local."""
    val = _current_span_id.get(None)
    if val is not None:
        return val
    return getattr(_thread_local, "span_id", None)


def _set_parent_span_id(span_id: str | None) -> None:
    """Set the current span ID in both context and thread-local."""
    _current_span_id.set(span_id)
    _thread_local.span_id = span_id


# ---------------------------------------------------------------------------
# Thread/session grouping (Gap #5)
# ---------------------------------------------------------------------------


def set_thread_id(thread_id: str | None) -> None:
    """Set the thread ID for multi-turn conversation grouping.

    All subsequent traced calls will include this thread_id in their
    span data until it is cleared (set to ``None``).

    Args:
        thread_id: A string identifier for the conversation thread,
            or ``None`` to clear.
    """
    _current_thread_id.set(thread_id)
    _thread_local.thread_id = thread_id


def set_session_id(session_id: str | None) -> None:
    """Set the session ID for multi-turn conversation grouping.

    All subsequent traced calls will include this session_id in their
    span data until it is cleared (set to ``None``).

    Args:
        session_id: A string identifier for the session,
            or ``None`` to clear.
    """
    _current_session_id.set(session_id)
    _thread_local.session_id = session_id


def _get_thread_id() -> str | None:
    """Get the current thread ID from context or thread-local."""
    val = _current_thread_id.get(None)
    if val is not None:
        return val
    return getattr(_thread_local, "thread_id", None)


def _get_session_id() -> str | None:
    """Get the current session ID from context or thread-local."""
    val = _current_session_id.get(None)
    if val is not None:
        return val
    return getattr(_thread_local, "session_id", None)


# ---------------------------------------------------------------------------
# Op versioning (Gap #1)
# ---------------------------------------------------------------------------


def _compute_op_version(func: Callable) -> str:
    """Compute a version hash for a function based on its source code.

    Combines the function's qualified name, module, and source code into
    a stable hash. Falls back to a hash of just the name/module if source
    is unavailable (e.g., built-ins, C extensions).

    Returns:
        A hex digest string (first 12 chars of SHA-256).
    """
    parts = [
        func.__module__ or "",
        func.__qualname__,
    ]
    try:
        parts.append(inspect.getsource(func))
    except (OSError, TypeError):
        # Source unavailable -- version based on name/module only
        pass
    content = "\n".join(parts)
    return hashlib.sha256(content.encode("utf-8")).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Data classes
# ---------------------------------------------------------------------------


@dataclass
class SpanData:
    """Captured data for a single span (function call)."""

    id: str
    trace_id: str
    parent_id: str | None
    name: str
    inputs: dict[str, Any] | None = None
    outputs: dict[str, Any] | None = None
    status: str = "success"
    start_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    end_time: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    duration_ms: float = 0.0
    metadata: dict[str, Any] | None = None
    error: str | None = None
    # Op versioning (Gap #1)
    op_version: str | None = None
    # Op display customization (Gap #2)
    kind: str | None = None
    color: str | None = None
    # Thread/session grouping (Gap #5)
    thread_id: str | None = None
    session_id: str | None = None

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for API submission."""
        d: dict[str, Any] = {
            "id": self.id,
            "parent_id": self.parent_id,
            "name": self.name,
            "inputs": self.inputs,
            "outputs": self.outputs,
            "status": self.status,
            "start_time": self.start_time.isoformat(),
            "end_time": self.end_time.isoformat(),
            "duration_ms": self.duration_ms,
            "metadata": self.metadata,
            "error": self.error,
        }
        # Include optional fields only when set (keep payloads lean)
        if self.op_version is not None:
            d["op_version"] = self.op_version
        if self.kind is not None:
            d["kind"] = self.kind
        if self.color is not None:
            d["color"] = self.color
        if self.thread_id is not None:
            d["thread_id"] = self.thread_id
        if self.session_id is not None:
            d["session_id"] = self.session_id
        return d


@dataclass
class TraceData:
    """Captured data for a complete trace."""

    id: str
    name: str
    project: str | None = None
    created_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    spans: list[SpanData] = field(default_factory=list)

    def to_dict(self) -> dict[str, Any]:
        """Serialize to dict for API submission."""
        return {
            "id": self.id,
            "name": self.name,
            "spans": [s.to_dict() for s in self.spans],
        }


# ---------------------------------------------------------------------------
# Trace collector (accumulates spans for a trace, sends on completion)
# ---------------------------------------------------------------------------

# Global trace store: trace_id -> TraceData
_active_traces: dict[str, TraceData] = {}
_traces_lock = threading.Lock()


def _register_span(span: SpanData) -> None:
    """Register a completed span with its parent trace."""
    with _traces_lock:
        trace = _active_traces.get(span.trace_id)
        if trace is not None:
            trace.spans.append(span)


def _start_trace(name: str) -> TraceData:
    """Start a new trace. Called when a root span begins."""
    trace = TraceData(
        id=str(uuid.uuid4()),
        name=name,
    )
    with _traces_lock:
        _active_traces[trace.id] = trace
    return trace


def _finish_trace(trace_id: str) -> TraceData | None:
    """Finish a trace and remove from active traces. Returns the trace data."""
    with _traces_lock:
        return _active_traces.pop(trace_id, None)


# ---------------------------------------------------------------------------
# Background sender
# ---------------------------------------------------------------------------

_send_queue: list[TraceData] = []
_send_lock = threading.Lock()
_sender_thread: threading.Thread | None = None
_sender_stop = threading.Event()


def _get_api_client():
    """Lazily get the API client from the active run, if available."""
    try:
        import openrunner
        if openrunner._active_run is not None:
            return openrunner._active_run._client, openrunner._active_run._project_id
    except Exception:
        pass
    return None, None


def _apply_pii_redaction(trace: TraceData) -> None:
    """Apply PII redaction to all spans in a trace, if enabled."""
    try:
        from openrunner.pii import is_pii_enabled, redact_dict

        if not is_pii_enabled():
            return
        for span in trace.spans:
            if span.inputs:
                span.inputs = redact_dict(span.inputs)
            if span.outputs:
                span.outputs = redact_dict(span.outputs)
    except ImportError:
        pass
    except Exception as e:
        logger.debug("pii redaction failed: %s", e)


def _send_trace(trace: TraceData) -> None:
    """Send a completed trace to the server via background thread."""
    _apply_pii_redaction(trace)

    with _send_lock:
        _send_queue.append(trace)

    _ensure_sender()


def _ensure_sender() -> None:
    """Start the background sender thread if not running."""
    global _sender_thread
    if _sender_thread is not None and _sender_thread.is_alive():
        return

    _sender_stop.clear()
    _sender_thread = threading.Thread(
        target=_sender_loop,
        daemon=True,
        name="openrunner-trace-sender",
    )
    _sender_thread.start()


def _sender_loop() -> None:
    """Background loop that sends queued traces."""
    while not _sender_stop.is_set():
        with _send_lock:
            batch = list(_send_queue)
            _send_queue.clear()

        if not batch:
            _sender_stop.wait(timeout=0.5)
            continue

        client, project_id = _get_api_client()
        if client is None or project_id is None:
            logger.debug("trace sender: no active run, discarding %d traces", len(batch))
            continue

        for trace in batch:
            try:
                client.post_trace(str(project_id), trace.to_dict())
            except Exception as e:
                logger.debug("trace sender failed: %s", e)


# ---------------------------------------------------------------------------
# Safe serialization
# ---------------------------------------------------------------------------


def _safe_serialize(obj: Any) -> Any:
    """Safely serialize an object to a JSON-compatible structure.

    Handles common types: dicts, lists, primitives, dataclasses.
    Falls back to str() for unrecognized types.
    """
    if obj is None:
        return None
    if isinstance(obj, (str, int, float, bool)):
        return obj
    if isinstance(obj, (list, tuple)):
        return [_safe_serialize(item) for item in obj[:100]]  # Cap list length
    if isinstance(obj, dict):
        return {str(k): _safe_serialize(v) for k, v in list(obj.items())[:50]}  # Cap dict size
    if hasattr(obj, "__dict__"):
        return _safe_serialize(vars(obj))
    try:
        json.dumps(obj)
        return obj
    except (TypeError, ValueError):
        return str(obj)[:1000]  # Truncate long strings


def _capture_inputs(func: Callable, args: tuple, kwargs: dict) -> dict[str, Any]:
    """Capture function inputs as a serializable dict."""
    sig = inspect.signature(func)
    bound = sig.bind(*args, **kwargs)
    bound.apply_defaults()
    return {k: _safe_serialize(v) for k, v in bound.arguments.items()}


def _capture_output(result: Any) -> dict[str, Any]:
    """Capture function output as a serializable dict."""
    return {"result": _safe_serialize(result)}


# ---------------------------------------------------------------------------
# The @trace decorator
# ---------------------------------------------------------------------------


# Valid values for the ``kind`` parameter (Gap #2).
_VALID_KINDS = frozenset({
    "agent", "llm", "tool", "search", "chain",
    "embedding", "retriever", "parser", None,
})

# Valid values for the ``color`` parameter (Gap #2).
_VALID_COLORS = frozenset({
    "red", "orange", "yellow", "green", "blue", "purple", None,
})


def trace(
    func: F | None = None,
    *,
    name: str | None = None,
    sample_rate: float = 1.0,
    kind: str | None = None,
    color: str | None = None,
    postprocess_inputs: Callable[[dict], dict] | None = None,
    postprocess_output: Callable[[Any], Any] | None = None,
    thread_id: str | None = None,
    session_id: str | None = None,
) -> F | Callable[[F], F]:
    """Decorator that traces a function call.

    Captures inputs, outputs, timing, and errors. Supports both sync
    and async functions. Creates nested spans when traced functions call
    other traced functions.

    Can be used with or without arguments::

        @trace
        def my_func(): ...

        @trace(name="custom_name", sample_rate=0.1)
        def my_func(): ...

        @trace(kind="llm", color="blue")
        def call_model(prompt): ...

        @trace(postprocess_inputs=lambda d: {k: "***" if "key" in k else v for k, v in d.items()})
        def secret_func(api_key, data): ...

    Args:
        func: The function to trace (when used without parentheses).
        name: Custom name for the trace span.
        sample_rate: Fraction of calls to trace (0.0-1.0). Default 1.0 (all).
        kind: Span kind for display grouping. One of ``"agent"``,
            ``"llm"``, ``"tool"``, ``"search"``, ``"chain"``,
            ``"embedding"``, ``"retriever"``, ``"parser"``, or ``None``.
        color: Span color hint. One of ``"red"``, ``"orange"``,
            ``"yellow"``, ``"green"``, ``"blue"``, ``"purple"``, or ``None``.
        postprocess_inputs: Callable that transforms the captured inputs
            dict before it is logged (e.g., to redact secrets).
        postprocess_output: Callable that transforms the captured output
            before it is logged.
        thread_id: Explicit thread ID to attach to spans created by this
            decorated function. Overrides the module-level thread ID.
        session_id: Explicit session ID to attach to spans created by this
            decorated function. Overrides the module-level session ID.
    """
    if func is None:
        # Called with arguments: @trace(name="...", sample_rate=...)
        return lambda f: trace(
            f,
            name=name,
            sample_rate=sample_rate,
            kind=kind,
            color=color,
            postprocess_inputs=postprocess_inputs,
            postprocess_output=postprocess_output,
            thread_id=thread_id,
            session_id=session_id,
        )

    # Validate kind/color early so mis-use is caught at decoration time
    if kind not in _VALID_KINDS:
        raise ValueError(
            f"Invalid kind={kind!r}. Must be one of {sorted(k for k in _VALID_KINDS if k)}."
        )
    if color not in _VALID_COLORS:
        raise ValueError(
            f"Invalid color={color!r}. Must be one of {sorted(c for c in _VALID_COLORS if c)}."
        )

    span_name = name or func.__qualname__

    # Compute op version once at decoration time (Gap #1)
    op_version = _compute_op_version(func)

    if asyncio.iscoroutinefunction(func):
        @functools.wraps(func)
        async def async_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Sample rate check -- skip tracing for unsampled calls
            if sample_rate < 1.0:
                import random
                if random.random() > sample_rate:
                    return await func(*args, **kwargs)

            # Determine if this is a root span (new trace) or nested
            existing_trace_id = _get_trace_id()
            parent_span_id = _get_parent_span_id()

            is_root = existing_trace_id is None
            if is_root:
                trace_data = _start_trace(span_name)
                trace_id = trace_data.id
            else:
                trace_id = existing_trace_id

            span_id = str(uuid.uuid4())

            # Set context for nested calls
            trace_token = _current_trace_id.set(trace_id)
            span_token = _current_span_id.set(span_id)
            old_tl_trace = getattr(_thread_local, "trace_id", None)
            old_tl_span = getattr(_thread_local, "span_id", None)
            _thread_local.trace_id = trace_id
            _thread_local.span_id = span_id

            # Capture inputs
            try:
                inputs = _capture_inputs(func, args, kwargs)
            except Exception:
                inputs = {"args": str(args)[:500], "kwargs": str(kwargs)[:500]}

            # Apply postprocess_inputs hook (Gap #4)
            if postprocess_inputs is not None:
                try:
                    inputs = postprocess_inputs(inputs)
                except Exception as pp_err:
                    logger.debug("postprocess_inputs failed: %s", pp_err)

            start = time.perf_counter()
            start_time = datetime.now(timezone.utc)
            error = None
            output = None
            status = "success"

            try:
                result = await func(*args, **kwargs)
                output = _capture_output(result)
                # Apply postprocess_output hook (Gap #4)
                if postprocess_output is not None:
                    try:
                        output = {"result": _safe_serialize(postprocess_output(result))}
                    except Exception as pp_err:
                        logger.debug("postprocess_output failed: %s", pp_err)
                return result
            except Exception as e:
                error = f"{type(e).__name__}: {e}"
                status = "error"
                raise
            finally:
                end = time.perf_counter()
                end_time = datetime.now(timezone.utc)
                duration_ms = (end - start) * 1000

                # Resolve thread/session IDs: decorator param > module-level
                resolved_thread_id = thread_id or _get_thread_id()
                resolved_session_id = session_id or _get_session_id()

                span = SpanData(
                    id=span_id,
                    trace_id=trace_id,
                    parent_id=parent_span_id if not is_root else None,
                    name=span_name,
                    inputs=inputs,
                    outputs=output,
                    status=status,
                    start_time=start_time,
                    end_time=end_time,
                    duration_ms=duration_ms,
                    error=error,
                    op_version=op_version,
                    kind=kind,
                    color=color,
                    thread_id=resolved_thread_id,
                    session_id=resolved_session_id,
                )
                _register_span(span)

                # Restore context
                _current_trace_id.set(trace_token if isinstance(trace_token, str) else (existing_trace_id))
                _current_span_id.set(span_token if isinstance(span_token, str) else parent_span_id)
                _thread_local.trace_id = old_tl_trace
                _thread_local.span_id = old_tl_span

                if is_root:
                    completed = _finish_trace(trace_id)
                    if completed is not None:
                        _send_trace(completed)

        return async_wrapper  # type: ignore[return-value]

    else:
        @functools.wraps(func)
        def sync_wrapper(*args: Any, **kwargs: Any) -> Any:
            # Sample rate check -- skip tracing for unsampled calls
            if sample_rate < 1.0:
                import random
                if random.random() > sample_rate:
                    return func(*args, **kwargs)

            # Determine if this is a root span (new trace) or nested
            existing_trace_id = _get_trace_id()
            parent_span_id = _get_parent_span_id()

            is_root = existing_trace_id is None
            if is_root:
                trace_data = _start_trace(span_name)
                trace_id = trace_data.id
            else:
                trace_id = existing_trace_id

            span_id = str(uuid.uuid4())

            # Set context for nested calls
            old_trace = _get_trace_id()
            old_span = _get_parent_span_id()
            _set_trace_id(trace_id)
            _set_parent_span_id(span_id)

            # Capture inputs
            try:
                inputs = _capture_inputs(func, args, kwargs)
            except Exception:
                inputs = {"args": str(args)[:500], "kwargs": str(kwargs)[:500]}

            # Apply postprocess_inputs hook (Gap #4)
            if postprocess_inputs is not None:
                try:
                    inputs = postprocess_inputs(inputs)
                except Exception as pp_err:
                    logger.debug("postprocess_inputs failed: %s", pp_err)

            start = time.perf_counter()
            start_time = datetime.now(timezone.utc)
            error = None
            output = None
            status = "success"

            try:
                result = func(*args, **kwargs)
                output = _capture_output(result)
                # Apply postprocess_output hook (Gap #4)
                if postprocess_output is not None:
                    try:
                        output = {"result": _safe_serialize(postprocess_output(result))}
                    except Exception as pp_err:
                        logger.debug("postprocess_output failed: %s", pp_err)
                return result
            except Exception as e:
                error = f"{type(e).__name__}: {e}"
                status = "error"
                raise
            finally:
                end = time.perf_counter()
                end_time = datetime.now(timezone.utc)
                duration_ms = (end - start) * 1000

                # Resolve thread/session IDs: decorator param > module-level
                resolved_thread_id = thread_id or _get_thread_id()
                resolved_session_id = session_id or _get_session_id()

                span = SpanData(
                    id=span_id,
                    trace_id=trace_id,
                    parent_id=parent_span_id if not is_root else None,
                    name=span_name,
                    inputs=inputs,
                    outputs=output,
                    status=status,
                    start_time=start_time,
                    end_time=end_time,
                    duration_ms=duration_ms,
                    error=error,
                    op_version=op_version,
                    kind=kind,
                    color=color,
                    thread_id=resolved_thread_id,
                    session_id=resolved_session_id,
                )
                _register_span(span)

                # Restore context
                _set_trace_id(old_trace)
                _set_parent_span_id(old_span)

                if is_root:
                    completed = _finish_trace(trace_id)
                    if completed is not None:
                        _send_trace(completed)

        return sync_wrapper  # type: ignore[return-value]


# ---------------------------------------------------------------------------
# Auto-patching for popular LLM libraries
# ---------------------------------------------------------------------------

_openai_patched = False


def patch_openai() -> None:
    """Monkey-patch openai.chat.completions.create to auto-trace.

    Wraps both sync and async create methods, capturing model, messages,
    and token usage in the trace metadata.
    """
    global _openai_patched
    if _openai_patched:
        return

    try:
        import openai
    except ImportError:
        logger.warning(
            "patch_openai: openai package not installed. "
            "Install with: pip install openai"
        )
        return

    # Patch sync completions.create
    try:
        original_create = openai.resources.chat.completions.Completions.create

        @functools.wraps(original_create)
        def traced_create(self: Any, *args: Any, **kwargs: Any) -> Any:
            @trace(name="openai.chat.completions.create")
            def _inner(**kw: Any) -> Any:
                return original_create(self, **kw)

            return _inner(**kwargs)

        openai.resources.chat.completions.Completions.create = traced_create
    except (AttributeError, Exception) as e:
        logger.debug("patch_openai: could not patch sync create: %s", e)

    # Patch async completions.create
    try:
        original_acreate = openai.resources.chat.completions.AsyncCompletions.create

        @functools.wraps(original_acreate)
        async def traced_acreate(self: Any, *args: Any, **kwargs: Any) -> Any:
            @trace(name="openai.chat.completions.create")
            async def _inner(**kw: Any) -> Any:
                return await original_acreate(self, **kw)

            return await _inner(**kwargs)

        openai.resources.chat.completions.AsyncCompletions.create = traced_acreate
    except (AttributeError, Exception) as e:
        logger.debug("patch_openai: could not patch async create: %s", e)

    _openai_patched = True
    logger.info("patch_openai: OpenAI chat completions auto-tracing enabled")


# ---------------------------------------------------------------------------
# Cleanup
# ---------------------------------------------------------------------------


def stop_sender() -> None:
    """Stop the background sender thread (for clean shutdown)."""
    _sender_stop.set()
    if _sender_thread is not None:
        _sender_thread.join(timeout=2.0)
