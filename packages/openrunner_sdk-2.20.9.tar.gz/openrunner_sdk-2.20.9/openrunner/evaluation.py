"""LLM evaluation framework -- scorers, datasets, evaluation runs.

Provides the ``@scorer`` decorator, ``Scorer`` base class, and
``evaluate()`` function for running structured evaluations of model
functions against datasets.

Usage::

    import openrunner

    @openrunner.scorer
    def accuracy_scorer(output, expected):
        return {"score": 1.0 if output == expected else 0.0}

    results = openrunner.evaluate(
        model=my_model,
        dataset=[{"input": "2+2?", "expected": "4"}],
        scorers=[accuracy_scorer],
        project="eval-project",
        name="gpt4-eval-v1",
    )
    print(results.summary)

Class-based scorers::

    from openrunner.evaluation import Scorer

    class MyScorer(Scorer):
        name = "my_scorer"

        def score(self, output, expected, **kwargs):
            return {"score": 1.0 if output == expected else 0.0}

        def summarize(self, scores):
            vals = [s["score"] for s in scores]
            return {"score": sum(vals) / len(vals), "max": max(vals)}
"""

from __future__ import annotations

import abc
import functools
import hashlib
import json
import logging
import time
import uuid
from dataclasses import dataclass, field
from typing import Any, Callable, TypeVar

logger = logging.getLogger("openrunner")

F = TypeVar("F", bound=Callable[..., Any])

# ---------------------------------------------------------------------------
# Scorer decorator
# ---------------------------------------------------------------------------

_SCORER_ATTR = "_openrunner_scorer"


def scorer(func: F) -> F:
    """Decorator that marks a function as an evaluation scorer.

    A scorer function must accept ``(output, expected)`` and return a
    dict with at least a ``"score"`` key (float 0.0-1.0).

    Can be used with or without parentheses::

        @openrunner.scorer
        def my_scorer(output, expected):
            return {"score": 1.0 if output == expected else 0.0}
    """
    setattr(func, _SCORER_ATTR, True)

    @functools.wraps(func)
    def wrapper(output: Any, expected: Any) -> dict[str, Any]:
        result = func(output, expected)
        if not isinstance(result, dict) or "score" not in result:
            raise ValueError(
                f"Scorer '{func.__name__}' must return a dict with a 'score' key, "
                f"got: {result!r}"
            )
        return result

    # Preserve the scorer marker on the wrapper
    setattr(wrapper, _SCORER_ATTR, True)
    return wrapper  # type: ignore[return-value]


def is_scorer(func: Any) -> bool:
    """Check if a function or Scorer instance is a valid scorer."""
    return getattr(func, _SCORER_ATTR, False) is True or isinstance(func, Scorer)


# ---------------------------------------------------------------------------
# Scorer base class
# ---------------------------------------------------------------------------


class Scorer(abc.ABC):
    """Base class for class-based evaluation scorers.

    Subclass this and implement :meth:`score` to create a reusable scorer.
    Override :meth:`summarize` for custom aggregation (default: mean).

    Attributes:
        name: Display name for this scorer. Defaults to the class name
              in snake_case if not set explicitly.

    Example::

        class AccuracyScorer(Scorer):
            name = "accuracy"

            def score(self, output, expected, **kwargs):
                return {"score": 1.0 if output == expected else 0.0}
    """

    name: str = ""

    def __init_subclass__(cls, **kwargs: Any) -> None:
        super().__init_subclass__(**kwargs)
        # Auto-generate name from class name if not explicitly set
        if not cls.name:
            # Convert CamelCase to snake_case
            import re

            s = re.sub(r"(?<!^)(?=[A-Z])", "_", cls.__name__).lower()
            # Remove trailing _scorer suffix for cleaner names
            cls.name = s

    @abc.abstractmethod
    def score(self, output: Any, expected: Any, **kwargs: Any) -> dict[str, Any]:
        """Score a single model output against the expected value.

        Must return a dict with at least a ``"score"`` key (float 0.0-1.0).
        Additional keys (e.g., ``"reasoning"``) are preserved in results.

        Args:
            output: Model output for the current dataset row.
            expected: Expected value from the dataset row.
            **kwargs: Additional context (e.g., ``input`` value).

        Returns:
            Dict with ``"score"`` (float) and optional extra keys.
        """
        ...

    def summarize(self, scores: list[dict[str, Any]]) -> dict[str, Any]:
        """Aggregate per-row scores into summary statistics.

        Default implementation computes the mean of the ``"score"`` values.
        Override for custom aggregation (median, weighted mean, etc.).

        Args:
            scores: List of dicts returned by :meth:`score`, one per row.

        Returns:
            Dict with aggregated metrics (at minimum ``"score"``).
        """
        if not scores:
            return {"score": 0.0}
        score_vals = [s.get("score", 0.0) for s in scores]
        return {"score": sum(score_vals) / len(score_vals)}

    @property
    def __name__(self) -> str:
        """Compatibility with function-based scorer name resolution."""
        return self.name or self.__class__.__name__

    def __call__(self, output: Any, expected: Any, **kwargs: Any) -> dict[str, Any]:
        """Make Scorer instances callable like function scorers."""
        result = self.score(output, expected, **kwargs)
        if not isinstance(result, dict) or "score" not in result:
            raise ValueError(
                f"Scorer '{self.name}' must return a dict with a 'score' key, "
                f"got: {result!r}"
            )
        return result


def _is_scorer_instance(obj: Any) -> bool:
    """Check if obj is a Scorer class instance (not a function scorer)."""
    return isinstance(obj, Scorer)


# ---------------------------------------------------------------------------
# EvalResult
# ---------------------------------------------------------------------------


@dataclass
class EvalResult:
    """Result of an evaluation run.

    Attributes:
        summary: Mean score per scorer, keyed as ``scorer_name.score``.
        table: List of dicts with columns: input, expected, output, and
               one column per scorer (``scorer_name.score``).
        scores: List of per-row score dicts (one dict per dataset row,
                containing scorer name -> score value mappings).
        name: Name of the evaluation run.
        project: Project name.
        dataset_hash: SHA-256 hash of the serialized dataset for dedup.
    """

    summary: dict[str, float] = field(default_factory=dict)
    table: list[dict[str, Any]] = field(default_factory=list)
    scores: list[dict[str, float]] = field(default_factory=list)
    name: str = ""
    project: str = ""
    dataset_hash: str = ""


# ---------------------------------------------------------------------------
# evaluate()
# ---------------------------------------------------------------------------


def _hash_dataset(dataset: list[dict[str, Any]]) -> str:
    """Compute a stable SHA-256 hash of the dataset for deduplication."""
    serialized = json.dumps(dataset, sort_keys=True, default=str)
    return hashlib.sha256(serialized.encode()).hexdigest()[:16]


def _get_scorer_name(s: Any) -> str:
    """Get the display name for a scorer (function or Scorer instance)."""
    if isinstance(s, Scorer):
        return s.name or s.__class__.__name__
    return s.__name__


def _run_single_evaluation(
    model: Callable[..., Any],
    dataset: list[dict[str, Any]],
    scorers: list[Any],
) -> EvalResult:
    """Run a single evaluation pass (internal helper).

    Accepts both function-based scorers (decorated with ``@scorer``)
    and class-based ``Scorer`` instances.

    Returns an EvalResult with summary, table, and scores for one trial.
    """
    table: list[dict[str, Any]] = []
    all_scores: list[dict[str, float]] = []

    # Track per-scorer raw score dicts for custom summarize()
    per_scorer_raw: dict[str, list[dict[str, Any]]] = {}

    scorer_totals: dict[str, float] = {}
    scorer_names = [_get_scorer_name(s) for s in scorers]
    for sname in scorer_names:
        scorer_totals[f"{sname}.score"] = 0.0
        per_scorer_raw[sname] = []

    for row_idx, row in enumerate(dataset):
        input_val = row.get("input", "")
        expected_val = row.get("expected", "")

        try:
            output_val = model(input_val)
        except Exception as e:
            logger.warning(
                "evaluate(): model raised %s on row %d: %s",
                type(e).__name__,
                row_idx,
                e,
            )
            output_val = f"ERROR: {e}"

        row_scores: dict[str, float] = {}
        row_result: dict[str, Any] = {
            "input": input_val,
            "expected": expected_val,
            "output": output_val,
        }

        for scorer_obj in scorers:
            sname = _get_scorer_name(scorer_obj)
            try:
                if isinstance(scorer_obj, Scorer):
                    score_result = scorer_obj.score(
                        output_val, expected_val, input=input_val,
                    )
                else:
                    score_result = scorer_obj(output_val, expected_val)
                score_val = float(score_result.get("score", 0.0))
                per_scorer_raw[sname].append(score_result)
            except Exception as e:
                logger.warning(
                    "evaluate(): scorer '%s' raised %s on row %d: %s",
                    sname,
                    type(e).__name__,
                    row_idx,
                    e,
                )
                score_val = 0.0
                per_scorer_raw[sname].append({"score": 0.0})

            key = f"{sname}.score"
            row_scores[key] = score_val
            row_result[key] = score_val
            scorer_totals[key] += score_val

        table.append(row_result)
        all_scores.append(row_scores)

    # Build summary: use custom summarize() for Scorer instances,
    # default mean for function scorers
    n = len(dataset)
    summary: dict[str, float] = {}
    for scorer_obj in scorers:
        sname = _get_scorer_name(scorer_obj)
        key = f"{sname}.score"
        if isinstance(scorer_obj, Scorer):
            try:
                custom_summary = scorer_obj.summarize(per_scorer_raw[sname])
                summary[key] = float(custom_summary.get("score", 0.0))
                # Include any extra summary keys from custom summarize
                for extra_key, extra_val in custom_summary.items():
                    if extra_key != "score":
                        summary[f"{sname}.{extra_key}"] = float(extra_val)
            except Exception as e:
                logger.warning(
                    "evaluate(): scorer '%s' summarize() raised %s: %s",
                    sname,
                    type(e).__name__,
                    e,
                )
                summary[key] = scorer_totals[key] / n if n else 0.0
        else:
            summary[key] = scorer_totals[key] / n if n else 0.0

    return EvalResult(
        summary=summary,
        table=table,
        scores=all_scores,
    )


def evaluate(
    model: Callable[..., Any],
    dataset: list[dict[str, Any]],
    scorers: list[Any],
    project: str = "uncategorized",
    name: str = "eval",
    trials: int = 1,
    **kwargs: Any,
) -> EvalResult | list[EvalResult]:
    """Run an evaluation of a model function against a dataset.

    For each row in the dataset, calls ``model(input)`` and then runs
    each scorer against the output and expected value. Collects results
    into an ``EvalResult`` with summary statistics, a results table,
    and per-row scores.

    Args:
        model: Callable that accepts an input string and returns output.
        dataset: List of dicts, each with ``"input"`` and ``"expected"`` keys.
        scorers: List of scorer functions (decorated with ``@scorer`` or
                 plain functions returning ``{"score": float}``), or
                 ``Scorer`` class instances.
        project: Project name for grouping evaluations.
        name: Name for this evaluation run.
        trials: Number of evaluation trials to run. When > 1, returns a
                list of EvalResult and logs mean/std variance metrics.

    Returns:
        EvalResult when trials=1, or list[EvalResult] when trials > 1.
    """
    if not dataset:
        logger.warning("evaluate(): empty dataset, returning empty result")
        return EvalResult(name=name, project=project)

    if not scorers:
        logger.warning("evaluate(): no scorers provided, returning empty result")
        return EvalResult(name=name, project=project)

    dataset_hash = _hash_dataset(dataset)

    all_results: list[EvalResult] = []
    for trial in range(trials):
        result = _run_single_evaluation(model, dataset, scorers)
        result.name = name if trials == 1 else f"{name}_trial{trial}"
        result.project = project
        result.dataset_hash = dataset_hash
        all_results.append(result)

    if trials > 1:
        # Compute mean and std across trials for variance metrics
        import math

        scorer_names = [_get_scorer_name(s) for s in scorers]
        keys = [f"{s}.score" for s in scorer_names]

        mean_summary: dict[str, float] = {}
        for key in keys:
            values = [r.summary.get(key, 0.0) for r in all_results]
            mean_val = sum(values) / len(values)
            std_val = math.sqrt(
                sum((v - mean_val) ** 2 for v in values) / len(values)
            )
            mean_summary[key] = mean_val
            mean_summary[f"{key}.std"] = std_val

        # Log the aggregate results
        _log_eval_results(
            project, name, mean_summary, all_results[0].table,
            scorer_names, dataset_hash,
        )
        return all_results
    else:
        result = all_results[0]
        scorer_names = [_get_scorer_name(s) for s in scorers]
        _log_eval_results(
            project, name, result.summary, result.table,
            scorer_names, dataset_hash,
        )
        return result


def _log_eval_results(
    project: str,
    name: str,
    summary: dict[str, float],
    table: list[dict[str, Any]],
    scorer_names: list[str],
    dataset_hash: str,
) -> None:
    """Log evaluation results to the server if an active run exists.

    Creates a run with group='evaluation', logs the results table and
    summary metrics. This is best-effort -- failures are logged but
    do not interrupt the evaluation.
    """
    try:
        import openrunner
        from openrunner.media import Table

        # Try to use existing active run or create a new one
        run = openrunner._active_run
        created_run = False

        if run is None:
            # Create a temporary run for evaluation results
            run = openrunner.init(
                project=project,
                name=name,
                group="evaluation",
                config={
                    "evaluation_name": name,
                    "dataset_hash": dataset_hash,
                    "scorer_names": scorer_names,
                },
            )
            created_run = True

        if run is not None:
            # Log summary metrics
            openrunner.log(summary)

            # Log the results as a Table
            columns = ["input", "expected", "output"] + [
                f"{s}.score" for s in scorer_names
            ]
            eval_table = Table(columns=columns, data=[
                [row.get(c, "") for c in columns] for row in table
            ])
            openrunner.log({"eval_results": eval_table})

            if created_run:
                openrunner.finish(quiet=True)

    except Exception as e:
        logger.debug("_log_eval_results failed: %s", e)


# ---------------------------------------------------------------------------
# EvaluationLogger
# ---------------------------------------------------------------------------


class EvaluationLogger:
    """Log evaluation results piecemeal without a dataset+model pattern.

    Useful for streaming evaluations, interactive experiments, or when
    you want to accumulate results row by row rather than using the
    batch ``evaluate()`` function.

    Usage::

        eval_log = EvaluationLogger("my-eval", project="llm-evals")
        eval_log.log(
            input={"question": "What is 2+2?"},
            output="4",
            expected="4",
            scores={"accuracy": 1.0},
        )
        eval_log.log(
            input={"question": "Capital of France?"},
            output="London",
            expected="Paris",
            scores={"accuracy": 0.0},
        )
        summary = eval_log.finish()
        print(summary)
        # {"count": 2, "scores": {"accuracy": {"mean": 0.5, "min": 0.0, "max": 1.0}}}

    Args:
        name: Display name for this evaluation session.
        project: Project name for grouping (default: "uncategorized").
    """

    def __init__(self, name: str, project: str | None = None) -> None:
        self.name = name
        self.project = project or "uncategorized"
        self._rows: list[dict[str, Any]] = []
        self._start_time = time.time()
        self._finished = False

    def log(
        self,
        input: dict[str, Any] | Any,
        output: Any,
        expected: Any = None,
        scores: dict[str, float] | None = None,
        metadata: dict[str, Any] | None = None,
    ) -> None:
        """Log a single evaluation result.

        Args:
            input: Input data (dict or any serializable value).
            output: Model output for this input.
            expected: Expected/ground-truth output (optional).
            scores: Dict of scorer_name -> score value (optional).
            metadata: Additional metadata for this row (optional).

        Raises:
            RuntimeError: If :meth:`finish` has already been called.
        """
        if self._finished:
            raise RuntimeError(
                "EvaluationLogger has been finished. "
                "Create a new instance to log more results."
            )

        row: dict[str, Any] = {
            "input": input,
            "output": output,
            "expected": expected,
            "timestamp": time.time(),
        }
        if scores:
            row["scores"] = dict(scores)
        if metadata:
            row["metadata"] = dict(metadata)

        self._rows.append(row)

    def finish(self) -> dict[str, Any]:
        """Finalize the evaluation session and compute summary statistics.

        Computes aggregated statistics (mean, min, max) over all logged
        scores and attempts to log results to the server.

        Returns:
            Summary dict with ``count``, ``scores`` (per-scorer stats),
            ``duration_seconds``, and ``name``.

        Raises:
            RuntimeError: If :meth:`finish` has already been called.
        """
        if self._finished:
            raise RuntimeError("EvaluationLogger.finish() already called.")

        self._finished = True
        duration = time.time() - self._start_time

        # Aggregate scores
        score_keys: set[str] = set()
        for row in self._rows:
            if "scores" in row:
                score_keys.update(row["scores"].keys())

        score_stats: dict[str, dict[str, float]] = {}
        for key in sorted(score_keys):
            values = [
                row["scores"][key]
                for row in self._rows
                if "scores" in row and key in row["scores"]
            ]
            if values:
                score_stats[key] = {
                    "mean": sum(values) / len(values),
                    "min": min(values),
                    "max": max(values),
                    "count": len(values),
                }

        summary: dict[str, Any] = {
            "name": self.name,
            "project": self.project,
            "count": len(self._rows),
            "scores": score_stats,
            "duration_seconds": round(duration, 2),
        }

        # Best-effort: log to server
        self._log_to_server(summary)

        return summary

    @property
    def rows(self) -> list[dict[str, Any]]:
        """Return a copy of all logged rows."""
        return list(self._rows)

    @property
    def count(self) -> int:
        """Return the number of logged rows."""
        return len(self._rows)

    def _log_to_server(self, summary: dict[str, Any]) -> None:
        """Attempt to log results to the OpenRunner server."""
        try:
            import openrunner
            from openrunner.media import Table

            run = openrunner.init(
                project=self.project,
                name=self.name,
                group="evaluation",
                config={
                    "evaluation_name": self.name,
                    "row_count": len(self._rows),
                },
            )
            if run is None:
                return

            # Log summary metrics (flatten score stats)
            flat_metrics: dict[str, float] = {}
            for key, stats in summary.get("scores", {}).items():
                for stat_name, stat_val in stats.items():
                    flat_metrics[f"{key}.{stat_name}"] = stat_val
            flat_metrics["duration_seconds"] = summary["duration_seconds"]
            openrunner.log(flat_metrics)

            # Log results table
            columns = ["input", "output", "expected"]
            score_key_list = sorted(
                {
                    k
                    for row in self._rows
                    if "scores" in row
                    for k in row["scores"]
                }
            )
            columns.extend(score_key_list)

            data = []
            for row in self._rows:
                table_row = [
                    str(row.get("input", "")),
                    str(row.get("output", "")),
                    str(row.get("expected", "")),
                ]
                for sk in score_key_list:
                    table_row.append(
                        row.get("scores", {}).get(sk, "")
                    )
                data.append(table_row)

            eval_table = Table(columns=columns, data=data)
            openrunner.log({"eval_results": eval_table})
            openrunner.finish(quiet=True)

        except Exception as e:
            logger.debug("EvaluationLogger._log_to_server failed: %s", e)
