"""W&B to OpenRunner migration tool.

Imports runs, metrics, configs, summaries, artifacts, and media
from a W&B project into an OpenRunner project.

Usage:
    openrunner migrate --from-wandb --entity myteam --project myproject
    openrunner migrate --from-wandb --entity myteam --project myproject --limit 50
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("openrunner")


def migrate_from_wandb(
    entity: str,
    project: str,
    target_project: str | None = None,
    limit: int | None = None,
    include_artifacts: bool = False,
    include_media: bool = False,
    dry_run: bool = False,
    wandb_api_key: str | None = None,
) -> None:
    """Import runs from a W&B project into OpenRunner.

    Args:
        entity: W&B entity (team/user).
        project: W&B project name.
        target_project: OpenRunner project name (defaults to ``entity/project``).
        limit: Max number of runs to import.
        include_artifacts: Import artifacts too.
        include_media: Import media files too.
        dry_run: Print what would be imported without actually doing it.
        wandb_api_key: W&B API key (defaults to WANDB_API_KEY env var).
    """
    try:
        import wandb  # type: ignore[import-untyped]
    except ImportError:
        raise ImportError(
            "Migration requires the wandb package. Install with: pip install wandb"
        )

    from openrunner.api_client import APIClient
    from openrunner.settings import SDKSettings

    # Initialize W&B API
    if wandb_api_key:
        api = wandb.Api(api_key=wandb_api_key)
    else:
        api = wandb.Api()

    target = target_project or f"{entity}/{project}"

    # Fetch runs from W&B
    runs = api.runs(f"{entity}/{project}")
    if limit:
        runs = list(runs)[:limit]
    else:
        runs = list(runs)

    print(f"Found {len(runs)} runs in {entity}/{project}")

    if dry_run:
        for wb_run in runs:
            print(
                f"  [{wb_run.state}] {wb_run.name} ({wb_run.id}) "
                f"-- {len(wb_run.history().columns)} metrics"
            )
        print(f"\nDry run complete. Use without --dry-run to import.")
        return

    # Initialize OpenRunner client
    settings = SDKSettings()
    client = APIClient(base_url=settings.base_url, api_key=settings.api_key or "")

    imported = 0
    failed = 0

    for i, wb_run in enumerate(runs):
        print(f"[{i + 1}/{len(runs)}] Importing {wb_run.name} ({wb_run.id})...")

        try:
            # Extract config and summary from W&B run
            config = dict(wb_run.config) if wb_run.config else {}
            summary = dict(wb_run.summary) if wb_run.summary else {}
            # Remove internal W&B keys from summary
            summary = {
                k: v
                for k, v in summary.items()
                if not k.startswith("_") and isinstance(v, (int, float, str, bool))
            }

            tags = list(wb_run.tags) if wb_run.tags else None

            # Map W&B state to OpenRunner state
            state_map = {
                "finished": "finished",
                "running": "finished",  # import as finished
                "crashed": "crashed",
                "failed": "crashed",
                "killed": "stopped",
            }
            state = state_map.get(wb_run.state, "finished")

            payload: dict[str, Any] = {
                "project": target,
                "display_name": wb_run.name,
                "config": config,
                "tags": tags,
                "notes": wb_run.notes,
                "group_name": wb_run.group,
                "job_type": wb_run.job_type,
            }

            result = client.create_run(payload)
            if not result:
                print("  ERROR: Failed to create run")
                failed += 1
                continue

            run_id = result.get("id")
            if not run_id:
                print("  ERROR: No run ID returned")
                failed += 1
                continue

            # Import metric history
            try:
                history = wb_run.scan_history()
                batch: list[dict[str, Any]] = []
                step = 0
                for row in history:
                    for key, value in row.items():
                        if key.startswith("_") or not isinstance(
                            value, (int, float)
                        ):
                            continue
                        batch.append(
                            {
                                "key": key,
                                "value": float(value),
                                "step": row.get("_step", step),
                            }
                        )
                    step += 1

                    # Flush in batches of 5000
                    if len(batch) >= 5000:
                        client.post_metrics(run_id, batch)
                        batch = []

                if batch:
                    client.post_metrics(run_id, batch)

                print(f"  Imported {step} steps of metrics")
            except Exception as e:
                print(f"  WARNING: Failed to import metrics: {e}")

            # Update state and summary
            update: dict[str, Any] = {"state": state, "summary": summary}
            client.update_run(run_id, update)

            imported += 1

        except Exception as e:
            print(f"  ERROR: {e}")
            failed += 1

    print(f"\nMigration complete: {imported} imported, {failed} failed")

    client.close()
