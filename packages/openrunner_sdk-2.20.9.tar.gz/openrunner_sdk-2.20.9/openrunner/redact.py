"""Session redaction — detect and mask PII/secrets before sync.

Inspired by Dataiku's kiji-proxy (DeBERTa NER + synthetic replacement).

Two modes:
1. Regex-based (fast, no deps): API keys, tokens, passwords, IPs, emails, paths
2. NER-based (accurate, needs transformers): full PII detection via DeBERTa

Redaction can be configured at:
- Client side: per-sync via `openrunner session sync --redact`
- Organization level: org setting forces redaction for all members
- User level: user setting in session_config.json
"""

from __future__ import annotations

import hashlib
import os
import re
from typing import Any

# ---------------------------------------------------------------------------
# Regex patterns for secrets and common PII
# ---------------------------------------------------------------------------

SECRET_PATTERNS: list[tuple[str, re.Pattern]] = [
    # API keys / tokens (generic patterns)
    ("API_KEY", re.compile(r"\b(sk-[a-zA-Z0-9\-_]{20,})\b")),  # OpenAI
    ("API_KEY", re.compile(r"\b(or_[a-zA-Z0-9_\-]{20,})\b")),  # OpenRunner
    ("API_KEY", re.compile(r"\b(ghp_[a-zA-Z0-9]{36,})\b")),  # GitHub PAT
    ("API_KEY", re.compile(r"\b(gho_[a-zA-Z0-9]{36,})\b")),  # GitHub OAuth
    ("API_KEY", re.compile(r"\b(github_pat_[a-zA-Z0-9_]{40,})\b")),  # GitHub fine-grained
    ("API_KEY", re.compile(r"\b(pypi-[a-zA-Z0-9_\-]{50,})\b")),  # PyPI
    ("API_KEY", re.compile(r"\b(npm_[a-zA-Z0-9]{30,})\b")),  # npm
    ("API_KEY", re.compile(r"\b(xox[bsapr]-[a-zA-Z0-9\-]{10,})\b")),  # Slack
    ("API_KEY", re.compile(r"\b(AKIA[0-9A-Z]{16})\b")),  # AWS access key
    ("SECRET", re.compile(r"\b([a-zA-Z0-9/+=]{40})\b(?=.*(?:secret|SECRET))")),  # AWS secret
    ("API_KEY", re.compile(r"\b(AIza[0-9A-Za-z_\-]{35})\b")),  # Google API
    ("TOKEN", re.compile(r"\b(eyJ[a-zA-Z0-9_\-]{20,}\.[a-zA-Z0-9_\-]{20,}\.[a-zA-Z0-9_\-]{20,})\b")),  # JWT
    # Passwords in config/env
    ("PASSWORD", re.compile(r"(?i)(?:password|passwd|pwd)\s*[=:]\s*['\"]?([^\s'\"]{6,})['\"]?")),
    # Connection strings
    ("CONNECTION_STRING", re.compile(r"(?i)((?:postgres|mysql|mongodb|redis)://[^\s'\"]+)")),
    # Private keys
    ("PRIVATE_KEY", re.compile(r"(-----BEGIN (?:RSA |EC |DSA )?PRIVATE KEY-----[^-]+-----END (?:RSA |EC |DSA )?PRIVATE KEY-----)", re.DOTALL)),
    # Email addresses
    ("EMAIL", re.compile(r"\b([a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,})\b")),
    # IP addresses (non-localhost, non-docker)
    ("IP_ADDRESS", re.compile(r"\b((?:(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d)\.){3}(?:25[0-5]|2[0-4]\d|1\d{2}|[1-9]?\d))\b")),
    # Home directory paths (contain username)
    ("PATH", re.compile(r"(/(?:home|Users)/[a-zA-Z0-9._\-]+)")),
]

# IPs to NOT redact (internal/docker/localhost)
SAFE_IPS = {"127.0.0.1", "0.0.0.0", "localhost", "172.17.0.1", "172.18.0.1"}
SAFE_IP_PREFIXES = ("10.", "172.16.", "172.17.", "172.18.", "192.168.")

# Emails to NOT redact
SAFE_EMAILS = {"noreply@anthropic.com", "noreply@github.com"}


def _is_safe_ip(ip: str) -> bool:
    return ip in SAFE_IPS or any(ip.startswith(p) for p in SAFE_IP_PREFIXES)


def _generate_replacement(label: str, original: str) -> str:
    """Generate a deterministic replacement (same input -> same output)."""
    # Use hash to generate consistent replacement
    h = hashlib.sha256(original.encode()).hexdigest()[:8]

    if label == "API_KEY":
        return f"REDACTED_KEY_{h}"
    elif label == "SECRET":
        return f"REDACTED_SECRET_{h}"
    elif label == "TOKEN":
        return f"REDACTED_TOKEN_{h}"
    elif label == "PASSWORD":
        return f"REDACTED_PASS_{h}"
    elif label == "CONNECTION_STRING":
        # Keep protocol, redact rest
        proto = original.split("://")[0] if "://" in original else "db"
        return f"{proto}://REDACTED_{h}"
    elif label == "PRIVATE_KEY":
        return "-----BEGIN PRIVATE KEY-----\nREDACTED\n-----END PRIVATE KEY-----"
    elif label == "EMAIL":
        domain = original.split("@")[1] if "@" in original else "example.com"
        return f"user_{h[:4]}@{domain}"
    elif label == "IP_ADDRESS":
        return f"x.x.x.{h[:2]}"
    elif label == "PATH":
        return f"/home/user_{h[:4]}"
    else:
        return f"[REDACTED:{label}]"


# ---------------------------------------------------------------------------
# Core redaction engine
# ---------------------------------------------------------------------------


class RedactionResult:
    """Result of redacting text."""

    def __init__(self, text: str, entities: list[dict], mapping: dict[str, str]):
        self.text = text
        self.entities = entities  # [{label, start, end, original, replacement}]
        self.mapping = mapping  # original -> replacement (for restoration)

    @property
    def redacted_count(self) -> int:
        return len(self.entities)


def redact_text(text: str, mode: str = "regex") -> RedactionResult:
    """Redact sensitive content from text.

    Args:
        text: Input text to redact.
        mode: "regex" (fast, pattern-based) or "ner" (ML-based, needs transformers).

    Returns:
        RedactionResult with redacted text and metadata.
    """
    if mode == "ner":
        return _redact_ner(text)
    return _redact_regex(text)


def _redact_regex(text: str) -> RedactionResult:
    """Fast regex-based redaction for secrets and common PII."""
    entities = []

    for label, pattern in SECRET_PATTERNS:
        for match in pattern.finditer(text):
            original = match.group(1) if match.lastindex else match.group(0)
            start = match.start(1) if match.lastindex else match.start(0)
            end = match.end(1) if match.lastindex else match.end(0)

            # Skip safe values
            if label == "IP_ADDRESS" and _is_safe_ip(original):
                continue
            if label == "EMAIL" and original.lower() in SAFE_EMAILS:
                continue
            # Skip very short matches (likely false positives)
            if len(original) < 6:
                continue

            entities.append({
                "label": label,
                "start": start,
                "end": end,
                "original": original,
                "replacement": _generate_replacement(label, original),
            })

    # Deduplicate overlapping entities (keep longest)
    entities.sort(key=lambda e: (e["start"], -(e["end"] - e["start"])))
    deduped = []
    last_end = -1
    for e in entities:
        if e["start"] >= last_end:
            deduped.append(e)
            last_end = e["end"]

    # Apply replacements (end-to-start to preserve offsets)
    result_text = text
    mapping = {}
    for e in reversed(deduped):
        result_text = result_text[:e["start"]] + e["replacement"] + result_text[e["end"]:]
        mapping[e["original"]] = e["replacement"]

    return RedactionResult(result_text, deduped, mapping)


def _redact_ner(text: str) -> RedactionResult:
    """NER-based redaction using DeBERTa model (DataikuNLP/kiji-pii-model).

    Falls back to regex if transformers not installed.
    """
    try:
        from transformers import pipeline
    except ImportError:
        return _redact_regex(text)

    # Load model (cached after first call)
    global _ner_pipeline
    if "_ner_pipeline" not in globals() or _ner_pipeline is None:
        try:
            _ner_pipeline = pipeline(
                "token-classification",
                model="DataikuNLP/kiji-pii-model-onnx",
                aggregation_strategy="simple",
            )
        except Exception:
            # Fall back to regex if model load fails
            return _redact_regex(text)

    # Run NER
    try:
        ner_results = _ner_pipeline(text[:10000])  # Cap at 10k chars
    except Exception:
        return _redact_regex(text)

    entities = []
    for ent in ner_results:
        if ent.get("score", 0) < 0.25:
            continue
        label = ent.get("entity_group", ent.get("entity", "UNKNOWN"))
        original = ent.get("word", "")
        entities.append({
            "label": label,
            "start": ent["start"],
            "end": ent["end"],
            "original": original,
            "replacement": _generate_replacement(label, original),
        })

    # Also run regex for secrets (NER won't catch API keys)
    regex_result = _redact_regex(text)
    # Merge: add regex entities that don't overlap with NER
    for re_ent in regex_result.entities:
        overlaps = any(
            re_ent["start"] < e["end"] and re_ent["end"] > e["start"]
            for e in entities
        )
        if not overlaps:
            entities.append(re_ent)

    entities.sort(key=lambda e: e["start"])

    # Apply replacements
    result_text = text
    mapping = {}
    for e in reversed(entities):
        result_text = result_text[:e["start"]] + e["replacement"] + result_text[e["end"]:]
        mapping[e["original"]] = e["replacement"]

    return RedactionResult(result_text, entities, mapping)


# ---------------------------------------------------------------------------
# Session-level redaction
# ---------------------------------------------------------------------------


def redact_session(parsed: dict[str, Any], mode: str = "regex") -> dict[str, Any]:
    """Redact a parsed session dict before sync.

    Redacts:
    - All message content (user + assistant)
    - File paths (replace usernames)
    - First message / summary

    Returns a new dict (doesn't mutate input).
    """
    import copy
    result = copy.deepcopy(parsed)

    total_redacted = 0

    # Redact messages
    for msg in result.get("messages", []):
        if msg.get("content"):
            r = redact_text(msg["content"], mode=mode)
            msg["content"] = r.text
            total_redacted += r.redacted_count

    # Redact first_message
    if result.get("first_message"):
        r = redact_text(result["first_message"], mode=mode)
        result["first_message"] = r.text
        total_redacted += r.redacted_count

    # Redact summary
    if result.get("summary"):
        r = redact_text(result["summary"], mode=mode)
        result["summary"] = r.text
        total_redacted += r.redacted_count

    # Redact file paths (just home dir usernames)
    if result.get("files_touched"):
        result["files_touched"] = [
            re.sub(r"/(?:home|Users)/[^/]+", "/home/user", f)
            for f in result["files_touched"]
        ]

    result["_redaction"] = {
        "mode": mode,
        "entities_redacted": total_redacted,
    }

    return result


# ---------------------------------------------------------------------------
# Redaction policy config
# ---------------------------------------------------------------------------


class RedactionPolicy:
    """Redaction policy: determines if/how to redact based on config."""

    def __init__(
        self,
        enabled: bool = False,
        mode: str = "regex",  # "regex" or "ner"
        force: bool = False,  # org-level forced redaction
    ):
        self.enabled = enabled
        self.mode = mode
        self.force = force

    @classmethod
    def from_config(cls, config: dict) -> "RedactionPolicy":
        """Load policy from session config or org settings."""
        redaction = config.get("redaction", {})
        return cls(
            enabled=redaction.get("enabled", False),
            mode=redaction.get("mode", "regex"),
            force=redaction.get("force", False),
        )

    @classmethod
    def from_org_settings(cls, org_settings: dict) -> "RedactionPolicy":
        """Load policy from organization-level settings."""
        if org_settings.get("force_session_redaction"):
            return cls(enabled=True, mode=org_settings.get("redaction_mode", "regex"), force=True)
        return cls(enabled=False)

    def should_redact(self, user_choice: bool | None = None) -> bool:
        """Determine if redaction should be applied.

        Priority: org force > user explicit choice > config default.
        """
        if self.force:
            return True
        if user_choice is not None:
            return user_choice
        return self.enabled
