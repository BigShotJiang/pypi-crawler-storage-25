"""LLM cost calculation from token usage.

Default costs for popular models. Users can override with add_cost().
"""

from __future__ import annotations

# Default costs per 1K tokens
DEFAULT_COSTS: dict[str, dict[str, float]] = {
    # OpenAI
    "gpt-4o": {"input": 0.005, "output": 0.015},
    "gpt-4o-mini": {"input": 0.00015, "output": 0.0006},
    "gpt-4-turbo": {"input": 0.01, "output": 0.03},
    "gpt-4": {"input": 0.03, "output": 0.06},
    "gpt-3.5-turbo": {"input": 0.0005, "output": 0.0015},
    # Anthropic
    "claude-opus-4-20250514": {"input": 0.015, "output": 0.075},
    "claude-sonnet-4-20250514": {"input": 0.003, "output": 0.015},
    "claude-3-5-haiku-20241022": {"input": 0.001, "output": 0.005},
    # Mistral
    "mistral-large-latest": {"input": 0.004, "output": 0.012},
    "mistral-small-latest": {"input": 0.001, "output": 0.003},
}

_custom_costs: dict[str, dict[str, float]] = {}


def add_cost(model: str, input_cost_per_1k: float, output_cost_per_1k: float) -> None:
    """Register custom cost for a model.

    Args:
        model: Model name/identifier.
        input_cost_per_1k: Cost in USD per 1K input tokens.
        output_cost_per_1k: Cost in USD per 1K output tokens.
    """
    _custom_costs[model] = {"input": input_cost_per_1k, "output": output_cost_per_1k}


def compute_cost(model: str, input_tokens: int, output_tokens: int) -> float | None:
    """Compute cost in USD for a model call.

    Checks custom costs first, then falls back to DEFAULT_COSTS.

    Args:
        model: Model name/identifier.
        input_tokens: Number of input/prompt tokens.
        output_tokens: Number of output/completion tokens.

    Returns:
        Cost in USD, or None if the model is not in the cost table.
    """
    costs = _custom_costs.get(model) or DEFAULT_COSTS.get(model)
    if not costs:
        return None
    return (input_tokens * costs["input"] + output_tokens * costs["output"]) / 1000
