"""AI session capture — sniff and log coding sessions from Claude Code, ChatGPT, Codex, Qwen.

Usage:
    openrunner session watch          # daemon mode, auto-logs new sessions
    openrunner session sync           # one-shot, sync recent unlogged sessions
    openrunner session hook install   # install Claude Code hook for auto-capture
    openrunner session list           # list captured sessions

Supports:
    - Claude Code (~/.claude/projects/*/*.jsonl)
    - ChatGPT API logs (if OPENAI_LOG_DIR set)
    - Codex CLI (~/.codex/sessions/)
    - Qwen Code (~/.qwen-code/sessions/)
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

logger = logging.getLogger("openrunner.session")

# ---------------------------------------------------------------------------
# Session source detectors
# ---------------------------------------------------------------------------

CLAUDE_CODE_DIR = Path.home() / ".claude" / "projects"
CODEX_DIR = Path.home() / ".codex" / "sessions"
QWEN_DIR = Path.home() / ".qwen-code" / "sessions"
CHATGPT_LOG_DIR = Path(os.environ.get("OPENAI_LOG_DIR", "~/.openai/logs")).expanduser()

# Track which sessions we've already synced
SYNC_STATE_FILE = Path.home() / ".openrunner" / "session_sync_state.json"


def _load_sync_state() -> dict:
    """Load set of already-synced session hashes."""
    if SYNC_STATE_FILE.exists():
        return json.loads(SYNC_STATE_FILE.read_text())
    return {"synced": {}}


def _save_sync_state(state: dict) -> None:
    SYNC_STATE_FILE.parent.mkdir(parents=True, exist_ok=True)
    SYNC_STATE_FILE.write_text(json.dumps(state, indent=2))


def _session_hash(path: Path) -> str:
    """Stable hash for a session file (path + size + mtime)."""
    stat = path.stat()
    key = f"{path}:{stat.st_size}:{int(stat.st_mtime)}"
    return hashlib.md5(key.encode()).hexdigest()[:12]


# ---------------------------------------------------------------------------
# Claude Code parser
# ---------------------------------------------------------------------------


def discover_claude_sessions(since_hours: float = 24) -> list[dict]:
    """Find recent Claude Code session files."""
    sessions = []
    if not CLAUDE_CODE_DIR.exists():
        return sessions

    cutoff = time.time() - (since_hours * 3600)
    for jsonl in CLAUDE_CODE_DIR.rglob("*.jsonl"):
        stat = jsonl.stat()
        if stat.st_size < 100 or stat.st_mtime < cutoff:
            continue
        if ".meta." in jsonl.name:
            continue
        sessions.append({
            "source": "claude-code",
            "path": jsonl,
            "mtime": stat.st_mtime,
            "size": stat.st_size,
        })
    return sorted(sessions, key=lambda s: s["mtime"], reverse=True)


def parse_claude_session(path: Path) -> dict[str, Any]:
    """Parse a Claude Code .jsonl session into structured data."""
    messages = []
    tools_used = set()
    files_touched = set()
    total_tokens = 0

    with open(path) as f:
        for line in f:
            line = line.strip()
            if not line:
                continue
            try:
                entry = json.loads(line)
            except json.JSONDecodeError:
                continue

            # Claude Code format: {type, message: {role, content}, ...}
            msg = entry.get("message", entry)
            role = msg.get("role", entry.get("type", ""))
            content = msg.get("content", "")

            # Handle content as list (Claude API format)
            if isinstance(content, list):
                text_parts = []
                for block in content:
                    if isinstance(block, dict):
                        if block.get("type") == "text":
                            text_parts.append(block.get("text", ""))
                        elif block.get("type") == "tool_use":
                            tools_used.add(block.get("name", "unknown"))
                            # Track files from Read/Write/Edit
                            inp = block.get("input", {})
                            if "file_path" in inp:
                                files_touched.add(inp["file_path"])
                            elif "path" in inp:
                                files_touched.add(inp["path"])
                        elif block.get("type") == "tool_result":
                            pass
                content = "\n".join(text_parts)

            # Get timestamp from entry
            ts = entry.get("timestamp") or entry.get("created_at") or ""
            if isinstance(ts, (int, float)):
                ts = datetime.fromtimestamp(ts / 1000 if ts > 1e12 else ts, tz=timezone.utc).isoformat()

            if role == "user" and content:
                messages.append({"role": "user", "content": content[:2000], "ts": ts})
            elif role == "assistant" and content:
                messages.append({"role": "assistant", "content": content[:2000], "ts": ts})

            # Token counting from usage field (may be at entry or message level)
            usage = entry.get("usage", msg.get("usage", {}))
            total_tokens += usage.get("input_tokens", 0) + usage.get("output_tokens", 0)

    # Extract project context from path
    # ~/.claude/projects/-home-user-myproject/session-id.jsonl
    # or ~/.claude/projects/-home-user-myproject/subagents/agent-xxx.jsonl
    parts = path.parts
    # Find the project dir (child of "projects")
    project_hint = ""
    for i, p in enumerate(parts):
        if p == "projects" and i + 1 < len(parts):
            project_hint = parts[i + 1].replace("-", "/").lstrip("/")
            break

    # Build summary
    user_messages = [m for m in messages if m["role"] == "user"]
    first_msg = user_messages[0]["content"][:200] if user_messages else "Empty session"

    return {
        "source": "claude-code",
        "session_file": str(path),
        "project_hint": project_hint,
        "started_at": datetime.fromtimestamp(path.stat().st_mtime - _estimate_duration(path), tz=timezone.utc).isoformat(),
        "ended_at": datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat(),
        "message_count": len(messages),
        "user_message_count": len(user_messages),
        "tools_used": sorted(tools_used),
        "files_touched": sorted(files_touched)[:50],
        "total_tokens": total_tokens,
        "first_message": first_msg,
        "summary": _summarize_session(messages),
        "messages": _compact_messages(messages),  # all user msgs, truncated assistant
    }


def _estimate_duration(path: Path) -> float:
    """Rough session duration estimate from file size."""
    # ~500 bytes per message exchange, ~30s per exchange
    size = path.stat().st_size
    exchanges = size / 500
    return min(exchanges * 30, 7200)  # cap at 2h


def _compact_messages(messages: list[dict]) -> list[dict]:
    """Compact messages for storage: keep all user msgs, truncate assistant to 500 chars."""
    result = []
    for msg in messages:
        if msg.get("role") == "user":
            result.append(msg)
        elif msg.get("role") == "assistant":
            content = msg.get("content", "")
            result.append({
                "role": "assistant",
                "content": content[:500] + ("..." if len(content) > 500 else ""),
                "ts": msg.get("ts", ""),
            })
    return result


def _summarize_session(messages: list[dict]) -> str:
    """Generate a structured summary from messages.

    Extracts: topic, key actions, outcomes.
    """
    user_msgs = [m["content"] for m in messages if m["role"] == "user" and m.get("content")]
    assistant_msgs = [m["content"] for m in messages if m["role"] == "assistant" and m.get("content")]

    if not user_msgs:
        return "Empty session"

    parts = []

    # Topic from first message
    parts.append(f"**Topic:** {user_msgs[0][:150]}")

    # Key user requests (sample up to 5 distinct short ones)
    if len(user_msgs) > 2:
        key_requests = []
        for msg in user_msgs[1:]:
            # Skip very short messages (confirmations) and very long ones (pastes)
            if 10 < len(msg) < 200:
                key_requests.append(msg.strip()[:80])
            if len(key_requests) >= 5:
                break
        if key_requests:
            parts.append("**Key requests:** " + " → ".join(key_requests))

    # Last request
    if len(user_msgs) > 1:
        parts.append(f"**Last:** {user_msgs[-1][:100]}")

    # Stats
    parts.append(f"**Stats:** {len(user_msgs)} requests, {len(assistant_msgs)} responses")

    return "\n".join(parts)


# ---------------------------------------------------------------------------
# Codex / Qwen / ChatGPT parsers (simpler)
# ---------------------------------------------------------------------------


def discover_codex_sessions(since_hours: float = 24) -> list[dict]:
    """Find recent Codex sessions."""
    sessions = []
    if not CODEX_DIR.exists():
        return sessions
    cutoff = time.time() - (since_hours * 3600)
    for f in CODEX_DIR.glob("*.json"):
        if f.stat().st_mtime < cutoff:
            continue
        sessions.append({"source": "codex", "path": f, "mtime": f.stat().st_mtime, "size": f.stat().st_size})
    return sessions


def discover_qwen_sessions(since_hours: float = 24) -> list[dict]:
    """Find recent Qwen Code sessions."""
    sessions = []
    if not QWEN_DIR.exists():
        return sessions
    cutoff = time.time() - (since_hours * 3600)
    for f in QWEN_DIR.rglob("*.json"):
        if f.stat().st_mtime < cutoff:
            continue
        sessions.append({"source": "qwen", "path": f, "mtime": f.stat().st_mtime, "size": f.stat().st_size})
    return sessions


def discover_chatgpt_sessions(since_hours: float = 24) -> list[dict]:
    """Find ChatGPT API log files."""
    sessions = []
    if not CHATGPT_LOG_DIR.exists():
        return sessions
    cutoff = time.time() - (since_hours * 3600)
    for f in CHATGPT_LOG_DIR.rglob("*.jsonl"):
        if f.stat().st_mtime < cutoff:
            continue
        sessions.append({"source": "chatgpt", "path": f, "mtime": f.stat().st_mtime, "size": f.stat().st_size})
    return sessions


def parse_generic_session(path: Path, source: str) -> dict[str, Any]:
    """Parse a generic JSON/JSONL session file."""
    messages = []
    try:
        if path.suffix == ".jsonl":
            with open(path) as f:
                for line in f:
                    if line.strip():
                        try:
                            messages.append(json.loads(line))
                        except json.JSONDecodeError:
                            pass
        else:
            data = json.loads(path.read_text())
            if isinstance(data, list):
                messages = data
            elif isinstance(data, dict) and "messages" in data:
                messages = data["messages"]
    except Exception:
        pass

    return {
        "source": source,
        "session_file": str(path),
        "project_hint": "",
        "started_at": datetime.fromtimestamp(path.stat().st_mtime - 1800, tz=timezone.utc).isoformat(),
        "ended_at": datetime.fromtimestamp(path.stat().st_mtime, tz=timezone.utc).isoformat(),
        "message_count": len(messages),
        "user_message_count": sum(1 for m in messages if isinstance(m, dict) and m.get("role") == "user"),
        "tools_used": [],
        "files_touched": [],
        "total_tokens": 0,
        "first_message": str(messages[0])[:200] if messages else "Empty",
        "summary": f"{source} session with {len(messages)} messages",
        "messages": messages[:100],
    }


# ---------------------------------------------------------------------------
# Sync to OpenRunner
# ---------------------------------------------------------------------------


def get_session_config(interactive: bool = False) -> dict:
    """Load or interactively configure session sync settings.

    Config stored in ~/.openrunner/session_config.json:
    {
        "api_key": "or_...",
        "base_url": "https://...",
        "project": "org/project-name"
    }

    Per-worktree overrides in .openrunner/session.json (local to cwd).
    """
    global_config_file = Path.home() / ".openrunner" / "session_config.json"
    local_config_file = Path.cwd() / ".openrunner" / "session.json"
    global_settings_file = Path.home() / ".openrunner" / "settings.json"

    # Load cascade: local > global session config > global settings > env
    config: dict[str, Any] = {}

    # Global settings (login credentials)
    if global_settings_file.exists():
        try:
            config.update(json.loads(global_settings_file.read_text()))
        except (json.JSONDecodeError, OSError):
            pass

    # Global session config
    if global_config_file.exists():
        try:
            config.update(json.loads(global_config_file.read_text()))
        except (json.JSONDecodeError, OSError):
            pass

    # Local override
    if local_config_file.exists():
        try:
            config.update(json.loads(local_config_file.read_text()))
        except (json.JSONDecodeError, OSError):
            pass

    # Env vars take precedence
    if os.environ.get("OPENRUNNER_API_KEY"):
        config["api_key"] = os.environ["OPENRUNNER_API_KEY"]
    if os.environ.get("OPENRUNNER_BASE_URL"):
        config["base_url"] = os.environ["OPENRUNNER_BASE_URL"]
    if os.environ.get("OPENRUNNER_SESSION_PROJECT"):
        config["project"] = os.environ["OPENRUNNER_SESSION_PROJECT"]

    return config


def save_session_config(config: dict, local: bool = False) -> None:
    """Save session config globally or locally."""
    if local:
        config_file = Path.cwd() / ".openrunner" / "session.json"
    else:
        config_file = Path.home() / ".openrunner" / "session_config.json"
    config_file.parent.mkdir(parents=True, exist_ok=True)
    config_file.write_text(json.dumps(config, indent=2))


def interactive_setup() -> dict:
    """Interactive first-run setup: prompt for API key and project selection.

    Returns config dict with api_key, base_url, project.
    """
    from openrunner.api_client import APIClient

    config = get_session_config()

    # Step 1: API key
    api_key = config.get("api_key")
    base_url = config.get("base_url", "")

    if not api_key:
        print("OpenRunner session sync — first-time setup")
        print("=" * 50)
        api_key = input("API Key (from OpenRunner settings): ").strip()
        if not api_key:
            print("No API key provided. Aborting.")
            return {}
        base_url_input = input(f"Server URL [{base_url}]: ").strip()
        if base_url_input:
            base_url = base_url_input

    # Step 2: Verify key works
    client = APIClient(base_url=base_url, api_key=api_key)
    try:
        resp = client._request("get", "/auth/me")
        if resp.status_code != 200:
            print(f"API key invalid (HTTP {resp.status_code}). Check your key.")
            client.close()
            return {}
        user_info = resp.json()
        print(f"Authenticated as: {user_info.get('display_name', user_info.get('email', '?'))}")
    except Exception as e:
        print(f"Connection failed: {e}")
        client.close()
        return {}

    # Step 3: Select project
    project = config.get("project")
    if not project:
        print("\nSelect project for session logs:")
        projects = client.list_projects()
        if not projects:
            print("No projects found. Create one in OpenRunner first.")
            client.close()
            return {}

        for i, p in enumerate(projects, 1):
            org = p.get("org_name", p.get("organization", {}).get("name", "?"))
            name = p.get("name", "?")
            print(f"  [{i}] {org}/{name}")

        choice = input(f"\nProject number [1-{len(projects)}]: ").strip()
        try:
            idx = int(choice) - 1
            p = projects[idx]
            org = p.get("org_name", p.get("organization", {}).get("name", ""))
            project = f"{org}/{p['name']}" if org else p["name"]
        except (ValueError, IndexError):
            print("Invalid selection.")
            client.close()
            return {}

    client.close()

    config_out = {
        "api_key": api_key,
        "base_url": base_url,
        "project": project,
    }

    # Save
    save_session_config(config_out)
    print(f"\nConfig saved. Sessions will sync to: {project}")
    print(f"Config file: ~/.openrunner/session_config.json")
    return config_out


def sync_session_to_openrunner(
    parsed: dict[str, Any],
    project: str | None = None,
    api_key: str | None = None,
    base_url: str | None = None,
    redact: bool | None = None,
    redact_mode: str | None = None,
    visibility: str = "private",
) -> str | None:
    """Upload a parsed session to OpenRunner as a run with notes.

    Args:
        redact: Force redaction on/off. None = use config/org policy.
        redact_mode: "regex" (fast) or "ner" (ML-based, needs transformers).
        visibility: "public" or "private".

    Returns the run ID on success, None on failure.
    """
    from openrunner.api_client import APIClient
    from openrunner.redact import RedactionPolicy, redact_session

    # Load config (cascade: args > env > session_config > settings)
    config = get_session_config()

    # Apply redaction policy (local config + server org policy)
    policy = RedactionPolicy.from_config(config)

    # Fetch server-side policy if not explicitly overridden
    if redact is None and api_key and base_url:
        try:
            client_check = APIClient(base_url=base_url, api_key=api_key)
            resp = client_check._request("get", "/users/me/settings/redaction")
            if resp.status_code == 200:
                server_policy = resp.json().get("effective", {})
                if server_policy.get("forced") or server_policy.get("enabled"):
                    policy = RedactionPolicy(
                        enabled=True,
                        mode=server_policy.get("mode", "regex"),
                        force=server_policy.get("forced", False),
                    )
            client_check.close()
        except Exception:
            pass  # Offline or server doesn't support — use local config

    if policy.should_redact(redact):
        mode = redact_mode or policy.mode
        parsed = redact_session(parsed, mode=mode)
        redaction_info = parsed.get("_redaction", {})
        if redaction_info.get("entities_redacted", 0) > 0:
            logger.info(f"Redacted {redaction_info['entities_redacted']} sensitive entities ({mode} mode)")

    api_key = api_key or config.get("api_key")
    base_url = base_url or config.get("base_url")

    if not api_key or not base_url:
        logger.warning("No API key or base URL configured. Run 'openrunner login' first.")
        return None

    # Determine project from config cascade
    if not project:
        project = config.get("project") or "research-sessions"

    client = APIClient(base_url=base_url, api_key=api_key)

    # Resolve project_id from "org/project" format
    project_id = None
    try:
        projects = client.list_projects()
        for p in projects:
            org_name = p.get("org_name", "") or ""
            org_slug = p.get("org_slug", "") or ""
            proj_name = p.get("name", "")
            proj_slug = p.get("slug", "")
            # Match: "org/project", "org_slug/project_slug", or just "project"
            candidates = [
                f"{org_name}/{proj_name}",
                f"{org_slug}/{proj_slug}",
                f"{org_name}/{proj_slug}",
                proj_name,
                proj_slug,
            ]
            if project in candidates:
                project_id = p.get("id")
                break
    except Exception:
        pass

    if not project_id:
        # Fallback: try creating as a run (backward compat with older servers)
        logger.warning(f"Could not resolve project '{project}', falling back to run creation")
        return _sync_as_run_fallback(client, parsed, project, visibility)

    # Build AI session data
    source = parsed["source"]
    project_hint = parsed.get("project_hint", "")
    timestamp = parsed.get("ended_at", "")[:16].replace("T", " ")

    if project_hint:
        short_hint = project_hint.rsplit("/", 1)[-1] if "/" in project_hint else project_hint
        title = f"{source}/{short_hint}/{timestamp}"
    else:
        title = f"{source}/{timestamp}"

    group_key = f"{source}:{project_hint}" if project_hint else f"{source}:default"

    session_data = {
        "title": title,
        "source": source,
        "worktree": project_hint,
        "group_key": group_key,
        "summary": parsed.get("summary"),
        "notes": _format_session_notes(parsed),
        "first_message": parsed.get("first_message"),
        "messages": parsed.get("messages"),
        "message_count": parsed.get("message_count", 0),
        "user_message_count": parsed.get("user_message_count", 0),
        "total_tokens": parsed.get("total_tokens", 0),
        "tools_used": parsed.get("tools_used", []),
        "files_touched": parsed.get("files_touched", []),
        "visibility": visibility,
        "tags": [f"source:{source}", f"worktree:{group_key}"],
        "redacted": bool(parsed.get("_redaction")),
        "redaction_mode": parsed.get("_redaction", {}).get("mode") if parsed.get("_redaction") else None,
        "session_file": parsed.get("session_file"),
        "started_at": parsed.get("started_at"),
        "ended_at": parsed.get("ended_at"),
    }

    # POST to /projects/{project_id}/ai-sessions
    try:
        resp = client._request("post", f"/projects/{project_id}/ai-sessions", json=session_data)
        if resp.status_code in (200, 201):
            result = resp.json()
            session_id = result.get("id")
            # Track in sync state to prevent future duplicates
            if parsed.get("session_file"):
                state = _load_sync_state()
                h = hashlib.md5(parsed["session_file"].encode()).hexdigest()[:12]
                state["synced"][h] = {
                    "session_id": session_id,
                    "source": parsed.get("source", ""),
                    "synced_at": datetime.now(timezone.utc).isoformat(),
                    "deduplicated": result.get("deduplicated", False),
                }
                _save_sync_state(state)
            client.close()
            if result.get("deduplicated"):
                logger.info(f"Session already synced (dedup): {session_id}")
            return session_id
        else:
            # Server doesn't have AI sessions endpoint yet — fall back to run
            logger.info("AI sessions endpoint not available, falling back to run")
            return _sync_as_run_fallback(client, parsed, project, visibility)
    except Exception as e:
        logger.warning(f"AI session sync failed: {e}")
        client.close()
        return None


def _sync_as_run_fallback(client, parsed: dict, project: str, visibility: str) -> str | None:
    """Fallback: create a run if AI sessions endpoint not available."""
    source = parsed["source"]
    timestamp = parsed.get("ended_at", "")[:16].replace("T", " ")
    project_hint = parsed.get("project_hint", "")

    if project_hint:
        short_hint = project_hint.rsplit("/", 1)[-1] if "/" in project_hint else project_hint
        run_name = f"{source}/{short_hint}/{timestamp}"
    else:
        run_name = f"{source}/{timestamp}"

    run_data = {
        "project": project,
        "display_name": run_name,
        "group_name": f"{source}:{project_hint}" if project_hint else f"{source}:default",
        "tags": [f"source:{source}", "ai-session"],
        "notes": _format_session_notes(parsed),
        "state": "finished",
    }

    result = client.create_run(run_data)
    client.close()
    return result.get("id") if result else None


def _format_session_notes(parsed: dict) -> str:
    """Format parsed session into readable notes."""
    lines = []
    source = parsed.get("source", "unknown").replace("-", " ").title()
    lines.append(f"# {source} Session")
    lines.append(f"**Time:** {parsed.get('started_at', '?')[:16]} → {parsed.get('ended_at', '?')[:16]}")
    if parsed.get("project_hint"):
        lines.append(f"**Project:** `{parsed['project_hint']}`")
    lines.append(f"**Tokens:** {parsed.get('total_tokens', 0):,}")
    lines.append("")

    if parsed.get("first_message"):
        lines.append("## Initial Request")
        lines.append(parsed["first_message"])
        lines.append("")

    if parsed.get("summary"):
        lines.append("## Summary")
        lines.append(parsed["summary"])
        lines.append("")

    if parsed.get("tools_used"):
        lines.append(f"## Tools Used ({len(parsed['tools_used'])})")
        lines.append(", ".join(parsed["tools_used"][:20]))
        lines.append("")

    if parsed.get("files_touched"):
        lines.append(f"## Files Modified ({len(parsed['files_touched'])})")
        for f in parsed["files_touched"][:30]:
            lines.append(f"- `{f}`")
        lines.append("")

    # Extract key conversation flow (first 10 user messages as bullet points)
    messages = parsed.get("messages", [])
    user_msgs = [m["content"] for m in messages if m.get("role") == "user" and m.get("content") and len(m["content"]) > 10]
    if len(user_msgs) > 2:
        lines.append("## Conversation Flow")
        for msg in user_msgs[:15]:
            lines.append(f"- {msg[:120]}")
        if len(user_msgs) > 15:
            lines.append(f"- ... ({len(user_msgs) - 15} more)")
        lines.append("")

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Discovery + sync orchestration
# ---------------------------------------------------------------------------


def discover_in_directory(directory: Path, since_hours: float = 24) -> list[dict]:
    """Discover session files in a given directory (recursive).

    Detects source by path heuristics:
    - .claude in path → claude-code
    - .codex in path → codex
    - .qwen in path → qwen
    - Otherwise → generic
    """
    sessions = []
    cutoff = time.time() - (since_hours * 3600)

    for pattern in ("**/*.jsonl", "**/*.json"):
        for f in directory.glob(pattern):
            stat = f.stat()
            # Skip empty files, meta files, and old files
            if stat.st_size < 100 or stat.st_mtime < cutoff:
                continue
            if ".meta." in f.name:
                continue
            # Detect source from path
            path_str = str(f).lower()
            if ".claude" in path_str:
                source = "claude-code"
            elif ".codex" in path_str:
                source = "codex"
            elif ".qwen" in path_str:
                source = "qwen"
            elif "openai" in path_str or "chatgpt" in path_str:
                source = "chatgpt"
            else:
                source = "claude-code"  # default — most common format
            sessions.append({
                "source": source,
                "path": f,
                "mtime": stat.st_mtime,
                "size": stat.st_size,
            })
    return sorted(sessions, key=lambda s: s["mtime"], reverse=True)


def discover_all_sessions(since_hours: float = 24) -> list[dict]:
    """Discover sessions from all default sources."""
    all_sessions = []
    all_sessions.extend(discover_claude_sessions(since_hours))
    all_sessions.extend(discover_codex_sessions(since_hours))
    all_sessions.extend(discover_qwen_sessions(since_hours))
    all_sessions.extend(discover_chatgpt_sessions(since_hours))
    return sorted(all_sessions, key=lambda s: s["mtime"], reverse=True)


def sync_all(
    since_hours: float = 24,
    project: str | None = None,
    dry_run: bool = False,
    directory: Path | None = None,
    redact: bool | None = None,
    redact_mode: str | None = None,
    visibility: str = "private",
) -> list[str]:
    """Discover and sync all new sessions. Returns list of synced run IDs."""
    state = _load_sync_state()
    sessions = discover_in_directory(directory, since_hours) if directory else discover_all_sessions(since_hours)
    synced_ids = []

    for session_info in sessions:
        h = _session_hash(session_info["path"])
        if h in state["synced"]:
            continue

        if dry_run:
            logger.info(f"[dry-run] Would sync: {session_info['source']} {session_info['path']}")
            continue

        # Parse
        if session_info["source"] == "claude-code":
            parsed = parse_claude_session(session_info["path"])
        else:
            parsed = parse_generic_session(session_info["path"], session_info["source"])

        # Sync
        run_id = sync_session_to_openrunner(parsed, project=project, redact=redact, redact_mode=redact_mode, visibility=visibility)
        if run_id:
            state["synced"][h] = {
                "run_id": run_id,
                "source": session_info["source"],
                "synced_at": datetime.now(timezone.utc).isoformat(),
            }
            synced_ids.append(run_id)
            logger.info(f"Synced {session_info['source']} session -> run {run_id}")

    _save_sync_state(state)
    return synced_ids


# ---------------------------------------------------------------------------
# Claude Code hook installer
# ---------------------------------------------------------------------------


HOOK_SCRIPT = '''#!/usr/bin/env python3
"""Auto-log Claude Code session to OpenRunner on exit."""
import sys
import os
from pathlib import Path

def main():
    try:
        from openrunner.session import discover_claude_sessions, parse_claude_session, sync_session_to_openrunner

        # Find the session for the CWD project (not just any recent session)
        cwd = Path.cwd()
        cwd_key = "-" + str(cwd).replace("/", "-").lstrip("-")
        project_dir = Path.home() / ".claude" / "projects" / cwd_key

        if project_dir.exists():
            # Find most recent .jsonl in this project
            sessions = sorted(
                [f for f in project_dir.glob("*.jsonl") if f.stat().st_size > 100 and ".meta." not in f.name],
                key=lambda f: f.stat().st_mtime,
                reverse=True,
            )
        else:
            # Fallback: most recent globally
            sessions_info = discover_claude_sessions(since_hours=0.1)
            sessions = [s["path"] for s in sessions_info]

        if not sessions:
            return

        latest = sessions[0]
        parsed = parse_claude_session(latest)

        # Only sync if meaningful (>2 user messages)
        if parsed.get("user_message_count", 0) < 2:
            return

        run_id = sync_session_to_openrunner(parsed)
        if run_id:
            print(f"openrunner: Session logged as run {run_id}", file=sys.stderr)
    except Exception as e:
        # Never crash Claude Code on hook failure
        print(f"openrunner hook: {e}", file=sys.stderr)

if __name__ == "__main__":
    main()
'''


def install_claude_hook() -> str:
    """Install Claude Code hook for auto-session capture.

    Returns path to the installed hook config.
    """
    claude_dir = Path.home() / ".claude"
    claude_dir.mkdir(exist_ok=True)

    # Write hook script
    hook_script_path = claude_dir / "openrunner_session_hook.py"
    hook_script_path.write_text(HOOK_SCRIPT)
    hook_script_path.chmod(0o755)

    # Update or create hooks.json
    hooks_file = claude_dir / "hooks.json"
    if hooks_file.exists():
        hooks = json.loads(hooks_file.read_text())
    else:
        hooks = {"hooks": {}}

    # Add to Stop hooks
    stop_hooks = hooks.setdefault("hooks", {}).setdefault("Stop", [])
    hook_cmd = f"python3 {hook_script_path}"

    # Don't duplicate
    if not any(hook_cmd in str(h) for h in stop_hooks):
        stop_hooks.append({"command": hook_cmd})

    hooks_file.write_text(json.dumps(hooks, indent=2))
    return str(hooks_file)


# ---------------------------------------------------------------------------
# Watch mode (daemon)
# ---------------------------------------------------------------------------


def watch(interval: int = 60, project: str | None = None) -> None:
    """Watch for new sessions and sync them continuously."""
    logger.info(f"Watching for AI sessions (interval={interval}s)...")
    while True:
        try:
            synced = sync_all(since_hours=1, project=project)
            if synced:
                logger.info(f"Synced {len(synced)} new session(s)")
        except Exception as e:
            logger.warning(f"Watch cycle error: {e}")
        time.sleep(interval)
