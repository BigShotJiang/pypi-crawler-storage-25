"""Feedback module -- submit and retrieve feedback on traced spans.

Provides functions to add reactions, notes, and structured key-value
feedback to production spans for human-in-the-loop quality monitoring.

Usage::

    import openrunner
    from openrunner.feedback import add_feedback, get_feedback

    # Add thumbs-up reaction
    add_feedback("span-uuid", reaction="thumbs_up")

    # Add a note with custom key-values
    add_feedback(
        "span-uuid",
        note="Great response quality",
        accuracy=0.95,
        relevance="high",
    )

    # Retrieve all feedback for a span
    feedback = get_feedback("span-uuid")
"""

from __future__ import annotations

import logging
from typing import Any

logger = logging.getLogger("openrunner")

# Allowed reaction values (must match server-side VALID_REACTIONS)
VALID_REACTIONS = {
    "thumbs_up", "thumbs_down", "heart", "fire",
    "warning", "star", "check", "x",
}


def _get_client_and_project():
    """Get the active API client. Returns (client, project_id) or (None, None)."""
    try:
        import openrunner

        if openrunner._active_run is not None:
            return openrunner._active_run._client, openrunner._active_run._project_id
    except Exception:
        pass
    return None, None


def add_feedback(
    span_id: str,
    reaction: str | None = None,
    note: str | None = None,
    **kwargs: Any,
) -> dict[str, Any] | None:
    """Add feedback to a traced span. Never raises.

    Args:
        span_id: The UUID of the span to attach feedback to.
        reaction: Optional emoji reaction. One of: thumbs_up, thumbs_down,
            heart, fire, warning, star, check, x.
        note: Optional text note (max 1024 chars).
        **kwargs: Additional key-value pairs stored as structured feedback
            (e.g., accuracy=0.95, category="good").

    Returns:
        Server response dict with feedback details, or None on failure.
    """
    try:
        if reaction is not None and reaction not in VALID_REACTIONS:
            logger.warning(
                "add_feedback: invalid reaction %r. Must be one of: %s",
                reaction,
                sorted(VALID_REACTIONS),
            )
            return None

        if reaction is None and note is None and not kwargs:
            logger.warning(
                "add_feedback: must provide at least one of reaction, note, or key-value pairs"
            )
            return None

        client, _ = _get_client_and_project()
        if client is None:
            logger.warning(
                "add_feedback: no active run -- call openrunner.init() first"
            )
            return None

        body: dict[str, Any] = {}
        if reaction is not None:
            body["reaction"] = reaction
        if note is not None:
            body["note"] = note[:1024]
        if kwargs:
            body["key_values"] = kwargs

        response = client._request(
            "post", f"/spans/{span_id}/feedback", json=body
        )
        response.raise_for_status()
        return response.json()

    except Exception as e:
        logger.warning("add_feedback failed: %s", e)
        return None


def get_feedback(span_id: str) -> list[dict[str, Any]]:
    """Retrieve all feedback for a traced span. Never raises.

    Args:
        span_id: The UUID of the span to get feedback for.

    Returns:
        List of feedback dicts, or empty list on failure.
    """
    try:
        client, _ = _get_client_and_project()
        if client is None:
            logger.warning(
                "get_feedback: no active run -- call openrunner.init() first"
            )
            return []

        response = client._request("get", f"/spans/{span_id}/feedback")
        response.raise_for_status()
        data = response.json()
        return data if isinstance(data, list) else []

    except Exception as e:
        logger.warning("get_feedback failed: %s", e)
        return []
