"""
pikobs.pbs_submit
=================
Auto-submit helper for pikobs CLI commands.

When a pikobs command is run on a login node (no PBS_JOBID), this module
generates a minimal PBS script and submits it via qsub, then tails the
log live until the job finishes.

When already inside a PBS job (PBS_JOBID set), it does nothing and lets
the caller proceed normally.

Usage inside any pikobs arg_call():

    from pikobs.pbs_submit import maybe_submit_to_pbs
    import argparse, sys

    def arg_call():
        parser = argparse.ArgumentParser()
        parser.add_argument('--pathwork',  required=True)
        parser.add_argument('--n_cpus',    type=int, default=4)
        parser.add_argument('--walltime',  default='02:00:00')
        # ... other args ...
        parser.add_argument('--no_submit', action='store_true',
                            help='Skip PBS auto-submit and run locally')
        args = parser.parse_args()

        # This call returns only on the compute node (or if --no_submit).
        # On a login node it submits and exits.
        maybe_submit_to_pbs(args)

        # ... rest of the function (runs on compute node only) ...
"""

import os
import sys
import shutil
import subprocess
import tempfile
import time
from pathlib import Path


# ==============================================================================
# VERSION CHECK
# ==============================================================================

def _check_version(project_dir: str) -> None:
    """Print version banner and offer upgrade if a newer PyPI version exists."""
    try:
        import pikobs
        try:
            from importlib.metadata import version as _v
            local = _v('pikobs')
        except Exception:
            local = getattr(pikobs, '__version__', 'installed')
    except ImportError:
        print("ERROR: cannot import pikobs.", file=sys.stderr)
        sys.exit(1)

    latest = ''
    try:
        import urllib.request, json
        with urllib.request.urlopen(
                'https://pypi.org/pypi/pikobs/json', timeout=10) as r:
            latest = json.loads(r.read())['info']['version']
    except Exception:
        pass

    suffix = f'  (latest on PyPI: {latest})' if latest and latest != local else ''
    print(f'Pikobs : {local}{suffix}')

    if latest and latest != local:
        try:
            from packaging.version import Version
            if Version(local) < Version(latest):
                # Interactive terminal — ask
                if sys.stdin.isatty():
                    ans = input(
                        f'\n  ⚠️  A newer version is available: {latest}\n'
                        f'  Installed: {local}\n'
                        f'  Update now? [y/N] '
                    ).strip().lower()
                    if ans == 'y':
                        _prefix = (os.environ.get('CONDA_PREFIX')
                                   or os.environ.get('VIRTUAL_ENV')
                                   or project_dir)
                        pip = Path(_prefix) / 'bin' / 'pip'
                        cmd = [str(pip) if pip.exists() else 'pip',
                               'install', '--upgrade', 'pikobs', '-q']
                        subprocess.run(cmd, check=False)
                        print(f'  ✅ Updated to {latest}')
                else:
                    print(f'  ⚠️  PyPI has {latest} — run: pip install --upgrade pikobs')
            else:
                print(f'  ℹ️  Dev build ({local} > PyPI {latest})')
        except Exception:
            pass


# ==============================================================================
# PBS AUTO-SUBMIT
# ==============================================================================

def maybe_submit_to_pbs(args) -> None:
    """
    If running on a login node (PBS_JOBID not set) and --no_submit is not
    given, generate a PBS script from sys.argv, submit it, tail the log,
    and exit.  Otherwise return immediately (compute node path).
    """
    in_compute_node = bool(os.environ.get('PBS_JOBID') or os.environ.get('PBS_ENVIRONMENT'))
    is_no_submit = getattr(args, 'no_submit', False)

    # ==========================================================================
    # 1. LOCAL / COMPUTE NODE MODE (Silent return)
    # ==========================================================================
    if in_compute_node or is_no_submit:
        # Lifesaver: If the user requested local execution but we detect 
        # they are still on the login node.
        if is_no_submit and not in_compute_node:
            print("\n⚠️  WARNING: You are using '--no_submit' on a Login Node. \n 
                        qsub -I -lselect=1:ncpus=80:mem=185gb,place=scatter:excl -lwalltime=6:0:0")
            ans = input("Have you opened an interactive session (e.g., qsub -I) before running this? [y/N]: ").strip().lower()
            if ans != 'y':
                print("❌ Cancelled. Please open a compute node first or run without '--no_submit'.\n")
                sys.exit(1)
            print("Continuing on the login node at your own risk...\n")
        
        # Silent return (fewer messages, skips version check)
        return

    # ==========================================================================
    # 2. SUBMIT MODE (PBS queue)
    # ==========================================================================
    pathwork = Path(getattr(args, 'pathwork', '.')).expanduser()
    pathwork.mkdir(parents=True, exist_ok=True)

    # Resolve project directory
    project_dir = os.environ.get('PIKOBS_PROJECT_DIR', '')
    if not project_dir:
        try:
            import pikobs as _pk
            for _p in [Path(_pk.__file__).parent, *Path(_pk.__file__).parents]:
                if (_p / 'load_pikobs.sh').exists():
                    project_dir = str(_p); break
        except Exception:
            pass
    if not project_dir:
        project_dir = os.environ.get('CONDA_PREFIX',
                      os.environ.get('VIRTUAL_ENV', ''))

    # Version check ONLY when submitting to PBS
    _check_version(project_dir)

    if not shutil.which('qsub'):
        print('WARNING: qsub not found — running locally.')
        return

    n_cpus   = getattr(args, 'n_cpus',   4)
    walltime = getattr(args, 'walltime', '02:00:00')

    pikobs_src = os.environ.get('PIKOBS_SRC', '')
    if not pikobs_src:
        try:
            import pikobs as _pk
            pikobs_src = str(Path(_pk.__file__).parent.parent)
        except Exception:
            pikobs_src = ''

    loader = Path(project_dir) / 'load_pikobs.sh' if project_dir else None

    # Find the correct Python executable
    python_exe = sys.executable 
    try:
        import pikobs as _pk
        _env_python = Path(_pk.__file__).parent.parent.parent / 'bin' / 'python'
        if _env_python.exists():
            python_exe = str(_env_python)
    except Exception:
        pass

    log_file = pathwork / f'pikobs_{time.strftime("%Y%m%d_%H%M%S")}.log'
    log_file.touch()

    # Reconstruct the original command
    import shlex

    # Reconstruct the original command (FIXED for python -c)
    try:
        # Lee el comando exacto desde Linux (recuperando el código de -c)
        with open('/proc/self/cmdline', 'r') as f:
            full_cmd = f.read().split('\0')[:-1]
        args_list = full_cmd[1:] # Ignora el ejecutable 'python' de la posición 0
    except Exception:
        args_list = sys.argv

    # shlex.quote pone automáticamente las comillas perfectas donde hagan falta
    cmd_args = ' '.join(shlex.quote(a) for a in args_list)
    pbs_script = f"""\
#!/usr/bin/env bash
set -eo pipefail
export PYTHONNOUSERSITE=1 PYTHONUNBUFFERED=1
export OMP_NUM_THREADS=1 OPENBLAS_NUM_THREADS=1 MKL_NUM_THREADS=1
export VECLIB_MAXIMUM_THREADS=1 NUMEXPR_NUM_THREADS=1
export HDF5_USE_FILE_LOCKING=FALSE

echo "Running on: $(hostname)  JobID: $PBS_JOBID"
echo "Date: $(date '+%Y-%m-%d %H:%M:%S')"

[ -f "{loader}" ] && source "{loader}"
[ -n "{pikobs_src}" ] && export PYTHONPATH="{pikobs_src}:${{PYTHONPATH:-}}"

{python_exe} -u {cmd_args} --no_submit
"""

    with tempfile.NamedTemporaryFile(
            dir=pathwork,
            mode='w', suffix='.sh', prefix='pikobs_pbs_',
            delete=False) as tmp:
        tmp.write(pbs_script)
        tmp_path = tmp.name
    os.chmod(tmp_path, 0o755)

    try:
        result = subprocess.run(
            ['qsub', '-V',
             '-N', 'pikobs',
             '-l', f'select=1:ncpus={n_cpus}:mem=185gb',
             '-l', f'walltime={walltime}',
             '-j', 'oe',
             '-o', str(log_file),
             '--', tmp_path],
            capture_output=True, text=True, check=True
        )
        job_id = result.stdout.strip().split()[0]
    except subprocess.CalledProcessError as e:
        print(f'ERROR qsub failed: {e.stderr}', file=sys.stderr)
        # os.unlink(tmp_path) 
        sys.exit(1)

    print(f'\nJob    : {job_id}')
    print(f'Log    : {log_file}')
    print('Tip    : Ctrl+C to detach — job keeps running.')
    print(f'         Re-attach: tail -f {log_file}')
    print('=' * 65)
    waited = 0
    while True:
        try:
            # Si el archivo existe y tiene texto, salimos del bucle
            if log_file.exists() and log_file.stat().st_size > 0:
                break
        except FileNotFoundError:
            # Si PBS lo borró momentáneamente, lo ignoramos y seguimos esperando
            pass
            
        time.sleep(3)
        waited += 3
        if waited >= 120:
            try:
                subprocess.run(['qstat', job_id],
                               capture_output=True, check=True)
            except subprocess.CalledProcessError:
                print(f'ERROR job gone, empty log. Check: qstat -xf {job_id}',
                      file=sys.stderr)
                sys.exit(1)
            print('Still waiting for job to start...')
            waited = 0

    tail = subprocess.Popen(['tail', '-n', '+1', '-f', str(log_file)])
    try:
        while True:
            try:
                subprocess.run(['qstat', job_id],
                               capture_output=True, check=True)
                time.sleep(5)
            except subprocess.CalledProcessError:
                break
    except KeyboardInterrupt:
        print('\nDetached — job keeps running.')
    finally:
        time.sleep(3)
        tail.terminate()
        # os.unlink(tmp_path) 

    print('=' * 65)
    print(f'Job {job_id} finished.  Log: {log_file}')
    sys.exit(0)
