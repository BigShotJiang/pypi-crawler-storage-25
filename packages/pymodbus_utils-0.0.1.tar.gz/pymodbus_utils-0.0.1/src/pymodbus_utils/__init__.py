from enum import Enum
import pymodbus.client as ModbusClient
from pymodbus.pdu import ExceptionResponse
from pymodbus import FramerType, ModbusException

def connect_modbus_rtu_server(port: str, baudrate: int, bytesize: int, parity: str, 
                              stopbits: int) -> ModbusClient.ModbusSerialClient:
    """
    Return a connected client
 
    Parameters
    ----------
    port: str
        port connected to the rtu modbus e.g. on linux '/dev/ttyAMA2'
    
    baudrate: int
        baudrate, specification of the modbus device, e.g. 38400 

    bytesize: int
        bytesize, specification of the modbus device, e.g. 8
    
    parity: str
        parity, specification of the modbus device, e.g. 'N'

    stopbits: int
        stopbits, specification of the modbus device, e.g. '2'
    
    Returns
    -------
    ModbusClient.ModbusSerialClient
        the connected modbus rtu client
    """
    client = ModbusClient.ModbusSerialClient(
        port,
        framer=FramerType.RTU,
        baudrate=baudrate,
        bytesize=bytesize,
        parity=parity,
        stopbits=stopbits,
    )
    client.connect()
    return client

def connect_modbus_tcp_server(host: str, port: int = 502) -> ModbusClient.ModbusTcpClient:
    """
    connect to a modbus tcp server.
 
    Parameters
    ----------
    host : str
        the ipv4 address of the modbus device e.g. "10.0.0.227"
    
    port: int, optional
        the port of the ipv4 address, for modbus the default port is 502
    
    Returns
    -------
    ModbusClient.ModbusTcpClient
        the connected modbus tcp client
    """
    client = ModbusClient.ModbusTcpClient(
        host=host,
        port=port
    )
    client.connect()
    return client

def write_register(client: ModbusClient.ModbusSerialClient | ModbusClient.ModbusTcpClient, addr: int, value: int):
    """Write a register."""
    try:
        # rr = client.write_registers(address=addr, values=[value], device_id=1)
        rr = client.write_register(addr, value)
        print(f"write is {rr}, Value = {value}")
    except ModbusException as exc:
        print(f"Modbus exception: {exc!s}")
    if rr.isError():
        print(f"Error")
    if isinstance(rr, ExceptionResponse):
        print(f"Response exception: {rr!s}")

def read_register(client: ModbusClient.ModbusSerialClient | ModbusClient.ModbusTcpClient, addr: int, format: str, 
                  device_id: int = 1, reg_type: str = 'Holding Register') -> int:
    """
    read a register.
 
    Parameters
    ----------
    client : ModbusTcpClient
        modbus client object
    
    addr: int
        address of the register

    format: str
        h=int16, H=uint16, i=int32 ,I=uint32, q=int64, Q=uint64, f=float32, d=float64, s=string, bits
    
    device_id: int, optional
        default is 1, id of the modbus device to read.

    reg_type: str, optional
        default is Holding Register. Options are Input Register
    
    Returns
    -------
    int
        the value of the register
    """
    data_type = get_data_type(format)
    # print(data_type)
    count = data_type.value[1]
    var_type = data_type.name
    print(f"*** Reading register({var_type})")
    try:
        if reg_type == 'Holding Register':
            rr = client.read_holding_registers(address=addr, count=count, device_id=device_id)
        elif reg_type == 'Input Register':
            rr = client.read_input_registers(address=addr, count=count, device_id=device_id)
        # rr = client.read_coils(addr)
    except ModbusException as exc:
        print(f"Modbus exception: {exc!s}")
   
    if rr.isError():
        print(f"Error")

    if isinstance(rr, ExceptionResponse):
        print(f"Response exception: {rr!s}")

    value = client.convert_from_registers(rr.registers, data_type)
    return value

def get_data_type(format: str) -> Enum:
    """
    get the pymodbus data type.
 
    Parameters
    ----------
    format: str
        h=int16, H=uint16, i=int32 ,I=uint32, q=int64, Q=uint64, f=float32, d=float64, s=string, bits
    
    Returns
    -------
    Enum
        pymodbus data type enum
    """
    for data_type in ModbusClient.ModbusSerialClient.DATATYPE:
        if data_type.value[0] == format:
            return data_type