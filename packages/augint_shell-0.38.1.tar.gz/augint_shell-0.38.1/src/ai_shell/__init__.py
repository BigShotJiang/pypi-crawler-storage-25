"""augint-shell (ai-shell) - Launch AI coding tools and local LLMs in Docker containers."""

__version__ = "0.38.1"

__all__ = [
    "__version__",
]
