from setuptools import setup, find_packages
setup(
    name="aithinking",
    version="0.0.1",
    packages=find_packages(),
    description="Decker Ops -- coming soon.",
    author="DeckerOps",
    author_email="decker.ops@gmail.com",
    url="https://github.com/DeckerOps",
    python_requires=">=3.8",
)
