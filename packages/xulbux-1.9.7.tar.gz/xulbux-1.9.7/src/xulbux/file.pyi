from pathlib import Path

class File:
    @classmethod
    def rename_extension(cls, file_path: Path | str, new_extension: str, /, *, full_extension: bool = False, camel_case_filename: bool = False) -> Path: ...
    @classmethod
    def create(cls, file_path: Path | str, content: str = '', /, *, force: bool = False) -> Path: ...
