from _typeshed import Incomplete

def get_latest_version() -> str | None: ...
def is_latest_version() -> bool | None: ...

URL: str
IS_LATEST_VERSION: Incomplete
CLI_COLORS: Incomplete
CLI_HELP: Incomplete

def show_help() -> None: ...
