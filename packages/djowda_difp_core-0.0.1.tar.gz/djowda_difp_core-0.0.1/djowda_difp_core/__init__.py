"""
DJOWDA DIFP CORE - initial release (structure placeholder).
"""
