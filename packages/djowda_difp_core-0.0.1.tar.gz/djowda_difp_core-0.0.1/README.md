# DJOWDA DIFP CORE

Initial skeleton package for DJOWDA DIFP CORE.
