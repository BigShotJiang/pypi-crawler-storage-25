"""PutPlace Server scripts."""
