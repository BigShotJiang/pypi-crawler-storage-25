## 1.10.0

- Rename `predicate` parameter to `scoring_criteria` in `Evaluators.create()`, `acreate()`, `update()`, and `aupdate()`

## 1.9.1

- Patch high-severity dependency vulnerability (urllib3 2.7.0 — CVE-2026-44431: sensitive headers forwarded in proxied redirects, decompression-bomb bypass)

## 1.9.0

- Add file upload support

## 1.8.0

- Simplify visibility model: replace multi-value `status` field with `private`/`public` visibility
- Remove `status` parameter from judge and evaluator creation
- Update `generate()`/`agenerate()` visibility to accept `"private"`, `"public"`, `"global"` (default: `"private"`)
- Remove deprecated RAGAS preset evaluators: `Answer_Relevance`, `Answer_Semantic_Similarity`, `Context_Precision`, `Context_Recall`, `Answer_Correctness`
- Remove `pii_filter`, `reference_variables`, `model_params`, `system_message` from skills API

## 1.7.2

- Patch high-severity dependency vulnerabilities (cryptography 46.0.5, urllib3 2.6.3)

## 1.7.1

- Simplify multi-turn api

## 1.7.0

- Add multi-turn conversation evaluation support

## 1.6.7

- Add user_id and session_id to evaluator and judge runs

## 1.6.6

- Remove functions field from evaluator requests

## 1.6.5

- Rebrand to scorable

## 1.6.4

### Added

- Status field to judges

## 1.6.3

### Added

- Add execute judge by name

### Changed

- Required evaluator inputs

## 1.6.2

### Added

- New execution log fields

## 1.6.1

### Added

- Added judge create method

## 1.6.0

### Added

- Added judge generate method.

### Changed

- Promoted judges out of beta.
- New signature for evaluator inputs.

### Removed

- Operational skills

## 1.5.4

### Added

- Added four new scorable evaluators


## 1.5.3

### Added

- Added `requires_contexts`, `requires_functions`, and `requires_expected_output` to evaluator list output

### Removed

- Removed data loaders. Input variables to be used as replacements for data loaders.

## 1.5.2

### Added

- Added evaluator execution by name

### Changed

- Evaluator uses new endpoints instead of deprecated ones in all functions

## 1.5.1

### Added

- Added 'include' parameter to listing execution logs to include optional fields

### Changed

- Dropped support for running only skill validators

## 1.5.0

### Added

- Added tags to evaluator and judge runs
- Added tag filtering to execution logs

### Changed

- Renamed the evaluator demonstration output and prompt parameters

## 1.4.0  

### Added
  - Introduced beta namespace for the client.  
  - Judges functionality for improved AI evaluation.  
  - Score field is now optional in `ExecutionLogList`.  
  - Colab example links for better accessibility.  
  - Refined example code formatting.  
  - Enhanced async usage documentation.  
  - Renamed custom evaluator for clarity.  



## 1.3.3

### Added

- Evaluators list and get methods
- Improved docstrings for the SDK

## 1.3.2

### Added

- Support 'items' property in the function passed to the JSON Schema evaluators

## 1.3.1

### Added

- Added asynchronous client and methods
- Support additional variables for custom evaluators
