"""CLI commands for SuperAgent SOP pipeline management.

Provides the ``superagent pipeline`` subcommand group with list, show, create,
add-stage, and run operations.  Uses Rich tables and panels for formatted output.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.pipeline import Pipeline, PipelineStage, get_pipeline_registry

pipeline_app = typer.Typer(
    name="pipeline",
    help="SOP Pipelines — define, inspect, and run multi-stage agent workflows.",
    no_args_is_help=True,
)
console = Console()


def _get_registry():
    """Create a PipelineRegistry using the configured data directory."""
    data_dir = os.environ.get(
        "CLAWTEAM_DATA_DIR",
        os.path.join(os.path.expanduser("~"), ".superagent"),
    )
    return get_pipeline_registry(data_dir)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@pipeline_app.command("list")
def pipeline_list(
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List all registered pipelines."""
    registry = _get_registry()
    pipelines = registry.list_all()

    if json_out:
        data = [
            {
                "name": p.name,
                "description": p.description,
                "stages": len(p.stages),
            }
            for p in pipelines
        ]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not pipelines:
        console.print("[yellow]No pipelines registered.[/yellow]")
        return

    table = Table(title=f"SOP Pipelines ({len(pipelines)})")
    table.add_column("Name", style="bold cyan", width=20)
    table.add_column("Stages", style="green", width=8, justify="center")
    table.add_column("Description", style="dim", max_width=55)

    for p in pipelines:
        table.add_row(p.name, str(len(p.stages)), p.description)

    console.print(table)


@pipeline_app.command("show")
def pipeline_show(
    name: str = typer.Argument(..., help="Pipeline name to display."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Show pipeline stages with a visual flow diagram."""
    registry = _get_registry()
    pipeline = registry.get(name)

    if pipeline is None:
        console.print(f"[red]Pipeline '{name}' not found.[/red]")
        raise typer.Exit(1)

    if json_out:
        console.print(json.dumps(pipeline.to_dict(), indent=2, ensure_ascii=False))
        return

    # Build the visual flow diagram
    flow_lines: list[str] = []
    for i, stage in enumerate(pipeline.stages):
        input_note = ""
        if stage.input_from:
            input_note = f"  [dim](reads from {stage.input_from})[/dim]"
        flow_lines.append(f"  [bold]{stage.name}[/bold] [dim]({stage.role})[/dim]{input_note}")
        flow_lines.append(f"    [green]->[/green] {stage.output_artifact}")
        if i < len(pipeline.stages) - 1:
            flow_lines.append("")

    flow_text = "\n".join(flow_lines)

    console.print(Panel(
        f"[bold]Pipeline:[/bold] {pipeline.name}\n"
        f"[bold]Description:[/bold] {pipeline.description}\n"
        f"[bold]Stages:[/bold] {len(pipeline.stages)}\n\n"
        f"{flow_text}",
        title=f"Pipeline: {pipeline.name}",
        border_style="cyan",
    ))

    # Stage detail table
    table = Table(title="Stage Details", show_lines=True)
    table.add_column("#", style="bold", width=4, justify="center")
    table.add_column("Stage", style="bold cyan", width=14)
    table.add_column("Role", style="magenta", width=22)
    table.add_column("Input From", style="blue", width=14)
    table.add_column("Output", style="green", width=20)
    table.add_column("Description", style="dim", max_width=35)

    for i, stage in enumerate(pipeline.stages, 1):
        table.add_row(
            str(i),
            stage.name,
            stage.role,
            stage.input_from or "(goal)",
            stage.output_artifact,
            stage.description,
        )

    console.print(table)


@pipeline_app.command("create")
def pipeline_create(
    name: str = typer.Argument(..., help="Name for the new pipeline."),
    description: str = typer.Option("", "--description", "-d", help="Pipeline description."),
):
    """Create a new empty pipeline."""
    registry = _get_registry()

    existing = registry.get(name)
    if existing is not None:
        console.print(f"[red]Pipeline '{name}' already exists. Remove it first or choose a different name.[/red]")
        raise typer.Exit(1)

    pipeline = Pipeline(name=name, description=description, stages=[])
    registry.register(pipeline)
    console.print(Panel(
        f"[bold green]Pipeline created[/bold green]\n\n"
        f"  [bold]Name:[/bold]        {pipeline.name}\n"
        f"  [bold]Description:[/bold] {pipeline.description or '(none)'}\n"
        f"  [bold]Stages:[/bold]      0\n\n"
        f"[dim]Add stages with:[/dim] superagent pipeline add-stage {name} --name \"Stage\" --role \"Role\" --output \"artifact\"",
        title="pipeline create",
        border_style="green",
    ))


@pipeline_app.command("add-stage")
def pipeline_add_stage(
    pipeline_name: str = typer.Argument(..., help="Pipeline to add the stage to."),
    name: str = typer.Option(..., "--name", "-n", help="Stage name."),
    role: str = typer.Option(..., "--role", "-r", help="Agent role for this stage."),
    output: str = typer.Option(..., "--output", "-o", help="Output artifact filename."),
    input_from: Optional[str] = typer.Option(None, "--input-from", "-i", help="Previous stage name to read input from."),
    prompt: str = typer.Option(
        "",
        "--prompt",
        "-p",
        help="Prompt template (use {goal}, {input}, {output} placeholders).",
    ),
    description: str = typer.Option("", "--description", "-d", help="Stage description."),
):
    """Add a stage to an existing pipeline."""
    registry = _get_registry()
    pipeline = registry.get(pipeline_name)

    if pipeline is None:
        console.print(f"[red]Pipeline '{pipeline_name}' not found.[/red]")
        raise typer.Exit(1)

    # Validate input_from references an existing stage
    if input_from:
        stage_names = {s.name for s in pipeline.stages}
        if input_from not in stage_names:
            console.print(
                f"[red]Stage '{input_from}' not found in pipeline '{pipeline_name}'. "
                f"Available stages: {', '.join(sorted(stage_names)) or '(none)'}[/red]"
            )
            raise typer.Exit(1)

    # Auto-link to previous stage if not specified and stages exist
    if input_from is None and pipeline.stages:
        input_from = pipeline.stages[-1].name

    # Default prompt template
    if not prompt:
        prompt = (
            f"You are a {role}. "
            "Complete your task based on the goal and any input provided.\n\n"
            "Goal: {goal}\n"
            "Input: {input}\n\n"
            "Write your output to {output}."
        )

    stage = PipelineStage(
        name=name,
        role=role,
        description=description,
        input_from=input_from,
        output_artifact=output,
        prompt_template=prompt,
    )
    pipeline.stages.append(stage)
    registry.register(pipeline)

    console.print(
        f"[green]Added stage '[bold]{name}[/bold]' to pipeline '{pipeline_name}' "
        f"(stage {len(pipeline.stages)}).[/green]"
    )


@pipeline_app.command("remove")
def pipeline_remove(
    name: str = typer.Argument(..., help="Pipeline name to remove."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
):
    """Remove a pipeline."""
    registry = _get_registry()
    pipeline = registry.get(name)

    if pipeline is None:
        console.print(f"[red]Pipeline '{name}' not found.[/red]")
        raise typer.Exit(1)

    if not force:
        confirm = typer.confirm(f"Remove pipeline '{name}' ({len(pipeline.stages)} stages)?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    registry.remove(name)
    console.print(f"[green]Removed pipeline '{name}'.[/green]")


@pipeline_app.command("run")
def pipeline_run(
    name: str = typer.Argument(..., help="Pipeline name to execute."),
    goal: str = typer.Option(..., "--goal", "-g", help="The project goal."),
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Team name (auto-generated if not specified)."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show the launch plan without executing."),
    command: str = typer.Option("claude", "--command", "-c", help="CLI agent command."),
    backend: str = typer.Option("tmux", "--backend", "-b", help="Backend: tmux or subprocess."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Run a pipeline — generate a launch plan from pipeline stages.

    With --dry-run, shows the plan without launching. Without it, calls
    ``superagent auto`` internally to launch the team.
    """
    registry = _get_registry()
    pipeline = registry.get(name)

    if pipeline is None:
        console.print(f"[red]Pipeline '{name}' not found.[/red]")
        raise typer.Exit(1)

    if not pipeline.stages:
        console.print(f"[red]Pipeline '{name}' has no stages. Add stages first.[/red]")
        raise typer.Exit(1)

    # Build the execution plan
    plan_stages: list[dict] = []
    for i, stage in enumerate(pipeline.stages):
        # Resolve input artifact
        input_artifact = None
        if stage.input_from:
            for prev in pipeline.stages:
                if prev.name == stage.input_from:
                    input_artifact = prev.output_artifact
                    break

        rendered_prompt = stage.prompt_template.format(
            goal=goal,
            input=input_artifact or "(project goal)",
            output=stage.output_artifact,
        )

        plan_stages.append({
            "stage": i + 1,
            "name": stage.name,
            "role": stage.role,
            "input_from": stage.input_from,
            "input_artifact": input_artifact,
            "output_artifact": stage.output_artifact,
            "prompt": rendered_prompt,
        })

    plan_data = {
        "pipeline": pipeline.name,
        "goal": goal,
        "team": team,
        "stages": plan_stages,
    }

    if json_out:
        console.print(json.dumps(plan_data, indent=2, ensure_ascii=False))
        return

    # Display the plan
    console.print(f"\n[bold]Pipeline:[/bold] {pipeline.name}")
    console.print(f"[bold]Goal:[/bold] {goal}")
    if team:
        console.print(f"[bold]Team:[/bold] {team}")
    console.print()

    # Visual flow
    console.print(Panel(
        _render_flow(pipeline, goal),
        title="Execution Plan",
        border_style="cyan",
    ))

    # Stage detail table
    table = Table(title="Stage Execution Order", show_lines=True)
    table.add_column("#", width=4, justify="center")
    table.add_column("Stage", style="bold cyan", width=14)
    table.add_column("Role", style="magenta", width=22)
    table.add_column("Reads", style="blue", width=20)
    table.add_column("Produces", style="green", width=20)

    for ps in plan_stages:
        table.add_row(
            str(ps["stage"]),
            ps["name"],
            ps["role"],
            ps["input_artifact"] or "(goal)",
            ps["output_artifact"],
        )

    console.print(table)

    if dry_run:
        console.print("\n[dim]Dry run -- no agents launched. Remove --dry-run to execute.[/dim]")
        return

    # Launch via superagent auto
    console.print(f"\n[bold green]Launching pipeline '{pipeline.name}'...[/bold green]\n")

    # Build a descriptive goal that encodes the pipeline flow
    auto_goal = (
        f"[Pipeline: {pipeline.name}] {goal}\n\n"
        f"Execute the following stages in order:\n"
    )
    for ps in plan_stages:
        auto_goal += (
            f"  Stage {ps['stage']}: {ps['name']} ({ps['role']}) "
            f"-> {ps['output_artifact']}\n"
        )

    launch_cmd = [
        sys.executable, "-m", "superagent",
        "auto", auto_goal,
        "--max-agents", str(len(pipeline.stages)),
        "--command", command,
        "--backend", backend,
    ]
    if team:
        launch_cmd.extend(["--team", team])

    console.print(f"[dim]$ {' '.join(launch_cmd)}[/dim]\n")

    try:
        result = subprocess.run(launch_cmd, cwd=os.getcwd())
        if result.returncode == 0:
            console.print(f"\n[bold green]Pipeline '{pipeline.name}' launched successfully![/bold green]")
        else:
            console.print(f"\n[red]Pipeline launch failed with exit code {result.returncode}[/red]")
    except KeyboardInterrupt:
        console.print("\n[yellow]Launch interrupted.[/yellow]")
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")


# ------------------------------------------------------------------
# Helpers
# ------------------------------------------------------------------


def _render_flow(pipeline: Pipeline, goal: str) -> str:
    """Render a visual flow diagram for a pipeline."""
    lines: list[str] = []
    for i, stage in enumerate(pipeline.stages):
        lines.append(f"  [bold]{stage.name}[/bold] [dim]({stage.role})[/dim]")
        lines.append(f"    [green]->[/green] {stage.output_artifact}")
        if i < len(pipeline.stages) - 1:
            lines.append("")
    return "\n".join(lines)
