"""Corrections system — shared correction memory that propagates across all agents.

Inspired by Moxt.ai's pattern where corrections made to one agent
are automatically learned by all agents in the team.

Corrections are stored as JSON files under ~/.superagent/corrections/
and injected into agent prompts at execution time.
"""
from __future__ import annotations

import json
import logging
import os
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class Correction:
    """A shared correction that applies to all agents."""

    id: str
    content: str
    category: str  # style, behavior, output, domain
    source_agent: str  # which agent was corrected
    created_at: str
    applied_count: int = 0

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "content": self.content,
            "category": self.category,
            "source_agent": self.source_agent,
            "created_at": self.created_at,
            "applied_count": self.applied_count,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Correction:
        return cls(
            id=data["id"],
            content=data["content"],
            category=data.get("category", "general"),
            source_agent=data.get("source_agent", ""),
            created_at=data.get("created_at", ""),
            applied_count=data.get("applied_count", 0),
        )


class CorrectionStore:
    """Manages shared corrections that propagate to all agents."""

    def __init__(self, corrections_dir: str | Path):
        self._dir = Path(corrections_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def add(self, content: str, category: str = "general",
            source_agent: str = "user") -> Correction:
        """Add a new correction that will apply to all future agent executions."""
        correction = Correction(
            id=uuid.uuid4().hex[:12],
            content=content,
            category=category,
            source_agent=source_agent,
            created_at=datetime.now(timezone.utc).isoformat(),
        )
        path = self._dir / f"{correction.id}.json"
        atomic_write(path, json.dumps(correction.to_dict(), indent=2, ensure_ascii=False))
        logger.info("Correction added: %s (category=%s)", correction.id, category)
        return correction

    def list_all(self) -> list[Correction]:
        """Return all active corrections sorted by creation time."""
        corrections = []
        for path in sorted(self._dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                corrections.append(Correction.from_dict(data))
            except (json.JSONDecodeError, KeyError):
                continue
        return corrections

    def get_prompt_block(self, limit: int = 10) -> str:
        """Generate a prompt block containing recent corrections.

        Returns empty string if no corrections exist.
        """
        corrections = self.list_all()[-limit:]
        if not corrections:
            return ""

        lines = [
            "\n## Shared Team Corrections",
            "The following corrections have been learned from past interactions.",
            "Apply these rules consistently:\n",
        ]
        for c in corrections:
            lines.append(f"- [{c.category}] {c.content}")

        return "\n".join(lines) + "\n"

    def remove(self, correction_id: str) -> bool:
        """Remove a correction by ID."""
        path = self._dir / f"{correction_id}.json"
        if path.exists():
            path.unlink()
            return True
        return False


def get_correction_store(data_dir: Optional[str] = None) -> CorrectionStore:
    if data_dir is None:
        data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    return CorrectionStore(os.path.join(data_dir, "corrections"))
