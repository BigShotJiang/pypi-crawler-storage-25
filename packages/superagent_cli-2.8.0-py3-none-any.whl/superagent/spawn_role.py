"""Spawn-role helpers — inject role prompts into agent tasks.

Provides two functions:
- build_role_task: combine a role template's prompt with a task description
- inject_roles_into_toml: pre-launch hook that resolves role fields in TOML templates
"""

from __future__ import annotations

import re
from pathlib import Path
from typing import Optional

from superagent.roles import get_role_index


def build_role_task(role_name: str, task: str, roles_dir: Optional[str] = None) -> str:
    """Combine a role template's prompt with a task description.

    Loads the role by name from the role index, reads its full Markdown prompt,
    and prepends it to the given task string with a separator.

    Args:
        role_name: Exact role name (case-insensitive), e.g. "Code Reviewer".
        task: The original task description for the agent.
        roles_dir: Optional path to roles directory. Uses default if None.

    Returns:
        The task string with the role prompt prepended, or the original task
        unchanged if the role is not found.
    """
    index = get_role_index(roles_dir)
    role = index.get_role(role_name)
    if role is None:
        return task
    prompt = role.load_prompt()
    if not prompt.strip():
        return task
    return f"{prompt.strip()}\n\n---\n\n{task}"


def inject_roles_into_toml(toml_path: str, roles_dir: Optional[str] = None) -> str:
    """Read a TOML template, resolve role fields, and write back.

    For each ``[[template.agents]]`` block that contains a ``role = "..."``
    field, loads the corresponding role prompt and prepends it to the agent's
    ``task`` value.  The ``role`` line is removed after injection.

    Args:
        toml_path: Path to the TOML template file.
        roles_dir: Optional path to roles directory. Uses default if None.

    Returns:
        The path to the (modified) TOML file.
    """
    path = Path(toml_path)
    content = path.read_text(encoding="utf-8")

    index = get_role_index(roles_dir)

    # Pattern to match agent blocks with a role field.
    # We process the file as text to avoid adding a TOML library dependency.
    # Strategy: find each [[template.agents]] block, look for role = "...",
    # and if found, prepend the role prompt to the task value.

    lines = content.splitlines(keepends=True)
    result: list[str] = []
    i = 0

    while i < len(lines):
        line = lines[i]

        # Detect start of an agent block
        if re.match(r'^\s*\[\[template\.agents\]\]\s*$', line):
            # Collect the entire block (until next section header or EOF)
            block_lines = [line]
            i += 1
            while i < len(lines) and not re.match(r'^\s*\[', lines[i]):
                block_lines.append(lines[i])
                i += 1

            block_text = "".join(block_lines)

            # Check for role field
            role_match = re.search(r'^role\s*=\s*"([^"]+)"', block_text, re.MULTILINE)
            if role_match:
                role_name = role_match.group(1)
                role_template = index.get_role(role_name)

                if role_template:
                    role_prompt = role_template.load_prompt().strip()

                    if role_prompt:
                        # Find and modify the task field — handles multi-line triple-quoted strings
                        task_pattern = re.compile(
                            r'(task\s*=\s*""")(.*?)(""")',
                            re.DOTALL,
                        )
                        task_match = task_pattern.search(block_text)
                        if task_match:
                            original_task = task_match.group(2)
                            new_task = f"{role_prompt}\n\n---\n\n{original_task}"
                            block_text = (
                                block_text[:task_match.start()]
                                + task_match.group(1)
                                + new_task
                                + task_match.group(3)
                                + block_text[task_match.end():]
                            )
                        else:
                            # Try single-quoted task
                            task_pattern_single = re.compile(
                                r'(task\s*=\s*")((?:[^"\\]|\\.)*)(")',
                            )
                            task_match_single = task_pattern_single.search(block_text)
                            if task_match_single:
                                original_task = task_match_single.group(2)
                                new_task = f"{role_prompt}\\n\\n---\\n\\n{original_task}"
                                block_text = (
                                    block_text[:task_match_single.start()]
                                    + task_match_single.group(1)
                                    + new_task
                                    + task_match_single.group(3)
                                    + block_text[task_match_single.end():]
                                )

                # Remove the role line
                block_text = re.sub(r'^role\s*=\s*"[^"]*"\s*\n', '', block_text, flags=re.MULTILINE)

            result.append(block_text)
        else:
            result.append(line)
            i += 1

    new_content = "".join(result)
    path.write_text(new_content, encoding="utf-8")
    return str(path)
