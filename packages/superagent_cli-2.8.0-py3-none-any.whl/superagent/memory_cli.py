"""CLI commands for SuperAgent memory management.

Provides the ``superagent memory`` subcommand group with write, search, list,
show, delete, export, and purge operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import json
import os
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.memory import MemoryScope, get_memory_store

memory_app = typer.Typer(
    name="memory",
    help="Memory management — write, search, list, and manage layered agent memories.",
    no_args_is_help=True,
)
console = Console()


def _resolve_scope(scope: Optional[str]) -> Optional[MemoryScope]:
    """Convert a CLI scope string to a MemoryScope enum value."""
    if scope is None:
        return None
    scope = scope.strip().lower()
    if scope == "global":
        return MemoryScope.global_
    try:
        return MemoryScope(scope)
    except ValueError:
        console.print(f"[red]Invalid scope '{scope}'. Choose from: agent, team, global[/red]")
        raise typer.Exit(1)


def _get_store():
    """Create a MemoryStore using the configured data directory."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    return get_memory_store(data_dir)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@memory_app.command("write")
def memory_write(
    content: str = typer.Argument(..., help="Memory content to store."),
    tags: Optional[str] = typer.Option(None, "--tags", "-t", help="Comma-separated tags."),
    scope: str = typer.Option("global", "--scope", "-s", help="Scope: agent, team, or global."),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent name (for agent scope)."),
    team: Optional[str] = typer.Option(None, "--team", help="Team name (for team scope)."),
    expires: Optional[str] = typer.Option(None, "--expires", help="Expiration ISO timestamp."),
):
    """Write a new memory entry."""
    store = _get_store()
    mem_scope = _resolve_scope(scope) or MemoryScope.global_
    tag_list = [t.strip() for t in tags.split(",") if t.strip()] if tags else []

    try:
        entry = store.write(
            content=content,
            tags=tag_list,
            scope=mem_scope,
            agent_name=agent,
            team_name=team,
            expires_at=expires,
        )
    except ValueError as e:
        console.print(f"[red]Error: {e}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold green]Memory saved[/bold green]\n\n"
        f"  [bold]ID:[/bold]    {entry.id}\n"
        f"  [bold]Scope:[/bold] {entry.scope.value}\n"
        f"  [bold]Tags:[/bold]  {', '.join(entry.tags) or '(none)'}",
        title="memory write",
        border_style="green",
    ))


@memory_app.command("search")
def memory_search(
    query: str = typer.Argument(..., help="Search query (keywords)."),
    scope: Optional[str] = typer.Option(None, "--scope", "-s", help="Filter by scope."),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by agent name."),
    team: Optional[str] = typer.Option(None, "--team", help="Filter by team name."),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Search memories by keyword."""
    store = _get_store()
    mem_scope = _resolve_scope(scope)
    results = store.search(query, scope=mem_scope, agent_name=agent, team_name=team, limit=limit)

    if json_out:
        data = [e.to_dict() for e in results]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not results:
        console.print(f"[yellow]No memories matching '{query}'.[/yellow]")
        return

    table = Table(title=f"Search: \"{query}\" ({len(results)} results)")
    table.add_column("ID", style="cyan", width=14)
    table.add_column("Scope", style="magenta", width=8)
    table.add_column("Tags", style="green", width=20)
    table.add_column("Content", max_width=50)
    table.add_column("Updated", style="dim", width=20)

    for entry in results:
        content_preview = entry.content[:50] + ("..." if len(entry.content) > 50 else "")
        table.add_row(
            entry.id,
            entry.scope.value,
            ", ".join(entry.tags) or "-",
            content_preview,
            entry.updated_at[:19],
        )

    console.print(table)


@memory_app.command("list")
def memory_list(
    scope: Optional[str] = typer.Option(None, "--scope", "-s", help="Filter by scope."),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by agent name."),
    team: Optional[str] = typer.Option(None, "--team", help="Filter by team name."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List memory entries."""
    store = _get_store()
    mem_scope = _resolve_scope(scope)
    entries = store.list_memories(scope=mem_scope, agent_name=agent, team_name=team)

    if json_out:
        data = [e.to_dict() for e in entries]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not entries:
        console.print("[yellow]No memories found.[/yellow]")
        return

    table = Table(title=f"Memories ({len(entries)} entries)")
    table.add_column("ID", style="cyan", width=14)
    table.add_column("Scope", style="magenta", width=8)
    table.add_column("Owner", style="blue", width=16)
    table.add_column("Tags", style="green", width=20)
    table.add_column("Content", max_width=45)
    table.add_column("Updated", style="dim", width=20)

    for entry in entries:
        owner = entry.agent_name or entry.team_name or "-"
        content_preview = entry.content[:45] + ("..." if len(entry.content) > 45 else "")
        table.add_row(
            entry.id,
            entry.scope.value,
            owner,
            ", ".join(entry.tags) or "-",
            content_preview,
            entry.updated_at[:19],
        )

    console.print(table)


@memory_app.command("show")
def memory_show(
    memory_id: str = typer.Argument(..., help="Memory entry ID."),
):
    """Show full details of a memory entry."""
    store = _get_store()
    entry = store.get(memory_id)

    if entry is None:
        console.print(f"[red]Memory '{memory_id}' not found.[/red]")
        raise typer.Exit(1)

    owner = entry.agent_name or entry.team_name or "(none)"
    expired_marker = " [red][EXPIRED][/red]" if entry.is_expired else ""

    console.print(Panel(
        f"[bold]ID:[/bold]         {entry.id}\n"
        f"[bold]Scope:[/bold]      {entry.scope.value}{expired_marker}\n"
        f"[bold]Owner:[/bold]      {owner}\n"
        f"[bold]Tags:[/bold]       {', '.join(entry.tags) or '(none)'}\n"
        f"[bold]Created:[/bold]    {entry.created_at}\n"
        f"[bold]Updated:[/bold]    {entry.updated_at}\n"
        f"[bold]Expires:[/bold]    {entry.expires_at or '(never)'}\n"
        f"\n[bold]Content:[/bold]\n{entry.content}",
        title=f"Memory: {entry.id}",
        border_style="cyan",
    ))


@memory_app.command("delete")
def memory_delete(
    memory_id: str = typer.Argument(..., help="Memory entry ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
):
    """Delete a memory entry."""
    store = _get_store()

    # Verify it exists first
    entry = store.get(memory_id)
    if entry is None:
        console.print(f"[red]Memory '{memory_id}' not found.[/red]")
        raise typer.Exit(1)

    if not force:
        content_preview = entry.content[:60] + ("..." if len(entry.content) > 60 else "")
        confirm = typer.confirm(f"Delete memory {memory_id}? ({content_preview})")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    deleted = store.delete(memory_id)
    if deleted:
        console.print(f"[green]Deleted memory {memory_id}.[/green]")
    else:
        console.print(f"[red]Failed to delete memory {memory_id}.[/red]")
        raise typer.Exit(1)


@memory_app.command("export")
def memory_export(
    scope: Optional[str] = typer.Option(None, "--scope", "-s", help="Filter by scope."),
    format: str = typer.Option("json", "--format", "-f", help="Export format (json)."),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output file path (default: stdout)."),
):
    """Export memories to JSON."""
    store = _get_store()
    mem_scope = _resolve_scope(scope)
    exported = store.export_memories(scope=mem_scope, format=format)

    if output:
        with open(output, "w", encoding="utf-8") as f:
            f.write(exported)
        console.print(f"[green]Exported to {output}[/green]")
    else:
        console.print(exported)


@memory_app.command("audit")
def memory_audit(
    memory_id: Optional[str] = typer.Option(None, "--id", "-i", help="Filter by memory ID."),
    operation: Optional[str] = typer.Option(None, "--operation", "-o", help="Filter by operation type."),
    limit: int = typer.Option(50, "--limit", "-n", help="Max entries to show."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """View memory operation audit log (MGP compliance)."""
    store = _get_store()
    entries = store.get_audit_log(memory_id=memory_id, operation=operation, limit=limit)

    if json_out:
        data = [e.to_dict() for e in entries]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not entries:
        console.print("[yellow]No audit entries found.[/yellow]")
        return

    table = Table(title=f"Audit Log ({len(entries)} entries)")
    table.add_column("Timestamp", style="dim", width=22)
    table.add_column("Operation", style="magenta", width=10)
    table.add_column("Memory ID", style="cyan", width=14)
    table.add_column("Actor", style="blue", width=12)
    table.add_column("Details", max_width=40)

    for entry in entries:
        table.add_row(
            entry.timestamp[:19],
            entry.operation,
            entry.memory_id,
            entry.actor,
            entry.details,
        )

    console.print(table)


@memory_app.command("revoke")
def memory_revoke(
    memory_id: str = typer.Argument(..., help="Memory entry ID to revoke."),
    reason: str = typer.Option("", "--reason", "-r", help="Reason for revocation."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
):
    """Revoke a memory entry (soft-delete with audit trail)."""
    store = _get_store()

    entry = store.get(memory_id)
    if entry is None:
        console.print(f"[red]Memory '{memory_id}' not found.[/red]")
        raise typer.Exit(1)

    if not force:
        content_preview = entry.content[:60] + ("..." if len(entry.content) > 60 else "")
        confirm = typer.confirm(f"Revoke memory {memory_id}? ({content_preview})")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    revoked = store.revoke(memory_id, reason=reason)
    if revoked:
        console.print(f"[green]Revoked memory {memory_id}.[/green]")
    else:
        console.print(f"[red]Failed to revoke memory {memory_id}.[/red]")
        raise typer.Exit(1)


@memory_app.command("context")
def memory_context(
    agent: Optional[str] = typer.Option(None, "--agent", help="Agent name"),
    team: Optional[str] = typer.Option(None, "--team", help="Team name"),
):
    """Show combined 3-layer memory context for an agent."""
    store = _get_store()
    ctx = store.get_context(agent_name=agent, team_name=team)
    console.print(f"\n[bold]Memory Context[/bold] (agent={agent}, team={team})")
    console.print(f"  Conversation: {len(ctx['conversation'])} entries")
    console.print(f"  Persistent:   {len(ctx['persistent'])} entries")
    console.print(f"  Skill:        {len(ctx['skill'])} entries")
    console.print(f"  Total:        {ctx['total']}")


@memory_app.command("purge")
def memory_purge(
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
):
    """Purge all expired memory entries."""
    store = _get_store()

    if not force:
        confirm = typer.confirm("Purge all expired memories?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    count = store.purge_expired()
    if count > 0:
        console.print(f"[green]Purged {count} expired memor{'y' if count == 1 else 'ies'}.[/green]")
    else:
        console.print("[dim]No expired memories found.[/dim]")
