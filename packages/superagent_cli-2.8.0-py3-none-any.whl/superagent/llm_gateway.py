"""LLM Gateway for SuperAgent — unified provider interface.

Inspired by LiteLLM, provides a single interface for managing 100+ LLM
providers with built-in presets, environment-variable key resolution, and
persistent JSON-backed configuration.
"""

from __future__ import annotations

import json
import logging
import os
import random
import stat
import time
from dataclasses import asdict, dataclass
from pathlib import Path
from typing import Any, Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class ProviderConfig:
    """Configuration for a single LLM provider."""

    name: str
    api_key: str = ""
    base_url: str = ""
    default_model: str = ""
    enabled: bool = True

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> ProviderConfig:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# Built-in provider presets
# ---------------------------------------------------------------------------

BUILTIN_PROVIDERS: list[ProviderConfig] = [
    ProviderConfig(
        name="openai",
        api_key="$OPENAI_API_KEY",
        base_url="https://api.openai.com/v1",
        default_model="gpt-4o",
    ),
    ProviderConfig(
        name="anthropic",
        api_key="$ANTHROPIC_API_KEY",
        base_url="https://api.anthropic.com/v1",
        default_model="claude-sonnet-4-20250514",
    ),
    ProviderConfig(
        name="deepseek",
        api_key="$DEEPSEEK_API_KEY",
        base_url="https://api.deepseek.com/v1",
        default_model="deepseek-chat",
    ),
    ProviderConfig(
        name="ollama",
        api_key="",
        base_url="http://localhost:11434/v1",
        default_model="llama3",
    ),
    ProviderConfig(
        name="openrouter",
        api_key="$OPENROUTER_API_KEY",
        base_url="https://openrouter.ai/api/v1",
        default_model="auto",
    ),
    ProviderConfig(
        name="groq",
        api_key="$GROQ_API_KEY",
        base_url="https://api.groq.com/openai/v1",
        default_model="llama-3.3-70b-versatile",
    ),
    ProviderConfig(
        name="together",
        api_key="$TOGETHER_API_KEY",
        base_url="https://api.together.xyz/v1",
        default_model="meta-llama/Llama-3-70b-chat-hf",
    ),
    ProviderConfig(
        name="siliconflow",
        api_key="$SILICONFLOW_API_KEY",
        base_url="https://api.siliconflow.cn/v1",
        default_model="deepseek-ai/DeepSeek-V3",
    ),
    ProviderConfig(
        name="venus",
        api_key="$VENUS_API_KEY",
        base_url="http://v2.open.venus.oa.com/llmproxy",
        default_model="GLM-5",
    ),
]


def _get_data_dir() -> Path:
    """Return the SuperAgent data directory (from env or default)."""
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


class LLMGateway:
    """Manages LLM provider configurations at ``<data_dir>/llm/providers.json``."""

    def __init__(self, data_dir: Optional[str] = None):
        base = Path(data_dir) if data_dir else _get_data_dir()
        self._dir = base / "llm"
        self._path = self._dir / "providers.json"
        self._providers: dict[str, ProviderConfig] = {}
        self._default: str = ""
        self.load()

    # -- Persistence ---------------------------------------------------------

    def load(self) -> None:
        """Load providers from disk, seeding built-in presets on first run."""
        if self._path.exists():
            try:
                raw = json.loads(self._path.read_text(encoding="utf-8"))
                for item in raw.get("providers", []):
                    cfg = ProviderConfig.from_dict(item)
                    self._providers[cfg.name] = cfg
                self._default = raw.get("default", "")
            except (json.JSONDecodeError, TypeError, AttributeError):
                pass

        # Seed built-in presets (idempotent)
        changed = False
        for preset in BUILTIN_PROVIDERS:
            if preset.name not in self._providers:
                self._providers[preset.name] = ProviderConfig(
                    name=preset.name,
                    api_key=preset.api_key,
                    base_url=preset.base_url,
                    default_model=preset.default_model,
                    enabled=preset.enabled,
                )
                changed = True

        if not self._default and self._providers:
            self._default = "openai"
            changed = True

        if changed:
            self.save()

    def save(self) -> None:
        """Persist provider configurations to disk."""
        self._dir.mkdir(parents=True, exist_ok=True)
        data = {
            "default": self._default,
            "providers": [cfg.to_dict() for cfg in self._providers.values()],
        }
        atomic_write(self._path, json.dumps(data, indent=2, ensure_ascii=False))
        # Restrict permissions — file may contain API keys
        try:
            os.chmod(str(self._path), stat.S_IRUSR | stat.S_IWUSR)  # 0o600
        except OSError:
            pass  # Best-effort on platforms that don't support chmod

    # -- CRUD ----------------------------------------------------------------

    def add_provider(self, config: ProviderConfig) -> None:
        """Add or update a provider configuration."""
        self._providers[config.name] = config
        self.save()

    def remove_provider(self, name: str) -> bool:
        """Remove a provider by name. Returns True if it existed."""
        if name in self._providers:
            del self._providers[name]
            if self._default == name:
                self._default = ""
            self.save()
            return True
        return False

    def get_provider(self, name: str) -> Optional[ProviderConfig]:
        """Get a provider configuration by name."""
        return self._providers.get(name)

    def list_providers(self) -> list[ProviderConfig]:
        """Return all provider configurations sorted by name."""
        return sorted(self._providers.values(), key=lambda c: c.name)

    # -- Default management --------------------------------------------------

    def set_default(self, name: str) -> None:
        """Set the default provider."""
        if name not in self._providers:
            raise KeyError(f"Provider '{name}' not found")
        self._default = name
        self.save()

    def get_default(self) -> Optional[ProviderConfig]:
        """Return the default provider, or None if unset."""
        if self._default:
            return self._providers.get(self._default)
        return None

    # -- Key resolution ------------------------------------------------------

    @staticmethod
    def resolve_api_key(provider: ProviderConfig) -> str:
        """Resolve an API key, expanding ``$ENV_VAR`` references."""
        key = provider.api_key
        if key.startswith("$"):
            return os.environ.get(key[1:], "")
        return key


# ---------------------------------------------------------------------------
# Singleton accessor
# ---------------------------------------------------------------------------

_gateway_instance: Optional[LLMGateway] = None


def get_llm_gateway(data_dir: Optional[str] = None) -> LLMGateway:
    """Get or create the singleton LLMGateway."""
    global _gateway_instance
    if _gateway_instance is None:
        _gateway_instance = LLMGateway(data_dir=data_dir)
    return _gateway_instance


# ---------------------------------------------------------------------------
# Circuit breaker
# ---------------------------------------------------------------------------

_CIRCUIT_BREAKER_FAILURE_THRESHOLD = 5
_CIRCUIT_BREAKER_RESET_WINDOW = 60.0  # seconds
_CIRCUIT_BREAKER_OPEN_DURATION = 30.0  # seconds
_MAX_RETRIES = 3
_BASE_RETRY_DELAY = 1.0  # seconds

_circuit_breaker: dict[str, dict[str, Any]] = {}


def _check_circuit(provider_name: str) -> None:
    """Raise if the circuit breaker is open for *provider_name*."""
    state = _circuit_breaker.get(provider_name)
    if state is None:
        return
    now = time.monotonic()
    if now < state.get("open_until", 0):
        remaining = state["open_until"] - now
        raise RuntimeError(
            f"Provider '{provider_name}' circuit breaker is open "
            f"({state.get('failures', 0)} recent failures, retry in {remaining:.0f}s). "
            f"Try a different provider."
        )


def _record_success(provider_name: str) -> None:
    """Reset the circuit breaker after a successful call."""
    if provider_name in _circuit_breaker:
        _circuit_breaker[provider_name]["failures"] = 0
        _circuit_breaker[provider_name]["open_until"] = 0.0


def _record_failure(provider_name: str) -> None:
    """Increment failure count and open circuit if threshold reached."""
    now = time.monotonic()
    state = _circuit_breaker.setdefault(provider_name, {
        "failures": 0, "open_until": 0.0, "last_failure": 0.0,
    })
    # Reset failure window if last failure was long ago
    if now - state["last_failure"] > _CIRCUIT_BREAKER_RESET_WINDOW:
        state["failures"] = 0
    state["failures"] += 1
    state["last_failure"] = now
    if state["failures"] >= _CIRCUIT_BREAKER_FAILURE_THRESHOLD:
        state["open_until"] = now + _CIRCUIT_BREAKER_OPEN_DURATION
        logger.warning(
            "Circuit breaker opened for provider '%s' (%d failures in %.0fs)",
            provider_name, state["failures"], _CIRCUIT_BREAKER_RESET_WINDOW,
        )


def _is_retryable_error(exc: Exception) -> bool:
    """Return True if the exception is transient and worth retrying."""
    # httpx errors
    try:
        import httpx
        if isinstance(exc, httpx.HTTPStatusError):
            return exc.response.status_code == 429 or exc.response.status_code >= 500
        if isinstance(exc, (httpx.ConnectError, httpx.ReadTimeout, httpx.PoolTimeout)):
            return True
    except ImportError:
        pass
    # litellm errors
    try:
        import litellm  # type: ignore[import-untyped]
        if isinstance(exc, (
            litellm.RateLimitError,
            litellm.ServiceUnavailableError,
            litellm.Timeout,
            litellm.APIConnectionError,
        )):
            return True
    except (ImportError, AttributeError):
        pass
    # Generic connection errors
    if isinstance(exc, (ConnectionError, OSError)):
        return True
    return False


# ---------------------------------------------------------------------------
# Unified LLM call
# ---------------------------------------------------------------------------


def call_llm(
    provider_name: str,
    messages: list[dict[str, str]],
    *,
    model: Optional[str] = None,
    data_dir: Optional[str] = None,
    **kwargs: Any,
) -> str:
    """Call an LLM provider and return the response text.

    Resolves provider config from the gateway, then:
    1. Uses ``litellm.completion()`` if litellm is installed.
    2. Falls back to an ``httpx`` POST to the provider's OpenAI-compatible
       ``/chat/completions`` endpoint.

    Parameters
    ----------
    provider_name:
        Name of a configured provider (e.g. ``"openai"``, ``"ollama"``).
    messages:
        Chat messages in OpenAI format (``[{"role": "user", "content": "..."}]``).
    model:
        Override the provider's default model.
    data_dir:
        Optional custom data directory for the gateway.
    **kwargs:
        Extra parameters forwarded to the completion call (e.g. ``temperature``).

    Returns
    -------
    str
        The assistant's reply text.
    """
    gw = get_llm_gateway(data_dir=data_dir)
    provider = gw.get_provider(provider_name)
    if provider is None:
        raise KeyError(f"Provider '{provider_name}' not found in gateway")

    _check_circuit(provider_name)

    api_key = LLMGateway.resolve_api_key(provider)
    resolved_model = model or provider.default_model

    last_exc: Optional[Exception] = None

    for attempt in range(1, _MAX_RETRIES + 1):
        try:
            result = _call_llm_once(provider_name, provider, api_key, resolved_model, messages, kwargs)
            _record_success(provider_name)
            return result
        except Exception as exc:
            last_exc = exc
            if not _is_retryable_error(exc) or attempt >= _MAX_RETRIES:
                _record_failure(provider_name)
                raise
            delay = _BASE_RETRY_DELAY * (2 ** (attempt - 1)) + random.uniform(0, 0.5)
            logger.warning(
                "Retrying %s after error (attempt %d/%d): %s",
                provider_name, attempt, _MAX_RETRIES, exc,
            )
            time.sleep(delay)

    # Should not reach here, but just in case
    _record_failure(provider_name)
    raise last_exc  # type: ignore[misc]


def _call_llm_once(
    provider_name: str,
    provider: ProviderConfig,
    api_key: str,
    resolved_model: str,
    messages: list[dict[str, str]],
    kwargs: dict[str, Any],
) -> str:
    """Single attempt to call an LLM provider (no retry logic)."""
    # --- Strategy 1: litellm --------------------------------------------------
    try:
        import litellm  # type: ignore[import-untyped]

        logger.debug("Using litellm for provider=%s model=%s", provider_name, resolved_model)
        response = litellm.completion(
            model=resolved_model,
            messages=messages,
            api_key=api_key or None,
            api_base=provider.base_url or None,
            **kwargs,
        )
        # Track cost
        _track_cost(provider_name, resolved_model, response)
        return response.choices[0].message.content  # type: ignore[union-attr]

    except ImportError:
        logger.debug("litellm not installed, falling back to httpx")

    # --- Strategy 2: httpx fallback -------------------------------------------
    import httpx

    base = provider.base_url.rstrip("/")
    url = f"{base}/chat/completions"
    headers: dict[str, str] = {"Content-Type": "application/json"}
    if api_key:
        headers["Authorization"] = f"Bearer {api_key}"

    payload: dict[str, Any] = {
        "model": resolved_model,
        "messages": messages,
        **kwargs,
    }

    with httpx.Client(timeout=120) as client:
        resp = client.post(url, json=payload, headers=headers)
        resp.raise_for_status()
        data = resp.json()

    # Track cost from httpx response
    _track_cost(provider_name, resolved_model, data)

    return data["choices"][0]["message"]["content"]


def _track_cost(provider_name: str, model: str, response: Any) -> None:
    """Record token usage and cost from an LLM response."""
    try:
        from superagent.costs import get_cost_tracker
        usage = getattr(response, "usage", None)
        if usage is None and isinstance(response, dict):
            usage = response.get("usage", {})
        if usage:
            input_t = getattr(usage, "prompt_tokens", 0) or (usage.get("prompt_tokens", 0) if isinstance(usage, dict) else 0)
            output_t = getattr(usage, "completion_tokens", 0) or (usage.get("completion_tokens", 0) if isinstance(usage, dict) else 0)
            if input_t or output_t:
                get_cost_tracker().record(
                    provider=provider_name, model=model,
                    input_tokens=input_t, output_tokens=output_t,
                    operation="call_llm",
                )
    except Exception:
        logger.debug("Cost tracking failed for %s/%s", provider_name, model, exc_info=True)
