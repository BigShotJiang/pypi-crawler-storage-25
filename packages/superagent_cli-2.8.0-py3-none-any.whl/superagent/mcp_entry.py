"""Entry point for superagent MCP server."""

from __future__ import annotations

import os
import sys

_upstream = os.path.join(os.path.dirname(__file__), "..", "..", "upstream", "clawteam")
if os.path.isdir(_upstream) and _upstream not in sys.path:
    sys.path.insert(0, _upstream)

if "CLAWTEAM_DATA_DIR" not in os.environ:
    os.environ["CLAWTEAM_DATA_DIR"] = os.path.join(os.path.expanduser("~"), ".superagent")


def main():
    from clawteam.mcp.server import main as _mcp_main
    _mcp_main()


if __name__ == "__main__":
    main()
