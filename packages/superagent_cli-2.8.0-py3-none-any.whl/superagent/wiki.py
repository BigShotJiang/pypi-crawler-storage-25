"""LLM Wiki system for SuperAgent — structured knowledge base with wiki-links.

Provides an agent-managed wiki that ingests documents, extracts entities and
concepts, maintains interlinked markdown pages with YAML frontmatter, and
supports keyword search, LLM-powered queries, and graph visualization.

Usage:
    wiki = get_wiki_store()      # factory with default path
    wiki.init()                  # create directory structure
    wiki.ingest("notes.md")      # ingest a document
    wiki.search("transformers")  # keyword search
    wiki.query("What is RAG?")   # LLM-powered Q&A over the wiki
"""

from __future__ import annotations

import hashlib
import json
import logging
import os
import re
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class PageType(str, Enum):
    """Classification of wiki pages."""

    source = "source"
    entity = "entity"
    concept = "concept"
    comparison = "comparison"
    synthesis = "synthesis"


class PageStatus(str, Enum):
    """Lifecycle status of a wiki page."""

    stub = "stub"
    draft = "draft"
    active = "active"
    stale = "stale"
    archived = "archived"


class ConfidenceLevel(str, Enum):
    """Three-level confidence labels inspired by Graphify.

    EXTRACTED — relationship found directly in source (import, heading, explicit mention)
    INFERRED  — reasonable deduction (co-occurrence, structural proximity)
    AMBIGUOUS — uncertain, flagged for human review
    """

    extracted = "extracted"
    inferred = "inferred"
    ambiguous = "ambiguous"


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

_TYPE_DIRS: dict[PageType, str] = {
    PageType.source: "sources",
    PageType.entity: "entities",
    PageType.concept: "concepts",
    PageType.comparison: "comparisons",
    PageType.synthesis: "syntheses",
}


def _now_iso() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def _slugify(text: str) -> str:
    """Convert *text* to a URL/filename-safe slug."""
    slug = text.lower().strip()
    slug = re.sub(r"[^a-z0-9\s-]", "", slug)
    slug = re.sub(r"[\s]+", "-", slug)
    slug = re.sub(r"-+", "-", slug)
    return slug.strip("-")


@dataclass
class WikiFrontmatter:
    """YAML frontmatter metadata for a wiki page."""

    type: PageType
    title: str
    related: list[str] = field(default_factory=list)
    confidence: float = 0.5
    confidence_level: str = "inferred"  # extracted | inferred | ambiguous
    status: PageStatus = PageStatus.draft
    tags: list[str] = field(default_factory=list)
    created: str = ""
    updated: str = ""
    source_ids: list[str] = field(default_factory=list)
    summary_l0: str = ""

    def to_dict(self) -> dict:
        """Serialize to a plain dict suitable for YAML/JSON storage."""
        d = asdict(self)
        d["type"] = self.type.value if isinstance(self.type, PageType) else str(self.type)
        d["status"] = self.status.value if isinstance(self.status, PageStatus) else str(self.status)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> WikiFrontmatter:
        """Deserialize from a dict loaded from frontmatter."""
        page_type = PageType(data.get("type", "entity"))
        status = PageStatus(data.get("status", "draft"))
        return cls(
            type=page_type,
            title=data.get("title", ""),
            related=data.get("related", []),
            confidence=float(data.get("confidence", 0.5)),
            confidence_level=data.get("confidence_level", "inferred"),
            status=status,
            tags=data.get("tags", []),
            created=data.get("created", ""),
            updated=data.get("updated", ""),
            source_ids=data.get("source_ids", []),
            summary_l0=data.get("summary_l0", ""),
        )


@dataclass
class WikiPage:
    """A single wiki page with frontmatter and body content."""

    path: str
    frontmatter: WikiFrontmatter
    body: str = ""
    wiki_links: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "path": self.path,
            "frontmatter": self.frontmatter.to_dict(),
            "body": self.body,
            "wiki_links": self.wiki_links,
        }

    @classmethod
    def from_dict(cls, data: dict) -> WikiPage:
        return cls(
            path=data.get("path", ""),
            frontmatter=WikiFrontmatter.from_dict(data.get("frontmatter", {})),
            body=data.get("body", ""),
            wiki_links=data.get("wiki_links", []),
        )


@dataclass
class IngestResult:
    """Result of ingesting a document into the wiki."""

    source_path: str
    pages_created: list[str] = field(default_factory=list)
    pages_updated: list[str] = field(default_factory=list)
    claims_extracted: int = 0
    contradictions: list[str] = field(default_factory=list)

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> IngestResult:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


@dataclass
class LintResult:
    """Result of linting the wiki for quality issues."""

    orphan_pages: list[str] = field(default_factory=list)
    broken_links: list[str] = field(default_factory=list)
    stubs: list[str] = field(default_factory=list)
    stale_pages: list[str] = field(default_factory=list)
    contradictions: list[str] = field(default_factory=list)
    score: float = 100.0

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> LintResult:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# WikiStore
# ---------------------------------------------------------------------------


class WikiStore:
    """Manages a structured wiki of interlinked markdown pages.

    Directory layout under *wiki_dir*::

        wiki/
        ├── raw/                  # immutable source copies
        ├── wiki/
        │   ├── sources/          # source summary pages
        │   ├── entities/         # entity pages
        │   ├── concepts/         # concept pages
        │   ├── comparisons/      # comparison pages
        │   ├── syntheses/        # synthesis pages
        │   ├── index.md          # auto-generated index
        │   └── log.md            # append-only operation log
        └── config.json           # wiki configuration
    """

    def __init__(self, wiki_dir: str | None = None) -> None:
        base = Path(wiki_dir) if wiki_dir else _get_data_dir() / "wiki"
        self.base_dir = base
        self.raw_dir = base / "raw"
        self.wiki_dir = base / "wiki"
        self.config_path = base / "config.json"
        # SQLite search index (Hermes FTS5 pattern)
        self._db = None  # lazy init

    # ------------------------------------------------------------------
    # Initialization
    # ------------------------------------------------------------------

    def init(self) -> None:
        """Create the wiki directory structure and default files."""
        self.raw_dir.mkdir(parents=True, exist_ok=True)
        for subdir in _TYPE_DIRS.values():
            (self.wiki_dir / subdir).mkdir(parents=True, exist_ok=True)

        index_path = self.wiki_dir / "index.md"
        if not index_path.exists():
            index_path.write_text("# Wiki Index\n\n_No pages yet._\n", encoding="utf-8")

        log_path = self.wiki_dir / "log.md"
        if not log_path.exists():
            log_path.write_text("# Wiki Log\n\n", encoding="utf-8")

        if not self.config_path.exists():
            default_config = {
                "version": 1,
                "stale_days": 30,
                "default_confidence": 0.5,
                "auto_index": True,
            }
            self.config_path.write_text(
                json.dumps(default_config, indent=2, ensure_ascii=False),
                encoding="utf-8",
            )

        logger.info("Wiki initialized at %s", self.base_dir)
        # Pre-initialize SQLite index
        self._get_db()

    def _get_db(self):
        """Lazy-init SQLite connection scoped to this wiki's directory."""
        if self._db is None:
            try:
                from superagent.db import get_db, migrate_wiki_from_files
                db_path = str(self.base_dir / "wiki.db")
                self._db = get_db(db_path=db_path)
                migrate_wiki_from_files(self._db, str(self.base_dir))
            except Exception as e:
                logger.debug("Wiki SQLite initialization failed: %s", e)
        return self._db

    # ------------------------------------------------------------------
    # Frontmatter helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _parse_frontmatter(text: str) -> tuple[dict, str]:
        """Parse YAML frontmatter between ``---`` delimiters.

        Returns (metadata_dict, body_text).  Falls back to regex parsing
        when ``python-frontmatter`` is not installed.
        """
        try:
            import frontmatter as fm  # type: ignore[import-untyped]

            post = fm.loads(text)
            return dict(post.metadata), post.content
        except ImportError:
            pass
        except Exception as e:
            # python-frontmatter failed (e.g. YAML parse error) — fall through
            logger.debug("Frontmatter parsing failed: %s", e)

        # Regex fallback: parse simple key: value lines
        match = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
        if not match:
            return {}, text

        raw_yaml = match.group(1)
        body = text[match.end():]
        meta: dict[str, Any] = {}

        for line in raw_yaml.splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" not in line:
                continue
            key, _, value = line.partition(":")
            key = key.strip()
            value = value.strip()

            # Handle simple list syntax: [a, b, c]
            if value.startswith("[") and value.endswith("]"):
                items = value[1:-1].split(",")
                meta[key] = [item.strip().strip("'\"") for item in items if item.strip()]
            # Handle booleans
            elif value.lower() in ("true", "false"):
                meta[key] = value.lower() == "true"
            # Handle numbers
            else:
                try:
                    meta[key] = float(value) if "." in value else int(value)
                except ValueError:
                    meta[key] = value.strip("'\"")

        return meta, body

    @staticmethod
    def _render_frontmatter(meta: dict, body: str) -> str:
        """Render frontmatter dict and body text to a markdown string."""
        lines = ["---"]
        for key, value in meta.items():
            if isinstance(value, list):
                lines.append(f"{key}: [{', '.join(str(v) for v in value)}]")
            elif isinstance(value, bool):
                lines.append(f"{key}: {'true' if value else 'false'}")
            elif isinstance(value, str) and (":" in value or "#" in value or value.startswith(("{", "["))):
                # Quote strings that contain YAML-special characters
                escaped = value.replace('"', '\\"')
                lines.append(f'{key}: "{escaped}"')
            else:
                lines.append(f"{key}: {value}")
        lines.append("---")
        lines.append("")
        if body:
            lines.append(body)
        return "\n".join(lines)

    # ------------------------------------------------------------------
    # Wiki-link helpers
    # ------------------------------------------------------------------

    @staticmethod
    def _extract_wiki_links(text: str) -> list[str]:
        """Extract all ``[[link-target]]`` references from *text*."""
        return re.findall(r"\[\[([^\]]+)\]\]", text)

    def _resolve_link(self, link: str) -> str | None:
        """Resolve a wiki-link target to a file path, or ``None`` if not found."""
        slug = _slugify(link)
        for subdir in _TYPE_DIRS.values():
            candidate = self.wiki_dir / subdir / f"{slug}.md"
            if candidate.exists():
                return str(candidate.relative_to(self.base_dir))
        return None

    # ------------------------------------------------------------------
    # Page CRUD
    # ------------------------------------------------------------------

    def _read_page(self, rel_path: str) -> WikiPage | None:
        """Read a wiki page from disk and parse its frontmatter."""
        full_path = self.base_dir / rel_path
        if not full_path.exists():
            return None
        try:
            text = full_path.read_text(encoding="utf-8")
        except OSError:
            return None

        meta, body = self._parse_frontmatter(text)
        fm = WikiFrontmatter.from_dict(meta)
        links = self._extract_wiki_links(text)

        return WikiPage(
            path=rel_path,
            frontmatter=fm,
            body=body.strip(),
            wiki_links=links,
        )

    def _write_page(self, page: WikiPage) -> None:
        """Write a wiki page to disk with frontmatter and index in SQLite."""
        full_path = self.base_dir / page.path
        full_path.parent.mkdir(parents=True, exist_ok=True)
        content = self._render_frontmatter(page.frontmatter.to_dict(), page.body)
        full_path.write_text(content, encoding="utf-8")

        # Upsert into SQLite search index
        db = self._get_db()
        if db is not None:
            fm = page.frontmatter
            try:
                db.execute(
                    """INSERT OR REPLACE INTO wiki_pages
                       (path, title, page_type, status, confidence, confidence_level,
                        tags, summary, body, source_ids, related, wiki_links,
                        created_at, updated_at)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        page.path,
                        fm.title,
                        fm.type.value if isinstance(fm.type, PageType) else str(fm.type),
                        fm.status.value if isinstance(fm.status, PageStatus) else str(fm.status),
                        fm.confidence,
                        fm.confidence_level,
                        json.dumps(fm.tags),
                        fm.summary_l0,
                        page.body[:5000],
                        json.dumps(fm.source_ids),
                        json.dumps(fm.related),
                        json.dumps(page.wiki_links),
                        fm.created,
                        fm.updated,
                    ),
                )
                db.commit()
            except Exception as exc:
                logger.debug("Failed to index wiki page in SQLite: %s", exc)

        # Also update standalone FTS index
        if db is not None:
            try:
                # Delete old FTS entry
                db.execute("DELETE FROM wiki_fts WHERE path = ?", (page.path,))
                # Insert new FTS entry
                db.execute(
                    "INSERT INTO wiki_fts (path, title, tags, body, summary) VALUES (?, ?, ?, ?, ?)",
                    (page.path, fm.title, json.dumps(fm.tags), page.body[:5000], fm.summary_l0),
                )
                db.commit()
            except Exception as e:
                logger.debug("Wiki page SQLite indexing failed: %s", e)

    def _list_pages(self, page_type: PageType | None = None) -> list[str]:
        """List all page paths relative to *base_dir*, optionally filtered by type."""
        pages: list[str] = []
        if page_type is not None:
            subdir = _TYPE_DIRS.get(page_type, "")
            if subdir:
                target = self.wiki_dir / subdir
                if target.exists():
                    for f in sorted(target.glob("*.md")):
                        pages.append(str(f.relative_to(self.base_dir)))
        else:
            for subdir in _TYPE_DIRS.values():
                target = self.wiki_dir / subdir
                if target.exists():
                    for f in sorted(target.glob("*.md")):
                        pages.append(str(f.relative_to(self.base_dir)))
        return pages

    # ------------------------------------------------------------------
    # Log
    # ------------------------------------------------------------------

    def _append_log(self, operation: str, detail: str) -> None:
        """Append a timestamped entry to ``wiki/log.md``."""
        log_path = self.wiki_dir / "log.md"
        timestamp = _now_iso()
        entry = f"\n## [{timestamp}] {operation} | {detail}\n"
        try:
            with open(log_path, "a", encoding="utf-8") as f:
                f.write(entry)
        except OSError as exc:
            logger.warning("Failed to append to wiki log: %s", exc)

    # ------------------------------------------------------------------
    # Index
    # ------------------------------------------------------------------

    def update_index(self) -> None:
        """Rebuild ``wiki/index.md`` from all pages."""
        pages = self._list_pages()
        lines = [
            "# Wiki Index",
            "",
            f"_Total pages: {len(pages)}_",
            "",
            "| Page | Summary | Tags |",
            "| ---- | ------- | ---- |",
        ]

        for rel_path in pages:
            page = self._read_page(rel_path)
            if page is None:
                continue
            fm = page.frontmatter
            slug = Path(rel_path).stem
            summary = fm.summary_l0 or "_no summary_"
            tags = ", ".join(fm.tags) if fm.tags else ""
            lines.append(f"| [[{slug}]] | {summary} | {tags} |")

        lines.append("")
        index_path = self.wiki_dir / "index.md"
        index_path.write_text("\n".join(lines), encoding="utf-8")

    # ------------------------------------------------------------------
    # Ingest
    # ------------------------------------------------------------------

    def ingest(
        self,
        file_path: str,
        *,
        title: str = "",
        tags: list[str] | None = None,
        use_llm: bool = False,
    ) -> IngestResult:
        """Ingest a document into the wiki.

        Copies the source to ``raw/``, extracts entities and concepts, creates
        or updates wiki pages, and rebuilds the index.

        Parameters
        ----------
        file_path:
            Path to the source document (markdown or plain text).
        title:
            Override the page title (default: extracted from heading or filename).
        tags:
            Tags to apply to the source page.
        use_llm:
            If True, use the LLM gateway for entity/concept extraction.
        """
        file_path = os.path.expanduser(file_path)
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        content = Path(file_path).read_text(encoding="utf-8", errors="replace")
        tags = tags or []

        # --- SHA256 incremental cache (Graphify pattern) ---
        content_sha = hashlib.sha256(content.encode()).hexdigest()
        if self._is_cached(file_path, content_sha):
            logger.info("Skipping unchanged file (cache hit): %s", file_path)
            return IngestResult(source_path=file_path)

        result = IngestResult(source_path=file_path)

        # 1. Copy source to raw/{hash[:8]}-{slug}.md (immutable)
        content_hash = hashlib.md5(content.encode()).hexdigest()[:8]
        src_slug = _slugify(Path(file_path).stem)
        raw_name = f"{content_hash}-{src_slug}.md"
        raw_dest = self.raw_dir / raw_name
        if not raw_dest.exists():
            self.raw_dir.mkdir(parents=True, exist_ok=True)
            raw_dest.write_text(content, encoding="utf-8")

        # 2. Extract title from first heading or filename
        if not title:
            heading_match = re.search(r"^#\s+(.+)$", content, re.MULTILINE)
            if heading_match:
                title = heading_match.group(1).strip()
            else:
                title = Path(file_path).stem.replace("-", " ").replace("_", " ").title()

        # 3. Extract entities/concepts
        entities: list[str] = []
        concepts: list[str] = []
        claims: list[str] = []

        if use_llm:
            entities, concepts, claims = self._extract_with_llm(content)
            confidence_lvl = "inferred"  # LLM extraction = inferred
        else:
            entities, concepts = self._extract_from_structure(content)
            confidence_lvl = "extracted"  # AST/structure = extracted

        result.claims_extracted = len(claims)

        # 4. Create or update pages for each entity/concept
        now = _now_iso()
        source_id = raw_name

        for name in entities:
            slug = _slugify(name)
            if not slug:
                continue
            rel_path = f"wiki/entities/{slug}.md"
            existing = self._read_page(rel_path)

            if existing is not None:
                # Update: add related links and bump timestamp
                if source_id not in existing.frontmatter.source_ids:
                    existing.frontmatter.source_ids.append(source_id)
                existing.frontmatter.updated = now
                src_slug_link = _slugify(title)
                if src_slug_link and src_slug_link not in existing.frontmatter.related:
                    existing.frontmatter.related.append(src_slug_link)
                self._write_page(existing)
                result.pages_updated.append(rel_path)
            else:
                # Create new entity page
                page = WikiPage(
                    path=rel_path,
                    frontmatter=WikiFrontmatter(
                        type=PageType.entity,
                        title=name,
                        status=PageStatus.draft,
                        confidence=0.5,
                        confidence_level=confidence_lvl,
                        tags=tags.copy(),
                        created=now,
                        updated=now,
                        source_ids=[source_id],
                        summary_l0=f"Entity: {name}",
                        related=[_slugify(title)],
                    ),
                    body=f"# {name}\n\nExtracted from [[{_slugify(title)}]].\n",
                )
                self._write_page(page)
                result.pages_created.append(rel_path)

        for name in concepts:
            slug = _slugify(name)
            if not slug:
                continue
            rel_path = f"wiki/concepts/{slug}.md"
            existing = self._read_page(rel_path)

            if existing is not None:
                if source_id not in existing.frontmatter.source_ids:
                    existing.frontmatter.source_ids.append(source_id)
                existing.frontmatter.updated = now
                src_slug_link = _slugify(title)
                if src_slug_link and src_slug_link not in existing.frontmatter.related:
                    existing.frontmatter.related.append(src_slug_link)
                self._write_page(existing)
                result.pages_updated.append(rel_path)
            else:
                page = WikiPage(
                    path=rel_path,
                    frontmatter=WikiFrontmatter(
                        type=PageType.concept,
                        title=name,
                        status=PageStatus.draft,
                        confidence=0.5,
                        confidence_level=confidence_lvl,
                        tags=tags.copy(),
                        created=now,
                        updated=now,
                        source_ids=[source_id],
                        summary_l0=f"Concept: {name}",
                        related=[_slugify(title)],
                    ),
                    body=f"# {name}\n\nExtracted from [[{_slugify(title)}]].\n",
                )
                self._write_page(page)
                result.pages_created.append(rel_path)

        # 5. Create source summary page
        source_slug = _slugify(title)
        source_rel = f"wiki/sources/{source_slug}.md"
        all_extracted = entities + concepts
        related_slugs = [_slugify(n) for n in all_extracted if _slugify(n)]
        body_links = ", ".join(f"[[{_slugify(n)}]]" for n in all_extracted if _slugify(n))
        source_page = WikiPage(
            path=source_rel,
            frontmatter=WikiFrontmatter(
                type=PageType.source,
                title=title,
                status=PageStatus.active,
                confidence=1.0,
                tags=tags.copy(),
                created=now,
                updated=now,
                source_ids=[source_id],
                summary_l0=f"Source: {title}",
                related=related_slugs,
            ),
            body=f"# {title}\n\n**Source file:** `{Path(file_path).name}`\n\n"
                 f"**Extracted items:** {body_links}\n",
        )
        self._write_page(source_page)
        result.pages_created.append(source_rel)

        # 6. Update index
        self.update_index()

        # 7. Log the operation
        self._append_log(
            "ingest",
            f"file={Path(file_path).name} created={len(result.pages_created)} "
            f"updated={len(result.pages_updated)} claims={result.claims_extracted}",
        )

        # 8. Update cache
        self._save_cache(file_path, content_sha)

        return result

    def _extract_with_llm(self, content: str) -> tuple[list[str], list[str], list[str]]:
        """Use the LLM gateway to extract entities, concepts, and claims."""
        try:
            from superagent.llm_gateway import call_llm
        except ImportError:
            logger.warning("llm_gateway not available, falling back to structural extraction")
            entities, concepts = self._extract_from_structure(content)
            return entities, concepts, []

        prompt = (
            "Extract key entities and concepts from this document.\n"
            'Return JSON: {"entities": ["name1", ...], "concepts": ["name1", ...], '
            '"claims": ["claim1", ...]}\n\n'
            f"Document:\n{content[:4000]}"
        )

        try:
            response = call_llm(
                "openai",
                [{"role": "user", "content": prompt}],
                temperature=0.2,
            )
            data = json.loads(response)
            return (
                data.get("entities", []),
                data.get("concepts", []),
                data.get("claims", []),
            )
        except (json.JSONDecodeError, KeyError, Exception) as exc:
            logger.warning("LLM extraction failed: %s — falling back to structural", exc)
            entities, concepts = self._extract_from_structure(content)
            return entities, concepts, []

    @staticmethod
    def _extract_from_structure(content: str) -> tuple[list[str], list[str]]:
        """Extract entities from headings and bold terms, concepts from list items."""
        entities: list[str] = []
        concepts: list[str] = []
        seen: set[str] = set()
        # Common bold phrases that are not entities
        _bold_stopwords = {
            "note", "important", "warning", "example", "tip", "caution",
            "summary", "todo", "fixme", "update", "source", "output",
            "input", "result", "see also", "references", "key takeaway",
        }

        # Entities: ## headings
        for match in re.finditer(r"^##\s+(.+)$", content, re.MULTILINE):
            name = match.group(1).strip()
            lower = name.lower()
            if lower not in seen and len(name) > 1:
                entities.append(name)
                seen.add(lower)

        # Entities: **bold terms** (skip common stopwords)
        for match in re.finditer(r"\*\*([^*]+)\*\*", content):
            name = match.group(1).strip().rstrip(":")
            lower = name.lower()
            if lower not in seen and lower not in _bold_stopwords and len(name) > 1 and len(name) < 80:
                entities.append(name)
                seen.add(lower)

        # Concepts: list items starting with - or *
        for match in re.finditer(r"^[\-\*]\s+(.+)$", content, re.MULTILINE):
            name = match.group(1).strip()
            # Only treat short list items as concepts
            if len(name) > 2 and len(name) < 60:
                lower = name.lower()
                if lower not in seen:
                    concepts.append(name)
                    seen.add(lower)

        return entities, concepts

    def ingest_url(self, url: str, **kwargs: Any) -> IngestResult:
        """Ingest a web page into the wiki.

        Tries Firecrawl first for high-quality markdown conversion, then
        falls back to urllib for basic HTML fetching.

        Only ``http`` and ``https`` schemes are allowed.
        """
        import tempfile
        from urllib.parse import urlparse

        # Validate URL scheme to prevent SSRF (file://, ftp://, etc.)
        parsed = urlparse(url)
        if parsed.scheme not in ("http", "https"):
            raise ValueError(f"Only http/https URLs are supported, got: {parsed.scheme!r}")
        if not parsed.hostname:
            raise ValueError(f"Invalid URL: {url}")

        markdown = ""

        # Strategy 1: Firecrawl
        try:
            from superagent.firecrawl_scraper import get_firecrawl

            fc = get_firecrawl()
            if fc is not None:
                result = fc.scrape_url(url)
                if result.get("success"):
                    markdown = result.get("markdown", "")
                    logger.info("Fetched URL via Firecrawl: %s", url)
        except ImportError:
            pass

        # Strategy 2: urllib fallback
        if not markdown:
            try:
                import urllib.request

                with urllib.request.urlopen(url, timeout=30) as resp:
                    raw_html = resp.read().decode("utf-8", errors="replace")
                # Strip HTML tags for a rough markdown conversion
                markdown = re.sub(r"<[^>]+>", "", raw_html)
                markdown = re.sub(r"\n{3,}", "\n\n", markdown).strip()
                logger.info("Fetched URL via urllib: %s", url)
            except (OSError, ValueError) as exc:
                raise RuntimeError(f"Failed to fetch URL {url}: {exc}") from exc

        # Write to a temp file and ingest
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".md", delete=False, encoding="utf-8"
        ) as tmp:
            tmp.write(f"# {url}\n\n{markdown}")
            tmp_path = tmp.name

        try:
            return self.ingest(tmp_path, **kwargs)
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    # ------------------------------------------------------------------
    # Search
    # ------------------------------------------------------------------

    def list_all(self, page_type: PageType | None = None) -> list[WikiPage]:
        """Return all wiki pages, optionally filtered by type."""
        pages: list[WikiPage] = []
        for rel_path in self._list_pages(page_type):
            page = self._read_page(rel_path)
            if page is not None:
                pages.append(page)
        return pages

    def search(
        self,
        query: str,
        *,
        limit: int = 10,
        page_type: PageType | None = None,
    ) -> list[WikiPage]:
        """Full-text search across wiki pages using SQLite FTS5.

        Falls back to in-memory keyword scoring if FTS is unavailable.
        """
        query_lower = query.lower().strip()
        if not query_lower:
            return []

        # Try FTS5 first
        db = self._get_db()
        if db is not None:
            try:
                safe_q = " ".join(w + "*" for w in query_lower.split() if w)
                sql = """
                    SELECT path FROM wiki_fts
                    WHERE wiki_fts MATCH ?
                """
                params: list = [safe_q]
                if page_type is not None:
                    # Fall back to in-memory for type filtering with FTS
                    pass
                sql += " ORDER BY rank LIMIT ?"
                params.append(limit)

                rows = db.execute(sql, params).fetchall()
                pages: list[WikiPage] = []
                for row in rows:
                    page = self._read_page(row[0])  # path is first column
                    if page is not None:
                        if page_type is None or page.frontmatter.type == page_type:
                            pages.append(page)
                return pages
            except Exception as e:
                logger.debug("Wiki FTS search failed, falling back to in-memory: %s", e)

        # Fallback: in-memory keyword scoring
        return self._search_inmemory(query_lower, limit, page_type)

    def _search_inmemory(self, query_lower: str, limit: int, page_type: PageType | None) -> list[WikiPage]:
        """In-memory keyword search fallback."""
        query_words = set(query_lower.split())
        scored: list[tuple[WikiPage, float]] = []

        for rel_path in self._list_pages(page_type):
            page = self._read_page(rel_path)
            if page is None:
                continue
            score = 0.0
            fm = page.frontmatter
            title_lower = fm.title.lower()
            if query_lower in title_lower:
                score += 5.0
            for word in query_words:
                if word in title_lower:
                    score += 2.0
            tags_lower = [t.lower() for t in fm.tags]
            for word in query_words:
                if word in tags_lower:
                    score += 3.0
            body_lower = page.body.lower()
            if query_lower in body_lower:
                score += 1.0
            for word in query_words:
                if word in body_lower:
                    score += 0.5
            if score > 0:
                scored.append((page, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [page for page, _ in scored[:limit]]

    # ------------------------------------------------------------------
    # Query (LLM-powered)
    # ------------------------------------------------------------------

    def query(
        self,
        question: str,
        *,
        limit: int = 5,
        provider: str = "openai",
    ) -> str:
        """Answer a question using wiki content.

        Searches for relevant pages and either synthesizes an answer with
        an LLM or returns concatenated summaries when no LLM is available.
        """
        pages = self.search(question, limit=limit)
        if not pages:
            return "No relevant wiki pages found."

        # Build context from top pages
        context_parts: list[str] = []
        for page in pages:
            fm = page.frontmatter
            context_parts.append(
                f"## {fm.title}\n"
                f"Summary: {fm.summary_l0}\n"
                f"Tags: {', '.join(fm.tags)}\n\n"
                f"{page.body[:1000]}\n"
            )

        context = "\n---\n".join(context_parts)

        # Try LLM synthesis
        try:
            from superagent.llm_gateway import call_llm

            prompt = (
                "Based on the following wiki pages, answer the question.\n"
                "Be concise and cite page titles where relevant.\n\n"
                f"Question: {question}\n\n"
                f"Wiki context:\n{context}"
            )
            answer = call_llm(
                provider,
                [{"role": "user", "content": prompt}],
                temperature=0.3,
            )
            return answer
        except (ImportError, KeyError, Exception) as exc:
            logger.debug("LLM query unavailable (%s), returning summaries", exc)

        # Fallback: concatenated summaries
        summaries = [
            f"- **{p.frontmatter.title}**: {p.frontmatter.summary_l0}"
            for p in pages
            if p.frontmatter.summary_l0
        ]
        return f"Relevant pages for: {question}\n\n" + "\n".join(summaries)

    # ------------------------------------------------------------------
    # Lint
    # ------------------------------------------------------------------

    def lint(self) -> LintResult:
        """Check wiki quality and return a lint report.

        Identifies orphan pages, broken links, stubs, stale pages, and
        calculates a health score from 0 to 100.
        """
        result = LintResult()
        all_paths = self._list_pages()
        if not all_paths:
            return result

        # Build graph
        slug_to_path: dict[str, str] = {}
        incoming: dict[str, int] = {}
        all_links: dict[str, list[str]] = {}

        for rel_path in all_paths:
            slug = Path(rel_path).stem
            slug_to_path[slug] = rel_path
            incoming.setdefault(slug, 0)

        for rel_path in all_paths:
            page = self._read_page(rel_path)
            if page is None:
                continue

            slug = Path(rel_path).stem
            links = page.wiki_links
            all_links[slug] = links

            for link_target in links:
                target_slug = _slugify(link_target)
                if target_slug in slug_to_path:
                    incoming[target_slug] = incoming.get(target_slug, 0) + 1
                else:
                    broken = f"[[{link_target}]] in {rel_path}"
                    if broken not in result.broken_links:
                        result.broken_links.append(broken)

        # Orphans: 0 incoming links (excluding index.md)
        for slug, count in incoming.items():
            if count == 0 and slug != "index":
                result.orphan_pages.append(slug_to_path[slug])

        # Stubs and stale pages
        config = self._load_config()
        stale_days = config.get("stale_days", 30)

        for rel_path in all_paths:
            page = self._read_page(rel_path)
            if page is None:
                continue

            fm = page.frontmatter

            # Stubs
            if fm.status == PageStatus.stub:
                result.stubs.append(rel_path)

            # Stale: updated more than stale_days ago
            if fm.updated:
                try:
                    updated_dt = datetime.fromisoformat(fm.updated)
                    age = (datetime.now(timezone.utc) - updated_dt).days
                    if age > stale_days:
                        result.stale_pages.append(rel_path)
                except (ValueError, TypeError):
                    pass

        # Calculate score: 100 minus penalties
        total = max(len(all_paths), 1)
        penalty = 0.0
        penalty += len(result.orphan_pages) * (20.0 / total)
        penalty += len(result.broken_links) * (15.0 / total)
        penalty += len(result.stubs) * (10.0 / total)
        penalty += len(result.stale_pages) * (5.0 / total)
        result.score = round(max(0.0, min(100.0, 100.0 - penalty)), 1)

        return result

    def _load_config(self) -> dict:
        """Load wiki configuration from disk."""
        if self.config_path.exists():
            try:
                return json.loads(self.config_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {"stale_days": 30, "default_confidence": 0.5}

    # ------------------------------------------------------------------
    # Status
    # ------------------------------------------------------------------

    def status(self) -> dict:
        """Return a summary of the wiki's current state."""
        counts: dict[str, int] = {}
        total = 0
        for ptype in PageType:
            pages = self._list_pages(ptype)
            counts[ptype.value] = len(pages)
            total += len(pages)

        # Last ingest from log
        last_ingest = ""
        log_path = self.wiki_dir / "log.md"
        if log_path.exists():
            try:
                text = log_path.read_text(encoding="utf-8")
                matches = re.findall(r"\[([^\]]+)\] ingest", text)
                if matches:
                    last_ingest = matches[-1]
            except OSError:
                pass

        # Health score
        lint_result = self.lint()

        return {
            "base_dir": str(self.base_dir),
            "total_pages": total,
            "pages_by_type": counts,
            "last_ingest": last_ingest,
            "health_score": lint_result.score,
        }

    # ------------------------------------------------------------------
    # RAG sync
    # ------------------------------------------------------------------

    def sync_to_rag(self) -> int:
        """Sync all wiki pages to the RAG store.

        Returns the number of pages synced.
        """
        try:
            from superagent.rag import get_rag
        except ImportError:
            logger.warning("rag module not available — skipping sync")
            return 0

        rag = get_rag()
        count = 0

        for rel_path in self._list_pages():
            page = self._read_page(rel_path)
            if page is None:
                continue

            full_path = self.base_dir / rel_path
            try:
                if hasattr(rag, "ingest"):
                    rag.ingest(str(full_path))
                elif hasattr(rag, "upload_document"):
                    rag.upload_document(str(full_path))
                count += 1
            except (OSError, Exception) as exc:
                logger.warning("Failed to sync %s to RAG: %s", rel_path, exc)

        self._append_log("rag_sync", f"synced={count}")
        return count

    # ------------------------------------------------------------------
    # Graph
    # ------------------------------------------------------------------

    def graph(self) -> dict:
        """Return a graph representation of the wiki for visualization.

        Returns a dict with ``nodes`` and ``edges`` lists suitable for
        rendering with D3, vis.js, or similar libraries.
        """
        nodes: list[dict] = []
        edges: list[dict] = []
        seen_edges: set[tuple[str, str]] = set()

        all_paths = self._list_pages()

        for rel_path in all_paths:
            page = self._read_page(rel_path)
            if page is None:
                continue

            slug = Path(rel_path).stem
            fm = page.frontmatter
            nodes.append({
                "id": slug,
                "label": fm.title or slug,
                "type": fm.type.value if isinstance(fm.type, PageType) else str(fm.type),
                "status": fm.status.value if isinstance(fm.status, PageStatus) else str(fm.status),
                "confidence": fm.confidence,
            })

            for link_target in page.wiki_links:
                target_slug = _slugify(link_target)
                edge_key = (slug, target_slug)
                if edge_key not in seen_edges:
                    edges.append({"source": slug, "target": target_slug})
                    seen_edges.add(edge_key)

        return {"nodes": nodes, "edges": edges}

    # ------------------------------------------------------------------
    # SHA256 incremental cache (Graphify pattern)
    # ------------------------------------------------------------------

    def _cache_path(self) -> Path:
        return self.base_dir / "cache.json"

    def _load_cache(self) -> dict[str, str]:
        cp = self._cache_path()
        if cp.exists():
            try:
                return json.loads(cp.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _is_cached(self, file_path: str, sha256: str) -> bool:
        cache = self._load_cache()
        return cache.get(os.path.abspath(file_path)) == sha256

    def _save_cache(self, file_path: str, sha256: str) -> None:
        cache = self._load_cache()
        cache[os.path.abspath(file_path)] = sha256
        self._cache_path().write_text(
            json.dumps(cache, indent=2, ensure_ascii=False), encoding="utf-8"
        )

    # ------------------------------------------------------------------
    # Interactive HTML graph (Graphify vis.js pattern)
    # ------------------------------------------------------------------

    def render_html(self) -> str:
        """Generate an interactive vis.js HTML graph and return the path."""
        g = self.graph()
        nodes_js = json.dumps(g["nodes"], ensure_ascii=False)
        edges_js = json.dumps(g["edges"], ensure_ascii=False)

        _TYPE_COLORS = {
            "source": "#4CAF50",
            "entity": "#2196F3",
            "concept": "#FF9800",
            "comparison": "#9C27B0",
            "synthesis": "#F44336",
        }

        html = f"""\
<!DOCTYPE html>
<html><head>
<meta charset="utf-8">
<title>SuperAgent Wiki Graph</title>
<script src="https://unpkg.com/vis-network/standalone/umd/vis-network.min.js"></script>
<style>
  body {{ margin:0; font-family: -apple-system, sans-serif; background: #1a1a2e; color: #eee; }}
  #graph {{ width:100vw; height:92vh; }}
  #toolbar {{ padding:8px 16px; background:#16213e; display:flex; gap:12px; align-items:center; }}
  #toolbar input {{ padding:6px 12px; border-radius:4px; border:1px solid #555; background:#0f3460; color:#eee; width:250px; }}
  .legend {{ display:flex; gap:10px; margin-left:auto; }}
  .legend span {{ display:flex; align-items:center; gap:4px; font-size:12px; }}
  .dot {{ width:10px; height:10px; border-radius:50%; display:inline-block; }}
</style>
</head><body>
<div id="toolbar">
  <strong>SuperAgent Wiki Graph</strong>
  <input id="search" placeholder="Search nodes..." oninput="filterNodes(this.value)">
  <div class="legend">
    <span><span class="dot" style="background:#4CAF50"></span>Source</span>
    <span><span class="dot" style="background:#2196F3"></span>Entity</span>
    <span><span class="dot" style="background:#FF9800"></span>Concept</span>
    <span><span class="dot" style="background:#9C27B0"></span>Comparison</span>
    <span><span class="dot" style="background:#F44336"></span>Synthesis</span>
  </div>
</div>
<div id="graph"></div>
<script>
const rawNodes = {nodes_js};
const rawEdges = {edges_js};
const typeColors = {json.dumps(_TYPE_COLORS)};

const nodes = new vis.DataSet(rawNodes.map(n => ({{
  id: n.id, label: n.label,
  color: typeColors[n.type] || '#888',
  title: n.type + ' | ' + (n.status || '') + ' | conf: ' + (n.confidence || ''),
  font: {{ color: '#eee', size: 12 }},
  shape: 'dot', size: 15 + (n.confidence || 0.5) * 10
}})));

const edges = new vis.DataSet(rawEdges.map((e, i) => ({{
  id: i, from: e.source, to: e.target,
  arrows: 'to', color: {{ color: '#555', opacity: 0.6 }}
}})));

const container = document.getElementById('graph');
const network = new vis.Network(container, {{ nodes, edges }}, {{
  physics: {{ solver: 'forceAtlas2Based', forceAtlas2Based: {{ gravitationalConstant: -30 }} }},
  interaction: {{ hover: true, tooltipDelay: 100 }},
  layout: {{ improvedLayout: true }}
}});

function filterNodes(q) {{
  if (!q) {{ nodes.forEach(n => nodes.update({{ id: n.id, hidden: false }})); return; }}
  const lower = q.toLowerCase();
  rawNodes.forEach(n => {{
    nodes.update({{ id: n.id, hidden: !n.label.toLowerCase().includes(lower) }});
  }});
}}
</script>
</body></html>"""

        out_path = self.base_dir / "wiki" / "graph.html"
        out_path.write_text(html, encoding="utf-8")
        return str(out_path)


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def _get_data_dir() -> Path:
    """Return the SuperAgent data directory (from env or default)."""
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


def get_wiki_store(wiki_dir: str | None = None) -> WikiStore:
    """Factory — return a WikiStore with the given or default directory.

    Uses ``CLAWTEAM_DATA_DIR`` env var falling back to ``~/.superagent/wiki``.
    """
    return WikiStore(wiki_dir=wiki_dir)
