"""Self-Evolution Engine — skill quality tracking, analysis, and auto-evolution.

Tracks skill execution outcomes (success/failure), detects degradation patterns,
and recommends or triggers skill evolution when quality drops below thresholds.

Inspired by OpenSpace AUTO-FIX/IMPROVE/LEARN concepts but kept practical:
- Each skill is a JSON record persisted to ~/.superagent/skills/
- Success/failure counters drive quality metrics
- Stale or failing skills are flagged for evolution
- Evolution creates a new version with reset counters
"""

from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class SkillRecord:
    """A tracked skill with execution metrics and version history."""

    name: str
    description: str
    version: int = 1
    category: str = "general"
    success_count: int = 0
    failure_count: int = 0
    last_used: str = ""
    last_error: str = ""
    evolved_from: Optional[str] = None
    status: str = "active"  # active | deprecated | fixing

    @property
    def total_runs(self) -> int:
        return self.success_count + self.failure_count

    @property
    def success_rate(self) -> float:
        if self.total_runs == 0:
            return 0.0
        return self.success_count / self.total_runs

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "version": self.version,
            "category": self.category,
            "success_count": self.success_count,
            "failure_count": self.failure_count,
            "last_used": self.last_used,
            "last_error": self.last_error,
            "evolved_from": self.evolved_from,
            "status": self.status,
        }

    @classmethod
    def from_dict(cls, data: dict) -> SkillRecord:
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            version=data.get("version", 1),
            category=data.get("category", "general"),
            success_count=data.get("success_count", 0),
            failure_count=data.get("failure_count", 0),
            last_used=data.get("last_used", ""),
            last_error=data.get("last_error", ""),
            evolved_from=data.get("evolved_from"),
            status=data.get("status", "active"),
        )


class SkillStore:
    """Manages skill records persisted as individual JSON files."""

    def __init__(self, skills_dir: str):
        self._dir = Path(skills_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    @property
    def path(self) -> Path:
        return self._dir

    def _skill_path(self, name: str) -> Path:
        safe_name = name.replace("/", "_").replace(" ", "_")
        return self._dir / f"{safe_name}.json"

    def load_all(self) -> list[SkillRecord]:
        """Load all skill records from disk."""
        skills: list[SkillRecord] = []
        if not self._dir.exists():
            return skills
        for fp in sorted(self._dir.glob("*.json")):
            try:
                data = json.loads(fp.read_text(encoding="utf-8"))
                skills.append(SkillRecord.from_dict(data))
            except (json.JSONDecodeError, KeyError):
                continue
        return skills

    def get(self, name: str) -> Optional[SkillRecord]:
        """Load a single skill by name. Returns None if not found."""
        fp = self._skill_path(name)
        if not fp.exists():
            return None
        try:
            data = json.loads(fp.read_text(encoding="utf-8"))
            return SkillRecord.from_dict(data)
        except (json.JSONDecodeError, KeyError):
            return None

    def save(self, skill: SkillRecord) -> None:
        """Persist a skill record to disk."""
        fp = self._skill_path(skill.name)
        atomic_write(fp, json.dumps(skill.to_dict(), indent=2, ensure_ascii=False) + "\n")

    def record_success(self, name: str) -> Optional[SkillRecord]:
        """Increment success counter and update last_used. Returns updated record or None."""
        skill = self.get(name)
        if skill is None:
            return None
        skill.success_count += 1
        skill.last_used = datetime.now(timezone.utc).isoformat()
        self.save(skill)
        return skill

    def record_failure(self, name: str, error: str = "") -> Optional[SkillRecord]:
        """Increment failure counter, store error, update last_used. Returns updated record or None."""
        skill = self.get(name)
        if skill is None:
            return None
        skill.failure_count += 1
        skill.last_used = datetime.now(timezone.utc).isoformat()
        if error:
            skill.last_error = error
        self.save(skill)
        return skill

    def get_failing_skills(self, threshold: float = 0.5) -> list[SkillRecord]:
        """Return skills with success rate below threshold that have been run at least once."""
        return [
            s for s in self.load_all()
            if s.total_runs > 0 and s.success_rate < threshold
        ]

    def get_top_skills(self, limit: int = 10) -> list[SkillRecord]:
        """Return the most successful skills sorted by success rate then total runs."""
        skills = [s for s in self.load_all() if s.total_runs > 0]
        skills.sort(key=lambda s: (s.success_rate, s.total_runs), reverse=True)
        return skills[:limit]

    def evolve_skill(self, name: str, new_description: str) -> Optional[SkillRecord]:
        """Create a new version of a skill with reset counters.

        The old version is marked as deprecated, and a new record is created
        with incremented version, reset counters, and evolved_from reference.
        Returns the new skill record or None if the original doesn't exist.
        """
        old = self.get(name)
        if old is None:
            return None
        # Deprecate the old version
        old.status = "deprecated"
        self.save(old)
        # Create evolved version
        evolved = SkillRecord(
            name=old.name,
            description=new_description,
            version=old.version + 1,
            category=old.category,
            success_count=0,
            failure_count=0,
            last_used="",
            last_error="",
            evolved_from=f"{old.name}@v{old.version}",
            status="active",
        )
        self.save(evolved)
        return evolved


@dataclass
class EvolutionReport:
    """Summary of skill ecosystem health and evolution recommendations."""

    skills_total: int = 0
    skills_healthy: int = 0
    skills_failing: int = 0
    recommendations: list[str] = field(default_factory=list)


def analyze_evolution(store: SkillStore) -> EvolutionReport:
    """Analyze all skills and generate evolution recommendations.

    - Flags skills with success_rate < 0.5 as "needs fix"
    - Flags skills unused for 30+ days as "stale"
    - Recommends evolution for skills with high failure + specific error patterns
    """
    skills = store.load_all()
    report = EvolutionReport(skills_total=len(skills))

    now = datetime.now(timezone.utc)
    stale_threshold_days = 30

    for skill in skills:
        if skill.status == "deprecated":
            continue

        is_failing = skill.total_runs > 0 and skill.success_rate < 0.5
        is_stale = False

        if skill.last_used:
            try:
                last = datetime.fromisoformat(skill.last_used)
                if last.tzinfo is None:
                    last = last.replace(tzinfo=timezone.utc)
                days_idle = (now - last).days
                is_stale = days_idle >= stale_threshold_days
            except ValueError:
                pass

        if is_failing:
            report.skills_failing += 1
            rate_pct = f"{skill.success_rate:.0%}"
            report.recommendations.append(
                f"[FIX] Skill '{skill.name}' has low success rate ({rate_pct}, "
                f"{skill.failure_count} failures). Consider evolving or fixing."
            )
            # Recommend evolution if there's a repeated error pattern
            if skill.last_error:
                report.recommendations.append(
                    f"  -> Last error: {skill.last_error[:120]}"
                )
        elif is_stale:
            report.recommendations.append(
                f"[STALE] Skill '{skill.name}' unused for {days_idle}+ days. "
                f"Review if still needed or deprecate."
            )
        else:
            report.skills_healthy += 1

    if not report.recommendations:
        report.recommendations.append("All skills are healthy. No action needed.")

    return report


def auto_fix(store: SkillStore) -> list[str]:
    """AUTO-FIX: Detect failing skills and create fixed versions.

    For skills with success_rate < 0.5 and last_error set:
    - Create a new evolved version with description updated to include fix notes
    - Append "[AUTO-FIX] Fixed based on error: {last_error}" to description
    - Return list of fixed skill names
    """
    fixed: list[str] = []
    for skill in store.load_all():
        if skill.status == "deprecated":
            continue
        if skill.total_runs > 0 and skill.success_rate < 0.5 and skill.last_error:
            new_desc = (
                f"{skill.description} "
                f"[AUTO-FIX] Fixed based on error: {skill.last_error}"
            )
            store.evolve_skill(skill.name, new_desc)
            fixed.append(skill.name)
    return fixed


def auto_learn(
    store: SkillStore,
    success_threshold: float = 0.8,
    min_runs: int = 5,
) -> list[str]:
    """AUTO-LEARN: Extract successful patterns as new skills.

    For skills with success_rate >= threshold and total_runs >= min_runs:
    - If no derived skill exists yet, create a "best-practice-{name}" derived skill
    - Copy description + append "[AUTO-LEARN] Extracted from {name} (success rate: {rate}%)"
    - Return list of newly created skill names
    """
    learned: list[str] = []
    for skill in store.load_all():
        if skill.status == "deprecated":
            continue
        if skill.success_rate >= success_threshold and skill.total_runs >= min_runs:
            bp_name = f"best-practice-{skill.name}"
            if store.get(bp_name) is not None:
                continue
            rate_pct = round(skill.success_rate * 100)
            new_desc = (
                f"{skill.description} "
                f"[AUTO-LEARN] Extracted from {skill.name} (success rate: {rate_pct}%)"
            )
            bp = SkillRecord(
                name=bp_name,
                description=new_desc,
                version=1,
                category=skill.category,
                evolved_from=f"{skill.name}@v{skill.version}",
                status="active",
            )
            store.save(bp)
            learned.append(bp_name)
    return learned


def export_skill_pack(store: SkillStore, names: list[str] = None, output_path: str = None) -> dict:
    """Export skills as a portable skill pack (JSON format compatible with community sharing).

    Format follows agentskills.io-inspired standard:
    {
        "format": "superagent-skill-pack-v1",
        "exported_at": "ISO timestamp",
        "skills": [
            {
                "name": "...",
                "description": "...",
                "category": "...",
                "version": N,
                "success_rate": 0.X,
                "total_runs": N,
                "tags": ["auto-learned", ...],
            }
        ]
    }
    """
    skills = store.load_all()
    if names:
        skills = [s for s in skills if s.name in names]

    pack = {
        "format": "superagent-skill-pack-v1",
        "exported_at": datetime.now(timezone.utc).isoformat(),
        "source": "superagent",
        "skills": [
            {
                "name": s.name,
                "description": s.description,
                "category": s.category,
                "version": s.version,
                "success_rate": round(s.success_rate, 3),
                "total_runs": s.total_runs,
                "status": s.status,
                "evolved_from": s.evolved_from,
            }
            for s in skills if s.status != "deprecated"
        ],
    }

    if output_path:
        Path(output_path).write_text(json.dumps(pack, indent=2, ensure_ascii=False))

    return pack


def import_skill_pack(store: SkillStore, pack: dict) -> int:
    """Import skills from a skill pack. Returns count imported."""
    # Security scan imported skills
    try:
        from superagent.skills_guard import scan_text
        safe_skills = []
        for skill_data in pack.get("skills", []):
            result = scan_text(skill_data.get("description", ""), source=f"skill:{skill_data.get('name','?')}")
            if result.verdict == "dangerous":
                logger.warning("Blocked dangerous skill: %s (%s)", skill_data.get("name"), 
                              [f.description for f in result.findings[:3]])
                continue
            safe_skills.append(skill_data)
        pack = {**pack, "skills": safe_skills}
    except ImportError:
        pass

    count = 0
    for skill_data in pack.get("skills", []):
        existing = store.get(skill_data["name"])
        if existing and existing.version >= skill_data.get("version", 1):
            continue  # Don't downgrade

        skill = SkillRecord(
            name=skill_data["name"],
            description=skill_data.get("description", ""),
            category=skill_data.get("category", "imported"),
            version=skill_data.get("version", 1),
            status=skill_data.get("status", "active"),
            evolved_from=skill_data.get("evolved_from"),
        )
        store.save(skill)
        count += 1

    return count


def get_skill_store(data_dir: Optional[str] = None) -> SkillStore:
    """Factory to create a SkillStore with the default or specified path."""
    if data_dir is None:
        data_dir = os.environ.get(
            "CLAWTEAM_DATA_DIR",
            os.path.join(os.path.expanduser("~"), ".superagent"),
        )
    skills_dir = os.path.join(data_dir, "skills")
    return SkillStore(skills_dir)
