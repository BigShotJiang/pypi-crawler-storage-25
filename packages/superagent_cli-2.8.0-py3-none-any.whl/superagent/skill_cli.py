"""SuperAgent skill CLI commands — track, evolve, and analyze skill quality."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.evolution import (
    SkillRecord,
    SkillStore,
    analyze_evolution,
    auto_fix,
    auto_learn,
    get_skill_store,
)

skill_app = typer.Typer(
    name="skill",
    help="Skill management — track quality, trigger evolution, and analyze skill health.",
    no_args_is_help=True,
)
console = Console()


def _get_store() -> SkillStore:
    """Get a SkillStore using CLAWTEAM_DATA_DIR or default."""
    data_dir = os.environ.get(
        "CLAWTEAM_DATA_DIR",
        os.path.join(os.path.expanduser("~"), ".superagent"),
    )
    return get_skill_store(data_dir)


@skill_app.command("list")
def skill_list(
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status (active/deprecated/fixing)."),
    sort: str = typer.Option("name", "--sort", help="Sort by: name, success_rate, or runs."),
):
    """List all tracked skills."""
    store = _get_store()
    skills = store.load_all()

    if status:
        skills = [s for s in skills if s.status == status]

    if sort == "success_rate":
        skills.sort(key=lambda s: s.success_rate, reverse=True)
    elif sort == "runs":
        skills.sort(key=lambda s: s.total_runs, reverse=True)
    else:
        skills.sort(key=lambda s: s.name)

    if not skills:
        console.print("[yellow]No skills found.[/yellow]")
        return

    table = Table(title=f"Skills ({len(skills)} total)")
    table.add_column("Name", style="bold", min_width=15)
    table.add_column("Version", justify="center", width=8)
    table.add_column("Category", style="cyan", width=12)
    table.add_column("Status", width=12)
    table.add_column("Runs", justify="right", width=6)
    table.add_column("Success Rate", justify="right", width=13)
    table.add_column("Description", style="dim", max_width=40)

    for s in skills:
        status_style = {"active": "green", "deprecated": "dim", "fixing": "yellow"}.get(s.status, "white")
        rate = f"{s.success_rate:.0%}" if s.total_runs > 0 else "-"
        rate_style = "green" if s.success_rate >= 0.8 else ("yellow" if s.success_rate >= 0.5 else "red")
        if s.total_runs == 0:
            rate_style = "dim"
        table.add_row(
            s.name,
            f"v{s.version}",
            s.category,
            f"[{status_style}]{s.status}[/{status_style}]",
            str(s.total_runs),
            f"[{rate_style}]{rate}[/{rate_style}]",
            (s.description[:37] + "...") if len(s.description) > 40 else s.description,
        )

    console.print(table)


@skill_app.command("show")
def skill_show(
    name: str = typer.Argument(..., help="Skill name to show details for."),
):
    """Show detailed information about a skill."""
    store = _get_store()
    skill = store.get(name)
    if skill is None:
        console.print(f"[red]Skill '{name}' not found.[/red]")
        raise typer.Exit(1)

    status_style = {"active": "green", "deprecated": "dim", "fixing": "yellow"}.get(skill.status, "white")
    rate = f"{skill.success_rate:.1%}" if skill.total_runs > 0 else "N/A"

    info_lines = [
        f"[bold]Name:[/bold]         {skill.name}",
        f"[bold]Description:[/bold]  {skill.description}",
        f"[bold]Version:[/bold]      v{skill.version}",
        f"[bold]Category:[/bold]     {skill.category}",
        f"[bold]Status:[/bold]       [{status_style}]{skill.status}[/{status_style}]",
        "",
        f"[bold]Total Runs:[/bold]   {skill.total_runs}",
        f"[bold]Successes:[/bold]    {skill.success_count}",
        f"[bold]Failures:[/bold]     {skill.failure_count}",
        f"[bold]Success Rate:[/bold] {rate}",
        "",
        f"[bold]Last Used:[/bold]    {skill.last_used or 'never'}",
    ]

    if skill.last_error:
        info_lines.append(f"[bold]Last Error:[/bold]   [red]{skill.last_error}[/red]")
    if skill.evolved_from:
        info_lines.append(f"[bold]Evolved From:[/bold] {skill.evolved_from}")

    panel = Panel("\n".join(info_lines), title=f"Skill: {skill.name}", border_style="blue")
    console.print(panel)


@skill_app.command("record")
def skill_record(
    name: str = typer.Argument(..., help="Skill name to record outcome for."),
    success: bool = typer.Option(False, "--success", help="Record a successful run."),
    failure: bool = typer.Option(False, "--failure", help="Record a failed run."),
    error: Optional[str] = typer.Option(None, "--error", "-e", help="Error message (used with --failure)."),
):
    """Record a success or failure outcome for a skill."""
    if not success and not failure:
        console.print("[red]Specify --success or --failure.[/red]")
        raise typer.Exit(1)

    if success and failure:
        console.print("[red]Specify only one of --success or --failure.[/red]")
        raise typer.Exit(1)

    store = _get_store()

    if success:
        result = store.record_success(name)
        if result is None:
            console.print(f"[red]Skill '{name}' not found.[/red]")
            raise typer.Exit(1)
        console.print(f"[green]Recorded success for '{name}' (total: {result.success_count}/{result.total_runs})[/green]")
    else:
        result = store.record_failure(name, error=error or "")
        if result is None:
            console.print(f"[red]Skill '{name}' not found.[/red]")
            raise typer.Exit(1)
        console.print(f"[yellow]Recorded failure for '{name}' (total: {result.failure_count}/{result.total_runs})[/yellow]")


@skill_app.command("evolve")
def skill_evolve(
    name: str = typer.Argument(..., help="Skill name to evolve."),
    description: str = typer.Option(..., "--description", "-d", help="Description for the evolved version."),
):
    """Create an evolved version of a skill with reset counters."""
    store = _get_store()
    evolved = store.evolve_skill(name, description)
    if evolved is None:
        console.print(f"[red]Skill '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold]Name:[/bold]         {evolved.name}\n"
        f"[bold]Version:[/bold]      v{evolved.version}\n"
        f"[bold]Description:[/bold]  {evolved.description}\n"
        f"[bold]Evolved From:[/bold] {evolved.evolved_from}\n"
        f"[bold]Status:[/bold]       [green]{evolved.status}[/green]",
        title="Skill Evolved",
        border_style="green",
    ))


@skill_app.command("analyze")
def skill_analyze():
    """Run evolution analysis and show health report."""
    store = _get_store()
    report = analyze_evolution(store)

    summary = (
        f"[bold]Total Skills:[/bold]   {report.skills_total}\n"
        f"[bold]Healthy:[/bold]        [green]{report.skills_healthy}[/green]\n"
        f"[bold]Failing:[/bold]        [red]{report.skills_failing}[/red]"
    )

    console.print(Panel(summary, title="Evolution Report", border_style="blue"))

    if report.recommendations:
        console.print("\n[bold]Recommendations:[/bold]")
        for rec in report.recommendations:
            if rec.startswith("  ->"):
                console.print(f"  [dim]{rec.strip()}[/dim]")
            elif rec.startswith("[FIX]"):
                console.print(f"  [red]{rec}[/red]")
            elif rec.startswith("[STALE]"):
                console.print(f"  [yellow]{rec}[/yellow]")
            else:
                console.print(f"  [green]{rec}[/green]")
        console.print()


@skill_app.command("create")
def skill_create(
    name: str = typer.Argument(..., help="Name for the new skill."),
    description: str = typer.Option(..., "--description", "-d", help="Skill description."),
    category: str = typer.Option("general", "--category", "-c", help="Skill category."),
):
    """Create a new skill record."""
    store = _get_store()

    if store.get(name) is not None:
        console.print(f"[red]Skill '{name}' already exists. Use 'evolve' to create a new version.[/red]")
        raise typer.Exit(1)

    skill = SkillRecord(name=name, description=description, category=category)
    store.save(skill)
    console.print(f"[green]Created skill '{name}' (v1, category: {category})[/green]")


@skill_app.command("share")
def skill_share(
    name: str = typer.Argument(..., help="Skill name to export."),
    output_dir: str = typer.Option(None, "--output", "-o", help="Output directory (default: ~/.superagent/shared-skills/)."),
):
    """Export a skill to a shareable JSON file."""
    store = _get_store()
    skill = store.get(name)
    if skill is None:
        console.print(f"[red]Skill '{name}' not found.[/red]")
        raise typer.Exit(1)

    if output_dir:
        out = Path(output_dir)
    else:
        out = Path.home() / ".superagent" / "shared-skills"
    out.mkdir(parents=True, exist_ok=True)

    out_file = out / f"{name}.json"
    out_file.write_text(json.dumps(skill.to_dict(), indent=2, ensure_ascii=False) + "\n", encoding="utf-8")
    console.print(f"[green]Exported skill '{name}' to {out_file}[/green]")


@skill_app.command("import-shared")
def skill_import_shared(
    path: str = typer.Argument(..., help="Path to a shared skill JSON file."),
):
    """Import a shared skill from a JSON file."""
    fp = Path(path)
    if not fp.is_file():
        console.print(f"[red]File '{path}' does not exist.[/red]")
        raise typer.Exit(1)

    try:
        data = json.loads(fp.read_text(encoding="utf-8"))
        skill = SkillRecord.from_dict(data)
    except (json.JSONDecodeError, KeyError) as exc:
        console.print(f"[red]Invalid skill file: {exc}[/red]")
        raise typer.Exit(1)

    store = _get_store()
    if store.get(skill.name) is not None:
        console.print(f"[yellow]Skill '{skill.name}' already exists — overwriting.[/yellow]")

    store.save(skill)
    console.print(f"[green]Imported skill '{skill.name}' (v{skill.version}, category: {skill.category})[/green]")


@skill_app.command("auto-evolve")
def skill_auto_evolve():
    """Run AUTO-FIX and AUTO-LEARN on all skills."""
    store = _get_store()

    console.print("[bold]Running AUTO-FIX...[/bold]")
    fixed = auto_fix(store)
    if fixed:
        for name in fixed:
            console.print(f"  [red]Fixed:[/red] {name}")
    else:
        console.print("  [dim]No failing skills to fix.[/dim]")

    console.print("[bold]Running AUTO-LEARN...[/bold]")
    learned = auto_learn(store)
    if learned:
        for name in learned:
            console.print(f"  [green]Learned:[/green] {name}")
    else:
        console.print("  [dim]No new best-practice skills to extract.[/dim]")

    total = len(fixed) + len(learned)
    console.print(Panel(
        f"[bold]Fixed:[/bold]   {len(fixed)} skill(s)\n"
        f"[bold]Learned:[/bold] {len(learned)} skill(s)\n"
        f"[bold]Total:[/bold]   {total} action(s)",
        title="Auto-Evolve Summary",
        border_style="green" if total > 0 else "dim",
    ))


@skill_app.command("export-pack")
def skill_export_pack(
    output: str = typer.Option("skill-pack.json", "--output", "-o", help="Output file path."),
    names: Optional[str] = typer.Option(None, "--names", help="Comma-separated skill names (default: all)."),
):
    """Export skills as a portable skill pack for community sharing."""
    from superagent.evolution import export_skill_pack
    store = _get_store()
    name_list = [n.strip() for n in names.split(",")] if names else None
    pack = export_skill_pack(store, names=name_list, output_path=output)
    console.print(f"[green]Exported {len(pack['skills'])} skills to {output}[/green]")


@skill_app.command("import-pack")
def skill_import_pack(
    path: str = typer.Argument(..., help="Path to skill pack JSON file."),
):
    """Import skills from a community skill pack."""
    import json

    from superagent.evolution import import_skill_pack
    store = _get_store()
    with open(path) as f:
        pack = json.load(f)

    if pack.get("format") != "superagent-skill-pack-v1":
        console.print(f"[yellow]Warning: Unknown format '{pack.get('format')}', attempting import anyway.[/yellow]")

    count = import_skill_pack(store, pack)
    console.print(f"[green]Imported {count} skills from {path}[/green]")


@skill_app.command("export-agentskills")
def skill_export_agentskills(
    output: str = typer.Option("./skills-export", "--output", "-o", help="Output directory."),
):
    """Export skills as agentskills.io Markdown format (Hermes/OpenHarness compatible)."""
    import os
    store = _get_store()
    skills = store.load_all()

    os.makedirs(output, exist_ok=True)
    count = 0

    for skill in skills:
        if skill.status == "deprecated":
            continue
        filename = skill.name.replace(" ", "-").lower() + ".md"
        content = (
            f"---\n"
            f"name: {skill.name}\n"
            f"description: {skill.description}\n"
            f"category: {skill.category}\n"
            f"version: {skill.version}\n"
            f"success_rate: {skill.success_rate:.0%}\n"
            f"---\n\n"
            f"# {skill.name}\n\n"
            f"## Description\n{skill.description}\n\n"
            f"## Category\n{skill.category}\n\n"
            f"## Usage\nThis skill was auto-learned by SuperAgent.\n"
            f"Success rate: {skill.success_rate:.0%} ({skill.success_count}/{skill.total_runs} runs)\n"
        )
        with open(os.path.join(output, filename), "w", encoding="utf-8") as f:
            f.write(content)
        count += 1

    console.print(f"[green]Exported {count} skills to {output}/ (agentskills.io format)[/green]")
    console.print("[dim]Compatible with Hermes Agent and OpenHarness[/dim]")


@skill_app.command("import-agentskills")
def skill_import_agentskills(
    path: str = typer.Argument(..., help="Path to agentskills.io Markdown file or directory."),
):
    """Import skills from agentskills.io Markdown format (Hermes/OpenHarness compatible)."""
    import os
    import re

    from superagent.evolution import SkillRecord

    store = _get_store()
    files = []

    if os.path.isdir(path):
        files = [os.path.join(path, f) for f in os.listdir(path) if f.endswith(".md")]
    elif os.path.isfile(path):
        files = [path]
    else:
        console.print(f"[red]Path not found: {path}[/red]")
        raise typer.Exit(1)

    count = 0
    for fpath in files:
        try:
            text = open(fpath, encoding="utf-8").read()
            # Parse YAML frontmatter
            meta = {}
            match = re.match(r"^---\n(.*?)\n---", text, re.DOTALL)
            if match:
                for line in match.group(1).splitlines():
                    if ":" in line:
                        k, _, v = line.partition(":")
                        meta[k.strip()] = v.strip()

            name = meta.get("name", os.path.splitext(os.path.basename(fpath))[0])
            desc = meta.get("description", "Imported from agentskills.io")
            category = meta.get("category", "imported")

            existing = store.get(name)
            if existing:
                console.print(f"  [yellow]Skip[/yellow] {name} (already exists)")
                continue

            skill = SkillRecord(
                name=name,
                description=desc,
                category=category,
                version=int(meta.get("version", 1)),
            )
            store.save(skill)
            count += 1
            console.print(f"  [green]+[/green] {name}")
        except Exception as exc:
            console.print(f"  [red]Error[/red] {fpath}: {exc}")

    console.print(f"\n[green]Imported {count} skills from agentskills.io format[/green]")


# ---------------------------------------------------------------
# New commands: skill execution (CodeBuddy-inspired SKILL.md)
# ---------------------------------------------------------------

@skill_app.command("exec")
def skill_exec(
    name: str = typer.Argument(..., help="Skill name to execute"),
    arguments: str = typer.Option("", "--args", "-a", help="Arguments for the skill"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Execute a skill by name (SKILL.md execution engine)."""
    import asyncio
    from superagent.skill_exec import get_skill_execution_registry
    from superagent.llm_gateway import call_llm

    registry = get_skill_execution_registry()
    skill = registry.get(name)

    if skill is None:
        console.print(f"[red]Skill '{name}' not found.[/red]")
        console.print("[dim]Available skills: " + ", ".join(s.name for s in registry.list_skills()) + "[/dim]")
        raise typer.Exit(1)

    # Render the skill prompt with parameter substitution and shell execution
    rendered = registry.render_skill_prompt(name, arguments=arguments)
    if rendered is None:
        console.print(f"[red]Failed to render skill '{name}'.[/red]")
        raise typer.Exit(1)

    if not json_out:
        console.print(f"[bold green]Executing skill:[/bold green] {name}")
        console.print(f"[dim]Description: {skill.description}[/dim]")
        console.print(f"[dim]Tools: {', '.join(skill.allowed_tools) or '(inherit all)'}[/dim]")

    # Execute via LLM
    result = asyncio.run(call_llm(rendered, provider="default"))

    # Record outcome in the existing evolution system
    store = _get_store()
    if store.get(name) is None:
        store.save(SkillRecord(name=name, description=skill.description, category="skill-exec"))
    store.record_success(name)

    if json_out:
        console.print(json.dumps({
            "skill": name,
            "result": result or "",
            "status": "success",
        }, indent=2, ensure_ascii=False))
    else:
        from rich.panel import Panel
        console.print(Panel(
            result[:5000] if result else "(no output)",
            title=f"Skill: {name} (completed)",
            border_style="green",
        ))


@skill_app.command("match")
def skill_match(
    task: str = typer.Argument(..., help="Task description to match against skills"),
):
    """Find the best skill for a task (AI auto-invocation matching)."""
    from superagent.skill_exec import get_skill_execution_registry
    registry = get_skill_execution_registry()
    skill = registry.match_skill(task)

    if skill is None:
        console.print("[yellow]No matching skill found for this task.[/yellow]")
        console.print("[dim]Available: " + ", ".join(s.name for s in registry.list_skills()) + "[/dim]")
        raise typer.Exit(1)

    console.print(f"[green]Best match: {skill.name}[/green]")
    console.print(f"  Description: {skill.description}")
    console.print(f"  Tools: {', '.join(skill.allowed_tools) or '(inherit all)'}")
    console.print(f"  Context: {skill.context}")


@skill_app.command("seed-skills")
def skill_seed_skills():
    """Seed built-in SKILL.md definitions (commit, security-review, diagnose)."""
    from superagent.skill_exec import seed_builtin_skills
    count = seed_builtin_skills()
    if count > 0:
        console.print(f"[green]Seeded {count} built-in skills.[/green]")
    else:
        console.print("[dim]All built-in skills already exist.[/dim]")


@skill_app.command("render")
def skill_render(
    name: str = typer.Argument(..., help="Skill name"),
    arguments: str = typer.Option("", "--args", "-a", help="Arguments for the skill"),
):
    """Render a skill's prompt (preview before execution)."""
    from superagent.skill_exec import get_skill_execution_registry
    registry = get_skill_execution_registry()

    rendered = registry.render_skill_prompt(name, arguments=arguments)
    if rendered is None:
        console.print(f"[red]Skill '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        rendered[:3000],
        title=f"Skill: {name} (rendered)",
        border_style="cyan",
    ))
