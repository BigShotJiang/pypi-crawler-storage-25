"""CLI commands for SuperAgent Langfuse observability.

Provides the ``superagent trace`` subcommand group with status, list, start,
and log operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.observability import get_tracer, is_langfuse_available

observability_app = typer.Typer(
    name="trace",
    help="Observability — Langfuse-powered agent execution tracing.",
    no_args_is_help=True,
)
console = Console()


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@observability_app.command("status")
def trace_status():
    """Check Langfuse availability and connection status."""
    available = is_langfuse_available()

    if available:
        import os

        host = os.environ.get("LANGFUSE_HOST", "https://cloud.langfuse.com")
        public_key = os.environ.get("LANGFUSE_PUBLIC_KEY", "")
        masked_key = public_key[:8] + "..." if len(public_key) > 8 else public_key

        console.print(Panel(
            f"[bold green]Langfuse is available[/bold green]\n\n"
            f"  [bold]Host:[/bold]       {host}\n"
            f"  [bold]Public Key:[/bold] {masked_key}\n"
            f"  [bold]Secret Key:[/bold] ********",
            title="Trace Status",
            border_style="green",
        ))
    else:
        # Determine what's missing
        try:
            import langfuse  # noqa: F401
            pkg_installed = True
        except ImportError:
            pkg_installed = False

        import os

        has_public = bool(os.environ.get("LANGFUSE_PUBLIC_KEY"))
        has_secret = bool(os.environ.get("LANGFUSE_SECRET_KEY"))

        issues: list[str] = []
        if not pkg_installed:
            issues.append("[red]langfuse package not installed[/red] — pip install langfuse")
        if not has_public:
            issues.append("[red]LANGFUSE_PUBLIC_KEY not set[/red]")
        if not has_secret:
            issues.append("[red]LANGFUSE_SECRET_KEY not set[/red]")

        issue_text = "\n  ".join(issues) if issues else "Unknown issue"

        console.print(Panel(
            f"[bold red]Langfuse is not available[/bold red]\n\n"
            f"  {issue_text}\n\n"
            f"  [dim]Set LANGFUSE_PUBLIC_KEY, LANGFUSE_SECRET_KEY, and optionally\n"
            f"  LANGFUSE_HOST to enable observability.[/dim]",
            title="Trace Status",
            border_style="red",
        ))


@observability_app.command("list")
def trace_list(
    limit: int = typer.Option(20, "--limit", "-n", help="Maximum number of traces to display."),
):
    """List recent traces from Langfuse."""
    if not is_langfuse_available():
        console.print("[red]Langfuse is not available. Run 'superagent trace status' for details.[/red]")
        raise typer.Exit(1)

    tracer = get_tracer()
    traces = tracer.get_traces(limit=limit)

    if not traces:
        console.print("[yellow]No traces found.[/yellow]")
        return

    table = Table(title=f"Recent Traces ({len(traces)} found)")
    table.add_column("ID", style="cyan", width=18)
    table.add_column("Name", style="blue", width=24)
    table.add_column("Status", width=12)
    table.add_column("Started", style="dim", width=22)

    for t in traces:
        status = t.get("status", "unknown")
        status_style = {
            "success": "bold green",
            "error": "bold red",
            "running": "bold yellow",
        }.get(status, "dim")

        table.add_row(
            t.get("id", "")[:18],
            t.get("name", "—"),
            f"[{status_style}]{status}[/{status_style}]",
            t.get("started_at", "—")[:22],
        )

    console.print(table)


@observability_app.command("start")
def trace_start(
    name: str = typer.Argument(..., help="Name for the new trace."),
    metadata: Optional[str] = typer.Option(None, "--metadata", "-m", help="JSON metadata string."),
):
    """Manually start a new trace."""
    if not is_langfuse_available():
        console.print("[red]Langfuse is not available. Run 'superagent trace status' for details.[/red]")
        raise typer.Exit(1)

    meta: dict = {}
    if metadata:
        import json

        try:
            meta = json.loads(metadata)
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON for --metadata: {e}[/red]")
            raise typer.Exit(1)

    tracer = get_tracer()
    trace_id = tracer.trace_start(name=name, metadata=meta)

    console.print(Panel(
        f"[bold green]Trace started[/bold green]\n\n"
        f"  [bold]Trace ID:[/bold] {trace_id}\n"
        f"  [bold]Name:[/bold]     {name}",
        title="trace start",
        border_style="green",
    ))


@observability_app.command("log")
def trace_log(
    trace_id: str = typer.Argument(..., help="Trace ID to log the event to."),
    event: str = typer.Argument(..., help="Event name or description."),
    input: Optional[str] = typer.Option(None, "--input", "-i", help="Event input (string or JSON)."),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Event output (string or JSON)."),
    level: str = typer.Option("DEFAULT", "--level", "-l", help="Event level: DEFAULT, DEBUG, WARNING, ERROR."),
):
    """Log an event to an existing trace."""
    if not is_langfuse_available():
        console.print("[red]Langfuse is not available. Run 'superagent trace status' for details.[/red]")
        raise typer.Exit(1)

    # Try to parse input/output as JSON, fall back to raw string
    import json

    def _parse(value: Optional[str]):
        if value is None:
            return None
        try:
            return json.loads(value)
        except json.JSONDecodeError:
            return value

    tracer = get_tracer()
    tracer.trace_event(
        trace_id=trace_id,
        name=event,
        input=_parse(input),
        output=_parse(output),
        level=level,
    )

    console.print(
        f"[green]Event logged[/green] to trace [cyan]{trace_id}[/cyan]: {event}"
    )
