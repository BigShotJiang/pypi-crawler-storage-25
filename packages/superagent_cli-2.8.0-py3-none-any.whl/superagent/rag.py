"""RAG (Retrieval-Augmented Generation) for SuperAgent — powered by RAGFlow (75k stars).

RAGFlow is a heavy server-based RAG engine for document retrieval. This module
provides a lightweight bridge that works with a running RAGFlow server, and falls
back to a simple keyword-based RAG when the server is not available.

Usage:
    rag = get_rag()          # auto-detects RAGFlow or falls back to SimpleRAG
    rag.search("my query")   # search across indexed documents
"""
from __future__ import annotations

import json
import logging
import os
import shutil
import urllib.error
import urllib.request
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_DEFAULT_BASE_URL = "http://localhost:9380"
_RAG_STORE_DIR = os.path.join(os.path.expanduser("~"), ".superagent", "rag")


def is_ragflow_available(base_url: str = _DEFAULT_BASE_URL) -> bool:
    """Check if a RAGFlow server is running and reachable."""
    try:
        req = urllib.request.Request(
            f"{base_url}/api/v1/datasets",
            method="GET",
            headers={"Content-Type": "application/json"},
        )
        with urllib.request.urlopen(req, timeout=3):
            return True
    except (urllib.error.URLError, OSError, ValueError):
        return False


class RAGBridge:
    """Bridge to a running RAGFlow server for document retrieval.

    RAGFlow API docs: https://ragflow.io/docs/dev/
    """

    def __init__(
        self,
        base_url: str = _DEFAULT_BASE_URL,
        api_key: Optional[str] = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.api_key = api_key or os.environ.get("RAGFLOW_API_KEY", "")

    @property
    def engine_name(self) -> str:
        return "ragflow"

    def _headers(self) -> dict[str, str]:
        headers = {"Content-Type": "application/json"}
        if self.api_key:
            headers["Authorization"] = f"Bearer {self.api_key}"
        return headers

    def _request(
        self,
        method: str,
        path: str,
        data: Optional[dict] = None,
    ) -> dict:
        """Send an HTTP request to the RAGFlow API and return the JSON response."""
        url = f"{self.base_url}{path}"
        body = json.dumps(data).encode() if data else None
        req = urllib.request.Request(url, data=body, headers=self._headers(), method=method)
        try:
            with urllib.request.urlopen(req, timeout=30) as resp:
                return json.loads(resp.read().decode())
        except urllib.error.HTTPError as exc:
            body_text = exc.read().decode() if exc.fp else ""
            logger.error("RAGFlow HTTP %s: %s", exc.code, body_text)
            return {"code": exc.code, "message": body_text}
        except (urllib.error.URLError, OSError) as exc:
            logger.error("RAGFlow request failed: %s", exc)
            return {"code": -1, "message": str(exc)}

    def upload_document(self, file_path: str, dataset_id: str = "default") -> str:
        """Upload a document to RAGFlow for indexing.

        Returns the document ID assigned by RAGFlow.
        """
        file_path = os.path.expanduser(file_path)
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        url = f"{self.base_url}/api/v1/datasets/{dataset_id}/documents"
        filename = os.path.basename(file_path)

        # Build multipart form data
        boundary = "----SuperAgentBoundary"
        with open(file_path, "rb") as f:
            file_data = f.read()

        body = (
            f"--{boundary}\r\n"
            f'Content-Disposition: form-data; name="file"; filename="{filename}"\r\n'
            f"Content-Type: application/octet-stream\r\n\r\n"
        ).encode() + file_data + f"\r\n--{boundary}--\r\n".encode()

        headers = self._headers()
        headers["Content-Type"] = f"multipart/form-data; boundary={boundary}"

        req = urllib.request.Request(url, data=body, headers=headers, method="POST")
        try:
            with urllib.request.urlopen(req, timeout=60) as resp:
                result = json.loads(resp.read().decode())
                doc_id = result.get("data", {}).get("id", "")
                if doc_id:
                    logger.info("Uploaded document '%s' → id=%s", filename, doc_id)
                return doc_id
        except (urllib.error.URLError, OSError) as exc:
            logger.error("Upload failed: %s", exc)
            return ""

    def search(self, query: str, limit: int = 5, dataset_id: str = "default") -> list[dict]:
        """Search for relevant document chunks matching the query.

        Returns a list of dicts with keys: content, score, document_name.
        """
        result = self._request("POST", "/api/v1/retrieval", data={
            "question": query,
            "dataset_ids": [dataset_id],
            "top_k": limit,
        })
        chunks = result.get("data", {}).get("chunks", [])
        return [
            {
                "content": c.get("content", ""),
                "score": c.get("similarity", 0.0),
                "document_name": c.get("document_name", ""),
            }
            for c in chunks[:limit]
        ]

    def list_documents(self, dataset_id: str = "default") -> list[dict]:
        """List all documents in a RAGFlow dataset.

        Returns a list of dicts with keys: id, name, size, status.
        """
        result = self._request("GET", f"/api/v1/datasets/{dataset_id}/documents")
        docs = result.get("data", {}).get("documents", [])
        return [
            {
                "id": d.get("id", ""),
                "name": d.get("name", ""),
                "size": d.get("size", 0),
                "status": d.get("run", "unknown"),
            }
            for d in docs
        ]


class SimpleRAG:
    """Fallback RAG using plain-text keyword search when RAGFlow is not available.

    Stores documents as files under ``~/.superagent/rag/`` and performs simple
    keyword matching for retrieval.
    """

    def __init__(self, store_dir: Optional[str] = None) -> None:
        self.store_dir = Path(store_dir or _RAG_STORE_DIR)
        self.store_dir.mkdir(parents=True, exist_ok=True)

    @property
    def engine_name(self) -> str:
        return "simple"

    def ingest(self, file_path: str) -> str:
        """Copy a file into the RAG store for later searching.

        Returns the stored file name.
        """
        file_path = os.path.expanduser(file_path)
        if not os.path.isfile(file_path):
            raise FileNotFoundError(f"File not found: {file_path}")

        dest = self.store_dir / os.path.basename(file_path)
        shutil.copy2(file_path, dest)
        logger.info("Ingested '%s' → %s", os.path.basename(file_path), dest)
        return dest.name

    def search(self, query: str, limit: int = 5) -> list[dict]:
        """Keyword search across all stored documents.

        Splits the query into words and scores each document by the number of
        matching words found in its content. Returns the top results sorted by
        relevance score.
        """
        query_words = set(query.lower().split())
        if not query_words:
            return []

        scored: list[tuple[str, float, str]] = []
        for path in self.store_dir.iterdir():
            if path.is_dir() or path.name.startswith("."):
                continue
            try:
                text = path.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue

            text_lower = text.lower()
            score = 0.0

            # Full query substring match
            if query.lower() in text_lower:
                score += 3.0

            # Individual word matches
            for word in query_words:
                if word in text_lower:
                    score += 1.0

            if score > 0:
                # Extract a relevant snippet (first occurrence context)
                snippet = _extract_snippet(text, query_words)
                scored.append((path.name, score, snippet))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [
            {
                "content": snippet,
                "score": score,
                "document_name": name,
            }
            for name, score, snippet in scored[:limit]
        ]

    def list_documents(self) -> list[dict]:
        """List all documents in the local RAG store."""
        docs = []
        for path in sorted(self.store_dir.iterdir()):
            if path.is_dir() or path.name.startswith("."):
                continue
            stat = path.stat()
            docs.append({
                "id": path.name,
                "name": path.name,
                "size": stat.st_size,
                "status": "indexed",
            })
        return docs


def _extract_snippet(text: str, query_words: set[str], context_chars: int = 200) -> str:
    """Extract a text snippet around the first occurrence of a query word."""
    text_lower = text.lower()
    best_pos = len(text)
    for word in query_words:
        pos = text_lower.find(word)
        if 0 <= pos < best_pos:
            best_pos = pos

    if best_pos >= len(text):
        # No match found, return start of document
        return text[:context_chars].strip()

    start = max(0, best_pos - context_chars // 2)
    end = min(len(text), best_pos + context_chars // 2)
    snippet = text[start:end].strip()
    if start > 0:
        snippet = "..." + snippet
    if end < len(text):
        snippet = snippet + "..."
    return snippet


def get_rag(
    base_url: Optional[str] = None,
    api_key: Optional[str] = None,
) -> RAGBridge | SimpleRAG:
    """Return the best available RAG backend.

    If a RAGFlow server is reachable at *base_url*, returns a ``RAGBridge``.
    Otherwise returns a ``SimpleRAG`` using local keyword search.
    """
    url = base_url or _DEFAULT_BASE_URL
    if is_ragflow_available(url):
        logger.info("RAGFlow server detected at %s", url)
        return RAGBridge(base_url=url, api_key=api_key)
    logger.info("RAGFlow not available — using SimpleRAG fallback")
    return SimpleRAG()
