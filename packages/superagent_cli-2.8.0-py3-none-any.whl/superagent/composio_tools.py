"""External service integration for SuperAgent — powered by Composio (12k stars).

Provides unified access to 200+ external services (GitHub, Slack, Jira, Linear, etc.)
"""
from __future__ import annotations

import logging
from typing import Optional

logger = logging.getLogger(__name__)

_COMPOSIO_AVAILABLE = False
try:
    from composio import Action, App, ComposioToolSet
    _COMPOSIO_AVAILABLE = True
except ImportError:
    logger.debug("composio not installed: pip install composio-core")


def is_composio_available() -> bool:
    return _COMPOSIO_AVAILABLE


class ComposioBridge:
    """Bridge to Composio's 200+ service integrations."""
    
    def __init__(self, api_key: Optional[str] = None):
        if not _COMPOSIO_AVAILABLE:
            raise RuntimeError("composio not installed. Run: pip install composio-core")
        import os
        self._api_key = api_key or os.environ.get("COMPOSIO_API_KEY", "")
        self._toolset = ComposioToolSet(api_key=self._api_key if self._api_key else None)
    
    def list_apps(self) -> list[dict]:
        """List available Composio apps/integrations."""
        try:
            apps = self._toolset.get_apps()
            return [{"name": app.name, "description": getattr(app, 'description', ''), 
                     "categories": getattr(app, 'categories', [])} for app in apps[:50]]
        except Exception as e:
            logger.error("Failed to list apps: %s", e)
            return []
    
    def list_actions(self, app_name: str = None) -> list[dict]:
        """List available actions, optionally filtered by app."""
        try:
            kwargs = {}
            if app_name:
                kwargs["apps"] = [app_name]
            actions = self._toolset.get_actions(**kwargs)
            return [{"name": a.name, "description": getattr(a, 'description', ''),
                     "app": getattr(a, 'app', '')} for a in actions[:50]]
        except Exception as e:
            logger.error("Failed to list actions: %s", e)
            return []
    
    def execute_action(self, action_name: str, params: dict = None) -> dict:
        """Execute a Composio action."""
        try:
            result = self._toolset.execute_action(
                action=action_name,
                params=params or {},
            )
            return {"success": True, "result": result, "error": None}
        except Exception as e:
            return {"success": False, "result": None, "error": str(e)}
    
    def get_tools_for_llm(self, apps: list[str] = None) -> list:
        """Get Composio tools formatted for LLM function calling."""
        try:
            kwargs = {}
            if apps:
                kwargs["apps"] = apps
            return self._toolset.get_tools(**kwargs)
        except Exception as e:
            logger.error("Failed to get tools: %s", e)
            return []


# Pre-defined useful app categories for SuperAgent
RECOMMENDED_APPS = {
    "dev": ["github", "gitlab", "linear", "jira"],
    "communication": ["slack", "discord", "gmail", "telegram"],
    "productivity": ["notion", "google_docs", "google_sheets", "trello"],
    "cloud": ["aws", "gcp", "vercel", "netlify"],
    "data": ["postgres", "mysql", "mongodb", "redis"],
}


def get_composio_bridge(api_key: Optional[str] = None) -> Optional[ComposioBridge]:
    """Get a ComposioBridge instance, or None if not available."""
    if not _COMPOSIO_AVAILABLE:
        return None
    try:
        return ComposioBridge(api_key)
    except Exception as e:
        logger.warning("Failed to initialize Composio: %s", e)
        return None
