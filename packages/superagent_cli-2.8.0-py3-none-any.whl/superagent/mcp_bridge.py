"""MCP (Model Context Protocol) server configuration and tool discovery bridge.

Manages a JSON registry of MCP servers with:
- Server configuration (command, args, env, enabled state)
- Built-in presets for common MCP servers (filesystem, fetch, git, memory, brave-search)
- Add/remove/enable/disable server management
- Persistent storage at ``~/.superagent/mcp/servers.json``
"""

from __future__ import annotations

import json
import os
import subprocess
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write


@dataclass
class MCPServerConfig:
    """Configuration for a single MCP server."""

    name: str
    command: str
    args: list[str] = field(default_factory=list)
    env: dict[str, str] = field(default_factory=dict)
    enabled: bool = True
    description: str = ""

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> MCPServerConfig:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# Built-in MCP server presets
# ---------------------------------------------------------------------------

BUILTIN_SERVERS: list[MCPServerConfig] = [
    MCPServerConfig(
        name="filesystem",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-filesystem", "/tmp"],
        description="MCP filesystem server — read/write files in /tmp.",
    ),
    MCPServerConfig(
        name="fetch",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-fetch"],
        description="MCP fetch server — retrieve web content.",
    ),
    MCPServerConfig(
        name="git",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-git"],
        description="MCP git server — interact with git repositories.",
    ),
    MCPServerConfig(
        name="memory",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-memory"],
        description="MCP memory server — persistent key-value memory.",
    ),
    MCPServerConfig(
        name="brave-search",
        command="npx",
        args=["-y", "@modelcontextprotocol/server-brave-search"],
        env={"BRAVE_API_KEY": "$BRAVE_API_KEY"},
        enabled=False,
        description="MCP Brave Search server — web search via Brave API (requires BRAVE_API_KEY).",
    ),
]


def _get_data_dir() -> Path:
    """Return the SuperAgent data directory (from env or default)."""
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


class MCPBridge:
    """Manages MCP server configurations persisted at ``<data_dir>/mcp/servers.json``."""

    def __init__(self, data_dir: Optional[str] = None):
        base = Path(data_dir) if data_dir else _get_data_dir()
        self._dir = base / "mcp"
        self._path = self._dir / "servers.json"
        self._servers: dict[str, MCPServerConfig] = {}
        self.load()

    # -- Persistence ---------------------------------------------------------

    def load(self) -> None:
        """Load server configs from disk, seeding built-in presets on first run."""
        if self._path.exists():
            try:
                data = json.loads(self._path.read_text(encoding="utf-8"))
                for item in data:
                    config = MCPServerConfig.from_dict(item)
                    self._servers[config.name] = config
            except (json.JSONDecodeError, TypeError):
                pass

        # Ensure all built-in presets are present (idempotent)
        changed = False
        for preset in BUILTIN_SERVERS:
            if preset.name not in self._servers:
                self._servers[preset.name] = MCPServerConfig(
                    name=preset.name,
                    command=preset.command,
                    args=list(preset.args),
                    env=dict(preset.env),
                    enabled=preset.enabled,
                    description=preset.description,
                )
                changed = True

        if changed:
            self.save()

    def save(self) -> None:
        """Persist all server configs to disk."""
        self._dir.mkdir(parents=True, exist_ok=True)
        data = [config.to_dict() for config in self._servers.values()]
        atomic_write(self._path, json.dumps(data, indent=2, ensure_ascii=False))

    # -- CRUD ----------------------------------------------------------------

    def add_server(self, config: MCPServerConfig) -> None:
        """Add or update an MCP server configuration."""
        self._servers[config.name] = config
        self.save()

    def remove_server(self, name: str) -> bool:
        """Remove a server by name. Returns True if it existed."""
        if name in self._servers:
            del self._servers[name]
            self.save()
            return True
        return False

    def get_server(self, name: str) -> Optional[MCPServerConfig]:
        """Get a server config by name."""
        return self._servers.get(name)

    def list_servers(self) -> list[MCPServerConfig]:
        """List all registered MCP servers, sorted by name."""
        return sorted(self._servers.values(), key=lambda s: s.name)

    # -- Enable / Disable ----------------------------------------------------

    def enable(self, name: str) -> bool:
        """Enable a server. Returns True if found."""
        server = self._servers.get(name)
        if server:
            server.enabled = True
            self.save()
            return True
        return False

    def disable(self, name: str) -> bool:
        """Disable a server. Returns True if found."""
        server = self._servers.get(name)
        if server:
            server.enabled = False
            self.save()
            return True
        return False


# ---------------------------------------------------------------------------
# Singleton accessor
# ---------------------------------------------------------------------------

_bridge_instance: Optional[MCPBridge] = None


def get_mcp_bridge(data_dir: Optional[str] = None) -> MCPBridge:
    """Get or create the singleton MCPBridge."""
    global _bridge_instance
    if _bridge_instance is None:
        _bridge_instance = MCPBridge(data_dir=data_dir)
    return _bridge_instance


# ---------------------------------------------------------------------------
# MCP Client — runtime protocol calls over stdio JSON-RPC
# ---------------------------------------------------------------------------

class MCPClient:
    """Simple MCP client that communicates with MCP servers via stdio JSON-RPC."""

    def __init__(self, server_config: MCPServerConfig):
        self.config = server_config
        self._process: Optional[subprocess.Popen] = None
        self._request_id = 0

    def start(self) -> None:
        """Start the MCP server subprocess."""
        env = os.environ.copy()
        env.update(self.config.env)
        cmd = [self.config.command] + self.config.args
        self._process = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            env=env,
        )

    def stop(self) -> None:
        """Stop the MCP server subprocess."""
        if self._process is not None:
            self._process.terminate()
            try:
                self._process.wait(timeout=5)
            except subprocess.TimeoutExpired:
                self._process.kill()
                self._process.wait()
            self._process = None

    def _send_jsonrpc(self, method: str, params: Optional[dict] = None) -> dict:
        """Send a JSON-RPC 2.0 request and read the response."""
        if self._process is None or self._process.stdin is None or self._process.stdout is None:
            raise RuntimeError("MCPClient is not started")

        self._request_id += 1
        request: dict = {
            "jsonrpc": "2.0",
            "id": self._request_id,
            "method": method,
        }
        if params is not None:
            request["params"] = params

        payload = json.dumps(request) + "\n"
        self._process.stdin.write(payload.encode())
        self._process.stdin.flush()

        line = self._process.stdout.readline()
        if not line:
            raise RuntimeError("No response from MCP server")
        return json.loads(line)

    def list_tools(self) -> list[dict]:
        """Send tools/list request, return list of tool definitions."""
        resp = self._send_jsonrpc("tools/list")
        return resp.get("result", {}).get("tools", [])

    def call_tool(self, tool_name: str, arguments: Optional[dict] = None) -> dict:
        """Send tools/call request."""
        resp = self._send_jsonrpc("tools/call", {"name": tool_name, "arguments": arguments or {}})
        return resp.get("result", {})
