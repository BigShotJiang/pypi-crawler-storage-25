"""SuperAgent Gateway — FastAPI HTTP server with REST API and Web UI.

Inspired by CodeBuddy CLI's ``--serve`` / ``daemon start`` and OpenClaw's
Gateway control plane.  Provides a unified HTTP API for all SuperAgent
operations, enabling Web UI, mobile control, CI/CD integration, and
external channel bridges.

Production-grade features (aligned with CodeBuddy CLI standards):
- **TLS/HTTPS**: Self-signed cert generation, Cloudflare Tunnel integration
- **Multi-user auth**: 3-tier (JWT > API Key > static password), RBAC
- **Data persistence**: SQLite-backed runs, transcripts, schema migration
- **Execution sandbox**: OS-level isolation (Seatbelt/bwrap)

Architecture::

    Browser/Mobile <-- HTTPS --> [Gateway FastAPI :7890]
                                       |
                                       |-- /api/v1/health
                                       |-- /api/v1/dashboard
                                       |-- /api/v1/runs (agent execution)
                                       |-- /api/v1/sessions
                                       |-- /api/v1/teams
                                       |-- /api/v1/agents
                                       |-- /api/v1/checkpoints
                                       |-- /api/v1/workers
                                       |-- /api/v1/fs (file operations)
                                       |-- /api/v1/channels
                                       |-- /api/v1/channels/webhook
                                       |-- /api/v1/settings
                                       |-- /api/v1/auth (login, users, api-keys)
                                       |-- /api/v1/sessions/{id}/transcript
                                       |-- /ws (real-time WebSocket)
                                       +-- / (Web UI SPA)
"""

# NOTE: Do NOT use `from __future__ import annotations` here.
# FastAPI requires runtime-resolvable type annotations for dependency injection.
# With `from __future__ import annotations`, all annotations become strings
# and FastAPI treats `request: Request` as a query parameter instead of
# injecting the HTTP request object.

import asyncio
import json
import logging
import os
import platform
import secrets
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

# FastAPI types MUST be imported at module level (not inside create_gateway_app)
# so that FastAPI can resolve type annotations at route registration time.
# Without this, `request: Request` gets treated as a query parameter.
from fastapi import Request as _FastAPIRequest
from fastapi import WebSocket as _FastAPIWebSocket
from fastapi import WebSocketDisconnect as _FastAPIWebSocketDisconnect
from fastapi.responses import JSONResponse as _FastAPIJSONResponse

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


def _data_dir() -> Path:
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", Path.home() / ".superagent"))


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------


@dataclass
class GatewayConfig:
    """Gateway server configuration."""

    host: str = "127.0.0.1"
    port: int = 7890
    auth: str = "password"  # "password", "jwt", or "none"
    password: Optional[str] = None
    cors_origins: list[str] = field(default_factory=list)
    max_connections: int = 10
    session_timeout: int = 86400  # 24 hours in seconds
    # TLS
    tls: Optional[Any] = None  # TLSConfig from tls.py
    tunnel: bool = False
    # Sandbox
    sandbox: bool = True

    def __post_init__(self):
        # Load saved config if available
        saved = self._load_saved_config()
        if saved:
            for k, v in saved.items():
                # Don't override auth/password from saved config — these are
                # runtime parameters set by CLI flags, not persistent settings
                if k in ('auth', 'password', 'tls'):
                    continue
                if hasattr(self, k) and getattr(self, k) in (None, [], 0, '127.0.0.1', 7890, 'password'):
                    setattr(self, k, v)
        if self.auth in ("password", "jwt") and not self.password:
            self.password = self._load_or_generate_password()

    def _load_or_generate_password(self) -> str:
        pw_dir = _data_dir() / "gateway"
        pw_dir.mkdir(parents=True, exist_ok=True)
        pw_file = pw_dir / "password.json"
        if pw_file.exists():
            try:
                data = json.loads(pw_file.read_text(encoding="utf-8"))
                return data.get("password", "")
            except (json.JSONDecodeError, OSError):
                pass
        pw = secrets.token_urlsafe(32)
        atomic_write(pw_file, json.dumps({"password": pw, "created_at": _now_iso()}))
        return pw

    def _load_saved_config(self) -> dict:
        cfg_file = _data_dir() / "gateway" / "config.json"
        if cfg_file.exists():
            try:
                return json.loads(cfg_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def save(self) -> None:
        """Persist configuration to disk."""
        cfg_dir = _data_dir() / "gateway"
        cfg_dir.mkdir(parents=True, exist_ok=True)
        cfg_file = cfg_dir / "config.json"
        data = {
            "host": self.host,
            "port": self.port,
            "auth": self.auth,
            "cors_origins": self.cors_origins,
            "max_connections": self.max_connections,
            "session_timeout": self.session_timeout,
            "sandbox": self.sandbox,
        }
        atomic_write(cfg_file, json.dumps(data, indent=2))


# ---------------------------------------------------------------------------
# Run Manager (SQLite-backed)
# ---------------------------------------------------------------------------


@dataclass
class Run:
    """An agent execution run."""

    runId: str
    text: str = ""
    sender: dict = field(default_factory=dict)
    user_id: str = ""
    status: str = "accepted"  # accepted | running | completed | failed | cancelled
    result: Optional[str] = None
    error: Optional[str] = None
    created_at: str = ""
    started_at: Optional[str] = None
    completed_at: Optional[str] = None
    process: Any = None  # In-memory only: active subprocess handle

    def to_dict(self) -> dict:
        return {
            "runId": self.runId,
            "text": self.text,
            "user_id": self.user_id,
            "status": self.status,
            "result": self.result,
            "error": self.error,
            "created_at": self.created_at,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


class RunManager:
    """Manages agent execution runs. Persisted to SQLite."""

    def __init__(self, db: sqlite3.Connection):
        self._db = db
        self._lock = asyncio.Lock()
        # In-memory only: active subprocess handles (not persisted)
        self._processes: dict[str, Any] = {}

    async def create(self, text: str, sender: dict | None = None, user_id: str = "") -> Run:
        run_id = uuid.uuid4().hex[:16]
        run = Run(
            runId=run_id,
            text=text,
            sender=sender or {},
            user_id=user_id,
            status="accepted",
            created_at=_now_iso(),
        )
        self._db.execute(
            """INSERT INTO runs (id, user_id, text, sender, status, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (run_id, user_id, text, json.dumps(sender or {}), "accepted", run.created_at),
        )
        self._db.commit()
        return run

    async def get(self, run_id: str) -> Optional[Run]:
        row = self._db.execute("SELECT * FROM runs WHERE id = ?", (run_id,)).fetchone()
        if row is None:
            return None
        run = Run(
            runId=row["id"], text=row["text"],
            sender=json.loads(row["sender"]) if row["sender"] else {},
            user_id=row["user_id"] or "",
            status=row["status"], result=row["result"],
            error=row["error"], created_at=row["created_at"],
            started_at=row["started_at"], completed_at=row["completed_at"],
        )
        # Attach live process if still running
        run.process = self._processes.get(run_id)
        return run

    async def list_runs(self, limit: int = 50, user_id: str | None = None) -> list[Run]:
        sql = "SELECT * FROM runs"
        params: list = []
        if user_id:
            sql += " WHERE user_id = ?"
            params.append(user_id)
        sql += " ORDER BY created_at DESC LIMIT ?"
        params.append(limit)
        rows = self._db.execute(sql, params).fetchall()
        return [Run(
            runId=r["id"], text=r["text"], user_id=r["user_id"] or "",
            status=r["status"], result=r["result"], error=r["error"],
            created_at=r["created_at"], started_at=r["started_at"],
            completed_at=r["completed_at"],
        ) for r in rows]

    async def update(self, run: Run) -> None:
        """Persist run state changes to DB."""
        self._db.execute(
            """UPDATE runs SET status=?, result=?, error=?, started_at=?, completed_at=?
               WHERE id=?""",
            (run.status, run.result, run.error, run.started_at, run.completed_at, run.runId),
        )
        self._db.commit()

    async def cancel(self, run_id: str) -> Optional[Run]:
        run = await self.get(run_id)
        if run is None:
            return None
        proc = self._processes.pop(run_id, None)
        if proc and proc.returncode is None:
            try:
                proc.terminate()
            except OSError:
                pass
        run.status = "cancelled"
        run.completed_at = _now_iso()
        await self.update(run)
        return run

    async def execute(self, run: Run, *, sandbox: bool = True) -> None:
        """Execute the run by spawning ``superagent auto`` in a subprocess."""
        import subprocess
        import sys

        run.status = "running"
        run.started_at = _now_iso()
        await self.update(run)

        try:
            cmd = [sys.executable, "-m", "superagent", "auto", run.text]

            if sandbox:
                try:
                    from superagent.sandbox_native import NativeSandbox, SandboxProfile
                    work_dir = os.getcwd()
                    profile = SandboxProfile.default(work_dir)
                    ns = NativeSandbox(profile)
                    result = ns.execute_shell(
                        " ".join(cmd),
                        timeout=600,
                        working_dir=work_dir,
                    )
                    if run.status == "cancelled":
                        return
                    run.result = result.get("stdout", "")[-5000:]
                    if result["success"]:
                        run.status = "completed"
                    else:
                        run.status = "failed"
                        run.error = result.get("stderr", "Run failed")[:3000]
                    return
                except Exception as exc:
                    logger.warning("Sandbox execution failed, falling back: %s", exc)

            # Unsandboxed fallback
            proc = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.STDOUT,
                text=True,
                cwd=os.getcwd(),
                env={**os.environ},
            )
            self._processes[run.runId] = proc
            run.process = proc

            stdout, _ = await asyncio.get_event_loop().run_in_executor(
                None, proc.communicate
            )
            self._processes.pop(run.runId, None)

            if run.status == "cancelled":
                return

            if proc.returncode == 0:
                run.status = "completed"
                run.result = stdout[-5000:] if stdout else "Task completed."
            else:
                run.status = "failed"
                run.error = stdout[-3000:] if stdout else f"Process exited with code {proc.returncode}"

        except Exception as exc:
            run.status = "failed"
            run.error = str(exc)
            logger.error("Run %s failed: %s", run.runId, exc)
        finally:
            run.completed_at = _now_iso()
            run.process = None
            await self.update(run)


# ---------------------------------------------------------------------------
# Gateway App Factory
# ---------------------------------------------------------------------------


def create_gateway_app(config: GatewayConfig | None = None) -> Any:
    """Create and return a FastAPI application for the Gateway.

    This function is designed to be called from ``gateway_cli.py`` and
    gracefully handles the case where FastAPI is not installed.
    """
    try:
        from fastapi import FastAPI
        from fastapi.middleware.cors import CORSMiddleware
        from fastapi.responses import (
            HTMLResponse,
            StreamingResponse,
        )
        # Use module-level imports for Request, WebSocket, etc.
        Request = _FastAPIRequest
        WebSocket = _FastAPIWebSocket
        WebSocketDisconnect = _FastAPIWebSocketDisconnect
        JSONResponse = _FastAPIJSONResponse
    except ImportError:
        raise ImportError(
            "FastAPI is required for the Gateway. "
            "Install with: pip install fastapi 'uvicorn[standard]'"
        )

    if config is None:
        config = GatewayConfig()

    app = FastAPI(
        title="SuperAgent Gateway",
        version="2.8.0",
        docs_url="/api/docs",
        openapi_url="/api/openapi.json",
    )

    # CORS
    cors_origins = config.cors_origins or ["*"]
    app.add_middleware(
        CORSMiddleware,
        allow_origins=cors_origins,
        allow_credentials=True,
        allow_methods=["*"],
        allow_headers=["*"],
    )

    # State
    from superagent.db import get_db
    db = get_db()
    run_manager = RunManager(db)
    start_time = time.time()
    ws_clients: list[Any] = []

    # Auth manager (lazy-init to avoid import issues if passlib not installed)
    auth_manager: Any = None

    def _get_auth_manager():
        nonlocal auth_manager
        if auth_manager is None:
            try:
                from superagent.auth import get_auth_manager
                auth_manager = get_auth_manager(db)
            except Exception:
                pass
        return auth_manager

    # ── Auth middleware (3-tier: JWT > API Key > static password) ──
    @app.middleware("http")
    async def auth_middleware(request: Request, call_next):
        # Skip auth for health, docs, openapi, static, and login endpoint
        skip_paths = {
            "/api/v1/health", "/api/docs", "/api/openapi.json", "/",
            "/api/v1/auth/login", "/api/v1/auth/status",
        }
        if request.url.path in skip_paths:
            return await call_next(request)

        if config.auth == "none":
            # In no-auth mode, set a default admin user for RBAC checks
            request.state.user = {"user_id": "anonymous", "role": "admin"}
            return await call_next(request)

        # Per-IP rate limiting
        am = _get_auth_manager()
        client_ip = request.client.host if request.client else "unknown"
        if am and not am.check_rate_limit(client_ip):
            return JSONResponse(status_code=429, content={"error": {"code": "RATE_LIMITED", "message": "Too many requests"}})
        if am:
            am.record_request(client_ip)

        # 3-tier authentication
        auth_result = _authenticate_request(request, config, am)

        if auth_result is None:
            return JSONResponse(
                status_code=401,
                content={"error": {"code": "AUTH_REQUIRED", "message": "Authentication required"}},
            )

        # Attach user info to request state
        request.state.user = auth_result
        return await call_next(request)

    # ── Helpers ──
    def _success(data: Any = None) -> dict:
        return {"data": data}

    def _error(code: str, message: str, status: int = 400) -> JSONResponse:
        return JSONResponse(status_code=status, content={"error": {"code": code, "message": message}})

    def _require_role(request: Request, *roles: str) -> Optional[JSONResponse]:
        """Check if the authenticated user has one of the required roles."""
        user = getattr(request.state, "user", None)
        if user is None:
            return _error("AUTH_REQUIRED", "Authentication required", 401)
        role = user.get("role", "")
        if role in roles or role == "admin":
            return None  # admin can do anything
        return _error("FORBIDDEN", "Insufficient permissions", 403)

    async def _broadcast(event: dict):
        dead = []
        for i, ws in enumerate(ws_clients):
            try:
                await ws.send_json(event)
            except Exception:
                dead.append(i)
        for i in reversed(dead):
            ws_clients.pop(i)

    # ════════════════════════════════════════════════════════════════════
    # REST API Endpoints
    # ════════════════════════════════════════════════════════════════════

    # ── System ──

    @app.get("/api/v1/health")
    async def health():
        return _success({"status": "ok", "uptime": time.time() - start_time})

    @app.get("/api/v1/info")
    async def info():
        from superagent import __version__
        return _success({
            "version": __version__,
            "platform": platform.system(),
            "hostname": platform.node(),
            "cwd": os.getcwd(),
            "uptime": time.time() - start_time,
        })

    @app.get("/api/v1/metrics")
    async def metrics():
        import resource
        rusage = resource.getrusage(resource.RUSAGE_SELF)
        return _success({
            "ts": time.time(),
            "cpu_used_pct": 0,
            "mem_total_mib": 0,
            "mem_used_mib": rusage.ru_maxrss / 1024 if hasattr(rusage, "ru_maxrss") else 0,
            "instances": [],
        })

    # ── Dashboard ──

    @app.get("/api/v1/dashboard")
    async def dashboard():
        """Consolidated system state for dashboard overview."""
        health_data = {"status": "ok", "uptime": time.time() - start_time}

        data_dir = _data_dir()
        teams = []
        teams_dir = data_dir / "teams"
        if teams_dir.exists():
            for d in teams_dir.iterdir():
                if d.is_dir():
                    registry = d / "spawn_registry.json"
                    info = {"name": d.name, "status": "unknown", "agents": []}
                    if registry.exists():
                        try:
                            info = json.loads(registry.read_text(encoding="utf-8"))
                            info["name"] = d.name
                        except (json.JSONDecodeError, OSError):
                            pass
                    teams.append(info)

        agent_count = sum(len(t.get("agents", [])) for t in teams)
        runs = await run_manager.list_runs(limit=5)

        workers_count = 0
        try:
            from superagent.worker_manager import WorkerManager
            wm = WorkerManager()
            workers_count = len(wm.list_workers())
        except Exception:
            pass

        channels_count = 0
        try:
            from superagent.channel_bridge import get_channel_bridge
            bridge = get_channel_bridge()
            channels_count = len(bridge.list_channels())
        except Exception:
            pass

        checkpoints_count = 0
        try:
            from superagent.checkpoint_system import get_checkpoint_manager
            mgr = get_checkpoint_manager()
            checkpoints_count = len(mgr.list_checkpoints())
        except Exception:
            pass

        return _success({
            "health": health_data,
            "teams": teams,
            "agent_count": agent_count,
            "recent_runs": [r.to_dict() for r in runs],
            "workers_count": workers_count,
            "channels_count": channels_count,
            "checkpoints_count": checkpoints_count,
        })

    # ── Auth ──

    @app.get("/api/v1/auth/status")
    async def auth_status():
        return _success({"mode": config.auth, "authenticated": config.auth == "none"})

    @app.post("/api/v1/auth/login")
    async def auth_login(request: Request):
        body = await request.json()

        # Try multi-user login first
        am = _get_auth_manager()
        if am:
            username = body.get("username", "")
            password = body.get("password", "")
            if username:
                user = am.authenticate(username, password)
                if user:
                    session = am.create_session(user, ttl=config.session_timeout)
                    return _success({
                        "token": session.token,
                        "ttl": session.ttl,
                        "user": user.to_dict(),
                    })
                # Failed user login — rate limit
                return _error("AUTH_INVALID", "Invalid username or password", 401)

        # Legacy: static password login
        pw = body.get("password", "")
        if config.auth == "password" and pw == config.password:
            # Create a legacy session if auth manager available
            if am:
                from superagent.auth import Role
                session = am.create_session(
                    type("LegacyUser", (), {"id": "legacy", "username": "legacy", "role": Role.admin, "is_active": True})(),
                    ttl=config.session_timeout,
                )
                return _success({"token": session.token, "ttl": session.ttl, "user": {"id": "legacy", "username": "legacy", "role": "admin"}})
            return _success({"token": config.password, "ttl": config.session_timeout})
        if not am:
            return _error("AUTH_INVALID", "Invalid password", 401)
        return _error("AUTH_INVALID", "Invalid credentials", 401)

    @app.post("/api/v1/auth/logout")
    async def auth_logout(request: Request):
        auth_header = request.headers.get("authorization", "")
        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            am = _get_auth_manager()
            if am:
                am.revoke_session(token)
        return _success({"logged_out": True})

    @app.get("/api/v1/auth/users")
    async def list_users(request: Request):
        denied = _require_role(request, "admin")
        if denied:
            return denied
        am = _get_auth_manager()
        if not am:
            return _success([])
        return _success([u.to_dict() for u in am.list_users()])

    @app.post("/api/v1/auth/users")
    async def create_user(request: Request):
        denied = _require_role(request, "admin")
        if denied:
            return denied
        am = _get_auth_manager()
        if not am:
            return _error("NOT_AVAILABLE", "Auth system not available", 501)
        body = await request.json()
        username = body.get("username", "")
        password = body.get("password", "")
        role = body.get("role", "user")
        if not username or not password:
            return _error("BAD_REQUEST", "username and password are required")
        from superagent.auth import Role
        try:
            role_enum = Role(role)
        except ValueError:
            return _error("BAD_REQUEST", f"Invalid role: {role}")
        if am.get_user_by_username(username):
            return _error("CONFLICT", f"User '{username}' already exists", 409)
        user = am.create_user(username, password, role_enum)
        return _success(user.to_dict())

    @app.post("/api/v1/auth/api-keys")
    async def create_api_key(request: Request):
        denied = _require_role(request, "admin", "user")
        if denied:
            return denied
        am = _get_auth_manager()
        if not am:
            return _error("NOT_AVAILABLE", "Auth system not available", 501)
        body = await request.json()
        name = body.get("name", "")
        role = body.get("role", "user")
        from superagent.auth import Role
        try:
            role_enum = Role(role)
        except ValueError:
            return _error("BAD_REQUEST", f"Invalid role: {role}")
        user = getattr(request.state, "user", {})
        user_id = user.get("user_id", "")
        api_key, raw_key = am.create_api_key(user_id, name, role_enum)
        return _success({"api_key": api_key.to_dict(), "key": raw_key})

    @app.get("/api/v1/auth/api-keys")
    async def list_api_keys(request: Request):
        am = _get_auth_manager()
        if not am:
            return _success([])
        user = getattr(request.state, "user", {})
        user_id = user.get("user_id", "")
        return _success([k.to_dict() for k in am.list_api_keys(user_id)])

    @app.delete("/api/v1/auth/api-keys/{key_id}")
    async def revoke_api_key(key_id: str, request: Request):
        am = _get_auth_manager()
        if not am:
            return _error("NOT_AVAILABLE", "Auth system not available", 501)
        success = am.revoke_api_key(key_id)
        return _success({"revoked": success})

    # ── Runs ──

    @app.post("/api/v1/runs")
    async def create_run(request: Request):
        body = await request.json()
        text = body.get("text", "")
        sender = body.get("sender", {})
        if not text:
            return _error("BAD_REQUEST", "text field is required")

        user = getattr(request.state, "user", {})
        user_id = user.get("user_id", "")

        run = await run_manager.create(text, sender, user_id)
        asyncio.create_task(run_manager.execute(run, sandbox=config.sandbox))
        return _success(run.to_dict())

    @app.get("/api/v1/runs")
    async def list_runs(request: Request):
        user = getattr(request.state, "user", {})
        user_id = user.get("user_id", "")
        # Admin can see all runs; others see their own
        if user.get("role") == "admin":
            user_id = None
        runs = await run_manager.list_runs(user_id=user_id)
        return _success([r.to_dict() for r in runs])

    @app.get("/api/v1/runs/{run_id}")
    async def get_run(run_id: str):
        run = await run_manager.get(run_id)
        if run is None:
            return _error("RUN_NOT_FOUND", f"Run {run_id} not found", 404)
        return _success(run.to_dict())

    @app.get("/api/v1/runs/{run_id}/stream")
    async def stream_run(run_id: str):
        run = await run_manager.get(run_id)
        if run is None:
            return _error("RUN_NOT_FOUND", f"Run {run_id} not found", 404)

        async def event_stream():
            while True:
                run = await run_manager.get(run_id)
                if run is None:
                    break
                yield f"data: {json.dumps(run.to_dict())}\n\n"
                if run.status in ("completed", "failed", "cancelled"):
                    yield f"data: {json.dumps({'type': 'done', 'result': run.result, 'error': run.error})}\n\n"
                    break
                await asyncio.sleep(1)

        return StreamingResponse(event_stream(), media_type="text/event-stream")

    @app.post("/api/v1/runs/{run_id}/cancel")
    async def cancel_run(run_id: str):
        run = await run_manager.cancel(run_id)
        if run is None:
            return _error("RUN_NOT_FOUND", f"Run {run_id} not found", 404)
        return _success(run.to_dict())

    # ── Sessions ──

    @app.get("/api/v1/sessions")
    async def list_sessions():
        data_dir = _data_dir()
        sessions = []
        projects_dir = data_dir / "projects"
        if projects_dir.exists():
            for d in projects_dir.iterdir():
                if d.is_dir():
                    sessions.append({"id": d.name, "cwd": d.name})
        return _success(sessions)

    @app.delete("/api/v1/sessions/{session_id}")
    async def delete_session(session_id: str):
        data_dir = _data_dir()
        session_dir = data_dir / "projects" / session_id
        if session_dir.exists():
            import shutil
            shutil.rmtree(session_dir, ignore_errors=True)
        return _success({"deleted": session_id})

    # ── Transcripts ──

    @app.post("/api/v1/sessions/{session_id}/transcript")
    async def add_transcript(session_id: str, request: Request):
        body = await request.json()
        user = getattr(request.state, "user", {})
        user_id = user.get("user_id", "")
        db.execute(
            """INSERT INTO transcripts (session_id, user_id, role, content, metadata, created_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (session_id, user_id, body.get("role", "user"),
             body.get("content", ""), json.dumps(body.get("metadata", {})), _now_iso()),
        )
        db.commit()
        return _success({"recorded": True})

    @app.get("/api/v1/sessions/{session_id}/transcript")
    async def get_transcript(session_id: str, limit: int = 200):
        rows = db.execute(
            "SELECT * FROM transcripts WHERE session_id = ? ORDER BY id DESC LIMIT ?",
            (session_id, limit),
        ).fetchall()
        return _success([dict(r) for r in reversed(rows)])

    # ── Teams ──

    @app.get("/api/v1/teams")
    async def list_teams():
        data_dir = _data_dir()
        teams = []
        teams_dir = data_dir / "teams"
        if teams_dir.exists():
            for d in teams_dir.iterdir():
                if d.is_dir():
                    registry = d / "spawn_registry.json"
                    info = {"name": d.name, "status": "unknown", "agents": []}
                    if registry.exists():
                        try:
                            info = json.loads(registry.read_text(encoding="utf-8"))
                            info["name"] = d.name
                        except (json.JSONDecodeError, OSError):
                            pass
                    teams.append(info)
        return _success(teams)

    @app.get("/api/v1/teams/{team_name}")
    async def get_team(team_name: str):
        data_dir = _data_dir()
        team_dir = data_dir / "teams" / team_name
        if not team_dir.exists():
            return _error("NOT_FOUND", f"Team {team_name} not found", 404)
        registry = team_dir / "spawn_registry.json"
        info = {"name": team_name, "status": "unknown", "agents": []}
        if registry.exists():
            try:
                info = json.loads(registry.read_text(encoding="utf-8"))
                info["name"] = team_name
            except (json.JSONDecodeError, OSError):
                pass
        tasks_dir = team_dir / "tasks"
        if tasks_dir.exists():
            task_counts = {"completed": 0, "in_progress": 0, "pending": 0, "blocked": 0}
            for tf in tasks_dir.glob("*.json"):
                try:
                    td = json.loads(tf.read_text(encoding="utf-8"))
                    status = td.get("status", "pending")
                    if status in task_counts:
                        task_counts[status] += 1
                except (json.JSONDecodeError, OSError):
                    pass
            info["task_counts"] = task_counts
        return _success(info)

    # ── Agents ──

    @app.get("/api/v1/agents")
    async def list_agents():
        data_dir = _data_dir()
        agents = []
        teams_dir = data_dir / "teams"
        if teams_dir.exists():
            for d in teams_dir.iterdir():
                if d.is_dir():
                    registry = d / "spawn_registry.json"
                    if registry.exists():
                        try:
                            data = json.loads(registry.read_text(encoding="utf-8"))
                            for agent in data.get("agents", []):
                                agent["team"] = d.name
                                agents.append(agent)
                        except (json.JSONDecodeError, OSError):
                            pass
        return _success(agents)

    # ── Checkpoints (Rewind) ──

    @app.get("/api/v1/checkpoints")
    async def list_checkpoints(session_id: str | None = None):
        from superagent.checkpoint_system import get_checkpoint_manager
        mgr = get_checkpoint_manager()
        cps = mgr.list_checkpoints(session_id=session_id)
        return _success([{
            "id": cp.id, "session_id": cp.session_id,
            "agent_name": cp.agent_name, "timestamp": cp.timestamp,
            "description": cp.description, "files_changed": cp.files_changed,
            "additions": cp.additions, "deletions": cp.deletions,
        } for cp in cps])

    @app.get("/api/v1/checkpoints/{checkpoint_id}")
    async def get_checkpoint(checkpoint_id: str):
        from superagent.checkpoint_system import get_checkpoint_manager
        mgr = get_checkpoint_manager()
        cp = mgr.get_checkpoint(checkpoint_id)
        if cp is None:
            return _error("NOT_FOUND", f"Checkpoint {checkpoint_id} not found", 404)
        return _success({
            "id": cp.id, "session_id": cp.session_id,
            "agent_name": cp.agent_name, "timestamp": cp.timestamp,
            "description": cp.description, "files_changed": cp.files_changed,
            "additions": cp.additions, "deletions": cp.deletions,
        })

    @app.get("/api/v1/checkpoints/{checkpoint_id}/diff")
    async def get_checkpoint_diff(checkpoint_id: str, path: str):
        from superagent.checkpoint_system import get_checkpoint_manager
        mgr = get_checkpoint_manager()
        diff = mgr.get_diff(checkpoint_id, path)
        if diff is None:
            return _error("NOT_FOUND", "Checkpoint or file not found", 404)
        return _success(diff)

    @app.post("/api/v1/checkpoints/{checkpoint_id}/revert")
    async def revert_checkpoint(checkpoint_id: str, request: Request):
        from superagent.checkpoint_system import get_checkpoint_manager
        mgr = get_checkpoint_manager()
        body = await request.json() if request.headers.get("content-type") else {}
        scope = body.get("scope", "Code")
        paths = body.get("paths")
        if scope == "CodeAndConversation":
            result = mgr.revert_all(checkpoint_id)
        else:
            result = mgr.revert_code(checkpoint_id, paths)
        if not result.get("success"):
            return _error("BAD_REQUEST", "; ".join(result.get("errors", ["Revert failed"])))
        return _success(result)

    # ── Workers ──

    @app.get("/api/v1/workers")
    async def list_workers(kind: str | None = None):
        try:
            from superagent.worker_manager import WorkerManager
            wm = WorkerManager()
            workers = wm.list_workers(kind=kind)
            return _success([w.to_dict() for w in workers])
        except Exception:
            return _success([])

    @app.get("/api/v1/workers/{worker_id}/logs")
    async def worker_logs(worker_id: str, type: str | None = None, tail: int = 200):
        try:
            from superagent.worker_manager import WorkerManager
            wm = WorkerManager()
            logs = wm.get_worker_logs(worker_id, log_type=type, tail=tail)
            return _success({"logs": logs})
        except Exception:
            return _success({"logs": ""})

    @app.delete("/api/v1/workers/{worker_id}")
    async def kill_worker(worker_id: str):
        try:
            from superagent.worker_manager import WorkerManager
            wm = WorkerManager()
            success = wm.kill_worker(worker_id)
            return _success({"killed": success})
        except Exception:
            return _error("INTERNAL_ERROR", "Failed to kill worker")

    # ── Daemon ──

    @app.get("/api/v1/daemon/status")
    async def daemon_status():
        try:
            from superagent.worker_manager import WorkerManager
            wm = WorkerManager()
            return _success(wm.daemon_status() or {"status": "not_running"})
        except Exception:
            return _success({"status": "not_running"})

    # ── File System ──

    @app.get("/api/v1/fs/search")
    async def fs_search(query: str, limit: int = 20):
        import subprocess
        try:
            result = subprocess.run(
                ["rg", "-l", query, os.getcwd(), "--max-count", str(limit)],
                capture_output=True, text=True, timeout=10,
            )
            files = result.stdout.strip().split("\n") if result.stdout.strip() else []
            return _success({"files": files, "query": query})
        except FileNotFoundError:
            return _error("BAD_REQUEST", "ripgrep (rg) not installed")
        except subprocess.TimeoutExpired:
            return _error("BAD_REQUEST", "Search timed out")

    @app.post("/api/v1/fs/list")
    async def fs_list(request: Request):
        body = await request.json()
        path = body.get("path", os.getcwd())
        try:
            p = Path(path)
            if not p.is_dir():
                return _error("PATH_NOT_DIRECTORY", f"{path} is not a directory")
            entries = []
            for child in sorted(p.iterdir()):
                entries.append({
                    "name": child.name,
                    "path": str(child),
                    "is_dir": child.is_dir(),
                    "size": child.stat().st_size if child.is_file() else 0,
                })
            return _success(entries)
        except OSError as exc:
            return _error("BAD_REQUEST", str(exc))

    @app.get("/api/v1/fs/download")
    async def fs_download(path: str):
        from fastapi.responses import FileResponse
        p = Path(path)
        if not p.is_file():
            return _error("NOT_FOUND", f"File {path} not found", 404)
        return FileResponse(str(p), filename=p.name)

    # ── Channels ──

    @app.get("/api/v1/channels")
    async def list_channels():
        try:
            from superagent.channel_bridge import get_channel_bridge
            bridge = get_channel_bridge()
            channels = bridge.list_channels()
            return _success(channels)
        except ImportError:
            return _success([])
        except Exception as exc:
            logger.warning("Failed to list channels: %s", exc)
            return _success([])

    @app.get("/api/v1/channels/webhook/{platform}")
    async def webhook_verify(platform: str):
        return _success({"platform": platform, "status": "ok"})

    @app.post("/api/v1/channels/webhook/{platform}")
    async def webhook_receive(platform: str, request: Request):
        body = await request.json() if request.headers.get("content-type", "").startswith("application/json") else {}
        query = dict(request.query_params)
        logger.info("Webhook received from %s: %s", platform, str(body)[:200])

        try:
            from superagent.channel_bridge import get_channel_bridge
            bridge = get_channel_bridge()
            msg = bridge.handle_webhook(platform, body, query)
            if msg is None:
                return _success({"received": True, "status": "verification_or_empty"})
            if msg.reply_text:
                return JSONResponse({
                    "data": {"received": True, "pairing_required": True,
                             "sender_id": msg.sender_id, "message": msg.reply_text}
                }, status_code=403)
            text = msg.content
            if text:
                run = await run_manager.create(text, {"platform": platform, "sender_id": msg.sender_id})
                asyncio.create_task(run_manager.execute(run, sandbox=config.sandbox))
                await _broadcast({"type": "data_changed", "source": f"webhook:{platform}"})
            return _success({"received": True, "sender": msg.sender_id})
        except ImportError:
            pass
        except Exception as exc:
            logger.warning("ChannelBridge error, falling back: %s", exc)

        text = body.get("text", body.get("content", ""))
        if text:
            run = await run_manager.create(text, {"platform": platform, "sender": body.get("sender", {})})
            asyncio.create_task(run_manager.execute(run, sandbox=config.sandbox))
            await _broadcast({"type": "data_changed", "source": f"webhook:{platform}"})
        return _success({"received": True})

    @app.post("/api/v1/channels/{channel_type}/{channel_id}/approve")
    async def approve_channel_sender(channel_type: str, channel_id: str, request: Request):
        body = await request.json()
        code = body.get("code", "")
        if not code:
            return _error("BAD_REQUEST", "Pairing code required")
        try:
            from superagent.channel_bridge import get_channel_bridge
            bridge = get_channel_bridge()
            sender_id = bridge.approve_sender(code)
            if sender_id is None:
                return _error("BAD_REQUEST", "Invalid or expired pairing code")
            return _success({"approved": True, "channel_id": channel_id, "sender_id": sender_id})
        except ImportError:
            return _error("NOT_IMPLEMENTED", "ChannelBridge not available", 501)

    # ── Settings ──

    @app.get("/api/v1/settings")
    async def list_settings():
        data_dir = _data_dir()
        settings_file = data_dir / "gateway" / "config.json"
        if settings_file.exists():
            try:
                return _success(json.loads(settings_file.read_text(encoding="utf-8")))
            except (json.JSONDecodeError, OSError):
                pass
        return _success({})

    @app.put("/api/v1/settings/{key}")
    async def set_setting(key: str, request: Request):
        denied = _require_role(request, "admin")
        if denied:
            return denied
        body = await request.json()
        value = body.get("value")
        data_dir = _data_dir()
        settings_dir = data_dir / "gateway"
        settings_dir.mkdir(parents=True, exist_ok=True)
        settings_file = settings_dir / "config.json"
        settings = {}
        if settings_file.exists():
            try:
                settings = json.loads(settings_file.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        settings[key] = value
        atomic_write(settings_file, json.dumps(settings, indent=2))
        return _success({key: value})

    # ════════════════════════════════════════════════════════════════════
    # WebSocket
    # ════════════════════════════════════════════════════════════════════

    @app.websocket("/ws")
    async def websocket_endpoint(websocket: WebSocket):
        # Authenticate WebSocket via query param token
        if config.auth != "none":
            token = websocket.query_params.get("token")
            if not token:
                await websocket.close(code=4001, reason="Authentication required")
                return
            # Validate JWT or API key
            am = _get_auth_manager()
            if am:
                session = am.validate_session(token)
                api_key = am.validate_api_key(token) if token.startswith("sa_") else None
                if not session and not api_key:
                    await websocket.close(code=4001, reason="Invalid token")
                    return
            elif token != config.password:
                await websocket.close(code=4001, reason="Invalid token")
                return

        await websocket.accept()
        ws_clients.append(websocket)
        try:
            while True:
                data = await websocket.receive_text()
                try:
                    msg = json.loads(data)
                    if msg.get("type") == "chat":
                        text = msg.get("text", "")
                        if text:
                            run = await run_manager.create(text, {"sender": {"id": "ws", "name": "WebSocket"}})
                            asyncio.create_task(run_manager.execute(run, sandbox=config.sandbox))
                except json.JSONDecodeError:
                    pass
        except WebSocketDisconnect:
            pass
        except Exception:
            pass
        finally:
            if websocket in ws_clients:
                ws_clients.remove(websocket)

    # ════════════════════════════════════════════════════════════════════
    # Web UI
    # ════════════════════════════════════════════════════════════════════

    @app.get("/", response_class=HTMLResponse)
    async def web_ui():
        from superagent.gateway_webui import get_html
        return HTMLResponse(content=get_html())

    return app


# ---------------------------------------------------------------------------
# 3-tier auth helper
# ---------------------------------------------------------------------------


def _authenticate_request(request: Any, config: GatewayConfig, auth_manager: Any) -> Optional[dict]:
    """3-tier authentication: JWT Bearer > API Key > static password.

    Returns ``{"user_id": ..., "role": ...}`` on success, ``None`` on failure.

    Aligned with CodeBuddy CLI's priority order:
    1. ``Authorization: Bearer <jwt>`` — JWT session token
    2. ``Authorization: Bearer sa_...`` or ``X-API-Key: sa_...`` — API key
    3. ``?password=...`` — static password (backward compat)
    """
    auth_header = request.headers.get("authorization", "")

    # Tier 1: JWT Bearer token
    if auth_header.startswith("Bearer "):
        token = auth_header[7:]

        if auth_manager:
            # Try JWT session
            session = auth_manager.validate_session(token)
            if session and not session.is_expired:
                return {"user_id": session.user_id, "role": session.role.value}

            # Tier 2: API key in Bearer header (sa_ prefix)
            if token.startswith("sa_"):
                api_key = auth_manager.validate_api_key(token)
                if api_key:
                    return {"user_id": api_key.user_id, "role": api_key.role.value}

    # Tier 2 alt: API key in X-API-Key header
    api_key_header = request.headers.get("x-api-key", "")
    if api_key_header.startswith("sa_") and auth_manager:
        api_key = auth_manager.validate_api_key(api_key_header)
        if api_key:
            return {"user_id": api_key.user_id, "role": api_key.role.value}

    # Tier 3: Static password (backward compat)
    if config.password:
        pw = None
        if auth_header.startswith("Bearer "):
            pw = auth_header[7:]
        elif "password" in request.query_params:
            pw = request.query_params["password"]
        if pw == config.password:
            return {"user_id": "legacy", "role": "admin"}

    return None


# ---------------------------------------------------------------------------
# Server runner
# ---------------------------------------------------------------------------


def run_server(config: GatewayConfig) -> None:
    """Start the Gateway HTTP server (blocking).

    This is the main entry point called by ``superagent serve``.
    """
    import uvicorn

    app = create_gateway_app(config)

    # Ensure admin user exists — use config.password so admin and
    # legacy password auth share the same credential
    try:
        from superagent.auth import get_auth_manager
        am = get_auth_manager()
        admin_user = am.get_user_by_username("admin")
        if admin_user is None:
            # Create admin with the same password as the gateway static password
            admin_pw = config.password or secrets.token_urlsafe(16)
            am.create_user("admin", admin_pw, __import__("superagent.auth", fromlist=["Role"]).Role.admin)
            logger.warning(
                "Default admin created — username: admin, password: %s  "
                "(CHANGE THIS IMMEDIATELY!)", admin_pw,
            )
    except Exception:
        pass  # Auth not available (missing passlib)

    # TLS configuration
    ssl_kwargs = {}
    if config.tls:
        from superagent.tls import TLSConfig, get_or_generate_cert

        if config.tls.enabled:
            ssl_kwargs = {
                "ssl_certfile": config.tls.cert_file,
                "ssl_keyfile": config.tls.key_file,
            }
        else:
            # Auto-generate self-signed cert
            cert, key = get_or_generate_cert(_data_dir())
            ssl_kwargs = {"ssl_certfile": cert, "ssl_keyfile": key}

    scheme = "https" if ssl_kwargs else "http"

    # Start Cloudflare Tunnel if requested
    tunnel_proc = None
    if config.tunnel:
        from superagent.tls import start_cloudflare_tunnel
        tunnel_proc = start_cloudflare_tunnel(config.port)

    logger.info(
        "Starting SuperAgent Gateway on %s://%s:%d (auth=%s, sandbox=%s)",
        scheme, config.host, config.port, config.auth, config.sandbox,
    )
    try:
        uvicorn.run(app, host=config.host, port=config.port, log_level="info", **ssl_kwargs)
    finally:
        if tunnel_proc and tunnel_proc.poll() is None:
            tunnel_proc.terminate()
