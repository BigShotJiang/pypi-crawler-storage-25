"""SuperAgent Python SDK — programmatic access to SuperAgent.

Inspired by CodeBuddy Code's Agent SDK:
- query() async streaming API for single-turn queries
- SuperAgentClient for multi-turn conversations
- canUseTool callback for permission control
- Hook system integration
- Session management (resume/continue)

Usage:
    from superagent.sdk import query, SuperAgentClient

    # Single-turn query
    async for msg in query(prompt="Analyze this code"):
        print(msg)

    # Multi-turn conversation
    async with SuperAgentClient() as client:
        await client.send("First question")
        async for msg in client.stream():
            print(msg)

        await client.send("Follow-up question")
        async for msg in client.stream():
            print(msg)
"""

from __future__ import annotations

import asyncio
import json
import uuid
from dataclasses import dataclass, field
from enum import Enum
from typing import AsyncIterator, Callable, Optional


# ---------------------------------------------------------------------------
# Message types
# ---------------------------------------------------------------------------

class MessageType(str, Enum):
    SYSTEM = "system"
    ASSISTANT = "assistant"
    TOOL_USE = "tool_use"
    TOOL_RESULT = "tool_result"
    RESULT = "result"


@dataclass
class TextBlock:
    type: str = "text"
    text: str = ""


@dataclass
class ToolUseBlock:
    type: str = "tool_use"
    name: str = ""
    input: dict = field(default_factory=dict)


@dataclass
class ToolResultBlock:
    type: str = "tool_result"
    content: str = ""


@dataclass
class SystemMessage:
    """Session initialization message."""
    type: str = "system"
    session_id: str = ""
    tools: list[str] = field(default_factory=list)
    data: dict = field(default_factory=dict)


@dataclass
class AssistantMessage:
    """AI assistant response."""
    type: str = "assistant"
    content: list = field(default_factory=list)  # list of TextBlock/ToolUseBlock/ToolResultBlock


@dataclass
class ResultMessage:
    """Query completion message."""
    type: str = "result"
    subtype: str = "success"  # success | error
    duration_ms: int = 0
    total_cost_usd: float = 0.0
    session_id: str = ""


# ---------------------------------------------------------------------------
# Permission control
# ---------------------------------------------------------------------------

@dataclass
class PermissionResultAllow:
    behavior: str = "allow"
    updated_input: Optional[dict] = None


@dataclass
class PermissionResultDeny:
    behavior: str = "deny"
    message: str = ""
    interrupt: bool = False


# Type alias for the permission callback
CanUseToolCallback = Callable[[str, dict, Optional[dict]], PermissionResultAllow | PermissionResultDeny]


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

@dataclass
class SuperAgentOptions:
    """Configuration options for SuperAgent SDK calls.

    Inspired by CodeBuddy's CodeBuddyAgentOptions:
    - Environment isolation by default (no filesystem config loaded)
    - Explicit control over model, tools, permissions
    - Hook system for lifecycle events
    """

    # Model configuration
    model: Optional[str] = None
    fallback_model: Optional[str] = None

    # Permission mode
    permission_mode: str = "default"  # default | acceptEdits | bypassPermissions | plan

    # Working directory
    cwd: Optional[str] = None

    # Resource limits
    max_turns: int = 20

    # Tool control
    allowed_tools: list[str] = field(default_factory=list)
    disallowed_tools: list[str] = field(default_factory=list)

    # Permission callback
    can_use_tool: Optional[CanUseToolCallback] = None

    # Hook system
    hooks: dict = field(default_factory=dict)  # event_name -> [HookMatcher]

    # Custom agents
    agents: dict = field(default_factory=dict)  # name -> AgentDefinition

    # MCP servers
    mcp_servers: dict = field(default_factory=dict)

    # Environment variables
    env: dict = field(default_factory=dict)

    # Setting sources (for loading filesystem config)
    setting_sources: list[str] = field(default_factory=list)  # 'user', 'project', 'local'


@dataclass
class AgentDefinition:
    """Custom sub-agent definition for SDK usage."""

    description: str = ""
    tools: list[str] = field(default_factory=list)
    disallowed_tools: list[str] = field(default_factory=list)
    prompt: str = ""
    model: Optional[str] = None


# ---------------------------------------------------------------------------
# Core query function
# ---------------------------------------------------------------------------

async def query(
    prompt: str,
    options: Optional[SuperAgentOptions] = None,
) -> AsyncIterator[SystemMessage | AssistantMessage | ResultMessage]:
    """Execute a single-turn query against SuperAgent.

    Inspired by CodeBuddy's query() function:
    - Returns an async iterator of messages
    - Supports streaming, permission control, and hooks
    - Environment isolation by default

    Usage:
        async for message in query(prompt="Explain this code"):
            if isinstance(message, AssistantMessage):
                for block in message.content:
                    if isinstance(block, TextBlock):
                        print(block.text)
    """
    if options is None:
        options = SuperAgentOptions()

    import time
    start_time = time.time()
    session_id = uuid.uuid4().hex[:16]

    # Trigger SessionStart hooks if configured
    if options.hooks:
        from superagent.hooks import trigger_hooks, HookEvent
        trigger_hooks(HookEvent.SESSION_START, data_dir=options.cwd)

    try:
        # Yield system message
        yield SystemMessage(
            session_id=session_id,
            tools=options.allowed_tools or [],
        )

        # Execute the query via LLM gateway
        from superagent.llm_gateway import call_llm

        # Check permission callback for allowed tools
        effective_prompt = prompt
        if options.can_use_tool:
            # Permission check is done at the tool level during execution
            pass

        result = await call_llm(
            effective_prompt,
            provider="default",
            model=options.model,
        )

        # Yield assistant message
        content = [TextBlock(text=result or "")]
        yield AssistantMessage(content=content)

        # Yield result message
        duration_ms = int((time.time() - start_time) * 1000)
        yield ResultMessage(
            subtype="success",
            duration_ms=duration_ms,
            session_id=session_id,
        )

    except Exception as e:
        duration_ms = int((time.time() - start_time) * 1000)
        yield ResultMessage(
            subtype="error",
            duration_ms=duration_ms,
            session_id=session_id,
        )

    finally:
        if options.hooks:
            from superagent.hooks import trigger_hooks, HookEvent
            trigger_hooks(HookEvent.SESSION_END, data_dir=options.cwd)


# ---------------------------------------------------------------------------
# Multi-turn client
# ---------------------------------------------------------------------------

class SuperAgentClient:
    """Multi-turn conversation client for SuperAgent.

    Inspired by CodeBuddy's CodeBuddySDKClient:
    - Maintains session state across multiple turns
    - Supports interrupt and resume
    - Integrates with permission and hook systems

    Usage:
        async with SuperAgentClient() as client:
            await client.send("First question")
            async for msg in client.receive_response():
                print(msg)

            await client.send("Follow-up")
            async for msg in client.receive_response():
                print(msg)
    """

    def __init__(self, options: Optional[SuperAgentOptions] = None):
        self.options = options or SuperAgentOptions()
        self.session_id = uuid.uuid4().hex[:16]
        self._history: list[dict] = []
        self._closed = False

    async def __aenter__(self) -> SuperAgentClient:
        from superagent.hooks import trigger_hooks, HookEvent
        trigger_hooks(HookEvent.SESSION_START)
        return self

    async def __aexit__(self, *args) -> None:
        from superagent.hooks import trigger_hooks, HookEvent
        trigger_hooks(HookEvent.SESSION_END)
        self._closed = True

    async def send(self, prompt: str) -> None:
        """Send a user prompt (add to conversation history)."""
        self._history.append({"role": "user", "content": prompt})

    async def receive_response(self) -> AsyncIterator[AssistantMessage | ResultMessage]:
        """Receive the response for the last sent prompt."""
        if not self._history:
            return

        from superagent.llm_gateway import call_llm
        import time

        start_time = time.time()

        try:
            # Build conversation context from history
            last_prompt = self._history[-1]["content"]
            result = await call_llm(
                last_prompt,
                provider="default",
                model=self.options.model,
            )

            self._history.append({"role": "assistant", "content": result or ""})

            yield AssistantMessage(content=[TextBlock(text=result or "")])

            duration_ms = int((time.time() - start_time) * 1000)
            yield ResultMessage(
                subtype="success",
                duration_ms=duration_ms,
                session_id=self.session_id,
            )

        except Exception as e:
            yield ResultMessage(subtype="error", session_id=self.session_id)

    async def interrupt(self) -> None:
        """Interrupt the current operation."""
        # Signal to stop any ongoing execution
        pass

    @property
    def history(self) -> list[dict]:
        """Get conversation history."""
        return list(self._history)
