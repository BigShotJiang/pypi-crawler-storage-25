"""SuperAgent aider CLI commands — terminal-native coding agent via aider."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel

from superagent.aider_agent import is_aider_available, run_aider

aider_app = typer.Typer(
    name="aider",
    help="Aider coding agent — terminal-native, model-agnostic code editing (25k stars).",
    no_args_is_help=True,
)
console = Console()


@aider_app.command("status")
def aider_status():
    """Check if aider is installed and ready."""
    available = is_aider_available()

    if available:
        console.print(Panel(
            "[green]aider is installed and ready.[/green]\n\n"
            "Engine: [bold]aider-chat[/bold]\n"
            "Run a task with: [bold]superagent aider run \"your task here\"[/bold]",
            title="Aider Status",
            border_style="green",
        ))
    else:
        console.print(Panel(
            "[yellow]aider is not installed.[/yellow]\n\n"
            "Install with: [bold]pip install aider-chat[/bold]\n"
            "Docs: https://github.com/paul-gauthier/aider",
            title="Aider Status",
            border_style="yellow",
        ))


@aider_app.command("run")
def aider_run(
    task: str = typer.Argument(..., help="Coding task to execute (e.g. 'Add error handling to main.py')."),
    model: str = typer.Option("deepseek/deepseek-chat", "--model", "-m", help="LLM model to use."),
    working_dir: str = typer.Option(".", "--dir", "-d", help="Working directory for aider."),
    auto_commit: bool = typer.Option(True, "--auto-commit/--no-auto-commit", help="Auto-commit changes."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Run an aider coding task."""
    if not is_aider_available():
        console.print(Panel(
            "[red]aider is not installed.[/red]\n\n"
            "Install it with: [bold]pip install aider-chat[/bold]",
            title="Aider Not Available",
            border_style="red",
        ))
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold]{task}[/bold]\n[dim]model: {model} | dir: {working_dir}[/dim]",
        title="Aider Task",
        border_style="cyan",
    ))

    with console.status("[cyan]Running aider...[/cyan]"):
        result = run_aider(task, working_dir=working_dir, model=model, auto_commit=auto_commit)

    if json_out:
        import json
        console.print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if result["success"]:
        console.print(Panel(
            result.get("stdout", "") or "[dim]Done (no output)[/dim]",
            title="[green]Result[/green]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[red]{result.get('error', 'Unknown error')}[/red]",
            title="[red]Failed[/red]",
            border_style="red",
        ))
        raise typer.Exit(1)


@aider_app.command("edit")
def aider_edit(
    file: str = typer.Argument(..., help="File to edit with aider."),
    task: str = typer.Argument(..., help="Edit instruction (e.g. 'Add type hints to all functions')."),
    model: str = typer.Option("deepseek/deepseek-chat", "--model", "-m", help="LLM model to use."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Edit a specific file with aider."""
    if not is_aider_available():
        console.print(Panel(
            "[red]aider is not installed.[/red]\n\n"
            "Install it with: [bold]pip install aider-chat[/bold]",
            title="Aider Not Available",
            border_style="red",
        ))
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold]File:[/bold] {file}\n[bold]Task:[/bold] {task}\n[dim]model: {model}[/dim]",
        title="Aider Edit",
        border_style="cyan",
    ))

    with console.status("[cyan]Editing with aider...[/cyan]"):
        result = run_aider(task, model=model, files=[file])

    if json_out:
        import json
        console.print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if result["success"]:
        console.print(Panel(
            result.get("stdout", "") or f"[dim]Edited {file}[/dim]",
            title=f"[green]Edited: {file}[/green]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[red]{result.get('error', 'Unknown error')}[/red]",
            title="[red]Edit Failed[/red]",
            border_style="red",
        ))
        raise typer.Exit(1)
