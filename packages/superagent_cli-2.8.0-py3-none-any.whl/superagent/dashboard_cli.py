"""SuperAgent dashboard CLI — launch pixel-art visualization panel."""
from __future__ import annotations

import os
import subprocess
import sys

import typer
from rich.console import Console
from rich.panel import Panel

from superagent.dashboard import (
    DashboardSyncThread,
    collect_team_state,
    get_dashboard_dir,
    write_star_office_state,
)

dashboard_app = typer.Typer(
    name="dashboard",
    help="Real-time pixel-art visualization of agent teams (Star-Office-UI).",
    no_args_is_help=True,
)
console = Console()


@dashboard_app.command("serve")
def dashboard_serve(
    team: str = typer.Option(None, "--team", "-t", help="Team to monitor (monitors all if not specified)."),
    port: int = typer.Option(19000, "--port", "-p", help="Dashboard port."),
    host: str = typer.Option("127.0.0.1", "--host", help="Dashboard host."),
    sync_interval: float = typer.Option(3.0, "--sync", help="State sync interval in seconds."),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't auto-open browser."),
):
    """Launch the pixel-art office dashboard with real-time agent monitoring."""
    dashboard_dir = get_dashboard_dir()
    backend_dir = os.path.join(dashboard_dir, "backend")
    
    if not os.path.isdir(backend_dir):
        console.print("[red]Dashboard backend not found. Ensure dashboard/ directory exists.[/red]")
        raise typer.Exit(1)
    
    # Write initial state
    if team:
        state, agents = write_star_office_state(team, dashboard_dir)
        console.print(f"[bold]Monitoring team:[/bold] {team}")
        console.print(f"[bold]Agents:[/bold] {len(agents)}")
        console.print(f"[bold]State:[/bold] {state['state']} — {state['detail']}")
    else:
        console.print("[bold]No team specified — dashboard will show idle state.[/bold]")
        console.print("[dim]Use --team <name> to monitor a specific team.[/dim]")
    
    console.print()
    console.print(Panel(
        f"[bold green]Dashboard starting at http://{host}:{port}[/bold green]\n\n"
        f"  Open in browser to see the pixel-art office visualization.\n"
        f"  Agents will appear as characters moving between work areas.\n\n"
        f"  [dim]Sync interval: {sync_interval}s | Press Ctrl+C to stop[/dim]",
        title="SuperAgent Dashboard",
    ))
    
    # Start sync thread if monitoring a team
    sync_thread = None
    if team:
        sync_thread = DashboardSyncThread(team, dashboard_dir, interval=sync_interval)
        sync_thread.start()
    
    # Install Flask if needed
    try:
        import flask  # noqa: F401
    except ImportError:
        console.print("[yellow]Installing Flask for dashboard...[/yellow]")
        subprocess.run([sys.executable, "-m", "pip", "install", "flask", "pillow"], capture_output=True)
    
    # Launch the Star-Office-UI Flask backend
    env = os.environ.copy()
    env["STAR_BACKEND_PORT"] = str(port)
    env["STAR_BACKEND_HOST"] = host
    
    try:
        subprocess.run(
            [sys.executable, os.path.join(backend_dir, "app.py")],
            cwd=dashboard_dir,
            env=env,
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Dashboard stopped.[/yellow]")
    finally:
        if sync_thread:
            sync_thread.stop()


@dashboard_app.command("status")
def dashboard_status(
    team: str = typer.Argument(..., help="Team name to show status for."),
):
    """Show current team status as it would appear in the dashboard."""
    state = collect_team_state(team)
    
    console.print(f"\n[bold]Team:[/bold] {team}")
    console.print(f"[bold]Agents:[/bold] {len(state['agents'])}")
    
    tasks = state["tasks"]
    console.print(f"[bold]Tasks:[/bold] {tasks['completed']}/{tasks['total']} completed, "
                  f"{tasks['in_progress']} running, {tasks['pending']} pending, {tasks['blocked']} blocked")
    console.print(f"[bold]Messages:[/bold] {state['messages']}")
    
    if state["agents"]:
        console.print("\n[bold]Agent Details:[/bold]")
        for a in state["agents"]:
            status_color = "green" if a["status"] not in ("dead", "error") else "red"
            console.print(f"  [{status_color}]{a['name']}[/{status_color}] — {a.get('task', 'no task')[:50]}")
    console.print()


@dashboard_app.command("sync")
def dashboard_sync(
    team: str = typer.Argument(..., help="Team name to sync."),
):
    """One-shot sync: write current team state to dashboard files."""
    dashboard_dir = get_dashboard_dir()
    state, agents = write_star_office_state(team, dashboard_dir)
    console.print(f"[green]Synced {len(agents)} agents to dashboard.[/green]")
    console.print(f"State: {state['state']} — {state['detail']}")
