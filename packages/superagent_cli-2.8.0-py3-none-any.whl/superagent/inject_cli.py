"""Inject command — send async user directives to a running team."""
from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console

console = Console()

inject_app = typer.Typer()


@inject_app.command("send")
def inject_send(
    team: str = typer.Argument(..., help="Team name to send directive to."),
    message: str = typer.Argument(..., help="New task, requirement, or instruction."),
    priority: str = typer.Option("normal", "--priority", "-p", help="Priority: normal, high, urgent."),
):
    """Send an async directive to a running team's leader.

    The leader will pick this up at the next re-evaluation checkpoint
    (e.g., before synthesis or between worker phases).

    Examples:
        superagent inject send my-team "Also add dark mode support"
        superagent inject send my-team "Stop backend work, focus on frontend" --priority urgent
    """
    import json
    import os
    import uuid
    from datetime import datetime, timezone

    from superagent.file_util import atomic_write

    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    inject_dir = os.path.join(data_dir, "teams", team, "injections")
    os.makedirs(inject_dir, exist_ok=True)

    directive = {
        "id": uuid.uuid4().hex[:12],
        "message": message,
        "priority": priority,
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "status": "pending",
    }

    path = os.path.join(inject_dir, f"inject-{directive['id']}.json")
    atomic_write(path, json.dumps(directive, indent=2, ensure_ascii=False))

    console.print(f"[green]Directive sent to team '{team}'[/green]")
    console.print(f"  ID: {directive['id']}")
    console.print(f"  Priority: {priority}")
    console.print(f"  Message: {message}")


@inject_app.command("list")
def inject_list(
    team: str = typer.Argument(..., help="Team name."),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status: pending, processed, all."),
):
    """List pending directives for a team."""
    import json
    import os

    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    inject_dir = os.path.join(data_dir, "teams", team, "injections")

    if not os.path.isdir(inject_dir):
        console.print(f"[dim]No directives for team '{team}'[/dim]")
        return

    directives = []
    for f in sorted(os.listdir(inject_dir)):
        if not f.endswith(".json"):
            continue
        try:
            data = json.loads(open(os.path.join(inject_dir, f), encoding="utf-8").read())
            if status and status != "all" and data.get("status") != status:
                continue
            directives.append(data)
        except (json.JSONDecodeError, OSError):
            continue

    if not directives:
        console.print(f"[dim]No {'pending ' if status == 'pending' else ''}directives for team '{team}'[/dim]")
        return

    from rich.table import Table
    table = Table(title=f"Directives — {team}")
    table.add_column("ID", style="dim")
    table.add_column("Priority")
    table.add_column("Status")
    table.add_column("Message")
    table.add_column("Time", style="dim")

    for d in directives:
        prio_style = {"urgent": "red bold", "high": "yellow", "normal": "dim"}.get(d.get("priority", ""), "")
        table.add_row(
            d.get("id", "?"),
            f"[{prio_style}]{d.get('priority', '?')}[/{prio_style}]",
            d.get("status", "?"),
            d.get("message", "")[:60],
            d.get("timestamp", "")[:19],
        )

    console.print(table)
