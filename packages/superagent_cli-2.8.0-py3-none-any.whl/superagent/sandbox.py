"""Sandboxed code execution for SuperAgent — powered by E2B or native OS sandbox.

Executes agent-generated code safely in isolated environments.
Priority: E2B (cloud microVM) > NativeSandbox (OS-level) > local subprocess.

Aligned with CodeBuddy CLI's sandbox approach:
- macOS: Seatbelt (sandbox-exec) for filesystem + network isolation
- Linux: bubblewrap (bwrap) for filesystem + network isolation
- Fallback: restricted subprocess with resource limits
"""
from __future__ import annotations

import logging
import os
import subprocess
import tempfile

logger = logging.getLogger(__name__)

_E2B_AVAILABLE = False
try:
    from e2b import Sandbox
    _E2B_AVAILABLE = True
except ImportError:
    pass


def is_e2b_available() -> bool:
    return _E2B_AVAILABLE and bool(os.environ.get("E2B_API_KEY"))


class CodeSandbox:
    """Execute code safely in E2B sandbox or native OS sandbox.

    Execution priority:
    1. E2B cloud sandbox (if API key available)
    2. NativeSandbox (OS-level: Seatbelt/bwrap/restricted)
    3. Bare local subprocess (legacy fallback)
    """

    def __init__(self, use_e2b: bool = True, use_native: bool = True):
        self._use_e2b = use_e2b and is_e2b_available()
        self._use_native = use_native
        self._native = None
        if self._use_native and not self._use_e2b:
            try:
                from superagent.sandbox_native import NativeSandbox
                self._native = NativeSandbox()
            except ImportError:
                pass

    def execute_python(self, code: str, timeout: int = 30) -> dict:
        """Execute Python code and return result."""
        if self._use_e2b:
            return self._execute_e2b(code, timeout)
        if self._native:
            return self._native.execute_python(code, timeout=timeout)
        return self._execute_local(code, timeout)

    def execute_shell(self, command: str, timeout: int = 30) -> dict:
        """Execute a shell command."""
        if self._use_e2b:
            return self._execute_e2b_shell(command, timeout)
        if self._native:
            return self._native.execute_shell(command, timeout=timeout)
        return self._execute_local_shell(command, timeout)

    def _execute_e2b(self, code, timeout):
        try:
            sandbox = Sandbox(timeout=timeout)
            result = sandbox.run_code(code)
            sandbox.kill()
            return {"success": True, "stdout": str(result), "stderr": "", "engine": "e2b"}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "engine": "e2b"}

    def _execute_e2b_shell(self, command, timeout):
        try:
            sandbox = Sandbox(timeout=timeout)
            result = sandbox.commands.run(command)
            sandbox.kill()
            return {"success": True, "stdout": result.stdout, "stderr": result.stderr, "engine": "e2b"}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "engine": "e2b"}

    def _execute_local(self, code, timeout):
        try:
            with tempfile.NamedTemporaryFile(mode='w', suffix='.py', delete=False) as f:
                f.write(code)
                f.flush()
                result = subprocess.run(['python', f.name], capture_output=True, text=True, timeout=timeout)
            os.unlink(f.name)
            return {"success": result.returncode == 0, "stdout": result.stdout, "stderr": result.stderr, "engine": "local"}
        except subprocess.TimeoutExpired:
            return {"success": False, "stdout": "", "stderr": "Timeout", "engine": "local"}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "engine": "local"}

    def _execute_local_shell(self, command, timeout):
        try:
            result = subprocess.run(command, shell=True, capture_output=True, text=True, timeout=timeout)
            return {"success": result.returncode == 0, "stdout": result.stdout, "stderr": result.stderr, "engine": "local"}
        except Exception as e:
            return {"success": False, "stdout": "", "stderr": str(e), "engine": "local"}


def get_sandbox(use_e2b: bool = True, use_native: bool = True) -> CodeSandbox:
    return CodeSandbox(use_e2b=use_e2b, use_native=use_native)
