"""Multi-platform trend search for SuperAgent — inspired by last30days-skill (18k stars).

Searches across multiple platforms for recent discussions on any topic.
Uses available APIs (Brave Search, Reddit, HN) with graceful fallbacks.
"""
from __future__ import annotations

import json
import logging
import os
import urllib.parse
import urllib.request
from dataclasses import dataclass
from datetime import datetime, timedelta, timezone

logger = logging.getLogger(__name__)


@dataclass
class SearchResult:
    title: str
    url: str
    source: str  # "reddit", "hackernews", "web", "youtube"
    snippet: str
    score: float = 0.0  # relevance score
    date: str = ""

    def to_dict(self) -> dict:
        return {"title": self.title, "url": self.url, "source": self.source,
                "snippet": self.snippet, "score": self.score, "date": self.date}


class TrendSearcher:
    """Search across multiple platforms for recent discussions."""

    def __init__(self):
        self._brave_key = os.environ.get("BRAVE_API_KEY", "")

    def search_all(self, query: str, limit: int = 10) -> list[SearchResult]:
        """Search across all available platforms and merge results."""
        results = []

        # Hacker News (always free, no API key needed)
        results.extend(self._search_hackernews(query, limit=limit))

        # Reddit (public JSON API, no key needed)
        results.extend(self._search_reddit(query, limit=limit))

        # Web search (Brave if key available)
        if self._brave_key:
            results.extend(self._search_brave(query, limit=limit))

        # Sort by score, deduplicate by URL
        seen_urls: set[str] = set()
        unique: list[SearchResult] = []
        for r in sorted(results, key=lambda x: x.score, reverse=True):
            if r.url not in seen_urls:
                seen_urls.add(r.url)
                unique.append(r)

        return unique[:limit]

    def search_platform(self, query: str, platform: str, limit: int = 10) -> list[SearchResult]:
        """Search a specific platform."""
        methods = {
            "hackernews": self._search_hackernews,
            "hn": self._search_hackernews,
            "reddit": self._search_reddit,
            "web": self._search_brave,
        }
        fn = methods.get(platform.lower())
        if fn:
            return fn(query, limit=limit)
        return []

    def _search_hackernews(self, query: str, limit: int = 5) -> list[SearchResult]:
        """Search Hacker News via Algolia API (free, no key)."""
        try:
            # Search last 30 days
            thirty_days_ago = int((datetime.now(timezone.utc) - timedelta(days=30)).timestamp())
            url = (f"https://hn.algolia.com/api/v1/search?"
                   f"query={urllib.parse.quote(query)}&"
                   f"numericFilters=created_at_i>{thirty_days_ago}&"
                   f"hitsPerPage={limit}")
            req = urllib.request.Request(url, headers={"User-Agent": "SuperAgent/2.3"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())

            results = []
            for hit in data.get("hits", [])[:limit]:
                title = hit.get("title") or hit.get("story_title", "")
                url = hit.get("url") or f"https://news.ycombinator.com/item?id={hit.get('objectID', '')}"
                snippet = hit.get("comment_text", "")[:200] if hit.get("comment_text") else ""
                results.append(SearchResult(
                    title=title, url=url, source="hackernews",
                    snippet=snippet or title,
                    score=hit.get("points", 0) / 100.0,
                    date=hit.get("created_at", ""),
                ))
            return results
        except Exception as e:
            logger.debug("HN search failed: %s", e)
            return []

    def _search_reddit(self, query: str, limit: int = 5) -> list[SearchResult]:
        """Search Reddit via public JSON API (free, no key)."""
        try:
            url = (f"https://www.reddit.com/search.json?"
                   f"q={urllib.parse.quote(query)}&sort=relevance&t=month&limit={limit}")
            req = urllib.request.Request(url, headers={"User-Agent": "SuperAgent/2.3"})
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())

            results = []
            for child in data.get("data", {}).get("children", [])[:limit]:
                post = child.get("data", {})
                results.append(SearchResult(
                    title=post.get("title", ""),
                    url=f"https://reddit.com{post.get('permalink', '')}",
                    source="reddit",
                    snippet=post.get("selftext", "")[:200] or post.get("title", ""),
                    score=post.get("score", 0) / 1000.0,
                    date=datetime.fromtimestamp(post.get("created_utc", 0), tz=timezone.utc).isoformat(),
                ))
            return results
        except Exception as e:
            logger.debug("Reddit search failed: %s", e)
            return []

    def _search_brave(self, query: str, limit: int = 5) -> list[SearchResult]:
        """Search web via Brave Search API (needs BRAVE_API_KEY)."""
        if not self._brave_key:
            return []
        try:
            url = (f"https://api.search.brave.com/res/v1/web/search?"
                   f"q={urllib.parse.quote(query)}&count={limit}&freshness=pm")
            req = urllib.request.Request(url, headers={
                "X-Subscription-Token": self._brave_key,
                "Accept": "application/json",
            })
            with urllib.request.urlopen(req, timeout=10) as resp:
                data = json.loads(resp.read())

            results = []
            for item in data.get("web", {}).get("results", [])[:limit]:
                results.append(SearchResult(
                    title=item.get("title", ""),
                    url=item.get("url", ""),
                    source="web",
                    snippet=item.get("description", "")[:200],
                    score=0.5,
                    date=item.get("age", ""),
                ))
            return results
        except Exception as e:
            logger.debug("Brave search failed: %s", e)
            return []

    def generate_report(self, query: str, results: list[SearchResult]) -> str:
        """Generate a markdown trend report from search results."""
        lines = [f"# Trend Report: {query}", "", f"*Generated: {datetime.now().isoformat()[:16]}*",
                 f"*Sources: {len(set(r.source for r in results))} platforms, {len(results)} results*", ""]

        by_source: dict[str, list[SearchResult]] = {}
        for r in results:
            by_source.setdefault(r.source, []).append(r)

        source_names = {"hackernews": "Hacker News", "reddit": "Reddit", "web": "Web", "youtube": "YouTube"}

        for source, items in by_source.items():
            lines.append(f"## {source_names.get(source, source)}")
            lines.append("")
            for i, r in enumerate(items, 1):
                lines.append(f"{i}. **[{r.title}]({r.url})**")
                if r.snippet and r.snippet != r.title:
                    lines.append(f"   > {r.snippet[:150]}")
                lines.append("")

        return "\n".join(lines)


def get_trend_searcher() -> TrendSearcher:
    return TrendSearcher()
