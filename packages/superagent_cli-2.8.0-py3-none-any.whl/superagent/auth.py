"""Multi-user authentication for SuperAgent Gateway.

Provides:
- User accounts with hashed passwords (bcrypt)
- JWT session tokens with TTL and refresh
- API key management (create, revoke, rotate)
- RBAC roles: admin, user, viewer
- Per-IP rate limiting

Aligned with CodeBuddy CLI's three-tier authentication model:
1. OAuth Bearer / JWT (highest priority)
2. API Key (``sa_`` prefix)
3. Static password (backward compatibility)

All auth data is persisted in the shared SQLite database.
"""
from __future__ import annotations

import hashlib
import logging
import os
import secrets
import sqlite3
import time
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Optional

logger = logging.getLogger(__name__)


class Role(str, Enum):
    """User roles with hierarchical permissions."""

    admin = "admin"    # Full access: manage users, API keys, settings, runs
    user = "user"      # Create runs, read teams/agents, manage own API keys
    viewer = "viewer"  # Read-only: dashboard, runs, health


# ── Data models ──


@dataclass
class User:
    """A registered user."""

    id: str
    username: str
    password_hash: str
    role: Role = Role.user
    created_at: str = ""
    updated_at: str = ""
    is_active: bool = True
    last_login: Optional[str] = None

    def to_dict(self, *, include_hash: bool = False) -> dict:
        d = {
            "id": self.id,
            "username": self.username,
            "role": self.role.value,
            "is_active": self.is_active,
            "created_at": self.created_at,
            "last_login": self.last_login,
        }
        if include_hash:
            d["password_hash"] = self.password_hash
        return d


@dataclass
class Session:
    """A JWT-like session token."""

    token: str
    user_id: str
    created_at: float
    expires_at: float
    role: Role

    @property
    def is_expired(self) -> bool:
        return time.time() > self.expires_at

    @property
    def ttl(self) -> int:
        """Remaining TTL in seconds."""
        return max(0, int(self.expires_at - time.time()))


@dataclass
class APIKey:
    """An API key for programmatic access."""

    id: str
    user_id: str
    key_prefix: str
    key_hash: str
    name: str
    role: Role = Role.user
    created_at: str = ""
    expires_at: Optional[str] = None
    last_used: Optional[str] = None
    is_active: bool = True

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "user_id": self.user_id,
            "key_prefix": self.key_prefix,
            "name": self.name,
            "role": self.role.value,
            "created_at": self.created_at,
            "expires_at": self.expires_at,
            "last_used": self.last_used,
            "is_active": self.is_active,
        }


# ── Auth schema ──

_AUTH_SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    username TEXT UNIQUE NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT,
    updated_at TEXT,
    is_active INTEGER DEFAULT 1,
    last_login TEXT
);

CREATE TABLE IF NOT EXISTS api_keys (
    id TEXT PRIMARY KEY,
    user_id TEXT NOT NULL REFERENCES users(id),
    key_prefix TEXT NOT NULL,
    key_hash TEXT NOT NULL UNIQUE,
    name TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'user',
    created_at TEXT,
    expires_at TEXT,
    last_used TEXT,
    is_active INTEGER DEFAULT 1
);

CREATE INDEX IF NOT EXISTS idx_api_keys_hash ON api_keys(key_hash);
CREATE INDEX IF NOT EXISTS idx_api_keys_user ON api_keys(user_id);
CREATE INDEX IF NOT EXISTS idx_api_keys_prefix ON api_keys(key_prefix);
CREATE INDEX IF NOT EXISTS idx_users_username ON users(username);
"""


# ── Password hashing ──

def _hash_password(password: str) -> str:
    """Hash a password using bcrypt."""
    try:
        from passlib.context import CryptContext
        pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
        return pwd_ctx.hash(password)
    except ImportError:
        # Fallback to SHA-256 + salt if passlib not available
        salt = secrets.token_hex(16)
        h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
        return f"sha256${salt}${h}"


def _verify_password(password: str, password_hash: str) -> bool:
    """Verify a password against its hash."""
    if password_hash.startswith("$2"):  # bcrypt
        try:
            from passlib.context import CryptContext
            pwd_ctx = CryptContext(schemes=["bcrypt"], deprecated="auto")
            return pwd_ctx.verify(password, password_hash)
        except ImportError:
            return False
    elif password_hash.startswith("sha256$"):
        parts = password_hash.split("$", 2)
        if len(parts) != 3:
            return False
        salt, stored_hash = parts[1], parts[2]
        h = hashlib.sha256(f"{salt}:{password}".encode()).hexdigest()
        return secrets.compare_digest(h, stored_hash)
    return False


# ── JWT token handling ──

def _get_jwt_secret() -> str:
    """Get or generate the JWT signing secret."""
    from superagent.gateway import _data_dir
    secret_path = _data_dir() / "gateway" / "jwt_secret"
    secret_path.parent.mkdir(parents=True, exist_ok=True)

    if secret_path.exists():
        try:
            return secret_path.read_text(encoding="utf-8").strip()
        except OSError:
            pass

    secret = secrets.token_urlsafe(48)
    from superagent.file_util import atomic_write
    atomic_write(secret_path, secret)
    os.chmod(str(secret_path), 0o600)
    return secret


def _create_jwt(payload: dict) -> str:
    """Create a JWT token. Uses python-jose if available, else HMAC-based."""
    try:
        from jose import jwt
        secret = _get_jwt_secret()
        return jwt.encode(payload, secret, algorithm="HS256")
    except ImportError:
        pass

    # Fallback: HMAC-SHA256 token
    import base64
    import json as _json
    import hmac as _hmac

    header = base64.urlsafe_b64encode(
        _json.dumps({"alg": "HS256", "typ": "JWT"}).encode()
    ).rstrip(b"=").decode()
    payload_b64 = base64.urlsafe_b64encode(
        _json.dumps(payload).encode()
    ).rstrip(b"=").decode()
    signing_input = f"{header}.{payload_b64}"
    sig = _hmac.new(
        _get_jwt_secret().encode(), signing_input.encode(), hashlib.sha256
    ).digest()
    signature = base64.urlsafe_b64encode(sig).rstrip(b"=").decode()
    return f"{signing_input}.{signature}"


def _decode_jwt(token: str) -> Optional[dict]:
    """Decode and verify a JWT token."""
    try:
        from jose import jwt, JWTError
        secret = _get_jwt_secret()
        return jwt.decode(token, secret, algorithms=["HS256"])
    except ImportError:
        pass
    except Exception:
        return None

    # Fallback: HMAC-SHA256 verification
    import base64
    import json as _json
    import hmac as _hmac

    parts = token.split(".")
    if len(parts) != 3:
        return None

    header_b64, payload_b64, signature = parts
    signing_input = f"{header_b64}.{payload_b64}"
    expected_sig = _hmac.new(
        _get_jwt_secret().encode(), signing_input.encode(), hashlib.sha256
    ).digest()
    try:
        actual_sig = base64.urlsafe_b64decode(signature + "==")
    except Exception:
        return None

    if not secrets.compare_digest(expected_sig, actual_sig):
        return None

    try:
        payload_json = base64.urlsafe_b64decode(payload_b64 + "==")
        return _json.loads(payload_json)
    except Exception:
        return None


# ── API Key helpers ──

API_KEY_PREFIX = "sa_"
API_KEY_LENGTH = 32


def _generate_api_key() -> tuple[str, str, str]:
    """Generate a new API key. Returns (full_key, prefix, hash)."""
    raw = secrets.token_urlsafe(API_KEY_LENGTH)
    full_key = f"{API_KEY_PREFIX}{raw}"
    prefix = full_key[:8]
    key_hash = hashlib.sha256(full_key.encode()).hexdigest()
    return full_key, prefix, key_hash


def _hash_api_key(key: str) -> str:
    """Hash an API key for lookup."""
    return hashlib.sha256(key.encode()).hexdigest()


# ── Auth Manager ──


class AuthManager:
    """Manages users, sessions, API keys, and rate limiting.

    All data is persisted in the shared SQLite database.
    """

    def __init__(self, db: Optional[sqlite3.Connection] = None):
        if db is None:
            from superagent.db import get_db
            self._db = get_db()
        else:
            self._db = db
        self._init_schema()
        # In-memory sessions (lost on restart is acceptable — users re-login)
        self._sessions: dict[str, Session] = {}
        # Per-IP rate limiting
        self._rate_limits: dict[str, list[float]] = {}

    def _init_schema(self) -> None:
        """Create auth tables if they don't exist."""
        for stmt in _AUTH_SCHEMA_SQL.strip().split(";"):
            stmt = stmt.strip()
            if stmt:
                try:
                    self._db.execute(stmt)
                except sqlite3.OperationalError:
                    pass  # table already exists
        self._db.commit()

    # ── User management ──

    def create_user(
        self, username: str, password: str, role: Role = Role.user
    ) -> User:
        """Create a new user."""
        user_id = uuid.uuid4().hex
        now = datetime.now(timezone.utc).isoformat()
        pw_hash = _hash_password(password)

        self._db.execute(
            """INSERT INTO users (id, username, password_hash, role, created_at, updated_at)
               VALUES (?, ?, ?, ?, ?, ?)""",
            (user_id, username, pw_hash, role.value, now, now),
        )
        self._db.commit()

        user = User(
            id=user_id,
            username=username,
            password_hash=pw_hash,
            role=role,
            created_at=now,
            updated_at=now,
        )
        logger.info("Created user: %s (role=%s)", username, role.value)
        return user

    def get_user(self, user_id: str) -> Optional[User]:
        """Get user by ID."""
        row = self._db.execute(
            "SELECT * FROM users WHERE id = ?", (user_id,)
        ).fetchone()
        return self._row_to_user(row) if row else None

    def get_user_by_username(self, username: str) -> Optional[User]:
        """Get user by username."""
        row = self._db.execute(
            "SELECT * FROM users WHERE username = ?", (username,)
        ).fetchone()
        return self._row_to_user(row) if row else None

    def list_users(self) -> list[User]:
        """List all users."""
        rows = self._db.execute(
            "SELECT * FROM users ORDER BY created_at"
        ).fetchall()
        return [self._row_to_user(r) for r in rows]

    def update_user(self, user_id: str, **kwargs) -> Optional[User]:
        """Update user fields."""
        user = self.get_user(user_id)
        if user is None:
            return None

        allowed = {"role", "is_active", "last_login"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return user

        now = datetime.now(timezone.utc).isoformat()
        updates["updated_at"] = now

        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [user_id]
        self._db.execute(f"UPDATE users SET {set_clause} WHERE id = ?", values)
        self._db.commit()

        return self.get_user(user_id)

    def delete_user(self, user_id: str) -> bool:
        """Delete a user and their API keys."""
        self._db.execute("DELETE FROM api_keys WHERE user_id = ?", (user_id,))
        self._db.execute("DELETE FROM users WHERE id = ?", (user_id,))
        self._db.commit()
        return self._db.total_changes > 0

    def verify_password(self, user: User, password: str) -> bool:
        """Verify a password for a user."""
        return _verify_password(password, user.password_hash)

    def authenticate(self, username: str, password: str) -> Optional[User]:
        """Authenticate a user by username and password.

        Updates last_login on success.
        """
        user = self.get_user_by_username(username)
        if user is None or not user.is_active:
            return None
        if not self.verify_password(user, password):
            return None

        now = datetime.now(timezone.utc).isoformat()
        self._db.execute(
            "UPDATE users SET last_login = ? WHERE id = ?", (now, user.id)
        )
        self._db.commit()
        user.last_login = now
        return user

    # ── Session management ──

    def create_session(
        self, user: User, ttl: int = 86400
    ) -> Session:
        """Create a new session (JWT token)."""
        now = time.time()
        expires_at = now + ttl

        payload = {
            "sub": user.id,
            "username": user.username,
            "role": user.role.value,
            "iat": int(now),
            "exp": int(expires_at),
        }
        token = _create_jwt(payload)

        session = Session(
            token=token,
            user_id=user.id,
            created_at=now,
            expires_at=expires_at,
            role=user.role,
        )
        self._sessions[token] = session
        return session

    def validate_session(self, token: str) -> Optional[Session]:
        """Validate a JWT session token.

        Checks both in-memory cache and JWT signature.
        """
        # Fast path: in-memory
        session = self._sessions.get(token)
        if session and not session.is_expired:
            return session

        # Slow path: verify JWT signature
        payload = _decode_jwt(token)
        if payload is None:
            return None

        # Check expiration
        exp = payload.get("exp", 0)
        if time.time() > exp:
            self._sessions.pop(token, None)
            return None

        # Verify user still exists and is active
        user_id = payload.get("sub")
        if not user_id:
            return None
        user = self.get_user(user_id)
        if user is None or not user.is_active:
            return None

        session = Session(
            token=token,
            user_id=user_id,
            created_at=payload.get("iat", 0),
            expires_at=exp,
            role=Role(payload.get("role", "user")),
        )
        self._sessions[token] = session
        return session

    def revoke_session(self, token: str) -> None:
        """Revoke a session token."""
        self._sessions.pop(token, None)

    def revoke_all_sessions(self, user_id: str) -> int:
        """Revoke all sessions for a user."""
        count = 0
        to_remove = [
            t for t, s in self._sessions.items() if s.user_id == user_id
        ]
        for t in to_remove:
            self._sessions.pop(t, None)
            count += 1
        return count

    # ── API key management ──

    def create_api_key(
        self, user_id: str, name: str, role: Role = Role.user
    ) -> tuple[APIKey, str]:
        """Create a new API key.

        Returns ``(APIKey, raw_key)``. The raw key is only shown once!
        """
        key_id = uuid.uuid4().hex
        full_key, prefix, key_hash = _generate_api_key()
        now = datetime.now(timezone.utc).isoformat()

        self._db.execute(
            """INSERT INTO api_keys (id, user_id, key_prefix, key_hash, name, role, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (key_id, user_id, prefix, key_hash, name, role.value, now),
        )
        self._db.commit()

        api_key = APIKey(
            id=key_id,
            user_id=user_id,
            key_prefix=prefix,
            key_hash=key_hash,
            name=name,
            role=role,
            created_at=now,
        )
        logger.info("Created API key: %s (prefix=%s, role=%s)", name, prefix, role.value)
        return api_key, full_key

    def validate_api_key(self, key: str) -> Optional[APIKey]:
        """Validate an API key string.

        Looks up by SHA-256 hash. Updates last_used timestamp.
        """
        if not key.startswith(API_KEY_PREFIX):
            return None

        key_hash = _hash_api_key(key)
        row = self._db.execute(
            "SELECT * FROM api_keys WHERE key_hash = ? AND is_active = 1",
            (key_hash,),
        ).fetchone()

        if row is None:
            return None

        api_key = self._row_to_api_key(row)

        # Check expiration
        if api_key.expires_at:
            try:
                exp_dt = datetime.fromisoformat(api_key.expires_at)
                if exp_dt < datetime.now(timezone.utc):
                    return None
            except (ValueError, TypeError):
                pass

        # Update last_used
        now = datetime.now(timezone.utc).isoformat()
        self._db.execute(
            "UPDATE api_keys SET last_used = ? WHERE id = ?",
            (now, api_key.id),
        )
        self._db.commit()
        api_key.last_used = now

        return api_key

    def revoke_api_key(self, key_id: str) -> bool:
        """Revoke an API key by ID."""
        self._db.execute(
            "UPDATE api_keys SET is_active = 0 WHERE id = ?", (key_id,)
        )
        self._db.commit()
        return self._db.total_changes > 0

    def list_api_keys(self, user_id: str) -> list[APIKey]:
        """List API keys for a user."""
        rows = self._db.execute(
            "SELECT * FROM api_keys WHERE user_id = ? ORDER BY created_at",
            (user_id,),
        ).fetchall()
        return [self._row_to_api_key(r) for r in rows]

    # ── Rate limiting (per-IP) ──

    def check_rate_limit(
        self,
        ip: str,
        max_per_minute: int = 30,
        max_per_hour: int = 500,
    ) -> bool:
        """Check if an IP is within rate limits."""
        now = time.time()
        attempts = self._rate_limits.get(ip, [])
        # Clean old entries
        attempts = [t for t in attempts if now - t < 3600]
        self._rate_limits[ip] = attempts

        minute_count = sum(1 for t in attempts if now - t < 60)
        hour_count = len(attempts)

        if minute_count >= max_per_minute:
            return False
        if hour_count >= max_per_hour:
            return False
        return True

    def record_request(self, ip: str) -> None:
        """Record a request from an IP for rate limiting."""
        now = time.time()
        if ip not in self._rate_limits:
            self._rate_limits[ip] = []
        self._rate_limits[ip].append(now)

    # ── Bootstrap ──

    def ensure_admin_user(self) -> tuple[str, str]:
        """Ensure at least one admin user exists.

        Returns ``(username, password)``. If admin already exists,
        returns ``("admin", "")``.
        """
        existing = self._db.execute(
            "SELECT id FROM users WHERE role = 'admin' AND is_active = 1 LIMIT 1"
        ).fetchone()

        if existing:
            return "admin", ""

        # Create default admin
        password = secrets.token_urlsafe(16)
        self.create_user("admin", password, Role.admin)
        logger.warning(
            "Created default admin user. "
            "Username: admin, Password: %s  "
            "CHANGE THIS PASSWORD IMMEDIATELY!",
            password,
        )
        return "admin", password

    # ── Row converters ──

    @staticmethod
    def _row_to_user(row: sqlite3.Row) -> User:
        return User(
            id=row["id"],
            username=row["username"],
            password_hash=row["password_hash"],
            role=Role(row["role"]),
            created_at=row["created_at"] or "",
            updated_at=row["updated_at"] or "",
            is_active=bool(row["is_active"]),
            last_login=row["last_login"],
        )

    @staticmethod
    def _row_to_api_key(row: sqlite3.Row) -> APIKey:
        return APIKey(
            id=row["id"],
            user_id=row["user_id"],
            key_prefix=row["key_prefix"],
            key_hash=row["key_hash"],
            name=row["name"],
            role=Role(row["role"]),
            created_at=row["created_at"] or "",
            expires_at=row["expires_at"],
            last_used=row["last_used"],
            is_active=bool(row["is_active"]),
        )


# ── Singleton ──

_auth_manager: Optional[AuthManager] = None


def get_auth_manager(db: Optional[sqlite3.Connection] = None) -> AuthManager:
    """Get or create the singleton AuthManager."""
    global _auth_manager
    if _auth_manager is None or db is not None:
        _auth_manager = AuthManager(db)
    return _auth_manager
