"""Handoff system for SuperAgent — agent-to-agent execution transfer.

Inspired by OpenAI Swarm's Handoff pattern.  Agents can transfer execution
directly to other agents via structured handoff requests that are persisted
as JSON files under ~/.superagent/handoffs/{team}/.
"""

from __future__ import annotations

import json
import os
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write


class HandoffStatus(str, Enum):
    """Lifecycle states for a handoff request."""

    pending = "pending"
    accepted = "accepted"
    rejected = "rejected"
    completed = "completed"


def _now_iso() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


@dataclass
class HandoffRequest:
    """A single agent-to-agent handoff record."""

    id: str
    from_agent: str
    to_agent: str
    team: str
    context: str
    reason: str
    status: HandoffStatus
    created_at: str
    completed_at: Optional[str] = None

    def to_dict(self) -> dict:
        """Serialize to a plain dict suitable for JSON storage."""
        d = asdict(self)
        status = self.status
        d["status"] = status.value if isinstance(status, HandoffStatus) else str(status)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> HandoffRequest:
        """Deserialize from a dict loaded from JSON."""
        return cls(
            id=data["id"],
            from_agent=data["from_agent"],
            to_agent=data["to_agent"],
            team=data["team"],
            context=data.get("context", ""),
            reason=data.get("reason", ""),
            status=HandoffStatus(data.get("status", "pending")),
            created_at=data.get("created_at", ""),
            completed_at=data.get("completed_at"),
        )


class HandoffStore:
    """Manages handoff requests persisted as JSON files.

    Directory layout under *base_dir*::

        handoffs/
        └── {team}/
            └── {handoff_id}.json
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir) / "handoffs"
        self._base.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _team_dir(self, team: str) -> Path:
        return self._base / team

    def _handoff_path(self, team: str, handoff_id: str) -> Path:
        return self._team_dir(team) / f"{handoff_id}.json"

    def _save(self, request: HandoffRequest) -> None:
        path = self._handoff_path(request.team, request.id)
        atomic_write(path, json.dumps(request.to_dict(), indent=2, ensure_ascii=False))

    def _load(self, path: Path) -> Optional[HandoffRequest]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return HandoffRequest.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def create(
        self,
        from_agent: str,
        to_agent: str,
        team: str,
        context: str,
        reason: str,
    ) -> HandoffRequest:
        """Create a new pending handoff request and persist it."""
        request = HandoffRequest(
            id=uuid.uuid4().hex[:12],
            from_agent=from_agent,
            to_agent=to_agent,
            team=team,
            context=context,
            reason=reason,
            status=HandoffStatus.pending,
            created_at=_now_iso(),
        )
        self._save(request)
        return request

    def accept(self, handoff_id: str) -> HandoffRequest:
        """Mark a handoff as accepted.

        Raises ``ValueError`` if the handoff does not exist.
        """
        request = self.get(handoff_id)
        if request is None:
            raise ValueError(f"Handoff '{handoff_id}' not found")
        request.status = HandoffStatus.accepted
        self._save(request)
        return request

    def reject(self, handoff_id: str, reason: Optional[str] = None) -> HandoffRequest:
        """Mark a handoff as rejected, optionally appending a reason.

        Raises ``ValueError`` if the handoff does not exist.
        """
        request = self.get(handoff_id)
        if request is None:
            raise ValueError(f"Handoff '{handoff_id}' not found")
        request.status = HandoffStatus.rejected
        if reason:
            request.reason = f"{request.reason} | rejected: {reason}"
        self._save(request)
        return request

    def complete(self, handoff_id: str) -> HandoffRequest:
        """Mark a handoff as completed.

        Raises ``ValueError`` if the handoff does not exist.
        """
        request = self.get(handoff_id)
        if request is None:
            raise ValueError(f"Handoff '{handoff_id}' not found")
        request.status = HandoffStatus.completed
        request.completed_at = _now_iso()
        self._save(request)
        return request

    def get(self, handoff_id: str) -> Optional[HandoffRequest]:
        """Retrieve a handoff by ID, searching all team directories."""
        for team_dir in self._base.iterdir():
            if not team_dir.is_dir():
                continue
            path = team_dir / f"{handoff_id}.json"
            if path.exists():
                return self._load(path)
        return None

    def list_pending(
        self,
        team: str,
        agent_name: Optional[str] = None,
    ) -> list[HandoffRequest]:
        """List pending handoffs for a team, optionally filtered by target agent."""
        results: list[HandoffRequest] = []
        team_dir = self._team_dir(team)
        if not team_dir.exists():
            return results
        for path in team_dir.glob("*.json"):
            request = self._load(path)
            if request is None or request.status != HandoffStatus.pending:
                continue
            if agent_name and request.to_agent != agent_name:
                continue
            results.append(request)
        results.sort(key=lambda r: r.created_at, reverse=True)
        return results

    def list_all(self, team: str) -> list[HandoffRequest]:
        """List all handoffs for a team."""
        results: list[HandoffRequest] = []
        team_dir = self._team_dir(team)
        if not team_dir.exists():
            return results
        for path in team_dir.glob("*.json"):
            request = self._load(path)
            if request:
                results.append(request)
        results.sort(key=lambda r: r.created_at, reverse=True)
        return results


def get_handoff_store(base_dir: Optional[str] = None) -> HandoffStore:
    """Factory — return a HandoffStore rooted at the project data directory.

    Uses CLAWTEAM_DATA_DIR env var, falling back to ``~/.superagent``.
    """
    if base_dir is None:
        base_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    return HandoffStore(base_dir)
