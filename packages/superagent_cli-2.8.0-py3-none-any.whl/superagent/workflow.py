"""Crew+Flow dual-mode workflow engine for SuperAgent.

Inspired by CrewAI's Crew (autonomous) + Flow (precise control) design.
Workflows operate in two modes:

* **crew** — autonomous: a coordinator assigns steps to agents who collaborate
  freely (parallel, dynamic hand-offs).
* **flow** — precise: steps execute in a strict, pre-defined graph with
  explicit branching and sequencing.

Workflows are persisted as individual JSON files under
``~/.superagent/workflows/``.
"""

from __future__ import annotations

import json
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

# ---------------------------------------------------------------------------
# Core enums & data models
# ---------------------------------------------------------------------------


class StepType(str, Enum):
    """The kind of step in a workflow graph."""

    ACTION = "action"
    CONDITION = "condition"
    PARALLEL = "parallel"
    WAIT = "wait"
    HANDOFF = "handoff"


@dataclass
class WorkflowStep:
    """A single node in a workflow graph.

    Attributes:
        id:              Unique identifier within the workflow.
        name:            Human-readable step name.
        step_type:       One of :class:`StepType`.
        agent_role:      Role that should execute this step (may be ``None``
                         for structural nodes like conditions).
        description:     What this step does.
        next_steps:      IDs of successor steps.
        condition:       Expression string for ``condition`` steps to decide
                         which branch to follow.
        timeout_seconds: Maximum time the step may run before being considered
                         timed-out.
    """

    id: str
    name: str
    step_type: StepType
    agent_role: Optional[str] = None
    description: str = ""
    next_steps: list[str] = field(default_factory=list)
    condition: Optional[str] = None
    timeout_seconds: int = 300

    def to_dict(self) -> dict:
        return {
            "id": self.id,
            "name": self.name,
            "step_type": self.step_type.value,
            "agent_role": self.agent_role,
            "description": self.description,
            "next_steps": list(self.next_steps),
            "condition": self.condition,
            "timeout_seconds": self.timeout_seconds,
        }

    @classmethod
    def from_dict(cls, data: dict) -> WorkflowStep:
        return cls(
            id=data["id"],
            name=data["name"],
            step_type=StepType(data["step_type"]),
            agent_role=data.get("agent_role"),
            description=data.get("description", ""),
            next_steps=data.get("next_steps", []),
            condition=data.get("condition"),
            timeout_seconds=data.get("timeout_seconds", 300),
        )


@dataclass
class Workflow:
    """A named workflow composed of :class:`WorkflowStep` nodes.

    Supports two modes:

    * ``"crew"`` — autonomous collaboration with parallel / dynamic steps.
    * ``"flow"`` — strict graph execution with explicit branching.
    """

    name: str
    description: str
    mode: str = "flow"  # "crew" or "flow"
    steps: list[WorkflowStep] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.now(timezone.utc).isoformat())

    # ------------------------------------------------------------------
    # Serialisation
    # ------------------------------------------------------------------

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "mode": self.mode,
            "steps": [s.to_dict() for s in self.steps],
            "created_at": self.created_at,
        }

    @classmethod
    def from_dict(cls, data: dict) -> Workflow:
        return cls(
            name=data["name"],
            description=data["description"],
            mode=data.get("mode", "flow"),
            steps=[WorkflowStep.from_dict(s) for s in data.get("steps", [])],
            created_at=data.get("created_at", datetime.now(timezone.utc).isoformat()),
        )

    # ------------------------------------------------------------------
    # Builder helpers (return *self* for chaining)
    # ------------------------------------------------------------------

    def then(self, step: WorkflowStep) -> Workflow:
        """Append *step* and link the previous step to it (sequential)."""
        if self.steps:
            last = self.steps[-1]
            if step.id not in last.next_steps:
                last.next_steps.append(step.id)
        self.steps.append(step)
        return self

    def branch(
        self,
        condition: WorkflowStep,
        if_true: WorkflowStep,
        if_false: WorkflowStep,
    ) -> Workflow:
        """Add a condition step that branches to *if_true* / *if_false*.

        Links the previous step to the condition step automatically.
        """
        condition.step_type = StepType.CONDITION
        condition.next_steps = [if_true.id, if_false.id]
        if self.steps:
            last = self.steps[-1]
            if condition.id not in last.next_steps:
                last.next_steps.append(condition.id)
        self.steps.extend([condition, if_true, if_false])
        return self

    def parallel(self, steps: list[WorkflowStep]) -> Workflow:
        """Add a set of steps that run in parallel.

        A synthetic *parallel* node is inserted and linked from the previous
        step; each supplied step becomes a successor of that node.
        """
        par_id = f"par-{'_'.join(s.id for s in steps)}"
        par_node = WorkflowStep(
            id=par_id,
            name="Parallel",
            step_type=StepType.PARALLEL,
            description="Execute the following steps in parallel.",
            next_steps=[s.id for s in steps],
        )
        if self.steps:
            last = self.steps[-1]
            if par_node.id not in last.next_steps:
                last.next_steps.append(par_node.id)
        self.steps.append(par_node)
        self.steps.extend(steps)
        return self


# ---------------------------------------------------------------------------
# Built-in workflows
# ---------------------------------------------------------------------------


def _builtin_code_review_flow() -> Workflow:
    """Code review workflow (flow mode).

    Author -> Reviewer -> (approved? -> Merge, else -> Author fix -> Reviewer)
    """
    author = WorkflowStep(
        id="author",
        name="Author",
        step_type=StepType.ACTION,
        agent_role="Senior Developer",
        description="Write or update the code changes and submit for review.",
    )
    reviewer = WorkflowStep(
        id="reviewer",
        name="Reviewer",
        step_type=StepType.ACTION,
        agent_role="Code Reviewer",
        description="Review the code changes for quality, correctness, and style.",
    )
    review_check = WorkflowStep(
        id="review-check",
        name="Review Decision",
        step_type=StepType.CONDITION,
        description="Decide if the review passed.",
        condition="review_approved",
    )
    merge = WorkflowStep(
        id="merge",
        name="Merge",
        step_type=StepType.ACTION,
        agent_role="DevOps Automator",
        description="Merge the approved changes into the main branch.",
    )
    author_fix = WorkflowStep(
        id="author-fix",
        name="Author Fix",
        step_type=StepType.ACTION,
        agent_role="Senior Developer",
        description="Address reviewer feedback and resubmit.",
        next_steps=["reviewer"],
    )

    wf = Workflow(
        name="code-review-flow",
        description="Code review: Author -> Reviewer -> (approved? Merge : Author fix -> Reviewer)",
        mode="flow",
    )
    wf.then(author).then(reviewer)
    # Manually wire the branch since it loops back
    reviewer.next_steps = ["review-check"]
    review_check.next_steps = ["merge", "author-fix"]
    wf.steps.extend([review_check, merge, author_fix])
    return wf


def _builtin_incident_response() -> Workflow:
    """Incident response workflow (crew mode).

    Commander assigns Investigator + Mitigator + Communicator in parallel.
    """
    commander = WorkflowStep(
        id="commander",
        name="Commander",
        step_type=StepType.ACTION,
        agent_role="Incident Commander",
        description="Assess the incident and coordinate the response team.",
    )
    investigator = WorkflowStep(
        id="investigator",
        name="Investigator",
        step_type=StepType.ACTION,
        agent_role="Root Cause Analyst",
        description="Investigate the root cause of the incident.",
    )
    mitigator = WorkflowStep(
        id="mitigator",
        name="Mitigator",
        step_type=StepType.ACTION,
        agent_role="Site Reliability Engineer",
        description="Mitigate the incident impact and restore service.",
    )
    communicator = WorkflowStep(
        id="communicator",
        name="Communicator",
        step_type=StepType.ACTION,
        agent_role="Communications Lead",
        description="Communicate status updates to stakeholders.",
    )

    wf = Workflow(
        name="incident-response",
        description="Incident response: Commander assigns Investigator + Mitigator + Communicator in parallel",
        mode="crew",
    )
    wf.then(commander).parallel([investigator, mitigator, communicator])
    return wf


def _builtin_feature_dev() -> Workflow:
    """Feature development workflow (flow mode).

    Spec -> Design -> Implement -> Test -> Review -> Deploy (sequential).
    """
    wf = Workflow(
        name="feature-dev",
        description="Feature development: Spec -> Design -> Implement -> Test -> Review -> Deploy",
        mode="flow",
    )
    wf.then(WorkflowStep(
        id="spec",
        name="Spec",
        step_type=StepType.ACTION,
        agent_role="Product Manager",
        description="Gather requirements and write the feature specification.",
    )).then(WorkflowStep(
        id="design",
        name="Design",
        step_type=StepType.ACTION,
        agent_role="UI Designer",
        description="Design the user interface and experience.",
    )).then(WorkflowStep(
        id="implement",
        name="Implement",
        step_type=StepType.ACTION,
        agent_role="Senior Developer",
        description="Implement the feature according to the spec and design.",
    )).then(WorkflowStep(
        id="test",
        name="Test",
        step_type=StepType.ACTION,
        agent_role="Evidence Collector",
        description="Write and execute tests for the new feature.",
    )).then(WorkflowStep(
        id="review",
        name="Review",
        step_type=StepType.ACTION,
        agent_role="Code Reviewer",
        description="Review the implementation for quality and correctness.",
    )).then(WorkflowStep(
        id="deploy",
        name="Deploy",
        step_type=StepType.ACTION,
        agent_role="DevOps Automator",
        description="Deploy the feature to production.",
    ))
    return wf


_BUILTIN_WORKFLOWS: dict[str, Workflow] = {
    "code-review-flow": _builtin_code_review_flow(),
    "incident-response": _builtin_incident_response(),
    "feature-dev": _builtin_feature_dev(),
}


# ---------------------------------------------------------------------------
# Workflow Store
# ---------------------------------------------------------------------------


class WorkflowStore:
    """Persists workflows as individual JSON files under a directory.

    Built-in workflows are written on first initialisation and can be
    overridden by user-defined workflows with the same name.
    """

    def __init__(self, workflows_dir: str | Path) -> None:
        self._dir = Path(workflows_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._ensure_builtins()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _workflow_path(self, name: str) -> Path:
        return self._dir / f"{name}.json"

    def _ensure_builtins(self) -> None:
        """Write built-in workflows to disk if they don't already exist."""
        for name, workflow in _BUILTIN_WORKFLOWS.items():
            path = self._workflow_path(name)
            if not path.exists():
                self._write(workflow)

    def _write(self, workflow: Workflow) -> None:
        path = self._workflow_path(workflow.name)
        atomic_write(path, json.dumps(workflow.to_dict(), indent=2, ensure_ascii=False))

    def _load(self, path: Path) -> Optional[Workflow]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return Workflow.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def save(self, workflow: Workflow) -> None:
        """Save (or overwrite) a workflow."""
        self._write(workflow)

    def get(self, name: str) -> Optional[Workflow]:
        """Retrieve a workflow by name.  Returns ``None`` if not found."""
        path = self._workflow_path(name)
        if not path.exists():
            return None
        return self._load(path)

    def list_all(self) -> list[Workflow]:
        """Return all stored workflows sorted by name."""
        workflows: list[Workflow] = []
        for path in sorted(self._dir.glob("*.json")):
            wf = self._load(path)
            if wf is not None:
                workflows.append(wf)
        return workflows

    def remove(self, name: str) -> bool:
        """Remove a workflow by name.  Returns ``True`` if found and deleted."""
        path = self._workflow_path(name)
        if path.exists():
            path.unlink()
            return True
        return False


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_workflow_store(base_dir: Optional[str] = None) -> WorkflowStore:
    """Return a :class:`WorkflowStore` rooted at the project data directory.

    Uses ``CLAWTEAM_DATA_DIR`` env var, falling back to ``~/.superagent``.
    """
    if base_dir is None:
        base_dir = os.environ.get(
            "CLAWTEAM_DATA_DIR",
            os.path.join(os.path.expanduser("~"), ".superagent"),
        )
    return WorkflowStore(os.path.join(base_dir, "workflows"))
