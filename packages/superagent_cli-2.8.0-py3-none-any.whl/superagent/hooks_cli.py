"""Hooks CLI commands — manage lifecycle hooks.

Commands:
    superagent hook list [--event EVENT]   — List hooks
    superagent hook add                   — Add a new hook
    superagent hook remove                — Remove a hook
    superagent hook test                  — Test hook execution
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from typing import Optional

console = Console()
hook_app = typer.Typer(help="Hooks — lifecycle event hooks for deterministic agent control.")


@hook_app.command("list")
def hook_list(
    event: Optional[str] = typer.Option(None, "--event", "-e", help="Filter by event type"),
):
    """List all registered hooks."""
    from superagent.hooks import get_hook_store, HookEvent
    store = get_hook_store()
    hooks = store.list_hooks(event)

    table = Table(title="Lifecycle Hooks", show_header=True, header_style="bold cyan")
    table.add_column("Event", style="yellow")
    table.add_column("Matcher", style="green")
    table.add_column("Command", max_width=60)

    any_found = False
    for event_name, matchers in hooks.items():
        for matcher in matchers:
            for hook in matcher.hooks:
                any_found = True
                table.add_row(event_name, matcher.matcher or "(all)", hook.command[:60])

    if any_found:
        console.print(table)
    else:
        console.print("[dim]No hooks registered.[/dim]")
        console.print(f"\nAvailable events: {', '.join(HookEvent.ALL)}")
        console.print("\nAdd a hook: [cyan]superagent hook add --event PreToolUse --matcher Bash --command 'echo logged'[/cyan]")


@hook_app.command("add")
def hook_add(
    event: str = typer.Option(..., "--event", "-e", help=f"Event type: PreToolUse, PostToolUse, etc."),
    matcher: str = typer.Option("*", "--matcher", "-m", help="Tool name pattern (e.g., 'Bash', 'Edit|Write', 'mcp__*')"),
    command: str = typer.Option(..., "--command", "-c", help="Shell command to execute"),
    scope: str = typer.Option("user", "--scope", help="Scope: user or project"),
):
    """Add a new lifecycle hook."""
    from superagent.hooks import get_hook_store, HookEvent
    store = get_hook_store()

    if event not in HookEvent.ALL:
        console.print(f"[red]Unknown event: {event}[/red]")
        console.print(f"Available: {', '.join(HookEvent.ALL)}")
        raise typer.Exit(1)

    store.add_hook(event, matcher, command)
    console.print(f"[green]Added hook:[/green]")
    console.print(f"  Event:   {event}")
    console.print(f"  Matcher: {matcher}")
    console.print(f"  Command: {command}")


@hook_app.command("remove")
def hook_remove(
    event: str = typer.Option(..., "--event", "-e", help="Event type"),
    matcher: str = typer.Option(..., "--matcher", "-m", help="Matcher pattern"),
    index: int = typer.Option(-1, "--index", "-i", help="Hook index within matcher (-1 = all)"),
):
    """Remove a lifecycle hook."""
    from superagent.hooks import get_hook_store
    store = get_hook_store()

    if store.remove_hook(event, matcher, index):
        console.print(f"[green]Removed hook for {event}/{matcher}.[/green]")
    else:
        console.print(f"[red]Hook not found for {event}/{matcher}.[/red]")
        raise typer.Exit(1)


@hook_app.command("test")
def hook_test(
    event: str = typer.Option(..., "--event", "-e", help="Event to trigger"),
    tool_name: str = typer.Option("", "--tool", "-t", help="Tool name to match"),
    tool_input_json: str = typer.Option("{}", "--input", "-i", help="Tool input as JSON"),
):
    """Test hook execution for a given event."""
    import json
    from superagent.hooks import get_hook_store
    store = get_hook_store()

    try:
        tool_input = json.loads(tool_input_json)
    except json.JSONDecodeError:
        console.print("[red]Invalid JSON for --input[/red]")
        raise typer.Exit(1)

    results = store.execute_hooks(event, tool_name=tool_name, tool_input=tool_input)

    if not results:
        console.print("[dim]No hooks matched this event/tool combination.[/dim]")
        return

    for i, result in enumerate(results):
        status = "[green]continue[/green]" if result.decision == "continue" else "[red]BLOCK[/red]"
        console.print(Panel(
            f"Success: {result.success}\n"
            f"Decision: {status}\n"
            f"Output: {result.output[:500]}\n"
            f"Reason: {result.reason or '(none)'}",
            title=f"Hook Result #{i+1}",
            border_style="red" if result.decision == "block" else "green",
        ))
