"""Sub-Agent CLI commands — manage and execute sub-agents.

Commands:
    superagent agent list              — List all registered sub-agents
    superagent agent show <name>       — Show sub-agent details
    superagent agent create <name>     — Create a new sub-agent
    superagent agent delete <name>     — Delete a sub-agent
    superagent agent delegate <task>   — Auto-select best agent for a task
    superagent agent run <name> <task> — Run a sub-agent with a task
    superagent agent seed              — Seed built-in sub-agents
"""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table
from typing import Optional

console = Console()
agent_app = typer.Typer(help="Sub-Agents — delegate tasks to specialized AI agents.")


@agent_app.command("list")
def agent_list():
    """List all registered sub-agents."""
    from superagent.subagent import get_subagent_registry
    registry = get_subagent_registry()
    agents = registry.list_agents()

    if not agents:
        console.print("[dim]No sub-agents registered. Run 'superagent agent seed' to add built-in agents.[/dim]")
        return

    table = Table(title="Sub-Agents", show_header=True, header_style="bold cyan")
    table.add_column("Name", style="green")
    table.add_column("Description", max_width=50)
    table.add_column("Tools", max_width=30)
    table.add_column("Model", style="dim")
    table.add_column("Source", style="dim", max_width=40)

    for agent in agents:
        tools_str = ", ".join(agent.tools) if agent.tools else "(inherit all)"
        source = agent.source_path or "builtin"
        table.add_row(
            agent.name,
            agent.description[:50],
            tools_str,
            agent.model,
            source[:40],
        )

    console.print(table)


@agent_app.command("show")
def agent_show(name: str = typer.Argument(..., help="Agent name")):
    """Show details of a sub-agent."""
    from superagent.subagent import get_subagent_registry
    registry = get_subagent_registry()
    agent = registry.get(name)

    if agent is None:
        console.print(f"[red]Agent '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold green]{agent.name}[/bold green]\n\n"
        f"[bold]Description:[/bold] {agent.description}\n"
        f"[bold]Model:[/bold] {agent.model}\n"
        f"[bold]Permission Mode:[/bold] {agent.permission_mode}\n"
        f"[bold]Tools:[/bold] {', '.join(agent.tools) if agent.tools else '(inherit all)'}\n"
        f"[bold]Skills:[/bold] {', '.join(agent.skills) if agent.skills else '(none)'}\n"
        f"[bold]Source:[/bold] {agent.source_path or 'builtin'}\n\n"
        f"[bold]System Prompt:[/bold]\n{agent.prompt[:2000]}",
        title=f"Sub-Agent: {name}",
    ))


@agent_app.command("create")
def agent_create(
    name: str = typer.Argument(..., help="Agent name (lowercase, hyphens)"),
    description: str = typer.Option("", "--desc", "-d", help="Agent description"),
    prompt: str = typer.Option("", "--prompt", "-p", help="System prompt"),
    tools: str = typer.Option("", "--tools", "-t", help="Comma-separated tool whitelist"),
    model: str = typer.Option("inherit", "--model", "-m", help="Model alias or 'inherit'"),
    scope: str = typer.Option("user", "--scope", help="Scope: user or project"),
):
    """Create a new sub-agent definition."""
    from superagent.subagent import SubAgentDefinition, get_subagent_registry
    registry = get_subagent_registry()

    if registry.get(name):
        console.print(f"[red]Agent '{name}' already exists. Delete it first.[/red]")
        raise typer.Exit(1)

    tools_list = [t.strip() for t in tools.split(",") if t.strip()] if tools else []

    agent = SubAgentDefinition(
        name=name,
        description=description,
        prompt=prompt or f"You are {name}, a specialized AI agent.",
        tools=tools_list,
        model=model,
    )
    registry.create_agent(agent, scope=scope)
    console.print(f"[green]Created sub-agent '{name}' ({scope} scope).[/green]")


@agent_app.command("delete")
def agent_delete(name: str = typer.Argument(..., help="Agent name")):
    """Delete a sub-agent definition."""
    from superagent.subagent import get_subagent_registry
    registry = get_subagent_registry()

    if registry.delete_agent(name):
        console.print(f"[green]Deleted sub-agent '{name}'.[/green]")
    else:
        console.print(f"[red]Agent '{name}' not found.[/red]")
        raise typer.Exit(1)


@agent_app.command("delegate")
def agent_delegate(
    task: str = typer.Argument(..., help="Task description to delegate"),
):
    """Auto-select the best sub-agent for a task."""
    from superagent.subagent import get_subagent_registry
    registry = get_subagent_registry()

    agent = registry.delegate(task)
    if agent is None:
        console.print("[yellow]No suitable sub-agent found for this task.[/yellow]")
        console.print("Available agents: " + ", ".join(a.name for a in registry.list_agents()))
        raise typer.Exit(1)

    console.print(f"[green]Best match: {agent.name}[/green]")
    console.print(f"  Description: {agent.description}")
    console.print(f"  Tools: {', '.join(agent.tools) if agent.tools else '(inherit all)'}")

    # Build the prompt
    prompt = registry.build_agent_prompt(agent.name, task)
    if prompt:
        console.print(Panel(prompt[:1500], title=f"Agent Prompt Preview", border_style="dim"))


@agent_app.command("run")
def agent_run(
    name: str = typer.Argument(..., help="Agent name"),
    task: str = typer.Argument(..., help="Task to assign"),
    background: bool = typer.Option(False, "--bg", help="Run in background"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """Run a sub-agent with a specific task."""
    import asyncio
    from superagent.subagent import get_subagent_registry
    from superagent.llm_gateway import call_llm

    registry = get_subagent_registry()
    agent = registry.get(name)

    if agent is None:
        console.print(f"[red]Agent '{name}' not found.[/red]")
        raise typer.Exit(1)

    # Create execution record
    execution = registry.start_execution(name, task, is_background=background)

    # Build the full prompt
    prompt = registry.build_agent_prompt(name, task)
    if prompt is None:
        console.print(f"[red]Failed to build prompt for agent '{name}'.[/red]")
        raise typer.Exit(1)

    if json_out:
        console.print(f'{{"agent_id": "{execution.agent_id}", "agent": "{name}", "status": "running"}}')

    # Execute via LLM
    registry.update_execution(execution.agent_id, "running")

    try:
        result = asyncio.run(call_llm(prompt, provider="default"))
        registry.update_execution(execution.agent_id, "completed", result=result)

        if json_out:
            import json
            console.print(json.dumps(execution.to_dict(), indent=2, ensure_ascii=False))
        else:
            console.print(Panel(
                result[:5000] if result else "(no output)",
                title=f"Agent: {name} (completed)",
                border_style="green",
            ))
    except Exception as e:
        registry.update_execution(execution.agent_id, "failed", result=str(e))
        if json_out:
            console.print(f'{{"agent_id": "{execution.agent_id}", "status": "failed", "error": "{str(e)}"}}')
        else:
            console.print(f"[red]Agent failed: {e}[/red]")


@agent_app.command("seed")
def agent_seed():
    """Seed built-in sub-agent definitions (code-reviewer, debugger, explorer, test-runner)."""
    from superagent.subagent import seed_builtin_agents
    count = seed_builtin_agents()
    if count > 0:
        console.print(f"[green]Seeded {count} built-in sub-agents.[/green]")
    else:
        console.print("[dim]All built-in agents already exist.[/dim]")
