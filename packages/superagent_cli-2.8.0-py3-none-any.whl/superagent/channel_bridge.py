"""SuperAgent Channel bridge — bidirectional messaging with external platforms.

Inspired by CodeBuddy CLI's Channels feature and OpenClaw's multi-channel
inbox.  Provides:

- Webhook handler for WeCom / DingTalk / Feishu / Generic platforms
- DM pairing with sender allowlist (CodeBuddy / OpenClaw pattern)
- Inbound message queue per session
- Reply routing back through the originating channel

Storage: ``~/.superagent/channels/``
"""

from __future__ import annotations

import dataclasses
import hashlib
import hmac
import json
import logging
import os
import secrets
import threading
import time
import uuid
from collections import deque
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


def _data_dir() -> Path:
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class InboundMessage:
    """A message received from an external channel."""
    id: str
    channel_type: str  # wecom, dingtalk, feishu, telegram, discord, generic
    channel_id: str
    sender_id: str
    sender_name: str
    content: str
    content_type: str = "text"  # text, image, file
    file_path: Optional[str] = None
    timestamp: str = ""
    processed: bool = False
    session_id: Optional[str] = None
    reply_text: Optional[str] = None

    def __post_init__(self):
        if not self.timestamp:
            self.timestamp = datetime.now(timezone.utc).isoformat()

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> InboundMessage:
        return cls(**{k: v for k, v in d.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# Sender authentication — DM pairing
# ---------------------------------------------------------------------------

class SenderAuth:
    """DM pairing flow: unknown senders receive a pairing code,
    approved senders are added to a persistent allowlist."""

    def __init__(self, channel_dir: Path):
        self._dir = channel_dir
        self._allowlist_path = channel_dir / "allowlist.json"
        self._pending: dict[str, tuple[str, str, float]] = {}  # code -> (channel_id, sender_id, expiry)
        self._lock = threading.Lock()

    def _load_allowlist(self) -> dict[str, list[str]]:
        if self._allowlist_path.is_file():
            try:
                return json.loads(self._allowlist_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                pass
        return {}

    def _save_allowlist(self, data: dict[str, list[str]]) -> None:
        self._dir.mkdir(parents=True, exist_ok=True)
        atomic_write(self._allowlist_path, json.dumps(data, indent=2, ensure_ascii=False))

    def is_approved(self, channel_id: str, sender_id: str) -> bool:
        allowlist = self._load_allowlist()
        return sender_id in allowlist.get(channel_id, [])

    def generate_pairing_code(self, channel_id: str, sender_id: str) -> str:
        code = secrets.token_urlsafe(6).upper()
        expiry = time.time() + 600  # 10 minutes
        with self._lock:
            self._pending[code] = (channel_id, sender_id, expiry)
        return code

    def approve_sender(self, code: str) -> Optional[str]:
        with self._lock:
            entry = self._pending.pop(code, None)
        if entry is None:
            return None
        channel_id, sender_id, expiry = entry
        if time.time() > expiry:
            return None
        allowlist = self._load_allowlist()
        allowlist.setdefault(channel_id, [])
        if sender_id not in allowlist[channel_id]:
            allowlist[channel_id].append(sender_id)
        self._save_allowlist(allowlist)
        return sender_id

    def remove_sender(self, channel_id: str, sender_id: str) -> None:
        allowlist = self._load_allowlist()
        if channel_id in allowlist and sender_id in allowlist[channel_id]:
            allowlist[channel_id].remove(sender_id)
            self._save_allowlist(allowlist)


# ---------------------------------------------------------------------------
# Webhook handlers per platform
# ---------------------------------------------------------------------------

class WebhookHandler:
    """Parse inbound messages from different platform webhook payloads."""

    @staticmethod
    def handle_wecom(body: dict, query: dict) -> Optional[InboundMessage]:
        """WeCom callback: URL verification (GET) + message event (POST).

        For GET verification, the caller should handle the echostr response
        separately.  This method only parses POST message payloads.
        """
        # URL verification challenge
        if "EchoStr" in body or "echostr" in query:
            return None  # handled at the API layer

        # Message event
        content = ""
        sender_id = ""
        sender_name = ""
        msg_type = "text"

        # WeCom XML-like JSON format
        if "Content" in body:
            content = body["Content"]
            sender_id = body.get("FromUserName", "")
            sender_name = body.get("FromUserName", "")
        elif "event" in body:
            evt = body["event"]
            if isinstance(evt, dict):
                content = evt.get("content", str(evt))
                sender_id = evt.get("user_id", "")

        if not content:
            return None

        return InboundMessage(
            id=str(uuid.uuid4()),
            channel_type="wecom",
            channel_id="wecom",
            sender_id=sender_id,
            sender_name=sender_name,
            content=content,
            content_type=msg_type,
        )

    @staticmethod
    def handle_dingtalk(body: dict) -> Optional[InboundMessage]:
        """DingTalk robot callback message."""
        msg = body.get("text", {})
        content = msg.get("content", "")
        sender_id = body.get("senderStaffId", body.get("senderId", ""))
        sender_name = body.get("senderNick", "")

        if not content:
            return None

        return InboundMessage(
            id=str(uuid.uuid4()),
            channel_type="dingtalk",
            channel_id="dingtalk",
            sender_id=sender_id,
            sender_name=sender_name,
            content=content.strip(),
        )

    @staticmethod
    def handle_feishu(body: dict, query: dict) -> Optional[InboundMessage]:
        """Feishu event callback: URL verification + message event."""
        # URL verification challenge
        if body.get("type") == "url_verification":
            return None  # handled at API layer

        # Event message
        event = body.get("event", {})
        msg = event.get("message", {})
        content_str = msg.get("content", "{}")

        try:
            content_obj = json.loads(content_str) if isinstance(content_str, str) else content_str
            text = content_obj.get("text", "")
        except (json.JSONDecodeError, AttributeError):
            text = content_str if isinstance(content_str, str) else str(content_obj)

        sender_id = event.get("sender", {}).get("sender_id", {}).get("user_id", "")
        sender_name = event.get("sender", {}).get("sender_id", {}).get("user_id", "")

        if not text:
            return None

        return InboundMessage(
            id=str(uuid.uuid4()),
            channel_type="feishu",
            channel_id="feishu",
            sender_id=sender_id,
            sender_name=sender_name,
            content=text.strip(),
        )

    @staticmethod
    def handle_generic(body: dict) -> Optional[InboundMessage]:
        """Generic webhook: accepts {text, sender_id, sender_name}."""
        text = body.get("text", body.get("content", ""))
        sender_id = body.get("sender_id", body.get("from", "unknown"))
        sender_name = body.get("sender_name", body.get("name", sender_id))

        if not text:
            return None

        return InboundMessage(
            id=str(uuid.uuid4()),
            channel_type="generic",
            channel_id="generic",
            sender_id=str(sender_id),
            sender_name=str(sender_name),
            content=str(text),
        )


    @staticmethod
    def dispatch(platform: str, body: dict, query: Optional[dict] = None) -> Optional[InboundMessage]:
        """Route a webhook to the correct platform handler."""
        query = query or {}
        handler = {
            "wecom": WebhookHandler.handle_wecom,
            "dingtalk": lambda b, q: WebhookHandler.handle_dingtalk(b),
            "feishu": WebhookHandler.handle_feishu,
            "generic": lambda b, q: WebhookHandler.handle_generic(b),
        }.get(platform, lambda b, q: WebhookHandler.handle_generic(b))
        return handler(body, query)


# ---------------------------------------------------------------------------
# Channel configuration model
# ---------------------------------------------------------------------------

@dataclasses.dataclass
class ChannelConfig:
    """Per-channel configuration."""
    type: str  # wecom, dingtalk, feishu, telegram, discord, generic
    token: str = ""
    aes_key: str = ""
    corp_id: str = ""
    webhook_secret: str = ""
    api_base: str = ""
    enabled: bool = True
    extra: dict = dataclasses.field(default_factory=dict)

    def to_dict(self) -> dict:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, d: dict) -> ChannelConfig:
        fields = {f.name for f in dataclasses.fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in fields})


# ---------------------------------------------------------------------------
# Channel bridge — the main orchestrator
# ---------------------------------------------------------------------------

class ChannelBridge:
    """Manages bidirectional messaging between external platforms and
    SuperAgent sessions.

    Usage::

        bridge = ChannelBridge()
        bridge.register_channel("wecom", {"token": "...", "aes_key": "..."})
        msg = bridge.handle_inbound("wecom", body, query)
        if msg and not bridge.is_approved("wecom", msg.sender_id):
            code = bridge.request_pairing("wecom", msg.sender_id)
            # send pairing code back to user
        ...
        bridge.send_reply("wecom", user_id, "Hello!")
    """

    MAX_QUEUE_SIZE = 100

    def __init__(self, data_dir: Optional[Path] = None):
        base = Path(data_dir) if data_dir else _data_dir()
        self._dir = base / "channels"
        self._dir.mkdir(parents=True, exist_ok=True)
        self._channels: dict[str, dict] = {}
        self._auths: dict[str, SenderAuth] = {}
        self._queues: dict[str, deque[InboundMessage]] = {}
        self._lock = threading.Lock()
        self._webhook = WebhookHandler()
        self._load_config()

    # -- Configuration -------------------------------------------------------

    def _config_path(self) -> Path:
        return self._dir / "config.json"

    def _load_config(self) -> None:
        path = self._config_path()
        if path.is_file():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                for cid, cfg in data.get("channels", {}).items():
                    self._channels[cid] = cfg
                    self._auths[cid] = SenderAuth(self._dir / cid)
            except (json.JSONDecodeError, OSError) as exc:
                logger.warning("Failed to load channel config: %s", exc)

    def _save_config(self) -> None:
        data = {"channels": {cid: cfg for cid, cfg in self._channels.items()}}
        atomic_write(self._config_path(), json.dumps(data, indent=2, ensure_ascii=False))

    # -- Channel management --------------------------------------------------

    def register_channel(self, channel_id: str, config: dict) -> ChannelConfig:
        """Register a new channel or update an existing one.

        Parameters
        ----------
        channel_id:
            Unique channel identifier (e.g. "wecom-main").
        config:
            Dict with channel configuration fields.  The ``type`` key is
            required and must be one of the supported platform types.

        Returns
        -------
        ChannelConfig
            The created or updated channel configuration.
        """
        cfg = ChannelConfig(type=config.get("type", channel_id.split("-")[0]), **{k: v for k, v in config.items() if k != "type"})
        with self._lock:
            self._channels[channel_id] = cfg.to_dict()
            self._auths[channel_id] = SenderAuth(self._dir / channel_id)
        self._save_config()
        logger.info("Channel registered: %s", channel_id)
        return cfg

    def unregister_channel(self, channel_id: str) -> None:
        """Remove a channel."""
        with self._lock:
            self._channels.pop(channel_id, None)
            self._auths.pop(channel_id, None)
            self._queues.pop(channel_id, None)
        self._save_config()
        logger.info("Channel unregistered: %s", channel_id)

    def list_channels(self) -> list[dict]:
        """Return all registered channels with their config."""
        result = []
        for cid, cfg in self._channels.items():
            entry = {"id": cid, **cfg}
            auth = self._auths.get(cid)
            if auth:
                allowlist = auth._load_allowlist()
                entry["approved_senders"] = len(allowlist.get(cid, []))
            result.append(entry)
        return result

    # -- Inbound processing --------------------------------------------------

    def handle_inbound(
        self,
        channel_type: str,
        body: dict,
        query: Optional[dict] = None,
    ) -> Optional[InboundMessage]:
        """Parse an inbound webhook payload and queue the message.

        Returns the InboundMessage if parsing succeeded, or None.
        If the sender is not approved, the message is still queued but
        the caller should request pairing.
        """
        query = query or {}
        handler = {
            "wecom": self._webhook.handle_wecom,
            "dingtalk": self._webhook.handle_dingtalk,
            "feishu": self._webhook.handle_feishu,
            "generic": self._webhook.handle_generic,
        }.get(channel_type, self._webhook.handle_generic)

        try:
            if channel_type == "wecom":
                msg = handler(body, query)
            elif channel_type == "feishu":
                msg = handler(body, query)
            elif channel_type == "dingtalk":
                msg = handler(body)
            else:
                msg = handler(body)
        except Exception as exc:
            logger.error("Webhook parse error (%s): %s", channel_type, exc)
            return None

        if msg is None:
            return None

        # Override channel_id from config if available
        for cid, cfg in self._channels.items():
            if cfg.get("type") == channel_type:
                msg.channel_id = cid
                break

        # Check sender approval
        if not self.is_approved(msg.channel_id, msg.sender_id):
            # Auto-generate pairing code for unapproved senders
            code = self.request_pairing(msg.channel_id, msg.sender_id)
            msg.reply_text = (
                f"Your pairing code is: {code}\n"
                f"Please approve in SuperAgent to continue."
            )
            logger.info("Pairing code %s generated for %s/%s", code, msg.channel_id, msg.sender_id)

        # Queue the message
        self._enqueue(msg)
        return msg

    def handle_webhook(
        self,
        platform: str,
        body: dict,
        query: Optional[dict] = None,
    ) -> Optional[InboundMessage]:
        """Convenience method: dispatch + inbound in one call."""
        msg = WebhookHandler.dispatch(platform, body, query)
        if msg is None:
            return None
        # Override channel_id from config if available
        for cid, cfg in self._channels.items():
            if cfg.get("type") == platform:
                msg.channel_id = cid
                break
        # Check sender approval
        if not self.is_approved(msg.channel_id, msg.sender_id):
            code = self.request_pairing(msg.channel_id, msg.sender_id)
            msg.reply_text = (
                f"Your pairing code is: {code}\n"
                f"Please approve in SuperAgent to continue."
            )
        self._enqueue(msg)
        return msg

    def get_channel(self, channel_id: str) -> Optional[dict]:
        """Get a specific channel's configuration."""
        return self._channels.get(channel_id)

    # -- Sender authentication ----------------------------------------------

    def is_approved(self, channel_id: str, sender_id: str) -> bool:
        """Check if a sender is on the approved list."""
        auth = self._auths.get(channel_id)
        if auth is None:
            return False
        return auth.is_approved(channel_id, sender_id)

    def request_pairing(self, channel_id: str, sender_id: str) -> str:
        """Generate a pairing code for a new sender."""
        auth = self._auths.get(channel_id)
        if auth is None:
            auth = SenderAuth(self._dir / channel_id)
            self._auths[channel_id] = auth
        return auth.generate_pairing_code(channel_id, sender_id)

    def approve_sender(self, code: str) -> Optional[str]:
        """Approve a sender by pairing code. Returns sender_id or None."""
        # Try all auth instances
        for auth in self._auths.values():
            result = auth.approve_sender(code)
            if result is not None:
                return result
        return None

    # -- Message queue -------------------------------------------------------

    def _enqueue(self, msg: InboundMessage) -> None:
        key = msg.channel_id
        with self._lock:
            if key not in self._queues:
                self._queues[key] = deque(maxlen=self.MAX_QUEUE_SIZE)
            self._queues[key].append(msg)

    def get_pending_messages(
        self, channel_id: Optional[str] = None, limit: int = 50,
    ) -> list[InboundMessage]:
        """Get unprocessed messages, optionally filtered by channel."""
        result: list[InboundMessage] = []
        with self._lock:
            queues = (
                {channel_id: self._queues[channel_id]}
                if channel_id and channel_id in self._queues
                else dict(self._queues)
            )
            for _, q in queues.items():
                for msg in q:
                    if not msg.processed:
                        result.append(msg)
                        if len(result) >= limit:
                            return result
        return result

    def mark_processed(self, message_id: str) -> None:
        """Mark a message as processed after it has been handled."""
        with self._lock:
            for q in self._queues.values():
                for msg in q:
                    if msg.id == message_id:
                        msg.processed = True
                        return

    # -- Outbound reply ------------------------------------------------------

    def send_reply(
        self,
        channel_id: str,
        user_id: str,
        text: str,
        file_path: Optional[str] = None,
    ) -> dict:
        """Send a reply back through a channel.

        For webhook-based channels, this returns the response payload
        that should be sent in the HTTP response body.
        For other channels, this would trigger the actual send.
        """
        cfg = self._channels.get(channel_id, {})
        channel_type = cfg.get("type", channel_id)

        reply = {
            "channel_id": channel_id,
            "channel_type": channel_type,
            "user_id": user_id,
            "text": text,
            "file_path": file_path,
            "timestamp": datetime.now(timezone.utc).isoformat(),
        }

        # Platform-specific reply formatting
        if channel_type == "wecom":
            reply["reply_format"] = "xml"  # WeCom expects XML response
        elif channel_type == "dingtalk":
            reply["reply_format"] = "json"
            reply["payload"] = {"msgtype": "text", "text": {"content": text}}
        elif channel_type == "feishu":
            reply["reply_format"] = "json"
            reply["payload"] = {"msg_type": "text", "content": json.dumps({"text": text})}

        logger.info("Reply sent via %s to %s", channel_id, user_id)
        return reply


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_instance: Optional[ChannelBridge] = None


def get_channel_bridge(data_dir: Optional[Path] = None) -> ChannelBridge:
    """Return the global ChannelBridge singleton."""
    global _instance
    if _instance is None:
        _instance = ChannelBridge(data_dir=data_dir)
    return _instance
