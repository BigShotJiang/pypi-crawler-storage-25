"""Browser automation for SuperAgent — powered by browser-use (86k stars).

Enables agents to browse the web, fill forms, scrape data, and automate web tasks.
"""
from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)

_BROWSER_USE_AVAILABLE = False
try:
    from browser_use import Agent as BrowserAgent
    _BROWSER_USE_AVAILABLE = True
except ImportError:
    logger.debug("browser-use not installed: pip install browser-use")


def is_browser_available() -> bool:
    return _BROWSER_USE_AVAILABLE


async def _run_browser_task(task: str, model: str = "deepseek", max_steps: int = 15) -> dict:
    """Run a browser task using browser-use Agent."""
    if not _BROWSER_USE_AVAILABLE:
        return {"success": False, "error": "browser-use not installed. Run: pip install browser-use"}

    try:
        # browser-use needs an LLM - use langchain_openai compatible
        from langchain_openai import ChatOpenAI

        # Resolve model/API from superagent config
        from superagent.llm_gateway import LLMGateway, get_llm_gateway
        gw = get_llm_gateway()

        # Try to find a provider with API key
        llm = None
        for provider in gw.list_providers():
            api_key = LLMGateway.resolve_api_key(provider)
            if api_key:
                llm = ChatOpenAI(
                    model=provider.default_model,
                    api_key=api_key,
                    base_url=provider.base_url,
                    timeout=120,
                )
                logger.info("Browser agent using provider: %s", provider.name)
                break

        if llm is None:
            return {"success": False, "error": "No LLM provider with API key configured"}

        agent = BrowserAgent(task=task, llm=llm, max_steps=max_steps)
        result = await agent.run()

        return {
            "success": True,
            "output": str(result),
            "engine": "browser-use",
            "error": None,
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "engine": "browser-use",
            "error": str(e),
        }


def browse(task: str, max_steps: int = 15) -> dict:
    """Synchronous wrapper for browser task execution."""
    return asyncio.run(_run_browser_task(task, max_steps=max_steps))
