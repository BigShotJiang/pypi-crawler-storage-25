"""SQLite + FTS5 backend for SuperAgent — shared database for memory and wiki.

Provides a single WAL-mode SQLite database at ``~/.superagent/superagent.db``
with full-text search indexes via FTS5.  Used by ``memory.py`` and ``wiki.py``
as a drop-in replacement for JSON file storage.

Hermes Agent pattern: SQLite + FTS5 gives concurrent reads (WAL), ACID
transactions, and sub-millisecond full-text search without external services.
"""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import threading
from pathlib import Path

logger = logging.getLogger(__name__)

_DB_FILENAME = "superagent.db"

# ---------------------------------------------------------------------------
# Schema
# ---------------------------------------------------------------------------

_SCHEMA_SQL = """
-- Memory entries
CREATE TABLE IF NOT EXISTS memories (
    id TEXT PRIMARY KEY,
    content TEXT NOT NULL,
    tags TEXT DEFAULT '[]',
    scope TEXT DEFAULT 'global',
    agent_name TEXT,
    team_name TEXT,
    layer TEXT DEFAULT 'persistent',
    user_id TEXT DEFAULT '',
    created_at TEXT,
    updated_at TEXT,
    expires_at TEXT,
    revoked INTEGER DEFAULT 0
);

-- Wiki pages (search index; .md files stay on disk)
CREATE TABLE IF NOT EXISTS wiki_pages (
    path TEXT PRIMARY KEY,
    title TEXT,
    page_type TEXT,
    status TEXT,
    confidence REAL DEFAULT 0.5,
    confidence_level TEXT DEFAULT 'inferred',
    tags TEXT DEFAULT '[]',
    summary TEXT,
    body TEXT,
    source_ids TEXT DEFAULT '[]',
    related TEXT DEFAULT '[]',
    wiki_links TEXT DEFAULT '[]',
    created_at TEXT,
    updated_at TEXT
);

-- Audit log
CREATE TABLE IF NOT EXISTS audit_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    operation TEXT,
    memory_id TEXT,
    actor TEXT DEFAULT 'system',
    user_id TEXT DEFAULT '',
    details TEXT
);

-- Persistent run records
CREATE TABLE IF NOT EXISTS runs (
    id TEXT PRIMARY KEY,
    user_id TEXT DEFAULT '',
    text TEXT NOT NULL,
    sender TEXT DEFAULT '{}',
    status TEXT DEFAULT 'accepted',
    result TEXT,
    error TEXT,
    created_at TEXT,
    started_at TEXT,
    completed_at TEXT
);

-- Session transcripts
CREATE TABLE IF NOT EXISTS transcripts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id TEXT NOT NULL,
    user_id TEXT DEFAULT '',
    role TEXT NOT NULL,
    content TEXT NOT NULL,
    metadata TEXT DEFAULT '{}',
    created_at TEXT
);

-- Schema version tracking
CREATE TABLE IF NOT EXISTS schema_version (
    key TEXT PRIMARY KEY,
    value TEXT
);
"""

_FTS_SCHEMA_SQL = """
-- FTS5 for memory search (standalone, not content-synced)
CREATE VIRTUAL TABLE IF NOT EXISTS memories_fts USING fts5(
    id, content, tags
);

-- FTS5 for wiki search (standalone)
CREATE VIRTUAL TABLE IF NOT EXISTS wiki_fts USING fts5(
    path, title, tags, body, summary
);
"""

_FTS_TRIGGERS_SQL = ""  # No triggers needed — we manage FTS manually


# ---------------------------------------------------------------------------
# Connection management
# ---------------------------------------------------------------------------

_connections: dict[str, sqlite3.Connection] = {}
_locks: dict[str, threading.Lock] = {}
_global_lock = threading.Lock()  # Guards _locks dict creation to prevent TOCTOU races


def _get_data_dir() -> Path:
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


def get_db(db_path: str | None = None) -> sqlite3.Connection:
    """Get or create a singleton SQLite connection with WAL mode and FTS5.

    Thread-safe: connection creation is guarded by a per-path lock to
    prevent race conditions when multiple threads request the same
    database concurrently.

    Parameters
    ----------
    db_path:
        Override the database file path (useful for testing).
        Defaults to ``~/.superagent/superagent.db``.
    """
    if db_path is None:
        db_path = str(_get_data_dir() / _DB_FILENAME)

    # Fast path — already initialised
    if db_path in _connections:
        return _connections[db_path]

    # Ensure a lock exists for this path (thread-safe via global lock)
    with _global_lock:
        if db_path not in _locks:
            _locks[db_path] = threading.Lock()
        lock = _locks[db_path]
    with lock:
        # Double-check after acquiring lock
        if db_path in _connections:
            return _connections[db_path]

        os.makedirs(os.path.dirname(db_path), exist_ok=True)
        conn = sqlite3.connect(db_path, check_same_thread=False)
        conn.row_factory = sqlite3.Row
        conn.execute("PRAGMA journal_mode=WAL")
        conn.execute("PRAGMA synchronous=NORMAL")
        conn.execute("PRAGMA foreign_keys=ON")

        init_db(conn)

        _connections[db_path] = conn
        logger.info("SQLite database opened: %s", db_path)
        return conn


def init_db(conn: sqlite3.Connection) -> None:
    """Create tables, FTS indexes, and triggers if they don't exist."""
    conn.executescript(_SCHEMA_SQL)

    # FTS5 requires separate creation (can't be in executescript with IF NOT EXISTS
    # on some SQLite versions, so we catch errors gracefully)
    for stmt in _FTS_SCHEMA_SQL.strip().split(";"):
        stmt = stmt.strip()
        if stmt:
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError:
                pass  # table already exists

    for stmt in _FTS_TRIGGERS_SQL.strip().split(";"):
        stmt = stmt.strip()
        if stmt:
            try:
                conn.execute(stmt)
            except sqlite3.OperationalError:
                pass  # trigger already exists

    conn.commit()

    # Migration: add user_id to legacy tables if missing
    _migrate_add_user_id(conn)

    # Record schema version
    conn.execute(
        "INSERT OR IGNORE INTO schema_version (key, value) VALUES (?, ?)",
        ("version", "2"),
    )
    conn.commit()


def _migrate_add_user_id(conn: sqlite3.Connection) -> None:
    """Add user_id column to tables that lack it. Idempotent."""
    for table in ("memories", "audit_log"):
        try:
            columns = [row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()]
            if "user_id" not in columns:
                conn.execute(f"ALTER TABLE {table} ADD COLUMN user_id TEXT DEFAULT ''")
                logger.info("Added user_id column to %s", table)
        except sqlite3.OperationalError:
            pass  # table may not exist yet


def close_db(db_path: str | None = None) -> None:
    """Close the database connection (for testing cleanup)."""
    if db_path is None:
        db_path = str(_get_data_dir() / _DB_FILENAME)
    conn = _connections.pop(db_path, None)
    if conn:
        conn.close()
    _locks.pop(db_path, None)


# ---------------------------------------------------------------------------
# Migration helpers
# ---------------------------------------------------------------------------


def migrate_memory_from_json(conn: sqlite3.Connection, memory_dir: str) -> int:
    """Import existing JSON memory files into the SQLite memories table.

    Returns the number of entries imported.
    """
    memory_path = Path(memory_dir)
    if not memory_path.is_dir():
        return 0

    marker = memory_path / ".migrated_to_sqlite"
    if marker.exists():
        return 0

    count = 0
    for scope_dir in memory_path.iterdir():
        if not scope_dir.is_dir() or scope_dir.name.startswith("."):
            continue
        for json_file in scope_dir.rglob("*.json"):
            if json_file.name == "audit_log.jsonl":
                continue
            try:
                data = json.loads(json_file.read_text(encoding="utf-8"))
                conn.execute(
                    """INSERT OR IGNORE INTO memories
                       (id, content, tags, scope, agent_name, team_name, layer,
                        created_at, updated_at, expires_at, revoked)
                       VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                    (
                        data.get("id", json_file.stem),
                        data.get("content", ""),
                        json.dumps(data.get("tags", [])),
                        data.get("scope", "global"),
                        data.get("agent_name"),
                        data.get("team_name"),
                        data.get("layer", "persistent"),
                        data.get("created_at", ""),
                        data.get("updated_at", ""),
                        data.get("expires_at"),
                        1 if json_file.suffix == ".revoked" else 0,
                    ),
                )
                count += 1
            except (json.JSONDecodeError, OSError):
                continue

    if count > 0:
        conn.commit()
        marker.write_text(f"Migrated {count} entries to SQLite\n")
        logger.info("Migrated %d memory entries from JSON to SQLite", count)

    return count


def migrate_wiki_from_files(conn: sqlite3.Connection, wiki_base_dir: str) -> int:
    """Index existing wiki .md files into the SQLite wiki_pages table.

    Returns the number of pages indexed.
    """
    import re

    wiki_path = Path(wiki_base_dir) / "wiki"
    if not wiki_path.is_dir():
        return 0

    marker = Path(wiki_base_dir) / ".wiki_indexed"
    if marker.exists():
        return 0

    count = 0
    for md_file in wiki_path.rglob("*.md"):
        if md_file.name in ("index.md", "log.md"):
            continue
        rel_path = str(md_file.relative_to(Path(wiki_base_dir)))
        try:
            text = md_file.read_text(encoding="utf-8")
            # Parse frontmatter
            meta: dict = {}
            body = text
            match = re.match(r"^---\n(.*?)\n---\n", text, re.DOTALL)
            if match:
                body = text[match.end():]
                for line in match.group(1).splitlines():
                    if ":" in line:
                        k, _, v = line.partition(":")
                        k, v = k.strip(), v.strip()
                        if v.startswith("[") and v.endswith("]"):
                            meta[k] = v
                        else:
                            meta[k] = v.strip("'\"")

            conn.execute(
                """INSERT OR IGNORE INTO wiki_pages
                   (path, title, page_type, status, confidence, confidence_level,
                    tags, summary, body, source_ids, related, wiki_links,
                    created_at, updated_at)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    rel_path,
                    meta.get("title", md_file.stem),
                    meta.get("type", "entity"),
                    meta.get("status", "draft"),
                    float(meta.get("confidence", 0.5)),
                    meta.get("confidence_level", "inferred"),
                    meta.get("tags", "[]"),
                    meta.get("summary_l0", ""),
                    body.strip()[:5000],
                    meta.get("source_ids", "[]"),
                    meta.get("related", "[]"),
                    json.dumps(re.findall(r"\[\[([^\]]+)\]\]", text)),
                    meta.get("created", ""),
                    meta.get("updated", ""),
                ),
            )
            count += 1
        except (OSError, ValueError):
            continue

    if count > 0:
        conn.commit()
        marker = Path(wiki_base_dir) / ".wiki_indexed"
        marker.write_text(f"Indexed {count} wiki pages into SQLite\n")
        logger.info("Indexed %d wiki pages into SQLite", count)

    return count
