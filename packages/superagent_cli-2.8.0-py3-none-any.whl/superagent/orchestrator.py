"""Orchestrator for SuperAgent — one sentence to full team automation.

`superagent auto "Build a todo app with auth"` will:
1. Analyze the goal and select the best team template + role prompts
2. Generate a dynamic TOML team template
3. Launch the team via ClawTeam's launch machinery
4. Monitor and report progress
"""

from __future__ import annotations

import json
import os
import re
import uuid
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Optional

from superagent.logger import get_logger
from superagent.roles import RoleTemplate, get_role_index

logger = get_logger(__name__)


# ---------------------------------------------------------------------------
# Goal → Team plan mapping (rule-based, no LLM needed)
# ---------------------------------------------------------------------------

class PermissionLevel:
    """Agent permission levels inspired by OpenCode's plan/build/explore isolation."""
    PLAN = "plan"          # Read-only: analyze, search, plan (no file writes)
    BUILD = "build"        # Full access: read, write, execute
    EXPLORE = "explore"    # Search only: grep, glob, read (no write, no execute)
    REVIEW = "review"      # Read + comment (no write, no execute)


@dataclass
class AgentPlan:
    """Plan for a single agent in the team."""
    name: str
    role: str
    task: str
    role_template: Optional[RoleTemplate] = None
    blocked_by: list[str] = field(default_factory=list)
    permission_level: str = "build"


@dataclass
class TeamPlan:
    """Complete plan for a team to execute a goal."""
    goal: str
    team_name: str
    leader: AgentPlan
    workers: list[AgentPlan]
    template_name: str = "auto"

    @property
    def all_agents(self) -> list[AgentPlan]:
        return [self.leader] + self.workers


# ---------------------------------------------------------------------------
# Task category detection
# ---------------------------------------------------------------------------

_CATEGORY_PATTERNS: dict[str, list[str]] = {
    "web-fullstack": [
        r"web\s*app", r"full[-\s]*stack", r"frontend.*backend", r"react",
        r"vue", r"angular", r"next\.?js", r"website", r"dashboard",
        r"todo\s*app", r"saas", r"landing\s*page", r"admin\s*panel",
    ],
    "backend-api": [
        r"api", r"rest\s*ful", r"graphql", r"microservice", r"server",
        r"database", r"postgres", r"mysql", r"redis", r"auth",
    ],
    "data-analysis": [
        r"data\s*analy", r"machine\s*learn", r"model", r"train",
        r"dataset", r"visualization", r"pandas", r"notebook",
        r"predict", r"classif", r"regress",
    ],
    "mobile-app": [
        r"mobile", r"android", r"ios", r"react\s*native", r"flutter",
        r"swift", r"kotlin",
    ],
    "devops-infra": [
        r"deploy", r"docker", r"kubernetes", r"ci\s*/?\s*cd", r"terraform",
        r"aws", r"cloud", r"infrastructure", r"monitor",
    ],
    "content-marketing": [
        r"content", r"marketing", r"seo", r"blog", r"social\s*media",
        r"brand", r"campaign", r"copywrite",
    ],
    "research": [
        r"research", r"paper", r"survey", r"analyz", r"study",
        r"report", r"investig", r"benchmark",
    ],
}


_CATEGORY_COMPILED_PATTERNS = {
    cat: [re.compile(p, re.IGNORECASE) for p in patterns]
    for cat, patterns in _CATEGORY_PATTERNS.items()
}

def detect_category(goal: str) -> str:
    """Detect the task category from a goal description."""
    scores: dict[str, int] = {}
    for category, patterns in _CATEGORY_COMPILED_PATTERNS.items():
        score = sum(1 for p in patterns if p.search(goal))
        if score > 0:
            scores[category] = score
    if not scores:
        return "general"  # no regex match — use LLM or generic fallback
    return max(scores, key=scores.get)


# ---------------------------------------------------------------------------
# Team composition templates per category
# ---------------------------------------------------------------------------

_TEAM_COMPOSITIONS: dict[str, list[dict[str, str]]] = {
    "web-fullstack": [
        {"name": "tech-lead", "search": "software architect senior developer", "type": "leader", "permission": "plan"},
        {"name": "backend-dev", "search": "backend architect api database", "type": "worker", "permission": "build"},
        {"name": "frontend-dev", "search": "frontend developer react UI", "type": "worker", "permission": "build"},
        {"name": "qa-engineer", "search": "evidence collector testing QA", "type": "worker", "permission": "review"},
    ],
    "backend-api": [
        {"name": "tech-lead", "search": "backend architect api", "type": "leader", "permission": "plan"},
        {"name": "api-dev", "search": "backend architect database", "type": "worker", "permission": "build"},
        {"name": "security-eng", "search": "security engineer", "type": "worker", "permission": "build"},
        {"name": "tester", "search": "api tester testing", "type": "worker", "permission": "review"},
    ],
    "data-analysis": [
        {"name": "lead-analyst", "search": "data engineer analysis", "type": "leader", "permission": "plan"},
        {"name": "data-eng", "search": "data engineer pipeline", "type": "worker", "permission": "build"},
        {"name": "ml-eng", "search": "ai engineer machine learning", "type": "worker", "permission": "build"},
    ],
    "mobile-app": [
        {"name": "tech-lead", "search": "mobile app builder", "type": "leader", "permission": "plan"},
        {"name": "mobile-dev", "search": "mobile app builder frontend", "type": "worker", "permission": "build"},
        {"name": "backend-dev", "search": "backend architect api", "type": "worker", "permission": "build"},
        {"name": "qa-engineer", "search": "evidence collector testing", "type": "worker", "permission": "review"},
    ],
    "devops-infra": [
        {"name": "infra-lead", "search": "devops automator infrastructure", "type": "leader", "permission": "plan"},
        {"name": "devops-eng", "search": "devops automator ci cd", "type": "worker", "permission": "build"},
        {"name": "sre", "search": "sre reliability monitoring", "type": "worker", "permission": "build"},
    ],
    "content-marketing": [
        {"name": "marketing-lead", "search": "growth hacker marketing", "type": "leader", "permission": "plan"},
        {"name": "content-creator", "search": "content creator writing", "type": "worker", "permission": "build"},
        {"name": "seo-specialist", "search": "seo specialist search", "type": "worker", "permission": "build"},
    ],
    "research": [
        {"name": "lead-researcher", "search": "senior developer research", "type": "leader", "permission": "plan"},
        {"name": "researcher-1", "search": "data engineer analysis", "type": "worker", "permission": "build"},
        {"name": "writer", "search": "technical writer documentation", "type": "worker", "permission": "build"},
    ],
    "general": [
        {"name": "strategist", "search": "strategy consultant planning", "type": "leader", "permission": "plan"},
        {"name": "executor-1", "search": "growth hacker marketing sales", "type": "worker", "permission": "build"},
        {"name": "executor-2", "search": "content creator writing", "type": "worker", "permission": "build"},
    ],
}


def plan_team(
    goal: str,
    max_agents: int = 5,
    team_name: Optional[str] = None,
    use_llm: bool = False,
) -> TeamPlan:
    """Create a team plan from a goal description.

    When *use_llm* is True or no regex category matches, the orchestrator
    calls an LLM to analyze the goal and dynamically select roles from the
    178-role index.  Falls back to template-based planning when the LLM is
    unavailable.
    """
    category = detect_category(goal)

    if team_name is None:
        team_name = f"auto-{uuid.uuid4().hex[:6]}"

    # Fast path: regex matched a known category and LLM not forced
    if category != "general" and not use_llm:
        return _plan_from_template(goal, category, max_agents, team_name)

    # Smart path: use LLM to pick roles dynamically
    try:
        return _plan_with_llm(goal, max_agents, team_name)
    except Exception as exc:
        logger.warning("LLM planning failed (%s), falling back to template", exc)
        fallback = category if category != "general" else "general"
        return _plan_from_template(goal, fallback, max_agents, team_name)


def _plan_from_template(
    goal: str, category: str, max_agents: int, team_name: str,
) -> TeamPlan:
    """Build a TeamPlan from a hardcoded category template."""
    composition = _TEAM_COMPOSITIONS.get(category, _TEAM_COMPOSITIONS["general"])
    idx = get_role_index()
    leader_plan = None
    worker_plans: list[AgentPlan] = []

    for spec in composition[:max_agents]:
        results = idx.search(spec["search"], limit=1)
        role_template = results[0][0] if results else None
        role_name = role_template.name if role_template else spec["name"]

        agent = AgentPlan(
            name=spec["name"],
            role=role_name,
            task="",
            role_template=role_template,
            permission_level=spec.get("permission", "build"),
        )

        if spec["type"] == "leader":
            leader_plan = agent
        else:
            worker_plans.append(agent)

    if leader_plan is None:
        leader_plan = AgentPlan(name="leader", role="Tech Lead", task="", permission_level="plan")

    return TeamPlan(
        goal=goal,
        team_name=team_name,
        leader=leader_plan,
        workers=worker_plans,
        template_name=category,
    )


def _plan_with_llm(
    goal: str, max_agents: int, team_name: str,
) -> TeamPlan:
    """Use an LLM to analyze the goal and dynamically compose a team.

    Provides the LLM with the available role divisions and asks it to
    return a JSON team composition.  Each member's ``role_search`` field
    is then used to find the best matching role template from the index.
    """
    from superagent.llm_gateway import call_llm, get_llm_gateway

    # Resolve provider: use default from gateway, fallback to deepseek
    gw = get_llm_gateway()
    default_provider = gw.get_default()
    provider_name = default_provider.name if default_provider else "deepseek"

    idx = get_role_index()
    divisions = idx.divisions
    # Build a compact role catalog for the prompt
    role_samples: list[str] = []
    for div in divisions:
        roles_in_div = [r.name for r in idx.list_roles(division=div)][:5]
        role_samples.append(f"  {div}: {', '.join(roles_in_div)}")
    role_catalog = "\n".join(role_samples)

    prompt = (
        "You are a team orchestrator. Given a goal, select the best team composition.\n\n"
        "## Complexity-Adaptive Scaling Rules (Mythos pattern)\n"
        "- Simple fact-finding or single-skill tasks: 1 leader only (no workers)\n"
        "- Moderate tasks (e.g. build a small app, write a report): 1 leader + 1-2 workers\n"
        "- Complex multi-domain tasks (e.g. launch a product, build a platform): 1 leader + 3-5 workers\n"
        f"- Hard maximum: {max_agents} total members\n\n"
        "Choose the MINIMUM team size needed. Do NOT over-staff simple goals.\n\n"
        f"Available role divisions and example roles:\n{role_catalog}\n\n"
        f"Goal: {goal}\n\n"
        "Return ONLY valid JSON (no markdown fences):\n"
        '{\n'
        '  "category": "short category name",\n'
        '  "complexity": "simple or moderate or complex",\n'
        '  "reasoning": "one sentence why this team size and composition",\n'
        '  "team": [\n'
        '    {"name": "agent-slug", "role_search": "keywords to find role", '
        '"task": "specific task for this agent", "type": "leader or worker", '
        '"permission": "plan or build or review"}\n'
        '  ]\n'
        '}'
    )

    response = call_llm(
        provider_name,
        [{"role": "user", "content": prompt}],
        temperature=0.3,
    )

    # Parse JSON — strip markdown fences if present
    cleaned = response.strip()
    if cleaned.startswith("```"):
        cleaned = re.sub(r"^```[a-z]*\n?", "", cleaned)
        cleaned = re.sub(r"\n?```$", "", cleaned)
    data: dict[str, Any] = json.loads(cleaned)

    category = data.get("category", "smart")
    team_specs: list[dict] = data.get("team", [])

    if not team_specs:
        raise ValueError("LLM returned empty team")

    leader_plan = None
    worker_plans: list[AgentPlan] = []

    for spec in team_specs[:max_agents]:
        search_query = spec.get("role_search", spec.get("name", ""))
        results = idx.search(search_query, limit=1)
        role_template = results[0][0] if results else None
        role_name = role_template.name if role_template else spec.get("name", "agent")

        agent = AgentPlan(
            name=spec.get("name", f"agent-{len(worker_plans)}"),
            role=role_name,
            task=spec.get("task", ""),
            role_template=role_template,
            permission_level=spec.get("permission", "build"),
        )

        if spec.get("type") == "leader" and leader_plan is None:
            leader_plan = agent
        else:
            worker_plans.append(agent)

    if leader_plan is None:
        if worker_plans:
            leader_plan = worker_plans.pop(0)
            leader_plan.permission_level = "plan"
        else:
            leader_plan = AgentPlan(name="leader", role="Strategist", task="", permission_level="plan")

    logger.info(
        "LLM planned team: category=%s complexity=%s leader=%s workers=%d reasoning=%s",
        category, data.get("complexity", "unknown"), leader_plan.role,
        len(worker_plans), data.get("reasoning", ""),
    )

    return TeamPlan(
        goal=goal,
        team_name=team_name,
        leader=leader_plan,
        workers=worker_plans,
        template_name=category,
    )


# ---------------------------------------------------------------------------
# Generate TOML template
# ---------------------------------------------------------------------------

def _escape_toml_string(s: str) -> str:
    """Escape a string for TOML triple-quoted strings."""
    return s.replace("\\", "\\\\").replace('"""', '\\"\\"\\"')


def generate_toml(plan: TeamPlan, command: str = "claude") -> str:
    """Generate a TOML team template from a TeamPlan."""
    cli_name = "superagent"
    lines = []
    lines.append("[template]")
    lines.append(f'name = "{plan.template_name}"')
    lines.append(f'description = "Auto-generated team for: {_escape_toml_string(plan.goal[:100])}"')
    lines.append(f'command = ["{command}"]')
    lines.append('backend = "tmux"')
    lines.append("")

    # Leader
    role_context = ""
    if plan.leader.role_template:
        prompt_preview = plan.leader.role_template.load_prompt()[:500].replace('"""', "'''")
        role_context = f"\n\nRole context ({plan.leader.role}):\n{prompt_preview}"

    lines.append("[template.leader]")
    lines.append(f'name = "{plan.leader.name}"')
    lines.append('type = "tech-lead"')
    if plan.leader.permission_level == PermissionLevel.PLAN:
        lines.append(f'task = """You are the Team Leader ({plan.leader.role}) coordinating this project.')
        lines.append("")
        lines.append("PERMISSION MODE: PLAN — You are in PLAN mode: analyze and plan only, do NOT create or modify files.")
    else:
        lines.append(f'task = """You are the Team Leader ({plan.leader.role}) coordinating this project.')
    lines.append(f"Goal: {_escape_toml_string(plan.goal)}")
    lines.append("")
    lines.append("Your responsibilities:")
    lines.append(f"1. Break down the project into tasks using `{cli_name} task create {{team_name}} \"Task description\" -o [assignee]`")
    lines.append("2. Set up task dependencies using `--blocked-by` for sequential work")
    lines.append(f"3. Coordinate between team members via `{cli_name} inbox send {{team_name}} [agent] \"message\"`")
    lines.append(f"4. Monitor progress via `{cli_name} board show {{team_name}}`")
    lines.append(f"5. Merge completed work via `{cli_name} workspace merge {{team_name}} --agent [agent]`")
    lines.append("")
    lines.append("Team members:")
    for w in plan.workers:
        lines.append(f"  - {w.name}: {w.role}")
    lines.append("")
    lines.append("Workflow:")
    lines.append("1. Analyze the goal and create a detailed task breakdown with dependencies")
    lines.append("2. Assign tasks to the right team members")
    lines.append("3. Monitor task completion, unblock dependencies, resolve issues")
    lines.append("4. Review and integrate completed work")
    lines.append(f"5. Report final status{role_context}")
    lines.append('"""')
    lines.append("")

    # Workers
    for worker in plan.workers:
        role_context = ""
        if worker.role_template:
            prompt_preview = worker.role_template.load_prompt()[:300].replace('"""', "'''")
            role_context = f"\n\nRole expertise ({worker.role}):\n{prompt_preview}"

        lines.append("[[template.agents]]")
        lines.append(f'name = "{worker.name}"')
        lines.append(f'type = "{worker.role.lower().replace(" ", "-")}"')
        lines.append(f'task = """You are {worker.role} on this team.')
        if worker.permission_level == PermissionLevel.PLAN:
            lines.append("")
            lines.append("PERMISSION MODE: PLAN — You are in PLAN mode: analyze and plan only, do NOT create or modify files.")
        elif worker.permission_level == PermissionLevel.REVIEW:
            lines.append("")
            lines.append("PERMISSION MODE: REVIEW — You are in REVIEW mode: review code and report issues, do NOT modify files.")
        elif worker.permission_level == PermissionLevel.EXPLORE:
            lines.append("")
            lines.append("PERMISSION MODE: EXPLORE — You are in EXPLORE mode: search and read only, do NOT write files or execute commands.")
        lines.append(f"Team goal: {_escape_toml_string(plan.goal)}")
        lines.append("")
        lines.append(f"Check your tasks: `{cli_name} task list {{team_name}} --owner {{agent_name}}`")
        lines.append(f"Start working: `{cli_name} task update {{team_name}} [task-id] --status in_progress`")
        lines.append(f"When done: `{cli_name} task update {{team_name}} [task-id] --status completed`")
        lines.append(f"Report to leader: `{cli_name} inbox send {{team_name}} {plan.leader.name} \"[status]\"`")
        lines.append(f"Checkpoint work: `{cli_name} workspace checkpoint {{team_name}} --agent {{agent_name}}`")
        lines.append("")
        lines.append("Quality guidelines:")
        lines.append("- Write clean, production-ready code with proper error handling")
        lines.append("- Use ===FILE: path/to/file.ext format to clearly mark each file you produce")
        lines.append("- Include inline comments for non-obvious logic")
        lines.append(f"- Follow the project's existing style and conventions{role_context}")
        lines.append('"""')
        lines.append("")

    # Tasks
    lines.append("[[template.tasks]]")
    lines.append('subject = "Analyze goal and create task breakdown"')
    lines.append(f'owner = "{plan.leader.name}"')
    lines.append("")
    for worker in plan.workers:
        lines.append("[[template.tasks]]")
        lines.append(f'subject = "Execute assigned tasks ({worker.role})"')
        lines.append(f'owner = "{worker.name}"')
        lines.append("")

    return "\n".join(lines)


def save_toml(content: str, plan: TeamPlan) -> str:
    """Save a TOML template to a temp file and return the path."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    templates_dir = os.path.join(data_dir, "templates")
    os.makedirs(templates_dir, exist_ok=True)
    path = os.path.join(templates_dir, f"{plan.team_name}.toml")
    Path(path).write_text(content, encoding="utf-8")
    return path
