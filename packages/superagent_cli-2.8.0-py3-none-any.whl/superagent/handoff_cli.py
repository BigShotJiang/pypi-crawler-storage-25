"""CLI commands for SuperAgent handoff management.

Provides the ``superagent handoff`` subcommand group with request, list,
accept, reject, and complete operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import os
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.handoff import HandoffStatus, get_handoff_store

handoff_app = typer.Typer(
    name="handoff",
    help="Handoff management — agent-to-agent execution transfer.",
    no_args_is_help=True,
)
console = Console()


def _get_store():
    """Create a HandoffStore using the configured data directory."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    return get_handoff_store(data_dir)


def _status_style(status: HandoffStatus) -> str:
    """Return a Rich style string for a given handoff status."""
    return {
        HandoffStatus.pending: "yellow",
        HandoffStatus.accepted: "cyan",
        HandoffStatus.rejected: "red",
        HandoffStatus.completed: "green",
    }.get(status, "dim")


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@handoff_app.command("request")
def handoff_request(
    team: str = typer.Argument(..., help="Team name."),
    from_agent: str = typer.Option(..., "--from", help="Source agent name."),
    to_agent: str = typer.Option(..., "--to", help="Target agent name."),
    context: str = typer.Option("", "--context", "-c", help="Context to pass to the target agent."),
    reason: str = typer.Option("", "--reason", "-r", help="Reason for the handoff."),
):
    """Create a new handoff request from one agent to another."""
    store = _get_store()
    request = store.create(
        from_agent=from_agent,
        to_agent=to_agent,
        team=team,
        context=context,
        reason=reason,
    )
    console.print(Panel(
        f"[bold green]Handoff created[/bold green]\n\n"
        f"  [bold]ID:[/bold]     {request.id}\n"
        f"  [bold]From:[/bold]   {request.from_agent}\n"
        f"  [bold]To:[/bold]     {request.to_agent}\n"
        f"  [bold]Team:[/bold]   {request.team}\n"
        f"  [bold]Status:[/bold] {request.status.value}",
        title="handoff request",
        border_style="green",
    ))


@handoff_app.command("list")
def handoff_list(
    team: str = typer.Argument(..., help="Team name."),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Filter by target agent name."),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status: pending, accepted, rejected, completed."),
):
    """List handoff requests for a team."""
    store = _get_store()

    if status:
        try:
            filter_status = HandoffStatus(status.strip().lower())
        except ValueError:
            console.print(f"[red]Invalid status '{status}'. Choose from: pending, accepted, rejected, completed[/red]")
            raise typer.Exit(1)
    else:
        filter_status = None

    # Use list_pending for pending-only queries, otherwise list_all and filter
    if filter_status == HandoffStatus.pending:
        requests = store.list_pending(team, agent_name=agent)
    else:
        requests = store.list_all(team)
        if agent:
            requests = [r for r in requests if r.to_agent == agent or r.from_agent == agent]
        if filter_status:
            requests = [r for r in requests if r.status == filter_status]

    if not requests:
        console.print("[yellow]No handoffs found.[/yellow]")
        return

    table = Table(title=f"Handoffs — {team} ({len(requests)} entries)")
    table.add_column("ID", style="cyan", width=14)
    table.add_column("From", style="blue", width=16)
    table.add_column("To", style="magenta", width=16)
    table.add_column("Status", width=10)
    table.add_column("Reason", max_width=30)
    table.add_column("Created", style="dim", width=20)

    for req in requests:
        style = _status_style(req.status)
        reason_preview = req.reason[:30] + ("..." if len(req.reason) > 30 else "")
        table.add_row(
            req.id,
            req.from_agent,
            req.to_agent,
            f"[{style}]{req.status.value}[/{style}]",
            reason_preview,
            req.created_at[:19],
        )

    console.print(table)


@handoff_app.command("accept")
def handoff_accept(
    team: str = typer.Argument(..., help="Team name."),
    handoff_id: str = typer.Argument(..., help="Handoff request ID."),
):
    """Accept a pending handoff request."""
    store = _get_store()
    try:
        request = store.accept(handoff_id)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold cyan]Handoff accepted[/bold cyan]\n\n"
        f"  [bold]ID:[/bold]     {request.id}\n"
        f"  [bold]From:[/bold]   {request.from_agent}\n"
        f"  [bold]To:[/bold]     {request.to_agent}\n"
        f"  [bold]Status:[/bold] [cyan]{request.status.value}[/cyan]",
        title="handoff accept",
        border_style="cyan",
    ))


@handoff_app.command("reject")
def handoff_reject(
    team: str = typer.Argument(..., help="Team name."),
    handoff_id: str = typer.Argument(..., help="Handoff request ID."),
    reason: Optional[str] = typer.Option(None, "--reason", "-r", help="Reason for rejection."),
):
    """Reject a pending handoff request."""
    store = _get_store()
    try:
        request = store.reject(handoff_id, reason=reason)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold red]Handoff rejected[/bold red]\n\n"
        f"  [bold]ID:[/bold]     {request.id}\n"
        f"  [bold]From:[/bold]   {request.from_agent}\n"
        f"  [bold]To:[/bold]     {request.to_agent}\n"
        f"  [bold]Status:[/bold] [red]{request.status.value}[/red]",
        title="handoff reject",
        border_style="red",
    ))


@handoff_app.command("complete")
def handoff_complete(
    team: str = typer.Argument(..., help="Team name."),
    handoff_id: str = typer.Argument(..., help="Handoff request ID."),
):
    """Mark a handoff as completed."""
    store = _get_store()
    try:
        request = store.complete(handoff_id)
    except ValueError as e:
        console.print(f"[red]{e}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold green]Handoff completed[/bold green]\n\n"
        f"  [bold]ID:[/bold]          {request.id}\n"
        f"  [bold]From:[/bold]        {request.from_agent}\n"
        f"  [bold]To:[/bold]          {request.to_agent}\n"
        f"  [bold]Status:[/bold]      [green]{request.status.value}[/green]\n"
        f"  [bold]Completed:[/bold]   {request.completed_at}",
        title="handoff complete",
        border_style="green",
    ))
