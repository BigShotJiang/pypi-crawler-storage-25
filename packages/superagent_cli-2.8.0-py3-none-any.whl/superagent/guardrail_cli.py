"""CLI commands for SuperAgent guardrail management.

Provides the ``superagent guardrail`` subcommand group with list, add, remove,
and test operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import os

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.guardrails import GuardrailAction, GuardrailEngine, GuardrailRule

guardrail_app = typer.Typer(
    name="guardrail",
    help="Guardrails — manage safety rules for agent input/output checking.",
    no_args_is_help=True,
)
console = Console()


def _get_engine() -> GuardrailEngine:
    """Create a GuardrailEngine using the configured data directory."""
    data_dir = os.environ.get(
        "CLAWTEAM_DATA_DIR",
        os.path.join(os.path.expanduser("~"), ".superagent"),
    )
    rules_dir = os.path.join(data_dir, "guardrails")
    return GuardrailEngine(rules_dir)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@guardrail_app.command("list")
def guardrail_list():
    """List all guardrail rules."""
    engine = _get_engine()
    rules = engine.list_rules()

    if not rules:
        console.print("[yellow]No guardrail rules configured.[/yellow]")
        return

    table = Table(title=f"Guardrail Rules ({len(rules)})")
    table.add_column("Name", style="cyan", min_width=16)
    table.add_column("Action", style="bold", min_width=6)
    table.add_column("Scope", style="magenta", min_width=8)
    table.add_column("Pattern", style="dim", max_width=40)
    table.add_column("Description", max_width=40)

    action_colors = {
        "block": "red",
        "warn": "yellow",
        "log": "dim",
    }

    for rule in rules:
        color = action_colors.get(rule.action.value, "white")
        table.add_row(
            rule.name,
            f"[{color}]{rule.action.value}[/{color}]",
            rule.scope,
            rule.pattern,
            rule.description or "-",
        )

    console.print(table)


@guardrail_app.command("add")
def guardrail_add(
    name: str = typer.Option(..., "--name", "-n", help="Unique rule name."),
    pattern: str = typer.Option(..., "--pattern", "-p", help="Regex pattern to match."),
    action: str = typer.Option("warn", "--action", "-a", help="Action: block, warn, or log."),
    scope: str = typer.Option("both", "--scope", "-s", help="Scope: input, output, or both."),
    description: str = typer.Option("", "--description", "-d", help="Human-readable description."),
):
    """Add a custom guardrail rule."""
    # Validate action
    try:
        guard_action = GuardrailAction(action.lower())
    except ValueError:
        console.print(f"[red]Invalid action '{action}'. Choose from: block, warn, log[/red]")
        raise typer.Exit(1)

    # Validate scope
    if scope.lower() not in ("input", "output", "both"):
        console.print(f"[red]Invalid scope '{scope}'. Choose from: input, output, both[/red]")
        raise typer.Exit(1)

    # Validate regex
    import re

    try:
        re.compile(pattern)
    except re.error as e:
        console.print(f"[red]Invalid regex pattern: {e}[/red]")
        raise typer.Exit(1)

    engine = _get_engine()
    rule = GuardrailRule(
        name=name,
        pattern=pattern,
        action=guard_action,
        scope=scope.lower(),
        description=description,
    )
    engine.add_rule(rule)

    console.print(Panel(
        f"[bold green]Rule added[/bold green]\n\n"
        f"  [bold]Name:[/bold]        {rule.name}\n"
        f"  [bold]Pattern:[/bold]     {rule.pattern}\n"
        f"  [bold]Action:[/bold]      {rule.action.value}\n"
        f"  [bold]Scope:[/bold]       {rule.scope}\n"
        f"  [bold]Description:[/bold] {rule.description or '(none)'}",
        title="guardrail add",
        border_style="green",
    ))


@guardrail_app.command("remove")
def guardrail_remove(
    name: str = typer.Argument(..., help="Name of the rule to remove."),
):
    """Remove a guardrail rule by name."""
    engine = _get_engine()
    removed = engine.remove_rule(name)

    if removed:
        console.print(f"[green]Removed rule '{name}'.[/green]")
    else:
        console.print(f"[red]Rule '{name}' not found.[/red]")
        raise typer.Exit(1)


@guardrail_app.command("test")
def guardrail_test(
    text: str = typer.Argument(..., help="Text to test against guardrail rules."),
    scope: str = typer.Option("input", "--scope", "-s", help="Scope: input or output."),
):
    """Test text against guardrail rules and show violations."""
    if scope.lower() not in ("input", "output"):
        console.print(f"[red]Invalid scope '{scope}'. Choose from: input, output[/red]")
        raise typer.Exit(1)

    engine = _get_engine()
    result = engine.check(text, scope=scope.lower())

    if result.passed and not result.violations:
        console.print("[bold green]PASSED[/bold green] — no violations found.")
        return

    # Build violations table
    table = Table(title="Guardrail Check Results")
    table.add_column("Rule", style="cyan", min_width=16)
    table.add_column("Action", style="bold", min_width=6)
    table.add_column("Matched Text", style="dim", max_width=50)

    action_colors = {
        "block": "red",
        "warn": "yellow",
        "log": "dim",
    }

    for v in result.violations:
        color = action_colors.get(v["action"], "white")
        table.add_row(
            v["rule_name"],
            f"[{color}]{v['action']}[/{color}]",
            v["matched_text"],
        )

    console.print(table)

    if result.passed:
        console.print("\n[bold yellow]WARN[/bold yellow] — violations found but no blocking rules triggered.")
    else:
        console.print("\n[bold red]BLOCKED[/bold red] — one or more blocking rules triggered.")
