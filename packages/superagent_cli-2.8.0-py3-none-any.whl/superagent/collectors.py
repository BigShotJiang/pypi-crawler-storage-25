"""Data collectors for SuperAgent dashboard — modular data gathering.

Inspired by Hermes HUD's collector pattern: one module per data domain,
each reads from the data directory and returns structured data.
"""

from __future__ import annotations

import json
import logging
import os
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


def _get_data_dir() -> Path:
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


# ---------------------------------------------------------------------------
# Memory Collector
# ---------------------------------------------------------------------------


def collect_memory(data_dir: str | None = None) -> dict:
    """Collect memory stats from SQLite."""
    try:
        from superagent.memory import get_memory_store
        store = get_memory_store()
        memories = store.list_memories()
        return {
            "total": len(memories),
            "by_scope": _count_by(memories, lambda m: m.scope.value if hasattr(m.scope, "value") else str(m.scope)),
            "by_layer": _count_by(memories, lambda m: m.layer),
            "recent": [{"id": m.id, "content": m.content[:80], "scope": str(m.scope), "tags": m.tags} for m in memories[:5]],
        }
    except Exception as e:
        logger.debug("Memory collection failed: %s", e)
        return {"total": 0, "by_scope": {}, "by_layer": {}, "recent": []}


# ---------------------------------------------------------------------------
# Wiki Collector
# ---------------------------------------------------------------------------


def collect_wiki(data_dir: str | None = None) -> dict:
    """Collect wiki stats."""
    try:
        from superagent.wiki import get_wiki_store
        store = get_wiki_store()
        if not store.wiki_dir.exists():
            return {"initialized": False}
        info = store.status()
        return {
            "initialized": True,
            "total_pages": info.get("total_pages", 0),
            "by_type": info.get("pages_by_type", {}),
            "health_score": info.get("health_score", 0),
            "last_ingest": info.get("last_ingest", ""),
        }
    except Exception as e:
        logger.debug("Wiki collection failed: %s", e)
        return {"initialized": False}


# ---------------------------------------------------------------------------
# Team Collector
# ---------------------------------------------------------------------------


def collect_teams(data_dir: str | None = None) -> dict:
    """Collect team status from filesystem."""
    base = Path(data_dir) if data_dir else _get_data_dir()
    teams_dir = base / "teams"
    if not teams_dir.is_dir():
        return {"teams": []}

    teams = []
    for team_dir in sorted(teams_dir.iterdir()):
        if not team_dir.is_dir():
            continue
        team = {"name": team_dir.name, "agents": 0, "tasks": 0}

        registry = team_dir / "spawn_registry.json"
        if registry.exists():
            try:
                data = json.loads(registry.read_text(encoding="utf-8"))
                team["agents"] = len(data)
            except (json.JSONDecodeError, OSError):
                pass

        tasks_dir = team_dir / "tasks"
        if tasks_dir.is_dir():
            team["tasks"] = len(list(tasks_dir.glob("*.json")))

        teams.append(team)

    return {"teams": teams, "total": len(teams)}


# ---------------------------------------------------------------------------
# Cost Collector
# ---------------------------------------------------------------------------


def collect_costs(days: int = 30) -> dict:
    """Collect cost summary from SQLite."""
    try:
        from superagent.costs import get_cost_tracker
        return get_cost_tracker().summary(days=days)
    except Exception as e:
        logger.debug("Cost collection failed: %s", e)
        return {"total_calls": 0, "total_cost_usd": 0, "by_model": [], "by_day": []}


# ---------------------------------------------------------------------------
# Skill Collector
# ---------------------------------------------------------------------------


def collect_skills(data_dir: str | None = None) -> dict:
    """Collect skill stats."""
    try:
        from superagent.evolution import get_skill_store
        store = get_skill_store()
        skills = store.load_all()
        active = [s for s in skills if s.status == "active"]
        fixing = [s for s in skills if s.status == "fixing"]
        return {
            "total": len(skills),
            "active": len(active),
            "fixing": len(fixing),
            "top": [{"name": s.name, "success_rate": f"{s.success_rate:.0%}", "runs": s.total_runs}
                    for s in sorted(active, key=lambda s: s.total_runs, reverse=True)[:5]],
        }
    except Exception as e:
        logger.debug("Skill collection failed: %s", e)
        return {"total": 0, "active": 0, "fixing": 0, "top": []}


# ---------------------------------------------------------------------------
# Engine Collector
# ---------------------------------------------------------------------------


def collect_engines() -> dict:
    """Collect execution engine availability."""
    try:
        from superagent.llm_gateway import LLMGateway, get_llm_gateway
        gw = get_llm_gateway()
        providers = gw.list_providers()
        default = gw.get_default()
        return {
            "total": len(providers),
            "default": default.name if default else "",
            "providers": [
                {"name": p.name, "model": p.default_model,
                 "has_key": bool(LLMGateway.resolve_api_key(p)),
                 "enabled": p.enabled}
                for p in providers
            ],
        }
    except Exception as e:
        logger.debug("Engine collection failed: %s", e)
        return {"total": 0, "default": "", "providers": []}


# ---------------------------------------------------------------------------
# Full Dashboard State Collector
# ---------------------------------------------------------------------------


def collect_all() -> dict:
    """Collect complete dashboard state from all collectors."""
    return {
        "timestamp": datetime.now(timezone.utc).isoformat(),
        "memory": collect_memory(),
        "wiki": collect_wiki(),
        "teams": collect_teams(),
        "costs": collect_costs(),
        "skills": collect_skills(),
        "engines": collect_engines(),
    }


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _count_by(items: list, key_fn) -> dict[str, int]:
    counts: dict[str, int] = {}
    for item in items:
        k = str(key_fn(item))
        counts[k] = counts.get(k, 0) + 1
    return counts
