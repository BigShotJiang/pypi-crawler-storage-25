"""SOP Pipeline system for SuperAgent — Code = SOP(Team).

Inspired by MetaGPT's "Code = SOP(Team)" philosophy: role outputs automatically
flow to the next role.  Each pipeline defines an ordered sequence of stages where
one agent's output artifact becomes the next agent's input.

Pipelines are persisted as individual JSON files under ``~/.superagent/pipelines/``
and can be listed, registered, and removed at runtime.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

# ---------------------------------------------------------------------------
# Core data models
# ---------------------------------------------------------------------------


@dataclass
class PipelineStage:
    """A single stage in an SOP pipeline.

    Attributes:
        name:            Human-readable stage name (e.g. "PM").
        role:            Maps to an agency-agents role string.
        description:     What this stage does.
        input_from:      Name of the previous stage whose artifact is input,
                         or ``None`` for the first stage.
        output_artifact: Filename/path the stage produces (e.g. "requirements.md").
        prompt_template: Prompt with ``{goal}``, ``{input}``, and ``{output}``
                         placeholders that will be filled at execution time.
    """

    name: str
    role: str
    description: str
    input_from: Optional[str]
    output_artifact: str
    prompt_template: str

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> PipelineStage:
        return cls(
            name=data["name"],
            role=data["role"],
            description=data["description"],
            input_from=data.get("input_from"),
            output_artifact=data["output_artifact"],
            prompt_template=data.get("prompt_template", ""),
        )


@dataclass
class Pipeline:
    """An ordered collection of :class:`PipelineStage` objects."""

    name: str
    description: str
    stages: list[PipelineStage] = field(default_factory=list)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "stages": [s.to_dict() for s in self.stages],
        }

    @classmethod
    def from_dict(cls, data: dict) -> Pipeline:
        return cls(
            name=data["name"],
            description=data["description"],
            stages=[PipelineStage.from_dict(s) for s in data.get("stages", [])],
        )


# ---------------------------------------------------------------------------
# Built-in pipelines
# ---------------------------------------------------------------------------


def _builtin_sdlc() -> Pipeline:
    """Software Development Lifecycle pipeline."""
    return Pipeline(
        name="sdlc",
        description="Software Development Lifecycle: PM -> Architect -> Engineer -> QA",
        stages=[
            PipelineStage(
                name="PM",
                role="Product Manager",
                description="Gather and refine requirements from the project goal.",
                input_from=None,
                output_artifact="requirements.md",
                prompt_template=(
                    "You are a Product Manager. Analyze the following goal and produce "
                    "a detailed requirements document.\n\n"
                    "Goal: {goal}\n\n"
                    "Write the output to {output}."
                ),
            ),
            PipelineStage(
                name="Architect",
                role="Software Architect",
                description="Design the system architecture based on requirements.",
                input_from="PM",
                output_artifact="architecture.md",
                prompt_template=(
                    "You are a Software Architect. Based on the requirements below, "
                    "design a system architecture.\n\n"
                    "Requirements ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write the architecture document to {output}."
                ),
            ),
            PipelineStage(
                name="Engineer",
                role="Senior Developer",
                description="Implement the code according to the architecture.",
                input_from="Architect",
                output_artifact="code/",
                prompt_template=(
                    "You are a Senior Developer. Implement the system described in "
                    "the architecture document.\n\n"
                    "Architecture ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write your implementation to {output}."
                ),
            ),
            PipelineStage(
                name="QA",
                role="Evidence Collector",
                description="Test the implementation and produce a test report.",
                input_from="Engineer",
                output_artifact="test_report.md",
                prompt_template=(
                    "You are a QA Engineer / Evidence Collector. Review and test "
                    "the implementation.\n\n"
                    "Code ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write your test report to {output}."
                ),
            ),
        ],
    )


def _builtin_content() -> Pipeline:
    """Content Production pipeline."""
    return Pipeline(
        name="content",
        description="Content Production: Researcher -> Writer -> Editor",
        stages=[
            PipelineStage(
                name="Researcher",
                role="Research Analyst",
                description="Research the topic and compile notes.",
                input_from=None,
                output_artifact="research_notes.md",
                prompt_template=(
                    "You are a Research Analyst. Research the following topic "
                    "and compile detailed notes.\n\n"
                    "Goal: {goal}\n\n"
                    "Write your research notes to {output}."
                ),
            ),
            PipelineStage(
                name="Writer",
                role="Content Writer",
                description="Write a draft based on the research notes.",
                input_from="Researcher",
                output_artifact="draft.md",
                prompt_template=(
                    "You are a Content Writer. Using the research notes below, "
                    "write a polished draft.\n\n"
                    "Research ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write the draft to {output}."
                ),
            ),
            PipelineStage(
                name="Editor",
                role="Content Editor",
                description="Edit and finalize the draft.",
                input_from="Writer",
                output_artifact="final.md",
                prompt_template=(
                    "You are a Content Editor. Review and polish the draft below "
                    "into a final version.\n\n"
                    "Draft ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write the final version to {output}."
                ),
            ),
        ],
    )


def _builtin_data_analysis() -> Pipeline:
    """Data Analysis pipeline."""
    return Pipeline(
        name="data-analysis",
        description="Data Analysis: Analyst -> Engineer -> Visualizer",
        stages=[
            PipelineStage(
                name="Analyst",
                role="Data Analyst",
                description="Profile the data and identify key insights.",
                input_from=None,
                output_artifact="data_profile.md",
                prompt_template=(
                    "You are a Data Analyst. Profile the data for the following "
                    "goal and identify key insights.\n\n"
                    "Goal: {goal}\n\n"
                    "Write the data profile to {output}."
                ),
            ),
            PipelineStage(
                name="Engineer",
                role="Data Engineer",
                description="Build the data processing pipeline.",
                input_from="Analyst",
                output_artifact="pipeline.py",
                prompt_template=(
                    "You are a Data Engineer. Based on the data profile, build "
                    "a processing pipeline.\n\n"
                    "Data Profile ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write the pipeline code to {output}."
                ),
            ),
            PipelineStage(
                name="Visualizer",
                role="Data Visualizer",
                description="Create visualizations and a final report.",
                input_from="Engineer",
                output_artifact="report.html",
                prompt_template=(
                    "You are a Data Visualizer. Create visualizations and a "
                    "summary report from the processed data.\n\n"
                    "Pipeline ({input}):\n{{input_content}}\n\n"
                    "Goal: {goal}\n\n"
                    "Write the report to {output}."
                ),
            ),
        ],
    )


_BUILTIN_PIPELINES: dict[str, Pipeline] = {
    "sdlc": _builtin_sdlc(),
    "content": _builtin_content(),
    "data-analysis": _builtin_data_analysis(),
}


# ---------------------------------------------------------------------------
# Pipeline Registry
# ---------------------------------------------------------------------------


class PipelineRegistry:
    """Persists pipelines as individual JSON files under a directory.

    Built-in pipelines are loaded on first initialization and can be
    overridden by user-defined pipelines with the same name.
    """

    def __init__(self, pipelines_dir: str | Path) -> None:
        self._dir = Path(pipelines_dir)
        self._dir.mkdir(parents=True, exist_ok=True)
        self._ensure_builtins()

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _pipeline_path(self, name: str) -> Path:
        return self._dir / f"{name}.json"

    def _ensure_builtins(self) -> None:
        """Write built-in pipelines to disk if they don't already exist."""
        for name, pipeline in _BUILTIN_PIPELINES.items():
            path = self._pipeline_path(name)
            if not path.exists():
                self._write(pipeline)

    def _write(self, pipeline: Pipeline) -> None:
        path = self._pipeline_path(pipeline.name)
        atomic_write(path, json.dumps(pipeline.to_dict(), indent=2, ensure_ascii=False))

    def _load(self, path: Path) -> Optional[Pipeline]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return Pipeline.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def register(self, pipeline: Pipeline) -> None:
        """Register (or overwrite) a pipeline."""
        self._write(pipeline)

    def get(self, name: str) -> Optional[Pipeline]:
        """Retrieve a pipeline by name. Returns ``None`` if not found."""
        path = self._pipeline_path(name)
        if not path.exists():
            return None
        return self._load(path)

    def list_all(self) -> list[Pipeline]:
        """Return all registered pipelines sorted by name."""
        pipelines: list[Pipeline] = []
        for path in sorted(self._dir.glob("*.json")):
            p = self._load(path)
            if p is not None:
                pipelines.append(p)
        return pipelines

    def remove(self, name: str) -> bool:
        """Remove a pipeline by name. Returns ``True`` if found and deleted."""
        path = self._pipeline_path(name)
        if path.exists():
            path.unlink()
            return True
        return False


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------


def get_pipeline_registry(base_dir: Optional[str] = None) -> PipelineRegistry:
    """Return a :class:`PipelineRegistry` rooted at the project data directory.

    Uses ``CLAWTEAM_DATA_DIR`` env var, falling back to ``~/.superagent``.
    """
    if base_dir is None:
        base_dir = os.environ.get(
            "CLAWTEAM_DATA_DIR",
            os.path.join(os.path.expanduser("~"), ".superagent"),
        )
    return PipelineRegistry(os.path.join(base_dir, "pipelines"))
