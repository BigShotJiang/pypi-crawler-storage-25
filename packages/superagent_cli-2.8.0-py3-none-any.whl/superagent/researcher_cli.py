"""SuperAgent research CLI commands — deep research via GPT-Researcher."""

from __future__ import annotations

from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel

from superagent.researcher import is_researcher_available, research

researcher_app = typer.Typer(
    name="research",
    help="Deep research agent — conduct thorough web research powered by GPT-Researcher.",
    no_args_is_help=True,
)
console = Console()


@researcher_app.command("status")
def research_status():
    """Check GPT-Researcher availability and configuration."""
    available = is_researcher_available()

    if available:
        console.print(Panel(
            "[green]GPT-Researcher is installed and ready.[/green]\n\n"
            "Engine: [bold]gpt-researcher[/bold]\n"
            "Run research with: [bold]superagent research run \"your topic here\"[/bold]",
            title="Research Status",
            border_style="green",
        ))
    else:
        console.print(Panel(
            "[yellow]GPT-Researcher is not installed — using LLM fallback.[/yellow]\n\n"
            "Install with: [bold]pip install gpt-researcher[/bold]\n"
            "Docs: https://github.com/assafelovic/gpt-researcher\n\n"
            "[dim]The LLM fallback uses your configured LLM provider to generate\n"
            "research reports directly (no web search/scraping).[/dim]",
            title="Research Status",
            border_style="yellow",
        ))


@researcher_app.command("run")
def research_run(
    query: str = typer.Argument(..., help="Research topic or question."),
    report_type: str = typer.Option(
        "research_report", "--type", "-t",
        help="Report type: research_report or detailed_report.",
    ),
    output: Optional[str] = typer.Option(
        None, "--output", "-o",
        help="Save report to file (e.g. report.md).",
    ),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Conduct deep research on a topic and generate a report."""
    engine = "gpt-researcher" if is_researcher_available() else "llm-fallback"
    console.print(Panel(
        f"[bold]{query}[/bold]\n"
        f"[dim]type: {report_type} | engine: {engine}[/dim]",
        title="Research Task",
        border_style="cyan",
    ))

    with console.status("[cyan]Researching...[/cyan]"):
        result = research(query, report_type=report_type)

    if json_out:
        import json
        console.print(json.dumps(result, indent=2, ensure_ascii=False))
        if output:
            Path(output).write_text(json.dumps(result, indent=2, ensure_ascii=False))
            console.print(f"\n[dim]Saved to {output}[/dim]")
        return

    if result["success"]:
        report_text = str(result.get("report", ""))
        console.print(Panel(
            report_text,
            title=f"[green]Research Report[/green] [dim]({result.get('engine', 'unknown')})[/dim]",
            border_style="green",
        ))
        if output:
            Path(output).write_text(report_text)
            console.print(f"\n[green]Report saved to {output}[/green]")
    else:
        console.print(Panel(
            f"[red]{result.get('error', 'Unknown error')}[/red]",
            title="[red]Research Failed[/red]",
            border_style="red",
        ))
        raise typer.Exit(1)


@researcher_app.command("quick")
def research_quick(
    query: str = typer.Argument(..., help="Research topic or question."),
    output: Optional[str] = typer.Option(
        None, "--output", "-o",
        help="Save report to file (e.g. report.md).",
    ),
):
    """Quick research — shorter, faster results."""
    console.print(Panel(
        f"[bold]{query}[/bold]\n[dim]mode: quick[/dim]",
        title="Quick Research",
        border_style="cyan",
    ))

    with console.status("[cyan]Researching (quick)...[/cyan]"):
        result = research(query, report_type="research_report")

    if result["success"]:
        report_text = str(result.get("report", ""))
        # Truncate for quick display if very long
        if len(report_text) > 3000:
            report_text = report_text[:3000] + "\n\n[dim]... truncated (use 'research run' for full report)[/dim]"
        console.print(Panel(
            report_text,
            title=f"[green]Quick Research[/green] [dim]({result.get('engine', 'unknown')})[/dim]",
            border_style="green",
        ))
        if output:
            full_report = str(result.get("report", ""))
            Path(output).write_text(full_report)
            console.print(f"\n[green]Full report saved to {output}[/green]")
    else:
        console.print(Panel(
            f"[red]{result.get('error', 'Unknown error')}[/red]",
            title="[red]Quick Research Failed[/red]",
            border_style="red",
        ))
        raise typer.Exit(1)
