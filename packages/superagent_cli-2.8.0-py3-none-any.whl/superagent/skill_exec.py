"""Skills Execution Engine — extends evolution.py with actual SKILL.md execution.

Inspired by CodeBuddy Code's Skills system:
- SKILL.md files define professional domain knowledge and workflows
- AI automatically identifies and invokes skills based on task context
- Skills support tool whitelisting (allowed-tools)
- Skills support shell command execution (!`command` syntax)
- Skills support file references (@file syntax)
- Skills support context:fork for isolated execution
- $ARGUMENTS parameter replacement

Directory structure:
- User skills:     ~/.superagent/skills/<name>/SKILL.md
- Project skills:  .superagent/skills/<name>/SKILL.md
"""

from __future__ import annotations

import json
import logging
import os
import re
import subprocess
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Skill definition (parsed from SKILL.md)
# ---------------------------------------------------------------------------

@dataclass
class SkillDefinition:
    """A skill definition parsed from a SKILL.md file.

    Frontmatter fields (borrowed from CodeBuddy):
    - name: skill name (defaults to directory name)
    - description: when to use this skill
    - allowed_tools: comma-separated tool whitelist
    - disable_model_invocation: if true, only triggerable via /skill-name
    - user_invocable: if false, hidden from / menu
    - context: 'fork' for isolated subagent execution
    - agent: subagent type when context:fork
    """

    name: str
    description: str
    prompt: str  # Body of SKILL.md after frontmatter
    allowed_tools: list[str] = field(default_factory=list)
    disable_model_invocation: bool = False
    user_invocable: bool = True
    context: str = "default"  # default | fork
    agent: str = "general-purpose"
    source_path: Optional[str] = None
    base_directory: str = ""  # Directory where SKILL.md resides

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "prompt": self.prompt[:500],
            "allowed_tools": self.allowed_tools,
            "disable_model_invocation": self.disable_model_invocation,
            "user_invocable": self.user_invocable,
            "context": self.context,
            "agent": self.agent,
            "source_path": self.source_path,
            "base_directory": self.base_directory,
        }


def parse_skill_markdown(content: str, source_path: str = "") -> SkillDefinition:
    """Parse a SKILL.md file with YAML frontmatter.

    Format:
        ---
        name: pdf
        description: PDF 文档处理专家
        allowed-tools: Read, Write, Bash, WebFetch
        disable-model-invocation: false
        user-invocable: true
        context: default
        agent: general-purpose
        ---

        Skill prompt content here...
    """
    fm_match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)', content, re.DOTALL)
    if not fm_match:
        name = Path(source_path).parent.name if source_path else "unnamed-skill"
        return SkillDefinition(
            name=name,
            description="",
            prompt=content.strip(),
            source_path=source_path,
            base_directory=str(Path(source_path).parent) if source_path else "",
        )

    frontmatter_text = fm_match.group(1)
    body = fm_match.group(2).strip()

    # Parse frontmatter
    meta: dict = {}
    for line in frontmatter_text.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip().lower().replace("-", "_")
        value = value.strip().strip('"').strip("'")
        meta[key] = value

    # Parse lists
    allowed_tools = [t.strip() for t in meta.get("allowed_tools", "").split(",") if t.strip()] \
        if meta.get("allowed_tools") else []

    return SkillDefinition(
        name=meta.get("name", Path(source_path).parent.name if source_path else "unnamed-skill"),
        description=meta.get("description", ""),
        prompt=body,
        allowed_tools=allowed_tools,
        disable_model_invocation=meta.get("disable_model_invocation", "false").lower() == "true",
        user_invocable=meta.get("user_invocable", "true").lower() != "false",
        context=meta.get("context", "default"),
        agent=meta.get("agent", "general-purpose"),
        source_path=source_path,
        base_directory=str(Path(source_path).parent) if source_path else "",
    )


# ---------------------------------------------------------------------------
# Skill Registry
# ---------------------------------------------------------------------------

class SkillExecutionRegistry:
    """Manages skill definitions and execution, extending the existing SkillStore.

    While evolution.py's SkillStore tracks metadata (success/failure counters),
    this registry handles the actual SKILL.md definitions and execution logic.
    """

    def __init__(self, data_dir: Optional[str] = None, project_dir: Optional[str] = None):
        if data_dir is None:
            data_dir = os.environ.get(
                "CLAWTEAM_DATA_DIR",
                os.path.join(os.path.expanduser("~"), ".superagent"),
            )
        self._data_dir = data_dir
        self._user_skills_dir = os.path.join(data_dir, "skills")
        self._project_skills_dir = os.path.join(project_dir, ".superagent", "skills") if project_dir else None
        self._skills: dict[str, SkillDefinition] = {}
        self._load()

    def _load(self) -> None:
        """Load skill definitions from user and project directories."""
        self._load_from_dir(self._user_skills_dir)
        if self._project_skills_dir:
            self._load_from_dir(self._project_skills_dir)

    def _load_from_dir(self, directory: str) -> None:
        """Load all SKILL.md definitions from a directory tree."""
        dir_path = Path(directory)
        if not dir_path.is_dir():
            return
        # Look for SKILL.md files in subdirectories
        for skill_md in sorted(dir_path.glob("*/SKILL.md")):
            try:
                content = skill_md.read_text(encoding="utf-8")
                skill = parse_skill_markdown(content, source_path=str(skill_md))
                self._skills[skill.name] = skill
                logger.debug("Loaded skill: %s from %s", skill.name, skill_md)
            except Exception as e:
                logger.warning("Failed to load skill from %s: %s", skill_md, e)

    def reload(self) -> None:
        """Reload all skill definitions."""
        self._skills.clear()
        self._load()

    def list_skills(self) -> list[SkillDefinition]:
        """Return all registered skills."""
        return list(self._skills.values())

    def get(self, name: str) -> Optional[SkillDefinition]:
        """Get a skill by name."""
        return self._skills.get(name)

    def create_skill(self, skill: SkillDefinition, scope: str = "user") -> None:
        """Create a new skill on disk."""
        if scope == "project" and self._project_skills_dir:
            base_dir = self._project_skills_dir
        else:
            base_dir = self._user_skills_dir

        skill_dir = os.path.join(base_dir, skill.name)
        os.makedirs(skill_dir, exist_ok=True)
        filepath = os.path.join(skill_dir, "SKILL.md")

        # Render as SKILL.md
        tools_str = ", ".join(skill.allowed_tools) if skill.allowed_tools else ""
        frontmatter = f"---\nname: {skill.name}\ndescription: {skill.description}\n"
        if tools_str:
            frontmatter += f"allowed-tools: {tools_str}\n"
        if skill.disable_model_invocation:
            frontmatter += "disable-model-invocation: true\n"
        if not skill.user_invocable:
            frontmatter += "user-invocable: false\n"
        if skill.context != "default":
            frontmatter += f"context: {skill.context}\n"
        if skill.agent != "general-purpose":
            frontmatter += f"agent: {skill.agent}\n"
        frontmatter += f"---\n\n{skill.prompt}\n"

        atomic_write(Path(filepath), frontmatter)
        skill.source_path = filepath
        skill.base_directory = skill_dir
        self._skills[skill.name] = skill

    def delete_skill(self, name: str) -> bool:
        """Delete a skill. Returns True if found and deleted."""
        skill = self._skills.pop(name, None)
        if skill is None:
            return False
        # Remove the entire skill directory
        if skill.base_directory and os.path.isdir(skill.base_directory):
            import shutil
            shutil.rmtree(skill.base_directory, ignore_errors=True)
        return True

    # ------------------------------------------------------------------
    # Skill matching (for AI auto-invocation)
    # ------------------------------------------------------------------

    def match_skill(self, task: str) -> Optional[SkillDefinition]:
        """Auto-select the best skill for a task based on description matching.

        Inspired by CodeBuddy's skill auto-invocation:
        - Matches task keywords against skill descriptions
        - Only considers skills where disable_model_invocation is False
        - Returns the skill with highest keyword overlap
        """
        task_lower = task.lower()
        task_words = set(re.findall(r'\w+', task_lower))

        best_skill: Optional[SkillDefinition] = None
        best_score = 0.0

        for skill in self._skills.values():
            if skill.disable_model_invocation:
                continue
            desc_words = set(re.findall(r'\w+', skill.description.lower()))
            if not desc_words:
                continue
            overlap = len(task_words & desc_words)
            score = overlap / len(desc_words) if desc_words else 0.0
            if score > best_score:
                best_score = score
                best_skill = skill

        return best_skill if best_score > 0.1 else None

    # ------------------------------------------------------------------
    # Skill execution
    # ------------------------------------------------------------------

    def render_skill_prompt(self, name: str, arguments: str = "") -> Optional[str]:
        """Render a skill's prompt with parameter substitution and shell execution.

        Processing pipeline (borrowed from CodeBuddy):
        1. $ARGUMENTS replacement
        2. !`command` shell execution (output replaces the line)
        3. @file reference processing (file content injected)

        Returns the fully rendered prompt, or None if skill not found.
        """
        skill = self.get(name)
        if skill is None:
            return None

        prompt = skill.prompt

        # Step 1: $ARGUMENTS replacement
        if arguments:
            prompt = prompt.replace("$ARGUMENTS", arguments)

        # Step 2: !`command` shell execution
        def execute_shell(match: re.Match) -> str:
            cmd = match.group(1)
            try:
                result = subprocess.run(
                    cmd, shell=True, capture_output=True, text=True, timeout=30
                )
                return result.stdout.strip()
            except (subprocess.TimeoutExpired, Exception) as e:
                logger.warning("Skill shell command failed: %s -> %s", cmd, e)
                return f"(error: {e})"

        prompt = re.sub(r'!`([^`]+)`', execute_shell, prompt)

        # Step 3: @file references
        def inject_file(match: re.Match) -> str:
            filepath = match.group(1)
            # Resolve relative to skill's base directory
            if not os.path.isabs(filepath) and skill.base_directory:
                filepath = os.path.join(skill.base_directory, filepath)
            try:
                return Path(filepath).read_text(encoding="utf-8")
            except (OSError, UnicodeDecodeError) as e:
                logger.warning("Skill file reference failed: @%s -> %s", filepath, e)
                return f"(file not found: {filepath})"

        prompt = re.sub(r'@(\S+)', inject_file, prompt)

        return prompt

    def estimate_token_count(self, name: str) -> int:
        """Estimate the token count for a skill's prompt (rough: 1 token per 4 chars)."""
        skill = self.get(name)
        if skill is None:
            return 0
        return len(skill.prompt) // 4


# ---------------------------------------------------------------------------
# Built-in skill definitions
# ---------------------------------------------------------------------------

BUILTIN_SKILLS: dict[str, str] = {
    "commit": """---
name: commit
description: 创建规范的 git commit，自动分析变更并生成提交消息
allowed-tools: Bash(git:*), Read
---

## 当前状态

- Git 状态： !`git status --short`
- 暂存变更： !`git diff --cached --stat`
- 最近提交： !`git log --oneline -5`

## 任务

基于以上信息，分析代码变更并创建规范的 git commit：
1. 审查变更内容
2. 生成简洁明了的提交消息
3. 执行 git add 和 git commit

$ARGUMENTS
""",
    "security-review": """---
name: security-review
description: 代码安全审查，检查常见安全漏洞
allowed-tools: Read, Grep, Glob, Bash
---

你是一位安全工程师，请对代码进行安全审查。

审查重点：
1. SQL 注入风险
2. XSS 漏洞
3. 认证授权问题
4. 敏感信息泄露
5. 不安全的依赖

对发现的问题按严重等级排序报告。

$ARGUMENTS
""",
    "diagnose": """---
name: diagnose
description: 诊断项目状态和环境
allowed-tools: Bash, Read
---

## 项目诊断报告

工作目录： !`pwd`
Git 状态： !`git status --short`
最近提交： !`git log --oneline -5`
依赖检查： !`ls package.json pyproject.toml requirements.txt 2>/dev/null || echo "No dependency files found"`

基于上述信息，总结项目状态并提出建议。

$ARGUMENTS
""",
}


def seed_builtin_skills(data_dir: Optional[str] = None) -> int:
    """Seed built-in skill definitions. Returns count seeded."""
    registry = SkillExecutionRegistry(data_dir=data_dir)
    seeded = 0
    for name, content in BUILTIN_SKILLS.items():
        if registry.get(name) is not None:
            continue
        skill = parse_skill_markdown(content, source_path=f"builtin:{name}")
        registry.create_skill(skill, scope="user")
        seeded += 1
    return seeded


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_skill_exec_registry: Optional[SkillExecutionRegistry] = None


def get_skill_execution_registry(
    data_dir: Optional[str] = None,
    project_dir: Optional[str] = None,
) -> SkillExecutionRegistry:
    """Return a singleton SkillExecutionRegistry instance."""
    global _skill_exec_registry
    if _skill_exec_registry is None:
        _skill_exec_registry = SkillExecutionRegistry(data_dir=data_dir, project_dir=project_dir)
    return _skill_exec_registry
