"""SuperAgent services CLI — manage external service integrations via Composio."""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from superagent.composio_tools import (
    RECOMMENDED_APPS,
    get_composio_bridge,
    is_composio_available,
)

services_app = typer.Typer(
    name="services",
    help="External service integrations — connect to 200+ services via Composio.",
    no_args_is_help=True,
)
console = Console()


@services_app.command("status")
def services_status():
    """Check Composio availability and connection status."""
    if not is_composio_available():
        console.print("[red]Composio is not installed.[/red]")
        console.print("Install with: [bold]pip install composio-core[/bold]")
        raise typer.Exit(1)

    bridge = get_composio_bridge()
    if bridge is None:
        console.print("[yellow]Composio is installed but failed to initialize.[/yellow]")
        console.print("Check your COMPOSIO_API_KEY environment variable.")
        raise typer.Exit(1)

    console.print("[green]Composio is available and connected.[/green]")

    apps = bridge.list_apps()
    console.print(f"  Available apps: [bold]{len(apps)}[/bold]")

    import os

    key = os.environ.get("COMPOSIO_API_KEY", "")
    if key:
        masked = key[:4] + "..." + key[-4:] if len(key) > 8 else "***"
        console.print(f"  API key: {masked}")
    else:
        console.print("  API key: [dim]not set (using default)[/dim]")


@services_app.command("list")
def services_list(
    category: Optional[str] = typer.Option(
        None,
        "--category",
        "-c",
        help="Filter by category (dev, communication, productivity, cloud, data).",
    ),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List available apps/services."""
    bridge = get_composio_bridge()
    if bridge is None:
        console.print("[red]Composio not available.[/red] Run [bold]superagent services status[/bold] for details.")
        raise typer.Exit(1)

    # If category specified, filter by recommended apps in that category
    if category:
        category_lower = category.lower()
        if category_lower not in RECOMMENDED_APPS:
            console.print(f"[red]Unknown category '{category}'.[/red]")
            console.print(f"Available: {', '.join(RECOMMENDED_APPS.keys())}")
            raise typer.Exit(1)

        recommended = RECOMMENDED_APPS[category_lower]
        apps = bridge.list_apps()
        apps = [a for a in apps if a["name"].lower() in recommended]
        title = f"Services — {category_lower}"
    else:
        apps = bridge.list_apps()
        title = f"Services ({len(apps)})"

    if json_out:
        console.print(json.dumps(apps, indent=2, ensure_ascii=False))
        return

    if not apps:
        console.print(f"[yellow]No services found{f' in category [{category}]' if category else ''}.[/yellow]")
        return

    table = Table(title=title)
    table.add_column("Name", style="bold", width=20)
    table.add_column("Description", style="dim", max_width=50)
    table.add_column("Categories", style="cyan", max_width=25)

    for app in apps:
        cats = ", ".join(app.get("categories", [])) if app.get("categories") else ""
        table.add_row(app["name"], app.get("description", "")[:50], cats)

    console.print(table)


@services_app.command("actions")
def services_actions(
    app: str = typer.Argument(..., help="App name (e.g. github, slack, jira)."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List actions for a specific app (e.g. github)."""
    bridge = get_composio_bridge()
    if bridge is None:
        console.print("[red]Composio not available.[/red] Run [bold]superagent services status[/bold] for details.")
        raise typer.Exit(1)

    actions = bridge.list_actions(app_name=app)

    if json_out:
        console.print(json.dumps(actions, indent=2, ensure_ascii=False))
        return

    if not actions:
        console.print(f"[yellow]No actions found for '{app}'.[/yellow]")
        return

    table = Table(title=f"Actions — {app}")
    table.add_column("Action", style="bold", width=30)
    table.add_column("App", style="cyan", width=12)
    table.add_column("Description", style="dim", max_width=45)

    for a in actions:
        table.add_row(a["name"], a.get("app", ""), a.get("description", "")[:45])

    console.print(table)


@services_app.command("run")
def services_run(
    action: str = typer.Argument(..., help="Action name to execute."),
    params: Optional[str] = typer.Option(
        None, "--params", "-p", help='JSON parameters (e.g. \'{"repo":"owner/name"}\').'
    ),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Execute a Composio action."""
    bridge = get_composio_bridge()
    if bridge is None:
        console.print("[red]Composio not available.[/red] Run [bold]superagent services status[/bold] for details.")
        raise typer.Exit(1)

    parsed_params = {}
    if params:
        try:
            parsed_params = json.loads(params)
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON params:[/red] {e}")
            raise typer.Exit(1)

    console.print(f"Executing [bold]{action}[/bold] ...")
    result = bridge.execute_action(action, parsed_params)

    if json_out:
        console.print(json.dumps(result, indent=2, ensure_ascii=False, default=str))
        return

    if result["success"]:
        console.print("[green]Action succeeded.[/green]")
        console.print(result["result"])
    else:
        console.print(f"[red]Action failed:[/red] {result['error']}")
        raise typer.Exit(1)


@services_app.command("recommended")
def services_recommended():
    """Show recommended apps by category."""
    table = Table(title="Recommended Service Integrations")
    table.add_column("Category", style="bold cyan", width=16)
    table.add_column("Services", style="dim")

    for category, apps in RECOMMENDED_APPS.items():
        table.add_row(category, ", ".join(apps))

    console.print(table)
    console.print("\n[dim]Use [bold]superagent services list --category <name>[/bold] to browse a category.[/dim]")
