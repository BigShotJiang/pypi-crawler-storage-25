"""SuperAgent sandbox CLI — execute code in E2B sandboxes or local fallback."""

from __future__ import annotations

import typer
from rich.console import Console

from superagent.sandbox import get_sandbox, is_e2b_available

sandbox_app = typer.Typer(
    name="sandbox",
    help="Sandboxed code execution — run Python or shell commands in E2B microVMs.",
    no_args_is_help=True,
)
console = Console()


@sandbox_app.command("status")
def sandbox_status():
    """Show E2B availability and API key status."""
    import os

    e2b_installed = False
    try:
        import e2b  # noqa: F401
        e2b_installed = True
    except ImportError:
        pass

    api_key = os.environ.get("E2B_API_KEY", "")
    has_key = bool(api_key)
    available = is_e2b_available()

    console.print("[bold]Sandbox Status[/bold]")
    console.print(f"  E2B package installed: {'[green]yes[/green]' if e2b_installed else '[red]no[/red]'}")
    console.print(f"  E2B API key set:       {'[green]yes[/green]' if has_key else '[yellow]no (set E2B_API_KEY)[/yellow]'}")
    console.print(f"  E2B sandbox available: {'[green]yes[/green]' if available else '[dim]no — using local fallback[/dim]'}")

    if not e2b_installed:
        console.print("\n  [dim]Install E2B: pip install e2b[/dim]")
    if not has_key:
        console.print("  [dim]Get an API key at https://e2b.dev[/dim]")


@sandbox_app.command("run-python")
def sandbox_run_python(
    code: str = typer.Argument(..., help="Python code to execute."),
    timeout: int = typer.Option(30, "--timeout", "-t", help="Execution timeout in seconds."),
):
    """Execute Python code in sandbox."""
    sb = get_sandbox()
    result = sb.execute_python(code, timeout=timeout)

    engine = result["engine"]
    console.print(f"[dim]Engine: {engine}[/dim]")

    if result["success"]:
        if result["stdout"]:
            console.print(result["stdout"], end="")
    else:
        console.print(f"[red]Error:[/red] {result['stderr']}")
        raise typer.Exit(1)


@sandbox_app.command("run-shell")
def sandbox_run_shell(
    command: str = typer.Argument(..., help="Shell command to execute."),
    timeout: int = typer.Option(30, "--timeout", "-t", help="Execution timeout in seconds."),
):
    """Execute a shell command in sandbox."""
    sb = get_sandbox()
    result = sb.execute_shell(command, timeout=timeout)

    engine = result["engine"]
    console.print(f"[dim]Engine: {engine}[/dim]")

    if result["success"]:
        if result["stdout"]:
            console.print(result["stdout"], end="")
    else:
        console.print(f"[red]Error:[/red] {result['stderr']}")
        raise typer.Exit(1)


@sandbox_app.command("test")
def sandbox_test():
    """Quick test — print hello world via sandbox."""
    sb = get_sandbox()
    result = sb.execute_python('print("Hello from SuperAgent sandbox!")')

    engine = result["engine"]
    if result["success"]:
        console.print(f"[green]OK[/green] ({engine}): {result['stdout'].strip()}")
    else:
        console.print(f"[red]FAIL[/red] ({engine}): {result['stderr']}")
        raise typer.Exit(1)
