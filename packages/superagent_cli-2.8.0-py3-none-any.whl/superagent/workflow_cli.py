"""CLI commands for SuperAgent workflow management.

Provides the ``superagent workflow`` subcommand group with list, show, create,
add-step, and remove operations.  Uses Rich tables and panels for formatted
output.
"""

from __future__ import annotations

import json
import os
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.workflow import (
    StepType,
    Workflow,
    WorkflowStep,
    get_workflow_store,
)

workflow_app = typer.Typer(
    name="workflow",
    help="Crew+Flow Workflows — define, inspect, and manage dual-mode agent workflows.",
    no_args_is_help=True,
)
console = Console()


def _get_store():
    """Create a WorkflowStore using the configured data directory."""
    data_dir = os.environ.get(
        "CLAWTEAM_DATA_DIR",
        os.path.join(os.path.expanduser("~"), ".superagent"),
    )
    return get_workflow_store(data_dir)


# ------------------------------------------------------------------
# Visual helpers
# ------------------------------------------------------------------


def _render_step_graph(workflow: Workflow) -> str:
    """Render a visual step graph for display in ``workflow show``.

    Produces indented output like::

        [1] Spec (Product Manager)
          -> [2] Design (UI Designer)
            -> [3] Implement (Senior Developer)
    """
    if not workflow.steps:
        return "[dim](no steps)[/dim]"

    # Build id -> step and id -> index maps
    id_to_step: dict[str, WorkflowStep] = {s.id: s for s in workflow.steps}
    id_to_idx: dict[str, int] = {s.id: i + 1 for i, s in enumerate(workflow.steps)}

    # Find root steps (steps not referenced as a next_step by any other step)
    all_nexts: set[str] = set()
    for s in workflow.steps:
        all_nexts.update(s.next_steps)
    roots = [s for s in workflow.steps if s.id not in all_nexts]
    if not roots:
        roots = [workflow.steps[0]]

    lines: list[str] = []
    visited: set[str] = set()

    def _walk(step_id: str, depth: int) -> None:
        if step_id in visited or step_id not in id_to_step:
            if step_id in id_to_step:
                idx = id_to_idx[step_id]
                step = id_to_step[step_id]
                role_str = f" ({step.agent_role})" if step.agent_role else ""
                prefix = "  " * depth + "[green]\u2192[/green] " if depth > 0 else ""
                lines.append(f"{prefix}[bold][{idx}][/bold] {step.name}{role_str} [dim](loop back)[/dim]")
            return

        visited.add(step_id)
        step = id_to_step[step_id]
        idx = id_to_idx[step_id]
        role_str = f" ({step.agent_role})" if step.agent_role else ""

        prefix = "  " * depth + "[green]\u2192[/green] " if depth > 0 else ""
        label = f"{prefix}[bold][{idx}][/bold] {step.name}{role_str}"

        if step.step_type == StepType.CONDITION and step.condition:
            label += f" [yellow]? {step.condition}[/yellow]"

        lines.append(label)

        for nid in step.next_steps:
            _walk(nid, depth + 1)

    for root in roots:
        _walk(root.id, 0)

    return "\n".join(lines)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@workflow_app.command("list")
def workflow_list(
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List all workflows."""
    store = _get_store()
    workflows = store.list_all()

    if json_out:
        data = [
            {
                "name": w.name,
                "mode": w.mode,
                "description": w.description,
                "steps": len(w.steps),
            }
            for w in workflows
        ]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not workflows:
        console.print("[yellow]No workflows registered.[/yellow]")
        return

    table = Table(title=f"Workflows ({len(workflows)})")
    table.add_column("Name", style="bold cyan", width=22)
    table.add_column("Mode", style="magenta", width=8, justify="center")
    table.add_column("Steps", style="green", width=8, justify="center")
    table.add_column("Description", style="dim", max_width=50)

    for w in workflows:
        table.add_row(w.name, w.mode, str(len(w.steps)), w.description)

    console.print(table)


@workflow_app.command("show")
def workflow_show(
    name: str = typer.Argument(..., help="Workflow name to display."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Show workflow details with a visual step graph."""
    store = _get_store()
    workflow = store.get(name)

    if workflow is None:
        console.print(f"[red]Workflow '{name}' not found.[/red]")
        raise typer.Exit(1)

    if json_out:
        console.print(json.dumps(workflow.to_dict(), indent=2, ensure_ascii=False))
        return

    graph = _render_step_graph(workflow)

    console.print(Panel(
        f"[bold]Workflow:[/bold] {workflow.name}\n"
        f"[bold]Mode:[/bold]     {workflow.mode}\n"
        f"[bold]Description:[/bold] {workflow.description}\n"
        f"[bold]Created:[/bold]  {workflow.created_at}\n"
        f"[bold]Steps:[/bold]    {len(workflow.steps)}\n\n"
        f"{graph}",
        title=f"Workflow: {workflow.name}",
        border_style="cyan",
    ))

    # Step detail table
    table = Table(title="Step Details", show_lines=True)
    table.add_column("#", style="bold", width=4, justify="center")
    table.add_column("ID", style="cyan", width=16)
    table.add_column("Name", style="bold", width=16)
    table.add_column("Type", style="magenta", width=12)
    table.add_column("Role", style="blue", width=22)
    table.add_column("Next", style="green", width=20)
    table.add_column("Description", style="dim", max_width=30)

    for i, step in enumerate(workflow.steps, 1):
        table.add_row(
            str(i),
            step.id,
            step.name,
            step.step_type.value,
            step.agent_role or "-",
            ", ".join(step.next_steps) if step.next_steps else "-",
            step.description,
        )

    console.print(table)


@workflow_app.command("create")
def workflow_create(
    name: str = typer.Argument(..., help="Name for the new workflow."),
    mode: str = typer.Option("flow", "--mode", "-m", help="Workflow mode: crew or flow."),
    description: str = typer.Option("", "--description", "-d", help="Workflow description."),
):
    """Create a new empty workflow."""
    store = _get_store()

    if mode not in ("crew", "flow"):
        console.print(f"[red]Invalid mode '{mode}'. Must be 'crew' or 'flow'.[/red]")
        raise typer.Exit(1)

    existing = store.get(name)
    if existing is not None:
        console.print(f"[red]Workflow '{name}' already exists. Remove it first or choose a different name.[/red]")
        raise typer.Exit(1)

    workflow = Workflow(name=name, description=description, mode=mode)
    store.save(workflow)
    console.print(Panel(
        f"[bold green]Workflow created[/bold green]\n\n"
        f"  [bold]Name:[/bold]        {workflow.name}\n"
        f"  [bold]Mode:[/bold]        {workflow.mode}\n"
        f"  [bold]Description:[/bold] {workflow.description or '(none)'}\n"
        f"  [bold]Steps:[/bold]       0\n\n"
        f"[dim]Add steps with:[/dim] superagent workflow add-step {name} --name \"Step\" --type action --role \"Role\" --description \"desc\"",
        title="workflow create",
        border_style="green",
    ))


@workflow_app.command("add-step")
def workflow_add_step(
    workflow_name: str = typer.Argument(..., help="Workflow to add the step to."),
    name: str = typer.Option(..., "--name", "-n", help="Step name."),
    step_type: str = typer.Option("action", "--type", "-t", help="Step type: action, condition, parallel, wait, handoff."),
    role: Optional[str] = typer.Option(None, "--role", "-r", help="Agent role for this step."),
    description: str = typer.Option("", "--description", "-d", help="Step description."),
    next_steps: Optional[str] = typer.Option(None, "--next", help="Comma-separated IDs of next steps."),
    condition: Optional[str] = typer.Option(None, "--condition", "-c", help="Condition expression (for condition steps)."),
):
    """Add a step to an existing workflow."""
    store = _get_store()
    workflow = store.get(workflow_name)

    if workflow is None:
        console.print(f"[red]Workflow '{workflow_name}' not found.[/red]")
        raise typer.Exit(1)

    # Validate step type
    try:
        st = StepType(step_type)
    except ValueError:
        valid = ", ".join(t.value for t in StepType)
        console.print(f"[red]Invalid step type '{step_type}'. Valid types: {valid}[/red]")
        raise typer.Exit(1)

    # Generate an ID from the name
    step_id = name.lower().replace(" ", "-")
    existing_ids = {s.id for s in workflow.steps}
    if step_id in existing_ids:
        # Append a counter to make unique
        counter = 2
        while f"{step_id}-{counter}" in existing_ids:
            counter += 1
        step_id = f"{step_id}-{counter}"

    parsed_next: list[str] = []
    if next_steps:
        parsed_next = [s.strip() for s in next_steps.split(",") if s.strip()]

    step = WorkflowStep(
        id=step_id,
        name=name,
        step_type=st,
        agent_role=role,
        description=description,
        next_steps=parsed_next,
        condition=condition,
    )

    # Auto-link from previous step if no explicit next_steps on the last step
    if workflow.steps and not parsed_next:
        last = workflow.steps[-1]
        if step_id not in last.next_steps:
            last.next_steps.append(step_id)

    workflow.steps.append(step)
    store.save(workflow)

    console.print(
        f"[green]Added step '[bold]{name}[/bold]' (id: {step_id}) to workflow '{workflow_name}' "
        f"(step {len(workflow.steps)}).[/green]"
    )


@workflow_app.command("remove")
def workflow_remove(
    name: str = typer.Argument(..., help="Workflow name to remove."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
):
    """Remove a workflow."""
    store = _get_store()
    workflow = store.get(name)

    if workflow is None:
        console.print(f"[red]Workflow '{name}' not found.[/red]")
        raise typer.Exit(1)

    if not force:
        confirm = typer.confirm(f"Remove workflow '{name}' ({len(workflow.steps)} steps)?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    store.remove(name)
    console.print(f"[green]Removed workflow '{name}'.[/green]")
