"""SuperAgent background session and worker management.

Inspired by CodeBuddy CLI's ``--bg`` / ``ps`` / ``logs`` / ``kill`` pattern
and OpenClaw's Worker Registry.

Provides:
- PID-file-based worker registry at ``~/.superagent/workers/``
- Background task launcher (``superagent auto "goal"`` in a subprocess)
- Daemon start/stop/status for the Gateway
- Log streaming for background workers
- Process liveness detection and stale-PID cleanup
"""

from __future__ import annotations

import dataclasses
import json
import logging
import os
import platform
import signal
import subprocess
import sys
import threading
import time
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)

_IS_WINDOWS = platform.system() == "Windows"


def _data_dir() -> Path:
    """Return the SuperAgent data directory."""
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", Path.home() / ".superagent"))


def _workers_dir() -> Path:
    return _data_dir() / "workers"


def _logs_dir() -> Path:
    return _data_dir() / "logs"


# ---------------------------------------------------------------------------
# Worker data model
# ---------------------------------------------------------------------------


@dataclasses.dataclass
class Worker:
    """A running (or recently finished) CLI process."""

    id: str  # PID (as str) or custom name
    pid: int
    session_id: str
    name: str
    kind: str  # interactive | bg | daemon
    cwd: str
    started_at: float  # unix timestamp
    url: Optional[str] = None
    status: str = "running"  # running | stopped | crashed
    hostname: str = ""
    command: str = ""
    log_path: str = ""

    # ---- serialisation helpers ----

    def to_dict(self) -> dict[str, Any]:
        return dataclasses.asdict(self)

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> Worker:
        # Tolerate missing fields with defaults
        field_names = {f.name for f in dataclasses.fields(cls)}
        filtered = {k: v for k, v in data.items() if k in field_names}
        return cls(**filtered)


# ---------------------------------------------------------------------------
# WorkerManager
# ---------------------------------------------------------------------------


class WorkerManager:
    """Manages background worker processes and the PID-file registry.

    Thread-safe: all registry mutations are protected by ``_lock``.
    """

    def __init__(self, data_dir: Optional[str] = None) -> None:
        self._data_dir = Path(data_dir) if data_dir else _data_dir()
        self._workers_dir = self._data_dir / "workers"
        self._logs_dir = self._data_dir / "logs"
        self._lock = threading.Lock()
        # Ensure directories exist
        self._workers_dir.mkdir(parents=True, exist_ok=True)
        self._logs_dir.mkdir(parents=True, exist_ok=True)

    # ---- PID file helpers ----

    def _pid_path(self, worker_id: str) -> Path:
        return self._workers_dir / f"{worker_id}.json"

    def _write_pid_file(self, worker: Worker) -> None:
        path = self._pid_path(worker.id)
        atomic_write(path, json.dumps(worker.to_dict(), indent=2))

    def _read_pid_file(self, worker_id: str) -> Optional[Worker]:
        path = self._pid_path(worker_id)
        if not path.is_file():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return Worker.from_dict(data)
        except (json.JSONDecodeError, TypeError) as exc:
            logger.warning("Corrupt PID file %s: %s", path, exc)
            return None

    def _remove_pid_file(self, worker_id: str) -> None:
        path = self._pid_path(worker_id)
        try:
            path.unlink(missing_ok=True)
        except OSError:
            pass

    # ---- process liveness ----

    @staticmethod
    def _is_alive(pid: int) -> bool:
        """Check whether *pid* is still running."""
        if _IS_WINDOWS:
            try:
                import ctypes

                kernel32 = ctypes.windll.kernel32  # type: ignore[attr-defined]
                process = kernel32.OpenProcess(0x100000, False, pid)
                if process:
                    kernel32.CloseHandle(process)
                    return True
                return False
            except Exception:
                return False
        else:
            try:
                os.kill(pid, 0)
                return True
            except (OSError, ProcessLookupError):
                return False

    # ---- public API ----

    def start_background(
        self,
        name: str,
        command: list[str] | None = None,
        args: list[str] | None = None,
        cwd: str | None = None,
        env: dict[str, str] | None = None,
    ) -> Worker:
        """Start a background worker process.

        Parameters
        ----------
        name:
            Display name (also used for log file).
        command:
            Command to run.  Defaults to ``[sys.executable, "-m", "superagent"]``.
        args:
            Extra arguments appended to *command*.
        cwd:
            Working directory (default: current directory).
        env:
            Extra environment variables merged into ``os.environ``.

        Returns
        -------
        Worker
            The registered worker object.
        """
        cmd = list(command or [sys.executable, "-m", "superagent"])
        if args:
            cmd.extend(args)

        cwd = cwd or os.getcwd()
        full_env = {**os.environ, **(env or {})}

        # Ensure log directory exists
        log_path = self._logs_dir / f"{name}.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)

        logger.info("Starting background worker %r: %s (cwd=%s)", name, cmd, cwd)

        with open(log_path, "a", encoding="utf-8") as log_fh:
            proc = subprocess.Popen(
                cmd,
                cwd=cwd,
                env=full_env,
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )

        worker = Worker(
            id=str(proc.pid),
            pid=proc.pid,
            session_id=f"bg-{uuid.uuid4().hex[:8]}",
            name=name,
            kind="bg",
            cwd=cwd,
            started_at=time.time(),
            url=None,
            status="running",
            hostname=platform.node(),
            command=" ".join(cmd),
            log_path=str(log_path),
        )

        with self._lock:
            self._write_pid_file(worker)

        return worker

    def list_workers(
        self,
        kind: str | None = None,
        local_only: bool = False,
    ) -> list[Worker]:
        """List all registered workers, pruning stale entries.

        Parameters
        ----------
        kind:
            Filter by worker kind (``interactive``, ``bg``, ``daemon``).
        local_only:
            Only return local (same-hostname) workers.
        """
        self.cleanup_stale()

        workers: list[Worker] = []
        with self._lock:
            for pid_file in self._workers_dir.glob("*.json"):
                try:
                    data = json.loads(pid_file.read_text(encoding="utf-8"))
                    w = Worker.from_dict(data)
                except (json.JSONDecodeError, TypeError):
                    continue
                # Refresh liveness
                w.status = "running" if self._is_alive(w.pid) else "stopped"
                if kind and w.kind != kind:
                    continue
                if local_only and w.hostname != platform.node():
                    continue
                workers.append(w)
        return workers

    def get_worker(self, worker_id: str) -> Optional[Worker]:
        """Get a single worker by ID (PID or name)."""
        worker = self._read_pid_file(worker_id)
        if worker is None:
            return None
        worker.status = "running" if self._is_alive(worker.pid) else "stopped"
        return worker

    def get_worker_logs(
        self,
        worker_id: str,
        log_type: str | None = None,
        tail: int = 200,
    ) -> str:
        """Return the last *tail* lines of a worker's log.

        Parameters
        ----------
        worker_id:
            Worker ID (PID or name).
        log_type:
            ``process`` (default), ``telemetry``, or ``transcript``.
        tail:
            Number of lines from the end.
        """
        worker = self.get_worker(worker_id)
        if worker is None:
            return ""

        # Determine log path based on type
        if log_type == "telemetry":
            date_str = datetime.fromtimestamp(worker.started_at, tz=timezone.utc).strftime("%Y-%m-%d")
            log_path = self._logs_dir / date_str / f"{worker.name}.log"
        elif log_type == "transcript":
            log_path = self._data_dir / "projects" / worker.session_id / "transcript.jsonl"
        else:
            # Default: process stdout/stderr
            log_path = Path(worker.log_path) if worker.log_path else self._logs_dir / f"{worker.name}.log"

        if not log_path.is_file():
            return ""

        try:
            lines = log_path.read_text(encoding="utf-8", errors="replace").splitlines()
            return "\n".join(lines[-tail:])
        except OSError as exc:
            logger.warning("Cannot read log %s: %s", log_path, exc)
            return ""

    def kill_worker(self, worker_id: str) -> bool:
        """Terminate a worker process.

        Sends ``SIGTERM`` first, waits up to 5 s, then sends ``SIGKILL``.
        On Windows, uses ``taskkill /F /PID``.

        Returns
        -------
        bool
            ``True`` if the process was successfully terminated.
        """
        worker = self.get_worker(worker_id)
        if worker is None:
            logger.warning("Worker %s not found", worker_id)
            return False

        if worker.status != "running":
            logger.info("Worker %s already %s", worker_id, worker.status)
            self._remove_pid_file(worker_id)
            return True

        pid = worker.pid
        logger.info("Killing worker %s (pid=%d)", worker_id, pid)

        try:
            if _IS_WINDOWS:
                subprocess.run(
                    ["taskkill", "/F", "/PID", str(pid)],
                    check=False,
                    capture_output=True,
                )
            else:
                os.kill(pid, signal.SIGTERM)

                # Wait up to 5 s for graceful exit
                for _ in range(50):
                    if not self._is_alive(pid):
                        break
                    time.sleep(0.1)
                else:
                    # Force kill
                    try:
                        os.kill(pid, signal.SIGKILL)
                    except (OSError, ProcessLookupError):
                        pass
        except (PermissionError, OSError) as exc:
            logger.error("Cannot kill pid %d: %s", pid, exc)
            return False

        # Update status
        worker.status = "stopped"
        with self._lock:
            self._write_pid_file(worker)

        return True

    def attach_worker(self, worker_id: str) -> Optional[dict[str, Any]]:
        """Return attach information for a worker.

        Includes the log path and command for re-connecting to the process.
        """
        worker = self.get_worker(worker_id)
        if worker is None:
            return None
        return {
            "id": worker.id,
            "pid": worker.pid,
            "name": worker.name,
            "command": worker.command,
            "cwd": worker.cwd,
            "log_path": worker.log_path,
            "status": worker.status,
            "kind": worker.kind,
            "started_at": worker.started_at,
        }

    def cleanup_stale(self) -> int:
        """Remove PID files whose processes are no longer alive.

        Returns
        -------
        int
            Number of stale entries removed.
        """
        removed = 0
        with self._lock:
            for pid_file in list(self._workers_dir.glob("*.json")):
                try:
                    data = json.loads(pid_file.read_text(encoding="utf-8"))
                    w = Worker.from_dict(data)
                except (json.JSONDecodeError, TypeError):
                    # Corrupt file — remove it
                    pid_file.unlink(missing_ok=True)
                    removed += 1
                    continue

                if not self._is_alive(w.pid):
                    logger.debug("Cleaning stale worker %s (pid=%d)", w.id, w.pid)
                    pid_file.unlink(missing_ok=True)
                    removed += 1

        return removed

    # ---- Daemon management ----

    def start_daemon(self, port: int = 7890, host: str = "127.0.0.1") -> Worker:
        """Start the Gateway daemon (idempotent).

        If a daemon is already running on the same host/port, return its
        existing ``Worker`` entry instead of launching a new one.

        Parameters
        ----------
        port:
            Port for the HTTP server.
        host:
            Bind address.
        """
        # Check for existing daemon
        daemon_worker = self.get_worker("daemon")
        if daemon_worker is not None and self._is_alive(daemon_worker.pid):
            logger.info("Daemon already running (pid=%d)", daemon_worker.pid)
            daemon_worker.url = f"http://{host}:{port}"
            return daemon_worker

        log_path = self._logs_dir / "daemon.log"
        log_path.parent.mkdir(parents=True, exist_ok=True)

        cmd = [
            sys.executable,
            "-m",
            "superagent",
            "serve",
            "--port",
            str(port),
            "--host",
            host,
        ]

        logger.info("Starting Gateway daemon: %s", cmd)

        with open(log_path, "a", encoding="utf-8") as log_fh:
            proc = subprocess.Popen(
                cmd,
                cwd=os.getcwd(),
                env={**os.environ, "SUPERAGENT_DAEMON": "1"},
                stdout=log_fh,
                stderr=subprocess.STDOUT,
                start_new_session=True,
            )

        worker = Worker(
            id="daemon",
            pid=proc.pid,
            session_id=f"daemon-{uuid.uuid4().hex[:8]}",
            name="daemon",
            kind="daemon",
            cwd=os.getcwd(),
            started_at=time.time(),
            url=f"http://{host}:{port}",
            status="running",
            hostname=platform.node(),
            command=" ".join(cmd),
            log_path=str(log_path),
        )

        with self._lock:
            self._write_pid_file(worker)

        return worker

    def stop_daemon(self) -> bool:
        """Stop the Gateway daemon.

        Returns
        -------
        bool
            ``True`` if the daemon was stopped (or was not running).
        """
        daemon_worker = self.get_worker("daemon")
        if daemon_worker is None:
            logger.info("No daemon found")
            return True

        if not self._is_alive(daemon_worker.pid):
            self._remove_pid_file("daemon")
            return True

        return self.kill_worker("daemon")

    def daemon_status(self) -> Optional[dict[str, Any]]:
        """Check daemon status.

        Returns
        -------
        dict or None
            Daemon info dict, or ``None`` if no daemon is registered.
        """
        worker = self.get_worker("daemon")
        if worker is None:
            return None

        alive = self._is_alive(worker.pid)
        return {
            "status": "running" if alive else "stopped",
            "pid": worker.pid,
            "endpoint": worker.url,
            "startedAt": int(worker.started_at * 1000),
            "hostname": worker.hostname,
        }

    # ---- Background task launcher ----

    def launch_bg_task(
        self,
        name: str,
        goal: str,
        command: str = "builtin",
        team: str | None = None,
    ) -> Worker:
        """Launch ``superagent auto "goal"`` in the background.

        This is the primary entry point for running autonomous agent tasks
        without blocking the terminal.

        Parameters
        ----------
        name:
            Display name (used for PID file and log file).
        goal:
            Natural-language goal passed to ``superagent auto``.
        command:
            Execution backend identifier (``builtin``, ``hermes``, etc.).
            Currently informational only; the actual CLI handles routing.
        team:
            Optional team name to assign.
        """
        args = ["auto", goal]
        if team:
            args.extend(["--team", team])
        if command != "builtin":
            args.extend(["--engine", command])

        return self.start_background(
            name=name,
            args=args,
        )
