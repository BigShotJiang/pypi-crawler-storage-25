"""SuperAgent Gateway CLI — serve, daemon, and worker management commands.

Inspired by CodeBuddy CLI's ``--serve``, ``daemon start/stop/status``,
and OpenClaw's Gateway control plane.

Usage:
    superagent gateway serve --port 7890    # Start Gateway with Web UI
    superagent gateway serve --tls          # Enable HTTPS with self-signed cert
    superagent gateway serve --tunnel       # Start Cloudflare Tunnel
    superagent gateway daemon start         # Start daemon in background
    superagent gateway daemon stop          # Stop running daemon
    superagent gateway daemon status        # Check daemon status
    superagent gateway ps                   # List running workers
    superagent gateway logs <name>          # View worker logs
    superagent gateway kill <name>          # Terminate a worker
    superagent gateway bg "goal"            # Run task in background
    superagent gateway user-create <name>   # Create a user
    superagent gateway user-list            # List users
    superagent gateway api-key-create <name> # Create an API key
"""

from __future__ import annotations

import os
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

console = Console()
gateway_app = typer.Typer(
    name="gateway",
    help="Gateway — serve Web UI, manage daemon and workers (CodeBuddy/OpenClaw pattern).",
    no_args_is_help=True,
)


@gateway_app.command("serve")
def gateway_serve(
    port: int = typer.Option(7890, "--port", "-p", help="Port for Gateway HTTP server."),
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind (0.0.0.0 for LAN access)."),
    password: Optional[str] = typer.Option(None, "--password", help="Auth password (auto-generated if not set)."),
    no_auth: bool = typer.Option(False, "--no-auth", help="Disable authentication (local only)."),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't auto-open browser."),
    tunnel: bool = typer.Option(False, "--tunnel", help="Start Cloudflare Tunnel for public HTTPS access."),
    tls: bool = typer.Option(False, "--tls", help="Enable HTTPS with self-signed certificate."),
    cert_file: Optional[str] = typer.Option(None, "--cert", help="Path to TLS certificate PEM file."),
    key_file: Optional[str] = typer.Option(None, "--key", help="Path to TLS private key PEM file."),
    sandbox: bool = typer.Option(True, "--sandbox/--no-sandbox", help="Enable OS-level sandbox for run execution."),
):
    """Start the SuperAgent Gateway with Web UI and REST API."""
    try:
        from superagent.gateway import create_gateway_app, GatewayConfig, run_server
    except ImportError:
        console.print("[red]Gateway dependencies not installed.[/red]")
        console.print("Install: [cyan]pip install fastapi 'uvicorn[standard]'[/cyan]")
        raise typer.Exit(1)

    # Build TLS config
    tls_config = None
    if tls or cert_file or key_file or tunnel:
        try:
            from superagent.tls import TLSConfig
            tls_config = TLSConfig(
                cert_file=cert_file,
                key_file=key_file,
                tunnel=tunnel,
            )
        except ImportError:
            console.print("[yellow]TLS module not available. Install: pip install cryptography[/yellow]")

    config = GatewayConfig(
        host=host,
        port=port,
        auth="none" if no_auth else "password",
        password=password,
        tls=tls_config,
        tunnel=tunnel,
        sandbox=sandbox,
    )

    # Auto-open browser
    if not no_browser:
        import threading
        import webbrowser
        scheme = "https" if (tls or cert_file) else "http"
        url = f"{scheme}://{host}:{port}"
        if config.auth == "password" and config.password:
            url += f"?password={config.password}"
        threading.Timer(1.5, lambda: webbrowser.open(url)).start()

    # Print connection info
    scheme = "https" if (tls or cert_file) else "http"
    console.print(Panel(
        f"[bold green]SuperAgent Gateway[/bold green]\n\n"
        f"  URL:     {scheme}://{host}:{port}\n"
        f"  Auth:    {config.auth}\n"
        f"  TLS:     {'enabled' if (tls or cert_file) else 'disabled'}\n"
        f"  Sandbox: {'enabled' if sandbox else 'disabled'}\n"
        f"  API:     {scheme}://{host}:{port}/api/v1/health\n"
        f"  Docs:    {scheme}://{host}:{port}/api/docs\n",
        title="Gateway Started",
        border_style="green",
    ))

    if config.auth == "password" and config.password:
        console.print(f"[yellow]Password: {config.password}[/yellow]")

    if tunnel:
        console.print("[cyan]Cloudflare Tunnel: will start automatically if cloudflared is installed.[/cyan]")

    run_server(config)


@gateway_app.command("daemon")
def daemon_cmd(
    action: str = typer.Argument(..., help="Action: start, stop, status, restart"),
    port: int = typer.Option(7890, "--port", "-p", help="Port for daemon."),
    host: str = typer.Option("127.0.0.1", "--host", help="Host to bind."),
):
    """Manage the SuperAgent Gateway daemon (background service)."""
    try:
        from superagent.worker_manager import WorkerManager
    except ImportError:
        console.print("[red]Worker manager not available.[/red]")
        raise typer.Exit(1)

    wm = WorkerManager()

    if action == "start":
        result = wm.start_daemon(port=port, host=host)
        if result:
            console.print(Panel(
                f"[bold green]Daemon Started[/bold green]\n\n"
                f"  PID:   {result.pid}\n"
                f"  URL:   http://{host}:{port}\n"
                f"  Status: running",
                border_style="green",
            ))
        else:
            console.print("[yellow]Daemon may already be running.[/yellow]")

    elif action == "stop":
        wm.stop_daemon()
        console.print("[green]Daemon stopped.[/green]")

    elif action == "status":
        status = wm.daemon_status()
        if status:
            console.print(Panel(
                f"  Status:    [green]running[/green]\n"
                f"  PID:       {status.get('pid', 'N/A')}\n"
                f"  URL:       {status.get('url', 'N/A')}\n"
                f"  Started:   {status.get('started_at', 'N/A')}",
                title="Daemon Status",
                border_style="green",
            ))
        else:
            console.print("[yellow]Daemon is not running.[/yellow]")

    elif action == "restart":
        wm.stop_daemon()
        import time
        time.sleep(1)
        result = wm.start_daemon(port=port, host=host)
        if result:
            console.print("[green]Daemon restarted.[/green]")
        else:
            console.print("[red]Failed to restart daemon.[/red]")
    else:
        console.print(f"[red]Unknown action: {action}[/red]")
        console.print("Valid actions: start, stop, status, restart")


@gateway_app.command("ps")
def list_workers(
    kind: Optional[str] = typer.Option(None, "--kind", "-k", help="Filter by kind: interactive, bg, daemon"),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """List running worker processes."""
    try:
        from superagent.worker_manager import WorkerManager
    except ImportError:
        console.print("[red]Worker manager not available.[/red]")
        raise typer.Exit(1)

    wm = WorkerManager()
    workers = wm.list_workers(kind=kind)

    if json_out:
        import json
        console.print(json.dumps([w.to_dict() for w in workers], indent=2, default=str))
        return

    if not workers:
        console.print("[dim]No running workers.[/dim]")
        return

    table = Table(title="SuperAgent Workers")
    table.add_column("ID", style="cyan")
    table.add_column("PID", style="green")
    table.add_column("Name", style="white")
    table.add_column("Kind", style="yellow")
    table.add_column("Status", style="magenta")
    table.add_column("CWD", style="dim")

    for w in workers:
        table.add_row(
            str(w.id),
            str(w.pid),
            w.name,
            w.kind,
            w.status,
            w.cwd[:40],
        )

    console.print(table)


@gateway_app.command("logs")
def worker_logs(
    name: str = typer.Argument(..., help="Worker name or PID."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output."),
    tail: int = typer.Option(100, "--tail", "-n", help="Number of lines to show."),
    log_type: Optional[str] = typer.Option(None, "--type", "-t", help="Log type: process, telemetry, transcript"),
):
    """View worker logs."""
    try:
        from superagent.worker_manager import WorkerManager
    except ImportError:
        console.print("[red]Worker manager not available.[/red]")
        raise typer.Exit(1)

    wm = WorkerManager()
    logs = wm.get_worker_logs(name, log_type=log_type, tail=tail)

    if not logs:
        console.print(f"[dim]No logs found for {name}.[/dim]")
        return

    console.print(logs)

    if follow:
        import time
        data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
        log_path = os.path.join(data_dir, "logs", f"{name}.log")
        if os.path.isfile(log_path):
            with open(log_path) as f:
                f.seek(0, 2)  # seek to end
                while True:
                    line = f.readline()
                    if line:
                        console.print(line.rstrip())
                    else:
                        time.sleep(0.5)


@gateway_app.command("kill")
def kill_worker(
    name: str = typer.Argument(..., help="Worker name or PID to terminate."),
):
    """Terminate a running worker process."""
    try:
        from superagent.worker_manager import WorkerManager
    except ImportError:
        console.print("[red]Worker manager not available.[/red]")
        raise typer.Exit(1)

    wm = WorkerManager()
    success = wm.kill_worker(name)
    if success:
        console.print(f"[green]Worker {name} terminated.[/green]")
    else:
        console.print(f"[red]Failed to terminate worker {name}.[/red]")


@gateway_app.command("bg")
def bg_task(
    goal: str = typer.Argument(..., help="Goal/task description."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Session name (auto-generated if not set)."),
    command: str = typer.Option("builtin", "--command", "-c", help="Execution engine: builtin, hermes, deerflow."),
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Team name."),
):
    """Run a task in the background (non-interactive)."""
    try:
        from superagent.worker_manager import WorkerManager
    except ImportError:
        console.print("[red]Worker manager not available.[/red]")
        raise typer.Exit(1)

    import uuid
    if not name:
        name = f"bg-{uuid.uuid4().hex[:6]}"

    wm = WorkerManager()
    worker = wm.launch_bg_task(name=name, goal=goal, command=command, team=team)

    if worker:
        console.print(Panel(
            f"[bold green]Background Task Started[/bold green]\n\n"
            f"  ID:     {worker.id}\n"
            f"  Name:   {worker.name}\n"
            f"  Goal:   {goal[:100]}\n\n"
            f"  [dim]superagent gateway logs {worker.name}[/dim]\n"
            f"  [dim]superagent gateway ps[/dim]",
            border_style="green",
        ))
    else:
        console.print("[red]Failed to start background task.[/red]")


# ── User management commands ──


@gateway_app.command("user-create")
def user_create(
    username: str = typer.Argument(..., help="Username for the new user."),
    role: str = typer.Option("user", "--role", "-r", help="Role: admin, user, viewer"),
    password: Optional[str] = typer.Option(None, "--password", "-p", help="Password (auto-generated if not set)."),
):
    """Create a new user account."""
    try:
        from superagent.auth import get_auth_manager, Role
    except ImportError:
        console.print("[red]Auth module not available. Install: pip install passlib[bcrypt] python-jose[cryptography][/red]")
        raise typer.Exit(1)

    try:
        role_enum = Role(role)
    except ValueError:
        console.print(f"[red]Invalid role: {role}. Must be: admin, user, viewer[/red]")
        raise typer.Exit(1)

    if not password:
        import secrets
        password = secrets.token_urlsafe(16)

    am = get_auth_manager()

    # Check if user already exists
    if am.get_user_by_username(username):
        console.print(f"[red]User '{username}' already exists.[/red]")
        raise typer.Exit(1)

    user = am.create_user(username, password, role_enum)
    console.print(Panel(
        f"[bold green]User Created[/bold green]\n\n"
        f"  Username: {username}\n"
        f"  Role:     {role}\n"
        f"  Password: {password}\n\n"
        f"  [dim]Store this password securely — it won't be shown again.[/dim]",
        border_style="green",
    ))


@gateway_app.command("user-list")
def user_list():
    """List all user accounts."""
    try:
        from superagent.auth import get_auth_manager
    except ImportError:
        console.print("[red]Auth module not available.[/red]")
        raise typer.Exit(1)

    am = get_auth_manager()
    users = am.list_users()

    if not users:
        console.print("[dim]No users found.[/dim]")
        return

    table = Table(title="SuperAgent Users")
    table.add_column("ID", style="dim")
    table.add_column("Username", style="cyan")
    table.add_column("Role", style="green")
    table.add_column("Active", style="yellow")
    table.add_column("Last Login", style="dim")

    for u in users:
        table.add_row(
            u.id[:8] + "...",
            u.username,
            u.role.value,
            str(u.is_active),
            u.last_login or "never",
        )

    console.print(table)


@gateway_app.command("api-key-create")
def api_key_create(
    name: str = typer.Argument(..., help="Human-readable label for the API key."),
    role: str = typer.Option("user", "--role", "-r", help="Role: admin, user, viewer"),
    username: Optional[str] = typer.Option(None, "--user", "-u", help="Create key for this user (admin only)."),
):
    """Create a new API key for programmatic access."""
    try:
        from superagent.auth import get_auth_manager, Role
    except ImportError:
        console.print("[red]Auth module not available. Install: pip install passlib[bcrypt] python-jose[cryptography][/red]")
        raise typer.Exit(1)

    try:
        role_enum = Role(role)
    except ValueError:
        console.print(f"[red]Invalid role: {role}. Must be: admin, user, viewer[/red]")
        raise typer.Exit(1)

    am = get_auth_manager()

    # Determine target user
    if username:
        target_user = am.get_user_by_username(username)
        if not target_user:
            console.print(f"[red]User '{username}' not found.[/red]")
            raise typer.Exit(1)
    else:
        # Use the first admin user as default
        users = am.list_users()
        admin = next((u for u in users if u.role == Role.admin), None)
        if not admin:
            console.print("[red]No admin user found. Create one first with 'user-create'.[/red]")
            raise typer.Exit(1)
        target_user = admin

    api_key, raw_key = am.create_api_key(target_user.id, name, role_enum)
    console.print(Panel(
        f"[bold green]API Key Created[/bold green]\n\n"
        f"  Name:    {name}\n"
        f"  Role:    {role}\n"
        f"  Prefix:  {api_key.key_prefix}...\n"
        f"  Key:     {raw_key}\n\n"
        f"  [red]Store this key securely — it won't be shown again![/red]",
        border_style="green",
    ))
