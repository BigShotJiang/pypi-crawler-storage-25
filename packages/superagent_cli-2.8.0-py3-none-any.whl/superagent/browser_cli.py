"""SuperAgent browser CLI commands — web automation via browser-use."""

from __future__ import annotations

import typer
from rich.console import Console
from rich.panel import Panel

from superagent.browser_agent import browse, is_browser_available

browser_app = typer.Typer(
    name="browser",
    help="Browser automation — browse the web, fill forms, scrape data with browser-use.",
    no_args_is_help=True,
)
console = Console()


@browser_app.command("run")
def browser_run(
    task: str = typer.Argument(..., help="Browser task to execute (e.g. 'Go to google.com and search for AI agents')."),
    max_steps: int = typer.Option(15, "--max-steps", "-s", help="Maximum browser interaction steps."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Execute a browser automation task."""
    if not is_browser_available():
        console.print(Panel(
            "[red]browser-use is not installed.[/red]\n\n"
            "Install it with: [bold]pip install browser-use[/bold]",
            title="Browser Not Available",
            border_style="red",
        ))
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold]{task}[/bold]\n[dim]max steps: {max_steps}[/dim]",
        title="Browser Task",
        border_style="cyan",
    ))

    with console.status("[cyan]Running browser task...[/cyan]"):
        result = browse(task, max_steps=max_steps)

    if json_out:
        import json
        console.print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if result["success"]:
        console.print(Panel(
            str(result.get("output", "")),
            title="[green]Result[/green]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[red]{result.get('error', 'Unknown error')}[/red]",
            title="[red]Failed[/red]",
            border_style="red",
        ))
        raise typer.Exit(1)


@browser_app.command("status")
def browser_status():
    """Check if browser-use is available."""
    available = is_browser_available()

    if available:
        console.print(Panel(
            "[green]browser-use is installed and ready.[/green]\n\n"
            "Engine: [bold]browser-use[/bold]\n"
            "Run a task with: [bold]superagent browser run \"your task here\"[/bold]",
            title="Browser Status",
            border_style="green",
        ))
    else:
        console.print(Panel(
            "[yellow]browser-use is not installed.[/yellow]\n\n"
            "Install with: [bold]pip install browser-use[/bold]\n"
            "Docs: https://github.com/browser-use/browser-use",
            title="Browser Status",
            border_style="yellow",
        ))


@browser_app.command("search")
def browser_search(
    query: str = typer.Argument(..., help="Search query to run via browser."),
    max_steps: int = typer.Option(10, "--max-steps", "-s", help="Maximum browser interaction steps."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Quick web search via browser automation."""
    if not is_browser_available():
        console.print(Panel(
            "[red]browser-use is not installed.[/red]\n\n"
            "Install it with: [bold]pip install browser-use[/bold]",
            title="Browser Not Available",
            border_style="red",
        ))
        raise typer.Exit(1)

    task = f"Search Google for '{query}' and return the top results with titles and URLs."

    console.print(Panel(
        f"[bold]Searching:[/bold] {query}",
        title="Browser Search",
        border_style="cyan",
    ))

    with console.status("[cyan]Searching...[/cyan]"):
        result = browse(task, max_steps=max_steps)

    if json_out:
        import json
        console.print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    if result["success"]:
        console.print(Panel(
            str(result.get("output", "")),
            title=f"[green]Search Results: {query}[/green]",
            border_style="green",
        ))
    else:
        console.print(Panel(
            f"[red]{result.get('error', 'Unknown error')}[/red]",
            title="[red]Search Failed[/red]",
            border_style="red",
        ))
        raise typer.Exit(1)
