"""Guardrails safety system for SuperAgent — input/output safety checks.

Inspired by OpenAI Agents SDK's Guardrails pattern.  Provides a rule-based
engine that checks agent inputs and outputs against configurable regex patterns,
blocking, warning, or logging potential safety violations.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import asdict, dataclass, field
from enum import Enum
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write


class GuardrailAction(str, Enum):
    """Action to take when a guardrail rule matches."""

    block = "block"
    warn = "warn"
    log = "log"


@dataclass
class GuardrailRule:
    """A single guardrail rule definition."""

    name: str
    pattern: str
    action: GuardrailAction
    scope: str = "both"  # "input", "output", or "both"
    description: str = ""

    def to_dict(self) -> dict:
        d = asdict(self)
        d["action"] = self.action.value
        return d

    @classmethod
    def from_dict(cls, data: dict) -> GuardrailRule:
        action = data.get("action", "log")
        if isinstance(action, str):
            action = GuardrailAction(action)
        return cls(
            name=data["name"],
            pattern=data["pattern"],
            action=action,
            scope=data.get("scope", "both"),
            description=data.get("description", ""),
        )


@dataclass
class GuardrailResult:
    """Result of checking text against guardrail rules."""

    passed: bool
    violations: list[dict] = field(default_factory=list)


# ------------------------------------------------------------------
# Default built-in rules
# ------------------------------------------------------------------

_DEFAULT_RULES: list[dict] = [
    {
        "name": "no-rm-rf",
        "pattern": r"rm\s+(-rf?|--recursive).*\/",
        "action": "block",
        "scope": "output",
        "description": "Block recursive file deletion commands.",
    },
    {
        "name": "no-secrets",
        "pattern": r"(api[_\-]?key|password|secret|token)\s*[:=]\s*\S+",
        "action": "warn",
        "scope": "both",
        "description": "Warn on potential secrets or credentials in text.",
    },
    {
        "name": "no-sudo-rm",
        "pattern": r"sudo\s+rm",
        "action": "block",
        "scope": "output",
        "description": "Block sudo rm commands.",
    },
    {
        "name": "no-drop-table",
        "pattern": r"drop\s+(table|database)",
        "action": "block",
        "scope": "output",
        "description": "Block SQL DROP TABLE/DATABASE statements.",
    },
    {
        "name": "no-format-disk",
        "pattern": r"(mkfs|fdisk|dd\s+if=)",
        "action": "block",
        "scope": "output",
        "description": "Block disk formatting and low-level disk operations.",
    },
    {
        "name": "no-env-leak",
        "pattern": r"\.(env|credentials|pem|key)\b",
        "action": "warn",
        "scope": "output",
        "description": "Warn on references to sensitive environment/credential files.",
    },
    {
        "name": "no-sandbox-escape",
        "pattern": r"(\.superagent[/\\]gateway|jwt_secret|sandbox_exec)",
        "action": "block",
        "scope": "output",
        "description": "Block attempts to access Gateway config or JWT secret from agent code.",
    },
    {
        "name": "no-sudo",
        "pattern": r"\bsudo\s+",
        "action": "block",
        "scope": "output",
        "description": "Block sudo commands — sandbox should not escalate privileges.",
    },
]


class GuardrailEngine:
    """Rule-based safety engine for checking agent inputs and outputs.

    Rules are persisted to ``<rules_dir>/rules.json``.  On first
    initialisation (when no rules file exists) the built-in default rules
    are written automatically.
    """

    def __init__(self, rules_dir: Optional[str | Path] = None) -> None:
        if rules_dir is None:
            data_dir = os.environ.get(
                "CLAWTEAM_DATA_DIR",
                os.path.join(os.path.expanduser("~"), ".superagent"),
            )
            rules_dir = os.path.join(data_dir, "guardrails")

        self._rules_dir = Path(rules_dir)
        self._rules_path = self._rules_dir / "rules.json"
        self._rules: list[GuardrailRule] = []
        self.load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Load rules from disk, or initialise with defaults if absent."""
        if self._rules_path.exists():
            try:
                data = json.loads(self._rules_path.read_text(encoding="utf-8"))
                self._rules = [GuardrailRule.from_dict(r) for r in data]
                return
            except (json.JSONDecodeError, KeyError, OSError):
                pass

        # First run — seed with built-in defaults
        self._rules = [GuardrailRule.from_dict(r) for r in _DEFAULT_RULES]
        self.save()

    def save(self) -> None:
        """Persist current rules to disk."""
        self._rules_dir.mkdir(parents=True, exist_ok=True)
        data = [r.to_dict() for r in self._rules]
        atomic_write(self._rules_path, json.dumps(data, indent=2, ensure_ascii=False))

    # ------------------------------------------------------------------
    # Rule management
    # ------------------------------------------------------------------

    def add_rule(self, rule: GuardrailRule) -> None:
        """Add a rule (replaces any existing rule with the same name)."""
        self._rules = [r for r in self._rules if r.name != rule.name]
        self._rules.append(rule)
        self.save()

    def remove_rule(self, name: str) -> bool:
        """Remove a rule by name.  Returns True if found and removed."""
        before = len(self._rules)
        self._rules = [r for r in self._rules if r.name != name]
        if len(self._rules) < before:
            self.save()
            return True
        return False

    def list_rules(self) -> list[GuardrailRule]:
        """Return a copy of all current rules."""
        return list(self._rules)

    # ------------------------------------------------------------------
    # Checking
    # ------------------------------------------------------------------

    def check(self, text: str, scope: str = "input") -> GuardrailResult:
        """Check *text* against all rules applicable to *scope*.

        Returns a :class:`GuardrailResult` whose ``passed`` flag is ``False``
        if any *block* rule matched.
        """
        violations: list[dict] = []

        for rule in self._rules:
            if rule.scope != "both" and rule.scope != scope:
                continue

            try:
                match = re.search(rule.pattern, text, re.IGNORECASE)
            except re.error:
                continue

            if match:
                violations.append({
                    "rule_name": rule.name,
                    "matched_text": match.group(),
                    "action": rule.action.value,
                })

        passed = all(v["action"] != "block" for v in violations)
        return GuardrailResult(passed=passed, violations=violations)

    def check_input(self, text: str) -> GuardrailResult:
        """Convenience wrapper — check text as agent input."""
        return self.check(text, scope="input")

    def check_output(self, text: str) -> GuardrailResult:
        """Convenience wrapper — check text as agent output."""
        return self.check(text, scope="output")


# ------------------------------------------------------------------
# Singleton factory
# ------------------------------------------------------------------

_engine_instance: Optional[GuardrailEngine] = None


def get_guardrail_engine() -> GuardrailEngine:
    """Return a singleton :class:`GuardrailEngine` instance."""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = GuardrailEngine()
    return _engine_instance
