"""Langfuse-powered observability for SuperAgent — agent execution tracing.

Provides an ``ObservabilityTracer`` that records traces, events, and LLM calls
to a Langfuse instance.  When Langfuse is not installed or configured, a silent
``NoopTracer`` is returned so callers never need to guard imports.
"""

from __future__ import annotations

import logging
import os
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Optional

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


def is_langfuse_available() -> bool:
    """Return *True* if the ``langfuse`` package is importable **and** the
    required environment variables are set."""
    try:
        import langfuse  # noqa: F401
    except ImportError:
        return False
    return bool(
        os.environ.get("LANGFUSE_PUBLIC_KEY")
        and os.environ.get("LANGFUSE_SECRET_KEY")
    )


# ------------------------------------------------------------------
# Data helpers
# ------------------------------------------------------------------

@dataclass
class TraceRecord:
    """Lightweight in-memory representation of an active trace."""

    trace_id: str
    name: str
    metadata: dict[str, Any] = field(default_factory=dict)
    started_at: str = ""
    ended_at: str = ""
    status: str = "running"
    output: Any = None


# ------------------------------------------------------------------
# Noop implementation (used when Langfuse is unavailable)
# ------------------------------------------------------------------

class NoopTracer:
    """Silent stand-in that satisfies the tracer interface but does nothing."""

    def trace_start(self, name: str, metadata: Optional[dict[str, Any]] = None) -> str:
        return uuid.uuid4().hex[:16]

    def trace_event(
        self,
        trace_id: str,
        name: str,
        input: Any = None,
        output: Any = None,
        level: str = "DEFAULT",
    ) -> None:
        return

    def trace_end(
        self,
        trace_id: str,
        status: str = "success",
        output: Any = None,
    ) -> None:
        return

    def trace_llm_call(
        self,
        trace_id: str,
        model: str,
        input: Any = None,
        output: Any = None,
        tokens: Optional[dict[str, int]] = None,
        cost: Optional[float] = None,
    ) -> None:
        return

    def get_traces(self, limit: int = 20) -> list[dict[str, Any]]:
        return []


# ------------------------------------------------------------------
# Real Langfuse tracer
# ------------------------------------------------------------------

class ObservabilityTracer:
    """Wraps the Langfuse SDK to provide a simple tracing API for SuperAgent.

    Parameters are read from environment variables:
    - ``LANGFUSE_PUBLIC_KEY``
    - ``LANGFUSE_SECRET_KEY``
    - ``LANGFUSE_HOST`` (optional, defaults to Langfuse cloud)
    """

    def __init__(self) -> None:
        from langfuse import Langfuse

        self._client = Langfuse(
            public_key=os.environ["LANGFUSE_PUBLIC_KEY"],
            secret_key=os.environ["LANGFUSE_SECRET_KEY"],
            host=os.environ.get("LANGFUSE_HOST", "https://cloud.langfuse.com"),
        )
        self._traces: dict[str, Any] = {}

    # ------------------------------------------------------------------
    # Trace lifecycle
    # ------------------------------------------------------------------

    def trace_start(self, name: str, metadata: Optional[dict[str, Any]] = None) -> str:
        """Begin a new trace and return its ``trace_id``."""
        trace_id = uuid.uuid4().hex[:16]
        trace = self._client.trace(
            id=trace_id,
            name=name,
            metadata=metadata or {},
        )
        self._traces[trace_id] = trace
        return trace_id

    def trace_event(
        self,
        trace_id: str,
        name: str,
        input: Any = None,
        output: Any = None,
        level: str = "DEFAULT",
    ) -> None:
        """Log an event within an existing trace."""
        trace = self._traces.get(trace_id)
        if trace is None:
            return
        trace.event(
            name=name,
            input=input,
            output=output,
            level=level,
        )

    def trace_end(
        self,
        trace_id: str,
        status: str = "success",
        output: Any = None,
    ) -> None:
        """End a trace, recording its final status and output."""
        trace = self._traces.pop(trace_id, None)
        if trace is None:
            return
        trace.update(
            output=output,
            metadata={"status": status},
        )
        # Flush to ensure the trace is persisted
        self._client.flush()

    # ------------------------------------------------------------------
    # LLM call logging
    # ------------------------------------------------------------------

    def trace_llm_call(
        self,
        trace_id: str,
        model: str,
        input: Any = None,
        output: Any = None,
        tokens: Optional[dict[str, int]] = None,
        cost: Optional[float] = None,
    ) -> None:
        """Log an LLM generation within an existing trace.

        *tokens* should be a dict like ``{"input": 120, "output": 55}`` when
        available.  *cost* is the total cost in USD (optional).
        """
        trace = self._traces.get(trace_id)
        if trace is None:
            return

        usage = None
        if tokens:
            usage = {
                "input": tokens.get("input", 0),
                "output": tokens.get("output", 0),
                "total": tokens.get("input", 0) + tokens.get("output", 0),
            }

        generation_kwargs: dict[str, Any] = {
            "name": f"llm-{model}",
            "model": model,
            "input": input,
            "output": output,
        }
        if usage is not None:
            generation_kwargs["usage"] = usage
        if cost is not None:
            generation_kwargs["metadata"] = {"cost_usd": cost}

        trace.generation(**generation_kwargs)

    # ------------------------------------------------------------------
    # Query helpers
    # ------------------------------------------------------------------

    def get_traces(self, limit: int = 20) -> list[dict[str, Any]]:
        """Return recent traces from Langfuse.

        Returns a list of dicts with keys: ``id``, ``name``, ``status``,
        ``started_at``, ``metadata``.
        """
        try:
            response = self._client.fetch_traces(limit=limit)
            traces = response.data if hasattr(response, "data") else response
            results: list[dict[str, Any]] = []
            for t in traces:
                results.append({
                    "id": getattr(t, "id", ""),
                    "name": getattr(t, "name", ""),
                    "status": getattr(t, "metadata", {}).get("status", "unknown"),
                    "started_at": str(getattr(t, "timestamp", "")),
                    "metadata": getattr(t, "metadata", {}),
                })
            return results
        except Exception as e:
            logger.debug("Langfuse trace listing failed: %s", e)
            return []


# ------------------------------------------------------------------
# Factory
# ------------------------------------------------------------------

def get_tracer() -> ObservabilityTracer | NoopTracer:
    """Return an ``ObservabilityTracer`` if Langfuse is available, otherwise a
    silent ``NoopTracer``."""
    if is_langfuse_available():
        try:
            return ObservabilityTracer()
        except Exception as e:
            logger.debug("Langfuse tracer initialization failed: %s", e)
            return NoopTracer()
    return NoopTracer()
