"""SuperAgent local CLI commands — manage local LLM backends (Ollama, LocalAI, llama.cpp)."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.local_models import (
    call_local,
    detect_backends,
    get_best_local_backend,
    register_local_in_gateway,
    setup_ollama,
)

local_app = typer.Typer(
    name="local",
    help="Local AI — zero-cost offline inference via Ollama, LocalAI, and llama.cpp.",
    no_args_is_help=True,
)
console = Console()

# ---------------------------------------------------------------------------
# Install instructions shown when no backends are found
# ---------------------------------------------------------------------------

_INSTALL_HELP = """\
[bold]No local backends detected.[/bold] Install one to get started:

[cyan]Ollama[/cyan] (recommended — easiest setup):
  curl -fsSL https://ollama.ai/install.sh | sh
  ollama serve          # start the service
  ollama pull llama3.2  # download a model

[cyan]LocalAI[/cyan] (OpenAI-compatible, any model):
  docker run -p 8080:8080 localai/localai

[cyan]llama.cpp[/cyan] (lowest level, maximum control):
  brew install llama.cpp   # or build from source
  llama-server -m model.gguf --port 8081\
"""


@local_app.command("status")
def local_status(
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Detect all local backends and show their status."""
    backends = detect_backends()

    if json_out:
        import json

        data = [b.to_dict() for b in backends]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not backends:
        console.print(Panel(_INSTALL_HELP, title="Local AI Status", border_style="yellow"))
        return

    table = Table(title=f"Local AI Backends ({len(backends)})")
    table.add_column("Backend", style="bold", width=12)
    table.add_column("Status", width=12)
    table.add_column("Base URL", style="dim", width=30)
    table.add_column("Models", style="cyan", max_width=40)
    table.add_column("Version", style="dim", width=20)

    for b in backends:
        if b.status == "running":
            status = "[green]running[/green]"
        elif b.status == "installed":
            status = "[yellow]installed[/yellow]"
        else:
            status = "[red]not found[/red]"

        models_str = ", ".join(b.models[:5]) if b.models else "[dim]none[/dim]"
        if len(b.models) > 5:
            models_str += f" (+{len(b.models) - 5} more)"

        table.add_row(b.name, status, b.base_url, models_str, b.version or "-")

    console.print(table)

    running = [b for b in backends if b.status == "running"]
    if running:
        best = running[0]
        console.print(
            f"\n[green]Ready:[/green] {best.name} is running with "
            f"{len(best.models)} model(s). Use [bold]superagent local run <prompt>[/bold] to chat."
        )
    else:
        installed = [b for b in backends if b.status == "installed"]
        if installed:
            console.print(
                f"\n[yellow]Hint:[/yellow] {installed[0].name} is installed but not running. "
                f"Start it first (e.g. `ollama serve`)."
            )


@local_app.command("setup")
def local_setup(
    model: str = typer.Option("llama3.2", "--model", "-m", help="Model to pull."),
):
    """Quick Ollama setup wizard — install check, service check, model pull."""
    console.print(f"[bold]Ollama Setup Wizard[/bold] (model: {model})\n")

    result = setup_ollama(model=model)

    for i, step in enumerate(result["steps"], 1):
        icon = "[green]OK[/green]" if "installed" in step.lower() or "running" in step.lower() or "success" in step.lower() else "[yellow]!![/yellow]"
        console.print(f"  {icon} Step {i}: {step}")

    if result["success"]:
        console.print("\n[green]Setup complete![/green] Try: [bold]superagent local run 'Hello!'[/bold]")
    else:
        console.print("\n[yellow]Setup incomplete.[/yellow] Fix the issues above and re-run.")


@local_app.command("register")
def local_register():
    """Auto-register running local backends as LLM providers in the gateway."""
    console.print("Scanning for running local backends...")

    registered = register_local_in_gateway()

    if not registered:
        console.print("[yellow]No running backends found to register.[/yellow]")
        console.print("Start a local backend first (e.g. `ollama serve`), then retry.")
        raise typer.Exit(1)

    for name in registered:
        console.print(f"  [green]+[/green] Registered provider: [bold]{name}[/bold]")

    console.print(
        f"\n[green]Done![/green] {len(registered)} provider(s) added to LLM gateway."
    )
    console.print("View with: [bold]superagent llm list[/bold]")


@local_app.command("run")
def local_run(
    prompt: str = typer.Argument(..., help="Prompt to send to the local model."),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Override model name."),
    backend_name: Optional[str] = typer.Option(None, "--backend", "-b", help="Force backend (ollama, localai, llamacpp)."),
):
    """Send a prompt to a local model and display the response."""
    # Resolve backend if specified
    backend = None
    if backend_name:
        backends = detect_backends()
        matches = [b for b in backends if b.name == backend_name and b.status == "running"]
        if not matches:
            console.print(f"[red]Backend '{backend_name}' is not running.[/red]")
            raise typer.Exit(1)
        backend = matches[0]

    target = backend or get_best_local_backend()
    if target:
        resolved_model = model or (target.models[0] if target.models else "default")
        console.print(f"Calling [bold]{target.name}[/bold] (model: {resolved_model}) ...\n")
    else:
        console.print("[red]No local backend running.[/red]")
        console.print(Panel(_INSTALL_HELP, border_style="yellow"))
        raise typer.Exit(1)

    result = call_local(prompt, backend=backend, model=model)

    if result["success"]:
        console.print(f"[green]Response[/green] (engine: {result['engine']}):\n")
        console.print(result["output"])
    else:
        console.print(f"[red]Error[/red] (engine: {result['engine']}): {result['error']}")
        raise typer.Exit(1)


@local_app.command("models")
def local_models(
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List available models across all running backends."""
    backends = detect_backends()
    running = [b for b in backends if b.status == "running"]

    if json_out:
        import json

        data = [
            {"backend": b.name, "model": m, "base_url": b.base_url}
            for b in running
            for m in b.models
        ]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not running:
        console.print("[yellow]No running backends found.[/yellow]")
        console.print("Start a local backend first (e.g. `ollama serve`).")
        return

    total = sum(len(b.models) for b in running)
    table = Table(title=f"Local Models ({total})")
    table.add_column("Backend", style="bold", width=12)
    table.add_column("Model", style="cyan", width=35)
    table.add_column("Base URL", style="dim", width=30)

    for b in running:
        if not b.models:
            table.add_row(b.name, "[dim]no models loaded[/dim]", b.base_url)
        else:
            for m in b.models:
                table.add_row(b.name, m, b.base_url)

    console.print(table)


@local_app.command("test")
def local_test():
    """Quick test — send 'Hello' to the best available local backend."""
    backend = get_best_local_backend()

    if not backend:
        console.print("[yellow]No running local backend found.[/yellow]")
        console.print(Panel(_INSTALL_HELP, border_style="yellow"))
        raise typer.Exit(1)

    model = backend.models[0] if backend.models else "default"
    console.print(
        f"Testing [bold]{backend.name}[/bold] (model: {model}) with prompt: \"Hello\"\n"
    )

    result = call_local("Hello", backend=backend)

    if result["success"]:
        console.print(f"[green]OK[/green] (engine: {result['engine']})\n")
        console.print(result["output"])
    else:
        console.print(f"[red]FAIL[/red] (engine: {result['engine']}): {result['error']}")
        raise typer.Exit(1)
