"""Role engine for SuperAgent — index, search, and match agent roles from 178+ templates.

Parses YAML frontmatter from agency-agents Markdown templates and provides:
- Role indexing by division/name/keywords
- Keyword-based matching for task → role recommendations
- Role loading for prompt injection
"""

from __future__ import annotations

import functools
import os
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional


@dataclass
class RoleTemplate:
    """A parsed agent role template."""

    name: str
    description: str
    division: str
    file_path: str
    color: str = ""
    emoji: str = ""
    vibe: str = ""
    keywords: list[str] = field(default_factory=list)

    @property
    def id(self) -> str:
        """Unique identifier: division/filename-stem."""
        stem = Path(self.file_path).stem
        return f"{self.division}/{stem}"

    def load_prompt(self) -> str:
        """Load the full Markdown prompt content (without frontmatter)."""
        with open(self.file_path, "r", encoding="utf-8") as f:
            content = f.read()
        # Strip YAML frontmatter
        match = re.match(r"^---\s*\n.*?\n---\s*\n", content, re.DOTALL)
        if match:
            return content[match.end():]
        return content


_FRONTMATTER_RE = re.compile(r"^---\s*\n(.*?)\n---", re.DOTALL)
_YAML_FIELD_RE = re.compile(r"^(\w+):\s*(.+)$", re.MULTILINE)


@functools.lru_cache(maxsize=1024)
def _parse_frontmatter(content: str) -> frozenset[tuple[str, str]]:
    """Parse simple YAML frontmatter (key: value pairs only)."""
    match = _FRONTMATTER_RE.match(content)
    if not match:
        return frozenset()
    block = match.group(1)
    return frozenset((m.group(1), m.group(2).strip()) for m in _YAML_FIELD_RE.finditer(block))


def _extract_keywords(name: str, description: str, division: str) -> list[str]:
    """Extract search keywords from role metadata."""
    text = f"{name} {description} {division}".lower()
    # Remove common stop words
    stops = {"a", "an", "the", "and", "or", "for", "in", "on", "to", "with", "of", "is", "who"}
    words = re.findall(r"[a-z]+", text)
    return list(dict.fromkeys(w for w in words if w not in stops and len(w) > 2))


class RoleIndex:
    """Index of all available role templates with search capabilities."""

    def __init__(self, roles_dir: Optional[str] = None):
        self._roles: list[RoleTemplate] = []
        self._by_division: dict[str, list[RoleTemplate]] = {}
        self._by_name: dict[str, RoleTemplate] = {}
        if roles_dir:
            self.load_directory(roles_dir)

    @property
    def roles(self) -> list[RoleTemplate]:
        return list(self._roles)

    @property
    def divisions(self) -> list[str]:
        return sorted(self._by_division.keys())

    def load_directory(self, roles_dir: str) -> int:
        """Load all .md role templates from a directory tree. Returns count loaded."""
        roles_path = Path(roles_dir)
        if not roles_path.is_dir():
            return 0
        count = 0
        for division_dir in sorted(roles_path.iterdir()):
            if not division_dir.is_dir():
                continue
            division = division_dir.name
            for md_file in sorted(division_dir.glob("*.md")):
                if md_file.name.lower().startswith("readme"):
                    continue
                role = self._parse_role(md_file, division)
                if role:
                    self._roles.append(role)
                    self._by_division.setdefault(division, []).append(role)
                    self._by_name[role.name.lower()] = role
                    count += 1
        return count

    def _parse_role(self, path: Path, division: str) -> Optional[RoleTemplate]:
        """Parse a single role template file."""
        try:
            content = path.read_text(encoding="utf-8")
        except OSError:
            return None
        fm = dict(_parse_frontmatter(content))
        name = fm.get("name", path.stem.replace("-", " ").title())
        description = fm.get("description", "")
        if not name:
            return None
        return RoleTemplate(
            name=name,
            description=description,
            division=division,
            file_path=str(path),
            color=fm.get("color", ""),
            emoji=fm.get("emoji", ""),
            vibe=fm.get("vibe", ""),
            keywords=_extract_keywords(name, description, division),
        )

    def list_roles(self, division: Optional[str] = None) -> list[RoleTemplate]:
        """List roles, optionally filtered by division."""
        if division:
            return self._by_division.get(division, [])
        return list(self._roles)

    def get_role(self, name: str) -> Optional[RoleTemplate]:
        """Get a role by exact name (case-insensitive)."""
        return self._by_name.get(name.lower())

    def search(self, query: str, limit: int = 10) -> list[tuple[RoleTemplate, float]]:
        """Search roles by keyword matching. Returns (role, score) pairs sorted by relevance."""
        query_words = set(re.findall(r"[a-z]+", query.lower()))
        if not query_words:
            return []
        results: list[tuple[RoleTemplate, float]] = []
        for role in self._roles:
            score = 0.0
            role_words = set(role.keywords)
            # Exact word matches in name (highest weight)
            name_words = set(re.findall(r"[a-z]+", role.name.lower()))
            name_matches = query_words & name_words
            score += len(name_matches) * 3.0
            # Keyword matches
            kw_matches = query_words & role_words
            score += len(kw_matches) * 1.0
            # Substring matches in description
            desc_lower = role.description.lower()
            for qw in query_words:
                if qw in desc_lower:
                    score += 0.5
            # Division match bonus
            if role.division.lower() in query_words:
                score += 2.0
            if score > 0:
                results.append((role, score))
        results.sort(key=lambda x: x[1], reverse=True)
        return results[:limit]

    def match_team(self, task_description: str, max_agents: int = 5) -> list[RoleTemplate]:
        """Recommend a team composition for a given task description.

        Uses keyword matching to find the most relevant diverse roles.
        Ensures diversity by picking at most 2 from the same division.
        """
        results = self.search(task_description, limit=max_agents * 3)
        team: list[RoleTemplate] = []
        division_count: dict[str, int] = {}
        for role, _score in results:
            div = role.division
            if division_count.get(div, 0) >= 2:
                continue
            team.append(role)
            division_count[div] = division_count.get(div, 0) + 1
            if len(team) >= max_agents:
                break
        return team


def get_default_roles_dir() -> str:
    """Get the default roles directory path."""
    # Check project-local roles/ first
    project_roles = os.path.join(os.getcwd(), "roles")
    if os.path.isdir(project_roles):
        return project_roles
    # Fall back to package-bundled roles
    pkg_roles = os.path.join(os.path.dirname(__file__), "..", "..", "roles")
    if os.path.isdir(pkg_roles):
        return os.path.abspath(pkg_roles)
    # Fall back to ~/.superagent/roles
    return os.path.join(os.path.expanduser("~"), ".superagent", "roles")


@functools.lru_cache(maxsize=None)
def get_role_index(roles_dir: Optional[str] = None) -> RoleIndex:
    """Get a RoleIndex loaded from the default or specified directory."""
    if roles_dir is None:
        roles_dir = get_default_roles_dir()
    index = RoleIndex()
    index.load_directory(roles_dir)
    return index
