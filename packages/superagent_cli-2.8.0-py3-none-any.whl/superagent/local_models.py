"""Local model management for SuperAgent — zero-cost offline AI execution.

Supports three local inference backends:
1. LocalAI (45k stars) — OpenAI-compatible API, any model, CPU/GPU
2. Ollama — easiest setup, popular models pre-packaged
3. llama.cpp server — lowest level, maximum control

All backends expose OpenAI-compatible /v1/chat/completions endpoints,
so they work seamlessly with SuperAgent's existing llm_gateway.
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass, field
from typing import Any, Optional

logger = logging.getLogger(__name__)


@dataclass
class LocalBackend:
    """Represents a local LLM inference backend."""

    name: str  # "localai", "ollama", "llamacpp"
    base_url: str
    status: str  # "running", "installed", "not-installed"
    models: list[str] = field(default_factory=list)
    version: str = ""

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "base_url": self.base_url,
            "status": self.status,
            "models": self.models,
            "version": self.version,
        }


def detect_backends() -> list[LocalBackend]:
    """Auto-detect all available local inference backends."""
    backends = []

    # 1. Check Ollama
    ollama_path = shutil.which("ollama")
    if ollama_path:
        status = "installed"
        models: list[str] = []
        version = ""
        try:
            proc = subprocess.run(
                ["ollama", "--version"], capture_output=True, text=True, timeout=5
            )
            if proc.returncode == 0:
                version = proc.stdout.strip()
        except Exception as e:
            logger.debug("Ollama version check failed: %s", e)
        try:
            import httpx

            resp = httpx.get("http://localhost:11434/api/tags", timeout=3)
            if resp.status_code == 200:
                status = "running"
                data = resp.json()
                models = [m["name"] for m in data.get("models", [])]
        except Exception as e:
            logger.debug("Ollama status check failed: %s", e)
        backends.append(
            LocalBackend(
                name="ollama",
                base_url="http://localhost:11434/v1",
                status=status,
                models=models,
                version=version,
            )
        )

    # 2. Check LocalAI
    try:
        import httpx

        resp = httpx.get("http://localhost:8080/v1/models", timeout=3)
        if resp.status_code == 200:
            data = resp.json()
            models = [m["id"] for m in data.get("data", [])]
            backends.append(
                LocalBackend(
                    name="localai",
                    base_url="http://localhost:8080/v1",
                    status="running",
                    models=models,
                )
            )
    except Exception as e:
        logger.debug("LocalAI probe failed, checking binary: %s", e)
        # Check if binary exists
        if shutil.which("local-ai"):
            backends.append(
                LocalBackend(
                    name="localai",
                    base_url="http://localhost:8080/v1",
                    status="installed",
                    models=[],
                )
            )

    # 3. Check llama.cpp server
    try:
        import httpx

        resp = httpx.get("http://localhost:8081/v1/models", timeout=3)
        if resp.status_code == 200:
            backends.append(
                LocalBackend(
                    name="llamacpp",
                    base_url="http://localhost:8081/v1",
                    status="running",
                    models=["default"],
                )
            )
    except Exception as e:
        logger.debug("llama.cpp probe failed, checking binary: %s", e)
        if shutil.which("llama-server") or shutil.which("llama-cli"):
            backends.append(
                LocalBackend(
                    name="llamacpp",
                    base_url="http://localhost:8081/v1",
                    status="installed",
                    models=[],
                )
            )

    return backends


def get_best_local_backend() -> Optional[LocalBackend]:
    """Get the best available running local backend (prefer Ollama > LocalAI > llama.cpp)."""
    backends = detect_backends()
    for b in backends:
        if b.status == "running":
            return b
    return None


def register_local_in_gateway() -> list[str]:
    """Auto-register running local backends as LLM providers in the gateway."""
    from superagent.llm_gateway import ProviderConfig, get_llm_gateway

    gw = get_llm_gateway()

    backends = detect_backends()
    registered = []

    for b in backends:
        if b.status != "running":
            continue

        model = b.models[0] if b.models else "default"
        provider_name = f"local-{b.name}"

        config = ProviderConfig(
            name=provider_name,
            api_key="",  # No key needed for local
            base_url=b.base_url,
            default_model=model,
            enabled=True,
        )
        gw.add_provider(config)
        registered.append(provider_name)
        logger.info(
            "Registered local provider: %s (%s, model=%s)",
            provider_name,
            b.base_url,
            model,
        )

    gw.save()
    return registered


def setup_ollama(model: str = "llama3.2") -> dict[str, Any]:
    """Quick setup: install Ollama and pull a model."""
    result: dict[str, Any] = {"success": False, "steps": []}

    # Check if ollama is installed
    if not shutil.which("ollama"):
        result["steps"].append(
            "Ollama not installed. Install: https://ollama.ai or `brew install ollama`"
        )
        return result

    result["steps"].append("Ollama is installed")

    # Check if service is running
    try:
        import httpx

        httpx.get("http://localhost:11434/api/tags", timeout=3)
        result["steps"].append("Ollama service is running")
    except Exception as e:
        logger.debug("Ollama service not running: %s", e)
        result["steps"].append(
            "Starting Ollama service... Run: `ollama serve` in another terminal"
        )
        return result

    # Pull model
    try:
        proc = subprocess.run(
            ["ollama", "pull", model], capture_output=True, text=True, timeout=300
        )
        if proc.returncode == 0:
            result["steps"].append(f"Model '{model}' pulled successfully")
            result["success"] = True
        else:
            result["steps"].append(f"Failed to pull model: {proc.stderr[:200]}")
    except subprocess.TimeoutExpired:
        result["steps"].append(
            "Model pull timed out (large models may take a while)"
        )
    except Exception as e:
        result["steps"].append(f"Error: {e}")

    return result


def call_local(
    prompt: str,
    backend: Optional[LocalBackend] = None,
    model: Optional[str] = None,
) -> dict[str, Any]:
    """Call a local model directly. Returns dict with success, output, engine."""
    if backend is None:
        backend = get_best_local_backend()

    if backend is None:
        return {
            "success": False,
            "output": "",
            "engine": "none",
            "error": "No local backend running. Start Ollama: `ollama serve`",
        }

    resolved_model = model or (backend.models[0] if backend.models else "default")

    try:
        import httpx

        resp = httpx.post(
            f"{backend.base_url}/chat/completions",
            json={
                "model": resolved_model,
                "messages": [{"role": "user", "content": prompt}],
            },
            timeout=120,
        )
        resp.raise_for_status()
        data = resp.json()
        content = data["choices"][0]["message"]["content"]
        return {
            "success": True,
            "output": content,
            "engine": f"local-{backend.name}",
            "error": None,
        }
    except Exception as e:
        return {
            "success": False,
            "output": "",
            "engine": f"local-{backend.name}",
            "error": str(e),
        }
