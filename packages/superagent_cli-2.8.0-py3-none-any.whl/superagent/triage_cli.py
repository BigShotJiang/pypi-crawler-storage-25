"""CLI commands for SuperAgent triage (intelligent routing).

Provides the ``superagent triage`` subcommand group with route, list, add,
remove, and test operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import os
import re

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.triage import TriageEngine, TriageRule

triage_app = typer.Typer(
    name="triage",
    help="Triage — intelligent task routing to specialist roles.",
    no_args_is_help=True,
)
console = Console()


def _get_engine() -> TriageEngine:
    """Create a TriageEngine using the configured data directory."""
    data_dir = os.environ.get(
        "CLAWTEAM_DATA_DIR",
        os.path.join(os.path.expanduser("~"), ".superagent"),
    )
    rules_dir = os.path.join(data_dir, "triage")
    return TriageEngine(rules_dir)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@triage_app.command("route")
def triage_route(
    task: str = typer.Argument(..., help="Task description to route."),
):
    """Route a task to the best-matching specialist role (top 3)."""
    engine = _get_engine()
    decisions = engine.route(task)

    if not decisions:
        console.print("[yellow]No matching rules found for this task.[/yellow]")
        return

    top = decisions[:3]

    table = Table(title="Triage Routing Decisions")
    table.add_column("#", style="dim", width=3)
    table.add_column("Rule", style="cyan", min_width=16)
    table.add_column("Target Role", style="bold green", min_width=20)
    table.add_column("Confidence", style="magenta", min_width=10)
    table.add_column("Reasoning", max_width=50)

    for i, d in enumerate(top, 1):
        conf_color = "green" if d.confidence >= 0.5 else "yellow" if d.confidence >= 0.3 else "dim"
        table.add_row(
            str(i),
            d.rule_name,
            d.target_role,
            f"[{conf_color}]{d.confidence:.1%}[/{conf_color}]",
            d.reasoning,
        )

    console.print(table)

    best = top[0]
    console.print(
        f"\n[bold]Recommended:[/bold] Route to [bold green]{best.target_role}[/bold green] "
        f"(via rule [cyan]{best.rule_name}[/cyan], confidence {best.confidence:.1%})"
    )


@triage_app.command("list")
def triage_list():
    """List all triage rules."""
    engine = _get_engine()
    rules = engine.list_rules()

    if not rules:
        console.print("[yellow]No triage rules configured.[/yellow]")
        return

    table = Table(title=f"Triage Rules ({len(rules)})")
    table.add_column("Name", style="cyan", min_width=16)
    table.add_column("Target Role", style="bold green", min_width=20)
    table.add_column("Priority", style="magenta", min_width=8)
    table.add_column("Patterns", style="dim", max_width=40)
    table.add_column("Description", max_width=35)

    # Sort by priority descending for display
    for rule in sorted(rules, key=lambda r: r.priority, reverse=True):
        patterns_str = ", ".join(rule.patterns[:4])
        if len(rule.patterns) > 4:
            patterns_str += f" (+{len(rule.patterns) - 4})"
        table.add_row(
            rule.name,
            rule.target_role,
            str(rule.priority),
            patterns_str,
            rule.description or "-",
        )

    console.print(table)


@triage_app.command("add")
def triage_add(
    name: str = typer.Option(..., "--name", "-n", help="Unique rule name."),
    patterns: str = typer.Option(..., "--patterns", "-p", help="Comma-separated regex patterns."),
    target_role: str = typer.Option(..., "--target-role", "-t", help="Target specialist role."),
    priority: int = typer.Option(50, "--priority", help="Priority (higher = more specific)."),
    description: str = typer.Option("", "--description", "-d", help="Human-readable description."),
):
    """Add a custom triage rule."""
    pattern_list = [p.strip() for p in patterns.split(",") if p.strip()]

    if not pattern_list:
        console.print("[red]At least one pattern is required.[/red]")
        raise typer.Exit(1)

    # Validate regex patterns
    for p in pattern_list:
        try:
            re.compile(p)
        except re.error as e:
            console.print(f"[red]Invalid regex pattern '{p}': {e}[/red]")
            raise typer.Exit(1)

    engine = _get_engine()
    rule = TriageRule(
        name=name,
        patterns=pattern_list,
        target_role=target_role,
        priority=priority,
        description=description,
    )
    engine.add_rule(rule)

    console.print(Panel(
        f"[bold green]Rule added[/bold green]\n\n"
        f"  [bold]Name:[/bold]        {rule.name}\n"
        f"  [bold]Target:[/bold]      {rule.target_role}\n"
        f"  [bold]Priority:[/bold]    {rule.priority}\n"
        f"  [bold]Patterns:[/bold]    {', '.join(rule.patterns)}\n"
        f"  [bold]Description:[/bold] {rule.description or '(none)'}",
        title="triage add",
        border_style="green",
    ))


@triage_app.command("remove")
def triage_remove(
    name: str = typer.Argument(..., help="Name of the rule to remove."),
):
    """Remove a triage rule by name."""
    engine = _get_engine()
    removed = engine.remove_rule(name)

    if removed:
        console.print(f"[green]Removed triage rule '{name}'.[/green]")
    else:
        console.print(f"[red]Triage rule '{name}' not found.[/red]")
        raise typer.Exit(1)


@triage_app.command("test")
def triage_test(
    task: str = typer.Argument(..., help="Task description to test routing."),
):
    """Test routing with a detailed explanation of all matches."""
    engine = _get_engine()
    decisions = engine.route(task)

    if not decisions:
        console.print("[yellow]No rules matched this task description.[/yellow]")
        console.print(f"\n[dim]Input:[/dim] {task}")
        return

    console.print(Panel(
        f"[bold]Task:[/bold] {task}",
        title="Triage Test",
        border_style="blue",
    ))

    table = Table(title=f"All Matches ({len(decisions)})")
    table.add_column("#", style="dim", width=3)
    table.add_column("Rule", style="cyan", min_width=16)
    table.add_column("Target Role", style="bold green", min_width=20)
    table.add_column("Confidence", style="magenta", min_width=10)
    table.add_column("Reasoning", max_width=55)

    for i, d in enumerate(decisions, 1):
        conf_color = "green" if d.confidence >= 0.5 else "yellow" if d.confidence >= 0.3 else "dim"
        marker = " *" if i == 1 else ""
        table.add_row(
            str(i),
            d.rule_name + marker,
            d.target_role,
            f"[{conf_color}]{d.confidence:.1%}[/{conf_color}]",
            d.reasoning,
        )

    console.print(table)

    best = decisions[0]
    console.print(
        f"\n[bold green]Best match:[/bold green] [bold]{best.target_role}[/bold] "
        f"via [cyan]{best.rule_name}[/cyan] ({best.confidence:.1%} confidence)"
    )
    console.print(f"[dim]Reasoning: {best.reasoning}[/dim]")
