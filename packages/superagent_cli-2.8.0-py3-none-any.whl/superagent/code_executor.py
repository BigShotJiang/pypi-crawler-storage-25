"""Code Executor — safe local code execution for agent-generated scripts.

Inspired by OpenAgents' Data Agent kernel_publisher pattern.
Provides sandboxed execution of Python code with timeout, output capture,
and result extraction. Used to verify agent-produced code locally.

When ``sandbox=True`` (default), uses OS-level sandboxing (Seatbelt on macOS,
bubblewrap on Linux) for filesystem and network isolation. Falls back to
unsandboxed subprocess if the native sandbox is unavailable.
"""
from __future__ import annotations

import logging
import os
import subprocess
import sys
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class ExecutionResult:
    """Result of a code execution."""

    success: bool
    stdout: str = ""
    stderr: str = ""
    return_code: int = 0
    files_created: list[str] = field(default_factory=list)
    execution_time: float = 0.0
    error: str = ""

    def to_dict(self) -> dict:
        return {
            "success": self.success,
            "stdout": self.stdout,
            "stderr": self.stderr,
            "return_code": self.return_code,
            "files_created": self.files_created,
            "execution_time": self.execution_time,
            "error": self.error,
        }


def execute_python(
    code: str,
    *,
    working_dir: Optional[str] = None,
    timeout: int = 30,
    capture_files: bool = True,
    sandbox: bool = True,
) -> ExecutionResult:
    """Execute Python code in a subprocess with timeout and output capture.

    When ``sandbox=True`` (default), uses OS-level sandboxing (Seatbelt/bwrap)
    for filesystem and network isolation. Falls back to unsandboxed subprocess
    if the native sandbox is unavailable.

    Parameters
    ----------
    code:
        Python source code to execute.
    working_dir:
        Directory to execute in (default: temp directory).
    timeout:
        Maximum execution time in seconds.
    capture_files:
        If True, list files created during execution.
    sandbox:
        If True, use OS-level sandbox for isolation.
    """
    import time

    if working_dir is None:
        working_dir = tempfile.mkdtemp(prefix="superagent-exec-")
    else:
        os.makedirs(working_dir, exist_ok=True)

    # Try OS-level sandbox first
    if sandbox:
        try:
            from superagent.sandbox_native import NativeSandbox, SandboxProfile

            profile = SandboxProfile.default(working_dir)
            ns = NativeSandbox(profile)
            result = ns.execute_python(code, timeout=timeout, working_dir=working_dir)

            new_files: list[str] = []
            if capture_files:
                try:
                    new_files = sorted(
                        f for f in os.listdir(working_dir)
                        if f != "_exec_script.py" and f != "__pycache__"
                    )
                except OSError:
                    pass

            return ExecutionResult(
                success=result["success"],
                stdout=result.get("stdout", "")[:10000],
                stderr=result.get("stderr", "")[:5000],
                return_code=result.get("return_code", 1),
                files_created=new_files,
                execution_time=result.get("execution_time", 0),
            )
        except Exception as exc:
            logger.debug("Native sandbox unavailable, falling back: %s", exc)

    # Unsandboxed fallback
    # Record existing files for diff
    files_before: set[str] = set()
    if capture_files:
        try:
            files_before = set(os.listdir(working_dir))
        except OSError:
            pass

    # Write code to temp file
    script_path = os.path.join(working_dir, "_exec_script.py")
    Path(script_path).write_text(code, encoding="utf-8")

    start = time.monotonic()
    try:
        result = subprocess.run(
            [sys.executable, script_path],
            capture_output=True,
            text=True,
            cwd=working_dir,
            timeout=timeout,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        elapsed = time.monotonic() - start

        # Detect new files
        new_files: list[str] = []
        if capture_files:
            try:
                files_after = set(os.listdir(working_dir))
                new_files = sorted(
                    files_after - files_before - {"_exec_script.py", "__pycache__"}
                )
            except OSError:
                pass

        return ExecutionResult(
            success=result.returncode == 0,
            stdout=result.stdout[:10000],
            stderr=result.stderr[:5000],
            return_code=result.returncode,
            files_created=new_files,
            execution_time=round(elapsed, 2),
        )
    except subprocess.TimeoutExpired:
        elapsed = time.monotonic() - start
        return ExecutionResult(
            success=False,
            stderr=f"Execution timed out after {timeout}s",
            execution_time=round(elapsed, 2),
            error=f"timeout ({timeout}s)",
        )
    except Exception as e:
        elapsed = time.monotonic() - start
        return ExecutionResult(
            success=False,
            stderr=str(e),
            execution_time=round(elapsed, 2),
            error=str(e),
        )
    finally:
        # Clean up script file
        try:
            os.unlink(script_path)
        except OSError:
            pass


def execute_shell(
    command: str,
    *,
    working_dir: Optional[str] = None,
    timeout: int = 30,
    sandbox: bool = True,
) -> ExecutionResult:
    """Execute a shell command with timeout and output capture.

    When ``sandbox=True`` (default), uses OS-level sandboxing for isolation.
    """
    import time

    if working_dir is None:
        working_dir = os.getcwd()

    # Try OS-level sandbox first
    if sandbox:
        try:
            from superagent.sandbox_native import NativeSandbox, SandboxProfile

            profile = SandboxProfile.default(working_dir)
            ns = NativeSandbox(profile)
            result = ns.execute_shell(command, timeout=timeout, working_dir=working_dir)
            return ExecutionResult(
                success=result["success"],
                stdout=result.get("stdout", "")[:10000],
                stderr=result.get("stderr", "")[:5000],
                return_code=result.get("return_code", 1),
                execution_time=result.get("execution_time", 0),
            )
        except Exception as exc:
            logger.debug("Native sandbox unavailable, falling back: %s", exc)

    # Unsandboxed fallback
    start = time.monotonic()
    try:
        result = subprocess.run(
            command,
            shell=True,
            capture_output=True,
            text=True,
            cwd=working_dir,
            timeout=timeout,
        )
        elapsed = time.monotonic() - start
        return ExecutionResult(
            success=result.returncode == 0,
            stdout=result.stdout[:10000],
            stderr=result.stderr[:5000],
            return_code=result.returncode,
            execution_time=round(elapsed, 2),
        )
    except subprocess.TimeoutExpired:
        elapsed = time.monotonic() - start
        return ExecutionResult(
            success=False,
            error=f"timeout ({timeout}s)",
            execution_time=round(elapsed, 2),
        )
    except Exception as e:
        elapsed = time.monotonic() - start
        return ExecutionResult(
            success=False,
            error=str(e),
            execution_time=round(elapsed, 2),
        )


def verify_agent_code(
    code: str,
    language: str = "python",
    working_dir: Optional[str] = None,
    timeout: int = 30,
    sandbox: bool = True,
) -> ExecutionResult:
    """Verify that agent-generated code actually runs successfully.

    Inspired by OpenAgents Data Agent pattern: agents generate code,
    the system verifies it executes correctly before presenting to user.

    Parameters
    ----------
    code: Source code to verify.
    language: "python" or "shell".
    working_dir: Execution directory.
    timeout: Max seconds.
    sandbox: If True, use OS-level sandbox for isolation.
    """
    # Safety: check guardrails before execution
    try:
        from superagent.guardrails import get_guardrail_engine

        guard = get_guardrail_engine().check_output(code)
        if not guard.passed:
            blocked = [v for v in guard.violations if v["action"] == "block"]
            if blocked:
                return ExecutionResult(
                    success=False,
                    error=f"Blocked by guardrail: {blocked[0]['rule_name']}",
                    stderr=f"Code blocked by safety rule: {blocked[0]['matched_text']}",
                )
    except ImportError:
        pass

    if language == "python":
        return execute_python(code, working_dir=working_dir, timeout=timeout, sandbox=sandbox)
    elif language == "shell":
        return execute_shell(code, working_dir=working_dir, timeout=timeout, sandbox=sandbox)
    else:
        return ExecutionResult(
            success=False, error=f"Unsupported language: {language}"
        )
