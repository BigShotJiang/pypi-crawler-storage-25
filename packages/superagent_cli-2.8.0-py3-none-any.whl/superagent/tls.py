"""TLS/HTTPS support for SuperAgent Gateway.

Provides:
- Self-signed certificate generation (mkcert-style) for development
- TLS configuration for uvicorn (ssl_certfile/ssl_keyfile)
- Cloudflare Tunnel integration helpers

Production deployment should delegate TLS to infrastructure
(reverse proxy like nginx/Caddy, or Cloudflare Tunnel).
Self-signed certs are for local development only.

Aligned with CodeBuddy CLI's approach: "Delegate TLS to infrastructure."
"""
from __future__ import annotations

import logging
import os
import subprocess
import tempfile
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


@dataclass
class TLSConfig:
    """TLS configuration for the Gateway server."""

    cert_file: Optional[str] = None
    key_file: Optional[str] = None
    tunnel: bool = False

    @property
    def enabled(self) -> bool:
        """True when both cert and key files are set."""
        return bool(self.cert_file and self.key_file)

    def to_dict(self) -> dict:
        return {
            "cert_file": self.cert_file,
            "key_file": self.key_file,
            "tunnel": self.tunnel,
            "enabled": self.enabled,
        }


def generate_self_signed_cert(
    *,
    host: str = "127.0.0.1",
    out_dir: Optional[str] = None,
    days: int = 365,
) -> tuple[str, str]:
    """Generate a self-signed TLS certificate.

    Uses ``openssl`` subprocess (universally available on macOS/Linux).
    Falls back to the ``cryptography`` library if openssl is not found.

    Returns ``(cert_path, key_path)``.
    """
    if out_dir is None:
        from superagent.gateway import _data_dir
        out_dir = str(_data_dir() / "gateway" / "tls")

    os.makedirs(out_dir, exist_ok=True)
    cert_path = os.path.join(out_dir, "cert.pem")
    key_path = os.path.join(out_dir, "key.pem")

    # Try openssl first
    if _try_openssl_gen(cert_path, key_path, host, days):
        logger.info("Generated self-signed cert via openssl: %s", cert_path)
        return cert_path, key_path

    # Fallback: cryptography library
    if _try_cryptography_gen(cert_path, key_path, host, days):
        logger.info("Generated self-signed cert via cryptography: %s", cert_path)
        return cert_path, key_path

    raise RuntimeError(
        "Cannot generate TLS certificate: neither openssl nor cryptography "
        "library is available. Install openssl or run: pip install cryptography"
    )


def _try_openssl_gen(
    cert_path: str, key_path: str, host: str, days: int
) -> bool:
    """Attempt to generate cert using openssl CLI."""
    try:
        # Generate private key
        subprocess.run(
            ["openssl", "genrsa", "-out", key_path, "2048"],
            capture_output=True, timeout=30, check=True,
        )
        # Generate self-signed cert
        san = f"DNS:localhost,IP:127.0.0.1,IP:::1"
        if host not in ("127.0.0.1", "0.0.0.0", "localhost", "::1"):
            san += f",DNS:{host}"

        subprocess.run(
            [
                "openssl", "req", "-new", "-x509",
                "-key", key_path,
                "-out", cert_path,
                "-days", str(days),
                "-subj", "/O=SuperAgent/CN=localhost",
                "-addext", f"subjectAltName={san}",
            ],
            capture_output=True, timeout=30, check=True,
        )
        # Restrict permissions
        os.chmod(key_path, 0o600)
        os.chmod(cert_path, 0o644)
        return True
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired) as exc:
        logger.debug("openssl cert generation failed: %s", exc)
        return False


def _try_cryptography_gen(
    cert_path: str, key_path: str, host: str, days: int
) -> bool:
    """Attempt to generate cert using the ``cryptography`` Python library."""
    try:
        from cryptography import x509
        from cryptography.hazmat.primitives import hashes, serialization
        from cryptography.hazmat.primitives.asymmetric import rsa
        from cryptography.x509.oid import NameOID
        import datetime

        key = rsa.generate_private_key(public_exponent=65537, key_size=2048)

        san_entries = [
            x509.DNSName("localhost"),
            x509.IPAddress(__import__("ipaddress").IPv4Address("127.0.0.1")),
            x509.IPAddress(__import__("ipaddress").IPv6Address("::1")),
        ]
        if host not in ("127.0.0.1", "0.0.0.0", "localhost", "::1"):
            san_entries.append(x509.DNSName(host))

        subject = issuer = x509.Name([
            x509.NameAttribute(NameOID.ORGANIZATION_NAME, "SuperAgent"),
            x509.NameAttribute(NameOID.COMMON_NAME, "localhost"),
        ])
        cert = (
            x509.CertificateBuilder()
            .subject_name(subject)
            .issuer_name(issuer)
            .public_key(key.public_key())
            .serial_number(x509.random_serial_number())
            .not_valid_before(datetime.datetime.utcnow())
            .not_valid_after(datetime.datetime.utcnow() + datetime.timedelta(days=days))
            .add_extension(x509.SubjectAlternativeName(san_entries), critical=False)
            .sign(key, hashes.SHA256())
        )

        # Write key
        key_pem = key.private_bytes(
            serialization.Encoding.PEM,
            serialization.PrivateFormat.TraditionalOpenSSL,
            serialization.NoEncryption(),
        )
        with open(key_path, "wb") as f:
            f.write(key_pem)
        os.chmod(key_path, 0o600)

        # Write cert
        cert_pem = cert.public_bytes(serialization.Encoding.PEM)
        with open(cert_path, "wb") as f:
            f.write(cert_pem)
        os.chmod(cert_path, 0o644)

        return True
    except ImportError:
        logger.debug("cryptography library not available")
        return False
    except Exception as exc:
        logger.debug("cryptography cert generation failed: %s", exc)
        return False


def get_or_generate_cert(data_dir: Path) -> tuple[str, str]:
    """Return existing cert or generate a new one.

    Checks ``<data_dir>/gateway/tls/`` for existing ``cert.pem`` / ``key.pem``.
    If not found, generates a self-signed certificate.
    """
    tls_dir = data_dir / "gateway" / "tls"
    cert_path = tls_dir / "cert.pem"
    key_path = tls_dir / "key.pem"

    if cert_path.is_file() and key_path.is_file():
        logger.info("Using existing TLS certificate: %s", cert_path)
        return str(cert_path), str(key_path)

    return generate_self_signed_cert(out_dir=str(tls_dir))


def start_cloudflare_tunnel(
    port: int,
    hostname: Optional[str] = None,
) -> Optional[subprocess.Popen]:
    """Start a Cloudflare Quick Tunnel pointing at ``localhost:port``.

    Returns the ``Popen`` process if ``cloudflared`` is available, else ``None``.

    Quick Tunnel provides a temporary ``*.trycloudflare.com`` URL with
    automatic TLS termination at the Cloudflare edge — the same approach
    used by CodeBuddy CLI for remote access.
    """
    import shutil

    if shutil.which("cloudflared") is None:
        logger.warning(
            "cloudflared not found. Install from: "
            "https://developers.cloudflare.com/cloudflare-one/connections/connect-networks/downloads/"
        )
        return None

    cmd = ["cloudflared", "tunnel", "--url", f"http://127.0.0.1:{port}"]
    if hostname:
        cmd.extend(["--hostname", hostname])

    try:
        proc = subprocess.Popen(
            cmd,
            stdout=subprocess.PIPE,
            stderr=subprocess.PIPE,
            text=True,
        )
        logger.info("Cloudflare Tunnel started (PID %d) -> localhost:%d", proc.pid, port)
        return proc
    except Exception as exc:
        logger.error("Failed to start Cloudflare Tunnel: %s", exc)
        return None


def is_tls_available() -> bool:
    """Check if TLS dependencies are available (openssl or cryptography)."""
    # Check openssl
    try:
        subprocess.run(
            ["openssl", "version"], capture_output=True, timeout=5, check=True,
        )
        return True
    except (FileNotFoundError, subprocess.CalledProcessError, subprocess.TimeoutExpired):
        pass

    # Check cryptography
    try:
        import cryptography  # noqa: F401
        return True
    except ImportError:
        pass

    return False
