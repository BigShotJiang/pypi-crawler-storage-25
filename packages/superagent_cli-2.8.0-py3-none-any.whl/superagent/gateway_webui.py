"""SuperAgent Gateway Web UI — mobile-first single-page application.

Self-contained HTML/CSS/JS served by the Gateway at the root path.
Inspired by CodeBuddy CLI Remote Control + OpenClaw Canvas patterns.

Features:
  - 6 tabs: Dashboard, Teams, Agents, Runs, Chat, Settings
  - Mobile-first responsive (bottom tab bar on mobile, sidebar on desktop)
  - Dark theme with SuperAgent branding (purple/cyan accents)
  - i18n: Chinese/English toggle
  - Real-time updates via WebSocket
  - SSE streaming for run output
  - No external dependencies
"""

HTML_CONTENT = r"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1.0,maximum-scale=1.0,user-scalable=no">
<title>SuperAgent Gateway</title>
<meta name="theme-color" content="#0d1117">
<style>
*,*::before,*::after{margin:0;padding:0;box-sizing:border-box}
:root{
  --bg:#0d1117;--surface:#161b22;--card:#1c2333;--card-hover:#222d3f;
  --border:#30363d;--border-light:#3d444d;
  --purple:#8b5cf6;--blue:#3b82f6;--cyan:#58a6ff;
  --green:#4ade80;--yellow:#d29922;--red:#f85149;
  --magenta:#bc8cff;--orange:#ff9800;
  --text:#e2e8f0;--muted:#8b949e;--dim:#484f58;
  --mono:'SF Mono','Fira Code','Cascadia Code',Consolas,monospace;
  --sans:-apple-system,BlinkMacSystemFont,'Segoe UI','Noto Sans SC',sans-serif;
  --radius:10px;--radius-sm:6px;
  --sidebar-w:220px;--tabbar-h:56px;
  --accent:var(--purple);--accent-glow:rgba(139,92,246,.2);
}
html,body{height:100%;overflow:hidden}
body{font-family:var(--sans);background:var(--bg);color:var(--text);line-height:1.5}
a{color:var(--purple);text-decoration:none}
a:hover{color:var(--cyan)}
button{font-family:var(--sans);cursor:pointer;border:none;border-radius:var(--radius-sm);padding:8px 16px;font-size:.85rem;transition:all .2s}
input,select,textarea{font-family:var(--sans);font-size:.85rem;border:1px solid var(--border);border-radius:var(--radius-sm);padding:8px 12px;background:var(--surface);color:var(--text);outline:none;transition:border-color .2s}
input:focus,select:focus,textarea:focus{border-color:var(--purple)}
textarea{resize:vertical}

/* Layout */
.app{display:flex;height:100%;overflow:hidden}
.sidebar{width:var(--sidebar-w);background:var(--surface);border-right:1px solid var(--border);display:flex;flex-direction:column;flex-shrink:0;overflow-y:auto}
.sidebar-logo{padding:20px 16px 16px;display:flex;align-items:center;gap:10px;border-bottom:1px solid var(--border)}
.sidebar-logo .icon{width:28px;height:28px;border-radius:6px;background:linear-gradient(135deg,var(--purple),var(--cyan));display:flex;align-items:center;justify-content:center;font-size:14px;font-weight:800;color:#fff}
.sidebar-logo span{font-weight:700;font-size:.95rem;background:linear-gradient(90deg,var(--purple),var(--cyan));-webkit-background-clip:text;-webkit-text-fill-color:transparent}
.sidebar-nav{flex:1;padding:8px}
.sidebar-nav button{display:flex;align-items:center;gap:10px;width:100%;padding:10px 14px;background:none;color:var(--muted);border-radius:var(--radius-sm);font-size:.85rem;text-align:left}
.sidebar-nav button:hover{background:var(--card);color:var(--text)}
.sidebar-nav button.active{background:var(--card);color:var(--purple);font-weight:600}
.sidebar-nav button .nav-icon{font-size:1.1rem;width:22px;text-align:center}
.sidebar-footer{padding:12px 16px;border-top:1px solid var(--border);font-size:.72rem;color:var(--dim)}

.main{flex:1;display:flex;flex-direction:column;overflow:hidden;min-width:0}
.topbar{display:flex;align-items:center;justify-content:space-between;padding:10px 20px;border-bottom:1px solid var(--border);background:var(--surface);flex-shrink:0;min-height:48px}
.topbar-left{display:flex;align-items:center;gap:12px}
.topbar h1{font-size:1rem;font-weight:700}
.topbar-right{display:flex;align-items:center;gap:8px}
.lang-toggle{background:var(--card);color:var(--muted);padding:4px 10px;font-size:.75rem;border-radius:999px;border:1px solid var(--border)}
.lang-toggle:hover{color:var(--text);border-color:var(--purple)}
.conn-dot{width:8px;height:8px;border-radius:50%;background:var(--green);animation:pulse 2s ease-in-out infinite}
.conn-dot.off{background:var(--red);animation:none}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.4}

.content{flex:1;overflow-y:auto;padding:20px}

/* Mobile tab bar */
.tabbar{display:none;position:fixed;bottom:0;left:0;right:0;height:var(--tabbar-h);background:var(--surface);border-top:1px solid var(--border);z-index:100}
.tabbar-inner{display:flex;height:100%}
.tabbar button{flex:1;display:flex;flex-direction:column;align-items:center;justify-content:center;background:none;color:var(--muted);font-size:.65rem;gap:2px;border-radius:0}
.tabbar button .tab-icon{font-size:1.15rem}
.tabbar button.active{color:var(--purple)}

/* Cards & Components */
.card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:16px;transition:border-color .2s}
.card:hover{border-color:var(--border-light)}
.card-header{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
.card-title{font-weight:700;font-size:.9rem}
.stat-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(140px,1fr));gap:12px}
.stat-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:14px;text-align:center}
.stat-value{font-size:1.6rem;font-weight:800;font-family:var(--mono)}
.stat-value.purple{color:var(--purple)}.stat-value.cyan{color:var(--cyan)}
.stat-value.green{color:var(--green)}.stat-value.yellow{color:var(--yellow)}
.stat-value.red{color:var(--red)}.stat-value.blue{color:var(--blue)}
.stat-label{font-size:.72rem;color:var(--muted);margin-top:4px}

.badge{display:inline-flex;align-items:center;gap:4px;padding:2px 8px;border-radius:999px;font-size:.7rem;font-weight:600}
.badge.green{background:rgba(74,222,128,.15);color:var(--green)}
.badge.yellow{background:rgba(210,153,34,.15);color:var(--yellow)}
.badge.red{background:rgba(248,81,73,.15);color:var(--red)}
.badge.blue{background:rgba(59,130,246,.15);color:var(--blue)}
.badge.purple{background:rgba(139,92,246,.15);color:var(--purple)}
.badge.dim{background:rgba(139,148,158,.1);color:var(--muted)}

.btn{background:var(--purple);color:#fff;font-weight:600}
.btn:hover{background:#7c3aed;box-shadow:0 0 16px var(--accent-glow)}
.btn-sm{padding:6px 12px;font-size:.78rem}
.btn-outline{background:none;border:1px solid var(--border);color:var(--muted)}
.btn-outline:hover{border-color:var(--purple);color:var(--text)}
.btn-danger{background:var(--red);color:#fff}
.btn-danger:hover{background:#e5443d}

.empty-state{text-align:center;padding:60px 20px;color:var(--muted)}
.empty-state .empty-icon{font-size:3rem;margin-bottom:12px;opacity:.4}
.empty-state p{font-size:.9rem}

.loading{display:flex;align-items:center;justify-content:center;padding:40px;color:var(--muted)}
.spinner{width:24px;height:24px;border:3px solid var(--border);border-top-color:var(--purple);border-radius:50%;animation:spin .8s linear infinite;margin-right:10px}
@keyframes spin{to{transform:rotate(360deg)}}

/* Table-like list */
.item-list{display:flex;flex-direction:column;gap:8px}
.item{display:flex;align-items:center;gap:12px;padding:12px 14px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);cursor:pointer;transition:all .2s}
.item:hover{border-color:var(--purple);background:var(--card-hover)}
.item-icon{width:36px;height:36px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:1.1rem;flex-shrink:0}
.item-body{flex:1;min-width:0}
.item-title{font-weight:600;font-size:.85rem;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item-sub{font-size:.72rem;color:var(--muted);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.item-actions{display:flex;gap:6px;flex-shrink:0}

/* Agent grid */
.agent-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(200px,1fr));gap:12px}
.agent-card{background:var(--card);border:1px solid var(--border);border-radius:var(--radius);padding:14px;cursor:pointer;transition:all .2s}
.agent-card:hover{border-color:var(--purple);transform:translateY(-1px)}
.agent-avatar{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:1.1rem;font-weight:700;margin-bottom:8px}
.agent-name{font-weight:700;font-size:.85rem;margin-bottom:2px}
.agent-role{font-size:.72rem;color:var(--muted);margin-bottom:6px}
.agent-status{display:flex;align-items:center;gap:4px;font-size:.72rem}
.status-dot{width:6px;height:6px;border-radius:50%;flex-shrink:0}
.status-dot.running{background:var(--green);box-shadow:0 0 6px rgba(74,222,128,.5)}
.status-dot.idle{background:var(--dim)}
.status-dot.error{background:var(--red);box-shadow:0 0 6px rgba(248,81,73,.5)}

/* Chat */
.chat-container{display:flex;flex-direction:column;height:calc(100vh - 180px);min-height:300px}
.chat-messages{flex:1;overflow-y:auto;padding:12px 0}
.chat-msg{margin-bottom:12px;max-width:85%}
.chat-msg.user{margin-left:auto}
.chat-msg-bubble{padding:10px 14px;border-radius:12px;font-size:.85rem;line-height:1.5;word-break:break-word}
.chat-msg.user .chat-msg-bubble{background:var(--purple);color:#fff;border-bottom-right-radius:4px}
.chat-msg.assistant .chat-msg-bubble{background:var(--card);border:1px solid var(--border);border-bottom-left-radius:4px}
.chat-msg .chat-meta{font-size:.68rem;color:var(--muted);margin-top:4px}
.chat-input-area{display:flex;gap:8px;padding-top:12px;border-top:1px solid var(--border)}
.chat-input-area input{flex:1}
.chat-input-area button{flex-shrink:0}

/* Run output */
.run-output{background:#0d1117;border:1px solid var(--border);border-radius:var(--radius-sm);padding:12px;font-family:var(--mono);font-size:.78rem;line-height:1.6;white-space:pre-wrap;word-break:break-word;max-height:400px;overflow-y:auto;color:var(--green)}
.run-output .err{color:var(--red)}
.run-output .info{color:var(--cyan)}
.run-output .warn{color:var(--yellow)}

/* Form */
.form-group{margin-bottom:14px}
.form-group label{display:block;font-size:.78rem;color:var(--muted);margin-bottom:4px;font-weight:600}
.form-group input,.form-group select,.form-group textarea{width:100%}

/* QR Code (simple CSS-only) */
.qr-placeholder{width:160px;height:160px;background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);display:flex;align-items:center;justify-content:center;margin:12px auto;font-size:.8rem;color:var(--muted);text-align:center;padding:12px}

/* Modal */
.modal-overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.6);z-index:200;align-items:center;justify-content:center}
.modal-overlay.open{display:flex}
.modal{background:var(--surface);border:1px solid var(--border);border-radius:var(--radius);padding:24px;width:90%;max-width:480px;max-height:90vh;overflow-y:auto}
.modal h2{font-size:1.1rem;margin-bottom:16px}
.modal .modal-actions{display:flex;gap:8px;justify-content:flex-end;margin-top:16px}

/* Responsive */
@media(max-width:768px){
  .sidebar{display:none}
  .tabbar{display:block}
  .content{padding:14px;padding-bottom:calc(var(--tabbar-h) + 14px)}
  .topbar{padding:8px 14px}
  .stat-grid{grid-template-columns:repeat(2,1fr)}
  .agent-grid{grid-template-columns:1fr}
  .chat-container{height:calc(100vh - 220px)}
  .item{padding:10px 12px}
  .modal{width:95%;padding:16px}
}
@media(max-width:400px){
  .stat-grid{grid-template-columns:1fr}
}

/* Scrollbar */
::-webkit-scrollbar{width:6px;height:6px}
::-webkit-scrollbar-track{background:transparent}
::-webkit-scrollbar-thumb{background:var(--border);border-radius:3px}
::-webkit-scrollbar-thumb:hover{background:var(--dim)}

/* View toggle */
.view{display:none}
.view.active{display:block}

/* Toast */
.toast{position:fixed;top:16px;right:16px;background:var(--card);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px 16px;font-size:.82rem;z-index:300;transform:translateX(120%);transition:transform .3s}
.toast.show{transform:translateX(0)}
.toast.success{border-color:var(--green);color:var(--green)}
.toast.error{border-color:var(--red);color:var(--red)}
</style>
</head>
<body>

<div class="app">
  <!-- Sidebar (desktop) -->
  <aside class="sidebar">
    <div class="sidebar-logo">
      <div class="icon">S</div>
      <span>SuperAgent</span>
    </div>
    <nav class="sidebar-nav" id="sidebarNav">
      <button class="active" data-tab="dashboard"><span class="nav-icon">&#9632;</span> <span data-en="Dashboard" data-zh="仪表盘">Dashboard</span></button>
      <button data-tab="teams"><span class="nav-icon">&#9881;</span> <span data-en="Teams" data-zh="团队">Teams</span></button>
      <button data-tab="agents"><span class="nav-icon">&#9673;</span> <span data-en="Agents" data-zh="智能体">Agents</span></button>
      <button data-tab="runs"><span class="nav-icon">&#9654;</span> <span data-en="Runs" data-zh="执行">Runs</span></button>
      <button data-tab="chat"><span class="nav-icon">&#9993;</span> <span data-en="Chat" data-zh="对话">Chat</span></button>
      <button data-tab="settings"><span class="nav-icon">&#9881;</span> <span data-en="Settings" data-zh="设置">Settings</span></button>
    </nav>
    <div class="sidebar-footer">SuperAgent Gateway v2.8</div>
  </aside>

  <!-- Main content -->
  <div class="main">
    <div class="topbar">
      <div class="topbar-left">
        <h1 id="viewTitle" data-en="Dashboard" data-zh="仪表盘">Dashboard</h1>
      </div>
      <div class="topbar-right">
        <div class="conn-dot" id="connDot" title="Connected"></div>
        <button class="lang-toggle" id="langToggle" title="Switch language">EN/中</button>
      </div>
    </div>

    <div class="content">
      <!-- Dashboard -->
      <div class="view active" id="view-dashboard">
        <div class="stat-grid" id="dashStats">
          <div class="stat-card"><div class="stat-value purple" id="statTeams">--</div><div class="stat-label" data-en="Active Teams" data-zh="活跃团队">Active Teams</div></div>
          <div class="stat-card"><div class="stat-value cyan" id="statAgents">--</div><div class="stat-label" data-en="Running Agents" data-zh="运行中智能体">Running Agents</div></div>
          <div class="stat-card"><div class="stat-value green" id="statRuns">--</div><div class="stat-label" data-en="Total Runs" data-zh="总执行数">Total Runs</div></div>
          <div class="stat-card"><div class="stat-value yellow" id="statUptime">--</div><div class="stat-label" data-en="Uptime" data-zh="运行时间">Uptime</div></div>
        </div>
        <div style="margin-top:20px;display:flex;gap:8px">
          <button class="btn" onclick="switchTab('runs');showNewRunModal()" data-en="+ New Run" data-zh="+ 新执行">+ New Run</button>
          <button class="btn-outline" onclick="switchTab('teams')" data-en="View Teams" data-zh="查看团队">View Teams</button>
        </div>
        <h3 style="margin-top:24px;margin-bottom:12px;font-size:.9rem" data-en="Recent Runs" data-zh="最近执行">Recent Runs</h3>
        <div class="item-list" id="recentRuns">
          <div class="empty-state"><div class="empty-icon">&#9654;</div><p data-en="No runs yet" data-zh="暂无执行记录">No runs yet</p></div>
        </div>
      </div>

      <!-- Teams -->
      <div class="view" id="view-teams">
        <div id="teamsList">
          <div class="loading"><div class="spinner"></div> <span data-en="Loading teams..." data-zh="加载团队中...">Loading teams...</span></div>
        </div>
        <div id="teamDetail" style="display:none"></div>
      </div>

      <!-- Agents -->
      <div class="view" id="view-agents">
        <div class="agent-grid" id="agentGrid">
          <div class="loading"><div class="spinner"></div> <span data-en="Loading agents..." data-zh="加载智能体中...">Loading agents...</span></div>
        </div>
      </div>

      <!-- Runs -->
      <div class="view" id="view-runs">
        <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:16px">
          <h3 data-en="Execution History" data-zh="执行历史">Execution History</h3>
          <button class="btn btn-sm" onclick="showNewRunModal()" data-en="+ New Run" data-zh="+ 新执行">+ New Run</button>
        </div>
        <div class="item-list" id="runsList">
          <div class="empty-state"><div class="empty-icon">&#9654;</div><p data-en="No runs yet. Start your first run!" data-zh="暂无执行记录，开始第一次执行！">No runs yet. Start your first run!</p></div>
        </div>
        <div id="runDetail" style="display:none;margin-top:16px"></div>
      </div>

      <!-- Chat -->
      <div class="view" id="view-chat">
        <div style="margin-bottom:12px;display:flex;gap:8px;align-items:center">
          <select id="chatTarget" style="max-width:200px">
            <option value="" data-en="Select target..." data-zh="选择目标...">Select target...</option>
          </select>
        </div>
        <div class="chat-container">
          <div class="chat-messages" id="chatMessages">
            <div class="empty-state"><div class="empty-icon">&#9993;</div><p data-en="Select a target and start chatting" data-zh="选择目标并开始对话">Select a target and start chatting</p></div>
          </div>
          <div class="chat-input-area">
            <input type="text" id="chatInput" placeholder="Type a message..." data-en-placeholder="Type a message..." data-zh-placeholder="输入消息...">
            <button class="btn btn-sm" onclick="sendChat()" data-en="Send" data-zh="发送">Send</button>
          </div>
        </div>
      </div>

      <!-- Settings -->
      <div class="view" id="view-settings">
        <div class="card" style="margin-bottom:16px">
          <div class="card-header"><span class="card-title" data-en="Gateway Status" data-zh="网关状态">Gateway Status</span></div>
          <div id="gatewayInfo" style="font-family:var(--mono);font-size:.8rem;line-height:1.8;color:var(--muted)"></div>
        </div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-header"><span class="card-title" data-en="Authentication" data-zh="认证">Authentication</span></div>
          <div id="authInfo" style="font-family:var(--mono);font-size:.8rem;line-height:1.8;color:var(--muted)"></div>
        </div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-header"><span class="card-title" data-en="Workers" data-zh="工作进程">Workers</span></div>
          <div id="workerList" style="font-family:var(--mono);font-size:.8rem"></div>
        </div>
        <div class="card" style="margin-bottom:16px">
          <div class="card-header"><span class="card-title" data-en="Mobile Access" data-zh="移动端访问">Mobile Access</span></div>
          <p style="font-size:.82rem;color:var(--muted);margin-bottom:8px" data-en="Scan or open this URL on your phone:" data-zh="在手机上扫描或打开此链接：">Scan or open this URL on your phone:</p>
          <div style="background:var(--bg);border:1px solid var(--border);border-radius:var(--radius-sm);padding:10px;font-family:var(--mono);font-size:.78rem;color:var(--cyan);word-break:break-all" id="mobileUrl"></div>
          <div class="qr-placeholder" id="qrArea">
            <span data-en="QR Code\n(for password)" data-zh="二维码\n(含密码)">QR Code<br>(for password)</span>
          </div>
        </div>
        <div class="card">
          <div class="card-header"><span class="card-title" data-en="Channels" data-zh="通道">Channels</span></div>
          <div id="channelList" style="font-family:var(--mono);font-size:.8rem;color:var(--muted)" data-en="No channels configured" data-zh="未配置通道">No channels configured</div>
        </div>
      </div>
    </div>
  </div>
</div>

<!-- Mobile tab bar -->
<div class="tabbar">
  <div class="tabbar-inner">
    <button class="active" data-tab="dashboard"><span class="tab-icon">&#9632;</span><span data-en="Dash" data-zh="仪表">Dash</span></button>
    <button data-tab="teams"><span class="tab-icon">&#9881;</span><span data-en="Teams" data-zh="团队">Teams</span></button>
    <button data-tab="agents"><span class="tab-icon">&#9673;</span><span data-en="Agents" data-zh="智能体">Agents</span></button>
    <button data-tab="runs"><span class="tab-icon">&#9654;</span><span data-en="Runs" data-zh="执行">Runs</span></button>
    <button data-tab="chat"><span class="tab-icon">&#9993;</span><span data-en="Chat" data-zh="对话">Chat</span></button>
    <button data-tab="settings"><span class="tab-icon">&#9881;</span><span data-en="More" data-zh="更多">More</span></button>
  </div>
</div>

<!-- New Run Modal -->
<div class="modal-overlay" id="newRunModal">
  <div class="modal">
    <h2 data-en="New Run" data-zh="新建执行">New Run</h2>
    <div class="form-group">
      <label data-en="Goal / Task" data-zh="目标 / 任务">Goal / Task</label>
      <textarea id="runGoal" rows="3" placeholder="e.g. Build a todo app with auth" data-en-placeholder="e.g. Build a todo app with auth" data-zh-placeholder="例如：构建一个带认证的待办应用"></textarea>
    </div>
    <div class="form-group">
      <label data-en="Engine" data-zh="引擎">Engine</label>
      <select id="runEngine">
        <option value="builtin">Builtin</option>
        <option value="hermes">Hermes</option>
        <option value="deerflow">DeerFlow</option>
        <option value="local">Local (Ollama)</option>
      </select>
    </div>
    <div class="form-group">
      <label data-en="Team (optional)" data-zh="团队（可选）">Team (optional)</label>
      <input type="text" id="runTeam" placeholder="Team name">
    </div>
    <div class="modal-actions">
      <button class="btn-outline" onclick="closeModal('newRunModal')" data-en="Cancel" data-zh="取消">Cancel</button>
      <button class="btn" onclick="submitNewRun()" data-en="Start Run" data-zh="开始执行">Start Run</button>
    </div>
  </div>
</div>

<!-- Toast -->
<div class="toast" id="toast"></div>

<script>
/* ===== State ===== */
const API = window.location.origin;
let authToken = localStorage.getItem('sa_token') || '';
let lang = localStorage.getItem('sa_lang') || 'en';
let currentTab = 'dashboard';
let ws = null;
let refreshTimer = null;
let activeSSE = null;

/* ===== i18n ===== */
function applyLang() {
  document.querySelectorAll('[data-' + lang + ']').forEach(el => {
    const txt = el.getAttribute('data-' + lang);
    if (txt) el.textContent = txt;
  });
  document.querySelectorAll('[data-' + lang + '-placeholder]').forEach(el => {
    const ph = el.getAttribute('data-' + lang + '-placeholder');
    if (ph) el.placeholder = ph;
  });
}
function toggleLang() {
  lang = lang === 'en' ? 'zh' : 'en';
  localStorage.setItem('sa_lang', lang);
  applyLang();
}
document.getElementById('langToggle').onclick = toggleLang;

/* ===== Navigation ===== */
function switchTab(tab) {
  currentTab = tab;
  document.querySelectorAll('.view').forEach(v => v.classList.remove('active'));
  const view = document.getElementById('view-' + tab);
  if (view) view.classList.add('active');

  document.querySelectorAll('.sidebar-nav button, .tabbar button').forEach(b => {
    b.classList.toggle('active', b.dataset.tab === tab);
  });

  const titles = {dashboard:'Dashboard',teams:'Teams',agents:'Agents',runs:'Runs',chat:'Chat',settings:'Settings'};
  const titlesZh = {dashboard:'仪表盘',teams:'团队',agents:'智能体',runs:'执行',chat:'对话',settings:'设置'};
  const h1 = document.getElementById('viewTitle');
  h1.textContent = lang === 'zh' ? titlesZh[tab] : titles[tab];
  h1.setAttribute('data-en', titles[tab]);
  h1.setAttribute('data-zh', titlesZh[tab]);

  loadTabData(tab);
}

document.querySelectorAll('.sidebar-nav button, .tabbar button').forEach(b => {
  b.addEventListener('click', () => switchTab(b.dataset.tab));
});

/* ===== API helpers ===== */
async function api(path, opts = {}) {
  const headers = { 'Content-Type': 'application/json', ...(opts.headers || {}) };
  if (authToken) headers['Authorization'] = 'Bearer ' + authToken;
  try {
    const res = await fetch(API + path, { ...opts, headers });
    if (res.status === 401) {
      showToast(lang === 'zh' ? '认证失败，请检查密码' : 'Auth failed, check password', 'error');
      return null;
    }
    const data = await res.json();
    if (data.error) { showToast(data.error.message || 'API error', 'error'); return null; }
    return data.data !== undefined ? data.data : data;
  } catch (e) {
    console.error('API error:', e);
    document.getElementById('connDot').classList.add('off');
    return null;
  }
}

/* ===== Toast ===== */
function showToast(msg, type = 'success') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast ' + type + ' show';
  setTimeout(() => t.classList.remove('show'), 3000);
}

/* ===== Modal ===== */
function showModal(id) { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }
function showNewRunModal() { showModal('newRunModal'); }

/* ===== WebSocket ===== */
function connectWS() {
  const proto = location.protocol === 'https:' ? 'wss' : 'ws';
  const url = proto + '://' + location.host + '/ws';
  ws = new WebSocket(url);
  ws.onopen = () => { document.getElementById('connDot').classList.remove('off'); };
  ws.onclose = () => {
    document.getElementById('connDot').classList.add('off');
    setTimeout(connectWS, 3000);
  };
  ws.onmessage = (e) => {
    try {
      const msg = JSON.parse(e.data);
      if (msg.type === 'data_changed' || msg.type === 'team_update' || msg.type === 'run_update') {
        if (currentTab === 'dashboard' || currentTab === 'teams' || currentTab === 'agents' || currentTab === 'runs') {
          loadTabData(currentTab);
        }
      }
    } catch {}
  };
}

/* ===== Data Loading ===== */
async function loadTabData(tab) {
  switch (tab) {
    case 'dashboard': await loadDashboard(); break;
    case 'teams': await loadTeams(); break;
    case 'agents': await loadAgents(); break;
    case 'runs': await loadRuns(); break;
    case 'chat': await loadChatTargets(); break;
    case 'settings': await loadSettings(); break;
  }
}

async function loadDashboard() {
  const [health, teams, runs] = await Promise.all([
    api('/api/v1/health'),
    api('/api/v1/teams'),
    api('/api/v1/runs?limit=5'),
  ]);
  document.getElementById('statTeams').textContent = teams?.length ?? '--';
  document.getElementById('statAgents').textContent = countRunningAgents(teams);
  document.getElementById('statRuns').textContent = runs?.length ?? '--';
  const uptime = health?.uptime;
  document.getElementById('statUptime').textContent = uptime ? formatUptime(uptime) : '--';
  document.getElementById('connDot').classList.toggle('off', !health);

  const recentEl = document.getElementById('recentRuns');
  if (runs && runs.length > 0) {
    recentEl.innerHTML = runs.map(r => runItem(r)).join('');
  } else {
    recentEl.innerHTML = '<div class="empty-state"><div class="empty-icon">&#9654;</div><p>' +
      (lang === 'zh' ? '暂无执行记录' : 'No runs yet') + '</p></div>';
  }
}

function countRunningAgents(teams) {
  if (!teams) return '--';
  let count = 0;
  teams.forEach(t => { if (t.agents) count += t.agents.filter(a => a.status === 'running').length; });
  return count;
}

function formatUptime(seconds) {
  if (seconds < 60) return Math.floor(seconds) + 's';
  if (seconds < 3600) return Math.floor(seconds / 60) + 'm';
  if (seconds < 86400) return Math.floor(seconds / 3600) + 'h';
  return Math.floor(seconds / 86400) + 'd';
}

function runItem(r) {
  const statusColors = {pending:'blue',running:'yellow',completed:'green',failed:'red'};
  const sc = statusColors[r.status] || 'dim';
  return '<div class="item" onclick="viewRun(\'' + r.run_id + '\')">' +
    '<div class="item-icon" style="background:var(--card)">&#9654;</div>' +
    '<div class="item-body"><div class="item-title">' + esc(r.goal || r.run_id) + '</div>' +
    '<div class="item-sub">' + (r.engine || '') + ' &middot; ' + (r.started_at ? new Date(r.started_at * 1000).toLocaleString() : '') + '</div></div>' +
    '<span class="badge ' + sc + '">' + r.status + '</span></div>';
}

async function loadTeams() {
  const teams = await api('/api/v1/teams');
  const el = document.getElementById('teamsList');
  const detail = document.getElementById('teamDetail');
  detail.style.display = 'none';
  el.style.display = '';

  if (!teams || teams.length === 0) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">&#9881;</div><p>' +
      (lang === 'zh' ? '暂无活跃团队' : 'No active teams') + '</p></div>';
    return;
  }
  el.innerHTML = '<div class="item-list">' + teams.map(t => {
    const agentCount = t.agents ? t.agents.length : 0;
    const sc = t.status === 'active' ? 'green' : t.status === 'idle' ? 'yellow' : 'dim';
    return '<div class="item" onclick="viewTeam(\'' + esc(t.name) + '\')">' +
      '<div class="item-icon" style="background:rgba(139,92,246,.15);color:var(--purple)">&#9881;</div>' +
      '<div class="item-body"><div class="item-title">' + esc(t.name) + '</div>' +
      '<div class="item-sub">' + agentCount + ' ' + (lang === 'zh' ? '智能体' : 'agents') + '</div></div>' +
      '<span class="badge ' + sc + '">' + t.status + '</span></div>';
  }).join('') + '</div>';
}

async function viewTeam(name) {
  const team = await api('/api/v1/teams/' + encodeURIComponent(name));
  if (!team) return;
  const el = document.getElementById('teamsList');
  const detail = document.getElementById('teamDetail');
  el.style.display = 'none';
  detail.style.display = '';

  let agentsHtml = '';
  if (team.agents && team.agents.length > 0) {
    agentsHtml = team.agents.map(a => {
      const sc = a.status === 'running' ? 'running' : a.status === 'error' ? 'error' : 'idle';
      const avatarColors = ['var(--purple)','var(--cyan)','var(--green)','var(--yellow)','var(--magenta)'];
      const ac = avatarColors[Math.abs(hashStr(a.name)) % avatarColors.length];
      return '<div class="agent-card" onclick="viewAgent(\'' + esc(a.name) + '\')">' +
        '<div class="agent-avatar" style="background:' + ac + '22;color:' + ac + '">' + esc(a.name.charAt(0).toUpperCase()) + '</div>' +
        '<div class="agent-name">' + esc(a.name) + '</div>' +
        '<div class="agent-role">' + esc(a.role || a.agent_type || 'general') + '</div>' +
        '<div class="agent-status"><span class="status-dot ' + sc + '"></span> ' + a.status +
        (a.task ? ' &middot; ' + esc(a.task.substring(0, 40)) : '') + '</div></div>';
    }).join('');
  }

  detail.innerHTML = '<div style="display:flex;align-items:center;gap:12px;margin-bottom:16px">' +
    '<button class="btn-outline btn-sm" onclick="loadTeams()">&larr; ' + (lang === 'zh' ? '返回' : 'Back') + '</button>' +
    '<h3 style="flex:1">' + esc(team.name) + '</h3>' +
    '<span class="badge ' + (team.status === 'active' ? 'green' : 'dim') + '">' + team.status + '</span></div>' +
    '<div class="agent-grid">' + agentsHtml + '</div>' +
    (team.agents && team.agents.length === 0 ? '<div class="empty-state" style="padding:30px"><p>' +
      (lang === 'zh' ? '该团队暂无智能体' : 'No agents in this team') + '</p></div>' : '');
}

async function loadAgents() {
  const teams = await api('/api/v1/teams');
  const grid = document.getElementById('agentGrid');
  if (!teams || teams.length === 0) {
    grid.innerHTML = '<div class="empty-state"><div class="empty-icon">&#9673;</div><p>' +
      (lang === 'zh' ? '暂无智能体' : 'No agents found') + '</p></div>';
    return;
  }
  let allAgents = [];
  teams.forEach(t => {
    if (t.agents) t.agents.forEach(a => { a.team = t.name; allAgents.push(a); });
  });
  if (allAgents.length === 0) {
    grid.innerHTML = '<div class="empty-state"><div class="empty-icon">&#9673;</div><p>' +
      (lang === 'zh' ? '暂无智能体' : 'No agents found') + '</p></div>';
    return;
  }
  const avatarColors = ['var(--purple)','var(--cyan)','var(--green)','var(--yellow)','var(--magenta)','var(--blue)','var(--orange)'];
  grid.innerHTML = allAgents.map(a => {
    const sc = a.status === 'running' ? 'running' : a.status === 'error' ? 'error' : 'idle';
    const ac = avatarColors[Math.abs(hashStr(a.name)) % avatarColors.length];
    return '<div class="agent-card">' +
      '<div class="agent-avatar" style="background:' + ac + '22;color:' + ac + '">' + esc(a.name.charAt(0).toUpperCase()) + '</div>' +
      '<div class="agent-name">' + esc(a.name) + '</div>' +
      '<div class="agent-role">' + esc(a.role || a.agent_type || 'general') + '</div>' +
      '<div class="agent-status"><span class="status-dot ' + sc + '"></span> ' + a.status + '</div>' +
      (a.team ? '<div style="font-size:.68rem;color:var(--dim);margin-top:4px">' + esc(a.team) + '</div>' : '') +
      (a.task ? '<div style="font-size:.72rem;color:var(--muted);margin-top:4px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap">' + esc(a.task.substring(0, 60)) + '</div>' : '') +
      '</div>';
  }).join('');
}

async function loadRuns() {
  const runs = await api('/api/v1/runs');
  const el = document.getElementById('runsList');
  if (!runs || runs.length === 0) {
    el.innerHTML = '<div class="empty-state"><div class="empty-icon">&#9654;</div><p>' +
      (lang === 'zh' ? '暂无执行记录' : 'No runs yet') + '</p></div>';
    return;
  }
  el.innerHTML = runs.map(r => runItem(r)).join('');
}

async function viewRun(runId) {
  const run = await api('/api/v1/runs/' + runId);
  if (!run) return;
  const detail = document.getElementById('runDetail');
  detail.style.display = '';

  detail.innerHTML = '<div style="display:flex;align-items:center;gap:12px;margin-bottom:12px">' +
    '<button class="btn-outline btn-sm" onclick="document.getElementById(\'runDetail\').style.display=\'none\'">&larr;</button>' +
    '<h3 style="flex:1">' + (run.goal || runId) + '</h3>' +
    '<span class="badge ' + ({pending:'blue',running:'yellow',completed:'green',failed:'red'}[run.status] || 'dim') + '">' + run.status + '</span></div>' +
    '<div class="run-output" id="runOutput">' + (lang === 'zh' ? '等待输出...' : 'Waiting for output...') + '</div>' +
    (run.status === 'running' ? '<button class="btn-outline btn-sm" style="margin-top:8px" onclick="cancelRun(\'' + runId + '\')">' +
      (lang === 'zh' ? '取消执行' : 'Cancel Run') + '</button>' : '');

  if (run.status === 'running') {
    streamRun(runId);
  } else if (run.output) {
    document.getElementById('runOutput').textContent = run.output;
  }

  switchTab('runs');
}

function streamRun(runId) {
  if (activeSSE) activeSSE.close();
  const output = document.getElementById('runOutput');
  if (!output) return;
  output.textContent = '';

  const url = API + '/api/v1/runs/' + runId + '/stream';
  const headers = {};
  if (authToken) headers['Authorization'] = 'Bearer ' + authToken;

  activeSSE = new EventSource(url);
  activeSSE.onmessage = (e) => {
    try {
      const data = JSON.parse(e.data);
      if (data.type === 'token' || data.type === 'text') {
        output.textContent += data.content || data.text || '';
      } else if (data.type === 'done') {
        activeSSE.close();
        activeSSE = null;
      } else if (data.type === 'error') {
        output.innerHTML += '<span class="err">' + esc(data.message || 'Error') + '</span>\n';
        activeSSE.close();
        activeSSE = null;
      }
    } catch {}
    output.scrollTop = output.scrollHeight;
  };
  activeSSE.onerror = () => {
    activeSSE.close();
    activeSSE = null;
  };
}

async function cancelRun(runId) {
  await api('/api/v1/runs/' + runId + '/cancel', { method: 'POST' });
  showToast(lang === 'zh' ? '执行已取消' : 'Run cancelled');
  loadRuns();
}

async function submitNewRun() {
  const goal = document.getElementById('runGoal').value.trim();
  if (!goal) { showToast(lang === 'zh' ? '请输入目标' : 'Enter a goal', 'error'); return; }
  const engine = document.getElementById('runEngine').value;
  const team = document.getElementById('runTeam').value.trim();

  const res = await api('/api/v1/runs', {
    method: 'POST',
    body: JSON.stringify({ goal, engine, team }),
  });

  closeModal('newRunModal');
  document.getElementById('runGoal').value = '';
  document.getElementById('runTeam').value = '';

  if (res && res.run_id) {
    showToast(lang === 'zh' ? '执行已启动' : 'Run started');
    switchTab('runs');
    viewRun(res.run_id);
  }
}

async function loadChatTargets() {
  const teams = await api('/api/v1/teams');
  const sel = document.getElementById('chatTarget');
  sel.innerHTML = '<option value="">' + (lang === 'zh' ? '选择目标...' : 'Select target...') + '</option>';
  if (teams) {
    teams.forEach(t => {
      sel.innerHTML += '<option value="team:' + esc(t.name) + '">' + (lang === 'zh' ? '团队: ' : 'Team: ') + esc(t.name) + '</option>';
      if (t.agents) {
        t.agents.forEach(a => {
          sel.innerHTML += '<option value="agent:' + esc(a.name) + '">' + (lang === 'zh' ? '智能体: ' : 'Agent: ') + esc(a.name) + '</option>';
        });
      }
    });
  }
}

async function sendChat() {
  const input = document.getElementById('chatInput');
  const msg = input.value.trim();
  if (!msg) return;
  const target = document.getElementById('chatTarget').value;
  if (!target) { showToast(lang === 'zh' ? '请选择目标' : 'Select a target', 'error'); return; }

  const messagesEl = document.getElementById('chatMessages');
  // Clear empty state
  if (messagesEl.querySelector('.empty-state')) messagesEl.innerHTML = '';

  // Add user message
  messagesEl.innerHTML += '<div class="chat-msg user"><div class="chat-msg-bubble">' + esc(msg) +
    '</div><div class="chat-meta">' + new Date().toLocaleTimeString() + '</div></div>';
  input.value = '';
  messagesEl.scrollTop = messagesEl.scrollHeight;

  // Send via API
  const [type, name] = target.split(':');
  const res = await api('/api/v1/runs', {
    method: 'POST',
    body: JSON.stringify({ goal: msg, engine: 'builtin', team: type === 'team' ? name : undefined, agent: type === 'agent' ? name : undefined }),
  });

  if (res && res.run_id) {
    // Stream response as "assistant" message
    const bubble = document.createElement('div');
    bubble.className = 'chat-msg assistant';
    bubble.innerHTML = '<div class="chat-msg-bubble" id="chat-resp-' + res.run_id + '">' +
      (lang === 'zh' ? '思考中...' : 'Thinking...') + '</div>' +
      '<div class="chat-meta">' + new Date().toLocaleTimeString() + '</div>';
    messagesEl.appendChild(bubble);
    messagesEl.scrollTop = messagesEl.scrollHeight;

    const respEl = document.getElementById('chat-resp-' + res.run_id);
    const sse = new EventSource(API + '/api/v1/runs/' + res.run_id + '/stream');
    let fullText = '';
    sse.onmessage = (e) => {
      try {
        const data = JSON.parse(e.data);
        if (data.type === 'token' || data.type === 'text') {
          fullText += data.content || data.text || '';
          respEl.textContent = fullText;
        } else if (data.type === 'done' || data.type === 'error') {
          sse.close();
          if (!fullText) respEl.textContent = data.message || (lang === 'zh' ? '完成' : 'Done');
        }
      } catch {}
      messagesEl.scrollTop = messagesEl.scrollHeight;
    };
    sse.onerror = () => { sse.close(); };
  }
}

async function loadSettings() {
  const [health, info, workers] = await Promise.all([
    api('/api/v1/health'),
    api('/api/v1/info'),
    api('/api/v1/workers'),
  ]);

  document.getElementById('gatewayInfo').innerHTML =
    '<div>Status: <span style="color:var(--green)">' + (health ? 'Online' : 'Offline') + '</span></div>' +
    (info ? '<div>Version: ' + (info.version || '--') + '</div>' +
    '<div>OS: ' + (info.platform || '--') + '</div>' +
    '<div>CWD: ' + (info.cwd || '--') + '</div>' +
    '<div>Uptime: ' + (info.uptime ? formatUptime(info.uptime) : '--') + '</div>' : '<div>No info available</div>');

  document.getElementById('authInfo').innerHTML =
    '<div>Auth: ' + (authToken ? '<span style="color:var(--green)">Authenticated</span>' : '<span style="color:var(--yellow)">No token</span>') + '</div>' +
    '<div style="margin-top:8px"><input type="password" id="authPassword" placeholder="' +
    (lang === 'zh' ? '输入密码' : 'Enter password') + '" style="max-width:200px;display:inline-block"> ' +
    '<button class="btn btn-sm" onclick="doLogin()">' + (lang === 'zh' ? '登录' : 'Login') + '</button></div>';

  const wEl = document.getElementById('workerList');
  if (workers && workers.length > 0) {
    wEl.innerHTML = '<div class="item-list">' + workers.map(w =>
      '<div class="item"><div class="item-body"><div class="item-title">' + esc(w.name || w.id) +
      '</div><div class="item-sub">PID ' + (w.pid || '?') + ' &middot; ' + (w.kind || '?') + ' &middot; ' +
      (w.status || '?') + '</div></div>' +
      (w.status === 'running' ? '<button class="btn-outline btn-sm" onclick="killWorker(\'' + w.id + '\')">' +
      (lang === 'zh' ? '停止' : 'Kill') + '</button>' : '') + '</div>'
    ).join('') + '</div>';
  } else {
    wEl.innerHTML = '<div style="color:var(--muted)">' + (lang === 'zh' ? '无活跃工作进程' : 'No active workers') + '</div>';
  }

  // Mobile URL
  const url = window.location.href;
  document.getElementById('mobileUrl').textContent = url;
}

async function doLogin() {
  const pw = document.getElementById('authPassword').value;
  if (!pw) return;
  const res = await api('/api/v1/auth/login', {
    method: 'POST',
    body: JSON.stringify({ password: pw }),
  });
  if (res && res.token) {
    authToken = res.token;
    localStorage.setItem('sa_token', authToken);
    showToast(lang === 'zh' ? '登录成功' : 'Logged in');
    loadSettings();
  }
}

async function killWorker(id) {
  await api('/api/v1/workers/' + id, { method: 'DELETE' });
  showToast(lang === 'zh' ? '工作进程已停止' : 'Worker killed');
  loadSettings();
}

/* ===== Utilities ===== */
function esc(s) { if (!s) return ''; const d = document.createElement('div'); d.textContent = s; return d.innerHTML; }
function hashStr(s) { let h = 0; for (let i = 0; i < s.length; i++) { h = ((h << 5) - h) + s.charCodeAt(i); h |= 0; } return h; }

/* ===== Auto-refresh ===== */
function startRefresh() {
  if (refreshTimer) clearInterval(refreshTimer);
  refreshTimer = setInterval(() => loadTabData(currentTab), 10000);
}

/* ===== Init ===== */
window.addEventListener('DOMContentLoaded', () => {
  applyLang();
  connectWS();
  loadDashboard();
  startRefresh();
});

// Cleanup SSE on tab switch
const origSwitchTab = switchTab;
// handled within switchTab already via loadTabData

window.addEventListener('beforeunload', () => {
  if (ws) ws.close();
  if (activeSSE) activeSSE.close();
  if (refreshTimer) clearInterval(refreshTimer);
});
</script>
</body>
</html>
"""


def get_html() -> str:
    """Return the Web UI HTML template."""
    return HTML_CONTENT
