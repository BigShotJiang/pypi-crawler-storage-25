"""CLI commands for multi-platform content publishing."""

from __future__ import annotations

import asyncio
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

publish_app = typer.Typer(
    name="publish",
    help="Publish — multi-platform content distribution for creators.",
    no_args_is_help=True,
)
console = Console()


def _run_async(coro):
    """Run an async coroutine from sync context."""
    try:
        loop = asyncio.get_running_loop()
    except RuntimeError:
        loop = None
    if loop and loop.is_running():
        import concurrent.futures
        with concurrent.futures.ThreadPoolExecutor() as pool:
            return pool.submit(asyncio.run, coro).result()
    return asyncio.run(coro)


@publish_app.command("status")
def publish_status():
    """Check publishing configuration and platform status."""
    from superagent.content_publish import (
        PLATFORM_INFO,
        get_publish_bridge,
        is_playwright_available,
    )

    bridge = get_publish_bridge()
    configured = bridge.config.list_platforms()
    configured_names = {p.name for p in configured}

    table = Table(title="Publishing Platforms")
    table.add_column("Platform", style="cyan")
    table.add_column("Type", style="dim")
    table.add_column("Status", style="bold")
    table.add_column("Description")

    for name, info in PLATFORM_INFO.items():
        if name in configured_names:
            cfg = bridge.config.get_platform(name)
            if cfg and cfg.enabled:
                status = "[green]Configured[/green]"
            else:
                status = "[yellow]Disabled[/yellow]"
        else:
            status = "[dim]Not configured[/dim]"

        ptype = info["type"].upper()
        if info["type"] == "browser" and not is_playwright_available():
            ptype += " [red](playwright missing)[/red]"

        table.add_row(name, ptype, status, info["description"])

    console.print(table)

    if not configured:
        console.print(
            "\n[yellow]No platforms configured yet.[/yellow]\n"
            "Run [cyan]superagent publish config add-platform[/cyan] to get started."
        )


@publish_app.command("platforms")
def publish_platforms():
    """List all supported publishing platforms."""
    from superagent.content_publish import PLATFORM_INFO

    table = Table(title="Supported Platforms")
    table.add_column("Name", style="cyan bold")
    table.add_column("Type")
    table.add_column("Auth Method")
    table.add_column("Description")

    for name, info in PLATFORM_INFO.items():
        table.add_row(name, info["type"], info.get("auth", ""), info["description"])

    console.print(table)
    console.print(
        "\n[dim]API platforms use tokens/keys. Browser platforms use exported cookies.[/dim]"
    )


config_app = typer.Typer(name="config", help="Manage platform configurations.", no_args_is_help=True)
publish_app.add_typer(config_app, name="config")


@config_app.command("add-platform")
def config_add_platform(
    name: str = typer.Argument(..., help="Platform name (e.g., medium, devto, zhihu)"),
    api_key: Optional[str] = typer.Option(None, "--api-key", "-k", help="API key or token"),
    api_url: Optional[str] = typer.Option(None, "--api-url", "-u", help="API base URL (for WordPress)"),
    cookies_file: Optional[str] = typer.Option(None, "--cookies", "-c", help="Path to cookies JSON file (for browser platforms)"),
):
    """Add or update a platform configuration."""
    from superagent.content_publish import PLATFORM_INFO, PlatformConfig, get_publish_bridge

    if name not in PLATFORM_INFO:
        console.print(f"[red]Unknown platform '{name}'.[/red] Supported: {', '.join(PLATFORM_INFO.keys())}")
        raise typer.Exit(1)

    info = PLATFORM_INFO[name]
    platform_type = info["type"]

    cookies = ""
    if cookies_file:
        from pathlib import Path
        cf = Path(cookies_file)
        if not cf.exists():
            console.print(f"[red]Cookies file not found: {cookies_file}[/red]")
            raise typer.Exit(1)
        cookies = cf.read_text(encoding="utf-8")

    bridge = get_publish_bridge()
    config = PlatformConfig(
        name=name,
        platform_type=platform_type,
        api_key=api_key or "",
        api_url=api_url or "",
        cookies=cookies,
    )
    bridge.config.add_platform(config)
    console.print(f"[green]Platform '{name}' configured successfully.[/green]")


@config_app.command("remove-platform")
def config_remove_platform(
    name: str = typer.Argument(..., help="Platform name to remove"),
):
    """Remove a platform configuration."""
    from superagent.content_publish import get_publish_bridge

    bridge = get_publish_bridge()
    if bridge.config.remove_platform(name):
        console.print(f"[green]Platform '{name}' removed.[/green]")
    else:
        console.print(f"[yellow]Platform '{name}' not found in configuration.[/yellow]")


@config_app.command("show")
def config_show():
    """Show current platform configurations."""
    from superagent.content_publish import get_publish_bridge

    bridge = get_publish_bridge()
    platforms = bridge.config.list_platforms()

    if not platforms:
        console.print("[yellow]No platforms configured.[/yellow]")
        return

    for p in platforms:
        key_display = ""
        if p.api_key:
            key_display = p.api_key[:4] + "..." + p.api_key[-4:] if len(p.api_key) > 8 else "****"

        panel_content = f"Type: {p.platform_type}\nEnabled: {p.enabled}"
        if key_display:
            panel_content += f"\nAPI Key: {key_display}"
        if p.api_url:
            panel_content += f"\nAPI URL: {p.api_url}"
        if p.cookies:
            panel_content += "\nCookies: [configured]"

        console.print(Panel(panel_content, title=f"[cyan]{p.name}[/cyan]", border_style="dim"))


@publish_app.command("article")
def publish_article(
    file_path: str = typer.Argument(..., help="Path to Markdown file"),
    platforms: Optional[str] = typer.Option(None, "--platforms", "-p", help="Comma-separated platform names"),
    all_platforms: bool = typer.Option(False, "--all", "-a", help="Publish to all configured platforms"),
):
    """Publish a Markdown article to one or more platforms."""
    from pathlib import Path

    from superagent.content_publish import get_publish_bridge

    if not Path(file_path).exists():
        console.print(f"[red]File not found: {file_path}[/red]")
        raise typer.Exit(1)

    if not platforms and not all_platforms:
        console.print("[red]Specify platforms with --platforms or use --all[/red]")
        raise typer.Exit(1)

    platform_list = [p.strip() for p in platforms.split(",")] if platforms else None

    bridge = get_publish_bridge()

    async def _do_publish():
        return await bridge.publish_article(
            file_path=file_path,
            platforms=platform_list,
            all_platforms=all_platforms,
        )

    console.print(f"[cyan]Publishing[/cyan] {file_path}...")
    results = _run_async(_do_publish())

    table = Table(title="Publish Results")
    table.add_column("Platform", style="cyan")
    table.add_column("Status", style="bold")
    table.add_column("URL / Error")

    for r in results:
        if r.success:
            status = "[green]OK[/green]" + (" [dim](draft)[/dim]" if r.draft else "")
            detail = r.url or "[dim]—[/dim]"
        else:
            status = "[red]FAIL[/red]"
            detail = f"[red]{r.error}[/red]"
        table.add_row(r.platform, status, detail)

    console.print(table)

    success_count = sum(1 for r in results if r.success)
    console.print(f"\n[bold]{success_count}/{len(results)}[/bold] platforms published successfully.")
