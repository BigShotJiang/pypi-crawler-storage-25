"""OS-level execution sandbox for SuperAgent.

Provides filesystem and network isolation for agent-generated code
using platform-native sandboxing:
- macOS: Seatbelt (``sandbox-exec``)
- Linux: bubblewrap (``bwrap``)
- Fallback: restricted subprocess with ``resource.setrlimit``

Inspired by CodeBuddy CLI's sandbox implementation which uses
bubblewrap on Linux and Apple Seatbelt on macOS for both
filesystem and network isolation.
"""
from __future__ import annotations

import logging
import os
import platform
import resource
import shutil
import subprocess
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)

_IS_MACOS = platform.system() == "Darwin"
_IS_LINUX = platform.system() == "Linux"


@dataclass
class SandboxProfile:
    """Configuration for a sandboxed execution.

    Controls filesystem access, network access, and resource limits.
    """

    # Filesystem
    read_only_paths: list[str] = field(default_factory=list)
    read_write_paths: list[str] = field(default_factory=list)
    denied_paths: list[str] = field(default_factory=list)

    # Network
    allow_network: bool = False
    allowed_domains: list[str] = field(default_factory=list)

    # Resources
    max_cpu_seconds: int = 60
    max_memory_mb: int = 512
    max_file_size_mb: int = 50
    timeout_seconds: int = 120

    @classmethod
    def default(cls, working_dir: str) -> SandboxProfile:
        """Create a default profile for local agent execution.

        - Working directory is read-write
        - System directories are read-only
        - Network is denied by default
        - Config directory is protected
        """
        home = os.path.expanduser("~")
        config_dir = os.path.join(home, ".superagent", "gateway")

        read_only = ["/usr", "/lib", "/lib64", "/opt", "/etc/alternatives"]
        if _IS_MACOS:
            read_only.extend(["/System", "/Library", "/Applications", "/usr/local"])
        elif _IS_LINUX:
            read_only.extend(["/bin", "/sbin", "/usr/local"])

        return cls(
            read_only_paths=[p for p in read_only if os.path.isdir(p)],
            read_write_paths=[working_dir],
            denied_paths=[config_dir],
            allow_network=False,
            allowed_domains=[],
            max_cpu_seconds=60,
            max_memory_mb=512,
            max_file_size_mb=50,
            timeout_seconds=120,
        )


def is_seatbelt_available() -> bool:
    """Check if macOS Seatbelt (``sandbox-exec``) is available."""
    if not _IS_MACOS:
        return False
    return shutil.which("sandbox-exec") is not None


def is_bubblewrap_available() -> bool:
    """Check if Linux bubblewrap (``bwrap``) is available."""
    if not _IS_LINUX:
        return False
    return shutil.which("bwrap") is not None


def get_sandbox_type() -> str:
    """Return the best available sandbox type: ``seatbelt``, ``bubblewrap``, or ``restricted``."""
    if is_seatbelt_available():
        return "seatbelt"
    if is_bubblewrap_available():
        return "bubblewrap"
    return "restricted"


class NativeSandbox:
    """Execute code in an OS-level sandbox.

    Automatically selects the best available sandbox backend:
    - macOS: ``sandbox-exec`` (Seatbelt)
    - Linux: ``bwrap`` (bubblewrap)
    - Fallback: restricted subprocess with resource limits
    """

    def __init__(self, profile: Optional[SandboxProfile] = None):
        self._profile = profile
        self._sandbox_type = get_sandbox_type()

    @property
    def sandbox_type(self) -> str:
        return self._sandbox_type

    def execute_python(
        self,
        code: str,
        *,
        timeout: int = 30,
        working_dir: Optional[str] = None,
    ) -> dict:
        """Execute Python code in sandbox.

        Returns dict with: success, stdout, stderr, engine, return_code, execution_time.
        """
        work_dir = working_dir or tempfile.mkdtemp(prefix="superagent-sandbox-")
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".py", delete=False, dir=work_dir
        ) as f:
            f.write(code)
            tmp_path = f.name

        try:
            cmd = [self._python(), tmp_path]
            return self._execute(cmd, work_dir, timeout)
        finally:
            try:
                os.unlink(tmp_path)
            except OSError:
                pass

    def execute_shell(
        self,
        command: str,
        *,
        timeout: int = 30,
        working_dir: Optional[str] = None,
    ) -> dict:
        """Execute a shell command in sandbox.

        Returns dict with: success, stdout, stderr, engine, return_code, execution_time.
        """
        work_dir = working_dir or tempfile.mkdtemp(prefix="superagent-sandbox-")
        cmd = ["/bin/sh", "-c", command]
        return self._execute(cmd, work_dir, timeout)

    # ── Private ──

    def _execute(self, cmd: list[str], working_dir: str, timeout: int) -> dict:
        """Dispatch to the appropriate sandbox backend."""
        import time

        effective_timeout = min(
            timeout,
            self._profile.timeout_seconds if self._profile else timeout,
        )
        start = time.monotonic()

        try:
            if self._sandbox_type == "seatbelt":
                result = self._execute_seatbelt(cmd, working_dir, effective_timeout)
            elif self._sandbox_type == "bubblewrap":
                result = self._execute_bubblewrap(cmd, working_dir, effective_timeout)
            else:
                result = self._execute_restricted(cmd, working_dir, effective_timeout)
        except Exception as exc:
            result = {
                "success": False,
                "stdout": "",
                "stderr": str(exc),
                "engine": self._sandbox_type,
                "return_code": 1,
            }

        result["execution_time"] = round(time.monotonic() - start, 3)
        return result

    def _execute_seatbelt(
        self, cmd: list[str], working_dir: str, timeout: int
    ) -> dict:
        """Execute using macOS Seatbelt (``sandbox-exec``).

        Generates a Seatbelt SBPL profile from SandboxProfile and wraps
        the command with ``sandbox-exec -p <profile> -- <cmd>``.
        """
        sbpl = self._generate_seatbelt_profile(working_dir)
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".sb", delete=False
        ) as f:
            f.write(sbpl)
            profile_path = f.name

        try:
            full_cmd = ["sandbox-exec", "-p", sbpl, "--"] + cmd
            proc = subprocess.run(
                full_cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir,
                env=self._safe_env(),
            )
            return {
                "success": proc.returncode == 0,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "engine": "seatbelt",
                "return_code": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "stdout": "",
                "stderr": f"Timeout after {timeout}s",
                "engine": "seatbelt",
                "return_code": -1,
            }
        finally:
            try:
                os.unlink(profile_path)
            except OSError:
                pass

    def _execute_bubblewrap(
        self, cmd: list[str], working_dir: str, timeout: int
    ) -> dict:
        """Execute using Linux bubblewrap (``bwrap``).

        Constructs a bwrap command with filesystem binds and
        ``--unshare-net`` for network isolation.
        """
        bwrap_cmd = self._build_bwrap_cmd(working_dir) + cmd

        proc = subprocess.run(
            bwrap_cmd,
            capture_output=True,
            text=True,
            timeout=timeout,
            cwd=working_dir,
            env=self._safe_env(),
        )
        return {
            "success": proc.returncode == 0,
            "stdout": proc.stdout,
            "stderr": proc.stderr,
            "engine": "bubblewrap",
            "return_code": proc.returncode,
        }

    def _execute_restricted(
        self, cmd: list[str], working_dir: str, timeout: int
    ) -> dict:
        """Fallback: restricted subprocess with ``resource.setrlimit``.

        Sets CPU time, memory, and file size limits. Drops dangerous
        environment variables. No filesystem or network isolation.
        """
        max_cpu = self._profile.max_cpu_seconds if self._profile else 60
        max_mem = self._profile.max_memory_mb if self._profile else 512
        max_file = self._profile.max_file_size_mb if self._profile else 50

        def preexec():
            resource.setrlimit(resource.RLIMIT_CPU, (max_cpu, max_cpu))
            resource.setrlimit(
                resource.RLIMIT_AS,
                (max_mem * 1024 * 1024, max_mem * 1024 * 1024),
            )
            resource.setrlimit(
                resource.RLIMIT_FSIZE,
                (max_file * 1024 * 1024, max_file * 1024 * 1024),
            )

        try:
            proc = subprocess.run(
                cmd,
                capture_output=True,
                text=True,
                timeout=timeout,
                cwd=working_dir,
                env=self._safe_env(),
                preexec_fn=preexec,
            )
            return {
                "success": proc.returncode == 0,
                "stdout": proc.stdout,
                "stderr": proc.stderr,
                "engine": "restricted",
                "return_code": proc.returncode,
            }
        except subprocess.TimeoutExpired:
            return {
                "success": False,
                "stdout": "",
                "stderr": f"Timeout after {timeout}s",
                "engine": "restricted",
                "return_code": -1,
            }

    @staticmethod
    def _real_path(p: str) -> str:
        """Resolve symlinks for Seatbelt subpath matching.

        macOS uses symlinks: /tmp -> /private/tmp, /var -> /private/var.
        Seatbelt resolves paths before matching, so we must use real paths.
        """
        try:
            return os.path.realpath(p) or p
        except OSError:
            return p

    def _generate_seatbelt_profile(self, working_dir: str) -> str:
        """Generate macOS Seatbelt SBPL from SandboxProfile."""
        lines = ["(version 1)", "(deny default)"]

        profile = self._profile or SandboxProfile.default(working_dir)
        rp = self._real_path

        # Allow broad file-read* — Python needs to read many system files.
        # Write access is restricted to whitelisted paths only.
        lines.append("(allow file-read*)")

        # Read-only paths (explicitly listed for documentation; already covered
        # by file-read* above, but kept for clarity if read is tightened later)
        for p in profile.read_only_paths:
            lines.append(f'(allow file-read* (subpath "{rp(p)}"))')

        # Read-write paths
        for p in profile.read_write_paths:
            real = rp(p)
            lines.append(f'(allow file-write* (subpath "{real}"))')

        # Denied paths — must use deny file-read* and deny file-write*
        # separately (deny file* is less specific than allow file-read*
        # and won't override it in Seatbelt's specificity rules).
        for p in profile.denied_paths:
            real = rp(p)
            lines.append(f'(deny file-read* (subpath "{real}"))')
            lines.append(f'(deny file-write* (subpath "{real}"))')

        # Temp directories — must use /private/tmp (real path on macOS)
        real_tmp = rp("/tmp")
        real_var_folders = rp("/var/folders")
        lines.append(f'(allow file-write* (subpath "{real_tmp}"))')
        lines.append(f'(allow file-write* (subpath "{real_var_folders}"))')

        # Network
        if profile.allow_network:
            lines.append("(allow network*)")
        else:
            lines.append("(deny network*)")
            # Allow DNS resolution even when network is denied
            lines.append('(allow network-outbound (regex #"^/var/run/mDNSResponder$"))')

        # Process management
        lines.append("(allow process-exec)")
        lines.append("(allow process-fork)")
        lines.append("(allow signal (target same-sandbox))")
        lines.append("(allow mach-lookup)")
        lines.append("(allow ipc-posix*)")
        lines.append("(allow sysctl-read)")

        return "\n".join(lines)

    def _build_bwrap_cmd(self, working_dir: str) -> list[str]:
        """Build the ``bwrap`` command arguments."""
        profile = self._profile or SandboxProfile.default(working_dir)
        args = ["bwrap"]

        # Read-only binds
        for p in profile.read_only_paths:
            if os.path.isdir(p):
                args.extend(["--ro-bind", p, p])

        # Read-write binds
        for p in profile.read_write_paths:
            if os.path.isdir(p) or os.path.isfile(p):
                args.extend(["--bind", p, p])

        # Essential filesystem
        args.extend(["--dev", "/dev"])
        args.extend(["--proc", "/proc"])
        if os.path.isdir("/tmp"):
            args.extend(["--bind", "/tmp", "/tmp"])

        # Try to bind /etc/resolv.conf for DNS
        resolv = "/etc/resolv.conf"
        if os.path.isfile(resolv):
            args.extend(["--ro-bind", resolv, resolv])

        # Network isolation
        if not profile.allow_network:
            args.append("--unshare-net")

        # Security flags
        args.extend(["--die-with-parent", "--new-session"])

        # Deny access to protected paths via --tmpfs overlay
        for p in profile.denied_paths:
            # Mount empty tmpfs over denied path to block access
            if os.path.isdir(p):
                args.extend(["--tmpfs", p])

        # Resource limits via bwrap (if supported)
        if profile.max_cpu_seconds > 0:
            args.extend(["--", "/bin/sh", "-c",
                         f"ulimit -t {profile.max_cpu_seconds}; exec"])

        args.append("--")
        return args

    def _safe_env(self) -> dict:
        """Return a sanitized environment dict.

        Removes dangerous variables and keeps essential ones.
        """
        keep_keys = {
            "PATH", "HOME", "USER", "LANG", "LC_ALL", "LC_CTYPE",
            "TERM", "TMPDIR", "TEMP", "TMP",
            "SSL_CERT_FILE", "REQUESTS_CA_BUNDLE",
            "PYTHONPATH", "PYTHONIOENCODING", "PYTHONDONTWRITEBYTECODE",
        }
        env = {}
        for k, v in os.environ.items():
            if k in keep_keys or k.startswith("SUPERAGENT_"):
                env[k] = v
        # Never pass secrets into sandbox
        for secret_key in (
            "OPENAI_API_KEY", "ANTHROPIC_API_KEY", "DEEPSEEK_API_KEY",
            "E2B_API_KEY", "SUPERAGENT_PASSWORD", "JWT_SECRET",
        ):
            env.pop(secret_key, None)
        return env

    @staticmethod
    def _python() -> str:
        """Return the Python interpreter path."""
        import sys
        return sys.executable
