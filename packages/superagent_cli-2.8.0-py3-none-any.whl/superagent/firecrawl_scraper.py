"""Web scraping and crawling for SuperAgent — powered by Firecrawl (91k stars).

Provides high-quality web scraping that converts pages to clean markdown,
with support for crawling entire sites, web search, and structured data extraction.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Optional

logger = logging.getLogger(__name__)

_FIRECRAWL_AVAILABLE = False
try:
    from firecrawl import FirecrawlApp  # type: ignore[import-untyped]
    _FIRECRAWL_AVAILABLE = True
except ImportError:
    logger.debug("firecrawl not installed: pip install firecrawl-py")


def is_firecrawl_available() -> bool:
    """Check whether the ``firecrawl-py`` package is importable."""
    return _FIRECRAWL_AVAILABLE


class FirecrawlBridge:
    """Bridge to Firecrawl's web scraping, crawling, search, and extraction APIs."""

    def __init__(self, api_key: Optional[str] = None):
        if not _FIRECRAWL_AVAILABLE:
            raise RuntimeError("firecrawl not installed. Run: pip install firecrawl-py")
        self._api_key = api_key or os.environ.get("FIRECRAWL_API_KEY", "")
        if not self._api_key:
            raise RuntimeError(
                "Firecrawl API key not found. "
                "Set the FIRECRAWL_API_KEY environment variable or pass api_key=."
            )
        self._app = FirecrawlApp(api_key=self._api_key)

    # -- Scrape --------------------------------------------------------------

    def scrape_url(self, url: str, **kwargs: Any) -> dict:
        """Scrape a single URL and return markdown content with metadata.

        Returns a dict with keys: ``markdown``, ``metadata``, ``url``, ``success``.
        """
        try:
            result = self._app.scrape_url(url, params=kwargs or None)
            # Firecrawl v1 returns dict with 'markdown', 'metadata', etc.
            return {
                "success": True,
                "url": url,
                "markdown": result.get("markdown", ""),
                "metadata": result.get("metadata", {}),
                "error": None,
            }
        except Exception as e:
            logger.error("Failed to scrape %s: %s", url, e)
            return {
                "success": False,
                "url": url,
                "markdown": "",
                "metadata": {},
                "error": str(e),
            }

    # -- Crawl ---------------------------------------------------------------

    def crawl_site(self, url: str, limit: int = 10, **kwargs: Any) -> list[dict]:
        """Crawl a website starting from *url*, returning up to *limit* pages as markdown.

        Each item in the returned list has: ``url``, ``markdown``, ``metadata``.
        """
        try:
            params = {"limit": limit, **kwargs}
            result = self._app.crawl_url(url, params=params, poll_interval=5)
            pages: list[dict] = []
            # crawl_url returns a dict with a 'data' key containing page results
            data = result.get("data", []) if isinstance(result, dict) else []
            for page in data:
                pages.append({
                    "url": page.get("metadata", {}).get("sourceURL", page.get("url", "")),
                    "markdown": page.get("markdown", ""),
                    "metadata": page.get("metadata", {}),
                })
            return pages
        except Exception as e:
            logger.error("Failed to crawl %s: %s", url, e)
            return []

    # -- Search --------------------------------------------------------------

    def search(self, query: str, limit: int = 5, **kwargs: Any) -> list[dict]:
        """Search the web via Firecrawl and return results as markdown.

        Each result has: ``url``, ``title``, ``markdown``, ``metadata``.
        """
        try:
            params = {"limit": limit, **kwargs}
            result = self._app.search(query, params=params)
            results: list[dict] = []
            data = result.get("data", []) if isinstance(result, dict) else []
            for item in data:
                results.append({
                    "url": item.get("url", ""),
                    "title": item.get("metadata", {}).get("title", item.get("title", "")),
                    "markdown": item.get("markdown", ""),
                    "metadata": item.get("metadata", {}),
                })
            return results
        except Exception as e:
            logger.error("Firecrawl search failed for '%s': %s", query, e)
            return []

    # -- Extract -------------------------------------------------------------

    def extract(self, url: str, schema: dict, **kwargs: Any) -> dict:
        """Extract structured data from a URL using a JSON schema.

        *schema* should be a JSON-schema-style dict describing the fields to extract.
        Returns ``{"success": True, "data": {...}, "error": None}`` on success.
        """
        try:
            params = {"extractorOptions": {"extractionSchema": schema}, **kwargs}
            result = self._app.scrape_url(url, params=params)
            extracted = result.get("extract", result.get("json", {}))
            return {
                "success": True,
                "data": extracted,
                "url": url,
                "error": None,
            }
        except Exception as e:
            logger.error("Extraction failed for %s: %s", url, e)
            return {
                "success": False,
                "data": {},
                "url": url,
                "error": str(e),
            }


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

def get_firecrawl(api_key: Optional[str] = None) -> Optional[FirecrawlBridge]:
    """Create a FirecrawlBridge instance, or ``None`` if unavailable.

    Returns *None* when ``firecrawl-py`` is not installed or the API key
    is missing, instead of raising.
    """
    if not _FIRECRAWL_AVAILABLE:
        return None
    try:
        return FirecrawlBridge(api_key)
    except Exception as e:
        logger.warning("Failed to initialize Firecrawl: %s", e)
        return None
