"""SuperAgent CLI - thin wrapper over ClawTeam with SuperAgent branding and defaults.

This module re-exports the ClawTeam Typer app with customized naming:
- CLI command: `superagent` (instead of `clawteam` / `oh`)
- Data directory: `~/.superagent/` (instead of `~/.clawteam/`)
- Branding: SuperAgent
"""

from __future__ import annotations

import os
import sys
from typing import Optional

# Ensure upstream clawteam package is importable
_upstream = os.path.join(os.path.dirname(__file__), "..", "..", "upstream", "clawteam")
if os.path.isdir(_upstream) and _upstream not in sys.path:
    sys.path.insert(0, _upstream)

# Override default data directory before any clawteam import
if "CLAWTEAM_DATA_DIR" not in os.environ:
    os.environ["CLAWTEAM_DATA_DIR"] = os.path.join(os.path.expanduser("~"), ".superagent")

import typer  # noqa: E402
from rich.console import Console  # noqa: E402
from rich.panel import Panel  # noqa: E402

# Patch the version in clawteam module so any internal references use ours
import clawteam  # noqa: E402
from superagent import __version__  # noqa: E402

clawteam.__version__ = __version__

# Import the clawteam app
from clawteam.cli.commands import app as _clawteam_app  # noqa: E402
from clawteam.cli.commands import spawn_agent as _upstream_spawn  # noqa: E402

console = Console()

# Create a fresh app that wraps clawteam's subcommands but with our own callback
app = typer.Typer(
    name="superagent",
    help="SuperAgent - AI Agent self-organizing teams, task allocation, and collaborative CLI tool",
    no_args_is_help=True,
)


def _version_callback(value: bool):
    if value:
        console.print(f"superagent v{__version__}")
        raise typer.Exit()


@app.callback()
def main_callback(
    version: bool = typer.Option(
        None, "--version", "-v", callback=_version_callback, is_eager=True,
        help="Show version and exit.",
    ),
    json_out: bool = typer.Option(
        False, "--json", help="Output JSON instead of human-readable text.",
    ),
    data_dir: Optional[str] = typer.Option(
        None, "--data-dir", help="Override data directory (default: ~/.superagent).",
    ),
    transport: Optional[str] = typer.Option(
        None, "--transport", help="Transport backend: file or p2p.",
    ),
):
    """SuperAgent - AI Agent self-organizing teams, task allocation, and collaborative CLI tool."""
    # Delegate to clawteam's main callback logic
    import clawteam.cli.commands as cmd
    cmd._json_output = json_out
    if data_dir:
        os.environ["CLAWTEAM_DATA_DIR"] = data_dir
        cmd._data_dir = data_dir
    if transport:
        os.environ["CLAWTEAM_TRANSPORT"] = transport


# Re-register all subcommands from clawteam app
for _registered in _clawteam_app.registered_groups:
    app.add_typer(_registered.typer_instance, name=_registered.name, help=_registered.help)

for _registered_cmd in _clawteam_app.registered_commands:
    if _registered_cmd.callback:
        # Skip upstream spawn — we wrap it below with --role support
        if _registered_cmd.name == "spawn":
            continue
        app.command(name=_registered_cmd.name)(_registered_cmd.callback)


# ---------------------------------------------------------------------------
# Wrapped spawn command with --role support
# ---------------------------------------------------------------------------

@app.command("spawn")
def spawn(
    backend: Optional[str] = typer.Argument(None, help="Backend: tmux (default) or subprocess"),
    command: list[str] = typer.Argument(None, help="Command and arguments to run (default: claude)"),
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Team name"),
    agent_name: Optional[str] = typer.Option(None, "--agent-name", "-n", help="Agent name"),
    profile: Optional[str] = typer.Option(None, "--profile", help="Apply a named runtime profile"),
    agent_type: str = typer.Option("general-purpose", "--agent-type", help="Agent type"),
    task: Optional[str] = typer.Option(None, "--task", help="Task to assign (becomes the agent's initial prompt)"),
    workspace: Optional[bool] = typer.Option(None, "--workspace/--no-workspace", "-w", help="Create isolated git worktree (default: auto)"),
    repo: Optional[str] = typer.Option(None, "--repo", help="Git repo path (default: cwd)"),
    skip_permissions: Optional[bool] = typer.Option(None, "--skip-permissions/--no-skip-permissions", help="Skip tool approval for claude (default: from config, true)"),
    resume: bool = typer.Option(False, "--resume", "-r", help="Resume previous session if available"),
    replace: bool = typer.Option(False, "--replace", help="Replace a running agent with the same name"),
    skill: Optional[list[str]] = typer.Option(None, "--skill", help="Skill name(s) to inject into the agent's system prompt (repeatable, claude only)"),
    role: Optional[str] = typer.Option(None, "--role", help="Role name — prepend the role template prompt to --task"),
):
    """Spawn a new agent process with identity + task as its initial prompt.

    Extends the upstream spawn with --role: when given, the role's prompt
    template is prepended to --task via build_role_task().
    """
    if role and task:
        from superagent.spawn_role import build_role_task
        task = build_role_task(role, task)
    elif role and not task:
        console.print("[yellow]Warning: --role ignored because --task was not provided.[/yellow]")

    _upstream_spawn(
        backend=backend,
        command=command,
        team=team,
        agent_name=agent_name,
        profile=profile,
        agent_type=agent_type,
        task=task,
        workspace=workspace,
        repo=repo,
        skip_permissions=skip_permissions,
        resume=resume,
        replace=replace,
        skill=skill,
    )


# Register SuperAgent-specific subcommands
from superagent.agentcard_cli import card_app  # noqa: E402
from superagent.aider_cli import aider_app  # noqa: E402
from superagent.browser_cli import browser_app  # noqa: E402
from superagent.checkpoint_cli import checkpoint_app  # noqa: E402
from superagent.composio_cli import services_app  # noqa: E402
from superagent.content_publish_cli import publish_app  # noqa: E402
from superagent.dashboard_cli import dashboard_app  # noqa: E402
from superagent.engine_cli import engine_app  # noqa: E402
from superagent.firecrawl_cli import firecrawl_app  # noqa: E402
from superagent.guardrail_cli import guardrail_app  # noqa: E402
from superagent.handoff_cli import handoff_app  # noqa: E402
from superagent.inject_cli import inject_app  # noqa: E402
from superagent.llm_cli import llm_app  # noqa: E402
from superagent.local_cli import local_app  # noqa: E402
from superagent.mcp_cli import mcp_app  # noqa: E402
from superagent.mem0_cli import mem0_app  # noqa: E402
from superagent.memory_cli import memory_app  # noqa: E402
from superagent.observability_cli import observability_app  # noqa: E402
from superagent.pipeline_cli import pipeline_app  # noqa: E402
from superagent.rag_cli import rag_app  # noqa: E402
from superagent.researcher_cli import researcher_app  # noqa: E402
from superagent.role_cli import role_app  # noqa: E402
from superagent.sandbox_cli import sandbox_app  # noqa: E402
from superagent.schedule_cli import schedule_app  # noqa: E402
from superagent.skill_cli import skill_app  # noqa: E402
from superagent.tool_cli import tool_app  # noqa: E402
from superagent.trend_cli import trend_app  # noqa: E402
from superagent.triage_cli import triage_app  # noqa: E402
from superagent.wiki_cli import wiki_app  # noqa: E402
from superagent.subagent_cli import agent_app  # noqa: E402
from superagent.hooks_cli import hook_app  # noqa: E402
from superagent.worker_cli import worker_app  # noqa: E402
from superagent.workflow_cli import workflow_app  # noqa: E402
from superagent.gateway_cli import gateway_app  # noqa: E402

app.add_typer(role_app, name="role", help="Agent role management — browse, search, and match 150+ role templates.")
app.add_typer(tool_app, name="tool", help="Tool ecosystem — discover, search, and install agent tools.")
app.add_typer(skill_app, name="skill", help="Skill evolution — track, evolve, and share agent skills.")
app.add_typer(memory_app, name="memory", help="Memory layer — write, search, and share cross-agent memories.")
app.add_typer(guardrail_app, name="guardrail", help="Safety guardrails — input/output security rules.")
app.add_typer(handoff_app, name="handoff", help="Agent handoff — transfer tasks between agents.")
app.add_typer(card_app, name="card", help="Agent cards — publish and discover agent capabilities.")
app.add_typer(pipeline_app, name="pipeline", help="SOP pipelines — staged workflow orchestration.")
app.add_typer(llm_app, name="llm", help="LLM gateway — manage providers, API keys, and connectivity.")
app.add_typer(mcp_app, name="mcp", help="MCP servers — Model Context Protocol tool server management.")
app.add_typer(triage_app, name="triage", help="Triage router — intelligent task routing to best agent role.")
app.add_typer(workflow_app, name="workflow", help="Workflows — Crew+Flow dual-mode workflow engine.")
app.add_typer(checkpoint_app, name="checkpoint", help="Checkpoints — persistent execution with pause/resume.")
app.add_typer(dashboard_app, name="dashboard", help="Dashboard — pixel-art real-time agent visualization.")
app.add_typer(engine_app, name="engine", help="Engine — manage DeerFlow and LLM execution backends.")
app.add_typer(browser_app, name="browser", help="Browser — web automation via browser-use.")
app.add_typer(mem0_app, name="mem0", help="Mem0 — semantic vector memory (AI-powered search).")
app.add_typer(services_app, name="services", help="Services — 200+ external integrations via Composio.")
app.add_typer(aider_app, name="aider", help="Aider — terminal-native coding agent (model-agnostic).")
app.add_typer(sandbox_app, name="sandbox", help="Sandbox — secure code execution via E2B microVMs.")
app.add_typer(researcher_app, name="research", help="Research — deep web research and analysis.")
app.add_typer(firecrawl_app, name="scrape", help="Scrape — web scraping and crawling via Firecrawl.")
app.add_typer(rag_app, name="rag", help="RAG — document retrieval via RAGFlow or local keyword search.")
app.add_typer(observability_app, name="trace", help="Trace — Langfuse-powered agent execution tracing.")
app.add_typer(local_app, name="local", help="Local — zero-cost offline AI via Ollama/LocalAI/llama.cpp.")
app.add_typer(trend_app, name="trends", help="Trends — multi-platform trend search across HN, Reddit, and web.")
app.add_typer(publish_app, name="publish", help="Publish — multi-platform content distribution for creators.")
app.add_typer(wiki_app, name="wiki", help="Wiki — LLM knowledge base with structured cross-referenced pages.")
app.add_typer(inject_app, name="inject", help="Inject — send async directives to running teams.")
app.add_typer(schedule_app, name="schedule", help="Schedule — cron-style recurring agent task automation (Moxt pattern).")
app.add_typer(agent_app, name="agent", help="Sub-Agents — delegate tasks to specialized AI agents.")
app.add_typer(hook_app, name="hook", help="Hooks — lifecycle event hooks for deterministic agent control.")
app.add_typer(worker_app, name="worker", help="Workers — manage background sessions, ps/logs/kill/daemon.")
app.add_typer(gateway_app, name="gateway", help="Gateway — serve Web UI, manage daemon and workers (CodeBuddy/OpenClaw pattern).")

# Headless / Pipe mode
from superagent.headless import pipe_app  # noqa: E402
app.add_typer(pipe_app, name="pipe", help="Pipe — non-interactive / headless execution with stdin support.")

# Cost tracking command
@app.command("costs")
def cost_show(
    days: int = typer.Option(30, "--days", "-d", help="Number of days to show."),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Show token usage and cost summary."""
    import json as _json

    from superagent.costs import get_cost_tracker
    tracker = get_cost_tracker()
    summary = tracker.summary(days=days)
    if json_out:
        console.print(_json.dumps(summary, indent=2))
        return
    console.print(f"\n[bold]Cost Summary (last {days} days)[/bold]")
    console.print(f"  Total calls: {summary['total_calls']}")
    console.print(f"  Input tokens: {summary['total_input_tokens']:,}")
    console.print(f"  Output tokens: {summary['total_output_tokens']:,}")
    console.print(f"  Total cost: [green]${summary['total_cost_usd']:.4f}[/green]")
    if summary["by_model"]:
        console.print("\n[bold]By Model:[/bold]")
        for m in summary["by_model"]:
            console.print(f"  {m['model']:30s} {m['calls']:4d} calls  ${m['cost_usd']:.4f}")

# Collector status command
@app.command("status")
def status_show(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Show full system status from all collectors."""
    import json as _json

    from superagent.collectors import collect_all
    data = collect_all()
    if json_out:
        console.print(_json.dumps(data, indent=2))
        return
    console.print(f"\n[bold]SuperAgent Status[/bold] ({data['timestamp'][:19]})\n")
    m = data["memory"]
    console.print(f"  Memory: {m['total']} entries ({m.get('by_layer', {})})")
    w = data["wiki"]
    console.print(f"  Wiki: {'initialized' if w.get('initialized') else 'not initialized'}"
                  + (f" ({w['total_pages']} pages, health {w['health_score']:.0f}/100)" if w.get("initialized") else ""))
    t = data["teams"]
    console.print(f"  Teams: {t.get('total', 0)} active")
    c = data["costs"]
    console.print(f"  Costs: {c.get('total_calls', 0)} calls, ${c.get('total_cost_usd', 0):.4f}")
    s = data["skills"]
    console.print(f"  Skills: {s.get('total', 0)} total ({s.get('active', 0)} active)")
    e = data["engines"]
    console.print(f"  Engines: {e.get('total', 0)} providers (default: {e.get('default', 'none')})")

# Code execution command (OpenAgents Data Agent pattern)
@app.command("exec")
def exec_code(
    code: str = typer.Argument(..., help="Python code to execute (or @filename to read from file)."),
    language: str = typer.Option("python", "--lang", "-l", help="Language: python or shell."),
    timeout: int = typer.Option(30, "--timeout", "-t", help="Timeout in seconds."),
    working_dir: Optional[str] = typer.Option(None, "--dir", "-d", help="Working directory."),
):
    """Execute code locally and show results (OpenAgents Data Agent pattern)."""
    import os as _os

    from superagent.code_executor import verify_agent_code

    # Support @filename syntax
    if code.startswith("@"):
        fpath = code[1:]
        if _os.path.isfile(fpath):
            code = open(fpath, encoding="utf-8").read()
        else:
            console.print(f"[red]File not found: {fpath}[/red]")
            raise typer.Exit(1)

    result = verify_agent_code(code, language=language, working_dir=working_dir, timeout=timeout)

    if result.stdout:
        console.print(Panel(result.stdout[:3000], title="stdout", border_style="green" if result.success else "red"))
    if result.stderr:
        console.print(Panel(result.stderr[:2000], title="stderr", border_style="yellow"))
    if result.files_created:
        console.print(f"[bold]Files created:[/bold] {', '.join(result.files_created)}")

    status = "[green]OK[/green]" if result.success else f"[red]FAILED (code {result.return_code})[/red]"
    console.print(f"\nStatus: {status} ({result.execution_time}s)")

# Web UI command (Hermes HUD)
@app.command("webui")
def webui_serve(
    port: int = typer.Option(3001, "--port", "-p", help="Port for Web UI."),
    host: str = typer.Option("127.0.0.1", "--host", help="Host for Web UI."),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't auto-open browser."),
):
    """Launch the Web UI consciousness monitor (Hermes HUD) in browser."""
    import subprocess
    import webbrowser

    webui_dir = os.path.join(os.path.dirname(__file__), "..", "..", "webui")
    backend_main = os.path.join(webui_dir, "backend", "main.py")

    if not os.path.isdir(os.path.join(webui_dir, "backend")):
        console.print("[red]Web UI not found.[/red]")
        console.print("Install: [cyan]cd superagent && git clone https://github.com/joeynyc/hermes-hudui.git webui[/cyan]")
        console.print("Then:    [cyan]pip install fastapi 'uvicorn[standard]' pyyaml watchfiles[/cyan]")
        raise typer.Exit(1)

    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    os.environ["HERMES_HOME"] = data_dir

    console.print(f"[bold green]Web UI starting at http://{host}:{port}[/bold green]")
    console.print(f"[dim]Data directory: {data_dir}[/dim]")

    if not no_browser:
        import threading
        threading.Timer(1.5, lambda: webbrowser.open(f"http://{host}:{port}")).start()

    try:
        subprocess.run(
            [sys.executable, "-m", "uvicorn", "backend.main:app",
             "--host", host, "--port", str(port)],
            cwd=webui_dir,
            env={**os.environ, "HERMES_HOME": data_dir},
        )
    except KeyboardInterrupt:
        console.print("\n[yellow]Web UI stopped.[/yellow]")

# Register the auto command (one sentence → full team)
from superagent.auto_cli import auto_command  # noqa: E402

app.command(name="auto", help="One sentence to full team automation.")(auto_command)

# Gateway / Serve command (CodeBuddy/OpenClaw-inspired persistent HTTP server)
@app.command("serve")
def serve_gateway(
    port: int = typer.Option(7890, "--port", "-p", help="Gateway port."),
    host: str = typer.Option("127.0.0.1", "--host", help="Gateway host."),
    auth: str = typer.Option("password", "--auth", help="Auth mode: password or none."),
    no_browser: bool = typer.Option(False, "--no-browser", help="Don't auto-open browser."),
):
    """Start the SuperAgent Gateway — persistent HTTP server with REST API and Web UI.

    Inspired by CodeBuddy CLI's ``--serve`` / ``daemon start`` and OpenClaw's
    local-first Gateway daemon.  Provides a FastAPI-based HTTP server that
    exposes all SuperAgent operations via REST API, SSE streaming, and WebSocket.

    Once running, access:
    - Web UI: http://host:port
    - API docs: http://host:port/api/docs
    - REST API: http://host:port/api/v1/*
    - WebSocket: ws://host:port/ws
    """
    from superagent.gateway import GatewayConfig, run_server

    config = GatewayConfig(host=host, port=port, auth=auth)
    config.save()

    if not no_browser:
        import threading
        import webbrowser
        threading.Timer(2.0, lambda: webbrowser.open(f"http://{host}:{port}")).start()

    run_server(config)


def main():
    """Entry point for superagent CLI."""
    app()


if __name__ == "__main__":
    main()
