"""SuperAgent role CLI commands — list, search, match, and show agent role templates."""

from __future__ import annotations

import shutil
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from superagent.roles import get_default_roles_dir, get_role_index

role_app = typer.Typer(
    name="role",
    help="Agent role management — browse, search, and match 150+ professional role templates.",
    no_args_is_help=True,
)
console = Console()


@role_app.command("list")
def role_list(
    division: Optional[str] = typer.Option(None, "--division", "-d", help="Filter by division."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List available agent role templates."""
    idx = get_role_index()
    roles = idx.list_roles(division=division)

    if json_out:
        import json
        data = [{"name": r.name, "division": r.division, "emoji": r.emoji, "description": r.description[:80]} for r in roles]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not roles:
        console.print(f"[yellow]No roles found{f' in division [{division}]' if division else ''}.[/yellow]")
        if division:
            console.print(f"Available divisions: {', '.join(idx.divisions)}")
        return

    table = Table(title=f"Agent Roles ({len(roles)} templates)")
    table.add_column("Division", style="cyan", width=18)
    table.add_column("", width=3)
    table.add_column("Name", style="bold")
    table.add_column("Description", style="dim", max_width=60)

    for r in roles:
        table.add_row(r.division, r.emoji, r.name, r.description[:60] + ("..." if len(r.description) > 60 else ""))

    console.print(table)


@role_app.command("search")
def role_search(
    query: str = typer.Argument(..., help="Search query (e.g. 'frontend react' or 'database backend')."),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Search roles by keywords."""
    idx = get_role_index()
    results = idx.search(query, limit=limit)

    if json_out:
        import json
        data = [{"name": r.name, "division": r.division, "score": round(s, 1)} for r, s in results]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not results:
        console.print(f"[yellow]No roles matching '{query}'.[/yellow]")
        return

    table = Table(title=f"Search: \"{query}\"")
    table.add_column("Score", style="green", width=6)
    table.add_column("", width=3)
    table.add_column("Name", style="bold")
    table.add_column("Division", style="cyan")
    table.add_column("Description", style="dim", max_width=50)

    for r, score in results:
        table.add_row(f"{score:.1f}", r.emoji, r.name, r.division, r.description[:50])

    console.print(table)


@role_app.command("match")
def role_match(
    task: str = typer.Argument(..., help="Task description to match roles for."),
    max_agents: int = typer.Option(5, "--max", "-m", help="Max team size."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Recommend a team composition for a task."""
    idx = get_role_index()
    team = idx.match_team(task, max_agents=max_agents)

    if json_out:
        import json
        data = [{"name": r.name, "division": r.division, "emoji": r.emoji, "id": r.id} for r in team]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not team:
        console.print("[yellow]No matching roles found for this task.[/yellow]")
        return

    console.print(f"\n[bold]Recommended team for:[/bold] {task}\n")
    for i, r in enumerate(team, 1):
        console.print(f"  {i}. {r.emoji} [bold]{r.name}[/bold] [dim]({r.division})[/dim]")
        if r.vibe:
            console.print(f"     [italic dim]{r.vibe}[/italic dim]")
    console.print()


@role_app.command("show")
def role_show(
    name: str = typer.Argument(..., help="Role name to show details for."),
):
    """Show full details of a specific role."""
    idx = get_role_index()
    role = idx.get_role(name)
    if not role:
        # Try fuzzy search
        results = idx.search(name, limit=1)
        if results:
            role = results[0][0]

    if not role:
        console.print(f"[red]Role '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(f"\n{role.emoji} [bold]{role.name}[/bold] [dim]({role.division})[/dim]")
    console.print(f"[italic]{role.description}[/italic]\n")
    if role.vibe:
        console.print(f"[dim]Vibe: {role.vibe}[/dim]\n")
    # Show first ~30 lines of the prompt
    prompt = role.load_prompt()
    lines = prompt.strip().split("\n")[:30]
    console.print("\n".join(lines))
    if len(prompt.strip().split("\n")) > 30:
        console.print(f"\n[dim]... ({len(prompt.strip().split(chr(10)))} lines total, use file: {role.file_path})[/dim]")


@role_app.command("divisions")
def role_divisions():
    """List all available divisions."""
    idx = get_role_index()
    for div in idx.divisions:
        count = len(idx.list_roles(division=div))
        console.print(f"  [cyan]{div}[/cyan] ({count} roles)")


@role_app.command(name="import")
def role_import(
    source: str = typer.Argument(..., help="Source directory to import role templates from."),
    division: str = typer.Option(None, "--division", "-d", help="Target division name (default: dirname)."),
):
    """Import custom role templates from an external directory."""
    source_path = Path(source)
    if not source_path.is_dir():
        console.print(f"[red]Source directory '{source}' does not exist.[/red]")
        raise typer.Exit(1)

    md_files = list(source_path.glob("*.md"))
    if not md_files:
        console.print(f"[yellow]No .md files found in '{source}'.[/yellow]")
        return

    division_name = division or source_path.name
    roles_dir = Path(get_default_roles_dir())
    target_dir = roles_dir / division_name
    target_dir.mkdir(parents=True, exist_ok=True)

    count = 0
    for f in md_files:
        shutil.copy2(f, target_dir / f.name)
        count += 1

    console.print(f"[green]Imported {count} role template(s) into '{division_name}'.[/green]")
