"""Sub-Agent Execution Engine — inspired by CodeBuddy Code's Sub-Agent system.

Each sub-agent is defined as a Markdown file with YAML frontmatter:
    ---
    name: code-reviewer
    description: 代码审查专家。在代码更改后主动使用。
    tools: Read, Grep, Glob, Bash
    model: inherit
    permission_mode: default
    skills: code-review
    ---

    System prompt content here...

Key features (borrowed from CodeBuddy):
- Independent context window per sub-agent
- Automatic delegation based on task description matching
- Explicit invocation by name
- Resumable agents (agentId-based)
- Background execution support
- Tool whitelist restrictions
"""

from __future__ import annotations

import json
import logging
import os
import re
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class SubAgentDefinition:
    """A sub-agent definition parsed from a Markdown file.

    Mirrors CodeBuddy's sub-agent frontmatter schema:
    - name: unique identifier
    - description: when to invoke this agent
    - tools: comma-separated tool whitelist (omit = inherit all)
    - model: model alias or 'inherit'
    - permission_mode: default | acceptEdits | bypassPermissions | plan
    - skills: comma-separated skill names auto-loaded on start
    - prompt: the system prompt (body of the Markdown file)
    """

    name: str
    description: str
    prompt: str
    tools: list[str] = field(default_factory=list)  # empty = inherit all
    model: str = "inherit"
    permission_mode: str = "default"
    skills: list[str] = field(default_factory=list)
    source_path: Optional[str] = None  # where this definition was loaded from

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "prompt": self.prompt,
            "tools": self.tools,
            "model": self.model,
            "permission_mode": self.permission_mode,
            "skills": self.skills,
            "source_path": self.source_path,
        }

    @classmethod
    def from_dict(cls, data: dict) -> SubAgentDefinition:
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            prompt=data.get("prompt", ""),
            tools=data.get("tools", []),
            model=data.get("model", "inherit"),
            permission_mode=data.get("permission_mode", "default"),
            skills=data.get("skills", []),
            source_path=data.get("source_path"),
        )


@dataclass
class SubAgentExecution:
    """Tracks a sub-agent execution instance."""

    agent_id: str
    agent_name: str
    task: str
    status: str = "pending"  # pending | running | completed | failed | cancelled
    result: str = ""
    started_at: str = ""
    completed_at: str = ""
    parent_session: Optional[str] = None
    is_background: bool = False

    def to_dict(self) -> dict:
        return {
            "agent_id": self.agent_id,
            "agent_name": self.agent_name,
            "task": self.task,
            "status": self.status,
            "result": self.result[:5000] if self.result else "",
            "started_at": self.started_at,
            "completed_at": self.completed_at,
            "parent_session": self.parent_session,
            "is_background": self.is_background,
        }


# ---------------------------------------------------------------------------
# Markdown + YAML frontmatter parser
# ---------------------------------------------------------------------------

def parse_agent_markdown(content: str, source_path: str = "") -> SubAgentDefinition:
    """Parse a sub-agent definition from Markdown with YAML frontmatter.

    Format:
        ---
        name: code-reviewer
        description: 代码审查专家
        tools: Read, Grep, Glob, Bash
        model: inherit
        permission_mode: default
        skills: code-review
        ---

        System prompt content here...
    """
    # Split frontmatter and body
    fm_match = re.match(r'^---\s*\n(.*?)\n---\s*\n(.*)', content, re.DOTALL)
    if not fm_match:
        # No frontmatter — treat entire content as prompt with filename as name
        name = Path(source_path).stem if source_path else "unnamed-agent"
        return SubAgentDefinition(
            name=name,
            description="",
            prompt=content.strip(),
            source_path=source_path,
        )

    frontmatter_text = fm_match.group(1)
    body = fm_match.group(2).strip()

    # Simple YAML parsing (avoid pyyaml dependency for core functionality)
    meta: dict = {}
    for line in frontmatter_text.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip().lower().replace("-", "_")
        value = value.strip()
        # Remove quotes if present
        if value.startswith('"') and value.endswith('"'):
            value = value[1:-1]
        elif value.startswith("'") and value.endswith("'"):
            value = value[1:-1]
        meta[key] = value

    # Parse comma-separated lists
    tools = [t.strip() for t in meta.get("tools", "").split(",") if t.strip()] if meta.get("tools") else []
    skills = [s.strip() for s in meta.get("skills", "").split(",") if s.strip()] if meta.get("skills") else []

    return SubAgentDefinition(
        name=meta.get("name", Path(source_path).stem if source_path else "unnamed-agent"),
        description=meta.get("description", ""),
        prompt=body,
        tools=tools,
        model=meta.get("model", "inherit"),
        permission_mode=meta.get("permission_mode", "default"),
        skills=skills,
        source_path=source_path,
    )


# ---------------------------------------------------------------------------
# Sub-Agent Registry
# ---------------------------------------------------------------------------

class SubAgentRegistry:
    """Manages sub-agent definitions loaded from .superagent/agents/ directories.

    Inspired by CodeBuddy's project + user scoping:
    - Project agents: .superagent/agents/ (under project root)
    - User agents: ~/.superagent/agents/ (global)

    Project-level agents take priority over user-level agents.
    """

    def __init__(self, data_dir: Optional[str] = None, project_dir: Optional[str] = None):
        if data_dir is None:
            data_dir = os.environ.get(
                "CLAWTEAM_DATA_DIR",
                os.path.join(os.path.expanduser("~"), ".superagent"),
            )
        self._data_dir = data_dir
        self._user_agents_dir = os.path.join(data_dir, "agents")
        self._project_agents_dir = os.path.join(project_dir, ".superagent", "agents") if project_dir else None
        self._agents: dict[str, SubAgentDefinition] = {}
        self._executions: dict[str, SubAgentExecution] = {}
        self._load()

    def _load(self) -> None:
        """Load agent definitions from user and project directories."""
        # Load user-level agents first (lower priority)
        self._load_from_dir(self._user_agents_dir, scope="user")
        # Project-level agents override user-level
        if self._project_agents_dir:
            self._load_from_dir(self._project_agents_dir, scope="project")

    def _load_from_dir(self, directory: str, scope: str = "user") -> None:
        """Load all .md agent definitions from a directory."""
        dir_path = Path(directory)
        if not dir_path.is_dir():
            return
        for fp in sorted(dir_path.glob("*.md")):
            try:
                content = fp.read_text(encoding="utf-8")
                agent = parse_agent_markdown(content, source_path=str(fp))
                agent.source_path = str(fp)
                self._agents[agent.name] = agent
                logger.debug("Loaded %s agent: %s from %s", scope, agent.name, fp)
            except Exception as e:
                logger.warning("Failed to load agent from %s: %s", fp, e)

    def reload(self) -> None:
        """Reload all agent definitions."""
        self._agents.clear()
        self._load()

    def list_agents(self) -> list[SubAgentDefinition]:
        """Return all registered sub-agents."""
        return list(self._agents.values())

    def get(self, name: str) -> Optional[SubAgentDefinition]:
        """Get a sub-agent by name."""
        return self._agents.get(name)

    def create_agent(self, agent: SubAgentDefinition, scope: str = "user") -> None:
        """Create a new sub-agent definition on disk."""
        if scope == "project" and self._project_agents_dir:
            agents_dir = self._project_agents_dir
        else:
            agents_dir = self._user_agents_dir

        os.makedirs(agents_dir, exist_ok=True)
        filepath = os.path.join(agents_dir, f"{agent.name}.md")

        # Render as Markdown + YAML frontmatter
        tools_str = ", ".join(agent.tools) if agent.tools else ""
        skills_str = ", ".join(agent.skills) if agent.skills else ""
        frontmatter = (
            f"---\n"
            f"name: {agent.name}\n"
            f"description: {agent.description}\n"
        )
        if tools_str:
            frontmatter += f"tools: {tools_str}\n"
        if agent.model != "inherit":
            frontmatter += f"model: {agent.model}\n"
        if agent.permission_mode != "default":
            frontmatter += f"permission_mode: {agent.permission_mode}\n"
        if skills_str:
            frontmatter += f"skills: {skills_str}\n"
        frontmatter += f"---\n\n{agent.prompt}\n"

        atomic_write(Path(filepath), frontmatter)
        self._agents[agent.name] = agent

    def delete_agent(self, name: str) -> bool:
        """Delete a sub-agent definition. Returns True if found and deleted."""
        agent = self._agents.pop(name, None)
        if agent is None:
            return False
        # Remove the source file
        if agent.source_path and os.path.isfile(agent.source_path):
            os.remove(agent.source_path)
        return True

    # ------------------------------------------------------------------
    # Execution management
    # ------------------------------------------------------------------

    def start_execution(
        self,
        agent_name: str,
        task: str,
        parent_session: Optional[str] = None,
        is_background: bool = False,
    ) -> SubAgentExecution:
        """Create and track a new sub-agent execution."""
        execution = SubAgentExecution(
            agent_id=uuid.uuid4().hex[:12],
            agent_name=agent_name,
            task=task,
            status="pending",
            started_at=datetime.now(timezone.utc).isoformat(),
            parent_session=parent_session,
            is_background=is_background,
        )
        self._executions[execution.agent_id] = execution
        return execution

    def update_execution(self, agent_id: str, status: str, result: str = "") -> Optional[SubAgentExecution]:
        """Update execution status."""
        execution = self._executions.get(agent_id)
        if execution is None:
            return None
        execution.status = status
        if result:
            execution.result = result
        if status in ("completed", "failed", "cancelled"):
            execution.completed_at = datetime.now(timezone.utc).isoformat()
        return execution

    def get_execution(self, agent_id: str) -> Optional[SubAgentExecution]:
        """Get an execution by agent_id."""
        return self._executions.get(agent_id)

    def list_executions(self, status: Optional[str] = None) -> list[SubAgentExecution]:
        """List all executions, optionally filtered by status."""
        executions = list(self._executions.values())
        if status:
            executions = [e for e in executions if e.status == status]
        return executions

    # ------------------------------------------------------------------
    # Delegation — auto-select best agent for a task
    # ------------------------------------------------------------------

    def delegate(self, task: str) -> Optional[SubAgentDefinition]:
        """Auto-select the best sub-agent for a task based on description matching.

        Inspired by CodeBuddy's automatic delegation:
        - Matches task keywords against each agent's description
        - Returns the agent with the highest keyword overlap
        """
        task_lower = task.lower()
        task_words = set(re.findall(r'\w+', task_lower))

        best_agent: Optional[SubAgentDefinition] = None
        best_score = 0.0

        for agent in self._agents.values():
            desc_words = set(re.findall(r'\w+', agent.description.lower()))
            if not desc_words:
                continue
            overlap = len(task_words & desc_words)
            score = overlap / len(desc_words) if desc_words else 0.0
            if score > best_score:
                best_score = score
                best_agent = agent

        return best_agent if best_score > 0.1 else None

    def build_agent_prompt(self, agent_name: str, task: str) -> Optional[str]:
        """Build the full prompt for a sub-agent: system prompt + task.

        This is what gets sent to the LLM when delegating to a sub-agent.
        """
        agent = self.get(agent_name)
        if agent is None:
            return None

        # Load skill prompts if referenced
        skill_sections = []
        for skill_name in agent.skills:
            skill_prompt = self._load_skill_prompt(skill_name)
            if skill_prompt:
                skill_sections.append(f"## Skill: {skill_name}\n\n{skill_prompt}")

        parts = []
        parts.append(agent.prompt)
        if skill_sections:
            parts.append("\n\n" + "\n\n".join(skill_sections))
        parts.append(f"\n\n## Task\n\n{task}")

        return "".join(parts)

    def _load_skill_prompt(self, skill_name: str) -> Optional[str]:
        """Load a SKILL.md prompt from the skills directory."""
        # Check project skills first
        for base in [self._project_agents_dir, self._user_agents_dir]:
            if not base:
                continue
            skill_path = Path(base).parent / "skills" / skill_name / "SKILL.md"
            if skill_path.is_file():
                try:
                    return skill_path.read_text(encoding="utf-8")
                except OSError:
                    pass
        return None


# ---------------------------------------------------------------------------
# Built-in sub-agent definitions (CodeBuddy-inspired)
# ---------------------------------------------------------------------------

BUILTIN_AGENTS: dict[str, str] = {
    "code-reviewer": """---
name: code-reviewer
description: 代码审查专家。主动审查代码的质量、安全性和可维护性。在编写或修改代码后立即使用。
tools: Read, Grep, Glob, Bash
model: inherit
---

你是一位确保代码质量和安全性高标准的高级代码审查员。

审查清单：
- 代码清晰易读
- 函数和变量命名良好
- 没有重复代码
- 正确的错误处理
- 没有暴露的密钥或 API 密钥
- 实现了输入验证
- 良好的测试覆盖率
- 考虑了性能问题

按优先级组织反馈：
- 严重问题（必须修复）
- 警告（应该修复）
- 建议（考虑改进）
""",
    "debugger": """---
name: debugger
description: 错误、测试失败和意外行为的调试专家。遇到任何问题时主动使用。
tools: Read, Edit, Bash, Grep, Glob
---

你是一位专门从事根因分析的专家级调试器。

调试过程：
1. 捕获错误消息和堆栈跟踪
2. 确定复现步骤
3. 隔离故障位置
4. 实现最小修复
5. 验证解决方案有效

对于每个问题，提供：
- 根因解释
- 支持诊断的证据
- 具体的代码修复
- 测试方法
- 预防建议
""",
    "explorer": """---
name: explorer
description: 快速代码库探索和分析专家。用于快速文件发现和代码搜索。
tools: Read, Grep, Glob, Bash
model: inherit
---

你是一个快速、轻量级的代码库探索代理。

工作方式：
- 使用 Glob 查找文件模式
- 使用 Grep 搜索代码内容
- 使用 Read 读取文件内容
- 只使用只读命令

彻底度级别：
- Quick: 快速搜索，最小探索
- Medium: 适度探索，平衡速度和彻底度
- Very thorough: 全面分析，跨多个位置和命名约定
""",
    "test-runner": """---
name: test-runner
description: 测试自动化专家。主动运行测试并修复失败。
tools: Read, Edit, Bash, Grep, Glob
---

你是一位测试自动化专家。当你看到代码更改时，主动运行相应的测试。

如果测试失败，分析失败原因并修复它们，同时保持原始测试意图。
""",
}


def seed_builtin_agents(data_dir: Optional[str] = None) -> int:
    """Seed built-in sub-agent definitions if they don't already exist. Returns count seeded."""
    registry = SubAgentRegistry(data_dir=data_dir)
    seeded = 0
    for name, content in BUILTIN_AGENTS.items():
        if registry.get(name) is not None:
            continue
        agent = parse_agent_markdown(content, source_path=f"builtin:{name}")
        registry.create_agent(agent, scope="user")
        seeded += 1
    return seeded


# ---------------------------------------------------------------------------
# Singleton factory
# ---------------------------------------------------------------------------

_registry_instance: Optional[SubAgentRegistry] = None


def get_subagent_registry(data_dir: Optional[str] = None, project_dir: Optional[str] = None) -> SubAgentRegistry:
    """Return a singleton SubAgentRegistry instance."""
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = SubAgentRegistry(data_dir=data_dir, project_dir=project_dir)
    return _registry_instance
