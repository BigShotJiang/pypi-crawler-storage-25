class SuperAgentError(Exception):
    """Base exception for all SuperAgent related errors."""
    pass

class OrchestrationError(SuperAgentError):
    """Raised when there is an error in orchestrating the flow."""
    pass

class RoleNotFoundError(SuperAgentError):
    """Raised when a specified role cannot be found."""
    pass

class AgentMemoryError(SuperAgentError):
    """Raised when there is an issue with memory operations."""
    pass

class ExecutionError(SuperAgentError):
    """Raised when there is an error executing a task or step."""
    pass

class ValidationError(SuperAgentError):
    """Raised when validation of input or configuration fails."""
    pass
