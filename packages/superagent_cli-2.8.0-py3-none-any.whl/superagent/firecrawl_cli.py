"""SuperAgent scrape CLI — web scraping and crawling via Firecrawl."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.firecrawl_scraper import get_firecrawl, is_firecrawl_available

firecrawl_app = typer.Typer(
    name="scrape",
    help="Web scraping and crawling — convert any website to clean markdown via Firecrawl.",
    no_args_is_help=True,
)
console = Console()


@firecrawl_app.command("status")
def scrape_status():
    """Check Firecrawl availability and API key status."""
    if not is_firecrawl_available():
        console.print(
            Panel(
                "[red bold]Firecrawl is not installed.[/red bold]\n\n"
                "Install with: [bold]pip install firecrawl-py[/bold]",
                title="Firecrawl Status",
                border_style="red",
            )
        )
        raise typer.Exit(1)

    api_key = os.environ.get("FIRECRAWL_API_KEY", "")
    if not api_key:
        console.print(
            Panel(
                "[yellow bold]Firecrawl is installed but no API key is set.[/yellow bold]\n\n"
                "Set your key: [bold]export FIRECRAWL_API_KEY=fc-...[/bold]\n"
                "Get one at: https://firecrawl.dev",
                title="Firecrawl Status",
                border_style="yellow",
            )
        )
        raise typer.Exit(1)

    bridge = get_firecrawl()
    if bridge is None:
        console.print(
            Panel(
                "[red bold]Firecrawl failed to initialize.[/red bold]\n\n"
                "Check your FIRECRAWL_API_KEY and network connectivity.",
                title="Firecrawl Status",
                border_style="red",
            )
        )
        raise typer.Exit(1)

    masked = api_key[:5] + "..." + api_key[-4:] if len(api_key) > 9 else "***"
    console.print(
        Panel(
            "[green bold]Firecrawl is ready.[/green bold]\n\n"
            f"  API key: {masked}\n"
            f"  Package: firecrawl-py",
            title="Firecrawl Status",
            border_style="green",
        )
    )


@firecrawl_app.command("url")
def scrape_url(
    url: str = typer.Argument(..., help="URL to scrape."),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Save markdown to a file."),
    json_out: bool = typer.Option(False, "--json", help="Output full result as JSON."),
):
    """Scrape a single URL and convert it to clean markdown."""
    bridge = get_firecrawl()
    if bridge is None:
        console.print("[red]Firecrawl not available.[/red] Run [bold]superagent scrape status[/bold] for details.")
        raise typer.Exit(1)

    console.print(f"Scraping [bold cyan]{url}[/bold cyan] ...")
    result = bridge.scrape_url(url)

    if not result["success"]:
        console.print(f"[red]Scrape failed:[/red] {result['error']}")
        raise typer.Exit(1)

    if json_out:
        console.print(json.dumps(result, indent=2, ensure_ascii=False))
        return

    # Save to file if requested
    if output:
        Path(output).write_text(result["markdown"], encoding="utf-8")
        console.print(f"[green]Saved to {output}[/green] ({len(result['markdown']):,} chars)")
        return

    # Display in a panel
    title = result.get("metadata", {}).get("title", url)
    md_preview = result["markdown"][:3000]
    if len(result["markdown"]) > 3000:
        md_preview += f"\n\n... ({len(result['markdown']):,} chars total, use --output to save full content)"

    console.print(Panel(md_preview, title=title, border_style="cyan", expand=False))


@firecrawl_app.command("crawl")
def scrape_crawl(
    url: str = typer.Argument(..., help="Starting URL to crawl."),
    limit: int = typer.Option(10, "--limit", "-l", help="Maximum number of pages to crawl."),
    json_out: bool = typer.Option(False, "--json", help="Output full results as JSON."),
):
    """Crawl a website and convert all pages to markdown."""
    bridge = get_firecrawl()
    if bridge is None:
        console.print("[red]Firecrawl not available.[/red] Run [bold]superagent scrape status[/bold] for details.")
        raise typer.Exit(1)

    console.print(f"Crawling [bold cyan]{url}[/bold cyan] (limit: {limit}) ...")
    pages = bridge.crawl_site(url, limit=limit)

    if not pages:
        console.print("[yellow]No pages returned.[/yellow]")
        return

    if json_out:
        console.print(json.dumps(pages, indent=2, ensure_ascii=False))
        return

    table = Table(title=f"Crawl Results ({len(pages)} pages)")
    table.add_column("#", style="dim", width=4)
    table.add_column("URL", style="cyan", max_width=60)
    table.add_column("Title", style="bold", max_width=35)
    table.add_column("Length", style="green", justify="right", width=10)

    for i, page in enumerate(pages, 1):
        title = page.get("metadata", {}).get("title", "")[:35]
        length = f"{len(page.get('markdown', '')):,}"
        page_url = page.get("url", "")
        if len(page_url) > 60:
            page_url = page_url[:57] + "..."
        table.add_row(str(i), page_url, title, length)

    console.print(table)
    console.print("\n[dim]Use --json to get full markdown content for all pages.[/dim]")


@firecrawl_app.command("search")
def scrape_search(
    query: str = typer.Argument(..., help="Search query."),
    limit: int = typer.Option(5, "--limit", "-l", help="Maximum number of results."),
    json_out: bool = typer.Option(False, "--json", help="Output full results as JSON."),
):
    """Search the web and return results as markdown."""
    bridge = get_firecrawl()
    if bridge is None:
        console.print("[red]Firecrawl not available.[/red] Run [bold]superagent scrape status[/bold] for details.")
        raise typer.Exit(1)

    console.print(f"Searching [bold cyan]{query}[/bold cyan] (limit: {limit}) ...")
    results = bridge.search(query, limit=limit)

    if not results:
        console.print("[yellow]No results found.[/yellow]")
        return

    if json_out:
        console.print(json.dumps(results, indent=2, ensure_ascii=False))
        return

    for i, item in enumerate(results, 1):
        title = item.get("title", "Untitled")
        url = item.get("url", "")
        md_preview = item.get("markdown", "")[:500]
        if len(item.get("markdown", "")) > 500:
            md_preview += " ..."

        console.print(
            Panel(
                f"[cyan]{url}[/cyan]\n\n{md_preview}",
                title=f"[{i}] {title}",
                border_style="blue",
                expand=False,
            )
        )
