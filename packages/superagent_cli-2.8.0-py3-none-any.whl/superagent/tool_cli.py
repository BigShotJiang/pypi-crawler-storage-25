"""SuperAgent tool CLI commands — list, search, install, and register tools."""

from __future__ import annotations

import subprocess
import sys
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from superagent.tools import ToolEntry, ToolRegistry, get_tool_registry

tool_app = typer.Typer(
    name="tool",
    help="Tool ecosystem management — discover, install, and manage pip-based tools.",
    no_args_is_help=True,
)
console = Console()


@tool_app.command("list")
def tool_list(
    category: Optional[str] = typer.Option(None, "--category", "-c", help="Filter by category."),
    installed: bool = typer.Option(False, "--installed", "-i", help="Show only installed tools."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List available tools in the registry."""
    reg = get_tool_registry()
    tools = reg.list_tools(category=category, installed_only=installed)

    if json_out:
        import json

        data = [t.to_dict() for t in tools]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not tools:
        console.print(f"[yellow]No tools found{f' in category [{category}]' if category else ''}.[/yellow]")
        if category:
            console.print(f"Available categories: {', '.join(reg.categories())}")
        return

    title = f"Tools ({len(tools)})"
    if category:
        title += f" — category: {category}"
    if installed:
        title += " [installed only]"

    table = Table(title=title)
    table.add_column("Name", style="bold", width=18)
    table.add_column("Category", style="cyan", width=10)
    table.add_column("Installed", width=10)
    table.add_column("Description", style="dim", max_width=50)

    for t in tools:
        status = "[green]yes[/green]" if t.installed else "[dim]no[/dim]"
        table.add_row(t.name, t.category, status, t.description[:50])

    console.print(table)


@tool_app.command("search")
def tool_search(
    query: str = typer.Argument(..., help="Search query (e.g. 'image processing' or 'database sql')."),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Search tools by keywords."""
    reg = get_tool_registry()
    results = reg.search(query, limit=limit)

    if json_out:
        import json

        data = [{"name": t.name, "category": t.category, "score": round(s, 1), "installed": t.installed} for t, s in results]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not results:
        console.print(f"[yellow]No tools matching '{query}'.[/yellow]")
        return

    table = Table(title=f'Search: "{query}"')
    table.add_column("Score", style="green", width=6)
    table.add_column("Name", style="bold", width=18)
    table.add_column("Category", style="cyan", width=10)
    table.add_column("Installed", width=10)
    table.add_column("Description", style="dim", max_width=45)

    for t, score in results:
        status = "[green]yes[/green]" if t.installed else "[dim]no[/dim]"
        table.add_row(f"{score:.1f}", t.name, t.category, status, t.description[:45])

    console.print(table)


@tool_app.command("install")
def tool_install(
    name: str = typer.Argument(..., help="Tool name to install."),
):
    """Install a tool via pip."""
    reg = get_tool_registry()
    tool = reg.get(name)

    if not tool:
        console.print(f"[red]Tool '{name}' not found in registry.[/red]")
        console.print("Use [bold]superagent tool search[/bold] to find available tools.")
        raise typer.Exit(1)

    if reg.is_installed(name):
        console.print(f"[green]'{name}' is already installed.[/green]")
        return

    console.print(f"Installing [bold]{name}[/bold] via: {tool.install_cmd}")
    result = subprocess.run(
        [sys.executable, "-m", "pip", "install", *tool.install_cmd.split()[2:]],
        capture_output=True,
        text=True,
    )

    if result.returncode == 0:
        tool.installed = True
        reg.save()
        console.print(f"[green]Successfully installed '{name}'.[/green]")
    else:
        console.print(f"[red]Installation failed:[/red]\n{result.stderr}")
        raise typer.Exit(1)


@tool_app.command("register")
def tool_register(
    name: str = typer.Option(..., "--name", help="Tool name (unique identifier)."),
    description: str = typer.Option(..., "--description", help="Short description of the tool."),
    install_cmd: str = typer.Option(..., "--install-cmd", help="Pip install command (e.g. 'pip install my-tool')."),
    category: str = typer.Option("dev", "--category", help="Category (dev, data, web, media, office, ai)."),
):
    """Register a custom tool in the registry."""
    reg = get_tool_registry()

    existing = reg.get(name)
    if existing:
        console.print(f"[yellow]Tool '{name}' already exists. Updating.[/yellow]")

    entry = ToolEntry(
        name=name,
        description=description,
        install_cmd=install_cmd,
        category=category,
        keywords=list(dict.fromkeys(
            w for w in name.lower().replace("-", " ").split() + category.lower().split()
            if len(w) > 2
        )),
        installed=ToolRegistry._check_installed(name),
    )
    reg.register(entry)
    console.print(f"[green]Registered tool '{name}' in category '{category}'.[/green]")


@tool_app.command("categories")
def tool_categories():
    """List available tool categories."""
    reg = get_tool_registry()
    cats = reg.categories()
    if not cats:
        console.print("[yellow]No categories found.[/yellow]")
        return

    all_tools = reg.list_tools()
    for cat in cats:
        count = sum(1 for t in all_tools if t.category == cat)
        installed = sum(1 for t in all_tools if t.category == cat and t.installed)
        console.print(f"  [cyan]{cat}[/cyan] ({count} tools, {installed} installed)")


@tool_app.command("sync")
def tool_sync(
    url: str = typer.Option(
        ...,
        "--url",
        "-u",
        help="URL of a remote JSON tool registry (CLI-Hub compatible).",
    ),
):
    """Sync tools from a remote registry URL into the local registry."""
    reg = get_tool_registry()

    console.print(f"Fetching tools from [bold]{url}[/bold] ...")
    try:
        added, updated = reg.sync_remote(url)
    except Exception as exc:
        console.print(f"[red]Sync failed:[/red] {exc}")
        raise typer.Exit(1)

    console.print(f"[green]Sync complete:[/green] {added} added, {updated} updated.")
