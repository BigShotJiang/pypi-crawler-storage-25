"""Skills security scanner for SuperAgent — inspired by Hermes Agent skills_guard.py.

Scans skill files and imported content for threats:
- Data exfiltration (curl/wget with secrets, env dumps)
- Prompt injection (ignore previous instructions)
- Destructive commands (rm -rf, drop table)
- Credential access (reading .env, .ssh, .aws)
"""
from __future__ import annotations

import re
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class SecurityFinding:
    pattern_id: str
    severity: str  # critical, high, medium
    category: str  # exfiltration, injection, destructive, credential_access
    file: str
    line: int
    match: str
    description: str


@dataclass 
class ScanResult:
    target: str
    verdict: str  # safe, caution, dangerous
    findings: list[SecurityFinding] = field(default_factory=list)
    
    @property
    def is_safe(self) -> bool:
        return self.verdict == "safe"


# Threat patterns: (regex, id, severity, category, description)
THREAT_PATTERNS = [
    # Exfiltration
    (r'curl\s+[^\n]*\$\{?\w*(KEY|TOKEN|SECRET|PASSWORD|CREDENTIAL|API)', "exfil_curl", "critical", "exfiltration", "curl with secret env var"),
    (r'wget\s+[^\n]*\$\{?\w*(KEY|TOKEN|SECRET|PASSWORD)', "exfil_wget", "critical", "exfiltration", "wget with secret env var"),
    (r'requests\.(get|post)\s*\([^\n]*(KEY|TOKEN|SECRET|PASSWORD)', "exfil_requests", "critical", "exfiltration", "HTTP request with secret"),
    (r'httpx?\.(get|post)\s*\([^\n]*(KEY|TOKEN|SECRET)', "exfil_httpx", "critical", "exfiltration", "httpx with secret"),
    (r'cat\s+[^\n]*\.(env|credentials|netrc|pgpass|npmrc|pypirc)', "read_secrets", "critical", "exfiltration", "reads secrets file"),
    (r'printenv|env\s*\|', "dump_env", "high", "exfiltration", "dumps all env vars"),
    (r'os\.environ\b', "os_environ", "high", "exfiltration", "accesses os.environ"),
    (r'base64[^\n]*env', "encoded_exfil", "high", "exfiltration", "base64 + env access"),
    (r'!\[.*\]\(https?://[^\)]*\$\{?', "md_image_exfil", "high", "exfiltration", "markdown image with variable (image-based exfil)"),
    # Credential access
    (r'\$HOME/\.ssh|\~/\.ssh', "ssh_access", "high", "credential_access", "SSH directory access"),
    (r'\$HOME/\.aws|\~/\.aws', "aws_access", "high", "credential_access", "AWS credentials access"),
    (r'\$HOME/\.kube|\~/\.kube', "kube_access", "high", "credential_access", "Kubernetes config access"),
    # Prompt injection
    (r'ignore\s+(all\s+)?previous\s+instructions', "prompt_inject", "high", "injection", "prompt injection attempt"),
    (r'you\s+are\s+now\s+', "role_override", "medium", "injection", "role override attempt"),
    (r'system\s*:\s*', "fake_system", "medium", "injection", "fake system message"),
    # Destructive
    (r'rm\s+(-rf?|--recursive).*[/~]', "destructive_rm", "critical", "destructive", "recursive delete"),
    (r'drop\s+(table|database)', "drop_table", "critical", "destructive", "SQL drop"),
    (r'(mkfs|fdisk|dd\s+if=)', "disk_format", "critical", "destructive", "disk formatting"),
    (r'chmod\s+777', "chmod_777", "medium", "destructive", "world-writable permissions"),
]

_COMPILED = [(re.compile(p, re.IGNORECASE | re.MULTILINE), pid, sev, cat, desc) for p, pid, sev, cat, desc in THREAT_PATTERNS]


def scan_text(text: str, source: str = "<text>") -> ScanResult:
    """Scan a text string for security threats."""
    findings = []
    for i, line in enumerate(text.split("\n"), 1):
        for pattern, pid, severity, category, description in _COMPILED:
            for m in pattern.finditer(line):
                findings.append(SecurityFinding(
                    pattern_id=pid, severity=severity, category=category,
                    file=source, line=i, match=m.group()[:100], description=description,
                ))
    
    has_critical = any(f.severity == "critical" for f in findings)
    has_high = any(f.severity == "high" for f in findings)
    verdict = "dangerous" if has_critical else ("caution" if has_high else "safe")
    return ScanResult(target=source, verdict=verdict, findings=findings)


def scan_file(path: str) -> ScanResult:
    """Scan a file for security threats."""
    try:
        content = Path(path).read_text(encoding="utf-8", errors="ignore")
        return scan_text(content, source=path)
    except Exception as e:
        return ScanResult(target=path, verdict="caution", findings=[
            SecurityFinding("read_error", "medium", "error", path, 0, str(e), "Could not read file"),
        ])


def scan_directory(dir_path: str) -> list[ScanResult]:
    """Scan all files in a directory."""
    results = []
    for p in Path(dir_path).rglob("*"):
        if p.is_file() and p.suffix in (".py", ".sh", ".js", ".ts", ".md", ".yaml", ".yml", ".toml"):
            results.append(scan_file(str(p)))
    return results
