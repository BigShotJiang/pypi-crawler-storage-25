"""SuperAgent - AI Agent self-organizing teams, task allocation, and collaborative CLI tool.

Built on ClawTeam with enhancements from 35+ open-source projects.
"""

from superagent.logger import get_logger

__version__ = "2.8.0"
__all__ = ["get_logger"]
