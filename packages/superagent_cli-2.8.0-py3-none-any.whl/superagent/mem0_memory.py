"""Semantic memory for SuperAgent — powered by Mem0 (52k stars).

Upgrades SuperAgent's keyword-based memory to semantic vector search.
Falls back to the existing memory.py when Mem0 is not available.
"""
from __future__ import annotations

import logging
import os
from typing import Optional

logger = logging.getLogger(__name__)

_MEM0_AVAILABLE = False
try:
    from mem0 import Memory
    _MEM0_AVAILABLE = True
except ImportError:
    logger.debug("mem0 not installed: pip install mem0ai")


def is_mem0_available() -> bool:
    return _MEM0_AVAILABLE


class Mem0Store:
    """Semantic memory store powered by Mem0."""
    
    def __init__(self, config: Optional[dict] = None):
        if not _MEM0_AVAILABLE:
            raise RuntimeError("mem0 not installed. Run: pip install mem0ai")
        
        self._config = config or self._default_config()
        self._memory = Memory.from_config(self._config)
    
    @staticmethod
    def _default_config() -> dict:
        """Default Mem0 config using the best available LLM."""
        # Try to get API key from superagent config
        api_key = os.environ.get("OPENAI_API_KEY", "")
        if not api_key:
            api_key = os.environ.get("DEEPSEEK_API_KEY", "")
        
        config = {
            "version": "v1.1",
        }
        
        # If we have an API key, configure the LLM
        if api_key and os.environ.get("OPENAI_API_KEY"):
            config["llm"] = {
                "provider": "openai",
                "config": {"model": "gpt-4o-mini", "api_key": api_key}
            }
        
        return config
    
    def add(self, content: str, user_id: str = "default", agent_id: Optional[str] = None, 
            metadata: Optional[dict] = None) -> dict:
        """Add a memory. Returns the memory object."""
        kwargs = {"user_id": user_id}
        if agent_id:
            kwargs["agent_id"] = agent_id
        if metadata:
            kwargs["metadata"] = metadata
        result = self._memory.add(content, **kwargs)
        return result
    
    def search(self, query: str, user_id: str = "default", limit: int = 10) -> list[dict]:
        """Semantic search across memories."""
        results = self._memory.search(query, user_id=user_id, limit=limit)
        return results.get("results", []) if isinstance(results, dict) else results
    
    def get_all(self, user_id: str = "default") -> list[dict]:
        """Get all memories for a user."""
        results = self._memory.get_all(user_id=user_id)
        return results.get("results", []) if isinstance(results, dict) else results
    
    def delete(self, memory_id: str) -> bool:
        """Delete a specific memory."""
        try:
            self._memory.delete(memory_id)
            return True
        except Exception as e:
            logger.debug("Mem0 delete failed for %s: %s", memory_id, e)
            return False
    
    def history(self, memory_id: str) -> list[dict]:
        """Get the history/evolution of a memory."""
        try:
            return self._memory.history(memory_id)
        except Exception as e:
            logger.debug("Mem0 history failed for %s: %s", memory_id, e)
            return []


def get_mem0_store(config: Optional[dict] = None) -> Optional[Mem0Store]:
    """Get a Mem0Store instance, or None if Mem0 is not available."""
    if not _MEM0_AVAILABLE:
        return None
    try:
        return Mem0Store(config)
    except Exception as e:
        logger.warning("Failed to initialize Mem0: %s", e)
        return None
