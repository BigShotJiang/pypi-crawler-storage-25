"""Aider coding agent integration for SuperAgent — terminal-native, model-agnostic (25k stars).

Enables SuperAgent to use Aider as an alternative coding backend.
Aider excels at incremental code changes via unified diffs.
"""
from __future__ import annotations

import logging
import os
import shutil
import subprocess
from typing import Optional

logger = logging.getLogger(__name__)

_AIDER_AVAILABLE = shutil.which("aider") is not None


def is_aider_available() -> bool:
    return _AIDER_AVAILABLE


def run_aider(
    task: str,
    *,
    working_dir: Optional[str] = None,
    model: str = "deepseek/deepseek-chat",
    auto_commit: bool = True,
    yes: bool = True,
    files: Optional[list[str]] = None,
) -> dict:
    """Run Aider with a task in the specified directory.
    
    Returns dict with success, stdout, stderr, files_changed.
    """
    cmd = ["aider", "--message", task, "--model", model]
    
    if yes:
        cmd.append("--yes-always")
    if not auto_commit:
        cmd.append("--no-auto-commits")
    if files:
        cmd.extend(files)
    
    # Set API key env vars from superagent config
    env = os.environ.copy()
    
    try:
        result = subprocess.run(
            cmd,
            cwd=working_dir or os.getcwd(),
            capture_output=True,
            text=True,
            timeout=300,
            env=env,
        )
        return {
            "success": result.returncode == 0,
            "stdout": result.stdout,
            "stderr": result.stderr,
            "engine": "aider",
            "error": None if result.returncode == 0 else result.stderr[:200],
        }
    except subprocess.TimeoutExpired:
        return {"success": False, "stdout": "", "stderr": "Timeout (300s)", "engine": "aider", "error": "Timeout"}
    except FileNotFoundError:
        return {"success": False, "stdout": "", "stderr": "aider not found", "engine": "aider", "error": "aider not installed. Run: pip install aider-chat"}
    except Exception as e:
        return {"success": False, "stdout": "", "stderr": str(e), "engine": "aider", "error": str(e)}
