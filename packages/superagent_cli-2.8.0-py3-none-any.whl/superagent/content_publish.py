"""Multi-platform content publishing bridge.

Provides a unified interface for publishing articles to multiple platforms
simultaneously. Supports both API-based (Medium, Dev.to, WordPress) and
browser-automated (Zhihu, Juejin) publishing.
"""

from __future__ import annotations

import json
import logging
import os
import re
from abc import ABC, abstractmethod
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

import httpx

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)

# Optional dependency check
_PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.async_api import async_playwright  # noqa: F401
    _PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass

_FRONTMATTER_AVAILABLE = False
try:
    import frontmatter  # noqa: F401
    _FRONTMATTER_AVAILABLE = True
except ImportError:
    pass


def is_playwright_available() -> bool:
    return _PLAYWRIGHT_AVAILABLE


# ---------------------------------------------------------------------------
# Data models
# ---------------------------------------------------------------------------


@dataclass
class PlatformConfig:
    """Configuration for a single publishing platform."""
    name: str
    platform_type: str  # "api" or "browser"
    enabled: bool = True
    api_key: str = ""
    api_url: str = ""
    cookies: str = ""  # JSON string of cookies for browser platforms
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class PublishResult:
    """Result of a publish operation."""
    platform: str
    success: bool
    url: str = ""
    error: str = ""
    draft: bool = False


@dataclass
class Article:
    """Parsed article ready for publishing."""
    title: str
    content_markdown: str
    content_html: str
    tags: list[str] = field(default_factory=list)
    cover_image: str = ""
    canonical_url: str = ""
    description: str = ""


# ---------------------------------------------------------------------------
# Content adapter
# ---------------------------------------------------------------------------


class ContentAdapter:
    """Converts Markdown content to platform-specific formats."""

    @staticmethod
    def parse_article(file_path: str) -> Article:
        """Parse a Markdown file into an Article."""
        path = Path(file_path)
        if not path.exists():
            raise FileNotFoundError(f"Article file not found: {file_path}")

        raw = path.read_text(encoding="utf-8")

        # Parse frontmatter if available
        title = ""
        tags: list[str] = []
        cover_image = ""
        canonical_url = ""
        description = ""
        body = raw

        if _FRONTMATTER_AVAILABLE:
            post = frontmatter.loads(raw)
            title = post.get("title", "")
            tags = post.get("tags", [])
            if isinstance(tags, str):
                tags = [t.strip() for t in tags.split(",")]
            cover_image = post.get("cover_image", post.get("cover", ""))
            canonical_url = post.get("canonical_url", "")
            description = post.get("description", "")
            body = post.content
        else:
            # Basic frontmatter extraction without library
            fm_match = re.match(r"^---\s*\n(.*?)\n---\s*\n", raw, re.DOTALL)
            if fm_match:
                fm_text = fm_match.group(1)
                body = raw[fm_match.end():]
                for line in fm_text.splitlines():
                    if ":" in line:
                        key, _, val = line.partition(":")
                        key = key.strip().lower()
                        val = val.strip().strip('"').strip("'")
                        if key == "title":
                            title = val
                        elif key == "tags":
                            tags = [t.strip() for t in val.split(",")]
                        elif key in ("cover_image", "cover"):
                            cover_image = val
                        elif key == "canonical_url":
                            canonical_url = val
                        elif key == "description":
                            description = val

        if not title:
            # Extract title from first H1
            h1 = re.search(r"^#\s+(.+)$", body, re.MULTILINE)
            if h1:
                title = h1.group(1).strip()

        if not title:
            title = path.stem.replace("-", " ").replace("_", " ").title()

        html = ContentAdapter.markdown_to_html(body)

        return Article(
            title=title,
            content_markdown=body,
            content_html=html,
            tags=tags,
            cover_image=cover_image,
            canonical_url=canonical_url,
            description=description,
        )

    @staticmethod
    def markdown_to_html(md: str) -> str:
        """Convert Markdown to HTML with basic support."""
        try:
            import markdown
            return markdown.markdown(md, extensions=["fenced_code", "tables", "toc"])
        except ImportError:
            pass
        # Minimal fallback: wrap in <pre> for code, basic paragraph splitting
        paragraphs = md.split("\n\n")
        html_parts = []
        for p in paragraphs:
            p = p.strip()
            if not p:
                continue
            if p.startswith("```"):
                html_parts.append(f"<pre><code>{p.strip('`').strip()}</code></pre>")
            elif p.startswith("# "):
                html_parts.append(f"<h1>{p[2:]}</h1>")
            elif p.startswith("## "):
                html_parts.append(f"<h2>{p[3:]}</h2>")
            elif p.startswith("### "):
                html_parts.append(f"<h3>{p[4:]}</h3>")
            else:
                html_parts.append(f"<p>{p}</p>")
        return "\n".join(html_parts)


# ---------------------------------------------------------------------------
# Config manager
# ---------------------------------------------------------------------------


class ConfigManager:
    """Manage platform publishing configurations."""

    def __init__(self, config_dir: str | None = None):
        self._dir = Path(config_dir or os.path.join(
            os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")),
            "publish",
        ))
        self._dir.mkdir(parents=True, exist_ok=True)
        self._config_file = self._dir / "config.json"
        self._platforms: dict[str, PlatformConfig] = {}
        self._load()

    def _load(self) -> None:
        if self._config_file.exists():
            try:
                data = json.loads(self._config_file.read_text(encoding="utf-8"))
                for name, cfg in data.get("platforms", {}).items():
                    self._platforms[name] = PlatformConfig(name=name, **cfg)
            except (json.JSONDecodeError, TypeError):
                logger.warning("Failed to load publish config, starting fresh")

    def save(self) -> None:
        data = {"platforms": {}}
        for name, cfg in self._platforms.items():
            data["platforms"][name] = {
                "platform_type": cfg.platform_type,
                "enabled": cfg.enabled,
                "api_key": cfg.api_key,
                "api_url": cfg.api_url,
                "cookies": cfg.cookies,
                "extra": cfg.extra,
            }
        atomic_write(self._config_file, json.dumps(data, indent=2, ensure_ascii=False))

    def get_platform(self, name: str) -> PlatformConfig | None:
        return self._platforms.get(name)

    def add_platform(self, config: PlatformConfig) -> None:
        self._platforms[config.name] = config
        self.save()

    def remove_platform(self, name: str) -> bool:
        if name in self._platforms:
            del self._platforms[name]
            self.save()
            return True
        return False

    def list_platforms(self) -> list[PlatformConfig]:
        return list(self._platforms.values())

    def get_enabled_platforms(self) -> list[PlatformConfig]:
        return [p for p in self._platforms.values() if p.enabled]


# ---------------------------------------------------------------------------
# Abstract publisher
# ---------------------------------------------------------------------------


class PlatformPublisher(ABC):
    """Abstract base class for platform publishers."""

    name: str
    platform_type: str  # "api" or "browser"

    @abstractmethod
    async def publish(self, article: Article, config: PlatformConfig) -> PublishResult:
        """Publish an article to this platform."""

    @abstractmethod
    async def validate_config(self, config: PlatformConfig) -> bool:
        """Check if the platform configuration is valid."""


# ---------------------------------------------------------------------------
# API publishers
# ---------------------------------------------------------------------------


class MediumPublisher(PlatformPublisher):
    """Publish articles to Medium via API."""

    name = "medium"
    platform_type = "api"

    async def validate_config(self, config: PlatformConfig) -> bool:
        if not config.api_key:
            return False
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    "https://api.medium.com/v1/me",
                    headers={"Authorization": f"Bearer {config.api_key}"},
                )
                return resp.status_code == 200
        except Exception as e:
            logger.debug("Medium auth check failed: %s", e)
            return False

    async def publish(self, article: Article, config: PlatformConfig) -> PublishResult:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                # Get user ID
                me_resp = await client.get(
                    "https://api.medium.com/v1/me",
                    headers={"Authorization": f"Bearer {config.api_key}"},
                )
                me_resp.raise_for_status()
                user_id = me_resp.json()["data"]["id"]

                # Create post
                payload = {
                    "title": article.title,
                    "contentFormat": "html",
                    "content": f"<h1>{article.title}</h1>\n{article.content_html}",
                    "tags": article.tags[:5],  # Medium allows max 5 tags
                    "publishStatus": "draft",
                }
                if article.canonical_url:
                    payload["canonicalUrl"] = article.canonical_url

                resp = await client.post(
                    f"https://api.medium.com/v1/users/{user_id}/posts",
                    headers={
                        "Authorization": f"Bearer {config.api_key}",
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
                resp.raise_for_status()
                data = resp.json()["data"]
                return PublishResult(
                    platform="medium",
                    success=True,
                    url=data.get("url", ""),
                    draft=True,
                )
        except Exception as e:
            return PublishResult(platform="medium", success=False, error=str(e))


class DevtoPublisher(PlatformPublisher):
    """Publish articles to Dev.to via API."""

    name = "devto"
    platform_type = "api"

    async def validate_config(self, config: PlatformConfig) -> bool:
        if not config.api_key:
            return False
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(
                    "https://dev.to/api/users/me",
                    headers={"api-key": config.api_key},
                )
                return resp.status_code == 200
        except Exception as e:
            logger.debug("Dev.to auth check failed: %s", e)
            return False

    async def publish(self, article: Article, config: PlatformConfig) -> PublishResult:
        try:
            async with httpx.AsyncClient(timeout=30) as client:
                payload = {
                    "article": {
                        "title": article.title,
                        "body_markdown": article.content_markdown,
                        "published": False,  # Draft first
                        "tags": article.tags[:4],  # Dev.to allows max 4 tags
                    }
                }
                if article.cover_image:
                    payload["article"]["main_image"] = article.cover_image
                if article.canonical_url:
                    payload["article"]["canonical_url"] = article.canonical_url
                if article.description:
                    payload["article"]["description"] = article.description

                resp = await client.post(
                    "https://dev.to/api/articles",
                    headers={
                        "api-key": config.api_key,
                        "Content-Type": "application/json",
                    },
                    json=payload,
                )
                resp.raise_for_status()
                data = resp.json()
                return PublishResult(
                    platform="devto",
                    success=True,
                    url=data.get("url", ""),
                    draft=True,
                )
        except Exception as e:
            return PublishResult(platform="devto", success=False, error=str(e))


class WordPressPublisher(PlatformPublisher):
    """Publish articles to WordPress via REST API."""

    name = "wordpress"
    platform_type = "api"

    async def validate_config(self, config: PlatformConfig) -> bool:
        if not config.api_url:
            return False
        try:
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.get(f"{config.api_url.rstrip('/')}/wp-json/wp/v2/posts")
                return resp.status_code in (200, 401)  # 401 means API exists but needs auth
        except Exception as e:
            logger.debug("WordPress API check failed: %s", e)
            return False

    async def publish(self, article: Article, config: PlatformConfig) -> PublishResult:
        try:
            base = config.api_url.rstrip("/")
            headers: dict[str, str] = {"Content-Type": "application/json"}
            if config.api_key:
                headers["Authorization"] = f"Bearer {config.api_key}"

            payload = {
                "title": article.title,
                "content": article.content_html,
                "status": "draft",
            }
            if article.tags:
                payload["tags"] = article.tags

            async with httpx.AsyncClient(timeout=30) as client:
                resp = await client.post(
                    f"{base}/wp-json/wp/v2/posts",
                    headers=headers,
                    json=payload,
                )
                resp.raise_for_status()
                data = resp.json()
                return PublishResult(
                    platform="wordpress",
                    success=True,
                    url=data.get("link", ""),
                    draft=True,
                )
        except Exception as e:
            return PublishResult(platform="wordpress", success=False, error=str(e))


# ---------------------------------------------------------------------------
# Browser-automated publishers (require Playwright)
# ---------------------------------------------------------------------------


class ZhihuPublisher(PlatformPublisher):
    """Publish articles to Zhihu (知乎) via browser automation."""

    name = "zhihu"
    platform_type = "browser"

    async def validate_config(self, config: PlatformConfig) -> bool:
        return bool(config.cookies) and _PLAYWRIGHT_AVAILABLE

    async def publish(self, article: Article, config: PlatformConfig) -> PublishResult:
        if not _PLAYWRIGHT_AVAILABLE:
            return PublishResult(
                platform="zhihu",
                success=False,
                error="playwright not installed. Run: pip install playwright && playwright install chromium",
            )
        try:
            cookies = json.loads(config.cookies) if config.cookies else []
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context()
                if cookies:
                    await context.add_cookies(cookies)
                page = await context.new_page()

                await page.goto("https://zhuanlan.zhihu.com/write", wait_until="networkidle")
                # Fill title
                title_input = page.locator('[placeholder*="请输入标题"]').first
                await title_input.fill(article.title)
                # Fill content via clipboard paste
                editor = page.locator(".ProseMirror, .public-DraftEditor-content, .ql-editor").first
                await editor.click()
                await page.keyboard.insert_text(article.content_markdown)

                await browser.close()
                return PublishResult(
                    platform="zhihu",
                    success=True,
                    url="https://zhuanlan.zhihu.com/write",
                    draft=True,
                )
        except Exception as e:
            return PublishResult(platform="zhihu", success=False, error=str(e))


class JuejinPublisher(PlatformPublisher):
    """Publish articles to Juejin (掘金) via browser automation."""

    name = "juejin"
    platform_type = "browser"

    async def validate_config(self, config: PlatformConfig) -> bool:
        return bool(config.cookies) and _PLAYWRIGHT_AVAILABLE

    async def publish(self, article: Article, config: PlatformConfig) -> PublishResult:
        if not _PLAYWRIGHT_AVAILABLE:
            return PublishResult(
                platform="juejin",
                success=False,
                error="playwright not installed. Run: pip install playwright && playwright install chromium",
            )
        try:
            cookies = json.loads(config.cookies) if config.cookies else []
            async with async_playwright() as p:
                browser = await p.chromium.launch(headless=True)
                context = await browser.new_context()
                if cookies:
                    await context.add_cookies(cookies)
                page = await context.new_page()

                await page.goto("https://juejin.cn/editor/drafts/new", wait_until="networkidle")
                # Fill title
                title_input = page.locator('[placeholder*="输入文章标题"]').first
                await title_input.fill(article.title)
                # Fill content
                editor = page.locator(".CodeMirror, .bytemd-body, .ProseMirror").first
                await editor.click()
                await page.keyboard.insert_text(article.content_markdown)

                await browser.close()
                return PublishResult(
                    platform="juejin",
                    success=True,
                    url="https://juejin.cn/editor/drafts/new",
                    draft=True,
                )
        except Exception as e:
            return PublishResult(platform="juejin", success=False, error=str(e))


# ---------------------------------------------------------------------------
# Publisher registry
# ---------------------------------------------------------------------------


PUBLISHERS: dict[str, PlatformPublisher] = {
    "medium": MediumPublisher(),
    "devto": DevtoPublisher(),
    "wordpress": WordPressPublisher(),
    "zhihu": ZhihuPublisher(),
    "juejin": JuejinPublisher(),
}

PLATFORM_INFO: dict[str, dict[str, str]] = {
    "medium": {"type": "api", "description": "Medium — popular English blogging platform", "auth": "Integration token"},
    "devto": {"type": "api", "description": "Dev.to — developer community blog", "auth": "API key"},
    "wordpress": {"type": "api", "description": "WordPress — self-hosted blog via REST API", "auth": "Application password"},
    "zhihu": {"type": "browser", "description": "知乎专栏 — Chinese knowledge-sharing platform", "auth": "Browser cookies"},
    "juejin": {"type": "browser", "description": "掘金 — Chinese developer community", "auth": "Browser cookies"},
}


# ---------------------------------------------------------------------------
# Main bridge
# ---------------------------------------------------------------------------


class ContentPublishBridge:
    """Unified interface for multi-platform content publishing."""

    def __init__(self, config_dir: str | None = None):
        self._config = ConfigManager(config_dir)

    @property
    def config(self) -> ConfigManager:
        return self._config

    async def publish_article(
        self,
        file_path: str,
        platforms: list[str] | None = None,
        all_platforms: bool = False,
    ) -> list[PublishResult]:
        """Publish an article to specified platforms.

        Args:
            file_path: Path to a Markdown file.
            platforms: List of platform names. If None and all_platforms is True, uses all enabled.
            all_platforms: If True, publish to all enabled platforms.

        Returns:
            List of PublishResult for each platform.
        """
        article = ContentAdapter.parse_article(file_path)
        results: list[PublishResult] = []

        if all_platforms:
            target_configs = self._config.get_enabled_platforms()
        elif platforms:
            target_configs = [
                self._config.get_platform(p) for p in platforms
                if self._config.get_platform(p)
            ]
        else:
            return [PublishResult(platform="none", success=False, error="No platforms specified")]

        for cfg in target_configs:
            if cfg is None:
                continue
            publisher = PUBLISHERS.get(cfg.name)
            if publisher is None:
                results.append(PublishResult(
                    platform=cfg.name, success=False,
                    error=f"No publisher implemented for '{cfg.name}'",
                ))
                continue
            result = await publisher.publish(article, cfg)
            results.append(result)
            logger.info(
                "Published to %s: %s %s",
                cfg.name,
                "OK" if result.success else "FAIL",
                result.url or result.error,
            )

        return results


def get_publish_bridge(config_dir: str | None = None) -> ContentPublishBridge:
    """Factory function to create a ContentPublishBridge."""
    return ContentPublishBridge(config_dir)
