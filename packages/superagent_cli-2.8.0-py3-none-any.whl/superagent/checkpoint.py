"""Checkpoint and Resume system for SuperAgent — persistent execution with failure recovery.

Inspired by LangGraph's durable execution model.  Provides checkpointing of
multi-stage team workflows so that long-running orchestrations can be paused,
resumed, and recovered after failures.  Checkpoints are persisted as JSON files
under ``~/.superagent/checkpoints/{team}/``.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write


class CheckpointStatus(str, Enum):
    """Lifecycle status of a checkpoint."""

    active = "active"
    paused = "paused"
    completed = "completed"
    failed = "failed"


def _now_iso() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


@dataclass
class Checkpoint:
    """A durable execution checkpoint capturing the state of a team workflow."""

    id: str
    team: str
    stage: str
    status: CheckpointStatus
    state: dict = field(default_factory=dict)
    agent_states: dict[str, str] = field(default_factory=dict)
    created_at: str = ""
    updated_at: str = ""
    error: Optional[str] = None

    def to_dict(self) -> dict:
        """Serialize to a plain dict suitable for JSON storage."""
        d = asdict(self)
        status = self.status
        d["status"] = status.value if isinstance(status, CheckpointStatus) else str(status)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> Checkpoint:
        """Deserialize from a dict loaded from JSON."""
        return cls(
            id=data["id"],
            team=data["team"],
            stage=data.get("stage", ""),
            status=CheckpointStatus(data.get("status", "active")),
            state=data.get("state", {}),
            agent_states=data.get("agent_states", {}),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
            error=data.get("error"),
        )


class CheckpointStore:
    """Manages durable checkpoints persisted as JSON files.

    Directory layout under *base_dir*::

        checkpoints/
        └── {team}/
            └── {checkpoint_id}.json
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir) / "checkpoints"
        self._base.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _team_dir(self, team: str) -> Path:
        return self._base / team

    def _checkpoint_path(self, team: str, checkpoint_id: str) -> Path:
        return self._team_dir(team) / f"{checkpoint_id}.json"

    def _save_file(self, checkpoint: Checkpoint) -> None:
        path = self._checkpoint_path(checkpoint.team, checkpoint.id)
        atomic_write(path, json.dumps(checkpoint.to_dict(), indent=2, ensure_ascii=False))

    def _load_file(self, path: Path) -> Optional[Checkpoint]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return Checkpoint.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def save(self, checkpoint: Checkpoint) -> Checkpoint:
        """Save or update a checkpoint."""
        checkpoint.updated_at = _now_iso()
        if not checkpoint.created_at:
            checkpoint.created_at = checkpoint.updated_at
        self._save_file(checkpoint)
        return checkpoint

    def get(self, checkpoint_id: str) -> Optional[Checkpoint]:
        """Retrieve a checkpoint by ID, searching all teams."""
        for json_file in self._base.rglob("*.json"):
            if json_file.stem == checkpoint_id:
                return self._load_file(json_file)
        return None

    def get_latest(self, team: str) -> Optional[Checkpoint]:
        """Return the most recently updated checkpoint for a team."""
        team_dir = self._team_dir(team)
        if not team_dir.exists():
            return None
        latest: Optional[Checkpoint] = None
        for json_file in team_dir.glob("*.json"):
            cp = self._load_file(json_file)
            if cp is None:
                continue
            if latest is None or cp.updated_at > latest.updated_at:
                latest = cp
        return latest

    def list_checkpoints(
        self,
        team: Optional[str] = None,
        status: Optional[CheckpointStatus] = None,
    ) -> list[Checkpoint]:
        """List checkpoints with optional team and status filters."""
        results: list[Checkpoint] = []
        if team:
            search_dir = self._team_dir(team)
            if not search_dir.exists():
                return []
            files = search_dir.glob("*.json")
        else:
            files = self._base.rglob("*.json")

        for json_file in files:
            cp = self._load_file(json_file)
            if cp is None:
                continue
            if status is not None and cp.status != status:
                continue
            results.append(cp)

        results.sort(key=lambda c: c.updated_at, reverse=True)
        return results

    def update_stage(
        self,
        checkpoint_id: str,
        stage: str,
        state: Optional[dict] = None,
    ) -> Optional[Checkpoint]:
        """Advance a checkpoint to the next stage, optionally updating state."""
        cp = self.get(checkpoint_id)
        if cp is None:
            return None
        cp.stage = stage
        if state is not None:
            cp.state = state
        return self.save(cp)

    def update_agent_state(
        self,
        checkpoint_id: str,
        agent_name: str,
        status: str,
    ) -> Optional[Checkpoint]:
        """Update the status of an individual agent within a checkpoint."""
        cp = self.get(checkpoint_id)
        if cp is None:
            return None
        cp.agent_states[agent_name] = status
        return self.save(cp)

    def pause(self, checkpoint_id: str) -> Optional[Checkpoint]:
        """Pause execution of a checkpoint."""
        cp = self.get(checkpoint_id)
        if cp is None:
            return None
        cp.status = CheckpointStatus.paused
        return self.save(cp)

    def resume(self, checkpoint_id: str) -> Optional[Checkpoint]:
        """Resume a paused checkpoint."""
        cp = self.get(checkpoint_id)
        if cp is None:
            return None
        if cp.status != CheckpointStatus.paused:
            return None
        cp.status = CheckpointStatus.active
        cp.error = None
        return self.save(cp)

    def fail(self, checkpoint_id: str, error: str) -> Optional[Checkpoint]:
        """Mark a checkpoint as failed with an error message."""
        cp = self.get(checkpoint_id)
        if cp is None:
            return None
        cp.status = CheckpointStatus.failed
        cp.error = error
        return self.save(cp)

    def complete(self, checkpoint_id: str) -> Optional[Checkpoint]:
        """Mark a checkpoint as completed."""
        cp = self.get(checkpoint_id)
        if cp is None:
            return None
        cp.status = CheckpointStatus.completed
        cp.error = None
        return self.save(cp)

    def cleanup(self, team: str, keep_latest: int = 3) -> int:
        """Remove old checkpoints for a team, keeping the N most recent.

        Returns the number of checkpoints removed.
        """
        team_dir = self._team_dir(team)
        if not team_dir.exists():
            return 0

        checkpoints: list[tuple[Path, Checkpoint]] = []
        for json_file in team_dir.glob("*.json"):
            cp = self._load_file(json_file)
            if cp is not None:
                checkpoints.append((json_file, cp))

        # Sort by updated_at descending so we keep the newest
        checkpoints.sort(key=lambda x: x[1].updated_at, reverse=True)

        removed = 0
        for path, _cp in checkpoints[keep_latest:]:
            path.unlink()
            removed += 1

        # Remove team directory if empty
        try:
            if team_dir.exists() and not any(team_dir.iterdir()):
                team_dir.rmdir()
        except OSError:
            pass

        return removed


def get_checkpoint_store(base_dir: Optional[str] = None) -> CheckpointStore:
    """Factory — return a CheckpointStore rooted at the project data directory.

    Uses CLAWTEAM_DATA_DIR env var, falling back to ``~/.superagent``.
    """
    if base_dir is None:
        base_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    return CheckpointStore(base_dir)
