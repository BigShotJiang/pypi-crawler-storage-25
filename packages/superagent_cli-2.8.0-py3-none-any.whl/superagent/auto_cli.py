"""SuperAgent auto command — one sentence to full team automation.

Integrates Hooks (lifecycle events) and Sub-Agents (specialized delegation)
inspired by CodeBuddy Code's architecture.

Hook lifecycle in auto flow:
  SessionStart → UserPromptSubmit → [per-agent: PreToolUse → PostToolUse → SubagentStop] → Stop → SessionEnd

Sub-Agent integration:
  Each worker is matched against the SubAgentRegistry — if a matching sub-agent
  exists, its system prompt and tool whitelist are prepended to the worker's prompt.
"""

from __future__ import annotations

import logging
import os
import subprocess
import sys
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, TextColumn
from rich.table import Table

from superagent.orchestrator import (
    PermissionLevel,
    detect_category,
    generate_toml,
    plan_team,
    save_toml,
)

logger = logging.getLogger(__name__)
console = Console()


def _notify_hook(message: str, detail: str = "") -> None:
    """Trigger a Notification hook with a status message."""
    try:
        from superagent.hooks import trigger_hooks, HookEvent
        trigger_hooks(HookEvent.NOTIFICATION, tool_input={"message": message, "detail": detail})
    except Exception:
        pass


def _compress_plan(plan_text: str, max_chars: int = 3000) -> str:
    """Compress a leader's plan output for worker consumption.
    
    Inspired by Hermes Agent's context_compressor.py — protects key info
    while trimming verbose content to fit token budgets.
    """
    if len(plan_text) <= max_chars:
        return plan_text
    
    lines = plan_text.split("\n")
    
    # Keep headers and key structural lines
    important = []
    other = []
    for line in lines:
        stripped = line.strip()
        if (stripped.startswith("#") or stripped.startswith("-") or 
            stripped.startswith("*") or ":" in stripped[:50] or
            any(kw in stripped.lower() for kw in ["file", "create", "implement", "task", "agent"])):
            important.append(line)
        else:
            other.append(line)
    
    # Build compressed version: all important lines + truncated others
    result = "\n".join(important)
    if len(result) < max_chars and other:
        remaining = max_chars - len(result) - 100
        other_text = "\n".join(other)[:remaining]
        result += "\n" + other_text
    
    return result[:max_chars] + "\n\n[... plan truncated for token efficiency]"

def auto_command(
    goal: str = typer.Argument(..., help="Project goal (one sentence describing what to build)."),
    team_name: Optional[str] = typer.Option(None, "--team", "-t", help="Team name (auto-generated if not specified)."),
    max_agents: int = typer.Option(4, "--max-agents", "-m", help="Maximum number of agents including leader."),
    command: str = typer.Option("claude", "--command", "-c", help="CLI agent command (claude, codex, builtin, local, hermes)."),
    backend: str = typer.Option("tmux", "--backend", "-b", help="Backend: tmux or subprocess."),
    workspace: bool = typer.Option(True, "--workspace/--no-workspace", "-w", help="Create isolated git worktrees."),
    dry_run: bool = typer.Option(False, "--dry-run", help="Show the plan and generated TOML without launching."),
    json_out: bool = typer.Option(False, "--json", help="Output plan as JSON."),
    smart: bool = typer.Option(False, "--smart", "-s", help="Use LLM to analyze goal and dynamically compose the team."),
    dashboard: bool = typer.Option(False, "--dashboard", "-d", help="Open live dashboard in browser during execution."),
    parallel: bool = typer.Option(True, "--parallel/--no-parallel", help="Execute workers in parallel (Mythos pattern)."),
    synthesis: bool = typer.Option(True, "--synthesis/--no-synthesis", help="Run leader synthesis review after workers complete."),
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help="LLM provider for Smart Orchestrator (default: from llm config)."),
):
    """One sentence to full team automation.

    Analyzes your goal, selects the best agent roles, generates a team template,
    and launches the full team with task dependencies.

    Examples:\n      superagent auto "Build a todo app with auth and React frontend"
      superagent auto "赚100美金" --smart --command builtin
      superagent auto "Analyze sales data" --max-agents 3 --dashboard
      superagent auto "Build a mobile app" --dry-run
    """
    # Step 0a: Trigger SessionStart hooks
    from superagent.hooks import trigger_hooks, HookEvent
    trigger_hooks(HookEvent.SESSION_START, tool_input={"goal": goal, "command": command})

    try:
        return _auto_command_inner(goal, team_name, max_agents, command, backend,
                                   workspace, dry_run, json_out, smart, dashboard,
                                   parallel, synthesis, provider)
    finally:
        # Step final: Trigger SessionEnd hooks
        trigger_hooks(HookEvent.SESSION_END, tool_input={"goal": goal})


def _auto_command_inner(goal, team_name, max_agents, command, backend,
                        workspace, dry_run, json_out, smart, dashboard,
                        parallel, synthesis, provider):
    """Inner implementation of auto_command, wrapped by SessionStart/End hooks."""
    # Step 0: Safety check — run guardrail on user goal
    try:
        from superagent.guardrails import get_guardrail_engine
        guard_result = get_guardrail_engine().check_input(goal)
        if not guard_result.passed:
            blocked = [v for v in guard_result.violations if v["action"] == "block"]
            if blocked:
                console.print("[red]Goal blocked by safety guardrails:[/red]")
                for v in blocked:
                    console.print(f"  - Rule '{v['rule_name']}': matched '{v['matched_text']}'")
                raise typer.Exit(1)
            for v in guard_result.violations:
                if v["action"] == "warn":
                    console.print(f"[yellow]Warning: rule '{v['rule_name']}' matched in goal[/yellow]")
    except ImportError:
        pass

    # Step 0b: Trigger UserPromptSubmit hooks (after guardrails, before processing)
    from superagent.hooks import trigger_hooks, should_block, HookEvent
    hook_results = trigger_hooks(HookEvent.USER_PROMPT_SUBMIT, tool_input={"goal": goal})
    blocked, block_reason = False, ""
    for hr in hook_results:
        if hr.decision == "block":
            blocked, block_reason = True, hr.reason
            break
    if blocked:
        console.print(f"[red]Goal blocked by hook:[/red] {block_reason}")
        raise typer.Exit(1)

    # Step 1: Detect category
    category = detect_category(goal)
    console.print(f"\n[bold]Goal:[/bold] {goal}")
    if smart:
        console.print("[bold]Mode:[/bold] [magenta]Smart (LLM-powered team planning)[/magenta]")
    console.print(f"[bold]Category:[/bold] [cyan]{category}[/cyan]\n")

    # If --provider given, temporarily set as default for this run
    if provider:
        from superagent.llm_gateway import get_llm_gateway
        gw = get_llm_gateway()
        if not gw.get_provider(provider):
            console.print(f"[red]Provider '{provider}' not found. Run `superagent llm list` to see available providers.[/red]")
            raise typer.Exit(1)
        gw.set_default(provider)
        console.print(f"[dim]Using LLM provider: {provider}[/dim]")

    # Step 2: Plan the team
    plan = plan_team(goal, max_agents=max_agents, team_name=team_name, use_llm=smart)

    # Step 3: Display the plan
    table = Table(title=f"Team: {plan.team_name}", show_lines=True)
    table.add_column("Agent", style="bold")
    table.add_column("Role", style="cyan")
    table.add_column("Type")

    table.add_row(
        plan.leader.name,
        plan.leader.role,
        "[yellow]Leader[/yellow]",
    )
    for w in plan.workers:
        table.add_row(w.name, w.role, "Worker")

    console.print(table)
    console.print()

    # Step 4: Generate TOML
    toml_content = generate_toml(plan, command=command)

    if json_out:
        import json
        data = {
            "goal": plan.goal,
            "team_name": plan.team_name,
            "category": category,
            "leader": {"name": plan.leader.name, "role": plan.leader.role},
            "workers": [{"name": w.name, "role": w.role} for w in plan.workers],
        }
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if dry_run:
        if command == "builtin":
            console.print(Panel(
                f"[bold]Builtin engine[/bold] would execute {len(plan.all_agents)} agents directly (no TOML / tmux).",
                title="Dry Run — Builtin Mode",
                border_style="dim",
            ))
        elif command == "local":
            console.print(Panel(
                f"[bold]Local backend[/bold] would execute {len(plan.all_agents)} agents via Ollama/LocalAI (no TOML / tmux).",
                title="Dry Run — Local Mode",
                border_style="dim",
            ))
        elif command == "oh":
            console.print(Panel(
                f"[bold]OpenHarness[/bold] would execute {len(plan.all_agents)} agents with full agent loop (43+ tools).",
                title="Dry Run — OpenHarness Mode",
                border_style="dim",
            ))
        elif command == "hermes":
            console.print(Panel(
                f"[bold]Hermes Agent[/bold] would execute {len(plan.all_agents)} agents with full tool-calling loop (55+ tools).",
                title="Dry Run — Hermes Mode",
                border_style="dim",
            ))
        else:
            console.print(Panel(toml_content, title="Generated TOML Template", border_style="dim"))
        console.print("[dim]Dry run — no agents launched. Remove --dry-run to execute.[/dim]")
        return

    # Step 5: Execute
    if command == "builtin":
        # Direct execution via deerflow_engine — no TOML, no tmux
        output_dir = os.path.join(os.getcwd(), ".superagent", "auto", plan.team_name)
        _execute_builtin(goal, plan, output_dir, dashboard=dashboard, parallel=parallel, synthesis=synthesis)
        return

    if command == "local":
        # Direct execution via local backend (Ollama/LocalAI/llama.cpp)
        output_dir = os.path.join(os.getcwd(), ".superagent", "auto", plan.team_name)
        _execute_local(goal, plan, output_dir, dashboard=dashboard, parallel=parallel, synthesis=synthesis)
        return

    if command == "oh":
        # OpenHarness agent loop — each worker gets full tool-use cycle
        output_dir = os.path.join(os.getcwd(), ".superagent", "auto", plan.team_name)
        _execute_openharness(goal, plan, output_dir, dashboard=dashboard)
        return

    if command == "hermes":
        # Hermes Agent — full tool-calling loop with 55+ tools
        from superagent.hermes_engine import execute_team_hermes
        output_dir = os.path.join(os.getcwd(), ".superagent", "auto", plan.team_name)
        execute_team_hermes(goal, plan, output_dir, dashboard=dashboard, parallel=parallel, synthesis=synthesis)
        return

    # --- Existing path: generate TOML + launch via tmux ---
    toml_path = save_toml(toml_content, plan)
    console.print(f"[dim]Template saved: {toml_path}[/dim]\n")

    # Step 6: Launch via ClawTeam's launch command (use template name, not path)
    launch_cmd = [
        sys.executable, "-m", "superagent",
        "launch", plan.team_name,
        "--team", plan.team_name,
        "--goal", goal,
        "--backend", backend,
    ]
    if workspace:
        launch_cmd.append("--workspace")

    console.print(f"[bold green]Launching team '{plan.team_name}' with {len(plan.all_agents)} agents...[/bold green]\n")
    console.print(f"[dim]$ {' '.join(launch_cmd)}[/dim]\n")

    try:
        result = subprocess.run(launch_cmd, cwd=os.getcwd())
        if result.returncode == 0:
            console.print(f"\n[bold green]Team '{plan.team_name}' launched successfully![/bold green]")
            console.print(f"\nMonitor: [cyan]superagent board live {plan.team_name}[/cyan]")
            console.print(f"Attach:  [cyan]superagent board attach {plan.team_name}[/cyan]")
            console.print(f"Status:  [cyan]superagent team status {plan.team_name}[/cyan]")
        else:
            console.print(f"\n[red]Launch failed with exit code {result.returncode}[/red]")
            console.print(f"Template at: {toml_path}")
            console.print(f"Try manually: [cyan]superagent launch {toml_path} --team {plan.team_name} --goal \"{goal}\"[/cyan]")
    except KeyboardInterrupt:
        console.print("\n[yellow]Launch interrupted.[/yellow]")
    except Exception as e:
        console.print(f"\n[red]Error: {e}[/red]")
        console.print(f"Template saved at: {toml_path}")
        console.print(f"Try manually: [cyan]superagent launch {toml_path} --team {plan.team_name} --goal \"{goal}\"[/cyan]")


def _poll_injections(team_name: str) -> list[dict]:
    """Poll for pending user-injected directives and mark them as processed.

    Returns a list of directive dicts sorted by priority (urgent > high > normal).
    """
    import json

    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    inject_dir = os.path.join(data_dir, "teams", team_name, "injections")

    if not os.path.isdir(inject_dir):
        return []

    directives = []
    priority_order = {"urgent": 0, "high": 1, "normal": 2}

    for f in sorted(os.listdir(inject_dir)):
        if not f.endswith(".json"):
            continue
        path = os.path.join(inject_dir, f)
        try:
            data = json.loads(open(path, encoding="utf-8").read())
            if data.get("status") != "pending":
                continue
            directives.append(data)
            # Mark as processed
            data["status"] = "processed"
            from superagent.file_util import atomic_write
            atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))
        except (json.JSONDecodeError, OSError):
            continue

    directives.sort(key=lambda d: priority_order.get(d.get("priority", "normal"), 2))
    return directives


def _execute_builtin(goal: str, plan, output_dir: str, dashboard: bool = False,
                     parallel: bool = True, synthesis: bool = True) -> None:
    """Execute the team plan via the built-in engine.

    Mythos patterns:
    - Workers run in parallel via asyncio.gather (parallel=True)
    - Leader reviews all worker output for completeness (synthesis=True)

    Hooks integration (CodeBuddy-inspired):
    - PreToolUse/PostToolUse around each execute_task call
    - SubagentStop after each worker completes
    - Stop when all execution finishes

    Sub-Agent integration (CodeBuddy-inspired):
    - Each worker is matched against SubAgentRegistry
    - Matching sub-agent's prompt and tools enhance the worker
    """
    import asyncio

    from superagent.deerflow_engine import execute_task, execute_task_async
    from superagent.hooks import trigger_hooks, should_block, HookEvent
    from superagent.subagent import get_subagent_registry

    os.makedirs(output_dir, exist_ok=True)
    agents = plan.all_agents  # leader + workers

    # --- Dashboard live mode ---
    dash_proc = None
    dash_agents: list[dict] = []
    if dashboard:
        dash_agents = [
            {"name": a.name, "role": a.role, "status": "pending", "detail": "Waiting..."}
            for a in agents
        ]
        dash_proc = _start_dashboard(plan.team_name, dash_agents)

    mode_label = "parallel" if parallel else "sequential"
    console.print(f"\n[bold green]Executing team '{plan.team_name}' via built-in engine "
                  f"({len(agents)} agents, {mode_label})...[/bold green]\n")

    results: list[dict] = []
    leader_output = ""

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # --- Leader: planning phase ---
        leader = plan.leader
        leader_dir = os.path.join(output_dir, leader.name)
        tid = progress.add_task(f"[yellow]Leader[/yellow] {leader.name} ({leader.role}) — planning", total=None)

        leader_prompt = (
            f"You are the Team Leader ({leader.role}) planning a software project.\n\n"
            f"## Project Goal\n{goal}\n\n"
            f"## Your Team\n"
            + "\n".join(f"- **{w.name}** ({w.role})" for w in plan.workers)
            + "\n\n## Instructions\n"
            "Create a DETAILED execution plan with:\n"
            "1. Project architecture overview\n"
            "2. For EACH worker, specify:\n"
            "   - Exact files to create (with full paths)\n"
            "   - What each file should contain\n"
            "   - Dependencies between files\n"
            "   - Acceptance criteria\n"
            "3. File naming conventions\n"
            "4. Technology choices with brief rationale\n\n"
            "Be specific \u2014 your workers will follow this plan exactly."
        )
        if leader.task:
            leader_prompt += f"\n\n## Additional Context\n{leader.task}"

        # Moxt pattern: Inject leader's accumulated experience
        try:
            from superagent.agent_profile import get_profile_store
            leader_profile = get_profile_store().get(plan.leader.name)
            if leader_profile and leader_profile.experience_level != "novice":
                leader_prompt += f"\n\n## Your Experience\n{leader_profile.get_context_prompt()}"
        except Exception as e:
            logger.debug("Leader profile context failed: %s", e)

        # --- Hook: PreToolUse (leader execution) ---
        blocked, block_reason = should_block(
            HookEvent.PRE_TOOL_USE,
            tool_name="execute_task",
            tool_input={"agent": leader.name, "role": leader.role, "type": "leader"},
        )
        if blocked:
            leader_result = {"success": False, "error": f"Blocked by hook: {block_reason}",
                             "output": "", "files_created": [], "engine": "blocked"}
            console.print(f"[red]Leader blocked by hook: {block_reason}[/red]")
        else:
            leader_result = execute_task(leader_prompt, working_dir=leader_dir)
            # --- Hook: PostToolUse (leader execution) ---
            trigger_hooks(
                HookEvent.POST_TOOL_USE,
                tool_name="execute_task",
                tool_input={"agent": leader.name, "role": leader.role, "type": "leader"},
            )

        leader_output = leader_result.get("output", "")
        results.append({"agent": leader.name, "role": leader.role, "type": "leader", **leader_result})

        if leader_result.get("success"):
            progress.update(tid, description=f"[green]Leader[/green] {leader.name} — done")
            _notify_hook(f"Leader {leader.name} completed planning", detail=leader.role)
        else:
            progress.update(tid, description=f"[red]Leader[/red] {leader.name} — failed")
            _notify_hook(f"Leader {leader.name} failed", detail=leader_result.get("error", "")[:200])
            console.print(f"[red]Leader failed: {leader_result.get('error')}[/red]")

        if dashboard and dash_agents:
            s = "done" if leader_result.get("success") else "failed"
            dash_agents[0]["status"] = s
            dash_agents[0]["detail"] = "Plan created" if s == "done" else "Failed"
            _update_dashboard(plan.team_name, dash_agents)

        # ============================================================
        # Phase 2: Workers (parallel or sequential, Mythos pattern)
        # ============================================================
        worker_prompts: list[tuple[int, str, str, list[str]]] = []

        # --- Moxt pattern: Load shared corrections for all workers ---
        corrections_block = ""
        try:
            from superagent.corrections import get_correction_store
            corrections_block = get_correction_store().get_prompt_block(limit=10)
        except Exception as e:
            logger.debug("Corrections load failed: %s", e)

        for wi, worker in enumerate(plan.workers):
            worker_dir = os.path.join(output_dir, worker.name)
            os.makedirs(worker_dir, exist_ok=True)

            wp = f"You are **{worker.name}** ({worker.role}), an expert.\n\n"
            if worker.permission_level == PermissionLevel.PLAN:
                wp += "## Permission Mode: PLAN\nAnalyze and plan only, do NOT create files.\n\n"
            elif worker.permission_level == PermissionLevel.REVIEW:
                wp += "## Permission Mode: REVIEW\nReview and report issues, do NOT modify files.\n\n"
            elif worker.permission_level == PermissionLevel.EXPLORE:
                wp += "## Permission Mode: EXPLORE\nSearch and read only.\n\n"
            wp += (
                f"## Project Goal\n{goal}\n\n"
                f"## Leader's Plan\n{_compress_plan(leader_output)}\n\n"
                f"## Your Assignment\n{worker.task or 'Implement your part of the project'}\n\n"
                "## Requirements\n"
                "- Write COMPLETE, PRODUCTION-QUALITY code\n"
                "- Include error handling and input validation\n"
                "- Add comments for complex logic\n"
                "- Follow best practices for the language/framework\n"
                "- Create ALL files needed for your part to work\n\n"
                "Output files using ===FILE: path=== format."
                + corrections_block
            )
            if getattr(worker, "role_template", None):
                wp = f"## Your Expertise\n{worker.role_template}\n\n" + wp

            # --- Sub-Agent integration: enhance worker prompt with matching sub-agent ---
            worker_tools_whitelist: list[str] = []
            try:
                sa_registry = get_subagent_registry()
                matching_agent = sa_registry.delegate(worker.task or worker.role)
                if matching_agent:
                    # Prepend sub-agent's specialized system prompt
                    wp = f"## Specialized Agent Profile: {matching_agent.name}\n{matching_agent.prompt}\n\n---\n\n" + wp
                    if matching_agent.tools:
                        worker_tools_whitelist = matching_agent.tools
                        wp += f"\n\n## Allowed Tools (restricted by sub-agent '{matching_agent.name}')\n"
                        wp += "You may only use these tools: " + ", ".join(matching_agent.tools) + "\n"
                    logger.info("Worker %s matched sub-agent %s", worker.name, matching_agent.name)
            except Exception as e:
                logger.debug("Sub-agent delegation failed for worker %s: %s", worker.name, e)

            worker_prompts.append((wi, worker.name, wp, worker_tools_whitelist))

        if parallel and len(plan.workers) > 1:
            # --- Parallel execution (Mythos pattern) ---
            progress_ids: dict[str, int] = {}
            for wi, worker in enumerate(plan.workers):
                pid = progress.add_task(
                    f"[cyan]Worker[/cyan] {worker.name} ({worker.role}) \u2014 parallel", total=None)
                progress_ids[worker.name] = pid

            if dashboard and dash_agents:
                for wi in range(len(plan.workers)):
                    dash_agents[wi + 1]["status"] = "executing"
                    dash_agents[wi + 1]["detail"] = f"Working: {plan.workers[wi].task or plan.workers[wi].role}"[:60]
                _update_dashboard(plan.team_name, dash_agents)

            async def _run_all_workers():
                tasks = []
                for _wi, _name, _prompt, _tools in worker_prompts:
                    # --- Hook: PreToolUse (worker execution) ---
                    w_blocked, _ = should_block(
                        HookEvent.PRE_TOOL_USE,
                        tool_name="execute_task",
                        tool_input={"agent": _name, "type": "worker"},
                    )
                    wdir = os.path.join(output_dir, _name)
                    if w_blocked:
                        # Return a blocked result instead of executing
                        async def _blocked_result(name=_name):
                            return {"success": False, "error": "Blocked by hook",
                                    "output": "", "files_created": [], "engine": "blocked"}
                        tasks.append(_blocked_result())
                    else:
                        tasks.append(execute_task_async(_prompt, working_dir=wdir))
                return await asyncio.gather(*tasks, return_exceptions=True)

            worker_results = asyncio.run(_run_all_workers())

            for (wi, name, _, _tools), wr in zip(worker_prompts, worker_results):
                worker = plan.workers[wi]
                if isinstance(wr, Exception):
                    wr = {"success": False, "error": str(wr), "output": "", "files_created": [], "engine": "error"}
                results.append({"agent": name, "role": worker.role, "type": "worker", **wr})
                pid = progress_ids[name]
                if wr.get("success"):
                    progress.update(pid, description=f"[green]Worker[/green] {name} \u2014 done")
                else:
                    progress.update(pid, description=f"[red]Worker[/red] {name} \u2014 failed")
                if dashboard and dash_agents:
                    dash_agents[wi + 1]["status"] = "done" if wr.get("success") else "failed"
                    _update_dashboard(plan.team_name, dash_agents)
                # --- Hook: PostToolUse + SubagentStop ---
                trigger_hooks(
                    HookEvent.POST_TOOL_USE,
                    tool_name="execute_task",
                    tool_input={"agent": name, "role": worker.role, "type": "worker",
                                "success": wr.get("success", False)},
                )
                trigger_hooks(
                    HookEvent.SUBAGENT_STOP,
                    tool_name=name,
                    tool_input={"agent": name, "role": worker.role, "success": wr.get("success", False)},
                )
                _auto_capture_memory(name, worker.role, wr, plan.team_name)
        else:
            # --- Sequential execution ---
            for wi, name, prompt, _tools in worker_prompts:
                worker = plan.workers[wi]
                wid = progress.add_task(f"Worker {name} ({worker.role})", total=None)
                if dashboard and dash_agents:
                    dash_agents[wi + 1]["status"] = "executing"
                    _update_dashboard(plan.team_name, dash_agents)

                # --- Hook: PreToolUse (worker execution) ---
                w_blocked, w_block_reason = should_block(
                    HookEvent.PRE_TOOL_USE,
                    tool_name="execute_task",
                    tool_input={"agent": name, "role": worker.role, "type": "worker"},
                )
                if w_blocked:
                    wr = {"success": False, "error": f"Blocked by hook: {w_block_reason}",
                          "output": "", "files_created": [], "engine": "blocked"}
                else:
                    wr = execute_task(prompt, working_dir=os.path.join(output_dir, name))

                results.append({"agent": name, "role": worker.role, "type": "worker", **wr})
                if wr.get("success"):
                    progress.update(wid, description=f"[green]Worker[/green] {name} \u2014 done")
                else:
                    progress.update(wid, description=f"[red]Worker[/red] {name} \u2014 failed")
                if dashboard and dash_agents:
                    dash_agents[wi + 1]["status"] = "done" if wr.get("success") else "failed"
                    _update_dashboard(plan.team_name, dash_agents)
                # --- Hook: PostToolUse + SubagentStop ---
                trigger_hooks(
                    HookEvent.POST_TOOL_USE,
                    tool_name="execute_task",
                    tool_input={"agent": name, "role": worker.role, "type": "worker",
                                "success": wr.get("success", False)},
                )
                trigger_hooks(
                    HookEvent.SUBAGENT_STOP,
                    tool_name=name,
                    tool_input={"agent": name, "role": worker.role, "success": wr.get("success", False)},
                )
                _auto_capture_memory(name, worker.role, wr, plan.team_name)

        # ============================================================
        # Phase 3: Synthesis \u2014 Leader reviews all outputs (Mythos)
        # ============================================================
        synthesis_output = ""
        if synthesis and leader_result.get("success"):
            sid = progress.add_task("[magenta]Synthesis[/magenta] \u2014 Leader reviewing outputs", total=None)
            if dashboard and dash_agents:
                dash_agents[0]["status"] = "executing"
                dash_agents[0]["detail"] = "Reviewing worker outputs..."
                _update_dashboard(plan.team_name, dash_agents)

            worker_summaries = []
            for r in results:
                if r.get("type") == "worker":
                    status_s = "OK" if r.get("success") else "FAILED"
                    files_s = ", ".join(r.get("files_created", [])) or "none"
                    out_preview = (r.get("output", "") or "")[:500]
                    worker_summaries.append(
                        f"### {r['agent']} ({r['role']}) \u2014 {status_s}\n"
                        f"Files: {files_s}\nOutput:\n{out_preview}\n"
                    )

            # --- Check for user-injected directives ---
            injected = _poll_injections(plan.team_name)
            injection_context = ""
            if injected:
                console.print(f"\n[bold magenta]Received {len(injected)} user directive(s):[/bold magenta]")
                injection_lines = []
                for inj in injected:
                    prio = inj.get("priority", "normal")
                    msg = inj.get("message", "")
                    console.print(f"  [{prio}] {msg}")
                    injection_lines.append(f"- [{prio.upper()}] {msg}")
                injection_context = (
                    "\n\n## User Directives (received during execution)\n"
                    "The user has sent the following new requirements/instructions while the team was working. "
                    "You MUST incorporate these into your review and recommendations:\n"
                    + "\n".join(injection_lines) + "\n"
                )

            sep = "---\n"
            syn_prompt = (
                f"You are the Team Leader reviewing your team's completed work.\n\n"
                f"## Original Goal\n{goal}\n\n"
                f"## Your Plan\n{_compress_plan(leader_output)}\n\n"
                f"## Worker Outputs\n{sep.join(worker_summaries)}\n\n"
                f"{injection_context}"
                "## Review Task\n"
                "1. Evaluate completeness: did the team achieve the goal?\n"
                "2. Identify gaps, contradictions, or missing pieces\n"
                "3. Assess quality of each worker's output\n"
                "4. Provide a final summary and next steps\n\nBe concise."
            )
            syn_result = execute_task(syn_prompt, working_dir=os.path.join(output_dir, "synthesis"))
            synthesis_output = syn_result.get("output", "")
            results.append({"agent": leader.name, "role": "Synthesis", "type": "synthesis", **syn_result})

            if syn_result.get("success"):
                progress.update(sid, description="[green]Synthesis[/green] \u2014 review complete")
            else:
                progress.update(sid, description="[yellow]Synthesis[/yellow] \u2014 skipped")
            if dashboard and dash_agents:
                dash_agents[0]["status"] = "done"
                _update_dashboard(plan.team_name, dash_agents)

    # Stop dashboard
    if dashboard and dash_proc:
        _stop_dashboard(dash_proc)

    # --- Hook: Stop (all execution complete) ---
    trigger_hooks(
        HookEvent.STOP,
        tool_input={"goal": goal, "team": plan.team_name,
                     "results_count": len(results),
                     "success_count": sum(1 for r in results if r.get("success"))},
    )

    # --- Summary ---
    console.print()
    summary_table = Table(title=f"Builtin Execution Results — {plan.team_name}", show_lines=True)
    summary_table.add_column("Agent", style="bold")
    summary_table.add_column("Role", style="cyan")
    summary_table.add_column("Status")
    summary_table.add_column("Files Created")
    summary_table.add_column("Engine", style="dim")

    for r in results:
        status = "[green]OK[/green]" if r.get("success") else f"[red]FAIL: {r.get('error', '?')}[/red]"
        files = ", ".join(r.get("files_created", [])) or "—"
        summary_table.add_row(r["agent"], r["role"], status, files, r.get("engine", "—"))

    console.print(summary_table)

    if synthesis and synthesis_output:
        console.print()
        console.print(Panel(synthesis_output[:2000], title="Synthesis Review", border_style="magenta"))

    console.print(f"\n[dim]Output directory: {output_dir}[/dim]")

    # --- Moxt pattern: Update agent profiles with execution results ---
    try:
        from superagent.agent_profile import get_profile_store
        profiles = get_profile_store()
        for r in results:
            if r.get("type") == "synthesis":
                continue
            p = profiles.get_or_create(r["agent"], role=r.get("role", ""))
            p.record_execution(
                task=goal[:200],
                success=r.get("success", False),
                files_created=len(r.get("files_created", [])),
                domain=plan.template_name,
            )
            profiles.save(p)
    except Exception as e:
        logger.debug("Agent profile update failed: %s", e)

    # Write a summary JSON for tooling / downstream use
    import json
    summary_path = os.path.join(output_dir, "execution_summary.json")
    Path(summary_path).write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    console.print(f"[dim]Summary written: {summary_path}[/dim]")

    # Hermes learning loop: auto-create skills from execution
    _auto_learn_from_execution(goal, plan, results)


def _auto_capture_memory(agent_name: str, role: str, result: dict, team_name: str) -> None:
    """Auto-capture successful work to team memory."""
    try:
        from superagent.memory import get_memory_store
        mem_store = get_memory_store()
        if result.get("success") and result.get("files_created"):
            mem_store.write(
                f"Agent {agent_name} ({role}) created: {', '.join(result['files_created'][:5])}",
                tags=["auto-capture", role.lower().replace(" ", "-")],
                scope="team", team_name=team_name,
            )
    except Exception as e:
        logger.debug("Auto-capture memory failed for agent %s: %s", agent_name, e)
# ---------------------------------------------------------------------------

_MEMORY_CURATION_LIMIT = 3575  # Hermes pattern: force quality over quantity


def _auto_learn_from_execution(goal: str, plan, results: list[dict]) -> None:
    """Analyze execution results and auto-create/improve skills.

    Hermes patterns:
    - Auto-create skills from successful complex tasks (5+ files created)
    - Record failure patterns for future avoidance
    - Enforce memory curation limit (3575 chars)
    """
    try:
        from superagent.evolution import SkillRecord, get_skill_store
    except ImportError:
        return

    store = get_skill_store()
    now = datetime.now(timezone.utc).isoformat()

    successful_agents = [r for r in results if r.get("success") and r.get("type") != "synthesis"]
    failed_agents = [r for r in results if not r.get("success") and r.get("type") != "synthesis"]
    total_files = sum(len(r.get("files_created", [])) for r in successful_agents)

    # --- Auto-create skill from complex successful execution ---
    if total_files >= 5 and len(successful_agents) >= 2:
        skill_name = f"auto-{plan.template_name}-{plan.team_name[:8]}"
        existing = store.get(skill_name)

        if existing:
            # Patch: increment success count
            existing.success_count += 1
            existing.last_used = now
            store.save(existing)
            console.print(f"[dim]Skill '{skill_name}' improved (success #{existing.success_count})[/dim]")
        else:
            # Create new skill
            roles = ", ".join(f"{r['agent']}({r['role']})" for r in successful_agents)
            skill = SkillRecord(
                name=skill_name,
                description=f"Auto-learned: {goal[:100]}. Team: {roles}. Files: {total_files}.",
                category=plan.template_name,
                success_count=1,
                last_used=now,
            )
            store.save(skill)
            console.print(f"[dim]New skill auto-created: '{skill_name}' (Hermes learning loop)[/dim]")

    # --- Record failure patterns ---
    for r in failed_agents:
        skill_name = f"fail-{r['agent']}-{plan.team_name[:6]}"
        existing = store.get(skill_name)
        if existing:
            existing.failure_count += 1
            existing.last_error = r.get("error", "")[:200]
            existing.last_used = now
            store.save(existing)
        else:
            store.save(SkillRecord(
                name=skill_name,
                description=f"Failure pattern: {r.get('error', 'unknown')[:150]}",
                category="failure-pattern",
                failure_count=1,
                last_error=r.get("error", "")[:200],
                last_used=now,
                status="fixing",
            ))

    # --- Curate team memory (enforce 3575 char limit, Hermes pattern) ---
    try:
        from superagent.memory import MemoryScope, get_memory_store
        mem = get_memory_store()
        team_memories = mem.search("", scope=MemoryScope.team, team_name=plan.team_name, limit=50)
        total_chars = sum(len(m.content) for m in team_memories)
        if total_chars > _MEMORY_CURATION_LIMIT:
            # Remove oldest low-value memories to stay under limit
            sorted_mems = sorted(team_memories, key=lambda m: m.created_at)
            while total_chars > _MEMORY_CURATION_LIMIT and sorted_mems:
                oldest = sorted_mems.pop(0)
                mem.delete(oldest.id)
                total_chars -= len(oldest.content)
    except Exception as e:
        logger.debug("Memory curation failed: %s", e)


def _execute_openharness(goal: str, plan, output_dir: str, *, dashboard: bool = False) -> None:
    """Execute via OpenHarness agent loop (each worker gets full tool-use cycle).

    Requires ``pip install openharness-ai``.  Each agent runs in a streaming
    tool-call loop (stream -> tool -> permission -> execute -> loop) with
    access to 43+ tools.
    """
    try:
        _oh_available = True
        # Check if openharness is installed
        import importlib
        importlib.import_module("openharness")
    except ImportError:
        _oh_available = False

    if not _oh_available:
        console.print(
            "[red]OpenHarness not installed.[/red]\n"
            "  Install: [cyan]pip install openharness-ai[/cyan]\n"
            "  Then retry: [cyan]superagent auto \"goal\" --command oh[/cyan]"
        )
        raise typer.Exit(1)

    os.makedirs(output_dir, exist_ok=True)
    agents = plan.all_agents

    console.print(f"\n[bold green]Executing team '{plan.team_name}' via OpenHarness "
                  f"({len(agents)} agents, agent-loop mode)...[/bold green]\n")

    results: list[dict] = []

    for agent in agents:
        agent_dir = os.path.join(output_dir, agent.name)
        os.makedirs(agent_dir, exist_ok=True)
        agent_type = "Leader" if agent == plan.leader else "Worker"
        console.print(f"  [{('yellow' if agent_type == 'Leader' else 'cyan')}]{agent_type}[/] "
                      f"{agent.name} ({agent.role})")

        prompt = (
            f"You are {agent.name} ({agent.role}) working on: {goal}\n"
            f"{'Create a detailed plan for the team.' if agent_type == 'Leader' else agent.task or 'Implement your part.'}\n"
            f"Working directory: {agent_dir}"
        )

        try:
            # Use oh CLI in non-interactive mode
            cmd = [
                sys.executable, "-m", "openharness",
                "-p", prompt,
                "--output-format", "json",
                "--permission-mode", "auto",
            ]
            result = subprocess.run(
                cmd, capture_output=True, text=True, cwd=agent_dir, timeout=300,
            )
            import json as _json
            try:
                output_data = _json.loads(result.stdout) if result.stdout else {}
            except (ValueError, _json.JSONDecodeError):
                output_data = {"output": result.stdout}

            success = result.returncode == 0
            results.append({
                "agent": agent.name, "role": agent.role, "type": agent_type.lower(),
                "success": success, "output": output_data.get("result", result.stdout[:2000]),
                "files_created": [], "engine": "openharness",
                "error": result.stderr[:500] if not success else None,
            })
            status = "[green]OK[/green]" if success else "[red]FAIL[/red]"
            console.print(f"    {status}")

        except subprocess.TimeoutExpired:
            results.append({
                "agent": agent.name, "role": agent.role, "type": agent_type.lower(),
                "success": False, "output": "", "files_created": [],
                "engine": "openharness", "error": "Timeout after 300s",
            })
            console.print("    [red]TIMEOUT[/red]")
        except Exception as exc:
            results.append({
                "agent": agent.name, "role": agent.role, "type": agent_type.lower(),
                "success": False, "output": "", "files_created": [],
                "engine": "openharness", "error": str(exc),
            })
            console.print(f"    [red]ERROR: {exc}[/red]")

    # --- Summary ---
    console.print()
    summary_table = Table(title=f"OpenHarness Results \u2014 {plan.team_name}", show_lines=True)
    summary_table.add_column("Agent", style="bold")
    summary_table.add_column("Role", style="cyan")
    summary_table.add_column("Status")
    summary_table.add_column("Engine", style="dim")

    for r in results:
        status = "[green]OK[/green]" if r.get("success") else "[red]FAIL[/red]"
        summary_table.add_row(r["agent"], r["role"], status, r.get("engine", "\u2014"))

    console.print(summary_table)
    console.print(f"\n[dim]Output directory: {output_dir}[/dim]")

    # Auto-learn from execution
    _auto_learn_from_execution(goal, plan, results)

    import json
    summary_path = os.path.join(output_dir, "execution_summary.json")
    Path(summary_path).write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    console.print(f"[dim]Summary written: {summary_path}[/dim]")


def _execute_local(goal: str, plan, output_dir: str, dashboard: bool = False,
                   parallel: bool = True, synthesis: bool = True) -> None:
    """Execute the team plan using a local model backend (Ollama/LocalAI/llama.cpp)."""
    from superagent.deerflow_engine import _execute_with_local

    os.makedirs(output_dir, exist_ok=True)
    agents = plan.all_agents  # leader + workers

    console.print(f"\n[bold green]Executing team '{plan.team_name}' via local backend ({len(agents)} agents)...[/bold green]\n")

    results: list[dict] = []
    leader_output = ""

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # --- Leader: planning phase ---
        leader = plan.leader
        leader_dir = os.path.join(output_dir, leader.name)
        tid = progress.add_task(f"[yellow]Leader[/yellow] {leader.name} ({leader.role}) — planning", total=None)

        leader_prompt = (
            f"You are the Team Leader ({leader.role}) for project: {goal}\n\n"
            f"Your team has {len(plan.workers)} workers:\n"
            + "\n".join(f"  - {w.name}: {w.role}" for w in plan.workers)
            + "\n\nCreate a concrete execution plan. "
            "For each worker, specify exact tasks, files to create, and acceptance criteria.\n"
            f"\n{leader.task}" if leader.task else ""
        )

        leader_result = _execute_with_local(leader_prompt, working_dir=leader_dir)
        leader_output = leader_result.get("output", "")
        results.append({"agent": leader.name, "role": leader.role, "type": "leader", **leader_result})

        if leader_result.get("success"):
            progress.update(tid, description=f"[green]Leader[/green] {leader.name} — done")
        else:
            progress.update(tid, description=f"[red]Leader[/red] {leader.name} — failed")
            console.print(f"[red]Leader failed: {leader_result.get('error')}[/red]")

        # --- Workers: execution phase ---
        for worker in plan.workers:
            worker_dir = os.path.join(output_dir, worker.name)
            wid = progress.add_task(f"Worker {worker.name} ({worker.role})", total=None)

            worker_prompt = (
                f"You are {worker.name} ({worker.role}) on a team working on: {goal}\n\n"
                f"The team leader's plan:\n{leader_output}\n\n"
                f"Your specific task:\n{worker.task}\n\n"
                "Implement your part fully. Create all necessary files."
            )

            worker_result = _execute_with_local(worker_prompt, working_dir=worker_dir)
            results.append({"agent": worker.name, "role": worker.role, "type": "worker", **worker_result})

            if worker_result.get("success"):
                progress.update(wid, description=f"[green]Worker[/green] {worker.name} — done")
            else:
                progress.update(wid, description=f"[red]Worker[/red] {worker.name} — failed")

    # --- Summary ---
    console.print()
    summary_table = Table(title=f"Local Execution Results — {plan.team_name}", show_lines=True)
    summary_table.add_column("Agent", style="bold")
    summary_table.add_column("Role", style="cyan")
    summary_table.add_column("Status")
    summary_table.add_column("Files Created")
    summary_table.add_column("Engine", style="dim")

    for r in results:
        status = "[green]OK[/green]" if r.get("success") else f"[red]FAIL: {r.get('error', '?')}[/red]"
        files = ", ".join(r.get("files_created", [])) or "—"
        summary_table.add_row(r["agent"], r["role"], status, files, r.get("engine", "—"))

    console.print(summary_table)
    console.print(f"\n[dim]Output directory: {output_dir}[/dim]")

    # Write a summary JSON for tooling / downstream use
    import json
    summary_path = os.path.join(output_dir, "execution_summary.json")
    Path(summary_path).write_text(json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8")
    console.print(f"[dim]Summary written: {summary_path}[/dim]")


# ---------------------------------------------------------------------------
# Dashboard helpers
# ---------------------------------------------------------------------------


def _update_dashboard(team_name: str, agents: list[dict]) -> None:
    """Push current agent states to the dashboard state files."""
    try:
        from superagent.dashboard import get_dashboard_dir, write_builtin_execution_state
        dashboard_dir = get_dashboard_dir()
        write_builtin_execution_state(team_name, dashboard_dir, agents)
    except Exception as e:
        logger.debug("Dashboard update failed for team %s: %s", team_name, e)


def _start_dashboard(team_name: str, agents: list[dict]) -> subprocess.Popen | None:
    """Start the Flask dashboard backend and open the browser."""
    import webbrowser

    _update_dashboard(team_name, agents)

    try:
        from superagent.dashboard import get_dashboard_dir
        dashboard_dir = get_dashboard_dir()
        backend_script = os.path.join(dashboard_dir, "backend", "app.py")

        if not os.path.isfile(backend_script):
            console.print("[yellow]Dashboard backend not found — skipping live view.[/yellow]")
            return None

        env = os.environ.copy()
        env["STAR_BACKEND_PORT"] = "19000"
        env["STAR_BACKEND_HOST"] = "127.0.0.1"

        proc = subprocess.Popen(
            [sys.executable, backend_script],
            cwd=dashboard_dir,
            env=env,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
        )

        import time
        time.sleep(1.5)

        webbrowser.open("http://127.0.0.1:19000")
        console.print("[bold green]Dashboard opened at http://127.0.0.1:19000[/bold green]\n")
        return proc
    except Exception as exc:
        console.print(f"[yellow]Dashboard failed to start: {exc}[/yellow]")
        return None


def _stop_dashboard(proc: subprocess.Popen | None) -> None:
    """Stop the background dashboard process."""
    if proc is None:
        return
    try:
        proc.terminate()
        proc.wait(timeout=3)
    except Exception as e:
        logger.debug("Failed to terminate dashboard process: %s", e)
        try:
            proc.kill()
        except Exception as e2:
            logger.debug("Failed to kill dashboard process: %s", e2)
