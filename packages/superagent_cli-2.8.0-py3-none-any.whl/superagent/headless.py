"""Headless / Pipe-friendly CLI mode — inspired by CodeBuddy Code's headless mode.

Enables non-interactive usage:
    echo "explain this code" | superagent pipe
    superagent run -p "Analyze the project" --output-format json
    git log --oneline | superagent pipe "Find potential issues"
    cat error.log | superagent pipe "Help me analyze these error logs"

Key features (borrowed from CodeBuddy):
- Pipe-friendly stdin input
- --output-format json/stream-json/text
- --resume / --continue for multi-turn conversations
- Structured JSON output with JSON Schema
- --allowedTools / --disallowedTools for tool control
- --permission-mode for access control
"""

from __future__ import annotations

import asyncio
import json
import sys
from typing import Optional

import typer
from rich.console import Console

console = Console()
pipe_app = typer.Typer(help="Pipe — non-interactive / headless execution mode.")


@pipe_app.command("run")
def pipe_run(
    prompt: str = typer.Argument(..., help="Prompt text, or '-' to read from stdin"),
    output_format: str = typer.Option("text", "--output-format", "-f", help="Output format: text, json, stream-json"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
    allowed_tools: Optional[str] = typer.Option(None, "--allowed-tools", help="Comma-separated allowed tools"),
    permission_mode: str = typer.Option("default", "--permission-mode", help="Permission mode: default, acceptEdits, bypassPermissions, plan"),
    resume: Optional[str] = typer.Option(None, "--resume", "-r", help="Resume session by ID"),
    max_turns: int = typer.Option(20, "--max-turns", help="Maximum conversation turns"),
    json_schema: Optional[str] = typer.Option(None, "--json-schema", help="JSON Schema for structured output"),
    skip_permissions: bool = typer.Option(False, "-y", "--dangerously-skip-permissions", help="Skip all permission checks"),
):
    """Run a prompt in non-interactive (headless) mode."""
    # Read from stdin if prompt is '-'
    if prompt == "-":
        stdin_data = sys.stdin.read()
        if not stdin_data.strip():
            console.print("[red]No input from stdin.[/red]")
            raise typer.Exit(1)
        prompt = stdin_data

    _execute_headless(
        prompt=prompt,
        output_format=output_format,
        model=model,
        allowed_tools=allowed_tools,
        permission_mode=permission_mode,
        resume_session=resume,
        max_turns=max_turns,
        json_schema=json_schema,
        skip_permissions=skip_permissions,
    )


@pipe_app.command("pipe")
def pipe_stdin(
    prompt_prefix: str = typer.Argument("", help="Prompt prefix (stdin content appended)"),
    output_format: str = typer.Option("text", "--output-format", "-f", help="Output format: text, json, stream-json"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
):
    """Pipe-friendly mode: read stdin as context, combine with prompt.

    Usage:
        git log --oneline | superagent pipe "Analyze these commits"
        cat error.log | superagent pipe "Help me analyze errors"
        echo "hello world" | superagent pipe "Translate to Chinese"
    """
    stdin_data = ""
    if not sys.stdin.isatty():
        stdin_data = sys.stdin.read()

    if not stdin_data.strip() and not prompt_prefix:
        console.print("[red]No input. Pipe data to stdin or provide a prompt.[/red]")
        raise typer.Exit(1)

    # Combine prompt prefix + stdin data
    full_prompt = ""
    if prompt_prefix:
        full_prompt = prompt_prefix
    if stdin_data.strip():
        if full_prompt:
            full_prompt += "\n\n--- Input Data ---\n\n"
        full_prompt += stdin_data

    _execute_headless(
        prompt=full_prompt,
        output_format=output_format,
        model=model,
    )


def _execute_headless(
    prompt: str,
    output_format: str = "text",
    model: Optional[str] = None,
    allowed_tools: Optional[str] = None,
    permission_mode: str = "default",
    resume_session: Optional[str] = None,
    max_turns: int = 20,
    json_schema: Optional[str] = None,
    skip_permissions: bool = False,
) -> None:
    """Execute a prompt in headless mode with various output formats.

    Inspired by CodeBuddy's headless mode:
    - text: plain text output
    - json: structured JSON with metadata (session_id, cost, etc.)
    - stream-json: streaming JSON messages (one per line)
    """
    import time
    from superagent.llm_gateway import call_llm
    from superagent.hooks import trigger_hooks, HookEvent

    # Trigger SessionStart hooks
    trigger_hooks(HookEvent.SESSION_START)

    start_time = time.time()

    try:
        # Execute via LLM
        result = asyncio.run(call_llm(prompt, provider="default", model=model))

        duration_ms = int((time.time() - start_time) * 1000)

        if output_format == "json":
            output = {
                "result": result or "",
                "session_id": resume_session or "",
                "duration_ms": duration_ms,
                "model": model or "default",
                "permission_mode": permission_mode,
            }
            # Apply JSON Schema if provided
            if json_schema:
                try:
                    schema = json.loads(json_schema)
                    output["json_schema_applied"] = True
                except json.JSONDecodeError:
                    pass
            console.print(json.dumps(output, indent=2, ensure_ascii=False))

        elif output_format == "stream-json":
            # Simulated streaming output (single chunk for now)
            messages = [
                {"type": "system", "session_id": resume_session or ""},
                {"type": "assistant", "content": [{"type": "text", "text": result or ""}]},
                {"type": "result", "subtype": "success", "duration_ms": duration_ms},
            ]
            for msg in messages:
                console.print(json.dumps(msg, ensure_ascii=False))

        else:  # text
            console.print(result or "")

    except Exception as e:
        if output_format in ("json", "stream-json"):
            error_output = {
                "type": "result",
                "subtype": "error",
                "error": str(e),
            }
            console.print(json.dumps(error_output, ensure_ascii=False))
        else:
            console.print(f"[red]Error: {e}[/red]", file=sys.stderr)
        raise typer.Exit(1)

    finally:
        # Trigger SessionEnd hooks
        trigger_hooks(HookEvent.SESSION_END)
