"""Deep research agent for SuperAgent — powered by GPT-Researcher (18k stars).

Enables agents to conduct thorough web research: search → scrape → analyze → report.
Falls back to a simple search-based approach when GPT-Researcher is not available.
"""
from __future__ import annotations

import asyncio
import logging

logger = logging.getLogger(__name__)

_GPT_RESEARCHER_AVAILABLE = False
try:
    from gpt_researcher import GPTResearcher
    _GPT_RESEARCHER_AVAILABLE = True
except (ImportError, Exception) as e:
    logger.debug("gpt-researcher not available: %s", e)


def is_researcher_available() -> bool:
    return _GPT_RESEARCHER_AVAILABLE


async def _research_with_gptr(query: str, report_type: str = "research_report") -> dict:
    """Use GPT-Researcher for deep research."""
    researcher = GPTResearcher(query=query, report_type=report_type)
    report = await researcher.conduct_research()
    return {"success": True, "report": report, "engine": "gpt-researcher", "error": None}


async def _research_fallback(query: str) -> dict:
    """Fallback: use LLM directly for research."""
    try:
        from superagent.llm_gateway import LLMGateway, call_llm, get_llm_gateway
        gw = get_llm_gateway()
        provider = None
        for p in gw.list_providers():
            if LLMGateway.resolve_api_key(p):
                provider = p.name
                break
        if not provider:
            return {"success": False, "report": "", "engine": "none", "error": "No LLM provider with API key"}

        prompt = f"""You are a research agent. Conduct thorough research on the following topic and produce a detailed report with findings, analysis, and conclusions.

Topic: {query}

Structure your report with:
1. Executive Summary
2. Key Findings
3. Detailed Analysis
4. Conclusions and Recommendations

Cite sources where possible."""

        report = call_llm(provider, [{"role": "user", "content": prompt}], temperature=0.3)
        return {"success": True, "report": report, "engine": f"llm-{provider}", "error": None}
    except Exception as e:
        return {"success": False, "report": "", "engine": "fallback", "error": str(e)}


def research(query: str, report_type: str = "research_report") -> dict:
    """Conduct research on a topic. Uses GPT-Researcher if available, otherwise LLM fallback."""
    if _GPT_RESEARCHER_AVAILABLE:
        try:
            return asyncio.run(_research_with_gptr(query, report_type))
        except Exception as e:
            logger.warning("GPT-Researcher failed, falling back: %s", e)
    return asyncio.run(_research_fallback(query))
