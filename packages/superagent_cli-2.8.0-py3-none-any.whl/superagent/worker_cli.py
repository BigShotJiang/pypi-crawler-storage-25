"""SuperAgent worker / daemon CLI commands.

Provides ``superagent ps``, ``superagent logs``, ``superagent kill``,
``superagent daemon start/stop/status``, and ``superagent bg``.

Inspired by CodeBuddy CLI's worker management pattern.
"""

from __future__ import annotations

import json as _json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

console = Console()
worker_app = typer.Typer(help="Workers — manage background sessions and the daemon.")


@worker_app.command("ps")
def worker_ps(
    kind: Optional[str] = typer.Option(None, "--kind", "-k", help="Filter by kind: interactive, bg, daemon."),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """List all active workers (like ``ps`` for agent processes)."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    workers = mgr.list_workers(kind=kind)

    if json_out:
        console.print(_json.dumps([w.to_dict() for w in workers], indent=2))
        return

    table = Table(title="SuperAgent Workers")
    table.add_column("ID", style="cyan")
    table.add_column("Name", style="green")
    table.add_column("PID", justify="right")
    table.add_column("Kind")
    table.add_column("Status")
    table.add_column("Started")
    table.add_column("Command", max_width=40, no_wrap=True)

    for w in workers:
        from datetime import datetime, timezone

        started = datetime.fromtimestamp(w.started_at, tz=timezone.utc).strftime("%m-%d %H:%M")
        status_style = "green" if w.status == "running" else "red"
        table.add_row(
            w.id,
            w.name,
            str(w.pid),
            w.kind,
            f"[{status_style}]{w.status}[/{status_style}]",
            started,
            w.command[:40] if w.command else "",
        )

    console.print(table)


@worker_app.command("logs")
def worker_logs(
    name: str = typer.Argument(..., help="Worker name or ID."),
    log_type: Optional[str] = typer.Option(None, "--type", "-t", help="Log type: process, telemetry, transcript."),
    tail: int = typer.Option(200, "--tail", "-n", help="Last N lines."),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output (like tail -f)."),
):
    """View a worker's log output."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    output = mgr.get_worker_logs(name, log_type=log_type, tail=tail)
    if not output:
        console.print(f"[yellow]No logs found for worker '{name}'.[/yellow]")
        return
    console.print(output)

    if follow:
        import time

        worker = mgr.get_worker(name)
        if worker is None or worker.status != "running":
            return

        log_path = worker.log_path
        if not log_path:
            return

        import subprocess

        try:
            subprocess.run(["tail", "-f", log_path])
        except KeyboardInterrupt:
            pass


@worker_app.command("kill")
def worker_kill(
    name: str = typer.Argument(..., help="Worker name or ID to terminate."),
):
    """Terminate a running worker process."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    if mgr.kill_worker(name):
        console.print(f"[green]Worker '{name}' terminated.[/green]")
    else:
        console.print(f"[red]Failed to terminate worker '{name}'.[/red]")


@worker_app.command("bg")
def worker_bg(
    name: str = typer.Argument(..., help="Display name for the background task."),
    goal: str = typer.Argument(..., help="Goal / task description."),
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Team name to assign."),
    engine: str = typer.Option("builtin", "--engine", "-e", help="Execution engine: builtin, hermes, deerflow."),
):
    """Launch a task in the background (non-blocking)."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    worker = mgr.launch_bg_task(name=name, goal=goal, command=engine, team=team)
    console.print(f"[green]Background task '{name}' started (pid={worker.pid}).[/green]")
    console.print(f"[dim]  Log: {worker.log_path}[/dim]")
    console.print(f"[dim]  Track: superagent worker logs {name}[/dim]")


# ---- Daemon sub-commands ----

daemon_app = typer.Typer(help="Daemon — start/stop the persistent Gateway daemon.")
worker_app.add_typer(daemon_app, name="daemon")


@daemon_app.command("start")
def daemon_start(
    port: int = typer.Option(7890, "--port", "-p", help="HTTP port."),
    host: str = typer.Option("127.0.0.1", "--host", help="Bind address."),
):
    """Start the Gateway daemon (idempotent)."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    worker = mgr.start_daemon(port=port, host=host)
    console.print(f"[green]Gateway daemon started (pid={worker.pid}).[/green]")
    console.print(f"[dim]  Endpoint: {worker.url}[/dim]")
    console.print(f"[dim]  Log: {worker.log_path}[/dim]")


@daemon_app.command("stop")
def daemon_stop():
    """Stop the Gateway daemon."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    if mgr.stop_daemon():
        console.print("[green]Gateway daemon stopped.[/green]")
    else:
        console.print("[red]Failed to stop daemon.[/red]")


@daemon_app.command("status")
def daemon_status(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Check Gateway daemon status."""
    from superagent.worker_manager import WorkerManager

    mgr = WorkerManager()
    status = mgr.daemon_status()
    if status is None:
        console.print("[yellow]No daemon registered.[/yellow]")
        return
    if json_out:
        console.print(_json.dumps(status, indent=2))
        return

    running = status["status"] == "running"
    style = "green" if running else "red"
    console.print(f"[{style}]Daemon {status['status']}[/{style}]")
    if running:
        console.print(f"  PID:      {status['pid']}")
        console.print(f"  Endpoint: {status['endpoint']}")
        console.print(f"  Host:     {status['hostname']}")
