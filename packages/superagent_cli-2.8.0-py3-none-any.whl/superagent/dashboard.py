"""SuperAgent Dashboard — real-time pixel-art visualization of agent teams.

Integrates Star-Office-UI (pixel office) with SuperAgent state data.
Reads team/task/agent status from ~/.superagent/ and pushes to the visualization.
"""
from __future__ import annotations

import json
import logging
import os
import threading
from datetime import datetime, timezone
from pathlib import Path

logger = logging.getLogger(__name__)


def _get_data_dir() -> str:
    return os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))


def _get_dashboard_dir() -> str:
    """Get path to dashboard/ directory in the project."""
    return os.path.join(os.path.dirname(__file__), "..", "..", "dashboard")


# --- State mapping: SuperAgent → Star-Office-UI ---

_TASK_STATE_MAP = {
    "in_progress": "executing",
    "pending": "idle",
    "completed": "idle",
    "blocked": "idle",
}

def map_agent_state(agent_info: dict) -> str:
    """Map SuperAgent agent info to Star-Office-UI state."""
    # Check if agent has active tasks
    # States: idle, writing, researching, executing, syncing, error
    status = agent_info.get("status", "idle")
    if status == "dead" or status == "error":
        return "error"
    return "executing"  # active agents are "executing"


def collect_team_state(team_name: str) -> dict:
    """Collect full state for a team from ~/.superagent/ filesystem."""
    data_dir = _get_data_dir()
    team_dir = os.path.join(data_dir, "teams", team_name)
    
    result = {
        "team": team_name,
        "agents": [],
        "tasks": {"total": 0, "completed": 0, "in_progress": 0, "pending": 0, "blocked": 0},
        "messages": 0,
    }
    
    # Read spawn registry
    registry_path = os.path.join(team_dir, "spawn_registry.json")
    if os.path.isfile(registry_path):
        try:
            with open(registry_path) as f:
                registry = json.load(f)
            for name, info in registry.items():
                result["agents"].append({
                    "name": name,
                    "status": info.get("status", "unknown"),
                    "backend": info.get("backend", ""),
                    "task": info.get("task", ""),
                    "started_at": info.get("started_at", ""),
                })
        except (json.JSONDecodeError, KeyError):
            pass
    
    # Read tasks
    tasks_dir = os.path.join(team_dir, "tasks")
    if os.path.isdir(tasks_dir):
        for tf in Path(tasks_dir).glob("*.json"):
            try:
                task = json.loads(tf.read_text())
                status = task.get("status", "pending")
                result["tasks"]["total"] += 1
                result["tasks"][status] = result["tasks"].get(status, 0) + 1
            except (json.JSONDecodeError, KeyError):
                pass
    
    # Count inbox messages
    inbox_dir = os.path.join(team_dir, "inboxes")
    if os.path.isdir(inbox_dir):
        for inbox in Path(inbox_dir).iterdir():
            if inbox.is_dir():
                result["messages"] += len(list(inbox.glob("*.json")))
    
    return result


def collect_wiki_state() -> dict | None:
    """Collect wiki stats for the dashboard. Returns None if wiki not initialized."""
    try:
        from superagent.wiki import get_wiki_store
        store = get_wiki_store()
        if not store.wiki_dir.exists():
            return None
        info = store.status()
        return {
            "pages": info.get("total_pages", 0),
            "health_score": info.get("health_score", 0),
            "last_ingest": info.get("last_ingest", ""),
            "by_type": info.get("pages_by_type", {}),
        }
    except Exception as e:
        logger.debug("Dashboard data collection failed: %s", e)
        return None


def write_star_office_state(team_name: str, dashboard_dir: str):
    """Write SuperAgent team state to Star-Office-UI state.json format."""
    state = collect_team_state(team_name)
    
    tasks = state["tasks"]
    total = tasks["total"]
    completed = tasks["completed"]
    in_progress = tasks["in_progress"]
    
    # Determine overall state
    if total == 0:
        overall_state = "idle"
        detail = f"Team '{team_name}' ready — no tasks yet"
    elif completed == total:
        overall_state = "idle"
        detail = f"All {total} tasks completed!"
    elif in_progress > 0:
        overall_state = "executing"
        detail = f"{in_progress} tasks running, {completed}/{total} done"
    else:
        overall_state = "researching"
        detail = f"Planning — {total - completed} tasks pending"
    
    progress = completed / total if total > 0 else 0
    
    # Write state.json for main agent
    state_path = os.path.join(dashboard_dir, "state.json")
    state_data = {
        "state": overall_state,
        "detail": detail,
        "progress": round(progress, 2),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "officeName": f"SuperAgent: {team_name}",
    }
    
    # Collect wiki state if available
    wiki_state = collect_wiki_state()
    if wiki_state:
        state_data["wiki"] = wiki_state

    Path(state_path).write_text(json.dumps(state_data, indent=2), encoding="utf-8")

    # Write agents-state.json for multi-agent view
    agents_state = []
    
    # Main agent (team leader)
    agents_state.append({
        "agentId": "star",
        "name": f"Leader ({team_name})",
        "isMain": True,
        "state": overall_state,
        "detail": detail,
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "area": "writing" if overall_state != "idle" else "breakroom",
        "source": "local",
        "authStatus": "approved",
    })
    
    # Worker agents
    for i, agent in enumerate(state["agents"]):
        agent_state = map_agent_state(agent)
        area = "error" if agent_state == "error" else ("writing" if agent_state != "idle" else "breakroom")
        agents_state.append({
            "agentId": f"agent_{agent['name']}",
            "name": agent["name"],
            "isMain": False,
            "state": agent_state,
            "detail": agent.get("task", "")[:60],
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "area": area,
            "source": "local",
            "authStatus": "approved",
            "avatar": f"guest_role_{(i % 6) + 1}",
        })
    
    agents_path = os.path.join(dashboard_dir, "agents-state.json")
    Path(agents_path).write_text(json.dumps(agents_state, indent=2), encoding="utf-8")
    
    return state_data, agents_state


class DashboardSyncThread(threading.Thread):
    """Background thread that periodically syncs SuperAgent state to Star-Office-UI."""
    
    def __init__(self, team_name: str, dashboard_dir: str, interval: float = 3.0):
        super().__init__(daemon=True)
        self.team_name = team_name
        self.dashboard_dir = dashboard_dir
        self.interval = interval
        self._stop_event = threading.Event()
    
    def run(self):
        while not self._stop_event.is_set():
            try:
                write_star_office_state(self.team_name, self.dashboard_dir)
            except Exception as e:
                logger.debug("Dashboard state sync failed for team %s: %s", self.team_name, e)
            self._stop_event.wait(self.interval)
    
    def stop(self):
        self._stop_event.set()


# ---------------------------------------------------------------------------
# Builtin execution state (no ClawTeam registry needed)
# ---------------------------------------------------------------------------

_AGENT_STATE_TO_AREA = {
    "pending": "breakroom",
    "planning": "writing",
    "executing": "writing",
    "done": "breakroom",
    "failed": "error",
}


def write_builtin_execution_state(
    team_name: str,
    dashboard_dir: str,
    agents: list[dict],
) -> None:
    """Write dashboard state directly from builtin/local execution.

    Each entry in *agents* should have keys:
    ``name``, ``role``, ``status`` (pending|planning|executing|done|failed),
    ``detail`` (short description of what the agent is doing).

    This bypasses ``collect_team_state`` which requires a ClawTeam spawn
    registry; instead it writes ``state.json`` and ``agents-state.json``
    directly from the in-memory execution loop.
    """
    total = len(agents)
    done = sum(1 for a in agents if a.get("status") == "done")
    failed = sum(1 for a in agents if a.get("status") == "failed")
    active = sum(1 for a in agents if a.get("status") in ("planning", "executing"))

    if done + failed == total:
        overall = "idle"
        detail = f"All {total} agents finished ({done} ok, {failed} failed)" if failed else f"All {total} agents completed!"
    elif active > 0:
        overall = "executing"
        detail = f"{active} agents working, {done}/{total} done"
    else:
        overall = "researching"
        detail = f"Preparing {total} agents..."

    progress = (done + failed) / total if total > 0 else 0

    state_data = {
        "state": overall,
        "detail": detail,
        "progress": round(progress, 2),
        "updated_at": datetime.now(timezone.utc).isoformat(),
        "officeName": f"SuperAgent: {team_name}",
    }

    state_path = os.path.join(dashboard_dir, "state.json")
    Path(state_path).write_text(json.dumps(state_data, indent=2), encoding="utf-8")

    # Agents state
    agents_state = []
    for i, a in enumerate(agents):
        status = a.get("status", "pending")
        area = _AGENT_STATE_TO_AREA.get(status, "breakroom")
        ui_state = "error" if status == "failed" else ("executing" if status in ("planning", "executing") else "idle")

        agents_state.append({
            "agentId": f"agent_{a['name']}",
            "name": f"{a['name']} ({a.get('role', '')})",
            "isMain": i == 0,
            "state": ui_state,
            "detail": a.get("detail", "")[:80],
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "area": area,
            "source": "local",
            "authStatus": "approved",
            "avatar": f"guest_role_{(i % 6) + 1}" if i > 0 else None,
        })

    agents_path = os.path.join(dashboard_dir, "agents-state.json")
    Path(agents_path).write_text(json.dumps(agents_state, indent=2), encoding="utf-8")


def get_dashboard_dir() -> str:
    """Get the dashboard directory, ensuring state files exist."""
    dashboard_dir = _get_dashboard_dir()
    
    # Ensure state files exist
    state_path = os.path.join(dashboard_dir, "state.json")
    if not os.path.isfile(state_path):
        sample = os.path.join(dashboard_dir, "state.sample.json")
        if os.path.isfile(sample):
            import shutil
            shutil.copy2(sample, state_path)
        else:
            Path(state_path).write_text(json.dumps({
                "state": "idle", "detail": "SuperAgent ready", "progress": 0,
                "updated_at": datetime.now(timezone.utc).isoformat(),
                "officeName": "SuperAgent Office",
            }))
    
    agents_path = os.path.join(dashboard_dir, "agents-state.json")
    if not os.path.isfile(agents_path):
        Path(agents_path).write_text(json.dumps([{
            "agentId": "star", "name": "SuperAgent", "isMain": True,
            "state": "idle", "detail": "ready", "area": "breakroom",
            "updated_at": datetime.now(timezone.utc).isoformat(),
            "source": "local", "authStatus": "approved",
        }]))
    
    join_keys_path = os.path.join(dashboard_dir, "join-keys.json")
    if not os.path.isfile(join_keys_path):
        sample = os.path.join(dashboard_dir, "join-keys.sample.json")
        if os.path.isfile(sample):
            import shutil
            shutil.copy2(sample, join_keys_path)
    
    return dashboard_dir
