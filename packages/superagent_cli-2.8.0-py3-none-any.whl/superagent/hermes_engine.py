"""Hermes Agent execution engine — full tool-calling agent loop for SuperAgent.

Wraps the upstream Hermes Agent's AIAgent class to provide a production-grade
execution engine with 55+ tools, automatic context compression, and multi-turn
tool-calling loops.

Usage:
    superagent auto "Build a todo app" --command hermes
"""
from __future__ import annotations

import asyncio
import logging
import os
import sys
from pathlib import Path
from typing import Any, Optional

logger = logging.getLogger(__name__)

# Add upstream hermes-agent to sys.path (same pattern as ClawTeam/DeerFlow)
_HERMES_PATH = os.path.join(os.path.dirname(__file__), "..", "..", "upstream", "hermes-agent")
if os.path.isdir(_HERMES_PATH) and _HERMES_PATH not in sys.path:
    sys.path.insert(0, _HERMES_PATH)

_HERMES_AVAILABLE = False
try:
    from run_agent import AIAgent  # type: ignore[import-untyped]

    _HERMES_AVAILABLE = True
    logger.info("Hermes Agent engine available")
except ImportError as e:
    logger.debug("Hermes Agent not available: %s", e)


def is_hermes_available() -> bool:
    """Check whether the Hermes Agent engine is importable."""
    return _HERMES_AVAILABLE


# ---------------------------------------------------------------------------
# Provider mapping: SuperAgent LLM Gateway → Hermes AIAgent params
# ---------------------------------------------------------------------------


def _resolve_hermes_params(provider_name: Optional[str] = None) -> dict[str, Any]:
    """Map SuperAgent's LLM Gateway config to Hermes AIAgent constructor params.

    Returns dict with keys: base_url, api_key, model, provider.
    """
    from superagent.llm_gateway import LLMGateway, get_llm_gateway

    gw = get_llm_gateway()

    if provider_name:
        cfg = gw.get_provider(provider_name)
    else:
        cfg = gw.get_default()

    if cfg is None:
        # Try to find any provider with a key
        for p in gw.list_providers():
            key = LLMGateway.resolve_api_key(p)
            if key:
                cfg = p
                break

    if cfg is None:
        raise RuntimeError(
            "No LLM provider configured. Run: superagent llm add --name openai --api-key $OPENAI_API_KEY"
        )

    api_key = LLMGateway.resolve_api_key(cfg)
    return {
        "base_url": cfg.base_url,
        "api_key": api_key,
        "model": cfg.default_model,
        "provider": cfg.name,
    }


# ---------------------------------------------------------------------------
# Single-task executor
# ---------------------------------------------------------------------------


def execute_with_hermes(
    task: str,
    *,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    working_dir: Optional[str] = None,
    max_iterations: int = 20,
    toolsets: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Execute a task using Hermes Agent's full tool-calling loop.

    Returns dict matching SuperAgent's standard result contract:
        {success, output, files_created, engine, error}
    """
    if not _HERMES_AVAILABLE:
        return {
            "success": False,
            "output": "",
            "files_created": [],
            "engine": "hermes",
            "error": "Hermes Agent not available. Ensure upstream/hermes-agent/ exists.",
        }

    params = _resolve_hermes_params(provider)
    if model:
        params["model"] = model

    work_dir = working_dir or os.getcwd()
    os.makedirs(work_dir, exist_ok=True)

    # Snapshot files before execution for diff
    try:
        files_before = set(os.listdir(work_dir))
    except OSError:
        files_before = set()

    try:
        agent = AIAgent(
            base_url=params["base_url"],
            api_key=params["api_key"],
            model=params["model"],
            provider=params["provider"],
            max_iterations=max_iterations,
            enabled_toolsets=toolsets or ["web", "terminal", "development", "research"],
            quiet_mode=True,
            skip_memory=True,
            skip_context_files=True,
        )

        # Change to working dir for file operations
        original_cwd = os.getcwd()
        try:
            os.chdir(work_dir)
            result = agent.run_conversation(user_message=task)
        finally:
            os.chdir(original_cwd)

        output = result.get("final_response", "")

        # Detect new files
        try:
            files_after = set(os.listdir(work_dir))
            new_files = sorted(files_after - files_before - {"__pycache__"})
        except OSError:
            new_files = []

        return {
            "success": True,
            "output": output,
            "files_created": new_files,
            "engine": "hermes",
            "error": None,
        }

    except Exception as e:
        logger.error("Hermes execution failed: %s", e)
        return {
            "success": False,
            "output": "",
            "files_created": [],
            "engine": "hermes",
            "error": str(e),
        }


async def execute_with_hermes_async(
    task: str,
    *,
    provider: Optional[str] = None,
    model: Optional[str] = None,
    working_dir: Optional[str] = None,
    max_iterations: int = 20,
    toolsets: Optional[list[str]] = None,
) -> dict[str, Any]:
    """Async wrapper for parallel worker execution."""
    return await asyncio.to_thread(
        execute_with_hermes,
        task,
        provider=provider,
        model=model,
        working_dir=working_dir,
        max_iterations=max_iterations,
        toolsets=toolsets,
    )


# ---------------------------------------------------------------------------
# Team executor (3-phase: Leader → Workers → Synthesis)
# ---------------------------------------------------------------------------


def execute_team_hermes(
    goal: str,
    plan: Any,
    output_dir: str,
    *,
    dashboard: bool = False,
    parallel: bool = True,
    synthesis: bool = True,
) -> None:
    """Execute a team plan using Hermes Agent engine.

    Follows the same 3-phase pattern as _execute_builtin():
    1. Leader plans with research-only toolset
    2. Workers execute in parallel with full toolset
    3. Leader synthesizes and reviews all outputs

    Reuses SuperAgent's existing infrastructure:
    - Dashboard visualization
    - Agent profile recording (Moxt pattern)
    - Shared corrections injection (Moxt pattern)
    - Injection polling (async directive system)
    - Memory capture and learning loop
    """
    if not _HERMES_AVAILABLE:
        from rich.console import Console

        Console().print(
            "[red]Hermes Agent not available.[/red]\n"
            "  Ensure upstream/hermes-agent/ exists.\n"
            "  Run: [cyan]make subtree-update-hermes[/cyan]"
        )
        import typer

        raise typer.Exit(1)

    from rich.console import Console
    from rich.panel import Panel
    from rich.progress import Progress, SpinnerColumn, TextColumn
    from rich.table import Table

    from superagent.auto_cli import (
        _auto_capture_memory,
        _auto_learn_from_execution,
        _compress_plan,
        _poll_injections,
        _start_dashboard,
        _stop_dashboard,
        _update_dashboard,
    )
    from superagent.orchestrator import PermissionLevel

    console = Console()
    os.makedirs(output_dir, exist_ok=True)
    agents = plan.all_agents

    # --- Dashboard ---
    dash_proc = None
    dash_agents: list[dict] = []
    if dashboard:
        dash_agents = [
            {"name": a.name, "role": a.role, "status": "pending", "detail": "Waiting..."}
            for a in agents
        ]
        dash_proc = _start_dashboard(plan.team_name, dash_agents)

    mode_label = "parallel" if parallel else "sequential"
    console.print(
        f"\n[bold green]Executing team '{plan.team_name}' via Hermes Agent "
        f"({len(agents)} agents, {mode_label}, 55+ tools)...[/bold green]\n"
    )

    results: list[dict] = []
    leader_output = ""

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        console=console,
    ) as progress:
        # ============================================================
        # Phase 1: Leader planning (research toolset only)
        # ============================================================
        leader = plan.leader
        leader_dir = os.path.join(output_dir, leader.name)
        tid = progress.add_task(
            f"[yellow]Leader[/yellow] {leader.name} ({leader.role}) — planning", total=None
        )

        leader_prompt = (
            f"You are the Team Leader ({leader.role}) planning a software project.\n\n"
            f"## Project Goal\n{goal}\n\n"
            f"## Your Team\n"
            + "\n".join(f"- **{w.name}** ({w.role})" for w in plan.workers)
            + "\n\n## Instructions\n"
            "Create a DETAILED execution plan with:\n"
            "1. Project architecture overview\n"
            "2. For EACH worker, specify exact files to create with full paths\n"
            "3. Technology choices with brief rationale\n"
            "4. Acceptance criteria\n\n"
            "Be specific — your workers will follow this plan exactly."
        )

        # Moxt pattern: Inject leader's accumulated experience
        try:
            from superagent.agent_profile import get_profile_store

            leader_profile = get_profile_store().get(leader.name)
            if leader_profile and leader_profile.experience_level != "novice":
                leader_prompt += f"\n\n## Your Experience\n{leader_profile.get_context_prompt()}"
        except Exception as e:
            logger.debug("Leader profile context failed: %s", e)

        leader_result = execute_with_hermes(
            leader_prompt,
            working_dir=leader_dir,
            max_iterations=15,
            toolsets=["web", "research"],  # Plan mode: no file writes
        )
        leader_output = leader_result.get("output", "")
        results.append({"agent": leader.name, "role": leader.role, "type": "leader", **leader_result})

        if leader_result.get("success"):
            progress.update(tid, description=f"[green]Leader[/green] {leader.name} — done")
        else:
            progress.update(tid, description=f"[red]Leader[/red] {leader.name} — failed")
            console.print(f"[red]Leader failed: {leader_result.get('error')}[/red]")

        if dashboard and dash_agents:
            dash_agents[0]["status"] = "done" if leader_result.get("success") else "failed"
            _update_dashboard(plan.team_name, dash_agents)

        # ============================================================
        # Phase 2: Workers (parallel or sequential)
        # ============================================================

        # Moxt pattern: Load shared corrections
        corrections_block = ""
        try:
            from superagent.corrections import get_correction_store

            corrections_block = get_correction_store().get_prompt_block(limit=10)
        except Exception as e:
            logger.debug("Corrections load failed: %s", e)

        worker_prompts: list[tuple[int, str, str]] = []
        for wi, worker in enumerate(plan.workers):
            worker_dir = os.path.join(output_dir, worker.name)
            os.makedirs(worker_dir, exist_ok=True)

            wp = f"You are **{worker.name}** ({worker.role}).\n\n"
            if worker.permission_level == PermissionLevel.REVIEW:
                wp += "## Permission: REVIEW — review and report only, do NOT modify files.\n\n"
            wp += (
                f"## Project Goal\n{goal}\n\n"
                f"## Leader's Plan\n{_compress_plan(leader_output)}\n\n"
                f"## Your Assignment\n{worker.task or 'Implement your part of the project'}\n\n"
                "## Requirements\n"
                "- Write COMPLETE, PRODUCTION-QUALITY code\n"
                "- Include error handling and input validation\n"
                "- Create ALL files needed for your part to work\n"
                + corrections_block
            )
            worker_prompts.append((wi, worker.name, wp))

        # Determine toolsets per worker
        worker_toolsets = ["web", "terminal", "development", "research"]

        if parallel and len(plan.workers) > 1:
            # --- Parallel execution ---
            progress_ids: dict[str, int] = {}
            for wi, worker in enumerate(plan.workers):
                pid = progress.add_task(
                    f"[cyan]Worker[/cyan] {worker.name} ({worker.role}) — parallel", total=None
                )
                progress_ids[worker.name] = pid

            if dashboard and dash_agents:
                for wi in range(len(plan.workers)):
                    dash_agents[wi + 1]["status"] = "executing"
                _update_dashboard(plan.team_name, dash_agents)

            async def _run_all():
                tasks = []
                for _wi, name, prompt in worker_prompts:
                    wdir = os.path.join(output_dir, name)
                    tasks.append(
                        execute_with_hermes_async(
                            prompt, working_dir=wdir, toolsets=worker_toolsets
                        )
                    )
                return await asyncio.gather(*tasks, return_exceptions=True)

            worker_results = asyncio.run(_run_all())

            for (wi, name, _), wr in zip(worker_prompts, worker_results):
                worker = plan.workers[wi]
                if isinstance(wr, Exception):
                    wr = {"success": False, "error": str(wr), "output": "", "files_created": [], "engine": "hermes"}
                results.append({"agent": name, "role": worker.role, "type": "worker", **wr})
                pid = progress_ids[name]
                if wr.get("success"):
                    progress.update(pid, description=f"[green]Worker[/green] {name} — done")
                else:
                    progress.update(pid, description=f"[red]Worker[/red] {name} — failed")
                if dashboard and dash_agents:
                    dash_agents[wi + 1]["status"] = "done" if wr.get("success") else "failed"
                    _update_dashboard(plan.team_name, dash_agents)
                _auto_capture_memory(name, worker.role, wr, plan.team_name)
        else:
            # --- Sequential execution ---
            for wi, name, prompt in worker_prompts:
                worker = plan.workers[wi]
                wid = progress.add_task(f"Worker {name} ({worker.role})", total=None)
                if dashboard and dash_agents:
                    dash_agents[wi + 1]["status"] = "executing"
                    _update_dashboard(plan.team_name, dash_agents)
                wr = execute_with_hermes(
                    prompt, working_dir=os.path.join(output_dir, name), toolsets=worker_toolsets
                )
                results.append({"agent": name, "role": worker.role, "type": "worker", **wr})
                if wr.get("success"):
                    progress.update(wid, description=f"[green]Worker[/green] {name} — done")
                else:
                    progress.update(wid, description=f"[red]Worker[/red] {name} — failed")
                if dashboard and dash_agents:
                    dash_agents[wi + 1]["status"] = "done" if wr.get("success") else "failed"
                    _update_dashboard(plan.team_name, dash_agents)
                _auto_capture_memory(name, worker.role, wr, plan.team_name)

        # ============================================================
        # Phase 3: Synthesis — Leader reviews all outputs
        # ============================================================
        synthesis_output = ""
        if synthesis and leader_result.get("success"):
            sid = progress.add_task("[magenta]Synthesis[/magenta] — Leader reviewing outputs", total=None)

            # Check for user-injected directives
            injected = _poll_injections(plan.team_name)
            injection_context = ""
            if injected:
                console.print(f"\n[bold magenta]Received {len(injected)} user directive(s):[/bold magenta]")
                injection_lines = []
                for inj in injected:
                    prio = inj.get("priority", "normal")
                    msg = inj.get("message", "")
                    console.print(f"  [{prio}] {msg}")
                    injection_lines.append(f"- [{prio.upper()}] {msg}")
                injection_context = (
                    "\n\n## User Directives (received during execution)\n"
                    "You MUST incorporate these into your review:\n"
                    + "\n".join(injection_lines)
                    + "\n"
                )

            worker_summaries = []
            for r in results:
                if r.get("type") == "worker":
                    status_s = "OK" if r.get("success") else "FAILED"
                    files_s = ", ".join(r.get("files_created", [])) or "none"
                    out_preview = (r.get("output", "") or "")[:500]
                    worker_summaries.append(
                        f"### {r['agent']} ({r['role']}) — {status_s}\n"
                        f"Files: {files_s}\nOutput:\n{out_preview}\n"
                    )

            syn_prompt = (
                f"You are the Team Leader reviewing your team's completed work.\n\n"
                f"## Original Goal\n{goal}\n\n"
                f"## Your Plan\n{_compress_plan(leader_output)}\n\n"
                f"## Worker Outputs\n{'---\n'.join(worker_summaries)}\n\n"
                f"{injection_context}"
                "## Review Task\n"
                "1. Evaluate completeness\n"
                "2. Identify gaps or missing pieces\n"
                "3. Assess quality\n"
                "4. Provide final summary and next steps\n\nBe concise."
            )
            syn_result = execute_with_hermes(
                syn_prompt,
                working_dir=os.path.join(output_dir, "synthesis"),
                max_iterations=10,
                toolsets=["web", "research"],
            )
            synthesis_output = syn_result.get("output", "")
            results.append({"agent": leader.name, "role": "Synthesis", "type": "synthesis", **syn_result})

            if syn_result.get("success"):
                progress.update(sid, description="[green]Synthesis[/green] — review complete")
            else:
                progress.update(sid, description="[yellow]Synthesis[/yellow] — skipped")

    # Stop dashboard
    if dashboard and dash_proc:
        _stop_dashboard(dash_proc)

    # --- Summary ---
    console.print()
    summary_table = Table(title=f"Hermes Execution Results — {plan.team_name}", show_lines=True)
    summary_table.add_column("Agent", style="bold")
    summary_table.add_column("Role", style="cyan")
    summary_table.add_column("Status")
    summary_table.add_column("Files Created")
    summary_table.add_column("Engine", style="dim")

    for r in results:
        status = "[green]OK[/green]" if r.get("success") else f"[red]FAIL: {r.get('error', '?')}[/red]"
        files = ", ".join(r.get("files_created", [])) or "—"
        summary_table.add_row(r["agent"], r["role"], status, files, r.get("engine", "—"))

    console.print(summary_table)

    if synthesis and synthesis_output:
        console.print()
        console.print(Panel(synthesis_output[:2000], title="Synthesis Review", border_style="magenta"))

    console.print(f"\n[dim]Output directory: {output_dir}[/dim]")

    # Moxt pattern: Update agent profiles
    try:
        from superagent.agent_profile import get_profile_store

        profiles = get_profile_store()
        for r in results:
            if r.get("type") == "synthesis":
                continue
            p = profiles.get_or_create(r["agent"], role=r.get("role", ""))
            p.record_execution(
                task=goal[:200],
                success=r.get("success", False),
                files_created=len(r.get("files_created", [])),
                domain=plan.template_name,
            )
            profiles.save(p)
    except Exception as e:
        logger.debug("Agent profile update failed: %s", e)

    # Write execution summary
    import json

    summary_path = os.path.join(output_dir, "execution_summary.json")
    Path(summary_path).write_text(
        json.dumps(results, indent=2, ensure_ascii=False, default=str), encoding="utf-8"
    )
    console.print(f"[dim]Summary written: {summary_path}[/dim]")

    # Hermes learning loop
    _auto_learn_from_execution(goal, plan, results)
