"""Agent Card capability discovery system for SuperAgent.

Inspired by Google A2A's Agent Card pattern — agents publish capability
descriptions so that other agents (and humans) can discover them.

Cards are persisted as JSON files under ``~/.superagent/cards/{team}/{agent_name}.json``.
"""

from __future__ import annotations

import json
import os
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write


def _now_iso() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


@dataclass
class AgentCard:
    """Describes an agent's capabilities, role, and current status."""

    agent_name: str
    team: str
    capabilities: list[str] = field(default_factory=list)
    status: str = "active"
    model: str = ""
    tools: list[str] = field(default_factory=list)
    role: str = ""
    created_at: str = ""
    updated_at: str = ""

    def __post_init__(self) -> None:
        now = _now_iso()
        if not self.created_at:
            self.created_at = now
        if not self.updated_at:
            self.updated_at = now

    def to_dict(self) -> dict:
        """Serialize to a plain dict suitable for JSON storage."""
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> AgentCard:
        """Deserialize from a dict loaded from JSON."""
        return cls(
            agent_name=data["agent_name"],
            team=data["team"],
            capabilities=data.get("capabilities", []),
            status=data.get("status", "active"),
            model=data.get("model", ""),
            tools=data.get("tools", []),
            role=data.get("role", ""),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
        )


class CardRegistry:
    """Registry that persists agent cards as JSON files.

    Directory layout::

        cards/
        └── {team}/
            └── {agent_name}.json
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir) / "cards"
        self._base.mkdir(parents=True, exist_ok=True)

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _card_path(self, team: str, agent_name: str) -> Path:
        return self._base / team / f"{agent_name}.json"

    def _save_card(self, card: AgentCard) -> None:
        path = self._card_path(card.team, card.agent_name)
        atomic_write(path, json.dumps(card.to_dict(), indent=2, ensure_ascii=False))

    def _load_card(self, path: Path) -> Optional[AgentCard]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return AgentCard.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def publish(self, card: AgentCard) -> AgentCard:
        """Publish or update an agent card."""
        card.updated_at = _now_iso()
        self._save_card(card)
        return card

    def unpublish(self, team: str, agent_name: str) -> bool:
        """Remove an agent card. Returns True if found and deleted."""
        path = self._card_path(team, agent_name)
        if path.exists():
            path.unlink()
            # Clean up empty team directory
            parent = path.parent
            try:
                if parent != self._base and not any(parent.iterdir()):
                    parent.rmdir()
            except OSError:
                pass
            return True
        return False

    def get(self, team: str, agent_name: str) -> Optional[AgentCard]:
        """Retrieve a single agent card."""
        path = self._card_path(team, agent_name)
        if not path.exists():
            return None
        return self._load_card(path)

    def discover(
        self,
        team: Optional[str] = None,
        capability: Optional[str] = None,
        status: Optional[str] = None,
    ) -> list[AgentCard]:
        """Discover agent cards with optional filters.

        Args:
            team: Filter by team name.
            capability: Filter by capability keyword (substring match).
            status: Filter by agent status.

        Returns:
            List of matching AgentCard instances, sorted by updated_at descending.
        """
        results: list[AgentCard] = []
        cap_lower = capability.lower() if capability else None

        for card in self._iter_cards(team):
            if status and card.status != status:
                continue
            if cap_lower:
                card_caps = " ".join(card.capabilities).lower()
                if cap_lower not in card_caps:
                    continue
            results.append(card)

        results.sort(key=lambda c: c.updated_at, reverse=True)
        return results

    def search(self, query: str, team: Optional[str] = None) -> list[AgentCard]:
        """Keyword search across capabilities and roles.

        Args:
            query: Search keywords.
            team: Optional team filter.

        Returns:
            List of matching AgentCard instances ranked by relevance.
        """
        query_lower = query.lower()
        query_words = set(query_lower.split())
        scored: list[tuple[AgentCard, float]] = []

        for card in self._iter_cards(team):
            score = 0.0
            searchable = " ".join([
                " ".join(card.capabilities),
                card.role,
                card.agent_name,
                " ".join(card.tools),
            ]).lower()

            # Full query substring match
            if query_lower in searchable:
                score += 3.0

            # Individual word matches
            for word in query_words:
                if word in searchable:
                    score += 1.0

            if score > 0:
                scored.append((card, score))

        scored.sort(key=lambda x: x[1], reverse=True)
        return [c for c, _ in scored]

    def update_status(self, team: str, agent_name: str, status: str) -> Optional[AgentCard]:
        """Quick status update for an agent card.

        Returns the updated card or None if not found.
        """
        card = self.get(team, agent_name)
        if card is None:
            return None
        card.status = status
        card.updated_at = _now_iso()
        self._save_card(card)
        return card

    def list_teams(self) -> list[str]:
        """List all teams that have published cards."""
        teams: list[str] = []
        if not self._base.exists():
            return teams
        for child in sorted(self._base.iterdir()):
            if child.is_dir() and any(child.glob("*.json")):
                teams.append(child.name)
        return teams

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _iter_cards(self, team: Optional[str] = None):
        """Yield AgentCard objects, optionally filtered by team."""
        if team:
            team_dir = self._base / team
            if team_dir.exists():
                for f in team_dir.glob("*.json"):
                    card = self._load_card(f)
                    if card:
                        yield card
        else:
            for f in self._base.rglob("*.json"):
                card = self._load_card(f)
                if card:
                    yield card


def get_card_registry(base_dir: Optional[str] = None) -> CardRegistry:
    """Factory — return a CardRegistry rooted at the project data directory.

    Uses CLAWTEAM_DATA_DIR env var, falling back to ``~/.superagent``.
    """
    if base_dir is None:
        base_dir = os.environ.get(
            "CLAWTEAM_DATA_DIR",
            os.path.join(os.path.expanduser("~"), ".superagent"),
        )
    return CardRegistry(base_dir)
