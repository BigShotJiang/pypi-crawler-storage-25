"""SuperAgent trend search CLI — multi-platform trend discovery."""

from __future__ import annotations

import json
import os
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.trend_search import get_trend_searcher

trend_app = typer.Typer(
    name="trends",
    help="Multi-platform trend search — discover recent discussions across HN, Reddit, and the web.",
    no_args_is_help=True,
)
console = Console()

_SOURCE_BADGES = {
    "hackernews": "[bold orange1]HN[/bold orange1]",
    "reddit": "[bold bright_red]Reddit[/bold bright_red]",
    "web": "[bold blue]Web[/bold blue]",
    "youtube": "[bold red]YT[/bold red]",
}


@trend_app.command("search")
def trend_search(
    query: str = typer.Argument(..., help="Search query (e.g. 'AI agents 2025')."),
    platform: str = typer.Option(
        "all", "--platform", "-p",
        help="Platform to search: all, hn, reddit, web.",
    ),
    limit: int = typer.Option(10, "--limit", "-l", help="Max results to return."),
    json_out: bool = typer.Option(False, "--json", help="Output raw JSON."),
):
    """Search across multiple platforms for recent discussions on a topic."""
    searcher = get_trend_searcher()

    with console.status(f"[bold green]Searching for '{query}'...", spinner="dots"):
        if platform == "all":
            results = searcher.search_all(query, limit=limit)
        else:
            results = searcher.search_platform(query, platform, limit=limit)

    if not results:
        console.print(f"[yellow]No results found for '{query}'.[/yellow]")
        raise typer.Exit()

    if json_out:
        console.print(json.dumps([r.to_dict() for r in results], indent=2))
        return

    table = Table(
        title=f"Trend Search: {query}",
        show_lines=True,
        title_style="bold cyan",
    )
    table.add_column("#", style="dim", width=3, justify="right")
    table.add_column("Source", width=8, justify="center")
    table.add_column("Title", min_width=30)
    table.add_column("Score", width=6, justify="right")
    table.add_column("Date", width=12)

    for i, r in enumerate(results, 1):
        badge = _SOURCE_BADGES.get(r.source, r.source)
        score_str = f"{r.score:.1f}" if r.score else "-"
        date_str = r.date[:10] if r.date else "-"
        title_text = f"[link={r.url}]{r.title}[/link]" if r.title else "-"
        table.add_row(str(i), badge, title_text, score_str, date_str)

    console.print(table)
    console.print(f"\n[dim]{len(results)} results from {len(set(r.source for r in results))} platform(s)[/dim]")


@trend_app.command("report")
def trend_report(
    query: str = typer.Argument(..., help="Research topic for the trend report."),
    output: Optional[str] = typer.Option(
        None, "--output", "-o",
        help="Save report to file (e.g. report.md).",
    ),
    limit: int = typer.Option(15, "--limit", "-l", help="Max results per report."),
):
    """Generate a full markdown trend report from multi-platform search."""
    searcher = get_trend_searcher()

    with console.status(f"[bold green]Researching '{query}' across platforms...", spinner="dots"):
        results = searcher.search_all(query, limit=limit)

    if not results:
        console.print(f"[yellow]No results found for '{query}'.[/yellow]")
        raise typer.Exit()

    report = searcher.generate_report(query, results)

    if output:
        out_path = Path(output)
        out_path.write_text(report, encoding="utf-8")
        console.print(Panel(
            f"[green]Report saved to [bold]{out_path}[/bold][/green]\n"
            f"Results: {len(results)} from {len(set(r.source for r in results))} platforms",
            title="Trend Report",
            border_style="green",
        ))
    else:
        from rich.markdown import Markdown
        console.print(Markdown(report))


@trend_app.command("platforms")
def trend_platforms():
    """List available search platforms and API key status."""
    brave_key = os.environ.get("BRAVE_API_KEY", "")

    table = Table(title="Available Platforms", show_lines=True, title_style="bold cyan")
    table.add_column("Platform", style="bold")
    table.add_column("API Key", width=12, justify="center")
    table.add_column("Status", width=12, justify="center")
    table.add_column("Notes")

    table.add_row(
        "Hacker News",
        "[dim]not needed[/dim]",
        "[green]ready[/green]",
        "Free Algolia API — no key required",
    )
    table.add_row(
        "Reddit",
        "[dim]not needed[/dim]",
        "[green]ready[/green]",
        "Public JSON endpoint — no key required",
    )
    table.add_row(
        "Web (Brave)",
        "[green]set[/green]" if brave_key else "[red]missing[/red]",
        "[green]ready[/green]" if brave_key else "[yellow]optional[/yellow]",
        "Set BRAVE_API_KEY for web search" if not brave_key else "Brave Search API active",
    )

    console.print(table)
    console.print("\n[dim]Tip: export BRAVE_API_KEY=<key> to enable web search via Brave.[/dim]")
