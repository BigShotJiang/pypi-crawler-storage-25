"""Hooks Lifecycle System — inspired by CodeBuddy Code's Hooks.

Hooks are user-defined shell commands that execute at different stages of the
agent lifecycle, providing deterministic control over agent behavior.

Event types (borrowed from CodeBuddy):
- PreToolUse:    Before a tool call (can block)
- PostToolUse:   After a tool call completes
- UserPromptSubmit: After user submits prompt, before processing
- Notification:  When agent sends a notification
- Stop:          When agent finishes a response
- SubagentStop:  When a sub-agent task completes
- PreCompact:    Before context compaction
- SessionStart:  When a session starts
- SessionEnd:    When a session ends

Configuration:
- User hooks:    ~/.superagent/hooks/hooks.json
- Project hooks: .superagent/hooks/hooks.json (project root)
"""

from __future__ import annotations

import json
import logging
import os
import subprocess
import re
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Event types
# ---------------------------------------------------------------------------

class HookEvent:
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    USER_PROMPT_SUBMIT = "UserPromptSubmit"
    NOTIFICATION = "Notification"
    STOP = "Stop"
    SUBAGENT_STOP = "SubagentStop"
    PRE_COMPACT = "PreCompact"
    SESSION_START = "SessionStart"
    SESSION_END = "SessionEnd"

    ALL = [
        PRE_TOOL_USE,
        POST_TOOL_USE,
        USER_PROMPT_SUBMIT,
        NOTIFICATION,
        STOP,
        SUBAGENT_STOP,
        PRE_COMPACT,
        SESSION_START,
        SESSION_END,
    ]


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class HookDefinition:
    """A single hook command definition."""

    type: str = "command"  # always "command" for now
    command: str = ""

    def to_dict(self) -> dict:
        return {"type": self.type, "command": self.command}

    @classmethod
    def from_dict(cls, data: dict) -> HookDefinition:
        return cls(type=data.get("type", "command"), command=data.get("command", ""))


@dataclass
class HookMatcher:
    """A matcher that filters which tools/events a hook applies to."""

    matcher: str = ""  # tool name pattern, e.g., "Bash", "Edit|Write", "mcp__github__.*"
    hooks: list[HookDefinition] = field(default_factory=list)

    def matches(self, tool_name: str) -> bool:
        """Check if this matcher applies to the given tool name."""
        if not self.matcher or self.matcher == "*":
            return True
        # Support pipe-separated OR patterns
        patterns = [p.strip() for p in self.matcher.split("|")]
        for pattern in patterns:
            try:
                if re.match(pattern, tool_name, re.IGNORECASE):
                    return True
            except re.error:
                if pattern.lower() == tool_name.lower():
                    return True
        return False

    def to_dict(self) -> dict:
        return {
            "matcher": self.matcher,
            "hooks": [h.to_dict() for h in self.hooks],
        }

    @classmethod
    def from_dict(cls, data: dict) -> HookMatcher:
        hooks = [HookDefinition.from_dict(h) for h in data.get("hooks", [])]
        return cls(matcher=data.get("matcher", ""), hooks=hooks)


@dataclass
class HookResult:
    """Result from executing a hook."""

    success: bool = True
    output: str = ""
    decision: str = "continue"  # continue | block
    reason: str = ""


# ---------------------------------------------------------------------------
# Hook Store
# ---------------------------------------------------------------------------

class HookStore:
    """Manages hook configurations and execution.

    Inspired by CodeBuddy's hooks.json format:
    {
        "hooks": {
            "PreToolUse": [
                {
                    "matcher": "Bash",
                    "hooks": [{"type": "command", "command": "..."}]
                }
            ]
        }
    }
    """

    def __init__(self, data_dir: Optional[str] = None, project_dir: Optional[str] = None):
        if data_dir is None:
            data_dir = os.environ.get(
                "CLAWTEAM_DATA_DIR",
                os.path.join(os.path.expanduser("~"), ".superagent"),
            )
        self._data_dir = data_dir
        self._user_hooks_path = os.path.join(data_dir, "hooks", "hooks.json")
        self._project_hooks_path = (
            os.path.join(project_dir, ".superagent", "hooks", "hooks.json")
            if project_dir else None
        )
        # hooks[event_name] -> list[HookMatcher]
        self._hooks: dict[str, list[HookMatcher]] = {event: [] for event in HookEvent.ALL}
        self._load()

    def _load(self) -> None:
        """Load hook configurations from user and project files."""
        self._load_from_file(self._user_hooks_path)
        if self._project_hooks_path:
            self._load_from_file(self._project_hooks_path)

    def _load_from_file(self, filepath: str) -> None:
        """Load hooks from a single JSON file."""
        path = Path(filepath)
        if not path.is_file():
            return
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            hooks_data = data.get("hooks", {})
            for event_name, matchers in hooks_data.items():
                if event_name not in HookEvent.ALL:
                    logger.warning("Unknown hook event: %s", event_name)
                    continue
                for matcher_data in matchers:
                    matcher = HookMatcher.from_dict(matcher_data)
                    self._hooks[event_name].append(matcher)
        except (json.JSONDecodeError, KeyError, OSError) as e:
            logger.warning("Failed to load hooks from %s: %s", filepath, e)

    def save(self, scope: str = "user") -> None:
        """Save hook configuration to disk."""
        filepath = self._user_hooks_path
        if scope == "project" and self._project_hooks_path:
            filepath = self._project_hooks_path

        os.makedirs(os.path.dirname(filepath), exist_ok=True)
        data = {
            "hooks": {
                event: [m.to_dict() for m in matchers]
                for event, matchers in self._hooks.items()
                if matchers
            }
        }
        atomic_write(Path(filepath), json.dumps(data, indent=2, ensure_ascii=False) + "\n")

    def reload(self) -> None:
        """Reload all hooks from disk."""
        self._hooks = {event: [] for event in HookEvent.ALL}
        self._load()

    # ------------------------------------------------------------------
    # Hook management
    # ------------------------------------------------------------------

    def add_hook(self, event: str, matcher: str, command: str) -> None:
        """Add a hook for a specific event and matcher pattern."""
        if event not in HookEvent.ALL:
            raise ValueError(f"Unknown event: {event}. Must be one of: {', '.join(HookEvent.ALL)}")

        hook_def = HookDefinition(type="command", command=command)
        # Find existing matcher or create new one
        for m in self._hooks[event]:
            if m.matcher == matcher:
                m.hooks.append(hook_def)
                self.save()
                return

        # New matcher
        self._hooks[event].append(HookMatcher(matcher=matcher, hooks=[hook_def]))
        self.save()

    def remove_hook(self, event: str, matcher: str, command_index: int = -1) -> bool:
        """Remove a hook. If command_index is -1, remove all hooks for the matcher."""
        if event not in self._hooks:
            return False

        for i, m in enumerate(self._hooks[event]):
            if m.matcher == matcher:
                if command_index == -1:
                    self._hooks[event].pop(i)
                elif 0 <= command_index < len(m.hooks):
                    m.hooks.pop(command_index)
                    if not m.hooks:
                        self._hooks[event].pop(i)
                else:
                    return False
                self.save()
                return True
        return False

    def list_hooks(self, event: Optional[str] = None) -> dict[str, list[HookMatcher]]:
        """List hooks, optionally filtered by event."""
        if event:
            return {event: self._hooks.get(event, [])}
        return dict(self._hooks)

    # ------------------------------------------------------------------
    # Hook execution
    # ------------------------------------------------------------------

    def execute_hooks(
        self,
        event: str,
        tool_name: str = "",
        tool_input: Optional[dict] = None,
        timeout: int = 60,
    ) -> list[HookResult]:
        """Execute all matching hooks for a given event.

        Inspired by CodeBuddy's hook execution:
        - Hooks receive JSON input via stdin with tool_name and tool_input
        - Hook output (stdout) is captured
        - A hook can block the operation by exiting with code 2
        - A hook can deny with a message by outputting JSON with "decision": "block"

        Returns list of HookResult for each executed hook.
        """
        results: list[HookResult] = []

        if event not in self._hooks:
            return results

        # Build JSON input for the hook
        hook_input = json.dumps({
            "event": event,
            "tool_name": tool_name,
            "tool_input": tool_input or {},
        }, ensure_ascii=False)

        for matcher in self._hooks[event]:
            if tool_name and not matcher.matches(tool_name):
                continue

            for hook_def in matcher.hooks:
                result = self._execute_single_hook(hook_def, hook_input, timeout)
                results.append(result)

                # If a hook blocks, stop executing further hooks
                if result.decision == "block":
                    return results

        return results

    def _execute_single_hook(
        self,
        hook: HookDefinition,
        stdin_data: str,
        timeout: int,
    ) -> HookResult:
        """Execute a single hook command."""
        if hook.type != "command" or not hook.command:
            return HookResult(success=True, decision="continue")

        try:
            proc = subprocess.run(
                hook.command,
                shell=True,
                input=stdin_data,
                capture_output=True,
                text=True,
                timeout=timeout,
            )

            output = (proc.stdout or "").strip()
            decision = "continue"
            reason = ""

            # Exit code 2 = block (CodeBuddy convention)
            if proc.returncode == 2:
                decision = "block"
                reason = output or "Blocked by hook"
            elif proc.returncode != 0:
                logger.warning("Hook exited with code %d: %s", proc.returncode, proc.stderr)
                # Non-zero exit (not 2) = warning but continue
                decision = "continue"
                reason = f"Hook warning (exit {proc.returncode}): {(proc.stderr or '')[:200]}"

            # Check for JSON-formatted block response
            if output and decision != "block":
                try:
                    response = json.loads(output)
                    if response.get("decision") == "block":
                        decision = "block"
                        reason = response.get("reason", "Blocked by hook")
                except (json.JSONDecodeError, KeyError):
                    pass

            return HookResult(
                success=proc.returncode == 0 or decision == "block",
                output=output[:2000],
                decision=decision,
                reason=reason,
            )

        except subprocess.TimeoutExpired:
            logger.warning("Hook timed out: %s", hook.command[:100])
            return HookResult(success=False, decision="continue", reason="Hook timed out")
        except Exception as e:
            logger.warning("Hook execution error: %s", e)
            return HookResult(success=False, decision="continue", reason=str(e)[:200])


# ---------------------------------------------------------------------------
# Convenience: trigger hooks from the agent loop
# ---------------------------------------------------------------------------

def trigger_hooks(
    event: str,
    tool_name: str = "",
    tool_input: Optional[dict] = None,
    data_dir: Optional[str] = None,
) -> list[HookResult]:
    """Trigger hooks for a given event. Convenience function for use in agent loops."""
    store = HookStore(data_dir=data_dir)
    return store.execute_hooks(event, tool_name=tool_name, tool_input=tool_input)


def should_block(event: str, tool_name: str = "", tool_input: Optional[dict] = None) -> tuple[bool, str]:
    """Check if any hook blocks the operation. Returns (is_blocked, reason)."""
    results = trigger_hooks(event, tool_name=tool_name, tool_input=tool_input)
    for result in results:
        if result.decision == "block":
            return True, result.reason
    return False, ""


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_hook_store_instance: Optional[HookStore] = None


def get_hook_store(data_dir: Optional[str] = None, project_dir: Optional[str] = None) -> HookStore:
    """Return a singleton HookStore instance."""
    global _hook_store_instance
    if _hook_store_instance is None:
        _hook_store_instance = HookStore(data_dir=data_dir, project_dir=project_dir)
    return _hook_store_instance
