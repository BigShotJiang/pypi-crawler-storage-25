"""File-edit Checkpoint/Rewind system for SuperAgent.

Inspired by CodeBuddy CLI's Checkpointing feature.  Automatically tracks file
edits made by agents so that unwanted changes can be reverted.  Every user prompt
(or agent step) triggers a checkpoint that snapshots the current content of files
about to be modified, enabling ``/rewind``-style rollback.

This is **complementary** to the existing :pymod:`superagent.checkpoint` module
which handles workflow-stage checkpoints (pause/resume).  This module handles
**file-level** checkpoints (snapshot/revert of individual file edits).

Storage layout under *data_dir*/rewind/::

    rewind/
    ├── {checkpoint_id}.json       # full snapshot
    └── index.json                 # session → [checkpoint_ids] mapping
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def _data_dir() -> Path:
    """Return the SuperAgent data directory."""
    return Path(
        os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    )


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class FileCheckpoint:
    """A snapshot of file contents captured before an agent edit.

    Attributes
    ----------
    id:
        Unique checkpoint identifier (UUID hex).
    session_id:
        The session this checkpoint belongs to.
    agent_name:
        Name of the agent that is about to edit files.
    timestamp:
        ISO-8601 UTC timestamp of when the checkpoint was created.
    description:
        Human-readable description (e.g. "before refactoring auth module").
    files_snapshot:
        Mapping of file path → content *before* the edit.  Files that don't
        exist yet have a value of ``None``.
    files_changed:
        List of file paths that are expected to change.
    additions:
        Estimated number of lines added (populated after the edit).
    deletions:
        Estimated number of lines removed (populated after the edit).
    """

    id: str = ""
    session_id: str = ""
    agent_name: str = ""
    timestamp: str = ""
    description: str = ""
    files_snapshot: dict[str, Optional[str]] = field(default_factory=dict)
    files_changed: list[str] = field(default_factory=list)
    additions: int = 0
    deletions: int = 0

    def to_dict(self) -> dict:
        d = asdict(self)
        # Convert None values to a JSON-friendly marker
        snap: dict = {}
        for k, v in d["files_snapshot"].items():
            snap[k] = v if v is not None else "__DELETED__"
        d["files_snapshot"] = snap
        return d

    @classmethod
    def from_dict(cls, data: dict) -> FileCheckpoint:
        snap: dict = {}
        for k, v in data.get("files_snapshot", {}).items():
            snap[k] = None if v == "__DELETED__" else v
        return cls(
            id=data.get("id", ""),
            session_id=data.get("session_id", ""),
            agent_name=data.get("agent_name", ""),
            timestamp=data.get("timestamp", ""),
            description=data.get("description", ""),
            files_snapshot=snap,
            files_changed=data.get("files_changed", []),
            additions=data.get("additions", 0),
            deletions=data.get("deletions", 0),
        )


# ---------------------------------------------------------------------------
# Manager
# ---------------------------------------------------------------------------


class CheckpointManager:
    """Manages file-edit checkpoints with snapshot and revert capabilities.

    Parameters
    ----------
    data_dir:
        Root data directory.  Defaults to ``~/.superagent``.
    """

    def __init__(self, data_dir: Optional[str | Path] = None) -> None:
        self._base = Path(data_dir) / "rewind" if data_dir else _data_dir() / "rewind"
        self._base.mkdir(parents=True, exist_ok=True)
        self._index_path = self._base / "index.json"
        self._index: dict[str, list[str]] = self._load_index()

    # ------------------------------------------------------------------
    # Index helpers
    # ------------------------------------------------------------------

    def _load_index(self) -> dict[str, list[str]]:
        """Load the session → checkpoint_ids index."""
        if self._index_path.exists():
            try:
                return json.loads(self._index_path.read_text(encoding="utf-8"))
            except (json.JSONDecodeError, OSError):
                return {}
        return {}

    def _save_index(self) -> None:
        """Persist the index to disk."""
        atomic_write(self._index_path, json.dumps(self._index, indent=2, ensure_ascii=False))

    def _add_to_index(self, session_id: str, checkpoint_id: str) -> None:
        ids = self._index.setdefault(session_id, [])
        ids.append(checkpoint_id)
        self._save_index()

    def _remove_from_index(self, session_id: str, checkpoint_id: str) -> None:
        ids = self._index.get(session_id, [])
        if checkpoint_id in ids:
            ids.remove(checkpoint_id)
        if not ids:
            self._index.pop(session_id, None)
        self._save_index()

    # ------------------------------------------------------------------
    # Checkpoint file I/O
    # ------------------------------------------------------------------

    def _cp_path(self, checkpoint_id: str) -> Path:
        return self._base / f"{checkpoint_id}.json"

    def _write_checkpoint(self, cp: FileCheckpoint) -> None:
        path = self._cp_path(cp.id)
        atomic_write(path, json.dumps(cp.to_dict(), indent=2, ensure_ascii=False))

    def _read_checkpoint(self, checkpoint_id: str) -> Optional[FileCheckpoint]:
        path = self._cp_path(checkpoint_id)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return FileCheckpoint.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError) as exc:
            logger.warning("Failed to read checkpoint %s: %s", checkpoint_id, exc)
            return None

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def snapshot(
        self,
        session_id: str,
        agent_name: str,
        files_changed: list[str],
        description: str = "",
    ) -> FileCheckpoint:
        """Create a checkpoint by snapshotting the current content of *files_changed*.

        Call this **before** an agent edits the files so the original content
        is preserved for potential rollback.

        Parameters
        ----------
        session_id:
            The active session identifier.
        agent_name:
            Name of the agent about to perform edits.
        files_changed:
            File paths that will be modified.
        description:
            Optional human-readable note (e.g. "refactor auth module").

        Returns
        -------
        FileCheckpoint
            The newly created checkpoint.
        """
        cp_id = uuid.uuid4().hex[:16]
        files_snapshot: dict[str, Optional[str]] = {}

        for fpath in files_changed:
            p = Path(fpath)
            if p.exists() and p.is_file():
                try:
                    files_snapshot[fpath] = p.read_text(encoding="utf-8")
                except OSError as exc:
                    logger.warning("Cannot read %s for snapshot: %s", fpath, exc)
                    files_snapshot[fpath] = None
            else:
                # File doesn't exist yet (will be created by the agent)
                files_snapshot[fpath] = None

        cp = FileCheckpoint(
            id=cp_id,
            session_id=session_id,
            agent_name=agent_name,
            timestamp=_now_iso(),
            description=description,
            files_snapshot=files_snapshot,
            files_changed=list(files_changed),
        )
        self._write_checkpoint(cp)
        self._add_to_index(session_id, cp_id)
        logger.info(
            "Checkpoint %s created for session %s (%d files)",
            cp_id, session_id, len(files_changed),
        )
        return cp

    def list_checkpoints(
        self,
        session_id: Optional[str] = None,
        limit: int = 50,
    ) -> list[FileCheckpoint]:
        """List checkpoints, optionally filtered by session.

        Returns checkpoints ordered by timestamp (newest first).
        """
        if session_id:
            ids = self._index.get(session_id, [])
        else:
            # Collect all checkpoint IDs from all sessions
            ids = []
            for session_ids in self._index.values():
                ids.extend(session_ids)

        checkpoints: list[FileCheckpoint] = []
        for cp_id in ids:
            cp = self._read_checkpoint(cp_id)
            if cp is not None:
                checkpoints.append(cp)

        checkpoints.sort(key=lambda c: c.timestamp, reverse=True)
        return checkpoints[:limit]

    def get_checkpoint(self, checkpoint_id: str) -> Optional[FileCheckpoint]:
        """Retrieve a single checkpoint by ID."""
        return self._read_checkpoint(checkpoint_id)

    def revert_code(
        self,
        checkpoint_id: str,
        paths: Optional[list[str]] = None,
    ) -> dict:
        """Revert file changes to the state captured in a checkpoint.

        Parameters
        ----------
        checkpoint_id:
            The checkpoint to revert to.
        paths:
            Optional list of specific file paths to revert.  If ``None``,
            all files in the checkpoint are reverted.

        Returns
        -------
        dict
            ``{"success": bool, "reverted_files": [...], "errors": [...]}``
        """
        cp = self._read_checkpoint(checkpoint_id)
        if cp is None:
            return {"success": False, "reverted_files": [], "errors": [f"Checkpoint {checkpoint_id} not found"]}

        target_paths = paths if paths else cp.files_changed
        reverted: list[str] = []
        errors: list[str] = []

        for fpath in target_paths:
            if fpath not in cp.files_snapshot:
                errors.append(f"File {fpath} not in checkpoint snapshot")
                continue

            original_content = cp.files_snapshot[fpath]
            p = Path(fpath)

            try:
                if original_content is None:
                    # File was created by the agent — delete it to revert
                    if p.exists():
                        p.unlink()
                        logger.info("Deleted file (revert): %s", fpath)
                    reverted.append(fpath)
                else:
                    # Restore original content
                    atomic_write(fpath, original_content)
                    logger.info("Restored file (revert): %s", fpath)
                    reverted.append(fpath)
            except OSError as exc:
                errors.append(f"Failed to revert {fpath}: {exc}")
                logger.error("Failed to revert %s: %s", fpath, exc)

        return {
            "success": len(errors) == 0,
            "reverted_files": reverted,
            "errors": errors,
        }

    def revert_all(self, checkpoint_id: str) -> dict:
        """Revert both code and conversation state to a checkpoint.

        This reverts all file changes and marks the conversation as rewound.

        Returns
        -------
        dict
            ``{"success": bool, "reverted_files": [...], "errors": [...], "conversation_rewound": bool}``
        """
        code_result = self.revert_code(checkpoint_id)
        # Mark conversation as rewound by updating the checkpoint description
        cp = self._read_checkpoint(checkpoint_id)
        conversation_rewound = False
        if cp is not None:
            cp.description = f"[REWOUND] {cp.description}"
            self._write_checkpoint(cp)
            conversation_rewound = True

        return {
            **code_result,
            "conversation_rewound": conversation_rewound,
        }

    def get_diff(self, checkpoint_id: str, path: str) -> Optional[dict]:
        """Get the diff between a checkpoint's snapshot and the current file state.

        Returns a unified diff string, or ``None`` if the checkpoint or file
        is not found.
        """
        cp = self._read_checkpoint(checkpoint_id)
        if cp is None:
            return None

        original = cp.files_snapshot.get(path)
        p = Path(path)
        current: Optional[str] = None
        if p.exists() and p.is_file():
            try:
                current = p.read_text(encoding="utf-8")
            except OSError:
                current = None

        import difflib
        original_lines = (original or "").splitlines(keepends=True)
        current_lines = (current or "").splitlines(keepends=True)

        diff = difflib.unified_diff(
            original_lines,
            current_lines,
            fromfile=f"{path} (checkpoint)",
            tofile=f"{path} (current)",
        )

        return {
            "path": path,
            "old_text": original,
            "new_text": current,
            "diff": "".join(diff),
            "has_changes": original != current,
        }

    def cleanup(self, ttl_days: int = 30) -> int:
        """Remove checkpoints older than *ttl_days*.

        Returns the number of checkpoints removed.
        """
        cutoff = datetime.now(timezone.utc)
        removed = 0

        sessions_to_prune: list[tuple[str, str]] = []
        for session_id, cp_ids in list(self._index.items()):
            for cp_id in cp_ids:
                cp = self._read_checkpoint(cp_id)
                if cp is None:
                    sessions_to_prune.append((session_id, cp_id))
                    continue
                try:
                    ts = datetime.fromisoformat(cp.timestamp)
                    age = (cutoff - ts).days
                    if age > ttl_days:
                        sessions_to_prune.append((session_id, cp_id))
                except (ValueError, TypeError):
                    # Malformed timestamp — remove it
                    sessions_to_prune.append((session_id, cp_id))

        for session_id, cp_id in sessions_to_prune:
            # Delete checkpoint file
            cp_path = self._cp_path(cp_id)
            if cp_path.exists():
                cp_path.unlink()
            self._remove_from_index(session_id, cp_id)
            removed += 1

        if removed:
            logger.info("Cleaned up %d old checkpoints (TTL=%d days)", removed, ttl_days)
        return removed

    # ------------------------------------------------------------------
    # Integration helpers
    # ------------------------------------------------------------------

    def create_pre_edit_snapshot(
        self,
        session_id: str,
        agent_name: str,
        file_paths: list[str],
        description: str = "",
    ) -> FileCheckpoint:
        """Convenience helper for execution engines.

        Reads the current content of *file_paths* and creates a checkpoint.
        This should be called **before** each agent action that modifies files.

        Example usage in an execution engine::

            from superagent.checkpoint_system import get_checkpoint_manager

            mgr = get_checkpoint_manager()
            mgr.create_pre_edit_snapshot(
                session_id="sess-123",
                agent_name="frontend-dev",
                file_paths=["/src/App.tsx", "/src/utils.ts"],
                description="before adding dark mode",
            )
            # ... agent edits files ...
        """
        return self.snapshot(
            session_id=session_id,
            agent_name=agent_name,
            files_changed=file_paths,
            description=description,
        )


# ---------------------------------------------------------------------------
# Factory
# ---------------------------------------------------------------------------

_manager_instance: Optional[CheckpointManager] = None


def get_checkpoint_manager(data_dir: Optional[str | Path] = None) -> CheckpointManager:
    """Return a singleton CheckpointManager.

    Uses CLAWTEAM_DATA_DIR env var, falling back to ``~/.superagent``.
    """
    global _manager_instance
    if _manager_instance is None or data_dir is not None:
        _manager_instance = CheckpointManager(data_dir)
    return _manager_instance
