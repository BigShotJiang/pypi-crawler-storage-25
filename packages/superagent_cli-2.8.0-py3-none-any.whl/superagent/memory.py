"""Layered memory system for SuperAgent — persistent, scoped memory with search.

Inspired by Letta/MemGPT Memory Blocks and the Memory Governance Protocol (MGP).
Provides agent-level, team-level, and global memory scopes persisted as JSON files
under ~/.superagent/memory/.
"""

from __future__ import annotations

import json
import logging
import os
import uuid
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Optional

logger = logging.getLogger(__name__)


class MemoryScope(str, Enum):
    """Scope levels for memory entries."""

    agent = "agent"
    team = "team"
    global_ = "global"


class MemoryLayer(str, Enum):
    """Three memory layers inspired by Hermes Agent's architecture."""
    conversation = "conversation"  # Short-term: current session context
    persistent = "persistent"      # Medium-term: cross-session knowledge
    skill = "skill"                # Long-term: reusable patterns and expertise


@dataclass
class MemoryEntry:
    """A single memory record with metadata and lifecycle management."""

    id: str
    content: str
    tags: list[str]
    scope: MemoryScope
    agent_name: Optional[str] = None
    team_name: Optional[str] = None
    created_at: str = ""
    updated_at: str = ""
    expires_at: Optional[str] = None
    layer: str = "persistent"  # conversation/persistent/skill

    @property
    def is_expired(self) -> bool:
        """Check whether this entry has passed its expiration time."""
        if self.expires_at is None:
            return False
        try:
            exp = datetime.fromisoformat(self.expires_at)
            return datetime.now(timezone.utc) > exp
        except (ValueError, TypeError):
            return False

    def to_dict(self) -> dict:
        """Serialize to a plain dict suitable for JSON storage."""
        d = asdict(self)
        scope = self.scope
        d["scope"] = scope.value if isinstance(scope, MemoryScope) else str(scope)
        return d

    @classmethod
    def from_dict(cls, data: dict) -> MemoryEntry:
        """Deserialize from a dict loaded from JSON."""
        scope_val = data.get("scope", "global")
        # Normalize the enum value
        if scope_val == "global":
            scope = MemoryScope.global_
        else:
            scope = MemoryScope(scope_val)
        return cls(
            id=data["id"],
            content=data["content"],
            tags=data.get("tags", []),
            scope=scope,
            agent_name=data.get("agent_name"),
            team_name=data.get("team_name"),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
            expires_at=data.get("expires_at"),
        )


@dataclass
class AuditEntry:
    """Immutable audit record for MGP compliance."""

    timestamp: str  # ISO-8601
    operation: str  # write/update/delete/expire/revoke/search/export
    memory_id: str
    actor: str  # who performed the operation (agent name or "system")
    details: str  # human-readable description

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> AuditEntry:
        return cls(
            timestamp=data["timestamp"],
            operation=data["operation"],
            memory_id=data["memory_id"],
            actor=data["actor"],
            details=data.get("details", ""),
        )


def _now_iso() -> str:
    """Return current UTC time as an ISO-8601 string."""
    return datetime.now(timezone.utc).isoformat()


class MemoryStore:
    """Manages layered memory entries persisted as JSON files.

    Directory layout under *base_dir*::

        memory/
        ├── agent/{agent_name}/{id}.json
        ├── team/{team_name}/{id}.json
        └── global/{id}.json
    """

    def __init__(self, base_dir: str | Path) -> None:
        self._base = Path(base_dir) / "memory"
        self._base.mkdir(parents=True, exist_ok=True)
        self._audit_path = self._base / "audit_log.jsonl"
        # SQLite backend (Hermes pattern) — scoped to this memory dir
        from superagent.db import get_db, migrate_memory_from_json
        db_path = str(Path(base_dir) / "memory.db")
        self._db = get_db(db_path=db_path)
        migrate_memory_from_json(self._db, str(self._base))

    # ------------------------------------------------------------------
    # Path helpers
    # ------------------------------------------------------------------

    def _scope_dir(
        self,
        scope: MemoryScope,
        agent_name: Optional[str] = None,
        team_name: Optional[str] = None,
    ) -> Path:
        """Return the directory for a given scope (and optional owner name)."""
        if scope == MemoryScope.agent:
            if not agent_name:
                raise ValueError("agent_name is required for agent-scoped memories")
            return self._base / "agent" / agent_name
        if scope == MemoryScope.team:
            if not team_name:
                raise ValueError("team_name is required for team-scoped memories")
            return self._base / "team" / team_name
        return self._base / "global"

    def _entry_path(self, entry: MemoryEntry) -> Path:
        d = self._scope_dir(entry.scope, entry.agent_name, entry.team_name)
        return d / f"{entry.id}.json"

    def _save_entry(self, entry: MemoryEntry, *, _commit: bool = True) -> None:
        """Persist a MemoryEntry to SQLite and update the FTS index.

        Parameters
        ----------
        entry:
            The memory entry to persist.
        _commit:
            When True (default), commit immediately.  Set to False when
            the caller wants to batch several writes into a single
            transaction and will commit manually.
        """
        scope_val = entry.scope.value if isinstance(entry.scope, MemoryScope) else str(entry.scope)
        tags_json = json.dumps(entry.tags)
        self._db.execute(
            """INSERT OR REPLACE INTO memories
               (id, content, tags, scope, agent_name, team_name, layer,
                created_at, updated_at, expires_at, revoked)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (entry.id, entry.content, tags_json, scope_val,
             entry.agent_name, entry.team_name, entry.layer,
             entry.created_at, entry.updated_at, entry.expires_at, 0),
        )
        # Update standalone FTS
        self._db.execute("DELETE FROM memories_fts WHERE id = ?", (entry.id,))
        self._db.execute(
            "INSERT INTO memories_fts (id, content, tags) VALUES (?, ?, ?)",
            (entry.id, entry.content, tags_json),
        )
        if _commit:
            self._db.commit()

    def _load_entry(self, path: Path) -> Optional[MemoryEntry]:
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return MemoryEntry.from_dict(data)
        except (json.JSONDecodeError, KeyError, OSError):
            return None

    @staticmethod
    def _is_revoked(path: Path) -> bool:
        """Check whether a JSON memory file has been soft-deleted (revoked)."""
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return "revoked_at" in data
        except (json.JSONDecodeError, OSError):
            return False

    # ------------------------------------------------------------------
    # Audit helpers (MGP compliance)
    # ------------------------------------------------------------------

    def _audit(self, operation: str, memory_id: str, actor: str = "system", details: str = "") -> None:
        """Record an audit entry to SQLite audit_log table."""
        self._db.execute(
            "INSERT INTO audit_log (timestamp, operation, memory_id, actor, details) VALUES (?, ?, ?, ?, ?)",
            (_now_iso(), operation, memory_id, actor, details),
        )
        self._db.commit()

    def get_audit_log(self, memory_id: str | None = None, operation: str | None = None, limit: int = 50) -> list[AuditEntry]:
        """Read and filter the audit log from SQLite."""
        sql = "SELECT * FROM audit_log WHERE 1=1"
        params: list = []
        if memory_id:
            sql += " AND memory_id = ?"
            params.append(memory_id)
        if operation:
            sql += " AND operation = ?"
            params.append(operation)
        sql += " ORDER BY id DESC LIMIT ?"
        params.append(limit)
        rows = self._db.execute(sql, params).fetchall()
        return [AuditEntry(
            timestamp=r["timestamp"], operation=r["operation"],
            memory_id=r["memory_id"], actor=r["actor"], details=r["details"],
        ) for r in rows]

    def revoke(self, memory_id: str, reason: str = "") -> bool:
        """MGP Revoke: soft-delete with audit trail."""
        cursor = self._db.execute(
            "UPDATE memories SET revoked = 1 WHERE id = ? AND revoked = 0",
            (memory_id,),
        )
        self._db.commit()
        if cursor.rowcount > 0:
            self._audit("revoke", memory_id, details=reason or "revoked")
            return True
        return False

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def write(
        self,
        content: str,
        tags: Optional[list[str]] = None,
        scope: MemoryScope = MemoryScope.global_,
        agent_name: Optional[str] = None,
        team_name: Optional[str] = None,
        expires_at: Optional[str] = None,
    ) -> MemoryEntry:
        """Create a new memory entry and persist it."""
        now = _now_iso()
        entry = MemoryEntry(
            id=uuid.uuid4().hex[:12],
            content=content,
            tags=tags or [],
            scope=scope,
            agent_name=agent_name,
            team_name=team_name,
            created_at=now,
            updated_at=now,
            expires_at=expires_at,
        )
        self._save_entry(entry)
        self._audit("write", entry.id, details=f"scope={scope.value if isinstance(scope, MemoryScope) else scope}")
        return entry

    def get(self, memory_id: str) -> Optional[MemoryEntry]:
        """Retrieve a memory entry by ID."""
        row = self._db.execute("SELECT * FROM memories WHERE id = ? AND revoked = 0", (memory_id,)).fetchone()
        if row is None:
            return None
        return self._row_to_entry(row)

    def search(
        self,
        query: str,
        scope: Optional[MemoryScope] = None,
        agent_name: Optional[str] = None,
        team_name: Optional[str] = None,
        limit: int = 10,
    ) -> list[MemoryEntry]:
        """Full-text search across memories using SQLite FTS5."""
        if not query or not query.strip():
            return []

        # Build FTS5 match query — escape special chars
        safe_query = " ".join(w + "*" for w in query.split() if w)

        try:
            sql = """
                SELECT m.* FROM memories m
                WHERE m.id IN (SELECT id FROM memories_fts WHERE memories_fts MATCH ?)
                AND m.revoked = 0
            """
            params: list = [safe_query]

            if scope is not None:
                scope_val = scope.value if isinstance(scope, MemoryScope) else str(scope)
                sql += " AND m.scope = ?"
                params.append(scope_val)
            if agent_name:
                sql += " AND m.agent_name = ?"
                params.append(agent_name)
            if team_name:
                sql += " AND m.team_name = ?"
                params.append(team_name)

            sql += " ORDER BY m.updated_at DESC LIMIT ?"
            params.append(limit)

            rows = self._db.execute(sql, params).fetchall()
            return [self._row_to_entry(r) for r in rows if not self._entry_is_expired(r)]
        except Exception as e:
            # Fallback to LIKE if FTS fails
            logger.warning("FTS5 search failed, falling back to LIKE: %s", e)
            return self._search_fallback(query, scope, agent_name, team_name, limit)

    def list_memories(
        self,
        scope: Optional[MemoryScope] = None,
        agent_name: Optional[str] = None,
        team_name: Optional[str] = None,
        limit: int = 500,
    ) -> list[MemoryEntry]:
        """List non-expired memory entries matching the given filters.

        Parameters
        ----------
        limit:
            Maximum number of rows to return (default 500).  Prevents
            unbounded memory consumption on large datasets.
        """
        sql = "SELECT * FROM memories WHERE revoked = 0"
        params: list = []
        if scope is not None:
            scope_val = scope.value if isinstance(scope, MemoryScope) else str(scope)
            sql += " AND scope = ?"
            params.append(scope_val)
        if agent_name:
            sql += " AND agent_name = ?"
            params.append(agent_name)
        if team_name:
            sql += " AND team_name = ?"
            params.append(team_name)
        sql += " ORDER BY updated_at DESC LIMIT ?"
        params.append(limit)
        rows = self._db.execute(sql, params).fetchall()
        return [self._row_to_entry(r) for r in rows if not self._entry_is_expired(r)]

    def update(
        self,
        memory_id: str,
        content: Optional[str] = None,
        tags: Optional[list[str]] = None,
    ) -> Optional[MemoryEntry]:
        """Update an existing memory entry. Returns the updated entry or None."""
        entry = self.get(memory_id)
        if entry is None:
            return None
        if content is not None:
            entry.content = content
        if tags is not None:
            entry.tags = tags
        entry.updated_at = _now_iso()
        self._save_entry(entry)
        self._audit("update", memory_id, details="content/tags updated")
        return entry

    def delete(self, memory_id: str) -> bool:
        """Delete a memory entry by ID. Returns True if found and deleted."""
        cursor = self._db.execute("DELETE FROM memories WHERE id = ?", (memory_id,))
        self._db.commit()
        if cursor.rowcount > 0:
            self._audit("delete", memory_id, details="permanently deleted")
            return True
        return False

    def purge_expired(self) -> int:
        """Remove all expired memory entries. Returns the count of purged entries."""
        now = datetime.now(timezone.utc).isoformat()
        cursor = self._db.execute(
            "DELETE FROM memories WHERE expires_at IS NOT NULL AND expires_at != '' AND expires_at < ?",
            (now,),
        )
        self._db.commit()
        return cursor.rowcount

    def write_conversation(self, content: str, tags: list[str] | None = None,
                           agent_name: str | None = None, team_name: str | None = None) -> MemoryEntry:
        """Quick write to conversation layer (auto-expires in 24h)."""
        from datetime import timedelta
        expires = (datetime.now(timezone.utc) + timedelta(hours=24)).isoformat()
        return self.write(content, tags=tags or [], scope=MemoryScope.agent,
                         agent_name=agent_name, team_name=team_name, expires_at=expires)

    def write_persistent(self, content: str, tags: list[str] | None = None,
                         scope: MemoryScope = MemoryScope.team, **kwargs) -> MemoryEntry:
        """Write to persistent layer (no expiry, cross-session)."""
        return self.write(content, tags=tags or [], scope=scope, **kwargs)

    def write_skill(self, content: str, tags: list[str] | None = None,
                    scope: MemoryScope = MemoryScope.global_, **kwargs) -> MemoryEntry:
        """Write to skill layer (long-term, reusable patterns)."""
        tags = (tags or []) + ["skill-memory"]
        return self.write(content, tags=tags, scope=scope, **kwargs)

    def get_context(self, agent_name: str | None = None, team_name: str | None = None,
                    limit: int = 20) -> dict:
        """Get combined context from all 3 layers for an agent.
        Returns dict with conversation, persistent, skill memories."""
        conversation = self.list_memories(scope=MemoryScope.agent, agent_name=agent_name)[-limit:]
        persistent = self.list_memories(scope=MemoryScope.team, team_name=team_name)[-limit:] if team_name else []
        skill = [m for m in self.list_memories(scope=MemoryScope.global_) if "skill-memory" in (m.tags if hasattr(m, 'tags') else [])][-limit:]
        return {
            "conversation": conversation,
            "persistent": persistent,
            "skill": skill,
            "total": len(conversation) + len(persistent) + len(skill),
        }

    def export_memories(
        self,
        scope: Optional[MemoryScope] = None,
        format: str = "json",
    ) -> str:
        """Export memories as a serialized string.

        Args:
            scope: Filter to a specific scope, or None for all.
            format: Output format (currently only "json" is supported).

        Returns:
            Serialized string of memory entries.
        """
        entries = self.list_memories(scope=scope)
        data = [e.to_dict() for e in entries]
        return json.dumps(data, indent=2, ensure_ascii=False)

    def import_memories(self, data: str | list[dict]) -> int:
        """Import memories from a JSON string or list of dicts.

        All entries are persisted in a single transaction for atomicity.

        Returns the number of entries imported.
        """
        if isinstance(data, str):
            data = json.loads(data)
        count = 0
        try:
            for item in data:
                entry = MemoryEntry.from_dict(item)
                # Assign new timestamps if missing
                if not entry.created_at:
                    entry.created_at = _now_iso()
                entry.updated_at = _now_iso()
                self._save_entry(entry, _commit=False)
                count += 1
            self._db.commit()
        except Exception:
            self._db.rollback()
            raise
        return count

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    # ------------------------------------------------------------------
    # SQLite helper methods
    # ------------------------------------------------------------------

    @staticmethod
    def _row_to_entry(row) -> MemoryEntry:
        """Convert a sqlite3.Row to a MemoryEntry."""
        scope_val = row["scope"] or "global"
        if scope_val == "global":
            scope = MemoryScope.global_
        else:
            scope = MemoryScope(scope_val)
        tags = []
        try:
            tags = json.loads(row["tags"]) if row["tags"] else []
        except (json.JSONDecodeError, TypeError):
            pass
        return MemoryEntry(
            id=row["id"],
            content=row["content"],
            tags=tags,
            scope=scope,
            agent_name=row["agent_name"],
            team_name=row["team_name"],
            created_at=row["created_at"] or "",
            updated_at=row["updated_at"] or "",
            expires_at=row["expires_at"],
            layer=row["layer"] or "persistent",
        )

    @staticmethod
    def _entry_is_expired(row) -> bool:
        exp = row["expires_at"]
        if not exp:
            return False
        try:
            return datetime.now(timezone.utc) > datetime.fromisoformat(exp)
        except (ValueError, TypeError):
            return False

    def _search_fallback(self, query, scope, agent_name, team_name, limit):
        """LIKE-based fallback when FTS5 query fails."""
        sql = "SELECT * FROM memories WHERE revoked = 0 AND content LIKE ?"
        params: list = [f"%{query}%"]
        if scope is not None:
            scope_val = scope.value if isinstance(scope, MemoryScope) else str(scope)
            sql += " AND scope = ?"
            params.append(scope_val)
        if agent_name:
            sql += " AND agent_name = ?"
            params.append(agent_name)
        if team_name:
            sql += " AND team_name = ?"
            params.append(team_name)
        sql += " LIMIT ?"
        params.append(limit)
        rows = self._db.execute(sql, params).fetchall()
        return [self._row_to_entry(r) for r in rows]

    def _iter_entries(
        self,
        scope: Optional[MemoryScope] = None,
        agent_name: Optional[str] = None,
        team_name: Optional[str] = None,
    ):
        """Yield MemoryEntry objects matching the given scope filters."""
        if scope is not None:
            try:
                scope_dir = self._scope_dir(scope, agent_name, team_name)
            except ValueError:
                # Missing required name for scoped query — fall back to scanning the scope root
                if scope == MemoryScope.agent:
                    scope_dir = self._base / "agent"
                elif scope == MemoryScope.team:
                    scope_dir = self._base / "team"
                else:
                    scope_dir = self._base / "global"
            if scope_dir.exists():
                for f in scope_dir.rglob("*.json"):
                    if self._is_revoked(f):
                        continue
                    entry = self._load_entry(f)
                    if entry:
                        yield entry
        else:
            # Scan all scopes
            for f in self._base.rglob("*.json"):
                if self._is_revoked(f):
                    continue
                entry = self._load_entry(f)
                if entry:
                    # Apply optional name filters
                    if agent_name and entry.agent_name != agent_name:
                        continue
                    if team_name and entry.team_name != team_name:
                        continue
                    yield entry


def get_memory_store(base_dir: Optional[str] = None) -> MemoryStore:
    """Factory — return a MemoryStore rooted at the project data directory.

    Uses CLAWTEAM_DATA_DIR env var, falling back to ``~/.superagent``.
    """
    if base_dir is None:
        base_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    return MemoryStore(base_dir)
