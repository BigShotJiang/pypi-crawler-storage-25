"""CLI commands for SuperAgent Mem0 semantic memory integration.

Provides the ``superagent mem0`` subcommand group with status, add, search,
list, delete, and history operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import logging
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

logger = logging.getLogger(__name__)

mem0_app = typer.Typer(
    name="mem0",
    help="Semantic memory (Mem0) — vector-search memory with add, search, list, delete, and history.",
    no_args_is_help=True,
)
console = Console()


def _get_store():
    """Create a Mem0Store, or exit with install instructions if unavailable."""
    from superagent.mem0_memory import Mem0Store, is_mem0_available

    if not is_mem0_available():
        console.print(Panel(
            "[bold red]Mem0 is not installed[/bold red]\n\n"
            "Install it with:\n\n"
            "  [bold cyan]pip install mem0ai[/bold cyan]\n\n"
            "Or add it to your project dependencies:\n\n"
            "  [bold cyan]uv add mem0ai[/bold cyan]\n\n"
            "Mem0 provides semantic vector-search memory powered by LLMs.\n"
            "Learn more: [link=https://github.com/mem0ai/mem0]https://github.com/mem0ai/mem0[/link]",
            title="Mem0 Not Available",
            border_style="red",
        ))
        raise typer.Exit(1)

    try:
        return Mem0Store()
    except Exception as e:
        console.print(f"[red]Failed to initialize Mem0: {e}[/red]")
        raise typer.Exit(1)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@mem0_app.command("status")
def mem0_status():
    """Check Mem0 availability and configuration."""
    import os

    from superagent.mem0_memory import Mem0Store, is_mem0_available

    available = is_mem0_available()

    if not available:
        console.print(Panel(
            "[bold red]Mem0 is NOT installed[/bold red]\n\n"
            "Install it with:\n\n"
            "  [bold cyan]pip install mem0ai[/bold cyan]\n\n"
            "Mem0 adds semantic vector-search memory to SuperAgent,\n"
            "upgrading the default keyword-based memory system.",
            title="Mem0 Status",
            border_style="red",
        ))
        return

    # Check for API keys
    openai_key = "set" if os.environ.get("OPENAI_API_KEY") else "not set"
    deepseek_key = "set" if os.environ.get("DEEPSEEK_API_KEY") else "not set"

    # Try to get version
    try:
        import mem0
        version = getattr(mem0, "__version__", "unknown")
    except Exception as e:
        logger.debug("Failed to get mem0 version: %s", e)
        version = "unknown"

    # Try to initialize
    init_status = "[green]OK[/green]"
    try:
        Mem0Store()
    except Exception as e:
        init_status = f"[red]Failed: {e}[/red]"

    console.print(Panel(
        f"[bold green]Mem0 is installed[/bold green]\n\n"
        f"  [bold]Version:[/bold]       {version}\n"
        f"  [bold]Init status:[/bold]   {init_status}\n"
        f"  [bold]OPENAI_API_KEY:[/bold] {openai_key}\n"
        f"  [bold]DEEPSEEK_API_KEY:[/bold] {deepseek_key}",
        title="Mem0 Status",
        border_style="green",
    ))


@mem0_app.command("add")
def mem0_add(
    content: str = typer.Argument(..., help="Memory content to store."),
    user: str = typer.Option("default", "--user", "-u", help="User ID for the memory."),
    agent: Optional[str] = typer.Option(None, "--agent", "-a", help="Agent ID to associate."),
):
    """Add a semantic memory."""
    store = _get_store()

    try:
        result = store.add(content, user_id=user, agent_id=agent)
    except Exception as e:
        console.print(f"[red]Error adding memory: {e}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold green]Memory added[/bold green]\n\n"
        f"  [bold]User:[/bold]  {user}\n"
        f"  [bold]Agent:[/bold] {agent or '(none)'}\n\n"
        f"  [dim]{result}[/dim]",
        title="mem0 add",
        border_style="green",
    ))


@mem0_app.command("search")
def mem0_search(
    query: str = typer.Argument(..., help="Semantic search query."),
    user: str = typer.Option("default", "--user", "-u", help="User ID to search within."),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results to return."),
):
    """Semantic search across memories."""
    store = _get_store()

    try:
        results = store.search(query, user_id=user, limit=limit)
    except Exception as e:
        console.print(f"[red]Error searching memories: {e}[/red]")
        raise typer.Exit(1)

    if not results:
        console.print(f"[yellow]No memories matching '{query}'.[/yellow]")
        return

    table = Table(title=f"Semantic Search: \"{query}\" ({len(results)} results)")
    table.add_column("ID", style="cyan", width=20)
    table.add_column("Memory", max_width=60)
    table.add_column("Score", style="green", width=8)

    for item in results:
        memory_id = item.get("id", "?")
        memory_text = item.get("memory", item.get("text", str(item)))
        score = item.get("score", "")
        score_str = f"{score:.3f}" if isinstance(score, float) else str(score)

        # Truncate long memories
        if len(memory_text) > 60:
            memory_text = memory_text[:57] + "..."

        table.add_row(memory_id, memory_text, score_str)

    console.print(table)


@mem0_app.command("list")
def mem0_list(
    user: str = typer.Option("default", "--user", "-u", help="User ID to list memories for."),
):
    """List all memories for a user."""
    store = _get_store()

    try:
        results = store.get_all(user_id=user)
    except Exception as e:
        console.print(f"[red]Error listing memories: {e}[/red]")
        raise typer.Exit(1)

    if not results:
        console.print(f"[yellow]No memories found for user '{user}'.[/yellow]")
        return

    table = Table(title=f"Memories for user \"{user}\" ({len(results)} entries)")
    table.add_column("ID", style="cyan", width=20)
    table.add_column("Memory", max_width=60)
    table.add_column("Created", style="dim", width=20)

    for item in results:
        memory_id = item.get("id", "?")
        memory_text = item.get("memory", item.get("text", str(item)))
        created = item.get("created_at", item.get("timestamp", ""))

        if len(memory_text) > 60:
            memory_text = memory_text[:57] + "..."
        if len(created) > 19:
            created = created[:19]

        table.add_row(memory_id, memory_text, created)

    console.print(table)


@mem0_app.command("delete")
def mem0_delete(
    memory_id: str = typer.Argument(..., help="Memory ID to delete."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
):
    """Delete a specific memory."""
    store = _get_store()

    if not force:
        confirm = typer.confirm(f"Delete memory {memory_id}?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    deleted = store.delete(memory_id)
    if deleted:
        console.print(f"[green]Deleted memory {memory_id}.[/green]")
    else:
        console.print(f"[red]Failed to delete memory {memory_id}.[/red]")
        raise typer.Exit(1)


@mem0_app.command("history")
def mem0_history(
    memory_id: str = typer.Argument(..., help="Memory ID to show history for."),
):
    """Show the evolution history of a memory."""
    store = _get_store()

    try:
        entries = store.history(memory_id)
    except Exception as e:
        console.print(f"[red]Error fetching history: {e}[/red]")
        raise typer.Exit(1)

    if not entries:
        console.print(f"[yellow]No history found for memory '{memory_id}'.[/yellow]")
        return

    table = Table(title=f"History for memory {memory_id}")
    table.add_column("#", style="bold", width=4)
    table.add_column("Event", style="magenta", width=12)
    table.add_column("Memory", max_width=50)
    table.add_column("Timestamp", style="dim", width=20)

    for i, entry in enumerate(entries, 1):
        event = entry.get("event", entry.get("type", "update"))
        memory_text = entry.get("memory", entry.get("old_memory", entry.get("new_memory", str(entry))))
        timestamp = entry.get("created_at", entry.get("timestamp", ""))

        if isinstance(memory_text, str) and len(memory_text) > 50:
            memory_text = memory_text[:47] + "..."
        if len(timestamp) > 19:
            timestamp = timestamp[:19]

        table.add_row(str(i), str(event), str(memory_text), timestamp)

    console.print(table)
