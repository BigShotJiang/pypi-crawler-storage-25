"""Atomic file write utilities for SuperAgent.

Provides safe file write operations that prevent data corruption
on crash/interruption by writing to a temp file first, then
atomically renaming.
"""
from __future__ import annotations

import os
import tempfile
from pathlib import Path


def atomic_write(path: str | Path, content: str, *, encoding: str = "utf-8") -> None:
    """Write content to a file atomically.

    Writes to a temporary file in the same directory first, then
    uses os.replace() for an atomic rename. This prevents corruption
    if the process is interrupted during write.

    Parameters
    ----------
    path:
        Target file path.
    content:
        Content to write.
    encoding:
        Text encoding (default: utf-8).
    """
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)

    # Write to temp file in same directory (same filesystem for atomic rename)
    fd, tmp_path = tempfile.mkstemp(
        dir=str(path.parent),
        prefix=f".{path.name}.tmp",
    )
    try:
        with os.fdopen(fd, "w", encoding=encoding) as f:
            f.write(content)
        os.replace(tmp_path, str(path))
    except BaseException:
        # Clean up temp file on any error
        try:
            os.unlink(tmp_path)
        except OSError:
            pass
        raise
