"""OpenAPI Tool Bridge — import tools from OpenAPI/ai-plugin.json specs.

Inspired by OpenAgents' plugin system where each tool is defined by:
  - ai-plugin.json (metadata, branding, auth)
  - openapi.yaml (API spec with paths)

This module lets SuperAgent import any OpenAPI-compatible tool spec
and make it available as a registered tool.
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class OpenAPITool:
    """A tool imported from an OpenAPI/ai-plugin.json specification."""

    name: str
    description: str
    api_url: str
    auth_type: str = "none"  # none, api_key, oauth
    openapi_spec: dict = field(default_factory=dict)
    endpoints: list[dict] = field(default_factory=list)
    logo_url: str = ""
    contact_email: str = ""
    legal_info_url: str = ""

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "description": self.description,
            "api_url": self.api_url,
            "auth_type": self.auth_type,
            "endpoints": self.endpoints,
            "logo_url": self.logo_url,
            "contact_email": self.contact_email,
            "legal_info_url": self.legal_info_url,
        }

    @classmethod
    def from_dict(cls, data: dict) -> OpenAPITool:
        return cls(
            name=data["name"],
            description=data.get("description", ""),
            api_url=data.get("api_url", ""),
            auth_type=data.get("auth_type", "none"),
            openapi_spec=data.get("openapi_spec", {}),
            endpoints=data.get("endpoints", []),
            logo_url=data.get("logo_url", ""),
            contact_email=data.get("contact_email", ""),
            legal_info_url=data.get("legal_info_url", ""),
        )

    def get_prompt_description(self) -> str:
        """Generate a description suitable for LLM tool-use prompts."""
        lines = [f"**{self.name}**: {self.description}"]
        if self.endpoints:
            lines.append("Available operations:")
            for ep in self.endpoints[:10]:
                method = ep.get("method", "GET").upper()
                path = ep.get("path", "")
                desc = ep.get("description", "")
                lines.append(f"  - {method} {path}: {desc}")
        return "\n".join(lines)


def parse_ai_plugin(plugin_json: dict) -> dict:
    """Parse an ai-plugin.json manifest (OpenAgents/ChatGPT plugin standard).

    Expected format:
    {
        "name_for_model": "tool_name",
        "name_for_human": "Tool Name",
        "description_for_model": "...",
        "description_for_human": "...",
        "api": {"type": "openapi", "url": "https://.../.well-known/openapi.yaml"},
        "auth": {"type": "none"},
        "logo_url": "...",
        "contact_email": "...",
        "legal_info_url": "..."
    }
    """
    return {
        "name": plugin_json.get(
            "name_for_model", plugin_json.get("name_for_human", "unknown")
        ),
        "description": plugin_json.get(
            "description_for_model", plugin_json.get("description_for_human", "")
        ),
        "api_url": plugin_json.get("api", {}).get("url", ""),
        "auth_type": plugin_json.get("auth", {}).get("type", "none"),
        "logo_url": plugin_json.get("logo_url", ""),
        "contact_email": plugin_json.get("contact_email", ""),
        "legal_info_url": plugin_json.get("legal_info_url", ""),
    }


def parse_openapi_spec(spec: dict) -> list[dict]:
    """Extract endpoint information from an OpenAPI 3.x specification.

    Returns a list of endpoint dicts with method, path, description, parameters.
    """
    endpoints = []
    paths = spec.get("paths", {})

    for path, methods in paths.items():
        for method, details in methods.items():
            if method in ("get", "post", "put", "delete", "patch"):
                endpoint = {
                    "method": method.upper(),
                    "path": path,
                    "description": details.get(
                        "summary", details.get("description", "")
                    ),
                    "operation_id": details.get("operationId", ""),
                    "parameters": [],
                }
                # Extract parameters
                for param in details.get("parameters", []):
                    endpoint["parameters"].append(
                        {
                            "name": param.get("name", ""),
                            "in": param.get("in", "query"),
                            "required": param.get("required", False),
                            "description": param.get("description", ""),
                        }
                    )
                # Extract request body schema if present
                body = details.get("requestBody", {}).get("content", {})
                if body:
                    for content_type, schema_info in body.items():
                        endpoint["request_body"] = {
                            "content_type": content_type,
                            "schema": schema_info.get("schema", {}),
                        }
                        break

                endpoints.append(endpoint)

    return endpoints


class OpenAPIToolRegistry:
    """Registry for OpenAPI-based tools.

    Stores imported tool specs at ~/.superagent/openapi_tools/
    """

    def __init__(self, tools_dir: str | Path):
        self._dir = Path(tools_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def import_plugin(
        self, plugin_json: dict, openapi_spec: dict | None = None
    ) -> OpenAPITool:
        """Import a tool from ai-plugin.json + optional OpenAPI spec."""
        parsed = parse_ai_plugin(plugin_json)

        endpoints = []
        if openapi_spec:
            endpoints = parse_openapi_spec(openapi_spec)

        tool = OpenAPITool(
            name=parsed["name"],
            description=parsed["description"],
            api_url=parsed["api_url"],
            auth_type=parsed["auth_type"],
            openapi_spec=openapi_spec or {},
            endpoints=endpoints,
            logo_url=parsed.get("logo_url", ""),
            contact_email=parsed.get("contact_email", ""),
            legal_info_url=parsed.get("legal_info_url", ""),
        )

        # Save
        path = self._dir / f"{tool.name}.json"
        atomic_write(
            path, json.dumps(tool.to_dict(), indent=2, ensure_ascii=False)
        )
        logger.info(
            "Imported OpenAPI tool: %s (%d endpoints)", tool.name, len(endpoints)
        )
        return tool

    def get(self, name: str) -> Optional[OpenAPITool]:
        """Retrieve a registered tool by name."""
        path = self._dir / f"{name}.json"
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return OpenAPITool.from_dict(data)
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Failed to load OpenAPI tool %s: %s", name, e)
            return None

    def list_all(self) -> list[OpenAPITool]:
        """List all registered OpenAPI tools."""
        tools = []
        for path in sorted(self._dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                tools.append(OpenAPITool.from_dict(data))
            except (json.JSONDecodeError, KeyError):
                continue
        return tools

    def remove(self, name: str) -> bool:
        """Remove a registered tool."""
        path = self._dir / f"{name}.json"
        if path.exists():
            path.unlink()
            return True
        return False

    def get_all_prompt_descriptions(self) -> str:
        """Get combined prompt descriptions for all registered tools."""
        tools = self.list_all()
        if not tools:
            return ""
        lines = ["\n## Available API Tools (OpenAPI)\n"]
        for t in tools:
            lines.append(t.get_prompt_description())
            lines.append("")
        return "\n".join(lines)


def get_openapi_registry(
    data_dir: Optional[str] = None,
) -> OpenAPIToolRegistry:
    """Factory for OpenAPIToolRegistry."""
    if data_dir is None:
        data_dir = os.environ.get(
            "CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")
        )
    return OpenAPIToolRegistry(os.path.join(data_dir, "openapi_tools"))
