"""Structured JSON logging configuration for SuperAgent.

Provides a configured logger that outputs structured JSON logs.
"""
from __future__ import annotations

import json
import logging
import sys
from typing import Any


class JSONFormatter(logging.Formatter):
    """Format log records as structured JSON."""
    
    def format(self, record: logging.LogRecord) -> str:
        log_data: dict[str, Any] = {
            "level": record.levelname,
            "logger": record.name,
            "message": record.getMessage(),
            "timestamp": self.formatTime(record, self.datefmt),
        }
        
        # Add exception info if present
        if record.exc_info:
            log_data["exc_info"] = self.formatException(record.exc_info)
            
        # Add extra context if passed via extra={}
        if hasattr(record, "extra_context"):
            log_data.update(record.extra_context) # type: ignore
            
        return json.dumps(log_data)

def get_logger(name: str, level: int = logging.INFO) -> logging.Logger:
    """Get a configured structured JSON logger."""
    logger = logging.getLogger(name)
    
    # Only configure if no handlers exist to avoid duplicate logs
    if not logger.handlers:
        logger.setLevel(level)
        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(JSONFormatter())
        logger.addHandler(handler)
        
        # Prevent logs from propagating to root logger to avoid double printing
        logger.propagate = False
        
    return logger

# Default logger for simple imports
logger = get_logger("superagent")
