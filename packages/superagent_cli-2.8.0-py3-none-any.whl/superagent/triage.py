"""Triage (intelligent routing) system for SuperAgent.

Inspired by Microsoft Semantic Kernel's Triage Pattern — Leader Agent as
intelligent router.  Matches incoming task descriptions against configurable
regex-based rules and returns ranked routing decisions indicating which
specialist role should handle the task.
"""

from __future__ import annotations

import json
import os
import re
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write


@dataclass
class TriageRule:
    """A single triage routing rule."""

    def __init__(self, name: str, patterns: list[str], target_role: str, priority: int = 0, description: str = ""):
        self.name = name
        self.patterns = patterns
        self.target_role = target_role
        self.priority = priority
        self.description = description
        self._compiled_patterns = [re.compile(p, re.IGNORECASE) for p in patterns]

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "patterns": self.patterns,
            "target_role": self.target_role,
            "priority": self.priority,
            "description": self.description,
        }

    @classmethod
    def from_dict(cls, data: dict) -> TriageRule:
        return cls(
            name=data["name"],
            patterns=data.get("patterns", []),
            target_role=data["target_role"],
            priority=data.get("priority", 0),
            description=data.get("description", ""),
        )


@dataclass
class TriageDecision:
    """Result of matching a task against a triage rule."""

    rule_name: str
    target_role: str
    confidence: float
    reasoning: str


# ------------------------------------------------------------------
# Built-in rules (15+)
# ------------------------------------------------------------------

_DEFAULT_RULES: list[dict] = [
    {
        "name": "bug-security",
        "patterns": [r"security", r"vulnerability", r"CVE", r"XSS", r"injection", r"exploit", r"auth\s*bypass"],
        "target_role": "Security Engineer",
        "priority": 90,
        "description": "Security vulnerabilities, CVEs, and exploit-related issues.",
    },
    {
        "name": "bug-general",
        "patterns": [r"bug", r"fix", r"error", r"crash", r"exception", r"traceback", r"segfault"],
        "target_role": "Senior Developer",
        "priority": 50,
        "description": "General bug fixes, errors, and crash investigations.",
    },
    {
        "name": "frontend-ui",
        "patterns": [r"frontend", r"react", r"vue", r"CSS", r"UI", r"component", r"responsive", r"tailwind", r"HTML"],
        "target_role": "Frontend Developer",
        "priority": 60,
        "description": "Frontend development, UI components, and styling.",
    },
    {
        "name": "backend-api",
        "patterns": [r"API", r"endpoint", r"REST", r"GraphQL", r"server", r"database", r"middleware", r"route"],
        "target_role": "Backend Architect",
        "priority": 60,
        "description": "Backend API design, endpoints, and server-side logic.",
    },
    {
        "name": "database",
        "patterns": [r"SQL", r"query", r"schema", r"migration", r"PostgreSQL", r"MySQL", r"MongoDB", r"index"],
        "target_role": "Database Optimizer",
        "priority": 70,
        "description": "Database queries, schema design, and migrations.",
    },
    {
        "name": "devops",
        "patterns": [r"deploy", r"docker", r"kubernetes", r"CI/?CD", r"infrastructure", r"terraform", r"helm"],
        "target_role": "DevOps Automator",
        "priority": 70,
        "description": "Deployment, containerization, and infrastructure automation.",
    },
    {
        "name": "testing",
        "patterns": [r"test", r"QA", r"coverage", r"assertion", r"mock", r"integration\s+test", r"pytest", r"jest"],
        "target_role": "Evidence Collector",
        "priority": 55,
        "description": "Testing, QA, and code coverage improvements.",
    },
    {
        "name": "docs",
        "patterns": [r"documentation", r"README", r"API\s+docs?", r"guide", r"tutorial", r"docstring"],
        "target_role": "Technical Writer",
        "priority": 40,
        "description": "Documentation, guides, and technical writing.",
    },
    {
        "name": "design",
        "patterns": [r"design", r"mockup", r"wireframe", r"Figma", r"prototype", r"UX", r"user\s+experience"],
        "target_role": "UI Designer",
        "priority": 55,
        "description": "UI/UX design, mockups, and prototyping.",
    },
    {
        "name": "performance",
        "patterns": [r"performance", r"latency", r"optimization", r"profiling", r"caching", r"bottleneck", r"slow"],
        "target_role": "SRE",
        "priority": 65,
        "description": "Performance optimization, profiling, and caching strategies.",
    },
    {
        "name": "mobile",
        "patterns": [r"mobile", r"iOS", r"Android", r"React\s+Native", r"Flutter", r"Swift", r"Kotlin"],
        "target_role": "Mobile App Builder",
        "priority": 65,
        "description": "Mobile app development for iOS and Android platforms.",
    },
    {
        "name": "data",
        "patterns": [r"data\s+pipeline", r"ETL", r"analytics", r"visualization", r"pandas", r"spark", r"airflow"],
        "target_role": "Data Engineer",
        "priority": 60,
        "description": "Data pipelines, ETL processes, and analytics.",
    },
    {
        "name": "ml-ai",
        "patterns": [r"machine\s+learning", r"model", r"training", r"inference", r"neural", r"LLM", r"GPT", r"embedding"],
        "target_role": "AI Engineer",
        "priority": 70,
        "description": "Machine learning, model training, and AI integration.",
    },
    {
        "name": "code-review",
        "patterns": [r"review", r"refactor", r"code\s+quality", r"lint", r"architecture", r"clean\s*code"],
        "target_role": "Code Reviewer",
        "priority": 45,
        "description": "Code review, refactoring, and architecture improvements.",
    },
    {
        "name": "project-mgmt",
        "patterns": [r"sprint", r"backlog", r"milestone", r"deadline", r"scope", r"roadmap", r"planning"],
        "target_role": "Senior Project Manager",
        "priority": 40,
        "description": "Project management, sprint planning, and scope definition.",
    },
    {
        "name": "auth",
        "patterns": [r"auth(?:entication)?", r"OAuth", r"JWT", r"login", r"SSO", r"SAML", r"RBAC", r"permission"],
        "target_role": "Security Engineer",
        "priority": 80,
        "description": "Authentication, authorization, and access control.",
    },
]


class TriageEngine:
    """Intelligent routing engine that matches tasks to specialist roles.

    Rules are persisted to ``<rules_dir>/rules.json``.  On first
    initialisation (when no rules file exists) the built-in default rules
    are written automatically.
    """

    def __init__(self, rules_dir: Optional[str | Path] = None) -> None:
        if rules_dir is None:
            data_dir = os.environ.get(
                "CLAWTEAM_DATA_DIR",
                os.path.join(os.path.expanduser("~"), ".superagent"),
            )
            rules_dir = os.path.join(data_dir, "triage")

        self._rules_dir = Path(rules_dir)
        self._rules_path = self._rules_dir / "rules.json"
        self._rules: list[TriageRule] = []
        self.load()

    # ------------------------------------------------------------------
    # Persistence
    # ------------------------------------------------------------------

    def load(self) -> None:
        """Load rules from disk, or initialise with defaults if absent."""
        if self._rules_path.exists():
            try:
                data = json.loads(self._rules_path.read_text(encoding="utf-8"))
                self._rules = [TriageRule.from_dict(r) for r in data]
                return
            except (json.JSONDecodeError, KeyError, OSError):
                pass

        # First run — seed with built-in defaults
        self._rules = [TriageRule.from_dict(r) for r in _DEFAULT_RULES]
        self.save()

    def save(self) -> None:
        """Persist current rules to disk."""
        self._rules_dir.mkdir(parents=True, exist_ok=True)
        data = [r.to_dict() for r in self._rules]
        atomic_write(self._rules_path, json.dumps(data, indent=2, ensure_ascii=False))

    # ------------------------------------------------------------------
    # Rule management
    # ------------------------------------------------------------------

    def add_rule(self, rule: TriageRule) -> None:
        """Add a rule (replaces any existing rule with the same name)."""
        self._rules = [r for r in self._rules if r.name != rule.name]
        self._rules.append(rule)
        self.save()

    def remove_rule(self, name: str) -> bool:
        """Remove a rule by name.  Returns True if found and removed."""
        before = len(self._rules)
        self._rules = [r for r in self._rules if r.name != name]
        if len(self._rules) < before:
            self.save()
            return True
        return False

    def list_rules(self) -> list[TriageRule]:
        """Return a copy of all current rules."""
        return list(self._rules)

    # ------------------------------------------------------------------
    # Routing
    # ------------------------------------------------------------------

    def route(self, task_description: str) -> list[TriageDecision]:
        """Match *task_description* against all rules and return decisions
        sorted by confidence (highest first).
        """
        decisions: list[TriageDecision] = []

        for rule in self._rules:
            matches: list[str] = []
            for pattern, compiled_pattern in zip(rule.patterns, rule._compiled_patterns):
                try:
                    if compiled_pattern.search(task_description):
                        matches.append(pattern)
                except re.error:
                    continue

            if not matches:
                continue

            # Confidence: base from match ratio, boosted by priority
            match_ratio = len(matches) / len(rule.patterns)
            priority_boost = rule.priority / 100.0
            confidence = min(1.0, 0.4 * match_ratio + 0.6 * priority_boost * match_ratio)
            # Ensure at least a minimum confidence for any match
            confidence = max(confidence, 0.1 * match_ratio)

            matched_str = ", ".join(matches)
            reasoning = (
                f"Matched {len(matches)}/{len(rule.patterns)} patterns "
                f"({matched_str}) with priority {rule.priority}"
            )

            decisions.append(TriageDecision(
                rule_name=rule.name,
                target_role=rule.target_role,
                confidence=round(confidence, 3),
                reasoning=reasoning,
            ))

        decisions.sort(key=lambda d: d.confidence, reverse=True)
        return decisions

    def route_best(self, task_description: str) -> Optional[TriageDecision]:
        """Return the single best routing decision, or None if no rules match."""
        decisions = self.route(task_description)
        return decisions[0] if decisions else None


# ------------------------------------------------------------------
# Singleton factory
# ------------------------------------------------------------------

_engine_instance: Optional[TriageEngine] = None


def get_triage_engine() -> TriageEngine:
    """Return a singleton :class:`TriageEngine` instance."""
    global _engine_instance
    if _engine_instance is None:
        _engine_instance = TriageEngine()
    return _engine_instance
