"""Tool ecosystem for SuperAgent — registry, search, and install management.

Manages a JSON index of available tools (pip packages) with:
- Category-based organization (dev, data, web, media, office, ai)
- Keyword-based search for tool discovery
- Install/uninstall tracking via pip subprocess calls
- Pre-populated built-in tool entries for common packages
"""

from __future__ import annotations

import importlib.util
import json
import logging
import os
import re
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class ToolEntry:
    """A registered tool (pip package) in the SuperAgent ecosystem."""

    name: str
    description: str
    install_cmd: str
    category: str
    keywords: list[str] = field(default_factory=list)
    installed: bool = False

    def to_dict(self) -> dict:
        return asdict(self)

    @classmethod
    def from_dict(cls, data: dict) -> ToolEntry:
        return cls(**{k: v for k, v in data.items() if k in cls.__dataclass_fields__})


# ---------------------------------------------------------------------------
# Built-in tool catalogue
# ---------------------------------------------------------------------------

BUILTIN_TOOLS: list[ToolEntry] = [
    # dev
    ToolEntry(
        name="ruff",
        description="Extremely fast Python linter and formatter, written in Rust.",
        install_cmd="pip install ruff",
        category="dev",
        keywords=["lint", "format", "style", "check", "python", "ruff"],
    ),
    ToolEntry(
        name="pytest",
        description="Full-featured Python testing framework.",
        install_cmd="pip install pytest",
        category="dev",
        keywords=["test", "testing", "unit", "assert", "fixture", "pytest"],
    ),
    ToolEntry(
        name="black",
        description="The uncompromising Python code formatter.",
        install_cmd="pip install black",
        category="dev",
        keywords=["format", "formatter", "style", "code", "python", "black"],
    ),
    ToolEntry(
        name="mypy",
        description="Optional static type checker for Python.",
        install_cmd="pip install mypy",
        category="dev",
        keywords=["type", "typing", "check", "static", "analysis", "mypy"],
    ),
    # data
    ToolEntry(
        name="pandas",
        description="Powerful data analysis and manipulation library.",
        install_cmd="pip install pandas",
        category="data",
        keywords=["data", "dataframe", "csv", "analysis", "table", "pandas"],
    ),
    ToolEntry(
        name="polars",
        description="Blazingly fast DataFrame library written in Rust.",
        install_cmd="pip install polars",
        category="data",
        keywords=["data", "dataframe", "fast", "rust", "analysis", "polars"],
    ),
    ToolEntry(
        name="duckdb",
        description="In-process SQL OLAP database management system.",
        install_cmd="pip install duckdb",
        category="data",
        keywords=["sql", "database", "olap", "analytics", "query", "duckdb"],
    ),
    # web
    ToolEntry(
        name="httpx",
        description="Modern async HTTP client for Python.",
        install_cmd="pip install httpx",
        category="web",
        keywords=["http", "request", "api", "client", "async", "httpx"],
    ),
    ToolEntry(
        name="beautifulsoup4",
        description="HTML/XML parser for web scraping.",
        install_cmd="pip install beautifulsoup4",
        category="web",
        keywords=["html", "parse", "scrape", "web", "xml", "soup", "beautifulsoup"],
    ),
    ToolEntry(
        name="playwright",
        description="Browser automation and end-to-end testing framework.",
        install_cmd="pip install playwright",
        category="web",
        keywords=["browser", "automation", "test", "selenium", "web", "playwright"],
    ),
    # media
    ToolEntry(
        name="pillow",
        description="Python Imaging Library fork — image processing.",
        install_cmd="pip install pillow",
        category="media",
        keywords=["image", "photo", "resize", "crop", "convert", "pil", "pillow"],
    ),
    ToolEntry(
        name="ffmpeg-python",
        description="Python bindings for FFmpeg — video/audio processing.",
        install_cmd="pip install ffmpeg-python",
        category="media",
        keywords=["video", "audio", "convert", "transcode", "ffmpeg", "media"],
    ),
    # office
    ToolEntry(
        name="python-docx",
        description="Create and modify Word (.docx) documents.",
        install_cmd="pip install python-docx",
        category="office",
        keywords=["word", "docx", "document", "office", "write", "python-docx"],
    ),
    ToolEntry(
        name="openpyxl",
        description="Read/write Excel 2010+ (.xlsx) files.",
        install_cmd="pip install openpyxl",
        category="office",
        keywords=["excel", "xlsx", "spreadsheet", "office", "openpyxl"],
    ),
    # ai
    ToolEntry(
        name="litellm",
        description="Unified interface for 100+ LLM providers.",
        install_cmd="pip install litellm",
        category="ai",
        keywords=["llm", "ai", "openai", "anthropic", "model", "litellm"],
    ),
    ToolEntry(
        name="openai",
        description="Official OpenAI Python client library.",
        install_cmd="pip install openai",
        category="ai",
        keywords=["openai", "gpt", "chat", "api", "ai", "llm"],
    ),
]


def _get_data_dir() -> Path:
    """Return the SuperAgent data directory (from env or default)."""
    return Path(os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent")))


class ToolRegistry:
    """Manages a JSON index of available tools at ``<data_dir>/tools/registry.json``."""

    def __init__(self, data_dir: Optional[str] = None):
        base = Path(data_dir) if data_dir else _get_data_dir()
        self._dir = base / "tools"
        self._path = self._dir / "registry.json"
        self._tools: dict[str, ToolEntry] = {}
        self.load()

    # -- Persistence ---------------------------------------------------------

    def load(self) -> None:
        """Load registry from disk, seeding built-ins on first run."""
        if self._path.exists():
            try:
                data = json.loads(self._path.read_text(encoding="utf-8"))
                for item in data:
                    entry = ToolEntry.from_dict(item)
                    self._tools[entry.name] = entry
            except (json.JSONDecodeError, TypeError):
                pass

        # Ensure all built-in tools are present (idempotent)
        changed = False
        for builtin in BUILTIN_TOOLS:
            if builtin.name not in self._tools:
                self._tools[builtin.name] = ToolEntry(
                    name=builtin.name,
                    description=builtin.description,
                    install_cmd=builtin.install_cmd,
                    category=builtin.category,
                    keywords=list(builtin.keywords),
                    installed=self._check_installed(builtin.name),
                )
                changed = True

        if changed:
            self.save()

    def save(self) -> None:
        """Persist the registry to disk."""
        self._dir.mkdir(parents=True, exist_ok=True)
        data = [entry.to_dict() for entry in self._tools.values()]
        atomic_write(self._path, json.dumps(data, indent=2, ensure_ascii=False))

    # -- CRUD ----------------------------------------------------------------

    def register(self, tool: ToolEntry) -> None:
        """Add or update a tool entry."""
        self._tools[tool.name] = tool
        self.save()

    def unregister(self, name: str) -> bool:
        """Remove a tool by name. Returns True if it existed."""
        if name in self._tools:
            del self._tools[name]
            self.save()
            return True
        return False

    def get(self, name: str) -> Optional[ToolEntry]:
        """Get a tool entry by exact name."""
        return self._tools.get(name)

    # -- Query / Search ------------------------------------------------------

    def list_tools(
        self,
        category: Optional[str] = None,
        installed_only: bool = False,
    ) -> list[ToolEntry]:
        """List tools with optional filters."""
        results = list(self._tools.values())
        if category:
            cat_lower = category.lower()
            results = [t for t in results if t.category.lower() == cat_lower]
        if installed_only:
            results = [t for t in results if t.installed]
        results.sort(key=lambda t: (t.category, t.name))
        return results

    def search(self, query: str, limit: int = 10) -> list[tuple[ToolEntry, float]]:
        """Keyword search over tools. Returns ``(tool, score)`` pairs sorted by relevance."""
        query_words = set(re.findall(r"[a-z0-9]+", query.lower()))
        if not query_words:
            return []

        results: list[tuple[ToolEntry, float]] = []
        for tool in self._tools.values():
            score = 0.0
            # Exact name match (highest weight)
            name_words = set(re.findall(r"[a-z0-9]+", tool.name.lower()))
            score += len(query_words & name_words) * 3.0
            # Keyword match
            kw_set = set(w.lower() for w in tool.keywords)
            score += len(query_words & kw_set) * 1.5
            # Category match
            if tool.category.lower() in query_words:
                score += 2.0
            # Substring match in description
            desc_lower = tool.description.lower()
            for qw in query_words:
                if qw in desc_lower:
                    score += 0.5
            if score > 0:
                results.append((tool, score))

        results.sort(key=lambda x: x[1], reverse=True)
        return results[:limit]

    def categories(self) -> list[str]:
        """Return sorted list of unique categories."""
        return sorted({t.category for t in self._tools.values()})

    def is_installed(self, name: str) -> bool:
        """Check if the tool's pip package is importable."""
        tool = self._tools.get(name)
        if not tool:
            return False
        installed = self._check_installed(name)
        # Update cached state if changed
        if tool.installed != installed:
            tool.installed = installed
            self.save()
        return installed

    # -- Remote registry -----------------------------------------------------

    @staticmethod
    def fetch_remote_tools(url: str) -> list[ToolEntry]:
        """Fetch a JSON tool list from a remote URL (CLI-Hub compatible).

        Expects the response to be a JSON array of objects with at least
        ``name``, ``description``, ``install_cmd``, and ``category`` keys.
        """
        import httpx

        resp = httpx.get(url, timeout=30, follow_redirects=True)
        resp.raise_for_status()
        data = resp.json()

        if isinstance(data, dict):
            # Support wrapping: {"tools": [...]}
            data = data.get("tools", [])

        entries: list[ToolEntry] = []
        for item in data:
            if not isinstance(item, dict) or "name" not in item:
                continue
            entry = ToolEntry(
                name=item["name"],
                description=item.get("description", ""),
                install_cmd=item.get("install_cmd", f"pip install {item['name']}"),
                category=item.get("category", "remote"),
                keywords=item.get("keywords", []),
                installed=False,
            )
            entries.append(entry)

        logger.debug("Fetched %d tools from %s", len(entries), url)
        return entries

    def sync_remote(self, url: str) -> tuple[int, int]:
        """Merge remote tools into the local registry.

        Returns ``(added, updated)`` counts.
        """
        remote_tools = self.fetch_remote_tools(url)
        added = 0
        updated = 0

        for remote in remote_tools:
            existing = self._tools.get(remote.name)
            if existing is None:
                remote.installed = self._check_installed(remote.name)
                self._tools[remote.name] = remote
                added += 1
            else:
                # Update description and metadata, keep local installed state
                existing.description = remote.description
                existing.install_cmd = remote.install_cmd
                existing.category = remote.category
                if remote.keywords:
                    existing.keywords = remote.keywords
                updated += 1

        if added or updated:
            self.save()

        return added, updated

    # -- Helpers -------------------------------------------------------------

    @staticmethod
    def _check_installed(name: str) -> bool:
        """Check if a Python package is available via importlib."""
        # Map tool names to their importable module names where they differ
        import_map: dict[str, str] = {
            "beautifulsoup4": "bs4",
            "python-docx": "docx",
            "pillow": "PIL",
            "ffmpeg-python": "ffmpeg",
        }
        module_name = import_map.get(name, name.replace("-", "_"))
        return importlib.util.find_spec(module_name) is not None


# ---------------------------------------------------------------------------
# Singleton accessor
# ---------------------------------------------------------------------------

_registry_instance: Optional[ToolRegistry] = None


def get_tool_registry(data_dir: Optional[str] = None) -> ToolRegistry:
    """Get or create the singleton ToolRegistry."""
    global _registry_instance
    if _registry_instance is None:
        _registry_instance = ToolRegistry(data_dir=data_dir)
    return _registry_instance
