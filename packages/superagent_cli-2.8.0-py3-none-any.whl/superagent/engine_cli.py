"""SuperAgent engine CLI — manage and test execution engines."""
from __future__ import annotations

import os
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.deerflow_engine import execute_task, is_deerflow_available, list_available_engines

engine_app = typer.Typer(
    name="engine",
    help="Execution engines — manage LLM backends for task execution.",
    no_args_is_help=True,
)
console = Console()


@engine_app.command("list")
def engine_list():
    """List available execution engines and their status."""
    engines = list_available_engines()
    
    table = Table(title="Execution Engines")
    table.add_column("Engine", style="bold")
    table.add_column("Status")
    table.add_column("Description", style="dim")
    
    for e in engines:
        status_color = "green" if e["status"] in ("available", "ready") else "yellow"
        table.add_row(e["name"], f"[{status_color}]{e['status']}[/{status_color}]", e["description"])
    
    if not engines:
        console.print("[yellow]No engines available. Configure an LLM provider with API key.[/yellow]")
        console.print("  superagent llm add --name openai --api-key $OPENAI_API_KEY")
        return
    
    console.print(table)
    if is_deerflow_available():
        console.print("\n[green]DeerFlow engine: ACTIVE[/green]")
    else:
        console.print("\n[yellow]DeerFlow: not installed (using direct LLM fallback)[/yellow]")


@engine_app.command("run")
def engine_run(
    task: str = typer.Argument(..., help="Task to execute."),
    provider: str = typer.Option("openai", "--provider", "-p", help="LLM provider name."),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Override model."),
    output_dir: str = typer.Option("./output", "--output", "-o", help="Output directory for generated files."),
):
    """Execute a task using the best available engine."""
    console.print(f"[bold]Task:[/bold] {task}")
    console.print(f"[bold]Engine:[/bold] {'DeerFlow' if is_deerflow_available() else f'LLM-{provider}'}")
    console.print(f"[bold]Output:[/bold] {output_dir}\n")
    
    with console.status("Executing task..."):
        result = execute_task(task, provider=provider, model=model, working_dir=output_dir)
    
    if result["success"]:
        console.print(Panel(
            f"[green]Task completed successfully[/green]\n\n"
            f"Engine: {result['engine']}\n"
            f"Files created: {len(result['files_created'])}\n"
            + ("\n".join(f"  - {f}" for f in result['files_created']) if result['files_created'] else "  (none)"),
            title="Result",
        ))
        if result['output']:
            console.print(f"\n[dim]{result['output'][:500]}{'...' if len(result['output']) > 500 else ''}[/dim]")
    else:
        console.print(f"[red]Task failed: {result['error']}[/red]")
        console.print("\nCheck your LLM provider API key:")
        console.print("  superagent llm list")
        console.print("  superagent engine list")


@engine_app.command("test")
def engine_test(
    provider: str = typer.Option("openai", "--provider", "-p", help="Provider to test."),
):
    """Quick test: ask the engine to create a hello world file."""
    console.print(f"Testing engine with provider '{provider}'...\n")
    result = execute_task(
        "Create a single file called hello.txt with the content 'Hello from SuperAgent!'",
        provider=provider,
        working_dir="/tmp/superagent-test",
    )
    if result["success"]:
        console.print(f"[green]Engine test passed![/green] (engine: {result['engine']})")
        if result["files_created"]:
            for f in result["files_created"]:
                path = os.path.join("/tmp/superagent-test", f)
                if os.path.isfile(path):
                    console.print(f"  {f}: {open(path).read().strip()}")
    else:
        console.print(f"[red]Engine test failed: {result['error']}[/red]")
