"""Wiki CLI — structured knowledge base with cross-referenced pages."""

from __future__ import annotations

import json
import os
import re
from typing import Optional

import typer
from rich.console import Console
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

wiki_app = typer.Typer(
    name="wiki",
    help="Wiki — structured knowledge base with cross-referenced pages.",
    no_args_is_help=True,
)
console = Console()


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@wiki_app.command("init")
def wiki_init(
    dir: Optional[str] = typer.Option(None, "--dir", help="Custom wiki directory path."),
):
    """Initialize the wiki directory structure."""
    from superagent.wiki import get_wiki_store

    store = get_wiki_store(wiki_dir=dir)
    store.init()
    console.print(f"[green]Wiki initialized at {store.base_dir}[/green]")


@wiki_app.command("ingest")
def wiki_ingest(
    source: str = typer.Argument(..., help="File path or URL to ingest."),
    title: Optional[str] = typer.Option(None, "--title", "-t", help="Override source title."),
    tags: Optional[str] = typer.Option(None, "--tags", help="Comma-separated tags."),
    use_llm: bool = typer.Option(False, "--use-llm", help="Use LLM for semantic extraction."),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Ingest a source document or URL into the wiki."""
    from dataclasses import asdict

    from superagent.wiki import get_wiki_store

    store = get_wiki_store()
    tag_list = [t.strip() for t in tags.split(",")] if tags else None

    # Check if URL
    if source.startswith("http://") or source.startswith("https://"):
        result = store.ingest_url(source, title=title or "", tags=tag_list, use_llm=use_llm)
    else:
        result = store.ingest(source, title=title or "", tags=tag_list, use_llm=use_llm)

    if json_out:
        console.print_json(json.dumps(asdict(result)))
    else:
        console.print(f"[green]Ingested:[/green] {result.source_path}")
        console.print(f"  Pages created: {len(result.pages_created)}")
        console.print(f"  Pages updated: {len(result.pages_updated)}")
        console.print(f"  Claims extracted: {result.claims_extracted}")
        if result.contradictions:
            console.print(f"  [yellow]Contradictions: {len(result.contradictions)}[/yellow]")
            for c in result.contradictions:
                console.print(f"    - {c}")


@wiki_app.command("search")
def wiki_search(
    query: str = typer.Argument(..., help="Search query."),
    limit: int = typer.Option(10, "--limit", "-n", help="Max results."),
    page_type: Optional[str] = typer.Option(
        None, "--type", help="Filter by page type (entity/concept/source/comparison/synthesis)."
    ),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Search wiki pages by keyword."""
    from superagent.wiki import PageType, get_wiki_store

    store = get_wiki_store()
    pt = PageType(page_type) if page_type else None
    results = store.search(query, limit=limit, page_type=pt)

    if json_out:
        items = [
            {
                "path": p.path,
                "title": p.frontmatter.title,
                "type": p.frontmatter.type.value,
                "tags": p.frontmatter.tags,
                "summary": p.frontmatter.summary_l0,
            }
            for p in results
        ]
        console.print_json(json.dumps(items))
    else:
        if not results:
            console.print("[dim]No results found.[/dim]")
            return

        table = Table(title=f"Wiki Search: '{query}'")
        table.add_column("Type", style="cyan", width=12)
        table.add_column("Title", style="bold")
        table.add_column("Tags")
        table.add_column("Summary")
        for p in results:
            table.add_row(
                p.frontmatter.type.value,
                p.frontmatter.title,
                ", ".join(p.frontmatter.tags),
                p.frontmatter.summary_l0[:60],
            )
        console.print(table)


@wiki_app.command("query")
def wiki_query(
    question: str = typer.Argument(..., help="Question to ask the wiki."),
    limit: int = typer.Option(5, "--limit", "-n", help="Max pages to consider."),
    provider: str = typer.Option("openai", "--provider", "-p", help="LLM provider for synthesis."),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Query the wiki with LLM-synthesized answers."""
    from superagent.wiki import get_wiki_store

    store = get_wiki_store()
    answer = store.query(question, limit=limit, provider=provider)

    if json_out:
        console.print_json(json.dumps({"question": question, "answer": answer}))
    else:
        console.print(Panel(Markdown(answer), title=f"Wiki Answer: {question[:50]}"))


@wiki_app.command("show")
def wiki_show(
    page_path: str = typer.Argument(..., help="Page path (e.g. concepts/transformers)."),
    level: str = typer.Option(
        "L2",
        "--level",
        "-l",
        help="Detail level: L0 (summary), L1 (frontmatter), L2 (full), L3 (full + links).",
    ),
):
    """Show a specific wiki page."""
    from superagent.wiki import get_wiki_store

    store = get_wiki_store()

    # Add .md extension if needed
    if not page_path.endswith(".md"):
        page_path = page_path + ".md"

    # Try wiki/ prefix and bare path
    page = None
    for prefix in ["wiki/", ""]:
        page = store._read_page(prefix + page_path)
        if page:
            break

    if not page:
        console.print(f"[red]Page not found: {page_path}[/red]")
        raise typer.Exit(1)

    fm = page.frontmatter
    if level == "L0":
        console.print(f"[bold]{fm.title}[/bold] — {fm.summary_l0}")
    elif level == "L1":
        console.print(
            Panel.fit(
                f"[bold]{fm.title}[/bold]\n"
                f"Type: {fm.type.value} | Status: {fm.status.value} | Confidence: {fm.confidence} ({fm.confidence_level})\n"
                f"Tags: {', '.join(fm.tags)}\n"
                f"Related: {', '.join(fm.related)}\n"
                f"Sources: {', '.join(fm.source_ids)}\n"
                f"Summary: {fm.summary_l0}",
                title="Page Info",
            )
        )
    else:
        console.print(
            Panel(
                Markdown(page.body),
                title=fm.title,
                subtitle=f"{fm.type.value} | {fm.status.value}",
            )
        )
        if level == "L3" and page.wiki_links:
            console.print(f"\n[dim]Wiki links: {', '.join(page.wiki_links)}[/dim]")


@wiki_app.command("lint")
def wiki_lint(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Run health checks on the wiki."""
    from dataclasses import asdict

    from superagent.wiki import get_wiki_store

    store = get_wiki_store()
    result = store.lint()

    if json_out:
        console.print_json(json.dumps(asdict(result)))
    else:
        color = "green" if result.score >= 80 else "yellow" if result.score >= 50 else "red"
        console.print(f"\n[{color}]Wiki Health Score: {result.score:.1f}/100[/{color}]\n")

        if result.orphan_pages:
            console.print(f"[yellow]Orphan pages ({len(result.orphan_pages)}):[/yellow]")
            for p in result.orphan_pages:
                console.print(f"  - {p}")

        if result.broken_links:
            console.print(f"[red]Broken links ({len(result.broken_links)}):[/red]")
            for link in result.broken_links:
                console.print(f"  - {link}")

        if result.stubs:
            console.print(f"[yellow]Stubs ({len(result.stubs)}):[/yellow]")
            for s in result.stubs:
                console.print(f"  - {s}")

        if result.stale_pages:
            console.print(f"[dim]Stale pages ({len(result.stale_pages)}):[/dim]")
            for s in result.stale_pages:
                console.print(f"  - {s}")

        if result.contradictions:
            console.print(f"[red]Contradictions ({len(result.contradictions)}):[/red]")
            for c in result.contradictions:
                console.print(f"  - {c}")


@wiki_app.command("status")
def wiki_status(
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Show wiki status and health overview."""
    from superagent.wiki import get_wiki_store

    store = get_wiki_store()
    info = store.status()

    if json_out:
        console.print_json(json.dumps(info))
    else:
        console.print(
            Panel.fit(
                f"[bold]Wiki Status[/bold]\n"
                f"Directory: {store.base_dir}\n"
                f"Total pages: {info['total_pages']}\n"
                f"  Sources: {info['pages_by_type'].get('source', 0)}\n"
                f"  Entities: {info['pages_by_type'].get('entity', 0)}\n"
                f"  Concepts: {info['pages_by_type'].get('concept', 0)}\n"
                f"  Comparisons: {info['pages_by_type'].get('comparison', 0)}\n"
                f"  Syntheses: {info['pages_by_type'].get('synthesis', 0)}\n"
                f"Last ingest: {info.get('last_ingest', 'never')}\n"
                f"Health score: {info['health_score']:.1f}/100",
                title="Wiki",
            )
        )


@wiki_app.command("log")
def wiki_log(
    limit: int = typer.Option(20, "--limit", "-n", help="Number of log entries to show."),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """View the wiki audit log."""
    from superagent.wiki import get_wiki_store

    store = get_wiki_store()
    log_path = os.path.join(store.base_dir, "wiki", "log.md")

    if not os.path.isfile(log_path):
        console.print("[dim]No log entries yet.[/dim]")
        return

    with open(log_path, encoding="utf-8") as f:
        lines = f.readlines()

    # Parse entries (lines starting with ## [timestamp])
    entries = []
    for line in lines:
        m = re.match(r"^## \[(.+?)\] (.+?) \| (.+)", line.strip())
        if m:
            entries.append(
                {"timestamp": m.group(1), "operation": m.group(2), "detail": m.group(3)}
            )

    entries = entries[-limit:]

    if json_out:
        console.print_json(json.dumps(entries))
    else:
        if not entries:
            console.print("[dim]No log entries found.[/dim]")
            return

        table = Table(title="Wiki Log")
        table.add_column("Time", style="dim")
        table.add_column("Operation", style="cyan")
        table.add_column("Detail")
        for e in entries:
            table.add_row(e["timestamp"], e["operation"], e["detail"])
        console.print(table)


@wiki_app.command("export")
def wiki_export(
    format: str = typer.Option("md", "--format", "-f", help="Export format: md or json."),
    output: Optional[str] = typer.Option(None, "--output", "-o", help="Output directory."),
    to_rag: bool = typer.Option(False, "--to-rag", help="Sync wiki pages to RAG system."),
    json_out: bool = typer.Option(False, "--json", help="Output as JSON."),
):
    """Export wiki pages or sync to RAG."""
    from dataclasses import asdict

    from superagent.wiki import get_wiki_store

    store = get_wiki_store()

    if to_rag:
        count = store.sync_to_rag()
        if json_out:
            console.print_json(json.dumps({"synced": count}))
        else:
            console.print(f"[green]Synced {count} pages to RAG.[/green]")
        return

    out_dir = output or os.path.join(os.getcwd(), "wiki-export")
    os.makedirs(out_dir, exist_ok=True)

    pages = store.list_all()  # get all wiki pages

    if format == "json":
        data = [
            {
                "path": p.path,
                "title": p.frontmatter.title,
                "type": p.frontmatter.type.value,
                "tags": p.frontmatter.tags,
                "summary": p.frontmatter.summary_l0,
                "body": p.body,
                "wiki_links": p.wiki_links,
            }
            for p in pages
        ]
        export_path = os.path.join(out_dir, "wiki.json")
        with open(export_path, "w") as f:
            json.dump(data, f, indent=2, ensure_ascii=False)
        console.print(f"[green]Exported {len(pages)} pages to {export_path}[/green]")
    else:
        for p in pages:
            dest = os.path.join(out_dir, p.path)
            os.makedirs(os.path.dirname(dest), exist_ok=True)
            full = store._render_frontmatter(asdict(p.frontmatter), p.body)
            with open(dest, "w") as f:
                f.write(full)
        console.print(f"[green]Exported {len(pages)} pages to {out_dir}/[/green]")


@wiki_app.command("graph")
def wiki_graph(
    format: str = typer.Option(
        "text", "--format", "-f", help="Output format: text, json, dot, or html."
    ),
):
    """Show wiki page link graph."""
    import webbrowser

    from superagent.wiki import get_wiki_store

    store = get_wiki_store()

    if format == "html":
        path = store.render_html()
        console.print(f"[green]Interactive graph written to {path}[/green]")
        webbrowser.open(f"file://{path}")
        return

    g = store.graph()

    if format == "json":
        console.print_json(json.dumps(g))
    elif format == "dot":
        lines = ["digraph wiki {", "  rankdir=LR;"]
        for node in g["nodes"]:
            nid = node["id"]
            label = node.get("label", nid).replace("/", "\\n")
            lines.append(f'  "{nid}" [label="{label}"];')
        for edge in g["edges"]:
            lines.append(f'  "{edge["source"]}" -> "{edge["target"]}";')
        lines.append("}")
        console.print("\n".join(lines))
    else:
        console.print(
            f"[bold]Wiki Graph[/bold]: {len(g['nodes'])} nodes, {len(g['edges'])} edges\n"
        )
        for node in sorted(g["nodes"], key=lambda n: n["id"]):
            nid = node["id"]
            label = node.get("label", nid)
            links_out = [e["target"] for e in g["edges"] if e["source"] == nid]
            links_in = [e["source"] for e in g["edges"] if e["target"] == nid]
            console.print(
                f"  [cyan]{label}[/cyan] ({node.get('type', '')})  \u2192{len(links_out)} \u2190{len(links_in)}"
            )
