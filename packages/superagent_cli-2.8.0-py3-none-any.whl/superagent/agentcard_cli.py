"""CLI commands for SuperAgent agent card management.

Provides the ``superagent card`` subcommand group with publish, discover, show,
search, and remove operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import os
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.agentcard import AgentCard, get_card_registry

card_app = typer.Typer(
    name="card",
    help="Agent Card discovery — publish, discover, and search agent capability cards.",
    no_args_is_help=True,
)
console = Console()


def _get_registry():
    """Create a CardRegistry using the configured data directory."""
    data_dir = os.environ.get(
        "CLAWTEAM_DATA_DIR",
        os.path.join(os.path.expanduser("~"), ".superagent"),
    )
    return get_card_registry(data_dir)


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@card_app.command("publish")
def card_publish(
    team: str = typer.Argument(..., help="Team name."),
    agent: str = typer.Argument(..., help="Agent name."),
    capabilities: Optional[str] = typer.Option(
        None, "--capabilities", "-c", help="Comma-separated capabilities.",
    ),
    model: str = typer.Option("", "--model", "-m", help="Model identifier."),
    role: str = typer.Option("", "--role", "-r", help="Agent role description."),
    tools: Optional[str] = typer.Option(
        None, "--tools", "-t", help="Comma-separated tool names.",
    ),
    status: str = typer.Option("active", "--status", "-s", help="Agent status."),
) -> None:
    """Publish or update an agent capability card."""
    registry = _get_registry()

    cap_list = [c.strip() for c in capabilities.split(",") if c.strip()] if capabilities else []
    tool_list = [t.strip() for t in tools.split(",") if t.strip()] if tools else []

    # Check if card already exists to preserve created_at
    existing = registry.get(team, agent)
    card = AgentCard(
        agent_name=agent,
        team=team,
        capabilities=cap_list,
        status=status,
        model=model,
        tools=tool_list,
        role=role,
        created_at=existing.created_at if existing else "",
    )
    registry.publish(card)

    console.print(Panel(
        f"[bold green]Card published[/bold green]\n\n"
        f"  [bold]Agent:[/bold]        {card.agent_name}\n"
        f"  [bold]Team:[/bold]         {card.team}\n"
        f"  [bold]Role:[/bold]         {card.role or '(none)'}\n"
        f"  [bold]Model:[/bold]        {card.model or '(none)'}\n"
        f"  [bold]Status:[/bold]       {card.status}\n"
        f"  [bold]Capabilities:[/bold] {', '.join(card.capabilities) or '(none)'}\n"
        f"  [bold]Tools:[/bold]        {', '.join(card.tools) or '(none)'}",
        title="card publish",
        border_style="green",
    ))


@card_app.command("discover")
def card_discover(
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Filter by team."),
    capability: Optional[str] = typer.Option(
        None, "--capability", "-c", help="Filter by capability keyword.",
    ),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status."),
) -> None:
    """Discover agents by team, capability, or status."""
    registry = _get_registry()
    cards = registry.discover(team=team, capability=capability, status=status)

    if not cards:
        console.print("[yellow]No agents found matching the given filters.[/yellow]")
        return

    table = Table(title=f"Agent Cards ({len(cards)} found)")
    table.add_column("Agent", style="cyan", width=18)
    table.add_column("Team", style="magenta", width=14)
    table.add_column("Role", style="green", width=20)
    table.add_column("Status", width=8)
    table.add_column("Capabilities", max_width=35)
    table.add_column("Model", style="dim", width=12)

    for card in cards:
        status_style = {
            "active": "[green]active[/green]",
            "idle": "[yellow]idle[/yellow]",
            "busy": "[blue]busy[/blue]",
            "offline": "[red]offline[/red]",
        }.get(card.status, card.status)

        caps = ", ".join(card.capabilities)
        if len(caps) > 35:
            caps = caps[:32] + "..."

        table.add_row(
            card.agent_name,
            card.team,
            card.role or "-",
            status_style,
            caps or "-",
            card.model or "-",
        )

    console.print(table)


@card_app.command("show")
def card_show(
    team: str = typer.Argument(..., help="Team name."),
    agent: str = typer.Argument(..., help="Agent name."),
) -> None:
    """Show full details of an agent card."""
    registry = _get_registry()
    card = registry.get(team, agent)

    if card is None:
        console.print(f"[red]Card not found: {team}/{agent}[/red]")
        raise typer.Exit(1)

    console.print(Panel(
        f"[bold]Agent:[/bold]        {card.agent_name}\n"
        f"[bold]Team:[/bold]         {card.team}\n"
        f"[bold]Role:[/bold]         {card.role or '(none)'}\n"
        f"[bold]Model:[/bold]        {card.model or '(none)'}\n"
        f"[bold]Status:[/bold]       {card.status}\n"
        f"[bold]Tools:[/bold]        {', '.join(card.tools) or '(none)'}\n"
        f"[bold]Capabilities:[/bold] {', '.join(card.capabilities) or '(none)'}\n"
        f"[bold]Created:[/bold]      {card.created_at}\n"
        f"[bold]Updated:[/bold]      {card.updated_at}",
        title=f"Agent Card: {card.team}/{card.agent_name}",
        border_style="cyan",
    ))


@card_app.command("search")
def card_search(
    query: str = typer.Argument(..., help="Search keywords."),
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Filter by team."),
) -> None:
    """Search agents by capability keyword."""
    registry = _get_registry()
    cards = registry.search(query, team=team)

    if not cards:
        console.print(f"[yellow]No agents matching '{query}'.[/yellow]")
        return

    table = Table(title=f"Search: \"{query}\" ({len(cards)} results)")
    table.add_column("Agent", style="cyan", width=18)
    table.add_column("Team", style="magenta", width=14)
    table.add_column("Role", style="green", width=20)
    table.add_column("Status", width=8)
    table.add_column("Capabilities", max_width=35)
    table.add_column("Tools", style="dim", max_width=20)

    for card in cards:
        status_style = {
            "active": "[green]active[/green]",
            "idle": "[yellow]idle[/yellow]",
            "busy": "[blue]busy[/blue]",
            "offline": "[red]offline[/red]",
        }.get(card.status, card.status)

        caps = ", ".join(card.capabilities)
        if len(caps) > 35:
            caps = caps[:32] + "..."
        tools_str = ", ".join(card.tools)
        if len(tools_str) > 20:
            tools_str = tools_str[:17] + "..."

        table.add_row(
            card.agent_name,
            card.team,
            card.role or "-",
            status_style,
            caps or "-",
            tools_str or "-",
        )

    console.print(table)


@card_app.command("remove")
def card_remove(
    team: str = typer.Argument(..., help="Team name."),
    agent: str = typer.Argument(..., help="Agent name."),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation."),
) -> None:
    """Unpublish an agent card."""
    registry = _get_registry()

    # Verify it exists
    card = registry.get(team, agent)
    if card is None:
        console.print(f"[red]Card not found: {team}/{agent}[/red]")
        raise typer.Exit(1)

    if not force:
        confirm = typer.confirm(f"Remove card {team}/{agent}?")
        if not confirm:
            console.print("[dim]Cancelled.[/dim]")
            raise typer.Exit()

    deleted = registry.unpublish(team, agent)
    if deleted:
        console.print(f"[green]Removed card {team}/{agent}.[/green]")
    else:
        console.print(f"[red]Failed to remove card {team}/{agent}.[/red]")
        raise typer.Exit(1)
