"""File merger for SuperAgent — combine multi-agent outputs into one project.

When agents work in separate directories (tech-lead/, backend-dev/, frontend-dev/),
this module merges their outputs into a single unified project directory.
"""
from __future__ import annotations

import os
import shutil


def merge_agent_outputs(
    agent_dirs: list[str],
    output_dir: str,
    conflict_strategy: str = "latest",  # "latest", "largest", "first"
) -> dict:
    """Merge files from multiple agent output directories into one project.
    
    Args:
        agent_dirs: List of agent output directories to merge from
        output_dir: Target directory for merged project
        conflict_strategy: How to handle conflicting files:
            - "latest": keep the most recently modified version
            - "largest": keep the largest file (more content = more complete)
            - "first": keep the first version found
    
    Returns:
        dict with: files_merged, conflicts_resolved, total_files
    """
    os.makedirs(output_dir, exist_ok=True)
    
    # Collect all files across all agent dirs
    file_map: dict[str, list[tuple[str, str]]] = {}  # relative_path → [(agent_dir, full_path)]
    
    for agent_dir in agent_dirs:
        if not os.path.isdir(agent_dir):
            continue
        for root, _, files in os.walk(agent_dir):
            for fname in files:
                full_path = os.path.join(root, fname)
                rel_path = os.path.relpath(full_path, agent_dir)
                file_map.setdefault(rel_path, []).append((agent_dir, full_path))
    
    stats = {"files_merged": 0, "conflicts_resolved": 0, "total_files": len(file_map)}
    
    for rel_path, sources in file_map.items():
        target = os.path.join(output_dir, rel_path)
        os.makedirs(os.path.dirname(target), exist_ok=True)
        
        if len(sources) == 1:
            # No conflict — just copy
            shutil.copy2(sources[0][1], target)
            stats["files_merged"] += 1
        else:
            # Conflict — resolve based on strategy
            if conflict_strategy == "largest":
                best = max(sources, key=lambda s: os.path.getsize(s[1]))
            elif conflict_strategy == "latest":
                best = max(sources, key=lambda s: os.path.getmtime(s[1]))
            else:  # first
                best = sources[0]
            
            shutil.copy2(best[1], target)
            stats["files_merged"] += 1
            stats["conflicts_resolved"] += 1
    
    return stats


def list_project_files(project_dir: str) -> list[dict]:
    """List all files in a merged project with metadata."""
    files = []
    for root, _, filenames in os.walk(project_dir):
        for fname in filenames:
            full = os.path.join(root, fname)
            rel = os.path.relpath(full, project_dir)
            files.append({
                "path": rel,
                "size": os.path.getsize(full),
                "lines": sum(1 for _ in open(full, errors="ignore")),
            })
    return sorted(files, key=lambda f: f["path"])
