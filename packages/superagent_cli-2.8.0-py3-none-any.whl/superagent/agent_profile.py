"""Agent Profile — persistent agent identity with accumulated experience.

Inspired by Moxt.ai's "momo" agents that maintain personality, skills, and memory
across sessions. Each agent profile tracks execution history, success patterns,
and domain expertise over time.

Profiles are stored as JSON files under ~/.superagent/profiles/{agent_name}.json
"""
from __future__ import annotations

import json
import logging
import os
from dataclasses import dataclass, field
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional

from superagent.file_util import atomic_write

logger = logging.getLogger(__name__)


@dataclass
class AgentProfile:
    """Persistent identity for an AI agent."""

    name: str
    role: str = ""
    description: str = ""
    # Accumulated stats
    tasks_completed: int = 0
    tasks_failed: int = 0
    total_files_created: int = 0
    # Domain expertise (auto-discovered from successful tasks)
    expertise: list[str] = field(default_factory=list)
    # Preferences learned from corrections
    preferences: list[str] = field(default_factory=list)
    # Execution history (last N entries)
    history: list[dict] = field(default_factory=list)
    # Timestamps
    created_at: str = ""
    last_active: str = ""

    @property
    def success_rate(self) -> float:
        total = self.tasks_completed + self.tasks_failed
        return self.tasks_completed / total if total > 0 else 0.0

    @property
    def experience_level(self) -> str:
        total = self.tasks_completed + self.tasks_failed
        if total >= 50:
            return "expert"
        if total >= 20:
            return "experienced"
        if total >= 5:
            return "intermediate"
        return "novice"

    def record_execution(self, task: str, success: bool, files_created: int = 0,
                         domain: str = "", error: str = "") -> None:
        """Record a task execution outcome."""
        now = datetime.now(timezone.utc).isoformat()
        self.last_active = now

        if success:
            self.tasks_completed += 1
            self.total_files_created += files_created
            if domain and domain not in self.expertise:
                self.expertise.append(domain)
                # Keep top 20 expertise areas
                self.expertise = self.expertise[-20:]
        else:
            self.tasks_failed += 1

        # Keep last 50 history entries
        self.history.append({
            "task": task[:200],
            "success": success,
            "files": files_created,
            "domain": domain,
            "error": error[:200] if error else "",
            "timestamp": now,
        })
        self.history = self.history[-50:]

    def add_correction(self, correction: str) -> None:
        """Record a user correction (Moxt pattern: corrections improve the agent)."""
        self.preferences.append(correction)
        # Keep last 30 corrections
        self.preferences = self.preferences[-30:]

    def get_context_prompt(self) -> str:
        """Generate a context prompt reflecting this agent's accumulated experience."""
        parts = [f"You are {self.name}"]
        if self.role:
            parts[0] += f" ({self.role})"
        parts[0] += "."

        if self.experience_level != "novice":
            parts.append(f"Experience level: {self.experience_level} "
                         f"({self.tasks_completed} tasks completed, "
                         f"{self.success_rate:.0%} success rate).")

        if self.expertise:
            parts.append(f"Domain expertise: {', '.join(self.expertise[:10])}.")

        if self.preferences:
            parts.append("Learned preferences:")
            for p in self.preferences[-5:]:
                parts.append(f"  - {p}")

        return "\n".join(parts)

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "role": self.role,
            "description": self.description,
            "tasks_completed": self.tasks_completed,
            "tasks_failed": self.tasks_failed,
            "total_files_created": self.total_files_created,
            "expertise": self.expertise,
            "preferences": self.preferences,
            "history": self.history,
            "created_at": self.created_at,
            "last_active": self.last_active,
        }

    @classmethod
    def from_dict(cls, data: dict) -> AgentProfile:
        return cls(
            name=data["name"],
            role=data.get("role", ""),
            description=data.get("description", ""),
            tasks_completed=data.get("tasks_completed", 0),
            tasks_failed=data.get("tasks_failed", 0),
            total_files_created=data.get("total_files_created", 0),
            expertise=data.get("expertise", []),
            preferences=data.get("preferences", []),
            history=data.get("history", []),
            created_at=data.get("created_at", ""),
            last_active=data.get("last_active", ""),
        )


class ProfileStore:
    """Manages persistent agent profiles."""

    def __init__(self, profiles_dir: str | Path):
        self._dir = Path(profiles_dir)
        self._dir.mkdir(parents=True, exist_ok=True)

    def _path(self, name: str) -> Path:
        safe = name.replace("/", "_").replace(" ", "_")
        return self._dir / f"{safe}.json"

    def get(self, name: str) -> Optional[AgentProfile]:
        path = self._path(name)
        if not path.exists():
            return None
        try:
            data = json.loads(path.read_text(encoding="utf-8"))
            return AgentProfile.from_dict(data)
        except (json.JSONDecodeError, KeyError) as e:
            logger.warning("Failed to load profile %s: %s", name, e)
            return None

    def get_or_create(self, name: str, role: str = "") -> AgentProfile:
        profile = self.get(name)
        if profile is None:
            profile = AgentProfile(
                name=name,
                role=role,
                created_at=datetime.now(timezone.utc).isoformat(),
            )
            self.save(profile)
        return profile

    def save(self, profile: AgentProfile) -> None:
        atomic_write(self._path(profile.name),
                     json.dumps(profile.to_dict(), indent=2, ensure_ascii=False))

    def list_all(self) -> list[AgentProfile]:
        profiles = []
        for path in sorted(self._dir.glob("*.json")):
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                profiles.append(AgentProfile.from_dict(data))
            except (json.JSONDecodeError, KeyError):
                continue
        return profiles

    def get_best_for_domain(self, domain: str, limit: int = 3) -> list[AgentProfile]:
        """Find agents with the most expertise in a domain."""
        scored = []
        for p in self.list_all():
            score = sum(1 for e in p.expertise if domain.lower() in e.lower())
            if score > 0:
                scored.append((score, p.success_rate, p))
        scored.sort(key=lambda x: (x[0], x[1]), reverse=True)
        return [p for _, _, p in scored[:limit]]


def get_profile_store(data_dir: Optional[str] = None) -> ProfileStore:
    if data_dir is None:
        data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    return ProfileStore(os.path.join(data_dir, "profiles"))
