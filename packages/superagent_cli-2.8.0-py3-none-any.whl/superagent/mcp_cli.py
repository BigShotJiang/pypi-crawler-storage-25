"""SuperAgent MCP CLI commands — list, add, remove, enable/disable MCP servers."""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from superagent.mcp_bridge import MCPClient, MCPServerConfig, get_mcp_bridge

mcp_app = typer.Typer(
    name="mcp",
    help="MCP server management — configure, enable, and discover MCP tool servers.",
    no_args_is_help=True,
)
console = Console()


@mcp_app.command("list")
def mcp_list(
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List all registered MCP servers."""
    bridge = get_mcp_bridge()
    servers = bridge.list_servers()

    if json_out:
        data = [s.to_dict() for s in servers]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not servers:
        console.print("[yellow]No MCP servers configured.[/yellow]")
        console.print("Use [bold]superagent mcp add[/bold] to register a server.")
        return

    table = Table(title=f"MCP Servers ({len(servers)})")
    table.add_column("Name", style="bold", width=16)
    table.add_column("Enabled", width=9)
    table.add_column("Command", style="cyan", width=10)
    table.add_column("Args", style="dim", max_width=45)
    table.add_column("Description", style="dim", max_width=40)

    for s in servers:
        status = "[green]yes[/green]" if s.enabled else "[red]no[/red]"
        args_str = " ".join(s.args)
        table.add_row(s.name, status, s.command, args_str[:45], s.description[:40])

    console.print(table)


@mcp_app.command("add")
def mcp_add(
    name: str = typer.Option(..., "--name", help="Unique server name."),
    command: str = typer.Option(..., "--command", help="Executable command (e.g. 'npx', 'python')."),
    args: Optional[str] = typer.Option(None, "--args", help="Comma-separated arguments."),
    env: Optional[str] = typer.Option(None, "--env", help="Environment vars as KEY=VAL pairs, comma-separated."),
    description: str = typer.Option("", "--description", help="Short description of the server."),
):
    """Add a new MCP server configuration."""
    bridge = get_mcp_bridge()

    existing = bridge.get_server(name)
    if existing:
        console.print(f"[yellow]Server '{name}' already exists. Updating.[/yellow]")

    # Parse args
    arg_list: list[str] = []
    if args:
        arg_list = [a.strip() for a in args.split(",") if a.strip()]

    # Parse env
    env_dict: dict[str, str] = {}
    if env:
        for pair in env.split(","):
            pair = pair.strip()
            if "=" in pair:
                k, v = pair.split("=", 1)
                env_dict[k.strip()] = v.strip()

    config = MCPServerConfig(
        name=name,
        command=command,
        args=arg_list,
        env=env_dict,
        enabled=True,
        description=description,
    )
    bridge.add_server(config)
    console.print(f"[green]Added MCP server '{name}'.[/green]")


@mcp_app.command("remove")
def mcp_remove(
    name: str = typer.Argument(..., help="Server name to remove."),
):
    """Remove an MCP server configuration."""
    bridge = get_mcp_bridge()

    if not bridge.remove_server(name):
        console.print(f"[red]Server '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(f"[green]Removed MCP server '{name}'.[/green]")


@mcp_app.command("enable")
def mcp_enable(
    name: str = typer.Argument(..., help="Server name to enable."),
):
    """Enable an MCP server."""
    bridge = get_mcp_bridge()

    if not bridge.enable(name):
        console.print(f"[red]Server '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(f"[green]Enabled MCP server '{name}'.[/green]")


@mcp_app.command("disable")
def mcp_disable(
    name: str = typer.Argument(..., help="Server name to disable."),
):
    """Disable an MCP server."""
    bridge = get_mcp_bridge()

    if not bridge.disable(name):
        console.print(f"[red]Server '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(f"[yellow]Disabled MCP server '{name}'.[/yellow]")


@mcp_app.command("config")
def mcp_config():
    """Show the full MCP configuration as JSON (for copying to Claude Code, etc.)."""
    bridge = get_mcp_bridge()
    servers = bridge.list_servers()

    # Format as mcpServers-style config (compatible with Claude Code / MCP clients)
    config: dict[str, dict] = {}
    for s in servers:
        entry: dict = {
            "command": s.command,
            "args": s.args,
        }
        if s.env:
            entry["env"] = s.env
        if not s.enabled:
            entry["disabled"] = True
        config[s.name] = entry

    output = {"mcpServers": config}
    console.print(json.dumps(output, indent=2, ensure_ascii=False))


@mcp_app.command("tools")
def mcp_tools(
    server: str = typer.Argument(..., help="Name of the MCP server to query."),
):
    """List tools available from an MCP server (starts server temporarily)."""
    bridge = get_mcp_bridge()
    config = bridge.get_server(server)
    if config is None:
        console.print(f"[red]Server '{server}' not found.[/red]")
        raise typer.Exit(1)

    client = MCPClient(config)
    try:
        client.start()
        tools = client.list_tools()
    finally:
        client.stop()

    if not tools:
        console.print(f"[yellow]No tools reported by '{server}'.[/yellow]")
        return

    table = Table(title=f"Tools from '{server}' ({len(tools)})")
    table.add_column("Name", style="bold")
    table.add_column("Description", style="dim")
    for t in tools:
        table.add_row(t.get("name", ""), t.get("description", ""))
    console.print(table)


@mcp_app.command("call")
def mcp_call(
    server: str = typer.Argument(..., help="Name of the MCP server."),
    tool: str = typer.Argument(..., help="Tool name to call."),
    args_json: str = typer.Option("{}", "--args", help="Tool arguments as a JSON string."),
):
    """Call a tool on an MCP server."""
    bridge = get_mcp_bridge()
    config = bridge.get_server(server)
    if config is None:
        console.print(f"[red]Server '{server}' not found.[/red]")
        raise typer.Exit(1)

    try:
        arguments = json.loads(args_json)
    except json.JSONDecodeError as exc:
        console.print(f"[red]Invalid JSON for --args: {exc}[/red]")
        raise typer.Exit(1)

    client = MCPClient(config)
    try:
        client.start()
        result = client.call_tool(tool, arguments)
    finally:
        client.stop()

    console.print(json.dumps(result, indent=2, ensure_ascii=False))
