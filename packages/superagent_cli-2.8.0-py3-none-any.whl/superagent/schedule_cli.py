"""Schedule CLI — cron-style agent task scheduling.

Inspired by Moxt.ai's 24/7 automated agent execution pattern.
Enables scheduling recurring agent tasks like:
  - Nightly competitor monitoring
  - Weekly report generation
  - Hourly data analysis

Schedules are stored as JSON files under ~/.superagent/schedules/
and executed by `superagent schedule run` (meant to be called from system cron).
"""
from __future__ import annotations

import json
import os
import uuid
from datetime import datetime, timezone
from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from superagent.file_util import atomic_write

console = Console()
schedule_app = typer.Typer()


@schedule_app.command("add")
def schedule_add(
    goal: str = typer.Argument(..., help="Task goal to execute on schedule."),
    cron: str = typer.Option("0 9 * * *", "--cron", "-c", help="Cron expression (default: daily 9am)."),
    name: Optional[str] = typer.Option(None, "--name", "-n", help="Schedule name."),
    command: str = typer.Option("builtin", "--command", help="Execution command (builtin, local, claude)."),
    max_agents: int = typer.Option(3, "--max-agents", "-m", help="Max agents."),
    enabled: bool = typer.Option(True, "--enabled/--disabled", help="Whether schedule is active."),
):
    """Add a scheduled recurring agent task.

    Examples:
        superagent schedule add "Monitor competitor pricing" --cron "0 2 * * *" --name nightly-monitor
        superagent schedule add "Generate weekly report" --cron "0 9 * * 1" --name weekly-report
        superagent schedule add "Analyze error logs" --cron "0 * * * *" --command local
    """
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    schedules_dir = os.path.join(data_dir, "schedules")
    os.makedirs(schedules_dir, exist_ok=True)

    schedule_id = uuid.uuid4().hex[:8]
    schedule = {
        "id": schedule_id,
        "name": name or f"schedule-{schedule_id}",
        "goal": goal,
        "cron": cron,
        "command": command,
        "max_agents": max_agents,
        "enabled": enabled,
        "created_at": datetime.now(timezone.utc).isoformat(),
        "last_run": None,
        "run_count": 0,
    }

    path = os.path.join(schedules_dir, f"{schedule_id}.json")
    atomic_write(path, json.dumps(schedule, indent=2, ensure_ascii=False))

    console.print(f"[green]Schedule created:[/green] {schedule['name']}")
    console.print(f"  ID: {schedule_id}")
    console.print(f"  Goal: {goal}")
    console.print(f"  Cron: {cron}")
    console.print(f"  Command: {command}")
    console.print()
    console.print("[dim]To activate, add to system crontab:[/dim]")
    console.print(f"  [cyan]{cron} superagent schedule run {schedule_id}[/cyan]")


@schedule_app.command("list")
def schedule_list():
    """List all scheduled tasks."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    schedules_dir = os.path.join(data_dir, "schedules")

    if not os.path.isdir(schedules_dir):
        console.print("[dim]No schedules configured.[/dim]")
        return

    table = Table(title="Scheduled Tasks")
    table.add_column("ID", style="dim")
    table.add_column("Name", style="bold")
    table.add_column("Cron")
    table.add_column("Goal")
    table.add_column("Enabled")
    table.add_column("Runs", style="dim")
    table.add_column("Last Run", style="dim")

    for f in sorted(os.listdir(schedules_dir)):
        if not f.endswith(".json"):
            continue
        try:
            data = json.loads(open(os.path.join(schedules_dir, f), encoding="utf-8").read())
            status = "[green]Yes[/green]" if data.get("enabled") else "[red]No[/red]"
            last = (data.get("last_run") or "never")[:19]
            table.add_row(
                data.get("id", "?"),
                data.get("name", "?"),
                data.get("cron", "?"),
                data.get("goal", "")[:50],
                status,
                str(data.get("run_count", 0)),
                last,
            )
        except (json.JSONDecodeError, OSError):
            continue

    console.print(table)


@schedule_app.command("run")
def schedule_run(
    schedule_id: str = typer.Argument(..., help="Schedule ID to execute."),
):
    """Execute a scheduled task (called by system cron)."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    path = os.path.join(data_dir, "schedules", f"{schedule_id}.json")

    if not os.path.isfile(path):
        console.print(f"[red]Schedule '{schedule_id}' not found.[/red]")
        raise typer.Exit(1)

    data = json.loads(open(path, encoding="utf-8").read())
    if not data.get("enabled"):
        console.print(f"[yellow]Schedule '{data['name']}' is disabled. Skipping.[/yellow]")
        return

    console.print(f"[bold]Running schedule: {data['name']}[/bold]")
    console.print(f"  Goal: {data['goal']}")

    # Update run metadata
    data["last_run"] = datetime.now(timezone.utc).isoformat()
    data["run_count"] = data.get("run_count", 0) + 1
    atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))

    # Execute via auto command
    import subprocess
    import sys
    cmd = [
        sys.executable, "-m", "superagent", "auto", data["goal"],
        "--command", data.get("command", "builtin"),
        "--max-agents", str(data.get("max_agents", 3)),
    ]
    console.print(f"  [dim]$ {' '.join(cmd)}[/dim]")
    subprocess.run(cmd, cwd=os.getcwd())


@schedule_app.command("remove")
def schedule_remove(
    schedule_id: str = typer.Argument(..., help="Schedule ID to remove."),
):
    """Remove a scheduled task."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    path = os.path.join(data_dir, "schedules", f"{schedule_id}.json")
    if os.path.isfile(path):
        os.unlink(path)
        console.print(f"[green]Schedule '{schedule_id}' removed.[/green]")
    else:
        console.print(f"[red]Schedule '{schedule_id}' not found.[/red]")


@schedule_app.command("toggle")
def schedule_toggle(
    schedule_id: str = typer.Argument(..., help="Schedule ID to toggle."),
):
    """Toggle a schedule enabled/disabled."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.expanduser("~/.superagent"))
    path = os.path.join(data_dir, "schedules", f"{schedule_id}.json")
    if not os.path.isfile(path):
        console.print(f"[red]Schedule '{schedule_id}' not found.[/red]")
        raise typer.Exit(1)

    data = json.loads(open(path, encoding="utf-8").read())
    data["enabled"] = not data.get("enabled", True)
    atomic_write(path, json.dumps(data, indent=2, ensure_ascii=False))
    status = "enabled" if data["enabled"] else "disabled"
    console.print(f"[green]Schedule '{data['name']}' {status}.[/green]")
