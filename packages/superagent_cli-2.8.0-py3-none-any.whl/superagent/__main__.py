"""Entry point for running superagent as a module: python -m superagent"""

from superagent.cli import main

if __name__ == "__main__":
    main()
