"""Token cost tracking for SuperAgent — per-model pricing and usage accounting.

Inspired by Hermes HUD's token cost tracking with hardcoded MODEL_PRICING.
Records input/output tokens and estimated cost for each LLM call.

Data persisted to the shared SQLite database (``superagent.db``) via ``db.get_db()``.
Cost records include ``user_id`` for multi-user cost attribution.
"""
from __future__ import annotations

import logging
import os
import sqlite3
from dataclasses import asdict, dataclass
from datetime import datetime, timezone
from typing import Optional

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Per-model pricing (USD per 1M tokens)
# ---------------------------------------------------------------------------

MODEL_PRICING: dict[str, dict[str, float]] = {
    # OpenAI
    "gpt-4o":              {"input": 2.50,  "output": 10.00},
    "gpt-4o-mini":         {"input": 0.15,  "output": 0.60},
    "gpt-4-turbo":         {"input": 10.00, "output": 30.00},
    "o1":                  {"input": 15.00, "output": 60.00},
    "o3-mini":             {"input": 1.10,  "output": 4.40},
    # Anthropic
    "claude-sonnet-4-20250514":  {"input": 3.00, "output": 15.00},
    "claude-opus-4-20250514":    {"input": 15.00, "output": 75.00},
    "claude-haiku-3-5":    {"input": 0.80,  "output": 4.00},
    # DeepSeek
    "deepseek-chat":       {"input": 0.14,  "output": 0.28},
    "deepseek-reasoner":   {"input": 0.55,  "output": 2.19},
    # Meta (via providers)
    "llama3":              {"input": 0.00,  "output": 0.00},  # local
    "llama-3.3-70b-versatile": {"input": 0.59, "output": 0.79},
    # Default fallback
    "_default":            {"input": 3.00,  "output": 15.00},
}


def _get_pricing(model: str) -> dict[str, float]:
    """Get pricing for a model, falling back to default."""
    # Try exact match
    if model in MODEL_PRICING:
        return MODEL_PRICING[model]
    # Try prefix match
    for key in MODEL_PRICING:
        if model.startswith(key):
            return MODEL_PRICING[key]
    return MODEL_PRICING["_default"]


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class CostRecord:
    """A single LLM call cost record."""
    timestamp: str
    provider: str
    model: str
    input_tokens: int
    output_tokens: int
    cost_usd: float
    user_id: str = ""
    team_name: str = ""
    agent_name: str = ""
    operation: str = ""  # e.g. "orchestrator", "execute_task", "wiki_query"

    def to_dict(self) -> dict:
        return asdict(self)


# ---------------------------------------------------------------------------
# Cost Store (SQLite-backed, shared DB)
# ---------------------------------------------------------------------------

_CREATE_TABLE = """
CREATE TABLE IF NOT EXISTS cost_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp TEXT,
    user_id TEXT DEFAULT '',
    provider TEXT,
    model TEXT,
    input_tokens INTEGER DEFAULT 0,
    output_tokens INTEGER DEFAULT 0,
    cost_usd REAL DEFAULT 0.0,
    team_name TEXT DEFAULT '',
    agent_name TEXT DEFAULT '',
    operation TEXT DEFAULT ''
);

CREATE INDEX IF NOT EXISTS idx_cost_records_user ON cost_records(user_id);
CREATE INDEX IF NOT EXISTS idx_cost_records_timestamp ON cost_records(timestamp);
"""


class CostTracker:
    """Track and query LLM token costs.

    Uses the shared SQLite database via ``db.get_db()``.
    """

    def __init__(self, db_path: str | None = None):
        if db_path is None:
            from superagent.db import get_db
            self._conn = get_db()
        else:
            os.makedirs(os.path.dirname(db_path), exist_ok=True)
            self._conn = sqlite3.connect(db_path, check_same_thread=False)
            self._conn.row_factory = sqlite3.Row
            self._conn.execute("PRAGMA journal_mode=WAL")
        self._conn.executescript(_CREATE_TABLE)
        self._conn.commit()

    def record(
        self,
        provider: str,
        model: str,
        input_tokens: int,
        output_tokens: int,
        *,
        user_id: str = "",
        team_name: str = "",
        agent_name: str = "",
        operation: str = "",
    ) -> CostRecord:
        """Record a single LLM call with cost estimation."""
        pricing = _get_pricing(model)
        cost = (input_tokens * pricing["input"] + output_tokens * pricing["output"]) / 1_000_000

        record = CostRecord(
            timestamp=datetime.now(timezone.utc).isoformat(),
            provider=provider,
            model=model,
            input_tokens=input_tokens,
            output_tokens=output_tokens,
            cost_usd=round(cost, 6),
            user_id=user_id,
            team_name=team_name,
            agent_name=agent_name,
            operation=operation,
        )

        self._conn.execute(
            """INSERT INTO cost_records
               (timestamp, user_id, provider, model, input_tokens, output_tokens,
                cost_usd, team_name, agent_name, operation)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (record.timestamp, record.user_id, record.provider, record.model,
             record.input_tokens, record.output_tokens, record.cost_usd,
             record.team_name, record.agent_name, record.operation),
        )
        self._conn.commit()
        return record

    def summary(self, days: int = 30, user_id: str = "") -> dict:
        """Get cost summary for the last N days.

        If ``user_id`` is provided, filters to that user's costs.
        """
        from datetime import timedelta
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()

        where = "WHERE timestamp > ?"
        params: list = [cutoff]
        if user_id:
            where += " AND user_id = ?"
            params.append(user_id)

        row = self._conn.execute(
            f"""SELECT
                 COUNT(*) as calls,
                 COALESCE(SUM(input_tokens), 0) as total_input,
                 COALESCE(SUM(output_tokens), 0) as total_output,
                 COALESCE(SUM(cost_usd), 0) as total_cost
               FROM cost_records {where}""",
            params,
        ).fetchone()

        by_model = self._conn.execute(
            f"""SELECT model, COUNT(*) as calls,
                 SUM(input_tokens) as input_t, SUM(output_tokens) as output_t,
                 SUM(cost_usd) as cost
               FROM cost_records {where}
               GROUP BY model ORDER BY cost DESC""",
            params,
        ).fetchall()

        by_day = self._conn.execute(
            f"""SELECT DATE(timestamp) as day, SUM(cost_usd) as cost, COUNT(*) as calls
               FROM cost_records {where}
               GROUP BY day ORDER BY day DESC LIMIT 30""",
            params,
        ).fetchall()

        return {
            "period_days": days,
            "total_calls": row["calls"],
            "total_input_tokens": row["total_input"],
            "total_output_tokens": row["total_output"],
            "total_cost_usd": round(row["total_cost"], 4),
            "by_model": [
                {"model": r["model"], "calls": r["calls"],
                 "input_tokens": r["input_t"], "output_tokens": r["output_t"],
                 "cost_usd": round(r["cost"], 4)}
                for r in by_model
            ],
            "by_day": [
                {"day": r["day"], "cost_usd": round(r["cost"], 4), "calls": r["calls"]}
                for r in by_day
            ],
        }

    def recent(self, limit: int = 20, user_id: str = "") -> list[dict]:
        """Get recent cost records."""
        if user_id:
            rows = self._conn.execute(
                "SELECT * FROM cost_records WHERE user_id = ? ORDER BY id DESC LIMIT ?",
                (user_id, limit),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT * FROM cost_records ORDER BY id DESC LIMIT ?", (limit,),
            ).fetchall()
        return [dict(r) for r in rows]


# ---------------------------------------------------------------------------
# Singleton
# ---------------------------------------------------------------------------

_tracker: Optional[CostTracker] = None


def get_cost_tracker() -> CostTracker:
    global _tracker
    if _tracker is None:
        _tracker = CostTracker()
    return _tracker
