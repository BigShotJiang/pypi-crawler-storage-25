"""SuperAgent LLM CLI commands — list, add, remove, configure, and test LLM providers."""

from __future__ import annotations

from typing import Optional

import typer
from rich.console import Console
from rich.table import Table

from superagent.llm_gateway import LLMGateway, ProviderConfig, call_llm, get_llm_gateway

llm_app = typer.Typer(
    name="llm",
    help="LLM Gateway — manage providers, API keys, and test connectivity.",
    no_args_is_help=True,
)
console = Console()


@llm_app.command("list")
def llm_list(
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Show all configured LLM providers."""
    gw = get_llm_gateway()
    providers = gw.list_providers()
    default = gw.get_default()
    default_name = default.name if default else ""

    if json_out:
        import json

        data = [p.to_dict() for p in providers]
        console.print(json.dumps(data, indent=2, ensure_ascii=False))
        return

    if not providers:
        console.print("[yellow]No providers configured.[/yellow]")
        return

    table = Table(title=f"LLM Providers ({len(providers)})")
    table.add_column("Name", style="bold", width=14)
    table.add_column("Model", style="cyan", width=30)
    table.add_column("Base URL", style="dim", max_width=40)
    table.add_column("Has Key", width=8)
    table.add_column("Default", width=8)

    for p in providers:
        resolved = LLMGateway.resolve_api_key(p)
        has_key = "[green]yes[/green]" if resolved else "[dim]no[/dim]"
        is_default = "[green]*[/green]" if p.name == default_name else ""
        table.add_row(p.name, p.default_model, p.base_url, has_key, is_default)

    console.print(table)


@llm_app.command("add")
def llm_add(
    name: str = typer.Option(..., "--name", "-n", help="Provider name (e.g. openai, my-custom)."),
    base_url: str = typer.Option(..., "--base-url", "-b", help="API base URL."),
    model: str = typer.Option(..., "--model", "-m", help="Default model name."),
    api_key: str = typer.Option("", "--api-key", "-k", help="API key or $ENV_VAR reference."),
):
    """Add or update an LLM provider."""
    gw = get_llm_gateway()
    existing = gw.get_provider(name)

    config = ProviderConfig(
        name=name,
        api_key=api_key,
        base_url=base_url,
        default_model=model,
        enabled=True,
    )
    gw.add_provider(config)

    if existing:
        console.print(f"[green]Updated provider '{name}'.[/green]")
    else:
        console.print(f"[green]Added provider '{name}'.[/green]")


@llm_app.command("remove")
def llm_remove(
    name: str = typer.Argument(..., help="Provider name to remove."),
):
    """Remove an LLM provider."""
    gw = get_llm_gateway()

    if not gw.remove_provider(name):
        console.print(f"[red]Provider '{name}' not found.[/red]")
        raise typer.Exit(1)

    console.print(f"[green]Removed provider '{name}'.[/green]")


@llm_app.command("default")
def llm_default(
    name: Optional[str] = typer.Argument(None, help="Provider name to set as default."),
):
    """Show or set the default LLM provider."""
    gw = get_llm_gateway()

    if name is None:
        current = gw.get_default()
        if current:
            console.print(f"Default provider: [bold]{current.name}[/bold] ({current.default_model})")
        else:
            console.print("[yellow]No default provider set.[/yellow]")
        return

    if not gw.get_provider(name):
        console.print(f"[red]Provider '{name}' not found.[/red]")
        raise typer.Exit(1)

    gw.set_default(name)
    console.print(f"[green]Default provider set to '{name}'.[/green]")


@llm_app.command("test")
def llm_test(
    name: Optional[str] = typer.Argument(None, help="Provider name to test (default: default provider)."),
):
    """Test provider connectivity with an HTTP HEAD request to the base URL."""
    import urllib.error
    import urllib.request

    gw = get_llm_gateway()

    if name is None:
        provider = gw.get_default()
        if not provider:
            console.print("[red]No default provider set. Specify a provider name.[/red]")
            raise typer.Exit(1)
    else:
        provider = gw.get_provider(name)
        if not provider:
            console.print(f"[red]Provider '{name}' not found.[/red]")
            raise typer.Exit(1)

    url = provider.base_url
    if not url:
        console.print(f"[red]Provider '{provider.name}' has no base URL configured.[/red]")
        raise typer.Exit(1)

    console.print(f"Testing [bold]{provider.name}[/bold] at {url} ...")

    try:
        req = urllib.request.Request(url, method="HEAD")
        resolved_key = LLMGateway.resolve_api_key(provider)
        if resolved_key:
            req.add_header("Authorization", f"Bearer {resolved_key}")
        with urllib.request.urlopen(req, timeout=10) as resp:
            console.print(f"[green]OK[/green] — HTTP {resp.status}")
    except urllib.error.HTTPError as exc:
        # Many APIs return 4xx for HEAD but that still means the server is reachable
        if exc.code in (401, 403, 404, 405):
            console.print(f"[green]Reachable[/green] — HTTP {exc.code} ({exc.reason})")
        else:
            console.print(f"[red]Error[/red] — HTTP {exc.code}: {exc.reason}")
            raise typer.Exit(1)
    except (urllib.error.URLError, OSError) as exc:
        console.print(f"[red]Connection failed[/red] — {exc}")
        raise typer.Exit(1)


@llm_app.command("call")
def llm_call(
    provider: Optional[str] = typer.Argument(None, help="Provider name (default: default provider)."),
    prompt: str = typer.Option("Hello! Reply in one sentence.", "--prompt", "-p", help="User prompt to send."),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Override the provider's default model."),
):
    """Send a prompt to an LLM provider and display the response."""
    gw = get_llm_gateway()

    if provider is None:
        default = gw.get_default()
        if not default:
            console.print("[red]No default provider set. Specify a provider name.[/red]")
            raise typer.Exit(1)
        provider = default.name

    cfg = gw.get_provider(provider)
    if not cfg:
        console.print(f"[red]Provider '{provider}' not found.[/red]")
        raise typer.Exit(1)

    resolved_model = model or cfg.default_model
    console.print(f"Calling [bold]{provider}[/bold] (model: {resolved_model}) ...")

    try:
        messages = [{"role": "user", "content": prompt}]
        reply = call_llm(provider, messages, model=model)
        console.print(f"\n[green]Response:[/green]\n{reply}")
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)
