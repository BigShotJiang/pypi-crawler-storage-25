"""CLI commands for SuperAgent checkpoint management.

Provides the ``superagent checkpoint`` subcommand group with list, show, save,
pause, resume, and cleanup operations.  Uses Rich for formatted output.
"""

from __future__ import annotations

import json
import os
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.checkpoint import Checkpoint, CheckpointStatus, get_checkpoint_store

checkpoint_app = typer.Typer(
    name="checkpoint",
    help="Checkpoint management — save, resume, and manage durable execution checkpoints.",
    no_args_is_help=True,
)
console = Console()


def _get_store():
    """Create a CheckpointStore using the configured data directory."""
    data_dir = os.environ.get("CLAWTEAM_DATA_DIR", os.path.join(os.path.expanduser("~"), ".superagent"))
    return get_checkpoint_store(data_dir)


def _resolve_status(status: Optional[str]) -> Optional[CheckpointStatus]:
    """Convert a CLI status string to a CheckpointStatus enum value."""
    if status is None:
        return None
    status = status.strip().lower()
    try:
        return CheckpointStatus(status)
    except ValueError:
        valid = ", ".join(s.value for s in CheckpointStatus)
        console.print(f"[red]Invalid status '{status}'. Choose from: {valid}[/red]")
        raise typer.Exit(1)


def _status_style(status: CheckpointStatus) -> str:
    """Return a Rich style for a checkpoint status."""
    return {
        CheckpointStatus.active: "bold green",
        CheckpointStatus.paused: "bold yellow",
        CheckpointStatus.completed: "bold cyan",
        CheckpointStatus.failed: "bold red",
    }.get(status, "dim")


# ------------------------------------------------------------------
# Commands
# ------------------------------------------------------------------


@checkpoint_app.command("list")
def checkpoint_list(
    team: Optional[str] = typer.Option(None, "--team", "-t", help="Filter by team name."),
    status: Optional[str] = typer.Option(None, "--status", "-s", help="Filter by status (active, paused, completed, failed)."),
):
    """List checkpoints with optional filters."""
    store = _get_store()
    cp_status = _resolve_status(status)
    checkpoints = store.list_checkpoints(team=team, status=cp_status)

    if not checkpoints:
        console.print("[yellow]No checkpoints found.[/yellow]")
        return

    table = Table(title=f"Checkpoints ({len(checkpoints)} found)")
    table.add_column("ID", style="cyan", width=14)
    table.add_column("Team", style="blue", width=16)
    table.add_column("Stage", style="magenta", width=20)
    table.add_column("Status", width=12)
    table.add_column("Agents", style="dim", width=8)
    table.add_column("Updated", style="dim", width=20)

    for cp in checkpoints:
        style = _status_style(cp.status)
        table.add_row(
            cp.id,
            cp.team,
            cp.stage[:20] if cp.stage else "-",
            f"[{style}]{cp.status.value}[/{style}]",
            str(len(cp.agent_states)),
            cp.updated_at[:19],
        )

    console.print(table)


@checkpoint_app.command("show")
def checkpoint_show(
    checkpoint_id: str = typer.Argument(..., help="Checkpoint ID to display."),
):
    """Show detailed information about a checkpoint."""
    store = _get_store()
    cp = store.get(checkpoint_id)

    if cp is None:
        console.print(f"[red]Checkpoint '{checkpoint_id}' not found.[/red]")
        raise typer.Exit(1)

    style = _status_style(cp.status)

    # Build agent states display
    agent_lines = ""
    if cp.agent_states:
        for agent, agent_status in sorted(cp.agent_states.items()):
            agent_lines += f"\n    {agent}: {agent_status}"
    else:
        agent_lines = "\n    (none)"

    # Build state display
    state_str = json.dumps(cp.state, indent=2, ensure_ascii=False) if cp.state else "(empty)"

    error_line = ""
    if cp.error:
        error_line = f"\n[bold]Error:[/bold]      [red]{cp.error}[/red]"

    console.print(Panel(
        f"[bold]ID:[/bold]         {cp.id}\n"
        f"[bold]Team:[/bold]       {cp.team}\n"
        f"[bold]Stage:[/bold]      {cp.stage or '(none)'}\n"
        f"[bold]Status:[/bold]     [{style}]{cp.status.value}[/{style}]\n"
        f"[bold]Created:[/bold]    {cp.created_at}\n"
        f"[bold]Updated:[/bold]    {cp.updated_at}"
        f"{error_line}\n"
        f"\n[bold]Agent States:[/bold]{agent_lines}\n"
        f"\n[bold]State Data:[/bold]\n{state_str}",
        title=f"Checkpoint: {cp.id}",
        border_style="cyan",
    ))


@checkpoint_app.command("save")
def checkpoint_save(
    team: str = typer.Argument(..., help="Team name for the checkpoint."),
    stage: str = typer.Option("init", "--stage", "-s", help="Current stage name."),
    state: Optional[str] = typer.Option(None, "--state", help="State data as JSON string."),
):
    """Create a new checkpoint for a team."""
    import uuid as _uuid

    store = _get_store()

    state_data: dict = {}
    if state:
        try:
            state_data = json.loads(state)
        except json.JSONDecodeError as e:
            console.print(f"[red]Invalid JSON for --state: {e}[/red]")
            raise typer.Exit(1)

    cp = Checkpoint(
        id=_uuid.uuid4().hex[:12],
        team=team,
        stage=stage,
        status=CheckpointStatus.active,
        state=state_data,
    )
    store.save(cp)

    console.print(Panel(
        f"[bold green]Checkpoint saved[/bold green]\n\n"
        f"  [bold]ID:[/bold]    {cp.id}\n"
        f"  [bold]Team:[/bold]  {cp.team}\n"
        f"  [bold]Stage:[/bold] {cp.stage}",
        title="checkpoint save",
        border_style="green",
    ))


@checkpoint_app.command("pause")
def checkpoint_pause(
    checkpoint_id: str = typer.Argument(..., help="Checkpoint ID to pause."),
):
    """Pause execution of a checkpoint."""
    store = _get_store()
    cp = store.pause(checkpoint_id)

    if cp is None:
        console.print(f"[red]Checkpoint '{checkpoint_id}' not found.[/red]")
        raise typer.Exit(1)

    console.print(f"[yellow]Checkpoint {cp.id} paused.[/yellow] (team: {cp.team}, stage: {cp.stage})")


@checkpoint_app.command("resume")
def checkpoint_resume(
    checkpoint_id: str = typer.Argument(..., help="Checkpoint ID to resume."),
):
    """Resume a paused checkpoint."""
    store = _get_store()

    # Check existence and state first
    cp = store.get(checkpoint_id)
    if cp is None:
        console.print(f"[red]Checkpoint '{checkpoint_id}' not found.[/red]")
        raise typer.Exit(1)

    if cp.status != CheckpointStatus.paused:
        console.print(f"[red]Checkpoint '{checkpoint_id}' is not paused (status: {cp.status.value}).[/red]")
        raise typer.Exit(1)

    cp = store.resume(checkpoint_id)
    console.print(f"[green]Checkpoint {cp.id} resumed.[/green] (team: {cp.team}, stage: {cp.stage})")


@checkpoint_app.command("cleanup")
def checkpoint_cleanup(
    team: str = typer.Argument(..., help="Team name to clean up checkpoints for."),
    keep: int = typer.Option(3, "--keep", "-k", help="Number of most recent checkpoints to keep."),
):
    """Remove old checkpoints for a team, keeping the N most recent."""
    store = _get_store()
    removed = store.cleanup(team, keep_latest=keep)

    if removed > 0:
        console.print(f"[green]Removed {removed} old checkpoint{'s' if removed != 1 else ''} for team '{team}'.[/green]")
    else:
        console.print(f"[dim]No checkpoints to clean up for team '{team}'.[/dim]")
