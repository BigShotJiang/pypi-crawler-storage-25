"""SuperAgent RAG CLI commands — document retrieval via RAGFlow or local fallback."""

from __future__ import annotations

import json
from typing import Optional

import typer
from rich.console import Console
from rich.panel import Panel
from rich.table import Table

from superagent.rag import RAGBridge, SimpleRAG, get_rag, is_ragflow_available

rag_app = typer.Typer(
    name="rag",
    help="RAG — document retrieval via RAGFlow or local keyword search.",
    no_args_is_help=True,
)
console = Console()


@rag_app.command("status")
def rag_status(
    url: Optional[str] = typer.Option(None, "--url", help="RAGFlow server URL."),
):
    """Check RAGFlow server availability and current mode."""
    base_url = url or "http://localhost:9380"
    available = is_ragflow_available(base_url)

    if available:
        console.print(Panel(
            f"[green]RAGFlow server is running at {base_url}[/green]\n\n"
            "Engine: [bold]ragflow[/bold]\n"
            "Run search with: [bold]superagent rag search \"your query\"[/bold]",
            title="RAG Status",
            border_style="green",
        ))
    else:
        rag = SimpleRAG()
        doc_count = len(rag.list_documents())
        console.print(Panel(
            f"[yellow]RAGFlow server not reachable at {base_url}[/yellow]\n\n"
            "Engine: [bold]simple (local keyword search)[/bold]\n"
            f"Documents in store: {doc_count}\n"
            f"Store path: {rag.store_dir}\n\n"
            "[dim]Install RAGFlow: https://github.com/infiniflow/ragflow\n"
            "Or use local mode — ingest files with: superagent rag ingest <file>[/dim]",
            title="RAG Status",
            border_style="yellow",
        ))


@rag_app.command("ingest")
def rag_ingest(
    file: str = typer.Argument(..., help="Path to file to ingest."),
    url: Optional[str] = typer.Option(None, "--url", help="RAGFlow server URL."),
    dataset: str = typer.Option("default", "--dataset", "-d", help="Dataset ID (RAGFlow mode)."),
):
    """Add a document to the knowledge base."""
    rag = get_rag(base_url=url)

    with console.status("[cyan]Ingesting document...[/cyan]"):
        if isinstance(rag, RAGBridge):
            doc_id = rag.upload_document(file, dataset_id=dataset)
            if doc_id:
                console.print(f"[green]Uploaded to RAGFlow: {doc_id}[/green]")
            else:
                console.print("[red]Upload failed — check RAGFlow logs.[/red]")
                raise typer.Exit(1)
        else:
            name = rag.ingest(file)
            console.print(f"[green]Ingested locally: {name}[/green]")


@rag_app.command("search")
def rag_search(
    query: str = typer.Argument(..., help="Search query."),
    limit: int = typer.Option(5, "--limit", "-n", help="Max results to return."),
    url: Optional[str] = typer.Option(None, "--url", help="RAGFlow server URL."),
    dataset: str = typer.Option("default", "--dataset", "-d", help="Dataset ID (RAGFlow mode)."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """Search the knowledge base for relevant document chunks."""
    rag = get_rag(base_url=url)

    with console.status("[cyan]Searching...[/cyan]"):
        if isinstance(rag, RAGBridge):
            results = rag.search(query, limit=limit, dataset_id=dataset)
        else:
            results = rag.search(query, limit=limit)

    if json_out:
        console.print(json.dumps(results, indent=2, ensure_ascii=False))
        return

    if not results:
        console.print(f"[yellow]No results found for '{query}'.[/yellow]")
        return

    console.print(Panel(
        f"[bold]{query}[/bold]\n[dim]engine: {rag.engine_name} | results: {len(results)}[/dim]",
        title="RAG Search",
        border_style="cyan",
    ))

    for i, r in enumerate(results, 1):
        score = r.get("score", 0)
        doc = r.get("document_name", "unknown")
        content = r.get("content", "").strip()
        # Truncate long content for display
        if len(content) > 500:
            content = content[:500] + "..."
        console.print(Panel(
            content,
            title=f"[bold]#{i}[/bold] {doc} [dim](score: {score:.2f})[/dim]",
            border_style="dim",
        ))


@rag_app.command("list")
def rag_list(
    url: Optional[str] = typer.Option(None, "--url", help="RAGFlow server URL."),
    dataset: str = typer.Option("default", "--dataset", "-d", help="Dataset ID (RAGFlow mode)."),
    json_out: bool = typer.Option(False, "--json", help="Output JSON."),
):
    """List all indexed documents."""
    rag = get_rag(base_url=url)

    if isinstance(rag, RAGBridge):
        docs = rag.list_documents(dataset_id=dataset)
    else:
        docs = rag.list_documents()

    if json_out:
        console.print(json.dumps(docs, indent=2, ensure_ascii=False))
        return

    if not docs:
        console.print("[yellow]No documents indexed.[/yellow]")
        console.print("Use [bold]superagent rag ingest <file>[/bold] to add documents.")
        return

    table = Table(title=f"Indexed Documents ({len(docs)}) — engine: {rag.engine_name}")
    table.add_column("Name", style="bold", max_width=40)
    table.add_column("ID", style="dim", max_width=20)
    table.add_column("Size", justify="right")
    table.add_column("Status", style="cyan")

    for d in docs:
        size = d.get("size", 0)
        size_str = f"{size:,} B" if size < 1024 else f"{size / 1024:.1f} KB"
        table.add_row(
            d.get("name", ""),
            d.get("id", ""),
            size_str,
            d.get("status", ""),
        )

    console.print(table)
