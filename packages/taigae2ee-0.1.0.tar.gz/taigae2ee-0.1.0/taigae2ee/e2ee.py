import struct, secrets
from gostcrypto import gostcipher, gosthash, gostsignature

# ========== Низкоуровневые обёртки над PyGOST ==========

def _kuznechik_encrypt_block(key: bytes, block: bytes) -> bytes:
    """Зашифровать один 128-битный блок Кузнечиком."""
    cipher = gostcipher.new('kuznechik', key, gostcipher.MODE_ECB)
    return cipher.encrypt(block)

def _streebog_256(data: bytes) -> bytes:
    """Хэш Стрибог-256."""
    return gosthash.new('streebog256', data=data).digest()

def _streebog_512(data: bytes) -> bytes:
    """Хэш Стрибог-512."""
    return gosthash.new('streebog512', data=data).digest()

def _mgm_encrypt(key: bytes, nonce: bytes, plaintext: bytes, associated_data: bytes = b'') -> (bytes, bytes):
    """Режим MGM (ГОСТ 34.13-2015) — возвращает (ciphertext, tag)."""
    cipher = gostcipher.new('kuznechik', key, gostcipher.MODE_MGM, nonce=nonce, aad=associated_data)
    ct = cipher.encrypt(plaintext)
    tag = cipher.mac
    return ct, tag

def _mgm_decrypt(key: bytes, nonce: bytes, ciphertext: bytes, tag: bytes, associated_data: bytes = b'') -> bytes:
    cipher = gostcipher.new('kuznechik', key, gostcipher.MODE_MGM, nonce=nonce, aad=associated_data)
    pt = cipher.decrypt(ciphertext)
    if cipher.mac != tag:
        raise ValueError("Invalid tag")
    return pt

# ========== Эллиптическая кривая и ECDH ==========

def _generate_keypair():
    """Генерирует пару ключей ГОСТ Р 34.10-2012 (256 бит)."""
    private_key = gostsignature.GOSTSignatureKey(curve='id-tc26-gost-3410-12-256-paramSetA')
    private_key.generate()
    public_key = private_key.public_key
    # Получаем байтовое представление
    priv_bytes = private_key.encoded  # 32 байта
    pub_bytes = public_key.encoded    # 64 байта (x||y)
    return priv_bytes, pub_bytes

def _ecdh(private_key_bytes: bytes, public_key_bytes: bytes) -> bytes:
    """Вычисляет общий секрет по ECDH."""
    priv = gostsignature.GOSTSignatureKey(curve='id-tc26-gost-3410-12-256-paramSetA',
                                           encoded=private_key_bytes)
    pub = gostsignature.GOSTPublicKey(curve='id-tc26-gost-3410-12-256-paramSetA',
                                      encoded=public_key_bytes)
    shared = priv.dh(pub)
    return shared  # 32 байта (x-координата)

# ========== KDF и подтверждение ключа ==========

def _derive_key(shared_secret: bytes, salt: bytes) -> bytes:
    """Простая KDF на основе Стрибог-256."""
    return _streebog_256(salt + shared_secret)

def _make_confirmation(key: bytes, sender_pub: bytes) -> bytes:
    """Создаёт 8-байтный тег подтверждения ключа."""
    return _streebog_256(b"CONFIRM" + sender_pub + key)[:8]

# ========== Основной класс пользователя ==========

class TaigaUser:
    """
    Пользователь протокола сквозного шифрования «Тайга».
    Обладает долговременной ключевой парой и умеет шифровать/расшифровывать сообщения.
    """
    def __init__(self):
        self.priv_bytes, self.pub_bytes = _generate_keypair()

    def clear(self):
        """Затирает приватный ключ в памяти."""
        if self.priv_bytes:
            mask = secrets.token_bytes(32)
            self.priv_bytes = bytes(a ^ b for a, b in zip(self.priv_bytes, mask))
            self.priv_bytes = None

    def encrypt_for(self, recipient_pub_bytes: bytes, plaintext: bytes) -> bytes:
        """
        Шифрует сообщение для получателя.
        Возвращает бинарный пакет, готовый к передаче по сети.
        """
        # 1. Эфемерный ключ отправителя
        eph_priv, eph_pub = _generate_keypair()
        # 2. ECDH
        shared = _ecdh(eph_priv, recipient_pub_bytes)
        salt = secrets.token_bytes(16)
        key = _derive_key(shared, salt)

        # 3. Подтверждение ключа (отправитель доказывает знание ключа)
        confirm_tag = _make_confirmation(key, self.pub_bytes)  # используем свой долговременный pub

        # 4. Шифрование MGM
        nonce = secrets.token_bytes(16)
        ct, tag = _mgm_encrypt(key, nonce, plaintext)

        # 5. Бинарная упаковка
        # Формат: версия(1B) | эфемерный_публичный(64B) | salt(16B) | nonce(16B) | len_ct(2B big) | ct | tag(16B) | confirm(8B)
        body = (struct.pack(">B", 1)
                + eph_pub
                + salt
                + nonce
                + struct.pack(">H", len(ct))
                + ct
                + tag
                + confirm_tag)
        return body

    def decrypt_from(self, sender_pub_bytes: bytes, packet: bytes) -> bytes:
        """
        Расшифровывает сообщение от отправителя.
        Ожидает бинарный пакет, созданный encrypt_for.
        """
        pos = 0
        version = packet[pos]; pos += 1
        if version != 1:
            raise ValueError("Неизвестная версия пакета")
        eph_pub = packet[pos:pos+64]; pos += 64
        salt = packet[pos:pos+16]; pos += 16
        nonce = packet[pos:pos+16]; pos += 16
        ct_len = struct.unpack(">H", packet[pos:pos+2])[0]; pos += 2
        ct = packet[pos:pos+ct_len]; pos += ct_len
        tag = packet[pos:pos+16]; pos += 16
        confirm_tag = packet[pos:pos+8]; pos += 8

        # 1. ECDH
        shared = _ecdh(self.priv_bytes, eph_pub)
        key = _derive_key(shared, salt)

        # 2. Проверяем подтверждение ключа
        expected_confirm = _make_confirmation(key, sender_pub_bytes)
        if expected_confirm != confirm_tag:
            raise ValueError("Подтверждение ключа не совпало")

        # 3. Расшифровка
        return _mgm_decrypt(key, nonce, ct, tag)