"""
TokenSaver SDK - Python client for the TokenSaver API.

This package only contains code intended for PyPI/open-source publication.
No local pipeline orchestration is implemented here; it is an API client.
"""

from tokensaver_sdk.client import (
    ERROR_RAG_FILE_NOT_FOUND,
    HISTORY_LOCAL,
    HISTORY_NONE,
    HISTORY_SERVER,
    HistoryMode,
    TokenSaver,
    TokenSaverClient,
)
from tokensaver_sdk.errors import (
    AuthenticationError,
    ProviderKeyMissingError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    TimeoutError,
    TokenSaverError,
    ValidationError,
)
from tokensaver_sdk.types import (
    ContextView,
    MetricsView,
    PiiOptions,
    RagOptions,
    RunResult,
    TraceView,
)

__version__ = "0.1.5"
__all__ = [
    "TokenSaver",
    "TokenSaverClient",
    "ERROR_RAG_FILE_NOT_FOUND",
    "HISTORY_NONE",
    "HISTORY_LOCAL",
    "HISTORY_SERVER",
    "HistoryMode",
    "RunResult",
    "MetricsView",
    "TraceView",
    "ContextView",
    "RagOptions",
    "PiiOptions",
    "TokenSaverError",
    "AuthenticationError",
    "ProviderKeyMissingError",
    "QuotaExceededError",
    "RateLimitError",
    "ValidationError",
    "ServerError",
    "TimeoutError",
    "__version__",
]
