"""TokenSaver SDK client (pipeline, pricing, chat sessions)."""

from __future__ import annotations

import time
import uuid
from pathlib import Path
from typing import Any, Literal

import httpx

from tokensaver_sdk.errors import (
    AuthenticationError,
    ProviderKeyMissingError,
    QuotaExceededError,
    RateLimitError,
    ServerError,
    TimeoutError,
    TokenSaverError,
    ValidationError,
)
from tokensaver_sdk.types import ContextView, MetricsView, RunResult, TraceView

RetryableStatus = {429, 502, 503, 504}
DEFAULT_BASE_URL = "https://api.tokensaver.fr/api/v1"
HISTORY_NONE = "none"
HISTORY_LOCAL = "local"
HISTORY_SERVER = "server"
HistoryMode = Literal["none", "local", "server"]
HTTP_GET = "GET"
HTTP_POST = "POST"
HTTP_DELETE = "DELETE"
ENDPOINT_CHATS = "sdk/chats"
ENDPOINT_PIPELINES_RUN = "pipelines/run"
ENDPOINT_PRICING_ESTIMATE = "pricing/estimate"
ENDPOINT_RAG_DOCUMENTS = "rag/documents"
RAG_STATUS_DONE = "done"
RAG_STATUS_INGESTED = "ingested"
RAG_STATUS_ERROR = "error"
ERROR_TIMEOUT = "TIMEOUT"
ERROR_NETWORK = "NETWORK_ERROR"
ERROR_PROVIDER_KEY_MISSING = "PROVIDER_KEY_MISSING"
ERROR_QUOTA_EXCEEDED = "QUOTA_EXCEEDED"
ERROR_RATE_LIMITED = "RATE_LIMITED"
ERROR_AUTH = "AUTH_ERROR"
ERROR_VALIDATION = "VALIDATION_ERROR"
ERROR_SERVER = "SERVER_ERROR"
ERROR_UNKNOWN = "UNKNOWN_ERROR"
ERROR_RAG_INGESTION = "RAG_INGESTION_ERROR"
ERROR_RAG_INGESTION_TIMEOUT = "RAG_INGESTION_TIMEOUT"
ERROR_RAG_DOCUMENT_ID_MISSING = "RAG_DOCUMENT_ID_MISSING"
ERROR_RAG_FILE_NOT_FOUND = "RAG_FILE_NOT_FOUND"


class ChatSession:
    """Chat session wrapper for history modes."""

    def __init__(
        self,
        client: "TokenSaver",
        *,
        history_mode: HistoryMode,
        chat_id: str | None = None,
    ):
        self._client = client
        self.history_mode = history_mode
        self.chat_id = chat_id
        self._local_history: list[dict[str, str]] = []

    def ask(self, prompt: str, **kwargs: Any) -> RunResult:
        if self.history_mode == HISTORY_NONE:
            return self._client.ask(prompt, history=HISTORY_NONE, **kwargs)
        if self.history_mode == HISTORY_SERVER:
            return self._client.ask(prompt, history=HISTORY_SERVER, chat_id=self.chat_id, **kwargs)

        chat_history = list(self._local_history)
        result = self._client.ask(prompt, history=HISTORY_LOCAL, chat_history=chat_history, **kwargs)
        self._local_history.append({"role": "user", "content": prompt})
        self._local_history.append({"role": "assistant", "content": result.text})
        return result

    def messages(self, *, limit: int = 50, cursor: str | None = None, order: str = "asc") -> dict[str, Any]:
        if self.history_mode != HISTORY_SERVER or not self.chat_id:
            return {"items": [], "next_cursor": None, "has_more": False}
        params: dict[str, Any] = {"limit": limit, "order": order}
        if cursor:
            params["cursor"] = cursor
        response = self._client.get(f"{ENDPOINT_CHATS}/{self.chat_id}/messages", params=params)
        return self._client._parse_json_or_empty(response)

    def close(self) -> None:
        if self.history_mode == HISTORY_SERVER and self.chat_id:
            self._client.delete(f"{ENDPOINT_CHATS}/{self.chat_id}")


class _ChatFacade:
    def __init__(self, client: "TokenSaver"):
        self._client = client

    def session(
        self,
        *,
        history: HistoryMode = HISTORY_NONE,
        name: str = "New Chat",
        provider: str | None = None,
        model: str | None = None,
    ) -> ChatSession:
        if history == HISTORY_SERVER:
            payload = {"name": name, "provider": provider, "model": model}
            headers = {"Idempotency-Key": str(uuid.uuid4())}
            response = self._client.post(ENDPOINT_CHATS, json=payload, headers=headers)
            data = self._client._parse_json_or_empty(response)
            return ChatSession(self._client, history_mode=HISTORY_SERVER, chat_id=data.get("id"))
        return ChatSession(self._client, history_mode=history)


class TokenSaver:
    """Main SDK client."""

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        *,
        provider_api_key: str | None = None,
        timeout_total: float = 30.0,
        connect_timeout: float = 5.0,
        read_timeout: float = 25.0,
        max_retries: int = 2,
        headers: dict[str, str] | None = None,
    ):
        if not api_key:
            raise ValueError("api_key is required")

        # If caller does not provide a base URL, use TokenSaver production API endpoint.
        self.base_url = (base_url or DEFAULT_BASE_URL).rstrip("/")
        self.api_key = api_key
        pk = (provider_api_key or "").strip()
        self._default_provider_api_key: str | None = pk or None
        self.timeout_total = timeout_total
        self.connect_timeout = connect_timeout
        self.read_timeout = read_timeout
        self.max_retries = max_retries
        self._headers = {
            "Authorization": f"Bearer {api_key}",
            "Content-Type": "application/json",
            "Accept": "application/json",
            **(headers or {}),
        }
        self.chat = _ChatFacade(self)

    def _effective_provider_api_key(self, override: str | None) -> str | None:
        raw = self._default_provider_api_key if override is None else override
        if raw is None:
            return None
        s = str(raw).strip()
        return s or None

    def _http_timeout(self) -> httpx.Timeout:
        return httpx.Timeout(timeout=self.timeout_total, connect=self.connect_timeout, read=self.read_timeout)

    def _request(
        self,
        method: str,
        path: str,
        *,
        retryable: bool = True,
        **kwargs: Any,
    ) -> httpx.Response:
        url = f"{self.base_url}/{path.lstrip('/')}"
        req_headers = {**self._headers, **(kwargs.pop("headers", {}) or {})}
        last_error: Exception | None = None

        for attempt in range(self.max_retries + 1):
            try:
                response = httpx.request(method, url, headers=req_headers, timeout=self._http_timeout(), **kwargs)
                if retryable and response.status_code in RetryableStatus and attempt < self.max_retries:
                    self._sleep_backoff(attempt)
                    continue
                self._raise_for_error(response)
                return response
            except httpx.TimeoutException as exc:
                last_error = exc
                if retryable and attempt < self.max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise TimeoutError(code=ERROR_TIMEOUT, message="Request timed out") from exc
            except httpx.TransportError as exc:
                last_error = exc
                if retryable and attempt < self.max_retries:
                    self._sleep_backoff(attempt)
                    continue
                raise ServerError(code=ERROR_NETWORK, message=str(exc)) from exc
        raise ServerError(code=ERROR_NETWORK, message=str(last_error or "Unknown transport error"))

    @staticmethod
    def _sleep_backoff(attempt: int) -> None:
        time.sleep((2**attempt) * 0.15)

    def _parse_json_or_empty(self, response: httpx.Response) -> dict[str, Any]:
        return response.json() if response.content else {}

    def _raise_for_error(self, response: httpx.Response) -> None:
        if response.status_code < 400:
            return
        payload: dict[str, Any] = {}
        try:
            payload = response.json()
        except Exception:
            payload = {"message": response.text}

        code = str(payload.get("error_code") or "")
        message = str(payload.get("message") or payload.get("detail") or "Request failed")
        request_id = payload.get("request_id")
        details = payload.get("details") if isinstance(payload.get("details"), dict) else {}

        if not code:
            code = self._infer_error_code(response.status_code, message)

        kwargs = {
            "code": code,
            "message": message,
            "status_code": response.status_code,
            "request_id": request_id,
            "raw": payload,
        }
        if code == ERROR_PROVIDER_KEY_MISSING:
            raise ProviderKeyMissingError(provider=details.get("provider"), **kwargs)
        if code == ERROR_QUOTA_EXCEEDED:
            raise QuotaExceededError(
                quota_dimension=details.get("quota_dimension"),
                limit=details.get("limit"),
                current_usage=details.get("current_usage"),
                retry_after_seconds=details.get("retry_after_seconds"),
                **kwargs,
            )
        if code == ERROR_RATE_LIMITED:
            raise RateLimitError(retry_after_seconds=details.get("retry_after_seconds"), **kwargs)
        if code == ERROR_AUTH:
            raise AuthenticationError(**kwargs)
        if code == ERROR_VALIDATION:
            raise ValidationError(**kwargs)
        if response.status_code >= 500:
            raise ServerError(**kwargs)
        raise TokenSaverError(**kwargs)

    @staticmethod
    def _infer_error_code(status_code: int, message: str) -> str:
        lower = message.lower()
        if status_code == 429:
            return ERROR_RATE_LIMITED
        if status_code in (401, 403):
            if "quota limit reached" in lower:
                return ERROR_QUOTA_EXCEEDED
            if "provider key configured" in lower:
                return ERROR_PROVIDER_KEY_MISSING
            return ERROR_AUTH
        if status_code in (400, 422):
            return ERROR_VALIDATION
        if status_code >= 500:
            return ERROR_SERVER
        return ERROR_UNKNOWN

    def get(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._request(HTTP_GET, path, **kwargs)

    def post(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._request(HTTP_POST, path, **kwargs)

    def delete(self, path: str, **kwargs: Any) -> httpx.Response:
        return self._request(HTTP_DELETE, path, **kwargs)

    def run_pipeline(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        pipeline_id: str | None = None,
        use_cache: bool = False,
        use_rag: bool = False,
        use_compression: bool = False,
        use_pii_filter: bool = False,
        stream: bool = False,
        chat_id: str | None = None,
        chat_history: list[dict[str, str]] | None = None,
        temperature: float | None = None,
        rag_similarity_threshold: float | None = None,
        cache_similarity_threshold: float | None = None,
        compression_level: int | None = None,
        rag_options: dict[str, Any] | None = None,
        pii_options: dict[str, Any] | None = None,
        context_layers: dict[str, Any] | None = None,
        system_prompt: str | None = None,
        profile_context: str | None = None,
        workspace_instructions: str | None = None,
        provider_api_key: str | None = None,
    ) -> dict[str, Any]:
        """POST /pipelines/run — same optional fields as the API (thresholds, module options)."""
        payload: dict[str, Any] = {
            "prompt": prompt,
            "provider": provider.strip().lower(),
            "model": model,
            "pipeline_id": pipeline_id,
            "use_cache": use_cache,
            "use_rag": use_rag,
            "use_compression": use_compression,
            "use_pii_filter": use_pii_filter,
            "stream": stream,
        }
        if chat_id:
            payload["chat_id"] = chat_id
        if chat_history:
            payload["chat_history"] = chat_history
        optional: list[tuple[str, Any]] = [
            ("temperature", temperature),
            ("rag_similarity_threshold", rag_similarity_threshold),
            ("cache_similarity_threshold", cache_similarity_threshold),
            ("compression_level", compression_level),
            ("rag_options", rag_options),
            ("pii_options", pii_options),
            ("context_layers", context_layers),
            ("system_prompt", system_prompt),
            ("profile_context", profile_context),
            ("workspace_instructions", workspace_instructions),
        ]
        for key, val in optional:
            if val is not None:
                payload[key] = val
        eff_pk = self._effective_provider_api_key(provider_api_key)
        if eff_pk:
            payload["provider_api_key"] = eff_pk
        r = self.post(ENDPOINT_PIPELINES_RUN, json=payload)
        return self._parse_json_or_empty(r)

    def ask(
        self,
        prompt: str,
        *,
        provider: str,
        model: str,
        use_cache: bool = False,
        use_rag: bool = False,
        use_compression: bool = False,
        use_pii_filter: bool = False,
        history: HistoryMode = HISTORY_NONE,
        chat_id: str | None = None,
        chat_history: list[dict[str, str]] | None = None,
        temperature: float | None = None,
        rag_similarity_threshold: float | None = None,
        cache_similarity_threshold: float | None = None,
        compression_level: int | None = None,
        rag_options: dict[str, Any] | None = None,
        pii_options: dict[str, Any] | None = None,
        context_layers: dict[str, Any] | None = None,
        system_prompt: str | None = None,
        profile_context: str | None = None,
        workspace_instructions: str | None = None,
        provider_api_key: str | None = None,
    ) -> RunResult:
        data = self.run_pipeline(
            prompt,
            provider=provider,
            model=model,
            use_cache=use_cache,
            use_rag=use_rag,
            use_compression=use_compression,
            use_pii_filter=use_pii_filter,
            chat_id=chat_id if history == HISTORY_SERVER else None,
            chat_history=chat_history if history == HISTORY_LOCAL else None,
            temperature=temperature,
            rag_similarity_threshold=rag_similarity_threshold,
            cache_similarity_threshold=cache_similarity_threshold,
            compression_level=compression_level,
            rag_options=rag_options,
            pii_options=pii_options,
            context_layers=context_layers,
            system_prompt=system_prompt,
            profile_context=profile_context,
            workspace_instructions=workspace_instructions,
            provider_api_key=provider_api_key,
        )
        return self._to_run_result(data, history=history, chat_id=chat_id)

    def _to_run_result(
        self,
        data: dict[str, Any],
        *,
        history: HistoryMode,
        chat_id: str | None,
    ) -> RunResult:
        metadata = data.get("metadata") or {}
        token_metrics = metadata.get("token_metrics") or {}
        total = token_metrics.get("total") or {}
        prompt = token_metrics.get("prompt") or {}
        response = token_metrics.get("response") or {}
        trace = TraceView(
            request_id=metadata.get("request_id"),
            provider=data.get("provider") or metadata.get("provider"),
            model=data.get("model"),
        )
        metrics = MetricsView(
            cost_usd=total.get("cost"),
            latency_ms=total.get("latency_ms"),
            cache_hit=token_metrics.get("cache_hit"),
            tokens_input=prompt.get("after_compression_tokens") or prompt.get("raw_tokens"),
            tokens_output=response.get("tokens"),
            tokens_total=total.get("with_compression"),
            tokens_saved=total.get("tokens_saved"),
            savings_ratio=total.get("savings_ratio"),
        )
        context = ContextView(
            history_mode=history,
            chat_id=chat_id,
            layers_used=self._extract_layers_used(data.get("context_layers_used")),
        )
        return RunResult(
            text=str(data.get("response") or ""),
            raw=data,
            metrics=metrics,
            trace=trace,
            context=context,
        )

    @staticmethod
    def _extract_layers_used(context_layers_used: dict[str, Any] | None) -> list[str]:
        if not context_layers_used:
            return []
        layers: list[str] = []
        if "instruction_context" in context_layers_used:
            layers.append("instruction")
        if "knowledge_context" in context_layers_used:
            layers.append("knowledge")
        if "interaction_context" in context_layers_used:
            layers.append("interaction")
        return layers

    def estimate_cost(
        self,
        prompt_tokens: int,
        completion_tokens: int,
        provider: str,
        model: str,
    ) -> dict[str, Any]:
        r = self.post(
            ENDPOINT_PRICING_ESTIMATE,
            json={
                "prompt_tokens": prompt_tokens,
                "completion_tokens": completion_tokens,
                "provider": provider,
                "model": model,
            },
        )
        return self._parse_json_or_empty(r)

    def rag_list_documents(self) -> dict[str, Any]:
        """List RAG documents for the current user/workspace (`GET /rag/documents`)."""
        response = self.get(ENDPOINT_RAG_DOCUMENTS)
        return self._parse_json_or_empty(response)

    def rag_upload_document(
        self,
        file_path: str | Path,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> dict[str, Any]:
        """Upload a PDF document to RAG (`POST /rag/documents`)."""
        path = Path(file_path)
        if not path.is_file():
            resolved = path.resolve()
            raise ValidationError(
                code=ERROR_RAG_FILE_NOT_FOUND,
                message=f"RAG file not found or not a regular file: {resolved}",
                status_code=None,
                raw={"path": str(resolved)},
            )

        # Multipart requests must not force JSON Content-Type.
        headers = {k: v for k, v in self._headers.items() if k.lower() != "content-type"}
        with path.open("rb") as f:
            files = {"file": (path.name, f, "application/pdf")}
            data: dict[str, str] = {}
            if name:
                data["name"] = name
            if description:
                data["description"] = description
            response = httpx.post(
                f"{self.base_url}/{ENDPOINT_RAG_DOCUMENTS}",
                # Keep explicit multipart call to avoid JSON content-type.
                headers=headers,
                files=files,
                data=data,
                timeout=self._http_timeout(),
            )
        self._raise_for_error(response)
        return self._parse_json_or_empty(response)

    def rag_get_document(self, document_id: str) -> dict[str, Any]:
        """Get RAG document status/metadata (`GET /rag/documents/{document_id}`)."""
        response = self.get(f"{ENDPOINT_RAG_DOCUMENTS}/{document_id}")
        return self._parse_json_or_empty(response)

    def rag_wait_document_ready(
        self,
        document_id: str,
        *,
        timeout_seconds: float = 90.0,
        poll_interval_seconds: float = 2.0,
    ) -> dict[str, Any]:
        """Poll until RAG ingestion reaches `done`/`ingested` or fails."""
        deadline = time.time() + timeout_seconds
        while time.time() < deadline:
            payload = self.rag_get_document(document_id)
            status = str(payload.get("status") or "").strip().lower()
            if status in {RAG_STATUS_DONE, RAG_STATUS_INGESTED}:
                return payload
            if status == RAG_STATUS_ERROR:
                message = payload.get("error_message") or "RAG ingestion failed"
                raise ServerError(code=ERROR_RAG_INGESTION, message=str(message), raw=payload)
            time.sleep(poll_interval_seconds)
        raise TimeoutError(
            code=ERROR_RAG_INGESTION_TIMEOUT,
            message=f"Timed out waiting for RAG ingestion: {document_id}",
        )

    def rag_upload_and_wait(
        self,
        file_path: str | Path,
        *,
        name: str | None = None,
        description: str | None = None,
        timeout_seconds: float = 90.0,
        poll_interval_seconds: float = 2.0,
    ) -> dict[str, Any]:
        """Upload a RAG PDF then wait for ingestion readiness."""
        created = self.rag_upload_document(file_path, name=name, description=description)
        document_id = str(created.get("document_id") or "").strip()
        if not document_id:
            raise ValidationError(
                code=ERROR_RAG_DOCUMENT_ID_MISSING,
                message="Upload succeeded but response did not include document_id",
                raw=created,
            )
        return self.rag_wait_document_ready(
            document_id,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_seconds,
        )

    def rag_ensure_document(
        self,
        file_path: str | Path,
        *,
        reuse_existing: bool = True,
        name: str | None = None,
        description: str | None = None,
        timeout_seconds: float = 90.0,
        poll_interval_seconds: float = 2.0,
    ) -> dict[str, Any]:
        """
        Ensure a PDF is ingested: list existing docs and reuse one with the same filename
        if status is ``done``/``ingested``, or wait if ``pending``; otherwise upload.

        Filenames are compared to ``Path(file_path).name``. The API returns documents
        newest-first; the first matching name wins.
        """
        path = Path(file_path)
        if not reuse_existing:
            return self.rag_upload_and_wait(
                path,
                name=name,
                description=description,
                timeout_seconds=timeout_seconds,
                poll_interval_seconds=poll_interval_seconds,
            )
        want = path.name
        listing = self.rag_list_documents()
        for d in listing.get("documents") or []:
            if (d.get("filename") or "") != want:
                continue
            status = str(d.get("status") or "").strip().lower()
            did = str(d.get("document_id") or "").strip()
            if not did:
                continue
            if status in {RAG_STATUS_DONE, RAG_STATUS_INGESTED}:
                return d
            if status == "pending":
                return self.rag_wait_document_ready(
                    did,
                    timeout_seconds=timeout_seconds,
                    poll_interval_seconds=poll_interval_seconds,
                )
            break
        return self.rag_upload_and_wait(
            path,
            name=name,
            description=description,
            timeout_seconds=timeout_seconds,
            poll_interval_seconds=poll_interval_seconds,
        )


TokenSaverClient = TokenSaver
