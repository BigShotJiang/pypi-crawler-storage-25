"""Contract tests for TokenSaver SDK behavior."""

import pytest

from tokensaver_sdk import TokenSaver
from tokensaver_sdk.errors import ProviderKeyMissingError, QuotaExceededError


def test_quota_error_mapping(httpx_mock):
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        status_code=403,
        json={
            "error_code": "QUOTA_EXCEEDED",
            "message": "Quota limit reached",
            "request_id": "req_1",
            "details": {"quota_dimension": "tokens_per_month", "limit": 1000, "current_usage": 1000},
        },
    )
    client = TokenSaver("https://api.example.com/api/v1", "key")
    with pytest.raises(QuotaExceededError) as exc:
        client.ask("Hi", provider="openai", model="gpt-4o")
    assert exc.value.quota_dimension == "tokens_per_month"
    assert exc.value.request_id == "req_1"


def test_provider_missing_error_mapping(httpx_mock):
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        status_code=403,
        json={
            "error_code": "PROVIDER_KEY_MISSING",
            "message": "No LLM provider key configured",
            "request_id": "req_2",
            "details": {"provider": "openai"},
        },
    )
    client = TokenSaver("https://api.example.com/api/v1", "key")
    with pytest.raises(ProviderKeyMissingError) as exc:
        client.ask("Hi", provider="openai", model="gpt-4o")
    assert exc.value.provider == "openai"


def test_run_result_normalization(httpx_mock):
    httpx_mock.add_response(
        url="https://api.example.com/api/v1/pipelines/run",
        status_code=200,
        json={
            "response": "Hello",
            "model": "gpt-4o",
            "metadata": {
                "request_id": "req_3",
                "token_metrics": {
                    "cache_hit": False,
                    "prompt": {"raw_tokens": 10, "after_compression_tokens": 8},
                    "response": {"tokens": 20},
                    "total": {
                        "with_compression": 28,
                        "tokens_saved": 2,
                        "savings_ratio": 0.2,
                        "latency_ms": 120,
                        "cost": 0.01,
                    },
                },
            },
            "context_layers_used": {"instruction_context": {}, "knowledge_context": {}},
        },
    )
    client = TokenSaver("https://api.example.com/api/v1", "key")
    result = client.ask("Hi", provider="openai", model="gpt-4o")
    assert result.text == "Hello"
    assert result.trace.request_id == "req_3"
    assert result.metrics.cost_usd == 0.01
    assert result.metrics.tokens_total == 28
    assert result.context.layers_used == ["instruction", "knowledge"]
