"""Input type models for Questra Data API.

These Pydantic models provide type-safe wrappers for GraphQL input types
with Python snake_case field names and automatic camelCase serialization.

Both snake_case and camelCase field names are accepted in constructors
thanks to ``populate_by_name=True`` and ``alias_generator=to_camel``.
"""

from __future__ import annotations

from typing import Any

from pydantic import BaseModel, ConfigDict, field_serializer
from pydantic.alias_generators import to_camel

# Re-exports for Property-Helper from generated models
from ..generated.models import FieldAssignableDataTypeEnumType as AssignableDataType
from ..generated.models import FieldRelationTypeEnumType as RelationType
from ..generated.rest_models import (
    Aggregation,
    QuotationBehavior,
    TimeUnit,
    ValueAlignment,
    ValueAvailability,
)


class _CamelCaseModel(BaseModel):
    """Base model with camelCase alias generation for GraphQL compatibility."""

    model_config = ConfigDict(
        alias_generator=to_camel,
        populate_by_name=True,
    )

    def to_dict(self) -> dict[str, Any]:
        """Convert to dictionary with camelCase keys for GraphQL input.

        Filters None values and converts enums to their string values.
        """
        return self.model_dump(by_alias=True, exclude_none=True, mode="json")


class StringPropertyConfig(_CamelCaseModel):
    """
    String property configuration.

    Attributes:
        max_length: Maximum length in characters
        is_case_sensitive: Case sensitive (default: False)
    """

    max_length: int
    is_case_sensitive: bool = False

    @field_serializer("max_length")
    def _serialize_max_length(self, v: int) -> str:
        """GraphQL expects Long, send as string."""
        return str(v)


class FilePropertyConfig(_CamelCaseModel):
    """
    File property configuration.

    Attributes:
        max_length: Maximum length in bytes
    """

    max_length: int

    @field_serializer("max_length")
    def _serialize_max_length(self, v: int) -> str:
        """GraphQL expects Long, send as string."""
        return str(v)


class IntervalConfig(_CamelCaseModel):
    """
    Time interval configuration.

    Attributes:
        time_unit: Time unit (TimeUnit enum)
        multiplier: Interval multiplier (default: 1)
    """

    time_unit: TimeUnit
    multiplier: int = 1


class TimeSeriesPropertyConfig(_CamelCaseModel):
    """
    Configuration for TimeSeries properties.

    Corresponds to _CreateInventoryPropertyTimeSeries__InputType from the GraphQL schema.

    Attributes:
        interval: Time interval (IntervalConfig)
        unit: Unit (e.g. "kW", "kWh", "g")
        value_alignment: Value alignment (ValueAlignment Enum, default: LEFT)
        value_availability: Availability (ValueAvailability Enum, default: AT_INTERVAL_BEGIN)
        time_zone: Time zone (default: "Europe/Berlin")
        default_aggregation: Default aggregation (Aggregation Enum, optional)
        start_of_time: Start time (optional, ISO-8601 with microseconds)
        enable_audit: Enable audit (default: False)
        enable_quotation: Enable quotation (default: False)
        default_quotation_behavior: Default quotation behavior (QuotationBehavior Enum, default: LATEST)
        allow_specifics_per_instance: Allow specifications per instance (default: False)
    """

    interval: IntervalConfig
    unit: str
    value_alignment: ValueAlignment = ValueAlignment.LEFT
    value_availability: ValueAvailability = ValueAvailability.AT_INTERVAL_BEGIN
    time_zone: str = "Europe/Berlin"
    default_aggregation: Aggregation | None = None
    start_of_time: str | None = None
    enable_audit: bool = False
    enable_quotation: bool = False
    default_quotation_behavior: QuotationBehavior = QuotationBehavior.LATEST
    allow_specifics_per_instance: bool = False


class InventoryProperty(_CamelCaseModel):
    """
    Property definition for inventory creation.

    Corresponds to _CreateInventoryProperty__InputType from the GraphQL schema.

    Attributes:
        property_name: Name of the Property
        data_type: Data type (DataType Enum)
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description
        string: String-specific configuration (for AssignableDataType.STRING)
        file: File-specific configuration (for AssignableDataType.FILE)
        time_series: TimeSeries specific configuration (for AssignableDataType.TIME_SERIES)

    Example:
        Simple string property:

        ```python
        InventoryProperty(
            property_name="Name",
            data_type=AssignableDataType.STRING,
            is_required=True,
            string=StringPropertyConfig(max_length=200),
        )
        ```

    Example:
        Integer property:

        ```python
        InventoryProperty(
            property_name="Age", data_type=AssignableDataType.INT, is_required=False
        )
        ```

    Example:
        TimeSeries property:

        ```python
        InventoryProperty(
            property_name="messwerte_Energie",
            data_type=AssignableDataType.TIME_SERIES,
            time_series=TimeSeriesPropertyConfig(
                interval=IntervalConfig(time_unit=TimeUnit.MINUTE, multiplier=15),
                unit="kWh",
            ),
        )
        ```
    """

    property_name: str
    data_type: AssignableDataType
    is_required: bool = True
    is_unique: bool = False
    is_array: bool = False
    description: str | None = None
    string: StringPropertyConfig | None = None
    file: FilePropertyConfig | None = None
    time_series: TimeSeriesPropertyConfig | None = None


class TimeSeriesSpecifics(_CamelCaseModel):
    """
    Optional specifications for TimeSeries during creation.

    Corresponds to _TimeSeriesSpecifics__InputType from the GraphQL schema.

    Attributes:
        interval: Time interval (IntervalConfig, optional)
        value_alignment: Value alignment (ValueAlignment Enum, optional)
        value_availability: Availability (ValueAvailability Enum, optional)
        unit: Unit (str, optional)
        time_zone: Time zone (str, optional)
        default_aggregation: Default aggregation (Aggregation Enum, optional)
        start_of_time: Start time (str, optional, ISO-8601 with microseconds)
        default_quotation_behavior: Quotation behavior (QuotationBehavior Enum, optional)

    Example:
        With all options:

        ```python
        TimeSeriesSpecifics(
            interval=IntervalConfig(time_unit=TimeUnit.MINUTE, multiplier=15),
            value_alignment=ValueAlignment.LEFT,
            value_availability=ValueAvailability.AT_INTERVAL_BEGIN,
            unit="kWh",
            time_zone="Europe/Berlin",
            default_aggregation=Aggregation.AVERAGE,
            default_quotation_behavior=QuotationBehavior.LATEST,
        )
        ```

    Example:
        Minimal (all fields optional):

        ```python
        TimeSeriesSpecifics(
            interval=IntervalConfig(time_unit=TimeUnit.HOUR, multiplier=1), unit="kW"
        )
        ```
    """

    interval: IntervalConfig | None = None
    value_alignment: ValueAlignment | None = None
    value_availability: ValueAvailability | None = None
    unit: str | None = None
    time_zone: str | None = None
    default_aggregation: Aggregation | None = None
    start_of_time: str | None = None
    default_quotation_behavior: QuotationBehavior | None = None


class CreateTimeSeriesInput(_CamelCaseModel):
    """
    Input for creating a TimeSeries.

    Corresponds to _CreateTimeSeries__InputType from the GraphQL schema.

    Attributes:
        inventory_name: Name of the inventory
        property_name: Name of the Property
        namespace_name: Optional Namespace (default: None)
        specifics: Optional Timeseries specifications (TimeSeriesSpecifics)

    Example:
        With specifications:

        ```python
        CreateTimeSeriesInput(
            inventory_name="Sensoren",
            property_name="messwerte_temperatur",
            namespace_name="TestDaten",
            specifics=TimeSeriesSpecifics(
                interval=IntervalConfig(time_unit=TimeUnit.MINUTE, multiplier=15),
                unit="°C",
            ),
        )
        ```

    Example:
        Without specifications (uses property defaults):

        ```python
        CreateTimeSeriesInput(
            inventory_name="Sensoren", property_name="messwerte_energie"
        )
        ```
    """

    inventory_name: str
    property_name: str
    namespace_name: str | None = None
    specifics: TimeSeriesSpecifics | None = None


class InventoryRelation(_CamelCaseModel):
    """
    Relation definition for inventory creation.

    Corresponds to _CreateInventoryRelation__InputType from the GraphQL schema.

    Attributes:
        property_name: Name of the Relation-Property in Child-Inventory
        relation_type: Relation type (RelationType Enum)
        parent_inventory_name: Name of the Parent-inventory
        parent_property_name: Name of the Relation-Property in Parent-Inventory
        is_required: Required relation (optional)
        parent_namespace_name: Namespace of the parent inventory (optional)

    Example:
        One-to-Many Relation: Anlagen -> Technologie
        ```python
        InventoryRelation(
            property_name="Technologie",
            relation_type=RelationType.ONE_TO_MANY,
            parent_inventory_name="TEC",
            parent_property_name="Anlagen",
        )
        ```

    Example:
        One-to-Many: Many employees belong to one department
        ```python
        InventoryRelation(
            property_name="Abteilung",
            relation_type=RelationType.ONE_TO_MANY,
            parent_inventory_name="Departments",
            parent_property_name="Mitarbeiter",
            parent_namespace_name="HR",
            is_required=True,
        )
        ```
    """

    property_name: str
    relation_type: RelationType
    parent_inventory_name: str
    parent_property_name: str
    is_required: bool | None = None
    parent_namespace_name: str | None = None


# ==============================================================================
# Spezialisierte Property-Klassen (flache Hierarchie)
# ==============================================================================


class BaseProperty(_CamelCaseModel):
    """
    Base class for all specialized property classes.

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description
    """

    property_name: str
    is_required: bool = True
    is_unique: bool = False
    is_array: bool = False
    description: str | None = None


class StringProperty(BaseProperty):
    """
    String-Property. Replaces InventoryProperty(data_type=STRING, string=StringPropertyConfig(...)).

    Attributes:
        property_name: Name of the Property
        max_length: Maximum length in characters
        is_case_sensitive: Case-sensitive (default: False)
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        StringProperty(
            property_name="gebaeudename",
            max_length=100,
            is_required=True,
            is_unique=True,
        )
        ```
    """

    max_length: int
    is_case_sensitive: bool = False

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.STRING,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
            string=StringPropertyConfig(
                max_length=self.max_length, is_case_sensitive=self.is_case_sensitive
            ),
        )


class IntProperty(BaseProperty):
    """
    Integer-Property. Replaces InventoryProperty(data_type=INT).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        IntProperty(property_name="baujahr", is_required=False)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.INT,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class DecimalProperty(BaseProperty):
    """
    Decimal-Property. Replaces InventoryProperty(data_type=DECIMAL).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        DecimalProperty(property_name="preis", is_required=True)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.DECIMAL,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class LongProperty(BaseProperty):
    """
    Long-Property. Replaces InventoryProperty(data_type=LONG).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        LongProperty(property_name="artikel_nummer", is_required=False)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.LONG,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class BoolProperty(BaseProperty):
    """
    Boolean-Property. Replaces InventoryProperty(data_type=BOOLEAN).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        BoolProperty(property_name="aktiv", is_required=True)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.BOOLEAN,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class DateTimeProperty(BaseProperty):
    """
    DateTime-Property. Replaces InventoryProperty(data_type=DATE_TIME).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        DateTimeProperty(property_name="erstellt_am", is_required=True)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.DATE_TIME,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class DateTimeOffsetProperty(BaseProperty):
    """
    DateTimeOffset-Property. Replaces InventoryProperty(data_type=DATE_TIME_OFFSET).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        DateTimeOffsetProperty(property_name="letzte_aenderung", is_required=True)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.DATE_TIME_OFFSET,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class DateProperty(BaseProperty):
    """
    Date-Property. Replaces InventoryProperty(data_type=DATE).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        DateProperty(property_name="geburtsdatum", is_required=True)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.DATE,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class TimeProperty(BaseProperty):
    """
    Time-Property. Replaces InventoryProperty(data_type=TIME).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        TimeProperty(property_name="oeffnungszeit", is_required=True)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.TIME,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class GuidProperty(BaseProperty):
    """
    GUID-Property. Replaces InventoryProperty(data_type=GUID).

    Attributes:
        property_name: Name of the Property
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        GuidProperty(property_name="external_id", is_required=False)
        ```
    """

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.GUID,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
        )


class FileProperty(BaseProperty):
    """
    File-Property. Replaces InventoryProperty(data_type=FILE, file=FilePropertyConfig(...)).

    Attributes:
        property_name: Name of the Property
        max_length: Maximum length in bytes
        is_required: Required field (default: True)
        is_unique: Unique (default: False)
        is_array: Array field (default: False)
        description: Optional description

    Example:
        ```python
        FileProperty(
            property_name="dokument",
            max_length=10485760,  # 10 MB
            is_required=False,
        )
        ```
    """

    max_length: int

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.FILE,
            is_required=self.is_required,
            is_unique=self.is_unique,
            is_array=self.is_array,
            description=self.description,
            file=FilePropertyConfig(max_length=self.max_length),
        )


class TimeSeriesProperty(BaseProperty):
    """
    Timeseries Property. Replaces InventoryProperty(data_type=TIME_SERIES, time_series=TimeSeriesPropertyConfig(...)).

    Attributes:
        property_name: Name of the Property
        time_unit: Time unit (e.g. TimeUnit.MINUTE, TimeUnit.HOUR)
        unit: Unit of the measured values (e.g. "°C", "kWh", "%")
        multiplier: Multiplier for interval (default: 1)
        time_zone: Time zone (default: "Europe/Berlin")
        value_alignment: Value alignment (default: ValueAlignment.LEFT)
        value_availability: Availability (default: ValueAvailability.AT_INTERVAL_BEGIN)
        is_required: Required field (default: False, as TimeSeries are optional)
        description: Optional description
        default_aggregation: Default aggregation (optional)
        start_of_time: Start time (optional, ISO-8601)
        enable_audit: Enable audit (default: False)
        enable_quotation: Enable quotation (default: False)
        default_quotation_behavior: Default quotation behavior (default: QuotationBehavior.LATEST)
        allow_specifics_per_instance: Allow specifications per instance (default: False)

    Example:
        ```python
        TimeSeriesProperty(
            property_name="messwerte_temperatur",
            time_unit=TimeUnit.MINUTE,
            multiplier=15,
            unit="°C",
            time_zone="Europe/Berlin",
        )
        ```
    """

    time_unit: TimeUnit
    unit: str
    multiplier: int = 1
    time_zone: str = "Europe/Berlin"
    value_alignment: ValueAlignment = ValueAlignment.LEFT
    value_availability: ValueAvailability = ValueAvailability.AT_INTERVAL_BEGIN
    default_aggregation: Aggregation | None = None
    start_of_time: str | None = None
    enable_audit: bool = False
    enable_quotation: bool = False
    default_quotation_behavior: QuotationBehavior = QuotationBehavior.LATEST
    allow_specifics_per_instance: bool = False

    def to_inventory_property(self) -> InventoryProperty:
        """Convert to InventoryProperty for GraphQL compatibility."""
        return InventoryProperty(
            property_name=self.property_name,
            data_type=AssignableDataType.TIME_SERIES,
            is_required=self.is_required,
            is_unique=False,  # TimeSeries are never unique
            is_array=False,  # TimeSeries are never arrays
            description=self.description,
            time_series=TimeSeriesPropertyConfig(
                interval=IntervalConfig(
                    time_unit=self.time_unit, multiplier=self.multiplier
                ),
                unit=self.unit,
                value_alignment=self.value_alignment,
                value_availability=self.value_availability,
                time_zone=self.time_zone,
                default_aggregation=self.default_aggregation,
                start_of_time=self.start_of_time,
                enable_audit=self.enable_audit,
                enable_quotation=self.enable_quotation,
                default_quotation_behavior=self.default_quotation_behavior,
                allow_specifics_per_instance=self.allow_specifics_per_instance,
            ),
        )
