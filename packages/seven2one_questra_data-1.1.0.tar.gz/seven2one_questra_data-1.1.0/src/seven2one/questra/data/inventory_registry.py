"""Inventory schema registry with lean GraphQL query and property name resolution.

Replaces: _schema_cache, _load_inventory_schema(), _build_field_name(),
_build_type_name(), _check_inventory_exists() in DynamicInventoryOperations.
"""

from __future__ import annotations

import logging
from collections.abc import Callable
from dataclasses import dataclass
from typing import Any

logger = logging.getLogger(__name__)

# Mapping: dataType Enum → GraphQL Scalar Type (only scalar types)
# TIME_SERIES, NAVIGATION, REFERENCE, etc. are deliberately omitted –
# they have no simple scalar representation and are handled separately.
DATATYPE_TO_GQL: dict[str, str] = {
    "STRING": "String",
    "INT": "Int",
    "LONG": "Long",
    "DECIMAL": "Decimal",
    "DATE_TIME": "DateTime",
    "DATE_TIME_OFFSET": "DateTime",
    "DATE": "Date",
    "TIME": "TimeSpan",
    "BOOLEAN": "Boolean",
    "GUID": "UUID",
    "FILE": "UUID",
    "TIME_SERIES": "Long",  # TimeSeries ID references are Long scalars (require string serialization)
}

# Lean query: only schema-relevant fields (~60 % less payload than get_inventories())
_SCHEMA_QUERY = """
    query GetInventorySchemas(
        $where: _InventoryFilter__InputType
    ) {
        _inventories(where: $where) {
            name
            selectFieldName
            insertFieldName
            updateFieldName
            deleteFieldName
            namespace { name }
            properties {
                name
                fieldName
                dataType
                isRequired
                isArray
            }
        }
    }
"""


def resolve_field_name(user_key: str, schema: InventorySchema) -> str:
    """Resolve user-supplied property name (case-insensitive) to authoritative fieldName.

    Resolution priority:
    1. Exact match on ``fieldName`` (most common case, O(1))
    2. Case-insensitive match on original name  → return ``fieldName``
    3. Case-insensitive match on ``fieldName``  → return ``fieldName``

    Args:
        user_key: Property name as supplied by the caller.
        schema: ``InventorySchema`` containing the lookup tables.

    Returns:
        The authoritative ``fieldName`` for use in GraphQL queries.

    Raises:
        ValueError: If no matching property is found.

    Examples:
        ```python
        fn = resolve_field_name("Name", schema)  # → "name"
        fn = resolve_field_name("name", schema)  # → "name"
        fn = resolve_field_name("NAME", schema)  # → "name"
        fn = resolve_field_name("nAmE", schema)  # → "name"
        ```
    """
    # 1. Exact fieldName match (fast path – properties already resolved)
    if user_key in schema.name_mapping:
        return user_key

    key_lower = user_key.lower()

    # 2. Case-insensitive match on original name (e.g. "Name" → "name")
    if key_lower in schema._reverse_mapping:
        return schema._reverse_mapping[key_lower]

    # 3. Case-insensitive match on fieldName itself
    if key_lower in schema._field_name_lower:
        return schema._field_name_lower[key_lower]

    available = sorted(schema.name_mapping.values())
    raise ValueError(
        f"Property '{user_key}' not found. Available properties: {available}"
    )


@dataclass(frozen=True)
class InventorySchema:
    """Immutable, thread-safe schema snapshot for a single inventory.

    All lookup tables are pre-computed at construction time for O(1) access.

    Attributes:
        select_field_name: GraphQL field name for select queries.
        insert_field_name: GraphQL field name for insert mutations.
        update_field_name: GraphQL field name for update mutations.
        delete_field_name: GraphQL field name for delete mutations.
        type_name: GraphQL type prefix (= ``select_field_name``).
        name_mapping: ``fieldName → original name`` mapping.
        field_types: ``fieldName → GraphQL scalar type`` (scalars only).
        required_fields: Set of required fieldNames.
        array_fields: Set of array fieldNames.
        timeseries_field_names: Set of fieldNames with ``dataType == TIME_SERIES``.
        file_field_names: Set of fieldNames with ``dataType == FILE``.
        all_field_names: All fieldNames as returned by the server (including internal fields).
    """

    # Server-provided GraphQL operation names
    select_field_name: str
    insert_field_name: str
    update_field_name: str
    delete_field_name: str
    type_name: str  # = selectFieldName (type-prefix for InputTypes)

    # Property metadata
    name_mapping: dict[str, str]  # fieldName → original name
    field_types: dict[str, str]  # fieldName → GraphQL type (scalars only)
    required_fields: frozenset[str]  # fieldNames
    array_fields: frozenset[str]  # fieldNames
    timeseries_field_names: frozenset[str]  # fieldNames with dataType == TIME_SERIES
    file_field_names: frozenset[str]  # fieldNames with dataType == FILE
    all_field_names: tuple[str, ...]  # all fieldNames as returned by the server

    # Pre-computed lookup tables (frozen, thread-safe)
    _reverse_mapping: dict[str, str]  # lower(original name) → fieldName
    _field_name_lower: dict[str, str]  # lower(fieldName)      → fieldName


class InventoryRegistry:
    """Central schema cache with lazy loading per inventory.

    Replaces ``_schema_cache``, ``_load_inventory_schema()``,
    ``_build_field_name()``, ``_build_type_name()``,
    ``_check_inventory_exists()`` in ``DynamicInventoryOperations``.

    Args:
        execute_func: GraphQL execute function
            ``(query: str, variables: dict | None) → dict``.

    Examples:
        ```python
        registry = InventoryRegistry(execute_func=transport.execute)

        # Lazy load – fetches schema on first access per inventory
        schema = registry.get("Kunde", namespace_name="ns")

        # Explicit bulk load (e.g. for discovery)
        registry.load_all()

        # Targeted cache invalidation after schema changes
        registry.refresh("Kunde", namespace_name="ns")
        ```
    """

    def __init__(self, execute_func: Callable[..., dict[str, Any]]) -> None:
        self._execute = execute_func
        self._cache: dict[str, InventorySchema] = {}
        self._loaded_all: bool = False

    @staticmethod
    def _cache_key(inventory_name: str, namespace_name: str | None = None) -> str:
        return f"{namespace_name or ''}::{inventory_name}"

    def get(
        self,
        inventory_name: str,
        namespace_name: str | None = None,
    ) -> InventorySchema:
        """Return schema for an inventory (lazy-loaded, cached).

        Args:
            inventory_name: Inventory name.
            namespace_name: Optional namespace qualifier.

        Returns:
            Immutable ``InventorySchema`` for this inventory.

        Raises:
            ValueError: If the inventory does not exist.
        """
        key = self._cache_key(inventory_name, namespace_name)
        if key not in self._cache:
            self._load_single(inventory_name, namespace_name)
        return self._cache[key]

    def load_all(self) -> None:
        """Load all inventories in a single batch query.

        Subsequent calls are no-ops unless ``refresh()`` was called first.
        """
        if self._loaded_all:
            return
        result = self._execute(_SCHEMA_QUERY, {"where": None})
        for inv_data in result["_inventories"]:
            schema = self._build_schema(inv_data)
            ns = inv_data.get("namespace") or {}
            ns_name: str | None = ns.get("name")
            key = self._cache_key(inv_data["name"], ns_name)
            self._cache[key] = schema
        self._loaded_all = True
        logger.info(f"Registry: {len(self._cache)} inventories loaded (bulk)")

    def refresh(
        self,
        inventory_name: str | None = None,
        namespace_name: str | None = None,
    ) -> None:
        """Invalidate cached schema.

        Args:
            inventory_name: If ``None``, clears the entire cache.
            namespace_name: Namespace qualifier when ``inventory_name`` is given.
        """
        if inventory_name is None:
            self._cache.clear()
            self._loaded_all = False
            logger.debug("Registry: full cache cleared")
        else:
            key = self._cache_key(inventory_name, namespace_name)
            self._cache.pop(key, None)
            logger.debug(f"Registry: cache entry '{key}' removed")

    @property
    def cached_keys(self) -> list[str]:
        """Currently cached inventory keys (for debugging)."""
        return list(self._cache.keys())

    def _load_single(self, inventory_name: str, namespace_name: str | None) -> None:
        where: dict[str, Any] = {"inventoryNames": [inventory_name]}
        if namespace_name:
            where["namespaceNames"] = [namespace_name]

        result = self._execute(_SCHEMA_QUERY, {"where": where})
        inventories: list[dict[str, Any]] = result["_inventories"]

        if not inventories:
            ns_part = f" in namespace '{namespace_name}'" if namespace_name else ""
            raise ValueError(f"Inventory '{inventory_name}'{ns_part} does not exist")

        schema = self._build_schema(inventories[0])
        key = self._cache_key(inventory_name, namespace_name)
        self._cache[key] = schema
        logger.debug(
            f"Registry: loaded '{key}' ({len(schema.name_mapping)} properties)"
        )

    @staticmethod
    def _build_schema(inv: dict[str, Any]) -> InventorySchema:
        name_mapping: dict[str, str] = {}
        field_types: dict[str, str] = {}
        required: set[str] = set()
        arrays: set[str] = set()
        timeseries: set[str] = set()
        files: set[str] = set()
        all_fns: list[str] = []

        for prop in inv.get("properties") or []:
            fn: str = prop["fieldName"]
            original: str = prop["name"]
            dt: str = prop["dataType"]

            all_fns.append(fn)
            name_mapping[fn] = original

            gql_type = DATATYPE_TO_GQL.get(dt)
            if gql_type:
                field_types[fn] = gql_type

            if dt == "TIME_SERIES":
                timeseries.add(fn)
            if dt == "FILE":
                files.add(fn)
            if prop.get("isRequired") and not fn.startswith("_"):
                required.add(fn)
            if prop.get("isArray"):
                arrays.add(fn)

        # Pre-compute lookup tables for O(1) case-insensitive access
        reverse = {name.lower(): fn for fn, name in name_mapping.items()}
        fn_lower = {fn.lower(): fn for fn in name_mapping}

        # GraphQL type names must start with uppercase in the inventory segment.
        # selectFieldName uses camelCase; only the last `__`-separated segment
        # (the inventory part) is capitalized. Namespace prefixes stay as-is.
        # e.g. "testNs__testInv" → "testNs__TestInv"
        # e.g. "testInv"         → "TestInv"
        sf = inv["selectFieldName"]
        if "__" in sf:
            prefix, _, last = sf.rpartition("__")
            type_name = f"{prefix}__{last[0].upper() + last[1:]}"
        else:
            type_name = sf[0].upper() + sf[1:]

        return InventorySchema(
            select_field_name=inv["selectFieldName"],
            insert_field_name=inv["insertFieldName"],
            update_field_name=inv["updateFieldName"],
            delete_field_name=inv["deleteFieldName"],
            type_name=type_name,
            name_mapping=name_mapping,
            field_types=field_types,
            required_fields=frozenset(required),
            array_fields=frozenset(arrays),
            timeseries_field_names=frozenset(timeseries),
            file_field_names=frozenset(files),
            all_field_names=tuple(all_fns),
            _reverse_mapping=reverse,
            _field_name_lower=fn_lower,
        )
