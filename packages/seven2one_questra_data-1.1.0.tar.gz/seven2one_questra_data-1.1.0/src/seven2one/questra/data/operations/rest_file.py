"""REST operations for File endpoints."""

from __future__ import annotations

import logging
from collections.abc import Callable, Sequence
from pathlib import Path
from typing import BinaryIO

logger = logging.getLogger(__name__)


class FileOperations:
    """
    REST operations for file endpoints.

    Provides methods for uploading and downloading files.
    """

    def __init__(self, rest_get_func: Callable, rest_post_func: Callable):
        """
        Initialize the file operations.

        Args:
            rest_get_func: Function for GET requests
            rest_post_func: Function for POST requests
        """
        self._get = rest_get_func
        self._post = rest_post_func
        logger.debug("FileOperations initialized")

    def download(self, file_id: int) -> bytes:
        """
        Download a file.

        Args:
            file_id: File ID

        Returns:
            bytes: File content as bytes
        """
        logger.info(f"Downloading file with ID {file_id}")
        result = self._get(f"/file/{file_id}")
        logger.info(f"File downloaded successfully, size: {len(result)} bytes")
        return result

    def upload(
        self,
        files: Sequence[tuple[str, str | Path | BinaryIO, str, str]],
    ) -> list[int]:
        """
        Upload one or more files.

        Args:
            files: List of tuples (name, file_data, filename, content_type)
                - name: Name in format "Namespace__Inventory.Property" or "Inventory.Property"
                - file_data: File path (str/Path) or file object (BinaryIO)
                - filename: Original filename (e.g. 'document.pdf')
                - content_type: MIME type (e.g. 'application/pdf')

        Returns:
            list[int]: List of file IDs

        Example:
            Upload with file path:

            ```python
            file_ids = client.files.upload(
                [
                    (
                        "MyNamespace__MyInventory.DocumentProperty",
                        "/path/to/file.pdf",
                        "file.pdf",
                        "application/pdf",
                    )
                ]
            )
            ```

        Example:
            Upload with file object:

            ```python
            with open("file.pdf", "rb") as f:
                file_ids = client.files.upload(
                    [("MyInventory.DocumentProperty", f, "file.pdf", "application/pdf")]
                )
            ```
        """
        logger.info(f"Uploading {len(files)} file(s)")

        files_list: list[tuple[str, tuple[str, BinaryIO, str]]] = []
        opened_files = []

        try:
            for name, file_data, filename, content_type in files:
                # If file_data is a path, open the file
                if isinstance(file_data, (str, Path)):
                    file_obj = open(file_data, "rb")
                    opened_files.append(file_obj)
                else:
                    file_obj = file_data

                # Format: (filename, file_object, content_type)
                files_list.append((name, (filename, file_obj, content_type)))

            # POST with multipart/form-data
            result = self._post("/file/upload", files=files_list)

            # API returns a list of string IDs
            file_ids = [int(file_id) for file_id in result]

            logger.info(f"Successfully uploaded {len(file_ids)} file(s)")
            return file_ids

        finally:
            # Close all opened files
            for file_obj in opened_files:
                try:
                    file_obj.close()
                except Exception as e:
                    logger.warning(f"Failed to close file: {e}")

    def upload_single(
        self,
        name: str,
        file_data: str | Path | BinaryIO,
        filename: str,
        content_type: str,
    ) -> int:
        """
        Uploads a single file (convenience method).

        Args:
            name: Name in format "Namespace__Inventory.Property" or "Inventory.Property"
            file_data: File path (str/Path) or file object (BinaryIO)
            filename: Original filename (e.g. 'document.pdf')
            content_type: MIME type (e.g. 'application/pdf')

        Returns:
            int: File ID

        Example:
            ```python
            file_id = client.files.upload_single(
                name="MyNamespace__MyInventory.DocumentProperty",
                file_data="/path/to/file.pdf",
                filename="file.pdf",
                content_type="application/pdf",
            )
            ```
        """
        result = self.upload([(name, file_data, filename, content_type)])
        return result[0]
