"""
QuestraData client for Questra Data.

Provides a simplified interface for common operations,
without the user needing to know the internal details (GraphQL vs REST).
"""

from __future__ import annotations

import logging
from collections.abc import Mapping
from datetime import datetime
from typing import TYPE_CHECKING, Any

logger = logging.getLogger(__name__)
from seven2one.questra.authentication import QuestraAuthentication

from .inventory_registry import InventorySchema, resolve_field_name
from .managers import CatalogManager
from .models import (
    Aggregation,
    BackgroundJobResult,
    ConflictAction,
    Inventory,
    NamedItemResult,
    Namespace,
    Quality,
    QuotationBehavior,
    Role,
    SystemInfo,
    TimeUnit,
    TimeZone,
    Unit,
)
from .models.inputs import (
    BoolProperty,
    DateProperty,
    DateTimeOffsetProperty,
    DateTimeProperty,
    DecimalProperty,
    FileProperty,
    GuidProperty,
    IntProperty,
    InventoryProperty,
    InventoryRelation,
    LongProperty,
    StringProperty,
    TimeProperty,
    TimeSeriesProperty,
)
from .models.rest import SetTimeSeriesDataInput, TimeSeriesValue
from .raw_client import _QuestraDataCore
from .results import QueryResult, TimeSeriesResult, _CaseInsensitiveDict

# Optional pandas Integration
if TYPE_CHECKING:
    import pandas as pd

try:
    import pandas as pd

    _PANDAS_AVAILABLE = True
except ImportError:
    _PANDAS_AVAILABLE = False


class QuestraData:
    """Data client for Questra Data.

    Provides a simplified, type-safe interface for interacting with the Questra
    Data service without requiring knowledge of the underlying GraphQL or REST
    implementation details. For advanced use cases, raw API access is available
    via the [`raw`][seven2one.questra.data.QuestraData.raw] property.

    Args:
        graphql_url: GraphQL endpoint URL
        auth_client: Authenticated QuestraAuthentication instance
        rest_base_url: REST API base URL (auto-derived if not provided)

    Example:
        ```python
        from seven2one.questra.authentication import QuestraAuthentication
        from seven2one.questra.data import QuestraData

        auth = QuestraAuthentication(...)
        client = QuestraData(
            graphql_url="https://example.com/data/graphql", auth_client=auth
        )
        ```
    """

    def __init__(
        self,
        graphql_url: str,
        auth_client: QuestraAuthentication,
        rest_base_url: str | None = None,
    ):
        logger.info(f"Initializing QuestraData. graphql_url={graphql_url}")

        # Create _QuestraDataCore client (advanced operations)
        self._client = _QuestraDataCore(
            graphql_url=graphql_url,
            auth_client=auth_client,
            rest_base_url=rest_base_url,
        )

        # Initialize internal managers (for code organization)
        self._catalog_manager = CatalogManager(self._client)
        self._registry = self._client.inventory._registry

        logger.info("QuestraData initialized successfully")

    def _normalize_properties(
        self,
        properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ],
    ) -> list[InventoryProperty]:
        normalized: list[InventoryProperty] = []
        for prop in properties:
            if isinstance(prop, InventoryProperty):
                normalized.append(prop)
            else:
                # Specialized property classes all have to_inventory_property()
                normalized.append(prop.to_inventory_property())  # type: ignore[union-attr]
        return normalized

    @staticmethod
    def _remap_response(
        items: list[dict[str, Any]],
        name_mapping: dict[str, str],
    ) -> list[dict[str, Any]]:
        """Replace fieldName keys in response items with original property names.

        Recursively remaps nested dicts (e.g. TimeSeries sub-objects).
        System fields (``_id``, ``_rowVersion``) are not in ``name_mapping``
        and pass through unchanged.

        Args:
            items: GraphQL response items with fieldName keys.
            name_mapping: ``fieldName \u2192 original name`` mapping from schema.

        Returns:
            Items with original property names as keys.
        """

        def remap(item: dict[str, Any]) -> dict[str, Any]:
            return {
                name_mapping.get(k, k): (
                    remap(v)
                    if isinstance(v, dict)
                    else [remap(x) if isinstance(x, dict) else x for x in v]
                    if isinstance(v, list)
                    else v
                )
                for k, v in item.items()
            }

        return [remap(item) for item in items]

    def _get_nested_schema(
        self,
        inventory_name_for_schema: str,
        namespace_name: str | None,
    ) -> InventorySchema | None:
        """Get nested inventory schema with case-insensitive inventory fallback."""
        try:
            return self._registry.get(inventory_name_for_schema, namespace_name)
        except ValueError:
            pass

        # Fall back to case-insensitive inventory name lookup in the same namespace.
        self._registry.load_all()
        candidate = inventory_name_for_schema.lower()
        ns_key = namespace_name or ""
        for cache_key in self._registry.cached_keys:
            key_ns, _, key_inventory = cache_key.partition("::")
            if key_ns == ns_key and key_inventory.lower() == candidate:
                return self._registry.get(key_inventory, namespace_name)
        return None

    def _resolve_property_segments(
        self,
        segments: list[str],
        current_schema: InventorySchema,
        namespace_name: str | None,
    ) -> str:
        """Resolve each path segment to authoritative fieldNames."""
        resolved_field = resolve_field_name(segments[0], current_schema)
        if len(segments) == 1:
            return resolved_field

        # Scalar/Timeseries fields do not provide nested schema metadata.
        # Keep trailing segments as provided (e.g. "messwerte_temperatur.id").
        if resolved_field in current_schema.field_types:
            return f"{resolved_field}.{'.'.join(segments[1:])}"

        next_inventory_name = current_schema.name_mapping.get(
            resolved_field, resolved_field
        )
        nested_schema = self._get_nested_schema(next_inventory_name, namespace_name)
        if nested_schema is None:
            return f"{resolved_field}.{'.'.join(segments[1:])}"

        return (
            f"{resolved_field}."
            f"{self._resolve_property_segments(segments[1:], nested_schema, namespace_name)}"
        )

    def _canonicalize_property_segments(
        self,
        segments: list[str],
        current_schema: InventorySchema,
        namespace_name: str | None,
    ) -> str:
        """Canonicalize each path segment to schema property names."""
        resolved_field = resolve_field_name(segments[0], current_schema)
        canonical_name = current_schema.name_mapping.get(resolved_field, resolved_field)
        if len(segments) == 1:
            return canonical_name

        # Scalar/Timeseries fields do not provide nested schema metadata.
        # Keep trailing segments as provided for header readability.
        if resolved_field in current_schema.field_types:
            return f"{canonical_name}.{'.'.join(segments[1:])}"

        nested_schema = self._get_nested_schema(canonical_name, namespace_name)
        if nested_schema is None:
            return f"{canonical_name}.{'.'.join(segments[1:])}"

        return (
            f"{canonical_name}."
            f"{self._canonicalize_property_segments(segments[1:], nested_schema, namespace_name)}"
        )

    def _map_property_path(
        self,
        property_path: str,
        schema: InventorySchema,
        namespace_name: str | None,
    ) -> tuple[str, str]:
        """Map user property path to query field path and canonical path."""
        segments = property_path.split(".")
        query_path = self._resolve_property_segments(segments, schema, namespace_name)
        canonical_path = self._canonicalize_property_segments(
            segments, schema, namespace_name
        )
        return query_path, canonical_path

    def _validate_and_resolve_properties(
        self,
        properties: list[str],
        schema: InventorySchema,
        inventory_name: str,
        namespace_name: str | None = None,
    ) -> tuple[list[str], InventorySchema]:
        """Resolve user-supplied property names to fieldNames, with auto-refresh.

        Dot-notation properties have all segments resolved recursively via
        sub-inventory schemas from the registry (if available).

        Args:
            properties: User-supplied property names (may use original names).
            schema: Current inventory schema.
            inventory_name: Inventory name (for cache refresh if needed).
            namespace_name: Optional namespace qualifier.

        Returns:
            Tuple of ``(resolved_field_names, schema)`` where schema may be
            refreshed if the first resolution attempt failed.

        Raises:
            ValueError: If a property cannot be resolved even after schema refresh.
        """

        def _resolve_segments(segments: list[str], s: InventorySchema) -> str:
            return self._resolve_property_segments(segments, s, namespace_name)

        def _resolve_list(props: list[str], s: InventorySchema) -> list[str]:
            return [_resolve_segments(prop.split("."), s) for prop in props]

        try:
            return _resolve_list(properties, schema), schema
        except ValueError:
            # Schema might be stale \u2013 refresh and retry once
            self._registry.refresh(inventory_name, namespace_name)
            schema = self._registry.get(inventory_name, namespace_name)

        # Second attempt with refreshed schema \u2013 ValueError propagates cleanly (no chaining)
        return _resolve_list(properties, schema), schema

    def _auto_create_timeseries(
        self,
        items: list[dict[str, Any]],
        schema: InventorySchema,
        inventory_name: str,
        namespace_name: str | None,
    ) -> None:
        """Auto-create TimeSeries objects for TIME_SERIES properties with None values.

        Mutates *items* in-place, replacing ``None`` values with the newly
        created TimeSeries IDs and integer string/int values with ``int(id)``.

        Args:
            items: Items list to mutate.
            schema: Inventory schema (provides ``timeseries_field_names``).
            inventory_name: Inventory name for TimeSeries creation.
            namespace_name: Optional namespace qualifier.

        Raises:
            ValueError: For invalid TimeSeries property values.
        """
        from .models.inputs import CreateTimeSeriesInput

        timeseries_to_create: list[CreateTimeSeriesInput] = []
        timeseries_mapping: dict[tuple[int, str], int] = {}

        for item_idx, item in enumerate(items):
            for item_key in list(item.keys()):
                if item_key.startswith("_"):
                    continue
                try:
                    fn = resolve_field_name(item_key, schema)
                except ValueError:
                    continue
                if fn not in schema.timeseries_field_names:
                    continue

                item_value = item[item_key]
                original_name = schema.name_mapping.get(fn, fn)

                if item_value is None:
                    ts_input = CreateTimeSeriesInput(
                        inventory_name=inventory_name,
                        property_name=original_name,
                        namespace_name=namespace_name,
                    )
                    timeseries_mapping[(item_idx, item_key)] = len(timeseries_to_create)
                    timeseries_to_create.append(ts_input)
                elif isinstance(item_value, (str, int)):
                    items[item_idx][item_key] = int(item_value)
                    logger.debug(
                        f"Using existing TimeSeries ID {item_value} for "
                        f"item {item_idx}, property {item_key}"
                    )
                else:
                    raise ValueError(
                        f"Invalid TimeSeries value for item {item_idx}, "
                        f"property {item_key}: {item_value!r}. "
                        f"Expected None (auto-create) or string/int (existing ID)."
                    )

        if timeseries_to_create:
            logger.info(f"Creating {len(timeseries_to_create)} TimeSeries via GraphQL")
            ts_results = self._client.mutations.create_timeseries(timeseries_to_create)
            for (item_idx, prop_key), ts_idx in timeseries_mapping.items():
                ts_id = int(ts_results[ts_idx].id)
                items[item_idx][prop_key] = ts_id
                logger.debug(
                    f"Assigned TimeSeries ID {ts_id} to item {item_idx}, "
                    f"property {prop_key}"
                )

    def _auto_upload_files(
        self,
        items: list[dict[str, Any]],
        schema: InventorySchema,
        inventory_name: str,
        namespace_name: str | None,
    ) -> None:
        """Upload files for FILE properties containing a ``FileUpload`` value.

        Mutates *items* in-place. ``FileUpload`` → replaced with ``int`` file ID.
        ``int`` values (existing IDs) are left unchanged.

        Args:
            items: Items list to mutate.
            schema: Inventory schema (provides ``file_field_names``).
            inventory_name: Inventory name for upload name construction.
            namespace_name: Optional namespace qualifier.

        Raises:
            ValueError: If a FILE property value is neither ``FileUpload`` nor ``int``.
        """
        from pathlib import Path
        from typing import BinaryIO

        from .models.file_upload import FileUpload

        uploads: list[tuple[int, str, FileUpload]] = []

        for item_idx, item in enumerate(items):
            for item_key in list(item.keys()):
                if item_key.startswith("_"):
                    continue
                try:
                    fn = resolve_field_name(item_key, schema)
                except ValueError:
                    continue
                if fn not in schema.file_field_names:
                    continue

                item_value = item[item_key]
                if isinstance(item_value, FileUpload):
                    uploads.append((item_idx, item_key, item_value))
                elif isinstance(item_value, int):
                    logger.debug(
                        f"Using existing file ID {item_value} for item {item_idx}, "
                        f"property {item_key}"
                    )
                elif item_value is None:
                    raise ValueError(
                        f"FILE property '{item_key}' in item {item_idx} is None. "
                        f"Use FileUpload(...) or pass an existing file ID as int."
                    )
                else:
                    raise ValueError(
                        f"Invalid FILE property value for item {item_idx}, "
                        f"property '{item_key}': {item_value!r}. "
                        f"Expected FileUpload(...) or int."
                    )

        if not uploads:
            return

        files_list: list[tuple[str, str | Path | BinaryIO, str, str]] = []
        for _, item_key, fu in uploads:
            fn = resolve_field_name(item_key, schema)
            original_name = schema.name_mapping.get(fn, fn)
            upload_name = (
                f"{namespace_name}__{inventory_name}.{original_name}"
                if namespace_name
                else f"{inventory_name}.{original_name}"
            )
            files_list.append(
                (
                    upload_name,
                    fu.file_data,
                    fu.resolve_filename(),
                    fu.resolve_content_type(),
                )
            )

        logger.info(
            f"Uploading {len(files_list)} file(s) for inventory '{inventory_name}'"
        )
        file_ids = self._client.files.upload(files_list)

        for (item_idx, item_key, _), file_id in zip(uploads, file_ids):
            items[item_idx][item_key] = file_id
            logger.debug(
                f"Assigned file ID {file_id} to item {item_idx}, property '{item_key}'"
            )

    # ===== Time Series Operations =====

    def list_timeseries_values(
        self,
        inventory_name: str,
        timeseries_properties: str | list[str],
        from_time: datetime,
        to_time: datetime,
        namespace_name: str | None = None,
        properties: list[str] | None = None,
        where: dict[str, Any] | None = None,
        aggregation: Aggregation | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int | None = None,
        exclude_qualities: list[Quality] | None = None,
        time_zone: str | None = None,
    ) -> TimeSeriesResult:
        """Retrieve time series values for inventory items, with optional item filtering and value aggregation.

        Args:
            inventory_name: Name of inventory
            timeseries_properties: Property name(s) containing time series
            from_time: Start timestamp
            to_time: End timestamp
            namespace_name: Optional namespace filter
            properties: Additional item properties to include
            where: GraphQL filter conditions for inventory items. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            aggregation: Optional data aggregation
            time_unit: Time interval unit for aggregation
            multiplier: Multiplier for time_unit
            exclude_qualities: Quality flags to exclude
            time_zone: Timezone for timestamps

        Returns:
            TimeSeriesResult with item and time series data

        Example:
            ```python
            from datetime import datetime, timedelta

            # Get time series values for all items
            end = datetime.now()
            start = end - timedelta(days=7)
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
            )

            # Filter by sensor status
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
                where={"status": {"eq": "active"}},
            )

            # Filter by location pattern
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties=["temperature", "humidity"],
                from_time=start,
                to_time=end,
                where={"location": {"startsWith": "building-A"}},
                properties=["name", "location"],
            )

            # Complex filter with multiple conditions
            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
                where={
                    "and": [{"type": {"eq": "indoor"}}, {"floor": {"gte": 1, "lte": 3}}]
                },
            )

            # With aggregation
            from seven2one.questra.data import Aggregation, TimeUnit

            result = client.list_timeseries_values(
                inventory_name="Sensors",
                timeseries_properties="temperature",
                from_time=start,
                to_time=end,
                where={"location": {"contains": "room"}},
                aggregation=Aggregation.AVERAGE,
                time_unit=TimeUnit.HOUR,
                multiplier=1,
            )
            ```
        """
        ts_properties = (
            [timeseries_properties]
            if isinstance(timeseries_properties, str)
            else timeseries_properties
        )

        logger.info(
            f"Listing timeseries values from inventory. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_properties={ts_properties}, properties={properties}"
        )

        # Step 1: Lade Inventory Items with Timeseries properties and normal properties
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_names = {tp: resolve_field_name(tp, schema) for tp in ts_properties}
        ts_fields = set(ts_field_names.values())
        query_properties = ["_id", "_rowVersion"]

        # Collect Timeseries subfields (z.B. "messwerte_temperatur.timeZone")
        ts_subfields = {ts_field: set() for ts_field in ts_fields}

        # Collect requested properties for DataFrame output and timeseries subfields for query
        item_properties: list[str] = []
        if properties:
            for prop in properties:
                query_prop, canonical_prop = self._map_property_path(
                    prop, schema, namespace_name
                )

                # Check whether it is a nested Timeseries Property
                is_ts_subfield = False
                if "." in prop:
                    root_prop, subfield = prop.split(".", 1)
                    try:
                        resolved_root = resolve_field_name(root_prop, schema)
                    except ValueError:
                        resolved_root = None

                    if resolved_root in ts_subfields:
                        ts_subfields[resolved_root].add(subfield)
                        item_properties.append(canonical_prop)
                        is_ts_subfield = True

                if not is_ts_subfield:
                    # _id is always the DataFrame column key – skip to avoid duplicate level
                    if query_prop.lower() == "_id":
                        continue
                    query_properties.append(query_prop)
                    item_properties.append(canonical_prop)

        # Add Timeseries Properties with ihren Subfeldern hinzu
        for fn in ts_fields:
            # Always query .id (for time series data)
            ts_subfields[fn].add("id")

            # Add all subfields as nested Properties hinzu
            for subfield in ts_subfields[fn]:
                query_properties.append(f"{fn}.{subfield}")

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=query_properties,
            where=where,
            first=1000,  # TODO: Implement pagination if more items
        )

        items = result.get("nodes", [])
        logger.debug(f"Found {len(items)} items with TimeSeries properties")

        if not items:
            logger.warning(f"No items found in {inventory_name}")
            return TimeSeriesResult({}, self, properties=item_properties or None)

        # Step 2: Extrahiere Timeseries IDs and create Mapping
        # Format: ts_id -> (item_id, property_name)
        ts_to_item_mapping = {}
        timeseries_ids = []

        for item in items:
            item_id = item["_id"]
            for field in ts_properties:
                normalized_field = ts_field_names[field]
                ts_data = item.get(normalized_field)
                if ts_data and isinstance(ts_data, dict) and "id" in ts_data:
                    # GraphQL returns IDs as strings, REST API uses integers
                    # Convert to int for consistent mapping
                    ts_id = int(ts_data["id"])
                    ts_to_item_mapping[ts_id] = {
                        "item_id": item_id,
                        "property_name": schema.name_mapping.get(
                            normalized_field, normalized_field
                        ),
                    }
                    timeseries_ids.append(ts_id)

        if not timeseries_ids:
            logger.warning("No TimeSeries IDs found in items")
            return TimeSeriesResult({}, self, properties=item_properties or None)

        logger.debug(f"Extracted {len(timeseries_ids)} TimeSeries IDs")

        # Step 3: Lade time series values
        # Default: only exclude MISSING
        if exclude_qualities is None:
            exclude_qualities = [Quality.MISSING]

        ts_result = self._client.timeseries.get_data(
            time_series_ids=timeseries_ids,
            from_time=from_time,
            to_time=to_time,
            time_unit=time_unit,
            multiplier=multiplier if time_unit else None,
            aggregation=aggregation,
            time_zone=time_zone,
            exclude_qualities=exclude_qualities,
        )

        # Step 4: Combine Results
        # Uniform structure: ALWAYS with "timeseries" dict
        # Rename item keys from GraphQL fieldName → canonical name (from inventory registry)
        item_index = {
            item["_id"]: _CaseInsensitiveDict(
                {schema.name_mapping.get(k, k): v for k, v in item.items()}
            )
            for item in items
        }
        result_dict: dict[str, _CaseInsensitiveDict] = {}

        for ts_data in ts_result.data:
            ts_id = ts_data.time_series_id
            if ts_id not in ts_to_item_mapping:
                continue

            mapping = ts_to_item_mapping[ts_id]
            item_id = mapping["item_id"]
            property_name = mapping["property_name"]

            # Initialize item entry if needed
            if item_id not in result_dict:
                result_dict[item_id] = _CaseInsensitiveDict(
                    {
                        "item": item_index[item_id],
                        "timeseries": {},
                    }
                )

            # Store TimeSeries data ALWAYS under timeseries[property_name]
            result_dict[item_id]["timeseries"][property_name] = {
                "timeseries_id": ts_id,
                "values": ts_data.values,
                "unit": ts_data.unit,
                "interval": ts_data.interval,
                "time_zone": ts_data.time_zone,
            }

        logger.info(f"Listed timeseries values for {len(result_dict)} items")
        return TimeSeriesResult(result_dict, self, properties=item_properties or None)

    def _convert_timeseries_to_dataframe(
        self,
        result: Mapping[str, dict],
        properties: list[str] | None = None,
    ) -> pd.DataFrame:
        if not _PANDAS_AVAILABLE:
            raise ImportError("pandas is required for DataFrame conversion")

        # Collect all data and item information
        # {(property, unit, item_id): {time: value}}
        data_dict = {}
        # {item_id: {property_name: field_value}}
        item_properties_dict = {}

        def get_nested_value(d: dict, path: str):
            """Extract value from nested dict using dot notation."""
            keys = path.split(".")
            value = d
            for key in keys:
                if isinstance(value, dict):
                    value = value.get(key)
                else:
                    return None
            return value

        for item_id, data in result.items():
            # Collect normal properties for this item
            if properties:
                item_properties_dict[item_id] = {}
                for field in properties:
                    # Support nested properties (e.g. "messwerte_temperatur.timeZone")
                    item_properties_dict[item_id][field] = get_nested_value(
                        data["item"], field
                    )

            # Unitliche Struktur: IMMER data["timeseries"]
            for property_name, ts_data in data["timeseries"].items():
                values = ts_data["values"]
                unit = ts_data.get("unit") or ""

                key = (property_name, unit, item_id)
                data_dict[key] = {
                    ts_value.time: float(ts_value.value) for ts_value in values
                }

        if not data_dict:
            # Leerer DataFrame
            return pd.DataFrame()  # type: ignore

        # Create DataFrame from dict
        # Collect columns as List of Tuples (property_name, unit, item_id)
        columns_list = []
        series_list = []

        for (property_name, unit, item_id), time_values in data_dict.items():
            columns_list.append((property_name, unit, item_id))
            series_list.append(pd.Series(time_values))  # type: ignore

        if not columns_list:
            return pd.DataFrame()  # type: ignore

        # Create DataFrame with MultiIndex columns
        df = pd.DataFrame(dict(enumerate(series_list)))  # type: ignore
        df.index.name = "time"
        df = df.sort_index()

        # Check ob all Units per Timeseries-Field gleich sind
        # If yes, we can simplify the unit level
        field_units = {}
        for ts_field, unit, item in columns_list:
            if ts_field not in field_units:
                field_units[ts_field] = set()
            field_units[ts_field].add(unit)

        # If all TimeSeries properties have only a single unit, simplify
        all_single_unit = all(len(units) == 1 for units in field_units.values())

        # Create MultiIndex with normalen properties as Spalten-Ebenen
        if properties and item_properties_dict:
            # Extend columns_list with field values
            # Struktur: (ts_field, unit, field1_value, field2_value, ..., item_id)
            extended_columns = []
            for ts_field, unit, item_id in columns_list:
                # Get field values for this Item
                field_values = []
                if item_id in item_properties_dict:
                    for field in properties:
                        field_values.append(item_properties_dict[item_id].get(field))
                else:
                    field_values = [None] * len(properties)

                # Baue Spalten-Tuple
                if all_single_unit:
                    # (ts_field [unit], field1, field2, ..., item_id)
                    ts_field_with_unit = f"{ts_field} [{unit}]" if unit else ts_field
                    extended_columns.append(
                        (ts_field_with_unit, *field_values, item_id)
                    )
                else:
                    # (ts_field, unit, field1, field2, ..., item_id)
                    extended_columns.append((ts_field, unit, *field_values, item_id))

            # Create names for the MultiIndex-Ebenen
            if all_single_unit:
                column_names = ["Timeseries-Field [Unit]"] + properties + ["_Id"]
            else:
                column_names = ["Timeseries-Field", "Unit"] + properties + ["_Id"]

            df.columns = pd.MultiIndex.from_tuples(  # type: ignore
                extended_columns, names=column_names
            )
        else:
            # No normalen properties: like vorher
            if all_single_unit:
                # Vereinfachter MultiIndex: Timeseries-Field and Item-ID
                # Unit is combined with field in the first level
                simplified_columns = []
                for ts_field, unit, item in columns_list:
                    ts_field_with_unit = f"{ts_field} [{unit}]" if unit else ts_field
                    simplified_columns.append((ts_field_with_unit, item))

                df.columns = pd.MultiIndex.from_tuples(  # type: ignore
                    simplified_columns, names=["Timeseries-Field [Unit]", "_Id"]
                )
            else:
                # Voller MultiIndex: Timeseries-Field, Unit, Item-ID
                df.columns = pd.MultiIndex.from_tuples(  # type: ignore
                    columns_list, names=["Timeseries-Field", "Unit", "_Id"]
                )

        return df

    def save_timeseries_values(
        self,
        inventory_name: str,
        timeseries_property: str,
        item_id: str,
        values: list[TimeSeriesValue],
        namespace_name: str | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int = 1,
        unit: str | None = None,
        time_zone: str | None = None,
    ) -> None:
        """Save time series values for a single inventory item.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            item_id: Item ID
            values: Time series values to save
            namespace_name: Optional namespace
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            unit: Measurement unit
            time_zone: Timezone for values
        """
        logger.info(
            f"Saving timeseries values for single item. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, item_id={item_id}, value_count={len(values)}"
        )

        # Delegiere to Bulk-Methode
        self.save_timeseries_values_bulk(
            inventory_name=inventory_name,
            timeseries_properties=timeseries_property,
            item_values={item_id: values},
            namespace_name=namespace_name,
            time_unit=time_unit,
            multiplier=multiplier,
            unit=unit,
            time_zone=time_zone,
        )

    def save_timeseries_values_bulk(
        self,
        inventory_name: str,
        timeseries_properties: str | list[str],
        item_values: dict[str, list[TimeSeriesValue]]
        | dict[str, dict[str, list[TimeSeriesValue]]],
        namespace_name: str | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int = 1,
        unit: str | None = None,
        time_zone: str | None = None,
    ) -> None:
        """Save time series values for multiple inventory items in a single batch operation.

        Args:
            inventory_name: Name of inventory
            timeseries_properties: Property name(s) containing time series
            item_values: Dict mapping item IDs to values (list or dict)
            namespace_name: Optional namespace
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            unit: Measurement unit
            time_zone: Timezone for values
        """
        ts_properties = (
            [timeseries_properties]
            if isinstance(timeseries_properties, str)
            else timeseries_properties
        )

        logger.info(
            f"Saving timeseries values for inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(item_values)}, timeseries_properties={ts_properties}"
        )

        if not item_values:
            logger.warning("No item values provided")
            return

        # Step 1: Lade Inventory Items with Timeseries properties
        # Note: _id verwendet lowercase Filter (eq, in) statt _eq, _in
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_names = {tp: resolve_field_name(tp, schema) for tp in ts_properties}
        item_ids = list(item_values.keys())
        where = {"_id": {"in": item_ids}}

        # Create properties list with all Timeseries-properties
        properties = ["_id"]
        for field in ts_properties:
            fn = ts_field_names[field]
            properties.append(f"{fn}.id")

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=properties,
            where=where,
            first=len(item_ids),
        )

        items = result.get("nodes", [])
        logger.debug(f"Found {len(items)} items")

        # Step 2: Erstelle SetTimeSeriesDataInput for all Timeseries-properties
        from .models import Interval

        data_inputs = []

        # Check whether we are with multiple Timeseries-properties arbeiten
        is_multi_field = len(ts_properties) > 1

        for item in items:
            item_id = item["_id"]
            item_value_data = item_values.get(item_id)

            if not item_value_data:
                continue

            # Verarbeite jedes Timeseries-Field
            for field in ts_properties:
                normalized_field = ts_field_names[field]
                ts_data = item.get(normalized_field)

                if not ts_data or not isinstance(ts_data, dict) or "id" not in ts_data:
                    logger.warning(
                        f"Item {item_id} has no valid TimeSeries field '{field}' "
                        f"(field: '{normalized_field}')"
                    )
                    continue

                # GraphQL returns IDs as strings, REST API uses integers
                ts_id = int(ts_data["id"])

                # Get Werte basierend auf Modus (single vs. multi field)
                if is_multi_field:
                    # Multi-Field-Modus: item_value_data ist Dict[str, list[TimeSeriesValue]]
                    if not isinstance(item_value_data, dict):
                        expected_fields = ", ".join(
                            f'"{p}": [...]' for p in ts_properties
                        )
                        raise ValueError(
                            f"Item {item_id}: Multi-field mode requires dict structure.\n"
                            f"Expected: {{{expected_fields}}}\n"
                            f"Got {type(item_value_data).__name__}: {item_value_data!r}"
                        )
                    values = item_value_data.get(field, [])
                else:
                    # Single-Field-Modus: item_value_data ist list[TimeSeriesValue]
                    if isinstance(item_value_data, dict):
                        hint_props = ", ".join(f'"{k}"' for k in item_value_data.keys())
                        raise ValueError(
                            f"Item {item_id}: Single-field mode requires list structure.\n"
                            f"Expected: [TimeSeriesValue(...), ...]\n"
                            f"Got dict with keys: {list(item_value_data.keys())}\n"
                            f"Hint: For multiple properties, pass them as list: "
                            f"timeseries_properties=[{hint_props}]"
                        )
                    values = item_value_data

                if values:
                    data_input = SetTimeSeriesDataInput(
                        time_series_id=ts_id,
                        values=values,
                        interval=Interval(time_unit=time_unit, multiplier=multiplier)
                        if time_unit
                        else None,
                        unit=unit,
                        time_zone=time_zone,
                        quotation_time=None,
                    )
                    data_inputs.append(data_input)

        # Step 3: Speichere values via REST API
        if data_inputs:
            self._client.timeseries.set_data(data_inputs)
            total_values = sum(len(di.values) for di in data_inputs)
            logger.info(
                f"Saved {total_values} values for {len(data_inputs)} TimeSeries"
            )
        else:
            logger.warning("No valid data inputs created")

    # ===== Quotation Operations =====

    def list_quotation_timestamps(
        self,
        inventory_name: str,
        timeseries_property: str,
        from_time: datetime,
        to_time: datetime,
        namespace_name: str | None = None,
        where: dict[str, Any] | None = None,
        aggregated: bool = False,
    ) -> dict[str, list[datetime]] | list[datetime]:
        """List the quotation timestamps available for a time series property within a given time range.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            from_time: Start timestamp
            to_time: End timestamp
            namespace_name: Optional namespace
            where: GraphQL filter conditions for inventory items. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            aggregated: If True, return unique timestamps across all items

        Returns:
            Dict mapping item IDs to timestamps, or list of unique timestamps if aggregated

        Example:
            ```python
            from datetime import datetime, timedelta

            # List all available quotation timestamps
            end = datetime.now()
            start = end - timedelta(days=30)
            timestamps = client.list_quotation_timestamps(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
            )
            # Returns: {"item_id_1": [datetime1, datetime2], "item_id_2": [...]}

            # Get aggregated timestamps across all items
            all_timestamps = client.list_quotation_timestamps(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                aggregated=True,
            )
            # Returns: [datetime1, datetime2, datetime3, ...]

            # Filter by product category
            timestamps = client.list_quotation_timestamps(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"category": {"eq": "electronics"}},
            )

            # Filter by multiple categories
            timestamps = client.list_quotation_timestamps(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"category": {"in": ["electronics", "appliances"]}},
            )

            # Complex filter
            timestamps = client.list_quotation_timestamps(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={
                    "and": [
                        {"category": {"eq": "electronics"}},
                        {"brand": {"startsWith": "Premium"}},
                    ]
                },
                aggregated=True,
            )
            ```
        """
        logger.info(
            f"Listing quotation timestamps. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, aggregated={aggregated}"
        )

        # Step 1: Lade Inventory Items with Timeseries Property
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_name = resolve_field_name(timeseries_property, schema)
        properties = ["_id", f"{ts_field_name}.id"]

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=properties,
            where=where,
            first=1000,  # TODO: Implement pagination if more items
        )

        items = result.get("nodes", [])
        logger.debug(f"Found {len(items)} items with TimeSeries property")

        if not items:
            logger.warning(f"No items found in {inventory_name}")
            return [] if aggregated else {}

        # Step 2: Extrahiere Timeseries IDs
        timeseries_ids = []
        ts_to_item_mapping = {}

        normalized_field = ts_field_name

        for item in items:
            item_id = item["_id"]
            ts_data = item.get(normalized_field)
            if ts_data and isinstance(ts_data, dict) and "id" in ts_data:
                # GraphQL returns IDs as strings, REST API uses integers
                # Convert to int for consistent mapping
                ts_id = int(ts_data["id"])
                timeseries_ids.append(ts_id)
                ts_to_item_mapping[ts_id] = item_id

        if not timeseries_ids:
            logger.warning("No TimeSeries IDs found in items")
            return [] if aggregated else {}

        logger.debug(f"Extracted {len(timeseries_ids)} TimeSeries IDs")

        # Step 3: Lade quotations
        try:
            quotations_result = self._client.timeseries.get_quotations(
                time_series_ids=timeseries_ids,
                from_time=from_time,
                to_time=to_time,
                aggregated=aggregated,
            )
        except Exception as e:
            # REST API kann Fehler zurückgeben, wenn z.B. keine Quotations vorhanden sind
            logger.warning(f"Failed to get quotations: {e}. Returning empty result.")
            return [] if aggregated else {}

        # Step 4: Verarbeite Ergebnisse
        if aggregated:
            # Aggregated: Sammle all unique quotation timestamps
            all_timestamps = set()
            for quotations in quotations_result.items:
                if quotations.values:
                    for quot_value in quotations.values:
                        all_timestamps.add(quot_value.time)

            result_list = sorted(list(all_timestamps))
            logger.info(
                f"Found {len(result_list)} unique quotation timestamps (aggregated)"
            )
            return result_list
        else:
            # Pro Item: Mapping Item-ID -> Notierungs-Zeitstempel
            item_quotations = {}
            for quotations in quotations_result.items:
                ts_id = quotations.time_series_id
                if ts_id in ts_to_item_mapping and quotations.values:
                    item_id = ts_to_item_mapping[ts_id]
                    timestamps = [quot_value.time for quot_value in quotations.values]
                    item_quotations[item_id] = sorted(timestamps)

            logger.info(f"Found quotations for {len(item_quotations)} items")
            return item_quotations

    def list_quotation_values(
        self,
        inventory_name: str,
        timeseries_property: str,
        from_time: datetime,
        to_time: datetime,
        quotation_time: datetime | None = None,
        quotation_behavior: QuotationBehavior = QuotationBehavior.LATEST,
        quotation_exactly_at: bool = False,
        namespace_name: str | None = None,
        where: dict[str, Any] | None = None,
        properties: list[str] | None = None,
        aggregation: Aggregation | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int | None = None,
        exclude_qualities: list[Quality] | None = None,
        time_zone: str | None = None,
    ) -> dict[str, dict]:
        """Retrieve time series values for inventory items at a specific quotation timestamp.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            from_time: Start timestamp
            to_time: End timestamp
            quotation_time: Optional specific quotation timestamp
            quotation_behavior: How to select quotation if not exact
            quotation_exactly_at: Require exact quotation match
            namespace_name: Optional namespace
            where: GraphQL filter conditions for inventory items. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
            properties: Additional item properties to include
            aggregation: Optional data aggregation
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            exclude_qualities: Quality flags to exclude
            time_zone: Timezone for timestamps

        Returns:
            Dict mapping item IDs to item and time series data

        Example:
            ```python
            from datetime import datetime, timedelta
            from seven2one.questra.data import QuotationBehavior

            # Get latest quotation for all items
            end = datetime.now()
            start = end - timedelta(days=7)
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
            )
            # Returns: {"item_id": {"item": {...}, "timeseries": {...}}}

            # Get specific quotation
            quot_time = datetime(2026, 1, 15, 12, 0, 0)
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                quotation_time=quot_time,
                quotation_exactly_at=True,
            )

            # Get quotation with fallback behavior
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                quotation_time=quot_time,
                quotation_behavior=QuotationBehavior.PREVIOUS,
            )

            # Filter by product category
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"category": {"eq": "electronics"}},
                properties=["name", "category", "brand"],
            )

            # Filter by price range (numeric property)
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"base_price": {"gte": 100, "lte": 500}},
            )

            # Complex filter with multiple conditions
            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={
                    "and": [
                        {"category": {"eq": "electronics"}},
                        {
                            "or": [
                                {"brand": {"startsWith": "Premium"}},
                                {"brand": {"eq": "Luxury"}},
                            ]
                        },
                    ]
                },
                quotation_time=quot_time,
            )

            # With aggregation (hourly averages)
            from seven2one.questra.data import Aggregation, TimeUnit

            result = client.list_quotation_values(
                inventory_name="Products",
                timeseries_property="price_history",
                from_time=start,
                to_time=end,
                where={"category": {"in": ["electronics", "appliances"]}},
                aggregation=Aggregation.AVERAGE,
                time_unit=TimeUnit.HOUR,
                multiplier=1,
            )
            ```
        """
        logger.info(
            f"Getting quotation data. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, quotation_time={quotation_time}, quotation_behavior={quotation_behavior}"
        )

        # Step 1: Lade Inventory Items with Timeseries Property
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_name = resolve_field_name(timeseries_property, schema)
        query_properties = ["_id", "_rowVersion"]

        # Add Timeseries Property hinzu
        query_properties.append(f"{ts_field_name}.id")

        # Add additional properties
        if properties:
            for prop in properties:
                if prop not in query_properties:
                    query_properties.append(prop)

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=query_properties,
            where=where,
            first=1000,  # TODO: Implement pagination if more items
        )

        items = result.get("nodes", [])
        logger.debug(f"Found {len(items)} items with TimeSeries property")

        if not items:
            logger.warning(f"No items found in {inventory_name}")
            return {}

        # Step 2: Extrahiere Timeseries IDs
        normalized_field = ts_field_name
        timeseries_ids = []
        ts_to_item_mapping = {}

        for item in items:
            item_id = item["_id"]
            ts_data = item.get(normalized_field)
            if ts_data and isinstance(ts_data, dict) and "id" in ts_data:
                # GraphQL returns IDs as strings, REST API uses integers
                # Convert to int for consistent mapping
                ts_id = int(ts_data["id"])
                ts_to_item_mapping[ts_id] = item_id
                timeseries_ids.append(ts_id)

        if not timeseries_ids:
            logger.warning("No TimeSeries IDs found in items")
            return {}

        logger.debug(f"Extracted {len(timeseries_ids)} TimeSeries IDs")

        # Step 3: Lade time series values with Quotation
        # Default: only exclude MISSING
        if exclude_qualities is None:
            exclude_qualities = [Quality.MISSING]

        ts_result = self._client.timeseries.get_data(
            time_series_ids=timeseries_ids,
            from_time=from_time,
            to_time=to_time,
            time_unit=time_unit,
            multiplier=multiplier if time_unit else None,
            aggregation=aggregation,
            time_zone=time_zone,
            quotation_time=quotation_time,
            quotation_exactly_at=quotation_exactly_at,
            quotation_behavior=quotation_behavior,
            exclude_qualities=exclude_qualities,
        )

        # Step 4: Combine Results
        item_index = {item["_id"]: item for item in items}
        result_dict = {}

        for ts_data in ts_result.data:
            ts_id = ts_data.time_series_id
            if ts_id not in ts_to_item_mapping:
                continue

            item_id = ts_to_item_mapping[ts_id]

            # Initialize item entry if needed
            if item_id not in result_dict:
                result_dict[item_id] = {
                    "item": item_index[item_id],
                    "quotation_time": None,  # Set as needed
                    "timeseries": {},
                }

            # Speichere Timeseries Daten
            result_dict[item_id]["timeseries"][timeseries_property] = {
                "timeseries_id": ts_id,
                "values": ts_data.values,
                "unit": ts_data.unit,
                "interval": ts_data.interval,
                "time_zone": ts_data.time_zone,
            }

            # TODO: quotation_time extract from Response if available
            # Currently the API does not return the actually used quotation

        logger.info(f"Loaded quotation data for {len(result_dict)} items")
        return result_dict

    def save_quotation_values(
        self,
        inventory_name: str,
        timeseries_property: str,
        item_id: str,
        values: list[TimeSeriesValue],
        quotation_time: datetime,
        namespace_name: str | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int = 1,
        unit: str | None = None,
        time_zone: str | None = None,
    ) -> None:
        """Save time series values for a single inventory item under a specific quotation timestamp.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            item_id: Item ID
            values: Time series values to save
            quotation_time: Quotation timestamp
            namespace_name: Optional namespace
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit
            unit: Measurement unit
            time_zone: Timezone for values
        """
        logger.info(
            f"Saving quotation data for single item. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, item_id={item_id}, quotation_time={quotation_time}, value_count={len(values)}"
        )

        # Step 1: Lade Item mit Timeseries Property
        schema = self._registry.get(inventory_name, namespace_name)
        ts_field_name = resolve_field_name(timeseries_property, schema)
        where = {"_id": {"eq": item_id}}
        properties = ["_id", f"{ts_field_name}.id"]

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=properties,
            where=where,
            first=1,
        )

        items = result.get("nodes", [])
        if not items:
            raise ValueError(f"Item with ID {item_id} not found in {inventory_name}")

        item = items[0]
        ts_data = item.get(ts_field_name)

        if not ts_data or not isinstance(ts_data, dict) or "id" not in ts_data:
            raise ValueError(
                f"Item {item_id} has no valid TimeSeries property '{timeseries_property}' "
                f"(field: '{ts_field_name}')"
            )

        # GraphQL returns IDs as strings, REST API uses integers
        ts_id = int(ts_data["id"])
        logger.debug(f"Found TimeSeries ID {ts_id} for item {item_id}")

        # Step 2: Erstelle SetTimeSeriesDataInput with quotation
        from .models import Interval

        data_input = SetTimeSeriesDataInput(
            time_series_id=ts_id,
            values=values,
            interval=Interval(time_unit=time_unit, multiplier=multiplier)
            if time_unit
            else None,
            unit=unit,
            time_zone=time_zone,
            quotation_time=quotation_time,  # ← Notierungs-Zeitstempel!
        )

        # Step 3: Speichere values via REST API
        self._client.timeseries.set_data([data_input])
        logger.info(
            f"Saved {len(values)} values with quotation_time={quotation_time} for TimeSeries {ts_id}"
        )

    def compare_quotations(
        self,
        inventory_name: str,
        timeseries_property: str,
        item_id: str,
        quotation_times: list[datetime],
        from_time: datetime,
        to_time: datetime,
        namespace_name: str | None = None,
        aggregation: Aggregation | None = None,
        time_unit: TimeUnit | None = None,
        multiplier: int | None = None,
    ) -> pd.DataFrame:
        """Compare time series values across multiple quotation timestamps for a single item.

        Args:
            inventory_name: Name of inventory
            timeseries_property: Time series property name
            item_id: Item ID to compare
            quotation_times: List of quotation timestamps to compare
            from_time: Start timestamp
            to_time: End timestamp
            namespace_name: Optional namespace
            aggregation: Optional data aggregation
            time_unit: Time interval unit
            multiplier: Multiplier for time_unit

        Returns:
            pandas DataFrame with quotation comparison

        Raises:
            ImportError: If pandas is not installed
        """
        if not _PANDAS_AVAILABLE:
            raise ImportError(
                "pandas is required for DataFrame output. "
                "Install with: pip install seven2one-questra-data[pandas]"
            )

        if not quotation_times:
            raise ValueError("At least one quotation_time is required")

        logger.info(
            f"Comparing quotations. inventory_name={inventory_name}, namespace_name={namespace_name}, timeseries_property={timeseries_property}, item_id={item_id}, quotation_count={len(quotation_times)}"
        )

        # Load Daten for each quotation
        all_data = {}
        for quot_time in quotation_times:
            logger.debug(f"Loading data for quotation {quot_time}")
            data = self.list_quotation_values(
                inventory_name=inventory_name,
                timeseries_property=timeseries_property,
                from_time=from_time,
                to_time=to_time,
                quotation_time=quot_time,
                quotation_exactly_at=True,  # Exakt diese Notierung
                namespace_name=namespace_name,
                where={"_id": {"eq": item_id}},
                aggregation=aggregation,
                time_unit=time_unit,
                multiplier=multiplier,
            )

            # Extract values for this item
            if item_id in data:
                item_data = data[item_id]
                if timeseries_property in item_data["timeseries"]:
                    ts_values = item_data["timeseries"][timeseries_property]["values"]
                    all_data[quot_time] = ts_values
                else:
                    logger.warning(
                        f"No data for quotation {quot_time} and property {timeseries_property}"
                    )
                    all_data[quot_time] = []
            else:
                logger.warning(f"No data for quotation {quot_time} and item {item_id}")
                all_data[quot_time] = []

        # Create DataFrame with MultiIndex columns
        # Format: (quotation_time, "value") and (quotation_time, "quality")
        data_dict = {}

        for quot_time, values in all_data.items():
            # Column for values
            value_series = pd.Series(  # type: ignore
                {val.time: float(val.value) for val in values},
                name=(quot_time, "value"),
            )
            data_dict[(quot_time, "value")] = value_series

            # Column for quality
            quality_series = pd.Series(  # type: ignore
                {
                    val.time: val.quality.value if val.quality else None
                    for val in values
                },
                name=(quot_time, "quality"),
            )
            data_dict[(quot_time, "quality")] = quality_series

        # Create DataFrame
        df = pd.DataFrame(data_dict)  # type: ignore
        df.index.name = "time"
        df = df.sort_index()

        # Set MultiIndex for columns
        df.columns = pd.MultiIndex.from_tuples(  # type: ignore
            df.columns, names=["quotation_time", "metric"]
        )

        logger.info(f"Created comparison DataFrame with {len(df)} rows")
        return df

    # ===== Inventory Operations =====

    def list_items(
        self,
        inventory_name: str,
        properties: list[str] | None = None,
        namespace_name: str | None = None,
        where: dict[str, Any] | None = None,
        limit: int = 100,
    ) -> QueryResult:
        """List items from the given inventory, with optional filtering and property selection.

        Args:
            inventory_name: Name of inventory
            properties: Properties to retrieve (defaults to _id and _rowVersion)
            namespace_name: Optional namespace filter
            where: GraphQL filter conditions. Operators depend on property type:
                - String properties: `eq`, `neq`, `in`, `nin`, `contains`, `ncontains`,
                  `startsWith`, `nstartsWith`, `endsWith`, `nendsWith`, `and`, `or`
                - Numeric properties (Int, Long): `eq`, `neq`, `in`, `nin`, `gt`, `ngt`,
                  `gte`, `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - DateTime properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - UUID properties: `eq`, `neq`, `in`, `nin`, `gt`, `ngt`, `gte`,
                  `ngte`, `lt`, `nlt`, `lte`, `nlte`
                - Root level: `and`, `or`
                Note: Negated operators (prefixed with 'n') negate the condition.
            limit: Maximum number of items to return

        Returns:
            QueryResult containing items

        Example:
            ```python
            # List all items
            result = client.list_items("Sensors", properties=["_id", "name", "status"])

            # Filter by exact value
            result = client.list_items("Sensors", where={"status": {"eq": "active"}})

            # Filter by value list
            result = client.list_items(
                "Sensors", where={"type": {"in": ["temperature", "humidity"]}}
            )

            # Exclude values
            result = client.list_items(
                "Sensors", where={"status": {"nin": ["inactive", "deleted"]}}
            )

            # Filter by string pattern
            result = client.list_items(
                "Sensors", where={"name": {"startsWith": "sensor-"}}
            )

            # Negated string pattern (does not start with)
            result = client.list_items(
                "Sensors", where={"name": {"nstartsWith": "test-"}}
            )

            # Numeric comparison
            result = client.list_items(
                "Sensors", where={"temperature": {"gte": 20, "lte": 25}}
            )

            # Complex filter with AND
            result = client.list_items(
                "Sensors",
                where={
                    "and": [
                        {"status": {"eq": "active"}},
                        {"location": {"contains": "building-A"}},
                    ]
                },
            )

            # Complex filter with OR
            result = client.list_items(
                "Sensors",
                where={
                    "or": [{"status": {"eq": "active"}}, {"status": {"eq": "pending"}}]
                },
            )

            # Nested complex filter
            result = client.list_items(
                "Sensors",
                where={
                    "and": [
                        {"type": {"eq": "temperature"}},
                        {
                            "or": [
                                {"location": {"contains": "room-A"}},
                                {"location": {"contains": "room-B"}},
                            ]
                        },
                    ]
                },
            )
            ```
        """
        logger.info(
            f"Listing inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, limit={limit}"
        )

        # If no properties specified, load basic fields
        if properties is None:
            properties = ["_id", "_rowVersion"]

        schema = self._registry.get(inventory_name, namespace_name)
        properties, schema = self._validate_and_resolve_properties(
            properties, schema, inventory_name, namespace_name
        )

        result = self._client.inventory.list(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            properties=properties,
            where=where,
            first=limit,
        )

        items = result.get("nodes", [])
        items = self._remap_response(items, schema.name_mapping)
        logger.info(f"Listed {len(items)} items from {inventory_name}")
        return QueryResult(items)

    def create_items(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
    ) -> QueryResult[dict[str, Any]]:
        """Create one or more items in the given inventory.

        **Automatic time series creation:** For every TIME_SERIES property in
        the inventory schema, the value in each item dict controls the
        behaviour:

        - ``None`` – a new TimeSeries object is created automatically and its
          ID is written back into the item dict before the inventory mutation
          is sent.
        - ``str`` or ``int`` – interpreted as an existing TimeSeries ID; the
          value is kept as-is (normalised to ``int``).
        - Any other type – raises ``ValueError``.

        If the inventory has no TIME_SERIES properties, this step is skipped
        entirely.

        Note:
            The returned dicts contain only ``_id``, ``_rowVersion``, and
            ``_existed``.  Original property values are **not** reflected in
            the return value.  Merge them with the input dicts when you need
            the full item representation.

        Args:
            inventory_name: Name of inventory
            items: List of item dicts to create.  For TIME_SERIES properties
                set the value to ``None`` to auto-create a new TimeSeries, or
                pass an existing TimeSeries ID (``str`` or ``int``) to reuse it.
                For FILE properties pass a :class:`FileUpload` instance to upload
                automatically, or an existing file ID (``int``) to reuse.
            namespace_name: Optional namespace

        Returns:
            QueryResult of created items, each containing only ``_id``,
            ``_rowVersion``, and ``_existed``.  Keys are accessible
            case-insensitively (e.g. ``item["_rowversion"]``).

        Raises:
            ValueError: If a TIME_SERIES property value is not ``None``,
                ``str``, or ``int``.

        Example:
            ```python
            # Auto-create time series (None → new TimeSeries ID written back in-place)
            items = [
                {"name": "Sensor A", "temperature": None},
                {"name": "Sensor B", "temperature": None},
            ]
            created = client.create_items("Sensors", items)

            # Merge IDs with original data if the full representation is needed
            for original, result in zip(items, created):
                original["_id"] = result["_id"]
                original["_rowVersion"] = result["_rowVersion"]

            # FILE property: FileUpload handles upload automatically
            created = client.create_items(
                "MyInventory",
                [{"name": "Doc A", "Document": FileUpload("/path/to/file.pdf")}],
                namespace_name="MyNamespace",
            )
            # Reuse existing file by ID
            created = client.create_items(
                "MyInventory",
                [{"name": "Doc A", "Document": 42}],
                namespace_name="MyNamespace",
            )
            ```
        """
        logger.info(
            f"Creating inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(items)}"
        )

        schema = self._registry.get(inventory_name, namespace_name)
        if schema.file_field_names:
            self._auto_upload_files(items, schema, inventory_name, namespace_name)
        if schema.timeseries_field_names:
            self._auto_create_timeseries(items, schema, inventory_name, namespace_name)

        result = self._client.inventory.create(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            items=items,
        )
        logger.info(f"Created {len(result)} items in {inventory_name}")
        return QueryResult(result)

    def update_items(
        self,
        inventory_name: str,
        items: list[dict[str, Any]],
        namespace_name: str | None = None,
    ) -> QueryResult[dict[str, Any]]:
        """Update one or more existing items in the given inventory.

        System keys (``_id``, ``_rowVersion``) are accepted in any casing
        and normalised automatically, so ``_Id``/``_RowVersion`` work as well.

        Args:
            inventory_name: Name of inventory
            items: List of items with ``_id`` and ``_rowVersion``
                (any casing accepted).  For FILE properties pass a
                :class:`FileUpload` instance to upload automatically, or an
                existing file ID (``int``) to reuse.
            namespace_name: Optional namespace

        Returns:
            QueryResult of updated items, each containing only ``_id``,
            ``_rowVersion``, and ``_existed``.  Keys are accessible
            case-insensitively.

        Example:
            ```python
            # Update a scalar property
            client.update_items(
                "MyInventory",
                [{"_id": 1, "_rowVersion": 1, "name": "New Name"}],
            )

            # FILE property: upload a new file automatically
            client.update_items(
                "MyInventory",
                [
                    {
                        "_id": 1,
                        "_rowVersion": 1,
                        "Document": FileUpload("/path/to/new.pdf"),
                    }
                ],
            )

            # FILE property: reuse an already-uploaded file by ID
            client.update_items(
                "MyInventory",
                [{"_id": 1, "_rowVersion": 1, "Document": 42}],
            )
            ```
        """
        logger.info(
            f"Updating inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(items)}"
        )

        schema = self._registry.get(inventory_name, namespace_name)
        if schema.file_field_names:
            self._auto_upload_files(items, schema, inventory_name, namespace_name)

        result = self._client.inventory.update(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            items=items,
        )
        logger.info(f"Updated {len(result)} items in {inventory_name}")
        return QueryResult(result)

    def delete_items(
        self,
        inventory_name: str,
        item_ids: list[int | dict[str, Any]],
        namespace_name: str | None = None,
    ) -> QueryResult[dict[str, Any]]:
        """Delete one or more items from the given inventory by ID.

        Args:
            inventory_name: Name of inventory
            item_ids: List of item IDs or dicts with _id and _rowVersion
            namespace_name: Optional namespace

        Returns:
            QueryResult of deleted items, each containing only ``_id``,
            ``_rowVersion``, and ``_existed``.  Keys are accessible
            case-insensitively.
        """
        logger.info(
            f"Deleting inventory items. inventory_name={inventory_name}, namespace_name={namespace_name}, item_count={len(item_ids)}"
        )

        # Convert IDs to dicts if necessary
        items_to_delete = []
        for item in item_ids:
            if isinstance(item, dict):
                items_to_delete.append(item)
            else:
                loaded = self._client.inventory.list(
                    inventory_name=inventory_name,
                    namespace_name=namespace_name,
                    properties=["_id", "_rowVersion"],
                    where={"_id": {"eq": item}},
                    first=1,
                )
                if loaded.get("nodes"):
                    items_to_delete.append(loaded["nodes"][0])

        result = self._client.inventory.delete(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            items=items_to_delete,
        )

        logger.info(f"Deleted {len(result)} items from {inventory_name}")
        return QueryResult(result)

    def create_namespace(
        self,
        name: str,
        description: str | None = None,
        if_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Create a namespace to logically group inventories and items.

        Args:
            name: Namespace name
            description: Optional description
            if_exists: Action if namespace already exists

        Returns:
            NamedItemResult indicating creation status
        """
        logger.info(f"Creating namespace. name={name}")

        result = self._client.mutations.create_namespace(
            namespace_name=name,
            description=description,
            if_exists=if_exists,
        )

        logger.info(f"Namespace created: {name}, existed={result.existed}")
        return result

    def delete_namespace(
        self,
        name: str,
        if_not_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Delete a namespace.

        Args:
            name: Namespace name
            if_not_exists: Action if namespace doesn't exist

        Returns:
            NamedItemResult indicating deletion status
        """
        logger.info(f"Deleting namespace. name={name}")

        result = self._client.mutations.drop_namespace(
            namespace_name=name,
            if_not_exists=if_not_exists,
        )

        logger.info(f"Namespace deleted: {name}, existed={result.existed}")
        return result

    def create_inventory(
        self,
        name: str,
        properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ],
        namespace_name: str | None = None,
        description: str | None = None,
        enable_audit: bool = False,
        relations: list[InventoryRelation] | None = None,
        if_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Create a new inventory with the given properties and optional configuration.

        Args:
            name: Inventory name
            properties: List of inventory properties
            namespace_name: Optional namespace
            description: Optional description
            enable_audit: Enable audit logging
            relations: Optional inventory relations
            if_exists: Action if inventory already exists

        Returns:
            NamedItemResult indicating creation status
        """
        logger.info(f"Creating inventory. name={name}, namespace_name={namespace_name}")

        normalized_properties = self._normalize_properties(properties)

        result = self._client.mutations.create_inventory(
            inventory_name=name,
            properties=normalized_properties,
            namespace_name=namespace_name,
            description=description,
            enable_audit=enable_audit,
            relations=relations,
            if_exists=if_exists,
        )

        logger.info(f"Inventory created: {name}, existed={result.existed}")
        return result

    def update_inventory(
        self,
        inventory_name: str,
        namespace_name: str | None = None,
        add_properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ]
        | None = None,
        alter_properties: list[
            InventoryProperty
            | StringProperty
            | IntProperty
            | LongProperty
            | DecimalProperty
            | BoolProperty
            | DateTimeProperty
            | DateTimeOffsetProperty
            | DateProperty
            | TimeProperty
            | GuidProperty
            | FileProperty
            | TimeSeriesProperty
        ]
        | None = None,
        drop_properties: list[str] | None = None,
        add_relations: list[InventoryRelation] | None = None,
        drop_relations: list[str] | None = None,
        alter_relations: list[InventoryRelation] | None = None,
        new_inventory_name: str | None = None,
        description: str | None = None,
        enable_audit: bool | None = None,
        if_not_exists: ConflictAction = ConflictAction.RAISE_ERROR,
    ) -> BackgroundJobResult:
        """Alter the schema of an existing inventory (add, modify, or drop properties and relations).

        Changes are applied asynchronously — the returned job ID can be used to track
        completion.

        Args:
            inventory_name: Name of the inventory to alter
            namespace_name: Optional namespace
            add_properties: Properties to add
            alter_properties: Properties to alter
            drop_properties: Property names to drop
            add_relations: Relations to add
            drop_relations: Relation names to drop
            alter_relations: Relations to alter
            new_inventory_name: Rename inventory to this name
            description: New description
            enable_audit: Enable or disable audit
            if_not_exists: Behavior when inventory does not exist

        Returns:
            BackgroundJobResult with the background job ID
        """
        logger.info(
            f"Updating inventory. inventory_name={inventory_name}, namespace_name={namespace_name}"
        )

        normalized_add = (
            self._normalize_properties(add_properties) if add_properties else None
        )
        normalized_alter = (
            self._normalize_properties(alter_properties) if alter_properties else None
        )

        result = self._client.mutations.start_alter_inventory(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            add_properties=normalized_add,
            alter_properties=normalized_alter,
            drop_properties=drop_properties,
            add_relations=add_relations,
            drop_relations=drop_relations,
            alter_relations=alter_relations,
            new_inventory_name=new_inventory_name,
            description=description,
            enable_audit=enable_audit,
            if_not_exists=if_not_exists,
        )

        logger.info(
            f"Inventory update job started. inventory_name={inventory_name}, background_job_id={result.background_job_id}"
        )
        return result

    def delete_inventory(
        self,
        inventory_name: str,
        namespace_name: str | None = None,
        if_not_exists: ConflictAction = ConflictAction.IGNORE,
    ) -> NamedItemResult:
        """Delete an inventory.

        Args:
            inventory_name: Name of inventory to delete
            namespace_name: Optional namespace
            if_not_exists: Action if inventory doesn't exist

        Returns:
            NamedItemResult indicating deletion status
        """
        logger.info(
            f"Deleting inventory. inventory_name={inventory_name}, namespace_name={namespace_name}"
        )

        result = self._client.mutations.delete_inventory(
            inventory_name=inventory_name,
            namespace_name=namespace_name,
            if_not_exists=if_not_exists,
        )

        logger.info(f"Inventory deleted: {inventory_name}, existed={result.existed}")
        return result

    def get_system_info(self) -> SystemInfo:
        """Return version and configuration details of the connected Questra Data service."""
        return self._catalog_manager.get_system_info()

    def list_namespaces(self) -> QueryResult[Namespace]:
        """Return all namespaces defined in the Questra Data service."""
        namespaces = self._catalog_manager.list_namespaces()
        return QueryResult(namespaces)

    def list_roles(self) -> QueryResult[Role]:
        """Return all roles available for managing inventory access permissions."""
        roles = self._catalog_manager.list_roles()
        return QueryResult(roles)

    def list_units(self) -> QueryResult[Unit]:
        """Return all measurement units available for annotating time series values."""
        units = self._catalog_manager.list_units()
        return QueryResult(units)

    def list_time_zones(self) -> QueryResult[TimeZone]:
        """Return all time zones supported by the service for use in time series operations."""
        time_zones = self._catalog_manager.list_time_zones()
        return QueryResult(time_zones)

    def list_inventories(
        self,
        namespace_name: str | None = None,
        inventory_names: list[str] | None = None,
    ) -> QueryResult[Inventory]:
        """List inventories, optionally filtered by namespace or name.

        Args:
            namespace_name: Optional namespace filter
            inventory_names: Optional inventory name filter

        Returns:
            QueryResult containing inventories
        """
        logger.info(f"Listing inventories. namespace_name={namespace_name}")

        where = {}
        if namespace_name:
            where["namespaceNames"] = [namespace_name]
        if inventory_names:
            where["inventoryNames"] = inventory_names

        inventories = self._client.queries.get_inventories(
            where=where if where else None
        )
        return QueryResult(inventories)

    # ===== Direct Access to raw client =====

    @property
    def raw(self) -> _QuestraDataCore:
        """Exposes the full low-level API surface for advanced use cases not covered by the `QuestraData` methods."""
        return self._client

    def is_authenticated(self) -> bool:
        """Return whether the underlying authentication client currently holds a valid token."""
        return self._client.is_authenticated()

    def __repr__(self) -> str:
        auth_status = (
            "authenticated" if self.is_authenticated() else "not authenticated"
        )
        return f"QuestraData(url='{self._client.graphql_url}', status='{auth_status}')"
