"""Flux service provider using the Insight API (bitcore-node compatible).

Primary endpoint: explorer.runonflux.io (same backend as SSP wallet).
"""

from __future__ import annotations

import asyncio
import contextlib
import logging
import re
import ssl
from datetime import datetime, timezone
from decimal import Decimal
from typing import TYPE_CHECKING, Self

import certifi
import httpx
import yarl

from fluxwallet.config import TIMEOUT_REQUESTS, UTXO_BATCH_SIZE
from fluxwallet.exceptions import ClientError as ClientError
from fluxwallet.networks import Network
from fluxwallet.services.models import BroadcastResult, ProviderUtxo
from fluxwallet.services.retry import retry_with_backoff
from fluxwallet.transactions import FluxTransaction, Input, Output

if TYPE_CHECKING:
    import collections.abc

_logger = logging.getLogger(__name__)

PROVIDERNAME = "insight"

# /api/addrs/<addr>/txs supports from/to ranges up to 500.
_MAX_RANGE = 500
# Number of concurrent range requests per round.
_CONCURRENCY = 10

_BASE58_RE = re.compile(r"^[123456789ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz]{25,35}$")
_TXID_RE = re.compile(r"^[0-9a-fA-F]{64}$")
_MAX_MONEY = 440_000_000 * 100_000_000


def _validate_address(address: str) -> None:
    if not _BASE58_RE.match(address):
        raise ValueError(f"Invalid address format: {address!r}")


def _validate_utxo(u: dict) -> bool:
    txid = u.get("txid", "")
    if not _TXID_RE.match(str(txid)):
        _logger.warning("Skipping UTXO with invalid txid: %s", txid)
        return False
    vout = u.get("vout")
    if not isinstance(vout, int) or vout < 0:
        _logger.warning("Skipping UTXO with invalid vout: %s", vout)
        return False
    sats = u.get("satoshis")
    if not isinstance(sats, int) or sats <= 0 or sats > _MAX_MONEY:
        _logger.warning("Skipping UTXO with invalid value: %s", sats)
        return False
    return True



class InsightClient:
    """Async client for the Flux Insight API.

    Uses the same Insight-compatible API as the SSP wallet (explorer.runonflux.io). All methods are async.
    """

    def __init__(
        self,
        network: str,
        base_url: str,
        denominator: int,
        api_key: str = "",
        provider_coin_id: str = "",
        network_overrides: dict[str, str] | None = None,
        timeout: int = TIMEOUT_REQUESTS,
        latest_block: int | None = None,
        strict: bool = True,
    ) -> None:
        if not isinstance(network, Network):
            self.network = Network(network)
        else:
            self.network = network
        self.base_url = base_url.rstrip("/")
        parsed = yarl.URL(self.base_url)
        if parsed.scheme != "https":
            raise ValueError(f"InsightClient requires HTTPS, got: {self.base_url}")
        self.provider = PROVIDERNAME
        self.units = denominator
        self.timeout = timeout
        self.latest_block = latest_block
        ssl_ctx = ssl.create_default_context(cafile=certifi.where())
        self._client = httpx.AsyncClient(
            verify=ssl_ctx,
            timeout=timeout,
            headers={"Accept": "application/json"},
        )

    async def __aenter__(self) -> Self:
        return self

    async def __aexit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: object,
    ) -> None:
        await self.close()

    # --- HTTP helpers ---

    async def _get(self, path: str) -> dict | list | int | str:
        """GET request to the Insight API.

        :param path: API path (appended to base_url/api)
        :returns: Parsed JSON response
        :raises ClientError: On HTTP errors or connection failures
        """
        url = f"{self.base_url}/api{path}"

        async def _do() -> dict | list | int | str:
            response = await self._client.get(url)
            response.raise_for_status()
            return response.json()

        try:
            return await retry_with_backoff(_do)
        except httpx.HTTPStatusError as e:
            msg = str(e)
            with contextlib.suppress(ValueError, AttributeError):
                msg = e.response.text
            raise ClientError(f"HTTP {e.response.status_code} from {url}: {msg}") from e
        except httpx.RequestError as e:
            raise ClientError(f"Request failed for {url}: {e}") from e

    async def _post(self, path: str, data: dict[str, str]) -> dict[str, str]:
        """POST request to the Insight API.

        :param path: API path (appended to base_url/api)
        :param data: JSON body
        :returns: Parsed JSON response
        :raises ClientError: On HTTP errors or connection failures
        """
        url = f"{self.base_url}/api{path}"

        async def _do() -> dict[str, str]:
            response = await self._client.post(url, json=data)
            response.raise_for_status()
            return response.json()

        try:
            return await retry_with_backoff(_do)
        except httpx.HTTPStatusError as e:
            msg = str(e)
            with contextlib.suppress(ValueError, AttributeError):
                msg = e.response.text
            raise ClientError(f"HTTP {e.response.status_code} from {url}: {msg}") from e
        except httpx.RequestError as e:
            raise ClientError(f"Request failed for {url}: {e}") from e

    async def _get_tx_range(self, address: str, start: int, end: int) -> list[dict]:
        """Fetch a range of transactions for an address.

        Uses /api/addrs/<addr>/txs?from=X&to=Y which supports ranges up to 500 and returns transactions newest-first.

        :param address: Flux address
        :param start: Start index (inclusive, 0 = newest)
        :param end: End index (exclusive)
        :returns: List of raw transaction dicts
        """
        result = await self._get(f"/addrs/{address}/txs?from={start}&to={end}&noAsm=1&noScriptSig=1")
        if isinstance(result, dict):
            return result.get("items", [])
        return []

    # --- Blockchain queries ---

    async def blockcount(self) -> int:
        """Get the current block height.

        Uses /api/sync which returns {height, status, ...}.

        :returns: Current block height
        """
        result = await self._get("/sync")
        if not isinstance(result, dict):
            raise ClientError("Unexpected /api/sync response type")
        height = result.get("height")
        if height is None:
            raise ClientError("No height in /api/sync response")
        return int(height)

    async def getblock(self, block_hash: str, parse_transactions: bool = False) -> dict:
        """Get block data by hash.

        :param block_hash: Block hash
        :param parse_transactions: If True, parse transaction objects
        :returns: Block data dict
        """
        result = await self._get(f"/block/{block_hash}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected block response type: {type(result)}")
        return result

    async def getblockhash(self, height: int) -> str:
        """Get block hash by height.

        :param height: Block height
        :returns: Block hash string
        """
        result = await self._get(f"/block-index/{height}")
        if not isinstance(result, dict):
            raise ClientError(f"Unexpected block-index response type: {type(result)}")
        return str(result["blockHash"])

    # --- Address queries ---

    async def getbalance(self, addresslist: str | list[str]) -> int:
        """Get balance for an address in satoshis.

        :param addresslist: Single address string or list of addresses
        :returns: Balance in satoshis
        """
        if isinstance(addresslist, list):
            total = 0
            for addr in addresslist:
                total += await self.getbalance(addr)
            return total
        _validate_address(addresslist)
        result = await self._get(f"/addr/{addresslist}/balance")
        if not isinstance(result, (int, str)):
            raise ClientError(f"Unexpected balance response type: {type(result)}")
        return int(result)

    async def getutxos(
        self,
        address: str,
        after_txid: str = "",
        limit: int = 0,
    ) -> list[ProviderUtxo]:
        """Get unspent transaction outputs for an address.

        :param address: Flux address (t1... or t3...)
        :param after_txid: Only return UTXOs after this txid (unused, for API compat)
        :param limit: Maximum number of UTXOs to return (0 = unlimited)
        :returns: List of ProviderUtxo objects
        """
        _validate_address(address)
        raw_utxos: list | dict | int | str = await self._get(f"/addr/{address}/utxo")
        if not isinstance(raw_utxos, list):
            raise ClientError(f"Unexpected UTXO response type: {type(raw_utxos)}")

        utxos: list[ProviderUtxo] = []
        for u in raw_utxos:
            if not _validate_utxo(u):
                continue
            utxos.append(
                ProviderUtxo(
                    address=u.get("address", address),
                    txid=u["txid"],
                    output_n=u["vout"],
                    value=u["satoshis"],
                    script=u.get("scriptPubKey", ""),
                    confirmations=u.get("confirmations", 0),
                )
            )
            if limit and len(utxos) >= limit:
                break

        return utxos

    async def getutxos_multi(
        self,
        addresses: list[str],
        limit: int = 0,
    ) -> list[ProviderUtxo]:
        """Get UTXOs for multiple addresses in a single API call.

        Uses /api/addrs/addr1,addr2,.../utxo which is far more efficient
        than individual address queries.

        :param addresses: List of Flux addresses
        :param limit: Maximum UTXOs to return (0 = unlimited)
        :returns: List of ProviderUtxo objects
        """
        if not addresses:
            return []

        for addr in addresses:
            _validate_address(addr)

        utxos: list[ProviderUtxo] = []

        for i in range(0, len(addresses), UTXO_BATCH_SIZE):
            batch_addrs = addresses[i : i + UTXO_BATCH_SIZE]
            addr_str = ",".join(batch_addrs)
            raw_utxos_resp = await self._get(f"/addrs/{addr_str}/utxo")
            if not isinstance(raw_utxos_resp, list):
                raise ClientError(f"Unexpected UTXO response type: {type(raw_utxos_resp)}")
            raw_utxos = raw_utxos_resp

            for u in raw_utxos:
                if not _validate_utxo(u):
                    continue
                utxos.append(
                    ProviderUtxo(
                        address=u.get("address", ""),
                        txid=u["txid"],
                        output_n=u["vout"],
                        value=u["satoshis"],
                        script=u.get("scriptPubKey", ""),
                        confirmations=u.get("confirmations", 0),
                    )
                )
                if limit and len(utxos) >= limit:
                    return utxos

        return utxos

    # --- Transaction queries ---

    async def gettransaction(self, txid: str) -> FluxTransaction:
        """Get a transaction by txid.

        Fetches the raw hex and parses it into a FluxTransaction object.

        :param txid: Transaction ID
        :returns: Parsed FluxTransaction
        """
        # Get decoded tx for metadata
        tx_data_resp = await self._get(f"/tx/{txid}")
        if not isinstance(tx_data_resp, dict):
            raise ClientError(f"Unexpected tx response type: {type(tx_data_resp)}")
        tx_data = tx_data_resp

        # Get raw hex for proper parsing
        raw_data = await self._get(f"/rawtx/{txid}")
        raw_hex = raw_data.get("rawtx", "") if isinstance(raw_data, dict) else ""

        if raw_hex:
            t = FluxTransaction.parse_hex(
                raw_hex,
                network=self.network.name,
            )
        else:
            # Fallback: construct from decoded data
            t = self._build_transaction_from_insight(tx_data)

        t.txid = txid
        t.confirmations = int(tx_data.get("confirmations", 0))
        t.status = "confirmed" if t.confirmations else "unconfirmed"
        t.block_height = tx_data.get("blockheight")
        t.fee = int(Decimal(str(tx_data.get("fees", 0))) * self.units)
        t.size = tx_data.get("size")
        block_time = tx_data.get("blocktime") or tx_data.get("time")
        t.date = datetime.fromtimestamp(int(block_time), tz=timezone.utc) if block_time else None

        return t

    async def gettransactions(
        self,
        address: str,
        after_txid: str = "",
        limit: int = 50,
    ) -> list[FluxTransaction]:
        """Get transactions for an address.

        :param address: Flux address
        :param after_txid: Only return transactions after this txid
        :param limit: Maximum number of transactions
        :returns: List of FluxTransaction objects
        """
        transactions = []
        page = 0
        found_after = not bool(after_txid)

        while True:
            result = await self._get(f"/txs/?address={address}&pageNum={page}")
            if not isinstance(result, dict):
                break
            txs = result.get("txs", [])
            if not txs:
                break

            for tx_data in txs:
                txid = tx_data.get("txid", "") if isinstance(tx_data, dict) else ""
                if not found_after:
                    if txid == after_txid:
                        found_after = True
                    continue

                if isinstance(tx_data, dict):
                    transactions.append(self._parse_tx_data(tx_data))

                if len(transactions) >= limit:
                    return transactions

            pages_total = result.get("pagesTotal", 1)
            page += 1
            if page >= pages_total:
                break

        return transactions

    async def get_transactions_by_address(
        self,
        address: str,
        after_tx_index: int = 0,
        limit: int = 0,
    ) -> collections.abc.AsyncGenerator[list[FluxTransaction]]:
        """Async generator yielding transaction batches for an address.

        Uses /api/addrs/<addr>/txs with range-based pagination (from/to) for
        efficient bulk fetching. Ranges of up to 500 txs are fetched
        concurrently in rounds.

        Transactions are ordered newest-first. ``after_tx_index`` is the number
        of transactions already known (i.e. skip the first N).

        :param address: Flux address
        :param after_tx_index: Skip this many newest transactions
        :param limit: Maximum new transactions to return (0 = all)
        :yields: List[FluxTransaction] per concurrent batch
        """
        # Probe to get total transaction count.
        probe = await self._get(f"/addrs/{address}/txs?from=0&to=1&noAsm=1&noScriptSig=1")
        total_items = probe.get("totalItems", 0) if isinstance(probe, dict) else 0

        new_txs = total_items - after_tx_index
        if new_txs <= 0:
            return

        if limit:
            new_txs = min(new_txs, limit)

        # Build (from, to) windows covering the range we need.
        # Index 0 is newest. We want indices [0 .. new_txs), which maps to
        # the transactions the caller hasn't seen yet.
        windows = []
        pos = 0
        while pos < new_txs:
            end = min(pos + _MAX_RANGE, new_txs)
            windows.append((pos, end))
            pos = end

        # Fire all requests, stream results as they complete.
        sem = asyncio.Semaphore(_CONCURRENCY)

        async def _fetch_window(start: int, end: int) -> list:
            async with sem:
                return await self._get_tx_range(address, start, end)

        pending = [asyncio.create_task(_fetch_window(s, e)) for s, e in windows]
        total_yielded = 0

        for coro in asyncio.as_completed(pending):
            try:
                result = await coro
            except (httpx.HTTPError, ClientError, OSError) as e:
                _logger.warning("Failed to fetch tx range for %s: %s", address, e)
                continue

            batch = [self._parse_tx_data(tx_data) for tx_data in result]
            total_yielded += len(batch)

            if batch:
                yield batch

            if limit and total_yielded >= limit:
                for task in pending:
                    task.cancel()
                return

    # --- Transaction parsing ---

    def _parse_tx_data(self, tx_data: dict) -> FluxTransaction:
        """Parse a single Insight API tx dict into a FluxTransaction.

        Shared by gettransactions and get_transactions_by_address.
        """
        t = self._build_transaction_from_insight(tx_data)
        t.txid = str(tx_data.get("txid", ""))
        t.confirmations = int(tx_data.get("confirmations", 0))
        t.status = "confirmed" if t.confirmations else "unconfirmed"
        t.block_height = tx_data.get("blockheight")
        t.fee = int(Decimal(str(tx_data.get("fees", 0))) * self.units)
        t.size = tx_data.get("size")
        block_time = tx_data.get("blocktime") or tx_data.get("time")
        if block_time:
            t.date = datetime.fromtimestamp(int(block_time), tz=timezone.utc)
        return t

    def _build_transaction_from_insight(self, tx_data: dict) -> FluxTransaction:
        """Build a FluxTransaction from Insight API decoded transaction data.

        :param tx_data: Decoded transaction dict from /api/tx/:txid
        :returns: FluxTransaction object
        """
        inputs = []
        for vin in tx_data.get("vin", []):
            if not isinstance(vin, dict):
                continue
            inp = Input(
                prev_txid=str(vin.get("txid", "")),
                output_n=int(vin.get("vout", 0)),
                value=int(Decimal(str(vin.get("value", 0))) * self.units),
                address=str(vin.get("addr", "")),
                witness_type="legacy",
            )
            inputs.append(inp)

        outputs = []
        for vout in tx_data.get("vout", []):
            if not isinstance(vout, dict):
                continue
            script_pub_key = vout.get("scriptPubKey", {})
            if not isinstance(script_pub_key, dict):
                script_pub_key = {}
            addresses = script_pub_key.get("addresses", [])
            addr = addresses[0] if isinstance(addresses, list) and addresses else ""
            value = int(Decimal(str(vout.get("value", 0))) * self.units)
            if value < 0 or value > _MAX_MONEY:
                raise ValueError(f"API returned invalid output value: {value}")
            out = Output(
                value=value,
                address=str(addr),
                lock_script=bytes.fromhex(str(script_pub_key.get("hex", ""))),
                network=self.network.name,
                output_n=int(vout.get("n", 0)),
            )
            outputs.append(out)

        return FluxTransaction(
            inputs=inputs,
            outputs=outputs,
            network=self.network.name,
            version=int(tx_data.get("version", 4)),
            locktime=int(tx_data.get("locktime", 0)),
        )

    async def getrawtransaction(self, txid: str) -> str:
        """Get raw transaction hex by txid."""
        raw_data = await self._get(f"/rawtx/{txid}")
        if isinstance(raw_data, dict):
            return str(raw_data.get("rawtx", ""))
        return ""

    async def gettransactions_by_txids(self, txids: list[str]) -> tuple[list[FluxTransaction], list[str]]:
        """Fetch multiple transactions concurrently.

        Returns (successful_transactions, failed_txids) so callers can retry or log failures without losing the
        successful results.
        """
        results = await asyncio.gather(
            *[self.gettransaction(txid) for txid in txids],
            return_exceptions=True,
        )
        succeeded: list[FluxTransaction] = []
        failed: list[str] = []
        for txid, result in zip(txids, results, strict=False):
            if isinstance(result, BaseException):
                _logger.warning("Failed to fetch tx %s: %s", txid, result)
                failed.append(txid)
            else:
                succeeded.append(result)
        return succeeded, failed

    # --- Broadcasting ---

    async def sendrawtransaction(self, rawtx: str) -> BroadcastResult:
        """Broadcast a raw transaction.

        :param rawtx: Transaction hex string
        :returns: BroadcastResult with txid
        :raises ClientError: If broadcast fails
        """
        result = await self._post("/tx/send", {"rawtx": rawtx})
        txid = result.get("txid")
        if not txid:
            raise ClientError(f"No txid in broadcast response: {result}")
        return BroadcastResult(txid=txid)

    # --- Fee estimation ---

    async def estimatefee(self, blocks: int = 1) -> int:
        """Estimate fee rate for Flux transactions.

        Flux uses a fixed fee rate of 1 sat/byte.

        :param blocks: Target confirmation blocks (unused for Flux)
        :returns: Fee rate in satoshis per KB
        """
        return 1000  # 1 sat/byte = 1000 sat/KB

    # --- Cleanup ---

    async def close(self) -> None:
        """Close the underlying HTTP client."""
        await self._client.aclose()
