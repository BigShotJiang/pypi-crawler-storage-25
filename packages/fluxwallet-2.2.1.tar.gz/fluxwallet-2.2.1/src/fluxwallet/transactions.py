from __future__ import annotations

# -*- coding: utf-8 -*-
#
#    fluxwallet - Python Cryptocurrency Library
#    TRANSACTION class to create, verify and sign Transactions
#    © 2017 - 2022 - 1200 Web Development <http://1200wd.com/>
#
#    This program is free software: you can redistribute it and/or modify
#    it under the terms of the GNU Affero General Public License as
#    published by the Free Software Foundation, either version 3 of the
#    License, or (at your option) any later version.
#
#    This program is distributed in the hope that it will be useful,
#    but WITHOUT ANY WARRANTY; without even the implied warranty of
#    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#    GNU Affero General Public License for more details.
#
#    You should have received a copy of the GNU Affero General Public License
#    along with this program.  If not, see <http://www.gnu.org/licenses/>.
#
import json
import logging
import math
import secrets
from collections.abc import Sequence as SequenceABC
from copy import deepcopy
from datetime import datetime
from io import BytesIO
from pathlib import Path
from typing import Protocol, runtime_checkable

import msgpack

from fluxwallet.config import (
    BIP68_LOCKTIME_GRANULARITY_SECONDS,
    DEFAULT_NETWORK,
    FW_DATA_DIR,
    SEQUENCE_LOCKTIME_DISABLE_FLAG,
    SEQUENCE_LOCKTIME_TYPE_FLAG,
    SEQUENCE_REPLACE_BY_FEE,
    SIGHASH_ALL,
)
from fluxwallet.config.opcodes import op
from fluxwallet.encoding import (
    double_sha256,
    hash160,
    read_varbyteint,
    to_bytes,
    to_hexstring,
    varbyteint_to_int,
    varstr,
)
from fluxwallet.exceptions import FluxWalletError
from fluxwallet.flux_transaction import (
    MAX_MONEY,
    MAX_STANDARD_TX_SIGOPS,
    MAX_TX_SIZE_AFTER_SAPLING,
    NULL_PREVOUT,
    SAPLING_MIN_TX_VERSION,
    TX_EXPIRY_HEIGHT_THRESHOLD,
    OutPoint,
    SaplingTx,
    TxIn,
    TxOut,
)
from fluxwallet.flux_transaction import Script as FluxScript
from fluxwallet.keys import (
    Address,
    HDKey,
    Key,
    Signature,
    deserialize_address,
    sign,
    verify,
)
from fluxwallet.main import script_type_default
from fluxwallet.networks import Network
from fluxwallet.scripts import Script
from fluxwallet.type_guards import is_bytes, is_network
from fluxwallet.values import Value, value_to_satoshi

_logger = logging.getLogger(__name__)


def script_add_locktime_cltv(locktime_cltv: int, script: bytes) -> bytes:
    _op_cltv: int = op.op_checklocktimeverify
    _op_drop: int = op.op_drop
    lockbytes = bytes([_op_cltv, _op_drop])
    if script and len(script) > 6 and script[4:6] == lockbytes:
        return script
    return varstr(locktime_cltv.to_bytes(4, "little")) + lockbytes + script



def dust_threshold(output_size: int = 34, min_relay_fee_per_kb: int = 1000) -> int:
    """Calculate dust threshold per daemon rules.

    Formula: 3 * minRelayFee * (output_size + 148) / 1000
    148 bytes = estimated input size to spend this output.
    """
    return 3 * min_relay_fee_per_kb * (output_size + 148) // 1000


def _count_script_sigops(script_bytes: bytes) -> int:
    """Count OP_CHECKSIG (1) and OP_CHECKMULTISIG (20) in raw script bytes."""
    OP_CHECKSIG = 0xAC
    OP_CHECKSIGVERIFY = 0xAD
    OP_CHECKMULTISIG = 0xAE
    OP_CHECKMULTISIGVERIFY = 0xAF
    count = 0
    for byte in script_bytes:
        if byte in (OP_CHECKSIG, OP_CHECKSIGVERIFY):
            count += 1
        elif byte in (OP_CHECKMULTISIG, OP_CHECKMULTISIGVERIFY):
            count += 20  # worst case: MAX_PUBKEYS_PER_MULTISIG
    return count


class TransactionError(FluxWalletError):
    """Handle Transaction class Exceptions."""

    def __init__(self, msg: str = "") -> None:
        _logger.error(msg)
        super().__init__(msg)


def get_unlocking_script_type(locking_script_type: str, witness_type: str = "legacy", multisig: bool = False) -> str:
    """Specify locking script type and get corresponding script type for unlocking script.

    :param locking_script_type: Locking script type. I.e.: p2pkh, p2sh
    :type locking_script_type: str
    :param witness_type: Type of witness: legacy. Default is legacy
    :type witness_type: str
    :param multisig: Is multisig script or not? Default is False
    :type multisig: bool
    :return str: Unlocking script type such as sig_pubkey or p2sh_multisig
    """

    if locking_script_type == "p2pkh":
        return "sig_pubkey"
    if multisig:
        return "p2sh_multisig"
    if locking_script_type == "p2sh":
        if not multisig:
            return "sig_pubkey"
        return "p2sh_multisig"
    if locking_script_type == "p2pk":
        return "signature"
    raise TransactionError(f"Unknown locking script type {locking_script_type}")


def transaction_update_spents(txs: list[FluxTransaction], address: str) -> list[FluxTransaction]:
    """Update spent information for list of transactions for a specific address. This method assumes the list of
    transaction complete and up-to-date.

    This method loops through all the transaction and update all transaction outputs for given address, checks if the
    output is spent and add the spending transaction ID and index number to the outputs.

    The same list of transactions with updates outputs will be returned

    :param txs: Complete list of transactions for given address
    :type txs: list of Transaction
    :param address: Address string
    :type address: str
    :return list of Transaction:
    """
    spend_list: dict[tuple[str, int], FluxTransaction] = {}
    for t in txs:
        for inp in t.inputs:
            if inp.address == address:
                spend_list.update({(inp.prev_txid.hex(), inp.output_n_int): t})

    address_inputs = list(spend_list.keys())
    for t in txs:
        for to in t.outputs:
            if to.address != address:
                continue

            spent = (t.txid, to.output_n) in address_inputs
            txs[txs.index(t)].outputs[to.output_n].spent = spent

            if spent:
                spending_tx = spend_list[(t.txid, to.output_n)]
                spending_index_n = [
                    inp
                    for inp in txs[txs.index(spending_tx)].inputs
                    if inp.prev_txid.hex() == t.txid and inp.output_n_int == to.output_n
                ][0].index_n

                txs[txs.index(t)].outputs[to.output_n].spending_txid = spending_tx.txid
                txs[txs.index(t)].outputs[to.output_n].spending_index_n = spending_index_n
    return txs


@runtime_checkable
class TransactionProtocol(Protocol):
    """Structural interface for chain transaction types."""

    inputs: list[Input]
    outputs: list[Output]
    txid: str
    txhash: str
    version_int: int
    locktime: int
    network: Network
    fee: int | None
    fee_per_kb: int | None
    size: int | None
    vsize: int | None
    date: datetime | None
    confirmations: int | None
    block_height: int | None
    block_hash: str | None
    input_total: int
    output_total: int
    rawtx: bytes
    status: str
    verified: bool
    witness_type: str
    change: int
    coinbase: bool
    expiry_height: int

    def sign(
        self,
        keys: list[HDKey | Key] | None = None,
        index_n: int | None = None,
        multisig_key_n: int | None = None,
        hash_type: int = SIGHASH_ALL,
        fail_on_unknown_key: bool = True,
        replace_signatures: bool = False,
    ) -> None: ...
    def verify(self) -> bool: ...
    def raw_hex(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        witness_type: str | None = None,
    ) -> str: ...
    def raw(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        **kwargs: str | int | None,
    ) -> bytes: ...
    def signature_hash(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        witness_type: str | None = None,
        as_hex: bool = False,
    ) -> bytes: ...
    def add_input(
        self,
        prev_txid: bytes | str,
        output_n: bytes | int,
        keys: SequenceABC[Key | HDKey | bytes | str] | Key | HDKey | bytes | str | None = None,
        signatures: SequenceABC[Signature | bytes | str] | Signature | bytes | str | None = None,
        public_hash: bytes = b"",
        unlocking_script: bytes | str = b"",
        unlocking_script_unsigned: bytes | str | None = None,
        script_type: str | None = None,
        address: str | Address = "",
        sequence: int | bytes = 0xFFFFFFFF,
        compressed: bool = True,
        sigs_required: int | None = None,
        sort: bool = False,
        index_n: int | None = None,
        value: int | None = None,
        double_spend: bool = False,
        locktime_cltv: int | None = None,
        key_path: str | list[int] = "",
        witness_type: str | None = None,
        witnesses: list[bytes] | list[str] | bytes | None = None,
        encoding: str | None = None,
        strict: bool = True,
    ) -> int: ...
    def add_output(
        self,
        value: int,
        address: str | Address = "",
        public_hash: bytes | str = b"",
        public_key: bytes | str = b"",
        lock_script: bytes | str = b"",
        spent: bool = False,
        output_n: int | None = None,
        encoding: str | None = None,
        spending_txid: str | None = None,
        spending_index_n: int | None = None,
        strict: bool = True,
    ) -> int: ...
    def update_totals(self) -> None: ...
    def estimate_size(self, number_of_change_outputs: int = 0) -> int: ...
    def calculate_fee(self) -> int: ...
    def as_dict(
        self,
    ) -> dict[
        str,
        str | int | bool | list[dict[str, str | int | bool | list[str] | None]] | datetime | None,
    ]: ...
    def as_json(self) -> str: ...
    def info(self) -> None: ...
    def merge_transaction(self, transaction: TransactionProtocol) -> None: ...
    def shuffle(self) -> None: ...
    def save(self, filename: str | None = None) -> None: ...


class Input:
    """Transaction Input class, used by Transaction class.

    An Input contains a reference to an UTXO or Unspent Transaction Output (prev_txid + output_n). To spend the UTXO an
    unlocking script can be included to prove ownership.

    Inputs are verified by the Transaction class.
    """

    def __init__(
        self,
        prev_txid: bytes | str,
        output_n: bytes | int,
        keys: SequenceABC[Key | HDKey | bytes | str] | Key | HDKey | bytes | str | None = None,
        signatures: SequenceABC[Signature | bytes | str] | Signature | bytes | str | None = None,
        public_hash: bytes = b"",
        unlocking_script: bytes | str = b"",
        unlocking_script_unsigned: bytes | str | None = None,
        script: Script | None = None,
        script_type: str | None = None,
        address: str | Address = "",
        sequence: int | bytes = 0xFFFFFFFF,
        compressed: bool | None = None,
        sigs_required: int | None = None,
        sort: bool = False,
        index_n: int = 0,
        value: int | Value | str = 0,
        double_spend: bool = False,
        locktime_cltv: int | None = None,
        key_path: str | list[int] = "",
        witness_type: str | None = None,
        witnesses: list[bytes] | list[str] | bytes | None = None,
        encoding: str | None = None,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> None:
        """Create a new transaction input.

        :param prev_txid: Transaction hash of the UTXO (previous output) which will be
            spent.
        :type prev_txid: bytes, str
        :param output_n: Output number in previous transaction.
        :type output_n: bytes, int
        :param keys: A list of Key objects or public / private key string in various
            formats. If no list is provided but a bytes or string variable, a list with
            one item will be created. Optional
        :type keys: list (bytes, str, Key)
        :param signatures: Specify optional signatures
        :type signatures: list (bytes, str, Signature)
        :param public_hash: Public key hash or script hash. Specify if key is not
            available
        :type public_hash: bytes
        :param unlocking_script: Unlocking script (scriptSig) to prove ownership.
            Optional
        :type unlocking_script: bytes, hexstring
        :param unlocking_script_unsigned: Unlocking script for signing transaction
        :type unlocking_script_unsigned: bytes, hexstring
        :param script_type: Type of unlocking script used, i.e. p2pkh or p2sh_multisig.
            Default is p2pkh
        :type script_type: str
        :param address: Address string or object for input
        :type address: str, Address
        :param sequence: Sequence part of input, you normally do not have to touch this
        :type sequence: bytes, int
        :param compressed: Use compressed or uncompressed public keys. Default is
            compressed
        :type compressed: bool
        :param sigs_required: Number of signatures required for a p2sh_multisig
            unlocking script
        :type sigs_required: int
        :param sort: Sort public keys according to BIP0045 standard. Default is False to
            avoid unexpected change of key order.
        :type sort: boolean
        :param index_n: Index of input in transaction. Used by Transaction class.
        :type index_n: int
        :param value: Value of input in the smallest denominator integers (Satoshi's) or
            as Value object or string
        :type value: int, Value, str
        :param double_spend: Is this input also spend in another transaction
        :type double_spend: bool
        :param locktime_cltv: Check Lock Time Verify value. Script level absolute time
            lock for this input
        :type locktime_cltv: int
        :param key_path: Key path of input key as BIP32 string or list
        :type key_path: str, list
        :param witness_type: Specify witness/signature position: 'segwit' or 'legacy'.
            Determine from script, address or encoding if not specified.
        :type witness_type: str
        :param witnesses: List of witnesses for inputs, used for segwit transactions for
            instance. Argument can be list of bytes or string or a single bytes string
            with concatenated witnesses as found in a raw transaction.
        :type witnesses: list of bytes, list of str, bytes
        :param encoding: Address encoding used. For example bech32/base32 or base58.
            Leave empty for default
        :type encoding: str
        :param strict: Raise exception when input is malformed, incomplete or not
            understood
        :type strict: bool
        :param network: Network, leave empty for default
        :type network: str, Network
        """

        self.prev_txid: bytes = to_bytes(prev_txid)
        if isinstance(output_n, int):
            self.output_n_int: int = output_n
            self.output_n: bytes = output_n.to_bytes(4, "big")
        else:
            self.output_n_int = int.from_bytes(output_n, "big")
            self.output_n = output_n
        self.unlocking_script: bytes = b"" if unlocking_script is None else to_bytes(unlocking_script)
        self.unlocking_script_unsigned: bytes = (
            b"" if unlocking_script_unsigned is None else to_bytes(unlocking_script_unsigned)
        )
        self.script: Script | None = None
        self.hash_type: int = SIGHASH_ALL
        if isinstance(sequence, int):
            self.sequence: int = sequence
        else:
            self.sequence = int.from_bytes(sequence, "little")
        self.compressed: bool | None = compressed
        if is_network(network):
            self.network: Network = network
        else:
            self.network = Network(network)
        self.index_n: int = index_n
        self.value: int = value_to_satoshi(value, network=network)
        if self.value is not None and self.value < 0:
            raise TransactionError(f"Input value cannot be negative: {self.value}")
        if not keys:
            keys_list: list[Key | HDKey | bytes | str] = []
        elif not isinstance(keys, list):
            keys_list = [keys] if not isinstance(keys, SequenceABC) else list(keys)
        else:
            keys_list = list(keys)
        self.keys: list[Key] = []
        self.public_hash: bytes = public_hash
        if not signatures:
            sigs_list: list[Signature | bytes | str] = []
        elif not isinstance(signatures, list):
            sigs_list = [signatures] if not isinstance(signatures, SequenceABC) else list(signatures)
        else:
            sigs_list = list(signatures)
        self.sort: bool = sort
        if isinstance(address, Address):
            self.address: str = address.address
            self.encoding: str = address.encoding if address.encoding is not None else "base58"
            if is_network(address.network):
                self.network = address.network
            else:
                self.network = Network(address.network)
        else:
            self.address = address
        self.signatures: list[Signature] = []
        self.redeemscript: bytes = b""
        self.script_type: str | None = script_type

        if self.prev_txid == b"\0" * 32:
            self.script_type = "coinbase"
        elif self.prev_txid == NULL_PREVOUT:
            # Should not happen since b"\0"*32 == NULL_PREVOUT, but guard against future changes
            raise TransactionError("Non-coinbase input has null prevout")
        self.double_spend: bool = double_spend
        self.locktime_cltv: int | None = locktime_cltv
        self.witness_type: str | None = witness_type
        if encoding is None:
            self.encoding = "base58"
        else:
            self.encoding = encoding
        self.valid: bool | None = None
        self.key_path: str | list[int] = key_path

        self.witnesses: list[bytes] = []
        if isinstance(witnesses, bytes):
            n_items, cursor = varbyteint_to_int(witnesses[0:9])
            for _m in range(0, n_items):
                witness: bytes = b"\0"
                item_size, size = varbyteint_to_int(witnesses[cursor : cursor + 9])
                if item_size:
                    witness = witnesses[cursor + size : cursor + item_size + size]
                cursor += item_size + size
                self.witnesses.append(witness)
        elif witnesses:
            self.witnesses = [bytes.fromhex(w) if isinstance(w, str) else w for w in witnesses]
        self.script_code: bytes = b""
        self.script = script

        # If unlocking script is specified extract keys, signatures, type from script
        if self.unlocking_script and self.script_type != "coinbase" and not (signatures and keys) and not script:
            self.script = Script.parse_bytes(self.unlocking_script, strict=strict)
            self.keys = [k for k in self.script.keys if isinstance(k, Key)]
            self.signatures = [s for s in self.script.signatures if isinstance(s, Signature)]
            if len(self.signatures):
                self.hash_type = self.signatures[0].hash_type
            sigs_required = self.script.sigs_required
            self.redeemscript = self.script.redeemscript if self.script.redeemscript else self.redeemscript
            if len(self.script.script_types) == 1 and not self.script_type:
                self.script_type = self.script.script_types[0]
            elif self.script.script_types == ["signature_multisig", "multisig"]:
                self.script_type = "p2sh_multisig"
        if self.unlocking_script_unsigned and not self.signatures:
            ls = Script.parse_bytes(self.unlocking_script_unsigned, strict=strict)
            self.public_hash = self.public_hash if not ls.public_hash else ls.public_hash
        self.sigs_required: int = sigs_required if sigs_required else 1

        self.witness_type = "legacy"
        if not self.script_type:
            self.script_type = "sig_pubkey"

        for key in keys_list:
            kobj: Key
            if isinstance(key, Key):
                kobj = key
            elif isinstance(key, (bytes, str)):
                kobj = Key(key, network=network, strict=strict)
            else:
                continue
            if kobj not in self.keys:
                # if self.compressed is not None and kobj.compressed != self.compressed:
                #     _logger.warning("Key compressed is %s but Input class compressed argument is %s " %
                #                     (kobj.compressed, self.compressed))
                self.compressed = kobj.compressed
                self.keys.append(kobj)
        if self.compressed is None:
            self.compressed = True
        if self.sort:
            self.keys.sort(key=lambda k: k.public_byte)
        self.strict: bool = strict

        for sig in sigs_list:
            parsed_sig: Signature | None
            if isinstance(sig, Signature):
                parsed_sig = sig
            elif isinstance(sig, (bytes, str)):
                try:
                    parsed_sig = Signature.parse(sig)
                except (ValueError, IndexError) as e:
                    _logger.error(f"Could not parse signature {to_hexstring(sig)} in Input. Error: {e}")
                    continue
            else:
                continue
            if parsed_sig is None:
                continue
            if parsed_sig.as_der_encoded() not in [x.as_der_encoded() for x in self.signatures]:
                self.signatures.append(parsed_sig)
                if parsed_sig.hash_type:
                    self.hash_type = parsed_sig.hash_type

        self.update_scripts(hash_type=self.hash_type)

    @classmethod
    def parse(
        cls,
        raw: BytesIO,
        index_n: int = 0,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
        **kwargs: bytes | str | int | bool,
    ) -> Input:
        """Parse raw BytesIO string and return Input object.

        :param raw: Input
        :type raw: BytesIO
        :param index_n: Index number of input
        :type index_n: int
        :param strict: Raise exception when input is malformed, incomplete or not understood
        :type strict: bool
        :param network: Network, leave empty for default
        :type network: str, Network
        :return Input:
        """
        prev_hash = raw.read(32)[::-1]
        if len(prev_hash) != 32:
            raise TransactionError("Input transaction hash not found. Probably malformed raw transaction")
        output_n = raw.read(4)[::-1]
        unlocking_script_size = read_varbyteint(raw)
        unlocking_script = raw.read(unlocking_script_size)
        sequence_number = raw.read(4)

        return Input(
            prev_txid=prev_hash,
            output_n=output_n,
            unlocking_script=unlocking_script,
            witness_type="legacy",
            sequence=sequence_number,
            index_n=index_n,
            strict=strict,
            network=network,
        )

    def update_scripts(self, hash_type: int = SIGHASH_ALL) -> bool | None:
        """Method to update Input scripts.

        Creates or updates unlocking script, witness script for segwit inputs, multisig redeemscripts and locktime
        scripts. This method is called when initializing an Input class or when signing an input.

        :param hash_type: Specific hash type, default is SIGHASH_ALL
        :type hash_type: int
        :return bool: Always returns True when method is completed
        """

        addr_data: bytes = b""
        unlock_script: bytes = b""
        if self.script_type == "sig_pubkey":
            if not self.public_hash and self.keys:
                self.public_hash = self.keys[0].hash160
            if not self.keys and not self.public_hash:
                return None
            self.script_code = b"\x76\xa9\x14" + self.public_hash + b"\x88\xac"
            self.unlocking_script_unsigned = self.script_code
            addr_data = self.public_hash
            if self.signatures and self.keys:
                unlock_script = b"".join(
                    [
                        bytes(varstr(self.signatures[0].as_der_encoded() if hash_type else b"")),
                        bytes(varstr(self.keys[0].public_byte or b"")),
                    ]
                )
            if (not self.unlocking_script or self.strict) and unlock_script != b"":
                self.unlocking_script = unlock_script
        elif self.script_type == "p2sh_multisig":
            if not self.redeemscript and self.keys:
                _keys_for_script: list[Key | bytes] = list(self.keys)
                self.redeemscript = Script(
                    script_types=["multisig"],
                    keys=_keys_for_script,
                    sigs_required=self.sigs_required,
                ).serialize()
            if self.redeemscript:
                self.public_hash = hash160(self.redeemscript)
            addr_data = self.public_hash
            self.unlocking_script_unsigned = self.redeemscript

            if self.redeemscript and self.keys:
                n_tag: int | bytes = self.redeemscript[0:1]
                if not isinstance(n_tag, int):
                    n_tag = int.from_bytes(n_tag, "big")
                self.sigs_required = n_tag - 80
                signatures: list[bytes | str] = [s.as_der_encoded() for s in self.signatures[: self.sigs_required]]
                if b"" in signatures:
                    raise TransactionError(
                        "Empty signature found in signature list when signing. "
                        "Is DER encoded version of signature defined?"
                    )
                if len(self.signatures) >= self.sigs_required:
                    _pub_bytes: list[Key | bytes] = [k.public_byte or b"" for k in self.keys]
                    _sigs_slice: list[Signature | bytes] = list(self.signatures[: self.sigs_required])
                    unlock_script_obj: Script = Script(
                        script_types=["p2sh_multisig"],
                        keys=_pub_bytes,
                        signatures=_sigs_slice,
                        sigs_required=self.sigs_required,
                        redeemscript=self.redeemscript,
                    )
                    unlock_script = unlock_script_obj.serialize()
                elif self.signatures:
                    unlock_script = b"\x00"  # OP_0 (multisig bug workaround)
                    pub_key_list: list[bytes] = [k.public_byte or b"" for k in self.keys]
                    for _i in range(self.sigs_required):
                        placed: bool = False
                        for sig in self.signatures:
                            if sig.public_key and sig.public_key.public_byte in pub_key_list:
                                idx: int = pub_key_list.index(sig.public_key.public_byte)
                                if idx == _i:
                                    unlock_script += varstr(sig.as_der_encoded())
                                    placed = True
                                    break
                        if not placed:
                            unlock_script += b"\x00"  # OP_0 placeholder
                    unlock_script += varstr(self.redeemscript)
                if unlock_script != b"" and self.strict:
                    self.unlocking_script = unlock_script
        elif self.script_type == "signature":
            if self.keys:
                _pub_byte: bytes = self.keys[0].public_byte or b""
                self.script_code = varstr(_pub_byte) + b"\xac"
                self.unlocking_script_unsigned = self.script_code
                addr_data = _pub_byte
            if self.signatures and not self.unlocking_script:
                _der_encoded: bytes | str = self.signatures[0].as_der_encoded()
                self.unlocking_script = varstr(_der_encoded)
        elif self.script_type not in ["coinbase", "unknown"] and self.strict:
            raise TransactionError(f"Unknown unlocking script type {self.script_type} for input {self.index_n}")
        if addr_data and not self.address:
            self.address = Address(
                hashed_data=addr_data,
                encoding=self.encoding,
                network=self.network,
                script_type=self.script_type,
                witness_type=self.witness_type,
            ).address

        if self.locktime_cltv:
            self.unlocking_script_unsigned = script_add_locktime_cltv(
                self.locktime_cltv, self.unlocking_script_unsigned
            )
            self.unlocking_script = script_add_locktime_cltv(self.locktime_cltv, self.unlocking_script)
        return True

    def verify(self, transaction_hash: bytes) -> bool:
        """Verify input with provided transaction hash, check if signatures matches public key.

        Does not check if UTXO is valid or has already been spent

        :param transaction_hash: Double SHA256 Hash of Transaction signature
        :type transaction_hash: bytes
        :return bool: True if enough signatures provided and if all signatures are valid
        """

        if self.script_type == "coinbase":
            self.valid = True
            return True
        if not self.signatures:
            _logger.info(f"No signatures found for transaction input {self.index_n}")
            return False

        sig_n: int = 0
        key_n: int = 0
        sigs_verified: int = 0
        while sigs_verified < self.sigs_required:
            if key_n >= len(self.keys):
                _logger.info(
                    f"Not enough valid signatures provided for input {self.index_n}. "
                    f"Found {sigs_verified} signatures but {self.sigs_required} needed"
                )
                return False
            if sig_n >= len(self.signatures):
                _logger.info("No valid signatures found")
                return False
            if verify(transaction_hash, self.signatures[sig_n], self.keys[key_n]):
                sigs_verified += 1
                sig_n += 1
            key_n += 1
        self.valid = True
        return True

    def as_dict(self) -> dict[str, str | int | bool | list[str] | None]:
        """Get transaction input information in json format.

        :return dict: Json with output_n, prev_txid, output_n, type, address, public_key, public_hash, unlocking_script
            and sequence
        """

        pks: list[str] | str = []
        for k in self.keys:
            pks.append(k.public_hex or "")
        if len(self.keys) == 1:
            pks = pks[0]
        return {
            "index_n": self.index_n,
            "prev_txid": self.prev_txid.hex(),
            "output_n": self.output_n_int,
            "script_type": self.script_type,
            "address": self.address,
            "value": self.value,
            "public_keys": pks,
            "compressed": self.compressed,
            "encoding": self.encoding,
            "double_spend": self.double_spend,
            "script": self.unlocking_script.hex(),
            "redeemscript": self.redeemscript.hex(),
            "sequence": self.sequence,
            "signatures": [s.hex() for s in self.signatures],
            "sigs_required": self.sigs_required,
            "locktime_cltv": self.locktime_cltv,
            "public_hash": self.public_hash.hex(),
            "script_code": self.script_code.hex(),
            "unlocking_script": self.unlocking_script.hex(),
            "unlocking_script_unsigned": self.unlocking_script_unsigned.hex(),
            "witness_type": self.witness_type,
            "witness": b"".join(self.witnesses).hex(),
            "sort": self.sort,
            "valid": self.valid,
        }

    def __repr__(self) -> str:
        return (
            f"<Input(prev_txid='{self.prev_txid.hex()}', output_n={self.output_n_int}, "
            f"address='{self.address}', index_n={self.index_n}, type='{self.script_type}')>"
        )


class Output:
    """Transaction Output class, normally part of Transaction class.

    Contains the amount and destination of a transaction.
    """

    def __init__(
        self,
        value: int | Value | str,
        address: str | Address | HDKey = "",
        public_hash: bytes | str = b"",
        public_key: bytes | str = b"",
        lock_script: bytes | str = b"",
        spent: bool = False,
        output_n: int = 0,
        script_type: str | None = None,
        encoding: str | None = None,
        spending_txid: str = "",
        spending_index_n: int | None = None,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> None:
        """Create a new transaction output.

        A transaction outputs locks the specified amount to a public key. Anyone with
        the private key can unlock this output.

        The transaction output class contains an amount and the destination which can be
        provided either as address, public key, public key hash or a locking script.
        Only one needs to be provided as they all can be derived from each other, but
        you can provide as many attributes as you know to improve speed.

        :param value: Amount of output in the smallest denominator integers (Satoshi's)
            or as Value object or string
        :type value: int, Value, str
        :param address: Destination address of output. Leave empty to derive from other
            attributes you provide. An instance of an Address or HDKey class is allowed
            as argument.
        :type address: str, Address, HDKey
        :param public_hash: Hash of public key or script
        :type public_hash: bytes, str
        :param public_key: Destination public key
        :type public_key: bytes, str
        :param lock_script: Locking script of output. If not provided a default
            unlocking script will be provided with a public key hash.
        :type lock_script: bytes, str
        :param spent: Is output already spent? Default is False
        :type spent: bool
        :param output_n: Output index number, default is 0. Index number has to be
            unique per transaction and 0 for first output, 1 for second, etc
        :type output_n: int
        :param script_type: Script type of output (p2pkh, p2sh, segwit p2wpkh, etc).
            Extracted from lock_script if provided.
        :type script_type: str
        :param encoding: Address encoding used. For example bech32/base32 or base58.
            Leave empty to derive from address or default base58 encoding
        :type encoding: str
        :param spending_txid: Transaction hash of input spending this transaction output
        :type spending_txid: str
        :param spending_index_n: Index number of input spending this transaction output
        :type spending_index_n: int
        :param strict: Raise exception when output is malformed, incomplete or not
            understood
        :type strict: bool
        :param network: Network, leave empty for default
        :type network: str, Network
        """

        if strict and not (address or public_hash or public_key or lock_script):
            raise TransactionError(
                "Please specify address, lock_script, public key or public key hash when creating output"
            )

        if is_network(network):
            self.network: Network = network
        else:
            self.network = Network(network)
        self.value: int = value_to_satoshi(value, network=network)
        if self.value is not None and self.value < 0:
            raise TransactionError(f"Output value cannot be negative: {self.value}")

        if self.value is not None and self.value > MAX_MONEY:
            raise TransactionError(f"Output value {self.value} exceeds MAX_MONEY")
        self.lock_script: bytes = b"" if lock_script is None else to_bytes(lock_script)
        self.public_hash: bytes = to_bytes(public_hash)
        if isinstance(address, Address):
            self._address: str = address.address
            self._address_obj: Address | None = address
        elif isinstance(address, HDKey):
            self._address = address.address()
            self._address_obj = address.address_obj
            public_key = address.public_byte or b""
            if not script_type:
                script_type = script_type_default(address.witness_type, address.multisig, True)
            self.public_hash = address.hash160
        else:
            self._address = address
            self._address_obj = None
        self.public_key: bytes | str = to_bytes(public_key)
        self.compressed: bool = True
        self.k: Key | None = None
        self.versionbyte: bytes = self.network.prefix_address
        self.script_type: str | None = script_type
        self.encoding: str | None = encoding
        if not self._address and self.encoding is None:
            self.encoding = "base58"
        self.spent: bool = spent
        self.output_n: int = output_n
        self.key_id: int | None = None
        self.script: Script | None = Script.parse_bytes(self.lock_script, strict=strict)

        if self._address_obj:
            self.script_type = self._address_obj.script_type if script_type is None else script_type
            self.public_hash = self._address_obj.hash_bytes
            if is_network(self._address_obj.network):
                self.network = self._address_obj.network
            else:
                self.network = Network(self._address_obj.network)
            self.encoding = self._address_obj.encoding

        if self.script:
            self.script_type = self.script_type if not self.script.script_types else self.script.script_types[0]
            self.public_hash = self.script.public_hash
            if self.script.keys:
                _first_key = self.script.keys[0]
                if isinstance(_first_key, Key) and _first_key.public_hex is not None:
                    self.public_key = _first_key.public_hex

        if self.public_key and not self.public_hash:
            k = Key(self.public_key, is_private=False, network=network)
            self.public_hash = k.hash160
        elif self._address and (not self.public_hash or not self.script_type or not self.encoding):
            address_dict: dict[str, str | bytes | list[str] | int | None] = deserialize_address(
                self._address, self.encoding, self.network.name
            )
            _ad_script_type = address_dict["script_type"]
            if _ad_script_type and not script_type and isinstance(_ad_script_type, str):
                self.script_type = _ad_script_type
            if not self.script_type:
                raise TransactionError(f"Could not determine script type of address {self._address}")
            _ad_encoding = address_dict["encoding"]
            if isinstance(_ad_encoding, str):
                self.encoding = _ad_encoding
            _ad_networks = address_dict["networks"]
            network_guesses: list[str] = _ad_networks if isinstance(_ad_networks, list) else []
            _ad_network = address_dict["network"]
            if _ad_network and isinstance(_ad_network, str) and self.network.name != _ad_network:
                raise TransactionError(
                    f"Address {self._address} is from {_ad_network} network and transaction from "
                    f"{self.network.name} network"
                )
            if self.network.name not in network_guesses:
                raise TransactionError(
                    f"Network for output address {self._address} is different from transaction network. "
                    f"{self.network.name} not "
                    f"in {network_guesses}"
                )
            _ad_pubhash = address_dict["public_key_hash_bytes"]
            if isinstance(_ad_pubhash, bytes):
                self.public_hash = _ad_pubhash
        if not self.encoding:
            self.encoding = "base58"

        if self.script_type is None:
            self.script_type = "p2pkh"
        if strict and self.value == 0 and not (self.script_type or "").startswith("nulldata"):
            raise TransactionError("Output value cannot be zero (only OP_RETURN/nulldata outputs may have zero value)")
        # if self.public_hash and not self._address:
        #     self.address_obj = Address(hashed_data=self.public_hash, script_type=self.script_type,
        #                                encoding=self.encoding, network=self.network)
        #     self.address = self.address_obj.address
        #     self.versionbyte = self.address_obj.prefix
        if not self.script and strict and (self.public_hash or self.public_key):
            _pk_bytes: bytes = self.public_key if is_bytes(self.public_key) else to_bytes(self.public_key)
            self.script = Script(
                script_types=[self.script_type],
                public_hash=self.public_hash,
                keys=[_pk_bytes],
            )
            self.lock_script = self.script.serialize()
            if not self.script:
                raise TransactionError(f"Unknown output script type {self.script_type}, please provide locking script")
        self.spending_txid: str = spending_txid
        self.spending_index_n: int | None = spending_index_n
        if self.value < 0:
            raise TransactionError(f"Output value cannot be negative: {self.value}")
        if self.script_type != "nulldata" and self.value < self.network.dust_amount:
            raise TransactionError(
                f"Output to {self.address} must be more than dust amount {self.network.dust_amount}"
            )

    @property
    def address_obj(self) -> Address | None:
        """Get address object property. Create standard address object if not defined already.

        :return Address:
        """
        if not self._address_obj and self.public_hash:
            self._address_obj = Address(
                hashed_data=self.public_hash,
                script_type=self.script_type,
                encoding=self.encoding,
                network=self.network,
            )
            self._address = self._address_obj.address
            if self._address_obj.prefix is not None:
                self.versionbyte = self._address_obj.prefix
        return self._address_obj

    @property
    def address(self) -> str:
        if not self._address:
            address_obj = self.address_obj
            if not address_obj:
                return ""
            self._address = address_obj.address
        return self._address

    @classmethod
    def parse(
        cls,
        raw: BytesIO,
        output_n: int = 0,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> Output:
        """Parse raw BytesIO string and return Output object.

        :param raw: raw output stream
        :type raw: BytesIO
        :param output_n: Output number of Transaction output
        :type output_n: int
        :param strict: Raise exception when output is malformed, incomplete or not understood
        :type strict: bool
        :param network: Network, leave empty for default network
        :type network: str, Network
        :return Output:
        """
        value = int.from_bytes(raw.read(8)[::-1], "big")
        lock_script_size = read_varbyteint(raw)
        lock_script = raw.read(lock_script_size)
        return Output(
            value=value,
            lock_script=lock_script,
            output_n=output_n,
            strict=strict,
            network=network,
        )

    def as_dict(self) -> dict[str, str | int | bool | list[str] | None]:
        """Get transaction output information in json format.

        :return dict: Json with amount, locking script, public key, public key hash and address
        """

        return {
            "value": self.value,
            "script": self.lock_script.hex(),
            "script_type": self.script_type,
            "public_key": self.public_key.hex() if is_bytes(self.public_key) else self.public_key,
            "public_hash": self.public_hash.hex(),
            "address": self.address,
            "output_n": self.output_n,
            "spent": self.spent,
            "spending_txid": self.spending_txid,
            "spending_index_n": self.spending_index_n,
        }

    def __repr__(self) -> str:
        return f"<Output(value={self.value}, address={self.address}, type={self.script_type})>"


class TransactionMixin:
    def __init__(
        self,
        *,
        inputs: list[Input] | None = None,
        outputs: list[Output] | None = None,
        locktime: int = 0,
        version: bytes | int | None = None,
        network: str = DEFAULT_NETWORK,
        fee: int | None = None,
        fee_per_kb: int | None = None,
        size: int | None = None,
        txid: str = "",
        txhash: str = "",
        date: datetime | None = None,
        confirmations: int | None = None,
        block_height: int | None = None,
        block_hash: str | None = None,
        input_total: int = 0,
        output_total: int = 0,
        rawtx: bytes = b"",
        status: str = "new",
        coinbase: bool = False,
        verified: bool = False,
        witness_type: str = "legacy",
        flag: str | None = None,
        expiry_height: int = 0,
    ) -> None:
        """Create a new transaction class with provided inputs and outputs.

        You can also create an empty transaction and add input and outputs later.

        To verify and sign transactions all inputs and outputs need to be included in transaction. Any modification
        after signing makes the transaction invalid.

        :param inputs: Array of Input objects. Leave empty to add later
        :type inputs: list (Input)
        :param outputs: Array of Output object. Leave empty to add later
        :type outputs: list (Output)
        :param locktime: Transaction level locktime. Locks the transaction until a specified block
            (value from 1 to 5 million) or until a certain time (Timestamp in seconds after
            1-jan-1970). Default value is 0 for transactions without locktime
        :type locktime: int
        :param version: Version rules. Defaults to 1 in bytes
        :type version: bytes, int
        :param network: Network, leave empty for default network
        :type network: str, Network
        :param fee: Fee in smallest denominator (ie Satoshi) for complete transaction
        :type fee: int
        :param fee_per_kb: Fee in smallest denominator per kilobyte. Specify when exact transaction size is not known.
        :type fee_per_kb: int
        :param size: Transaction size in bytes
        :type size: int
        :param txid: The transaction id (same for legacy/segwit) based on
            [nVersion][txins][txouts][nLockTime as hexadecimal string
        :type txid: str
        :param txhash: The transaction hash (differs from txid for witness transactions), based on
            [nVersion][marker][flag][txins][txouts][witness][nLockTime] in Segwit
            (as hexadecimal string). Unused at the moment
        :type txhash: str
        :param date: Confirmation date of transaction
        :type date: datetime
        :param confirmations: Number of confirmations
        :type confirmations: int
        :param block_height: Block number which includes transaction
        :type block_height: int
        :param block_hash: Hash of block for this transaction
        :type block_hash: str
        :param input_total: Total value of inputs
        :type input_total: int
        :param output_total: Total value of outputs
        :type output_total: int
        :param rawtx: Bytes representation of complete transaction
        :type rawtx: bytes
        :param status: Transaction status, for example: 'new', 'unconfirmed', 'confirmed'
        :type status: str
        :param coinbase: Coinbase transaction or not?
        :type coinbase: bool
        :param verified: Is transaction successfully verified? Updated when verified() method is called
        :type verified: bool
        :param witness_type: Specify witness/signature position: 'segwit' or 'legacy'. Determine
            from script, address or encoding if not specified.
        :type witness_type: str
        :param flag: Transaction flag to indicate version, for example for SegWit
        :type flag: bytes, str
        """
        self.expiry_height: int = expiry_height

        self.coinbase: bool = coinbase

        self.inputs: list[Input] = inputs if inputs else []

        if not input_total:
            input_total = sum([i.value for i in self.inputs])

        # this overwrites any inputs index_n passed in
        for index, inp in enumerate(self.inputs):
            inp.index_n = index

        self.outputs: list[Output] = outputs if outputs else []

        if not output_total:
            output_total = sum([o.value for o in self.outputs])

        if fee is None and output_total and input_total:
            fee = input_total - output_total
            if fee < 0:
                raise TransactionError(
                    "Transaction inputs total value must be greater then total value of transaction outputs"
                )
        if not version:
            version = b"\x00\x00\x00\x01"

        if isinstance(version, int):
            self.version: bytes = version.to_bytes(4, "big")
            self.version_int: int = version
        else:
            self.version = version
            self.version_int = int.from_bytes(version, "big")

        self.locktime: int = locktime
        if is_network(network):
            self.network: Network = network
        else:
            self.network = Network(network)

        self.flag: str | None = flag
        self.fee: int | None = fee
        self.fee_per_kb: int | None = fee_per_kb
        self.size: int | None = size
        self.vsize: int | None = size
        self.txid: str = txid
        self.txhash: str = txhash
        self.date: datetime | None = date
        self.confirmations: int | None = confirmations
        self.block_height: int | None = block_height
        self.block_hash: str | None = block_hash
        self.input_total: int = input_total
        self.output_total: int = output_total
        self.rawtx: bytes = rawtx
        self.status: str = status
        self.verified: bool = verified
        self.witness_type: str = witness_type
        self.change: int = 0
        self.calc_weight_units()

        if self.witness_type != "legacy":
            raise TransactionError("Please specify a valid witness type: legacy")
        if not self.txid:
            self.txid = self.signature_hash()[::-1].hex()

    def __str__(self) -> str:
        return self.txid

    def __add__(self, other: TransactionProtocol) -> TransactionMixin:
        """Merge this transaction with another transaction keeping the original transaction intact.

        :return Transaction:
        """
        t = deepcopy(self)
        t.merge_transaction(other)
        return t

    def __hash__(self) -> int:
        return hash(self.txid)

    def __eq__(self, other: object) -> bool:
        """Compare two transaction, must have same transaction ID.

        :param other: Other transaction object
        :type other: Transaction
        :return bool:
        """
        if not isinstance(other, TransactionMixin):
            return NotImplemented
        return self.txid == other.txid

    @classmethod
    def parse_hex(
        cls,
        rawtx: str,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> TransactionMixin:
        """Parse a raw hexadecimal transaction string.

        Must be overridden by subclasses.
        """
        raise NotImplementedError("Subclasses must implement parse_hex")

    @classmethod
    def from_dict(
        cls,
        data: dict[
            str,
            str | int | bool | list[dict[str, str | int | bool | list[str] | None]] | datetime | None,
        ],
    ) -> TransactionMixin:
        """Reconstruct a TransactionMixin (FluxTransaction) from a dictionary, as produced by :func:`as_dict`.

        If a 'raw' key with a valid hex string is present, the transaction is reconstructed by parsing the raw
        transaction bytes. Otherwise, Input and Output objects are rebuilt from the dict data.

        :param data: Transaction dictionary
        :type data: dict
        :return Transaction:
        """

        def _str(key: str, default: str = "") -> str:
            v = data.get(key, default)
            return v if isinstance(v, str) else default

        def _int(key: str, default: int = 0) -> int:
            v = data.get(key, default)
            return v if isinstance(v, int) and not isinstance(v, bool) else default

        def _int_or_none(key: str) -> int | None:
            v = data.get(key)
            if isinstance(v, int) and not isinstance(v, bool):
                return v
            return None

        def _str_or_none(key: str) -> str | None:
            v = data.get(key)
            return v if isinstance(v, str) else None

        def _bool(key: str, default: bool = False) -> bool:
            v = data.get(key, default)
            return v if isinstance(v, bool) else default

        raw_hex = data.get("raw")
        raw_hex_str: str = raw_hex if isinstance(raw_hex, str) else ""
        if raw_hex_str:
            t = cls.parse_hex(raw_hex_str, strict=False, network=_str("network", DEFAULT_NETWORK))
            t.status = _str("status", "new")
            t.verified = _bool("verified", False)
            t.confirmations = _int_or_none("confirmations")
            t.block_height = _int_or_none("block_height")
            t.block_hash = _str_or_none("block_hash")
            t.fee = _int_or_none("fee")
            t.fee_per_kb = _int_or_none("fee_per_kb")
            date_val = data.get("date")
            if isinstance(date_val, str):
                try:
                    t.date = datetime.fromisoformat(date_val)
                except (ValueError, TypeError):
                    t.date = None
            elif isinstance(date_val, datetime):
                t.date = date_val
            else:
                t.date = None
            return t

        inputs: list[Input] = []
        _inputs_raw = data.get("inputs", [])
        _inputs_list: list[dict[str, str | int | bool | list[str] | None]] = (
            _inputs_raw if isinstance(_inputs_raw, list) else []
        )
        for inp_d in _inputs_list:
            if not isinstance(inp_d, dict):
                continue

            def _id_str(k: str, d: str = "", _src: dict = inp_d) -> str:
                v = _src.get(k, d)
                return v if isinstance(v, str) else d

            def _id_int(k: str, d: int = 0, _src: dict = inp_d) -> int:
                v = _src.get(k, d)
                return v if isinstance(v, int) and not isinstance(v, bool) else d

            def _id_int_or_none(k: str, _src: dict = inp_d) -> int | None:
                v = _src.get(k)
                if isinstance(v, int) and not isinstance(v, bool):
                    return v
                return None

            def _id_str_or_none(k: str, _src: dict = inp_d) -> str | None:
                v = _src.get(k)
                return v if isinstance(v, str) else None

            def _id_bool(k: str, d: bool = False, _src: dict = inp_d) -> bool:
                v = _src.get(k, d)
                return v if isinstance(v, bool) else d

            def _id_bool_or_none(k: str, _src: dict = inp_d) -> bool | None:
                v = _src.get(k)
                return v if isinstance(v, bool) else None

            _sigs_raw = inp_d.get("signatures", [])
            _sigs_list: list[str] = [s for s in _sigs_raw if isinstance(s, str)] if isinstance(_sigs_raw, list) else []

            _pkeys_raw = inp_d.get("public_keys", [])
            _pkeys_list: list[Key | HDKey | bytes | str] = (
                [s for s in _pkeys_raw if isinstance(s, str)] if isinstance(_pkeys_raw, list) else []
            )

            inp = Input(
                prev_txid=bytes.fromhex(_id_str("prev_txid")),
                output_n=_id_int("output_n"),
                keys=_pkeys_list,
                signatures=[bytes.fromhex(s) for s in _sigs_list],
                public_hash=bytes.fromhex(_id_str("public_hash")),
                unlocking_script=bytes.fromhex(_id_str("unlocking_script")),
                unlocking_script_unsigned=bytes.fromhex(_id_str("unlocking_script_unsigned")),
                script_type=_id_str_or_none("script_type"),
                address=_id_str("address"),
                sequence=_id_int("sequence", 0xFFFFFFFF),
                compressed=_id_bool_or_none("compressed"),
                sigs_required=_id_int_or_none("sigs_required"),
                sort=_id_bool("sort", False),
                index_n=_id_int("index_n", 0),
                value=_id_int("value", 0),
                double_spend=_id_bool("double_spend", False),
                locktime_cltv=_id_int_or_none("locktime_cltv"),
                witness_type=_id_str_or_none("witness_type"),
                encoding=_id_str_or_none("encoding"),
                strict=False,
                network=_str("network", DEFAULT_NETWORK),
            )
            inputs.append(inp)

        outputs: list[Output] = []
        _outputs_raw = data.get("outputs", [])
        _outputs_list: list[dict[str, str | int | bool | list[str] | None]] = (
            _outputs_raw if isinstance(_outputs_raw, list) else []
        )
        for out_d in _outputs_list:
            if not isinstance(out_d, dict):
                continue

            def _od_str(k: str, d: str = "", _src: dict = out_d) -> str:
                v = _src.get(k, d)
                return v if isinstance(v, str) else d

            def _od_int(k: str, d: int = 0, _src: dict = out_d) -> int:
                v = _src.get(k, d)
                return v if isinstance(v, int) and not isinstance(v, bool) else d

            def _od_int_or_none(k: str, _src: dict = out_d) -> int | None:
                v = _src.get(k)
                if isinstance(v, int) and not isinstance(v, bool):
                    return v
                return None

            def _od_str_or_none(k: str, _src: dict = out_d) -> str | None:
                v = _src.get(k)
                return v if isinstance(v, str) else None

            def _od_bool(k: str, d: bool = False, _src: dict = out_d) -> bool:
                v = _src.get(k, d)
                return v if isinstance(v, bool) else d

            out = Output(
                value=_od_int("value"),
                address=_od_str("address"),
                public_hash=bytes.fromhex(_od_str("public_hash")),
                public_key=bytes.fromhex(_od_str("public_key")),
                lock_script=bytes.fromhex(_od_str("script")),
                spent=_od_bool("spent", False),
                output_n=_od_int("output_n", 0),
                script_type=_od_str_or_none("script_type"),
                encoding=_od_str_or_none("encoding"),
                spending_txid=_od_str("spending_txid"),
                spending_index_n=_od_int_or_none("spending_index_n"),
                strict=False,
                network=_str("network", DEFAULT_NETWORK),
            )
            outputs.append(out)

        flag_val = data.get("flag")
        flag: str | None = (
            chr(flag_val)
            if isinstance(flag_val, int) and not isinstance(flag_val, bool)
            else (flag_val if isinstance(flag_val, str) else None)
        )

        date_val = data.get("date")
        date_parsed: datetime | None = None
        if isinstance(date_val, str):
            try:
                date_parsed = datetime.fromisoformat(date_val)
            except (ValueError, TypeError):
                date_parsed = None
        elif isinstance(date_val, datetime):
            date_parsed = date_val

        return cls(
            inputs=inputs,
            outputs=outputs,
            locktime=_int("locktime", 0),
            version=_int("version", 1),
            network=_str("network", DEFAULT_NETWORK),
            fee=_int_or_none("fee"),
            fee_per_kb=_int_or_none("fee_per_kb"),
            size=_int_or_none("size"),
            txid=_str("txid"),
            txhash=_str("txhash"),
            date=date_parsed,
            confirmations=_int_or_none("confirmations"),
            block_height=_int_or_none("block_height"),
            block_hash=_str_or_none("block_hash"),
            input_total=_int("input_total", 0),
            output_total=_int("output_total", 0),
            rawtx=bytes.fromhex(raw_hex_str) if raw_hex_str else b"",
            status=_str("status", "new"),
            coinbase=_bool("coinbase", False),
            verified=_bool("verified", False),
            witness_type=_str("witness_type", "legacy"),
            flag=flag,
        )

    @staticmethod
    def load(txid: str | None = None, filename: str | None = None) -> TransactionMixin:
        """Load transaction object from file which has been stored with the :func:`save` method.

        Specify transaction ID or filename.

        :param txid: Transaction ID. Transaction object will be read from .fluxwallet datadir
        :type txid: str
        :param filename: Name of transaction object file
        :type filename: str
        :return Transaction:
        """
        if not filename and not txid:
            raise TransactionError("Please supply filename or txid")
        if not filename and txid:
            p = Path(FW_DATA_DIR, f"{txid}.tx")
        elif filename:
            p = Path(filename)
            if not p.parent or str(p.parent) == ".":
                p = Path(FW_DATA_DIR, filename)
        else:
            raise TransactionError("Please supply filename or txid")
        with p.open("rb") as f:
            data = msgpack.unpack(f, raw=False)
        return FluxTransaction.from_dict(data)

    def save(self, filename: str | None = None) -> None:
        """Store transaction object as file, so it can be imported in fluxwallet later with the :func:`load` method.

        :param filename: Location and name of file, leave empty to store transaction in
            fluxwallet data directory: .fluxwallet/<transaction_id.tx)
        :type filename: str
        :return:
        """
        if not filename:
            p = Path(FW_DATA_DIR, f"{self.txid}.tx")
        else:
            p = Path(filename)
            if not p.parent or str(p.parent) == ".":
                p = Path(FW_DATA_DIR, filename)
        data = self.as_dict()
        _date_val = data.get("date")
        if isinstance(_date_val, datetime):
            data["date"] = _date_val.isoformat()
        with p.open("wb") as f:
            msgpack.pack(data, f, use_bin_type=True)

    def as_dict(
        self,
    ) -> dict[
        str,
        str | int | bool | list[dict[str, str | int | bool | list[str] | None]] | datetime | None,
    ]:
        """
        Return Json dictionary with transaction information: Inputs, outputs, version and locktime

        :return dict:
        """

        inputs: list[dict[str, str | int | bool | list[str] | None]] = []
        outputs: list[dict[str, str | int | bool | list[str] | None]] = []
        for i in self.inputs:
            inputs.append(i.as_dict())
        for o in self.outputs:
            outputs.append(o.as_dict())
        return {
            "txid": self.txid,
            "date": self.date,
            "network": self.network.name,
            "witness_type": self.witness_type,
            "coinbase": self.coinbase,
            "flag": None if not self.flag else ord(self.flag),
            "txhash": self.txhash,
            "confirmations": self.confirmations,
            "block_height": self.block_height,
            "block_hash": self.block_hash,
            "fee": self.fee,
            "fee_per_kb": self.fee_per_kb,
            "inputs": inputs,
            "outputs": outputs,
            "input_total": self.input_total,
            "output_total": self.output_total,
            "version": self.version_int,
            "locktime": self.locktime,
            "raw": self.raw_hex(),
            "size": self.size,
            "vsize": self.vsize,
            "verified": self.verified,
            "status": self.status,
        }

    def as_json(self) -> str:
        """Get current key as json formatted string.

        :return str:
        """
        adict = self.as_dict()
        return json.dumps(adict, indent=4, default=str)

    def info(self) -> None:
        """Prints transaction information to standard output."""

        print(f"Transaction {self.txid}")
        print(f"Date: {self.date}")
        print(f"Network: {self.network.name}")
        if self.locktime and self.locktime != 0xFFFFFFFF:
            if self.locktime < 500000000:
                print(f"Locktime: Until block {self.locktime}")
            else:
                print(f"Locktime: Until {datetime.fromtimestamp(self.locktime, tz=None)} UTC")
        print(f"Version: {self.version_int}")
        print(f"Witness type: {self.witness_type}")
        print(f"Status: {self.status}")
        print(f"Verified: {self.verified}")
        print("Inputs")
        replace_by_fee: bool = False
        for ti in self.inputs:
            print(
                "-",
                ti.address,
                Value.from_satoshi(ti.value, network=self.network).format_str(1),
                ti.prev_txid.hex(),
                ti.output_n_int,
            )
            validstr: str = "not validated"
            if ti.valid:
                validstr = "valid"
            elif ti.valid is False:
                validstr = "invalid"
            print(
                f"  {ti.witness_type} {ti.script_type}; sigs: {len(ti.signatures)}"
                f" ({ti.sigs_required or 0}-of-{len(ti.keys)}) {validstr}"
            )
            if ti.sequence <= SEQUENCE_REPLACE_BY_FEE:
                replace_by_fee = True
            if ti.locktime_cltv:
                if ti.locktime_cltv & SEQUENCE_LOCKTIME_TYPE_FLAG:
                    cltv_seconds = BIP68_LOCKTIME_GRANULARITY_SECONDS * (ti.locktime_cltv - SEQUENCE_LOCKTIME_TYPE_FLAG)
                    print(f"  Check Locktime Verify (CLTV) for {cltv_seconds} seconds")
                else:
                    print(f"  Check Locktime Verify (CLTV) for {ti.locktime_cltv} blocks")

        print("Outputs")
        for to in self.outputs:
            if to.script_type == "nulldata":
                print("- NULLDATA ", to.lock_script[2:])
            else:
                spent_str: str = ""
                if to.spent:
                    spent_str = "S"
                elif to.spent is False:
                    spent_str = "U"
                print(
                    "-",
                    to.address,
                    Value.from_satoshi(to.value, network=self.network).format_str(1),
                    to.script_type,
                    spent_str,
                )
        if replace_by_fee:
            print("Replace by fee: Enabled")
        print(f"Size: {self.size}")
        print(f"Vsize: {self.vsize}")
        print(f"Fee: {self.fee}")
        print(f"Confirmations: {self.confirmations}")
        print(f"Block: {self.block_height}")

    def set_locktime_blocks(self, blocks: int) -> None:
        """Set nLocktime, a transaction level absolute lock time in blocks using the transaction sequence field.

        So for example if you set this value to 600000 the transaction will only be valid after block 600000.

        :param blocks: Transaction is valid after supplied block number. Value must be between 0 and 500000000. Zero
            means no locktime.
        :type blocks: int
        :return:
        """
        if blocks == 0 or blocks == 0xFFFFFFFF:
            self.locktime = 0xFFFFFFFF
            self.sign(replace_signatures=True)
            self.verify()
            return
        if blocks > 500000000:
            raise TransactionError(f"Number of locktime blocks must be below {500000000}")
        self.locktime = blocks
        if blocks != 0 and blocks != 0xFFFFFFFF:
            for i in self.inputs:
                if i.sequence == 0xFFFFFFFF:
                    i.sequence = 0xFFFFFFFD
        self.sign_and_update()

    def set_locktime_time(self, timestamp: int) -> None:
        """Set nLocktime, a transaction level absolute lock time in timestamp using the transaction sequence field.

        :param timestamp: Transaction is valid after the given timestamp. Value must be between 500000000 and 0xfffffffe
        :return:
        """
        if timestamp == 0 or timestamp == 0xFFFFFFFF:
            self.locktime = 0xFFFFFFFF
            self.sign(replace_signatures=True)
            self.verify()
            return

        if timestamp <= 500000000:
            raise TransactionError(f"Timestamp must have a value higher then {500000000}")
        if timestamp > 0xFFFFFFFE:
            raise TransactionError(f"Timestamp must have a value lower then {0xFFFFFFFE}")
        self.locktime = timestamp

        # Input sequence value must be below 0xffffffff
        for i in self.inputs:
            if i.sequence == 0xFFFFFFFF:
                i.sequence = 0xFFFFFFFD
        self.sign_and_update()

    def validate(self) -> bool:
        """Validate transaction against Flux consensus rules before broadcast."""
        # Size limit
        raw = self.raw()
        if len(raw) > MAX_TX_SIZE_AFTER_SAPLING:
            raise TransactionError(f"Transaction size {len(raw)} exceeds limit {MAX_TX_SIZE_AFTER_SAPLING}")

        # Output value bounds + overflow
        total_output: int = 0
        for out in self.outputs:
            if out.value < 0:
                raise TransactionError("Output value cannot be negative")
            if out.value > MAX_MONEY:
                raise TransactionError(f"Output value {out.value} exceeds MAX_MONEY")
            total_output += out.value
            if total_output > MAX_MONEY:
                raise TransactionError("Total output value exceeds MAX_MONEY")

        # Duplicate input detection
        seen: set[tuple[str, int]] = set()
        for inp in self.inputs:
            key = (inp.prev_txid.hex(), inp.output_n_int)
            if key in seen:
                raise TransactionError(f"Duplicate input: {key[0][:16]}...:{key[1]}")
            seen.add(key)

        # Non-coinbase null prevout check
        if not self.coinbase:
            for inp in self.inputs:
                if inp.prev_txid == NULL_PREVOUT:
                    raise TransactionError("Non-coinbase input has null prevout")

        # Sigop count
        sigops = self.count_sigops()
        if sigops > MAX_STANDARD_TX_SIGOPS:
            raise TransactionError(f"Sigop count {sigops} exceeds limit {MAX_STANDARD_TX_SIGOPS}")

        return True

    def count_sigops(self) -> int:
        """Count signature operations in all scripts."""
        count = 0
        for inp in self.inputs:
            if inp.script:
                count += _count_script_sigops(inp.script.raw if hasattr(inp.script, "raw") else inp.script)
        for out in self.outputs:
            if out.lock_script:
                count += _count_script_sigops(out.lock_script)
        return count

    def sign(
        self,
        keys: list[HDKey | Key | bytes] | HDKey | Key | bytes | None = None,
        index_n: int | None = None,
        multisig_key_n: int | None = None,
        hash_type: int = SIGHASH_ALL,
        fail_on_unknown_key: bool = True,
        replace_signatures: bool = False,
    ) -> None:
        """Sign the transaction input with provided private key.

        :param keys: A private key or list of private keys
        :type keys: HDKey, Key, bytes, list
        :param index_n: Index of transaction input. Leave empty to sign all inputs
        :type index_n: int
        :param multisig_key_n: Index number of key for multisig input for segwit transactions. Leave empty if not known.
            If not specified all possibilities will be checked
        :type multisig_key_n: int
        :param hash_type: Specific hash type, default is SIGHASH_ALL
        :type hash_type: int
        :param fail_on_unknown_key: Method fails if public key from signature is not found in public key list
        :type fail_on_unknown_key: bool
        :param replace_signatures: Replace signature with new one if already signed.
        :type replace_signatures: bool
        :return None:
        """

        if index_n is None:
            tids: range | list[int] = range(len(self.inputs))
        else:
            tids = [index_n]

        if keys is None:
            keys = []
        elif not isinstance(keys, list):
            keys = [keys]

        for tid in tids:
            n_signs: int = 0
            _raw_compressed = self.inputs[tid].compressed
            _tid_compressed: bool = _raw_compressed if isinstance(_raw_compressed, bool) else True
            tid_keys: list[HDKey | Key] = [
                k
                if isinstance(k, (HDKey, Key))
                else Key(
                    k if isinstance(k, (bytes, str)) else b"",
                    compressed=_tid_compressed,
                )
                for k in keys
            ]
            for k in self.inputs[tid].keys:
                if k.is_private and k not in tid_keys:
                    tid_keys.append(k)
            # If input does not contain any keys, try using provided keys
            if not self.inputs[tid].keys:
                self.inputs[tid].keys = tid_keys
                self.inputs[tid].update_scripts(hash_type=hash_type)
            if self.inputs[tid].script_type == "coinbase":
                raise TransactionError("Can not sign coinbase transactions")
            pub_key_list: list[bytes] = [k.public_byte or b"" for k in self.inputs[tid].keys]
            n_total_sigs: int = len(self.inputs[tid].keys)
            _empty_sigs: list[Signature | str] = ["" for _ in range(n_total_sigs)]
            sig_domain: list[Signature | str] = _empty_sigs

            # this should store on the tx
            txid: bytes = self.signature_hash(tid, hash_type=hash_type, witness_type=self.inputs[tid].witness_type)
            for key in tid_keys:
                # Check if signature signs known key and is not already in list
                if key.public_byte not in pub_key_list:
                    if fail_on_unknown_key:
                        raise TransactionError(f"This key does not sign any known key: {key.public_hex}")
                    _logger.info(f"This key does not sign any known key: {key.public_hex}")
                    continue
                if not replace_signatures and key in [x.public_key for x in self.inputs[tid].signatures]:
                    _logger.info(f"Key {key.public_hex} already signed")
                    break

                if not key.private_byte:
                    raise TransactionError("Please provide a valid private key to sign the transaction")
                sig: Signature = sign(txid, key)
                newsig_pos: int = pub_key_list.index(key.public_byte)
                sig_domain[newsig_pos] = sig
                n_signs += 1

            if not n_signs:
                break

            # Add already known signatures on correct position
            n_sigs_to_insert: int = len(self.inputs[tid].signatures)
            for sig in self.inputs[tid].signatures:
                if sig.public_key and sig.public_key.public_byte is not None:
                    newsig_pos = pub_key_list.index(sig.public_key.public_byte)
                    if sig_domain[newsig_pos] == "":
                        sig_domain[newsig_pos] = sig
                        n_sigs_to_insert -= 1
                else:
                    placed: bool = False
                    for pos, pub in enumerate(pub_key_list):
                        if sig_domain[pos] != "":
                            continue
                        if sig.verify(txid, HDKey(pub)):
                            sig_domain[pos] = sig
                            n_sigs_to_insert -= 1
                            placed = True
                            break
                    if not placed:
                        free_positions: list[int] = [i for i, s in enumerate(sig_domain) if s == ""]
                        if free_positions:
                            sig_domain[free_positions[0]] = sig
                            n_sigs_to_insert -= 1
            if n_sigs_to_insert:
                _logger.info("Some signatures are replaced with the signatures of the provided keys")
            self.inputs[tid].signatures = [s for s in sig_domain if isinstance(s, Signature)]
            self.inputs[tid].update_scripts(hash_type)

        self.validate()

    def sign_and_update(self, index_n: int | None = None) -> None:
        """Update transaction ID and resign. Use if some properties of the transaction changed.

        :param index_n: Index of transaction input. Leave empty to sign all inputs
        :type index_n: int
        :return:
        """

        self.version = self.version_int.to_bytes(4, "big")
        self.sign(index_n=index_n, replace_signatures=True)
        self.txid = self.signature_hash()[::-1].hex()
        self.size = len(self.raw())
        self.calc_weight_units()
        self.update_totals()
        if self.fee and self.vsize:
            self.fee_per_kb = int((self.fee / float(self.vsize)) * 1000)

    def add_input(
        self,
        prev_txid: bytes | str,
        output_n: bytes | int,
        keys: SequenceABC[Key | HDKey | bytes | str] | Key | HDKey | bytes | str | None = None,
        signatures: SequenceABC[Signature | bytes | str] | Signature | bytes | str | None = None,
        public_hash: bytes = b"",
        unlocking_script: bytes | str = b"",
        unlocking_script_unsigned: bytes | str | None = None,
        script_type: str | None = None,
        address: str | Address = "",
        sequence: int | bytes = 0xFFFFFFFF,
        compressed: bool = True,
        sigs_required: int | None = None,
        sort: bool = False,
        index_n: int | None = None,
        value: int | None = None,
        double_spend: bool = False,
        locktime_cltv: int | None = None,
        key_path: str | list[int] = "",
        witness_type: str | None = None,
        witnesses: list[bytes] | list[str] | bytes | None = None,
        encoding: str | None = None,
        strict: bool = True,
    ) -> int:
        """Add input to this transaction.

        Wrapper for append method of Input class.

        :param prev_txid: Transaction hash of the UTXO (previous output) which will be spent.
        :type prev_txid: bytes, hexstring
        :param output_n: Output number in previous transaction.
        :type output_n: bytes, int
        :param keys: Public keys can be provided to construct an Unlocking script. Optional
        :type keys: bytes, str
        :param signatures: Add signatures to input if already known
        :type signatures: bytes, str
        :param public_hash: Specify public hash from key or redeemscript if key is not available
        :type public_hash: bytes
        :param unlocking_script: Unlocking script (scriptSig) to prove ownership. Optional
        :type unlocking_script: bytes, hexstring
        :param unlocking_script_unsigned: Unsigned version of the unlocking script, used as the signing template
        :type unlocking_script_unsigned: bytes, str
        :param script_type: Type of unlocking script used, i.e. p2pkh or p2sh_multisig. Default is p2pkh
        :type script_type: str
        :param address: Specify address of input if known, default is to derive from key or scripts
        :type address: str, Address
        :param sequence: Sequence part of input, used for timelocked transactions
        :type sequence: int, bytes
        :param compressed: Use compressed or uncompressed public keys. Default is compressed
        :type compressed: bool
        :param sigs_required: Number of signatures required for a p2sh_multisig unlocking script
        :param sigs_required: int
        :param sort: Sort public keys according to BIP0045 standard. Default is False to avoid
            unexpected change of key order.
        :type sort: boolean
        :param index_n: Index number of position in transaction, leave empty to add input to end of inputs list
        :type index_n: int
        :param value: Value of input
        :type value: int
        :param double_spend: True if double spend is detected, depends on which service provider is selected
        :type double_spend: bool
        :param locktime_cltv: Check Lock Time Verify value. Script level absolute time lock for this input
        :type locktime_cltv: int
        :param key_path: Key path of input key as BIP32 string or list
        :type key_path: str, list
        :param witness_type: Specify witness/signature position: 'segwit' or 'legacy'. Determine
            from script, address or encoding if not specified.
        :type witness_type: str
        :param witnesses: List of witnesses for inputs, used for segwit transactions for instance.
        :type witnesses: list of bytes, list of str
        :param encoding: Address encoding used. For example bech32/base32 or base58. Leave empty
            to derive from script or script type
        :type encoding: str
        :param strict: Raise exception when input is malformed or incomplete
        :type strict: bool

        :return int: Transaction index number (index_n)
        """

        if index_n is None:
            index_n = len(self.inputs)
        if isinstance(sequence, bytes):
            sequence_int: int = int.from_bytes(sequence, "little")
        else:
            sequence_int = sequence

        if self.version == b"\x00\x00\x00\x01" and 0 < sequence_int < SEQUENCE_LOCKTIME_DISABLE_FLAG:
            self.version = b"\x00\x00\x00\x02"
            self.version_int = 2

        if witness_type is None:
            witness_type = self.witness_type

        inp = Input(
            prev_txid=prev_txid,
            output_n=output_n,
            keys=keys,
            signatures=signatures,
            public_hash=public_hash,
            unlocking_script=unlocking_script,
            unlocking_script_unsigned=unlocking_script_unsigned,
            script_type=script_type,
            address=address,
            sequence=sequence,
            compressed=compressed,
            sigs_required=sigs_required,
            sort=sort,
            index_n=index_n,
            value=value if value is not None else 0,
            double_spend=double_spend,
            locktime_cltv=locktime_cltv,
            key_path=key_path,
            witness_type=witness_type,
            witnesses=witnesses,
            encoding=encoding,
            strict=strict,
            network=self.network.name,
        )
        for existing in self.inputs:
            if existing.prev_txid == inp.prev_txid and existing.output_n == inp.output_n:
                raise TransactionError(f"Duplicate input: {inp.prev_txid}:{inp.output_n}")
        self.inputs.append(inp)
        return index_n

    def add_output(
        self,
        value: int,
        address: str | Address = "",
        public_hash: bytes | str = b"",
        public_key: bytes | str = b"",
        lock_script: bytes | str = b"",
        spent: bool = False,
        output_n: int | None = None,
        encoding: str | None = None,
        spending_txid: str | None = None,
        spending_index_n: int | None = None,
        strict: bool = True,
    ) -> int:
        """Add an output to this transaction.

        Wrapper for the append method of the Output class.

        :param value: Value of output in the smallest denominator of currency, for example satoshi's for bitcoins
        :type value: int
        :param address: Destination address of output. Leave empty to derive from other attributes you provide.
        :type address: str, Address
        :param public_hash: Hash of public key or script
        :type public_hash: bytes, str
        :param public_key: Destination public key
        :type public_key: bytes, str
        :param lock_script: Locking script of output. If not provided a default unlocking script will be provided with a
            public key hash.
        :type lock_script: bytes, str
        :param spent: Has output been spent in new transaction?
        :type spent: bool, None
        :param output_n: Index number of output in transaction
        :type output_n: int
        :param encoding: Address encoding used. For example bech32/base32 or base58. Leave empty for to derive from
            script or script type
        :type encoding: str
        :param spending_txid: Transaction hash of input spending this transaction output
        :type spending_txid: str
        :param spending_index_n: Index number of input spending this transaction output
        :type spending_index_n: int
        :param strict: Raise exception when output is malformed or incomplete
        :type strict: bool
        :return int: Transaction output number (output_n)
        """

        lock_script = to_bytes(lock_script)
        if output_n is None:
            output_n = len(self.outputs)
        if not float(value).is_integer():
            raise TransactionError("Output must be of type integer and contain no decimals")
        if lock_script.startswith(b"\x6a") and value != 0:
            raise TransactionError("Output value for OP_RETURN script must be 0")
        self.outputs.append(
            Output(
                value=int(value),
                address=address,
                public_hash=public_hash,
                public_key=public_key,
                lock_script=lock_script,
                spent=spent,
                output_n=output_n,
                encoding=encoding,
                spending_txid=spending_txid if spending_txid is not None else "",
                spending_index_n=spending_index_n,
                strict=strict,
                network=self.network.name,
            )
        )
        return output_n

    def merge_transaction(self, transaction: TransactionProtocol) -> None:
        """Merge this transaction with provided Transaction object.

        Add all inputs and outputs of a transaction to this Transaction object. Because the transaction signature
        changes with this operation, the transaction inputs need to be signed again.

        Can be used to implement CoinJoin. Where two or more unrelated Transactions are merged into 1 transaction to
        safe fees and increase privacy.

        :param transaction: The transaction to be merged
        :type transaction: Transaction
        """
        self.inputs += transaction.inputs
        self.outputs += transaction.outputs
        self.shuffle()
        self.update_totals()
        self.sign_and_update()

    def estimate_size(self, number_of_change_outputs: int = 0) -> int:
        """Get estimated vsize for current transaction based on transaction type and number of inputs and outputs.

        :param number_of_change_outputs: Number of change outputs, default is 0
        :type number_of_change_outputs: int
        :return int: Estimated transaction size
        """

        # if self.input_total and self.output_total + self.fee == self.input_total:
        #     add_change_output = False
        est_size: int = 10
        # Default to one standard p2pkh input when estimating before inputs are added
        if not self.inputs:
            est_size += 125
        for inp in self.inputs:
            est_size += 40
            scr_size: int = 0
            if inp.unlocking_script and len(inp.signatures) >= inp.sigs_required:
                scr_size += len(varstr(inp.unlocking_script))
            else:
                if inp.script_type == "sig_pubkey":
                    scr_size += 107
                    if not inp.compressed:
                        scr_size += 33
                elif inp.script_type == "p2sh_multisig":
                    scr_size += 9 + (len(inp.keys) * 34) + (inp.sigs_required * 72)
                elif inp.script_type == "signature":
                    scr_size += 9 + 72
                else:
                    raise TransactionError(
                        f"Unknown input script type {inp.script_type} cannot estimate transaction size"
                    )
            est_size += scr_size
        for outp in self.outputs:
            est_size += 8
            if outp.lock_script:
                est_size += len(varstr(outp.lock_script))
            else:
                raise TransactionError(f"Need locking script for output {outp.output_n} to estimate size")
        if number_of_change_outputs:
            is_multisig: bool = bool(self.inputs and self.inputs[0].script_type == "p2sh_multisig")
            co_size: int = 8
            co_size += 24 if is_multisig else 26
            est_size += number_of_change_outputs * co_size
        self.size = est_size
        self.vsize = est_size
        return est_size

    def calc_weight_units(self) -> int | None:
        """Calculate weight units and vsize for this Transaction.

        :return int:
        """
        if not self.size:
            return None
        wu: int = self.size * 4
        self.vsize = math.ceil(wu / 4)
        return wu

    @property
    def weight_units(self) -> int | None:
        return self.calc_weight_units()

    def calculate_fee(self) -> int:
        """Get fee for this transaction in the smallest denominator (i.e. Satoshi) based on its size and the
        transaction.fee_per_kb value.

        :return int: Estimated transaction fee
        """

        if not self.fee_per_kb:
            raise TransactionError("Cannot calculate transaction fees: transaction.fee_per_kb is not set")
        if self.fee_per_kb < self.network.fee_min:
            self.fee_per_kb = self.network.fee_min
        elif self.fee_per_kb > self.network.fee_max:
            self.fee_per_kb = self.network.fee_max
        if not self.vsize:
            self.estimate_size()
        _vsize: int = self.vsize if self.vsize else 1
        fee: int = int(_vsize / 1000.0 * self.fee_per_kb)
        return fee

    def update_totals(self) -> None:
        """Update input_total, output_total and fee according to inputs and outputs of this transaction.

        :return int:
        """

        self.input_total = sum([i.value for i in self.inputs if i.value])
        self.output_total = sum([o.value for o in self.outputs if o.value])
        if self.coinbase:
            self.input_total = self.output_total
        # self.fee = 0
        if self.input_total:
            self.fee = self.input_total - self.output_total
            if self.fee < 0 and not self.coinbase:
                raise TransactionError(
                    f"Negative fee: outputs ({self.output_total}) exceed inputs ({self.input_total})"
                )
            if self.vsize:
                self.fee_per_kb = int((self.fee / float(self.vsize)) * 1000)

    def shuffle_inputs(self) -> None:
        """Shuffle transaction inputs in random order.

        :return:
        """
        secrets.SystemRandom().shuffle(self.inputs)
        for idx, o in enumerate(self.inputs):
            o.index_n = idx

    def shuffle_outputs(self) -> None:
        """Shuffle transaction outputs in random order.

        :return:
        """
        secrets.SystemRandom().shuffle(self.outputs)
        for idx, o in enumerate(self.outputs):
            o.output_n = idx

    def shuffle(self) -> None:
        """Shuffle transaction inputs and outputs in random order.

        :return:
        """
        self.shuffle_inputs()
        self.shuffle_outputs()

    def raw_hex(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        witness_type: str | None = None,
    ) -> str:
        """Wrapper for raw() method. Return current raw transaction hex.

        :param sign_id: Create raw transaction which can be signed by transaction with this input ID
        :type sign_id: int
        :param hash_type: Specific hash type, default is SIGHASH_ALL
        :type hash_type: int
        :param witness_type: Serialize transaction with other witness type then default. Use to create legacy raw
            transaction for segwit transaction to create transaction signature ID's
        :type witness_type: str
        :return hexstring:
        """

        return self.raw(sign_id, hash_type=hash_type, witness_type=witness_type).hex()

    def verify(self) -> bool:
        """Verify all inputs of a transaction, check if signatures match public key.

        Does not check if UTXO is valid or has already been spent

        :return bool: True if enough signatures provided and if all signatures are valid
        """

        self.verified = False
        for inp in self.inputs:
            try:
                transaction_hash: bytes = self.signature_hash(inp.index_n, inp.hash_type, inp.witness_type)
            except TransactionError as e:
                _logger.info(f"Could not create transaction hash. Error: {e}")
                return False
            if not transaction_hash:
                _logger.info("Need at least 1 key to create segwit transaction signature")
                return False
            self.verified = inp.verify(transaction_hash)
            if not self.verified:
                return False

        self.verified = True
        return True

    def signature_hash(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        witness_type: str | None = None,
    ) -> bytes:
        raise NotImplementedError

    def raw(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        **kwargs: str | int | None,
    ) -> bytes:
        raise NotImplementedError

    @classmethod
    def parse_bytesio(
        cls,
        rawtx: BytesIO,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> TransactionMixin:
        raise NotImplementedError


class FluxTransaction(TransactionMixin):
    @classmethod
    def parse(
        cls,
        rawtx: BytesIO | bytes | str,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> FluxTransaction:
        """Parse a raw transaction and create a Transaction object.

        :param rawtx: Raw transaction string
        :type rawtx: BytesIO, bytes, str
        :param strict: Raise exception when transaction is malformed, incomplete or not understood
        :type strict: bool
        :param network: Network, leave empty for default network
        :type network: str, Network
        :return Transaction:
        """
        if isinstance(rawtx, bytes):
            rawtx = BytesIO(rawtx)
        elif isinstance(rawtx, str):
            rawtx = BytesIO(bytes.fromhex(rawtx))

        return cls.parse_bytesio(rawtx, strict, network)

    @classmethod
    def parse_hex(
        cls,
        rawtx: str,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> FluxTransaction:
        """Parse a raw hexadecimal transaction and create a Transaction object. Wrapper for the :func:`parse_bytesio`
        method.

        :param rawtx: Raw transaction hexadecimal string
        :type rawtx: str
        :param strict: Raise exception when transaction is malformed, incomplete or not understood
        :type strict: bool
        :param network: Network, leave empty for default network
        :type network: str, Network
        :return Transaction:
        """

        return cls.parse_bytesio(BytesIO(bytes.fromhex(rawtx)), strict, network)

    @classmethod
    def parse_bytes(
        cls,
        rawtx: bytes,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> FluxTransaction:
        """Parse a raw bytes transaction and create a Transaction object.  Wrapper for the :func:`parse_bytesio` method.

        :param rawtx: Raw transaction hexadecimal string
        :type rawtx: bytes
        :param strict: Raise exception when transaction is malformed, incomplete or not understood
        :type strict: bool
        :param network: Network, leave empty for default network
        :type network: str, Network
        :return Transaction:
        """

        return cls.parse(BytesIO(rawtx), strict, network)

    @classmethod
    def parse_input_bytes(cls, raw: BytesIO) -> TxIn:
        prev_hash: bytes = raw.read(32)

        if len(prev_hash) != 32:
            raise TransactionError("Input transaction hash not found. Probably malformed raw transaction")

        output_n: bytes = raw.read(4)
        output_n_int: int = int.from_bytes(output_n, "little")
        unlocking_script_size: int = read_varbyteint(raw)
        unlocking_script: bytes = raw.read(unlocking_script_size)
        sequence_number: bytes = raw.read(4)
        sequence_number_int: int = int.from_bytes(sequence_number, "little")

        outpoint: OutPoint = OutPoint(prev_hash, output_n_int)
        scriptSig: FluxScript = FluxScript.from_bytes(unlocking_script)

        return TxIn(outpoint, scriptSig, sequence_number_int)

    @classmethod
    def parse_output_bytes(cls, raw: BytesIO) -> TxOut:
        value: int = int.from_bytes(raw.read(8)[::-1], "big")
        lock_script_size: int = read_varbyteint(raw)
        lock_script: bytes = raw.read(lock_script_size)

        script: FluxScript = FluxScript.from_bytes(lock_script)

        return TxOut(value, script)

    @classmethod
    def parse_bytesio(
        cls,
        rawtx: BytesIO,
        strict: bool = True,
        network: str | Network = DEFAULT_NETWORK,
    ) -> FluxTransaction:
        """Parse a raw transaction and create a Transaction object.

        :param rawtx: Raw transaction string
        :type rawtx: BytesIO
        :param strict: Raise exception when transaction is malformed, incomplete or not understood
        :type strict: bool
        :param network: Network, leave empty for default network
        :type network: str, Network
        :return Transaction:
        """

        _coinbase: bool = False
        _flag: str | None = None
        _witness_type: str = "legacy"

        raw_bytes: bytes = b""

        try:
            pos_start: int = rawtx.tell()
        except AttributeError as err:
            raise TransactionError(
                "Provide raw transaction as BytesIO. Use parse, parse_bytes, parse_hex to parse other data types"
            ) from err

        header: int = int.from_bytes(rawtx.read(4), "little")
        overwintered: bool = bool(header >> 31)

        if overwintered:
            version: int = header & 0x7FFFFFFF
            _version_group_id: str = rawtx.read(4)[::-1].hex()

        else:
            version = header

        n_inputs: int = read_varbyteint(rawtx)

        inputs: list[TxIn] = []

        for _n in range(n_inputs):
            inp: TxIn = FluxTransaction.parse_input_bytes(rawtx)
            # if inp.prevout.txid == 32 * b"\0":
            #     coinbase = True

            inputs.append(inp)

        outputs: list[TxOut] = []
        output_total: int = 0
        n_outputs: int = read_varbyteint(rawtx)
        for _n in range(n_outputs):
            out: TxOut = FluxTransaction.parse_output_bytes(rawtx)
            outputs.append(out)
            output_total += out.nValue
        if not outputs:
            raise TransactionError("Error no outputs found in this transaction")

        locktime: int = int.from_bytes(rawtx.read(4), "little")
        expiry_height: int = int.from_bytes(rawtx.read(4), "little")
        value_balance: bytes = rawtx.read(8)  # should be all zero
        _value_balance_int: int = int.from_bytes(value_balance, "little")
        _sighash: bytes = rawtx.read(4)[:-1]

        pos_end: int = rawtx.tell()
        raw_len: int = pos_end - pos_start
        rawtx.seek(pos_start)
        raw_bytes = rawtx.read(raw_len)
        _txhash: bytes | str = double_sha256(raw_bytes)
        _txhash_bytes: bytes = _txhash if is_bytes(_txhash) else bytes.fromhex(_txhash)
        txid: str = _txhash_bytes[::-1].hex()

        # Convert TxIn/TxOut to Input/Output objects
        parsed_inputs: list[Input] = []
        for inp in inputs:
            parsed_inputs.append(
                Input(
                    prev_txid=inp.prevout.txid,
                    output_n=inp.prevout.n,
                    unlocking_script=bytes(inp.scriptSig),
                    sequence=inp.nSequence,
                    witness_type="legacy",
                    network=network,
                )
            )

        parsed_outputs: list[Output] = []
        for n, out in enumerate(outputs):
            parsed_outputs.append(
                Output(
                    value=out.nValue,
                    lock_script=bytes(out.script),
                    network=network,
                    output_n=n,
                    strict=strict,
                )
            )

        _net_str: str = network if isinstance(network, str) else network.name
        t: FluxTransaction = FluxTransaction(
            inputs=parsed_inputs,
            outputs=parsed_outputs,
            network=_net_str,
            version=version,
            locktime=locktime,
            expiry_height=expiry_height,
        )
        t.txid = txid
        t.size = len(raw_bytes)
        t.rawtx = raw_bytes
        return t

    def __init__(
        self,
        *,
        version: int | bytes = 4,
        expiry_height: int = 0,
        lock_time: int = 0,
        inputs: list[Input] | None = None,
        outputs: list[Output] | None = None,
        locktime: int = 0,
        network: str | Network = DEFAULT_NETWORK,
        fee: int | None = None,
        fee_per_kb: int | None = None,
        size: int | None = None,
        txid: str = "",
        txhash: str = "",
        date: datetime | None = None,
        confirmations: int | None = None,
        block_height: int | None = None,
        block_hash: str | None = None,
        input_total: int = 0,
        output_total: int = 0,
        rawtx: bytes = b"",
        status: str = "new",
        coinbase: bool = False,
        verified: bool = False,
        witness_type: str = "legacy",
        flag: str | None = None,
    ) -> None:
        # so we don't have to modify TransactionMixin
        if isinstance(version, bytes):
            version = int.from_bytes(version, byteorder="big")

        network_str: str = network.name if is_network(network) else network

        self.sapling_tx: SaplingTx = SaplingTx(version, nExpiryHeight=expiry_height)
        super().__init__(
            version=version,
            expiry_height=expiry_height,
            inputs=inputs,
            outputs=outputs,
            locktime=locktime,
            network=network_str,
            fee=fee,
            fee_per_kb=fee_per_kb,
            size=size,
            txid=txid,
            txhash=txhash,
            date=date,
            confirmations=confirmations,
            block_height=block_height,
            block_hash=block_hash,
            input_total=input_total,
            output_total=output_total,
            rawtx=rawtx,
            status=status,
            coinbase=coinbase,
            verified=verified,
            witness_type=witness_type,
            flag=flag,
        )

    def validate(self) -> bool:
        """Validate Flux/Sapling-specific consensus rules."""
        super().validate()
        if self.version_int < SAPLING_MIN_TX_VERSION:
            raise TransactionError(f"Transaction version {self.version_int} below Sapling minimum")
        if self.expiry_height >= TX_EXPIRY_HEIGHT_THRESHOLD:
            raise TransactionError(f"Expiry height {self.expiry_height} exceeds threshold")

        # Non-empty transaction (daemon main.cpp:1480-1487)
        has_shielded = bool(self.sapling_tx.vShieldedSpends or self.sapling_tx.vJoinSplit)
        if not self.inputs and not self.outputs and not has_shielded:
            raise TransactionError("Transaction must have at least one input, output, or shielded operation")

        # valueBalance must be 0 when no shielded ops (daemon main.cpp:1585)
        if (
            self.sapling_tx.valueBalance != 0
            and not self.sapling_tx.vShieldedSpends
            and not self.sapling_tx.vShieldedOutputs
        ):
            raise TransactionError("valueBalance must be 0 when there are no shielded spends or outputs")

        return True

    def __repr__(self) -> str:
        return (
            f"<FluxTransaction(id={self.txid}, inputs={len(self.inputs)}, "
            f"outputs={len(self.outputs)}, status={self.status}, network={self.network.name})>"
        )

    def raw(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        **kwargs: str | int | None,
    ) -> bytes:
        for i in self.inputs:
            match sign_id:
                case None:
                    script: FluxScript = FluxScript.from_bytes(i.unlocking_script)
                case i.index_n:
                    script = FluxScript.from_bytes(i.unlocking_script_unsigned)
                case _:
                    script = FluxScript()
            if self.sapling_tx.vin:
                self.sapling_tx.vin[i.index_n].scriptSig = script

        self.sync_tx()
        return bytes(self.sapling_tx)

    def sync_tx(self) -> None:
        if self.inputs or self.outputs:
            self.sapling_tx.vout = []
            self.sapling_tx.vin = []
            for input in self.inputs:
                # investigate why prev_txid is reversed?!?
                outpoint: OutPoint = OutPoint(input.prev_txid[::-1], input.output_n_int)
                unlocking_script: FluxScript = FluxScript(input.unlocking_script)
                self.sapling_tx.vin.append(TxIn(outpoint, unlocking_script, input.sequence))

            for output in self.outputs:
                _script_raw: bytes = output.script.raw if output.script is not None else b""
                self.sapling_tx.vout.append(TxOut(output.value, FluxScript.from_bytes(_script_raw)))

    def signature_hash(
        self,
        sign_id: int | None = None,
        hash_type: int = SIGHASH_ALL,
        witness_type: str | None = None,
        as_hex: bool = False,
    ) -> bytes:
        if sign_id is None:
            return b""

        self.sync_tx()
        value: int = self.inputs[sign_id].value if self.inputs else 0
        _n_inputs: int = len(self.inputs)

        script_code: bytes = self.inputs[sign_id].unlocking_script_unsigned

        sighash: bytes = self.sapling_tx.signature_hash(script_code, value, sign_id, sign_id, hash_type)

        return sighash

    def witness_data(self) -> bytes:
        """Get witness data for all inputs of this transaction.

        Just a hack, so we don't have to modify TransactionMixin as FLux has no witness data.

        :return bytes:
        """
        return b""
