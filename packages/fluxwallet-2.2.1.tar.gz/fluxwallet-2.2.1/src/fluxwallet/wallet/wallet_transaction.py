from __future__ import annotations

import logging
from copy import deepcopy
from datetime import UTC, datetime
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from fluxwallet.wallet import Wallet

from fluxwallet.config import SIGHASH_ALL
from fluxwallet.encoding import int_to_varbyteint, to_bytes, to_hexstring, varstr
from fluxwallet.keys import HDKey
from fluxwallet.networks import Network
from fluxwallet.services.core import Service
from fluxwallet.transactions import (
    FluxTransaction,
    Input,
    Output,
    TransactionMixin,
)
from fluxwallet.wallet.store_access import _get_store, _save_store
from fluxwallet.wallet_store import (
    StoredTransaction,
    StoredTxInput,
    StoredTxOutput,
    WalletStore,
)

_logger = logging.getLogger(__name__)


class WalletTransaction[T: TransactionMixin]:
    """Used as attribute of Wallet class. Child of Transaction object with extra reference to wallet and store object.

    All WalletTransaction items are stored via WalletStore.
    """

    def __init__(
        self,
        hdwallet: Wallet,
        transaction: T,
        addresslist: list[str],
        *,
        account_id: int | None = None,
    ) -> None:
        self.hdwallet: Wallet = hdwallet
        self.tx: T = transaction

        self.status = "confirmed" if self.tx.confirmations else "new"

        self.pushed: bool = False
        self.error: str | None = None

        self.outgoing_tx: bool | None = None
        self.incoming_tx: bool | None = None

        self.account_id: int = (self.hdwallet.default_account_id or 0) if account_id is None else account_id

        if hdwallet.witness_type in ["segwit", "p2sh-segwit"]:
            self.tx.witness_type = hdwallet.witness_type
        else:
            self.tx.witness_type = "legacy"

        self.outgoing_tx = bool([i.address for i in self.tx.inputs if i.address in addresslist])
        self.incoming_tx = bool([o.address for o in self.tx.outputs if o.address in addresslist])

    @classmethod
    async def create(
        cls,
        hdwallet: Wallet,
        transaction: T,
        account_id: int | None = None,
    ) -> WalletTransaction[T]:
        addresslist = await hdwallet.addresslist()
        return WalletTransaction(hdwallet, transaction, addresslist, account_id=account_id)

    def __repr__(self) -> str:
        return (
            f"<WalletTransaction(input_count={len(self.tx.inputs)}, output_count={len(self.tx.outputs)}, "
            f"status={self.status}, network={self.tx.network.name})>"
        )

    def __deepcopy__(self, memo: dict[int, WalletTransaction[T]]) -> WalletTransaction[T]:
        cls = self.__class__
        result = cls.__new__(cls)
        memo[id(self)] = result
        self_dict: dict[str, Wallet | T | str | bool | int | None] = self.__dict__
        for k, v in self_dict.items():
            if k != "hdwallet":
                setattr(result, k, deepcopy(v, memo))
        result.hdwallet = self.hdwallet
        return result

    @classmethod
    async def from_txid(
        cls, hdwallet: Wallet, txid: str, addresslist: list[str] | None
    ) -> WalletTransaction[FluxTransaction] | None:
        """Read single transaction from store with given transaction ID / hash.

        :param hdwallet: Wallet object
        :param txid: Transaction hash as hexadecimal string
        :return: WalletTransaction or None
        """
        if not addresslist:
            addresslist = await hdwallet.addresslist()



        store: WalletStore = await _get_store()
        db_tx = store.get_transaction(txid=to_bytes(txid), wallet_id=hdwallet.wallet_id)
        if not db_tx:
            return None

        fee_per_kb = None
        if db_tx.fee and db_tx.size:
            fee_per_kb = int((db_tx.fee / db_tx.size) * 1000)

        network = Network(db_tx.network_name)

        inputs = []
        for inp in db_tx.inputs:
            sequence = inp.sequence if inp.sequence else 0xFFFFFFFF
            inp_keys = []

            if inp.key_id:
                key = await hdwallet.key(inp.key_id)

                if key.key_type == "multisig":
                    db_key = store.get_key(key_id=key.key_id)
                    if db_key:
                        for child_id, _ in db_key.multisig_children:
                            child_key = store.get_key(key_id=child_id)
                            if child_key and child_key.public:
                                inp_keys.append(child_key.public.hex())
                else:
                    k = key.key()
                    inp_keys = [k] if k is not None else []

            inputs.append(
                Input(
                    prev_txid=inp.prev_txid or b"",
                    output_n=inp.output_n,
                    keys=inp_keys,
                    unlocking_script=inp.script or b"",
                    script_type=inp.script_type,
                    sequence=sequence,
                    index_n=inp.index_n,
                    value=inp.value,
                    double_spend=inp.double_spend,
                    witness_type=inp.witness_type,
                    network=network,
                    address=inp.address,
                    witnesses=inp.witnesses,
                )
            )

        outputs = []
        for out in db_tx.outputs:
            address = ""
            public_key = b""

            if out.key_id:
                key = await hdwallet.key(out.key_id)
                address = key.address

                if key.key_type != "multisig":
                    k_out = key.key()
                    if k_out is not None and k_out.public_hex is not None:
                        public_key = k_out.public_hex

            outputs.append(
                Output(
                    value=out.value,
                    address=address,
                    public_key=public_key,
                    lock_script=out.script or b"",
                    spent=out.spent,
                    output_n=out.output_n,
                    script_type=out.script_type,
                    network=network,
                )
            )

        tx = FluxTransaction(
            inputs=inputs,
            outputs=outputs,
            locktime=db_tx.locktime,
            version=db_tx.version,
            network=network,
            fee=db_tx.fee,
            fee_per_kb=fee_per_kb,
            size=db_tx.size,
            txid=to_hexstring(txid),
            date=db_tx.date,
            confirmations=db_tx.confirmations,
            block_height=db_tx.block_height,
            input_total=db_tx.input_total,
            output_total=db_tx.output_total,
            rawtx=db_tx.raw or b"",
            status=db_tx.status,
            coinbase=db_tx.coinbase,
            verified=db_tx.verified,
        )

        return WalletTransaction(hdwallet, tx, addresslist, account_id=db_tx.account_id)

    def to_transaction(self) -> T:
        return self.tx

    def sign(
        self,
        keys: HDKey | str | list[HDKey] | list[HDKey | str] | None = None,
        index_n: int = 0,
        multisig_key_n: int | None = None,
        hash_type: int = SIGHASH_ALL,
        fail_on_unknown_key: bool = False,
        replace_signatures: bool = False,
        partial: bool = False,
    ) -> None:
        """Sign this transaction. Use existing keys from wallet or use keys argument for extra keys.

        :param keys: Extra private keys to sign the transaction
        :param index_n: Transaction index_n to sign
        :param multisig_key_n: Index number of key for multisig input for segwit transactions
        :param hash_type: Hashtype to use, default is SIGHASH_ALL
        :param fail_on_unknown_key: Method fails if public key from signature is not found in public key list
        :param replace_signatures: Replace signature with new one if already signed
        :param partial: If True, skip verification after signing (used for SSP 2-of-2 multisig)
        :return: None
        """
        priv_key_list_arg: list[tuple[str | list[int] | None, HDKey]] = []
        if keys:
            key_paths: list[str | list[int]] = [ti.key_path for ti in self.tx.inputs if ti.key_path[0] == "m"]

            if isinstance(keys, HDKey):
                key_list: list[HDKey | str] = [keys]
            elif isinstance(keys, str):
                key_list = [keys]
            else:
                key_list = list(keys)

            for key_input in key_list:
                if isinstance(key_input, HDKey):
                    resolved_key: HDKey = key_input
                else:
                    raw_key: str = key_input
                    if len(raw_key.split(" ")) > 4:
                        resolved_key = HDKey.from_passphrase(raw_key, network=self.tx.network)
                    else:
                        resolved_key = HDKey(raw_key, network=self.tx.network.name)

                priv_key_list_arg.append((None, resolved_key))

                if key_paths and resolved_key.depth == 0 and resolved_key.key_type != "single":
                    for key_path in key_paths:
                        kp: str | list[str] = key_path if isinstance(key_path, str) else [str(x) for x in key_path]
                        priv_key_list_arg.append((key_path, resolved_key.subkey_for_path(kp)))

        for ti in self.tx.inputs:
            priv_key_list = []

            for key_path, priv_key in priv_key_list_arg:
                if (not key_path or key_path == ti.key_path) and priv_key not in priv_key_list:
                    priv_key_list.append(priv_key)

            priv_key_list += [k for k in ti.keys if k.is_private]

            self.tx.sign(
                priv_key_list,
                ti.index_n,
                multisig_key_n,
                hash_type,
                fail_on_unknown_key,
                replace_signatures,
            )

        if not partial:
            self.tx.verify()
        self.error = ""

    async def send(self, offline: bool = False) -> None:
        """Verify and push transaction to network. Update UTXOs in store after successful send.

        :param offline: Just return the transaction object and do not send it when offline = True
        :return: None
        """
        self.error = None
        if not self.tx.verified or not self.tx.verify():
            self.error = "Cannot verify transaction"
            return

        if offline:
            return

        srv = Service(
            network=self.hdwallet.network.name,
            providers=self.hdwallet.providers,
            cache_uri=self.hdwallet.db_cache_uri,
        )
        res = await srv.sendrawtransaction(self.tx.raw_hex())

        if not res:
            self.error = f"Cannot send transaction. {srv.errors}"
            return

        _logger.info(f"Successfully pushed transaction, result: {res}")

        self.tx.txid = res.txid
        self.status = "unconfirmed"
        self.pushed = True

        await self.store()



        store: WalletStore = await _get_store()
        txid_bytes = bytes.fromhex(self.tx.txid)

        # Mark spent UTXOs
        for inp in self.tx.inputs:
            prev_txid = inp.prev_txid
            for stx in store.transactions.values():
                if stx.txid == prev_txid:
                    for out in stx.outputs:
                        if out.output_n == inp.output_n_int and not out.spent:
                            out.spent = True
                            out.spending_txid = txid_bytes
                            out.spending_index_n = inp.index_n
                            store._dirty = True

        await self.hdwallet._balance_update(network=self.tx.network.name)
        await _save_store()

    async def sync(self) -> None:
        """Sync this wallet transaction data with the store."""


        store: WalletStore = await _get_store()
        db_tx = store.get_transaction(txid=bytes.fromhex(self.tx.txid), wallet_id=self.hdwallet.wallet_id)
        if not db_tx:
            return

        self.tx.block_height = db_tx.block_height if db_tx.block_height else self.tx.block_height
        self.tx.confirmations = db_tx.confirmations if db_tx.confirmations else self.tx.confirmations
        self.tx.date = db_tx.date if db_tx.date else self.tx.date
        self.status = db_tx.status if db_tx.status else self.status

    async def store(self) -> int:
        """Store this transaction to the wallet store.

        :return int: Transaction index number
        """


        store: WalletStore = await _get_store()
        txid_bytes = bytes.fromhex(self.tx.txid)

        db_tx = store.get_transaction(txid=txid_bytes, wallet_id=self.hdwallet.wallet_id)

        if not db_tx:
            # Check for orphan tx (wallet_id not set) — not applicable in flat-file store,
            # but keep the pattern: just create new if not found.
            version = 4 if self.tx.network.name == "flux" else 1

            # Build inputs
            stored_inputs = []
            for ti in self.tx.inputs:
                tx_key = store.get_key(address=ti.address)
                key_id = None
                if tx_key and tx_key.wallet_id == self.hdwallet.wallet_id:
                    key_id = tx_key.id
                    tx_key.used = True
                    store._dirty = True

                witnesses = int_to_varbyteint(len(ti.witnesses)) + b"".join([bytes(varstr(w)) for w in ti.witnesses])
                stored_inputs.append(
                    StoredTxInput(
                        index_n=ti.index_n,
                        output_n=ti.output_n_int,
                        key_id=key_id,
                        value=ti.value,
                        prev_txid=ti.prev_txid,
                        double_spend=ti.double_spend,
                        script=ti.unlocking_script,
                        script_type=ti.script_type or "",
                        witness_type=ti.witness_type or "",
                        sequence=ti.sequence,
                        address=ti.address,
                        witnesses=witnesses,
                    )
                )

            # Build outputs
            stored_outputs = []
            for to in self.tx.outputs:
                tx_key = store.get_key(address=to.address)
                key_id = None
                if tx_key and tx_key.wallet_id == self.hdwallet.wallet_id:
                    key_id = tx_key.id
                    tx_key.used = True
                    store._dirty = True

                stored_outputs.append(
                    StoredTxOutput(
                        output_n=to.output_n,
                        key_id=key_id,
                        address=to.address,
                        value=to.value,
                        spent=to.spent if to.spent else False,
                        script=to.lock_script,
                        script_type=to.script_type or "",
                    )
                )

            new_tx = StoredTransaction(
                id=0,  # assigned by add_transaction
                wallet_id=self.hdwallet.wallet_id,
                version=version,
                txid=txid_bytes,
                block_height=self.tx.block_height,
                size=self.tx.size or 0,
                confirmations=self.tx.confirmations or 0,
                date=self.tx.date or datetime.now(UTC),
                fee=self.tx.fee or 0,
                status=self.status,
                input_total=self.tx.input_total,
                output_total=self.tx.output_total,
                network_name=self.tx.network.name,
                raw=self.tx.rawtx,
                verified=self.tx.verified,
                account_id=self.account_id,
                coinbase=self.tx.coinbase,
                expiry_height=self.tx.expiry_height,
                inputs=stored_inputs,
                outputs=stored_outputs,
            )
            txidn = store.add_transaction(new_tx)

        else:
            # Update existing transaction
            txidn = db_tx.id
            db_tx.block_height = self.tx.block_height if self.tx.block_height else db_tx.block_height
            db_tx.confirmations = self.tx.confirmations if self.tx.confirmations else db_tx.confirmations
            db_tx.date = self.tx.date if self.tx.date else db_tx.date
            db_tx.fee = self.tx.fee if self.tx.fee else db_tx.fee
            db_tx.status = self.status if self.status else db_tx.status
            db_tx.input_total = self.tx.input_total if self.tx.input_total else db_tx.input_total
            db_tx.output_total = self.tx.output_total if self.tx.output_total else db_tx.output_total
            db_tx.network_name = self.tx.network.name if self.tx.network.name else db_tx.network_name
            db_tx.raw = self.tx.rawtx if self.tx.rawtx else db_tx.raw
            db_tx.verified = self.tx.verified
            db_tx.coinbase = self.tx.coinbase
            store._dirty = True

            # Update/add inputs
            existing_inputs = {inp.index_n: inp for inp in db_tx.inputs}
            for ti in self.tx.inputs:
                tx_key = store.get_key(address=ti.address)
                key_id = None
                if tx_key and tx_key.wallet_id == self.hdwallet.wallet_id:
                    key_id = tx_key.id
                    tx_key.used = True

                if ti.index_n not in existing_inputs:
                    witnesses = int_to_varbyteint(len(ti.witnesses)) + b"".join(
                        [bytes(varstr(w)) for w in ti.witnesses]
                    )
                    db_tx.inputs.append(
                        StoredTxInput(
                            index_n=ti.index_n,
                            output_n=ti.output_n_int,
                            key_id=key_id,
                            value=ti.value,
                            prev_txid=ti.prev_txid,
                            double_spend=ti.double_spend,
                            script=ti.unlocking_script,
                            script_type=ti.script_type or "",
                            witness_type=ti.witness_type or "",
                            sequence=ti.sequence,
                            address=ti.address,
                            witnesses=witnesses,
                        )
                    )
                elif key_id:
                    tx_input = existing_inputs[ti.index_n]
                    tx_input.key_id = key_id
                    if ti.value:
                        tx_input.value = ti.value
                    if ti.prev_txid:
                        tx_input.prev_txid = ti.prev_txid
                    if ti.unlocking_script:
                        tx_input.script = ti.unlocking_script

            # Update/add outputs
            existing_outputs = {out.output_n: out for out in db_tx.outputs}
            for to in self.tx.outputs:
                tx_key = store.get_key(address=to.address)
                key_id = None
                if tx_key and tx_key.wallet_id == self.hdwallet.wallet_id:
                    key_id = tx_key.id
                    tx_key.used = True

                spent = to.spent
                if to.output_n not in existing_outputs:
                    db_tx.outputs.append(
                        StoredTxOutput(
                            output_n=to.output_n,
                            key_id=key_id,
                            address=to.address,
                            value=to.value,
                            spent=spent if spent else False,
                            script=to.lock_script,
                            script_type=to.script_type or "",
                        )
                    )
                elif key_id:
                    tx_output = existing_outputs[to.output_n]
                    tx_output.key_id = key_id
                    tx_output.spent = spent if spent is not None else tx_output.spent

        return txidn

    def info(self) -> None:
        """Print Wallet transaction information to standard output."""
        self.tx.info()
        print(f"Pushed to network: {self.pushed}")
        print(f"Wallet: {self.hdwallet.name}")
        if self.error:
            print(f"Errors: {self.error}")
        print("\n")

    async def export(
        self, skip_change: bool = True
    ) -> list[tuple[str | None, str, str, list[str], str, int, int | float]]:
        """
        Export this transaction as list of tuples:
            (transaction_date, transaction_hash, in/out, addresses_in, addresses_out, value, fee)

        :param skip_change: Do not include outputs to own wallet (default)
        :return: list of tuple
        """
        mut_list = []
        wlt_addresslist = await self.hdwallet.addresslist()

        input_addresslist = [i.address for i in self.tx.inputs]
        if self.outgoing_tx:
            fee_per_output = (self.tx.fee or 0) / len(self.tx.outputs)

            for o in self.tx.outputs:
                o_value = -o.value
                if o.address in wlt_addresslist:
                    if skip_change:
                        continue
                    if self.incoming_tx:
                        o_value = 0
                mut_list.append(
                    (
                        self.tx.date,
                        self.tx.txid,
                        "out",
                        input_addresslist,
                        o.address,
                        o_value,
                        fee_per_output,
                    )
                )
        else:
            for o in self.tx.outputs:
                if o.address not in wlt_addresslist:
                    continue
                mut_list.append(
                    (
                        self.tx.date,
                        self.tx.txid,
                        "in",
                        input_addresslist,
                        o.address,
                        o.value,
                        0,
                    )
                )

        return mut_list
