"""Shared guard-evaluation logic for drop-in LLM integrations.

Both ``patch_openai`` and ``patch_anthropic`` call into this module after the
model response arrives and before control returns to the caller. For each
tool call the model wants to run we:

  1. Evaluate the guard via ``staso.guard.guard()``.
  2. Emit a ``guard:blocked:<tool>`` / ``guard:would-block:<tool>`` /
     ``guard:modified:<tool>`` child span so the trace viewer renders the
     decision visibly (frontend already handles these names).
  3. Annotate the parent LLM span's metadata with the evaluation summary.
  4. For ``modify`` — apply the modification in-place on the provider's
     tool-call object so the subsequent agent loop sees the rewritten input.
  5. For ``block`` / ``escalate`` — raise :class:`staso.guard.GuardBlocked`
     so the tool call is actually prevented from running.

This replaces the earlier observational-only pattern where the integration
emitted a ``guard:blocked:*`` span and then handed the tool call back to the
caller intact, which was a lie: nothing was blocked. Real blocking is the
only honest semantic for a rule configured in enforce mode.
"""
from __future__ import annotations

import logging
import os
from typing import Any, Callable

from ..client import get_tracer
from ..guard import GuardBlocked
from ..guard_types import GuardResult
from ..types import SpanKind, SpanStatus

logger = logging.getLogger("staso")


def guard_enabled() -> bool:
    return os.environ.get("STASO_GUARD_ENABLED", "true").lower() != "false"


def try_guard(tool_name: str, tool_input: dict[str, Any]) -> GuardResult | None:
    """Evaluate a single tool call against the guard API.

    Returns the :class:`GuardResult` on success, or ``None`` if the guard
    call itself errored out (network, timeout, etc). Guard-call failures are
    fail-open — we never block a tool just because our own evaluation fell
    over.

    Pulls ``trace_id`` / ``session_id`` / ``agent_name`` from the active SDK
    context so the resulting ``guard_violations`` row links back to the
    trace on the dashboard.
    """
    try:
        from ..context import agent_name_var, get_current_span, session_id_var
        from ..guard import guard

        span = get_current_span()
        ctx = {
            "trace_id": getattr(span, "trace_id", "") if span is not None else "",
            "session_id": session_id_var.get() or "",
            "agent_name": agent_name_var.get() or "",
        }
        return guard(tool_name=tool_name, tool_input=tool_input, context=ctx)
    except Exception:
        logger.debug("staso: guard evaluation failed", exc_info=True)
        return None


def _emit_child_span(
    span_name: str,
    status: SpanStatus,
    tool_name: str,
    tool_input: dict[str, Any],
    output: dict[str, Any],
    reason: str,
    latency_ms: float,
    error_message: str | None,
) -> None:
    tracer = get_tracer()
    if tracer is None:
        return
    try:
        child = tracer.start_span(span_name, kind=SpanKind.TOOL)
    except Exception:
        return
    try:
        child.input = {"tool_name": tool_name, "tool_input": tool_input}
        child.output = output
        child.metadata["guard_action"] = output.get("action", "")
        child.metadata["guard_reason"] = reason
        child.metadata["guard_latency_ms"] = latency_ms
        child.status = status
        if error_message:
            child.error_message = error_message
    finally:
        try:
            child.end()
        except Exception:
            pass


def evaluate_and_enforce(
    tool_calls: list[dict[str, Any]],
    parent_span: Any,
    *,
    apply_modify: Callable[[Any, dict[str, Any]], None] | None = None,
) -> None:
    """Evaluate guard for every tool call, emit child spans, apply modifications,
    annotate the parent span, and raise :class:`GuardBlocked` on the first
    enforce-mode block.

    Args:
        tool_calls: A list of ``{"name": str, "input": dict, "ref": Any}``.
            ``ref`` is the provider-specific handle that ``apply_modify``
            uses to rewrite the modified args in-place on the response
            object. ``ref`` may be ``None`` if the provider can't mutate.
        parent_span: The LLM span that spawned these tool calls. Its
            ``metadata["guard_evaluations"]`` gets populated, and on block
            its status is set to ``ERROR`` with the guard reason.
        apply_modify: Optional callback ``apply_modify(ref, modified_input)``
            invoked when a ``modify`` rule fires. If the callback raises, the
            modification is logged and dropped — we don't fail the call.

    Raises:
        GuardBlocked: when any enforce-mode rule returns ``action=="block"``
            (or ``"escalate"``). All guard spans for the batch are emitted
            first, so the trace viewer still shows every decision.
    """
    if not guard_enabled() or not tool_calls:
        return

    evaluations: list[dict[str, Any]] = []
    blocked: list[tuple[str, GuardResult]] = []
    block_reason_parts: list[str] = []

    for tc in tool_calls:
        name = tc.get("name") or "unknown"
        inp = tc.get("input") or {}
        ref = tc.get("ref")

        result = try_guard(name, inp)
        if result is None:
            continue

        action = result.action
        reason = result.reason or ""
        latency_ms = result.latency_ms or 0.0
        rules_triggered = list(result.rules_triggered or [])
        audit_results = [r for r in (result.results or []) if not r.passed]

        evaluations.append(
            {
                "tool_name": name,
                "action": action,
                "reason": reason,
                "latency_ms": latency_ms,
                "rules_triggered": rules_triggered,
            }
        )

        if action in ("block", "escalate"):
            output = {
                "action": "block",
                "reason": reason,
                "rules_triggered": rules_triggered,
            }
            err = f"Guard blocked: {reason}" if reason else "Guard blocked"
            _emit_child_span(
                span_name=f"guard:blocked:{name}",
                status=SpanStatus.ERROR,
                tool_name=name,
                tool_input=inp,
                output=output,
                reason=reason,
                latency_ms=latency_ms,
                error_message=err,
            )
            blocked.append((name, result))
            if reason:
                block_reason_parts.append(f"{name}: {reason}")

        elif action == "modify":
            output = {
                "action": "modify",
                "reason": reason,
                "modified_input": result.modified_input,
                "modifications": list(result.modifications or []),
                "rules_triggered": rules_triggered,
            }
            _emit_child_span(
                span_name=f"guard:modified:{name}",
                status=SpanStatus.OK,
                tool_name=name,
                tool_input=inp,
                output=output,
                reason=reason,
                latency_ms=latency_ms,
                error_message=None,
            )
            if (
                apply_modify is not None
                and ref is not None
                and result.modified_input is not None
            ):
                try:
                    apply_modify(ref, result.modified_input)
                except Exception:
                    logger.debug(
                        "staso: modify application failed for %s", name, exc_info=True
                    )

        elif action == "allow" and audit_results:
            # Audit-mode rules fired — call proceeds, but we emit a
            # would-block span so the dashboard sees the suppressed block.
            output = {
                "action": "would_block",
                "reason": "; ".join(r.reason for r in audit_results if r.reason),
                "rules_triggered": [
                    {
                        "rule_name": r.rule_name,
                        "action": r.action,
                        "reason": r.reason,
                        "severity": getattr(r, "severity", "medium"),
                    }
                    for r in audit_results
                ],
            }
            _emit_child_span(
                span_name=f"guard:would-block:{name}",
                status=SpanStatus.OK,
                tool_name=name,
                tool_input=inp,
                output=output,
                reason=output["reason"],
                latency_ms=latency_ms,
                error_message=None,
            )
        # else: action == "allow" with no audit fires — nothing to show.

    if evaluations:
        try:
            parent_span.metadata["guard_evaluations"] = evaluations
        except Exception:
            pass

    if blocked:
        first_tool, first_result = blocked[0]
        try:
            parent_span.status = SpanStatus.ERROR
            combined = "; ".join(block_reason_parts) or first_result.reason or ""
            parent_span.error_message = (
                f"Guard blocked: {combined}" if combined else "Guard blocked"
            )
        except Exception:
            pass
        raise GuardBlocked(tool_name=first_tool, result=first_result)
