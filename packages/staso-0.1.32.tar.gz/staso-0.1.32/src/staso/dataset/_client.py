"""Synchronous HTTP client for dataset CRUD operations."""

from __future__ import annotations

import logging
import threading
from typing import Any

import httpx

from staso._common.version import USER_AGENT_DATASETS
from staso.dataset._types import (
    Dataset,
    DatasetColumn,
    DatasetEntry,
    DatasetFolder,
    StasoDatasetError,
)

logger = logging.getLogger(__name__)

_MAX_RETRIES = 3
_BACKOFF = (0.5, 1.0, 2.0)


class DatasetHTTPClient:
    def __init__(self, base_url: str, api_key: str, workspace_slug: str) -> None:
        self._base_url = f"{base_url.rstrip('/')}/v1/datasets"
        self._api_key = api_key
        self._workspace_slug = workspace_slug
        self._client: httpx.Client | None = None
        self._lock = threading.Lock()

    def _http(self) -> httpx.Client:
        if self._client is not None:
            return self._client
        with self._lock:
            if self._client is None:
                self._client = httpx.Client(
                    headers={
                        "X-API-Key": self._api_key,
                        "Content-Type": "application/json",
                        "User-Agent": USER_AGENT_DATASETS,
                    },
                    timeout=30.0,
                )
        return self._client

    def shutdown(self) -> None:
        if self._client is not None:
            self._client.close()
            self._client = None

    def _request(self, method: str, path: str, **kwargs: Any) -> Any:
        url = f"{self._base_url}{path}"
        last_err: Exception | None = None
        for attempt in range(_MAX_RETRIES):
            try:
                resp = self._http().request(method, url, **kwargs)
                if resp.status_code >= 400:
                    if resp.status_code >= 500 and attempt < _MAX_RETRIES - 1:
                        import time
                        time.sleep(_BACKOFF[attempt])
                        continue
                    raise StasoDatasetError(
                        f"Dataset API error: {resp.status_code}",
                        status_code=resp.status_code,
                        response_body=resp.text,
                    )
                if resp.status_code == 204 or not resp.content:
                    return None
                return resp.json()
            except httpx.HTTPError as e:
                last_err = e
                if attempt < _MAX_RETRIES - 1:
                    import time
                    time.sleep(_BACKOFF[attempt])
        raise StasoDatasetError(f"Network error: {last_err}") from last_err

    # ── Parsing helpers ───────────────────────────────────────

    @staticmethod
    def _parse_dataset(data: dict) -> Dataset:
        columns = tuple(
            DatasetColumn(
                name=c.get("name", ""),
                column_type=c.get("column_type", "variable"),
                description=c.get("description", ""),
                required=c.get("is_required", False),
            )
            for c in data.get("columns", [])
        )
        return Dataset(
            id=data["id"],
            name=data["name"],
            description=data.get("description", ""),
            folder_id=data.get("folder_id"),
            template=data.get("template", "custom"),
            columns=columns,
            entry_count=data.get("entry_count", 0),
            created_at=data.get("created_at", ""),
            updated_at=data.get("updated_at", ""),
        )

    @staticmethod
    def _parse_entry(data: dict) -> DatasetEntry:
        return DatasetEntry(
            id=data["id"],
            dataset_id=data["dataset_id"],
            data=data.get("data", {}),
            split=data.get("split_id"),
            source_type=data.get("source_type"),
            created_at=data.get("created_at", ""),
        )

    @staticmethod
    def _parse_folder(data: dict) -> DatasetFolder:
        return DatasetFolder(
            id=data["id"],
            name=data["name"],
            parent_id=data.get("parent_id"),
        )

    # ── Dataset CRUD ──────────────────────────────────────────

    def create_dataset(
        self, name: str, description: str, columns: list[dict], folder_id: str | None
    ) -> Dataset:
        body: dict[str, Any] = {"name": name, "template": "custom", "description": description}
        if folder_id:
            body["folder_id"] = folder_id
        data = self._request("POST", "", json=body)
        ds = self._parse_dataset(data)
        if columns:
            for col in columns:
                self._request("POST", f"/{ds.id}/columns", json={
                    "name": col.get("name", ""),
                    "column_type": col.get("column_type", "variable"),
                    "description": col.get("description", ""),
                })
            data = self._request("GET", f"/{ds.id}")
            ds = self._parse_dataset(data)
        return ds

    def get_dataset(self, dataset_id: str) -> Dataset:
        return self._parse_dataset(self._request("GET", f"/{dataset_id}"))

    def list_datasets(self, folder_id: str | None, limit: int, offset: int) -> list[Dataset]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if folder_id:
            params["folder_id"] = folder_id
        data = self._request("GET", "", params=params)
        datasets = data.get("datasets", data) if isinstance(data, dict) else data
        return [self._parse_dataset(d) for d in datasets]

    def update_dataset(self, dataset_id: str, name: str | None, description: str | None) -> Dataset:
        body: dict[str, Any] = {}
        if name is not None:
            body["name"] = name
        if description is not None:
            body["description"] = description
        return self._parse_dataset(self._request("PATCH", f"/{dataset_id}", json=body))

    def delete_dataset(self, dataset_id: str) -> None:
        self._request("DELETE", f"/{dataset_id}")

    # ── Entries ───────────────────────────────────────────────

    def add_entry(
        self, dataset_id: str, data: dict, split: str | None,
        source_trace_id: str | None, source_span_id: str | None,
    ) -> DatasetEntry:
        body: dict[str, Any] = {"data": data}
        if split:
            body["split_id"] = split
        resp = self._request("POST", f"/{dataset_id}/entries", json=body)
        return self._parse_entry(resp)

    def add_entries(self, dataset_id: str, entries: list[dict], split: str | None) -> list[DatasetEntry]:
        body: dict[str, Any] = {"entries": entries}
        if split:
            body["split_id"] = split
        resp = self._request("POST", f"/{dataset_id}/entries/bulk", json=body)
        return [self._parse_entry(e) for e in resp]

    def list_entries(self, dataset_id: str, split: str | None, limit: int, offset: int) -> list[DatasetEntry]:
        params: dict[str, Any] = {"limit": limit, "offset": offset}
        if split:
            params["split_id"] = split
        data = self._request("GET", f"/{dataset_id}/entries", params=params)
        entries = data.get("entries", data) if isinstance(data, dict) else data
        return [self._parse_entry(e) for e in entries]

    def update_entry(self, dataset_id: str, entry_id: str, data: dict | None) -> DatasetEntry:
        body: dict[str, Any] = {}
        if data is not None:
            body["data"] = data
        return self._parse_entry(self._request("PATCH", f"/{dataset_id}/entries/{entry_id}", json=body))

    def delete_entry(self, dataset_id: str, entry_id: str) -> None:
        self._request("DELETE", f"/{dataset_id}/entries", json={"entry_ids": [entry_id]})

    # ── Folders ───────────────────────────────────────────────

    def create_folder(self, name: str, parent_id: str | None) -> DatasetFolder:
        body: dict[str, Any] = {"name": name}
        if parent_id:
            body["parent_id"] = parent_id
        return self._parse_folder(self._request("POST", "/folders", json=body))

    def list_folders(self, parent_id: str | None) -> list[DatasetFolder]:
        params: dict[str, Any] = {}
        if parent_id:
            params["parent_id"] = parent_id
        data = self._request("GET", "/folders", params=params)
        folders = data if isinstance(data, list) else data.get("folders", [])
        return [self._parse_folder(f) for f in folders]

    def delete_folder(self, folder_id: str) -> None:
        self._request("DELETE", f"/folders/{folder_id}")

    # ── CSV ───────────────────────────────────────────────────

    def upload_csv(self, dataset_id: str, file_path: str, split: str | None) -> int:
        with open(file_path, "rb") as f:
            files = {"file": (file_path.split("/")[-1], f, "text/csv")}
            # For file upload, don't send JSON content-type
            resp = self._http().post(
                f"{self._base_url}/{dataset_id}/import/csv",
                files=files,
            )
            if resp.status_code >= 400:
                raise StasoDatasetError(f"CSV upload error: {resp.status_code}", resp.status_code, resp.text)
            data = resp.json()
            return data.get("imported", 0)

    def download_csv(self, dataset_id: str, file_path: str, split: str | None) -> str:
        params: dict[str, Any] = {}
        if split:
            params["split_id"] = split
        resp = self._http().get(f"{self._base_url}/{dataset_id}/export/csv", params=params)
        if resp.status_code >= 400:
            raise StasoDatasetError(f"CSV download error: {resp.status_code}", resp.status_code, resp.text)
        with open(file_path, "wb") as f:
            f.write(resp.content)
        return file_path

    # ── Trace curation ────────────────────────────────────────

    def create_from_traces(
        self, name: str, trace_ids: list[str], mapping: dict[str, str] | None, description: str
    ) -> Dataset:
        ds = self.create_dataset(name, description, [], None)
        if mapping and trace_ids:
            mappings = [
                {"source_field": src, "target_column": tgt}
                for tgt, src in mapping.items()
            ]
            self._request("POST", f"/{ds.id}/curate", json={
                "trace_ids": trace_ids,
                "mappings": mappings,
            })
            return self.get_dataset(ds.id)
        return ds

    # ── Synthetic ─────────────────────────────────────────────

    def generate_synthetic(
        self, dataset_id: str, count: int, prompt: str | None, seed_entry_ids: list[str] | None
    ) -> list[DatasetEntry]:
        body: dict[str, Any] = {"count": count}
        if prompt:
            body["instructions"] = prompt
        if seed_entry_ids:
            body["seed_entry_ids"] = seed_entry_ids
        resp = self._request("POST", f"/{dataset_id}/generate", json=body)
        entries = resp.get("entries", []) if isinstance(resp, dict) else []
        return [self._parse_entry(e) for e in entries]
