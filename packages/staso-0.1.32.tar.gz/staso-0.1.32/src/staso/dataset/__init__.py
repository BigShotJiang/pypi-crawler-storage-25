"""Dataset management — create, curate, evaluate datasets for AI agent testing."""

from __future__ import annotations

import threading
from pathlib import Path
from typing import TYPE_CHECKING, Any, Callable

from staso.dataset._types import (
    ColumnType,
    Dataset,
    DatasetColumn,
    DatasetEntry,
    DatasetFolder,
    EvalResult,
    EvalSummary,
    SplitType,
    StasoDatasetError,
)

if TYPE_CHECKING:
    from staso.dataset._client import DatasetHTTPClient

_client: DatasetHTTPClient | None = None
_lock = threading.Lock()


def _get_client() -> DatasetHTTPClient:
    global _client
    if _client is not None:
        return _client

    from staso.client import get_client

    client = get_client()
    if client is None:
        raise RuntimeError("st.init() must be called before using st.dataset")

    with _lock:
        if _client is None:
            from staso.dataset._client import DatasetHTTPClient as Cls

            cfg = client.config
            _client = Cls(
                base_url=cfg.base_url,
                api_key=cfg.api_key,
                workspace_slug=cfg.workspace_slug,
            )
    return _client


def shutdown_dataset_client() -> None:
    global _client
    if _client is not None:
        _client.shutdown()
        _client = None


class DatasetNamespace:
    """Namespace exposing dataset operations as ``st.dataset.*``."""

    # ── Dataset CRUD ──────────────────────────────────────────

    def create(
        self,
        name: str,
        *,
        description: str = "",
        columns: list[dict[str, str]] | None = None,
        folder_id: str | None = None,
    ) -> Dataset:
        return _get_client().create_dataset(name, description, columns or [], folder_id)

    def get(self, dataset_id: str) -> Dataset:
        return _get_client().get_dataset(dataset_id)

    def list(
        self,
        *,
        folder_id: str | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[Dataset]:
        return _get_client().list_datasets(folder_id, limit, offset)

    def update(
        self,
        dataset_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
    ) -> Dataset:
        return _get_client().update_dataset(dataset_id, name, description)

    def delete(self, dataset_id: str) -> None:
        _get_client().delete_dataset(dataset_id)

    # ── Entries ───────────────────────────────────────────────

    def add_entry(
        self,
        dataset_id: str,
        data: dict[str, Any],
        *,
        split: str | SplitType | None = None,
        source_trace_id: str | None = None,
        source_span_id: str | None = None,
    ) -> DatasetEntry:
        return _get_client().add_entry(
            dataset_id, data, str(split) if split else None, source_trace_id, source_span_id
        )

    def add_entries(
        self,
        dataset_id: str,
        entries: list[dict[str, Any]],
        *,
        split: str | SplitType | None = None,
    ) -> list[DatasetEntry]:
        return _get_client().add_entries(dataset_id, entries, str(split) if split else None)

    def list_entries(
        self,
        dataset_id: str,
        *,
        split: str | SplitType | None = None,
        limit: int = 100,
        offset: int = 0,
    ) -> list[DatasetEntry]:
        return _get_client().list_entries(dataset_id, str(split) if split else None, limit, offset)

    def update_entry(
        self,
        dataset_id: str,
        entry_id: str,
        *,
        data: dict[str, Any] | None = None,
    ) -> DatasetEntry:
        return _get_client().update_entry(dataset_id, entry_id, data)

    def delete_entry(self, dataset_id: str, entry_id: str) -> None:
        _get_client().delete_entry(dataset_id, entry_id)

    # ── CSV ───────────────────────────────────────────────────

    def upload_csv(
        self,
        dataset_id: str,
        file_path: str | Path,
        *,
        split: str | SplitType | None = None,
    ) -> int:
        return _get_client().upload_csv(dataset_id, str(file_path), str(split) if split else None)

    def download_csv(
        self,
        dataset_id: str,
        file_path: str | Path,
        *,
        split: str | SplitType | None = None,
    ) -> Path:
        return Path(_get_client().download_csv(dataset_id, str(file_path), str(split) if split else None))

    # ── Trace Curation ────────────────────────────────────────

    def from_traces(
        self,
        name: str,
        trace_ids: list[str],
        *,
        mapping: dict[str, str] | None = None,
        description: str = "",
    ) -> Dataset:
        return _get_client().create_from_traces(name, trace_ids, mapping, description)

    # ── Folders ───────────────────────────────────────────────

    def create_folder(self, name: str, *, parent_id: str | None = None) -> DatasetFolder:
        return _get_client().create_folder(name, parent_id)

    def list_folders(self, *, parent_id: str | None = None) -> list[DatasetFolder]:
        return _get_client().list_folders(parent_id)

    def delete_folder(self, folder_id: str) -> None:
        _get_client().delete_folder(folder_id)

    # ── Evaluation ────────────────────────────────────────────

    def evaluate(
        self,
        dataset_id: str,
        fn: Callable[[dict[str, Any]], Any],
        *,
        scorers: list[Callable[[dict, Any], float]] | None = None,
        split: str | SplitType | None = None,
        max_concurrency: int = 1,
        trace: bool = True,
    ) -> EvalSummary:
        from staso.dataset._eval import EvaluationRunner

        return EvaluationRunner(
            dataset_id=dataset_id,
            fn=fn,
            scorers=scorers or [],
            split=str(split) if split else None,
            max_concurrency=max_concurrency,
            trace=trace,
            http_client=_get_client(),
        ).run()

    # ── Synthetic ─────────────────────────────────────────────

    def generate(
        self,
        dataset_id: str,
        *,
        count: int = 10,
        prompt: str | None = None,
        seed_entry_ids: list[str] | None = None,
    ) -> list[DatasetEntry]:
        return _get_client().generate_synthetic(dataset_id, count, prompt, seed_entry_ids)


dataset = DatasetNamespace()
