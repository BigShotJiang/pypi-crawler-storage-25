"""
Browser Agent tool — autonomous browser automation via browser-use Agent.

Unlike the low-level `browser` tool (where the LLM manually issues open/click/type),
this tool gives a high-level *task* to browser-use's Agent, which autonomously plans
and executes browser actions (navigation, clicks, typing, scrolling, screenshots, etc.)
using its own internal LLM.

The browser runs non-headless by default so the user can watch it live via VNC/noVNC
in environments like GitHub Codespaces.

A single persistent Chromium process is launched on first use and kept alive forever
(until explicit "close" command). browser-use attaches to it via CDP each run, so the
browser window is always visible in VNC before and after tasks complete.
"""
from __future__ import annotations

import asyncio
import logging
import os
import subprocess
import time
import urllib.request
from typing import Any

from . import Tool, ToolContext, ToolOutput

logger = logging.getLogger("zwischenzug.tools.browser_agent")

# The single persistent Chromium subprocess (module-level singleton).
_CHROMIUM_PROC: subprocess.Popen | None = None
_CDP_PORT = 9222
_CDP_URL = f"http://localhost:{_CDP_PORT}"


def _browser_use_available() -> bool:
    try:
        import browser_use  # noqa: F401
        return True
    except ImportError:
        return False


def _chromium_binary() -> str:
    """Find the Playwright-installed Chromium binary."""
    import shutil
    for candidate in ("chromium", "chromium-browser", "google-chrome", "google-chrome-stable"):
        path = shutil.which(candidate)
        if path:
            return path
    # Playwright installs chromium here (chrome-linux or chrome-linux64)
    pw_chromium = os.path.expanduser(
        "~/.cache/ms-playwright/chromium-*/chrome-linux*/chrome"
    )
    import glob
    matches = glob.glob(pw_chromium)
    if matches:
        return matches[0]
    raise FileNotFoundError("Could not find a Chromium binary.")


def _ensure_chromium_running(display: str) -> None:
    """Start the persistent Chromium process if it is not already running."""
    global _CHROMIUM_PROC

    # Check if existing process is still alive
    if _CHROMIUM_PROC is not None and _CHROMIUM_PROC.poll() is None:
        return  # already running

    # Check if a Chromium is already listening on the CDP port (e.g. survived a zwis restart)
    import urllib.request
    try:
        urllib.request.urlopen(f"{_CDP_URL}/json/version", timeout=1)
        logger.info("Chromium already running at %s — reusing it", _CDP_URL)
        return
    except Exception:
        pass

    binary = _chromium_binary()
    env = {**os.environ, "DISPLAY": display}
    cmd = [
        binary,
        f"--remote-debugging-port={_CDP_PORT}",
        "--no-first-run",
        "--no-default-browser-check",
        "--disable-dev-shm-usage",
        "--disable-gpu",
        "--disable-extensions",
        "--no-sandbox",
        "--start-maximized",
        "about:blank",
    ]
    logger.info("Launching persistent Chromium: %s", " ".join(cmd))
    _CHROMIUM_PROC = subprocess.Popen(
        cmd,
        env=env,
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
        start_new_session=True,  # own process group — survives zwis Ctrl+C
    )
    # Give Chromium a moment to start up and open the debugging port
    for _ in range(20):
        time.sleep(0.3)
        try:
            urllib.request.urlopen(f"{_CDP_URL}/json/version", timeout=1)
            logger.info("Chromium CDP ready at %s", _CDP_URL)
            return
        except Exception:
            pass
    raise RuntimeError("Chromium did not start in time — CDP port not responding")


def _ensure_playwright_browser() -> None:
    """Install Playwright's Chromium if no binary is found.

    Runs `python -m playwright install chromium` using the current interpreter
    so no external tools (uvx, npm, etc.) are required.
    """
    try:
        _chromium_binary()
        return  # already installed
    except FileNotFoundError:
        pass
    import sys
    logger.info("No Chromium found — running 'python -m playwright install chromium' …")
    try:
        result = subprocess.run(
            [sys.executable, "-m", "playwright", "install", "chromium"],
            capture_output=True, text=True, timeout=300,
        )
        if result.returncode != 0:
            logger.warning("playwright install failed:\n%s\n%s", result.stdout, result.stderr)
        else:
            logger.info("Playwright Chromium installed.")
    except Exception as exc:
        logger.warning("Could not install Playwright Chromium: %s", exc)


def _auto_start_chromium() -> None:
    """Launch Chromium at import time so VNC always shows a browser window."""
    display = os.environ.get("DISPLAY", "")
    if not display:
        try:
            ps = subprocess.check_output(["pgrep", "-a", "Xtigervnc"], text=True, stderr=subprocess.DEVNULL)
            for line in ps.strip().splitlines():
                for token in line.split():
                    if token.startswith(":"):
                        display = token
                        os.environ["DISPLAY"] = display
                        break
        except Exception:
            pass
    if not display:
        return
    try:
        _chromium_binary()  # check binary exists before trying
    except FileNotFoundError:
        return
    _ensure_chromium_running(display)


# Auto-start on import so the browser is visible in VNC from the moment zwis launches.
try:
    _auto_start_chromium()
except Exception as _e:
    logger.debug("Auto-start Chromium skipped: %s", _e)


def _build_llm(provider: str | None = None, model: str | None = None) -> Any:
    """Build a browser-use compatible LLM from env/config.

    Checks for a dedicated BROWSER_AGENT_MODEL env var first, then falls back
    to the main Zwischenzug provider/model, then to sensible defaults.
    """
    ba_model = os.getenv("BROWSER_AGENT_MODEL", "").strip()

    if ba_model:
        # User explicitly set a browser-agent model
        model_id = ba_model
    elif provider and model:
        model_id = model
    else:
        # Fall back to env
        model_id = os.getenv("ZWISCHENZUG_MODEL", "").strip()
        provider = os.getenv("ZWISCHENZUG_PROVIDER", "").strip().lower()

    if not model_id:
        raise ValueError(
            "No LLM configured for browser agent. Set BROWSER_AGENT_MODEL or "
            "ZWISCHENZUG_MODEL in your .env."
        )

    from langchain_litellm import ChatLiteLLM

    # Normalize to LiteLLM format: provider/model
    if provider and not model_id.startswith(f"{provider}/"):
        litellm_model = f"{provider}/{model_id}"
    else:
        litellm_model = model_id

    llm = ChatLiteLLM(model=litellm_model, temperature=1.0)

    # browser-use probes and monkey-patches the LLM object in several ways that
    # are incompatible with Pydantic models:
    #   1. reads  llm.provider   → AttributeError on undeclared Pydantic fields
    #   2. reads  llm.model_name → None (ChatLiteLLM uses .model, not .model_name)
    #   3. sets   llm.ainvoke    → ValueError (Pydantic blocks arbitrary setattr)
    # A plain proxy class sidesteps all three without touching the Pydantic model.
    class _Proxy:
        provider = ""  # satisfies llm.provider == 'browser-use' check

        def __init__(self, wrapped, model_id: str):
            object.__setattr__(self, "_wrapped", wrapped)
            # browser-use telemetry reads llm.model_name; ChatLiteLLM has .model
            object.__setattr__(self, "model_name", model_id)

        def __getattr__(self, name):
            return getattr(object.__getattribute__(self, "_wrapped"), name)

        def __setattr__(self, name, value):
            # browser-use sets ainvoke/arun wrappers — store on the proxy so
            # they shadow the real methods without touching the Pydantic model.
            object.__setattr__(self, name, value)

    return _Proxy(llm, litellm_model)


class BrowserAgentTool(Tool):
    """Give a high-level task to an autonomous browser agent."""

    @property
    def name(self) -> str:
        return "browser_agent"

    @property
    def description(self) -> str:
        return (
            "Autonomous browser agent. Give it a task in plain English and it will "
            "navigate websites, click buttons, fill forms, scroll, take screenshots, "
            "and extract information — all on its own.\n"
            "Examples:\n"
            "- 'Go to google.com and search for OpenAI'\n"
            "- 'Go to github.com/anthropics and list the top repositories'\n"
            "- 'Fill out the contact form at example.com with test data'\n"
            "The browser is visible via VNC (port 6080) so you can watch it work."
        )

    @property
    def is_read_only(self) -> bool:
        return False

    def input_schema(self) -> dict[str, Any]:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": (
                        "The task for the browser agent to accomplish, in plain English. "
                        "Be specific about what you want it to do and what information to extract. "
                        "Use 'close' to close the browser when done inspecting."
                    ),
                },
                "max_steps": {
                    "type": "integer",
                    "description": "Maximum number of browser actions (default 25).",
                },
                "headless": {
                    "type": "boolean",
                    "description": "Run headless (no visible browser). Default false — browser is visible via VNC.",
                },
                "keep_open": {
                    "type": "boolean",
                    "description": (
                        "Keep the browser open after the task finishes so you can inspect "
                        "the page via VNC. Default true. Set false to close immediately."
                    ),
                },
            },
            "required": ["task"],
        }

    async def execute(self, ctx: ToolContext, **kwargs: Any) -> ToolOutput:
        task = kwargs.get("task", "").strip()

        # Handle "close" action to shut down a kept-open browser.
        if task.lower() == "close":
            return await self._close_browser(ctx)

        if not task:
            return ToolOutput.error("'browser_agent' requires a 'task'.")

        if not _browser_use_available():
            return ToolOutput.error("browser-use is not installed. Run: pip install zwischenzug[browser]")

        max_steps = int(kwargs.get("max_steps", 25))
        headless = kwargs.get("headless", False)
        keep_open = kwargs.get("keep_open", True)

        try:
            return await self._run_agent(ctx, task, max_steps, headless, keep_open)
        except Exception as exc:
            logger.exception("Browser agent failed")
            return ToolOutput.error(f"Browser agent failed: {exc}")

    async def _close_browser(self, ctx: ToolContext) -> ToolOutput:
        """Kill the persistent Chromium process."""
        global _CHROMIUM_PROC
        if _CHROMIUM_PROC is None or _CHROMIUM_PROC.poll() is not None:
            return ToolOutput.success("No browser running.")
        _CHROMIUM_PROC.terminate()
        try:
            _CHROMIUM_PROC.wait(timeout=5)
        except subprocess.TimeoutExpired:
            _CHROMIUM_PROC.kill()
        _CHROMIUM_PROC = None
        return ToolOutput.success("Browser closed.")

    def _ensure_display(self) -> str:
        """Return a DISPLAY value, starting Xvfb if necessary.

        Always produces a display so Chromium is visible in noVNC.
        """
        if os.environ.get("DISPLAY"):
            return os.environ["DISPLAY"]

        # Check for an already-running Xvfb or Xtigervnc
        for proc in ("Xvfb", "Xtigervnc"):
            try:
                ps = subprocess.check_output(
                    ["pgrep", "-a", proc], text=True, stderr=subprocess.DEVNULL
                )
                for line in ps.strip().splitlines():
                    for token in line.split():
                        if token.startswith(":"):
                            os.environ["DISPLAY"] = token
                            logger.info("Auto-detected DISPLAY=%s from %s", token, proc)
                            return token
            except (subprocess.CalledProcessError, FileNotFoundError):
                pass

        # Install Xvfb if missing
        import shutil
        if not shutil.which("Xvfb"):
            logger.info("Xvfb not found — installing via apt-get …")
            subprocess.run(
                ["apt-get", "install", "-y", "-q", "xvfb"],
                capture_output=True, timeout=120,
            )

        # Start a new Xvfb on :99
        display = ":99"
        try:
            subprocess.Popen(
                ["Xvfb", display, "-screen", "0", "1920x1080x24"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            time.sleep(0.5)
            os.environ["DISPLAY"] = display
            logger.info("Started Xvfb on %s", display)
        except FileNotFoundError:
            logger.warning("Xvfb still not available after install attempt")
        return display

    async def _create_session(self) -> Any:
        """Attach to our persistent Chromium via CDP."""
        from browser_use import BrowserSession
        return BrowserSession(cdp_url=_CDP_URL, highlight_elements=True)

    async def _run_agent(
        self, ctx: ToolContext, task: str, max_steps: int, headless: bool, keep_open: bool
    ) -> ToolOutput:
        from browser_use import Agent

        # Always launch Chromium with a display so it's visible in noVNC.
        # _ensure_display() starts Xvfb if needed — never falls back to headless.
        display = self._ensure_display()
        _ensure_chromium_running(display)

        # Build LLM for the browser agent
        provider = os.getenv("ZWISCHENZUG_PROVIDER", "").strip().lower()
        model = os.getenv("ZWISCHENZUG_MODEL", "").strip()
        llm = _build_llm(provider, model)

        # Disable browser-use telemetry — it reads llm internals to build
        # event payloads and fails when the LLM isn't a natively supported type.
        os.environ.setdefault("ANONYMIZED_TELEMETRY", "false")

        # Ensure Chromium is installed before browser-use tries to use uvx.
        _ensure_playwright_browser()

        # Fresh session each run — CDP if Chromium is running, headless otherwise.
        session = await self._create_session()

        # Step callback for live progress reporting
        steps_log: list[str] = []

        def on_step(state, output, step_num):
            action_names = []
            if hasattr(output, 'action') and output.action:
                for action in output.action if isinstance(output.action, list) else [output.action]:
                    name = getattr(action, 'name', None) or type(action).__name__
                    action_names.append(name)
            thought = ""
            if hasattr(output, 'current_state') and output.current_state:
                cs = output.current_state
                thought = getattr(cs, 'thought', '') or ''
            summary = f"Step {step_num}: {', '.join(action_names) or 'thinking'}"
            if thought:
                summary += f" — {thought[:120]}"
            steps_log.append(summary)
            logger.info(summary)

        try:
            agent = Agent(
                task=task,
                llm=llm,
                browser_session=session,
                register_new_step_callback=on_step,
                max_actions_per_step=3,
                use_vision=True,
            )

            history = await agent.run(max_steps=max_steps)

            # Build result summary
            parts: list[str] = []
            parts.append(f"Task: {task}")
            parts.append(f"Steps: {history.number_of_steps()}")
            parts.append(f"Done: {history.is_done()}")

            if history.is_done() and history.final_result():
                parts.append(f"\nResult:\n{history.final_result()}")

            extracted = history.extracted_content()
            if extracted:
                content = "\n".join(str(e) for e in extracted)
                if content.strip():
                    parts.append(f"\nExtracted content:\n{content[:5000]}")

            if history.has_errors():
                errors = history.errors()
                parts.append(f"\nErrors: {errors[:500]}")

            if steps_log:
                parts.append("\nAction log:\n" + "\n".join(steps_log[-15:]))

            urls = history.urls()
            if urls:
                parts.append(f"\nVisited URLs: {', '.join(urls[:10])}")

            parts.append("\nBrowser remains open — check it via VNC (port 6080). "
                         "Use browser_agent(task='close') to shut it down.")
            return ToolOutput.success("\n".join(parts))

        finally:
            # Detach the session wrapper but leave the Chromium process running.
            try:
                await session.stop()
            except Exception:
                pass