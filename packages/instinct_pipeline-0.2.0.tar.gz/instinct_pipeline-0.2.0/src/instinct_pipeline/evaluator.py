"""Evaluate compressed instincts against originals."""
from dataclasses import dataclass
from .extractor import Instinct
from .compressor import CompressedInstinct, InstinctCompressor


@dataclass
class EvalResult:
    accuracy_retention: float  # 0.0-1.0, how much accuracy is preserved
    compression_ratio: float   # size reduction factor
    inference_speedup: float   # estimated speedup
    max_error: float           # worst-case reconstruction error
    mean_error: float          # average reconstruction error

    @property
    def is_acceptable(self) -> bool:
        return self.accuracy_retention >= 0.8 and self.max_error < 0.3

    def to_dict(self) -> dict:
        return {
            "accuracy_retention": round(self.accuracy_retention, 4),
            "compression_ratio": round(self.compression_ratio, 2),
            "inference_speedup": round(self.inference_speedup, 2),
            "max_error": round(self.max_error, 4),
            "mean_error": round(self.mean_error, 4),
            "acceptable": self.is_acceptable,
        }


class InstinctEvaluator:
    """Evaluate the quality of compressed instincts."""

    def evaluate(self, originals: list[Instinct],
                 compressed: list[CompressedInstinct]) -> EvalResult:
        if len(originals) != len(compressed):
            raise ValueError("Mismatched lengths")

        decompressor = InstinctCompressor()
        errors = []
        comp_ratios = []

        for orig, comp in zip(originals, compressed):
            # Decompress and compare
            dec_inp, dec_out = decompressor.decompress(comp)
            err = self._mean_abs_error(
                orig.input_features + orig.output_features,
                dec_inp + dec_out,
            )
            errors.append(err)
            comp_ratios.append(comp.compression_ratio)

        max_err = max(errors) if errors else 0.0
        mean_err = sum(errors) / len(errors) if errors else 0.0
        accuracy = max(0.0, 1.0 - mean_err)
        avg_ratio = sum(comp_ratios) / len(comp_ratios) if comp_ratios else 1.0
        speedup = avg_ratio  # approximate: compression ratio ≈ speedup

        return EvalResult(
            accuracy_retention=accuracy,
            compression_ratio=avg_ratio,
            inference_speedup=speedup,
            max_error=max_err,
            mean_error=mean_err,
        )

    def _mean_abs_error(self, original: list[float], reconstructed: list[float]) -> float:
        if len(original) != len(reconstructed):
            return 1.0
        if not original:
            return 0.0
        errors = [abs(o - r) for o, r in zip(original, reconstructed)]
        return sum(errors) / len(errors)
