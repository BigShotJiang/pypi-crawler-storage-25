"""Extract instincts from model outputs."""
import hashlib
from dataclasses import dataclass, field


@dataclass
class Instinct:
    id: str = ""
    input_features: list[float] = field(default_factory=list)
    output_features: list[float] = field(default_factory=list)
    confidence: float = 0.5
    source_model: str = "70b"

    def __post_init__(self):
        if not self.id:
            content = f"{self.input_features[:5]}:{self.output_features[:5]}:{self.source_model}"
            self.id = hashlib.sha256(content.encode()).hexdigest()[:12]

    @property
    def dimension(self) -> int:
        return len(self.input_features)

    def to_dict(self) -> dict:
        return {"id": self.id, "dim": self.dimension, "confidence": self.confidence, "source": self.source_model}


class InstinctExtractor:
    """Extract instincts from question-answer pairs as sparse feature vectors."""

    def __init__(self, feature_dim: int = 128):
        self._feature_dim = feature_dim

    def extract(self, questions: list[str], answers: list[str],
                source_model: str = "70b") -> list[Instinct]:
        instincts = []
        for q, a in zip(questions, answers):
            inp = self._text_to_features(q)
            out = self._text_to_features(a)
            conf = min(1.0, len(a) / 200)  # longer answers = more confident
            instincts.append(Instinct(
                input_features=inp,
                output_features=out,
                confidence=conf,
                source_model=source_model,
            ))
        return instincts

    def _text_to_features(self, text: str) -> list[float]:
        """Convert text to fixed-dim feature vector via simple hashing."""
        features = [0.0] * self._feature_dim
        words = text.lower().split()
        for w in words:
            idx = hash(w) % self._feature_dim
            features[idx] += 1.0
        # Normalize
        mx = max(features) if features else 1.0
        if mx > 0:
            features = [f / mx for f in features]
        return features
