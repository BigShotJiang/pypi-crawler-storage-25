"""Binary instinct format — compact serialization for edge deployment."""
import struct
from dataclasses import dataclass
from typing import Optional
from .compressor import CompressedInstinct

# Header: 8 bytes
# magic (1B) | version (1B) | feature_count (2B uint16) | scale_bits (1B) | reserved (3B)
MAGIC = 0x1C
VERSION = 0x01
HEADER_FORMAT = "!BBH B 3s"
HEADER_SIZE = 8


@dataclass
class InstinctFormat:
    """Serialize/deserialize compressed instincts to binary."""

    @staticmethod
    def serialize(comp: CompressedInstinct) -> bytes:
        """Serialize to binary: header + quantized features + scale factors."""
        all_quantized = comp.quantized_input + comp.quantized_output
        all_scales = comp.input_scale + comp.output_scale

        feature_count = len(all_quantized)
        header = struct.pack(
            HEADER_FORMAT,
            MAGIC, VERSION, feature_count, comp.bits, b"\x00\x00\x00",
        )
        quant_bytes = bytes(all_quantized)
        scale_bytes = struct.pack(f"{len(all_scales)}f", *all_scales)
        return header + quant_bytes + scale_bytes

    @staticmethod
    def deserialize(data: bytes) -> CompressedInstinct:
        """Deserialize from binary."""
        if len(data) < HEADER_SIZE:
            raise ValueError(f"Too short: {len(data)} < {HEADER_SIZE}")

        magic, version, feature_count, bits, _ = struct.unpack(HEADER_FORMAT, data[:HEADER_SIZE])
        if magic != MAGIC:
            raise ValueError(f"Bad magic: {magic:#x} != {MAGIC:#x}")
        if version != VERSION:
            raise ValueError(f"Bad version: {version}")

        quant_bytes = data[HEADER_SIZE:HEADER_SIZE + feature_count]
        quantized = list(quant_bytes)

        scale_count = 4  # 2 scales per (input + output), each has [min, range]
        scale_start = HEADER_SIZE + feature_count
        scale_data = data[scale_start:scale_start + scale_count * 4]
        scales = list(struct.unpack(f"{scale_count}f", scale_data))

        half = feature_count // 2 if feature_count > 1 else 1
        return CompressedInstinct(
            id="",
            quantized_input=quantized[:half],
            quantized_output=quantized[half:],
            input_scale=scales[:2],
            output_scale=scales[2:],
            bits=bits,
        )

    @staticmethod
    def serialize_batch(compressed: list[CompressedInstinct]) -> bytes:
        """Serialize multiple instincts."""
        parts = []
        for c in compressed:
            data = InstinctFormat.serialize(c)
            parts.append(struct.pack("!H", len(data)) + data)
        return b"".join(parts)

    @staticmethod
    def size_estimate(n_features: int, bits: int = 4) -> int:
        """Estimate binary size for n quantized features."""
        return HEADER_SIZE + n_features * max(1, bits // 8) + 4 * 4  # + scales
