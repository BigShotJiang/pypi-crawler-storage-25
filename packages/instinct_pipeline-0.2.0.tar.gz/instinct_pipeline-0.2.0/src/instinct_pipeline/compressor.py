"""Compress instincts via quantization (7B → 1B)."""
import math
from dataclasses import dataclass, field


@dataclass
class CompressedInstinct:
    id: str
    quantized_input: list[int] = field(default_factory=list)
    quantized_output: list[int] = field(default_factory=list)
    input_scale: list[float] = field(default_factory=list)
    output_scale: list[float] = field(default_factory=list)
    bits: int = 4
    source_model: str = "1b"

    @property
    def compression_ratio(self) -> float:
        # float32 (4 bytes) vs quantized (bits/8 bytes) per feature
        float_bytes = (len(self.quantized_input) + len(self.quantized_output)) * 4
        quant_bytes = (len(self.quantized_input) + len(self.quantized_output)) * max(1, self.bits // 8)
        return float_bytes / quant_bytes if quant_bytes > 0 else 1.0

    @property
    def size_bytes(self) -> int:
        n = len(self.quantized_input) + len(self.quantized_output)
        return n * max(1, self.bits // 8) + len(self.input_scale) * 4 + len(self.output_scale) * 4


class InstinctCompressor:
    """Compress instincts via uniform quantization."""

    def __init__(self, bits: int = 4):
        self._bits = bits
        self._levels = 2 ** bits

    def compress(self, instincts: list, bits: int | None = None) -> list[CompressedInstinct]:
        bits = bits or self._bits
        compressed = []
        for inst in instincts:
            q_inp, s_inp = self._quantize(inst.input_features, bits)
            q_out, s_out = self._quantize(inst.output_features, bits)
            compressed.append(CompressedInstinct(
                id=inst.id,
                quantized_input=q_inp,
                quantized_output=q_out,
                input_scale=s_inp,
                output_scale=s_out,
                bits=bits,
                source_model=f"{bits}bit",
            ))
        return compressed

    def _quantize(self, features: list[float], bits: int) -> tuple[list[int], list[float]]:
        """Quantize float features to int using min-max scaling."""
        if not features:
            return [], [0.0, 1.0]

        levels = 2 ** bits
        mn, mx = min(features), max(features)
        scale = mx - mn if mx != mn else 1.0

        quantized = []
        for f in features:
            normalized = (f - mn) / scale
            q = min(levels - 1, max(0, int(normalized * (levels - 1))))
            quantized.append(q)

        # Store scale as [min, range] for dequantization
        return quantized, [mn, scale]

    def decompress(self, compressed: CompressedInstinct) -> tuple[list[float], list[float]]:
        """Decompress back to float features."""
        inp = self._dequantize(compressed.quantized_input, compressed.input_scale, compressed.bits)
        out = self._dequantize(compressed.quantized_output, compressed.output_scale, compressed.bits)
        return inp, out

    def _dequantize(self, quantized: list[int], scale: list[float], bits: int) -> list[float]:
        levels = 2 ** bits
        mn, rng = scale[0], scale[1]
        return [mn + (q / (levels - 1)) * rng for q in quantized]
