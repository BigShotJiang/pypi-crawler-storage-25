"""Instinct Pipeline — 70B→7B→1B compression."""
from .extractor import InstinctExtractor, Instinct
from .distiller import InstinctDistiller
from .compressor import InstinctCompressor, CompressedInstinct
from .evaluator import InstinctEvaluator, EvalResult
from .format import InstinctFormat

__version__ = "0.1.0"
__all__ = [
    "InstinctExtractor", "Instinct", "InstinctDistiller",
    "InstinctCompressor", "CompressedInstinct", "InstinctEvaluator",
    "EvalResult", "InstinctFormat",
]
