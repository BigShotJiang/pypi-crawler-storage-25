"""Distill instincts from 70B to 7B via feature clustering."""
from dataclasses import dataclass
from .extractor import Instinct


class InstinctDistiller:
    """Distill instincts by clustering features (70B → 7B dimension reduction)."""

    def __init__(self, target_size: int = 7, cluster_method: str = "average"):
        self._target = target_size
        self._method = cluster_method

    def distill(self, instincts: list[Instinct], target_size: int | None = None) -> list[Instinct]:
        """Reduce feature dimensions by clustering adjacent features."""
        target = target_size or self._target
        if not instincts:
            return []

        distilled = []
        for inst in instincts:
            new_inp = self._cluster_features(inst.input_features, target)
            new_out = self._cluster_features(inst.output_features, target)
            distilled.append(Instinct(
                input_features=new_inp,
                output_features=new_out,
                confidence=inst.confidence * 0.95,  # slight loss
                source_model=f"{target}b",
            ))
        return distilled

    def _cluster_features(self, features: list[float], target_dim: int) -> list[float]:
        """Cluster features by averaging groups."""
        if not features or target_dim <= 0:
            return [0.0] * max(1, target_dim)

        src_dim = len(features)
        if target_dim >= src_dim:
            return list(features) + [0.0] * (target_dim - src_dim)

        cluster_size = src_dim / target_dim
        result = []
        for i in range(target_dim):
            start = int(i * cluster_size)
            end = int((i + 1) * cluster_size)
            chunk = features[start:end]
            avg = sum(chunk) / len(chunk) if chunk else 0.0
            result.append(avg)
        return result
