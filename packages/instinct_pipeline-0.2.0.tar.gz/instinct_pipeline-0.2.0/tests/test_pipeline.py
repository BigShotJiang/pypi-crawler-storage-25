"""Tests for instinct pipeline."""
import pytest
from instinct_pipeline import (
    InstinctExtractor, Instinct, InstinctDistiller,
    InstinctCompressor, CompressedInstinct, InstinctEvaluator,
    EvalResult, InstinctFormat,
)


class TestExtractor:
    def test_extract(self):
        ext = InstinctExtractor(feature_dim=64)
        instincts = ext.extract(["What is X?"], ["X is a feature vector that represents knowledge"])
        assert len(instincts) == 1
        assert len(instincts[0].input_features) == 64
        assert instincts[0].source_model == "70b"

    def test_multiple(self):
        ext = InstinctExtractor(feature_dim=32)
        qs = [f"Q{i}?" for i in range(5)]
        ans = [f"Answer {i} with enough text for confidence" for i in range(5)]
        instincts = ext.extract(qs, ans)
        assert len(instincts) == 5
        assert all(inst.dimension == 32 for inst in instincts)


class TestDistiller:
    def test_distill(self):
        ext = InstinctExtractor(feature_dim=128)
        instincts = ext.extract(["Q?"], ["A good answer with enough words"])
        distiller = InstinctDistiller()
        distilled = distiller.distill(instincts, target_size=16)
        assert len(distilled) == 1
        assert len(distilled[0].input_features) == 16
        assert distilled[0].source_model == "16b"

    def test_confidence_slight_loss(self):
        ext = InstinctExtractor(feature_dim=64)
        instincts = ext.extract(["Q?"], ["A" * 200])
        original_conf = instincts[0].confidence
        distiller = InstinctDistiller()
        distilled = distiller.distill(instincts, target_size=8)
        assert distilled[0].confidence <= original_conf


class TestCompressor:
    def test_compress(self):
        inst = Instinct(input_features=[0.1, 0.5, 0.9], output_features=[0.2, 0.6, 0.8])
        comp = InstinctCompressor(bits=4)
        compressed = comp.compress([inst])
        assert len(compressed) == 1
        assert all(0 <= q < 16 for q in compressed[0].quantized_input)

    def test_round_trip(self):
        inst = Instinct(input_features=[0.1, 0.5, 0.9], output_features=[0.2, 0.6, 0.8])
        comp = InstinctCompressor(bits=8)
        compressed = comp.compress([inst])[0]
        dec_inp, dec_out = comp.decompress(compressed)
        for orig, dec in zip(inst.input_features, dec_inp):
            assert abs(orig - dec) < 0.1  # 8-bit should be close

    def test_compression_ratio(self):
        inst = Instinct(input_features=[0.1, 0.5] * 50, output_features=[0.2, 0.8] * 50)
        comp = InstinctCompressor(bits=4)
        compressed = comp.compress([inst])[0]
        assert compressed.compression_ratio > 1.0


class TestEvaluator:
    def test_evaluate(self):
        ext = InstinctExtractor(feature_dim=32)
        instincts = ext.extract(["Q?"], ["A" * 100])
        comp = InstinctCompressor(bits=8)
        compressed = comp.compress(instincts)
        evaluator = InstinctEvaluator()
        result = evaluator.evaluate(instincts, compressed)
        assert result.accuracy_retention > 0.5
        assert result.compression_ratio > 1.0

    def test_acceptable(self):
        r = EvalResult(accuracy_retention=0.9, compression_ratio=4.0, inference_speedup=4.0, max_error=0.1, mean_error=0.05)
        assert r.is_acceptable


class TestBinaryFormat:
    def test_serialize_deserialize(self):
        comp = CompressedInstinct(
            id="test",
            quantized_input=[1, 5, 10],
            quantized_output=[3, 7, 12],
            input_scale=[0.0, 1.0],
            output_scale=[0.0, 1.0],
            bits=4,
        )
        data = InstinctFormat.serialize(comp)
        restored = InstinctFormat.deserialize(data)
        assert restored.quantized_input == [1, 5, 10]
        assert restored.quantized_output == [3, 7, 12]
        assert restored.bits == 4

    def test_size_estimate(self):
        size = InstinctFormat.size_estimate(100, bits=4)
        assert size > 0
        assert size < 1000  # should be compact
