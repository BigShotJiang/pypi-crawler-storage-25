//! Standard library sweep.

use anyhow::Result;
use kcmc::ModelingCmd;
use kcmc::each_cmd as mcmd;
use kcmc::length_unit::LengthUnit;
use kcmc::shared::BodyType;
use kittycad_modeling_cmds::id::ModelingCmdId;
use kittycad_modeling_cmds::shared::RelativeTo;
use kittycad_modeling_cmds::{self as kcmc};
use serde::Serialize;

use super::DEFAULT_TOLERANCE_MM;
use super::args::TyF64;
use crate::errors::KclError;
use crate::errors::KclErrorDetails;
use crate::execution::ExecState;
use crate::execution::Helix;
use crate::execution::KclValue;
use crate::execution::ModelingCmdMeta;
use crate::execution::ProfileClosed;
use crate::execution::Segment;
use crate::execution::Sketch;
use crate::execution::Solid;
use crate::execution::types::ArrayLen;
use crate::execution::types::RuntimeType;
use crate::parsing::ast::types::TagNode;
use crate::std::Args;
use crate::std::extrude::build_segment_surface_sketch;
use crate::std::extrude::do_post_extrude;
use crate::std::revolve::coerce_revolve_targets;

/// A path to sweep along.
#[derive(Debug, Clone, Serialize, PartialEq, ts_rs::TS)]
#[ts(export)]
#[serde(untagged)]
#[allow(clippy::large_enum_variant)]
pub enum SweepPath {
    Sketch(Sketch),
    Helix(Box<Helix>),
    Segments(Vec<Segment>),
}

/// The outer (typical) sweep path gets converted to this, losing some of its variants in the conversion.
#[allow(clippy::large_enum_variant)]
enum InnerSweepPath {
    Sketch(Sketch),
    Helix(Box<Helix>),
}

/// Create a 3D surface or solid by sweeping a sketch along a path.
pub async fn sweep(exec_state: &mut ExecState, args: Args) -> Result<KclValue, KclError> {
    let sketch_values = args.get_unlabeled_kw_arg(
        "sketches",
        &RuntimeType::Array(
            Box::new(RuntimeType::Union(vec![RuntimeType::sketch(), RuntimeType::segment()])),
            ArrayLen::Minimum(1),
        ),
        exec_state,
    )?;
    let path: SweepPath = args.get_kw_arg(
        "path",
        &RuntimeType::Union(vec![
            RuntimeType::sketch(),
            RuntimeType::helix(),
            RuntimeType::Array(Box::new(RuntimeType::segment()), ArrayLen::Minimum(1)),
        ]),
        exec_state,
    )?;
    let sectional = args.get_kw_arg_opt("sectional", &RuntimeType::bool(), exec_state)?;
    let tolerance: Option<TyF64> = args.get_kw_arg_opt("tolerance", &RuntimeType::length(), exec_state)?;
    let relative_to: Option<String> = args.get_kw_arg_opt("relativeTo", &RuntimeType::string(), exec_state)?;
    let tag_start = args.get_kw_arg_opt("tagStart", &RuntimeType::tag_decl(), exec_state)?;
    let tag_end = args.get_kw_arg_opt("tagEnd", &RuntimeType::tag_decl(), exec_state)?;
    let body_type: Option<BodyType> = args.get_kw_arg_opt("bodyType", &RuntimeType::string(), exec_state)?;
    let version: Option<u32> = args.get_kw_arg_opt("version", &RuntimeType::count(), exec_state)?;
    let path = match path {
        SweepPath::Segments(segments) => InnerSweepPath::Sketch(
            build_segment_surface_sketch(segments, exec_state, &args.ctx, args.source_range).await?,
        ),
        SweepPath::Sketch(sketch) => InnerSweepPath::Sketch(sketch),
        SweepPath::Helix(helix) => InnerSweepPath::Helix(helix),
    };

    let sketches = coerce_revolve_targets(
        sketch_values,
        body_type.unwrap_or_default(),
        tag_start.as_ref(),
        tag_end.as_ref(),
        exec_state,
        &args.ctx,
        args.source_range,
    )
    .await?;

    let value = inner_sweep(
        sketches,
        path,
        sectional,
        tolerance,
        relative_to,
        tag_start,
        tag_end,
        body_type,
        version,
        exec_state,
        args,
    )
    .await?;
    Ok(value.into())
}

#[allow(clippy::too_many_arguments)]
async fn inner_sweep(
    sketches: Vec<Sketch>,
    path: InnerSweepPath,
    sectional: Option<bool>,
    tolerance: Option<TyF64>,
    relative_to: Option<String>,
    tag_start: Option<TagNode>,
    tag_end: Option<TagNode>,
    body_type: Option<BodyType>,
    version: Option<u32>,
    exec_state: &mut ExecState,
    args: Args,
) -> Result<Vec<Solid>, KclError> {
    let body_type = body_type.unwrap_or_default();
    if matches!(body_type, BodyType::Solid) && sketches.iter().any(|sk| matches!(sk.is_closed, ProfileClosed::No)) {
        return Err(KclError::new_semantic(KclErrorDetails::new(
            "Cannot solid sweep an open profile. Either close the profile, or use a surface sweep.".to_owned(),
            vec![args.source_range],
        )));
    }

    let trajectory = ModelingCmdId::from(match path {
        InnerSweepPath::Sketch(sketch) => sketch.id,
        InnerSweepPath::Helix(helix) => helix.value,
    });
    let relative_to = match relative_to.as_deref() {
        Some("sketchPlane") => RelativeTo::SketchPlane,
        Some("trajectoryCurve") | None => RelativeTo::TrajectoryCurve,
        Some(_) => {
            return Err(KclError::new_syntax(crate::errors::KclErrorDetails::new(
                "If you provide relativeTo, it must either be 'sketchPlane' or 'trajectoryCurve'".to_owned(),
                vec![args.source_range],
            )));
        }
    };

    let version = version.map(|v| u8::try_from(v).unwrap_or(u8::MAX));

    let mut solids = Vec::new();
    for sketch in &sketches {
        let id = exec_state.next_uuid();
        exec_state
            .batch_modeling_cmd(
                ModelingCmdMeta::from_args_id(exec_state, &args, id),
                ModelingCmd::from(
                    mcmd::Sweep::builder()
                        .target(sketch.id.into())
                        .trajectory(trajectory)
                        .sectional(sectional.unwrap_or(false))
                        .tolerance(LengthUnit(
                            tolerance.as_ref().map(|t| t.to_mm()).unwrap_or(DEFAULT_TOLERANCE_MM),
                        ))
                        .relative_to(relative_to)
                        .body_type(body_type)
                        .maybe_version(version)
                        .build(),
                ),
            )
            .await?;

        solids.push(
            do_post_extrude(
                sketch,
                id.into(),
                sectional.unwrap_or(false),
                &super::extrude::NamedCapTags {
                    start: tag_start.as_ref(),
                    end: tag_end.as_ref(),
                },
                kittycad_modeling_cmds::shared::ExtrudeMethod::New,
                exec_state,
                &args,
                None,
                None,
                body_type,
                crate::std::extrude::BeingExtruded::Sketch,
            )
            .await?,
        );
    }

    // Hide the artifact from the sketch or helix.
    exec_state
        .batch_modeling_cmd(
            ModelingCmdMeta::from_args(exec_state, &args),
            ModelingCmd::from(
                mcmd::ObjectVisible::builder()
                    .object_id(trajectory.into())
                    .hidden(true)
                    .build(),
            ),
        )
        .await?;

    Ok(solids)
}
