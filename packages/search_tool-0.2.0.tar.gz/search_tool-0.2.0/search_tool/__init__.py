"""
search_tool: Unified web search interface package.
"""

from .search import SearchTool
from .config import SearchConfig, SearchEngine, SafeSearch, TimeRange
from .playwright_manager import PlaywrightManager
from .cookie_sync import sync_cookies_to_playwright
from .models import BaseResult, WebResult, ImageResult, VideoResult, NewsResult, XResult, SearchResults
from .exceptions import SearchToolError, SearchEngineError, ParsingError, PlaywrightError, ConfigurationError

__all__ = [
    "SearchTool",
    "SearchConfig",
    "SearchEngine",
    "SafeSearch",
    "TimeRange",
    "BaseResult",
    "WebResult",
    "ImageResult",
    "VideoResult",
    "NewsResult",
    "XResult",
    "SearchResults",
    "SearchToolError",
    "SearchEngineError",
    "ParsingError",
    "PlaywrightError",
    "PlaywrightManager",
    "ConfigurationError",
    "sync_cookies_to_playwright",
]
