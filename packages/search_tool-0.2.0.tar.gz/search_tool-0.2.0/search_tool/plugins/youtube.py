"""YouTube search plugin."""

from __future__ import annotations

import asyncio
import re
import sys

from playwright.async_api import TimeoutError
from pydantic import HttpUrl

from ..exceptions import SearchEngineError
from ..models import SearchResults, VideoResult
from .base import SearchContext


def views_to_count(view_text: str) -> int:
    text = view_text.strip()
    if text.startswith("No "):
        return 0

    match = re.search(r"([\d,.]+)\s*([KMB]?)", text, re.IGNORECASE)
    if not match:
        return 0

    value = float(match.group(1).replace(",", ""))
    suffix = match.group(2).upper()
    multiplier = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}.get(suffix, 1)
    return int(value * multiplier)


class YouTubeSearchPlugin:
    name = "youtube"
    aliases = ("yt",)
    result_types = ("video",)
    requires_browser = True
    browser_headless = False

    async def search(self, query: str, context: SearchContext) -> SearchResults:
        if context.playwright_manager is None:
            raise SearchEngineError("YouTube plugin requires an initialized Playwright manager.")

        if sys.platform == "win32":
            asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())

        page = await context.playwright_manager.get_page()
        try:
            await page.goto("https://www.youtube.com", wait_until="domcontentloaded", timeout=30000)

            for selector in ("button:has-text('I agree')", "button:has-text('Accept all')"):
                button = page.locator(selector)
                first_button = button.first
                if await button.count() and await first_button.is_visible():
                    await first_button.click()
                    break

            await page.type("input#search", query)
            await page.wait_for_timeout(1000)
            await page.keyboard.press("Enter")
            await page.wait_for_timeout(5000)
            await page.mouse.wheel(0, 10000)
            await page.wait_for_timeout(5000)

            try:
                await page.wait_for_selector("ytd-video-renderer", timeout=30000)
            except TimeoutError:
                raise SearchEngineError("Could not find YouTube video results within 30 seconds.")

            video_results: list[VideoResult] = []
            result_elements = await page.query_selector_all("ytd-video-renderer")

            for position, result in enumerate(result_elements, start=1):
                video_title = await result.query_selector("#video-title")
                if video_title is None:
                    continue

                href = await video_title.get_attribute("href")
                if not href or "/shorts" in href or "v=" not in href:
                    continue

                video_id = href.split("v=", 1)[1].split("&", 1)[0]
                title = (await video_title.inner_text()).strip()
                views = 0
                published = None

                for item in await result.query_selector_all(".inline-metadata-item"):
                    item_text = (await item.inner_text()).strip()
                    if "views" in item_text:
                        views = views_to_count(item_text)
                    elif "ago" in item_text:
                        published = item_text
                    if views and published:
                        break

                video_results.append(
                    VideoResult(
                        title=title,
                        search_engine=self.name,
                        url=HttpUrl(f"https://www.youtube.com/watch?v={video_id}"),
                        platform=self.name,
                        view_count=views,
                        description=published,
                        metadata={"video_id": video_id, "published_text": published, "position": position},
                    )
                )

                if len(video_results) >= context.config.num_results:
                    break

            return SearchResults(
                query=query,
                search_engine=self.name,
                video_results=video_results,
            )
        finally:
            await context.playwright_manager.close_page(page)
