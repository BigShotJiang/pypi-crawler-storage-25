"""Search plugin registry and discovery."""

from __future__ import annotations

import importlib
import importlib.util
import os
import platform
import pkgutil
import sys
from importlib.metadata import entry_points
from pathlib import Path
from typing import Callable, cast

from ..engines.base_engine import BaseSearchEngine
from ..engines.brave import BraveEngine
from ..engines.duckduckgo import DuckDuckGoEngine
from ..engines.google import GoogleEngine
from .base import EngineSearchPlugin, SearchPlugin

PluginFactory = Callable[[], SearchPlugin]


class SearchPluginRegistry:
    """Registry that resolves search plugin names and aliases."""

    def __init__(self) -> None:
        self._plugins: dict[str, SearchPlugin] = {}
        self._aliases: dict[str, str] = {}

    def register(self, plugin: SearchPlugin) -> None:
        name = self.normalize(plugin.name)
        if name in self._plugins:
            raise ValueError(f"Search plugin '{plugin.name}' is already registered.")

        self._plugins[name] = plugin
        for alias in plugin.aliases:
            alias_name = self.normalize(alias)
            if alias_name in self._aliases or alias_name in self._plugins:
                raise ValueError(f"Search plugin alias '{alias}' conflicts with an existing plugin.")
            self._aliases[alias_name] = name

    def get(self, name: str) -> SearchPlugin | None:
        normalized = self.normalize(name)
        canonical = self._aliases.get(normalized, normalized)
        return self._plugins.get(canonical)

    def require(self, name: str) -> SearchPlugin:
        plugin = self.get(name)
        if plugin is None:
            supported = ", ".join(self.available_names())
            raise KeyError(f"Search plugin '{name}' is not supported. Supported engines are: {supported}")
        return plugin

    def available_names(self) -> list[str]:
        names: list[str] = []
        for name, plugin in sorted(self._plugins.items()):
            names.append(name)
            names.extend(sorted(plugin.aliases))
        return names

    @staticmethod
    def normalize(name: str) -> str:
        return name.strip().lower().replace("_", "-")


def _load_entry_point_plugin(value: object) -> SearchPlugin:
    if callable(value) and not hasattr(value, "search"):
        factory = cast(PluginFactory, value)
        value = factory()
    return cast(SearchPlugin, value)


def _load_module_plugin(value: object) -> SearchPlugin:
    if callable(value) and not hasattr(value, "search"):
        factory = cast(PluginFactory, value)
        value = factory()
    return cast(SearchPlugin, value)


def _get_user_config_dir() -> Path:
    if platform.system() == "Windows":
        appdata = os.environ.get("APPDATA")
        if appdata:
            return Path(appdata) / "search_tool"
    return Path.home() / ".config" / "search_tool"


PLUGIN_DIR = _get_user_config_dir() / "plugins"


def _load_thirdparty_plugins(registry: SearchPluginRegistry) -> None:
    init_file = PLUGIN_DIR / "__init__.py"
    if not init_file.is_file():
        return

    spec = importlib.util.spec_from_file_location(
        "search_tool_user_plugins",
        str(init_file),
        submodule_search_locations=[str(PLUGIN_DIR)],
    )
    if spec is None or spec.loader is None:
        return

    package = importlib.util.module_from_spec(spec)
    sys.modules["search_tool_user_plugins"] = package
    spec.loader.exec_module(package)

    for module_info in pkgutil.iter_modules([str(PLUGIN_DIR)]):
        module = importlib.import_module(f"search_tool_user_plugins.{module_info.name}")
        for attribute_name in ("plugin", "PLUGIN", "create_plugin"):
            value = getattr(module, attribute_name, None)
            if value is not None:
                registry.register(_load_module_plugin(value))
                break


def create_default_registry(
    load_entry_points: bool = True,
    load_thirdparty_plugins: bool = True,
    engine_classes: dict[str, type[BaseSearchEngine]] | None = None,
) -> SearchPluginRegistry:
    registry = SearchPluginRegistry()
    engines = {
        "google": cast(type[BaseSearchEngine], GoogleEngine),
        "duckduckgo": cast(type[BaseSearchEngine], DuckDuckGoEngine),
        "brave": cast(type[BaseSearchEngine], BraveEngine),
    }
    if engine_classes:
        engines.update(engine_classes)

    registry.register(cast(SearchPlugin, EngineSearchPlugin("google", engines["google"])))
    registry.register(cast(SearchPlugin, EngineSearchPlugin("duckduckgo", engines["duckduckgo"], aliases=("ddg",))))
    registry.register(cast(SearchPlugin, EngineSearchPlugin("brave", engines["brave"])))

    from .youtube import YouTubeSearchPlugin

    registry.register(cast(SearchPlugin, YouTubeSearchPlugin()))

    from .twitter import TwitterSearchPlugin

    registry.register(cast(SearchPlugin, TwitterSearchPlugin()))

    if load_thirdparty_plugins:
        _load_thirdparty_plugins(registry)

    if load_entry_points:
        discovered = entry_points(group="search_tool.plugins")
        for entry_point in discovered:
            registry.register(_load_entry_point_plugin(entry_point.load()))

    return registry
