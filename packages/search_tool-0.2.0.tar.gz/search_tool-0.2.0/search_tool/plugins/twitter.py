"""Twitter/X search plugin."""

from __future__ import annotations

import re
import sys
from urllib.parse import quote_plus, urljoin

from playwright.async_api import TimeoutError
from pydantic import HttpUrl

from ..exceptions import SearchEngineError
from ..models import SearchResults, XResult
from .base import SearchContext


LOGIN_WARNING = (
    "X/Twitter login required. Use a persistent profile, or run --sync-cookies with "
    "--sync-domains .x.com .twitter.com before searching X."
)


class TwitterSearchPlugin:
    name = "twitter"
    aliases = ("x",)
    result_types = ("x",)
    requires_browser = True
    browser_headless = None

    async def search(self, query: str, context: SearchContext) -> SearchResults:
        if context.playwright_manager is None:
            raise SearchEngineError("Twitter plugin requires an initialized Playwright manager.")

        limit = min(context.config.num_results, 10)
        verbose = context.config.verbose
        page = await context.playwright_manager.get_page()
        try:
            await page.goto("https://x.com/home", wait_until="domcontentloaded", timeout=context.config.timeout * 1000)
            await page.wait_for_timeout(1000)
            self._debug(verbose, f"opened {getattr(page, 'url', 'https://x.com/home')}")
            await self._raise_if_login_page(page)

            try:
                search_input = await page.wait_for_selector('input[placeholder="Search"]', timeout=15000)
            except TimeoutError:
                await self._raise_if_login_page(page)
                raise SearchEngineError("Could not find X search input within 15 seconds.")

            if search_input is None:
                raise SearchEngineError("Could not find X search input element.")
            await search_input.click()
            await search_input.fill(query)
            await page.keyboard.press("Enter")
            self._debug(verbose, "submitted X search query")

            try:
                await page.wait_for_selector('article[data-testid="tweet"], article', timeout=30000)
            except TimeoutError:
                await self._raise_if_login_page(page)
                raise SearchEngineError("Could not find X search results within 30 seconds.")

            x_results: list[XResult] = []
            seen_urls: set[str] = set()

            for _ in range(5):
                await self._append_visible_tweets(
                    page, query=query, limit=limit, seen_urls=seen_urls, results=x_results, verbose=verbose
                )
                if len(x_results) >= limit:
                    break
                await page.mouse.wheel(0, 3000)
                await page.wait_for_timeout(1500)

            self._debug(verbose, f"returning {len(x_results)} X results")
            return SearchResults(query=query, search_engine=self.name, x_results=x_results)
        finally:
            await context.playwright_manager.close_page(page)

    async def _raise_if_login_page(self, page) -> None:
        current_url = getattr(page, "url", "")
        if self._is_login_url(current_url):
            raise SearchEngineError(LOGIN_WARNING)

    @staticmethod
    def _is_login_url(url: str) -> bool:
        return "/login" in url or "/i/flow/login" in url

    async def _append_visible_tweets(
        self,
        page,
        *,
        query: str,
        limit: int,
        seen_urls: set[str],
        results: list[XResult],
        verbose: bool,
    ) -> None:
        tweet_elements = await page.query_selector_all('article[data-testid="tweet"], article')
        self._debug(verbose, f"found {len(tweet_elements)} visible tweet candidates")
        for position, tweet in enumerate(tweet_elements, start=1):
            if len(results) >= limit:
                break

            text = (await tweet.inner_text()).strip()
            if not text:
                continue

            url = await self._tweet_url(tweet)
            if url is None:
                url = f"https://x.com/search?q={quote_plus(query)}&src=typed_query&result={position}"
            if url in seen_urls:
                continue

            seen_urls.add(url)
            xhandle = await self._xhandle(tweet, text)
            author_name = self._author_name_from_text(text, xhandle)
            metrics = await self._tweet_metrics(tweet, text, verbose=verbose)
            title = author_name or xhandle or self._title_from_tweet_text(text)
            results.append(
                XResult(
                    title=title,
                    search_engine=self.name,
                    url=HttpUrl(url),
                    text=text,
                    xhandle=xhandle,
                    author_name=author_name,
                    replies=metrics["replies"],
                    reposts=metrics["reposts"],
                    likes=metrics["likes"],
                    views=metrics["views"],
                    position=len(results) + 1,
                    metadata={"query": query, "source_position": position},
                )
            )

    async def _tweet_url(self, tweet) -> str | None:
        links = await tweet.query_selector_all('a[href*="/status/"]')
        for link in links:
            href = await link.get_attribute("href")
            if href:
                return str(urljoin("https://x.com", href))
        return None

    @staticmethod
    def _title_from_tweet_text(text: str) -> str:
        first_line = next((line.strip() for line in text.splitlines() if line.strip()), "")
        return first_line[:120] or "X post"

    @staticmethod
    def _debug(verbose: bool, message: str) -> None:
        if verbose:
            print(f"Twitter plugin: {message}", file=sys.stderr)

    async def _xhandle(self, tweet, text: str) -> str | None:
        handle = self._xhandle_from_text(text)
        if handle:
            return handle

        links = await tweet.query_selector_all('a[href^="/"]')
        for link in links:
            href = await link.get_attribute("href")
            if not href or "/status/" in href:
                continue
            match = re.fullmatch(r"/([A-Za-z0-9_]{1,15})", href)
            if match:
                return f"@{match.group(1)}"
        return None

    @staticmethod
    def _xhandle_from_text(text: str) -> str | None:
        match = re.search(r"(?<![\w.])@([A-Za-z0-9_]{1,15})\b", text)
        if not match:
            return None
        return f"@{match.group(1)}"

    @staticmethod
    def _author_name_from_text(text: str, xhandle: str | None) -> str | None:
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if not lines:
            return None
        if xhandle is None:
            return lines[0]

        try:
            handle_index = lines.index(xhandle)
        except ValueError:
            handle_index = next((i for i, line in enumerate(lines) if xhandle in line), -1)

        if handle_index > 0:
            return lines[handle_index - 1]
        if lines[0] != xhandle:
            return lines[0]
        return None

    async def _tweet_metrics(self, tweet, text: str, *, verbose: bool = False) -> dict[str, int | None]:
        labels = [text]
        labels.extend(await self._aria_labels(tweet, '[data-testid="reply"]'))
        labels.extend(await self._aria_labels(tweet, '[data-testid="retweet"], [data-testid="unretweet"]'))
        labels.extend(await self._aria_labels(tweet, '[data-testid="like"], [data-testid="unlike"]'))
        labels.extend(await self._aria_labels(tweet, 'a[href$="/analytics"], a[aria-label*="Views"]'))
        combined = "\n".join(label for label in labels if label)

        return {
            "replies": self._metric_from_text(combined, ("reply", "replies"), verbose=verbose),
            "reposts": self._metric_from_text(
                combined, ("repost", "reposts", "retweet", "retweets"), verbose=verbose
            ),
            "likes": self._metric_from_text(combined, ("like", "likes"), verbose=verbose),
            "views": self._metric_from_text(combined, ("view", "views"), verbose=verbose),
        }

    async def _aria_labels(self, tweet, selector: str) -> list[str]:
        labels: list[str] = []
        for element in await tweet.query_selector_all(selector):
            label = await element.get_attribute("aria-label")
            if label:
                labels.append(label)
        return labels

    @classmethod
    def _metric_from_text(cls, text: str, words: tuple[str, ...], *, verbose: bool = False) -> int | None:
        number_pattern = r"(\d[\d,]*(?:\.\d+)?)\s*([KMB]?)"
        for word in words:
            patterns = (
                rf"{number_pattern}\s+{word}\b",
                rf"{word}\b[^\d\n]*{number_pattern}",
            )
            for pattern in patterns:
                match = re.search(pattern, text, re.IGNORECASE)
                if match:
                    return cls._count_to_int(match.group(1), match.group(2), verbose=verbose)
        return None

    @staticmethod
    def _count_to_int(value_text: str, suffix: str, *, verbose: bool = False) -> int | None:
        normalized = value_text.replace(",", "")
        try:
            value = float(normalized)
        except ValueError:
            if verbose:
                print(f"Twitter plugin: ignoring unparsable metric value {value_text!r}", file=sys.stderr)
            return None
        multiplier = {"K": 1_000, "M": 1_000_000, "B": 1_000_000_000}.get(suffix.upper(), 1)
        return int(value * multiplier)
