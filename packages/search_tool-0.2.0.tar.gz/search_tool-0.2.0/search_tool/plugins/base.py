"""Base types for search plugins."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Protocol, runtime_checkable

from ..config import SearchConfig, SearchEngine
from ..engines.base_engine import BaseSearchEngine
from ..models import SearchResults
from ..playwright_manager import PlaywrightManager


@dataclass(frozen=True)
class SearchContext:
    """Runtime dependencies passed to plugins."""

    config: SearchConfig
    playwright_manager: PlaywrightManager | None = None


@runtime_checkable
class SearchPlugin(Protocol):
    """Common interface implemented by built-in and external search plugins."""

    name: str
    aliases: tuple[str, ...]
    result_types: tuple[str, ...]
    requires_browser: bool
    browser_headless: bool | None

    async def search(self, query: str, context: SearchContext) -> SearchResults:
        """Run a search and return structured results."""


class EngineSearchPlugin:
    """Adapter that exposes existing browser-backed engines as plugins."""

    result_types: tuple[str, ...] = ("web",)
    requires_browser = True

    def __init__(
        self,
        name: str,
        engine_class: type[BaseSearchEngine],
        aliases: tuple[str, ...] = (),
    ):
        self.name = name
        self.aliases: tuple[str, ...] = aliases
        self.engine_class = engine_class
        self.browser_headless: bool | None = None

    async def search(self, query: str, context: SearchContext) -> SearchResults:
        if context.playwright_manager is None:
            raise RuntimeError(f"Plugin '{self.name}' requires an initialized Playwright manager.")

        engine_config = context.config
        try:
            engine_config = context.config.model_copy(update={"search_engine": SearchEngine(self.name)})
        except ValueError:
            engine_config = context.config.model_copy(update={"search_engine": self.name})

        engine = self.engine_class(config=engine_config, playwright_manager=context.playwright_manager)
        return await engine.search(query=query)
