"""
CLI for the search_tool package.
"""

import argparse
import asyncio
import contextlib
import io
import json
import os
import platform
import subprocess
import sys
from .search import SearchTool
from .config import SearchConfig
from .exceptions import ConfigurationError, SearchEngineError
from .playwright_manager import clear_browser_profile
from .plugins.registry import create_default_registry, PLUGIN_DIR


async def _run_with_optional_output(coro, *, verbose: bool, json_output: bool = False):
    if verbose and not json_output:
        return await coro
    output_stream = sys.stderr if verbose and json_output else io.StringIO()
    with contextlib.redirect_stdout(output_stream):
        return await coro


_EXAMPLE_PLUGIN_TEMPLATE = '''\
"""Example search-tool plugin."""

from search_tool.models import SearchResults
from search_tool.plugins.base import SearchContext


class ExamplePlugin:
    name = "example"
    aliases = ("ex",)
    result_types = ("web",)
    requires_browser = False

    async def search(self, query: str, context: SearchContext) -> SearchResults:
        return SearchResults(query=query, search_engine=self.name)


def create_plugin():
    return ExamplePlugin()
'''


def _is_playwright_chromium_installed() -> bool:
    try:
        from playwright.sync_api import sync_playwright

        with sync_playwright() as p:
            path = p.chromium.executable_path
            return bool(path) and os.path.exists(path)
    except Exception:
        return False


def _has_results(results_obj) -> bool:
    return any(
        [
            results_obj.web_results,
            results_obj.video_results,
            results_obj.image_results,
            results_obj.news_results,
            results_obj.x_results,
        ]
    )


def _print_search_results(results_obj, *, verbose: bool) -> None:
    if verbose:
        print('\nSearch Results:')

    for i, result in enumerate(results_obj.web_results, 1):
        print(f'{i}. {result.title}')
        print(f'   URL: {result.url}')
        if result.description:
            print(f'   Description: {result.description}')

    for i, result in enumerate(results_obj.video_results, 1):
        print(f'{i}. {result.title}')
        print(f'   URL: {result.url}')
        if result.view_count is not None:
            print(f'   Views: {result.view_count}')
        if result.description:
            print(f'   Description: {result.description}')

    for i, result in enumerate(results_obj.image_results, 1):
        print(f'{i}. {result.title}')
        print(f'   Image URL: {result.image_url}')
        print(f'   Source URL: {result.source_url}')

    for i, result in enumerate(results_obj.news_results, 1):
        print(f'{i}. {result.title}')
        print(f'   URL: {result.url}')
        if result.source_name:
            print(f'   Source: {result.source_name}')
        if result.snippet:
            print(f'   Snippet: {result.snippet}')

    for i, result in enumerate(results_obj.x_results, 1):
        print(f'{i}. {result.title}')
        print(f'   URL: {result.url}')
        if result.xhandle:
            print(f'   Handle: {result.xhandle}')
        print(f'   Text: {result.text}')


def _normalize_output_format(output_format: str) -> str:
    if output_format in {'j', 'json'}:
        return 'json'
    return 'markdown'


def _result_to_json_object(result, *, result_type: str, link_field: str = 'url') -> dict:
    result_data = result.model_dump(
        mode='json',
        exclude_none=True,
        exclude_defaults=True,
        exclude={'retrieved_at', 'search_engine', 'metadata', 'title'},
    )
    link = result_data.pop(link_field)
    return {
        'title': result.title,
        'link': link,
        'type': result_type,
        **result_data,
    }


def _search_results_json(results_obj) -> dict[str, list[dict]]:
    search_results: list[dict] = []
    search_results.extend(_result_to_json_object(result, result_type='web') for result in results_obj.web_results)
    search_results.extend(_result_to_json_object(result, result_type='video') for result in results_obj.video_results)
    search_results.extend(
        _result_to_json_object(result, result_type='image', link_field='source_url')
        for result in results_obj.image_results
    )
    search_results.extend(_result_to_json_object(result, result_type='news') for result in results_obj.news_results)
    search_results.extend(_result_to_json_object(result, result_type='x') for result in results_obj.x_results)
    return {'search_results': search_results}


def _print_json_search_results(results_obj) -> None:
    print(json.dumps(_search_results_json(results_obj), indent=2, ensure_ascii=False))


async def run_search():
    plugin_registry = create_default_registry()
    available_engines = plugin_registry.available_names()

    parser = argparse.ArgumentParser(description='Search the web using various engines.')
    parser.add_argument(
        '--engine',
        '-e',
        default='ddg',
        help=f'The search engine to use ({", ".join(available_engines)}).',
    )
    parser.add_argument('query', nargs='*', help='The search query.')
    parser.add_argument('--num-results', '-n', type=int, default=10, help='Number of results to fetch.')
    parser.add_argument(
        '--pages',
        '-p',
        type=int,
        default=0,
        help='Number of result pages or posts to expand when supported.',
    )
    parser.add_argument('--timeout', type=int, default=10, help='Timeout in seconds for initial page load.')
    parser.add_argument(
        '--output-format',
        '-o',
        default='markdown',
        choices=['markdown', 'md', 'm', 'json', 'j'],
        help='Output format: markdown or json.',
    )
    parser.add_argument(
        '--verbose',
        '-v',
        action='store_true',
        help='Print progress and diagnostic information.',
    )
    parser.add_argument(
        '--headless',
        action=argparse.BooleanOptionalAction,
        default=True,
        help='Run browser in headless mode.',
    )
    parser.add_argument(
        '--no-persistent-profile',
        action='store_true',
        help='Do not use a persistent browser profile.',
    )
    parser.add_argument(
        '--clear-browser-profile',
        action='store_true',
        help='Clear the browser profile and exit.',
    )
    parser.add_argument(
        '--sync-cookies',
        choices=['chrome', 'firefox', 'edge', 'brave', 'safari', 'opera'],
        help='Sync cookies from a local browser to Playwright profile.',
    )
    parser.add_argument(
        '--sync-domains',
        nargs='+',
        help='Specific domains to sync cookies for (e.g., .x.com .twitter.com).',
    )
    parser.add_argument(
        '--init',
        '-i',
        action='store_true',
        help='Create the user plugins directory, verify Playwright setup, and exit.',
    )

    args = parser.parse_args()

    if args.clear_browser_profile:
        clear_browser_profile()
        return

    if args.sync_cookies:
        from .cookie_sync import sync_cookies_to_playwright

        print(f"Syncing cookies from {args.sync_cookies}...")
        try:
            count = await sync_cookies_to_playwright(args.sync_cookies, domains=args.sync_domains)
            print(f"Successfully synced {count} cookies to Playwright profile.")
        except Exception as e:
            print(f"Error syncing cookies: {e}")
        return

    if args.init:
        PLUGIN_DIR.mkdir(parents=True, exist_ok=True)
        init_file = PLUGIN_DIR / "__init__.py"
        init_file.touch(exist_ok=True)

        print(f"Plugins directory: {PLUGIN_DIR}")
        print()
        print("Copy your plugin .py files into this directory, then run:")
        print("  search-tool --engine <plugin_name> \"your query\"")
        print()

        if _is_playwright_chromium_installed():
            print("Playwright Chromium is already installed.")
        else:
            print("Playwright Chromium not found. Installing dependencies...")
            if platform.system() == "Linux":
                channel_name = "chromium"
            else:
                channel_name = "chrome"
            try:
                subprocess.run(["playwright", "install", channel_name], check=True)
                print("Playwright dependencies installed.")
            except FileNotFoundError:
                print("Error: 'playwright' CLI not found. Install with: pip install playwright")
            except subprocess.CalledProcessError as e:
                print(f"Error running 'playwright install {channel_name}': {e}")
        return

    if not args.query:
        parser.error("the following arguments are required: query")

    engine_name_str = plugin_registry.normalize(args.engine)
    search_query = ' '.join(args.query)
    output_format = _normalize_output_format(args.output_format)

    selected_plugin = plugin_registry.get(engine_name_str)
    if selected_plugin is None:
        print(f"Error: Invalid search engine '{args.engine}'. Supported engines are: {available_engines}")
        return

    if args.verbose:
        print(
            f'Searching with {selected_plugin.name} for: "{search_query}" '
            f'(Headless: {args.headless}, Num Results: {args.num_results})',
            file=sys.stderr if output_format == 'json' else sys.stdout,
        )

    config = SearchConfig(
        search_engine=selected_plugin.name,
        num_results=args.num_results,
        headless=args.headless,
        use_persistent_profile=not args.no_persistent_profile,
        timeout=args.timeout,
        follow_pages=args.pages,
        verbose=args.verbose,
    )

    search_tool_instance = SearchTool(config)

    try:
        json_output = output_format == 'json'
        await _run_with_optional_output(
            search_tool_instance.initialize(),
            verbose=args.verbose,
            json_output=json_output,
        )
        results_obj = await _run_with_optional_output(
            search_tool_instance.search(search_query),
            verbose=args.verbose,
            json_output=json_output,
        )

        if args.pages > 0 and results_obj and results_obj.web_results:
            for i in range(min(args.pages, len(results_obj.web_results))):
                content = results_obj.web_results[i].metadata.get('content_markdown')
                if content:
                    print(content)
                    print("\n---\n")
        elif output_format == 'json':
            _print_json_search_results(results_obj)
        elif results_obj and _has_results(results_obj):
            _print_search_results(results_obj, verbose=args.verbose)
        else:
            print('No results found.')
    except SearchEngineError as e:
        print(f"Search Engine Error: {e}", file=sys.stderr)
    except ConfigurationError as e:
        print(f"Configuration Error: {e}", file=sys.stderr)
    except Exception as e:
        print(f"An unexpected error occurred: {e}", file=sys.stderr)
    finally:
        await _run_with_optional_output(
            search_tool_instance.close(),
            verbose=args.verbose,
            json_output=output_format == 'json',
        )


def main():
    asyncio.run(run_search())


if __name__ == "__main__":
    main()
