"""Backward-compatible YouTube search wrapper.

YouTube search is implemented as a first-party plugin in
`search_tool.plugins.youtube`.
"""

from __future__ import annotations

import asyncio
import sys

from pydantic import BaseModel

from .config import SearchConfig
from .playwright_manager import PlaywrightManager
from .plugins.base import SearchContext
from .plugins.youtube import YouTubeSearchPlugin, views_to_count


class YoutubeSearchResult(BaseModel):
    title: str
    vid: str
    views: int
    published: str | None = None


def views2count(viewtext: str) -> int:
    return views_to_count(viewtext)


class YoutubeSearchTool:
    name: str = "search youtube"
    description: str = "Search YouTube and return video results."

    async def _run(self, keyword: str) -> list[YoutubeSearchResult]:
        config = SearchConfig(search_engine="youtube", headless=False)
        playwright_manager = PlaywrightManager(config)
        plugin = YouTubeSearchPlugin()

        async with playwright_manager:
            results = await plugin.search(keyword, SearchContext(config=config, playwright_manager=playwright_manager))

        return [
            YoutubeSearchResult(
                title=result.title,
                vid=str(result.metadata.get("video_id", "")),
                views=result.view_count or 0,
                published=result.metadata.get("published_text"),
            )
            for result in results.video_results
        ]


if __name__ == "__main__":
    if len(sys.argv) < 2:
        exit("Usage: python -m search_tool.yt_search <keyword>")

    tool = YoutubeSearchTool()
    loop = asyncio.new_event_loop()
    asyncio.set_event_loop(loop)
    for result in loop.run_until_complete(tool._run(sys.argv[1])):
        print(result)
