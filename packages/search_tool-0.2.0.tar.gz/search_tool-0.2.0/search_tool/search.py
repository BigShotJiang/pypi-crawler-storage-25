"""
Main search tool class.
"""

import asyncio

from readability import Document  # type: ignore[import-untyped]
from markdownify import markdownify as md  # type: ignore[import-untyped]

from .models import SearchResults
from .config import SearchConfig, SearchEngine
from .playwright_manager import PlaywrightManager
from .exceptions import SearchEngineError, ConfigurationError
from .engines.google import GoogleEngine
from .engines.duckduckgo import DuckDuckGoEngine
from .engines.brave import BraveEngine
from .plugins.base import SearchContext
from .plugins.registry import SearchPluginRegistry, create_default_registry


class SearchTool:
    """
    Orchestrates browser automation to perform web searches and parse results.
    """

    def __init__(self, config: SearchConfig):
        if not isinstance(config, SearchConfig):
            raise ConfigurationError("Invalid SearchConfig provided.")
        self.config = config
        self.playwright_manager = PlaywrightManager(config)
        self._initialized = False
        self._browser_initialized = False
        self._plugin_registry: SearchPluginRegistry = create_default_registry(
            engine_classes={
                "google": GoogleEngine,
                "duckduckgo": DuckDuckGoEngine,
                "brave": BraveEngine,
            }
        )

        # Backward-compatible view of built-in engines for callers that inspect it.
        self._engines_registry = {
            SearchEngine.google: GoogleEngine,
            SearchEngine.duckduckgo: DuckDuckGoEngine,
            SearchEngine.brave: BraveEngine,
        }

    async def initialize(self):
        """
        Initialize Playwright and browser context for background operation.
        This should be called once at application startup.
        """
        if not self._initialized:
            try:
                plugin = self._plugin_registry.require(self.config.engine_name)
            except KeyError as e:
                raise SearchEngineError(str(e)) from e

            if plugin.requires_browser:
                browser_headless = getattr(plugin, "browser_headless", None)
                browser_config = self.config
                if browser_headless is not None and self.config.headless != browser_headless:
                    browser_config = self.config.model_copy(update={"headless": browser_headless})
                if browser_config is not self.config:
                    self.playwright_manager = PlaywrightManager(browser_config)
                await self.playwright_manager.__aenter__()
                self._browser_initialized = True
            self._initialized = True

    async def __aenter__(self):
        """Async context manager entry point."""
        await self.initialize()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        """Async context manager exit point."""
        await self.close()

    def is_initialized(self) -> bool:
        """Check if Playwright has been initialized."""
        return self._initialized

    async def search(self, query: str) -> SearchResults:
        """
        Execute the search based on the provided SearchConfig and return structured SearchResults.
        This method assumes Playwright has already been initialized.
        """
        if not self._initialized:
            raise ConfigurationError(
                "SearchTool must be initialized before performing searches. Call initialize() first."
            )

        engine_name = self.config.engine_name
        plugin = self._plugin_registry.get(engine_name)
        if not plugin:
            supported = ", ".join(self._plugin_registry.available_names())
            raise SearchEngineError(
                f"Search engine '{engine_name}' is not supported. Supported engines are: {supported}"
            )

        context = SearchContext(
            config=self.config,
            playwright_manager=self.playwright_manager if self._browser_initialized else None,
        )
        try:
            results = await plugin.search(query=query, context=context)
            if (
                self.config.follow_pages > 0
                and results.web_results
                and not getattr(plugin, "handles_follow_pages", False)
            ):
                num_to_follow = min(self.config.follow_pages, len(results.web_results))
                tasks = [self.fetch_content(str(results.web_results[i].url)) for i in range(num_to_follow)]
                contents = await asyncio.gather(*tasks)
                for i, content in enumerate(contents):
                    results.web_results[i].metadata['content_markdown'] = content
            return results
        except SearchEngineError as e:
            print(f"Error during search with {engine_name}: {e}")
            raise  # Re-raise the original SearchEngineError
        except Exception as e:
            # Catch any other unexpected errors from the engine's search method
            raise SearchEngineError(f"An unexpected error occurred in {engine_name} engine: {e}") from e

    async def fetch_content(self, url: str) -> str:
        """Fetch content from a URL and convert it to Markdown."""
        page = await self.playwright_manager.get_page()
        try:
            await page.goto(str(url), wait_until="load", timeout=self.config.timeout * 1000)
            content = await page.content()
            doc = Document(content)
            summary = doc.summary()
            title = doc.title()
            markdown = md(summary)
            return f"# {title}\n\n{markdown}"
        except Exception as e:
            return f"Error fetching {url}: {e}"
        finally:
            await page.close()

    async def close(self):
        """Cleanly close the Playwright manager."""
        if self._initialized:
            if self._browser_initialized:
                await self.playwright_manager.__aexit__(None, None, None)
                self._browser_initialized = False
            self._initialized = False
