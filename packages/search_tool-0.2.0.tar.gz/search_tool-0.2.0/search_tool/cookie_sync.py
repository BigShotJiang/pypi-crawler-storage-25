"""
Utility for syncing cookies from local browsers to Playwright's persistent profile.
"""

from __future__ import annotations

import logging
from typing import Any, cast

try:
    import rookiepy
except ImportError:
    rookiepy = None  # type: ignore

from .config import SearchConfig
from .playwright_manager import PlaywrightManager

logger = logging.getLogger(__name__)


def get_browser_cookies(browser_name: str, domains: list[str] | None = None) -> list[dict[str, Any]]:
    """
    Extract cookies from a local browser and format them for Playwright.

    Args:
        browser_name: Name of the browser (chrome, firefox, edge, brave, safari, opera).
        domains: Optional list of domains to filter cookies for.

    Returns:
        List of cookie dictionaries in Playwright format.
    """
    if rookiepy is None:
        raise ImportError(
            "The 'rookiepy' package is required for cookie syncing. Install it with: pip install rookiepy"
        )

    browser_name = browser_name.lower()
    browser_funcs = {
        "chrome": rookiepy.chrome,
        "firefox": rookiepy.firefox,
        "edge": rookiepy.edge,
        "brave": rookiepy.brave,
        "safari": rookiepy.safari,
        "opera": rookiepy.opera,
    }

    if browser_name not in browser_funcs:
        supported = ", ".join(browser_funcs.keys())
        raise ValueError(f"Unsupported browser: {browser_name}. Supported browsers: {supported}")

    try:
        # rookiepy returns a list of dictionaries
        raw_cookies = browser_funcs[browser_name](domains)
    except Exception as e:
        raise RuntimeError(f"Failed to extract cookies from {browser_name}: {e}") from e

    formatted_cookies: list[dict[str, Any]] = []
    for cookie in raw_cookies:
        # Playwright cookie format:
        # {name, value, domain, path, expires, httpOnly, secure, sameSite}

        # rookiepy keys: name, value, domain, path, expires, http_only, secure, same_site
        playwright_cookie = {
            "name": cookie.get("name"),
            "value": cookie.get("value"),
            "domain": cookie.get("domain"),
            "path": cookie.get("path", "/"),
            "secure": cookie.get("secure", False),
            "httpOnly": cookie.get("http_only", False),
        }

        expires = cookie.get("expires")
        if expires is not None:
            playwright_cookie["expires"] = expires

        same_site = cookie.get("same_site")
        if same_site is not None:
            # rookiepy might return integers for same_site, Playwright expects string
            # 0: None, 1: Lax, 2: Strict
            mapping = {0: "None", 1: "Lax", 2: "Strict"}
            if isinstance(same_site, int):
                playwright_cookie["sameSite"] = mapping.get(same_site, "Lax")
            else:
                playwright_cookie["sameSite"] = str(same_site).capitalize()
        else:
            playwright_cookie["sameSite"] = "Lax"

        formatted_cookies.append(playwright_cookie)

    return formatted_cookies


async def sync_cookies_to_playwright(
    browser_name: str, domains: list[str] | None = None, config: SearchConfig | None = None
) -> int:
    """
    Extract cookies from a local browser and inject them into Playwright's persistent profile.

    Returns:
        The number of cookies synced.
    """
    if config is None:
        config = SearchConfig(use_persistent_profile=True, headless=True)

    if not config.use_persistent_profile:
        logger.warning("Syncing cookies to a non-persistent profile will not persist them.")

    cookies = get_browser_cookies(browser_name, domains)
    if not cookies:
        logger.warning(f"No cookies found for {browser_name} with domains {domains}")
        return 0

    manager = PlaywrightManager(config)
    async with manager:
        await manager._ensure_playwright_and_browser()
        context = manager._context
        if context:
            await context.add_cookies(cast(Any, cookies))
            # Browser context must be closed to persist changes to the user_data_dir
        else:
            raise RuntimeError("Failed to initialize Playwright context.")

    return len(cookies)
