import os
import platform
import random
import shutil
import subprocess
from typing import Final

from playwright.async_api import ViewportSize, async_playwright, BrowserContext, Page, Playwright
from playwright_stealth import Stealth

from .exceptions import PlaywrightError
from .config import SearchConfig

# Common desktop viewport sizes
VIEWPORTS: Final[list[ViewportSize]] = [
    {"width": 1920, "height": 1080},
    {"width": 1366, "height": 768},
    {"width": 1536, "height": 864},
    {"width": 1440, "height": 900},
    {"width": 1280, "height": 720},
    {"width": 1600, "height": 900},
    {"width": 1280, "height": 800},
    {"width": 1280, "height": 1024},
]

# Modern user-agent strings
USER_AGENTS = {
    'win': (
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36"
    ),
    'linux': "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/140.0.0.0 Safari/537.36",
    'mac': (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/108.0.0.0"
        " Safari/537.36"
    ),
}


# Platform-specific user data directories and configuration
def get_browser_config():
    """Get platform-specific browser configuration."""
    system = platform.system()

    if system == "Linux":
        return {
            "user_agent": USER_AGENTS['linux'],
            "user_data_dir": os.path.expanduser(os.path.join("~", ".cache", "playwright_chromium")),
            "install_command": ["playwright", "install", "--with-deps", "chromium"],
        }
    elif system == "Windows":
        return {
            "user_agent": USER_AGENTS['win'],
            "user_data_dir": os.path.expanduser(os.path.join("~", "AppData", "Local", "Google", "Chrome", "User Data")),
            "install_command": ["playwright", "install", "--with-deps", "chrome"],
        }
    else:  # Windows and Mac
        return {
            "user_agent": USER_AGENTS['mac'],
            "user_data_dir": os.path.expanduser(os.path.join("~", ".cache", "playwright_chrome")),
            "install_command": ["playwright", "install", "--with-deps", "chrome"],
        }


browser_config = get_browser_config()
user_data_dir = browser_config["user_data_dir"]
os.makedirs(user_data_dir, exist_ok=True)


def clear_browser_profile():
    """Clears the browser profile directory."""
    if os.path.exists(user_data_dir):
        shutil.rmtree(user_data_dir)
        print(f"Browser profile at {user_data_dir} cleared.")
    else:
        print(f"Browser profile at {user_data_dir} not found.")


class PlaywrightManager:
    """
    Manages Playwright browser instances, contexts, and pages.
    Uses Chrome on Windows/Mac and Chromium on Linux for better compatibility.
    """

    launch_args = [
        "--disable-blink-features=AutomationControlled",  # Disable automation flag
        "--disable-dev-shm-usage",
        "--start-maximized",
    ]

    def __init__(self, config: SearchConfig):
        self._playwright: Playwright | None = None
        self._context: BrowserContext | None = None
        self.config = config
        self._browser_config = browser_config
        if platform.system() == "Linux":
            self.launch_args.append("--disable-gpu")
            self.launch_args.append("--no-sandbox")

    async def _ensure_playwright_and_browser(self):
        """Ensures Playwright is started and a browser instance is available."""
        stealth = Stealth(init_scripts_only=True)
        if self._playwright is None:
            try:
                self._playwright = await async_playwright().start()
            except Exception:
                try:
                    print(
                        f'First time running Playwright on {platform.system()}, installing'
                        f' chrome dependencies...'
                    )
                    subprocess.run(self._browser_config["install_command"], stdout=subprocess.DEVNULL, check=True)
                    self._playwright = await async_playwright().start()
                except Exception as e:
                    raise PlaywrightError(f"Failed to start Playwright: {e}")

        if self._context is None:
            try:
                user_agent = self.config.user_agent or self._browser_config["user_agent"]
                launch_kwargs = {
                    "headless": self.config.headless,
                    "args": self.launch_args,
                    "channel": "chrome"
                }

                if self.config.proxy:
                    launch_kwargs["proxy"] = {"server": self.config.proxy}

                if self.config.use_persistent_profile:
                    launch_kwargs.update({
                        'locale': 'en-US',
                        'java_script_enabled': True,
                        'user_agent': user_agent,
                        'has_touch': False,
                        'is_mobile': False,
                        'device_scale_factor': 1,
                        # 'timezone_id': 'America/Chicago',
                    })
                    self._context = await self._playwright.chromium.launch_persistent_context(
                        user_data_dir, **launch_kwargs
                    )
                    await self._context.add_init_script(
                        "    Object.defineProperty(navigator, 'webdriver', {get: () => undefined});\n"
                        "    Object.defineProperty(navigator, 'plugins', {get: () => [1, 2, 3]});\n"
                        "    Object.defineProperty(navigator, 'languages', {get: () => ['en-US', 'en']});\n"
                        "    Object.defineProperty(window, 'chrome', { get: () => ({ runtime: {} }) });\n"
                    )
                    # Optional: Spoof WebGL to avoid fingerprinting
                    await self._context.add_init_script(
                        "    const getParameter = WebGLRenderingContext.prototype.getParameter;\n"
                        "    WebGLRenderingContext.prototype.getParameter = function(parameter) {\n"
                        "        if (parameter === 37445) return 'Intel Inc.';\n"
                        "        if (parameter === 37446) return 'Intel Iris OpenGL Engine';\n"
                        "        return getParameter.apply(this, arguments);\n"
                        "    };"
                    )
                    # Stealth is not needed, and does not work for persistent context anyway
                else:
                    browser = await self._playwright.chromium.launch(**launch_kwargs)
                    self._context = await browser.new_context(user_agent=user_agent, viewport=random.choice(VIEWPORTS))
                    await stealth.apply_stealth_async(self._context)

            except Exception as e:
                # Attempt to close playwright if browser launch fails
                if self._playwright:
                    await self._playwright.stop()
                    self._playwright = None

                error_msg = (
                    f"Failed to launch chrome browser on {platform.system()}: {e}"
                )

                # Provide helpful error message for Linux
                if platform.system() == "Linux":
                    error_msg += (
                        "\n\nLinux troubleshooting suggestions:\n"
                        "1. Install Chromium: sudo apt-get install chromium-browser (Ubuntu/Debian)\n"
                        "2. Install dependencies: playwright install-deps chromium\n"
                        "3. Check if GUI libraries are available\n"
                        "4. Try running with --headless=true if in headless environment"
                    )

                raise PlaywrightError(error_msg)

    async def get_page(self) -> Page:
        """
        Provides a new Playwright Page instance.
        Manages browser launch and context creation.
        """
        await self._ensure_playwright_and_browser()

        if self._context is None:  # Should not happen if _ensure_playwright_and_browser worked
            raise PlaywrightError("Browser is not available after ensuring playwright and browser.")

        try:
            page = await self._context.new_page()
            # await stealth_async(page)
            return page
        except Exception as e:
            raise PlaywrightError(f"Failed to create new page: {e}")

    async def get_pages(self, pages_needed: int) -> list[Page]:
        """
        Provides new Playwright Page instances.
        Manages browser launch and context creation.
        """
        await self._ensure_playwright_and_browser()

        if self._context is None:  # Should not happen if _ensure_playwright_and_browser worked
            raise PlaywrightError("Browser is not available after ensuring playwright and browser.")

        pages = []
        try:
            for _ in range(pages_needed):
                page = await self._context.new_page()
                viewport = random.choice(VIEWPORTS)
                await page.set_viewport_size(viewport)
                pages.append(page)
            return pages
        except Exception as e:
            raise PlaywrightError(f"Failed to create new page: {e}")

    async def close_page(self, page: Page):
        """Closes a page and its context."""
        if page and not page.is_closed():
            context = page.context
            try:
                await page.close()
                if context and len(context.pages) == 0:  # Close context if no more pages
                    await context.close()
            except Exception as e:
                # Log or handle error during page/context close if necessary
                print(f"Error closing page/context: {e}")  # Consider logging instead

    async def close(self):
        """Closes the browser and stops Playwright."""
        if self._context:
            try:
                await self._context.close()
            except Exception as e:
                print(f"Error closing browser: {e}")  # Consider logging
            self._context = None

        if self._playwright:
            try:
                await self._playwright.stop()
            except Exception as e:
                print(f"Error stopping Playwright: {e}")  # Consider logging
            self._playwright = None

    # Optional: Add an __aenter__ and __aexit__ for use as an async context manager
    async def __aenter__(self):
        await self._ensure_playwright_and_browser()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()

    def get_browser_info(self) -> dict:
        """Get information about the current browser configuration."""
        return {
            "platform": platform.system(),
            "user_data_dir": self._browser_config["user_data_dir"],
        }
