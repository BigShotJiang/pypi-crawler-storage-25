"""
Base class for search engines.
"""

from __future__ import annotations

import asyncio
import logging
import platform
import random
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any

from playwright.async_api import Page

from ..config import SearchConfig
from ..models import SearchResults, WebResult
from ..exceptions import SearchEngineError, ParsingError, PlaywrightError
from ..playwright_manager import PlaywrightManager

# Set up logger for debugging
logger = logging.getLogger(__name__)


class BaseSearchEngine(ABC):
    """
    Abstract Base Class for search engine implementations.
    Defines a common interface for performing searches and parsing results.
    """

    def __init__(self, config: SearchConfig, playwright_manager: PlaywrightManager):
        """
        Initializes the search engine with configuration and a Playwright manager.

        Args:
            config: The search configuration.
            playwright_manager: Manager for Playwright browser instances.
        """
        if not isinstance(config, SearchConfig):
            raise TypeError("config must be an instance of SearchConfig")
        if not isinstance(playwright_manager, PlaywrightManager):
            raise TypeError("playwright_manager must be an instance of PlaywrightManager")

        self.config = config
        self.playwright_manager = playwright_manager
        self.pages_needed = 1

    @property
    def engine_name(self) -> str:
        return self.config.engine_name

    @abstractmethod
    async def _build_search_url(self, query: str, page_no: int = 0) -> str:
        """
        Constructs the specific search URL for the engine based on self.config.
        This method must be implemented by subclasses.

        Returns:
            The fully constructed search URL.
        """

    @abstractmethod
    async def _parse_results(self, page: Page) -> list[WebResult]:
        """
        Parses the HTML content of the SERP from the Playwright Page
        and returns populated SearchResults Pydantic models.
        This method will typically delegate to a specific HTML parser.
        This method must be implemented by subclasses.

        Args:
            page: The Playwright Page object containing the SERP content.

        Returns:
            Populated SearchResults Pydantic model.
        """

    async def _get_supported_result_types(self) -> list[str]:
        """
        (Optional) Returns a list of result types (e.g., "web", "image", "video")
        supported by this search engine.
        Defaults to supporting "web" results if not overridden.

        Returns:
            A list of supported result type strings.
        """
        return ["web"]  # Default implementation

    async def _debug_page_state(self, page: Page, query: str, page_no: int) -> dict:
        """
        Collects debug information about the current page state.

        Args:
            page: The Playwright Page object
            query: The search query
            page_no: The page number

        Returns:
            Dictionary with debug information
        """
        try:
            debug_info = {
                "platform": platform.system(),
                "browser_config": self.playwright_manager.get_browser_info(),
                "url": page.url,
                "title": await page.title(),
                "query": query,
                "page_no": page_no,
                "viewport": page.viewport_size,
                "user_agent": await page.evaluate("navigator.userAgent"),
            }

            common_selectors = ['#search', '.g', '.result', '.web-result', '#results', '.s-result-item']
            selector_results: dict[str, int | str] = {}
            for selector in common_selectors:
                try:
                    count = await page.locator(selector).count()
                    selector_results[selector] = count
                except Exception as e:
                    selector_results[selector] = f"Error: {str(e)}"
            debug_info["selector_counts"] = selector_results

            debug_info["ready_state"] = await page.evaluate("document.readyState")

            page_text = await page.text_content("body")
            if page_text:
                lower_page_text = page_text.lower()
                bot_keywords = [
                    "captcha",
                    "challenge",
                    "blocked",
                    "access denied",
                    "unusual traffic",
                    "verify you are human",
                    "Our system has detected unusual traffic",
                ]
                debug_info["has_bot_detection"] = any(keyword in lower_page_text for keyword in bot_keywords)
                debug_info["page_text_length"] = len(page_text)
                debug_info["page_text_preview"] = page_text[:500] if len(page_text) > 500 else page_text

            return debug_info

        except Exception as e:
            logger.error(f"Error collecting debug info: {e}")
            return {"error": str(e)}

    async def _save_debug_html(self, page: Page, query: str, page_no: int, console_logs: list[str] | None = None):
        """
        Saves the current page HTML, screenshot, and console logs for debugging.

        Args:
            page: The Playwright Page object.
            query: The search query.
            page_no: The page number.
            console_logs: A list of console messages captured from the browser.
        """
        try:
            debug_dir = Path("debug_html")
            debug_dir.mkdir(exist_ok=True)

            clean_query = (
                "".join(c for c in query if c.isalnum() or c in (' ', '-', '_')).rstrip().replace(' ', '_')[:50]
            )
            base_filename = f"{self.engine_name}_{clean_query}_page{page_no}_{platform.system().lower()}"

            # Save HTML content
            html_path = debug_dir / f"{base_filename}.html"
            html_content = await page.content()
            with open(html_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            logger.info(f"Debug HTML saved to: {html_path}")

            # Save screenshot
            try:
                screenshot_path = debug_dir / f"{base_filename}.png"
                await page.screenshot(path=str(screenshot_path), full_page=True)
                logger.info(f"Debug screenshot saved to: {screenshot_path}")
            except Exception as e:
                logger.warning(f"Could not save screenshot: {e}")

            # Save console logs
            if console_logs:
                try:
                    log_path = debug_dir / f"{base_filename}_console.log"
                    with open(log_path, 'w', encoding='utf-8') as f:
                        f.write("\n".join(console_logs))
                    logger.info(f"Console logs saved to: {log_path}")
                except Exception as e:
                    logger.warning(f"Could not save console logs: {e}")

        except Exception as e:
            logger.error(f"Error saving debug files: {e}")

    @abstractmethod
    def _get_search_input_selector(self) -> str:
        """
        Returns the CSS selector for the search input field.
        """

    @abstractmethod
    def _get_search_button_selector(self) -> str | None:
        """
        Returns the CSS selector for the search button.
        """

    @abstractmethod
    def get_home_url(self) -> str:
        """
        Returns the home URL for the search engine.
        """

    async def _get_page_results(self, page: Page, page_no: int, query: str) -> list[WebResult]:
        console_logs: list[str] = []

        def handle_console(msg):
            console_logs.append(f"[{msg.type}] {msg.text}")

        page.on("console", handle_console)

        try:
            if self.config.simulate_typing:
                logger.info(f"Simulating typing for query: '{query}'")
                await page.goto(self.get_home_url(), wait_until="domcontentloaded", timeout=30000)
                await page.type(self._get_search_input_selector(), query, delay=random.randint(50, 150))

                button_selector = self._get_search_button_selector()
                if button_selector:
                    await page.click(button_selector)
                else:
                    await page.press(self._get_search_input_selector(), 'Enter')

                await page.wait_for_load_state("domcontentloaded")
            else:
                search_url = await self._build_search_url(query, page_no)
                logger.info(f"Navigating to: {search_url}")
                await page.goto(search_url, wait_until="domcontentloaded", timeout=30000)

            if platform.system() == "Linux":
                logger.info("Linux detected, waiting additional time for page to fully load...")
                await asyncio.sleep(2)

            debug_info = await self._debug_page_state(page, query, page_no)
            logger.info(f"Page debug info: {debug_info}")

            if (
                debug_info.get("has_bot_detection")
                or logger.isEnabledFor(logging.DEBUG)
                or platform.system() == "Linux"
            ):
                await self._save_debug_html(page, query, page_no, console_logs)

            page_title = await page.title()
            if any(term in page_title.lower() for term in ["captcha", "challenge", "blocked", "access denied"]):
                logger.warning(f"Potential blocking detected. Title: {page_title}")
                await self._save_debug_html(page, query, page_no, console_logs)
                raise SearchEngineError(
                    f"Search engine blocking detected. Title: {page_title}. "
                    f"Platform: {platform.system()}. URL: {page.url}"
                )

            results = await self._parse_results(page)

            if not results:
                logger.warning(f"No results found. Debug info: {debug_info}")
                await self._save_debug_html(page, query, page_no, console_logs)

                platform_name = platform.system()
                error_msg = (
                    f"No search results found on {platform_name}. "
                    "This might be due to bot detection or other issues. "
                    "Debug files saved to ./debug_html/ for analysis."
                )
                logger.error(error_msg)

            return results

        except Exception as e:
            debug_info = await self._debug_page_state(page, query, page_no)
            await self._save_debug_html(page, query, page_no, console_logs)

            error_msg = (
                f"Error during search on {platform.system()}: {str(e)}\nURL: {page.url}\nDebug info: {debug_info}"
            )
            logger.error(error_msg)
            raise SearchEngineError(error_msg)
        finally:
            page.remove_listener("console", handle_console)

    async def search(self, query: str) -> SearchResults:
        """
        Orchestrates the search operation:
        1. Builds the search URL.
        2. Launches a browser page using PlaywrightManager.
        3. Navigates to the URL.
        4. Gets the page content.
        5. Parses the results.
        6. Closes the page.

        Returns:
            Populated SearchResults Pydantic model.

        Raises:
            SearchEngineError: If any step in the search process fails.
        """
        logger.info(f"Starting search for query: '{query}' on platform: {platform.system()}")

        pages: list[Page] | None = None
        try:
            pages = await self.playwright_manager.get_pages(self.pages_needed)
            page_results: list[Any] = []
            for i, page in enumerate(pages):
                page_results.append(self._get_page_results(page, i, query))
            gathered_results = await asyncio.gather(*page_results)
            results = [item for sublist in gathered_results for item in sublist]

            logger.info(f"Search completed. Found {len(results)} results.")

            return SearchResults(
                query=query,
                search_engine=self.engine_name,
                web_results=results,
            )

        except PlaywrightError as e:
            logger.error(f"Playwright operation failed: {e}")
            raise SearchEngineError(f"Playwright operation failed during search: {e}")
        except ParsingError as e:  # Assuming _parse_results might raise this
            logger.error(f"Parsing failed: {e}")
            raise SearchEngineError(f"Failed to parse search results: {e}")
        except Exception as e:
            # Catch any other unexpected errors during the search process
            error_url = pages[0].url if pages and len(pages) > 0 else "Unknown URL"
            error_msg = (
                "An unexpected error occurred during search with "
                f"{self.engine_name} for query '{query}' "
                f"on {platform.system()} at URL {error_url}: {e}"
            )
            logger.error(error_msg)
            raise SearchEngineError(error_msg)
        finally:
            if pages:
                for page in pages:
                    await self.playwright_manager.close_page(page)
