# Search-Tool

A unified interface and CLI for performing web searches across various search engines using Playwright.

## Installation

```bash
uv tool install search-tool
```

Or use pip/pipx:
```bash
pip install search-tool
pipx install search-tool
```

## Usage

### CLI

```bash
# Basic search
st python decorator

# get first page
st -p1 current weather dallas tx

# Search with a specific engine
st -e brave "Python async programming"

# Sync cookies from Chrome to bypass logins (e.g., for Twitter/X)
st --sync-cookies chrome --sync-domains .x.com .twitter.com
```

### Python API

```python
import asyncio
from search_tool import SearchTool, SearchConfig

async def main():
    config = SearchConfig(search_engine="google", num_results=5)
    async with SearchTool(config) as tool:
        results = await tool.search("OpenAI o3-mini")
        for result in results.web_results:
            print(f"{result.title}: {result.url}")

if __name__ == "__main__":
    asyncio.run(main())
```

## Cookie Syncing

The `--sync-cookies` flag allows you to import logged-in sessions from your existing browser (Chrome, Firefox, Edge, Brave, Safari, Opera) into Playwright's isolated persistent profile. This is particularly useful for:
- Bypassing login screens on social media sites.
- Avoiding captchas.
- Searching authenticated content.
