from ctrecon import phantoms, scanners, tools

import numpy as np
import matplotlib

matplotlib.use("qtagg")
import matplotlib.pyplot as plt

if __name__ == "__main__":
    # ph = phantoms.Debug()
    ph = phantoms.WanderingLinePair(2, 3, 8, np.pi / 2)

    n_channels = 256
    fov = 30  # (cm)
    dt = fov / n_channels
    # scanner = scanners.ParallelBeam(59.5, 109.5, 256, 0.5)
    scanner = scanners.ParallelBeam(59.5, 109.5, n_channels, dt)
    result = scanner.scan(ph)

    fig = plt.figure()
    # ax1, ax2, ax3 = fig.subplots(1, 3)
    ax1 = fig.subplots(1, 1)

    if result.sinogram is None:
        raise RuntimeError

    if len(result.sinogram.shape) != 2:
        raise RuntimeError

    ax1.imshow(result.sinogram, cmap="gray")
    plt.show()


# if __name__ == "__main__":
#
#     # Generate cryptographically secure 32-bit sequence
#     # random_bytes = secrets.token_bytes(4)
#     # random_bytes = b"\xff\xff\xff\xff"
#     # print(f"Original sequence: {random_bytes.hex()}")
#     # Create spiral code phantom
#     # phantom = SpiralCodePhantom.from_sequence(random_bytes)
#     phantom = phantoms.HD()
#     print(f"Phantom with {len(phantom.circles)} circles")
#
#     # Create the scanner
#     # using units of CM
#     # scanner = PencilBeamDetector(59.5, 109.5, 256, 0.5)
#     scanner = scanners.CircularFan(59.5, 109.5, 256, 0.5)
#
#     sinogram, project_metadata = scanner.scan(phantom)
#     sinogram_noisy = tools.add_noise(sinogram, 1000)
#
#     # Render parameters
#     cx, cy, fov, dim = 0.0, 0.0, 120.0, 500
#
#     # Render the phantom
#     rendered = phantom.render(cx=cx, cy=cy, fov=fov, dim=dim)
#     print(f"Rendered image shape: {rendered.shape}")
#
#     fig = plt.figure()
#     ax1, ax2, ax3 = fig.subplots(1, 3)
#
#     ax2.imshow(sinogram_noisy, cmap="gray")
#     ax2.autoscale(enable=False)
#     ax2.set_title("Noisy Sinogram")
#
#     plt.show(block=False)
#     plt.ion()
#
#     # projection_number = int(sinogram.shape[0]/2)
#     projection_number = 0
#     line = ax2.plot(
#         [0, sinogram.shape[1]], [projection_number, projection_number], c="red"
#     )
#
#     profile_line = ax3.plot(
#         np.arange(0, scanner.n),
#         sinogram[projection_number, :],
#         c="blue",
#         label="no noise",
#     )
#     noisy_profile_line = ax3.plot(
#         np.arange(0, scanner.n),
#         sinogram_noisy[projection_number, :],
#         c="red",
#         label="sim. noise",
#     )
#     ax3.set_title("attenuation profile")
#     ax3.legend()
#
#     while True:
#
#         if not plt.fignum_exists(fig.number):
#             break
#
#         # Draw the rays for the current projection
#         ax1.clear()
#         ax1.imshow(
#             rendered,
#             cmap="gray",
#             extent=[-fov / 2, fov / 2, -fov / 2, fov / 2],
#             origin="lower",
#         )
#         ax1.autoscale(enable=False)
#
#         # Plot rays if provided
#         # Limit number of rays for visibility
#         max_rays = 24
#         rays = scanner.at(project_metadata[projection_number].tube_angle)
#         if max_rays is not None and len(rays) > max_rays:
#             # Sample evenly
#             indices = np.linspace(0, len(rays) - 1, max_rays, dtype=int)
#             rays_to_plot = [rays[i] for i in indices]
#         else:
#             rays_to_plot = rays
#
#         for i, ray in enumerate(rays_to_plot):
#             # Calculate ray endpoints within FOV
#             # Extend ray far enough to cross entire FOV
#             t_max = fov  # Generous length
#
#             x_start = ray.ox
#             y_start = ray.oy
#             x_end = ray.ox + t_max * ray.rx
#             y_end = ray.oy + t_max * ray.ry
#
#             # Plot ray
#             color = plt.cm.rainbow(i / len(rays_to_plot))
#             ax1.plot(
#                 [x_start, x_end], [y_start, y_end], color=color, alpha=0.6, linewidth=1
#             )
#
#             # Mark ray origin
#             ax1.plot(x_start, y_start, "o", color=color, markersize=4)
#
#         # Wait for user click
#         # pt = plt.ginput(1, timeout=0)
#
#         # if len(pt) ==0:
#         #     continue
#
#         # projection_number = int(np.round(pt[0][1]))
#         plt.pause(0.01)
#         projection_number = (projection_number + 1) % sinogram.shape[0]
#         line[0].set_data([0, sinogram.shape[1]], [projection_number, projection_number])
#
#         profile_line[0].set_data(
#             np.arange(0, scanner.n), sinogram[projection_number, :]
#         )
#
#         if sinogram_noisy is not None:
#             noisy_profile_line[0].set_data(
#                 np.arange(0, scanner.n), sinogram_noisy[projection_number, :]
#             )
