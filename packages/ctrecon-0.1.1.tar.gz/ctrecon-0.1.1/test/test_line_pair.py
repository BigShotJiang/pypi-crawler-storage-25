from ctrecon import phantoms
import matplotlib.pyplot as plt

if __name__ == "__main__":

    cx = 2
    cy = 3
    fov = 3
    dim = 512

    ph = phantoms.WanderingLinePair(2, 3, 10, 24)
    img = ph.render(cx, cy, fov, dim)

    # Unzip the list of tuples into separate X and Y lists for the scatter plot
    points = ph.measurement_points(sampling_interval=0.02)
    xs, ys = zip(*points)

    # 3. Calculate the physical boundaries of the rendered FOV
    extent = (
        cx - fov / 2.0,  # left
        cx + fov / 2.0,  # right
        cy - fov / 2.0,  # bottom
        cy + fov / 2.0,  # top
    )

    # 4. Create the plot
    fig, ax = plt.subplots(figsize=(8, 8))

    # Draw the background image
    # origin='lower' is critical! It ensures the image's Y-axis grows upwards
    # like standard Cartesian math, matching our physics renderer.
    ax.imshow(img, extent=extent, origin="lower", cmap="bone")

    # Draw the scatter points
    # Using a bright contrasting color (cyan/magenta/yellow), a small size (s),
    # and slight transparency (alpha) looks great on medical physics phantoms.
    ax.scatter(
        xs, ys, c="cyan", s=15, alpha=0.8, edgecolor="none", zorder=5, label="Samples"
    )

    ax.set_title("Wandering Line Pair & Measurement Profile")
    ax.set_xlabel("X Coordinate (cm)")
    ax.set_ylabel("Y Coordinate (cm)")
    ax.legend()

    plt.show()

    # plt.imshow(img, vmin=0.5, vmax=2.05, cmap="gray")

    # ph = phantoms.FORBILDHead(mu_water=0.0192)
    # img = ph.render(0, 0, 25, 512)
    # plt.imshow(img, vmin=0.019, vmax=0.02, cmap="gray")

    # plt.show()
