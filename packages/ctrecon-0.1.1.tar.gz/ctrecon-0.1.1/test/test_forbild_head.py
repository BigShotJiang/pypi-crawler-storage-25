from ctrecon import phantoms
import matplotlib.pyplot as plt

if __name__ == "__main__":

    ph = phantoms.ForbildHead()
    # img = ph.render(0, 0, 25, 512)
    img = ph.render(-5, 0, 5, 512)
    plt.imshow(img, vmin=0.5, vmax=2.05, cmap="gray")

    # ph = phantoms.FORBILDHead(mu_water=0.0192)
    # img = ph.render(0, 0, 25, 512)
    # plt.imshow(img, vmin=0.019, vmax=0.02, cmap="gray")

    plt.show()
