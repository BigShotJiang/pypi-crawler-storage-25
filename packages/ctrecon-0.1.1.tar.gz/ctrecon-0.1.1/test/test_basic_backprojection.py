from ctrecon import phantoms, scanners, recon

import matplotlib.pyplot as plt

from ctrecon.recon.backprojection import BackprojectionEngine

if __name__ == "__main__":
    # Create something to scan
    ph = phantoms.Debug()

    # Set up our scanner
    fov = 30  # cm
    n_det = 256
    dt = fov / n_det  # detector size
    scanner = scanners.ParallelBeam(59.5, 109.5, n_det, dt)
    scan_result = scanner.scan(ph)

    if scan_result.sinogram is not None:
        plt.imshow(scan_result.sinogram, cmap="gray")
        plt.show()

    # Configure the Points object to pass to our reconstruction
    # Points provide the image locations to reconstruction via their `points` method.
    N = 256
    grid = recon.IsoGrid2D(0, 0, 30, N)

    # Do the reconstruction
    # The "workspace" manages reconstructions and provides
    # an organized history of all reconstructions performed
    wksp = recon.Workspace(scan_result)
    recon_result = wksp.recon(
        grid, BackprojectionEngine(), id="first-recon", tags=("test",)
    )

    print(recon_result)

    # Points objects also should provide a `format` method to reshape flat
    # attenuation values back into something more useful.  It can
    # return any useful representation (here we return grid-like data).
    X, Y, img = grid.format(recon_result.recon)

    # Show the image
    plt.pcolormesh(X, Y, img, cmap="gray")
    plt.axis("image")
    plt.show()
