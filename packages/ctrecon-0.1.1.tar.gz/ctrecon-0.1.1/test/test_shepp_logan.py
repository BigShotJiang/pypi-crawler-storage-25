from ctrecon import phantoms
import matplotlib.pyplot as plt

if __name__ == "__main__":

    ph = phantoms.SheppLogan()
    img = ph.render(0, 0, 25, 512)
    plt.imshow(img, vmin=0.9, vmax=1.05)

    ph = phantoms.SheppLogan(mu_water=0.0192)
    img = ph.render(0, 0, 25, 512)
    plt.imshow(img, vmin=0.019, vmax=0.02, cmap="gray")

    plt.show()
