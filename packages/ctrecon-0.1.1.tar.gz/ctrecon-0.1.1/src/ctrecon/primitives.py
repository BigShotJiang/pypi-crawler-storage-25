import math
import random


class Labeled:
    """
    Labeled provides basic labeling interfaces so that
    we can provide *something* when called, or raise an error to
    the user if more appropriate

    This class is largely used to automatically generate IDs when not provided
    by users to enable an effective, automatic ReconHistory.
    """

    def label(self):
        return f"{type(self).__name__}-NEEDS-LABEL-METHOD"


class Ellipse:
    def __init__(self, cx, cy, wx, wy, angle: float, attenuation: float):
        self.type = "Ellipse"
        self.cx = cx
        self.cy = cy
        self.wx = wx  # Total width
        self.wy = wy  # Total height
        self.angle = angle  # Rotation in radians
        self.attenuation = attenuation

    def to_csv(self) -> str:
        return f"Ellipse,{self.cx},{self.cy},{self.wx},{self.wy},{self.angle},{self.attenuation}"

    @classmethod
    def from_csv_parts(cls, parts: list) -> "Ellipse":
        return cls(*map(float, parts[:6]))


class Rectangle:
    def __init__(self, cx, cy, w, h, angle: float, attenuation: float):
        self.type = "Rectangle"
        self.cx = cx  # center x
        self.cy = cy  # center y
        self.w = w  # width
        self.h = h  # height
        self.angle = angle  # rotation in radians
        self.attenuation = attenuation
        self.color = None

    def c(self):
        if self.color is None:
            self.color = (random.random(), random.random(), random.random())
        return self.color

    def to_csv(self) -> str:
        return f"Rectangle,{self.cx},{self.cy},{self.w},{self.h},{self.angle},{self.attenuation}"

    @classmethod
    def from_csv_parts(cls, parts: list) -> "Rectangle":
        return cls(
            float(parts[0]),
            float(parts[1]),
            float(parts[2]),
            float(parts[3]),
            float(parts[4]),
            float(parts[5]),
        )


class Circle:
    def __init__(self, cx, cy, r: float, attenuation: float):
        self.type = "Circle"
        self.cx = cx  # x coordinate of circle center
        self.cy = cy  # y coordinate of circle center
        self.r = r  # radius of circle
        self.attenuation = attenuation  # additional property
        self.color = None

    def c(self):

        if self.color is None:
            r = random.random()
            b = random.random()
            g = random.random()
            self.color = (r, g, b)

        return self.color

    def to_csv(self) -> str:
        """
        Serialize the circle to a single CSV line: "cx,cy,r,attenuation".
        """
        return f"{self.cx},{self.cy},{self.r},{self.attenuation}"

    @classmethod
    def from_csv(cls, line: str) -> "Circle":
        """
        Parse a circle from a CSV line in the format: "cx,cy,r,attenuation".
        This simplified version omits error handling for readability.
        """
        parts = [p.strip() for p in line.strip().split(",")]
        cx = float(parts[0])
        cy = float(parts[1])
        r = float(parts[2])
        attenuation = float(parts[3])
        return cls(cx, cy, r, attenuation)


class Ray:
    def __init__(self, ox, oy, rx, ry: float):
        self.ox = ox
        self.oy = oy
        # Perform vector normalization
        # <normalization>
        mag = (rx * rx + ry * ry) ** 0.5
        if mag == 0.0:
            # Zero-length direction → default to no direction
            self.rx, self.ry = 0.0, 0.0
        else:
            self.rx = rx / mag  # ray direction x component
            self.ry = ry / mag  # ray direction y component

    def __str__(self):
        return f"ray origin: ({self.ox},{self.oy}) direction: ({self.rx},{self.ry})"

    @classmethod
    def from_points(cls, ox, oy, px, py: float) -> "Ray":
        rx = px - ox
        ry = py - oy
        return cls(ox, oy, rx, ry)


class ForbildShape:
    """
    A single mathematical primitive for the FORBILD head phantom.
    Used for both ellipses and clipped ellipses.
    """

    def __init__(
        self,
        cx: float,
        cy: float,
        a: float,
        b: float,
        phi_deg: float,
        rho: float,
        clips=None,
    ):
        self.type = "ForbildShape"
        self.cx = cx
        self.cy = cy
        self.a = a
        self.b = b
        self.phi = math.radians(phi_deg)
        self.rho = rho
        # clips is a list of tuples: (d, psi_deg) defining the half-planes
        self.clips = clips if clips is not None else []  # return Phantom(objects)


def ray_circle_intersections(circle: Circle, ray: Ray):
    """
    Compute intersections between a normalized ray and a circle.
    Returns a list of (x, y) points with t >= 0.
    """
    ox, oy = ray.ox, ray.oy
    dx, dy = ray.rx, ray.ry
    cx, cy, r = circle.cx, circle.cy, circle.r

    # Vector from circle center to ray origin
    fx = ox - cx
    fy = oy - cy

    # Quadratic for |o + t d - c|^2 = r^2
    a = dx * dx + dy * dy  # ≈ 1.0 after normalization
    b = 2 * (fx * dx + fy * dy)
    c0 = fx * fx + fy * fy - r * r

    if a == 0.0:
        return []  # degenerate direction → no proper ray

    disc = b * b - 4 * a * c0
    if disc < 0.0:
        return []  # no intersection

    sqrt_disc = math.sqrt(disc)
    t1 = (-b - sqrt_disc) / (2 * a)
    t2 = (-b + sqrt_disc) / (2 * a)

    pts = []
    for t in (t1, t2):
        if t >= 0.0:
            pts.append((t, ox + t * dx, oy + t * dy, circle.attenuation))

    # If tangent, remove duplicate
    if len(pts) == 2 and abs(t1 - t2) < 1e-12:
        return [pts[0]]
    return pts
