from typing import Any
import time
import numpy as np
from .base import ReconEngine
from ctrecon.scanners import ScanResult


class BackprojectionEngine(ReconEngine):

    # TODO: return a helpful message
    def supports(self, scan: ScanResult) -> bool:
        if type(scan.scanner).__name__ != "ParallelBeam":
            return False

        return True

    def label(self):
        return "bpj"

    def compute(
        self, scan: ScanResult, points: np.ndarray, cache: dict | None = None
    ) -> tuple[np.ndarray, dict]:

        start = time.time()

        # These will raise exceptions if we're missing
        # essential data. There may be a cleaner way to handle it
        # but "fail fast" has worked pretty well so far.
        # I couldn't really achieved a class-based model to provide
        # these as part of the "supports" call.
        scanner = scan.must_get_scanner()
        protocol = scan.must_get_protocol()
        sinogram = scan.must_get_sinogram()

        if not self.supports(scan):
            raise RuntimeError("Scan and engine are incompatible")

        log = {}

        if cache is None:
            cache = {}

        cache["sinogram"] = scan.sinogram

        x = points[:, 0]
        y = points[:, 1]

        mu = np.zeros_like(x, dtype=np.float32)
        d_thetas = np.gradient(protocol.theta)
        central_det = (scanner.spec.n_channels - 1) / 2.0 + scanner.spec.channel_offset
        det_indices = np.arange(scanner.spec.n_channels)

        for i, (theta, weight) in enumerate(zip(protocol.theta, d_thetas)):

            # Voxel projection math
            t = -x * np.sin(theta) + y * np.cos(theta)
            t_idx = t / scanner.spec.channel_width + central_det

            # Interpolate and WEIGHT the result by this specific angular step
            projection_contribution = np.interp(
                t_idx, det_indices, sinogram[i], left=0.0, right=0.0
            )
            mu += projection_contribution * weight

        end = time.time()

        log["bpj-elapsed-s"] = end - start

        return mu, log
        # raise NotImplementedError("backprojection is next for implementing")
        # return super().compute(scan, points, cache)
