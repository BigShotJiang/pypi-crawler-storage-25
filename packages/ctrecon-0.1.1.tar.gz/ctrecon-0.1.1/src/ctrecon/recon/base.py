from dataclasses import dataclass
import enum
from typing import Any
import numpy as np
from ctrecon.primitives import Labeled
from ctrecon.scanners import ScanResult


class Points(Labeled):
    """
    Points is a low-level abstraction for images
    """

    def points(self) -> np.ndarray:
        """
        Returns an (N, D) array of spatial coordinates.
        N is the number of points, D is the spatial dimension (2 or 3).
        """
        raise NotImplementedError

    def logical_shape(self) -> tuple[int, ...]:
        """
        The logical shape is how the Points object intends a user
        to hold values in memory. In most cases, this is (or should be)
        equivalent to ndarray.shape.
        """
        raise NotImplementedError

    def format(self, values: np.ndarray, uv: np.ndarray | None = None) -> Any:
        """
        Takes an (N,) array of values and reformats them appropriately.
        Optionally, users can also pass an (N,2) dimensional array representin
        UV mapping coordinates for final image presentation.
        N is the number of points, D is the spatial dimension (2 or 3).

        The consideration here is that the inheriting type knows/understands
        what it needs to present the final image appropriately.
        """
        raise NotImplementedError


class ReconEngine(Labeled):
    """
    ReconEngine computes attenuation values from projection data. It is
    intended as a very raw, math-oriented class.  I.e., one level above, say,
    a call to call to a GPU.
    """

    def supports(self, scan: ScanResult) -> bool:
        raise NotImplementedError

    def compute(
        self, scan: ScanResult, points: np.ndarray, cache: dict | None = None
    ) -> tuple[np.ndarray, dict]:
        raise NotImplementedError


@dataclass()
class ReconRecord:
    id: str
    tags: set[str]
    scan_id: str
    points: Points
    recon: np.ndarray
    log: dict

    def summary(self) -> dict:
        """Returns a flat dictionary of metadata for reporting."""
        return {
            "id": self.id,
            "scan_id": self.scan_id,
            "n_points": f"{self.recon.shape}",
            "shape": f"{self.points.logical_shape()}",
            "points_label": getattr(self.points, "label", "unlabeled"),
            "tags": ", ".join(sorted(self.tags)),
            # "engine": self.log.get("engine", "unknown"),
            # "compute_time": self.log.get("duration", "n/a"),
        }


class Workspace:
    """
    ReconWorkspace is a collecting class that handles an entire reconstruction
    process. including providing a history and caching for important data that
    we may want to inspect or reuse later.

    The workspace also acts as an object store for the reconstruction artifacts.
    """

    def __init__(self, scan: ScanResult):

        # Run some sanity checks
        if scan.scanner is None:
            raise RuntimeError(
                "No scanner defined in scan result; unable to open for reconstruction."
            )

        if scan.sinogram is None:
            raise RuntimeError(
                "Scan does not contain sinogram data for reconstruction."
            )

        if scan.protocol is None:
            raise RuntimeError(
                "Scan does not contain a protocol describing how data was acquired."
            )

        self.scan = scan
        self._cache = {}
        self._history = {}
        self._timeline = []

    def get(self, id: str) -> ReconRecord:
        if id not in self._history:
            raise KeyError(f"no recons with id {id}")
        return self._history[id][-1]

    def get_all(self, id: str) -> list[ReconRecord]:
        if id not in self._history:
            raise KeyError(f"no recons with id {id}")
        return self._history[id]

    def put(self, id: str, recon: ReconRecord):
        if id not in self._history:
            self._history[id] = []
        self._history[id].append(recon)
        self._timeline.append(recon)

    def __getitem__(self, idx: int) -> ReconRecord:
        return self._timeline[idx]

    def recon(
        self,
        points: Points,
        engine: ReconEngine,
        id: str | None = None,
        tags: tuple[str] | None = None,
    ) -> ReconRecord:

        if id is None:
            id = f"{engine.label()}-{points.label()}"

        tag_set = set()
        if tags is not None:
            tag_set = set(tags)

        recon_locations = points.points()
        recon_values, log = engine.compute(
            self.scan, recon_locations, cache=self._cache
        )

        r = ReconRecord(id, tag_set, self.scan.id, points, recon_values, log)
        self.put(id, r)
        return r

    def _all_records(self) -> list[ReconRecord]:
        """Flattens the versioned history into a single list of records."""
        return [record for versions in self._history.values() for record in versions]

    def ls(self):
        """Prints a scannable table of the workspace contents to stdout."""
        records = self._all_records()
        if not records:
            print("Workspace is empty.")
            return

        #  "id": self.id,
        #  "scan_id": self.scan_id,
        #  "n_points": f"{self.recon.shape}",
        #  "shape": f"{self.points.logical_shape()}",
        #  "points_label": getattr(self.points, "label", "unlabeled"),
        #  "tags": ", ".join(sorted(self.tags)),

        # Simple manual padding for a 'no-dependency' table
        template = "{:<3} | {:<20} | {:<15} | {:<15} | {:<20}"
        print(template.format("idx", "ID", "Scan ID", "Shape", "Tags"))
        print("-" * 75)
        for idx, r in enumerate(records):
            summary = r.summary()
            print(
                template.format(
                    idx,
                    summary["id"][:18],
                    summary["scan_id"][:13],
                    summary["shape"],
                    # summary["points_label"][],
                    summary["tags"][:18],
                )
            )

    def to_df(self):
        """
        Converts workspace history to a Pandas DataFrame.
        Requires 'pandas' to be installed.
        """
        try:
            import pandas as pd  # type: ignore
        except ImportError:
            raise ImportError(
                "Pandas is required for .to_df(). "
                "Install it with 'pip install pandas'."
            ) from None

        data = [r.summary() for r in self._all_records()]
        return pd.DataFrame(data)
