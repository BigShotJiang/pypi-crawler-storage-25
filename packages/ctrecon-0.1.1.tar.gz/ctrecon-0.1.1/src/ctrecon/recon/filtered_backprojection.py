from typing import Any
import time
import numpy as np
from numpy import ndarray, pi
from ctrecon.scanners import ScanResult
from ctrecon import specs
from .base import ReconEngine

from dataclasses import replace


def _next_pwr_2(x) -> int:
    # Use current value if already a power of 2
    if x & (x - 1) == 0:
        return x
    return 1 << (x - 1).bit_length()


def _bl_ramp_filter(spec: specs.ParallelBeam) -> np.ndarray:

    n = spec.n_channels
    dt = spec.channel_width

    min_size = 2 * n - 1
    target_size = _next_pwr_2(min_size)

    filt = np.zeros(target_size)
    for i, n in enumerate(np.arange(-target_size / 2, target_size / 2)):
        if n == 0:
            filt[i] = 1 / (4 * dt * dt)
        elif n % 2 == 1:
            filt[i] = -1 / (n * pi * dt * n * pi * dt)
        elif n % 2 == 0:
            filt[i] = 0

    return filt


class FBPEngine(ReconEngine):
    """FBPEngine"""

    def supports(self, scan: ScanResult) -> bool:
        if type(scan.scanner).__name__ != "ParallelBeam":
            return False

        return True

    def label(self):
        return "fbp"

    def compute(
        self, scan: ScanResult, points: np.ndarray, cache: dict | None = None
    ) -> tuple[np.ndarray, dict]:

        start = time.time()

        # These will raise exceptions if we're missing
        # essential data. There may be a cleaner way to handle it
        # but "fail fast" has worked pretty well so far.
        # I couldn't really achieved a class-based model to provide
        # these as part of the "supports" call.
        scanner = scan.must_get_scanner()
        protocol = scan.must_get_protocol()
        sinogram = scan.must_get_sinogram()

        if not self.supports(scan):
            raise RuntimeError("Scan and engine are incompatible")

        log = {}

        if cache is None:
            cache = {}

        cache["sinogram-original"] = scan.sinogram

        x = points[:, 0]
        y = points[:, 1]
        mu = np.zeros_like(x)

        # NOTE: This section is the only real difference
        # when compared to basic backprojection, but it is of
        # critical importance when aiming for "accurate" reconstruction
        #
        # Prep and filter the sinogram
        filtering_start = time.time()

        new_sino, new_spec = self._upsample(scan, 2)
        filtered_sino = self._filter(new_sino, new_spec)

        log["elapsed-filtering-s"] = time.time() - filtering_start
        cache["sinogram-upsampled"] = new_sino
        cache["sinogram-filtered"] = filtered_sino

        # Run the backprojection
        # NOTE: we could hand the filtered sinogram off to the
        # "BackprojectionEngine" but we deliberately keep these engines
        # independent to avoid unintended side effects at the user level. The
        # backprojection code is identical between the two implementations.
        mu = np.zeros_like(x, dtype=np.float32)
        d_thetas = np.gradient(protocol.theta)
        central_det = (new_spec.n_channels - 1) / 2.0 + new_spec.channel_offset
        det_indices = np.arange(new_spec.n_channels)

        for i, (theta, weight) in enumerate(zip(protocol.theta, d_thetas)):

            # Voxel projection math
            t = -x * np.sin(theta) + y * np.cos(theta)
            t_idx = t / new_spec.channel_width + central_det

            # Interpolate and WEIGHT the result by this specific angular step
            projection_contribution = np.interp(
                t_idx, det_indices, filtered_sino[i], left=0.0, right=0.0
            )
            mu += projection_contribution * weight

        # Return our data
        log["elapsed-fbp-s"] = time.time() - start

        return mu, log

    def _upsample(
        self, scan: ScanResult, upsample_factor: int
    ) -> tuple[np.ndarray, Any]:

        # Get the data we need
        sinogram = scan.must_get_sinogram()
        scanner = scan.must_get_scanner()
        spec = scanner.spec

        # parameters for the new detector
        # these will get populated into our "upsampled"
        # spec for handoff the the next stage of the recon engine
        n = spec.n_channels * upsample_factor
        dt = spec.channel_width / float(upsample_factor)
        # det_type = type(self)
        offset = float(upsample_factor) * spec.channel_offset

        upsampled_spec = replace(
            spec, n_channels=n, channel_offset=offset, channel_width=dt
        )

        # Upsample the sinogram
        central_det = (spec.n_channels - 1) / 2 + spec.channel_offset
        org_sample_points = (
            np.arange(spec.n_channels) - central_det
        ) * spec.channel_width

        new_central_det = (n - 1) / 2 + offset
        new_sample_points = (np.arange(n) - new_central_det) * dt

        n_proj = sinogram.shape[0]

        up_sinogram = np.zeros((n_proj, n))
        for i in range(n_proj):
            up_sinogram[i, :] = np.interp(
                new_sample_points, org_sample_points, sinogram[i, :]
            )

        return up_sinogram, upsampled_spec

    def _filter(self, sinogram: np.ndarray, spec: Any) -> np.ndarray:

        filt = _bl_ramp_filter(spec)

        pad_size = filt.size - spec.n_channels

        if pad_size % 2 != 0:
            raise RuntimeError("pad size must be an even number")

        pad_size = int(pad_size / 2)

        filt_f = np.fft.fft(np.fft.fftshift(filt))

        # pad sinogram to next greatest power of two
        pad_dims = ((0, 0), (pad_size, pad_size))
        sinogram_padded = np.pad(sinogram, pad_dims)
        sinogram_filtered = np.zeros(sinogram_padded.shape)

        # apply filter to all rows of the sinogram
        for i, projection in enumerate(sinogram_padded):
            proj_f = np.fft.fft(projection)

            # NOTE: Don't forget the extra factor of spec.channel_width, since
            # we're performing a discrete convolution!!!! Ask me how I know...
            sinogram_filtered[i, :] = spec.channel_width * np.real(
                np.fft.ifft(np.multiply(proj_f, filt_f))
            )

        # TODO: cut off the padded portion of the sinogram?
        # sinogram_filtered = sinogram_filtered[:, offset : offset + self.n]
        sinogram_filtered = sinogram_filtered[:, pad_size : pad_size + spec.n_channels]

        return sinogram_filtered

    def _backproject(self, sinogram: np.ndarray, spec: Any):
        pass
