import matplotlib.pyplot as plt
import numpy as np

from ctrecon.scanners.scan_geometry import ScanGeometry, _ProjectionMeta


class Texel:
    def __init__(self, x: float, y: float, u: float, v: float, value: float | None):
        self.x, self.y, self.u, self.v, self.value = x, y, u, v, value


class Image:
    def __init__(self):
        self.texels = []

    def reconstruct(
        self,
        scanner: ScanGeometry,
        sinogram: np.ndarray,
        metadata: list[_ProjectionMeta],
    ):
        raise NotImplementedError

    def display(self):
        raise NotImplementedError

    def data(self) -> dict:
        raise NotImplementedError

    def save(self, filepath: str):
        raise NotImplementedError


class CartesianImage(Image):
    """
    CartesianImage defines an image grid aligned with our world
    coordinate system.

    Generally, speaking, I intend people to access the cartesian image
    through the SquareImage subclass.  Primarly b/c the "api" here
    is a little non-intuitive.

    x_min represents the x location of the center of the "left-est" pixel.
    x_max represents the x location of the center of the "right-est" pixel.
    y_min represents the y location of the center of the "up-est" pixel.
    y_max represents the y location of the center of the "down-est" pixel.
    """

    def __init__(self, x_min, x_max, y_min, y_max, nx, ny):
        super().__init__()
        self.x_min = x_min
        self.x_max = x_max
        self.y_min = y_min
        self.y_max = y_max
        self.nx = nx
        self.ny = ny

        self.pixel_size_x = (x_max - x_min) / (self.nx - 1)
        self.pixel_size_y = (y_max - y_min) / (self.ny - 1)

        self.texture_spacing_x = 1.0 / (self.nx - 1)
        self.texture_spacing_y = 1.0 / (self.ny - 1)

        self._generate_pixel_list()

    def reconstruct(
        self,
        scanner: ScanGeometry,
        sinogram: np.ndarray,
        metadata: list[_ProjectionMeta],
        n_cpu: int = 8,
    ):
        # Build the list of points to pass to the scanner to reconstruct
        recon_texels = []
        points = []
        for texel in self.texels:
            if texel.value is None:
                recon_texels.append(texel)
                points.append((texel.x, texel.y))

        # Do the reconstruction
        recon_data = scanner.recon(points, sinogram, metadata, n_cpu=n_cpu)

        # Map reconstructed points back to image
        # NOTE: pythons pass-by-reference *should* set the underlying
        # texel value without us needing to call back to self.
        for tex, pt in zip(recon_texels, recon_data):
            # sanity check
            if tex.x != pt[0] or tex.y != pt[1]:
                raise RuntimeError("mapped reconstruction points do not match")

            tex.value = pt[2]

    def _to_grid(self) -> np.ndarray:
        """
        _to_grid reorganizes the list of texels into a standard
        2D grid representation.
        """
        # Reorganize the texels into a grid
        img_grid = np.zeros((self.ny, self.nx))

        # sort the texels by u, v
        # NOTE: I'm not sure why this messes things up but it does...
        #
        # self.texels.sort(key=lambda tex: (tex.u, tex.v))

        # Copy reconstructed values into the grid
        for i, tex in enumerate(self.texels):
            # if not alread reconstructed, just leave at zero (STOP FUTUREPROOFING, john)
            if tex.value is None:
                continue

            img_grid.flat[i] = tex.value

        return img_grid

    def display(self):
        """
        display shows the image as a standard 2D image
        """
        img = self._to_grid()
        plt.imshow(img, cmap="gray")
        plt.show()

    def _generate_pixel_list(self):
        for iy in range(self.ny):
            curr_y = iy * self.pixel_size_y + self.y_min
            curr_v = iy * self.texture_spacing_y + self.texture_spacing_y / 2.0
            for ix in range(self.nx):
                curr_x = ix * self.pixel_size_x + self.x_min
                curr_u = ix * self.texture_spacing_x + self.texture_spacing_x / 2.0
                self.texels.append(Texel(curr_x, curr_y, curr_u, curr_v, None))

    def data(self) -> dict:
        return {
            "image": self._to_grid(),
        }


class SquareImage(CartesianImage):
    """
    SquareImage represents our "default" CT image, which
    is a cartesian image where (y_min, y_max) == (x_min, x_max) and
    nx == ny.

    pixel size is fov/N
    """

    def __init__(self, x_center, y_center, fov, N):
        self.x_center = x_center
        self.y_center = y_center
        self.fov = fov
        self.N = N

        # WARN: this math may be incorrect by a fencepost
        pixel_size = fov / N
        lim = pixel_size * (N - 1) / 2.0

        x_min = x_center - lim
        x_max = x_center + lim
        y_min = y_center - lim
        y_max = y_center + lim
        nx = N
        ny = N

        super().__init__(x_min, x_max, y_min, y_max, nx, ny)


class DebugImage(SquareImage):
    def __init__(self, x_center, y_center, fov, N):
        super().__init__(x_center, y_center, fov, N)

        self.ph = None
        self.sino = None
        self.sino_n = None

    # def set_debug_info(
    #     self,
    #     phantom: Phantom,
    #     sinogram: np.ndarray,
    #     sinogram_noisy: np.ndarray,
    #     scanner: ScanGeometry,
    # ):
    #     self.ph = phantom
    #     self.sino = sinogram
    #     self.sino_n = sinogram_noisy
    #     self.scanner = scanner

    def display(self):
        # TODO: add a gridspec and more precise figure handling
        # TODO: add some real window leveling so that we can verify attenuation values
        fig = plt.figure()
        ax1, ax2, ax3, ax4 = fig.subplots(1, 4)

        if self.ph is None or self.sino is None or self.sino_n is None:
            raise RuntimeError("run DebugImage.set_debug_info before display or save")

        ph_image = self.ph.render(self.x_center, self.y_center, self.fov, self.N)
        recon_image = self._to_grid()

        ax1.imshow(ph_image, cmap="gray")
        ax2.imshow(recon_image, cmap="gray")
        ax3.imshow(self.sino, cmap="gray")
        ax4.imshow(self.sino_n, cmap="gray")
        # ax5.imshow(sino_filt, cmap="gray", vmin=-10, vmax=10)

        plt.show()


if __name__ == "__main__":
    # x_min, x_max, y_min, y_max, nx, ny = -10, 10, -10.0, 10.0, 256, 256
    # img = CartesianImage(x_min, x_max, y_min, y_max, nx, ny)

    img = SquareImage(0.0, 0.0, 20.0, 256)
    img.display()
