from typing import Any, NamedTuple
from .base import Points
import numpy as np


class Grid(NamedTuple):
    X: np.ndarray
    Y: np.ndarray
    image: np.ndarray


class IsoGrid2D(Points):
    def __init__(self, cx: float, cy: float, fov: float, N: int):

        self.cx = cx
        self.cy = cy
        self.fov = fov
        self.N = N

        # WARN: this math may be incorrect by a fencepost
        pixel_size = fov / N
        lim = pixel_size * (N - 1) / 2.0

        x_min = cx - lim
        x_max = cx + lim
        y_min = cy - lim
        y_max = cy + lim

        self.x = np.linspace(x_min, x_max, N)
        self.y = np.linspace(y_min, y_max, N)

    def label(self):
        return f"isogrid2d-{self.N}-{self.fov}cm-{self.cx}-{self.cy}"

    def logical_shape(self) -> tuple[int, ...]:
        return self.N, self.N

    def points(self) -> np.ndarray:
        X, Y = np.meshgrid(self.x, self.y)
        return np.column_stack((X.ravel(), Y.ravel()))

    def format(self, values: np.ndarray, uv: np.ndarray | None = None) -> Any:
        """
        Grid's natural format is a 2d array
        """
        X, Y = np.meshgrid(self.x, self.y)
        grid_shape = (len(self.y), len(self.x))
        recon_image = values.reshape(grid_shape)
        return Grid(X, Y, recon_image)
