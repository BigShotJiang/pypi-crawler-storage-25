from dataclasses import dataclass
from typing import NamedTuple


"""
ReconSpecs represent the geometric basis for specific classes of CT scanners.
They act as standardized communication contracts that resolve naming ambiguity
across the pipeline, ensuring that required physical parameters are delivered
consistently from "hardware"-facing scan results to the reconstruction
algorithms that depend on them.

For now, these should strictly be data holding structures (no methods)
These are simply a means to provide some amount of standardized
"language"
"""


@dataclass(frozen=True)
class Common:
    """
    The common spec provides fields we know to be semi-universal to CT scanner
    specification.
    """

    sid: float  # source to isocenter distance
    sdd: float  # source to detector distance
    n_channels: int  # number of detector channels
    channel_offset: float  # central detector offset


@dataclass(frozen=True)
class ParallelBeam(Common):
    """
    Parallel beam scanners, in addition to their common spec, are charcterized
    via their detector channel width.  Equidistant detectors.
    """

    channel_width: float  # detector channel width in cm


@dataclass(frozen=True)
class CircularFanBeam(Common):
    """
    CircularFanBeam scanners are primarily characterized by their fan angle
    increment, which can be used to find the detector size. Equiangular detectors.
    """

    fan_angle_increment: float  # dector angle increment in rad
