import numpy as np

def decode(profile_samples, num_bits):

    # measurements to chop off the front and back of the profile.
    offset = 2
    interval = 29.3

    # Extract data
    a = np.array([s[3] for s in profile_samples])  # attenuations
    s = np.array([s[0] for s in profile_samples])  # arc lengths

    # interval = int(len(s) / (num_bits+1.10))
    # interval = 28

    bits = []
    for i in range(num_bits+1):
        if i == 0:
            continue

        idx = int(i * interval + offset)

        if a[idx] > 0.5:
            bits.append(1)
        else:
            bits.append(0)

        sample = list(profile_samples[idx])

        sample[3] = -1.0
        profile_samples[idx] = tuple(sample)

    return bytes([sum(bits[i*8+j]<<(7-j) for j in range(8)) for i in range(4)])
    
def decode_with_mf(profile_samples, num_bits=32):
    """
    Decode bit sequence from profile using matched filter concepts.
    
    Args:
        profile_samples: List of (s, x, y, attenuation) tuples
        num_bits: Expected number of bits (default 32)
    
    Returns:
        Decoded bytes object
    """
    # Extract data
    a = np.array([s[3] for s in profile_samples])  # attenuations
    s = np.array([s[0] for s in profile_samples])  # arc lengths
    
    # Calculate sampling resolution (arc length per sample)
    ds = np.mean(np.diff(s)) if len(s) > 1 else 1.0
    
    # Estimate feature sizes based on total arc length and expected structure
    # We expect: start_marker + 32 bits + end_marker
    total_arc_length = s[-1] - s[0]
    estimated_bit_spacing = total_arc_length / (num_bits + 1)
    
    # Code circle diameter is approximately the bit spacing
    code_circle_width = estimated_bit_spacing * 0.8  # Slightly less than spacing
    
    # Number of samples per feature
    samples_per_code_circle = int(code_circle_width / ds)
    
    # Remove DC (window size based on bit spacing)
    dc_window = max(5, int(estimated_bit_spacing / ds))
    a_ac = a - np.convolve(a, np.ones(dc_window)/dc_window, mode='same')
    
    # Create bit template: [background, peak, background]
    # Template width should span about one code circle
    template_samples = max(7, samples_per_code_circle)
    if template_samples % 2 == 0:  # Make odd for symmetry
        template_samples += 1
    
    # Create pulse shape: negative sides, positive center
    template = np.ones(template_samples) * -1
    center_start = template_samples // 3
    center_end = 2 * template_samples // 3
    template[center_start:center_end] = 2
    
    template = template - np.mean(template)  # Zero mean
    template = template / np.linalg.norm(template)  # Unit energy

    # Matched filter: cross-correlate
    correlation = np.correlate(a_ac, template, mode='same')

    # Find start and end of encoded region using original signal
    # Markers have very low attenuation (0.0) compared to background (0.3)
    # Find the two deepest minima
    sorted_indices = np.argsort(a)
    start_idx = min(sorted_indices[0], sorted_indices[1])
    end_idx = max(sorted_indices[0], sorted_indices[1])
    
    # Expected bit positions (uniform spacing in arc length)
    positions = np.linspace(s[start_idx], s[end_idx], num_bits+2)[1:-1]
    
    # Sample correlation at bit positions
    # Adaptive threshold based on correlation statistics
    threshold = np.mean(correlation) + 1.5 * np.std(correlation)
    
    bits = [int(correlation[np.argmin(np.abs(s-p))] > threshold) for p in positions]
    
    # Convert to bytes
    return bytes([sum(bits[i*8+j]<<(7-j) for j in range(8)) for i in range(4)])


def compare_sequences(original_bytes, decoded_bytes):
    """
    Compare original and decoded sequences, calculate information loss.
    
    Args:
        original_bytes: Original byte sequence
        decoded_bytes: Decoded byte sequence
    
    Returns:
        Dictionary with comparison metrics
    """
    # Convert to bit arrays
    orig_bits = []
    for byte in original_bytes:
        for i in range(8):
            orig_bits.append((byte >> (7 - i)) & 1)
    
    dec_bits = []
    for byte in decoded_bytes:
        for i in range(8):
            dec_bits.append((byte >> (7 - i)) & 1)
    
    # Ensure same length
    min_len = min(len(orig_bits), len(dec_bits))
    orig_bits = orig_bits[:min_len]
    dec_bits = dec_bits[:min_len]
    
    # Calculate metrics
    total_bits = len(orig_bits)
    bit_errors = sum(o != d for o, d in zip(orig_bits, dec_bits))
    bit_error_rate = bit_errors / total_bits if total_bits > 0 else 0.0
    
    # Information loss (in bits)
    # Each bit error loses 1 bit of information
    info_loss_bits = bit_errors
    info_loss_percent = (bit_errors / total_bits * 100) if total_bits > 0 else 0.0
    
    return {
        'total_bits': total_bits,
        'bit_errors': bit_errors,
        'bit_error_rate': bit_error_rate,
        'info_loss_bits': info_loss_bits,
        'info_loss_percent': info_loss_percent,
        'original_hex': original_bytes.hex(),
        'decoded_hex': decoded_bytes.hex(),
        'match': original_bytes == decoded_bytes
    }

