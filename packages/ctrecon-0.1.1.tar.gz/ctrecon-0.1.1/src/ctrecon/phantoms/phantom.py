import enum
import numpy as np

from ctrecon.primitives import *


class Phantom(Labeled):
    def __init__(self, objects: list):
        """
        Initialize a Phantom with a list of objects objects.
        The order determines precedence: first objects has highest precedence.
        """
        self.objects = objects

    @classmethod
    def from_csv(cls, filepath: str):
        """
        Create a Phantom from a CSV file where each line represents a Circle.
        The first line has highest precedence, last line has lowest precedence.
        """
        raise NotImplementedError(
            "this code needs to be updated since addition of extra objects"
        )
        objects = []
        with open(filepath, "r") as f:
            for line in f:
                line = line.strip()
                if line:  # Skip empty lines
                    objects.append(Circle.from_csv(line))
        return cls(circles)

    @classmethod
    def from_csv_string(cls, csv_content: str) -> "Phantom":
        """
        Create a Phantom from a CSV string where each line represents a Circle.
        """
        raise NotImplementedError(
            "this code needs to be updated since addition of extra objects"
        )
        circles = []
        for line in csv_content.strip().split("\n"):
            line = line.strip()
            if line:  # Skip empty lines
                circles.append(Circle.from_csv(line))
        return cls(circles)

    def to_csv(self, filepath: str):
        """
        Write the Phantom to a CSV file.
        """
        raise NotImplementedError(
            "this code needs to be updated since addition of extra objects"
        )
        with open(filepath, "w") as f:
            for circle in self.circles:
                f.write(circle.to_csv() + "\n")

    def render(
        self, cx: float, cy: float, fov: float, dim: int
    ) -> tuple[np.ndarray, np.ndarray, np.ndarray]:
        """
        Render the phantom to a 2D array using vectorized masking.

        Args:
            cx, cy: Center of viewport in world coordinates
            fov: Field of view (width and height of square viewport)
            dim: Output matrix dimension (dim x dim pixels)

        Returns:
            np.ndarray of shape (dim, dim) with attenuation values
        """
        # Create output array, initialize to 0 (background)
        image = np.zeros((dim, dim), dtype=float)

        # Calculate pixel size
        pixel_size = fov / dim

        # Generate 1D arrays for the x and y coordinates of the pixel centers
        # We add/subtract pixel_size / 2.0 to center the samples perfectly
        x_coords = np.linspace(
            cx - fov / 2.0 + pixel_size / 2.0, cx + fov / 2.0 - pixel_size / 2.0, dim
        )

        y_coords = np.linspace(
            cy - fov / 2.0 + pixel_size / 2.0, cy + fov / 2.0 - pixel_size / 2.0, dim
        )

        # Create 2D grids of X and Y coordinates.
        # X and Y will both be of shape (dim, dim)
        X, Y = np.meshgrid(x_coords, y_coords)

        # Iterate through objects in REVERSE order (lowest precedence first)
        # This naturally handles overlaps: higher precedence objects overwrite lower ones.
        for obj in reversed(self.objects):

            # Note: Ensure your Shape classes have a self.type string property,
            # or use isinstance(obj, Circle) instead.

            if obj.type == "Circle":
                mask = (X - obj.cx) ** 2 + (Y - obj.cy) ** 2 <= obj.r**2

            elif obj.type == "Rectangle":
                # Translate to local space
                loc_X = X - obj.cx
                loc_Y = Y - obj.cy

                # Rotate points to axis-aligned space
                cos_t, sin_t = np.cos(-obj.angle), np.sin(-obj.angle)
                rot_X = loc_X * cos_t - loc_Y * sin_t
                rot_Y = loc_X * sin_t + loc_Y * cos_t

                # Mask: |x| <= w/2 AND |y| <= h/2
                mask = (np.abs(rot_X) <= obj.w / 2.0) & (np.abs(rot_Y) <= obj.h / 2.0)

            elif obj.type == "Ellipse":
                # Translate to local space
                loc_X = X - obj.cx
                loc_Y = Y - obj.cy

                # Rotate points to axis-aligned space
                cos_t, sin_t = np.cos(-obj.angle), np.sin(-obj.angle)
                rot_X = loc_X * cos_t - loc_Y * sin_t
                rot_Y = loc_X * sin_t + loc_Y * cos_t

                # Apply ellipse mask (using semi-axes wx/2 and wy/2)
                a, b = obj.wx / 2.0, obj.wy / 2.0
                mask = (rot_X / a) ** 2 + (rot_Y / b) ** 2 <= 1.0

            # elif obj.type == "ClippedEllipse":
            #     # 1. Standard Ellipse Transformation & Mask
            #     loc_X = X - obj.cx
            #     loc_Y = Y - obj.cy

            #     cos_t, sin_t = np.cos(-obj.angle), np.sin(-obj.angle)
            #     rot_X = loc_X * cos_t - loc_Y * sin_t
            #     rot_Y = loc_X * sin_t + loc_Y * cos_t

            #     a, b = obj.wx / 2.0, obj.wy / 2.0
            #     ellipse_mask = (rot_X / a) ** 2 + (rot_Y / b) ** 2 <= 1.0

            #     # 2. Clipping Plane Mask (Dot product with normal vector)
            #     # We want points where the vector from the line point (px,py)
            #     # to the sample (X,Y) aligns with the normal vector.
            #     vec_X = X - obj.px
            #     vec_Y = Y - obj.py
            #     plane_mask = (vec_X * obj.nx + vec_Y * obj.ny) >= 0

            #     # 3. Combine masks: Point must be inside the ellipse AND on the correct side of the line
            #     mask = ellipse_mask & plane_mask

            #     # Paint attenuation
            #     image[mask] = obj.attenuation

            elif obj.type == "ForbildShape":
                # 1. Translate to local space
                loc_X = X - obj.cx
                loc_Y = Y - obj.cy

                # 2. Rotate points (Matching PMB 2012 MATLAB matrix Q)
                cos_p, sin_p = np.cos(obj.phi), np.sin(obj.phi)
                rot_X = cos_p * loc_X + sin_p * loc_Y
                rot_Y = -sin_p * loc_X + cos_p * loc_Y

                # 3. Apply base ellipse mask
                mask = (rot_X / obj.a) ** 2 + (rot_Y / obj.b) ** 2 <= 1.0

                # 4. Iteratively evaluate and apply Clipping Planes
                for d, psi_deg in obj.clips:
                    psi = np.radians(psi_deg)
                    # Project unrotated local coordinates onto the clipping normal vector
                    proj = loc_X * np.cos(psi) + loc_Y * np.sin(psi)
                    mask &= proj < d

                # 5. ADDITIVE linear combination
                image[mask] += obj.rho

                # Use continue to bypass the absolute assignment logic below,
                # preserving the additive density.
                continue

            else:
                raise RuntimeError(f"unknown object type: {obj.type}")

            # Paint the attenuation value wherever the mask is True
            image[mask] = obj.attenuation

        return X, Y, image

    ##    def render(self, cx: float, cy: float, fov: float, dim: int) -> np.ndarray:
    ##        """
    ##        Render the phantom to a 2D array.
    ##
    ##        Args:
    ##            cx, cy: Center of viewport in world coordinates
    ##            fov: Field of view (width and height of square viewport)
    ##            dim: Output matrix dimension (dim x dim pixels)
    ##
    ##        Returns:
    ##            np.ndarray of shape (dim, dim) with attenuation values
    ##        """
    ##        # Create output array, initialize to 0 (background)
    ##        image = np.zeros((dim, dim), dtype=float)
    ##
    ##        # Calculate pixel size
    ##        pixel_size = fov / dim
    ##
    ##        # Calculate world coordinates for top-left corner
    ##        world_x_min = cx - fov / 2.0
    ##        world_y_min = cy - fov / 2.0
    ##
    ##        # Iterate through pixels
    ##        for i in range(dim):
    ##            for j in range(dim):
    ##                # Calculate world coordinates of pixel center
    ##                # i is row (y-axis), j is column (x-axis)
    ##                world_x = world_x_min + (j + 0.5) * pixel_size
    ##                world_y = world_y_min + (i + 0.5) * pixel_size
    ##
    ##                # Check circles in order of precedence (highest first)
    ##                for object in self.objects:
    ##
    ##
    ##
    ##                    # Calculate distance from pixel to circle center
    ##                    dx = world_x - circle.cx
    ##                    dy = world_y - circle.cy
    ##                    dist_sq = dx * dx + dy * dy
    ##
    ##                    # If pixel is inside this circle, use its attenuation
    ##                    if dist_sq <= circle.r * circle.r:
    ##                        image[i, j] = circle.attenuation
    ##                        break  # Higher precedence wins, stop checking
    ##
    ##        return image

    def raycast(self, rays: list[Ray], step_size=0.01, max_dist=109.5) -> np.ndarray:

        # Reformat our rays for vectorized calculation
        N = len(rays)

        ray_origins = np.zeros((N, 2))
        ray_directions = np.zeros((N, 2))
        for i, ray in enumerate(rays):
            ray_origins[i, :] = [ray.ox, ray.oy]
            ray_directions[i, :] = [ray.rx, ray.ry]

        # TODO: automatically derive "max dist"

        # We always want to guarantee *sampling distance* for our
        # applications/users (not "number of steps").  We expect this to be
        # more intuitive for physics/math/sampling questions.
        l_vals = np.arange(0.0, max_dist, step_size)
        steps = len(l_vals)

        X = ray_origins[:, 0:1] + ray_directions[:, 0:1] * l_vals
        Y = ray_origins[:, 1:2] + ray_directions[:, 1:2] * l_vals

        ray_sums = np.zeros((N, steps))

        for obj in reversed(self.objects):

            if obj.type == "Circle":
                pass
            elif obj.type == "Rectangle":
                pass
            elif obj.type == "Ellipse":
                pass
            elif obj.type == "ForbildShape":
                pass

        return ray_sums

    # def raycast(self, ray: Ray) -> tuple[float, list[float] | None, list[float] | None]:
    #     """
    #     raycasting is, strictly speaking, not as accurate as the analytic
    #     calculation (which is also not working correctly), however it suffices
    #     for small enough step size (step size << object sizes).
    #     """
    #     segments = []

    #     # filter any circles we do not intersect
    #     for precedence, circle in enumerate(self.circles):
    #         intersections = ray_circle_intersections(circle, ray)

    #         if len(intersections) == 2:
    #             p1, p2 = intersections
    #             segments.append(
    #                 {
    #                     "t_start": p1[0],
    #                     "t_end": p2[0],
    #                     "attenuation": circle.attenuation,
    #                     "precedence": precedence,
    #                 }
    #             )

    #     # No intersections
    #     if len(segments) == 0:
    #         return 0.0, None, None

    #     # Sort segments by precedence
    #     segments.sort(key=lambda s: s["precedence"])

    #     # Ray marching
    #     def sample(l) -> float:
    #         for seg in segments:
    #             if l >= seg["t_start"] and l <= seg["t_end"]:
    #                 return seg["attenuation"]

    #         return 0.0

    #     dl = 0.01  # Should be << object sizes, units are cm
    #     # dl = 0.1  # Should be << object sizes, units are cm
    #     sum = 0
    #     l_values = []
    #     profile = []
    #     for l in np.arange(0, 109.5, step=dl):
    #         l_values.append(l)
    #         sampled_val = dl * sample(l)
    #         profile.append(sampled_val)
    #         sum += sampled_val

    #     return sum, l_values, profile
