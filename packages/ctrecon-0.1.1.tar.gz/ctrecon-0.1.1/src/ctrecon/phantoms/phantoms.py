from enum import global_enum
from ctrecon.primitives import *
from .phantom import Phantom


class HD(Phantom):

    def __init__(self):

        # tuneable elements, units are cm
        bg_attenuation = 0.0192
        ph_radius = 10.0
        insert_radius = 1.5
        insert_ring_radius = 7.0

        elements = []

        bg = Circle(0, 0, ph_radius, bg_attenuation)
        middle_insert = Circle(0, 0, insert_radius, 0)

        elements.append(bg)
        elements.append(middle_insert)

        increment = 2 * math.pi / 7
        for i in range(7):
            x = insert_ring_radius * math.sin(i * increment)
            y = insert_ring_radius * math.cos(i * increment)

            elements.append(Circle(x, y, insert_radius, 0))

        elements.reverse()

        self.circles = elements

    def label(self):
        return "hd-phantom"


class Debug(Phantom):
    def __init__(self):

        # tuneable elements, units are cm
        bg_attenuation = 0.0192
        ph_radius = 10.0

        elements = []

        bg = Circle(0, 0, ph_radius, bg_attenuation)

        findable_insert_1 = Circle(0, 5, 3.0, 0.04)
        findable_insert_2 = Circle(5, 0, 1.5, 0.04)

        # Intuitively, we draw from "bg" -> "fg"
        elements.append(bg)
        elements.append(findable_insert_1)
        elements.append(findable_insert_2)

        # When raycasting, its most efficient to intersect the fg first
        elements.reverse()

        # Save the elements of the phantom
        self.objects = elements

    def label(self):
        return "debug-phantom"


class BinaryCode(Phantom):

    def __init__(
        self,
        bits: list[int],
        obj_size: float = 0.1,
        obj_spacing: float | None = None,
        obj_attenuation: float = 0.04,
        bg_attenuation: float = 0.0192,
    ):

        self.circles = []

        self.n_obj = len(bits)
        self.obj_size = obj_size
        self.obj_radius = obj_size / 2

        if obj_spacing is None:
            self.obj_spacing = obj_size
        else:
            self.obj_spacing = obj_spacing

        # Add the phantom body
        bg = Circle(0, 0, 10.0, bg_attenuation)
        self.circles.append(bg)

        for i, b in enumerate(bits):
            # Skip unset bits
            if b == 0:
                continue

            # Add object for set bit
            cx = i * (self.obj_size + self.obj_spacing) - self._sequence_offset()
            cy = 0.0
            self.circles.append(Circle(cx, cy, self.obj_radius, obj_attenuation))

        self.circles.reverse()
        self.bits = bits

    def label(self):
        return self._get_id()

    def _sequence_offset(self) -> float:
        return (self.n_obj - 1) / 2 * self.obj_spacing + (
            self.n_obj - 1
        ) / 2 * self.obj_size

    def _get_id(self) -> str:
        s = "".join([str(bit) for bit in self.bits])
        return f"{len(self.bits)}bit-{s}-{self.obj_size}cm-phantom"

    def measurement_points(
        self, sampling_interval: float = 0.01
    ) -> list[tuple[float, float]]:
        points = []
        for i in range(self.n_obj):

            # Get obj center
            # (TODO: use the object itself, which already has the center calculated and stored)
            cx = i * (self.obj_size + self.obj_spacing) - self._sequence_offset()
            cy = 0.0

            # Sample the object around the object center
            for j in range(int(self.obj_size / sampling_interval)):
                x = j * sampling_interval - self.obj_size / 2
                points.append((cx + x, cy))

        return points


class SheppLogan(Phantom):
    """
    Instantiates the standard Shepp-Logan phantom using absolute overwriting
    attenuation values.

    Order: Highest precedence (details) to Lowest precedence (background skull).
    Note: Standard tables use semi-axes (a, b). We multiply by 2 for total width/height.
    """

    def label(self) -> str:
        return "shepp-logan-phantom"

    def __init__(self, mu_water=None):

        # Standard Shepp-Logan parameters: (cx, cy, a, b, theta_deg, absolute_rho)
        # Using normalized dimensions spanning roughly [-1, 1]
        parameters = [
            # --- HIGHEST PRECEDENCE (Small details and tumors) ---
            # Three small tumors (rho = 1.03)
            (0.00, 0.100, 0.0460, 0.0460, 0.0, 1.03),
            (0.00, -0.100, 0.0460, 0.0460, 0.0, 1.03),
            (0.00, -0.605, 0.0230, 0.0230, 0.0, 1.03),
            # Three small detail features (rho = 1.03)
            (-0.08, -0.605, 0.0460, 0.0230, 0.0, 1.03),
            (0.06, -0.605, 0.0230, 0.0460, 0.0, 1.03),
            (0.00, 0.350, 0.2100, 0.2500, 0.0, 1.03),
            # --- MEDIUM PRECEDENCE (Ventricles) ---
            # Left and Right Ventricles (rho = 1.00)
            (0.22, 0.000, 0.1100, 0.3100, -18.0, 1.00),
            (-0.22, 0.000, 0.1600, 0.4100, 18.0, 1.00),
            # --- LOW PRECEDENCE (Brain mass) ---
            # Main brain tissue (rho = 1.02)
            (0.00, -0.0184, 0.6624, 0.8740, 0.0, 1.02),
            # --- LOWEST PRECEDENCE (Outer Skull) ---
            # Outer bone shell (rho = 2.00)
            (0.00, 0.000, 0.6900, 0.9200, 0.0, 2.00),
        ]

        if mu_water is None:
            mu_water = 1.0

        objects = []
        for cx, cy, a, b, theta_deg, rho in parameters:
            # Convert semi-axes to full width/height, and degrees to radians
            wx = a * 2.0
            wy = b * 2.0
            angle_rad = math.radians(theta_deg)

            # the factor of 10 is to return the phantom in centimeters
            objects.append(
                Ellipse(
                    10.0 * cx,
                    10.0 * cy,
                    10.0 * wx,
                    10.0 * wy,
                    angle_rad,
                    mu_water * rho,
                )
            )

        self.objects = objects


class ForbildHead(Phantom):  # Assuming it inherits from (Phantom)

    def label(self) -> str:
        return "forbild-head-phantom"

    def __init__(self, mu_water=None, mu_bone=None):
        """
        Instantiates the analytical FORBILD Head phantom based on PMB 2012.
        Default attenuations simulate standard relative densities (Water=1.0, Bone=1.85)
        """
        self.objects = []

        # Physical attenuation baseline
        muW = mu_water if mu_water is not None else 1.0
        muB = mu_bone if mu_bone is not None else 1.85

        # Shared constants from MATLAB
        sha = 0.2 * math.sqrt(3)
        y016b = -14.294530834372887
        a16b = 0.443194085308632
        b16b = 3.892760834372886
        oR = 1  # Flag to include right ear

        # Base shapes matrix E: [cx, cy, a, b, phi, f_orig, nclip]
        E_base = [
            [-4.7, 4.3, 1.79989, 1.79989, 0, 0.010, 0],  # 1
            [4.7, 4.3, 1.79989, 1.79989, 0, 0.010, 0],  # 2
            [-1.08, -9, 0.4, 0.4, 0, 0.0025, 0],  # 3
            [1.08, -9, 0.4, 0.4, 0, -0.0025, 0],  # 4
            [0, 0, 9.6, 12, 0, 1.800, 0],  # 5
            [0, 8.4, 1.8, 3.0, 0, -1.050, 0],  # 6 (MATLAB %7)
            [1.9, 5.4, 0.41633, 1.17425, -31.07698, 0.750, 0],  # 7 (MATLAB %8)
            [-1.9, 5.4, 0.41633, 1.17425, 31.07698, 0.750, 0],  # 8 (MATLAB %9)
            [-4.3, 6.8, 1.8, 0.24, -30, 0.750, 0],  # 9 (MATLAB %10)
            [4.3, 6.8, 1.8, 0.24, 30, 0.750, 0],  # 10 (MATLAB %11)
            [0, -3.6, 1.8, 3.6, 0, -0.005, 0],  # 11 (MATLAB %12)
            [6.39395, -6.39395, 1.2, 0.42, 58.1, 0.005, 0],  # 12 (MATLAB %13)
            [0, 3.6, 2, 2, 0, 0.750, 4],  # 13 (MATLAB %14)
            [0, 9.6, 1.8, 3.0, 0, 1.800, 4],  # 14 (MATLAB %15)
            [0, 0, 9.0, 11.4, 0, 0.750, 3],  # 15 (MATLAB %16a)
            [0, y016b, a16b, b16b, 0, 0.750, 1],  # 16 (MATLAB %16b)
            [0, 0, 9.0, 11.4, 0, -0.750, oR],  # 17 (MATLAB %6)
            [9.1, 0, 4.2, 1.8, 0, 0.750, 1],  # 18 (R_ear)
        ]

        # 1. Generate Left Ear (Resolution Pattern - 80 elements)
        # Replicating MATLAB's nested loop matrix generations
        x0, y0, d0_xy = -7.0, -1.0, 0.04
        d_xy = [0.0357, 0.0312, 0.0278, 0.0250]
        E_leftear = []
        for m in range(4):  # 4 vertical block duplications
            y_shift = m * 12 * d0_xy
            for i in range(4):  # 4 columns of different resolutions
                r = 0.5 * d_xy[i]
                for k in range(5):  # 5 pins per block column
                    x = x0 + 2 * i * d0_xy
                    y = y0 + k * 2 * d_xy[i] + y_shift
                    E_leftear.append([x, y, r, r, 0, 0.750, 0])

        # 2. Generate Right Ear Air Cavities (53 elements)
        cavity1 = [8.8 - 0.4 * i for i in range(9)]
        cavity2 = [0.0] * 9
        for j in range(1, 4):
            kj = 8 - 2 * (j // 3)
            dj = 0.2 * (j % 2)
            c1_app = [cavity1[i] - dj for i in range(kj)]
            cavity1.extend(c1_app)
            cavity1.extend(c1_app)
            cavity2.extend([j * sha] * kj)
            cavity2.extend([-j * sha] * kj)

        E_cavity = []
        for x, y in zip(cavity1, cavity2):
            E_cavity.append([x, y, 0.15, 0.15, 0, -1.800, 0])

        # Combine into master matrix (length 151)
        E_total = E_leftear + E_base + E_cavity

        # Apply physical value adjustments from MATLAB `physical_value` mapping
        # Convert MATLAB 1-based indexing to Python 0-based indexing with `shift=80`
        for i in range(80):
            E_total[i][5] = muB - 1.05 * muW
        E_total[97][5] = muB - 1.05 * muW  # 18+shift (R_ear)
        for i in range(98, 151):
            E_total[i][5] = -muB  # (19:71)+shift

        E_total[84][5] = muB  # 5+shift
        E_total[96][5] = 1.05 * muW - muB  # 17+shift
        E_total[85][5] = -1.05 * muW  # 6+shift
        E_total[93][5] = muB  # 14+shift

        for i in [86, 87, 88, 89, 92, 94, 95]:  # [7 8 9 10 13 15 16]+shift
            E_total[i][5] = muB - 1.05 * muW

        for i in [80, 81, 82, 83, 90, 91]:  # [1 2 3 4 11 12]+shift
            E_total[i][5] = muW * E_total[i][5]

        # Clipping matrix C parameters: d (distance) and psi (angle in degrees)
        C_d = [
            1.2,
            1.2,
            0.27884,
            0.27884,
            0.60687,
            0.60687,
            0.2,
            0.2,
            -2.605,
            -2.605,
            -10.71177,
            y016b + 10.71177,
            8.88740,
            -0.21260,
        ]
        C_psi = [0, 180, 90, 270, 90, 270, 0, 180, 15, 165, 90, 270, 0, 0]

        # Construct objects sequentially, mapping clipping planes
        nclipinfo = 0
        for row in E_total:
            cx, cy, a, b, phi, rho, nclip = row
            nclip = int(nclip)
            clips = []

            # Extract the assigned clipping planes sequentially
            for _ in range(nclip):
                clips.append((C_d[nclipinfo], C_psi[nclipinfo]))
                nclipinfo += 1

            self.objects.append(ForbildShape(cx, cy, a, b, phi, rho, clips))


class WanderingLinePair(Phantom):  # Assuming it inherits from your Phantom base class
    def __init__(
        self,
        cx: float,
        cy: float,
        spatial_frequency: float,
        orientation: float,
        mu_water: float = 1.0,
        mu_line: float = 2.0,
    ):
        """
        Instantiates a wandering line pair phantom for MTF/resolution testing.

        Args:
            cx: Center X coordinate of the 2x2cm line pair patch (cm)
            cy: Center Y coordinate of the 2x2cm line pair patch (cm)
            spatial_frequency: Resolution in line pairs per centimeter (lp/cm)
            orientation: Angle of the lines in radians
            mu_water: Attenuation of the 20cm background phantom
            mu_line: Attenuation of the resolution lines
        """
        self.objects = []
        self.orientation = orientation
        self.cx = cx
        self.cy = cy

        self.freq = spatial_frequency

        # 1. Background: 20cm circular water-equivalent phantom at isocenter
        # A 20cm diameter means a radius of 10.0cm
        self.objects.append(Circle(cx=0.0, cy=0.0, r=10.0, attenuation=mu_water))

        # 2. Wandering Line Pair Patch (2cm x 2cm)
        # spatial_frequency is lp/cm. One line pair is one solid line and one space.
        line_width = 1.0 / (2.0 * spatial_frequency)
        line_length = 2.0
        patch_size = 2.0

        # Total number of solid lines needed to span the 2cm patch
        num_lines = int(patch_size * spatial_frequency)

        # Pre-compute rotation sine/cosine for placing the lines
        cos_t = math.cos(orientation)
        sin_t = math.sin(orientation)

        for i in range(num_lines):
            # Calculate the local X position centered around 0
            # Spacing between lines is 2 * line_width (because of the gap)
            local_x = (i - (num_lines - 1) / 2.0) * (2.0 * line_width)
            local_y = 0.0  # Centered vertically within the patch

            # Apply rotation and translate to the requested patch center (cx, cy)
            global_x = cx + (local_x * cos_t - local_y * sin_t)
            global_y = cy + (local_x * sin_t + local_y * cos_t)

            # Since we iterate in reverse in the render engine, these rectangles
            # will cleanly overwrite the water background using Painter's Algorithm.
            self.objects.append(
                Rectangle(
                    cx=global_x,
                    cy=global_y,
                    w=line_width,
                    h=line_length,
                    angle=orientation,
                    attenuation=mu_line,
                )
            )
        self.objects.reverse()

    def label(self):
        return f"wandering-lines-x{self.cx}-y{self.cy}-{self.orientation}rad-{self.freq}lpcm"

    def measurement_points(
        self, sampling_interval: float = 0.01
    ) -> list[tuple[float, float]]:
        """
        Generates sample locations perpendicular to the bar pattern
        across the center of the 2x2cm patch.
        """
        points = []
        patch_size = 2.0

        # Calculate how many samples fit across the 2cm patch
        num_samples = int(patch_size / sampling_interval)

        # Pre-compute trigonometry for the rotation
        cos_t = math.cos(self.orientation)
        sin_t = math.sin(self.orientation)

        for j in range(num_samples):
            # Calculate local coordinate moving perpendicular to the lines.
            # This spans from -1.0 to +1.0 (for a 2.0cm patch)
            local_x = j * sampling_interval - (patch_size / 2.0)

            # We measure straight across the center of the patch, so local Y is 0
            local_y = 0.0

            # Rotate to match the patch's orientation and translate to its center
            global_x = self.cx + (local_x * cos_t - local_y * sin_t)
            global_y = self.cy + (local_x * sin_t + local_y * cos_t)

            points.append((global_x, global_y))

        return points
