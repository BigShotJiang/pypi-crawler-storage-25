import multiprocessing
import numpy as np


def _add_noise_to_projection(proj: np.ndarray, n_photons: int):
    noisy_proj = np.zeros(proj.shape)
    n_channels = proj.size

    for col in range(n_channels):
        curr_attenuation = proj[col]
        bank = np.random.random((n_photons,))

        # We treat exp(-mu) as the probability of absorption along
        # the path I don't fully know if this is valid, but it gets
        # us something that looks moderately like noise.
        counts = np.sum(bank < np.exp(-curr_attenuation))

        max_attenuation = 10.0

        # This represents the photon-starved case where we lack the correct
        # number of photons to properly estimate the attenuation
        if counts == 0:
            noisy_proj[col] = max_attenuation
            # noisy_proj[col] = 0.0
            continue

        # This is the "correct" case, where we have at least some
        # measure of attenuation
        noisy_proj[col] = -np.log(counts / n_photons)

    return noisy_proj


def add_noise_mp(sinogram: np.ndarray, n_photons: int, n_cpu: int = 8):
    with multiprocessing.Pool(n_cpu) as pool:
        results = pool.starmap(
            _add_noise_to_projection, [(proj, n_photons) for proj in sinogram]
        )

    # map results back to sinogram
    sinogram_noisy = np.zeros(sinogram.shape)
    for i, result in enumerate(results):
        sinogram_noisy[i, :] = result

    return sinogram_noisy


def add_noise(sinogram: np.ndarray, n_photons: int) -> np.ndarray:
    # There's limited value in throwing only a few random numbers in paralled
    if n_photons > 1000:
        return add_noise_mp(sinogram, n_photons)

    return add_noise_single_thread(sinogram, n_photons)


def add_noise_single_thread(sinogram: np.ndarray, n_photons: int) -> np.ndarray:
    n_proj, n_channels = sinogram.shape[0], sinogram.shape[1]

    # Run a crude MC noise simulation if the number of photons
    # is specified
    sinogram_noisy = np.zeros((n_proj, n_channels))
    for row in range(n_proj):
        for col in range(n_channels):
            curr_attenuation = sinogram[row, col]
            bank = np.random.random((n_photons,))

            # We treat exp(-mu) as the probability of absorption along
            # the path I don't fully know if this is valid, but it gets
            # us something that looks moderately like noise.
            counts = np.sum(bank < np.exp(-curr_attenuation))

            # This represents the photon-starved case where we lack the correct
            # number of photons to properly estimate the attenuation
            max_attenuation = 10.0
            if counts == 0:
                sinogram_noisy[row, col] = max_attenuation
                continue

            sinogram_noisy[row, col] = -np.log(counts / n_photons)

    return sinogram_noisy
