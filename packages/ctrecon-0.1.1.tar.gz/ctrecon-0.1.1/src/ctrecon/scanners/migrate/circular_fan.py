import math

import numpy as np

from .base import Scanner
from .pencil_beam import PencilBeam
from ctrecon.primitives import Ray


class CircularFan(Scanner):
    def _rcn_rebin(
        self, sinogram: np.ndarray, scan_metadata: list[_ProjectionMeta]
    ) -> tuple[np.ndarray, PencilBeam]:
        pbd = PencilBeam(self.r_si, self.r_sd, self.n, self.dt)

        # TODO: do the rebin here
        raise NotImplementedError

        return np.zeros(sinogram.shape), pbd

    def recon(
        self,
        points: list[tuple],
        sinogram: np.ndarray,
        scan_metadata: list[_ProjectionMeta],
        n_cpu: int = 8,
    ) -> list[tuple]:
        sinogram_rebinned, pbd = self._rcn_rebin(sinogram, scan_metadata)
        return pbd.recon(points, sinogram_rebinned, scan_metadata, n_cpu=n_cpu)

    def at(self, tube_angle: float) -> list[Ray]:
        rays = []

        # Source position
        rx = np.cos(tube_angle)
        ry = np.sin(tube_angle)

        sx = -self.r_si * rx
        sy = -self.r_si * ry

        # Identify the locations on the circular detector
        central_det = (self.n - 1) / 2 + self.offset
        fan_increment = math.asin(self.dt / self.r_sd)
        for i in range(self.n):
            beta = (i - central_det) * fan_increment
            dx = sx + self.r_sd * math.cos(tube_angle + beta)
            dy = sy + self.r_sd * math.sin(tube_angle + beta)
            rays.append(Ray.from_points(sx, sy, dx, dy))

        return rays
