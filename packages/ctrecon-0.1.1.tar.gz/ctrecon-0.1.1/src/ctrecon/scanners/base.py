from typing import Any, Generator
from dataclasses import dataclass, field
import numpy as np
from ctrecon.phantoms import Phantom
from ctrecon.primitives import Labeled


@dataclass
class View:
    """Standardized geometry passed from the Scanner to the Engine.
    A view describes a collection of rays representing a single abstract projection"""

    index: int
    origins: np.ndarray  # Shape: (total_rays, 2)
    directions: np.ndarray  # Shape: (total_rays, 2)

    logical_shape: tuple[int, ...]  # e.g., (n_views, num_detector_pixels)


# from .scan_engines import NaiveEngine, ScanEngine
class ScanEngine(Labeled):
    def validate_hardware(self, Scanner):
        """query the scanner to ensure it provides sufficient
        detail/information. when implementing, favor trying to get the user a
        reconstruction with as little information as possible.
        """
        raise NotImplementedError

    def compute_transit(
        self, ph: Phantom, ray_origins: np.ndarray, ray_directions: np.ndarray
    ) -> tuple[np.ndarray, dict]:
        raise NotImplementedError


class ViewAlignedData:
    """This is purely a documentation class indicating that the inheriting
    structure organizes its data into ndarrays where the first dimension
    corresponds to the view index"""

    pass


@dataclass
class Protocol(ViewAlignedData, Labeled):
    """Defines the geometric and physical parameters for a scan.
    The protocol represents the scanning *intent*."""

    name: str
    n_views: int

    # GEOMETRY (trajectory)  this may require future reconsideration
    theta: np.ndarray

    # --- PHYSICS / TECHNIQUE ---
    incident_photons: np.ndarray | None = None
    # kvp_spectra: list[np.ndarray] | None = None

    def label(self):
        return f"protocol-{self.name}"

    @classmethod
    def uniform(cls, theta_start: float, theta_stop: float, proj_per_rotation):
        """
        uniform returns what most of us would consider the "default" CT
        protocol.  This protocol is parameterized by the "view angle" theta,
        from which all other geometry can be derived.  This parameterization is
        suitable for 2D and many 3D CT systems. Does not include the
        theta_stop. For a "single rotation" scan, you would get an array:
        [0..2*pi).  This scan yields N=proj_per_rotation distinct locations
        from which to "image."
        """

        delta_theta = (theta_stop - theta_start) / (2 * np.pi)
        n_views = int(delta_theta * proj_per_rotation)
        theta = np.linspace(theta_start, theta_stop, n_views)

        return cls(
            name=f"uniform-{np.round(theta_start,2)}-{np.round(theta_stop),2}-{proj_per_rotation}",
            n_views=n_views,
            theta=theta,
        )


@dataclass
class Telemetry(ViewAlignedData):
    """Telemetry represents the scanning protocol that was *carried out*
    If the protocol is the intent, the telemetry is the record of how close we got.

    In the case of a real CT scanner, this might record instantaneous tube current
    actual tube angle measured, actual table positions, etc.

    In our simulations this might record actual total number of photons detected,
    or simulation metrics (time/projection).
    """

    @classmethod
    def from_projection_logs(cls, logs: list[dict], **fixed_fields):
        """
        The Factory: Consolidates single-view dictionaries into a Telemetry object.
        """
        if not logs:
            return cls(**fixed_fields)

        # 1. Identify all keys present in the logs
        keys = logs[0].keys()

        # 2. Pivot: List of dicts -> Dict of lists
        # We use a comprehension to "unzip" the logs
        consolidated = {key: np.array([log.get(key) for log in logs]) for key in keys}

        return cls(custom_metrics=consolidated)

    # The Extensible Dictionary (The Wild West). This approach highlights to
    # future developers that we are not trying to explicitly control this
    # beyond the "view aligned" array storage.  Results may vary.
    custom_metrics: dict[str, np.ndarray] = field(default_factory=dict)

    def __setitem__(self, key: str, value: np.ndarray):
        """Allows `telemetry["gantry_wobble"] = data` syntax."""
        self.custom_metrics[key] = value

    def __getitem__(self, key: str) -> np.ndarray:
        """Allows `data = telemetry["gantry_wobble"]` syntax."""
        return self.custom_metrics[key]

    def __contains__(self, key: str) -> bool:
        return key in self.custom_metrics


@dataclass
class ScanResult:
    """ScanResult captures, organizes, and standardizes empirical output of a scan

    TODO: it should also handle serialization if needed."""

    id: str
    tags: set[str] | None = None
    scanner: Scanner | None = None
    protocol: Protocol | None = None
    telemetry: Telemetry | None = None
    sinogram: np.ndarray | None = None

    def must_get_scanner(self) -> Scanner:
        if self.scanner is None:
            raise ValueError("scanner is None")
        return self.scanner

    def must_get_protocol(self) -> Protocol:
        if self.protocol is None:
            raise ValueError("protocol is None")
        return self.protocol

    def must_get_sinogram(self) -> np.ndarray:
        if self.sinogram is None:
            raise ValueError("sinogram is None")
        return self.sinogram


# Scanners have one job: they scan things
#
# In our model of CT scanning, these translate a physical object into a
# sinogram representation of that object using the details implemented by the
# specific class instance.  We try to dictate as little as possible structure
# beyond the data that goes in (a phantom) and the minimal geometric information
# required to get a scan.
class Scanner(Labeled):

    # All scanners MUST provide a spec attribute.
    # see specs.py
    # The "any" will disable downstream type-checking, however
    # we get to use a very direct structures in the reconstruction
    # code that correspond to the scanners being reconstructed.
    # If specific typing is required, that should be handled in the engine
    # via the "supports" call, or in the compute block.
    spec: Any

    def scan(
        self,
        ph: Phantom,
        protocol: Protocol | None = None,
        engine: ScanEngine | None = None,
        id: str | None = None,
        tags: tuple | None = None,
    ) -> ScanResult:

        if protocol is None:
            protocol = self.default_protocol()

        if engine is None:
            engine = self.default_engine()

        if id is None:
            id = f"{self.label()}-{ph.label()}-{engine.label()}-{protocol.label()}"

        tag_set = None
        if tags is not None:
            tag_set = set(tags)

        first_view = next(self.generate_views(protocol))
        full_shape = (len(protocol.theta), *first_view.logical_shape)
        sinogram = np.zeros(full_shape, dtype=np.float32)

        # translate the protocol into concrete, geometry-specific "views"
        # views provide rays for the raycasting engine
        logs = []
        for view in self.generate_views(protocol):
            # Run the engine
            flat_projection, projection_log = engine.compute_transit(
                ph, view.origins, view.directions
            )
            # Engines can return dictionaries to be collected into
            # view-level "Telemetry".
            logs.append(projection_log)

            projection = flat_projection.reshape(view.logical_shape)
            sinogram[view.index, :] = projection

        telemetry = Telemetry.from_projection_logs(logs)

        # Return final data in our results structure
        return ScanResult(
            id,
            tags=tag_set,
            scanner=self,
            sinogram=sinogram,
            telemetry=telemetry,
            protocol=protocol,
        )

    # Optional methods for users
    # possibly useful in the future if we want to "wrap" real scanner hardware.
    def set_metadata(self, meta: dict):
        """
        Metadata is a configurable dictionary of additional information
        we may want to have attached to ScanResults for serialization or process tracking.
        """
        self._metadata = meta

    def metadata(self) -> dict:
        """
        get_metadata returns the scanner's metadata.
        returns an empty dictionary if no metadata has been set.
        """
        return getattr(self, "_metadata", {})

    # For all intents and purposes, required to preserve broad library functionality/utility
    def generate_views(self, protocol: Protocol) -> Generator[View]:
        raise NotImplementedError

    def default_protocol(self) -> Protocol:
        raise NotImplementedError

    def default_engine(self) -> ScanEngine:
        raise NotImplementedError
