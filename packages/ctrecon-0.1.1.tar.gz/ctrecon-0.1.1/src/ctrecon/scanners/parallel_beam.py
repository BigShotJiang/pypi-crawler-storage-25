from typing import Generator
import numpy as np

from .base import ScanEngine, Scanner, Protocol, View
from .naive_engine import NaiveEngine

from ctrecon import specs


def next_pwr_2(x) -> int:
    # Use current value if already a power of 2
    if x & (x - 1) == 0:
        return x

    return 1 << (x - 1).bit_length()


class ParallelBeam(Scanner):
    """
    PencilBeam provides our fundamental geometry for reconstruction
    at the moment.  All reconstruction logic, including filter generation,
    assumes that we have a parallel or pseudo parallel geometry.
    """

    # scanner = scanners.PencilBeamScanner(59.5, 109.5, n_channels, det_size)
    def __init__(
        self,
        r_si_cm: float,
        r_sd_cm: float,
        n_channels: int,
        det_size_cm: float,
        offset: float = 0.0,
    ):
        self.spec = specs.ParallelBeam(
            r_si_cm, r_sd_cm, n_channels, offset, det_size_cm
        )

    def label(self) -> str:
        s = self.spec

        # This is downright baroque. We need better ways to label things
        # this looks like the DRO naming scheme, only we also have a phantom
        # and a protocol to describe.
        return f"parallel-beam-{s.sid}-{s.sdd}-{s.n_channels}-{s.channel_width}-{s.channel_offset}"

    def default_protocol(self) -> Protocol:
        return Protocol.uniform(0, 2 * np.pi, 360)

    def default_engine(self) -> ScanEngine:
        n = NaiveEngine()
        # While I like the idea of auto-calculating a step size
        # this should really derive from the *phantom* and not the scanner.
        # I definitely noticed "odd" behavior when I shrunk my FOV, which felt
        # counter-intuitive.  But in hindsight, makes sense.
        # step_size = self.spec.channel_width / 10

        # Using a fixed step size for now
        # I think this behavior is more intuitive, and step size can
        # be configured directly for users who need it. 1/10 of a mm
        # feels like a pretty solid starting point that would only miss very small
        # objects.
        step_size = 0.01  # cm
        n.configure(step_size=step_size, max_dist=self.spec.sdd)
        return n

    def generate_views(self, protocol: Protocol) -> Generator[View]:
        """A simple PencilBeam scan's ray geometry can be completely
        protocolized via its tube angle"""

        for view_idx, view_angle in enumerate(protocol.theta):

            n_channels = self.spec.n_channels
            origins = np.zeros((n_channels, 2))
            directions = np.zeros((n_channels, 2))

            # For parallel beam, all rays travel in the same direction
            # Direction from source side toward detector side
            rx = np.cos(view_angle)
            ry = np.sin(view_angle)

            directions[:, 0] = rx
            directions[:, 1] = ry

            # Perpendicular direction for detector array (rotated 90° from ray direction)
            perp_x = -np.sin(view_angle)
            perp_y = np.cos(view_angle)

            # Calculate detector positions
            # TODO: this can probably leverage numpy's efficient
            # matrix math better
            ts = []
            central_det = (n_channels - 1) / 2 + self.spec.channel_offset
            for i in range(n_channels):
                t = (i - central_det) * self.spec.channel_width
                ts.append(t)

                # Position ray "behind" isocenter, offset laterally
                # Start at -r_si distance (opposite to ray direction)
                ox = -self.spec.sid * rx + t * perp_x
                oy = -self.spec.sid * ry + t * perp_y

                origins[i, :] = np.array([ox, oy])

            yield View(view_idx, origins, directions, (n_channels,))


######     def _bl_ramp_filter(self) -> np.ndarray:
######         min_size = 2 * self.n - 1
######         target_size = next_pwr_2(min_size)
######
######         filt = np.zeros(target_size)
######         for i, n in enumerate(np.arange(-target_size / 2, target_size / 2)):
######             if n == 0:
######                 filt[i] = 1 / (4 * self.dt * self.dt)
######             elif n % 2 == 1:
######                 filt[i] = -1 / (n * math.pi * self.dt * n * math.pi * self.dt)
######             elif n % 2 == 0:
######                 filt[i] = 0
######
######         return filt
######
######     # Should only be applied after rebinning, before filtering
######     def _upsample(
######         self, sinogram: np.ndarray, up_factor: int = 2
######     ) -> tuple[np.ndarray, "PencilBeam"]:
######         # parameters for the new detector
######         n = self.n * up_factor
######         dt = self.dt / float(up_factor)
######         det_type = type(self)
######         offset = float(up_factor) * self.offset
######
######         # Upsample the sinogram
######         central_det = (self.n - 1) / 2 + self.offset
######         org_sample_points = (np.arange(self.n) - central_det) * self.dt
######
######         new_central_det = (n - 1) / 2 + offset
######         new_sample_points = (np.arange(n) - new_central_det) * dt
######
######         n_proj = sinogram.shape[0]
######
######         up_sinogram = np.zeros((n_proj, n))
######         for i in range(n_proj):
######             up_sinogram[i, :] = np.interp(
######                 new_sample_points, org_sample_points, sinogram[i, :]
######             )
######
######         return up_sinogram, det_type(self.r_si, self.r_sd, n, dt, offset=offset)
######
######     # this filter function assumes pencil beam geometry
######     # or a suitably rebinned fan.
######     def _rcn_filter(self, sinogram, sharpness=1.0) -> np.ndarray:
######         # generate a band-limited ramp filter for the given detector
######         # use power of two optimization for FFT operations
######         filt = self._bl_ramp_filter()
######
######         pad_size = filt.size - sinogram.shape[1]
######
######         if pad_size % 2 != 0:
######             raise RuntimeError("pad size must be an even number")
######
######         pad_size = int(pad_size / 2)
######
######         filt_f = np.fft.fft(np.fft.fftshift(filt))
######
######         # pad sinogram to next greatest power of two
######         pad_dims = ((0, 0), (pad_size, pad_size))
######         sinogram_padded = np.pad(sinogram, pad_dims)
######         sinogram_filtered = np.zeros(sinogram_padded.shape)
######
######         # apply filter to all rows of the sinogram
######         for i, projection in enumerate(sinogram_padded):
######             proj_f = np.fft.fft(projection)
######
######             # NOTE: Don't forget the extra factor of self.dt, since we're performing a discrete convolution!!!!
######             sinogram_filtered[i, :] = self.dt * np.real(
######                 np.fft.ifft(np.multiply(proj_f, filt_f))
######             )
######
######         # TODO: cut off the padded portion of the sinogram?
######         # sinogram_filtered = sinogram_filtered[:, offset : offset + self.n]
######         sinogram_filtered = sinogram_filtered[:, pad_size : pad_size + self.n]
######
######         return sinogram_filtered
######
######     # backproject data from a filtered sinogram to reconstruct
######     # location (x,y)
######     def _rcn_backproject(
######         self,
######         x: float,
######         y: float,
######         sinogram: np.ndarray,
######         scan_metadata: list[_ProjectionMeta],
######     ) -> tuple[float, float, float]:
######         # WARN: naive implementation
######         # TODO: (if too slow) precalculate interpolation points and use 2D interpolation
######
######         # to calculate voxels.
######         mu = 0.0
######         d_theta = math.pi / len(scan_metadata)
######         for prj, md in zip(sinogram, scan_metadata):
######             # Calculate detector coordinate
######             # t = x * math.cos(md.tube_angle) + y * math.sin(md.tube_angle)
######             t = -x * math.sin(md.tube_angle) + y * math.cos(md.tube_angle)
######
######             # Calculate detector index from coordinate
######             # TODO: move central detector calculation to scanner?
######
######             central_det = (self.n - 1) / 2.0 + self.offset
######
######             # Bilinear interpolation
######             t_idx = t / self.dt + central_det
######             t_low, t_high = math.floor(t_idx), math.ceil(t_idx)
######             w = t_idx - float(t_low)
######
######             # handle interpolation outside of project bounds
######             if t_low < 0:
######                 continue
######
######             if t_high >= len(prj):
######                 continue
######
######             mu += (1.0 - w) * prj[t_low] + w * prj[t_high]
######             # mu += w * prj[t_low] + (1.0 - w) * prj[t_high]
######
######         return x, y, d_theta * mu
######
######     def at(self, tube_angle: float) -> list[Ray]:
######         # For parallel beam, all rays travel in the same direction
######         # Direction from source side toward detector side
######         rx = np.cos(tube_angle)
######         ry = np.sin(tube_angle)
######
######         # Perpendicular direction for detector array (rotated 90° from ray direction)
######         perp_x = -np.sin(tube_angle)
######         perp_y = np.cos(tube_angle)
######
######         rays = []
######
######         # Calculate detector positions
######         # TODO: this can probably leverage numpy's efficient
######         # matrix math better
######         ts = []
######         central_det = (self.n - 1) / 2 + self.offset
######         for i in range(self.n):
######             t = (i - central_det) * self.dt
######             ts.append(t)
######
######             # Position ray origin far behind isocenter, offset laterally
######             # Start at -r_si distance (opposite to ray direction)
######             ox = -self.r_si * rx + t * perp_x
######             oy = -self.r_si * ry + t * perp_y
######
######             rays.append(Ray(ox, oy, rx, ry))
######
######         return rays
######
######     # recon calculates "points" from the given sinogram + metadata, based on the underlying scan geometry ("self")
######     # it is up to the user to reshape those points into a 2D image
######     def recon(
######         self,
######         points: list[tuple],
######         sinogram: np.ndarray,
######         scan_metadata: list[_ProjectionMeta],
######         n_cpu: int = 8,
######     ) -> list[tuple]:
######         # upsample the number of detector rows to avoid circular
######         # convolution artifacts
######         sinogram_upsampled, new_scanner = self._upsample(sinogram)
######
######         # filter the sinogram using the updated geometry
######         sinogram_filtered = new_scanner._rcn_filter(sinogram_upsampled)
######
######         # Do the backprojection in parallel. Each point (x,y) is
######         # deployed into the multiprocessing pool.
######
######         if n_cpu == 1:
######             from itertools import starmap
######
######             recon_result = starmap(
######                 new_scanner._rcn_backproject,
######                 [(pt[0], pt[1], sinogram_filtered, scan_metadata) for pt in points],
######             )
######         else:
######             with multiprocessing.Pool(n_cpu) as pool:
######                 recon_result = pool.starmap(
######                     new_scanner._rcn_backproject,
######                     [(pt[0], pt[1], sinogram_filtered, scan_metadata) for pt in points],
######                 )
######
######         return recon_result
