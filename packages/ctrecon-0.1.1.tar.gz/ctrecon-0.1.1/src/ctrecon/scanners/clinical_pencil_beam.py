from numpy import pi
from ctrecon.scanners import Protocol
from ctrecon import specs
from .parallel_beam import ParallelBeam


class ClinicalPencilBeam(ParallelBeam):
    """
    This gets us physical sizes/shapes analogous to
    a clinical scanner in the UCLA fleet. It does *not* reflect a real
    scanner geometry.
    """

    def __init__(self):
        fov = 50.0
        n_det = 736
        dt = fov / n_det
        self.spec = specs.ParallelBeam(59.5, 109.5, n_det, 0.25, dt)

    def label(self):
        return "clin-geom-pencil-beam"

    def default_protocol(self) -> Protocol:
        return Protocol.uniform(0, 2 * pi, 1152)
