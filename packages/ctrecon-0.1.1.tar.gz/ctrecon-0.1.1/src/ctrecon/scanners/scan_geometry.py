import multiprocessing
import math

import numpy as np

from ctrecon.phantoms import Phantom
from ctrecon.primitives import Ray


# TODO: Reflect on this; adapt to work in my code
def vectorized_ray_march(ray_origins, ray_directions, max_dist, steps, objects):
    """
    ray_origins: (N, 2) array of (x,y) origins
    ray_directions: (N, 2) array of (x,y) normalized directions
    objects: list of shapes (highest precedence first)
    """
    N = len(ray_origins)

    # 1. Create the marching steps for all rays simultaneously
    # t_vals shape: (steps,)
    t_vals = np.linspace(0, max_dist, steps)

    # 2. Compute ALL (x, y) coordinates for ALL rays at ALL steps
    # Using broadcasting to get shape (N, steps)
    X = ray_origins[:, 0:1] + ray_directions[:, 0:1] * t_vals
    Y = ray_origins[:, 1:2] + ray_directions[:, 1:2] * t_vals

    # 3. Initialize the attenuation profile with zeros (background)
    attenuation_profile = np.zeros((N, steps))

    # 4. Evaluate shapes in REVERSE precedence (lowest priority first)
    # This naturally handles overlaps. High priority shapes overwrite low ones.
    for obj in reversed(objects):

        if obj.type == "Circle":
            # Mathematical mask: (X - cx)^2 + (Y - cy)^2 <= r^2
            mask = (X - obj.cx) ** 2 + (Y - obj.cy) ** 2 <= obj.r**2

        elif obj.type == "Rectangle":
            # Translate to local space
            loc_X = X - obj.cx
            loc_Y = Y - obj.cy

            # Rotate points to AABB space
            cos_t, sin_t = np.cos(-obj.angle), np.sin(-obj.angle)
            rot_X = loc_X * cos_t - loc_Y * sin_t
            rot_Y = loc_X * sin_t + loc_Y * cos_t

            # Mask: |x| <= w/2 AND |y| <= h/2
            mask = (np.abs(rot_X) <= obj.w / 2) & (np.abs(rot_Y) <= obj.h / 2)

        elif obj.type == "Ellipse":
            # 1. Translate to local space
            loc_X = X - obj.cx
            loc_Y = Y - obj.cy

            # 2. Rotate points to axis-aligned space
            cos_t, sin_t = np.cos(-obj.angle), np.sin(-obj.angle)
            rot_X = loc_X * cos_t - loc_Y * sin_t
            rot_Y = loc_X * sin_t + loc_Y * cos_t

            # 3. Apply ellipse mask (using semi-axes wx/2 and wy/2)
            a, b = obj.wx / 2.0, obj.wy / 2.0
            mask = (rot_X / a) ** 2 + (rot_Y / b) ** 2 <= 1.0

            # Paint attenuation
            attenuation_profile[mask] = obj.attenuation
        elif obj.type == "ForbildShape":
            # 1. Translate to local space
            loc_X = X - obj.cx
            loc_Y = Y - obj.cy

            # 2. Rotate points (Matching PMB 2012 MATLAB matrix Q)
            cos_p, sin_p = np.cos(obj.phi), np.sin(obj.phi)
            rot_X = cos_p * loc_X + sin_p * loc_Y
            rot_Y = -sin_p * loc_X + cos_p * loc_Y

            # 3. Apply base ellipse mask
            mask = (rot_X / obj.a) ** 2 + (rot_Y / obj.b) ** 2 <= 1.0

            # 4. Iteratively evaluate and apply Clipping Planes
            for d, psi_deg in obj.clips:
                psi = np.radians(psi_deg)
                # Project unrotated local coordinates onto the clipping normal vector
                proj = loc_X * np.cos(psi) + loc_Y * np.sin(psi)
                mask &= proj < d

            # 5. ADDITIVE linear combination
            attenuation_profile[mask] += obj.rho

            # Use continue to bypass the absolute assignment logic below,
            # preserving the additive density.
            continue
        else:
            raise RuntimeError(f"unrecognized object type {obj.type}")

        # "Paint" the attenuation value where the mask is True
        attenuation_profile[mask] = obj.attenuation

    # 'attenuation_profile' now perfectly represents what every ray hit
    # at every step, respecting exact precedence and overlaps.
    return t_vals, attenuation_profile


# Describes any useful information about a Projection
class _ProjectionMeta:
    def __init__(self, tube_angle: float):
        self.tube_angle = tube_angle

    def _get_header(self):
        return ["tube-angle"]


def load_metadata(fp: str) -> list[_ProjectionMeta]:
    import csv

    metadata = []

    with open(fp, "r") as csvfile:

        reader = csv.DictReader(csvfile)

        for row in reader:

            tube_angle = float(row["tube-angle"])
            metadata.append(_ProjectionMeta(tube_angle))

    return metadata


def save_metadata(metadata: list[_ProjectionMeta], fp: str):
    import csv

    with open(fp, "w") as csvfile:
        wr = csv.writer(csvfile)

        for i, meta in enumerate(metadata):
            if i == 0:
                wr.writerow(meta._get_header())
            wr.writerow([meta.tube_angle])


# Scan geometry gives us an iterator for rays at a given
# projection angle.  We assume all "scanners" share isocenter at 0,0.
class ScanGeometry:
    def __init__(
        self, r_si: float, r_sd: float, n: int, dt: float, offset: float = 0.0
    ):
        self.n = n
        self.dt = dt
        self.r_si = r_si  # Source isocenter distance
        self.r_sd = r_sd  # Source detector difference
        self.offset = offset  # Detector offsets in units of detectors

    def __str__(self):
        return f"{type(self).__name__} - n: {self.n}, dt: {self.dt}, r_src_iso: {self.r_si}, r_src_det: {self.r_sd}, det_offset: {self.offset}"

    def at(self, tube_angle: float) -> list[Ray]:
        """
        ScanGeometry.at calculates the set of rays comprising the projection at a given angle

        Inputs:
            tube_angle: angle of the x-ray source in radians

        Returns:
            list[Ray]: list of all Ray objects for the projection
        """
        raise NotImplementedError

    def project(self, ph: Phantom, angle: float) -> np.ndarray:
        """
        ScanGeometry.project calculates the forward projection through a phantom
        at the given angle

        Inputs:
            ph: a Phantom object derived from the phantom base class
            angle: angle of the x-ray source in radians

        Returns:
            np.ndarray: the 1d array representing the projection at 'angle'
        """
        return self.project_rays(ph, self.at(angle))

    def project_rays(self, ph: Phantom, rays: list[Ray]) -> np.ndarray:
        """
        ScanGeometry.project_rays calculates the forward projection through a phantom
        for a given set of ray objects

        Inputs:
            ph: a Phantom object derived from the phantom base class
            rays: a list of Ray objects through which to calculate a forward projection

        Returns:
            np.ndarray: the 1d array representing the projection at 'angle'
        """
        raise RuntimeError("PROJECT RAYS TEMPORARILY DOWN")
        projection = np.zeros((1, self.n))
        for i, ray in enumerate(rays):
            projection[0, i], _, _ = ph.raycast(ray)
        return projection

    def scan(
        self,
        ph: Phantom,
        num_proj: int = 180,
        n_cpu: int = 8,
        max_theta: float = math.pi,
    ) -> tuple[np.ndarray, list[_ProjectionMeta]]:
        """
        ScanGeometry.scan performs a simulated CT scan through a phantom

        Inputs:
            ph: a Phantom object derived from the phantom base class
            num_proj: number of projections to acquire (default 180)
            n_cpu: number of multiprocessing threads to use (default 8)
            max_theta: acquire num_proj spaced between [0, max_theta) (endpoint is excluded)
            n_photons: (optional) if set, run an additional pseudo Monte Carlo simulation using n_photons per ray.

        Returns:
            np.ndarray: noise-free (analytic) sinogram with dimensions num_proj x scanner.num_channels
            np.ndarray | None: noisy sinogram, if n_photons is non-zero (same dimensions as sinogram)
            list[_ProjectionMeta]: list of metadata for each projection with len()== num_proj
        """
        # Build the scan metadata
        tube_angles = np.linspace(0, max_theta, num=num_proj, endpoint=False)

        scan_metadata = []
        for angle in tube_angles:
            scan_metadata.append(_ProjectionMeta(angle))

        # Acquire projections at all angles

        with multiprocessing.Pool(n_cpu) as p:
            result = p.starmap(self.project, [(ph, angle) for angle in tube_angles])

        # Assemble readout into a final sinogram
        sinogram = np.zeros((num_proj, self.n))
        for i, row in enumerate(result):
            sinogram[i, :] = row

        # sinogram_noisy = None
        # if n_photons != 0:
        #     sinogram_noisy = add_noise(sinogram, n_photons)

        return sinogram, scan_metadata

    # For a scanner to be generally useful, is should provide us with a reconstruction
    # function.  This function recovers attenuation values at (x,y) using the given metadata.
    #
    # recon simply calculates these "points" from the given sinogram +
    # metadata, based on the underlying scan geometry ("self") it is up to the
    # user to reshape those points into a 2D image.
    def recon(
        self,
        points: list[tuple],
        sinogram: np.ndarray,
        scan_metadata: list[_ProjectionMeta],
        n_cpu=8,
    ) -> list[tuple]:
        """
        ScanGeometry.recon performs a reconstruction of a given sinogram using
        the configured geometry.

        Inputs:
            points: list of tuples to reconstruct. each tuple is (x, y) locations in scanner's coordinate system.
            sinogram: the sinogram from which to reconstruct
            scan_metadata: a list of projection metadata to use for reconstruction

        the sinogram and scan_metadata are generally the output of ScanGeometry.scan

        Returns:
            list[tuple]: associated reconstructed values for the provided points.

            Each returned tuple has the form (x, y, mu) where mu is the calculated attenuation
            value.
        """
        raise NotImplementedError
