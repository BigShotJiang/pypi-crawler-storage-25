import numpy as np
from ctrecon.phantoms import Phantom

from .base import ScanEngine


class NaiveEngine(ScanEngine):
    def configure(self, step_size=0.01, max_dist=109.5):
        self.step_size = step_size
        self.max_dist = max_dist

    def label(self):
        return f"naive-engine-step{self.step_size}"

    def compute_transit(
        self, ph: Phantom, ray_origins: np.ndarray, ray_directions: np.ndarray
    ) -> tuple[np.ndarray, dict]:

        # Log is free to be used however deemed appropriate by the engine
        log = {"incident_photons": np.inf}

        N = len(ray_origins)
        # t_vals = np.linspace(0, max_dist, steps)
        max_dist = self.max_dist
        step_size = self.step_size
        t_vals = np.arange(0.0, max_dist, step_size)
        steps = t_vals.size

        # 2. Compute ALL (x, y) coordinates for ALL rays at ALL steps
        # Using broadcasting to get shape (N, steps)
        X = ray_origins[:, 0:1] + ray_directions[:, 0:1] * t_vals
        Y = ray_origins[:, 1:2] + ray_directions[:, 1:2] * t_vals

        attenuation_profile = np.zeros((N, steps))

        for obj in reversed(ph.objects):
            if obj.type == "Circle":
                # Mathematical mask: (X - cx)^2 + (Y - cy)^2 <= r^2
                mask = (X - obj.cx) ** 2 + (Y - obj.cy) ** 2 <= obj.r**2
            elif obj.type == "Rectangle":
                # Translate to local space
                loc_X = X - obj.cx
                loc_Y = Y - obj.cy

                # Rotate points to AABB space
                cos_t, sin_t = np.cos(-obj.angle), np.sin(-obj.angle)
                rot_X = loc_X * cos_t - loc_Y * sin_t
                rot_Y = loc_X * sin_t + loc_Y * cos_t

                # Mask: |x| <= w/2 AND |y| <= h/2
                mask = (np.abs(rot_X) <= obj.w / 2) & (np.abs(rot_Y) <= obj.h / 2)
            else:
                raise RuntimeError(f"unrecognized object type {obj.type}")

            attenuation_profile[mask] = obj.attenuation

        # flat_projection = np.zeros((n_rays,))
        flat_projection = self.step_size * np.sum(attenuation_profile, axis=1)
        return flat_projection, log
