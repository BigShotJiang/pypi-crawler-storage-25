# notification_onebot

AUTO-MAS 通知插件 - OneBot 11 HTTP API 通道

## 功能

通过 OneBot 11 标准 HTTP API 发送通知消息，支持：

- 私聊消息（`send_private_msg`）
- 群消息（`send_group_msg`）
- 多目标同时推送
- Access Token 鉴权
- `text` / `json` 两种消息载荷格式

## 配置说明

| 字段 | 类型 | 说明 |
|------|------|------|
| `enabled` | bool | 是否启用 |
| `api_url` | string | OneBot HTTP API 地址，如 `http://127.0.0.1:5700` |
| `access_token` | string | Access Token（可留空） |
| `targets` | list | 通知目标列表 |

### 目标配置

| 字段 | 类型 | 说明 |
|------|------|------|
| `name` | string | 目标名称 |
| `enabled` | bool | 是否启用 |
| `target_type` | `private` / `group` | 私聊或群聊 |
| `target_id` | int | QQ 号或群号 |
| `message_format` | `text` / `json` | 消息格式。`text` 发送字符串消息；`json` 发送 OneBot 消息段数组 |

> `message_format` 的 schema 枚举是 `text` 和 `json`。如果你希望发送 CQ 码，应该使用 `text`，并由目标 OneBot 实现按字符串消息解析。

## 兼容的 OneBot 实现

- go-cqhttp
- OpenShamrock
- Lagrange
- LLOneBot
- NapCat
- 其他兼容 OneBot 11 标准的实现

## 依赖

- `notification` 主插件（提供 `notify` 服务）
- `httpx`
