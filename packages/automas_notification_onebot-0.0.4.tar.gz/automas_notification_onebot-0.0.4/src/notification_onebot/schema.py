﻿from typing import Literal

from app.plugins.fields import PluginField
from pydantic import BaseModel, ConfigDict


class Config(BaseModel):
    model_config = ConfigDict(extra="allow")

    enabled: bool = PluginField(default=True, description="启用 OneBot 通知")
    api_url: str = PluginField(
        default="http://127.0.0.1:5700",
        description="OneBot HTTP API 地址",
    )
    access_token: str = PluginField(
        default="",
        description="Access Token（可留空）",
        format="password",
    )
    target_type: Literal["private", "group"] = PluginField(
        default="private",
        description="目标类型（private=私聊，group=群聊）",
    )
    target_id: int = PluginField(default=0, description="QQ 号或群号")
    message_format: Literal["text", "json"] = PluginField(
        default="text",
        description="消息格式（text=字符串，json=OneBot 消息段数组）",
    )
