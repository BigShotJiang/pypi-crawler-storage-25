from __future__ import annotations

from typing import Any, TYPE_CHECKING

import httpx

from app.core import Config as AppConfig

if TYPE_CHECKING:
    from app.plugins import PluginContext

from .schema import Config


class OneBotChannel:
    def __init__(self, ctx: "PluginContext", config: Config) -> None:
        self.ctx = ctx
        self.config = config

    async def send(self, payload: dict[str, Any]) -> bool:
        if not self.config.enabled:
            return False

        if not self.config.target_id:
            self.ctx.logger.warning("未配置目标 ID")
            return False

        message = self._format_message(payload)

        # 直接指定目标（来自 send_onebot 便利方法）
        direct_type = str(payload.get("target_type") or "").strip()
        direct_id = payload.get("target_id")
        if direct_type and direct_id:
            return await self._send(message, direct_type, int(direct_id))

        return await self._send(
            message, self.config.target_type, self.config.target_id
        )

    def _format_message(self, payload: dict[str, Any]) -> str:
        title = str(payload.get("title") or "AUTO-MAS 通知")
        text = str(payload.get("text") or "")
        signature = str(payload.get("signature") or "").strip()
        parts = [f"[{title}]", text]
        if signature:
            parts.append(f"\n{signature}")
        return "\n".join(parts)

    async def _send(self, message: str, target_type: str, target_id: int) -> bool:
        if target_type == "private":
            endpoint = "/send_private_msg"
            body: dict[str, Any] = {"user_id": target_id}
        else:
            endpoint = "/send_group_msg"
            body = {"group_id": target_id}

        if self.config.message_format == "json":
            body["message"] = [{"type": "text", "data": {"text": message}}]
        else:
            body["message"] = message

        url = self.config.api_url.rstrip("/") + endpoint
        headers: dict[str, str] = {"Content-Type": "application/json"}
        if self.config.access_token:
            headers["Authorization"] = f"Bearer {self.config.access_token}"

        async with httpx.AsyncClient(proxy=AppConfig.proxy, timeout=10) as client:
            response = await client.post(url, json=body, headers=headers)

        data = response.json()
        if data.get("retcode") == 0:
            self.ctx.logger.info(
                f"消息发送成功: "
                f"{target_type}={target_id}"
            )
            return True

        raise RuntimeError(
            f"OneBot API 错误: retcode={data.get('retcode')}, "
            f"msg={data.get('msg')}, wording={data.get('wording')}"
        )


class Plugin:
    needs = "notify"

    def __init__(self, ctx: "PluginContext") -> None:
        self.ctx = ctx

    async def on_start(self) -> None:
        raw_config = self.ctx.config.to_dict() if hasattr(self.ctx.config, "to_dict") else dict(self.ctx.config)
        channel = OneBotChannel(self.ctx, Config.model_validate(raw_config))
        self.ctx.get("notify").register_channel("onebot", channel)
        self.ctx.logger.info("通道已启动")

    async def on_stop(self, reason: str) -> None:
        notify = self.ctx.get("notify")
        if notify is not None:
            notify.unregister_channel("onebot")
        self.ctx.logger.info(f"插件停止, reason={reason}")
