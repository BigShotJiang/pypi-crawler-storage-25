# Antigravity MCP Client Spec

- **Config path:** `~/.gemini/antigravity/mcp_config.json` (all platforms)
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** none (global only)
- **Transport:** stdio, SSE, Streamable HTTP
- **Last verified:** 2026-05-02

## Editor docs

- **MCP:** https://antigravity.google/docs/mcp

## Notes

- Shares the `~/.gemini/` base directory with the Gemini CLI but uses a separate config file.
- Remote entries use `serverUrl` (not `url`).
- Antigravity is a VS Code fork but does NOT honor VS Code-style user `mcp.json`.
- Extension scanning deferred: extensions contribute MCP via runtime API only (not statically detectable).
