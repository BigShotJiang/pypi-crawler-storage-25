# GitHub Copilot CLI MCP Client Spec

- **Config path:** `$COPILOT_HOME/mcp-config.json` or `~/.copilot/mcp-config.json`
- **Format:** JSON
- **Servers key (global):** `mcpServers`
- **Project config (primary):** `.mcp.json` (servers key: `mcpServers`)
- **Project config (additional):** `.github/mcp.json` (`mcpServers`), `.vscode/mcp.json` (`servers`, legacy)
- **Transport:** stdio, SSE, Streamable HTTP
- **Skills:** `~/.copilot/skills/<name>/SKILL.md` (global), `.github/skills/` (project)
- **Plugins:** `~/.copilot/installed-plugins/<marketplace>/<plugin>/` and `_direct/<source-id>/`
- **Last verified:** 2026-05-02

## Editor docs

- **MCP:** https://docs.github.com/en/copilot/how-tos/copilot-cli/customize-copilot/add-mcp-servers
- **Config dir:** https://docs.github.com/copilot/reference/copilot-cli-reference/cli-config-dir-reference
- **Plugins:** https://docs.github.com/copilot/reference/copilot-cli-reference/cli-plugin-reference

## Notes

- `$COPILOT_HOME` overrides `~/.copilot` (XDG_CONFIG_HOME does NOT apply).
- `.vscode/mcp.json` is legacy; migration docs show `jq '{mcpServers: .servers}'` conversion.
- Plugin MCP found via `.mcp.json` at plugin root, `.github/mcp.json`, or inline `mcpServers` in manifest.
- Plugin manifest locations: `.plugin/plugin.json`, `plugin.json`, `.github/plugin/plugin.json`, `.claude-plugin/plugin.json`.
