# Cline (VS Code Extension) MCP Client Spec

- **Config path (macOS):** `~/Library/Application Support/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json`
- **Config path (Windows):** `%APPDATA%/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json`
- **Config path (Linux):** `~/.config/Code/User/globalStorage/saoudrizwan.claude-dev/settings/cline_mcp_settings.json`
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** none (global only)
- **Skills:** `~/.cline/skills/<name>/SKILL.md` (global), `.cline/skills/` / `.clinerules/skills/` / `.claude/skills/` (project)
- **Transport:** stdio, SSE, Streamable HTTP
- **Last verified:** 2026-05-02

## Editor docs

- **MCP:** https://docs.cline.bot/mcp/configuring-mcp-servers
- **Skills:** https://docs.cline.bot/customization/skills
- **Extension ID:** `saoudrizwan.claude-dev`
- **Linux path:** https://raw.githubusercontent.com/cline/linear-mcp/main/README.md §"4. Cline Integration"
