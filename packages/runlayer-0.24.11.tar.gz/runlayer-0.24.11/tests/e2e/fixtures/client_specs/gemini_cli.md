# Gemini CLI MCP Client Spec

- **Config path:** `~/.gemini/settings.json` (all platforms)
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** `.gemini/settings.json` (servers key: `mcpServers`)
- **Extensions (global):** `~/.gemini/extensions/<name>/gemini-extension.json` (top-level `mcpServers`)
- **Extensions (project):** `<workspace>/.gemini/extensions/<name>/gemini-extension.json`
- **Transport:** stdio, SSE, Streamable HTTP
- **Last verified:** 2026-05-02

## Editor docs

- **MCP:** https://github.com/google-gemini/gemini-cli/blob/main/docs/cli/configuration.md#mcp-servers
- **Extensions:** https://raw.githubusercontent.com/google-gemini/gemini-cli/main/docs/extensions/reference.md

## Notes

- State file `extension-enablement.json` lives alongside extension dirs; scanner must `is_dir()` filter.
- Project-level extensions loaded from `<workspace>/.gemini/extensions/`; workspace wins conflicts with user-level.
- `gemini extensions install` only writes to `~/.gemini/extensions/`; project-level requires manual `git clone`.
