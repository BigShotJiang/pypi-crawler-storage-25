# Cline CLI MCP Client Spec

- **Config path:** `$CLINE_DIR/data/settings/cline_mcp_settings.json` (defaults to `~/.cline/data/settings/cline_mcp_settings.json`)
- **Format:** JSON
- **Servers key:** `mcpServers`
- **Project config:** none (global only)
- **Skills:** `~/.cline/skills/<name>/SKILL.md` (shared with Cline VS Code)
- **Transport:** stdio, SSE, Streamable HTTP
- **Last verified:** 2026-05-02

## Editor docs

- **MCP:** https://docs.cline.bot/mcp/configuring-mcp-servers
- **Configuration:** https://docs.cline.bot/cline-cli/configuration §"Configuration Directory"

## Notes

- `$CLINE_DIR` replaces `~/.cline` (not `~/.cline/data`). Empirically verified 2026-05-01.
