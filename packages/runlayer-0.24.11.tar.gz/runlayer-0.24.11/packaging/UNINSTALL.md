# AI Watch — Uninstall Guide

Covers teardown for both the **script-based** deployment (`scripts/mdm/run-ai-watch-*`) and the **package-based** deployment (`.pkg`/`.msi` from `cli/packaging/`). For deployment details see [`DEPLOYMENT.md`](DEPLOYMENT.md) and [`scripts/mdm/README.md`](../../scripts/mdm/README.md).

## Which deployment do I have?

Run the checks below on a target device to determine which variant is installed.

### macOS

| Check | Script deployment | Package deployment |
| ----- | ----------------- | ------------------ |
| `test -x /usr/local/bin/runlayer-scan && echo YES` | YES | — |
| `test -f ~/Library/LaunchAgents/com.runlayer.scan.plist && echo YES` | YES | — |
| `test -L /usr/local/bin/aiwatch && echo YES` | — | YES |
| `test -f /Library/LaunchAgents/com.runlayer.aiwatch.plist && echo YES` | — | YES |
| `pkgutil --pkg-info com.runlayer.aiwatch 2>/dev/null && echo YES` | — | YES |

### Windows

| Check (PowerShell) | Script deployment | Package deployment |
| ------------------- | ----------------- | ------------------ |
| `Get-ScheduledTask RunlayerAIWatch -ErrorAction SilentlyContinue` | present | — |
| `Test-Path "$env:ProgramData\Runlayer\Scripts\runlayer-ai-watch.ps1"` | True | — |
| `Test-Path "C:\Program Files\Runlayer\AIWatch\aiwatch.exe"` | — | True |
| `Get-ItemProperty "HKLM:\Software\Runlayer\AIWatch" -ErrorAction SilentlyContinue` | — | present |

Both variants can coexist during a migration window. If both are detected, uninstall the script deployment first (see [Migrating from script to package](#migrating-from-script-to-package)).

---

## Script deployment — macOS

### 1. Remove MDM assignments

Unassign the scan script **and** the PPPC profile (`runlayer-ai-watch-profile.mobileconfig`) from the target device group:

- **Iru / other MDMs**: remove the Custom Script and Custom Profile from the device group.
- **Jamf Pro**: unscope the Policy (script) and the Configuration Profile.
- **SimpleMDM**: unassign the Script and the Custom Configuration Profile.
- **Mosyle / other**: unassign the equivalent script + profile items.

The PPPC profile is auto-removed from devices once unassigned.

### 2. Run cleanup script

Push a **Run Once** script via MDM (or run manually as root) to remove on-disk artifacts:

```bash
#!/bin/bash
set -euo pipefail

CONSOLE_USER=$(stat -f '%Su' /dev/console 2>/dev/null)
CONSOLE_UID=$(id -u "$CONSOLE_USER" 2>/dev/null || echo "")
USER_HOME=$(dscl . -read "/Users/$CONSOLE_USER" NFSHomeDirectory 2>/dev/null | awk '{print $2}')

# Unload LaunchAgent
if [ -n "$CONSOLE_UID" ] && [ "$CONSOLE_UID" != "0" ]; then
    launchctl bootout "gui/${CONSOLE_UID}/com.runlayer.scan" 2>/dev/null || true
fi

# Remove wrapper binary, LaunchAgent plist, logs
rm -f /usr/local/bin/runlayer-scan
rm -f "$USER_HOME/Library/LaunchAgents/com.runlayer.scan.plist"
rm -f /tmp/runlayer-scan.stdout.log /tmp/runlayer-scan.stderr.log
rm -rf /var/log/runlayer

# Remove stored org key
sudo -u "$CONSOLE_USER" "$USER_HOME/.local/bin/uvx" runlayer credentials remove org ai_watch_mdm 2>/dev/null || true
```

### What is intentionally left behind

- **`uv`** (`/usr/local/bin/uv`) and the `runlayer` tool install — shared developer tooling that may be in use independently.
- **`~/.runlayer/config.yaml`** — only the `org_api_keys.ai_watch_mdm` entry is removed; the file is kept if other entries exist.

---

## Script deployment — Windows

### 1. Remove MDM assignments

- **Intune**: Devices → Scripts — unassign `run-ai-watch-windows.ps1` from the device group.

### 2. Run cleanup script

Push a cleanup script via Intune Remediations or Proactive Remediations (run as **logged-on user**):

```powershell
# Remove scheduled task
Unregister-ScheduledTask -TaskName "RunlayerAIWatch" -Confirm:$false -ErrorAction SilentlyContinue

# Remove recurring script + logs
Remove-Item -Recurse -Force "$env:ProgramData\Runlayer" -ErrorAction SilentlyContinue

# Remove stored org key
& "$env:USERPROFILE\.local\bin\uvx.exe" runlayer credentials remove org ai_watch_mdm 2>$null
```

### What is intentionally left behind

- **`uv.exe`** and the `runlayer` tool install — shared user tooling.
- **`~/.runlayer/config.yaml`** — only the `ai_watch_mdm` org key entry is removed.

---

## Package deployment — macOS

### 1. Remove MDM assignments

Unscope the Blueprint (or equivalent device group) to remove all four MDM items:

| MDM | Action |
| --- | ------ |
| Iru / other | Remove the Custom App + 3 Custom Profiles from the device group. |
| Jamf Pro | Unscope the Policy (`.pkg`) and 3 Configuration Profiles from the Smart Group. |
| Workspace ONE | Unassign the Application + 3 Profiles from the Organization Group. |
| Mosyle / Jamf Now / Intune macOS | Unassign the Custom App and each uploaded Custom Profile. |

Removing the profiles auto-deletes the managed preferences (`/Library/Managed Preferences/com.runlayer.aiwatch.plist`), PPPC grants, and Login Items approval from the device.

### 2. Run cleanup script

Push a **Run Once** script via MDM (or run manually as root):

```bash
#!/bin/bash
set -euo pipefail

CONSOLE_UID=$(stat -f %u /dev/console 2>/dev/null || echo "")

# Unload LaunchAgent
if [ -n "$CONSOLE_UID" ] && [ "$CONSOLE_UID" != "0" ]; then
    launchctl bootout "gui/${CONSOLE_UID}/com.runlayer.aiwatch" 2>/dev/null || true
fi

# Remove binary, onedir bundle, LaunchAgent plist, logs
rm -f /usr/local/bin/aiwatch
rm -rf /usr/local/lib/runlayer/aiwatch
rm -f /Library/LaunchAgents/com.runlayer.aiwatch.plist
rm -f /tmp/aiwatch.out /tmp/aiwatch.err

# Forget installer receipt
pkgutil --forget com.runlayer.aiwatch 2>/dev/null || true

# Clear any cached TCC decisions
tccutil reset All com.runlayer.aiwatch 2>/dev/null || true
```

---

## Package deployment — Windows

### 1. Remove MDM assignments

In Intune, unscope **both**:

- The **Win32 app** (`aiwatch-<ver>-win-x64.intunewin`).
- The **Remediation** script package.

On next device check-in Intune issues `msiexec /x`, which removes `C:\Program Files\Runlayer\AIWatch\` and the `HKLM\Software\Runlayer\AIWatch` registry key.

### 2. Optional per-user cleanup

If using Option B (`scheduled/` remediation), a per-user compliance marker file is written. Remove it if desired (run as logged-on user):

```powershell
Remove-Item -Force "$env:LOCALAPPDATA\Runlayer\last_scan" -ErrorAction SilentlyContinue
```

### 3. Manual fallback

If the Intune-managed uninstall does not fire (e.g. device retired before sync), run manually as admin:

```powershell
Get-Package -Name "Runlayer AI Watch" -ErrorAction SilentlyContinue |
    Uninstall-Package -Force

# Or by product code:
# msiexec /x "{PRODUCT-CODE}" /qn
```

---

## Verify uninstall

### macOS

```bash
# Package deployment artifacts
pkgutil --pkg-info com.runlayer.aiwatch 2>&1 | grep -q "No receipt" && echo "pkg receipt gone"
launchctl print "gui/$(id -u)/com.runlayer.aiwatch" 2>&1 | grep -q "Could not find" && echo "agent gone"
test ! -e /usr/local/bin/aiwatch && echo "binary gone"

# Script deployment artifacts
launchctl print "gui/$(id -u)/com.runlayer.scan" 2>&1 | grep -q "Could not find" && echo "wrapper agent gone"
test ! -e /usr/local/bin/runlayer-scan && echo "wrapper binary gone"

# MDM profiles removed?
profiles show -type configuration 2>/dev/null | grep -qi runlayer && echo "WARN: profile still present" || echo "profiles clean"
```

### Windows

```powershell
# Package deployment artifacts
if (-not (Test-Path "C:\Program Files\Runlayer\AIWatch\aiwatch.exe")) { "binary gone" }
try { Get-ItemProperty "HKLM:\Software\Runlayer\AIWatch" -ErrorAction Stop; "WARN: registry still present" } catch { "registry gone" }

# Script deployment artifacts
try { Get-ScheduledTask "RunlayerAIWatch" -ErrorAction Stop; "WARN: task still present" } catch { "scheduled task gone" }
if (-not (Test-Path "$env:ProgramData\Runlayer\Scripts\runlayer-ai-watch.ps1")) { "recurring script gone" }
```

---

## Migrating from script to package

Run the script-deployment uninstall (macOS or Windows sections above) **first**, then deploy the package variant per [`DEPLOYMENT.md`](DEPLOYMENT.md). The two deployments use different identifiers (`com.runlayer.scan` / `ai_watch_mdm` config key vs. `com.runlayer.aiwatch` / MDM-managed preferences + registry), so no credential or config carry-over is needed.
