# AI Watch Packaging

Scan-only binary for MDM deployment (macOS, Windows/Intune). Ships `aiwatch` — a stripped-down `runlayer` exposing only `scan`, `login`, `logout`, `logs`, and `org-api-key`.

> **Deploying to a fleet?** See [`DEPLOYMENT.md`](DEPLOYMENT.md) for the admin-side step-by-step (macOS MDM, Intune, Jamf, troubleshooting, upgrade/uninstall).

## Bundle layout

PyInstaller `--onedir`: the built artifact is a directory (`dist/aiwatch/`) containing the exe + ~120 bundled `.dylib`/`.so`/`.pyd` files. Installers copy the whole tree to disk once; every scan is an exec of an already-installed signed binary. We deliberately **do not** use `--onefile` — self-extracting binaries write executables to temp on every run, which CrowdStrike / SentinelOne / Defender ATP behavioral rules flag as dropper-shaped. See header comment in `aiwatch.spec` for the full rationale. UPX is also disabled for the same EDR-signal reason and because it complicates macOS codesigning.

Installed layout:

| Platform | Path |
|----------|------|
| macOS    | `/usr/local/lib/runlayer/aiwatch/` (bundle) + symlink `/usr/local/bin/aiwatch` |
| Windows  | `C:\Program Files\Runlayer\AIWatch\` (bundle, `aiwatch.exe` at the root) |

One build artifact per platform works for every tenant. Tenant-specific settings (host, org API key value, scan schedule) are supplied at deploy time through OS-native surfaces. The MDM-pushed org API key is the **actual `rl_org_...` secret**, not a name to look up — `aiwatch` uses it directly as `RUNLAYER_API_KEY`.

- **macOS**: Configuration Profile (host / org API key) + PPPC Profile (Full Disk Access) + Login Items Profile (Ventura+ background-item pre-approval). The LaunchAgent (schedule) ships inside the `.pkg` itself — macOS configuration profiles have no LaunchAgent payload type and most MDMs lack a standalone Launch Agent library item, so bundling is the portable pattern.
- **Windows**: Registry via MSI properties (host / org API key) + Intune Remediations schedule (schedule) — schedule editable in the Intune UI.

Host and org API key are resolved at runtime by `aiwatch` — no subprocess, no extra runtime deps, stdlib only (`plistlib`, `winreg`).

Resolution order inside `aiwatch`:

1. `--host` / `--secret` CLI flags
2. `RUNLAYER_HOST` / `RUNLAYER_API_KEY` env vars
3. OS-native managed config (see below)

## Building

### macOS (.pkg)

```bash
cd cli
make package-aiwatch-macos                        # host arch
AIWATCH_PKG_ARCH=arm64 make package-aiwatch-macos # override arch label
```

Output: `dist/aiwatch-<ver>-macos-<arch>.pkg` where `<arch>` is `arm64` or `x86_64`. Tenant-agnostic.

CI (`release-aiwatch.yml`) builds both natively in a matrix (`macos-14` for arm64, `macos-13` for x86_64) and ships both. We avoid PyInstaller `--target-arch universal2` because it requires every Python C-extension to be fat — `setup-python` doesn't guarantee that, and a half-fat build silently produced single-arch binaries that prompted Apple Silicon users to install Rosetta. The `.pkg`'s `hostArchitectures` makes macOS Installer cleanly refuse the wrong arch instead.

### Windows (x64 .msi + .intunewin)

```powershell
cd cli
make package-aiwatch-windows
```

Output: `dist/aiwatch-<ver>-win-x64.msi`, `dist/aiwatch-<ver>-win-x64.intunewin`. Tenant-agnostic.

### Windows alternative (py2exe)

```powershell
cd cli
make package-aiwatch-py2exe
```

Note: the checked-in py2exe setup is onefile-shaped (`bundle_files=1`) and has the same EDR/AV drawbacks as `--onefile`. Kept as an escape hatch for corp environments that block PyInstaller but not py2exe; prefer PyInstaller onedir where possible.

### CI

`release-aiwatch.yml` builds both platforms on `workflow_dispatch` or `cli-*` tag push. Artifacts are bundled into deployment `.zip` files and attached to a GitHub Release on tag.

## Deploying

### macOS

The `.pkg` is self-contained: bundle at `/usr/local/lib/runlayer/aiwatch/`, symlink at `/usr/local/bin/aiwatch`, and the LaunchAgent at `/Library/LaunchAgents/com.runlayer.aiwatch.plist`. The postinstall script bootstraps the agent for the console user so scans start running immediately at the bundled default `StartInterval` (15 min). The LaunchAgent is bundled (not pushed via MDM) because configuration profiles have no LaunchAgent payload type and most MDMs lack a standalone Launch Agent library item.

Extract the macOS `.zip` from the GitHub Release (`aiwatch-<ver>-macos-arm64.zip`). It contains the `.pkg` and all `.mobileconfig` / `.json` files referenced below.

1. Upload the `.pkg` as a **Custom App** (or equivalent). Target: all AI Watch devices.
2. Push tenant host / org API key via a **Custom Profile**: edit `com.runlayer.aiwatch.config.mobileconfig`, replacing `REPLACE_WITH_TENANT_HOST` (e.g. `https://tenant.runlayer.com`) and `REPLACE_WITH_ORG_API_KEY` (the actual `rl_org_...` secret minted in Runlayer), then upload the file as-is. Targets preference domain `com.runlayer.aiwatch`; `aiwatch` reads it from `/Library/Managed Preferences/com.runlayer.aiwatch.plist` at scan time. Updating either value is a profile re-push — no reinstall.
3. Push **Full Disk Access** via a **PPPC Profile** — upload `com.runlayer.aiwatch.pppc.mobileconfig` as-is. Grants FDA + granular folder access to `/usr/local/lib/runlayer/aiwatch/aiwatch` with CodeRequirement `identifier "com.runlayer.aiwatch"`. Without this, the background LaunchAgent silently skips `~/Desktop`, `~/Documents`, `~/Downloads`, and parts of `~/Library/Application Support` since TCC can't prompt from a background agent. Requires the binary to be Developer ID signed and the device UAMDM-enrolled. Permission surface mirrors the existing `scripts/mdm/runlayer-ai-watch-profile.mobileconfig` (uvx-wrapper) profile — same reviewer-approved scope.
4. Push **Managed Login Items** via a **Custom Profile** — edit `com.runlayer.aiwatch.loginitems.mobileconfig`, replace `REPLACE_WITH_TEAM_ID` with the Developer ID team identifier the binary is signed with (same value for every tenant), and upload. Pre-approves the bundled LaunchAgent on macOS 13+ so users don't see "Background Item Added" notifications and can't disable the agent from System Settings. macOS < 13 ignores the payload silently.
5. (Optional) Override the default `StartInterval` via an MDM **Custom Script** — see `DEPLOYMENT.md` §5 for the script template. Only needed if 15 min is wrong for your fleet; the override has to be re-applied after each `.pkg` upgrade.

### Intune (Windows)

Extract the Intune `.zip` from the GitHub Release (`aiwatch-<ver>-intune-package.zip`). It contains the `.intunewin` and two remediation script sets under `scan-on-detect/` and `scheduled/` subfolders.

**Step 1 — Install the binary with tenant config:**

1. Upload the `.intunewin` as a **Win32 app**.
2. Install command (`AIWATCH_ORG_API_KEY` is the actual `rl_org_...` secret):

   ```
   msiexec /i aiwatch-<ver>-win-x64.msi /qn AIWATCH_HOST=https://tenant.runlayer.com AIWATCH_ORG_API_KEY=rl_org_xxxxxxxxxxxxxxxxxxxxxxxxxxxx
   ```

3. Uninstall command: `msiexec /x aiwatch-<ver>-win-x64.msi /qn`
4. Detection rule: file version `C:\Program Files\Runlayer\AIWatch\aiwatch.exe` >= `<version>` (enables Supersedence upgrades).
5. Deploy in **System context** (per-machine install).

The MSI writes the two properties to `HKLM\Software\Runlayer\AIWatch` (values `Host`, `OrgApiKey`). `aiwatch.exe` reads them via `winreg` at scan time and feeds `OrgApiKey` directly into `RUNLAYER_API_KEY`.

**Step 2 — Schedule scan execution:**

The `.zip` ships two remediation strategies:

- **`scan-on-detect/`** — detection script runs the scan directly (simpler, one script).
- **`scheduled/`** — detection checks staleness, remediation runs the scan (follows Microsoft's intended pattern, 3-state dashboard).

1. In Intune > Devices > Remediations, create a new script package.
2. Upload scripts from your chosen subfolder — no templating needed.
3. **Critical**: set **"Run this script using the logged-on credentials"** to **Yes** so scan runs as the signed-in user and sees per-user MCP client configs.
4. Set schedule frequency as desired (minimum hourly in Intune).

See the [Intune Deployment Package docs](https://docs.runlayer.com/shadow-ai/detect/intune-deployment-package) for full pro/con and step-by-step for each option.

## Execution context

| Platform | Install runs as | Scan runs as | Schedule owner | Host / org key source |
|----------|----------------|--------------|----------------|-----------------------|
| macOS    | root (pkg)     | logged-in user (LaunchAgent bundled in pkg) | `StartInterval` in `/Library/LaunchAgents/com.runlayer.aiwatch.plist` (default 900 s; override via MDM Custom Script) | `/Library/Managed Preferences/com.runlayer.aiwatch.plist` (MDM Configuration Profile) |
| Windows  | SYSTEM (msi)   | logged-in user (Intune Remediation)     | Intune Remediations UI (min 1 hr)          | `HKLM\Software\Runlayer\AIWatch` (written by MSI properties) |

## Signing

### macOS (implemented in `build_pkg.sh`)

`build_pkg.sh` signs every inner Mach-O with Developer ID Application + hardened runtime, then signs the outer `.pkg` with Developer ID Installer, then optionally notarizes + staples. Signing + notarization are **required** for the PPPC profile to work: the profile's `CodeRequirement = identifier "com.runlayer.aiwatch"` only matches a properly signed binary, not PyInstaller's ad-hoc identity.

Set these env vars (both required for signing; both required for notarization on top):

| Env var | Value |
|---|---|
| `AIWATCH_SIGN_IDENTITY_APP` | `Developer ID Application: Company Name (TEAMID)` |
| `AIWATCH_SIGN_IDENTITY_PKG` | `Developer ID Installer: Company Name (TEAMID)` |
| `AIWATCH_NOTARIZE_PROFILE` *(preferred)* | Keychain profile saved via `xcrun notarytool store-credentials` |
| `AIWATCH_NOTARIZE_APPLE_ID` *(alt.)* | Apple ID email |
| `AIWATCH_NOTARIZE_TEAM_ID` *(alt.)* | 10-char Developer Team ID |
| `AIWATCH_NOTARIZE_PASSWORD` *(alt.)* | App-specific password from appleid.apple.com |

When the `_APP` / `_PKG` vars are unset, `build_pkg.sh` falls back to ad-hoc signing for fast local iteration — the resulting `.pkg` works for smoke-testing but will not get TCC grants via PPPC.

One-time local setup:

```bash
xcrun notarytool store-credentials aiwatch-notary \
    --apple-id you@example.com \
    --team-id ABCDE12345 \
    --password <app-specific-password>
export AIWATCH_SIGN_IDENTITY_APP="Developer ID Application: Runlayer Inc. (ABCDE12345)"
export AIWATCH_SIGN_IDENTITY_PKG="Developer ID Installer: Runlayer Inc. (ABCDE12345)"
export AIWATCH_NOTARIZE_PROFILE=aiwatch-notary
make package-aiwatch-macos
```

Hardened-runtime entitlements live in `packaging/macos/entitlements.plist` (`allow-dyld-environment-variables` for PyInstaller's bootloader, `disable-library-validation` because PyInstaller ships CPython + many C extensions with heterogenous signatures).

### CI secrets

`.github/workflows/release-aiwatch.yml` picks up these GitHub Actions secrets automatically. When present, the workflow imports the cert into a temp keychain and passes the env vars to `build_pkg.sh`. When absent, the workflow produces an ad-hoc `.pkg` as today — the test matrix still runs.

| Secret | Value |
|---|---|
| `MACOS_SIGNING_CERT_P12` | Base64-encoded `.p12` bundling the Developer ID Application + Installer certs + private keys |
| `MACOS_SIGNING_CERT_PASSWORD` | Password for the `.p12` |
| `MACOS_SIGN_IDENTITY_APP` | `Developer ID Application: Company Name (TEAMID)` |
| `MACOS_SIGN_IDENTITY_PKG` | `Developer ID Installer: Company Name (TEAMID)` |
| `MACOS_NOTARIZE_APPLE_ID` | Apple ID email |
| `MACOS_NOTARIZE_TEAM_ID` | 10-char Developer Team ID |
| `MACOS_NOTARIZE_PASSWORD` | App-specific password |

Export the `.p12`:

```bash
# After importing both certs + keys into Keychain Access, from the account
# that holds the Developer ID identities:
security find-identity -v -p codesigning
# Note the TEAMID shown in parens.
# Export both certs (hold Cmd, select both) → right-click → Export → .p12.
# Then:
base64 < aiwatch-signing.p12 | pbcopy
# Paste as MACOS_SIGNING_CERT_P12 in GitHub → repo Settings → Secrets.
```

### Windows (Azure Artifact Signing)

CI signs every `.exe`, `.dll`, and `.pyd` in the PyInstaller onedir bundle before WiX packages them into the MSI, then signs the MSI itself. Signing uses [Azure Artifact Signing](https://learn.microsoft.com/en-us/azure/artifact-signing/) via `azure/artifact-signing-action@v1` with OIDC federated identity — no certificate or secret on disk. When `AZURE_CLIENT_ID` is absent (fork PRs, unconfigured repos), the workflow degrades to unsigned artifacts.

#### CI secrets

| Secret | Value |
|---|---|
| `AZURE_TENANT_ID` | Microsoft Entra (Azure AD) tenant ID |
| `AZURE_CLIENT_ID` | App Registration client ID (with federated credential for the repo) |
| `AZURE_SUBSCRIPTION_ID` | Azure subscription containing the Artifact Signing account |
| `AZURE_TRUSTED_SIGNING_ENDPOINT` | Regional endpoint, e.g. `https://eus.codesigning.azure.net` |
| `AZURE_TRUSTED_SIGNING_ACCOUNT` | Artifact Signing account name |
| `AZURE_TRUSTED_SIGNING_PROFILE` | Certificate profile name |

#### One-time Azure setup

1. Create an App Registration in Microsoft Entra.
2. Add a **federated credential** for GitHub Actions (`repo:runlayer/Runlayer:ref:refs/heads/main` + `repo:runlayer/Runlayer:ref:refs/tags/cli-*`).
3. On the Artifact Signing certificate profile, assign the App Registration the **Artifact Signing Certificate Profile Signer** role.
4. Store the six values above as GitHub Actions secrets.

#### Local dev

Windows builds are unsigned locally — `build_msi.ps1` and `build_intunewin.ps1` don't invoke signtool. Signing only happens in CI when the secrets are configured.

## File layout

```
packaging/
  aiwatch.spec                    PyInstaller onedir spec
  py2exe/setup_py2exe.py          Windows py2exe alternative (onefile-shaped; fallback only)
  macos/
    build_pkg.sh                                  Builds .pkg from dist/aiwatch/ (onedir tree)
    com.runlayer.aiwatch.plist                    LaunchAgent (bundled in .pkg at /Library/LaunchAgents/)
    com.runlayer.aiwatch.config.mobileconfig      Tenant-config profile template (edit Host / OrgApiKey, deploy via MDM)
    com.runlayer.aiwatch.pppc.mobileconfig        PPPC/FDA profile template (deploy via MDM as-is)
    com.runlayer.aiwatch.loginitems.mobileconfig  Managed Login Items profile (edit team ID, deploy via MDM)
    distribution.xml                              productbuild layout
    scripts/postinstall                           chmod binary + bootstrap LaunchAgent for console user
  windows/
    aiwatch.wxs                   WiX source for .msi (harvests dist\aiwatch\, writes HKLM from properties)
    build_msi.ps1                 Builds .msi via WiX
    build_intunewin.ps1           Wraps .msi into .intunewin
    remediation/
      scan-on-detect/
        detect.ps1                Option A: runs scan in detection phase
      scheduled/
        detect.ps1                Option B: checks last-scan freshness
        remediate.ps1             Option B: runs scan when stale
```
