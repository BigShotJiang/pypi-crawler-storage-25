# CLI Service - Agent Context

> **Service**: cli
> **Type**: Python command-line application
> **Role**: Runlayer CLI for MCP server execution

## Quick Context

This is a **Python CLI tool** that end-users install and run to connect to MCP servers through the Runlayer backend.

## When Working Here

You are in a **Python CLI** environment:

- **ALWAYS use `uv`** - Never use `python`, `python3`, or `pip` directly
- Package manager: `uv`
- Distribution: PyPI package installed via `uvx`
- Users run: `uvx runlayer <uuid> --secret <key> --host <url>`

## Critical Commands

```bash
# Run locally
uv run runlayer <uuid> --secret <key> --host <url>

# Tests
make test

# Build
make build
```

## Key Characteristics

- **User-facing**: End-users install and run this tool
- **Authentication**: Handles API key authentication with backend
- **Proxy**: Proxies MCP protocol traffic securely
- **Cross-platform**: Must work on macOS, Linux, Windows

## Entrypoints

| Entrypoint | Module | Scope |
|------------|--------|-------|
| `runlayer` | `runlayer_cli.main:cli` | Full CLI (all subcommands) |
| `aiwatch` | `runlayer_cli.aiwatch:main` | Scan-only (scan, login, logout, logs, org-api-key) |

`aiwatch` is a stripped-down entrypoint for MDM deployment (Iru, Intune, and other MDMs) that excludes `fastmcp`, `docker`, `mcp`, `anyio`, `questionary` from its PyInstaller bundle. Anything `aiwatch.py` transitively imports at module load must tolerate those deps being absent.

Rules to keep the bundle valid:

- **`runlayer_cli/commands/__init__.py` must stay empty of re-exports.** Python runs it before loading any submodule (e.g. `commands.scan`), so top-level imports there are paid by `aiwatch` on startup. `main.py` imports command submodules directly.
- **`runlayer_cli/models.py` must not import `mcp`.** mcp-dependent models (`LocalCapabilities`, `PreRequest`, `PostRequest`) live in `runlayer_cli/models_mcp.py`, imported only by `middleware.py` / `sync.py` / the `runlayer run` path.
- **`runlayer_cli/api.py` keeps `mcp`-typed signatures under `TYPE_CHECKING`.** Runtime is duck-typed (`.model_dump()`); `from __future__ import annotations` keeps the type hints resolvable without the import.
- **`runlayer_cli/metrics.py` must stay `anyio`-free** (pure TypedDicts + builders). It's loaded by `api.py`, which is in the `aiwatch` closure. The `anyio`-dependent `flush_installation_events` lives in `runlayer_cli/metrics_flush.py`, imported only by `plugins/installer.py` and `skills/installer.py` (neither is in `aiwatch`).
- **Never add top-level `fastmcp`/`docker`/`mcp`/`anyio`/`questionary` imports** to `scan*`, `auth`, `logs`, `org_api_key`, `api`, `metrics`, `config`, `console`, `credential_store`, `logging`, `symbols`, or any module in their transitive closure.

Regression test: `tests/test_aiwatch_imports.py` spawns a subprocess with those modules blocked and verifies `runlayer_cli.aiwatch` still imports.

## AI Watch Packaging

MDM-ready binaries live in `packaging/`. See `packaging/README.md` for full details.

```bash
# macOS: PyInstaller universal2 onedir bundle + .pkg
make package-aiwatch-macos

# Windows: PyInstaller onedir bundle + .msi + .intunewin
make package-aiwatch-windows

# CI: .github/workflows/release-aiwatch.yml
```

**Do not switch aiwatch.spec to `--onefile` or re-enable UPX.** Onefile self-extracts ~25 MB of dylibs/DLLs to `$TMPDIR` on every invocation, which matches the behavioral fingerprint EDR products (CrowdStrike, SentinelOne, Defender ATP) flag as dropper-shaped. UPX-packed Mach-O/PE is another packer signal. Onedir installs once; every scan is an exec of an already-on-disk signed binary. Rationale is captured in the `aiwatch.spec` docstring.

## Common Tasks

### Testing CLI

```bash
uv run runlayer test_uuid --secret test_key --host http://localhost:8000
```

### Adding New Option

1. Update argument parser
2. Implement functionality
3. Update README
4. Add tests

## Common Pitfalls

1. **Never use `python` directly** - Always `uv run`
2. **Never log secrets** - API keys must not appear in logs
3. **Cross-platform paths** - Use `pathlib.Path`
4. **User-friendly errors** - No raw stack traces for users

## Cross-Service Interactions

- **Backend**: Authenticates with and proxies through backend API
- **MCP Servers**: Connects to servers defined in backend

## Security

- Never log API keys or tokens
- Validate all inputs
- Use HTTPS by default
- Provide clear security guidance in docs

## Documentation

- See `CLAUDE.md` in this directory for detailed guide
- See `README.md` for user documentation
- See root `CLAUDE.md` for monorepo patterns
