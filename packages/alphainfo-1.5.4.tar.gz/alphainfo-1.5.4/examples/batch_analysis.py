#!/usr/bin/env python3
"""
alphainfo — Batch analysis (analyze many signals in one HTTP call)

When you have N independent signals of the same shape, send them all
in a single request via analyze_batch(). One round-trip instead of N,
and the server processes them in parallel.

Limits: up to 100 signals per batch.

    export ALPHAINFO_API_KEY="ai_your_key"
    python examples/batch_analysis.py
"""
import math
import os
import random

from alphainfo import AlphaInfo


def synthetic_signal(freq: float, amplitude: float, n: int = 400) -> list[float]:
    """Sine wave with a pinch of noise."""
    return [amplitude * math.sin(2 * math.pi * freq * i / n)
            + random.gauss(0, 0.05)
            for i in range(n)]


def main() -> None:
    random.seed(42)  # reproducible
    client = AlphaInfo(api_key=os.environ["ALPHAINFO_API_KEY"])

    # 6 synthetic signals — some stable, some with amplitude drift.
    signals = [
        synthetic_signal(freq=1.0, amplitude=1.0),   # stable
        synthetic_signal(freq=1.0, amplitude=1.0),   # stable
        synthetic_signal(freq=1.0, amplitude=2.5),   # amplitude changed
        synthetic_signal(freq=2.0, amplitude=1.0),   # frequency changed
        synthetic_signal(freq=1.0, amplitude=1.0),   # stable
        synthetic_signal(freq=3.0, amplitude=0.5),   # different regime
    ]

    # One baseline (first signal) compared against every other signal.
    # This is a common pattern for "is each one still like the reference?".
    baseline = signals[0]

    batch = client.analyze_batch(
        signals=signals[1:],          # skip the baseline
        baselines=[baseline] * 5,     # compare each against the same reference
        sampling_rate=100.0,
        domain="generic",
    )

    print(f"Analyzed {len(batch.results)} signals in one call")
    print("-" * 50)
    for item in batch.results:
        if item.success:
            mark = "✓" if item.confidence_band == "stable" else "⚠"
            print(f"  {mark} signal[{item.index + 1}] score={item.structural_score:.3f} "
                  f"band={item.confidence_band}")
        else:
            print(f"  ✗ signal[{item.index + 1}] error: {item.error}")

    # Rate limit headers are set by the server on the last response;
    # the SDK surfaces them for quota visibility.
    if client.rate_limit_info:
        info = client.rate_limit_info
        print(f"\nQuota remaining: {info.remaining}/{info.limit}")


if __name__ == "__main__":
    main()
