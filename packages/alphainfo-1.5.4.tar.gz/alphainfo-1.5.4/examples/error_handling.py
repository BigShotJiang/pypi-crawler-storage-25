#!/usr/bin/env python3
"""
alphainfo SDK - Error Handling Example

Demonstrates proper error handling patterns when using the alphainfo SDK.

Usage:
    export ALPHAINFO_API_KEY="ai_your_key_here"
    python examples/error_handling.py
"""

import os
from alphainfo import AlphaInfo
from alphainfo.exceptions import (
    AuthError,
    RateLimitError,
    ValidationError,
    NotFoundError,
    APIError,
    TimeoutError,
    NetworkError,
)


def main():
    """Demonstrate error handling patterns."""

    api_key = os.getenv("ALPHAINFO_API_KEY")
    if not api_key:
        print("Error: ALPHAINFO_API_KEY environment variable not set")
        return

    client = AlphaInfo(api_key=api_key)

    print("=" * 60)
    print("alphainfo SDK - Error Handling Examples")
    print("=" * 60)

    # Example 1: Validation Error
    print("\n1. Handling Validation Errors")
    print("-" * 40)
    try:
        # Empty signal
        client.analyze(signal=[], sampling_rate=250.0)
    except ValidationError as e:
        print(f"Caught ValidationError: {e.message}")
        print(f"Status Code: {e.status_code}")
        print(f"Response: {e.response_data}")

    # Example 2: Invalid sampling rate
    print("\n2. Handling Invalid Sampling Rate")
    print("-" * 40)
    try:
        client.analyze(signal=[1.0, 2.0], sampling_rate=-1)
    except ValidationError as e:
        print(f"Caught ValidationError: {e.message}")

    # Example 3: Authentication Error (with bad key)
    print("\n3. Handling Authentication Errors")
    print("-" * 40)
    bad_client = AlphaInfo(api_key="ai_invalid_key_xyz")
    try:
        result = bad_client.analyze(
            signal=[1.0, 2.0, 3.0, 2.0, 1.0],
            sampling_rate=250.0,
        )
    except AuthError as e:
        print(f"Caught AuthError: {e.message}")
        print(f"Status Code: {e.status_code}")
    except Exception as e:
        print(f"Other error (expected in demo): {type(e).__name__}")

    # Example 4: Rate Limit Error
    print("\n4. Handling Rate Limit Errors")
    print("-" * 40)
    print("(Skipped in demo - would trigger after many requests)")
    print("Pattern:")
    print("""
    try:
        result = client.analyze(signal=[...], sampling_rate=250.0)
    except RateLimitError as e:
        print(f"Rate limited. Retry after {e.retry_after} seconds")
        time.sleep(e.retry_after)
        # Retry the request
    """)

    # Example 5: Network/Timeout Error
    print("\n5. Handling Network/Timeout Errors")
    print("-" * 40)
    slow_client = AlphaInfo(api_key=api_key, timeout=0.001)  # Very short timeout
    try:
        result = slow_client.analyze(
            signal=[1.0, 2.0, 3.0, 2.0, 1.0] * 100,
            sampling_rate=250.0,
        )
    except TimeoutError as e:
        print(f"Caught TimeoutError: {e.message}")
    except Exception as e:
        print(f"Other error (expected in demo): {type(e).__name__}: {str(e)}")

    # Example 6: Generic error handling
    print("\n6. Generic Error Handling")
    print("-" * 40)
    print("""
    from alphainfo.exceptions import AlphaInfoError

    try:
        result = client.analyze(signal=[...], sampling_rate=250.0)
    except AlphaInfoError as e:
        # Catches all alphainfo SDK errors
        print(f"SDK Error: {e.message}")
        print(f"Status: {e.status_code}")
        print(f"Details: {e.response_data}")
    except Exception as e:
        # Unexpected error
        print(f"Unexpected error: {e}")
    """)

    # Example 7: Checking rate limit info
    print("\n7. Checking Rate Limit Information")
    print("-" * 40)
    try:
        result = client.analyze(
            signal=[1.0, 2.0, 3.0, 2.0, 1.0],
            sampling_rate=250.0,
        )
        print(f"Analysis successful!")
        if client.rate_limit_info:
            info = client.rate_limit_info
            print(f"Rate Limit: {info.remaining}/{info.limit} remaining")
            print(f"Resets at: {info.reset}")
    except Exception as e:
        print(f"Error: {e}")

    client.close()

    print("\n" + "=" * 60)
    print("Done!")
    print("=" * 60)


if __name__ == "__main__":
    main()
