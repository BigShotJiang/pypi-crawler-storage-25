"""
structural_perception.py — LLM Tool Use wrapper for alphainfo

Provides three functions that an LLM agent can call as tools:
  - perceive()  → structured dict for agent reasoning
  - diagnose()  → human-readable text interpretation
  - compare_multi() → pairwise similarity matrix for clustering

Concept: "The LLM reasons, alphainfo perceives."
The LLM does not need to understand signal processing — it calls
perceive() and gets back a structured assessment it can reason about.

Usage with Claude tool_use:
    tools = [
        {"name": "perceive_structure", "description": "...", "input_schema": {...}},
        {"name": "diagnose_change", "description": "...", "input_schema": {...}},
        {"name": "compare_signals", "description": "...", "input_schema": {...}},
    ]

Example:
    from alphainfo import AlphaInfo
    from examples.structural_perception import StructuralPerception

    client = AlphaInfo(api_key="ai_your_key")
    sp = StructuralPerception(client)

    # Agent calls perceive() and gets back a dict it can reason about
    result = sp.perceive(signal=data, baseline=reference, sampling_rate=250.0)
    # → {"status": "diverging", "severity": "high", "score": 0.25, ...}

    # Agent calls diagnose() for a text explanation
    text = sp.diagnose(signal=data, baseline=reference, sampling_rate=250.0)
    # → "Structure diverged significantly (score: 0.25). The change is primarily
    #    along the mid-scale dimension while cross-scale structure is preserved.
    #    Scale pattern is near uniform, indicating change across all scales."

    # Agent calls compare_multi() for clustering
    matrix = sp.compare_multi(signals=[s1, s2, s3, s4], sampling_rate=10.0)
    # → {"n": 4, "clusters": [...], "outlier": 2, "matrix": [...]}
"""

from typing import Any, Dict, List, Optional


class StructuralPerception:
    """Wrapper that translates alphainfo results into LLM-friendly formats."""

    def __init__(self, client: Any):
        """
        Args:
            client: An AlphaInfo or AsyncAlphaInfo client instance.
        """
        self.client = client

    def perceive(
        self,
        signal: List[float],
        baseline: List[float],
        sampling_rate: float = 1.0,
        domain: str = "generic",
    ) -> Dict[str, Any]:
        """
        Analyze structural similarity and return a dict for agent reasoning.

        Returns a flat dict with the most important fields an LLM needs:
          - status: "stable", "monitoring", or "diverging"
          - severity: "none", "low", "moderate", "high", "critical"
          - score: structural_score (0-1, higher = more similar)
          - change_detected: bool
          - confidence: "stable", "transition", or "unstable"
          - action: recommended action string
          - summary: one-line human-readable summary
          - fingerprint: dict of the 5 structural dimensions (if available)
        """
        result = self.client.analyze(
            signal=signal,
            baseline=baseline,
            sampling_rate=sampling_rate,
            domain=domain,
            include_semantic=True,
            use_multiscale=True,
        )

        perception: Dict[str, Any] = {
            "status": getattr(result.semantic, "trend", None) or "unknown",
            "severity": getattr(result.semantic, "severity", None) or "unknown",
            "score": result.structural_score,
            "change_detected": result.change_detected,
            "confidence": result.confidence_band,
            "action": getattr(result.semantic, "recommended_action", None),
            "summary": getattr(result.semantic, "summary", ""),
        }

        # Extract fingerprint from metrics if available
        if result.metrics:
            fp = {}
            for key in ("sim_local", "sim_fractal", "sim_spectral",
                        "sim_transition", "sim_trend"):
                if key in result.metrics:
                    fp[key] = result.metrics[key]
            if fp:
                perception["fingerprint"] = fp

        return perception

    def diagnose(
        self,
        signal: List[float],
        baseline: List[float],
        sampling_rate: float = 1.0,
        domain: str = "generic",
    ) -> str:
        """
        Analyze and return a human-readable diagnostic text.

        This is useful when the LLM needs to explain the result to a user,
        or when you want to include the interpretation in a report.
        """
        p = self.perceive(signal, baseline, sampling_rate, domain)

        lines = []
        score = p["score"]
        status = p["status"]

        if score >= 0.70:
            lines.append(
                f"Structure is well preserved (score: {score:.2f}, status: {status})."
            )
        elif score >= 0.35:
            lines.append(
                f"Structure is in transition (score: {score:.2f}, status: {status})."
            )
        else:
            lines.append(
                f"Structure diverged significantly (score: {score:.2f}, status: {status})."
            )

        # Fingerprint diagnosis
        fp = p.get("fingerprint", {})
        if fp:
            # Find the most changed dimension
            lowest_key = min(fp, key=fp.get) if fp else None
            highest_key = max(fp, key=fp.get) if fp else None
            if lowest_key and highest_key and lowest_key != highest_key:
                lines.append(
                    f"The change is primarily in {_dim_name(lowest_key)} "
                    f"({lowest_key}: {fp[lowest_key]:.2f}) "
                    f"while {_dim_name(highest_key)} is preserved "
                    f"({highest_key}: {fp[highest_key]:.2f})."
                )

        return " ".join(lines)

    def compare_multi(
        self,
        signals: List[List[float]],
        sampling_rate: float = 1.0,
        domain: str = "generic",
        *,
        use_multiscale: bool = True,
    ) -> Dict[str, Any]:
        """
        Compare N signals pairwise and return clustering-ready results.

        Returns:
          - n: number of signals
          - matrix: NxN similarity matrix
          - most_similar_pair: (i, j) with highest score
          - most_different_pair: (i, j) with lowest score
          - outlier: index of the signal most different from all others
          - mean_scores: per-signal average similarity to all others
        """
        mr = self.client.analyze_matrix(
            signals=signals,
            sampling_rate=sampling_rate,
            domain=domain,
            use_multiscale=use_multiscale,
        )

        n = mr.n_signals

        # Compute mean similarity per signal (excluding self)
        mean_scores = []
        for i in range(n):
            others = [mr.matrix[i][j] for j in range(n) if j != i]
            mean_scores.append(sum(others) / len(others) if others else 0.0)

        # Find best and worst pairs
        best_pair = (0, 1)
        worst_pair = (0, 1)
        best_score = -1.0
        worst_score = 2.0
        for i in range(n):
            for j in range(i + 1, n):
                s = mr.matrix[i][j]
                if s > best_score:
                    best_score = s
                    best_pair = (i, j)
                if s < worst_score:
                    worst_score = s
                    worst_pair = (i, j)

        # Outlier = signal with lowest mean similarity
        outlier = mean_scores.index(min(mean_scores))

        return {
            "n": n,
            "matrix": mr.matrix,
            "most_similar_pair": best_pair,
            "most_different_pair": worst_pair,
            "outlier": outlier,
            "mean_scores": [round(s, 3) for s in mean_scores],
            "analyses_consumed": mr.analyses_consumed,
        }


def _dim_name(key: str) -> str:
    """Human-readable name for each structural dimension.

    Neutral, scale-oriented labels — descriptive of what the number
    tells the user, not of how it is computed internally.
    """
    names = {
        "sim_local": "the short-range dimension",
        "sim_spectral": "the mid-scale dimension",
        "sim_fractal": "the cross-scale dimension",
        "sim_transition": "the transition dimension",
        "sim_trend": "the long-range dimension",
    }
    return names.get(key, key)
