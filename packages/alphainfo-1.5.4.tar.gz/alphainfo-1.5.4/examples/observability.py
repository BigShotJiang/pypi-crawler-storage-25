#!/usr/bin/env python3
"""
alphainfo — Observability example (Prometheus-like metric time series)

Detect structural change in a service metric: request latency, error
rate, queue depth, CPU, anything you scrape every minute. Compare a
fresh window against a known-good baseline window and let the score
tell you whether behavior changed.

    export ALPHAINFO_API_KEY="ai_your_key"
    python examples/observability.py

Typical use: cron or scheduled job that re-runs this every few minutes,
with the baseline being "yesterday same-hour window" and the signal
being "last 15 minutes". Plot structural_score over time to see
deviation.
"""
import math
import os
import random

from alphainfo import AlphaInfo


def latency_series(mean_ms: float, spike_at: int = -1, n: int = 300) -> list[float]:
    """Fake a latency series with a configurable spike. Units: ms."""
    random.seed(0)
    out = [mean_ms + random.gauss(0, mean_ms * 0.05) for _ in range(n)]
    if 0 <= spike_at < n:
        # Inject a sustained regime change starting at spike_at.
        for i in range(spike_at, n):
            out[i] = (mean_ms * 3) + random.gauss(0, mean_ms * 0.2)
    return [round(max(0.0, v), 2) for v in out]


def main() -> None:
    client = AlphaInfo(api_key=os.environ["ALPHAINFO_API_KEY"])

    # Baseline: 5 minutes of healthy latency (mean ~80ms).
    baseline = latency_series(mean_ms=80.0)

    # Current window: latency started spiking midway.
    current = latency_series(mean_ms=80.0, spike_at=150)

    result = client.analyze(
        signal=current,
        baseline=baseline,
        sampling_rate=1.0,           # one data point per second
        domain="sensors",            # good fit for monotonic engineering metrics
        include_semantic=True,
    )

    print("Latency regime check (current vs healthy baseline)")
    print("-" * 55)
    print(f"structural_score: {result.structural_score:.3f}  "
          "(1.0 = same distribution, 0.0 = changed)")
    print(f"confidence_band:  {result.confidence_band}")
    print(f"change_detected:  {result.change_detected}")

    if result.semantic:
        print(f"severity:         {result.semantic.severity}")
        print(f"recommended:      {result.semantic.recommended_action}")

    # In a real pipeline you would:
    #   - Emit structural_score as a Prometheus gauge
    #   - Alert if confidence_band == "unstable" for N consecutive windows
    #   - Keep analysis_id so you can call /v1/audit/replay/{id} later


if __name__ == "__main__":
    main()
