#!/usr/bin/env python3
"""
alphainfo SDK - Async Example

Demonstrates asynchronous usage of the alphainfo Python SDK.

Usage:
    export ALPHAINFO_API_KEY="ai_your_key_here"
    python examples/async_example.py
"""

import os
import asyncio
from alphainfo import AsyncAlphaInfo


async def main():
    """Run async examples."""

    # Get API key from environment
    api_key = os.getenv("ALPHAINFO_API_KEY")
    if not api_key:
        print("Error: ALPHAINFO_API_KEY environment variable not set")
        return

    print("=" * 60)
    print("alphainfo Python SDK - Async Example")
    print("=" * 60)

    # Use async context manager
    async with AsyncAlphaInfo(api_key=api_key) as client:

        # 1. Health check
        print("\n1. Health Check (async)")
        print("-" * 40)
        try:
            health = await client.health()
            print(f"Status: {health.status}")
            print(f"Version: {health.version}")
        except Exception as e:
            print(f"Error: {e}")
            return

        # 2. Analyze signal
        print("\n2. Signal Analysis (async)")
        print("-" * 40)
        try:
            signal = [1.0, 2.0, 3.0, 2.5, 2.0, 1.5, 1.0] * 20

            result = await client.analyze(
                signal=signal,
                sampling_rate=250.0,
                domain="generic",
            )

            print(f"Structural Score: {result.structural_score:.3f}")
            print(f"Change Detected: {result.change_detected}")
            print(f"Confidence Band: {result.confidence_band}")
            print(f"Analysis ID: {result.analysis_id}")

        except Exception as e:
            print(f"Error: {e}")

        # 3. Concurrent requests (multiple analyses in parallel)
        print("\n3. Concurrent Requests (async)")
        print("-" * 40)
        try:
            # Create multiple tasks to run concurrently
            signals = [
                [1.0, 2.0, 3.0, 2.5, 2.0, 1.5, 1.0] * 10,
                [2.0, 3.0, 4.0, 3.5, 3.0, 2.5, 2.0] * 10,
                [0.5, 1.0, 1.5, 1.2, 1.0, 0.8, 0.5] * 10,
            ]

            tasks = [
                client.analyze(signal=sig, sampling_rate=250.0)
                for sig in signals
            ]

            results = await asyncio.gather(*tasks)

            for i, result in enumerate(results, 1):
                print(f"Analysis {i}: Score={result.structural_score:.3f}, "
                      f"Changed={result.change_detected}")

        except Exception as e:
            print(f"Error: {e}")

    print("\n" + "=" * 60)
    print("Done! (Async client automatically closed)")
    print("=" * 60)


if __name__ == "__main__":
    asyncio.run(main())
