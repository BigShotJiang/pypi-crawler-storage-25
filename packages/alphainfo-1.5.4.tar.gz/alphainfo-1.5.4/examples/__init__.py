"""
alphainfo SDK Examples

This directory contains example scripts showing how to use the alphainfo SDK.

- quickstart.py: Basic synchronous usage
- async_example.py: Asynchronous usage with concurrent requests
"""
