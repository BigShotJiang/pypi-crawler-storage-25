#!/usr/bin/env python3
"""
alphainfo — Fintech example (SPY daily prices via yfinance)

Detects structural change across periods of the SPY ETF. Useful as a
template for regime-shift monitoring, crisis detection, or comparing
two market periods.

Requires yfinance:
    pip install alphainfo yfinance

    export ALPHAINFO_API_KEY="ai_your_key"
    python examples/fintech.py
"""
import os

import yfinance as yf

from alphainfo import AlphaInfo


def fetch_spy(start: str, end: str) -> list[float]:
    """Fetch daily SPY closing prices between two dates."""
    df = yf.download("SPY", start=start, end=end, progress=False, auto_adjust=False)
    if df is None or df.empty:
        raise RuntimeError(f"No SPY data returned for {start} to {end}")
    return df["Close"].squeeze().tolist()


def main() -> None:
    client = AlphaInfo(api_key=os.environ["ALPHAINFO_API_KEY"])

    # Calm baseline: first 9 months of 2019.
    baseline = fetch_spy("2019-01-01", "2019-09-30")
    # Window under test: March 2020 (COVID crash).
    window = fetch_spy("2020-02-15", "2020-04-15")

    result = client.analyze(
        signal=window,
        baseline=baseline,
        sampling_rate=1.0,   # daily data
        domain="finance",
        include_semantic=True,
    )

    print("SPY March 2020 vs 2019 baseline")
    print("-" * 40)
    print(f"structural_score: {result.structural_score:.3f}  "
          "(1.0 = stable, 0.0 = regime changed)")
    print(f"confidence_band:  {result.confidence_band}")
    print(f"change_detected:  {result.change_detected}")

    if result.semantic:
        print(f"severity:         {result.semantic.severity}  "
              f"(score {result.semantic.severity_score})")
        print(f"trend:            {result.semantic.trend}")
        print(f"recommended:      {result.semantic.recommended_action}")
        print()
        print(result.semantic.summary)


if __name__ == "__main__":
    main()
