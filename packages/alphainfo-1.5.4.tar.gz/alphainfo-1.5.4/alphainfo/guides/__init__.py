# Guide markdown files are included in this package for offline access.
# For the live, structured version, use client.guide() or GET /v1/guide.
