"""
alphainfo SDK — Synchronous and Async Clients

Production-grade Python client for the alphainfo Structural Intelligence API.
Supports all endpoints with automatic retry, rate limit tracking, and typed responses.

Example (sync):
    >>> from alphainfo import AlphaInfo
    >>> client = AlphaInfo(api_key="ai_xxxxxxxxxxxxx")
    >>> result = client.analyze(signal=[...], sampling_rate=250.0)
    >>> print(result.structural_score, result.confidence_band)

Example (async):
    >>> from alphainfo import AsyncAlphaInfo
    >>> async with AsyncAlphaInfo(api_key="ai_xxx") as client:
    ...     result = await client.analyze(signal=[...], sampling_rate=250.0)
"""

import asyncio
import time
from typing import Any, Dict, List, Optional

import httpx

from .exceptions import (
    APIError,
    AuthError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    ValidationError,
)
from .exceptions import (
    TimeoutError as SDKTimeoutError,
)
from .models import (
    AnalysisResult,
    AuditReplay,
    AuditSummary,
    BatchItemResult,
    BatchResult,
    ChannelResult,
    FingerprintResult,
    HealthStatus,
    MatrixResult,
    PlanInfo,
    RateLimitInfo,
    SemanticResult,
    VectorResult,
)

__all__ = ["AlphaInfo", "AsyncAlphaInfo"]

_SDK_VERSION = "1.5.1"

# ---------------------------------------------------------------------------
# HTTP/2 auto-detection
# ---------------------------------------------------------------------------

try:
    import h2  # noqa: F401
    _H2_AVAILABLE = True
except ImportError:
    _H2_AVAILABLE = False


def _resolve_http2(http2: Optional[bool]) -> bool:
    """Resolve http2 flag: explicit value wins, otherwise auto-detect h2 package."""
    if http2 is not None:
        return http2
    return _H2_AVAILABLE


def _build_url(base_url: str, endpoint: str) -> str:
    """Build full URL safely."""
    base = base_url.rstrip("/")
    path = endpoint if endpoint.startswith("/") else f"/{endpoint}"
    return f"{base}{path}"


# ---------------------------------------------------------------------------
# Response handling (shared)
# ---------------------------------------------------------------------------

def _handle_error_response(response: httpx.Response) -> None:
    """Raise typed exception for non-2xx responses."""
    status = response.status_code

    try:
        data = response.json()
    except Exception:
        data = {}

    if status == 401:
        raise AuthError("Invalid or missing API key", status_code=401, response_data=data)

    if status == 400:
        detail = data.get("detail", "Bad request")
        msg = detail if isinstance(detail, str) else str(detail)
        raise ValidationError(f"Validation error: {msg}", status_code=400, response_data=data)

    if status == 413:
        detail = data.get("detail", {})
        msg = detail.get("message", "Signal too large") if isinstance(detail, dict) else str(detail)
        raise ValidationError(f"Payload too large: {msg}", status_code=413, response_data=data)

    if status == 404:
        detail = data.get("detail", "Not found")
        raise NotFoundError(str(detail), status_code=404, response_data=data)

    if status == 429:
        retry_after = int(response.headers.get("Retry-After", "60"))
        detail = data.get("detail", {})
        if isinstance(detail, dict):
            msg = detail.get("message", "Rate limit exceeded")
        else:
            msg = str(detail)
        raise RateLimitError(
            msg, status_code=429,
            retry_after=retry_after, response_data=data,
        )

    if status >= 500:
        detail = data.get("detail", "Internal server error")
        raise APIError(f"Server error: {detail}", status_code=status, response_data=data)

    if status >= 400:
        raise APIError(f"HTTP {status}", status_code=status, response_data=data)


def _extract_rate_limit(headers: httpx.Headers) -> Optional[RateLimitInfo]:
    """Extract rate limit info from response headers."""
    try:
        limit = int(headers.get("x-ratelimit-limit", "0"))
        if limit > 0:
            return RateLimitInfo(
                limit=limit,
                remaining=int(headers.get("x-ratelimit-remaining", "0")),
                reset=int(headers.get("x-ratelimit-reset", "0")),
            )
    except (ValueError, TypeError):
        pass
    return None


# ---------------------------------------------------------------------------
# Result parsers (shared between sync and async)
# ---------------------------------------------------------------------------

def _parse_semantic(raw: Any) -> Optional[SemanticResult]:
    """Parse semantic dict into SemanticResult dataclass."""
    if raw is None or not isinstance(raw, dict):
        return None
    _known = {"summary", "alert_level", "recommended_action", "trend", "severity", "severity_score"}
    return SemanticResult(
        summary=raw.get("summary", ""),
        alert_level=raw.get("alert_level", "normal"),
        recommended_action=raw.get("recommended_action"),
        trend=raw.get("trend"),
        severity=raw.get("severity"),
        severity_score=raw.get("severity_score"),
        details={k: v for k, v in raw.items() if k not in _known} or None,
    )


def _parse_analysis(data: Dict[str, Any]) -> AnalysisResult:
    return AnalysisResult(
        structural_score=data["structural_score"],
        change_detected=data["change_detected"],
        change_score=data["change_score"],
        confidence_band=data["confidence_band"],
        engine_version=data["engine_version"],
        analysis_id=data["analysis_id"],
        metrics=data.get("metrics"),
        provenance=data.get("provenance"),
        semantic=_parse_semantic(data.get("semantic")),
        warning=data.get("warning"),
    )


def _parse_batch(data: Dict[str, Any]) -> BatchResult:
    items: List[BatchItemResult] = []
    for r in data.get("results", []):
        items.append(BatchItemResult(
            index=r.get("index", len(items)),
            structural_score=r.get("structural_score"),
            change_detected=r.get("change_detected"),
            change_score=r.get("change_score"),
            confidence_band=r.get("confidence_band"),
            engine_version=r.get("engine_version"),
            analysis_id=r.get("analysis_id"),
            metrics=r.get("metrics"),
            semantic=_parse_semantic(r.get("semantic")),
            error=r.get("error"),
        ))
    return BatchResult(
        results=items,
        analyses_consumed=data.get("analyses_consumed", len(items)),
        total_signals=data.get("total_signals", len(items)),
    )


def _parse_vector(data: Dict[str, Any]) -> VectorResult:
    channels: Dict[str, ChannelResult] = {}
    for name, ch in data.get("channels", {}).items():
        channels[name] = ChannelResult(
            name=name,
            structural_score=ch.get("structural_score"),
            change_detected=ch.get("change_detected"),
            change_score=ch.get("change_score"),
            confidence_band=ch.get("confidence_band"),
            engine_version=ch.get("engine_version"),
            error=ch.get("error"),
        )
    return VectorResult(
        analysis_id=data["analysis_id"],
        structural_score=data["structural_score"],
        change_detected=data["change_detected"],
        change_score=data.get("change_score", 0.0),
        n_channels=data.get("n_channels", len(channels)),
        channels=channels,
        confidence_band=data.get("confidence_band"),
        analyses_consumed=data.get("analyses_consumed", 1),
        semantic=_parse_semantic(data.get("semantic")),
        warning=data.get("warning"),
    )


def _parse_audit_replay(data: Dict[str, Any]) -> AuditReplay:
    params = data.get("parameters", {})
    # sampling_rate lives inside parameters; fall back to top-level for compat
    sampling_rate = data.get("sampling_rate") or params.get("sampling_rate", 0.0)
    return AuditReplay(
        analysis_id=data["analysis_id"],
        timestamp=data["timestamp"],
        signal_length=data.get("signal_length", data.get("n_samples", 0)),
        sampling_rate=float(sampling_rate),
        parameters=params,
        output=data.get("output", {}),
        engine_version=data.get("engine_version", ""),
        client_id=data.get("client_id"),
        request_id=data.get("request_id"),
    )


def _parse_matrix(data: Dict[str, Any]) -> MatrixResult:
    """Parse matrix response."""
    return MatrixResult(
        matrix=data["matrix"],
        labels=data.get("labels", []),
        n_signals=data["n_signals"],
        n_pairs=data["n_pairs"],
        analyses_consumed=data["analyses_consumed"],
        errors=data.get("errors"),
    )


def _parse_health(data: Dict[str, Any]) -> HealthStatus:
    """Parse health response."""
    return HealthStatus(
        status=data["status"],
        version=data["version"],
        message=data.get("message", ""),
    )


def _parse_plans(data: Any) -> List[PlanInfo]:
    """Parse plans response."""
    items = data.get("plans", []) if isinstance(data, dict) else data
    return [
        PlanInfo(
            id=p["id"],
            name=p["name"],
            slug=p["slug"],
            price_cents=p["price_cents"],
            currency=p.get("currency", "USD"),
            monthly_limit=p.get("monthly_limit", 0),
            features=p.get("features"),
            stripe_price_id=p.get("stripe_price_id"),
        )
        for p in items
    ]


def _parse_fingerprint(data: Dict[str, Any]) -> FingerprintResult:
    """Parse analysis response into a minimal FingerprintResult (5D vector)."""
    metrics = data.get("metrics", {})
    return FingerprintResult(
        analysis_id=data["analysis_id"],
        structural_score=data["structural_score"],
        confidence_band=data["confidence_band"],
        sim_local=metrics.get("sim_local", 0.0),
        sim_spectral=metrics.get("sim_spectral", 0.0),
        sim_fractal=metrics.get("sim_fractal", 0.0),
        sim_transition=metrics.get("sim_transition", 0.0),
        sim_trend=metrics.get("sim_trend", 0.0),
    )


def _parse_audit_list(data: Any) -> List[AuditSummary]:
    """Parse audit list response."""
    items = data if isinstance(data, list) else data.get("analyses", [])
    return [
        AuditSummary(
            analysis_id=a.get("analysis_id") or a.get("id", ""),
            timestamp=a.get("timestamp", ""),
            signal_length=a.get("signal_length", 0),
            domain=a.get("domain"),
            structural_score=a.get("structural_score"),
            change_detected=a.get("change_detected"),
        )
        for a in items
    ]


# ---------------------------------------------------------------------------
# Payload builders (shared between sync and async)
# ---------------------------------------------------------------------------

def _build_analyze_payload(
    signal: List[float],
    sampling_rate: float,
    domain: str,
    baseline: Optional[List[float]],
    metadata: Optional[Dict[str, Any]],
    include_semantic: bool,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build analyze payload."""
    if not signal:
        raise ValidationError("signal cannot be empty")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    payload: Dict[str, Any] = {
        "signal": signal,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "include_semantic": include_semantic,
        "use_multiscale": use_multiscale,
    }
    if baseline is not None:
        payload["baseline"] = baseline
    if metadata is not None:
        payload["metadata"] = metadata
    return payload


def _build_batch_payload(
    signals: List[List[float]],
    sampling_rate: float,
    domain: str,
    baselines: Optional[List[Optional[List[float]]]],
    include_semantic: bool,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build batch payload."""
    if not signals:
        raise ValidationError("signals list cannot be empty")
    if len(signals) > 100:
        raise ValidationError("Maximum 100 signals per batch")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    if baselines is not None and len(baselines) != len(signals):
        raise ValidationError(
            f"baselines length ({len(baselines)}) must match "
            f"signals length ({len(signals)})"
        )
    payload: Dict[str, Any] = {
        "signals": signals,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "include_semantic": include_semantic,
        "use_multiscale": use_multiscale,
    }
    if baselines is not None:
        payload["baselines"] = baselines
    return payload


def _build_matrix_payload(
    signals: List[List[float]],
    sampling_rate: float,
    domain: str,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build matrix payload."""
    if len(signals) < 2:
        raise ValidationError("Need at least 2 signals for matrix")
    if len(signals) > 50:
        raise ValidationError("Maximum 50 signals per matrix request")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    return {
        "signals": signals,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "use_multiscale": use_multiscale,
    }


def _build_vector_payload(
    channels: Dict[str, List[float]],
    sampling_rate: float,
    domain: str,
    baselines: Optional[Dict[str, List[float]]],
    include_semantic: bool,
    use_multiscale: bool,
) -> Dict[str, Any]:
    """Validate inputs and build vector payload."""
    if not channels:
        raise ValidationError("channels cannot be empty")
    if sampling_rate <= 0:
        raise ValidationError("sampling_rate must be positive")
    if baselines is not None:
        unknown = set(baselines.keys()) - set(channels.keys())
        if unknown:
            raise ValidationError(f"Baseline keys {sorted(unknown)} don't match any channel")
    payload: Dict[str, Any] = {
        "channels": channels,
        "sampling_rate": sampling_rate,
        "domain": domain,
        "include_semantic": include_semantic,
        "use_multiscale": use_multiscale,
    }
    if baselines is not None:
        payload["baselines"] = baselines
    return payload


# ---------------------------------------------------------------------------
# Synchronous client
# ---------------------------------------------------------------------------

class AlphaInfo:
    """
    Synchronous client for the alphainfo Structural Intelligence API.

    Args:
        api_key: Your API key (starts with 'ai_').
        base_url: API base URL (default: https://www.alphainfo.io).
        timeout: Default request timeout in seconds.
        max_retries: Maximum retries on transient failures (5xx, timeouts, rate limits).
        retry_base_delay: Base delay (seconds) for exponential backoff (default: 1.0).
        retry_max_delay: Maximum delay (seconds) between retries (default: 32.0).
        http2: Enable HTTP/2. Auto-detected if h2 package is installed.
            Install with: pip install alphainfo[http2]

    Usage:
        >>> client = AlphaInfo(api_key="ai_your_key")
        >>> result = client.analyze([1.0, 2.0, 3.0, ...], sampling_rate=250.0)
        >>> print(result.confidence_band)  # 'stable', 'transition', or 'unstable'
    """

    DEFAULT_BASE_URL = "https://www.alphainfo.io"
    DEFAULT_TIMEOUT = 30.0
    ANALYZE_TIMEOUT = 60.0
    HEALTH_TIMEOUT = 10.0
    MAX_RETRIES = 3
    RETRY_BASE_DELAY = 1.0
    RETRY_MAX_DELAY = 32.0

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
        retry_base_delay: float = RETRY_BASE_DELAY,
        retry_max_delay: float = RETRY_MAX_DELAY,
        http2: Optional[bool] = None,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_base_delay = retry_base_delay
        self._retry_max_delay = retry_max_delay
        self._http2 = _resolve_http2(http2)
        self._client = httpx.Client(timeout=timeout, http2=self._http2)
        self._rate_limit: Optional[RateLimitInfo] = None

    def close(self) -> None:
        """Close the underlying HTTP connection pool."""
        self._client.close()

    def __enter__(self) -> "AlphaInfo":
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    @property
    def rate_limit_info(self) -> Optional[RateLimitInfo]:
        """Rate limit info from the most recent request."""
        return self._rate_limit

    def _headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": f"alphainfo-python/{_SDK_VERSION}",
        }

    def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        """Execute HTTP request with retry on transient errors."""
        url = _build_url(self._base_url, endpoint)
        headers = self._headers()
        effective_timeout = timeout or self._timeout
        last_exc: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                if method == "GET":
                    resp = self._client.get(url, headers=headers, timeout=effective_timeout)
                else:
                    resp = self._client.post(
                        url, json=json, headers=headers,
                        timeout=effective_timeout,
                    )

                self._rate_limit = _extract_rate_limit(resp.headers)

                if resp.status_code < 400:
                    result: Dict[str, Any] = resp.json()
                    return result

                _handle_error_response(resp)

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self._max_retries:
                    time.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise SDKTimeoutError(
                    f"Request to {endpoint} timed out after {self._max_retries + 1} attempts"
                ) from e

            except RateLimitError as e:
                last_exc = e
                if attempt < self._max_retries:
                    delay = e.retry_after or self._retry_base_delay * (2 ** attempt)
                    time.sleep(min(delay, self._retry_max_delay))
                    continue
                raise

            except (AuthError, ValidationError, NotFoundError):
                raise  # Non-retryable

            except APIError as e:
                last_exc = e
                if attempt < self._max_retries and e.status_code and e.status_code >= 500:
                    time.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise

        raise NetworkError(f"Failed after {self._max_retries + 1} attempts") from last_exc

    # -- analyze --------------------------------------------------------------

    def analyze(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> AnalysisResult:
        """
        Analyze a time series signal for structural regime changes.

        Args:
            signal: Signal data (list of floats, min 10 samples).
            sampling_rate: Sampling rate in Hz (must be > 0).
            domain: Analysis domain ('generic', 'biomedical', 'finance', 'energy', etc.).
            baseline: Optional baseline signal for comparison.
            metadata: Optional metadata dict (max 10KB serialized).
            include_semantic: Include human-readable interpretation.
            use_multiscale: Enable multi-scale analysis (more thorough, slower).

        Returns:
            AnalysisResult with structural_score, confidence_band, analysis_id, etc.

        Raises:
            ValidationError: Invalid input (empty signal, bad sampling rate, etc.)
            AuthError: Invalid API key.
            RateLimitError: Monthly quota or concurrent limit exceeded.
        """
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata, include_semantic, use_multiscale,
        )
        data = self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_analysis(data)

    # -- analyze_batch ---------------------------------------------------------

    def analyze_batch(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[List[Optional[List[float]]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> BatchResult:
        """
        Analyze multiple signals in a single request.

        Args:
            signals: List of signal arrays (max 100 signals per batch).
            sampling_rate: Common sampling rate for all signals.
            domain: Analysis domain.
            baselines: Optional per-signal baselines. Same length as signals.
                Use None for signals that don't need a baseline.
            include_semantic: Include semantic interpretation per signal.
            use_multiscale: Enable multi-scale analysis.

        Returns:
            BatchResult with per-signal results and quota usage.

        Note:
            Each signal in the batch counts as 1 analysis against your quota.
        """
        payload = _build_batch_payload(
            signals, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = self._request(
            "POST", "/v1/analyze/batch",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_batch(data)

    # -- analyze_matrix --------------------------------------------------------

    def analyze_matrix(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        use_multiscale: bool = True,
    ) -> MatrixResult:
        """
        Compute pairwise structural similarity matrix for N signals.

        Args:
            signals: List of signal arrays (2-50 signals).
            sampling_rate: Common sampling rate for all signals.
            domain: Analysis domain.
            use_multiscale: Enable multi-scale analysis.

        Returns:
            MatrixResult with NxN similarity matrix and helper methods.

        Note:
            Consumes N*(N-1)/2 analyses (one per unique pair).
        """
        payload = _build_matrix_payload(signals, sampling_rate, domain, use_multiscale)
        data = self._request(
            "POST", "/v1/analyze/matrix",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_matrix(data)

    # -- analyze_vector --------------------------------------------------------

    def analyze_vector(
        self,
        channels: Dict[str, List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[Dict[str, List[float]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> VectorResult:
        """
        Analyze multi-channel signal data (e.g., multi-lead ECG, multi-axis sensors).

        Args:
            channels: Dict mapping channel names to signal arrays.
                Example: {"lead_I": [...], "lead_II": [...]}
            sampling_rate: Common sampling rate for all channels.
            domain: Analysis domain.
            baselines: Optional per-channel baselines for comparison.
                Keys must match channel names.
                Example: {"lead_I": [...], "lead_II": [...]}
            include_semantic: Include semantic interpretation.
            use_multiscale: Enable multi-scale analysis.

        Returns:
            VectorResult with per-channel results and aggregated score.

        Note:
            Vector analysis consumes only 1 analysis regardless of channel count.
        """
        payload = _build_vector_payload(
            channels, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = self._request(
            "POST", "/v1/analyze/vector",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_vector(data)

    # -- audit -----------------------------------------------------------------

    def audit_replay(self, analysis_id: str) -> AuditReplay:
        """
        Replay a past analysis by its unique ID.

        Args:
            analysis_id: UUID from a previous analysis result.

        Returns:
            AuditReplay with full inputs, parameters, and outputs.

        Raises:
            NotFoundError: Analysis ID not found.
        """
        if not analysis_id:
            raise ValidationError("analysis_id cannot be empty")
        data = self._request("GET", f"/v1/audit/replay/{analysis_id}")
        return _parse_audit_replay(data)

    def audit_list(self, limit: int = 100) -> List[AuditSummary]:
        """
        List recent analyses for your API key.

        Args:
            limit: Maximum number of results (default 100).

        Returns:
            List of AuditSummary objects.
        """
        data = self._request("GET", f"/v1/audit/list?limit={limit}")
        return _parse_audit_list(data)

    # -- health ----------------------------------------------------------------

    def health(self) -> HealthStatus:
        """Check API health status."""
        data = self._request("GET", "/health", timeout=self.HEALTH_TIMEOUT)
        return _parse_health(data)

    # -- plans -----------------------------------------------------------------

    def plans(self) -> List[PlanInfo]:
        """List available billing plans."""
        data = self._request("GET", "/api/plans")
        return _parse_plans(data)

    # -- guide -----------------------------------------------------------------

    def guide(self) -> Dict[str, Any]:
        """
        Fetch the universal encoding guide from the API.

        Returns a dict with sections: encoding_patterns, usage_modes, endpoints,
        common_mistakes, performance_tips, debugging_tips,
        fingerprint_interpretation, signal_requirements, baseline_guide, and
        more.

        No authentication required. Useful for discoverability and AI agent
        introspection.

        Returns:
            Dict with guide version and all sections.
        """
        return self._request("GET", "/v1/guide", timeout=self.HEALTH_TIMEOUT)

    # -- fingerprint -----------------------------------------------------------

    def fingerprint(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
    ) -> FingerprintResult:
        """
        Extract the 5D structural fingerprint of a signal (fast path).

        Skips semantic interpretation and multi-scale analysis for speed.
        Returns a 5-dimensional vector capturing the signal's structural
        identity. Use ``result.vector`` for nearest-neighbor / ANN indexing.

        Args:
            signal: Signal data (list of floats, min 10 samples).
            sampling_rate: Sampling rate in Hz.
            domain: Analysis domain.
            baseline: Optional baseline for comparison.

        Returns:
            FingerprintResult with the 5 structural dimensions and a
            ``.vector`` property ready for pgvector / Qdrant / Faiss.
        """
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata=None,
            include_semantic=False,
            use_multiscale=False,
        )
        data = self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_fingerprint(data)

    # -- version ---------------------------------------------------------------

    def version(self) -> Dict[str, Any]:
        """
        Get API version and compatibility information.

        Returns:
            Dict with api_version, sdk_compat, engine_version, etc.
        """
        return self._request("GET", "/v1/version", timeout=self.HEALTH_TIMEOUT)


# ---------------------------------------------------------------------------
# Async client
# ---------------------------------------------------------------------------

class AsyncAlphaInfo:
    """
    Asynchronous client for the alphainfo Structural Intelligence API.

    Args:
        api_key: Your API key (starts with 'ai_').
        base_url: API base URL (default: https://www.alphainfo.io).
        timeout: Default request timeout in seconds.
        max_retries: Maximum retries on transient failures (5xx, timeouts, rate limits).
        retry_base_delay: Base delay (seconds) for exponential backoff (default: 1.0).
        retry_max_delay: Maximum delay (seconds) between retries (default: 32.0).
        http2: Enable HTTP/2. Auto-detected if h2 package is installed.
            Install with: pip install alphainfo[http2]

    Usage:
        >>> async with AsyncAlphaInfo(api_key="ai_xxx") as client:
        ...     result = await client.analyze([1.0, 2.0, ...], sampling_rate=250.0)
    """

    DEFAULT_BASE_URL = AlphaInfo.DEFAULT_BASE_URL
    DEFAULT_TIMEOUT = AlphaInfo.DEFAULT_TIMEOUT
    ANALYZE_TIMEOUT = AlphaInfo.ANALYZE_TIMEOUT
    HEALTH_TIMEOUT = AlphaInfo.HEALTH_TIMEOUT
    MAX_RETRIES = AlphaInfo.MAX_RETRIES
    RETRY_BASE_DELAY = AlphaInfo.RETRY_BASE_DELAY
    RETRY_MAX_DELAY = AlphaInfo.RETRY_MAX_DELAY

    def __init__(
        self,
        api_key: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = MAX_RETRIES,
        retry_base_delay: float = RETRY_BASE_DELAY,
        retry_max_delay: float = RETRY_MAX_DELAY,
        http2: Optional[bool] = None,
    ):
        if not api_key:
            raise ValueError("api_key is required")
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._timeout = timeout
        self._max_retries = max_retries
        self._retry_base_delay = retry_base_delay
        self._retry_max_delay = retry_max_delay
        self._http2 = _resolve_http2(http2)
        self._client = httpx.AsyncClient(timeout=timeout, http2=self._http2)
        self._rate_limit: Optional[RateLimitInfo] = None

    async def close(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncAlphaInfo":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    @property
    def rate_limit_info(self) -> Optional[RateLimitInfo]:
        return self._rate_limit

    def _headers(self) -> Dict[str, str]:
        return {
            "X-API-Key": self._api_key,
            "Content-Type": "application/json",
            "User-Agent": f"alphainfo-python/{_SDK_VERSION}",
        }

    async def _request(
        self,
        method: str,
        endpoint: str,
        json: Optional[Dict[str, Any]] = None,
        timeout: Optional[float] = None,
    ) -> Dict[str, Any]:
        url = _build_url(self._base_url, endpoint)
        headers = self._headers()
        effective_timeout = timeout or self._timeout
        last_exc: Optional[Exception] = None

        for attempt in range(self._max_retries + 1):
            try:
                if method == "GET":
                    resp = await self._client.get(url, headers=headers, timeout=effective_timeout)
                else:
                    resp = await self._client.post(
                        url, json=json, headers=headers,
                        timeout=effective_timeout,
                    )

                self._rate_limit = _extract_rate_limit(resp.headers)

                if resp.status_code < 400:
                    result: Dict[str, Any] = resp.json()
                    return result

                _handle_error_response(resp)

            except (httpx.TimeoutException, httpx.ConnectError) as e:
                last_exc = e
                if attempt < self._max_retries:
                    await asyncio.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise SDKTimeoutError(
                    f"Request to {endpoint} timed out "
                    f"after {self._max_retries + 1} attempts"
                ) from e

            except RateLimitError as e:
                last_exc = e
                if attempt < self._max_retries:
                    delay = e.retry_after or (
                        self._retry_base_delay * (2 ** attempt)
                    )
                    await asyncio.sleep(min(delay, self._retry_max_delay))
                    continue
                raise

            except (AuthError, ValidationError, NotFoundError):
                raise

            except APIError as e:
                last_exc = e
                if (
                    attempt < self._max_retries
                    and e.status_code
                    and e.status_code >= 500
                ):
                    await asyncio.sleep(min(
                        self._retry_base_delay * (2 ** attempt),
                        self._retry_max_delay,
                    ))
                    continue
                raise

        raise NetworkError(
            f"Failed after {self._max_retries + 1} attempts",
        ) from last_exc

    # -- All endpoints use shared builders and parsers -------------------------

    async def analyze(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
        metadata: Optional[Dict[str, Any]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> AnalysisResult:
        """Analyze a signal for structural regime changes (async)."""
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata, include_semantic, use_multiscale,
        )
        data = await self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_analysis(data)

    async def analyze_batch(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[List[Optional[List[float]]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> BatchResult:
        """Analyze multiple signals in one request (async)."""
        payload = _build_batch_payload(
            signals, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = await self._request(
            "POST", "/v1/analyze/batch",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_batch(data)

    async def analyze_matrix(
        self,
        signals: List[List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        use_multiscale: bool = True,
    ) -> MatrixResult:
        """Compute pairwise structural similarity matrix (async)."""
        payload = _build_matrix_payload(signals, sampling_rate, domain, use_multiscale)
        data = await self._request(
            "POST", "/v1/analyze/matrix",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_matrix(data)

    async def analyze_vector(
        self,
        channels: Dict[str, List[float]],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baselines: Optional[Dict[str, List[float]]] = None,
        include_semantic: bool = False,
        use_multiscale: bool = True,
    ) -> VectorResult:
        """Analyze multi-channel signal data (async)."""
        payload = _build_vector_payload(
            channels, sampling_rate, domain,
            baselines, include_semantic, use_multiscale,
        )
        data = await self._request(
            "POST", "/v1/analyze/vector",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_vector(data)

    async def audit_replay(self, analysis_id: str) -> AuditReplay:
        """Replay a past analysis (async)."""
        if not analysis_id:
            raise ValidationError("analysis_id cannot be empty")
        data = await self._request("GET", f"/v1/audit/replay/{analysis_id}")
        return _parse_audit_replay(data)

    async def audit_list(self, limit: int = 100) -> List[AuditSummary]:
        """List recent analyses (async)."""
        data = await self._request("GET", f"/v1/audit/list?limit={limit}")
        return _parse_audit_list(data)

    async def health(self) -> HealthStatus:
        """Check API health (async)."""
        data = await self._request("GET", "/health", timeout=self.HEALTH_TIMEOUT)
        return _parse_health(data)

    async def plans(self) -> List[PlanInfo]:
        """List available plans (async)."""
        data = await self._request("GET", "/api/plans")
        return _parse_plans(data)

    async def guide(self) -> Dict[str, Any]:
        """Fetch the universal encoding guide (async). No auth required."""
        return await self._request("GET", "/v1/guide", timeout=self.HEALTH_TIMEOUT)

    async def fingerprint(
        self,
        signal: List[float],
        sampling_rate: float,
        domain: str = "generic",
        *,
        baseline: Optional[List[float]] = None,
    ) -> FingerprintResult:
        """Extract the 5D structural fingerprint (async, fast path)."""
        payload = _build_analyze_payload(
            signal, sampling_rate, domain,
            baseline, metadata=None,
            include_semantic=False,
            use_multiscale=False,
        )
        data = await self._request(
            "POST", "/v1/analyze/stream",
            json=payload, timeout=self.ANALYZE_TIMEOUT,
        )
        return _parse_fingerprint(data)

    async def version(self) -> Dict[str, Any]:
        """Get API version and compatibility info (async)."""
        return await self._request("GET", "/v1/version", timeout=self.HEALTH_TIMEOUT)
