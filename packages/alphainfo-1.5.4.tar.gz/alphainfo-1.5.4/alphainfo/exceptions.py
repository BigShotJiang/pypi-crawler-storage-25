"""
alphainfo SDK — Exception Hierarchy

All exceptions inherit from AlphaInfoError for easy catch-all handling.
Each maps to a specific HTTP error scenario from the API.
"""

from typing import Any, Dict, Optional


class AlphaInfoError(Exception):
    """Base exception for all alphainfo SDK errors.

    Attributes:
        message: Human-readable error message.
        status_code: HTTP status code (when the error originated from the API).
        response_data: Parsed JSON body of the error response, if any.
    """

    def __init__(
        self,
        message: str,
        status_code: Optional[int] = None,
        response_data: Optional[Dict[str, Any]] = None,
    ):
        super().__init__(message)
        self.message = message
        self.status_code = status_code
        self.response_data = response_data or {}

    def __repr__(self) -> str:
        parts = [f"message={self.message!r}"]
        if self.status_code is not None:
            parts.append(f"status_code={self.status_code}")
        return f"{type(self).__name__}({', '.join(parts)})"


class AuthError(AlphaInfoError):
    """Invalid or missing API key (HTTP 401).

    Not retryable — the SDK will not retry this. Obtain a valid key at
    https://alphainfo.io/register and pass it via ``api_key=``.
    """
    pass


class RateLimitError(AlphaInfoError):
    """Rate or quota limit exceeded (HTTP 429).

    Attributes:
        retry_after: Seconds to wait before retrying (from the
            ``Retry-After`` response header).

    The SDK auto-retries this up to ``max_retries`` times with backoff
    respecting ``retry_after``; if exhausted, it's raised to the caller.
    """

    def __init__(self, message: str, retry_after: Optional[int] = None, **kwargs: Any):
        super().__init__(message, **kwargs)
        self.retry_after = retry_after

    def __str__(self) -> str:
        if self.retry_after is not None:
            return f"{self.message} (retry after {self.retry_after}s)"
        return self.message

    def __repr__(self) -> str:
        parts = [f"message={self.message!r}"]
        if self.retry_after is not None:
            parts.append(f"retry_after={self.retry_after}")
        if self.status_code is not None:
            parts.append(f"status_code={self.status_code}")
        return f"{type(self).__name__}({', '.join(parts)})"


class ValidationError(AlphaInfoError):
    """Request validation failed (HTTP 400/413).

    Typical causes: signal too short (< 10 samples), invalid
    sampling_rate, NaN/Inf values in signal, baseline length mismatch,
    signal exceeds the plan's max_signal_length, or metadata above 10KB.
    Not retryable — fix the input.
    """
    pass


class NotFoundError(AlphaInfoError):
    """Resource not found (HTTP 404).

    Raised by ``audit_replay(id)`` when the analysis_id does not exist
    or belongs to another API key.
    """
    pass


class APIError(AlphaInfoError):
    """Server-side API error (HTTP 5xx).

    The SDK auto-retries 5xx responses; this is raised only after all
    retries are exhausted.
    """
    pass


class TimeoutError(AlphaInfoError):
    """Request timed out after all retry attempts."""
    pass


class NetworkError(AlphaInfoError):
    """Network-level failure — DNS resolution, TCP, TLS, etc."""
    pass
