"""Sherpa Tabular formatter"""

__version__ = "1.6.205"
