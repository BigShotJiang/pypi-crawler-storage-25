.. include:: ../BADGES.rst

.. _hydrotoolbox_documentation:

hydrotoolbox
============

This is the home page for hydrotoolbox.  hydrotoolbox is a command line program
and Python library for hydrologic analysis.

hydrotoolbox should work with Python 3.10+.

Table of Contents
-----------------
.. toctree::
   :maxdepth: 2

   readme
   function_summary
   command_line
   contributing
   authors
   license

Other Projects
--------------
http://timcera.bitbucket.io
