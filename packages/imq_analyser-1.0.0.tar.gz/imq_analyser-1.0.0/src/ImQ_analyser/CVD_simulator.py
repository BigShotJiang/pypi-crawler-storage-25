"""
Copyright 2026 Liliana Gejdošová

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 language governing permissions and limitations under the License.
"""

import cv2
import matplotlib.image as mpimg
import numpy as np
from colorspacious import cspace_convert


def simulate(img, path):
    """
    method using the colorspacious library to create a simulation of how somebody with deuteranomaly with
    severity score of 0.8 would see the img

    :param path: path where the simulated image will be saved to be used later in gui
    :param img: image to convert to cvd colorspace, expects np array with values between 0-1
    :return: converted cvd image
    """

    sim_path = path.replace('.png', '_simulated.png')

    cvd_space = {"name": "sRGB1+CVD",
                 "cvd_type": "deuteranomaly",
                 "severity": 80}

    img_cvd = np.clip(cspace_convert(img, cvd_space, "sRGB1"), 0, 1)
    try:
        mpimg.imsave(sim_path, img_cvd)
    except (ValueError, PermissionError, OSError):
        return img_cvd

    img = cv2.GaussianBlur(img, (3, 3), 0)
    img_cvd = np.clip(cspace_convert(img, cvd_space, "sRGB1"), 0, 1)

    return img_cvd
