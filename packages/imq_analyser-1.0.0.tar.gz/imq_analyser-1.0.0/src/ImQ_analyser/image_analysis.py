"""
Copyright 2026 Liliana Gejdošová

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 language governing permissions and limitations under the License.
"""

import cv2
import numpy as np
import skimage.exposure
from skimage.color import rgb2lab, deltaE_ciede2000
from .CVD_simulator import simulate
from skimage.io import imread


def analyze(path, report):
    """
    Opens image on given path, and analyzes
    contrast, DPI, color-blindness suitability and exposure of the image.

    :param path: path to the image to analyze
    :param report: dict that will be converted into the final output dataframe
    """

    try:
        img = imread(path)
    except (ValueError, PermissionError):
        # this really shouldn't happen, somebody would have to delete the image in the between the save and analyse
        # call... and in that case the image will just be ignored from the analysis?
        return False

    # ignore alpha channel
    if img.shape[-1] == 4:
        img = img[..., :3]

    if len(img.shape) != 2:
        img_gray = cv2.cvtColor(img, cv2.COLOR_RGB2GRAY)
    else:
        img_gray = img

    hist, _ = np.histogram(img_gray, bins=256, range=(0, 255))
    amount_of_pixels = np.sum(hist)
    normalized = img / 255.0

    if hist[0] + hist[255] == amount_of_pixels:
        report['contrast'] = 'OK'
    else:
        report["contrast"] = contrast_analysis(img_gray)

    report["dpi_status"] = dpi_report(report['dpi_x'], report['dpi_y'])

    if is_drawing(hist, amount_of_pixels):
        report["CVD_analysis"] = color_diff_analysis(normalized, path)
        report["exposure_grayscale"] = "-"

    else:
        report["CVD_analysis"] = '-'
        report["exposure_grayscale"] = exposure_analysis(hist, amount_of_pixels)

    return True


# the 35% threshold is from
# https://pyimagesearch.com/2021/01/25/detecting-low-contrast-images-with-opencv-scikit-image-and-python/, it should
# work well on any type of image (drawing, graph, photo..)
def contrast_analysis(img):
    """
    analyses if an image has low contrast using the skimage.is_low_contrast metric. Image gets flagged as low contrast
    when its range of brightness spans less than 0.35 of its data type’s full range.

    :param img: image to analyse, needs to be grayscale
    :return: OK for good contrast, LOW otherwise
    """
    # img = img / 255.0
    # contrast = np.std(img)
    low_contrast = skimage.exposure.is_low_contrast(img, fraction_threshold=0.35, upper_percentile=99.5,
                                                    lower_percentile=0.05)
    return 'OK' if not low_contrast else 'LOW'


# why grayscale/luma also in https://is.muni.cz/th/ondjg/finalBT.pdf section about
# luma histograms as well as the threshold to determine if clipping is happening
def exposure_analysis(hist, num_of_pixels):
    """
    if more than given threshold percent of pixels are bunched to the
    left/right, then value clipping is happening, and the histogram is over/under-exposed.
    Not the most precise method, but simple and efficient for warnings.

    :param num_of_pixels: number of pixels in analysed image (histogram)
    :param hist: grayscale histogram
    """

    brightness = np.sum(hist[255]) / num_of_pixels * 100
    shadows = np.sum(hist[0]) / num_of_pixels * 100

    thresh_intensity = 10  # more than 10% of values are completely white/black
    # thresh value from https://is.muni.cz/th/ondjg/finalBT.pdf bucket method

    if brightness > thresh_intensity:
        return "OVEREXPOSED"
    elif shadows > thresh_intensity:
        return "UNDEREXPOSED"
    return "OK"


def dpi_report(dpi_x, dpi_y):
    """
    Categorize DPI based on its value, DPI under 250 is low, 250 < DPI < 300 is borderline and higher is okay.
    Thresholds are from Adobe. Selects lower from DPI_x and DPI_y, but they are usually the same
    """

    dpi = min(dpi_x, dpi_y)
    if dpi < 250:
        return 'LOW'
    if 250 < dpi < 300:
        return 'BORDERLINE'
    return 'OK'


def color_diff_analysis(img, path):
    """
    Method to compute the CIEDE2000 delta_e difference image between img, and it's
    simulated color deficiency image. Then compute the ratio of all pixels in the difference image that
    have value above given value to all non-gray (and not blue) pixels of the diff image.

    :param path: path where the cvd simulated image will be saved, for further use in the gui
    :param img: image to be processed

    :return: OK if ratio of pixels that were majorly changed to all non-gray pixels is less than 0.5, WARNING otherwise
    """
    if len(img.shape) == 2:
        # no point to check grayscale image in simulation
        return 'OK'

    sim = rgb2lab(simulate(img, path))

    img = cv2.GaussianBlur(img, (3, 3), 0)  # to deal with cleartype text artifacts
    orig = rgb2lab(img)

    diff = deltaE_ciede2000(sim, orig)

    thresh = 5  # https://skychemi.com/color-difference-formula-delta-e/#how-to-calculate-and-interpret-%CE%B4e says
    # noticeable difference is >3 and very different colors >5

    # remove gray, black, white and blue pixels from the calculation as they don't change for people with red-green
    # colorblindness.. focus on quantifying the change in red and green pixels (or any colors that contain red/green)
    a_channel = orig[..., 1]
    b_channel = orig[..., 2]
    chroma = np.sqrt(a_channel ** 2 + b_channel ** 2)
    has_color = chroma > 5

    # b_channel < -5 -> blue half of the blue-yellow channel and
    # the absolute value of 'b' is greater than the absolute value of 'a'
    # (Meaning the pixel is more blue than it is red or green)
    is_blue = (b_channel < -5) & (np.abs(b_channel) > np.abs(a_channel))

    is_not_gray = has_color & ~is_blue
    not_gray_pixels = np.sum(is_not_gray)

    big_diff_mask = (diff > thresh) & is_not_gray
    big_difference_pixels = np.sum(big_diff_mask)

    total_pixels = img.shape[0] * img.shape[1]

    if not_gray_pixels < (total_pixels * 0.01):
        # almost grayscale
        return 'OK'
    ratio = big_difference_pixels / not_gray_pixels

    return 'WARNING' if ratio > 0.5 else 'OK'


# is turning it grayscale okay? - I'd say so, because I only want the most prominent colors and those are kept in
# grayscale
def is_drawing(hist, amount_of_pixels):
    """
    method to determine if a given image is a photo or a visualization (graph, drawing, diagram..) based on the
    amount of colors the image contains (very low for drawings) and maybe is it contains photon or gaussian noise

    colors that span less than 0.005 of the image are ignored in the calculation

    :param amount_of_pixels: how many pixels the image has
    :param hist: histogram of the given image

    :return: true for visualizations (images with less than 30 prominent colors), false for photos
    """

    # hist_norm = hist / 255
    # peaks, properties = scipy.signal.find_peaks(hist_norm, prominence=0.2, distance=5)
    # print(len(peaks))

    non_zero = 0
    for i, pix_count in enumerate(hist):
        if (pix_count / amount_of_pixels) > 0.005:
            non_zero += 1
        else:
            hist[i] = 0

    return non_zero <= 25


def has_issues(report):
    """
    simple method to go over the dictionary of image properties and their value and
    find if there are any causing trouble, in order to be able to then classify the image.
    Adds a has-issue property for easier classification in the GUI

    :param report: dict of image properties

    :return: true if there is a property that is not labeled 'OK', false if everything is okay
    """

    for img_property in report.keys():
        if img_property == 'dpi_x' or img_property == 'dpi_y' or img_property == 'page' or img_property == 'file name':
            continue
        if report[img_property] != 'OK' and report[img_property] != '-':
            report['has_issue'] = 'yes'
            return True

    report['has_issue'] = 'no'
    return False




