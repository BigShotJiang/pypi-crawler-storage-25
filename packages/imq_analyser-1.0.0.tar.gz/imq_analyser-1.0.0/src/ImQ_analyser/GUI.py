"""
Copyright 2026 Liliana Gejdošová

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 language governing permissions and limitations under the License.
"""

import hashlib
import os.path
import shutil

import pymupdf as fitz
import pandas
from PyQt6.QtGui import QPixmap, QImage
# from PyQt6.QtWebEngineWidgets import QWebEngineView
from PyQt6.QtWidgets import (QMainWindow, QWidget, QVBoxLayout,
                             QHBoxLayout, QLabel, QScrollArea, QSplitter,
                             QFileDialog, QPushButton, QTextEdit, QMessageBox,
                             QProgressBar, QTabWidget, QListWidget, QListWidgetItem, QStackedWidget, QTextBrowser,
                             QDialog, QLayout)
from PyQt6.QtCore import Qt, QThread, pyqtSignal, QUrl
from .image_extraction import image_extraction_and_analysis


# TODO when too many images overlap, the bboxes are disgusting and confusing

class AnalysisWorker(QThread):
    """
    Class created to be able to track progress of the analysis page by page and then display it in a progress bar in
    the GUI
    """

    progress = pyqtSignal(int)  # Signal to update the progress bar
    finished = pyqtSignal(object)  # Signal when done

    def __init__(self, file_path, cache_dir):
        super().__init__()
        self.file_path = file_path
        self.cache_dir = cache_dir

    def run(self):
        res = image_extraction_and_analysis(self.file_path, self.cache_dir, progress_callback=self.progress.emit)
        self.finished.emit(res)


class ImageComparisonDialog(QDialog):
    """
    Simple class used to create a display pop-up window with the original image and its color vision deficiency
    counterpart. Calculates the size of the window based on the screen size and also scales the images to fit the
    window nicely.
    """

    def __init__(self, orig_path, sim_path, parent=None):
        super().__init__(parent)
        self.setWindowTitle("Colorblindness Simulation Comparison")

        # this opens the images
        orig_pixmap = QPixmap(orig_path)
        sim_pixmap = QPixmap(sim_path)

        screen = self.screen().availableGeometry()
        target_h = min(350, int(screen.height() * 0.6))

        aspect_ratio = orig_pixmap.width() / orig_pixmap.height()
        target_w = int(target_h * aspect_ratio)

        while target_w > int(screen.width() * 0.3):
            target_h -= 25
            target_w = int(target_h * aspect_ratio)

        main_layout = QHBoxLayout(self)
        main_layout.setContentsMargins(15, 15, 15, 15)
        main_layout.setSpacing(20)

        self.left_side = self.image_section("Original Image", orig_pixmap, target_w, target_h)
        self.right_side = self.image_section("Simulated (Deuteranomaly)", sim_pixmap, target_w, target_h)

        main_layout.addLayout(self.left_side)
        main_layout.addLayout(self.right_side)

        # TODO it seems to be resizeable on linux
        self.layout().setSizeConstraint(QLayout.SizeConstraint.SetFixedSize)

    @staticmethod
    def image_section(title, pixmap, w, h):
        """
        Method to scale and add the images to the pop-up window.

        :param title: title of the image (original/simulated)
        :param pixmap: pixmap of the image, essentially the image itself
        :param w: width of the image
        :param h: height of the image
        :return: layout of the window with the image added
        """
        layout = QVBoxLayout()

        lbl_title = QLabel(f"<b>{title}</b>")
        lbl_title.setAlignment(Qt.AlignmentFlag.AlignCenter)

        img_label = QLabel()

        scaled_pix = pixmap.scaled(w, h, Qt.AspectRatioMode.KeepAspectRatio,
                                   Qt.TransformationMode.SmoothTransformation)
        img_label.setPixmap(scaled_pix)
        img_label.setFixedSize(w, h)

        layout.addWidget(lbl_title)
        layout.addWidget(img_label)
        return layout


class PDFViewer(QMainWindow):
    """
    The main class encapsulating the whole ImQ-analyser viewer.
    """

    def __init__(self):
        super().__init__()
        self.setWindowTitle("ImQ Analysis Viewer")
        self.resize(1200, 700)

        self.doc = None
        self.current_page_num = 0
        self.scale_factor = 0.5

        self.current_file_path = None
        self.current_cache_dir = None
        self.app_cache_dir = os.path.join(os.path.expanduser("~"), ".ImQ_analyser_cache")
        # os.makedirs(self.app_cache_dir, exist_ok=True)

        self.worker = None
        self.df = None
        self.original_pixmap = None

        # buttons
        self.btn_open = QPushButton("Open PDF")
        self.btn_explain = QPushButton("About")
        # self.btn_help = QPushButton("Help")
        self.btn_zoom_out = QPushButton("-")
        self.btn_zoom_in = QPushButton("+")
        self.btn_prev = QPushButton("Previous")
        self.btn_next = QPushButton("Next")
        self.btn_open_welcome = QPushButton("Open PDF")

        # widgets
        self.progress_bar = QProgressBar()
        self.splitter = QSplitter(Qt.Orientation.Horizontal)
        self.scroll_area = QScrollArea()
        # self.pdf_label = QWebEngineView()
        self.pdf_label = QLabel()
        self.text_preview = QTextBrowser()
        self.tabs = QTabWidget()
        self.tab_details = QWidget()
        self.details_layout = QVBoxLayout(self.tab_details)
        self.tab_index = QWidget()
        self.index_layout = QVBoxLayout(self.tab_index)
        self.issues_list = QListWidget()
        self.main_stack = QStackedWidget()
        self.welcome_widget = QWidget()
        self.lbl_welcome = QLabel()
        self.viewer_widget = QWidget()
        self.balancer = QWidget()
        self.loading_page = QWidget()

        self.loading_label = QLabel(
            "<h1 style='color: #2c3e50; margin-bottom: 5px;'> Analysing Document...</h1>"
            "<p style='color: #7f8c8d; font-size: 14px;'>This might take a few moments depending on the file size.</p>"
        )

        self.init_ui()

    def init_ui(self):
        """
        Method to initialize the whole layout of the viewer, create all the widgets and buttons
        and connect them with methods.

        :return: None
        """

        # MAIN CONTAINER
        central_widget = QWidget()
        self.setCentralWidget(central_widget)

        main_layout = QVBoxLayout(central_widget)

        # TOP BAR
        top_bar = QHBoxLayout()

        self.btn_open.clicked.connect(self.open_pdf)
        top_bar.addWidget(self.btn_open)

        self.btn_explain.clicked.connect(self.show_explanation)
        top_bar.addWidget(self.btn_explain)

        top_bar.addStretch()
        main_layout.addLayout(top_bar)

        # PROGRESS BAR
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setTextVisible(True)
        self.progress_bar.setVisible(False)
        main_layout.addWidget(self.progress_bar)

        # STACKED WIDGET
        main_layout.addWidget(self.main_stack)

        # WELCOME SCREEN
        welcome_layout = QVBoxLayout(self.welcome_widget)
        welcome_layout.setSpacing(15)
        welcome_layout.addStretch()

        self.welcome_widget.setObjectName("WelcomeWidget")
        self.welcome_widget.setStyleSheet("""
            QWidget#WelcomeWidget {
                background-color: qlineargradient(spread:pad, x1:0, y1:0, x2:1, y2:1, 
                                                  stop:0 palette(base), stop:1 palette(window));
            }

            QLabel {
                color: palette(text);
            }
        """)

        self.lbl_welcome = QLabel()
        self.lbl_welcome.setWordWrap(True)

        self.lbl_welcome.setAlignment(Qt.AlignmentFlag.AlignHCenter)

        welcome_text = """
        <div style="font-family: 'Segoe UI', Helvetica, sans-serif;">
            <h1 style="font-size: 80px; font-weight: 500; letter-spacing: 5px; margin-bottom: 18px;">
                Welcome to ImQ Analyser!
            </h1>
            <p style="font-size: 16px; font-weight: 400; margin-top: 0px; margin-bottom: 40px;">
                An automated tool for evaluating image quality and red-green colorblindness accessibility in your PDF 
               documents
            </p>
            <p style="font-size: 15px; margin-bottom: 10px; font-weight:500">
                To start, select a PDF document to analyze
            </p>
        </div>
        """
        self.lbl_welcome.setText(welcome_text)

        welcome_layout.addWidget(self.lbl_welcome)

        self.btn_open_welcome.setFixedSize(200, 45)
        self.btn_open_welcome.setCursor(Qt.CursorShape.PointingHandCursor)

        self.btn_open_welcome.setStyleSheet("""
            QPushButton {
                background-color: #6366f1;
                color: white;
                font-weight: bold;
                font-size: 14px;
                letter-spacing: 1px;
                border-radius: 22px;
                border: none;
            }
            QPushButton:hover {
                background-color: #4f46e5;
            }
            QPushButton:pressed {
                background-color: #4338ca;
            }
        """)
        self.btn_open_welcome.clicked.connect(self.open_pdf)

        welcome_layout.addWidget(self.btn_open_welcome, alignment=Qt.AlignmentFlag.AlignHCenter)

        welcome_layout.addStretch()

        self.main_stack.addWidget(self.welcome_widget)

        # PDF VIEWER
        viewer_layout = QVBoxLayout(self.viewer_widget)

        # LEFT SIDE
        left_widget = QWidget()
        left_layout = QVBoxLayout(left_widget)
        left_layout.setContentsMargins(0, 0, 0, 0)

        # self.pdf_label = QWebEngineView(left_widget)
        # self.pdf_label.setHtml("<html><body style='background-color: white;'></body></html>")
        # # self.pdf_label.setStyleSheet("background-color: white;")
        # # self.scroll_area.setStyleSheet("background-color: #b8b8b8;")
        # # self.scroll_area.setWidgetResizable(False)
        # # self.scroll_area.setAlignment(Qt.AlignmentFlag.AlignCenter)
        # # self.scroll_area.setWidget(self.pdf_label)
        # # left_layout.addWidget(self.scroll_area)
        # left_layout.addWidget(self.pdf_label)
        # left_layout.setStretchFactor(self.pdf_label, 1)

        self.pdf_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.pdf_label.setStyleSheet("background-color: gray;")

        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setAlignment(Qt.AlignmentFlag.AlignCenter)
        self.scroll_area.setWidget(self.pdf_label)
        self.scroll_area.setStyleSheet("background-color: #b8b8b8;")

        left_layout.addWidget(self.scroll_area)

        # BOTTOM BAR
        controls_layout = QHBoxLayout()
        controls_layout.setContentsMargins(0, 0, 0, 0)

        # Zoom Buttons
        zoom_layout = QHBoxLayout()
        self.btn_zoom_out.setFixedWidth(40)
        self.btn_zoom_out.clicked.connect(self.zoom_out)
        zoom_layout.addWidget(self.btn_zoom_out)

        self.btn_zoom_in.setFixedWidth(40)
        self.btn_zoom_in.clicked.connect(self.zoom_in)
        zoom_layout.addWidget(self.btn_zoom_in)

        controls_layout.addLayout(zoom_layout)

        controls_layout.addStretch()

        # Navigation Buttons
        self.btn_prev.clicked.connect(self.prev_page)
        controls_layout.addWidget(self.btn_prev)

        self.btn_next.clicked.connect(self.next_page)
        controls_layout.addWidget(self.btn_next)

        controls_layout.addStretch()

        # balancer to center the next/prev buttons automatically
        self.balancer.setFixedWidth(68)
        controls_layout.addWidget(self.balancer)

        left_layout.addLayout(controls_layout)

        self.splitter.addWidget(left_widget)

        # RIGHT SIDE
        self.details_layout.setContentsMargins(0, 0, 0, 0)

        self.details_splitter = QSplitter(Qt.Orientation.Vertical)

        self.text_preview.setReadOnly(True)
        self.text_preview.setFrameShape(QTextEdit.Shape.NoFrame)
        self.text_preview.anchorClicked.connect(self.handle_text_link)
        self.details_splitter.addWidget(self.text_preview)

        self.fixes_preview = QTextBrowser()
        self.fixes_preview.setReadOnly(True)
        self.fixes_preview.setFrameShape(QTextEdit.Shape.NoFrame)
        self.details_splitter.addWidget(self.fixes_preview)

        self.details_splitter.setSizes([700, 300])

        self.details_layout.addWidget(self.details_splitter)
        self.tabs.addTab(self.tab_details, "Current Page Details")

        self.index_layout.setContentsMargins(0, 0, 0, 0)
        self.issues_list.itemClicked.connect(self.on_issue_clicked)
        self.index_layout.addWidget(self.issues_list)
        self.tabs.addTab(self.tab_index, "Issues Index")

        right_container = QWidget()
        right_layout = QVBoxLayout(right_container)
        right_layout.setContentsMargins(0, 0, 0, 0)

        right_layout.addWidget(self.tabs)

        dummy_space = QWidget()
        dummy_space.setFixedHeight(25)
        right_layout.addWidget(dummy_space)

        self.splitter.addWidget(right_container)
        self.splitter.setSizes([700, 300])

        viewer_layout.addWidget(self.splitter)

        font = self.btn_zoom_in.font()
        font.setBold(True)

        self.btn_zoom_out.setFont(font)
        self.btn_zoom_in.setFont(font)

        self.btn_prev.setFont(font)
        self.btn_next.setFont(font)

        self.btn_prev.setEnabled(False)
        self.btn_next.setEnabled(False)
        self.btn_zoom_in.setEnabled(False)
        self.btn_zoom_out.setEnabled(False)

        self.main_stack.addWidget(self.viewer_widget)

        # LOADING SCREEN
        loading_layout = QVBoxLayout(self.loading_page)
        loading_layout.setAlignment(Qt.AlignmentFlag.AlignCenter)

        self.loading_label.setAlignment(Qt.AlignmentFlag.AlignCenter)
        loading_layout.addWidget(self.loading_label)

        self.main_stack.addWidget(self.loading_page)

        self.main_stack.setCurrentIndex(0)  # Show Welcome Screen

    @staticmethod
    def get_file_hash(filepath):
        """Generates a unique MD5 fingerprint for the file."""
        hasher = hashlib.md5()
        with open(filepath, 'rb') as f:
            buf = f.read(65536)
            while len(buf) > 0:
                hasher.update(buf)
                buf = f.read(65536)
        return hasher.hexdigest()

    def open_pdf(self):
        """
        Method linked with the 'Open PDF' button. Either loads a pdf from a selected file, creates a cache folder for it
        and initializes the analysis, or checks the cache if the folder already exists and opens the analysed
        pdf from there.

        :return: None
        """
        self.issues_list.clear()

        file_path, _ = QFileDialog.getOpenFileName(self, "Open PDF", "", "PDF Files (*.pdf)")
        if file_path:
            self.current_file_path = file_path
            self.text_preview.clear()
            self.btn_open.setEnabled(False)

            try:
                file_hash = self.get_file_hash(file_path)
                self.current_cache_dir = os.path.join(self.app_cache_dir, file_hash)
            except Exception:
                self.analysis_finished((False, "Unable to open selected pdf."))

            csv_path = os.path.join(self.current_cache_dir, "output.csv")

            if os.path.exists(csv_path):
                path = os.path.join(self.current_cache_dir, 'annotated.pdf')
                self.analysis_finished((True, path))

            else:
                try:
                    os.makedirs(self.app_cache_dir, exist_ok=True)
                    os.makedirs(self.current_cache_dir, exist_ok=True)
                except (PermissionError, OSError):
                    QMessageBox.critical(self, "Permission Error",
                                         f"Cannot create cache at {self.app_cache_dir}. Please check folder "
                                         f"permissions.")
                    return

                self.progress_bar.setValue(0)
                self.progress_bar.setVisible(True)

                self.main_stack.setCurrentIndex(2)
                self.worker = AnalysisWorker(self.current_file_path, self.current_cache_dir)
                self.worker.progress.connect(self.update_progress)
                self.worker.finished.connect(self.analysis_finished)
                self.worker.start()

    def update_progress(self, val):
        """
        Method for tracking analysis progress page by page, updates the progress bar.

        :param val: current percentage of analysed pages in the document
        :return: None
        """

        self.progress_bar.setValue(val)

    def fit_to_width(self):
        """
        Method used to scale the pdf to the width of the pdf viewer app on screen, when the doc is first opened.

        :return: None
        """

        if not self.original_pixmap:
            return

        scroll_width = self.scroll_area.viewport().width() - 5
        pixmap_width = self.original_pixmap.width()

        if pixmap_width > 0:
            self.scale_factor = scroll_width / pixmap_width
            self.apply_zoom()

    def analysis_finished(self, analysis_res):
        """
        Like a controller method for when the analysis is finished. Tries to open the analysed pdf file as well as the
        analysis data from the respective dataframe and handles any errors that occur during this process (also shows a
        pop-up error message to the user). If there is no error, it fills the widgets with data from the analysis.

        :param analysis_res: tuple (status, path), status is a boolean value, if true, then the analysis run
        successfully and path is a path to the analysis data in the cache folder. Status is false if an error
        occurred during the analysis
        :return: None
        """

        # hide progress bar and enable open pdf button
        self.progress_bar.setVisible(False)
        self.btn_open.setEnabled(True)

        status, data = analysis_res

        self.current_file_path = data
        if not status:
            QMessageBox.information(
                self,
                "Error",
                data
            )
            self.main_stack.setCurrentIndex(0)

            if self.doc is not None:
                self.doc.close()

            if os.path.exists(self.app_cache_dir):
                try:
                    shutil.rmtree(self.app_cache_dir)
                except PermissionError:
                    QMessageBox.warning(self, "Warning", "Could not clear cache. Some files are still in use.")
            return

        try:
            self.doc = fitz.open(self.current_file_path)
        except (fitz.FileNotFoundError, FileNotFoundError):
            QMessageBox.information(
                self,
                "Error",
                "There has been a problem with opening the analysed PDF document! Please try restarting the app and "
                "select 'NO' when asked to keep analysis data."
            )
            self.main_stack.setCurrentIndex(0)

            if os.path.exists(self.app_cache_dir):
                try:
                    shutil.rmtree(self.app_cache_dir)
                except PermissionError:
                    QMessageBox.warning(self, "Warning", "Could not clear cache. Some files are still in use.")
            return

        self.current_page_num = 0

        df_path = os.path.join(self.current_cache_dir, "output.csv")

        try:
            self.df = pandas.read_csv(df_path)
        except TypeError:
            self.df = None

        self.populate_issue_index()

        self.show_page(self.current_page_num)
        self.fit_to_width()
        self.main_stack.setCurrentIndex(1)
        self.update_buttons()

    def show_page(self, page_num):
        """
        Method to render a page of the analysed pdf as a high resolution image, scale it and display it in the
        widget.

        :param page_num: number of page to be displayed from the pdf
        :return: None
        """

        if not self.doc:
            return
        self.current_page_num = page_num
        page = self.doc.load_page(page_num)

        zoom_matrix = fitz.Matrix(3.0, 3.0)
        pix = page.get_pixmap(matrix=zoom_matrix)

        q_img = QImage(pix.samples, pix.width, pix.height, pix.stride, QImage.Format.Format_RGB888)
        self.original_pixmap = QPixmap.fromImage(q_img)

        self.apply_zoom()
        self.update_page_info()

    def apply_zoom(self):
        """
        Method for scaling the displayed pdf page.

        :return: None
        """

        if self.original_pixmap:
            scaled_pix = self.original_pixmap.scaled(
                self.original_pixmap.size() * self.scale_factor,
                Qt.AspectRatioMode.KeepAspectRatio,
                Qt.TransformationMode.SmoothTransformation
            )
            self.pdf_label.setPixmap(scaled_pix)

    def update_page_info(self):
        """
        Method used to fill the info widget with information about images on the currently displayed pdf page. The
        method takes the data from the analysis dataframe and formats them. THis method also handles displaying the
        information in the recommendation window for each page.

        :return: None
        """

        current_page_idx = self.current_page_num + 1
        no_issue_images = True

        page_issues = {
            "low_dpi": [],
            "cvd_warning": [],
            "contrast": [],
            "exposure": [],
            "visibility": []
        }

        try:
            page_rows = self.df[self.df['page'] == current_page_idx]
        except (TypeError, KeyError):
            page_rows = None

        html = f"<h3 style='color:#333; font-size: 13.5pt;'>Page {current_page_idx} Analysis</h3>"

        if page_rows is None or len(page_rows) == 0:
            pass
        else:
            count = 1
            for index, row in page_rows.iterrows():
                if row['has_issue'] == 'no' and row['CVD_analysis'] == '-':
                    continue
                else:
                    no_issue_images = False

                def get_status_color(value):
                    if value != "OK" and value != '-':
                        return "red"
                    return "black"

                vis_color = get_status_color(row['visibility'])
                contrast_color = get_status_color(row['contrast'])
                cvd_color = get_status_color(row['CVD_analysis'])
                exposure_color = get_status_color(row['exposure_grayscale'])

                dpi = min(row['dpi_x'], row['dpi_y'])
                dpi_status = row['dpi_status'].lower()
                dpi_color = "red" if dpi_status == "low" else ('orange' if dpi_status == "borderline" else "black")

                if dpi_status != 'ok':
                    page_issues["low_dpi"].append(count)
                if row['visibility'] != "OK":
                    page_issues["visibility"].append(count)
                if row['contrast'] == 'LOW':
                    page_issues["contrast"].append(count)
                if row['exposure_grayscale'] not in ["OK", "-"]:
                    page_issues["exposure"].append(count)
                if row['CVD_analysis'] == 'WARNING':
                    page_issues["cvd_warning"].append(count)

                cvd_link = ""
                if row['CVD_analysis'] != '-':
                    orig_img_path = os.path.join(self.current_cache_dir, row['file name'])
                    sim_img_path = os.path.join(self.current_cache_dir,
                                                row['file name'].replace('.png', '_simulated.png'))

                    cvd_link = f'<a href="sim:{orig_img_path}|{sim_img_path}" ' \
                               f'style="text-decoration: none; color: #0055ff;"><b>\u2315</b></a>'

                html += f"""
                        <div style="
                            border: 1px solid #ddd; 
                            border-radius: 5px; 
                            padding: 8px; 
                            margin-bottom: 10px; 
                            background-color: #f9f9f9;">

                            <div style="font-weight:bold; color:#2c3e50; margin-bottom:6px; 
                                                                border-bottom: 1px solid #eee; padding-bottom: 10px;
                                                                font-size: 10.5pt;">
                                Image #{count}
                            </div>

                            <table style="width:100%; font-size: 10.5pt;">
                                <tr>
                                    <td><b>Visibility:</b></td>
                                    <td style="color:{vis_color};">{row['visibility'].lower()}</td>
                                </tr>
                                <tr>
                            <td><b>Resolution:</b></td> 
                            <td>
                                <span style="color:{dpi_color};">
                                    {dpi_status} ({dpi} DPI)
                                </span>
                            </td>
                        </tr>
                                <tr>
                                    <td><b>Contrast:</b></td>
                                    <td style="color:{contrast_color}">{row['contrast'].lower()}</td>
                                </tr>
                                <tr>
                                    <td><b>Exposure:</b></td>
                                    <td style="color:{exposure_color}">{row['exposure_grayscale'].lower()}</td>
                                </tr>
                                <tr>
                                    <td><b>CVD Analysis:</b></td>
                                    <td style="color:{cvd_color};">{row['CVD_analysis'].lower()} {cvd_link}<br>
                                </tr>
                            </table>
                        </div>
                        """
                count += 1

        if no_issue_images:
            html += "<p style='color:gray;'><i>There are no problematic images on this page.</i></p>"

        self.text_preview.setHtml(html)

        fixes_html = "<div><b style='color: #333; font-size: 13pt;'>Recommendations</b><br><br>"

        if not any(page_issues.values()):
            fixes_html += "<span style='color: #5cb85c;'><b>No issues found :)</b><br.</span>"
        else:
            if page_issues["low_dpi"]:
                fixes_html += "<b style='color: #333; font-size: 11.5pt;'>Low Resolution:</b><br>"
                fixes_html += "<span style='font-size: 10.5pt;'>To achieve high resolution, recommended value of DPI " \
                              "is over 300.</span><br><br>"

            if page_issues["cvd_warning"]:
                fixes_html += "<b style='color: #333; font-size: 12pt;'>Color Accessibility Warning:</b><br>"
                fixes_html += "<span style='font-size: 10.5pt;'>[click on the <b>\u2315</b> to compare the image to " \
                              "its CVD simulation]<br>Color pixels changed significantly in simulation, " \
                              "make sure the changes do not " \
                              "influence the readability of the image. If it is your graphic, consider changing the " \
                              "color palette or adding patterns or labels to help differentiate between differently " \
                              "colored areas.</span><br><br>"

            if page_issues["contrast"]:
                fixes_html += "<b style='color: #333; font-size: 12pt;'>Low Contrast:</b><br>"
                fixes_html += "<span style='font-size: 10.5pt;'>If contrast is low, colors blend together, and the " \
                              "image can look dull. Choose different colors for your graphic or try to increase " \
                              "contrast in a photo editor.</span><br><br>"

            if page_issues["exposure"]:
                fixes_html += "<b style='color: #333; font-size: 12pt;'>Exposure:</b><br>"
                fixes_html += "<span style='font-size: 10.5pt;'>If the image is overexposed, it contains too many " \
                              "white pixels, and is too bright. If it is underexposed, it is too dark. If " \
                              "details are getting lost, try adjusting brightness of the image in a photo " \
                              "editor.</span><br><br>"

            if page_issues["visibility"]:
                fixes_html += "<b style='color: #333; font-size: 12pt;'>Visibility Issues:</b><br>"
                fixes_html += "<span style='font-size: 10.5pt;'>The image is being cut off by the edge of the PDF " \
                              "page. Make sure the image is " \
                              "fully within the page margin or crop it accordingly.</span><br><br>"

            fixes_html += "</div>"

        self.fixes_preview.setHtml(fixes_html)

    def handle_text_link(self, url: QUrl):
        """
        Method for handling actions that happen after clicking on a link in the application. So far the only link is
        the magnifying glass icon that then displays the image + CVD simulation pop-up, but can be modified to handle
        other links as well.

        :param url: The link that was clicked
        :return: None
        """

        if url.scheme() == "sim":
            paths_string = url.path()
            paths = paths_string.split("|")

            if len(paths) == 2:
                orig_path = paths[0]
                sim_path = paths[1]

                try:
                    dialog = ImageComparisonDialog(orig_path, sim_path, self)
                    dialog.exec()
                except (ValueError, PermissionError, OSError):
                    QMessageBox.warning(self, "Error",
                                        f"Could not find image files at:\n{orig_path}\nor\n{sim_path}")

        self.update_page_info()

    def prev_page(self):
        """
        Method for navigating the displayed pdf.
        """
        if self.doc and self.current_page_num > 0:
            self.current_page_num -= 1
            self.show_page(self.current_page_num)
            self.update_buttons()

    def next_page(self):
        """
        Method for navigating the displayed pdf.
        """

        if self.doc and self.current_page_num < len(self.doc) - 1:
            self.current_page_num += 1
            self.show_page(self.current_page_num)
            self.update_buttons()

    def update_buttons(self):
        """
        Method for updating (setting them as enabled) all buttons in the pdf
        """
        if not self.doc:
            return
        self.btn_prev.setEnabled(self.current_page_num > 0)
        self.btn_next.setEnabled(self.current_page_num < len(self.doc) - 1)
        self.btn_zoom_in.setEnabled(True)
        self.btn_zoom_out.setEnabled(True)

    def zoom_in(self):
        """
        Method for zooming in the displayed pdf.
        """
        if self.doc:
            self.scale_factor *= 1.1
            self.apply_zoom()

    def zoom_out(self):
        """
        Method for zooming out the displayed pdf.
        """
        if self.doc:
            self.scale_factor *= 0.9
            self.apply_zoom()

    # TODO better describe what the cvd warning means
    def show_explanation(self):
        """
        Method linked to the 'About' button, when the button is clicked, an information pop-up is displayed. It contains
        both technical information about the app and detailed information about each metric that is being
        computed during the analysis.
        """

        terms = """
        <li>Switch between 'Page Details' and 'Issue Index' tabs to see either all issue details for current page
            or index of all pages with problematic images.</li>
            <li></li>
            <b>PDF Viewer Controls:</b>
            <li><b>Open PDF:</b> Click top-left to load a pdf file.</li>
            <li><b>Navigation:</b> Use Prev/Next buttons below the PDF.</li>
            <li><b>Zooming:</b> Use +/- buttons to zoom in and out.</li>
            <li><b>Split View:</b> Drag the divider between PDF and Info panel.</li>
        <br>
        <li><b>Analysed metrics details:</b></li>
        <li><b>Visibility: </b>Checks if the image is completely on the page. It will be marked "Partially visible" or 
        "Not visible" if it is cut off by the edges of the PDF document.</li><br>
        <li><b>Overlapping other images: </b>Detects if two images are stacked on top of each other. The area where 
        they overlap will be highlighted with a green rectangle.</li><br>
        <li><b>Resolution:</b> Rates the resolution (quality of the image) based on its DPI (DPI - Dots Per Inch 
        measures how sharp an image will look when physically printed):
                <ul style="margin-top: 4px; margin-bottom: 4px;">
                    <li><b>Low</b> (Under 250 DPI): The image may look blurry or pixelated when printed.</li>
                    <li><b>Low</b> (Between 250 and 300 DPI): In some cases the image can still look blurry, but 
                    sometimes the resolution can be acceptable.</li>
                    <li><b>Ok</b> (Over 300 DPI): Standard, clear quality for printing.</li>
                </ul>
        </li><br>
        <li><b>Contrast: </b>Contrast determines the difference in brightness between foreground and background 
        colors of the image. If contrast is low, colors blend together, and the image can look dull.</li><br>
        <li><b>Exposure: </b>Checks the overall brightness of a photograph. "Overexposed" means the picture is
        too bright, while "underexposed" means it is too dark. Digitally created images (such as graphs, schematics,
         and so on) will not have their exposure evaluated.</li><br>
        <li><b>Color Vision Deficiency (color-blindness) Analysis:</b> Checks if your image is accessible to people with
         color vision deficiencies. A "Warning" means the test detected a major change in the image's core colors 
         (ignoring black, white, and gray pixels, as they appear the same to all viewers), which could make it hard to 
         read. Because color perception varies, you can click the <b>[\u2315]</b> icon to see a simulation of exactly ho
         w the image appears to someone with deuteranomaly (red-green colorblindness. Note: This check is only performed 
         on digital graphics like charts, graphs, and schematics.</i></li><br>
         <li>The analysis results are automated suggestions to help you catch potential issues like low DPI, poor 
        contrast, or colorblindness accessibility.</li></br>
        """

        dialog = QDialog(self)
        dialog.setWindowTitle("Explanation")

        dialog.resize(550, 350)

        layout = QVBoxLayout(dialog)

        text_browser = QTextBrowser()
        text_browser.setHtml(terms)
        layout.addWidget(text_browser)

        dialog.exec()

    def populate_issue_index(self):
        """
        Method filling the issue index widget with data based on the analysis data from a dataframe. Verifies if the
        page contains problematic images and if yes it adds the page number to the issue index. Each element on the
        list is clickable and connected to the page.

        :return: None
        """

        self.issues_list.setStyleSheet("""
            QListWidget::item {
                padding-top: 10px;
                padding-bottom: 10pt;
                padding-left: 15px;
            }
        """)
        self.issues_list.clear()

        try:
            pages = self.df['page'].unique()
        except (TypeError, KeyError):
            msg = QMessageBox(self)
            msg.setWindowTitle("Analysis Complete")
            msg.setText("No issues found!")
            msg.setInformativeText("The document has no problematic images")
            msg.exec()
            pages = []

        issues_found_count = 0

        for page_num in pages:
            # Get all rows for this page
            page_rows = self.df[self.df['page'] == page_num]

            if (page_rows['has_issue'] == 'yes').any():
                label_text = f"Page {page_num}"

                item = QListWidgetItem(label_text)
                item.setData(Qt.ItemDataRole.UserRole, int(page_num) - 1)
                item.setForeground(Qt.GlobalColor.red)

                self.issues_list.addItem(item)
                issues_found_count += 1

        self.tabs.setTabText(1, f"Issues Index")

        # if issues exist, auto-switch to the index tab so the user sees them immediately
        if issues_found_count > 0:
            self.tabs.setCurrentIndex(1)
        else:
            # print no issues found in the issue index
            item = QListWidgetItem("No issues found :)")
            font = item.font()
            font.setBold(True)
            item.setFont(font)
            item.setForeground(Qt.GlobalColor.green)
            item.setFlags(Qt.ItemFlag.NoItemFlags)  # non-clickable

            self.issues_list.addItem(item)

    def on_issue_clicked(self, item):
        """
        Method dealing with what happens when an element of the issue index is clicked. When the index is clicked, the
        user gets transported to said problematic page.

        :param item: issue index item/element
        :return: None
        """

        page_idx = item.data(Qt.ItemDataRole.UserRole)

        if page_idx is None:
            return

        self.current_page_num = page_idx
        self.show_page(self.current_page_num)
        self.update_buttons()

        # switch back to the details tab
        self.tabs.setCurrentIndex(0)

    def closeEvent(self, event):
        """
        Method used to handle closing of the app and clearing the apps cache. The method first asks the user if they
        want the cache cleared, the default is 'no'.

        :param event: closing the app event
        :return: None
        """

        if hasattr(self, 'app_cache_dir') and os.path.exists(self.app_cache_dir) and os.listdir(self.app_cache_dir):
            reply = QMessageBox.question(
                self,
                "Clear Cache?",
                "Keep analysis data so previously analyzed PDFs load instantly next time?\n\n",
                QMessageBox.StandardButton.Yes | QMessageBox.StandardButton.No,
                QMessageBox.StandardButton.Yes
            )

            if reply == QMessageBox.StandardButton.No:
                if self.doc is not None:
                    self.doc.close()

                try:
                    shutil.rmtree(self.app_cache_dir)
                except PermissionError:
                    QMessageBox.warning(self, "Warning", "Could not clear cache. Some files are still in use.")

        event.accept()
