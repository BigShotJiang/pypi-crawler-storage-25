"""
Copyright 2026 Liliana Gejdošová

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 language governing permissions and limitations under the License.
"""

import math
import os.path

import pandas
import pymupdf
from .Utils import format_file_name, get_file_name_from_path
from .image_analysis import analyze, has_issues


def image_extraction_and_analysis(path, output_path, progress_callback=None):
    """
    Method used to extract all images from a pdf file and to save them as .png
    on specified path, run the analysis and create a .csv file with data about extracted images

    :param progress_callback: calculates progress of the extraction and analysis for the
    GUI based on what percentage of pages was already processed
    :param path: pdf file to be opened
    :param output_path: path where extracted images should be saved
    :return: path to a .csv file with the image analysis information
    """

    try:
        doc = pymupdf.open(path)

        if not doc.is_pdf:
            raise ValueError("The file is not a valid PDF document.")
    except ValueError:
        # couldn't load pdf
        return False, "Failed to load selected pdf."

    image_number = 0

    pdf_name = get_file_name_from_path(path)

    image_data = []
    image_reports = []

    intersections = {}

    for page_index in range(len(doc)):
        page = doc[page_index]
        image_list = page.get_image_info(xrefs=True)
        error_count = 0
        for image_index, img in enumerate(image_list, start=1):
            report = dict()

            xref = img["xref"]
            try:
                bbox = img["bbox"]
                if xref == 0:
                    pix = page.get_pixmap(clip=bbox)
                else:
                    pix = pymupdf.Pixmap(doc, xref)

                    # clip transparent images from pdf page with their background
                    if pix.alpha or img['has-mask']:
                        pix = page.get_pixmap(matrix=pymupdf.Matrix(3.0, 3.0), clip=bbox)

            except ValueError:
                continue

            formatted_file_name = format_file_name(pdf_name, image_number)

            # edit data for the dataframe
            img["type"] = "raster"

            # check if image is fully/partially visible
            page_bbox = page.rect
            is_visible = page_bbox.intersects(img['bbox'])
            is_partially_visible = is_visible and not (page_bbox.contains(img['bbox']))
            report["visibility"] = "partially visible" if is_partially_visible else ("OK" if is_visible
                                                                                     else "not visible")

            # dpi using the transform matrix to effectively calculate it
            # even for rotated images
            a, b, c, d, e, f = img["transform"]
            width_points = math.hypot(a, c)
            height_points = math.hypot(b, d)

            report["dpi_x"] = int(72 * img["width"] / width_points)
            report["dpi_y"] = int(72 * img["height"] / height_points)

            # find all regions where other images overlap img
            intersection = calculate_overlap(img, image_list)
            report["overlaying_other_images"] = 'NOT OK' if intersection else 'OK'

            if intersection:
                if intersections.get(page_index) is None:
                    intersections[page_index] = intersection
                else:
                    intersections[page_index].update(intersection)

            report["page"] = page_index + 1
            report["file name"] = formatted_file_name

            # end of dataframe processing

            # pix.n - number of color channels
            # if pix.n - pix.alpha > 3 ~> has more than three color channels, is CMYK and needs to be converted
            # into RGB as png does not support CMYK
            # it does keep the alpha channel
            if pix.n - pix.alpha > 3:
                pix = pymupdf.Pixmap(pymupdf.csRGB, pix)

            image_name = os.path.join(output_path, formatted_file_name)

            try:
                pix.save(image_name)
            except (ValueError, PermissionError, OSError):
                # can this even happen? like they are from the pdf and not manipulated with, the format should be
                # correct and also being saved into a folder I created so i should have permission
                # anyways the image will be excluded from the final result
                return False, "Failed to save extracted images."

            analysis_complete = analyze(image_name, report)

            if not analysis_complete:
                # if for some reason somebody deleted the image in between the save and analyse call, it will be ignored
                # from the final report
                continue
            else:
                image_data.append(img)

            issues = has_issues(report)
            if issues or report["CVD_analysis"] != '-':
                error_count += 1

                # highlight images that have any issues
                # and number them, so they are identifiable in the GUI

                visible_rect = page.rect & img['bbox']
                bg_rect = pymupdf.Rect(visible_rect[0], visible_rect[1], visible_rect[0] + 10, visible_rect[1] + 12)
                if not issues:
                    page.draw_rect(bg_rect, color=(1, 1, 1),
                                   fill=(1, 1, 1), width=1)

                    page.insert_text(
                        point=pymupdf.Point(visible_rect[0] + 2, visible_rect[1] + 10),
                        text=str(error_count),
                        fontsize=10,
                        color=(1, 0, 0)
                    )
                elif not visible_rect.is_empty and issues:
                    page.draw_rect(bg_rect, color=(1, 1, 1),
                                   fill=(1, 1, 1), width=1)  # rect under the number, so it is visible

                    page.insert_text(
                        point=pymupdf.Point(visible_rect[0] + 2, visible_rect[1] + 10),
                        text=str(error_count),
                        fontsize=10,
                        color=(1, 0, 0)
                    )  # img number on page

                    page.draw_rect(img['bbox'], color=(1, 0, 0), width=2)  # red border

            image_reports.append(report)

            image_number += 1

        if intersections.get(page_index) is not None:
            for intersection_box in intersections[page_index]:
                page.draw_rect(intersection_box, color=(0, 1, 0), width=2)

        # for progress bar in gui, calculates progress based on how many pages were processed
        progress_callback(int(((page_index + 1) / len(doc)) * 100))

    final_path_beginning = output_path

    try:
        df_name = os.path.join(final_path_beginning, pdf_name + ".csv")
        df = pandas.DataFrame.from_dict(image_data)
        df.to_csv(df_name)

        reports = pandas.DataFrame.from_dict(image_reports)
        reports.to_csv(os.path.join(final_path_beginning, "output.csv"))

        doc.save(os.path.join(final_path_beginning, "annotated.pdf"))
        doc.close()
    except (ValueError, PermissionError, OSError):
        return False, "Failed to save data required to display the analysed pdf."

    return True, os.path.join(final_path_beginning, "annotated.pdf")


def calculate_overlap(img, other_images_on_page):
    """
    calculate bboxes of all the areas where an image overlaps with
    other images on the same page.

    :param img: dict of image info from page.get_image_info()
    :param other_images_on_page

    :return: set of bboxes
    """

    intersection_bboxes = set()
    bbox1_x0, bbox1_y0, bbox1_x1, bbox1_y1 = img['bbox']

    for i in other_images_on_page:
        if i['number'] == img['number']:
            continue
        bbox2_x0, bbox2_y0, bbox2_x1, bbox2_y1 = i['bbox']

        if img['bbox'] == i['bbox']:
            # overlaps completely
            continue

        if (bbox1_x0 <= bbox2_x1 and
                bbox1_x1 >= bbox2_x0 and
                bbox1_y0 <= bbox2_y1 and
                bbox1_y1 >= bbox2_y0):

            x0 = max(bbox1_x0, bbox2_x0)
            y0 = max(bbox1_y0, bbox2_y0)
            x1 = min(bbox1_x1, bbox2_x1)
            y1 = min(bbox1_y1, bbox2_y1)

            if (x0, y0, x1, y1) == i["bbox"]:
                # overlaps completely
                pass

            intersection_bboxes.add((x0, y0, x1, y1))

    return intersection_bboxes
