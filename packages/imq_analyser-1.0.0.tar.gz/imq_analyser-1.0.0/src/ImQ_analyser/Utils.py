"""
Copyright 2026 Liliana Gejdošová

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 language governing permissions and limitations under the License.
"""

import os


def format_file_name(pdf_name, image_number):
    """
    helper method used to create uniform ordered names for images

    :param pdf_name: name of the pdf extracted from the path
    :param image_number: image order in the pdf
    :return: file name formatted as 'pdf-name_[0-9][0-9][0-9].png'
    """
    image_number_string = str(image_number)

    if image_number < 10:
        formatted_image_number = '00' + image_number_string
    elif 10 < image_number < 100:
        formatted_image_number = '0' + image_number_string
    else:
        formatted_image_number = image_number_string

    return pdf_name + '_' + formatted_image_number + '.png'


def get_file_name_from_path(path):
    """
    helper method for extracting file name from path

    :param path: path from with file name should be extracted
    :return: file name
    """
    filename = os.path.basename(path)
    name, _ = os.path.splitext(filename)
    return name
