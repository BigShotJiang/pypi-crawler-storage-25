"""
Copyright 2026 Liliana Gejdošová

Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except in compliance with the
License. You may obtain a copy of the License at http://www.apache.org/licenses/LICENSE-2.0

Unless required by applicable law or agreed to in writing, software distributed under the License is distributed on an
"AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the License for the specific
 language governing permissions and limitations under the License.
"""

from .GUI import PDFViewer
from PyQt6.QtWidgets import QApplication
import sys


def main():
    app = QApplication(sys.argv)

    # because linux renders pixel in different size than windows
    if sys.platform == "linux":
        base_font = app.font()
        base_font.setPointSize(12)
        app.setFont(base_font)

    viewer = PDFViewer()
    viewer.show()
    sys.exit(app.exec())


if __name__ == '__main__':
    main()
