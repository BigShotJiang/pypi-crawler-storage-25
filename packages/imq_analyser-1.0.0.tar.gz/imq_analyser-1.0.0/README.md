# ImQ-Analyser

**ImQ-Analyser** is an automated desktop application designed to evaluate the visual quality and accessibility of raster images embedded within PDF documents. Developed as part of a Bachelor's Thesis at Masaryk University.

## Installation
You can install the analyzer directly from PyPI:
```bash
pip install imq-analyser
```

## Usage
1. Run the application: 
``` bash 
imq-analyser
```
2. Open a PDF file using the file dialog.
3. Navigate through pages and review highlighted issues.

## Detailed Description

1. **Opening a Document:** Click the **Open PDF** button in the top-left corner and select your file.

2. **The Analysis Pipeline:** Once a file is loaded, the application automatically processes each page in the background.
Each image is analysed for its resolution, contrast, exposure and if it is accessible for people with color vision 
deficiencies.

3. **Reviewing the Report:** The application provides two methods for data review:
   * **Current Page Details:** Displays specific metrics for every image on the active page.
   * **Issues Index:** A filtered view that lists only the pages containing critical quality or accessibility warnings, 
   allowing for navigation through large documents.

4. **CVD Comparison:** For any image flagged with a **Color Vision Deficiency (CVD)** warning, a magnifying glass icon 
(🔍) will appear in the report. Clicking this opens a dedicated window providing a side-by-side comparison between the 
original image and a **Deuteranomaly simulation**. This allows the user to visually verify if 
structural information (like legend colors or graph lines) remains distinguishable.

All warnings serve only as recommendations and should be analysed by the user based on the context of the document.