import time
from rich.console import Console
from rich.table import Table
from rich.panel import Panel
from rich.progress import Progress, SpinnerColumn, BarColumn, TextColumn, TimeElapsedColumn
from rich.live import Live
from rich.text import Text
from rich import box
from rich.align import Align

console = Console()


def print_header(file_name: str, server_url: str):
    console.print()
    console.print(Panel.fit(
        f"[bold cyan]Extracta[/bold cyan] [dim]-- Agentic Document Extraction[/dim]",
        border_style="cyan",
        padding=(0, 2),
    ))
    console.print(f"  [dim]File   :[/dim] [white]{file_name}[/white]")
    console.print(f"  [dim]Server :[/dim] [white]{server_url}[/white]")
    console.print()


def print_analysing():
    console.print("  [bold yellow]Sending document to server...[/bold yellow]")
    console.print()


def animate_waiting(stop_event, message: str = "Processing"):
    """
    Show animated spinner with elapsed time while waiting for server response.
    Call this in a thread alongside the actual HTTP request.
    """
    frames = ["⠋", "⠙", "⠹", "⠸", "⠼", "⠴", "⠦", "⠧", "⠇", "⠏"]
    colors = ["cyan", "magenta", "yellow", "green", "blue"]
    start = time.time()
    i = 0

    stages = [
        (0,   "Uploading document..."),
        (3,   "Detecting layout per page..."),
        (8,   "Analysing projection profiles..."),
        (15,  "Running XY-Cut segmentation..."),
        (25,  "Extracting reading order..."),
        (40,  "Running ADE context threading..."),
        (70,  "LLM is analysing context threads..."),
        (110, "Finalising extraction..."),
    ]

    with Live(console=console, refresh_per_second=10) as live:
        while not stop_event.is_set():
            elapsed = time.time() - start
            frame = frames[i % len(frames)]
            color = colors[(i // 5) % len(colors)]

            # Pick current stage message
            stage_msg = stages[0][1]
            for threshold, msg in stages:
                if elapsed >= threshold:
                    stage_msg = msg

            mins = int(elapsed) // 60
            secs = int(elapsed) % 60
            time_str = f"{mins:02d}:{secs:02d}"

            line = Text()
            line.append(f"  {frame} ", style=f"bold {color}")
            line.append(stage_msg, style="white")
            line.append(f"  [{time_str}]", style="dim")

            live.update(line)
            time.sleep(0.1)
            i += 1

    console.print()


def print_page_results(pages: list):
    console.print("  [bold green]Layout analysis complete[/bold green]")
    console.print()

    table = Table(
        show_header=True,
        header_style="bold cyan",
        box=box.SIMPLE,
        padding=(0, 2),
        show_edge=False,
    )
    table.add_column("Page", style="dim", width=6)
    table.add_column("Layout", width=16)
    table.add_column("Strategy", width=12)
    table.add_column("Regions", width=8)

    for page in pages:
        page_num = str(page.get("page_number", "?"))
        layout = page.get("layout_type", "unknown")
        strategy = page.get("strategy", "unknown")
        regions = str(len(page.get("regions", [])))

        strategy_display = (
            "[bold green]V-Major[/bold green]"
            if strategy == "v_major"
            else "[bold magenta]H-Major[/bold magenta]"
        )

        layout_display = _format_layout(layout)
        table.add_row(page_num, layout_display, strategy_display, regions)

    console.print(table)
    console.print()


def print_threading():
    console.print("  [bold yellow]Running ADE context threading...[/bold yellow]")
    console.print()


def print_progress_bar(label: str, total_steps: int = 20, duration: float = 2.0):
    """Show a quick animated progress bar for visual feedback."""
    with Progress(
        TextColumn(f"  [dim]{label}[/dim]"),
        BarColumn(bar_width=30, style="cyan", complete_style="bold cyan"),
        TextColumn("[progress.percentage]{task.percentage:>3.0f}%"),
        TimeElapsedColumn(),
        console=console,
        transient=False,
    ) as progress:
        task = progress.add_task("", total=total_steps)
        step_time = duration / total_steps
        while not progress.finished:
            time.sleep(step_time)
            progress.advance(task)


def print_done(total_pages: int, total_regions: int, output_path: str):
    console.print(
        f"  [bold green]Done[/bold green] "
        f"[dim]--[/dim] "
        f"[white]{total_pages} pages[/white] [dim]|[/dim] "
        f"[white]{total_regions} regions[/white]"
    )
    console.print()
    console.print(Panel.fit(
        f"[bold white]Output:[/bold white] [cyan]{output_path}[/cyan]",
        border_style="green",
        padding=(0, 2),
    ))
    console.print()


def print_error(message: str):
    console.print()
    console.print(Panel.fit(
        f"[bold red]Error:[/bold red] [white]{message}[/white]",
        border_style="red",
        padding=(0, 2),
    ))
    console.print()


def print_server_error(status_code: int, detail: str):
    console.print()
    console.print(Panel.fit(
        f"[bold red]Server Error [{status_code}]:[/bold red] [white]{detail}[/white]",
        border_style="red",
        padding=(0, 2),
    ))
    console.print()


def _format_layout(layout: str) -> str:
    mapping = {
        "single_col":  "[white]single_col[/white]",
        "multi_col":   "[bold cyan]multi_col[/bold cyan]",
        "mixed":       "[bold yellow]mixed[/bold yellow]",
        "table_heavy": "[bold blue]table_heavy[/bold blue]",
        "image_heavy": "[bold magenta]image_heavy[/bold magenta]",
        "unknown":     "[dim]unknown[/dim]",
    }
    return mapping.get(layout, f"[white]{layout}[/white]")