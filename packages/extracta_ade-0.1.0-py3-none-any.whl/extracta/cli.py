import json
import sys
import threading
from pathlib import Path

import typer
import httpx

from extracta.client import extract_file, SERVER_URL
from extracta.display import (
    console,
    print_header,
    print_analysing,
    animate_waiting,
    print_page_results,
    print_threading,
    print_progress_bar,
    print_done,
    print_error,
    print_server_error,
)

app = typer.Typer(add_completion=False)

SUPPORTED_EXTENSIONS = {".pdf", ".pptx", ".docx", ".html", ".htm"}


@app.command()
def extract(
    file_path: str = typer.Argument(..., help="Path to the document to extract"),
):
    """
    Extract a document using Extracta -- agentic layout-aware extraction.
    Outputs a JSON file in the same directory as the input file.
    """
    path = Path(file_path).resolve()

    # Validate file exists
    if not path.exists():
        print_error(f"File not found: {file_path}")
        raise typer.Exit(code=1)

    # Validate file is a file not a directory
    if not path.is_file():
        print_error(f"Path is not a file: {file_path}")
        raise typer.Exit(code=1)

    # Validate extension
    if path.suffix.lower() not in SUPPORTED_EXTENSIONS:
        print_error(
            f"Unsupported file type: {path.suffix} | "
            f"Supported: {', '.join(SUPPORTED_EXTENSIONS)}"
        )
        raise typer.Exit(code=1)

    print_header(path.name, SERVER_URL)
    print_analysing()

    # Run HTTP request in a thread so animation can run in main thread
    result_container = {}
    error_container = {}
    stop_event = threading.Event()

    def do_request():
        try:
            result_container["data"] = extract_file(path)
        except Exception as e:
            error_container["error"] = e
        finally:
            stop_event.set()

    request_thread = threading.Thread(target=do_request, daemon=True)
    request_thread.start()

    # Animate while waiting
    animate_waiting(stop_event)

    request_thread.join()

    # Handle errors
    if "error" in error_container:
        e = error_container["error"]
        if isinstance(e, httpx.ConnectError):
            print_error(
                f"Could not connect to server at {SERVER_URL}. "
                f"Make sure extracta-server is running."
            )
        elif isinstance(e, httpx.TimeoutException):
            print_error(
                "Request timed out. The document may be too large "
                "or the server is busy. Try again -- server may have been cold starting."
            )
        elif isinstance(e, httpx.HTTPStatusError):
            try:
                detail = e.response.json().get("detail", str(e))
            except Exception:
                detail = str(e)
            print_server_error(e.response.status_code, detail)
        else:
            print_error(f"Unexpected error: {str(e)}")
        raise typer.Exit(code=1)

    result = result_container["data"]

    # Print per-page layout and strategy results
    pages = result.get("pages", [])
    print_page_results(pages)

    # Show ADE threading progress bar
    print_threading()
    print_progress_bar("Merging context threads", total_steps=30, duration=1.5)
    console.print()

    # Calculate totals
    total_pages = result.get("total_pages", len(pages))
    total_regions = sum(len(p.get("regions", [])) for p in pages)

    # Build output path -- same dir as input, same stem + _extracted.json
    output_path = path.parent / f"{path.stem}_extracted.json"

    # Write JSON output
    try:
        with open(output_path, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)
    except Exception as e:
        print_error(f"Failed to write output file: {str(e)}")
        raise typer.Exit(code=1)

    print_done(total_pages, total_regions, str(output_path))


def main():
    app()


if __name__ == "__main__":
    main()