import httpx
from pathlib import Path

SERVER_URL = "https://extracta-server.onrender.com"
EXTRACT_ENDPOINT = f"{SERVER_URL}/api/v1/extract"
TIMEOUT = 300.0  # 5 minutes


def extract_file(file_path: Path) -> dict:
    """
    Upload file to extracta-server and return parsed JSON response.
    Raises httpx.HTTPError on network or server errors.
    """
    with open(file_path, "rb") as f:
        files = {"file": (file_path.name, f, _get_mime_type(file_path))}
        response = httpx.post(
            EXTRACT_ENDPOINT,
            files=files,
            timeout=TIMEOUT,
        )

    response.raise_for_status()
    return response.json()


def _get_mime_type(file_path: Path) -> str:
    mime_map = {
        ".pdf":  "application/pdf",
        ".pptx": "application/vnd.openxmlformats-officedocument.presentationml.presentation",
        ".docx": "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
        ".html": "text/html",
        ".htm":  "text/html",
    }
    return mime_map.get(file_path.suffix.lower(), "application/octet-stream")