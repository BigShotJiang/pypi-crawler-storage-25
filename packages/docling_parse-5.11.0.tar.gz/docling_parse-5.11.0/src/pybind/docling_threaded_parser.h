//-*-C++-*-

#ifndef PYBIND_THREADED_PDF_PARSER_H
#define PYBIND_THREADED_PDF_PARSER_H

#include <pybind/docling_threaded_base.h>

namespace docling
{
  class docling_threaded_parser :
    public docling_threaded_base<docling_threaded_parser, page_decode_result>
  {
  public:

    docling_threaded_parser(std::string loglevel,
                            int num_threads,
                            int max_concurrent_results,
                            pdflib::decode_config config):
      docling_threaded_base<docling_threaded_parser, page_decode_result>(loglevel,
                                                                         num_threads,
                                                                         max_concurrent_results,
                                                                         config)
    {}

    void worker_loop();
  };

  inline void docling_threaded_parser::worker_loop()
  {
    while(true)
      {
        std::pair<std::string, int> task;
        {
          std::lock_guard<std::mutex> lock(task_mutex);

          if(task_queue.empty())
            {
              break;
            }

          task = task_queue.front();
          task_queue.pop();
        }

        const std::string& doc_key = task.first;
        int page_number = task.second;

        page_decode_result result;
        result.doc_key = doc_key;
        result.page_number = page_number;

        try
          {
            auto itr = key2doc.find(doc_key);
            if(itr == key2doc.end())
              {
                result.success = false;
                result.error_message = "Document key not found: " + doc_key;
              }
            else
              {
                auto& doc_decoder = itr->second;

                auto page_decoder = std::make_shared<pdflib::pdf_decoder<pdflib::PAGE>>(
                    doc_decoder->get_buffer(),
                    doc_decoder->get_password(),
                    page_number);

                page_decoder->decode_page(config);

                if(config.create_word_cells)
                  {
                    page_decoder->create_word_cells(config);
                  }

                if(config.create_line_cells)
                  {
                    page_decoder->create_line_cells(config);
                  }

                result.success = true;
                result.page_decoder = page_decoder;
              }
          }
        catch(const std::exception& exc)
          {
            result.success = false;
            result.error_message = "Error decoding page " + std::to_string(page_number)
              + " of " + doc_key + ": " + exc.what();
          }

        {
          std::unique_lock<std::mutex> lock(results_mutex);

          cv_results_consumed.wait(lock, [this]() {
            return static_cast<int>(results_queue.size()) < max_concurrent_results;
          });

          results_queue.push(std::move(result));
          cv_results_available.notify_one();
        }
      }

    active_workers.fetch_sub(1);

    cv_results_available.notify_all();
  }

}

#endif
