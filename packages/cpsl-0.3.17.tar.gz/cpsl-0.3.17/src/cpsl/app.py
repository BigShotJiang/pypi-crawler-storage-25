from __future__ import annotations

from dataclasses import fields as dc_fields
from typing import Any, Callable, Type, TypeVar, Union, TYPE_CHECKING

if TYPE_CHECKING:
    from .task_types import TaskDescriptor

from .channels import Chat, ChannelRef, _DeprecatedChannel, API
from .constants import (
    ACCESS_PUBLIC, AccessLevel,
    CollectionDecl, CollectionScope,
    PAGE_TYPE_DSL, PAGE_TYPE_REACT,
    PRICING_ONE_TIME, PricingType,
    SCOPE_APP, VALID_SCOPES,
)
from .db import CollectionRef
from .filesystem import FileSystem
from .image import Image
from .integration import IntegrationConfig, KNOWN_SECRET_INTEGRATIONS
from .decorators import (
    _BOOT_ATTR, _SHUTDOWN_ATTR, _ENTER_ATTR, _EXIT_ATTR,
    _MESSAGE_ATTR, _SCHEDULE_ATTR, _ENDPOINT_ATTR, _ASGI_ATTR,
)
from .secret import Secret
from .theme import PresetName, Radius, Theme, resolve_theme

ChannelLike = Union[Chat, ChannelRef, _DeprecatedChannel, API]

F = TypeVar("F", bound=Callable)
T = TypeVar("T")

_REGISTERED_CLASSES: list[dict[str, Any]] = []
_DATA_REGISTRY: dict[str, Callable] = {}

_DATA_ATTR = "__cpsl_data__"
_ACCESS_ATTR = "_cpsl_access"


def _collect_channel_secrets(channels: list[ChannelLike]) -> list[str]:
    """Extract secret names from channel credential fields."""
    names: list[str] = []
    for ch in channels:
        if isinstance(ch, (Chat, ChannelRef, API)):
            continue
        for f in dc_fields(ch):
            v = getattr(ch, f.name)
            if isinstance(v, Secret) and v.name:
                names.append(v.name)
    return names


class App:
    """Deployment namespace for capsule apps.

    Class-based (existing):
        app = App(name="foo")

        @app.cls(image=Image(), channels=[Chat()])
        class Foo: ...

    Functional (new):
        app = App(name="foo", image=Image(), channels=[Chat()])

        @app.message()
        async def handle(session, msg): ...
    """

    def __init__(
        self,
        name: str,
        *,
        image: Image | None = None,
        channels: list[ChannelLike] | None = None,
        keep_warm_seconds: int = 0,
        secrets: list[str] | None = None,
        filesystems: dict[str, FileSystem] | None = None,
        price: int = 0,
        pricing_type: PricingType = PRICING_ONE_TIME,
    ) -> None:
        self.name = name
        self._integrations: list[IntegrationConfig] = []
        self._pages: list[dict[str, Any]] = []
        self._collections: list[CollectionDecl] = []
        self._collection_refs: list[CollectionRef] = []
        self._data_sources: dict[str, Callable] = {}
        self._page_order: int = 0
        self._theme: Theme | None = None

        # Functional mode: image provided at init time (no @app.cls needed).
        self._functional = image is not None
        self._has_cls = False
        if self._functional:
            all_channels = channels or []
            all_secrets = list(secrets or [])
            for s in _collect_channel_secrets(all_channels):
                if s not in all_secrets:
                    all_secrets.append(s)

            fs_map: dict[str, str] = {}
            if filesystems:
                for mount_path, fs_obj in filesystems.items():
                    fs_map[mount_path] = fs_obj.name

            self._cpsl_config: dict[str, Any] = {
                "app_name": name,
                "image": image.to_dict(),
                "price": price,
                "pricing_type": pricing_type,
                "channels": [c.to_dict() for c in all_channels],
                "keep_warm_seconds": keep_warm_seconds,
                "secrets": all_secrets,
                "filesystems": fs_map,
                "integrations": [],
                "schedules": [],
                "pages": [],
                "collections": [],
                "collection_refs": [],
                "data_sources": [],
                "theme": None,
                "module": None,
                "class_name": None,
            }
            _REGISTERED_CLASSES.append(self._cpsl_config)

    # -- collections ---------------------------------------------------------

    def collection(
        self,
        name: str,
        *,
        columns: list[str] | None = None,
        scope: CollectionScope = SCOPE_APP,
        sortable: bool = False,
        filterable: bool = False,
        paginate: int = 0,
    ) -> CollectionRef:
        """Declare a collection and return a ``CollectionRef`` handle.

        Scopes: ``"app"`` (shared), ``"user"`` (per individual),
        ``"team"`` (per org), ``"session"`` (per chat session).
        """
        if scope not in VALID_SCOPES:
            raise ValueError(f"scope must be one of {VALID_SCOPES}, got {scope!r}")
        decl = CollectionDecl(
            name=name,
            scope=scope,
            columns=tuple(columns) if columns else None,
            sortable=sortable,
            filterable=filterable,
            paginate=paginate,
        )
        self._collections.append(decl)
        ref = CollectionRef(name=name, decl=decl)
        self._collection_refs.append(ref)
        return ref

    # -- theme ---------------------------------------------------------------

    def theme(
        self,
        *,
        preset: PresetName | None = None,
        logo: str | None = None,
        tagline: str | None = None,
        primary: str | None = None,
        accent: str | None = None,
        background: str | None = None,
        foreground: str | None = None,
        sidebar: str | None = None,
        surface: str | None = None,
        border: str | None = None,
        muted: str | None = None,
        danger: str | None = None,
        success: str | None = None,
        font_sans: str | None = None,
        font_mono: str | None = None,
        radius: Radius | None = None,
    ) -> None:
        """Configure the visual theme for the subdomain app.

        Args:
            preset: Start from a built-in theme — ``"dark"``, ``"light"``,
                ``"midnight"``, or ``"warm"``.
            logo: Path to a logo image (relative to app root) or a URL.
            tagline: Short text displayed below the app name in the sidebar.
            primary: Interactive elements — links, buttons, focus rings (hex).
            accent: Warm highlight for emphasis (hex). Use sparingly.
            background: Page background color (hex).
            foreground: Primary text color (hex).
            sidebar: Sidebar / navigation background (hex).
            surface: Raised surface color for cards and panels (hex).
            border: Borders, dividers, and separators (hex).
            muted: Secondary / de-emphasized text (hex).
            danger: Destructive actions and error states (hex).
            success: Success states and confirmations (hex).
            font_sans: CSS ``font-family`` for body text.
            font_mono: CSS ``font-family`` for code and data values.
            radius: Border-radius scale — ``"sm"``, ``"md"``, or ``"lg"``.
        """
        overrides = {
            k: v for k, v in locals().items()
            if k not in ("self", "preset") and v is not None
        }
        self._theme = resolve_theme(preset=preset, **overrides)

    # -- integrations --------------------------------------------------------

    def add_integration(
        self,
        integration_type: str,
        *,
        client_id: str | Secret = "",
        client_secret: str | Secret = "",
        scopes: list[str] | None = None,
        fields: list[str] | None = None,
    ) -> None:
        """Declare an integration the app requires from end users.

        OAuth integrations need ``client_id`` and ``client_secret``.
        Secret-based integrations (``tailscale``, ``aws``, or custom with
        ``fields=``) need neither — the user submits credentials via a form.
        """
        is_secret = fields is not None or integration_type in KNOWN_SECRET_INTEGRATIONS
        if not is_secret and not client_id:
            raise ValueError(
                f"OAuth integration '{integration_type}' requires client_id and client_secret"
            )
        self._integrations.append(IntegrationConfig(
            type=integration_type,
            client_id=client_id,
            client_secret=client_secret,
            scopes=scopes or [],
            fields=fields,
        ))

    # -- pages ---------------------------------------------------------------

    def add_page(
        self,
        name: str,
        *,
        icon: str = "file",
        component: str,
        packages: list[str] | None = None,
        order: int | None = None,
        access: AccessLevel = ACCESS_PUBLIC,
    ) -> None:
        """Declare a React/TSX page that appears in the subdomain sidebar.

        ``access`` controls who can view the page:
        ``"public"`` (default) — anyone, ``"authenticated"`` — logged-in users only.
        """
        if order is None:
            order = self._page_order
        self._page_order = max(self._page_order, order) + 1
        self._pages.append({
            "name": name,
            "icon": icon,
            "type": PAGE_TYPE_REACT,
            "component": component,
            "packages": packages or [],
            "order": order,
            "access": access,
        })

    def page(
        self,
        name: str,
        *,
        icon: str = "file",
        order: int | None = None,
        access: AccessLevel = ACCESS_PUBLIC,
    ) -> Callable[[Callable], Callable]:
        """Decorator for Python DSL pages. The function must return a ui.Page widget tree.

        ``access`` controls who can view the page:
        ``"public"`` (default) — anyone, ``"authenticated"`` — logged-in users only.
        """
        if order is None:
            order = self._page_order
        self._page_order = max(self._page_order, order) + 1
        _order = order
        _access = access

        def decorator(fn: Callable) -> Callable:
            widget_tree = fn()
            tree_dict = widget_tree.to_dict() if hasattr(widget_tree, "to_dict") else {}
            self._pages.append({
                "name": name,
                "icon": icon,
                "type": PAGE_TYPE_DSL,
                "widget_tree": tree_dict,
                "order": _order,
                "access": _access,
            })
            return fn

        return decorator

    # -- data sources --------------------------------------------------------

    def data(self, name: str, *, access: AccessLevel = ACCESS_PUBLIC) -> Callable[[Callable], Callable]:
        """Register a named data source endpoint. The function is called on
        ``GET /data/<name>`` and should return JSON-serializable data.

        ``access`` controls who can call the endpoint:
        ``"public"`` (default) — anyone, ``"authenticated"`` — logged-in users only.
        """
        _access = access

        def decorator(fn: Callable) -> Callable:
            self._data_sources[name] = fn
            _DATA_REGISTRY[name] = fn
            setattr(fn, _DATA_ATTR, name)
            setattr(fn, _ACCESS_ATTR, _access)
            return fn
        return decorator

    # -- functional handler decorators ----------------------------------------

    def _require_functional(self, decorator_name: str) -> None:
        if self._has_cls:
            raise RuntimeError(
                f"@app.{decorator_name}() cannot be used with @app.cls — "
                "use either functional or class-based style, not both"
            )
        if not self._functional:
            raise RuntimeError(
                f"@app.{decorator_name}() requires an image. "
                "Pass image= to App() or use @app.cls with a class instead."
            )

    def _hook_decorator(self, attr: str, name: str) -> Callable[[F], F]:
        self._require_functional(name)

        def decorator(fn: F) -> F:
            setattr(fn, attr, True)
            setattr(self, f"_{name}_handler", fn)
            return fn
        return decorator

    def boot(self) -> Callable[[F], F]:
        """Register a boot handler (functional apps)."""
        return self._hook_decorator(_BOOT_ATTR, "boot")

    def shutdown(self) -> Callable[[F], F]:
        """Register a shutdown handler (functional apps)."""
        return self._hook_decorator(_SHUTDOWN_ATTR, "shutdown")

    def enter(self) -> Callable[[F], F]:
        """Register a session-enter handler (functional apps)."""
        return self._hook_decorator(_ENTER_ATTR, "enter")

    def exit(self) -> Callable[[F], F]:
        """Register a session-exit handler (functional apps)."""
        return self._hook_decorator(_EXIT_ATTR, "exit")

    def message(self) -> Callable[[F], F]:
        """Register the message handler (functional apps)."""
        return self._hook_decorator(_MESSAGE_ATTR, "message")

    def schedule(self, cron: str) -> Callable[[F], F]:
        """Register a handler that runs on a cron schedule.

        Args:
            cron: Cron expression (e.g. ``"*/5 * * * *"`` for every 5 minutes,
                ``"0 9 * * 1-5"`` for weekday mornings at 9 AM UTC).
        """
        self._require_functional("schedule")

        def decorator(fn: F) -> F:
            setattr(fn, _SCHEDULE_ATTR, cron)
            attr_name = fn.__name__
            setattr(self, attr_name, fn)
            self._cpsl_config["schedules"].append({"name": attr_name, "cron": cron})
            return fn
        return decorator

    def endpoint(self, method: str = "GET", path: str = "/", authorized: bool = True) -> Callable[[F], F]:
        """Register an HTTP endpoint handler.

        Args:
            method: HTTP method (``"GET"``, ``"POST"``, ``"PUT"``, etc.).
            path: URL path to mount the handler at (e.g. ``"/webhook"``).
            authorized: If ``True``, requests require a valid session token.
        """
        self._require_functional("endpoint")

        def decorator(fn: F) -> F:
            setattr(fn, _ENDPOINT_ATTR, {"method": method, "path": path, "authorized": authorized})
            setattr(self, fn.__name__, fn)
            return fn
        return decorator

    def asgi(self, path: str = "/app") -> Callable[[F], F]:
        """Mount an ASGI application (e.g. FastAPI, Starlette).

        Args:
            path: URL prefix where the ASGI app is served.
        """
        self._require_functional("asgi")

        def decorator(fn: F) -> F:
            setattr(fn, _ASGI_ATTR, {"path": path})
            setattr(self, fn.__name__, fn)
            return fn
        return decorator

    def task(
        self,
        retries: int = 0,
        timeout: int = 0,
        lock: str | None = None,
        retry_for: list[Type[Exception]] | None = None,
        callback_url: str | None = None,
        process: bool = False,
    ) -> Callable[..., TaskDescriptor]:
        """Register a background task.

        The decorated function becomes a :class:`TaskDescriptor` with
        ``.submit()``, ``.schedule()``, ``.find()``, ``.count()``, and
        ``.cancel()`` methods.

        Args:
            retries: Max retry attempts on failure.
            timeout: Seconds before the task is killed (``0`` = no limit).
            lock: Lock template for distributed locking (e.g.
                ``"user:{user_id}"``).
            retry_for: Exception types that trigger a retry instead of
                permanent failure.
            callback_url: URL to POST task result on completion/failure.
            process: Run the task in a **separate OS process** for true
                CPU parallelism and crash isolation. The child receives
                a fully re-hydrated ``Session``.

        Example::

            @app.task(retries=2, timeout=60)
            async def send_email(session: cpsl.Session, to: str, body: str):
                ...

            @app.task(process=True, timeout=300)
            async def heavy_compute(session: cpsl.Session, data: dict):
                # runs on its own core, isolated from the main runner
                ...

            handle = await send_email.submit(session=session, to="a@b.c", body="Hi")
        """
        self._require_functional("task")
        from .task_types import TaskDescriptor as _TD, _TASK_ATTR

        def decorator(fn: Callable) -> TaskDescriptor:
            desc = _TD(
                fn, retries=retries, timeout=timeout, lock=lock,
                retry_for=retry_for, callback_url=callback_url,
                functional=True, process=process,
            )
            setattr(desc, _TASK_ATTR, True)
            setattr(self, fn.__name__, desc)
            return desc
        return decorator

    # -- cls decorator -------------------------------------------------------

    def cls(
        self,
        *,
        image: Image,
        price: int = 0,
        pricing_type: PricingType = PRICING_ONE_TIME,
        channels: list[ChannelLike] | None = None,
        keep_warm_seconds: int = 0,
        secrets: list[str] | None = None,
        filesystems: dict[str, FileSystem] | None = None,
    ) -> Callable[[type[T]], type[T]]:
        """Decorator for class-based apps. Captures deploy config."""
        if self._functional:
            raise RuntimeError(
                "@app.cls cannot be used on an App with image= set — "
                "use either functional or class-based style, not both"
            )
        self._has_cls = True

        app_name = self.name
        all_channels = channels or []
        all_secrets = list(secrets or [])
        for name in _collect_channel_secrets(all_channels):
            if name not in all_secrets:
                all_secrets.append(name)

        fs_map: dict[str, str] = {}
        if filesystems:
            for mount_path, fs_obj in filesystems.items():
                fs_map[mount_path] = fs_obj.name

        integrations = [ig.to_dict() for ig in self._integrations]
        pages = sorted(self._pages, key=lambda p: p.get("order", 0))
        data_source_names = list(self._data_sources.keys())
        collections = [c.to_dict() for c in self._collections]
        collection_refs = list(self._collection_refs)
        theme_dict = self._theme.to_dict() if self._theme else None

        def decorator(klass: type[T]) -> type[T]:
            schedule_specs: list[dict[str, str]] = []
            for attr_name in dir(klass):
                fn = getattr(klass, attr_name, None)
                cron_val = getattr(fn, _SCHEDULE_ATTR, None)
                if cron_val and isinstance(cron_val, str):
                    schedule_specs.append({"name": attr_name, "cron": cron_val})

            config = {
                "app_name": app_name,
                "image": image.to_dict(),
                "price": price,
                "pricing_type": pricing_type,
                "channels": [c.to_dict() for c in all_channels],
                "keep_warm_seconds": keep_warm_seconds,
                "secrets": all_secrets,
                "filesystems": fs_map,
                "integrations": integrations,
                "schedules": schedule_specs,
                "pages": pages,
                "collections": collections,
                "collection_refs": collection_refs,
                "data_sources": data_source_names,
                "theme": theme_dict,
                "module": klass.__module__,
                "class_name": klass.__qualname__,
            }
            klass._cpsl_config = config  # type: ignore[attr-defined]
            _REGISTERED_CLASSES.append(config)
            return klass

        return decorator

    # -- config finalization -------------------------------------------------

    def _finalize_config(self) -> None:
        """Snapshot mutable state into the config dict (functional apps only).

        Called by resolve_entry_point / Runner before reading the config,
        so collections, pages, integrations, and data sources declared
        after __init__ are captured.
        """
        if not self._functional:
            return
        cfg = self._cpsl_config
        cfg["integrations"] = [ig.to_dict() for ig in self._integrations]
        cfg["pages"] = sorted(self._pages, key=lambda p: p.get("order", 0))
        cfg["data_sources"] = list(self._data_sources.keys())
        cfg["collections"] = [c.to_dict() for c in self._collections]
        cfg["collection_refs"] = list(self._collection_refs)
        cfg["theme"] = self._theme.to_dict() if self._theme else None

    def _serialize(self) -> dict[str, Any] | None:
        """Return the deploy spec for the class registered under this app."""
        self._finalize_config()
        for cfg in _REGISTERED_CLASSES:
            if cfg["app_name"] == self.name:
                return cfg
        return None
