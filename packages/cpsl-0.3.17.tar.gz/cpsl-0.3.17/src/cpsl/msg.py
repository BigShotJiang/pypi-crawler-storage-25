from __future__ import annotations

import time as _time
from dataclasses import dataclass, field
from typing import Literal


Sender = Literal["user", "app"]
"""Who sent the message — the end user or the app itself."""

ChannelType = Literal["chat", "api", "telegram", "slack", "whatsapp"]
"""Transport the message arrived on."""


@dataclass
class Attachment:
    """File attached to a message."""

    name: str
    content_type: str
    url: str

    def to_dict(self) -> dict:
        return {
            "name": self.name,
            "content_type": self.content_type,
            "url": self.url,
        }


@dataclass
class Message:
    """A single message exchanged between user and app.

    Attributes:
        text: Message body (plain text or markdown).
        sender: ``"user"`` for inbound messages, ``"app"`` for replies.
        channel_type: Transport channel — ``"chat"``, ``"api"``,
            ``"telegram"``, ``"slack"``, or ``"whatsapp"``.
        timestamp: Unix epoch seconds (defaults to now).
        attachments: Optional list of file attachments.
    """

    text: str
    sender: Sender
    channel_type: ChannelType
    timestamp: float = field(default_factory=_time.time)
    attachments: list[Attachment] | None = None

    def to_dict(self) -> dict:
        d = {
            "text": self.text,
            "sender": self.sender,
            "channel_type": self.channel_type,
            "timestamp": self.timestamp,
        }
        if self.attachments:
            d["attachments"] = [a.to_dict() for a in self.attachments]
        return d
