"""Validation engine for JSONL changelog entries with result caching, checking field constraints, hash integrity, and entry ordering."""

from __future__ import annotations

import os
import subprocess
import sys

from .files import list_versioned_files, read_unreleased
from .resolve import resolve_hash, resolve_hashes
from .schema import ChangelogEntry, parse_jsonl, validate_schema
from ..config import get_changelog_validation_config
from ..utils import commit_files


# Defaults applied when batch_limits keys are absent or malformed.
_BATCH_LIMITS_DEFAULTS = {
    "max_commits_per_entry": 5,
    "max_entries_per_commit": 5,
    "exclusions": [],
}


def _get_batch_limits_config() -> dict:
    """Return the resolved batch_limits config with defaults applied.

    Reads the raw ``batch_limits`` section via
    :func:`get_changelog_validation_config` and guarantees that all three
    expected keys are present with sane types:

    - ``max_commits_per_entry`` (int)
    - ``max_entries_per_commit`` (int)
    - ``exclusions`` (list)

    If any key is missing or has the wrong type, the default is used and a
    warning is emitted on stderr.
    """
    raw = get_changelog_validation_config() or {}
    resolved: dict = {}

    for key, default in _BATCH_LIMITS_DEFAULTS.items():
        if key not in raw:
            resolved[key] = default
            continue
        value = raw[key]
        if not isinstance(value, type(default)) or isinstance(value, bool) and not isinstance(default, bool):
            # bool is a subclass of int, so guard against accidental bool-as-int
            print(
                f"warning: batch_limits.{key} has wrong type "
                f"({type(value).__name__}); using default {default!r}",
                file=sys.stderr,
            )
            resolved[key] = default
        else:
            resolved[key] = value

    return resolved


def _git_log_hashes(range_spec: str) -> list[str]:
    """Get commit hashes from git log for a given range spec.

    Returns a list of full 40-char SHAs, or empty list on error.
    """
    try:
        result = subprocess.run(
            ["git", "log", "--format=%H", range_spec],
            capture_output=True,
            text=True,
            timeout=30,
        )
        if result.returncode != 0:
            return []
        return [line.strip() for line in result.stdout.strip().splitlines() if line.strip()]
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return []


def _get_last_version_tag(tag_glob: str | None = None) -> str | None:
    """Get the most recent version tag (e.g., v0.25.2).

    When tag_glob is set (monorepo mode), uses it directly as the
    ``--match`` pattern (e.g. ``mylib@v*`` or ``go/v*``).

    Returns the tag string or None if no version tags exist.
    """
    match_pattern = tag_glob if tag_glob else "v*"
    try:
        result = subprocess.run(
            ["git", "describe", "--tags", "--abbrev=0", "--match", match_pattern],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        tag = result.stdout.strip()
        return tag if tag else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


def _unreleased_range(tag_glob: str | None = None) -> str:
    """Return the git log range spec for unreleased commits.

    Uses <last_tag>..HEAD if a version tag exists, otherwise HEAD
    (all commits, for first release). Passes tag_glob through to
    _get_last_version_tag for monorepo-aware tag discovery.
    """
    tag = _get_last_version_tag(tag_glob)
    if tag:
        return f"{tag}..HEAD"
    return "HEAD"


def _git_head() -> str | None:
    """Get the current HEAD commit hash."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "HEAD"],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return None
        sha = result.stdout.strip()
        return sha if len(sha) == 40 else None
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return None


_CHANGELOG_PATTERNS = (".rlsbl/changes/", ".rlsbl/version", "CHANGELOG.md")


def _is_changelog_only_commit(sha: str) -> bool:
    """Check if a commit only touches changelog/release infrastructure files.

    Uses suffix-iteration to handle monorepo paths: for a file like
    ``python/.rlsbl/changes/unreleased.jsonl``, checks every path suffix
    (``python/.rlsbl/changes/unreleased.jsonl``, ``.rlsbl/changes/unreleased.jsonl``,
    ``changes/unreleased.jsonl``, ``unreleased.jsonl``) against the patterns.

    Returns True only if ALL files in the commit match some pattern.
    """
    try:
        result = subprocess.run(
            ["git", "diff-tree", "--no-commit-id", "--name-only", "-r", sha],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return False
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False

    files = [line.strip() for line in result.stdout.strip().splitlines() if line.strip()]
    if not files:
        return False

    for filepath in files:
        segments = filepath.split("/")
        matched = False
        for i in range(len(segments)):
            suffix = "/".join(segments[i:])
            for pat in _CHANGELOG_PATTERNS:
                if pat.endswith("/"):
                    if suffix.startswith(pat):
                        matched = True
                        break
                else:
                    if suffix == pat:
                        matched = True
                        break
            if matched:
                break
        if not matched:
            return False
    return True


def _is_autogenerated(sha: str) -> bool:
    """Check if a commit has the ``Autogenerated: true`` trailer.

    Returns True when the trailer is present with value ``true``,
    False otherwise.  Subprocess errors are treated as non-autogenerated.
    """
    try:
        result = subprocess.run(
            ["git", "log", "-1", "--format=%(trailers:key=Autogenerated,valueonly)", sha],
            capture_output=True,
            text=True,
            timeout=10,
        )
        if result.returncode != 0:
            return False
        return result.stdout.strip() == "true"
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


def _is_ancestor(ancestor: str, descendant: str) -> bool:
    """Check if ancestor is an ancestor of descendant."""
    try:
        result = subprocess.run(
            ["git", "merge-base", "--is-ancestor", ancestor, descendant],
            capture_output=True,
            text=True,
            timeout=10,
        )
        return result.returncode == 0
    except (subprocess.TimeoutExpired, FileNotFoundError, OSError):
        return False


# ---------------------------------------------------------------------------
# Validation cache
# ---------------------------------------------------------------------------

def _cache_path(changes_dir: str) -> str:
    """Return path to the .validated cache file."""
    return os.path.join(changes_dir, ".validated")


def _read_cache(changes_dir: str) -> str | None:
    """Read the .validated file. Return the cached HEAD hash or None."""
    path = _cache_path(changes_dir)
    if not os.path.isfile(path):
        return None
    try:
        with open(path, "r", encoding="utf-8") as f:
            sha = f.read().strip()
        return sha if len(sha) == 40 else None
    except OSError:
        return None


def _write_cache(changes_dir: str) -> None:
    """Write the current HEAD hash to the .validated cache file."""
    head = _git_head()
    if head is None:
        return
    path = _cache_path(changes_dir)
    with open(path, "w", encoding="utf-8") as f:
        f.write(head + "\n")
    commit_files("update validation cache", [path], allow_failure=True)


def _is_cache_valid(changes_dir: str) -> bool:
    """Check if the validation cache is still valid.

    Valid when:
    - .validated exists and contains a 40-char SHA
    - That SHA is an ancestor of (or equal to) HEAD
    - unreleased.jsonl's mtime is older than .validated's mtime
    """
    cached_sha = _read_cache(changes_dir)
    if cached_sha is None:
        return False

    head = _git_head()
    if head is None:
        return False

    # Check ancestor relationship (equal counts as ancestor)
    if cached_sha != head and not _is_ancestor(cached_sha, head):
        return False

    # Check mtimes
    cache_file = _cache_path(changes_dir)
    unreleased_file = os.path.join(changes_dir, "unreleased.jsonl")
    if not os.path.isfile(unreleased_file):
        return True  # No unreleased file means nothing to invalidate
    try:
        cache_mtime = os.path.getmtime(cache_file)
        unreleased_mtime = os.path.getmtime(unreleased_file)
        return unreleased_mtime <= cache_mtime
    except OSError:
        return False


# ---------------------------------------------------------------------------
# Individual checks
# ---------------------------------------------------------------------------

def check_hashes_resolve(entries: list[ChangelogEntry]) -> tuple[bool, list[str]]:
    """Check that every hash in every entry resolves via git rev-parse."""
    details: list[str] = []
    all_hashes: list[str] = []
    for entry in entries:
        all_hashes.extend(entry.commits)

    resolved = resolve_hashes(all_hashes)
    for h, full in resolved.items():
        if full is None:
            details.append(f"hash does not resolve: {h}")

    return (len(details) == 0, details)


def check_in_range(entries: list[ChangelogEntry], tag_glob: str | None = None) -> tuple[bool, list[str]]:
    """Check that every resolved hash is in the unreleased range.

    Unreleased range: commits since the last version tag (or all commits
    if no tags exist). When tag_glob is set, scopes to monorepo tags.
    """
    details: list[str] = []
    unreleased_commits = set(_git_log_hashes(_unreleased_range(tag_glob)))

    all_hashes: list[str] = []
    for entry in entries:
        all_hashes.extend(entry.commits)

    resolved = resolve_hashes(all_hashes)
    for h, full in resolved.items():
        if full is not None and full not in unreleased_commits:
            details.append(f"hash not in unreleased range: {h} ({full})")

    return (len(details) == 0, details)


def check_coverage(entries: list[ChangelogEntry], tag_glob: str | None = None) -> tuple[bool, list[str]]:
    """Check that every unreleased commit appears in at least one entry.

    Commits with the ``Autogenerated: true`` trailer are automatically
    exempted -- they are release infrastructure and don't need coverage.
    When tag_glob is set, scopes to monorepo tags.
    """
    details: list[str] = []
    unreleased_commits = set(_git_log_hashes(_unreleased_range(tag_glob)))

    # Collect all resolved hashes from entries
    all_hashes: list[str] = []
    for entry in entries:
        all_hashes.extend(entry.commits)
    resolved = resolve_hashes(all_hashes)
    covered = {full for full in resolved.values() if full is not None}

    skipped_autogenerated = 0
    skipped_changelog_only = 0
    uncovered = 0
    for commit in sorted(unreleased_commits):
        if commit not in covered:
            if _is_autogenerated(commit):
                skipped_autogenerated += 1
                continue
            if _is_changelog_only_commit(commit):
                skipped_changelog_only += 1
                continue
            uncovered += 1
            details.append(f"unreleased commit not covered: {commit[:12]}")

    if skipped_autogenerated > 0:
        details.append(f"skipped {skipped_autogenerated} autogenerated commit(s)")
    if skipped_changelog_only > 0:
        details.append(f"skipped {skipped_changelog_only} changelog-only commit(s)")

    return (uncovered == 0, details)


def check_no_orphans(entries: list[ChangelogEntry]) -> tuple[bool, list[str]]:
    """Flag entries where ALL hashes are unresolvable (stale/rebased entries)."""
    details: list[str] = []
    for i, entry in enumerate(entries):
        if not entry.commits:
            continue
        resolved = resolve_hashes(entry.commits)
        if all(v is None for v in resolved.values()):
            hashes_str = ", ".join(entry.commits[:3])
            if len(entry.commits) > 3:
                hashes_str += ", ..."
            details.append(f"entry {i + 1}: all hashes unresolvable ({hashes_str})")

    return (len(details) == 0, details)


def check_schema(entries: list[ChangelogEntry]) -> tuple[bool, list[str]]:
    """Check that every entry passes schema validation."""
    details: list[str] = []
    for i, entry in enumerate(entries):
        errors = validate_schema(entry)
        for error in errors:
            details.append(f"entry {i + 1}: {error}")

    return (len(details) == 0, details)


def check_batch_size_commits(
    entries: list[ChangelogEntry],
    config: dict,
    version: str = "unreleased",
) -> tuple[bool, list[str]]:
    """Check that no entry has more commits than ``max_commits_per_entry``.

    ``config`` is the resolved batch_limits config (see
    :func:`_get_batch_limits_config`). Per-entry exclusions (matched by
    ``version`` + 1-based line number) silence the check for those entries.
    """
    max_commits = config.get("max_commits_per_entry", _BATCH_LIMITS_DEFAULTS["max_commits_per_entry"])
    exclusions = config.get("exclusions", [])

    exempted_entries: set[tuple[str, int]] = set()
    for excl in exclusions:
        if not isinstance(excl, dict):
            continue
        for entry_ref in excl.get("entries", []) or []:
            if not isinstance(entry_ref, dict):
                continue
            v = entry_ref.get("version")
            ln = entry_ref.get("line")
            if v is not None and isinstance(ln, int):
                exempted_entries.add((v, ln))

    details: list[str] = []
    for i, entry in enumerate(entries):
        line_num = i + 1
        if (version, line_num) in exempted_entries:
            continue
        if len(entry.commits) > max_commits:
            short_commits = ", ".join(c[:7] for c in entry.commits)
            details.append(
                f"{version}.jsonl line {line_num}: {len(entry.commits)} commits "
                f"(max: {max_commits}) [{short_commits}]"
            )
    return (len(details) == 0, details)


def check_batch_size_entries(
    entries_by_version: dict[str, list[ChangelogEntry]],
    config: dict,
) -> tuple[bool, list[str]]:
    """Check that no commit appears in more than ``max_entries_per_commit`` entries.

    ``entries_by_version`` maps version label (e.g. ``"unreleased"`` or
    ``"0.32.0"``) to its entry list, so the check spans across ALL JSONL
    files, not just unreleased. Per-commit exclusions in ``config``
    silence specific hashes.
    """
    max_entries = config.get("max_entries_per_commit", _BATCH_LIMITS_DEFAULTS["max_entries_per_commit"])
    exclusions = config.get("exclusions", [])

    exempted_commits: set[str] = set()
    for excl in exclusions:
        if not isinstance(excl, dict):
            continue
        for commit in excl.get("commits", []) or []:
            if isinstance(commit, str):
                exempted_commits.add(commit)

    appearances: dict[str, list[tuple[str, int]]] = {}
    for version, entries in entries_by_version.items():
        for i, entry in enumerate(entries):
            for commit in entry.commits:
                appearances.setdefault(commit, []).append((version, i + 1))

    details: list[str] = []
    for commit in sorted(appearances):
        locations = appearances[commit]
        if commit in exempted_commits:
            continue
        if len(locations) > max_entries:
            loc_str = ", ".join(f"{v}.jsonl:{ln}" for v, ln in locations)
            details.append(
                f"commit {commit[:7]}: appears in {len(locations)} entries "
                f"(max: {max_entries}) [{loc_str}]"
            )
    return (len(details) == 0, details)


def _read_all_versioned_entries(changes_dir: str) -> dict[str, list[ChangelogEntry]]:
    """Read entries from unreleased.jsonl AND every x.y.z.jsonl in changes_dir.

    Returns a mapping ``{version_label: entries}`` where ``version_label`` is
    ``"unreleased"`` or the bare semver string (e.g. ``"0.32.0"``).
    Files that fail to parse are skipped silently -- other checks surface
    such errors separately.
    """
    result: dict[str, list[ChangelogEntry]] = {
        "unreleased": read_unreleased(changes_dir),
    }
    for version, path in list_versioned_files(changes_dir):
        try:
            result[version] = parse_jsonl(path)
        except (ValueError, OSError):
            continue
    return result


# ---------------------------------------------------------------------------
# Combined validation
# ---------------------------------------------------------------------------

def validate_unreleased(changes_dir: str, tag_glob: str | None = None) -> dict:
    """Run all 7 validation checks on unreleased.jsonl.

    Returns a dict with:
    - check names as keys, (passed, details) tuples as values
    - "passed": overall bool (True only if all checks pass)

    Uses validation cache: if the cache is valid and HEAD hasn't changed,
    skips full revalidation. When tag_glob is set, uses it directly as
    the glob pattern for monorepo tag discovery (e.g. ``mylib@v*`` or
    ``go/v*``).

    The two batch_limits checks (``batch_size_commits`` and
    ``batch_size_entries``) read configuration from
    ``.rlsbl/config.json`` via :func:`_get_batch_limits_config`. The
    cross-version ``batch_size_entries`` check reads every
    ``x.y.z.jsonl`` file in ``changes_dir`` so it can detect commits
    that appear in too many entries across versions.
    """
    entries = read_unreleased(changes_dir)
    batch_config = _get_batch_limits_config()

    # Check cache
    if _is_cache_valid(changes_dir):
        cached_sha = _read_cache(changes_dir)
        head = _git_head()
        if cached_sha == head:
            # Nothing changed since last validation
            return {
                "passed": True,
                "checks": {
                    "hashes_resolve": (True, []),
                    "in_range": (True, []),
                    "coverage": (True, []),
                    "no_orphans": (True, []),
                    "schema": (True, []),
                    "batch_size_commits": (True, []),
                    "batch_size_entries": (True, []),
                },
            }
        # Cache is valid but HEAD moved: only validate new entries
        # (entries added since the cached state). Since we can't easily
        # determine which entries are new without more metadata, run full
        # validation but update cache on success.

    entries_by_version = _read_all_versioned_entries(changes_dir)

    checks = {
        "hashes_resolve": check_hashes_resolve(entries),
        "in_range": check_in_range(entries, tag_glob),
        "coverage": check_coverage(entries, tag_glob),
        "no_orphans": check_no_orphans(entries),
        "schema": check_schema(entries),
        "batch_size_commits": check_batch_size_commits(entries, batch_config, version="unreleased"),
        "batch_size_entries": check_batch_size_entries(entries_by_version, batch_config),
    }

    overall = all(passed for passed, _ in checks.values())

    if overall:
        _write_cache(changes_dir)

    return {
        "passed": overall,
        "checks": checks,
    }
