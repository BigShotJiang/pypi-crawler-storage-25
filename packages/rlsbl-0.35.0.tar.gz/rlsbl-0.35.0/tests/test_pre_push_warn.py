"""Tests for the manual-push warning in pre_push_check.run_cmd."""

import json
from io import StringIO
from unittest.mock import patch

import pytest

from conftest import run_git as _run_git, git_head as _git_head
from rlsbl.commands.pre_push_check import (
    _get_release_branches,
    _warn_if_manual_release_push,
    run_cmd,
)


WARN_MARKER = "Manual push to release branch"


@pytest.fixture
def jsonl_git_repo(tmp_path, monkeypatch):
    """Mirror of test_pre_push_check.jsonl_git_repo: minimal repo with
    .rlsbl/changes/ in place so the run_cmd flow runs to completion.
    """
    repo = tmp_path / "repo"
    repo.mkdir()
    monkeypatch.chdir(repo)

    _run_git(repo, "init", "-q")
    _run_git(repo, "config", "user.email", "test@test.local")
    _run_git(repo, "config", "user.name", "Test")

    (repo / "README.md").write_text("# test\n")
    _run_git(repo, "add", "README.md")
    _run_git(repo, "commit", "-q", "-m", "initial")
    _run_git(repo, "tag", "v0.0.0")

    changes = repo / ".rlsbl" / "changes"
    changes.mkdir(parents=True)
    (changes / "unreleased.jsonl").write_text("")

    # Ensure RLSBL_RELEASE_PUSH is NOT inherited from the surrounding env.
    monkeypatch.delenv("RLSBL_RELEASE_PUSH", raising=False)

    return repo


def _push_stdin(local_ref, sha, remote_ref=None, remote_sha=None):
    """Build a single-line pre-push hook stdin payload."""
    remote_ref = remote_ref or local_ref
    remote_sha = remote_sha or "0" * 40
    return f"{local_ref} {sha} {remote_ref} {remote_sha}\n"


def _add_covered_commit(repo, filename="src.py", message="feat: covered"):
    """Add a commit and write a JSONL entry covering it.

    Returns a tuple ``(base_sha, head_sha)`` where base_sha is the SHA before
    the new commits (use as the pre-push hook's ``remote_sha``) and head_sha
    is the new HEAD (use as ``local_sha``).
    """
    base_sha = _git_head(repo)
    (repo / filename).write_text("x = 1\n")
    _run_git(repo, "add", filename)
    _run_git(repo, "commit", "-q", "-m", message)
    sha = _git_head(repo)
    entry = {
        "commits": [sha],
        "user_facing": True,
        "description": "covered",
        "type": "feature",
    }
    (repo / ".rlsbl" / "changes" / "unreleased.jsonl").write_text(
        json.dumps(entry) + "\n"
    )
    _run_git(repo, "add", ".rlsbl/changes/unreleased.jsonl")
    _run_git(repo, "commit", "-q", "-m", "changelog: covered")
    return base_sha, _git_head(repo)


class TestWarnSuppressedWhenEnvSet:
    """RLSBL_RELEASE_PUSH=1 suppresses the warning even on main push."""

    def test_no_warning_when_env_set(self, jsonl_git_repo, monkeypatch, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/main", sha, remote_sha=base)

        monkeypatch.setenv("RLSBL_RELEASE_PUSH", "1")
        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER not in captured.err
        assert WARN_MARKER not in captured.out
        assert exc_info.value.code == 0


class TestWarnOnManualMainPush:
    """Without the env var, a push to main triggers the warning."""

    def test_warning_printed(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/main", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER in captured.err
        # Hook still exits 0 -- warning is non-blocking.
        assert exc_info.value.code == 0

    def test_warning_printed_for_master(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/master", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER in captured.err
        assert exc_info.value.code == 0


class TestNoWarnOnFeatureBranch:
    """Feature-branch pushes never warn."""

    def test_feature_branch_no_warning(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/foo", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER not in captured.err
        assert exc_info.value.code == 0


class TestWarningGoesToStderr:
    """Verify the warning goes to stderr, not stdout."""

    def test_stderr_not_stdout(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/main", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit):
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER in captured.err
        assert WARN_MARKER not in captured.out


class TestExitsZeroWhenWarning:
    """The hook exits 0 (doesn't block) even when it prints a warning."""

    def test_exits_zero(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/main", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER in captured.err
        assert exc_info.value.code == 0


class TestTagOnlyPushNoWarning:
    """Pushing only tags (no branch refs) does not trigger the warning."""

    def test_tag_only_no_warning(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        # Non-version tag (a version tag would also bypass the JSONL check,
        # but here we want to verify the warning path explicitly).
        # For tag pushes we still pass base as remote_sha so coverage only
        # looks at our new commits, not the initial commit.
        stdin_data = _push_stdin("refs/tags/some-label", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER not in captured.err
        # JSONL check passes (commit is covered) -> exit 0.
        assert exc_info.value.code == 0

    def test_version_tag_only_no_warning(self, jsonl_git_repo, capsys):
        """A version-tag push bypasses everything (including the warning)."""
        repo = jsonl_git_repo
        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/tags/v1.0.0", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER not in captured.err
        assert exc_info.value.code == 0


class TestReleaseBranchesConfigOverride:
    """release_branches config override changes which branches warn."""

    def test_override_excludes_main(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        # Configure release_branches to only contain "develop"
        config_dir = repo / ".rlsbl"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "config.json").write_text(
            json.dumps({"release_branches": ["develop"]})
        )

        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/main", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER not in captured.err
        assert exc_info.value.code == 0

    def test_override_includes_develop(self, jsonl_git_repo, capsys):
        repo = jsonl_git_repo
        config_dir = repo / ".rlsbl"
        config_dir.mkdir(exist_ok=True)
        (config_dir / "config.json").write_text(
            json.dumps({"release_branches": ["develop"]})
        )

        base, sha = _add_covered_commit(repo)
        stdin_data = _push_stdin("refs/heads/develop", sha, remote_sha=base)

        with patch("sys.stdin", StringIO(stdin_data)), \
             patch("sys.stdin.isatty", return_value=False):
            with pytest.raises(SystemExit) as exc_info:
                run_cmd(None, [], {})

        captured = capsys.readouterr()
        assert WARN_MARKER in captured.err
        assert exc_info.value.code == 0


class TestGetReleaseBranches:
    """Unit tests for the _get_release_branches helper."""

    def test_default_when_no_config(self, tmp_project):
        assert _get_release_branches() == ["main", "master"]

    def test_default_when_key_missing(self, tmp_project):
        (tmp_project / ".rlsbl").mkdir()
        (tmp_project / ".rlsbl" / "config.json").write_text(json.dumps({"other": 1}))
        assert _get_release_branches() == ["main", "master"]

    def test_override(self, tmp_project):
        (tmp_project / ".rlsbl").mkdir()
        (tmp_project / ".rlsbl" / "config.json").write_text(
            json.dumps({"release_branches": ["trunk", "stable"]})
        )
        assert _get_release_branches() == ["trunk", "stable"]

    def test_empty_list_raises(self, tmp_project):
        """An empty list would silently disable the warning entirely.
        Treat it as a configuration error: the user should remove the key
        to opt back into the default, or list at least one branch.
        """
        (tmp_project / ".rlsbl").mkdir()
        (tmp_project / ".rlsbl" / "config.json").write_text(
            json.dumps({"release_branches": []})
        )
        with pytest.raises(ValueError) as excinfo:
            _get_release_branches()
        msg = str(excinfo.value)
        assert ".rlsbl/config.json" in msg
        assert "release_branches" in msg
        assert "empty list" in msg
        # Suggests the recovery path
        assert "Remove the key" in msg or "remove the key" in msg

    def test_non_list_raises(self, tmp_project):
        """A non-list value (string, dict, int) is also a configuration error."""
        (tmp_project / ".rlsbl").mkdir()
        (tmp_project / ".rlsbl" / "config.json").write_text(
            json.dumps({"release_branches": "main"})
        )
        with pytest.raises(ValueError) as excinfo:
            _get_release_branches()
        msg = str(excinfo.value)
        assert ".rlsbl/config.json" in msg
        assert "release_branches" in msg
        assert "list" in msg


class TestWarnHelperDirect:
    """Direct tests of the _warn_if_manual_release_push helper."""

    def test_env_set_skips(self, monkeypatch, capsys):
        monkeypatch.setenv("RLSBL_RELEASE_PUSH", "1")
        _warn_if_manual_release_push(
            ["refs/heads/main abc refs/heads/main def"]
        )
        assert WARN_MARKER not in capsys.readouterr().err

    def test_empty_lines_no_warn(self, monkeypatch, capsys):
        monkeypatch.delenv("RLSBL_RELEASE_PUSH", raising=False)
        _warn_if_manual_release_push([])
        assert WARN_MARKER not in capsys.readouterr().err

    def test_none_lines_no_warn(self, monkeypatch, capsys):
        monkeypatch.delenv("RLSBL_RELEASE_PUSH", raising=False)
        _warn_if_manual_release_push(None)
        assert WARN_MARKER not in capsys.readouterr().err
