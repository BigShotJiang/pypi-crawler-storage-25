# rlsbl

Release orchestration and project scaffolding CLI. Automates the full release lifecycle for npm, PyPI, and Go projects: version bumping, changelog validation, git tagging, GitHub Release creation, CI/CD scaffolding, and CI monitoring.

Built in Python 3.11+ (one dependency: tomlkit), also distributed as an npm wrapper package. Current version: check `package.json`.

Key commands:

- `rlsbl release [patch|minor|major]` -- bump version, tag, push, create GitHub Release
- `rlsbl scaffold [--update|--force]` -- generate/update CI/CD workflows, hooks, changelog, license. Supports `--dry-run` to preview changes without writing.
- `rlsbl status` -- show version, branch, last tag, changelog coverage
- `rlsbl watch <sha>` -- poll CI status for a commit
- `rlsbl undo` -- revert the last release (delete tag, GH release, revert commit)
- `rlsbl check <name> --target <r>` -- check name availability on npm/PyPI
- `rlsbl dev install` -- locally install the project for development (editable). Defaults to `--global` (e.g. `uv tool install -e`, `npm link`, `go install`). Use `--venv` for the project's local environment, `--uninstall` to reverse. In monorepo mode, requires `--all`, `--include`, or `--exclude`. Supports pypi, npm, go, cargo, hex, deno, zig, swift targets.
- `rlsbl discover` -- list rlsbl ecosystem projects via GitHub topics
- `rlsbl monorepo {init,add,sync,...}` -- manage monorepo workspaces. Each subcommand supports `--no-commit` to skip its auto-commit.
- `rlsbl changelog add` -- append a JSONL entry. Auto-commits; pass `--no-commit` to skip.

## Release workflow

This project uses [rlsbl](https://github.com/smm-h/rlsbl) for release orchestration.

- Update CHANGELOG.md with a `## X.Y.Z` entry describing changes
- Run `rlsbl release [patch|minor|major]` to bump version and create a GitHub Release
- CI handles publishing automatically via the publish workflow
- Never publish manually — always use `rlsbl release`
- Requires NPM_TOKEN secret on GitHub (Settings > Secrets > Actions)
- Use `rlsbl release --dry-run` to preview a release without making changes

## Conventions

- No tokens or secrets in command-line arguments (use env vars or config files)
- All file writes to shared state should be atomic (write to tmp, then rename)
- External calls (APIs, CLI tools) must have timeouts and graceful fallbacks
- Use `rlsbl dev install` for local editable installs (it picks the right tool per target: `uv tool install -e` for pypi, `npm link` for npm, `go install` for go, etc.)
- CI runs smoke tests on every push; manual testing for UI/UX changes

## Configuration

`.rlsbl/config.json` holds per-project settings. Notable keys:

- `publish` -- per-target publish configuration (e.g. `publish.pypi`, `publish.npm`, `publish.docker`). Each entry can set:
    - `local` (bool) -- whether to publish from the developer machine; when `false`, the local publish step is skipped and CI handles it.
    - `token_var` -- name of the env var holding the publish token (used by pypi, npm, hex, deno, maven, etc.)
    - `username_var` / `password_var` -- name of the env vars for username/password auth (used by docker)
- `release_branches` -- list of branch names that trigger the manual-release-push warning. Defaults to `["main", "master"]` when the key is absent. An empty list is now an error -- either remove the key or list at least one branch.
- `batch_limits` -- limits and exclusions for the `batch_size_commits` and `batch_size_entries` changelog validation checks. Both checks are blocking errors when they fail. Keys:
    - `max_commits_per_entry` (int, default `5`) -- maximum number of commit hashes allowed in a single JSONL entry. Larger batches usually indicate a missed split of mixed changes.
    - `max_entries_per_commit` (int, default `5`) -- maximum number of JSONL entries (across all versioned files plus `unreleased.jsonl`) that may reference the same commit hash. A higher count almost always means a retroactive correction or an entry was duplicated by mistake.
    - `exclusions` (list of dicts, default `[]`) -- per-violation silencers. Each exclusion must have a `reason` (string, mandatory audit trail) plus at least one of:
        - `commits` (list of hashes) -- exempted from `max_entries_per_commit`.
        - `entries` (list of `{version, line}` objects) -- exempted from `max_commits_per_entry`. `version` is the bare semver string (e.g. `"0.5.0"`) or `"unreleased"`; `line` is the 1-based line number inside that JSONL file.

## CI customization

Add custom GitHub Actions jobs via the user-owned `.github/workflows/ci-custom.yml` and `publish-custom.yml` files. Scaffold never touches them, so they survive `scaffold --update`'s three-way merge. See `docs/ci-customization.md` for the pattern.

## Pre-push hook

`.git/hooks/pre-push` runs `rlsbl pre-push-check`, which:

- enforces JSONL commit coverage for every pushed commit (hard error -- blocks the push)
- warns when a push targets a release branch but did not originate from `rlsbl release` / `rlsbl undo`

The release/undo commands set `RLSBL_RELEASE_PUSH=1` in the push environment so the hook recognises legitimate release pushes and suppresses the warning. Users should not set this env var directly -- it is an internal contract between rlsbl and its own git hook.

## Validation cache

`rlsbl changelog validate` writes `.rlsbl/changes/.validated` (the SHA of the last successfully validated HEAD) so subsequent invocations can short-circuit when nothing has changed. The cache file is auto-committed with an `Autogenerated: true` trailer so it persists across sessions and machines. That auto-commit is exempted from changelog coverage requirements, but it still shows up in `git log`, which is why `rlsbl status` may report "1 commit behind v0.X.0" immediately after a release -- this is by design, not a bug. The next release recognises the trailer and skips the entry requirement automatically.
