import dataclasses
from typing import Any, TypeVar

import factory
from faker import Faker

from easyfactory.utils import is_optional, select_generator_for_type, make_factory_class

fake = Faker()

T = TypeVar("T", bound=Any)


def _is_required_field(field: dataclasses.Field) -> bool:
    """
    Check if a dataclass field is required (has no default value).

    :param field: The dataclass field to check.
    :return: True if the field is required, False otherwise.
    """
    return field.default is dataclasses.MISSING and field.default_factory is dataclasses.MISSING


def _select_generator(field_name: str, type_: type, model_fields):
    if field_name.endswith("_id") and field_name[:-3] in model_fields:
        return factory.SelfAttribute(f"{field_name[:-3]}.id")
    return select_generator_for_type(field_name, type_,
                                     lambda t: factory.SubFactory(DataclassFactoryGenerator.make_factory_for(t)))


class DataclassFactoryGenerator:
    """
    A class responsible for generating dataclass factories dynamically based on provided attributes.
    """
    generated_factories: dict[tuple[int, str], factory.Factory | None] = {}

    @classmethod
    def make_dataclass_factory(cls, model: T, attributes: dict[str, Any]):
        """
        Generates a factory for the given dataclass with the specified attributes.

        :param model: The dataclass for which the factory is generated.
        :type model: Type[T]
        :param attributes: Dictionary containing additional attributes to be included in the factory.
        :type attributes: dict[str, Any]
        :return: A dynamically generated dataclass factory class.
        :rtype: factory.Factory
        """
        model_fields = model.__dataclass_fields__
        attrs = {
            field: _select_generator(field, field_info.type, model_fields) if not is_optional(
                field_info.type) else None
            for field, field_info in model_fields.items() if _is_required_field(field_info)
        }
        attrs.update(attributes)
        return make_factory_class(model, attrs)

    @classmethod
    def make_factory_for[T](cls, model: T, **attributes: Any) -> factory.Factory:
        """
        Generates a factory for the given dataclass with the specified attributes if not already existing otherwise
        return the existing one.

        :param model: The dataclass for which the factory is generated.
        :type model: Type[T]
        :param attributes: Additional attributes to be included in the factory.
        :type attributes: Any
        :return: A factory class for the given dataclass.
        :rtype: factory.Factory
        """
        if (key := (id(model), str(attributes))) not in cls.generated_factories:
            cls.generated_factories[key] = None  # tell sub factory to not generate this value
            cls.generated_factories[key] = cls.make_dataclass_factory(model, attributes)
        return cls.generated_factories[key]
