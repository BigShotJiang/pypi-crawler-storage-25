import pytest
import os
from pathlib import Path
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import (
    DictionaryEntry, 
    GraphTriplet, 
    CommunityReport, 
    GlobalReport, 
    UsageExample
)

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test_graph_sieve.db"
    storage = SQLiteStorage(db_path)
    return storage

def test_upsert_and_get_entry(temp_db):
    entry = DictionaryEntry(
        term="Test Term",
        overview="A test overview.",
        source_file="test.txt",
        usage_examples=[UsageExample(context="Test context", source="test.txt")],
        related_terms=["Other Term"]
    )
    temp_db.upsert_entry(entry)
    
    retrieved = temp_db.get_entry("Test Term")
    assert retrieved is not None
    assert retrieved.term == entry.term
    assert retrieved.overview == entry.overview
    assert len(retrieved.usage_examples) == 1
    assert retrieved.usage_examples[0].context == "Test context"
    assert retrieved.related_terms == ["Other Term"]

def test_list_entries(temp_db):
    entry1 = DictionaryEntry(term="Term 1", overview="Overview 1", source_file="src1.txt")
    entry2 = DictionaryEntry(term="Term 2", overview="Overview 2", source_file="src2.txt")
    
    temp_db.upsert_entry(entry1)
    temp_db.upsert_entry(entry2)
    
    entries = temp_db.list_entries()
    assert len(entries) == 2
    terms = [e.term for e in entries]
    assert "Term 1" in terms
    assert "Term 2" in terms

def test_add_and_get_relationships(temp_db):
    triplet = GraphTriplet(
        subject="A",
        relationship="USES",
        object="B",
        anchor="A uses B",
        source_file="test.txt"
    )
    temp_db.add_relationship(triplet)
    
    rels = temp_db.get_relationships(subject="A")
    assert len(rels) == 1
    assert rels[0].subject == "A"
    assert rels[0].object == "B"
    assert rels[0].relationship == "USES"

def test_upsert_and_get_community_report(temp_db):
    report = CommunityReport(
        community_id="comm1",
        title="Community 1",
        summary="A summary.",
        nodes=["node1", "node2"]
    )
    temp_db.upsert_community_report(report)
    
    retrieved = temp_db.get_community_report("comm1")
    assert retrieved is not None
    assert retrieved.title == "Community 1"
    assert retrieved.nodes == ["node1", "node2"]

def test_upsert_and_get_global_report(temp_db):
    report = GlobalReport(
        summary="Global summary.",
        key_themes=["Theme 1", "Theme 2"]
    )
    temp_db.upsert_global_report(report)
    
    retrieved = temp_db.get_global_report()
    assert retrieved is not None
    assert retrieved.summary == "Global summary."
    assert retrieved.key_themes == ["Theme 1", "Theme 2"]
