import pytest
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import GraphTriplet, DictionaryEntry, UsageExample

@pytest.fixture
def temp_db(tmp_path):
    db_path = tmp_path / "test_graph_sieve_engine.db"
    storage = SQLiteStorage(db_path)
    return storage

def test_build_nx_graph_from_db(temp_db):
    # Setup DB
    triplet = GraphTriplet(
        subject="A",
        relationship="USES",
        object="B",
        anchor="A uses B",
        source_file="test.txt",
        weight=0.8
    )
    temp_db.add_relationship(triplet)
    
    # Engine with storage
    engine = GraphKnowledgeEngine(storage=temp_db)
    G = engine.build_nx_graph()
    
    assert G.has_edge("A", "B")
    assert G.edges["A", "B"]["weight"] == 0.8
    assert G.edges["A", "B"]["type"] == "USES"

def test_get_neighbors_from_db(temp_db):
    # Setup DB
    rel1 = GraphTriplet(subject="A", relationship="USES", object="B", anchor="...", source_file="...")
    rel2 = GraphTriplet(subject="C", relationship="DEPENDS_ON", object="A", anchor="...", source_file="...")
    temp_db.add_relationship(rel1)
    temp_db.add_relationship(rel2)
    
    engine = GraphKnowledgeEngine(storage=temp_db)
    neighbors = engine.get_neighbors("A")
    
    assert len(neighbors) == 2
    subjects = [r.subject for r in neighbors]
    objects = [r.object for r in neighbors]
    assert "A" in subjects
    assert "B" in objects
    
    relationships = [r.relationship for r in neighbors]
    assert "USES" in relationships
    assert "IS_DEPENDED_ON_BY" in relationships
    
    # Check inverse
    a_neighbors = [r for r in neighbors if r.subject == "A"]
    assert len(a_neighbors) == 2
    targets = [r.object for r in a_neighbors]
    assert "B" in targets
    assert "C" in targets

def test_generate_community_reports_from_db(temp_db, mocker):
    # Setup DB
    entry_a = DictionaryEntry(term="A", overview="Overview A", source_file="...")
    entry_b = DictionaryEntry(term="B", overview="Overview B", source_file="...")
    temp_db.upsert_entry(entry_a)
    temp_db.upsert_entry(entry_b)
    
    rel = GraphTriplet(subject="A", relationship="USES", object="B", anchor="...", source_file="...", weight=1.0)
    temp_db.add_relationship(rel)
    
    # Mock LLM client
    mock_client = mocker.Mock()
    mock_client.chat.return_value = "Mocked Community Report"
    mocker.patch("src.graph_sieve.graph_engine.get_llm_client", return_value=mock_client)
    
    engine = GraphKnowledgeEngine(storage=temp_db)
    engine.generate_community_reports()
    
    reports = temp_db.get_all_community_reports()
    assert len(reports) > 0
    report = reports[0]
    assert report.summary == "Mocked Community Report"
    
    # Verify it was saved to DB
    db_report = temp_db.get_community_report(report.community_id)
    assert db_report is not None
    assert db_report.summary == "Mocked Community Report"