import sys
import os
import pytest

# Add src to sys.path to allow importing graph_sieve
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '..', 'src')))

from graph_sieve.graph_engine import GraphKnowledgeEngine
from graph_sieve.storage_sqlite import SQLiteStorage
from graph_sieve.models import GraphTriplet

def test_louvain_communities(tmp_path):
    engine = GraphKnowledgeEngine(storage=SQLiteStorage(db_path=tmp_path / "test.db"))
    # Cluster 1
    engine.add_triplet(GraphTriplet(subject="A", relationship="ALIAS_OF", object="B", anchor="...", source_file="..."))
    engine.add_triplet(GraphTriplet(subject="B", relationship="ALIAS_OF", object="C", anchor="...", source_file="..."))
    engine.add_triplet(GraphTriplet(subject="C", relationship="ALIAS_OF", object="A", anchor="...", source_file="..."))
    
    # Cluster 2
    engine.add_triplet(GraphTriplet(subject="X", relationship="ALIAS_OF", object="Y", anchor="...", source_file="..."))
    engine.add_triplet(GraphTriplet(subject="Y", relationship="ALIAS_OF", object="Z", anchor="...", source_file="..."))
    engine.add_triplet(GraphTriplet(subject="Z", relationship="ALIAS_OF", object="X", anchor="...", source_file="..."))
    
    # Weak link (weight 0.2 for REPLACES)
    engine.add_triplet(GraphTriplet(subject="C", relationship="REPLACES", object="X", anchor="...", source_file="..."))
    
    communities = engine.cluster_communities()
    assert len(communities) == 2
    
    communities_low = engine.cluster_communities(prune_threshold=0.1)
    assert len(communities_low) == 2

if __name__ == "__main__":
    test_louvain_communities(None)
    print("Test passed!")