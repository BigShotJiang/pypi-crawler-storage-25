import pytest
import os
import shutil
from unittest.mock import patch, MagicMock
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.models import DictionaryEntry, GraphTriplet, UsageExample

@pytest.fixture
def agent(tmp_path):
    db_path = tmp_path / "test_extended.db"
    from src.graph_sieve.storage_sqlite import SQLiteStorage
    storage = SQLiteStorage(db_path=db_path)
    return DictionaryAgent(storage=storage)

def test_process_directory_with_seeds(agent, tmp_path):
    # Setup directory structure
    project_dir = tmp_path / "project"
    project_dir.mkdir()
    seed_file = project_dir / "seed.txt"
    seed_file.write_text("This is a seed document.")
    
    other_file = project_dir / "other.txt"
    other_file.write_text("This is another document.")
    
    # Configure agent with seed
    agent.seed_paths = [str(seed_file)]
    
    mock_discovery = [{"term": "SeedTerm", "overview": "Seed Overview", "entity_type": "PROJECT", "relationships": []}]
    mock_validation = {"is_valid": True, "confidence_level": "GOLD", "status": "PASS"}
    
    with patch("src.graph_sieve.agent.extract_all", return_value="Some content"), \
         patch("src.graph_sieve.agent.extract_with_llm", return_value=mock_discovery), \
         patch("src.graph_sieve.agent.validate_with_llm", return_value=mock_validation), \
         patch.object(agent.graph_engine, "generate_community_reports"), \
         patch.object(agent.graph_engine, "generate_global_narrative"):
        
        agent.process_directory(str(project_dir))
        
        assert agent.storage.get_term_exists("SeedTerm")
        assert agent.storage.get_entry("SeedTerm").authority_level == "SEED"

def test_get_bounty_hints(agent):
    # Add pending entries
    agent.storage.upsert_entry(DictionaryEntry(
        term="Term1", overview="[PENDING]", source_file="f1.txt", status="PENDING_DEFINITION", document_count=5, is_bounty=True
    ))
    agent.storage.upsert_entry(DictionaryEntry(
        term="Term2", overview="[PENDING]", source_file="f2.txt", status="PENDING_DEFINITION", document_count=3, is_bounty=True
    ))
    agent.storage.upsert_entry(DictionaryEntry(
        term="Term3", overview="Def", source_file="f3.txt", status="ACTIVE", document_count=10
    ))
    
    hints = agent.get_bounty_hints()
    assert "Term1" in hints
    assert "Term2" in hints
    assert "Term3" not in hints

def test_merge_conflicting_definitions(agent):
    existing = DictionaryEntry(
        term="Conflict", overview="Old Overview", source_file="f1.txt", confidence_level="GOLD"
    )
    new_item = {
        "term": "Conflict",
        "overview": "New Overview",
        "confidence_level": "GOLD",
        "deep_dive": "New technical details"
    }
    
    mock_synthesized = {"overview": "Synthesized Overview", "deep_dive": "Synthesized Technical"}
    
    with patch("src.graph_sieve.agent.get_llm_client") as mock_get_client:
        mock_client = MagicMock()
        mock_get_client.return_value = mock_client
        mock_client.chat.return_value = mock_synthesized
        
        result = agent.merge_conflicting_definitions(existing, new_item)
        
        assert result is True
        assert existing.overview == "Synthesized Overview"
        assert existing.deep_dive == "Synthesized Technical"
        assert existing.confidence_level == "GOLD"

def test_reconcile_supersedes(agent):
    agent.storage.upsert_entry(DictionaryEntry(
        term="OldTerm", overview="Old", source_file="f1.txt", status="ACTIVE"
    ))
    rel = GraphTriplet(subject="OldTerm", relationship="DEPENDS_ON", object="X", anchor="...", source_file="...")
    agent.storage.add_relationship(rel)
    
    agent.reconcile_supersedes("NewTerm", "OldTerm")
    
    assert agent.storage.get_entry("OldTerm").status == "LEGACY"
    # Relationships aren't directly fetched by ID but subject, so checking length or getting it by subject is better
    rels = agent.storage.get_relationships(subject="OldTerm")
    assert rels[0].status == "LEGACY"

def test_generate_summary(agent):
    agent.storage.upsert_entry(DictionaryEntry(
        term="Term1", overview="Overview 1", source_file="f1.txt", document_count=10, confidence_level="GOLD"
    ))
    from src.graph_sieve.models import GlobalReport
    agent.storage.upsert_global_report(GlobalReport(summary="Global Summary", key_themes=["Theme1"]))
    
    summary = agent.generate_summary()
    assert "Term1" in summary
    assert "Global Summary" in summary
    assert "Theme1" in summary

def test_extract_all_error_handling(agent, tmp_path):
    test_file = tmp_path / "error.txt"
    test_file.write_text("content")
    
    with patch("src.graph_sieve.agent.extract_all", return_value="[Error] Could not read file"):
        added = agent.process_document(str(test_file))
        assert added == []