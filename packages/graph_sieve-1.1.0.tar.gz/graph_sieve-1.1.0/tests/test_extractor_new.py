import pytest
import os
from unittest.mock import MagicMock, patch

from src.graph_sieve.extractor import extract_all, extract_text_from_txt, extract_text_from_one
from src.graph_sieve.hebrew_utils import normalize_rtl_text

# Mock MarkItDown.convert for consistent testing across various document types
class MockMarkItDownResult:
    def __init__(self, text_content):
        self.text_content = text_content

@pytest.fixture(autouse=True)
def mock_vlm_client():
    with patch("src.graph_sieve.extractor.get_vlm_client_for_markitdown") as mock:
        mock.return_value = MagicMock()
        yield mock

@pytest.fixture
def mock_markitdown_convert():
    with patch("markitdown.MarkItDown.convert") as mock_convert:
        # Default mock behavior: return a simple text_content
        mock_convert.return_value = MockMarkItDownResult(text_content="Mocked content from MarkItDown")
        yield mock_convert

@pytest.fixture
def mock_extract_text_from_txt():
    with patch("src.graph_sieve.extractor.extract_text_from_txt") as mock_txt:
        mock_txt.return_value = "Mocked content from extract_text_from_txt"
        yield mock_txt

@pytest.fixture
def mock_extract_text_from_one():
    with patch("src.graph_sieve.extractor.extract_text_from_one") as mock_one:
        mock_one.return_value = "[OneNote extraction for test.one - text extraction limited in this version]"
        yield mock_one

def test_extract_all_pdf(mock_markitdown_convert, tmp_path):
    dummy_file = tmp_path / "test.pdf"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_called_once_with(str(dummy_file))
    assert "Mocked content from MarkItDown" in extracted_text

def test_extract_all_docx(mock_markitdown_convert, tmp_path):
    dummy_file = tmp_path / "test.docx"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_called_once_with(str(dummy_file))
    assert "Mocked content from MarkItDown" in extracted_text

def test_extract_all_pptx(mock_markitdown_convert, tmp_path):
    dummy_file = tmp_path / "test.pptx"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_called_once_with(str(dummy_file))
    assert "Mocked content from MarkItDown" in extracted_text

def test_extract_all_msg(mock_markitdown_convert, tmp_path):
    dummy_file = tmp_path / "test.msg"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_called_once_with(str(dummy_file))
    assert "Mocked content from MarkItDown" in extracted_text

def test_extract_all_html(mock_markitdown_convert, tmp_path):
    dummy_file = tmp_path / "test.html"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_called_once_with(str(dummy_file))
    assert "Mocked content from MarkItDown" in extracted_text

def test_extract_all_txt_custom_extractor_success(mock_markitdown_convert, mock_extract_text_from_txt, tmp_path):
    dummy_file = tmp_path / "test.txt"
    dummy_file.write_text("dummy content for text file")
    
    mock_extract_text_from_txt.return_value = "Custom extracted text from txt file"
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_not_called() # MarkItDown should not be called for .txt
    mock_extract_text_from_txt.assert_called_once_with(str(dummy_file))
    assert "Custom extracted text from txt file" in extracted_text

def test_extract_all_one(mock_extract_text_from_one, tmp_path):
    dummy_file = tmp_path / "test.one"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_extract_text_from_one.assert_called_once_with(str(dummy_file))
    assert "[OneNote extraction for test.one - text extraction limited in this version]" in extracted_text

def test_extract_all_unsupported_format(mock_markitdown_convert, tmp_path):
    dummy_file = tmp_path / "test.xyz"  # Unsupported extension
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    mock_markitdown_convert.assert_not_called()
    assert extracted_text == ""

def test_extract_all_applies_rtl_normalization(mock_markitdown_convert, tmp_path):
    hebrew_text = "פרויקט מיקום" # Hebrew text
    mock_markitdown_convert.return_value = MockMarkItDownResult(text_content=hebrew_text)
    dummy_file = tmp_path / "test.pdf"
    dummy_file.write_text("dummy content")
    
    extracted_text = extract_all(str(dummy_file))
    
    # Assert that the output is normalized (reversed for simple case)
    assert normalize_rtl_text(hebrew_text) in extracted_text

def test_extract_all_file_not_found():
    non_existent_file = "non_existent.pdf"
    extracted_text = extract_all(non_existent_file)
    assert "[Error: File not found non_existent.pdf]" in extracted_text
