import pytest
import os
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import CommunityReport, DictionaryEntry

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

def test_generate_global_narrative(temp_db):
    # Enable mocking
    os.environ["MOCK_LLM"] = "true"
    
    # Setup dictionary with community reports
    temp_db.upsert_entry(DictionaryEntry(term="A", overview="Desc A", source_file="f1.txt"))
    temp_db.upsert_entry(DictionaryEntry(term="B", overview="Desc B", source_file="f1.txt"))
    temp_db.upsert_entry(DictionaryEntry(term="C", overview="Desc C", source_file="f1.txt"))
    
    temp_db.upsert_community_report(CommunityReport(
        community_id="comm_0",
        title="Community 0",
        summary="Summary 0",
        nodes=["A", "B"]
    ))
    temp_db.upsert_community_report(CommunityReport(
        community_id="comm_1",
        title="Community 1",
        summary="Summary 1",
        nodes=["C"]
    ))
    
    engine = GraphKnowledgeEngine(storage=temp_db)
    engine.generate_global_narrative()
    
    report = temp_db.get_global_report()
    assert report is not None
    assert "synthesizing multiple communities" in report.summary
    assert len(report.key_themes) == 5
    assert "Theme1" in report.key_themes

def test_generate_global_narrative_empty(temp_db):
    engine = GraphKnowledgeEngine(storage=temp_db)
    engine.generate_global_narrative()
    assert temp_db.get_global_report() is None