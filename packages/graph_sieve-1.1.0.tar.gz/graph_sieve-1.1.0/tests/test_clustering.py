import pytest
from unittest.mock import patch, MagicMock
from src.graph_sieve.graph_engine import GraphKnowledgeEngine
from src.graph_sieve.storage_sqlite import SQLiteStorage
from src.graph_sieve.models import GraphTriplet, DictionaryEntry

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

def test_clustering_logic(temp_db):
    engine = GraphKnowledgeEngine(storage=temp_db)
    # Create two separate communities
    rels = [
        GraphTriplet(subject="A", relationship="ALIAS_OF", object="B", anchor="A is B", source_file="..."),
        GraphTriplet(subject="B", relationship="SUB_PROJECT_OF", object="C", anchor="B is part of C", source_file="..."),
        GraphTriplet(subject="X", relationship="ALIAS_OF", object="Y", anchor="X is Y", source_file="...")
    ]
    for r in rels: engine.add_triplet(r)

    communities = engine.cluster_communities(prune_threshold=0.1)
    assert len(communities) == 2

@patch('src.graph_sieve.graph_engine.get_llm_client')
def test_community_report_generation(mock_get_client, temp_db):
    mock_client = MagicMock()
    mock_get_client.return_value = mock_client
    mock_client.chat.return_value = "Mocked community report summary."

    engine = GraphKnowledgeEngine(storage=temp_db)
    temp_db.upsert_entry(DictionaryEntry(term="Prism", overview="Security suite", source_file="..."))
    temp_db.upsert_entry(DictionaryEntry(term="Cortex", overview="Identity manager", source_file="..."))
    
    rel = GraphTriplet(subject="Prism", relationship="DEPENDS_ON", object="Cortex", anchor="Prism depends on Cortex", source_file="...")
    engine.add_triplet(rel)
    
    engine.generate_community_reports()
    reports = temp_db.get_all_community_reports()
    assert len(reports) > 0
    assert reports[0].summary == "Mocked community report summary."
    mock_client.chat.assert_called_once()