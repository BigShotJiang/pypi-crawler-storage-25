import pytest
import os
from src.graph_sieve.agent import DictionaryAgent
from src.graph_sieve.storage_sqlite import SQLiteStorage
from unittest.mock import patch, MagicMock

@pytest.fixture
def temp_db(tmp_path):
    return SQLiteStorage(db_path=tmp_path / "test.db")

def test_full_workflow_end_to_end(temp_db):
    # 1. Setup mock data
    os.makedirs("tests/data", exist_ok=True)
    test_files = {
        "tests/data/readme.md": "Project Prism is a new security suite.",
        "tests/data/notes.txt": "Prism depends on project Cortex for identity."
    }
    
    for path, content in test_files.items():
        with open(path, "w", encoding="utf-8") as f:
            f.write(content)
            
    # 2. Setup Agent
    agent = DictionaryAgent(storage=temp_db)
    
    # 3. Process files
    with patch("src.graph_sieve.agent.extract_with_llm") as mock_extract, \
         patch("src.graph_sieve.agent.validate_with_llm") as mock_validate:

        # readme.md extraction
        mock_extract.side_effect = [
            [{"term": "Prism", "overview": "A security suite.", "anchor": "Project Prism", "entity_type": "PROJECT"}],
            [{
                "term": "Prism",
                "overview": "...",
                "anchor": "Prism depends on project Cortex",
                "entity_type": "PROJECT",
                "relationships": [{"target": "Cortex", "type": "DEPENDS_ON"}]
            }]
        ]        
        # validation
        mock_validate.return_value = {"is_valid": True, "status": "PASS"}
        
        agent.process_document("tests/data/readme.md")
        agent.process_document("tests/data/notes.txt")
        
    # 4. Verify results
    assert agent.storage.get_term_exists("Prism")
    rels = agent.storage.get_relationships()
    assert len(rels) == 1
    rel = rels[0]
    assert rel.subject == "Prism"
    assert rel.relationship == "DEPENDS_ON"
    assert rel.object == "Cortex"
    
    # 5. Verify graph walk
    context = agent.graph_engine.get_context_map("Prism")
    assert "DEPENDS_ON" in context
    assert "Cortex" in context