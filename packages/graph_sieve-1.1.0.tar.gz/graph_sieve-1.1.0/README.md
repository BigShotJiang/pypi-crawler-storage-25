# Graph-Sieve 🕸️📊

**Full Spectrum Graph Sieve - Automated Technical Term Extraction and Relationship Mapping**

`graph-sieve` is a standalone utility and service designed to extract relationship-aware domain knowledge from internal documents (.docx, .pptx, .msg, .pdf). It uses a multi-gate verifiable pipeline with local or remote models (OpenAI, Ollama, vLLM) to build a structured knowledge graph of technical terms and their relationships.

## Features

- **Multi-Gate Extraction**: A robust pipeline (Detection -> Extraction -> Validation) ensuring high-fidelity term capture.
- **Relationship Mapping**: Beyond simple term lookup—builds a Property Graph of how terms relate.
- **Multi-Format Support**: Handles PDF, PPTX, DOCX, MSG, and images (via OCR) using Microsoft **MarkItDown**.
- **Hebrew & Mixed-Language Handling**: Specialized BIDI (Bi-Directional) support for Hebrew-English technical documents, ensuring technical terms are correctly extracted from mixed-language contexts.
- **Flexible LLM Backend**: Run locally with Ollama/vLLM for privacy, or use OpenAI for scale.
- **Interactive Visualization**: Generate dynamic, relationship-aware graph visualizations.
- **MCP Server**: Integrated Model Context Protocol (MCP) server for seamless AI agent integration.

## Installation

```bash
pip install graph-sieve
```

## Quick Start

1.  **Configure Your LLM**:
    Create a `.env` file in your working directory:
    ```env
    LLM_PROVIDER=openai
    OPENAI_API_KEY=your_key_here
    ```
    *Or use Ollama (default):*
    ```env
    LLM_PROVIDER=ollama
    OLLAMA_BASE_URL=http://localhost:11434
    MODEL_NAME=llama3
    ```

2.  **Scan a Directory**:
    ```bash
    graph-sieve-scan ./path/to/documents --dict my_dictionary.json
    ```

3.  **Visualize the Results**:
    ```bash
    graph-sieve-visualize --dict my_dictionary.json
    ```

## CLI Commands

- `graph-sieve-scan`: Extract terms from a directory or file.
- `graph-sieve-lookup`: Query terms and their graph context.
- `graph-sieve-visualize`: Generate an interactive HTML graph.
- `graph-sieve-mcp`: Launch the MCP server.
- `graph-sieve-whois`: Find the source document for a specific term.

## Configuration (Environment Variables)

| Variable | Description | Default |
|----------|-------------|---------|
| `LLM_PROVIDER` | `openai`, `ollama`, or `vllm` | `ollama` |
| `OPENAI_API_KEY` | Required if using OpenAI | None |
| `OLLAMA_BASE_URL`| URL for Ollama API | `http://localhost:11434` |
| `MODEL_NAME` | Model to use for extraction | `gpt-4o-mini` / `llama3` |
| `STORAGE_DIR` | Directory for graph data | Platform-specific |

## AI Agent Integration

### Claude Desktop / Gemini CLI
To use Graph-Sieve as a tool, add it to your agent's config:

```json
{
  "mcpServers": {
    "graph-sieve": {
      "command": "graph-sieve-mcp",
      "args": []
    }
  }
}
```

## License

MIT License. See [LICENSE](LICENSE) for details.
