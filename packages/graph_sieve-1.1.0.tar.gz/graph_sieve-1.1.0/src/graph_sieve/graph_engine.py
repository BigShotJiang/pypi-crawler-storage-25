from typing import List, Dict, Any, Optional
import networkx as nx
from networkx.algorithms import community
from .models import GraphTriplet, DictionaryEntry, UsageExample, CommunityReport, GlobalReport, RELATION_WEIGHTS
from .llm_client import get_llm_client
from .storage_sqlite import SQLiteStorage
from .prompts import (
    COMMUNITY_REPORT_SYSTEM_TEMPLATE,
    COMMUNITY_REPORT_USER_TEMPLATE,
    GLOBAL_NARRATIVE_SYSTEM_TEMPLATE,
    GLOBAL_NARRATIVE_USER_TEMPLATE,
    THEME_EXTRACTION_SYSTEM_TEMPLATE
)

class GraphKnowledgeEngine:
    """
    Manages the Knowledge Graph state, clustering, and global reasoning.
    """
    def __init__(self, storage: SQLiteStorage):
        self.storage = storage

    def add_triplet(self, triplet: GraphTriplet):
        # 1. Assign weight based on relationship type
        triplet.weight = RELATION_WEIGHTS.get(triplet.relationship, 0.5)

        existing_rels = self.storage.get_relationships(subject=triplet.subject, object=triplet.object)
        for existing in existing_rels:
            if existing.relationship == triplet.relationship:
                # Update existing triplet if it has a lower weight (e.g. was BRONZE before)
                triplet.weight = max(existing.weight, triplet.weight)
                break
                
        self.storage.add_relationship(triplet)

    def get_neighbors(self, term: str) -> List[GraphTriplet]:
        """
        Returns all relationships for a term, ensuring they are oriented from the term's perspective.
        """
        from .models import RELATION_INVERSES
        results = []

        # Query DB for relationships where term is subject or object
        relationships = self.storage.get_relationships(subject=term)
        relationships += self.storage.get_relationships(object=term)

        # Use a dict to de-duplicate if necessary (though SQL UNIQUE should handle it)
        # but we need to handle the orientation/inverse logic
        seen = set()
        for r in relationships:
            # Create a unique key for the raw relationship
            key = (r.subject, r.relationship, r.object)
            if key in seen:
                continue
            seen.add(key)

            if r.subject == term:
                results.append(r)
            elif r.object == term:
                inverse_rel = RELATION_INVERSES.get(r.relationship, r.relationship)
                results.append(GraphTriplet(
                    subject=r.object,
                    relationship=inverse_rel,
                    object=r.subject,
                    anchor=r.anchor,
                    source_file=r.source_file,
                    weight=r.weight,
                    date_added=r.date_added,
                    status=r.status
                ))
        return results

    def build_nx_graph(self, prune_threshold: float = 0.0) -> nx.Graph:
        """
        Builds a NetworkX graph using weighted edges.
        Folds alias nodes into their canonical counterparts using both entries and the explicit aliases table.
        """
        G = nx.Graph()

        relationships = self.storage.get_relationships()
        entries = {e.term: e for e in self.storage.list_entries()}
        explicit_aliases = self.storage.get_all_aliases()

        # Combine alias mappings: explicit aliases take precedence
        canonical_map = {term: (entry.canonical_id or term) for term, entry in entries.items()}
        canonical_map.update(explicit_aliases)

        for rel in relationships:
            # Pitfall 2 Fix: Pruning weak edges before clustering
            if rel.weight < prune_threshold:
                continue

            # ALIAS_OF relationships are now included to ensure all nodes are part of the graph
            # unless we have a canonical mapping that folds them.

            u = canonical_map.get(rel.subject, rel.subject)
            v = canonical_map.get(rel.object, rel.object)

            if u == v:
                continue

            if G.has_edge(u, v):
                # Combine weights (max)
                G[u][v]['weight'] = max(G[u][v].get('weight', 0), rel.weight)
            else:
                G.add_edge(u, v, type=rel.relationship, weight=rel.weight)
        return G

    def cluster_communities(self, resolution: float = 1.0, prune_threshold: float = 0.3):
        """
        Groups nodes into communities using modularity-based clustering (Louvain).
        Identifies "neighborhoods" of terms that belong together even if they aren't directly linked in every chunk.
        """
        G = self.build_nx_graph(prune_threshold=prune_threshold)
        if G.number_of_nodes() == 0:
            return []
        
        # Identify dense semantic clusters
        communities = community.louvain_communities(G, weight='weight', resolution=resolution)
        return [list(c) for c in communities]

    def generate_community_reports(self, max_workers: int = 5):
        """
        Uses an LLM to summarize each community for global reasoning.
        """
        import concurrent.futures

        communities = self.cluster_communities()
        client = get_llm_client()

        def process_community(i, nodes):
            if len(nodes) < 2: return None
            
            # Gather all info for this community
            context = []
            for node in nodes:
                entry = self.storage.get_entry(node)

                if entry:
                    info = f"Term: {node}, Overview: {entry.overview}"
                    if entry.deep_dive:
                        info += f", Deep Dive: {entry.deep_dive}"
                    context.append(info)
            
            rels = []
            # This could be slow if done node-by-node, but we only need rels between nodes in the community.
            # A better way might be to get all rels and filter, or a specific query.
            # For now, let's get all rels if not already loaded.
            all_rels = self.storage.get_relationships()

            for rel in all_rels:
                if rel.subject in nodes and rel.object in nodes:
                    rels.append(f"{rel.subject} --{rel.relationship} ({rel.weight})--> {rel.object}")

            user_prompt = COMMUNITY_REPORT_USER_TEMPLATE.format(
                nodes_info="\n".join(context),
                relationships_info="\n".join(rels)
            )
            
            messages = [
                {"role": "system", "content": COMMUNITY_REPORT_SYSTEM_TEMPLATE},
                {"role": "user", "content": user_prompt}
            ]
            
            report_data = client.chat(messages, json_mode=False) # Get text summary
            
            report = CommunityReport(
                community_id=f"comm_{i}",
                title=f"Community {i}: " + ", ".join(nodes[:3]),
                summary=report_data,
                nodes=nodes
            )

            # Save to storage
            self.storage.upsert_community_report(report)
            
            return report

        with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
            # Submit all tasks
            future_to_community = {
                executor.submit(process_community, i, nodes): i 
                for i, nodes in enumerate(communities)
            }
            
            # Process results as they complete
            for future in concurrent.futures.as_completed(future_to_community):
                result = future.result()

    def generate_global_narrative(self):
        """
        Synthesizes all community reports into a single Project Master Plan.
        """
        community_reports = self.storage.get_all_community_reports()
        if not community_reports:
            return
        
        client = get_llm_client()
        
        community_summaries = []
        for report in community_reports:
            community_summaries.append(f"Title: {report.title}\nNodes: {', '.join(report.nodes)}\nSummary: {report.summary}")
            
        full_context = "\n\n---\n\n".join(community_summaries)
        
        messages = [
            {"role": "system", "content": GLOBAL_NARRATIVE_SYSTEM_TEMPLATE},
            {"role": "user", "content": GLOBAL_NARRATIVE_USER_TEMPLATE.format(community_reports=full_context)}
        ]
        
        narrative = client.chat(messages, json_mode=False)
        
        # Extract key themes
        theme_messages = [
            {"role": "system", "content": THEME_EXTRACTION_SYSTEM_TEMPLATE},
            {"role": "user", "content": narrative}
        ]
        themes_raw = client.chat(theme_messages, json_mode=False)
        themes = [t.strip() for t in themes_raw.split(",") if t.strip()]
        
        global_report = GlobalReport(
            summary=narrative,
            key_themes=themes
        )

        self.storage.upsert_global_report(global_report)

    def get_context_map(self, term: str) -> str:
        neighbors = self.get_neighbors(term)
        
        entry = self.storage.get_entry(term)
        
        lines = [f"Knowledge Graph Context for '{term}':"]
        if entry:
            lines.append(f"Ubiquity: Found in {entry.document_count} unique documents.")
            lines.append(f"Confidence Level: {entry.confidence_level}")
            
        for r in neighbors:
            lines.append(f"- {r.subject} --[{r.relationship} (w:{r.weight})]--> {r.object}")
        
        # Add Community Summary if available
        reports = self.storage.get_all_community_reports()

        for report in reports:
            if term in report.nodes:
                lines.append(f"\nExecutive Summary (Community Context):\n{report.summary}")
                break
                
        return "\n".join(lines)

    def visualize_graph(self, output_path: str = None):
        """
        Generates an interactive HTML visualization of the knowledge graph.
        Implements Graph Folding: Aliases are merged into their canonical nodes.
        """
        from pyvis.network import Network
        import os
        from .config import settings

        if output_path is None:
            settings.ensure_dirs()
            output_path = str(settings.storage_dir / "graph.html")
        net = Network(height="750px", width="100%", bgcolor="#222222", font_color="white", directed=True, notebook=False)
        
        # Physics configuration for better layout
        net.force_atlas_2based()
        
        # Map entity types to colors (Base colors)
        type_colors = {
            "PROJECT": "#ff4b4b",   # Red
            "COMPONENT": "#4b4bff", # Blue
            "TECH_STACK": "#4bff4b",# Green
            "PERSON": "#ffff4b",    # Yellow
            "ORG": "#ff4bff"        # Purple
        }

        reports = self.storage.get_all_community_reports()

        # Community Color Map (Generates distinct colors for communities)
        import random
        community_colors = {}
        for report in reports:
            # Generate a random bright color for each community
            community_colors[report.community_id] = "#%06x" % random.randint(0, 0xFFFFFF)

        # Map nodes to communities
        node_to_community = {}
        for report in reports:
            for node in report.nodes:
                node_to_community[node] = report.community_id

        # Fetch entries and build canonical mapping
        entries = {e.term: e for e in self.storage.list_entries()}
        explicit_aliases = self.storage.get_all_aliases()

        canonical_map = {} # term -> canonical_term
        alias_groups = {}  # canonical_term -> list of alias terms

        for term, entry in entries.items():
            canonical = entry.canonical_id or term
            canonical_map[term] = canonical
            if canonical != term:
                if canonical not in alias_groups:
                    alias_groups[canonical] = []
                alias_groups[canonical].append(term)
        
        # Merge explicit aliases
        for alias, canonical in explicit_aliases.items():
            canonical_map[alias] = canonical
            if canonical != alias:
                if canonical not in alias_groups:
                    alias_groups[canonical] = []
                if alias not in alias_groups[canonical]:
                    alias_groups[canonical].append(alias)

        # Add canonical nodes
        for term, entry in entries.items():
            # Skip if this is an alias node (we only want canonical nodes)
            if entry.canonical_id and entry.canonical_id != term:
                continue
                
            comm_id = node_to_community.get(term)
            color = community_colors.get(comm_id) if comm_id else type_colors.get(entry.entity_type, "#97c2fc")
            
            # Node size based on aggregate document count of node + all its aliases
            doc_count = entry.document_count
            aliases = alias_groups.get(term, [])
            for alias in aliases:
                alias_entry = entries.get(alias)
                if alias_entry:
                    doc_count += alias_entry.document_count
            
            size = min(max(10, doc_count * 5), 50)
            
            # Tooltip shows the term and its aliases
            display_name = term
            if aliases:
                display_name += f" (Aliases: {', '.join(aliases)})"
                
            title = f"<b>{display_name}</b><br>{entry.overview}<br>Docs: {doc_count}"
            if comm_id:
                title += f"<br><b>Community: {comm_id}</b>"
            
            net.add_node(term, label=term, title=title, color=color, size=size, group=comm_id)

        # Add edges from relationships (folded to canonical nodes)
        relationships = self.storage.get_relationships()

        seen_edges = set()
        for rel in relationships:
            # Skip ALIAS_OF relationships as they are represented by folding
            if rel.relationship == "ALIAS_OF":
                continue

            # Redirect both ends to canonical nodes
            u = canonical_map.get(rel.subject, rel.subject)
            v = canonical_map.get(rel.object, rel.object)
            
            # Skip self-loops after folding
            if u == v:
                continue
                
            # De-duplicate edges between canonical nodes (keep strongest)
            edge_key = (u, v, rel.relationship)
            if edge_key in seen_edges:
                continue
            seen_edges.add(edge_key)

            # Ensure both nodes exist in the visual network
            if u not in net.nodes: # Should have been added above unless missing from entries
                net.add_node(u, label=u, color="#999999")
            if v not in net.nodes:
                net.add_node(v, label=v, color="#999999")
                
            # Edge width based on weight
            width = rel.weight * 5
            
            net.add_edge(u, v, label=rel.relationship, width=width, title=rel.anchor)

        # Save the graph
        net.save_graph(output_path)
        print(f"Graph visualization saved to: {os.path.abspath(output_path)}")
