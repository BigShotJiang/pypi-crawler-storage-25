from typing import List, Tuple, Dict, Optional, Any
import numpy as np
from .storage_sqlite import SQLiteStorage
from .llm_client import get_llm_client
from .hebrew_utils import is_hebrew
from .models import DictionaryEntry

class VectorResolver:
    """
    Identifies candidate alias pairs based on semantic vector similarity.
    Uses multilingual embeddings to bridge Hebrew and English terms.
    """
    def __init__(self, storage: SQLiteStorage, llm_client: Optional[Any] = None):
        self.storage = storage
        self.llm_client = llm_client or get_llm_client()
        self._embedding_cache: Dict[str, List[float]] = {}

    def discover_candidates(self, threshold: float = 0.7) -> List[Tuple[str, str, float]]:
        """
        Fetches all dictionary entries, generates embeddings for their terms,
        and returns pairs that have a cosine similarity above the threshold.
        
        Returns:
            List of (term1, term2, similarity_score)
        """
        entries = self.storage.list_entries()
        if not entries:
            return []
            
        terms = [e.term for e in entries]
        if len(terms) < 2:
            return []
            
        embeddings = []
        for term in terms:
            if term not in self._embedding_cache:
                # Generate and cache embedding
                emb = self.llm_client.get_embedding(term)
                self._embedding_cache[term] = emb
            embeddings.append(self._embedding_cache[term])
            
        # Convert to numpy array for efficient computation
        X = np.array(embeddings)
        
        # Normalize embeddings to unit length for cosine similarity
        norms = np.linalg.norm(X, axis=1, keepdims=True)
        # Handle zero vectors if any (though unlikely for embeddings)
        X_normalized = np.divide(X, norms, out=np.zeros_like(X), where=norms!=0)
        
        # Compute cosine similarity matrix via dot product
        # sim(i, j) = X_norm[i] . X_norm[j]
        sim_matrix = X_normalized @ X_normalized.T
        
        candidates = []
        n = len(terms)
        for i in range(n):
            for j in range(i + 1, n):
                score = sim_matrix[i, j]
                if score >= threshold:
                    # Return terms and the score (converted from numpy float)
                    candidates.append((terms[i], terms[j], float(score)))
                    
        # Sort by similarity score descending
        candidates.sort(key=lambda x: x[2], reverse=True)
        
        return candidates

class SemanticResolver:
    """
    Validates candidate alias pairs using LLM judgment.
    """
    def __init__(self, storage: SQLiteStorage, llm_client: Optional[Any] = None):
        self.storage = storage
        self.llm_client = llm_client or get_llm_client()

    def verify_and_map(self, candidates: List[Tuple[str, str, float]]):
        """
        Iterates through candidates, asks the LLM for verification,
        decides on canonical names, and links aliases in storage.
        """
        for term1, term2, score in candidates:
            # Check if either term already has a canonical mapping
            entry1 = self.storage.get_entry(term1)
            entry2 = self.storage.get_entry(term2)
            
            if not entry1 or not entry2:
                continue
                
            # If both already have the same canonical mapping, skip
            c1 = entry1.canonical_id or term1
            c2 = entry2.canonical_id or term2
            if c1 == c2:
                continue

            # LLM Prompt for verification
            prompt = [
                {"role": "system", "content": "You are a technical entity resolution expert. Your task is to determine if two terms refer to the exact same technical component, project, or concept."},
                {"role": "user", "content": f"""Do these two terms represent the same specific technical component? 
One might be a translation (Hebrew/English), an acronym, or a slight variation.

Term 1: {term1}
Overview 1: {entry1.overview}

Term 2: {term2}
Overview 2: {entry2.overview}

Respond with a JSON object:
{{
  "is_same": "YES" | "NO",
  "reasoning": "brief explanation"
}}"""}
            ]
            
            try:
                response = self.llm_client.chat(prompt, json_mode=True)
                if response.get("is_same") == "YES":
                    # Determine canonical name
                    canonical = self._decide_canonical(entry1, entry2)
                    alias = term2 if canonical == term1 else term1
                    
                    self.storage.link_alias(alias, canonical)
                    print(f"Linked alias: {alias} -> {canonical} ({response.get('reasoning')})")
            except Exception as e:
                print(f"Error resolving {term1} and {term2}: {e}")

    def _decide_canonical(self, entry1: DictionaryEntry, entry2: DictionaryEntry) -> str:
        """
        Decides which term should be the canonical one.
        Rule: Prefer English technical terms, then most frequent.
        """
        # 1. Prefer English (non-Hebrew)
        heb1 = is_hebrew(entry1.term)
        heb2 = is_hebrew(entry2.term)
        
        if heb1 and not heb2:
            return entry2.term
        if heb2 and not heb1:
            return entry1.term
            
        # 2. Prefer most frequent (document_count)
        if entry1.document_count > entry2.document_count:
            return entry1.term
        if entry2.document_count > entry1.document_count:
            return entry2.term
            
        # 3. Default to alphabetical if counts are equal
        return min(entry1.term, entry2.term)
