import json
import os
import requests
import sys
import time
import asyncio
import httpx
from typing import Dict, List, Any, Optional
from openai import OpenAI, OpenAIError, AsyncOpenAI
from tenacity import retry, stop_after_attempt, wait_exponential, retry_if_exception_type, AsyncRetrying
from .config import settings
from .telemetry import log_interaction

class LLMClientError(Exception):
    """Base class for LLM client errors with user-friendly messages."""
    pass

class LocalLLMClient:
    """
    Client for interacting with local Ollama/vLLM models.
    Supports JSON mode for structured extraction.
    """
    def __init__(self, base_url: str = None, model: str = None):
        self.base_url = base_url or settings.ollama_base_url
        self.model = model or settings.model_name

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((requests.exceptions.RequestException, LLMClientError)),
        reraise=True
    )
    def chat(self, messages: List[Dict[str, str]], json_mode: bool = True) -> Any:
        """
        Sends a chat request to the local LLM.
        """
        # Mock for environments where Ollama is not running
        if os.getenv("MOCK_LLM", "false").lower() == "true":
            return self._mock_response(messages, json_mode)

        endpoint = f"{self.base_url}/api/chat"
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "format": "json" if json_mode else None
        }
        
        start_time = time.time()
        try:
            response = requests.post(endpoint, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()
            content = data.get("message", {}).get("content", "")
            
            latency = (time.time() - start_time) * 1000
            log_interaction(
                provider="ollama",
                model=self.model,
                endpoint="/api/chat",
                prompt=messages,
                response=content,
                latency_ms=latency,
                prompt_tokens=data.get("prompt_eval_count", 0),
                completion_tokens=data.get("eval_count", 0)
            )
            
            if json_mode:
                try:
                    return json.loads(content)
                except json.JSONDecodeError:
                    print(f"Warning: LLM returned invalid JSON. Content: {content}")
                    return {}
            return content
        except requests.exceptions.ConnectionError as e:
            log_interaction(
                provider="ollama", model=self.model, endpoint="/api/chat",
                prompt=messages, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            raise LLMClientError(
                f"Could not connect to local LLM at {self.base_url}. "
                "Ensure Ollama/vLLM is running or set LLM_PROVIDER=openai and provide OPENAI_API_KEY."
            )
        except requests.exceptions.RequestException as e:
            log_interaction(
                provider="ollama", model=self.model, endpoint="/api/chat",
                prompt=messages, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            print(f"Warning: LLM request failed, retrying... ({e})")
            raise  # Let tenacity handle it
        except Exception as e:
            log_interaction(
                provider="ollama", model=self.model, endpoint="/api/chat",
                prompt=messages, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            print(f"Error calling local LLM: {e}")
            return self._mock_response(messages, json_mode)

    async def batch_chat(self, messages_list: List[List[Dict[str, str]]], json_mode: bool = True) -> List[Any]:
        """
        Sends multiple chat requests in parallel using asyncio and httpx.
        """
        if os.getenv("MOCK_LLM", "false").lower() == "true":
            return [self._mock_response(m, json_mode) for m in messages_list]

        async with httpx.AsyncClient(timeout=60) as client:
            tasks = [self._async_chat(client, messages, json_mode) for messages in messages_list]
            return await asyncio.gather(*tasks)

    async def _async_chat(self, client: httpx.AsyncClient, messages: List[Dict[str, str]], json_mode: bool) -> Any:
        endpoint = f"{self.base_url}/api/chat"
        payload = {
            "model": self.model,
            "messages": messages,
            "stream": False,
            "format": "json" if json_mode else None
        }
        
        start_time = time.time()
        
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(5),
            wait=wait_exponential(multiplier=1, min=2, max=30),
            retry=retry_if_exception_type((httpx.RequestError, LLMClientError)),
            reraise=True
        ):
            with attempt:
                try:
                    response = await client.post(endpoint, json=payload)
                    response.raise_for_status()
                    data = response.json()
                    content = data.get("message", {}).get("content", "")
                    
                    latency = (time.time() - start_time) * 1000
                    log_interaction(
                        provider="ollama",
                        model=self.model,
                        endpoint="/api/chat",
                        prompt=messages,
                        response=content,
                        latency_ms=latency,
                        prompt_tokens=data.get("prompt_eval_count", 0),
                        completion_tokens=data.get("eval_count", 0)
                    )
                    
                    if json_mode:
                        try:
                            return json.loads(content)
                        except json.JSONDecodeError:
                            print(f"Warning: LLM returned invalid JSON. Content: {content}")
                            return {}
                    return content
                except httpx.ConnectError as e:
                    raise LLMClientError(f"Could not connect to local LLM: {e}")
                except httpx.RequestError as e:
                    print(f"Warning: Async LLM request failed, retrying... ({e})")
                    raise

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((requests.exceptions.RequestException, LLMClientError)),
        reraise=True
    )
    def get_embedding(self, text: str) -> List[float]:
        """
        Returns vector embeddings for a string using local Ollama/vLLM.
        """
        if os.getenv("MOCK_LLM", "false").lower() == "true":
            return [0.0] * 1536  # Return dummy embedding

        endpoint = f"{self.base_url}/api/embeddings"
        payload = {
            "model": settings.embedding_model,
            "prompt": text
        }
        
        start_time = time.time()
        try:
            response = requests.post(endpoint, json=payload, timeout=60)
            response.raise_for_status()
            data = response.json()
            
            latency = (time.time() - start_time) * 1000
            log_interaction(
                provider="ollama",
                model=settings.embedding_model,
                endpoint="/api/embeddings",
                prompt=text,
                response="<embedding data>",
                latency_ms=latency
            )
            return data.get("embedding", [])
        except requests.exceptions.RequestException as e:
            log_interaction(
                provider="ollama", model=settings.embedding_model, endpoint="/api/embeddings",
                prompt=text, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            print(f"Warning: Embedding request failed, retrying... ({e})")
            raise
        except Exception as e:
            log_interaction(
                provider="ollama", model=settings.embedding_model, endpoint="/api/embeddings",
                prompt=text, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            raise LLMClientError(f"Error getting local embeddings: {e}")

    def _mock_response(self, messages: List[Dict[str, str]], json_mode: bool) -> Any:
        """
        Provides a fallback mock response for testing.
        """
        system_msg = ""
        for msg in messages:
            if msg["role"] == "system":
                system_msg = msg["content"].lower()
        
        # Mock Gate 2: Extraction
        if "librarian" in system_msg:
            last_user_msg = messages[-1]["content"].lower()
            if "prism" in last_user_msg:
                return [
                    {
                        "term": "Prism",
                        "overview": "A new security project.",
                        "deep_dive": "Uses port 8080 for secure communication and involves advanced encryption.",
                        "anchor": "The project Prism uses port 8080 for secure communication.",
                        "is_new": True,
                        "entity_type": "PROJECT"
                    }
                ]
            if "sql" in last_user_msg:
                return [
                    {
                        "term": "SQL",
                        "overview": "A domain-specific SQL implementation.",
                        "deep_dive": "Custom database system optimized for internal queries.",
                        "anchor": "Project SQL is a new database system.",
                        "is_new": True,
                        "entity_type": "TECH_STACK"
                    }
                ]
            return []
        
        # Mock Gate 3/5: Validation
        if "reviewer" in system_msg:
            last_user_msg = messages[-1]["content"].lower()
            # Simulate a failure for 'coffee' to test negative cases
            if "coffee" in last_user_msg:
                return {
                    "is_valid": False,
                    "confidence_level": "PENDING",
                    "status": "HALLUCINATION",
                    "reasoning": "Not supported by context."
                }
            return {
                "is_valid": True,
                "confidence_level": "GOLD",
                "status": "PASS",
                "reasoning": "Supported by context."
            }
            
        # Mock Community/Global Report
        if "strategic architect" in system_msg:
            if "principal" in system_msg:
                return "This is a mock Project Master Plan synthesizing multiple communities."
            return "This is a mock community summary."
        
        if "extract 5-7 key strategic themes" in system_msg:
            return "Theme1, Theme2, Theme3, Theme4, Theme5"

        if json_mode:
            return {"error": "Mock not implemented for this prompt"}
        return "Mock not implemented for this prompt"

class OpenAIClientWrapper:
    """Wrapper for OpenAI's official client."""
    def __init__(self, api_key: str = None, model: str = None):
        self.api_key = api_key or settings.openai_api_key
        if not self.api_key:
            raise LLMClientError("OPENAI_API_KEY is required when LLM_PROVIDER=openai.")
        self.client = OpenAI(api_key=self.api_key)
        self.async_client = AsyncOpenAI(api_key=self.api_key)
        self.model = model or settings.model_name

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((OpenAIError, LLMClientError)),
        reraise=True
    )
    def chat(self, messages: List[Dict[str, str]], json_mode: bool = True) -> Any:
        start_time = time.time()
        try:
            response = self.client.chat.completions.create(
                model=self.model,
                messages=messages,
                response_format={"type": "json_object"} if json_mode else None
            )
            content = response.choices[0].message.content
            latency = (time.time() - start_time) * 1000
            
            log_interaction(
                provider="openai",
                model=self.model,
                endpoint="chat.completions",
                prompt=messages,
                response=content,
                latency_ms=latency,
                prompt_tokens=response.usage.prompt_tokens,
                completion_tokens=response.usage.completion_tokens
            )

            if json_mode:
                return json.loads(content)
            return content
        except OpenAIError as e:
            log_interaction(
                provider="openai", model=self.model, endpoint="chat.completions",
                prompt=messages, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            print(f"Warning: OpenAI API call failed, retrying... ({e})")
            raise  # Let tenacity handle it
        except Exception as e:
            log_interaction(
                provider="openai", model=self.model, endpoint="chat.completions",
                prompt=messages, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            raise LLMClientError(f"OpenAI API call failed: {e}")

    async def batch_chat(self, messages_list: List[List[Dict[str, str]]], json_mode: bool = True) -> List[Any]:
        """
        Sends multiple chat requests in parallel using AsyncOpenAI.
        """
        tasks = [self._async_chat(messages, json_mode) for messages in messages_list]
        return await asyncio.gather(*tasks)

    async def _async_chat(self, messages: List[Dict[str, str]], json_mode: bool) -> Any:
        start_time = time.time()
        
        async for attempt in AsyncRetrying(
            stop=stop_after_attempt(5),
            wait=wait_exponential(multiplier=1, min=2, max=30),
            retry=retry_if_exception_type((OpenAIError, LLMClientError)),
            reraise=True
        ):
            with attempt:
                try:
                    response = await self.async_client.chat.completions.create(
                        model=self.model,
                        messages=messages,
                        response_format={"type": "json_object"} if json_mode else None
                    )
                    content = response.choices[0].message.content
                    latency = (time.time() - start_time) * 1000
                    
                    log_interaction(
                        provider="openai",
                        model=self.model,
                        endpoint="chat.completions",
                        prompt=messages,
                        response=content,
                        latency_ms=latency,
                        prompt_tokens=response.usage.prompt_tokens,
                        completion_tokens=response.usage.completion_tokens
                    )

                    if json_mode:
                        return json.loads(content)
                    return content
                except OpenAIError as e:
                    print(f"Warning: Async OpenAI API call failed, retrying... ({e})")
                    raise
                except Exception as e:
                    raise LLMClientError(f"Async OpenAI API call failed: {e}")

    @retry(
        stop=stop_after_attempt(5),
        wait=wait_exponential(multiplier=1, min=2, max=30),
        retry=retry_if_exception_type((OpenAIError, LLMClientError)),
        reraise=True
    )
    def get_embedding(self, text: str) -> List[float]:
        """
        Returns vector embeddings for a string using OpenAI.
        """
        start_time = time.time()
        try:
            response = self.client.embeddings.create(
                model=settings.embedding_model,
                input=text
            )
            latency = (time.time() - start_time) * 1000
            log_interaction(
                provider="openai",
                model=settings.embedding_model,
                endpoint="embeddings",
                prompt=text,
                response="<embedding data>",
                latency_ms=latency,
                prompt_tokens=response.usage.prompt_tokens,
                completion_tokens=0
            )
            return response.data[0].embedding
        except OpenAIError as e:
            log_interaction(
                provider="openai", model=settings.embedding_model, endpoint="embeddings",
                prompt=text, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            print(f"Warning: OpenAI Embedding call failed, retrying... ({e})")
            raise
        except Exception as e:
            log_interaction(
                provider="openai", model=settings.embedding_model, endpoint="embeddings",
                prompt=text, status="ERROR", error_message=str(e),
                latency_ms=(time.time() - start_time) * 1000
            )
            raise LLMClientError(f"OpenAI Embedding call failed: {e}")

def get_llm_client():
    if os.getenv("MOCK_LLM", "false").lower() == "true":
        return LocalLLMClient()
    if settings.llm_provider.lower() == "openai":
        return OpenAIClientWrapper()
    return LocalLLMClient()

def get_vlm_client_for_markitdown():
    """
    Returns an OpenAI-compatible client for VLM OCR, useful for MarkItDown.
    """
    if settings.llm_provider.lower() == "openai":
        return OpenAI(api_key=settings.openai_api_key)
        
    return OpenAI(
        base_url=os.getenv("VLLM_URL", "http://localhost:8000/v1"),
        api_key=os.getenv("VLLM_API_KEY", "vllm-local")
    )
