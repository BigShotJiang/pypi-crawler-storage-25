from typing import Dict, Any, Optional
import difflib
from .llm_client import get_llm_client
from .prompts import VALIDATOR_SYSTEM_TEMPLATE

def verify_anchor_exists(raw_text: str, anchor: str, threshold: float = 0.7) -> bool:
    """
    Deterministic hard-check to ensure the anchor exists in the raw text.
    Handles minor OCR noise using fuzzy matching.
    """
    if not anchor:
        return False
    
    clean_anchor = anchor.strip()
    if clean_anchor in raw_text:
        return True
    
    # Fuzzy fallback with sliding window
    # We use a window close to the anchor size to get better ratios
    anchor_len = len(clean_anchor)
    # Allow some margin for noise
    window_size = int(anchor_len * 1.1)
    step = max(1, anchor_len // 2)
    
    from difflib import SequenceMatcher

    for i in range(0, len(raw_text) - anchor_len + 1, step):
        window = raw_text[i : i + window_size]
        s = SequenceMatcher(None, clean_anchor, window)
        if s.ratio() >= threshold:
            return True
            
    return False

def validate_with_llm(raw_text: str, extraction: Dict[str, Any]) -> Dict[str, Any]:
    """
    Validates an extraction using a local LLM with an initial hard-anchor check.
    """
    anchor = extraction.get("anchor", "")
    
    # 1. Hard-Anchor Verification (Pitfall 1 Fix)
    if not verify_anchor_exists(raw_text, anchor):
        return {
            "is_valid": False,
            "confidence_level": "PENDING",
            "status": "HALLUCINATION",
            "reasoning": "Hard-Anchor Verification Failed: The provided quote does not exist in the source text.",
            "suggested_fix": None
        }

    # 2. LLM Logical Validation
    client = get_llm_client()
    messages = [
        {"role": "system", "content": VALIDATOR_SYSTEM_TEMPLATE},
        {"role": "user", "content": f"Raw Context:\n{raw_text}\n\nProposed Extraction:\n{extraction}"}
    ]
    
    return client.chat(messages, json_mode=True)
