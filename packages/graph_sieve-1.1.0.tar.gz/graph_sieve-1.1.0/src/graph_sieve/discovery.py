import os
import json
from typing import List, Dict, Any, Optional
from datetime import datetime
from pydantic import BaseModel, Field

from hyperextract import AutoModel

from .llm_client import get_llm_client
from .models import DictionaryEntry, UsageExample, GraphTriplet, RELATION_TYPES, RELATION_WEIGHTS
from .prompts import EXTRACTOR_SYSTEM_TEMPLATE

class ExtractedEntity(BaseModel):
    term: str
    overview: str
    deep_dive: str
    anchor: str
    entity_type: str = Field(pattern="PROJECT|COMPONENT|TECH_STACK")
    relationships: List[Dict[str, str]]

class ExtractionSchema(BaseModel):
    entities: List[ExtractedEntity]

def get_extractor_system_prompt():
    # Dynamically fetch allowed relationships from the Literal type
    allowed_rels = ", ".join(RELATION_TYPES.__args__)
    return EXTRACTOR_SYSTEM_TEMPLATE.format(allowed_rels=allowed_rels)

def extract_with_llm(text: str, context_hints: Optional[str] = None) -> List[Dict]:
    """
    Extracts terms and relationships using LLM directly with centralized prompts.
    Fallback to hyperextract if desired, but here we prioritize direct prompt control.
    """
    if not text:
        return []

    # If mock LLM is active for tests, return a static response
    if os.environ.get("MOCK_LLM") == "true":
        return [{
            "term": "Prism",
            "overview": "Project Prism overview",
            "deep_dive": "Deep dive into Prism",
            "anchor": "The project Prism uses port 8080",
            "entity_type": "PROJECT",
            "relationships": []
        }]

    client = get_llm_client()
    system_prompt = get_extractor_system_prompt()
    user_prompt = f"Context Hints: {context_hints}\n\nRaw Text:\n{text}" if context_hints else f"Raw Text:\n{text}"
    
    messages = [
        {"role": "system", "content": system_prompt},
        {"role": "user", "content": user_prompt}
    ]
    
    try:
        result = client.chat(messages, json_mode=True)
        # Handle different output formats (list or wrapped in "entities")
        if isinstance(result, list):
            return result
        if isinstance(result, dict):
            return result.get("entities", [])
        return []
    except Exception as e:
        print(f"LLM Extraction failed: {e}")
        return []

def batch_extract_with_llm(texts: List[str], context_hints: Optional[str] = None) -> List[List[Dict]]:
    """
    Processes multiple chunks in parallel using the batch_chat capability.
    """
    if not texts:
        return []

    import asyncio
    
    client = get_llm_client()
    system_prompt = get_extractor_system_prompt()
    
    messages_list = []
    for text in texts:
        user_prompt = f"Context Hints: {context_hints}\n\nRaw Text:\n{text}" if context_hints else f"Raw Text:\n{text}"
        messages_list.append([
            {"role": "system", "content": system_prompt},
            {"role": "user", "content": user_prompt}
        ])

    try:
        # Check if we are already in an event loop
        try:
            loop = asyncio.get_running_loop()
        except RuntimeError:
            loop = None

        if loop and loop.is_running():
            # Fallback to sequential sync calls if already in an event loop
            return [extract_with_llm(t, context_hints) for t in texts]

        # We use a helper to wrap batch_chat with return_exceptions=True if needed,
        # but for now let's just use the client's batch_chat and handle the whole-batch failure.
        results = asyncio.run(client.batch_chat(messages_list, json_mode=True))
        
        final_results = []
        for result in results:
            if isinstance(result, list):
                final_results.append(result)
            elif isinstance(result, dict):
                # If it's a dict, it might be {"entities": [...]} or just the entity itself
                if "entities" in result:
                    final_results.append(result["entities"])
                else:
                    # Possibly a single entity returned as a dict? 
                    # Our schema expects a list of entities.
                    final_results.append([result])
            else:
                final_results.append([])
        return final_results
    except Exception as e:
        print(f"Batch LLM Extraction failed: {e}")
        # Return None for each text to signify total failure
        return [None for _ in texts]

# Keeping legacy name for backward compatibility in tests
def extract_with_anchors(text: str) -> List[Dict]:
    return extract_with_llm(text)

def process_discovered_terms(discovered_terms: List[Dict], 
                             source_file: str, is_seed: bool = False, graph_engine: Any = None,
                             confidence_levels: Dict[str, str] = None,
                             storage: Optional[Any] = None) -> List[str]:
    """
    Consolidated logic for updating the storage with discovered terms.
    Pitfall 6 Fix: Multi-Tiered Confidence Scoring.
    """
    if not storage:
        # If no storage provided, we can't do much in this new model
        return []

    terms_seen_in_current_doc = set()
    added_terms = []
    confidence_levels = confidence_levels or {}
    
    for item in discovered_terms:
        term = item.get("term")
        overview = item.get("overview")
        deep_dive = item.get("deep_dive")
        anchor = item.get("anchor") or item.get("usage_context", "")
        entity_type = item.get("entity_type")
        relationships = item.get("relationships", [])
        confidence = confidence_levels.get(term, "BRONZE")
        
        if not term: continue

        status = "ACTIVE"
        if overview == "[PENDING]" or not overview:
            status = "PENDING_DEFINITION"
            overview = "[PENDING]"
            confidence = "PENDING"

        existing = storage.get_entry(term)
        if existing:
            # Upgrade Logic: If existing is PENDING and new is ACTIVE, upgrade it
            if existing.status == "PENDING_DEFINITION" and status == "ACTIVE":
                existing.overview = overview
                existing.deep_dive = deep_dive
                existing.status = "ACTIVE"
                existing.confidence_level = confidence
            
            # Confidence Upgrade
            confidence_order = {"PENDING": 0, "BRONZE": 1, "SILVER": 2, "GOLD": 3}
            if confidence_order.get(confidence, 0) > confidence_order.get(existing.confidence_level, 0):
                existing.confidence_level = confidence
            
            # Update deep_dive if it was empty but now we have info
            if not existing.deep_dive and deep_dive:
                existing.deep_dive = deep_dive
            
            existing.usage_examples.append(UsageExample(context=anchor, source=source_file))
            existing.last_seen = datetime.now().isoformat()
            
            if is_seed:
                existing.authority_level = "SEED"
                existing.is_golden = True

            if term not in terms_seen_in_current_doc:
                existing.document_count += 1
            
            entry_to_save = existing
        else:
            entry = DictionaryEntry(
                term=term,
                overview=overview,
                deep_dive=deep_dive,
                source_file=source_file,
                entity_type=entity_type,
                usage_examples=[UsageExample(context=anchor, source=source_file)],
                last_seen=datetime.now().isoformat(),
                document_count=1,
                status=status,
                authority_level="SEED" if is_seed else "DISCOVERED",
                confidence_level=confidence,
                is_golden=is_seed
            )
            added_terms.append(term)
            entry_to_save = entry

        # Persist to storage
        storage.upsert_entry(entry_to_save)
        terms_seen_in_current_doc.add(term)

        # Process Relationships directly using storage
        for rel in relationships:
            target = rel.get("target")
            rel_type = rel.get("type")
            if target and rel_type:
                weight = RELATION_WEIGHTS.get(rel_type, 0.5)
                triplet = GraphTriplet(
                    subject=term,
                    relationship=rel_type,
                    object=target,
                    anchor=anchor,
                    source_file=source_file,
                    weight=weight
                )
                storage.add_relationship(triplet)
                    
    return added_terms
