import os
from typing import List
from markitdown import MarkItDown
from .hebrew_utils import normalize_rtl_text
from .llm_client import get_vlm_client_for_markitdown

def extract_text_from_one(file_path: str) -> str:
    if not os.path.exists(file_path):
        raise FileNotFoundError(f"OneNote file not found: {file_path}")
    return f"[OneNote extraction for {file_path} - text extraction limited in this version]"

try:
    import chardet
except (ImportError, Exception):
    chardet = None

def extract_text_from_txt(file_path: str) -> str:
    print(f"Debug: Entering extract_text_from_txt for {file_path}")
    with open(file_path, "rb") as f:
        raw_data = f.read()
    
    print(f"Debug: Raw data length: {len(raw_data)}")
    
    for enc in ['utf-8', 'windows-1255', 'iso-8859-8']:
        try:
            decoded_text = raw_data.decode(enc)
            print(f"Debug: Successfully decoded with {enc}")
            return decoded_text
        except UnicodeDecodeError:
            print(f"Debug: Failed to decode with {enc}")
            continue
            
    if chardet:
        try:
            detected = chardet.detect(raw_data)
            encoding = detected['encoding'] or 'utf-8'
            print(f"Debug: Chardet detected encoding: {encoding}, confidence: {detected['confidence']}")
            return raw_data.decode(encoding)
        except Exception as e:
            print(f"Debug: Chardet failed: {e}")
            pass
            
    print("Debug: Falling back to utf-8 with replace errors")
    return raw_data.decode('utf-8', errors='replace')

def chunk_text(text: str, file_path: str, chunk_size: int = 1200, overlap: int = 200) -> List[str]:
    """
    Splits text into chunks optimized for GraphRAG.
    - Uses larger chunks (1200 chars/tokens approx)
    - Maintains overlap to preserve relationships across boundaries
    - Prepends document metadata to every chunk
    """
    if not text:
        return []
        
    # Recursive strategy: split by paragraph, then sentence
    # For a simple local implementation, we'll use character-based sliding window with paragraph awareness
    filename = os.path.basename(file_path)
    metadata = f"[Context: Source File: {filename}]\n\n"
    
    chunks = []
    start = 0
    while start < len(text):
        end = start + chunk_size
        
        # Try to find a natural break point (paragraph or sentence)
        if end < len(text):
            # Look for last paragraph break in the window
            last_break = text.rfind('\n\n', start, end)
            if last_break != -1 and last_break > start + (chunk_size // 2):
                end = last_break + 2
            else:
                # Look for last sentence break
                last_sentence = text.rfind('. ', start, end)
                if last_sentence != -1 and last_sentence > start + (chunk_size // 2):
                    end = last_sentence + 2
        
        chunk_content = text[start:end].strip()
        if chunk_content:
            chunks.append(metadata + chunk_content)
            
        start = end - overlap
        if start >= len(text) or end >= len(text):
            break
            
    return chunks

def extract_all(file_path: str) -> str:
    """Unified interface returning extracted text as Markdown via MarkItDown."""
    if not os.path.exists(file_path):
        return f"[Error: File not found {file_path}]"

    ext = os.path.splitext(file_path)[1].lower()
    
    # Handle specific formats that might need special care
    if ext == ".one":
        return normalize_rtl_text(extract_text_from_one(file_path))
    elif ext == ".txt": # Prioritize our text extractor for plain text files
        try:
            raw_text = extract_text_from_txt(file_path)
            return normalize_rtl_text(raw_text)
        except Exception as e:
            print(f"Debug: Custom text extraction failed for {file_path} - {str(e)}")
            # Fall through to MarkItDown if custom extraction fails

    
    # List of common extensions supported by MarkItDown or relevant to our context
    # MarkItDown supports: .pdf, .docx, .pptx, .xlsx, .msg, .html, .csv, .json, .xml, .zip, etc.
    # If it's not a common text/office format, we might want to skip it to avoid noise.
    supported_extensions = {
        '.pdf', '.docx', '.doc', '.pptx', '.ppt', '.xlsx', '.xls', 
        '.msg', '.html', '.htm', '.csv', '.json', '.xml', 
        '.txt', '.log', '.md', '.rtf'
    }

    if ext not in supported_extensions:
        print(f"Debug: Skipping unsupported file format: {ext} ({file_path})")
        return ""

    # Initialize MarkItDown with VLM support
    vlm_client = get_vlm_client_for_markitdown()
    vlm_model = os.getenv("VLLM_VLM_MODEL", "pixtral-12b")
    md = MarkItDown(llm_client=vlm_client, llm_model=vlm_model)

    try:
        result = md.convert(file_path)
        raw_text = result.text_content
    except Exception as e:
        # Fallback for plain text or unsupported types if md fails
        try:
            raw_text = extract_text_from_txt(file_path)
        except Exception:
            print(f"Debug: Extraction failed for {ext} ({file_path}) - {str(e)}")
            return ""

    return normalize_rtl_text(raw_text)
