import sqlite3
import json
from pathlib import Path
from contextlib import closing
from typing import List, Optional, Dict, Any
from .models import (
    DictionaryEntry, 
    GraphTriplet, 
    CommunityReport, 
    GlobalReport, 
    UsageExample,
    LLMLogEntry
)
from .config import settings

class SQLiteStorage:
    """
    Relational storage for graph-sieve data using SQLite.
    Handles table creation and low-level SQL operations with JSON support.
    """
    def __init__(self, db_path: Optional[Path] = None):
        self.db_path = db_path or settings.db_path
        self._init_db()

    def _get_connection(self):
        """Get a SQLite connection with row factory for dictionary access."""
        conn = sqlite3.connect(self.db_path)
        conn.row_factory = sqlite3.Row
        return conn

    def _init_db(self):
        """Initialize the database schema with WAL mode and necessary tables."""
        settings.ensure_dirs()
        with closing(self._get_connection()) as conn:
            # Enable WAL mode for better concurrency and performance
            conn.execute("PRAGMA journal_mode=WAL;")
            
            with conn:
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS entries (
                        term TEXT PRIMARY KEY,
                        canonical_id TEXT,
                        overview TEXT,
                        deep_dive TEXT,
                        source_file TEXT,
                        entity_type TEXT,
                        usage_examples TEXT, -- JSON
                        related_terms TEXT,  -- JSON
                        is_golden BOOLEAN,
                        status TEXT,
                        authority_level TEXT,
                        confidence_level TEXT,
                        last_seen TEXT,
                        document_count INTEGER,
                        is_bounty BOOLEAN
                    )
                """)
                # Migration: Add canonical_id if it doesn't exist
                cursor = conn.execute("PRAGMA table_info(entries)")
                columns = [row['name'] for row in cursor.fetchall()]
                if 'canonical_id' not in columns:
                    conn.execute("ALTER TABLE entries ADD COLUMN canonical_id TEXT")

                conn.execute("""
                    CREATE TABLE IF NOT EXISTS relationships (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        subject TEXT,
                        relationship TEXT,
                        object TEXT,
                        anchor TEXT,
                        source_file TEXT,
                        weight REAL,
                        date_added TEXT,
                        status TEXT,
                        UNIQUE(subject, relationship, object)
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS community_reports (
                        community_id TEXT PRIMARY KEY,
                        title TEXT,
                        summary TEXT,
                        nodes TEXT, -- JSON
                        last_updated TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS global_report (
                        id INTEGER PRIMARY KEY CHECK (id = 1),
                        summary TEXT,
                        key_themes TEXT, -- JSON
                        last_updated TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS chunk_cache (
                        chunk_hash TEXT PRIMARY KEY,
                        extracted_data TEXT, -- JSON representation
                        date_added TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS aliases (
                        alias TEXT PRIMARY KEY,
                        canonical_id TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS dlq_failed_chunks (
                        chunk_hash TEXT PRIMARY KEY,
                        chunk_data TEXT,
                        error_reason TEXT,
                        retries INTEGER DEFAULT 0,
                        date_added TEXT,
                        source_file TEXT
                    )
                """)
                conn.execute("""
                    CREATE TABLE IF NOT EXISTS llm_logs (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        timestamp TEXT,
                        provider TEXT,
                        model TEXT,
                        endpoint TEXT,
                        prompt TEXT,
                        response TEXT,
                        latency_ms REAL,
                        prompt_tokens INTEGER,
                        completion_tokens INTEGER,
                        total_tokens INTEGER,
                        cost REAL,
                        status TEXT,
                        error_message TEXT
                    )
                """)
                # Create indexes for relationships
                conn.execute("CREATE INDEX IF NOT EXISTS idx_rel_subject ON relationships (subject)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_rel_object ON relationships (object)")
                conn.execute("CREATE INDEX IF NOT EXISTS idx_llm_logs_timestamp ON llm_logs (timestamp)")

    def _row_to_entry(self, row: sqlite3.Row) -> DictionaryEntry:
        """Convert a database row to a DictionaryEntry."""
        data = dict(row)
        data['usage_examples'] = [
            UsageExample(**ex) for ex in json.loads(data['usage_examples'] or '[]')
        ]
        data['related_terms'] = json.loads(data['related_terms'] or '[]')
        data['is_golden'] = bool(data['is_golden'])
        data['is_bounty'] = bool(data['is_bounty'])
        return DictionaryEntry(**data)

    def _row_to_triplet(self, row: sqlite3.Row) -> GraphTriplet:
        """Convert a database row to a GraphTriplet."""
        return GraphTriplet(**dict(row))

    def _row_to_community_report(self, row: sqlite3.Row) -> CommunityReport:
        """Convert a database row to a CommunityReport."""
        data = dict(row)
        data['nodes'] = json.loads(data['nodes'] or '[]')
        return CommunityReport(**data)

    def _row_to_global_report(self, row: sqlite3.Row) -> GlobalReport:
        """Convert a database row to a GlobalReport."""
        data = dict(row)
        data.pop('id', None)
        data['key_themes'] = json.loads(data['key_themes'] or '[]')
        return GlobalReport(**data)

    def log_llm_interaction(self, entry: LLMLogEntry):
        """Save an LLM interaction log to the database."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT INTO llm_logs (
                        timestamp, provider, model, endpoint, prompt, response,
                        latency_ms, prompt_tokens, completion_tokens, total_tokens,
                        cost, status, error_message
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry.timestamp,
                    entry.provider,
                    entry.model,
                    entry.endpoint,
                    entry.prompt,
                    entry.response,
                    entry.latency_ms,
                    entry.prompt_tokens,
                    entry.completion_tokens,
                    entry.total_tokens,
                    entry.cost,
                    entry.status,
                    entry.error_message
                ))

    def upsert_entry(self, entry: DictionaryEntry):
        """Insert or update a dictionary entry."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT OR REPLACE INTO entries (
                        term, canonical_id, overview, deep_dive, source_file, entity_type,
                        usage_examples, related_terms, is_golden, status,
                        authority_level, confidence_level, last_seen,
                        document_count, is_bounty
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    entry.term,
                    entry.canonical_id,
                    entry.overview,
                    entry.deep_dive,
                    entry.source_file,
                    entry.entity_type,
                    json.dumps([ex.model_dump() for ex in entry.usage_examples]),
                    json.dumps(entry.related_terms),
                    1 if entry.is_golden else 0,
                    entry.status,
                    entry.authority_level,
                    entry.confidence_level,
                    entry.last_seen,
                    entry.document_count,
                    1 if entry.is_bounty else 0
                ))

    def get_entry(self, term: str) -> Optional[DictionaryEntry]:
        """Retrieve a dictionary entry by term."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT * FROM entries WHERE term = ?", (term,)).fetchone()
            if not row:
                return None
            return self._row_to_entry(row)

    def get_term_exists(self, term: str) -> bool:
        """Check if a term exists in the entries table."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT 1 FROM entries WHERE term = ?", (term,)).fetchone()
            return row is not None

    def get_bounty_candidates(self, limit: int = 10) -> List[DictionaryEntry]:
        """Retrieve entries marked as bounty candidates."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute(
                "SELECT * FROM entries WHERE is_bounty = 1 LIMIT ?", 
                (limit,)
            ).fetchall()
            return [self._row_to_entry(row) for row in rows]

    def get_active_terms_count(self) -> int:
        """Count terms with 'ACTIVE' status."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT COUNT(*) FROM entries WHERE status = 'ACTIVE'").fetchone()
            return row[0] if row else 0

    def list_entries(self) -> List[DictionaryEntry]:
        """Retrieve all dictionary entries."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT * FROM entries").fetchall()
            return [self._row_to_entry(row) for row in rows]

    def link_alias(self, alias_term: str, canonical_term: str):
        """
        Updates the entries table to set canonical_id for the alias,
        inserts into the aliases table,
        and inserts an ALIAS_OF triplet into the relationships table.
        """
        with closing(self._get_connection()) as conn:
            with conn:
                # 1. Update entries table (if entry exists)
                conn.execute(
                    "UPDATE entries SET canonical_id = ? WHERE term = ?",
                    (canonical_term, alias_term)
                )

                # 2. Update/Insert into aliases table
                conn.execute(
                    "INSERT OR REPLACE INTO aliases (alias, canonical_id) VALUES (?, ?)",
                    (alias_term, canonical_term)
                )
                
                # 3. Insert ALIAS_OF triplet
                from .models import GraphTriplet
                triplet = GraphTriplet(
                    subject=alias_term,
                    relationship="ALIAS_OF",
                    object=canonical_term,
                    anchor=f"Semantic resolution: {alias_term} is an alias of {canonical_term}",
                    source_file="semantic_resolver",
                    weight=1.0
                )
                
                conn.execute("""
                    INSERT OR REPLACE INTO relationships (
                        subject, relationship, object, anchor, source_file,
                        weight, date_added, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    triplet.subject,
                    triplet.relationship,
                    triplet.object,
                    triplet.anchor,
                    triplet.source_file,
                    triplet.weight,
                    triplet.date_added,
                    triplet.status
                ))

    def get_all_aliases(self) -> Dict[str, str]:
        """Retrieve all alias mappings as a dictionary {alias: canonical_id}."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT alias, canonical_id FROM aliases").fetchall()
            return {row['alias']: row['canonical_id'] for row in rows}

    def add_relationship(self, triplet: GraphTriplet):
        """Add a new relationship triplet."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT OR REPLACE INTO relationships (
                        subject, relationship, object, anchor, source_file,
                        weight, date_added, status
                    ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
                """, (
                    triplet.subject,
                    triplet.relationship,
                    triplet.object,
                    triplet.anchor,
                    triplet.source_file,
                    triplet.weight,
                    triplet.date_added,
                    triplet.status
                ))

    def get_relationships_count(self) -> int:
        """Count total relationships."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT COUNT(*) FROM relationships").fetchone()
            return row[0] if row else 0

    def get_relationships(self, subject: Optional[str] = None, object: Optional[str] = None) -> List[GraphTriplet]:
        """Retrieve relationships, optionally filtering by subject or object."""
        query = "SELECT * FROM relationships"
        params = []
        conditions = []
        if subject:
            conditions.append("subject = ?")
            params.append(subject)
        if object:
            conditions.append("object = ?")
            params.append(object)
        
        if conditions:
            query += " WHERE " + " AND ".join(conditions)
            
        with closing(self._get_connection()) as conn:
            rows = conn.execute(query, params).fetchall()
            return [self._row_to_triplet(row) for row in rows]

    def upsert_community_report(self, report: CommunityReport):
        """Insert or update a community report."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT OR REPLACE INTO community_reports (
                        community_id, title, summary, nodes, last_updated
                    ) VALUES (?, ?, ?, ?, ?)
                """, (
                    report.community_id,
                    report.title,
                    report.summary,
                    json.dumps(report.nodes),
                    report.last_updated
                ))

    def get_community_report(self, community_id: str) -> Optional[CommunityReport]:
        """Retrieve a community report by ID."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT * FROM community_reports WHERE community_id = ?", (community_id,)).fetchone()
            if not row:
                return None
            return self._row_to_community_report(row)

    def get_all_community_reports(self) -> List[CommunityReport]:
        """Retrieve all community reports."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT * FROM community_reports").fetchall()
            return [self._row_to_community_report(row) for row in rows]

    def upsert_global_report(self, report: GlobalReport):
        """Insert or update the global report."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("""
                    INSERT OR REPLACE INTO global_report (
                        id, summary, key_themes, last_updated
                    ) VALUES (1, ?, ?, ?)
                """, (
                    report.summary,
                    json.dumps(report.key_themes),
                    report.last_updated
                ))

    def get_global_report(self) -> Optional[GlobalReport]:
        """Retrieve the global report."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT * FROM global_report WHERE id = 1").fetchone()
            if not row:
                return None
            return self._row_to_global_report(row)

    def upsert_chunk_cache(self, chunk_hash: str, extracted_data: List[Dict[str, Any]]):
        """Insert or update a chunk extraction cache."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT OR REPLACE INTO chunk_cache (
                        chunk_hash, extracted_data, date_added
                    ) VALUES (?, ?, ?)
                """, (
                    chunk_hash,
                    json.dumps(extracted_data),
                    datetime.now().isoformat()
                ))

    def get_chunk_cache(self, chunk_hash: str) -> Optional[List[Dict[str, Any]]]:
        """Retrieve cached extraction data for a chunk."""
        with closing(self._get_connection()) as conn:
            row = conn.execute("SELECT extracted_data FROM chunk_cache WHERE chunk_hash = ?", (chunk_hash,)).fetchone()
            if not row:
                return None
            return json.loads(row['extracted_data'] or '[]')

    def push_to_dlq(self, chunk_hash: str, chunk_data: str, error_reason: str, source_file: str):
        """Push a failed chunk to the Dead Letter Queue."""
        with closing(self._get_connection()) as conn:
            with conn:
                from datetime import datetime
                conn.execute("""
                    INSERT INTO dlq_failed_chunks (
                        chunk_hash, chunk_data, error_reason, retries, date_added, source_file
                    ) VALUES (?, ?, ?, 0, ?, ?)
                    ON CONFLICT(chunk_hash) DO UPDATE SET
                        error_reason = excluded.error_reason,
                        retries = retries + 1,
                        date_added = excluded.date_added
                """, (
                    chunk_hash,
                    chunk_data,
                    error_reason,
                    datetime.now().isoformat(),
                    source_file
                ))

    def get_all_dlq_items(self) -> List[Dict[str, Any]]:
        """Retrieve all items from the Dead Letter Queue."""
        with closing(self._get_connection()) as conn:
            rows = conn.execute("SELECT * FROM dlq_failed_chunks").fetchall()
            return [dict(row) for row in rows]

    def remove_from_dlq(self, chunk_hash: str):
        """Remove a chunk from the Dead Letter Queue."""
        with closing(self._get_connection()) as conn:
            with conn:
                conn.execute("DELETE FROM dlq_failed_chunks WHERE chunk_hash = ?", (chunk_hash,))
