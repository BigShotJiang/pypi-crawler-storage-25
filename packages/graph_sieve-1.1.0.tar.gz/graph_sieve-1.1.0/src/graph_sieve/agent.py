from typing import List, Dict, Any, Optional
import os
from datetime import datetime
from .extractor import extract_all
from .filters import is_domain_specific
from .discovery import extract_with_llm, process_discovered_terms
from .validator import validate_with_llm
from .models import DictionaryEntry, UsageExample
from .graph_engine import GraphKnowledgeEngine
from .hashing import HashStore, calculate_chunk_hash
from .strategic_filter import StrategicSieve
from .storage_sqlite import SQLiteStorage
from .llm_client import get_llm_client

class DictionaryAgent:
    """
    The main entry point for the Dictionary Agent.
    Consolidates the 5-gate pipeline logic and the high-level agent interface.
    """
    def __init__(self, whitelist: List[str] = None, 
                 hash_store: HashStore = None, strategic_sieve: StrategicSieve = None,
                 seed_paths: List[str] = None, storage: SQLiteStorage = None):
        self.whitelist = whitelist or []
        self.storage = storage or SQLiteStorage()
        self.graph_engine = GraphKnowledgeEngine(storage=self.storage)
        self.hash_store = hash_store or HashStore()
        self.strategic_sieve = strategic_sieve or StrategicSieve()
        self.seed_paths = seed_paths or []

    def scan_file(self, file_path: str):
        """Simple interface for scanning a single file."""
        return self.process_document(file_path)

    def resolve_aliases(self):
        """
        Task 3: LLM Verification & Canonicalization.
        Discovers candidate aliases and verifies them with an LLM.
        """
        from .resolution import VectorResolver, SemanticResolver
        print("\nResolving Aliases and Canonicalizing Terms...")
        
        vector_resolver = VectorResolver(storage=self.storage)
        candidates = vector_resolver.discover_candidates(threshold=0.8)
        
        if candidates:
            semantic_resolver = SemanticResolver(storage=self.storage)
            semantic_resolver.verify_and_map(candidates)

    def process_directory(self, dir_path: str) -> List[str]:
        """
        Processes documents, starting with seed documents if provided.
        """
        all_added = []
        
        # 1. Process Seeds First
        for seed in self.seed_paths:
            if os.path.isfile(seed):
                all_added.extend(self.process_document(seed, is_seed=True))
            elif os.path.isdir(seed):
                for root, _, filenames in os.walk(seed):
                    for f in filenames:
                        path = os.path.join(root, f)
                        all_added.extend(self.process_document(path, is_seed=True))

        # 2. Process Remaining Docs in reverse-chronological order
        files = []
        for root, _, filenames in os.walk(dir_path):
            for f in filenames:
                path = os.path.join(root, f)
                # Skip if already processed as seed
                is_already_seed = any(os.path.samefile(path, s) for s in self.seed_paths if os.path.exists(s) and os.path.isfile(s))
                if is_already_seed:
                    continue
                files.append((path, os.path.getmtime(path)))
        
        files.sort(key=lambda x: x[1], reverse=True)
        
        for file_path, _ in files:
            # Gate 1: Strategic Sieve
            if not self.strategic_sieve.is_relevant(file_path):
                continue

            if not self.hash_store.has_changed(file_path):
                continue
            
            added = self.process_document(file_path)
            all_added.extend(added)
            
        # Task 3: Resolve Aliases
        self.resolve_aliases()

        # Trigger Global Synthesis after processing all docs
        print("\nFinalizing Knowledge Graph...")
        self.graph_engine.generate_community_reports()
        self.graph_engine.generate_global_narrative()

        self.hash_store.save()
        return all_added

    def get_bounty_hints(self) -> Optional[str]:
        """
        Pitfall 3 Fix: Bounty System. Identifies high-velocity pending terms.
        Bounty Capping (Second-Order Fix): Limit to top 10 to protect context window.
        """
        bounty_candidates = self.storage.get_bounty_candidates(limit=10)
        # Sort by ubiquity to find most important missing terms
        bounty_candidates.sort(key=lambda x: x.document_count, reverse=True)
        bounty_terms = [e.term for e in bounty_candidates]
        
        if not bounty_terms:
            return None
        return "The following terms have been seen multiple times but lack a definition. Please prioritize finding their meanings: " + ", ".join(bounty_terms)

    def merge_conflicting_definitions(self, existing: DictionaryEntry, new_item: Dict[str, Any]) -> bool:
        """
        Synthesis Gate: Merges conflicting high-confidence definitions using an LLM.
        """
        # If both are high confidence (GOLD or SILVER) and overviews differ significantly
        confidence_order = {"PENDING": 0, "BRONZE": 1, "SILVER": 2, "GOLD": 3}
        new_conf = new_item.get("confidence_level", "BRONZE")
        
        if (confidence_order.get(existing.confidence_level, 0) >= 2 and 
            confidence_order.get(new_conf, 0) >= 2 and
            existing.overview.strip().lower() != new_item.get("overview", "").strip().lower()):
            
            print(f"Triggering Synthesis Gate for term: {existing.term}")
            client = get_llm_client()
            prompt = f"""You are a Master Lexicographer. Two authoritative sources have defined the same term differently. 
Your task is to SYNTHESIZE them into a single, unified definition that captures the nuances of both.

Term: {existing.term}
Definition A: {existing.overview}
Definition B: {new_item.get("overview")}

Deep Dive A: {existing.deep_dive or "None"}
Deep Dive B: {new_item.get("deep_dive") or "None"}

Provide a single JSON response with:
- overview: The synthesized 1-sentence summary.
- deep_dive: The combined technical details.
"""
            messages = [
                {"role": "system", "content": "Return JSON with 'overview' and 'deep_dive'."},
                {"role": "user", "content": prompt}
            ]
            
            try:
                synthesized = client.chat(messages, json_mode=True)
                existing.overview = synthesized.get("overview", existing.overview)
                existing.deep_dive = synthesized.get("deep_dive", existing.deep_dive)
                # Upgrade to highest confidence if merged
                existing.confidence_level = "GOLD" if "GOLD" in [existing.confidence_level, new_conf] else "SILVER"
                return True
            except:
                return False
        return False

    def reconcile_supersedes(self, subject: str, target: str):
        """
        Gate 4 Extension: If a new term SUPERSEDES an old one, update statuses.
        """
        if self.storage.get_term_exists(target):
            old_entry = self.storage.get_entry(target)
            if old_entry.status != "LEGACY":
                print(f"Temporal Reconciliation: {subject} SUPERSEDES {target}. Marking {target} as LEGACY.")
                old_entry.status = "LEGACY"
                self.storage.upsert_entry(old_entry)
                
        # Also mark related relationships as legacy
        for rel in self.storage.get_relationships(subject=target):
            if rel.status != "LEGACY":
                rel.status = "LEGACY"
                self.storage.add_relationship(rel)
                
        for rel in self.storage.get_relationships(object=target):
            if rel.status != "LEGACY":
                rel.status = "LEGACY"
                self.storage.add_relationship(rel)

    def process_document(self, file_path: str, is_seed: bool = False) -> List[str]:
        """
        Runs the 5-gate pipeline on a document by processing it in metadata-aware chunks.
        """
        from .extractor import chunk_text

        # Gate 2: Extraction
        full_text = extract_all(file_path)
        if full_text.startswith("[Error"):
            return []

        # Pitfall: Large documents need chunking
        chunks = chunk_text(full_text, file_path)
        all_added_terms = []

        # Batch Processing: Collect chunks that need extraction
        chunks_to_extract = []
        chunk_hashes = []
        
        for chunk in chunks:
            chunk_hash = calculate_chunk_hash(chunk)
            cached_discovery = self.storage.get_chunk_cache(chunk_hash)
            if cached_discovery is None:
                chunks_to_extract.append(chunk)
                chunk_hashes.append(chunk_hash)

        # Execute Batch Extraction
        if chunks_to_extract:
            print(f"Batch extracting {len(chunks_to_extract)} new chunks from {file_path}...")
            context_hints = self.get_bounty_hints()
            from .discovery import batch_extract_with_llm
            batch_results = batch_extract_with_llm(chunks_to_extract, context_hints=context_hints)
            
            for i, discovered in enumerate(batch_results):
                if discovered is None:
                    # Failure case: Push to DLQ
                    chunk = chunks_to_extract[i]
                    chunk_hash = chunk_hashes[i]
                    print(f"Batch extraction failed for chunk {chunk_hash}. Pushing to DLQ.")
                    self.storage.push_to_dlq(chunk_hash, chunk, "Batch LLM Extraction Failure", os.path.basename(file_path))
                else:
                    # Success (even if empty list): Save to cache so _process_chunk finds it
                    self.storage.upsert_chunk_cache(chunk_hashes[i], discovered)

        for chunk in chunks:
            added_terms = self._process_chunk(chunk, file_path, full_text, is_seed)
            all_added_terms.extend(added_terms)
            
        return list(set(all_added_terms)) # Deduplicate added terms

    def _process_chunk(self, chunk: str, file_path: str, full_text: str, is_seed: bool) -> List[str]:
        """Internal helper to process a single chunk."""
        from .discovery import process_discovered_terms
        
        chunk_hash = calculate_chunk_hash(chunk)
        cached_discovery = self.storage.get_chunk_cache(chunk_hash)
        
        if cached_discovery is not None:
            discovered = cached_discovery
        else:
            try:
                context_hints = self.get_bounty_hints()
                discovered = extract_with_llm(chunk, context_hints=context_hints)
                self.storage.upsert_chunk_cache(chunk_hash, discovered)
            except Exception as e:
                print(f"Extraction failed for chunk {chunk_hash} from {file_path}: {str(e)}")
                self.storage.push_to_dlq(chunk_hash, chunk, str(e), os.path.basename(file_path))
                return []

        valid_items = []
        confidence_map = {}

        for item in discovered:
            term = item.get("term")
            if not term: continue
            if not is_domain_specific(term, self.whitelist): continue

            validation = validate_with_llm(full_text, item)
            if not validation.get("is_valid", False):
                if validation.get("status") == "HALLUCINATION" and "Hard-Anchor" in validation.get("reasoning", ""):
                    print(f"Discarding Hallucination (No Anchor): {term}")
                continue

            valid_items.append(item)
            confidence_map[term] = validation.get("confidence_level", "BRONZE")
                
            for rel in item.get("relationships", []):
                if rel.get("type") == "SUPERSEDES":
                    self.reconcile_supersedes(term, rel.get("target"))

        for item in valid_items:
            term = item.get("term")
            if self.storage.get_term_exists(term):
                existing = self.storage.get_entry(term)
                item["confidence_level"] = confidence_map.get(term, "BRONZE")
                if self.merge_conflicting_definitions(existing, item):
                    self.storage.upsert_entry(existing)

        return process_discovered_terms(
            valid_items, 
            file_path, 
            is_seed=is_seed, 
            graph_engine=self.graph_engine,
            confidence_levels=confidence_map,
            storage=self.storage
        )

    def retry_failed_chunks(self) -> int:
        """
        Retries all chunks currently in the Dead Letter Queue.
        Returns the number of successfully processed chunks.
        """
        failed_chunks = self.storage.get_all_dlq_items()
        if not failed_chunks:
            print("No chunks in Dead Letter Queue to retry.")
            return 0

        print(f"Retrying {len(failed_chunks)} chunks from DLQ...")
        success_count = 0
        
        for item in failed_chunks:
            chunk_hash = item["chunk_hash"]
            chunk_data = item["chunk_data"]
            source_file = item["source_file"]
            
            # Note: We don't have the 'full_text' of the original document here,
            # but we can use the chunk data itself as a fallback for anchor validation.
            # Ideally we'd store the full text or just enough context.
            # For now, we'll pass the chunk data as full_text.
            
            added = self._process_chunk(chunk_data, source_file, chunk_data, is_seed=False)
            if added:
                self.storage.remove_from_dlq(chunk_hash)
                success_count += 1
                
        return success_count

    def generate_summary(self) -> str:
        """
        Generates a comprehensive summary of the agent's learning journey.
        """
        all_entries = self.storage.list_entries()
        total_terms = len(all_entries)
        active_entries = [e for e in all_entries if e.status == "ACTIVE"]
        pending_entries = [e for e in all_entries if e.status == "PENDING_DEFINITION"]
        relationships_count = self.storage.get_relationships_count()
        community_reports = self.storage.get_all_community_reports()
        global_report = self.storage.get_global_report()
        
        # Sort by document_count to find most common terms
        common_terms = sorted(active_entries, key=lambda x: x.document_count, reverse=True)[:5]
        
        lines = [
            "\n" + "="*50,
            "📊 DICTIONARY AGENT LEARNING SUMMARY",
            "="*50,
            f"Total Concepts Tracked:  {total_terms}",
            f"Fully Defined Terms:     {len(active_entries)}",
            f"Pending Definitions:     {len(pending_entries)}",
            f"Knowledge Graph Links:   {relationships_count}",
            f"Identified Communities:  {len(community_reports)}",
        ]
        
        if global_report:
            lines.append("\n🌍 PROJECT MASTER PLAN (Global Synthesis):")
            lines.append(global_report.summary)
            if global_report.key_themes:
                lines.append("\n🔑 STRATEGIC THEMES:")
                for theme in global_report.key_themes:
                    lines.append(f"• {theme}")
        
        lines.append("\n⭐ MOST COMMON TERMS:")
        
        for entry in common_terms:
            lines.append(f"• {entry.term} (seen in {entry.document_count} files)")
            lines.append(f"  Confidence: {entry.confidence_level}")
            lines.append(f"  Overview: {entry.overview}")
            if entry.deep_dive:
                # Show first 100 chars of deep dive
                dd_snippet = (entry.deep_dive[:100] + "...") if len(entry.deep_dive) > 100 else entry.deep_dive
                lines.append(f"  Deep Dive: {dd_snippet}")
            lines.append("")

        bounty_candidates = [e for e in pending_entries if e.document_count >= 3]
        if bounty_candidates:
            lines.append("🎯 BOUNTY LIST (Critical missing definitions):")
            for entry in sorted(bounty_candidates, key=lambda x: x.document_count, reverse=True)[:10]:
                lines.append(f"• {entry.term} (seen {entry.document_count} times)")
        elif pending_entries:
            lines.append("⏳ TOP PENDING CONCEPTS (Need more context):")
            for entry in sorted(pending_entries, key=lambda x: x.document_count, reverse=True)[:3]:
                lines.append(f"• {entry.term} (seen {entry.document_count} times)")
        
        lines.append("\n" + "="*50 + "\n")
        return "\n".join(lines)
