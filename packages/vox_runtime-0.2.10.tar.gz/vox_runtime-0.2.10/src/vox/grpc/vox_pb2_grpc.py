
"""Client and server classes corresponding to protobuf-defined services."""
import grpc
import warnings

from . import vox_pb2 as vox__pb2

GRPC_GENERATED_VERSION = '1.80.0'
GRPC_VERSION = grpc.__version__
_version_not_supported = False

try:
    from grpc._utilities import first_version_is_lower
    _version_not_supported = first_version_is_lower(GRPC_VERSION, GRPC_GENERATED_VERSION)
except ImportError:
    _version_not_supported = True

if _version_not_supported:
    raise RuntimeError(
        f'The grpc package installed is at version {GRPC_VERSION},'
        + ' but the generated code in vox_pb2_grpc.py depends on'
        + f' grpcio>={GRPC_GENERATED_VERSION}.'
        + f' Please upgrade your grpc module to grpcio>={GRPC_GENERATED_VERSION}'
        + f' or downgrade your generated code using grpcio-tools<={GRPC_VERSION}.'
    )


class HealthServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Health = channel.unary_unary(
                '/vox.HealthService/Health',
                request_serializer=vox__pb2.HealthRequest.SerializeToString,
                response_deserializer=vox__pb2.HealthResponse.FromString,
                _registered_method=True)
        self.ListLoaded = channel.unary_unary(
                '/vox.HealthService/ListLoaded',
                request_serializer=vox__pb2.ListLoadedRequest.SerializeToString,
                response_deserializer=vox__pb2.ListLoadedResponse.FromString,
                _registered_method=True)


class HealthServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def Health(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListLoaded(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_HealthServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'Health': grpc.unary_unary_rpc_method_handler(
                    servicer.Health,
                    request_deserializer=vox__pb2.HealthRequest.FromString,
                    response_serializer=vox__pb2.HealthResponse.SerializeToString,
            ),
            'ListLoaded': grpc.unary_unary_rpc_method_handler(
                    servicer.ListLoaded,
                    request_deserializer=vox__pb2.ListLoadedRequest.FromString,
                    response_serializer=vox__pb2.ListLoadedResponse.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'vox.HealthService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('vox.HealthService', rpc_method_handlers)



class HealthService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def Health(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.HealthService/Health',
            vox__pb2.HealthRequest.SerializeToString,
            vox__pb2.HealthResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def ListLoaded(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.HealthService/ListLoaded',
            vox__pb2.ListLoadedRequest.SerializeToString,
            vox__pb2.ListLoadedResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)


class ModelServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Pull = channel.unary_stream(
                '/vox.ModelService/Pull',
                request_serializer=vox__pb2.PullRequest.SerializeToString,
                response_deserializer=vox__pb2.PullProgress.FromString,
                _registered_method=True)
        self.List = channel.unary_unary(
                '/vox.ModelService/List',
                request_serializer=vox__pb2.ListModelsRequest.SerializeToString,
                response_deserializer=vox__pb2.ListModelsResponse.FromString,
                _registered_method=True)
        self.Show = channel.unary_unary(
                '/vox.ModelService/Show',
                request_serializer=vox__pb2.ShowRequest.SerializeToString,
                response_deserializer=vox__pb2.ShowResponse.FromString,
                _registered_method=True)
        self.Delete = channel.unary_unary(
                '/vox.ModelService/Delete',
                request_serializer=vox__pb2.DeleteRequest.SerializeToString,
                response_deserializer=vox__pb2.DeleteResponse.FromString,
                _registered_method=True)


class ModelServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def Pull(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def List(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def Show(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def Delete(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_ModelServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'Pull': grpc.unary_stream_rpc_method_handler(
                    servicer.Pull,
                    request_deserializer=vox__pb2.PullRequest.FromString,
                    response_serializer=vox__pb2.PullProgress.SerializeToString,
            ),
            'List': grpc.unary_unary_rpc_method_handler(
                    servicer.List,
                    request_deserializer=vox__pb2.ListModelsRequest.FromString,
                    response_serializer=vox__pb2.ListModelsResponse.SerializeToString,
            ),
            'Show': grpc.unary_unary_rpc_method_handler(
                    servicer.Show,
                    request_deserializer=vox__pb2.ShowRequest.FromString,
                    response_serializer=vox__pb2.ShowResponse.SerializeToString,
            ),
            'Delete': grpc.unary_unary_rpc_method_handler(
                    servicer.Delete,
                    request_deserializer=vox__pb2.DeleteRequest.FromString,
                    response_serializer=vox__pb2.DeleteResponse.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'vox.ModelService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('vox.ModelService', rpc_method_handlers)



class ModelService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def Pull(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_stream(
            request,
            target,
            '/vox.ModelService/Pull',
            vox__pb2.PullRequest.SerializeToString,
            vox__pb2.PullProgress.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def List(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.ModelService/List',
            vox__pb2.ListModelsRequest.SerializeToString,
            vox__pb2.ListModelsResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def Show(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.ModelService/Show',
            vox__pb2.ShowRequest.SerializeToString,
            vox__pb2.ShowResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def Delete(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.ModelService/Delete',
            vox__pb2.DeleteRequest.SerializeToString,
            vox__pb2.DeleteResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)


class TranscriptionServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Transcribe = channel.unary_unary(
                '/vox.TranscriptionService/Transcribe',
                request_serializer=vox__pb2.TranscribeRequest.SerializeToString,
                response_deserializer=vox__pb2.TranscribeResponse.FromString,
                _registered_method=True)
        self.Annotate = channel.unary_unary(
                '/vox.TranscriptionService/Annotate',
                request_serializer=vox__pb2.AnnotateRequest.SerializeToString,
                response_deserializer=vox__pb2.AnnotateResponse.FromString,
                _registered_method=True)


class TranscriptionServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def Transcribe(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def Annotate(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_TranscriptionServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'Transcribe': grpc.unary_unary_rpc_method_handler(
                    servicer.Transcribe,
                    request_deserializer=vox__pb2.TranscribeRequest.FromString,
                    response_serializer=vox__pb2.TranscribeResponse.SerializeToString,
            ),
            'Annotate': grpc.unary_unary_rpc_method_handler(
                    servicer.Annotate,
                    request_deserializer=vox__pb2.AnnotateRequest.FromString,
                    response_serializer=vox__pb2.AnnotateResponse.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'vox.TranscriptionService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('vox.TranscriptionService', rpc_method_handlers)



class TranscriptionService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def Transcribe(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.TranscriptionService/Transcribe',
            vox__pb2.TranscribeRequest.SerializeToString,
            vox__pb2.TranscribeResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def Annotate(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.TranscriptionService/Annotate',
            vox__pb2.AnnotateRequest.SerializeToString,
            vox__pb2.AnnotateResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)


class SynthesisServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Synthesize = channel.unary_stream(
                '/vox.SynthesisService/Synthesize',
                request_serializer=vox__pb2.SynthesizeRequest.SerializeToString,
                response_deserializer=vox__pb2.AudioChunk.FromString,
                _registered_method=True)
        self.ListVoices = channel.unary_unary(
                '/vox.SynthesisService/ListVoices',
                request_serializer=vox__pb2.ListVoicesRequest.SerializeToString,
                response_deserializer=vox__pb2.ListVoicesResponse.FromString,
                _registered_method=True)
        self.CreateVoice = channel.unary_unary(
                '/vox.SynthesisService/CreateVoice',
                request_serializer=vox__pb2.CreateVoiceRequest.SerializeToString,
                response_deserializer=vox__pb2.CreateVoiceResponse.FromString,
                _registered_method=True)
        self.DeleteVoice = channel.unary_unary(
                '/vox.SynthesisService/DeleteVoice',
                request_serializer=vox__pb2.DeleteVoiceRequest.SerializeToString,
                response_deserializer=vox__pb2.DeleteVoiceResponse.FromString,
                _registered_method=True)


class SynthesisServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def Synthesize(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def ListVoices(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def CreateVoice(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')

    def DeleteVoice(self, request, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_SynthesisServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'Synthesize': grpc.unary_stream_rpc_method_handler(
                    servicer.Synthesize,
                    request_deserializer=vox__pb2.SynthesizeRequest.FromString,
                    response_serializer=vox__pb2.AudioChunk.SerializeToString,
            ),
            'ListVoices': grpc.unary_unary_rpc_method_handler(
                    servicer.ListVoices,
                    request_deserializer=vox__pb2.ListVoicesRequest.FromString,
                    response_serializer=vox__pb2.ListVoicesResponse.SerializeToString,
            ),
            'CreateVoice': grpc.unary_unary_rpc_method_handler(
                    servicer.CreateVoice,
                    request_deserializer=vox__pb2.CreateVoiceRequest.FromString,
                    response_serializer=vox__pb2.CreateVoiceResponse.SerializeToString,
            ),
            'DeleteVoice': grpc.unary_unary_rpc_method_handler(
                    servicer.DeleteVoice,
                    request_deserializer=vox__pb2.DeleteVoiceRequest.FromString,
                    response_serializer=vox__pb2.DeleteVoiceResponse.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'vox.SynthesisService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('vox.SynthesisService', rpc_method_handlers)



class SynthesisService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def Synthesize(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_stream(
            request,
            target,
            '/vox.SynthesisService/Synthesize',
            vox__pb2.SynthesizeRequest.SerializeToString,
            vox__pb2.AudioChunk.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def ListVoices(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.SynthesisService/ListVoices',
            vox__pb2.ListVoicesRequest.SerializeToString,
            vox__pb2.ListVoicesResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def CreateVoice(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.SynthesisService/CreateVoice',
            vox__pb2.CreateVoiceRequest.SerializeToString,
            vox__pb2.CreateVoiceResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)

    @staticmethod
    def DeleteVoice(request,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.unary_unary(
            request,
            target,
            '/vox.SynthesisService/DeleteVoice',
            vox__pb2.DeleteVoiceRequest.SerializeToString,
            vox__pb2.DeleteVoiceResponse.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)


class StreamingServiceStub(object):
    """Missing associated documentation comment in .proto file."""

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.StreamTranscribe = channel.stream_stream(
                '/vox.StreamingService/StreamTranscribe',
                request_serializer=vox__pb2.StreamInput.SerializeToString,
                response_deserializer=vox__pb2.StreamOutput.FromString,
                _registered_method=True)


class StreamingServiceServicer(object):
    """Missing associated documentation comment in .proto file."""

    def StreamTranscribe(self, request_iterator, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_StreamingServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'StreamTranscribe': grpc.stream_stream_rpc_method_handler(
                    servicer.StreamTranscribe,
                    request_deserializer=vox__pb2.StreamInput.FromString,
                    response_serializer=vox__pb2.StreamOutput.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'vox.StreamingService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('vox.StreamingService', rpc_method_handlers)



class StreamingService(object):
    """Missing associated documentation comment in .proto file."""

    @staticmethod
    def StreamTranscribe(request_iterator,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.stream_stream(
            request_iterator,
            target,
            '/vox.StreamingService/StreamTranscribe',
            vox__pb2.StreamInput.SerializeToString,
            vox__pb2.StreamOutput.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)


class ConversationServiceStub(object):
    """---------------------------------------------------------------------------
    ConversationService: bidi streaming for agent-facing voice orchestration.
    The agent (any language) terminates WebRTC/SIP/etc. on its own and streams
    PCM into Vox; Vox runs VAD+STT+EOU+state-machine+TTS and streams back
    transcripts, state changes, and synthesized audio.
    ---------------------------------------------------------------------------

    """

    def __init__(self, channel):
        """Constructor.

        Args:
            channel: A grpc.Channel.
        """
        self.Converse = channel.stream_stream(
                '/vox.ConversationService/Converse',
                request_serializer=vox__pb2.ConverseClientMessage.SerializeToString,
                response_deserializer=vox__pb2.ConverseServerMessage.FromString,
                _registered_method=True)


class ConversationServiceServicer(object):
    """---------------------------------------------------------------------------
    ConversationService: bidi streaming for agent-facing voice orchestration.
    The agent (any language) terminates WebRTC/SIP/etc. on its own and streams
    PCM into Vox; Vox runs VAD+STT+EOU+state-machine+TTS and streams back
    transcripts, state changes, and synthesized audio.
    ---------------------------------------------------------------------------

    """

    def Converse(self, request_iterator, context):
        """Missing associated documentation comment in .proto file."""
        context.set_code(grpc.StatusCode.UNIMPLEMENTED)
        context.set_details('Method not implemented!')
        raise NotImplementedError('Method not implemented!')


def add_ConversationServiceServicer_to_server(servicer, server):
    rpc_method_handlers = {
            'Converse': grpc.stream_stream_rpc_method_handler(
                    servicer.Converse,
                    request_deserializer=vox__pb2.ConverseClientMessage.FromString,
                    response_serializer=vox__pb2.ConverseServerMessage.SerializeToString,
            ),
    }
    generic_handler = grpc.method_handlers_generic_handler(
            'vox.ConversationService', rpc_method_handlers)
    server.add_generic_rpc_handlers((generic_handler,))
    server.add_registered_method_handlers('vox.ConversationService', rpc_method_handlers)



class ConversationService(object):
    """---------------------------------------------------------------------------
    ConversationService: bidi streaming for agent-facing voice orchestration.
    The agent (any language) terminates WebRTC/SIP/etc. on its own and streams
    PCM into Vox; Vox runs VAD+STT+EOU+state-machine+TTS and streams back
    transcripts, state changes, and synthesized audio.
    ---------------------------------------------------------------------------

    """

    @staticmethod
    def Converse(request_iterator,
            target,
            options=(),
            channel_credentials=None,
            call_credentials=None,
            insecure=False,
            compression=None,
            wait_for_ready=None,
            timeout=None,
            metadata=None):
        return grpc.experimental.stream_stream(
            request_iterator,
            target,
            '/vox.ConversationService/Converse',
            vox__pb2.ConverseClientMessage.SerializeToString,
            vox__pb2.ConverseServerMessage.FromString,
            options,
            channel_credentials,
            insecure,
            call_credentials,
            compression,
            wait_for_ready,
            timeout,
            metadata,
            _registered_method=True)
