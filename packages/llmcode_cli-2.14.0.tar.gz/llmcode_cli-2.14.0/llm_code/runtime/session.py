"""Session management: immutable Session dataclass, SessionManager for persistence."""
from __future__ import annotations

import dataclasses
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path

from llm_code.api.types import (
    ContentBlock,
    ImageBlock,
    Message,
    TextBlock,
    ThinkingBlock,
    TokenUsage,
    ToolResultBlock,
    ToolUseBlock,
)

# ---------------------------------------------------------------------------
# Token counting (tiktoken when available, else chars // 4)
# ---------------------------------------------------------------------------

try:
    import tiktoken as _tiktoken
    _tokenizer = _tiktoken.get_encoding("cl100k_base")

    def _count_tokens(text: str) -> int:
        return len(_tokenizer.encode(text, disallowed_special=()))
except ImportError:
    def _count_tokens(text: str) -> int:
        return len(text) // 4


# ---------------------------------------------------------------------------
# Serialization helpers
# ---------------------------------------------------------------------------

def _block_to_dict(block: ContentBlock) -> dict:
    # Wave2-1a P3: ThinkingBlock is serialized first so existing
    # deserialization logic for text/tool_use/etc. is unreachable when
    # the block is a thinking block.
    if isinstance(block, ThinkingBlock):
        return {
            "type": "thinking",
            "thinking": block.content,
            "signature": block.signature,
        }
    if isinstance(block, TextBlock):
        return {"type": "text", "text": block.text}
    if isinstance(block, ToolUseBlock):
        return {"type": "tool_use", "id": block.id, "name": block.name, "input": block.input}
    if isinstance(block, ToolResultBlock):
        return {
            "type": "tool_result",
            "tool_use_id": block.tool_use_id,
            "content": block.content,
            "is_error": block.is_error,
        }
    if isinstance(block, ImageBlock):
        return {"type": "image", "media_type": block.media_type, "data": block.data}
    raise ValueError(f"Unknown block type: {type(block)}")


def _dict_to_block(d: dict) -> ContentBlock:
    t = d["type"]
    if t == "thinking":
        # Wave2-1a P3: defensive defaults so a corrupted row (missing
        # signature column before the P5 migration) still rehydrates
        # without crashing. The signature may be stored under the
        # legacy Anthropic field name or the flat column.
        return ThinkingBlock(
            content=d.get("thinking") or d.get("content") or "",
            signature=d.get("signature") or "",
        )
    if t == "text":
        return TextBlock(text=d["text"])
    if t == "tool_use":
        return ToolUseBlock(id=d["id"], name=d["name"], input=d["input"])
    if t == "tool_result":
        return ToolResultBlock(
            tool_use_id=d["tool_use_id"],
            content=d["content"],
            is_error=d.get("is_error", False),
        )
    if t == "image":
        return ImageBlock(media_type=d["media_type"], data=d["data"])
    raise ValueError(f"Unknown block type: {t}")


def _message_to_dict(msg: Message) -> dict:
    return {
        "role": msg.role,
        "content": [_block_to_dict(b) for b in msg.content],
    }


def _dict_to_message(d: dict) -> Message:
    return Message(
        role=d["role"],
        content=tuple(_dict_to_block(b) for b in d["content"]),
    )


# ---------------------------------------------------------------------------
# Session
# ---------------------------------------------------------------------------

@dataclasses.dataclass(frozen=True)
class Session:
    id: str
    messages: tuple[Message, ...]
    created_at: str
    updated_at: str
    total_usage: TokenUsage
    project_path: Path
    name: str = ""
    tags: tuple[str, ...] = ()

    @classmethod
    def create(cls, project_path: Path) -> "Session":
        """Create a new empty session with a unique 8-char hex ID."""
        now = datetime.now(timezone.utc).isoformat()
        session_id = uuid.uuid4().hex[:8]
        return cls(
            id=session_id,
            messages=(),
            created_at=now,
            updated_at=now,
            total_usage=TokenUsage(input_tokens=0, output_tokens=0),
            project_path=project_path,
        )

    def add_message(self, msg: Message) -> "Session":
        """Return a new Session with the message appended (immutable)."""
        now = datetime.now(timezone.utc).isoformat()
        return dataclasses.replace(
            self,
            messages=self.messages + (msg,),
            updated_at=now,
        )

    def rename(self, name: str) -> "Session":
        """Return a new Session with the given name (immutable)."""
        now = datetime.now(timezone.utc).isoformat()
        return dataclasses.replace(self, name=name, updated_at=now)

    def add_tags(self, *tags: str) -> "Session":
        """Return a new Session with tags merged (deduped, order-preserving, immutable)."""
        merged = tuple(dict.fromkeys(self.tags + tags))
        now = datetime.now(timezone.utc).isoformat()
        return dataclasses.replace(self, tags=merged, updated_at=now)

    def update_usage(self, usage: TokenUsage) -> "Session":
        """Return a new Session with accumulated token usage (immutable)."""
        now = datetime.now(timezone.utc).isoformat()
        new_usage = TokenUsage(
            input_tokens=self.total_usage.input_tokens + usage.input_tokens,
            output_tokens=self.total_usage.output_tokens + usage.output_tokens,
        )
        return dataclasses.replace(self, total_usage=new_usage, updated_at=now)

    def estimated_tokens(self) -> int:
        """Rough token estimate for pre-turn context size check.

        Uses tiktoken (cl100k_base) when available for accurate counts,
        otherwise falls back to chars/4.  Adds a fixed overhead for the
        system prompt and tool definitions not included in messages.
        After the first API call, conversation.py uses the actual
        API-reported input_tokens instead of this estimate.
        """
        _SYSTEM_OVERHEAD = 4000  # system prompt + tool schemas
        parts: list[str] = []
        for msg in self.messages:
            for block in msg.content:
                # Wave2-1a P3: thinking blocks occupy real tokens when
                # the provider requires round-tripping them (Anthropic
                # extended thinking). Counting them here ensures the
                # proactive-compaction trigger fires early enough.
                if isinstance(block, ThinkingBlock):
                    parts.append(block.content)
                elif isinstance(block, TextBlock):
                    parts.append(block.text)
                elif isinstance(block, ToolResultBlock):
                    parts.append(block.content)
                elif isinstance(block, ToolUseBlock):
                    parts.append(block.name)
                    parts.append(str(block.input))
        text = "".join(parts)
        return _count_tokens(text) + _SYSTEM_OVERHEAD

    def to_dict(self) -> dict:
        return {
            "_schema_version": 3,
            "id": self.id,
            "messages": [_message_to_dict(m) for m in self.messages],
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "total_usage": {
                "input_tokens": self.total_usage.input_tokens,
                "output_tokens": self.total_usage.output_tokens,
            },
            "project_path": str(self.project_path),
            "name": self.name,
            "tags": list(self.tags),
        }

    @classmethod
    def from_dict(cls, data: dict) -> "Session":
        return cls(
            id=data["id"],
            messages=tuple(_dict_to_message(m) for m in data["messages"]),
            created_at=data["created_at"],
            updated_at=data["updated_at"],
            total_usage=TokenUsage(
                input_tokens=data["total_usage"]["input_tokens"],
                output_tokens=data["total_usage"]["output_tokens"],
            ),
            project_path=Path(data["project_path"]),
            name=data.get("name", ""),
            tags=tuple(data.get("tags", ())),
        )


# ---------------------------------------------------------------------------
# SessionSummary
# ---------------------------------------------------------------------------

@dataclasses.dataclass(frozen=True)
class SessionSummary:
    id: str
    project_path: Path
    created_at: str
    message_count: int
    name: str = ""
    tags: tuple[str, ...] = ()


# ---------------------------------------------------------------------------
# SessionManager
# ---------------------------------------------------------------------------

class SessionManager:
    def __init__(self, session_dir: Path) -> None:
        self._session_dir = session_dir
        session_dir.mkdir(parents=True, exist_ok=True)

    def save(self, session: Session) -> Path:
        """Persist session as JSON; returns the file path."""
        path = self._session_dir / f"{session.id}.json"
        path.write_text(json.dumps(session.to_dict(), indent=2), encoding="utf-8")
        return path

    def load(self, session_id: str) -> Session:
        """Load session by ID; raises FileNotFoundError if missing.

        Routes through session_migration.load_and_migrate so older schema
        versions are upgraded, orphan thinking filtered, and tool chains
        rebuilt before ``Session.from_dict`` deserializes the result.
        """
        path = self._session_dir / f"{session_id}.json"
        if not path.exists():
            raise FileNotFoundError(f"Session '{session_id}' not found at {path}")
        data = json.loads(path.read_text(encoding="utf-8"))
        try:
            from llm_code.runtime.session_migration import load_and_migrate
            data = dict(data)
            data["messages"] = load_and_migrate(path)
        except Exception:  # pragma: no cover - defensive
            pass
        return Session.from_dict(data)

    def list_sessions(self) -> list[SessionSummary]:
        """Return session summaries sorted by modification time (most recent first)."""
        files = sorted(
            self._session_dir.glob("*.json"),
            key=lambda p: p.stat().st_mtime,
            reverse=True,
        )
        summaries: list[SessionSummary] = []
        for f in files:
            try:
                data = json.loads(f.read_text(encoding="utf-8"))
                summaries.append(
                    SessionSummary(
                        id=data["id"],
                        project_path=Path(data["project_path"]),
                        created_at=data["created_at"],
                        message_count=len(data["messages"]),
                        name=data.get("name", ""),
                        tags=tuple(data.get("tags", ())),
                    )
                )
            except (json.JSONDecodeError, KeyError):
                continue
        return summaries

    def rename(self, session_id: str, name: str) -> Session:
        """Rename a session and persist the change; returns updated Session."""
        session = self.load(session_id)
        renamed = session.rename(name)
        self.save(renamed)
        return renamed

    def delete(self, session_id: str) -> bool:
        """Delete a session file; returns True if deleted, False if not found."""
        path = self._session_dir / f"{session_id}.json"
        if not path.exists():
            return False
        path.unlink()
        return True

    def search(self, query: str) -> list[SessionSummary]:
        """Return summaries whose name, project path, or tags contain query (case-insensitive)."""
        query_lower = query.lower()
        return [
            s for s in self.list_sessions()
            if query_lower in s.name.lower()
            or query_lower in str(s.project_path).lower()
            or any(query_lower in t.lower() for t in s.tags)
        ]

    def get_by_name(self, name: str) -> Session | None:
        """Return the first Session whose name matches exactly, or None."""
        for summary in self.list_sessions():
            if summary.name == name:
                return self.load(summary.id)
        return None
