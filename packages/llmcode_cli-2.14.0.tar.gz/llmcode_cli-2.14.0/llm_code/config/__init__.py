"""Configuration support package."""
