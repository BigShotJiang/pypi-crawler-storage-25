::: AeroViz.plot.meteorology.CBPF
