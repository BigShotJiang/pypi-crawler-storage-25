::: AeroViz.plot.optical
