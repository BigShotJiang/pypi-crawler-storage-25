::: AeroViz.plot.bar.bar
