"""ARAX (AI-Readiness & Agent Experience) Dimension Calculator.

Calculates the ARAX dimension score by aggregating signal values.

Formula:
    DimensionScore = 100 × (sum of normalised signals) / (number of signals)

All signals are treated equally (no weighting within dimension in v1).
"""

from ....enums import DIMENSION_WEIGHTS, DimensionKind
from ....models import DimensionScore, ScoreContext, Signal
from ...grade import calculate_grade
from ...signals.registry import list_signals
from .. import aggregate_signal_values


__all__ = ["calculate_dimension_score"]


def calculate_dimension_score(ctx: ScoreContext) -> DimensionScore:
    """Calculate the AI-Readiness & Agent Experience (ARAX) dimension score.

    Executes all ARAX signal calculators and aggregates their normalized values
    into a dimension score using arithmetic mean scaled to 0-100 range.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        DimensionScore with:
        - kind: DimensionKind.ARAX
        - name: "AI-Readiness & Agent Experience"
        - score: 0-100 aggregate score
        - signals: List of individual Signal results
        - weight: From DIMENSION_WEIGHTS[DimensionKind.ARAX]
        - description: Dimension purpose

    Example:
        Given signals with values [0.78, 0.82, 0.85, 0.88, 0.90, 0.92, 0.95]:
        ARAX score = 100 × (0.78 + 0.82 + 0.85 + 0.88 + 0.90 + 0.92 + 0.95) / 7 ≈ 87.14
    """
    # Get all signal configurations for ARAX dimension from registry
    signal_configs = list_signals(dimension=DimensionKind.ARAX)

    # Execute each signal calculator and collect results
    signals: list[Signal] = []
    for signal_config in signal_configs:
        # Execute the calculator with the context
        signal = signal_config.calculator(ctx, signal_config)
        signals.append(signal)

    # Calculate dimension score using arithmetic mean
    # Formula: 100 × (sum of signal values) / count
    score = aggregate_signal_values(signals)

    # Create and return dimension score
    return DimensionScore(
        kind=DimensionKind.ARAX,
        name="AI-Readiness & Agent Experience",
        score=score,
        grade=calculate_grade(score),
        signals=signals,
        weight=DIMENSION_WEIGHTS[DimensionKind.ARAX],
        description="Semantic breadth, depth, and agent comprehension for AI systems.",
    )
