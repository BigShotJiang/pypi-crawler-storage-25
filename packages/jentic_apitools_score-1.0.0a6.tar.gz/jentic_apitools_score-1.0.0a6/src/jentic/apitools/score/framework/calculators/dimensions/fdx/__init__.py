"""FDX (Foundational & DX) group dimension calculators.

This group contains two dimensions:
- FC (Foundational Compliance): Base layer of spec validity and structural soundness
- DXJ (DX & Jentic Compatibility): Developer experience and tooling readiness
"""

from . import dxj, fc


__all__ = ["fc", "dxj"]
