"""Enum definitions for the API Scoring Framework.

This module defines the enum types used throughout the scoring system,
including groups, dimensions, signal types, and their relationships.
"""

from enum import Enum
from types import MappingProxyType


__all__ = [
    "GroupKind",
    "DimensionKind",
    "BuiltinSignal",
    "SpecType",
    "Maturity",
    "Grade",
    "DiagnosticSeverityWeight",
    "DIMENSION_TO_GROUP",
    "DIMENSION_WEIGHTS",
]


class GroupKind(str, Enum):
    """Group categories in the scoring framework.

    Groups represent the strategic organization of dimensions into
    three themed areas of API maturity assessment.
    """

    FDX = "FDX"
    """Foundational & DX: Human-oriented and tooling alignment.

    Evaluates whether APIs are standards-compliant, linted, and usable by developers.
    Includes compatibility with Jentic ingestion pipeline requirements.
    """

    AIRU = "AIRU"
    """AI-Readiness & Usability: Machine-oriented semantic clarity.

    Evaluates how interpretable, structured, and semantically rich APIs are for
    AI agents and autonomous systems.
    """

    TSD = "TSD"
    """Trust/Safety & Discoverability: Ecosystem-oriented governance.

    Evaluates how governable, secure, and findable APIs are across AI and
    agent systems.
    """


class DimensionKind(str, Enum):
    """Dimension categories in the scoring framework."""

    FC = "FC"
    """Foundational Compliance: Base layer of quality and conformance."""

    DXJ = "DXJ"
    """Developer Experience & Jentic Compatibility: Clarity, completeness, and ingestion readiness."""

    ARAX = "ARAX"
    """AI-Readiness & Agent Experience: Semantic breadth, depth, and agent comprehension."""

    AU = "AU"
    """Agent Usability: Functional utility, complexity, and AI orchestration possibilities."""

    SEC = "SEC"
    """Security: Trust, compliance, and risk posture."""

    AID = "AID"
    """AI Discoverability: Findability, semantic richness, and reasoning readiness."""


class BuiltinSignal(str, Enum):
    """Built-in signal identifiers for the scoring framework.

    This enum documents all standard signals defined in the framework specification.
    The Signal.name field remains a string type to allow custom/extended signals
    while this enum provides autocomplete and documentation for built-in signals.

    Version 0.1 implements Group A (Foundational & DX) signals only.
    Groups B and C signals are documented but not yet implemented.
    """

    # Group: Foundational & DX (FDX)
    # Dimension: Foundational Compliance (FC)
    SPEC_VALIDITY = "spec_validity"
    """Does the API specification parse successfully? (binary)"""

    RESOLUTION_COMPLETENESS = "resolution_completeness"
    """Percentage of $refs resolved successfully (coverage)"""

    LINT_RESULTS = "lint_results"
    """Severity-weighted inverse linter score (severity-weighted)"""

    STRUCTURAL_INTEGRITY = "structural_integrity"
    """Schema/model interpretability (inverse-error)"""

    # Group: Foundational & DX (FDX)
    # Dimension: Developer Experience & Jentic Compatibility Baseline (DXJ)
    EXAMPLE_DENSITY = "example_density"
    """How richly the API is illustrated with examples (coverage)"""

    EXAMPLE_VALIDITY = "example_validity"
    """How many examples conform to schemas (coverage)"""

    DOC_CLARITY = "doc_clarity"
    """Linguistic clarity using readability metrics (custom)"""

    RESPONSE_COVERAGE = "response_coverage"
    """How many operations define realistic outcomes (coverage)"""

    TOOLING_READINESS = "tooling_readiness"
    """Jentic ingestion health (inverse-error)"""

    # Group: AI-Readiness & Usability (AIRU)
    # Dimension: AI-Readiness & Agent Experience (ARAX)
    SUMMARY_COVERAGE = "summary_coverage"
    """Coverage of summaries across operations/tags/info (coverage)"""

    DESCRIPTION_COVERAGE = "description_coverage"
    """Coverage of descriptions across API elements (coverage)"""

    TYPE_SPECIFICITY = "type_specificity"
    """Semantic expressiveness of datatypes, formats, enums (weighted)"""

    POLICY_PRESENCE = "policy_presence"
    """Operations with SLA/rate-limit/policy metadata (coverage)"""

    ERROR_STANDARDIZATION = "error_standardization"
    """RFC 9457 Problem Details usage (coverage)"""

    OPID_QUALITY = "opid_quality"
    """OperationId coverage × distinctiveness (combined)"""

    AI_SEMANTIC_SURFACE = "ai_semantic_surface"
    """Bonus multiplier for x-intent, Arazzo, AI hints (bonus)"""

    # Group: AI-Readiness & Usability (AIRU)
    # Dimension: Agent Usability (AU)
    COMPLEXITY_COMFORT = "complexity_comfort"
    """Penalty for document size/endpoint density using logistic curve (logistic)"""

    DISTINCTIVENESS = "distinctiveness"
    """Inverse of operation semantic similarity (inverse)"""

    PAGINATION = "pagination"
    """Ratio of paginated collection GETs (coverage)"""

    HYPERMEDIA_SUPPORT = "hypermedia_support"
    """HATEOAS/JSON:API/HAL affordances (coverage)"""

    INTENT_LEGIBILITY = "intent_legibility"
    """Semantic match to canonical action verbs (semantic)"""

    SAFETY = "safety"
    """Idempotency + sensitive operation protections (combined)"""

    TOOL_CALLING_ALIGNMENT = "tool_calling_alignment"
    """OpenAI/Anthropic function calling readiness (coverage)"""

    NAVIGATION = "navigation"
    """Combines pagination + hypermedia with links bonus (composite)"""

    # Group: Trust/Safety & Discoverability (TSD)
    # Dimension: Security (SEC)
    AUTH_COVERAGE = "auth_coverage"
    """Operations requiring auth vs expected (coverage)"""

    AUTH_STRENGTH = "auth_strength"
    """Quality of security schemes (weighted)"""

    TRANSPORT_SECURITY = "transport_security"
    """HTTPS usage on public endpoints (coverage)"""

    SECRET_HYGIENE = "secret_hygiene"
    """No hardcoded credentials detected (binary)"""

    SENSITIVE_HANDLING = "sensitive_handling"
    """Protected PII fields / total PII fields (coverage)"""

    OWASP_POSTURE = "owasp_posture"
    """OWASP API Top 10 ruleset with sqrt dampening (severity-weighted)"""

    # Group: Trust/Safety & Discoverability (TSD)
    # Dimension: AI Discoverability (AID)
    DESCRIPTIVE_RICHNESS = "descriptive_richness"
    """Clarity and depth of descriptions across levels (custom)"""

    INTENT_PHRASING = "intent_phrasing"
    """Verb-object clarity in summaries (semantic)"""

    WORKFLOW_CONTEXT = "workflow_context"
    """Operations with workflow/use-case references (coverage)"""

    REGISTRY_SIGNALS = "registry_signals"
    """llms.txt, APIs.json, MCP, externalDocs indicators (coverage)"""

    DOMAIN_TAGGING = "domain_tagging"
    """Operations with domain/taxonomy tags (coverage)"""


class SpecType(str, Enum):
    """Supported API specification types.

    Currently only OpenAPI is supported. Future versions may add support for
    other specification formats like Swagger 2.0, AsyncAPI, or Google Discovery.
    """

    OPENAPI = "openapi"
    """OpenAPI Specification (3.x+)"""


class Maturity(str, Enum):
    """API maturity levels based on final score thresholds.

    Maturity levels represent the staged progression of API quality toward
    AI-Readiness, mapped from the final score (0-100) to categorical levels.

    Each level represents a qualitative milestone in API maturity:
    - non-ready: APIs that fail basic quality standards
    - foundational: Developer-ready APIs with foundational quality
    - ai-aware: APIs beginning to support AI use cases
    - ai-ready: Fully AI-ready APIs with strong semantic clarity
    - agent-optimized: Optimized for autonomous agent operation
    """

    LEVEL_0 = "non-ready"
    """Not Ready (score < 40).

    APIs at this level have significant quality issues and are not suitable
    for production use by developers or AI systems.
    """

    LEVEL_1 = "foundational"
    """Foundational / Developer Ready (score 40-60).

    APIs meet basic quality standards with proper structure and documentation,
    suitable for human developers but limited AI comprehension.
    """

    LEVEL_2 = "ai-aware"
    """AI-Aware (score 60-75).

    APIs demonstrate awareness of AI needs with improved semantic clarity
    and structure, enabling basic AI agent interaction.
    """

    LEVEL_3 = "ai-ready"
    """AI-Ready (score 75-90).

    APIs are well-optimized for AI consumption with rich semantics,
    clear intent, and strong structural quality.
    """

    LEVEL_4 = "agent-optimized"
    """Agent-Optimised (score 90+).

    APIs represent excellence in AI-Readiness with comprehensive semantic
    metadata, optimal structure, and full support for autonomous agents.
    """


class Grade(str, Enum):
    """Letter grades for API quality scores on the 0-100 scale.

    Grades provide a familiar, intuitive representation of API quality scores
    for richer graphical representation and easier interpretation. They map
    from numerical scores (0-100) to letter grades (A+ through F).

    Grade levels mirror academic grading systems, with A+ representing
    exceptional quality (90-100) and F representing failing quality (< 40).

    Each grade maps to a specific score range:
    - A+ represents exceptional quality (90-100)
    - A through A- represent excellent quality (70-89)
    - B+ through B- represent good quality (60-69)
    - C+ through C- represent satisfactory quality (50-59)
    - D+ through D- represent poor quality (40-49)
    - F represents failing quality (< 40)

    Grades can be applied to any score in the hierarchy:
    - Final scores (overall API quality)
    - Group scores (FDX, AIRU, TSD)
    - Dimension scores (FC, DXJ, ARAX, AU, SEC, AID)
    """

    A_PLUS = "A+"
    """Exceptional (90-100).

    Represents exceptional API quality. APIs at this level demonstrate
    excellence across all measured dimensions.
    """

    A = "A"
    """Excellent (80-89).

    Represents excellent API quality with strong performance across
    most dimensions.
    """

    A_MINUS = "A-"
    """Very Good (70-79).

    Represents very good API quality with solid performance across
    dimensions.
    """

    B_PLUS = "B+"
    """Good+ (67-69).

    Represents good API quality, above average performance.
    """

    B = "B"
    """Good (63-66).

    Represents good API quality with average to above-average performance.
    """

    B_MINUS = "B-"
    """Good- (60-62).

    Represents acceptable API quality, meeting basic good standards.
    """

    C_PLUS = "C+"
    """Satisfactory+ (57-59).

    Represents satisfactory API quality, above minimum acceptable standards.
    """

    C = "C"
    """Satisfactory (53-56).

    Represents minimally satisfactory API quality.
    """

    C_MINUS = "C-"
    """Satisfactory- (50-52).

    Represents barely satisfactory API quality, needs improvement.
    """

    D_PLUS = "D+"
    """Poor+ (47-49).

    Represents poor API quality, approaching unsatisfactory.
    """

    D = "D"
    """Poor (43-46).

    Represents poor API quality with significant issues.
    """

    D_MINUS = "D-"
    """Poor- (40-42).

    Represents poor API quality, barely passing minimum standards.
    """

    F = "F"
    """Failing (< 40).

    Represents failing API quality. APIs at this level have critical
    quality issues and are not suitable for production use.
    """


class DiagnosticSeverityWeight(float, Enum):
    """Diagnostic severity weights for linting quality calculation.

    These weights represent the relative impact of each severity level
    in the weighted cost calculation used by lint_results signal and
    severity_weighted_inverse normalizer.

    The enum extends float to allow direct arithmetic operations:
        weighted_cost = DiagnosticSeverityWeight.CRITICAL * count

    Severity levels and their weights:
    - CRITICAL: Highest impact - spec parse failures, critical violations
    - ERROR: Serious issues that should be fixed
    - WARNING: Potential problems worth reviewing
    - INFO: Lowest impact - suggestions and minor improvements
    """

    CRITICAL = 1.0
    """Critical severity weight (highest impact)."""

    ERROR = 0.6
    """Error severity weight."""

    WARNING = 0.0025
    """Warning severity weight."""

    INFO = 0.001
    """Info severity weight (second lowest impact)."""

    HINT = 0.0
    """Hint severity weight (lowest impact)."""


# Mapping of dimensions to their parent groups
DIMENSION_TO_GROUP: MappingProxyType[DimensionKind, GroupKind] = MappingProxyType(
    {
        DimensionKind.FC: GroupKind.FDX,
        DimensionKind.DXJ: GroupKind.FDX,
        DimensionKind.ARAX: GroupKind.AIRU,
        DimensionKind.AU: GroupKind.AIRU,
        DimensionKind.SEC: GroupKind.TSD,
        DimensionKind.AID: GroupKind.TSD,
    }
)

# Dimension weights for final score calculation
# All dimensions now have at least one signal implemented, so we use target weights.
# These weights define the relative importance of each dimension in the overall score.
# Weights must sum to 1.0 for proper normalization in the weighted harmonic mean.
DIMENSION_WEIGHTS: MappingProxyType[DimensionKind, float] = MappingProxyType(
    {
        DimensionKind.FC: 0.16,  # Foundational Compliance: 16%
        DimensionKind.DXJ: 0.18,  # Developer Experience: 18%
        DimensionKind.ARAX: 0.24,  # AI-Readiness: 24%
        DimensionKind.AU: 0.20,  # Agent Usability: 20%
        DimensionKind.SEC: 0.12,  # Security: 12%
        DimensionKind.AID: 0.10,  # AI Discoverability: 10%
    }
)
