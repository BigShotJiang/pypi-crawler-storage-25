"""ARAX Signal: Error Standardization

Measures the percentage of operations using RFC 9457 (formerly RFC 7807)
Problem Details for error responses.

This signal evaluates whether API operations use standardized error response
formats (RFC 9457/7807 Problem Details) for their error responses (4xx, 5xx).
Standardized errors improve AI agent comprehension and error handling.

RFC 9457 supersedes RFC 7807 and defines the Problem Details format:
- Media types: application/problem+json, application/problem+xml
- Fields: type, title, status, detail, instance

Detection uses two tiers:
1. Media type check: application/problem+json or application/problem+xml
2. Schema inspection: At least 2 RFC 9457/7807 fields (type, title, status, detail, instance)

Formula:
    error_standardization = operations_using_RFC9457 / total_operations

Special case:
    If total_operations = 0, returns 1.0 (no penalty for irrelevance)
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.ERROR_STANDARDIZATION,
    name="Error Standardization",
    description="Coverage of RFC 9457 Problem Details for error responses.",
    group=GroupKind.AIRU,
    dimension=DimensionKind.ARAX,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def error_standardization(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate error standardization signal based on RFC 9457 usage.

    Expects ctx.diagnostics to contain:
    - "operations_using_RFC9457": Count of operations with RFC 9457 error responses
    - "total_operations": Total count of operations

    Formula:
        error_standardization = operations_using_RFC9457 / total_operations

    If total_operations = 0, returns 1.0 (no operations to evaluate).

    Args:
        ctx: Scoring context with diagnostics containing operation counts
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], RFC9457 count as raw_value,
        and breakdown metadata
    """

    operations_using_rfc9457 = 0
    total_operations = 0

    # Find diagnostics and extract values
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            if diagnostic.code == DiagnosticCode.OPERATIONS_USING_RFC9457 and isinstance(
                diagnostic.data, dict
            ):
                operations_using_rfc9457 = diagnostic.data.get(
                    DiagnosticCode.OPERATIONS_USING_RFC9457, 0
                )
            elif diagnostic.code == DiagnosticCode.TOTAL_OPERATIONS and isinstance(
                diagnostic.data, dict
            ):
                total_operations = diagnostic.data.get(DiagnosticCode.TOTAL_OPERATIONS, 0)

    # Ensure values are integers
    try:
        operations_using_rfc9457 = int(operations_using_rfc9457)
        total_operations = int(total_operations)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid operation count values in diagnostics: "
            "operations_using_rfc9457=%r, total_operations=%r. "
            "Defaulting to 0. This may indicate a data quality issue in the diagnostics pipeline.",
            operations_using_rfc9457,
            total_operations,
        )
        operations_using_rfc9457 = 0
        total_operations = 0

    # Clamp: using cannot exceed total (defensive against inconsistent diagnostics)
    if operations_using_rfc9457 > total_operations and total_operations > 0:
        logger.warning(
            "operations_using_rfc9457 (%d) exceeds total_operations (%d); clamping",
            operations_using_rfc9457,
            total_operations,
        )
        operations_using_rfc9457 = total_operations
    operations_without_rfc9457 = total_operations - operations_using_rfc9457

    # Normalize using coverage (handles division by zero with default=1.0)
    normalized_value = config.normalizer(
        count_present=float(operations_using_rfc9457),
        count_expected=float(total_operations),
    )

    return Signal(
        value=normalized_value,
        raw_value=operations_using_rfc9457,
        metadata={
            "operations_using_rfc9457": operations_using_rfc9457,
            "operations_without_rfc9457": operations_without_rfc9457,
            "total_operations": total_operations,
            "provenance": {
                "diagnostics": {
                    "code": [
                        DiagnosticCode.OPERATIONS_USING_RFC9457,
                        DiagnosticCode.TOTAL_OPERATIONS,
                    ]
                },
            },
        },
    )
