"""FDX (Foundational & DX) Group Calculator.

Calculates the FDX group score by aggregating FC and DXJ dimension scores.

Formula:
    GroupScore = (FC_score × 0.16 + DXJ_score × 0.18) / (0.16 + 0.18)
               = (FC_score × 0.16 + DXJ_score × 0.18) / 0.34
"""

from ...enums import GroupKind
from ...models import DimensionScore, GroupScore, ScoreContext
from ..dimensions.fdx import dxj, fc
from ..grade import calculate_grade
from . import aggregate_dimension_scores


__all__ = ["calculate_group_score"]


def calculate_group_score(ctx: ScoreContext) -> GroupScore:
    """Calculate the Foundational & DX (FDX) group score.

    Executes FC and DXJ dimension calculators and aggregates their scores
    using weighted average.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        GroupScore with:
        - kind: GroupKind.FDX
        - name: "Foundational & DX"
        - score: 0-100 weighted aggregate score
        - dimension_scores: List of DimensionScore results [FC, DXJ]
        - focus: Group theme description

    Example:
        Given FC = 80.0 (weight 0.16) and DXJ = 60.0 (weight 0.18):
        FDX score = (80 × 0.16 + 60 × 0.18) / 0.34 ≈ 69.41
    """
    # Calculate dimension scores
    fc_dimension = fc.calculate_dimension_score(ctx)
    dxj_dimension = dxj.calculate_dimension_score(ctx)

    dimension_scores: list[DimensionScore] = [fc_dimension, dxj_dimension]

    # Calculate group score using weighted average
    score = aggregate_dimension_scores(dimension_scores)

    # Create and return group score
    return GroupScore(
        kind=GroupKind.FDX,
        name="Foundational & DX",
        score=score,
        grade=calculate_grade(score),
        dimension_scores=dimension_scores,
        description="Human-oriented and tooling alignment - standards compliance, linting, and developer usability.",
    )
