"""AU Signal: Complexity Comfort

Measures how comfortable an AI agent would be operating on this API based on
operational complexity (endpoint count) and structural complexity (schema depth).

This signal evaluates two dimensions of API complexity:
1. Operational complexity: number of callable endpoints
2. Structural complexity: depth of schema nesting, weighted by prevalence

The signal uses a sigmoid curve to gradually reduce score as complexity increases,
avoiding harsh penalties for moderately large APIs while still penalizing
extremely complex ones.

Formula (JAIRF v1.0.0):
    normalised_endpoint_count = max(0, min(1, (total_operations - 50) / 150))
    pct_schemas_exceeding = schemas_exceeding_threshold / schema_count
    normalised_schema_depth = min(1, (max_schema_depth / depth_baseline) * pct_schemas_exceeding)
    raw_complexity = 0.5 * normalised_endpoint_count + 0.5 * normalised_schema_depth
    complexity_comfort = 1 / (1 + exp(6 * (raw_complexity - 0.45)))

Where:
    - Endpoint penalties begin at 50 operations and reach maximum at 200 operations
    - depth_baseline = 18
    - pct_schemas_exceeding is the proportion of schemas exceeding the depth threshold
    - The penalty is proportional to schema depth prevalence, not just maximum depth

The sigmoid curve provides:
- No penalty for APIs with <= 50 endpoints
- Gradual penalty from 50-200 endpoints
- Schema depth penalty proportional to how many schemas are deeply nested
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import LogisticShapingNormalizer, clamp, logistic_shaping, safe_divide
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.COMPLEXITY_COMFORT,
    name="Complexity Comfort",
    description="Agent comfort level based on API operational and structural complexity.",
    group=GroupKind.AIRU,
    dimension=DimensionKind.AU,
    normalizer=logistic_shaping,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def complexity_comfort(
    ctx: ScoreContext, config: SignalConfig[LogisticShapingNormalizer]
) -> Signal:
    """Calculate complexity comfort signal based on endpoint count and schema depth.

    Extracts total_operations, max_schema_depth, schema_count, and
    schemas_exceeding_threshold from diagnostics, then calculates
    normalized complexity metrics and applies sigmoid curve.

    Formula (JAIRF v1.0.0):
        normalised_endpoint_count = max(0, min(1, (total_operations - 50) / 150))
        pct_schemas_exceeding = schemas_exceeding_threshold / schema_count
        normalised_schema_depth = min(1, (max_schema_depth / 18) * pct_schemas_exceeding)
        raw_complexity = 0.5 * normalised_endpoint_count + 0.5 * normalised_schema_depth
        complexity_comfort = 1 / (1 + exp(6 * (raw_complexity - 0.45)))

    Special cases:
        - If total_operations <= 50, normalised_endpoint_count = 0 (comfort zone)
        - If schema_count = 0, pct_schemas_exceeding = 0 (no schemas to evaluate)
        - Callbacks and webhooks are NOT counted in total_operations

    Args:
        ctx: Scoring context with diagnostics
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], raw_complexity as raw_value,
        and breakdown metadata
    """
    # Constants from JAIRF v1.0.0 specification
    endpoint_baseline_start = 50.0  # penalties begin at 50 operations
    endpoint_baseline_range = 150.0  # reach maximum at 200 operations (50 + 150)
    depth_baseline = 18.0

    # Extract metrics from diagnostics
    total_operations = 0
    max_schema_depth = 0
    schema_count = 0
    schemas_exceeding_threshold = 0

    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            if diagnostic.code == DiagnosticCode.TOTAL_OPERATIONS and isinstance(
                diagnostic.data, dict
            ):
                total_operations = diagnostic.data.get(DiagnosticCode.TOTAL_OPERATIONS, 0)
            elif diagnostic.code == DiagnosticCode.MAX_SCHEMA_DEPTH and isinstance(
                diagnostic.data, dict
            ):
                max_schema_depth = diagnostic.data.get(DiagnosticCode.MAX_SCHEMA_DEPTH, 0)
                deep_paths = diagnostic.data.get("paths", [])
                schemas_exceeding_threshold = len(deep_paths) if isinstance(deep_paths, list) else 0
            elif diagnostic.code == DiagnosticCode.SCHEMA_COUNT and isinstance(
                diagnostic.data, dict
            ):
                schema_count = diagnostic.data.get(DiagnosticCode.SCHEMA_COUNT, 0)

    # Ensure values are numeric
    try:
        total_operations = int(total_operations)
        max_schema_depth = int(max_schema_depth)
        schema_count = int(schema_count)
        schemas_exceeding_threshold = int(schemas_exceeding_threshold)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid complexity metrics in diagnostics: "
            "total_operations=%r, max_schema_depth=%r, schema_count=%r, "
            "schemas_exceeding_threshold=%r. Defaulting to 0.",
            total_operations,
            max_schema_depth,
            schema_count,
            schemas_exceeding_threshold,
        )
        total_operations = 0
        max_schema_depth = 0
        schema_count = 0
        schemas_exceeding_threshold = 0

    # JAIRF v1.0.0: penalties begin at 50 operations, max at 200
    normalised_endpoint_count = clamp(
        (total_operations - endpoint_baseline_start) / endpoint_baseline_range
    )

    # JAIRF v1.0.0: depth penalty proportional to prevalence of deep schemas
    # Note: schemas_exceeding_threshold comes from post-deref traversal while schema_count
    # comes from pre-deref. Clamped to [0, 1] to handle potential inflation from inlined refs.
    pct_schemas_exceeding = clamp(
        safe_divide(schemas_exceeding_threshold, schema_count, default=0.0)
    )
    normalised_schema_depth = clamp((max_schema_depth / depth_baseline) * pct_schemas_exceeding)

    # Calculate raw complexity (weighted average)
    raw_complexity = 0.5 * normalised_endpoint_count + 0.5 * normalised_schema_depth

    # Apply logistic shaping (sigmoid curve)
    # Uses defaults: midpoint=0.45 and steepness=6.0
    normalized_value = config.normalizer(raw_complexity=raw_complexity)

    return Signal(
        value=normalized_value,
        raw_value=raw_complexity,
        metadata={
            "total_operations": total_operations,
            "max_schema_depth": max_schema_depth,
            "schema_count": schema_count,
            "schemas_exceeding_threshold": schemas_exceeding_threshold,
            "pct_schemas_exceeding": pct_schemas_exceeding,
            "normalised_endpoint_count": normalised_endpoint_count,
            "normalised_schema_depth": normalised_schema_depth,
            "raw_complexity": raw_complexity,
            "endpoint_baseline_start": endpoint_baseline_start,
            "endpoint_baseline_range": endpoint_baseline_range,
            "depth_baseline": depth_baseline,
            "provenance": {
                "diagnostics": {
                    "code": [
                        DiagnosticCode.TOTAL_OPERATIONS,
                        DiagnosticCode.MAX_SCHEMA_DEPTH,
                        DiagnosticCode.SCHEMA_COUNT,
                    ],
                    "source": ["speclynx-validator"],
                }
            },
        },
    )
