"""Grade Calculator for the Jentic API Scoring Framework.

Maps numerical scores (0-100) to letter grades (A+ through F) for richer
graphical representation of API quality scores.
"""

from ..enums import Grade
from ..models import DimensionScore, FinalScore, GroupScore


__all__ = ["calculate_grade"]


def calculate_grade(score: float | DimensionScore | GroupScore | FinalScore) -> Grade:
    """Calculate letter grade from a numerical score.

    Maps scores on the [0, 100] scale to letter grades using the framework's
    grading system. Works with any score type in the hierarchy: FinalScore,
    GroupScore, DimensionScore, or raw float values.

    Grading Scale:
        - A+ : 90-100
        - A  : 80-89
        - A- : 70-79
        - B+ : 67-69
        - B  : 63-66
        - B- : 60-62
        - C+ : 57-59
        - C  : 53-56
        - C- : 50-52
        - D+ : 47-49
        - D  : 43-46
        - D- : 40-42
        - F  : < 40

    Args:
        score: Either a numeric score (0-100) or a score object
               (DimensionScore, GroupScore, or FinalScore)

    Returns:
        Grade enum value (e.g., Grade.A_PLUS, Grade.B_MINUS, Grade.F)

    Raises:
        ValueError: If the numeric score is outside the [0, 100] range

    Examples:
        Grade a final score::

            from jentic_openapi.score.framework import calculate_final_score, calculate_grade

            final_score = calculate_final_score(ctx)
            grade = calculate_grade(final_score)
            # Returns: Grade.A_PLUS (if final_score.score >= 90)
            print(grade.value)  # Prints: "A+"

        Grade a dimension score::

            dimension_score = final_score.dimension_scores[0]
            grade = calculate_grade(dimension_score)
            # Returns: Grade.B (if dimension_score.score is 63-66)

        Grade a raw numeric value::

            grade = calculate_grade(85.5)
            # Returns: Grade.A

        Grade a group score::

            group_score = final_score.group_scores[0]
            grade = calculate_grade(group_score)
            # Returns: Grade.C_PLUS (if group_score.score is 57-59)
    """
    # Extract numeric value from score objects
    if isinstance(score, (DimensionScore, GroupScore, FinalScore)):
        numeric_score = score.score
    else:
        numeric_score = score

    # Validate score range
    if not (0.0 <= numeric_score <= 100.0):
        raise ValueError(f"Score must be in [0, 100] range, got {numeric_score}")

    # Map score to letter grade using threshold boundaries
    if numeric_score >= 90:
        return Grade.A_PLUS
    elif numeric_score >= 80:
        return Grade.A
    elif numeric_score >= 70:
        return Grade.A_MINUS
    elif numeric_score >= 67:
        return Grade.B_PLUS
    elif numeric_score >= 63:
        return Grade.B
    elif numeric_score >= 60:
        return Grade.B_MINUS
    elif numeric_score >= 57:
        return Grade.C_PLUS
    elif numeric_score >= 53:
        return Grade.C
    elif numeric_score >= 50:
        return Grade.C_MINUS
    elif numeric_score >= 47:
        return Grade.D_PLUS
    elif numeric_score >= 43:
        return Grade.D
    elif numeric_score >= 40:
        return Grade.D_MINUS
    else:  # numeric_score < 40
        return Grade.F
