"""TSD (Trust/Safety & Discoverability) group dimension calculators.

This group contains two dimensions:
- SEC (Security): Trust, compliance, and risk posture
- AID (AI Discoverability): Findability, semantic richness, and reasoning readiness
"""

from . import aid, sec


__all__ = ["sec", "aid"]
