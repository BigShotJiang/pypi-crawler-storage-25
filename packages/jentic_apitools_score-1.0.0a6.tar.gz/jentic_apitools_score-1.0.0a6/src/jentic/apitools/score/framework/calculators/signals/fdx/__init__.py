"""FDX (Foundational & DX) group signals.

This group focuses on human-oriented and tooling alignment aspects of API specifications.
It includes two dimensions:
- FC (Foundational Compliance): Base layer quality and conformance
- DXJ (Developer Experience & Jentic Compatibility): Clarity and ingestion readiness

Version 0.1 of the framework implements signals in this group.
"""

# Import all dimensions in this group to trigger signal registration
from . import dxj, fc  # noqa: F401 I001


__all__ = []  # Signals register automatically via dimension imports
