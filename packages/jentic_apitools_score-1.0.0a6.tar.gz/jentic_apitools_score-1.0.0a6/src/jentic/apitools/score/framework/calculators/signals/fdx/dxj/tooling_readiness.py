"""DXJ Signal: Tooling Readiness

Measures Jentic ingestion health based on diagnostic codes that block or impair ingestion.

This signal evaluates how ready the OpenAPI specification is for ingestion into the
Jentic platform by counting diagnostic codes across three categories:
- Server URL issues (4 codes)
- Security issues (2 codes)
- Structural issues (2 codes)

Formula:
    tooling_readiness = max(0, 1 - (ingestion_error_count / 15))

Special case:
    If ingestion_error_count >= 15, returns 0.0 (clipped at threshold)
"""

import logging

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import InverseErrorNormalizer, inverse_error
from ...registry import register_signal


logger = logging.getLogger(__name__)

# Diagnostic codes that impact Jentic ingestion
TOOLING_READINESS_CODES = [
    # Server URL issues
    "MISSING_SERVER_URL",
    "INVALID_SERVER_OBJECT_FORMAT",
    "SERVER_URL_MISSING_OR_EMPTY",
    "RELATIVE_SERVER_URL",
    # Security issues
    "UNDEFINED_SECURITY_SCHEME_REFERENCE",
    "UNUSED_SECURITY_SCHEME_DEFINED",
    # Structural issues
    "OPENAPI_MISSING_INFO",
    "OPENAPI_MISSING_PATHS",
]


@register_signal(
    kind=BuiltinSignal.TOOLING_READINESS,
    name="Tooling Readiness",
    description="Health of API ingestion, bundling, and resolution within Jentic pipelines.",
    group=GroupKind.FDX,
    dimension=DimensionKind.DXJ,
    normalizer=inverse_error,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def tooling_readiness(ctx: ScoreContext, config: SignalConfig[InverseErrorNormalizer]) -> Signal:
    """Calculate tooling readiness signal based on ingestion-blocking diagnostics.

    Counts diagnostic codes that impact Jentic ingestion across 3 categories:
    - Server URL issues (4 codes): MISSING_SERVER_URL, INVALID_SERVER_OBJECT_FORMAT,
      SERVER_URL_MISSING_OR_EMPTY, RELATIVE_SERVER_URL
    - Security issues (2 codes): UNDEFINED_SECURITY_SCHEME_REFERENCE,
      UNUSED_SECURITY_SCHEME_DEFINED
    - Structural issues (2 codes): OPENAPI_MISSING_INFO, OPENAPI_MISSING_PATHS

    Formula:
        tooling_readiness = max(0, 1 - (ingestion_error_count / 15))

    If ingestion_error_count >= 15, returns 0.0 (clipped at threshold).

    Args:
        ctx: Scoring context with spec and diagnostics
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], error count as raw_value, and interpretation
    """
    ingestion_errors = 0

    if isinstance(ctx.diagnostics, list):
        # Count diagnostics that match tooling readiness codes
        for diagnostic in ctx.diagnostics:
            if diagnostic.code and diagnostic.code in TOOLING_READINESS_CODES:
                ingestion_errors += 1

    # Normalize using inverse_error with threshold=15
    threshold = 15.0
    normalized_value = config.normalizer(
        issue_count=float(ingestion_errors),
        threshold=threshold,
    )

    # Determine interpretation based on count ranges
    if ingestion_errors <= 3:
        interpretation = "Easily ingested"
    elif ingestion_errors <= 8:
        interpretation = "Cleanup recommended"
    elif ingestion_errors <= 14:
        interpretation = "High friction"
    else:  # 15+
        interpretation = "Cannot reliably ingest"

    return Signal(
        value=normalized_value,
        raw_value=float(ingestion_errors),
        metadata={
            "ingestion_errors": ingestion_errors,
            "threshold": threshold,
            "interpretation": interpretation,
            "provenance": {"diagnostics": {"code": TOOLING_READINESS_CODES}},
        },
    )
