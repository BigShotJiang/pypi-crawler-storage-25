"""Signal registry for the API Scoring Framework.

This module provides a thread-safe registration system for signal calculators,
allowing signals to be discovered, validated, and looked up by kind.

Signals can be registered at any time (during import or at runtime), and all
registry operations are protected by a lock to ensure thread safety.

The decorator automatically injects signal metadata (kind, name, description, bounds, group, dimension)
into returned Signal instances, ensuring single source of truth from the decorator parameters.

Usage:
    from jentic_openapi.score.framework import DimensionKind, GroupKind
    from jentic_openapi.score.framework.normalizers import binary

    @register_signal(
        kind="my_signal",
        name="My Signal",
        description="My custom signal.",
        dimension=DimensionKind.FC,
        group=GroupKind.FDX,
        normalizer=binary,
        bounds=(0, 1),
    )
    def my_signal(ctx: ScoreContext, config: SignalConfig) -> Signal:
        '''Calculate my custom signal.'''
        raw = 1
        return Signal(
            value=config.normalizer(raw),
            raw_value=raw,
        )  # kind, name, description, bounds, group, dimension auto-injected

    # Later, retrieve registered signals:
    signal_config = get_signal("my_signal")
    all_signals = list_signals()
"""

import threading
from collections.abc import Callable, Mapping
from dataclasses import replace
from typing import Protocol

from ...constants import SIGNAL_BOOST_MULTIPLIER
from ...enums import DIMENSION_TO_GROUP, BuiltinSignal, DimensionKind, GroupKind, SpecType
from ...models import ScoreContext, Signal, SignalCalculator, SignalConfig
from ...normalizers import clamp


__all__ = [
    "SignalCalculatorProtocol",
    "register_signal",
    "get_signal",
    "list_signals",
    "all_signals",
]

_registry: dict[str, SignalConfig] = {}
_registry_lock = threading.Lock()


class SignalCalculatorProtocol(Protocol):
    """Protocol defining the interface for signal calculator functions.

    Signal calculators must:
    - Accept a ScoreContext and SignalConfig as parameters
    - Return a Signal instance

    Note: Metadata is stored in SignalConfig via the registry, not on the function.
    """

    def __call__(self, ctx: ScoreContext, config: SignalConfig) -> Signal:
        """Calculate and return a signal from the given context."""
        ...


def register_signal(
    kind: BuiltinSignal | str,
    name: str,
    description: str,
    dimension: DimensionKind,
    normalizer: Callable[..., float],
    bounds: tuple[float, float] = (0.0, 1.0),
    group: GroupKind | None = None,
    target_specs: list[tuple[SpecType | str, str]] | None = None,
) -> Callable[[SignalCalculator], SignalCalculator]:
    """Decorator to register a signal calculator function.

    This decorator:
    1. Registers the signal calculator with metadata
    2. Wraps the calculator to inject SignalConfig as 2nd parameter
    3. Auto-injects kind, name, description, and bounds into returned Signal instances

    Args:
        kind: Signal identifier (use BuiltinSignal enum for built-in signals)
        name: Human-readable display name (e.g., "Specification Validity")
        description: Detailed description of what this signal measures
        dimension: Which dimension this signal belongs to
        normalizer: Normalization function to use (e.g., binary, coverage)
        bounds: Expected range for raw values (default: (0.0, 1.0))
        group: Which group this signal belongs to (optional, auto-derived from dimension if not provided)
        target_specs: List of (spec_type, version_pattern) tuples this signal supports (optional)

    Returns:
        Decorator function that registers and wraps the signal calculator

    Raises:
        TypeError: If decorated function doesn't match SignalCalculator signature
        ValueError: If signal kind is already registered

    Example:
        from jentic_openapi.score.framework.normalizers import binary

        @register_signal(
            kind=BuiltinSignal.SPEC_VALIDITY,
            name="Specification Validity",
            description="Does the spec parse successfully.",
            dimension=DimensionKind.FC,
            normalizer=binary,
            group=GroupKind.FDX,
        )
        def spec_validity(ctx: ScoreContext, config: SignalConfig) -> Signal:
            raw = 1 if ctx.spec_document else 0
            return Signal(value=config.normalizer(raw), raw_value=raw)
    """

    def decorator(func: SignalCalculator) -> SignalCalculator:
        # Convert enum to string if needed
        signal_kind = kind.value if hasattr(kind, "value") else kind  # type: ignore

        # Validate function signature
        if not callable(func):
            raise TypeError(
                f"The function '{func}' decorated with @register_signal must be callable"
            )

        # Auto-derive group from dimension if not explicitly provided in decorator
        signal_group = group if group is not None else DIMENSION_TO_GROUP[dimension]

        # Normalize target_specs: convert enums to strings and make immutable
        normalized_target_specs: tuple[tuple[str, str], ...] | None = None
        if target_specs is not None:
            normalized_target_specs = tuple(
                (spec_type.value if isinstance(spec_type, SpecType) else spec_type, version)
                for spec_type, version in target_specs
            )

        # Create wrapper function that injects SignalConfig and auto-injects metadata
        def wrapper(ctx: ScoreContext, config: SignalConfig | None = None) -> Signal:
            if config is None:
                raise TypeError(f"Signal calculator {func.__name__} requires config parameter")
            signal = func(ctx, config)  # type: ignore[call-arg]

            # Apply boost multiplier to normalized value, clamped to [0, 1]
            if SIGNAL_BOOST_MULTIPLIER != 1.0:
                adjusted_value = clamp(signal.value * SIGNAL_BOOST_MULTIPLIER)
                signal = replace(signal, value=adjusted_value)

            # Inject kind, name, description, bounds, group, and dimension if missing
            if (
                signal.kind is None
                or signal.name is None
                or signal.description is None
                or signal.bounds is None
                or signal.group is None
                or signal.dimension is None
            ):
                signal = replace(
                    signal,
                    kind=signal_kind if signal.kind is None else signal.kind,
                    name=name if signal.name is None else signal.name,
                    description=description if signal.description is None else signal.description,
                    bounds=bounds if signal.bounds is None else signal.bounds,
                    group=signal_group if signal.group is None else signal.group,
                    dimension=dimension if signal.dimension is None else signal.dimension,
                )
            return signal

        # Thread-safe registration
        with _registry_lock:
            # Check for duplicate registration
            if signal_kind in _registry:
                raise ValueError(f"Duplicate signal kind: {signal_kind}")

            # Create and store the signal configuration
            # Note: We store SignalConfig without type parameter for flexibility
            # Callers can cast to specific type like SignalConfig[InverseErrorNormalizer] if needed
            config = SignalConfig(  # type: ignore[type-arg]
                kind=signal_kind,
                name=name,
                description=description,
                group=signal_group,
                dimension=dimension,
                normalizer=normalizer,
                bounds=bounds,
                calculator=wrapper,  # Store the wrapper
                target_specs=normalized_target_specs,
            )

            _registry[signal_kind] = config

        # Preserve function metadata for debugging (outside lock)
        wrapper.__name__ = func.__name__  # Preserve original function name
        wrapper.__doc__ = func.__doc__  # Preserve docstring

        return wrapper  # type: ignore[return-value]

    return decorator


def get_signal(kind: BuiltinSignal | str) -> SignalConfig:
    """Retrieve a registered signal configuration by kind.

    Args:
        kind: Signal identifier (string or BuiltinSignal enum)

    Returns:
        SignalConfig for the requested signal

    Raises:
        KeyError: If signal kind is not registered

    Example:
        config = get_signal("spec_validity")
        signal = config.calculator(ctx, config)  # Pass config as 2nd arg
    """
    signal_kind = kind.value if hasattr(kind, "value") else kind  # type: ignore

    with _registry_lock:
        if signal_kind not in _registry:
            raise KeyError(
                f"Signal '{signal_kind}' not found in registry. "
                f"Available signals: {', '.join(_registry.keys())}"
            )

        return _registry[signal_kind]


def list_signals(
    dimension: DimensionKind | None = None,
) -> list[SignalConfig]:
    """List all registered signals, optionally filtered by dimension.

    Args:
        dimension: Optional dimension to filter by

    Returns:
        List of SignalConfig objects matching the criteria

    Example:
        # Get all signals
        all_sigs = list_signals()

        # Get only FC dimension signals
        fc_sigs = list_signals(dimension=DimensionKind.FC)
    """
    with _registry_lock:
        signals = list(_registry.values())

    if dimension is not None:
        signals = [s for s in signals if s.dimension == dimension]

    return signals


def all_signals() -> Mapping[str, SignalConfig]:
    """Return a read-only snapshot of all registered signals.

    Returns:
        Mapping from signal kinds (identifiers) to SignalConfig objects.
        This is a snapshot taken at the time of the call, so concurrent
        registrations will not affect the returned mapping.

    Example:
        registry = all_signals()
        print(f"Registered signals: {list(registry.keys())}")
    """
    with _registry_lock:
        # Return a shallow copy to prevent external modification
        return dict(_registry)
