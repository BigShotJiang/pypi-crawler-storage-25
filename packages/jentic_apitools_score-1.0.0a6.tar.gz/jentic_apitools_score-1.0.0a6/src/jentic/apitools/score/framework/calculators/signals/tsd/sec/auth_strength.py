"""SEC Signal: Authentication Strength

Measures the average quality and robustness of authentication mechanisms defined in the API.

This signal evaluates security schemes based on their authentication strength:

HTTP Authentication (IANA-registered schemes):
  Weak (0.10-0.20):
  - basic: 0.10 - Plaintext credentials; easily leaked [RFC7617]
  - oauth: 0.20 - OAuth 1.0; deprecated, complex signatures [RFC5849]
  - digest: 0.20 - Better than basic, still outdated/vulnerable [RFC7616]

  Weak-Moderate (0.25-0.40):
  - scram-sha-1: 0.25 - Challenge-response but SHA-1 is deprecated [RFC7804]
  - negotiate: 0.35 - Kerberos/NTLM; violates HTTP semantics [RFC4559]

  Moderate (0.60-0.70):
  - bearer (opaque): 0.60 - Opaque tokens; only as strong as distribution [RFC6750]
  - vapid: 0.60 - WebPush tokens; similar to bearer [RFC8292]
  - scram-sha-256: 0.65 - Modern challenge-response, password-based [RFC7804]

  Good (0.75-0.85):
  - bearer (JWT): 0.75 - Cryptographically verifiable, supports scopes/claims
  - privatetoken: 0.75 - Privacy Pass; cryptographically strong [RFC9577]
  - hoba: 0.80 - Origin-bound authentication with client certs [RFC7486]
  - concealed: 0.85 - Modern concealed authentication [RFC9729]

  Very Good (0.90-0.95):
  - dpop: 0.90 - Demonstrating Proof-of-Possession for tokens [RFC9449]
  - gnap: 0.90 - Grant Negotiation; modern OAuth successor [RFC9635]
  - mutual: 0.95 - HTTP-level mutual authentication [RFC8120]

API Key:
- query: 0.15 - Very high leakage risk (logs, proxies, URLs)
- header/cookie: 0.50 - Common; moderately secure
- missing name/in: 0.0 - Misconfigured

OAuth 2.0 (weakest link principle):
- password: 0.30 - Deprecated by OAuth 2.1
- implicit: 0.35 - Deprecated; token exposure risk
- clientCredentials: 0.85 - Modern; scoped; secure
- authorizationCode: 0.90 - Best-practice OAuth flow
- no flows: 0.0 - Misconfigured

Other:
- openIdConnect: 1.0 - Gold standard for AI agents
- mutualTLS: 1.0 - Hardware-backed identity; extremely strong

Formula:
    auth_strength = safe_divide(sum(strength_scores), count(schemes))

If no schemes are defined, returns 1.0 (signal not applicable - nothing to measure).
"""

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import identity, safe_divide
from ...registry import register_signal


# HTTP scheme strength scores (IANA-registered authentication schemes)
HTTP_SCHEME_SCORES = {
    # Weak - Credential Leakage Risk (0.10-0.20)
    "basic": 0.10,  # [RFC7617] Plaintext credentials; easily leaked
    "oauth": 0.20,  # [RFC5849] OAuth 1.0; deprecated, complex signatures
    "digest": 0.20,  # [RFC7616] Better than basic, still outdated/vulnerable
    # Weak-Moderate - Legacy/Limited (0.25-0.40)
    "scram-sha-1": 0.25,  # [RFC7804] Challenge-response but SHA-1 is deprecated
    "negotiate": 0.35,  # [RFC4559] Kerberos/NTLM; violates HTTP semantics
    # Moderate - Token-Based (0.60-0.70)
    "bearer": 0.60,  # [RFC6750] Opaque tokens; only as strong as distribution
    "vapid": 0.60,  # [RFC8292] WebPush tokens; similar to bearer
    "scram-sha-256": 0.65,  # [RFC7804] Modern challenge-response, password-based
    # Good - Cryptographic Binding (0.75-0.85)
    "privatetoken": 0.75,  # [RFC9577] Privacy Pass; cryptographically strong
    "hoba": 0.80,  # [RFC7486] Origin-bound authentication with client certs
    "concealed": 0.85,  # [RFC9729] Modern concealed authentication
    # Very Good - Proof-of-Possession (0.90-0.95)
    "dpop": 0.90,  # [RFC9449] Demonstrating Proof-of-Possession for tokens
    "gnap": 0.90,  # [RFC9635] Grant Negotiation; modern OAuth successor
    "mutual": 0.95,  # [RFC8120] HTTP-level mutual authentication
}

# Bearer format bonus for JWT
BEARER_JWT_SCORE = 0.75  # Cryptographically verifiable, supports scopes/claims

# API Key strength by location
APIKEY_LOCATION_SCORES = {
    "query": 0.15,  # Very high leakage risk (logs, proxies, URLs)
    "header": 0.50,  # Common; moderately secure
    "cookie": 0.50,  # Same as header
}

# OAuth2 flow scores (direct, not base+adjustment)
OAUTH2_FLOW_SCORES = {
    "password": 0.30,  # Deprecated by OAuth 2.1
    "implicit": 0.35,  # Deprecated; token exposure risk
    "clientCredentials": 0.85,  # Modern; scoped; secure
    "authorizationCode": 0.90,  # Best-practice OAuth flow
}

# Top-level scheme scores (for types without sub-variants)
SECURITY_STRENGTH_SCORES = {
    "openIdConnect": 1.0,  # Gold standard for AI agents
    "mutualTLS": 1.0,  # Hardware-backed identity; extremely strong
}


@register_signal(
    kind=BuiltinSignal.AUTH_STRENGTH,
    name="Authentication Strength",
    description="Average quality of security schemes based on authentication method strength (weakest link for OAuth2).",
    group=GroupKind.TSD,
    dimension=DimensionKind.SEC,
    normalizer=identity,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def auth_strength(ctx: ScoreContext, config: SignalConfig) -> Signal:
    """Calculate authentication strength based on security schemes.

    Extracts security scheme information from diagnostics and calculates
    a strength score for each scheme based on its type and configuration.
    Returns the average strength of all defined security schemes.

    Scoring logic:
    - HTTP (IANA schemes): basic 0.10, oauth 0.20, digest 0.20, scram-sha-1 0.25,
      negotiate 0.35, bearer 0.60, vapid 0.60, scram-sha-256 0.65, bearer(JWT) 0.75,
      privatetoken 0.75, hoba 0.80, concealed 0.85, dpop 0.90, gnap 0.90, mutual 0.95,
      unrecognized 0.0
    - API Key: query 0.15, header/cookie 0.50, misconfigured 0.0
    - OAuth2: password 0.30, implicit 0.35, clientCredentials 0.85, authorizationCode 0.90
    - Other: openIdConnect 1.0, mutualTLS 1.0

    Special cases:
    - No schemes defined: Returns 1.0 (signal not applicable - nothing to measure)
    - Unrecognized HTTP scheme: Returns 0.0 (cannot assess security)
    - OAuth2 with no flows: Returns 0.0 for that scheme (misconfigured)
    - OAuth2 with multiple flows: Uses weakest flow score (security = weakest link)
    - API Key missing name or in: Returns 0.0 (misconfigured)

    Args:
        ctx: Scoring context with diagnostics containing security_scheme_collector data
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], average_strength_of_security_schemes as raw_value,
        and breakdown metadata including per-scheme scores and configuration details
    """
    # Extract security schemes from diagnostics
    schemes = []

    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            if diagnostic.code == DiagnosticCode.SECURITY_SCHEMES and isinstance(
                diagnostic.data, dict
            ):
                schemes = diagnostic.data.get(DiagnosticCode.SECURITY_SCHEMES, [])
                break

    # Calculate strength for each scheme
    strength_scores = []
    schemes_count = len(schemes)
    schemes_metadata = []

    for scheme_data in schemes:
        score = _calculate_scheme_strength(scheme_data)
        strength_scores.append(score)

        schemes_metadata.append(
            {
                "type": scheme_data["type"],
                "score": score,
                "details": _get_scheme_details(scheme_data),
            }
        )

    # Calculate average strength using safe_divide
    # If no schemes exist, safe_divide(0, 0) returns 1.0 (signal not applicable)
    auth_strength_ = safe_divide(sum(strength_scores), schemes_count)

    # Apply normalizer (identity for this signal)
    normalized_value = config.normalizer(auth_strength_)

    return Signal(
        value=normalized_value,
        raw_value=auth_strength_,
        metadata={
            "strength_scores": strength_scores,
            "schemes_count": schemes_count,
            "schemes": schemes_metadata,
            "provenance": {"diagnostics": {"code": [DiagnosticCode.SECURITY_SCHEMES]}},
        },
    )


def _calculate_scheme_strength(scheme_data: dict) -> float:
    """Calculate strength score for a single security scheme.

    Dispatches to type-specific calculation functions for HTTP, API Key, and OAuth2.
    Other types (openIdConnect, mutualTLS) use direct lookup.

    Args:
        scheme_data: Security scheme information dict with 'type' field and
                     type-specific configuration (http_scheme, bearer_format, apikey_in, etc.)

    Returns:
        Strength score between 0.0 and 1.0 based on authentication method type
    """
    scheme_type = scheme_data.get("type")

    if scheme_type == "http":
        return _calculate_http_strength(scheme_data)

    if scheme_type == "apiKey":
        return _calculate_apikey_strength(scheme_data)

    if scheme_type == "oauth2":
        return _calculate_oauth2_strength(scheme_data)

    # openIdConnect, mutualTLS, or unknown
    return SECURITY_STRENGTH_SCORES.get(scheme_type, 0.0)  # type: ignore


def _calculate_http_strength(scheme_data: dict) -> float:
    """Calculate HTTP auth strength based on scheme and bearer format.

    Supports all IANA-registered HTTP authentication schemes:
    - Weak (0.10-0.20): basic, oauth, digest
    - Weak-Moderate (0.25-0.40): scram-sha-1, negotiate
    - Moderate (0.60-0.70): bearer (opaque), vapid, scram-sha-256
    - Good (0.75-0.85): bearer (JWT), privatetoken, hoba, concealed
    - Very Good (0.90-0.95): dpop, gnap, mutual
    - Unrecognized schemes: 0.0 (cannot assess security)

    Args:
        scheme_data: Security scheme dict with http_scheme and optional bearer_format

    Returns:
        HTTP auth strength score between 0.0 and 0.95
    """
    http_scheme = scheme_data.get("http_scheme", "").lower()

    if http_scheme == "bearer":
        bearer_format = scheme_data.get("bearer_format", "")
        if bearer_format and bearer_format.upper() == "JWT":
            return BEARER_JWT_SCORE
        return HTTP_SCHEME_SCORES["bearer"]

    return HTTP_SCHEME_SCORES.get(http_scheme, 0.0)


def _calculate_apikey_strength(scheme_data: dict) -> float:
    """Calculate API Key strength based on location.

    Scoring:
    - query: 0.15 (high leakage risk)
    - header/cookie: 0.50
    - missing name or in: 0.0 (misconfigured)
    - unrecognized location: 0.0 (cannot assess security)

    Note: Location values are case-sensitive per OpenAPI spec.

    Args:
        scheme_data: Security scheme dict with apikey_in and apikey_name

    Returns:
        API Key strength score
    """
    apikey_in = scheme_data.get("apikey_in")
    apikey_name = scheme_data.get("apikey_name")

    # Misconfigured: missing required fields
    if not apikey_in or not apikey_name:
        return 0.0

    return APIKEY_LOCATION_SCORES.get(apikey_in, 0.0)


def _calculate_oauth2_strength(scheme_data: dict) -> float:
    """Calculate OAuth2 strength based on weakest available flow.

    Uses direct flow scores (not base+adjustment):
    - password: 0.30
    - implicit: 0.35
    - clientCredentials: 0.85
    - authorizationCode: 0.90
    - unrecognized flows: 0.0 (cannot assess security)

    Uses the minimum score of all defined flows (weakest link principle).
    If deprecated flows are available, they determine the score even if
    modern flows are also present.

    Args:
        scheme_data: Security scheme dict with oauth2_flows list

    Returns:
        OAuth2 strength score based on weakest flow, or 0.0 if no flows defined
    """
    flows = scheme_data.get("oauth2_flows", [])

    flow_scores = []
    for flow in flows:
        score = OAUTH2_FLOW_SCORES.get(flow, 0.0)
        flow_scores.append(score)

    # Return weakest (minimum) flow score (0.0 if no flows defined)
    # Security is only as strong as the weakest available flow
    return min(flow_scores) if flow_scores else 0.0


def _get_scheme_details(scheme_data: dict) -> dict:
    """Extract relevant details for metadata based on scheme type.

    Extracts type-specific fields from the scheme data for inclusion in
    signal metadata, helping users understand the configuration details:
    - http: includes http_scheme (basic, bearer, digest, etc.) and bearer_format if present
    - apiKey: includes 'in' location (header, query, cookie) and parameter name
    - oauth2: includes list of available flows

    Args:
        scheme_data: Security scheme information dict with all fields

    Returns:
        Dict with type-specific configuration details, or empty dict for
        other scheme types (mutualTLS, openIdConnect)
    """
    scheme_type = scheme_data.get("type")
    details = {}

    if scheme_type == "http":
        details["http_scheme"] = scheme_data.get("http_scheme")
        # Include bearer_format if present (for JWT detection)
        if scheme_data.get("bearer_format"):
            details["bearer_format"] = scheme_data.get("bearer_format")
    elif scheme_type == "apiKey":
        details["in"] = scheme_data.get("apikey_in")
        details["name"] = scheme_data.get("apikey_name")
    elif scheme_type == "oauth2":
        details["flows"] = scheme_data.get("oauth2_flows", [])

    return details
