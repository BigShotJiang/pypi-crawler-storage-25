"""Jentic API Scoring Framework.

This module implements the comprehensive API scoring system that evaluates
APIs across multiple dimensions to assess their AI-Readiness.

The framework evaluates APIs in three main groups:
- A. Foundational & DX: Standards compliance and developer experience
- B. AI-Readiness & Usability: Semantic clarity and agent operability
- C. Trust/Safety & Discoverability: Security and findability
"""

from .calculators import calculate_final_score, calculate_maturity, calculate_readiness
from .calculators.grade import calculate_grade
from .enums import DimensionKind, Grade, GroupKind, Maturity, SpecType
from .models import DimensionScore, FinalScore, GroupScore, Readiness, ScoreContext, Signal


__all__ = [
    # Functions
    "calculate_readiness",
    "calculate_final_score",
    "calculate_maturity",
    "calculate_grade",
    # Result Types
    "Readiness",
    "FinalScore",
    "Maturity",
    "Grade",
    "GroupScore",
    "DimensionScore",
    "Signal",
    # Input Types
    "ScoreContext",
    # Navigation Enums
    "GroupKind",
    "DimensionKind",
    "SpecType",
    # Version
    "SCORING_VERSION",
    "JAIRF_VERSION",
    "__version__",
]

SCORING_VERSION = "0.4.0"
"""Scoring calculation version - increment when weights, maturity logic, signals, or algorithms change.

This version tracks the implementation and may increment more frequently than JAIRF_VERSION due to
bugfixes and implementation enhancements that don't affect the specification but affect the scoring engine.
"""

JAIRF_VERSION = "1.0.0"
"""Jentic API AI-Readiness Framework (JAIRF) Specification version used to implement scoring calculations.

This tracks the JAIRF specification version and changes less frequently than SCORING_VERSION, only when
the underlying specification itself is updated. These versions may diverge as the implementation evolves
independently from the specification.
"""

__version__ = f"{SCORING_VERSION}+jairf.{JAIRF_VERSION}"
"""Complete version string combining scoring implementation and JAIRF specification versions.

Format: {SCORING_VERSION}+jairf.{JAIRF_VERSION} (e.g., 0.1.0+jairf.1.0.0)
The scoring version is the main semver for comparison; JAIRF version is build metadata.
"""
