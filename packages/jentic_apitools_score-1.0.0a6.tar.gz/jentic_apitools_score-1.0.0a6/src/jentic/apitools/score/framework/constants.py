"""Framework-wide mathematical and computational constants.

This module centralizes numerical constants used throughout the scoring framework.
"""

__all__ = ["EPSILON", "SIGNAL_BOOST_MULTIPLIER"]


EPSILON = 1e-6
"""Small epsilon value used to prevent division by zero in mathematical operations.

Used primarily in the harmonic mean calculation for the final score to ensure
numerical stability when dimension scores approach zero. Value chosen to provide
appropriate safety margin for score range [0, 100].
"""

SIGNAL_BOOST_MULTIPLIER = 1.0
"""Multiplier applied to all normalized signal values before clamping.

Set to 1.0 for backward compatibility. Increase to boost scores proportionally
(e.g., 1.2 for 20% boost) while keeping zero at zero.
"""
