"""TSD (Trust/Safety & Discoverability) group signals.

This group focuses on ecosystem-oriented governance aspects of API specifications.
It includes two dimensions:
- SEC (Security): Trust, compliance, and risk posture
- AID (AI Discoverability): Findability, semantic richness, and reasoning readiness
"""

# Import all dimensions in this group to trigger signal registration
from . import aid, sec  # noqa: F401 I001


__all__ = []  # Signals register automatically via dimension imports
