"""AIRU (AI-Readiness & Usability) group signals.

This group focuses on machine-oriented semantic clarity aspects of API specifications.
It includes two dimensions:
- ARAX (AI-Readiness & Agent Experience): Semantic breadth, depth, and agent comprehension
- AU (Agent Usability): Functional utility, complexity, and AI orchestration possibilities
"""

# Import all dimensions in this group to trigger signal registration
from . import arax, au  # noqa: F401 I001


__all__ = []  # Signals register automatically via dimension imports
