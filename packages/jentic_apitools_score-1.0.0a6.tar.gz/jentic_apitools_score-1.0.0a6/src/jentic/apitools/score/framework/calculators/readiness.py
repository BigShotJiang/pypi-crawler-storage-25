"""Readiness Calculator for the Jentic API Scoring Framework.

Provides a unified interface for calculating both numerical scores and maturity
levels in a single operation, combining the outputs of calculate_final_score
and calculate_maturity.
"""

from ..models import Readiness, ScoreContext
from .final_score import calculate_final_score
from .maturity import calculate_maturity


__all__ = ["calculate_readiness"]


def calculate_readiness(ctx: ScoreContext) -> Readiness:
    """Calculate complete AI-Readiness assessment (scores + maturity level).

    This is the primary entry point for assessing an API's AI-Readiness.
    It combines numerical scoring across all dimensions/groups with categorical
    maturity level classification into a single comprehensive assessment.

    The function efficiently calculates the final score once and reuses it
    for maturity classification, ensuring consistency between the numerical
    scores and the categorical level.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        Readiness model containing:
        - final_score: Complete numerical scoring breakdown (0-100 scale)
        - maturity: Categorical AI-Readiness level (Level 0-4)

    Examples:
        Basic usage::

            from jentic_openapi.score.framework import calculate_readiness, ScoreContext

            ctx = ScoreContext(spec_document={...}, spec_uri="...", ...)
            readiness = calculate_readiness(ctx)

            # Access overall metrics
            print(f"Final Score: {readiness.final_score.score}/100")
            print(f"Maturity Level: {readiness.maturity.value}")

            # Access detailed breakdowns
            for group in readiness.final_score.group_scores:
                print(f"  {group.name}: {group.score}")

        Maturity-driven workflow::

            readiness = calculate_readiness(ctx)

            if readiness.maturity == Maturity.LEVEL_0:
                print("API not ready - fix foundational issues")
            elif readiness.maturity == Maturity.LEVEL_3:
                print("API is AI-Ready!")

        Score-driven workflow::

            readiness = calculate_readiness(ctx)

            for dimension in readiness.final_score.dimension_scores:
                if dimension.score < 50:
                    print(f"Improve {dimension.name}: {dimension.score}")

    Note:
        This function is preferred over calling calculate_final_score and
        calculate_maturity separately, as it's more efficient (avoids duplicate
        calculation) and ensures the scores and maturity level are always
        consistent with each other.
    """
    # Calculate final score once
    final_score = calculate_final_score(ctx)

    # Derive maturity level from final score (with gating rules)
    maturity = calculate_maturity(ctx, final_score=final_score)

    # Return unified assessment
    return Readiness(final_score=final_score, maturity=maturity)
