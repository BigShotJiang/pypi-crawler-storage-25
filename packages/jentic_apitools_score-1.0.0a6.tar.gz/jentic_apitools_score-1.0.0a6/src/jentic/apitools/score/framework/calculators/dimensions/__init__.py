"""Dimension calculators for the Jentic API Scoring Framework.

Dimensions aggregate signal values into higher-level quality metrics.
Each dimension represents a specific aspect of API quality.

Structure (flat organization by group/dimension):
- dimensions/fdx/fc.py     - Foundational & DX → Foundational Compliance
- dimensions/fdx/dxj.py    - Foundational & DX → DX & Jentic Compatibility
- dimensions/airu/arax.py  - AI Readiness & Usability → AI Readiness & Agent Experience
- dimensions/airu/au.py    - AI Readiness & Usability → Agent Usability
- dimensions/tsd/sec.py    - Trust, Security & Discoverability → Security
- dimensions/tsd/aid.py    - Trust, Security & Discoverability → AI Discoverability
"""

from ...models import Signal
from ...normalizers import clamp, safe_divide


__all__ = ["aggregate_signal_values"]


def aggregate_signal_values(signals: list[Signal]) -> float:
    """Aggregate signal values into a dimension score using arithmetic mean.

    Implements the standard dimension scoring formula:

        DimensionScore = 100 × (sum of normalised signals) / (number of signals)

    All signals within a dimension are treated equally (no intra-dimension weighting
    in v1). The arithmetic mean is scaled to a 0-100 range.

    Args:
        signals: List of Signal objects with normalized values in [0, 1]

    Returns:
        Dimension score in [0, 100] range. Returns 0.0 if signals list is empty.

    Example:
        >>> signals = [
        ...     Signal(value=1.0, raw_value=1, name="spec_validity"),
        ...     Signal(value=0.92, raw_value=23, name="resolution_completeness"),
        ...     Signal(value=0.85, raw_value=3.75, name="lint_results"),
        ...     Signal(value=0.88, raw_value=2, name="structural_integrity"),
        ... ]
        >>> aggregate_signal_values(signals)
        91.25

    Note:
        This function assumes all signal values are already normalized to [0, 1].
        Signal normalization happens at the signal calculator level using the
        normalizer functions from the normalizers module.
    """
    signal_sum = sum(s.value for s in signals)

    # Calculate arithmetic mean (safe_divide handles empty list)
    score = 100.0 * safe_divide(signal_sum, len(signals), default=0.0)

    # Clamp to [0, 100] to handle floating-point precision issues
    return clamp(score, min_val=0.0, max_val=100.0)
