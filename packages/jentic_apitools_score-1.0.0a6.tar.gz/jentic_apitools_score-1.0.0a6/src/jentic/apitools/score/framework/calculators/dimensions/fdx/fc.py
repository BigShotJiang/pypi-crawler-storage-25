"""FC (Foundational Compliance) Dimension Calculator.

Calculates the FC dimension score by aggregating signal values.

Formula:
    DimensionScore = 100 × (sum of normalised signals) / (number of signals)

All signals are treated equally (no weighting within dimension in v1).
"""

from ....enums import DIMENSION_WEIGHTS, DimensionKind
from ....models import DimensionScore, ScoreContext, Signal
from ...grade import calculate_grade
from ...signals.registry import list_signals
from .. import aggregate_signal_values


__all__ = ["calculate_dimension_score"]


def calculate_dimension_score(ctx: ScoreContext) -> DimensionScore:
    """Calculate the Foundational Compliance (FC) dimension score.

    Executes all FC signal calculators and aggregates their normalized values
    into a dimension score using arithmetic mean scaled to 0-100 range.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        DimensionScore with:
        - kind: DimensionKind.FC
        - name: "Foundational Compliance"
        - score: 0-100 aggregate score
        - signals: List of individual Signal results
        - weight: From DIMENSION_WEIGHTS[DimensionKind.FC]
        - description: Dimension purpose

    Example:
        Given signals with values [1.0, 0.92, 0.85, 0.88]:
        FC score = 100 × (1.0 + 0.92 + 0.85 + 0.88) / 4 ≈ 91.25
    """
    # Get all signal configurations for FC dimension from registry
    signal_configs = list_signals(dimension=DimensionKind.FC)

    # Execute each signal calculator and collect results
    signals: list[Signal] = []
    for signal_config in signal_configs:
        # Execute the calculator with the context
        signal = signal_config.calculator(ctx, signal_config)
        signals.append(signal)

    # Calculate dimension score using arithmetic mean
    # Formula: 100 × (sum of signal values) / count
    score = aggregate_signal_values(signals)

    # Create and return dimension score
    return DimensionScore(
        kind=DimensionKind.FC,
        name="Foundational Compliance",
        score=score,
        grade=calculate_grade(score),
        signals=signals,
        weight=DIMENSION_WEIGHTS[DimensionKind.FC],
        description="Base layer of spec validity and structural soundness.",
    )
