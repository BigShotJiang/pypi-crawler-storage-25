"""ARAX Signal: OperationId Quality

Measures operationId coverage, uniqueness (with collision penalty), and casing consistency
for AI agent usability.

This signal evaluates:
1. Whether API operations have operationIds (coverage)
2. Whether operationIds are unique case-insensitively with collision penalty (uniqueness)
3. Whether operationIds use consistent casing conventions (casing_consistency)

Formula:
    coverage            = ops_with_operation_id / total_operations
    uniqueness          = unambiguous_operation_ids / ops_with_operation_id / total_collision_issues
    casing_consistency  = dominant_casing_count / ops_with_operation_id
    opid_quality        = coverage × uniqueness × casing_consistency

Diagnostic sources:
- speclynx-validator: total_operations, operations_with_operationId, operation_id_casing,
  ambiguous_operation_id
- spectral-validator: operation-operationId-unique

Collision vs Ambiguity:
- Ambiguity: Different strings that lowercase to the same value (e.g., "getUser" vs "GetUser")
  Detected via ambiguous_operation_id diagnostics from speclynx-validator.
- Collision: Same exact string appearing multiple times (e.g., "getUser" used 3 times)
  Detected via operation-operationId-unique diagnostics from spectral-validator.
  Collisions indicate a broken spec and are penalized more severely via division.

Casing styles detected (via operation_id_casing diagnostics from speclynx-validator):
- camelCase, PascalCase, snake_case, kebab-case
- SCREAMING_SNAKE_CASE, lowercase, UPPERCASE

Special cases:
    - If total_operations = 0, returns 1.0 (no penalty for irrelevance)
    - If ops_with_operation_id = 0, uniqueness = 1.0, casing_consistency = 1.0
    - If no collisions exist, uniqueness is not divided

Examples:
    [getUser, createOrder]              → uniqueness = 1.0, collisions = 0, casing = 1.0
    [getUser, GetUser]                  → uniqueness = 0.0, collisions = 0, casing = 0.5 (ambiguous)
    [getUser, getUser, getUser]         → uniqueness = 0.0, collisions = 3 (collision)
    [getUser, getUser, createOrder]     → uniqueness ≈ 1/6, collisions = 2
"""

import logging
from collections import Counter

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import IdentityNormalizer, identity, safe_divide
from .....normalizers import coverage as coverage_normalizer
from ...registry import register_signal


logger = logging.getLogger(__name__)

# Casing style constant for unknown (used in dominant casing selection)
_CASING_UNKNOWN = "unknown"

# spectral-validator diagnostic code for operationId uniqueness (collision detection)
_SPECTRAL_OPERATION_ID_UNIQUE = "operation-operationId-unique"


@register_signal(
    kind=BuiltinSignal.OPID_QUALITY,
    name="OperationId Quality",
    description="Coverage, uniqueness, and casing consistency of operationIds for AI inference.",
    group=GroupKind.AIRU,
    dimension=DimensionKind.ARAX,
    normalizer=identity,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def opid_quality(ctx: ScoreContext, config: SignalConfig[IdentityNormalizer]) -> Signal:
    """Calculate operationId quality signal based on coverage, uniqueness, and casing.

    Expects ctx.diagnostics to contain (by source):

    From speclynx-validator:
    - "total_operations": Total count of operations
    - "operations_with_operationId": OperationIds list and count
    - "operation_id_casing": One per operationId with casing style
    - "ambiguous_operation_id": One per ambiguous operationId

    From spectral-validator:
    - "operation-operationId-unique": One per duplicate operationId

    Formula:
        coverage            = ops_with_operation_id / total_operations
        uniqueness          = unambiguous_operation_ids / ops_with_operation_id / collision_issues
        casing_consistency  = dominant_casing_count / ops_with_operation_id
        opid_quality        = coverage × uniqueness × casing_consistency

    See module docstring for special cases.

    Args:
        ctx: Scoring context with diagnostics containing operation counts
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], raw computed value,
        and breakdown metadata including total_collision_issues
    """
    total_operations = 0
    operation_ids: list[str] = []
    casing_breakdown: Counter[str] = Counter()
    ambiguous_operation_ids = 0
    total_collision_issues = 0

    # Extract data from diagnostics
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            if diagnostic.code == DiagnosticCode.TOTAL_OPERATIONS and isinstance(
                diagnostic.data, dict
            ):
                total_operations = diagnostic.data.get(DiagnosticCode.TOTAL_OPERATIONS, 0)
            elif diagnostic.code == DiagnosticCode.OPERATIONS_WITH_OPERATIONID and isinstance(
                diagnostic.data, dict
            ):
                # Get operationIds list from operations_with_operationId diagnostic
                operation_ids = diagnostic.data.get("operation_ids", [])
            elif diagnostic.code == DiagnosticCode.OPERATION_ID_CASING and isinstance(
                diagnostic.data, dict
            ):
                # Each operation_id_casing diagnostic provides casing info for one operationId
                casing = diagnostic.data.get("casing", _CASING_UNKNOWN)
                casing_breakdown[casing] += 1
            elif diagnostic.code == DiagnosticCode.AMBIGUOUS_OPERATION_ID and isinstance(
                diagnostic.data, dict
            ):
                # Each ambiguous_operation_id diagnostic represents one ambiguous operationId
                ambiguous_operation_ids += 1
            elif (
                diagnostic.code == _SPECTRAL_OPERATION_ID_UNIQUE
                and diagnostic.source == "spectral-validator"
            ):
                # Each operation-operationId-unique diagnostic from spectral-validator indicates a collision
                total_collision_issues += 1

    # Ensure count values are integers
    try:
        total_operations = int(total_operations)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid total_operations value in diagnostics: %r. Defaulting to 0.",
            total_operations,
        )
        total_operations = 0

    ops_with_operation_id = len(operation_ids)

    # Calculate coverage (handles division by zero with default=1.0)
    coverage = coverage_normalizer(
        count_present=float(ops_with_operation_id),
        count_expected=float(total_operations),
    )

    # Calculate uniqueness: ratio of unambiguous operationIds, adjusted for collisions
    # total_collision_issues comes from Spectral's operation-operationId-unique diagnostics
    # Spectral emits N-1 diagnostics for N identical operationIds, so we use total_collision_issues + 1
    # as the divisor to get a penalty proportional to the number of duplicates (N):
    # 0 collisions → /1 (no penalty), 1 collision (2 identical) → /2, 2 collisions (3 identical) → /3
    unambiguous_operation_ids = ops_with_operation_id - ambiguous_operation_ids
    uniqueness_base = safe_divide(unambiguous_operation_ids, ops_with_operation_id, default=1.0)
    uniqueness = uniqueness_base / (total_collision_issues + 1)

    # Calculate casing consistency from casing_breakdown
    casing_consistency, dominant_casing = _calculate_casing_consistency(
        casing_breakdown, ops_with_operation_id
    )
    dominant_casing_count = casing_breakdown.get(dominant_casing, 0) if dominant_casing else 0

    # Final score: coverage × uniqueness × casing_consistency
    raw_value = coverage * uniqueness * casing_consistency

    # Apply normalizer (identity pass-through)
    normalized_value = config.normalizer(raw_value)

    return Signal(
        value=normalized_value,
        raw_value=raw_value,
        metadata={
            "ops_with_operation_id": ops_with_operation_id,
            "total_operations": total_operations,
            "coverage": coverage,
            "unambiguous_operation_ids": unambiguous_operation_ids,
            "ambiguous_operation_ids": ambiguous_operation_ids,
            "uniqueness": uniqueness,
            "total_collision_issues": total_collision_issues,
            "casing_consistency": casing_consistency,
            "dominant_casing": dominant_casing,
            "dominant_casing_count": dominant_casing_count,
            "casing_breakdown": dict(casing_breakdown),
            "provenance": {
                "diagnostics": {
                    "code": [
                        DiagnosticCode.TOTAL_OPERATIONS,
                        DiagnosticCode.OPERATIONS_WITH_OPERATIONID,
                        DiagnosticCode.OPERATION_ID_CASING,
                        DiagnosticCode.AMBIGUOUS_OPERATION_ID,
                        _SPECTRAL_OPERATION_ID_UNIQUE,
                    ],
                    "source": [
                        "speclynx-validator",
                        "spectral-validator",
                    ],
                },
            },
        },
    )


def _calculate_casing_consistency(
    casing_breakdown: Counter[str], total_count: int
) -> tuple[float, str | None]:
    """Calculate casing consistency ratio from pre-computed casing breakdown.

    Args:
        casing_breakdown: Counter mapping casing style to count
        total_count: Total number of operationIds

    Returns:
        Tuple of (consistency_ratio, dominant_style)
        - consistency_ratio: float from 0.0 to 1.0
        - dominant_style: the most common known casing style (or None if empty/all unknown)
    """
    if total_count == 0 or not casing_breakdown:
        return 1.0, None

    # Filter out "unknown" for dominant selection - only known styles can be dominant
    known_styles = {k: v for k, v in casing_breakdown.items() if k != _CASING_UNKNOWN}

    if not known_styles:
        # All operationIds are unknown - no recognizable patterns
        return 0.0, None

    # Find max count among known styles, then pick alphabetically first (deterministic tie-breaking)
    max_count = max(known_styles.values())
    dominant_style = min(style for style, count in known_styles.items() if count == max_count)

    # Consistency = dominant known count / total (unknown operationIds reduce score)
    consistency = max_count / total_count
    return consistency, dominant_style
