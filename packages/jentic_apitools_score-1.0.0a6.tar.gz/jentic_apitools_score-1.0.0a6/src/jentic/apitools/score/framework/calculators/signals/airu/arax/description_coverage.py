"""ARAX Signal: Description Coverage

Measures the percentage of API elements that include descriptions.

This signal evaluates whether key OpenAPI elements (info object, operations,
schemas, and parameters) provide description fields to aid human and AI understanding.

Describable elements include (among others):
- info object (1 per spec)
- Operations (GET /users, POST /orders, etc.)
- Schemas (in components.schemas and inline schemas)
- Parameters (path, query, header, cookie parameters)
- PathItem objects
- Example objects

Formula:
    description_coverage = described_elements / describable_elements

Special case:
    If describable_elements = 0, returns 1.0 (no penalty for irrelevance)
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.DESCRIPTION_COVERAGE,
    name="Description Coverage",
    description="Coverage of descriptions across API elements.",
    group=GroupKind.AIRU,
    dimension=DimensionKind.ARAX,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def description_coverage(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate description coverage signal based on API element descriptions.

    Expects ctx.diagnostics to contain:
    - "described_elements": Count of elements with descriptions
    - "describable_elements": Total count of elements that could have descriptions

    Formula:
        description_coverage = described_elements / describable_elements

    If describable_elements = 0, returns 1.0 (no elements to describe).

    Args:
        ctx: Scoring context with metadata containing description counts
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], described count as raw_value,
        and breakdown metadata
    """

    described_elements = 0
    describable_elements = 0

    # Find diagnostic with code 'describable_elements', 'described_elements' and extract the value
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            if diagnostic.code == DiagnosticCode.DESCRIBED_ELEMENTS and isinstance(
                diagnostic.data, dict
            ):
                described_elements = diagnostic.data.get(DiagnosticCode.DESCRIBED_ELEMENTS, 0)
            elif diagnostic.code == DiagnosticCode.DESCRIBABLE_ELEMENTS and isinstance(
                diagnostic.data, dict
            ):
                describable_elements = diagnostic.data.get(DiagnosticCode.DESCRIBABLE_ELEMENTS, 0)

    # Ensure values are integers
    try:
        described_elements = int(described_elements)
        describable_elements = int(describable_elements)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid description count values in metadata: "
            "described_elements=%r, describable_elements=%r. "
            "Defaulting to 0. This may indicate a data quality issue in the metadata pipeline.",
            described_elements,
            describable_elements,
        )
        described_elements = 0
        describable_elements = 0

    # Clamp: described cannot exceed describable (defensive against inconsistent diagnostics)
    if described_elements > describable_elements and describable_elements > 0:
        logger.warning(
            "described_elements (%d) exceeds describable_elements (%d); clamping",
            described_elements,
            describable_elements,
        )
        described_elements = describable_elements
    undescribed_elements = describable_elements - described_elements

    # Normalize using coverage (handles division by zero with default=1.0)
    normalized_value = config.normalizer(
        count_present=float(described_elements),
        count_expected=float(describable_elements),
    )

    return Signal(
        value=normalized_value,
        raw_value=described_elements,
        metadata={
            "described_elements": described_elements,
            "undescribed_elements": undescribed_elements,
            "describable_elements": describable_elements,
            "provenance": {
                "diagnostics": {
                    "code": [DiagnosticCode.DESCRIBED_ELEMENTS, DiagnosticCode.DESCRIBABLE_ELEMENTS]
                },
            },
        },
    )
