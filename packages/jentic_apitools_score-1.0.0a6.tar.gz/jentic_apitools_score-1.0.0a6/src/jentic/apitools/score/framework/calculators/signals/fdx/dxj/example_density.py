"""DXJ Signal: Example Density

Measures the density of examples across eligible example locations in the API spec.
Uses coverage normalization: present_examples / expected_examples.

Eligible example locations include (among others):
- Request bodies (requestBody.content.*.example or examples)
- Response schemas (responses.*.content.*.example or examples)
- Parameters (parameters[*].example or examples)
- Schema properties in components (components.schemas.*.properties.*.example)
- Media type examples (content.*.examples)

Formula:
    example_density = present_examples / expected_examples

Special case:
    If expected_examples = 0, returns 1.0 (no penalty for irrelevance)
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.EXAMPLE_DENSITY,
    name="Example Density",
    description="How richly the API is illustrated with examples.",
    group=GroupKind.FDX,
    dimension=DimensionKind.DXJ,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def example_density(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate example density signal based on example presence.

    Expects ctx.diagnostics to contain:
    - "present_examples": Count of examples present in the spec
    - "expected_examples": Count of locations where examples could be provided

    Formula:
        example_density = present_examples / expected_examples

    If expected_examples = 0, returns 1.0 (no locations to provide examples).

    Args:
        ctx: Scoring context with spec and metadata
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], counts as raw_value, and breakdown metadata
    """
    expected_examples = 0
    present_examples = 0
    # Find diagnostic with code 'expected_examples', 'present_examples' and extract the value
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics:
            if diagnostic.code == DiagnosticCode.EXPECTED_EXAMPLES and isinstance(
                diagnostic.data, dict
            ):
                expected_examples = diagnostic.data.get(DiagnosticCode.EXPECTED_EXAMPLES, 0)
            elif diagnostic.code == DiagnosticCode.PRESENT_EXAMPLES and isinstance(
                diagnostic.data, dict
            ):
                present_examples = diagnostic.data.get(DiagnosticCode.PRESENT_EXAMPLES, 0)

    # Ensure values are integers
    try:
        present_examples = int(present_examples)
        expected_examples = int(expected_examples)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid example count values in metadata: present_examples=%r, expected_examples=%r. "
            "Defaulting to 0. This may indicate a data quality issue in the metadata pipeline.",
            present_examples,
            expected_examples,
        )
        present_examples = 0
        expected_examples = 0

    # Normalize using coverage (handles division by zero with default=1.0)
    normalized_value = config.normalizer(
        count_present=float(present_examples),
        count_expected=float(expected_examples),
    )

    return Signal(
        value=normalized_value,
        raw_value=present_examples,
        metadata={
            "present_examples": present_examples,
            "expected_examples": expected_examples,
            "provenance": {
                "diagnostics": {
                    "code": [DiagnosticCode.PRESENT_EXAMPLES, DiagnosticCode.EXPECTED_EXAMPLES]
                }
            },
        },
    )
