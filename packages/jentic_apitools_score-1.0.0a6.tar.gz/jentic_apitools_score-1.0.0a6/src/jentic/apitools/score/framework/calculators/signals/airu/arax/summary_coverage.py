"""ARAX Signal: Summary Coverage

Measures the percentage of API elements that include summary fields.

This signal evaluates whether key OpenAPI elements (info object, operations, and tags)
provide summary fields to give quick, concise overviews for human and AI understanding.

Summary-eligible elements include:
- Path Item object (/users, /orders, etc.)
- Operations (GET /users, POST /orders, etc.)
- Example Object

Formula:
    summary_coverage = summaries_present / summaries_expected

Special case:
    If summaries_expected = 0, returns 1.0 (no penalty for irrelevance)

Example:
    summary_coverage = 0.78
    78% of operations/tags/info objects include a summary field
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.SUMMARY_COVERAGE,
    name="Summary Coverage",
    description="Coverage of summaries across operations/tags/info.",
    group=GroupKind.AIRU,
    dimension=DimensionKind.ARAX,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def summary_coverage(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate summary coverage signal based on API element summaries.

    Expects ctx.diagnostics to contain:
    - "summaries_present": Count of elements with summary fields
    - "summaries_expected": Total count of elements that could have summaries

    Formula:
        summary_coverage = summaries_present / summaries_expected

    If summaries_expected = 0, returns 1.0 (no elements eligible for summaries).

    Args:
        ctx: Scoring context with metadata containing summary counts
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], summaries_present count as raw_value,
        and breakdown metadata
    """
    summaries_present = 0
    summaries_expected = 0

    # Find diagnostic with code 'summaries_expected', 'summaries_present' and extract the value
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            if diagnostic.code == DiagnosticCode.SUMMARIES_PRESENT and isinstance(
                diagnostic.data, dict
            ):
                summaries_present = diagnostic.data.get(DiagnosticCode.SUMMARIES_PRESENT, 0)
            elif diagnostic.code == DiagnosticCode.SUMMARIES_EXPECTED and isinstance(
                diagnostic.data, dict
            ):
                summaries_expected = diagnostic.data.get(DiagnosticCode.SUMMARIES_EXPECTED, 0)

    # Ensure values are integers
    try:
        summaries_present = int(summaries_present)
        summaries_expected = int(summaries_expected)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid summary count values in metadata: "
            "summaries_present=%r, summaries_expected=%r. "
            "Defaulting to 0. This may indicate a data quality issue in the metadata pipeline.",
            summaries_present,
            summaries_expected,
        )
        summaries_present = 0
        summaries_expected = 0

    # Calculate missing summaries
    missing_summaries = summaries_expected - summaries_present

    # Normalize using coverage (handles division by zero with default=1.0)
    normalized_value = config.normalizer(
        count_present=float(summaries_present),
        count_expected=float(summaries_expected),
    )

    return Signal(
        value=normalized_value,
        raw_value=summaries_present,
        metadata={
            "summaries_present": summaries_present,
            "missing_summaries": missing_summaries,
            "summaries_expected": summaries_expected,
            "provenance": {
                "diagnostics": {
                    "code": [DiagnosticCode.SUMMARIES_PRESENT, DiagnosticCode.SUMMARIES_EXPECTED]
                }
            },
        },
    )
