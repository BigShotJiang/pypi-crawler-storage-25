"""TSD (Trust/Safety & Discoverability) Group Calculator.

Calculates the TSD group score by aggregating SEC and AID dimension scores.

Formula:
    GroupScore = (SEC_score × 0.12 + AID_score × 0.10) / (0.12 + 0.10)
               = (SEC_score × 0.12 + AID_score × 0.10) / 0.22
"""

from ...enums import GroupKind
from ...models import DimensionScore, GroupScore, ScoreContext
from ..dimensions.tsd import aid, sec
from ..grade import calculate_grade
from . import aggregate_dimension_scores


__all__ = ["calculate_group_score"]


def calculate_group_score(ctx: ScoreContext) -> GroupScore:
    """Calculate the Trust/Safety & Discoverability (TSD) group score.

    Executes SEC and AID dimension calculators and aggregates their scores
    using weighted average.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        GroupScore with:
        - kind: GroupKind.TSD
        - name: "Trust/Safety & Discoverability"
        - score: 0-100 weighted aggregate score
        - dimension_scores: List of DimensionScore results [SEC, AID]
        - focus: Group theme description

    Example:
        Given SEC = 90.0 (weight 0.12) and AID = 75.0 (weight 0.10):
        TSD score = (90 × 0.12 + 75 × 0.10) / 0.22 ≈ 83.18
    """
    # Calculate dimension scores
    sec_dimension = sec.calculate_dimension_score(ctx)
    aid_dimension = aid.calculate_dimension_score(ctx)

    dimension_scores: list[DimensionScore] = [sec_dimension, aid_dimension]

    # Calculate group score using weighted average
    score = aggregate_dimension_scores(dimension_scores)

    # Create and return group score
    return GroupScore(
        kind=GroupKind.TSD,
        name="Trust/Safety & Discoverability",
        score=score,
        grade=calculate_grade(score),
        dimension_scores=dimension_scores,
        description="Ecosystem-oriented governance - security, findability, and safe AI agent interaction.",
    )
