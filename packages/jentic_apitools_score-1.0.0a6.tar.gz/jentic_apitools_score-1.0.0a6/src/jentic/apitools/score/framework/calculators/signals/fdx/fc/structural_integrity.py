"""FC Signal: Structural Integrity

Measures schema-breaking or model-level correctness failures using logarithmic dampening
normalization per JAIRF v0.2.0 specification.

This signal evaluates structural issues that affect the API's underlying data model
coherence, not cosmetic compliance. Structural failures affect correctness, while
linting concerns style or completeness.

Structural issue categories:
- invalid_model_shape: type: object but no properties
- contradictory_typing: type: string + format: int32
- impossible_constraints: minimum > maximum, contradictory schema constructs
- broken_polymorphism: oneOf without discriminator, mismatched subschemas
- request_response_undefined: requestBody: {} or missing schema
- non_evaluable_example: example invalid JSON or contradicting type
- unresolvable_or_circular_schema: schema references that cannot be resolved or are circular

The logarithmic dampening curve provides early penalty for first few issues while
preventing premature score collapse. The threshold of 15 represents the point where
structural reliability collapses. Once an API has more than ~15 schema-breaking or
integrity flaws, automated interpretation is no longer trustworthy.
"""

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import LogarithmicDampeningNormalizer, logarithmic_dampening
from ...registry import register_signal


@register_signal(
    kind=BuiltinSignal.STRUCTURAL_INTEGRITY,
    name="Structural Integrity",
    description="Structural correctness score based on schema issues using logarithmic dampening.",
    group=GroupKind.FDX,
    dimension=DimensionKind.FC,
    normalizer=logarithmic_dampening,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def structural_integrity(
    ctx: ScoreContext, config: SignalConfig[LogarithmicDampeningNormalizer]
) -> Signal:
    """Calculate structural integrity signal based on schema-breaking issues.

    Counts structural issues by filtering diagnostics by their code. Issues are
    categorized into 7 types representing model-level correctness failures.

    Formula (JAIRF v0.2.0):
        structural_integrity = max(0, 1 - (log10(1 + issues) / log10(1 + structural_issue_threshold)))

    Where structural_issues are diagnostics with structural_integrity_category set.
    Threshold of 15 represents the collapse point for automated interpretation.

    The logarithmic dampening provides:
    - Early penalty for first few issues
    - Smooth decay curve
    - Slower collapse near structural_issue_threshold

    Note: post_parse_reference_failure is not included as it overlaps with
    the resolution_completeness signal.

    Args:
        ctx: Scoring context with spec and diagnostics
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], issue count as raw_value, and category breakdown
    """
    # Initialize category counts for structural issues
    category_counts = {
        "invalid_model_shape": 0,
        "contradictory_typing": 0,
        "impossible_constraints": 0,
        "broken_polymorphism": 0,
        "request_response_undefined": 0,
        "non_evaluable_example": 0,
        "unresolvable_or_circular_schema": 0,
    }

    # Count structural issues by filtering diagnostics
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics:
            if diagnostic.code == "jentic-object-should-have-shape":
                category_counts["invalid_model_shape"] += 1
            elif diagnostic.code in (
                "jentic-format-must-match-type-numeric",
                "jentic-format-must-match-type-stringy",
            ):
                category_counts["contradictory_typing"] += 1
            elif diagnostic.code == "jentic-oneof-requires-discriminator-for-objects":
                category_counts["broken_polymorphism"] += 1
            elif diagnostic.code in (
                "jentic-request-body-must-have-schema",
                "jentic-response-content-should-have-schema",
            ):
                category_counts["request_response_undefined"] += 1
            elif diagnostic.code == DiagnosticCode.SCHEMA_INVALID_MIN_MAX:
                category_counts["impossible_constraints"] += 1

    structural_issue_threshold = 15.0

    # Calculate total structural issues
    structural_issues = sum(category_counts.values())

    # Normalize using logarithmic_dampening
    normalized_value = config.normalizer(
        issue_count=structural_issues,
        threshold=structural_issue_threshold,
    )

    return Signal(
        value=normalized_value,
        raw_value=float(structural_issues),
        metadata={
            "structural_issues": structural_issues,
            "structural_issue_threshold": structural_issue_threshold,
            "category_counts": category_counts,
            "provenance": {
                "diagnostics": {
                    "code": [
                        "jentic-object-should-have-shape",
                        "jentic-format-must-match-type-numeric",
                        "jentic-format-must-match-type-stringy",
                        "jentic-oneof-requires-discriminator-for-objects",
                        "jentic-request-body-must-have-schema",
                        "jentic-response-content-should-have-schema",
                        DiagnosticCode.SCHEMA_INVALID_MIN_MAX,
                    ]
                }
            },
        },
    )
