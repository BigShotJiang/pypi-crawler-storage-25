"""FC Signal: Spec Validity

Measures whether the OpenAPI specification parses successfully and is structurally valid.

This signal performs comprehensive validation:
1. Parse success: spec_document is not None (valid YAML/JSON)
2. Type match: spec_type matches target_specs types (e.g., OpenAPI not AsyncAPI)
3. Version match: spec_version matches target_specs patterns (e.g., "3.0.*", "3.1.*")
4. No critical errors: diagnostics contain no critical/error severity issues

This is a binary signal: 1.0 if ALL checks pass, 0.0 if ANY check fails.
"""

from fnmatch import fnmatch

from lsprotocol.types import DiagnosticSeverity

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import BinaryNormalizer, binary
from ...registry import register_signal


@register_signal(
    kind=BuiltinSignal.SPEC_VALIDITY,
    name="Specification Validity",
    description="Checks whether the API description parses successfully and conforms to its declared specification (e.g., OpenAPI).",
    group=GroupKind.FDX,
    dimension=DimensionKind.FC,
    normalizer=binary,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def spec_validity(ctx: ScoreContext, config: SignalConfig[BinaryNormalizer]) -> Signal:
    """Calculate spec validity signal with comprehensive validation.

    Validation steps (all must pass):
    1. Parse success: spec_document is not None
    2. Type match: spec_type matches target_specs types
    3. Version match: spec_version matches target_specs patterns
    4. No critical errors: diagnostics contain no Error severity issues

    Args:
        ctx: Scoring context with spec and diagnostics
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with value 1.0 (valid) or 0.0 (invalid) and detailed metadata
    """
    # Initialize validation state
    is_valid = True
    failure_reason = None

    # Check 1: Parse success (spec_document is not None)
    if ctx.spec_document is None:
        is_valid = False
        failure_reason = "parse_failed"

    # Check 2: Type match (spec_type in target_specs)
    if is_valid:
        if ctx.spec_type is None:
            is_valid = False
            failure_reason = "spec_type_unknown"
        elif config.target_specs:
            # Extract target types from target_specs tuples
            target_types = {spec_type for spec_type, _ in config.target_specs}
            if ctx.spec_type not in target_types:
                is_valid = False
                failure_reason = "spec_type_mismatch"

    # Check 3: Version match (spec_version matches target_specs patterns)
    if is_valid:
        if ctx.spec_version is None:
            is_valid = False
            failure_reason = "spec_version_unknown"
        elif config.target_specs:
            # Check if version matches any pattern for the spec_type
            version_matches = False
            for spec_type, version_pattern in config.target_specs:
                if spec_type == ctx.spec_type:
                    if fnmatch(ctx.spec_version, version_pattern):
                        version_matches = True
                        break
            if not version_matches:
                is_valid = False
                failure_reason = "spec_version_mismatch"

    # Check 4: No critical errors in diagnostics
    if is_valid and isinstance(ctx.diagnostics, list):
        # Count diagnostics by severity
        error_count = sum(1 for d in ctx.diagnostics if d.severity == DiagnosticSeverity.Error)
        if error_count > 0:
            is_valid = False
            failure_reason = "validation_errors"

    # Normalize to binary value
    normalized_value = config.normalizer(is_valid)

    # Build metadata
    diagnostic_counts = {
        "error": 0,
        "warning": 0,
        "information": 0,
        "hint": 0,
    }

    if isinstance(ctx.diagnostics, list):
        for d in ctx.diagnostics:
            if d.severity == DiagnosticSeverity.Error:
                diagnostic_counts["error"] += 1
            elif d.severity == DiagnosticSeverity.Warning:
                diagnostic_counts["warning"] += 1
            elif d.severity == DiagnosticSeverity.Information:
                diagnostic_counts["information"] += 1
            elif d.severity == DiagnosticSeverity.Hint:
                diagnostic_counts["hint"] += 1

    return Signal(
        value=normalized_value,
        raw_value=is_valid,
        metadata={
            "failure_reason": failure_reason,
            "diagnostic_counts": diagnostic_counts,
            "provenance": {"diagnostics": {"severity": [DiagnosticSeverity.Error]}},
        },
    )
