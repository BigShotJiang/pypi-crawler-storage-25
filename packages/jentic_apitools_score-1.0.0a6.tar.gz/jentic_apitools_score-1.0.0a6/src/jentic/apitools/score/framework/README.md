# Jentic API Scoring Framework

A comprehensive framework for evaluating OpenAPI specifications across multiple dimensions to assess their AI-Readiness.

## Overview

The framework evaluates APIs in three main groups:

- **FDX (Foundational & DX)**: Standards compliance and developer experience
- **AIRU (AI-Readiness & Usability)**: Semantic clarity and agent operability
- **TSD (Trust/Safety & Discoverability)**: Security and findability

Each group contains multiple dimensions, which in turn are composed of individual signals. Scores are calculated using a weighted harmonic mean to ensure balanced quality across all dimensions.

**Current Version**: 0.1.0

This framework implements version **0.2.0** of the [Jentic API AI-Readiness Framework (JAIRF) Specification](https://github.com/jentic/api-ai-readiness-framework), currently focusing on Group A (Foundational & DX) with partial Group B (AI-Readiness & Usability) implementation.

## Quick Start

```python
import yaml
from pathlib import Path
from jentic_openapi.score.framework import calculate_readiness, ScoreContext

# Load your OpenAPI specification
spec_path = Path("path/to/openapi.yaml")
spec_source = spec_path.read_text()
spec_document = yaml.safe_load(spec_source)

# Create scoring context
ctx = ScoreContext(
    spec_uri=spec_path.as_uri(),      # e.g., "file:///path/to/openapi.yaml"
    spec_source=spec_source,          # Raw YAML/JSON string
    spec_document=spec_document,      # Parsed dict/mapping
    spec_type="openapi",              # Optional: spec type
    spec_version="3.1.0",             # Optional: detected version
    diagnostics=[],                   # Optional: validation diagnostics
    metadata={"vendor": "acme"},      # Optional: custom metadata
)

# Calculate complete AI-Readiness assessment
readiness = calculate_readiness(ctx)

# Access results
print(f"Overall Score: {readiness.final_score.score:.1f}/100")
print(f"Maturity Level: {readiness.maturity.value}")

# Access dimension details
for dimension in readiness.final_score.dimension_scores:
    print(f"{dimension.name}: {dimension.score:.1f}")
    for signal in dimension.signals:
        print(f"  {signal.name}: {signal.value:.2f}")
```

## Public API

The framework exports a minimal, focused API:

### Functions

- **`calculate_readiness(ctx)`** - Primary entry point returning complete assessment (scores + maturity)
- **`calculate_final_score(ctx)`** - Calculate detailed scores only
- **`calculate_maturity(ctx, final_score=None)`** - Classify maturity level with optional pre-calculated score

### Result Types

- **`Readiness`** - Complete assessment combining `FinalScore` and `Maturity`
- **`FinalScore`** - Overall score (0-100) with breakdowns by group and dimension
- **`Maturity`** - Categorical level (Level 0-4) representing AI-Readiness stage
- **`GroupScore`** - Score for a specific group (FDX, AIRU, or TSD)
- **`DimensionScore`** - Score for a specific dimension (FC, DXJ, ARAX, AU, SEC, AID)
- **`Signal`** - Individual signal measurement with normalized value (0-1)

### Input Types

- **`ScoreContext`** - Input context containing:
  - `spec_uri` (required): URI where spec was loaded from (e.g., "file:///path/to/spec.yaml")
  - `spec_source` (required): Raw YAML/JSON string source
  - `spec_document` (required): Parsed OpenAPI specification as dict/mapping (or None if parse failed)
  - `spec_type` (optional): Type of spec (e.g., "openapi")
  - `spec_version` (optional): Version string (e.g., "3.0.0", "3.1.0")
  - `diagnostics` (optional): List of validation/linting diagnostics
  - `metadata` (optional): Additional custom metadata dict

### Navigation Enums

- **`GroupKind`** - Group identifiers: `FDX`, `AIRU`, `TSD`
- **`DimensionKind`** - Dimension identifiers: `FC`, `DXJ`, `ARAX`, `AU`, `SEC`, `AID`

### Version Tracking

- **`SCORING_VERSION`** - Framework calculation version (currently "0.1.0")
  - Increment when: weights change, maturity logic changes, signals added/modified, algorithms change
  - Use this to track which framework version generated a score

## Understanding Results

### Maturity Levels

APIs are classified into 5 maturity levels based on final score and gating rules:

| Level | Score Range | Description |
|-------|-------------|-------------|
| Level 0 | < 40 | Not Ready - significant quality issues |
| Level 1 | 40-60 | Foundational / Developer Ready |
| Level 2 | 60-75 | AI-Aware - basic AI agent interaction |
| Level 3 | 75-90 | AI-Ready - well-optimized for AI |
| Level 4 | 90+ | Agent-Optimized - excellence in AI-Readiness |

**Gating Rule**: If Foundational Compliance (FC) score < 40, the API is automatically classified as Level 0 regardless of overall score.

### Score Hierarchy

```
Readiness
├── FinalScore (0-100)
│   ├── GroupScore (FDX)
│   │   ├── DimensionScore (FC)
│   │   │   ├── Signal (spec_validity)
│   │   │   ├── Signal (resolution_completeness)
│   │   │   ├── Signal (lint_results)
│   │   │   └── Signal (structural_integrity)
│   │   └── DimensionScore (DXJ)
│   │       ├── Signal (example_density)
│   │       ├── Signal (example_validity)
│   │       ├── Signal (response_coverage)
│   │       └── Signal (tooling_readiness)
│   ├── GroupScore (AIRU)
│   │   ├── DimensionScore (ARAX)
│   │   │   ├── Signal (summary_coverage)
│   │   │   ├── Signal (description_coverage)
│   │   │   ├── Signal (error_standardization)
│   │   │   └── Signal (opid_quality)
│   │   └── DimensionScore (AU)
│   │       └── Signal (complexity_comfort)
│   └── GroupScore (TSD)
│       ├── DimensionScore (SEC)
│       │   └── Signal (auth_strength)
│       └── DimensionScore (AID)
│           └── Signal (descriptive_richness)
└── Maturity (Level 0-4)
```

### Accessing Specific Results

```python
readiness = calculate_readiness(ctx)

# Access by enum
from jentic_openapi.score.framework import DimensionKind, GroupKind

fc_dimension = next(
    d for d in readiness.final_score.dimension_scores
    if d.kind == DimensionKind.FC
)
print(f"FC Score: {fc_dimension.score:.1f}")

# Iterate through all signals
for signal in fc_dimension.signals:
    print(f"{signal.name}: {signal.value:.2f}")
```

## Architecture

### Groups and Dimensions

**Group A: Foundational & DX (FDX)** - Weight: 34%
- **FC (Foundational Compliance)**: 16% - Base layer of validity and soundness
- **DXJ (Developer Experience & Jentic)**: 18% - Clarity, completeness, ingestion readiness

**Group B: AI-Readiness & Usability (AIRU)** - Weight: 44%
- **ARAX (AI-Readiness & Agent Experience)**: 24% - Semantic breadth and comprehension
- **AU (Agent Usability)**: 20% - Functional utility and orchestration

**Group C: Trust/Safety & Discoverability (TSD)** - Weight: 22%
- **SEC (Security)**: 12% - Trust, compliance, risk posture
- **AID (AI Discoverability)**: 10% - Findability and reasoning readiness

### Calculation Method

The final score uses a **weighted harmonic mean** to ensure balanced quality:

```
Final Score = (sum of dimension_weights) / (sum of (dimension_weight / dimension_score))
```

This penalizes low scores in any dimension, requiring balanced excellence across all areas.

## Dimension Weights

All dimensions use their target weights:

| Dimension | Weight | Focus | Status |
|-----------|--------|-------|--------|
| **FC** | **16%** | Foundational quality | ✅ Fully implemented |
| **DXJ** | **18%** | Developer & tooling readiness | 🔨 Partially implemented |
| **ARAX** | **24%** | AI semantic clarity | 🔨 Partially implemented |
| **AU** | **20%** | Agent operational utility | 🔨 Partially implemented |
| **SEC** | **12%** | Security posture | 🔨 Partially implemented |
| **AID** | **10%** | Discoverability | 🔨 Partially implemented |

## Advanced Usage

### Lower-Level Calculation

```python
from jentic_openapi.score.framework import (
    calculate_final_score,
    calculate_maturity
)

# Calculate scores without maturity
final_score = calculate_final_score(ctx)

# Calculate maturity separately (reusing final_score for efficiency)
maturity = calculate_maturity(ctx, final_score=final_score)
```

### Accessing Internal APIs

For internal development or testing, non-public items can be imported from submodules:

```python
# Import from specific submodules
from jentic_openapi.score.framework.enums import SpecType, BuiltinSignal
from jentic_openapi.score.framework.constants import EPSILON
from jentic_openapi.score.framework.normalizers import coverage, binary
from jentic_openapi.score.framework.calculators.signals.registry import register_signal

# These are not part of the public API and may change between versions
```

## Implementation Status

**Version 0.1.0** implements:
- ✅ Group A (FDX):
  - FC dimension: All 4 signals (spec_validity, resolution_completeness, lint_results, structural_integrity)
  - DXJ dimension: Partial (4/5 signals - example_density, example_validity, response_coverage, tooling_readiness)
- ✅ Group B (AIRU):
  - ARAX dimension: Partial (4/7 signals - summary_coverage, description_coverage, error_standardization, opid_quality)
  - AU dimension: Partial (1/5 signals - complexity_comfort)
- ✅ Group C (TSD):
  - SEC dimension: Partial (1/6 signals - auth_strength)
  - AID dimension: Partial (1/4 signals - descriptive_richness)
- ✅ Final score calculation with weighted harmonic mean
- ✅ Maturity classification with FC gating rule

Future versions will implement remaining DXJ signal (doc_clarity), remaining ARAX signals, remaining AU signals, remaining SEC signals, and remaining AID signals.

## Error Handling

```python
from jentic_openapi.score.framework import calculate_readiness, ScoreContext

try:
    readiness = calculate_readiness(ctx)
except ValueError as e:
    # Raised if FC dimension is missing (indicates framework bug)
    print(f"Framework error: {e}")
```

The framework expects all dimensions to be present in calculation results. If the FC dimension is missing during maturity calculation, a `ValueError` is raised.

## Thread Safety

The framework is thread-safe. You can safely calculate scores for different APIs in parallel across multiple threads.
