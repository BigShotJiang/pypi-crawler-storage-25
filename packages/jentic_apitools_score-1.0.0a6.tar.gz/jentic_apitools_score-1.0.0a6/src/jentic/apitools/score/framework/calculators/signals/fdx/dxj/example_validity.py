"""DXJ Signal: Example Validity

Measures the percentage of examples that conform to their defined schemas.
Uses coverage normalization: valid_examples / total_examples.

This signal evaluates the quality and correctness of examples, checking whether:
- Examples are valid JSON
- Examples match the types specified in the schema
- Examples don't contradict the schema definition

Formula:
    example_validity = valid_examples / total_examples

Special case:
    If total_examples = 0, returns 1.0 (no penalty for no examples)
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.EXAMPLE_VALIDITY,
    name="Example Validity",
    description="Percentage of examples that conform to their schemas.",
    group=GroupKind.FDX,
    dimension=DimensionKind.DXJ,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def example_validity(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate example validity signal based on schema conformance.

    Expects ctx.diagnostics to contain:
    - "total_examples": Diagnostic with total example count
    - "oas3-valid-schema-example": Diagnostics for invalid schema examples
    - "oas3-valid-media-example": Diagnostics for invalid media examples

    Formula:
        example_validity = valid_examples / total_examples

    If total_examples = 0, returns 1.0 (no examples to validate).

    Args:
        ctx: Scoring context with spec and diagnostics
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], counts as raw_value, and breakdown metadata
    """
    # Extract example validation counts from diagnostics
    invalid_examples = 0
    total_examples = 0

    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics:
            if diagnostic.code == DiagnosticCode.TOTAL_EXAMPLES and isinstance(
                diagnostic.data, dict
            ):
                total_examples = diagnostic.data.get(DiagnosticCode.TOTAL_EXAMPLES, 0)
            elif diagnostic.code in ("oas3-valid-schema-example", "oas3-valid-media-example"):
                invalid_examples += 1

    # Ensure total_examples is an integer
    try:
        total_examples = int(total_examples)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid total_examples value in diagnostic data: %r. "
            "Defaulting to 0. This may indicate a data quality issue.",
            total_examples,
        )
        total_examples = 0
        invalid_examples = 0

    # Clamp invalid_examples if it exceeds total_examples
    if invalid_examples > total_examples:
        logger.warning(
            "Invalid examples count (%d) exceeds total examples count (%d). "
            "Clamping to total_examples. This may indicate duplicate diagnostics or miscounting.",
            invalid_examples,
            total_examples,
        )
        invalid_examples = total_examples

    # Calculate valid examples
    valid_examples = total_examples - invalid_examples

    # Normalize using coverage (handles division by zero with default=1.0)
    normalized_value = config.normalizer(
        count_present=float(valid_examples),
        count_expected=float(total_examples),
    )

    return Signal(
        value=normalized_value,
        raw_value=valid_examples,
        metadata={
            "valid_examples": valid_examples,
            "invalid_examples": invalid_examples,
            "total_examples": total_examples,
            "provenance": {
                "diagnostics": {
                    "code": [
                        DiagnosticCode.TOTAL_EXAMPLES,
                        "oas3-valid-schema-example",
                        "oas3-valid-media-example",
                    ]
                }
            },
        },
    )
