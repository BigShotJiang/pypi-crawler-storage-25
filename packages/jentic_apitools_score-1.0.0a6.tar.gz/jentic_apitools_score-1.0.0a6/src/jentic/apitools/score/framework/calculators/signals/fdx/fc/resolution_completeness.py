"""FC Signal: Resolution Completeness

Measures the completeness of $ref resolution in the OpenAPI specification.
Uses coverage normalization: resolved_refs / total_refs.

This signal expects total_refs and resolved_refs to be provided in ctx.diagnostics
by the validation/parsing pipeline.
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.RESOLUTION_COMPLETENESS,
    name="Resolution Completeness",
    description="Percentage of `$ref` references that resolve successfully.",
    group=GroupKind.FDX,
    dimension=DimensionKind.FC,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def resolution_completeness(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate resolution completeness signal.

    Reads total_refs and resolved_refs from diagnostics, which should be
    populated by the validation/parsing pipeline.

    Args:
        ctx: Scoring context with metadata containing ref counts
        config: Signal configuration with normalizer and bounds

    Returns:
        Signal with normalized value (resolved/total) and metadata
    """

    total_refs = 0
    resolved_refs = 0
    # Find diagnostic with code 'total_refs', 'resolved_refs' and extract the value
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics:
            if (
                diagnostic.code == DiagnosticCode.TOTAL_REFS
                and diagnostic.source == "speclynx-validator"
                and isinstance(diagnostic.data, dict)
            ):
                total_refs = diagnostic.data.get(DiagnosticCode.TOTAL_REFS, 0)
            elif (
                diagnostic.code == DiagnosticCode.RESOLVED_REFS
                and diagnostic.source == "speclynx-validator"
                and isinstance(diagnostic.data, dict)
            ):
                resolved_refs = diagnostic.data.get(DiagnosticCode.RESOLVED_REFS, 0)

    # Ensure values are integers
    try:
        total_refs = int(total_refs)
        resolved_refs = int(resolved_refs)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid ref count values in metadata: total_refs=%r, resolved_refs=%r. "
            "Defaulting to 0. This may indicate a data quality issue in the metadata pipeline.",
            total_refs,
            resolved_refs,
        )
        total_refs = 0
        resolved_refs = 0

    unresolved_refs = total_refs - resolved_refs

    # Normalize using coverage
    normalized_value = config.normalizer(float(resolved_refs), float(total_refs))

    return Signal(
        value=normalized_value,
        raw_value=resolved_refs,
        metadata={
            "total_refs": total_refs,
            "resolved_refs": resolved_refs,
            "unresolved_refs": unresolved_refs,
            "provenance": {
                "diagnostics": {
                    "code": [DiagnosticCode.TOTAL_REFS, DiagnosticCode.RESOLVED_REFS],
                    "source": ["speclynx-validator"],
                }
            },
        },
    )
