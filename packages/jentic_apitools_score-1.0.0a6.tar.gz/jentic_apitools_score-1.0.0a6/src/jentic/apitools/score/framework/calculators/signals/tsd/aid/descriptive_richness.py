"""AID Signal: Descriptive Richness

Measures the semantic value of textual descriptions within an API.
Evaluates whether descriptions are sufficiently clear and detailed
for AI systems to infer purpose, behaviour, and domain context.

Formula:
    descriptive_richness = Σ(element_descriptive_score) / (2 * number_of_describable_elements)

Each element earns up to 2 points (1 for clarity + 1 for depth).
Score normalized to [0, 1].

If no describable elements or no semantic analysis, returns 1.0 (not applicable).

.. warning::
    Current implementation is LIMITED TO OPERATION OBJECTS ONLY.
    Future versions will extend semantic analysis to all describable elements:
    info.description, schema descriptions, parameter descriptions, response descriptions,
    header descriptions, tag descriptions, etc.
"""

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import clamp, identity, safe_divide
from ...registry import register_signal


# Issue codes mapped to clarity levels (worst issue wins)
CLARITY_LOW_ISSUES = {"poor_ai_interpretability"}  # Score: 0.0
CLARITY_MODERATE_ISSUES = {
    "vague_summary",
    "vague_description",
    "inconsistent_terminology",
    "not_actionable",
}  # Score: 0.5

# Issue codes mapped to depth levels (worst issue wins)
DEPTH_LOW_ISSUES = {"unclear_purpose", "poor_ai_interpretability"}  # Score: 0.0
DEPTH_MEDIUM_ISSUES = {
    "missing_context",
    "missing_input_details",
    "missing_output_details",
    "missing_side_effects",
    "not_actionable",
}  # Score: 0.5


@register_signal(
    kind=BuiltinSignal.DESCRIPTIVE_RICHNESS,
    name="Descriptive Richness",
    description="Clarity and depth of descriptions across API elements.",
    group=GroupKind.TSD,
    dimension=DimensionKind.AID,
    normalizer=identity,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def descriptive_richness(ctx: ScoreContext, config: SignalConfig) -> Signal:
    """Calculate descriptive richness based on LLM semantic analysis.

    Extracts quality issues from semantic_analyzer diagnostics and computes
    clarity and depth scores for each operation.

    .. warning::
        Current implementation only analyzes OPERATION OBJECTS.
        Future versions will extend to all describable elements (schemas,
        parameters, responses, headers, tags, info, etc.).

    Args:
        ctx: Scoring context with diagnostics from semantic_analyzer
        config: Signal configuration

    Returns:
        Signal with normalized value [0, 1]
    """
    # Extract data from diagnostics
    number_of_describable_elements = 0
    operation_issues: dict[str, list[str]] = {}  # operation_id -> issues_found

    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics or []:
            # Get total operations analyzed from semantic analyzer summary
            if diagnostic.code == DiagnosticCode.SEMANTIC_ANALYSIS_SUMMARY and isinstance(
                diagnostic.data, dict
            ):
                number_of_describable_elements = diagnostic.data.get("total_operations_analyzed", 0)

            # Get operation quality issues from semantic analyzer
            if diagnostic.code == DiagnosticCode.POOR_OPERATION_SEMANTICS and isinstance(
                diagnostic.data, dict
            ):
                op_id = diagnostic.data.get("operation_id", "")
                issues = diagnostic.data.get("issues_found", [])
                if op_id and issues:
                    operation_issues[op_id] = issues

    # Calculate Σ(element_descriptive_score)
    sum_of_element_descriptive_scores = 0.0
    operations_scored = []

    # Score operations with issues
    for op_id, issues in operation_issues.items():
        clarity_score, depth_score = _calculate_scores(issues)
        element_descriptive_score = clarity_score + depth_score
        sum_of_element_descriptive_scores += element_descriptive_score
        operations_scored.append(
            {
                "operation_id": op_id,
                "clarity_score": clarity_score,
                "depth_score": depth_score,
                "element_descriptive_score": element_descriptive_score,
                "issues_found": issues,
            }
        )

    # Operations without issues get full score (2.0)
    operations_without_issues = number_of_describable_elements - len(operation_issues)
    sum_of_element_descriptive_scores += operations_without_issues * 2.0

    # Apply formula: descriptive_richness = Σ(element_descriptive_score) / (2 * number_of_describable_elements)
    # If no describable elements, safe_divide returns 1.0 (signal not applicable)
    _descriptive_richness = safe_divide(
        sum_of_element_descriptive_scores, 2 * number_of_describable_elements
    )

    # Apply normalizer (identity for this signal)
    normalized_value = config.normalizer(clamp(_descriptive_richness))

    return Signal(
        value=normalized_value,
        raw_value=_descriptive_richness,
        metadata={
            "number_of_describable_elements": number_of_describable_elements,
            "operations_with_issues": len(operation_issues),
            "operations_without_issues": operations_without_issues,
            "sum_of_element_descriptive_scores": sum_of_element_descriptive_scores,
            "operations_scored": operations_scored,
            "provenance": {
                "diagnostics": {
                    "code": [
                        DiagnosticCode.SEMANTIC_ANALYSIS_SUMMARY,
                        DiagnosticCode.POOR_OPERATION_SEMANTICS,
                    ]
                }
            },
        },
    )


def _calculate_scores(issues: list[str]) -> tuple[float, float]:
    """Calculate clarity and depth scores based on issue severity levels.

    Uses context-aware scoring for clarity:
    - When summary is good (no vague_summary) but description is bad (vague_description),
      poor_ai_interpretability is attributed to description only, not penalizing the good summary.
    - Otherwise uses "worst issue wins" approach.

    Clarity Levels:
        - High (1.0): No clarity issues
        - Moderate (0.5): vague_summary, vague_description, inconsistent_terminology, not_actionable
        - Low (0.0): poor_ai_interpretability

    Depth Levels:
        - High (1.0): No depth issues
        - Medium (0.5): missing_context, missing_input_details, missing_output_details,
                        missing_side_effects, not_actionable
        - Low (0.0): unclear_purpose, poor_ai_interpretability

    Args:
        issues: List of issue codes from semantic analyzer

    Returns:
        Tuple of (clarity_score, depth_score), each in range [0, 1]
    """
    # Check summary/description specific issues
    has_vague_summary = "vague_summary" in issues
    has_vague_description = "vague_description" in issues
    has_poor_ai = "poor_ai_interpretability" in issues

    # Context-aware clarity scoring
    if not has_vague_summary and has_vague_description:
        # Summary is good, description is bad - attribute poor_ai to description only
        summary_clarity = 1.0
        if has_poor_ai:
            description_clarity = 0.0  # poor_ai attributed to description
        else:
            description_clarity = 0.5  # just vague description
        clarity_score = (summary_clarity + description_clarity) / 2
    elif has_vague_summary and not has_vague_description:
        # Summary is bad, description is good - attribute poor_ai to summary only
        if has_poor_ai:
            summary_clarity = 0.0  # poor_ai attributed to summary
        else:
            summary_clarity = 0.5  # just vague summary
        description_clarity = 1.0
        clarity_score = (summary_clarity + description_clarity) / 2
    else:
        # Both bad or both good - use worst-wins logic
        if has_poor_ai:
            clarity_score = 0.0
        elif any(issue in CLARITY_MODERATE_ISSUES for issue in issues):
            clarity_score = 0.5
        else:
            clarity_score = 1.0

    # Determine depth level - context-aware for poor_ai_interpretability
    # When one component is good and other is bad, poor_ai is attributed to the bad component
    # and should not tank depth to 0.0
    is_context_aware = (not has_vague_summary and has_vague_description) or (
        has_vague_summary and not has_vague_description
    )
    if is_context_aware and has_poor_ai:
        # Context-aware: ignore poor_ai for depth, only check other low issues
        other_depth_low = DEPTH_LOW_ISSUES - {"poor_ai_interpretability"}
        if any(issue in other_depth_low for issue in issues):
            depth_score = 0.0
        elif any(issue in DEPTH_MEDIUM_ISSUES for issue in issues):
            depth_score = 0.5
        else:
            depth_score = 1.0
    else:
        # Standard worst-wins logic
        if any(issue in DEPTH_LOW_ISSUES for issue in issues):
            depth_score = 0.0
        elif any(issue in DEPTH_MEDIUM_ISSUES for issue in issues):
            depth_score = 0.5
        else:
            depth_score = 1.0

    return clarity_score, depth_score
