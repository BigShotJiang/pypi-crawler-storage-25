"""Core data structures for the API Scoring Framework.

This module defines the fundamental dataclasses used throughout the scoring system,
including signals, dimensions, groups, and their metadata.
"""

from collections.abc import Mapping
from dataclasses import dataclass, field
from typing import Any, Callable, Generic, TypeVar

from jentic.apitools.openapi.validator.core import JenticDiagnostic

from .enums import BuiltinSignal, DimensionKind, Grade, GroupKind, Maturity, SpecType


__all__ = [
    # Core types
    "Signal",
    "SignalConfig",
    "DimensionScore",
    "GroupScore",
    "FinalScore",
    "Readiness",
    "ScoreContext",
    # Type aliases
    "SignalCalculator",
    "NormalizerT",
]

# Type aliases for clarity
SignalCalculator = Callable[["ScoreContext", "SignalConfig"], "Signal"]
"""Function signature for signal calculators: (ScoreContext, SignalConfig) -> Signal"""

NormalizerT = TypeVar("NormalizerT", bound=Callable[..., float])
"""Type variable for normalizer types, bound to Callable[..., float].

This allows SignalConfig to be parameterized with any normalizer function type:
    config: SignalConfig[InverseErrorNormalizer]  # Built-in protocol
    config: SignalConfig[Callable[[int, int], float]]  # Custom normalizer

The bound ensures normalizers are callables that return float, but allows
users to implement custom normalizers beyond the built-in protocols.
"""


@dataclass(frozen=True)
class Signal:
    """A normalized signal value representing a specific measurable property.

    Signals are the atomic units of measurement in the scoring framework.
    Each signal is normalized to the [0, 1] range where:
    - 1.0 represents ideal/perfect
    - 0.0 represents unusable/absent

    Attributes:
        value: Normalized value in [0, 1]
        raw_value: Original measurement before normalization (required)
        kind: Unique identifier for this signal (auto-injected by decorator if None)
        name: Human-readable display name (auto-injected by decorator if None)
        description: What this signal measures (auto-injected by decorator if None)
        bounds: Expected range for the raw value (auto-injected by decorator if None)
        group: Which group this signal belongs to (auto-injected by decorator if None)
        dimension: Which dimension this signal belongs to (auto-injected by decorator if None)
        metadata: Additional context (e.g., counts, thresholds)
    """

    value: float  # Normalized [0, 1]
    raw_value: float
    kind: BuiltinSignal | str | None = None
    name: str | None = None
    description: str | None = None
    bounds: tuple[float, float] | None = None
    group: GroupKind | None = None
    dimension: DimensionKind | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self):
        # Validate signal constraints and normalize kind to string.
        if not (0.0 <= self.value <= 1.0):
            raise ValueError(f"Signal value must be in [0, 1], got {self.value}")
        # Convert BuiltinSignal enum to string value if needed
        if isinstance(self.kind, BuiltinSignal):
            object.__setattr__(self, "kind", self.kind.value)


@dataclass
class SignalConfig(Generic[NormalizerT]):
    """Configuration describing a signal calculator.

    This is used for registration and documentation of available signals.

    Type Parameters:
        NormalizerT: The specific normalizer protocol type (e.g., InverseErrorNormalizer)
                     This enables type-safe access to config.normalizer without casting.

    Attributes:
        kind: Unique signal identifier (use BuiltinSignal enum for built-in signals)
        name: Human-readable display name
        description: What this signal measures
        dimension: Which dimension this signal belongs to
        group: Which group this signal belongs to (auto-derived from dimension)
        normalizer: Normalization function used by this signal (type-safe when parameterized)
        bounds: Expected raw value range (source of truth, injected into Signal)
        calculator: Function that computes this signal
        target_specs: Target (spec_type, version_pattern) tuples this signal supports

    Examples:
        # Type-safe config with specific normalizer
        config: SignalConfig[InverseErrorNormalizer] = SignalConfig(
            kind="my_signal",
            name="My Signal",
            normalizer=inverse_error,  # Type checker knows this is InverseErrorNormalizer
            ...
        )

        # Unparameterized config (for registry storage)
        config: SignalConfig = SignalConfig(...)  # Works too!
    """

    kind: BuiltinSignal | str
    name: str
    description: str
    group: GroupKind
    dimension: DimensionKind
    normalizer: NormalizerT
    calculator: SignalCalculator
    bounds: tuple[float, float] = (0.0, 1.0)
    target_specs: tuple[tuple[str, str], ...] | None = None

    def __post_init__(self):
        # Normalize kind to string if enum provided.
        if isinstance(self.kind, BuiltinSignal):
            object.__setattr__(self, "kind", self.kind.value)

    def __repr__(self) -> str:
        normalizer_name = getattr(self.normalizer, "__name__", str(self.normalizer))
        return f"SignalConfig(kind='{self.kind}', name='{self.name}', dimension={self.dimension.value}, group={self.group.value}, normalizer={normalizer_name})"


@dataclass(frozen=True)
class DimensionScore:
    """Score for a dimension, aggregated from multiple signals.

    Dimensions represent thematic groupings of signals and are scored
    on a [0, 100] scale for easier interpretation.

    Attributes:
        kind: Dimension identifier (from DimensionKind)
        name: Human-readable dimension name
        score: Aggregated score [0, 100]
        grade: Letter grade (A+ through F) for this dimension
        signals: Individual signals that comprise this dimension
        weight: Weight used in final score aggregation
        description: Explanation of what this dimension measures
    """

    kind: DimensionKind
    name: str
    score: float  # [0, 100]
    grade: Grade
    signals: list[Signal] = field(default_factory=list)
    weight: float = 1.0
    description: str = ""

    def __post_init__(self):
        """Validate dimension score constraints."""
        if not (0.0 <= self.score <= 100.0):
            raise ValueError(f"Dimension score must be in [0, 100], got {self.score}")
        if not (0.0 <= self.weight <= 1.0):
            raise ValueError(f"Dimension weight must be in [0, 1], got {self.weight}")


@dataclass(frozen=True)
class GroupScore:
    """Score for a group, aggregated from multiple dimensions.

    Groups represent high-level organizational themes and contain
    2 dimensions each. Scored on a [0, 100] scale.

    Attributes:
        kind: Group identifier (from GroupKind)
        name: Human-readable group name
        score: Aggregated score [0, 100]
        grade: Letter grade (A+ through F) for this group
        dimension_scores: Individual dimension scores that comprise this group
        description: Description of what this group focuses on
    """

    kind: GroupKind
    name: str
    score: float  # [0, 100]
    grade: Grade
    dimension_scores: list[DimensionScore] = field(default_factory=list)
    description: str = ""

    def __post_init__(self):
        """Validate group score constraints."""
        if not (0.0 <= self.score <= 100.0):
            raise ValueError(f"Group score must be in [0, 100], got {self.score}")


@dataclass(frozen=True)
class FinalScore:
    """Final API quality score, aggregated from all groups using weighted harmonic mean.

    The final score represents the overall API quality across all dimensions
    and groups. Scored on a [0, 100] scale using weighted harmonic mean,
    which penalizes weak performance in any dimension.

    Attributes:
        score: Final aggregated score [0, 100]
        grade: Letter grade (A+ through F) for the overall API quality
        group_scores: The 3 group scores (FDX, AIRU, TSD)
        dimension_scores: All 6 dimension scores extracted from groups
    """

    score: float  # [0, 100]
    grade: Grade
    group_scores: list[GroupScore] = field(default_factory=list)
    dimension_scores: list[DimensionScore] = field(default_factory=list)

    def __post_init__(self):
        """Validate final score constraints."""
        if not (0.0 <= self.score <= 100.0):
            raise ValueError(f"Final score must be in [0, 100], got {self.score}")


@dataclass(frozen=True)
class Readiness:
    """Complete AI-Readiness assessment combining numerical scores and maturity level.

    This model provides the full picture of an API's AI-Readiness by combining:
    - Detailed numerical scores across all dimensions, groups, and signals
    - A categorical maturity level (Level 0-4) representing the API's readiness stage

    The maturity level is derived from the final score with gating rules applied,
    so it's always consistent with the numerical scores provided.

    Attributes:
        final_score: Complete scoring breakdown (0-100 scale)
        maturity: Categorical AI-Readiness level (Level 0-4)

    Examples:
        Calculate complete readiness assessment::

            from jentic_openapi.score.framework import calculate_readiness, ScoreContext

            ctx = ScoreContext(spec_document={...}, spec_uri="...", ...)
            readiness = calculate_readiness(ctx)

            print(f"Score: {readiness.final_score.score}")
            print(f"Maturity: {readiness.maturity.value}")

            # Access detailed breakdowns
            for dimension in readiness.final_score.dimension_scores:
                print(f"{dimension.name}: {dimension.score}")
    """

    final_score: FinalScore
    maturity: Maturity


@dataclass(frozen=True)
class ScoreContext:
    """Context passed to signal calculators containing all necessary data.

    This provides a consistent interface for all signal calculation functions,
    containing the parsed spec, source information, and diagnostic data.

    Attributes:
        spec_uri: URI where the spec was loaded from (file://, http://, https://)
        spec_source: Raw YAML/JSON string source
        spec_document: Parsed OpenAPI document as Mapping, or None if parsing failed
        spec_type: Type of spec (currently only OPENAPI supported), if detected
        spec_version: Version string (e.g., "3.0.0", "3.1.0"), if detected
        diagnostics: List of validation diagnostics
        metadata: Additional context (vendor, version, etc.)
    """

    spec_uri: str
    spec_source: str | None
    spec_document: Mapping[str, Any] | None
    spec_type: SpecType | str | None = None
    spec_version: str | None = None
    diagnostics: list[JenticDiagnostic] = field(default_factory=list)
    metadata: dict[str, Any] = field(default_factory=dict)

    def __post_init__(self) -> None:
        """Normalize spec_type enum to string value."""
        if isinstance(self.spec_type, SpecType):
            object.__setattr__(self, "spec_type", self.spec_type.value)
