"""Maturity Level Calculator for the Jentic API Scoring Framework.

Classifies API quality into maturity levels (Level 0-4) based on the final score
and gating rules defined in the framework specification.
"""

from ..enums import DimensionKind, Maturity
from ..models import FinalScore, ScoreContext
from .final_score import calculate_final_score


__all__ = ["calculate_maturity"]


def calculate_maturity(ctx: ScoreContext, final_score: FinalScore | None = None) -> Maturity:
    """Calculate the maturity level based on final score and gating rules.

    Maps the numerical final score (0-100) to a categorical maturity level
    representing the API's quality and AI-Readiness progression, applying
    gating rules that can override the score-based classification.

    Gating Rules (from framework specification):
        - Foundational Compliance (FC) < 40: API classified as "Non-Compliant" (Level 0)

    Maturity Level Thresholds (when no gates triggered):
        - Level 0 (Not Ready): score < 40
        - Level 1 (Foundational): 40 <= score < 60
        - Level 2 (AI-Aware): 60 <= score < 75
        - Level 3 (AI-Ready): 75 <= score < 90
        - Level 4 (Agent-Optimised): score >= 90

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata
        final_score: Optional pre-calculated FinalScore. If None, will be calculated
                    using calculate_final_score(ctx)

    Returns:
        Maturity enum value representing the categorical maturity level

    Examples:
        Basic usage - auto-calculates final score::

            from jentic_openapi.score.framework import calculate_maturity, ScoreContext

            ctx = ScoreContext(spec_document={...}, spec_uri="...", ...)
            maturity = calculate_maturity(ctx)
            # Returns: Maturity.LEVEL_1 (if final score is 40-60)

        With pre-calculated FinalScore (avoids re-calculation)::

            final_score = calculate_final_score(ctx)
            maturity = calculate_maturity(ctx, final_score=final_score)
            # Returns: Maturity.LEVEL_2 (if final score is 60-75)

        Gating rule - FC < 40 forces Level 0 regardless of final score::

            # If FC dimension score is 30 but final score is 75:
            maturity = calculate_maturity(ctx, final_score=final_score)
            # Returns: Maturity.LEVEL_0 (gate triggered by FC < 40)
    """
    # Calculate final score if not provided
    if final_score is None:
        final_score = calculate_final_score(ctx)

    # Extract Foundational Compliance (FC) dimension score for gating check
    fc_dimension = next(
        (d for d in final_score.dimension_scores if d.kind == DimensionKind.FC), None
    )

    # FC dimension must always exist - if missing, the scoring system is broken
    if fc_dimension is None:
        raise ValueError(
            "FC dimension missing from final_score - this indicates a bug in calculate_final_score"
        )

    # Gating Rule: Foundational Compliance below 40 → Level 0 (Non-Compliant)
    if fc_dimension.score < 40:
        return Maturity.LEVEL_0

    # Map final score to maturity level using threshold boundaries
    score = final_score.score
    if score < 40:
        return Maturity.LEVEL_0
    elif score < 60:
        return Maturity.LEVEL_1
    elif score < 75:
        return Maturity.LEVEL_2
    elif score < 90:
        return Maturity.LEVEL_3
    else:  # score >= 90
        return Maturity.LEVEL_4
