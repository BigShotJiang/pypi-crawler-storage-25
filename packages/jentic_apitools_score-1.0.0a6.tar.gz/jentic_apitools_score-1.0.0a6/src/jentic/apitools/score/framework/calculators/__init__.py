"""Calculator module for the API Scoring Framework.

This module contains all calculators for computing scores at different levels:
- readiness: Complete AI-Readiness assessment (scores + maturity)
- final_score: Overall API score calculator
- maturity: Maturity level classifier
- groups: Group-level score calculators (FDX, AIRU, TSD)
- dimensions: Dimension-level score calculators (FC, DXJ, ARAX, AU, SEC, AID)
- signals: Individual signal calculators and registry
"""

# Import signals module to trigger @register_signal decorators
from . import signals  # noqa: F401
from .final_score import calculate_final_score
from .maturity import calculate_maturity
from .readiness import calculate_readiness


__all__ = [
    "calculate_readiness",
    "calculate_final_score",
    "calculate_maturity",
]
