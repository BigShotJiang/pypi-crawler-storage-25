"""Signal definitions for the API Scoring Framework.

This module contains all signal calculator implementations organized hierarchically:
- Groups (FDX, AIRU, TSD)
  - Dimensions (FC, DXJ, ARAX, AU, SEC, AID)
    - Individual signals

Signals are automatically registered when this module is imported.

Structure:
  signals/
  ├── fdx/              # Group A: Foundational & DX
  │   ├── fc/           # Dimension: Foundational Compliance
  │   └── dxj/          # Dimension: Developer Experience & Jentic
  ├── airu/             # Group B: AI-Readiness & Usability (future)
  │   ├── arax/         # Dimension: AI-Readiness & Agent Experience
  │   └── au/           # Dimension: Agent Usability
  └── tsd/              # Group C: Trust/Safety & Discoverability (future)
      ├── sec/          # Dimension: Security
      └── aid/          # Dimension: AI Discoverability

Version 0.1 implements only Group A (FDX) signals.
"""

# Import all group modules to trigger signal registration
from . import airu, fdx, tsd  # noqa: F401 I001

# Expose registry functions for public use
from .registry import (
    SignalCalculatorProtocol,
    all_signals,
    get_signal,
    list_signals,
    register_signal,
)


__all__ = [
    # Registry functions
    "register_signal",
    "get_signal",
    "list_signals",
    "all_signals",
    "SignalCalculatorProtocol",
]
