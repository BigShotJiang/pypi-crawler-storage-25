"""AIRU (AI-Readiness & Usability) Group Calculator.

Calculates the AIRU group score by aggregating ARAX and AU dimension scores.

Formula:
    GroupScore = (ARAX_score × 0.24 + AU_score × 0.20) / (0.24 + 0.20)
               = (ARAX_score × 0.24 + AU_score × 0.20) / 0.44
"""

from ...enums import GroupKind
from ...models import DimensionScore, GroupScore, ScoreContext
from ..dimensions.airu import arax, au
from ..grade import calculate_grade
from . import aggregate_dimension_scores


__all__ = ["calculate_group_score"]


def calculate_group_score(ctx: ScoreContext) -> GroupScore:
    """Calculate the AI-Readiness & Usability (AIRU) group score.

    Executes ARAX and AU dimension calculators and aggregates their scores
    using weighted average.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        GroupScore with:
        - kind: GroupKind.AIRU
        - name: "AI-Readiness & Usability"
        - score: 0-100 weighted aggregate score
        - dimension_scores: List of DimensionScore results [ARAX, AU]
        - focus: Group theme description

    Example:
        Given ARAX = 85.0 (weight 0.24) and AU = 80.0 (weight 0.20):
        AIRU score = (85 × 0.24 + 80 × 0.20) / 0.44 ≈ 82.73
    """
    # Calculate dimension scores
    arax_dimension = arax.calculate_dimension_score(ctx)
    au_dimension = au.calculate_dimension_score(ctx)

    dimension_scores: list[DimensionScore] = [arax_dimension, au_dimension]

    # Calculate group score using weighted average
    score = aggregate_dimension_scores(dimension_scores)

    # Create and return group score
    return GroupScore(
        kind=GroupKind.AIRU,
        name="AI-Readiness & Usability",
        score=score,
        grade=calculate_grade(score),
        dimension_scores=dimension_scores,
        description="Machine-oriented semantic clarity - interpretability, structure, and AI agent comprehension.",
    )
