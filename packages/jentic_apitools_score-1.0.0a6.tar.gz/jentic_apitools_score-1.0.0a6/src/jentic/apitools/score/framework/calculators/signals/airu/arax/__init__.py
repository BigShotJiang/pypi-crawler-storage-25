"""ARAX (AI-Readiness & Agent Experience) dimension signals.

This dimension measures AI-readiness and agent comprehension of API specifications.
Signals in this dimension evaluate semantic breadth, depth, and clarity for AI systems.
"""

import importlib
import pkgutil


# Auto-discover and import all signal modules to trigger @register_signal decorators
# Skip stub signals (files starting with underscore)
for importer, modname, ispkg in pkgutil.iter_modules(__path__):
    if not ispkg and not modname.startswith("_"):  # Only import implemented signals
        importlib.import_module(f".{modname}", package=__name__)

__all__ = []  # Signals register automatically via decorators
