"""AIRU (AI-Readiness & Usability) group dimension calculators.

This group contains two dimensions:
- ARAX (AI-Readiness & Agent Experience): Semantic breadth, depth, and agent comprehension
- AU (Agent Usability): Functional utility, complexity, and AI orchestration possibilities
"""

from . import arax, au


__all__ = ["arax", "au"]
