"""Normalization utilities for the API Scoring Framework.

This module implements various normalization strategies for Jentic API Scoring Framework.
These functions convert raw measurements into normalized values in the range [0, 1], where:
- 1.0 represents ideal/perfect
- 0.0 represents unusable/absent

All normalization functions follow a consistent pattern:
- Accept raw measurements as input
- Return float in [0, 1] range
- Handle edge cases (division by zero, etc.)

Categorization by Mathematical Complexity
=========================================

The normalizers are organized into three categories based on their mathematical
complexity and transformation approach:

1. Linear Normalizations
   - Simple arithmetic operations (ratios, inversions, passthrough)
   - Direct input-to-output mapping
   - Examples: identity, coverage, inverse_error, binary, semantic_similarity
   - Use when: You need straightforward proportional transformations or no transformation at all

2. Weighted Normalizations
   - Combine multiple inputs with weights or factors
   - Multiplicative adjustments and context-aware scaling
   - Examples: severity_weighted_inverse, bonus_multiplier, context_scaling, risk_discount
   - Use when: Multiple factors need to be combined or scores need contextual adjustment

3. Non-linear Normalizations
   - Curve shaping and sigmoid transformations
   - Non-proportional response to input changes
   - Examples: logistic_shaping
   - Use when: You need to avoid over-penalization or create threshold-based transitions

Type Safety
===========

Each normalizer function has a corresponding Protocol class for type-safe usage.
When implementing signals, you can cast config.normalizer to the specific protocol
to get type checking and autocomplete:

    from typing import cast
    normalizer = cast(InverseErrorNormalizer, config.normalizer)
    value = normalizer(issue_count=5, threshold=15, floor_at_zero=True)
"""

import math
from typing import Protocol

from .enums import DiagnosticSeverityWeight


__all__ = [
    # Linear normalizations
    "identity",
    "binary",
    "coverage",
    "inverse_error",
    "semantic_similarity",
    # Weighted normalizations
    "severity_weighted_inverse",
    "bonus_multiplier",
    "context_scaling",
    "risk_discount",
    # Non-linear normalizations
    "logistic_shaping",
    "logarithmic_dampening",
    # Protocol classes for type safety
    "IdentityNormalizer",
    "BinaryNormalizer",
    "CoverageNormalizer",
    "InverseErrorNormalizer",
    "SemanticSimilarityNormalizer",
    "SeverityWeightedNormalizer",
    "BonusMultiplierNormalizer",
    "ContextScalingNormalizer",
    "RiskDiscountNormalizer",
    "LogisticShapingNormalizer",
    "LogarithmicDampeningNormalizer",
    # Helpers
    "clamp",
    "safe_divide",
]


# =============================================================================
# Protocol Classes for Type Safety
# =============================================================================


class IdentityNormalizer(Protocol):
    """Protocol for identity normalization: identity(value: float) -> float."""

    def __call__(self, value: float) -> float:
        """Identity normalization: returns the input value unchanged (passthrough)."""
        ...


class BinaryNormalizer(Protocol):
    """Protocol for binary normalization: binary(condition: bool) -> float."""

    def __call__(self, condition: bool) -> float:
        """Binary normalization: 1.0 if condition is True, 0.0 otherwise."""
        ...


class CoverageNormalizer(Protocol):
    """Protocol for coverage normalization: coverage(present, expected) -> float."""

    def __call__(self, count_present: float, count_expected: float) -> float:
        """Coverage normalization: ratio of present to expected items."""
        ...


class InverseErrorNormalizer(Protocol):
    """Protocol for inverse error normalization: inverse_error(issue_count, threshold, floor_at_zero=True) -> float."""

    def __call__(self, issue_count: float, threshold: float, floor_at_zero: bool = True) -> float:
        """Inverse error normalization: penalizes error counts."""
        ...


class SemanticSimilarityNormalizer(Protocol):
    """Protocol for semantic similarity: semantic_similarity(similarity) -> float."""

    def __call__(self, similarity: float) -> float:
        """Semantic similarity normalization: measures distinctiveness (1 - similarity)."""
        ...


class SeverityWeightedNormalizer(Protocol):
    """Protocol for severity weighted normalization: severity_weighted_inverse(counts, max_cost, use_sqrt=False) -> float."""

    def __call__(self, counts: dict[str, int], max_cost: float, use_sqrt: bool = False) -> float:
        """Severity weighted inverse: weights issues by severity levels."""
        ...


class BonusMultiplierNormalizer(Protocol):
    """Protocol for bonus multiplier: bonus_multiplier(base_score, bonus_factor, coverage_value) -> float."""

    def __call__(self, base_score: float, bonus_factor: float, coverage_value: float) -> float:
        """Bonus multiplier: applies multiplicative bonus for features."""
        ...


class ContextScalingNormalizer(Protocol):
    """Protocol for context scaling: context_scaling(base_score, sensitivity_factor, exposure_factor) -> float."""

    def __call__(
        self, base_score: float, sensitivity_factor: float, exposure_factor: float
    ) -> float:
        """Context scaling: scales scores based on exposure and sensitivity."""
        ...


class RiskDiscountNormalizer(Protocol):
    """Protocol for risk discount: risk_discount(base_score, risk_index, min_discount=0.6) -> float."""

    def __call__(self, base_score: float, risk_index: float, min_discount: float = 0.6) -> float:
        """Risk discount: applies soft penalty for risk factors."""
        ...


class LogisticShapingNormalizer(Protocol):
    """Protocol for logistic shaping: logistic_shaping(raw_complexity, midpoint=0.45, steepness=6.0) -> float."""

    def __call__(
        self, raw_complexity: float, midpoint: float = 0.45, steepness: float = 6.0
    ) -> float:
        """Logistic shaping: sigmoid curve for complexity."""
        ...


class LogarithmicDampeningNormalizer(Protocol):
    """Protocol for logarithmic dampening: logarithmic_dampening(issue_count, threshold) -> float."""

    def __call__(self, issue_count: float, threshold: float) -> float:
        """Logarithmic dampening: smooth decay curve for issue penalization."""
        ...


# =============================================================================
# Linear Normalizations
# =============================================================================
# Simple arithmetic operations with direct input-to-output mapping


def identity(value: float) -> float:
    """Identity normalization: returns the input value unchanged (passthrough).

    Used when the signal calculator already produces a normalized value in [0, 1]
    and no further transformation is needed. This is the simplest normalizer and
    serves as explicit documentation that no normalization is applied.

    Formula:
        identity = value

    Args:
        value: Pre-normalized value in [0, 1]

    Returns:
        The same value unchanged

    Example:
        >>> identity(0.75)
        0.75
        >>> identity(1.0)
        1.0
        >>> identity(0.0)
        0.0
    """
    return value


def coverage(count_present: float, count_expected: float) -> float:
    """Coverage normalization: measures presence vs absence as a ratio.

    Used when measuring presence vs absence such as examples, descriptions,
    pagination, etc.

    Formula:
        coverage = count_present / count_expected

    If there are zero expected occurrences, coverage = 1.0 (the API is not
    penalized for irrelevance).

    Args:
        count_present: Number of items present
        count_expected: Number of items expected

    Returns:
        Normalized coverage score in [0, 1]

    Example:
        >>> coverage(23, 25)  # 92% of refs resolved
        0.92
        >>> coverage(0, 0)  # No expectations, perfect score
        1.0
    """
    result = safe_divide(count_present, count_expected, default=1.0)
    return clamp(result)


def inverse_error(issue_count: float, threshold: float, floor_at_zero: bool = True) -> float:
    """Inverse error normalization: penalizes error counts.

    Used when a raw count of issues must lower the score (linting, structural
    problems, ingestion errors, etc.).

    Formula:
        inverse = max(0, 1 - (issue_count / threshold))

    If the issue_count exceeds threshold, the score is floored at 0.
    Thresholds are dimension-specific.

    Args:
        issue_count: Number of issues detected
        threshold: Maximum acceptable issue count
        floor_at_zero: If True, floor negative values at 0 (default: True)

    Returns:
        Normalized inverse error score in [0, 1]

    Example:
        >>> inverse_error(3, 15)  # 3 structural issues, threshold 15
        0.8
        >>> inverse_error(20, 15)  # Exceeds threshold
        0.0
    """
    score = 1.0 - safe_divide(issue_count, threshold, default=0.0)
    if floor_at_zero:
        return clamp(score)
    return score


def binary(condition: bool) -> float:
    """Binary normalization: simple pass/fail check.

    Used where a single condition should result in 0 or 1.

    Formula:
        present = 0 or 1

    Args:
        condition: Boolean condition to check

    Returns:
        1.0 if condition is True, 0.0 otherwise

    Example:
        >>> binary(True)  # Spec parsed successfully
        1.0
        >>> binary(False)  # Spec failed to parse
        0.0
    """
    return 1.0 if condition else 0.0


def semantic_similarity(similarity: float) -> float:
    """Semantic similarity normalization: measures distinctiveness.

    Used for measuring distinctiveness, intent clarity, and overlap.

    Formula:
        distinctiveness = 1 - similarity

    Where similarity ∈ [0, 1]:
    - 0.0 = completely different
    - 1.0 = identical

    Args:
        similarity: Similarity score in [0, 1] (validated)

    Returns:
        Distinctiveness score in [0, 1]

    Raises:
        ValueError: If similarity is not in [0, 1] range

    Example:
        >>> round(semantic_similarity(0.3), 1)  # Low overlap
        0.7
        >>> round(semantic_similarity(0.9), 1)  # High overlap (bad)
        0.1
    """
    if not (0.0 <= similarity <= 1.0):
        raise ValueError(f"semantic_similarity requires similarity in [0, 1], got {similarity}")
    return 1.0 - similarity


# =============================================================================
# Weighted Normalizations
# =============================================================================
# Combine multiple inputs with weights or apply contextual adjustments


def severity_weighted_inverse(
    counts: dict[str, int], max_cost: float, use_sqrt: bool = False
) -> float:
    """Severity-weighted inverse normalization for static analysis output.

    Used for static analysis output where different findings carry different
    severity. Weights issues by severity and inverts the cost.

    Formula (without sqrt dampening):
        weighted_cost = (1.0 * critical) + (0.6 * errors) +
                       (0.0025 * warnings) + (0.001 * info)
        score = max(0, 1 - (weighted_cost / max_cost))

    Formula (with sqrt dampening):
        raw_weighted_cost = (1.0 * critical) + (0.6 * errors) +
                           (0.0025 * warnings) + (0.001 * info)
        dampened_cost = sqrt(raw_weighted_cost)
        score = max(0, 1 - (dampened_cost / max_cost))

    Sqrt dampening reduces artificial penalties from noisy rulesets by applying
    a square root transformation to the weighted cost. This is used for lint_results
    and OWASP posture signals.

    Severity weights (from DiagnosticSeverityWeight enum):
        - critical: 1.0
        - error: 0.6
        - warning: 0.0025
        - info: 0.001

    Args:
        counts: Dictionary mapping severity levels to counts
                Keys: "critical", "error", "warning", "info"
        max_cost: Maximum weighted cost threshold
        use_sqrt: If True, apply sqrt dampening to reduce noise (default: False)

    Returns:
        Normalized severity-weighted score in [0, 1]

    Example:
        >>> counts = {"critical": 0, "error": 5, "warning": 10, "info": 20}
        >>> severity_weighted_inverse(counts, 25, use_sqrt=True)
        0.9302
    """
    weighted_cost = (
        DiagnosticSeverityWeight.CRITICAL * counts.get("critical", 0)
        + DiagnosticSeverityWeight.ERROR * counts.get("error", 0)
        + DiagnosticSeverityWeight.WARNING * counts.get("warning", 0)
        + DiagnosticSeverityWeight.INFO * counts.get("info", 0)
    )

    if use_sqrt:
        weighted_cost = math.sqrt(weighted_cost)

    score = 1.0 - safe_divide(weighted_cost, max_cost, default=0.0)
    return max(0.0, score)


def bonus_multiplier(base_score: float, bonus_factor: float, coverage_value: float) -> float:
    """Bonus multiplier normalization: applies multiplicative bonus.

    Used where a feature is not required but improves AI usability/discoverability.

    Formula:
        score = base_score * (1 + bonus_factor * coverage)

    Applied to:
    - AI semantic surface (ARAX)
    - Hypermedia links (AU)
    - Discoverability boosting via registries

    Args:
        base_score: The base score to apply bonus to
        bonus_factor: Multiplier strength (typically 0.03 - 0.05)
        coverage_value: Coverage ratio in [0, 1]

    Returns:
        Enhanced score with bonus applied

    Example:
        >>> round(bonus_multiplier(0.696, 0.05, 0.30), 4)  # 5% bonus on 30% coverage
        0.7064
    """
    bonus = 1.0 + (bonus_factor * coverage_value)
    return base_score * bonus


def context_scaling(base_score: float, sensitivity_factor: float, exposure_factor: float) -> float:
    """Context scaling normalization: scales scores based on context.

    Used when the same issue becomes riskier depending on exposure and sensitivity.

    Formula:
        scaled = base_score * sensitivity_factor * exposure_factor

    This turns the same hygiene score into different effective risk depending on
    real-world enterprise use-case.

    Typical factors:
    - sensitivity_factor ∈ {1.00, 0.90, 0.75}
    - exposure_factor ∈ {1.00, 0.90, 0.80}

    Args:
        base_score: The base security/hygiene score
        sensitivity_factor: Data sensitivity multiplier (1.0=low, 0.75=high)
        exposure_factor: Exposure level multiplier (1.0=internal, 0.8=public)

    Returns:
        Context-scaled score

    Example:
        >>> round(context_scaling(0.833, 0.90, 0.80), 4)  # Moderate sensitivity, public API
        0.5998
    """
    return base_score * sensitivity_factor * exposure_factor


def risk_discount(base_score: float, risk_index: float, min_discount: float = 0.6) -> float:
    """Risk discount normalization: soft penalty for risk factors.

    Used when security posture should reduce but not disable discoverability.

    Formula:
        risk_discount = 1 - (0.5 * risk_index)
        final_score = base_score * risk_discount

    Clamped to [min_discount, 1.0] to avoid total suppression.

    Args:
        base_score: The base discoverability score
        risk_index: Risk index calculated from exposure/sensitivity
        min_discount: Minimum discount multiplier (default: 0.6)

    Returns:
        Risk-discounted score

    Example:
        >>> round(risk_discount(55.0, 0.1503, min_discount=0.6), 2)
        50.87
    """
    discount = 1.0 - (0.5 * risk_index)
    discount = clamp(discount, min_val=min_discount)
    return base_score * discount


# =============================================================================
# Non-linear Normalizations
# =============================================================================
# Curve shaping and sigmoid transformations


def logistic_shaping(
    raw_complexity: float, midpoint: float = 0.45, steepness: float = 6.0
) -> float:
    """Logistic shaping normalization: reduces score gradually for growing complexity.

    Used to reduce score gradually for growing complexity. This is useful to avoid
    over-penalizing large, well-structured APIs.

    Formula:
        logistic = 1 / (1 + exp(k * (raw_complexity - midpoint)))

    Where:
    - k controls steepness (higher = sharper transition)
    - midpoint controls tolerance (higher = more forgiving)

    This avoids "size penalties" for APIs that are large but well-structured.

    Args:
        raw_complexity: Raw complexity measurement (typically normalized to [0, 1])
        midpoint: Complexity threshold for 50% score (default: 0.45)
        steepness: Steepness of the sigmoid curve (default: 6.0)

    Returns:
        Normalized logistic score in [0, 1]

    Example:
        >>> round(logistic_shaping(0.3), 2)  # Low complexity
        0.71
        >>> round(logistic_shaping(0.6), 2)  # High complexity
        0.29
    """
    try:
        exponent = steepness * (raw_complexity - midpoint)
        return 1.0 / (1.0 + math.exp(exponent))
    except OverflowError:
        # If exp overflows, return appropriate extreme
        return 0.0 if raw_complexity > midpoint else 1.0


def logarithmic_dampening(issue_count: float, threshold: float) -> float:
    """Logarithmic dampening normalization: provides smooth decay for issue penalties.

    Used for structural integrity and similar metrics where early issues should be
    penalized but the score shouldn't collapse immediately. Provides early penalty with
    slower collapse near threshold.

    Formula:
        dampened = max(0, 1 - (log10(1 + issue_count) / log10(1 + threshold)))

    This yields a smooth decay curve that:
    - Penalizes first few issues more noticeably than linear
    - Prevents premature score collapse
    - Still ensures score reaches 0 at threshold

    Defined in JAIRF v0.2.0 specification for structural integrity signal.

    Args:
        issue_count: Number of issues detected
        threshold: Maximum acceptable issue count before score reaches 0

    Returns:
        Normalized logarithmic score in [0, 1]

    Example:
        >>> round(logarithmic_dampening(0, 15), 2)   # No issues
        1.0
        >>> round(logarithmic_dampening(5, 15), 2)   # Few issues
        0.35
        >>> round(logarithmic_dampening(15, 15), 2)  # At threshold
        0.0
    """
    if threshold <= 0:
        raise ValueError("Threshold must be greater than 0")

    if issue_count <= 0:
        return 1.0

    # Compute log10-based dampening
    numerator = math.log10(1 + issue_count)
    denominator = math.log10(1 + threshold)

    score = 1.0 - (numerator / denominator)

    return max(0.0, score)


# =============================================================================
# Protocol Conformance Checks
# =============================================================================
# These type assertions ensure each function correctly implements its Protocol.
# If a function signature changes without updating the Protocol, mypy will catch it.

_identity_check: IdentityNormalizer = identity
_coverage_check: CoverageNormalizer = coverage
_inverse_error_check: InverseErrorNormalizer = inverse_error
_binary_check: BinaryNormalizer = binary
_semantic_similarity_check: SemanticSimilarityNormalizer = semantic_similarity
_severity_weighted_check: SeverityWeightedNormalizer = severity_weighted_inverse
_bonus_multiplier_check: BonusMultiplierNormalizer = bonus_multiplier
_context_scaling_check: ContextScalingNormalizer = context_scaling
_risk_discount_check: RiskDiscountNormalizer = risk_discount
_logistic_shaping_check: LogisticShapingNormalizer = logistic_shaping


# =============================================================================
# Helper Functions (Internal)
# =============================================================================
# These are internal utility functions not exposed in __all__


def clamp(value: float, min_val: float = 0.0, max_val: float = 1.0) -> float:
    """Clamp a value to a specified range.

    Args:
        value: The value to clamp
        min_val: Minimum allowed value (default: 0.0)
        max_val: Maximum allowed value (default: 1.0)

    Returns:
        Value clamped to [min_val, max_val]

    Example:
        >>> clamp(1.5, 0.0, 1.0)
        1.0
        >>> clamp(-0.5, 0.0, 1.0)
        0.0
    """
    return max(min_val, min(max_val, value))


def safe_divide(numerator: float, denominator: float, default: float = 1.0) -> float:
    """Safely divide two numbers, returning default if denominator is zero.

    Args:
        numerator: The numerator
        denominator: The denominator
        default: Value to return if denominator is zero (default: 1.0)

    Returns:
        Result of division, or default if denominator is zero

    Example:
        >>> safe_divide(10, 2)
        5.0
        >>> safe_divide(10, 0, default=1.0)
        1.0
    """
    if denominator == 0:
        return default
    return numerator / denominator
