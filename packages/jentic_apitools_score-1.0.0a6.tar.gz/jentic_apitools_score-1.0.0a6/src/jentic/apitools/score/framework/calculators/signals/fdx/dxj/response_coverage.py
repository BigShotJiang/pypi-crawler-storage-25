"""DXJ Signal: Response Coverage

Measures the percentage of operations that define complete response outcomes.
Uses graded scoring per operation based on response categories present.

Formula:
    response_coverage = sum(operation_response_coverage) / total_operations

Where:
Each operation receives an `operation_response_coverage` from 0.0 to 1.0:
- +0.25 if at least one 2XX response is defined
- +0.25 if at least one 4XX response is defined
- +0.25 if at least one 5XX response is defined
- +0.25 if default response is defined

Special case:
    If total_operations = 0, returns 1.0 (no penalty for no operations)
"""

import logging

from jentic.apitools.analyze.enums import DiagnosticCode

from .....enums import BuiltinSignal, DimensionKind, GroupKind, SpecType
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import CoverageNormalizer, coverage
from ...registry import register_signal


logger = logging.getLogger(__name__)


@register_signal(
    kind=BuiltinSignal.RESPONSE_COVERAGE,
    name="Response Coverage",
    description="Percentage of operations with complete response definitions (success, client error, server error).",
    group=GroupKind.FDX,
    dimension=DimensionKind.DXJ,
    normalizer=coverage,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def response_coverage(ctx: ScoreContext, config: SignalConfig[CoverageNormalizer]) -> Signal:
    """Calculate response coverage signal based on graded response scores.

    Expects ctx.diagnostics to contain:
    - "operation_response_coverage": Per-operation diagnostics with 2XX, 4XX, 5XX, default booleans
      indicating whether each response category is defined
    - "total_operations": Total count of all operations in the spec

    Each operation is scored: 0.25 per response category present (2XX, 4XX, 5XX, default)

    Formula:
        response_coverage = sum(operation_response_coverage) / total_operations

    If total_operations = 0, returns 1.0 (no operations to evaluate).

    Args:
        ctx: Scoring context with spec and metadata
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], sum of scores as raw_value, and breakdown metadata
    """
    total_operations = 0
    response_coverage_sum = 0.0

    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics:
            if diagnostic.code == DiagnosticCode.TOTAL_OPERATIONS and isinstance(
                diagnostic.data, dict
            ):
                total_operations = diagnostic.data.get(DiagnosticCode.TOTAL_OPERATIONS, 0)
            elif diagnostic.code == DiagnosticCode.OPERATION_RESPONSE_COVERAGE and isinstance(
                diagnostic.data, dict
            ):
                # Extract coverage booleans
                has_2XX = diagnostic.data.get("2XX", False)
                has_4XX = diagnostic.data.get("4XX", False)
                has_5XX = diagnostic.data.get("5XX", False)
                has_default = diagnostic.data.get("default", False)

                # Calculate graded score for this operation (0.25 per category present)
                operation_response_coverage = 0.25 * sum([has_2XX, has_4XX, has_5XX, has_default])
                response_coverage_sum += operation_response_coverage

    # Ensure total_operations is an integer
    try:
        total_operations = int(total_operations)
    except (ValueError, TypeError):
        logger.warning(
            "Invalid total_operations value in metadata: %r. Defaulting to 0.",
            total_operations,
        )
        total_operations = 0

    # Normalize using coverage (handles division by zero with default=1.0)
    normalized_value = config.normalizer(
        count_present=response_coverage_sum,
        count_expected=float(total_operations),
    )

    return Signal(
        value=normalized_value,
        raw_value=response_coverage_sum,
        metadata={
            "total_operations": total_operations,
            "response_coverage_sum": response_coverage_sum,
            "provenance": {
                "diagnostics": {
                    "code": [
                        DiagnosticCode.OPERATION_RESPONSE_COVERAGE,
                        DiagnosticCode.TOTAL_OPERATIONS,
                    ]
                }
            },
        },
    )
