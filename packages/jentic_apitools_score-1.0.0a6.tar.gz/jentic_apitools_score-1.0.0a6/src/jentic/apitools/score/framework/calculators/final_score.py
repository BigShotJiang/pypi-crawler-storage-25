"""Final Score Calculator for the Jentic API Scoring Framework.

Calculates the final API quality score using weighted harmonic mean aggregation
of dimension scores extracted from group scores.
"""

from .. import constants
from ..models import DimensionScore, FinalScore, GroupScore, ScoreContext
from ..normalizers import clamp
from .grade import calculate_grade
from .groups import airu, fdx, tsd


__all__ = ["calculate_final_score"]


def calculate_final_score(ctx: ScoreContext) -> FinalScore:
    """Calculate the final API quality score using weighted harmonic mean.

    This is the top-level scoring function that:
    1. Calculates all 3 group scores (FDX, AIRU, TSD)
    2. Extracts all 6 dimension scores from the groups
    3. Applies weighted harmonic mean formula

    Formula:
        FinalScore = (sum of weights) / (sum of (weight / (dimensionScore + epsilon)))
                   = 1.0 / Σ(wi / (di + ε))

    Where:
        - wi = dimension weight
        - di = dimension score (0-100)
        - ε = constants.EPSILON (1e-6, prevents division by zero)

    The weighted harmonic mean penalizes low scores more heavily than arithmetic mean,
    ensuring that weakness in any dimension significantly impacts the final score.

    Args:
        ctx: Scoring context containing the spec document, diagnostics, and metadata

    Returns:
        FinalScore object containing:
        - score: Final score in [0, 100] range
        - group_scores: List of 3 GroupScore objects [FDX, AIRU, TSD]
        - dimension_scores: List of 6 DimensionScore objects extracted from groups

    Example:
        If all dimension scores = 80:
        FinalScore = 1.0 / (0.16/80 + 0.18/80 + 0.24/80 + 0.20/80 + 0.12/80 + 0.10/80)
                   = 1.0 / (1.0/80)
                   = 80.0
    """
    # Step 1: Calculate all group scores
    fdx_group = fdx.calculate_group_score(ctx)
    airu_group = airu.calculate_group_score(ctx)
    tsd_group = tsd.calculate_group_score(ctx)

    group_scores: list[GroupScore] = [fdx_group, airu_group, tsd_group]

    # Step 2: Extract all dimensions from groups
    dimension_scores: list[DimensionScore] = []
    for group in group_scores:
        dimension_scores.extend(group.dimension_scores)

    # Step 3: Calculate weighted harmonic mean
    # Formula: FinalScore = (sum of weights) / (sum of (weight / (score + epsilon)))
    sum_of_weights = sum(d.weight for d in dimension_scores)
    sum_of_ratios = sum(d.weight / (d.score + constants.EPSILON) for d in dimension_scores)

    # Final score calculation
    final_score = sum_of_weights / sum_of_ratios

    # Clamp to [0, 100] to handle floating-point precision issues
    final_score = clamp(final_score, min_val=0.0, max_val=100.0)

    # Return result with all components
    return FinalScore(
        score=final_score,
        grade=calculate_grade(final_score),
        group_scores=group_scores,
        dimension_scores=dimension_scores,
    )
