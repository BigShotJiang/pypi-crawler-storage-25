"""FC Signal: Lint Results

Measures linting quality using severity-weighted inverse normalization.

This signal evaluates the quality of the OpenAPI specification based on linting
diagnostics with severity-weighted scoring. Severity weights are defined in the
DiagnosticSeverityWeight enum (see enums.py).

The weighted cost is calculated and normalized against a threshold of 25.
"""

from lsprotocol.types import DiagnosticSeverity

from .....enums import (
    BuiltinSignal,
    DiagnosticSeverityWeight,
    DimensionKind,
    GroupKind,
    SpecType,
)
from .....models import ScoreContext, Signal, SignalConfig
from .....normalizers import SeverityWeightedNormalizer, severity_weighted_inverse
from ...registry import register_signal


@register_signal(
    kind=BuiltinSignal.LINT_RESULTS,
    name="Lint Results",
    description="Aggregated quality score from linter diagnostics, weighted by severity.",
    group=GroupKind.FDX,
    dimension=DimensionKind.FC,
    normalizer=severity_weighted_inverse,
    bounds=(0.0, 1.0),
    target_specs=[
        (SpecType.OPENAPI, "3.0.*"),
        (SpecType.OPENAPI, "3.1.*"),
        (SpecType.OPENAPI, "3.2.*"),
    ],
)
def lint_results(ctx: ScoreContext, config: SignalConfig[SeverityWeightedNormalizer]) -> Signal:
    """Calculate lint results signal based on diagnostic severity.

    Counts diagnostics by severity level and applies weighted scoring using
    DiagnosticSeverityWeight values.

    Formula:
        weighted_cost = sum(DiagnosticSeverityWeight.{level} * count for each level)
        lint_results = max(0, 1 - (weighted_cost / max_cost))

    Where max_cost = 25 (threshold from framework specification)

    Args:
        ctx: Scoring context with spec and diagnostics
        config: Signal configuration with normalizer, bounds, and target_specs

    Returns:
        Signal with normalized value [0, 1], weighted cost as raw_value, and severity breakdown
    """
    # Initialize severity counts
    severity_counts: dict[str, int] = {
        "critical": 0,
        "error": 0,
        "warning": 0,
        "info": 0,
        "hint": 0,
    }

    # Critical check: spec document failed to parse
    if ctx.spec_document is None:
        severity_counts["critical"] += 1

    # Count diagnostics by severity
    # Note: LSP DiagnosticSeverity doesn't have Critical level by default
    # We map Error -> error, Warning -> warning, Information -> info, Hint -> info
    if isinstance(ctx.diagnostics, list):
        for diagnostic in ctx.diagnostics:
            if diagnostic.severity == DiagnosticSeverity.Error:
                severity_counts["error"] += 1
            elif diagnostic.severity == DiagnosticSeverity.Warning:
                severity_counts["warning"] += 1
            elif diagnostic.severity == DiagnosticSeverity.Information:
                severity_counts["info"] += 1
            elif diagnostic.severity == DiagnosticSeverity.Hint:
                severity_counts["hint"] += 1
            # If there are any other severity values, we could log a warning
            # For now, we'll just ignore unknown severities

    # Calculate weighted cost using framework severity weights
    weighted_cost = (
        DiagnosticSeverityWeight.CRITICAL.value * severity_counts["critical"]
        + DiagnosticSeverityWeight.ERROR.value * severity_counts["error"]
        + DiagnosticSeverityWeight.WARNING.value * severity_counts["warning"]
        + DiagnosticSeverityWeight.INFO.value * severity_counts["info"]
        + DiagnosticSeverityWeight.HINT.value * severity_counts["hint"]
    )

    # Normalize using severity_weighted_inverse with max_cost=25
    max_cost = 25.0
    normalized_value = config.normalizer(
        counts=severity_counts,
        max_cost=max_cost,
        use_sqrt=True,  # sqrt dampening for lint results
    )

    return Signal(
        value=normalized_value,
        raw_value=weighted_cost,
        metadata={
            "severity_counts": severity_counts,
            "weighted_cost": weighted_cost,
            "max_cost": max_cost,
            "provenance": {
                "diagnostics": {
                    "severity": [
                        DiagnosticSeverity.Error,
                        DiagnosticSeverity.Warning,
                        DiagnosticSeverity.Information,
                        DiagnosticSeverity.Hint,
                    ]
                }
            },
        },
    )
