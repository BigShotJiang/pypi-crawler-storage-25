"""Group score calculators for the Jentic API Scoring Framework.

Groups aggregate dimension scores into higher-level quality assessments.
Each group contains 2 dimensions and represents a strategic theme.
"""

from ...models import DimensionScore
from ...normalizers import clamp, safe_divide


__all__ = ["aggregate_dimension_scores"]


def aggregate_dimension_scores(dimensions: list[DimensionScore]) -> float:
    """Aggregate dimension scores into a group score using weighted average.

    Uses dimension weights to calculate a weighted average score. This respects
    the relative importance of dimensions within a group.

    Formula:
        GroupScore = (sum of dimension_score × dimension_weight) / (sum of dimension_weights)

    Args:
        dimensions: List of DimensionScore objects with scores in [0, 100] and weights

    Returns:
        Group score in [0, 100] range. Returns 0.0 if dimensions list is empty.

    Example:
        >>> from jentic_openapi.score.framework.models import DimensionScore
        >>> from jentic_openapi.score.framework.enums import DimensionKind
        >>>
        >>> fc_dim = DimensionScore(
        ...     kind=DimensionKind.FC,
        ...     name="FC",
        ...     score=80.0,
        ...     weight=0.16,
        ...     signals=[]
        ... )
        >>> dxj_dim = DimensionScore(
        ...     kind=DimensionKind.DXJ,
        ...     name="DXJ",
        ...     score=60.0,
        ...     weight=0.18,
        ...     signals=[]
        ... )
        >>> aggregate_dimension_scores([fc_dim, dxj_dim])
        69.41...
    """
    weighted_sum = sum(d.score * d.weight for d in dimensions)
    total_weight = sum(d.weight for d in dimensions)

    # Calculate weighted average (safe_divide handles division by zero)
    score = safe_divide(weighted_sum, total_weight, default=0.0)

    # Clamp to [0, 100] to handle floating-point precision issues
    return clamp(score, min_val=0.0, max_val=100.0)
