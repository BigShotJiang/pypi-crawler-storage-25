"""
AI-readiness scoring for OpenAPI specifications.

This module provides functionality to calculate AI-readiness scores
using the 6-dimension framework (FDX, AIRU, TSD).
"""

from __future__ import annotations

from datetime import datetime, timezone
from pathlib import Path
from typing import List

from jentic.apitools.openapi.validator.core import JenticDiagnostic

from jentic.apitools.common.models import OASRequestMeta, Scorecard
from jentic.apitools.common.utils.logging import get_module_logger
from jentic.apitools.score.framework import ScoreContext, SpecType, __version__, calculate_readiness


__all__ = ["calculate_score"]


logger = get_module_logger(__name__)


def calculate_score(
    *,
    spec_path: Path,
    spec_text: str | None = None,
    spec_content: dict,
    diagnostics: List[JenticDiagnostic],
    vendor: str,
    api_name: str,
    version: str,
    oas_version: str,
    oas_request_meta: OASRequestMeta,
    source_url: str,
    artifacts_root: Path,
    fatalError: bool = False,
    include_diagnostics: bool = True,
) -> Scorecard:
    total_operations = 0
    schema_count = 0
    security_scheme_count = 0
    security_scheme_types = []
    tag_count = 0
    diagnostics_data = []

    for diag in diagnostics:
        # Build diagnostics data for response
        if include_diagnostics:
            diag_dict = {
                "code": diag.code,
                "message": diag.message,
                "severity": diag.severity.value
                if diag.severity and hasattr(diag.severity, "value")
                else str(diag.severity),
                "source": diag.source,
                "data": diag.data if hasattr(diag, "data") else None,
            }
            diagnostics_data.append(diag_dict)

        # Check for operation count
        if diag.code == "total_operations" and hasattr(diag, "data") and diag.data:
            try:
                total_operations = int(diag.data.get("total_operations", 0))
            except (ValueError, TypeError):
                total_operations = 0
        # check for schema count
        if diag.code == "schema_count" and hasattr(diag, "data") and diag.data:
            try:
                schema_count = int(diag.data.get("schema_count", 0))
            except (ValueError, TypeError):
                schema_count = 0
        # check for security scheme count
        if diag.code == "security_scheme_count" and hasattr(diag, "data") and diag.data:
            try:
                security_scheme_count = int(diag.data.get("security_scheme_count", 0))
            except (ValueError, TypeError):
                security_scheme_count = 0
        # check for security scheme types
        if diag.code == "security_scheme_types" and hasattr(diag, "data") and diag.data:
            try:
                security_scheme_types = diag.data.get("security_scheme_types", [])
            except (ValueError, TypeError):
                security_scheme_types = []
        # check for tag count
        if diag.code == "tag_count" and hasattr(diag, "data") and diag.data:
            try:
                tag_count = int(diag.data.get("tag_count", 0))
            except (ValueError, TypeError):
                tag_count = 0

    # Current timestamp for added/updated
    current_timestamp = datetime.now(timezone.utc).replace(microsecond=0).isoformat()

    ctx = ScoreContext(
        spec_uri=spec_path.as_uri(),  # e.g., "file:///path/to/openapi.yaml"
        spec_source=spec_text,  # Raw YAML/JSON string
        spec_document=spec_content,  # Parsed dict/mapping
        spec_type="openapi",  # Optional: spec type
        spec_version=oas_version,  # Optional: detected version
        diagnostics=diagnostics,  # Optional: validation diagnostics
        metadata={"vendor": "acme"},  # Optional: custom metadata
    )
    readiness = calculate_readiness(ctx)

    dimensions = []
    for dimension_score in readiness.final_score.dimension_scores:
        dimension_details = {
            "kind": dimension_score.kind.value,
            "name": dimension_score.name,
            "intention": dimension_score.description,
            "score": round(dimension_score.score, 2),
            "grade": dimension_score.grade.value,
        }
        dimensions.append(dimension_details)

    details = []
    for group_score in readiness.final_score.group_scores:
        details_dimensions = []
        for dimension_score in group_score.dimension_scores:
            signals = []
            for signal in dimension_score.signals:
                signals.append(
                    {
                        "kind": signal.kind,
                        "name": signal.name,
                        "description": signal.description,
                        "score": round(signal.value, 2),
                        "metadata": signal.metadata,
                        # "scoreDeviation": {
                        #    "previous": 50,
                        #    "current": 70,
                        #    "delta": 20
                        # },
                        # "rules": [
                        #    {
                        #        "kind": "jentic",
                        #        "ruleId": "error-formats",
                        #        "description": "Ensures RFC9457 Problem Details are used for errors.",
                        #        "severity": "high",
                        #        "status": "passed",
                        #        "impact": "Improves AI interpretability of error responses."
                        #   }
                        # ],
                        # "findings": [
                        #    {
                        #       "description": "Missing response examples",
                        #        "count": 5,
                        #        "trend": "remaining"
                        #    }
                        # ]
                    }
                )
            dimension_details = {
                "kind": dimension_score.kind,
                "name": dimension_score.name,
                "intention": dimension_score.description,
                "score": round(dimension_score.score, 2),
                "grade": dimension_score.grade.value,
                # "scoreDeviation": {
                #    "previous": 50,
                #    "current": 70,
                #    "delta": 20
                # },
                "signals": signals,
            }
            details_dimensions.append(dimension_details)

        grouping = {
            "kind": group_score.kind.value,
            "name": group_score.name,
            "description": group_score.description,
            "score": round(group_score.score, 2),
            "grade": group_score.grade.value,
            "dimensions": details_dimensions,
        }

        details.append(grouping)

    response = {
        "metadata": {
            "version": version,
            "releaseDate": None,
            "engine": {
                "name": "Jentic API Scoring Framework",
                "version": __version__,
            },
            "disclaimer": "Scores are indicative and opinion biased based on Jentic's view of what is important to deliver APIs which higher levels of interpretability for AI systems.",
        },
        "apiMetadata": {
            "apiId": oas_request_meta.api_id if oas_request_meta.api_id else "",
            "name": api_name,
            "apiDescriptionVersion": version,
            "specification": SpecType.OPENAPI.value,
            "specificationVersion": oas_version,
            "sourceUrl": source_url,
            "vendor": {
                "name": vendor,
                "domain": None,
                "contact": {
                    "name": spec_content.get("info", {}).get("contact", {}).get("name", ""),
                    "email": spec_content.get("info", {}).get("contact", {}).get("email", ""),
                },
            },
            "operationCount": total_operations,
            "schemaCount": schema_count,
            "securitySchemeCount": security_scheme_count,
            "securitySchemeTypes": security_scheme_types,
            "tagCount": tag_count,
        },
        "summary": {
            "scoringDate": current_timestamp,
            "score": round(readiness.final_score.score, 2),
            "level": readiness.maturity.value,
            "grade": readiness.final_score.grade.value,
            # "trend": "improved",
            # "scoreDeviation": {
            #  "previous": 50,
            #  "current": 70,
            #  "delta": 20
            # },
            "dimensions": dimensions,
        },
        "details": details,
    }
    if include_diagnostics:
        response["diagnostics"] = diagnostics_data

    return Scorecard.model_validate(response)
