# Jentic API Tools - Score

AI-readiness scoring framework for OpenAPI specifications using 6 dimensions organized into 3 groups: FDX (Foundational and DX), AIRU (AI-Readiness and Usability), and TSD (Trust, Security and Discoverability).

## Key Features

The scoring framework evaluates specs across six dimensions (FC, DXJ, ARAX, AU, SEC, AID), each fed by multiple signals that measure specific quality aspects like spec validity, example density, description coverage, error standardization, auth strength, and more. Signal values are normalized and aggregated into dimension scores (0-100), group scores, and a final weighted score using a harmonic mean. The final score maps to a letter grade (A+ through F) and a maturity level (non-ready, foundational, ai-aware, ai-ready, agent-optimized).

## Dependencies

Internal: `jentic.apitools.common`, `jentic.apitools.analyze`.

## Installation

```bash
pip install jentic-apitools-score
```

## Quick Start

```python
from pathlib import Path
from jentic.apitools.score.score import calculate_score

score = calculate_score(
    spec_path=Path("spec.json"),
    spec_content={"openapi": "3.1.0", ...},
    diagnostics=diagnostics,
    vendor="example",
    api_name="my-api",
    version="1.0",
    oas_version="3.1.0",
    oas_request_meta=meta,
    source_url="https://example.com/api.json",
    artifacts_root=Path("/tmp"),
)
```

## Testing

```bash
pytest tests -v
```
