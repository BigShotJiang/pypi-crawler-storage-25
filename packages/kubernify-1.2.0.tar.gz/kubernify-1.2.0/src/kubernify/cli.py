"""Kubernify — Kubernetes deployment version verification tool.

Verifies that deployed workloads in a Kubernetes cluster match a given version
manifest.  Checks for:

1. Existence of expected workloads
2. Version consistency
3. Pod stability (Ready, not terminating, restart count)
4. Controller convergence
5. Revision consistency
"""

from __future__ import annotations

import argparse
import json
import logging
import sys
import time
from collections import defaultdict
from dataclasses import asdict
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from .image_parser import parse_image_reference
from .kubernetes_controller import KubernetesController
from .models import (
    DEFAULT_RESTART_THRESHOLD,
    DEFAULT_TIMEOUT_SECONDS,
    RETRY_INTERVAL_SECONDS,
    ComponentMapEntry,
    ComponentMapResult,
    ComponentReport,
    ComponentVerificationResult,
    ContainerType,
    ImageReference,
    PodInfo,
    ReportSummary,
    StabilityAuditResult,
    VerificationReport,
    VerificationResult,
    VerificationStatus,
    VersionVerificationResults,
    WorkloadInspectionResult,
    WorkloadReport,
    filter_active_pods,
)
from .stability_audit import StabilityAuditor
from .workload_discovery import WorkloadDiscovery

logger = logging.getLogger(__name__)


def _setup_logging(verbose: bool = False) -> None:
    """Configure logging for CLI usage. Only called from main().

    Args:
        verbose: When ``True``, set console log level to DEBUG; otherwise INFO.
    """
    log_level = logging.DEBUG if verbose else logging.INFO
    logging.basicConfig(
        level=log_level,
        format="%(asctime)s : kubernify : %(levelname)s :: %(message)s",
    )


def _get_current_namespace() -> str:
    """Read active namespace from kubeconfig or in-cluster service account."""
    import kubernetes.config

    # 1. Try kubeconfig (local dev)
    try:
        _, active_context = kubernetes.config.list_kube_config_contexts()
        if ns := active_context.get("context", {}).get("namespace"):
            return str(ns)
    except Exception:  # noqa: S110
        pass

    # 2. Try in-cluster service account (running in Pod)
    try:
        with open("/var/run/secrets/kubernetes.io/serviceaccount/namespace") as f:
            return f.read().strip()
    except FileNotFoundError:
        pass

    # 3. Fallback
    return "default"


# ---------------------------------------------------------------------------
# Container extraction helpers
# ---------------------------------------------------------------------------


def _containers_from_spec(
    init_containers: list[Any] | None,
    app_containers: list[Any] | None,
    pod_info: PodInfo | None,
) -> list[tuple[str, ContainerType, PodInfo | None]]:
    """Yield ``(image, container_type, pod_info)`` tuples from container lists.

    Consolidates the duplicated init/app iteration that was previously
    repeated for both running pods and zero-replica pod-spec templates.

    Args:
        init_containers: Init containers (may be ``None``).
        app_containers: Application containers (may be ``None``).
        pod_info: Associated pod metadata, or ``None`` for spec-only extraction.

    Returns:
        List of ``(image_string, ContainerType, PodInfo | None)`` tuples.
    """
    results: list[tuple[str, ContainerType, PodInfo | None]] = []
    for container in init_containers or []:
        results.append((container.image, ContainerType.INIT, pod_info))
    for container in app_containers or []:
        results.append((container.image, ContainerType.APP, pod_info))
    return results


def _extract_containers(
    workload: WorkloadInspectionResult,
    ignore_tombstone_pods: bool = False,
) -> list[tuple[str, ContainerType, PodInfo | None]]:
    """Extract container image/type/pod tuples from a workload.

    When running pods exist, their containers are used directly.  When no pods
    exist (zero-replica workloads), the function falls back to the pod spec
    template so that version verification can still be performed.

    Args:
        workload: A Kubernetes workload inspection result containing pods and pod_spec.
        ignore_tombstone_pods: When ``True``, pods in phase ``Failed`` or ``Succeeded``
            (e.g. Evicted, OOMKilled, Completed) are excluded from container extraction
            to prevent stale image versions from polluting the component map.

    Returns:
        List of ``(image_string, container_type, pod_info)`` tuples.
    """
    pods = workload.pods
    if ignore_tombstone_pods and pods:
        pods = filter_active_pods(pods)

    if pods:
        results: list[tuple[str, ContainerType, PodInfo | None]] = []
        for pod in pods:
            pod_info = PodInfo(
                name=pod.metadata.name,
                ip=pod.status.pod_ip,
                node=pod.spec.node_name,
                start_time=str(pod.status.start_time),
                phase=pod.status.phase,
            )
            results.extend(_containers_from_spec(pod.spec.init_containers, pod.spec.containers, pod_info))
        return results

    if pod_spec := workload.pod_spec:
        logger.info(f"Workload '{workload.name}' has 0 pods — using pod spec template for version extraction")
        return _containers_from_spec(pod_spec.init_containers, pod_spec.containers, None)

    return []


# ---------------------------------------------------------------------------
# Component map construction
# ---------------------------------------------------------------------------


def _build_or_update_entry(
    component_map: dict[str, list[ComponentMapEntry]],
    component: str,
    workload_name: str,
    workload_type: str,
    parsed: ImageReference,
    container_type: ContainerType,
    pod_info: PodInfo | None,
) -> None:
    """Insert a new ``ComponentMapEntry`` or append a pod to an existing one.

    Groups entries by ``(workload_name, workload_type, component, version)``
    so that multiple pods running the same container image are collected under
    a single entry.

    Args:
        component_map: Mutable mapping being built up.
        component: Parsed component name (manifest key).
        workload_name: Name of the owning workload.
        workload_type: Kind of the owning workload (e.g. ``Deployment``).
        parsed: Parsed ``ImageReference`` containing component and version.
        container_type: ``ContainerType`` enum value (``INIT`` or ``APP``).
        pod_info: Pod metadata, or ``None`` for zero-replica workloads.
    """
    existing_entry = next(
        (
            entry
            for entry in component_map[component]
            if entry.workload_name == workload_name
            and entry.workload_type == workload_type
            and entry.container_name == parsed.component
            and entry.actual_version == parsed.version
        ),
        None,
    )

    if existing_entry:
        if pod_info:
            existing_entry.pods.append(pod_info)
    else:
        component_map[component].append(
            ComponentMapEntry(
                workload_name=workload_name,
                workload_type=workload_type,
                container_name=parsed.component,
                container_type=container_type,
                actual_version=parsed.version or "latest",
                pods=[pod_info] if pod_info else [],
            )
        )


def _should_skip(skip_patterns: list[str], container_name: str, workload_name: str) -> str | None:
    """Check if a workload/container should be skipped based on skip patterns.

    Matches each pattern against both the container name and the workload name.

    Args:
        skip_patterns: List of substring patterns to match.
        container_name: Kubernetes container name (e.g. ``"backend"``).
        workload_name: Kubernetes workload name.

    Returns:
        The first matching pattern, or ``None`` if nothing matched.
    """
    for pattern in skip_patterns:
        if pattern in container_name or pattern in workload_name:
            return pattern
    return None


def _resolve_component(
    parsed_component: str,
    workload_name: str,
    alias_lookup: dict[str, list[str]],
    manifest: dict[str, str],
) -> str | None:
    """Resolve a parsed image component name to a manifest key.

    Resolution order:

    1. If the parsed component name is directly in the manifest and has no
       alias entry, return it immediately (no alias needed).
    2. If an alias entry exists for the parsed component, pick the best
       candidate:

       a. If only one candidate exists, return it.
       b. If multiple candidates exist, prefer the one whose manifest key
          appears as a substring of the workload name.
       c. If no candidate matches the workload name, fall through to
          step 3.

    3. Fall back to the parsed component name itself if it is in the
       manifest.
    4. Return ``None`` — no match.

    Args:
        parsed_component: Component name extracted from the container image
            (e.g. ``"shared-svc"``).
        workload_name: Kubernetes workload name used for disambiguation
            (e.g. ``"my-app-123-bar-node"``).
        alias_lookup: Reverse alias map built by ``build_reverse_alias_map``.
        manifest: Version manifest for membership checks.

    Returns:
        The resolved manifest key, or ``None`` if no match is found.
    """
    candidates = alias_lookup.get(parsed_component)

    if candidates is None:
        # No alias defined — use the raw parsed component if it's in the manifest
        return parsed_component if parsed_component in manifest else None

    if len(candidates) == 1:
        return candidates[0] if candidates[0] in manifest else None

    # Multiple candidates — disambiguate by workload name
    for candidate in candidates:
        if candidate in workload_name:
            return candidate if candidate in manifest else None

    # No workload-name match — fall back to raw component if it's in the manifest
    if parsed_component in manifest:
        return parsed_component

    return None


def _image_path_segments(image: str) -> list[str]:
    """Split a container image reference into its path segments.

    Mirrors the segment-splitting logic of :func:`parse_image_reference` for
    the limited purpose of detecting whether a repository anchor appears
    anywhere in the image path. Strips any ``@``-suffix and the trailing tag,
    then drops the registry host segment if one is present. The function does
    not normalize Docker Hub aliases — anchor detection on Docker Hub images
    is not a use case we currently care about for logging purposes.

    Args:
        image: Raw container image reference (e.g.
            ``"registry.example.com/org/my-app/backend:v1.2.3"``).

    Returns:
        List of path segments excluding the registry host and tag. Returns an
        empty list if the input is empty/whitespace-only.
    """
    if not image or not image.strip():
        return []

    working = image.strip()
    if "@" in working:
        working = working[: working.index("@")]

    segments = working.split("/")
    last_segment = segments[-1]
    if ":" in last_segment:
        name_part, _ = last_segment.rsplit(":", 1)
        segments[-1] = name_part

    # Drop registry host (first segment containing '.' or ':')
    if len(segments) > 1 and ("." in segments[0] or ":" in segments[0]):
        segments = segments[1:]

    return segments


def _format_manifest_keys(manifest: dict[str, str]) -> str:
    """Render manifest keys as a deterministic, comma-separated string.

    Args:
        manifest: Version manifest mapping component names to expected versions.

    Returns:
        Sorted, comma-separated list of manifest keys (e.g. ``"backend, frontend"``).
    """
    return ", ".join(sorted(manifest.keys()))


def construct_component_map(
    workloads: list[WorkloadInspectionResult],
    manifest: dict[str, str],
    repository_anchor: str,
    skip_containers: list[str] | None = None,
    reverse_aliases: dict[str, list[str]] | None = None,
    ignore_tombstone_pods: bool = False,
) -> ComponentMapResult:
    """Construct a map of components to their found workloads and versions.

    Always extracts containers from both running pods and zero-replica pod spec
    templates so that all manifest components can be verified.

    When multiple manifest keys alias to the same container image name, the
    workload name is used to disambiguate: the manifest key that appears as a
    substring of the workload name wins.

    Per-workload bucket precedence (each workload ends up in exactly one
    bucket of the returned :class:`ComponentMapResult`):

    ``included > container_skipped > unparseable > not_in_manifest``

    A workload is ``included`` if it contributed at least one entry to
    ``component_map``. Otherwise the strictest matching exclusion bucket
    wins.

    Args:
        workloads: Discovered Kubernetes workload objects.
        manifest: Version manifest mapping component names to expected versions.
        repository_anchor: Repository name used as the anchor for image parsing.
        skip_containers: Optional list of patterns; workloads whose container name
            or workload name matches any pattern are excluded from the map entirely.
        reverse_aliases: Optional mapping from image names to **lists** of manifest
            component names (e.g. ``{"shared-svc": ["foo", "bar"]}``).
            Built by ``build_reverse_alias_map()``.
        ignore_tombstone_pods: When ``True``, evicted/failed pods (phase ``Failed``
            or ``Succeeded``) are excluded from container extraction to prevent
            stale image versions from polluting the component map.

    Returns:
        A :class:`ComponentMapResult` containing the component map and three
        mutually exclusive sets of workload names that were excluded from
        the map (container-skipped, unparseable image, not in manifest).
    """
    component_map: dict[str, list[ComponentMapEntry]] = defaultdict(list)
    skip_patterns = skip_containers or []
    alias_lookup = reverse_aliases or {}
    manifest_keys = _format_manifest_keys(manifest)
    not_in_manifest_logged: set[tuple[str, str]] = set()
    container_skipped_logged: set[tuple[str, str]] = set()
    unparseable_logged: set[tuple[str, str]] = set()

    has_included: dict[str, bool] = defaultdict(bool)
    has_container_skipped: dict[str, bool] = defaultdict(bool)
    has_unparseable: dict[str, bool] = defaultdict(bool)
    has_not_in_manifest: dict[str, bool] = defaultdict(bool)

    pending_container_skipped_logs: dict[str, list[tuple[str, str, str, str]]] = defaultdict(list)
    pending_unparseable_logs: dict[str, list[tuple[str, str, str]]] = defaultdict(list)

    for workload in workloads:
        for image, container_type, pod_info in _extract_containers(
            workload=workload, ignore_tombstone_pods=ignore_tombstone_pods
        ):
            try:
                parsed = parse_image_reference(image=image, repository_anchor=repository_anchor)
            except ValueError as exc:
                has_unparseable[workload.name] = True
                pending_unparseable_logs[workload.name].append((workload.name, image, str(exc)))
                continue

            # Apply alias resolution: remap image name → manifest component name
            resolved_component = _resolve_component(
                parsed_component=parsed.component,
                workload_name=workload.name,
                alias_lookup=alias_lookup,
                manifest=manifest,
            )

            if resolved_component is None:
                has_not_in_manifest[workload.name] = True
                dedupe_key = (workload.name, image)
                if dedupe_key not in not_in_manifest_logged:
                    not_in_manifest_logged.add(dedupe_key)
                    anchor_present = repository_anchor in _image_path_segments(image)
                    if anchor_present:
                        logger.debug(
                            f"Ignoring workload '{workload.name}' parsed component "
                            f"'{parsed.component}' is not in manifest [{manifest_keys}]"
                        )
                    else:
                        logger.debug(
                            f"Ignoring workload '{workload.name}' anchor "
                            f"'{repository_anchor}' not found in image path, "
                            f"fallback component '{parsed.component}' is not in manifest [{manifest_keys}]"
                        )
                continue

            matched_pattern = _should_skip(
                skip_patterns=skip_patterns, container_name=resolved_component, workload_name=workload.name
            )
            if matched_pattern:
                has_container_skipped[workload.name] = True
                pending_container_skipped_logs[workload.name].append(
                    (workload.name, image, matched_pattern, resolved_component)
                )
                continue

            has_included[workload.name] = True
            _build_or_update_entry(
                component_map=component_map,
                component=resolved_component,
                workload_name=workload.name,
                workload_type=workload.type,
                parsed=parsed,
                container_type=container_type,
                pod_info=pod_info,
            )

    container_skipped_workloads: set[str] = set()
    unparseable_image_workloads: set[str] = set()
    not_in_manifest_workloads: set[str] = set()
    workload_names = set(has_included) | set(has_container_skipped) | set(has_unparseable) | set(has_not_in_manifest)
    for name in workload_names:
        if has_included[name]:
            continue
        if has_container_skipped[name]:
            container_skipped_workloads.add(name)
        elif has_unparseable[name]:
            unparseable_image_workloads.add(name)
        elif has_not_in_manifest[name]:
            not_in_manifest_workloads.add(name)

    for name in container_skipped_workloads:
        for workload_name, image, pattern, container_name in pending_container_skipped_logs[name]:
            dedupe_key = (workload_name, image)
            if dedupe_key in container_skipped_logged:
                continue
            container_skipped_logged.add(dedupe_key)
            logger.debug(
                f"Container-skipping workload '{workload_name}' container image "
                f"'{image}': matched skip pattern '{pattern}' on container '{container_name}'"
            )
    for name in unparseable_image_workloads:
        for workload_name, image, error_message in pending_unparseable_logs[name]:
            dedupe_key = (workload_name, image)
            if dedupe_key in unparseable_logged:
                continue
            unparseable_logged.add(dedupe_key)
            logger.debug(f"Could not parse container image '{image}' for workload '{workload_name}': {error_message}")

    return ComponentMapResult(
        component_map=dict(component_map),
        container_skipped_workloads=container_skipped_workloads,
        unparseable_image_workloads=unparseable_image_workloads,
        not_in_manifest_workloads=not_in_manifest_workloads,
    )


def _log_discovery_summary(
    discovered_workloads: list[WorkloadInspectionResult],
    skipped_workload_names: list[str],
    component_map: dict[str, list[ComponentMapEntry]],
    container_skipped_workloads: set[str],
    unparseable_image_workloads: set[str],
    not_in_manifest_workloads: set[str],
) -> None:
    """Log discovery summary with five mutually exclusive workload buckets.

    Args:
        discovered_workloads: Workloads returned by ``discover_cluster_state``.
        skipped_workload_names: Workload names skipped by ``--skip-containers``.
        component_map: Component map produced by ``construct_component_map``.
        container_skipped_workloads: Workloads filtered by ``--skip-containers``.
        unparseable_image_workloads: Workloads with unparseable images.
        not_in_manifest_workloads: Workloads with no manifest match.
    """
    inspected = len(discovered_workloads)
    skipped = len(skipped_workload_names)
    included_workloads: set[str] = {entry.workload_name for entries in component_map.values() for entry in entries}
    included = len(included_workloads)
    container_skipped = len(container_skipped_workloads)
    unparseable = len(unparseable_image_workloads)
    not_in_manifest = len(not_in_manifest_workloads)

    logger.info(
        f"Discovery summary: {included} included, "
        f"{skipped} skipped (--skip-containers workload-name match), "
        f"{container_skipped} container-skipped (--skip-containers container-name match), "
        f"{unparseable} unparseable images, "
        f"{not_in_manifest} not in manifest, "
        f"{inspected} inspected"
    )

    bucket_sum = included + container_skipped + unparseable + not_in_manifest
    if bucket_sum != inspected:
        logger.warning(
            f"Discovery summary bucket invariant violated: included ({included}) + "
            f"container_skipped ({container_skipped}) + unparseable ({unparseable}) + "
            f"not_in_manifest ({not_in_manifest}) = {bucket_sum}, expected {inspected} (inspected). "
            f"This indicates a bucketing bug."
        )


# ---------------------------------------------------------------------------
# Validation helpers
# ---------------------------------------------------------------------------


def validate_manifest(manifest: dict[str, str], component_map: dict[str, list[ComponentMapEntry]]) -> list[str]:
    """Validate that all components in the manifest exist in the cluster.

    Args:
        manifest: Version manifest mapping component names to expected versions.
        component_map: Discovered component map from ``construct_component_map``.

    Returns:
        List of error messages for missing components.
    """
    return [f"Component '{c}' not found in cluster" for c in manifest if c not in component_map]


def verify_required_workloads(
    required_workloads: list[str],
    discovered_workloads: list[WorkloadInspectionResult],
) -> list[str]:
    """Verify that specific workloads exist in the discovered workloads.

    Uses partial matching — checks if the required workload name is contained
    in any discovered workload name.  For example, ``'frontend'`` will match
    ``'my-app-frontend'``.

    Args:
        required_workloads: List of required workload name patterns.
        discovered_workloads: List of discovered workload inspection results.

    Returns:
        List of error messages for missing required workloads.
    """
    found_names = {w.name for w in discovered_workloads}
    return [
        f"Required workload '{required}' not found"
        for required in required_workloads
        if not any(required in name for name in found_names)
    ]


# ---------------------------------------------------------------------------
# Version verification
# ---------------------------------------------------------------------------


def _verify_component_entry(
    entry: ComponentMapEntry,
    expected_version: str,
    allow_zero_replicas: bool,
    allow_zero_replicas_for: frozenset[str] = frozenset(),
) -> VerificationResult:
    """Verify a single workload entry against expected version and replica count.

    Note: skip-pattern filtering is already performed in ``construct_component_map``,
    so entries reaching this function are guaranteed to not match any skip pattern.

    Uses **substring matching** for ``allow_zero_replicas_for``: a workload is
    exempted when any pattern in the set is contained in the workload name.
    This is consistent with ``--skip-containers`` and ``--required-workloads``.

    Args:
        entry: Workload entry containing container and version information.
        expected_version: Expected version string.
        allow_zero_replicas: When ``True``, do not fail workloads with 0 running pods.
        allow_zero_replicas_for: Patterns selectively allowing workloads to have 0
            replicas.  Matched as substrings against the workload name.

    Returns:
        ``VerificationResult`` containing verification status.
    """
    if not entry.pods:
        workload_is_exempted = allow_zero_replicas or any(
            pattern in entry.workload_name for pattern in allow_zero_replicas_for
        )
        if not workload_is_exempted:
            return VerificationResult(
                workload=entry.workload_name,
                type=entry.workload_type,
                container=entry.container_name,
                status=VerificationStatus.FAIL,
                error=f"Workload has 0 running pods (version from pod spec: {entry.actual_version})",
            )

    if entry.actual_version != expected_version:
        return VerificationResult(
            workload=entry.workload_name,
            type=entry.workload_type,
            container=entry.container_name,
            status=VerificationStatus.FAIL,
            error=f"Version mismatch: expected {expected_version}, found {entry.actual_version}",
        )

    return VerificationResult(
        workload=entry.workload_name,
        type=entry.workload_type,
        container=entry.container_name,
        status=VerificationStatus.PASS,
    )


def verify_versions(
    manifest: dict[str, str],
    component_map: dict[str, list[ComponentMapEntry]],
    allow_zero_replicas: bool = False,
    allow_zero_replicas_for: list[str] | None = None,
) -> VersionVerificationResults:
    """Verify versions for all components.

    Args:
        manifest: Dict mapping component names to expected version strings.
        component_map: Dict mapping component names to their discovered workloads.
        allow_zero_replicas: When ``True``, do not fail workloads with 0 running pods.
        allow_zero_replicas_for: Optional list of workload name patterns selectively
            allowed to have 0 replicas.  Matched as substrings against workload names.

    Returns:
        A ``VersionVerificationResults`` instance with per-component details.
    """
    _exempted_patterns: frozenset[str] = frozenset(allow_zero_replicas_for or ())
    results = VersionVerificationResults()

    for component, expected_version in manifest.items():
        comp_result = ComponentVerificationResult()

        if component not in component_map:
            msg = f"Component '{component}' not found"
            comp_result.status = VerificationStatus.FAIL.value
            comp_result.errors.append(msg)
            results.errors.append(msg)
            results.components[component] = comp_result
            continue

        for entry in component_map[component]:
            entry_status = _verify_component_entry(
                entry=entry,
                expected_version=expected_version,
                allow_zero_replicas=allow_zero_replicas,
                allow_zero_replicas_for=_exempted_patterns,
            )
            comp_result.workloads.append(entry_status)
            if entry_status.status == VerificationStatus.FAIL:
                comp_result.status = VerificationStatus.FAIL.value
                comp_result.errors.append(f"{entry.workload_name}: {entry_status.error}")
                results.errors.append(f"[{component}] {entry.workload_name}: {entry_status.error}")

        results.components[component] = comp_result

    return results


def load_manifest(manifest: str) -> dict[str, str]:
    """Parse a JSON string manifest into a dict.

    Args:
        manifest: JSON string containing the version manifest.

    Returns:
        Parsed dict mapping component names to expected versions.

    Raises:
        ValueError: If the manifest is empty or not valid JSON.
    """
    if not manifest:
        raise ValueError("Manifest JSON string must not be empty")
    try:
        data = json.loads(manifest)
        if not isinstance(data, dict):
            raise ValueError("Manifest must be a JSON object")
        return {str(k): str(v) for k, v in data.items()}
    except json.JSONDecodeError as exc:
        raise ValueError(f"Manifest is not valid JSON: {manifest}") from exc


def load_component_aliases(raw: str | None) -> dict[str, str]:
    """Parse a JSON string of component aliases into a dict.

    Args:
        raw: JSON string mapping manifest component names to image names,
            or ``None`` if no aliases are provided.

    Returns:
        Parsed dict mapping manifest keys to image names, or empty dict.

    Raises:
        ValueError: If the string is not valid JSON or not a JSON object.
    """
    if not raw:
        return {}
    try:
        data = json.loads(raw)
        if not isinstance(data, dict):
            raise ValueError("Component aliases must be a JSON object")
        return {str(k): str(v) for k, v in data.items()}
    except json.JSONDecodeError as exc:
        raise ValueError(f"Component aliases is not valid JSON: {raw}") from exc


def build_reverse_alias_map(
    aliases: dict[str, str],
    manifest: dict[str, str],
) -> dict[str, list[str]]:
    """Build a reverse lookup from image names to manifest component names.

    Supports many-to-one mappings where multiple manifest keys alias to the
    same container image name.  When this happens, the caller must
    disambiguate using the workload name (see ``construct_component_map``).

    Args:
        aliases: Mapping of manifest component names to image names
            (e.g. ``{"foo": "bar-baz"}``).
        manifest: The version manifest for validation.

    Returns:
        Mapping from image names to **lists** of manifest keys
        (e.g. ``{"bar-baz": ["foo"]}``).  When multiple manifest keys
        share the same image name the list will contain all of them
        (e.g. ``{"shared-svc": ["foo", "bar"]}``).
    """
    reverse: dict[str, list[str]] = {}
    for manifest_key, image_name in aliases.items():
        if manifest_key not in manifest:
            logger.warning(
                f"Component alias key '{manifest_key}' is not present in the manifest — this alias will have no effect"
            )
        reverse.setdefault(image_name, []).append(manifest_key)
    return reverse


# ---------------------------------------------------------------------------
# Report generation
# ---------------------------------------------------------------------------


def generate_report(
    overall_status: VerificationStatus,
    verification_results: VersionVerificationResults,
    stability_results: dict[str, StabilityAuditResult],
    missing_components: list[str],
    missing_workloads: list[str],
    context: str,
    namespace: str,
    skipped_workload_names: list[str] | None = None,
) -> VerificationReport:
    """Generate the final verification report.

    Args:
        overall_status: Overall verification status (PASS / FAIL).
        verification_results: Structured results produced by ``verify_versions``.
        stability_results: Mapping of workload keys to their stability audit results.
        missing_components: List of component-level error messages.
        missing_workloads: List of workload-level error messages.
        context: Kubeconfig context name or identifier.
        namespace: Kubernetes namespace that was inspected.
        skipped_workload_names: Names of workloads skipped during discovery.

    Returns:
        A fully populated ``VerificationReport`` instance.
    """
    summary = ReportSummary(
        total_components=len(verification_results.components),
        missing_components=len(missing_components),
        missing_workloads=len(missing_workloads),
        skipped_containers=len(skipped_workload_names) if skipped_workload_names else 0,
    )

    report = VerificationReport(
        timestamp=datetime.now(timezone.utc).isoformat(),
        context=context,
        namespace=namespace,
        status=overall_status,
        summary=summary,
    )

    for component, comp_result in verification_results.components.items():
        if comp_result.status == VerificationStatus.FAIL.value:
            summary.version_mismatched_components += 1

        comp_report = ComponentReport(
            status=comp_result.status,
            errors=list(comp_result.errors),
        )

        component_has_stability_errors = False

        for w_entry in comp_result.workloads:
            w_key = f"{w_entry.type}/{w_entry.workload}"
            is_skipped = w_entry.status == VerificationStatus.SKIPPED

            if is_skipped:
                summary.skipped_containers += 1
                continue

            stability_entry = stability_results.get(w_key)
            stability_dict = asdict(stability_entry) if stability_entry else {}

            w_report = WorkloadReport(
                name=w_entry.workload,
                type=w_entry.type,
                container=w_entry.container,
                version_error=w_entry.error,
                stability=stability_dict,
            )

            has_stability_errors = bool(stability_dict.get("errors"))
            has_version_failure = w_entry.status == VerificationStatus.FAIL

            if has_stability_errors:
                summary.unstable_workloads += 1
                component_has_stability_errors = True
                for err in stability_dict.get("errors", []):
                    comp_report.errors.append(f"{w_entry.workload}: {err}")

            # Only include workloads with failures (version or stability)
            if has_version_failure or has_stability_errors:
                comp_report.workloads.append(w_report)

        if component_has_stability_errors:
            comp_report.status = VerificationStatus.FAIL.value

        report.details[component] = comp_report

    summary.failed_components = sum(
        1
        for v in report.details.values()
        if isinstance(v, ComponentReport) and v.status == VerificationStatus.FAIL.value
    )

    summary.passing_components = sum(
        1
        for v in report.details.values()
        if isinstance(v, ComponentReport) and v.status == VerificationStatus.PASS.value
    )

    if missing_components:
        report.details["_missing_components"] = missing_components
    if missing_workloads:
        report.details["_missing_workloads"] = missing_workloads

    return report


# ---------------------------------------------------------------------------
# CLI argument parsing
# ---------------------------------------------------------------------------


def parse_args(args: list[str] | None = None) -> argparse.Namespace:
    """Parse command line arguments.

    Args:
        args: Optional list of argument strings (defaults to ``sys.argv``).

    Returns:
        Parsed ``argparse.Namespace``.
    """
    parser = argparse.ArgumentParser(
        description="Kubernify — Verify Kubernetes deployments match a version manifest",
        formatter_class=argparse.ArgumentDefaultsHelpFormatter,
    )

    context_group = parser.add_mutually_exclusive_group()
    context_group.add_argument(
        "--context",
        help="Kubeconfig context name to use for cluster connection",
    )
    context_group.add_argument(
        "--gke-project",
        help="GCP project ID — resolves the kube context from GKE-style context names",
    )

    parser.add_argument(
        "--manifest",
        required=True,
        help='JSON string containing the version manifest (e.g. \'{"backend": "v1.2.3"}\')',
    )
    parser.add_argument(
        "--component-aliases",
        default=None,
        help=(
            "JSON string mapping manifest component names to their actual image names "
            'when they differ. Example: \'{"foo": "bar-baz"}\' means the '
            "manifest key 'foo' corresponds to the container image named 'bar-baz'."
        ),
    )
    parser.add_argument(
        "--namespace",
        default=_get_current_namespace(),
        help="Kubernetes namespace (default: from kubeconfig or 'default')",
    )
    parser.add_argument(
        "--required-workloads",
        help="Comma-separated list of workload names that MUST exist (e.g., 'frontend, api')",
    )
    parser.add_argument(
        "--skip-containers",
        help=(
            "Comma-separated list of patterns to skip verification for; "
            "matched against both container names and workload names"
        ),
    )
    parser.add_argument("--min-uptime", type=int, default=0, help="Minimum pod uptime in seconds")
    parser.add_argument(
        "--restart-threshold",
        type=int,
        default=DEFAULT_RESTART_THRESHOLD,
        help=(
            "Maximum acceptable restart count per container. "
            "Use 0 to forbid any restarts, or -1 to skip the restart check entirely"
        ),
    )
    parser.add_argument("--timeout", type=int, default=DEFAULT_TIMEOUT_SECONDS, help="Global timeout in seconds")
    zero_replica_group = parser.add_mutually_exclusive_group()
    zero_replica_group.add_argument(
        "--allow-zero-replicas",
        action="store_true",
        help="Allow workloads with 0 replicas to pass verification without flagging as a failure",
    )
    zero_replica_group.add_argument(
        "--allow-zero-replicas-for",
        default=None,
        help=(
            "Comma-separated list of workload name patterns allowed to have 0 replicas. "
            "Uses substring matching: e.g. 'my-worker' matches "
            "'ns-123-my-worker' "
            "(mutually exclusive with --allow-zero-replicas)"
        ),
    )
    parser.add_argument(
        "--dry-run",
        action="store_true",
        help="Validate manifest against current cluster state without waiting",
    )
    parser.add_argument(
        "--anchor",
        required=True,
        help=(
            "The image path segment used as the anchor point for component name extraction. "
            "Example: for image 'registry.example.com/my-org/my-app/backend:v1.0', "
            "using --anchor my-app extracts component name 'backend'."
        ),
    )
    parser.add_argument(
        "--include-statefulsets",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Include StatefulSets",
    )
    parser.add_argument(
        "--include-daemonsets",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Include DaemonSets",
    )
    parser.add_argument(
        "--include-jobs",
        action=argparse.BooleanOptionalAction,
        default=False,
        help="Include Jobs and CronJobs",
    )
    parser.add_argument(
        "--ignore-tombstone-pods",
        action="store_true",
        default=False,
        help=(
            "When set, pods in phase Failed or Succeeded (OOMKilled, Evicted, Completed) "
            "are excluded from per-pod health checks. "
            "The deployment availability check (available_replicas >= spec.replicas) "
            "always runs regardless of this flag."
        ),
    )
    parser.add_argument(
        "--output-file",
        default=None,
        help="Path to save the JSON verification report to a file (report is always printed to stdout)",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Enable verbose output (DEBUG level logging to console)",
    )
    return parser.parse_args(args)


# ---------------------------------------------------------------------------
# Stability audit orchestration
# ---------------------------------------------------------------------------


def _parse_comma_list(raw: str | None) -> list[str]:
    """Parse a comma-separated string into a stripped list, or return empty list.

    Args:
        raw: Raw comma-separated string, or ``None``.

    Returns:
        List of stripped, non-empty strings.
    """
    if not raw:
        return []
    return [item.strip() for item in raw.split(",") if item.strip()]


def _perform_stability_audit(
    auditor: StabilityAuditor,
    component_map: dict[str, list[ComponentMapEntry]],
    discovered_items: list[WorkloadInspectionResult],
    discovered_map: dict[str, WorkloadInspectionResult],
    required_workloads: list[str],
    skip_containers: list[str],
    restart_threshold: int,
    min_uptime: int,
    ignore_tombstone_pods: bool = False,
) -> tuple[dict[str, StabilityAuditResult], bool]:
    """Perform stability audit on relevant workloads.

    Args:
        auditor: ``StabilityAuditor`` instance.
        component_map: Map of components to their workloads.
        discovered_items: List of discovered workload items.
        discovered_map: Map of workload keys to inspection results.
        required_workloads: List of required workload names.
        skip_containers: List of container name patterns to skip.
        restart_threshold: Maximum acceptable restart count per container.
            Use ``0`` to forbid any restarts, or ``-1`` to skip the restart check entirely.
        min_uptime: Minimum pod uptime in seconds.
        ignore_tombstone_pods: When ``True``, pods in phase Failed or Succeeded are
            excluded from per-pod health checks before calling ``audit_workload``.

    Returns:
        Tuple of ``(stability_results, all_stable)`` where ``stability_results``
        maps workload keys to ``StabilityAuditResult`` and ``all_stable`` is
        ``True`` when every audited workload has zero errors.
    """
    stability_results: dict[str, StabilityAuditResult] = {}
    all_stable = True
    workloads_to_audit: set[str] = set()
    workloads_to_skip: set[str] = set()

    # Build sets from component map entries
    for comp_entries in component_map.values():
        for entry in comp_entries:
            w_key = f"{entry.workload_type}/{entry.workload_name}"
            if _should_skip(
                skip_patterns=skip_containers,
                container_name=entry.container_name,
                workload_name=entry.workload_name,
            ):
                workloads_to_skip.add(w_key)
            else:
                workloads_to_audit.add(w_key)

    # Add required workloads that match discovered items
    for item in discovered_items:
        w_key = f"{item.type}/{item.name}"
        if _should_skip(skip_patterns=skip_containers, container_name="", workload_name=item.name):
            workloads_to_skip.add(w_key)
            continue
        for required in required_workloads:
            if required in item.name and w_key not in workloads_to_skip:
                workloads_to_audit.add(w_key)
                break

    for w_key in workloads_to_audit:
        if w_key not in discovered_map:
            continue
        audit_res = auditor.audit_workload(
            workload_info=discovered_map[w_key],
            restart_threshold=restart_threshold,
            min_uptime_sec=min_uptime,
            ignore_tombstone_pods=ignore_tombstone_pods,
        )
        stability_results[w_key] = audit_res
        if audit_res.errors:
            all_stable = False

    return stability_results, all_stable


# ---------------------------------------------------------------------------
# Main execution
# ---------------------------------------------------------------------------


def run_verification(args: argparse.Namespace) -> int:
    """Main execution flow.

    Args:
        args: Parsed CLI arguments.

    Returns:
        Process exit code (0 = PASS, 1 = FAIL).
    """
    start_time = time.time()

    try:
        manifest = load_manifest(manifest=args.manifest)

        component_aliases = load_component_aliases(args.component_aliases)
        reverse_aliases = build_reverse_alias_map(aliases=component_aliases, manifest=manifest)
        if component_aliases:
            logger.info(f"Component aliases: {component_aliases}")

        required_workloads = _parse_comma_list(args.required_workloads)
        if required_workloads:
            logger.info(f"Required workloads: {required_workloads}")

        skip_containers = _parse_comma_list(args.skip_containers)
        if skip_containers:
            logger.info(f"Skipping verification for patterns (container/workload name): {skip_containers}")

        allow_zero_replicas_for = _parse_comma_list(args.allow_zero_replicas_for)
        if allow_zero_replicas_for:
            logger.info(f"Allowing zero replicas for workloads: {allow_zero_replicas_for}")

        k8s_controller = KubernetesController(
            context=args.context,
            gke_project=args.gke_project,
        )
        discovery = WorkloadDiscovery(
            k8s_controller=k8s_controller,
            include_statefulsets=args.include_statefulsets,
            include_daemonsets=args.include_daemonsets,
            include_jobs=args.include_jobs,
        )
        auditor = StabilityAuditor(k8s_controller=k8s_controller)
    except Exception as e:
        logger.error(f"Initialization failed: {e}")
        return 1

    overall_status = VerificationStatus.PASS
    verification_results = VersionVerificationResults()
    stability_results: dict[str, StabilityAuditResult] = {}
    missing_components: list[str] = []
    missing_workloads: list[str] = []
    skipped_workload_names: list[str] = []

    report_context = args.context or args.gke_project or "in-cluster"

    while True:
        if time.time() - start_time > args.timeout:
            logger.error("Global timeout reached")
            overall_status = VerificationStatus.FAIL
            break

        logger.info("Discovering cluster state...")
        try:
            discovered_items, skipped_workload_names = discovery.discover_cluster_state(
                namespace=args.namespace,
                skip_patterns=skip_containers,
            )
            discovered_map = {f"{item.type}/{item.name}": item for item in discovered_items}
            component_map_result = construct_component_map(
                workloads=discovered_items,
                manifest=manifest,
                repository_anchor=args.anchor,
                skip_containers=skip_containers,
                reverse_aliases=reverse_aliases,
                ignore_tombstone_pods=args.ignore_tombstone_pods,
            )
            component_map = component_map_result.component_map
            _log_discovery_summary(
                discovered_workloads=discovered_items,
                skipped_workload_names=skipped_workload_names,
                component_map=component_map,
                container_skipped_workloads=component_map_result.container_skipped_workloads,
                unparseable_image_workloads=component_map_result.unparseable_image_workloads,
                not_in_manifest_workloads=component_map_result.not_in_manifest_workloads,
            )
        except Exception as e:
            logger.error(f"Discovery failed: {e}")
            if args.dry_run:
                return 1
            time.sleep(RETRY_INTERVAL_SECONDS)
            continue

        missing_components = validate_manifest(manifest=manifest, component_map=component_map)
        missing_workloads = verify_required_workloads(
            required_workloads=required_workloads,
            discovered_workloads=discovered_items,
        )
        verification_results = verify_versions(
            manifest=manifest,
            component_map=component_map,
            allow_zero_replicas=args.allow_zero_replicas,
            allow_zero_replicas_for=allow_zero_replicas_for,
        )

        stability_results, all_stable = _perform_stability_audit(
            auditor=auditor,
            component_map=component_map,
            discovered_items=discovered_items,
            discovered_map=discovered_map,
            required_workloads=required_workloads,
            skip_containers=skip_containers,
            restart_threshold=args.restart_threshold,
            min_uptime=args.min_uptime,
            ignore_tombstone_pods=args.ignore_tombstone_pods,
        )

        has_errors = bool(verification_results.errors) or bool(missing_components) or bool(missing_workloads)

        if args.dry_run:
            if has_errors or not all_stable:
                overall_status = VerificationStatus.FAIL
            break

        if not has_errors and all_stable:
            logger.info("Verification and stability checks passed!")
            overall_status = VerificationStatus.PASS
            break

        logger.info("Waiting for convergence/stability...")
        time.sleep(RETRY_INTERVAL_SECONDS)

    try:
        report = generate_report(
            overall_status=overall_status,
            verification_results=verification_results,
            stability_results=stability_results,
            missing_components=missing_components,
            missing_workloads=missing_workloads,
            context=report_context,
            namespace=args.namespace,
            skipped_workload_names=skipped_workload_names,
        )
        report_json = json.dumps(report.to_dict(), indent=2)
        print(report_json)

        if args.output_file:
            output_path = Path(args.output_file)
            output_path.parent.mkdir(parents=True, exist_ok=True)
            output_path.write_text(report_json + "\n", encoding="utf-8")
            logger.info(f"Report saved to {output_path}")
    except Exception as e:
        logger.error(f"Failed to generate report: {e}")
        return 1

    return overall_status.exit_code


def main() -> None:
    """CLI entry point for kubernify."""
    parsed_args = parse_args()
    _setup_logging(verbose=parsed_args.verbose)
    try:
        sys.exit(run_verification(args=parsed_args))
    except Exception as e:
        print(f"Error: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
