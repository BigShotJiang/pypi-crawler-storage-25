from datetime import datetime, timezone
from zoneinfo import ZoneInfo

from bollhav.model.runtime import _apply_to_model
from bollhav.model.batch import Batch, ChunkMode, IntervalChunks, RowChunks
from bollhav.model.bounds import Bounds
from bollhav.model.model import Model
from bollhav.model.target import Target
from bollhav.model.target_schema import TargetSchema


CET = ZoneInfo("Europe/Stockholm")
UTC = timezone.utc


def _apply(
    model: Model,
    *,
    schema_suffix: str = "dev",
    latest: bool = False,
    backfill_since: datetime | None = None,
    backfill_until: datetime | None = None,
    interval_expression_override: str | None = None,
    window_expression_override: str | None = None,
    tz_override=None,
) -> Model:
    return _apply_to_model(
        model,
        schema_suffix=schema_suffix,
        latest=latest,
        backfill_since=backfill_since,
        backfill_until=backfill_until,
        interval_expression_override=interval_expression_override,
        window_expression_override=window_expression_override,
        tz_override=tz_override,
    )


def _model(**batch_kwargs) -> Model:
    iv = {"expression": "@hourly", "tz": UTC}
    iv.update(batch_kwargs)
    return Model(
        target=Target(
            name="orders", schema=TargetSchema(name="public", suffix_appendix=None)
        ),
        batching=Batch(interval=IntervalChunks(**iv)),
    )


class TestApplyDoesNotMutate:
    def test_original_untouched(self) -> None:
        m = _model()
        _apply(m, schema_suffix="stg")
        assert m.target.schema.suffix == ""
        assert m.target.schema.name == "public"

    def test_returns_new_model(self) -> None:
        m = _model()
        out = _apply(m)
        assert out is not m


class TestSchemaSuffix:
    def test_schema_suffix_baked_in(self) -> None:
        m = _apply(_model(), schema_suffix="pr123")
        assert m.target.schema.suffix == "pr123"
        # schema.name stays as the base; .resolved is the suffixed form.
        assert m.target.schema.name == "public"
        assert m.target.schema.resolved == "public_pr123"


class TestPipeOverrides:
    def test_interval_expression_override(self) -> None:
        m = _apply(
            _model(expression="@daily"),
            interval_expression_override="0 * * * *",
        )
        assert m.batching.interval.expression == "0 * * * *"

    def test_window_expression_override(self) -> None:
        m = _apply(_model(), latest=True, window_expression_override="@daily")
        assert m.batching.interval.window_expression == "@daily"

    def test_tz_override(self) -> None:
        m = _apply(_model(tz=UTC), tz_override=CET)
        assert m.batching.interval.tz == CET

    def test_overrides_skipped_when_unset(self) -> None:
        m = _apply(_model(expression="@daily", tz=CET))
        assert m.batching.interval.expression == "@daily"
        assert m.batching.interval.tz == CET


class TestDirectives:
    def test_latest_set_from_arg(self) -> None:
        m = _apply(_model(), latest=True)
        assert m.directives.latest is True

    def test_latest_forced_off_when_reload(self) -> None:
        m = _model()
        m.directives.reload = True
        out = _apply(m, latest=True)
        assert out.directives.latest is False
        assert out.directives.reload is True

    def test_since_and_until_from_args(self) -> None:
        since = datetime(2024, 1, 1, tzinfo=UTC)
        until = datetime(2024, 2, 1, tzinfo=UTC)
        m = _apply(_model(), backfill_since=since, backfill_until=until)
        assert m.directives.since == since
        assert m.directives.until == until


class TestTagReloadBakedIntoBatching:
    def test_reload_mode_baked_into_batching(self) -> None:
        m = Model(
            target=Target(
                name="events", schema=TargetSchema(name="raw", suffix_appendix=None)
            ),
            batching=Batch(
                mode=ChunkMode.INTERVAL,
                interval=IntervalChunks(expression="@hourly", tz=UTC),
                row=RowChunks(batch_size=5000),
            ),
            bounds=Bounds(begin=datetime(2024, 1, 1, tzinfo=UTC)),
        )
        m.directives.reload = True
        m.directives.reload_mode = ChunkMode.ROW
        m.directives.reload_batch_size = 100

        out = _apply(m)
        assert out.batching.mode is ChunkMode.ROW
        assert out.batching.row.batch_size == 100
        # Overrides absorbed — directives fields cleared.
        assert out.directives.reload_mode is None
        assert out.directives.reload_batch_size is None

    def test_reload_interval_expression_baked_into_batching(self) -> None:
        m = _model(expression="@hourly")
        m.directives.reload = True
        m.directives.reload_interval_expression = "@daily"

        out = _apply(m)
        assert out.batching.interval.expression == "@daily"
        assert out.directives.reload_interval_expression is None

    def test_pipe_override_wins_over_tag_reload_expression(self) -> None:
        """If both a tag and the runtime supply an interval expression, the
        runtime override wins — the explicit env knob beats the tag."""
        m = _model(expression="@hourly")
        m.directives.reload = True
        m.directives.reload_interval_expression = "@daily"

        out = _apply(m, interval_expression_override="*/15 * * * *")
        assert out.batching.interval.expression == "*/15 * * * *"


class TestBatchingNone:
    def test_no_batching_skips_interval_baking(self) -> None:
        m = Model(target=Target(name="t", schema=TargetSchema(suffix_appendix=None)))
        out = _apply(m, interval_expression_override="@daily")
        assert out.batching is None
