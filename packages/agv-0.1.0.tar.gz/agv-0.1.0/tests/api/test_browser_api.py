"""Tests for browser API client."""

from unittest.mock import Mock

import pytest

from agentenv.api.browser import BrowserAPI


@pytest.fixture
def mock_client():
    """Create a mock API client."""
    return Mock()


@pytest.fixture
def browser_api(mock_client):
    """Create BrowserAPI with a mock client."""
    return BrowserAPI(mock_client)


def test_create_browser_uses_current_session_dto(browser_api, mock_client):
    """Browser create should send the current browser session DTO fields."""
    mock_client.post.return_value.json.return_value = {
        "id": "br-1",
        "name": "browser-demo",
        "status": "starting",
        "cdpUrl": "wss://example.com/devtools",
        "createdAt": "2024-01-01T00:00:00Z",
    }

    session = browser_api.create(
        name="browser-demo",
        workspace_id="wk-1",
        screen_width=1440,
        screen_height=900,
        enable_stealth=True,
        enable_adblock=True,
        profile_mode="persistent",
        profile_id="profile-1",
        proxy_url="http://proxy.example:8080",
        proxy_provider="brightdata",
        proxy_type="residential",
        enable_captcha_solver=True,
        captcha_provider="capsolver",
        captcha_api_key="secret",
        enable_rrweb=True,
        enable_logger=True,
        cpu_millis=2000,
        memory_mb=4096,
        max_lifetime_seconds=1800,
        gpu_type="A100",
        geonode_proxy={
            "enabled": True,
            "mode": "whitelist",
            "domains": ["*.example.com"],
        },
    )

    assert session.id == "br-1"
    mock_client.post.assert_called_once_with(
        "/v1/browser/sessions",
        json={
            "name": "browser-demo",
            "workspaceId": "wk-1",
            "screenWidth": 1440,
            "screenHeight": 900,
            "enableStealth": True,
            "enableAdblock": True,
            "profileMode": "persistent",
            "profileId": "profile-1",
            "proxyUrl": "http://proxy.example:8080",
            "proxyProvider": "brightdata",
            "proxyType": "residential",
            "enableCaptchaSolver": True,
            "captchaProvider": "capsolver",
            "captchaApiKey": "secret",
            "enableRrweb": True,
            "enableLogger": True,
            "cpuMillis": 2000,
            "memoryMb": 4096,
            "maxLifetimeSeconds": 1800,
            "gpuType": "A100",
            "geonodeProxy": {
                "enabled": True,
                "mode": "whitelist",
                "domains": ["*.example.com"],
            },
        },
    )


def test_list_browsers_can_filter_by_workspace(browser_api, mock_client):
    """Browser list should pass workspaceId when requested."""
    mock_client.get.return_value.json.return_value = []

    browser_api.list_all(workspace_id="wk-1")

    mock_client.get.assert_called_once_with(
        "/v1/browser/sessions",
        params={"workspaceId": "wk-1"},
    )
