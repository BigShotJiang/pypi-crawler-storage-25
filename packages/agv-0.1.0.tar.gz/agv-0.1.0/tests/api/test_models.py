"""Tests for AI Gateway models."""

import pytest
from datetime import datetime
from agentenv.api.models import (
    GatewayUpstream,
    GatewayPool,
    GatewayApiKey,
    ChatCompletionRequest,
    ChatCompletionResponse,
    Message,
    Choice,
    Usage,
)


def test_gateway_upstream_creation():
    """Test GatewayUpstream model."""
    upstream = GatewayUpstream(
        id="up_123",
        name="OpenAI Prod",
        provider="openai",
        base_url="https://api.openai.com",
        is_active=True,
        rate_limit_rpm=1000,
        created_at=datetime.now(),
    )
    assert upstream.id == "up_123"
    assert upstream.provider == "openai"


def test_chat_completion_request():
    """Test ChatCompletionRequest model."""
    request = ChatCompletionRequest(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
        temperature=0.7,
        stream=True,
    )
    assert request.model == "gpt-4"
    assert request.temperature == 0.7
    assert request.stream is True
