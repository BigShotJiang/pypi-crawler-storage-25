"""Tests for AI Gateway API client."""

import pytest
from datetime import datetime
from unittest.mock import Mock

from agentenv.api.client import Client
from agentenv.api.ai_gateway import AIGatewayAPI
from agentenv.api.models import ChatCompletionRequest


@pytest.fixture
def mock_client():
    """Create mock HTTP client."""
    return Mock(spec=Client)


def test_list_upstreams(mock_client):
    """Test listing upstreams."""
    mock_response = Mock()
    mock_response.json.return_value = [
        {
            "id": "up_123",
            "name": "OpenAI Prod",
            "provider": "openai",
            "isActive": True,
            "createdAt": datetime.now().isoformat(),
        }
    ]
    mock_client.get.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    upstreams = api.list_upstreams()

    assert len(upstreams) == 1
    assert upstreams[0].id == "up_123"
    mock_client.get.assert_called_once_with("/ai-gateway/upstreams")


def test_create_chat_completion(mock_client):
    """Test chat completion creation."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "id": "chat_123",
        "object": "chat.completion",
        "created": 1234567890,
        "model": "gpt-4",
        "choices": [
            {
                "index": 0,
                "message": {"role": "assistant", "content": "Hello!"},
                "finishReason": "stop",
            }
        ],
        "usage": {"promptTokens": 10, "completionTokens": 5, "totalTokens": 15},
    }
    mock_client.post.return_value = mock_response

    api = AIGatewayAPI(mock_client, gateway_key="cr_test")
    request = ChatCompletionRequest(
        model="gpt-4",
        messages=[{"role": "user", "content": "Hello"}],
    )
    response = api.chat.create(request)

    assert response.id == "chat_123"
    assert response.choices[0].message.content == "Hello!"


def test_list_platform_models(mock_client):
    """Test listing platform models."""
    mock_response = Mock()
    mock_response.json.return_value = {
        "providers": [
            {
                "id": "openai",
                "displayName": "OpenAI",
                "models": [
                    {
                        "id": "gpt-4o",
                        "displayName": "GPT-4o",
                        "inputPrice": 5,
                        "outputPrice": 15,
                    }
                ],
            }
        ]
    }
    mock_client.get.return_value = mock_response

    api = AIGatewayAPI(mock_client)
    payload = api.list_platform_models()

    assert payload["providers"][0]["id"] == "openai"
    mock_client.get.assert_called_once_with("/ai-gateway/platform-models")
