"""Tests for notebook cell models."""

import pytest
from datetime import datetime
from agentenv.api.models import (
    NotebookDocument,
    NotebookCell,
    CellOutput,
    NotebookCellDetail,
    ExecutionResult,
    NotebookSession,
)


def test_notebook_cell_creation():
    """Test NotebookCell model."""
    cell = NotebookCell(
        id="cell-uuid-123",
        notebookId="nb-123",
        cellIndex=0,
        cellType="code",
        source="print('hello')",
        sourceOtVersion=1,
        createdAt=datetime.now(),
        updatedAt=datetime.now(),
    )
    assert cell.id == "cell-uuid-123"
    assert cell.cell_type == "code"
    assert cell.cell_index == 0


def test_cell_output_stream():
    """Test CellOutput with stream type."""
    output = CellOutput(
        outputType="stream",
        name="stdout",
        text="Hello, world!\n",
    )
    assert output.output_type == "stream"
    assert output.name == "stdout"


def test_cell_output_stream_normalizes_text_list():
    """Stream output text from imported notebooks may arrive as a list of lines."""
    output = CellOutput(
        outputType="stream",
        name="stdout",
        text=["Hello, ", "world!\n"],
    )
    assert output.text == "Hello, world!\n"


def test_cell_output_error():
    """Test CellOutput with error type."""
    output = CellOutput(
        outputType="error",
        ename="ZeroDivisionError",
        evalue="division by zero",
        traceback=["Traceback...", "  File..."],
    )
    assert output.output_type == "error"
    assert output.ename == "ZeroDivisionError"


def test_notebook_cell_detail():
    """Test NotebookCellDetail with outputs."""
    cell = NotebookCellDetail(
        id="cell-uuid-123",
        notebookId="nb-123",
        cellIndex=0,
        cellType="code",
        source="print('hello')",
        sourceOtVersion=1,
        createdAt=datetime.now(),
        updatedAt=datetime.now(),
        outputs=[
            CellOutput(outputType="stream", name="stdout", text="hello\n")
        ],
        executionCount=5,
        status="ok",
        lastRunAt=123456,
        lastRunDuration=1.23,
    )
    assert cell.execution_count == 5
    assert cell.last_run_at == 123456
    assert len(cell.outputs) == 1


def test_execution_result():
    """Test ExecutionResult model."""
    result = ExecutionResult(
        executionId="exec-123",
        status="started",
    )
    assert result.execution_id == "exec-123"


def test_notebook_document_creation():
    """Test NotebookDocument model."""
    document = NotebookDocument(
        id="nb-123",
        workspaceId="wk-1",
        name="Demo",
        filePath="/mnt/notebooks/nb-123/notebook.ipynb",
        metadata={
            "kernel": "python3",
            "runtime": "cpu",
            "autoSaveEnabled": True,
            "version": 1,
        },
        createdAt=datetime.now(),
        updatedAt=datetime.now(),
    )

    assert document.workspace_id == "wk-1"
    assert document.metadata is not None
    assert document.metadata.kernel == "python3"


def test_notebook_session_keeps_ttl_policy_config():
    """NotebookSession should preserve kernel TTL config."""
    session = NotebookSession(
        id="session-1",
        status="running",
        config={
            "ttlPolicy": {
                "persistent": False,
                "idleTtlSeconds": 300,
            }
        },
        createdAt=datetime.now(),
    )

    assert session.config is not None
    assert session.config["ttlPolicy"]["idleTtlSeconds"] == 300
