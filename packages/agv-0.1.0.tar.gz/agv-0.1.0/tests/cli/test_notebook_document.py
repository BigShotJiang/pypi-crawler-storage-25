"""Integration tests for notebook document CLI commands."""

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import Mock, patch

import pytest
from typer.testing import CliRunner

from agentenv.cli.app import app


runner = CliRunner()


def _mock_document(doc_id: str = "nb-123") -> SimpleNamespace:
    metadata = SimpleNamespace(kernel="python3", runtime="cpu", auto_save_enabled=True)
    return SimpleNamespace(
        id=doc_id,
        workspace_id="wk-1",
        name="Demo",
        description="test",
        file_path=f"/mnt/notebooks/{doc_id}/notebook.ipynb",
        metadata=metadata,
        created_at=datetime.now(timezone.utc),
        updated_at=datetime.now(timezone.utc),
        model_dump=lambda by_alias=True, exclude_none=True: {
            "id": doc_id,
            "workspaceId": "wk-1",
            "name": "Demo",
        },
    )


@pytest.fixture
def mock_api():
    """Mock NotebookAPI."""
    with patch("agentenv.cli.notebook.NotebookAPI") as mock:
        yield mock.return_value


@pytest.fixture
def mock_client():
    """Mock authenticated client."""
    with patch("agentenv.cli.notebook.get_client") as mock:
        mock.return_value = Mock()
        yield mock


def test_document_list(mock_client, mock_api):
    """List notebook documents by workspace."""
    mock_api.list_documents.return_value = [_mock_document()]

    result = runner.invoke(
        app,
        ["notebook", "document", "list", "--workspace", "wk-1"],
    )

    assert result.exit_code == 0
    assert "Demo" in result.output
    mock_api.list_documents.assert_called_once_with("wk-1")


def test_document_create(mock_client, mock_api):
    """Create a notebook document."""
    mock_api.create_document.return_value = _mock_document()

    result = runner.invoke(
        app,
        [
            "notebook",
            "document",
            "create",
            "--workspace",
            "wk-1",
            "--name",
            "Demo",
            "--kernel",
            "python3",
            "--image",
            "docker://registry.example/custom:latest",
        ],
    )

    assert result.exit_code == 0
    assert "created" in result.output.lower()
    mock_api.create_document.assert_called_once_with(
        workspace_id="wk-1",
        name="Demo",
        description=None,
        kernel="python3",
        runtime="cpu",
        image="docker://registry.example/custom:latest",
        auto_save_enabled=None,
        markdown_first_cell=False,
    )


def test_document_get(mock_client, mock_api):
    """Get notebook document details."""
    mock_api.get_document.return_value = _mock_document()

    result = runner.invoke(app, ["notebook", "document", "get", "nb-123"])

    assert result.exit_code == 0
    assert "Notebook Document" in result.output
    mock_api.get_document.assert_called_once_with("nb-123")


def test_document_set_requires_updates(mock_client, mock_api):
    """Set command requires at least one change option."""
    result = runner.invoke(app, ["notebook", "document", "set", "nb-123"])

    assert result.exit_code == 1
    assert "No updates provided" in result.output
    mock_api.update_document.assert_not_called()


def test_document_set(mock_client, mock_api):
    """Update notebook document metadata."""
    mock_api.update_document.return_value = _mock_document()

    result = runner.invoke(
        app,
        ["notebook", "document", "set", "nb-123", "--name", "Demo v2"],
    )

    assert result.exit_code == 0
    assert "updated" in result.output.lower()
    mock_api.update_document.assert_called_once_with(
        notebook_id="nb-123",
        name="Demo v2",
        description=None,
        kernel=None,
        auto_save_enabled=None,
    )


def test_document_rm(mock_client, mock_api):
    """Delete notebook document."""
    result = runner.invoke(
        app,
        ["notebook", "document", "rm", "nb-123", "--force"],
    )

    assert result.exit_code == 0
    mock_api.delete_document.assert_called_once_with("nb-123")


def test_document_import_requires_single_source(mock_client, mock_api):
    """Import requires exactly one source."""
    result = runner.invoke(
        app,
        ["notebook", "document", "import", "--workspace", "wk-1"],
    )

    assert result.exit_code == 1
    assert "Provide exactly one of --url or --file" in result.output
    mock_api.import_document.assert_not_called()


def test_document_import_from_url(mock_client, mock_api):
    """Import notebook document from URL."""
    mock_api.import_document.return_value = _mock_document("nb-456")

    result = runner.invoke(
        app,
        [
            "notebook",
            "document",
            "import",
            "--workspace",
            "wk-1",
            "--url",
            "https://example.com/demo.ipynb",
            "--image",
            "docker://registry.example/custom:latest",
        ],
    )

    assert result.exit_code == 0
    assert "imported" in result.output.lower()
    mock_api.import_document.assert_called_once_with(
        workspace_id="wk-1",
        name=None,
        url="https://example.com/demo.ipynb",
        file_path=None,
        image="docker://registry.example/custom:latest",
    )


def test_document_export_to_file(mock_client, mock_api, tmp_path):
    """Export notebook document content to local file."""
    mock_api.export_document.return_value = '{"cells":[]}'
    output_file = tmp_path / "exported.ipynb"

    result = runner.invoke(
        app,
        [
            "notebook",
            "document",
            "export",
            "nb-123",
            "--output",
            str(output_file),
        ],
    )

    assert result.exit_code == 0
    assert output_file.exists()
    assert output_file.read_text(encoding="utf-8") == '{"cells":[]}'
    mock_api.export_document.assert_called_once_with("nb-123", download=True)


def test_document_save(mock_client, mock_api):
    """Save notebook document."""
    mock_api.save_document.return_value = _mock_document()

    result = runner.invoke(app, ["notebook", "document", "save", "nb-123"])

    assert result.exit_code == 0
    assert "saved" in result.output.lower()
    mock_api.save_document.assert_called_once_with("nb-123")


def test_document_outline(mock_client, mock_api):
    """Outline should render markdown headings from notebook cells."""
    mock_api.list_cells.return_value = [
        Mock(
            id="cell-1",
            notebook_id="nb-123",
            cell_index=0,
            cell_type="markdown",
            source="# Title\n## Section\nplain text",
            outputs=[],
        ),
        Mock(
            id="cell-2",
            notebook_id="nb-123",
            cell_index=1,
            cell_type="code",
            source="print('hello')",
            outputs=[],
        ),
    ]

    result = runner.invoke(app, ["notebook", "document", "outline", "nb-123"])

    assert result.exit_code == 0
    assert "Title" in result.output
    assert "Section" in result.output
    mock_api.list_cells.assert_called_once_with("nb-123", include_outputs=False)
