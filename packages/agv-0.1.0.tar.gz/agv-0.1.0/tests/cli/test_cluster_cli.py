"""Integration tests for cluster CLI commands."""

from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.cli.app import app

runner = CliRunner()


def test_cluster_ls_uses_workspace_filter() -> None:
    """List clusters should forward the workspace filter."""
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.list_clusters.return_value = []
        result = runner.invoke(app, ["cluster", "ls", "--workspace", "wk-1"])

    assert result.exit_code == 0
    mock_api_cls.return_value.list_clusters.assert_called_once_with(workspace_id="wk-1")


def test_cluster_ray_create_uses_current_payload() -> None:
    """Create Ray cluster should use the current cluster DTO fields."""
    with (
        patch("agentenv.cli.cluster.get_client", return_value=Mock()),
        patch("agentenv.cli.cluster.ClusterAPI") as mock_api_cls,
    ):
        mock_api_cls.return_value.create_ray_cluster.return_value = {
            "id": "cl-1",
            "status": "pending",
            "type": "ray",
            "config": {"shape": "4x2xH100"},
        }
        result = runner.invoke(
            app,
            [
                "cluster",
                "ray",
                "4x2xH100",
                "--workspace",
                "wk-1",
                "--name",
                "training",
                "--image",
                "docker://rayproject/ray:latest",
                "--snapshot",
                "snap-1",
                "--allow-cidr",
                "1.2.3.4/32",
            ],
        )

    assert result.exit_code == 0
    mock_api_cls.return_value.create_ray_cluster.assert_called_once_with(
        workspace_id="wk-1",
        shape="4x2xH100",
        name="training",
        image="docker://rayproject/ray:latest",
        snapshot_id="snap-1",
        allow_cidr="1.2.3.4/32",
    )
