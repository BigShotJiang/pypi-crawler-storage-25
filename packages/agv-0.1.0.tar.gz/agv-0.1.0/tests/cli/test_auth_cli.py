"""Tests for auth CLI commands."""

import json
from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.api.models import APIKey
from agentenv.cli.app import app
from agentenv.cli.auth import _build_frontend_login_url

runner = CliRunner()


def _mock_settings() -> Mock:
    settings = Mock()
    settings.api_url = "http://test"
    settings.api_key = None
    settings.access_token = "access-token"
    settings.refresh_token = None
    settings.workspace = None
    settings.is_authenticated.return_value = True
    return settings


def test_create_key_parses_api_key_alias() -> None:
    """create-key should parse apiKey from server response."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.create_api_key.return_value = APIKey(
            id="ak_1234567890ab",
            name="My CLI Key",
            apiKey="sk_live_from_api_key",
            createdAt="2026-03-02T00:00:00Z",
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "create-key", "My CLI Key"])

    assert result.exit_code == 0
    assert "sk_live_from_api_key" in result.output
    assert "av login --api-key sk_live_from_api_key" in result.output


def test_create_key_keeps_legacy_key_compatibility() -> None:
    """create-key should also accept legacy key field for compatibility."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.create_api_key.return_value = APIKey(
            id="ak_1234567890ab",
            name="My CLI Key",
            key="sk_live_legacy_key",
            createdAt="2026-03-02T00:00:00Z",
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "create-key", "My CLI Key"])

    assert result.exit_code == 0
    assert "sk_live_legacy_key" in result.output


def test_create_key_fails_if_plaintext_key_is_missing() -> None:
    """create-key must fail if response does not include plaintext key."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.create_api_key.return_value = APIKey(
            id="ak_1234567890ab",
            name="My CLI Key",
            createdAt="2026-03-02T00:00:00Z",
        )
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "create-key", "My CLI Key"])

    assert result.exit_code == 1
    assert "did not include plaintext key" in result.output


def test_list_keys_handles_nullable_name() -> None:
    """list-keys should render keys even if name is null."""
    settings = _mock_settings()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_api = Mock()
        mock_api.list_api_keys.return_value = [
            APIKey(
                id="ak_1234567890ab",
                name=None,
                createdAt="2026-03-02T00:00:00Z",
            ),
        ]
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["auth", "list-keys"])

    assert result.exit_code == 0
    assert "API Keys" in result.output
    assert "Traceback" not in result.output


def test_login_browser_flow_uses_public_host_for_remote_callback() -> None:
    settings = _mock_settings()
    settings.api_key = None
    settings.access_token = None
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch("agentenv.oauth.flow.run_browser_login_flow") as mock_browser_flow,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_browser_flow.return_value = ("access-token-remote", None)
        mock_api = Mock()
        mock_api.get_profile.return_value = SimpleNamespace(username="tester")
        mock_api_class.return_value = mock_api

        result = runner.invoke(
            app,
            [
                "login",
                "--public-host",
                "177.54.159.23",
                "--callback-port",
                "50392",
            ],
        )

    assert result.exit_code == 0
    mock_browser_flow.assert_called_once_with(
        frontend_url="http://test/login",
        port=50392,
        open_browser=True,
        callback_host="177.54.159.23",
        callback_bind_host="0.0.0.0",
    )


def test_login_browser_flow_defaults_to_localhost_callback() -> None:
    settings = _mock_settings()
    settings.api_key = None
    settings.access_token = None
    settings.save_credentials = Mock()

    with (
        patch("agentenv.cli.auth.get_settings", return_value=settings),
        patch("agentenv.cli.auth.Client"),
        patch("agentenv.cli.auth.AuthAPI") as mock_api_class,
        patch("agentenv.oauth.flow.run_browser_login_flow") as mock_browser_flow,
        patch(
            "agentenv.cli.auth.status",
            side_effect=lambda *_args, **_kwargs: nullcontext(),
        ),
    ):
        mock_browser_flow.return_value = ("access-token-local", None)
        mock_api = Mock()
        mock_api.get_profile.return_value = SimpleNamespace(username="tester")
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["login"])

    assert result.exit_code == 0
    mock_browser_flow.assert_called_once_with(
        frontend_url="http://test/login",
        port=50391,
        open_browser=True,
        callback_host="localhost",
        callback_bind_host="127.0.0.1",
    )


def test_build_frontend_login_url_for_local_api_uses_vite_port() -> None:
    """Local API URLs should still open the local frontend dev server."""
    assert _build_frontend_login_url("http://localhost:3000") == "http://localhost:5173/login"
    assert _build_frontend_login_url("http://127.0.0.1:3000") == "http://127.0.0.1:5173/login"


def test_build_frontend_login_url_for_hosted_api_uses_branded_frontend() -> None:
    """Hosted API URLs should map to the branded frontend domain without api."""
    assert (
        _build_frontend_login_url("https://api.agentenv.cloud")
        == "https://agentenv.cloud/login"
    )
    assert (
        _build_frontend_login_url("https://api.agentenv.cloud/api")
        == "https://agentenv.cloud/login"
    )


def test_auth_status_global_json_outputs_single_payload() -> None:
    """Global --json should make auth status emit one JSON object."""
    settings = _mock_settings()

    with patch("agentenv.cli.auth.get_settings", return_value=settings):
        result = runner.invoke(app, ["--json", "auth", "status"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["authenticated"] is True
    assert payload["credentials"]["apiUrl"] == "http://test"
