"""Tests for workflow CLI commands."""

from datetime import UTC, datetime
from types import SimpleNamespace
from unittest.mock import Mock, patch
import json

from typer.testing import CliRunner

from agentenv.api.models import (
    Workflow,
    WorkflowDefinition,
    WorkflowMetrics,
    WorkflowWebhookEndpoint,
)
from agentenv.cli.app import app

runner = CliRunner()


def _make_workflow() -> Workflow:
    now = datetime.now(UTC)
    return Workflow(
        id="51699bcc-7308-4715-a0e8-aa375806e264",
        workspaceId="ff80914b-eb24-4d3d-b6d8-8a149dc91a10",
        name="daily-sync",
        description="sync workflow",
        version=3,
        status="draft",
        definition=WorkflowDefinition(nodes=[], edges=[]),
        publishedDefinition=None,
        publishedAt=None,
        createdAt=now,
        updatedAt=now,
    )


def test_workflow_ls_json_uses_default_workspace_and_outputs_full_ids() -> None:
    """workflow ls --json should use the configured workspace and print full IDs."""
    workflow = _make_workflow()
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
            with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
                mock_api = mock_api_cls.return_value
                mock_api.list_all.return_value = [workflow]

                result = runner.invoke(app, ["workflow", "ls", "--json"])

    assert result.exit_code == 0
    assert workflow.id in result.output
    assert workflow.workspace_id in result.output
    mock_api.list_all.assert_called_once_with("wk_default", status=None)


def test_workflow_create_reads_definition_file(tmp_path) -> None:
    """workflow create should parse the definition file and pass it to the API."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text(
        '{"nodes":[{"id":"trigger-1","type":"webhook","config":{}}],"edges":[]}',
        encoding="utf-8",
    )
    workflow = _make_workflow()
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
            with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
                mock_api = mock_api_cls.return_value
                mock_api.create.return_value = workflow

                result = runner.invoke(
                    app,
                    [
                        "workflow",
                        "create",
                        "daily-sync",
                        "--file",
                        str(definition_path),
                        "--json",
                    ],
                )

    assert result.exit_code == 0
    mock_api.create.assert_called_once_with(
        "wk_default",
        name="daily-sync",
        definition={
            "nodes": [{"id": "trigger-1", "type": "webhook", "config": {}}],
            "edges": [],
        },
        description=None,
    )


def test_workflow_execute_reads_input_file(tmp_path) -> None:
    """workflow execute should parse structured input files."""
    input_path = tmp_path / "input.json"
    input_path.write_text('{"customerId":"cus_123","amount":42}', encoding="utf-8")

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.execute.return_value = {"executionId": "exec_123"}

            result = runner.invoke(
                app,
                [
                    "workflow",
                    "execute",
                    "wf_123",
                    "--input-file",
                    str(input_path),
                    "--json",
                ],
            )

    assert result.exit_code == 0
    mock_api.execute.assert_called_once_with(
        "wf_123",
        input_data={"customerId": "cus_123", "amount": 42},
        trigger_node_id=None,
    )
    assert "exec_123" in result.output


def test_workflow_deploy_calls_api() -> None:
    """workflow deploy should call the renamed API method."""
    workflow = _make_workflow()

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.deploy.return_value = workflow

            result = runner.invoke(app, ["workflow", "deploy", "wf_123", "--json"])

    assert result.exit_code == 0
    mock_api.deploy.assert_called_once_with("wf_123")
    assert workflow.id in result.output


def test_workflow_update_requires_changes() -> None:
    """workflow update should fail when no changes are provided."""
    result = runner.invoke(app, ["workflow", "update", "wf_123"])

    assert result.exit_code == 1
    assert "No updates specified" in result.output


def test_workflow_ls_rejects_invalid_status() -> None:
    """workflow ls should validate status filters before making API calls."""
    result = runner.invoke(app, ["workflow", "ls", "--status", "paused"])

    assert result.exit_code == 1
    assert "Invalid status 'paused'" in result.output


def test_workflow_create_rejects_non_object_definition() -> None:
    """workflow create should reject non-object workflow definitions before the API call."""
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        result = runner.invoke(
            app,
            [
                "workflow",
                "create",
                "daily-sync",
                "--definition",
                '["not","an","object"]',
            ],
        )

    assert result.exit_code == 1
    assert "workflow definition must be a JSON object" in result.output


def test_workflow_execute_rejects_non_object_input() -> None:
    """workflow execute should reject non-object input before hitting the API."""
    result = runner.invoke(
        app,
        [
            "workflow",
            "execute",
            "wf_123",
            "--input",
            '["bad"]',
        ],
    )

    assert result.exit_code == 1
    assert "execution input must be a JSON object" in result.output


def test_workflow_execute_in_memory_reads_definition_and_input_files(tmp_path) -> None:
    """workflow execute-in-memory should parse definition and input files."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text(
        '{"nodes":[{"id":"trigger","type":"webhook","config":{}}],"edges":[]}',
        encoding="utf-8",
    )
    input_path = tmp_path / "input.json"
    input_path.write_text('{"customerId":"cus_123"}', encoding="utf-8")

    settings = SimpleNamespace(workspace="wk_default")
    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
            with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
                mock_api = mock_api_cls.return_value
                mock_api.execute_in_memory.return_value = {
                    "status": "completed",
                    "duration": 12,
                    "output": {"ok": True},
                }

                result = runner.invoke(
                    app,
                    [
                        "workflow",
                        "execute-in-memory",
                        "--file",
                        str(definition_path),
                        "--input-file",
                        str(input_path),
                        "--json",
                    ],
                )

    assert result.exit_code == 0
    mock_api.execute_in_memory.assert_called_once_with(
        "wk_default",
        {
            "nodes": [{"id": "trigger", "type": "webhook", "config": {}}],
            "edges": [],
        },
        input_data={"customerId": "cus_123"},
        trigger_node_id=None,
    )
    payload = json.loads(result.output)
    assert payload["status"] == "completed"


def test_workflow_execute_in_memory_rejects_non_object_input(tmp_path) -> None:
    """workflow execute-in-memory should reject non-object execution input."""
    definition_path = tmp_path / "workflow.json"
    definition_path.write_text(
        '{"nodes":[{"id":"trigger","type":"webhook","config":{}}],"edges":[]}',
        encoding="utf-8",
    )
    settings = SimpleNamespace(workspace="wk_default")

    with patch("agentenv.cli.workflow.get_settings", return_value=settings):
        result = runner.invoke(
            app,
            [
                "workflow",
                "execute-in-memory",
                "--file",
                str(definition_path),
                "--input",
                '"bad"',
            ],
        )

    assert result.exit_code == 1
    assert "execution input must be a JSON object" in result.output


def test_workflow_metrics_json_outputs_metric_payload() -> None:
    """workflow metrics --json should emit serialized metrics."""
    metrics = WorkflowMetrics(
        total=10,
        pending=1,
        running=2,
        completed=6,
        failed=1,
        successRate=85.71,
        avgDurationMs=1200,
    )

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get_metrics.return_value = metrics

            result = runner.invoke(app, ["workflow", "metrics", "wf_123", "--json"])

    assert result.exit_code == 0
    mock_api.get_metrics.assert_called_once_with("wf_123", from_time=None, to_time=None)
    payload = json.loads(result.output)
    assert payload["successRate"] == 85.71
    assert payload["avgDurationMs"] == 1200


def test_workflow_inspect_json_includes_webhook_endpoints() -> None:
    """workflow inspect --json should preserve webhook endpoint metadata."""
    workflow = _make_workflow().model_copy(
        update={
            "webhook_endpoints": [
                WorkflowWebhookEndpoint(
                    nodeId="trigger-1",
                    nodeType="webhook",
                    nodeName="Incoming Webhook",
                    path="wf_123/trigger-1/openai",
                    relativeUrl="/v1/webhooks/v1/wf_123/trigger-1/openai",
                    methods=["POST"],
                    isActive=True,
                )
            ]
        }
    )

    with patch("agentenv.cli.workflow.get_client", return_value=Mock()):
        with patch("agentenv.cli.workflow.WorkflowAPI") as mock_api_cls:
            mock_api = mock_api_cls.return_value
            mock_api.get.return_value = workflow

            result = runner.invoke(app, ["workflow", "inspect", "wf_123", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["webhookEndpoints"][0]["relativeUrl"] == "/v1/webhooks/v1/wf_123/trigger-1/openai"
