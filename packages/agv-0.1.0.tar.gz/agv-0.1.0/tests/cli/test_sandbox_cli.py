"""Tests for sandbox CLI log commands."""

from contextlib import nullcontext
from types import SimpleNamespace
from unittest.mock import Mock

from agentenv.cli.sandbox import print_logs, run_sandbox


class _DummyResponse:
    def __init__(self, payload=None, text: str = "", json_error: Exception | None = None):
        self._payload = payload
        self.text = text
        self._json_error = json_error

    def json(self):
        if self._json_error is not None:
            raise self._json_error
        return self._payload


def test_print_logs_follow_polls_lifecycle_and_prints_incremental_entries(
    monkeypatch,
    capsys,
) -> None:
    """follow mode should poll lifecycle logs and print only new messages."""
    mock_client = Mock()
    responses = [
        _DummyResponse(
            {
                "entries": [
                    {
                        "timestamp": "2026-03-03T07:13:54.960Z",
                        "message": "first",
                        "logPath": "pending",
                    },
                    {
                        "timestamp": "2026-03-03T07:13:55.000Z",
                        "message": "second",
                        "logPath": "pending",
                    },
                ]
            }
        ),
        _DummyResponse(
            {
                "entries": [
                    {
                        "timestamp": "2026-03-03T07:13:55.000Z",
                        "message": "second",
                        "logPath": "pending",
                    },
                    {
                        "timestamp": "2026-03-03T07:13:56.000Z",
                        "message": "third",
                        "logPath": "stdout",
                    },
                ]
            }
        ),
        KeyboardInterrupt(),
    ]

    def _fake_get(*_args, **_kwargs):
        item = responses.pop(0)
        if isinstance(item, BaseException):
            raise item
        return item

    mock_client.get.side_effect = _fake_get

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: mock_client)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )
    monkeypatch.setattr("agentenv.cli.sandbox.time.sleep", lambda _seconds: None)

    print_logs("sandbox-prefix", follow=True, tail=50)

    assert mock_client.get.call_count == 3
    first_call = mock_client.get.call_args_list[0]
    second_call = mock_client.get.call_args_list[1]
    assert first_call.args[0] == "/v1/sandboxes/sandbox-full-id/logs/lifecycle"
    assert first_call.kwargs["params"] == {"sort": "asc", "limit": 50}
    assert second_call.kwargs["params"] == {
        "sort": "asc",
        "limit": 50,
        "from": "2026-03-03T07:13:55.000Z",
    }

    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["first", "second", "third"]


def test_print_logs_non_follow_reads_lifecycle_once(monkeypatch, capsys) -> None:
    """non-follow mode should read lifecycle logs once and print message lines."""
    mock_client = Mock()
    mock_client.get.return_value = _DummyResponse(
        {
            "entries": [
                {
                    "timestamp": "2026-03-03T07:13:54.960Z",
                    "message": "line-one",
                    "logPath": "stdout",
                },
                {
                    "timestamp": "2026-03-03T07:13:55.000Z",
                    "message": "line-two",
                    "logPath": "pending",
                },
            ]
        }
    )

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: mock_client)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )

    print_logs("sandbox-prefix", follow=False)

    mock_client.get.assert_called_once_with(
        "/v1/sandboxes/sandbox-full-id/logs/lifecycle",
        params={"sort": "asc", "limit": 200},
    )
    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["line-one", "line-two"]


def test_print_logs_non_follow_falls_back_to_plain_text(monkeypatch, capsys) -> None:
    """non-follow mode should print raw text if response body is not JSON."""
    mock_client = Mock()
    mock_client.get.return_value = _DummyResponse(
        payload=None,
        text="plain text log",
        json_error=ValueError("invalid json"),
    )

    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: mock_client)
    monkeypatch.setattr(
        "agentenv.cli.sandbox.resolve_sandbox_id",
        lambda _client, _sandbox_id: "sandbox-full-id",
    )

    print_logs("sandbox-prefix", follow=False)

    output_lines = capsys.readouterr().out.strip().splitlines()
    assert output_lines == ["plain text log"]


def test_run_with_explicit_image_and_no_command_uses_image_default(monkeypatch) -> None:
    """run --image <img> without command should not force /bin/bash."""
    captured_args = {}
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-1", status="pending")

    def _fake_build_request(**kwargs):
        captured_args["args"] = kwargs["args"]
        return {"args": kwargs["args"]}

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", _fake_build_request)

    run_sandbox(
        ctx=Mock(),
        name="nginx",
        type=None,
        sandbox=None,
        image="nginx:latest",
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        follow=False,
        command=None,
    )

    assert captured_args["args"] == []
    mock_api.create.assert_called_once_with({"args": []})


def test_run_without_runtime_source_and_no_command_defaults_to_bash(monkeypatch) -> None:
    """plain `av run` without command should keep shell-first behavior."""
    captured_args = {}
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-2", status="pending")

    def _fake_build_request(**kwargs):
        captured_args["args"] = kwargs["args"]
        return {"args": kwargs["args"]}

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", _fake_build_request)

    run_sandbox(
        ctx=Mock(),
        name=None,
        type=None,
        sandbox=None,
        image=None,
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        follow=False,
        command=None,
    )

    assert captured_args["args"] == ["/bin/bash"]
    mock_api.create.assert_called_once_with({"args": ["/bin/bash"]})


def test_run_sandbox_is_async_and_follows_logs_without_wait(monkeypatch) -> None:
    """run_sandbox should not wait for running and should follow lifecycle logs by default."""
    mock_api = Mock()
    mock_api.create.return_value = SimpleNamespace(id="sb-async", status="pending")
    mock_api.wait_for_status.side_effect = AssertionError("wait_for_status should not be called")

    monkeypatch.setattr("agentenv.cli.sandbox.get_settings", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.get_client", lambda: Mock())
    monkeypatch.setattr("agentenv.cli.sandbox.SandboxAPI", lambda _client: mock_api)
    monkeypatch.setattr("agentenv.cli.sandbox.status", lambda *_a, **_k: nullcontext())
    monkeypatch.setattr("agentenv.cli.sandbox.build_sandbox_request", lambda **_kwargs: {})
    mock_print_logs = Mock()
    monkeypatch.setattr("agentenv.cli.sandbox.print_logs", mock_print_logs)

    run_sandbox(
        ctx=Mock(),
        name="nginx",
        type=None,
        sandbox=None,
        image="nginx:latest",
        image_tag=None,
        snapshot=None,
        cpu=None,
        memory=None,
        gpu=0,
        gpu_type=None,
        env=[],
        expose=[],
        secret=[],
        region=None,
        max_lifetime_seconds=None,
        follow=True,
        command=[],
    )

    mock_api.create.assert_called_once_with({})
    assert mock_api.wait_for_status.call_count == 0
    mock_print_logs.assert_called_once_with("sb-async", follow=True)
