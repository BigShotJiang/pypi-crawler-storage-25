"""Tests for notebook collaboration CLI commands."""

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.cli.app import app


runner = CliRunner()


def _mock_collaborator(user_id: str, name: str) -> SimpleNamespace:
    payload = {
        "notebookId": "nb-123",
        "sessionId": f"session-{user_id}",
        "userId": user_id,
        "userData": {"name": name, "color": "#ef4444"},
        "lastHeartbeat": datetime.now(timezone.utc).isoformat(),
    }
    return SimpleNamespace(
        notebook_id="nb-123",
        session_id=f"session-{user_id}",
        user_id=user_id,
        user_data={"name": name, "color": "#ef4444"},
        last_heartbeat=datetime.now(timezone.utc),
        model_dump=lambda by_alias=True, exclude_none=True: payload,
    )


def test_notebook_collab_ls() -> None:
    with patch("agentenv.cli.notebook.get_client") as mock_client, patch(
        "agentenv.cli.notebook.NotebookAPI"
    ) as mock_api_cls:
        mock_client.return_value = Mock()
        mock_api = mock_api_cls.return_value
        mock_api.list_collaborators.return_value = [
            _mock_collaborator("user-1", "jacob"),
            _mock_collaborator("user-2", "jacob2"),
        ]

        result = runner.invoke(app, ["notebook", "collab", "ls", "nb-123"])

        assert result.exit_code == 0
        assert "jacob" in result.output
        assert "jacob2" in result.output
        mock_api.list_collaborators.assert_called_once_with("nb-123")
