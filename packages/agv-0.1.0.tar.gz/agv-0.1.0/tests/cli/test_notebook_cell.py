"""Integration tests for notebook cell CLI commands."""

import json
import pytest
from unittest.mock import Mock, call, patch
from typer.testing import CliRunner

from agentenv.cli.app import app
from agentenv.api.models import APIError


runner = CliRunner()


@pytest.fixture
def mock_api():
    """Mock NotebookAPI."""
    with patch("agentenv.cli.notebook.NotebookAPI") as mock:
        yield mock.return_value


@pytest.fixture
def mock_client():
    """Mock get_client."""
    with patch("agentenv.cli.notebook.get_client") as mock:
        mock.return_value = Mock()
        yield mock


def test_cell_list(mock_client, mock_api):
    """Test cell list command."""
    mock_api.list_cells.return_value = [
        Mock(
            id="cell-1",
            notebook_id="nb-123",
            cell_index=0,
            cell_type="code",
            source="x = 1",
            status="ok",
            execution_count=1,
            last_run_duration=0.5,
            outputs=[],
        )
    ]

    result = runner.invoke(app, ["notebook", "cell", "list", "nb-123"])

    assert result.exit_code == 0
    assert "cell-1" in result.output
    mock_api.list_cells.assert_called_once_with("nb-123", include_outputs=True)


def test_cell_list_json_is_valid_json(mock_client, mock_api):
    """Cell list JSON output should remain machine-parseable."""
    mock_api.list_cells.return_value = [
        Mock(
            id="cell-1",
            notebook_id="nb-123",
            cell_index=0,
            cell_type="markdown",
            source="# Imported Demo Synced\nThis notebook was imported for acceptance.",
            status=None,
            execution_count=None,
            last_run_duration=None,
            outputs=[],
        )
    ]

    result = runner.invoke(app, ["notebook", "cell", "list", "nb-123", "--json"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload[0]["source"].startswith("# Imported Demo Synced")


def test_cell_get_by_id(mock_client, mock_api):
    """Test cell get command with --id."""
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        notebook_id="nb-123",
        cell_index=0,
        cell_type="code",
        source="print('hello')",
        status="ok",
        execution_count=5,
        last_run_duration=1.23,
        outputs=[],
    )

    result = runner.invoke(
        app,
        ["notebook", "cell", "get", "nb-123", "--id", "cell-1"],
    )

    assert result.exit_code == 0
    assert "cell-1" in result.output
    mock_api.get_cell.assert_called_once_with("nb-123", "cell-1")


def test_cell_get_json_is_valid_json(mock_client, mock_api):
    """Cell get JSON output should remain machine-parseable."""
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        notebook_id="nb-123",
        cell_index=0,
        cell_type="code",
        source="print('hello')\nprint('world')",
        status="ok",
        execution_count=5,
        last_run_duration=1.23,
        outputs=[],
    )

    result = runner.invoke(
        app,
        ["notebook", "cell", "get", "nb-123", "--id", "cell-1", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["source"] == "print('hello')\nprint('world')"


def test_cell_get_by_index(mock_client, mock_api):
    """Test cell get command with --index."""
    mock_api.get_cell_by_index.return_value = Mock(
        id="cell-2",
        notebook_id="nb-123",
        cell_index=2,
        cell_type="code",
        source="print('index')",
        status="ok",
        execution_count=1,
        last_run_duration=0.5,
        outputs=[],
    )

    result = runner.invoke(
        app,
        ["notebook", "cell", "get", "nb-123", "--index", "2"],
    )

    assert result.exit_code == 0
    mock_api.get_cell_by_index.assert_called_once_with("nb-123", 2)


def test_cell_add(mock_client, mock_api):
    """Test cell add command."""
    mock_api.add_cell.return_value = Mock(
        id="cell-new",
        cell_index=0,
    )

    result = runner.invoke(app, ["notebook", "cell", "add", "nb-123", "x = 1"])

    assert result.exit_code == 0
    assert "cell-new" in result.output
    mock_api.add_cell.assert_called_once()


def test_cell_set_by_id(mock_client, mock_api):
    """Test cell set command."""
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        source_ot_version=3,
    )
    mock_api.update_cell_source.return_value = Mock(id="cell-1")

    result = runner.invoke(
        app,
        ["notebook", "cell", "set", "nb-123", "x = 2", "--id", "cell-1"],
    )

    assert result.exit_code == 0
    assert "updated" in result.output.lower()
    mock_api.update_cell_source.assert_called_once_with(
        "nb-123",
        "cell-1",
        "x = 2",
        expected_version=3,
    )


def test_cell_rm_by_id(mock_client, mock_api):
    """Test cell rm command."""
    result = runner.invoke(
        app,
        ["notebook", "cell", "rm", "nb-123", "--id", "cell-1", "--force"],
    )

    assert result.exit_code == 0
    mock_api.delete_cell.assert_called_once_with("nb-123", "cell-1")


def test_cell_execute_by_id(mock_client, mock_api):
    """Test cell execute command."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        status="ok",
        execution_count=5,
        last_run_duration=1.0,
        outputs=[],
    )

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--no-wait"],
    )

    assert result.exit_code == 0
    assert "exec-123" in result.output
    mock_api.execute_cell.assert_called_once_with(
        "nb-123",
        cell_id="cell-1",
        cell_index=None,
        source=None,
    )


def test_cell_execute_wait(mock_client, mock_api):
    """Test cell execute with wait."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        status="ok",
        execution_count=5,
        last_run_duration=1.0,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="result\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "result\n",
                },
            )
        ],
    )

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--wait"],
    )

    assert result.exit_code == 0
    assert "completed" in result.output.lower() or "result" in result.output


def test_cell_execute_wait_json_uses_last_run_duration(mock_client, mock_api):
    """Waited JSON output should use lastRunDuration and not legacy duration."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        status="ok",
        execution_count=8,
        last_run_duration=0.75,
        outputs=[],
    )

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--wait", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "ok"
    assert payload["executionCount"] == 8
    assert payload["lastRunDuration"] == 0.75
    assert "duration" not in payload


def test_cell_execute_wait_requires_outputs_to_change_from_baseline(mock_client, mock_api):
    """Wait should complete when outputs change, not merely because outputs already existed."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    baseline = Mock(
        id="cell-1",
        status=None,
        execution_count=None,
        last_run_duration=None,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="done\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "done\n",
                },
            )
        ],
    )
    updated = Mock(
        id="cell-1",
        status=None,
        execution_count=None,
        last_run_duration=None,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="new\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "new\n",
                },
            )
        ],
    )
    mock_api.get_cell.side_effect = [baseline, baseline, updated]

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--wait", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "completed"
    assert payload["outputs"][0]["text"] == "new\n"


def test_cell_execute_wait_detects_rerun_with_same_outputs_via_last_run_at(mock_client, mock_api):
    """Wait should complete for idempotent reruns when lastRunAt changes."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    baseline = Mock(
        id="cell-1",
        status=None,
        execution_count=1,
        last_run_at=1000,
        last_run_duration=0.5,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="same\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "same\n",
                },
            )
        ],
    )
    updated = Mock(
        id="cell-1",
        status="ok",
        execution_count=1,
        last_run_at=2000,
        last_run_duration=0.5,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="same\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "same\n",
                },
            )
        ],
    )
    mock_api.get_cell.side_effect = [baseline, updated]

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--wait", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "ok"
    assert payload["outputs"][0]["text"] == "same\n"


def test_cell_execute_wait_does_not_finish_while_execution_is_still_running(
    mock_client, mock_api
):
    """lastRunAt changes should not complete the wait loop before execution settles."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    baseline = Mock(
        id="cell-1",
        status=None,
        execution_count=1,
        last_run_at=1000,
        last_run_duration=0.5,
        outputs=[],
    )
    running = Mock(
        id="cell-1",
        status="running",
        execution_count=1,
        last_run_at=2000,
        last_run_duration=0.5,
        outputs=[],
    )
    completed = Mock(
        id="cell-1",
        status="ok",
        execution_count=1,
        last_run_at=2000,
        last_run_duration=0.6,
        outputs=[],
    )
    mock_api.get_cell.side_effect = [baseline, running, completed]

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--wait", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "ok"


def test_cell_execute_wait_ignores_zero_duration_while_status_is_starting(
    mock_client, mock_api
):
    """A placeholder lastRunDuration=0 must not short-circuit wait before completion."""
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    baseline = Mock(
        id="cell-1",
        status=None,
        execution_count=1,
        last_run_at=1000,
        last_run_duration=None,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="old\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "old\n",
                },
            )
        ],
    )
    starting = Mock(
        id="cell-1",
        status="starting",
        execution_count=1,
        last_run_at=1000,
        last_run_duration=0.0,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="old\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "old\n",
                },
            )
        ],
    )
    completed = Mock(
        id="cell-1",
        status="ok",
        execution_count=2,
        last_run_at=2000,
        last_run_duration=0.4,
        outputs=[
            Mock(
                output_type="stream",
                name="stdout",
                text="new\n",
                data=None,
                ename=None,
                evalue=None,
                traceback=None,
                execution_count=None,
                model_dump=lambda by_alias=True, exclude_none=True: {
                    "outputType": "stream",
                    "name": "stdout",
                    "text": "new\n",
                },
            )
        ],
    )
    mock_api.get_cell.side_effect = [baseline, starting, completed]

    result = runner.invoke(
        app,
        ["notebook", "cell", "execute", "nb-123", "--id", "cell-1", "--wait", "--json"],
    )

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["status"] == "ok"
    assert payload["outputs"][0]["text"] == "new\n"


def test_kernel_ensure_no_wait(mock_client, mock_api):
    """Kernel ensure should call API and return immediately."""
    mock_api.ensure_kernel.return_value = {"status": "starting"}

    result = runner.invoke(
        app,
        ["notebook", "kernel", "ensure", "nb-123", "--no-wait", "--json"],
    )

    assert result.exit_code == 0
    assert '"status": "starting"' in result.output
    mock_api.ensure_kernel.assert_called_once_with("nb-123")


def test_kernel_ensure_wait(mock_client, mock_api):
    """Kernel ensure wait should poll kernel status until ready."""
    mock_api.ensure_kernel.return_value = {"status": "starting"}
    mock_api.get_kernel_status.side_effect = [
        {"status": "busy", "message": "Kernel starting"},
        {"status": "idle"},
    ]

    result = runner.invoke(
        app,
        ["notebook", "kernel", "ensure", "nb-123", "--wait", "--timeout", "2", "--json"],
    )

    assert result.exit_code == 0
    assert '"status": "running"' in result.output
    assert mock_api.get_kernel_status.call_count == 2


def test_kernel_interrupt(mock_client, mock_api):
    """Kernel interrupt should call API once."""
    mock_api.interrupt_kernel.return_value = {"ok": True}

    result = runner.invoke(app, ["notebook", "kernel", "interrupt", "nb-123"])

    assert result.exit_code == 0
    assert "interrupted" in result.output.lower()
    mock_api.interrupt_kernel.assert_called_once_with("nb-123")


def test_kernel_restart(mock_client, mock_api):
    """Kernel restart should call API once."""
    mock_api.restart_kernel.return_value = {"ok": True}

    result = runner.invoke(app, ["notebook", "kernel", "restart", "nb-123"])

    assert result.exit_code == 0
    assert "restart" in result.output.lower()
    mock_api.restart_kernel.assert_called_once_with("nb-123")


def test_kernel_ttl_get(mock_client, mock_api):
    """Kernel ttl get should read current session ttl policy."""
    mock_api.get_document.return_value = Mock(
        metadata=Mock(kernel_session_id="session-1"),
    )
    mock_api.get.return_value = Mock(
        config={"ttlPolicy": {"persistent": False, "idleTtlSeconds": 300}},
        model_dump=lambda by_alias=True, exclude_none=True: {
            "config": {"ttlPolicy": {"persistent": False, "idleTtlSeconds": 300}}
        },
    )

    result = runner.invoke(app, ["notebook", "kernel", "ttl", "get", "nb-123", "--json"])

    assert result.exit_code == 0
    assert '"idleTtlSeconds": 300' in result.output


def test_kernel_ttl_set(mock_client, mock_api):
    """Kernel ttl set should forward policy updates."""
    mock_api.update_kernel_ttl_policy.return_value = {
        "success": True,
        "ttlPolicy": {
            "persistent": False,
            "idleTtlSeconds": 60,
            "snapshotFavor": "disk",
        },
    }

    result = runner.invoke(
        app,
        [
            "notebook",
            "kernel",
            "ttl",
            "set",
            "nb-123",
            "--idle-ttl",
            "60",
            "--snapshot-favor",
            "disk",
        ],
    )

    assert result.exit_code == 0
    assert "updated" in result.output.lower()
    mock_api.update_kernel_ttl_policy.assert_called_once_with(
        "nb-123",
        persistent=None,
        idle_ttl_seconds=60,
        snapshot_favor="disk",
        hard_kill_at=None,
        hard_kill_after_seconds=None,
    )


def test_cell_requires_exactly_one_selector(mock_client, mock_api):
    """Selector validation requires exactly one of --id or --index."""
    result_none = runner.invoke(app, ["notebook", "cell", "get", "nb-123"])
    assert result_none.exit_code == 1
    assert "Provide exactly one of --id or --index" in result_none.output

    result_both = runner.invoke(
        app,
        [
            "notebook",
            "cell",
            "get",
            "nb-123",
            "--id",
            "cell-1",
            "--index",
            "0",
        ],
    )
    assert result_both.exit_code == 1
    assert "Provide exactly one of --id or --index" in result_both.output


def test_cell_set_conflict_error_message(mock_client, mock_api):
    """Set should render a clear conflict message when expectedVersion mismatches."""
    mock_api.get_cell.return_value = Mock(
        id="cell-1",
        source_ot_version=1,
    )
    mock_api.update_cell_source.side_effect = APIError(
        status_code=409,
        message="Cell source version conflict",
        details={"currentVersion": 2},
    )

    result = runner.invoke(
        app,
        [
            "notebook",
            "cell",
            "set",
            "nb-123",
            "print('executed'); 123",
            "--id",
            "cell-1",
        ],
    )

    assert result.exit_code == 1
    assert "Version conflict" in result.output
    assert "current sourceOtVersion=2" in result.output


def test_cell_set_execute_by_id(mock_client, mock_api):
    """Set+execute should persist source first, then execute."""
    mock_api.update_cell_source.return_value = Mock(id="cell-1")
    mock_api.execute_cell.return_value = Mock(
        execution_id="exec-123",
        status="started",
    )
    mock_api.get_cell.side_effect = [
        Mock(
            id="cell-1",
            source_ot_version=1,
        ),
        Mock(
            id="cell-1",
            status=None,
            execution_count=None,
            last_run_duration=None,
            outputs=[],
        ),
        Mock(
            id="cell-1",
            status="ok",
            execution_count=6,
            last_run_duration=0.7,
            outputs=[],
        ),
    ]

    result = runner.invoke(
        app,
        [
            "notebook",
            "cell",
            "set",
            "nb-123",
            "print('executed'); 123",
            "--id",
            "cell-1",
            "--execute",
            "--wait",
            "--timeout",
            "45",
            "--json",
        ],
    )

    assert result.exit_code == 0
    assert '"status": "ok"' in result.output
    mock_api.update_cell_source.assert_called_once_with(
        "nb-123",
        "cell-1",
        "print('executed'); 123",
        expected_version=1,
    )
    mock_api.execute_cell.assert_called_once_with(
        "nb-123",
        cell_id="cell-1",
        cell_index=None,
        source=None,
    )


def test_cell_execute_all_runs_code_cells_in_order(mock_client, mock_api):
    """execute-all should skip non-code cells and run code cells sequentially."""
    mock_api.list_cells.return_value = [
        Mock(id="cell-a", cell_type="code"),
        Mock(id="cell-b", cell_type="markdown"),
        Mock(id="cell-c", cell_type="code"),
    ]
    mock_api.execute_cell.return_value = Mock(execution_id="exec-123", status="started")
    mock_api.get_cell.side_effect = [
        Mock(id="cell-a", status=None, execution_count=None, last_run_at=None, last_run_duration=None, outputs=[]),
        Mock(id="cell-a", status="ok", execution_count=1, last_run_at=1000, last_run_duration=0.1, outputs=[]),
        Mock(id="cell-c", status=None, execution_count=None, last_run_at=None, last_run_duration=None, outputs=[]),
        Mock(id="cell-c", status="ok", execution_count=2, last_run_at=2000, last_run_duration=0.1, outputs=[]),
    ]

    result = runner.invoke(app, ["notebook", "cell", "execute-all", "nb-123"])

    assert result.exit_code == 0
    mock_api.list_cells.assert_called_once_with("nb-123", include_outputs=False)
    assert mock_api.execute_cell.call_args_list == [
        call("nb-123", cell_id="cell-a", cell_index=None, source=None),
        call("nb-123", cell_id="cell-c", cell_index=None, source=None),
    ]


def test_cell_execute_all_skips_blank_code_cells(mock_client, mock_api):
    """execute-all should skip empty starter code cells."""
    mock_api.list_cells.return_value = [
        Mock(id="cell-empty", cell_type="code", source=""),
        Mock(id="cell-spaces", cell_type="code", source="   \n\t"),
        Mock(id="cell-a", cell_type="code", source="print('a')"),
    ]
    mock_api.execute_cell.return_value = Mock(execution_id="exec-123", status="started")
    mock_api.get_cell.side_effect = [
        Mock(id="cell-a", status=None, execution_count=None, last_run_at=None, last_run_duration=None, outputs=[]),
        Mock(id="cell-a", status="ok", execution_count=1, last_run_at=1000, last_run_duration=0.1, outputs=[]),
    ]

    result = runner.invoke(app, ["notebook", "cell", "execute-all", "nb-123"])

    assert result.exit_code == 0
    mock_api.execute_cell.assert_called_once_with(
        "nb-123",
        cell_id="cell-a",
        cell_index=None,
        source=None,
    )


def test_cell_execute_all_restarts_kernel_before_running(mock_client, mock_api):
    """execute-all --restart should restart and wait before execution."""
    mock_api.list_cells.return_value = [Mock(id="cell-a", cell_type="code")]
    mock_api.restart_kernel.return_value = {"ok": True}
    mock_api.get_kernel_status.side_effect = [
        {"status": "busy", "message": "Kernel starting"},
        {"status": "idle"},
    ]
    mock_api.execute_cell.return_value = Mock(execution_id="exec-123", status="started")
    mock_api.get_cell.side_effect = [
        Mock(id="cell-a", status=None, execution_count=None, last_run_at=None, last_run_duration=None, outputs=[]),
        Mock(id="cell-a", status="ok", execution_count=1, last_run_at=1000, last_run_duration=0.1, outputs=[]),
    ]

    result = runner.invoke(app, ["notebook", "cell", "execute-all", "nb-123", "--restart"])

    assert result.exit_code == 0
    mock_api.restart_kernel.assert_called_once_with("nb-123")
    assert mock_api.get_kernel_status.call_count == 2
    mock_api.execute_cell.assert_called_once_with(
        "nb-123",
        cell_id="cell-a",
        cell_index=None,
        source=None,
    )


def test_cell_execute_all_stops_after_first_error(mock_client, mock_api):
    """execute-all should stop after the first error and exit non-zero."""
    mock_api.list_cells.return_value = [
        Mock(id="cell-a", cell_type="code"),
        Mock(id="cell-b", cell_type="code"),
    ]
    mock_api.execute_cell.return_value = Mock(execution_id="exec-123", status="started")
    mock_api.get_cell.side_effect = [
        Mock(id="cell-a", status=None, execution_count=None, last_run_at=None, last_run_duration=None, outputs=[]),
        Mock(id="cell-a", status="error", execution_count=1, last_run_at=1000, last_run_duration=0.1, outputs=[]),
    ]

    result = runner.invoke(app, ["notebook", "cell", "execute-all", "nb-123"])

    assert result.exit_code == 1
    assert mock_api.execute_cell.call_args_list == [
        call("nb-123", cell_id="cell-a", cell_index=None, source=None),
    ]
    assert "stopped" in result.output.lower()


def test_cell_clear_outputs(mock_client, mock_api):
    """clear-outputs should call the notebook-level outputs endpoint."""
    mock_api.clear_notebook_outputs.return_value = {"clearedCellCount": 2}

    result = runner.invoke(
        app,
        ["notebook", "cell", "clear-outputs", "nb-123", "--force"],
    )

    assert result.exit_code == 0
    mock_api.clear_notebook_outputs.assert_called_once_with("nb-123")
    assert "cleared" in result.output.lower()
