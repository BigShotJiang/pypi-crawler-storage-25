"""Tests for AI Gateway CLI commands."""

import pytest
from typer.testing import CliRunner
from unittest.mock import Mock, patch

from agentenv.cli.app import app


runner = CliRunner()


class TestAICommands:
    """Test AI Gateway CLI commands."""

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_list_upstreams(self, mock_api_class, mock_get_settings):
        """Test list upstreams command."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        mock_api.list_upstreams.return_value = []
        mock_api_class.return_value = mock_api

        result = runner.invoke(app, ["ai", "upstreams", "list"])

        assert result.exit_code == 0
        mock_api.list_upstreams.assert_called_once()

    @patch("agentenv.cli.ai.get_settings")
    @patch("agentenv.cli.ai.AIGatewayAPI")
    def test_chat_command(self, mock_api_class, mock_get_settings):
        """Test chat command."""
        mock_settings = Mock()
        mock_settings.api_url = "http://test"
        mock_settings.api_key = "sk_test"
        mock_get_settings.return_value = mock_settings

        mock_api = Mock()
        # Mock streaming response - needs to be iterable
        mock_chunk = Mock()
        mock_chunk.choices = [Mock(delta=Mock(content="Hello!"))]
        mock_api.chat.create.return_value = [mock_chunk]
        mock_api_class.return_value = mock_api

        with patch.dict("os.environ", {"AGENTENV_AI_KEY": "cr_test"}):
            result = runner.invoke(app, ["ai", "chat", "Hello"])

        assert result.exit_code == 0
        assert "Hello!" in result.output
