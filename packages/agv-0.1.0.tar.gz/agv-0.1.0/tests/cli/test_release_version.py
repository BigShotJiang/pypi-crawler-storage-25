"""Tests for release version validation."""

from __future__ import annotations

import subprocess
import sys
from pathlib import Path

from agentenv import __version__


def test_release_version_script_accepts_matching_tag() -> None:
    """Matching tag and package versions should validate cleanly."""

    cli_root = Path(__file__).resolve().parents[2]
    completed = subprocess.run(
        [
            sys.executable,
            "scripts/check_release_version.py",
            "--tag",
            f"agv-v{__version__}",
        ],
        cwd=cli_root,
        check=True,
        capture_output=True,
        text=True,
    )

    assert "Validated release tag" in completed.stdout


def test_release_version_script_rejects_mismatched_tag() -> None:
    """A mismatched tag version should fail the release check."""

    cli_root = Path(__file__).resolve().parents[2]
    completed = subprocess.run(
        [
            sys.executable,
            "scripts/check_release_version.py",
            "--tag",
            "agv-v9.9.9",
        ],
        cwd=cli_root,
        check=False,
        capture_output=True,
        text=True,
    )

    assert completed.returncode != 0
    assert "does not match package version" in completed.stderr
