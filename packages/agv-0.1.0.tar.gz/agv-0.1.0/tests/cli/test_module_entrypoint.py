"""Regression tests for the module entrypoint."""

from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path


def test_python_m_agentenv_help_works() -> None:
    """`python -m agentenv --help` should stay usable as an install fallback."""

    cli_root = Path(__file__).resolve().parents[2]
    src_dir = cli_root / "src"
    env = os.environ.copy()
    existing_pythonpath = env.get("PYTHONPATH")
    env["PYTHONPATH"] = (
        f"{src_dir}{os.pathsep}{existing_pythonpath}" if existing_pythonpath else str(src_dir)
    )

    completed = subprocess.run(
        [sys.executable, "-m", "agentenv", "--help"],
        cwd=cli_root,
        env=env,
        check=True,
        capture_output=True,
        text=True,
    )

    assert "AgentEnv Cloud CLI" in completed.stdout
    assert "Usage:" in completed.stdout
