"""Integration tests for workspace CLI commands."""

from datetime import datetime, timezone
from types import SimpleNamespace
from unittest.mock import Mock, patch

from typer.testing import CliRunner

from agentenv.cli.app import app


runner = CliRunner()


def test_workspace_ls_json_shows_full_ids() -> None:
    """workspace ls --json should output full workspace UUIDs."""
    workspace_id = "51699bcc-7308-4715-a0e8-aa375806e264"
    owner_id = "ff80914b-eb24-4d3d-b6d8-8a149dc91a10"

    workspace = SimpleNamespace(
        id=workspace_id,
        name="cli-verify-ws",
        owner_id=owner_id,
        created_at=datetime.now(timezone.utc),
        model_dump=lambda by_alias=True, exclude_none=True: {
            "id": workspace_id,
            "name": "cli-verify-ws",
            "ownerId": owner_id,
            "createdAt": datetime.now(timezone.utc).isoformat(),
        },
    )

    with patch("agentenv.cli.workspace.get_client", return_value=Mock()):
        with patch("agentenv.cli.workspace.WorkspaceAPI") as mock_api_cls:
            mock_api_cls.return_value.list_all.return_value = [workspace]

            result = runner.invoke(app, ["workspace", "ls", "--json"])

    assert result.exit_code == 0
    assert workspace_id in result.output
    assert owner_id in result.output
