"""Tests for configuration command behavior."""

import json
from pathlib import Path

import pytest
from typer.testing import CliRunner

from agentenv.cli.app import app
from agentenv.config.defaults import reset_defaults_manager
from agentenv.config.settings import reset_settings

runner = CliRunner()


@pytest.fixture(autouse=True)
def reset_cli_state() -> None:
    """Reset cached settings/default managers between test runs."""
    reset_settings()
    reset_defaults_manager()
    yield
    reset_settings()
    reset_defaults_manager()


def test_config_root_shows_configuration(monkeypatch, tmp_path: Path) -> None:
    """`av config` should show configuration instead of erroring."""
    monkeypatch.setenv("HOME", str(tmp_path))

    result = runner.invoke(app, ["config"])

    assert result.exit_code == 0
    assert "Configuration" in result.output


def test_global_json_config_show_outputs_object(monkeypatch, tmp_path: Path) -> None:
    """Global --json should make config show emit a JSON object."""
    monkeypatch.setenv("HOME", str(tmp_path))

    result = runner.invoke(app, ["--json", "config", "show"])

    assert result.exit_code == 0
    payload = json.loads(result.output)
    assert payload["API URL"] == "http://localhost:3000"
    assert payload["JSON Output"] == "True"


def test_set_type_persists_only_type_key(monkeypatch, tmp_path: Path) -> None:
    """Setting a preset type should not persist derived cpu/memory overrides."""
    monkeypatch.setenv("HOME", str(tmp_path))

    result = runner.invoke(app, ["set", "type", "xl"])

    assert result.exit_code == 0
    defaults = json.loads((tmp_path / ".agentenv" / "defaults.json").read_text())
    assert defaults == {"type": "xl"}


def test_unset_type_clears_stale_derived_resources(monkeypatch, tmp_path: Path) -> None:
    """Unsetting type should clear cpu/memory only when they were derived from that preset."""
    monkeypatch.setenv("HOME", str(tmp_path))

    defaults_dir = tmp_path / ".agentenv"
    defaults_dir.mkdir(mode=0o700, exist_ok=True)
    (defaults_dir / "defaults.json").write_text(
        json.dumps({"type": "xl", "cpu": 16000, "memory": 32768})
    )

    result = runner.invoke(app, ["config", "unset", "type"])

    assert result.exit_code == 0
    defaults = json.loads((defaults_dir / "defaults.json").read_text())
    assert defaults == {}
