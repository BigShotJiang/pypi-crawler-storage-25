"""Regression tests for code / CLI / docs / Mintlify alignment."""

from __future__ import annotations

import json
import subprocess
from pathlib import Path

import pytest
from typer.testing import CliRunner

from agentenv.cli.app import app

runner = CliRunner()
REPO_ROOT = Path(__file__).resolve().parents[3]
ACTIVE_DOCS = [
    REPO_ROOT / "api-server/.env.example",
    REPO_ROOT / "cli/README.md",
    REPO_ROOT / "docs/README.md",
    REPO_ROOT / "docs/api/API.md",
    REPO_ROOT / "docs/api/notebooks-curl.md",
    REPO_ROOT / "docs/api-server/README.md",
    REPO_ROOT / "docs/configuration/configuration.md",
    REPO_ROOT / "docs/development/development.md",
    REPO_ROOT / "docs/operations/operations.md",
    REPO_ROOT / "docs/testing/README.md",
    REPO_ROOT / "docs/testing/e2e/MANUAL_TESTING.md",
    REPO_ROOT / "mintlify_docs/README.md",
    REPO_ROOT / "mintlify_docs/index.mdx",
    REPO_ROOT / "mintlify_docs/authentication.mdx",
    REPO_ROOT / "mintlify_docs/quickstart.mdx",
    REPO_ROOT / "mintlify_docs/api/notebooks/overview.mdx",
    REPO_ROOT / "mintlify_docs/api/sandboxes/overview.mdx",
    REPO_ROOT / "mintlify_docs/api/workflows/overview.mdx",
    REPO_ROOT / "mintlify_docs/api/workspaces/overview.mdx",
]
FORBIDDEN_ACTIVE_DOC_SNIPPETS = [
    "AUTH0_DOMAIN",
    "AUTH0_CLIENT_ID",
    "AUTH0_CLIENT_SECRET",
    "AUTH0_AUDIENCE",
    "AUTH0_JWKS_CACHE_TTL_MS",
    "X-CSRF-Token",
    "Auth0-issued JWTs",
    "YOUR_AUTH0_DOMAIN",
]


@pytest.mark.parametrize("path", ACTIVE_DOCS, ids=lambda path: path.name)
def test_active_docs_do_not_reference_removed_auth_or_csrf_contracts(
    path: Path,
) -> None:
    """Current-facing docs should not drift back to removed auth/CSRF guidance."""

    text = path.read_text(encoding="utf-8")

    for snippet in FORBIDDEN_ACTIVE_DOC_SNIPPETS:
        assert snippet not in text, f"{path} still contains forbidden snippet: {snippet}"


@pytest.mark.parametrize(
    ("argv", "expected_fragment"),
    [
        (["--help"], "workspace"),
        (["notebook", "session", "--help"], "create"),
        (["workspace", "--help"], "secret-set"),
        (["site", "--help"], "deploy"),
        (["image", "--help"], "build"),
        (["cluster", "ray", "--help"], "Cluster shape"),
        (["app", "--help"], "deploy"),
        (["browser", "--help"], "cdp"),
        (["ai", "--help"], "upstreams"),
        (["workflow", "--help"], "execute-in-memory"),
    ],
)
def test_documented_cli_command_groups_are_available(
    argv: list[str],
    expected_fragment: str,
) -> None:
    """Commands referenced by current docs should remain discoverable via help."""

    result = runner.invoke(app, argv)

    assert result.exit_code == 0, result.output
    assert expected_fragment in result.output


def test_checked_in_mintlify_openapi_matches_regenerated_schema(tmp_path: Path) -> None:
    """Mintlify OpenAPI must stay in sync with the current api-server export."""

    output_path = tmp_path / "openapi.json"
    completed = subprocess.run(
        [
            "npm",
            "run",
            "docs:mintlify:openapi",
            "--",
            str(output_path),
        ],
        cwd=REPO_ROOT / "api-server",
        check=True,
        capture_output=True,
        text=True,
    )

    assert "Wrote OpenAPI schema" in completed.stdout
    checked_in = (REPO_ROOT / "mintlify_docs/api-reference/openapi.json").read_text(
        encoding="utf-8"
    )
    regenerated = output_path.read_text(encoding="utf-8")
    assert regenerated == checked_in


def test_workflow_openapi_contract_exposes_real_request_shapes() -> None:
    """Workflow request DTOs in Mintlify OpenAPI should not collapse to empty objects."""

    document = json.loads(
        (REPO_ROOT / "mintlify_docs/api-reference/openapi.json").read_text(encoding="utf-8")
    )
    schemas = document["components"]["schemas"]

    assert "name" in schemas["CreateWorkflowDto"]["properties"]
    assert "definition" in schemas["CreateWorkflowDto"]["properties"]
    assert "status" in schemas["UpdateWorkflowDto"]["properties"]
    assert "input" in schemas["ExecuteWorkflowDto"]["properties"]
    assert "definition" in schemas["ExecuteInMemoryDto"]["properties"]


def test_workflow_openapi_marks_optional_query_params_as_optional() -> None:
    """Workflow query parameters should match controller optionality."""

    document = json.loads(
        (REPO_ROOT / "mintlify_docs/api-reference/openapi.json").read_text(encoding="utf-8")
    )
    workflows_get = document["paths"]["/workflows"]["get"]["parameters"]
    executions_get = document["paths"]["/workflows/{id}/executions"]["get"]["parameters"]
    metrics_get = document["paths"]["/workflows/{id}/metrics"]["get"]["parameters"]
    series_get = document["paths"]["/workflows/{id}/metrics/timeseries"]["get"]["parameters"]

    assert workflows_get[0]["name"] == "status"
    assert workflows_get[0]["required"] is False

    optional_execution_params = {item["name"]: item["required"] for item in executions_get}
    assert optional_execution_params["page"] is False
    assert optional_execution_params["limit"] is False
    assert optional_execution_params["status"] is False
    assert optional_execution_params["from"] is False
    assert optional_execution_params["to"] is False

    optional_metric_params = {item["name"]: item["required"] for item in metrics_get}
    assert optional_metric_params["from"] is False
    assert optional_metric_params["to"] is False

    optional_series_params = {item["name"]: item["required"] for item in series_get}
    assert optional_series_params["interval"] is False
    assert optional_series_params["from"] is False
    assert optional_series_params["to"] is False


def test_handwritten_api_doc_mentions_current_workflow_routes() -> None:
    """The handwritten API doc should mention the main workflow routes it claims to cover."""

    text = (REPO_ROOT / "docs/api/API.md").read_text(encoding="utf-8")

    assert "GET /v1/workflows/{workflow_id}" in text
    assert "PUT /v1/workflows/{workflow_id}" in text
    assert "DELETE /v1/workflows/{workflow_id}" in text
    assert "GET /v1/workflows/{workflow_id}/executions/{execution_id}" in text
    assert "POST /v1/workflows/{workflow_id}/executions/{execution_id}/cancel" in text
