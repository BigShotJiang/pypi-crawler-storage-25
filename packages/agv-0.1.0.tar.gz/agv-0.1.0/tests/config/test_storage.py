"""Tests for credential storage fallback behavior."""

import json
from pathlib import Path
from unittest.mock import Mock

from agentenv.config import storage as storage_module
from agentenv.config.storage import CredentialStorage


def test_uses_file_storage_when_keyring_module_unavailable(
    monkeypatch,
    tmp_path: Path,
) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", False)

    storage = CredentialStorage()
    storage.set_api_key("sk_test_file")

    assert storage._use_keyring is False
    assert storage.get_api_key() == "sk_test_file"
    assert (tmp_path / ".agentenv" / "credentials.json").exists()


def test_gateway_key_round_trips_through_storage(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", False)

    storage = CredentialStorage()
    storage.set_gateway_key("cr_test_gateway")

    assert storage.get_gateway_key() == "cr_test_gateway"
    assert json.loads((tmp_path / ".agentenv" / "credentials.json").read_text()) == {
        "gateway_key": "cr_test_gateway"
    }


def test_keeps_keyring_backend_when_runtime_is_healthy(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    mock_keyring = Mock()
    mock_keyring.get_password.return_value = "sk_test_keyring"
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    storage.set_api_key("sk_test_keyring")

    assert storage._use_keyring is True
    assert storage.get_api_key() == "sk_test_keyring"
    assert not (tmp_path / ".agentenv" / "credentials.json").exists()


def test_falls_back_to_file_when_keyring_set_fails(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    mock_keyring = Mock()
    mock_keyring.set_password.side_effect = RuntimeError("backend not available")
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    storage.set_api_key("sk_test_fallback")

    assert storage._use_keyring is False
    assert storage.get_api_key() == "sk_test_fallback"
    assert (tmp_path / ".agentenv" / "credentials.json").exists()


def test_falls_back_to_file_when_keyring_get_fails(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    creds_file = tmp_path / ".agentenv" / "credentials.json"
    creds_file.parent.mkdir(mode=0o700, exist_ok=True)
    creds_file.write_text(json.dumps({"api_key": "sk_test_from_file"}))

    mock_keyring = Mock()
    mock_keyring.get_password.side_effect = RuntimeError("prompt dismissed")
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    value = storage.get_api_key()

    assert value == "sk_test_from_file"
    assert storage._use_keyring is False


def test_clear_all_clears_file_after_keyring_failure(monkeypatch, tmp_path: Path) -> None:
    monkeypatch.setenv("HOME", str(tmp_path))
    monkeypatch.setattr(storage_module, "KEYRING_AVAILABLE", True)

    creds_file = tmp_path / ".agentenv" / "credentials.json"
    creds_file.parent.mkdir(mode=0o700, exist_ok=True)
    creds_file.write_text(json.dumps({"api_key": "sk_test_from_file"}))

    mock_keyring = Mock()
    mock_keyring.delete_password.side_effect = RuntimeError("collection unavailable")
    mock_keyring.errors.PasswordDeleteError = ValueError
    monkeypatch.setattr(storage_module, "keyring", mock_keyring)

    storage = CredentialStorage()
    storage.clear_all()

    assert storage._use_keyring is False
    assert not creds_file.exists()
