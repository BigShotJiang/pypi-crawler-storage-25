"""Tests for AI SDK."""

import pytest
from unittest.mock import Mock, patch

from agentenv.sdk.ai import AIClient, ChatCompletions


class TestAIClient:
    """Test AIClient SDK."""

    @patch("agentenv.sdk.ai.Client")
    def test_init_with_api_key(self, mock_client_class):
        """Test initialization with API key."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client

        client = AIClient(api_key="cr_test123")

        assert client.api_key == "cr_test123"
        assert client.chat is not None
        assert client.embeddings is not None

    @patch("agentenv.sdk.ai.Client")
    @patch.dict("os.environ", {"AGENTENV_AI_KEY": "cr_env_key"})
    def test_init_from_env(self, mock_client_class):
        """Test initialization from environment variable."""
        mock_client = Mock()
        mock_client_class.return_value = mock_client

        client = AIClient()

        assert client.api_key == "cr_env_key"


class TestChatCompletions:
    """Test ChatCompletions SDK."""

    def test_create_non_streaming(self):
        """Test non-streaming chat completion."""
        mock_api = Mock()
        mock_response = Mock()
        mock_response.id = "chat_123"
        mock_response.choices = [Mock(message=Mock(content="Hello!"))]
        mock_api.create.return_value = mock_response

        chat = ChatCompletions(mock_api)
        response = chat.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hi"}],
            stream=False,
        )

        assert response.id == "chat_123"
        mock_api.create.assert_called_once()

    def test_create_with_message_objects(self):
        """Test chat with Message objects."""
        mock_api = Mock()
        mock_response = Mock()
        mock_response.id = "chat_123"
        mock_response.choices = [Mock(message=Mock(content="Hello!"))]
        mock_api.create.return_value = mock_response

        from agentenv.api.models import Message

        chat = ChatCompletions(mock_api)
        response = chat.create(
            model="gpt-4",
            messages=[Message(role="user", content="Hi")],
        )

        assert response.id == "chat_123"
