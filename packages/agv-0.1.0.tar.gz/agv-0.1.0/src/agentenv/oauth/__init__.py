"""OAuth authentication flow for AgentEnv CLI."""
