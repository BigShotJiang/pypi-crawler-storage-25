"""OAuth authentication flow for AgentEnv CLI."""

import secrets
import socket
import threading
import time
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, HTTPServer
from typing import Any


class OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP server handler for OAuth callback."""

    def __init__(self, *args: Any, callback_queue: dict[str, Any], **kwargs: Any):
        """Initialize handler.

        Args:
            *args: Positional args for BaseHTTPRequestHandler
            callback_queue: Dictionary to store callback data
            **kwargs: Keyword args for BaseHTTPRequestHandler
        """
        self.callback_queue = callback_queue
        super().__init__(*args, **kwargs)

    def do_GET(self) -> None:  # noqa: N802
        """Handle GET request for OAuth callback."""
        parsed = urllib.parse.urlparse(self.path)
        params = urllib.parse.parse_qs(parsed.query)

        # Validate state parameter to prevent CSRF
        received_state = params.get("state", [None])[0]
        expected_state = self.callback_queue.get("state")

        if received_state != expected_state:
            self.callback_queue["error"] = "invalid_state"
            self.send_response(400)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"""
                <html>
                <head><title>Authentication Failed</title></head>
                <body>
                    <h1>Authentication Failed</h1>
                    <p>Invalid state parameter. This could indicate a security issue.</p>
                </body>
                </html>
                """
            )
            return

        # Store the result - expecting token directly from frontend
        if "token" in params:
            self.callback_queue["token"] = params["token"][0]
            self.callback_queue["error"] = None
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"""
                <html>
                <head><title>Authentication Successful</title></head>
                <body>
                    <h1>Authentication Successful!</h1>
                    <p>You can close this window and return to the terminal.</p>
                    <script>window.close();</script>
                </body>
                </html>
                """
            )
        elif "error" in params:
            self.callback_queue["token"] = None
            error_msg = params.get("error", ["unknown"])[0]
            error_description = params.get("error_description", [""])[0]
            self.callback_queue["error"] = f"{error_msg}: {error_description}" if error_description else error_msg
            self.send_response(400)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"""
                <html>
                <head><title>Authentication Failed</title></head>
                <body>
                    <h1>Authentication Failed</h1>
                    <p>You can close this window and return to the terminal.</p>
                </body>
                </html>
                """
            )
        else:
            self.send_response(200)
            self.send_header("Content-type", "text/html")
            self.end_headers()
            self.wfile.write(
                b"""
                <html>
                <head><title>AgentEnv CLI Callback</title></head>
                <body>
                    <h1>Waiting for authentication...</h1>
                    <p>This page should not be accessed directly.</p>
                </body>
                </html>
                """
            )

    def log_message(self, format: str, *args: Any) -> None:  # noqa: A002
        """Suppress log messages."""
        pass


def get_callback_handler(callback_queue: dict[str, Any]) -> type[OAuthCallbackHandler]:
    """Factory function to create handler with callback queue.

    Args:
        callback_queue: Dictionary to store callback data

    Returns:
        Handler class
    """

    def handler(*args: Any, **kwargs: Any) -> OAuthCallbackHandler:
        return OAuthCallbackHandler(*args, callback_queue=callback_queue, **kwargs)

    return handler


def find_free_port(start_port: int = 50391, bind_host: str = "127.0.0.1") -> int:
    """Find a free port starting from the given port.

    Args:
        start_port: Port to start checking from
        bind_host: Host to bind while probing ports

    Returns:
        Available port number
    """
    for port in range(start_port, start_port + 100):
        try:
            with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                s.bind((bind_host, port))
                return port
        except OSError:
            continue
    raise RuntimeError("Could not find a free port")


def run_browser_login_flow(
    frontend_url: str,
    port: int = 50391,
    open_browser: bool = True,
    timeout: int = 300,
    callback_host: str = "localhost",
    callback_bind_host: str = "127.0.0.1",
) -> tuple[str | None, str | None]:
    """Run browser-based login flow with JWT callback.

    SECURITY: Uses state parameter to prevent CSRF.

    Args:
        frontend_url: Frontend login URL (e.g., http://localhost:3000/login)
        port: Port for callback server (default: 50391)
        open_browser: Whether to automatically open browser
        timeout: Timeout in seconds
        callback_host: Host used in callback URL sent to frontend
        callback_bind_host: Host address to bind the local callback server

    Returns:
        Tuple of (jwt_token, error) - one will be None
    """
    # Generate secure random state for CSRF protection
    state = secrets.token_urlsafe(32)

    callback_queue: dict[str, Any] = {
        "token": None,
        "error": None,
        "state": state,
    }

    # Find a free port
    try:
        port = find_free_port(port, bind_host=callback_bind_host)
    except RuntimeError:
        return None, "Could not find available port"

    # Start callback server
    server = HTTPServer((callback_bind_host, port), get_callback_handler(callback_queue))

    def run_server():
        server.serve_forever()

    server_thread = threading.Thread(target=run_server, daemon=True)
    server_thread.start()

    # Build callback URL
    callback_url = f"http://{callback_host}:{port}/callback"

    # Build login URL with callback and state parameters
    login_url = f"{frontend_url}"
    if "?" in frontend_url:
        login_url += f"&cli_callback={urllib.parse.quote(callback_url)}&state={state}"
    else:
        login_url += f"?cli_callback={urllib.parse.quote(callback_url)}&state={state}"

    # Open browser
    if open_browser:
        try:
            webbrowser.open(login_url)
            print(f"\nOpening browser for login...")
        except Exception:
            print(f"\nCould not open browser automatically.")

    print(f"If browser doesn't open, visit this URL:")
    print(f"  {login_url}")
    print(f"\nWaiting for authentication callback on {callback_url}")
    print("Press Ctrl+C to cancel.\n")

    # Wait for callback
    start_time = time.time()
    while callback_queue["token"] is None and callback_queue["error"] is None:
        if time.time() - start_time > timeout:
            server.shutdown()
            return None, "timeout"
        time.sleep(0.1)

    server.shutdown()

    return callback_queue["token"], callback_queue["error"]
