"""Main AgentEnv CLI application."""

import sys
from pathlib import Path

import typer

from .. import __version__
from ..config.settings import get_settings, normalize_api_url
from ..ui.tables import emit_json, json_output_enabled, print_error, print_success
from . import (
    ai,
    analytics,
    app_cmd,
    auth,
    billing,
    browser,
    config_cmd,
    cluster,
    file,
    image,
    notebook,
    sandbox,
    site,
    snapshot,
    workflow,
    workspace,
)

# Create main Typer app
app = typer.Typer(
    name="av",
    help="AgentEnv Cloud CLI - Manage containers, sandboxes, and more",
    no_args_is_help=True,
    add_completion=True,
    rich_markup_mode="rich",
)

# Global state for context
_context_state: dict = {}


def get_global_state() -> dict:
    """Get global state dictionary."""
    return _context_state


# =============================================================================
# Callback for global options
# =============================================================================

@app.callback()
def main(
    ctx: typer.Context,
    config: Path | None = typer.Option(
        None,
        "--config",
        "-c",
        help="Config file path",
    ),
    api_url: str | None = typer.Option(
        None,
        "--api-url",
        help="API server URL",
    ),
    api_key: str | None = typer.Option(
        None,
        "--api-key",
        help="API key for authentication",
    ),
    debug: bool = typer.Option(
        False,
        "--debug",
        help="Enable debug output",
    ),
    json_output: bool = typer.Option(
        False,
        "--json",
        help="Output in JSON format",
    ),
    workspace: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID",
    ),
) -> None:
    """AgentEnv Cloud CLI - Manage containers, sandboxes, and more.

    \b
    Examples:
        av login --api-key sk_live_xxxxx
        av run --type xl -- python3 -m http.server
        av ls
        av logs -f <id>

    \b
    For more help on each command:
        av <command> --help
    """
    # Load settings
    settings = get_settings(reload=True)

    # Apply overrides from command line
    if config:
        import yaml
        if config.exists():
            with open(config) as f:
                config_data = yaml.safe_load(f)
                if config_data:
                    for key, value in config_data.items():
                        if hasattr(settings, key):
                            setattr(settings, key, value)

    if api_url:
        settings.api_url = normalize_api_url(api_url)
    if api_key:
        settings.api_key = api_key
    if workspace:
        settings.workspace = workspace
    if debug:
        settings.debug = True
    if json_output:
        settings.json_output = True

    # Store settings in context for subcommands
    ctx.ensure_object(dict)
    ctx.obj["settings"] = settings

    # Store in global state too for easy access
    _context_state["settings"] = settings
    _context_state["ctx"] = ctx


# Authentication (also available as root commands)
app.add_typer(auth.app, name="auth")

# Sandbox management
app.add_typer(sandbox.app, name="sandbox")

# Snapshot management
app.add_typer(snapshot.app, name="snapshot")

# Browser sessions
app.add_typer(browser.app, name="browser")

# Notebook sessions
app.add_typer(notebook.app, name="notebook")

# Workspace management
app.add_typer(workspace.app, name="workspace")

# Billing
app.add_typer(billing.app, name="billing")

# Clusters
app.add_typer(cluster.app, name="cluster")
app.add_typer(cluster.app, name="clusters")  # Alias

# File storage
app.add_typer(file.app, name="file")

# Configuration
app.add_typer(config_cmd.app, name="config")

# Images
app.add_typer(image.app, name="image")

# App deployments
app.add_typer(app_cmd.app, name="app")
app.add_typer(app_cmd.app, name="apps")  # Alias

# Workflows
app.add_typer(workflow.app, name="workflow")
app.add_typer(workflow.app, name="workflows")  # Alias

# AI Gateway
app.add_typer(ai.app, name="ai")

# Analytics
app.add_typer(analytics.app, name="analytics")

# Static sites
app.add_typer(site.app, name="site")
app.add_typer(site.app, name="sites")  # Alias


# =============================================================================
# Root-level convenience commands
# =============================================================================

@app.command()
def login(
    ctx: typer.Context,
    api_key: str | None = typer.Option(None, "--api-key", help="API key"),
    username: str | None = typer.Option(None, "--username", "-u", help="Username"),
    password: str | None = typer.Option(None, "--password", "-p", help="Password"),
    public_host: str | None = typer.Option(
        None,
        "--public-host",
        help="Public host/IP for remote browser login callback",
    ),
    callback_port: int = typer.Option(
        50391,
        "--callback-port",
        help="Local callback server port for browser login",
    ),
) -> None:
    """Authenticate with AgentEnv Cloud.

    Opens browser for login. After successful authentication,
    you'll be redirected back to the CLI with a JWT token.

    Examples:
        av login
        av login --api-key sk_live_xxxxx
        av login --public-host 177.54.159.23
    """
    from .auth import login as auth_login
    auth_login(ctx, api_key, username, password, public_host, callback_port)


@app.command()
def logout() -> None:
    """Logout and clear credentials.

    Example:
        av logout
    """
    from .auth import logout as auth_logout
    auth_logout()


@app.command("run")
def run(
    ctx: typer.Context,
    name: str | None = typer.Option(None, "--name", help="Sandbox name"),
    type: str | None = typer.Option(None, "--type", "-t", help="Sandbox type"),
    sandbox: str | None = typer.Option(None, "--sandbox", help="Alias for --type"),
    image: str | None = typer.Option(None, "--image", help="Container image"),
    image_tag: str | None = typer.Option(None, "--image-tag", help="Image tag to resolve"),
    snapshot: str | None = typer.Option(None, "--snapshot", help="Restore from snapshot"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    gpu: int = typer.Option(0, "--gpu", help="GPU count"),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    env: list[str] = typer.Option([], "--env", "-e", help="Environment variables"),
    expose: list[str] = typer.Option([], "--expose", "-p", help="Expose ports"),
    secret: list[str] = typer.Option([], "--secret", help="Inject secrets"),
    region: str | None = typer.Option(None, "--region", help="Region"),
    max_lifetime_seconds: int | None = typer.Option(
        None,
        "--max-lifetime-seconds",
        help="Maximum lifetime in seconds (starts when sandbox is running)",
    ),
    follow: bool = typer.Option(
        True,
        "--follow/--no-follow",
        help="Follow lifecycle logs after sandbox creation",
    ),
    command: list[str] = typer.Argument(None, help="Command to run"),
) -> None:
    """Create and run a sandbox.

    Examples:
        av run -- python3 -m http.server
        av run --type xl --expose 8080:http -- python3 -m http.server
    """
    from .sandbox import run_sandbox
    run_sandbox(
        ctx,
        name=name,
        type=type,
        sandbox=sandbox,
        image=image,
        image_tag=image_tag,
        snapshot=snapshot,
        cpu=cpu,
        memory=memory,
        gpu=gpu,
        gpu_type=gpu_type,
        env=env,
        expose=expose,
        secret=secret,
        region=region,
        max_lifetime_seconds=max_lifetime_seconds,
        follow=follow,
        command=command,
    )


@app.command("ls")
def list_sandboxes_cmd(
    all: bool = typer.Option(False, "--all", "-a", help="Include stopped sandboxes"),
) -> None:
    """List sandboxes.

    Example:
        av ls
    """
    from .sandbox import list_sandboxes
    list_sandboxes(all)


@app.command("ps", deprecated=True)
def list_sandboxes_ps_cmd(
    all: bool = typer.Option(False, "--all", "-a", help="Include stopped sandboxes"),
) -> None:
    """List sandboxes (alias for ls).

    Example:
        av ps
    """
    from .sandbox import list_sandboxes
    list_sandboxes(all)


@app.command()
def logs(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow logs"),
    tail: int | None = typer.Option(None, "--tail", "-n", help="Number of lines"),
) -> None:
    """View sandbox logs.

    Example:
        av logs -f sb_abc123
    """
    from .sandbox import print_logs
    print_logs(sandbox_id, follow, tail)


@app.command()
def stop(sandbox_id: str = typer.Argument(..., help="Sandbox ID")) -> None:
    """Stop a sandbox.

    Example:
        av stop sb_abc123
    """
    from .sandbox import stop as stop_sandbox
    stop_sandbox(sandbox_id)


@app.command()
def start(sandbox_id: str = typer.Argument(..., help="Sandbox ID")) -> None:
    """Start a stopped sandbox.

    Example:
        av start sb_abc123
    """
    from .sandbox import start as start_sandbox
    start_sandbox(sandbox_id)


@app.command("rm")
def delete_sandbox_cmd(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete"),
) -> None:
    """Delete a sandbox.

    Example:
        av rm sb_abc123
    """
    from .sandbox import delete_sandbox
    delete_sandbox(sandbox_id, force)


@app.command()
def inspect(sandbox_id: str = typer.Argument(..., help="Sandbox ID")) -> None:
    """Show sandbox details.

    Example:
        av inspect sb_abc123
    """
    from .sandbox import inspect as inspect_sandbox
    inspect_sandbox(sandbox_id)


@app.command()
def expose(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID"),
    port: int = typer.Argument(..., help="Container port"),
    port_type: str = typer.Option("tcp", "--type", "-t", help="Port type"),
) -> None:
    """Expose a port on a sandbox.

    Example:
        av expose sb_abc123 8080
    """
    from .sandbox import expose_port_cli
    expose_port_cli(sandbox_id, port, port_type)


@app.command()
def url(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID"),
    port: int | None = typer.Argument(None, help="Container port"),
) -> None:
    """Get sandbox URL.

    Example:
        av url sb_abc123 8080
    """
    from .sandbox import url_cli
    url_cli(sandbox_id, port)


@app.command()
def set(
    ctx: typer.Context,
    key: str = typer.Argument(None, help="Configuration key"),
    value: str = typer.Argument(None, help="Configuration value"),
) -> None:
    """Set configuration value.

    Examples:
        av set type xl
        av set image python:3.11
        av set workspace wk_abc123
    """
    from .config_cmd import set_value
    set_value(ctx, key, value)


@app.command()
def balance(
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Show account balance.

    Example:
        av balance
    """
    from .billing import show_balance
    show_balance(workspace)


@app.command()
def health() -> None:
    """Check API health.

    Example:
        av health
    """
    import httpx

    settings = get_settings()

    try:
        api_url = normalize_api_url(settings.api_url)
        response = httpx.get(f"{api_url}/v1/health", timeout=10)
        if response.status_code == 200:
            data = response.json()
            if json_output_enabled():
                payload = {"healthy": True, "apiUrl": api_url}
                if "version" in data:
                    payload["version"] = data["version"]
                emit_json(payload)
                return

            print_success("API is healthy")
            if "version" in data:
                print(f"  Version: {data['version']}")
        else:
            print_error(f"API returned status {response.status_code}")
            raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to connect to API: {e}")
        raise typer.Exit(1)


@app.command()
def version() -> None:
    """Show version information.

    Example:
        av version
    """
    from rich.console import Console
    from rich.table import Table

    version_data = {
        "agentenvCli": __version__,
        "python": f"{sys.version_info.major}.{sys.version_info.minor}.{sys.version_info.micro}",
    }
    if json_output_enabled():
        emit_json(version_data)
        return

    console = Console()
    table = Table(show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("AgentEnv CLI", version_data["agentenvCli"])
    table.add_row("Python", version_data["python"])

    console.print(table)


# =============================================================================
# Entry point
# =============================================================================

def main_cli() -> None:
    """Main entry point for the CLI."""
    app()


if __name__ == "__main__":
    main_cli()
