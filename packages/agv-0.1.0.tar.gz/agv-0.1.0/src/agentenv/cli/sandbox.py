"""Sandbox CLI commands."""

import time
from datetime import datetime
from typing import Any

import typer

from ..api.client import APIError, Client
from ..api.sandbox import SandboxAPI
from ..config.defaults import get_defaults_manager
from ..config.settings import get_settings
from ..spec import SandboxSpecError
from ..spec import resolve_sandbox_type as _resolve_sandbox_type
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_error,
    print_ports_table,
    print_sandbox_detail,
    print_sandbox_table,
    print_success,
    print_warning,
)

app = typer.Typer(help="Sandbox management commands")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def resolve_sandbox_id(client: Client, sandbox_id: str) -> str:
    """Resolve sandbox ID prefix to full ID.

    Args:
        client: API client
        sandbox_id: Full or partial sandbox ID

    Returns:
        Full sandbox ID

    Raises:
        typer.Exit: If sandbox not found or ambiguous
    """
    # If it looks like a full UUID (36 chars with hyphens), use as-is
    if len(sandbox_id) == 36 and sandbox_id.count("-") == 4:
        return sandbox_id

    # Otherwise, try to find a match by prefix
    api = SandboxAPI(client)
    try:
        sandboxes = api.list_all()
    except APIError:
        # If list fails, return as-is and let the API handle it
        return sandbox_id

    # Find sandboxes that start with the given prefix
    matches = [s for s in sandboxes if s.id.startswith(sandbox_id)]

    if len(matches) == 0:
        print_error(f"No sandbox found with ID prefix '{sandbox_id}'")
        raise typer.Exit(1)
    elif len(matches) == 1:
        return matches[0].id
    else:
        # Multiple matches - show them
        print_warning(f"Multiple sandboxes match '{sandbox_id}':")
        print_sandbox_table(matches)
        raise typer.Exit(1)


def resolve_sandbox_type(type_name: str) -> tuple[int, int]:
    """Resolve sandbox type to CPU and memory values.

    Args:
        type_name: Type name (micro, small, medium, large, xl)

    Returns:
        Tuple of (cpu_millis, memory_mb)
    """
    try:
        return _resolve_sandbox_type(type_name)
    except SandboxSpecError as e:
        raise typer.BadParameter(str(e)) from e


def build_sandbox_request(
    settings,
    type_name: str | None,
    image: str | None,
    cpu: int | None,
    memory: int | None,
    gpu: int,
    gpu_type: str | None,
    env: list[str],
    expose: list[str],
    secret: list[str],
    region: str | None,
    max_lifetime_seconds: int | None,
    args: list[str],
    name: str | None = None,
    snapshot_id: str | None = None,
) -> dict:
    """Build sandbox creation request.

    Args:
        settings: Settings instance
        type_name: Sandbox type preset
        image: Container image
        cpu: CPU millis
        memory: Memory MB
        gpu: GPU count
        gpu_type: GPU type
        env: Environment variables
        expose: Ports to expose
        secret: Secret references
        region: Preferred region
        max_lifetime_seconds: Maximum lifetime in seconds
        args: Command arguments
        name: Sandbox name
        snapshot_id: Snapshot ID to restore

    Returns:
        Request dictionary
    """
    # Get defaults
    defaults_mgr = get_defaults_manager()
    sandbox_defaults = defaults_mgr.get_sandbox_defaults()

    # Resolve type
    if type_name:
        type_cpu, type_memory = resolve_sandbox_type(type_name)
        if cpu is None:
            cpu = type_cpu
        if memory is None:
            memory = type_memory
    else:
        # Use defaults
        if "type" in sandbox_defaults:
            type_cpu, type_memory = resolve_sandbox_type(sandbox_defaults["type"])
            if cpu is None:
                cpu = type_cpu
            if memory is None:
                memory = type_memory

    # Fallback to small type
    if cpu is None:
        cpu = 2000
    if memory is None:
        memory = 4096

    resolved_image = None
    if not snapshot_id:
        resolved_image = settings.resolve_image(image or sandbox_defaults.get("image"))
        if not resolved_image.startswith(("docker://", "docker.io/")):
            resolved_image = f"docker://{resolved_image}"

    # Parse environment variables
    env_dict: dict[str, str] = {}
    for e in env:
        if "=" in e:
            key, value = e.split("=", 1)
            env_dict[key] = value
        else:
            # Allow -e KEY to pull from environment
            import os
            value = os.getenv(e)
            if value is None:
                print_warning(f"Environment variable {e} not set, skipping")
            else:
                env_dict[e] = value

    # Parse ports to expose
    port_configs = []
    for port_spec in expose:
        if ":" in port_spec:
            parts = port_spec.split(":")
            if len(parts) == 2:
                container_port, port_type = parts
                try:
                    port_configs.append({
                        "containerPort": int(container_port),
                        "portType": port_type,
                    })
                except ValueError:
                    print_warning(f"Invalid port specification: {port_spec}")
            elif len(parts) == 3:
                host_port, container_port, port_type = parts
                try:
                    port_configs.append({
                        "hostPort": int(host_port),
                        "containerPort": int(container_port),
                        "portType": port_type,
                    })
                except ValueError:
                    print_warning(f"Invalid port specification: {port_spec}")
        else:
            try:
                port_configs.append({
                    "containerPort": int(port_spec),
                    "portType": "tcp",
                })
            except ValueError:
                print_warning(f"Invalid port specification: {port_spec}")

    # Parse secrets
    from ..api.models import SecretRef
    secret_refs = []
    for secret_spec in secret:
        if "=" in secret_spec:
            key, secret_id = secret_spec.split("=", 1)
            secret_refs.append(SecretRef(secret_id=secret_id, env_name=key))

    # Region
    if region is None:
        region = sandbox_defaults.get("region")
    if max_lifetime_seconds is None:
        max_lifetime_seconds = sandbox_defaults.get("max_lifetime_seconds")
    if max_lifetime_seconds is not None and max_lifetime_seconds <= 0:
        raise typer.BadParameter("max lifetime must be greater than 0")

    # Build request
    request: dict = {
        "cpuMillis": cpu,
        "memoryMb": memory,
        "gpuCount": gpu,
        "env": env_dict,
        "args": args,
    }

    if resolved_image:
        request["image"] = resolved_image

    if name:
        request["name"] = name
    if snapshot_id:
        request["snapshotId"] = snapshot_id
    if gpu_type:
        request["gpuType"] = gpu_type
    if port_configs:
        request["portMappings"] = port_configs
    if secret_refs:
        request["secretRefs"] = [s.model_dump() for s in secret_refs]
    if region:
        request["allowedRegions"] = [region]
    if max_lifetime_seconds is not None:
        request["maxLifetimeSeconds"] = max_lifetime_seconds
    if settings.workspace:
        request["workspaceId"] = settings.workspace

    return request


@app.command("run")
def run_sandbox(
    ctx: typer.Context,
    name: str | None = typer.Option(None, "--name", help="Sandbox name"),
    type: str | None = typer.Option(None, "--type", "-t", help="Sandbox type preset"),
    sandbox: str | None = typer.Option(None, "--sandbox", help="Alias for --type"),
    image: str | None = typer.Option(None, "--image", help="Container image"),
    image_tag: str | None = typer.Option(None, "--image-tag", help="Image tag to resolve"),
    snapshot: str | None = typer.Option(None, "--snapshot", help="Restore from snapshot"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis (1000 = 1 core)"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    gpu: int = typer.Option(0, "--gpu", help="GPU count"),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    env: list[str] = typer.Option([], "--env", "-e", help="Environment variables"),
    expose: list[str] = typer.Option([], "--expose", "-p", help="Expose ports"),
    secret: list[str] = typer.Option([], "--secret", help="Inject secrets (KEY=ID)"),
    region: str | None = typer.Option(None, "--region", help="Preferred region"),
    max_lifetime_seconds: int | None = typer.Option(
        None,
        "--max-lifetime-seconds",
        help="Maximum lifetime in seconds (starts when sandbox is running)",
    ),
    follow: bool = typer.Option(
        True,
        "--follow/--no-follow",
        help="Follow lifecycle logs after sandbox creation",
    ),
    command: list[str] = typer.Argument(None, help="Command to run"),
) -> None:
    """Create and run a sandbox.

    Examples:
        av run -- python3 -m http.server
        av run --type xl --expose 8080:http -- python3 -m http.server
        av run --image node -- node script.js
    """
    settings = get_settings()
    client = get_client()
    api = SandboxAPI(client)

    # Use --sandbox as alias for --type
    if sandbox and not type:
        type = sandbox

    # If no command, choose defaults based on invocation intent.
    if not command:
        if image or snapshot or image_tag:
            # Explicit runtime source provided: defer to image/snapshot defaults.
            command = []
        else:
            # Plain `av run`: keep historical shell-first behavior.
            command = ["/bin/bash"]

    # Resolve image tag to snapshot ID if provided
    if image_tag:
        from ..api.image import ImageAPI

        if not settings.workspace:
            print_error("Workspace is required to resolve image tags")
            raise typer.Exit(1)
        try:
            resolved = ImageAPI(client).resolve(settings.workspace, image_tag)
            snapshot = resolved.id
            image = None
        except APIError as e:
            print_error(f"Failed to resolve image tag: {e.message}")
            raise typer.Exit(1)

    # Build request
    request = build_sandbox_request(
        settings=settings,
        type_name=type,
        image=image,
        cpu=cpu,
        memory=memory,
        gpu=gpu,
        gpu_type=gpu_type,
        env=env,
        expose=expose,
        secret=secret,
        region=region,
        max_lifetime_seconds=max_lifetime_seconds,
        args=command,
        name=name,
        snapshot_id=snapshot,
    )

    # Create sandbox
    try:
        with status(f"Creating sandbox{f' {name}' if name else ''}..."):
            sandbox = api.create(request)
    except APIError as e:
        print_error(f"Failed to create sandbox: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(sandbox)
        return

    print_success(f"Sandbox created: {sandbox.id}")

    if follow:
        print("\nLogs:")
        print_logs(sandbox.id, follow=True)


@app.command("ls")
def list_sandboxes(
    all: bool = typer.Option(False, "--all", "-a", help="Include stopped sandboxes"),
) -> None:
    """List sandboxes."""
    client = get_client()
    api = SandboxAPI(client)

    try:
        sandboxes = api.list_all()
    except APIError as e:
        print_error(f"Failed to list sandboxes: {e.message}")
        raise typer.Exit(1)

    if not all:
        sandboxes = [s for s in sandboxes if s.status == "running"]

    print_sandbox_table(sandboxes)


@app.command("ps")
def list_sandboxes_ps(
    all: bool = typer.Option(False, "--all", "-a", help="Include stopped sandboxes"),
) -> None:
    """List sandboxes (alias for ls)."""
    list_sandboxes(all=all)


@app.command()
def inspect(sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix")) -> None:
    """Show sandbox details.

    Examples:
        av inspect sb_abc123
        av inspect 3b284871-df8
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        sandbox = api.get(sandbox_id)
    except APIError as e:
        print_error(f"Failed to get sandbox: {e.message}")
        raise typer.Exit(1)

    print_sandbox_detail(sandbox)


@app.command()
def stop(sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix")) -> None:
    """Stop a running sandbox.

    Examples:
        av stop sb_abc123
        av stop 3b284871-df8
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        with status(f"Stopping sandbox {sandbox_id}..."):
            api.stop(sandbox_id)
    except APIError as e:
        print_error(f"Failed to stop sandbox: {e.message}")
        raise typer.Exit(1)

    print_success(f"Sandbox {sandbox_id} stopped")


@app.command()
def extend(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix"),
    additional_seconds: int = typer.Option(..., "--additional-seconds", "-s", help="Number of seconds to extend the TTL by"),
) -> None:
    """Extend the TTL of a running sandbox.

    Examples:
        av extend sb_abc123 --additional-seconds 3600
        av extend 3b284871-df8 -s 7200
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        with status(f"Extending sandbox {sandbox_id} TTL..."):
            result = api.extend_ttl(sandbox_id, additional_seconds)
        if json_output_enabled():
            emit_json(result)
            return
        print_success(f"Extended sandbox {sandbox_id} TTL by {additional_seconds} seconds")
        if result.metadata.expires_at:
            print(f"New expiration: {result.metadata.expires_at}")
    except APIError as e:
        print_error(f"Failed to extend sandbox TTL: {e.message}")
        raise typer.Exit(1)


@app.command()
def start(sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix")) -> None:
    """Start a stopped sandbox.

    Examples:
        av start sb_abc123
        av start 3b284871-df8
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        with status(f"Starting sandbox {sandbox_id}..."):
            api.start(sandbox_id)
    except APIError as e:
        print_error(f"Failed to start sandbox: {e.message}")
        raise typer.Exit(1)

    print_success(f"Sandbox {sandbox_id} started")


@app.command("rm")
def delete_sandbox(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a sandbox.

    Examples:
        av rm sb_abc123
        av rm 3b284871-df8
    """
    client = get_client()
    api = SandboxAPI(client)

    # Resolve sandbox ID first
    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    if not force:
        typer.confirm(f"Delete sandbox {sandbox_id}?", abort=True)

    try:
        with status(f"Deleting sandbox {sandbox_id}..."):
            api.delete(sandbox_id)
    except APIError as e:
        print_error(f"Failed to delete sandbox: {e.message}")
        raise typer.Exit(1)

    print_success(f"Sandbox {sandbox_id} deleted")


@app.command("delete", deprecated=True)
def delete_sandbox_alt(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a sandbox (alias for rm)."""
    delete_sandbox(sandbox_id, force=True)


@app.command()
def logs(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix"),
    follow: bool = typer.Option(False, "--follow", "-f", help="Follow log output"),
    tail: int | None = typer.Option(None, "--tail", "-n", help="Number of lines to tail"),
) -> None:
    """View sandbox logs.

    Examples:
        av logs sb_abc123
        av logs 3b284871-df8
        av logs -f 3b284871-df8
    """
    print_logs(sandbox_id, follow, tail)


def _extract_log_entries(payload: Any) -> list[dict[str, str | None]]:
    """Normalize API log payloads into a list of entries."""
    if isinstance(payload, dict):
        raw_entries = payload.get("entries")
        if isinstance(raw_entries, list) and raw_entries:
            entries: list[dict[str, str | None]] = []
            for raw in raw_entries:
                if isinstance(raw, dict):
                    message = raw.get("message")
                    if message is None:
                        continue
                    timestamp = raw.get("timestamp")
                    log_path = raw.get("logPath")
                    entries.append(
                        {
                            "message": str(message),
                            "timestamp": str(timestamp) if timestamp is not None else None,
                            "logPath": str(log_path) if log_path is not None else None,
                        }
                    )
                elif raw is not None:
                    entries.append(
                        {
                            "message": str(raw),
                            "timestamp": None,
                            "logPath": None,
                        }
                    )
            if entries:
                return entries

        raw_logs = payload.get("logs")
        if isinstance(raw_logs, list):
            return [
                {"message": str(log), "timestamp": None, "logPath": None}
                for log in raw_logs
                if log is not None
            ]

        message = payload.get("message")
        if message is not None:
            return [{"message": str(message), "timestamp": None, "logPath": None}]

    if isinstance(payload, list):
        return [
            {"message": str(item), "timestamp": None, "logPath": None}
            for item in payload
            if item is not None
        ]

    if isinstance(payload, str) and payload:
        return [{"message": payload, "timestamp": None, "logPath": None}]

    return []


def _parse_timestamp_value(timestamp: str | None) -> float | None:
    """Convert ISO timestamp to epoch seconds for cursor advancement."""
    if not timestamp:
        return None

    normalized = timestamp.replace("Z", "+00:00")
    try:
        return datetime.fromisoformat(normalized).timestamp()
    except ValueError:
        return None


def _fetch_lifecycle_log_entries(
    client: Client,
    sandbox_id: str,
    limit: int,
    from_timestamp: str | None = None,
) -> list[dict[str, str | None]]:
    """Fetch lifecycle log entries from API server."""
    params: dict[str, Any] = {"sort": "asc", "limit": limit}
    if from_timestamp:
        params["from"] = from_timestamp

    response = client.get(
        f"/v1/sandboxes/{sandbox_id}/logs/lifecycle",
        params=params,
    )

    try:
        payload = response.json()
    except Exception:
        payload = response.text

    return _extract_log_entries(payload)


def print_logs(sandbox_id: str, follow: bool = False, tail: int | None = None) -> None:
    """Print logs for a sandbox.

    Args:
        sandbox_id: Sandbox ID (or prefix)
        follow: Whether to follow logs
        tail: Number of lines to tail
    """
    client = get_client()
    # Resolve sandbox ID prefix to full ID
    sandbox_id = resolve_sandbox_id(client, sandbox_id)
    limit = tail if tail is not None else 200

    try:
        if follow:
            # Poll lifecycle logs and print only new entries.
            cursor_timestamp: str | None = None
            cursor_value: float | None = None
            cursor_emitted_counts: dict[str, int] = {}

            while True:
                entries = _fetch_lifecycle_log_entries(
                    client,
                    sandbox_id,
                    limit=limit,
                    from_timestamp=cursor_timestamp,
                )
                poll_cursor_counts: dict[str, int] = {}

                for entry in entries:
                    message = entry["message"] or ""
                    timestamp = entry.get("timestamp")
                    log_path = entry.get("logPath") or ""
                    dedupe_key = f"{log_path}|{message}"

                    timestamp_value = _parse_timestamp_value(timestamp)
                    if (
                        timestamp is not None
                        and timestamp_value is not None
                        and (cursor_value is None or timestamp_value > cursor_value)
                    ):
                        cursor_value = timestamp_value
                        cursor_timestamp = timestamp
                        cursor_emitted_counts = {}
                        poll_cursor_counts = {}

                    # The API currently uses `from` with inclusive semantics (`gte`).
                    # Keep occurrence counts at the boundary timestamp to avoid re-printing
                    # prior entries while still allowing legitimate duplicate log lines.
                    if (
                        timestamp is not None
                        and timestamp_value is not None
                        and cursor_timestamp is not None
                        and timestamp == cursor_timestamp
                    ):
                        occurrence = poll_cursor_counts.get(dedupe_key, 0) + 1
                        poll_cursor_counts[dedupe_key] = occurrence
                        if occurrence <= cursor_emitted_counts.get(dedupe_key, 0):
                            continue

                    print(message)

                if poll_cursor_counts:
                    cursor_emitted_counts = poll_cursor_counts

                time.sleep(1.0)
        else:
            entries = _fetch_lifecycle_log_entries(
                client,
                sandbox_id,
                limit=limit,
            )
            for entry in entries:
                print(entry["message"])
    except APIError as e:
        print_error(f"Failed to get logs: {e.message}")
        if e.details:
            print_error(f"Details: {e.details}")
        raise typer.Exit(1)
    except KeyboardInterrupt:
        pass


def expose_port_cli(
    sandbox_id: str,
    port: int,
    port_type: str = "tcp",
) -> None:
    """Expose a port on a running sandbox (shared implementation).

    Args:
        sandbox_id: Sandbox ID or prefix
        port: Container port to expose
        port_type: Port type (tcp, http, ws)
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        with status(f"Exposing port {port}..."):
            mapping = api.expose_port(sandbox_id, port, port_type)
    except APIError as e:
        print_error(f"Failed to expose port: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(mapping)
        return

    print_success(f"Port {port} exposed")
    if mapping.public_url:
        print(f"  URL: {mapping.public_url}")
    else:
        print(f"  Host port: {mapping.host_port}")


@app.command()
def expose(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix"),
    port: int = typer.Argument(..., help="Container port to expose"),
    port_type: str = typer.Option("tcp", "--type", "-t", help="Port type (tcp, http, ws)"),
) -> None:
    """Expose a port on a running sandbox.

    Examples:
        av sandbox expose sb_abc123 8080
        av sandbox expose 3b284871-df8 8080
        av sandbox expose sb_abc123 8080 --type http
    """
    expose_port_cli(sandbox_id, port, port_type)


def url_cli(
    sandbox_id: str,
    port: int | None = None,
) -> None:
    """Get the URL for a sandbox port (shared implementation).

    Args:
        sandbox_id: Sandbox ID or prefix
        port: Optional container port
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        sandbox = api.get(sandbox_id)
    except APIError as e:
        print_error(f"Failed to get sandbox: {e.message}")
        raise typer.Exit(1)

    if sandbox.metadata.port_mappings:
        if port is not None:
            # Find specific port
            for mapping in sandbox.metadata.port_mappings:
                if mapping.container_port == port:
                    print(mapping.public_url or f"localhost:{mapping.host_port}")
                    return
            print_error(f"Port {port} not exposed")
            raise typer.Exit(1)
        else:
            # List all URLs
            for mapping in sandbox.metadata.port_mappings:
                url = mapping.public_url or f"localhost:{mapping.host_port}"
                print(f"{mapping.container_port}: {url}")
    else:
        print_warning("No ports exposed")


@app.command()
def url(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix"),
    port: int | None = typer.Argument(None, help="Container port"),
) -> None:
    """Get the URL for a sandbox port.

    Examples:
        av sandbox url sb_abc123 8080
        av sandbox url 3b284871-df8 8080
    """
    url_cli(sandbox_id, port)


# Create ports subcommand group
ports_app = typer.Typer(help="Port management commands")
app.add_typer(ports_app, name="ports")


@ports_app.command("list")
def list_ports(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID or prefix"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List all exposed ports for a sandbox.

    Examples:
        av sandbox ports list sb_abc123
        av sandbox ports list 3b284871-df8
        av sandbox ports list sb_abc123 --json
    """
    client = get_client()
    api = SandboxAPI(client)

    sandbox_id = resolve_sandbox_id(client, sandbox_id)

    try:
        ports = api.list_ports(sandbox_id)
    except APIError as e:
        print_error(f"Failed to list ports: {e.message}")
        raise typer.Exit(1)

    if json_output:
        import json
        print(json.dumps([p.model_dump() for p in ports], indent=2))
    else:
        print_ports_table(ports, sandbox_id)


# =============================================================================
# Quick shortcuts
# =============================================================================

def run_quick(
    image: str,
    type_name: str = "small",
    command: list[str] | None = None,
) -> None:
    """Run a quick sandbox with common settings.

    Args:
        image: Container image
        type_name: Sandbox type
        command: Command to run
    """
    from ..cli.app import app as main_app

    if command is None:
        command = []

    ctx = typer.Context(main_app)
    run_sandbox(
        ctx,
        type=type_name,
        image=image,
        command=command,
    )


@app.command("python")
def run_python(
    ctx: typer.Context,
    type: str = typer.Option("small", "--type", "-t", help="Sandbox type"),
    command: list[str] = typer.Argument(None, help="Python command"),
) -> None:
    """Start a Python sandbox.

    Examples:
        av python
        av python -- -c "print('hello')"
        av python -- python script.py
    """
    if not command:
        command = ["python3"]
    run_quick("python", type, command)


@app.command("node")
def run_node(
    ctx: typer.Context,
    type: str = typer.Option("small", "--type", "-t", help="Sandbox type"),
    command: list[str] = typer.Argument(None, help="Node command"),
) -> None:
    """Start a Node.js sandbox.

    Examples:
        av node
        av node -- node script.js
    """
    if not command:
        command = ["node"]
    run_quick("node", type, command)


@app.command("bash")
def run_bash(
    ctx: typer.Context,
    type: str = typer.Option("small", "--type", "-t", help="Sandbox type"),
) -> None:
    """Start a bash shell sandbox.

    Examples:
        av bash
        av bash --type xl
    """
    run_quick("bash", type, ["/bin/bash"])
