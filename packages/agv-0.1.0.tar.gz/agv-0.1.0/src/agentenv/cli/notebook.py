"""Notebook CLI commands."""

from __future__ import annotations

import json
import re
import sys
import webbrowser
from contextlib import nullcontext
from datetime import UTC, datetime
from enum import StrEnum
from pathlib import Path
from typing import Any

import typer

from ..api.client import APIError, Client
from ..api.models import NotebookCellDetail
from ..api.notebook import NotebookAPI
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    console,
    print_cell_detail,
    print_cell_table,
    print_error,
    print_execution_result,
    print_file_table,
    print_notebook_document_detail,
    print_notebook_document_table,
    print_notebook_table,
    print_success,
)

app = typer.Typer(help="Jupyter notebook commands")
session_app = typer.Typer(help="Notebook session commands")
kernel_app = typer.Typer(help="Notebook kernel commands")
kernel_ttl_app = typer.Typer(help="Notebook kernel TTL commands")
document_app = typer.Typer(help="Notebook document commands")
cell_app = typer.Typer(help="Cell management commands")
file_app = typer.Typer(help="Notebook file workspace commands")
collab_app = typer.Typer(help="Notebook collaboration commands")
app.add_typer(session_app, name="session")
app.add_typer(kernel_app, name="kernel")
kernel_app.add_typer(kernel_ttl_app, name="ttl")
app.add_typer(document_app, name="document")
app.add_typer(cell_app, name="cell")
app.add_typer(file_app, name="file")
app.add_typer(collab_app, name="collab")


class SnapshotFavor(StrEnum):
    """Snapshot behavior when kernel TTL expires."""

    none = "none"
    disk = "disk"
    disk_include_memory = "disk_include_memory"


@app.callback(invoke_without_command=True)
def notebook_entrypoint(
    ctx: typer.Context,
    name: str | None = typer.Option(None, "--name", help="Notebook session name"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to configured workspace)",
    ),
    type: str = typer.Option("small", "--type", "-t", help="Sandbox type preset"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    image: str | None = typer.Option(None, "--image", help="Notebook image"),
    snapshot_id: str | None = typer.Option(None, "--snapshot", "--snapshot-id", help="Snapshot ID"),
    gpu_count: int | None = typer.Option(None, "--gpu", "--gpu-count", help="GPU count"),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    storage_mode: str | None = typer.Option(None, "--storage-mode", help="Storage mode"),
    env: list[str] = typer.Option([], "--env", "-e", help="Environment variables"),
    idle_ttl_seconds: int | None = typer.Option(None, "--idle-ttl", help="Kernel idle TTL in seconds"),
    persistent: bool = typer.Option(
        False,
        "--persistent/--no-persistent",
        help="Disable kernel TTL entirely (infinite)",
    ),
    snapshot_favor: SnapshotFavor = typer.Option(
        SnapshotFavor.disk_include_memory,
        "--snapshot-favor",
        help="Snapshot behavior when kernel auto-stops",
    ),
    kill_after: str | None = typer.Option(
        None,
        "--kill-after",
        help='Hard kill cap duration (e.g. "2h", "30m")',
    ),
    kill_at: str | None = typer.Option(
        None,
        "--kill-at",
        help='Hard kill cap absolute time (e.g. "2026-02-06T21:00:00Z")',
    ),
    open_url: bool = typer.Option(True, "--open/--no-open", help="Open notebook URL"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for session to be ready"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a notebook session when invoked without a subcommand."""
    if ctx.invoked_subcommand is None:
        create_notebook(
            name=name,
            workspace_id=workspace_id,
            type=type,
            cpu=cpu,
            memory=memory,
            image=image,
            snapshot_id=snapshot_id,
            gpu_count=gpu_count,
            gpu_type=gpu_type,
            storage_mode=storage_mode,
            env=env,
            idle_ttl_seconds=idle_ttl_seconds,
            persistent=persistent,
            snapshot_favor=snapshot_favor,
            kill_after=kill_after,
            kill_at=kill_at,
            open_url=open_url,
            wait=wait,
            json_output=json_output,
        )


HEADING_REGEX = re.compile(r"^(#{1,6})\s+(.+)$")


def _parse_duration_seconds(value: str) -> int:
    """Parse a simple duration string into seconds.

    Supported formats:
    - Integer seconds: "300"
    - Unit-suffixed parts: "5m", "2h", "1h30m", "1d"
    Units: s, m, h, d
    """
    import re

    raw = value.strip().replace(" ", "")
    if not raw:
        raise ValueError("duration is empty")

    if raw.isdigit():
        seconds = int(raw)
        if seconds <= 0:
            raise ValueError("duration must be > 0")
        return seconds

    pattern = re.compile(r"(\d+)([smhdSMHD])")
    total = 0
    pos = 0
    for match in pattern.finditer(raw):
        if match.start() != pos:
            raise ValueError(
                "invalid duration format (examples: 300, 5m, 2h, 1h30m, 1d)"
            )
        amount = int(match.group(1))
        unit = match.group(2).lower()
        multiplier = {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
        total += amount * multiplier
        pos = match.end()

    if pos != len(raw):
        raise ValueError(
            "invalid duration format (examples: 300, 5m, 2h, 1h30m, 1d)"
        )

    if total <= 0:
        raise ValueError("duration must be > 0")

    return total


def _normalize_iso_timestamp(value: str) -> str:
    """Normalize an ISO-8601 timestamp to an RFC3339 UTC string.

    Accepts "Z" suffix and naive timestamps (assumed local time).
    """
    raw = value.strip()
    if not raw:
        raise ValueError("timestamp is empty")

    try:
        dt = datetime.fromisoformat(raw.replace("Z", "+00:00"))
    except ValueError as e:
        raise ValueError(
            "invalid timestamp (expected ISO-8601, e.g. 2026-02-06T21:00:00Z)"
        ) from e

    if dt.tzinfo is None:
        dt = dt.replace(tzinfo=datetime.now().astimezone().tzinfo)

    return dt.astimezone(UTC).isoformat().replace("+00:00", "Z")


def _parse_env_list(
    values: list[str],
    *,
    json_output: bool,
) -> dict[str, str]:
    """Parse repeatable KEY=VALUE env options into a mapping."""
    parsed: dict[str, str] = {}
    for item in values:
        if "=" not in item:
            _fail(
                f"Invalid --env value '{item}'. Expected KEY=VALUE.",
                json_output=json_output,
                code="INVALID_ARGUMENT",
            )
        key, value = item.split("=", 1)
        key = key.strip()
        if not key:
            _fail(
                f"Invalid --env value '{item}'. Expected KEY=VALUE.",
                json_output=json_output,
                code="INVALID_ARGUMENT",
            )
        parsed[key] = value
    return parsed


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _is_kernel_ready(kernel_status: dict[str, Any]) -> bool:
    """Kernel readiness for CLI wait loops.

    `busy` is considered ready unless backend explicitly marks startup.
    """
    status_value = str(kernel_status.get("status") or "")
    message = str(kernel_status.get("message") or "")
    if status_value == "idle":
        return True
    if status_value == "busy" and message != "Kernel starting":
        return True
    return False


def _wait_for_kernel_ready(
    api: NotebookAPI,
    notebook_id: str,
    *,
    timeout: int = 30,
    ensure: bool = True,
) -> None:
    """Ensure kernel exists and wait until it is ready for notebook file ops."""
    import time

    if ensure:
        api.ensure_kernel(notebook_id)

    start = time.time()
    while time.time() - start < timeout:
        status = api.get_kernel_status(notebook_id)
        if _is_kernel_ready(status):
            return
        time.sleep(0.5)

    raise TimeoutError(f"Kernel ensure timeout after {timeout}s")


def _split_upload_destination(
    remote_path: str | None,
) -> tuple[str | None, str | None]:
    """Interpret upload destination as either a directory or a full file path.

    Rules:
    - empty -> upload to notebook root with the local filename
    - trailing slash -> destination directory
    - single path segment without suffix -> destination directory
    - otherwise -> explicit file path (parent directory + filename)
    """
    if not remote_path:
        return None, None

    normalized = remote_path.lstrip("/")
    if not normalized:
        return None, None

    if normalized.endswith("/"):
        return normalized.rstrip("/"), None

    destination = Path(normalized)
    if len(destination.parts) == 1 and destination.suffix == "":
        return normalized, None

    parent = destination.parent.as_posix()
    if parent == ".":
        parent = ""
    return (parent or None), destination.name


@session_app.command("create")
def create_notebook(
    name: str | None = typer.Option(None, "--name", help="Notebook session name"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID (defaults to configured workspace)",
    ),
    type: str = typer.Option("small", "--type", "-t", help="Sandbox type preset"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    image: str | None = typer.Option(None, "--image", help="Notebook image"),
    snapshot_id: str | None = typer.Option(None, "--snapshot", "--snapshot-id", help="Snapshot ID"),
    gpu_count: int | None = typer.Option(None, "--gpu", "--gpu-count", help="GPU count"),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    storage_mode: str | None = typer.Option(None, "--storage-mode", help="Storage mode"),
    env: list[str] = typer.Option([], "--env", "-e", help="Environment variables"),
    idle_ttl_seconds: int | None = typer.Option(None, "--idle-ttl", help="Kernel idle TTL in seconds"),
    persistent: bool = typer.Option(
        False,
        "--persistent/--no-persistent",
        help="Disable kernel TTL entirely (infinite)",
    ),
    snapshot_favor: SnapshotFavor = typer.Option(
        SnapshotFavor.disk_include_memory,
        "--snapshot-favor",
        help="Snapshot behavior when kernel auto-stops",
    ),
    kill_after: str | None = typer.Option(
        None,
        "--kill-after",
        help='Hard kill cap duration (e.g. "2h", "30m")',
    ),
    kill_at: str | None = typer.Option(
        None,
        "--kill-at",
        help='Hard kill cap absolute time (e.g. "2026-02-06T21:00:00Z")',
    ),
    open_url: bool = typer.Option(True, "--open/--no-open", help="Open notebook URL"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for session to be ready"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a Jupyter notebook session.

    Examples:
        av notebook session create --workspace wk_abc123
        av notebook session create --workspace wk_abc123 --type xl
        av notebook session create --workspace wk_abc123 --cpu 4000 --memory 8192
        av notebook session create --workspace wk_abc123 --image docker://quay.io/jupyter/datascience-notebook:notebook-7.5.5
        av notebook session create --workspace wk_abc123 --snapshot snap_abc123 --storage-mode persistent
        av notebook session create --workspace wk_abc123 --kill-after 2h --snapshot-favor disk
        av notebook session create --workspace wk_abc123 --persistent
    """
    client = get_client()
    api = NotebookAPI(client)
    env_map = _parse_env_list(env, json_output=json_output)

    if kill_after and kill_at:
        _fail("Use only one of --kill-after or --kill-at", json_output=json_output, code="INVALID_ARGUMENT")

    hard_kill_after_seconds: int | None = None
    hard_kill_at: str | None = None
    if kill_after:
        try:
            hard_kill_after_seconds = _parse_duration_seconds(kill_after)
        except ValueError as e:
            _fail(f"Invalid --kill-after: {e}", json_output=json_output, code="INVALID_ARGUMENT")
    if kill_at:
        try:
            hard_kill_at = _normalize_iso_timestamp(kill_at)
        except ValueError as e:
            _fail(f"Invalid --kill-at: {e}", json_output=json_output, code="INVALID_ARGUMENT")

    resolved_workspace_id = workspace_id or get_settings().workspace
    if not resolved_workspace_id:
        _fail(
            "No workspace specified. Use --workspace or set default with 'av workspace use'",
            json_output=json_output,
            code="WORKSPACE_REQUIRED",
        )

    try:
        with _status_context("Creating notebook session...", json_output=json_output):
            session = api.create(
                name=name,
                workspace_id=resolved_workspace_id,
                type=type,
                cpu=cpu,
                memory=memory,
                image=image,
                snapshot_id=snapshot_id,
                gpu_count=gpu_count,
                gpu_type=gpu_type,
                storage_mode=storage_mode,
                env=env_map or None,
                idle_ttl_seconds=idle_ttl_seconds,
                persistent=persistent,
                snapshot_favor=snapshot_favor.value,
                hard_kill_at=hard_kill_at,
                hard_kill_after_seconds=hard_kill_after_seconds,
            )
    except APIError as e:
        _fail_api("create notebook session", e, json_output=json_output)

    if not json_output:
        print_success(f"Notebook session {session.id} created")

    if wait:
        with _status_context("Waiting for session to start...", json_output=json_output):
            try:
                session = api.wait_for_status(session.id, timeout=120)
            except TimeoutError:
                _fail("Notebook session failed to start in time", json_output=json_output, code="TIMEOUT")

        if not json_output:
            print_success(f"Notebook session {session.id} is running")

    if not json_output and getattr(session, "notebook_url", None):
        console.print(f"Notebook URL: [cyan]{session.notebook_url}[/cyan]")
        if open_url:
            webbrowser.open(session.notebook_url)

    if json_output:
        _print_json(session.model_dump(by_alias=True, exclude_none=True))
        return


@session_app.command("list")
@session_app.command("ls", hidden=True)
def list_notebooks(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List notebook sessions."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        sessions = api.list_all()
    except APIError as e:
        _fail_api("list notebook sessions", e, json_output=json_output)

    if json_output:
        _print_json([s.model_dump(by_alias=True, exclude_none=True) for s in sessions])
        return

    print_notebook_table(sessions)


@session_app.command("get")
@session_app.command("inspect", hidden=True)
def inspect(
    session_id: str = typer.Argument(..., help="Session ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Show notebook session details.

    Examples:
        av notebook session get nb_abc123
    """
    client = get_client()
    api = NotebookAPI(client)

    try:
        session = api.get(session_id)
    except APIError as e:
        _fail_api("get notebook session", e, json_output=json_output)

    if json_output:
        _print_json(session.model_dump(by_alias=True, exclude_none=True))
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _colored_status, _format_datetime

    console = Console()
    table = Table(title=f"Notebook Session: {session.id}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", session.id)
    table.add_row("Status", _colored_status(session.status))
    table.add_row("Created", _format_datetime(session.created_at))

    console.print(table)


@session_app.command()
def stop(
    session_id: str = typer.Argument(..., help="Session ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Stop a notebook session.

    Examples:
        av notebook session stop nb_abc123
    """
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context(f"Stopping notebook session {session_id}...", json_output=json_output):
            api.stop(session_id)
    except APIError as e:
        _fail_api("stop notebook session", e, json_output=json_output)

    if json_output:
        _print_json(
            {
                "id": session_id,
                "success": True,
                "action": "stop",
            }
        )
        return

    print_success(f"Notebook session {session_id} stopped")


@session_app.command()
def wake(
    session_id: str = typer.Argument(..., help="Session ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Wake a stopped notebook session from its latest snapshot.

    Examples:
        av notebook session wake nb_abc123
    """
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context(f"Waking notebook session {session_id}...", json_output=json_output):
            session = api.wake(session_id)
    except APIError as e:
        _fail_api("wake notebook session", e, json_output=json_output)

    if json_output:
        _print_json(session.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Notebook session {session.id} wake requested")


@session_app.command("rm")
def delete_notebook(
    session_id: str = typer.Argument(..., help="Session ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a notebook session.

    Examples:
        av notebook session rm nb_abc123
    """
    if not force:
        typer.confirm(f"Delete notebook session {session_id}?", abort=True)

    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context(f"Deleting notebook session {session_id}...", json_output=json_output):
            api.delete(session_id)
    except APIError as e:
        _fail_api("delete notebook session", e, json_output=json_output)

    if json_output:
        _print_json(
            {
                "id": session_id,
                "success": True,
                "action": "delete",
            }
        )
        return

    print_success(f"Notebook session {session_id} deleted")


@session_app.command("delete", hidden=True)
def delete_notebook_alt(
    session_id: str = typer.Argument(..., help="Session ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a notebook session (alias for rm)."""
    delete_notebook(session_id, force=True)


# =============================================================================
# Kernel Commands
# =============================================================================


@kernel_app.command("ensure")
def ensure_kernel(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    wait: bool = typer.Option(
        True,
        "--wait/--no-wait",
        help="Wait for kernel to become ready",
    ),
    timeout: int = typer.Option(120, "--timeout", help="Wait timeout in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Ensure kernel session exists for a notebook document."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Ensuring notebook kernel...", json_output=json_output):
            ensured = api.ensure_kernel(notebook_id)
    except APIError as e:
        _fail_api("ensure kernel", e, json_output=json_output)

    if not wait:
        if json_output:
            _print_json(ensured)
        else:
            print_success(f"Kernel ensure accepted ({ensured.get('status', 'unknown')})")
        return

    import time

    start = time.time()
    latest_status: dict[str, Any] = {"status": "unknown"}
    while time.time() - start < timeout:
        try:
            latest_status = api.get_kernel_status(notebook_id)
        except APIError as e:
            _fail_api("query kernel status", e, json_output=json_output)

        if _is_kernel_ready(latest_status):
            payload = {
                "status": "running",
                "ensureStatus": ensured.get("status"),
                "kernelStatus": latest_status,
            }
            if json_output:
                _print_json(payload)
            else:
                print_success(
                    f"Kernel is ready ({latest_status.get('status', 'unknown')})"
                )
            return

        time.sleep(0.5)

    _fail(f"Kernel ensure timeout after {timeout}s", json_output=json_output, code="TIMEOUT")


@kernel_app.command("interrupt")
def interrupt_kernel(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Interrupt a notebook kernel."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Interrupting notebook kernel...", json_output=json_output):
            result = api.interrupt_kernel(notebook_id)
    except APIError as e:
        _fail_api("interrupt kernel", e, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    print_success(f"Notebook kernel {notebook_id} interrupted")


@kernel_app.command("restart")
def restart_kernel(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Restart a notebook kernel."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Restarting notebook kernel...", json_output=json_output):
            result = api.restart_kernel(notebook_id)
    except APIError as e:
        _fail_api("restart kernel", e, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    print_success(f"Notebook kernel {notebook_id} restart requested")


@kernel_ttl_app.command("get")
def get_kernel_ttl(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get notebook kernel TTL policy."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        document = api.get_document(notebook_id)
        session_id = document.metadata.kernel_session_id if document.metadata else None
        if not session_id:
            _fail(
                "Notebook has no kernel session",
                json_output=json_output,
                code="KERNEL_SESSION_REQUIRED",
            )
        session = api.get(session_id)
        ttl_policy = (getattr(session, "config", None) or {}).get("ttlPolicy", {})
    except APIError as e:
        _fail_api("get kernel ttl policy", e, json_output=json_output)

    if json_output:
        _print_json(ttl_policy)
        return

    if not ttl_policy:
        print_error("Notebook kernel has no TTL policy")
        raise typer.Exit(1)

    _print_json(ttl_policy)


@kernel_ttl_app.command("set")
def set_kernel_ttl(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    persistent: bool | None = typer.Option(
        None,
        "--persistent/--no-persistent",
        help="Enable or disable always-on mode",
    ),
    idle_ttl: int | None = typer.Option(
        None,
        "--idle-ttl",
        help="Idle TTL in seconds",
    ),
    snapshot_favor: SnapshotFavor | None = typer.Option(
        None,
        "--snapshot-favor",
        help="Snapshot mode on TTL expiry",
    ),
    kill_after: str | None = typer.Option(
        None,
        "--kill-after",
        help='Hard kill cap duration (e.g. "2h", "30m")',
    ),
    kill_at: str | None = typer.Option(
        None,
        "--kill-at",
        help='Hard kill cap absolute time (e.g. "2026-02-06T21:00:00Z")',
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Update notebook kernel TTL policy."""
    if all(
        value is None
        for value in (persistent, idle_ttl, snapshot_favor, kill_after, kill_at)
    ):
        _fail(
            "No TTL updates provided",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    if kill_after and kill_at:
        _fail(
            "Use only one of --kill-after or --kill-at",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    hard_kill_after_seconds: int | None = None
    hard_kill_at: str | None = None
    if kill_after:
        try:
            hard_kill_after_seconds = _parse_duration_seconds(kill_after)
        except ValueError as e:
            _fail(f"Invalid --kill-after: {e}", json_output=json_output, code="INVALID_ARGUMENT")
    if kill_at:
        try:
            hard_kill_at = _normalize_iso_timestamp(kill_at)
        except ValueError as e:
            _fail(f"Invalid --kill-at: {e}", json_output=json_output, code="INVALID_ARGUMENT")

    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Updating notebook kernel TTL policy...", json_output=json_output):
            result = api.update_kernel_ttl_policy(
                notebook_id,
                persistent=persistent,
                idle_ttl_seconds=idle_ttl,
                snapshot_favor=snapshot_favor.value if snapshot_favor else None,
                hard_kill_at=hard_kill_at,
                hard_kill_after_seconds=hard_kill_after_seconds,
            )
    except APIError as e:
        _fail_api("update kernel ttl policy", e, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    print_success(f"Notebook kernel TTL policy updated for {notebook_id}")


# =============================================================================
# Document Commands
# =============================================================================


def _print_json(data: object) -> None:
    """Print object as JSON."""
    print(json.dumps(data, indent=2, default=str))


def _status_context(message: str, *, json_output: bool):
    """Return a status context for interactive mode and a no-op for JSON mode."""
    if json_output:
        return nullcontext()
    return status(message)


def _fail(
    message: str,
    *,
    json_output: bool,
    code: str = "CLI_ERROR",
    details: dict[str, Any] | None = None,
) -> None:
    """Terminate command with either structured JSON or rich error output."""
    if json_output:
        payload: dict[str, Any] = {"error": {"code": code, "message": message}}
        if details:
            payload["error"]["details"] = details
        _print_json(payload)
    else:
        print_error(message)
    raise typer.Exit(1)


def _fail_api(action: str, error: APIError, *, json_output: bool) -> None:
    """Render API failures in the command's selected output mode."""
    details: dict[str, Any] = {"statusCode": error.status_code}
    if error.details:
        details["apiError"] = error.details
    _fail(
        f"Failed to {action}: {error.message}",
        json_output=json_output,
        code="API_ERROR",
        details=details,
    )


def _require_document_updates(payload: dict[str, object], *, json_output: bool) -> None:
    """Ensure document update command has at least one explicit change."""
    if not payload:
        _fail(
            "No updates provided. Pass at least one --name/--description/metadata option.",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )


@document_app.command("create")
def create_document(
    workspace_id: str = typer.Option(..., "--workspace", "-w", help="Workspace ID"),
    name: str = typer.Option(..., "--name", help="Notebook name"),
    description: str | None = typer.Option(None, "--description", help="Notebook description"),
    kernel: str | None = typer.Option(None, "--kernel", help="Kernel (e.g. python3)"),
    image: str | None = typer.Option(None, "--image", help="Notebook image"),
    auto_save: bool | None = typer.Option(
        None,
        "--auto-save/--no-auto-save",
        help="Enable/disable auto save",
    ),
    markdown_first_cell: bool = typer.Option(
        False,
        "--markdown-first-cell",
        help="Create with initial markdown cell",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Create a notebook document."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Creating notebook document...", json_output=json_output):
            document = api.create_document(
                workspace_id=workspace_id,
                name=name,
                description=description,
                kernel=kernel,
                runtime="cpu",
                image=image,
                auto_save_enabled=auto_save,
                markdown_first_cell=markdown_first_cell,
            )
    except APIError as e:
        _fail_api("create notebook document", e, json_output=json_output)

    if json_output:
        _print_json(document.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Notebook document {document.id} created")
    print_notebook_document_detail(document)


@document_app.command("list")
@document_app.command("ls", hidden=True)
def list_documents(
    workspace_id: str = typer.Option(..., "--workspace", "-w", help="Workspace ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List notebook documents in a workspace."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        documents = api.list_documents(workspace_id)
    except APIError as e:
        _fail_api("list notebook documents", e, json_output=json_output)

    if json_output:
        _print_json([doc.model_dump(by_alias=True, exclude_none=True) for doc in documents])
        return

    print_notebook_document_table(documents)


@document_app.command("get")
def get_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get notebook document details."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        document = api.get_document(notebook_id)
    except APIError as e:
        _fail_api("get notebook document", e, json_output=json_output)

    if json_output:
        _print_json(document.model_dump(by_alias=True, exclude_none=True))
        return

    print_notebook_document_detail(document)


@document_app.command("set")
def set_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    name: str | None = typer.Option(None, "--name", help="Notebook name"),
    description: str | None = typer.Option(None, "--description", help="Notebook description"),
    kernel: str | None = typer.Option(None, "--kernel", help="Kernel"),
    auto_save: bool | None = typer.Option(
        None,
        "--auto-save/--no-auto-save",
        help="Enable/disable auto save",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Update notebook document metadata."""
    update_payload: dict[str, object] = {}
    if name is not None:
        update_payload["name"] = name
    if description is not None:
        update_payload["description"] = description
    if kernel is not None:
        update_payload["kernel"] = kernel
    if auto_save is not None:
        update_payload["auto_save"] = auto_save
    _require_document_updates(update_payload, json_output=json_output)

    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Updating notebook document...", json_output=json_output):
            document = api.update_document(
                notebook_id=notebook_id,
                name=name,
                description=description,
                kernel=kernel,
                auto_save_enabled=auto_save,
            )
    except APIError as e:
        _fail_api("update notebook document", e, json_output=json_output)

    if json_output:
        _print_json(document.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Notebook document {document.id} updated")
    print_notebook_document_detail(document)


@document_app.command("rm")
@document_app.command("delete", hidden=True)
def remove_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a notebook document."""
    if not force:
        typer.confirm(f"Delete notebook document {notebook_id}?", abort=True)

    client = get_client()
    api = NotebookAPI(client)

    try:
        with status("Deleting notebook document..."):
            api.delete_document(notebook_id)
    except APIError as e:
        print_error(f"Failed to delete notebook document: {e.message}")
        raise typer.Exit(1)

    print_success(f"Notebook document {notebook_id} deleted")


@document_app.command("duplicate")
def duplicate_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Duplicate a notebook document."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Duplicating notebook document...", json_output=json_output):
            document = api.duplicate_document(notebook_id)
    except APIError as e:
        _fail_api("duplicate notebook document", e, json_output=json_output)

    if json_output:
        _print_json(document.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Notebook document duplicated: {document.id}")
    print_notebook_document_detail(document)


@document_app.command("import")
def import_document(
    workspace_id: str = typer.Option(..., "--workspace", "-w", help="Workspace ID"),
    name: str | None = typer.Option(None, "--name", help="Notebook name override"),
    image: str | None = typer.Option(None, "--image", help="Notebook image"),
    url: str | None = typer.Option(None, "--url", help="Import notebook URL"),
    file_path: str | None = typer.Option(None, "--file", help="Import local .ipynb file"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Import notebook from URL or local file."""
    if bool(url) == bool(file_path):
        _fail("Provide exactly one of --url or --file", json_output=json_output, code="INVALID_ARGUMENT")

    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Importing notebook document...", json_output=json_output):
            document = api.import_document(
                workspace_id=workspace_id,
                name=name,
                image=image,
                url=url,
                file_path=file_path,
            )
    except (APIError, ValueError) as e:
        message = e.message if isinstance(e, APIError) else str(e)
        if isinstance(e, APIError):
            _fail_api("import notebook document", e, json_output=json_output)
        _fail(
            f"Failed to import notebook document: {message}",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )

    if json_output:
        _print_json(document.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Notebook document imported: {document.id}")
    print_notebook_document_detail(document)


@document_app.command("export")
def export_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    output: str | None = typer.Option(None, "--output", "-o", help="Write output to file"),
    download: bool = typer.Option(
        False,
        "--download",
        help="Use download response mode",
    ),
) -> None:
    """Export notebook document content."""
    client = get_client()
    api = NotebookAPI(client)
    use_download_mode = download or output is not None

    try:
        content = api.export_document(notebook_id, download=use_download_mode)
    except APIError as e:
        print_error(f"Failed to export notebook document: {e.message}")
        raise typer.Exit(1)

    if output:
        path = Path(output)
        text = content if isinstance(content, str) else json.dumps(content, indent=2)
        path.write_text(text, encoding="utf-8")
        print_success(f"Notebook exported to {path}")
        return

    if isinstance(content, str):
        print(content)
        return
    _print_json(content)


@document_app.command("save")
def save_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Persist notebook document state."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Saving notebook document...", json_output=json_output):
            document = api.save_document(notebook_id)
    except APIError as e:
        _fail_api("save notebook document", e, json_output=json_output)

    if json_output:
        _print_json(document.model_dump(by_alias=True, exclude_none=True))
        return

    print_success(f"Notebook document {document.id} saved")
    print_notebook_document_detail(document)


@document_app.command("outline")
def outline_document(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Print markdown headings from a notebook document."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        cells = api.list_cells(notebook_id, include_outputs=False)
    except APIError as e:
        _fail_api("build notebook outline", e, json_output=json_output)

    headings: list[dict[str, Any]] = []
    for cell in cells:
        if cell.cell_type != "markdown":
            continue
        for line in cell.source.splitlines():
            match = HEADING_REGEX.match(line.strip())
            if not match:
                continue
            headings.append(
                {
                    "level": len(match.group(1)),
                    "text": match.group(2).strip(),
                    "cellIndex": cell.cell_index,
                }
            )

    if json_output:
        _print_json(headings)
        return

    if not headings:
        print_error("No headings found")
        raise typer.Exit(1)

    for heading in headings:
        indent = "  " * max(0, heading["level"] - 1)
        console.print(f"{indent}- {heading['text']} [dim](cell {heading['cellIndex']})[/dim]")


# =============================================================================
# Cell Commands
# =============================================================================


def _read_content(
    content: str | None,
    file: str | None,
    *,
    json_output: bool,
) -> str:
    """Read content from argument, file, or stdin.

    Priority: file > argument > stdin
    """
    if file:
        with open(file) as f:
            return f.read()

    if content:
        return content

    # Check if stdin has data
    if not sys.stdin.isatty():
        return sys.stdin.read()

    _fail(
        "No content provided. Use argument, --file, or pipe from stdin.",
        json_output=json_output,
        code="INVALID_ARGUMENT",
    )


def _validate_cell_selector(
    cell_id: str | None,
    cell_index: int | None,
    *,
    json_output: bool = False,
) -> None:
    """Validate cell selector options."""
    has_id = bool(cell_id)
    has_index = cell_index is not None
    if has_id == has_index:
        _fail(
            "Provide exactly one of --id or --index",
            json_output=json_output,
            code="INVALID_ARGUMENT",
        )
    if cell_index is not None and cell_index < 0:
        _fail("--index must be a non-negative integer", json_output=json_output, code="INVALID_ARGUMENT")


def _resolve_cell_id(
    api: NotebookAPI,
    notebook_id: str,
    cell_id: str | None,
    cell_index: int | None,
    *,
    json_output: bool = False,
) -> str:
    """Resolve a cell selector to cell ID."""
    _validate_cell_selector(cell_id, cell_index, json_output=json_output)
    if cell_id:
        return cell_id
    cell = api.get_cell_by_index(notebook_id, cell_index or 0)
    return cell.id


def _get_selected_cell(
    api: NotebookAPI,
    notebook_id: str,
    cell_id: str | None,
    cell_index: int | None,
    *,
    json_output: bool = False,
) -> NotebookCellDetail:
    """Fetch selected cell details using explicit selector."""
    _validate_cell_selector(cell_id, cell_index, json_output=json_output)
    if cell_id:
        return api.get_cell(notebook_id, cell_id)
    return api.get_cell_by_index(notebook_id, cell_index or 0)


def _list_code_cells(api: NotebookAPI, notebook_id: str) -> list[Any]:
    """Return non-empty code cells in notebook order."""
    return [
        cell
        for cell in api.list_cells(notebook_id, include_outputs=False)
        if getattr(cell, "cell_type", None) == "code"
        and str(getattr(cell, "source", "") or "").strip() != ""
    ]


@cell_app.command("list")
@cell_app.command("ls", hidden=True)
def list_cells(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List cells in a notebook."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        detailed_cells = api.list_cells(notebook_id, include_outputs=True)
        print_cell_table(detailed_cells, json_output=json_output)
    except APIError as e:
        _fail_api("list cells", e, json_output=json_output)


@cell_app.command("get")
def get_cell(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    cell_id: str | None = typer.Option(
        None,
        "--id",
        help="Cell ID",
    ),
    cell_index: int | None = typer.Option(
        None,
        "--index",
        help="Cell index (zero-based)",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Get cell details with full output."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        cell = _get_selected_cell(
            api,
            notebook_id,
            cell_id,
            cell_index,
            json_output=json_output,
        )
        print_cell_detail(cell, json_output=json_output)
    except APIError as e:
        _fail_api("get cell", e, json_output=json_output)


@cell_app.command("add")
def add_cell(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    content: str | None = typer.Argument(None, help="Cell content"),
    cell_type: str = typer.Option("code", "--type", "-t", help="Cell type: code, markdown, raw"),
    index: int | None = typer.Option(None, "--index", "-i", help="Position (default: end)"),
    file: str | None = typer.Option(None, "--file", "-f", help="Read content from file"),
    execute: bool = typer.Option(False, "--execute", "-x", help="Execute after adding"),
    wait: bool = typer.Option(
        True,
        "--wait/--no-wait",
        help="Wait for execution to complete",
    ),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Add a new cell to a notebook."""
    client = get_client()
    api = NotebookAPI(client)

    source = _read_content(content, file, json_output=json_output)

    try:
        with _status_context("Adding cell...", json_output=json_output):
            cell = api.add_cell(notebook_id, source, cell_type=cell_type, index=index)

        if json_output and not execute:
            _print_json({"id": cell.id, "index": cell.cell_index})
        elif not execute:
            print_success(f"Cell {cell.id} added at index {cell.cell_index}")

        if execute:
            _execute_cell_impl(
                api,
                notebook_id,
                cell_id=cell.id,
                wait=wait,
                json_output=json_output,
            )

    except APIError as e:
        _fail_api("add cell", e, json_output=json_output)


@cell_app.command("set")
def set_cell(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    content: str | None = typer.Argument(None, help="New content"),
    cell_id: str | None = typer.Option(
        None,
        "--id",
        help="Cell ID",
    ),
    cell_index: int | None = typer.Option(
        None,
        "--index",
        help="Cell index (zero-based)",
    ),
    file: str | None = typer.Option(None, "--file", "-f", help="Read content from file"),
    execute: bool = typer.Option(False, "--execute", "-x", help="Execute after updating"),
    wait: bool = typer.Option(
        True,
        "--wait/--no-wait",
        help="Wait for execution to complete",
    ),
    timeout: int = typer.Option(30, "--timeout", help="Wait timeout in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Update an existing cell."""
    client = get_client()
    api = NotebookAPI(client)

    source = _read_content(content, file, json_output=json_output)

    try:
        selected_cell = _get_selected_cell(
            api,
            notebook_id,
            cell_id,
            cell_index,
            json_output=json_output,
        )
        with _status_context("Updating cell...", json_output=json_output):
            cell = api.update_cell_source(
                notebook_id,
                selected_cell.id,
                source,
                expected_version=selected_cell.source_ot_version,
            )

        if json_output and not execute:
            _print_json({"id": cell.id, "updated": True})
        elif not execute:
            print_success(f"Cell {cell.id} updated")

        if execute:
            _execute_cell_impl(
                api,
                notebook_id,
                cell_id=selected_cell.id,
                wait=wait,
                timeout=timeout,
                json_output=json_output,
            )

    except APIError as e:
        if e.status_code == 409:
            current_version = e.details.get("currentVersion")
            detail = (
                f"Version conflict (current sourceOtVersion={current_version}). "
                "Refresh the cell and retry."
                if current_version is not None
                else "Version conflict. Refresh the cell and retry."
            )
            _fail(
                f"Failed to update cell: {detail}",
                json_output=json_output,
                code="VERSION_CONFLICT",
                details={"currentVersion": current_version},
            )
        _fail_api("update cell", e, json_output=json_output)


@cell_app.command("rm")
@cell_app.command("remove", hidden=True)
@cell_app.command("delete", hidden=True)
def remove_cell(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    cell_id: str | None = typer.Option(
        None,
        "--id",
        help="Cell ID",
    ),
    cell_index: int | None = typer.Option(
        None,
        "--index",
        help="Cell index (zero-based)",
    ),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Delete a cell."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        resolved_cell_id = _resolve_cell_id(
            api,
            notebook_id,
            cell_id,
            cell_index,
            json_output=json_output,
        )
        selector_label = cell_id or f"#{cell_index}"
        if not force:
            typer.confirm(f"Delete cell {selector_label}?", abort=True)

        with _status_context("Deleting cell...", json_output=json_output):
            api.delete_cell(notebook_id, resolved_cell_id)

        if json_output:
            _print_json({"id": resolved_cell_id, "deleted": True})
        else:
            print_success(f"Cell {resolved_cell_id} deleted")
    except APIError as e:
        _fail_api("delete cell", e, json_output=json_output)


@cell_app.command("execute")
def execute_cell(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    cell_id: str | None = typer.Option(
        None,
        "--id",
        help="Cell ID",
    ),
    cell_index: int | None = typer.Option(
        None,
        "--index",
        help="Cell index (zero-based)",
    ),
    wait: bool = typer.Option(
        True,
        "--wait/--no-wait",
        help="Wait for execution to complete",
    ),
    timeout: int = typer.Option(30, "--timeout", help="Wait timeout in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Execute a cell."""
    client = get_client()
    api = NotebookAPI(client)

    _execute_cell_impl(
        api,
        notebook_id,
        cell_id=cell_id,
        cell_index=cell_index,
        wait=wait,
        timeout=timeout,
        json_output=json_output,
    )


@cell_app.command("execute-all")
def execute_all_cells(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    restart: bool = typer.Option(
        False,
        "--restart",
        help="Restart kernel before executing all code cells",
    ),
    timeout: int = typer.Option(30, "--timeout", help="Wait timeout in seconds"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Execute all code cells in notebook order and stop on first error."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        code_cells = _list_code_cells(api, notebook_id)
    except APIError as e:
        _fail_api("list notebook cells", e, json_output=json_output)

    total_code_cells = len(code_cells)
    if total_code_cells == 0:
        payload = {"status": "noop", "executedCellCount": 0, "totalCodeCells": 0}
        if json_output:
            _print_json(payload)
        else:
            print_success("No code cells to execute")
        return

    if restart:
        try:
            with _status_context("Restarting notebook kernel...", json_output=json_output):
                api.restart_kernel(notebook_id)
            _wait_for_kernel_ready(api, notebook_id, timeout=timeout, ensure=False)
        except APIError as e:
            _fail_api("restart kernel", e, json_output=json_output)
        except TimeoutError as e:
            _fail(str(e), json_output=json_output, code="TIMEOUT")

    execution_results: list[dict[str, Any]] = []
    for index, cell in enumerate(code_cells, start=1):
        if not json_output:
            print(f"[{index}/{total_code_cells}] Executing cell {cell.id}...")

        result = _execute_cell_impl(
            api,
            notebook_id,
            cell_id=cell.id,
            wait=True,
            timeout=timeout,
            json_output=json_output,
            emit_output=not json_output,
        )
        result_payload = {"cellId": cell.id, **(result or {})}
        execution_results.append(result_payload)

        if str(result_payload.get("status") or "").lower() == "error":
            summary = {
                "status": "error",
                "executedCellCount": index,
                "totalCodeCells": total_code_cells,
                "stoppedAtCellId": cell.id,
                "results": execution_results,
            }
            if json_output:
                _print_json(summary)
            else:
                print_error(f"Execution stopped at cell {cell.id} ({index}/{total_code_cells})")
            raise typer.Exit(1)

    summary = {
        "status": "ok",
        "executedCellCount": total_code_cells,
        "totalCodeCells": total_code_cells,
        "results": execution_results,
    }
    if json_output:
        _print_json(summary)
    else:
        print_success(f"Executed {total_code_cells} code cell(s)")


@cell_app.command("clear-outputs")
def clear_notebook_outputs(
    notebook_id: str = typer.Argument(..., help="Notebook ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """Clear outputs for all code cells in a notebook."""
    if not force:
        typer.confirm(f"Clear outputs for notebook {notebook_id}?", abort=True)

    client = get_client()
    api = NotebookAPI(client)

    try:
        with _status_context("Clearing notebook outputs...", json_output=json_output):
            result = api.clear_notebook_outputs(notebook_id)
    except APIError as e:
        _fail_api("clear notebook outputs", e, json_output=json_output)

    if json_output:
        _print_json(result)
        return

    cleared = int(result.get("clearedCellCount") or 0)
    print_success(f"Cleared outputs for {cleared} code cell(s)")


@file_app.command("ls")
def list_notebook_files(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    path: str = typer.Argument("/", help="Notebook workspace path"),
) -> None:
    """List notebook-scoped files."""
    client = get_client()
    api = NotebookAPI(client)
    normalized_path = "" if path == "/" else path.lstrip("/")

    try:
        _wait_for_kernel_ready(api, notebook_id)
        files = api.list_files(notebook_id, normalized_path or None)
    except APIError as e:
        print_error(f"Failed to list notebook files: {e.message}")
        raise typer.Exit(1)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)

    print_file_table(files)


@file_app.command("mkdir")
def make_notebook_directory(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    path: str = typer.Argument(..., help="Notebook workspace directory path"),
) -> None:
    """Create a notebook-scoped directory."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        _wait_for_kernel_ready(api, notebook_id)
        with status(f"Creating directory {path}..."):
            api.create_directory(notebook_id, path.lstrip("/"))
    except APIError as e:
        print_error(f"Failed to create notebook directory: {e.message}")
        raise typer.Exit(1)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)

    print_success(f"Directory created: {path}")


@file_app.command("upload")
def upload_notebook_file(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    local_path: str = typer.Argument(..., help="Local file path"),
    remote_path: str | None = typer.Argument(
        None,
        help="Destination directory or file path inside the notebook workspace",
    ),
) -> None:
    """Upload a file into the notebook workspace."""
    local_file = Path(local_path)
    if not local_file.exists():
        print_error(f"File not found: {local_path}")
        raise typer.Exit(1)

    client = get_client()
    api = NotebookAPI(client)
    remote_directory, remote_filename = _split_upload_destination(remote_path)

    try:
        _wait_for_kernel_ready(api, notebook_id)
        with status(f"Uploading {local_file.name}..."):
            metadata = api.upload_file(
                notebook_id,
                str(local_file),
                remote_directory,
                remote_filename,
            )
    except APIError as e:
        print_error(f"Failed to upload notebook file: {e.message}")
        raise typer.Exit(1)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)

    print_success(f"File uploaded: {metadata.path}")


@file_app.command("download")
def download_notebook_file(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    remote_path: str = typer.Argument(..., help="Notebook workspace file path"),
    local_path: str | None = typer.Argument(None, help="Local output path"),
) -> None:
    """Download a file from the notebook workspace."""
    output_path = local_path or Path(remote_path).name
    client = get_client()
    api = NotebookAPI(client)

    try:
        _wait_for_kernel_ready(api, notebook_id)
        with status(f"Downloading {remote_path}..."):
            api.download_file(notebook_id, remote_path.lstrip("/"), output_path)
    except APIError as e:
        print_error(f"Failed to download notebook file: {e.message}")
        raise typer.Exit(1)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)

    print_success(f"File downloaded: {output_path}")


@file_app.command("rm")
def remove_notebook_file(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    path: str = typer.Argument(..., help="Notebook workspace file or directory path"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a notebook-scoped file or directory."""
    if not force:
        typer.confirm(f"Delete {path}?", abort=True)

    client = get_client()
    api = NotebookAPI(client)

    try:
        _wait_for_kernel_ready(api, notebook_id)
        with status(f"Deleting {path}..."):
            api.delete_file(notebook_id, path.lstrip("/"))
    except APIError as e:
        print_error(f"Failed to delete notebook file: {e.message}")
        raise typer.Exit(1)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)

    print_success(f"Deleted: {path}")


@collab_app.command("ls")
def list_notebook_collaborators(
    notebook_id: str = typer.Argument(..., help="Notebook document ID"),
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List active collaborators for a notebook."""
    client = get_client()
    api = NotebookAPI(client)

    try:
        collaborators = api.list_collaborators(notebook_id)
    except APIError as e:
        _fail_api("list notebook collaborators", e, json_output=json_output)

    if json_output:
        _print_json(
            [item.model_dump(by_alias=True, exclude_none=True) for item in collaborators]
        )
        return

    if not collaborators:
        print_error("No active collaborators")
        raise typer.Exit(1)

    for collaborator in collaborators:
        name = (
            (collaborator.user_data or {}).get("name")
            or collaborator.user_id
        )
        print(f"{name} ({collaborator.user_id})")


def _execute_cell_impl(
    api: NotebookAPI,
    notebook_id: str,
    cell_id: str | None = None,
    cell_index: int | None = None,
    source: str | None = None,
    wait: bool = True,
    timeout: int = 30,
    json_output: bool = False,
    emit_output: bool = True,
) -> dict[str, Any]:
    """Execute a cell implementation."""
    def _normalize_outputs(cell: NotebookCellDetail) -> list[dict[str, Any]]:
        outputs = getattr(cell, "outputs", None)
        if not isinstance(outputs, list):
            return []
        return [o.model_dump(by_alias=True, exclude_none=True) for o in outputs]

    def _is_execution_complete(
        cell: NotebookCellDetail,
        baseline_outputs: list[dict[str, Any]],
        baseline_execution_count: int | None,
        baseline_last_run_at: int | None,
        baseline_last_run_duration: float | int | None,
    ) -> bool:
        outputs = getattr(cell, "outputs", None)
        has_outputs = isinstance(outputs, (list, tuple)) and len(outputs) > 0
        has_execution_count = isinstance(cell.execution_count, int)
        has_last_run_at = isinstance(cell.last_run_at, int)
        has_last_run_duration = isinstance(cell.last_run_duration, (int, float))
        execution_settled = cell.status not in ("starting", "running")
        return (
            cell.status in ("ok", "error")
            or (has_outputs and _normalize_outputs(cell) != baseline_outputs)
            or (has_execution_count and cell.execution_count != baseline_execution_count)
            or (
                execution_settled
                and has_last_run_at
                and cell.last_run_at != baseline_last_run_at
            )
            or (
                execution_settled
                and has_last_run_duration
                and cell.last_run_duration != baseline_last_run_duration
            )
        )

    try:
        _validate_cell_selector(cell_id, cell_index, json_output=json_output)
        baseline_cell = _get_selected_cell(
            api,
            notebook_id,
            cell_id,
            cell_index,
            json_output=json_output,
        )
        baseline_outputs = _normalize_outputs(baseline_cell)
        baseline_execution_count = (
            baseline_cell.execution_count if isinstance(baseline_cell.execution_count, int) else None
        )
        baseline_last_run_at = (
            baseline_cell.last_run_at if isinstance(baseline_cell.last_run_at, int) else None
        )
        baseline_last_run_duration = (
            baseline_cell.last_run_duration
            if isinstance(baseline_cell.last_run_duration, (int, float))
            else None
        )

        result = api.execute_cell(
            notebook_id,
            cell_id=cell_id,
            cell_index=cell_index,
            source=source,
        )

        if not wait:
            payload = {
                "executionId": result.execution_id,
                "status": result.status,
            }
            if emit_output and json_output:
                _print_json(payload)
            elif emit_output:
                print_execution_result(payload, waited=False)
            return payload

        if result.status == "queued" and emit_output and not json_output:
            print("Execution queued; waiting for completion...")

        # Wait for completion by polling cell status
        import time
        start = time.time()
        while time.time() - start < timeout:
            cell = _get_selected_cell(
                api,
                notebook_id,
                cell_id,
                cell_index,
                json_output=json_output,
            )
            if _is_execution_complete(
                cell,
                baseline_outputs,
                baseline_execution_count,
                baseline_last_run_at,
                baseline_last_run_duration,
            ):
                normalized_outputs = _normalize_outputs(cell)
                final_status = cell.status or ("error" if any(
                    output.get("outputType") == "error" or output.get("output_type") == "error"
                    for output in normalized_outputs
                ) else "completed")
                result_data = {
                    "status": final_status,
                    "executionCount": cell.execution_count,
                    "lastRunDuration": cell.last_run_duration,
                    "outputs": normalized_outputs,
                }
                if emit_output and json_output:
                    _print_json(result_data)
                elif emit_output:
                    print_execution_result(result_data, waited=True)
                return result_data
            time.sleep(0.5)

        _fail(f"Execution timeout after {timeout}s", json_output=json_output, code="TIMEOUT")

    except APIError as e:
        _fail_api("execute cell", e, json_output=json_output)
