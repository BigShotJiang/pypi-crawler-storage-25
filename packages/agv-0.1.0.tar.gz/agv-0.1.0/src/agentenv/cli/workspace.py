"""Workspace CLI commands."""

import json

import typer

from ..api.client import APIError, Client
from ..api.workspace import WorkspaceAPI
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_error,
    print_success,
    print_workspace_table,
)

app = typer.Typer(help="Workspace management commands")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


@app.command("create")
def create_workspace(
    name: str = typer.Argument(..., help="Workspace name"),
) -> None:
    """Create a new workspace.

    Examples:
        av workspace create "My Workspace"
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Creating workspace '{name}'..."):
            workspace = api.create(name)
    except APIError as e:
        print_error(f"Failed to create workspace: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(workspace)
        return

    print_success(f"Workspace {workspace.id} created")
    print(f"  Name: {workspace.name}")


@app.command("ls")
def list_workspaces(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
) -> None:
    """List workspaces."""
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        workspaces = api.list_all()
    except APIError as e:
        print_error(f"Failed to list workspaces: {e.message}")
        raise typer.Exit(1)

    if json_output or json_output_enabled():
        print(
            json.dumps(
                [ws.model_dump(by_alias=True, exclude_none=True) for ws in workspaces],
                indent=2,
                default=str,
            )
        )
        return

    print_workspace_table(workspaces)


@app.command("list", deprecated=True)
def list_workspaces_alt() -> None:
    """List workspaces (alias for ls)."""
    list_workspaces()


@app.command()
def inspect(workspace_id: str = typer.Argument(..., help="Workspace ID")) -> None:
    """Show workspace details.

    Examples:
        av workspace inspect wk_abc123
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        workspace = api.get(workspace_id)
    except APIError as e:
        print_error(f"Failed to get workspace: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(workspace)
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _format_datetime

    console = Console()
    table = Table(title=f"Workspace: {workspace.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", workspace.id)
    table.add_row("Name", workspace.name)
    table.add_row("Owner", workspace.owner_id)
    table.add_row("Created", _format_datetime(workspace.created_at))

    if workspace.members:
        table.add_section()
        table.add_row("Members", "")
        for member in workspace.members:
            role_color = "green" if member.role == "owner" else "blue"
            table.add_row(
                "",
                f"{member.email} [{role_color}]{member.role}[/{role_color}]",
            )

    console.print(table)


@app.command("use")
def use_workspace(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
) -> None:
    """Set default workspace.

    Examples:
        av workspace use wk_abc123
    """
    settings = get_settings()
    settings.workspace = workspace_id
    settings.save()

    print_success(f"Default workspace set to {workspace_id}")


@app.command("invite")
def invite_member(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    email: str = typer.Argument(..., help="Member email"),
) -> None:
    """Invite a member to the workspace.

    Examples:
        av workspace invite wk_abc123 user@example.com
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Inviting {email} to workspace..."):
            result = api.invite_member(workspace_id, email)
    except APIError as e:
        print_error(f"Failed to invite member: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    print_success(f"Invitation sent to {email}")
    if "code" in result:
        print(f"  Invite code: {result['code']}")


@app.command("members")
def list_members(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
) -> None:
    """List workspace members.

    Examples:
        av workspace members wk_abc123
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        members = api.get_members(workspace_id)
    except APIError as e:
        print_error(f"Failed to list members: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(members)
        return

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _format_datetime

    console = Console()
    table = Table(title=f"Members of {workspace_id}")
    table.add_column("Email")
    table.add_column("Role")
    table.add_column("Joined")

    for member in members:
        role_color = "green" if member.role == "owner" else "blue"
        table.add_row(
            member.email,
            f"[{role_color}]{member.role}[/{role_color}]",
            _format_datetime(member.joined_at),
        )

    console.print(table)


@app.command("remove-member")
def remove_member(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    user_id: str = typer.Argument(..., help="User ID to remove"),
) -> None:
    """Remove a member from the workspace.

    Examples:
        av workspace remove-member wk_abc123 user_123
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Removing member {user_id}..."):
            api.remove_member(workspace_id, user_id)
    except APIError as e:
        print_error(f"Failed to remove member: {e.message}")
        raise typer.Exit(1)

    print_success(f"Member {user_id} removed")


@app.command("rm")
def delete_workspace(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a workspace.

    Examples:
        av workspace rm wk_abc123
    """
    if not force:
        typer.confirm(f"Delete workspace {workspace_id}?", abort=True)

    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Deleting workspace {workspace_id}..."):
            api.delete(workspace_id)
    except APIError as e:
        print_error(f"Failed to delete workspace: {e.message}")
        raise typer.Exit(1)

    print_success(f"Workspace {workspace_id} deleted")

    # Clear default workspace if it was the deleted one
    settings = get_settings()
    if settings.workspace == workspace_id:
        settings.workspace = None
        settings.save()


@app.command("delete", deprecated=True)
def delete_workspace_alt(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a workspace (alias for rm)."""
    delete_workspace(workspace_id, force=True)


# =============================================================================
# Secret management
# =============================================================================

@app.command("secret-ls")
def list_secrets(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
) -> None:
    """List workspace secrets.

    Examples:
        av workspace secret-ls wk_abc123
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        secrets = api.list_secrets(workspace_id)
    except APIError as e:
        print_error(f"Failed to list secrets: {e.message}")
        raise typer.Exit(1)

    from rich.console import Console
    from rich.table import Table

    console = Console()
    table = Table(title=f"Secrets in {workspace_id}")
    table.add_column("ID")
    table.add_column("Key")
    table.add_column("Created")

    for secret in secrets:
        table.add_row(
            secret.get("id", "")[:12],
            secret.get("key", "-"),
            secret.get("createdAt", "-"),
        )

    console.print(table)


@app.command("secret-set")
def set_secret(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    key: str = typer.Argument(..., help="Secret key"),
    value: str = typer.Argument(..., help="Secret value"),
) -> None:
    """Set a workspace secret.

    Examples:
        av workspace secret-set wk_abc123 API_KEY xxxxx
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Setting secret '{key}'..."):
            api.create_secret(workspace_id, key, value)
    except APIError as e:
        print_error(f"Failed to set secret: {e.message}")
        raise typer.Exit(1)

    print_success(f"Secret '{key}' set")


@app.command("secret-rm")
def delete_secret(
    workspace_id: str = typer.Argument(..., help="Workspace ID"),
    secret_id: str = typer.Argument(..., help="Secret ID"),
) -> None:
    """Delete a workspace secret.

    Examples:
        av workspace secret-rm wk_abc123 secret_123
    """
    client = get_client()
    api = WorkspaceAPI(client)

    try:
        with status(f"Deleting secret {secret_id}..."):
            api.delete_secret(workspace_id, secret_id)
    except APIError as e:
        print_error(f"Failed to delete secret: {e.message}")
        raise typer.Exit(1)

    print_success(f"Secret {secret_id} deleted")
