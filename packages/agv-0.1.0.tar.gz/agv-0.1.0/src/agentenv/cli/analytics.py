"""Analytics CLI commands."""

from typing import Optional

import typer

from ..api.client import Client
from ..api.analytics import AnalyticsAPI
from ..config.settings import get_settings
from ..ui.tables import (
    print_error,
    print_success,
    print_warning,
)
from ..ui.progress import status


app = typer.Typer(help="Analytics management commands")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


@app.command("installations")
def list_installations(
    json_output: bool = typer.Option(False, "--json", help="Output as JSON"),
):
    """List analytics installations."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        installations = api.list_installations()
        
        if not installations:
            print_warning("No installations found.")
            return

        if json_output:
            import json
            print(json.dumps([i.model_dump() for i in installations], indent=2, default=str))
        else:
            print(f"{'ID':<36} {'Name':<30} {'API Key':<40} {'Active'}")
            print("-" * 110)
            for inst in installations:
                print(f"{inst.id:<36} {inst.name:<30} {inst.api_key:<40} {inst.is_active}")
    except Exception as e:
        print_error(f"Failed to list installations: {e}")
        raise typer.Exit(1)


@app.command("create")
def create_installation(
    name: str = typer.Argument(..., help="Installation name"),
):
    """Create a new analytics installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        with status(f"Creating installation '{name}'..."):
            installation = api.create_installation(name)
        
        print_success(f"Created installation: {installation.name}")
        print(f"API Key: {installation.api_key}")
        print(f"ID: {installation.id}")
    except Exception as e:
        print_error(f"Failed to create installation: {e}")
        raise typer.Exit(1)


@app.command("script")
def get_script(
    installation_id: str = typer.Argument(..., help="Installation ID"),
):
    """Get installation script tag."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        script_data = api.get_installation_script(installation_id)
        print(script_data.get("scriptTag", ""))
    except Exception as e:
        print_error(f"Failed to get script: {e}")
        raise typer.Exit(1)


@app.command("stats")
def get_stats(
    installation_id: Optional[str] = typer.Option(None, "--installation", help="Installation ID filter"),
):
    """Get analytics statistics."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        stats = api.get_stats(installation_id)
        
        print(f"Total Sessions: {stats.get('totalSessions', 0)}")
        print(f"Total Page Views: {stats.get('totalPageViews', 0)}")
        print(f"Unique Visitors: {stats.get('uniqueVisitors', 0)}")
        print(f"Total Events: {stats.get('totalEvents', 0)}")
        print(f"Total Users: {stats.get('totalUsers', 0)}")
    except Exception as e:
        print_error(f"Failed to get stats: {e}")
        raise typer.Exit(1)


@app.command("realtime")
def get_realtime_stats():
    """Get real-time statistics."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        stats = api.get_realtime_stats()
        
        print(f"Active Users (5m): {stats.get('activeUsers', 0)}")
        print(f"Recent Events: {stats.get('recentEvents', 0)}")
        print(f"Recent Page Views: {stats.get('recentPageViews', 0)}")
    except Exception as e:
        print_error(f"Failed to get realtime stats: {e}")
        raise typer.Exit(1)


@app.command("events")
def list_events(
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
    event_name: Optional[str] = typer.Option(None, "--event-name", help="Filter by event name"),
    fingerprint: Optional[str] = typer.Option(None, "--fingerprint", help="Filter by user fingerprint"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of events"),
):
    """List analytics events for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        events = api.query_events(
            installation_id=installation,
            event_name=event_name,
            fingerprint=fingerprint,
            limit=limit,
        )

        if not events:
            print_warning("No events found.")
            return

        print(f"{'ID':<36} {'Name':<30} {'Fingerprint':<20} {'Timestamp'}")
        print("-" * 100)
        for event in events:
            timestamp = event.timestamp.strftime("%Y-%m-%d %H:%M") if event.timestamp else "N/A"
            print(f"{event.id:<36} {event.event_name:<30} {event.fingerprint[:20]:<20} {timestamp}")
    except Exception as e:
        print_error(f"Failed to list events: {e}")
        raise typer.Exit(1)


@app.command("funnels")
def list_funnels(
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
):
    """List analytics funnels for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        funnels = api.list_funnels(installation_id=installation)

        if not funnels:
            print_warning("No funnels found.")
            return

        print(f"{'ID':<36} {'Name':<30} {'Steps':<10} {'Active'}")
        print("-" * 80)
        for funnel in funnels:
            print(f"{funnel.id:<36} {funnel.name:<30} {len(funnel.steps):<10} {funnel.is_active}")
    except Exception as e:
        print_error(f"Failed to list funnels: {e}")
        raise typer.Exit(1)


@app.command("funnel-create")
def create_funnel(
    name: str = typer.Argument(..., help="Funnel name"),
    steps: list[str] = typer.Option(..., "--step", help="Funnel steps (format: 'step_name:event_name')"),
):
    """Create a new funnel."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        # Parse steps
        parsed_steps = []
        for step in steps:
            if ":" not in step:
                print_error(f"Invalid step format: {step}. Use 'step_name:event_name'")
                raise typer.Exit(1)
            step_name, event_name = step.split(":", 1)
            parsed_steps.append({"name": step_name, "eventName": event_name})

        funnel = api.create_funnel(name, parsed_steps)
        print_success(f"Created funnel: {funnel.name}")
        print(f"ID: {funnel.id}")
        print(f"Steps: {len(funnel.steps)}")
    except Exception as e:
        print_error(f"Failed to create funnel: {e}")
        raise typer.Exit(1)


@app.command("funnel-analyze")
def analyze_funnel(
    funnel_id: str = typer.Argument(..., help="Funnel ID"),
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
    days: int = typer.Option(7, "--days", help="Number of days to analyze"),
):
    """Analyze funnel conversion for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        analysis = api.analyze_funnel(funnel_id, installation_id=installation, days=days)

        print(f"Funnel: {analysis.get('funnelName', 'Unknown')}")
        print(f"Total Conversion: {analysis.get('totalConversion', 0):.2f}%")
        print()

        steps = analysis.get('steps', [])
        print(f"{'Step':<6} {'Name':<30} {'Users':<10} {'Conversion %':<15} {'Drop-off %'}")
        print("-" * 80)
        for step in steps:
            print(f"{step.get('step', 0):<6} {step.get('name', ''):<30} "
                  f"{step.get('uniqueUsers', 0):<10} {step.get('conversionRate', 0):<15.2f} "
                  f"{step.get('dropOffRate', 0):.2f}")
    except Exception as e:
        print_error(f"Failed to analyze funnel: {e}")
        raise typer.Exit(1)


@app.command("users")
def list_users(
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
    limit: int = typer.Option(100, "--limit", help="Maximum number of users"),
):
    """List user profiles for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        users = api.list_users(installation_id=installation, limit=limit)

        if not users:
            print_warning("No users found.")
            return

        print(f"{'Fingerprint':<20} {'Email':<30} {'Sessions':<10} {'Last Seen'}")
        print("-" * 80)
        for user in users:
            email = user.email or "N/A"
            last_seen = user.last_seen_at.strftime("%Y-%m-%d") if user.last_seen_at else "N/A"
            print(f"{user.fingerprint[:20]:<20} {email:<30} {user.session_count:<10} {last_seen}")
    except Exception as e:
        print_error(f"Failed to list users: {e}")
        raise typer.Exit(1)


@app.command("trajectory")
def get_trajectory(
    fingerprint: str = typer.Argument(..., help="User fingerprint"),
    installation: str = typer.Option(..., "--installation", help="Installation ID (required)"),
):
    """Get user trajectory for an installation."""
    client = get_client()
    api = AnalyticsAPI(client)

    try:
        trajectory = api.get_trajectory(fingerprint, installation_id=installation)

        if not trajectory:
            print_warning("No trajectory found for this fingerprint.")
            return

        for session in trajectory:
            print(f"Session: {session.get('sessionId', 'Unknown')}")
            print(f"  Started: {session.get('startedAt', 'N/A')}")
            print(f"  Duration: {session.get('duration', 0)}s")
            print(f"  Pages visited:")
            for page in session.get('pages', []):
                print(f"    - {page.get('url', 'Unknown')} ({page.get('timestamp', 'N/A')})")
            print()
    except Exception as e:
        print_error(f"Failed to get trajectory: {e}")
        raise typer.Exit(1)
