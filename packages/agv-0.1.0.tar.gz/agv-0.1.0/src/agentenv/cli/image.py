"""Image CLI commands."""

from __future__ import annotations

import json
from pathlib import Path

import typer

from ..api.client import APIError, Client
from ..api.image import ImageAPI
from ..config.settings import get_settings
from ..sdk.image import ImageBuilder
from ..sdk.image import image as image_builder
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_error,
    print_image_detail,
    print_image_table,
    print_image_tags_table,
    print_success,
    print_warning,
)

app = typer.Typer(help="Image build and management commands")


def get_client() -> Client:
    settings = get_settings()
    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)
    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _parse_env_list(env: list[str]) -> dict[str, str]:
    result: dict[str, str] = {}
    for item in env:
        if "=" in item:
            key, value = item.split("=", 1)
            result[key] = value
        else:
            import os
            value = os.getenv(item)
            if value is None:
                print_warning(f"Environment variable {item} not set, skipping")
            else:
                result[item] = value
    return result


def _load_config(path: Path) -> dict:
    if path.suffix.lower() == ".json":
        return json.loads(path.read_text(encoding="utf-8"))
    import yaml
    return yaml.safe_load(path.read_text(encoding="utf-8")) or {}


def _find_default_config() -> Path | None:
    for name in ("agentenv-image.yaml", "agentenv-image.yml", "agentenv-image.json"):
        candidate = Path.cwd() / name
        if candidate.exists():
            return candidate
    return None


def _apply_steps(builder: ImageBuilder, steps: list[dict]) -> None:
    for step in steps:
        if isinstance(step, str):
            builder.execute(step)
            continue
        if not isinstance(step, dict) or len(step) != 1:
            raise ValueError(f"Invalid step format: {step}")

        key, value = next(iter(step.items()))
        if key == "execute":
            if isinstance(value, str):
                builder.execute(value)
            else:
                builder.execute(
                    value.get("command"),
                    env=value.get("env"),
                    workdir=value.get("workdir"),
                )
            continue

        if key == "python_packages":
            packages = value.get("packages") if isinstance(value, dict) else value
            builder.python_packages(packages or [])
            continue

        if key in {"requirements_file", "requirement_file"}:
            path = value.get("path") if isinstance(value, dict) else value
            builder.requirement_file(path)
            continue

        if key == "pyproject_toml":
            path = value.get("path") if isinstance(value, dict) else value
            builder.pyproject_toml(path)
            continue

        if key == "uv_lock":
            path = value.get("path") if isinstance(value, dict) else value
            builder.uv_lock(path)
            continue

        if key == "copy":
            if isinstance(value, str):
                builder.copy(value)
            else:
                builder.copy(
                    value.get("src") or value.get("source"),
                    remote_path=value.get("dest"),
                    ignore=value.get("ignore"),
                    sync=bool(value.get("sync")),
                )
            continue

        if key == "remove":
            builder.remove(value if isinstance(value, str) else value.get("path"))
            continue

        if key == "git_clone":
            if not isinstance(value, dict):
                raise ValueError("git_clone step must be a mapping")
            builder.git_clone(
                url=value.get("url"),
                path=value.get("path"),
                ref=value.get("ref"),
                depth=value.get("depth", 1),
                token=value.get("token"),
                ssh_key_path=value.get("ssh_key"),
                submodules=bool(value.get("submodules")),
            )
            continue

        if key == "system_packages":
            packages = value.get("packages") if isinstance(value, dict) else value
            builder.system_packages(packages or [])
            continue

        if key == "execute_python_script":
            if isinstance(value, str):
                builder.execute_python_script(value)
            else:
                builder.execute_python_script(
                    value.get("script"),
                    python_path=value.get("python_path"),
                    env=value.get("env"),
                    workdir=value.get("workdir"),
                )
            continue

        if key == "execute_nodejs_script":
            if isinstance(value, str):
                builder.execute_nodejs_script(value)
            else:
                builder.execute_nodejs_script(
                    value.get("script"),
                    node_path=value.get("node_path"),
                    env=value.get("env"),
                    workdir=value.get("workdir"),
                )
            continue

        if key == "enable_ray":
            if isinstance(value, dict):
                builder.enable_ray(
                    break_system_packages=bool(value.get("break_system_packages")),
                    pip_args=value.get("pip_args"),
                    python_path=value.get("python_path"),
                )
            else:
                builder.enable_ray()
            continue

        if key == "enable_spark":
            if isinstance(value, dict):
                builder.enable_spark(
                    spark_version=value.get("spark_version"),
                    hadoop=value.get("hadoop"),
                    install_path=value.get("install_path"),
                )
            else:
                builder.enable_spark()
            continue

        raise ValueError(f"Unknown step type: {key}")


@app.command("build")
def build_image(
    file: Path | None = typer.Option(None, "--file", "-f", help="Image config file"),
    image: str | None = typer.Option(None, "--image", help="Base image"),
    snapshot: str | None = typer.Option(None, "--snapshot", help="Base snapshot ID"),
    name: str | None = typer.Option(None, "--name", help="Image name"),
    tag: list[str] = typer.Option([], "--tag", "-t", help="Image tag (repeatable)"),
    workdir: str | None = typer.Option(None, "--workdir", help="Default workdir for build"),
    env: list[str] = typer.Option([], "--env", "-e", help="Build environment variables"),
    cache: str | None = typer.Option(None, "--cache", help="Cache mode: reuse or clean"),
    force: bool = typer.Option(False, "--force", help="Force rebuild if failed"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for build to complete"),
    timeout: int = typer.Option(900, "--timeout", help="Build timeout in seconds"),
    no_progress: bool = typer.Option(False, "--no-progress", help="Disable progress output"),
) -> None:
    """Build an image from steps."""
    settings = get_settings()
    if not settings.workspace:
        print_error("Workspace is required to build images")
        raise typer.Exit(1)

    config_path = file or _find_default_config()
    config: dict = {}
    if config_path:
        try:
            config = _load_config(config_path)
        except Exception as exc:
            print_error(f"Failed to load config: {exc}")
            raise typer.Exit(1)

    base_image = image or config.get("base_image") or config.get("image")
    base_snapshot = snapshot or config.get("base_snapshot") or config.get("snapshot")
    image_name = name or config.get("name")
    config_tags = config.get("tags") or []
    config_caps = config.get("capabilities") or []
    if isinstance(config_tags, str):
        config_tags = [config_tags]
    if isinstance(config_caps, str):
        config_caps = [config_caps]
    tags = list(dict.fromkeys(tag + list(config_tags)))
    workdir_value = workdir or config.get("workdir")
    cache_mode = cache or config.get("cache") or "reuse"

    env_values = {}
    if isinstance(config.get("env"), dict):
        env_values.update({str(k): str(v) for k, v in config.get("env").items()})
    if isinstance(config.get("build_args"), dict):
        env_values.update({str(k): str(v) for k, v in config.get("build_args").items()})
    env_values.update(_parse_env_list(env))

    steps = config.get("steps") or []
    if not steps:
        print_error("No steps provided (config file required or include steps)")
        raise typer.Exit(1)

    if not base_image and not base_snapshot:
        print_error("Base image or base snapshot is required")
        raise typer.Exit(1)

    builder = image_builder(
        base_image=base_image,
        base_snapshot_id=base_snapshot,
        workspace_id=settings.workspace,
        name=image_name,
    )

    if env_values:
        builder.env(env_values)
    if workdir_value:
        builder.workdir(workdir_value)
    if cache_mode:
        builder.cache(cache_mode)
    if tags:
        builder.tags(tags)
    if config_caps:
        builder.capabilities(config_caps)

    try:
        _apply_steps(builder, steps)
    except Exception as exc:
        print_error(str(exc))
        raise typer.Exit(1)

    image_id_holder: dict[str, str | None] = {"id": None}

    if no_progress:
        try:
            image_obj = builder.finalize(timeout=timeout, force=force, wait=wait)
        except (APIError, RuntimeError, TimeoutError) as exc:
            print_error(str(exc))
            raise typer.Exit(1)
        except KeyboardInterrupt:
            if image_id_holder["id"]:
                try:
                    ImageAPI(get_client()).cancel(image_id_holder["id"])
                except Exception:
                    pass
            raise
    else:
        from rich.console import Console
        from rich.progress import BarColumn, Progress, SpinnerColumn, TextColumn, TimeElapsedColumn

        console = Console()
        progress = Progress(
            SpinnerColumn(),
            TextColumn("[progress.description]{task.description}"),
            BarColumn(),
            TimeElapsedColumn(),
            console=console,
        )
        task_id = progress.add_task("Building image", total=len(steps))

        def handler(event: dict) -> None:
            if event.get("event") == "build_start":
                total = event.get("steps")
                progress.update(task_id, total=total)
            if event.get("event") == "build_snapshot":
                image_id_holder["id"] = event.get("imageId")
            if event.get("event") == "step_start":
                idx = event.get("index", 0) + 1
                step_type = event.get("type")
                progress.update(task_id, description=f"Step {idx}: {step_type}")
            if event.get("event") in {"step_complete", "step_error"}:
                meta = event.get("meta") or {}
                output = meta.get("outputPreview")
                if output:
                    console.print(output)
                progress.advance(task_id, 1)

        try:
            with progress:
                image_obj = builder.finalize(
                    timeout=timeout,
                    force=force,
                    wait=wait,
                    on_event=handler,
                )
        except (APIError, RuntimeError, TimeoutError) as exc:
            print_error(str(exc))
            raise typer.Exit(1)
        except KeyboardInterrupt:
            if image_id_holder["id"]:
                try:
                    ImageAPI(get_client()).cancel(image_id_holder["id"])
                except Exception:
                    pass
            raise

    if json_output_enabled():
        emit_json(image_obj)
        return

    print_success(f"Image build {image_obj.status}: {image_obj.id}")
    if image_obj.tags:
        print(f"  Tags: {', '.join(image_obj.tags)}")


@app.command("ls")
def list_images(
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    tag: str | None = typer.Option(None, "--tag", help="Filter by tag"),
    scope: str | None = typer.Option(None, "--scope", help="Scope: user, workspace, all"),
) -> None:
    """List images."""
    client = get_client()
    api = ImageAPI(client)

    try:
        images = api.list_all(workspace_id=workspace, tag=tag, scope=scope)
    except APIError as e:
        print_error(f"Failed to list images: {e.message}")
        raise typer.Exit(1)

    print_image_table(images)


@app.command()
def inspect(image_id: str = typer.Argument(..., help="Image ID")) -> None:
    """Show image details."""
    client = get_client()
    api = ImageAPI(client)

    try:
        image = api.get(image_id)
    except APIError as e:
        print_error(f"Failed to get image: {e.message}")
        raise typer.Exit(1)

    print_image_detail(image)


@app.command()
def delete(
    image_id: str = typer.Argument(..., help="Image ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete an image."""
    client = get_client()
    api = ImageAPI(client)

    if not force:
        typer.confirm(f"Delete image {image_id}?", abort=True)

    try:
        api.delete(image_id)
    except APIError as e:
        print_error(f"Failed to delete image: {e.message}")
        raise typer.Exit(1)

    print_success(f"Image {image_id} deleted")


@app.command()
def cancel(image_id: str = typer.Argument(..., help="Image ID")) -> None:
    """Cancel an in-progress image build."""
    client = get_client()
    api = ImageAPI(client)

    try:
        image = api.cancel(image_id)
    except APIError as e:
        print_error(f"Failed to cancel image: {e.message}")
        raise typer.Exit(1)

    print_success(f"Image {image.id} cancelled")


@app.command()
def tag(
    image_id: str = typer.Argument(..., help="Image ID"),
    tag: str = typer.Argument(..., help="Tag name"),
    overwrite: bool = typer.Option(False, "--overwrite", help="Overwrite existing tag"),
) -> None:
    """Add a tag to an image."""
    client = get_client()
    api = ImageAPI(client)

    try:
        image = api.add_tags(image_id, [tag], overwrite=overwrite)
    except APIError as e:
        print_error(f"Failed to tag image: {e.message}")
        raise typer.Exit(1)

    print_success(f"Tagged image {image.id} with {tag}")


@app.command()
def untag(
    image_id: str = typer.Argument(..., help="Image ID"),
    tag: str = typer.Argument(..., help="Tag to remove"),
) -> None:
    """Remove a tag from an image."""
    client = get_client()
    api = ImageAPI(client)

    try:
        api.remove_tag(image_id, tag)
    except APIError as e:
        print_error(f"Failed to remove tag: {e.message}")
        raise typer.Exit(1)

    print_success(f"Removed tag {tag} from {image_id}")


@app.command()
def resolve(
    tag: str = typer.Argument(..., help="Tag to resolve"),
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Resolve a tag to an image."""
    client = get_client()
    api = ImageAPI(client)
    settings = get_settings()
    workspace_id = workspace or settings.workspace

    if not workspace_id:
        print_error("Workspace is required to resolve a tag")
        raise typer.Exit(1)

    try:
        image = api.resolve(workspace_id, tag)
    except APIError as e:
        print_error(f"Failed to resolve tag: {e.message}")
        raise typer.Exit(1)

    print_success(f"Tag {tag} resolved to image {image.id}")


@app.command("tags")
def list_tags(
    workspace: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    image_id: str | None = typer.Option(None, "--image", help="Image ID"),
    tag: str | None = typer.Option(None, "--tag", help="Filter by tag"),
) -> None:
    """List image tags."""
    client = get_client()
    api = ImageAPI(client)

    try:
        tags = api.list_tags(workspace_id=workspace, image_id=image_id, tag=tag)
    except APIError as e:
        print_error(f"Failed to list tags: {e.message}")
        raise typer.Exit(1)

    print_image_tags_table(tags)
