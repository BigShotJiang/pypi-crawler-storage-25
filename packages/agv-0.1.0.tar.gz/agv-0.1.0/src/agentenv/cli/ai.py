"""AI Gateway CLI commands."""

import os
import sys
from pathlib import Path
from typing import Optional

import typer
from rich.console import Console
from rich.live import Live
from rich.markdown import Markdown
from rich.panel import Panel
from rich.table import Table

from ..api.client import Client
from ..api.ai_gateway import AIGatewayAPI
from ..api.models import Message, ChatCompletionRequest, CreateGatewayApiKeyRequest, APIError
from ..config.settings import get_settings
from ..ui.tables import print_error, print_success, print_warning

# Create Typer app
app = typer.Typer(
    name="ai",
    help="AI Gateway management and usage",
    no_args_is_help=True,
)

console = Console()


def get_gateway_key() -> str:
    """Get gateway key from environment or settings."""
    # Check environment variables (AGENTENV_AI_KEY takes precedence)
    key = os.getenv("AGENTENV_AI_KEY") or os.getenv("AGENTENV_GATEWAY_KEY")
    if key:
        return key

    # Try to get from settings (may have gateway_key field)
    settings = get_settings()
    if hasattr(settings, "gateway_key") and settings.gateway_key:
        return settings.gateway_key

    return ""


def get_api_client() -> tuple[Client, AIGatewayAPI]:
    """Get API client with current settings."""
    settings = get_settings()
    client = Client(base_url=settings.api_url, api_key=settings.api_key)
    gateway_key = get_gateway_key()
    api = AIGatewayAPI(client, gateway_key=gateway_key)
    return client, api


# =============================================================================
# Upstreams
# =============================================================================

upstreams_app = typer.Typer(name="upstreams", help="Manage upstream providers", no_args_is_help=True)
app.add_typer(upstreams_app)


@upstreams_app.command("list")
def list_upstreams():
    """List all upstream providers."""
    client, api = get_api_client()

    try:
        upstreams = api.list_upstreams()

        if not upstreams:
            console.print("[dim]No upstreams configured.[/dim]")
            return

        table = Table(title="Upstream Providers")
        table.add_column("ID", style="cyan")
        table.add_column("Name")
        table.add_column("Provider", style="green")
        table.add_column("Status")
        table.add_column("Rate Limit")

        for u in upstreams:
            status = "[green]active[/green]" if u.is_active else "[red]inactive[/red]"
            rate_limit = f"{u.rate_limit_rpm or '-'} RPM"
            table.add_row(u.id, u.name, u.provider, status, rate_limit)

        console.print(table)

    except APIError as e:
        print_error(f"Failed to list upstreams: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to list upstreams: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@upstreams_app.command("create")
def create_upstream(
    name: str = typer.Option(..., "--name", "-n", help="Upstream name"),
    provider: str = typer.Option(..., "--provider", "-p", help="Provider type (openai, anthropic, etc.)"),
    api_key: str = typer.Option(..., "--api-key", "-k", help="Provider API key"),
    base_url: Optional[str] = typer.Option(None, "--base-url", "-u", help="Custom base URL"),
    rpm: Optional[int] = typer.Option(None, "--rpm", help="Rate limit (requests per minute)"),
    tpm: Optional[int] = typer.Option(None, "--tpm", help="Rate limit (tokens per minute)"),
    priority: int = typer.Option(0, "--priority", help="Selection priority"),
    weight: int = typer.Option(1, "--weight", "-w", help="Load balancing weight"),
):
    """Create a new upstream provider."""
    client, api = get_api_client()

    try:
        upstream = api.create_upstream(
            name=name,
            provider=provider,
            api_key=api_key,
            base_url=base_url,
            rate_limit_rpm=rpm,
            rate_limit_tpm=tpm,
            priority=priority,
            weight=weight,
        )

        print_success(f"Created upstream: {upstream.name}")
        console.print(f"  ID: {upstream.id}")
        console.print(f"  Provider: {upstream.provider}")

    except APIError as e:
        print_error(f"Failed to create upstream: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to create upstream: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@upstreams_app.command("delete")
def delete_upstream(
    upstream_id: str = typer.Argument(..., help="Upstream ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete an upstream provider."""
    if not force:
        confirm = typer.confirm(f"Delete upstream {upstream_id}?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(0)

    client, api = get_api_client()

    try:
        api.delete_upstream(upstream_id)
        print_success(f"Deleted upstream: {upstream_id}")
    except APIError as e:
        print_error(f"Failed to delete upstream: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to delete upstream: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@upstreams_app.command("test")
def test_upstream(upstream_id: str = typer.Argument(..., help="Upstream ID to test")):
    """Test upstream connectivity."""
    client, api = get_api_client()

    try:
        with console.status("Testing upstream..."):
            result = api.test_upstream(upstream_id)

        if result.get("success"):
            print_success("Upstream is healthy")
            if "latency_ms" in result:
                console.print(f"  Latency: {result['latency_ms']}ms")
        else:
            print_error("Upstream test failed")
            if "error" in result:
                console.print(f"  Error: {result['error']}")

    except APIError as e:
        print_error(f"Failed to test upstream: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to test upstream: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


# =============================================================================
# Pools
# =============================================================================

pools_app = typer.Typer(name="pools", help="Manage load balancing pools", no_args_is_help=True)
app.add_typer(pools_app)


@pools_app.command("list")
def list_pools():
    """List all pools."""
    client, api = get_api_client()

    try:
        pools = api.list_pools()

        if not pools:
            console.print("[dim]No pools configured.[/dim]")
            return

        table = Table(title="Load Balancing Pools")
        table.add_column("ID", style="cyan")
        table.add_column("Name")
        table.add_column("Strategy", style="green")
        table.add_column("Members")

        for p in pools:
            table.add_row(p.id, p.name, p.strategy, str(len(p.members)))

        console.print(table)

    except APIError as e:
        print_error(f"Failed to list pools: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to list pools: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@pools_app.command("create")
def create_pool(
    name: str = typer.Option(..., "--name", "-n", help="Pool name"),
    strategy: str = typer.Option("round-robin", "--strategy", "-s", help="Selection strategy"),
):
    """Create a new pool."""
    client, api = get_api_client()

    try:
        pool = api.create_pool(name=name, strategy=strategy)
        print_success(f"Created pool: {pool.name}")
        console.print(f"  ID: {pool.id}")
        console.print(f"  Strategy: {pool.strategy}")
    except APIError as e:
        print_error(f"Failed to create pool: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to create pool: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@pools_app.command("delete")
def delete_pool(
    pool_id: str = typer.Argument(..., help="Pool ID to delete"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Delete a pool."""
    if not force:
        confirm = typer.confirm(f"Delete pool {pool_id}?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(0)

    client, api = get_api_client()

    try:
        api.delete_pool(pool_id)
        print_success(f"Deleted pool: {pool_id}")
    except APIError as e:
        print_error(f"Failed to delete pool: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to delete pool: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@pools_app.command("add-member")
def add_pool_member(
    pool_id: str = typer.Argument(..., help="Pool ID"),
    upstream_id: str = typer.Option(..., "--upstream", "-u", help="Upstream ID to add"),
    priority: int = typer.Option(0, "--priority", "-p", help="Member priority"),
    weight: int = typer.Option(1, "--weight", "-w", help="Member weight"),
):
    """Add upstream to pool."""
    client, api = get_api_client()

    try:
        pool = api.add_pool_member(pool_id, upstream_id, priority, weight)
        print_success(f"Added upstream to pool")
        console.print(f"  Pool: {pool.name}")
        console.print(f"  Members: {len(pool.members)}")
    except APIError as e:
        print_error(f"Failed to add member: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to add member: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


# =============================================================================
# Keys
# =============================================================================

keys_app = typer.Typer(name="keys", help="Manage API keys", no_args_is_help=True)
app.add_typer(keys_app)


@keys_app.command("list")
def list_keys():
    """List all API keys."""
    client, api = get_api_client()

    try:
        keys = api.list_keys()

        if not keys:
            console.print("[dim]No API keys configured.[/dim]")
            return

        table = Table(title="API Keys")
        table.add_column("ID", style="cyan")
        table.add_column("Name")
        table.add_column("Status")
        table.add_column("Daily Limit")
        table.add_column("Created")

        for k in keys:
            status = "[green]active[/green]" if k.is_active else "[red]revoked[/red]"
            limit = f"${k.daily_limit:.2f}" if k.daily_limit else "-"
            table.add_row(k.id, k.name, status, limit, str(k.created_at.date()))

        console.print(table)

    except APIError as e:
        print_error(f"Failed to list keys: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to list keys: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@keys_app.command("create")
def create_key(
    name: str = typer.Option(..., "--name", "-n", help="Key name"),
    daily_limit: Optional[float] = typer.Option(None, "--daily-limit", help="Daily spending limit (USD)"),
    monthly_limit: Optional[float] = typer.Option(None, "--monthly-limit", help="Monthly spending limit (USD)"),
):
    """Create a new API key."""
    client, api = get_api_client()

    try:
        request = CreateGatewayApiKeyRequest(
            name=name,
            daily_limit=daily_limit,
            monthly_limit=monthly_limit,
        )
        key = api.create_key(request)

        print_success(f"Created API key: {key.name}")
        console.print(Panel(
            f"[bold]{key.key}[/bold]\n\n"
            "[red]Save this key - it won't be shown again![/red]",
            title="API Key",
            border_style="green"
        ))

    except APIError as e:
        print_error(f"Failed to create key: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to create key: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


@keys_app.command("revoke")
def revoke_key(
    key_id: str = typer.Argument(..., help="Key ID to revoke"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
):
    """Revoke an API key."""
    if not force:
        confirm = typer.confirm(f"Revoke key {key_id}?")
        if not confirm:
            console.print("Cancelled.")
            raise typer.Exit(0)

    client, api = get_api_client()

    try:
        api.revoke_key(key_id)
        print_success(f"Revoked key: {key_id}")
    except APIError as e:
        print_error(f"Failed to revoke key: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to revoke key: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


# =============================================================================
# Usage
# =============================================================================

@app.command("usage")
def show_usage(
    start_date: Optional[str] = typer.Option(None, "--start-date", help="Start date (YYYY-MM-DD)"),
    end_date: Optional[str] = typer.Option(None, "--end-date", help="End date (YYYY-MM-DD)"),
):
    """Show usage statistics."""
    client, api = get_api_client()

    try:
        report = api.get_usage(start_date=start_date, end_date=end_date)

        console.print(Panel(
            f"[bold]Total Requests:[/bold] {report.total_requests:,}\n"
            f"[bold]Total Tokens:[/bold] {report.total_tokens:,}\n"
            f"[bold]Total Cost:[/bold] ${report.total_cost_usd:.4f}",
            title="Usage Report"
        ))

        if report.records:
            table = Table(title="Recent Usage")
            table.add_column("Time")
            table.add_column("Model")
            table.add_column("Tokens")
            table.add_column("Cost")

            for r in report.records[:20]:  # Show last 20
                table.add_row(
                    str(r.created_at),
                    r.model,
                    f"{r.total_tokens:,}",
                    f"${r.cost_usd:.4f}"
                )

            console.print(table)

    except APIError as e:
        print_error(f"Failed to get usage: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to get usage: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


# =============================================================================
# Providers
# =============================================================================

@app.command("providers")
def list_platform_providers():
    """List supported platform providers."""
    client, api = get_api_client()

    try:
        payload = api.list_providers()
        providers = payload.get("providers") or []

        if not providers:
            console.print("[dim]No platform providers available.[/dim]")
            return

        table = Table(title="Platform Providers")
        table.add_column("ID", style="cyan")
        table.add_column("Name")

        for provider in providers:
            table.add_row(
                str(provider.get("id", "-")),
                str(provider.get("displayName") or provider.get("name") or provider.get("id") or "-"),
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to list providers: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Failed to list providers: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


# =============================================================================
# Models
# =============================================================================

@app.command("models")
def list_models(
    provider: Optional[str] = typer.Option(None, "--provider", "-p", help="Filter by provider"),
):
    """List available platform models."""
    fallback_models = [
        ("gpt-4o", "openai", "GPT-4o"),
        ("gpt-4o-mini", "openai", "GPT-4o Mini"),
        ("claude-3-5-sonnet-20241022", "anthropic", "Claude 3.5 Sonnet"),
        ("claude-3-opus-20240229", "anthropic", "Claude 3 Opus"),
        ("gemini-1.5-pro", "gemini", "Gemini 1.5 Pro"),
        ("text-embedding-3-small", "openai", "Embedding 3 Small"),
        ("text-embedding-3-large", "openai", "Embedding 3 Large"),
    ]
    client, api = get_api_client()

    try:
        payload = api.list_platform_models()
        providers = payload.get("providers") or []

        table = Table(title="Available Models")
        table.add_column("Model ID", style="cyan")
        table.add_column("Provider", style="green")
        table.add_column("Name")
        table.add_column("Input $/1M", justify="right")
        table.add_column("Output $/1M", justify="right")

        row_count = 0
        for provider_entry in providers:
            provider_id = str(provider_entry.get("id", "-"))
            if provider and provider_id != provider:
                continue

            for model_entry in provider_entry.get("models") or []:
                table.add_row(
                    str(model_entry.get("id", "-")),
                    provider_id,
                    str(model_entry.get("displayName") or model_entry.get("id") or "-"),
                    str(model_entry.get("inputPrice", "-")),
                    str(model_entry.get("outputPrice", "-")),
                )
                row_count += 1

        if row_count == 0:
            console.print("[dim]No models available.[/dim]")
            return

        console.print(table)
    except Exception as e:
        print_warning(f"Falling back to built-in model catalog: {e}")

        if provider:
            models = [m for m in fallback_models if m[1] == provider]
        else:
            models = fallback_models

        if not models:
            console.print("[dim]No models available.[/dim]")
            return

        table = Table(title="Available Models")
        table.add_column("Model ID", style="cyan")
        table.add_column("Provider", style="green")
        table.add_column("Description")

        for model_id, prov, desc in models:
            table.add_row(model_id, prov, desc)

        console.print(table)
    finally:
        client.close()


# =============================================================================
# Chat
# =============================================================================

@app.command("chat")
def chat_command(
    message: Optional[str] = typer.Argument(None, help="Message to send"),
    system_prompt: Optional[str] = typer.Option(None, "--system-prompt", "-s", help="System prompt"),
    model: Optional[str] = typer.Option(None, "--model", "-m", help="Model to use"),
    temperature: float = typer.Option(1.0, "--temperature", "-t", help="Sampling temperature"),
    max_tokens: Optional[int] = typer.Option(None, "--max-tokens", help="Max tokens to generate"),
    stream: bool = typer.Option(True, "--stream/--no-stream", help="Stream response"),
    file: list[Path] = typer.Option([], "--file", "-f", help="Include file content"),
    interactive: bool = typer.Option(False, "--interactive", "-i", help="Interactive mode"),
):
    """Send a chat message to AI Gateway.

    Examples:
        av ai chat "What is the capital of France?"
        av ai chat "Explain quantum computing" --model gpt-4
        av ai chat "Write a function" --system-prompt "You are a Python expert"
        av ai chat "Review this" --file main.py --file utils.py
        cat main.py | av ai chat "Review this code"
    """
    # Get gateway key
    gateway_key = get_gateway_key()
    if not gateway_key:
        print_error("Gateway key required. Set AGENTENV_AI_KEY environment variable.")
        raise typer.Exit(1)

    settings = get_settings()

    # Interactive mode
    if interactive:
        _run_interactive_chat(settings.api_url, gateway_key, model, system_prompt)
        return

    # Build message
    content_parts = []

    # Read from stdin if no message and no files
    if not message and not file and sys.stdin.isatty():
        print_error("Please provide a message, use --interactive, or pipe input.")
        raise typer.Exit(1)

    if not message and not file and not sys.stdin.isatty():
        # Read from stdin
        content_parts.append(sys.stdin.read())
    elif message:
        content_parts.append(message)

    # Add file contents
    for f in file:
        if not f.exists():
            print_error(f"File not found: {f}")
            raise typer.Exit(1)
        content_parts.append(f"\n--- {f.name} ---\n")
        content_parts.append(f.read_text())

    full_message = "\n".join(content_parts)

    # Build messages list
    messages = []
    if system_prompt:
        messages.append(Message(role="system", content=system_prompt))
    messages.append(Message(role="user", content=full_message))

    # Use default model if not specified
    if not model:
        model = os.getenv("AGENTENV_AI_MODEL", "gpt-4o")

    # Create request
    request = ChatCompletionRequest(
        model=model,
        messages=messages,
        temperature=temperature,
        max_tokens=max_tokens,
        stream=stream,
    )

    # Send request
    client = Client(base_url=settings.api_url)
    api = AIGatewayAPI(client, gateway_key=gateway_key)

    try:
        response = api.chat.create(request)

        if stream:
            # Streaming output
            full_response = ""
            with Live(console=console, refresh_per_second=10) as live:
                for chunk in response:
                    if chunk.choices and chunk.choices[0].delta:
                        delta_content = chunk.choices[0].delta.content
                        if delta_content:
                            full_response += delta_content
                            live.update(Markdown(full_response))
            console.print()  # Newline after streaming
        else:
            # Non-streaming
            if response.choices and response.choices[0].message:
                content = response.choices[0].message.content
                console.print(Markdown(content))

    except APIError as e:
        print_error(f"Chat failed: {e.message}")
        raise typer.Exit(1)
    except Exception as e:
        print_error(f"Chat failed: {e}")
        raise typer.Exit(1)
    finally:
        client.close()


def _run_interactive_chat(
    base_url: str,
    gateway_key: str,
    model: Optional[str],
    system_prompt: Optional[str],
):
    """Run interactive chat session."""
    console.print("[bold green]Interactive Chat Mode[/bold green]")
    console.print("Type 'exit' or 'quit' to end the session.\n")

    # Use default model
    if not model:
        model = os.getenv("AGENTENV_AI_MODEL", "gpt-4o")

    # Build conversation history
    messages = []
    if system_prompt:
        messages.append(Message(role="system", content=system_prompt))

    client = Client(base_url=base_url)
    api = AIGatewayAPI(client, gateway_key=gateway_key)

    try:
        while True:
            # Get user input
            user_input = console.input("[bold blue]You:[/bold blue] ")

            if user_input.lower() in ("exit", "quit"):
                console.print("[dim]Goodbye![/dim]")
                break

            if not user_input.strip():
                continue

            # Add user message
            messages.append(Message(role="user", content=user_input))

            # Create request
            request = ChatCompletionRequest(
                model=model,
                messages=messages,
                stream=True,
            )

            # Get response
            console.print("[bold green]AI:[/bold green] ", end="")
            response_content = ""

            try:
                response = api.chat.create(request)
                for chunk in response:
                    if chunk.choices and chunk.choices[0].delta:
                        delta_content = chunk.choices[0].delta.content
                        if delta_content:
                            response_content += delta_content
                            console.print(delta_content, end="")
                console.print()  # Newline

                # Add assistant message to history
                messages.append(Message(role="assistant", content=response_content))

            except Exception as e:
                print_error(f"\nError: {e}")
                continue

    finally:
        client.close()
