"""Browser session CLI commands."""

import webbrowser

import typer

from ..api.browser import BrowserAPI
from ..api.client import APIError, Client
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_browser_table,
    print_error,
    print_success,
    print_warning,
)

app = typer.Typer(help="Browser session commands")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _normalize_profile_mode(profile_mode: str) -> str:
    """Keep backward compatibility with the old incognito alias."""
    return "ephemeral" if profile_mode == "incognito" else profile_mode


def _build_geonode_proxy_payload(
    *,
    enabled: bool,
    mode: str | None,
    domains: list[str],
) -> dict | None:
    """Build geonode proxy payload when the related options are provided."""
    if not enabled and not mode and not domains:
        return None
    if not mode:
        print_error("Geonode proxy requires --geonode-mode")
        raise typer.Exit(1)
    if not domains:
        print_error("Geonode proxy requires at least one --geonode-domain")
        raise typer.Exit(1)
    return {
        "enabled": enabled or bool(mode or domains),
        "mode": mode,
        "domains": domains,
    }


def _open_session_url(url: str | None) -> None:
    """Open the first browser-openable URL we have."""
    if url and url.startswith(("http://", "https://")):
        webbrowser.open(url)


@app.callback(invoke_without_command=True)
def browser_entrypoint(
    ctx: typer.Context,
    name: str | None = typer.Option(None, "--name", help="Browser session name"),
    workspace_id: str | None = typer.Option(
        None,
        "--workspace",
        "-w",
        help="Workspace ID",
    ),
    screen_width: int = typer.Option(1280, "--screen-width", "--width", help="Screen width"),
    screen_height: int = typer.Option(720, "--screen-height", "--height", help="Screen height"),
    stealth: bool = typer.Option(False, "--stealth", help="Enable stealth mode"),
    adblock: bool = typer.Option(False, "--adblock", help="Enable ad blocking"),
    profile_mode: str = typer.Option(
        "persistent",
        "--profile-mode",
        "--profile",
        help="Profile mode (persistent, ephemeral)",
    ),
    profile_id: str | None = typer.Option(None, "--profile-id", help="Browser profile ID"),
    proxy_url: str | None = typer.Option(None, "--proxy-url", help="Proxy URL"),
    proxy_provider: str | None = typer.Option(None, "--proxy-provider", help="Managed proxy provider"),
    proxy_type: str | None = typer.Option(None, "--proxy-type", help="Managed proxy type"),
    captcha_solver: bool = typer.Option(False, "--captcha-solver", help="Enable captcha solver"),
    captcha_provider: str | None = typer.Option(None, "--captcha-provider", help="Captcha solver provider"),
    captcha_api_key: str | None = typer.Option(None, "--captcha-api-key", help="Captcha solver API key"),
    rrweb: bool = typer.Option(False, "--rrweb", help="Enable rrweb recording"),
    logger: bool = typer.Option(False, "--logger", help="Enable logger extension"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    max_lifetime_seconds: int | None = typer.Option(
        None,
        "--max-lifetime-seconds",
        help="Maximum lifetime in seconds",
    ),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    geonode_proxy: bool = typer.Option(False, "--geonode-proxy", help="Enable Geonode proxy"),
    geonode_mode: str | None = typer.Option(None, "--geonode-mode", help="Geonode mode"),
    geonode_domain: list[str] = typer.Option([], "--geonode-domain", help="Geonode domain pattern"),
    open_url: bool = typer.Option(True, "--open/--no-open", help="Open browser URL"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for session to be ready"),
) -> None:
    """Create a browser session when invoked without a subcommand."""
    if ctx.invoked_subcommand is None:
        create_browser(
            name=name,
            workspace_id=workspace_id,
            screen_width=screen_width,
            screen_height=screen_height,
            stealth=stealth,
            adblock=adblock,
            profile_mode=profile_mode,
            profile_id=profile_id,
            proxy_url=proxy_url,
            proxy_provider=proxy_provider,
            proxy_type=proxy_type,
            captcha_solver=captcha_solver,
            captcha_provider=captcha_provider,
            captcha_api_key=captcha_api_key,
            rrweb=rrweb,
            logger=logger,
            cpu=cpu,
            memory=memory,
            max_lifetime_seconds=max_lifetime_seconds,
            gpu_type=gpu_type,
            geonode_proxy=geonode_proxy,
            geonode_mode=geonode_mode,
            geonode_domain=geonode_domain,
            open_url=open_url,
            wait=wait,
        )


@app.command("create")
def create_browser(
    name: str | None = typer.Option(None, "--name", help="Browser session name"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    screen_width: int = typer.Option(1280, "--screen-width", "--width", help="Screen width"),
    screen_height: int = typer.Option(720, "--screen-height", "--height", help="Screen height"),
    stealth: bool = typer.Option(False, "--stealth", help="Enable stealth mode"),
    adblock: bool = typer.Option(False, "--adblock", help="Enable ad blocking"),
    profile_mode: str = typer.Option(
        "persistent",
        "--profile-mode",
        "--profile",
        help="Profile mode (persistent, ephemeral)",
    ),
    profile_id: str | None = typer.Option(None, "--profile-id", help="Browser profile ID"),
    proxy_url: str | None = typer.Option(None, "--proxy-url", help="Proxy URL"),
    proxy_provider: str | None = typer.Option(None, "--proxy-provider", help="Managed proxy provider"),
    proxy_type: str | None = typer.Option(None, "--proxy-type", help="Managed proxy type"),
    captcha_solver: bool = typer.Option(False, "--captcha-solver", help="Enable captcha solver"),
    captcha_provider: str | None = typer.Option(None, "--captcha-provider", help="Captcha solver provider"),
    captcha_api_key: str | None = typer.Option(None, "--captcha-api-key", help="Captcha solver API key"),
    rrweb: bool = typer.Option(False, "--rrweb", help="Enable rrweb recording"),
    logger: bool = typer.Option(False, "--logger", help="Enable logger extension"),
    cpu: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    max_lifetime_seconds: int | None = typer.Option(
        None,
        "--max-lifetime-seconds",
        help="Maximum lifetime in seconds",
    ),
    gpu_type: str | None = typer.Option(None, "--gpu-type", help="GPU type"),
    geonode_proxy: bool = typer.Option(False, "--geonode-proxy", help="Enable Geonode proxy"),
    geonode_mode: str | None = typer.Option(None, "--geonode-mode", help="Geonode mode"),
    geonode_domain: list[str] = typer.Option([], "--geonode-domain", help="Geonode domain pattern"),
    open_url: bool = typer.Option(True, "--open/--no-open", help="Open browser URL"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for session to be ready"),
) -> None:
    """Create a browser session.

    Examples:
        av browser create
        av browser create --screen-width 1920 --screen-height 1080 --stealth
    """
    client = get_client()
    api = BrowserAPI(client)
    geonode_payload = _build_geonode_proxy_payload(
        enabled=geonode_proxy,
        mode=geonode_mode,
        domains=geonode_domain,
    )

    try:
        with status("Creating browser session..."):
            session = api.create(
                name=name,
                workspace_id=workspace_id,
                screen_width=screen_width,
                screen_height=screen_height,
                enable_stealth=stealth,
                enable_adblock=adblock,
                profile_mode=_normalize_profile_mode(profile_mode),
                profile_id=profile_id,
                proxy_url=proxy_url,
                proxy_provider=proxy_provider,
                proxy_type=proxy_type,
                enable_captcha_solver=captcha_solver,
                captcha_provider=captcha_provider,
                captcha_api_key=captcha_api_key,
                enable_rrweb=rrweb,
                enable_logger=logger,
                cpu_millis=cpu,
                memory_mb=memory,
                max_lifetime_seconds=max_lifetime_seconds,
                gpu_type=gpu_type,
                geonode_proxy=geonode_payload,
            )
    except APIError as e:
        print_error(f"Failed to create browser session: {e.message}")
        raise typer.Exit(1)

    if wait:
        with status("Waiting for session to start..."):
            try:
                session = api.wait_for_status(session.id, timeout=60)
            except TimeoutError:
                print_error("Browser session failed to start in time")
                raise typer.Exit(1)

    if json_output_enabled():
        emit_json(session)
        return

    print_success(f"Browser session {session.id} created")
    if wait:
        print_success(f"Browser session {session.id} is running")

    # Show URLs
    if session.vnc_url:
        print(f"\nVNC URL: {session.vnc_url}")
    if session.cdp_url:
        print(f"CDP URL: {session.cdp_url}")

    if open_url:
        _open_session_url(session.vnc_url)


@app.command("ls")
def list_browsers(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """List browser sessions."""
    client = get_client()
    api = BrowserAPI(client)

    try:
        sessions = api.list_all(workspace_id=workspace_id)
    except APIError as e:
        print_error(f"Failed to list browser sessions: {e.message}")
        raise typer.Exit(1)

    print_browser_table(sessions)


@app.command("list", deprecated=True)
def list_browsers_alt() -> None:
    """List browser sessions (alias for ls)."""
    list_browsers()


@app.command()
def inspect(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Show browser session details.

    Examples:
        av browser inspect br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        session = api.get(session_id)
    except APIError as e:
        print_error(f"Failed to get browser session: {e.message}")
        raise typer.Exit(1)

    from rich.console import Console
    from rich.table import Table

    from ..ui.tables import _colored_status, _format_datetime

    if json_output_enabled():
        emit_json(session)
        return

    console = Console()
    table = Table(title=f"Browser Session: {session.id}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", session.id)
    table.add_row("Name", session.name or "-")
    table.add_row("Status", _colored_status(session.status))
    table.add_row("Workspace", session.workspace_id or "-")
    table.add_row("CDP URL", session.cdp_url or "-")
    table.add_row("VNC URL", session.vnc_url or "-")
    table.add_row("Created", _format_datetime(session.created_at))
    if session.updated_at:
        table.add_row("Updated", _format_datetime(session.updated_at))

    console.print(table)


@app.command()
def stop(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Stop a browser session.

    Examples:
        av browser stop br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        with status(f"Stopping browser session {session_id}..."):
            api.stop(session_id)
    except APIError as e:
        print_error(f"Failed to stop browser session: {e.message}")
        raise typer.Exit(1)

    print_success(f"Browser session {session_id} stopped")


@app.command("rm")
def delete_browser(
    session_id: str = typer.Argument(..., help="Session ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a browser session.

    Examples:
        av browser rm br_abc123
    """
    if not force:
        typer.confirm(f"Delete browser session {session_id}?", abort=True)

    client = get_client()
    api = BrowserAPI(client)

    try:
        with status(f"Deleting browser session {session_id}..."):
            api.delete(session_id)
    except APIError as e:
        print_error(f"Failed to delete browser session: {e.message}")
        raise typer.Exit(1)

    print_success(f"Browser session {session_id} deleted")


@app.command("delete", deprecated=True)
def delete_browser_alt(
    session_id: str = typer.Argument(..., help="Session ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a browser session (alias for rm)."""
    # Re-use the same implementation
    import sys

    from typer import Exit
    # Simulate the rm command with same args
    original_argv = sys.argv
    try:
        # Force to bypass confirmation since this might be a script
        delete_browser(session_id, force=True)
    except Exit:
        raise
    finally:
        sys.argv = original_argv


@app.command("cdp")
def get_cdp_url(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Get CDP (Chrome DevTools Protocol) URL for a session.

    Examples:
        av browser cdp br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        url = api.get_cdp_url(session_id)
    except APIError as e:
        print_error(f"Failed to get CDP URL: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"cdpUrl": url})
        return

    if url:
        print(url)
    else:
        print_warning("CDP URL not available")


@app.command("vnc")
def get_vnc_url(session_id: str = typer.Argument(..., help="Session ID")) -> None:
    """Get VNC URL for a session.

    Examples:
        av browser vnc br_abc123
    """
    client = get_client()
    api = BrowserAPI(client)

    try:
        url = api.get_vnc_url(session_id)
    except APIError as e:
        print_error(f"Failed to get VNC URL: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"vncUrl": url})
        return

    if url:
        print(url)
    else:
        print_warning("VNC URL not available")
