"""Configuration CLI commands."""

import subprocess

import typer

from ..config.defaults import get_defaults_manager
from ..config.settings import get_settings, reset_settings
from ..ui.tables import emit_json, json_output_enabled, print_config, print_error, print_success

app = typer.Typer(help="Configuration management commands")


@app.callback(invoke_without_command=True)
def config_entrypoint(ctx: typer.Context) -> None:
    """Show configuration when no subcommand is provided."""
    if ctx.invoked_subcommand is None:
        show_config()


@app.command("show")
def show_config() -> None:
    """Show current configuration."""
    settings = get_settings()
    defaults_mgr = get_defaults_manager()

    config = {
        "API URL": settings.api_url,
        "Workspace": settings.workspace or "-",
        "Debug": str(settings.debug),
        "JSON Output": str(settings.json_output),
    }

    # Add defaults
    sandbox_defaults = defaults_mgr.get_sandbox_defaults()
    if sandbox_defaults:
        for key, value in sandbox_defaults.items():
            config[f"Default: {key}"] = str(value)

    print_config(config)


@app.command("edit")
def edit_config() -> None:
    """Edit configuration file.

    Opens the config file in your default editor.
    """
    import os

    config_dir = os.path.expanduser("~/.agentenv")
    config_file = os.path.join(config_dir, "config.yaml")

    # Create config file if it doesn't exist
    os.makedirs(config_dir, mode=0o700, exist_ok=True)
    if not os.path.exists(config_file):
        with open(config_file, "w") as f:
            f.write("# AgentEnv CLI Configuration\n")

    # Open in editor
    editor = os.environ.get("EDITOR", "vi")
    subprocess.call([editor, config_file])

    print_success(f"Configuration file edited: {config_file}")


@app.command("reset")
def reset_config(
    force: bool = typer.Option(False, "--force", "-f", help="Force reset without confirmation"),
) -> None:
    """Reset configuration to defaults.

    This clears all user-set defaults and configuration.
    Credentials are preserved - use 'av logout' to clear those.
    """
    if not force:
        typer.confirm("Reset all configuration to defaults?", abort=True)

    defaults_mgr = get_defaults_manager()
    defaults_mgr.clear()

    import os
    config_file = os.path.expanduser("~/.agentenv/config.yaml")
    if os.path.exists(config_file):
        os.remove(config_file)

    reset_settings()

    print_success("Configuration reset to defaults")


# =============================================================================
# Set command - manage defaults
# =============================================================================

@app.command("set", no_args_is_help=False)
def set_value(
    ctx: typer.Context,
    key: str = typer.Argument(None, help="Configuration key"),
    value: str = typer.Argument(None, help="Configuration value"),
) -> None:
    """Set a configuration value.

    Examples:
        av set type xl
        av set image python:3.11
        av set region us-east-1
        av set workspace wk_abc123
        av set cpu 4000
        av set memory 8192

    Available keys:
        type       : Sandbox type preset (micro, small, medium, large, xl)
        sandbox    : Alias for 'type'
        image      : Default container image
        cpu        : Default CPU in millis
        memory     : Default memory in MB
        gpu        : Default GPU count
        gpu-type   : Default GPU type
        region     : Default region
        workspace  : Default workspace ID
        api-url    : API server URL
    """
    if key is None:
        # Show current defaults
        defaults_mgr = get_defaults_manager()
        defaults_mgr.print_current()
        return

    if value is None:
        print_error("Value is required")
        raise typer.Exit(1)

    settings = get_settings()
    defaults_mgr = get_defaults_manager()

    def _clear_derived_type_resources(type_name: str | None) -> None:
        """Remove cpu/memory values when they only mirror a preset type."""
        if not type_name:
            return

        preset = settings.get_type_config(type_name)
        if preset is None:
            return

        current = defaults_mgr.get_all()
        if current.get("cpu") == preset.cpu:
            defaults_mgr.remove("cpu")
        if current.get("memory") == preset.memory:
            defaults_mgr.remove("memory")

    # Handle special keys that modify settings directly
    if key in ("workspace", "ws"):
        settings.workspace = value
        settings.save()
        print_success(f"Default workspace set to {value}")
        return

    if key in ("api-url", "api_url"):
        settings.api_url = value
        settings.save()
        print_success(f"API URL set to {value}")
        return

    # Type preset - validate and set CPU/memory
    if key in ("type", "sandbox"):
        if settings.get_type_config(value):
            _clear_derived_type_resources(defaults_mgr.get("type"))
            defaults_mgr.set("type", value)
            config = settings.get_type_config(value)
            if json_output_enabled():
                emit_json({"type": value, "cpu": config.cpu, "memory": config.memory})
                return
            print_success(f"Default type set to {value}")
            print(f"  CPU: {config.cpu} millis")
            print(f"  Memory: {config.memory} MB")
        else:
            print_error(f"Unknown type preset: {value}")
            if not json_output_enabled():
                print("Available: micro, small, medium, large, xl")
            raise typer.Exit(1)
        return

    # Numeric values
    if key == "cpu":
        try:
            cpu_val = int(value)
            defaults_mgr.set("cpu", cpu_val)
            print_success(f"Default CPU set to {cpu_val} millis")
        except ValueError:
            print_error("CPU must be a number")
            raise typer.Exit(1)
        return

    if key == "memory":
        try:
            mem_val = int(value)
            defaults_mgr.set("memory", mem_val)
            print_success(f"Default memory set to {mem_val} MB")
        except ValueError:
            print_error("Memory must be a number")
            raise typer.Exit(1)
        return

    if key == "gpu":
        try:
            gpu_val = int(value)
            defaults_mgr.set("gpu", gpu_val)
            print_success(f"Default GPU count set to {gpu_val}")
        except ValueError:
            print_error("GPU count must be a number")
            raise typer.Exit(1)
        return

    if key == "gpu-type" or key == "gpu_type":
        defaults_mgr.set("gpu_type", value)
        print_success(f"Default GPU type set to {value}")
        return

    # String values
    if key in ("image", "region"):
        defaults_mgr.set(key.replace("-", "_"), value)
        print_success(f"Default {key} set to {value}")
        return

    print_error(f"Unknown key: {key}")
    if not json_output_enabled():
        print("Available keys: type, image, cpu, memory, gpu, gpu-type, region, workspace, api-url")
    raise typer.Exit(1)


@app.command("unset")
def unset_value(
    key: str = typer.Argument(..., help="Configuration key to unset"),
) -> None:
    """Unset a configuration value (reset to default).

    Examples:
        av unset cpu
        av unset type
    """
    settings = get_settings()
    defaults_mgr = get_defaults_manager()

    # Map common aliases
    key_map = {
        "gpu-type": "gpu_type",
        "api-url": "api_url",
        "ws": "workspace",
    }
    normalized_key = key_map.get(key, key)

    if normalized_key == "workspace":
        settings.workspace = None
        settings.save()
        print_success(f"Unset {key}")
        return

    if normalized_key == "api_url":
        settings.api_url = type(settings)().api_url
        settings.save()
        print_success(f"Unset {key}")
        return

    if normalized_key == "type":
        current_type = defaults_mgr.get("type")
        preset = settings.get_type_config(current_type) if isinstance(current_type, str) else None
        current = defaults_mgr.get_all()
        defaults_mgr.remove("type")
        if preset is not None:
            if current.get("cpu") == preset.cpu:
                defaults_mgr.remove("cpu")
            if current.get("memory") == preset.memory:
                defaults_mgr.remove("memory")
        print_success(f"Unset {key}")
        return

    if normalized_key in defaults_mgr.get_all():
        defaults_mgr.remove(normalized_key)
        print_success(f"Unset {key}")
    else:
        print_error(f"Key not set: {key}")
        raise typer.Exit(1)


@app.command("ls")
def list_defaults() -> None:
    """List all current defaults."""
    defaults_mgr = get_defaults_manager()
    defaults_mgr.print_current()


@app.command("list", deprecated=True)
def list_defaults_alt() -> None:
    """List all current defaults (alias for ls)."""
    list_defaults()


@app.command("set-ai-key")
def set_ai_key(
    key: str = typer.Argument(..., help="AI Gateway key (cr_xxx)"),
) -> None:
    """Set AI Gateway API key."""
    # Validate key format
    if not key.startswith("cr_"):
        print_error("Invalid key format. AI Gateway keys must start with 'cr_'")
        raise typer.Exit(1)

    settings = get_settings()
    settings.gateway_key = key
    settings.save_credentials()
    print_success("AI Gateway key saved")


@app.command("get-ai-key")
def get_ai_key() -> None:
    """Show AI Gateway key (masked)."""
    from rich.console import Console

    console = Console()
    settings = get_settings()

    if settings.gateway_key:
        masked = settings.gateway_key[:8] + "..." + settings.gateway_key[-4:]
        if json_output_enabled():
            emit_json({"gatewayKey": masked})
            return
        console.print(f"AI Gateway key: {masked}")
    else:
        if json_output_enabled():
            emit_json({"gatewayKey": None})
            return
        console.print("[dim]No AI Gateway key configured.[/dim]")
