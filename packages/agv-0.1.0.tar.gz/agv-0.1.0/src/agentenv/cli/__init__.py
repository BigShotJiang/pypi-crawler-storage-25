"""CLI commands for AgentEnv."""
