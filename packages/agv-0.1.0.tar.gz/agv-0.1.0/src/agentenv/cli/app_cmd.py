"""App deployment CLI commands."""


import typer
from rich.console import Console
from rich.table import Table

from ..api.app import AppAPI
from ..api.client import APIError, Client
from ..config.settings import get_settings
from ..ui.tables import print_error, print_success

app = typer.Typer(help="App deployment management commands")
console = Console()


def get_client() -> Client:
    settings = get_settings()
    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def parse_env(env_list: list[str]) -> dict[str, str]:
    """Parse KEY=VALUE environment variable list."""
    result: dict[str, str] = {}
    for item in env_list:
        if "=" in item:
            key, value = item.split("=", 1)
            result[key] = value
    return result


@app.command("create")
def create_app(
    name: str = typer.Option(..., "--name", help="App name"),
    port: int = typer.Option(..., "--port", help="Container port to expose"),
    slug: str | None = typer.Option(None, "--slug", help="Custom slug"),
    ready_types: list[str] = typer.Option(
        ["port_accessible"],
        "--ready",
        help="Ready types (port_accessible, http_health)",
    ),
    min_replicas: int = typer.Option(0, "--min", help="Minimum replicas"),
    max_replicas: int = typer.Option(3, "--max", help="Maximum replicas"),
    health_path: str | None = typer.Option(None, "--health-path", help="Health check path"),
    cpu_millis: int | None = typer.Option(None, "--cpu", help="CPU in millis"),
    memory_mb: int | None = typer.Option(None, "--memory", help="Memory in MB"),
    idle_timeout_ms: int | None = typer.Option(None, "--idle-timeout", help="Idle timeout ms"),
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """Create a new app."""
    allowed_ready = {"port_accessible", "http_health"}
    invalid = [v for v in ready_types if v not in allowed_ready]
    if invalid:
        print_error(f"Invalid ready types: {', '.join(invalid)}")
        raise typer.Exit(1)

    if max_replicas < min_replicas:
        print_error("max must be >= min")
        raise typer.Exit(1)

    if "http_health" in ready_types and not health_path:
        health_path = "/health"

    client = get_client()
    api = AppAPI(client)

    payload: dict[str, object] = {
        "name": name,
        "containerPort": port,
        "readyTypes": ready_types,
        "minReplicas": min_replicas,
        "maxReplicas": max_replicas,
    }
    if slug:
        payload["slug"] = slug
    if health_path:
        payload["healthPath"] = health_path
    if cpu_millis:
        payload["cpuMillis"] = cpu_millis
    if memory_mb:
        payload["memoryMb"] = memory_mb
    if idle_timeout_ms:
        payload["idleTimeoutMs"] = idle_timeout_ms
    if workspace_id:
        payload["workspaceId"] = workspace_id

    try:
        result = api.create(payload)
        print_success(f"App created: {result.slug}")
        console.print(f"ID: {result.id}")
    except APIError as e:
        print_error(f"Failed to create app: {e.message}")
        raise typer.Exit(1)


@app.command("deploy")
def deploy_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    snapshot: str = typer.Option(..., "--snapshot", "-s", help="Snapshot ID to deploy"),
    env: list[str] = typer.Option([], "--env", "-e", help="Environment overrides (KEY=VALUE)"),
    entrypoint: str | None = typer.Option(None, "--entrypoint", help="Entrypoint override"),
) -> None:
    """Deploy a new version to an app."""
    client = get_client()
    api = AppAPI(client)

    env_overrides = parse_env(env) if env else None

    try:
        version = api.deploy(
            id_or_slug,
            snapshot_id=snapshot,
            env_overrides=env_overrides,
            entrypoint_override=entrypoint,
        )
        print_success(f"Deployed version {version.version}")
    except APIError as e:
        print_error(f"Failed to deploy: {e.message}")
        raise typer.Exit(1)


@app.command("ls")
def list_apps(
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """List apps."""
    client = get_client()
    api = AppAPI(client)

    try:
        apps = api.list_all(workspace_id=workspace_id)

        if not apps:
            console.print("[dim]No apps found.[/dim]")
            return

        table = Table(show_header=True)
        table.add_column("Name")
        table.add_column("Slug")
        table.add_column("Version")
        table.add_column("Status")
        table.add_column("Replicas")

        for a in apps:
            table.add_row(
                a.name,
                a.slug,
                a.current_version or "-",
                a.status,
                f"{a.config.min_replicas}-{a.config.max_replicas}",
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to list apps: {e.message}")
        raise typer.Exit(1)


@app.command("inspect")
def inspect_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
) -> None:
    """Show app details."""
    client = get_client()
    api = AppAPI(client)

    try:
        a = api.get(id_or_slug)

        table = Table(show_header=False)
        table.add_column("Field", style="cyan")
        table.add_column("Value")

        table.add_row("ID", a.id)
        table.add_row("Name", a.name)
        table.add_row("Slug", a.slug)
        table.add_row("Status", a.status)
        table.add_row("Current Version", a.current_version or "-")
        table.add_row("Port", str(a.config.container_port))
        table.add_row("Ready Types", ", ".join(a.config.ready_types))
        table.add_row("Min Replicas", str(a.config.min_replicas))
        table.add_row("Max Replicas", str(a.config.max_replicas))
        if a.config.cpu_millis:
            table.add_row("CPU (millis)", str(a.config.cpu_millis))
        if a.config.memory_mb:
            table.add_row("Memory (MB)", str(a.config.memory_mb))

        console.print(table)
    except APIError as e:
        print_error(f"Failed to get app: {e.message}")
        raise typer.Exit(1)


@app.command("update")
def update_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    name: str | None = typer.Option(None, "--name", help="New name"),
    min_replicas: int | None = typer.Option(None, "--min", help="Min replicas"),
    max_replicas: int | None = typer.Option(None, "--max", help="Max replicas"),
    cpu_millis: int | None = typer.Option(None, "--cpu", help="CPU millis"),
    memory_mb: int | None = typer.Option(None, "--memory", help="Memory MB"),
) -> None:
    """Update app config."""
    client = get_client()
    api = AppAPI(client)

    updates: dict[str, object] = {}
    if name:
        updates["name"] = name
    if min_replicas is not None:
        updates["minReplicas"] = min_replicas
    if max_replicas is not None:
        updates["maxReplicas"] = max_replicas
    if cpu_millis is not None:
        updates["cpuMillis"] = cpu_millis
    if memory_mb is not None:
        updates["memoryMb"] = memory_mb

    if not updates:
        print_error("No updates specified")
        raise typer.Exit(1)

    try:
        result = api.update(id_or_slug, **updates)
        print_success(f"App {result.slug} updated")
    except APIError as e:
        print_error(f"Failed to update app: {e.message}")
        raise typer.Exit(1)


@app.command("versions")
def list_versions(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    delete: str | None = typer.Option(None, "--delete", "-d", help="Delete a version"),
) -> None:
    """List or delete app versions."""
    client = get_client()
    api = AppAPI(client)

    if delete:
        try:
            api.delete_version(id_or_slug, delete)
            print_success(f"Deleted version {delete}")
        except APIError as e:
            print_error(f"Failed to delete version: {e.message}")
            raise typer.Exit(1)
        return

    try:
        app_info = api.get(id_or_slug)
        versions = api.get_versions(id_or_slug)

        if not versions:
            console.print("[dim]No versions found.[/dim]")
            return

        table = Table(show_header=True)
        table.add_column("Version")
        table.add_column("Snapshot")
        table.add_column("Created")
        table.add_column("Current")

        for v in sorted(versions, key=lambda x: x.created_at, reverse=True):
            is_current = "*" if v.version == app_info.current_version else ""
            table.add_row(
                v.version,
                v.snapshot_id[:12],
                v.created_at.strftime("%Y-%m-%d %H:%M"),
                is_current,
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to get versions: {e.message}")
        raise typer.Exit(1)


@app.command("rollback")
def rollback_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    version: str = typer.Argument(..., help="Version to rollback to"),
) -> None:
    """Rollback app to a previous version."""
    client = get_client()
    api = AppAPI(client)

    try:
        api.rollback(id_or_slug, version)
        print_success(f"Rolled back to version {version}")
    except APIError as e:
        print_error(f"Failed to rollback: {e.message}")
        raise typer.Exit(1)


@app.command("rm")
def delete_app(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete an app."""
    if not force:
        typer.confirm(f"Delete app {id_or_slug}?", abort=True)

    client = get_client()
    api = AppAPI(client)

    try:
        api.delete(id_or_slug)
        print_success(f"App {id_or_slug} deleted")
    except APIError as e:
        print_error(f"Failed to delete app: {e.message}")
        raise typer.Exit(1)


@app.command("logs")
def app_logs(
    id_or_slug: str = typer.Argument(..., help="App ID or slug"),
    query: str | None = typer.Option(None, "--query", "-q", help="Search query"),
    limit: int | None = typer.Option(None, "--limit", "-n", help="Max entries"),
    from_time: str | None = typer.Option(None, "--from", help="Start time (ISO 8601)"),
    to_time: str | None = typer.Option(None, "--to", help="End time (ISO 8601)"),
    sort: str | None = typer.Option(None, "--sort", help="Sort order (asc/desc)"),
) -> None:
    """View app logs."""
    client = get_client()
    api = AppAPI(client)

    try:
        output = api.logs(
            id_or_slug,
            query=query,
            limit=limit,
            from_time=from_time,
            to_time=to_time,
            sort=sort,
        )
        if output:
            print(output)
    except APIError as e:
        print_error(f"Failed to get logs: {e.message}")
        raise typer.Exit(1)
