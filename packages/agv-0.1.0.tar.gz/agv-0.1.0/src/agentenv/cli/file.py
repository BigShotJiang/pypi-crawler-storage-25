"""File storage CLI commands."""

import os
import typer
from typing import Optional
from pathlib import Path

from ..api.client import Client, APIError
from ..api.file import FileAPI
from ..config.settings import get_settings
from ..ui.progress import status, download_progress
from ..ui.tables import (
    print_file_table,
    print_error,
    print_success,
)


app = typer.Typer(help="File storage commands")


def get_workspace_id(workspace_id: Optional[str] = None) -> str:
    """Get workspace ID from argument or settings.

    Args:
        workspace_id: Explicit workspace ID

    Returns:
        Workspace ID
    """
    if workspace_id:
        return workspace_id

    settings = get_settings()
    if settings.workspace:
        return settings.workspace

    # Files can be user-scoped, so workspace is optional
    return None


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


@app.command("upload")
def upload_file(
    local_path: str = typer.Argument(..., help="Local file path"),
    remote_path: Optional[str] = typer.Argument(None, help="Remote path (optional)"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Upload a file.

    Examples:
        av file upload ./myfile.txt
        av file upload ./myfile.txt /path/remote.txt
        av file upload ./myfile.txt --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = FileAPI(client)

    if not os.path.exists(local_path):
        print_error(f"File not found: {local_path}")
        raise typer.Exit(1)

    file_size = os.path.getsize(local_path)
    file_name = os.path.basename(local_path)

    try:
        with status(f"Uploading {file_name} ({file_size:,} bytes)..."):
            metadata = api.upload(local_path, workspace, remote_path)
    except APIError as e:
        print_error(f"Failed to upload file: {e.message}")
        raise typer.Exit(1)

    print_success(f"File uploaded: {metadata.path}")


@app.command("download")
def download_file(
    remote_path: str = typer.Argument(..., help="Remote file path"),
    local_path: Optional[str] = typer.Argument(None, help="Local path (optional)"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Download a file.

    Examples:
        av file download /myfile.txt
        av file download /myfile.txt ./local.txt
        av file download /myfile.txt --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = FileAPI(client)

    # Determine local path
    if local_path is None:
        local_path = os.path.basename(remote_path)

    try:
        # Get metadata first for progress
        metadata = api.get_metadata(workspace, remote_path)

        with status(f"Downloading {metadata.name} ({metadata.size_bytes:,} bytes)..."):
            api.download(remote_path, local_path, workspace)

    except APIError as e:
        print_error(f"Failed to download file: {e.message}")
        raise typer.Exit(1)

    print_success(f"File downloaded: {local_path}")


@app.command("ls")
def list_files(
    path: str = typer.Argument("/", help="Remote directory path"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """List files.

    Examples:
        av file ls
        av file ls /documents
        av file ls / --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = FileAPI(client)

    try:
        files = api.list(workspace, path)
    except APIError as e:
        print_error(f"Failed to list files: {e.message}")
        raise typer.Exit(1)

    print_file_table(files)


@app.command("list", deprecated=True)
def list_files_alt(
    path: str = typer.Argument("/", help="Remote directory path"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """List files (alias for ls)."""
    list_files(path, workspace_id)


@app.command("mkdir")
def make_directory(
    path: str = typer.Argument(..., help="Directory path"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Create a directory.

    Examples:
        av file mkdir /documents
        av file mkdir /documents/new --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = FileAPI(client)

    try:
        with status(f"Creating directory {path}..."):
            api.create_directory(path, workspace)
    except APIError as e:
        print_error(f"Failed to create directory: {e.message}")
        raise typer.Exit(1)

    print_success(f"Directory created: {path}")


@app.command("rm")
def delete_file(
    path: str = typer.Argument(..., help="File path"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a file or directory.

    Examples:
        av file rm /myfile.txt
        av file rm /documents --workspace wk_abc123
    """
    if not force:
        typer.confirm(f"Delete {path}?", abort=True)

    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = FileAPI(client)

    try:
        with status(f"Deleting {path}..."):
            api.delete(path, workspace)
    except APIError as e:
        print_error(f"Failed to delete: {e.message}")
        raise typer.Exit(1)

    print_success(f"Deleted: {path}")


@app.command("delete", deprecated=True)
def delete_file_alt(
    path: str = typer.Argument(..., help="File path"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a file or directory (alias for rm)."""
    delete_file(path, workspace_id, force=True)


@app.command("info")
def show_file_info(
    path: str = typer.Argument(..., help="File path"),
    workspace_id: Optional[str] = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Show file metadata.

    Examples:
        av file info /myfile.txt
        av file info /myfile.txt --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = FileAPI(client)

    try:
        metadata = api.get_metadata(workspace, path)
    except APIError as e:
        print_error(f"Failed to get file info: {e.message}")
        raise typer.Exit(1)

    from rich.table import Table
    from rich.console import Console
    from ..ui.tables import _format_size, _format_datetime

    console = Console()
    table = Table(title=f"File: {metadata.name}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("Path", metadata.path)
    table.add_row("Name", metadata.name)
    table.add_row("Size", _format_size(metadata.size_bytes))
    table.add_row("Type", metadata.mime_type or "-")
    table.add_row("Directory", "Yes" if metadata.is_directory else "No")
    table.add_row("Created", _format_datetime(metadata.created_at))
    table.add_row("Modified", _format_datetime(metadata.modified_at))
    if metadata.checksum:
        table.add_row("Checksum", metadata.checksum)

    console.print(table)
