"""Authentication CLI commands."""

from urllib.parse import urlparse

import typer

from ..api.auth import AuthAPI
from ..api.client import Client
from ..config.settings import get_settings, reset_settings
from ..ui.progress import status
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_api_key_table,
    print_config,
    print_error,
    print_success,
)

app = typer.Typer(help="Authentication commands")


def _build_frontend_login_url(api_url: str) -> str:
    """Derive the browser login URL from the configured API URL."""
    frontend_url = api_url.rstrip("/")
    if frontend_url.endswith("/api"):
        frontend_url = frontend_url[:-4]
    elif frontend_url.endswith("/v1"):
        frontend_url = frontend_url[:-3]

    parsed = urlparse(frontend_url)
    scheme = parsed.scheme or "https"
    host = parsed.hostname or "localhost"

    if host in {"localhost", "127.0.0.1"}:
        return f"{scheme}://{host}:5173/login"

    if host.startswith("api."):
        host = host[4:]

    return f"{scheme}://{host}/login"


@app.command()
def login(
    ctx: typer.Context,
    api_key: str | None = typer.Option(None, "--api-key", help="API key for authentication"),
    username: str | None = typer.Option(None, "--username", "-u", help="Username for login"),
    password: str | None = typer.Option(None, "--password", "-p", help="Password for login"),
    public_host: str | None = typer.Option(
        None,
        "--public-host",
        help="Public host/IP for remote browser login callback (e.g. 177.54.159.23)",
    ),
    callback_port: int = typer.Option(
        50391,
        "--callback-port",
        help="Local callback server port for browser login",
    ),
) -> None:
    """Authenticate with AgentEnv Cloud.

    Opens browser for login. After successful authentication,
    you'll be redirected back to the CLI with a JWT token.

    Examples:
        av login
        av login --api-key sk_live_xxxxx
        av login --username user@example.com --password pass
        av login --public-host 177.54.159.23
    """
    settings = get_settings()

    if api_key:
        # API key login
        settings.api_key = api_key
        settings.save_credentials()
        if json_output_enabled():
            emit_json({"authenticated": True, "method": "api_key"})
            return
        print_success("Logged in with API key")
        return

    if username and password:
        # Username/password login (dev only)
        with status("Logging in..."):
            client = Client(base_url=settings.api_url)
            api = AuthAPI(client)
            try:
                result = api.login(username, password)
                settings.access_token = result.access_token
                settings.refresh_token = result.refresh_token
                settings.save_credentials()
                if json_output_enabled():
                    emit_json(
                        {
                            "authenticated": True,
                            "method": "password",
                            "username": result.user.username,
                        }
                    )
                    return
                print_success(f"Logged in as {result.user.username}")
                return
            except Exception as e:
                print_error(str(e))
                raise typer.Exit(1)

    # Browser-based OAuth flow
    from ..oauth.flow import run_browser_login_flow

    # Hosted environments use the branded root domain, while local dev keeps :5173.
    frontend_url = _build_frontend_login_url(settings.api_url)
    public_host = public_host.strip() if public_host else None

    callback_host = "localhost"
    callback_bind_host = "127.0.0.1"
    if public_host:
        callback_host = public_host
        callback_bind_host = "0.0.0.0"

    # Run browser login flow
    token, error = run_browser_login_flow(
        frontend_url=frontend_url,
        port=callback_port,
        open_browser=True,
        callback_host=callback_host,
        callback_bind_host=callback_bind_host,
    )

    if error:
        print_error(f"Login failed: {error}")
        raise typer.Exit(1)

    if token:
        # Verify token and get user info
        with status("Verifying token..."):
            try:
                client = Client(base_url=settings.api_url, access_token=token)
                api = AuthAPI(client)
                profile = api.get_profile()

                settings.access_token = token
                settings.save_credentials()
                if json_output_enabled():
                    emit_json(
                        {
                            "authenticated": True,
                            "method": "browser",
                            "username": profile.username,
                        }
                    )
                    return
                print_success(f"Logged in as {profile.username}")
                return
            except Exception as e:
                print_error(f"Failed to verify token: {e}")
                raise typer.Exit(1)


@app.command()
def logout() -> None:
    """Logout and clear stored credentials."""
    settings = get_settings()
    use_json = json_output_enabled()
    settings.clear_credentials()
    reset_settings()
    if use_json:
        emit_json({"authenticated": False})
        return
    print_success("Logged out successfully")


@app.command("status")
def auth_status() -> None:
    """Show current authentication status."""
    settings = get_settings()

    authenticated = settings.is_authenticated()
    credentials = {
        "apiKey": bool(settings.api_key),
        "accessToken": bool(settings.access_token),
        "refreshToken": bool(settings.refresh_token),
        "apiUrl": settings.api_url,
        "workspace": settings.workspace,
    }

    if json_output_enabled():
        emit_json({"authenticated": authenticated, "credentials": credentials})
        return

    config = {
        "API Key": "Set" if credentials["apiKey"] else "Not set",
        "Access Token": "Set" if credentials["accessToken"] else "Not set",
        "Refresh Token": "Set" if credentials["refreshToken"] else "Not set",
        "API URL": settings.api_url,
        "Workspace": settings.workspace or "Not set",
    }

    if authenticated:
        print_success("Authenticated")
    else:
        print_error("Not authenticated", title="Status")

    print_config(config)


@app.command("create-key")
def create_api_key(
    name: str = typer.Argument(..., help="Name for the API key"),
) -> None:
    """Create a new API key.

    Examples:
        av auth create-key "My CLI Key"
    """
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    with status("Creating API key..."):
        client = Client(
            base_url=settings.api_url,
            api_key=settings.api_key,
            access_token=settings.access_token,
        )
        api = AuthAPI(client)

        try:
            key = api.create_api_key(name)
        except Exception as e:
            print_error(f"Failed to create API key: {e}")
            raise typer.Exit(1)

    plaintext_key = key.key
    if not plaintext_key:
        print_error(
            "Failed to create API key: server response did not include plaintext key."
        )
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"id": key.id, "name": key.name, "key": plaintext_key})
        return

    print_success(f"API key '{name}' created")
    print(f"\nKey: [bold green]{plaintext_key}[/bold green]")
    print("\nSave this key now - you won't be able to see it again!")
    print(f"\nTo use it:\n  av login --api-key {plaintext_key}")


@app.command("list-keys")
def list_api_keys() -> None:
    """List all API keys."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    with status("Loading API keys..."):
        client = Client(
            base_url=settings.api_url,
            api_key=settings.api_key,
            access_token=settings.access_token,
        )
        api = AuthAPI(client)

        try:
            keys = api.list_api_keys()
        except Exception as e:
            print_error(f"Failed to list API keys: {e}")
            raise typer.Exit(1)

    print_api_key_table(keys)


@app.command("revoke-key")
def revoke_api_key(
    key_id: str = typer.Argument(..., help="API key ID to revoke"),
) -> None:
    """Revoke an API key.

    Examples:
        av auth revoke-key ak_abc123
    """
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    with status(f"Revoking API key {key_id}..."):
        client = Client(
            base_url=settings.api_url,
            api_key=settings.api_key,
            access_token=settings.access_token,
        )
        api = AuthAPI(client)

        try:
            api.delete_api_key(key_id)
        except Exception as e:
            print_error(f"Failed to revoke API key: {e}")
            raise typer.Exit(1)

    if json_output_enabled():
        emit_json({"revoked": key_id})
        return

    print_success(f"API key {key_id} revoked")


@app.command("profile")
def get_profile() -> None:
    """Get current user profile."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    with status("Loading profile..."):
        client = Client(
            base_url=settings.api_url,
            api_key=settings.api_key,
            access_token=settings.access_token,
        )
        api = AuthAPI(client)

        try:
            profile = api.get_profile()
        except Exception as e:
            print_error(f"Failed to load profile: {e}")
            raise typer.Exit(1)

    from ..ui.tables import print_config
    print_config({
        "ID": profile.id,
        "Email": profile.email,
        "Username": profile.username,
    })
