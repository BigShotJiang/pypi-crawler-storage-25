"""Compute cluster CLI commands."""

from __future__ import annotations

import json
import time
from typing import Any

import typer
from rich.console import Console
from rich.table import Table

from ..api.client import APIError, Client
from ..api.cluster import ClusterAPI
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import emit_json, json_output_enabled, print_error, print_success

app = typer.Typer(help="Ray and Spark cluster commands")
console = Console()


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def _emit(data: Any) -> None:
    """Emit output in the selected format."""
    if json_output_enabled():
        emit_json(data)
        return
    print(json.dumps(data, indent=2, default=str))


def _resolve_workspace_id(workspace_id: str | None) -> str:
    """Resolve the target workspace for cluster creation."""
    resolved = workspace_id or get_settings().workspace
    if resolved:
        return resolved

    print_error("No workspace specified. Use --workspace or set a default with 'av workspace use'.")
    raise typer.Exit(1)


def _wait_for_cluster(api: ClusterAPI, cluster_id: str, timeout: int) -> dict[str, Any]:
    """Wait for a cluster to reach a terminal or running state."""
    start = time.time()
    latest: dict[str, Any] = {"id": cluster_id, "status": "unknown"}
    while time.time() - start < timeout:
        latest = api.get_cluster(cluster_id)
        state = str(latest.get("status") or "").lower()
        if state in {"running", "failed", "stopped"}:
            return latest
        time.sleep(2)
    raise TimeoutError(f"Timed out waiting for cluster {cluster_id} to become ready")


def _print_cluster_table(clusters: list[dict[str, Any]]) -> None:
    """Render cluster rows in a table."""
    if not clusters:
        console.print("[dim]No clusters found.[/dim]")
        return

    table = Table(title="Clusters")
    table.add_column("ID", style="cyan")
    table.add_column("Type")
    table.add_column("Status")
    table.add_column("Shape")
    table.add_column("Workspace")
    table.add_column("Created")

    for cluster in clusters:
        config = cluster.get("config") or {}
        table.add_row(
            str(cluster.get("id", ""))[:12],
            str(cluster.get("type", "-")),
            str(cluster.get("status", "-")),
            str(config.get("shape", "-")),
            str(cluster.get("workspaceId", "-")),
            str(cluster.get("createdAt", "-")),
        )

    console.print(table)


@app.command("ray")
def create_ray_cluster(
    shape: str = typer.Argument(..., help="Cluster shape (for example 4x2xH100)"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    name: str | None = typer.Option(None, "--name", help="Cluster name"),
    image: str | None = typer.Option(None, "--image", help="Image override"),
    snapshot_id: str | None = typer.Option(None, "--snapshot", "--snapshot-id", help="Snapshot ID override"),
    allow_cidr: str | None = typer.Option(None, "--allow-cidr", help="Direct-connect allowlist CIDR"),
    wait: bool = typer.Option(False, "--wait/--no-wait", help="Wait for the cluster to reach running state"),
    timeout: int = typer.Option(600, "--timeout", help="Wait timeout in seconds"),
) -> None:
    """Create a Ray cluster."""
    client = get_client()
    api = ClusterAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        with status("Creating Ray cluster..."):
            cluster = api.create_ray_cluster(
                workspace_id=resolved_workspace_id,
                shape=shape,
                name=name,
                image=image,
                snapshot_id=snapshot_id,
                allow_cidr=allow_cidr,
            )
        if wait:
            with status("Waiting for cluster to become ready..."):
                cluster = _wait_for_cluster(api, cluster["id"], timeout)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Failed to create Ray cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    print_success(f"Ray cluster {cluster['id']} created")
    _emit(cluster)


@app.command("spark")
def create_spark_cluster(
    shape: str = typer.Argument(..., help="Cluster shape (for example 4x2xH100)"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
    name: str | None = typer.Option(None, "--name", help="Cluster name"),
    image: str | None = typer.Option(None, "--image", help="Image override"),
    snapshot_id: str | None = typer.Option(None, "--snapshot", "--snapshot-id", help="Snapshot ID override"),
    allow_cidr: str | None = typer.Option(None, "--allow-cidr", help="Direct-connect allowlist CIDR"),
    wait: bool = typer.Option(False, "--wait/--no-wait", help="Wait for the cluster to reach running state"),
    timeout: int = typer.Option(600, "--timeout", help="Wait timeout in seconds"),
) -> None:
    """Create a Spark cluster."""
    client = get_client()
    api = ClusterAPI(client)
    resolved_workspace_id = _resolve_workspace_id(workspace_id)

    try:
        with status("Creating Spark cluster..."):
            cluster = api.create_spark_cluster(
                workspace_id=resolved_workspace_id,
                shape=shape,
                name=name,
                image=image,
                snapshot_id=snapshot_id,
                allow_cidr=allow_cidr,
            )
        if wait:
            with status("Waiting for cluster to become ready..."):
                cluster = _wait_for_cluster(api, cluster["id"], timeout)
    except TimeoutError as e:
        print_error(str(e))
        raise typer.Exit(1)
    except APIError as e:
        print_error(f"Failed to create Spark cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    print_success(f"Spark cluster {cluster['id']} created")
    _emit(cluster)


@app.command("ls")
def list_clusters(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """List clusters."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        clusters = api.list_clusters(workspace_id=workspace_id)
    except APIError as e:
        print_error(f"Failed to list clusters: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(clusters)
        return

    _print_cluster_table(clusters)


@app.command("inspect")
def inspect_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
) -> None:
    """Show cluster details."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        cluster = api.get_cluster(cluster_id)
    except APIError as e:
        print_error(f"Failed to get cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    _emit(cluster)


@app.command("stop")
def stop_cluster(
    cluster_id: str = typer.Argument(..., help="Cluster ID"),
) -> None:
    """Stop a cluster."""
    client = get_client()
    api = ClusterAPI(client)

    try:
        with status(f"Stopping cluster {cluster_id}..."):
            cluster = api.stop_cluster(cluster_id)
    except APIError as e:
        print_error(f"Failed to stop cluster: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(cluster)
        return

    print_success(f"Cluster {cluster_id} stop requested")
    _emit(cluster)
