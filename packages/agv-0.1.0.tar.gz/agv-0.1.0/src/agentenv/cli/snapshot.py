"""Snapshot CLI commands."""

import typer
from typing import Optional

from ..api.client import Client, APIError
from ..api.snapshot import SnapshotAPI
from ..api.sandbox import SandboxAPI
from ..api.models import Snapshot
from ..config.settings import get_settings
from ..ui.progress import status
from ..ui.tables import (
    print_snapshot_table,
    print_sandbox_detail,
    print_error,
    print_success,
)


app = typer.Typer(help="Snapshot management commands")


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


@app.command("create")
def create_snapshot(
    sandbox_id: str = typer.Argument(..., help="Sandbox ID"),
    name: Optional[str] = typer.Option(None, "--name", help="Snapshot name"),
    memory: bool = typer.Option(False, "--memory", help="Include memory in snapshot"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for completion"),
) -> None:
    """Create a snapshot from a running sandbox.

    Examples:
        av snapshot create sb_abc123
        av snapshot create sb_abc123 --name "My Snapshot" --memory
    """
    client = get_client()
    api = SnapshotAPI(client)

    try:
        snapshot = api.create(sandbox_id, name=name, with_memory=memory)
    except APIError as e:
        print_error(f"Failed to create snapshot: {e.message}")
        raise typer.Exit(1)

    print_success(f"Snapshot {snapshot.id} created")

    if wait:
        with status("Waiting for snapshot to complete..."):
            try:
                snapshot = api.wait_for_status(snapshot.id, timeout=300)
            except TimeoutError:
                print_error("Snapshot timed out")
                raise typer.Exit(1)

        print_success(f"Snapshot {snapshot.id} completed")
        if snapshot.size_bytes is not None:
            print(f"  Size: {snapshot.size_bytes:,} bytes")
        if snapshot.name:
            print(f"  Name: {snapshot.name}")


@app.command("ls")
def list_snapshots() -> None:
    """List all snapshots."""
    client = get_client()
    api = SnapshotAPI(client)

    try:
        snapshots = api.list_all()
    except APIError as e:
        print_error(f"Failed to list snapshots: {e.message}")
        raise typer.Exit(1)

    print_snapshot_table(snapshots)


@app.command("list", deprecated=True)
def list_snapshots_alt() -> None:
    """List all snapshots (alias for ls)."""
    list_snapshots()


@app.command()
def inspect(snapshot_id: str = typer.Argument(..., help="Snapshot ID")) -> None:
    """Show snapshot details.

    Examples:
        av snapshot inspect sn_abc123
    """
    client = get_client()
    api = SnapshotAPI(client)

    try:
        snapshot = api.get(snapshot_id)
    except APIError as e:
        print_error(f"Failed to get snapshot: {e.message}")
        raise typer.Exit(1)

    from rich.table import Table
    from rich.console import Console
    from ..ui.tables import _colored_status, _format_size, _format_datetime

    console = Console()
    table = Table(title=f"Snapshot: {snapshot.name or snapshot.id}", show_header=False)
    table.add_column("Field", style="cyan")
    table.add_column("Value")

    table.add_row("ID", snapshot.id)
    table.add_row("Name", snapshot.name or "-")
    table.add_row("Status", _colored_status(snapshot.status))
    table.add_row("Sandbox ID", snapshot.sandbox_id)
    table.add_row("Size", _format_size(snapshot.size_bytes))
    table.add_row(
        "Memory",
        "Yes"
        if snapshot.has_memory is True
        else ("No" if snapshot.has_memory is False else "-"),
    )
    table.add_row("Checksum", snapshot.checksum or "-")
    table.add_row("Path", snapshot.snapshot_path or "-")
    table.add_row("Created", _format_datetime(snapshot.created_at))

    console.print(table)


@app.command("rm")
def delete_snapshot(
    snapshot_id: str = typer.Argument(..., help="Snapshot ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a snapshot.

    Examples:
        av snapshot rm sn_abc123
    """
    if not force:
        typer.confirm(f"Delete snapshot {snapshot_id}?", abort=True)

    client = get_client()
    api = SnapshotAPI(client)

    try:
        with status(f"Deleting snapshot {snapshot_id}..."):
            api.delete(snapshot_id)
    except APIError as e:
        print_error(f"Failed to delete snapshot: {e.message}")
        raise typer.Exit(1)

    print_success(f"Snapshot {snapshot_id} deleted")


@app.command("delete", deprecated=True)
def delete_snapshot_alt(
    snapshot_id: str = typer.Argument(..., help="Snapshot ID"),
    force: bool = typer.Option(False, "--force", "-f", help="Force delete without confirmation"),
) -> None:
    """Delete a snapshot (alias for rm)."""
    delete_snapshot(snapshot_id, force=True)


@app.command("restore")
def restore_snapshot(
    snapshot_id: str = typer.Argument(..., help="Snapshot ID or name"),
    name: Optional[str] = typer.Option(None, "--name", help="Name for restored sandbox"),
    wait: bool = typer.Option(True, "--wait/--no-wait", help="Wait for sandbox to start"),
) -> None:
    """Restore a sandbox from a snapshot.

    Examples:
        av snapshot restore sn_abc123
        av snapshot restore sn_abc123 --name "Restored Environment"
    """
    client = get_client()
    api = SnapshotAPI(client)

    try:
        with status("Restoring snapshot..."):
            sandbox = api.restore(snapshot_id, name=name)
    except APIError as e:
        print_error(f"Failed to restore snapshot: {e.message}")
        raise typer.Exit(1)

    print_success(f"Sandbox {sandbox.id} created from snapshot")

    if wait:
        from ..api.sandbox import SandboxAPI
        sandbox_api = SandboxAPI(client)

        with status("Waiting for sandbox to start..."):
            try:
                sandbox = sandbox_api.wait_for_status(sandbox.id, timeout=120)
            except TimeoutError:
                print_error("Sandbox failed to start in time")
                raise typer.Exit(1)

        print_success(f"Sandbox {sandbox.id} is running")
        print_sandbox_detail(sandbox)
