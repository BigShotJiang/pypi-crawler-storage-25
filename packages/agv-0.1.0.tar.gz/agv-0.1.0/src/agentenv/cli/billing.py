"""Billing CLI commands."""


import typer

from ..api.billing import BillingAPI
from ..api.client import APIError, Client
from ..config.settings import get_settings
from ..ui.tables import (
    emit_json,
    json_output_enabled,
    print_balance,
    print_error,
    print_success,
    print_transaction_table,
)

app = typer.Typer(help="Billing and payment commands")


def get_workspace_id(workspace_id: str | None = None) -> str:
    """Get workspace ID from argument or settings.

    Args:
        workspace_id: Explicit workspace ID

    Returns:
        Workspace ID
    """
    if workspace_id:
        return workspace_id

    settings = get_settings()
    if settings.workspace:
        return settings.workspace

    print_error("No workspace specified. Use --workspace or set default with 'av workspace use'")
    raise typer.Exit(1)


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()

    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)

    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


@app.command("balance")
def show_balance(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Show account balance.

    Examples:
        av balance
        av balance --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = BillingAPI(client)

    try:
        balance = api.get_balance(workspace)
    except APIError as e:
        print_error(f"Failed to get balance: {e.message}")
        raise typer.Exit(1)

    print_balance(balance)


@app.command("history")
def show_history(
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Show transaction history.

    Examples:
        av billing history
        av billing history --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = BillingAPI(client)

    try:
        transactions = api.get_transactions(workspace)
    except APIError as e:
        print_error(f"Failed to get transactions: {e.message}")
        raise typer.Exit(1)

    print_transaction_table(transactions)


@app.command("add")
def add_credits(
    amount: float = typer.Argument(..., help="Amount to add in USD"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Add credits to workspace.

    Examples:
        av billing add 10.00
        av billing add 50.00 --workspace wk_abc123
    """
    workspace = get_workspace_id(workspace_id)
    client = get_client()
    api = BillingAPI(client)

    amount_cents = int(amount * 100)

    try:
        result = api.create_checkout_session(workspace, amount_cents)
    except APIError as e:
        print_error(f"Failed to create checkout: {e.message}")
        raise typer.Exit(1)

    if json_output_enabled():
        emit_json(result)
        return

    if "url" in result:
        import webbrowser
        print_success(f"Checkout session created for ${amount:.2f}")
        print(f"Opening browser to: {result['url']}")
        webbrowser.open(result["url"])
    else:
        print_success(f"Added ${amount:.2f} to workspace")


@app.command("checkout")
def create_checkout(
    amount: float = typer.Argument(..., help="Amount in USD"),
    workspace_id: str | None = typer.Option(None, "--workspace", "-w", help="Workspace ID"),
) -> None:
    """Create a checkout session for adding credits.

    Examples:
        av billing checkout 10.00
    """
    add_credits(amount, workspace_id)
