"""Static site CLI commands."""

from __future__ import annotations

import tempfile
import zipfile
from pathlib import Path

import typer
from rich.console import Console
from rich.table import Table

from ..api.client import APIError, Client
from ..api.site import SiteAPI
from ..config.settings import get_settings
from ..ui.tables import emit_json, json_output_enabled, print_error, print_success

app = typer.Typer(help="Static site management commands")
console = Console()

# Patterns to exclude when zipping
EXCLUDE_PATTERNS = {
    ".git",
    ".gitignore",
    "node_modules",
    "__pycache__",
    ".DS_Store",
    "*.pyc",
    ".env",
    ".env.local",
    "venv",
    ".venv",
}


def get_client() -> Client:
    """Get authenticated API client."""
    settings = get_settings()
    if not settings.is_authenticated():
        print_error("Not authenticated. Run 'av login' first.")
        raise typer.Exit(1)
    return Client(
        base_url=settings.api_url,
        api_key=settings.api_key,
        access_token=settings.access_token,
    )


def should_exclude(path: Path, base: Path) -> bool:
    """Check if path should be excluded from zip."""
    rel_path = path.relative_to(base)
    rel_parts = rel_path.parts
    for part in rel_parts:
        if part in EXCLUDE_PATTERNS:
            return True
        for pattern in EXCLUDE_PATTERNS:
            if "*" in pattern and rel_path.match(pattern):
                return True
    return False


def create_zip(source_dir: Path, output_path: Path) -> int:
    """Create a zip file from directory, returns file count."""
    file_count = 0
    with zipfile.ZipFile(output_path, "w", zipfile.ZIP_DEFLATED) as zf:
        for file_path in source_dir.rglob("*"):
            if file_path.is_file() and not should_exclude(file_path, source_dir):
                arcname = file_path.relative_to(source_dir)
                zf.write(file_path, arcname)
                file_count += 1
    return file_count


def format_bytes(size: int) -> str:
    """Format bytes to human readable."""
    size_float = float(size)
    for unit in ["B", "KB", "MB", "GB"]:
        if size_float < 1024:
            return f"{size_float:.1f} {unit}"
        size_float /= 1024
    return f"{size_float:.1f} TB"


@app.command("create")
def create_site(
    name: str = typer.Option(..., "--name", "-n", help="Site display name"),
    slug: str | None = typer.Option(None, "--slug", "-s", help="Custom slug (optional)"),
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """Create a new static site."""
    client = get_client()
    api = SiteAPI(client)

    try:
        site = api.create(name=name, slug=slug, workspace_id=workspace_id)
        if json_output_enabled():
            emit_json(site)
            return
        print_success(f"Created site '{site.name}' ({site.slug})")
        console.print(f"URL: [cyan]{site.url}[/cyan]")
        console.print(f"\nDeploy with: [dim]av site deploy {site.slug} ./dist[/dim]")
    except APIError as e:
        print_error(f"Failed to create site: {e.message}")
        raise typer.Exit(1)


@app.command("deploy")
def deploy_site(
    slug: str = typer.Argument(..., help="Site slug"),
    path: Path = typer.Argument(..., help="Directory to deploy"),
) -> None:
    """Deploy a directory to a site."""
    if not path.exists():
        print_error(f"Path does not exist: {path}")
        raise typer.Exit(1)

    if not path.is_dir():
        print_error(f"Path is not a directory: {path}")
        raise typer.Exit(1)

    index_file = path / "index.html"
    if not index_file.exists():
        print_error(f"Directory must contain index.html: {path}")
        raise typer.Exit(1)

    client = get_client()
    api = SiteAPI(client)

    # Find site by slug
    site = api.get_by_slug(slug)
    if not site:
        print_error(f"Site not found: {slug}")
        raise typer.Exit(1)

    # Create zip in temp directory
    with tempfile.TemporaryDirectory() as temp_dir:
        zip_path = Path(temp_dir) / "deploy.zip"

        console.print(f"[dim]Packaging {path}...[/dim]")
        file_count = create_zip(path, zip_path)
        zip_size = zip_path.stat().st_size

        console.print(f"[dim]Uploading {format_bytes(zip_size)} ({file_count} files)...[/dim]")

        try:
            updated_site = api.deploy(site.id, zip_path)
            if json_output_enabled():
                emit_json(updated_site)
                return
            print_success(f"Deployed version {updated_site.current_version}")
            console.print(f"Live at: [cyan]{updated_site.url}[/cyan]")
        except APIError as e:
            print_error(f"Failed to deploy: {e.message}")
            raise typer.Exit(1)


@app.command("ls")
def list_sites(
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """List all sites."""
    client = get_client()
    api = SiteAPI(client)

    try:
        sites = api.list_all(workspace_id=workspace_id)
        if json_output_enabled():
            emit_json(sites)
            return

        if not sites:
            console.print("[dim]No sites found.[/dim]")
            return

        table = Table(show_header=True)
        table.add_column("Name")
        table.add_column("Slug")
        table.add_column("Version")
        table.add_column("URL")

        for site in sites:
            table.add_row(
                site.name,
                site.slug,
                site.current_version or "-",
                site.url,
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to list sites: {e.message}")
        raise typer.Exit(1)


@app.command("list", deprecated=True, hidden=True)
def list_sites_alt(
    workspace_id: str | None = typer.Option(None, "--workspace-id", "-w", help="Workspace ID"),
) -> None:
    """List all sites (alias for ls)."""
    list_sites(workspace_id=workspace_id)


@app.command("versions")
def list_versions(
    slug: str = typer.Argument(..., help="Site slug"),
    delete: str | None = typer.Option(None, "--delete", "-d", help="Delete a specific version"),
) -> None:
    """List or delete site versions."""
    client = get_client()
    api = SiteAPI(client)

    site = api.get_by_slug(slug)
    if not site:
        print_error(f"Site not found: {slug}")
        raise typer.Exit(1)

    if delete:
        # Delete version
        if delete == site.current_version:
            print_error("Cannot delete the current version")
            raise typer.Exit(1)

        try:
            api.delete_version(site.id, delete)
            print_success(f"Deleted version {delete}")
        except APIError as e:
            print_error(f"Failed to delete version: {e.message}")
            raise typer.Exit(1)
        return

    # List versions
    try:
        versions = api.get_versions(site.id)
        if json_output_enabled():
            emit_json(versions)
            return

        if not versions:
            console.print("[dim]No versions found.[/dim]")
            return

        table = Table(show_header=True)
        table.add_column("Version")
        table.add_column("Size")
        table.add_column("Files")
        table.add_column("Created")
        table.add_column("Current")

        for v in sorted(versions, key=lambda x: x.created_at, reverse=True):
            is_current = "*" if v.version == site.current_version else ""
            table.add_row(
                v.version,
                format_bytes(v.size_bytes),
                str(v.file_count),
                v.created_at.strftime("%Y-%m-%d %H:%M"),
                is_current,
            )

        console.print(table)
    except APIError as e:
        print_error(f"Failed to get versions: {e.message}")
        raise typer.Exit(1)


@app.command("rollback")
def rollback_site(
    slug: str = typer.Argument(..., help="Site slug"),
    version: str = typer.Argument(..., help="Version to rollback to"),
) -> None:
    """Rollback site to a previous version."""
    client = get_client()
    api = SiteAPI(client)

    site = api.get_by_slug(slug)
    if not site:
        print_error(f"Site not found: {slug}")
        raise typer.Exit(1)

    try:
        updated_site = api.rollback(site.id, version)
        if json_output_enabled():
            emit_json(updated_site)
            return
        print_success(f"Rolled back to version {version}")
        console.print(f"Live at: [cyan]{updated_site.url}[/cyan]")
    except APIError as e:
        print_error(f"Failed to rollback: {e.message}")
        raise typer.Exit(1)


@app.command("delete")
def delete_site(
    slug: str = typer.Argument(..., help="Site slug"),
    force: bool = typer.Option(False, "--force", "-f", help="Skip confirmation"),
) -> None:
    """Delete a site and all its versions."""
    client = get_client()
    api = SiteAPI(client)

    site = api.get_by_slug(slug)
    if not site:
        print_error(f"Site not found: {slug}")
        raise typer.Exit(1)

    if not force:
        confirm = typer.confirm(f"Delete site '{site.name}' ({site.slug})? This cannot be undone.")
        if not confirm:
            raise typer.Abort()

    try:
        api.delete(site.id)
        print_success(f"Deleted site '{site.name}'")
    except APIError as e:
        print_error(f"Failed to delete site: {e.message}")
        raise typer.Exit(1)
