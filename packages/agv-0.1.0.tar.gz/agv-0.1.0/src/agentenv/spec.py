"""Shared helpers for parsing sandbox specs."""

from __future__ import annotations

import re

from .config.settings import get_settings


class SandboxSpecError(ValueError):
    """Raised when a sandbox spec cannot be resolved."""


_CLUSTER_SHAPE_RE = re.compile(r"^\d+x(\d+x)?[A-Za-z0-9]+$", re.IGNORECASE)


def resolve_sandbox_type(type_name: str) -> tuple[int, int]:
    """Resolve a sandbox type or cpu:mem spec to (cpu_millis, memory_mb)."""
    settings = get_settings()
    type_config = settings.get_type_config(type_name)

    if type_config:
        return type_config.cpu, type_config.memory

    if ":" in type_name:
        cpu_str, mem_str = type_name.split(":", 1)
        try:
            return int(cpu_str), int(mem_str)
        except ValueError:
            pass

    raise SandboxSpecError(f"Unknown sandbox type: {type_name}")


def resolve_single_node_spec(spec: str) -> tuple[int, int]:
    """Resolve a single-node sandbox spec; reject cluster shapes."""
    if _CLUSTER_SHAPE_RE.match(spec):
        raise SandboxSpecError(
            "Cluster shapes are not supported for agentenv.function. "
            "Use a preset type (small/xl) or cpu:mem.",
        )
    return resolve_sandbox_type(spec)
