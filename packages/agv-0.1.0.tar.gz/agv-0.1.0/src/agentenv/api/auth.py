"""Authentication API client."""

from typing import Any

from .client import Client
from .models import APIKey, UserProfile, LoginResponse


class AuthAPI:
    """API client for authentication."""

    def __init__(self, client: Client):
        """Initialize auth API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def login(self, username: str, password: str, totp_code: str | None = None) -> LoginResponse:
        """Login with username and password.

        Args:
            username: Username or email
            password: Password
            totp_code: Optional TOTP code for 2FA

        Returns:
            Login response with tokens
        """
        data: dict[str, Any] = {"username": username, "password": password}
        if totp_code:
            data["totpCode"] = totp_code

        response = self.client.post("/v1/auth/login", json=data)
        return LoginResponse(**response.json())

    def signup(self, email: str, password: str, name: str | None = None) -> dict[str, Any]:
        """Sign up a new user.

        Args:
            email: Email address
            password: Password
            name: Optional display name

        Returns:
            Signup response
        """
        data: dict[str, Any] = {"email": email, "password": password}
        if name:
            data["name"] = name

        response = self.client.post("/v1/auth/signup", json=data)
        return response.json()

    def get_profile(self) -> UserProfile:
        """Get current user profile.

        Returns:
            User profile
        """
        response = self.client.get("/v1/auth/profile")
        return UserProfile(**response.json())

    def refresh_token(self, refresh_token: str) -> dict[str, Any]:
        """Refresh access token.

        Args:
            refresh_token: Refresh token

        Returns:
            New tokens
        """
        response = self.client.post(
            "/v1/auth/refresh",
            json={"refreshToken": refresh_token},
        )
        return response.json()

    def logout(self) -> None:
        """Logout current user."""
        self.client.post("/v1/auth/logout")

    # API Key management

    def create_api_key(self, name: str) -> APIKey:
        """Create a new API key.

        Args:
            name: API key name

        Returns:
            Created API key (includes the key value)
        """
        response = self.client.post("/v1/auth/api-keys", json={"name": name})
        return APIKey(**response.json())

    def list_api_keys(self) -> list[APIKey]:
        """List API keys for current user.

        Returns:
            List of API keys
        """
        response = self.client.get("/v1/auth/api-keys")
        return [APIKey(**item) for item in response.json()]

    def delete_api_key(self, key_id: str) -> None:
        """Delete an API key.

        Args:
            key_id: API key ID
        """
        self.client.delete(f"/v1/auth/api-keys/{key_id}")

    def update_api_key(self, key_id: str, name: str) -> APIKey:
        """Update API key name.

        Args:
            key_id: API key ID
            name: New name

        Returns:
            Updated API key
        """
        response = self.client.patch(
            f"/v1/auth/api-keys/{key_id}",
            json={"name": name},
        )
        return APIKey(**response.json())

    # Workspace management (for current user)

    def get_workspaces(self) -> list[dict[str, Any]]:
        """Get workspaces for current user.

        Returns:
            List of workspaces
        """
        response = self.client.get("/v1/auth/workspaces")
        return response.json()

    def set_workspace(self, workspace_id: str) -> dict[str, Any]:
        """Set active workspace.

        Args:
            workspace_id: Workspace ID

        Returns:
            Updated user data
        """
        response = self.client.patch(
            "/v1/auth/workspace",
            json={"workspaceId": workspace_id},
        )
        return response.json()
