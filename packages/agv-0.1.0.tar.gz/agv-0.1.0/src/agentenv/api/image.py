"""Image API client."""

from typing import Any

from .client import Client
from .models import ImageSnapshot, CreateImageRequest, ImageTag


class ImageAPI:
    """API client for image snapshot resources."""

    def __init__(self, client: Client):
        self.client = client

    def ensure(self, request: CreateImageRequest) -> ImageSnapshot:
        """Create or return an image snapshot (idempotent by build hash)."""
        response = self.client.post(
            "/v1/images/ensure",
            json=request.model_dump(exclude_none=True, by_alias=True),
        )
        return ImageSnapshot(**response.json())

    def list_all(
        self,
        workspace_id: str | None = None,
        build_hash: str | None = None,
        tag: str | None = None,
        scope: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> list[ImageSnapshot]:
        params: dict[str, Any] = {"page": page, "limit": limit}
        if workspace_id:
            params["workspaceId"] = workspace_id
        if build_hash:
            params["buildHash"] = build_hash
        if tag:
            params["tag"] = tag
        if scope:
            params["scope"] = scope

        response = self.client.get("/v1/images", params=params)
        data = response.json()

        if isinstance(data, dict) and "images" in data:
            return [ImageSnapshot(**item) for item in data["images"]]
        if isinstance(data, list):
            return [ImageSnapshot(**item) for item in data]
        return []

    def get(self, image_id: str) -> ImageSnapshot:
        response = self.client.get(f"/v1/images/{image_id}")
        return ImageSnapshot(**response.json())

    def delete(self, image_id: str) -> None:
        self.client.delete(f"/v1/images/{image_id}")

    def cancel(self, image_id: str) -> ImageSnapshot:
        response = self.client.post(f"/v1/images/{image_id}/cancel")
        return ImageSnapshot(**response.json())

    def add_tags(self, image_id: str, tags: list[str], overwrite: bool = False) -> ImageSnapshot:
        response = self.client.post(
            f"/v1/images/{image_id}/tags",
            json={"tags": tags, "overwrite": overwrite},
        )
        return ImageSnapshot(**response.json())

    def remove_tag(self, image_id: str, tag: str) -> dict[str, Any]:
        response = self.client.delete(f"/v1/images/{image_id}/tags/{tag}")
        return response.json()

    def list_tags(
        self,
        workspace_id: str | None = None,
        image_id: str | None = None,
        tag: str | None = None,
    ) -> list[ImageTag]:
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        if image_id:
            params["imageId"] = image_id
        if tag:
            params["tag"] = tag

        response = self.client.get("/v1/images/tags/list", params=params)
        data = response.json()
        if isinstance(data, dict) and "tags" in data:
            return [ImageTag(**item) for item in data["tags"]]
        if isinstance(data, list):
            return [ImageTag(**item) for item in data]
        return []

    def resolve(self, workspace_id: str, tag: str) -> ImageSnapshot:
        response = self.client.get(
            "/v1/images/resolve",
            params={"workspaceId": workspace_id, "tag": tag},
        )
        return ImageSnapshot(**response.json())
