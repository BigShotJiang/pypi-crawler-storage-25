"""Billing API client."""

from typing import Any

from .client import Client
from .models import Transaction, BalanceInfo


class BillingAPI:
    """API client for billing resources."""

    def __init__(self, client: Client):
        """Initialize billing API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def get_balance(self, workspace_id: str) -> BalanceInfo:
        """Get workspace balance.

        Args:
            workspace_id: Workspace ID

        Returns:
            Balance information
        """
        response = self.client.get(f"/v1/workspaces/{workspace_id}/billing/balance")
        return BalanceInfo(**response.json())

    def get_transactions(self, workspace_id: str) -> list[Transaction]:
        """Get transaction history.

        Args:
            workspace_id: Workspace ID

        Returns:
            List of transactions
        """
        response = self.client.get(f"/v1/workspaces/{workspace_id}/billing/transactions")
        data = response.json()

        # Handle paginated response: { transactions: [...], total, page, limit }
        if isinstance(data, dict) and "transactions" in data:
            return [Transaction(**item) for item in data["transactions"]]

        # Handle direct list response (fallback)
        if isinstance(data, list):
            return [Transaction(**item) for item in data]

        return []

    def add_credits(
        self,
        workspace_id: str,
        amount_cents: int,
    ) -> dict[str, Any]:
        """Add credits to workspace.

        Args:
            workspace_id: Workspace ID
            amount_cents: Amount in cents

        Returns:
            Payment/credit response
        """
        response = self.client.post(
            f"/v1/workspaces/{workspace_id}/billing/credits",
            json={"amountCents": amount_cents},
        )
        return response.json()

    def create_checkout_session(
        self,
        workspace_id: str,
        amount_cents: int,
    ) -> dict[str, Any]:
        """Create a checkout session for adding credits.

        Args:
            workspace_id: Workspace ID
            amount_cents: Amount in cents

        Returns:
            Checkout session URL
        """
        response = self.client.post(
            f"/v1/workspaces/{workspace_id}/billing/checkout",
            json={"amountCents": amount_cents},
        )
        return response.json()
