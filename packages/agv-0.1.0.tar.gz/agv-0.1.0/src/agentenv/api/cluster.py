"""API client for Ray/Spark clusters."""

from __future__ import annotations

from typing import Any

from .client import Client

class ClusterAPI:
    """API client for compute clusters."""

    def __init__(self, client: Client):
        self.client = client

    def create_ray_cluster(
        self,
        workspace_id: str,
        shape: str,
        name: str | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        allow_cidr: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workspaceId": workspace_id, "shape": shape}
        if name:
            payload["name"] = name
        if image:
            payload["image"] = image
        if snapshot_id:
            payload["snapshotId"] = snapshot_id
        if allow_cidr:
            payload["allowCidr"] = allow_cidr
        resp = self.client.post("/v1/clusters/ray", json=payload)
        return resp.json()

    def create_spark_cluster(
        self,
        workspace_id: str,
        shape: str,
        name: str | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        allow_cidr: str | None = None,
    ) -> dict[str, Any]:
        payload: dict[str, Any] = {"workspaceId": workspace_id, "shape": shape}
        if name:
            payload["name"] = name
        if image:
            payload["image"] = image
        if snapshot_id:
            payload["snapshotId"] = snapshot_id
        if allow_cidr:
            payload["allowCidr"] = allow_cidr
        resp = self.client.post("/v1/clusters/spark", json=payload)
        return resp.json()

    def list_clusters(self, workspace_id: str | None = None) -> list[dict[str, Any]]:
        params = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        resp = self.client.get("/v1/clusters", params=params or None)
        return resp.json()

    def get_cluster(self, cluster_id: str) -> dict[str, Any]:
        resp = self.client.get(f"/v1/clusters/{cluster_id}")
        return resp.json()

    def stop_cluster(self, cluster_id: str) -> dict[str, Any]:
        resp = self.client.put(f"/v1/clusters/{cluster_id}/stop")
        return resp.json()
