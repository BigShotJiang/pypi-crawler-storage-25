"""App deployment API client."""

from typing import Any

from .client import Client
from .models import App, AppVersion, CreateAppRequest


class AppAPI:
    """API client for app deployment resources."""

    def __init__(self, client: Client):
        self.client = client

    def create(self, request: dict[str, Any] | CreateAppRequest) -> App:
        if isinstance(request, CreateAppRequest):
            data = request.model_dump(exclude_none=True, by_alias=True)
        else:
            data = request
        response = self.client.post("/v1/apps", json=data)
        return App(**response.json())

    def list_all(self, workspace_id: str | None = None) -> list[App]:
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        response = self.client.get("/v1/apps", params=params)
        data = response.json()
        if isinstance(data, list):
            return [App(**item) for item in data]
        return []

    def get(self, id_or_slug: str) -> App:
        response = self.client.get(f"/v1/apps/{id_or_slug}")
        return App(**response.json())

    def update(self, id_or_slug: str, **kwargs: Any) -> App:
        response = self.client.patch(f"/v1/apps/{id_or_slug}", json=kwargs)
        return App(**response.json())

    def delete(self, id_or_slug: str) -> dict[str, Any]:
        response = self.client.delete(f"/v1/apps/{id_or_slug}")
        if response.content:
            return response.json()
        return {"success": True}

    def deploy(
        self,
        id_or_slug: str,
        snapshot_id: str,
        env_overrides: dict[str, str] | None = None,
        entrypoint_override: str | None = None,
    ) -> AppVersion:
        payload: dict[str, Any] = {"snapshotId": snapshot_id}
        if env_overrides:
            payload["envOverrides"] = env_overrides
        if entrypoint_override:
            payload["entrypointOverride"] = entrypoint_override
        response = self.client.post(f"/v1/apps/{id_or_slug}/deploy", json=payload)
        return AppVersion(**response.json())

    def get_versions(self, id_or_slug: str) -> list[AppVersion]:
        response = self.client.get(f"/v1/apps/{id_or_slug}/versions")
        data = response.json()
        if isinstance(data, list):
            return [AppVersion(**item) for item in data]
        return []

    def rollback(self, id_or_slug: str, version: str) -> App:
        response = self.client.post(
            f"/v1/apps/{id_or_slug}/rollback",
            json={"version": version},
        )
        return App(**response.json())

    def delete_version(self, id_or_slug: str, version: str) -> None:
        self.client.delete(f"/v1/apps/{id_or_slug}/versions/{version}")

    def logs(
        self,
        id_or_slug: str,
        query: str | None = None,
        limit: int | None = None,
        from_time: str | None = None,
        to_time: str | None = None,
        sort: str | None = None,
        log_path: str | None = None,
    ) -> str:
        """Get app logs."""
        params: dict[str, Any] = {}
        if query:
            params["q"] = query
        if limit is not None:
            params["limit"] = limit
        if from_time:
            params["from"] = from_time
        if to_time:
            params["to"] = to_time
        if sort:
            params["sort"] = sort
        if log_path:
            params["logPath"] = log_path

        response = self.client.get(f"/v1/apps/{id_or_slug}/logs", params=params)

        try:
            data = response.json()
            if isinstance(data, dict):
                entries = data.get("entries") or []
                if entries:
                    lines: list[str] = []
                    for entry in entries:
                        timestamp = entry.get("timestamp")
                        message = entry.get("message")
                        if timestamp:
                            lines.append(f"{timestamp} {message}")
                        else:
                            lines.append(message or "")
                    return "\n".join(lines)
                logs = data.get("logs") or []
                if logs:
                    return "\n".join(logs)
        except (ValueError, KeyError, TypeError):
            # Return raw text if JSON parsing fails
            pass

        return response.text
