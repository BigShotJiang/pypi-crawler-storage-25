"""Snapshot API client."""

from typing import Any

from .client import Client
from .models import Snapshot, CreateSnapshotRequest, Sandbox


class SnapshotAPI:
    """API client for snapshot resources."""

    def __init__(self, client: Client):
        """Initialize snapshot API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def create(
        self,
        sandbox_id: str,
        name: str | None = None,
        with_memory: bool = False,
    ) -> Snapshot:
        """Create a snapshot from a sandbox.

        Args:
            sandbox_id: Sandbox ID
            name: Optional snapshot name
            with_memory: Whether to include memory in snapshot
        Returns:
            Created snapshot
        """
        data: dict[str, Any] = {"withMemory": with_memory}
        if name:
            data["name"] = name

        response = self.client.post(
            f"/v1/sandboxes/{sandbox_id}/snapshots",
            json=data,
        )
        return Snapshot(**response.json())

    def list_all(
        self,
        sandbox_id: str | None = None,
        workspace_id: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> list[Snapshot]:
        """List all snapshots for the current user.

        Args:
            sandbox_id: Optional sandbox ID filter
            workspace_id: Optional workspace ID filter
            page: Page number (default: 1)
            limit: Items per page (default: 100)

        Returns:
            List of snapshots
        """
        params: dict[str, Any] = {"page": page, "limit": limit}
        if sandbox_id:
            params["sandboxId"] = sandbox_id
        if workspace_id:
            params["workspaceId"] = workspace_id

        response = self.client.get("/v1/snapshots/", params=params)
        data = response.json()

        # Handle paginated response: { snapshots: [...], total, page, limit }
        if isinstance(data, dict) and "snapshots" in data:
            return [Snapshot(**item) for item in data["snapshots"]]

        # Handle direct list response (fallback)
        if isinstance(data, list):
            return [Snapshot(**item) for item in data]

        return []

    def get(self, snapshot_id: str) -> Snapshot:
        """Get snapshot details.

        Args:
            snapshot_id: Snapshot ID

        Returns:
            Snapshot details
        """
        response = self.client.get(f"/v1/snapshots/{snapshot_id}")
        return Snapshot(**response.json())

    def update(self, snapshot_id: str, data: dict[str, Any]) -> Snapshot:
        """Update snapshot.

        Args:
            snapshot_id: Snapshot ID
            data: Update data

        Returns:
            Updated snapshot
        """
        response = self.client.put(f"/v1/snapshots/{snapshot_id}", json=data)
        return Snapshot(**response.json())

    def delete(self, snapshot_id: str) -> None:
        """Delete a snapshot.

        Args:
            snapshot_id: Snapshot ID
        """
        self.client.delete(f"/v1/snapshots/{snapshot_id}")

    def restore(self, snapshot_id: str, name: str | None = None) -> Sandbox:
        """Restore a sandbox from a snapshot.

        Args:
            snapshot_id: Snapshot ID or name
            name: Optional name for restored sandbox

        Returns:
            Created sandbox
        """
        payload: dict[str, Any] = {}
        if name:
            payload["name"] = name
        response = self.client.post(f"/v1/snapshots/{snapshot_id}/restore", json=payload)
        return Sandbox(**response.json())

    def wait_for_status(
        self,
        snapshot_id: str,
        desired_status: str = "completed",
        timeout: float = 300.0,
        interval: float = 1.0,
    ) -> Snapshot:
        """Wait for snapshot to reach desired status.

        Args:
            snapshot_id: Snapshot ID
            desired_status: Desired status (default: completed)
            timeout: Maximum wait time in seconds
            interval: Poll interval in seconds

        Returns:
            Snapshot when desired status is reached

        Raises:
            TimeoutError: If timeout is reached
        """
        import time

        start = time.time()
        while time.time() - start < timeout:
            snapshot = self.get(snapshot_id)
            if snapshot.status == desired_status:
                return snapshot
            if snapshot.status == "failed":
                raise RuntimeError(f"Snapshot {snapshot_id} failed")
            time.sleep(interval)

        raise TimeoutError(f"Timeout waiting for snapshot {snapshot_id} to complete")
