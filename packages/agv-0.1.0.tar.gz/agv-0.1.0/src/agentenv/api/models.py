"""API models for AgentEnv Cloud."""

from datetime import datetime
from typing import Any
from pydantic import BaseModel, ConfigDict, Field, field_validator

# =============================================================================
# Sandbox Models
# =============================================================================

class SecretRef(BaseModel):
    """Secret reference for sandbox environment variable injection."""

    secret_id: str
    env_name: str


class VolumeMount(BaseModel):
    """Volume mount for sandbox."""

    name: str
    mount_path: str
    read_only: bool = False


class SandboxConfig(BaseModel):
    """Sandbox configuration."""

    model_config = {"populate_by_name": True}

    image: str
    cpu_millis: int | None = Field(default=None, alias="cpuMillis")
    memory_mb: int | None = Field(default=None, alias="memoryMb")
    gpu_count: int = Field(default=0, alias="gpuCount")
    gpu_type: str | None = Field(default=None, alias="gpuType")
    max_lifetime_seconds: int | None = Field(default=None, alias="maxLifetimeSeconds")
    env: dict[str, str] = Field(default_factory=dict)
    args: list[str] = Field(default_factory=list)
    secret_refs: list[SecretRef] = Field(default_factory=list, alias="secretRefs")
    volume_mounts: list[VolumeMount] = Field(default_factory=list, alias="volumeMounts")


class PortMapping(BaseModel):
    """Port mapping for sandbox."""

    model_config = {"populate_by_name": True}

    host_port: int = Field(alias="hostPort")
    container_port: int = Field(alias="containerPort")
    protocol: str = "tcp"
    public_url: str | None = Field(default=None, alias="publicUrl")


class SandboxMetadata(BaseModel):
    """Sandbox metadata."""

    model_config = {"populate_by_name": True}

    created_at: datetime = Field(alias="createdAt")
    started_at: datetime | None = Field(default=None, alias="startedAt")
    stopped_at: datetime | None = Field(default=None, alias="stoppedAt")
    ip_address: str | None = Field(default=None, alias="ipAddress")
    port_mappings: list[PortMapping] = Field(default_factory=list, alias="portMappings")


class Sandbox(BaseModel):
    """Sandbox resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    description: str | None = None
    status: str  # pending, running, stopped, failed, terminated
    container_id: str | None = Field(default=None, alias="containerId")
    hypervisor_id: str | None = Field(default=None, alias="hypervisorId")
    task_id: str | None = Field(default=None, alias="taskId")
    workspace_id: str = Field(alias="workspaceId")
    config: SandboxConfig
    metadata: SandboxMetadata
    max_lifetime_seconds: int | None = Field(default=None, alias="maxLifetimeSeconds")
    progress: int | None = None
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class SandboxExecResult(BaseModel):
    """Sandbox command execution result."""

    model_config = {"populate_by_name": True}

    exec_id: str = Field(alias="execId")
    output: str
    exit_code: int = Field(alias="exitCode")


class CreateSandboxRequest(BaseModel):
    """Request to create a sandbox."""

    model_config = {"populate_by_name": True}

    workspace_id: str | None = Field(default=None, alias="workspaceId")
    name: str | None = None
    description: str | None = None
    image: str
    snapshot_id: str | None = Field(default=None, alias="snapshotId")
    cpu_millis: int | None = Field(default=None, alias="cpuMillis")
    memory_mb: int | None = Field(default=None, alias="memoryMb")
    gpu_count: int = Field(default=0, alias="gpuCount")
    gpu_type: str | None = Field(default=None, alias="gpuType")
    env: dict[str, str] = Field(default_factory=dict)
    args: list[str] = Field(default_factory=list)
    max_lifetime_seconds: int | None = Field(default=None, alias="maxLifetimeSeconds")
    allowed_regions: list[str] = Field(default_factory=list, alias="allowedRegions")
    secret_refs: list[SecretRef] = Field(default_factory=list, alias="secretRefs")
    volume_mounts: list[VolumeMount] = Field(default_factory=list, alias="volumeMounts")


class ExposePortRequest(BaseModel):
    """Request to expose a port."""

    model_config = {"populate_by_name": True}

    container_port: int = Field(alias="containerPort")
    port_type: str = Field(default="tcp", alias="portType")  # tcp, http, ws


# =============================================================================
# Snapshot Models
# =============================================================================

class Snapshot(BaseModel):
    """Snapshot resource."""

    model_config = {"populate_by_name": True}

    id: str
    sandbox_id: str = Field(alias="sandboxId")
    status: str  # pending, in_progress, completed, failed, deleting
    progress: int | None = None
    size_bytes: int | None = Field(default=None, alias="sizeBytes")
    snapshot_path: str | None = Field(default=None, alias="snapshotPath")
    checksum: str | None = None
    has_memory: bool | None = Field(default=None, alias="hasMemory")
    name: str | None = None
    metadata: dict[str, Any] | None = None
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class CreateSnapshotRequest(BaseModel):
    """Request to create a snapshot."""

    model_config = {"populate_by_name": True}

    with_memory: bool = Field(default=False, alias="withMemory")
    name: str | None = None


# =============================================================================
# App Models
# =============================================================================


class AppConfig(BaseModel):
    """App configuration."""

    model_config = {"populate_by_name": True}

    container_port: int = Field(alias="containerPort")
    startup_command: str | None = Field(default=None, alias="startupCommand")
    ready_types: list[str] = Field(default_factory=list, alias="readyTypes")
    health_path: str | None = Field(default=None, alias="healthPath")
    min_replicas: int = Field(alias="minReplicas")
    max_replicas: int = Field(alias="maxReplicas")
    idle_timeout_ms: int = Field(alias="idleTimeoutMs")
    cpu_millis: int | None = Field(default=None, alias="cpuMillis")
    memory_mb: int | None = Field(default=None, alias="memoryMb")
    scale_up_cpu_pct: int | None = Field(default=None, alias="scaleUpCpuPct")
    scale_down_cpu_pct: int | None = Field(default=None, alias="scaleDownCpuPct")
    scale_up_mem_pct: int | None = Field(default=None, alias="scaleUpMemPct")
    scale_down_mem_pct: int | None = Field(default=None, alias="scaleDownMemPct")
    ready_timeout_ms: int | None = Field(default=None, alias="readyTimeoutMs")


class App(BaseModel):
    """App deployment resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    slug: str
    status: str
    current_version: str | None = Field(default=None, alias="currentVersion")
    config: AppConfig
    last_request_at: datetime | None = Field(default=None, alias="lastRequestAt")
    created_at: datetime | None = Field(default=None, alias="createdAt")
    updated_at: datetime | None = Field(default=None, alias="updatedAt")


class AppVersion(BaseModel):
    """App version."""

    model_config = {"populate_by_name": True}

    version: str
    snapshot_id: str = Field(alias="snapshotId")
    env_overrides: dict[str, str] | None = Field(default=None, alias="envOverrides")
    entrypoint_override: str | None = Field(default=None, alias="entrypointOverride")
    created_at: datetime = Field(alias="createdAt")


class CreateAppRequest(BaseModel):
    """Request to create an app."""

    model_config = {"populate_by_name": True}

    name: str
    slug: str | None = None
    container_port: int = Field(alias="containerPort")
    ready_types: list[str] = Field(default=["port_accessible"], alias="readyTypes")
    startup_command: str | None = Field(default=None, alias="startupCommand")
    health_path: str | None = Field(default=None, alias="healthPath")
    min_replicas: int = Field(default=0, alias="minReplicas")
    max_replicas: int = Field(default=1, alias="maxReplicas")
    idle_timeout_ms: int | None = Field(default=None, alias="idleTimeoutMs")
    cpu_millis: int | None = Field(default=None, alias="cpuMillis")
    memory_mb: int | None = Field(default=None, alias="memoryMb")


# =============================================================================
# Site Models
# =============================================================================


class SiteVersion(BaseModel):
    """Site version resource."""

    id: str
    version: str
    size_bytes: int = Field(alias="sizeBytes")
    file_count: int = Field(alias="fileCount")
    created_at: datetime = Field(alias="createdAt")
    is_current: bool = Field(alias="isCurrent", default=False)

    model_config = ConfigDict(populate_by_name=True)


class Site(BaseModel):
    """Site resource."""

    id: str
    slug: str
    name: str
    url: str
    current_version: str | None = Field(alias="currentVersion", default=None)
    max_versions: int = Field(alias="maxVersions", default=5)
    workspace_id: str | None = Field(alias="workspaceId", default=None)
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")
    versions: list[SiteVersion] | None = None

    model_config = ConfigDict(populate_by_name=True)


# =============================================================================
# Workflow Models
# =============================================================================


class WorkflowPosition(BaseModel):
    """Workflow canvas position."""

    x: float
    y: float


class WorkflowNode(BaseModel):
    """Workflow node definition within a workflow document."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    type: str
    name: str | None = None
    config: dict[str, Any] = Field(default_factory=dict)
    trusted: bool | None = None
    position: WorkflowPosition | None = None


class WorkflowEdge(BaseModel):
    """Workflow edge definition."""

    model_config = ConfigDict(populate_by_name=True)

    source: str
    target: str
    condition_script: str | None = Field(default=None, alias="conditionScript")


class WorkflowDefinition(BaseModel):
    """Workflow definition graph."""

    model_config = ConfigDict(populate_by_name=True)

    nodes: list[WorkflowNode] = Field(default_factory=list)
    edges: list[WorkflowEdge] = Field(default_factory=list)


class WorkflowWebhookEndpoint(BaseModel):
    """Serialized webhook endpoint exposed for a workflow."""

    model_config = ConfigDict(populate_by_name=True)

    node_id: str = Field(alias="nodeId")
    node_type: str | None = Field(default=None, alias="nodeType")
    node_name: str | None = Field(default=None, alias="nodeName")
    path: str
    relative_url: str = Field(alias="relativeUrl")
    methods: list[str] = Field(default_factory=list)
    is_active: bool = Field(alias="isActive")


class Workflow(BaseModel):
    """Workflow resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    workspace_id: str = Field(alias="workspaceId")
    name: str
    description: str | None = None
    version: int
    status: str
    definition: WorkflowDefinition
    published_definition: WorkflowDefinition | None = Field(
        default=None,
        alias="publishedDefinition",
    )
    published_at: datetime | None = Field(default=None, alias="publishedAt")
    webhook_endpoints: list[WorkflowWebhookEndpoint] = Field(
        default_factory=list,
        alias="webhookEndpoints",
    )
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class WorkflowExecution(BaseModel):
    """Workflow execution resource."""

    model_config = ConfigDict(populate_by_name=True)

    id: str
    workflow_id: str = Field(alias="workflowId")
    workflow_version: int = Field(alias="workflowVersion")
    status: str
    input: Any = None
    output: Any = None
    node_outputs: dict[str, Any] = Field(default_factory=dict, alias="nodeOutputs")
    node_errors: dict[str, Any] = Field(default_factory=dict, alias="nodeErrors")
    started_at: datetime | None = Field(default=None, alias="startedAt")
    completed_at: datetime | None = Field(default=None, alias="completedAt")
    created_at: datetime = Field(alias="createdAt")
    error: str | None = None


class WorkflowMetrics(BaseModel):
    """Aggregated execution metrics for a workflow."""

    model_config = ConfigDict(populate_by_name=True)

    total: int
    pending: int
    running: int
    completed: int
    failed: int
    success_rate: float = Field(alias="successRate")
    avg_duration_ms: int = Field(alias="avgDurationMs")


class WorkflowTimeSeriesPoint(BaseModel):
    """Time-series point for workflow executions."""

    model_config = ConfigDict(populate_by_name=True)

    timestamp: str
    count: int


class WorkflowNodeSecret(BaseModel):
    """Secret definition for a workflow node."""

    key: str
    name: str
    description: str


class WorkflowNodeSecrets(BaseModel):
    """Secret requirements for a workflow node."""

    required: list[WorkflowNodeSecret] = Field(default_factory=list)
    optional: list[WorkflowNodeSecret] = Field(default_factory=list)


class WorkflowNodeSchemas(BaseModel):
    """JSON schema bundle for a workflow node."""

    config: dict[str, Any] = Field(default_factory=dict)
    input: dict[str, Any] | None = None
    output: dict[str, Any] | None = None


class WorkflowNodeHandler(BaseModel):
    """Execution handler configuration for a workflow node."""

    type: str
    service: str | None = None
    method: str | None = None
    plugin: str | None = None


class WorkflowNodeDefinitionLight(BaseModel):
    """Lightweight workflow node definition."""

    model_config = ConfigDict(populate_by_name=True)

    type: str
    category: str
    name: str
    description: str | None = None
    icon: str | None = None
    trusted: bool = False
    is_builtin: bool = Field(default=False, alias="isBuiltin")


class WorkflowNodeDefinition(WorkflowNodeDefinitionLight):
    """Full workflow node definition."""

    schemas: WorkflowNodeSchemas
    handler: WorkflowNodeHandler
    secrets: WorkflowNodeSecrets | None = None


# =============================================================================
# Image Models
# =============================================================================

class ImageBuildStep(BaseModel):
    """Image build step."""

    type: str
    data: dict[str, Any] = Field(default_factory=dict)
    meta: dict[str, Any] | None = None


class ImageSnapshot(BaseModel):
    """Image snapshot resource."""

    model_config = {"populate_by_name": True}

    id: str
    sandbox_id: str = Field(alias="sandboxId")
    name: str
    description: str | None = None
    status: str
    workspace_id: str | None = Field(default=None, alias="workspaceId")
    build_hash: str = Field(alias="buildHash")
    base_image: str | None = Field(default=None, alias="baseImage")
    base_snapshot_id: str | None = Field(default=None, alias="baseSnapshotId")
    steps: list[ImageBuildStep] = Field(default_factory=list)
    builder_version: str | None = Field(default=None, alias="builderVersion")
    workdir: str | None = None
    env_keys: list[str] = Field(default_factory=list, alias="envKeys")
    env_hash: str | None = Field(default=None, alias="envHash")
    cache_mode: str | None = Field(default=None, alias="cacheMode")
    tags: list[str] = Field(default_factory=list)
    build_started_at: datetime | None = Field(default=None, alias="buildStartedAt")
    build_completed_at: datetime | None = Field(default=None, alias="buildCompletedAt")
    size_bytes: int | None = Field(default=None, alias="sizeBytes")
    checksum: str | None = None
    snapshot_path: str | None = Field(default=None, alias="snapshotPath")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class CreateImageRequest(BaseModel):
    """Request to create or ensure an image snapshot."""

    model_config = {"populate_by_name": True}

    sandbox_id: str = Field(alias="sandboxId")
    name: str | None = None
    description: str | None = None
    build_hash: str = Field(alias="buildHash")
    base_image: str | None = Field(default=None, alias="baseImage")
    base_snapshot_id: str | None = Field(default=None, alias="baseSnapshotId")
    steps: list[ImageBuildStep]
    builder_version: str | None = Field(default=None, alias="builderVersion")
    workdir: str | None = None
    env_keys: list[str] | None = Field(default=None, alias="envKeys")
    env_hash: str | None = Field(default=None, alias="envHash")
    cache_mode: str | None = Field(default=None, alias="cacheMode")
    tags: list[str] | None = None
    capabilities: list[str] | None = None
    force: bool | None = None


class ImageTag(BaseModel):
    """Image tag mapping."""

    model_config = {"populate_by_name": True}

    id: str
    image_id: str = Field(alias="imageId")
    workspace_id: str = Field(alias="workspaceId")
    tag: str
    created_at: datetime | None = Field(default=None, alias="createdAt")


# =============================================================================
# Browser Session Models
# =============================================================================

class GeonodeProxyConfig(BaseModel):
    """Geonode proxy configuration for browser sessions."""

    model_config = {"populate_by_name": True}

    enabled: bool = False
    mode: str | None = None
    domains: list[str] = Field(default_factory=list)


class BrowserSessionConfig(BaseModel):
    """Browser session configuration."""

    model_config = {"populate_by_name": True}

    screen_width: int | None = Field(default=None, alias="screenWidth")
    screen_height: int | None = Field(default=None, alias="screenHeight")
    enable_stealth: bool | None = Field(default=None, alias="enableStealth")
    enable_adblock: bool | None = Field(default=None, alias="enableAdblock")
    proxy_url: str | None = Field(default=None, alias="proxyUrl")
    proxy_provider: str | None = Field(default=None, alias="proxyProvider")
    proxy_type: str | None = Field(default=None, alias="proxyType")
    enable_captcha_solver: bool | None = Field(default=None, alias="enableCaptchaSolver")
    captcha_provider: str | None = Field(default=None, alias="captchaProvider")
    enable_rrweb: bool | None = Field(default=None, alias="enableRrweb")
    enable_logger: bool | None = Field(default=None, alias="enableLogger")
    profile_mode: str | None = Field(default=None, alias="profileMode")
    profile_volume_id: str | None = Field(default=None, alias="profileVolumeId")
    profile_id: str | None = Field(default=None, alias="profileId")
    geonode_proxy: GeonodeProxyConfig | None = Field(default=None, alias="geonodeProxy")


class BrowserSessionMetadata(BaseModel):
    """Browser session runtime metadata."""

    model_config = {"populate_by_name": True}

    cdp_endpoint: str | None = Field(default=None, alias="cdpEndpoint")
    cdp_port: int | None = Field(default=None, alias="cdpPort")
    cdp_host_port: int | None = Field(default=None, alias="cdpHostPort")
    vnc_endpoint: str | None = Field(default=None, alias="vncEndpoint")
    vnc_port: int | None = Field(default=None, alias="vncPort")
    vnc_token: str | None = Field(default=None, alias="vncToken")
    proxy_url: str | None = Field(default=None, alias="proxyUrl")
    started_at: datetime | None = Field(default=None, alias="startedAt")
    stopped_at: datetime | None = Field(default=None, alias="stoppedAt")
    exit_reason: str | None = Field(default=None, alias="exitReason")


class BrowserSession(BaseModel):
    """Browser session resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str | None = None
    user_id: str | None = Field(default=None, alias="userId")
    workspace_id: str | None = Field(default=None, alias="workspaceId")
    status: str  # starting, running, stopped
    sandbox_id: str | None = Field(default=None, alias="sandboxId")
    config: BrowserSessionConfig | None = None
    metadata: BrowserSessionMetadata | None = None
    cdp_url: str | None = Field(default=None, alias="cdpUrl")
    vnc_url: str | None = Field(default=None, alias="vncUrl")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime | None = Field(default=None, alias="updatedAt")
    recording_status: str | None = Field(default=None, alias="recordingStatus")
    recording_event_count: int | None = Field(default=None, alias="recordingEventCount")
    recording_s3_key: str | None = Field(default=None, alias="recordingS3Key")
    recording_started_at: datetime | None = Field(default=None, alias="recordingStartedAt")
    recording_ended_at: datetime | None = Field(default=None, alias="recordingEndedAt")


class CreateBrowserSessionRequest(BaseModel):
    """Request to create a browser session."""

    model_config = {"populate_by_name": True}

    name: str
    workspace_id: str | None = Field(default=None, alias="workspaceId")
    screen_width: int = Field(default=1280, alias="screenWidth")
    screen_height: int = Field(default=720, alias="screenHeight")
    enable_stealth: bool = Field(default=False, alias="enableStealth")
    enable_adblock: bool | None = Field(default=None, alias="enableAdblock")
    profile_mode: str = Field(default="persistent", alias="profileMode")
    proxy_url: str | None = Field(default=None, alias="proxyUrl")
    proxy_username: str | None = Field(default=None, alias="proxyUsername")
    proxy_password: str | None = Field(default=None, alias="proxyPassword")
    proxy_provider: str | None = Field(default=None, alias="proxyProvider")
    proxy_type: str | None = Field(default=None, alias="proxyType")
    enable_captcha_solver: bool | None = Field(default=None, alias="enableCaptchaSolver")
    captcha_provider: str | None = Field(default=None, alias="captchaProvider")
    captcha_api_key: str | None = Field(default=None, alias="captchaApiKey")
    enable_rrweb: bool | None = Field(default=None, alias="enableRrweb")
    enable_logger: bool | None = Field(default=None, alias="enableLogger")
    cpu_millis: int | None = Field(default=None, alias="cpuMillis")
    memory_mb: int | None = Field(default=None, alias="memoryMb")
    max_lifetime_seconds: int | None = Field(default=None, alias="maxLifetimeSeconds")
    gpu_type: str | None = Field(default=None, alias="gpuType")
    profile_id: str | None = Field(default=None, alias="profileId")
    geonode_proxy: GeonodeProxyConfig | None = Field(default=None, alias="geonodeProxy")


# =============================================================================
# Notebook Session Models
# =============================================================================

class NotebookSession(BaseModel):
    """Notebook session resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str | None = None
    user_id: str | None = Field(default=None, alias="userId")
    workspace_id: str | None = Field(default=None, alias="workspaceId")
    status: str
    sandbox_id: str | None = Field(default=None, alias="sandboxId")
    notebook_url: str | None = Field(default=None, alias="notebookUrl")
    config: dict[str, Any] | None = None
    metadata: dict[str, Any] | None = None
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime | None = Field(default=None, alias="updatedAt")


class NotebookCollaborator(BaseModel):
    """Notebook collaborator presence record."""

    model_config = {"populate_by_name": True}

    notebook_id: str = Field(alias="notebookId")
    session_id: str = Field(alias="sessionId")
    user_id: str = Field(alias="userId")
    user_data: dict[str, Any] | None = Field(default=None, alias="userData")
    last_heartbeat: datetime = Field(alias="lastHeartbeat")


class CreateNotebookSessionRequest(BaseModel):
    """Request to create a notebook session."""

    model_config = {"populate_by_name": True}

    name: str
    workspace_id: str = Field(alias="workspaceId")
    image: str | None = None
    snapshot_id: str | None = Field(default=None, alias="snapshotId")
    cpu_millis: int | None = Field(default=None, alias="cpuMillis")
    memory_mb: int | None = Field(default=None, alias="memoryMb")
    gpu_count: int | None = Field(default=None, alias="gpuCount")
    gpu_type: str | None = Field(default=None, alias="gpuType")
    storage_mode: str | None = Field(default=None, alias="storageMode")
    env: dict[str, str] | None = None
    idle_ttl_seconds: int | None = Field(default=None, alias="idleTtlSeconds")
    snapshot_favor: str | None = Field(default=None, alias="snapshotFavor")
    persistent: bool | None = None
    hard_kill_at: str | None = Field(default=None, alias="hardKillAt")
    hard_kill_after_seconds: int | None = Field(default=None, alias="hardKillAfterSeconds")


# =============================================================================
# Notebook Document Models
# =============================================================================


class NotebookDocumentMetadata(BaseModel):
    """Notebook document metadata."""

    model_config = {"populate_by_name": True, "extra": "allow"}

    kernel: str | None = None
    runtime: str | None = None
    last_saved_at: datetime | None = Field(default=None, alias="lastSavedAt")
    auto_save_enabled: bool | None = Field(default=None, alias="autoSaveEnabled")
    image: str | None = None
    version: int | None = None
    collaborator_count: int | None = Field(default=None, alias="collaboratorCount")
    kernel_session_id: str | None = Field(default=None, alias="kernelSessionId")


class NotebookDocument(BaseModel):
    """Notebook document resource."""

    model_config = {"populate_by_name": True}

    id: str
    workspace_id: str = Field(alias="workspaceId")
    name: str
    description: str | None = None
    file_path: str = Field(alias="filePath")
    metadata: NotebookDocumentMetadata | None = None
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


# =============================================================================
# Notebook Cell Models
# =============================================================================


class CellOutput(BaseModel):
    """Notebook cell output."""

    model_config = {"populate_by_name": True}

    output_type: str = Field(alias="outputType")  # stream, execute_result, display_data, error
    text: str | None = None
    data: dict[str, Any] | None = None
    name: str | None = None  # stdout, stderr (for stream)
    ename: str | None = None  # error name
    evalue: str | None = None  # error value
    traceback: list[str] | None = None
    execution_count: int | None = Field(default=None, alias="executionCount")

    @field_validator("text", mode="before")
    @classmethod
    def normalize_stream_text(cls, value: Any) -> Any:
        """Imported notebook outputs may encode stream text as a list of chunks."""
        if isinstance(value, list):
            return "".join(str(part) for part in value)
        return value


class NotebookCell(BaseModel):
    """Notebook cell resource."""

    model_config = {"populate_by_name": True}

    id: str
    notebook_id: str = Field(alias="notebookId")
    cell_index: int = Field(alias="cellIndex")
    cell_type: str = Field(alias="cellType")  # code, markdown, raw
    source: str
    source_ot_version: int = Field(alias="sourceOtVersion")
    metadata: dict[str, Any] | None = None
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime = Field(alias="updatedAt")


class NotebookCellDetail(NotebookCell):
    """Notebook cell with outputs and execution info."""

    outputs: list[CellOutput] = Field(default_factory=list)
    execution_count: int | None = Field(default=None, alias="executionCount")
    status: str | None = None  # ok, running, error
    last_run_at: int | None = Field(default=None, alias="lastRunAt")
    last_run_duration: float | None = Field(default=None, alias="lastRunDuration")


class ExecutionResult(BaseModel):
    """Cell execution result."""

    model_config = {"populate_by_name": True}

    execution_id: str = Field(alias="executionId")
    status: str  # queued, started, completed, failed
    message: str | None = None


# =============================================================================
# Workspace Models
# =============================================================================

class WorkspaceMember(BaseModel):
    """Workspace member."""

    model_config = {"populate_by_name": True}

    user_id: str = Field(alias="userId")
    email: str
    role: str  # owner, member
    joined_at: datetime = Field(alias="joinedAt")


class Workspace(BaseModel):
    """Workspace resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    owner_id: str = Field(alias="ownerId")
    created_at: datetime = Field(alias="createdAt")


class WorkspaceDetail(Workspace):
    """Detailed workspace information."""

    members: list[WorkspaceMember] = Field(default_factory=list)


class CreateWorkspaceRequest(BaseModel):
    """Request to create a workspace."""

    name: str


class InviteMemberRequest(BaseModel):
    """Request to invite a member."""

    identifier: str


# =============================================================================
# Billing Models
# =============================================================================

class Transaction(BaseModel):
    """Transaction record."""

    model_config = {"populate_by_name": True}

    id: str
    amount_cents: int = Field(alias="amountCents")
    amount_usd: float = Field(alias="amountUsd")
    description: str
    created_at: datetime = Field(alias="createdAt")


class BalanceInfo(BaseModel):
    """Account balance information."""

    model_config = {"populate_by_name": True}

    balance_cents: int = Field(alias="balanceCents")
    balance_usd: float = Field(alias="balanceUsd")


# =============================================================================
# File Storage Models
# =============================================================================

class FileMetadata(BaseModel):
    """File metadata."""

    model_config = {"populate_by_name": True}

    name: str
    path: str
    size_bytes: int = Field(alias="sizeBytes")
    mime_type: str = Field(alias="mimeType")
    created_at: datetime = Field(alias="createdAt")
    modified_at: datetime = Field(alias="modifiedAt")
    checksum: str | None = None
    is_directory: bool = Field(default=False, alias="isDirectory")


# =============================================================================
# Auth Models
# =============================================================================

class APIKey(BaseModel):
    """API key resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str | None = None
    key: str | None = Field(default=None, alias="apiKey")  # Only shown on creation
    created_at: datetime = Field(alias="createdAt")
    last_used: datetime | None = Field(default=None, alias="lastUsedAt")


class CreateAPIKeyRequest(BaseModel):
    """Request to create an API key."""

    name: str


class UserProfile(BaseModel):
    """User profile."""

    model_config = {"populate_by_name": True}

    id: str = Field(alias="userId")
    email: str | None = None
    username: str
    roles: list[str] = Field(default_factory=list)
    permissions: list[str] | None = Field(default=None)
    last_login_at: datetime | None = Field(default=None, alias="lastLoginAt")
    email_verified: bool | None = Field(default=None, alias="emailVerified")
    totp_enabled: bool | None = Field(default=None, alias="totpEnabled")
    selected_workspace_id: str | None = Field(default=None, alias="selectedWorkspaceId")


class LoginResponse(BaseModel):
    """Response from login."""

    model_config = {"populate_by_name": True}

    access_token: str = Field(alias="accessToken")
    refresh_token: str = Field(alias="refreshToken")
    user: UserProfile


class RefreshTokenRequest(BaseModel):
    """Request to refresh token."""

    refresh_token: str


# =============================================================================
# Error Models
# =============================================================================

class APIError(Exception):
    """API error response."""

    def __init__(self, status_code: int, message: str, details: dict[str, Any] | None = None):
        self.status_code = status_code
        self.message = message
        self.details = details or {}
        super().__init__(self.message)

    def __str__(self) -> str:
        return f"API Error {self.status_code}: {self.message}"


# =============================================================================
# Health Models
# =============================================================================

class HealthStatus(BaseModel):
    """Health check response."""

    status: str
    version: str | None = None


# =============================================================================
# AI Gateway Models
# =============================================================================

class GatewayUpstream(BaseModel):
    """AI Gateway upstream provider configuration."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    provider: str
    base_url: str | None = Field(default=None, alias="baseUrl")
    is_active: bool = Field(default=True, alias="isActive")
    rate_limit_rpm: int | None = Field(default=None, alias="rateLimitRpm")
    rate_limit_tpm: int | None = Field(default=None, alias="rateLimitTpm")
    priority: int = Field(default=0)
    weight: int = Field(default=1)
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime | None = Field(default=None, alias="updatedAt")


class PoolMember(BaseModel):
    """Pool member (upstream in a pool)."""

    model_config = {"populate_by_name": True}

    upstream_id: str = Field(alias="upstreamId")
    priority: int = Field(default=0)
    weight: int = Field(default=1)


class GatewayPool(BaseModel):
    """AI Gateway load balancing pool."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    strategy: str = "round-robin"  # round-robin, least-used, intelligent
    members: list[PoolMember] = Field(default_factory=list)
    model_mappings: dict[str, str] = Field(default_factory=dict, alias="modelMappings")
    created_at: datetime = Field(alias="createdAt")
    updated_at: datetime | None = Field(default=None, alias="updatedAt")


class GatewayApiKey(BaseModel):
    """AI Gateway API key."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    key: str | None = None  # Only shown on creation
    key_hash: str | None = Field(default=None, alias="keyHash")
    daily_limit: float | None = Field(default=None, alias="dailyLimitUsd")
    monthly_limit: float | None = Field(default=None, alias="monthlyLimitUsd")
    total_limit: float | None = Field(default=None, alias="totalLimitUsd")
    is_active: bool = Field(default=True, alias="isActive")
    allowed_models: list[str] = Field(default_factory=list, alias="allowedModels")
    blocked_models: list[str] = Field(default_factory=list, alias="blockedModels")
    allowed_providers: list[str] = Field(default_factory=list, alias="allowedProviders")
    created_at: datetime = Field(alias="createdAt")


class CreateGatewayApiKeyRequest(BaseModel):
    """Request to create API key."""

    model_config = {"populate_by_name": True}

    name: str
    daily_limit: float | None = Field(default=None, alias="dailyLimitUsd")
    monthly_limit: float | None = Field(default=None, alias="monthlyLimitUsd")
    total_limit: float | None = Field(default=None, alias="totalLimitUsd")
    allowed_models: list[str] | None = Field(default=None, alias="allowedModels")
    blocked_models: list[str] | None = Field(default=None, alias="blockedModels")
    allowed_providers: list[str] | None = Field(default=None, alias="allowedProviders")


class GatewayUsageRecord(BaseModel):
    """Individual usage record."""

    model_config = {"populate_by_name": True}

    id: str
    upstream_id: str = Field(alias="upstreamId")
    model: str
    prompt_tokens: int = Field(alias="promptTokens")
    completion_tokens: int = Field(alias="completionTokens")
    total_tokens: int = Field(alias="totalTokens")
    cost_usd: float = Field(alias="costUsd")
    created_at: datetime = Field(alias="createdAt")


class GatewayUsageReport(BaseModel):
    """Usage report aggregate."""

    model_config = {"populate_by_name": True}

    total_requests: int = Field(alias="totalRequests")
    total_tokens: int = Field(alias="totalTokens")
    total_cost_usd: float = Field(alias="totalCostUsd")
    records: list[GatewayUsageRecord] = Field(default_factory=list)


# Chat Completion Models (OpenAI-compatible)

class Message(BaseModel):
    """Chat message."""

    model_config = {"populate_by_name": True}

    role: str  # system, user, assistant, tool
    content: str
    name: str | None = None


class Choice(BaseModel):
    """Completion choice."""

    model_config = {"populate_by_name": True}

    index: int
    message: Message | None = None
    delta: Message | None = None  # For streaming
    finish_reason: str | None = Field(default=None, alias="finishReason")


class Usage(BaseModel):
    """Token usage."""

    model_config = {"populate_by_name": True}

    prompt_tokens: int = Field(alias="promptTokens")
    completion_tokens: int = Field(alias="completionTokens")
    total_tokens: int = Field(alias="totalTokens")


class ChatCompletionRequest(BaseModel):
    """Chat completion request (OpenAI-compatible)."""

    model_config = {"populate_by_name": True}

    model: str
    messages: list[Message]
    temperature: float | None = 1.0
    max_tokens: int | None = Field(default=None, alias="maxTokens")
    stream: bool = False
    top_p: float | None = Field(default=None, alias="topP")
    stop: str | list[str] | None = None
    presence_penalty: float | None = Field(default=None, alias="presencePenalty")
    frequency_penalty: float | None = Field(default=None, alias="frequencyPenalty")


class ChatCompletionResponse(BaseModel):
    """Chat completion response."""

    model_config = {"populate_by_name": True}

    id: str
    object: str = "chat.completion"
    created: int
    model: str
    choices: list[Choice]
    usage: Usage | None = None


class ChatCompletionChunk(BaseModel):
    """Streaming chat completion chunk."""

    model_config = {"populate_by_name": True}

    id: str
    object: str = "chat.completion.chunk"
    created: int
    model: str
    choices: list[Choice]


# Embedding Models

class EmbeddingRequest(BaseModel):
    """Embedding request."""

    model_config = {"populate_by_name": True}

    model: str
    input: str | list[str]
    encoding_format: str = Field(default="float", alias="encodingFormat")


class Embedding(BaseModel):
    """Single embedding result."""

    object: str = "embedding"
    embedding: list[float]
    index: int


class EmbeddingResponse(BaseModel):
    """Embedding response."""

    model_config = {"populate_by_name": True}

    object: str = "list"
    data: list[Embedding]
    model: str
    usage: Usage


# =============================================================================
# Analytics Models
# =============================================================================

class AnalyticsInstallation(BaseModel):
    """Analytics installation resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    api_key: str = Field(alias="apiKey")
    is_active: bool = Field(alias="isActive")
    allowed_domains: list[str] = Field(default_factory=list, alias="allowedDomains")
    settings: dict[str, Any] = Field(default_factory=dict)
    created_at: datetime = Field(alias="createdAt")


class AnalyticsFunnelStep(BaseModel):
    """Funnel step definition."""

    model_config = {"populate_by_name": True}

    name: str
    event_name: str = Field(alias="eventName")
    properties: dict[str, Any] | None = None


class AnalyticsFunnel(BaseModel):
    """Analytics funnel resource."""

    model_config = {"populate_by_name": True}

    id: str
    name: str
    steps: list[AnalyticsFunnelStep]
    is_active: bool = Field(alias="isActive")
    created_at: datetime = Field(alias="createdAt")


class AnalyticsUserProfile(BaseModel):
    """Analytics user profile."""

    model_config = {"populate_by_name": True}

    id: str
    fingerprint: str
    user_id: str | None = Field(default=None, alias="userId")
    email: str | None = None
    name: str | None = None
    traits: dict[str, Any] = Field(default_factory=dict)
    session_count: int = Field(alias="sessionCount")
    first_seen_at: datetime | None = Field(default=None, alias="firstSeenAt")
    last_seen_at: datetime | None = Field(default=None, alias="lastSeenAt")


class AnalyticsEvent(BaseModel):
    """Analytics event."""

    model_config = {"populate_by_name": True}

    id: str
    event_name: str = Field(alias="eventName")
    fingerprint: str
    session_id: str | None = Field(default=None, alias="sessionId")
    properties: dict[str, Any] = Field(default_factory=dict)
    timestamp: datetime
    url: str | None = None


class CreateAnalyticsInstallationRequest(BaseModel):
    """Request to create analytics installation."""

    model_config = {"populate_by_name": True}

    name: str
    allowed_domains: list[str] | None = Field(default=None, alias="allowedDomains")
    settings: dict[str, Any] | None = None


class CreateAnalyticsFunnelRequest(BaseModel):
    """Request to create analytics funnel."""

    model_config = {"populate_by_name": True}

    name: str
    steps: list[AnalyticsFunnelStep]
