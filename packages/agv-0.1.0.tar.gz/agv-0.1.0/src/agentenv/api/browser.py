"""Browser session API client."""

from uuid import uuid4
from typing import Any

from .client import Client
from .models import BrowserSession


class BrowserAPI:
    """API client for browser sessions."""

    def __init__(self, client: Client):
        """Initialize browser API client.

        Args:
            client: HTTP client instance
        """
        self.client = client

    def create(
        self,
        name: str | None = None,
        workspace_id: str | None = None,
        screen_width: int | None = None,
        screen_height: int | None = None,
        enable_stealth: bool = False,
        enable_adblock: bool | None = None,
        profile_mode: str = "persistent",
        proxy_url: str | None = None,
        proxy_username: str | None = None,
        proxy_password: str | None = None,
        proxy_provider: str | None = None,
        proxy_type: str | None = None,
        enable_captcha_solver: bool | None = None,
        captcha_provider: str | None = None,
        captcha_api_key: str | None = None,
        enable_rrweb: bool | None = None,
        enable_logger: bool | None = None,
        cpu_millis: int | None = None,
        memory_mb: int | None = None,
        max_lifetime_seconds: int | None = None,
        gpu_type: str | None = None,
        profile_id: str | None = None,
        geonode_proxy: dict[str, Any] | None = None,
        width: int | None = None,
        height: int | None = None,
    ) -> BrowserSession:
        """Create a new browser session.

        Args:
            name: Session name (defaults to browser-<id>)
            workspace_id: Optional workspace ID
            screen_width: Screen width
            screen_height: Screen height
            enable_stealth: Enable stealth mode
            profile_mode: Profile mode (persistent, ephemeral)

        Returns:
            Created browser session
        """
        resolved_profile_mode = "ephemeral" if profile_mode == "incognito" else profile_mode
        resolved_screen_width = screen_width if screen_width is not None else width if width is not None else 1280
        resolved_screen_height = screen_height if screen_height is not None else height if height is not None else 720
        data: dict[str, Any] = {
            "name": name or f"browser-{uuid4().hex[:8]}",
            "screenWidth": resolved_screen_width,
            "screenHeight": resolved_screen_height,
            "enableStealth": enable_stealth,
            "profileMode": resolved_profile_mode,
        }
        if workspace_id:
            data["workspaceId"] = workspace_id
        if enable_adblock is not None:
            data["enableAdblock"] = enable_adblock
        if proxy_url:
            data["proxyUrl"] = proxy_url
        if proxy_username:
            data["proxyUsername"] = proxy_username
        if proxy_password:
            data["proxyPassword"] = proxy_password
        if proxy_provider:
            data["proxyProvider"] = proxy_provider
        if proxy_type:
            data["proxyType"] = proxy_type
        if enable_captcha_solver is not None:
            data["enableCaptchaSolver"] = enable_captcha_solver
        if captcha_provider:
            data["captchaProvider"] = captcha_provider
        if captcha_api_key:
            data["captchaApiKey"] = captcha_api_key
        if enable_rrweb is not None:
            data["enableRrweb"] = enable_rrweb
        if enable_logger is not None:
            data["enableLogger"] = enable_logger
        if cpu_millis is not None:
            data["cpuMillis"] = cpu_millis
        if memory_mb is not None:
            data["memoryMb"] = memory_mb
        if max_lifetime_seconds is not None:
            data["maxLifetimeSeconds"] = max_lifetime_seconds
        if gpu_type:
            data["gpuType"] = gpu_type
        if profile_id:
            data["profileId"] = profile_id
        if geonode_proxy is not None:
            data["geonodeProxy"] = geonode_proxy

        response = self.client.post("/v1/browser/sessions", json=data)
        return BrowserSession(**response.json())

    def list_all(self, workspace_id: str | None = None) -> list[BrowserSession]:
        """List all browser sessions.

        Returns:
            List of browser sessions
        """
        params = {"workspaceId": workspace_id} if workspace_id else None
        response = self.client.get("/v1/browser/sessions", params=params)
        return [BrowserSession(**item) for item in response.json()]

    def get(self, session_id: str) -> BrowserSession:
        """Get browser session details.

        Args:
            session_id: Session ID

        Returns:
            Browser session details
        """
        response = self.client.get(f"/v1/browser/sessions/{session_id}")
        return BrowserSession(**response.json())

    def stop(self, session_id: str) -> BrowserSession:
        """Stop a browser session.

        Args:
            session_id: Session ID

        Returns:
            Stopped session
        """
        response = self.client.put(f"/v1/browser/sessions/{session_id}/stop")
        return BrowserSession(**response.json())

    def delete(self, session_id: str) -> None:
        """Delete a browser session.

        Args:
            session_id: Session ID
        """
        self.client.delete(f"/v1/browser/sessions/{session_id}")

    def get_cdp_url(self, session_id: str) -> str:
        """Get Chrome DevTools Protocol URL for a session.

        Args:
            session_id: Session ID

        Returns:
            CDP WebSocket URL
        """
        response = self.client.get(f"/v1/browser/sessions/{session_id}/cdp-url")
        data = response.json()
        return data.get("cdpUrl", "")

    def get_vnc_url(self, session_id: str) -> str:
        """Get VNC URL for a session.

        Args:
            session_id: Session ID

        Returns:
            VNC WebSocket URL
        """
        response = self.client.get(f"/v1/browser/sessions/{session_id}/vnc-url")
        data = response.json()
        return data.get("vncUrl", "")

    def wait_for_status(
        self,
        session_id: str,
        desired_status: str = "running",
        timeout: float = 60.0,
        interval: float = 0.5,
    ) -> BrowserSession:
        """Wait for browser session to reach desired status.

        Args:
            session_id: Session ID
            desired_status: Desired status (default: running)
            timeout: Maximum wait time in seconds
            interval: Poll interval in seconds

        Returns:
            Session when desired status is reached

        Raises:
            TimeoutError: If timeout is reached
        """
        import time

        start = time.time()
        while time.time() - start < timeout:
            session = self.get(session_id)
            if session.status == desired_status:
                return session
            if session.status == "stopped":
                raise RuntimeError(f"Browser session {session_id} stopped")
            time.sleep(interval)

        raise TimeoutError(f"Timeout waiting for browser session {session_id} to start")
