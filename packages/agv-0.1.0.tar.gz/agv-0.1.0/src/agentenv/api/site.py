"""Site API client."""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING, Any

from .models import Site, SiteVersion

if TYPE_CHECKING:
    from .client import Client


class SiteAPI:
    """API client for site resources."""

    def __init__(self, client: Client) -> None:
        self.client = client

    def create(self, name: str, slug: str | None = None, workspace_id: str | None = None) -> Site:
        """Create a new site.

        Args:
            name: Display name for the site
            slug: Custom slug (optional, auto-generated if not provided)
            workspace_id: Workspace ID (optional)

        Returns:
            Created site
        """
        data: dict[str, Any] = {"name": name}
        if slug:
            data["slug"] = slug
        if workspace_id:
            data["workspaceId"] = workspace_id
        response = self.client.post("/v1/sites", json=data)
        return Site(**response.json())

    def list_all(self, workspace_id: str | None = None) -> list[Site]:
        """List all sites.

        Args:
            workspace_id: Filter by workspace ID (optional)

        Returns:
            List of sites
        """
        params: dict[str, Any] = {}
        if workspace_id:
            params["workspaceId"] = workspace_id
        response = self.client.get("/v1/sites", params=params)
        data = response.json()
        return [Site(**item) for item in data] if isinstance(data, list) else []

    def get(self, site_id: str) -> Site:
        """Get a site by ID.

        Args:
            site_id: Site ID

        Returns:
            Site details
        """
        response = self.client.get(f"/v1/sites/{site_id}")
        return Site(**response.json())

    def get_by_slug(self, slug: str) -> Site | None:
        """Get a site by slug.

        Args:
            slug: Site slug

        Returns:
            Site if found, None otherwise
        """
        sites = self.list_all()
        for site in sites:
            if site.slug == slug:
                return self.get(site.id)
        return None

    def update(
        self,
        site_id: str,
        name: str | None = None,
        slug: str | None = None,
        max_versions: int | None = None,
    ) -> Site:
        """Update a site.

        Args:
            site_id: Site ID
            name: New display name (optional)
            slug: New slug (optional)
            max_versions: New max versions limit (optional)

        Returns:
            Updated site
        """
        data: dict[str, Any] = {}
        if name:
            data["name"] = name
        if slug:
            data["slug"] = slug
        if max_versions is not None:
            data["maxVersions"] = max_versions
        response = self.client.patch(f"/v1/sites/{site_id}", json=data)
        return Site(**response.json())

    def delete(self, site_id: str) -> None:
        """Delete a site.

        Args:
            site_id: Site ID
        """
        self.client.delete(f"/v1/sites/{site_id}")

    def check_slug(self, slug: str) -> bool:
        """Check if a slug is available.

        Args:
            slug: Slug to check

        Returns:
            True if available, False otherwise
        """
        response = self.client.get(f"/v1/sites/check-slug/{slug}")
        return response.json().get("available", False)

    def deploy(self, site_id: str, zip_path: Path) -> Site:
        """Deploy files to a site.

        Args:
            site_id: Site ID
            zip_path: Path to zip file containing site files

        Returns:
            Updated site with new version
        """
        with open(zip_path, "rb") as f:
            files = {"file": (zip_path.name, f, "application/zip")}
            response = self.client.post(f"/v1/sites/{site_id}/deploy", files=files)
        return Site(**response.json())

    def get_versions(self, site_id: str) -> list[SiteVersion]:
        """Get all versions for a site.

        Args:
            site_id: Site ID

        Returns:
            List of site versions
        """
        response = self.client.get(f"/v1/sites/{site_id}/versions")
        data = response.json()
        return [SiteVersion(**item) for item in data] if isinstance(data, list) else []

    def rollback(self, site_id: str, version: str) -> Site:
        """Rollback a site to a previous version.

        Args:
            site_id: Site ID
            version: Version hash to rollback to

        Returns:
            Updated site
        """
        response = self.client.post(f"/v1/sites/{site_id}/rollback", json={"version": version})
        return Site(**response.json())

    def delete_version(self, site_id: str, version: str) -> None:
        """Delete a specific version.

        Args:
            site_id: Site ID
            version: Version hash to delete
        """
        self.client.delete(f"/v1/sites/{site_id}/versions/{version}")
