"""Python SDK for AgentEnv Cloud.

Usage:
    import agentenv as av

    # Initialize client
    client = av.Client(api_key="sk_live_xxxxx")

    # Create sandbox
    sandbox = client.sandbox.create(image="python:3.11", cpu=2000, memory=4096)

    # Wait for it to start
    sandbox.wait_for_status("running")

    # Get logs
    logs = sandbox.logs()

    # Expose port
    mapping = sandbox.expose_port(8080, "http")
"""

from typing import Any, Optional

from ..api.client import Client as _Client
from ..api.models import (
    Sandbox,
    Snapshot,
    ImageSnapshot,
    ImageTag,
    BrowserSession,
    NotebookCell,
    NotebookCellDetail,
    NotebookDocument,
    ExecutionResult,
    NotebookSession,
    Workspace,
)
from ..config.settings import get_settings
from .function import function, RemoteFunctionError
from .ai import AIClient, ChatCompletions, Embeddings, ManagementAPI


class Client:
    """AgentEnv Cloud Python SDK client."""

    def __init__(
        self,
        api_key: str | None = None,
        api_url: str | None = None,
        access_token: str | None = None,
    ):
        """Initialize AgentEnv client.

        Args:
            api_key: API key for authentication
            api_url: API server URL (default: from settings or http://localhost:3000)
            access_token: JWT access token
        """
        settings = get_settings()

        if api_url:
            settings.api_url = api_url
        if api_key:
            settings.api_key = api_key
        if access_token:
            settings.access_token = access_token

        self._client = _Client(
            base_url=settings.api_url,
            api_key=settings.api_key,
            access_token=settings.access_token,
        )
        self._api_url = settings.api_url

    @property
    def sandbox(self) -> "SandboxAPI":
        """Sandbox operations."""
        return SandboxAPI(self._client)

    @property
    def snapshot(self) -> "SnapshotAPI":
        """Snapshot operations."""
        return SnapshotAPI(self._client)

    @property
    def image(self) -> "ImageAPI":
        """Image snapshot operations."""
        return ImageAPI(self._client)

    @property
    def browser(self) -> "BrowserAPI":
        """Browser session operations."""
        return BrowserAPI(self._client)

    @property
    def notebook(self) -> "NotebookAPI":
        """Notebook session operations."""
        return NotebookAPI(self._client)

    @property
    def workspace(self) -> "WorkspaceAPI":
        """Workspace operations."""
        return WorkspaceAPI(self._client)

    @property
    def billing(self) -> "BillingAPI":
        """Billing operations."""
        return BillingAPI(self._client)

    @property
    def analytics(self):
        """Analytics operations."""
        return AnalyticsAPIWrapper(self._client)

    def close(self) -> None:
        """Close the HTTP client."""
        self._client.close()

    def __enter__(self):
        """Context manager entry."""
        return self

    def __exit__(self, *args):
        """Context manager exit."""
        self.close()


class SandboxAPI:
    """Sandbox API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        image: str,
        cpu: int = 2000,
        memory: int = 4096,
        max_lifetime_seconds: int | None = None,
        name: str | None = None,
        args: list[str] | None = None,
        env: dict[str, str] | None = None,
        **kwargs,
    ) -> "SandboxResource":
        """Create a sandbox.

        Args:
            image: Container image
            cpu: CPU in millis
            memory: Memory in MB
            max_lifetime_seconds: Maximum lifetime in seconds
            name: Optional name
            args: Command arguments
            env: Environment variables
            **kwargs: Additional arguments

        Returns:
            Sandbox resource object
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI
        from ..api.models import CreateSandboxRequest

        # Build request
        data = {
            "image": image if image.startswith("docker://") else f"docker://{image}",
            "cpuMillis": cpu,
            "memoryMb": memory,
            "args": args or [],
            "env": env or {},
            **kwargs,
        }

        if name:
            data["name"] = name
        if max_lifetime_seconds is not None:
            data["maxLifetimeSeconds"] = max_lifetime_seconds

        result = _SandboxAPI(self._api).create(data)
        return SandboxResource(self._api, result)

    def get(self, sandbox_id: str) -> "SandboxResource":
        """Get a sandbox.

        Args:
            sandbox_id: Sandbox ID

        Returns:
            Sandbox resource object
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._api).get(sandbox_id)
        return SandboxResource(self._api, result)

    def list_all(self) -> list["SandboxResource"]:
        """List sandboxes.

        Returns:
            List of sandbox resource objects
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        results = _SandboxAPI(self._api).list_all()
        return [SandboxResource(self._api, r) for r in results]


class SnapshotAPI:
    """Snapshot API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        sandbox_id: str,
        name: str | None = None,
        with_memory: bool = False,
    ) -> Snapshot:
        """Create a snapshot.

        Args:
            sandbox_id: Sandbox ID
            name: Optional snapshot name
            with_memory: Include memory in snapshot
        Returns:
            Snapshot object
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).create(
            sandbox_id,
            name=name,
            with_memory=with_memory,
        )

    def get(self, snapshot_id: str) -> Snapshot:
        """Get a snapshot.

        Args:
            snapshot_id: Snapshot ID

        Returns:
            Snapshot object
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).get(snapshot_id)

    def list_all(self) -> list[Snapshot]:
        """List snapshots.

        Returns:
            List of snapshots
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).list_all()

    def restore(self, snapshot_id: str, name: str | None = None) -> Sandbox:
        """Restore a sandbox from snapshot.

        Args:
            snapshot_id: Snapshot ID or name
            name: Optional name for restored sandbox

        Returns:
            Created sandbox
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._api).restore(snapshot_id, name=name)


class ImageAPI:
    """Image snapshot API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_all(
        self,
        workspace_id: str | None = None,
        build_hash: str | None = None,
        tag: str | None = None,
        scope: str | None = None,
        page: int = 1,
        limit: int = 100,
    ) -> list[ImageSnapshot]:
        """List image snapshots."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).list_all(
            workspace_id=workspace_id,
            build_hash=build_hash,
            tag=tag,
            scope=scope,
            page=page,
            limit=limit,
        )

    def get(self, image_id: str) -> ImageSnapshot:
        """Get image snapshot details."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).get(image_id)

    def delete(self, image_id: str) -> None:
        """Delete an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        _ImageAPI(self._api).delete(image_id)

    def cancel(self, image_id: str) -> ImageSnapshot:
        """Cancel an in-progress image build."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).cancel(image_id)

    def add_tags(self, image_id: str, tags: list[str], overwrite: bool = False) -> ImageSnapshot:
        """Add tags to an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).add_tags(image_id, tags, overwrite)

    def remove_tag(self, image_id: str, tag: str) -> dict[str, Any]:
        """Remove a tag from an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).remove_tag(image_id, tag)

    def resolve(self, workspace_id: str, tag: str) -> ImageSnapshot:
        """Resolve an image tag to an image snapshot."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).resolve(workspace_id, tag)

    def list_tags(
        self,
        workspace_id: str | None = None,
        image_id: str | None = None,
        tag: str | None = None,
    ) -> list[ImageTag]:
        """List image tags."""
        from ..api.image import ImageAPI as _ImageAPI

        return _ImageAPI(self._api).list_tags(
            workspace_id=workspace_id,
            image_id=image_id,
            tag=tag,
        )


class BrowserAPI:
    """Browser API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        name: str | None = None,
        workspace_id: str | None = None,
        screen_width: int | None = None,
        screen_height: int | None = None,
        stealth: bool = False,
        adblock: bool | None = None,
        profile_mode: str = "persistent",
        profile_id: str | None = None,
        proxy_url: str | None = None,
        proxy_provider: str | None = None,
        proxy_type: str | None = None,
        enable_captcha_solver: bool | None = None,
        enable_rrweb: bool | None = None,
        enable_logger: bool | None = None,
        cpu_millis: int | None = None,
        memory_mb: int | None = None,
        max_lifetime_seconds: int | None = None,
        gpu_type: str | None = None,
        width: int | None = None,
        height: int | None = None,
    ) -> BrowserSession:
        """Create a browser session.

        Args:
            name: Session name
            workspace_id: Optional workspace ID
            screen_width: Screen width
            screen_height: Screen height
            stealth: Enable stealth mode

        Returns:
            Browser session
        """
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).create(
            name=name,
            workspace_id=workspace_id,
            screen_width=screen_width,
            screen_height=screen_height,
            enable_stealth=stealth,
            enable_adblock=adblock,
            profile_mode=profile_mode,
            proxy_url=proxy_url,
            proxy_provider=proxy_provider,
            proxy_type=proxy_type,
            enable_captcha_solver=enable_captcha_solver,
            enable_rrweb=enable_rrweb,
            enable_logger=enable_logger,
            cpu_millis=cpu_millis,
            memory_mb=memory_mb,
            max_lifetime_seconds=max_lifetime_seconds,
            gpu_type=gpu_type,
            profile_id=profile_id,
            width=width,
            height=height,
        )

    def list_all(self) -> list[BrowserSession]:
        """List browser sessions.

        Returns:
            List of browser sessions
        """
        from ..api.browser import BrowserAPI as _BrowserAPI

        return _BrowserAPI(self._api).list_all()


class NotebookAPI:
    """Notebook API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(
        self,
        workspace_id: str,
        name: str | None = None,
        type: str = "small",
        cpu: int | None = None,
        memory: int | None = None,
        image: str | None = None,
        snapshot_id: str | None = None,
        gpu_count: int | None = None,
        gpu_type: str | None = None,
        storage_mode: str | None = None,
        env: dict[str, str] | None = None,
        idle_ttl_seconds: int | None = None,
        persistent: bool | None = None,
        snapshot_favor: str | None = None,
        hard_kill_at: str | None = None,
        hard_kill_after_seconds: int | None = None,
    ) -> NotebookSession:
        """Create a notebook session.

        Args:
            workspace_id: Workspace ID
            type: Sandbox type preset
            cpu: Custom CPU in millis
            memory: Custom memory in MB

        Returns:
            Notebook session
        """
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).create(
            workspace_id=workspace_id,
            name=name,
            type=type,
            cpu=cpu,
            memory=memory,
            image=image,
            snapshot_id=snapshot_id,
            gpu_count=gpu_count,
            gpu_type=gpu_type,
            storage_mode=storage_mode,
            env=env,
            idle_ttl_seconds=idle_ttl_seconds,
            persistent=persistent,
            snapshot_favor=snapshot_favor,
            hard_kill_at=hard_kill_at,
            hard_kill_after_seconds=hard_kill_after_seconds,
        )

    def list_all(self) -> list[NotebookSession]:
        """List notebook sessions.

        Returns:
            List of notebook sessions
        """
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_all()

    def create_document(
        self,
        workspace_id: str,
        name: str,
        *,
        description: str | None = None,
        kernel: str | None = None,
        runtime: str | None = None,
        image: str | None = None,
        auto_save_enabled: bool | None = None,
        markdown_first_cell: bool = False,
    ) -> NotebookDocument:
        """Create a notebook document."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).create_document(
            workspace_id=workspace_id,
            name=name,
            description=description,
            kernel=kernel,
            runtime=runtime,
            image=image,
            auto_save_enabled=auto_save_enabled,
            markdown_first_cell=markdown_first_cell,
        )

    def list_documents(self, workspace_id: str) -> list[NotebookDocument]:
        """List notebook documents in a workspace."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_documents(workspace_id)

    def get_document(self, notebook_id: str) -> NotebookDocument:
        """Get notebook document details."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).get_document(notebook_id)

    def update_document(
        self,
        notebook_id: str,
        *,
        name: str | None = None,
        description: str | None = None,
        kernel: str | None = None,
        runtime: str | None = None,
        auto_save_enabled: bool | None = None,
    ) -> NotebookDocument:
        """Update notebook document metadata."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).update_document(
            notebook_id=notebook_id,
            name=name,
            description=description,
            kernel=kernel,
            runtime=runtime,
            auto_save_enabled=auto_save_enabled,
        )

    def delete_document(self, notebook_id: str) -> None:
        """Delete a notebook document."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        _NotebookAPI(self._api).delete_document(notebook_id)

    def duplicate_document(self, notebook_id: str) -> NotebookDocument:
        """Duplicate a notebook document."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).duplicate_document(notebook_id)

    def import_document(
        self,
        workspace_id: str,
        *,
        name: str | None = None,
        url: str | None = None,
        file_path: str | None = None,
    ) -> NotebookDocument:
        """Import a notebook document from URL or local file."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).import_document(
            workspace_id=workspace_id,
            name=name,
            url=url,
            file_path=file_path,
        )

    def export_document(
        self,
        notebook_id: str,
        *,
        download: bool = False,
    ) -> dict[str, Any] | str:
        """Export notebook document content."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).export_document(
            notebook_id,
            download=download,
        )

    def save_document(self, notebook_id: str) -> NotebookDocument:
        """Persist notebook document to storage."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).save_document(notebook_id)

    @staticmethod
    def _validate_cell_selector(
        index: int | None = None,
        cell_id: str | None = None,
    ) -> None:
        has_index = index is not None
        has_id = bool(cell_id)
        if has_index == has_id:
            raise ValueError("Provide exactly one of index or cell_id")
        if index is not None and index < 0:
            raise ValueError("index must be a non-negative integer")

    def list_cells(
        self,
        notebook_id: str,
        *,
        include_outputs: bool = False,
    ) -> list[NotebookCell] | list[NotebookCellDetail]:
        """List cells in a notebook."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).list_cells(
            notebook_id,
            include_outputs=include_outputs,
        )

    def add_cell(
        self,
        notebook_id: str,
        content: str,
        *,
        cell_type: str = "code",
        index: int | None = None,
    ) -> NotebookCell:
        """Add a cell to a notebook."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        return _NotebookAPI(self._api).add_cell(
            notebook_id,
            content,
            cell_type=cell_type,
            index=index,
        )

    def get_cell(
        self,
        notebook_id: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
    ) -> NotebookCellDetail:
        """Get a cell by ID or zero-based index."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        self._validate_cell_selector(index=index, cell_id=cell_id)
        api = _NotebookAPI(self._api)
        if cell_id:
            return api.get_cell(notebook_id, cell_id)
        return api.get_cell_by_index(notebook_id, index or 0)

    def update_cell(
        self,
        notebook_id: str,
        content: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
    ) -> NotebookCell:
        """Update a cell source by ID or index with optimistic concurrency."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        resolved = self.get_cell(notebook_id, index=index, cell_id=cell_id)
        return _NotebookAPI(self._api).update_cell_source(
            notebook_id,
            resolved.id,
            content,
            expected_version=resolved.source_ot_version,
        )

    def remove_cell(
        self,
        notebook_id: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
    ) -> None:
        """Delete a cell by ID or index."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        resolved = self.get_cell(notebook_id, index=index, cell_id=cell_id)
        _NotebookAPI(self._api).delete_cell(notebook_id, resolved.id)

    def ensure_kernel(
        self,
        notebook_id: str,
        *,
        wait: bool = False,
        timeout: int = 120,
    ) -> dict[str, Any]:
        """Ensure kernel exists and optionally wait until ready."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        api = _NotebookAPI(self._api)
        ensured = api.ensure_kernel(notebook_id)
        if not wait:
            return ensured

        import time

        start = time.time()
        while time.time() - start < timeout:
            kernel_status = api.get_kernel_status(notebook_id)
            status = str(kernel_status.get("status") or "")
            message = str(kernel_status.get("message") or "")
            if status == "idle" or (status == "busy" and message != "Kernel starting"):
                return {
                    "status": "running",
                    "ensureStatus": ensured.get("status"),
                    "kernelStatus": kernel_status,
                }
            time.sleep(0.5)

        raise TimeoutError(f"Timeout waiting for kernel readiness ({timeout}s)")

    def execute_cell(
        self,
        notebook_id: str,
        *,
        index: int | None = None,
        cell_id: str | None = None,
        wait: bool = True,
        timeout: int = 30,
    ) -> ExecutionResult | NotebookCellDetail:
        """Execute a cell and optionally wait for completion."""
        from ..api.notebook import NotebookAPI as _NotebookAPI

        self._validate_cell_selector(index=index, cell_id=cell_id)
        api = _NotebookAPI(self._api)
        result = api.execute_cell(
            notebook_id,
            cell_id=cell_id,
            cell_index=index,
        )
        if not wait:
            return result

        import time

        def _normalize_outputs(cell: NotebookCellDetail) -> list[dict]:
            outputs = getattr(cell, "outputs", None)
            if not isinstance(outputs, list):
                return []
            return [output.model_dump(by_alias=True, exclude_none=True) for output in outputs]

        def _is_execution_complete(
            cell: NotebookCellDetail,
            baseline_outputs: list[dict],
            baseline_execution_count: int | None,
            baseline_last_run_at: int | None,
            baseline_last_run_duration: float | int | None,
        ) -> bool:
            outputs = getattr(cell, "outputs", None)
            has_outputs = isinstance(outputs, (list, tuple)) and len(outputs) > 0
            has_execution_count = isinstance(cell.execution_count, int)
            has_last_run_at = isinstance(cell.last_run_at, int)
            has_last_run_duration = isinstance(cell.last_run_duration, (int, float))
            execution_settled = cell.status not in ("starting", "running")
            return (
                cell.status in ("ok", "error")
                or (has_outputs and _normalize_outputs(cell) != baseline_outputs)
                or (has_execution_count and cell.execution_count != baseline_execution_count)
                or (
                    execution_settled
                    and has_last_run_at
                    and cell.last_run_at != baseline_last_run_at
                )
                or (
                    execution_settled
                    and has_last_run_duration
                    and cell.last_run_duration != baseline_last_run_duration
                )
            )

        baseline_cell = self.get_cell(notebook_id, index=index, cell_id=cell_id)
        baseline_outputs = _normalize_outputs(baseline_cell)
        baseline_execution_count = (
            baseline_cell.execution_count if isinstance(baseline_cell.execution_count, int) else None
        )
        baseline_last_run_at = (
            baseline_cell.last_run_at if isinstance(baseline_cell.last_run_at, int) else None
        )
        baseline_last_run_duration = (
            baseline_cell.last_run_duration
            if isinstance(baseline_cell.last_run_duration, (int, float))
            else None
        )

        start = time.time()
        while time.time() - start < timeout:
            cell = self.get_cell(notebook_id, index=index, cell_id=cell_id)
            if _is_execution_complete(
                cell,
                baseline_outputs,
                baseline_execution_count,
                baseline_last_run_at,
                baseline_last_run_duration,
            ):
                return cell
            time.sleep(0.5)

        raise TimeoutError(f"Timeout waiting for cell execution ({timeout}s)")


class WorkspaceAPI:
    """Workspace API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def create(self, name: str) -> Workspace:
        """Create a workspace.

        Args:
            name: Workspace name

        Returns:
            Workspace object
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).create(name)

    def list_all(self) -> list[Workspace]:
        """List workspaces.

        Returns:
            List of workspaces
        """
        from ..api.workspace import WorkspaceAPI as _WorkspaceAPI

        return _WorkspaceAPI(self._api).list_all()


class BillingAPI:
    """Billing API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def get_balance(self, workspace_id: str) -> dict[str, Any]:
        """Get workspace balance.

        Args:
            workspace_id: Workspace ID

        Returns:
            Balance info
        """
        from ..api.billing import BillingAPI as _BillingAPI

        result = _BillingAPI(self._api).get_balance(workspace_id)
        return {
            "balance_cents": result.balance_cents,
            "balance_usd": result.balance_usd,
        }


class AnalyticsAPIWrapper:
    """Analytics API wrapper."""

    def __init__(self, client: _Client):
        self._api = client

    def list_installations(self) -> list["AnalyticsInstallationResource"]:
        """List analytics installations.

        Returns:
            List of installation resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI
        from ..api.models import AnalyticsInstallation

        results = _AnalyticsAPI(self._api).list_installations()
        return [AnalyticsInstallationResource(self._api, r) for r in results]

    def create_installation(
        self,
        name: str,
        allowed_domains: list[str] | None = None,
        settings: dict[str, Any] | None = None,
    ) -> "AnalyticsInstallationResource":
        """Create an analytics installation.

        Args:
            name: Installation name
            allowed_domains: Optional allowed domains
            settings: Optional settings

        Returns:
            Installation resource
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).create_installation(
            name, allowed_domains, settings
        )
        return AnalyticsInstallationResource(self._api, result)

    def get_stats(self) -> dict[str, Any]:
        """Get analytics statistics.

        Returns:
            Statistics data
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_stats()

    def get_realtime_stats(self) -> dict[str, Any]:
        """Get real-time statistics.

        Returns:
            Real-time stats
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_realtime_stats()

    def list_funnels(self, installation_id: str) -> list["AnalyticsFunnelResource"]:
        """List funnels for an installation.

        Args:
            installation_id: Installation ID

        Returns:
            List of funnel resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).list_funnels(installation_id=installation_id)
        return [AnalyticsFunnelResource(self._api, r) for r in results]

    def create_funnel(
        self,
        name: str,
        steps: list[dict[str, Any]],
    ) -> "AnalyticsFunnelResource":
        """Create a funnel.

        Args:
            name: Funnel name
            steps: List of steps with name and eventName

        Returns:
            Funnel resource
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        result = _AnalyticsAPI(self._api).create_funnel(name, steps)
        return AnalyticsFunnelResource(self._api, result)

    def list_users(self, installation_id: str, limit: int = 100) -> list["AnalyticsUserResource"]:
        """List user profiles for an installation.

        Args:
            installation_id: Installation ID
            limit: Maximum number of results

        Returns:
            List of user resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).list_users(installation_id=installation_id, limit=limit)
        return [AnalyticsUserResource(self._api, r) for r in results]

    def get_events(
        self,
        installation_id: str,
        event_name: str | None = None,
        fingerprint: str | None = None,
        limit: int = 100,
    ) -> list["AnalyticsEventResource"]:
        """Get events for an installation.

        Args:
            installation_id: Installation ID
            event_name: Optional event name filter
            fingerprint: Optional user fingerprint filter
            limit: Maximum number of results

        Returns:
            List of event resources
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        results = _AnalyticsAPI(self._api).query_events(
            installation_id=installation_id,
            event_name=event_name,
            fingerprint=fingerprint,
            limit=limit,
        )
        return [AnalyticsEventResource(self._api, r) for r in results]

    def get_trajectory(
        self,
        fingerprint: str,
        installation_id: str,
        limit: int = 100,
    ) -> list[dict[str, Any]]:
        """Get user trajectory for an installation.

        Args:
            fingerprint: User fingerprint
            installation_id: Installation ID
            limit: Maximum number of sessions

        Returns:
            User trajectory data
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._api).get_trajectory(
            fingerprint=fingerprint,
            installation_id=installation_id,
            limit=limit,
        )


class AnalyticsEventResource:
    """Analytics event resource."""

    def __init__(self, client: _Client, event: Any):
        self._client = client
        self._event = event

    @property
    def id(self) -> str:
        return self._event.id

    @property
    def event_name(self) -> str:
        return self._event.event_name

    @property
    def fingerprint(self) -> str:
        return self._event.fingerprint

    @property
    def timestamp(self) -> Any:
        return self._event.timestamp


class AnalyticsInstallationResource:
    """Analytics installation resource."""

    def __init__(self, client: _Client, installation: Any):
        self._client = client
        self._installation = installation

    @property
    def id(self) -> str:
        return self._installation.id

    @property
    def name(self) -> str:
        return self._installation.name

    @property
    def api_key(self) -> str:
        return self._installation.api_key

    def get_script(self) -> dict[str, Any]:
        """Get installation script."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._client).get_installation_script(self._installation.id)

    def delete(self) -> None:
        """Delete the installation."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        _AnalyticsAPI(self._client).delete_installation(self._installation.id)


class AnalyticsFunnelResource:
    """Analytics funnel resource."""

    def __init__(self, client: _Client, funnel: Any):
        self._client = client
        self._funnel = funnel

    @property
    def id(self) -> str:
        return self._funnel.id

    @property
    def name(self) -> str:
        return self._funnel.name

    def analyze(self, installation_id: str, days: int | None = None) -> dict[str, Any]:
        """Analyze funnel conversion.

        Args:
            installation_id: Installation ID (required)
            days: Optional number of days to analyze

        Returns:
            Analysis results
        """
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        return _AnalyticsAPI(self._client).analyze_funnel(
            self._funnel.id, installation_id=installation_id, days=days
        )

    def delete(self) -> None:
        """Delete the funnel."""
        from ..api.analytics import AnalyticsAPI as _AnalyticsAPI

        _AnalyticsAPI(self._client).delete_funnel(self._funnel.id)


class AnalyticsUserResource:
    """Analytics user resource."""

    def __init__(self, client: _Client, user: Any):
        self._client = client
        self._user = user

    @property
    def fingerprint(self) -> str:
        return self._user.fingerprint

    @property
    def email(self) -> str | None:
        return self._user.email

    @property
    def name(self) -> str | None:
        return self._user.name

    @property
    def session_count(self) -> int:
        return self._user.session_count


class SandboxResource:
    """A sandbox resource with helper methods."""

    def __init__(self, client: _Client, sandbox: Sandbox):
        self._client = client
        self._sandbox = sandbox

    @property
    def id(self) -> str:
        return self._sandbox.id

    @property
    def status(self) -> str:
        return self._sandbox.status

    @property
    def config(self):
        return self._sandbox.config

    @property
    def metadata(self):
        return self._sandbox.metadata

    def start(self) -> "SandboxResource":
        """Start the sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._client).start(self._sandbox.id)
        return SandboxResource(self._client, result)

    def stop(self) -> "SandboxResource":
        """Stop the sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._client).stop(self._sandbox.id)
        return SandboxResource(self._client, result)

    def delete(self) -> None:
        """Delete the sandbox."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        _SandboxAPI(self._client).delete(self._sandbox.id)

    def logs(
        self,
        follow: bool = False,
        tail: int | None = None,
    ) -> str:
        """Get sandbox logs.

        Args:
            follow: Whether to follow logs
            tail: Number of lines to tail

        Returns:
            Log output
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).logs(self._sandbox.id, follow, tail)

    def expose_port(
        self,
        port: int,
        port_type: str = "tcp",
    ):
        """Expose a port.

        Args:
            port: Container port
            port_type: Port type (tcp, http, ws)

        Returns:
            Port mapping
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).expose_port(self._sandbox.id, port, port_type)

    def list_ports(self) -> list[Any]:
        """List all exposed ports for this sandbox.

        Returns:
            List of PortMapping objects containing container_port, host_port,
            protocol, host_ip, and public_url for each exposed port.
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        return _SandboxAPI(self._client).list_ports(self._sandbox.id)

    def wait_for_status(
        self,
        desired_status: str = "running",
        timeout: float = 120.0,
    ) -> "SandboxResource":
        """Wait for sandbox to reach desired status.

        Args:
            desired_status: Desired status
            timeout: Maximum wait time in seconds

        Returns:
            Sandbox resource
        """
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        result = _SandboxAPI(self._client).wait_for_status(
            self._sandbox.id, desired_status, timeout
        )
        return SandboxResource(self._client, result)

    def create_snapshot(
        self,
        name: str | None = None,
        with_memory: bool = False,
    ) -> Snapshot:
        """Create a snapshot.

        Args:
            name: Snapshot name
            with_memory: Include memory
        Returns:
            Snapshot
        """
        from ..api.snapshot import SnapshotAPI as _SnapshotAPI

        return _SnapshotAPI(self._client).create(
            self._sandbox.id,
            name=name,
            with_memory=with_memory,
        )

    def refresh(self) -> None:
        """Refresh sandbox data from API."""
        from ..api.sandbox import SandboxAPI as _SandboxAPI

        self._sandbox = _SandboxAPI(self._client).get(self._sandbox.id)

    def __repr__(self) -> str:
        return f"Sandbox(id={self._sandbox.id}, status={self._sandbox.status})"


# Convenience function to create client with default settings
def connect(
    api_key: str | None = None,
    api_url: str | None = None,
) -> Client:
    """Create an AgentEnv client with default settings.

    Args:
        api_key: API key (reads from settings if not provided)
        api_url: API URL (reads from settings if not provided)

    Returns:
        Client instance
    """
    return Client(api_key=api_key, api_url=api_url)


# Export main classes
__all__ = [
    "Client",
    "connect",
    "SandboxResource",
    "function",
    "RemoteFunctionError",
    "AIClient",
    "ChatCompletions",
    "Embeddings",
    "ManagementAPI",
]
