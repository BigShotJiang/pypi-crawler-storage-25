"""Lightweight remote function execution via a single sandbox."""

from __future__ import annotations

import base64
import os
import pickle
import re
import tempfile
import textwrap
import uuid
from functools import update_wrapper
from typing import Any, Callable, Generic, TypeVar

from ..api.client import Client as ApiClient
from ..api.sandbox import SandboxAPI
from ..config.settings import get_settings
from ..spec import SandboxSpecError, resolve_single_node_spec

T = TypeVar("T")

_UUID_RE = re.compile(
    r"^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$"
)
_RESULT_PREFIX = "AGENTENV_RESULT:"


class RemoteFunctionError(RuntimeError):
    """Error raised when a remote function execution fails."""

    def __init__(
        self,
        message: str,
        *,
        stdout: str | None = None,
        stderr: str | None = None,
        traceback: str | None = None,
        sandbox_id: str | None = None,
    ) -> None:
        super().__init__(message)
        self.stdout = stdout
        self.stderr = stderr
        self.traceback = traceback
        self.sandbox_id = sandbox_id


class RemoteFunction(Generic[T]):
    """Callable wrapper that executes a function inside an AgentEnv sandbox."""

    def __init__(
        self,
        target: T,
        spec: str | None,
        *,
        image: str | None = None,
        workspace_id: str | None = None,
        name: str | None = None,
        api_url: str | None = None,
        api_key: str | None = None,
        access_token: str | None = None,
        wait_timeout_s: int = 600,
        cleanup: bool = True,
        gpu_count: int = 0,
        gpu_type: str | None = None,
        env: dict[str, str] | None = None,
        sandbox_args: list[str] | None = None,
    ) -> None:
        self._target = target
        self._spec = spec
        self._image = image
        self._workspace_id = workspace_id
        self._name = name
        self._api_url = api_url
        self._api_key = api_key
        self._access_token = access_token
        self._wait_timeout_s = wait_timeout_s
        self._cleanup = cleanup
        self._gpu_count = gpu_count
        self._gpu_type = gpu_type
        self._env = env or {}
        self._sandbox_args = sandbox_args

    def __call__(self, *args: Any, **kwargs: Any) -> Any:
        settings = get_settings()
        base_url = self._api_url or settings.api_url
        api_key = self._api_key or settings.api_key
        access_token = self._access_token or settings.access_token

        workspace_id = self._workspace_id or settings.workspace
        if not workspace_id:
            raise RuntimeError("workspace_id is required (or set default workspace via config)")

        spec_value = self._spec or settings.defaults.type
        if not spec_value:
            raise RuntimeError("spec is required")

        try:
            cpu_millis, memory_mb = resolve_single_node_spec(spec_value)
        except SandboxSpecError as e:
            raise RuntimeError(str(e)) from e

        self._validate_target()

        payload = {"func": self._target, "args": args, "kwargs": kwargs}
        try:
            payload_bytes = pickle.dumps(payload)
        except Exception as e:
            raise RuntimeError(f"Failed to pickle function payload: {e}") from e

        image_value = self._image
        if image_value is not None and hasattr(image_value, "finalize"):
            try:
                image_obj = image_value.finalize()
            except Exception as exc:
                raise RuntimeError(f"Failed to build image: {exc}") from exc
            image_value = getattr(image_obj, "id", image_obj)
            self._image = image_value

        image, snapshot_id = self._resolve_image(image_value, settings)
        normalized_env = {str(k): str(v) for k, v in (self._env or {}).items()}
        normalized_args = (
            [str(arg) for arg in self._sandbox_args] if self._sandbox_args is not None else None
        )

        request: dict[str, Any] = {
            "workspaceId": workspace_id,
            "name": self._name or f"fn-{getattr(self._target, '__name__', 'task')}",
            "cpuMillis": cpu_millis,
            "memoryMb": memory_mb,
            "gpuCount": max(0, int(self._gpu_count)),
            "env": normalized_env,
            "args": normalized_args or ["/bin/sh", "-lc", "sleep infinity"],
        }
        if image is not None:
            request["image"] = image
        if snapshot_id is not None:
            request["snapshotId"] = snapshot_id
        if self._gpu_type:
            request["gpuType"] = self._gpu_type

        api_timeout_s = max(240.0, float(self._wait_timeout_s) + 30.0)
        api_client = ApiClient(
            base_url=base_url,
            api_key=api_key,
            access_token=access_token,
            timeout=api_timeout_s,
        )
        sandbox_api = SandboxAPI(api_client)

        sandbox_id: str | None = None
        try:
            sandbox = sandbox_api.create(request)
            sandbox_id = sandbox.id
            sandbox_api.wait_for_status(
                sandbox_id,
                "running",
                timeout=float(self._wait_timeout_s),
            )
            return self._execute(sandbox_api, sandbox_id, payload_bytes)
        finally:
            if sandbox_id and self._cleanup:
                try:
                    sandbox_api.delete(sandbox_id)
                except Exception:
                    pass

    def _validate_target(self) -> None:
        module = getattr(self._target, "__module__", None)
        qualname = getattr(self._target, "__qualname__", "")
        if module in (None, "__main__") or "<locals>" in qualname:
            raise RuntimeError(
                "agentenv.function requires a top-level, importable function. "
                "Define it in a module available inside the sandbox image."
            )

    def _resolve_image(self, image: Any | None, settings) -> tuple[str | None, str | None]:
        if image is None:
            resolved = settings.resolve_image(settings.defaults.image)
            if not resolved.startswith(("docker://", "docker.io/")):
                resolved = f"docker://{resolved}"
            return resolved, None

        if not isinstance(image, str):
            image = getattr(image, "id", None)
            if not image:
                raise RuntimeError("image must be a string or an object with an id attribute")

        if image.startswith("snapshot://"):
            return None, image.split("snapshot://", 1)[1]
        if image.startswith("snapshot:"):
            return None, image.split("snapshot:", 1)[1]
        if _UUID_RE.match(image):
            return None, image

        resolved = settings.resolve_image(image)
        if not resolved.startswith(("docker://", "docker.io/")):
            resolved = f"docker://{resolved}"
        return resolved, None

    def _execute(self, sandbox_api: SandboxAPI, sandbox_id: str, payload: bytes) -> Any:
        harness = textwrap.dedent(
            """
            import base64
            import io
            import pickle
            import sys
            import traceback
            from contextlib import redirect_stdout, redirect_stderr

            def main():
                stdout_buf = io.StringIO()
                stderr_buf = io.StringIO()
                result = {"ok": True, "result": None, "stdout": "", "stderr": ""}
                try:
                    with redirect_stdout(stdout_buf), redirect_stderr(stderr_buf):
                        payload_path = sys.argv[1]
                        with open(payload_path, "rb") as f:
                            payload = pickle.load(f)
                        func = payload["func"]
                        args = payload.get("args", ())
                        kwargs = payload.get("kwargs", {})
                        result["result"] = func(*args, **kwargs)
                except Exception as exc:
                    result["ok"] = False
                    result["error"] = repr(exc)
                    result["traceback"] = traceback.format_exc()
                result["stdout"] = stdout_buf.getvalue()
                result["stderr"] = stderr_buf.getvalue()
                try:
                    data = pickle.dumps(result)
                except Exception as exc:
                    fallback = {
                        "ok": False,
                        "error": f"Failed to pickle result: {exc!r}",
                        "stdout": result.get("stdout"),
                        "stderr": result.get("stderr"),
                        "traceback": result.get("traceback"),
                    }
                    data = pickle.dumps(fallback)
                sys.stdout.write("AGENTENV_RESULT:" + base64.b64encode(data).decode("ascii"))

            if __name__ == "__main__":
                main()
            """
        ).lstrip()

        run_id = uuid.uuid4().hex[:12]
        remote_payload = f"/tmp/agentenv-function-{run_id}.pkl"
        remote_harness = f"/tmp/agentenv-function-{run_id}.py"

        with tempfile.TemporaryDirectory() as tmpdir:
            payload_path = os.path.join(tmpdir, "payload.pkl")
            harness_path = os.path.join(tmpdir, "harness.py")

            with open(payload_path, "wb") as f:
                f.write(payload)
            with open(harness_path, "w", encoding="utf-8") as f:
                f.write(harness)

            sandbox_api.upload_file(sandbox_id, payload_path, remote_payload)
            sandbox_api.upload_file(sandbox_id, harness_path, remote_harness)

        command = (
            "if command -v python3 >/dev/null 2>&1; then "
            f"python3 {remote_harness} {remote_payload}; "
            "else python "
            f"{remote_harness} {remote_payload}; fi"
        )

        exec_result = sandbox_api.exec(sandbox_id, command)
        output = exec_result.output or ""
        payload_b64 = self._extract_payload(output)

        if not payload_b64:
            raise RemoteFunctionError(
                f"Remote execution failed (exit_code={exec_result.exit_code})",
                stdout=output,
                sandbox_id=sandbox_id,
            )

        try:
            result = pickle.loads(base64.b64decode(payload_b64))
        except Exception as e:
            raise RemoteFunctionError(
                f"Failed to decode remote result: {e}",
                stdout=output,
                sandbox_id=sandbox_id,
            ) from e

        if not isinstance(result, dict):
            raise RemoteFunctionError(
                "Remote execution returned invalid payload",
                stdout=output,
                sandbox_id=sandbox_id,
            )

        if not result.get("ok", False):
            raise RemoteFunctionError(
                result.get("error", "Remote execution failed"),
                stdout=result.get("stdout"),
                stderr=result.get("stderr"),
                traceback=result.get("traceback"),
                sandbox_id=sandbox_id,
            )

        return result.get("result")

    def _extract_payload(self, output: str) -> str | None:
        if _RESULT_PREFIX in output:
            _, _, tail = output.rpartition(_RESULT_PREFIX)
            payload = tail.strip().splitlines()[0] if tail else ""
            return payload or None
        return None


def function(
    spec: str | None,
    *,
    image: str | None = None,
    workspace_id: str | None = None,
    name: str | None = None,
    api_url: str | None = None,
    api_key: str | None = None,
    access_token: str | None = None,
    wait_timeout_s: int = 600,
    cleanup: bool = True,
    gpu_count: int = 0,
    gpu_type: str | None = None,
    env: dict[str, str] | None = None,
    sandbox_args: list[str] | None = None,
) -> Callable[[T], RemoteFunction[T]]:
    """Decorator to run a function in a single-node sandbox.

    Example:
        @agentenv.function("small", image="python:3.11-slim")
        def add(x, y):
            return x + y
    """

    def decorator(target: T) -> RemoteFunction[T]:
        wrapper = RemoteFunction(
            target,
            spec,
            image=image,
            workspace_id=workspace_id,
            name=name,
            api_url=api_url,
            api_key=api_key,
            access_token=access_token,
            wait_timeout_s=wait_timeout_s,
            cleanup=cleanup,
            gpu_count=gpu_count,
            gpu_type=gpu_type,
            env=env,
            sandbox_args=sandbox_args,
        )
        return update_wrapper(wrapper, target)  # type: ignore[arg-type]

    return decorator
