"""Secure storage for credentials using keyring or file storage."""

import json
import os
from pathlib import Path

try:
    import keyring
    KEYRING_AVAILABLE = True
except ImportError:
    KEYRING_AVAILABLE = False


class CredentialStorage:
    """Secure credential storage."""

    KEYRING_SERVICE = "agentenv-cli"
    KEYRING_API_KEY = "api_key"
    KEYRING_GATEWAY_KEY = "gateway_key"
    KEYRING_ACCESS_TOKEN = "access_token"
    KEYRING_REFRESH_TOKEN = "refresh_token"

    def __init__(self, use_keyring: bool = True):
        """Initialize credential storage.

        Args:
            use_keyring: Whether to use keyring if available. Falls back to file storage.
        """
        self._use_keyring = use_keyring and KEYRING_AVAILABLE
        self._config_dir = Path.home() / ".agentenv"
        self._config_dir.mkdir(mode=0o700, exist_ok=True)
        self._credentials_file = self._config_dir / "credentials.json"

    def _disable_keyring_and_fallback(self) -> None:
        """Disable keyring backend after runtime failure."""
        self._use_keyring = False

    def _keyring_set_or_fallback(self, keyring_key: str, file_key: str, value: str) -> None:
        if not self._use_keyring:
            self._set_file_credential(file_key, value)
            return

        try:
            keyring.set_password(self.KEYRING_SERVICE, keyring_key, value)
            self._delete_file_credential(file_key)
        except Exception:
            self._disable_keyring_and_fallback()
            self._set_file_credential(file_key, value)

    def _keyring_get_or_fallback(self, keyring_key: str, file_key: str) -> str | None:
        if not self._use_keyring:
            return self._get_file_credential(file_key)

        try:
            return keyring.get_password(self.KEYRING_SERVICE, keyring_key)
        except Exception:
            self._disable_keyring_and_fallback()
            return self._get_file_credential(file_key)

    def _keyring_delete_or_fallback(self, keyring_key: str, file_key: str) -> None:
        if not self._use_keyring:
            self._delete_file_credential(file_key)
            return

        try:
            try:
                keyring.delete_password(self.KEYRING_SERVICE, keyring_key)
            except keyring.errors.PasswordDeleteError:
                pass
            self._delete_file_credential(file_key)
        except Exception:
            self._disable_keyring_and_fallback()
            self._delete_file_credential(file_key)

    def set_api_key(self, api_key: str) -> None:
        """Store API key."""
        self._keyring_set_or_fallback(self.KEYRING_API_KEY, "api_key", api_key)

    def get_api_key(self) -> str | None:
        """Retrieve API key."""
        return self._keyring_get_or_fallback(self.KEYRING_API_KEY, "api_key")

    def set_gateway_key(self, gateway_key: str) -> None:
        """Store AI gateway key."""
        self._keyring_set_or_fallback(self.KEYRING_GATEWAY_KEY, "gateway_key", gateway_key)

    def get_gateway_key(self) -> str | None:
        """Retrieve AI gateway key."""
        return self._keyring_get_or_fallback(self.KEYRING_GATEWAY_KEY, "gateway_key")

    def set_access_token(self, token: str) -> None:
        """Store access token."""
        self._keyring_set_or_fallback(self.KEYRING_ACCESS_TOKEN, "access_token", token)

    def get_access_token(self) -> str | None:
        """Retrieve access token."""
        return self._keyring_get_or_fallback(self.KEYRING_ACCESS_TOKEN, "access_token")

    def set_refresh_token(self, token: str) -> None:
        """Store refresh token."""
        self._keyring_set_or_fallback(self.KEYRING_REFRESH_TOKEN, "refresh_token", token)

    def get_refresh_token(self) -> str | None:
        """Retrieve refresh token."""
        return self._keyring_get_or_fallback(self.KEYRING_REFRESH_TOKEN, "refresh_token")

    def clear_all(self) -> None:
        """Clear all stored credentials."""
        for keyring_key, file_key in [
            (self.KEYRING_API_KEY, "api_key"),
            (self.KEYRING_GATEWAY_KEY, "gateway_key"),
            (self.KEYRING_ACCESS_TOKEN, "access_token"),
            (self.KEYRING_REFRESH_TOKEN, "refresh_token"),
        ]:
            self._keyring_delete_or_fallback(keyring_key, file_key)

        if self._credentials_file.exists():
            self._credentials_file.unlink()

    def _set_file_credential(self, key: str, value: str) -> None:
        """Store credential in file."""
        creds: dict[str, str] = {}
        if self._credentials_file.exists():
            with open(self._credentials_file) as f:
                creds = json.load(f)

        creds[key] = value

        with open(self._credentials_file, "w") as f:
            json.dump(creds, f)
        os.chmod(self._credentials_file, 0o600)

    def _get_file_credential(self, key: str) -> str | None:
        """Retrieve credential from file."""
        if not self._credentials_file.exists():
            return None

        with open(self._credentials_file) as f:
            creds = json.load(f)
        return creds.get(key)

    def _delete_file_credential(self, key: str) -> None:
        """Delete a credential from file storage."""
        if not self._credentials_file.exists():
            return

        with open(self._credentials_file) as f:
            creds = json.load(f)

        creds.pop(key, None)
        if creds:
            with open(self._credentials_file, "w") as f:
                json.dump(creds, f)
            os.chmod(self._credentials_file, 0o600)
            return

        self._credentials_file.unlink()

    def sync(
        self,
        *,
        api_key: str | None,
        gateway_key: str | None,
        access_token: str | None,
        refresh_token: str | None,
    ) -> None:
        """Synchronize all supported credentials with the configured backend."""
        credentials = {
            "api_key": (self.KEYRING_API_KEY, api_key),
            "gateway_key": (self.KEYRING_GATEWAY_KEY, gateway_key),
            "access_token": (self.KEYRING_ACCESS_TOKEN, access_token),
            "refresh_token": (self.KEYRING_REFRESH_TOKEN, refresh_token),
        }

        for file_key, (keyring_key, value) in credentials.items():
            if value:
                self._keyring_set_or_fallback(keyring_key, file_key, value)
            else:
                self._keyring_delete_or_fallback(keyring_key, file_key)

    def get_all(self) -> dict[str, str | None]:
        """Get all stored credentials."""
        return {
            "api_key": self.get_api_key(),
            "gateway_key": self.get_gateway_key(),
            "access_token": self.get_access_token(),
            "refresh_token": self.get_refresh_token(),
        }

    def has_credentials(self) -> bool:
        """Check if any credentials are stored."""
        return any(self.get_all().values())

    @staticmethod
    def is_keyring_available() -> bool:
        """Check if keyring is available."""
        return KEYRING_AVAILABLE
