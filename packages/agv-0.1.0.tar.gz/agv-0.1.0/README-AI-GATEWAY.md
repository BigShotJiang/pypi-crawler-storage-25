# AI Gateway CLI and SDK

## Quick Start

### CLI

```bash
# Set your AI Gateway key
export AGENTENV_AI_KEY="cr_xxxxx"

# Or save to config
av config set-ai-key cr_xxxxx

# Chat with AI
av ai chat "What is the capital of France?"
av ai chat "Explain quantum computing" --model gpt-4
av ai chat "Write a function" --system-prompt "You are a Python expert"

# Include files
av ai chat "Review this code" --file main.py --file utils.py

# Interactive mode
av ai chat --interactive

# Management (requires login with JWT)
av login
av ai providers
av ai models
av ai upstreams list
av ai upstreams create --provider openai --api-key $OPENAI_KEY --name "OpenAI"
av ai pools create --name production --strategy round-robin
av ai keys create --name "Production Key" --daily-limit 100.00
av ai usage --start-date 2025-01-01
```

### SDK

```python
from agentenv import AIClient

# Initialize
client = AIClient(api_key="cr_xxxxx")

# Chat completion
response = client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Hello!"}]
)
print(response.choices[0].message.content)

# Streaming
for chunk in client.chat.completions.create(
    model="gpt-4",
    messages=[{"role": "user", "content": "Tell me a story"}],
    stream=True
):
    print(chunk.choices[0].delta.content, end="")

# Embeddings
embeddings = client.embeddings.create(
    model="text-embedding-3-small",
    input="Hello world"
)

# Management
upstreams = client.management.list_upstreams()
key = client.management.create_key(name="New Key", daily_limit=50.00)
```

## Environment Variables

- `AGENTENV_AI_KEY` - AI Gateway API key (for chat/embeddings)
- `AGENTENV_API_KEY` - Management API key (for upstreams/pools/keys)
- `AGENTENV_AI_MODEL` - Default model (default: gpt-4o)
