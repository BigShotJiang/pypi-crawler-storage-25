#!/usr/bin/env python3
"""Validate agv release tags against the package version."""

from __future__ import annotations

import argparse
import os
import re
import runpy
import sys
from pathlib import Path

CLI_ROOT = Path(__file__).resolve().parents[1]
VERSION_FILE = CLI_ROOT / "src" / "agentenv" / "_version.py"
TAG_PATTERN = re.compile(r"^agv-v(?P<version>[0-9][0-9A-Za-z.+_-]*)$")


def load_version() -> str:
    """Load the package version from the canonical version file."""

    version = runpy.run_path(str(VERSION_FILE)).get("__version__")
    if not isinstance(version, str) or not version:
        raise SystemExit(f"Could not load __version__ from {VERSION_FILE}")
    return version


def validate_tag(tag: str, version: str) -> None:
    """Ensure the release tag format and version match the package version."""

    match = TAG_PATTERN.fullmatch(tag)
    if match is None:
        raise SystemExit(
            f"Release tag must match 'agv-v<version>', got: {tag}"
        )

    tag_version = match.group("version")
    if tag_version != version:
        raise SystemExit(
            f"Release tag version {tag_version} does not match package version {version}"
        )


def main() -> int:
    """CLI entrypoint."""

    parser = argparse.ArgumentParser(
        description="Validate agv package version and optional release tag."
    )
    parser.add_argument(
        "--tag",
        help="Release tag to validate, for example agv-v0.1.0. "
        "Defaults to GITHUB_REF_NAME when present.",
    )
    parser.add_argument(
        "--print-version",
        action="store_true",
        help="Print the package version.",
    )
    args = parser.parse_args()

    version = load_version()
    if args.print_version:
        print(version)

    tag = args.tag or os.getenv("GITHUB_REF_NAME")
    if tag:
        validate_tag(tag, version)
        print(f"Validated release tag {tag} against package version {version}")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
