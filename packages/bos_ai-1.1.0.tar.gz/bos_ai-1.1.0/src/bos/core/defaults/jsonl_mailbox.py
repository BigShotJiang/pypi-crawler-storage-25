"""
JSONL-backed mailbox.

Each agent has an inbox file ``<agent_name>.jsonl`` inside *store_dir*.
Messages are appended atomically via file locking.
"""

from __future__ import annotations

import asyncio
import json
import urllib.parse
from dataclasses import asdict
from datetime import datetime
from pathlib import Path

from bos.protocol import Envelope, MessageContent, MessageType

from .._utils import _flock
from ..contract import ep_mail_route


def _slugify(address: str) -> str:
    """Convert an address to a filesystem-safe filename segment using URL encoding.

    The ``@`` separator is kept unencoded for readability with the
    ``type@name`` convention.

    Examples:
        "agent@main"  -> "agent@main"
        "channel@http"  -> "channel@http"
    """
    return urllib.parse.quote(address, safe="@")


class _JsonlMailBox:
    def __init__(self, route: "JsonlMailRoute", address: str) -> None:
        self._route = route
        self._address = address

    @property
    def address(self) -> str:
        return self._address

    async def receive(self) -> Envelope:
        return await self._route.receive(self._address)

    async def send(
        self,
        recipient: str,
        content: MessageContent,
        *,
        content_type: MessageType | str = MessageType.MESSAGE,
        chat_id: str | None = None,
        metadata: dict[str, object] | None = None,
    ) -> None:
        await self._route.deliver(
            Envelope(
                sender=self._address,
                recipient=recipient,
                content=content,
                content_type=content_type,
                chat_id=chat_id,
                metadata=metadata or {},
            )
        )

    async def receive_nowait(self) -> Envelope | None:
        return await self._route.receive_nowait(self._address)


@ep_mail_route(name="_default")
class JsonlMailRoute:
    """File-based mail route using JSONL inbox files."""

    def __init__(self, store_dir: str | Path = None, bos_dir: str | Path | None = None) -> None:
        store_dir = Path(store_dir).expanduser() if store_dir else "mailboxes"
        self._dir = Path(bos_dir or ".").expanduser().resolve() / store_dir
        self._dir.mkdir(parents=True, exist_ok=True)
        self._byte_offsets: dict[str, int] = {}

    def _inbox_path(self, address: str) -> Path:
        return self._dir / f"{_slugify(address)}.jsonl"

    def bind(self, address: str) -> _JsonlMailBox:
        return _JsonlMailBox(self, address)

    async def receive(self, address: str) -> Envelope:
        while True:
            env = await self.receive_nowait(address)
            if env is not None:
                return env
            await asyncio.sleep(0.5)

    async def deliver(self, env: Envelope) -> None:
        target = self._dir / f"{_slugify(env.recipient)}.jsonl"
        payload = asdict(env)
        payload["timestamp"] = env.timestamp.isoformat()
        serialized = json.dumps(payload, default=str) + "\n"

        def _write() -> None:
            with _flock(target):
                with target.open("a", encoding="utf-8") as f:
                    f.write(serialized)

        await asyncio.to_thread(_write)

    def _init_offset(self, address: str) -> int:
        """Seek to EOF on first access so we skip messages from prior runs."""
        inbox = self._inbox_path(address)
        offset = inbox.stat().st_size if inbox.exists() else 0
        self._byte_offsets[address] = offset
        return offset

    async def receive_nowait(self, address: str) -> Envelope | None:
        """Non-blocking receive. Returns ``None`` when inbox is empty."""
        inbox = self._inbox_path(address)
        offset = self._byte_offsets.get(address) if address in self._byte_offsets else self._init_offset(address)

        def _read() -> tuple[str | None, int]:
            if not inbox.exists():
                return None, offset
            with _flock(inbox):
                with inbox.open("r", encoding="utf-8") as f:
                    f.seek(offset)
                    line = f.readline()
                    if not line or not line.endswith("\n"):
                        return None, offset
                    return line, f.tell()

        line, new_offset = await asyncio.to_thread(_read)
        self._byte_offsets[address] = new_offset
        if line is None:
            return None
        raw = json.loads(line)
        if timestamp := raw.get("timestamp"):
            raw["timestamp"] = datetime.fromisoformat(timestamp)
        return Envelope(**raw)

    async def aclose(self) -> None:
        """Release tracked state. File locks are per-operation (not held long-term)."""
        self._byte_offsets.clear()
