import importlib

import click

_LAZY_COMMANDS: dict[str, str] = {
    "auth": "bos.cli.commands.auth:auth",
    "init": "bos.cli.commands.init:init",
    "prompt": "bos.cli.commands.agent:prompt",
    "start": "bos.cli.commands.agent:start",
    "stop": "bos.cli.commands.agent:stop",
    "status": "bos.cli.commands.agent:status",
    "restart": "bos.cli.commands.agent:restart",
    "task": "bos.cli.commands.agent:task",
    "tui": "bos.cli.commands.agent:tui",
}


class _LazyGroup(click.Group):
    """Click group that lazily imports command modules on first access."""

    def __init__(self, *args, lazy_commands: dict[str, str] | None = None, **kwargs):
        super().__init__(*args, **kwargs)
        self._lazy_commands = lazy_commands or {}

    def list_commands(self, ctx: click.Context) -> list[str]:
        return sorted(set(super().list_commands(ctx)) | set(self._lazy_commands))

    def get_command(self, ctx: click.Context, cmd_name: str) -> click.Command | None:
        if cmd := super().get_command(ctx, cmd_name):
            return cmd
        if cmd_name in self._lazy_commands:
            module_path, attr = self._lazy_commands[cmd_name].rsplit(":", 1)
            mod = importlib.import_module(module_path)
            return getattr(mod, attr)
        return None


@click.group(cls=_LazyGroup, lazy_commands=_LAZY_COMMANDS)
@click.option(
    "-w",
    "--workspace",
    type=click.Path(exists=False, file_okay=False, dir_okay=True),
    default=None,
    help="Path to the workspace directory.",
)
@click.pass_context
def cli(ctx, workspace):
    """BOS AI CLI"""
    import logging
    import os
    import sys

    logging.basicConfig(
        level=os.environ.get("BOS_LOG_LEVEL", "INFO").upper(),
        format="%(asctime)s %(levelname)-8s %(name)s %(message)s",
        stream=sys.stderr,
    )

    ctx.ensure_object(dict)
    ctx.obj["WORKSPACE"] = workspace or os.environ.get("BOS_WORKSPACE", ".")


def main():
    cli()


if __name__ == "__main__":
    main()
