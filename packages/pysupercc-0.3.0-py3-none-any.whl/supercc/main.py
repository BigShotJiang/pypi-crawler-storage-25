"""CLI entry point — starts WebSocket long connection to Feishu.

Config, sessions, and data all live in .supercc/ subdirectory of the current working directory.
"""
from __future__ import annotations

import argparse
import asyncio
import filelock
import logging
import os

from supercc.banner import print_banner
import shutil
import signal
import sys
from pathlib import Path


AGENTS_MD_CONTENT = """你是龙王 SuperCC，你是基于 claude code 的顶级智能体 Agent，你的任务是配合用户完成相关任务。

# 浏览器自动化
当用户需要浏览器自动化、阅读链接、搜索资料（打开本地浏览器使用百度搜索）相关的操作时，优先考虑使用：
- web access ( https://github.com/eze-is/web-access )
- browser harness ( https://github.com/browser-use/browser-harness.git )
- agent reach ( https://github.com/Panniantong/Agent-Reach )

# 编码工具
当用户需要写代码开发项目时，优先考虑使用两个技能：
- gstack ( https://github.com/garrytan/gstack )
- superpower ( https://github.com/obra/superpowers )

# 编码原则
## 四个原则详解

### 1. 编码前思考
不要假设。不要隐藏困惑。呈现权衡。

- 明确说明假设 — 如果不确定，询问而不是猜测
- 呈现多种解释 — 当存在歧义时，不要默默选择
- 适时提出异议 — 如果存在更简单的方法，说出来
- 困惑时停下来 — 指出不清楚的地方并要求澄清

### 2. 简洁优先
用最少的代码解决问题。不要过度推测。

- 不要添加要求之外的功能
- 不要为一次性代码创建抽象
- 不要为未要求的"灵活性"或"可配置性"
- 不要为不可能发生的场景做错误处理
- 如果 200 行代码可以写成 50 行，重写它

**检验标准：** 资深工程师会觉得这过于复杂吗？如果是，简化。

### 3. 精准修改
只碰必须碰的。只清理自己造成的混乱。

编辑现有代码时：
- 不要"改进"相邻的代码、注释或格式
- 不要重构没坏的东西
- 匹配现有风格，即使你更倾向于不同的写法
- 如果注意到无关的死代码，提一下 —— 不要删除它

当你的改动产生孤儿代码时：
- 删除因你的改动而变得无用的导入/变量/函数
- 不要删除预先存在的死代码，除非被要求

**检验标准：** 每一行修改都应该能直接追溯到用户的请求。

### 4. 目标驱动执行
定义成功标准。循环验证直到达成。

将指令式任务转化为可验证的目标：
| 不要这样做... | 转化为... |
|---|---|
| "添加验证" | "为无效输入编写测试，然后让它们通过" |
| "修复 bug" | "编写重现 bug 的测试，然后让它通过" |
| "重构 X" | "确保重构前后测试都能通过" |

对于多步骤任务，说明一个简短的计划：
1. [步骤] → 验证: [检查]
2. [步骤] → 验证: [检查]
3. [步骤] → 验证: [检查]

**强有力的成功标准**让 LLM 能够独立循环执行。弱标准（"让它工作"）需要不断澄清。
"""



def _ensure_agents_md(project_dir: str) -> None:
    """Ensure AGENTS.md exists in project_dir; create with default content if missing."""
    agents_md = Path(project_dir) / "AGENTS.md"
    if not agents_md.exists():
        agents_md.write_text(AGENTS_MD_CONTENT, encoding="utf-8")


from supercc.config import init_config, get_config, write_config, resolve_config_path, SESSIONS_DB_PATH
from supercc.channels.feishu.client import FeishuClient, IncomingMessage
from supercc.channels.feishu.ws_client import FeishuWSClient
from supercc.core.cron_scheduler import CronScheduler, _get_active_chat_id, _is_group_chat
from supercc.core.mcps.cron_tools import set_cron_scheduler

logger = logging.getLogger(__name__)


def _register_skill_optimization_job(data_dir: str, scheduler) -> None:
    """Register a daily skill optimization scan job.

    Creates a cron job that delivers results to the active user's P2P chat.
    Only registers if active chat is P2P (not group).
    Only recreates job if the prompt has changed from the existing one.
    """
    from supercc.core.cron_scheduler import list_jobs, create_job, delete_job

    chat_id = _get_active_chat_id(data_dir)
    if not chat_id:
        logger.info("[skill_optimize] no active chat_id, skipping")
        return

    if _is_group_chat(data_dir, chat_id):
        logger.info("[skill_optimize] active chat is a group, skipping registration")
        return

    prompt = """【Skill 优化扫描 — 直接动手，不要只给建议】

你是熟练的工程师，直接动手解决问题，不要只给建议。发现确定的问题就立即修复。

**操作步骤：**
1. 先查看 {SKILLS_DIR}/ 目录下已有的 Skill
2. 发现有以下情况就直接动手：
   - **过时/错误内容** → 直接更新 SKILL.md（不要给建议）
   - **多个 Skill 内容重复** → 合并到最完整的一个，删除其余
   - **发现新的值得推广的模式** → 直接新建 Skill
   - **Skill 内容已无价值** → **必须先问用户确认**（删除是唯一需要确认的操作）

3. 删除前必须先向用户确认，格式：
   ```
   发现 Skill「<skill-name>」可能过时，确定要删除吗？
   ```
   用户确认后才能删除，用户拒绝则跳过

4. 每次操作后立即 `git add` + `git commit`，不要等到最后才提交

5. {SKILLS_DIR}/ 本身是一个 Git 仓库。写入 SKILL.md 后，在 {SKILLS_DIR}/ 目录下执行：
   ```
   cd {SKILLS_DIR} && git add <skill-name>/ && git commit -m "<中文 commit message>"
   ```
   commit message 必须用中文，清晰说明本次改动内容

完成后输出简短报告：做了哪些新建/更新/合并/删除操作。"""

    # Only recreate if prompt changed
    existing = list_jobs(data_dir)
    for j in existing:
        if j.get("name") == "Skill 优化扫描":
            if j.get("prompt") == prompt:
                logger.info("[skill_optimize] prompt unchanged, skipping recreation")
                return
            delete_job(j["id"], data_dir)
            logger.info("[skill_optimize] prompt changed, removed old job, will recreate")
            break

    try:
        create_job(
            prompt=prompt,
            schedule="0 4 * * *",  # 每天凌晨4点执行
            chat_id=chat_id,
            name="Skill 优化扫描",
            repeat=None,
            data_dir=data_dir,
            verbose=False,  # 不推送中间过程，只在 notify_at 发最终结果
            notify_at="0 8 * * *",  # 早上8点通知结果
        )
        logger.info("[skill_optimize] registered daily scan at 4am, notify at 8am")
    except Exception as e:
        logger.warning(f"[skill_optimize] failed to register: {e}")


class _SafeStreamHandler(logging.StreamHandler):
    """StreamHandler that silently ignores UnicodeEncodeError on Windows GBK consoles."""

    def emit(self, record: logging.LogRecord) -> None:
        try:
            super().emit(record)
        except UnicodeEncodeError:
            # Fallback: encode with errors='replace' and write directly
            try:
                msg = self.format(record) + self.terminator
                encoded = msg.encode("utf-8", errors="replace").decode("utf-8", errors="replace")
                self.stream.write(encoded)
                self.flush()
            except Exception:
                pass


def _ensure_codex_mcp(config) -> None:
    """Best-effort Codex MCP setup for Claude Code."""
    try:
        from supercc.core.mcps.codex_mcp import ensure_codex_mcp_configured

        status = ensure_codex_mcp_configured(config.codex)
        logger.info("Codex MCP status: %s", status.state)
        if status.state in {"missing_cli", "conflict", "error"}:
            logger.warning("Codex MCP not ready: %s", status.message or status.state)
    except Exception:
        logger.warning("Failed to configure Codex MCP", exc_info=True)


# ANSI color codes for terminal output


class _BaseLogFormatter(logging.Formatter):
    """Shared helpers for log formatters.

    Format: [MM-DD HH:MM:SS.mmm]  LEVEL  [module]  message
    """

    def _format_time(self, record: logging.LogRecord) -> str:
        """Format timestamp as HH:MM:SS.mmm in gray."""
        ct = record.created
        ms = int((ct - int(ct)) * 1000)
        st = self.converter(ct)
        return f"\033[90m{st.tm_hour:02d}:{st.tm_min:02d}:{st.tm_sec:02d}.{ms:03d}\033[0m"

    def _get_module(self, record: logging.LogRecord) -> str:
        """Derive short module name from logger name.

        'supercc.channels.feishu.message_handler' -> 'feishu'
        'supercc.claude.integration' -> 'claude'
        'supercc' -> 'root'
        """
        name = record.name
        if name == "root" or not name:
            return "root"
        # websockets 库显示为 ws
        if name == "websockets":
            return "ws"
        parts = name.split(".")
        # Skip 'supercc' prefix, return first sub-module name
        if len(parts) >= 2:
            return parts[-2]
        return parts[-1]


class ColoredFormatter(_BaseLogFormatter):
    """Add ANSI color codes to log records based on level and module.

    Format: [MM-DD HH:MM:SS.mmm] LEVEL [module] message
    Colors: LEVEL by level, [module] + msg by module.
    """

    COLORS = {
        "DEBUG": "\033[36m",     # cyan
        "INFO": "\033[32m",      # green
        "WARNING": "\033[33m",   # yellow
        "ERROR": "\033[31m",     # red
        "CRITICAL": "\033[35m",  # magenta
    }
    MODULE_COLORS = {
        "supercc": "\033[38;5;214m",  # bright gold
        "evolve": "\033[32m",       # green
        "feishu": "\033[36m",       # cyan
        "adapter": "\033[33m",      # yellow
        "claude": "\033[35m",       # purple
        "gateway": "\033[31m",      # red
        "security": "\033[38;5;208m",  # orange
        "skill_search": "\033[38;5;213m",  # pink
        "core": "\033[38;5;75m",    # light blue
    }
    RESET = "\033[0m"

    def _get_module_color(self, module: str) -> str:
        for name, color in self.MODULE_COLORS.items():
            if module.startswith(name):
                return color
        return self.RESET

    def format(self, record: logging.LogRecord) -> str:
        ts = self._format_time(record)
        level_color = self.COLORS.get(record.levelname, self.RESET)
        level = f"{level_color}{record.levelname}{self.RESET}"
        module = self._get_module(record)
        module_color = self._get_module_color(module)
        module_part = f"{module_color}[{module}] {self.RESET}"
        msg = f"{module_color}{record.getMessage()}{self.RESET}"
        return f"{ts} {level} {module_part}{msg}"


class PlainFormatter(_BaseLogFormatter):
    """Plain log formatter for file output (no colors).

    Format: HH:MM:SS.mmm LEVEL [module] message
    """

    def format(self, record: logging.LogRecord) -> str:
        ts = self._format_time(record)
        level = record.levelname
        module = self._get_module(record)
        return f"{ts} {level:>5} [{module}] {record.getMessage()}"


def write_pid(pid_file: str) -> None:
    """Write current PID to file."""
    Path(pid_file).write_text(str(os.getpid()))


def remove_pid(pid_file: str) -> None:
    """Remove PID file."""
    Path(pid_file).unlink(missing_ok=True)


RISK_WARNING = """
⚠️  安全风险警告 / Security Risk Warning
==============================================================

supercc 以 bypassPermissions 模式运行。
Claude Code 可以执行任意终端命令、读写本地文件，无需每次授权确认。

这意味着如果有人通过飞书向机器人发送恶意指令，攻击者可以：
  • 在你的电脑上执行任意命令
  • 读取、修改或删除你的本地文件
  • 访问你的敏感信息

请仅在可信任的网络环境下使用本工具。

supercc runs in bypassPermissions mode.
Claude Code can execute arbitrary terminal commands and read/write local files
without asking for permission each time.

Do you understand and accept these risks? (yes/no): """


def confirm_risk_warning(config_path: str) -> bool:
    """Show risk warning and get user confirmation. Saves acceptance to config on 'yes'."""
    from supercc.config import accept_bypass_warning
    print(RISK_WARNING)
    while True:
        try:
            response = input().strip().lower()
            if response in ("yes", "y"):
                accept_bypass_warning(config_path)
                print("已记录，下次启动将不再提示。")
                return True
            elif response in ("no", "n", ""):
                print("Cancelled — not starting SuperCC.")
                return False
            else:
                print("Please enter 'yes' or 'no': ", end="")
        except EOFError:
            print("no (EOF)")
            return False


async def start_bridge(config_path: str, data_dir: str, foreground: bool = False) -> None:
    """Start SuperCC: core + plugins all in one asyncio event loop.

    Args:
        foreground: if True, skip PID file lock check and don't write supercc.pid.
                   适合开发调试，Ctrl+C 退出。
    """
    # Check if another instance is already running (pure PID file detection)
    pid_file = os.path.join(data_dir, "supercc.pid")
    if not foreground and os.path.exists(pid_file):
        try:
            old_pid = int(Path(pid_file).read_text().strip())
            os.kill(old_pid, 0)  # Signal 0 checks if process exists
            print(f"错误：当前已有一个 SuperCC 实例正在运行 (PID {old_pid}, {data_dir})")
            print("请先停止运行中的实例: supercc stop")
            sys.exit(1)
        except (ValueError, OSError):
            # PID file is stale (invalid or process dead), continue
            pass

    config = init_config(config_path)

    # Auto-generate token if not set (one-time setup)
    cfg = get_config()
    if not cfg.core.token:
        import secrets
        cfg.core.token = secrets.token_urlsafe(32)
        write_config(cfg)
        print(f"[Core] Token auto-generated: {cfg.core.token}")

    # 检测是否被系统服务托管
    from supercc.gateway.platform import _is_service_installed
    is_daemon = _is_service_installed(data_dir)
    cfg = get_config()
    if cfg.daemon != is_daemon:
        cfg.daemon = is_daemon
        write_config(cfg)

    # 打印启动模式 & 警告
    if is_daemon:
        logger.info("[SuperCC] 运行模式: daemon (服务托管)，PID 文件管理已启用")
    else:
        logger.info("[SuperCC] 运行模式: standalone (独立进程)")
        if foreground:
            logger.warning("[SuperCC] ⚠️  前台模式运行，进程不会持久化。如需持久运行，请使用: supercc gateway start")

    # Startup: initialize model env singleton with global ~/.supercc/model.json
    from supercc.core.models.model_config import init_model_env, ensure_project_model_config
    init_model_env(config.claude.approved_directory)
    ensure_project_model_config(config.claude.approved_directory)

    # Startup: ensure Claude Code onboarding is complete (幂等，重复调用无影响)
    _ensure_codex_mcp(config)

    _ensure_agents_md(config.claude.approved_directory)

    # 清空日志文件（每次启动重新开始）
    try:
        log_path = os.path.join(data_dir, "supercc.log")
        # 写 banner 到日志文件
        from supercc.banner import write_log_banner
        from supercc import __version__ as _ver
        with open(log_path, "w") as f:
            f.write("=" * 64 + "\n")
            f.write("  龙王 SuperCC\n")
            f.write(f"  v{_ver}\n")
            f.write(f"  启动时间: {__import__('datetime').datetime.now().strftime('%Y-%m-%d %H:%M:%S')}\n")
            f.write("  自进化超级 AI · 越用越懂你\n")
            f.write("=" * 64 + "\n")
    except Exception:
        pass

    # Write PID file for process management (skip in foreground mode)
    if not foreground:
        pid_file = os.path.join(data_dir, "supercc.pid")
        write_pid(pid_file)

    logger.info(f"Starting SuperCC (async mode) — data: {data_dir}")

    # Warn if git is not available
    from supercc.banner import _check_git_available
    if not _check_git_available():
        logger.warning("[SuperCC] 未检测到 git，跳过 Git 相关功能。如需使用 /git 命令，请安装 git；或跟SuperCC说: \"安装 git\"")

    # Create media subdirectories
    for sub in ("received_images", "received_files"):
        sub_dir = os.path.join(data_dir, sub)
        os.makedirs(sub_dir, exist_ok=True)

    # ── Phase 2: Core WsServer（在同一个 event loop 中）─────────────────────
    core_port = config.core.port
    from supercc.core.session import SessionManager, DEFAULT_SESSIONS_DB_PATH
    from supercc.core.worker import WorkerPool
    from supercc.core.executor import CoreExecutor
    from supercc.core.server import WsServer

    session_manager = SessionManager(db_path=DEFAULT_SESSIONS_DB_PATH)
    worker_pool = WorkerPool()
    executor = CoreExecutor(
        session_manager=session_manager,
        worker_pool=worker_pool,
        config=config,
        data_dir=data_dir,
        config_path=config_path,
    )
    core_server = WsServer(
        host="127.0.0.1",
        port=core_port,
        executor=executor,
    )
    await core_server.start()
    logger.info(f"[Phase2] Core WsServer started on port {core_port}")

    # ── Plugin restart helper ───────────────────────────────────────────────
    async def _run_plugin_with_restart(name: str, config, data_dir, delay: float = 5.0):
        """运行一个 plugin task，崩溃后自动重启。"""
        while True:
            try:
                if name == "feishu":
                    from supercc.channels.feishu.__main__ import run_plugin as _run
                elif name == "wecom":
                    from supercc.channels.wecom.__main__ import run_plugin as _run
                await _run(config, data_dir)
            except asyncio.CancelledError:
                raise  # 有序关闭时会被外层 cancel，不继续重启
            except Exception:
                import traceback
                logger.error(f"plugin crashed, restarting in {delay}s\n{traceback.format_exc()}")
                await asyncio.sleep(delay)

    # ── Phase 3: Plugin async tasks（不复用旧 plugin __main__，直接 import）──
    plugin_tasks: list[asyncio.Task] = []

    # 飞书
    _feishu_cfg = getattr(config.channels, "feishu", None)
    if _feishu_cfg and getattr(_feishu_cfg, "enabled", False) and getattr(_feishu_cfg, "app_id", ""):
        task = asyncio.create_task(
            _run_plugin_with_restart("feishu", config, data_dir),
            name="feishu-plugin"
        )
        plugin_tasks.append(task)
        logger.info("[Bridge] Feishu plugin started (async task)")

    # 企业微信
    _wecom_cfg = getattr(config.channels, "wecom", None)
    if _wecom_cfg and getattr(_wecom_cfg, "enabled", False) and getattr(_wecom_cfg, "corp_id", ""):
        task = asyncio.create_task(
            _run_plugin_with_restart("wecom", config, data_dir),
            name="wecom-plugin"
        )
        plugin_tasks.append(task)
        logger.info("[Bridge] WeCom plugin started (async task)")

    # ── 首次使用提示 ────────────────────────────────────────────────────────
    from supercc.core.models.model_config import has_project_model_config
    cfg_path = Path(data_dir) / "config.json"
    cfg_configured = cfg_path.exists() and cfg_path.stat().st_size > 3
    if not cfg_configured or not has_project_model_config(config.claude.approved_directory):
        print("\n📋 **首次运行检测**：项目尚未完成初始配置。")
        print("   请执行以下命令完成初始化设置：")
        print("   supercc onboard\n")
        return

    # ── Phase 4: Cron scheduler ────────────────────────────────────────────
    cron_scheduler = CronScheduler(config, data_dir)
    set_cron_scheduler(cron_scheduler, config)
    cron_scheduler.start()
    cron_task = asyncio.create_task(cron_scheduler._run(), name="cron-scheduler")
    logger.info("[Phase4] CronScheduler started")

    # Ensure skills directory is a git repo (init if needed)
    from supercc.core.evolve.skill_nudge import _ensure_skills_git_repo
    _ensure_skills_git_repo(Path(data_dir) / "skills")

    # Register daily skill optimization scan
    _register_skill_optimization_job(data_dir, cron_scheduler)

    # Register nightly dream job (memory refinement at 3am)
    from supercc.core.evolve.dream import register_dream_job
    register_dream_job(data_dir)

    # ── Graceful shutdown ──────────────────────────────────────────────────
    stop_event = asyncio.Event()

    def _on_signal():
        logger.info("Received shutdown signal, stopping...")
        stop_event.set()

    loop = asyncio.get_running_loop()
    for sig in (signal.SIGINT, signal.SIGTERM):
        try:
            loop.add_signal_handler(sig, _on_signal)
        except NotImplementedError:
            pass  # Windows 不支持 add_signal_handler

    try:
        await stop_event.wait()
    finally:
        # 1. Cancel plugin tasks
        for task in plugin_tasks:
            if not task.done():
                task.cancel()
                try:
                    await task
                except asyncio.CancelledError:
                    pass
                except Exception:
                    pass
        # Wait 0.5s for plugin graceful shutdown
        await asyncio.sleep(0.5)

        # 2. Cancel cron task
        if 'cron_task' in locals() and not cron_task.done():
            cron_task.cancel()
            try:
                await cron_task
            except asyncio.CancelledError:
                pass
        await asyncio.sleep(0.5)

        # 3. Stop core server
        if core_server:
            await core_server.stop()

        remove_pid(pid_file)
        logger.info("SuperCC stopped gracefully")
        import os as _os
        _os._exit(0)


def start_core_only(config_path: str, data_dir: str):
    """仅启动 Core (WsServer + CronScheduler)，不启动任何 Channel。

    进程隔离后，这是 supercc-main 服务的入口。
    """
    # 1. 获取锁（复用现有代码）
    lock_file = os.path.join(data_dir, ".instance.lock")
    lock = filelock.FileLock(lock_file, timeout=1)
    global _active_lock
    _active_lock = lock
    try:
        lock.acquire()
    except filelock.Timeout:
        print(f"错误：当前已有一个 SuperCC 实例正在运行 ({data_dir})")
        print("如果确认没有实例在运行，请删除 .instance.lock 文件后重试。")
        sys.exit(1)

    # 2. 初始化 config, model env（复用现有代码）
    config = init_config(config_path)
    from supercc.core.models.model_config import init_model_env, ensure_project_model_config
    init_model_env(config.claude.approved_directory)
    ensure_project_model_config(config.claude.approved_directory)
    _ensure_codex_mcp(config)
    _ensure_agents_md(config.claude.approved_directory)

    # 3. 写 PID 文件
    pid_file = os.path.join(data_dir, "supercc.pid")
    write_pid(pid_file)

    # 4. 创建 media 子目录
    for sub in ("received_images", "received_files"):
        sub_dir = os.path.join(data_dir, sub)
        os.makedirs(sub_dir, exist_ok=True)

    # 5. 启动 Core WsServer（从 config 读取端口！）
    core_port = config.core.port  # 从 config 读，不是写死 8765
    logger.info(f"[Phase2] Starting Core WsServer on port {core_port}")

    # 用于 cleanup handler
    cron_scheduler = None
    core_server = None

    def run_core_server():
        import asyncio
        from supercc.core.session import SessionManager, DEFAULT_SESSIONS_DB_PATH
        from supercc.core.worker import WorkerPool
        from supercc.core.executor import CoreExecutor
        from supercc.core.server import WsServer

        session_manager = SessionManager(db_path=DEFAULT_SESSIONS_DB_PATH)
        worker_pool = WorkerPool()
        executor = CoreExecutor(
            session_manager=session_manager,
            worker_pool=worker_pool,
            config=config,
            data_dir=data_dir,
            config_path=config_path,
        )
        nonlocal core_server
        core_server = WsServer(
            host="127.0.0.1",
            port=core_port,  # 从 config 读取
            executor=executor,
        )
        loop = asyncio.new_event_loop()
        asyncio.set_event_loop(loop)
        loop.run_until_complete(core_server.start())
        loop.run_forever()

    import threading
    core_thread = threading.Thread(target=run_core_server, daemon=True)
    core_thread.start()
    logger.info("[Phase2] Core WsServer started in background thread")

    # 6. 启动 CronScheduler
    cron_scheduler = CronScheduler(config, data_dir)
    set_cron_scheduler(cron_scheduler, config)
    cron_scheduler.start()
    logger.info("[Phase2] CronScheduler started")

    # 7. 注册 cleanup signal handler
    def cleanup(signum, frame):
        nonlocal cron_scheduler, core_server
        if cron_scheduler:
            cron_scheduler.stop()
        if core_server:
            import asyncio as _asyncio
            _asyncio.run(core_server.stop())
        remove_pid(pid_file)
        lock.release()
        sys.exit(0)
    signal.signal(signal.SIGINT, cleanup)
    signal.signal(signal.SIGTERM, cleanup)

    # 8. 阻塞主线程（让 daemon thread 一直运行）
    import time
    while True:
        time.sleep(3600)


def list_bridges() -> None:
    """List SuperCC instances by checking the current directory's .supercc/ directory."""
    project_data_dir = os.path.join(os.getcwd(), ".supercc")
    pid_file = os.path.join(project_data_dir, "supercc.pid")
    print(f"\nSuperCC data directory: {project_data_dir}")
    print(f"{'PID':<8} {'Status':<20}")
    print("-" * 40)

    if not os.path.exists(pid_file):
        print("No running instances found.")
        print()
        return

    try:
        pid = int(Path(pid_file).read_text().strip())
        try:
            os.kill(pid, 0)
            status = "running"
        except OSError:
            status = "dead (clean up pid file)"
        print(f"{pid:<8} {status}")
    except (ValueError, OSError):
        print("Invalid PID file.")
    print()


def stop_bridge(pid: int) -> None:
    """Stop a SuperCC instance by PID."""
    try:
        os.kill(pid, signal.SIGTERM)
        print(f"Stopped PID {pid}")
    except OSError as e:
        print(f"Failed to stop PID {pid}: {e}")


def detect_config() -> tuple[bool, bool]:
    """Check config usability and YAML presence (does NOT create files).

    Returns (is_installed, yaml_exists):
    - is_installed: True if config.json is non-empty
    - yaml_exists: True if config.json exists (for migration)
    """
    # Use same logic as resolve_config_path() but WITHOUT creating files
    cwd = os.getcwd()
    cfg_dir = Path(cwd).resolve() / ".supercc"
    json_path = cfg_dir / "config.json"
    yaml_path = cfg_dir / "config.json"
    yaml_exists = yaml_path.exists() and yaml_path.stat().st_size > 0
    is_installed = json_path.exists() and json_path.stat().st_size > 0
    return (is_installed, yaml_exists)


async def interactive_install() -> tuple[str, str]:
    """Run the QR-code install flow. Returns (cfg_path, data_dir) on success."""
    from supercc.install.flow import run_install_flow
    cfg_path, data_dir = resolve_config_path()
    await run_install_flow(cfg_path)
    return cfg_path, data_dir


SUPPORTED_IMAGE_EXTS = {".png", ".jpg", ".jpeg", ".gif", ".webp", ".bmp"}
MAX_FILE_SIZE = 30 * 1024 * 1024  # 30MB


def _run_config_interactive() -> None:
    """交互式配置菜单（顶层：model / gateway / channel）。"""
    import questionary
    dirty = [False]  # 追踪是否有配置变更

    while True:
        choice = questionary.select(
            "SuperCC 配置",
            choices=[
                questionary.Choice("🔀  模型", value="model", description="添加/切换/删除模型"),
                questionary.Choice("🌐  Gateway", value="gateway", description="监听地址/端口/认证配置"),
                questionary.Choice("💬  Channel", value="channel", description="飞书/企微插件启用状态、凭证"),
                questionary.Choice("↩️  继续", value="continue"),
            ],
            style=questionary.Style([
                ("selected", "fg:#00AA00 bold"),
                ("choice", "fg:#CCCCCC"),
                ("pointer", "fg:#00AA00 bold"),
            ]),
        ).ask()
        if choice == "continue" or choice is None:
            if dirty[0]:
                print("\n⚠️  配置已变更，正在重启 SuperCC...\n")
                from supercc.gateway.cli import run_gateway_restart
                run_gateway_restart()
                return
            break
        elif choice == "model":
            _run_config_model_interactive(dirty)
        elif choice == "gateway":
            _run_config_gateway_interactive(dirty)
        elif choice == "channel":
            _run_config_channel_interactive(dirty)


def _run_config_model_interactive(dirty: list) -> None:
    """交互式模型配置子菜单（一页式，跟 onboard 风格一致）。"""
    import questionary
    from supercc.core.models.model_config import (
        ModelEnv,
        get_all_models,
        get_active_model,
        switch_model,
        delete_model,
        validate_model_env,
        init_model_env,
    )
    from supercc.core.models.model_providers import PROVIDERS
    auth_display_map = {"bearer": "Bearer API Key", "api_key": "API Key", "azure": "Azure AD Token"}

    models = get_all_models()
    active_entry = get_active_model()
    active_id = None
    if active_entry:
        for mid, mentry in models.items():
            if mentry.env.ANTHROPIC_BASE_URL == active_entry.env.ANTHROPIC_BASE_URL:
                active_id = mid
                break

    choices = []
    if active_entry:
        choices.append(questionary.Choice("🔄  " + active_entry.name + "  ✅", value="manage_active"))
    for mid, mentry in models.items():
        if mid == active_id:
            continue
        choices.append(questionary.Choice("   " + mentry.name, value=mid))
    choices.append(questionary.Choice("➕  添加新模型", value="add"))
    choices.append(questionary.Choice("↩️  返回上级", value="back"))

    choice = questionary.select(
        "模型配置",
        choices=choices,
        style=questionary.Style([
            ("selected", "fg:#00AA00 bold"),
            ("choice", "fg:#CCCCCC"),
            ("pointer", "fg:#00AA00 bold"),
        ]),
    ).ask()
    if choice == "back" or choice is None:
        return

    # ── 添加新模型 ────────────────────────────────────────────────────────────
    if choice == "add":
        from supercc.core.models.model_config import get_all_providers
        all_providers_data = get_all_providers()

        configured, unconfigured = [], []
        for pid, p in PROVIDERS.items():
            pdata = all_providers_data.get(pid)
            has_key = pdata and pdata.api_key
            (configured if has_key else unconfigured).append((pid, p))

        from dataclasses import dataclass
        @dataclass
        class _CP:
            id: str; base_url: str; models: list
        for pid in all_providers_data:
            if pid in PROVIDERS:
                continue
            pdata = all_providers_data.get(pid)
            if pdata and pdata.api_key:
                configured.append((pid, _CP(id=pid, base_url=pdata.base_url or "", models=pdata.models or [])))

        provider_choices = []
        for pid, p in configured:
            provider_choices.append(questionary.Choice(pid + "  (" + (p.base_url or "用户填入") + ")  ✅", value=pid))
        for pid, p in unconfigured:
            provider_choices.append(questionary.Choice(pid + "  (" + (p.base_url or "用户填入") + ")", value=pid))
        provider_choices.append(questionary.Choice("──────────────", value="__sep__", disabled=True))
        provider_choices.append(questionary.Choice("✨ 新增自定义供应商", value="__add__"))

        provider_id = questionary.select(
            "请选择供应商（✅ = 已配置过 API Key）",
            choices=provider_choices,
            style=questionary.Style([
                ("selected", "fg:#00AA00 bold"),
                ("choice", "fg:#CCCCCC"),
                ("pointer", "fg:#00AA00 bold"),
                ("separator", "fg:#555555"),
            ]),
        ).ask()
        if not provider_id or provider_id == "__sep__":
            return

        # ── 自定义供应商 ──────────────────────────────────────────────────────
        if provider_id == "__add__":
            base_url = questionary.text("Base URL（例如 https://api.example.com/v1）", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
            if not base_url:
                print("⚠️  未提供 Base URL，已取消")
                return
            base_url = base_url.strip().rstrip("/")
            selected_model = questionary.text("模型 ID（例如 gpt-4）", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
            if not selected_model:
                print("⚠️  模型 ID 不能为空，已取消")
                return
            selected_model = selected_model.strip()
            token = questionary.password("API Key", style=questionary.Style([("password", "fg:#CCCCCC")])).ask()
            if not token:
                print("⚠️  未提供 API Key，已取消")
                return
            import re, hashlib
            provider_name_raw = questionary.text("供应商名称（英文/数字）", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
            provider_name = provider_name_raw.strip() if provider_name_raw else "custom"
            if not re.fullmatch(r'[a-zA-Z0-9]+', provider_name):
                print("❌ 供应商名称只允许英文字母和数字")
                return
            if provider_name in PROVIDERS:
                print(f"❌ '{provider_name}' 是内置供应商，请使用其他名称")
                return
            env = ModelEnv(ANTHROPIC_AUTH_TOKEN=token, ANTHROPIC_BASE_URL=base_url, ANTHROPIC_MODEL=selected_model)
            valid, err = validate_model_env(env)
            if not valid:
                print(f"❌ API 验证失败: {err}")
                return
            from supercc.core.models.model_config import _load_json, _save_json
            raw = _load_json()
            raw.setdefault("providers", {})[provider_name] = {"api_key": token, "models": [selected_model], "base_url": base_url, "provider_name": provider_name}
            _save_json(raw)
            from supercc.config import resolve_config_path
            _, data_dir = resolve_config_path()
            import os
            project_path = os.path.dirname(os.path.dirname(data_dir))
            from supercc.core.models.model_config import set_project_model
            set_project_model(project_path, provider_name, selected_model)
            init_model_env(project_path)
            dirty[0] = True
            print(f"\n✅ 自定义供应商已添加并设为激活")
            print(f"   供应商: {provider_name}")
            print(f"   模型: `{selected_model}`")
            return

        # ── 预置供应商 ───────────────────────────────────────────────────────
        provider = PROVIDERS.get(provider_id)
        pdata = all_providers_data.get(provider_id)
        has_existing_key = pdata and pdata.api_key

        model_choices = [questionary.Choice(f"`{m}`", value=m) for m in provider.models]
        selected_model = questionary.select(f"请选择模型（{provider.id}）", choices=model_choices, style=questionary.Style([("selected", "fg:#00AA00 bold"), ("choice", "fg:#CCCCCC"), ("pointer", "fg:#00AA00 bold")])).ask()
        if not selected_model:
            return

        if has_existing_key:
            token = pdata.api_key
        else:
            auth_label = auth_display_map.get(provider.auth_type, provider.auth_type)
            token = questionary.password(f"API Key（{auth_label}）", style=questionary.Style([("password", "fg:#CCCCCC")])).ask()
            if not token:
                print("⚠️  未提供 API Key，已取消")
                return
            from supercc.core.models.model_config import update_provider_api_key
            ok, err = update_provider_api_key(provider_id, token)
            if not ok:
                print(f"❌ API Key 保存失败: {err}")
                return

        env = ModelEnv(ANTHROPIC_AUTH_TOKEN=token, ANTHROPIC_BASE_URL=provider.base_url, ANTHROPIC_MODEL=selected_model)
        valid, err = validate_model_env(env)
        if not valid:
            print(f"❌ API 验证失败: {err}")
            return

        from supercc.config import resolve_config_path
        _, data_dir = resolve_config_path()
        import os
        project_path = os.path.dirname(os.path.dirname(data_dir))
        from supercc.core.models.model_config import set_project_model
        set_project_model(project_path, provider_id, selected_model)
        init_model_env(project_path)
        dirty[0] = True
        print(f"\n✅ 模型 {provider.id}/{selected_model} 已添加并设为激活")
        return

    # ── 管理已激活模型 ─────────────────────────────────────────────────────────
    if choice == "manage_active":
        entry = active_entry
        sub_choices = [
            questionary.Choice("🔄  重新配置凭证", value="reconfigure"),
            questionary.Choice("🗑  删除此模型", value="delete"),
        ]
        other_models = [(m, e) for m, e in models.items() if m != active_id]
        if other_models:
            sub_choices.append(questionary.Choice("🔀  切换到其他模型", value="switch"))
        sub_choices.append(questionary.Choice("↩️  返回上级", value="back"))

        sub = questionary.select(entry.name, choices=sub_choices, style=questionary.Style([("selected", "fg:#00AA00 bold"), ("choice", "fg:#CCCCCC"), ("pointer", "fg:#00AA00 bold")])).ask()
        if sub == "back" or sub is None:
            return

        if sub == "delete":
            confirm = questionary.confirm(f"确认删除模型 `{active_id}`？", default=False, style=questionary.Style([("selected", "fg:#FF5555 bold")])).ask()
            if not confirm:
                return
            delete_model(active_id)
            dirty[0] = True
            print("✅ 模型已删除")
            return

        if sub == "switch":
            other_choices = [questionary.Choice(e.name, value=m) for m, e in other_models]
            target_id = questionary.select("切换到", choices=other_choices, style=questionary.Style([("selected", "fg:#00AA00 bold"), ("choice", "fg:#CCCCCC"), ("pointer", "fg:#00AA00 bold")])).ask()
            if not target_id:
                return
            switch_model(target_id)
            dirty[0] = True
            print(f"✅ 已切换到 {models[target_id].name}")
            return

        if sub == "reconfigure":
            provider_id = active_id
            for pid in PROVIDERS:
                if pid in active_id or active_id in pid:
                    provider_id = pid
                    break
            provider = PROVIDERS.get(provider_id)
            if not provider:
                print("⚠️  找不到对应供应商，请删除后重新添加")
                return
            auth_label = auth_display_map.get(provider.auth_type, provider.auth_type)
            token = questionary.password(f"新的 API Key（{auth_label}）", style=questionary.Style([("password", "fg:#CCCCCC")])).ask()
            if not token:
                print("⚠️  未提供 API Key，已取消")
                return
            env = ModelEnv(ANTHROPIC_AUTH_TOKEN=token, ANTHROPIC_BASE_URL=provider.base_url, ANTHROPIC_MODEL=active_entry.env.ANTHROPIC_MODEL)
            valid, err = validate_model_env(env)
            if not valid:
                print(f"❌ API 验证失败: {err}")
                return
            from supercc.core.models.model_config import update_provider_api_key
            ok, err = update_provider_api_key(provider_id, token)
            if ok:
                dirty[0] = True
                print("✅ 凭证已更新")
            else:
                print(f"❌ 保存失败: {err}")
            return

    # ── 切换到其他已配置模型 ─────────────────────────────────────────────────
    if choice in models and choice != active_id:
        switch_model(choice)
        dirty[0] = True
        print(f"✅ 已切换到 {models[choice].name}")


def _run_config_gateway_interactive(dirty: list) -> None:
    """交互式 Gateway/Core 配置子菜单（一页式展示当前状态）。"""
    import questionary
    from supercc.config import resolve_config_path, init_config, get_config, write_config
    import secrets
    cfg_path, _ = resolve_config_path()
    init_config(cfg_path)
    cfg = get_config()

    auth_mode = "Token" if cfg.core.token else ("用户名密码" if cfg.core.username else "未配置")

    choices = [
        questionary.Choice("🔑  Token（重新生成）", value="token"),
        questionary.Choice("👤  账号密码（设置/清除）", value="auth"),
        questionary.Choice("🌐  监听地址（" + cfg.core.host + "）", value="host"),
        questionary.Choice("🔌  监听端口（" + str(cfg.core.port) + "）", value="port"),
        questionary.Choice("↩️  返回上级", value="back"),
    ]

    choice = questionary.select(
        "Gateway 配置",
        choices=choices,
        style=questionary.Style([
            ("selected", "fg:#00AA00 bold"),
            ("choice", "fg:#CCCCCC"),
            ("pointer", "fg:#00AA00 bold"),
        ]),
    ).ask()
    if choice == "back" or choice is None:
        return

    if choice == "token":
        new_token = secrets.token_urlsafe(32)
        cfg.core.token = new_token
        write_config(cfg)
        dirty[0] = True
        print(f"✅ Token 已生成并保存: {new_token}")
        return

    if choice == "auth":
        username = questionary.text("用户名（回车清除）", default=cfg.core.username or "", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
        if username is None:
            return
        password = questionary.password("密码（回车清除）", style=questionary.Style([("password", "fg:#CCCCCC")])).ask()
        if password is None:
            return
        cfg.core.username = username
        cfg.core.password = password
        write_config(cfg)
        dirty[0] = True
        if username:
            print(f"✅ 账号密码已保存: {username}")
        else:
            print("✅ 账号密码已清除")
        return

    if choice == "host":
        host = questionary.select(
            "监听地址",
            choices=[
                questionary.Choice("127.0.0.1（推荐，仅本机）", value="127.0.0.1"),
                questionary.Choice("0.0.0.0（对外部开放）", value="0.0.0.0"),
            ],
            style=questionary.Style([("selected", "fg:#00AA00 bold"), ("choice", "fg:#CCCCCC"), ("pointer", "fg:#00AA00 bold")]),
        ).ask()
        if not host:
            return
        cfg.core.host = host
        write_config(cfg)
        dirty[0] = True
        print(f"✅ 监听地址已设置为: {host}（重启后生效）")
        return

    if choice == "port":
        port_str = questionary.text("端口（默认 28888）", default=str(cfg.core.port), style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
        if not port_str:
            return
        try:
            port = int(port_str)
            cfg.core.port = port
            write_config(cfg)
            dirty[0] = True
            print(f"✅ 端口已设置为: {port}（重启后生效）")
        except ValueError:
            print("❌ 端口必须是数字")
        return



def _run_config_channel_interactive(dirty: list) -> None:
    """交互式 Channel 插件子菜单（跟 onboard 风格一致）。"""
    import questionary
    import asyncio
    from supercc.config import resolve_config_path, init_config, get_config, write_config
    cfg_path, _ = resolve_config_path()
    init_config(cfg_path)
    cfg = get_config()

    feishu = cfg.channels.feishu
    wecom = cfg.channels.wecom
    feishu_status = "✅ 已配置" if feishu.app_id else "❌ 未配置"
    wecom_status = "✅ 已配置" if wecom.corp_id else "❌ 未配置"

    choice = questionary.select(
        "Channel 配置",
        choices=[
            questionary.Choice("📡  飞书 " + feishu_status, value="feishu"),
            questionary.Choice("💬  企业微信 " + wecom_status, value="wecom"),
            questionary.Choice("↩️  返回上级", value="back"),
        ],
        style=questionary.Style([
            ("selected", "fg:#00AA00 bold"),
            ("choice", "fg:#CCCCCC"),
            ("pointer", "fg:#00AA00 bold"),
        ]),
    ).ask()
    if choice == "back" or choice is None:
        return

    if choice == "feishu":
        if feishu.app_id:
            sub = questionary.select(
                "飞书已配置",
                choices=[
                    questionary.Choice("🔄  重新配置", value="reconfigure"),
                    questionary.Choice("🗑  删除配置", value="delete"),
                    questionary.Choice("↩️  返回上级", value="back"),
                ],
                style=questionary.Style([("selected", "fg:#00AA00 bold"), ("choice", "fg:#CCCCCC"), ("pointer", "fg:#00AA00 bold")]),
            ).ask()
            if sub == "back" or sub is None:
                return
            if sub == "delete":
                confirm = questionary.confirm("确认删除飞书配置？", default=False, style=questionary.Style([("selected", "fg:#FF5555 bold")])).ask()
                if not confirm:
                    return
                feishu.app_id = ""
                feishu.app_secret = ""
                feishu.bot_open_id = ""
                feishu.enabled = False
                write_config(cfg)
                dirty[0] = True
                print("✅ 飞书配置已删除")
                return
            if sub == "reconfigure":
                app_id = questionary.text("App ID", default=feishu.app_id or "", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
                if not app_id:
                    print("⚠️  App ID 不能为空")
                    return
                app_secret = questionary.password("App Secret", style=questionary.Style([("password", "fg:#CCCCCC")])).ask()
                feishu.app_id = app_id
                if app_secret:
                    feishu.app_secret = app_secret
                write_config(cfg)
                dirty[0] = True
                print("✅ 飞书凭证已保存（重启后生效）")
                return
        else:
            print("\n正在配置飞书...\n")
            try:
                from supercc.install.flow import run_install_flow
                asyncio.run(run_install_flow(cfg_path, bypass_accepted=True))
                print("✅ 飞书配置完成\n")
            except Exception as e:
                print(f"⚠️  飞书配置出错：{e}\n")
            return

    if choice == "wecom":
        if wecom.corp_id:
            sub = questionary.select(
                "企业微信已配置",
                choices=[
                    questionary.Choice("🔄  重新配置", value="reconfigure"),
                    questionary.Choice("🗑  删除配置", value="delete"),
                    questionary.Choice("↩️  返回上级", value="back"),
                ],
                style=questionary.Style([("selected", "fg:#00AA00 bold"), ("choice", "fg:#CCCCCC"), ("pointer", "fg:#00AA00 bold")]),
            ).ask()
            if sub == "back" or sub is None:
                return
            if sub == "delete":
                confirm = questionary.confirm("确认删除企业微信配置？", default=False, style=questionary.Style([("selected", "fg:#FF5555 bold")])).ask()
                if not confirm:
                    return
                wecom.corp_id = ""
                wecom.agent_id = ""
                wecom.secret = ""
                wecom.enabled = False
                write_config(cfg)
                dirty[0] = True
                print("✅ 企业微信配置已删除")
                return
            if sub == "reconfigure":
                corp_id = questionary.text("Corp ID", default=wecom.corp_id or "", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
                if not corp_id:
                    print("⚠️  Corp ID 不能为空")
                    return
                agent_id = questionary.text("Agent ID", default=wecom.agent_id or "", style=questionary.Style([("input", "fg:#CCCCCC")])).ask()
                secret = questionary.password("Secret", style=questionary.Style([("password", "fg:#CCCCCC")])).ask()
                wecom.corp_id = corp_id
                if agent_id:
                    wecom.agent_id = agent_id
                if secret:
                    wecom.secret = secret
                write_config(cfg)
                dirty[0] = True
                print("✅ 企业微信凭证已保存（重启后生效）")
                return
        else:
            print("\n正在配置企业微信...\n")
            import subprocess, sys
            subprocess.run([sys.executable, "-m", "pip", "install", "wecom-aibot-sdk-python", "--quiet"], capture_output=True)
            try:
                from supercc.install.wecom_flow import run_wecom_install_flow
                run_wecom_install_flow(cfg_path, bypass_accepted=True)
                print("✅ 企业微信配置完成\n")
            except Exception as e:
                print(f"⚠️  企业微信配置出错：{e}\n")
            return



def _run_config_command(args) -> None:
    """Handle supercc config <action> [args]."""
    from supercc.core.models.model_config import (
        get_all_models,
        get_active_model,
        switch_model,
        add_model,
        delete_model,
        ModelEnv,
        is_configured,
    )

    action = getattr(args, "config_action", None)
    raw_args = getattr(args, "config_args", "") or ""
    if isinstance(raw_args, list):
        raw_args = " ".join(raw_args)

    def _parse_args(args_str: str) -> list[str]:
        return [p.strip() for p in args_str.split("|")]

    def _fmt_model(model_id: str, entry, is_active: bool) -> str:
        active_mark = "✅ " if is_active else "   "
        env = entry.env
        token_display = f"***{env.ANTHROPIC_AUTH_TOKEN[-4:]:>4}" if env.ANTHROPIC_AUTH_TOKEN else "(未设置)"
        return (
            f"{active_mark}**{entry.name}** (`{model_id}`)\n"
            f"    描述: {entry.description or '(无)'}\n"
            f"    模型: `{env.ANTHROPIC_MODEL}`\n"
            f"    端点: `{env.ANTHROPIC_BASE_URL}`\n"
            f"    Token: ...{token_display}"
        )

    # 无 action（交互式菜单）或 list（只显示）
    if action is None:
        # 直接进入交互菜单，不打印模型列表
        _run_config_interactive()
        return

    if action == "list":
        if not is_configured():
            current_settings = {}
            try:
                from supercc.core.models.model_config import get_current_claude_settings
                current_settings = get_current_claude_settings()
            except Exception:
                pass
            env_cfg = current_settings.get("env", {})
            if env_cfg.get("ANTHROPIC_AUTH_TOKEN"):
                print("📋 **检测到您已配置过 Claude Code**\n")
                print("您的现有配置：")
                print(f"- 模型: `{env_cfg.get('ANTHROPIC_MODEL', '未设置')}`")
                print(f"- 端点: `{env_cfg.get('ANTHROPIC_BASE_URL', '未设置')}`")
                print("\n💡 **建议**: 使用 `supercc config add ...` 将现有配置导入为第一个模型。")
                print("\n用法: supercc config add --provider <provider_id> <api_key> <model>")
            else:
                print("📋 **尚未配置任何模型**")
                print("\n用法: supercc config add --provider <provider_id> <api_key> <model>")
                print("\n可用供应商: supercc config providers")
            return

        models = get_all_models()
        active_entry = get_active_model()
        active_id = None
        if active_entry:
            for mid, mentry in models.items():
                if mentry.env.ANTHROPIC_BASE_URL == active_entry.env.ANTHROPIC_BASE_URL:
                    active_id = mid
                    break

        # 只显示有有效 API key 的模型（过滤掉未配置的）
        configured_models = {
            mid: entry for mid, entry in models.items()
            if entry.env.ANTHROPIC_AUTH_TOKEN
        }
        if not configured_models:
            print("📋 **尚未配置任何模型**")
            print("\n用法: supercc config add --provider <provider_id> <api_key> <model>")
            print("\n可用供应商: supercc config providers")
            return

        print("🔀 **已配置的模型**\n")
        for model_id, entry in configured_models.items():
            print(_fmt_model(model_id, entry, is_active=(model_id == active_id)))
            print()
        print(f"\n当前激活: `{(active_id or '未知')}`")
        return

    if action == "add":
        provider_id = getattr(args, "provider", "") or ""

        if provider_id:
            # --provider 快捷模式
            from supercc.core.models.model_providers import get_provider, PROVIDERS
            provider = get_provider(provider_id)
            if not provider:
                available = ", ".join(f"`{p}`" for p in PROVIDERS.keys())
                print(f"未知供应商 `{provider_id}`\n可用供应商: {available}")
                return
            if provider_id == "custom":
                print("错误: 不支持 `--provider custom` 快捷方式")
                print("用法: supercc config add <model_id>|<name>|<description>|<api_key>|<base_url>|<model>")
                print("示例: supercc config add my-model|MyModel|自定义|gpt-4-api-key|https://api.example.com/v1|gpt-4")
                return

            pos_args = raw_args.split() if raw_args else []
            if len(pos_args) < 2:
                print(f"用法: supercc config add --provider {provider_id} <api_key> <model> [model_id] [name]")
                print(f"\n{provider.id} 可用模型:")
                for m in provider.models:
                    print(f"  `{m}`")
                return

            import hashlib
            token, model = pos_args[0], pos_args[1]
            # 默认用 md5(provider_id + model) 生成唯一 ID，可指定第3参数覆盖
            model_id = pos_args[2] if len(pos_args) > 2 else hashlib.md5(f"{provider_id}{model}".encode()).hexdigest()[:8]
            name = pos_args[3] if len(pos_args) > 3 else provider.id

            env = ModelEnv(
                ANTHROPIC_AUTH_TOKEN=token,
                ANTHROPIC_BASE_URL=provider.base_url,
                ANTHROPIC_MODEL=model,
            )
            ok = add_model(model_id, name, f"供应商: {provider.id}", env)
            if not ok:
                print(f"❌ 模型 ID `{model_id}` 已存在，请使用其他 ID")
                return
            print(f"✅ 模型 **{name}** (`{model_id}`) 已添加")
            print(f"   供应商: {provider.id}")
            print(f"   模型: `{model}`")
            print(f"   端点: `{provider.base_url}`")
            print(f"\n使用 `supercc config switch {model_id}` 切换到新模型。")
            return

        if not raw_args.strip():
            print("用法: supercc config add --provider <provider_id> <api_key> <model> [model_id] [name]")
            print("       supercc config add <model_id>|<name>|<description>|<api_key>|<base_url>|<model>")
            print("\n可用供应商:")
            from supercc.core.models.model_providers import PROVIDERS
            for pid, p in PROVIDERS.items():
                print(f"  `{pid}`")
            return

        parts = _parse_args(raw_args)
        if len(parts) < 6:
            print("错误: 需要 6 个参数，以 | 分隔")
            print("用法: supercc config add <model_id>|<name>|<description>|<api_key>|<base_url>|<model>")
            return
        model_id, name, description, token, base_url, model = parts
        env = ModelEnv(
            ANTHROPIC_AUTH_TOKEN=token,
            ANTHROPIC_BASE_URL=base_url,
            ANTHROPIC_MODEL=model,
        )
        ok = add_model(model_id, name, description, env)
        if not ok:
            print(f"❌ 模型 ID `{model_id}` 已存在，请使用其他 ID")
            return
        print(f"✅ 模型 **{name}** (`{model_id}`) 已添加")
        print(f"   模型: `{model}`")
        print(f"   端点: `{base_url}`")
        print(f"\n使用 `supercc config switch {model_id}` 切换到新模型。")
        return

    if action == "delete":
        if not raw_args.strip():
            print("用法: supercc config delete <model_id>")
            return
        model_id = raw_args.strip()
        ok = delete_model(model_id)
        if not ok:
            print(f"❌ 删除模型 `{model_id}` 失败。可能原因：模型不存在或为当前激活模型。")
            return
        print(f"✅ 模型 `{model_id}` 已删除。")
        return

    if action == "providers":
        from supercc.core.models.model_providers import PROVIDERS
        auth_display = {"bearer": "Bearer API Key", "api_key": "API Key", "azure": "Azure AD Token"}
        print("支持的模型供应商：\n")
        for pid, p in PROVIDERS.items():
            auth = auth_display.get(p.auth_type, p.auth_type)
            models_preview = ", ".join(p.models[:4])
            if len(p.models) > 4:
                models_preview += f" ... (+{len(p.models) - 4})"
            print(f"  `{pid}`")
            print(f"    端点: {p.base_url or '(用户填入)'}")
            print(f"    认证: {auth}")
            print(f"    模型: {models_preview}")
            print()
        print("用法: supercc config add --provider <provider_id> <api_key> <model>")
        return

    if action == "model":
        # Delegate to the existing model handlers using model_action
        model_action = getattr(args, "model_action", None)
        raw_args = getattr(args, "config_args", "") or ""
        if isinstance(raw_args, list):
            raw_args = " ".join(raw_args)
        # Route to existing handlers with action = model_action
        action = model_action
        # Each handler returns or falls through to the next

    if action == "gateway":
        from supercc.config import resolve_config_path, init_config, get_config, write_config
        cfg_path, _ = resolve_config_path()
        init_config(cfg_path)
        cfg = get_config()
        import secrets
        gateway_action = getattr(args, "gateway_action", None)

        if gateway_action == "token":
            tok = getattr(args, "token", None) or ""
            if not tok:
                tok = secrets.token_urlsafe(32)
            cfg.core.token = tok
            write_config(cfg)
            print(f"Token 已设置: {tok}")
        elif gateway_action == "username":
            cfg.core.username = getattr(args, "username", "")
            write_config(cfg)
            print(f"Username 已设置: {cfg.core.username}")
        elif gateway_action == "password":
            cfg.core.password = getattr(args, "password", "")
            write_config(cfg)
            print("Password 已设置")
        elif gateway_action == "host":
            cfg.core.host = getattr(args, "host", "127.0.0.1")
            write_config(cfg)
            print(f"Host 已设置为: {cfg.core.host}")
        elif gateway_action == "port":
            cfg.core.port = getattr(args, "port", 28888)
            write_config(cfg)
            print(f"Port 已设置为: {cfg.core.port}")
        elif gateway_action == "show":
            print(f"Host: {cfg.core.host}")
            print(f"Port: {cfg.core.port}")
            print(f"Token: {'已设置' if cfg.core.token else '未设置'}")
            print(f"Username: {cfg.core.username or '未设置'}")
            print(f"Password: {'已设置' if cfg.core.password else '未设置'}")
        elif gateway_action == "delete":
            cfg.core.token = ""
            cfg.core.username = ""
            cfg.core.password = ""
            write_config(cfg)
            print("Core 认证配置已清除")
        else:
            print("用法: supercc config gateway host/port/token/username/password/show/delete")
        return

    if action == "channel":
        channel_action = getattr(args, "channel_action", None)
        channel_name = getattr(args, "channel_name", None)
        from supercc.config import resolve_config_path, init_config, get_config, write_config
        try:
            cfg_path, _ = resolve_config_path()
            init_config(cfg_path)
            cfg = get_config()
        except Exception:
            print("❌ 无法读取配置，请确保在项目目录下运行")
            return

        feishu = cfg.channels.feishu
        wecom = cfg.channels.wecom

        if channel_action is None or channel_action == "status":
            feishu_creds = "✅ 已配置" if feishu.app_id else "❌ 未配置"
            wecom_creds = "✅ 已配置" if wecom.corp_id else "❌ 未配置"
            print(f"飞书:      enabled={feishu.enabled}  {feishu_creds}")
            print(f"企业微信:  enabled={wecom.enabled}  {wecom_creds}")
            print()
            print("说明：修改 enabled 后需重启 SuperCC（supercc gateway restart）才能生效")
            if channel_action is None:
                return

        if channel_name not in ("feishu", "wecom"):
            print(f"❌ 不支持的插件：{channel_name}（支持：feishu, wecom）")
            return

        channel = getattr(cfg.channels, channel_name, None)
        if not channel:
            print(f"❌ 未知错误：找不到 {channel_name} 配置")
            return

        if channel_action == "enable":
            if channel_name == "feishu" and not channel.app_id:
                print("❌ 飞书未配置凭证（app_id 为空），无法启用。请先运行 onboard")
                return
            if channel_name == "wecom" and not channel.corp_id:
                print("❌ 企业微信未配置凭证（corp_id 为空），无法启用。请先运行 onboard")
                return
            channel.enabled = True
            write_config(cfg)
            print(f"✅ {channel_name} 已启用（重启后生效）")
        elif channel_action == "disable":
            channel.enabled = False
            write_config(cfg)
            print(f"✅ {channel_name} 已禁用（重启后生效）")
        return


def _add_to_allowed_users(platform: str, user_id: str) -> None:
    """Add a user to the channel's allowed_users list and save config."""
    from supercc.config import get_config, write_config
    cfg = get_config()
    channel = getattr(cfg.channels, platform, None)
    if not channel:
        return
    if user_id not in channel.allowed_users:
        channel.allowed_users.append(user_id)
        write_config(cfg)


def _remove_from_allowed_users(platform: str, user_id: str) -> None:
    """Remove a user from the channel's allowed_users list and save config."""
    from supercc.config import get_config, write_config
    cfg = get_config()
    channel = getattr(cfg.channels, platform, None)
    if not channel:
        return
    if user_id in channel.allowed_users:
        channel.allowed_users.remove(user_id)
        write_config(cfg)


def main(args=None):
    # Read version once — shared by --version flag and startup banner
    try:
        from importlib.metadata import version as _get_version

        _version = _get_version("pysupercc")
    except Exception:
        _version = "dev"

    parser = argparse.ArgumentParser(
        description="SuperCC — 超级 Claude Code，支持飞书等多平台"
    )
    parser.add_argument(
        "-v", "--version",
        action="version",
        version=f"supercc {_version}",
    )
    parser.add_argument(
        "--log-level",
        type=str,
        default="INFO",
        choices=["DEBUG", "INFO", "WARNING", "ERROR"],
    )
    subparsers = parser.add_subparsers(dest="command", help="Commands")

    update_parser = subparsers.add_parser("update", help="Check for updates and restart if needed")

    # config
    config_parser = subparsers.add_parser("config", help="Manage all configurations (model/gateway/channel)")
    config_subparsers = config_parser.add_subparsers(dest="config_action", help="Action")
    config_subparsers.required = False  # 允许 `supercc config` 回车进入交互菜单

    # model
    ca_model = config_subparsers.add_parser("model", help="管理模型配置")
    ca_model_subparsers = ca_model.add_subparsers(dest="model_action", help="Action")
    ca_model_subparsers.required = False

    ca_list = ca_model_subparsers.add_parser("list", help="列出所有模型")
    ca_list.add_argument("config_args", nargs="*", default=[], help="(ignored)")

    ca_add = ca_model_subparsers.add_parser("add", help="添加模型")
    ca_add.add_argument("--provider", help="预设供应商 ID（如 openrouter, anthropic）")
    ca_add.add_argument("config_args", nargs="*", default=[], help="<api_key> <model> [model_id] [name] [description]")

    ca_delete = ca_model_subparsers.add_parser("delete", help="删除模型")
    ca_delete.add_argument("config_args", help="<model_id>")

    ca_providers = ca_model_subparsers.add_parser("providers", help="列出供应商")

    # gateway (core)
    ca_gateway = config_subparsers.add_parser("gateway", help="管理 core 监听配置")
    ca_gateway_subparsers = ca_gateway.add_subparsers(dest="gateway_action", help="Action")

    ca_gw_token = ca_gateway_subparsers.add_parser("token", help="设置 token（不提供则自动生成）")
    ca_gw_token.add_argument("token", nargs="?", default="", help="Token 值")

    ca_gw_username = ca_gateway_subparsers.add_parser("username", help="设置账号")
    ca_gw_username.add_argument("username", help="用户名")

    ca_gw_password = ca_gateway_subparsers.add_parser("password", help="设置密码")
    ca_gw_password.add_argument("password", help="密码")

    ca_gw_host = ca_gateway_subparsers.add_parser("host", help="设置监听地址（127.0.0.1 或 0.0.0.0）")
    ca_gw_host.add_argument("host", help="监听地址")

    ca_gw_port = ca_gateway_subparsers.add_parser("port", help="设置监听端口")
    ca_gw_port.add_argument("port", type=int, help="监听端口")

    ca_gw_show = ca_gateway_subparsers.add_parser("show", help="显示当前配置")
    ca_gw_delete = ca_gateway_subparsers.add_parser("delete", help="清除认证配置")

    # channel
    ca_channel = config_subparsers.add_parser("channel", help="管理飞书/企微插件")
    ca_channel_subparsers = ca_channel.add_subparsers(dest="channel_action", help="Action")
    ca_channel_subparsers.required = False

    ca_ch_enable = ca_channel_subparsers.add_parser("enable", help="启用插件")
    ca_ch_enable.add_argument("channel_name", help="插件名（feishu 或 wecom）")

    ca_ch_disable = ca_channel_subparsers.add_parser("disable", help="禁用插件")
    ca_ch_disable.add_argument("channel_name", help="插件名（feishu 或 wecom）")

    ca_ch_status = ca_channel_subparsers.add_parser("status", help="查看插件状态")

    # onboard
    onboard_parser = subparsers.add_parser("onboard", help="Interactive first-time setup")

    # logs
    logs_parser = subparsers.add_parser("logs", help="View SuperCC logs")
    logs_parser.add_argument("--follow", action="store_true", help="Follow log output (Ctrl+C to exit)")
    logs_parser.add_argument("--tail", type=int, default=100, help="Number of recent lines to show (default: 100)")

    # gateway
    gateway_parser = subparsers.add_parser("gateway", help="Gateway management (后台常驻服务)")
    gateway_subparsers = gateway_parser.add_subparsers(dest="gateway_action", help="Action")

    # 共享给所有 gateway 子命令的 --working-dir 参数
    # 用 parents 机制避免重复定义，每个子命令都能接受 --working-dir
    _shared_gw_args = argparse.ArgumentParser(add_help=False)
    _shared_gw_args.add_argument(
        "--working-dir",
        type=str,
        default="",
        help="项目工作目录（默认当前目录）。所有 gateway 子命令均支持此参数。",
    )

    gw_start = gateway_subparsers.add_parser("start", parents=[_shared_gw_args], help="Start gateway (auto-install if not installed)")
    gw_start.add_argument("--force", action="store_true", help="强制重新安装服务（刷新 Token 等）")
    gw_run = gateway_subparsers.add_parser("run", parents=[_shared_gw_args], help="Run gateway in foreground (实时打印日志)")
    gw_stop = gateway_subparsers.add_parser("stop", parents=[_shared_gw_args], help="Stop gateway")
    gw_status = gateway_subparsers.add_parser("status", parents=[_shared_gw_args], help="Show gateway status")
    gw_restart = gateway_subparsers.add_parser("restart", parents=[_shared_gw_args], help="热重启当前实例")

    # pairing
    pairing_parser = subparsers.add_parser("pairing", help="P2P pairing management (approve/revoke users)")
    pairing_subparsers = pairing_parser.add_subparsers(dest="pairing_action", help="Action")
    pairing_subparsers.required = False

    pairing_list = pairing_subparsers.add_parser("list", help="List pending and approved users")
    pairing_approve = pairing_subparsers.add_parser("approve", help="Approve a pairing code")
    pairing_approve.add_argument("code", help="Pairing code")
    pairing_revoke = pairing_subparsers.add_parser("revoke", help="Revoke user access")
    pairing_revoke.add_argument("platform", help="Platform (feishu/wecom)")
    pairing_revoke.add_argument("user_id", help="User ID to revoke")
    pairing_clear = pairing_subparsers.add_parser("clear-pending", help="Clear all pending codes")

    args = parser.parse_args(args)

    # --working-dir 必须在所有配置之前处理
    wd = getattr(args, "working_dir", "") or ""
    if wd:
        os.chdir(wd)

    # Print banner before any logging setup
    print_banner(_version)

    try:
        sys.stdout.reconfigure(encoding="utf-8")
    except AttributeError:
        pass  # Python < 3.7
    _stdout_handler = _SafeStreamHandler(sys.stdout)
    _stdout_handler.setLevel(args.log_level)
    _stdout_handler.setFormatter(ColoredFormatter())
    logging.root.addHandler(_stdout_handler)
    logging.root.setLevel(args.log_level)
    logging.getLogger("httpx").setLevel(logging.WARNING)
    logging.getLogger("qrcode").setLevel(logging.WARNING)

    command = args.command

    if command == "update":
        from supercc.core.commands.restart_impl import run_update_cli, RestartError as UpdateErr
        try:
            for step in run_update_cli(None):
                bar = "━" * (step.step - 1) + "▓" + "░" * (step.total - step.step)
                if step.status == "skip":
                    print(f"✅ 当前版本 {step.detail} 已是最新")
                    return
                if step.status == "final":
                    print(f"\r[{bar}] ✓ {step.label} {step.detail}")
                else:
                    detail_str = f"  {step.detail}" if step.detail else ""
                    print(f"\r[{bar}] {step.label}...{detail_str}")
            print()
            import os as _os
            _os._exit(0)
        except UpdateErr as e:
            print(f"\n❌ 更新失败: {e}")
            sys.exit(1)
        return

    if command == "config":
        _run_config_command(args)
        return

    if command == "logs":
        from supercc.logs import view_logs
        view_logs(follow=args.follow, tail=args.tail)
        return

    if command == "gateway":
        from supercc.gateway.cli import (
            run_gateway_start,
            run_gateway_stop,
            run_gateway_status,
            run_gateway_run,
            run_gateway_restart,
        )
        action = getattr(args, "gateway_action", None)
        if action == "start":
            run_gateway_start(force=getattr(args, "force", False))
        elif action == "stop":
            run_gateway_stop()
        elif action == "status":
            run_gateway_status()
        elif action == "run":
            try:
                run_gateway_run()
            except Exception as e:
                import traceback
                _logger = logging.getLogger("supercc")
                err_msg = str(e) or traceback.format_exc() or "未知错误"
                _logger.error("Gateway run failed: %s", err_msg)
                print(f"\n❌ Gateway run failed: {err_msg}", file=sys.stderr)
                sys.exit(1)
        elif action == "restart":
            run_gateway_restart()
        else:
            run_gateway_status()
        return

    if command == "onboard":
        from supercc.onboard import run_onboard_flow
        ok = run_onboard_flow()
        if ok:
            print("\n💡 现在可以运行以下命令启动 SuperCC：")
            print("   supercc gateway start\n")
        return

    if command == "pairing":
        from supercc.core.pairing import get_pairing_store
        cfg_path, _ = resolve_config_path()
        init_config(cfg_path)
        store = get_pairing_store()
        action = getattr(args, "pairing_action", None)

        if action is None or action == "list":
            # List pending and approved
            pending = store.list_pending()
            approved = store.list_approved()
            if not pending and not approved:
                print("No pairing data found. No one has tried to pair yet~")
                return
            if pending:
                print(f"\nPending Pairing Requests ({len(pending)}):")
                print(f"  {'Platform':<12} {'Code':<10} {'User ID':<20} {'Name':<20} {'Age'}")
                print(f"  {'--------':<12} {'----':<10} {'-------':<20} {'----':<20} {'---'}")
                for p in pending:
                    print(
                        f"  {p['platform']:<12} {p['code']:<10} {p['user_id']:<20} "
                        f"{p.get('user_name', ''):<20} {p['age_minutes']}m ago"
                    )
            else:
                print("\nNo pending pairing requests.")
            if approved:
                print(f"\nApproved Users ({len(approved)}):")
                print(f"  {'Platform':<12} {'User ID':<20} {'Name':<20}")
                print(f"  {'--------':<12} {'-------':<20} {'----':<20}")
                for a in approved:
                    print(f"  {a['platform']:<12} {a['user_id']:<20} {a.get('user_name', ''):<20}")
            else:
                print("\nNo approved users.")
            print()
            return

        if action == "approve":
            code = args.code.upper().strip()
            result = store.approve_code_global(code)
            if result:
                uid = result["user_id"]
                name = result.get("user_name", "")
                platform = result["platform"]
                display = f"{name} ({uid})" if name else uid
                print(f"\nApproved! User {display} on {platform} can now use the bot~")
                _add_to_allowed_users(platform, uid)
                print(" They'll be recognized automatically on their next message.\n")
            else:
                print(f"\nCode '{code}' not found or expired.")
                print(" Run 'supercc pairing list' to see pending codes.\n")
            return

        if action == "revoke":
            platform = args.platform.lower().strip()
            user_id = args.user_id
            if store.revoke(platform, user_id):
                print(f"\nRevoked access for user {user_id} on {platform}.\n")
                # Remove from channel's allowed_users
                _remove_from_allowed_users(platform, user_id)
            else:
                print(f"\nUser {user_id} not found in approved list for {platform}.\n")
            return

        if action == "clear-pending":
            count = store.clear_pending()
            if count:
                print(f"\nCleared {count} pending pairing request(s).\n")
            else:
                print("\nNo pending requests to clear.\n")
            return

    # `supercc` with no arguments shows help
    if command is None:
        parser.print_help()
        return


if __name__ == "__main__":
    main()
