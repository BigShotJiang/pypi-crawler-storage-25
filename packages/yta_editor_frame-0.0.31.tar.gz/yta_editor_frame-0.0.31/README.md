# Youtube Autonomous Main Editor Frame module

The main Editor module related to frames and how we process, transform and handle them.