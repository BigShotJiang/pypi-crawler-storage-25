"""
Module related to frames, to simplify the way
we handle, transform and process the frames
for the different GPU and CPU processors.
"""