"""VRL SDK tests package."""
