# kts_dark_theme

Dark theme for Knowing the Sky. Experimental, not yet for distribution.

## dev environment setup

Create a conda environment with at least:

* `jupyterlab>=4.3.1`
* `jupyterlab-myst`
* `python`
* `nodejs=22` (do **not** use your system node)

`make` is also required.

If you have the dependencies for Knowing The Sky installed, the only additional
requirement is `nodejs=22`.

Do **not** install `hatch-jupyter-builder`.

## dev installation

**initial**

run `make build && make install`. This will download all node dependencies,
perform an initial build of the extension, and symlink it to the central
Jupyter extensions directory. Now the extension should be available in 
JupyterLab, and changes you make to 
`kts_dark_theme/labextension/themes/kts-dark-theme/index.css` will appear 
in JupyterLab on page reload.

**rebuild**

If you want to ship changes to the theme, run `make rebuild`. This
will propagate changes from `kts_dark_theme/labextension/themes/kts-dark-theme/index.css`
into the non-editable ("regular") version of the extension.

**reinstall/relink**

If your links get messed up somehow such that you can't rebuild the
package or Jupyter can't find your editable CSS, run `make reinstall`.
Do not attempt to relink by directly reinstalling the package with `pip`.
The Lab extension build sequence will cause this to fail.

**full reinstall**

Run `make clean && make build && make install`.

### A note on PyCharm

The package includes ESLint configurations, which PyCharm will attempt to 
automatically use. It will probably fail unless you have all the correct
node packages and a compatible .stylelintrc available at system level. This will
create annoying error messages when editing many files. To fix this, you can 
either install them at system level or go to Settings/Stylelint and point it 
to the node module jlpm installed when you did the initial install:
`node_modules/stylelint` (relative to repo root)
