"""FastAPI/SSE backend server for the TypeScript TUI."""

from __future__ import annotations

import asyncio
import json
import threading
from typing import Any, AsyncIterator, Dict, Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel

from .agent import Agent, AgentMode
from .config import Config
from .core import AICode

app = FastAPI(title="codrninja-server", version="1.0.0")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

_ai: Optional[AICode] = None


def get_ai() -> AICode:
    global _ai
    if _ai is None:
        _ai = AICode()
    return _ai


# ── request models ────────────────────────────────────────────────────────────

class SendRequest(BaseModel):
    message: str
    model: Optional[str] = None
    max_steps: int = 50
    auto_approve: bool = True
    mode: str = "build"


class CreateSessionRequest(BaseModel):
    name: str


class ExecRequest(BaseModel):
    command: str


class SearchRequest(BaseModel):
    query: str


class FetchRequest(BaseModel):
    url: str


class CommitRequest(BaseModel):
    message: str


class TestRequest(BaseModel):
    command: str = "pytest -q"


# ── routes ────────────────────────────────────────────────────────────────────

@app.get("/health")
def health():
    return {"status": "ok"}


@app.get("/config")
def get_config():
    cfg = get_ai().config
    return {
        "provider": cfg.default_provider,
        "model": cfg.default_model,
        "ollama_url": cfg.ollama_url,
        "reasoning_level": cfg.reasoning_level,
        "permissions_mode": cfg.permissions_mode,
    }


@app.get("/sessions")
def list_sessions():
    return {"sessions": get_ai().list_sessions()}


@app.post("/sessions")
def create_session(req: CreateSessionRequest):
    session = get_ai().create_session(req.name)
    return {"id": session.id, "name": session.name, "created_at": session.created_at}


@app.get("/sessions/{name}")
def get_session(name: str):
    ai = get_ai()
    history = ai.get_history(name)
    if not history:
        raise HTTPException(status_code=404, detail=f"Session '{name}' not found")
    return history


@app.delete("/sessions/{name}")
def delete_session(name: str):
    ai = get_ai()
    try:
        ai.session_manager.delete(name)
        return {"deleted": name}
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/sessions/{name}/stream")
async def stream_agent(name: str, req: SendRequest) -> StreamingResponse:
    """Stream agent execution as Server-Sent Events."""
    ai = get_ai()
    ai.create_session(name)

    mode = AgentMode.PLAN if req.mode == "plan" else AgentMode.BUILD

    async def event_generator() -> AsyncIterator[str]:
        loop = asyncio.get_event_loop()
        queue: asyncio.Queue[Optional[Dict[str, Any]]] = asyncio.Queue()

        def run_agent():
            agent = Agent(ai, name, max_iterations=req.max_steps, mode=mode)
            try:
                for event in agent.stream_run(req.message, auto_approve=req.auto_approve):
                    loop.call_soon_threadsafe(queue.put_nowait, event)
            except Exception as exc:
                loop.call_soon_threadsafe(
                    queue.put_nowait,
                    {"type": "result", "result": {"success": False, "error": str(exc)}},
                )
            finally:
                loop.call_soon_threadsafe(queue.put_nowait, None)

        thread = threading.Thread(target=run_agent, daemon=True)
        thread.start()

        while True:
            event = await queue.get()
            if event is None:
                yield "event: done\ndata: {}\n\n"
                break
            yield f"data: {json.dumps(event)}\n\n"

    return StreamingResponse(
        event_generator(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "X-Accel-Buffering": "no",
        },
    )


@app.post("/run/exec")
def run_exec(req: ExecRequest):
    result = get_ai().tools.execute_command(req.command)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/search")
def run_search(req: SearchRequest):
    result = get_ai().tools.web_search(req.query)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/fetch")
def run_fetch(req: FetchRequest):
    result = get_ai().tools.web_fetch(req.url)
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/commit")
def run_commit(req: CommitRequest):
    import shlex
    get_ai().tools.execute_command("git add -A")
    result = get_ai().tools.execute_command(f"git commit -m {shlex.quote(req.message)}")
    return {"success": result.success, "output": result.output, "error": result.error}


@app.post("/run/test")
def run_test(req: TestRequest):
    result = get_ai().tools.execute_command(req.command)
    return {"success": result.success, "output": result.output, "error": result.error}


def run_server(host: str = "127.0.0.1", port: int = 7384):
    import uvicorn
    uvicorn.run(app, host=host, port=port, log_level="warning")
