# Extensibility

Probing provides mechanisms for extending its capabilities with custom data sources and metrics.

## Overview

The extension system allows:

- Custom data tables
- User-defined metrics
- Integration with external tools
- Plugin architecture

## Custom Tables

### Python API

Create custom tables using the `@table` decorator:

```python
from probing import table

@table("my_metrics")
def get_metrics():
    """Return data as list of dicts or pandas DataFrame."""
    return [
        {"name": "loss", "value": current_loss},
        {"name": "accuracy", "value": current_acc},
    ]
```

### Query Custom Tables

```sql
SELECT * FROM python.my_metrics;
```

### Table Schema

Tables are dynamically typed based on returned data:

```python
@table("training_state")
def get_training_state():
    return {
        "step": trainer.current_step,      # int
        "loss": trainer.last_loss,         # float
        "lr": optimizer.param_groups[0]["lr"],  # float
        "epoch": trainer.current_epoch,    # int
    }
```

## External Table Integration

### Pandas DataFrames

```python
import pandas as pd
from probing import register_table

df = pd.DataFrame({
    "timestamp": timestamps,
    "metric": values
})

register_table("external_metrics", df)
```

### Arrow Tables

```python
import pyarrow as pa
from probing import register_table

table = pa.table({
    "id": [1, 2, 3],
    "value": [10.0, 20.0, 30.0]
})

register_table("arrow_data", table)
```

## Custom Metrics

### Defining Metrics

```python
from probing import metric

@metric("gpu_utilization")
def gpu_util():
    """Return current GPU utilization."""
    import pynvml
    pynvml.nvmlInit()
    handle = pynvml.nvmlDeviceGetHandleByIndex(0)
    util = pynvml.nvmlDeviceGetUtilizationRates(handle)
    return util.gpu
```

### Querying Metrics

```sql
SELECT * FROM python.metrics WHERE name = 'gpu_utilization';
```

## Hook System

### Module Hooks

```python
from probing import register_hook

@register_hook("torch.nn.Linear", "forward")
def linear_hook(module, input, output):
    """Called on every Linear forward pass."""
    record_custom_data({
        "module": str(module),
        "input_shape": list(input[0].shape),
        "output_shape": list(output.shape),
    })
```

### Function Hooks

```python
from probing import hook_function

@hook_function("torch.optim.Adam.step")
def optimizer_hook(optimizer):
    """Called on every optimizer step."""
    record_custom_data({
        "lr": optimizer.param_groups[0]["lr"],
        "step_count": optimizer.state_dict()["state"][0]["step"],
    })
```

## Plugin Architecture

### Creating a Plugin

```python
# my_plugin.py
from probing import Plugin

class MyPlugin(Plugin):
    name = "my_plugin"

    def on_load(self):
        """Called when plugin is loaded."""
        self.register_table("plugin_data", self.get_data)

    def on_unload(self):
        """Called when plugin is unloaded."""
        pass

    def get_data(self):
        return [{"key": "value"}]
```

### Loading Plugins

```bash
# Environment variable
PROBING_PLUGINS=my_plugin python train.py

# Or programmatically
import probing
probing.load_plugin("my_plugin")
```

## Configuration Extension

### Custom Config Options

```python
from probing import config

# Register custom config
config.register("my_plugin.sample_rate", default=0.1, type=float)

# Use in plugin
rate = config.get("my_plugin.sample_rate")
```

### Query Configuration

```sql
SELECT * FROM information_schema.df_settings
WHERE name LIKE 'my_plugin.%';
```

## Integration Examples

### Weights & Biases

```python
from probing import table
import wandb

@table("wandb_metrics")
def get_wandb_metrics():
    run = wandb.run
    if run:
        return {
            "run_id": run.id,
            "step": run.step,
            "summary": dict(run.summary),
        }
    return {}
```

### TensorBoard

```python
from probing import table
from torch.utils.tensorboard import SummaryWriter

writer = SummaryWriter()

@table("tensorboard_scalars")
def get_tb_scalars():
    # Access TensorBoard data
    return logged_scalars
```

### Prometheus

```python
from probing import metric
from prometheus_client import Gauge

gpu_memory = Gauge("gpu_memory_bytes", "GPU memory usage")

@metric("prometheus_gpu_memory")
def update_prometheus():
    mem = torch.cuda.memory_allocated()
    gpu_memory.set(mem)
    return mem
```

## Best Practices

### 1. Lightweight Data Collection

```python
# Good: Return only necessary data
@table("efficient")
def get_efficient():
    return {"step": step, "loss": loss}

# Avoid: Expensive operations
@table("expensive")
def get_expensive():
    return serialize_entire_model()  # Too heavy
```

### 2. Error Handling

```python
@table("safe_data")
def get_safe_data():
    try:
        return {"value": compute_value()}
    except Exception as e:
        return {"error": str(e)}
```

### 3. Caching

```python
from functools import lru_cache

@table("cached_data")
@lru_cache(maxsize=1)
def get_cached_data():
    return expensive_computation()
```
