from ac_cli._version import __version__

__all__ = ["__version__"]
