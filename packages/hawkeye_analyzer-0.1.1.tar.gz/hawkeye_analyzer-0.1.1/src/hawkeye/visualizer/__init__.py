"""Visualization backend registry."""
