# -*- coding: utf-8 -*-
"""
styxx — nothing crosses unseen.

a fathom lab product.

The first drop-in cognitive vitals monitor for LLM agents. Reads an
agent's internal state in real time using signals available on any
LLM with a logprob interface (entropy, logprob, top-2 margin),
calibrated cross-architecture on the Fathom Cognitive Atlas v0.3.

Quickstart:

    # Before: from openai import OpenAI
    from styxx import OpenAI
    client = OpenAI()
    r = client.chat.completions.create(model="gpt-4o", messages=[...])

    print(r.choices[0].message.content)   # text, unchanged
    print(r.vitals.phase1_pre)            # pre-flight cognitive state
    print(r.vitals.phase4_late)           # late-flight hallucination read
    print(r.vitals.summary)               # human-readable vitals card

Fail-open: if styxx can't read vitals for any reason, the underlying
SDK call returns its normal response unchanged. styxx never breaks
the user's existing agent.

Honest specs at tier 0 (cross-model LOO, chance = 0.167):
  - phase 1 adversarial     acc 0.52  @ t=1
  - phase 1 reasoning       acc 0.43  @ t=1
  - phase 4 hallucination   acc 0.52  @ t=25
  - phase 4 reasoning       acc 0.69  @ t=25

This is an instrument panel, not a fortune teller.

Research: https://github.com/heyzoos123-blip/fathom
Patents:  US Provisional 64/020,489 · 64/021,113 · 64/026,964
License:  MIT (code), CC-BY-4.0 (atlas data)
"""

__version__ = "0.1.0a1"
__author__ = "flobi"
__license__ = "MIT"
__url__ = "https://fathom.darkflobi.com/styxx"
__tagline__ = "nothing crosses unseen."


# ── Windows console encoding safeguard ──────────────────────────────
#
# styxx emits Unicode box-drawing characters, sparkline blocks, and
# status glyphs. On legacy Windows consoles running cp1252 the default
# stdout can't encode them and `print()` crashes with UnicodeEncodeError.
#
# We reconfigure stdout/stderr to utf-8 on import whenever possible.
# Python 3.7+ stdio streams expose .reconfigure(). We swallow any
# failure silently — if we can't reconfigure, the user can still set
# PYTHONIOENCODING=utf-8 manually, or pipe output through a tool that
# handles encoding, or set STYXX_NO_COLOR=1 and live with the crash
# only if it actually happens. Fail-open: never block import.
def _auto_reconfigure_stdio():
    import sys as _sys
    for stream_name in ("stdout", "stderr"):
        stream = getattr(_sys, stream_name, None)
        if stream is None:
            continue
        reconfigure = getattr(stream, "reconfigure", None)
        if reconfigure is None:
            continue
        try:
            encoding = (getattr(stream, "encoding", "") or "").lower()
            # Only reconfigure if we're on a legacy codec that can't
            # handle the chars we emit. Don't touch utf-8 streams.
            if encoding and "utf" not in encoding:
                reconfigure(encoding="utf-8", errors="replace")
        except Exception:
            pass


_auto_reconfigure_stdio()
del _auto_reconfigure_stdio


def OpenAI(*args, **kwargs):
    """Drop-in replacement for openai.OpenAI that emits cognitive vitals.

    Every response gains a .vitals attribute alongside the normal
    .choices. Fails open: if the wrapper can't read vitals, the
    underlying openai call returns its normal response.

    Usage:
        from styxx import OpenAI
        client = OpenAI()  # same interface as openai.OpenAI
        r = client.chat.completions.create(...)
        print(r.vitals.summary)
    """
    from .adapters.openai import OpenAIWithVitals
    return OpenAIWithVitals(*args, **kwargs)


def Raw(*args, **kwargs):
    """Adapter for users who already have a logprob trajectory.

    Usage:
        from styxx import Raw
        styxx = Raw()
        vitals = styxx.read(
            entropy=[...],    # per-token entropy trajectory
            logprob=[...],    # per-token chosen-token logprob
            top2_margin=[...],
        )
        print(vitals.summary)
    """
    from .adapters.raw import RawAdapter
    return RawAdapter(*args, **kwargs)


def Anthropic(*args, **kwargs):
    """Honest pass-through wrapper around anthropic.Anthropic.

    Usage:
        # Before: from anthropic import Anthropic
        from styxx import Anthropic
        client = Anthropic()
        r = client.messages.create(
            model="claude-sonnet-4-6",
            max_tokens=1024,
            messages=[{"role": "user", "content": "..."}],
        )
        print(r.content[0].text)   # normal anthropic response
        print(r.vitals)            # always None (see below)

    IMPORTANT — .vitals is None on every Anthropic call.
    Anthropic's Messages API does not expose per-token logprobs
    (no logprobs=True / top_logprobs=k parameter), so tier 0 styxx
    vitals cannot be computed from the response. This wrapper
    exists so styxx.Anthropic is a valid import path, and so a
    one-time warning explains the situation at first use.

    Workarounds if you need vitals on Claude inference:
      - route through an OpenAI-compatible gateway (OpenRouter)
        and use styxx.OpenAI(base_url=...)
      - use styxx.Raw with a pre-captured logprob trajectory
      - wait for styxx v0.2 tier 1 (d-axis honesty from residual
        stream — does not need logprobs)
    """
    from .adapters.anthropic import AnthropicWithVitals
    return AnthropicWithVitals(*args, **kwargs)


# Public API
from .core import StyxxRuntime
from .vitals import Vitals, CentroidClassifier
from .watch import watch, observe, is_concerning, WatchSession
from .gates import on_gate, remove_gate, clear_gates, list_gates
from .reflex import reflex, rewind, abort, ReflexSession, ReflexSignal, RewindSignal, AbortSignal

__all__ = [
    # core
    "StyxxRuntime",
    "Vitals",
    "CentroidClassifier",
    # adapters
    "OpenAI",
    "Anthropic",
    "Raw",
    # observation — passive monitoring
    "watch",
    "observe",
    "is_concerning",
    "WatchSession",
    # gates — programmable thresholds + callbacks
    "on_gate",
    "remove_gate",
    "clear_gates",
    "list_gates",
    # reflex — active intervention (THE pitch)
    "reflex",
    "rewind",
    "abort",
    "ReflexSession",
    "ReflexSignal",
    "RewindSignal",
    "AbortSignal",
    # metadata
    "__version__",
    "__tagline__",
]
