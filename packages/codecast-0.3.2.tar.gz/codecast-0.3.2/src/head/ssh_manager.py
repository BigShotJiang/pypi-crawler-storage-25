"""
SSH Manager - handles SSH connections, tunnels, and daemon lifecycle on remote machines.

Uses asyncssh for async SSH operations and manages:
- SSH connection pool to remote machines
- Port forwarding tunnels (local:port -> remote:daemon_port)
- Remote daemon deployment and lifecycle
- Skills sync via SCP
- Localhost mode for running daemon on the head node itself
"""

import asyncio
import json as _json
import logging
import os
import platform
import shutil
import socket
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Optional

import asyncssh

from .__version__ import __version__
from .config import Config, PeerConfig
from .peer_manager import _build_daemon_static

logger = logging.getLogger(__name__)


def _parse_health_response(raw: str) -> tuple[bool, str | None]:
    """Parse a health.check JSON response, returning (is_healthy, version_or_none)."""
    try:
        data = _json.loads(raw)
    except (ValueError, TypeError):
        if '"ok":true' in raw or '"ok": true' in raw:
            return True, None
        return False, None
    ok = data.get("ok", False)
    version = data.get("version") if ok else None
    return bool(ok), version


@dataclass
class TunnelResult:
    """Result of ensure_tunnel, including daemon upgrade info."""

    local_port: int
    daemon_upgraded: bool = False
    old_version: str | None = None
    new_version: str | None = None


class SSHTunnel:
    """Represents an active SSH tunnel to a remote machine."""

    def __init__(
        self,
        machine_id: str,
        local_port: int,
        conn: Optional[asyncssh.SSHClientConnection],
        listener: Optional[asyncssh.SSHListener],
        is_localhost: bool = False,
        jump_conn: Optional[asyncssh.SSHClientConnection] = None,
    ):
        self.machine_id = machine_id
        self.local_port = local_port
        self.conn = conn
        self.listener = listener
        self.is_localhost = is_localhost
        self.jump_conn = jump_conn

    @property
    def alive(self) -> bool:
        """Check if the tunnel connection is still alive."""
        if self.is_localhost:
            return True  # Localhost tunnels are always "alive"
        try:
            return self.conn is not None and not self.conn.is_closed()  # type: ignore[union-attr]
        except Exception:
            return False

    async def close(self) -> None:
        """Close the tunnel and any jump host connection."""
        if self.is_localhost:
            return  # Nothing to close for localhost
        try:
            if self.listener:
                self.listener.close()
            if self.conn and not self.conn.is_closed():  # type: ignore[union-attr]
                self.conn.close()
                await self.conn.wait_closed()
            if self.jump_conn and not self.jump_conn.is_closed():  # type: ignore[union-attr]
                self.jump_conn.close()
                await self.jump_conn.wait_closed()
        except Exception as e:
            logger.warning(f"Error closing tunnel to {self.machine_id}: {e}")


class SSHManager:
    """Manages SSH connections, tunnels, and remote daemon lifecycle."""

    def __init__(self, config: Config):
        self.config = config
        self.machines = config.machines
        self.tunnels: dict[str, SSHTunnel] = {}
        self._next_port = 19100  # Starting port for local tunnel endpoints
        self._daemon_source = Path(__file__).parent.parent / "daemon"
        self._rust_binary = self._resolve_daemon_binary()

    @staticmethod
    def _resolve_daemon_binary() -> Path | None:
        """Resolve the daemon binary path.

        Delegates to the shared resolve_daemon_binary() in peer_manager.
        """
        from head.peer_manager import resolve_daemon_binary

        return resolve_daemon_binary()

    def _alloc_port(self) -> int:
        """Allocate an available local port for SSH tunnel."""
        while self._next_port < 19100 + 200:
            port = self._next_port
            self._next_port += 1
            try:
                with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
                    s.bind(("127.0.0.1", port))
                return port
            except OSError:
                logger.debug(f"Port {port} in use, trying next")
        raise RuntimeError("No available local port in range 19100..19300")

    async def _read_daemon_port_remote(self, conn: asyncssh.SSHClientConnection, default: int) -> int:
        """Read the actual daemon port from ~/.codecast/daemon.port on a remote machine."""
        try:
            result = await conn.run("cat ~/.codecast/daemon.port 2>/dev/null || true")
            stdout = (result.stdout or "").strip()
            if stdout:
                return int(stdout)
        except (ValueError, Exception) as e:
            logger.debug(f"Could not read remote daemon.port: {e}")
        return default

    async def _find_own_daemon_port(
        self, conn: asyncssh.SSHClientConnection, base_port: int
    ) -> Optional[tuple[int, str | None]]:
        """Find this user's daemon by scanning the port range.

        Returns (port, version) if found, or None.
        """
        # 1. Try the port file first (fast path)
        file_port = await self._read_daemon_port_remote(conn, 0)
        if file_port:
            health_out = await self._health_check_raw(conn, file_port)
            ok, version = _parse_health_response(health_out)
            if ok:
                if await self._daemon_owned_by_me(conn, file_port):
                    return file_port, version
                else:
                    logger.debug(f"Daemon on port {file_port} belongs to another user")

        # 2. Scan the range base_port .. base_port+100
        scan_cmd = " ; ".join(
            f"curl -sf http://127.0.0.1:{p}/rpc "
            f'-d \'{{"method":"health.check"}}\' '
            f"-H 'Content-Type: application/json' --max-time 1 "
            f"2>/dev/null && echo ' PORT={p}'"
            for p in range(base_port, base_port + 20)
        )
        result = await conn.run(f"{{ {scan_cmd} ; }} 2>/dev/null || true")
        stdout = result.stdout or ""

        for line in stdout.splitlines():
            if '"ok":true' in line or '"ok": true' in line:
                if "PORT=" in line:
                    try:
                        port = int(line.split("PORT=")[-1].strip())
                        if await self._daemon_owned_by_me(conn, port):
                            _, version = _parse_health_response(line)
                            return port, version
                    except ValueError:
                        continue
        return None

    async def _health_check_raw(self, conn: asyncssh.SSHClientConnection, port: int) -> str:
        """Run health.check RPC on a remote port, return raw stdout."""
        result = await conn.run(
            f"curl -sf http://127.0.0.1:{port}/rpc "
            f'-d \'{{"method":"health.check"}}\' '
            f"-H 'Content-Type: application/json' --max-time 2 2>/dev/null || true"
        )
        return (result.stdout or "").strip()

    async def _check_daemon_health(self, conn: asyncssh.SSHClientConnection, port: int) -> bool:
        """Quick health check on a specific port."""
        out = await self._health_check_raw(conn, port)
        ok, _ = _parse_health_response(out)
        return ok

    async def _daemon_owned_by_me(self, conn: asyncssh.SSHClientConnection, port: int) -> bool:
        """Check if the daemon listening on `port` is owned by the current SSH user."""
        # Find PID listening on the port and check its owner
        result = await conn.run(
            f"lsof -ti :{port} -sTCP:LISTEN 2>/dev/null | xargs -I{{}} ps -o user= -p {{}} 2>/dev/null || true"
        )
        owner = (result.stdout or "").strip().splitlines()
        if not owner:
            return False
        # Compare with current user
        whoami = await conn.run("whoami")
        me = (whoami.stdout or "").strip()
        return any(o.strip() == me for o in owner)

    def _read_daemon_port_local(self, default: int) -> int:
        """Read the actual daemon port from ~/.codecast/daemon.port locally."""
        port_file = Path.home() / ".codecast" / "daemon.port"
        try:
            if port_file.exists():
                return int(port_file.read_text().strip())
        except (ValueError, Exception) as e:
            logger.debug(f"Could not read local daemon.port: {e}")
        return default

    def _get_machine(self, machine_id: str) -> PeerConfig:
        """Get machine config by ID, raising if not found."""
        if machine_id not in self.machines:
            raise ValueError(f"Unknown machine: {machine_id}. Available: {list(self.machines.keys())}")
        return self.machines[machine_id]

    def _resolve_password(self, machine: PeerConfig) -> Optional[str]:
        """Resolve password from config. Supports 'file:/path' syntax."""
        if not machine.password:
            return None
        pw = machine.password
        if pw.startswith("file:"):
            pw_path = Path(pw[5:]).expanduser()
            if pw_path.exists():
                return pw_path.read_text().strip()
            else:
                logger.warning(f"Password file not found: {pw_path}")
                return None
        return pw

    async def _connect_ssh(
        self, machine: PeerConfig, timeout: float = 30.0
    ) -> tuple[asyncssh.SSHClientConnection, Optional[asyncssh.SSHClientConnection]]:
        """Establish SSH connection to a machine with timeout.

        Returns (conn, jump_conn_or_none). Caller is responsible for closing
        the jump_conn when done (unless it's stored in an SSHTunnel).
        """
        connect_kwargs: dict = {
            "host": machine.host,
            "port": machine.port,
            "username": machine.user,
            "known_hosts": None,  # Accept any host key (single user, trusted network)
        }

        if machine.ssh_key:
            connect_kwargs["client_keys"] = [machine.ssh_key]

        password = self._resolve_password(machine)
        if password:
            connect_kwargs["password"] = password

        jump_conn: Optional[asyncssh.SSHClientConnection] = None
        if machine.proxy_jump:
            # Connect through jump host
            jump_machine = self._get_machine(machine.proxy_jump)
            jump_password = self._resolve_password(jump_machine)
            jump_kwargs: dict = {
                "host": jump_machine.host,
                "port": jump_machine.port,
                "username": jump_machine.user,
                "known_hosts": None,
            }
            if jump_machine.ssh_key:
                jump_kwargs["client_keys"] = [jump_machine.ssh_key]
            if jump_password:
                jump_kwargs["password"] = jump_password
            logger.info(f"Connecting to jump host {machine.proxy_jump} ({jump_machine.host})...")
            jump_conn = await asyncio.wait_for(asyncssh.connect(**jump_kwargs), timeout=timeout)
            connect_kwargs["tunnel"] = jump_conn

        logger.info(f"Connecting to {machine.id} ({machine.host}:{machine.port})...")
        conn = await asyncio.wait_for(asyncssh.connect(**connect_kwargs), timeout=timeout)
        return conn, jump_conn

    async def ensure_tunnel(self, machine_id: str) -> TunnelResult:
        """
        Ensure an SSH tunnel exists to the remote machine's daemon port.
        Returns TunnelResult with the local port and optional upgrade info.
        """
        # Check existing tunnel
        if machine_id in self.tunnels:
            tunnel = self.tunnels[machine_id]
            if tunnel.alive:
                logger.debug(f"Tunnel to {machine_id} already active on port {tunnel.local_port}")
                return TunnelResult(local_port=tunnel.local_port)
            else:
                logger.info(f"Tunnel to {machine_id} is dead, recreating...")
                await tunnel.close()
                del self.tunnels[machine_id]

        machine = self._get_machine(machine_id)

        # Localhost mode: no SSH, just ensure daemon is running locally
        if machine.localhost:
            logger.info(f"Localhost machine {machine_id}: using direct connection to port {machine.daemon_port}")
            await self._ensure_daemon_local(machine)
            actual_port = self._read_daemon_port_local(machine.daemon_port)
            if actual_port != machine.daemon_port:
                logger.info(f"Daemon on {machine_id} using port {actual_port} (configured: {machine.daemon_port})")
            tunnel = SSHTunnel(
                machine_id,
                actual_port,
                conn=None,
                listener=None,
                is_localhost=True,
            )
            self.tunnels[machine_id] = tunnel
            return TunnelResult(local_port=actual_port)

        local_port = self._alloc_port()

        # Establish SSH connection
        conn, jump_conn = await self._connect_ssh(machine)

        # Ensure daemon is running on remote (may upgrade if version mismatch)
        upgrade_info = await self._ensure_daemon(machine_id, conn)

        # Read the actual daemon port — verify it belongs to us
        find_result = await self._find_own_daemon_port(conn, machine.daemon_port)
        if find_result:
            actual_remote_port = find_result[0]
        else:
            actual_remote_port = await self._read_daemon_port_remote(conn, machine.daemon_port)
        if actual_remote_port != machine.daemon_port:
            logger.info(f"Daemon on {machine_id} using port {actual_remote_port} (configured: {machine.daemon_port})")

        logger.info(f"Creating SSH tunnel: localhost:{local_port} -> {machine_id}:localhost:{actual_remote_port}")

        listener = await conn.forward_local_port(
            "127.0.0.1",
            local_port,
            "127.0.0.1",
            actual_remote_port,
        )

        tunnel = SSHTunnel(machine_id, local_port, conn, listener, jump_conn=jump_conn)
        self.tunnels[machine_id] = tunnel

        logger.info(f"Tunnel to {machine_id} ready on port {local_port}")

        upgrade_info.local_port = local_port
        return upgrade_info

    async def _ensure_daemon(self, machine_id: str, conn: asyncssh.SSHClientConnection) -> TunnelResult:
        """Ensure the daemon process is running on the remote machine.

        Returns TunnelResult with upgrade info (local_port filled in by caller).
        """
        machine = self._get_machine(machine_id)
        install_dir = self.config.daemon.install_dir
        upgrade_info = TunnelResult(local_port=0)  # port filled by caller

        # Find this user's daemon — checks port file, then scans range, verifies ownership
        result = await self._find_own_daemon_port(conn, machine.daemon_port)
        if result:
            port, daemon_version = result
            if daemon_version and daemon_version != __version__:
                logger.warning(
                    f"Daemon version mismatch on {machine_id}: "
                    f"daemon={daemon_version}, head={__version__}. Upgrading..."
                )
                upgrade_info.daemon_upgraded = True
                upgrade_info.old_version = daemon_version
                upgrade_info.new_version = __version__
                # Fall through to kill + redeploy
            else:
                logger.info(
                    f"Daemon already healthy on {machine_id} (port {port}, version {daemon_version or 'unknown'})"
                )
                return upgrade_info

        # Daemon not responding or version mismatch — check for stale processes
        result_ps = await conn.run("pgrep -u $(whoami) -f 'codecast-daemon' || true")
        stdout = result_ps.stdout.strip() if result_ps.stdout else ""

        if stdout:
            pids = " ".join(stdout.splitlines())  # Join all PIDs
            logger.warning(f"Own daemon on {machine_id} (PIDs: {pids}) is unresponsive or outdated, sending SIGTERM...")
            await conn.run(f"kill {pids} 2>/dev/null || true")
            await asyncio.sleep(2)

            recheck = await conn.run(f"kill -0 {pids} 2>/dev/null && echo 'alive' || echo 'dead'")
            if "alive" in (recheck.stdout or ""):
                logger.warning(f"Own daemon on {machine_id} (PIDs: {pids}) didn't stop, sending SIGKILL...")
                await conn.run(f"kill -9 {pids} 2>/dev/null || true")
                await asyncio.sleep(1)

        logger.info(f"Starting daemon on {machine_id}...")

        # Check if daemon binary exists on remote — at install_dir or on PATH
        binary_path = f"{install_dir}/codecast-daemon"
        check_result = await conn.run(
            f"test -x {binary_path} && echo 'exists' "
            f"|| command -v codecast-daemon >/dev/null 2>&1 && echo 'on-path' "
            f"|| echo 'missing'"
        )
        check_out = check_result.stdout.strip() if check_result.stdout else ""

        if check_out == "on-path" and not upgrade_info.daemon_upgraded:
            path_result = await conn.run("command -v codecast-daemon")
            binary_path = (path_result.stdout or "").strip()
            logger.info(f"Using pip-installed daemon on {machine_id}: {binary_path}")
        elif check_out == "missing" or upgrade_info.daemon_upgraded:
            if self.config.daemon.auto_deploy:
                await self._deploy_daemon(machine_id, conn)
            else:
                raise RuntimeError(
                    f"Daemon not installed on {machine_id} at {install_dir}. "
                    "Set daemon.auto_deploy: true or install manually."
                )

        log_file = self.config.daemon.log_file

        extra_paths = [f"/home/{machine.user}/.local/bin"]
        path_value = ":".join(extra_paths) + ":$PATH"

        start_cmd = f"DAEMON_PORT={machine.daemon_port} PATH={path_value} nohup {binary_path} > {log_file} 2>&1 &"
        await conn.run(start_cmd)

        for attempt in range(15):
            await asyncio.sleep(2)
            check_port = await self._read_daemon_port_remote(conn, machine.daemon_port)
            health_result = await conn.run(
                f"curl -sf http://127.0.0.1:{check_port}/rpc "
                f'-d \'{{"method":"health.check"}}\' '
                f"-H 'Content-Type: application/json' 2>/dev/null || true"
            )
            health_out = health_result.stdout.strip() if health_result.stdout else ""
            ok, _ = _parse_health_response(health_out)
            if ok:
                logger.info(f"Daemon started on {machine_id} (port {check_port})")
                return upgrade_info

        raise RuntimeError(f"Daemon failed to start on {machine_id} after 30s")

    async def _ensure_daemon_local(self, machine: PeerConfig) -> None:
        """
        Ensure the daemon is running locally (for localhost machines).
        Spawns it as a local subprocess instead of via SSH.
        """
        install_dir = Path(self.config.daemon.install_dir).expanduser()

        # Check if daemon is already running
        try:
            result = subprocess.run(["pgrep", "-f", "codecast-daemon"], capture_output=True, text=True)
            if result.stdout.strip():
                logger.info(f"Local daemon already running (PID: {result.stdout.strip()})")
                return
        except FileNotFoundError:
            pass  # pgrep not available, continue with startup

        logger.info(f"Local daemon not running, starting on port {machine.daemon_port}...")

        # Check if daemon binary exists — at install_dir or on PATH
        binary_path = install_dir / "codecast-daemon"
        if not binary_path.exists():
            which = shutil.which("codecast-daemon")
            if which:
                binary_path = Path(which)
                logger.info(f"Using pip-installed daemon: {binary_path}")
            elif self.config.daemon.auto_deploy:
                await self._deploy_daemon_local(machine, install_dir)
            else:
                raise RuntimeError(
                    f"Daemon not installed at {install_dir}. Set daemon.auto_deploy: true or install manually."
                )

        log_file = Path(self.config.daemon.log_file).expanduser()
        log_file.parent.mkdir(parents=True, exist_ok=True)

        env = os.environ.copy()
        env["DAEMON_PORT"] = str(machine.daemon_port)
        home_local_bin = Path.home() / ".local" / "bin"
        if home_local_bin.exists():
            env["PATH"] = str(home_local_bin) + ":" + env.get("PATH", "")

        # Start daemon as background process
        with open(log_file, "a") as lf:
            subprocess.Popen(
                [str(binary_path)],
                cwd=str(install_dir),
                env=env,
                stdout=lf,
                stderr=lf,
                start_new_session=True,  # Detach from parent process
            )

        # Wait for daemon to be ready
        # Read actual port from port file since daemon may have picked a different one
        import aiohttp

        for attempt in range(15):
            await asyncio.sleep(2)
            check_port = self._read_daemon_port_local(machine.daemon_port)
            try:
                async with aiohttp.ClientSession() as session:
                    async with session.post(
                        f"http://127.0.0.1:{check_port}/rpc",
                        json={"method": "health.check"},
                        timeout=aiohttp.ClientTimeout(total=5),
                    ) as resp:
                        data = await resp.json()
                        result = data.get("result", data)
                        if result.get("ok"):
                            logger.info(f"Local daemon started on port {check_port}")
                            return
            except Exception:
                pass

        raise RuntimeError(f"Local daemon failed to start after 30s")

    async def _deploy_daemon_local(self, machine: PeerConfig, install_dir: Path) -> None:
        """Deploy daemon binary locally (for localhost machines)."""
        logger.info(f"Deploying daemon locally to {install_dir}")

        # Build Rust daemon if needed
        if not self._rust_binary or not self._rust_binary.exists():
            _build_daemon_static(Path(__file__).parent.parent)
            self._rust_binary = self._resolve_daemon_binary()

        # Create install directory and copy binary
        install_dir.mkdir(parents=True, exist_ok=True)
        dest_binary = install_dir / "codecast-daemon"
        shutil.copy2(str(self._rust_binary), str(dest_binary))
        dest_binary.chmod(0o755)

        logger.info(f"Daemon deployed locally to {install_dir}")

    async def _deploy_daemon(self, machine_id: str, conn: asyncssh.SSHClientConnection) -> None:
        """Deploy daemon binary to remote machine via SCP."""
        install_dir = self.config.daemon.install_dir

        logger.info(f"Deploying daemon to {machine_id}:{install_dir}")

        # Build Rust daemon locally first if needed
        if not self._rust_binary or not self._rust_binary.exists():
            _build_daemon_static(Path(__file__).parent.parent)
            self._rust_binary = self._resolve_daemon_binary()

        # Create remote directory
        await conn.run(f"mkdir -p {install_dir}")

        # SCP binary to remote
        remote_binary = f"{install_dir}/codecast-daemon"
        await asyncssh.scp(str(self._rust_binary), (conn, remote_binary))
        await conn.run(f"chmod +x {remote_binary}")

        logger.info(f"Daemon deployed to {machine_id}")

    async def sync_skills(self, machine_id: str, remote_path: str) -> None:
        """Sync skills directory to a remote project path."""
        if not self.config.skills.sync_on_start:
            return

        skills_dir = Path(self.config.skills.shared_dir)
        if not skills_dir.exists():
            logger.debug("No skills directory to sync")
            return

        machine = self._get_machine(machine_id)

        # Localhost: use local file copy
        if machine.localhost:
            try:
                target = Path(remote_path)
                claude_md_src = skills_dir / "CLAUDE.md"
                if claude_md_src.exists() and not (target / "CLAUDE.md").exists():
                    shutil.copy2(str(claude_md_src), str(target / "CLAUDE.md"))
                    logger.info(f"Synced CLAUDE.md to local:{remote_path}")

                skills_src = skills_dir / ".claude" / "skills"
                if skills_src.exists():
                    dest_skills = target / ".claude" / "skills"
                    dest_skills.mkdir(parents=True, exist_ok=True)
                    shutil.copytree(str(skills_src), str(dest_skills), dirs_exist_ok=True)
                    logger.info(f"Synced .claude/skills/ to local:{remote_path}")
            except Exception as e:
                logger.warning(f"Skills sync failed for local:{remote_path}: {e}")
            return

        # Get or create SSH connection
        ad_hoc_conn = None
        if machine_id in self.tunnels and self.tunnels[machine_id].alive:
            conn = self.tunnels[machine_id].conn
        else:
            conn, _jc = await self._connect_ssh(machine)
            ad_hoc_conn = conn  # Track for cleanup

        # SCP skills to remote
        try:
            claude_md = skills_dir / "CLAUDE.md"
            if claude_md.exists():
                # Check if target already has CLAUDE.md
                check = await conn.run(f"test -f {remote_path}/CLAUDE.md && echo 'exists' || echo 'missing'")
                if "missing" in (check.stdout or ""):
                    await asyncssh.scp(str(claude_md), (conn, f"{remote_path}/CLAUDE.md"))
                    logger.info(f"Synced CLAUDE.md to {machine_id}:{remote_path}")

            claude_skills = skills_dir / ".claude" / "skills"
            if claude_skills.exists():
                await conn.run(f"mkdir -p {remote_path}/.claude/skills")
                await asyncssh.scp(
                    str(claude_skills),
                    (conn, f"{remote_path}/.claude/skills"),
                    recurse=True,
                )
                logger.info(f"Synced .claude/skills/ to {machine_id}:{remote_path}")

        except Exception as e:
            logger.warning(f"Skills sync failed for {machine_id}:{remote_path}: {e}")
        finally:
            if ad_hoc_conn:
                ad_hoc_conn.close()

    async def list_machines(self) -> list[dict]:
        """List all configured machines with their online status.

        Checks all machines in parallel with a short timeout.
        Skips machines that are only used as jump hosts (proxy_jump targets).
        """
        # Find which machines are only used as jump hosts
        jump_hosts = {m.proxy_jump for m in self.machines.values() if m.proxy_jump}

        # Filter to machines we want to check
        targets = [(mid, m) for mid, m in self.machines.items() if not (mid in jump_hosts and not m.default_paths)]

        async def check_machine(machine_id: str, machine: PeerConfig) -> dict:
            status = "unknown"
            daemon_status = "unknown"

            if machine.localhost:
                status = "online"
                try:
                    result = subprocess.run(
                        ["pgrep", "-f", "codecast-daemon"],
                        capture_output=True,
                        text=True,
                    )
                    daemon_status = "running" if result.stdout.strip() else "stopped"
                except FileNotFoundError:
                    daemon_status = "unknown"
            else:
                try:
                    conn = await asyncio.wait_for(
                        self._connect_ssh(machine),
                        timeout=5.0,
                    )
                    status = "online"
                    daemon_check = await conn.run(
                        f"pgrep -f 'codecast-daemon' > /dev/null 2>&1 && echo 'running' || echo 'stopped'"
                    )
                    daemon_status = (daemon_check.stdout or "").strip()
                    conn.close()
                except (asyncio.TimeoutError, OSError, asyncssh.Error) as e:
                    status = "offline"
                    daemon_status = "unknown"
                    logger.debug(f"list_machines: {machine_id} unreachable: {e}")

            return {
                "id": machine_id,
                "host": machine.host,
                "user": machine.user,
                "status": status,
                "daemon": daemon_status if status == "online" else "unknown",
                "default_paths": machine.default_paths,
                "localhost": machine.localhost,
            }

        # Check all machines in parallel
        results = await asyncio.gather(*(check_machine(mid, m) for mid, m in targets))
        return list(results)

    def get_local_port(self, machine_id: str) -> Optional[int]:
        """Get the local tunnel port for a machine, if tunnel exists."""
        tunnel = self.tunnels.get(machine_id)
        if tunnel and tunnel.alive:
            return tunnel.local_port
        return None

    async def upload_files(
        self,
        machine_id: str,
        file_entries: list,
        remote_base: Optional[str] = None,
    ) -> dict[str, str]:
        """
        SCP files to the remote machine (or local copy for localhost).

        Args:
            machine_id: Target machine ID.
            file_entries: List of FileEntry objects to upload.
            remote_base: Remote directory (defaults to config.file_pool.remote_dir).

        Returns:
            Dict mapping file_id -> remote_path.
        """
        if not remote_base:
            remote_base = self.config.file_pool.remote_dir

        machine = self._get_machine(machine_id)

        if machine.localhost:
            # Local copy
            base = Path(remote_base)
            base.mkdir(parents=True, exist_ok=True)
            mapping: dict[str, str] = {}
            for entry in file_entries:
                remote_filename = f"{entry.file_id}_{entry.original_name}"
                remote_path = str(base / remote_filename)
                shutil.copy2(str(entry.local_path), remote_path)
                mapping[entry.file_id] = remote_path
                logger.info(f"Copied {entry.original_name} to local:{remote_path}")
            return mapping

        # Get SSH connection (reuse tunnel connection)
        if machine_id not in self.tunnels or not self.tunnels[machine_id].alive:
            raise ValueError(f"No active tunnel to {machine_id}")
        conn = self.tunnels[machine_id].conn

        # Ensure remote directory exists
        await conn.run(f"mkdir -p {remote_base}")

        mapping = {}
        for entry in file_entries:
            remote_filename = f"{entry.file_id}_{entry.original_name}"
            remote_path = f"{remote_base}/{remote_filename}"
            await asyncssh.scp(str(entry.local_path), (conn, remote_path))
            mapping[entry.file_id] = remote_path
            logger.info(f"Uploaded {entry.original_name} to {machine_id}:{remote_path}")

        return mapping

    async def download_file(
        self,
        machine_id: str,
        remote_path: str,
        local_dir: str,
    ) -> Path:
        """Download a file from a remote machine via SCP.

        Args:
            machine_id: Target machine ID.
            remote_path: Absolute path on the remote machine.
            local_dir: Local directory to download into.

        Returns:
            Path to the downloaded local file.

        Raises:
            FileNotFoundError: If the remote file doesn't exist.
            ValueError: If no active tunnel exists.
        """
        machine = self._get_machine(machine_id)
        filename = Path(remote_path).name
        local_base = Path(local_dir).expanduser()
        local_base.mkdir(parents=True, exist_ok=True)
        local_path = local_base / filename

        if machine.localhost:
            # Local copy — expand ~ in remote path
            src = Path(remote_path).expanduser()
            if not src.exists():
                raise FileNotFoundError(f"File not found: {remote_path}")
            shutil.copy2(str(src), str(local_path))
            logger.info(f"Copied local file {remote_path} to {local_path}")
            return local_path

        # Remote: use SCP via existing tunnel connection
        if machine_id not in self.tunnels or not self.tunnels[machine_id].alive:
            raise ValueError(f"No active tunnel to {machine_id}")
        conn = self.tunnels[machine_id].conn

        # Check if file exists on remote
        check = await conn.run(f"test -f {remote_path} && echo 'exists' || echo 'missing'")
        if "missing" in (check.stdout or ""):
            raise FileNotFoundError(f"Remote file not found: {remote_path}")

        await asyncssh.scp((conn, remote_path), str(local_path))
        logger.info(f"Downloaded {machine_id}:{remote_path} to {local_path}")
        return local_path

    async def _run_remote(self, machine_id: str, cmd: str) -> str:
        """Run a command on a remote machine (or locally for localhost).

        Returns stdout. Raises RuntimeError on non-zero exit.
        """
        machine = self._get_machine(machine_id)

        if machine.localhost:
            proc = await asyncio.create_subprocess_shell(
                cmd,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
            )
            stdout_bytes, stderr_bytes = await proc.communicate()
            stdout = (stdout_bytes or b"").decode()
            if proc.returncode != 0:
                stderr = (stderr_bytes or b"").decode()
                raise RuntimeError(f"Command failed (rc={proc.returncode}): {stderr.strip()}")
            return stdout

        # Remote: reuse tunnel connection
        ad_hoc_conn = None
        if machine_id in self.tunnels and self.tunnels[machine_id].alive:
            conn = self.tunnels[machine_id].conn
        else:
            conn, _jc = await self._connect_ssh(machine)
            ad_hoc_conn = conn

        try:
            result = await conn.run(cmd, check=True)
            return result.stdout or ""
        finally:
            if ad_hoc_conn:
                ad_hoc_conn.close()

    async def ensure_dir(self, machine_id: str, path: str) -> None:
        """Ensure a directory exists on the remote machine (mkdir -p)."""
        try:
            await self._run_remote(machine_id, f"mkdir -p {path}")
        except Exception as exc:
            logger.warning(f"Failed to create directory {path} on {machine_id}: {exc}")

    async def ensure_repo(self, machine_id: str, path: str, git_url: str) -> None:
        """Clone a git repo on the remote machine if it doesn't already exist.

        Creates the parent directory if needed.
        """
        # Check if directory already exists
        machine = self._get_machine(machine_id)
        if machine.localhost:
            if Path(path).expanduser().exists():
                logger.info(f"Directory {path} already exists locally, skipping clone")
                return
        else:
            ad_hoc_conn = None
            if machine_id in self.tunnels and self.tunnels[machine_id].alive:
                conn = self.tunnels[machine_id].conn
            else:
                conn, _jc = await self._connect_ssh(machine)
                ad_hoc_conn = conn
            try:
                check = await conn.run(f"test -d {path} && echo 'exists' || echo 'missing'")
                if "exists" in (check.stdout or ""):
                    logger.info(f"Directory {path} already exists on {machine_id}, skipping clone")
                    return
            finally:
                if ad_hoc_conn:
                    ad_hoc_conn.close()

        # Get parent directory for mkdir -p
        parent = str(Path(path).parent)
        await self._run_remote(machine_id, f"mkdir -p {parent}")

        logger.info(f"Cloning {git_url} to {path} on {machine_id}")
        await self._run_remote(machine_id, f"git clone {git_url} {path}")
        logger.info(f"Clone complete: {path} on {machine_id}")

    async def list_project_dirs(self, machine_id: str) -> list[str]:
        """List directories under a machine's project_path.

        Uses an existing SSH connection if available.  Falls back to
        config.default_paths when no connection is open or the ls fails.
        """
        machine = self._get_machine(machine_id)
        project_path = machine.project_path  # e.g. "~/Projects"

        try:
            if machine.localhost:
                expanded = Path(project_path).expanduser()
                if expanded.is_dir():
                    return sorted(d.name for d in expanded.iterdir() if d.is_dir() and not d.name.startswith("."))
                return machine.default_paths

            tunnel = self.tunnels.get(machine_id)
            if not tunnel or not tunnel.conn or not tunnel.alive:
                return machine.default_paths

            result = await asyncio.wait_for(
                tunnel.conn.run(f"ls -1 {project_path}/ 2>/dev/null"),
                timeout=3.0,
            )
            stdout = (result.stdout or "").strip()
            if stdout:
                # Return bare directory names (user can type short names)
                return sorted(stdout.splitlines())
        except Exception:
            logger.debug(f"Failed to list project dirs on {machine_id}, using defaults")

        return machine.default_paths

    async def close_all(self) -> None:
        """Close all SSH tunnels and connections."""
        for machine_id, tunnel in list(self.tunnels.items()):
            logger.info(f"Closing tunnel to {machine_id}")
            await tunnel.close()
        self.tunnels.clear()
