from __future__ import annotations

from datetime import datetime

from jcp_data_manager.cli import build_parser
from jcp_data_manager.config import (
    load_environment,
    load_gemini_settings,
    load_github_models_settings,
    load_wordpress_settings,
)
from jcp_data_manager.jobs import calculate_hours_old, default_jobs_output_path
from jcp_data_manager.job_templates import build_post_content


def test_build_post_content_respects_linkedin_toggle() -> None:
    with_linkedin = build_post_content(
        google_script="<script>google</script>",
        generated_html="<p>body</p>",
        include_linkedin_popup=True,
    )
    without_linkedin = build_post_content(
        google_script="<script>google</script>",
        generated_html="<p>body</p>",
        include_linkedin_popup=False,
    )

    assert "Sign in with LinkedIn" in with_linkedin
    assert "Sign in with LinkedIn" not in without_linkedin
    assert "randomizeTreat" in without_linkedin
    assert "fetchJcpSessionId" in with_linkedin
    assert "action: 'jcpst_get_session_id'" in with_linkedin
    assert 'console.error("Failed to save survey row:", status, error);' in with_linkedin
    assert "document.addEventListener(\"DOMContentLoaded\", randomizeTreat);" in with_linkedin
    assert '<div id="jcp-login-overlay">' in without_linkedin
    assert 'console.warn("Overlay elements missing");' in without_linkedin


def test_default_jobs_output_path_matches_script_style() -> None:
    output_path = default_jobs_output_path(
        occupation_title="Graphic Designer",
        location="Seattle, WA",
        now=datetime(2026, 4, 21),
    )

    assert str(output_path) == "4-21-2026_graphic_designer_seattle,_wa_jobs.csv"


def test_calculate_hours_old_is_non_negative() -> None:
    hours_old = calculate_hours_old("04/21/2026", now=datetime(2026, 4, 20, 12, 0, 0))
    assert hours_old == 0


def test_load_environment_populates_required_settings(tmp_path, monkeypatch) -> None:
    env_path = tmp_path / ".env"
    env_path.write_text(
        "\n".join(
            [
                "WORDPRESS_BASE_URL=https://example.com",
                "WORDPRESS_USERNAME=user1",
                "WORDPRESS_APP_PASSWORD=pass1",
                "WORDPRESS_FEATURED_MEDIA_ID=1807",
                "GITHUB_MODELS_TOKEN=github-token",
                "GEMINI_API_KEY=gemini-token",
            ]
        ),
        encoding="utf-8",
    )

    for key in [
        "WORDPRESS_BASE_URL",
        "WORDPRESS_USERNAME",
        "WORDPRESS_APP_PASSWORD",
        "WORDPRESS_FEATURED_MEDIA_ID",
        "GITHUB_MODELS_TOKEN",
        "GEMINI_API_KEY",
        "GITHUB_MODELS_ENDPOINT",
        "GITHUB_MODELS_MODEL",
        "GEMINI_MODEL",
    ]:
        monkeypatch.delenv(key, raising=False)

    load_environment(env_path)

    wordpress = load_wordpress_settings()
    github = load_github_models_settings()
    gemini = load_gemini_settings()

    assert wordpress.posts_endpoint == "https://example.com/wp-json/wp/v2/posts"
    assert wordpress.featured_media_id == 1807
    assert github.token == "github-token"
    assert gemini.api_key == "gemini-token"


def test_cli_parser_accepts_get_jobs_no_linkedin_flag() -> None:
    parser = build_parser()
    args = parser.parse_args(
        [
            "get-jobs",
            "--occupation-title",
            "Graphic Designer",
            "--date-posted",
            "04/21/2026",
            "--location",
            "Seattle, WA",
            "--no-linkedin",
        ]
    )

    assert args.no_linkedin is True
    assert args.command == "get-jobs"
