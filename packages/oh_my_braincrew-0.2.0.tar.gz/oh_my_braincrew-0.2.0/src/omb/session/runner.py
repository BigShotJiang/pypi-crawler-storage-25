# BCRW-PLAN-000080: Task runner — dispatch by task_type
"""Task runner that dispatches pipeline tasks to the appropriate hook output.

Maps each TaskType to a HookOutput, driving Claude Code hook behaviour:
- SKILL        → BLOCK with an "invoke <skill>" message
- SUB_AGENT    → BLOCK with agent instruction (payload or default)
- USER_PROMPT  → ALLOW with guidance text (payload or default)
- SYSTEM_DECISION → ALLOW with decision context (payload or default)
"""

from __future__ import annotations

from omb.hook.types import Decision, HookOutput
from omb.pipeline.definitions import TASK_SKILL_MAP
from omb.pipeline.types import TaskState, TaskType


def run_task(task: TaskState) -> HookOutput:
    """Dispatch a pipeline task to the appropriate HookOutput.

    Args:
        task: The active TaskState to process.

    Returns:
        A HookOutput whose decision and message are derived from task_type.
    """
    if task.task_type == TaskType.SKILL:
        return _dispatch_skill(task)

    if task.task_type == TaskType.SUB_AGENT:
        return _dispatch_sub_agent(task)

    if task.task_type == TaskType.USER_PROMPT:
        return _dispatch_user_prompt(task)

    # SYSTEM_DECISION — allow Claude to decide; surface context
    return _dispatch_system_decision(task)


# ---------------------------------------------------------------------------
# Private dispatch helpers
# ---------------------------------------------------------------------------


def _dispatch_skill(task: TaskState) -> HookOutput:
    """Build a BLOCK output that instructs Claude to invoke a named skill."""
    skill_name = TASK_SKILL_MAP.get(task.task_name, task.task_name)
    message = f"invoke {skill_name}"
    if task.task_payload:
        message = f"{message} {task.task_payload}"
    return HookOutput(decision=Decision.BLOCK, message=message)


def _dispatch_sub_agent(task: TaskState) -> HookOutput:
    """Build a BLOCK output that delegates work to a sub-agent."""
    message = task.task_payload or f"use executor agent to handle {task.task_name}"
    return HookOutput(decision=Decision.BLOCK, message=message)


def _dispatch_user_prompt(task: TaskState) -> HookOutput:
    """Build an ALLOW output that injects user-facing guidance."""
    message = task.task_payload or "User guidance needed."
    return HookOutput(message=message)


def _dispatch_system_decision(task: TaskState) -> HookOutput:
    """Build an ALLOW output that surfaces system-level decision context."""
    message = task.task_payload or "System decision required."
    return HookOutput(message=message)
