# BCRW-PLAN-000080: handle_reject — inline recovery handler
"""Inline recovery handler for non-approved pipeline task results.

Handles REJECT, FAILED, and NONE outcomes by inserting a recovery task at the
front of the remaining queue and re-queuing the original task as PENDING.

This is a pure Python function — no Claude involvement, no hooks.
Retry limit enforcement (RPR-023): when the active task's iteration count
reaches max_iterations, the task is marked FAILED and the pipeline is STALLED.
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from omb.pipeline.types import (
    PipelineStatus,
    ResultStatus,
    TaskState,
    TaskStatus,
    TaskType,
)

if TYPE_CHECKING:
    from omb.hook.types import HookInput
    from omb.pipeline.types import PipelineState


def handle_reject(
    state: PipelineState,
    status: ResultStatus,
    input: HookInput,  # noqa: A002
    max_iterations: int = 5,
) -> TaskState | None:
    """Handle a non-approved task result by inserting a recovery task.

    Args:
        state: The active pipeline state (mutated in-place).
        status: The result status that triggered recovery.
        input: The hook payload from Claude Code (reserved for future use).
        max_iterations: Maximum retry attempts before stalling the pipeline.

    Returns:
        The newly inserted recovery ``TaskState``, or ``None`` when the
        retry limit is exceeded or when *status* is APPROVED.
    """
    # Guard clause: APPROVED should never reach this handler.
    if status == ResultStatus.APPROVED:
        return None

    active_task = state.active_task()

    # Guard: if no active task found, stall — cannot recover from undefined state.
    if active_task is None:
        state.status = PipelineStatus.STALLED
        return None

    # Retry limit enforcement (RPR-023): stall the pipeline when exhausted.
    if active_task.iteration >= max_iterations:
        active_task.status = TaskStatus.FAILED
        state.status = PipelineStatus.STALLED
        return None

    task_name = active_task.task_name

    # Build the recovery task based on result status.
    recovery_task = _build_recovery_task(status, task_name)

    # Re-queue original task as PENDING with incremented iteration counter.
    active_task.status = TaskStatus.PENDING
    active_task.iteration += 1

    # Insert recovery task at state.current_task + 1 (front of remaining queue).
    insert_at = state.current_task + 1
    state.tasks.insert(insert_at, recovery_task)

    return recovery_task


def _build_recovery_task(status: ResultStatus, task_name: str) -> TaskState:
    """Construct the appropriate recovery task for the given result status.

    Args:
        status: The result that triggered recovery.
        task_name: The name of the original task that failed.

    Returns:
        A new ``TaskState`` configured for recovery.
    """
    if status == ResultStatus.REJECT:
        return TaskState(
            task_name=f"recover-{task_name}",
            task_type=TaskType.SUB_AGENT,
            task_payload=f"use executor agent to fix {task_name} review findings",
            status=TaskStatus.PENDING,
        )

    if status == ResultStatus.FAILED:
        return TaskState(
            task_name=f"debug-{task_name}",
            task_type=TaskType.SUB_AGENT,
            task_payload=f"use debugger agent to investigate {task_name} failure",
            status=TaskStatus.PENDING,
        )

    # ResultStatus.NONE
    return TaskState(
        task_name=f"decide-{task_name}",
        task_type=TaskType.SYSTEM_DECISION,
        task_payload="Re-evaluate previous skill output and determine if task succeeded",
        status=TaskStatus.PENDING,
    )
