"""oh-my-braincrew: Multi-agent orchestration harness for Claude Code."""

__version__ = "0.2.0"
