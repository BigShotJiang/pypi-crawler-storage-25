"""Pipeline and session shared type system.

# BCRW-PLAN-000080: Pipeline and session type system
"""

from __future__ import annotations

import uuid
from datetime import datetime  # noqa: TC003
from enum import StrEnum

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class ResultStatus(StrEnum):
    """Outcome of a completed task or pipeline step."""

    APPROVED = "APPROVED"
    REJECT = "REJECT"
    FAILED = "FAILED"
    NONE = "NONE"


class TaskType(StrEnum):
    """Category of work represented by a task."""

    SKILL = "SKILL"
    SUB_AGENT = "SUB-AGENT"
    USER_PROMPT = "USER_PROMPT"
    SYSTEM_DECISION = "SYSTEM_DECISION"


class TaskStatus(StrEnum):
    """Lifecycle state of an individual task."""

    PENDING = "pending"
    ACTIVE = "active"
    DONE = "done"
    FAILED = "failed"
    SKIPPED = "skipped"


class PipelineStatus(StrEnum):
    """Lifecycle state of a pipeline."""

    ACTIVE = "active"
    COMPLETED = "completed"
    STALLED = "stalled"
    CANCELLED = "cancelled"


# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def uuid16() -> str:
    """Generate a 16-character hex ID from uuid4."""
    return uuid.uuid4().hex[:16]


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class TaskState(BaseModel):
    """State of a single task within a pipeline."""

    task_id: str = Field(default_factory=uuid16)
    task_name: str
    task_type: TaskType
    task_payload: str | None = None
    status: TaskStatus = TaskStatus.PENDING
    result: ResultStatus | None = None
    iteration: int = 0
    checkpoint: bool = False
    max_retries: int = 0
    notification: bool = True


class NotificationConfig(BaseModel):
    """Controls which pipeline lifecycle events trigger Slack notifications."""

    on_step_complete: bool = True
    on_pipeline_complete: bool = True
    on_failure: bool = True


class PipelineState(BaseModel):
    """Full state of an active or completed pipeline."""

    session_id: str
    name: str
    status: PipelineStatus = PipelineStatus.ACTIVE
    context: str = ""
    user_id: str | None = None
    token: str = ""
    created_at: datetime
    current_task: int = 0
    notification: NotificationConfig = Field(default_factory=NotificationConfig)
    tasks: list[TaskState] = Field(default_factory=lambda: [])

    def active_task(self) -> TaskState | None:
        """Return the task at the current_task index, or None if out of range."""
        if 0 <= self.current_task < len(self.tasks):
            return self.tasks[self.current_task]
        return None

    def next_pending_task(self) -> tuple[int, TaskState] | None:
        """Return (index, task) for the first pending task after current, or None."""
        for i, task in enumerate(self.tasks):
            if i > self.current_task and task.status == TaskStatus.PENDING:
                return (i, task)
        return None
