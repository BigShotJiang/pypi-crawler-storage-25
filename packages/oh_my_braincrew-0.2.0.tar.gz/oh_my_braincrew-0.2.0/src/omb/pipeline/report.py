"""Pipeline report generation — write a markdown summary to .omb/reports/.

# BCRW-PLAN-000080: Pipeline report generation
"""

from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path

from omb.pipeline.types import PipelineState, TaskStatus


def generate_report(state: PipelineState, project_root: str | Path) -> Path:
    """Write a markdown report for a completed pipeline and return its path.

    The report is written to::

        {project_root}/.omb/reports/{session_id}.md

    The directory is created if it does not already exist.

    Args:
        state: The pipeline state to report on.
        project_root: Root directory of the project (Path or str).

    Returns:
        Path to the generated report file.
    """
    root = Path(project_root)
    reports_dir = root / ".omb" / "reports"
    reports_dir.mkdir(parents=True, exist_ok=True)

    now = datetime.now(tz=UTC).isoformat(timespec="seconds")

    content = _build_report(state, now)

    report_path = reports_dir / f"{state.session_id}.md"
    report_path.write_text(content, encoding="utf-8")
    return report_path


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _build_report(state: PipelineState, completed_at: str) -> str:
    """Render the full markdown report string."""
    lines: list[str] = []

    # Header
    lines.append(f"# Pipeline Report: {state.name}")
    lines.append("")
    lines.append(f"**Session:** {state.session_id}")
    lines.append(f"**Status:** {state.status}")
    lines.append(f"**Created:** {state.created_at.isoformat(timespec='seconds')}")
    lines.append(f"**Completed:** {completed_at}")
    lines.append("")

    # Tasks table
    lines.append("## Tasks")
    lines.append("")
    lines.append("| # | Task | Status | Result | Iterations |")
    lines.append("|---|------|--------|--------|------------|")
    for i, task in enumerate(state.tasks, start=1):
        result = task.result if task.result is not None else "—"
        lines.append(f"| {i} | {task.task_name} | {task.status} | {result} | {task.iteration} |")
    lines.append("")

    # Summary counts
    total = len(state.tasks)
    completed = sum(1 for t in state.tasks if t.status == TaskStatus.DONE)
    failed = sum(1 for t in state.tasks if t.status == TaskStatus.FAILED)
    skipped = sum(1 for t in state.tasks if t.status == TaskStatus.SKIPPED)

    lines.append("## Summary")
    lines.append("")
    lines.append(f"- Total: {total}")
    lines.append(f"- Completed: {completed}")
    lines.append(f"- Failed: {failed}")
    lines.append(f"- Skipped: {skipped}")
    lines.append("")

    return "\n".join(lines)
