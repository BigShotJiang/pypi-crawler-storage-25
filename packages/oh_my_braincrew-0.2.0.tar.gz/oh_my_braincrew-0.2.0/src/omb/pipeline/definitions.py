"""Pipeline template definitions with checkpoint and retry support.

# BCRW-PLAN-000080: Pipeline definitions with checkpoint and retry support
"""

from __future__ import annotations

import copy

from omb.pipeline.types import TaskState, TaskType

# ---------------------------------------------------------------------------
# Helper
# ---------------------------------------------------------------------------


def _skill(name: str, checkpoint: bool = False, max_retries: int = 0) -> TaskState:
    """Create a SKILL-type TaskState with the given name and options."""
    return TaskState(
        task_name=name,
        task_type=TaskType.SKILL,
        checkpoint=checkpoint,
        max_retries=max_retries,
    )


# ---------------------------------------------------------------------------
# Pipeline templates
# ---------------------------------------------------------------------------

# Each template is a list of TaskState instances representing pipeline steps.
# The _TEMPLATES dict holds the canonical definitions; PIPELINE_TEMPLATES
# returns deep copies to ensure callers cannot mutate the originals.

_TEMPLATES: dict[str, list[TaskState]] = {
    "fix": [
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ],
    "full": [
        _skill("interview"),
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ],
    "plan": [
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
    ],
    "exec": [
        _skill("execute"),
        _skill("verify"),
        _skill("document"),
        _skill("create-pr"),
    ],
    "review-pr": [
        _skill("review-pr"),
        _skill("create-plan"),
        _skill("review-plan", checkpoint=True, max_retries=2),
        _skill("execute"),
        _skill("verify"),
        _skill("commit-to-pr"),
    ],
}


def _get_templates() -> dict[str, list[TaskState]]:
    """Return deep copies of all pipeline templates."""
    return {name: copy.deepcopy(steps) for name, steps in _TEMPLATES.items()}


# Removed mutable PIPELINE_TEMPLATES constant — callers MUST use get_pipeline_templates()
# to obtain isolated deep copies that cannot mutate the canonical _TEMPLATES dict.

# ---------------------------------------------------------------------------
# Task → skill name mapping
# ---------------------------------------------------------------------------

TASK_SKILL_MAP: dict[str, str] = {
    "interview": "omb-interview",
    "create-plan": "omb-create-plan",
    "review-plan": "omb-review-plan",
    "execute": "omb-execute",
    "verify": "omb-verify",
    "document": "omb-document",
    "create-pr": "omb-create-pr",
    "review-pr": "omb-review-pr",
    "commit-to-pr": "omb-commit-to-pr",
}


def get_pipeline_templates() -> dict[str, list[TaskState]]:
    """Return fresh deep copies of all pipeline templates.

    Always call this instead of reading PIPELINE_TEMPLATES directly when
    you intend to mutate the returned tasks (e.g., attaching a session_id).
    """
    return _get_templates()
