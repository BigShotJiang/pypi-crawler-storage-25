"""Pipeline state resolver — filters to ACTIVE pipelines only.

# BCRW-PLAN-000080: Pipeline resolver
"""

from __future__ import annotations

from typing import TYPE_CHECKING

from omb.pipeline.types import PipelineState, PipelineStatus

if TYPE_CHECKING:
    from omb.pipeline.storage import PipelineStorage


class PipelineResolver:
    """Resolves a session ID to its active PipelineState.

    Returns None for missing, completed, stalled, or cancelled pipelines so
    callers only ever receive a state that is ready for further processing.
    """

    def __init__(self, storage: PipelineStorage) -> None:
        self._storage = storage

    def resolve(self, session_id: str) -> PipelineState | None:
        """Load state for session_id and return it only if status is ACTIVE.

        Returns:
            PipelineState when the pipeline exists and is ACTIVE.
            None when the file is missing or status is not ACTIVE.
        """
        state = self._storage.load(session_id)
        if state is None or state.status != PipelineStatus.ACTIVE:
            return None
        return state
