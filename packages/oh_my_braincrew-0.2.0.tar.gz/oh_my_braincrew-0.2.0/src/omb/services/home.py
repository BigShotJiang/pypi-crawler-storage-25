"""Home directory management (~/.omb/) — replaces internal/home/home.go."""

from __future__ import annotations

import os
from pathlib import Path


def omb_dir() -> Path:
    """Return ~/.omb/, creating with 0700 if needed. Auto-migrates from legacy ~/.braincrew."""
    home = Path.home()
    target = home / ".omb"

    # Auto-migrate from legacy ~/.braincrew
    if not target.exists():
        legacy = home / ".braincrew"
        if legacy.exists():
            legacy.rename(target)

    target.mkdir(mode=0o700, exist_ok=True)
    return target


def read_home() -> str:
    """Read the harness repo path from ~/.omb/home.

    Raises FileNotFoundError if the file has not been written yet.
    """
    path = omb_dir() / "home"
    return path.read_text().strip()


def write_home(repo_path: str) -> None:
    """Write repo_path to ~/.omb/home with 0600 permissions.

    Raises ValueError if repo_path is not absolute.
    """
    trimmed = repo_path.strip()
    if not os.path.isabs(trimmed):
        raise ValueError(f"path must be absolute, got {trimmed!r}")

    target = omb_dir() / "home"
    target.write_text(trimmed)
    target.chmod(0o600)
