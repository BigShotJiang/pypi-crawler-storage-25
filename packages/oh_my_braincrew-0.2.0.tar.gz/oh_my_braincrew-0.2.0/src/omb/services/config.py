"""Config service — load/save .omb/config.json with snake_case keys (Go-compatible).

# BCRW-PLAN-000080: Config and tracking service

Mirrors the Go internal/config package:
- snake_case JSON keys throughout (not camelCase)
- Atomic write: temp file → fsync → rename
- File locking via fcntl.flock on .omb/config.lock
"""

from __future__ import annotations

import contextlib
import fcntl
import json
import os
import tempfile
from dataclasses import dataclass, field
from pathlib import Path  # noqa: TC003
from typing import Any

# ---------------------------------------------------------------------------
# Dataclasses (mirror Go config structs)
# ---------------------------------------------------------------------------


@dataclass
class PipelineConfig:
    enabled: bool = False
    max_iterations: int = 5
    stop_timeout_seconds: int = 15


@dataclass
class LoopConfig:
    enabled: bool = False


@dataclass
class StatuslineConfig:
    enabled: bool = False
    theme: str = "catppuccin"
    no_emoji: bool = False
    mode: str = ""


@dataclass
class SequencesConfig:
    plan: int = 0
    pr: int = 0


@dataclass
class SlackConfig:
    enabled: bool = False
    port: int = 0
    events: list[str] = field(default_factory=lambda: [])


@dataclass
class Config:
    schema_version: int = 1
    project_code: str = ""
    user_id: str = ""
    last_updated: str = ""
    pipeline: PipelineConfig = field(default_factory=PipelineConfig)
    loop: LoopConfig = field(default_factory=LoopConfig)
    statusline: StatuslineConfig = field(default_factory=StatuslineConfig)
    sequences: SequencesConfig = field(default_factory=SequencesConfig)
    slack: SlackConfig = field(default_factory=SlackConfig)
    features: dict[str, bool] = field(default_factory=lambda: {})


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def load_config(project_root: Path) -> Config:
    """Load .omb/config.json from project_root.

    Returns a default Config if the file does not exist or cannot be parsed.
    Handles snake_case keys as written by the Go binary.
    """
    config_path = project_root / ".omb" / "config.json"
    if not config_path.exists():
        return Config()

    try:
        data: dict[str, Any] = json.loads(config_path.read_text())
    except (json.JSONDecodeError, OSError):
        return Config()

    return dict_to_config(data)


def save_config(project_root: Path, cfg: Config) -> None:
    """Atomically write cfg to .omb/config.json using snake_case keys.

    Steps:
    1. Acquire exclusive lock on .omb/config.lock.
    2. Write JSON to a temp file in the same directory.
    3. fsync the temp file.
    4. os.rename (atomic on POSIX) to the final path.
    5. Release lock.
    """
    omb_dir = project_root / ".omb"
    omb_dir.mkdir(parents=True, exist_ok=True)

    config_path = omb_dir / "config.json"
    lock_path = omb_dir / "config.lock"

    data = config_to_dict(cfg)
    serialized = json.dumps(data, indent=2)

    with open(lock_path, "w") as lock_file:
        fcntl.flock(lock_file, fcntl.LOCK_EX)
        try:
            fd, tmp_path = tempfile.mkstemp(dir=str(omb_dir), suffix=".tmp")
            try:
                with os.fdopen(fd, "w") as tmp_file:
                    tmp_file.write(serialized)
                    tmp_file.flush()
                    os.fsync(tmp_file.fileno())
                os.rename(tmp_path, str(config_path))
            except Exception:
                # Clean up temp file if rename failed
                with contextlib.suppress(OSError):
                    os.unlink(tmp_path)
                raise
        finally:
            fcntl.flock(lock_file, fcntl.LOCK_UN)


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def dict_to_config(data: dict[str, Any]) -> Config:
    """Parse a snake_case JSON dict into a Config dataclass."""
    pipeline_data = data.get("pipeline", {})
    pipeline = PipelineConfig(
        enabled=bool(pipeline_data.get("enabled", False)),
        max_iterations=int(pipeline_data.get("max_iterations", 5)),
        stop_timeout_seconds=int(pipeline_data.get("stop_timeout_seconds", 15)),
    )

    loop_data = data.get("loop", {})
    loop = LoopConfig(
        enabled=bool(loop_data.get("enabled", False)),
    )

    statusline_data = data.get("statusline", {})
    statusline = StatuslineConfig(
        enabled=bool(statusline_data.get("enabled", False)),
        theme=str(statusline_data.get("theme", "catppuccin")),
        no_emoji=bool(statusline_data.get("no_emoji", False)),
        mode=str(statusline_data.get("mode", "")),
    )

    sequences_data = data.get("sequences", {})
    sequences = SequencesConfig(
        plan=int(sequences_data.get("plan", 0)),
        pr=int(sequences_data.get("pr", 0)),
    )

    slack_data = data.get("slack", {})
    slack = SlackConfig(
        enabled=bool(slack_data.get("enabled", False)),
        port=int(slack_data.get("port", 0)),
        events=list(slack_data.get("events", [])),
    )

    features: dict[str, bool] = {}
    for k, v in data.get("features", {}).items():
        features[k] = bool(v)

    return Config(
        schema_version=int(data.get("schema_version", 1)),
        project_code=str(data.get("project_code", "")),
        user_id=str(data.get("user_id", "")),
        last_updated=str(data.get("last_updated", "")),
        pipeline=pipeline,
        loop=loop,
        statusline=statusline,
        sequences=sequences,
        slack=slack,
        features=features,
    )


def config_to_dict(cfg: Config) -> dict[str, Any]:
    """Serialize a Config to a snake_case JSON-compatible dict (Go format)."""
    return {
        "schema_version": cfg.schema_version,
        "project_code": cfg.project_code,
        "user_id": cfg.user_id,
        "last_updated": cfg.last_updated,
        "pipeline": {
            "enabled": cfg.pipeline.enabled,
            "max_iterations": cfg.pipeline.max_iterations,
            "stop_timeout_seconds": cfg.pipeline.stop_timeout_seconds,
        },
        "loop": {
            "enabled": cfg.loop.enabled,
        },
        "statusline": {
            "enabled": cfg.statusline.enabled,
            "theme": cfg.statusline.theme,
            "no_emoji": cfg.statusline.no_emoji,
            "mode": cfg.statusline.mode,
        },
        "sequences": {
            "plan": cfg.sequences.plan,
            "pr": cfg.sequences.pr,
        },
        "slack": {
            "enabled": cfg.slack.enabled,
            "port": cfg.slack.port,
            "events": cfg.slack.events,
        },
        "features": cfg.features,
    }
