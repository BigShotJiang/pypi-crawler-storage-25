"""Tracking code service — allocate {PROJECT}-{KIND}-{NNNNNN} codes atomically.

# BCRW-PLAN-000080: Config and tracking service

Mirrors the Go cmd/tracking package:
- Lock is held across the full read → increment → save cycle to prevent races.
- Lock file: .omb/config.lock (shared with config service).
"""

from __future__ import annotations

import contextlib
import fcntl
import os
from pathlib import Path  # noqa: TC003

from omb.services.config import load_config

# ---------------------------------------------------------------------------
# Constants
# ---------------------------------------------------------------------------

VALID_KINDS: frozenset[str] = frozenset({"PLAN", "PR"})

_KIND_TO_FIELD = {
    "PLAN": "plan",
    "PR": "pr",
}

# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def next_tracking_code(project_root: Path, kind: str) -> str:
    """Allocate and return the next tracking code for the given kind.

    Args:
        project_root: Root directory containing the .omb/ folder.
        kind: One of PLAN, PR (uppercase).

    Returns:
        A formatted tracking code: "{project_code}-{kind}-{NNNNNN}"

    Raises:
        ValueError: If kind is not valid, or project_code is empty.
    """
    if kind not in VALID_KINDS:
        raise ValueError(
            f"invalid tracking kind {kind!r}; must be one of {sorted(VALID_KINDS)}"
        )

    omb_dir = project_root / ".omb"
    omb_dir.mkdir(parents=True, exist_ok=True)
    lock_path = omb_dir / "config.lock"

    # Hold the lock across the entire read-increment-save cycle.
    with open(lock_path, "w") as lock_file:
        fcntl.flock(lock_file, fcntl.LOCK_EX)
        try:
            cfg = load_config(project_root)

            if not cfg.project_code:
                raise ValueError(
                    "project_code is empty — set project_code in .omb/config.json"
                )

            # Increment the appropriate counter
            field_name = _KIND_TO_FIELD[kind]
            current = getattr(cfg.sequences, field_name)
            new_value = current + 1
            setattr(cfg.sequences, field_name, new_value)

            # Atomic save (save_config acquires its own lock internally,
            # but since we already hold it exclusively here via LOCK_EX,
            # write directly to avoid deadlock — replicate the write logic).
            _write_config_locked(project_root, cfg)

        finally:
            fcntl.flock(lock_file, fcntl.LOCK_UN)

    return f"{cfg.project_code}-{kind}-{new_value:06d}"


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------


def _write_config_locked(project_root: Path, cfg: object) -> None:
    """Write config JSON atomically; caller must already hold config.lock."""
    import json
    import tempfile

    from omb.services.config import Config, config_to_dict  # noqa: F811

    assert isinstance(cfg, Config)

    omb_dir = project_root / ".omb"
    config_path = omb_dir / "config.json"
    data = config_to_dict(cfg)
    serialized = json.dumps(data, indent=2)

    fd, tmp_path = tempfile.mkstemp(dir=str(omb_dir), suffix=".tmp")
    try:
        with os.fdopen(fd, "w") as tmp_file:
            tmp_file.write(serialized)
            tmp_file.flush()
            os.fsync(tmp_file.fileno())
        os.rename(tmp_path, str(config_path))
    except Exception:
        with contextlib.suppress(OSError):
            os.unlink(tmp_path)
        raise
