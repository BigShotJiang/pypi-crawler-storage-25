# BCRW-PLAN-000081: Centralized project root resolver
"""Shared project root resolution used across CLI commands and deps."""

from __future__ import annotations

import os
import warnings
from pathlib import Path


def resolve_project_root() -> Path:
    """Resolve the OMB project root directory.

    Resolution order:
    1. OMB_PROJECT_ROOT env var (with .omb/ verification)
    2. CLAUDE_PROJECT_DIR env var (with .omb/ verification)
    3. CWD walk-up (traverse parents looking for .omb/)
    """
    for env_var in ("OMB_PROJECT_ROOT", "CLAUDE_PROJECT_DIR"):
        value = os.environ.get(env_var)
        if value:
            path = Path(value)
            if (path / ".omb").is_dir():
                return path

    cwd = Path.cwd()
    for parent in [cwd, *cwd.parents]:
        if (parent / ".omb").is_dir():
            return parent

    warnings.warn(
        f"Could not locate .omb/ project root; falling back to CWD {cwd}",
        stacklevel=2,
    )
    return cwd
