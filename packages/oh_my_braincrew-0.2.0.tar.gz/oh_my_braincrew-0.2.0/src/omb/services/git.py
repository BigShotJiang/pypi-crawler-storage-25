"""Git CLI wrapper for worktree operations — replaces internal/git/exec.go."""

from __future__ import annotations

import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from collections.abc import Callable

# Injection point for subprocess mocking in tests.
_run_fn: Callable[..., subprocess.CompletedProcess[str]] = subprocess.run


@dataclass
class WorktreeEntry:
    """A single entry from `git worktree list --porcelain`."""

    path: str = ""
    branch: str = ""
    head: str = ""
    bare: bool = False


def worktree_add(path: str, branch: str) -> None:
    """Create a new linked worktree at path on a new branch."""
    _git("worktree", "add", "-b", branch, path)


def worktree_list(cwd: str | None = None) -> list[WorktreeEntry]:
    """Run `git worktree list --porcelain` and parse into WorktreeEntry list."""
    result = _git("worktree", "list", "--porcelain", cwd=cwd, capture=True)
    return _parse_worktree_porcelain(result.stdout)


def worktree_remove(path: str, *, force: bool = False) -> None:
    """Remove a linked worktree. Use force=True for dirty worktrees."""
    args = ["worktree", "remove"]
    if force:
        args.append("--force")
    args.append(path)
    _git(*args)


def worktree_prune() -> None:
    """Clean up stale worktree administrative files."""
    _git("worktree", "prune")


def branch_merged(branch: str, target: str) -> bool:
    """Check if branch has been fully merged into target."""
    result = _git("branch", "--merged", target, capture=True)
    for line in result.stdout.splitlines():
        name = line.strip().removeprefix("* ").strip()
        if name == branch:
            return True
    return False


def repo_root(cwd: str | None = None) -> str:
    """Return the absolute path to the git repository root."""
    result = _git("rev-parse", "--show-toplevel", cwd=cwd, capture=True)
    return result.stdout.strip()


def ensure_gitignore_entry(repo_root_path: str, entry: str) -> None:
    """Append entry to .gitignore if not already present."""
    gitignore = Path(repo_root_path) / ".gitignore"
    content = ""
    if gitignore.exists():
        content = gitignore.read_text()

    trimmed_entry = entry.strip()
    for line in content.splitlines():
        if line.strip() == trimmed_entry:
            return  # Already present

    to_append = entry + "\n"
    if content and not content.endswith("\n"):
        to_append = "\n" + to_append

    with gitignore.open("a") as f:
        f.write(to_append)


# --- helpers ------------------------------------------------------------------


def _git(*args: str, cwd: str | None = None, capture: bool = False) -> subprocess.CompletedProcess[str]:
    """Run a git command, raising on failure with stderr context."""
    cmd = ["git", *args]
    result = _run_fn(
        cmd,
        cwd=cwd,
        capture_output=True,
        text=True,
        timeout=30,
    )
    if result.returncode != 0:
        stderr = result.stderr.strip()
        msg = f"git {args[0]}: exit {result.returncode}"
        if stderr:
            msg += f": {stderr}"
        raise subprocess.CalledProcessError(result.returncode, msg, result.stdout, result.stderr)
    return result


def _parse_worktree_porcelain(output: str) -> list[WorktreeEntry]:
    """Parse `git worktree list --porcelain` output into WorktreeEntry list."""
    entries: list[WorktreeEntry] = []
    current = WorktreeEntry()
    in_block = False

    for line in output.split("\n"):
        if line == "":
            if in_block:
                entries.append(current)
                current = WorktreeEntry()
                in_block = False
            continue

        in_block = True

        if line.startswith("worktree "):
            current.path = line.removeprefix("worktree ")
        elif line.startswith("HEAD "):
            current.head = line.removeprefix("HEAD ")
        elif line.startswith("branch "):
            current.branch = line.removeprefix("branch ")
        elif line == "bare":
            current.bare = True

    # Flush last block if output didn't end with blank line
    if in_block:
        entries.append(current)

    return entries
