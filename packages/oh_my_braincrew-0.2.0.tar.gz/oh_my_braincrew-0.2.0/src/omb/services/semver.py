"""Lightweight semantic version comparison — replaces pkg/semver/semver.go."""

from __future__ import annotations


def is_valid(s: str) -> bool:
    """Check if s is a valid three-part semver string (N.N.N). Strips optional 'v' prefix."""
    s = s.removeprefix("v")
    parts = s.split(".")
    if len(parts) != 3:
        return False
    return all(p.isdigit() for p in parts)


def is_newer(current: str, latest: str) -> bool:
    """Return True if latest is strictly newer than current (semver comparison).

    Both strings may have an optional 'v' prefix. Returns False for non-semver strings.
    """
    current = current.removeprefix("v")
    latest = latest.removeprefix("v")

    c_parts = current.split(".")
    l_parts = latest.split(".")

    if len(c_parts) != 3 or len(l_parts) != 3:
        return False

    for c_str, l_str in zip(c_parts, l_parts, strict=True):
        if not c_str.isdigit() or not l_str.isdigit():
            return False
        c_val, l_val = int(c_str), int(l_str)
        if l_val > c_val:
            return True
        if l_val < c_val:
            return False
    return False
