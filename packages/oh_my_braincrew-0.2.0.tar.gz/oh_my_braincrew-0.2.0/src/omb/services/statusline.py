"""Statusline pipeline — builder, collectors, renderer.

# BCRW-PLAN-000083: Statusline service scaffold

Port of internal/statusline/*.go. Reads Claude Code JSON from stdin,
collects git/pipeline/metrics/memory data, renders formatted multi-line output.
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any

from omb.services.config import load_config
from omb.services.version import get_version

# ---------------------------------------------------------------------------
# Catppuccin Mocha palette (matches Go theme.go)
# BCRW-PLAN-000083: Color constants
# ---------------------------------------------------------------------------

COLOR_TEXT = "#cdd6f4"
COLOR_SUBTEXT = "#a6adc8"
COLOR_GREEN = "#a6e3a1"
COLOR_YELLOW = "#f9e2af"
COLOR_RED = "#f38ba8"
COLOR_BLUE = "#89b4fa"
COLOR_CYAN = "#94e2d5"
COLOR_DIM = "#585b70"

# Unicode block characters
BLOCK_FULL = "\u2588"  # █
BLOCK_LIGHT = "\u2591"  # ░

# Bar widths per mode
BAR_WIDTH_DEFAULT = 32
BAR_WIDTH_FULL = 40


# ---------------------------------------------------------------------------
# Data structures
# BCRW-PLAN-000083: StdinData and StatusData dataclasses
# ---------------------------------------------------------------------------

@dataclass
class StdinData:
    """Parsed Claude Code stdin JSON — supports both nested and flat formats."""
    # Nested format fields
    model_info: dict[str, str] = field(default_factory=dict)  # pyright: ignore[reportUnknownVariableType]
    workspace: dict[str, str] = field(default_factory=dict)  # pyright: ignore[reportUnknownVariableType]
    cost: dict[str, Any] = field(default_factory=dict)  # pyright: ignore[reportUnknownVariableType]
    context_window: dict[str, Any] = field(default_factory=dict)  # pyright: ignore[reportUnknownVariableType]
    version: str = ""
    # Flat format fields
    model_flat: str = ""
    total_cost_usd: float = 0.0
    cwd: str = ""
    context_win_size: int = 0
    context_win_used: int = 0
    conversation_duration_ms: int = 0
    total_input_tokens: int = 0
    total_output_tokens: int = 0
    # Rate limits — optional, direct pass-through (no collector)
    rate_limits: dict[str, Any] = field(default_factory=dict)  # pyright: ignore[reportUnknownVariableType]


@dataclass
class StatusData:
    """Aggregated data passed to the renderer."""
    model: str = ""
    cost_usd: float = 0.0
    context_percent: float = 0.0
    duration_str: str = ""
    tokens_used: int = 0
    token_budget: int = 0
    input_tokens: int = 0
    output_tokens: int = 0
    branch: str = ""
    git_status: str = ""
    git_modified: int = 0
    repo_name: str = ""
    pipeline_name: str = ""
    pipeline_step: str = ""
    pipeline_status: str = ""
    version: str = ""
    directory: str = ""
    project_code: str = ""
    rate_limit_5h_pct: float = 0.0
    rate_limit_7d_pct: float = 0.0
    session_id: str = ""


# ---------------------------------------------------------------------------
# Stdin parsing
# BCRW-PLAN-000083: stdin parser implementation
# ---------------------------------------------------------------------------

def parse_stdin(reader: Any = None) -> StdinData:  # [NEW]
    """Parse JSON from stdin, supporting both nested and flat formats."""
    # BCRW-PLAN-000083: guard for TTY reader
    if reader is not None and hasattr(reader, "isatty") and reader.isatty():
        return StdinData()

    # Use sys.stdin if no reader provided
    if reader is None:
        reader = sys.stdin

    try:
        content = reader.read()
        if not content or not content.strip():
            return StdinData()
        data: dict[str, Any] = json.loads(content)
    except (json.JSONDecodeError, OSError, ValueError):
        return StdinData()

    # BCRW-PLAN-000083: detect nested vs flat by checking if "model" value is a dict
    model_value = data.get("model")
    if isinstance(model_value, dict):
        # Nested format
        model_dict = dict[str, str](model_value)  # pyright: ignore[reportUnknownArgumentType]
        return StdinData(
            model_info=model_dict,
            workspace=data.get("workspace", {}),
            cost=data.get("cost", {}),
            context_window=data.get("context_window", {}),
            version=str(data.get("version", "")),
            rate_limits=data.get("rate_limits", {}),
        )
    else:
        # Flat format — camelCase keys from Claude Code
        return StdinData(
            model_flat=str(model_value) if model_value is not None else "",
            total_cost_usd=float(data.get("totalCostUSD", 0.0)),
            cwd=str(data.get("cwd", "")),
            context_win_size=int(data.get("contextWindow", 0)),
            context_win_used=int(data.get("contextWindowUsed", 0)),
            conversation_duration_ms=int(data.get("conversationDurationMs", 0)),
            total_input_tokens=int(data.get("totalInputTokens", 0)),
            total_output_tokens=int(data.get("totalOutputTokens", 0)),
            rate_limits=data.get("rate_limits", {}),
        )


# ---------------------------------------------------------------------------
# Collectors
# BCRW-PLAN-000083: collector implementations
# ---------------------------------------------------------------------------

def collect_memory(stdin: StdinData) -> tuple[float, int, int]:  # [NEW]
    """Return (context_percent, tokens_used, token_budget).
    Priority: nested used_percentage > nested used/total > flat used/size.
    """
    # BCRW-PLAN-000083: priority logic for context percentage
    tokens_used = 0
    token_budget = 0
    pct: float = 0.0

    if stdin.context_window:
        # Nested format — check used_percentage first
        if "used_percentage" in stdin.context_window:
            pct = float(stdin.context_window["used_percentage"])
            tokens_used = int(stdin.context_window.get("used", 0))
            token_budget = int(stdin.context_window.get("total", 0))
        elif "used" in stdin.context_window and "total" in stdin.context_window:
            tokens_used = int(stdin.context_window["used"])
            token_budget = int(stdin.context_window["total"])
            if token_budget > 0:
                pct = (tokens_used / token_budget) * 100.0
            else:
                pct = 0.0
    elif stdin.context_win_size > 0 or stdin.context_win_used > 0:
        # Flat format
        tokens_used = stdin.context_win_used
        token_budget = stdin.context_win_size
        if token_budget > 0:
            pct = (tokens_used / token_budget) * 100.0
        else:
            pct = 0.0

    # Clamp to [0, 100]
    pct = max(0.0, min(100.0, pct))
    return (pct, tokens_used, token_budget)


def collect_metrics(stdin: StdinData) -> tuple[str, str, str]:  # [NEW]
    """Return (model_short, cost_str, duration_str).
    Model shortening: opus/sonnet/haiku detection.
    Duration: ms -> human-readable (5s, 1m, 2h 0m).
    """
    # BCRW-PLAN-000083: model shortening logic
    if stdin.model_info:
        display_name = stdin.model_info.get("display_name", "")
        if display_name:
            model_short = display_name
        else:
            model_id = stdin.model_info.get("id", stdin.model_info.get("name", ""))
            model_short = _shorten_model_id(model_id)
    else:
        model_short = _shorten_model_id(stdin.model_flat)

    # BCRW-PLAN-000083: cost formatting
    if stdin.cost:
        cost_val = float(stdin.cost.get("total_usd", stdin.cost.get("total_cost_usd", 0.0)))
    else:
        cost_val = stdin.total_cost_usd
    cost_str = f"${cost_val:.2f}"

    # BCRW-PLAN-000083: duration formatting
    # Priority: nested cost.total_duration_ms > flat conversationDurationMs
    if stdin.cost and "total_duration_ms" in stdin.cost:
        duration_ms = int(stdin.cost["total_duration_ms"])
    else:
        duration_ms = stdin.conversation_duration_ms

    duration_str = _format_duration_ms(duration_ms)

    return (model_short, cost_str, duration_str)


def _shorten_model_id(model_id: str) -> str:
    """Shorten a model ID to a friendly name."""
    # BCRW-PLAN-000083: model shortening by keyword
    lower = model_id.lower()
    if "opus" in lower:
        return "Opus"
    if "sonnet" in lower:
        return "Sonnet"
    if "haiku" in lower:
        return "Haiku"
    return model_id


def _format_duration_ms(ms: int) -> str:
    """Format milliseconds to human-readable duration string."""
    # BCRW-PLAN-000083: duration formatting rules
    if ms <= 0:
        return "0s"

    total_secs = ms // 1000
    hours = total_secs // 3600
    minutes = (total_secs % 3600) // 60
    secs = total_secs % 60

    if hours > 0:
        return f"{hours}h {minutes}m"
    if minutes > 0:
        if secs > 0:
            return f"{minutes}m {secs}s"
        return f"{minutes}m"
    return f"{secs}s"


def _battery_icon(pct: float) -> str:
    """Return battery emoji based on usage percentage.
    > 70% used -> depleted, <= 70% -> charged.
    """
    # BCRW-PLAN-000083: battery icon for rate limit display
    return "\U0001faab" if pct > 70.0 else "\U0001f50b"


def collect_git(root_dir: str) -> tuple[str, str, int, str]:  # [NEW]
    """Return (branch, git_status_str, modified_count, repo_name).
    Non-fatal: returns empty on any git error.
    """
    # BCRW-PLAN-000083: git subprocess calls with error handling
    try:
        # Get current branch
        branch_result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=root_dir if root_dir else None,
        )
        branch = branch_result.stdout.strip()

        # Get repo root for name
        toplevel_result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=root_dir if root_dir else None,
        )
        toplevel = toplevel_result.stdout.strip()
        repo_name = Path(toplevel).name if toplevel else ""

        # Get git status
        status_result = subprocess.run(
            ["git", "status", "--porcelain"],
            capture_output=True,
            text=True,
            timeout=2,
            cwd=root_dir if root_dir else None,
        )
        status_output = status_result.stdout

        # Count modified files (lines starting with M or " M")
        modified_count = 0
        untracked_count = 0
        added_count = 0
        for line in status_output.splitlines():
            if len(line) >= 2:
                xy = line[:2]
                if xy[0] == "M" or xy[1] == "M":
                    modified_count += 1
                elif xy[0] == "?" and xy[1] == "?":
                    untracked_count += 1
                elif xy[0] == "A" or xy[1] == "A":
                    added_count += 1

        # Build status string: "+N MN ?N" format, omit zero counts
        parts: list[str] = []
        if added_count > 0:
            parts.append(f"+{added_count}")
        if modified_count > 0:
            parts.append(f"M{modified_count}")
        if untracked_count > 0:
            parts.append(f"?{untracked_count}")
        git_status_str = " ".join(parts)

        return (branch, git_status_str, modified_count, repo_name)

    except (subprocess.SubprocessError, subprocess.TimeoutExpired, OSError):
        return ("", "", 0, "")


def collect_pipeline(root_dir: str) -> tuple[str, str, str]:  # [NEW]
    """Return (pipeline_name, pipeline_step, pipeline_status).
    Scans .omb/sessions/ for active pipeline JSON files.
    """
    # BCRW-PLAN-000083: scan .omb/sessions/ for active pipelines
    sessions_dir = Path(root_dir) / ".omb" / "sessions"
    if not sessions_dir.exists():
        return ("", "", "")

    for session_file in sessions_dir.glob("*.json"):
        try:
            data: dict[str, Any] = json.loads(session_file.read_text())
        except (json.JSONDecodeError, OSError):
            continue

        status = str(data.get("status", ""))
        # Active = status is anything other than "completed" or "cancelled"
        if status in ("completed", "cancelled"):
            continue

        name = str(data.get("name", ""))
        step = str(data.get("current_step", ""))
        return (name, step, status)

    return ("", "", "")


# ---------------------------------------------------------------------------
# ANSI color helpers
# BCRW-PLAN-000083: ANSI helper implementations
# ---------------------------------------------------------------------------

def _is_no_color() -> bool:  # [NEW]
    """Check NO_COLOR env var only — do NOT check isatty().
    Statusline output is consumed by Claude Code via pipe, so isatty()
    is always False in production. ANSI codes must be emitted regardless.
    """
    return "NO_COLOR" in os.environ


def _ansi_fg(hex_color: str, text: str) -> str:  # [NEW]
    """Apply 24-bit ANSI foreground color. Returns plain text if no_color."""
    # BCRW-PLAN-000083: 24-bit ANSI color wrapping
    if _is_no_color():
        return text
    # Parse "#RRGGBB"
    hex_color = hex_color.lstrip("#")
    r = int(hex_color[0:2], 16)
    g = int(hex_color[2:4], 16)
    b = int(hex_color[4:6], 16)
    return f"\x1b[38;2;{r};{g};{b}m{text}\x1b[0m"


def _ansi_bold(text: str) -> str:  # pyright: ignore[reportUnusedFunction]
    """Apply ANSI bold. Returns plain text if no_color."""
    # BCRW-PLAN-000083: bold ANSI wrapping
    if _is_no_color():
        return text
    return f"\x1b[1m{text}\x1b[0m"


# ---------------------------------------------------------------------------
# Gradient bar
# BCRW-PLAN-000083: gradient bar implementation
# ---------------------------------------------------------------------------

def build_gradient_bar(pct: float, width: int, no_color: bool) -> str:  # [NEW]
    """Build a gradient progress bar (green->yellow->red).
    Each filled block gets individual RGB color interpolation.
    """
    # BCRW-PLAN-000083: gradient bar construction
    filled = round(pct / 100 * width)
    result: list[str] = []

    for i in range(width):
        if i < filled:
            if not no_color and filled > 0:
                # Position within filled portion [0.0, 1.0]
                block_pct = i / (filled - 1) if filled > 1 else 0.0
                r, g, b = _interpolate_gradient_color(block_pct)
                result.append(f"\x1b[38;2;{r};{g};{b}m{BLOCK_FULL}\x1b[0m")
            else:
                result.append(BLOCK_FULL)
        else:
            result.append(BLOCK_LIGHT)

    return "".join(result)


def _interpolate_gradient_color(block_pct: float) -> tuple[int, int, int]:  # [NEW]
    """Green(0.0) -> Yellow(0.5) -> Red(1.0) RGB interpolation."""
    # BCRW-PLAN-000083: linear gradient interpolation
    if block_pct <= 0.5:
        # Green (0,255,0) -> Yellow (255,255,0)
        t = block_pct * 2.0  # normalize to [0, 1]
        r = int(255 * t)
        g = 255
        b = 0
    else:
        # Yellow (255,255,0) -> Red (255,0,0)
        t = (block_pct - 0.5) * 2.0  # normalize to [0, 1]
        r = 255
        g = int(255 * (1.0 - t))
        b = 0

    return (r, g, b)


# ---------------------------------------------------------------------------
# Renderer
# BCRW-PLAN-000083: renderer implementation
# ---------------------------------------------------------------------------

def render(data: StatusData, mode: str, no_color: bool, no_emoji: bool) -> str:  # [NEW]
    """Render StatusData into formatted multi-line output.
    Default mode: 3-4 lines. Full mode: 4-5 lines.
    """
    # BCRW-PLAN-000083: multi-line renderer

    sep = " | "

    def color(hex_c: str, text: str) -> str:
        if no_color:
            return text
        return _ansi_fg(hex_c, text)

    def emoji(e: str) -> str:
        if no_emoji:
            return ""
        return e + " "

    lines: list[str] = []

    if mode == "full":
        # Full mode: 4-7 lines (+ rate limits + pipeline)
        # Line 1: Model | BC vVER | duration | session_id
        version_str = f"BC v{data.version}" if data.version else ""
        line1_parts: list[str] = []
        model_part = emoji("🤖") + color(COLOR_BLUE, data.model) if data.model else ""
        if model_part:
            line1_parts.append(model_part)
        if version_str:
            line1_parts.append(color(COLOR_SUBTEXT, version_str))
        if data.duration_str:
            line1_parts.append(emoji("⏱️") + color(COLOR_CYAN, data.duration_str))
        if data.session_id:
            line1_parts.append(emoji("🔑") + color(COLOR_DIM, data.session_id))
        lines.append(sep.join(line1_parts))

        # Line 2: gradient bar pct%
        bar = build_gradient_bar(data.context_percent, BAR_WIDTH_FULL, no_color)
        pct_str = f"{data.context_percent:.0f}%"
        lines.append(emoji("📊") + bar + " " + color(COLOR_TEXT, pct_str))

        # Line 3: cost | Xk in / Yk out
        in_k = f"{data.input_tokens // 1000}K" if data.input_tokens >= 1000 else str(data.input_tokens)
        out_k = f"{data.output_tokens // 1000}K" if data.output_tokens >= 1000 else str(data.output_tokens)
        cost_part = emoji("💰") + color(COLOR_YELLOW, f"${data.cost_usd:.2f}")
        tokens_part = color(COLOR_SUBTEXT, f"{in_k} in / {out_k} out")
        lines.append(cost_part + sep + tokens_part)

        # BCRW-PLAN-000083: rate limit lines (full mode — separate lines, 40-block bars)
        if data.rate_limit_5h_pct > 0 or data.rate_limit_7d_pct > 0:
            pct_5h = int(data.rate_limit_5h_pct)
            pct_7d = int(data.rate_limit_7d_pct)
            rl_bar_5h = build_gradient_bar(data.rate_limit_5h_pct, BAR_WIDTH_FULL, no_color)
            rl_bar_7d = build_gradient_bar(data.rate_limit_7d_pct, BAR_WIDTH_FULL, no_color)
            if no_emoji:
                lines.append(color(COLOR_DIM, "5H:") + " " + rl_bar_5h + " " + color(COLOR_TEXT, f"{pct_5h}%"))
                lines.append(color(COLOR_DIM, "7D:") + " " + rl_bar_7d + " " + color(COLOR_TEXT, f"{pct_7d}%"))
            else:
                icon_5h = _battery_icon(data.rate_limit_5h_pct)
                icon_7d = _battery_icon(data.rate_limit_7d_pct)
                lines.append(color(COLOR_DIM, "5H:") + " " + icon_5h + " " + rl_bar_5h + " " + color(COLOR_TEXT, f"{pct_5h}%"))
                lines.append(color(COLOR_DIM, "7D:") + " " + icon_7d + " " + rl_bar_7d + " " + color(COLOR_TEXT, f"{pct_7d}%"))

        # Branch | modified
        branch_part = emoji("🌿") + color(COLOR_GREEN, data.branch) if data.branch else ""
        mod_part = emoji("✏️") + color(COLOR_TEXT, str(data.git_modified)) if data.git_modified else ""
        git_line_parts = [p for p in [branch_part, mod_part] if p]
        lines.append(sep.join(git_line_parts) if git_line_parts else "")

    else:
        # Default mode: 3-5 lines (+ rate limits + pipeline)
        # Line 1: Model | BC vVER | duration | session_id
        version_str = f"BC v{data.version}" if data.version else ""
        line1_parts: list[str] = []
        model_part = emoji("🤖") + color(COLOR_BLUE, data.model) if data.model else ""
        if model_part:
            line1_parts.append(model_part)
        if version_str:
            line1_parts.append(color(COLOR_SUBTEXT, version_str))
        if data.duration_str:
            line1_parts.append(emoji("⏱️") + color(COLOR_CYAN, data.duration_str))
        if data.session_id:
            line1_parts.append(emoji("🔑") + color(COLOR_DIM, data.session_id))
        lines.append(sep.join(line1_parts))

        # Line 2: gradient bar pct% | cost
        bar = build_gradient_bar(data.context_percent, BAR_WIDTH_DEFAULT, no_color)
        pct_str = f"{data.context_percent:.0f}%"
        bar_part = emoji("📊") + bar + " " + color(COLOR_TEXT, pct_str)
        cost_part = emoji("💰") + color(COLOR_YELLOW, f"${data.cost_usd:.2f}")
        lines.append(bar_part + sep + cost_part)

        # BCRW-PLAN-000083: rate limit line (default mode — inline, 10-block bars)
        if data.rate_limit_5h_pct > 0 or data.rate_limit_7d_pct > 0:
            pct_5h = int(data.rate_limit_5h_pct)
            pct_7d = int(data.rate_limit_7d_pct)
            rl_bar_5h = build_gradient_bar(data.rate_limit_5h_pct, 10, no_color)
            rl_bar_7d = build_gradient_bar(data.rate_limit_7d_pct, 10, no_color)
            if no_emoji:
                part_5h = color(COLOR_DIM, "5H:") + " " + rl_bar_5h + " " + color(COLOR_TEXT, f"{pct_5h}%")
                part_7d = color(COLOR_DIM, "7D:") + " " + rl_bar_7d + " " + color(COLOR_TEXT, f"{pct_7d}%")
            else:
                icon_5h = _battery_icon(data.rate_limit_5h_pct)
                icon_7d = _battery_icon(data.rate_limit_7d_pct)
                part_5h = color(COLOR_DIM, "5H:") + " " + icon_5h + " " + rl_bar_5h + " " + color(COLOR_TEXT, f"{pct_5h}%")
                part_7d = color(COLOR_DIM, "7D:") + " " + icon_7d + " " + rl_bar_7d + " " + color(COLOR_TEXT, f"{pct_7d}%")
            lines.append(part_5h + sep + part_7d)

        # Branch | modified
        branch_part = emoji("🌿") + color(COLOR_GREEN, data.branch) if data.branch else ""
        mod_part = emoji("✏️") + color(COLOR_TEXT, str(data.git_modified)) if data.git_modified else ""
        git_line_parts = [p for p in [branch_part, mod_part] if p]
        lines.append(sep.join(git_line_parts) if git_line_parts else "")

    # Optional pipeline line (both modes)
    if data.pipeline_name:
        pipe_parts: list[str] = []
        pipe_parts.append(emoji("🔄") + color(COLOR_CYAN, data.pipeline_name))
        if data.pipeline_step:
            pipe_parts.append(emoji("📍") + color(COLOR_TEXT, data.pipeline_step))
        if data.pipeline_status:
            pipe_parts.append(emoji("✅") + color(COLOR_GREEN, data.pipeline_status))
        lines.append(sep.join(pipe_parts))

    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Builder (orchestrates the pipeline)
# BCRW-PLAN-000083: builder entry point implementation
# ---------------------------------------------------------------------------

def build(reader: Any = None, root_dir: str = "", no_color: bool = False,
          no_emoji: bool = False, mode: str = "default") -> str:  # [NEW]
    """Full statusline pipeline: parse -> collect -> render.
    This is the main entry point called by the CLI command.
    """
    # BCRW-PLAN-000083: orchestrate parse -> collect -> render pipeline
    stdin = parse_stdin(reader)

    context_percent, tokens_used, token_budget = collect_memory(stdin)
    model_short, _cost_str, duration_str = collect_metrics(stdin)
    branch, git_status, git_modified, repo_name = collect_git(root_dir or ".")
    pipeline_name, pipeline_step, pipeline_status = collect_pipeline(root_dir or ".")

    version = get_version()
    config = load_config(Path(root_dir or "."))
    project_code = config.project_code

    # Cost priority: nested cost.total_usd > cost.total_cost_usd > flat total_cost_usd
    if stdin.cost:
        cost_usd = float(stdin.cost.get("total_usd", stdin.cost.get("total_cost_usd", 0.0)))
    else:
        cost_usd = stdin.total_cost_usd

    # Input/output tokens
    if stdin.cost:
        input_tokens = int(stdin.cost.get("input_tokens", 0))
        output_tokens = int(stdin.cost.get("output_tokens", 0))
    else:
        input_tokens = stdin.total_input_tokens
        output_tokens = stdin.total_output_tokens

    # Resolve directory
    directory = stdin.workspace.get("current_dir", stdin.cwd) if stdin.workspace else stdin.cwd

    # BCRW-PLAN-000083: rate limits — direct pass-through, no collector
    _rl = stdin.rate_limits
    _5h: dict[str, Any] = _rl.get("five_hour", {}) if _rl else {}
    _7d: dict[str, Any] = _rl.get("seven_day", {}) if _rl else {}
    rate_limit_5h_pct = float(_5h.get("used_percentage", 0.0)) if _5h else 0.0
    rate_limit_7d_pct = float(_7d.get("used_percentage", 0.0)) if _7d else 0.0

    # BCRW-PLAN-000083: session ID from environment, truncated to 8 chars
    session_id_raw = os.environ.get("CLAUDE_SESSION_ID", "")
    session_id = session_id_raw[:8] if session_id_raw else ""

    data = StatusData(
        model=model_short,
        cost_usd=cost_usd,
        context_percent=context_percent,
        duration_str=duration_str,
        tokens_used=tokens_used,
        token_budget=token_budget,
        input_tokens=input_tokens,
        output_tokens=output_tokens,
        branch=branch,
        git_status=git_status,
        git_modified=git_modified,
        repo_name=repo_name,
        pipeline_name=pipeline_name,
        pipeline_step=pipeline_step,
        pipeline_status=pipeline_status,
        version=version,
        directory=directory,
        project_code=project_code,
        rate_limit_5h_pct=rate_limit_5h_pct,
        rate_limit_7d_pct=rate_limit_7d_pct,
        session_id=session_id,
    )

    return render(data, mode=mode, no_color=no_color, no_emoji=no_emoji)
