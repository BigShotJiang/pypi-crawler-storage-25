"""Slack webhook notification — replaces internal/slack/notifier.go.

Sends messages via Slack chat.postMessage API. Reads credentials from
~/.config/omb/slack.env (SLACK_BOT_TOKEN, SLACK_CHANNEL_ID).
"""

from __future__ import annotations

import logging
from dataclasses import dataclass
from pathlib import Path

import httpx

logger = logging.getLogger(__name__)

SLACK_API_URL = "https://slack.com/api/chat.postMessage"
SLACK_TIMEOUT = 5.0


@dataclass
class SlackConfig:
    """Slack credentials loaded from ~/.config/omb/slack.env."""

    bot_token: str
    channel_id: str
    api_url: str = ""

    @property
    def effective_url(self) -> str:
        return self.api_url or SLACK_API_URL


def load_config() -> SlackConfig | None:
    """Load Slack config from ~/.config/omb/slack.env.

    Returns None if the file doesn't exist or required fields are missing —
    notification is silently disabled.
    """
    home = Path.home()
    env_path = home / ".config" / "omb" / "slack.env"

    if not env_path.exists():
        return None

    env_vars = _parse_env(env_path.read_text())
    token = env_vars.get("SLACK_BOT_TOKEN", "")
    channel = env_vars.get("SLACK_CHANNEL_ID", "")

    if not token or not channel:
        return None

    return SlackConfig(
        bot_token=token,
        channel_id=channel,
        api_url=env_vars.get("SLACK_API_URL", ""),
    )


def notify_sync(config: SlackConfig | None, text: str) -> str | None:
    """Send a Slack message synchronously. Returns error string or None on success.

    If config is None, logs and returns None (notification disabled).
    """
    if config is None:
        logger.info("[slack] notification skipped: no Slack config loaded")
        return None

    try:
        post_message(config, text)
        return None
    except Exception as e:
        error_msg = f"[slack] notification failed: {e}"
        logger.warning(error_msg)
        return error_msg


def post_message(config: SlackConfig, text: str) -> None:
    """Send a message to Slack via chat.postMessage.

    Raises on HTTP errors or Slack API errors (ok: false).
    """
    payload = {"channel": config.channel_id, "text": text}

    with httpx.Client(timeout=SLACK_TIMEOUT) as client:
        resp = client.post(
            config.effective_url,
            json=payload,
            headers={
                "Content-Type": "application/json; charset=utf-8",
                "Authorization": f"Bearer {config.bot_token}",
            },
        )

    if resp.status_code != 200:
        raise RuntimeError(f"Slack API returned HTTP {resp.status_code}")

    data = resp.json()
    if not data.get("ok"):
        raise RuntimeError(f"Slack API error: {data.get('error', 'unknown')}")


def _parse_env(content: str) -> dict[str, str]:
    """Parse KEY=VALUE lines. Skips empty lines and comments."""
    result: dict[str, str] = {}
    for line in content.split("\n"):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        if "=" in line:
            key, _, value = line.partition("=")
            result[key.strip()] = value.strip()
    return result
