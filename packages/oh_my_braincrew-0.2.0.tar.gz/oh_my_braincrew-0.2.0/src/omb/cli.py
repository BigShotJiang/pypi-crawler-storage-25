# BCRW-PLAN-000080: Dependency wiring and CLI registration
"""CLI entry point — replaces cmd/omb/main.go + internal/cli/root.go."""

from __future__ import annotations

import click

from omb.commands.hook import hook_group
from omb.commands.misc import (
    check_updates_cmd,
    doctor_cmd,
    feedback_cmd,
    init_cmd,
    kanban_cmd,
    loop_group,
    setup_lsp_cmd,
    statusline_cmd,
)
from omb.commands.update import update_cmd
from omb.commands.run import run_cmd
from omb.commands.tracking import tracking_group
from omb.commands.worktree import worktree_group
from omb.services.version import get_info, get_version


@click.group()
@click.version_option(version=get_version(), prog_name="omb")
def main() -> None:
    """oh-my-braincrew: Multi-agent orchestration harness for Claude Code."""


@main.command()
@click.option("--json", "as_json", is_flag=True, help="Output as JSON")
def version(as_json: bool) -> None:
    """Show omb version information."""
    info = get_info()
    if as_json:
        click.echo(info.to_json())
    else:
        click.echo(info)


main.add_command(init_cmd)
main.add_command(doctor_cmd)
main.add_command(update_cmd)
main.add_command(check_updates_cmd)
main.add_command(statusline_cmd)
main.add_command(setup_lsp_cmd)
main.add_command(feedback_cmd)
main.add_command(kanban_cmd)
main.add_command(loop_group)
main.add_command(hook_group)
main.add_command(tracking_group)
main.add_command(worktree_group)
main.add_command(run_cmd)


if __name__ == "__main__":
    main()
