# BCRW-PLAN-000080: Hook shim stub for future daemon routing
from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from omb.hook.handler import HookHandler
    from omb.hook.types import HookInput, HookOutput


def route_to_handler(handler: HookHandler, input: HookInput) -> HookOutput:
    """Route hook input to handler. Future: daemon mode routing."""
    return handler.handle(input)
