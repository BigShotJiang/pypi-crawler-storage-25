# BCRW-PLAN-000080: Hook security constants
"""Static security constants for hook enforcement.

All constants are plain string lists — no compiled regex, no functions.
Ported from Go ``internal/hook/pre_tool.go`` with identical values.
"""

from __future__ import annotations

import os
from pathlib import Path

# ---------------------------------------------------------------------------
# Bash deny patterns — always-dangerous substrings (no context sensitivity needed).
# These are dangerous regardless of where they appear in a command string.
# ---------------------------------------------------------------------------

DANGEROUS_BASH_SUBSTRINGS: list[str] = [
    "DROP DATABASE",
    "DROP TABLE",
    ":(){:|:&};:",
]

# ---------------------------------------------------------------------------
# Write/Edit path deny patterns
# ---------------------------------------------------------------------------

DENY_PATH_PATTERNS: list[str] = [
    ".env",
    ".env.",
    "secrets/",
    "credentials/",
    ".ssh/",
    ".git/",
    "docs/claude-code-docs/",
]

DENY_PATH_EXTENSIONS: list[str] = [
    ".pem",
    ".key",
]

# ---------------------------------------------------------------------------
# Allowlist — paths that bypass path deny checks (content scan still applies)
# ---------------------------------------------------------------------------

_home = Path.home()
ALLOWLIST_PREFIXES: list[str] = [
    str(_home / ".claude") + os.sep,
    str(_home / ".omb") + os.sep,
    str(_home / ".claude"),
    str(_home / ".omb"),
]
