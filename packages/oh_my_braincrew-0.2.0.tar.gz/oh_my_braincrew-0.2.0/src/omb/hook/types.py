# BCRW-PLAN-000080: Hook type system
"""Pydantic v2 models and enums for Claude Code hook I/O.

Defines the canonical type system consumed by all hook handlers in this package.

Wire format reference (Claude Code hooks-reference.md §Decision control):

    PreToolUse events use ``hookSpecificOutput``:
        allow → ``{}``
        deny  → ``{"hookSpecificOutput": {"hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": "..."}}``

    Other events (PostToolUse, Stop, UserPromptSubmit, etc.) use top-level keys:
        allow (no message) → ``{}``
        allow (with message) → ``{"systemMessage": "..."}``
        block → ``{"decision": "block", "reason": "..."}``

    PermissionRequest uses nested decision object:
        ``{"hookSpecificOutput": {"hookEventName": "PermissionRequest",
            "decision": {"behavior": "allow|deny", ...}}}``

    PermissionDenied retry:
        ``{"hookSpecificOutput": {"hookEventName": "PermissionDenied",
            "retry": true}}``

    TaskCreated/TaskCompleted/TeammateIdle stop:
        ``{"continue": false, "stopReason": "..."}``
"""

from __future__ import annotations

import json
from enum import StrEnum
from typing import Any

from pydantic import BaseModel, ConfigDict, Field


class EventType(StrEnum):
    """All Claude Code hook event types (27 total per official docs)."""

    # Session lifecycle
    SESSION_START = "SessionStart"
    SESSION_END = "SessionEnd"

    # Tool lifecycle
    PRE_TOOL_USE = "PreToolUse"
    POST_TOOL_USE = "PostToolUse"
    POST_TOOL_USE_FAILURE = "PostToolUseFailure"

    # Permission
    PERMISSION_REQUEST = "PermissionRequest"
    PERMISSION_DENIED = "PermissionDenied"

    # Turn lifecycle
    STOP = "Stop"
    STOP_FAILURE = "StopFailure"
    USER_PROMPT_SUBMIT = "UserPromptSubmit"

    # Context management
    PRE_COMPACT = "PreCompact"
    POST_COMPACT = "PostCompact"
    INSTRUCTIONS_LOADED = "InstructionsLoaded"

    # Agent lifecycle
    SUBAGENT_START = "SubagentStart"
    SUBAGENT_STOP = "SubagentStop"

    # Task lifecycle
    TASK_CREATED = "TaskCreated"
    TASK_COMPLETED = "TaskCompleted"
    TEAMMATE_IDLE = "TeammateIdle"

    # Notifications
    NOTIFICATION = "Notification"

    # Configuration
    CONFIG_CHANGE = "ConfigChange"

    # Environment
    CWD_CHANGED = "CwdChanged"
    FILE_CHANGED = "FileChanged"

    # Worktree
    WORKTREE_CREATE = "WorktreeCreate"
    WORKTREE_REMOVE = "WorktreeRemove"

    # MCP elicitation
    ELICITATION = "Elicitation"
    ELICITATION_RESULT = "ElicitationResult"

    # Deprecated — not in official docs; kept for backward compat
    SETUP = "Setup"


# Events that use hookSpecificOutput with permissionDecision for deny/ask/defer.
_PRE_TOOL_EVENTS: frozenset[EventType] = frozenset({EventType.PRE_TOOL_USE})

# Events that carry session-level context and drive pipeline transitions.
SESSION_EVENTS: frozenset[EventType] = frozenset(
    {
        EventType.STOP,
        EventType.USER_PROMPT_SUBMIT,
        EventType.SESSION_START,
        EventType.SESSION_END,
    }
)


class Decision(StrEnum):
    """Claude Code hook decision values."""

    ALLOW = "allow"
    BLOCK = "block"
    DENY = "deny"
    ASK = "ask"
    DEFER = "defer"


class HookInput(BaseModel):
    """Parsed representation of the JSON payload Claude Code sends to hook stdin.

    Uses a flat model with optional fields. Only one event type fires at a time,
    so field reuse across event types is safe. ``extra="ignore"`` prevents
    validation errors from unrecognized future fields.
    """

    model_config = ConfigDict(extra="ignore")

    # --- Common fields (all events) ---
    session_id: str
    cwd: str
    hook_event_name: str
    transcript_path: str = ""
    permission_mode: str = ""
    agent_id: str = ""
    agent_type: str = ""

    # --- SessionStart ---
    source: str = ""
    model: str = ""

    # --- UserPromptSubmit ---
    user_prompt: str | None = None  # Official name is "prompt"; normalized in protocol.py

    # --- Stop / SubagentStop ---
    stop_hook_active: bool = False
    last_assistant_message: str = ""

    # --- PreToolUse / PostToolUse / PostToolUseFailure ---
    tool_name: str | None = None
    tool_input: dict[str, Any] | None = None
    tool_use_id: str = ""
    tool_output: str | None = None

    # --- PostToolUse ---
    tool_response: str = ""

    # --- PostToolUseFailure ---
    error: str = ""
    is_interrupt: bool = False

    # --- SubagentStop ---
    agent_transcript_path: str = ""

    # --- Notification ---
    message: str = ""
    title: str = ""
    notification_type: str = ""

    # --- SessionEnd ---
    reason: str = ""

    # --- ConfigChange ---
    config_source: str = ""

    # --- PreCompact / PostCompact ---
    compaction_trigger: str = ""

    # --- TaskCreated / TaskCompleted ---
    task_id: str = ""
    task_subject: str = ""
    task_description: str = ""
    teammate_name: str = ""
    team_name: str = ""

    # --- PermissionRequest ---
    permission_suggestions: list[dict[str, Any]] = Field(default_factory=list)  # pyright: ignore[reportUnknownVariableType]

    # --- CwdChanged ---
    previous_cwd: str = ""

    # --- FileChanged ---
    file_path: str = ""
    file_name: str = ""

    # --- WorktreeCreate / WorktreeRemove ---
    branch: str = ""
    base_directory: str = ""
    worktree_path: str = ""

    # --- InstructionsLoaded ---
    memory_type: str = ""
    load_reason: str = ""
    globs: list[str] = Field(default_factory=list)
    trigger_file_path: str = ""
    parent_file_path: str = ""

    # --- Elicitation ---
    mcp_server_name: str = ""
    form_fields: list[dict[str, Any]] = Field(default_factory=list)  # pyright: ignore[reportUnknownVariableType]

    # --- ElicitationResult ---
    form_data: dict[str, Any] = Field(default_factory=dict)
    action: str = ""

    # --- Internal ---
    raw: dict[str, Any] = Field(default_factory=dict)
    omb_project_dir: str = ""


class HookOutput(BaseModel):
    """Structured response written to hook stdout for Claude Code to consume.

    Callers set ``decision``, ``message``, and optionally ``event_type``.
    ``to_stdout()`` produces the correct wire format based on the event type.
    """

    decision: Decision = Decision.ALLOW
    exit_code: int = 0
    message: str = ""
    event_type: EventType | None = None

    # Additional context injected into Claude's conversation
    additional_context: str = ""

    # PreToolUse: modify tool arguments before execution
    updated_input: dict[str, Any] | None = None

    # Suppress hook output from verbose mode
    suppress_output: bool = False

    # TaskCreated/TaskCompleted/TeammateIdle: stop teammate
    continue_task: bool | None = None  # None = not set; False = stop teammate
    stop_reason: str = ""

    # PermissionDenied: allow model to retry
    retry: bool = False

    # PermissionRequest: structured decision
    permission_behavior: str = ""  # "allow" or "deny"
    updated_permissions: list[dict[str, Any]] | None = None

    def to_stdout(self) -> str:
        """Serialize to the JSON wire format Claude Code expects on hook stdout.

        Format varies by event type per Claude Code docs. See module docstring
        for the full wire format reference.
        """
        result: dict[str, Any] = {}

        # --- Global flags ---
        if self.suppress_output:
            result["suppressOutput"] = True

        # --- Teammate stop (continue: false) ---
        if self.continue_task is False:
            result["continue"] = False
            if self.stop_reason:
                result["stopReason"] = self.stop_reason
            return json.dumps(result)

        # --- PermissionRequest structured decision ---
        if self.event_type == EventType.PERMISSION_REQUEST and self.permission_behavior:
            hso: dict[str, Any] = {"hookEventName": "PermissionRequest"}
            decision_obj: dict[str, Any] = {"behavior": self.permission_behavior}
            if self.message and self.permission_behavior == "deny":
                decision_obj["message"] = self.message
            if self.updated_permissions:
                decision_obj["updatedPermissions"] = self.updated_permissions
            if self.updated_input is not None:
                decision_obj["updatedInput"] = self.updated_input
            hso["decision"] = decision_obj
            result["hookSpecificOutput"] = hso
            return json.dumps(result)

        # --- PermissionDenied retry ---
        if self.event_type == EventType.PERMISSION_DENIED and self.retry:
            result["hookSpecificOutput"] = {
                "hookEventName": "PermissionDenied",
                "retry": True,
            }
            return json.dumps(result)

        # --- Allow path ---
        if self.decision == Decision.ALLOW:
            # Build hookSpecificOutput if we have context or input updates
            hso_data: dict[str, Any] = {}
            if self.additional_context:
                hso_data["additionalContext"] = self.additional_context
            if self.updated_input is not None:
                hso_data["updatedInput"] = self.updated_input
            if self.event_type and hso_data:
                hso_data["hookEventName"] = self.event_type.value
                result["hookSpecificOutput"] = hso_data
            elif self.message and not hso_data:
                result["systemMessage"] = self.message

            return json.dumps(result) if result else json.dumps({})

        # --- Deny / Block path ---

        # PreToolUse: hookSpecificOutput with permissionDecision
        if self.event_type in _PRE_TOOL_EVENTS:
            result["hookSpecificOutput"] = {
                "hookEventName": "PreToolUse",
                "permissionDecision": self.decision.value,
                "permissionDecisionReason": self.message,
            }
            if self.additional_context:
                result["hookSpecificOutput"]["additionalContext"] = self.additional_context
            return json.dumps(result)

        # Other events: top-level decision/reason
        result["decision"] = "block"
        result["reason"] = self.message
        return json.dumps(result)
