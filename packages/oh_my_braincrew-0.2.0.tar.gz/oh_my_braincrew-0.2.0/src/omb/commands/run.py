# BCRW-PLAN-000080: CLI commands — tracking, worktree, run
"""Click command for activating a pipeline from an existing session file.

`omb run <session_id>` validates that the session file exists, loads the
pipeline state, and activates the first pending task (RPR-007).
"""

from __future__ import annotations

import sys
from pathlib import Path  # noqa: TC003

import click

from omb.pipeline.definitions import TASK_SKILL_MAP
from omb.pipeline.storage import PipelineStorage
from omb.pipeline.types import PipelineStatus, TaskStatus
from omb.services.paths import resolve_project_root

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _project_root() -> Path:
    """Resolve project root. Delegates to resolve_project_root() (RPR-044)."""
    return resolve_project_root()


# ---------------------------------------------------------------------------
# Command
# ---------------------------------------------------------------------------


@click.command("run")
@click.argument("session_id")
def run_cmd(session_id: str) -> None:
    """Activate the first pending task for an existing pipeline session.

    SESSION_ID is the pipeline session identifier (16-char hex).
    Validates the session file exists, then activates the first pending task
    and prints the skill to invoke (RPR-007).
    """
    root = _project_root()
    storage = PipelineStorage(root)

    if not storage.exists(session_id):
        click.echo(f"[run] session {session_id!r} not found", err=True)
        sys.exit(1)

    state = storage.load(session_id)
    if state is None:
        click.echo(f"[run] failed to load session {session_id!r}", err=True)
        sys.exit(1)

    if state.status != PipelineStatus.ACTIVE:
        click.echo(
            f"[run] pipeline {session_id!r} is {state.status}, not active",
            err=True,
        )
        sys.exit(1)

    # Find the first pending task and activate it.
    activated = False
    for task in state.tasks:
        if task.status == TaskStatus.PENDING:
            task.status = TaskStatus.ACTIVE
            state.current_task = state.tasks.index(task)
            activated = True
            break

    if not activated:
        # Check if there is already an active task.
        active = state.active_task()
        if active is not None and active.status == TaskStatus.ACTIVE:
            skill_name = TASK_SKILL_MAP.get(active.task_name, active.task_name)
            click.echo(f"pipeline_id: {state.session_id}")
            click.echo(f"invoke {skill_name}")
            return
        click.echo(f"[run] no pending tasks in pipeline {session_id!r}", err=True)
        sys.exit(1)

    storage.save(state)

    active = state.active_task()
    skill_name = TASK_SKILL_MAP.get(active.task_name, active.task_name) if active else ""
    click.echo(f"pipeline_id: {state.session_id}")
    if skill_name:
        click.echo(f"invoke {skill_name}")
