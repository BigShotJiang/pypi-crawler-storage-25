# BCRW-PLAN-000080: Stub CLI commands for Go parity
"""Stub Click commands for omb CLI parity with the Go binary.

Each command prints a "not yet implemented" notice and exits 0.
These stubs satisfy Go binary parity so `omb --help` shows a complete
command surface while Python implementations are pending.
"""

from __future__ import annotations

import click


@click.command("init")
@click.argument("path", default=".")
def init_cmd(path: str) -> None:
    """Initialize omb in a project directory."""
    click.echo(f"omb init: not yet implemented (target: {path})")


@click.command("doctor")
def doctor_cmd() -> None:
    """Run diagnostics on omb installation."""
    click.echo("omb doctor: not yet implemented")


@click.command("check-updates")
def check_updates_cmd() -> None:
    """Check for available updates."""
    click.echo("omb check-updates: not yet implemented")


# BCRW-PLAN-000083: Wire CLI statusline command to service
@click.command("statusline", hidden=True)
@click.option("--mode", default="", help="Display mode: default or full")
def statusline_cmd(mode: str) -> None:
    """Render statusline for Claude Code (reads JSON from stdin)."""
    import os
    import sys
    from pathlib import Path

    from omb.services.config import load_config
    from omb.services.statusline import build

    cwd = os.getcwd()

    # Resolve mode: --mode flag > config > "default"
    cfg = load_config(Path(cwd))
    if not mode:
        if cfg.statusline.mode:
            mode = cfg.statusline.mode

    no_color = "NO_COLOR" in os.environ
    no_emoji = cfg.statusline.no_emoji

    output = build(reader=sys.stdin, root_dir=cwd, no_color=no_color,
                   no_emoji=no_emoji, mode=mode or "default")
    if output:
        click.echo(output, nl=False)


@click.command("setup-lsp")
def setup_lsp_cmd() -> None:
    """Set up LSP configuration."""
    click.echo("omb setup-lsp: not yet implemented")


@click.command("feedback")
@click.argument("message", default="")
def feedback_cmd(message: str) -> None:
    """Submit feedback or report an issue."""
    click.echo("omb feedback: not yet implemented")


@click.command("kanban")
def kanban_cmd() -> None:
    """Manage kanban board."""
    click.echo("omb kanban: not yet implemented")


@click.group("loop")
def loop_group() -> None:
    """Loop management commands."""


@loop_group.command("start")
@click.argument("interval")
@click.argument("task")
def loop_start(interval: str, task: str) -> None:
    """Start a recurring loop."""
    click.echo(f"omb loop start: not yet implemented (interval={interval}, task={task})")


@loop_group.command("stop")
def loop_stop() -> None:
    """Stop active loop."""
    click.echo("omb loop stop: not yet implemented")
