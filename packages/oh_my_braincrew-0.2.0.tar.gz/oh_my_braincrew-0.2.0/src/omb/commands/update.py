"""omb update — pull latest and reinstall, cleaning legacy Go artifacts."""

from __future__ import annotations

import shutil
import subprocess
import sys
from pathlib import Path

import click


# Legacy artifacts left over from the Go-binary era.
_LEGACY_REPO_PATHS = ("bin/omb", "bin/braincrew")
_LEGACY_HOME_PATHS = (
    "~/.local/bin/omb",
    "~/.local/bin/braincrew",
    "~/go/bin/omb",
    "~/go/bin/braincrew",
)


def _remove(path: Path, *, label: str) -> bool:
    """Remove a file or symlink. Returns True if something was removed."""
    if path.is_symlink() or path.is_file():
        path.unlink()
        click.echo(f"  removed {label}: {path}")
        return True
    return False


def _rmdir(path: Path, *, label: str) -> bool:
    """Remove a directory tree. Returns True if something was removed."""
    if path.is_dir():
        shutil.rmtree(path)
        click.echo(f"  removed {label}: {path}")
        return True
    return False


def _clean_legacy(repo_root: Path) -> int:
    """Remove Go-era legacy artifacts. Returns count of items removed."""
    removed = 0

    # Go binaries inside the repo
    for rel in _LEGACY_REPO_PATHS:
        removed += _remove(repo_root / rel, label="legacy Go binary")

    # Remove bin/ directory if now empty
    bin_dir = repo_root / "bin"
    if bin_dir.is_dir() and not any(bin_dir.iterdir()):
        bin_dir.rmdir()
        click.echo(f"  removed empty directory: {bin_dir}")

    # Installed Go binaries in ~/.local/bin
    for raw in _LEGACY_HOME_PATHS:
        removed += _remove(Path(raw).expanduser(), label="legacy installed binary")

    # Legacy home directory ~/.braincrew
    removed += _rmdir(Path.home() / ".braincrew", label="legacy home dir")

    # Legacy Go build cache
    removed += _rmdir(repo_root / "build", label="legacy Go build dir")

    # Old setup.sh (Go-era installer)
    removed += _remove(repo_root / "scripts" / "setup.sh", label="legacy Go setup script")

    return removed


def _link_to_path(repo_root: Path) -> None:
    """Ensure ~/.local/bin/omb symlinks to the venv entry point."""
    venv_bin = repo_root / ".venv" / "bin" / "omb"
    if not venv_bin.is_file():
        return

    local_bin = Path.home() / ".local" / "bin"
    local_bin.mkdir(parents=True, exist_ok=True)
    link = local_bin / "omb"

    # Remove stale file/symlink if present
    if link.is_symlink() or link.is_file():
        link.unlink()

    link.symlink_to(venv_bin)
    click.echo(f"  symlinked {link} -> {venv_bin}")


def _run(cmd: list[str], *, cwd: Path) -> None:
    """Run a subprocess, raising on failure."""
    result = subprocess.run(cmd, cwd=cwd, capture_output=True, text=True)
    if result.returncode != 0:
        stderr = result.stderr.strip() or result.stdout.strip()
        raise click.ClickException(f"`{' '.join(cmd)}` failed:\n{stderr}")


def _ensure_uv() -> str:
    """Return the path to uv, installing it if missing."""
    uv = shutil.which("uv")
    if uv:
        return uv

    click.echo("uv not found — installing via official installer...")
    subprocess.run(
        ["sh", "-c", "curl -LsSf https://astral.sh/uv/install.sh | sh"],
        check=True,
    )

    # After install, uv lands in ~/.local/bin
    uv = shutil.which("uv") or str(Path.home() / ".local" / "bin" / "uv")
    if not Path(uv).is_file():
        raise click.ClickException("uv installation failed — install manually: https://docs.astral.sh/uv/")
    return uv


@click.command("update")
@click.option("--clean-only", is_flag=True, help="Only remove legacy artifacts without updating")
def update_cmd(clean_only: bool) -> None:
    """Update omb to latest version and clean legacy Go artifacts."""
    from omb.services.home import read_home

    # Resolve repo root
    try:
        repo_root = Path(read_home())
    except FileNotFoundError:
        repo_root = Path.cwd()

    if not (repo_root / ".omb").is_dir():
        raise click.ClickException(f"Not an omb repo: {repo_root}")

    # Phase 1: Clean legacy artifacts
    click.echo("Cleaning legacy artifacts...")
    removed = _clean_legacy(repo_root)
    if removed:
        click.echo(f"  cleaned {removed} legacy item(s)")
    else:
        click.echo("  no legacy artifacts found")

    # Ensure omb is on PATH via symlink
    _link_to_path(repo_root)

    if clean_only:
        click.echo("Done (clean-only mode).")
        return

    # Phase 2: Git pull
    click.echo("Pulling latest changes...")
    _run(["git", "pull", "--ff-only"], cwd=repo_root)

    # Phase 3: Reinstall via uv
    click.echo("Reinstalling package...")
    uv = _ensure_uv()
    _run([uv, "venv", str(repo_root / ".venv")], cwd=repo_root)
    _run([uv, "pip", "install", "-e", ".[dev]"], cwd=repo_root)

    click.echo("Update complete.")
    # Show new version
    _run([sys.executable, "-m", "omb", "version"], cwd=repo_root)
