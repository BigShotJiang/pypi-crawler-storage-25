# BCRW-PLAN-000080: CLI commands — tracking, worktree, run
"""Click command group for tracking code allocation.

Provides `omb tracking next <kind>` which atomically allocates and prints the
next tracking code (e.g. BCRW-PLAN-000042) from .omb/config.json.
"""

from __future__ import annotations

import sys
from pathlib import Path  # noqa: TC003

import click

from omb.services.paths import resolve_project_root
from omb.services.tracking import VALID_KINDS, next_tracking_code

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _project_root() -> Path:
    """Resolve project root. Delegates to resolve_project_root() (RPR-044)."""
    return resolve_project_root()


# ---------------------------------------------------------------------------
# Click group
# ---------------------------------------------------------------------------

tracking_group = click.Group("tracking", help="Tracking code allocation commands.")


@tracking_group.command("next")
@click.argument("kind", metavar="KIND")
def tracking_next(kind: str) -> None:
    """Allocate and print the next tracking code for KIND.

    KIND must be one of: PLAN, PR.

    Outputs one line: e.g. BCRW-PLAN-000042
    """
    kind_upper = kind.upper()
    if kind_upper not in VALID_KINDS:
        click.echo(
            f"[tracking] invalid kind {kind!r}; must be one of {sorted(VALID_KINDS)}",
            err=True,
        )
        sys.exit(1)

    try:
        code = next_tracking_code(_project_root(), kind_upper)
    except ValueError as exc:
        click.echo(f"[tracking] {exc}", err=True)
        sys.exit(1)

    click.echo(code)
