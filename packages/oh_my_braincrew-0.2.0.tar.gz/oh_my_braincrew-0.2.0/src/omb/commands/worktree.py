# BCRW-PLAN-000080: CLI commands — tracking, worktree, run
"""Click command group for git worktree management.

Provides `omb worktree list|remove|status|clean` using omb.services.git.
"""

from __future__ import annotations

import sys

import click

import omb.services.git as git_svc

# ---------------------------------------------------------------------------
# Click group
# ---------------------------------------------------------------------------

worktree_group = click.Group("worktree", help="Git worktree management commands.")


@worktree_group.command("list")
def worktree_list() -> None:
    """List all git worktrees with path, branch, and HEAD."""
    try:
        entries = git_svc.worktree_list()
    except Exception as exc:
        click.echo(f"[worktree] list failed: {exc}", err=True)
        sys.exit(1)

    if not entries:
        click.echo("No worktrees found.")
        return

    for entry in entries:
        bare_marker = " (bare)" if entry.bare else ""
        click.echo(f"{entry.path}  {entry.branch}  {entry.head}{bare_marker}")


@worktree_group.command("remove")
@click.argument("path")
@click.option("--force", is_flag=True, default=False, help="Force removal of dirty worktrees.")
def worktree_remove(path: str, force: bool) -> None:
    """Remove a linked worktree at PATH."""
    try:
        git_svc.worktree_remove(path, force=force)
    except Exception as exc:
        click.echo(f"[worktree] remove failed: {exc}", err=True)
        sys.exit(1)

    click.echo(f"Removed worktree: {path}")


@worktree_group.command("status")
def worktree_status() -> None:
    """Show worktree info (alias for list with richer label)."""
    try:
        entries = git_svc.worktree_list()
    except Exception as exc:
        click.echo(f"[worktree] status failed: {exc}", err=True)
        sys.exit(1)

    if not entries:
        click.echo("No worktrees found.")
        return

    for entry in entries:
        bare_label = " [bare]" if entry.bare else ""
        click.echo(f"path:   {entry.path}")
        click.echo(f"branch: {entry.branch}{bare_label}")
        click.echo(f"HEAD:   {entry.head}")
        click.echo("")


@worktree_group.command("clean")
def worktree_clean() -> None:
    """Remove worktrees whose branches have been merged into main."""
    try:
        entries = git_svc.worktree_list()
    except Exception as exc:
        click.echo(f"[worktree] clean: list failed: {exc}", err=True)
        sys.exit(1)

    removed = 0
    for entry in entries:
        if not entry.branch or entry.bare:
            continue
        # Strip refs/heads/ prefix for branch_merged check.
        branch_name = entry.branch.removeprefix("refs/heads/")
        try:
            if git_svc.branch_merged(branch_name, "main"):
                git_svc.worktree_remove(entry.path)
                click.echo(f"Removed merged worktree: {entry.path}")
                removed += 1
        except Exception as exc:
            click.echo(f"[worktree] skipping {entry.path}: {exc}", err=True)

    if removed == 0:
        click.echo("No merged worktrees to clean.")
    else:
        click.echo(f"Cleaned {removed} worktree(s).")
