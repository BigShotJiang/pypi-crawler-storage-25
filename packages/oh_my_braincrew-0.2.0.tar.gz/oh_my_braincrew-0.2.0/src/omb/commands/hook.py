# BCRW-PLAN-000080: CLI hook subcommands
"""Click command group exposing one subcommand per Claude Code hook event.

Each subcommand reads JSON from stdin, dispatches to HookHandler, and writes
the result to stdout.  On any exception the handler exits 0 (fail-safe) to
avoid blocking Claude Code's hook lifecycle.
"""

from __future__ import annotations

import sys

import click

# ---------------------------------------------------------------------------
# Shared implementation
# ---------------------------------------------------------------------------


def _run_hook_event(event_name: str) -> None:
    """Dispatch a single hook event: read stdin → handle → write stdout.

    Lazy-imports protocol and deps to keep CLI startup fast.
    Exit code is always 0 even on error (fail-safe: never block Claude Code).
    """
    try:
        from omb.deps import get_handler
        from omb.hook.protocol import read_input, write_output

        handler = get_handler()
        hook_input = read_input(sys.stdin)
        hook_output = handler.handle(hook_input)
        write_output(hook_output, sys.stdout)
        sys.exit(hook_output.exit_code)
    except Exception as exc:  # noqa: BLE001 — fail-safe: log and exit 0
        print(f"[omb hook] error handling {event_name}: {exc}", file=sys.stderr)
        sys.exit(0)


# ---------------------------------------------------------------------------
# Command group and per-event subcommands
# ---------------------------------------------------------------------------

hook_group = click.Group("hook")

# All 16 Claude Code hook events (RPR-052: use default arg to avoid B023 closure).
_EVENT_COMMANDS: list[tuple[str, str]] = [
    # Session lifecycle
    ("session-start", "SessionStart"),
    ("session-end", "SessionEnd"),
    # Tool lifecycle
    ("pre-tool-use", "PreToolUse"),
    ("post-tool-use", "PostToolUse"),
    ("post-tool-failure", "PostToolUseFailure"),
    # Permission
    ("permission-request", "PermissionRequest"),
    ("permission-denied", "PermissionDenied"),
    # Turn lifecycle
    ("stop", "Stop"),
    ("stop-failure", "StopFailure"),
    ("user-prompt-submit", "UserPromptSubmit"),
    # Context management
    ("pre-compact", "PreCompact"),
    ("post-compact", "PostCompact"),
    ("instructions-loaded", "InstructionsLoaded"),
    # Agent lifecycle
    ("subagent-start", "SubagentStart"),
    ("subagent-stop", "SubagentStop"),
    # Task lifecycle
    ("task-created", "TaskCreated"),
    ("task-completed", "TaskCompleted"),
    ("teammate-idle", "TeammateIdle"),
    # Notifications
    ("notification", "Notification"),
    # Configuration
    ("config-change", "ConfigChange"),
    # Environment
    ("cwd-changed", "CwdChanged"),
    ("file-changed", "FileChanged"),
    # Worktree
    ("worktree-create", "WorktreeCreate"),
    ("worktree-remove", "WorktreeRemove"),
    # MCP elicitation
    ("elicitation", "Elicitation"),
    ("elicitation-result", "ElicitationResult"),
    # Deprecated
    ("setup", "Setup"),
]

for _cmd_name, _event_name in _EVENT_COMMANDS:

    @hook_group.command(_cmd_name)
    def _cmd(en: str = _event_name) -> None:  # noqa: B023 — captured via default arg  # type: ignore[reportUnusedFunction]
        _run_hook_event(en)
