# BCRW-PLAN-000080: Module entry point for python3 -m omb
"""Entry point for running omb as a Python module: ``python3 -m omb``."""

from omb.cli import main

main()
