"""Loop state types for the omb-loop skill.

# BCRW-PLAN-000080: Loop controller stub
"""

from __future__ import annotations

from datetime import datetime  # noqa: TC003
from enum import StrEnum

from pydantic import BaseModel, Field

# ---------------------------------------------------------------------------
# Enums
# ---------------------------------------------------------------------------


class LoopStatus(StrEnum):
    """Lifecycle state of a recurring loop."""

    ACTIVE = "active"
    PAUSED = "paused"
    COMPLETED = "completed"
    CANCELLED = "cancelled"


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------


class LoopState(BaseModel):
    """State of a single recurring loop stored in .omb/loops/{id}.json."""

    id: str
    task: str
    interval_seconds: int
    status: LoopStatus = LoopStatus.ACTIVE
    iteration: int = 0
    created_at: datetime
    last_run_at: datetime | None = None


class LoopSummary(BaseModel):
    """Lightweight summary used when listing loops."""

    id: str = Field(description="Loop identifier")
    task: str = Field(description="Task description")
    status: LoopStatus
    iteration: int
