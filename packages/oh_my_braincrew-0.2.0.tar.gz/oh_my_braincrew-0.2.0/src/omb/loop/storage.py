"""Loop storage — read/write .omb/loops/{id}.json with atomic writes.

# BCRW-PLAN-000080: Loop controller stub

Mirrors the atomic-write pattern from services/config.py:
temp file → fsync → rename (POSIX-atomic).
"""

from __future__ import annotations

import contextlib
import os
import tempfile
from pathlib import Path  # noqa: TC003

from omb.loop.types import LoopState


class LoopStorage:
    """Persistent storage for loop state files under .omb/loops/."""

    def __init__(self, project_root: Path) -> None:
        self._loops_dir = project_root / ".omb" / "loops"

    def _ensure_dir(self) -> None:
        self._loops_dir.mkdir(parents=True, exist_ok=True)

    def _loop_path(self, loop_id: str) -> Path:
        return self._loops_dir / f"{loop_id}.json"

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def load(self, loop_id: str) -> LoopState | None:
        """Return the LoopState for loop_id, or None if not found."""
        path = self._loop_path(loop_id)
        if not path.exists():
            return None
        try:
            return LoopState.model_validate_json(path.read_text())
        except Exception:
            return None

    def save(self, state: LoopState) -> None:
        """Atomically write state to .omb/loops/{id}.json."""
        self._ensure_dir()
        path = self._loop_path(state.id)
        serialized = state.model_dump_json(indent=2)

        fd, tmp_path = tempfile.mkstemp(dir=str(self._loops_dir), suffix=".tmp")
        try:
            with os.fdopen(fd, "w") as tmp_file:
                tmp_file.write(serialized)
                tmp_file.flush()
                os.fsync(tmp_file.fileno())
            os.rename(tmp_path, str(path))
        except Exception:
            with contextlib.suppress(OSError):
                os.unlink(tmp_path)
            raise

    def list_loops(self) -> list[str]:
        """Return sorted list of loop IDs (filenames without .json suffix)."""
        if not self._loops_dir.exists():
            return []
        return sorted(p.stem for p in self._loops_dir.glob("*.json"))

    def delete(self, loop_id: str) -> None:
        """Remove the state file for loop_id. No-op if it does not exist."""
        path = self._loop_path(loop_id)
        with contextlib.suppress(FileNotFoundError):
            path.unlink()
