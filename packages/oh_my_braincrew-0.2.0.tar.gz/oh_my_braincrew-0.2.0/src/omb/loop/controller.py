"""Loop controller — create, stop, and query recurring loop state.

# BCRW-PLAN-000080: Loop controller stub

Stub implementation providing minimal API surface so the omb-loop skill
continues to function after the Go binary is removed. Full feature parity
(interval execution, sub-pipeline orchestration) is deferred to a follow-up.
"""

from __future__ import annotations

import uuid
from datetime import UTC, datetime
from typing import TYPE_CHECKING

from omb.loop.types import LoopState, LoopStatus

if TYPE_CHECKING:
    from omb.loop.storage import LoopStorage


class LoopController:
    """Manages loop lifecycle: create, stop, and introspect active loops."""

    def __init__(self, storage: LoopStorage) -> None:
        self._storage = storage

    # ------------------------------------------------------------------
    # Public API
    # ------------------------------------------------------------------

    def start(self, task: str, interval_seconds: int) -> LoopState:
        """Create a new active loop, persist it, and return its state."""
        state = LoopState(
            id=uuid.uuid4().hex[:16],
            task=task,
            interval_seconds=interval_seconds,
            status=LoopStatus.ACTIVE,
            iteration=0,
            created_at=datetime.now(tz=UTC),
            last_run_at=None,
        )
        self._storage.save(state)
        return state

    def stop(self, loop_id: str) -> None:
        """Mark a loop as cancelled. No-op if the loop does not exist."""
        state = self._storage.load(loop_id)
        if state is None:
            return
        state.status = LoopStatus.CANCELLED
        self._storage.save(state)

    def get_active(self) -> LoopState | None:
        """Return the first loop with ACTIVE status, or None."""
        for loop_id in self._storage.list_loops():
            state = self._storage.load(loop_id)
            if state is not None and state.status == LoopStatus.ACTIVE:
                return state
        return None
