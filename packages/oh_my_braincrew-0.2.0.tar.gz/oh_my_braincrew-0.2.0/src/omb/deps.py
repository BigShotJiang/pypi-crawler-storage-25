# BCRW-PLAN-000080: Dependency wiring and CLI registration
"""Shared dependency factories consumed by CLI command groups.

Centralises construction of stateful singletons (HookHandler, session manager)
so that command modules can import them lazily without circular dependencies.
"""

from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from omb.services.paths import resolve_project_root

if TYPE_CHECKING:
    from omb.hook.handler import HookHandler


def _project_root() -> str:
    """Return the project root directory as a string.

    Delegates to resolve_project_root() for centralized resolution (RPR-044).
    No caching — re-resolves on every call so tests can monkeypatch freely.
    """
    return str(resolve_project_root())


def get_handler() -> HookHandler:
    """Return a fully-wired HookHandler instance.

    When pipeline.enabled is True in .omb/config.json, constructs the full
    session manager chain:
        PipelineStorage → PipelineResolver → SessionHandler → SessionManager

    The concrete SessionManager.handle(event, input, status) is adapted to the
    handle_event(hook_input) protocol expected by HookHandler via a thin lambda
    adapter.  If pipeline is disabled or config cannot be loaded, returns a bare
    HookHandler with no session manager.

    All heavy imports are inside this function body (lazy imports, RPR-021).
    """
    # Lazy imports for startup performance (RPR-021).
    from omb.hook.handler import HookHandler, parse_result_status
    from omb.hook.types import EventType, HookInput, HookOutput
    from omb.services.config import load_config

    root = Path(_project_root())
    cfg = load_config(root)

    if not cfg.pipeline.enabled:
        return HookHandler()

    from omb.pipeline.resolver import PipelineResolver
    from omb.pipeline.storage import PipelineStorage
    from omb.pipeline.types import ResultStatus
    from omb.session.handler import SessionHandler
    from omb.session.manager import SessionManager as ConcreteSessionManager

    storage = PipelineStorage(root)
    resolver = PipelineResolver(storage)
    session_handler = SessionHandler(storage)
    concrete_manager = ConcreteSessionManager(resolver=resolver, handler=session_handler)

    class _SessionManagerAdapter:
        """Adapter from handle_event(hook_input) → concrete handle(event, input, status)."""

        def handle_event(self, event_input: HookInput) -> HookOutput:
            try:
                event = EventType(event_input.hook_event_name)
            except ValueError:
                return HookOutput()

            raw_status = parse_result_status(event_input.last_assistant_message)
            try:
                status = ResultStatus(raw_status) if raw_status else ResultStatus.NONE
            except ValueError:
                status = ResultStatus.NONE

            return concrete_manager.handle(event=event, input=event_input, status=status)

    return HookHandler(session_manager=_SessionManagerAdapter())
