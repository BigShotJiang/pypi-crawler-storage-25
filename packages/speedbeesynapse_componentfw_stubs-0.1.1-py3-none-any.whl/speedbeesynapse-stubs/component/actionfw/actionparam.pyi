from .errors import InternalError as InternalError
from .jsonpath import _SynapseJsonPath
from .types import FrozenJsonType as FrozenJsonType
from re import Pattern
from speedbeesynapse.component.base import DataType as DataType
from typing import Generic, TypeVar

T = TypeVar('T')

class _ActionParam(Generic[T]):
    def __init__(self, value_or_jpath: T | _SynapseJsonPath) -> None: ...
    def resolve(self, param: FrozenJsonType, path: str) -> T: ...

class _ActionParamBool(_ActionParam[bool]):
    def __init__(self, value_or_jpath: bool | _SynapseJsonPath) -> None: ...

class _ActionParamInt(_ActionParam[int]):
    def __init__(self, value_or_jpath: int | _SynapseJsonPath) -> None: ...

class _ActionParamFloat(_ActionParam[float]):
    def __init__(self, value_or_jpath: float | _SynapseJsonPath) -> None: ...

class _ActionParamStr(_ActionParam[str]):
    def __init__(self, value_or_jpath: str | _SynapseJsonPath) -> None: ...

class _ActionParamRegExp(_ActionParam[Pattern[str]]):
    def __init__(self, value_or_jpath: str | Pattern[str] | _SynapseJsonPath) -> None: ...

class _ActionParamDataType(_ActionParam[DataType]):
    def __init__(self, value_or_jpath: DataType | _SynapseJsonPath) -> None: ...

class _ActionParamDataTypeList(_ActionParam[list[DataType]]):
    def __init__(self, value_or_jpath: list[DataType] | _SynapseJsonPath) -> None: ...
