from .actionparam import _ActionParamBool, _ActionParamDataTypeList, _ActionParamFloat, _ActionParamRegExp, _ActionParamStr
from .errors import InternalError as InternalError
from .types import FrozenJsonType as FrozenJsonType, MSec as MSec
from _typeshed import Incomplete
from collections.abc import Callable as Callable
from dataclasses import dataclass
from enum import IntEnum
from re import Pattern
from speedbeesynapse.component.base import DataType as DataType, HiveRecord as HiveRecord, HiveRecordData as HiveRecordData, HiveWindowData as HiveWindowData

class TriggerType(IntEnum):
    NONE = 0
    TIME = 1
    DATA = 2
    RECORD = 3
    WINDOW = 4
    CALL = 5

@dataclass
class TriggerContext:
    trigger_type: TriggerType
    window_data: HiveWindowData | None = ...
    record: HiveRecord | None = ...
    data: HiveRecordData | None = ...
    @property
    def time(self) -> float | None: ...

class _ActionTrigger:
    t_type: Incomplete
    def set_action(self, action: Callable[[TriggerContext], None]) -> None: ...
    def __call__(self, trigger_context: TriggerContext) -> None: ...

class _ActionTriggerByTime(_ActionTrigger):
    t_type: Incomplete
    interval: Incomplete
    def __init__(self, interval: MSec) -> None: ...

class _ActionTriggerByData(_ActionTrigger):
    t_type: Incomplete
    component_name: Incomplete
    data_name: Incomplete
    data_types: Incomplete
    def __init__(self, component_name: str | Pattern[str] | None = None, data_name: str | Pattern[str] | None = None, data_types: list[DataType] | None = None) -> None: ...

class _ActionTriggerByRecord(_ActionTrigger):
    t_type: Incomplete

@dataclass
class _ActionTriggerBase:
    def resolve(self, param: FrozenJsonType, path: str) -> _ActionTrigger | None: ...

@dataclass
class _ActionTriggerBaseByTime(_ActionTriggerBase):
    interval: _ActionParamFloat
    enabled: _ActionParamBool | None = ...
    def resolve(self, param: FrozenJsonType, path: str) -> _ActionTrigger | None: ...

@dataclass
class _ActionTriggerBaseByData(_ActionTriggerBase):
    component_name: _ActionParamStr | None = ...
    component_name_pattern: _ActionParamRegExp | None = ...
    data_name: _ActionParamStr | None = ...
    data_name_pattern: _ActionParamRegExp | None = ...
    data_types: _ActionParamDataTypeList | None = ...
    enabled: _ActionParamBool | None = ...
    def resolve(self, param: FrozenJsonType, path: str) -> _ActionTrigger | None: ...

@dataclass
class _ActionTriggerBaseByRecord(_ActionTriggerBase):
    def resolve(self, _param: FrozenJsonType, _path: str) -> _ActionTrigger | None: ...
