from _typeshed import Incomplete
from typing import TypeVar

KT = TypeVar('KT')
VT = TypeVar('VT')

class FrozenDict(dict[KT, VT]):
    __setitem__: Incomplete
    __delitem__: Incomplete
    __ior__: Incomplete
    clear: Incomplete
    update: Incomplete
    setdefault: Incomplete
    pop: Incomplete
    popitem: Incomplete

class FrozenList(list[VT]):
    __setitem__: Incomplete
    __delitem__: Incomplete
    __ior__: Incomplete
    sort: Incomplete
    append: Incomplete
    clear: Incomplete
    extend: Incomplete
    insert: Incomplete
    pop: Incomplete
    remove: Incomplete
    reverse: Incomplete

FrozenJsonType: Incomplete
JsonType: Incomplete
MSec: Incomplete
MIN_INTERVAL_MS: Incomplete
