# teajuda-core

Pacote Python compartilhado contendo domínio, infraestrutura, repositórios e serviços da plataforma Te Ajuda.

## Instalação local

```bash
pip install -e ".[dev]"
```

## Estrutura

```
teajuda_core/
├── auth/           # JWT, middleware ASGI e dependências FastAPI
├── exceptions/     # Exceções de domínio compartilhadas
├── infrastructure/ # Configurações, MongoDB e logging
├── models/         # Schemas Pydantic
├── repositories/   # Acesso a dados (BaseRepository + específicos)
├── services/       # Regras de negócio
└── utils/          # Helpers genéricos
```
