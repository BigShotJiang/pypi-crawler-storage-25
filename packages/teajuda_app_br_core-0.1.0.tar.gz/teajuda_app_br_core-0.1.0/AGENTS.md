# teajuda-core

Pacote Python compartilhado contendo domínio, infraestrutura, repositórios e serviços da plataforma **Te Ajuda** (também referenciada internamente como *Tutto*).

Este projeto é uma biblioteca de core que serve como base para aplicações FastAPI e servidores MCP da plataforma. Não é uma aplicação standalone — ele é instalado como dependência em outros projetos.

---

## Visão Geral da Arquitetura

O código segue uma arquitetura em camadas com separação clara entre:

- **`models/`** — Schemas Pydantic v2 para entrada, saída e atualização de dados.
- **`repositories/`** — Acesso a dados assíncrono usando Motor (MongoDB async). Cada entidade possui um repositório específico que estende `BaseRepository`.
- **`services/`** — Regras de negócio e orquestração. Serviços encapsulam repositórios e integrações externas.
- **`auth/`** — Utilitários JWT, middleware ASGI de autenticação unificada e dependências FastAPI.
- **`infrastructure/`** — Configurações, conexão MongoDB, logging e lifespan compartilhado.
- **`exceptions/`** — Hierarquia de exceções de domínio compartilhadas.
- **`utils/`** — Helpers genéricos (atualmente vazio).

### Entidades Principais

| Entidade | Descrição |
|----------|-----------|
| `Tenant` | Instância/WhatsApp de um cliente (barbearia, etc.) |
| `Customer` | Usuário final da plataforma (pode ter múltiplos tenants) |
| `User` | Usuário interno vinculado a um tenant |
| `Schedule` | Agendamento de serviços |
| `Subscription` / `Plan` / `Payment` | Gestão de assinaturas e pagamentos |
| `Coupon` | Cupons de desconto |
| `Event` / `Message` / `Instruction` | Eventos, mensagens e instruções de operação |
| `Session` / `SecurityIdentity` | Sessões e identidades de API (client_id/client_secret) |
| `WebhookEvent` | Eventos de webhook recebidos |

---

## Tecnologias e Dependências

- **Python:** >= 3.10 (suporta 3.10, 3.11, 3.12)
- **Framework Web:** FastAPI (para dependências e middleware)
- **Banco de Dados:** MongoDB, acessado via `motor` (driver async)
- **Validação/Settings:** Pydantic v2 + pydantic-settings
- **Autenticação:** PyJWT, passlib[bcrypt], OAuth2 (Google OAuth 2.0)
- **Integrações Externas:**
  - Mercado Pago (`mercadopago` SDK) — pagamentos
  - Evolution API (`httpx`) — WhatsApp (instâncias, QR code, webhooks, envio de mensagens)
- **Build:** hatchling
- **Gerenciamento de Pacotes:** `uv` (presença de `uv.lock`)

### Dependências de Desenvolvimento

- `pytest` + `pytest-asyncio` — testes unitários
- `black` — formatação
- `ruff` — linting e import sorting
- `mypy` — type checking

---

## Comandos de Build e Teste

### Instalação Local

```bash
pip install -e ".[dev]"
```

Ou com `uv`:

```bash
uv pip install -e ".[dev]"
```

### Executar Testes

```bash
pytest
```

Os testes rodam sem necessidade de MongoDB real — usam mocks (`unittest.mock.AsyncMock`, `MagicMock`).

### Formatação e Lint

```bash
black src tests
ruff check src tests
mypy src
```

---

## Guia de Estilo de Código

- **Idioma:** Todo o código, docstrings, mensagens de erro e comentários devem ser escritos em **português (Brasil)**.
- **Line length:** 100 caracteres (configurado no `pyproject.toml` para Black e Ruff).
- **Imports:** Ruff organiza imports automaticamente (`select = ["E", "F", "I", "N", "W", "B", "Q"]`).
- **Tipagem:** Anotações de tipo são incentivadas mas não obrigatórias (`disallow_untyped_defs = false` no mypy).
- **Docstrings:** Usar docstrings em português para classes e métodos públicos, seguindo o formato do projeto.
- **Exceções:** Cada serviço deve definir sua própria exceção herdando de `ServiceError` (ex: `CustomerServiceError`, `EvolutionServiceError`).
- **Logging:** Sempre usar `get_logger(__name__)` do módulo `teajuda.core.infrastructure.logging`. O prefixo dos loggers é `tutto-mcp-server`.

---

## Estrutura de Diretórios

```
src/teajuda/core/
├── auth/
│   ├── jwt.py              # Criação/decodificação de tokens JWT
│   ├── middleware.py       # UnifiedAuthMiddleware (ASGI)
│   └── dependencies.py     # require_auth, require_customer_auth (FastAPI)
├── exceptions/
│   └── base.py             # ServiceError, NotFoundError, ValidationError, ConflictError
├── infrastructure/
│   ├── settings.py         # Configurações via pydantic-settings (.env)
│   ├── mongo.py            # MongoDBManager, connect_to_mongo, get_database
│   ├── logging.py          # setup_logging, get_logger
│   └── lifespan.py         # shared_lifespan para FastAPI/MCP
├── models/
│   ├── pyobjectid.py       # Tipo customizado PyObjectId para Pydantic v2
│   └── <entidade>.py       # Schemas Create, Update, Out para cada entidade
├── repositories/
│   ├── base.py             # BaseRepository (CRUD genérico MongoDB)
│   └── <entidade>_repository.py
├── services/
│   └── <entidade>_service.py
└── utils/
    └── helpers.py          # Placeholder para funções utilitárias
```

---

## Padrões de Implementação

### Repositórios

- `BaseRepository` fornece `create`, `get_by_id`, `update`, `delete`.
- Converte automaticamente `_id` (ObjectId) → `id` (str) via `_map_doc`.
- Adiciona `created_at` e `updated_at` automaticamente em `create`.
- Repositórios específicos estendem `BaseRepository` e recebem `AsyncIOMotorDatabase`.

### Serviços

- Cada serviço recebe seu repositório no `__init__` (injeção manual).
- Serviços que chamam APIs externas usam `httpx.AsyncClient`.
- Erros de serviço levantam exceções customizadas herdando de `ServiceError`.

### Autenticação

- **JWT:** Tokens de acesso (`access`) e refresh (`refresh`) com expiração configurável via `.env`.
- **Middleware:** `UnifiedAuthMiddleware` protege rotas via header `Authorization: Bearer <token>`. Ignora por padrão `/healthz`, `/openapi.json`, `/docs`, `/redoc` e prefixos `/auth`.
- **Tipos de token:**
  - `customer` — autentica um Customer no MongoDB e retorna seus dados.
  - `service` — retorna o payload JWT como identidade de serviço.
- **Dependências FastAPI:**
  - `require_auth` — extrai identidade do `request.state.user` (populado pelo middleware).
  - `require_customer_auth` — garante que a identidade não seja um token de serviço.

### Modelos Pydantic

- Padrão de nomenclatura: `<Entidade>Create`, `<Entidade>Update`, `<Entidade>Out`.
- `PyObjectId` é usado como tipo para campos `id` nos modelos de saída, com serialização para string.
- `ConfigDict(from_attributes=True, populate_by_name=True)` nos modelos `Out`.

---

## Configurações e Variáveis de Ambiente

O arquivo `.env` é carregado automaticamente por `pydantic-settings`. Veja `.env.example` para referência.

| Variável | Descrição | Padrão |
|----------|-----------|--------|
| `MONGODB_URL` | URI de conexão com MongoDB | obrigatória |
| `MONGODB_DATABASE_NAME` | Nome do banco | `tuttoDb` |
| `JWT_SECRET_KEY` | Chave secreta para JWT | obrigatória |
| `JWT_ALGORITHM` | Algoritmo JWT | `HS256` |
| `ACCESS_TOKEN_EXPIRE_MINUTES` | Expiração do access token | `30` |
| `REFRESH_TOKEN_EXPIRE_MINUTES` | Expiração do refresh token | `120` |
| `MERCADO_PAGO_ACCESS_TOKEN` | Token do Mercado Pago | `""` |
| `MERCADO_PAGO_BACK_URL_BASE` | URL base para callbacks de pagamento | `https://tutto.example.com` |
| `EVOLUTION_API_URL` | URL da Evolution API | `http://127.0.0.1:8080` |
| `EVOLUTION_API_KEY` | API key da Evolution | `""` |
| `GOOGLE_CLIENT_ID` / `GOOGLE_CLIENT_SECRET` / `GOOGLE_REDIRECT_URI` | OAuth 2.0 Google | `""` |
| `SERVER_PORT` | Porta (alias para `PORT`) | `8000` |
| `LOG_LEVEL` | Nível de log | `INFO` |

---

## Testes

- Localizados em `tests/`.
- Estratégia: testes unitários com mocks. Não há testes de integração com MongoDB real.
- Arquivos:
  - `test_imports.py` — valida que os módulos principais importam corretamente.
  - `test_auth.py` — testa criação e decodificação de tokens JWT.
  - `test_models.py` — valida construção e defaults de modelos Pydantic.
  - `test_repositories.py` — testa `BaseRepository` com mocks do Motor.

Para adicionar novos testes, seguir o padrão de nomenclatura `test_*.py` e usar `pytest.mark.asyncio` para funções async.

---

## Segurança

- **Nunca commite o arquivo `.env`** — ele contém segredos (`JWT_SECRET_KEY`, tokens de API).
- O middleware de autenticação deve ser aplicado em todas as aplicações que consumirem este pacote.
- Tokens JWT usam `HS256` e dependem de `JWT_SECRET_KEY` forte e única por ambiente.
- Callbacks do Mercado Pago usam um `callback_token` gerado via `secrets.token_urlsafe(32)` para validar a origem.
- Senhas e secrets de identidades de API são armazenados no MongoDB (ver `SecurityIdentityRepository`).

---

## Notas para Agentes de Código

- Ao criar novas entidades, siga o padrão: modelos (`Create`/`Update`/`Out`) → repositório → serviço.
- Mantenha a consistência linguística: **português** em todo o código produzido.
- Ao modificar serviços que interagem com APIs externas (Mercado Pago, Evolution, Google), mantenha o tratamento de exceções com `ServiceError` e logging apropriado.
- O pacote é importado como `teajuda.core` — não altere a estrutura de pacotes sem atualizar `pyproject.toml` (`[tool.hatch.build.targets.wheel]`).
- Este projeto não possui servidor HTTP próprio — ele fornece `shared_lifespan` e utilitários para serem usados em aplicações FastAPI/MCP externas.
