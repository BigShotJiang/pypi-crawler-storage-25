"""Testes unitários para modelos Pydantic."""

import pytest
from teajuda.core.models.tenant import TenantCreate, TenantUpdate
from teajuda.core.models.customer import CustomerCreate, CustomerEmail, CustomerPhone
from teajuda.core.models.schedule import ScheduleCreate



def test_tenant_create_defaults():
    """Deve criar um TenantCreate com valores padrão."""
    tenant = TenantCreate(customer_id="cust_123", phone="5511999999999", name="Barbearia X")
    assert tenant.customer_id == "cust_123"
    assert tenant.phone == "5511999999999"
    assert tenant.name == "Barbearia X"
    assert tenant.state == "stopped"
    assert tenant.type == "customer"
    assert tenant.token is None


def test_tenant_update_partial():
    """Deve permitir atualização parcial de tenant."""
    update = TenantUpdate(name="Novo Nome")
    assert update.name == "Novo Nome"
    assert update.phone is None


def test_customer_create():
    """Deve criar um CustomerCreate válido."""
    customer = CustomerCreate(
        tenants=["tenant_123"],
        name="João Silva",
        emails=[CustomerEmail(value="joao@example.com", type="personal", is_main=True)],
        phones=[CustomerPhone(value="5511988887777", type="mobile", is_main=True)],
    )
    assert customer.name == "João Silva"
    assert customer.phones[0].value == "5511988887777"
    assert customer.emails[0].value == "joao@example.com"


from datetime import datetime

def test_schedule_create():
    """Deve criar um ScheduleCreate válido."""
    scheduled = datetime(2025, 1, 1, 10, 0, 0)
    schedule = ScheduleCreate(
        tenant_id="tenant_123",
        user_id="user_456",
        instruction_id="instr_789",
        scheduled_at=scheduled,
    )
    assert schedule.tenant_id == "tenant_123"
    assert schedule.user_id == "user_456"
    assert schedule.instruction_id == "instr_789"
    assert schedule.scheduled_at == scheduled
