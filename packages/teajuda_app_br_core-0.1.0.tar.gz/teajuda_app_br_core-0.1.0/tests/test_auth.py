"""Testes unitários para autenticação JWT."""

import pytest
from teajuda.core.auth.jwt import create_access_token, create_refresh_token, decode_token



def test_create_and_decode_access_token():
    """Deve criar e decodificar um token de acesso corretamente."""
    payload = {"sub": "user-123", "type": "service"}
    token = create_access_token(payload)
    assert isinstance(token, str)

    decoded = decode_token(token)
    assert decoded["sub"] == "user-123"
    assert decoded["type"] == "service"
    assert decoded["token_type"] == "access"
    assert "exp" in decoded


def test_create_and_decode_refresh_token():
    """Deve criar e decodificar um refresh token corretamente."""
    payload = {"sub": "user-456", "type": "customer"}
    token = create_refresh_token(payload)
    assert isinstance(token, str)

    decoded = decode_token(token)
    assert decoded["sub"] == "user-456"
    assert decoded["type"] == "customer"
    assert decoded["token_type"] == "refresh"
    assert "exp" in decoded
