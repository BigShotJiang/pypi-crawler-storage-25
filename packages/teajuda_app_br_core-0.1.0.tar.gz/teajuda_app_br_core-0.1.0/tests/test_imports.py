"""Testes básicos de importação do teajuda-core."""



def test_import_settings():
    """Deve importar as configurações sem erros."""
    from teajuda.core.infrastructure.settings import settings

    assert settings is not None
    assert settings.PROJECT_NAME == "Tutto MCP Server"


def test_import_base_repository():
    """Deve importar o BaseRepository."""
    from teajuda.core.repositories.base import BaseRepository

    assert BaseRepository is not None


def test_import_jwt_utils():
    """Deve importar utilitários JWT."""
    from teajuda.core.auth.jwt import create_access_token, decode_token

    assert callable(create_access_token)
    assert callable(decode_token)


def test_import_middleware():
    """Deve importar o middleware de autenticação."""
    from teajuda.core.auth.middleware import UnifiedAuthMiddleware

    assert UnifiedAuthMiddleware is not None


def test_import_models():
    """Deve importar modelos principais."""
    from teajuda.core.models.tenant import TenantCreate
    from teajuda.core.models.customer import CustomerCreate
    from teajuda.core.models.schedule import ScheduleCreate

    assert TenantCreate is not None
    assert CustomerCreate is not None
    assert ScheduleCreate is not None


def test_import_rabbitmq_manager():
    """Deve importar o RabbitMQManager."""
    from teajuda.core.infrastructure.rabbitmq import RabbitMQManager

    assert RabbitMQManager is not None


def test_import_event_publisher_service():
    """Deve importar o EventPublisherService."""
    from teajuda.core.services.event_publisher_service import EventPublisherService

    assert EventPublisherService is not None


def test_import_event_consumer_service():
    """Deve importar o EventConsumerService."""
    from teajuda.core.services.event_consumer_service import EventConsumerService

    assert EventConsumerService is not None
