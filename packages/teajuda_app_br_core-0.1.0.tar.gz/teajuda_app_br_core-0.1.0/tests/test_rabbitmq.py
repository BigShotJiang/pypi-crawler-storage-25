"""Testes unitários para RabbitMQManager, EventPublisherService e EventConsumerService."""

import json
from datetime import datetime, timezone
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

pytestmark = pytest.mark.asyncio

from teajuda.core.infrastructure.rabbitmq import RabbitMQManager
from teajuda.core.services.event_consumer_service import EventConsumerService
from teajuda.core.services.event_publisher_service import EventPublisherService


@pytest.fixture
def mock_channel():
    """Mock de um canal aio_pika."""
    channel = AsyncMock()
    channel.declare_exchange = AsyncMock(return_value=AsyncMock())
    channel.declare_queue = AsyncMock(return_value=AsyncMock())
    return channel


@pytest.fixture
def mock_connection(mock_channel):
    """Mock de uma conexão aio_pika que retorna o canal mockado."""
    conn = AsyncMock()
    conn.channel = AsyncMock(return_value=mock_channel)
    conn.is_closed = False
    return conn


class TestRabbitMQManager:
    async def test_connect_declares_topology(self, mock_connection, mock_channel):
        with patch("aio_pika.connect_robust", return_value=mock_connection):
            manager = RabbitMQManager("amqp://test")
            await manager.connect()

        mock_connection.channel.assert_awaited_once()
        assert mock_channel.declare_exchange.await_count == 2
        assert mock_channel.declare_queue.await_count == 2

        # Verifica argumentos da fila principal (DLX)
        main_queue_call = mock_channel.declare_queue.await_args_list[0]
        assert main_queue_call.kwargs["arguments"]["x-dead-letter-exchange"] == "evolution.dlx"

    async def test_close_connection(self, mock_connection):
        with patch("aio_pika.connect_robust", return_value=mock_connection):
            manager = RabbitMQManager("amqp://test")
            await manager.connect()
            await manager.close()

        mock_connection.close.assert_awaited_once()


class TestEventPublisherService:
    async def test_publish_instance_event(self):
        exchange_mock = AsyncMock()
        manager = MagicMock()
        manager.exchange = exchange_mock

        publisher = EventPublisherService(manager)
        await publisher.publish_instance_event("tenant-1", "5511999999999", "cust-1")

        exchange_mock.publish.assert_awaited_once()
        message = exchange_mock.publish.await_args[0][0]
        payload = json.loads(message.body.decode("utf-8"))

        assert payload["type"] == "instance_created"
        assert payload["tenant_id"] == "tenant-1"
        assert payload["payload"]["phone"] == "5511999999999"
        assert message.delivery_mode == 2  # PERSISTENT

    async def test_publish_message_event(self):
        exchange_mock = AsyncMock()
        manager = MagicMock()
        manager.exchange = exchange_mock

        publisher = EventPublisherService(manager)
        await publisher.publish_message_event("tenant-1", "cust-1", {"text": "Oi"})

        exchange_mock.publish.assert_awaited_once()
        payload = json.loads(exchange_mock.publish.await_args[0][0].body.decode("utf-8"))

        assert payload["type"] == "message"
        assert payload["payload"]["text"] == "Oi"


class TestEventConsumerService:
    async def test_consume_and_process_success(self):
        queue_mock = AsyncMock()
        manager = MagicMock()
        manager.queue = queue_mock

        # Simula uma mensagem válida
        msg_mock = AsyncMock()
        msg_mock.headers = {}
        msg_mock.body = json.dumps({
            "type": "message",
            "tenant_id": "t1",
            "customer_id": "c1",
            "payload": {"text": "Oi", "phone": "5511999999999"},
        }).encode("utf-8")
        queue_mock.get = AsyncMock(side_effect=[msg_mock, Exception("empty")])

        evolution_mock = AsyncMock()
        tenant_repo = AsyncMock()
        tenant_repo.get_by_id = AsyncMock(return_value={"id": "t1", "name": "inst-1"})
        customer_repo = AsyncMock()
        customer_repo.get_by_id = AsyncMock(return_value={
            "id": "c1",
            "phones": [{"value": "5511999999999"}],
        })

        consumer = EventConsumerService(manager, evolution_mock, tenant_repo, customer_repo)
        result = await consumer.consume_and_process(limit=10)

        assert result["processed"] == 1
        assert result["failed"] == 0
        msg_mock.ack.assert_awaited_once()
        evolution_mock.send_text.assert_awaited_once_with(
            instance_name="inst-1",
            number="5511999999999",
            text="Oi",
            delay=1200,
        )

    async def test_consume_and_process_tenant_not_found_acks(self):
        """Se tenant não existe, deve dar ack para não ir para DLQ."""
        queue_mock = AsyncMock()
        manager = MagicMock()
        manager.queue = queue_mock

        msg_mock = AsyncMock()
        msg_mock.headers = {}
        msg_mock.body = json.dumps({
            "type": "message",
            "tenant_id": "t1",
            "customer_id": "c1",
            "payload": {},
        }).encode("utf-8")
        queue_mock.get = AsyncMock(side_effect=[msg_mock, Exception("empty")])

        tenant_repo = AsyncMock()
        tenant_repo.get_by_id = AsyncMock(return_value=None)

        consumer = EventConsumerService(manager, AsyncMock(), tenant_repo, AsyncMock())
        result = await consumer.consume_and_process(limit=10)

        assert result["processed"] == 1  # ack conta como processado
        msg_mock.ack.assert_awaited_once()

    async def test_consume_and_process_retry_then_dlq(self):
        """Falha 1x: republica com retry. Falha 2x: nack para DLQ."""
        queue_mock = AsyncMock()
        manager = MagicMock()
        manager.exchange = AsyncMock()
        manager.queue = queue_mock

        # Primeira mensagem falha (retry=0)
        msg1 = AsyncMock()
        msg1.headers = {"x-retry-count": 0}
        msg1.body = json.dumps({
            "type": "message",
            "tenant_id": "t1",
            "customer_id": "c1",
            "payload": {"text": "Oi", "phone": "5511999999999"},
        }).encode("utf-8")

        # Segunda mensagem é a republicada (retry=1)
        msg2 = AsyncMock()
        msg2.headers = {"x-retry-count": 1}
        msg2.body = msg1.body

        queue_mock.get = AsyncMock(side_effect=[msg1, msg2, Exception("empty")])

        tenant_repo = AsyncMock()
        tenant_repo.get_by_id = AsyncMock(return_value={"id": "t1", "name": "inst-1"})

        evolution_mock = AsyncMock()
        # Simula falha no send_text
        evolution_mock.send_text = AsyncMock(side_effect=Exception("Evolution error"))

        consumer = EventConsumerService(manager, evolution_mock, tenant_repo, AsyncMock())
        result = await consumer.consume_and_process(limit=10)

        assert result["processed"] == 0
        assert result["failed"] == 2

        # Primeira mensagem: republicada + ack
        msg1.ack.assert_awaited_once()
        manager.exchange.publish.assert_awaited_once()
        republished = manager.exchange.publish.await_args[0][0]
        assert republished.headers["x-retry-count"] == 1

        # Segunda mensagem: nack para DLQ
        msg2.nack.assert_awaited_once_with(requeue=False)
