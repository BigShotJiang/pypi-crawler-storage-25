"""Testes unitários para BaseRepository (sem MongoDB)."""

import pytest
from unittest.mock import AsyncMock, MagicMock
from bson import ObjectId
from teajuda.core.repositories.base import BaseRepository



def test_map_doc_converts_id():
    """Deve converter _id em id como string."""
    mock_db = MagicMock()
    repo = BaseRepository(mock_db, "test_collection")

    doc = {"_id": ObjectId("507f1f77bcf86cd799439011"), "name": "Teste"}
    mapped = repo._map_doc(doc)

    assert mapped["id"] == "507f1f77bcf86cd799439011"
    assert "_id" not in mapped
    assert mapped["name"] == "Teste"


def test_map_doc_none():
    """Deve retornar None para documento inexistente."""
    mock_db = MagicMock()
    repo = BaseRepository(mock_db, "test_collection")
    assert repo._map_doc(None) is None


@pytest.mark.asyncio
async def test_create_document():
    """Deve inserir documento e retornar mapeado."""
    mock_db = MagicMock()
    mock_collection = AsyncMock()
    mock_db.__getitem__ = MagicMock(return_value=mock_collection)

    repo = BaseRepository(mock_db, "test_collection")
    repo.collection = mock_collection

    inserted_id = ObjectId("507f1f77bcf86cd799439011")
    mock_collection.insert_one.return_value = MagicMock(inserted_id=inserted_id)
    from datetime import datetime, timezone
    now = datetime.now(timezone.utc)
    mock_collection.find_one.return_value = {
        "_id": inserted_id,
        "name": "Novo",
        "created_at": now,
        "updated_at": now,
    }

    result = await repo.create({"name": "Novo"})

    assert result["id"] == str(inserted_id)
    assert result["name"] == "Novo"
    assert "created_at" in result
    assert "updated_at" in result


@pytest.mark.asyncio
async def test_get_by_id_valid():
    """Deve buscar documento por ID válido."""
    mock_collection = AsyncMock()
    obj_id = ObjectId("507f1f77bcf86cd799439011")
    mock_collection.find_one.return_value = {"_id": obj_id, "name": "Teste"}

    mock_db = MagicMock()
    repo = BaseRepository(mock_db, "test_collection")
    repo.collection = mock_collection

    result = await repo.get_by_id(str(obj_id))
    assert result["id"] == str(obj_id)


@pytest.mark.asyncio
async def test_get_by_id_invalid():
    """Deve retornar None para ID inválido."""
    mock_db = MagicMock()
    repo = BaseRepository(mock_db, "test_collection")

    result = await repo.get_by_id("id-invalido")
    assert result is None


@pytest.mark.asyncio
async def test_delete_document():
    """Deve deletar documento e retornar True."""
    mock_collection = AsyncMock()
    mock_collection.delete_one.return_value = MagicMock(deleted_count=1)

    mock_db = MagicMock()
    repo = BaseRepository(mock_db, "test_collection")
    repo.collection = mock_collection

    obj_id = ObjectId("507f1f77bcf86cd799439011")
    result = await repo.delete(str(obj_id))
    assert result is True
