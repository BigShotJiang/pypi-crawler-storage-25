"""Middleware ASGI unificado para proteger API e MCP com Bearer JWT."""

from typing import Awaitable, Callable, List, Optional

import jwt
from starlette.responses import JSONResponse

from teajuda.core.auth.jwt import authenticate_token
from teajuda.core.infrastructure.logging import get_logger

logger = get_logger(__name__)

ASGIApp = Callable[[dict, Callable, Callable], Awaitable[None]]


class UnifiedAuthMiddleware:
    """Middleware ASGI que exige Bearer JWT para rotas protegidas."""

    def __init__(
        self,
        app: ASGIApp,
        exempt_paths: Optional[List[str]] = None,
        exempt_prefixes: Optional[List[str]] = None,
    ):
        self.app = app
        self.exempt_paths = exempt_paths or ["/healthz", "/openapi.json", "/docs", "/redoc"]
        self.exempt_prefixes = exempt_prefixes or ["/auth"]

    async def __call__(self, scope: dict, receive: Callable, send: Callable) -> None:
        if scope["type"] != "http":
            await self.app(scope, receive, send)
            return

        path = scope.get("path", "")

        if path in self.exempt_paths:
            await self.app(scope, receive, send)
            return

        for prefix in self.exempt_prefixes:
            if path.startswith(prefix):
                await self.app(scope, receive, send)
                return

        headers = dict(scope.get("headers", []))
        auth_header = ""
        for k, v in headers.items():
            if k == b"authorization":
                auth_header = v.decode("latin-1")
                break

        if auth_header.startswith("Bearer "):
            token = auth_header[7:]
            try:
                identity = await authenticate_token(token)
                if "state" not in scope:
                    scope["state"] = {}
                scope["state"]["user"] = identity
                await self.app(scope, receive, send)
                return
            except jwt.ExpiredSignatureError:
                logger.warning(f"Authentication failed for {path}: Token expired")
                await self._send_401(scope, receive, send, detail="Token expired")
                return
            except jwt.PyJWTError:
                logger.warning(f"Authentication failed for {path}: Invalid token")
                await self._send_401(scope, receive, send, detail="Invalid token")
                return
            except ValueError as exc:
                logger.warning(f"Authentication failed for {path}: {exc}")
                await self._send_401(scope, receive, send, detail=str(exc))
                return
            except Exception as exc:
                logger.error(f"Authentication unexpected error for {path}: {exc}")
                await self._send_401(scope, receive, send)
                return

        await self._send_401(scope, receive, send)

    async def _send_401(
        self,
        scope: dict,
        receive: Callable,
        send: Callable,
        detail: str = "Authentication required",
        auth_scheme: str = "Bearer",
    ) -> None:
        response = JSONResponse(
            {"detail": detail},
            status_code=401,
            headers={"WWW-Authenticate": auth_scheme},
        )
        await response(scope, receive, send)
