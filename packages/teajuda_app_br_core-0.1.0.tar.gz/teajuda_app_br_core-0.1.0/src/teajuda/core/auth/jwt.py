"""Utilitários JWT puros (sem dependência de FastAPI)."""

from datetime import datetime, timedelta, timezone
from typing import Optional

import jwt

from teajuda.core.infrastructure.logging import get_logger
from teajuda.core.infrastructure.mongo import get_database
from teajuda.core.infrastructure.settings import settings
from teajuda.core.repositories.customer_repository import CustomerRepository

logger = get_logger(__name__)


def create_access_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.ACCESS_TOKEN_EXPIRE_MINUTES
        )
    to_encode.update({"exp": expire, "token_type": "access"})
    encoded_jwt = jwt.encode(to_encode, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)
    return encoded_jwt


def create_refresh_token(data: dict, expires_delta: Optional[timedelta] = None) -> str:
    to_encode = data.copy()
    if expires_delta:
        expire = datetime.now(timezone.utc) + expires_delta
    else:
        expire = datetime.now(timezone.utc) + timedelta(
            minutes=settings.REFRESH_TOKEN_EXPIRE_MINUTES
        )
    to_encode.update({"exp": expire, "token_type": "refresh"})
    encoded_jwt = jwt.encode(to_encode, settings.JWT_SECRET_KEY, algorithm=settings.JWT_ALGORITHM)
    return encoded_jwt


def decode_token(token: str) -> dict:
    return jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])


async def authenticate_token(token: str) -> dict:
    """Valida um token JWT e retorna a identidade (customer ou payload de service)."""
    payload = jwt.decode(token, settings.JWT_SECRET_KEY, algorithms=[settings.JWT_ALGORITHM])

    subject: Optional[str] = payload.get("sub")
    token_type: Optional[str] = payload.get("type")
    if not subject or not token_type:
        raise ValueError("Invalid token payload")

    if token_type == "customer":
        db = get_database()
        repo = CustomerRepository(db)
        customer = await repo.get_by_id(subject)
        if not customer:
            raise ValueError("Customer not found")
        return customer

    # token_type == "service" (ou outro tipo de serviço)
    return payload
