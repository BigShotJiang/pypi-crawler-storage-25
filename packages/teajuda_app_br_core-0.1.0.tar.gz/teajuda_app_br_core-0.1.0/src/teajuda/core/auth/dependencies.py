"""Dependências FastAPI para autenticação."""

from fastapi import Depends, HTTPException, Request, status
from fastapi.security import OAuth2PasswordBearer

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="auth/login", auto_error=False)


async def require_auth(request: Request) -> dict:
    """Dependency que retorna a identidade autenticada pelo middleware global.

    Raises:
        HTTPException: 401 se a identidade não estiver no estado da requisição.
    """
    user = getattr(request.state, "user", None)
    if user:
        return user  # type: ignore[no-any-return]

    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED,
        detail="Authentication required",
        headers={"WWW-Authenticate": "Bearer"},
    )


async def require_customer_auth(
    identity: dict = Depends(require_auth),  # noqa: B008
) -> dict:
    """Wrapper que garante que a identidade autenticada é um customer."""
    if isinstance(identity, dict) and identity.get("type") == "service":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Customer access required",
        )
    return identity
