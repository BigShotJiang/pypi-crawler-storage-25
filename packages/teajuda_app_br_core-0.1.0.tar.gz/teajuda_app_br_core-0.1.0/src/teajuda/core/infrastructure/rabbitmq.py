"""Gerenciador de conexão e topologia RabbitMQ."""

import aio_pika
from aio_pika import DeliveryMode, ExchangeType, Message

from teajuda.core.infrastructure.logging import get_logger

logger = get_logger(__name__)


class RabbitMQManager:
    """Singleton de conexão RabbitMQ. Declara topologia completa no startup."""

    def __init__(self, amqp_url: str):
        self.amqp_url = amqp_url
        self.connection = None
        self.channel = None
        self.exchange = None
        self.queue = None
        self.dlx_exchange = None
        self.dlq = None

    async def connect(self) -> None:
        """Conecta ao RabbitMQ e declara a topologia."""
        logger.info("Conectando ao RabbitMQ...")
        self.connection = await aio_pika.connect_robust(self.amqp_url)
        self.channel = await self.connection.channel()
        await self._declare_topology()
        logger.info("RabbitMQ conectado e topologia declarada.")

    async def _declare_topology(self) -> None:
        """Declara exchange, filas e bindings idempotentemente."""
        # Exchange principal
        self.exchange = await self.channel.declare_exchange(
            "evolution", ExchangeType.TOPIC, durable=True
        )

        # Fila principal com DLX
        self.queue = await self.channel.declare_queue(
            "teajuda.events",
            durable=True,
            arguments={
                "x-dead-letter-exchange": "evolution.dlx",
                "x-dead-letter-routing-key": "teajuda.events.dlq",
            },
        )
        await self.queue.bind(self.exchange, routing_key="teajuda.events")

        # DLX + DLQ
        self.dlx_exchange = await self.channel.declare_exchange(
            "evolution.dlx", ExchangeType.TOPIC, durable=True
        )
        self.dlq = await self.channel.declare_queue(
            "teajuda.events.dlq", durable=True
        )
        await self.dlq.bind(self.dlx_exchange, routing_key="teajuda.events.dlq")

    async def close(self) -> None:
        """Fecha a conexão com o RabbitMQ."""
        if self.connection and not self.connection.is_closed:
            await self.connection.close()
            logger.info("Conexão com RabbitMQ fechada.")
