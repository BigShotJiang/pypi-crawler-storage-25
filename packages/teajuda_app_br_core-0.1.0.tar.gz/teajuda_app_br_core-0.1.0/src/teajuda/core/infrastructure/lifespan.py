"""Shared lifespan para FastAPI e MCP."""

from contextlib import asynccontextmanager
from typing import AsyncGenerator

from teajuda.core.infrastructure.logging import get_logger
from teajuda.core.infrastructure.mongo import close_mongo_connection, connect_to_mongo
from teajuda.core.infrastructure.rabbitmq import RabbitMQManager
from teajuda.core.infrastructure.settings import settings

logger = get_logger(__name__)

# Instância global do gerenciador RabbitMQ
rabbitmq_manager = RabbitMQManager(settings.RABBITMQ_URL)


@asynccontextmanager
async def shared_lifespan(app) -> AsyncGenerator[None, None]:
    """Gerencia o ciclo de vida compartilhado da aplicação."""
    logger.info("Lifespan starting...")
    await connect_to_mongo()
    await rabbitmq_manager.connect()
    logger.info("Lifespan started.")
    yield
    logger.info("Lifespan shutting down...")
    await rabbitmq_manager.close()
    await close_mongo_connection()
    logger.info("Lifespan shut down.")
