import secrets
import string
from typing import Optional

from teajuda.core.exceptions.base import ServiceError
from teajuda.core.models.tenant import TenantCreate, TenantUpdate
from teajuda.core.repositories.tenant_repository import TenantRepository


class TenantServiceError(ServiceError):
    pass


class TenantService:
    def __init__(self, repository: TenantRepository):
        self.repository = repository

    def _generate_token(self, length: int = 32) -> str:
        """Generate a random token with uppercase, lowercase letters and numbers."""
        alphabet = string.ascii_letters + string.digits
        return "".join(secrets.choice(alphabet) for _ in range(length))

    async def create_tenant(self, tenant: TenantCreate) -> dict:
        if tenant.customer_id:
            existing_doc = await self.repository.get_by_customer_id(tenant.customer_id)
            if existing_doc:
                raise TenantServiceError("Tenant with this customer_id already exists")

        existing_phone = await self.repository.get_by_phone(tenant.phone)
        if existing_phone:
            raise TenantServiceError("Tenant with this phone already exists")

        if not tenant.token:
            tenant.token = self._generate_token()

        created_tenant = await self.repository.create(tenant)
        return created_tenant

    async def update_tenant(self, tenant_id: str, update: TenantUpdate) -> dict:
        update_data = update.model_dump(exclude_unset=True)
        if not update_data:
            raise TenantServiceError("No data provided for update")

        existing = await self.repository.get_by_id(tenant_id)
        if not existing:
            raise TenantServiceError("Tenant not found")

        if update.customer_id:
            other = await self.repository.get_by_customer_id(update.customer_id)
            if other and str(other.get("id")) != tenant_id:
                raise TenantServiceError("Another tenant with this customer_id already exists")

        updated = await self.repository.update(tenant_id, update_data)
        if updated is None:
            raise TenantServiceError("Failed to update tenant")
        return updated

    async def get_tenant(self, identifier: str, by: str = "id") -> Optional[dict]:
        if by == "id":
            tenant = await self.repository.get_by_id(identifier)
        elif by == "phone":
            tenant = await self.repository.get_by_phone(identifier)
        elif by == "token":
            tenant = await self.repository.get_by_token(identifier)
        elif by == "customer_id":
            tenant = await self.repository.get_by_customer_id(identifier)
        else:
            raise TenantServiceError("Invalid 'by' parameter. Use id, phone, token, or customer_id.")

        if not tenant:
            raise TenantServiceError("Tenant not found")

        return tenant
