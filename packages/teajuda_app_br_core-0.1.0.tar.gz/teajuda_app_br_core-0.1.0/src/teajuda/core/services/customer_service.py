"""Business logic for customer auth and management."""

from datetime import datetime, timezone

from teajuda.core.exceptions.base import ServiceError
from typing import Any, Dict, List, Optional

from teajuda.core.repositories.customer_repository import CustomerRepository


class CustomerServiceError(ServiceError):
    """Exceção customizada para erros no domínio de Customer."""

    pass


class CustomerService:
    def __init__(self, repository: CustomerRepository):
        self.repository = repository

    def _normalize_contact_lists(self, data: dict) -> dict:
        """Garante que haja pelo menos um item principal em phones e emails."""
        phones = data.get("phones", [])
        emails = data.get("emails", [])

        if phones and not any(p.get("is_main") for p in phones):
            phones[0]["is_main"] = True
        if emails and not any(e.get("is_main") for e in emails):
            emails[0]["is_main"] = True

        data["phones"] = phones
        data["emails"] = emails
        return data

    async def register(self, data: dict) -> dict:
        tenants = data.get("tenants", [])
        emails = data.get("emails", [])
        phones = data.get("phones", [])

        if not tenants:
            raise CustomerServiceError("At least one tenant is required")
        if not emails:
            raise CustomerServiceError("At least one email is required")
        if not phones:
            raise CustomerServiceError("At least one phone is required")

        data = self._normalize_contact_lists(data)

        # Valida unicidade de email e phone entre todos os customers
        for email_obj in data["emails"]:
            existing_email = await self.repository.get_by_email(
                email_obj["value"].lower().strip()
            )
            if existing_email:
                raise CustomerServiceError(
                    f"Customer with email {email_obj['value']} already exists"
                )

        for phone_obj in data["phones"]:
            existing_phone = await self.repository.get_by_phone(phone_obj["value"])
            if existing_phone:
                raise CustomerServiceError(
                    f"Customer with phone {phone_obj['value']} already exists"
                )

        customer_data = {
            "tenants": tenants,
            "name": data.get("name"),
            "emails": data["emails"],
            "phones": data["phones"],
            "google_id": data.get("google_id"),
            "is_active": True,
            "created_at": datetime.now(timezone.utc),
            "updated_at": datetime.now(timezone.utc),
        }

        return await self.repository.create(customer_data)

    async def authenticate_or_create_google(
        self,
        email: str,
        name: str,
        google_id: str,
        tenant_id: Optional[str] = None,
    ) -> dict:
        """Autentica um customer via Google OAuth; cria se não existir.

        Args:
            email: Email do Google.
            name: Nome do Google.
            google_id: Identificador único do Google (sub).
            tenant_id: Tenant ao qual vincular em caso de criação.

        Returns:
            Documento do customer.

        Raises:
            CustomerServiceError: Se não encontrar e tenant_id não for fornecido.
        """
        customer = await self.repository.get_by_google_id(google_id)
        if customer:
            return customer

        customer = await self.repository.get_by_email(email.lower().strip())
        if customer:
            # Vincula google_id se ainda não tiver
            if not customer.get("google_id"):
                await self.repository.update(customer["id"], {"google_id": google_id})
                customer["google_id"] = google_id
            return customer

        if not tenant_id:
            raise CustomerServiceError(
                "Customer not found and tenant_id is required for signup"
            )

        return await self.register(
            {
                "tenants": [tenant_id],
                "name": name,
                "emails": [{"value": email.lower().strip(), "type": "personal", "is_main": True}],
                "phones": [],
                "google_id": google_id,
            }
        )

    async def get_customer(self, customer_id: str) -> dict:
        customer = await self.repository.get_by_id(customer_id)
        if not customer:
            raise CustomerServiceError("Customer not found")
        return customer

    async def get_profile(self, customer_id: str) -> dict:
        return await self.get_customer(customer_id)

    async def update_customer(self, customer_id: str, data: dict) -> dict:
        customer = await self.repository.get_by_id(customer_id)
        if not customer:
            raise CustomerServiceError("Customer not found")

        update_data: Dict[str, Any] = {}

        if "tenants" in data and data["tenants"] is not None:
            update_data["tenants"] = data["tenants"]
        if "name" in data and data["name"] is not None:
            update_data["name"] = data["name"]
        if "google_id" in data and data["google_id"] is not None:
            update_data["google_id"] = data["google_id"]
        if "is_active" in data and data["is_active"] is not None:
            update_data["is_active"] = data["is_active"]

        if "emails" in data and data["emails"] is not None:
            update_data["emails"] = data["emails"]
            if not any(e.get("is_main") for e in update_data["emails"]):
                update_data["emails"][0]["is_main"] = True

        if "phones" in data and data["phones"] is not None:
            update_data["phones"] = data["phones"]
            if not any(p.get("is_main") for p in update_data["phones"]):
                update_data["phones"][0]["is_main"] = True

        if not update_data:
            raise CustomerServiceError("No fields to update")

        updated = await self.repository.update(customer_id, update_data)
        if not updated:
            raise CustomerServiceError("Failed to update customer")
        return updated

    async def list_customers_by_tenant(self, tenant_id: str) -> List[dict]:
        return await self.repository.find_by_tenant(tenant_id)

    async def add_tenant_to_customer(self, customer_id: str, tenant_id: str) -> dict:
        customer = await self.repository.get_by_id(customer_id)
        if not customer:
            raise CustomerServiceError("Customer not found")

        tenants = customer.get("tenants", [])
        if tenant_id in tenants:
            raise CustomerServiceError("Customer already linked to this tenant")

        tenants.append(tenant_id)
        updated = await self.repository.update(customer_id, {"tenants": tenants})
        if not updated:
            raise CustomerServiceError("Failed to add tenant to customer")
        return updated

    async def find_customer_by_email(self, email: str) -> Optional[dict]:
        return await self.repository.get_by_email(email.lower().strip())

    async def find_customer_by_phone(self, phone: str) -> Optional[dict]:
        return await self.repository.get_by_phone(phone)
