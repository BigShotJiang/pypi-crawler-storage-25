from datetime import datetime, timedelta, timezone
from typing import Optional

from teajuda.core.exceptions.base import ServiceError
from teajuda.core.infrastructure.logging import get_logger
from teajuda.core.models.subscription import SubscriptionCreate, SubscriptionUpdate
from teajuda.core.repositories.subscription_repository import SubscriptionRepository
from teajuda.core.repositories.tenant_repository import TenantRepository
from teajuda.core.services.coupon_service import CouponService, CouponServiceError
from teajuda.core.services.payment_service import PaymentService
from teajuda.core.services.plan_service import PlanService, PlanServiceError

logger = get_logger(__name__)


class SubscriptionServiceError(ServiceError):
    pass


class SubscriptionService:
    def __init__(
        self,
        repository: SubscriptionRepository,
        tenant_repository: TenantRepository,
        coupon_service: CouponService,
        plan_service: PlanService,
        payment_service: PaymentService,
    ):
        self.repository = repository
        self.tenant_repository = tenant_repository
        self.payment_service = payment_service
        self.coupon_service = coupon_service
        self.plan_service = plan_service

    async def create_subscription(self, subscription: SubscriptionCreate) -> dict:
        # Check if tenant has a complete profile
        tenant = await self.tenant_repository.get_by_id(subscription.tenant_id)
        if not tenant:
            raise SubscriptionServiceError(f"Tenant {subscription.tenant_id} not found")

        required_fields = ["customer_id", "phone", "name"]
        missing = [f for f in required_fields if not tenant.get(f)]
        if missing:
            raise SubscriptionServiceError(
                f"Tenant profile is incomplete. Mandatory fields missing: {', '.join(missing)}"
            )

        # We check for an active subscription to upgrade/update
        existing = await self.repository.get_by_tenant(subscription.tenant_id, is_active=True)

        # Validate plan
        try:
            plan_data = await self.plan_service.get_plan_by_id(subscription.plan_id)
            price = plan_data.get("price", 0.0)
            if not plan_data.get("is_active"):
                raise SubscriptionServiceError(
                    f"Plan {subscription.plan_id} is currently inactive"
                )
        except PlanServiceError as e:
            raise SubscriptionServiceError(f"Plan validation failed: {str(e)}")

        # Validate coupon if provided
        if subscription.coupon_id:
            try:
                await self.coupon_service.get_coupon(subscription.coupon_id)
            except CouponServiceError as e:
                raise SubscriptionServiceError(f"Coupon validation failed: {str(e)}")

        # Default expiration if not provided
        if not subscription.expires_in:
            subscription.expires_in = datetime.now(timezone.utc) + timedelta(days=30)

        if existing:
            # Upgrade existing subscription
            update_data = SubscriptionUpdate(
                plan_id=subscription.plan_id,
                coupon_id=subscription.coupon_id,
                expires_in=subscription.expires_in,
                state=subscription.state,
            )
            result = await self.repository.update_by_tenant(subscription.tenant_id, update_data)
            if not result:
                raise SubscriptionServiceError("Failed to update existing subscription")
        else:
            # Create new subscription
            result = await self.repository.create(subscription)
            if not result:
                raise SubscriptionServiceError("Failed to create subscription")

        # Generate payment link if applicable (price > 0 and state pending without payment_id)
        payment_link = None
        if price > 0 and subscription.state == "pending" and not subscription.payment_id:
            try:
                payment_link = await self.payment_service.create_payment_link(
                    result["id"], plan_data.get("name", "plan"), price
                )
            except Exception as e:
                logger.error(f"Failed to generate payment link: {str(e)}")
                payment_link = "Error generating link. Contact support."

        result["payment_link"] = payment_link
        return result

    async def get_subscription(self, tenant_id: str, is_active: Optional[bool] = True) -> dict:
        subscription = await self.repository.get_by_tenant(tenant_id, is_active=is_active)
        if not subscription:
            status_str = "active " if is_active else ""
            raise SubscriptionServiceError(
                f"No {status_str}subscription found for tenant {tenant_id}"
            )
        return subscription

    async def update_subscription(
        self, tenant_id: str, subscription_update: SubscriptionUpdate
    ) -> dict:
        existing = await self.repository.get_by_tenant(tenant_id, is_active=True)
        if not existing:
            raise SubscriptionServiceError(f"No active subscription found for tenant {tenant_id}")

        # If plan is being updated, validate it
        if subscription_update.plan_id:
            try:
                plan_data = await self.plan_service.get_plan_by_id(subscription_update.plan_id)
                if not plan_data.get("is_active"):
                    raise SubscriptionServiceError(
                        f"Plan {subscription_update.plan_id} is currently inactive"
                    )
            except PlanServiceError as e:
                raise SubscriptionServiceError(f"Plan validation failed: {str(e)}")

        # Validate coupon if provided
        if subscription_update.coupon_id:
            try:
                await self.coupon_service.get_coupon(subscription_update.coupon_id)
            except CouponServiceError as e:
                raise SubscriptionServiceError(f"Coupon validation failed: {str(e)}")

        updated = await self.repository.update_by_tenant(tenant_id, subscription_update)
        if not updated:
            raise SubscriptionServiceError("Failed to update subscription")
        return updated

    async def cancel_subscription(self, tenant_id: str, reason: Optional[str] = None) -> dict:
        existing = await self.repository.get_by_tenant(tenant_id, is_active=True)
        if not existing:
            raise SubscriptionServiceError(f"No active subscription found for tenant {tenant_id}")

        cancel_update = SubscriptionUpdate(
            is_active=False,
            canceled_at=datetime.now(timezone.utc),
        )
        updated = await self.repository.update_by_tenant(tenant_id, cancel_update)
        if not updated:
            raise SubscriptionServiceError("Failed to cancel subscription")
        return updated
