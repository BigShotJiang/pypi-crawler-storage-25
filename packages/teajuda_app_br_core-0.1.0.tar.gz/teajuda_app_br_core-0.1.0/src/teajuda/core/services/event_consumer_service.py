"""Serviço para consumo e processamento de eventos da fila RabbitMQ."""

import json
from typing import Optional

from aio_pika import DeliveryMode, Message
from aio_pika.abc import AbstractQueue

from teajuda.core.exceptions.base import ServiceError
from teajuda.core.infrastructure.logging import get_logger
from teajuda.core.infrastructure.rabbitmq import RabbitMQManager
from teajuda.core.repositories.customer_repository import CustomerRepository
from teajuda.core.repositories.tenant_repository import TenantRepository
from teajuda.core.services.evolution_service import EvolutionService, EvolutionServiceError

logger = get_logger(__name__)

QUEUE_EMPTY_TIMEOUT = 1.0


class EventConsumerServiceError(ServiceError):
    """Exceção customizada para erros no consumo de eventos."""

    pass


class EventConsumerService:
    """Consome eventos da fila RabbitMQ e os processa."""

    def __init__(
        self,
        rabbitmq_manager: RabbitMQManager,
        evolution_service: EvolutionService,
        tenant_repository: TenantRepository,
        customer_repository: CustomerRepository,
    ):
        self.rabbitmq = rabbitmq_manager
        self.evolution = evolution_service
        self.tenant_repo = tenant_repository
        self.customer_repo = customer_repository

    async def consume_and_process(self, limit: int = 100) -> dict:
        """Consome até *limit* mensagens da fila e as processa.

        Returns:
            Resumo com contagem de processadas e falhas.
        """
        processed = 0
        failed = 0

        for _ in range(limit):
            try:
                message = await self.rabbitmq.queue.get(no_ack=False, timeout=QUEUE_EMPTY_TIMEOUT)
            except Exception:
                # QueueEmpty ou timeout — encerra o lote
                break

            success = await self._process_message(message)
            if success:
                processed += 1
            else:
                # _process_message já gerenciou ack/nack/retry
                failed += 1

        return {"processed": processed, "failed": failed, "skipped": 0}

    async def _process_message(self, message) -> bool:
        """Processa uma única mensagem.

        Returns:
            True se a mensagem foi ack'ed (sucesso ou descarte).
            False se falhou e foi nack'ed ou republicada.
        """
        retry_count = 0
        if message.headers:
            retry_count = message.headers.get("x-retry-count", 0)

        try:
            payload = json.loads(message.body.decode("utf-8"))
            tenant_id = payload.get("tenant_id")
            customer_id = payload.get("customer_id")
            event_type = payload.get("type")
            event_payload = payload.get("payload", {})

            if not tenant_id:
                logger.warning("Evento sem tenant_id, descartando")
                await message.ack()
                return True

            tenant = await self.tenant_repo.get_by_id(tenant_id)
            if not tenant:
                logger.warning(f"Tenant não encontrado, descartando: {tenant_id}")
                await message.ack()
                return True

            if event_type == "message":
                await self._handle_message_event(tenant, customer_id, event_payload)
            elif event_type == "instance_created":
                # Auto-provisionamento já ocorre no publisher; aqui apenas loga
                logger.info(f"Evento instance_created processado: {tenant_id}")
            else:
                logger.warning(f"Tipo de evento desconhecido, descartando: {event_type}")

            await message.ack()
            logger.info(f"Evento processado: {event_type} | tenant={tenant_id}")
            return True

        except Exception as exc:
            logger.error(
                f"Erro ao processar evento: {exc} (retry_count={retry_count})"
            )

            if retry_count == 0:
                await self._republish_with_retry(message)
                await message.ack()
            else:
                await message.nack(requeue=False)
            return False

    async def _handle_message_event(
        self, tenant: dict, customer_id: Optional[str], payload: dict
    ) -> None:
        """Processa um evento do tipo 'message' enviando WhatsApp."""
        instance_name = tenant.get("name")
        if not instance_name:
            raise EventConsumerServiceError(
                f"Tenant {tenant['id']} não possui nome de instância configurado"
            )

        phone = payload.get("phone")
        text = payload.get("text")

        if not phone and customer_id:
            customer = await self.customer_repo.get_by_id(customer_id)
            if customer:
                phones = customer.get("phones", [])
                if phones:
                    phone = phones[0].get("value")

        if not phone:
            raise EventConsumerServiceError(
                "Telefone não informado no payload e customer não possui telefone"
            )

        if not text:
            raise EventConsumerServiceError("Texto da mensagem não informado no payload")

        try:
            result = await self.evolution.send_text(
                instance_name=instance_name,
                number=phone,
                text=text,
                delay=payload.get("delay", 1200),
            )
            logger.info(
                "Mensagem WhatsApp enviada",
                phone=phone,
                instance_name=instance_name,
                result=result,
            )
        except EvolutionServiceError as exc:
            raise EventConsumerServiceError(f"Falha ao enviar mensagem WhatsApp: {exc}") from exc

    async def _republish_with_retry(self, message) -> None:
        """Republica a mensagem na fila principal com retry_count incrementado."""
        body = message.body
        headers = dict(message.headers) if message.headers else {}
        headers["x-retry-count"] = headers.get("x-retry-count", 0) + 1

        await self.rabbitmq.exchange.publish(
            Message(
                body=body,
                headers=headers,
                delivery_mode=DeliveryMode.PERSISTENT,
                content_type="application/json",
            ),
            routing_key="teajuda.events",
        )
        logger.info("Evento republicado para retry", retry=headers["x-retry-count"])
