import secrets
from typing import Any, Dict

import mercadopago

from teajuda.core.infrastructure.logging import get_logger
from teajuda.core.infrastructure.settings import settings
from teajuda.core.models.payment import PaymentCreate, PaymentUpdate
from teajuda.core.repositories.payment_repository import PaymentRepository

logger = get_logger(__name__)


class PaymentService:
    def __init__(self, repository: PaymentRepository):
        self.repository = repository
        self.sdk = mercadopago.SDK(settings.MERCADO_PAGO_ACCESS_TOKEN)

    async def create_payment_link(self, subscription_id: str, plan_name: str, price: float) -> str:
        """
        Creates a Mercado Pago preference, persists the payment record,
        and returns the init_point (payment link).
        """
        if price <= 0:
            return "No payment required for this plan."

        max_installments = 1
        plan_lower = plan_name.lower()
        if "anual" in plan_lower or "annual" in plan_lower:
            max_installments = 10

        callback_token = secrets.token_urlsafe(32)

        preference_data: Dict[str, Any] = {
            "items": [
                {
                    "title": f"Assinatura Tutto MCP - Plano {plan_name.capitalize()}",
                    "quantity": 1,
                    "unit_price": price,
                    "currency_id": "BRL",
                }
            ],
            "external_reference": subscription_id,
            "payment_methods": {
                "installments": max_installments,
                "excluded_payment_types": [
                    {"id": "ticket"},
                    {"id": "atm"},
                    {"id": "debit_card"},
                    {"id": "prepaid_card"},
                ],
            },
            "back_urls": {
                "success": f"{settings.MERCADO_PAGO_BACK_URL_BASE}/payments/mercadopago/callback?token={callback_token}",
                "failure": f"{settings.MERCADO_PAGO_BACK_URL_BASE}/payments/mercadopago/callback?token={callback_token}",
                "pending": f"{settings.MERCADO_PAGO_BACK_URL_BASE}/payments/mercadopago/callback?token={callback_token}",
            },
            "auto_return": "approved",
        }

        preference_response = self.sdk.preference().create(preference_data)

        if preference_response["status"] >= 400:
            raise Exception(f"Mercado Pago error: {preference_response['response']}")

        response_body = preference_response["response"]
        preference_id = response_body.get("id")
        init_point = response_body.get("init_point")

        payment_in = PaymentCreate(
            subscription_id=subscription_id,
            callback_token=callback_token,
            state="pending",
            mercado_pago_preference_id=preference_id,
            mercado_pago_data=response_body,
            amount=price,
            currency_id="BRL",
        )
        await self.repository.create(payment_in)

        return init_point

    async def process_callback(self, callback_data: Dict[str, Any], token: str) -> dict:
        """
        Processes the Mercado Pago callback (back_urls) and updates the payment state.
        Typical query params include: collection_id, collection_status, payment_id,
        status, external_reference, payment_type, merchant_order_id, preference_id.
        """
        preference_id = callback_data.get("preference_id")
        status = callback_data.get("collection_status") or callback_data.get("status", "pending")

        if not preference_id:
            raise ValueError("Missing preference_id in callback data")

        payment = await self.repository.get_by_preference_id(preference_id)
        if not payment:
            logger.warning(f"Payment with preference_id {preference_id} not found for callback")
            raise ValueError(f"Payment with preference_id {preference_id} not found")

        if payment.get("callback_token") != token:
            logger.warning(f"Invalid callback token for payment {payment.get('id')}")
            raise ValueError("Invalid callback token")

        # Map Mercado Pago statuses to internal states
        state_map = {
            "approved": "approved",
            "pending": "pending",
            "in_process": "in_process",
            "in_mediation": "in_mediation",
            "rejected": "failure",
            "cancelled": "cancelled",
            "refunded": "refunded",
            "charged_back": "charged_back",
        }
        internal_state = state_map.get(status, "pending")

        update = PaymentUpdate(
            state=internal_state,  # type: ignore[arg-type]
            mercado_pago_callback_data=callback_data,
        )
        updated = await self.repository.update(payment["id"], update)
        if not updated:
            raise ValueError("Failed to update payment")

        return updated
