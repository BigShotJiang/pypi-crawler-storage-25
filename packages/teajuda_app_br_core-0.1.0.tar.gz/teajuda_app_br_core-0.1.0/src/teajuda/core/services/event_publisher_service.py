"""Serviço para publicação de eventos na fila RabbitMQ."""

import json
from datetime import datetime, timezone

from aio_pika import DeliveryMode, Message

from teajuda.core.infrastructure.logging import get_logger
from teajuda.core.infrastructure.rabbitmq import RabbitMQManager

logger = get_logger(__name__)


class EventPublisherService:
    """Publica eventos da Evolution API na exchange RabbitMQ."""

    def __init__(self, rabbitmq_manager: RabbitMQManager):
        self.rabbitmq = rabbitmq_manager

    async def publish_instance_event(
        self, tenant_id: str, phone: str, customer_id: str | None = None
    ) -> None:
        """Publica evento de criação de instância."""
        payload = {
            "type": "instance_created",
            "channel": "whatsapp",
            "tenant_id": tenant_id,
            "customer_id": customer_id,
            "payload": {"phone": phone},
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await self._publish(payload)

    async def publish_message_event(
        self, tenant_id: str, customer_id: str, message: dict
    ) -> None:
        """Publica evento de mensagem."""
        payload = {
            "type": "message",
            "channel": "whatsapp",
            "tenant_id": tenant_id,
            "customer_id": customer_id,
            "payload": message,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        await self._publish(payload)

    async def _publish(self, payload: dict) -> None:
        """Serializa e publica o payload na exchange."""
        message = Message(
            body=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            delivery_mode=DeliveryMode.PERSISTENT,
            content_type="application/json",
        )
        await self.rabbitmq.exchange.publish(message, routing_key="teajuda.events")
        logger.info(
            "Evento publicado",
            type=payload["type"],
            tenant_id=payload["tenant_id"],
        )
