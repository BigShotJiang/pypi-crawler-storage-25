"""Exceções base compartilhadas para serviços."""


class ServiceError(Exception):
    """Erro genérico de serviço."""

    pass


class NotFoundError(ServiceError):
    """Recurso não encontrado."""

    pass


class ValidationError(ServiceError):
    """Dados inválidos."""

    pass


class ConflictError(ServiceError):
    """Conflito de estado ou duplicidade."""

    pass
