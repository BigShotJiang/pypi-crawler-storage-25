# Utilitários auxiliares genéricos (placeholder para futuras funções compartilhadas)
