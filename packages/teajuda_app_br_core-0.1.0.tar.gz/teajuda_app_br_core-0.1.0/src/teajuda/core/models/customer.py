from datetime import datetime
from typing import List, Optional

from pydantic import BaseModel, ConfigDict, Field

from teajuda.core.models.pyobjectid import PyObjectId


class CustomerPhone(BaseModel):
    value: str = Field(..., json_schema_extra={"example": "5511999999999"})
    type: str = Field(default="mobile", json_schema_extra={"example": "mobile"})
    is_main: bool = Field(default=False, json_schema_extra={"example": True})


class CustomerEmail(BaseModel):
    value: str = Field(..., json_schema_extra={"example": "maria@example.com"})
    type: str = Field(default="personal", json_schema_extra={"example": "personal"})
    is_main: bool = Field(default=False, json_schema_extra={"example": True})


class CustomerCreate(BaseModel):
    tenants: List[str] = Field(
        ..., json_schema_extra={"example": ["65f1a2b3c4d5e6f7a8b9c0d1"]}
    )
    name: str = Field(..., json_schema_extra={"example": "Maria Oliveira"})
    emails: List[CustomerEmail] = Field(
        ...,
        json_schema_extra={
            "example": [{"value": "maria@example.com", "type": "personal", "is_main": True}]
        },
    )
    phones: List[CustomerPhone] = Field(
        ...,
        json_schema_extra={
            "example": [{"value": "5511999999999", "type": "mobile", "is_main": True}]
        },
    )
    google_id: Optional[str] = Field(None, json_schema_extra={"example": "123456789"})


class CustomerUpdate(BaseModel):
    tenants: Optional[List[str]] = Field(
        None, json_schema_extra={"example": ["65f1a2b3c4d5e6f7a8b9c0d1"]}
    )
    name: Optional[str] = Field(None, json_schema_extra={"example": "Maria Oliveira"})
    emails: Optional[List[CustomerEmail]] = Field(
        None,
        json_schema_extra={
            "example": [{"value": "maria@example.com", "type": "personal", "is_main": True}]
        },
    )
    phones: Optional[List[CustomerPhone]] = Field(
        None,
        json_schema_extra={
            "example": [{"value": "5511999999999", "type": "mobile", "is_main": True}]
        },
    )
    google_id: Optional[str] = Field(None, json_schema_extra={"example": "123456789"})
    is_active: Optional[bool] = Field(None, json_schema_extra={"example": True})


class GoogleTokenRequest(BaseModel):
    google_token: str = Field(..., description="ID token JWT recebido do Google")


class CustomerOut(BaseModel):
    id: PyObjectId = Field(..., alias="id")
    tenants: List[str]
    name: str
    emails: List[CustomerEmail]
    phones: List[CustomerPhone]
    google_id: Optional[str] = None
    is_active: bool = True
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
