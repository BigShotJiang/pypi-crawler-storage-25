from datetime import datetime
from typing import Any, Dict, Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from teajuda.core.models.pyobjectid import PyObjectId


class PaymentCreate(BaseModel):
    subscription_id: str = Field(..., json_schema_extra={"example": "sub_abc123"})
    callback_token: str = Field(..., json_schema_extra={"example": "aBcD1234"})
    state: Literal[
        "pending",
        "approved",
        "failure",
        "cancelled",
        "in_process",
        "in_mediation",
        "refunded",
        "charged_back",
    ] = Field("pending", json_schema_extra={"example": "pending"})
    mercado_pago_preference_id: Optional[str] = Field(
        None, json_schema_extra={"example": "pref_123456"}
    )
    mercado_pago_data: Dict[str, Any] = Field(
        default_factory=dict, json_schema_extra={"example": {}}
    )
    amount: float = Field(..., json_schema_extra={"example": 29.9})
    currency_id: str = Field("BRL", json_schema_extra={"example": "BRL"})


class PaymentUpdate(BaseModel):
    state: Optional[
        Literal[
            "pending",
            "approved",
            "failure",
            "cancelled",
            "in_process",
            "in_mediation",
            "refunded",
            "charged_back",
        ]
    ] = Field(None, json_schema_extra={"example": "approved"})
    mercado_pago_callback_data: Optional[Dict[str, Any]] = Field(
        None, json_schema_extra={"example": {}}
    )


class PaymentOut(BaseModel):
    id: PyObjectId = Field(..., alias="id")
    subscription_id: str
    callback_token: str
    state: str
    mercado_pago_preference_id: Optional[str] = None
    mercado_pago_data: Dict[str, Any] = Field(default_factory=dict)
    mercado_pago_callback_data: Optional[Dict[str, Any]] = None
    amount: float
    currency_id: str = "BRL"
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
