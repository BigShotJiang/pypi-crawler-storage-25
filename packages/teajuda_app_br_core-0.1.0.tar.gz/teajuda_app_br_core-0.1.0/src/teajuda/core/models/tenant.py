from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from teajuda.core.models.pyobjectid import PyObjectId


class TenantCreate(BaseModel):
    customer_id: str = Field(..., json_schema_extra={"example": "cust_12345"})
    phone: str = Field(..., json_schema_extra={"example": "5511999999999"})
    qr: Optional[str] = Field(None, json_schema_extra={"example": "base64-qr-code-data"})
    state: Literal["connecting", "stopped", "connected"] = Field(
        "stopped", json_schema_extra={"example": "stopped"}
    )
    token: Optional[str] = Field(None, json_schema_extra={"example": "AbC1xYz9QwErTyUiOpAsDfGhJkL"})
    type: Literal["main", "customer"] = Field("customer", json_schema_extra={"example": "customer"})
    name: str = Field("Tutto", json_schema_extra={"example": "Tutto"})


class TenantUpdate(BaseModel):
    customer_id: Optional[str] = Field(None, json_schema_extra={"example": "cust_12345"})
    phone: Optional[str] = Field(None, json_schema_extra={"example": "5511999999999"})
    qr: Optional[str] = Field(None, json_schema_extra={"example": "base64-qr-code-data"})
    state: Optional[Literal["connecting", "stopped", "connected"]] = Field(
        None, json_schema_extra={"example": "connected"}
    )
    token: Optional[str] = Field(None, json_schema_extra={"example": "AbC1xYz9QwErTyUiOpAsDfGhJkL"})
    type: Optional[Literal["main", "customer"]] = Field(None, json_schema_extra={"example": "main"})
    name: Optional[str] = Field(None, json_schema_extra={"example": "Tutto Barbearia"})


class TenantOut(BaseModel):
    id: PyObjectId = Field(..., alias="id")
    customer_id: str
    phone: str
    qr: Optional[str] = None
    state: str
    token: str
    type: str
    name: str
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
