from datetime import datetime
from typing import Literal, Optional

from pydantic import BaseModel, ConfigDict, Field

from teajuda.core.models.pyobjectid import PyObjectId


class SubscriptionCreate(BaseModel):
    customer_id: str = Field(..., json_schema_extra={"example": "cust_12345"})
    tenant_id: str = Field(..., json_schema_extra={"example": "65f1a2b3c4d5e6f7a8b9c0d1"})
    plan_id: str = Field(..., json_schema_extra={"example": "65f1a2b3c4d5e6f7a8b9c0d2"})
    coupon_id: Optional[str] = Field(None, json_schema_extra={"example": "65f1a2b3c4d5e6f7a8b9c0d3"})
    expires_in: datetime = Field(..., json_schema_extra={"example": "2026-05-18T00:00:00"})
    is_active: bool = Field(True, json_schema_extra={"example": True})
    canceled_at: Optional[datetime] = Field(None, json_schema_extra={"example": "2026-04-18T00:00:00"})
    state: Literal["pending", "paid"] = Field("pending", json_schema_extra={"example": "pending"})
    payment_id: Optional[str] = Field(None, json_schema_extra={"example": "pay_abc123"})


class SubscriptionUpdate(BaseModel):
    plan_id: Optional[str] = Field(None, json_schema_extra={"example": "65f1a2b3c4d5e6f7a8b9c0d2"})
    coupon_id: Optional[str] = Field(None, json_schema_extra={"example": "65f1a2b3c4d5e6f7a8b9c0d3"})
    expires_in: Optional[datetime] = Field(None, json_schema_extra={"example": "2026-06-18T00:00:00"})
    is_active: Optional[bool] = Field(None, json_schema_extra={"example": False})
    canceled_at: Optional[datetime] = Field(None, json_schema_extra={"example": "2026-04-18T00:00:00"})
    state: Optional[Literal["pending", "paid"]] = Field(None, json_schema_extra={"example": "paid"})
    payment_id: Optional[str] = Field(None, json_schema_extra={"example": "pay_abc123"})


class SubscriptionOut(BaseModel):
    id: PyObjectId = Field(..., alias="id")
    customer_id: str
    tenant_id: str
    plan_id: str
    coupon_id: Optional[str] = None
    expires_in: datetime
    is_active: bool = True
    canceled_at: Optional[datetime] = None
    state: Literal["pending", "paid"] = "pending"
    payment_id: Optional[str] = None
    created_at: datetime
    updated_at: datetime

    model_config = ConfigDict(from_attributes=True, populate_by_name=True)
