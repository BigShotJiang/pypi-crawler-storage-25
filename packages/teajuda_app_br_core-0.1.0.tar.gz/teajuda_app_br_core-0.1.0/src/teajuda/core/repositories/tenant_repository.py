from typing import Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.repositories.base import BaseRepository


class TenantRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "tenants")

    async def get_by_phone(self, phone: str) -> Optional[dict]:
        doc = await self.collection.find_one({"phone": phone})
        return self._map_doc(doc)

    async def get_by_token(self, token: str) -> Optional[dict]:
        doc = await self.collection.find_one({"token": token})
        return self._map_doc(doc)

    async def get_by_customer_id(self, customer_id: str) -> Optional[dict]:
        doc = await self.collection.find_one({"customer_id": customer_id})
        return self._map_doc(doc)
