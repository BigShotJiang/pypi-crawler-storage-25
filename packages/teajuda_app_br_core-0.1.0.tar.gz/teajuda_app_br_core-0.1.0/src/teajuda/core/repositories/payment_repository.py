from datetime import datetime, timezone
from typing import List, Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.models.payment import PaymentUpdate
from teajuda.core.repositories.base import BaseRepository


class PaymentRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "payments")

    async def get_by_subscription_id(self, subscription_id: str) -> List[dict]:
        cursor = self.collection.find({"subscription_id": subscription_id})
        docs = await cursor.to_list(length=100)
        return [self._map_doc(doc) for doc in docs if doc is not None]  # type: ignore

    async def get_by_preference_id(self, preference_id: str) -> Optional[dict]:
        doc = await self.collection.find_one({"mercado_pago_preference_id": preference_id})
        return self._map_doc(doc)

    async def update(self, payment_id: str, payment_update: PaymentUpdate) -> Optional[dict]:
        if not ObjectId.is_valid(payment_id):
            return None

        update_data = payment_update.model_dump(exclude_unset=True)
        if not update_data:
            return await self.get_by_id(payment_id)

        update_data["updated_at"] = datetime.now(timezone.utc)

        await self.collection.update_one({"_id": ObjectId(payment_id)}, {"$set": update_data})

        doc = await self.collection.find_one({"_id": ObjectId(payment_id)})
        return self._map_doc(doc)

    async def update_by_preference_id(
        self, preference_id: str, payment_update: PaymentUpdate
    ) -> Optional[dict]:
        update_data = payment_update.model_dump(exclude_unset=True)
        if not update_data:
            return await self.get_by_preference_id(preference_id)

        update_data["updated_at"] = datetime.now(timezone.utc)

        await self.collection.update_one(
            {"mercado_pago_preference_id": preference_id}, {"$set": update_data}
        )

        doc = await self.collection.find_one({"mercado_pago_preference_id": preference_id})
        return self._map_doc(doc)
