from datetime import datetime, timezone
from typing import Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.repositories.base import BaseRepository


class SecurityIdentityRepository(BaseRepository):
    """Repositório para gerenciar identidades de segurança no MongoDB."""

    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "security_identities")

    async def find_by_client_id(self, client_id: str) -> Optional[dict]:
        doc = await self.collection.find_one({"credentials.client_id": client_id})
        return self._map_doc(doc)

    async def create_identity(
        self,
        app_name: str,
        credentials: dict,
        access_control: dict,
        is_active: bool = True,
    ) -> dict:
        now = datetime.now(timezone.utc)
        doc = {
            "app_name": app_name,
            "credentials": credentials,
            "access_control": access_control,
            "is_active": is_active,
            "created_at": now,
            "updated_at": now,
        }
        result = await self.collection.insert_one(doc)
        created = await self.collection.find_one({"_id": result.inserted_id})
        mapped = self._map_doc(created)
        if mapped is None:
            raise RuntimeError("Failed to retrieve created security identity")
        return mapped
