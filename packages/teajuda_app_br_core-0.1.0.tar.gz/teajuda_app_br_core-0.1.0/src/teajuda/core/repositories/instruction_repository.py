from datetime import datetime, timezone
from typing import List, Optional, Union

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.models.instruction import InstructionCreate
from teajuda.core.repositories.base import BaseRepository


class InstructionRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "tenants_instructions")

    async def create(self, instruction: InstructionCreate) -> dict:
        instruction_dict = instruction.model_dump()
        instruction_dict["created_at"] = datetime.now(timezone.utc)
        instruction_dict["updated_at"] = datetime.now(timezone.utc)
        instruction_dict["is_active"] = True
        result = await self.collection.insert_one(instruction_dict)
        doc = await self.collection.find_one({"_id": result.inserted_id})
        mapped = self._map_doc(doc)
        if mapped is None:
            raise RuntimeError("Failed to retrieve created document")
        return mapped

    async def update(
        self, instruction_id: str, instruction: Union[InstructionCreate, dict]
    ) -> Optional[dict]:
        if not ObjectId.is_valid(instruction_id):
            return None

        if isinstance(instruction, InstructionCreate):
            update_data = instruction.model_dump(exclude_unset=True)
        else:
            update_data = instruction

        update_data["updated_at"] = datetime.now(timezone.utc)

        await self.collection.update_one(
            {"_id": ObjectId(instruction_id)}, {"$set": update_data}
        )

        doc = await self.collection.find_one({"_id": ObjectId(instruction_id)})
        return self._map_doc(doc) if doc else None

    async def find_by_tenant(self, tenant_id: str) -> List[dict]:
        cursor = self.collection.find({"tenant_id": tenant_id, "is_active": True})
        docs = await cursor.to_list(length=100)
        return [self._map_doc(doc) for doc in docs if doc]  # type: ignore[misc]

    async def search(self, tenant_id: str, query: str) -> List[dict]:
        cursor = self.collection.find(
            {"tenant_id": tenant_id, "is_active": True, "name": {"$regex": query, "$options": "i"}}
        )
        docs = await cursor.to_list(length=100)
        return [self._map_doc(doc) for doc in docs if doc]  # type: ignore[misc]
