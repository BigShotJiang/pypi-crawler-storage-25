from datetime import datetime, timezone
from typing import Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.models.subscription import SubscriptionUpdate
from teajuda.core.repositories.base import BaseRepository


class SubscriptionRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "subscriptions")

    async def get_by_tenant(
        self, tenant_id: str, is_active: Optional[bool] = True
    ) -> Optional[dict]:
        query: dict = {"tenant_id": tenant_id}
        if is_active is not None:
            query["is_active"] = is_active

        doc = await self.collection.find_one(query)
        return self._map_doc(doc)

    async def update_by_tenant(
        self, tenant_id: str, subscription_update: SubscriptionUpdate
    ) -> Optional[dict]:
        update_data = subscription_update.model_dump(exclude_unset=True)
        if not update_data:
            return await self.get_by_tenant(tenant_id, is_active=True)

        update_data["updated_at"] = datetime.now(timezone.utc)

        await self.collection.update_one({"tenant_id": tenant_id}, {"$set": update_data})

        doc = await self.collection.find_one({"tenant_id": tenant_id})
        return self._map_doc(doc)
