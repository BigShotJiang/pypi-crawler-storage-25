from datetime import datetime, timezone
from typing import List, Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.models.coupon import CouponUpdate
from teajuda.core.repositories.base import BaseRepository


class CouponRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "coupons")

    async def get_by_short_code(self, short_code: str) -> Optional[dict]:
        doc = await self.collection.find_one({"short_code": short_code})
        return self._map_doc(doc)

    async def list_active(self) -> List[dict]:
        now = datetime.now(timezone.utc)
        cursor = self.collection.find(
            {
                "is_active": True,
                "start_date": {"$lte": now},
                "$or": [{"end_date": None}, {"end_date": {"$gte": now}}],
            }
        )
        docs = await cursor.to_list(length=100)
        return [self._map_doc(doc) for doc in docs if doc]  # type: ignore[misc]

    async def update(self, coupon_id: str, coupon_update: CouponUpdate) -> Optional[dict]:
        if not ObjectId.is_valid(coupon_id):
            return None

        update_data = coupon_update.model_dump(exclude_unset=True)
        if not update_data:
            return await self.get_by_id(coupon_id)

        update_data["updated_at"] = datetime.now(timezone.utc)

        await self.collection.update_one({"_id": ObjectId(coupon_id)}, {"$set": update_data})

        doc = await self.collection.find_one({"_id": ObjectId(coupon_id)})
        return self._map_doc(doc)
