from datetime import datetime, timezone
from typing import Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase


class BaseRepository:
    """Repositório base genérico para coleções MongoDB."""

    def __init__(self, db: AsyncIOMotorDatabase, collection_name: str):
        self.collection = db[collection_name]

    def _map_doc(self, doc) -> Optional[dict]:
        if not doc:
            return None
        mapped = dict(doc)
        mapped["id"] = str(mapped.pop("_id"))
        return mapped

    async def create(self, data_dict) -> dict:
        now = datetime.now(timezone.utc)
        data_dict["created_at"] = now
        data_dict["updated_at"] = now
        result = await self.collection.insert_one(data_dict)
        doc = await self.collection.find_one({"_id": result.inserted_id})
        mapped = self._map_doc(doc)
        if mapped is None:
            raise RuntimeError("Failed to retrieve created document")
        return mapped

    async def get_by_id(self, doc_id: str) -> Optional[dict]:
        if not ObjectId.is_valid(doc_id):
            return None
        doc = await self.collection.find_one({"_id": ObjectId(doc_id)})
        return self._map_doc(doc)

    async def update(self, doc_id: str, data) -> Optional[dict]:
        if not ObjectId.is_valid(doc_id):
            return None
        data["updated_at"] = datetime.now(timezone.utc)
        await self.collection.update_one({"_id": ObjectId(doc_id)}, {"$set": data})
        return await self.get_by_id(doc_id)

    async def delete(self, doc_id: str) -> bool:
        if not ObjectId.is_valid(doc_id):
            return False
        result = await self.collection.delete_one({"_id": ObjectId(doc_id)})
        return result.deleted_count > 0
