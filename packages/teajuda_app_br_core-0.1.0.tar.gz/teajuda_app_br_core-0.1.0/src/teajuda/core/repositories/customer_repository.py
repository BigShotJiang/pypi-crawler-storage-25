from typing import List, Optional

from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.repositories.base import BaseRepository


class CustomerRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "customers")

    async def get_by_email(self, email: str) -> Optional[dict]:
        doc = await self.collection.find_one(
            {"emails.value": email.lower().strip()}
        )
        return self._map_doc(doc)

    async def get_by_phone(self, phone: str) -> Optional[dict]:
        doc = await self.collection.find_one({"phones.value": phone})
        return self._map_doc(doc)

    async def get_by_google_id(self, google_id: str) -> Optional[dict]:
        doc = await self.collection.find_one({"google_id": google_id})
        return self._map_doc(doc)

    async def find_by_tenant(self, tenant_id: str) -> List[dict]:
        cursor = self.collection.find({"tenants": tenant_id})
        return [self._map_doc(doc) async for doc in cursor]  # type: ignore[misc]
