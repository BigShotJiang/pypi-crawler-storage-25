from datetime import datetime, timezone
from typing import List, Optional

from bson import ObjectId
from motor.motor_asyncio import AsyncIOMotorDatabase

from teajuda.core.models.plan import PlanCreate, PlanUpdate
from teajuda.core.repositories.base import BaseRepository


class PlanRepository(BaseRepository):
    def __init__(self, db: AsyncIOMotorDatabase):
        super().__init__(db, "plans")

    async def create(self, plan: PlanCreate) -> dict:
        plan_dict = plan.model_dump()
        plan_dict["created_at"] = datetime.now(timezone.utc)
        plan_dict["updated_at"] = datetime.now(timezone.utc)
        plan_dict["price_history"] = [
            {"price": plan.price, "changed_at": datetime.now(timezone.utc), "reason": "Initial price"}
        ]
        result = await self.collection.insert_one(plan_dict)
        doc = await self.collection.find_one({"_id": result.inserted_id})
        mapped = self._map_doc(doc)
        if mapped is None:
            raise RuntimeError("Failed to retrieve created document")
        return mapped

    async def get_by_name(self, name: str) -> Optional[dict]:
        doc = await self.collection.find_one({"name": name})
        return self._map_doc(doc)

    async def list_active(self) -> List[dict]:
        cursor = self.collection.find({"is_active": True})
        docs = await cursor.to_list(length=100)
        return [self._map_doc(doc) for doc in docs if doc is not None]  # type: ignore

    async def update(self, plan_id: str, plan_update: PlanUpdate) -> Optional[dict]:
        if not ObjectId.is_valid(plan_id):
            return None

        current = await self.collection.find_one({"_id": ObjectId(plan_id)})
        if not current:
            return None

        update_data = plan_update.model_dump(exclude_unset=True)
        change_reason = update_data.pop("change_reason", None)

        if not update_data:
            return self._map_doc(current)

        if "price" in update_data and update_data["price"] != current.get("price"):
            history_entry = {
                "price": update_data["price"],
                "changed_at": datetime.now(timezone.utc),
                "reason": change_reason or "Price update",
            }
            await self.collection.update_one(
                {"_id": ObjectId(plan_id)}, {"$push": {"price_history": history_entry}}
            )

        update_data["updated_at"] = datetime.now(timezone.utc)

        await self.collection.update_one({"_id": ObjectId(plan_id)}, {"$set": update_data})

        doc = await self.collection.find_one({"_id": ObjectId(plan_id)})
        return self._map_doc(doc)
