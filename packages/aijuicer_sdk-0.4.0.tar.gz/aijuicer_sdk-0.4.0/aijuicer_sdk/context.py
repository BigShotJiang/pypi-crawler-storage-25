"""AgentContext：handler 内可用的副作用对象。

产物存取**全部走 HTTP**（不再依赖 agent 与 scheduler 共享 FS）：
- save_artifact → POST /api/artifacts/upload （multipart 字节）
- load_artifact → GET  /api/workflows/{wf}/artifacts/by-key/content
两端可以分布在不同机器、不同容器、不同云。
"""

from __future__ import annotations

import hashlib
from dataclasses import dataclass
from typing import Any

import structlog

from aijuicer_sdk.transport import SchedulerClient


@dataclass
class ArtifactRef:
    key: str
    size_bytes: int
    sha256: str


class AgentContext:
    def __init__(
        self,
        *,
        task_id: str,
        workflow_id: str,
        step: str,
        attempt: int,
        input: dict,
        artifact_root: str,  # 兼容旧 payload；HTTP 模式下 SDK 不再使用
        request_id: str,
        client: SchedulerClient,
    ) -> None:
        self.task_id = task_id
        self.workflow_id = workflow_id
        self.step = step
        self.attempt = attempt
        self.input = input
        self.artifact_root = artifact_root
        self.request_id = request_id
        self._client = client
        self.log = structlog.get_logger("aijuicer_sdk.handler").bind(
            request_id=request_id,
            workflow_id=workflow_id,
            step=step,
            attempt=attempt,
            task_id=task_id,
        )

    async def heartbeat(self, message: str | None = None) -> None:
        await self._client.task_heartbeat(
            task_id=self.task_id, message=message, request_id=self.request_id
        )

    async def save_artifact(
        self, key: str, data: str | bytes, *, content_type: str | None = None
    ) -> ArtifactRef:
        """把产物字节通过 HTTP 上传给 scheduler，由 scheduler 写入 DB。"""
        raw: bytes = data.encode("utf-8") if isinstance(data, str) else data
        await self._client.upload_artifact(
            workflow_id=self.workflow_id,
            step=self.step,
            key=key,
            data=raw,
            content_type=content_type,
            request_id=self.request_id,
        )
        ref = ArtifactRef(
            key=key,
            size_bytes=len(raw),
            sha256=hashlib.sha256(raw).hexdigest(),
        )
        await self.log.ainfo(
            "artifact.saved", key=key, size_bytes=ref.size_bytes, sha256=ref.sha256
        )
        return ref

    async def load_artifact(self, step: str, key: str) -> bytes:
        """从 scheduler 拉指定 step+key 的产物字节。

        找不到时抛 FileNotFoundError（保持与旧 FS 版一致的错误类型）。
        """
        return await self._client.fetch_artifact_by_key(
            workflow_id=self.workflow_id, step=step, key=key
        )

    @staticmethod
    def from_task_payload(payload: dict[str, Any], *, client: SchedulerClient) -> AgentContext:
        return AgentContext(
            task_id=payload["task_id"],
            workflow_id=payload["workflow_id"],
            step=payload["step"],
            attempt=int(payload["attempt"]),
            input=payload.get("input") or {},
            artifact_root=payload.get("artifact_root", ""),
            request_id=payload["request_id"],
            client=client,
        )
