//! types for org domain
