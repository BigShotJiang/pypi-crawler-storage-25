//! types for auth domain
