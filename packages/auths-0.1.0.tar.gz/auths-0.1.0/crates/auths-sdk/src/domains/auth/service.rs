//! service for auth domain
