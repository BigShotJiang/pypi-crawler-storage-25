//! types for compliance domain
