//! error for signing domain
