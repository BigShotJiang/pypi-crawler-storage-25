//! error for namespace domain
