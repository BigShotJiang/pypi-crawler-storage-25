//! types for namespace domain
