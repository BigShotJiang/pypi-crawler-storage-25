//! service for namespace domain
