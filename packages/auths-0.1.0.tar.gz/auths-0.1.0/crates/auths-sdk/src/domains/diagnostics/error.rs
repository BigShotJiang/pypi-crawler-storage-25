//! error for diagnostics domain
