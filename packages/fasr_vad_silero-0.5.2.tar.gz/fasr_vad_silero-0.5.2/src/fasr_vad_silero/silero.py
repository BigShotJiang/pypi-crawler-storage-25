from __future__ import annotations

from typing import Any, Iterable

from loguru import logger
import numpy as np
from pydantic import Field
import torch
from typing_extensions import Self

from fasr.config import Config, registry
from fasr.data import AudioChunk, Waveform
from fasr.model import VADModel


class SileroStreamVAD(VADModel):
    """Streaming voice activity detection powered by Silero VAD.

    Silero VAD processes fixed-size windows (512 samples at 16 kHz, i.e. 32 ms)
    and uses a threshold-based state machine to detect speech boundaries.
    This class wraps the model into fasr's ``VADModel`` streaming interface.

    Registry name:
        ``stream_silero`` -- registered via ``registry.vad_models``.

    Typical usage:
        >>> from fasr_vad_silero.silero import SileroStreamVAD
        >>> vad = SileroStreamVAD(threshold=0.5, silence_duration_ms=400)
        >>> for out_chunk in vad.push_chunk(audio_chunk):
        ...     print(out_chunk.vad_state, out_chunk.start_ms, out_chunk.end_ms)
    """

    threshold: float = Field(
        default=0.5,
        ge=0.0,
        le=1.0,
        description="Speech probability threshold; higher = more conservative.",
    )
    silence_duration_ms: int = Field(
        default=400,
        ge=0,
        description="Silence duration (ms) required to trigger speech stop.",
    )
    sample_rate: int = 16000
    chunk_size_ms: int = 32
    model: Any | None = Field(default=None, exclude=True)

    def load_checkpoint(self, checkpoint_dir: str | None = None) -> Self:
        """Load the Silero VAD model via torch.hub.

        Args:
            checkpoint_dir: Ignored for Silero (model is downloaded by torch.hub).
        """
        try:
            loaded = torch.hub.load(
                repo_or_dir="snakers4/silero-vad",
                model="silero_vad",
                force_reload=False,
                onnx=False,
            )
        except Exception as e:
            logger.warning(f"Failed to load Silero VAD from torch.hub: {e}")
            self.model = None
            return self

        self.model = loaded[0] if isinstance(loaded, (list, tuple)) else None
        if self.model is not None:
            self.model.eval()
            if torch.cuda.is_available():
                self.model = self.model.cuda()
        return self

    def push_chunk(self, chunk: AudioChunk) -> Iterable[AudioChunk]:
        """Feed one audio chunk into the streaming VAD engine.

        Yields :class:`AudioChunk` objects annotated with ``vad_state``:

        * ``segment_start`` -- first emission of a new speech segment.
        * ``segment_mid``   -- continued speech (or a complete short segment).
        * ``segment_end``   -- final emission when speech stops.
        """
        if chunk.is_start and chunk.stream_id in self.states:
            del self.states[chunk.stream_id]

        state: dict = self.states.get(chunk.stream_id, {})

        waveform = chunk.waveform
        if waveform.sample_rate != self.sample_rate:
            waveform = waveform.resample(self.sample_rate)

        window_size = 512 if self.sample_rate == 16000 else 256
        silence_samples = int(self.silence_duration_ms * self.sample_rate / 1000)

        buffer: np.ndarray = state.get("buffer", np.array([], dtype=np.float32))
        audio_waveform: Waveform = state.get(
            "audio_waveform",
            Waveform(
                data=np.array([], dtype=np.float32),
                sample_rate=self.sample_rate,
            ),
        )

        buffer = np.concatenate([buffer, waveform.data.flatten()])
        audio_waveform = audio_waveform.append(waveform)

        is_speaking: bool = state.get("is_speaking", False)
        speech_start_sample: int = state.get("speech_start_sample", 0)
        last_speech_sample: int = state.get("last_speech_sample", 0)
        silence_counter: int = state.get("silence_counter", 0)
        total_samples: int = state.get("total_samples", 0)
        emitted_until_sample: int | None = state.get("emitted_until_sample", None)
        pending_start: bool = state.get("pending_start", False)

        chunk_start_sample = total_samples
        total_samples += len(waveform.data)

        emitted: list[AudioChunk] = []
        offset = 0

        while len(buffer) >= window_size:
            window = buffer[:window_size]
            buffer = buffer[window_size:]

            window_start = chunk_start_sample + offset
            window_end = window_start + window_size
            prob = self._infer(window)

            if prob > self.threshold:
                if not is_speaking:
                    is_speaking = True
                    speech_start_sample = window_start
                    pending_start = True
                last_speech_sample = window_end
                silence_counter = 0
            else:
                if is_speaking:
                    silence_counter += window_size
                    if silence_counter >= silence_samples:
                        end_sample = last_speech_sample
                        self._emit_segment(
                            emitted,
                            chunk.stream_id,
                            audio_waveform,
                            speech_start_sample,
                            end_sample,
                            pending_start,
                            emitted_until_sample,
                        )
                        is_speaking = False
                        pending_start = False
                        emitted_until_sample = end_sample
                        silence_counter = 0

            offset += window_size

        processed_until_sample = chunk_start_sample + offset

        if is_speaking:
            if pending_start:
                start_sample = speech_start_sample
                end_sample = processed_until_sample
                w = self._slice_waveform(audio_waveform, start_sample, end_sample)
                emitted.append(
                    AudioChunk(
                        stream_id=chunk.stream_id,
                        start_ms=self._sample_to_ms(start_sample),
                        end_ms=-1,
                        waveform=w,
                        sample_rate=self.sample_rate,
                        vad_state="segment_start",
                        is_start=True,
                    )
                )
                pending_start = False
                emitted_until_sample = end_sample
            elif (
                emitted_until_sample is not None
                and last_speech_sample > emitted_until_sample
            ):
                start_sample = emitted_until_sample
                end_sample = last_speech_sample
                w = self._slice_waveform(audio_waveform, start_sample, end_sample)
                emitted.append(
                    AudioChunk(
                        stream_id=chunk.stream_id,
                        start_ms=-1,
                        end_ms=-1,
                        waveform=w,
                        sample_rate=self.sample_rate,
                        vad_state="segment_mid",
                    )
                )
                emitted_until_sample = end_sample

        if chunk.is_last:
            if is_speaking:
                end_sample = last_speech_sample
                if pending_start:
                    start_sample = speech_start_sample
                    w = self._slice_waveform(audio_waveform, start_sample, end_sample)
                    emitted.append(
                        AudioChunk(
                            stream_id=chunk.stream_id,
                            start_ms=self._sample_to_ms(start_sample),
                            end_ms=self._sample_to_ms(end_sample),
                            waveform=w,
                            sample_rate=self.sample_rate,
                            vad_state="segment_mid",
                            is_last=True,
                        )
                    )
                else:
                    if emitted_until_sample is None:
                        emitted_until_sample = speech_start_sample
                    start_sample = emitted_until_sample
                    w = self._slice_waveform(audio_waveform, start_sample, end_sample)
                    emitted.append(
                        AudioChunk(
                            stream_id=chunk.stream_id,
                            start_ms=-1,
                            end_ms=self._sample_to_ms(end_sample),
                            waveform=w,
                            sample_rate=self.sample_rate,
                            vad_state="segment_end",
                            is_last=True,
                        )
                    )
                emitted_until_sample = end_sample

            self.states.pop(chunk.stream_id, None)
            for item in emitted:
                yield item
            return

        state.update(
            {
                "buffer": buffer,
                "is_speaking": is_speaking,
                "speech_start_sample": speech_start_sample,
                "last_speech_sample": last_speech_sample,
                "silence_counter": silence_counter,
                "total_samples": total_samples,
                "emitted_until_sample": emitted_until_sample,
                "audio_waveform": audio_waveform,
                "pending_start": pending_start,
            }
        )
        self.states[chunk.stream_id] = state

        for item in emitted:
            yield item

    def _emit_segment(
        self,
        emitted: list[AudioChunk],
        stream_id: str,
        audio_waveform: Waveform,
        speech_start_sample: int,
        end_sample: int,
        pending_start: bool,
        emitted_until_sample: int | None,
    ) -> None:
        """Emit a completed speech segment."""
        if pending_start:
            # Whole segment captured within this batch.
            w = self._slice_waveform(audio_waveform, speech_start_sample, end_sample)
            emitted.append(
                AudioChunk(
                    stream_id=stream_id,
                    start_ms=self._sample_to_ms(speech_start_sample),
                    end_ms=self._sample_to_ms(end_sample),
                    waveform=w,
                    sample_rate=self.sample_rate,
                    vad_state="segment_mid",
                    is_last=True,
                )
            )
            return

        start_sample = (
            emitted_until_sample
            if emitted_until_sample is not None
            else speech_start_sample
        )
        w = self._slice_waveform(audio_waveform, start_sample, end_sample)
        emitted.append(
            AudioChunk(
                stream_id=stream_id,
                start_ms=-1,
                end_ms=self._sample_to_ms(end_sample),
                waveform=w,
                sample_rate=self.sample_rate,
                vad_state="segment_end",
                is_last=True,
            )
        )

    def _infer(self, window: np.ndarray) -> float:
        """Run a single Silero VAD window and return the speech probability."""
        if self.model is None:
            return 0.0
        audio_tensor = torch.from_numpy(window).float()
        if audio_tensor.dim() == 1:
            audio_tensor = audio_tensor.unsqueeze(0)
        if torch.cuda.is_available():
            audio_tensor = audio_tensor.cuda()
        with torch.no_grad():
            return self.model(audio_tensor, self.sample_rate).item()

    def _sample_to_ms(self, sample: int) -> int:
        return int(sample * 1000 // self.sample_rate)

    def _slice_waveform(
        self, waveform: Waveform, start_sample: int, end_sample: int
    ) -> Waveform:
        return waveform[start_sample:end_sample]

    def get_config(self) -> Config:
        return Config(
            data={
                "vad_model": {
                    "@vad_models": "stream_silero",
                    "threshold": self.threshold,
                    "silence_duration_ms": self.silence_duration_ms,
                    "sample_rate": self.sample_rate,
                    "chunk_size_ms": self.chunk_size_ms,
                }
            }
        )


@registry.vad_models.register("stream_silero")
def stream_silero_entrypoint(
    threshold: float = 0.5,
    silence_duration_ms: int = 400,
    sample_rate: int = 16000,
    chunk_size_ms: int = 32,
    **kwargs,
) -> SileroStreamVAD:
    return SileroStreamVAD(
        threshold=threshold,
        silence_duration_ms=silence_duration_ms,
        sample_rate=sample_rate,
        chunk_size_ms=chunk_size_ms,
        **kwargs,
    )
