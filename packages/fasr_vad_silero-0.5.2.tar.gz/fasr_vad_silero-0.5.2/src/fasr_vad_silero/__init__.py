from fasr_vad_silero.silero import SileroStreamVAD

__all__ = ["SileroStreamVAD"]
