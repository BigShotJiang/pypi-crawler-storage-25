"""
Tests for libunwind header and library support across all platforms.

This test suite verifies that:
- libunwind.h can be found and included
- unwind.h can be found and included
- -lunwind links successfully
- Executables run successfully with libunwind
- Platform-specific libunwind sources work correctly:
  * Linux: Bundled libunwind (headers + shared libraries)
  * Windows: MinGW sysroot libunwind
  * macOS: System libunwind

Platform-specific environment variables:
- CLANG_TOOL_CHAIN_NO_BUNDLED_UNWIND (Linux only) - disables bundled libunwind
"""

import os
import subprocess
import sys
from unittest.mock import patch

import pytest


class TestLibunwindHeaderDiscovery:
    """Test that libunwind headers can be found and compiled."""

    def test_libunwind_header_found(self, tmp_path):
        """Verify #include <libunwind.h> compiles successfully."""
        # Create a simple C file that includes libunwind.h
        source_file = tmp_path / "test_libunwind.c"
        source_file.write_text("""
// UNW_LOCAL_ONLY must be defined before including libunwind.h
// to use local unwinding symbols (_ULx86_64_*) instead of
// remote unwinding symbols (_Ux86_64_*) which require libunwind-ptrace
#define UNW_LOCAL_ONLY
#include <libunwind.h>

int main() {
    unw_cursor_t cursor;
    unw_context_t context;
    (void)cursor;
    (void)context;
    return 0;
}
""")

        output_file = tmp_path / "test_libunwind"

        # Try to compile - this will skip if libunwind headers not available
        try:
            result = subprocess.run(
                ["clang-tool-chain-c", str(source_file), "-c", "-o", str(output_file) + ".o"],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode != 0:
                # Check if it's because libunwind.h is not found
                if "libunwind.h" in result.stderr and "not found" in result.stderr.lower():
                    pytest.skip("libunwind.h not bundled (archive rebuild needed)")
                # Other compilation error
                pytest.fail(f"Compilation failed: {result.stderr}")

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")

    def test_unwind_h_found(self, tmp_path):
        """Verify #include <unwind.h> compiles successfully."""
        # Create a simple C file that includes unwind.h
        source_file = tmp_path / "test_unwind.c"
        source_file.write_text("""
#include <unwind.h>

int main() {
    return 0;
}
""")

        output_file = tmp_path / "test_unwind.o"

        try:
            result = subprocess.run(
                ["clang-tool-chain-c", str(source_file), "-c", "-o", str(output_file)],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode != 0:
                if "unwind.h" in result.stderr and "not found" in result.stderr.lower():
                    pytest.skip("unwind.h not bundled (archive rebuild needed)")
                pytest.fail(f"Compilation failed: {result.stderr}")

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")


class TestLibunwindLinking:
    """Test that libunwind can be linked."""

    def test_libunwind_links(self, tmp_path):
        """Verify -lunwind links successfully on all platforms."""
        # Create a simple C file that uses libunwind
        source_file = tmp_path / "test_link.c"
        source_file.write_text("""
#include <stdio.h>

// Forward declare libunwind functions
extern int unw_getcontext(void *);
extern int unw_init_local(void *, void *);

int main() {
    printf("Linked with libunwind\\n");
    return 0;
}
""")

        output_file = tmp_path / "test_link"
        if sys.platform == "win32":
            output_file = tmp_path / "test_link.exe"

        try:
            result = subprocess.run(
                ["clang-tool-chain-c", str(source_file), "-lunwind", "-o", str(output_file)],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if result.returncode != 0:
                if "cannot find -lunwind" in result.stderr or "libunwind" in result.stderr:
                    pytest.skip("libunwind library not available (archive rebuild needed)")
                pytest.fail(f"Linking failed: {result.stderr}")

            # Verify executable was created
            assert output_file.exists(), "Executable should be created"

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")

    def test_libunwind_runtime(self, tmp_path):
        """Verify executable runs successfully with libunwind on all platforms."""
        # Create a simple program that uses libunwind
        source_file = tmp_path / "test_runtime.c"
        source_file.write_text("""
#include <stdio.h>
// UNW_LOCAL_ONLY must be defined before including libunwind.h
// to use local unwinding symbols (_ULx86_64_*) instead of
// remote unwinding symbols (_Ux86_64_*) which require libunwind-ptrace
#define UNW_LOCAL_ONLY
#include <libunwind.h>

int main() {
    unw_context_t context;
    unw_cursor_t cursor;

    // Initialize libunwind
    if (unw_getcontext(&context) != 0) {
        printf("unw_getcontext failed\\n");
        return 1;
    }

    if (unw_init_local(&cursor, &context) != 0) {
        printf("unw_init_local failed\\n");
        return 1;
    }

    printf("libunwind works!\\n");
    return 0;
}
""")

        output_file = tmp_path / "test_runtime"
        if sys.platform == "win32":
            output_file = tmp_path / "test_runtime.exe"

        try:
            # Compile with -lunwind
            compile_result = subprocess.run(
                ["clang-tool-chain-c", str(source_file), "-lunwind", "-o", str(output_file)],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if compile_result.returncode != 0:
                if "libunwind.h" in compile_result.stderr or "cannot find -lunwind" in compile_result.stderr:
                    pytest.skip("libunwind not available (archive rebuild needed)")
                pytest.fail(f"Compilation failed: {compile_result.stderr}")

            # Run the executable
            # Platform-specific environment setup:
            # - Linux: Remove LD_LIBRARY_PATH to verify bundled libunwind rpath works
            # - Windows: Clean environment (MinGW sysroot should work automatically)
            # - macOS: Clean environment (system libunwind should work)
            env = os.environ.copy()
            if sys.platform == "linux":
                env.pop("LD_LIBRARY_PATH", None)  # Verify bundled rpath works
            elif sys.platform == "win32":
                # Windows may need PATH for MinGW DLLs, so don't remove it
                pass
            elif sys.platform == "darwin":
                env.pop("DYLD_LIBRARY_PATH", None)  # macOS uses system libunwind

            run_result = subprocess.run(
                [str(output_file)],
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
            )

            if run_result.returncode != 0:
                if "libunwind" in run_result.stderr.lower():
                    pytest.fail(
                        f"Executable failed to find libunwind at runtime.\n"
                        f"Platform: {sys.platform}\n"
                        f"stderr: {run_result.stderr}\n"
                        f"stdout: {run_result.stdout}"
                    )
                pytest.fail(f"Executable failed: {run_result.stderr}\nstdout: {run_result.stdout}")

            assert "libunwind works!" in run_result.stdout

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")


class TestLibunwindBacktrace:
    """Test libunwind backtracing functionality on all platforms.

    These tests verify that libunwind can generate accurate stack traces.
    This is critical for debugging, profiling, and crash analysis.

    Platform support:
    - Linux: Uses bundled libunwind
    - Windows: Uses MinGW sysroot libunwind
    - macOS: Uses system libunwind
    """

    def test_libunwind_backtrace_basic(self, tmp_path):
        """Test basic backtrace generation with libunwind on all platforms."""
        source_file = tmp_path / "test_backtrace.c"
        source_file.write_text("""
#define UNW_LOCAL_ONLY
#include <libunwind.h>
#include <stdio.h>
#include <stdlib.h>

void print_backtrace() {
    unw_cursor_t cursor;
    unw_context_t context;
    int frame_count = 0;

    // Initialize context
    if (unw_getcontext(&context) != 0) {
        fprintf(stderr, "unw_getcontext failed\\n");
        exit(1);
    }

    // Initialize cursor
    if (unw_init_local(&cursor, &context) != 0) {
        fprintf(stderr, "unw_init_local failed\\n");
        exit(1);
    }

    // Walk the stack
    printf("BACKTRACE_START\\n");
    while (unw_step(&cursor) > 0) {
        unw_word_t offset, pc;
        char fname[256];

        unw_get_reg(&cursor, UNW_REG_IP, &pc);
        if (pc == 0) break;

        fname[0] = '\\0';
        unw_get_proc_name(&cursor, fname, sizeof(fname), &offset);

        printf("FRAME %d: %s+0x%lx [0x%lx]\\n",
               frame_count, fname[0] ? fname : "??", (unsigned long)offset, (unsigned long)pc);
        frame_count++;

        if (frame_count > 20) break;  // Safety limit
    }
    printf("BACKTRACE_END\\n");
    printf("Total frames: %d\\n", frame_count);
}

void level3() {
    print_backtrace();
}

void level2() {
    level3();
}

void level1() {
    level2();
}

int main() {
    printf("Testing libunwind backtrace...\\n");
    level1();
    printf("SUCCESS\\n");
    return 0;
}
""")

        output_file = tmp_path / "test_backtrace"
        if sys.platform == "win32":
            output_file = tmp_path / "test_backtrace.exe"

        try:
            # Compile with debug info for better symbol resolution
            compile_result = subprocess.run(
                [
                    "clang-tool-chain-c",
                    "-g",
                    "-O0",
                    "-fno-omit-frame-pointer",
                    str(source_file),
                    "-lunwind",
                    "-o",
                    str(output_file),
                ],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if compile_result.returncode != 0:
                if "libunwind.h" in compile_result.stderr or "cannot find -lunwind" in compile_result.stderr:
                    pytest.skip("libunwind not available (archive rebuild needed)")
                pytest.fail(f"Compilation failed: {compile_result.stderr}")

            # Run with clean environment (platform-appropriate)
            env = os.environ.copy()
            if sys.platform == "linux":
                env.pop("LD_LIBRARY_PATH", None)
            elif sys.platform == "darwin":
                env.pop("DYLD_LIBRARY_PATH", None)

            run_result = subprocess.run(
                [str(output_file)],
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
            )

            if run_result.returncode != 0:
                pytest.fail(f"Execution failed: {run_result.stderr}\nstdout: {run_result.stdout}")

            # Verify output
            output = run_result.stdout
            assert "SUCCESS" in output, f"Program did not complete successfully: {output}"
            assert "BACKTRACE_START" in output, f"Backtrace did not start: {output}"
            assert "BACKTRACE_END" in output, f"Backtrace did not complete: {output}"

            # Check that we got multiple frames
            frame_lines = [line for line in output.split("\n") if line.startswith("FRAME")]
            assert len(frame_lines) >= 3, f"Expected at least 3 frames, got {len(frame_lines)}: {output}"

            # Verify function names are resolved (nice to have, not required)
            functions_found = []
            for line in frame_lines:
                for func in ["print_backtrace", "level3", "level2", "level1", "main"]:
                    if func in line:
                        functions_found.append(func)

            # Note: Symbol resolution quality depends on debug symbols and libunwind version.
            # On some systems/configs (especially Windows), symbols may not be resolved at all.
            # The key test is that stack walking works (multiple frames) - symbol resolution is a bonus.
            # We log whether symbols were resolved but don't fail the test if they weren't.
            if len(functions_found) >= 1:
                print(f"✓ Symbol resolution working: {functions_found}")
            else:
                print(f"ℹ Symbol resolution not available (expected on some platforms): {output}")

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")

    def test_libunwind_backtrace_deep_stack(self, tmp_path):
        """Test backtrace with a deeper call stack (10 levels)."""
        source_file = tmp_path / "test_deep_backtrace.c"
        source_file.write_text("""
#define UNW_LOCAL_ONLY
#include <libunwind.h>
#include <stdio.h>
#include <stdlib.h>

int count_frames() {
    unw_cursor_t cursor;
    unw_context_t context;
    int frame_count = 0;

    if (unw_getcontext(&context) != 0) return -1;
    if (unw_init_local(&cursor, &context) != 0) return -1;

    while (unw_step(&cursor) > 0 && frame_count < 50) {
        frame_count++;
    }
    return frame_count;
}

// Create 10 levels of function calls
void level10() { printf("Frame count at level10: %d\\n", count_frames()); }
void level9() { level10(); }
void level8() { level9(); }
void level7() { level8(); }
void level6() { level7(); }
void level5() { level6(); }
void level4() { level5(); }
void level3() { level4(); }
void level2() { level3(); }
void level1() { level2(); }

int main() {
    printf("Testing deep backtrace...\\n");
    level1();
    printf("SUCCESS\\n");
    return 0;
}
""")

        output_file = tmp_path / "test_deep_backtrace"
        if sys.platform == "win32":
            output_file = tmp_path / "test_deep_backtrace.exe"

        try:
            compile_result = subprocess.run(
                [
                    "clang-tool-chain-c",
                    "-g",
                    "-O0",
                    "-fno-omit-frame-pointer",
                    str(source_file),
                    "-lunwind",
                    "-o",
                    str(output_file),
                ],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if compile_result.returncode != 0:
                if "libunwind.h" in compile_result.stderr or "cannot find -lunwind" in compile_result.stderr:
                    pytest.skip("libunwind not available (archive rebuild needed)")
                pytest.fail(f"Compilation failed: {compile_result.stderr}")

            env = os.environ.copy()
            if sys.platform == "linux":
                env.pop("LD_LIBRARY_PATH", None)
            elif sys.platform == "darwin":
                env.pop("DYLD_LIBRARY_PATH", None)

            run_result = subprocess.run(
                [str(output_file)],
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
            )

            if run_result.returncode != 0:
                pytest.fail(f"Execution failed: {run_result.stderr}")

            output = run_result.stdout
            assert "SUCCESS" in output, f"Program did not complete: {output}"

            # Extract frame count from output
            # Expected format: "Frame count at level10: N"
            import re

            match = re.search(r"Frame count at level10: (\d+)", output)
            assert match, f"Could not find frame count in output: {output}"

            frame_count = int(match.group(1))
            # Should have at least 10 user frames (level1-10) + count_frames + main
            assert frame_count >= 10, f"Expected at least 10 frames, got {frame_count}: {output}"

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")

    def test_libunwind_cpp_exception_backtrace(self, tmp_path):
        """Test that libunwind works with C++ exception handling."""
        source_file = tmp_path / "test_cpp_unwind.cpp"
        source_file.write_text("""
#define UNW_LOCAL_ONLY
#include <libunwind.h>
#include <iostream>
#include <stdexcept>

int count_frames() {
    unw_cursor_t cursor;
    unw_context_t context;
    int frame_count = 0;

    if (unw_getcontext(&context) != 0) return -1;
    if (unw_init_local(&cursor, &context) != 0) return -1;

    while (unw_step(&cursor) > 0 && frame_count < 50) {
        frame_count++;
    }
    return frame_count;
}

void throw_and_catch() {
    try {
        throw std::runtime_error("test exception");
    } catch (const std::exception& e) {
        std::cout << "Caught: " << e.what() << std::endl;
        std::cout << "Frame count in catch: " << count_frames() << std::endl;
    }
}

int main() {
    std::cout << "Testing C++ exception + libunwind..." << std::endl;
    throw_and_catch();
    std::cout << "SUCCESS" << std::endl;
    return 0;
}
""")

        output_file = tmp_path / "test_cpp_unwind"
        if sys.platform == "win32":
            output_file = tmp_path / "test_cpp_unwind.exe"

        try:
            compile_result = subprocess.run(
                [
                    "clang-tool-chain-cpp",
                    "-g",
                    "-O0",
                    "-fno-omit-frame-pointer",
                    str(source_file),
                    "-lunwind",
                    "-o",
                    str(output_file),
                ],
                capture_output=True,
                text=True,
                timeout=60,
            )

            if compile_result.returncode != 0:
                if "libunwind.h" in compile_result.stderr or "cannot find -lunwind" in compile_result.stderr:
                    pytest.skip("libunwind not available (archive rebuild needed)")
                pytest.fail(f"Compilation failed: {compile_result.stderr}")

            env = os.environ.copy()
            if sys.platform == "linux":
                env.pop("LD_LIBRARY_PATH", None)
            elif sys.platform == "darwin":
                env.pop("DYLD_LIBRARY_PATH", None)

            run_result = subprocess.run(
                [str(output_file)],
                capture_output=True,
                text=True,
                timeout=30,
                env=env,
            )

            if run_result.returncode != 0:
                pytest.fail(f"Execution failed: {run_result.stderr}")

            output = run_result.stdout
            assert "SUCCESS" in output, f"Program did not complete: {output}"
            assert "Caught: test exception" in output, f"Exception not caught: {output}"

            # Verify frame counting worked in catch block
            import re

            match = re.search(r"Frame count in catch: (\d+)", output)
            assert match, f"Could not find frame count: {output}"
            frame_count = int(match.group(1))
            assert frame_count >= 2, f"Expected at least 2 frames in catch, got {frame_count}"

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-cpp not installed")

    def test_libunwind_no_system_dependency(self, tmp_path):
        """Verify that compilation doesn't use system libunwind headers.

        This test checks that the include path points to the bundled libunwind,
        not system /usr/include/libunwind.h
        """
        source_file = tmp_path / "test_include_path.c"
        source_file.write_text("""
#include <stdio.h>

// This will show which libunwind.h is being used
#ifdef __has_include
#if __has_include(<libunwind.h>)
#include <libunwind.h>
#define HAS_LIBUNWIND 1
#endif
#endif

int main() {
#ifdef HAS_LIBUNWIND
    printf("libunwind.h found\\n");
#else
    printf("libunwind.h NOT found\\n");
#endif
    return 0;
}
""")

        try:
            # Compile with -v to see include paths
            compile_result = subprocess.run(
                ["clang-tool-chain-c", "-v", "-c", str(source_file), "-o", "/dev/null"],
                capture_output=True,
                text=True,
                timeout=60,
            )

            # The -I flag for bundled libunwind should appear in verbose output
            verbose_output = compile_result.stderr

            # Check if bundled include path is present
            # Should contain something like: -I/home/user/.clang-tool-chain/clang/.../include
            if "clang-tool-chain" in verbose_output and "/include" in verbose_output:
                # Good - using bundled path
                pass
            elif "/usr/include" in verbose_output and "libunwind" not in compile_result.stderr.lower():
                # If we're using system includes, that's also OK if libunwind isn't there
                pass

            # The key test is that compilation succeeds when libunwind is bundled
            if compile_result.returncode != 0 and "libunwind.h" in compile_result.stderr:
                pytest.skip("libunwind not bundled")

        except FileNotFoundError:
            pytest.skip("clang-tool-chain-c not installed")


@pytest.mark.skipif(sys.platform != "linux", reason="Linux-specific bundled libunwind tests")
class TestLibunwindOptOut:
    """Test CLANG_TOOL_CHAIN_NO_BUNDLED_UNWIND environment variable (Linux only).

    This tests the Linux-specific bundled libunwind feature which allows users
    to opt-out of the bundled libunwind and use system libunwind instead.
    """

    def test_opt_out_env_var(self):
        """Verify CLANG_TOOL_CHAIN_NO_BUNDLED_UNWIND disables bundled libunwind."""
        from clang_tool_chain.execution.arg_transformers import (
            LinuxUnwindTransformer,
            ToolContext,
        )

        transformer = LinuxUnwindTransformer()
        context = ToolContext(
            platform_name="linux",
            arch="x86_64",
            tool_name="clang",
            use_msvc=False,
        )

        # With opt-out disabled, should add paths (if libunwind exists)
        with patch.dict(os.environ, {}, clear=False):
            # Remove opt-out if set
            os.environ.pop("CLANG_TOOL_CHAIN_NO_BUNDLED_UNWIND", None)
            os.environ.pop("CLANG_TOOL_CHAIN_NO_AUTO", None)

            # May or may not add paths depending on whether libunwind.h exists
            _ = transformer.transform(["test.c"], context)

        # With opt-out enabled, should NOT add paths
        with patch.dict(os.environ, {"CLANG_TOOL_CHAIN_NO_BUNDLED_UNWIND": "1"}):
            result2 = transformer.transform(["test.c"], context)

        # With opt-out, result should be unchanged
        assert result2 == ["test.c"], "With opt-out, args should be unchanged"

    def test_no_auto_disables_bundled_unwind(self):
        """Verify CLANG_TOOL_CHAIN_NO_AUTO also disables bundled libunwind."""
        from clang_tool_chain.execution.arg_transformers import (
            LinuxUnwindTransformer,
            ToolContext,
        )

        transformer = LinuxUnwindTransformer()
        context = ToolContext(
            platform_name="linux",
            arch="x86_64",
            tool_name="clang",
            use_msvc=False,
        )

        # With NO_AUTO enabled, should NOT add paths
        with patch.dict(os.environ, {"CLANG_TOOL_CHAIN_NO_AUTO": "1"}):
            result = transformer.transform(["test.c"], context)

        # With opt-out, result should be unchanged
        assert result == ["test.c"], "With NO_AUTO, args should be unchanged"


@pytest.mark.skipif(sys.platform != "linux", reason="Linux-specific bundled libunwind tests")
class TestLinuxUnwindTransformer:
    """Unit tests for LinuxUnwindTransformer class (Linux only).

    This tests the Linux-specific bundled libunwind transformer that automatically
    adds -I and -L flags for bundled libunwind headers and libraries.
    """

    def test_priority(self):
        """Test transformer priority is 150."""
        from clang_tool_chain.execution.arg_transformers import LinuxUnwindTransformer

        transformer = LinuxUnwindTransformer()
        assert transformer.priority() == 150

    def test_skips_non_linux(self):
        """Test transformer skips non-Linux platforms."""
        from clang_tool_chain.execution.arg_transformers import (
            LinuxUnwindTransformer,
            ToolContext,
        )

        transformer = LinuxUnwindTransformer()

        # Test Windows
        context_win = ToolContext("win", "x86_64", "clang", False)
        result = transformer.transform(["test.c"], context_win)
        assert result == ["test.c"], "Should skip Windows"

        # Test macOS
        context_mac = ToolContext("darwin", "x86_64", "clang", False)
        result = transformer.transform(["test.c"], context_mac)
        assert result == ["test.c"], "Should skip macOS"

    def test_skips_non_clang_tools(self):
        """Test transformer skips non-clang tools."""
        from clang_tool_chain.execution.arg_transformers import (
            LinuxUnwindTransformer,
            ToolContext,
        )

        transformer = LinuxUnwindTransformer()

        # Test llvm-ar
        context = ToolContext("linux", "x86_64", "llvm-ar", False)
        result = transformer.transform(["test.a"], context)
        assert result == ["test.a"], "Should skip llvm-ar"

        # Test llvm-nm
        context = ToolContext("linux", "x86_64", "llvm-nm", False)
        result = transformer.transform(["test.o"], context)
        assert result == ["test.o"], "Should skip llvm-nm"

    def test_applies_to_clang(self):
        """Test transformer applies to clang on Linux."""
        from clang_tool_chain.execution.arg_transformers import (
            LinuxUnwindTransformer,
            ToolContext,
        )

        transformer = LinuxUnwindTransformer()
        context = ToolContext("linux", "x86_64", "clang", False)

        # Note: Result may or may not change depending on whether
        # bundled libunwind exists. We just verify it doesn't crash.
        result = transformer.transform(["test.c"], context)
        assert isinstance(result, list)

    def test_applies_to_clang_plus_plus(self):
        """Test transformer applies to clang++ on Linux."""
        from clang_tool_chain.execution.arg_transformers import (
            LinuxUnwindTransformer,
            ToolContext,
        )

        transformer = LinuxUnwindTransformer()
        context = ToolContext("linux", "x86_64", "clang++", False)

        result = transformer.transform(["test.cpp"], context)
        assert isinstance(result, list)


@pytest.mark.skipif(sys.platform != "linux", reason="Linux-specific .so deployment tests")
class TestSoDeployerLibunwind:
    """Test that so_deployer correctly handles libunwind libraries (Linux only).

    This tests the Linux-specific shared library deployment feature for libunwind.
    """

    def test_libunwind_is_deployable(self):
        """Test that libunwind libraries are recognized as deployable."""
        from clang_tool_chain.deployment.so_deployer import SoDeployer

        deployer = SoDeployer()

        # Main libunwind
        assert deployer.is_deployable_library("libunwind.so.8")
        assert deployer.is_deployable_library("libunwind.so.8.0.1")
        assert deployer.is_deployable_library("libunwind.so.1")

        # Platform-specific libunwind
        assert deployer.is_deployable_library("libunwind-x86_64.so.8")
        assert deployer.is_deployable_library("libunwind-x86_64.so.8.0.1")
        assert deployer.is_deployable_library("libunwind-aarch64.so.8")

    def test_system_libraries_not_deployable(self):
        """Test that system libraries are NOT deployable."""
        from clang_tool_chain.deployment.so_deployer import SoDeployer

        deployer = SoDeployer()

        # System libraries should NOT be deployable
        assert not deployer.is_deployable_library("libc.so.6")
        assert not deployer.is_deployable_library("libm.so.6")
        assert not deployer.is_deployable_library("libpthread.so.0")
        assert not deployer.is_deployable_library("ld-linux-x86-64.so.2")


@pytest.mark.skipif(sys.platform != "linux", reason="Linux-specific libunwind symlink tests")
class TestLibunwindSymlinkCreation:
    """Test that versioned libunwind SO symlinks are created correctly.

    The bundled Linux archive ships fully-versioned SO files (e.g.
    libunwind.so.8.0.1) but not the soname (libunwind.so.8) or the
    unversioned dev symlink (libunwind.so) needed by the linker.
    These tests verify that the helper creates the full chain.
    """

    def test_create_versioned_so_symlinks_basic(self, tmp_path):
        """Verify symlink chain is created for a basic versioned SO."""
        from clang_tool_chain.installers.clang import _create_versioned_so_symlinks

        # Create a fake versioned SO file
        (tmp_path / "libunwind.so.8.0.1").write_bytes(b"fake")

        _create_versioned_so_symlinks(tmp_path, prefix="libunwind")

        soname_link = tmp_path / "libunwind.so.8"
        dev_link = tmp_path / "libunwind.so"

        assert soname_link.is_symlink(), "libunwind.so.8 symlink should be created"
        assert dev_link.is_symlink(), "libunwind.so symlink should be created"
        assert os.readlink(str(soname_link)) == "libunwind.so.8.0.1"
        assert os.readlink(str(dev_link)) == "libunwind.so.8"

    def test_create_versioned_so_symlinks_arch_specific(self, tmp_path):
        """Verify symlinks are created for arch-specific libunwind SO."""
        from clang_tool_chain.installers.clang import _create_versioned_so_symlinks

        (tmp_path / "libunwind-x86_64.so.8.0.1").write_bytes(b"fake")

        _create_versioned_so_symlinks(tmp_path, prefix="libunwind")

        soname_link = tmp_path / "libunwind-x86_64.so.8"
        dev_link = tmp_path / "libunwind-x86_64.so"

        assert soname_link.is_symlink()
        assert dev_link.is_symlink()
        assert os.readlink(str(soname_link)) == "libunwind-x86_64.so.8.0.1"
        assert os.readlink(str(dev_link)) == "libunwind-x86_64.so.8"

    def test_create_versioned_so_symlinks_idempotent(self, tmp_path):
        """Verify repeated calls do not raise errors or overwrite existing symlinks."""
        from clang_tool_chain.installers.clang import _create_versioned_so_symlinks

        (tmp_path / "libunwind.so.8.0.1").write_bytes(b"fake")

        # Call twice — should not raise
        _create_versioned_so_symlinks(tmp_path, prefix="libunwind")
        _create_versioned_so_symlinks(tmp_path, prefix="libunwind")

        assert (tmp_path / "libunwind.so").is_symlink()
        assert (tmp_path / "libunwind.so.8").is_symlink()

    def test_create_versioned_so_symlinks_missing_dir(self, tmp_path):
        """Verify function silently skips missing directories."""
        from clang_tool_chain.installers.clang import _create_versioned_so_symlinks

        missing = tmp_path / "nonexistent"
        # Should not raise
        _create_versioned_so_symlinks(missing, prefix="libunwind")

    def test_installed_toolchain_has_libunwind_dev_symlinks(self):
        """Verify the installed toolchain lib directory has libunwind.so dev symlinks."""
        try:
            from clang_tool_chain.platform.detection import get_platform_binary_dir

            clang_bin = get_platform_binary_dir()
        except Exception:
            pytest.skip("Clang toolchain not installed")

        lib_dir = clang_bin.parent / "lib"
        libunwind_so = lib_dir / "libunwind.so"
        libunwind_so8 = lib_dir / "libunwind.so.8"
        versioned = lib_dir / "libunwind.so.8.0.1"

        if not versioned.exists():
            pytest.skip("libunwind.so.8.0.1 not found in toolchain lib (archive rebuild needed)")

        assert libunwind_so8.is_symlink() or libunwind_so8.is_file(), (
            "libunwind.so.8 must exist as symlink or file so -lunwind can be resolved"
        )
        assert libunwind_so.is_symlink() or libunwind_so.is_file(), (
            "libunwind.so dev-symlink must exist so the linker can resolve -lunwind"
        )


@pytest.mark.skipif(sys.platform != "darwin", reason="macOS-specific libunwind tests")
class TestMacOSUnwindTransformer:
    """Unit tests for MacOSUnwindTransformer class (macOS only).

    This tests the macOS-specific libunwind transformer that removes the -lunwind
    flag since macOS provides libunwind via libSystem (automatically linked).
    """

    def test_priority(self):
        """Test transformer priority is 125."""
        from clang_tool_chain.execution.arg_transformers import MacOSUnwindTransformer

        transformer = MacOSUnwindTransformer()
        assert transformer.priority() == 125

    def test_removes_lunwind_on_macos(self):
        """Test that -lunwind is removed on macOS."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()
        context = ToolContext("darwin", "arm64", "clang", False)

        # With -lunwind present
        args = ["test.c", "-lunwind", "-o", "test"]
        result = transformer.transform(args, context)

        assert "-lunwind" not in result
        assert "test.c" in result
        assert "-o" in result
        assert "test" in result

    def test_preserves_other_args(self):
        """Test that other args are preserved when -lunwind is removed."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()
        context = ToolContext("darwin", "x86_64", "clang++", False)

        args = ["-g", "-O2", "test.cpp", "-lunwind", "-lpthread", "-o", "test"]
        result = transformer.transform(args, context)

        assert "-lunwind" not in result
        assert "-g" in result
        assert "-O2" in result
        assert "-lpthread" in result

    def test_no_change_without_lunwind(self):
        """Test that args are unchanged when -lunwind is not present."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()
        context = ToolContext("darwin", "arm64", "clang", False)

        args = ["test.c", "-o", "test"]
        result = transformer.transform(args, context)

        assert result == args

    def test_skips_non_macos(self):
        """Test transformer skips non-macOS platforms."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()

        # Test Linux - should NOT remove -lunwind
        context_linux = ToolContext("linux", "x86_64", "clang", False)
        args = ["test.c", "-lunwind", "-o", "test"]
        result = transformer.transform(args, context_linux)
        assert "-lunwind" in result, "Should NOT remove -lunwind on Linux"

        # Test Windows - should NOT remove -lunwind
        context_win = ToolContext("win", "x86_64", "clang", False)
        result = transformer.transform(args, context_win)
        assert "-lunwind" in result, "Should NOT remove -lunwind on Windows"

    def test_skips_non_clang_tools(self):
        """Test transformer skips non-clang tools."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()

        # Test llvm-ar
        context = ToolContext("darwin", "arm64", "llvm-ar", False)
        args = ["test.a", "-lunwind"]
        result = transformer.transform(args, context)
        assert result == args, "Should skip llvm-ar"

    def test_opt_out_env_var(self):
        """Verify CLANG_TOOL_CHAIN_NO_MACOS_UNWIND_FIX disables the transformer."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()
        context = ToolContext("darwin", "arm64", "clang", False)
        args = ["test.c", "-lunwind", "-o", "test"]

        # With opt-out enabled, should NOT remove -lunwind
        with patch.dict(os.environ, {"CLANG_TOOL_CHAIN_NO_MACOS_UNWIND_FIX": "1"}):
            result = transformer.transform(args, context)

        assert "-lunwind" in result, "With opt-out, -lunwind should be preserved"

    def test_no_auto_disables_transformer(self):
        """Verify CLANG_TOOL_CHAIN_NO_AUTO also disables the transformer."""
        from clang_tool_chain.execution.arg_transformers import (
            MacOSUnwindTransformer,
            ToolContext,
        )

        transformer = MacOSUnwindTransformer()
        context = ToolContext("darwin", "arm64", "clang", False)
        args = ["test.c", "-lunwind", "-o", "test"]

        # With NO_AUTO enabled, should NOT remove -lunwind
        with patch.dict(os.environ, {"CLANG_TOOL_CHAIN_NO_AUTO": "1"}):
            result = transformer.transform(args, context)

        assert "-lunwind" in result, "With NO_AUTO, -lunwind should be preserved"
