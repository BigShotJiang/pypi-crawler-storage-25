"""Tests for VynFi resource modules."""

from __future__ import annotations

import httpx
import respx

from vynfi import VynFi

BASE = "https://api.vynfi.com"


# ── Jobs ──────────────────────────────────────────────────────────────────────


@respx.mock
def test_generate_job() -> None:
    respx.post(f"{BASE}/v1/generate").mock(
        return_value=httpx.Response(
            202,
            json={
                "id": "job-123",
                "status": "queued",
                "credits_reserved": 500,
                "estimated_duration_seconds": 5,
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    job = client.generate(tables=[{"name": "journal_entries", "rows": 500}])
    assert job.id == "job-123"
    assert job.status == "queued"
    assert job.credits_reserved == 500


@respx.mock
def test_generate_config() -> None:
    respx.post(f"{BASE}/v1/generate").mock(
        return_value=httpx.Response(
            202,
            json={"id": "job-456", "status": "queued", "credits_reserved": 100},
        )
    )
    client = VynFi(api_key="vf_test_abc")
    job = client.jobs.generate_config(config={"sector": "retail", "rows": 100})
    assert job.id == "job-456"


@respx.mock
def test_generate_quick() -> None:
    respx.post(f"{BASE}/v1/generate/quick").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "qj-1",
                "status": "completed",
                "credits_used": 10,
                "rows_generated": 100,
                "download_url": "https://example.com/dl",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.generate_quick(tables=[{"name": "journal_entries", "rows": 100}])
    assert result.id == "qj-1"
    assert result.credits_used == 10
    assert result.download_url == "https://example.com/dl"


@respx.mock
def test_list_jobs_data_wrapper() -> None:
    respx.get(f"{BASE}/v1/jobs").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {"id": "j1", "status": "completed"},
                    {"id": "j2", "status": "running"},
                ]
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.jobs.list()
    assert len(result.data) == 2
    assert result.data[0].id == "j1"


@respx.mock
def test_list_jobs_array_response() -> None:
    respx.get(f"{BASE}/v1/jobs").mock(
        return_value=httpx.Response(
            200,
            json=[
                {"id": "j1", "status": "completed"},
                {"id": "j2", "status": "running"},
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.jobs.list()
    assert len(result.data) == 2


@respx.mock
def test_get_job() -> None:
    respx.get(f"{BASE}/v1/jobs/j1").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "j1",
                "owner_id": "user-1",
                "status": "completed",
                "credits_reserved": 15,
                "credits_used": 15,
                "artifacts": [{"path": "journal_entries.json", "size": 1024}],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    job = client.jobs.get("j1")
    assert job.status == "completed"
    assert job.owner_id == "user-1"
    assert job.artifacts is not None


@respx.mock
def test_cancel_job() -> None:
    respx.delete(f"{BASE}/v1/jobs/j1").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "j1",
                "status": "cancelled",
                "credits_reserved": 100,
                "credits_used": 0,
                "credits_refunded": 100,
                "rows_generated": 0,
                "rows_total": 1000,
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.jobs.cancel("j1")
    assert result.status == "cancelled"
    assert result.credits_refunded == 100


@respx.mock
def test_download_file() -> None:
    respx.get(f"{BASE}/v1/jobs/j1/download/journal_entries.json").mock(
        return_value=httpx.Response(200, content=b'[{"amount": 100}]')
    )
    client = VynFi(api_key="vf_test_abc")
    data = client.jobs.download_file("j1", "journal_entries.json")
    assert b"amount" in data


@respx.mock
def test_analytics() -> None:
    respx.get(f"{BASE}/v1/jobs/j1/analytics").mock(
        return_value=httpx.Response(
            200,
            json={
                "benford_analysis": {
                    "sample_size": 10000,
                    "observed_frequencies": [
                        0.301,
                        0.176,
                        0.124,
                        0.097,
                        0.079,
                        0.067,
                        0.058,
                        0.051,
                        0.046,
                    ],
                    "observed_counts": [3010, 1760, 1240, 970, 790, 670, 580, 510, 460],
                    "expected_frequencies": [
                        0.301,
                        0.176,
                        0.124,
                        0.097,
                        0.079,
                        0.067,
                        0.058,
                        0.051,
                        0.046,
                    ],
                    "chi_squared": 5.2,
                    "degrees_of_freedom": 8,
                    "p_value": 0.74,
                    "mad": 0.004,
                    "conformity": "Close",
                    "max_deviation": [1, 0.001],
                    "passes": True,
                    "anti_benford_score": 0.01,
                },
                "amount_distribution": {
                    "sample_size": 10000,
                    "mean": "1234.56",
                    "median": "1100.00",
                    "std_dev": "345.67",
                    "min": "10.00",
                    "max": "9999.99",
                    "percentile_1": "50.00",
                    "percentile_99": "8900.00",
                    "skewness": 0.832,
                    "kurtosis": 1.245,
                    "round_number_ratio": 0.45,
                    "nice_number_ratio": 0.78,
                    "passes": True,
                },
                "process_variant_summary": {
                    "variant_count": 5,
                    "total_cases": 1000,
                    "variant_entropy": 1.456,
                    "happy_path_concentration": 0.65,
                    "top_variants": [["A->B->C", 0.65], ["A->B->D->C", 0.30]],
                    "passes": True,
                    "issues": [],
                },
                "banking_evaluation": {
                    "kyc": {
                        "core_field_rate": 0.95,
                        "name_rate": 0.98,
                        "dob_rate": 0.95,
                        "address_rate": 0.93,
                        "id_document_rate": 0.95,
                        "risk_rating_rate": 0.96,
                        "beneficial_owner_rate": 0.91,
                        "verification_rate": 0.87,
                        "total_profiles": 500,
                        "passes": True,
                        "issues": [],
                    },
                    "passes": True,
                    "issues": [],
                },
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    a = client.jobs.analytics("j1")
    assert a.benford_analysis is not None
    assert a.benford_analysis.sample_size == 10000
    assert a.benford_analysis.passes is True
    assert a.amount_distribution is not None
    assert a.amount_distribution.skewness == 0.832
    assert a.process_variant_summary is not None
    assert a.process_variant_summary.variant_count == 5
    assert a.banking_evaluation is not None
    assert a.banking_evaluation.kyc is not None
    assert a.banking_evaluation.kyc.total_profiles == 500


@respx.mock
def test_estimate_size() -> None:
    # API returns camelCase
    respx.post(f"{BASE}/v1/configs/estimate-size").mock(
        return_value=httpx.Response(
            200,
            json={
                "estimatedBytes": 5000000000,
                "estimatedFiles": 85,
                "tierQuotaBytes": 10737418240,
                "exceedsQuota": False,
                "warning": None,
                "breakdown": [
                    {"domain": "core_journal_entries", "bytes": 2000000000},
                    {"domain": "banking", "bytes": 3000000000},
                ],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.configs.estimate_size(config={"sector": "retail", "rows": 1000})
    assert result.estimated_bytes == 5000000000
    assert result.estimated_files == 85
    assert result.tier_quota_bytes == 10737418240
    assert result.exceeds_quota is False
    assert len(result.breakdown) == 2
    assert result.breakdown[0].domain == "core_journal_entries"


@respx.mock
def test_submit_raw() -> None:
    respx.post(f"{BASE}/v1/configs/raw").mock(
        return_value=httpx.Response(
            200,
            json={
                "valid": True,
                "estimatedCredits": 150,
                "warnings": [],
                "configId": "cfg-123",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.configs.submit_raw(yaml="rows: 1000\nsector: retail", name="my-cfg")
    assert result.valid is True
    assert result.estimated_credits == 150
    assert result.config_id == "cfg-123"


@respx.mock
def test_list_files() -> None:
    # API returns camelCase
    respx.get(f"{BASE}/v1/jobs/j1/files").mock(
        return_value=httpx.Response(
            200,
            json={
                "jobId": "j1",
                "totalFiles": 2,
                "totalSizeBytes": 500000,
                "files": [
                    {
                        "path": "journal_entries.json",
                        "sizeBytes": 400000,
                        "contentType": "application/json",
                        "schema": [
                            {"name": "entry_id", "type": "string"},
                            {"name": "debit_amount", "type": "string"},
                        ],
                    },
                    {
                        "path": "chart_of_accounts.json",
                        "sizeBytes": 100000,
                        "contentType": "application/json",
                        "schema": [],
                    },
                ],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.jobs.list_files("j1")
    assert result.job_id == "j1"
    assert result.total_files == 2
    assert result.total_size_bytes == 500000
    assert len(result.files) == 2
    assert result.files[0].path == "journal_entries.json"
    assert result.files[0].size_bytes == 400000
    assert len(result.files[0].schema_) == 2
    assert result.files[0].schema_[0].name == "entry_id"


# ── Catalog ───────────────────────────────────────────────────────────────────


@respx.mock
def test_list_sectors() -> None:
    respx.get(f"{BASE}/v1/sectors").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "slug": "retail",
                    "name": "Retail",
                    "table_count": 4,
                    "quality_score": 96,
                    "popularity": 92,
                    "multiplier": 1.5,
                },
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    sectors = client.catalog.list_sectors()
    assert len(sectors) == 1
    assert sectors[0].slug == "retail"
    assert sectors[0].multiplier == 1.5


@respx.mock
def test_get_sector_with_tables() -> None:
    respx.get(f"{BASE}/v1/sectors/retail").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "uuid-1",
                "slug": "retail",
                "name": "Retail",
                "multiplier": 1.5,
                "quality_score": 96,
                "tables": [
                    {
                        "id": "tbl-1",
                        "slug": "journal-entries",
                        "name": "Journal Entries",
                        "base_rate": 1.0,
                        "columns": [
                            {
                                "name": "amount",
                                "data_type": "decimal",
                                "nullable": False,
                                "example_values": ["100.00"],
                            },
                        ],
                    },
                ],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    sector = client.catalog.get_sector("retail")
    assert sector.slug == "retail"
    assert len(sector.tables) == 1
    assert sector.tables[0].columns[0].example_values == ["100.00"]


@respx.mock
def test_catalog_list_with_data_wrapper() -> None:
    respx.get(f"{BASE}/v1/catalog").mock(
        return_value=httpx.Response(
            200,
            json={
                "data": [
                    {"slug": "retail", "name": "Retail", "table_count": 4},
                ]
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    items = client.catalog.list(sector="retail")
    assert len(items) == 1


@respx.mock
def test_list_templates() -> None:
    respx.get(f"{BASE}/v1/templates").mock(
        return_value=httpx.Response(
            200,
            json={
                "templates": [
                    {
                        "id": "tpl-1",
                        "slug": "retail-quick-start",
                        "name": "Retail Quick Start",
                        "sector": "retail",
                        "country": "US",
                        "framework": "us_gaap",
                        "config": {"rows": 1000},
                        "minTier": "free",
                        "sortOrder": 1,
                    },
                ]
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    templates = client.catalog.list_templates()
    assert len(templates) == 1
    assert templates[0].min_tier == "free"


# ── Usage ─────────────────────────────────────────────────────────────────────


@respx.mock
def test_usage_summary() -> None:
    respx.get(f"{BASE}/v1/usage/summary").mock(
        return_value=httpx.Response(
            200,
            json={
                "balance": 8500,
                "total_used": 1500,
                "burn_rate": 50,
                "period_days": 30,
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    usage = client.usage.summary()
    assert usage.balance == 8500
    assert usage.burn_rate == 50


@respx.mock
def test_usage_daily() -> None:
    respx.get(f"{BASE}/v1/usage/daily").mock(
        return_value=httpx.Response(
            200,
            json={
                "daily": [{"date": "2026-04-09", "credits": 10}],
                "by_table": [{"table_name": "journal_entries", "credits": 10, "job_count": 1}],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    resp = client.usage.daily()
    assert len(resp.daily) == 1
    assert len(resp.by_table) == 1
    assert resp.by_table[0].table_name == "journal_entries"


# ── API Keys ──────────────────────────────────────────────────────────────────


@respx.mock
def test_create_api_key() -> None:
    respx.post(f"{BASE}/v1/api-keys").mock(
        return_value=httpx.Response(
            201,
            json={
                "id": "key-1",
                "name": "CI key",
                "key": "vf_test_abc123def456",
                "prefix": "vf_test_abc1",
                "environment": "test",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    key = client.api_keys.create(name="CI key", environment="test")
    assert key.key == "vf_test_abc123def456"
    assert key.environment == "test"


@respx.mock
def test_list_api_keys_data_wrapper() -> None:
    respx.get(f"{BASE}/v1/api-keys").mock(
        return_value=httpx.Response(
            200,
            json={"data": [{"id": "k1", "name": "key1", "prefix": "vf_", "environment": "live"}]},
        )
    )
    client = VynFi(api_key="vf_test_abc")
    keys = client.api_keys.list()
    assert len(keys) == 1
    assert keys[0].environment == "live"


@respx.mock
def test_revoke_api_key() -> None:
    respx.delete(f"{BASE}/v1/api-keys/k1").mock(
        return_value=httpx.Response(
            200,
            json={"id": "k1", "status": "revoked", "revoked_at": "2026-04-10T12:00:00Z"},
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.api_keys.revoke("k1")
    assert result.status == "revoked"


# ── Quality ───────────────────────────────────────────────────────────────────


@respx.mock
def test_quality_scores() -> None:
    respx.get(f"{BASE}/v1/quality/scores").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": "qs1",
                    "job_id": "j1",
                    "table_type": "journal_entries",
                    "rows": 1000,
                    "overall_score": 0.92,
                    "benford_score": 0.95,
                    "correlation_score": 0.88,
                    "distribution_score": 0.91,
                },
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    scores = client.quality.scores()
    assert len(scores) == 1
    assert scores[0].overall_score == 0.92


@respx.mock
def test_quality_timeline() -> None:
    respx.get(f"{BASE}/v1/quality/timeline").mock(
        return_value=httpx.Response(
            200,
            json=[{"date": "2026-04-09", "score": 0.85}],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    timeline = client.quality.timeline()
    assert len(timeline) == 1
    assert timeline[0].score == 0.85


# ── Webhooks ──────────────────────────────────────────────────────────────────


@respx.mock
def test_create_webhook() -> None:
    respx.post(f"{BASE}/v1/webhooks").mock(
        return_value=httpx.Response(
            201,
            json={
                "id": "wh1",
                "url": "https://example.com/hook",
                "events": ["job.completed"],
                "secret": "whsec_abc123",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    hook = client.webhooks.create(url="https://example.com/hook", events=["job.completed"])
    assert hook.secret == "whsec_abc123"


@respx.mock
def test_get_webhook_detail() -> None:
    respx.get(f"{BASE}/v1/webhooks/wh1").mock(
        return_value=httpx.Response(
            200,
            json={
                "id": "wh1",
                "url": "https://example.com/hook",
                "events": ["job.completed"],
                "status": "active",
                "deliveries": [
                    {
                        "id": "d1",
                        "webhook_id": "wh1",
                        "event_type": "job.completed",
                        "payload": {},
                        "status_code": 200,
                        "attempt": 1,
                        "succeeded": True,
                    },
                ],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    detail = client.webhooks.get("wh1")
    assert len(detail.deliveries) == 1
    assert detail.deliveries[0].succeeded is True


# ── Billing ───────────────────────────────────────────────────────────────────


@respx.mock
def test_billing_subscription() -> None:
    respx.get(f"{BASE}/v1/billing/subscription").mock(
        return_value=httpx.Response(
            200,
            json={"tier": "Free", "status": "active", "stripe_price_id": None},
        )
    )
    client = VynFi(api_key="vf_test_abc")
    sub = client.billing.subscription()
    assert sub.tier == "Free"
    assert sub.status == "active"


@respx.mock
def test_billing_checkout() -> None:
    respx.post(f"{BASE}/v1/billing/checkout").mock(
        return_value=httpx.Response(
            200, json={"checkout_url": "https://checkout.stripe.com/session-123"}
        )
    )
    client = VynFi(api_key="vf_test_abc")
    resp = client.billing.checkout(price_id="price_123")
    assert "stripe.com" in resp.checkout_url


@respx.mock
def test_billing_portal() -> None:
    respx.post(f"{BASE}/v1/billing/portal").mock(
        return_value=httpx.Response(
            200, json={"portal_url": "https://billing.stripe.com/session-456"}
        )
    )
    client = VynFi(api_key="vf_test_abc")
    resp = client.billing.portal()
    assert "stripe.com" in resp.portal_url


@respx.mock
def test_billing_invoices() -> None:
    respx.get(f"{BASE}/v1/billing/invoices").mock(
        return_value=httpx.Response(200, json={"data": []})
    )
    client = VynFi(api_key="vf_test_abc")
    invoices = client.billing.invoices()
    assert invoices == []


# ── Configs ───────────────────────────────────────────────────────────────────


@respx.mock
def test_create_config() -> None:
    respx.post(f"{BASE}/v1/configs").mock(
        return_value=httpx.Response(
            201,
            json={
                "id": "cfg-1",
                "ownerId": "user-1",
                "name": "My Config",
                "description": "",
                "config": {"rows": 1000},
                "version": 1,
                "visibility": "private",
                "tags": [],
                "createdAt": "2026-04-10T12:00:00Z",
                "updatedAt": "2026-04-10T12:00:00Z",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    cfg = client.configs.create(name="My Config", config={"rows": 1000})
    assert cfg.id == "cfg-1"
    assert cfg.owner_id == "user-1"


@respx.mock
def test_list_configs() -> None:
    respx.get(f"{BASE}/v1/configs").mock(return_value=httpx.Response(200, json={"configs": []}))
    client = VynFi(api_key="vf_test_abc")
    configs = client.configs.list()
    assert configs == []


@respx.mock
def test_validate_config() -> None:
    respx.post(f"{BASE}/v1/config/validate").mock(
        return_value=httpx.Response(
            200,
            json={"valid": True, "errors": [], "warnings": []},
        )
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.configs.validate(config={"sector": "retail", "rows": 100})
    assert result.valid is True


@respx.mock
def test_estimate_cost() -> None:
    respx.post(f"{BASE}/v1/config/estimate-cost").mock(
        return_value=httpx.Response(
            200,
            json={
                "baseCredits": 100,
                "multipliers": [{"source": "sector", "factor": 1.5, "label": "Retail"}],
                "totalCredits": 150,
                "balance": {"current": 9000, "afterJob": 8850, "status": "ok"},
                "output": {
                    "estimatedFiles": 83,
                    "estimatedSizeBytes": 157286400,
                    "note": "The 'rows' parameter is a scale factor.",
                },
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    est = client.configs.estimate_cost(config={"sector": "retail", "rows": 1000})
    assert est.total_credits == 150
    assert est.balance is not None
    assert est.balance.after_job == 8850
    assert est.output is not None
    assert est.output.estimated_files == 83
    assert est.output.estimated_size_bytes == 157286400


@respx.mock
def test_delete_config() -> None:
    respx.delete(f"{BASE}/v1/configs/cfg-1").mock(
        return_value=httpx.Response(200, json={"deleted": True})
    )
    client = VynFi(api_key="vf_test_abc")
    result = client.configs.delete("cfg-1")
    assert result.deleted is True


# ── Credits ───────────────────────────────────────────────────────────────────


@respx.mock
def test_credits_balance() -> None:
    respx.get(f"{BASE}/v1/credits/balance").mock(
        return_value=httpx.Response(
            200,
            json={"total_prepaid_credits": 5000, "batches": []},
        )
    )
    client = VynFi(api_key="vf_test_abc")
    bal = client.credits.balance()
    assert bal.total_prepaid_credits == 5000


@respx.mock
def test_credits_history() -> None:
    respx.get(f"{BASE}/v1/credits/history").mock(
        return_value=httpx.Response(
            200,
            json={
                "batches": [
                    {
                        "id": "batch-1",
                        "ownerId": "user-1",
                        "pack": "10k",
                        "creditsPurchased": 10000,
                        "creditsRemaining": 8000,
                        "creditsForfeited": 0,
                        "status": "active",
                        "purchasedAt": "2026-01-01T00:00:00Z",
                        "expiresAt": "2027-01-01T00:00:00Z",
                        "createdAt": "2026-01-01T00:00:00Z",
                    },
                ]
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    history = client.credits.history()
    assert len(history.batches) == 1
    assert history.batches[0].credits_purchased == 10000


@respx.mock
def test_credits_purchase() -> None:
    respx.post(f"{BASE}/v1/credits/purchase").mock(
        return_value=httpx.Response(
            200, json={"checkout_url": "https://checkout.stripe.com/credit-123"}
        )
    )
    client = VynFi(api_key="vf_test_abc")
    resp = client.credits.purchase(pack="10k")
    assert "stripe.com" in resp.checkout_url


# ── Sessions ──────────────────────────────────────────────────────────────────


@respx.mock
def test_create_session() -> None:
    respx.post(f"{BASE}/v1/sessions").mock(
        return_value=httpx.Response(
            201,
            json={
                "id": "sess-1",
                "name": "FY2026",
                "status": "created",
                "fiscalYearStart": "2026-01-01",
                "periodLengthMonths": 3,
                "periodsTotal": 4,
                "periodsGenerated": 0,
                "periods": [],
                "generationConfig": {"sector": "retail", "rows": 100},
                "createdAt": "2026-04-10T12:00:00Z",
                "updatedAt": "2026-04-10T12:00:00Z",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    session = client.sessions.create(
        name="FY2026",
        fiscal_year_start="2026-01-01",
        period_length_months=3,
        periods=4,
        generation_config={"sector": "retail", "rows": 100},
    )
    assert session.id == "sess-1"
    assert session.periods_total == 4


@respx.mock
def test_list_sessions() -> None:
    respx.get(f"{BASE}/v1/sessions").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": "sess-1",
                    "name": "FY2026",
                    "status": "created",
                    "fiscalYearStart": "2026-01-01",
                    "periodLengthMonths": 3,
                    "periodsTotal": 4,
                    "periodsGenerated": 0,
                    "periods": [],
                    "generationConfig": {},
                    "createdAt": "2026-04-10T12:00:00Z",
                    "updatedAt": "2026-04-10T12:00:00Z",
                },
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    sessions = client.sessions.list()
    assert len(sessions) == 1


# ── Scenarios ─────────────────────────────────────────────────────────────────


@respx.mock
def test_create_scenario() -> None:
    respx.post(f"{BASE}/v1/scenarios").mock(
        return_value=httpx.Response(
            201,
            json={
                "id": "sc-1",
                "name": "Fraud Test",
                "templateId": "supply-chain",
                "status": "created",
                "interventions": {"fraudRate": 0.05},
                "generationConfig": {"sector": "retail"},
                "createdAt": "2026-04-10T12:00:00Z",
                "updatedAt": "2026-04-10T12:00:00Z",
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    sc = client.scenarios.create(
        name="Fraud Test",
        template_id="supply-chain",
        interventions={"fraudRate": 0.05},
        generation_config={"sector": "retail"},
    )
    assert sc.id == "sc-1"
    assert sc.template_id == "supply-chain"


@respx.mock
def test_list_scenarios() -> None:
    respx.get(f"{BASE}/v1/scenarios").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": "sc-1",
                    "name": "Fraud Test",
                    "templateId": "supply-chain",
                    "status": "created",
                    "interventions": {},
                    "generationConfig": {},
                    "createdAt": "2026-04-10T12:00:00Z",
                    "updatedAt": "2026-04-10T12:00:00Z",
                },
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    scenarios = client.scenarios.list()
    assert len(scenarios) == 1


@respx.mock
def test_scenario_templates() -> None:
    respx.get(f"{BASE}/v1/scenarios/templates").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": "tpl_1",
                    "name": "Financial Process",
                    "description": "Default template",
                    "nodeCount": 17,
                    "nodes": [{"id": "gdp", "label": "GDP Growth", "x": 50, "y": 20}],
                    "edges": [{"source": "gdp", "target": "revenue"}],
                    "interventionTypes": ["shock", "gradual"],
                },
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    templates = client.scenarios.templates()
    assert len(templates) == 1
    assert templates[0].node_count == 17
    assert len(templates[0].nodes) == 1


# ── Notifications ─────────────────────────────────────────────────────────────


@respx.mock
def test_list_notifications() -> None:
    respx.get(f"{BASE}/v1/notifications").mock(
        return_value=httpx.Response(
            200,
            json=[
                {
                    "id": "n1",
                    "user_id": "user-1",
                    "type": "job.completed",
                    "title": "Job completed",
                    "message": "Job j1 finished",
                    "link": "/dashboard/jobs/j1",
                    "read": False,
                    "created_at": "2026-04-10T12:00:00Z",
                },
            ],
        )
    )
    client = VynFi(api_key="vf_test_abc")
    notifs = client.notifications.list()
    assert len(notifs) == 1
    assert notifs[0].type == "job.completed"
    assert notifs[0].read is False


@respx.mock
def test_mark_notifications_read() -> None:
    respx.post(f"{BASE}/v1/notifications/mark-read").mock(return_value=httpx.Response(204))
    client = VynFi(api_key="vf_test_abc")
    client.notifications.mark_read(ids=["n1"])  # should not raise


# ── DataSynth 3.0 / VynFi API 2.0+ ────────────────────────────────────────────


@respx.mock
def test_scenarios_packs() -> None:
    respx.get(f"{BASE}/v1/scenarios/packs").mock(
        return_value=httpx.Response(
            200,
            json={
                "packs": [
                    {
                        "name": "vendor_collusion_ring",
                        "category": "fraud",
                        "description": "Coordinated vendor bids with kickbacks",
                    },
                    {
                        "name": "recession_2008_replay",
                        "category": "macro",
                        "description": "GDP contraction, revenue decline",
                    },
                ]
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    packs = client.scenarios.packs()
    assert len(packs) == 2
    assert packs[0].name == "vendor_collusion_ring"
    assert packs[0].category == "fraud"


@respx.mock
def test_scenarios_create_v3_shape() -> None:
    """POST /v1/scenarios takes {name, generation_config} in 3.0 format."""
    captured = {}

    def _cap(request: httpx.Request) -> httpx.Response:
        import json as _json

        captured["body"] = _json.loads(request.content)
        return httpx.Response(
            201,
            json={
                "id": "sc-1",
                "name": "Q3 volume spike",
                "status": "created",
                "templateId": "",
                "interventions": None,
                "generationConfig": None,
                "baselineJobId": None,
                "counterfactualJobId": None,
                "diff": None,
            },
        )

    respx.post(f"{BASE}/v1/scenarios").mock(side_effect=_cap)
    client = VynFi(api_key="vf_test_abc")

    # 3.0 API: just name + generation_config
    scenario = client.scenarios.create(
        name="Q3 volume spike",
        generation_config={
            "sector": "retail",
            "rows": 1000,
            "scenarios": {"enabled": True, "packs": ["channel_stuffing"]},
        },
    )
    assert scenario.id == "sc-1"
    assert captured["body"]["name"] == "Q3 volume spike"
    assert "packs" in captured["body"]["generation_config"]["scenarios"]


@respx.mock
def test_scenarios_create_legacy_kwargs() -> None:
    """Backward-compat: template_id + interventions get folded into generation_config.scenarios."""
    captured = {}

    def _cap(request: httpx.Request) -> httpx.Response:
        import json as _json

        captured["body"] = _json.loads(request.content)
        return httpx.Response(
            201,
            json={"id": "sc-2", "name": "n", "status": "created", "templateId": ""},
        )

    respx.post(f"{BASE}/v1/scenarios").mock(side_effect=_cap)
    client = VynFi(api_key="vf_test_abc")
    client.scenarios.create(
        name="legacy",
        generation_config={"sector": "retail"},
        template_id="tpl-1",
        interventions=[{"type": "parameter_shift", "target": "x", "value": "1"}],
    )
    scen = captured["body"]["generation_config"]["scenarios"]
    assert scen["enabled"] is True
    assert scen["templateId"] == "tpl-1"
    assert scen["interventions"][0]["target"] == "x"


@respx.mock
def test_jobs_tune() -> None:
    respx.post(f"{BASE}/v1/jobs/j-1/tune").mock(
        return_value=httpx.Response(
            200,
            json={
                "originalConfig": {"rows": 100},
                "suggestedConfig": {"rows": 500, "fraudRate": 0.02},
                "explanation": "Increase rows for better Benford conformance.",
                "qualitySummary": {
                    "overall": "78.5%",
                    "benford": "82.0%",
                    "distribution": "75.0%",
                    "rowsAnalyzed": 100,
                },
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    r = client.jobs.tune("j-1", target_scores={"overall": 0.95})
    assert r.explanation.startswith("Increase")
    assert r.suggested_config["rows"] == 500
    assert r.quality_summary is not None
    assert r.quality_summary.overall == "78.5%"
    assert r.quality_summary.rows_analyzed == 100


@respx.mock
def test_ai_chat() -> None:
    respx.post(f"{BASE}/v1/ai/chat").mock(
        return_value=httpx.Response(200, json={"reply": "Try raising fraudRate to 0.05."})
    )
    client = VynFi(api_key="vf_test_abc")
    r = client.ai.chat("How do I increase fraud coverage?", page="quality")
    assert "fraudRate" in r.reply


@respx.mock
def test_adversarial_results() -> None:
    respx.get(f"{BASE}/v1/adversarial/pr-1/results").mock(
        return_value=httpx.Response(
            200,
            json={
                "n_probes": 1000,
                "mean_score": 0.52,
                "std_score": 0.18,
                "positive_rate": 0.41,
                "mean_margin": 0.04,
                "boundary_samples": [
                    {
                        "features": [0.1, 0.2],
                        "score": 0.51,
                        "predicted_positive": True,
                        "margin": 0.01,
                    },
                ],
            },
        )
    )
    client = VynFi(api_key="vf_test_abc")
    results = client.adversarial.results("pr-1")
    assert results.n_probes == 1000
    assert results.mean_score == 0.52
    assert len(results.boundary_samples) == 1
    assert results.boundary_samples[0].margin == 0.01
