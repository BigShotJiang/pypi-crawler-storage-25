# Changelog

All notable changes to the VynFi Python SDK are documented here.

## [1.4.0] - 2026-04-14

Adds support for DataSynth 3.0 + VynFi API features (scenario packs, fingerprint
synthesis, adversarial probing, AI tuning, co-pilot chat). All features verified
end-to-end against the live API.

### Added

- **`Scenarios.packs()`** — lists the 11 built-in DataSynth scenario packs:
  - **Fraud**: `vendor_collusion_ring`, `management_override`, `ghost_employee`,
    `procurement_kickback`, `channel_stuffing`
  - **Control failures**: `sox_material_weakness`, `it_control_breakdown`
  - **Macro**: `recession_2008_replay`, `supply_chain_disruption_q3`,
    `interest_rate_shock_300bp`
  - **Operational**: `erp_migration_cutover`
- **`Fingerprint` resource** (`client.fingerprint`) — privacy-preserving synthesis
  from `.dsf` fingerprint files via `POST /v1/fingerprint/synthesize`.
  Team+ for statistical, Scale+ for neural/hybrid backends.
- **`Adversarial` resource** (`client.adversarial`) — ONNX model probing for
  fraud detection robustness (Enterprise tier). Methods: `probe()`,
  `results()`.
- **`Jobs.tune()`** — LLM-powered config suggestion based on a completed job's
  quality scores (`POST /v1/jobs/{id}/tune`). Scale+.
- **`AI` resource** (`client.ai`) — free-text chat with the dashboard co-pilot
  (`POST /v1/ai/chat`). Scale+.
- **New models**: `ScenarioPack`, `ScenarioPackList`, `FingerprintSynthesisResponse`,
  `AdversarialProbeResponse`, `AdversarialProbeResults`, `ProbeSample`,
  `AiTuneResponse`, `AiChatResponse`, `QualitySummary`.
- **Four new examples**: `scenario_packs.py`, `ai_tune.py`,
  `fingerprint_synthesis.py`, `neural_diffusion.py`.

### Changed

- **`Scenarios.create()`** — updated to the DS 3.0 request shape
  (`{name, generation_config}`). Legacy `template_id` and `interventions`
  kwargs are still accepted and are auto-folded into
  `generation_config.scenarios.*` for backward compatibility.
- **Default client timeout** — bumped from 30s to 60s. The 30s default was too
  tight for `generate_quick` (30s server-side limit) with realistic network
  latency.

### DataSynth 3.0 features supported via existing endpoints (no SDK changes)

- **Scenario packs in config** — `generation_config.scenarios.packs = [...]`
- **Custom interventions** — `generation_config.scenarios.interventions = [...]`
  with timing (`startMonth`, `durationMonths`, `onset`) and constraints
  (`preserveAccountingIdentity`, etc.). Scale+.
- **Neural diffusion** — `generation_config.diffusion.backend = "neural"|"hybrid"`
  with `neural.*` subsection. Scale+.
- **Quality gates** — `generation_config.qualityGates.profile = "standard"|"strict"|"audit"`.
  Team+.
- **OCPM fields populated** — `ocpm_event_ids`, `ocpm_object_ids`, `ocpm_case_id`
  are now populated on journal entry headers (was empty in 2.3.x). Verified
  209/300 entries on a sample retail job.

### Still pending upstream (DataSynth team)

- `exportLayout: flat` hangs the DataSynth binary — use the default nested
  layout for now.

## [1.3.0] - 2026-04-13

Adds support for DataSynth 2.3 + VynFi API 2.0 features released by the platform team. All features verified end-to-end against the live API ([verification report](docs/v1.3.0-verification-report.md)).

### Fixed

- **CamelCase deserialization** for `JobFileList`, `JobFile`, `EstimateSizeResponse` — these were declared with plain `BaseModel` but the API returns camelCase fields. Pydantic silently fell back to defaults (e.g. `list_files()` reported 0 files even when 85 existed). Switched to `_CamelModel`.
- **Download timeout** extended from 30s → 5min default for `request_raw()`. Large archive downloads (>100MB) were timing out.

### Added

- **`Jobs.analytics()`** — fetch pre-built statistical analytics for a completed job
  (`GET /v1/jobs/{id}/analytics`). Returns Benford's Law conformity, amount distribution,
  process variant summary, and banking evaluation in one call.
- **`Jobs.stream_ndjson()`** — rate-controlled NDJSON streaming
  (`GET /v1/jobs/{id}/stream/ndjson`) with `rate`, `burst`, `progress_interval`, `file`
  query parameters. Yields data records and `_progress` envelopes. Scale tier+.
- **`Configs.estimate_size()`** — TB-scale storage quota validation
  (`POST /v1/configs/estimate-size`) with per-domain breakdown.
- **`Configs.submit_raw()`** — raw DataSynth YAML config submission
  (`POST /v1/configs/raw`). Scale tier+.
- **`JobArchive` now supports both backends** transparently — legacy zip archives and
  new TB-scale `managed_blob` manifests with presigned URLs. New `archive.backend`
  property and `archive.url(path)` / `archive.ttl_seconds()` methods.
- **Analytics models**: `JobAnalytics`, `BenfordAnalysis`, `AmountDistributionAnalysis`,
  `VariantAnalysis`, `BankingEvaluation`, `KycCompletenessAnalysis`,
  `AmlDetectabilityAnalysis`, `CrossLayerCoherenceAnalysis`, `VelocityQualityAnalysis`,
  `FalsePositiveAnalysis`, `TypologyDetection`.
- **Config models**: `EstimateSizeResponse`, `SizeBucket`, `RawConfigResponse`.
- **Three new examples**: `analytics_export.py`, `ndjson_streaming.py`, `native_mode.py`.

### DataSynth 2.3 features (server-side, supported by SDK)

- **`output.numericMode = "native"`** — decimals as JSON numbers (eliminates the need
  for `pd.to_numeric()` in consumer code)
- **`output.exportLayout = "flat"`** — header fields merged onto each line (eliminates
  manual flattening of journal entries)
- **`banking_customers.display_name`** — pre-flattened name field
- **Fraud label propagation** — `is_fraud` and `fraud_type` now appear on document flow
  records (PO, GR, VI, Payment, SO, Delivery, CI), not just journal entries
- **Pre-built analytics** — `analytics/` directory in every archive with Benford,
  distribution, variant, and banking evaluation files
- **TB-scale managed blob storage** — large jobs return manifest with presigned URLs
  instead of inline zip archive

## [1.2.0] - 2026-04-11

### Added

- **`Jobs.list_files()`** — list all files in a completed job's archive with sizes, content types, and per-file column schemas (`GET /v1/jobs/{id}/files`)
- **`JobFileList`**, **`JobFile`**, **`FileSchema`** models for the file listing response
- **`OutputEstimate`** model and `output` field on `EstimateCostResponse` — shows estimated file count and archive size before running a job
- **`OutputEstimate.note`** field — explains that the `rows` parameter is a scale factor

## [1.1.0] - 2026-04-11

### Added

- **`JobArchive` class** -- wraps downloaded zip archives for easy file access: `archive.json()`, `archive.files()`, `archive.categories()`, `archive.find()`, `archive.summary()`, `archive.extract_to()`
- **`Jobs.download_archive()`** -- returns a `JobArchive` instead of raw bytes
- **`archive_to_dataframes()`** in pandas integration -- converts all JSON files in an archive to a dict of DataFrames in one call, with automatic header/lines flattening for journal entries
- **7 Jupyter notebooks** -- quickstart, audit analytics, fraud detection, document flow audit trail, process mining, ESG reporting, AML compliance testing
- **7 standalone scripts** -- quickstart, streaming progress, pandas workflow, config management, multi-period sessions, what-if scenarios, quality monitoring
- **Examples README** with sample output figures and key metrics from live testing

### Fixed

- **Config endpoints** used wrong URL path: `/v1/configs/validate` -> `/v1/config/validate`, `/v1/configs/estimate-cost` -> `/v1/config/estimate-cost`, `/v1/configs/compose` -> `/v1/config/compose` (singular, matching Rust SDK reference)
- **Sessions `generate_next()`** used wrong URL path: `/v1/sessions/{id}/generate-next` -> `/v1/sessions/{id}/generate` (matching Rust SDK reference)

## [1.0.0] - 2026-04-10

First stable release. Full API parity with the VynFi Rust SDK reference implementation.

### Added

- **Configs resource** — save, list, get, update, delete generation configs; validate configs, estimate cost, and compose from layers
- **Credits resource** — purchase prepaid credit packs, check balance, view history
- **Sessions resource** — create multi-period generation sessions, extend, and generate each period sequentially
- **Scenarios resource** — create what-if scenarios with causal graph templates, run baseline vs counterfactual, get diff analysis
- **Notifications resource** — list and mark-read user notifications
- **Catalog templates** — `catalog.list_templates()` for browsing system generation templates
- **Billing checkout & portal** — `billing.checkout()` and `billing.portal()` for Stripe integration
- **Jobs enhancements** — `generate_config()` for config-based generation, `download_file()` for specific artifacts, `wait()` for polling convenience, `download()` returns bytes directly
- **ForbiddenError** (403) exception type
- **QuickJobResponse** and **CancelJobResponse** dedicated return types
- **WebhookDetail** with delivery history
- **RevokeKeyResponse** return type for API key revocation
- **pandas integration** (`vynfi.integrations.pandas`) — `download_dataframe()`, `job_to_dataframe()`, `usage_to_dataframe()`, `quality_to_dataframe()`
- **polars integration** (`vynfi.integrations.polars`) — `download_frame()`, `job_to_frame()`, `usage_to_frame()`, `quality_to_frame()`
- Optional dependency groups: `pip install vynfi[pandas]`, `vynfi[polars]`, `vynfi[all]`

### Changed

- **Version bumped to 1.0.0** (production-stable)
- **Job model** updated to match live API: `owner_id`, `config`, `artifacts`, `error_detail` fields; removed legacy `tables`, `format`, `sector_slug`, `output_path`, `error` fields
- **JobList** uses `data` field (was `jobs`) to match API response shape
- **Sector/SectorSummary/CatalogItem** now include `id`, `multiplier`, `quality_score` (int), `popularity` fields
- **Column** now includes `example_values`
- **TableDef** now includes `id`, `slug`
- **Fingerprint** model restructured: `sector` (value) + `table` (TableDef)
- **ApiKey/ApiKeyCreated** use `environment` field (was `scopes`/`expires_in_days`)
- **UsageSummary.burn_rate** is `int` (was `float`)
- **DailyUsageResponse.by_table** is `list[TableUsage]` (was `dict`)
- **Invoice** fields updated to match Stripe format (`amount_due`, `amount_paid`, `number`, `created`, `hosted_invoice_url`, `pdf`)
- **Subscription** now includes `stripe_price_id`
- **Billing.payment_method()** returns raw JSON (was `PaymentMethod` model)
- **Jobs.download()** returns `bytes` (was file-path based); use `download_to()` for file output
- Development status classifier: Alpha → Production/Stable

### Removed

- `PaymentMethod` model (API returns raw JSON)
- Legacy `JobProgress` model (job progress is now untyped `Any` matching API)

## [0.1.0] - 2026-04-09

Initial alpha release with 7 resource modules: jobs, catalog, usage, api_keys, quality, webhooks, billing.
