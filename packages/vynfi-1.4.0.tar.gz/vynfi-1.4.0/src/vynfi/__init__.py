"""VynFi Python SDK — synthetic financial data generation."""

from __future__ import annotations

from typing import Any

from ._archive import JobArchive
from ._client import SyncClient
from ._exceptions import (
    AuthenticationError,
    ConflictError,
    ForbiddenError,
    InsufficientCreditsError,
    NotFoundError,
    RateLimitError,
    ServerError,
    ValidationError,
    VynFiError,
)
from ._types import (
    AdversarialProbeResponse,
    AdversarialProbeResults,
    AiChatResponse,
    AiTuneResponse,
    AmlDetectabilityAnalysis,
    AmountDistributionAnalysis,
    ApiKey,
    ApiKeyCreated,
    BalanceInfo,
    BankingEvaluation,
    BenfordAnalysis,
    CancelJobResponse,
    CatalogItem,
    CheckoutResponse,
    Column,
    ComposeConfigResponse,
    CrossLayerCoherenceAnalysis,
    DailyQuality,
    DailyUsage,
    DailyUsageResponse,
    DeletedResponse,
    EstimateCostResponse,
    EstimateSizeResponse,
    FalsePositiveAnalysis,
    FileSchema,
    Fingerprint,
    FingerprintSynthesisResponse,
    GenerateSessionResponse,
    GenerationSession,
    Invoice,
    Job,
    JobAnalytics,
    JobFile,
    JobFileList,
    JobLinks,
    JobList,
    KycCompletenessAnalysis,
    MultiplierEntry,
    Notification,
    OutputEstimate,
    PortalResponse,
    PrepaidBalanceResponse,
    PrepaidBatch,
    PrepaidHistoryResponse,
    ProbeSample,
    PurchaseCreditsResponse,
    QualityScore,
    QualitySummary,
    QuickJobResponse,
    RawConfigResponse,
    RevokeKeyResponse,
    SavedConfig,
    Scenario,
    ScenarioPack,
    ScenarioPackList,
    ScenarioTemplate,
    ScenarioTemplateEdge,
    ScenarioTemplateNode,
    Sector,
    SectorSummary,
    SizeBucket,
    SseEvent,
    SubmitJobResponse,
    Subscription,
    TableDef,
    TableUsage,
    Template,
    TypologyDetection,
    UsageSummary,
    ValidateConfigResponse,
    ValidationFix,
    ValidationIssue,
    VariantAnalysis,
    VelocityQualityAnalysis,
    Webhook,
    WebhookCreated,
    WebhookDelivery,
    WebhookDetail,
)
from .resources.adversarial import Adversarial
from .resources.ai import AI
from .resources.api_keys import ApiKeys
from .resources.billing import Billing
from .resources.catalog import Catalog
from .resources.configs import Configs
from .resources.credits import Credits
from .resources.fingerprint import Fingerprint as FingerprintResource
from .resources.jobs import Jobs
from .resources.notifications import Notifications
from .resources.quality import Quality
from .resources.scenarios import Scenarios
from .resources.sessions import Sessions
from .resources.usage import Usage
from .resources.webhooks import Webhooks

__version__ = "1.4.0"
__all__ = [
    # Client
    "VynFi",
    # Archive
    "JobArchive",
    # Exceptions
    "VynFiError",
    "AuthenticationError",
    "InsufficientCreditsError",
    "ForbiddenError",
    "NotFoundError",
    "ConflictError",
    "ValidationError",
    "RateLimitError",
    "ServerError",
    # Jobs
    "Job",
    "JobList",
    "JobFile",
    "JobFileList",
    "FileSchema",
    "JobLinks",
    "SubmitJobResponse",
    "QuickJobResponse",
    "CancelJobResponse",
    "SseEvent",
    # Analytics (DataSynth 2.3+)
    "JobAnalytics",
    "BenfordAnalysis",
    "AmountDistributionAnalysis",
    "VariantAnalysis",
    "BankingEvaluation",
    "KycCompletenessAnalysis",
    "AmlDetectabilityAnalysis",
    "CrossLayerCoherenceAnalysis",
    "VelocityQualityAnalysis",
    "FalsePositiveAnalysis",
    "TypologyDetection",
    # Catalog
    "Column",
    "TableDef",
    "Sector",
    "SectorSummary",
    "CatalogItem",
    "Fingerprint",
    "Template",
    # Usage
    "UsageSummary",
    "DailyUsage",
    "DailyUsageResponse",
    "TableUsage",
    # API Keys
    "ApiKey",
    "ApiKeyCreated",
    "RevokeKeyResponse",
    # Quality
    "QualityScore",
    "DailyQuality",
    # Webhooks
    "Webhook",
    "WebhookCreated",
    "WebhookDetail",
    "WebhookDelivery",
    # Billing
    "Subscription",
    "CheckoutResponse",
    "PortalResponse",
    "Invoice",
    # Configs
    "SavedConfig",
    "DeletedResponse",
    "ValidateConfigResponse",
    "ValidationIssue",
    "ValidationFix",
    "EstimateCostResponse",
    "OutputEstimate",
    "MultiplierEntry",
    "BalanceInfo",
    "ComposeConfigResponse",
    "EstimateSizeResponse",
    "SizeBucket",
    "RawConfigResponse",
    # Credits
    "PurchaseCreditsResponse",
    "PrepaidBatch",
    "PrepaidBalanceResponse",
    "PrepaidHistoryResponse",
    # Sessions
    "GenerationSession",
    "GenerateSessionResponse",
    # Scenarios
    "Scenario",
    "ScenarioTemplate",
    "ScenarioTemplateNode",
    "ScenarioTemplateEdge",
    "ScenarioPack",
    "ScenarioPackList",
    # Fingerprint (DS 3.0)
    "FingerprintSynthesisResponse",
    # Adversarial (DS 3.0)
    "AdversarialProbeResponse",
    "AdversarialProbeResults",
    "ProbeSample",
    # AI (DS 3.0)
    "AiTuneResponse",
    "AiChatResponse",
    "QualitySummary",
    # Notifications
    "Notification",
    # Resource classes
    "Jobs",
    "Catalog",
    "Usage",
    "ApiKeys",
    "Quality",
    "Webhooks",
    "Billing",
    "Configs",
    "Credits",
    "Sessions",
    "Scenarios",
    "Notifications",
    "Adversarial",
    "AI",
]


class VynFi:
    """VynFi API client.

    Usage::

        from vynfi import VynFi

        client = VynFi(api_key="vf_live_...")

        # Generate data
        job = client.jobs.generate(
            tables=[{"name": "journal_entries", "rows": 5000}],
            sector_slug="retail",
        )

        # Wait for completion
        completed = client.jobs.wait(job.id)

        # Download results
        data = client.jobs.download(completed.id)

        # Check usage
        usage = client.usage.summary()
        print(f"Balance: {usage.balance} credits")
    """

    def __init__(
        self,
        api_key: str,
        *,
        base_url: str = "https://api.vynfi.com",
        timeout: float = 60.0,
        max_retries: int = 2,
    ) -> None:
        self._client = SyncClient(
            api_key,
            base_url=base_url,
            timeout=timeout,
            max_retries=max_retries,
        )
        self.jobs = Jobs(self._client)
        self.catalog = Catalog(self._client)
        self.usage = Usage(self._client)
        self.api_keys = ApiKeys(self._client)
        self.quality = Quality(self._client)
        self.webhooks = Webhooks(self._client)
        self.billing = Billing(self._client)
        self.configs = Configs(self._client)
        self.credits = Credits(self._client)
        self.sessions = Sessions(self._client)
        self.scenarios = Scenarios(self._client)
        self.notifications = Notifications(self._client)
        # DS 3.0 resources
        self.fingerprint = FingerprintResource(self._client)
        self.adversarial = Adversarial(self._client)
        self.ai = AI(self._client)

    def close(self) -> None:
        """Close the underlying HTTP client."""
        self._client.close()

    def __enter__(self) -> VynFi:
        return self

    def __exit__(self, *args: Any) -> None:
        self.close()

    # ── Convenience shortcuts ──

    def generate(self, **kwargs: Any) -> SubmitJobResponse:
        """Shortcut for ``client.jobs.generate(...)``."""
        return self.jobs.generate(**kwargs)

    def generate_quick(self, **kwargs: Any) -> QuickJobResponse:
        """Shortcut for ``client.jobs.generate_quick(...)``."""
        return self.jobs.generate_quick(**kwargs)
