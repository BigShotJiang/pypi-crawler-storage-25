"""Fingerprint synthesis resource (DataSynth 3.0+)."""

from __future__ import annotations

import json
from pathlib import Path
from typing import Any

import httpx

from .._client import SyncClient
from .._types import FingerprintSynthesisResponse


class Fingerprint:
    """Privacy-preserving synthesis from ``.dsf`` fingerprint files (DS 3.0+).

    Upload a fingerprinted dataset and synthesize new data matching its
    statistical properties via the DataSynth diffusion trainer.

    - Team+ tier required for the ``statistical`` backend
    - Scale+ tier required for ``neural`` / ``hybrid`` backends
    """

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def synthesize(
        self,
        fingerprint: str | Path | bytes,
        *,
        rows: int = 10000,
        backend: str = "statistical",
        seed: int = 42,
    ) -> FingerprintSynthesisResponse:
        """Submit a fingerprint file for synthesis.

        Args:
            fingerprint: Path to a ``.dsf`` file, or raw bytes (max 50 MB).
            rows: Number of synthetic rows to generate (min 100).
            backend: Diffusion backend — ``"statistical"`` (Team+),
                     ``"neural"`` (Scale+), or ``"hybrid"`` (Scale+).
            seed: Random seed for reproducibility.

        Returns:
            A :class:`FingerprintSynthesisResponse` with the spawned ``job_id``.
            Use :meth:`VynFi.jobs.wait` to poll for completion.
        """
        if isinstance(fingerprint, (str, Path)):
            data = Path(fingerprint).read_bytes()
            filename = Path(fingerprint).name
        else:
            data = fingerprint
            filename = "fingerprint.dsf"

        config_json = json.dumps({"rows": rows, "backend": backend, "seed": seed})

        # Multipart upload — sidestep the SDK's JSON content-type default.
        files: dict[str, Any] = {
            "fingerprint": (filename, data, "application/octet-stream"),
            "config": (None, config_json, "application/json"),
        }
        headers = {
            "Authorization": f"Bearer {self._client.api_key}",
            "User-Agent": "vynfi-python/1.4.0",
        }
        url = self._client._url("/v1/fingerprint/synthesize")
        resp = httpx.post(url, headers=headers, files=files, timeout=300.0)
        if resp.status_code >= 400:
            # Reuse the client's error mapping by re-raising through _raise_for_status
            from .._client import _raise_for_status

            _raise_for_status(resp)
        return FingerprintSynthesisResponse.model_validate(resp.json())
