"""What-if scenarios resource."""

from __future__ import annotations

from typing import Any, List

from .._client import SyncClient
from .._types import Scenario, ScenarioPack, ScenarioPackList, ScenarioTemplate


class Scenarios:
    """Manage what-if scenarios and counterfactual simulations (DS 3.0+)."""

    def __init__(self, client: SyncClient) -> None:
        self._client = client

    def list(self) -> List[Scenario]:
        """List all scenarios."""
        data = self._client.request("GET", "/v1/scenarios")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [Scenario.model_validate(s) for s in data]

    def create(
        self,
        *,
        name: str,
        generation_config: dict[str, Any],
        template_id: str | None = None,
        interventions: dict[str, Any] | None = None,
    ) -> Scenario:
        """Create a new scenario (baseline + counterfactual).

        The scenario's ``generation_config`` can include a ``scenarios`` section
        with built-in pack names and/or custom interventions::

            generation_config = {
                "sector": "retail",
                "rows": 1000,
                ...,
                "scenarios": {
                    "enabled": True,
                    "packs": ["management_override"],
                    "interventions": [
                        {"type": "parameter_shift", "target": "fraud.injection_rate",
                         "value": "0.08", "timing": {"startMonth": 6, "durationMonths": 3}}
                    ],
                    "constraints": {"preserveAccountingIdentity": True},
                    "diffFormats": ["summary", "record_level"],
                },
            }

        Args:
            name: Scenario display name
            generation_config: Base generation config (may include a ``scenarios`` key)
            template_id: (Legacy, pre-3.0) Causal graph template ID.
            interventions: (Legacy, pre-3.0) Intervention parameters — if
                provided, merged into ``generation_config.scenarios.interventions``.
        """
        # Backward-compat: if caller passed template_id/interventions the old
        # way, fold them into the generation_config.scenarios section.
        if template_id is not None or interventions is not None:
            cfg = dict(generation_config)
            scen = dict(cfg.get("scenarios", {}))
            scen.setdefault("enabled", True)
            if interventions is not None:
                scen["interventions"] = interventions
            if template_id is not None:
                scen["templateId"] = template_id
            cfg["scenarios"] = scen
            generation_config = cfg

        body: dict[str, Any] = {
            "name": name,
            "generation_config": generation_config,
        }
        data = self._client.request("POST", "/v1/scenarios", json=body)
        return Scenario.model_validate(data)

    def run(self, scenario_id: str) -> Scenario:
        """Run a scenario, spawning baseline + counterfactual jobs concurrently."""
        data = self._client.request("POST", f"/v1/scenarios/{scenario_id}/run")
        return Scenario.model_validate(data)

    def diff(self, scenario_id: str) -> Scenario:
        """Get diff analysis between baseline and counterfactual jobs."""
        data = self._client.request("GET", f"/v1/scenarios/{scenario_id}/diff")
        return Scenario.model_validate(data)

    def templates(self) -> List[ScenarioTemplate]:
        """List causal graph templates for the scenario builder."""
        data = self._client.request("GET", "/v1/scenarios/templates")
        if isinstance(data, dict):
            data = data.get("data") or []
        return [ScenarioTemplate.model_validate(t) for t in data]

    def packs(self) -> List[ScenarioPack]:
        """List the 11 built-in DataSynth scenario packs (DS 3.0+).

        Categories: fraud, control_failure, macro, operational.
        Names include: vendor_collusion_ring, management_override,
        ghost_employee, procurement_kickback, channel_stuffing,
        sox_material_weakness, it_control_breakdown, recession_2008_replay,
        supply_chain_disruption_q3, interest_rate_shock_300bp,
        erp_migration_cutover.
        """
        data = self._client.request("GET", "/v1/scenarios/packs")
        if isinstance(data, dict):
            wrapper = ScenarioPackList.model_validate(data)
            return wrapper.packs
        return [ScenarioPack.model_validate(p) for p in data]
