# Initializing a new project

Scenarios for initializing a new cottage repository:

## Create a fresh new git repo and keep secrets in it

To start a fresh new repo with secrets, run:

> ```bash,test,newdir
> mkdir myproject
> cd myproject
> git init
>
> ctg init
> ```

```stdout
Initialized empty Git repository in /tmp/tmp.XXX/.git/
```

To confirm that the repository is properly initialized, run:

> ```bash,test
> git status
> ```

```stdout
On branch main

No commits yet

Untracked files:
  (use "git add <file>..." to include in what will be committed)
        .cottage/
        .gitattributes
        .gitignore

nothing added to commit but untracked files present (use "git add" to track)
```

Check the contents in the `.cottage` directory:

> ```bash,test
> tree .cottage
> ```

```stdout
.cottage
├── identity
└── recipients
    └── XXX

2 directories, 2 files
```

Check the contents of `.gitignore` and `.gitattributes`:

> ```bash,test
> cat .gitignore
> ```

```stdout
/.cottage/identity
```

> ```bash,test
> cat .gitattributes
> ```

```stdout
*.cott.age binary export-ignore filter=cottage-encrypted -diff
```

## Add cottage to an existing git repo

To add cottage to an existing git repository (e.g. sayanarijit/jf), run:

> ```bash,test,newdir
> git clone git@github.com:sayanarijit/jf.git
> cd jf
>
> ctg init
> ```

To confirm that the repository is properly initialized, run:

> ```bash,test
> tree .cottage
> ```

```stdout
.cottage
├── identity
└── recipients
    └── XXX
```

To confirm that `.gitignore` and `.gitattributes` are properly updated, run:

> ```bash,test
> grep .cottage/identity .gitignore
> ```

```stdout
/.cottage/identity
```

> ```bash,test
> grep .cott.age .gitattributes
> ```

```stdout
*.cott.age binary export-ignore filter=cottage-encrypted -diff
```
