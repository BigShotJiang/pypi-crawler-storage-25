import re
from enum import Enum
from typing import Optional, Any, List
from pydantic import BaseModel


class EnforcementLevel(str, Enum):
    BLOCK = "block"
    WARN = "warn"
    LOG = "log"


class GuardrailType(str, Enum):
    ACTION_ALLOWLIST = "action_allowlist"
    ACTION_BLOCKLIST = "action_blocklist"
    CONFIDENCE_THRESHOLD = "confidence_threshold"
    CONTEXT_FIELD_CHECK = "context_field_check"
    REGEX_MATCH = "regex_match"
    JSON_PATH_CHECK = "json_path_check"
    VALUE_RANGE = "value_range"


class GuardrailRule(BaseModel):
    name: str
    rule_type: GuardrailType
    enforcement_level: EnforcementLevel = EnforcementLevel.WARN
    rule_config: dict
    agent_id: Optional[str] = None
    environment: Optional[str] = None
    is_active: bool = True
    priority: int = 0


class GuardrailResult(BaseModel):
    name: str
    rule_type: str
    enforcement_level: str
    triggered: bool
    message: Optional[str] = None


class EvaluationResults(BaseModel):
    results: List[GuardrailResult] = []
    blocked: bool = False
    blocking_rule: Optional[str] = None
    warnings: List[str] = []
    triggered_count: int = 0


class GuardrailEvaluator:
    """Client-side guardrail evaluator for pre-flight checks."""

    def __init__(self):
        self._rules: List[GuardrailRule] = []

    def add_rule(self, rule: GuardrailRule):
        self._rules.append(rule)

    def clear_rules(self):
        self._rules.clear()

    def sync_from_server(self, client: "TenetClient"):
        """Fetch guardrails from the server and populate local rules."""
        self.clear_rules()
        guardrails = client.list_guardrails(is_active=True)
        for g in guardrails:
            rule = GuardrailRule(
                name=g["name"],
                rule_type=g["rule_type"],
                enforcement_level=g["enforcement_level"],
                rule_config=g["rule_config"],
                agent_id=g.get("agent_id"),
                environment=g.get("environment"),
                is_active=g.get("is_active", True),
                priority=g.get("priority", 0),
            )
            self._rules.append(rule)

    def evaluate(
        self,
        chosen_action: str,
        confidence: float,
        context_inputs: Optional[dict] = None,
        agent_id: Optional[str] = None,
        environment: Optional[str] = None,
    ) -> EvaluationResults:
        """Run all rules locally and return results."""
        context_inputs = context_inputs or {}
        decision_data = {
            "chosen_action": chosen_action,
            "confidence": confidence,
        }

        # Filter and sort rules
        active_rules = [r for r in self._rules if r.is_active]

        # Filter by scope
        filtered = []
        for r in active_rules:
            if r.agent_id and agent_id and r.agent_id != agent_id:
                continue
            if r.environment and environment and r.environment != environment:
                continue
            filtered.append(r)

        # Sort by priority descending
        filtered.sort(key=lambda r: r.priority, reverse=True)

        results = []
        blocked = False
        blocking_rule = None
        warnings = []
        triggered_count = 0

        for rule in filtered:
            try:
                triggered, message = self._evaluate_rule(rule, decision_data, context_inputs)
            except Exception as e:
                triggered = False
                message = f"Evaluation error: {str(e)}"

            result = GuardrailResult(
                name=rule.name,
                rule_type=rule.rule_type.value if hasattr(rule.rule_type, 'value') else rule.rule_type,
                enforcement_level=rule.enforcement_level.value if hasattr(rule.enforcement_level, 'value') else rule.enforcement_level,
                triggered=triggered,
                message=message if triggered else None,
            )
            results.append(result)

            if triggered:
                triggered_count += 1
                level = rule.enforcement_level.value if hasattr(rule.enforcement_level, 'value') else rule.enforcement_level
                if level == "block" and not blocked:
                    blocked = True
                    blocking_rule = rule.name
                elif level == "warn":
                    warnings.append(message)

        return EvaluationResults(
            results=results,
            blocked=blocked,
            blocking_rule=blocking_rule,
            warnings=warnings,
            triggered_count=triggered_count,
        )

    def _evaluate_rule(
        self, rule: GuardrailRule, decision_data: dict, context_inputs: dict
    ) -> tuple:
        rule_type = rule.rule_type.value if hasattr(rule.rule_type, 'value') else rule.rule_type
        config = rule.rule_config

        evaluators = {
            "action_allowlist": self._eval_action_allowlist,
            "action_blocklist": self._eval_action_blocklist,
            "confidence_threshold": self._eval_confidence_threshold,
            "context_field_check": self._eval_context_field_check,
            "regex_match": self._eval_regex_match,
            "json_path_check": self._eval_json_path_check,
            "value_range": self._eval_value_range,
        }

        evaluator = evaluators.get(rule_type)
        if not evaluator:
            return False, f"Unknown rule type: {rule_type}"

        return evaluator(config, decision_data, context_inputs)

    # ── Per-type evaluators (mirrored from server) ──

    def _eval_action_allowlist(self, config, decision_data, context_inputs):
        allowed = config.get("allowed_actions", [])
        chosen = decision_data.get("chosen_action", "")
        if chosen not in allowed:
            return True, f"Action '{chosen}' not in allowed list: {allowed}"
        return False, ""

    def _eval_action_blocklist(self, config, decision_data, context_inputs):
        blocked = config.get("blocked_actions", [])
        chosen = decision_data.get("chosen_action", "")
        if chosen in blocked:
            return True, f"Action '{chosen}' is blocked"
        return False, ""

    def _eval_confidence_threshold(self, config, decision_data, context_inputs):
        min_conf = config.get("min_confidence", 0.0)
        confidence = decision_data.get("confidence", 1.0)
        if confidence < min_conf:
            return True, f"Confidence {confidence} below threshold {min_conf}"
        return False, ""

    def _eval_context_field_check(self, config, decision_data, context_inputs):
        field = config.get("field", "")
        operator = config.get("operator", "eq")
        expected = config.get("value")

        actual = self._resolve_field(field, decision_data, context_inputs)
        if actual is None:
            return False, f"Field '{field}' not found"

        triggered = self._apply_operator(actual, operator, expected)
        if triggered:
            return True, f"Field '{field}' ({actual}) {operator} {expected}"
        return False, ""

    def _eval_regex_match(self, config, decision_data, context_inputs):
        field = config.get("field", "chosen_action")
        pattern = config.get("pattern", "")
        negate = config.get("negate", False)

        value = self._resolve_field(field, decision_data, context_inputs)
        if value is None:
            return False, f"Field '{field}' not found"

        match = bool(re.search(pattern, str(value)))
        triggered = (not match) if negate else match

        if triggered:
            action = "did not match" if negate else "matched"
            return True, f"Field '{field}' value '{value}' {action} pattern '{pattern}'"
        return False, ""

    def _eval_json_path_check(self, config, decision_data, context_inputs):
        json_path = config.get("json_path", "")
        operator = config.get("operator", "eq")
        expected = config.get("expected")

        actual = self._resolve_dot_path(json_path, context_inputs)
        if actual is None:
            return False, f"Path '{json_path}' not found"

        triggered = self._apply_operator(actual, operator, expected)
        if triggered:
            return True, f"Path '{json_path}' ({actual}) {operator} {expected}"
        return False, ""

    def _eval_value_range(self, config, decision_data, context_inputs):
        field = config.get("field", "confidence")
        min_val = config.get("min")
        max_val = config.get("max")

        value = self._resolve_field(field, decision_data, context_inputs)
        if value is None:
            return False, f"Field '{field}' not found"

        try:
            value = float(value)
        except (TypeError, ValueError):
            return False, f"Field '{field}' is not numeric"

        if min_val is not None and value < float(min_val):
            return True, f"Field '{field}' ({value}) below minimum {min_val}"
        if max_val is not None and value > float(max_val):
            return True, f"Field '{field}' ({value}) above maximum {max_val}"
        return False, ""

    # ── Helpers ──

    def _resolve_field(self, field, decision_data, context_inputs):
        if "." not in field and field in decision_data:
            return decision_data[field]
        if field.startswith("inputs."):
            return self._resolve_dot_path(field[7:], context_inputs)
        result = self._resolve_dot_path(field, decision_data)
        if result is not None:
            return result
        return self._resolve_dot_path(field, context_inputs)

    def _resolve_dot_path(self, path, data):
        if not data or not path:
            return None
        parts = path.split(".")
        current = data
        for part in parts:
            if isinstance(current, dict) and part in current:
                current = current[part]
            else:
                return None
        return current

    def _apply_operator(self, actual, operator, expected):
        try:
            if operator == "eq":
                return actual == expected
            elif operator == "neq":
                return actual != expected
            elif operator == "gt":
                return float(actual) > float(expected)
            elif operator == "gte":
                return float(actual) >= float(expected)
            elif operator == "lt":
                return float(actual) < float(expected)
            elif operator == "lte":
                return float(actual) <= float(expected)
            elif operator == "in":
                return actual in expected
            elif operator == "not_in":
                return actual not in expected
            elif operator == "contains":
                return expected in actual
            else:
                return False
        except (TypeError, ValueError):
            return False
