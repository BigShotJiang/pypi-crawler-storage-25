from contextlib import contextmanager
from typing import Callable, Optional, List
from uuid import uuid4

from .client import (
    TenetClient,
    ActionOption,
    OriginType,
    ResultType,
    ActorType,
    ReplayConfig,
)
from .decorators import track
from .context import ContextBuilder, snapshot_context
from .guardrails import (
    GuardrailEvaluator,
    GuardrailRule,
    GuardrailResult,
    EvaluationResults,
    EnforcementLevel,
    GuardrailType,
)

__all__ = [
    "TenetClient",
    "ActionOption",
    "OriginType",
    "ResultType",
    "ActorType",
    "ReplayConfig",
    "track",
    "ContextBuilder",
    "snapshot_context",
    "init",
    "trace",
    "replay",
    "flush",
    "shutdown",
    "GuardrailEvaluator",
    "GuardrailRule",
    "GuardrailResult",
    "EvaluationResults",
    "EnforcementLevel",
    "GuardrailType",
]
__version__ = "0.5.0"


# ── Module-level API (matches landing page docs) ─────────────

_client: Optional[TenetClient] = None


def init(
    api_key: str,
    environment: str = "production",
    endpoint: str = "https://ael-backend.onrender.com",
    flush_interval: float = 5.0,
    timeout: float = 30.0,
    async_writes: bool = True,
    on_error: Optional[Callable[[Exception, dict], None]] = None,
):
    """
    Initialize the global Tenet AI client. Call once at application startup.

    Usage:
        import tenet
        tenet.init(api_key="tnt_your_key")
    """
    global _client
    _client = TenetClient(
        api_key=api_key,
        endpoint=endpoint,
        timeout=timeout,
        async_writes=async_writes,
        on_error=on_error,
    )
    _client._environment = environment
    _client._flush_interval = flush_interval


def _get_client() -> TenetClient:
    if _client is None:
        raise RuntimeError(
            "Tenet AI not initialized. Call tenet.init(api_key='...') first."
        )
    return _client


def flush(timeout: float = 10.0) -> None:
    """Block until all queued writes are sent. Useful in tests."""
    _get_client().flush(timeout)


def shutdown() -> None:
    """Flush remaining writes and stop the background worker."""
    _get_client().shutdown()


@contextmanager
def trace(
    agent_id: str,
    metadata: Optional[dict] = None,
    tags: Optional[List[str]] = None,
    session_id: Optional[str] = None,
):
    """
    Capture a decision. Use as a context manager.

    Usage:
        import tenet

        tenet.init(api_key="tnt_your_key")

        with tenet.trace(agent_id="finance-bot-v1") as decision:
            response = agent.run(prompt)
            # decision context captured automatically
    """
    client = _get_client()
    sid = session_id or str(uuid4())
    environment = getattr(client, "_environment", "production")

    with client.intent(
        goal=f"trace:{agent_id}",
        agent_id=agent_id,
        session_id=sid,
        origin=OriginType.AGENT,
    ) as intent:
        # Snapshot initial context with metadata/tags
        intent.snapshot_context(
            inputs={
                "agent_id": agent_id,
                "metadata": metadata or {},
                "tags": tags or [],
                "environment": environment,
            }
        )

        # Expose a simple decision object to the caller
        decision = _TraceDecision(intent, agent_id, tags=tags, metadata=metadata)
        yield decision

        # Auto-finalize if the user didn't explicitly call decide/execute
        decision._auto_finalize()


def replay(
    decision_id: str,
    compare: bool = True,
) -> dict:
    """
    Re-execute a past decision and compare outputs.

    Usage:
        result = tenet.replay(decision_id="d7f8a2c1", compare=True)
        print(result["drift_score"])
        print(result["diff"])
    """
    client = _get_client()
    return client.replay(
        execution_id=decision_id,
        force_llm_call=compare,
    )


class _TraceDecision:
    """Wrapper yielded by tenet.trace() for a simple docs-friendly API."""

    def __init__(self, intent, agent_id, tags=None, metadata=None):
        self._intent = intent
        self._agent_id = agent_id
        self._tags = tags
        self._metadata = metadata
        self._decided = False
        self._executed = False
        self.execution_id = None
        self.decision_id = None

    def decide(
        self,
        chosen_action: str,
        confidence: float = 1.0,
        reasoning: str = "",
        options: Optional[List[dict]] = None,
        replay_prompt: Optional[str] = None,
        replay_config: Optional[ReplayConfig] = None,
    ):
        """Record the decision."""
        action_options = []
        if options:
            for opt in options:
                action_options.append(ActionOption(
                    action=opt.get("action", chosen_action),
                    score=opt.get("score", confidence),
                    reason=opt.get("reason"),
                ))
        else:
            action_options.append(ActionOption(
                action=chosen_action, score=confidence
            ))

        self._intent.decide(
            options=action_options,
            chosen_action=chosen_action,
            confidence=confidence,
            reasoning=reasoning,
            replay_prompt=replay_prompt,
            replay_config=replay_config,
        )
        self.decision_id = self._intent.decision_id
        self._decided = True

    def execute(
        self,
        action: Optional[str] = None,
        target: Optional[dict] = None,
        result: ResultType = ResultType.SUCCESS,
        actor: ActorType = ActorType.AGENT,
    ):
        """Record the execution."""
        if not self._decided:
            raise RuntimeError("Call decision.decide() before decision.execute()")
        self.execution_id = self._intent.execute(
            action=action or self._agent_id,
            target=target or {},
            result=result,
            actor=actor,
        )
        self._executed = True

    def _auto_finalize(self):
        """Auto-record a default decision+execution if user didn't call them."""
        if not self._decided:
            self._intent.decide(
                options=[ActionOption(action=self._agent_id, score=1.0)],
                chosen_action=self._agent_id,
                confidence=1.0,
                reasoning="auto-traced",
            )
            self.decision_id = self._intent.decision_id
            self._decided = True
        if not self._executed:
            self.execution_id = self._intent.execute(
                action=self._agent_id,
                target={},
                result=ResultType.SUCCESS,
            )
            self._executed = True
