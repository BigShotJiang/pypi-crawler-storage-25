# SPDX-License-Identifier: MIT
"""xAI / call_llm failure-mode tests.

Documents the behavior of ``call_llm`` under every xAI failure class:
socket hang, timeout, rate limit (429), server error (5xx), malformed
response bodies. Pre-v0.2.17 the answer lived only in the source code
— no tests exercised the timeout / 429 / 5xx / malformed-response
branches. This file pins the expected behavior so future refactors
can't silently break failure handling.

Every test mocks ``opsec_urlopen`` (via the ``core.http`` module where
it lives) and the ``persist_cost`` import to avoid touching the real
network or real DB.
"""

from __future__ import annotations

import json
import urllib.error
from unittest.mock import MagicMock, patch

import pytest

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _http_error(code: int, msg: str = "error") -> urllib.error.HTTPError:
    """Build a real urllib.error.HTTPError instance."""
    return urllib.error.HTTPError(
        url="https://api.x.ai/v1/chat/completions",
        code=code,
        msg=msg,
        hdrs=None,  # type: ignore[arg-type]
        fp=None,
    )


def _make_response(payload: dict | bytes) -> MagicMock:
    """Build a context-manager-style mock urllib response."""
    if isinstance(payload, dict):
        body = json.dumps(payload).encode()
    else:
        body = payload
    resp = MagicMock()
    resp.read = MagicMock(return_value=body)
    resp.__enter__ = MagicMock(return_value=resp)
    resp.__exit__ = MagicMock(return_value=False)
    return resp


@pytest.fixture(autouse=True)
def fake_api_key(monkeypatch):
    """Most tests need the API key gate to pass."""
    monkeypatch.setenv("XAI_API_KEY", "xai-test-fake-key")
    # Bypass the prompt cache so every test exercises the network path.
    yield


@pytest.fixture(autouse=True)
def no_real_cost_writes(monkeypatch):
    """Prevent persist_cost from touching the real DB."""

    def _noop(**_kwargs):
        return None

    monkeypatch.setattr("core.persist_to_db.persist_cost", _noop, raising=False)


@pytest.fixture(autouse=True)
def no_cache_lookup(monkeypatch):
    """Force every test to skip the cache and exercise the HTTP path."""

    def _miss(*_args, **_kwargs):
        return None

    monkeypatch.setattr("core.llm_cache.lookup", _miss, raising=False)
    monkeypatch.setattr("core.llm_cache.store", lambda *a, **k: None, raising=False)


@pytest.fixture(autouse=True)
def reset_circuit_breaker_each_test():
    """Reset the circuit breaker before AND after every test in this file.

    Without this, tests in TestNetworkFailures and TestHTTPErrors would
    exhaust the failure threshold and open the breaker, causing every
    later test to short-circuit and return None without making any HTTP
    call. The TestCircuitBreaker class has its own narrower fixture for
    its specific assertions; this one keeps the rest of the file clean.
    """
    from core.llm_provider import reset_circuit_breaker

    reset_circuit_breaker()
    yield
    reset_circuit_breaker()


# ---------------------------------------------------------------------------
# Happy path baseline (sanity check that the mocking actually works)
# ---------------------------------------------------------------------------


class TestHappyPath:
    def test_valid_response_returns_dict(self):
        """A normal xAI response returns a dict with text/cost/tokens/model."""
        from core.llm_provider import call_llm

        payload = {
            "choices": [{"message": {"content": "hello world"}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(payload)):
            result = call_llm("test prompt", cache_ttl_seconds=0)

        assert result is not None
        assert result["text"] == "hello world"
        assert result["input_tokens"] == 10
        assert result["output_tokens"] == 5
        assert "cost_usd" in result
        assert "model" in result


# ---------------------------------------------------------------------------
# Configuration failures
# ---------------------------------------------------------------------------


class TestConfigurationFailures:
    def test_missing_api_key_returns_none(self, monkeypatch):
        """Without XAI_API_KEY set, call_llm must return None (no crash)."""
        from core.llm_provider import call_llm

        monkeypatch.delenv("XAI_API_KEY", raising=False)
        with patch("core.http.opsec_urlopen") as mock_http:
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 0, "Must not make any HTTP call when API key is missing"

    def test_empty_api_key_returns_none(self, monkeypatch):
        """An empty XAI_API_KEY string is the same as missing."""
        from core.llm_provider import call_llm

        monkeypatch.setenv("XAI_API_KEY", "")
        with patch("core.http.opsec_urlopen") as mock_http:
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 0


# ---------------------------------------------------------------------------
# Network failures (timeouts, hangs, connection issues)
# ---------------------------------------------------------------------------


class TestNetworkFailures:
    def test_socket_timeout_is_retried_then_returns_none(self):
        """A timeout on every attempt must NOT crash — return None after retries."""
        import socket

        from core.llm_provider import call_llm

        with (
            patch("core.http.opsec_urlopen", side_effect=TimeoutError("read timeout")),
            patch("core.llm_provider.time.sleep") as mock_sleep,  # skip the backoff
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        # 3 attempts → 3 sleeps (one per retry, even the last one)
        assert mock_sleep.call_count >= 2, "Must back off between retries on network failure"

    def test_url_error_is_retried_then_returns_none(self):
        """A connection refused / DNS failure must be caught and retried."""
        from core.llm_provider import call_llm

        with (
            patch(
                "core.http.opsec_urlopen",
                side_effect=urllib.error.URLError("connection refused"),
            ),
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None

    def test_generic_oserror_is_retried_then_returns_none(self):
        """Any OS-level error (e.g., broken pipe) must not crash the caller."""
        from core.llm_provider import call_llm

        with (
            patch("core.http.opsec_urlopen", side_effect=OSError("broken pipe")),
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None

    def test_retry_count_is_three(self):
        """Confirm the retry budget is exactly 3 attempts."""
        from core.llm_provider import call_llm

        with (
            patch(
                "core.http.opsec_urlopen",
                side_effect=urllib.error.URLError("net down"),
            ) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            call_llm("test", cache_ttl_seconds=0)

        assert mock_http.call_count == 3, f"Expected 3 retry attempts, got {mock_http.call_count}"


# ---------------------------------------------------------------------------
# HTTP error responses
# ---------------------------------------------------------------------------


class TestHTTPErrors:
    def test_429_rate_limit_is_retried(self):
        """HTTP 429 must trigger exponential-backoff retry, not immediate fail."""
        from core.llm_provider import call_llm

        with (
            patch(
                "core.http.opsec_urlopen", side_effect=_http_error(429, "rate limited")
            ) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 3, "429 must be retried 3 times"

    @pytest.mark.parametrize("code", [502, 503, 529])
    def test_5xx_transient_errors_are_retried(self, code):
        """502, 503, 529 are transient — must be retried."""
        from core.llm_provider import call_llm

        with (
            patch(
                "core.http.opsec_urlopen", side_effect=_http_error(code, "transient")
            ) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 3, f"HTTP {code} must be retried 3 times"

    def test_401_unauthorized_returns_immediately(self):
        """HTTP 401 (bad API key) must NOT retry — fail fast."""
        from core.llm_provider import call_llm

        with (
            patch(
                "core.http.opsec_urlopen", side_effect=_http_error(401, "unauthorized")
            ) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 1, "401 must not be retried"

    def test_400_bad_request_returns_immediately(self):
        """HTTP 400 (malformed request) must NOT retry."""
        from core.llm_provider import call_llm

        with (
            patch(
                "core.http.opsec_urlopen", side_effect=_http_error(400, "bad request")
            ) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 1


# ---------------------------------------------------------------------------
# Malformed response bodies — the defensive parser branches
# ---------------------------------------------------------------------------


class TestMalformedResponses:
    def test_non_dict_response_does_not_crash(self):
        """If xAI returns a JSON list instead of an object, retry then None."""
        from core.llm_provider import call_llm

        bad = _make_response([])  # JSON list, not dict
        with (
            patch("core.http.opsec_urlopen", return_value=bad),
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)
        assert result is None

    def test_invalid_json_does_not_crash(self):
        """A response that isn't JSON at all must be caught."""
        from core.llm_provider import call_llm

        bad = _make_response(b"<html>500 internal</html>")
        with (
            patch("core.http.opsec_urlopen", return_value=bad),
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)
        assert result is None

    def test_error_payload_returns_none_without_retry(self):
        """An xAI error body must NOT trigger 3 retries — fail fast."""
        from core.llm_provider import call_llm

        payload = {"error": {"message": "model not available", "type": "invalid_request"}}
        with (
            patch("core.http.opsec_urlopen", return_value=_make_response(payload)) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 1, "Error body must not trigger retries (it's deterministic)"

    def test_empty_choices_list_does_not_crash(self):
        """Response with no choices must be handled."""
        from core.llm_provider import call_llm

        payload = {"choices": [], "usage": {"prompt_tokens": 0, "completion_tokens": 0}}
        with (
            patch("core.http.opsec_urlopen", return_value=_make_response(payload)),
            patch("core.llm_provider.time.sleep"),
        ):
            result = call_llm("test", cache_ttl_seconds=0)
        assert result is None

    def test_missing_message_field_does_not_crash(self):
        """Response with choices but no message field — handled."""
        from core.llm_provider import call_llm

        payload = {
            "choices": [{"finish_reason": "stop"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 0},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(payload)):
            result = call_llm("test", cache_ttl_seconds=0)

        # Missing message → empty string content, but call still succeeds
        assert result is not None
        assert result["text"] == ""

    def test_null_content_returns_empty_string(self):
        """Some models return content=null with finish_reason=length."""
        from core.llm_provider import call_llm

        payload = {
            "choices": [
                {
                    "message": {"content": None},
                    "finish_reason": "length",
                }
            ],
            "usage": {"prompt_tokens": 100, "completion_tokens": 1000},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(payload)):
            result = call_llm("test", cache_ttl_seconds=0)

        # Null content normalizes to None then to "" — caller gets a usable dict
        assert result is not None
        assert result["text"] in ("", None)

    def test_message_is_not_a_dict(self):
        """A response where message is a string instead of {content: ...}."""
        from core.llm_provider import call_llm

        payload = {
            "choices": [{"message": "string instead of dict"}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(payload)):
            result = call_llm("test", cache_ttl_seconds=0)

        # Defensive parser must handle this — empty content, not a crash
        assert result is not None

    def test_choices_is_not_a_list(self):
        """A response where choices is a dict instead of a list.

        The defensive parser handles this by treating it as "no first
        choice" — returns a result dict with empty text rather than
        crashing or retrying. Pinned here so future refactors don't
        accidentally make it crash.
        """
        from core.llm_provider import call_llm

        payload = {
            "choices": {"oops": "not a list"},
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(payload)):
            result = call_llm("test", cache_ttl_seconds=0)
        # Defensive parser treats dict-shaped choices as "no first choice"
        # and returns an empty-text result rather than crashing.
        assert result is not None
        assert result["text"] in ("", None)


# ---------------------------------------------------------------------------
# Documenting the worst-case latency budget
# ---------------------------------------------------------------------------


class TestRetryBudget:
    """Pin the time budget so future "let's add more retries" PRs see it.

    With 3 retries, exponential backoff (2^attempt seconds), and a 120s
    socket timeout, the worst-case wall time for a single call_llm()
    invocation is roughly:

        attempt 1 timeout (120s) + sleep(2s) +
        attempt 2 timeout (120s) + sleep(4s) +
        attempt 3 timeout (120s) + sleep(8s, capped at 30) =
        ~360s socket time + ~14s sleep
        = ~374s = ~6.2 minutes

    With the 16-worker parallel runner this means up to 16 engines can be
    blocked simultaneously for 6+ minutes if xAI is hung. That is the
    documented worst case. If anyone bumps the retry count or timeout
    they should also bump this assertion.
    """

    def test_retry_count_is_exactly_three(self):
        """If you bump retries above 3, update the worst-case-budget docstring."""
        import core.llm_provider as llm

        # Look for the magic number in source so a refactor that hides
        # it behind a constant still passes (we just need it to be 3 in
        # behavior).
        with (
            patch("core.http.opsec_urlopen", side_effect=OSError("hang")) as mock_http,
            patch("core.llm_provider.time.sleep"),
        ):
            llm.call_llm("test", cache_ttl_seconds=0)

        assert mock_http.call_count == 3, (
            f"Retry count drift detected: expected 3 attempts, got "
            f"{mock_http.call_count}. If this is intentional, update the "
            f"worst-case latency budget in the docstring above."
        )

    def test_timeout_is_120_seconds(self):
        """The socket timeout per attempt is 120s."""
        from core.llm_provider import call_llm

        captured_timeout: list[int] = []

        def capture(req, timeout, **kwargs):
            captured_timeout.append(timeout)
            raise OSError("immediate fail")

        with (
            patch("core.http.opsec_urlopen", side_effect=capture),
            patch("core.llm_provider.time.sleep"),
        ):
            call_llm("test", cache_ttl_seconds=0)

        assert all(t == 120 for t in captured_timeout), (
            f"Timeout drift: expected 120s per call, got {captured_timeout}"
        )


# ---------------------------------------------------------------------------
# Circuit breaker (v0.2.18)
# ---------------------------------------------------------------------------


class TestCircuitBreaker:
    """The circuit breaker prevents 16 workers from stalling 6+ minutes each.

    Pattern: after N consecutive failures, the breaker OPENS and every
    subsequent ``call_llm()`` returns None immediately (no network call).
    A success closes the breaker; a failure keeps it open.
    """

    @pytest.fixture(autouse=True)
    def reset_breaker(self):
        from core.llm_provider import reset_circuit_breaker

        reset_circuit_breaker()
        yield
        reset_circuit_breaker()

    def test_breaker_opens_after_threshold_failures(self):
        from core.llm_provider import (
            CIRCUIT_FAILURE_THRESHOLD,
            _circuit_is_open,
            call_llm,
        )

        with (
            patch("core.http.opsec_urlopen", side_effect=OSError("hang")),
            patch("core.llm_provider.time.sleep"),
        ):
            for _ in range(CIRCUIT_FAILURE_THRESHOLD):
                call_llm("test", cache_ttl_seconds=0)

        assert _circuit_is_open(), f"Breaker must OPEN after {CIRCUIT_FAILURE_THRESHOLD} failures"

    def test_open_breaker_short_circuits_subsequent_calls(self):
        from core.llm_provider import CIRCUIT_FAILURE_THRESHOLD, call_llm

        with (
            patch("core.http.opsec_urlopen", side_effect=OSError("hang")),
            patch("core.llm_provider.time.sleep"),
        ):
            for _ in range(CIRCUIT_FAILURE_THRESHOLD):
                call_llm("test", cache_ttl_seconds=0)

        with patch("core.http.opsec_urlopen") as mock_http:
            result = call_llm("post-trip", cache_ttl_seconds=0)

        assert result is None
        assert mock_http.call_count == 0

    def test_success_resets_the_breaker(self):
        from core import llm_provider as llm

        with (
            patch("core.http.opsec_urlopen", side_effect=OSError("hang")),
            patch("core.llm_provider.time.sleep"),
        ):
            for _ in range(3):
                llm.call_llm("test", cache_ttl_seconds=0)

        assert llm._circuit_consecutive_failures == 3

        good_payload = {
            "choices": [{"message": {"content": "ok"}}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(good_payload)):
            result = llm.call_llm("test", cache_ttl_seconds=0)

        assert result is not None
        assert llm._circuit_consecutive_failures == 0

    def test_breaker_does_not_block_first_call(self):
        from core.llm_provider import _circuit_is_open, call_llm

        assert not _circuit_is_open()

        good_payload = {
            "choices": [{"message": {"content": "first"}}],
            "usage": {"prompt_tokens": 1, "completion_tokens": 1},
        }
        with patch("core.http.opsec_urlopen", return_value=_make_response(good_payload)):
            result = call_llm("test", cache_ttl_seconds=0)
        assert result is not None

    def test_reset_circuit_breaker_clears_state(self):
        from core.llm_provider import (
            CIRCUIT_FAILURE_THRESHOLD,
            _circuit_is_open,
            call_llm,
            reset_circuit_breaker,
        )

        with (
            patch("core.http.opsec_urlopen", side_effect=OSError("hang")),
            patch("core.llm_provider.time.sleep"),
        ):
            for _ in range(CIRCUIT_FAILURE_THRESHOLD):
                call_llm("test", cache_ttl_seconds=0)
        assert _circuit_is_open()

        reset_circuit_breaker()
        assert not _circuit_is_open()
