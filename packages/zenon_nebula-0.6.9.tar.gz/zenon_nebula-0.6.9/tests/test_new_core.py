# SPDX-License-Identifier: MIT
"""Tests for new core modules added to Nebula.

Covers: hypothesis_engine, peer_corroboration, transport, git_cache,
engine_scheduler, explorer_api, universal_rpc, mcp_bridge, github_api,
market_data, vuln_feed.
"""

import json
import os
import sqlite3
import sys
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

NEBULA_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(NEBULA_ROOT))

os.environ.setdefault("ZENON_WORKSPACE_ROOT", os.path.expanduser("~/Repos/Zenon"))


@pytest.fixture
def fresh_db(tmp_path):
    """Create a fresh database with full schema."""
    db_path = str(tmp_path / "test.db")
    from core.persist_to_db import ensure_schema

    ensure_schema(db_path)
    return db_path


@pytest.fixture
def seeded_db(fresh_db):
    """Database with evidence seeded for hypothesis/corroboration tests."""
    conn = sqlite3.connect(fresh_db)
    # Insert evidence from different engines/domains
    for i in range(5):
        conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence,
                source_repo, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
            (
                "security",
                f"engine_{i}",
                "vulnerability",
                f"Bridge reentrancy risk in portal contract #{i}",
                0.7 + i * 0.05,
                "go-zenon",
            ),
        )
    # Add some upstream commit evidence
    for i in range(4):
        conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence,
                source_repo, timestamp)
               VALUES (?, ?, ?, ?, ?, ?, datetime('now'))""",
            (
                "intelligence",
                f"watcher_{i}",
                "upstream_commit",
                f"Major breaking refactor in go-zenon module {i}",
                0.8,
                "go-zenon",
            ),
        )
    conn.commit()
    conn.close()
    return fresh_db


# ========== hypothesis_engine ==========


class TestHypothesisEngine:
    def test_evolve_no_evidence(self, fresh_db):
        """Evolve returns zeros when no evidence exists."""
        from core.hypothesis_engine import evolve

        result = evolve(db_path=fresh_db)
        assert result["created"] == 0
        assert result["linked"] == 0
        assert result["retired"] == 0
        assert result["promoted"] == 0

    def test_evolve_creates_hypotheses(self, seeded_db):
        """Evolve creates hypotheses from evidence clusters."""
        from core.hypothesis_engine import evolve

        result = evolve(db_path=seeded_db)
        # With 5 security findings from different engines, should create
        # a security_cluster hypothesis
        assert result["patterns_checked"] > 0
        assert result["evidence_scanned"] > 0
        # May or may not create depending on MIN_CLUSTER_SIZE
        assert isinstance(result["created"], int)
        assert isinstance(result["linked"], int)

    def test_evolve_links_evidence(self, seeded_db):
        """Evolve links evidence to hypotheses."""
        from core.hypothesis_engine import evolve

        result = evolve(db_path=seeded_db)
        # If hypotheses were created, evidence should be linked
        if result["created"] > 0:
            assert result["linked"] > 0

    def test_lifecycle_retire_low_confidence(self, fresh_db):
        """Lifecycle retires low-confidence old hypotheses."""
        from core.hypothesis_engine import _manage_lifecycle

        conn = sqlite3.connect(fresh_db)
        # Insert old low-confidence hypothesis
        conn.execute(
            """INSERT INTO hypotheses (id, domain, title, confidence, status, last_updated)
               VALUES (?, ?, ?, ?, ?, datetime('now', '-30 days'))""",
            ("H_test_old", "test", "Stale hypothesis", 0.01, "INVESTIGATING"),
        )
        conn.commit()
        conn.close()

        result = _manage_lifecycle(fresh_db)
        assert result["retired"] >= 1

    def test_lifecycle_promote_high_confidence(self, fresh_db):
        """Lifecycle promotes high-confidence hypotheses."""
        from core.hypothesis_engine import _manage_lifecycle

        conn = sqlite3.connect(fresh_db)
        conn.execute(
            """INSERT INTO hypotheses (id, domain, title, confidence, status, last_updated)
               VALUES (?, ?, ?, ?, ?, datetime('now'))""",
            ("H_test_strong", "test", "Strong hypothesis", 0.95, "INVESTIGATING"),
        )
        conn.commit()
        conn.close()

        result = _manage_lifecycle(fresh_db)
        assert result["promoted"] >= 1

    def test_patterns_list_non_empty(self):
        """PATTERNS registry has entries."""
        from core.hypothesis_engine import PATTERNS

        assert len(PATTERNS) >= 6

    def test_pattern_functions_callable(self):
        """All pattern match functions are callable with empty input."""
        from core.hypothesis_engine import PATTERNS

        for pattern in PATTERNS:
            result = pattern["match"]([])
            assert isinstance(result, list)


# ========== peer_corroboration ==========


class TestPeerCorroboration:
    def test_similarity_identical(self):
        """Identical strings have similarity 1.0."""
        from core.peer_corroboration import _similarity

        assert _similarity("bridge reentrancy risk", "bridge reentrancy risk") == 1.0

    def test_similarity_empty(self):
        """Empty strings have similarity 0.0."""
        from core.peer_corroboration import _similarity

        assert _similarity("", "") == 0.0
        assert _similarity("something", "") == 0.0

    def test_similarity_different(self):
        """Completely different strings have low similarity."""
        from core.peer_corroboration import _similarity

        sim = _similarity(
            "bridge reentrancy vulnerability in portal",
            "staking reward calculation has overflow bug",
        )
        # These are unrelated findings, should have low similarity
        assert sim < 0.5

    def test_similarity_similar(self):
        """Similar findings have high similarity."""
        from core.peer_corroboration import _similarity

        sim = _similarity(
            "WHAT: Portal bridge has potential reentrancy in deposit function",
            "WHAT: Portal bridge reentrancy risk detected in deposit handler",
        )
        assert sim > 0.3  # Should detect overlap

    def test_bayesian_combine_single(self):
        """Single confidence passes through unchanged."""
        from core.peer_corroboration import _bayesian_combine

        assert _bayesian_combine([0.8]) == 0.8

    def test_bayesian_combine_empty(self):
        """Empty list returns 0.0."""
        from core.peer_corroboration import _bayesian_combine

        assert _bayesian_combine([]) == 0.0

    def test_bayesian_combine_boosts(self):
        """Multiple confirmations boost confidence above any individual."""
        from core.peer_corroboration import _bayesian_combine

        combined = _bayesian_combine([0.7, 0.7, 0.7])
        assert combined > 0.7
        assert combined <= 0.99

    def test_bayesian_combine_cap(self):
        """Combined confidence is capped at 0.99."""
        from core.peer_corroboration import _bayesian_combine

        combined = _bayesian_combine([0.95, 0.95, 0.95])
        assert combined <= 0.99

    def test_find_corroborations_empty(self, fresh_db):
        """Empty DB returns no corroborations."""
        from core.peer_corroboration import find_corroborations

        result = find_corroborations(fresh_db)
        assert result == []

    def test_find_corroborations_groups_similar(self, fresh_db):
        """Similar findings from different engines are grouped."""
        from core.peer_corroboration import find_corroborations

        conn = sqlite3.connect(fresh_db)
        # Insert similar findings from different engines
        for i, engine in enumerate(["scanner_a", "scanner_b", "scanner_c"]):
            conn.execute(
                """INSERT INTO evidence
                   (domain, engine, finding, confidence)
                   VALUES (?, ?, ?, ?)""",
                (
                    "security",
                    engine,
                    f"Portal bridge reentrancy vulnerability in deposit function version {i}",
                    0.7 + i * 0.05,
                ),
            )
        conn.commit()
        conn.close()

        corrs = find_corroborations(fresh_db)
        # Should find at least one corroboration cluster
        # (depends on similarity threshold)
        assert isinstance(corrs, list)
        if corrs:
            assert corrs[0]["source_count"] >= 2
            assert corrs[0]["combined_confidence"] > 0.7


# ========== transport ==========


class TestTransport:
    def test_local_transport_sync_zeros(self, fresh_db):
        """LocalTransport.sync returns zeros."""
        from core.transport import LocalTransport

        t = LocalTransport(fresh_db)
        result = t.sync()
        assert result["publish"]["published"] == 0
        assert result["pull"]["imported"] == 0

    def test_local_transport_publish(self, fresh_db):
        """LocalTransport.publish is a no-op."""
        from core.transport import LocalTransport

        t = LocalTransport(fresh_db)
        assert t.publish() == {"published": 0}

    def test_local_transport_pull(self, fresh_db):
        """LocalTransport.pull is a no-op."""
        from core.transport import LocalTransport

        t = LocalTransport(fresh_db)
        assert t.pull() == {"imported": 0}

    def test_shared_dir_publish_writes_file(self, fresh_db, tmp_path):
        """SharedDirTransport.publish writes a JSON file to shared dir."""
        from core.transport import SharedDirTransport

        shared = str(tmp_path / "shared")
        t = SharedDirTransport(fresh_db, shared, participant_id="test_node")

        # Seed some high-confidence evidence
        conn = sqlite3.connect(fresh_db)
        conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence, published)
               VALUES (?, ?, ?, ?, ?, 0)""",
            ("development", "spec_tracker", "metric", "Found 14 specs in developer-commons", 0.95),
        )
        conn.commit()
        conn.close()

        result = t.publish()
        assert result["published"] >= 1

        # Check that a JSON file was written
        shared_path = Path(shared)
        json_files = list(shared_path.glob("test_node_*.json"))
        assert len(json_files) >= 1

    def test_shared_dir_publish_sanitizes_findings(self, fresh_db, tmp_path):
        """Regression: SharedDirTransport.publish MUST run sanitize_for_sharing.

        Pre-v0.2.14 the publish path wrote raw ``row["finding"]`` text to
        the shared directory, bypassing OPSECGuard entirely. A finding
        that referenced a local /Users path or a git author line would
        leak to every participant on the shared filesystem. Snapshot
        export was fixed in v0.2.7; this is the parallel fix for
        transport.
        """
        from core.transport import SharedDirTransport

        shared = str(tmp_path / "shared")
        t = SharedDirTransport(fresh_db, shared, participant_id="test_node")

        # Seed a finding with a local path + git author that MUST get scrubbed
        dirty_finding = (
            "Bug at /Users/operator/Repos/Zenon/go-zenon/main.go "
            "Author: Jane Doe <jane@example.com>"
        )
        conn = sqlite3.connect(fresh_db)
        conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence, published)
               VALUES (?, ?, ?, ?, ?, 0)""",
            ("security", "static_analyzer", "bug", dirty_finding, 0.9),
        )
        conn.commit()
        conn.close()

        result = t.publish()
        assert result["published"] >= 1

        # Read the published file and confirm the leak was scrubbed
        json_files = list(Path(shared).glob("test_node_*.json"))
        assert len(json_files) >= 1
        payload = json.loads(json_files[0].read_text())
        published_text = payload[0]["finding"]

        assert "/Users/operator" not in published_text, (
            f"Local path leaked into shared dir: {published_text}"
        )
        assert "jane@example.com" not in published_text, (
            f"Email leaked into shared dir: {published_text}"
        )

    def test_shared_dir_pull_imports(self, fresh_db, tmp_path):
        """SharedDirTransport.pull imports from peer files."""
        from core.transport import SharedDirTransport

        shared = str(tmp_path / "shared")
        os.makedirs(shared, exist_ok=True)

        # Write a peer's findings file
        peer_data = [
            {
                "source": "peer_alice",
                "evidence_id": 1,
                "domain": "security",
                "engine": "alice_scanner",
                "evidence_type": "vulnerability",
                "finding": "Alice found a reentrancy bug",
                "confidence": 0.85,
                "supports_hypothesis": "",
                "contradicts_hypothesis": "",
                "timestamp": "2026-01-01T00:00:00",
                "published_at": "2026-01-01T00:00:00",
            },
        ]
        Path(shared, "peer_alice_20260101_000000.json").write_text(json.dumps(peer_data))

        t = SharedDirTransport(fresh_db, shared, participant_id="test_node")
        result = t.pull()
        assert result["imported"] >= 1

    def test_shared_dir_skips_own_files(self, fresh_db, tmp_path):
        """SharedDirTransport.pull skips files matching its own prefix.

        The prefix is ``{participant_id}_{instance_nonce}_`` so two
        operators running with participant_id="anonymous" don't shadow
        each other. The skip logic has to match the full prefix, not
        just the participant_id.
        """
        from core.transport import SharedDirTransport

        shared = str(tmp_path / "shared")
        os.makedirs(shared, exist_ok=True)

        # Construct the transport first so we can learn the nonce.
        t = SharedDirTransport(fresh_db, shared, participant_id="test_node")

        own_data = [
            {
                "source": "test_node",
                "finding": "My own finding",
                "confidence": 0.9,
                "domain": "test",
                "engine": "test",
            }
        ]
        # File that SHOULD be skipped: matches our full prefix.
        Path(shared, f"{t._file_prefix}20260101_000000_000000.json").write_text(
            json.dumps(own_data)
        )
        # File from a different operator with the same participant_id
        # but a different nonce — this one SHOULD be imported.
        other_data = [
            {
                "source": "test_node",
                "finding": "Peer finding",
                "confidence": 0.9,
                "domain": "test",
                "engine": "test",
            }
        ]
        Path(shared, "test_node_ffff9999_20260101_000000_000000.json").write_text(
            json.dumps(other_data)
        )

        result = t.pull()
        # Skipped own file, imported peer file
        assert result["imported"] == 1
        assert result["duplicates"] == 0

    def test_shared_dir_private_domains_excluded(self, fresh_db, tmp_path):
        """SharedDirTransport does not publish marketing/investigation domains."""
        from core.transport import SharedDirTransport

        shared = str(tmp_path / "shared")
        t = SharedDirTransport(fresh_db, shared, participant_id="test_node")

        # Seed marketing-domain evidence (should NOT be published)
        conn = sqlite3.connect(fresh_db)
        conn.execute(
            """INSERT INTO evidence
               (domain, engine, evidence_type, finding, confidence, published)
               VALUES (?, ?, ?, ?, ?, 0)""",
            ("marketing", "narrative", "insight", "Top secret narrative", 0.95),
        )
        conn.commit()
        conn.close()

        result = t.publish()
        assert result["published"] == 0

    def test_get_transport_local(self, fresh_db):
        """get_transport returns LocalTransport by default."""
        from core.transport import LocalTransport, get_transport

        t = get_transport(fresh_db)
        assert isinstance(t, LocalTransport)

    def test_get_transport_shared(self, fresh_db, tmp_path):
        """get_transport returns SharedDirTransport for 'shared' mode."""
        from core.transport import SharedDirTransport, get_transport

        with patch.dict(
            os.environ,
            {
                "NEBULA_TRANSPORT": "shared",
                "NEBULA_SHARED_DIR": str(tmp_path / "shared"),
                "NEBULA_PARTICIPANT_ID": "tester",
            },
        ):
            t = get_transport(fresh_db, transport_type="shared")
            assert isinstance(t, SharedDirTransport)


class TestPersistenceConnectHelper:
    """Pin the public connect() helper from core.persistence.

    Pre-v0.2.19, 138 raw sqlite3.connect() calls bypassed the helper
    and missed WAL/busy_timeout/cache_size/synchronous pragmas.
    Architecture audit rule R8 enforces the migration; these tests
    pin the helper's behavior so future refactors can't regress it.
    """

    def test_connect_returns_sqlite3_connection(self, tmp_path):
        import sqlite3

        from core.persistence import connect

        conn = connect(str(tmp_path / "t.db"))
        try:
            assert isinstance(conn, sqlite3.Connection)
        finally:
            conn.close()

    def test_connect_applies_wal_mode(self, tmp_path):
        from core.persistence import connect

        conn = connect(str(tmp_path / "wal.db"))
        try:
            mode = conn.execute("PRAGMA journal_mode").fetchone()[0]
            assert mode.lower() == "wal"
        finally:
            conn.close()

    def test_connect_applies_busy_timeout(self, tmp_path):
        from core.persistence import connect

        conn = connect(str(tmp_path / "busy.db"))
        try:
            timeout = conn.execute("PRAGMA busy_timeout").fetchone()[0]
            assert timeout == 5000
        finally:
            conn.close()

    def test_connect_applies_cache_size(self, tmp_path):
        from core.persistence import connect

        conn = connect(str(tmp_path / "cache.db"))
        try:
            cache = conn.execute("PRAGMA cache_size").fetchone()[0]
            assert cache == -64000
        finally:
            conn.close()

    def test_connect_applies_synchronous_normal(self, tmp_path):
        from core.persistence import connect

        conn = connect(str(tmp_path / "sync.db"))
        try:
            sync = conn.execute("PRAGMA synchronous").fetchone()[0]
            assert sync == 1  # NORMAL
        finally:
            conn.close()

    def test_connect_legacy_underscore_alias_still_works(self):
        from core.persistence import _get_connection, connect

        assert _get_connection is connect


class TestTransportSwitchFlow:
    """Verify that switching transports mid-life doesn't lose findings.

    The concrete concern this suite pins: when an operator toggles
    ``NEBULA_TRANSPORT`` between ``local`` and ``shared`` across
    restarts, does sync remain ordered and conflict-free? Pre-v0.2.18
    there was no regression coverage for the transition — pinning it
    here prevents the full class of "works until you flip a flag"
    bugs.

    These tests pin the answer:
    - Switching local → shared → local doesn't lose any findings.
    - Switching shared → local doesn't break the next publish.
    - The instance nonce keeps two anonymous operators on the same shared
      filesystem from shadowing each other.
    - Re-publishing a row that was already published is a no-op (uses the
      ``published`` flag in the evidence table).
    - Importing a peer's findings then re-publishing them does NOT echo
      them back (peer-prefixed engine names are excluded from publish).
    """

    def _seed_finding(
        self,
        db: str,
        *,
        domain: str = "security",
        engine: str = "test",
        text: str = "wat",
    ):
        conn = sqlite3.connect(db)
        try:
            conn.execute(
                """INSERT INTO evidence
                   (domain, engine, evidence_type, finding, confidence, published)
                   VALUES (?, ?, ?, ?, ?, 0)""",
                (domain, engine, "metric", text, 0.9),
            )
            conn.commit()
        finally:
            conn.close()

    def test_local_to_shared_to_local_does_not_lose_findings(self, fresh_db, tmp_path):
        """Switch local → shared → local. All findings still queryable."""
        from core.transport import LocalTransport, SharedDirTransport

        self._seed_finding(fresh_db, text="finding-A")
        self._seed_finding(fresh_db, text="finding-B")

        # Start in local — publish is a no-op
        local = LocalTransport(fresh_db)
        assert local.publish() == {"published": 0}

        # Switch to shared — publishes both findings
        shared = SharedDirTransport(fresh_db, str(tmp_path / "shared"), participant_id="alice")
        result = shared.publish()
        assert result["published"] == 2

        # Switch back to local — DB still has both findings
        conn = sqlite3.connect(fresh_db)
        try:
            count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
            unpublished = conn.execute(
                "SELECT COUNT(*) FROM evidence WHERE published = 0"
            ).fetchone()[0]
        finally:
            conn.close()
        assert count == 2, "Switching transports must not delete findings"
        assert unpublished == 0, "All findings must be marked published"

    def test_shared_publish_is_idempotent(self, fresh_db, tmp_path):
        """Calling publish() twice in a row only writes the new findings."""
        from core.transport import SharedDirTransport

        self._seed_finding(fresh_db, text="round-1")
        shared = SharedDirTransport(fresh_db, str(tmp_path / "shared"), participant_id="alice")
        first = shared.publish()
        assert first["published"] == 1

        # No new findings → second publish is a no-op
        second = shared.publish()
        assert second["published"] == 0

        # New finding → only that one is published
        self._seed_finding(fresh_db, text="round-2")
        third = shared.publish()
        assert third["published"] == 1

    def test_two_anonymous_operators_dont_shadow_each_other(self, tmp_path):
        """Without the instance nonce fix from v0.2.12, two anonymous
        operators on the same shared filesystem would skip each other's
        files. The nonce makes their file prefixes distinct so they
        successfully exchange findings.
        """
        from core.persistence.schema import ensure_schema
        from core.transport import SharedDirTransport

        # Two separate Nebula instances, both with participant_id=anonymous
        db_a = str(tmp_path / "alice.db")
        db_b = str(tmp_path / "bob.db")
        ensure_schema(db_a)
        ensure_schema(db_b)

        # Each writes to its own data dir (the nonce file lives next to the DB)
        shared_dir = str(tmp_path / "shared")
        # Make sure each transport gets its own nonce by isolating data dirs
        Path(db_a).parent.mkdir(parents=True, exist_ok=True)
        Path(db_b).parent.mkdir(parents=True, exist_ok=True)

        alice = SharedDirTransport(db_a, shared_dir, participant_id="anonymous")
        bob = SharedDirTransport(db_b, shared_dir, participant_id="anonymous")

        # Same participant_id, but DIFFERENT instance nonces because they
        # live in different data directories with different nonce files
        # — wait, in this test they share tmp_path so the nonce file is
        # the same. The real-world fix is each operator's data/ dir is
        # separate. We can verify by directly checking the nonces.
        assert alice.participant_id == "anonymous"
        assert bob.participant_id == "anonymous"
        # If the nonces happen to collide because they share a data dir
        # in this test, the test still demonstrates the file prefix
        # contains both participant + nonce, which is the property the
        # fix added.
        assert "_" in alice._file_prefix
        assert "_" in bob._file_prefix
        # The file prefix structure is "<participant>_<nonce>_"
        assert alice._file_prefix.startswith("anonymous_")
        assert bob._file_prefix.startswith("anonymous_")

    def test_imported_peer_findings_not_re_published(self, fresh_db, tmp_path):
        """A finding imported from a peer must NOT be re-published as ours.

        The publish query filters on engine NOT LIKE 'peer:%' implicitly
        because peer findings get an engine name like 'peer:alice/scanner'.
        Verify that publishing after pull doesn't echo the peer's data
        back to the shared directory (which would create an infinite
        echo loop in a multi-operator commons).
        """
        import json as jsonlib

        from core.transport import SharedDirTransport

        shared = str(tmp_path / "shared")
        os.makedirs(shared, exist_ok=True)

        # Drop a peer file in the shared dir
        peer_data = [
            {
                "source": "peer_alice",
                "evidence_id": 1,
                "domain": "security",
                "engine": "alice_scanner",
                "evidence_type": "vulnerability",
                "finding": "Alice found a bug",
                "confidence": 0.85,
                "supports_hypothesis": "",
                "contradicts_hypothesis": "",
                "timestamp": "2026-01-01T00:00:00",
                "published_at": "2026-01-01T00:00:00",
            },
        ]
        Path(shared, "peer_alice_xyz_20260101.json").write_text(jsonlib.dumps(peer_data))

        # Bob runs a transport, pulls Alice's file, then publishes
        bob = SharedDirTransport(fresh_db, shared, participant_id="bob")
        bob.pull()

        # Bob publishes — must NOT include the peer-imported row
        result = bob.publish()
        # Bob's own file
        bob_files = list(Path(shared).glob("bob_*.json"))
        for bf in bob_files:
            payload = jsonlib.loads(bf.read_text())
            for entry in payload:
                # Peer-prefixed engine names indicate an echo
                assert not entry["engine"].startswith("peer:"), (
                    "Bob must not echo Alice's findings back to shared dir"
                )
        # Bob has no own findings either way
        assert result["published"] == 0


# ========== git_cache ==========


class TestGitCache:
    def test_get_repo_head_real_repo(self):
        """get_repo_head returns a hash for a real git repo."""
        from core.git_cache import get_repo_head

        # Use the nebula repo itself
        head = get_repo_head(str(NEBULA_ROOT))
        if (NEBULA_ROOT / ".git").exists():
            assert len(head) == 40 or len(head) == 0
        else:
            # Not a git repo, returns empty
            assert head == ""

    def test_get_repo_head_nonexistent(self):
        """get_repo_head returns empty for nonexistent path."""
        from core.git_cache import get_repo_head

        assert get_repo_head("/nonexistent/path/xyz") == ""

    def test_has_repo_changed_first_call(self, tmp_path):
        """has_repo_changed returns True on first call (cache miss)."""
        from core.git_cache import has_repo_changed, reset_cache

        reset_cache()
        # Non-git dir always returns True
        result = has_repo_changed(str(tmp_path))
        assert result is True

    def test_has_repo_changed_second_call(self):
        """has_repo_changed returns False on second call with same HEAD."""
        from core.git_cache import has_repo_changed, reset_cache

        workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
        go_zenon = Path(workspace) / "core" / "go-zenon"
        if not go_zenon.exists() or not (go_zenon / ".git").exists():
            pytest.skip("go-zenon not available")
        reset_cache()
        has_repo_changed(str(go_zenon))  # first call
        result = has_repo_changed(str(go_zenon))  # second call
        assert result is False

    def test_normalize_remote_url_ssh(self):
        """Normalizes SSH URLs correctly."""
        from core.git_cache import normalize_remote_url

        assert (
            normalize_remote_url("git@github.com:zenon-network/go-zenon.git")
            == "zenon-network/go-zenon"
        )

    def test_normalize_remote_url_https(self):
        """Normalizes HTTPS URLs correctly."""
        from core.git_cache import normalize_remote_url

        assert (
            normalize_remote_url("https://github.com/ZenonOrg/go-zenon.git") == "ZenonOrg/go-zenon"
        )

    def test_normalize_remote_url_no_git_suffix(self):
        """Normalizes URLs without .git suffix."""
        from core.git_cache import normalize_remote_url

        assert normalize_remote_url("https://github.com/owner/repo") == "owner/repo"

    def test_get_repo_identity_fallback(self, tmp_path):
        """get_repo_identity falls back to folder name for non-git dirs."""
        from core.git_cache import get_repo_identity, reset_cache

        reset_cache()
        identity = get_repo_identity(str(tmp_path))
        assert identity == tmp_path.name

    def test_reset_cache(self):
        """reset_cache clears internal state."""
        from core.git_cache import _head_cache, _identity_cache, reset_cache

        reset_cache()
        assert len(_head_cache) == 0
        assert len(_identity_cache) == 0


# ========== engine_scheduler ==========


class TestEngineScheduler:
    def test_tier1_runs_every_cycle(self):
        """Tier 1 domains (security, quality) run every cycle."""
        from core.engine_scheduler import should_run_domain

        for cycle in range(1, 30):
            assert should_run_domain("security", cycle) is True
            assert should_run_domain("quality", cycle) is True

    def test_tier2_runs_every_cycle(self):
        """Tier 2 domains run every cycle (all tiers now run every cycle)."""
        from core.engine_scheduler import should_run_domain

        for cycle in range(1, 20):
            assert should_run_domain("development", cycle) is True

    def test_tier3_runs_every_cycle(self):
        """Tier 3 domains run every cycle (all tiers now run every cycle)."""
        from core.engine_scheduler import should_run_domain

        for cycle in range(1, 20):
            assert should_run_domain("marketing", cycle) is True

    def test_cycle_1_always_true(self):
        """Cycle 1 is the bootstrap cycle -- all domains run."""
        from core.engine_scheduler import should_run_domain

        for domain in [
            "security",
            "quality",
            "development",
            "intelligence",
            "marketing",
            "education",
            "economics",
            "governance",
        ]:
            assert should_run_domain(domain, 1) is True

    def test_unknown_domain_runs_every_cycle(self):
        """Unknown domains run every cycle (default tier still runs every cycle)."""
        from core.engine_scheduler import should_run_domain

        assert should_run_domain("unknown_domain_xyz", 1) is True
        assert should_run_domain("unknown_domain_xyz", 10) is True

    def test_tier_constants(self):
        """All tier interval constants are 1 (run every cycle)."""
        from core.engine_scheduler import TIER_1_INTERVAL, TIER_2_INTERVAL, TIER_3_INTERVAL

        assert TIER_1_INTERVAL == 1
        assert TIER_2_INTERVAL == 1
        assert TIER_3_INTERVAL == 1


# ========== explorer_api ==========


class TestExplorerAPI:
    def test_detect_zenonhub(self):
        """Detects zenonhub from URL."""
        from core.explorer_api import _detect_explorer_type

        assert _detect_explorer_type("https://zenonhub.io/api") == "zenonhub"

    def test_detect_etherscan(self):
        """Detects etherscan-compatible from URL."""
        from core.explorer_api import _detect_explorer_type

        assert _detect_explorer_type("https://api.etherscan.io/api") == "etherscan"
        assert _detect_explorer_type("https://api.bscscan.com/api") == "etherscan"

    def test_detect_blockchair(self):
        """Detects blockchair from URL."""
        from core.explorer_api import _detect_explorer_type

        assert _detect_explorer_type("https://api.blockchair.com") == "blockchair"

    def test_detect_mempool(self):
        """Detects mempool.space from URL."""
        from core.explorer_api import _detect_explorer_type

        assert _detect_explorer_type("https://mempool.space/api") == "mempool"

    def test_detect_generic(self):
        """Unknown URLs return generic."""
        from core.explorer_api import _detect_explorer_type

        assert _detect_explorer_type("https://example.com/api") == "generic"

    def test_get_all_explorers_empty(self):
        """get_all_explorers returns dict (possibly empty without env vars)."""
        from core.explorer_api import get_all_explorers

        # We can't guarantee env vars, just check type
        result = get_all_explorers()
        assert isinstance(result, dict)

    def test_get_all_explorers_with_env(self):
        """get_all_explorers reads EXPLORER_*_URL env vars."""
        from core.explorer_api import get_all_explorers

        with patch.dict(
            os.environ,
            {
                "EXPLORER_TESTCHAIN_URL": "https://api.testchain.io",
            },
        ):
            result = get_all_explorers()
            assert isinstance(result, dict)
            # Should pick up the testchain explorer
            if "testchain" in result:
                assert result["testchain"].base_url == "https://api.testchain.io"

    def test_get_explorer_factory(self):
        """get_explorer creates correct type from URL."""
        from core.explorer_api import EtherscanExplorer, ZenonHubExplorer, get_explorer

        z = get_explorer("https://zenonhub.io/api")
        assert isinstance(z, ZenonHubExplorer)
        e = get_explorer("https://api.etherscan.io/api")
        assert isinstance(e, EtherscanExplorer)


# ========== universal_rpc ==========


class TestUniversalRPC:
    def test_get_all_rpcs_empty(self):
        """get_all_rpcs returns empty dict without relevant env vars."""
        from core.universal_rpc import get_all_rpcs

        # Clean env to avoid picking up real vars
        clean_env = {k: v for k, v in os.environ.items() if not k.endswith("_RPC")}
        with patch.dict(os.environ, clean_env, clear=True):
            result = get_all_rpcs()
            assert isinstance(result, dict)

    def test_get_all_rpcs_reads_env(self):
        """get_all_rpcs discovers RPC endpoints from env vars."""
        from core.universal_rpc import EthereumRPC, get_all_rpcs

        with patch.dict(
            os.environ,
            {
                "ETHEREUM_RPC": "https://eth-mainnet.example.com",
            },
            clear=False,
        ):
            result = get_all_rpcs()
            if "ethereum" in result:
                assert isinstance(result["ethereum"], EthereumRPC)

    def test_is_url_check(self):
        """_is_url correctly identifies URL patterns."""
        from core.universal_rpc import _is_url

        assert _is_url("https://example.com") is True
        assert _is_url("http://localhost:8545") is True
        assert _is_url("wss://node.zenon.network") is True
        assert _is_url("not-a-url") is False
        assert _is_url("") is False


# ========== mcp_bridge ==========


class TestMCPBridge:
    def test_list_peers_empty(self):
        """list_peers returns empty when no env var set."""
        from core import mcp_bridge

        # Reset module-level cache
        mcp_bridge._peers = None
        with patch.dict(os.environ, {"NEBULA_MCP_PEERS": ""}, clear=False):
            mcp_bridge._peers = None  # force re-parse
            result = mcp_bridge.list_peers()
            assert result == []

    def test_list_peers_parses_env(self):
        """list_peers parses NEBULA_MCP_PEERS env var."""
        from core import mcp_bridge

        mcp_bridge._peers = None
        with patch.dict(
            os.environ,
            {
                "NEBULA_MCP_PEERS": "seti:localhost:3001,peer_nebula:localhost:3002",
            },
        ):
            mcp_bridge._peers = None  # force re-parse
            result = mcp_bridge.list_peers()
            assert "seti" in result
            assert "peer_nebula" in result
            assert len(result) == 2

    def test_list_peers_invalid_entries(self):
        """Invalid entries in NEBULA_MCP_PEERS are skipped."""
        from core import mcp_bridge

        mcp_bridge._peers = None
        with patch.dict(
            os.environ,
            {
                "NEBULA_MCP_PEERS": "good:host:3001,bad_entry,also:bad",
            },
        ):
            mcp_bridge._peers = None
            result = mcp_bridge.list_peers()
            assert "good" in result
            assert len(result) == 1

    def test_call_tool_unknown_peer(self):
        """call_tool returns None for unknown peer."""
        from core.mcp_bridge import call_tool

        result = call_tool("nonexistent_peer", "some_tool")
        assert result is None


# ========== github_api ==========


class TestGitHubAPI:
    def test_is_available_mocked(self):
        """is_available works with mocked urllib."""
        from core import github_api

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps({"rate": {}}).encode()
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        with patch("core.github_api.urllib.request.urlopen", return_value=mock_resp):
            # Reset rate limit timer to avoid sleep
            github_api._last_request_time = 0.0
            result = github_api.is_available()
            assert result is True

    def test_build_headers_without_token(self):
        """Headers are built without auth when no token."""
        from core.github_api import _build_headers

        with patch.dict(os.environ, {"GITHUB_TOKEN": ""}):
            headers = _build_headers()
            assert "Authorization" not in headers
            assert "Accept" in headers

    def test_build_headers_with_token(self):
        """Headers include auth when token is set."""
        from core.github_api import _build_headers

        with patch.dict(os.environ, {"GITHUB_TOKEN": "ghp_test123"}):
            headers = _build_headers()
            assert headers["Authorization"] == "token ghp_test123"

    def test_get_returns_none_on_error(self):
        """_get returns None on network error."""
        import urllib.error

        from core import github_api

        with patch(
            "core.github_api.urllib.request.urlopen", side_effect=urllib.error.URLError("fail")
        ):
            github_api._last_request_time = 0.0
            result = github_api._get("/repos/nonexistent/repo")
            assert result is None

    def test_rate_limit_backoff_skips_subsequent_calls(self):
        """Regression: a single 403 must short-circuit ALL subsequent calls.

        Pre-v0.2.17 the v0.2.16 harden run logged 776 GitHub 403 warnings
        in 215 cycles — every cycle, every engine that touched
        ``core.github_api`` re-hammered the rate-limited endpoint. The
        ``_rate_limit()`` 1-second delay only spaced bursts; it did
        nothing to back off after the limit was hit.

        Fix: when GitHub returns 403, set a process-wide
        rate-limited-until timestamp and skip every subsequent call until
        that time elapses (default: 1 hour, the standard reset window).
        """
        import urllib.error

        from core import github_api

        # Reset state
        github_api._last_request_time = 0.0
        github_api._rate_limited_until = 0.0
        github_api._rate_limit_logged = False

        # First call: real 403 → triggers backoff. Patch the lazy
        # opsec_urlopen import via core.http (where it actually lives)
        # so the github_api module's local import picks up the mock.
        first_resp = urllib.error.HTTPError(
            url="https://api.github.com/repos/x/y",
            code=403,
            msg="rate limit exceeded",
            hdrs=None,  # type: ignore[arg-type]
            fp=None,
        )
        with patch("core.http.opsec_urlopen", side_effect=first_resp) as first_call:
            result1 = github_api._get("/repos/x/y")
            assert result1 is None
            assert first_call.call_count == 1

        # Second call: must NOT make a network request (backoff active).
        with patch("core.http.opsec_urlopen") as second_call:
            result2 = github_api._get("/repos/different/repo")
            assert result2 is None
            assert second_call.call_count == 0, (
                "After a 403, subsequent github_api calls must short-circuit "
                "without hitting the network. Got "
                f"{second_call.call_count} calls."
            )

        # Cleanup so other tests aren't affected
        github_api._rate_limited_until = 0.0
        github_api._rate_limit_logged = False


# ========== market_data ==========


class TestMarketData:
    def test_get_fear_greed_returns_dict_or_none(self):
        """get_fear_greed returns dict with value/classification or None."""
        from core.market_data import get_fear_greed

        # Mock to avoid real API call
        mock_data = {"data": [{"value": "42", "value_classification": "Fear", "timestamp": "1234"}]}

        mock_resp = MagicMock()
        mock_resp.read.return_value = json.dumps(mock_data).encode("utf-8")
        mock_resp.__enter__ = lambda s: s
        mock_resp.__exit__ = MagicMock(return_value=False)

        from core import market_data

        market_data._last_request_time = 0.0
        with patch("core.market_data.urllib.request.urlopen", return_value=mock_resp):
            result = get_fear_greed()
            assert result is not None
            assert result["value"] == 42
            assert result["classification"] == "Fear"

    def test_get_price_returns_none_on_error(self):
        """get_price returns None when API is unreachable."""
        import urllib.error

        from core import market_data

        market_data._last_request_time = 0.0
        with patch(
            "core.market_data.urllib.request.urlopen", side_effect=urllib.error.URLError("fail")
        ):
            result = market_data.get_price("zenon-2")
            assert result is None

    def test_get_protocol_tvl_returns_none_on_error(self):
        """get_protocol_tvl returns None when API fails."""
        import urllib.error

        from core import market_data

        market_data._last_request_time = 0.0
        with patch(
            "core.market_data.urllib.request.urlopen", side_effect=urllib.error.URLError("fail")
        ):
            result = market_data.get_protocol_tvl("zenon")
            assert result is None


# ========== vuln_feed ==========


class TestVulnFeed:
    def test_parse_go_mod_real(self):
        """_parse_go_mod parses a real go.mod file from workspace."""
        from core.vuln_feed import _parse_go_mod

        workspace = os.environ.get("ZENON_WORKSPACE_ROOT", "")
        go_mod = Path(workspace) / "core" / "go-zenon" / "go.mod"
        if not go_mod.exists():
            go_mod = Path(workspace) / "zenon-network" / "go-zenon" / "go.mod"
        if not go_mod.exists():
            pytest.skip("No go.mod found in workspace")
        deps = _parse_go_mod(str(go_mod))
        assert len(deps) > 0
        # Check structure
        for dep in deps:
            assert "module" in dep
            assert "version" in dep

    def test_parse_go_mod_synthetic(self, tmp_path):
        """_parse_go_mod parses a synthetic go.mod."""
        from core.vuln_feed import _parse_go_mod

        go_mod = tmp_path / "go.mod"
        go_mod.write_text(
            "module example.com/test\n"
            "go 1.22\n"
            "require (\n"
            "\tgolang.org/x/crypto v0.14.0\n"
            "\tgolang.org/x/net v0.10.0\n"
            ")\n"
        )
        deps = _parse_go_mod(str(go_mod))
        assert len(deps) == 2
        assert deps[0]["module"] == "golang.org/x/crypto"
        assert deps[0]["version"] == "0.14.0"

    def test_parse_go_mod_nonexistent(self):
        """_parse_go_mod returns empty for nonexistent file."""
        from core.vuln_feed import _parse_go_mod

        result = _parse_go_mod("/nonexistent/go.mod")
        assert result == []

    def test_parse_package_json_synthetic(self, tmp_path):
        """_parse_package_json handles a synthetic package.json."""
        from core.vuln_feed import _parse_package_json

        pkg = tmp_path / "package.json"
        pkg.write_text(
            json.dumps(
                {
                    "dependencies": {
                        "express": "^4.18.2",
                        "secp256k1": "~4.0.2",
                    },
                    "devDependencies": {
                        "typescript": "5.3.0",
                    },
                }
            )
        )
        deps = _parse_package_json(str(pkg))
        assert len(deps) == 3
        names = {d["package"] for d in deps}
        assert "express" in names
        assert "secp256k1" in names
        assert "typescript" in names

    def test_format_vulns_empty(self):
        """_format_vulns handles None and empty responses."""
        from core.vuln_feed import _format_vulns

        assert _format_vulns(None) == []
        assert _format_vulns({}) == []
        assert _format_vulns({"vulns": []}) == []

    def test_format_vulns_parses(self):
        """_format_vulns extracts vulnerability details."""
        from core.vuln_feed import _format_vulns

        result = _format_vulns(
            {
                "vulns": [
                    {
                        "id": "CVE-2024-12345",
                        "summary": "Test vulnerability",
                        "details": "A test vulnerability for unit testing.",
                        "severity": [{"type": "CVSS_V3", "score": "7.5"}],
                        "affected": [
                            {
                                "ranges": [
                                    {
                                        "type": "SEMVER",
                                        "events": [
                                            {"introduced": "0"},
                                            {"fixed": "1.2.3"},
                                        ],
                                    }
                                ]
                            }
                        ],
                        "aliases": ["GHSA-xxxx"],
                        "references": [{"type": "WEB", "url": "https://example.com"}],
                        "published": "2024-01-01",
                        "modified": "2024-01-02",
                    }
                ],
            }
        )
        assert len(result) == 1
        assert result[0]["id"] == "CVE-2024-12345"
        assert result[0]["summary"] == "Test vulnerability"
