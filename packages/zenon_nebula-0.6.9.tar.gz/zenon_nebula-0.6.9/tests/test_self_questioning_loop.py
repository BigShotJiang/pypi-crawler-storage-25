# SPDX-License-Identifier: MIT
"""Tests for domains.investigation.engines.self_questioning_loop (task #45).

Covers the full orchestrator-workers loop:
- Eligible-hypothesis selection (confidence band, status filter, rotation).
- Evidence gathering (limit, sort order).
- LLM prompt construction (hypothesis + evidence rendered).
- Response parsing (JSON, missing fields, garbage, non-dict).
- Hallucination guard (file existence, path traversal rejection).
- Persistence (findings land in evidence with correct shape).
- Graceful degradation (no workspace, no hypothesis, LLM returns None).

All LLM calls are injected via the ``llm_call`` parameter so no test
touches the real xAI API.
"""

from __future__ import annotations

import json
import sqlite3
from unittest.mock import MagicMock

import pytest

from core.workspace import reset_cache
from domains.investigation.engines.self_questioning_loop import (
    FOLLOWUP_CONFIDENCE,
    FOLLOWUP_DEADLINE_CYCLES,
    HYPOTHESIS_CONFIDENCE_CEILING,
    HYPOTHESIS_CONFIDENCE_FLOOR,
    MAX_PROPOSALS,
    _build_prompt,
    _parse_llm_response,
    _pick_eligible_hypothesis,
    _verify_file_exists,
    run_self_questioning_loop,
)


def _insert_hypothesis(
    db_path: str,
    hid: str,
    confidence: float,
    status: str = "INVESTIGATING",
    domain: str = "development",
    title: str = "Test hypothesis",
    last_updated: str | None = "2026-04-10T00:00:00Z",
) -> None:
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO hypotheses (id, domain, title, confidence, status, last_updated) "
            "VALUES (?,?,?,?,?,?)",
            (hid, domain, title, confidence, status, last_updated),
        )
        conn.commit()
    finally:
        conn.close()


def _insert_evidence(
    db_path: str,
    hypothesis_id: str,
    engine: str = "test_engine",
    finding: str = "Test evidence finding",
    confidence: float = 0.7,
    source_file: str | None = None,
    source_repo: str | None = None,
) -> None:
    conn = sqlite3.connect(db_path)
    try:
        conn.execute(
            "INSERT INTO evidence (domain, engine, evidence_type, finding, "
            "confidence, supports_hypothesis, source_repo, source_file) "
            "VALUES (?,?,?,?,?,?,?,?)",
            (
                "investigation",
                engine,
                "metric",
                finding,
                confidence,
                hypothesis_id,
                source_repo,
                source_file,
            ),
        )
        conn.commit()
    finally:
        conn.close()


# ---------------------------------------------------------------------------
# Import + contract
# ---------------------------------------------------------------------------


class TestImportAndContract:
    def test_entry_point_exists(self):
        from domains.investigation.engines import self_questioning_loop as mod

        assert hasattr(mod, "run_self_questioning_loop")
        assert callable(mod.run_self_questioning_loop)

    def test_runs_on_empty_db_no_llm_call(self, db_path, fake_workspace):
        reset_cache()
        llm = MagicMock()
        result = run_self_questioning_loop(db_path=db_path, llm_call=llm)
        assert result["hypothesis_id"] is None
        assert result["proposals_generated"] == 0
        assert result["findings_persisted"] == 0
        llm.assert_not_called()


# ---------------------------------------------------------------------------
# Eligible-hypothesis selection
# ---------------------------------------------------------------------------


class TestPickEligibleHypothesis:
    def test_below_floor_skipped(self, db_path):
        _insert_hypothesis(db_path, "H_low", HYPOTHESIS_CONFIDENCE_FLOOR - 0.1)
        assert _pick_eligible_hypothesis(db_path) is None

    def test_above_ceiling_skipped(self, db_path):
        _insert_hypothesis(db_path, "H_high", HYPOTHESIS_CONFIDENCE_CEILING + 0.05)
        assert _pick_eligible_hypothesis(db_path) is None

    def test_compelling_status_skipped(self, db_path):
        _insert_hypothesis(
            db_path,
            "H_done",
            (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2,
            status="COMPELLING",
        )
        assert _pick_eligible_hypothesis(db_path) is None

    def test_eligible_selected(self, db_path):
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H_ok", mid, title="Eligible hyp")
        row = _pick_eligible_hypothesis(db_path)
        assert row is not None
        assert row["id"] == "H_ok"
        assert row["title"] == "Eligible hyp"

    def test_oldest_first_rotation(self, db_path):
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H_new", mid, last_updated="2026-04-10T12:00:00Z", title="new")
        _insert_hypothesis(db_path, "H_old", mid, last_updated="2026-04-01T00:00:00Z", title="old")
        row = _pick_eligible_hypothesis(db_path)
        assert row is not None
        assert row["id"] == "H_old"


# ---------------------------------------------------------------------------
# Prompt construction
# ---------------------------------------------------------------------------


class TestBuildPrompt:
    def test_contains_hypothesis_title_and_confidence(self):
        hyp = {
            "id": "H1",
            "domain": "security",
            "title": "PTLC is sound against taproot rollback",
            "confidence": 0.72,
        }
        _, prompt = _build_prompt(hyp, [])
        assert "PTLC is sound against taproot rollback" in prompt
        assert "0.72" in prompt
        assert "security" in prompt

    def test_no_evidence_message(self):
        hyp = {"id": "H1", "domain": "dev", "title": "t", "confidence": 0.7}
        _, prompt = _build_prompt(hyp, [])
        assert "no supporting evidence yet" in prompt

    def test_renders_evidence_with_source(self):
        hyp = {"id": "H1", "domain": "dev", "title": "t", "confidence": 0.7}
        evidence = [
            {
                "engine": "spec_tracker",
                "finding": "Found 14 specs",
                "source_repo": "knowledge/developer-commons",
                "source_file": "docs/specs/PTLC/ptlc_spec.md",
                "source_line": 42,
            }
        ]
        _, prompt = _build_prompt(hyp, evidence)
        assert "spec_tracker" in prompt
        assert "Found 14 specs" in prompt
        assert "docs/specs/PTLC/ptlc_spec.md:42" in prompt

    def test_system_sets_anti_hallucination_rules(self):
        hyp = {"id": "H1", "domain": "dev", "title": "t", "confidence": 0.7}
        system, _ = _build_prompt(hyp, [])
        assert "never invent" in system.lower()
        assert "json" in system.lower()


# ---------------------------------------------------------------------------
# Response parsing
# ---------------------------------------------------------------------------


class TestParseLLMResponse:
    def test_none_returns_empty(self):
        assert _parse_llm_response(None) == []

    def test_empty_dict_returns_empty(self):
        assert _parse_llm_response({}) == []

    def test_non_json_text_returns_empty(self):
        assert _parse_llm_response({"text": "not json"}) == []

    def test_non_dict_payload_returns_empty(self):
        assert _parse_llm_response({"text": "[1,2,3]"}) == []

    def test_missing_proposals_key_returns_empty(self):
        assert _parse_llm_response({"text": json.dumps({"other": []})}) == []

    def test_valid_proposals_parsed(self):
        payload = {
            "proposals": [
                {
                    "question": "Does ptlc_spec.md list all ABI methods?",
                    "target_repo": "knowledge/developer-commons",
                    "target_file": "docs/specs/PTLC/ptlc_spec.md",
                }
            ]
        }
        result = _parse_llm_response({"text": json.dumps(payload)})
        assert len(result) == 1
        assert result[0]["question"].startswith("Does ptlc_spec.md")
        assert result[0]["target_repo"] == "knowledge/developer-commons"

    def test_max_proposals_cap(self):
        payload = {
            "proposals": [
                {"question": f"q{i}", "target_repo": "r", "target_file": "f.md"} for i in range(10)
            ]
        }
        result = _parse_llm_response({"text": json.dumps(payload)})
        assert len(result) == MAX_PROPOSALS

    def test_missing_fields_dropped(self):
        payload = {
            "proposals": [
                {"question": "q1", "target_repo": "r"},  # missing target_file
                {"question": "q2", "target_repo": "r", "target_file": ""},  # empty
                {"target_repo": "r", "target_file": "f.md"},  # missing question
                {"question": "q4", "target_repo": "r", "target_file": "f.md"},  # ok
            ]
        }
        result = _parse_llm_response({"text": json.dumps(payload)})
        assert len(result) == 1
        assert result[0]["question"] == "q4"

    def test_path_traversal_rejected(self):
        payload = {
            "proposals": [
                {"question": "q", "target_repo": "r", "target_file": "../secret.txt"},
                {"question": "q", "target_repo": "r", "target_file": "/etc/passwd"},
            ]
        }
        result = _parse_llm_response({"text": json.dumps(payload)})
        assert result == []


# ---------------------------------------------------------------------------
# Hallucination guard (file existence check)
# ---------------------------------------------------------------------------


class TestVerifyFileExists:
    def test_real_file_returns_path(self, fake_workspace):
        reset_cache()
        # ptlc_spec.md is created by fake_workspace fixture
        result = _verify_file_exists(
            "knowledge/developer-commons",
            "docs/specs/PTLC/ptlc_spec.md",
        )
        assert result is not None
        assert result.name == "ptlc_spec.md"

    def test_missing_file_returns_none(self, fake_workspace):
        reset_cache()
        result = _verify_file_exists(
            "knowledge/developer-commons",
            "docs/specs/PTLC/does_not_exist.md",
        )
        assert result is None

    def test_missing_repo_returns_none(self, fake_workspace):
        reset_cache()
        result = _verify_file_exists("nonexistent-repo", "file.md")
        assert result is None


# ---------------------------------------------------------------------------
# End-to-end orchestrator
# ---------------------------------------------------------------------------


class TestRunSelfQuestioningLoop:
    def test_happy_path_persists_findings(self, db_path, fake_workspace):
        reset_cache()
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H1", mid, title="PTLC spec coverage")
        _insert_evidence(
            db_path,
            "H1",
            engine="spec_tracker",
            finding="Found 14 specs in developer-commons",
        )

        mock_response = {
            "text": json.dumps(
                {
                    "proposals": [
                        {
                            "question": "Does the spec define the Reclaim boundary clearly?",
                            "target_repo": "knowledge/developer-commons",
                            "target_file": "docs/specs/PTLC/ptlc_spec.md",
                        }
                    ]
                }
            )
        }
        llm = MagicMock(return_value=mock_response)

        result = run_self_questioning_loop(db_path=db_path, llm_call=llm, current_cycle=42)

        assert result["hypothesis_id"] == "H1"
        assert result["proposals_generated"] == 1
        assert result["proposals_survived"] == 1
        assert result["findings_persisted"] == 1
        llm.assert_called_once()

        # Verify the persisted finding has correct shape
        conn = sqlite3.connect(db_path)
        conn.row_factory = sqlite3.Row
        row = conn.execute(
            "SELECT * FROM evidence WHERE engine = 'self_questioning_loop'"
        ).fetchone()
        conn.close()
        assert row is not None
        assert row["domain"] == "investigation"
        assert row["evidence_type"] == "self_question"
        assert row["supports_hypothesis"] == "H1"
        assert row["confidence"] == FOLLOWUP_CONFIDENCE
        # persist_finding normalizes source_repo via get_repo_identity,
        # which strips the leading "knowledge/" namespace for known
        # workspace layouts. The canonical identity lands in the row.
        assert row["source_repo"] in (
            "knowledge/developer-commons",
            "developer-commons",
        )
        assert "Reclaim boundary" in row["finding"]
        # persist_finding wraps raw_data in a {"data": ..., ...} envelope
        envelope = json.loads(row["raw_data"])
        raw = envelope["data"]
        assert raw["deadline_cycles"] == FOLLOWUP_DEADLINE_CYCLES
        assert raw["opened_at_cycle"] == 42

    def test_nonexistent_file_drops_proposal(self, db_path, fake_workspace):
        reset_cache()
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H1", mid)

        mock_response = {
            "text": json.dumps(
                {
                    "proposals": [
                        {
                            "question": "q",
                            "target_repo": "knowledge/developer-commons",
                            "target_file": "docs/specs/PTLC/made_up.md",
                        }
                    ]
                }
            )
        }
        llm = MagicMock(return_value=mock_response)
        result = run_self_questioning_loop(db_path=db_path, llm_call=llm)

        assert result["proposals_generated"] == 1
        assert result["proposals_survived"] == 0
        assert result["findings_persisted"] == 0

    def test_garbage_llm_response_no_crash(self, db_path, fake_workspace):
        reset_cache()
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H1", mid)
        llm = MagicMock(return_value={"text": "this is definitely not json {{{"})
        result = run_self_questioning_loop(db_path=db_path, llm_call=llm)
        assert result["proposals_generated"] == 0
        assert result["findings_persisted"] == 0

    def test_none_llm_response_no_crash(self, db_path, fake_workspace):
        reset_cache()
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H1", mid)
        llm = MagicMock(return_value=None)
        result = run_self_questioning_loop(db_path=db_path, llm_call=llm)
        assert result["proposals_generated"] == 0
        assert result["findings_persisted"] == 0

    def test_llm_raises_returns_summary(self, db_path, fake_workspace):
        reset_cache()
        mid = (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2
        _insert_hypothesis(db_path, "H1", mid)
        llm = MagicMock(side_effect=RuntimeError("simulated network error"))
        result = run_self_questioning_loop(db_path=db_path, llm_call=llm)
        assert result["findings_persisted"] == 0

    def test_no_workspace_skips_llm_call(self, db_path, monkeypatch):
        # Explicitly unset the workspace root so the engine graceful-
        # degrades. The db has no hypotheses either way so this tests
        # the early-exit path.
        monkeypatch.delenv("ZENON_WORKSPACE_ROOT", raising=False)
        reset_cache()
        llm = MagicMock()
        run_self_questioning_loop(db_path=db_path, llm_call=llm)
        # When there is no workspace installed, the engine must NOT
        # call the LLM even if eligible hypotheses exist — it has no
        # way to verify file paths.
        _insert_hypothesis(
            db_path,
            "H_preexit",
            (HYPOTHESIS_CONFIDENCE_FLOOR + HYPOTHESIS_CONFIDENCE_CEILING) / 2,
        )
        result2 = run_self_questioning_loop(db_path=db_path, llm_call=llm)
        if result2["workspace_root"] is None:
            llm.assert_not_called()


# ---------------------------------------------------------------------------
# Anti-hallucination cross-cuts
# ---------------------------------------------------------------------------


class TestAntiHallucinationInvariants:
    def test_followup_confidence_is_bounded(self):
        """Follow-up findings must never be persisted above the speculative cap."""
        assert 0.0 < FOLLOWUP_CONFIDENCE < 0.5, (
            "Self-questioning proposals are speculative — their "
            "confidence must be capped well below 'answer' level."
        )

    def test_confidence_band_non_degenerate(self):
        assert HYPOTHESIS_CONFIDENCE_FLOOR < HYPOTHESIS_CONFIDENCE_CEILING
        assert HYPOTHESIS_CONFIDENCE_CEILING < 1.0
        assert HYPOTHESIS_CONFIDENCE_FLOOR > 0.0
