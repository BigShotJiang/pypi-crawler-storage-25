# SPDX-License-Identifier: MIT
"""Tests for core.providers.ProviderRegistry (v0.6.6)."""

from __future__ import annotations

from typing import Any

import pytest

from core.providers import APIProvider, LLMProvider, MCPProvider, get_registry
from core.providers.registry import ProviderRegistry


class _FakeProvider(APIProvider):
    """Minimal provider for testing the registry contract."""

    def __init__(self, name: str = "fake", kind: str = "api-builtin") -> None:
        self._name = name
        self._kind = kind

    def name(self) -> str:
        return self._name

    def kind(self) -> str:
        return self._kind

    def is_available(self) -> bool:
        return True

    def call(self, method: str, **kwargs: Any) -> Any:
        return {"method": method, "kwargs": kwargs}


@pytest.fixture
def fresh_registry():
    """Each test gets a clean registry singleton."""
    ProviderRegistry.reset()
    reg = get_registry()
    yield reg
    ProviderRegistry.reset()


class TestRegistryBuiltinDiscovery:
    def test_discovers_seven_builtins(self, fresh_registry):
        """The 7 v0.6.6 builtin wrappers are auto-registered at boot."""
        names = set(fresh_registry.names())
        expected = {
            "github",
            "explorer",
            "market_data",
            "vuln_feed",
            "zenon_data",
            "wayback",
            "llm_xai",
        }
        missing = expected - names
        assert not missing, f"missing builtin providers: {missing}"

    def test_singleton_returns_same_instance(self):
        ProviderRegistry.reset()
        a = get_registry()
        b = get_registry()
        assert a is b

    def test_reset_clears_state(self, fresh_registry):
        fresh_registry.register(_FakeProvider(name="reset_test"))
        assert "reset_test" in fresh_registry
        ProviderRegistry.reset()
        new = get_registry()
        assert "reset_test" not in new


class TestRegisterUnregister:
    def test_register_then_get(self, fresh_registry):
        fake = _FakeProvider(name="custom_a")
        fresh_registry.register(fake)
        assert fresh_registry.get("custom_a") is fake

    def test_register_conflict_raises(self, fresh_registry):
        fresh_registry.register(_FakeProvider(name="dup"))
        with pytest.raises(ValueError, match="conflict"):
            fresh_registry.register(_FakeProvider(name="dup"))

    def test_register_empty_name_raises(self, fresh_registry):
        with pytest.raises(ValueError, match="empty name"):
            fresh_registry.register(_FakeProvider(name=""))

    def test_unregister_removes(self, fresh_registry):
        fresh_registry.register(_FakeProvider(name="rm_test"))
        assert "rm_test" in fresh_registry
        fresh_registry.unregister("rm_test")
        assert "rm_test" not in fresh_registry

    def test_unregister_unknown_is_noop(self, fresh_registry):
        # Should not raise
        fresh_registry.unregister("does_not_exist")


class TestLookup:
    def test_get_unknown_returns_none(self, fresh_registry):
        assert fresh_registry.get("does_not_exist") is None

    def test_get_by_kind_api_builtin(self, fresh_registry):
        api_providers = fresh_registry.get_by_kind("api-builtin")
        # Should include the builtin API wrappers (github, explorer, etc.)
        names = {p.name() for p in api_providers}
        assert "github" in names
        assert "vuln_feed" in names

    def test_get_by_kind_llm(self, fresh_registry):
        llm_providers = fresh_registry.get_by_kind("llm-xai")
        assert len(llm_providers) >= 1
        assert llm_providers[0].name() == "llm_xai"

    def test_get_by_kind_unknown_returns_empty(self, fresh_registry):
        assert fresh_registry.get_by_kind("nonexistent-kind") == []

    def test_list_all_returns_all(self, fresh_registry):
        all_providers = fresh_registry.list_all()
        assert len(all_providers) >= 7  # the 7 builtins
        assert all(isinstance(p, APIProvider) for p in all_providers)

    def test_list_available_filters(self, fresh_registry):
        # github is available (no key needed for unauthenticated calls);
        # llm_xai is unavailable without XAI_API_KEY
        available = fresh_registry.list_available()
        names = {p.name() for p in available}
        assert "github" in names
        assert "vuln_feed" in names

    def test_contains_operator(self, fresh_registry):
        assert "github" in fresh_registry
        assert "fake_xyz" not in fresh_registry
        assert 42 not in fresh_registry  # non-string is False

    def test_len(self, fresh_registry):
        assert len(fresh_registry) >= 7


class TestProviderContract:
    def test_github_provider_returns_dict_or_none(self, fresh_registry):
        gh = fresh_registry.get("github")
        assert gh is not None
        assert gh.kind() == "api-builtin"
        assert gh.is_available() is True
        # Don't actually call (would hit network); just verify dispatch
        # works for unknown method.
        result = gh.call("nonexistent_method", owner="x", repo="y")
        assert result is None  # graceful degrade

    def test_llm_provider_inherits_correctly(self, fresh_registry):
        llm = fresh_registry.get("llm_xai")
        assert llm is not None
        assert isinstance(llm, LLMProvider)
        # complete() exists
        assert hasattr(llm, "complete")

    def test_provider_shutdown_is_safe(self, fresh_registry):
        for provider in fresh_registry.list_all():
            # Should not raise
            provider.shutdown()


class TestABCContracts:
    def test_api_provider_is_abstract(self):
        """Cannot instantiate APIProvider directly."""
        with pytest.raises(TypeError):
            APIProvider()

    def test_mcp_provider_is_abstract(self):
        """Cannot instantiate MCPProvider directly without list_tools."""
        with pytest.raises(TypeError):
            MCPProvider()

    def test_llm_provider_dispatch_unknown_method_raises(self, fresh_registry):
        llm = fresh_registry.get("llm_xai")
        with pytest.raises(NotImplementedError):
            llm.call("not_complete")
