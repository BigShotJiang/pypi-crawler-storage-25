# SPDX-License-Identifier: MIT
"""Tests for `scripts/generate_dep_graph.py`.

The script is a CI gate — it walks core/ and domains/, builds the import
graph, and flags architectural violations. Before v0.6.9 it ignored
`--check` and always exited 0, which meant the `.github/workflows/test.yml`
`architecture` job silently passed despite the pre-existing
`spec_audit → tminusz_contributor` cross-engine import. These tests pin
the real behavior so the gate can't quietly regress back to a no-op.
"""

from __future__ import annotations

import importlib.util
import sys
from pathlib import Path

import pytest

# Import the script as a module even though it's in scripts/, not
# a package. argparse, main, and detect_violations are all we need.
SCRIPT_PATH = Path(__file__).resolve().parents[1] / "scripts" / "generate_dep_graph.py"
_spec = importlib.util.spec_from_file_location("generate_dep_graph", SCRIPT_PATH)
assert _spec is not None and _spec.loader is not None, "could not load generate_dep_graph.py"
generate_dep_graph = importlib.util.module_from_spec(_spec)
sys.modules["generate_dep_graph"] = generate_dep_graph
_spec.loader.exec_module(generate_dep_graph)


class TestDetectViolations:
    """Pure-function tests for the violation detector."""

    def test_clean_graph_has_no_violations(self):
        graph = {
            "core.foo": {"core.bar"},
            "core.bar": set(),
            "domains.security.engines.scanner": {"core.foo"},
        }
        violations = generate_dep_graph.detect_violations(graph)
        assert sum(len(v) for v in violations.values()) == 0

    def test_core_importing_domain_flagged(self):
        graph = {
            "core.bad": {"domains.security.engines.scanner"},
            "domains.security.engines.scanner": set(),
        }
        violations = generate_dep_graph.detect_violations(graph)
        assert len(violations["core_imports_domain"]) == 1
        assert violations["core_imports_domain"][0] == (
            "core.bad",
            "domains.security.engines.scanner",
        )

    def test_engine_importing_peer_engine_flagged(self):
        """The exact v0.3.0 regression this test exists to catch."""
        graph = {
            "domains.development.engines.spec_audit": {
                "domains.contribution.engines.tminusz_contributor"
            },
            "domains.contribution.engines.tminusz_contributor": set(),
        }
        violations = generate_dep_graph.detect_violations(graph)
        assert len(violations["engine_imports_other_engine"]) == 1

    def test_cross_domain_shared_module_allowed(self):
        """Engines can import from shared.py in their own domain."""
        graph = {
            "domains.security.engines.scanner": {"domains.security.shared"},
            "domains.security.shared": set(),
        }
        violations = generate_dep_graph.detect_violations(graph)
        assert len(violations["engine_imports_other_engine"]) == 0


class TestMainCheckMode:
    """End-to-end tests for `main(argv=[...])`."""

    def test_no_args_always_exits_zero(self, capsys):
        """Plain mode exits 0 regardless of violations (report-only)."""
        rc = generate_dep_graph.main(argv=[])
        assert rc == 0
        out = capsys.readouterr().out
        assert "violations:" in out

    def test_check_mode_clean_repo_exits_zero(self, capsys):
        """On the real repo (which is clean post-v0.6.9), --check returns 0."""
        rc = generate_dep_graph.main(argv=["--check"])
        assert rc == 0

    def test_check_mode_on_violation_returns_one(self, monkeypatch, capsys, tmp_path):
        """Inject a fake violation and confirm --check exits 1.

        Uses monkeypatch to redirect ``OUT_DIR`` to a tmp_path so the
        fake violation report never touches the real repo's
        ``docs/architecture/dependency-report.md``. Without this
        isolation, the test would leak a fake violation into the
        tracked file and every subsequent ``git status`` would show
        the repo as dirty until a manual regen — which v0.6.9's ship
        workflow actually tripped on its first attempt.
        """
        fake_violation = {
            "core_imports_domain": [],
            "engine_imports_other_engine": [("domains.foo.engines.a", "domains.foo.engines.b")],
            "circular_import": [],
        }
        monkeypatch.setattr(
            generate_dep_graph,
            "detect_violations",
            lambda graph: fake_violation,
        )
        # Redirect the module's OUT_DIR to a tmp_path so main()'s
        # write_text side effect never hits the real repo files.
        monkeypatch.setattr(generate_dep_graph, "OUT_DIR", tmp_path)
        rc = generate_dep_graph.main(argv=["--check"])
        assert rc == 1
        captured = capsys.readouterr()
        # The specific source → target pair appears in stdout so CI logs
        # point at the exact offender.
        assert "domains.foo.engines.a -> domains.foo.engines.b" in captured.out
        # And stderr carries the error summary.
        assert "violations" in captured.err.lower()
        # Verify the fake violation landed in the tmp report and NOT
        # in the real repo file (guards against future regressions).
        fake_report = tmp_path / "dependency-report.md"
        assert fake_report.exists()
        assert "domains.foo.engines.a" in fake_report.read_text()

    def test_help_flag_exits_zero(self, capsys):
        """`--help` should exit cleanly with usage text."""
        with pytest.raises(SystemExit) as exc:
            generate_dep_graph.main(argv=["--help"])
        # argparse exits 0 for --help
        assert exc.value.code == 0
        out = capsys.readouterr().out
        assert "--check" in out
