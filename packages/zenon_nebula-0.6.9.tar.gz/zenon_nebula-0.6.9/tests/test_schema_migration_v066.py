# SPDX-License-Identifier: MIT
"""Schema migration tests for v0.6.6 — api_sources + action_spec_json columns.

Verifies that:

1. A fresh DB created via ensure_schema has the new columns.
2. An old-shape DB (pre-v0.6.6) gets migrated forward when
   ensure_schema runs against it.
3. The api_call_log table is created via core.schema_registry.
4. Existing rows in evidence get NULL for the new columns (no
   data loss, no constraint violations).
"""

from __future__ import annotations

import sqlite3

from core.persistence import ensure_schema


def _get_columns(db_path: str, table: str) -> set[str]:
    conn = sqlite3.connect(db_path)
    try:
        return {row[1] for row in conn.execute(f"PRAGMA table_info({table})").fetchall()}
    finally:
        conn.close()


def _get_tables(db_path: str) -> set[str]:
    conn = sqlite3.connect(db_path)
    try:
        return {
            row[0]
            for row in conn.execute("SELECT name FROM sqlite_master WHERE type='table'").fetchall()
        }
    finally:
        conn.close()


class TestFreshDB:
    def test_evidence_has_api_sources(self, db_path):
        cols = _get_columns(db_path, "evidence")
        assert "api_sources" in cols

    def test_evidence_has_action_spec_json(self, db_path):
        cols = _get_columns(db_path, "evidence")
        assert "action_spec_json" in cols

    def test_api_call_log_exists(self, db_path):
        tables = _get_tables(db_path)
        assert "api_call_log" in tables

    def test_api_call_log_columns(self, db_path):
        cols = _get_columns(db_path, "api_call_log")
        assert "provider_name" in cols
        assert "engine_name" in cols
        assert "method" in cols
        assert "latency_ms" in cols
        assert "status" in cols
        assert "response_bytes" in cols
        assert "response_schema_hash" in cols
        assert "raw_meta_json" in cols

    def test_api_call_log_indexes(self, db_path):
        conn = sqlite3.connect(db_path)
        try:
            indexes = {
                row[0]
                for row in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='index' AND tbl_name='api_call_log'"
                ).fetchall()
            }
        finally:
            conn.close()
        assert "idx_api_call_log_provider" in indexes
        assert "idx_api_call_log_timestamp" in indexes


class TestForwardMigration:
    def test_old_db_without_new_columns_gets_migrated(self, tmp_path):
        """Simulate a v0.6.5 DB and run ensure_schema against it.

        Synthetic table includes the columns present at v0.6.5 ship
        time but NOT the v0.6.6 additions (api_sources, action_spec_json).
        After ensure_schema runs, both new columns must exist and the
        pre-existing row must survive intact.
        """
        db_path = str(tmp_path / "v065.db")
        # Create an evidence table that matches v0.6.5 shape — every
        # column the migration loop expects to find (or to ADD via the
        # ALTER blocks) but NOT the v0.6.6 additions.
        conn = sqlite3.connect(db_path)
        try:
            conn.execute(
                """CREATE TABLE evidence (
                    id INTEGER PRIMARY KEY AUTOINCREMENT,
                    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
                    domain TEXT NOT NULL DEFAULT 'system',
                    engine TEXT,
                    evidence_type TEXT,
                    finding TEXT,
                    confidence REAL DEFAULT 0.0,
                    supports_hypothesis TEXT,
                    contradicts_hypothesis TEXT,
                    verification_url TEXT,
                    raw_data TEXT,
                    provenance TEXT DEFAULT 'hypothesis',
                    published BOOLEAN DEFAULT FALSE,
                    run_id TEXT,
                    parent_finding_id INTEGER
                )"""
            )
            conn.execute(
                "INSERT INTO evidence (engine, finding, confidence) VALUES (?, ?, ?)",
                ("legacy_engine", "pre-migration row", 0.5),
            )
            conn.commit()
        finally:
            conn.close()

        # Pre-condition: new columns are NOT present yet
        cols_before = _get_columns(db_path, "evidence")
        assert "api_sources" not in cols_before
        assert "action_spec_json" not in cols_before

        # Run ensure_schema — should add the new columns via the
        # migration loop in core/persistence/schema.py.
        ensure_schema(db_path, force=True)

        cols_after = _get_columns(db_path, "evidence")
        assert "api_sources" in cols_after
        assert "action_spec_json" in cols_after

        # The pre-existing row should still be present with NULL new columns
        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT engine, finding, api_sources, action_spec_json FROM evidence"
            ).fetchone()
        finally:
            conn.close()
        assert row[0] == "legacy_engine"
        assert row[1] == "pre-migration row"
        assert row[2] is None
        assert row[3] is None

    def test_idempotent_migration(self, db_path):
        """Running ensure_schema twice doesn't break."""
        cols_before = _get_columns(db_path, "evidence")
        ensure_schema(db_path, force=True)
        cols_after = _get_columns(db_path, "evidence")
        assert cols_before == cols_after
