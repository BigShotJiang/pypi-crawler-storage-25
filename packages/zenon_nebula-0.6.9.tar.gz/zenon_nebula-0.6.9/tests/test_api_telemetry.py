# SPDX-License-Identifier: MIT
"""Tests for core.api_telemetry (v0.6.6)."""

from __future__ import annotations

import sqlite3

import pytest

from core.api_telemetry import (
    compute_schema_hash,
    get_call_stats,
    get_recent_calls,
    log_call,
)


class TestSchemaHash:
    def test_none_returns_none(self):
        assert compute_schema_hash(None) is None

    def test_empty_dict(self):
        h = compute_schema_hash({})
        assert h is not None
        assert len(h) == 16

    def test_deterministic(self):
        a = compute_schema_hash({"x": 1, "y": "abc"})
        b = compute_schema_hash({"x": 2, "y": "different"})
        # Same shape, different values → same hash
        assert a == b

    def test_different_shape_different_hash(self):
        a = compute_schema_hash({"x": 1})
        b = compute_schema_hash({"x": 1, "y": 2})
        assert a != b

    def test_nested(self):
        h = compute_schema_hash({"items": [{"id": 1, "name": "a"}, {"id": 2}]})
        assert h is not None

    def test_list_shape(self):
        a = compute_schema_hash([{"id": 1}, {"id": 2}])
        b = compute_schema_hash([{"id": 99}])
        # Same element shape → same hash
        assert a == b

    def test_handles_mixed_types(self):
        # Should not raise
        h = compute_schema_hash({"int": 1, "float": 1.5, "bool": True, "list": [1, 2]})
        assert h is not None


class TestLogCall:
    def test_log_creates_row(self, db_path):
        log_call(
            provider_name="github",
            engine_name="test_engine",
            method="get_repo_info",
            latency_ms=42,
            status="ok",
            response_bytes=1024,
            response_schema_hash="abc123",
            db_path=db_path,
        )
        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT provider_name, engine_name, method, latency_ms, status FROM api_call_log"
            ).fetchone()
        finally:
            conn.close()
        assert row is not None
        assert row[0] == "github"
        assert row[1] == "test_engine"
        assert row[2] == "get_repo_info"
        assert row[3] == 42
        assert row[4] == "ok"

    def test_log_call_never_raises(self, tmp_path):
        # Pass a nonexistent DB path — should not raise
        log_call(provider_name="x", db_path="/nonexistent/path/db.sqlite")

    def test_log_call_with_raw_meta(self, db_path):
        log_call(
            provider_name="github",
            method="x",
            status="error",
            raw_meta={"error_class": "TimeoutError", "error": "deadline exceeded"},
            db_path=db_path,
        )
        rows = get_recent_calls(db_path=db_path)
        assert len(rows) == 1
        import json

        meta = json.loads(rows[0]["raw_meta_json"])
        assert meta["error_class"] == "TimeoutError"


class TestAggregation:
    def _populate(self, db_path):
        for i in range(10):
            log_call(
                provider_name="github",
                engine_name=f"engine_{i % 2}",
                method="m",
                latency_ms=100 + i * 10,
                status="ok",
                response_bytes=500,
                db_path=db_path,
            )
        for _i in range(3):
            log_call(
                provider_name="github",
                method="m",
                latency_ms=200,
                status="error",
                db_path=db_path,
            )
        for _i in range(5):
            log_call(
                provider_name="vuln_feed",
                method="check_osv",
                latency_ms=50,
                status="ok",
                response_bytes=200,
                db_path=db_path,
            )

    def test_get_call_stats_groups_by_provider(self, db_path):
        self._populate(db_path)
        stats = get_call_stats(db_path=db_path)
        by_name = {s["provider_name"]: s for s in stats}
        assert by_name["github"]["total_calls"] == 13
        assert by_name["github"]["ok_calls"] == 10
        assert by_name["github"]["error_calls"] == 3
        assert by_name["vuln_feed"]["total_calls"] == 5

    def test_get_call_stats_filters_by_provider(self, db_path):
        self._populate(db_path)
        stats = get_call_stats(db_path=db_path, provider_name="vuln_feed")
        assert len(stats) == 1
        assert stats[0]["provider_name"] == "vuln_feed"

    def test_get_recent_calls_orders_desc(self, db_path):
        self._populate(db_path)
        rows = get_recent_calls(db_path=db_path, limit=5)
        assert len(rows) == 5
        # All rows have a timestamp; the most recent should be first.
        # Since they're inserted in batch, just verify rowcount.

    def test_get_recent_calls_filtered(self, db_path):
        self._populate(db_path)
        rows = get_recent_calls(db_path=db_path, provider_name="vuln_feed", limit=10)
        assert len(rows) == 5
        assert all(r["provider_name"] == "vuln_feed" for r in rows)
