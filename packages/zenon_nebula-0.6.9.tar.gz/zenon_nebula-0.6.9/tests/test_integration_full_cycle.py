# SPDX-License-Identifier: MIT
"""Integration test — full autonomous cycle end-to-end (task #55).

Closes the "seam bugs between modules" gap. Unit tests exercise one
module at a time; nothing else was running ``AutonomousRunner`` on a
clean fake-workspace DB through a real cycle. This test does exactly
that.

What it pins:

1. ``AutonomousRunner.__init__`` succeeds on a fresh DB with the
   registered domains (no registry drift, no import-time side effects
   that need prod config).
2. ``AutonomousRunner.run(max_cycles=1)`` completes one cycle without
   raising. This covers the full pipeline: director landscape read →
   domain ``decide_next_action`` rotation → ``_execute_engine`` dynamic
   import → engine entry-point call → persist path → cycle summary.
3. The returned summary dict has the canonical keys and sane types.
4. Actions logged to ``actions_log`` table (at minimum the ``start``
   action from ``_run_impl``).
5. No LLM calls happen — we patch ``call_llm`` to return None and
   assert zero cost.
6. No real network calls — ``urllib.request.urlopen`` raises loudly
   if any engine reaches for a URL.

What this test does NOT pin:
    - Individual engine output correctness (unit tests).
    - Specific hypothesis / collision / battle plan state (too
      engine-dependent; asserted to "at least runs without error").
    - Real LLM behavior (mocked).

Failure modes this test would catch that unit tests can't:
    - New engine registered in domain but module import fails.
    - Schema registry drift that breaks ``ensure_schema`` on a fresh
      DB before any test exercises the new table.
    - ``decide_next_action`` infinite loop (caught by
      ``MAX_ACTIONS_PER_CYCLE`` but a regression would make the cycle
      take forever — we set a 60s timeout).
    - DomainRegistry import-time crash from a new domain that fails
      silently (smoke test catches some of this; full-cycle catches
      more because it actually imports + instantiates the plugin).
    - ``AutonomousRunner.__init__`` side effects that need prod paths
      (checkpoint.json writes, telemetry, etc.) crashing on a fake
      tmp workspace.
"""

from __future__ import annotations

import sqlite3
import sys
from unittest.mock import patch

import pytest

# The integration test is heavier than a unit test (imports every
# registered domain, runs one real cycle). Timeout is bounded at 60s
# per-test via the global pytest-timeout config; this test should
# finish in a few seconds on a dev laptop.


@pytest.fixture
def integration_env(fake_workspace, db_path, monkeypatch):
    """Set up the full runtime env for an integration cycle.

    - fake_workspace: ZENON_WORKSPACE_ROOT pointed at a synthetic layout
    - db_path: fresh SQLite with ensure_schema already applied
    - LLM calls: patched to return None (zero cost, safe degradation)
    - Network: urlopen patched to raise loudly if anything escapes
    - Env: XAI_API_KEY unset so any accidental real call fails fast

    Returns the db_path so tests can query it after the cycle runs.
    """
    # Ensure no real API key leaks into the test.
    monkeypatch.delenv("XAI_API_KEY", raising=False)
    monkeypatch.delenv("NEBULA_MAX_PARALLEL_ENGINES", raising=False)

    # Patch the LLM entry point to return None — engines that call
    # call_llm get a safe "no response" and degrade. Zero cost.
    with patch("core.llm_provider.call_llm", return_value=None) as mock_llm:
        # Patch urlopen at the module level so any engine reaching for
        # a URL fails loudly. Real network calls in an integration test
        # would be a bug even if they happened to succeed — flakiness,
        # CI rate limits, OPSEC.
        def _raise_no_network(*args, **kwargs):
            raise RuntimeError("integration test attempted a real network call — mock it")

        with patch("urllib.request.urlopen", side_effect=_raise_no_network):
            yield {
                "db_path": db_path,
                "workspace": fake_workspace,
                "mock_llm": mock_llm,
            }


def _count_rows(db_path: str, table: str, where: str = "") -> int:
    """Count rows in a table. Returns 0 if the table doesn't exist."""
    conn = sqlite3.connect(db_path)
    try:
        sql = f"SELECT COUNT(*) FROM {table}"
        if where:
            sql += f" WHERE {where}"
        row = conn.execute(sql).fetchone()
        return int(row[0]) if row else 0
    except sqlite3.OperationalError:
        return 0
    finally:
        conn.close()


class TestAutonomousRunnerIntegration:
    """Full-cycle integration: runner instantiates + runs + returns summary."""

    def test_runner_instantiation_does_not_crash(self, integration_env):
        """AutonomousRunner.__init__ must succeed on a fresh DB.

        This is the lightest possible integration check — it exercises
        every import side effect: domain registration, schema
        migration, UnifiedDirector / CollisionEngine / WarRoom
        instantiation, CheckpointManager file creation. If any of
        those explode on a clean workspace, the runner would have
        been broken in prod for new operators on first install.
        """
        # Import inside the test so pytest collection doesn't drag in
        # the full autonomous module (it's heavy — imports every domain).
        from scripts.autonomous import AutonomousRunner

        runner = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.0,  # No LLM calls allowed — hard-enforced via budget
            domain_filter={"investigation", "self_maintenance"},
        )
        assert runner is not None
        assert runner.db_path == integration_env["db_path"]
        assert runner.registry is not None
        assert len(runner.registry.get_domain_names()) > 0

    def test_single_cycle_returns_summary(self, integration_env):
        """``runner.run(max_cycles=1)`` returns a valid summary dict.

        This is THE integration test: exercise the full cycle pipeline
        on a fake workspace and confirm it finishes without raising.
        Filtered to two lightweight domains so the cycle completes
        in under the 60s per-test timeout even on a slow CI runner.
        """
        from scripts.autonomous import AutonomousRunner

        runner = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,  # $0.01 is enough room — all LLM calls are mocked
            domain_filter={"investigation", "self_maintenance"},
        )

        summary = runner.run(max_cycles=1)

        assert isinstance(summary, dict)
        # Canonical keys — if the schema of the summary dict ever
        # changes, ./nebula status and the war room reporting will
        # break in prod. Pin the shape here.
        assert "cycles" in summary
        assert "total_actions" in summary
        assert "total_cost" in summary
        assert "elapsed_seconds" in summary
        assert "domains" in summary
        assert summary["cycles"] == 1
        assert isinstance(summary["total_actions"], int)
        assert summary["total_actions"] >= 0
        assert isinstance(summary["total_cost"], (int, float))
        assert summary["total_cost"] == 0.0  # LLM patched to None
        assert isinstance(summary["elapsed_seconds"], (int, float))
        assert summary["elapsed_seconds"] >= 0

    def test_cycle_logs_start_action(self, integration_env):
        """The start of the loop writes a ``start`` action to actions_log.

        This asserts the actions_log pipeline is wired end-to-end.
        If schema migration drifted (e.g. actions_log column renamed)
        or persist_action stopped working, this would catch it
        before it broke every operator's audit trail.
        """
        from scripts.autonomous import AutonomousRunner

        runner = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"self_maintenance"},
        )
        runner.run(max_cycles=1)

        start_count = _count_rows(
            integration_env["db_path"],
            "actions_log",
            "action = 'start' AND module = 'autonomous'",
        )
        assert start_count >= 1, (
            "autonomous runner did not log a start action — the actions_log pipeline is broken"
        )

    def test_cycle_produces_evidence_or_actions(self, integration_env):
        """At least one engine ran something — evidence or logged action.

        Looser than "evidence was persisted" because fake_workspace
        deliberately lacks most real repos, and many engines graceful-
        degrade with zero findings. But at minimum the actions_log
        should record that the loop TRIED to run engines, or the
        evidence table should have at least one row from a
        successfully-firing engine.
        """
        from scripts.autonomous import AutonomousRunner

        runner = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"investigation", "self_maintenance"},
        )
        runner.run(max_cycles=1)

        actions = _count_rows(integration_env["db_path"], "actions_log")
        evidence = _count_rows(integration_env["db_path"], "evidence")

        # One or the other must be true. Zero on both means the cycle
        # didn't actually try anything — that's a seam bug.
        assert actions > 0 or evidence > 0, (
            f"neither actions_log nor evidence had rows after cycle: "
            f"actions={actions} evidence={evidence}"
        )

    def test_cycle_never_calls_real_network(self, integration_env):
        """No engine escapes the urlopen patch during a cycle.

        If any engine tries to reach a real URL during the integration
        test, the patched urlopen raises RuntimeError and the cycle
        fails. This pins: no network calls during the default
        investigation+self_maintenance domain subset. A new engine
        that adds a real network call without mocking it in its own
        tests would break this assertion.
        """
        from scripts.autonomous import AutonomousRunner

        # Belt and braces: capture any exception via a side_effect wrap.
        network_attempts: list[str] = []

        def _tracking_raise(url, *args, **kwargs):
            network_attempts.append(str(url)[:100])
            raise RuntimeError(f"integration test attempted a real network call to {url}")

        # The outer fixture already patched urlopen, but we wrap it
        # again with tracking so an assertion failure reports WHICH
        # URL was attempted.
        with patch("urllib.request.urlopen", side_effect=_tracking_raise):
            runner = AutonomousRunner(
                db_path=integration_env["db_path"],
                max_hours=0.1,
                budget=0.01,
                domain_filter={"investigation", "self_maintenance"},
            )
            # Should complete without the patched urlopen ever being
            # called (or if called, any engine should swallow the
            # exception and graceful-degrade — the runner itself
            # should not raise).
            runner.run(max_cycles=1)

        # It's acceptable for network_attempts to be empty (no engine
        # tried). If there ARE attempts, they should have been caught
        # by the engine's own exception handler — the runner completed,
        # which is the invariant. Report the count for diagnostics.
        if network_attempts:
            # Allow a modest number of attempts — the engine's
            # graceful-degrade path is doing its job if the runner
            # still completed. Pin the cap at something generous
            # because domains like github_api + vuln_feed + explorer
            # do try several URLs per cycle.
            assert len(network_attempts) < 50, (
                f"too many network attempts during cycle: "
                f"{len(network_attempts)} — first 5: "
                f"{network_attempts[:5]}"
            )

    def test_provider_registry_available_during_cycle(self, integration_env):
        """v0.6.6 — the ProviderRegistry is initialized + queryable.

        After AutonomousRunner.__init__, an engine can query the registry
        for providers. This pins the boot path: if the registry can't
        be instantiated alongside the runner, every Phase A+ feature
        breaks before the first cycle even runs.
        """
        from core.providers import get_registry
        from scripts.autonomous import AutonomousRunner

        AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"self_maintenance"},
        )
        registry = get_registry()
        names = registry.names()
        assert "github" in names
        assert "vuln_feed" in names
        assert "llm_xai" in names
        assert len(names) >= 7  # the v0.6.6 builtin set

    def test_api_call_log_table_exists_after_cycle(self, integration_env):
        """v0.6.6 — the api_call_log table is created via schema_registry.

        Assertion: after a cycle runs, the table exists. We don't
        assert rows are populated because the test workspace doesn't
        actually call any providers (filesystem-only engines).
        """
        from scripts.autonomous import AutonomousRunner

        runner = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"self_maintenance"},
        )
        runner.run(max_cycles=1)

        conn = sqlite3.connect(integration_env["db_path"])
        try:
            row = conn.execute(
                "SELECT name FROM sqlite_master WHERE type='table' AND name='api_call_log'"
            ).fetchone()
        finally:
            conn.close()
        assert row is not None, (
            "api_call_log table missing after cycle — "
            "schema_registry didn't pick up core.api_telemetry.SCHEMA_SQL"
        )

    def test_evidence_has_v066_columns_after_cycle(self, integration_env):
        """v0.6.6 — api_sources + action_spec_json columns present."""
        from scripts.autonomous import AutonomousRunner

        runner = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"self_maintenance"},
        )
        runner.run(max_cycles=1)

        conn = sqlite3.connect(integration_env["db_path"])
        try:
            cols = {row[1] for row in conn.execute("PRAGMA table_info(evidence)").fetchall()}
        finally:
            conn.close()
        assert "api_sources" in cols
        assert "action_spec_json" in cols

    def test_runner_cleanup_does_not_leak_registry(self, integration_env, clean_registry):
        """After a cycle, a fresh AutonomousRunner starts clean.

        DomainRegistry is a singleton. Two runners created back-to-back
        should not accumulate domains or leak state between cycles.
        This catches singleton drift that would cause the second
        cycle to see stale domain data.
        """
        from scripts.autonomous import AutonomousRunner

        runner1 = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"self_maintenance"},
        )
        domain_count_1 = len(runner1.registry.get_domain_names())
        runner1.run(max_cycles=1)

        runner2 = AutonomousRunner(
            db_path=integration_env["db_path"],
            max_hours=0.1,
            budget=0.01,
            domain_filter={"self_maintenance"},
        )
        domain_count_2 = len(runner2.registry.get_domain_names())

        # Runner2 should see the SAME number of domains as runner1 —
        # __init__ resets the registry, so the count should be
        # identical. A drift here means DomainRegistry.reset() is
        # failing to clear state.
        assert domain_count_1 == domain_count_2


class TestIntegrationEnvironmentGuarantees:
    """The fixture itself honors its contract: no LLM key, no network escape."""

    def test_no_xai_api_key_leak(self, integration_env):
        import os

        assert os.environ.get("XAI_API_KEY") is None

    def test_workspace_root_is_fake(self, integration_env):
        import os

        ws = os.environ.get("ZENON_WORKSPACE_ROOT")
        assert ws is not None
        assert str(integration_env["workspace"]) == ws

    def test_db_has_canonical_schema(self, integration_env):
        """ensure_schema ran during the fixture and created core tables."""
        conn = sqlite3.connect(integration_env["db_path"])
        try:
            tables = {
                r[0]
                for r in conn.execute(
                    "SELECT name FROM sqlite_master WHERE type='table'"
                ).fetchall()
            }
        finally:
            conn.close()
        for name in ("evidence", "hypotheses", "actions_log", "cost_tracking"):
            assert name in tables, f"canonical table {name} missing"
