# SPDX-License-Identifier: MIT
"""Tests for core.findings.action_spec.ActionSpec (v0.6.6)."""

from __future__ import annotations

import json
import sqlite3

import pytest

from core.findings import ActionSpec
from core.findings.action_spec import VALID_ACTION_TYPES, VALID_EFFORT, VALID_RISK
from core.persistence.findings import persist_finding


class TestConstruction:
    def test_minimal(self):
        spec = ActionSpec(action_type="fix_bug", target_repo="go-zenon")
        assert spec.action_type == "fix_bug"
        assert spec.target_repo == "go-zenon"
        assert spec.target_file is None
        assert spec.target_line is None
        assert spec.success_criteria == ()
        assert spec.effort_estimate == "unknown"
        assert spec.risk_estimate == "unknown"

    def test_full(self):
        spec = ActionSpec(
            action_type="implement_feature",
            target_repo="znn_sdk_dart",
            target_file="lib/src/api/embedded/htlc.dart",
            target_line=142,
            success_criteria=("dart test passes", "ABI matches go-zenon"),
            effort_estimate="medium",
            risk_estimate="high",
            parent_action_id=42,
        )
        assert spec.target_line == 142
        assert spec.parent_action_id == 42
        assert len(spec.success_criteria) == 2

    def test_list_coerced_to_tuple(self):
        # Pass a list, get a tuple — frozen dataclass safety
        spec = ActionSpec(
            action_type="fix_bug",
            target_repo="go-zenon",
            success_criteria=["a", "b", "c"],
        )
        assert isinstance(spec.success_criteria, tuple)
        assert spec.success_criteria == ("a", "b", "c")

    def test_invalid_action_type_raises(self):
        with pytest.raises(ValueError, match="action_type"):
            ActionSpec(action_type="invent_new_thing", target_repo="x")

    def test_empty_target_repo_raises(self):
        with pytest.raises(ValueError, match="target_repo"):
            ActionSpec(action_type="fix_bug", target_repo="")

    def test_invalid_effort_raises(self):
        with pytest.raises(ValueError, match="effort_estimate"):
            ActionSpec(
                action_type="fix_bug",
                target_repo="x",
                effort_estimate="enormous",
            )

    def test_invalid_risk_raises(self):
        with pytest.raises(ValueError, match="risk_estimate"):
            ActionSpec(
                action_type="fix_bug",
                target_repo="x",
                risk_estimate="apocalyptic",
            )

    def test_negative_target_line_raises(self):
        with pytest.raises(ValueError, match="target_line"):
            ActionSpec(action_type="fix_bug", target_repo="x", target_line=-5)

    def test_target_line_zero_allowed(self):
        # 0 is technically a valid line number for "top of file" markers
        spec = ActionSpec(action_type="fix_bug", target_repo="x", target_line=0)
        assert spec.target_line == 0


class TestSerialization:
    def test_to_dict(self):
        spec = ActionSpec(
            action_type="fix_bug",
            target_repo="go-zenon",
            success_criteria=("test passes",),
        )
        d = spec.to_dict()
        assert d["action_type"] == "fix_bug"
        assert d["target_repo"] == "go-zenon"
        assert d["success_criteria"] == ("test passes",)

    def test_to_json_canonical(self):
        spec = ActionSpec(action_type="fix_bug", target_repo="go-zenon")
        j = spec.to_json()
        # Sort_keys=True means deterministic output
        assert ActionSpec.from_json(j) == spec

    def test_roundtrip(self):
        original = ActionSpec(
            action_type="harden_hypothesis",
            target_repo="knowledge/developer-commons",
            target_file="docs/specs/PTLC/ptlc_spec.md",
            target_line=42,
            success_criteria=("test vector verified", "ABI matches"),
            effort_estimate="small",
            risk_estimate="low",
            parent_action_id=99,
        )
        j = original.to_json()
        restored = ActionSpec.from_json(j)
        assert restored == original

    def test_from_dict_filters_unknown_fields(self):
        # A future field added to ActionSpec shouldn't crash older code
        # reading newer DB rows.
        d = {
            "action_type": "fix_bug",
            "target_repo": "go-zenon",
            "future_field_we_dont_know": "ignored",
        }
        spec = ActionSpec.from_dict(d)
        assert spec.target_repo == "go-zenon"


class TestPersistFindingIntegration:
    def test_action_spec_persists_to_evidence(self, db_path):
        spec = ActionSpec(
            action_type="fix_bug",
            target_repo="go-zenon",
            target_file="vm/embedded/htlc/htlc.go",
            target_line=142,
            success_criteria=("go test ./... passes",),
            effort_estimate="small",
            risk_estimate="low",
        )
        fid = persist_finding(
            db_path=db_path,
            domain="security",
            engine="test_engine",
            evidence_type="bug",
            finding="WHAT/SO WHAT/NOW WHAT body",
            confidence=0.75,
            api_sources=["github"],
            action_spec=spec,
        )
        assert fid > 0

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT api_sources, action_spec_json FROM evidence WHERE id = ?",
                (fid,),
            ).fetchone()
        finally:
            conn.close()

        assert row[0] == json.dumps(["github"])
        assert row[1] is not None
        restored = ActionSpec.from_json(row[1])
        assert restored == spec

    def test_finding_without_action_spec_is_null(self, db_path):
        fid = persist_finding(
            db_path=db_path,
            domain="test",
            engine="test_engine",
            evidence_type="test",
            finding="legacy finding",
            confidence=0.5,
        )
        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute(
                "SELECT api_sources, action_spec_json FROM evidence WHERE id = ?",
                (fid,),
            ).fetchone()
        finally:
            conn.close()
        assert row[0] is None
        assert row[1] is None


class TestValidationConstants:
    def test_valid_action_types_set(self):
        # Pin the v0.6.6 set so future additions are visible in diffs
        assert "fix_bug" in VALID_ACTION_TYPES
        assert "implement_feature" in VALID_ACTION_TYPES
        assert "harden_hypothesis" in VALID_ACTION_TYPES

    def test_valid_effort_includes_unknown(self):
        assert "unknown" in VALID_EFFORT

    def test_valid_risk_includes_critical(self):
        assert "critical" in VALID_RISK
