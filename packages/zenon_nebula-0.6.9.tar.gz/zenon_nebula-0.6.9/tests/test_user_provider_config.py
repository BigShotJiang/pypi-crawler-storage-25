# SPDX-License-Identifier: MIT
"""Tests for Phase B — user provider config + MCP consumer (v0.6.9).

Covers:
- ``core.providers.loader`` TOML parsing + path resolution + validation
- ``core.providers.declarative_api.DeclarativeAPIProvider`` construction,
  path-param substitution, URL building, JSON-path projection
- ``core.providers.mcp_consumer.MCPConsumerProvider`` construction +
  transport selection
- ``core.trust.cap_confidence_by_provider`` user-provider trust cap
- End-to-end: persist_finding routes findings through the cap when
  api_sources cites a user-declared provider
"""

from __future__ import annotations

import os
import sqlite3
from pathlib import Path
from unittest.mock import patch

import pytest

from core.providers.declarative_api import DeclarativeAPIProvider
from core.providers.loader import (
    _candidate_config_paths,
    _validate_api_entry,
    _validate_mcp_entry,
    load_user_providers,
)
from core.providers.mcp_consumer import MCPConsumerProvider
from core.providers.registry import ProviderRegistry


@pytest.fixture
def fresh_registry():
    ProviderRegistry.reset()
    reg = ProviderRegistry.instance()
    yield reg
    ProviderRegistry.reset()


# ---------------------------------------------------------------------------
# Loader — path resolution
# ---------------------------------------------------------------------------


class TestCandidatePaths:
    def test_includes_repo_fallback(self):
        paths = _candidate_config_paths()
        # The last entry should be <repo>/data/user_providers.toml
        assert any("data/user_providers.toml" in str(p) for p in paths)

    def test_respects_nebula_providers_config_env(self, monkeypatch, tmp_path):
        override = tmp_path / "custom.toml"
        monkeypatch.setenv("NEBULA_PROVIDERS_CONFIG", str(override))
        paths = _candidate_config_paths()
        assert paths[0] == override

    def test_respects_xdg_config_home(self, monkeypatch, tmp_path):
        xdg = tmp_path / "xdg"
        monkeypatch.setenv("XDG_CONFIG_HOME", str(xdg))
        monkeypatch.delenv("NEBULA_PROVIDERS_CONFIG", raising=False)
        paths = _candidate_config_paths()
        assert any(str(p).startswith(str(xdg)) for p in paths)


# ---------------------------------------------------------------------------
# Loader — validation
# ---------------------------------------------------------------------------


class TestValidation:
    def test_api_valid(self):
        entry = {
            "name": "x",
            "base_url": "https://api.example.com",
            "endpoints": [{"method_name": "get", "path": "/foo"}],
        }
        assert _validate_api_entry(entry, 0) == []

    def test_api_missing_name(self):
        errors = _validate_api_entry({"base_url": "https://api.example.com"}, 0)
        assert any("name" in e for e in errors)

    def test_api_missing_base_url(self):
        errors = _validate_api_entry({"name": "x"}, 0)
        assert any("base_url" in e for e in errors)

    def test_api_bad_scheme(self):
        errors = _validate_api_entry({"name": "x", "base_url": "ftp://x"}, 0)
        assert any("base_url" in e for e in errors)

    def test_api_missing_endpoint_method_name(self):
        errors = _validate_api_entry(
            {
                "name": "x",
                "base_url": "https://x",
                "endpoints": [{"path": "/foo"}],
            },
            0,
        )
        assert any("method_name" in e for e in errors)

    def test_mcp_valid_stdio(self):
        assert _validate_mcp_entry({"name": "x", "command": "python3"}, 0) == []

    def test_mcp_valid_http(self):
        assert _validate_mcp_entry({"name": "x", "url": "https://x"}, 0) == []

    def test_mcp_both_transports(self):
        errors = _validate_mcp_entry({"name": "x", "command": "python3", "url": "https://x"}, 0)
        assert any("both" in e for e in errors)

    def test_mcp_no_transport(self):
        errors = _validate_mcp_entry({"name": "x"}, 0)
        assert any("either" in e for e in errors)


# ---------------------------------------------------------------------------
# Loader — TOML parsing end-to-end
# ---------------------------------------------------------------------------


def _write_config(path: Path, content: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(content)


class TestLoaderE2E:
    def test_empty_config_returns_empty(self, tmp_path):
        config = tmp_path / "providers.toml"
        _write_config(config, "")
        result = load_user_providers(config_path=config)
        assert result == []

    def test_missing_file_returns_empty(self, tmp_path):
        result = load_user_providers(config_path=tmp_path / "nope.toml")
        assert result == []

    def test_one_api_provider(self, tmp_path):
        config = tmp_path / "providers.toml"
        _write_config(
            config,
            "[[api]]\n"
            'name = "test-api"\n'
            'base_url = "https://api.example.com"\n'
            "[[api.endpoints]]\n"
            'method_name = "ping"\n'
            'http_method = "GET"\n'
            'path = "/ping"\n',
        )
        providers = load_user_providers(config_path=config)
        assert len(providers) == 1
        assert providers[0].name() == "test-api"
        assert providers[0].kind() == "api-user"

    def test_invalid_entry_skipped_but_rest_loaded(self, tmp_path):
        config = tmp_path / "providers.toml"
        _write_config(
            config,
            "[[api]]\n"
            'name = "bad-api"\n'
            "# missing base_url\n"
            "\n"
            "[[api]]\n"
            'name = "good-api"\n'
            'base_url = "https://api.example.com"\n'
            "[[api.endpoints]]\n"
            'method_name = "ping"\n'
            'path = "/ping"\n',
        )
        providers = load_user_providers(config_path=config)
        assert len(providers) == 1
        assert providers[0].name() == "good-api"

    def test_malformed_toml_returns_empty(self, tmp_path):
        config = tmp_path / "providers.toml"
        _write_config(config, "this is not valid toml at all [[[")
        providers = load_user_providers(config_path=config)
        assert providers == []


# ---------------------------------------------------------------------------
# DeclarativeAPIProvider
# ---------------------------------------------------------------------------


class TestDeclarativeAPIProvider:
    def _spec(self, **overrides):
        base = {
            "name": "test",
            "base_url": "https://api.example.com",
            "endpoints": [
                {
                    "method_name": "get_item",
                    "http_method": "GET",
                    "path": "/items/{id}",
                }
            ],
        }
        base.update(overrides)
        return base

    def test_construction(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p.name() == "test"
        assert p.kind() == "api-user"
        assert p.is_available() is True

    def test_trust_tier_default(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p.trust_tier() == "user"

    def test_trust_tier_override(self):
        p = DeclarativeAPIProvider(spec=self._spec(trust_tier="peer"))
        assert p.trust_tier() == "peer"

    def test_unknown_method_returns_none(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p.call("nonexistent") is None

    def test_path_param_substitution(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        url = p._build_url("/items/{id}", {"id": "42"})
        assert url == "https://api.example.com/items/42"

    def test_path_param_url_encoding(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        url = p._build_url("/items/{id}", {"id": "hello world"})
        assert url == "https://api.example.com/items/hello%20world"

    def test_extra_kwargs_become_query_params(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        url = p._build_url("/items/{id}", {"id": "42", "filter": "new"})
        assert "filter=new" in url

    def test_jsonpath_projection_simple(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p._project_jsonpath({"data": {"x": 1}}, "$.data") == {"x": 1}

    def test_jsonpath_projection_nested(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p._project_jsonpath({"a": {"b": {"c": 42}}}, "$.a.b.c") == 42

    def test_jsonpath_projection_array_index(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p._project_jsonpath({"items": ["a", "b"]}, "$.items.0") == "a"

    def test_jsonpath_missing_path_returns_none(self):
        p = DeclarativeAPIProvider(spec=self._spec())
        assert p._project_jsonpath({"a": 1}, "$.nonexistent") is None


# ---------------------------------------------------------------------------
# MCPConsumerProvider
# ---------------------------------------------------------------------------


class TestMCPConsumerProvider:
    def test_stdio_construction(self):
        p = MCPConsumerProvider(spec={"name": "x", "command": "python3", "args": ["/tmp/x.py"]})
        assert p.name() == "x"
        assert p.kind() == "mcp-user"
        assert p.is_available() is True

    def test_http_construction(self):
        p = MCPConsumerProvider(spec={"name": "x", "url": "https://mcp.example.com:3000"})
        assert p.name() == "x"
        assert p.is_available() is True

    def test_both_transports_raises(self):
        with pytest.raises(ValueError, match="both"):
            MCPConsumerProvider(spec={"name": "x", "command": "python3", "url": "https://x"})

    def test_no_transport_raises(self):
        with pytest.raises(ValueError, match="either"):
            MCPConsumerProvider(spec={"name": "x"})

    def test_shutdown_is_safe(self):
        p = MCPConsumerProvider(spec={"name": "x", "command": "python3"})
        p.shutdown()  # should not raise

    def test_list_tools_empty_for_mvp(self):
        p = MCPConsumerProvider(spec={"name": "x", "url": "https://x"})
        assert p.list_tools() == []


# ---------------------------------------------------------------------------
# Trust cap by provider
# ---------------------------------------------------------------------------


class TestTrustCapByProvider:
    def test_no_api_sources_unchanged(self):
        from core.trust import cap_confidence_by_provider

        assert cap_confidence_by_provider(0.9, None) == 0.9
        assert cap_confidence_by_provider(0.9, []) == 0.9

    def test_builtin_provider_unchanged(self, fresh_registry):
        from core.trust import cap_confidence_by_provider

        # github is a builtin (kind=api-builtin) — should NOT cap
        assert cap_confidence_by_provider(0.9, ["github"]) == 0.9

    def test_user_api_provider_caps_confidence(self, fresh_registry):
        from core.trust import DEFAULT_TRUST, cap_confidence_by_provider

        # Register a user provider
        p = DeclarativeAPIProvider(
            spec={
                "name": "user-api",
                "base_url": "https://x.example.com",
                "endpoints": [{"method_name": "m", "path": "/foo"}],
            }
        )
        fresh_registry.register(p)

        capped = cap_confidence_by_provider(0.95, ["user-api"])
        assert capped == DEFAULT_TRUST  # 0.30 by default

    def test_user_mcp_provider_caps_confidence(self, fresh_registry):
        from core.trust import DEFAULT_TRUST, cap_confidence_by_provider

        p = MCPConsumerProvider(spec={"name": "user-mcp", "command": "python3"})
        fresh_registry.register(p)
        capped = cap_confidence_by_provider(0.95, ["user-mcp"])
        assert capped == DEFAULT_TRUST

    def test_user_provider_below_cap_unchanged(self, fresh_registry):
        from core.trust import cap_confidence_by_provider

        p = DeclarativeAPIProvider(
            spec={
                "name": "user-api2",
                "base_url": "https://x.example.com",
                "endpoints": [{"method_name": "m", "path": "/foo"}],
            }
        )
        fresh_registry.register(p)
        # 0.10 is below the 0.30 cap, so unchanged
        assert cap_confidence_by_provider(0.10, ["user-api2"]) == 0.10

    def test_mixed_builtin_and_user_caps(self, fresh_registry):
        from core.trust import DEFAULT_TRUST, cap_confidence_by_provider

        p = DeclarativeAPIProvider(
            spec={
                "name": "user-api3",
                "base_url": "https://x.example.com",
                "endpoints": [{"method_name": "m", "path": "/foo"}],
            }
        )
        fresh_registry.register(p)
        # If ANY cited provider is user, the cap applies
        capped = cap_confidence_by_provider(0.9, ["github", "user-api3"])
        assert capped == DEFAULT_TRUST


# ---------------------------------------------------------------------------
# persist_finding integration with trust cap
# ---------------------------------------------------------------------------


class TestPersistFindingWithUserProvider:
    def test_user_provider_finding_capped_at_persist(self, fresh_registry, db_path):
        """End-to-end: an engine passing high confidence + user-provider
        api_sources gets its finding capped BEFORE the row is written."""
        from core.persistence.findings import persist_finding

        p = DeclarativeAPIProvider(
            spec={
                "name": "user-cap-test",
                "base_url": "https://x.example.com",
                "endpoints": [{"method_name": "m", "path": "/foo"}],
            }
        )
        fresh_registry.register(p)

        fid = persist_finding(
            db_path=db_path,
            domain="test",
            engine="test_engine",
            evidence_type="test",
            finding="high-confidence claim that should be capped",
            confidence=0.95,
            api_sources=["user-cap-test"],
        )
        assert fid > 0

        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute("SELECT confidence FROM evidence WHERE id = ?", (fid,)).fetchone()
        finally:
            conn.close()
        # Confidence should be capped at DEFAULT_TRUST (0.30)
        assert row[0] <= 0.30

    def test_builtin_provider_finding_not_capped(self, fresh_registry, db_path):
        from core.persistence.findings import persist_finding

        fid = persist_finding(
            db_path=db_path,
            domain="test",
            engine="test_engine",
            evidence_type="test",
            finding="high-confidence claim from builtin source",
            confidence=0.85,
            api_sources=["github"],  # builtin
        )
        conn = sqlite3.connect(db_path)
        try:
            row = conn.execute("SELECT confidence FROM evidence WHERE id = ?", (fid,)).fetchone()
        finally:
            conn.close()
        # Not capped — passes through as 0.85
        assert row[0] == pytest.approx(0.85, abs=0.01)


# ---------------------------------------------------------------------------
# Registry reload
# ---------------------------------------------------------------------------


class TestRegistryReload:
    def test_reload_removes_stale_user_providers(self, fresh_registry):
        # Register a user provider manually
        p = DeclarativeAPIProvider(
            spec={
                "name": "stale-user",
                "base_url": "https://x.example.com",
                "endpoints": [{"method_name": "m", "path": "/foo"}],
            }
        )
        fresh_registry.register(p)
        assert "stale-user" in fresh_registry

        # Reload with no user config file — should drop the stale entry
        with patch("core.providers.loader.load_user_providers", return_value=[]):
            count = fresh_registry.reload()
        assert count == 0
        assert "stale-user" not in fresh_registry

    def test_reload_preserves_builtins(self, fresh_registry):
        # Builtins should survive reload
        with patch("core.providers.loader.load_user_providers", return_value=[]):
            fresh_registry.reload()
        assert "github" in fresh_registry
        assert "vuln_feed" in fresh_registry
