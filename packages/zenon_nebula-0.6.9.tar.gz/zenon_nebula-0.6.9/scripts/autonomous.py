#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
Autonomous Runner -- State-driven loop for the Nebula meta-layer.

Coordinates all domains through the unified Director, Collision Engine,
War Room, Strategy Evolver, Self-Improver, and Knowledge Graph.

Loop structure (every cycle, ~15 minutes):
  1. Domain registry loads all domains
  2. Director reads landscape, ranks cross-domain proposals
  3. Collision engine checks for convergent evidence
  4. Best action is selected and executed
  5. War Room runs daily (every 24h)
  6. Strategy Evolver runs weekly
  7. Self-Improver runs weekly
  8. Knowledge Graph refreshes after significant events

Usage:
  python3 scripts/autonomous.py --once          # single cycle
  python3 scripts/autonomous.py --max-hours 12  # 12-hour run
  python3 scripts/autonomous.py --budget 20.0   # $20 budget cap
"""

import argparse
import json
import logging
import os
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

# Ensure engine root is on sys.path
ENGINE_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ENGINE_ROOT))

# Load .env for API keys
try:
    from dotenv import load_dotenv

    load_dotenv(ENGINE_ROOT / ".env")
except ImportError:
    # Fallback: manually parse .env
    env_file = ENGINE_ROOT / ".env"
    if env_file.exists():
        for line in env_file.read_text().splitlines():
            line = line.strip()
            if line and not line.startswith("#") and "=" in line:
                key, _, value = line.partition("=")
                os.environ.setdefault(key.strip(), value.strip())

from core.collision_engine import CollisionEngine
from core.director import UnifiedDirector
from core.domain_registry import DomainRegistry
from core.feedback_bus import FeedbackBus
from core.knowledge_graph import KnowledgeGraph
from core.persist_to_db import (
    DEFAULT_DB,
    ensure_schema,
    persist_action,
)
from core.persistence import connect
from core.resilience import (
    CheckpointManager,
    GracefulShutdown,
    startup_checks,
)
from core.self_improver import SelfImprover
from core.strategy_evolver import StrategyEvolver
from core.war_room import WarRoom

logger = logging.getLogger(__name__)

# Timing — War Room prescribed: run meta-layer after every batch, not on schedule
CYCLE_INTERVAL_SECONDS = 1  # Brief pause between cycles
MIN_ACTIONS_PER_CYCLE = 3  # Don't exit after 1 action
MIN_CYCLE_DURATION_SECONDS = 5  # Minimum cycle time (was 30, too slow)
WAR_ROOM_INTERVAL_HOURS = 0.15  # Every ~10 min (not every cycle)
STRATEGY_INTERVAL_HOURS = 1.0  # Hourly (not every cycle)
SELF_IMPROVE_INTERVAL_HOURS = 0.15  # Every ~10 min
KNOWLEDGE_GRAPH_INTERVAL_HOURS = 0.15  # Every ~10 min

# Safety limits
MAX_ACTIONS_PER_HOUR = 100
MAX_ACTIONS_PER_CYCLE = 20  # Cap per cycle (17 domains + headroom)
MAX_CONSECUTIVE_ERRORS = 5
DEFAULT_MAX_HOURS = 24
DEFAULT_BUDGET = 50.0


def _register_domains(registry: DomainRegistry) -> None:
    """Auto-discover and register ALL available domain plugins."""
    import importlib

    domains_dir = ENGINE_ROOT / "domains"
    registered = 0
    failed = 0

    for domain_dir in sorted(domains_dir.iterdir()):
        if not domain_dir.is_dir() or domain_dir.name.startswith("_"):
            continue
        domain_py = domain_dir / "domain.py"
        if not domain_py.exists():
            continue

        try:
            mod = importlib.import_module(f"domains.{domain_dir.name}.domain")
            # Find the DomainPlugin subclass
            for attr_name in dir(mod):
                attr = getattr(mod, attr_name)
                if (
                    isinstance(attr, type)
                    and hasattr(attr, "get_engines")
                    and attr_name not in ("DomainPlugin", "ABC")
                ):
                    try:
                        instance = attr()
                        registry.register(instance)
                        registered += 1
                        break
                    except Exception as inner_exc:
                        logger.warning(
                            "Could not instantiate %s.%s: %s", domain_dir.name, attr_name, inner_exc
                        )
                        failed += 1
        except Exception as exc:
            logger.warning("Could not import domain %s: %s", domain_dir.name, exc)
            failed += 1

    logger.info("Domain registration: %d registered, %d failed", registered, failed)


class AutonomousRunner:
    """State-driven autonomous loop coordinating all meta-layer modules."""

    def __init__(
        self,
        db_path: str = DEFAULT_DB,
        max_hours: float = DEFAULT_MAX_HOURS,
        budget: float = DEFAULT_BUDGET,
        domain_filter: set | None = None,
    ):
        self.db_path = db_path
        self.max_hours = max_hours
        self.budget = budget
        self.domain_filter = domain_filter  # None = all domains

        # Startup checks (disk space, DB integrity, resume info)
        checks = startup_checks(db_path)
        if not checks["disk_space"]:
            logger.error("Insufficient disk space. Aborting.")
        if checks["checkpoint"]["was_mid_cycle"]:
            logger.info(
                "Resuming from interrupted cycle. Previously completed: %s",
                checks["checkpoint"]["engines_completed"],
            )

        # Ensure database schema
        ensure_schema(db_path)

        # Initialize registry
        DomainRegistry.reset()
        self.registry = DomainRegistry.instance()
        _register_domains(self.registry)

        if self.domain_filter:
            logger.info("Domain filter active: %s", sorted(self.domain_filter))

        # Initialize meta-layer
        self.director = UnifiedDirector(db_path=db_path)
        self.collision_engine = CollisionEngine(db_path=db_path)
        self.war_room = WarRoom(db_path=db_path)
        self.strategy_evolver = StrategyEvolver(db_path=db_path)
        self.self_improver = SelfImprover(db_path=db_path)
        self.knowledge_graph = KnowledgeGraph(db_path=db_path)
        self.bus = FeedbackBus(db_path=db_path)

        # Resilience — checkpoint per DB instance to avoid cross-process conflicts
        checkpoint_path = str(Path(db_path).parent / "checkpoint.json")
        self.checkpoint = CheckpointManager(checkpoint_path=checkpoint_path)
        self.shutdown = GracefulShutdown()

        # State tracking
        self._skip_engines = set()  # engines that failed due to missing infrastructure
        self._engine_cache = {}  # {key: (entry_fn, needs_db)} — avoids re-import
        self._engine_cooldowns = {}  # {key: cycles_to_skip} — backs off unproductive engines
        self._cycle_number = 0
        self.total_cost = 0.0
        self.total_actions = 0
        self.consecutive_errors = 0
        self.last_war_room = None
        self.last_strategy_evolve = None
        self.last_self_improve = None
        self.last_knowledge_graph = None
        self.start_time = None

    # ------------------------------------------------------------------
    # Main loop
    # ------------------------------------------------------------------

    def run(self, once: bool = False, max_cycles: int = 0) -> dict:
        """Run the autonomous loop.

        Args:
            once: If True, run a single cycle and return.
            max_cycles: If > 0, stop after this many cycles.

        Returns:
            Summary dict of the run.
        """
        try:
            return self._run_impl(once=once, max_cycles=max_cycles)
        except BaseException as exc:
            # Last-resort crash reporter. Only fires when the loop itself
            # explodes -- per-cycle errors are handled inside _run_impl.
            try:
                from core.telemetry import report_crash

                report_crash(exc, context="autonomous.run")
            except Exception as crash_exc:
                logger.debug("crash reporter itself failed: %s", crash_exc)
            raise

    def _run_impl(self, once: bool = False, max_cycles: int = 0) -> dict:
        """Internal entry point that implements the autonomous loop body."""
        self.start_time = datetime.now(timezone.utc)
        deadline = self.start_time + timedelta(hours=self.max_hours)
        cycle_count = 0

        logger.info(
            "=== AUTONOMOUS RUNNER START === domains=%d, max_hours=%.1f, budget=$%.2f",
            len(self.registry.get_domain_names()),
            self.max_hours,
            self.budget,
        )

        persist_action(
            db_path=self.db_path,
            domain="system",
            module="autonomous",
            action="start",
            result=json.dumps(
                {
                    "domains": self.registry.get_domain_names(),
                    "max_hours": self.max_hours,
                    "budget": self.budget,
                }
            ),
        )

        while True:
            now = datetime.now(timezone.utc)

            # Check termination conditions
            if self.shutdown.should_stop:
                logger.info("Graceful shutdown requested. Stopping.")
                break
            if now >= deadline:
                logger.info("Time limit reached. Stopping.")
                break
            if self.total_cost >= self.budget:
                logger.info("Budget exhausted. Stopping.")
                break
            if self.consecutive_errors >= MAX_CONSECUTIVE_ERRORS:
                logger.error(
                    "%d consecutive errors. Stopping.",
                    self.consecutive_errors,
                )
                break
            if self.checkpoint.should_pause():
                logger.error("Too many consecutive failures. Pausing.")
                break

            # Run one cycle
            try:
                self._run_cycle()
                cycle_count += 1
                self.consecutive_errors = 0
                self.checkpoint.cycle_completed()
            except Exception as exc:
                self.consecutive_errors += 1
                logger.error(
                    "Cycle error (%d consecutive): %s",
                    self.consecutive_errors,
                    exc,
                )
                self.checkpoint.engine_failed("cycle", str(exc))
                persist_action(
                    db_path=self.db_path,
                    domain="system",
                    module="autonomous",
                    action="cycle_error",
                    error=str(exc),
                )

            if once:
                break
            if max_cycles > 0 and cycle_count >= max_cycles:
                logger.info("Reached max_cycles=%d. Stopping.", max_cycles)
                break

            # Sleep until next cycle
            elapsed = (datetime.now(timezone.utc) - now).total_seconds()
            sleep_time = max(0, CYCLE_INTERVAL_SECONDS - elapsed)
            if sleep_time > 0:
                logger.info("Sleeping %.0fs until next cycle...", sleep_time)
                time.sleep(sleep_time)

        elapsed_total = (datetime.now(timezone.utc) - self.start_time).total_seconds()

        summary = {
            "cycles": cycle_count,
            "total_actions": self.total_actions,
            "total_cost": round(self.total_cost, 4),
            "elapsed_seconds": round(elapsed_total, 1),
            "domains": self.registry.get_domain_names(),
        }

        persist_action(
            db_path=self.db_path,
            domain="system",
            module="autonomous",
            action="stop",
            result=json.dumps(summary),
        )

        logger.info(
            "=== AUTONOMOUS RUNNER STOP === cycles=%d, actions=%d, cost=$%.4f, elapsed=%.0fs",
            cycle_count,
            self.total_actions,
            self.total_cost,
            elapsed_total,
        )
        return summary

    # ------------------------------------------------------------------
    # Engine execution
    # ------------------------------------------------------------------

    def _evidence_count(self) -> int:
        """Quick evidence row count for tracking engine productivity."""
        try:
            conn = connect(self.db_path)
            count = conn.execute("SELECT COUNT(*) FROM evidence").fetchone()[0]
            conn.close()
            return count
        except Exception as exc:
            logger.debug("Evidence count query failed: %s", exc)
            return 0

    def _execute_engine(self, domain_name: str, engine_name: str) -> str:
        """Import and run an engine module, returning a result summary.

        Caches module imports and entry-point resolution. Tracks cooldowns
        for engines that produce no new findings.
        """
        if not engine_name:
            return "no engine specified"

        cache_key = f"{domain_name}/{engine_name}"

        # Skip engines that need unavailable infrastructure
        if cache_key in self._skip_engines:
            return f"{engine_name}: skipped"

        # Cooldown: engines that found nothing wait before re-running
        cooldown = self._engine_cooldowns.get(cache_key, 0)
        if cooldown > 0:
            self._engine_cooldowns[cache_key] = cooldown - 1
            return f"{engine_name}: cooling down ({cooldown} cycles left)"

        module_path = f"domains.{domain_name}.engines.{engine_name}"
        try:
            import inspect

            # Cache module import + entry point resolution
            if cache_key not in self._engine_cache:
                import importlib

                mod = importlib.import_module(module_path)

                # Helper: does this candidate have only args we can fill?
                def _is_callable_no_required_args(fn):
                    try:
                        sig = inspect.signature(fn)
                    except (ValueError, TypeError):
                        return False
                    for p in sig.parameters.values():
                        if (
                            p.default is inspect.Parameter.empty
                            and p.kind
                            in (
                                inspect.Parameter.POSITIONAL_OR_KEYWORD,
                                inspect.Parameter.POSITIONAL_ONLY,
                            )
                            and p.name not in ("db_path", "specs", "self", "registry")
                        ):
                            return False
                    return True

                # Candidate discovery: iterate prefixes, return FIRST
                # candidate whose required args we can satisfy. This lets us
                # skip past helper imports like ``run_git`` that happen to
                # match ``run_`` but need positional args.
                entry_fn = None
                prefixes = (
                    # Highest-priority names first: engine-specific matches
                    "persist_findings",
                    "run_all",
                    "run_",
                    "scan_all",
                    "check_all",
                    "refresh_",
                    "scan_",
                    "check_",
                    "analyze_",
                    "detect_",
                    "process_",
                    "assess_",
                    "build_",
                    "get_build",
                    "classify_",
                    "evaluate_",
                    "fetch_",
                    "calculate_",
                    "generate_",
                )
                fallback_fn = None  # first name-match, even if args missing
                for prefix in prefixes:
                    for attr_name in sorted(dir(mod)):
                        if not attr_name.startswith(prefix):
                            continue
                        candidate = getattr(mod, attr_name)
                        if not callable(candidate):
                            continue
                        if fallback_fn is None:
                            fallback_fn = candidate
                        if _is_callable_no_required_args(candidate):
                            entry_fn = candidate
                            break
                    if entry_fn:
                        break

                if entry_fn is None:
                    # No zero-arg candidate — fall back so we at least report
                    # a meaningful skip reason instead of "no entry point".
                    entry_fn = fallback_fn

                if entry_fn is None:
                    self._skip_engines.add(cache_key)
                    return f"no entry point found in {module_path}"

                sig = inspect.signature(entry_fn)
                params = sig.parameters
                # Check for required positional args that we can't provide
                required_missing = [
                    p.name
                    for p in params.values()
                    if p.default is inspect.Parameter.empty
                    and p.kind
                    in (inspect.Parameter.POSITIONAL_OR_KEYWORD, inspect.Parameter.POSITIONAL_ONLY)
                    and p.name not in ("db_path", "specs", "self", "registry")
                ]
                if required_missing:
                    self._skip_engines.add(cache_key)
                    return f"{engine_name}: skipped (needs args: {required_missing})"
                needs_db = "db_path" in params
                needs_specs = "specs" in params
                self._engine_cache[cache_key] = (entry_fn, needs_db, needs_specs)

            entry_fn, needs_db, needs_specs = self._engine_cache[cache_key]
            kwargs = {}
            if needs_db:
                kwargs["db_path"] = self.db_path
            if needs_specs:
                # Load specs from the dev domain's spec_tracker
                try:
                    from domains.development.engines.spec_tracker import scan_all_specs

                    kwargs["specs"] = scan_all_specs()
                except Exception:
                    kwargs["specs"] = []

            # Track evidence count before/after to detect productive runs
            pre_count = self._evidence_count()
            result = entry_fn(**kwargs)
            post_count = self._evidence_count()
            new_findings = post_count - pre_count

            # Adaptive cooldown: only cool down file-scanning engines (not API engines)
            # API engines may return useful data even without new evidence rows
            is_api_engine = any(
                x in str(result) for x in ["success", "tvl", "pillar", "balance", "price"]
            )
            if new_findings == 0 and not is_api_engine:
                prev_cooldown = self._engine_cooldowns.get(cache_key, 0)
                self._engine_cooldowns[cache_key] = min(prev_cooldown + 1, 3)  # max 3 (was 5)
            else:
                self._engine_cooldowns[cache_key] = 0  # reset on success or API engine

            # Summarize result
            if isinstance(result, list):
                return f"{engine_name}: {len(result)} items"
            elif isinstance(result, dict):
                return f"{engine_name}: {json.dumps(result, default=str)[:200]}"
            elif result is not None:
                return f"{engine_name}: {str(result)[:200]}"
            return f"{engine_name}: completed"

        except Exception as exc:
            err_msg = str(exc)
            # Auto-skip engines with missing infrastructure (won't fix mid-run)
            if "missing" in err_msg.lower() and (
                "argument" in err_msg.lower() or "module" in err_msg.lower()
            ):
                self._skip_engines.add(cache_key)
                logger.info(
                    "Engine %s/%s requires unavailable infrastructure, skipping future cycles",
                    domain_name,
                    engine_name,
                )
            else:
                logger.warning("Engine %s/%s failed: %s", domain_name, engine_name, exc)
            return f"{engine_name}: ERROR — {err_msg[:150]}"

    # ------------------------------------------------------------------
    # Single cycle
    # ------------------------------------------------------------------

    def _run_cycle(self) -> None:
        """Execute one autonomous cycle."""
        self._cycle_number += 1
        now = datetime.now(timezone.utc)
        logger.info("--- Cycle %d at %s ---", self._cycle_number, now.isoformat())

        # 1. Director: read landscape and prioritize engines
        landscape = self.director.get_evidence_landscape()
        self.director.prioritize_engines(self.registry)
        stalled = self.director.detect_stalled()

        if stalled:
            logger.info("Stalled items detected: %d", len(stalled))
            for item in stalled[:3]:
                self.bus.post(
                    sender="director",
                    recipient="all",
                    message_type="stall_alert",
                    data=item,
                    domain=item.get("domain", "system"),
                )

        # 2. Collect all domain actions, then execute in parallel
        actions_to_run = []
        seen_actions = set()

        for _ in range(MAX_ACTIONS_PER_CYCLE):
            context = {
                "trigger_level": self._determine_trigger_level(landscape),
                "stale_data": self._identify_stale(landscape),
                "budget_remaining": self.budget - self.total_cost,
            }
            action = self.registry.decide_next_action(context, exclude=seen_actions)

            if not action:
                break

            # Skip domains not in filter (if filter is active)
            if self.domain_filter and action.get("domain") not in self.domain_filter:
                seen_actions.add(f"{action.get('domain')}:{action.get('action')}")
                continue

            # Tiered scheduling: low-priority domains run less often
            from core.engine_scheduler import should_run_domain

            if not should_run_domain(action.get("domain", ""), self._cycle_number):
                seen_actions.add(f"{action.get('domain')}:{action.get('action')}")
                continue

            action_key = f"{action.get('domain')}:{action.get('action')}"
            seen_actions.add(action_key)
            actions_to_run.append(action)

        # Execute engines in parallel (I/O bound — threads are effective).
        # max_workers was hardcoded at 16 pre-v0.2.18, which thrashes on a
        # 2-core 2GB VPS. v0.2.18 wires in the machine profile from
        # core.parallel_runner.detect_machine() so a tiny box gets 2-4
        # workers and a beefy box gets up to 16. The cap honors the env
        # var as an explicit operator override (e.g. for shared CI
        # runners or memory-constrained sandboxes). Most engines are
        # I/O-bound (HTTP to GitHub, xAI, RPC peers), so we allow up to
        # 2x the CPU-bound recommendation since waiting threads cost
        # almost nothing.
        from concurrent.futures import ThreadPoolExecutor, as_completed

        def _run_one(action):
            domain_name = action.get("domain", "?")
            engine_name = action.get("engine", "")
            result = self._execute_engine(domain_name, engine_name)
            return action, result

        # Wire in the machine profile so the default cap scales to the box.
        if not hasattr(self, "_logged_parallel_default"):
            try:
                from core.parallel_runner import detect_machine

                profile = detect_machine()
                # I/O-heavy → ~2x the CPU-bound recommendation, capped at 16.
                default_workers = max(
                    profile.recommended_parallelism,
                    min(16, profile.cpu_cores * 2),
                )
            except Exception:
                # Fall back to a conservative middle ground if detection fails.
                default_workers = 4
                profile = None
            override = os.environ.get("NEBULA_MAX_PARALLEL_ENGINES")
            if override:
                try:
                    self._max_workers_cap = int(override)
                    source = f"NEBULA_MAX_PARALLEL_ENGINES={override}"
                except ValueError:
                    self._max_workers_cap = default_workers
                    source = f"machine profile (env override invalid: {override!r})"
            else:
                self._max_workers_cap = default_workers
                source = "machine profile"
            if profile is not None:
                logger.info(
                    "Parallel runner: %d workers (%s, %s, %d cores, %.1f GB RAM, %s)",
                    self._max_workers_cap,
                    source,
                    profile.os_name,
                    profile.cpu_cores,
                    profile.ram_gb,
                    "VPS" if profile.is_vps else "bare metal",
                )
            else:
                logger.info(
                    "Parallel runner: %d workers (%s, machine detection failed)",
                    self._max_workers_cap,
                    source,
                )
            self._logged_parallel_default = True
        max_workers_cap = self._max_workers_cap
        actions_this_cycle = 0
        # Guard: ThreadPoolExecutor raises ValueError("max_workers must be
        # greater than 0") on an empty actions list, because
        # min(0, N) == 0. Skip the executor entirely when there's
        # nothing to run — the cycle is still valid, it just
        # executed no domain actions. Caught by the integration test
        # in v0.6.5 (task #55) against a fake workspace where the
        # domain_filter narrowed everything out.
        if not actions_to_run:
            logger.debug("No actions scheduled this cycle — skipping executor")
        else:
            with ThreadPoolExecutor(max_workers=min(len(actions_to_run), max_workers_cap)) as pool:
                futures = {pool.submit(_run_one, a): a for a in actions_to_run}
                for future in as_completed(futures):
                    action = futures[future]
                    domain_name = action.get("domain", "?")
                    action_name = action.get("action", "?")
                    engine_name = action.get("engine", "")

                    try:
                        _, engine_result = future.result(timeout=30)
                    except TimeoutError:
                        engine_result = "TIMEOUT: engine exceeded 30s"
                        # Cache slow engines so they skip future cycles
                        self._engine_cooldowns[f"{domain_name}/{engine_name}"] = 3
                    except Exception as exc:
                        engine_result = f"ERROR: {exc}"

                    logger.info(
                        "[%s] %s → %s",
                        domain_name,
                        action_name,
                        (engine_result or "done")[:100],
                    )

                    persist_action(
                        db_path=self.db_path,
                        domain=domain_name,
                        module="autonomous",
                        action=action_name,
                        target=engine_name,
                        result=engine_result or action.get("reason", ""),
                    )
                    self.total_actions += 1
                    actions_this_cycle += 1
                    action_key = f"{domain_name}:{action_name}"
                    self.checkpoint.engine_completed(action_key)

        self.checkpoint.engine_completed("director")
        logger.info("Executed %d domain actions this cycle", actions_this_cycle)

        # 3. Collision engine: check after action
        collisions = self.collision_engine.detect_collisions(self.registry)
        if collisions:
            logger.info(
                "Collisions detected: %d (top: %s, engines=%d)",
                len(collisions),
                collisions[0].title[:50],
                collisions[0].engine_count,
            )
            for c in collisions[:3]:
                for act in c.actions:
                    self.bus.post(
                        sender="collision_engine",
                        recipient="all",
                        message_type="signal",
                        data=act,
                    )

        # 3b. Peer corroboration: boost confidence when multiple sources agree
        try:
            from core.peer_corroboration import apply_corroborations

            corr_count = apply_corroborations(db_path=self.db_path)
            if corr_count:
                logger.info("Corroboration: %d findings strengthened by peer agreement", corr_count)
        except Exception as exc:
            logger.debug("Corroboration failed: %s", exc)

        # 3c. Auto-resolve findings: link bug findings to their fixes
        try:
            from core.persist_to_db import auto_resolve_findings

            resolved = auto_resolve_findings(db_path=self.db_path)
            if resolved:
                logger.info("Auto-resolved %d findings", resolved)
        except Exception as exc:
            logger.debug("Auto-resolve failed: %s", exc)

        # 3d. Hypothesis evolution: every 5 cycles
        if self._cycle_number % 5 == 0:
            try:
                from core.hypothesis_engine import evolve as hypothesis_evolve

                h_result = hypothesis_evolve(db_path=self.db_path)
                h_total = (
                    h_result.get("created", 0)
                    + h_result.get("linked", 0)
                    + h_result.get("retired", 0)
                    + h_result.get("promoted", 0)
                )
                if h_total:
                    logger.info(
                        "Hypothesis evolution: created=%d linked=%d retired=%d promoted=%d",
                        h_result.get("created", 0),
                        h_result.get("linked", 0),
                        h_result.get("retired", 0),
                        h_result.get("promoted", 0),
                    )
            except Exception as exc:
                logger.debug("Hypothesis evolution failed: %s", exc)

        # 4. War Room: daily (skippable via NEBULA_SKIP_WAR_ROOM for
        # portable/headless runs that lack LLM keys)
        if os.environ.get("NEBULA_SKIP_WAR_ROOM") == "1":
            pass
        elif self._should_run(self.last_war_room, WAR_ROOM_INTERVAL_HOURS):
            logger.info("Running War Room assessment...")
            try:
                assessment = self.war_room.run_assessment(registry=self.registry, dry_run=False)
                self.last_war_room = now
                self.checkpoint.war_room_completed()

                # Add multi-perspective analysis via Persona Panel
                try:
                    from core.persona_panel import get_multi_perspective, synthesize_perspectives

                    battle_plan_text = ""
                    if isinstance(assessment, dict):
                        battle_plan_text = json.dumps(assessment, default=str)[:2000]
                    elif isinstance(assessment, str):
                        battle_plan_text = assessment[:2000]
                    if battle_plan_text:
                        perspectives = get_multi_perspective(
                            evidence_summary=battle_plan_text,
                            context="War Room battle plan assessment",
                        )
                        synthesis = synthesize_perspectives(
                            perspectives,
                            db_path=self.db_path,
                            domain="system",
                        )
                        logger.info(
                            "Persona Panel: verdict=%s, score=%.2f, spread=%.2f",
                            synthesis.get("ensemble_verdict", "?"),
                            synthesis.get("mean_score", 0),
                            synthesis.get("confidence_spread", 0),
                        )
                except Exception as exc:
                    logger.debug("Persona Panel after War Room failed: %s", exc)
            except Exception as exc:
                logger.error("War Room failed: %s", exc)
                self.checkpoint.engine_failed("war_room", str(exc))

        # 5. Strategy Evolver: weekly
        if self._should_run(self.last_strategy_evolve, STRATEGY_INTERVAL_HOURS):
            logger.info("Running Strategy Evolver...")
            try:
                self.strategy_evolver.run_evolution_cycle(registry=self.registry, dry_run=True)
                self.last_strategy_evolve = now
                self.checkpoint.engine_completed("strategy_evolver")
            except Exception as exc:
                logger.error("Strategy Evolver failed: %s", exc)
                self.checkpoint.engine_failed("strategy_evolver", str(exc))

        # 6. Self-Improver: weekly
        if self._should_run(self.last_self_improve, SELF_IMPROVE_INTERVAL_HOURS):
            logger.info("Running Self-Improver...")
            try:
                report = self.self_improver.analyze_all(registry=self.registry)
                self.self_improver.save_report(report)
                self.last_self_improve = now
                self.checkpoint.engine_completed("self_improver")
            except Exception as exc:
                logger.error("Self-Improver failed: %s", exc)
                self.checkpoint.engine_failed("self_improver", str(exc))

        # 7. Knowledge Graph: every 6 hours
        if self._should_run(self.last_knowledge_graph, KNOWLEDGE_GRAPH_INTERVAL_HOURS):
            logger.info("Refreshing Knowledge Graph...")
            try:
                self.knowledge_graph.build()
                self.knowledge_graph.export_json()
                self.last_knowledge_graph = now
                self.checkpoint.engine_completed("knowledge_graph")
            except Exception as exc:
                logger.error("Knowledge Graph failed: %s", exc)
                self.checkpoint.engine_failed("knowledge_graph", str(exc))

        # 7a2. Hypothesis Hardener + Anomaly Detector: every 10 cycles
        if self._cycle_number % 10 == 0:
            try:
                from core.hypothesis_hardener import harden_all

                h_report = harden_all(db_path=self.db_path, persist=True)
                if h_report.fragile_count or h_report.biased_count or h_report.stale_count:
                    logger.info(
                        "Hypothesis hardening: checked=%d fragile=%d biased=%d stale=%d",
                        h_report.hypotheses_checked,
                        h_report.fragile_count,
                        h_report.biased_count,
                        h_report.stale_count,
                    )
            except Exception as exc:
                logger.debug("Hypothesis hardener failed: %s", exc)

            try:
                from core.anomaly_detector import detect_and_persist

                a_report = detect_and_persist(db_path=self.db_path)
                if a_report.anomalies:
                    logger.info(
                        "Anomaly detector: %d anomalies across %d engines",
                        len(a_report.anomalies),
                        a_report.engines_checked,
                    )
            except Exception as exc:
                logger.debug("Anomaly detector failed: %s", exc)

        # 7c. Breakthrough hunt: every 10 cycles, look for convergence,
        # anomaly spikes, and mission-critical finds. Cheap - no LLM.
        if self._cycle_number % 10 == 0:
            try:
                from core.breakthrough_engine import (
                    persist_breakthroughs,
                    run_breakthrough_hunt,
                )

                candidates = run_breakthrough_hunt(db_path=self.db_path)
                if candidates:
                    persisted = persist_breakthroughs(candidates, db_path=self.db_path)
                    logger.info(
                        "Breakthrough hunt: %d candidates, %d persisted",
                        len(candidates),
                        persisted,
                    )
            except Exception as exc:
                logger.debug("Breakthrough hunt failed: %s", exc)

        # 7d. Aspiration sweep: refresh live aspirations every 10 cycles.
        if self._cycle_number % 10 == 0:
            try:
                from core.aspiration_engine import sweep as aspiration_sweep

                live = aspiration_sweep(db_path=self.db_path)
                if live:
                    logger.info("Aspiration sweep: %d live goals", len(live))
            except Exception as exc:
                logger.debug("Aspiration sweep failed: %s", exc)

        # 7b. Synthesis Engine: build hypothesis graph every 10 cycles
        if self._cycle_number % 10 == 0:
            try:
                from core.synthesis_engine import SynthesisEngine

                synth = SynthesisEngine(db_path=self.db_path)
                synth.build_graph()
                if synth.graph.needs_synthesis:
                    context = synth.build_synthesis_context()
                    logger.info(
                        "Synthesis graph: %d nodes, %d edges, needs_synthesis=True",
                        synth.graph.node_count,
                        synth.graph.edge_count,
                    )
                else:
                    logger.debug(
                        "Synthesis graph: %d nodes, %d edges (no synthesis needed)",
                        synth.graph.node_count,
                        synth.graph.edge_count,
                    )
                synth.graph.save_graph()
            except ImportError:
                logger.debug("Synthesis engine skipped: networkx not installed")
            except Exception as exc:
                logger.debug("Synthesis engine failed: %s", exc)

        # 8. DB maintenance: prune stale data (every 100 cycles ≈ daily)
        if self._cycle_number % 100 == 0:
            try:
                from core.persist_to_db import maintain_db

                result = maintain_db(db_path=self.db_path)
                total = sum(v for v in result.values() if isinstance(v, int))
                if total > 0:
                    logger.info("DB maintenance: pruned %d rows", total)
            except Exception as exc:
                logger.debug("DB maintenance failed: %s", exc)

        # 8b. Forensic audit trail verification (every 50 cycles)
        if self._cycle_number % 50 == 0:
            try:
                from core.forensic_audit import ForensicAuditTrail

                trail = ForensicAuditTrail()
                verify_result = trail.verify_chain()
                if not verify_result["chain_intact"]:
                    logger.warning(
                        "FORENSIC AUDIT: chain integrity BROKEN at entries %s (%d/%d valid)",
                        verify_result["broken_at"][:5],
                        verify_result["valid"],
                        verify_result["total"],
                    )
                elif verify_result["total"] > 0:
                    logger.info(
                        "Forensic audit: chain intact (%d entries verified)",
                        verify_result["total"],
                    )
            except Exception as exc:
                logger.debug("Forensic audit failed: %s", exc)

        # 9. Evidence transport: share findings with peers
        try:
            from core.transport import get_transport

            transport = get_transport(self.db_path)
            sync_result = transport.sync()
            pub = sync_result.get("publish", {}).get("published", 0)
            pull = sync_result.get("pull", {}).get("imported", 0)
            if pub or pull:
                logger.info("Transport sync: published=%d, imported=%d", pub, pull)
        except Exception as exc:
            logger.debug("Transport sync skipped: %s", exc)

        # 9b. MCP peer intelligence (if peers configured)
        try:
            from core.mcp_bridge import call_tool, list_peers

            peers = list_peers()
            for peer_name in peers:
                try:
                    result = call_tool(peer_name, "nebula_status")
                    if result:
                        logger.info("MCP peer '%s' status received", peer_name)
                except Exception as exc:
                    logger.debug("MCP peer '%s' call failed: %s", peer_name, exc)
                    continue
        except Exception as exc:
            logger.debug("MCP peer intelligence step skipped: %s", exc)

        # 10. Heartbeat: tell Nexus we're alive (every 10 cycles)
        if self._cycle_number % 10 == 0:
            try:
                from core.integrations.probe import heartbeat

                heartbeat(status="active")
            except Exception as exc:
                logger.debug("Probe heartbeat skipped: %s", exc)

        # 11. Domain health check: flag if too few domains producing (every 20 cycles)
        if self._cycle_number % 20 == 0:
            try:
                conn = connect(self.db_path)
                active_domains = conn.execute(
                    "SELECT COUNT(DISTINCT domain) FROM evidence"
                ).fetchone()[0]
                conn.close()
                if active_domains < 10:
                    logger.warning(
                        "HEALTH: only %d/17 domains producing findings. "
                        "Check engine errors in actions_log.",
                        active_domains,
                    )
                else:
                    logger.info("Domain health: %d/17 domains active", active_domains)
            except Exception as exc:
                logger.debug("Domain health check skipped: %s", exc)

        # 12. Telemetry (opt-in, no-op unless NEBULA_TELEMETRY=1):
        # report aggregate engine error counts + cycle metrics to maintainers
        # so issues can be caught across running instances without users
        # needing to file GitHub issues.
        try:
            from core.telemetry import (
                is_enabled as _telemetry_enabled,
            )
            from core.telemetry import (
                report_engine_errors,
                report_metrics,
            )

            if _telemetry_enabled():
                # Per-engine error counts for the last 15 min window.
                try:
                    _conn = connect(self.db_path)
                    try:
                        rows = _conn.execute(
                            """SELECT target, COUNT(*) FROM actions_log
                               WHERE timestamp >= datetime('now', '-15 minutes')
                                 AND (result LIKE '%ERROR%' OR result LIKE '%TIMEOUT%'
                                      OR error IS NOT NULL)
                               GROUP BY target"""
                        ).fetchall()
                    finally:
                        _conn.close()
                    recent_errors = {
                        (target or "unknown"): count for target, count in rows if count
                    }
                    if recent_errors:
                        report_engine_errors(recent_errors)
                except Exception as _exc:
                    logger.debug("Telemetry engine_errors report skipped: %s", _exc)

                # Aggregate cycle metrics (no finding content).
                try:
                    report_metrics(
                        {
                            "cycle_number": self._cycle_number,
                            "total_actions": int(self.total_actions),
                            "actions_this_cycle": int(actions_this_cycle),
                            "total_cost_usd": round(float(self.total_cost), 4),
                            "evidence_count": int(self._evidence_count()),
                            "domain_count": len(self.registry.get_domain_names()),
                        }
                    )
                except Exception as _exc:
                    logger.debug("Telemetry metrics report skipped: %s", _exc)
        except Exception as _exc:
            logger.debug("Telemetry step skipped: %s", _exc)

        logger.info("--- Cycle %d complete ---", self._cycle_number)

    # ------------------------------------------------------------------
    # Helpers
    # ------------------------------------------------------------------

    def _should_run(
        self,
        last_run: datetime | None,
        interval_hours: float,
    ) -> bool:
        if last_run is None:
            return True
        elapsed = (datetime.now(timezone.utc) - last_run).total_seconds() / 3600
        return elapsed >= interval_hours

    def _determine_trigger_level(self, landscape: dict) -> str:
        pending = landscape.get("pending_messages", {})
        breakthroughs = pending.get("breakthrough", 0)
        signals = pending.get("signal", 0)

        if breakthroughs > 0:
            return "critical"
        if signals > 3:
            return "urgent"

        total_evidence = sum(
            d.get("count", 0) for d in landscape.get("evidence_by_domain", {}).values()
        )
        if total_evidence < 10:
            return "urgent"  # bootstrap mode

        return "routine"

    def _identify_stale(self, landscape: dict) -> list[str]:
        """Identify stale data tags so domains can decide what to run.

        Returns tags that domains check in their decide_next_action:
        - engine names that haven't run recently
        - topic tags (contributors, sentiment, docs, narratives, etc.)
        - bootstrap tags on first cycles to kick-start all domains
        """
        stale = []
        now = datetime.now(timezone.utc)

        # Engines with no recent evidence
        for engine, info in landscape.get("evidence_by_engine", {}).items():
            last_run = info.get("last_run")
            if last_run:
                try:
                    last = datetime.fromisoformat(last_run.replace("Z", "+00:00"))
                    if (now - last).total_seconds() > 48 * 3600:
                        stale.append(engine)
                except (ValueError, TypeError):
                    stale.append(engine)

        # Bootstrap: flag all topic tags as stale so every domain fires at least once
        # These match the strings checked in domains/*/domain.py decide_next_action
        ALL_TOPICS = [
            # community
            "contributors",
            "health",
            "sentiment",
            # education
            "docs",
            "onboarding",
            # investigation
            "architecture",
            "vision",
            "history",
            "literature",
            # interoperability
            "bridge",
            "evm",
            "consensus",
            "external_chains",
            # marketing
            "narratives",
            "positioning",
            "dominance",
            # product_market_fit
            "competitive_data",
            "landscape",
            "adoption",
            "roadmap",
            "surface",
            # self_maintenance
            "engine_health",
            "config_drift",
            # standards
            "bip_tracking",
            "deployment",
            # economics
            "liquidity",
            "supply",
            "whales",
            "yields",
            "funnel",
            "hype",
            # governance
            "proposals",
            "voting",
            "pillar_accountability",
            # network_health
            "pillars",
            "sentinels",
            "decentralization",
            "node_census",
        ]
        # Always include all topics so every domain can fire its action.
        # Domains self-regulate via cooldowns and their own dedup logic.
        stale.extend(ALL_TOPICS)
        return stale


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------


def main() -> None:
    parser = argparse.ArgumentParser(
        description="Nebula Autonomous Runner",
    )
    parser.add_argument(
        "--once",
        action="store_true",
        help="Run a single cycle and exit",
    )
    parser.add_argument(
        "--cycles",
        type=int,
        default=0,
        help="Run N cycles and exit (0 = unlimited, default: 0)",
    )
    parser.add_argument(
        "--max-hours",
        type=float,
        default=DEFAULT_MAX_HOURS,
        help=f"Maximum runtime in hours (default: {DEFAULT_MAX_HOURS})",
    )
    parser.add_argument(
        "--budget",
        type=float,
        default=DEFAULT_BUDGET,
        help=f"Maximum API budget in USD (default: {DEFAULT_BUDGET})",
    )
    parser.add_argument(
        "--db",
        type=str,
        default=DEFAULT_DB,
        help="Path to SQLite database",
    )
    parser.add_argument(
        "--resume",
        action="store_true",
        help="Resume from last checkpoint (skip engines that already completed)",
    )
    parser.add_argument(
        "--domains",
        type=str,
        default="",
        help="Comma-separated list of domains to run (default: all). Example: --domains security,quality,development",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Enable debug logging",
    )
    args = parser.parse_args()

    logging.basicConfig(
        level=logging.DEBUG if args.verbose else logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s - %(message)s",
    )

    runner = AutonomousRunner(
        db_path=args.db,
        max_hours=args.max_hours,
        budget=args.budget,
        domain_filter=set(args.domains.split(",")) if args.domains else None,
    )

    summary = runner.run(once=args.once, max_cycles=args.cycles)

    print("\n" + "=" * 60)
    print("  ZENON ENGINE - AUTONOMOUS RUN SUMMARY")
    print("=" * 60)
    print(f"  Cycles:  {summary['cycles']}")
    print(f"  Actions: {summary['total_actions']}")
    print(f"  Cost:    ${summary['total_cost']:.4f}")
    print(f"  Time:    {summary['elapsed_seconds']:.0f}s")
    print(f"  Domains: {', '.join(summary['domains'])}")
    print("=" * 60)


if __name__ == "__main__":
    main()
