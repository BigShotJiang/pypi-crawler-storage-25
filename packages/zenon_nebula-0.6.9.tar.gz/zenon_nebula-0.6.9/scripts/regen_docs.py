#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""Regenerate documentation from authoritative sources.

Single script that pulls numbers and structure directly from the codebase so
that no one has to hand-edit stat blocks in README.md, CLAUDE.md, or the docs
tree. Run this before every commit to source files; a pre-commit hook also
invokes it in --check mode.

What it regenerates:
- Stat blocks in README.md, CLAUDE.md, docs/ARCHITECTURE.md (between
  <!-- nebula:stats:start --> and <!-- nebula:stats:end --> markers)
- docs/DOMAINS.md — full domain + engine catalog, pulled from DomainRegistry
- docs/reference/cli.md — CLI reference, parsed from scripts/autonomous.py
  argparse

Usage:
    python3 scripts/regen_docs.py            # rewrite files in place
    python3 scripts/regen_docs.py --check    # exit 1 if any file would change
    python3 scripts/regen_docs.py --stats    # print computed stats and exit

Exit codes:
    0 — success (files up to date in --check, or rewritten successfully)
    1 — files were stale (--check only)
    2 — error collecting stats or importing registry
"""

from __future__ import annotations

import argparse
import ast
import difflib
import re
import sys
from dataclasses import dataclass
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
STATS_START = "<!-- nebula:stats:start -->"
STATS_END = "<!-- nebula:stats:end -->"

QUALITY_START = "<!-- nebula:quality-badges:start -->"
QUALITY_END = "<!-- nebula:quality-badges:end -->"

EXCLUDED_DIRS = {
    ".venv",
    "venv",
    "__pycache__",
    ".git",
    "build",
    "dist",
    ".mypy_cache",
    ".ruff_cache",
    ".pytest_cache",
}


@dataclass
class Stats:
    """Stats collected from the codebase."""

    py_files: int
    total_lines: int
    core_modules: int
    domain_count: int
    engine_count: int
    test_files: int
    scripts: int
    schema_tables: int
    mcp_tools: int
    # v0.6.9: test-shape counts that drive the README quality-badge block.
    # test_count is every `def test_` in tests/; fuzz_count is every test
    # under @pytest.mark.fuzz; scenario_count is every @pytest.mark.scenario
    # test. The render_quality_badges_block consumer expects live counts so
    # CI can't drift quietly. Zero-default keeps pre-v0.6.9 call sites that
    # build Stats manually from breaking.
    test_count: int = 0
    fuzz_count: int = 0
    scenario_count: int = 0


def _iter_py_files(base: Path):
    for p in base.rglob("*.py"):
        if any(part in EXCLUDED_DIRS for part in p.parts):
            continue
        yield p


def collect_stats() -> Stats:
    """Walk the repo and collect the numbers that appear in docs."""
    py_files = list(_iter_py_files(ROOT))
    total_lines = 0
    for p in py_files:
        # Read as text with universal newlines so the count is stable
        # across LF/CRLF filesystems. Iterating the binary file handle
        # produced different counts on macOS (LF) vs CI (git autocrlf).
        try:
            total_lines += len(p.read_text(encoding="utf-8", errors="ignore").splitlines())
        except OSError:
            continue

    core = [p for p in py_files if p.is_relative_to(ROOT / "core")]
    core_modules = [p for p in core if p.name != "__init__.py"]

    domains_dir = ROOT / "domains"
    domain_count = 0
    engine_count = 0
    if domains_dir.is_dir():
        for d in sorted(domains_dir.iterdir()):
            if not d.is_dir() or d.name.startswith("_") or d.name.startswith("."):
                continue
            domain_count += 1
            engines_dir = d / "engines"
            if engines_dir.is_dir():
                engine_count += sum(1 for f in engines_dir.glob("*.py") if f.name != "__init__.py")

    test_files = [
        p for p in py_files if p.is_relative_to(ROOT / "tests") and p.name.startswith("test_")
    ]
    scripts = [p for p in py_files if p.is_relative_to(ROOT / "scripts")]

    schema_tables = _count_schema_tables()
    mcp_tools = _count_mcp_tools()
    test_count, fuzz_count, scenario_count = _count_test_shapes(test_files)

    return Stats(
        py_files=len(py_files),
        total_lines=total_lines,
        core_modules=len(core_modules),
        domain_count=domain_count,
        engine_count=engine_count,
        test_files=len(test_files),
        scripts=len(scripts),
        schema_tables=schema_tables,
        mcp_tools=mcp_tools,
        test_count=test_count,
        fuzz_count=fuzz_count,
        scenario_count=scenario_count,
    )


def _count_schema_tables() -> int:
    """Count CREATE TABLE statements across every SCHEMA_SQL in the repo."""
    total = 0
    pattern = re.compile(r"CREATE\s+TABLE\s+IF\s+NOT\s+EXISTS", re.IGNORECASE)
    for p in _iter_py_files(ROOT):
        try:
            text = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if "SCHEMA_SQL" not in text and "CREATE TABLE" not in text:
            continue
        total += len(pattern.findall(text))
    return total


def _count_test_shapes(test_files: list[Path]) -> tuple[int, int, int]:
    """Count total tests, fuzz tests, scenario tests via AST walk.

    Returns:
        (test_count, fuzz_count, scenario_count).

    - **test_count**: every top-level or class-scoped ``def test_*`` in
      files under ``tests/``. This is the "tests passing" number that
      goes in the README quality badge. It's AST-based so it matches
      ``pytest --collect-only`` modulo parameterized expansions (which
      we don't try to resolve — a parameterized test counts as one
      test function here, which is the honest shape-of-suite count).
    - **fuzz_count**: distinct test functions carrying ``@pytest.mark.fuzz``.
      Hypothesis-based fuzz suites use this marker to opt out of the
      fast suite and into the nightly fuzz job.
    - **scenario_count**: distinct test functions carrying
      ``@pytest.mark.scenario``. Multi-instance / CI-gated regression
      suites live here (e.g., ``test_breadcrumb_discovery.py``).

    Class-level markers propagate to every method in the class — this
    is how pytest itself applies them. If you mark a class
    ``@pytest.mark.scenario`` and put 7 ``test_*`` methods in it, all 7
    count as scenario tests.
    """
    test_count = 0
    fuzz_count = 0
    scenario_count = 0

    for p in test_files:
        try:
            source = p.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        try:
            tree = ast.parse(source)
        except SyntaxError:
            continue

        # Module-level pytestmark applies to every test in the file.
        # pytest supports both a single mark and a list of marks:
        #     pytestmark = pytest.mark.fuzz
        #     pytestmark = [pytest.mark.fuzz, pytest.mark.slow]
        module_markers: set[str] = _extract_module_pytestmark(tree)

        for node in tree.body:
            if isinstance(node, ast.ClassDef):
                class_markers = module_markers | _extract_pytest_markers(node.decorator_list)
                for item in node.body:
                    if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                        if not item.name.startswith("test_"):
                            continue
                        test_count += 1
                        merged = class_markers | _extract_pytest_markers(item.decorator_list)
                        if "fuzz" in merged:
                            fuzz_count += 1
                        if "scenario" in merged:
                            scenario_count += 1
            elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
                if not node.name.startswith("test_"):
                    continue
                test_count += 1
                markers = module_markers | _extract_pytest_markers(node.decorator_list)
                if "fuzz" in markers:
                    fuzz_count += 1
                if "scenario" in markers:
                    scenario_count += 1

    return (test_count, fuzz_count, scenario_count)


def _extract_module_pytestmark(tree: ast.Module) -> set[str]:
    """Return pytest.mark.* names applied via module-level ``pytestmark = ...``.

    pytest supports both forms:

    - ``pytestmark = pytest.mark.scenario``
    - ``pytestmark = [pytest.mark.scenario, pytest.mark.slow]``

    Unrecognized shapes (dynamic assignments, conditional logic) are
    ignored — same lower-bound discipline as ``_extract_pytest_markers``.
    """
    markers: set[str] = set()
    for node in tree.body:
        if not isinstance(node, ast.Assign):
            continue
        for target in node.targets:
            if isinstance(target, ast.Name) and target.id == "pytestmark":
                value = node.value
                if isinstance(value, ast.List):
                    for elt in value.elts:
                        markers |= _extract_mark_name(elt)
                else:
                    markers |= _extract_mark_name(value)
    return markers


def _extract_mark_name(expr: ast.expr) -> set[str]:
    """Return ``{name}`` if ``expr`` matches ``pytest.mark.<name>`` (optionally
    called), else empty set."""
    target = expr.func if isinstance(expr, ast.Call) else expr
    if (
        isinstance(target, ast.Attribute)
        and isinstance(target.value, ast.Attribute)
        and target.value.attr == "mark"
        and isinstance(target.value.value, ast.Name)
        and target.value.value.id == "pytest"
    ):
        return {target.attr}
    return set()


def _extract_pytest_markers(decorators: list[ast.expr]) -> set[str]:
    """Return the set of pytest.mark.* names applied by these decorators.

    Handles both ``@pytest.mark.fuzz`` (ast.Attribute chain) and
    ``@pytest.mark.parametrize(...)`` (ast.Call with the same chain
    as its func). Unrecognized decorator shapes (lambdas, dynamic
    markers) are ignored — the count is a lower bound. Good enough
    for a visible quality badge.
    """
    markers: set[str] = set()
    for dec in decorators:
        # Call form: @pytest.mark.xxx(...)
        target = dec.func if isinstance(dec, ast.Call) else dec
        # Must end in an Attribute whose value's attr is 'mark' whose
        # value is a Name 'pytest'.
        if (
            isinstance(target, ast.Attribute)
            and isinstance(target.value, ast.Attribute)
            and target.value.attr == "mark"
            and isinstance(target.value.value, ast.Name)
            and target.value.value.id == "pytest"
        ):
            markers.add(target.attr)
    return markers


def _count_mcp_tools() -> int:
    """Parse scripts/mcp_server.py and count entries in the TOOLS list."""
    mcp = ROOT / "scripts" / "mcp_server.py"
    if not mcp.exists():
        return 0
    try:
        tree = ast.parse(mcp.read_text(encoding="utf-8"))
    except SyntaxError:
        return 0
    for node in ast.walk(tree):
        if isinstance(node, ast.Assign):
            for target in node.targets:
                if isinstance(target, ast.Name) and target.id == "TOOLS":
                    if isinstance(node.value, ast.List):
                        return len(node.value.elts)
    return 0


def render_stats_block(stats: Stats) -> str:
    """Render the shared stat block that goes into README, CLAUDE.md, etc."""
    return (
        f"{STATS_START}\n"
        f"<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->\n"
        f"\n"
        f"| Metric | Count |\n"
        f"|--------|-------|\n"
        f"| Python files | {stats.py_files} |\n"
        f"| Lines of code | {stats.total_lines:,} |\n"
        f"| Core modules | {stats.core_modules} |\n"
        f"| Domains | {stats.domain_count} |\n"
        f"| Engines | {stats.engine_count} |\n"
        f"| Test files | {stats.test_files} |\n"
        f"| Scripts | {stats.scripts} |\n"
        f"| Schema tables | {stats.schema_tables} |\n"
        f"| MCP tools | {stats.mcp_tools} |\n"
        f"\n"
        f"{STATS_END}"
    )


def collect_domain_catalog() -> list[dict]:
    """Read every domains/*/domain.py and pull name, description, engines.

    Falls back to filesystem scanning if the plugin refuses to import
    (e.g., dependency not installed in the current env). Never raises.
    """
    catalog = []
    domains_dir = ROOT / "domains"
    if not domains_dir.is_dir():
        return catalog

    for d in sorted(domains_dir.iterdir()):
        if not d.is_dir() or d.name.startswith("_") or d.name.startswith("."):
            continue

        entry = {
            "name": d.name,
            "description": _extract_description(d / "domain.py"),
            "priority": _extract_priority(d / "domain.py"),
            "engines": [],
        }

        engines_dir = d / "engines"
        if engines_dir.is_dir():
            for f in sorted(engines_dir.glob("*.py")):
                if f.name == "__init__.py":
                    continue
                entry["engines"].append(
                    {
                        "file": f.name,
                        "name": f.stem,
                        "purpose": _extract_module_docstring_summary(f),
                    }
                )
        catalog.append(entry)
    return catalog


def _extract_description(domain_py: Path) -> str:
    """Pull the return value of get_description() from a DomainPlugin."""
    if not domain_py.exists():
        return ""
    try:
        tree = ast.parse(domain_py.read_text(encoding="utf-8"))
    except SyntaxError:
        return ""
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "get_description":
            for stmt in node.body:
                if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant):
                    if isinstance(stmt.value.value, str):
                        return stmt.value.value
    return ""


def _extract_priority(domain_py: Path) -> int:
    if not domain_py.exists():
        return 5
    try:
        tree = ast.parse(domain_py.read_text(encoding="utf-8"))
    except SyntaxError:
        return 5
    for node in ast.walk(tree):
        if isinstance(node, ast.FunctionDef) and node.name == "get_priority":
            for stmt in node.body:
                if isinstance(stmt, ast.Return) and isinstance(stmt.value, ast.Constant):
                    if isinstance(stmt.value.value, int):
                        return stmt.value.value
    return 5


def _extract_module_docstring_summary(py_file: Path) -> str:
    """Return the first sentence of a module's docstring, or empty string."""
    try:
        tree = ast.parse(py_file.read_text(encoding="utf-8"))
    except (OSError, SyntaxError):
        return ""
    doc = ast.get_docstring(tree)
    if not doc:
        return ""
    first = doc.strip().split("\n")[0].strip()
    return first.rstrip(".")


def render_domains_md(catalog: list[dict]) -> str:
    """Render the full docs/DOMAINS.md from the domain catalog."""
    lines = [
        "# Domains & Engines",
        "",
        "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->",
        "",
        f"Nebula ships {len(catalog)} domains. Each domain is a plugin under",
        "`domains/<name>/` with a `DomainPlugin` subclass in `domain.py` and one",
        "engine per file under `engines/`. The loader auto-registers every domain",
        "at boot — see `core/domain_registry.py`.",
        "",
        "## Domains",
        "",
        "| Domain | Priority | Engines | Description |",
        "|--------|----------|---------|-------------|",
    ]
    for d in catalog:
        lines.append(
            f"| `{d['name']}` | {d['priority']} | {len(d['engines'])} | {d['description']} |"
        )
    lines.append("")

    for d in catalog:
        lines.append(f"## `{d['name']}`")
        lines.append("")
        if d["description"]:
            lines.append(d["description"])
            lines.append("")
        if not d["engines"]:
            lines.append("_No engines registered._")
            lines.append("")
            continue
        lines.append("| Engine | Purpose |")
        lines.append("|--------|---------|")
        for eng in d["engines"]:
            purpose = eng["purpose"] or "_(no module docstring)_"
            lines.append(f"| `{eng['name']}` | {purpose} |")
        lines.append("")
    return "\n".join(lines) + "\n"


def render_cli_reference() -> str:
    """Parse scripts/autonomous.py argparse and build a CLI reference.

    Extremely conservative: we don't actually import autonomous.py (it has
    side effects). Instead, we parse the AST and look for argparse .add_argument
    calls. Unparseable commands degrade to a stub line.
    """
    autonomous = ROOT / "scripts" / "autonomous.py"
    nebula_sh = ROOT / "nebula"

    lines = [
        "# CLI Reference",
        "",
        "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->",
        "",
        "The `./nebula` wrapper forwards to `scripts/autonomous.py`. All flags",
        "below are derived from its argparse definition via AST walk — if you",
        "add a new flag, run `python3 scripts/regen_docs.py` to refresh.",
        "",
    ]

    if not autonomous.exists():
        lines.append("_`scripts/autonomous.py` not found — CLI reference unavailable._\n")
        return "\n".join(lines)

    try:
        tree = ast.parse(autonomous.read_text(encoding="utf-8"))
    except SyntaxError as exc:
        lines.append(f"_Parse error in `scripts/autonomous.py`: {exc}_\n")
        return "\n".join(lines)

    add_arg_calls = []
    for node in ast.walk(tree):
        if not isinstance(node, ast.Call):
            continue
        if not isinstance(node.func, ast.Attribute):
            continue
        if node.func.attr != "add_argument":
            continue
        names = [
            a.value for a in node.args if isinstance(a, ast.Constant) and isinstance(a.value, str)
        ]
        kwargs = {}
        for kw in node.keywords:
            if kw.arg and isinstance(kw.value, ast.Constant):
                kwargs[kw.arg] = kw.value.value
        if names:
            add_arg_calls.append((names, kwargs))

    lines.append("## Flags")
    lines.append("")
    lines.append("| Flag | Type | Default | Help |")
    lines.append("|------|------|---------|------|")
    for names, kwargs in add_arg_calls:
        flag = ", ".join(f"`{n}`" for n in names)
        typ = kwargs.get("type", "str")
        if hasattr(typ, "__name__"):
            typ = typ.__name__
        default = kwargs.get("default", "")
        if default is None:
            default = ""
        help_text = kwargs.get("help", "")
        lines.append(f"| {flag} | {typ} | `{default}` | {help_text} |")
    lines.append("")

    if nebula_sh.exists():
        lines.append("## Subcommands (via `./nebula <cmd>`)")
        lines.append("")
        lines.append("The `./nebula` wrapper recognises the following subcommands")
        lines.append("before delegating remaining arguments to `scripts/autonomous.py`.")
        lines.append("Run `./nebula --help` for the authoritative list at any commit.")
        lines.append("")

    return "\n".join(lines) + "\n"


def rewrite_version_badge(path: Path, version: str) -> tuple[bool, str]:
    """Update the shields.io version badge in README.md to match core/version.py.

    Pre-v0.2.18 the badge was a hand-edited literal `v0.2.0` that nobody
    bumped on release. Now it's regenerated from `core/version.py` on
    every `regen_docs.py` run, and the release workflow runs
    `regen_docs.py --check` so a stale badge fails CI before tagging.

    Matches both the old `version-v0.2.0-informational` shape and any
    valid semver patch number after `version-v`. The replacement
    preserves the badge color and the alt text.
    """
    if not path.exists():
        return (False, "")
    original = path.read_text(encoding="utf-8")
    pattern = re.compile(
        r'(<img\s+src="https://img\.shields\.io/badge/version-v)'
        r"\d+\.\d+\.\d+"
        r'(-[a-z]+"\s+alt="Version v)'
        r"\d+\.\d+\.\d+"
        r'(">)'
    )
    new_contents, n = pattern.subn(rf"\g<1>{version}\g<2>{version}\g<3>", original)
    return (n > 0 and new_contents != original, new_contents)


def render_quality_badges_block(stats: Stats) -> str:
    """Render the README quality-badge block from live stats.

    The block contains 17 shields.io badges across two ``<p align="center">``
    rows. Five badges have live numbers pulled from the ``Stats`` object:
    tests, fuzz, scenarios, domains, engines. The rest are status flags
    (OPSEC, anti-doxxing, bandit, pip-audit, rule adherence, README truth,
    integrity, lint, architecture, dep graph, coverage, mutation-phase).

    When a status flag changes (e.g., mutation moves from Phase F to
    active), update the literal below in the same commit that flips the
    underlying state. The block is re-rendered on every ship so the
    counts stay honest, but the flags need human intent.

    The separation is deliberate: CI can't auto-detect "bandit is still
    the gate we care about" — that's a maintainer call. But CI MUST
    detect "test count dropped" or "engine count drifted" — those ship
    with the diff, not with a maintainer's blessing.
    """
    # Live numbers
    tests_label = f"{stats.test_count}_passing"
    fuzz_label = f"{stats.fuzz_count}_properties"
    scenarios_label = f"{stats.scenario_count}_gated"
    domains_label = f"{stats.domain_count}_plugins"
    engines_label = f"{stats.engine_count}_registered"

    # Status flags. Edit in-place when reality changes.
    coverage_label = "55%25_core%20%7C%2047%25_all"
    mutation_label = "Phase_F"
    mutation_color = "orange"

    lines = [
        QUALITY_START,
        "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand.",
        "     These badges are the operator-visible quality dashboard:",
        "     every number auto-updates from the actual codebase state on",
        "     every ship. If a count drops, the ship is rejecting reality. -->",
        '<p align="center">',
        f'  <img src="https://img.shields.io/badge/tests-{tests_label}-brightgreen" alt="Tests: {stats.test_count} passing">',
        f'  <img src="https://img.shields.io/badge/fuzz-{fuzz_label}-brightgreen" alt="Fuzz: {stats.fuzz_count} property-based tests">',
        f'  <img src="https://img.shields.io/badge/scenarios-{scenarios_label}-brightgreen" alt="Scenarios: {stats.scenario_count} CI-gated regression tests">',
        f'  <img src="https://img.shields.io/badge/coverage-{coverage_label}-brightgreen" alt="Coverage: 55% core / 47% all">',
        '  <img src="https://img.shields.io/badge/architecture-0_violations-brightgreen" alt="Architecture: 0 audit violations">',
        '  <img src="https://img.shields.io/badge/dep%20graph-0_cycles-brightgreen" alt="Dep graph: 0 cycles">',
        '  <img src="https://img.shields.io/badge/lint-ruff_clean-brightgreen" alt="Lint: ruff clean">',
        f'  <img src="https://img.shields.io/badge/mutation-{mutation_label}-{mutation_color}" alt="Mutation: {mutation_label.replace("_", " ")}">',
        "</p>",
        "",
        '<p align="center">',
        '  <img src="https://img.shields.io/badge/OPSEC-scanned-brightgreen" alt="OPSEC: scanned every push">',
        '  <img src="https://img.shields.io/badge/anti--doxxing-enforced-brightgreen" alt="Anti-doxxing: enforced by rule + test">',
        '  <img src="https://img.shields.io/badge/bandit-SAST_gated-brightgreen" alt="Bandit SAST gated">',
        '  <img src="https://img.shields.io/badge/pip--audit-clean-brightgreen" alt="pip-audit clean">',
        '  <img src="https://img.shields.io/badge/rule--adherence-auditor_live-brightgreen" alt="Rule adherence auditor live">',
        '  <img src="https://img.shields.io/badge/README%20truth-gate_live-brightgreen" alt="README truth gate live">',
        '  <img src="https://img.shields.io/badge/integrity-manifest_signed-brightgreen" alt="Integrity manifest signed">',
        f'  <img src="https://img.shields.io/badge/domains-{domains_label}-blue" alt="{stats.domain_count} domain plugins">',
        f'  <img src="https://img.shields.io/badge/engines-{engines_label}-blue" alt="{stats.engine_count} engines registered">',
        "</p>",
        QUALITY_END,
    ]
    return "\n".join(lines)


def rewrite_quality_badges_block(path: Path, new_block: str) -> tuple[bool, str]:
    """Return (changed, new_contents) for a file carrying the quality markers.

    Unlike ``rewrite_stats_block``, we never auto-inject the quality block
    — README.md already has it and no other file should. If the markers
    are missing, the file is left alone.
    """
    if not path.exists():
        return (False, "")
    original = path.read_text(encoding="utf-8")
    if QUALITY_START not in original or QUALITY_END not in original:
        return (False, original)
    pattern = re.compile(
        re.escape(QUALITY_START) + r".*?" + re.escape(QUALITY_END),
        re.DOTALL,
    )
    new_contents = pattern.sub(new_block, original)
    return (new_contents != original, new_contents)


def rewrite_stats_block(path: Path, new_block: str) -> tuple[bool, str]:
    """Return (changed, new_contents) for a file that has stat markers.

    If the file has no markers, inject the block after the first H1 heading
    (only when the file is README.md or CLAUDE.md — other files must carry
    markers explicitly).
    """
    if not path.exists():
        return (False, "")
    original = path.read_text(encoding="utf-8")
    if STATS_START in original and STATS_END in original:
        pattern = re.compile(
            re.escape(STATS_START) + r".*?" + re.escape(STATS_END),
            re.DOTALL,
        )
        new_contents = pattern.sub(new_block, original)
    elif path.name in {"README.md", "CLAUDE.md"}:
        h1 = re.search(r"^# .+$", original, re.MULTILINE)
        if not h1:
            return (False, original)
        insert_at = h1.end()
        new_contents = original[:insert_at] + "\n\n" + new_block + original[insert_at:]
    else:
        return (False, original)
    return (new_contents != original, new_contents)


def diff_preview(old: str, new: str, path: Path) -> str:
    diff = difflib.unified_diff(
        old.splitlines(keepends=True),
        new.splitlines(keepends=True),
        fromfile=str(path) + " (current)",
        tofile=str(path) + " (regenerated)",
        n=2,
    )
    return "".join(diff)


def main() -> int:
    ap = argparse.ArgumentParser()
    ap.add_argument("--check", action="store_true", help="Exit 1 if any file would change.")
    ap.add_argument("--stats", action="store_true", help="Print computed stats and exit.")
    ap.add_argument("--verbose", "-v", action="store_true")
    args = ap.parse_args()

    try:
        stats = collect_stats()
    except Exception as exc:
        print(f"error collecting stats: {exc}", file=sys.stderr)
        return 2

    if args.stats:
        print(f"py_files       {stats.py_files}")
        print(f"total_lines    {stats.total_lines}")
        print(f"core_modules   {stats.core_modules}")
        print(f"domains        {stats.domain_count}")
        print(f"engines        {stats.engine_count}")
        print(f"test_files     {stats.test_files}")
        print(f"tests          {stats.test_count}")
        print(f"fuzz_tests     {stats.fuzz_count}")
        print(f"scenario_tests {stats.scenario_count}")
        print(f"scripts        {stats.scripts}")
        print(f"schema_tables  {stats.schema_tables}")
        print(f"mcp_tools      {stats.mcp_tools}")
        return 0

    stats_block = render_stats_block(stats)
    quality_block = render_quality_badges_block(stats)
    domain_catalog = collect_domain_catalog()
    domains_md = render_domains_md(domain_catalog)
    cli_md = render_cli_reference()

    targets: list[tuple[Path, str]] = []

    # Resolve the current version from core/version.py so the README
    # badge stays in lockstep with the actual shipped version.
    current_version: str | None = None
    try:
        sys.path.insert(0, str(ROOT))
        from core.version import __version__ as current_version
    except Exception as exc:
        print(f"warn: could not import core.version: {exc}", file=sys.stderr)

    for md in [ROOT / "README.md", ROOT / "CLAUDE.md", ROOT / "docs" / "ARCHITECTURE.md"]:
        if not md.exists():
            continue
        # Stat block first; the version badge fixup operates on the
        # already-updated text so two changes in the same file get
        # collapsed into a single write.
        changed, new_contents = rewrite_stats_block(md, stats_block)
        # Now apply the version badge rewrite to the (possibly already
        # updated) contents.
        if current_version and md.name == "README.md":
            badge_changed, badge_contents = rewrite_version_badge(md, current_version)
            if badge_changed:
                # Re-apply the badge fix to whatever stats_block left.
                if changed:
                    # rewrite_stats_block produced new_contents — apply
                    # the badge regex to that, not to the original file.
                    pattern = re.compile(
                        r'(<img\s+src="https://img\.shields\.io/badge/version-v)'
                        r"\d+\.\d+\.\d+"
                        r'(-[a-z]+"\s+alt="Version v)'
                        r"\d+\.\d+\.\d+"
                        r'(">)'
                    )
                    new_contents = pattern.sub(
                        rf"\g<1>{current_version}\g<2>{current_version}\g<3>",
                        new_contents,
                    )
                else:
                    new_contents = badge_contents
                changed = True

        # Quality-badges block — README only (the markers are nowhere else).
        # Operates on whatever the stats + version rewrites already produced
        # so README doesn't get written twice per run.
        if md.name == "README.md":
            if QUALITY_START in (new_contents if changed else md.read_text(encoding="utf-8")):
                working_text = new_contents if changed else md.read_text(encoding="utf-8")
                pattern = re.compile(
                    re.escape(QUALITY_START) + r".*?" + re.escape(QUALITY_END),
                    re.DOTALL,
                )
                updated = pattern.sub(quality_block, working_text)
                if updated != working_text:
                    new_contents = updated
                    changed = True

        if changed:
            targets.append((md, new_contents))

    domains_md_path = ROOT / "docs" / "DOMAINS.md"
    if not domains_md_path.exists() or domains_md_path.read_text(encoding="utf-8") != domains_md:
        targets.append((domains_md_path, domains_md))

    # docs/reference/cli.md is hand-maintained. Only auto-generate it when
    # it's missing or when it still carries our machine-generated banner.
    cli_ref_path = ROOT / "docs" / "reference" / "cli.md"
    if not cli_ref_path.exists():
        targets.append((cli_ref_path, cli_md))
    else:
        existing = cli_ref_path.read_text(encoding="utf-8")
        # Marker in the auto-generated version. If the human rewrote it
        # without this marker, we leave it alone.
        marker = "<!-- Regenerated by scripts/regen_docs.py. Do not edit by hand. -->"
        if marker in existing and existing != cli_md:
            targets.append((cli_ref_path, cli_md))

    if args.check:
        if not targets:
            if args.verbose:
                print("docs are up to date")
            return 0
        print(
            "docs are stale — run `python3 scripts/regen_docs.py` to regenerate:", file=sys.stderr
        )
        for path, new_contents in targets:
            old = path.read_text(encoding="utf-8") if path.exists() else ""
            print(diff_preview(old, new_contents, path.relative_to(ROOT)), file=sys.stderr)
        return 1

    for path, new_contents in targets:
        path.parent.mkdir(parents=True, exist_ok=True)
        path.write_text(new_contents, encoding="utf-8")
        print(f"regenerated {path.relative_to(ROOT)}")

    if not targets:
        print("docs were already up to date")

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
