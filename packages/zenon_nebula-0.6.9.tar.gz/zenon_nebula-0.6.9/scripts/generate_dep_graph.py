#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""
generate_dep_graph.py -- walk core/ and domains/, build the import graph,
detect architectural violations, emit Mermaid diagram + violation report.

Writes:
    docs/architecture/dependency-graph.md
    docs/architecture/dependency-report.md

Usage::

    python3 scripts/generate_dep_graph.py          # always exits 0
    python3 scripts/generate_dep_graph.py --check  # exits 1 if violations
    python3 scripts/generate_dep_graph.py --help

The ``--check`` mode is the CI gate. Before v0.6.9 this script ignored
``--check`` and always exited 0, which meant the ``.github/workflows/test.yml``
``architecture`` job was a fake gate silently passing violations (the
``spec_audit → tminusz_contributor`` cross-engine import was present
since v0.3.0 and nobody noticed). v0.6.9 wires real enforcement.

No external dependencies -- uses stdlib ast module.
"""

from __future__ import annotations

import argparse
import ast
import sys
from collections import defaultdict
from pathlib import Path

NEBULA_ROOT = Path(__file__).resolve().parents[1]
CORE_DIR = NEBULA_ROOT / "core"
DOMAINS_DIR = NEBULA_ROOT / "domains"
OUT_DIR = NEBULA_ROOT / "docs" / "architecture"


def _module_name_for(path: Path) -> str:
    """Return the dotted module name for a .py file relative to nebula root."""
    rel = path.relative_to(NEBULA_ROOT).with_suffix("")
    parts = rel.parts
    if parts[-1] == "__init__":
        parts = parts[:-1]
    return ".".join(parts)


def _iter_py_files(root: Path) -> list[Path]:
    """Yield all .py files under root, excluding __pycache__ and tests."""
    files: list[Path] = []
    for p in root.rglob("*.py"):
        if "__pycache__" in p.parts:
            continue
        files.append(p)
    return files


def _extract_imports(path: Path) -> list[str]:
    """Return every imported module name found in a .py file."""
    try:
        tree = ast.parse(path.read_text(encoding="utf-8"), filename=str(path))
    except (SyntaxError, UnicodeDecodeError) as exc:
        print(f"warning: cannot parse {path}: {exc}", file=sys.stderr)
        return []
    imports: list[str] = []
    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports.append(alias.name)
        elif isinstance(node, ast.ImportFrom):
            if node.level and node.level > 0:
                # relative import; resolve to absolute
                pkg = _module_name_for(path).rsplit(".", node.level)[0]
                if node.module:
                    imports.append(f"{pkg}.{node.module}" if pkg else node.module)
                else:
                    imports.append(pkg)
            elif node.module:
                imports.append(node.module)
    return imports


def _domain_of(module: str) -> str | None:
    """Return the domain name if module lives under domains.X, else None."""
    if module.startswith("domains."):
        parts = module.split(".")
        if len(parts) >= 2:
            return parts[1]
    return None


def _engine_of(module: str) -> tuple[str, str] | None:
    """Return (domain, engine_name) if module is a domain engine, else None."""
    if module.startswith("domains.") and ".engines." in module:
        parts = module.split(".")
        # domains.<d>.engines.<e>[.sub]
        if len(parts) >= 4 and parts[2] == "engines":
            return parts[1], parts[3]
    return None


def _is_internal(module: str) -> bool:
    """True if the import targets something inside the nebula package."""
    return (
        module.startswith("core.")
        or module.startswith("domains.")
        or module == "core"
        or module == "domains"
    )


def build_graph() -> dict[str, set[str]]:
    """Walk core/ and domains/, return module -> set(imported_internal_modules).

    Every scanned module gets an entry even if it has zero internal imports,
    so downstream counts reflect the full codebase -- not just the connected
    subgraph.
    """
    graph: dict[str, set[str]] = defaultdict(set)
    for base in (CORE_DIR, DOMAINS_DIR):
        for path in _iter_py_files(base):
            src = _module_name_for(path)
            graph[src]  # ensure key exists even with no imports
            for imp in _extract_imports(path):
                if _is_internal(imp):
                    graph[src].add(imp)
    return graph


def detect_violations(graph: dict[str, set[str]]) -> dict[str, list[tuple[str, str]]]:
    """Return a mapping of violation_kind -> list of (source, target) edges."""
    violations: dict[str, list[tuple[str, str]]] = {
        "core_imports_domain": [],
        "engine_imports_other_engine": [],
        "circular_import": [],
    }
    # core -> domains is forbidden by core/CLAUDE.md
    for src, targets in graph.items():
        if src.startswith("core."):
            for t in targets:
                if t.startswith("domains."):
                    violations["core_imports_domain"].append((src, t))

    # engine -> any engine (same or different domain) is forbidden
    for src, targets in graph.items():
        src_engine = _engine_of(src)
        if not src_engine:
            continue
        for t in targets:
            t_engine = _engine_of(t)
            if t_engine and t_engine != src_engine:
                violations["engine_imports_other_engine"].append((src, t))

    # Circular imports via tarjan-lite -- only report 2-cycles which are
    # by far the most common real problem; longer cycles are rare enough
    # to chase manually from the full graph dump.
    for src, targets in graph.items():
        for t in targets:
            if t in graph and src in graph[t] and src != t:
                pair = tuple(sorted([src, t]))
                if (pair[0], pair[1]) not in violations["circular_import"]:
                    violations["circular_import"].append((pair[0], pair[1]))

    return violations


def _cluster_for(module: str) -> str:
    """Return the Mermaid cluster name for a module: domain name or 'core'."""
    if module.startswith("core."):
        return "core"
    d = _domain_of(module)
    return d or "other"


def _short(module: str) -> str:
    """Shorten a module name for display in Mermaid node labels."""
    if module.startswith("core."):
        return module[5:]
    if module.startswith("domains."):
        parts = module.split(".")
        if len(parts) >= 4 and parts[2] == "engines":
            return f"{parts[1]}/{parts[3]}"
        if len(parts) >= 3:
            return f"{parts[1]}/{parts[2]}"
        return parts[1] if len(parts) >= 2 else module
    return module


def _mermaid_id(module: str) -> str:
    """Return a valid Mermaid node id for a dotted module name."""
    return module.replace(".", "_").replace("-", "_")


def render_mermaid(graph: dict[str, set[str]]) -> str:
    """Return a Mermaid graph rendering of the top-level structure.

    We intentionally collapse to one node per (cluster, top-level file)
    -- a full per-module graph would be unreadable for 267 files.
    """
    clusters: dict[str, set[str]] = defaultdict(set)
    edges: set[tuple[str, str]] = set()

    def _node_for(module: str) -> str:
        # Collapse deep submodules to their top-level: core.X or
        # domains.D.engines.E
        if module.startswith("core."):
            top = ".".join(module.split(".")[:2])
        elif module.startswith("domains."):
            parts = module.split(".")
            if len(parts) >= 4 and parts[2] == "engines":
                top = ".".join(parts[:4])
            else:
                top = ".".join(parts[:2])
        else:
            top = module
        return top

    for src, targets in graph.items():
        s = _node_for(src)
        clusters[_cluster_for(s)].add(s)
        for t in targets:
            tt = _node_for(t)
            clusters[_cluster_for(tt)].add(tt)
            if s != tt:
                edges.add((s, tt))

    lines = ["```mermaid", "graph LR"]
    for cluster_name in sorted(clusters):
        lines.append(f"  subgraph {cluster_name}")
        for node in sorted(clusters[cluster_name]):
            lines.append(f'    {_mermaid_id(node)}["{_short(node)}"]')
        lines.append("  end")
    # Only render cross-cluster edges (intra-cluster noise is huge)
    for s, t in sorted(edges):
        if _cluster_for(s) != _cluster_for(t):
            lines.append(f"  {_mermaid_id(s)} --> {_mermaid_id(t)}")
    lines.append("```")
    return "\n".join(lines)


def render_graph_doc(graph: dict[str, set[str]]) -> str:
    """Return the full markdown for dependency-graph.md."""
    total_modules = len(graph)
    total_edges = sum(len(v) for v in graph.values())
    domains = sorted({_domain_of(m) for m in graph if _domain_of(m)})

    body = [
        "# Nebula Dependency Graph",
        "",
        "Auto-generated by `scripts/generate_dep_graph.py`. Do not edit by hand --",
        "re-run the script to refresh. Only cross-cluster edges are rendered",
        "(intra-cluster edges would make the diagram unreadable).",
        "",
        "## Summary",
        "",
        f"- Total internal modules scanned: **{total_modules}**",
        f"- Total internal import edges: **{total_edges}**",
        f"- Domains: **{len(domains)}** -- {', '.join(domains)}",
        "",
        "## Cross-cluster graph",
        "",
        "Each subgraph represents a cluster (`core` or a domain). Edges",
        "between subgraphs show which cluster depends on which. Intra-cluster",
        "edges are omitted for readability.",
        "",
        render_mermaid(graph),
        "",
        "## How to regenerate",
        "",
        "```bash",
        "python3 scripts/generate_dep_graph.py",
        "```",
        "",
        "## Architecture invariants enforced",
        "",
        "- `core/*.py` must NOT import from `domains.*` (plugin boundary).",
        "- Engines must NOT import other engines (no cross-engine coupling).",
        "- No circular imports between modules.",
        "",
        "Violations are recorded in `dependency-report.md`.",
    ]
    return "\n".join(body) + "\n"


def render_violations_doc(violations: dict[str, list[tuple[str, str]]]) -> str:
    """Return the markdown report of architectural violations."""
    total = sum(len(v) for v in violations.values())
    lines = [
        "# Nebula Dependency Violations",
        "",
        "Auto-generated by `scripts/generate_dep_graph.py`. This is the",
        "single source of truth for architectural boundary violations. Any",
        "non-empty section is a bug.",
        "",
        f"**Total violations: {total}**",
        "",
    ]

    def _section(title: str, key: str, rationale: str) -> None:
        entries = violations.get(key, [])
        lines.append(f"## {title}  ({len(entries)})")
        lines.append("")
        lines.append(rationale)
        lines.append("")
        if not entries:
            lines.append("_No violations. Good._")
            lines.append("")
            return
        lines.append("| source | imports |")
        lines.append("|--------|---------|")
        for src, tgt in sorted(set(entries)):
            lines.append(f"| `{src}` | `{tgt}` |")
        lines.append("")

    _section(
        "core/ imports domains/",
        "core_imports_domain",
        "`core/CLAUDE.md` rule: core is the framework, domains are plugins. "
        "Core must never import from `domains.*` -- not at module load, not "
        "at function body, not behind `TYPE_CHECKING`. If core needs "
        "something a domain has, the domain pushes it in via a DomainPlugin hook.",
    )
    _section(
        "engine imports another engine",
        "engine_imports_other_engine",
        "Engines must be independent. If two engines share logic, extract "
        "that logic into `core/` or into a shared module inside the same "
        "domain at the domain level -- never import engine-to-engine.",
    )
    _section(
        "circular imports (2-cycles)",
        "circular_import",
        "Circular imports work at runtime but signal tangled responsibilities "
        "and break `python -c 'import X'` smoke tests. Break the cycle by "
        "moving the shared surface into a third module or using a "
        "function-scoped import.",
    )

    return "\n".join(lines) + "\n"


def main(argv: list[str] | None = None) -> int:
    """Walk the codebase, build the graph, write reports.

    Returns:
        0 always, unless ``--check`` is passed and at least one
        architectural violation is detected — in which case returns
        1 so CI (``.github/workflows/test.yml`` architecture job)
        and ``scripts/release.py validate`` can mechanically block
        the build. Details are printed to stdout; the written
        ``dependency-report.md`` contains the full violation list.
    """
    parser = argparse.ArgumentParser(
        prog="generate_dep_graph.py",
        description=(
            "Walk core/ and domains/, build the import graph, detect architectural violations."
        ),
    )
    parser.add_argument(
        "--check",
        action="store_true",
        help=(
            "Exit non-zero if any architectural violation is found. "
            "Used by CI and release.py to block on violations."
        ),
    )
    args = parser.parse_args(argv)

    OUT_DIR.mkdir(parents=True, exist_ok=True)
    graph = build_graph()
    violations = detect_violations(graph)

    graph_md = render_graph_doc(graph)
    report_md = render_violations_doc(violations)

    (OUT_DIR / "dependency-graph.md").write_text(graph_md)
    (OUT_DIR / "dependency-report.md").write_text(report_md)

    total_violations = sum(len(v) for v in violations.values())
    print(f"scanned {len(graph)} modules")
    print(f"wrote {OUT_DIR / 'dependency-graph.md'}")
    print(f"wrote {OUT_DIR / 'dependency-report.md'}")
    print(f"violations: {total_violations}")
    for kind, entries in violations.items():
        if entries:
            print(f"  {kind}: {len(entries)}")
            # In --check mode, print the specific violations so CI
            # logs point at the exact source → target pair that needs
            # fixing instead of forcing operators to open the report.
            if args.check:
                for src, target in entries:
                    print(f"    {src} -> {target}")

    if args.check and total_violations > 0:
        print(
            "\nERROR: dependency graph has violations. "
            "See docs/architecture/dependency-report.md for details. "
            "Re-run without --check to regenerate the report only.",
            file=sys.stderr,
        )
        return 1
    return 0


if __name__ == "__main__":
    sys.exit(main())
