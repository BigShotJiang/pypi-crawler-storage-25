#!/usr/bin/env python3
# SPDX-License-Identifier: MIT
"""README truth gate — fails CI on broken or stale-forward claims.

Wraps ``domains.self_maintenance.engines.readme_truth_auditor`` and
exits non-zero on any ``broken`` or ``stale_forward_claim`` finding.
``drift`` and ``unverified`` are warnings (printed but exit 0) so
small numerical drift doesn't block the build — drift gets cleaned
up by ``scripts/regen_docs.py`` on the next ship.

Usage:

    python3 scripts/check_readme_truth.py            # CI mode: exit 1 on broken
    python3 scripts/check_readme_truth.py --strict   # also fail on drift
    python3 scripts/check_readme_truth.py --quiet    # suppress per-claim output
    python3 scripts/check_readme_truth.py --json     # machine-readable summary

The same engine runs autonomously inside Nebula's cycle (via
``decide_next_action`` rotation in the self_maintenance domain) so
operators see the same drift findings in their war room. The CI
gate is the mechanical-enforcement layer for the same logic.
"""

from __future__ import annotations

import argparse
import json
import os
import sqlite3
import sys
import tempfile
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(REPO_ROOT))

from core.persistence import ensure_schema
from domains.self_maintenance.engines.readme_truth_auditor import (
    run_readme_truth_audit,
)


def main() -> int:
    parser = argparse.ArgumentParser(
        description="README truth gate — fails CI on broken README claims",
    )
    parser.add_argument(
        "--strict",
        action="store_true",
        help="Also fail on `drift` (default: only fail on `broken` + `stale_forward`)",
    )
    parser.add_argument(
        "--warn-only",
        action="store_true",
        help=(
            "Print findings but always exit 0. Used during the v0.6.7 "
            "soak period while operators clean up the legacy broken "
            "claims accumulated before the gate existed. Flip to "
            "blocking mode (no --warn-only) after the broken count "
            "reaches zero."
        ),
    )
    parser.add_argument(
        "--quiet",
        action="store_true",
        help="Suppress per-claim output, only print the summary",
    )
    parser.add_argument(
        "--json",
        action="store_true",
        help="Print summary as JSON instead of human-readable text",
    )
    args = parser.parse_args()

    # Use a tmp DB so the gate doesn't pollute the operator's
    # data/engine.db with CI findings.
    with tempfile.NamedTemporaryFile(suffix=".db", delete=False) as f:
        db_path = f.name
    try:
        ensure_schema(db_path, force=True)
        summary = run_readme_truth_audit(db_path=db_path)

        # Pull the actual findings from the tmp DB so we can print them
        findings = _read_findings(db_path)
    finally:
        try:
            os.unlink(db_path)
        except OSError:
            pass

    if args.json:
        print(
            json.dumps(
                {"summary": summary, "findings": findings},
                indent=2,
            )
        )
    else:
        _print_human(summary, findings, quiet=args.quiet)

    # Exit code policy
    has_broken = summary.get("broken", 0) > 0
    has_stale_forward = summary.get("stale_forward_claims", 0) > 0
    has_drift = summary.get("drift", 0) > 0

    if args.warn_only:
        if not args.quiet:
            print()
            if has_broken or has_stale_forward:
                print(
                    f"WARN (--warn-only): {summary['broken']} broken, "
                    f"{summary['stale_forward_claims']} stale forward-looking. "
                    "Gate is in soak mode; flip to blocking after cleanup."
                )
            else:
                print("README truth gate (--warn-only): clean")
        return 0

    if has_broken or has_stale_forward:
        if not args.quiet:
            print()
            print(
                f"FAIL: {summary['broken']} broken claim(s), "
                f"{summary['stale_forward_claims']} stale forward-looking claim(s)."
            )
            print("Fix: edit README.md / docs/claims.yml / CHANGELOG.md (see findings above).")
        return 1
    if args.strict and has_drift:
        if not args.quiet:
            print()
            print(f"FAIL (--strict): {summary['drift']} drift claim(s).")
            print("Fix: run `python3 scripts/regen_docs.py` to auto-correct.")
        return 1

    if not args.quiet:
        print()
        print("README truth gate: PASS")
    return 0


def _read_findings(db_path: str) -> list[dict]:
    """Read every readme_truth_auditor finding from the tmp DB."""
    conn = sqlite3.connect(db_path)
    try:
        conn.row_factory = sqlite3.Row
        rows = conn.execute(
            """SELECT evidence_type, finding, raw_data
            FROM evidence
            WHERE engine = 'readme_truth_auditor'
            ORDER BY evidence_type, id"""
        ).fetchall()
        return [dict(r) for r in rows]
    finally:
        conn.close()


def _print_human(summary: dict, findings: list[dict], *, quiet: bool) -> None:
    print("README Truth Gate")
    print("=" * 60)
    print(f"  Claims audited:           {summary.get('claims_audited', 0)}")
    print(f"  Verified:                 {summary.get('verified', 0)}")
    print(f"  Drift (auto-correctable): {summary.get('drift', 0)}")
    print(f"  Broken (CI fails):        {summary.get('broken', 0)}")
    print(f"  Unverified (warnings):    {summary.get('unverified', 0)}")
    print(f"  Skipped:                  {summary.get('skipped', 0)}")
    print(f"  Stale forward claims:     {summary.get('stale_forward_claims', 0)}")
    print(f"  Findings persisted:       {summary.get('findings_persisted', 0)}")

    if quiet or not findings:
        return

    print()
    print("Per-claim drift:")
    print("-" * 60)
    by_type: dict[str, list[dict]] = {}
    for f in findings:
        by_type.setdefault(f["evidence_type"], []).append(f)
    for etype in sorted(by_type.keys()):
        print(f"\n[{etype}]  ({len(by_type[etype])} finding(s))")
        for f in by_type[etype][:10]:  # cap output per category
            text = (f.get("finding") or "")[:200].replace("\n", " ")
            print(f"  - {text}")
        if len(by_type[etype]) > 10:
            print(f"  ... and {len(by_type[etype]) - 10} more")


if __name__ == "__main__":
    raise SystemExit(main())
