# SPDX-License-Identifier: MIT
"""Shared formatter: spec_audit findings → paste-ready GitHub issues.

This module used to live inside ``domains/contribution/engines/tminusz_contributor.py``
and was imported from ``domains/development/engines/spec_audit.py`` — a
cross-engine import that violated the Rule 2 architecture invariant
(engines must not import from peer engines). The import has been
present since v0.3.0 and was silently passing CI because the
``generate_dep_graph.py --check`` gate was a no-op. v0.6.9 fixes both
by moving the formatter into ``core/`` (both engines now import from
core, which is allowed) and wiring real --check enforcement.

**Agent pattern:** Pure formatter. No state, no network, no LLM. Takes
a ``spec_audit`` results dict and writes a markdown file per finding
into a target directory.

Public surface:

- ``format_spec_audit_findings_as_issues(results, *, output_dir=None)`` —
  the entry point both engines call. Returns count of files written.
- ``SPEC_AUDIT_CONTRIBUTIONS_DIR`` — default output path override
  anchor. Tests monkeypatch this via the re-export from
  ``domains.contribution.engines.tminusz_contributor`` (preserved for
  backward compatibility with ``tests/test_spec_audit.py``).

Design notes:

- The developer-commons HEAD is resolved once per call so every issue
  file pins the same commit — reviewers can reproduce the finding by
  checking out that exact state.
- The output directory is created lazily. If it can't be created the
  function logs a warning and returns 0 instead of raising — the
  contribution domain is best-effort.
- The issue body's WHAT/SO WHAT/NOW WHAT split is tolerant of
  findings that use the flat-prose convention (without explicit
  section headers). It falls back to the whole description if the
  markers are absent.
"""

from __future__ import annotations

import hashlib
import logging
import re
from pathlib import Path

from core.workspace import workspace_root_or_nebula

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Anchor paths — computed at import time so tests can monkeypatch.
# ---------------------------------------------------------------------------

_ENGINE_ROOT = Path(__file__).resolve().parents[1]
_ZENON_WORKSPACE = workspace_root_or_nebula()

SPEC_AUDIT_CONTRIBUTIONS_DIR = _ENGINE_ROOT / "data" / "contributions" / "tminusz" / "spec_audit"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _slugify(text: str, max_len: int = 40) -> str:
    """Lowercase, alnum-only slug suitable for filenames."""
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower()).strip("_")
    return slug[:max_len] or "spec_audit"


def _spec_audit_issue_body(
    spec_name: str,
    finding: dict,
    commit: str,
) -> str:
    """Render one spec_audit finding as a paste-ready GitHub issue body.

    The body is self-contained markdown the maintainer can copy directly
    into GitHub's issue UI without manual editing. Every issue carries:

    - the spec name + finding category as a title
    - a clickable permalink back to the exact spec file (and line, if any)
    - the WHAT / SO WHAT / NOW WHAT split out as headings
    - provenance (engine, severity, confidence, commit) as a footer

    The footer is what makes findings reproducible: any other operator
    running spec_audit against the same commit gets the same result, so
    the issue is verifiable without the maintainer having to trust the
    submitter.
    """
    title = finding.get("title", f"{spec_name}: spec audit finding")
    description = finding.get("description", "")
    category = finding.get("category", "spec_gap")
    severity = finding.get("severity", "medium")
    line_hint = finding.get("line_hint", 0) or 0
    source_file = finding.get("source_file", "")

    # Strip the absolute workspace prefix so the path shown in the issue
    # is relative to the developer-commons repo root, not the operator's
    # filesystem.
    rel_path = source_file
    if rel_path:
        workspace_str = str(_ZENON_WORKSPACE)
        if rel_path.startswith(workspace_str + "/"):
            rel_path = rel_path[len(workspace_str) + 1 :]
        if rel_path.startswith("knowledge/developer-commons/"):
            rel_path = rel_path[len("knowledge/developer-commons/") :]

    rel_encoded = rel_path.replace(" ", "%20")
    ref = commit or "main"
    permalink = f"https://github.com/TminusZ/zenon-developer-commons/blob/{ref}/{rel_encoded}"
    if line_hint > 0:
        permalink = f"{permalink}#L{line_hint}"

    # Split the WHAT/SO WHAT/NOW WHAT prose into separate sections so the
    # issue is scannable. The split tolerates the original "WHAT: ... SO
    # WHAT: ... NOW WHAT: ..." flat-prose format and falls back to the
    # whole description if the markers are absent.
    what_section = description
    so_what_section = ""
    now_what_section = ""
    what_match = re.search(r"WHAT:\s*(.*?)(?=SO WHAT:|NOW WHAT:|$)", description, re.DOTALL)
    so_what_match = re.search(r"SO WHAT:\s*(.*?)(?=NOW WHAT:|$)", description, re.DOTALL)
    now_what_match = re.search(r"NOW WHAT:\s*(.*?)$", description, re.DOTALL)
    if what_match:
        what_section = what_match.group(1).strip()
    if so_what_match:
        so_what_section = so_what_match.group(1).strip()
    if now_what_match:
        now_what_section = now_what_match.group(1).strip()

    body = (
        f"# Spec audit: {title}\n\n"
        f"**Found by**: Nebula `spec_audit` engine\n"
        f"**Spec file**: [`{rel_path or 'unknown'}`]({permalink})\n"
        f"**Check**: `{category}`\n"
        f"**Severity**: {severity}\n"
        f"**Commit**: `{commit or 'main'}`\n\n"
        f"---\n\n"
        f"## What\n\n{what_section}\n"
    )
    if so_what_section:
        body += f"\n## So what\n\n{so_what_section}\n"
    if now_what_section:
        body += f"\n## Now what\n\n{now_what_section}\n"

    body += (
        "\n---\n\n"
        "*This issue was generated automatically by Nebula "
        "([github.com/ZenonOrg/nebula](https://github.com/ZenonOrg/nebula)) "
        "running `spec_audit` against `developer-commons`. The finding is "
        "reproducible by any operator running Nebula against the same "
        "commit — verify locally with "
        "`nebula query \"SELECT * FROM evidence WHERE engine='spec_audit' "
        f"AND source_file LIKE '%{rel_path or ''}%'\"`*\n"
    )
    return body


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------


def format_spec_audit_findings_as_issues(
    results: dict,
    *,
    output_dir: Path | None = None,
) -> int:
    """Render every spec_audit finding to a paste-ready GitHub issue file.

    Files are written to ``data/contributions/tminusz/spec_audit/`` (or
    the override ``output_dir``) using the naming scheme
    ``{spec_name}_{check_category}_{shorthash}.md``. The shorthash makes
    each filename unique even when the same spec triggers multiple findings
    of the same category at different lines.

    Args:
        results: The dict returned by
            ``domains.development.engines.spec_audit.audit_all_specs``.
        output_dir: Override for the output directory. Defaults to
            ``SPEC_AUDIT_CONTRIBUTIONS_DIR`` at the module level.
            Tests pass a tmp_path to keep the real data dir clean.

    Returns:
        Count of issue files written.
    """
    findings_by_spec = results.get("findings", {})
    if not findings_by_spec:
        return 0

    # Resolve the default lazily so tests that monkeypatch the module-level
    # SPEC_AUDIT_CONTRIBUTIONS_DIR (and its re-export from the contribution
    # engine) pick up the override.
    target_dir = output_dir if output_dir is not None else _resolve_default_output_dir()
    try:
        target_dir.mkdir(parents=True, exist_ok=True)
    except OSError as exc:
        logger.warning("could not create %s: %s", target_dir, exc)
        return 0

    # Resolve developer-commons HEAD once so every issue file pins the
    # same commit. This matches the spec_audit engine's persist path.
    commit = ""
    try:
        from core.git_cache import get_repo_head
        from core.workspace import workspace_repo

        dc_path = workspace_repo("knowledge/developer-commons")
        if dc_path is not None:
            commit = get_repo_head(str(dc_path)) or ""
    except Exception as exc:
        logger.debug("could not resolve developer-commons HEAD: %s", exc)

    written = 0
    for spec_name, findings in findings_by_spec.items():
        for finding in findings:
            body = _spec_audit_issue_body(spec_name, finding, commit)
            # Hash the body for a stable, unique filename suffix
            digest = hashlib.sha256(body.encode("utf-8")).hexdigest()[:8]
            category = finding.get("category", "gap")
            filename = f"{_slugify(spec_name)}_{_slugify(category)}_{digest}.md"
            target_path = target_dir / filename
            try:
                target_path.write_text(body, encoding="utf-8")
                written += 1
            except OSError as exc:
                logger.warning("could not write %s: %s", target_path, exc)

    if written > 0:
        logger.info(
            "spec_audit: wrote %d paste-ready issue files to %s",
            written,
            target_dir,
        )
    return written


def _resolve_default_output_dir() -> Path:
    """Return the current default output directory.

    Tests monkeypatch ``SPEC_AUDIT_CONTRIBUTIONS_DIR`` on the contribution
    engine module (the historical entry point) via
    ``tc.SPEC_AUDIT_CONTRIBUTIONS_DIR = tmp_path``. To preserve that test
    contract, check the contribution engine's attribute first if it has
    been imported — fall back to the module-level constant otherwise.
    """
    import sys

    tc_mod = sys.modules.get("domains.contribution.engines.tminusz_contributor")
    if tc_mod is not None:
        override = getattr(tc_mod, "SPEC_AUDIT_CONTRIBUTIONS_DIR", None)
        if override is not None:
            return override
    return SPEC_AUDIT_CONTRIBUTIONS_DIR


__all__ = [
    "SPEC_AUDIT_CONTRIBUTIONS_DIR",
    "format_spec_audit_findings_as_issues",
]
