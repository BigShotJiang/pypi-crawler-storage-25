# SPDX-License-Identifier: MIT
"""API call telemetry — every provider invocation logged for measurement.

The substrate for "value per API" scoring (Phase A v0.6.6), API
schema drift detection (Phase D v0.6.9), and the operator-visible
``nebula providers diagnose`` command. Every call to a provider's
``call(...)`` method writes one row to the ``api_call_log`` table:
provider name, calling engine, latency, status, response size,
response schema hash.

Design invariants:

1. **Write-only in the hot path.** ``log_call`` never reads the
   table. Aggregation queries are pulled from CLI / engine cycles,
   not inline. Cost: one INSERT per provider call, dominated by the
   network call's latency anyway.
2. **Never blocks engine code.** Logging failures are swallowed at
   debug level. The provider call returns its result regardless of
   whether telemetry was recorded.
3. **Schema-registry auto-applied.** This module declares
   ``SCHEMA_SQL`` at module level; ``core.schema_registry`` walks
   ``core/*.py`` for the constant and applies it at boot, so we
   don't need to edit ``core/persistence/schema.py`` to add the
   table.
4. **Schema hash deterministic.** Same response shape from two
   different machines produces the same hash. Used by Phase D to
   detect upstream API contract changes.
"""

from __future__ import annotations

import hashlib
import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

from core.persistence import connect

logger = logging.getLogger(__name__)

NEBULA_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_DB = str(NEBULA_ROOT / "data" / "engine.db")


# ---------------------------------------------------------------------------
# Schema (auto-applied by core.schema_registry walking core/*.py)
# ---------------------------------------------------------------------------

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS api_call_log (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    timestamp DATETIME NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%fZ','now')),
    provider_name TEXT NOT NULL,
    engine_name TEXT,
    method TEXT,
    latency_ms INTEGER NOT NULL DEFAULT 0,
    status TEXT NOT NULL DEFAULT 'ok',
    response_bytes INTEGER NOT NULL DEFAULT 0,
    response_schema_hash TEXT,
    raw_meta_json TEXT
);

CREATE INDEX IF NOT EXISTS idx_api_call_log_provider
    ON api_call_log(provider_name);
CREATE INDEX IF NOT EXISTS idx_api_call_log_timestamp
    ON api_call_log(timestamp);
CREATE INDEX IF NOT EXISTS idx_api_call_log_status
    ON api_call_log(status);
"""


# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------


def log_call(
    *,
    provider_name: str,
    engine_name: str | None = None,
    method: str | None = None,
    latency_ms: int = 0,
    status: str = "ok",
    response_bytes: int = 0,
    response_schema_hash: str | None = None,
    raw_meta: dict | None = None,
    db_path: str = DEFAULT_DB,
) -> None:
    """Append a single row to the api_call_log table.

    Never raises. Failures are logged at debug level so a broken
    DB connection doesn't take down the engine cycle that triggered
    the call.

    Args:
        provider_name: Name of the provider (e.g. "github").
        engine_name: Calling engine, if known.
        method: Method name on the provider (e.g. "get_repo_info").
        latency_ms: Wall-clock latency in milliseconds.
        status: "ok" | "error" | "timeout" | "rate_limited" | etc.
        response_bytes: Size of the response in bytes (0 if unknown).
        response_schema_hash: Hex digest of the response shape, used
            by Phase D to detect API contract drift. ``None`` is fine
            for non-JSON responses.
        raw_meta: Optional dict of extra metadata (status code, URL,
            error class, etc.) — stored as JSON in raw_meta_json.
        db_path: SQLite path. Defaults to live engine.db.
    """
    try:
        conn = connect(db_path)
        try:
            conn.execute(
                """INSERT INTO api_call_log
                (provider_name, engine_name, method, latency_ms, status,
                 response_bytes, response_schema_hash, raw_meta_json)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
                (
                    provider_name,
                    engine_name,
                    method,
                    int(latency_ms),
                    status,
                    int(response_bytes),
                    response_schema_hash,
                    json.dumps(raw_meta) if raw_meta else None,
                ),
            )
            conn.commit()
        finally:
            conn.close()
    except sqlite3.Error as exc:
        logger.debug("api_telemetry log_call failed: %s", exc)
    except Exception as exc:
        logger.debug("api_telemetry log_call unexpected error: %s", exc)


# ---------------------------------------------------------------------------
# Schema hashing
# ---------------------------------------------------------------------------


def compute_schema_hash(response: Any) -> str | None:
    """Return a hash of the response's shape (not its values).

    Used by Phase D's drift detection: same shape on two machines
    produces the same hash, so a sudden hash change signals an
    upstream API contract update.

    For dicts: hash the sorted key-set + the type of each value.
    For lists: hash "list" + the schema hash of the first element
    (assumes homogeneous lists, which is usually true for API
    responses).
    For scalars: hash the type name.

    Returns None for empty / None inputs (nothing to hash).
    """
    if response is None:
        return None
    try:
        shape = _shape_of(response)
        canonical = json.dumps(shape, sort_keys=True, separators=(",", ":"))
        return hashlib.sha256(canonical.encode("utf-8")).hexdigest()[:16]
    except Exception as exc:
        logger.debug("compute_schema_hash failed: %s", exc)
        return None


def _shape_of(value: Any, depth: int = 0) -> Any:
    """Recursively extract the shape (types only, no values)."""
    if depth > 5:
        # Bound recursion. Deep nested shapes are rare in API
        # responses; if we hit this depth the schema is too complex
        # to fingerprint usefully.
        return "deep"
    if value is None:
        return "none"
    if isinstance(value, bool):
        return "bool"
    if isinstance(value, int):
        return "int"
    if isinstance(value, float):
        return "float"
    if isinstance(value, str):
        return "str"
    if isinstance(value, list):
        if not value:
            return ["empty"]
        return ["list", _shape_of(value[0], depth + 1)]
    if isinstance(value, dict):
        return {k: _shape_of(v, depth + 1) for k, v in sorted(value.items())}
    return type(value).__name__


# ---------------------------------------------------------------------------
# Aggregation queries (read-only, called by CLI + Phase D)
# ---------------------------------------------------------------------------


def get_call_stats(
    db_path: str = DEFAULT_DB,
    provider_name: str | None = None,
    since_seconds: int = 86_400,
) -> list[dict]:
    """Return per-provider call stats for the last ``since_seconds``.

    Output rows: ``{provider_name, total_calls, ok_calls, error_calls,
    avg_latency_ms, total_response_bytes}``.

    Used by ``nebula providers list`` and Phase D's api_awareness
    engine.
    """
    try:
        conn = connect(db_path)
        try:
            conn.row_factory = sqlite3.Row
            where = []
            params: list[Any] = []
            where.append("timestamp > datetime('now', ? || ' seconds')")
            params.append(f"-{int(since_seconds)}")
            if provider_name:
                where.append("provider_name = ?")
                params.append(provider_name)
            where_clause = " AND ".join(where)
            rows = conn.execute(
                f"""SELECT
                    provider_name,
                    COUNT(*) AS total_calls,
                    SUM(CASE WHEN status = 'ok' THEN 1 ELSE 0 END) AS ok_calls,
                    SUM(CASE WHEN status != 'ok' THEN 1 ELSE 0 END) AS error_calls,
                    CAST(AVG(latency_ms) AS INTEGER) AS avg_latency_ms,
                    SUM(response_bytes) AS total_response_bytes
                FROM api_call_log
                WHERE {where_clause}
                GROUP BY provider_name
                ORDER BY total_calls DESC""",
                params,
            ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except sqlite3.Error as exc:
        logger.debug("api_telemetry get_call_stats failed: %s", exc)
        return []


def get_recent_calls(
    db_path: str = DEFAULT_DB,
    provider_name: str | None = None,
    limit: int = 50,
) -> list[dict]:
    """Return the last N call log rows, optionally filtered by provider.

    Used by ``nebula providers diagnose <name>`` for inspecting
    recent activity.
    """
    try:
        conn = connect(db_path)
        try:
            conn.row_factory = sqlite3.Row
            if provider_name:
                rows = conn.execute(
                    """SELECT * FROM api_call_log
                    WHERE provider_name = ?
                    ORDER BY timestamp DESC
                    LIMIT ?""",
                    (provider_name, int(limit)),
                ).fetchall()
            else:
                rows = conn.execute(
                    """SELECT * FROM api_call_log
                    ORDER BY timestamp DESC
                    LIMIT ?""",
                    (int(limit),),
                ).fetchall()
            return [dict(r) for r in rows]
        finally:
            conn.close()
    except sqlite3.Error as exc:
        logger.debug("api_telemetry get_recent_calls failed: %s", exc)
        return []


__all__ = [
    "SCHEMA_SQL",
    "compute_schema_hash",
    "get_call_stats",
    "get_recent_calls",
    "log_call",
]
