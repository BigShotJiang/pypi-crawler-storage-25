# SPDX-License-Identifier: MIT
"""DeclarativeAPIProvider — HTTP API provider built from a TOML spec.

Phase B (v0.6.9) of the v0.6.6 → v0.6.17 strategic plan. Operators
declare their own HTTP APIs in ``~/.config/nebula/providers.toml``;
this class turns each declaration into a callable ``APIProvider``
instance without any operator having to write Python code.

Supported features (MVP — v0.6.9):

- GET requests with path-param substitution (``/blocks/{block_number}``).
- Auth via environment variable (``Authorization: Bearer <env>``).
- Per-endpoint rate limit + timeout.
- Response is parsed as JSON; non-JSON responses return None.
- Optional ``response_jsonpath`` projection — a tiny jq-style path
  subset so engines get just the data they need without writing
  parsing code.

Deferred to later phases:
- POST / PUT / DELETE requests.
- Complex auth schemes (OAuth, HMAC, request signing).
- Response transformation beyond basic JSON-path projection.

Security model: the provider config lives in user-space
(``~/.config/nebula/``), NOT in the repo. The user trusts their
own config. Findings derived from declarative providers are
tagged ``kind="api-user"`` and routed through
``core.trust.cap_confidence_by_provider`` so a buggy declaration
can't produce high-confidence evidence.

All HTTP calls use ``core.api_fingerprint.FingerprintedSession``
so the v0.6.6 api_telemetry pipeline captures every call
automatically — no special wiring needed.
"""

from __future__ import annotations

import logging
import os
import time
from typing import Any
from urllib.parse import quote, urljoin

from core.providers.base import APIProvider

logger = logging.getLogger(__name__)


class DeclarativeAPIProvider(APIProvider):
    """HTTP API provider constructed from a user TOML declaration.

    The spec dict mirrors the [[api]] block schema documented in
    ``core.providers.loader``. Callers never instantiate this
    directly — the loader does that at boot.
    """

    def __init__(self, *, spec: dict[str, Any]) -> None:
        self._spec = spec
        self._name = str(spec.get("name", ""))
        self._description = str(spec.get("description", ""))
        self._base_url = str(spec.get("base_url", "")).rstrip("/")
        self._auth_env_var = str(spec.get("auth_env_var", "")).strip()
        self._auth_header = str(spec.get("auth_header", "Authorization"))
        self._auth_prefix = str(spec.get("auth_prefix", "Bearer "))
        self._timeout_seconds = float(spec.get("timeout_seconds", 10.0))
        self._rate_limit_rps = float(spec.get("rate_limit_rps", 1.0))
        self._trust_tier = str(spec.get("trust_tier", "user"))

        # Index endpoints by method_name so call() is O(1)
        self._endpoints: dict[str, dict[str, Any]] = {}
        for ep in spec.get("endpoints", []):
            if not isinstance(ep, dict):
                continue
            method_name = ep.get("method_name")
            if method_name:
                self._endpoints[method_name] = ep

        # Rate limiter: last request time, updated per call
        self._last_request_ts: float = 0.0

    # ------------------------------------------------------------------
    # APIProvider interface
    # ------------------------------------------------------------------

    def name(self) -> str:
        """Return the provider name from the TOML [[api]] block."""
        return self._name

    def kind(self) -> str:
        """User-declared HTTP API — always ``api-user``.

        Phase B safety rail: the trust system caps confidence on
        findings from ``api-user`` providers.
        """
        return "api-user"

    def description(self) -> str:
        """Return the human-readable description from TOML."""
        return self._description or f"User-declared API ({self._base_url})"

    def trust_tier(self) -> str:
        """User declarations default to ``user`` trust tier."""
        return self._trust_tier

    def is_available(self) -> bool:
        """True iff the provider has a base_url and at least one endpoint.

        We don't test reachability here — that would be a network
        call on boot. Engines calling a declarative provider get
        ``None`` on failure and degrade gracefully per the provider
        contract.
        """
        return bool(self._base_url and self._endpoints)

    def call(self, method: str, **kwargs: Any) -> Any:
        """Invoke a named endpoint with the given keyword arguments.

        ``method`` must match a ``method_name`` declared in the
        spec's endpoints list. Keyword arguments fill path
        parameters (``/blocks/{block_number}`` requires
        ``block_number=123``). Returns the parsed JSON response
        (optionally projected via ``response_jsonpath``) or ``None``
        on any failure.
        """
        endpoint = self._endpoints.get(method)
        if endpoint is None:
            logger.debug(
                "DeclarativeAPIProvider %r: unknown method %r (available: %s)",
                self._name,
                method,
                list(self._endpoints.keys()),
            )
            return None

        path = str(endpoint.get("path", ""))
        http_method = str(endpoint.get("http_method", "GET")).upper()

        # MVP: only GET is supported. POST/PUT/DELETE can land in
        # a follow-up phase once there's an engine that needs them.
        if http_method != "GET":
            logger.debug(
                "DeclarativeAPIProvider %r: %s not yet supported (only GET for MVP)",
                self._name,
                http_method,
            )
            return None

        try:
            url = self._build_url(path, kwargs)
        except KeyError as exc:
            logger.debug(
                "DeclarativeAPIProvider %r: missing path param %s for method %r",
                self._name,
                exc,
                method,
            )
            return None

        self._rate_limit()
        response = self._fetch_json(url)
        if response is None:
            return None

        jsonpath = endpoint.get("response_jsonpath")
        if jsonpath:
            return self._project_jsonpath(response, str(jsonpath))
        return response

    # ------------------------------------------------------------------
    # Internal helpers
    # ------------------------------------------------------------------

    def _build_url(self, path: str, kwargs: dict[str, Any]) -> str:
        """Substitute path params + join to base_url."""
        # Simple ``{name}`` substitution. Path params must be URL-safe.
        substituted = path
        import re

        placeholders = re.findall(r"\{([a-zA-Z_][a-zA-Z0-9_]*)\}", path)
        for placeholder in placeholders:
            if placeholder not in kwargs:
                raise KeyError(placeholder)
            value = quote(str(kwargs.pop(placeholder)), safe="")
            substituted = substituted.replace(f"{{{placeholder}}}", value)
        # Remaining kwargs become query params.
        if kwargs:
            from urllib.parse import urlencode

            qs = urlencode({k: str(v) for k, v in kwargs.items()})
            separator = "&" if "?" in substituted else "?"
            substituted = f"{substituted}{separator}{qs}"
        return urljoin(self._base_url + "/", substituted.lstrip("/"))

    def _rate_limit(self) -> None:
        """Sleep enough to honor ``rate_limit_rps``."""
        if self._rate_limit_rps <= 0:
            return
        min_interval = 1.0 / self._rate_limit_rps
        elapsed = time.monotonic() - self._last_request_ts
        if elapsed < min_interval:
            time.sleep(min_interval - elapsed)
        self._last_request_ts = time.monotonic()

    def _fetch_json(self, url: str) -> Any:
        """Execute the HTTP GET and return parsed JSON or None."""
        headers = {"Accept": "application/json"}
        if self._auth_env_var:
            token = os.environ.get(self._auth_env_var, "").strip()
            if token:
                headers[self._auth_header] = f"{self._auth_prefix}{token}"

        # Use FingerprintedSession so v0.6.6 api_telemetry captures
        # every call through the existing HTTP-instrumentation layer.
        try:
            from core.api_fingerprint import FingerprintedSession
        except ImportError:
            logger.debug(
                "DeclarativeAPIProvider %r: FingerprintedSession unavailable, "
                "falling back to urllib",
                self._name,
            )
            return self._fetch_json_urllib(url, headers)

        session = FingerprintedSession(
            engine_name=f"user_provider:{self._name}",
            domain="user_providers",
        )
        try:
            response = session.request(
                "GET",
                url,
                headers=headers,
                timeout=self._timeout_seconds,
            )
        except Exception as exc:
            logger.debug(
                "DeclarativeAPIProvider %r: request failed — %s",
                self._name,
                exc,
            )
            return None
        if response.status_code != 200:
            logger.debug(
                "DeclarativeAPIProvider %r: HTTP %d for %s",
                self._name,
                response.status_code,
                url,
            )
            return None
        try:
            return response.json()
        except Exception as exc:
            logger.debug(
                "DeclarativeAPIProvider %r: response not JSON — %s",
                self._name,
                exc,
            )
            return None

    def _fetch_json_urllib(self, url: str, headers: dict[str, str]) -> Any:
        """Fallback HTTP fetch using urllib (no requests dep)."""
        import json as _json
        import urllib.error
        import urllib.request

        req = urllib.request.Request(url, headers=headers)
        try:
            with urllib.request.urlopen(req, timeout=self._timeout_seconds) as resp:
                if resp.status != 200:
                    return None
                return _json.loads(resp.read().decode("utf-8"))
        except (urllib.error.URLError, OSError, _json.JSONDecodeError) as exc:
            logger.debug(
                "DeclarativeAPIProvider %r: urllib fetch failed — %s",
                self._name,
                exc,
            )
            return None

    def _project_jsonpath(self, data: Any, jsonpath: str) -> Any:
        """Tiny jq-style path subset: ``$.key``, ``$.key.nested``.

        We explicitly don't support full JSONPath (no wildcards, no
        filters, no recursion). If an engine needs complex projection
        it should extract in engine code, not in the provider spec.
        Returns the original data if the path doesn't match.
        """
        path = jsonpath.lstrip("$")
        if not path:
            return data
        parts = [p for p in path.split(".") if p]
        current = data
        for part in parts:
            if isinstance(current, dict):
                current = current.get(part)
            elif isinstance(current, list) and part.isdigit():
                idx = int(part)
                if 0 <= idx < len(current):
                    current = current[idx]
                else:
                    return None
            else:
                return None
            if current is None:
                return None
        return current


__all__ = ["DeclarativeAPIProvider"]
