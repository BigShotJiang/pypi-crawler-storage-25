# SPDX-License-Identifier: MIT
"""User provider config loader.

Reads ``~/.config/nebula/providers.toml`` (or the XDG-standard
``$XDG_CONFIG_HOME/nebula/providers.toml``, or
``data/user_providers.toml`` as a repo-local fallback) and returns a
list of ``APIProvider`` instances ready for registration.

Users declare their own HTTP APIs and MCP servers in this TOML file
without forking Nebula. Every user provider is tagged with a tighter
trust tier so a buggy or malicious declaration can't pollute the
evidence store with high-confidence findings.

The loader uses Python's stdlib ``tomllib`` (3.11+), so no new
dependencies. Validation errors surface as warnings + skip the bad
entry; we never crash boot over a malformed user config.

Schema::

    [[api]]
    name = "my-private-blockscout"
    description = "Internal block explorer"
    base_url = "https://blockscout.internal.example.com/api/v2"
    auth_env_var = "MY_BLOCKSCOUT_TOKEN"     # optional
    auth_header = "Authorization"             # default
    auth_prefix = "Bearer "                   # default
    rate_limit_rps = 2                        # default: 1
    timeout_seconds = 15                      # default: 10
    trust_tier = "user"                       # default: user

      [[api.endpoints]]
      method_name = "get_block"
      http_method = "GET"
      path = "/blocks/{block_number}"
      response_jsonpath = "$.data"            # optional projection

    [[mcp]]
    name = "my-research-mcp"
    command = "python3"
    args = ["/path/to/mcp_server.py"]
    env = { LOG_LEVEL = "info" }
    trust_tier = "user"

    [[mcp]]
    name = "team-http-mcp"
    url = "https://mcp.team.example.com:3000"
    auth_env_var = "TEAM_MCP_TOKEN"
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any

from core.providers.base import APIProvider

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# Path resolution
# ---------------------------------------------------------------------------


def _candidate_config_paths() -> list[Path]:
    """Return the ordered list of locations to search for providers.toml.

    Priority:
    1. ``$NEBULA_PROVIDERS_CONFIG`` if set (explicit override)
    2. ``$XDG_CONFIG_HOME/nebula/providers.toml``
    3. ``~/.config/nebula/providers.toml``
    4. ``<repo>/data/user_providers.toml`` (repo-local fallback)
    """
    candidates: list[Path] = []
    override = os.environ.get("NEBULA_PROVIDERS_CONFIG", "").strip()
    if override:
        candidates.append(Path(override))
    xdg = os.environ.get("XDG_CONFIG_HOME", "").strip()
    if xdg:
        candidates.append(Path(xdg) / "nebula" / "providers.toml")
    home = os.environ.get("HOME", "").strip()
    if home:
        candidates.append(Path(home) / ".config" / "nebula" / "providers.toml")
    # Repo-local fallback (opt-in for operators who prefer in-tree config)
    repo_root = Path(__file__).resolve().parents[2]
    candidates.append(repo_root / "data" / "user_providers.toml")
    return candidates


def _first_existing_config() -> Path | None:
    """Return the first existing config file, or None."""
    for path in _candidate_config_paths():
        if path.is_file():
            return path
    return None


# ---------------------------------------------------------------------------
# TOML parsing
# ---------------------------------------------------------------------------


def _parse_toml(path: Path) -> dict[str, Any] | None:
    """Parse a TOML file. Returns None on any parse failure.

    Prefers stdlib ``tomllib`` (Python 3.11+). Falls back to the
    ``tomli`` backport on Python 3.10 since we still ship CI + wheel
    for 3.10 and user provider config must work on every supported
    Python version. ``tomli`` is declared in ``pyproject.toml`` under
    ``python_version < '3.11'`` for exactly this reason.
    """
    try:
        import tomllib  # Python 3.11+ stdlib
    except ImportError:
        try:
            import tomli as tomllib  # Python 3.10 backport
        except ImportError:
            logger.warning(
                "core.providers.loader: neither tomllib (3.11+) nor tomli "
                "(3.10 backport) available. User provider config skipped. "
                "Install tomli: pip install tomli"
            )
            return None
    try:
        with open(path, "rb") as f:
            return tomllib.load(f)
    except (OSError, tomllib.TOMLDecodeError) as exc:
        logger.warning(
            "core.providers.loader: failed to parse %s — %s. "
            "User providers from this file will not be loaded.",
            path,
            exc,
        )
        return None


# ---------------------------------------------------------------------------
# Validation
# ---------------------------------------------------------------------------


def _validate_api_entry(entry: dict[str, Any], index: int) -> list[str]:
    """Return a list of validation errors for a single [[api]] block.

    Empty list means the entry is valid enough to build a provider.
    """
    errors: list[str] = []
    if not isinstance(entry, dict):
        return [f"[[api]] entry {index} is not a table"]
    name = entry.get("name")
    if not name or not isinstance(name, str):
        errors.append(f"[[api]] entry {index}: missing or non-string 'name'")
    base_url = entry.get("base_url")
    if not base_url or not isinstance(base_url, str):
        errors.append(f"[[api]] entry {index} ({name!r}): missing or non-string 'base_url'")
    elif not base_url.startswith(("https://", "http://")):
        errors.append(
            f"[[api]] entry {index} ({name!r}): base_url must start with https:// or http://"
        )
    endpoints = entry.get("endpoints", [])
    if not isinstance(endpoints, list):
        errors.append(f"[[api]] entry {index} ({name!r}): 'endpoints' must be a list")
    else:
        for j, ep in enumerate(endpoints):
            if not isinstance(ep, dict):
                errors.append(f"[[api]] {name!r} endpoint {j}: not a table")
                continue
            if not ep.get("method_name"):
                errors.append(f"[[api]] {name!r} endpoint {j}: missing 'method_name'")
            if not ep.get("path"):
                errors.append(f"[[api]] {name!r} endpoint {j}: missing 'path'")
    return errors


def _validate_mcp_entry(entry: dict[str, Any], index: int) -> list[str]:
    """Return a list of validation errors for a single [[mcp]] block."""
    errors: list[str] = []
    if not isinstance(entry, dict):
        return [f"[[mcp]] entry {index} is not a table"]
    name = entry.get("name")
    if not name or not isinstance(name, str):
        errors.append(f"[[mcp]] entry {index}: missing or non-string 'name'")
    # Must have exactly one of command/args (stdio) or url (http)
    has_command = bool(entry.get("command"))
    has_url = bool(entry.get("url"))
    if not has_command and not has_url:
        errors.append(
            f"[[mcp]] entry {index} ({name!r}): must have either 'command' "
            "(stdio transport) or 'url' (HTTP transport)"
        )
    if has_command and has_url:
        errors.append(
            f"[[mcp]] entry {index} ({name!r}): cannot have both 'command' and 'url'; pick one"
        )
    if has_command and not isinstance(entry.get("args", []), list):
        errors.append(f"[[mcp]] entry {index} ({name!r}): 'args' must be a list")
    return errors


# ---------------------------------------------------------------------------
# Public loader API
# ---------------------------------------------------------------------------


def load_user_providers(
    *,
    config_path: Path | None = None,
) -> list[APIProvider]:
    """Load user-declared providers from the TOML config.

    Walks ``_candidate_config_paths()`` (or uses ``config_path`` if
    passed explicitly, which tests use). Returns an empty list if no
    config file exists — that's the default case for operators who
    haven't written one yet.

    Validation errors skip the bad entry but let valid entries load.
    Every error surfaces as a WARNING log so operators can find + fix
    them without reading engine source.
    """
    if config_path is None:
        config_path = _first_existing_config()
    if config_path is None or not config_path.is_file():
        logger.debug("core.providers.loader: no user provider config file found")
        return []

    data = _parse_toml(config_path)
    if data is None:
        return []

    providers: list[APIProvider] = []

    # Lazy-import the concrete provider classes so a broken import
    # here doesn't prevent the registry from loading builtins.
    try:
        from core.providers.declarative_api import DeclarativeAPIProvider
    except ImportError as exc:
        logger.warning(
            "core.providers.loader: DeclarativeAPIProvider import failed: %s. "
            "User HTTP providers skipped.",
            exc,
        )
        DeclarativeAPIProvider = None  # type: ignore[assignment]

    try:
        from core.providers.mcp_consumer import MCPConsumerProvider
    except ImportError as exc:
        logger.warning(
            "core.providers.loader: MCPConsumerProvider import failed: %s. "
            "User MCP providers skipped.",
            exc,
        )
        MCPConsumerProvider = None  # type: ignore[assignment]

    # [[api]] entries → DeclarativeAPIProvider
    api_entries = data.get("api", [])
    if isinstance(api_entries, list) and DeclarativeAPIProvider is not None:
        for i, entry in enumerate(api_entries):
            errors = _validate_api_entry(entry, i)
            if errors:
                for err in errors:
                    logger.warning("core.providers.loader: %s", err)
                continue
            try:
                provider = DeclarativeAPIProvider(spec=entry)
                providers.append(provider)
                logger.info(
                    "core.providers.loader: registered user API provider %r",
                    entry.get("name"),
                )
            except Exception as exc:
                logger.warning(
                    "core.providers.loader: failed to construct DeclarativeAPIProvider for %r: %s",
                    entry.get("name"),
                    exc,
                )

    # [[mcp]] entries → MCPConsumerProvider
    mcp_entries = data.get("mcp", [])
    if isinstance(mcp_entries, list) and MCPConsumerProvider is not None:
        for i, entry in enumerate(mcp_entries):
            errors = _validate_mcp_entry(entry, i)
            if errors:
                for err in errors:
                    logger.warning("core.providers.loader: %s", err)
                continue
            try:
                provider = MCPConsumerProvider(spec=entry)
                providers.append(provider)
                logger.info(
                    "core.providers.loader: registered user MCP provider %r",
                    entry.get("name"),
                )
            except Exception as exc:
                logger.warning(
                    "core.providers.loader: failed to construct MCPConsumerProvider for %r: %s",
                    entry.get("name"),
                    exc,
                )

    return providers


__all__ = [
    "load_user_providers",
]
