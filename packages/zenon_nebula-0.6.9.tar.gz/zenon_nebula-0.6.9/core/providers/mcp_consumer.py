# SPDX-License-Identifier: MIT
"""MCPConsumerProvider — Nebula consumes external MCP servers.

Phase B (v0.6.9) of the v0.6.6 → v0.6.17 strategic plan. Wraps the
existing ``core.mcp_bridge`` module (which already has ``call_tool``
for HTTP MCP peers and ``call_tool_stdio`` for subprocess MCP peers)
behind the ``MCPProvider`` abstraction so user-declared MCP servers
can participate in the provider registry just like any HTTP API.

Security model: user MCP declarations live in
``~/.config/nebula/providers.toml``. The user trusts their own
config. Tools invoked through an MCP consumer are tagged
``kind="mcp-user"`` and routed through the trust-cap system so
findings derived from them can't exceed the user-provider trust
floor (0.30 by default). Phase G2's user-extensibility does NOT
extend to the claims.yml side — user MCPs can contribute evidence,
but they can't inject code into Nebula's CI gates.

Two transports supported (matching core.mcp_bridge):

- **HTTP JSON-RPC** (``url`` in the spec): the MCP server is
  reachable over HTTP. Reused from ``core.mcp_bridge.call_tool``.
- **stdio subprocess** (``command`` + ``args`` in the spec):
  Nebula spawns the MCP server as a child process and communicates
  via stdin/stdout. Reused from ``core.mcp_bridge.call_tool_stdio``.

Phase B ships a thin wrapper; the real work lives in mcp_bridge.
Later phases may add subprocess lifecycle management (keep-alive
across cycles instead of per-call spawn) if the latency cost
matters.
"""

from __future__ import annotations

import logging
from typing import Any

from core.providers.base import MCPProvider

logger = logging.getLogger(__name__)


class MCPConsumerProvider(MCPProvider):
    """User-declared MCP server wrapped as an ``MCPProvider``.

    Instantiated by ``core.providers.loader`` from [[mcp]] entries
    in the user TOML config. Engines query the registry for
    ``kind="mcp-user"`` providers and call them via the standard
    ``provider.call(tool_name, **args)`` interface.
    """

    def __init__(self, *, spec: dict[str, Any]) -> None:
        self._spec = spec
        self._name = str(spec.get("name", ""))
        self._description = str(spec.get("description", ""))
        self._trust_tier = str(spec.get("trust_tier", "user"))

        # Transport selection based on what's in the spec
        self._url = str(spec.get("url", "")).strip()
        self._command = str(spec.get("command", "")).strip()
        self._args = list(spec.get("args", []))
        self._env = dict(spec.get("env", {}))
        self._auth_env_var = str(spec.get("auth_env_var", "")).strip()
        self._timeout_seconds = float(spec.get("timeout_seconds", 30.0))

        if self._url and self._command:
            raise ValueError(
                f"MCPConsumerProvider {self._name!r}: spec has both 'url' and 'command'; "
                "pick exactly one transport"
            )
        if not self._url and not self._command:
            raise ValueError(
                f"MCPConsumerProvider {self._name!r}: spec must have either 'url' or 'command'"
            )

    # ------------------------------------------------------------------
    # APIProvider / MCPProvider interface
    # ------------------------------------------------------------------

    def name(self) -> str:
        """Return the provider name from the TOML [[mcp]] block."""
        return self._name

    def kind(self) -> str:
        """User-declared MCP server — always ``mcp-user``.

        Overrides the base ``MCPProvider.kind()`` which returns
        ``mcp-builtin``. This distinction lets the trust system
        apply the user-provider cap via ``cap_confidence_by_provider``.
        """
        return "mcp-user"

    def description(self) -> str:
        """Return the human-readable description from TOML."""
        transport = "HTTP" if self._url else "stdio"
        if self._description:
            return self._description
        return f"User-declared MCP server ({transport})"

    def trust_tier(self) -> str:
        """User declarations default to ``user`` trust tier."""
        return self._trust_tier

    def is_available(self) -> bool:
        """True iff the provider has a valid transport configuration.

        For HTTP transport: the URL must be set.
        For stdio transport: the command must be set.
        We don't probe the server here — that's a network / subprocess
        cost we defer until call() is invoked.
        """
        return bool(self._url or self._command)

    def list_tools(self) -> list[dict]:
        """Return the list of tools the MCP server exposes.

        MVP: returns empty list. Phase B ships the call path; tool
        discovery via ``tools/list`` MCP protocol is a follow-up
        once an engine actually needs to iterate available tools.
        Most engines know which tool they're calling.
        """
        return []

    def call(self, method: str, **kwargs: Any) -> Any:
        """Invoke an MCP tool by name via the configured transport.

        ``method`` is the MCP tool name. ``kwargs`` become the MCP
        tool arguments. Returns the tool result or ``None`` on
        failure.

        Routes through ``core.mcp_bridge`` so the existing JSON-RPC
        client code is reused unchanged — we don't reimplement the
        protocol.
        """
        if self._url:
            return self._call_http(method, kwargs)
        if self._command:
            return self._call_stdio(method, kwargs)
        return None

    def shutdown(self) -> None:
        """No subprocess cleanup needed for the per-call-spawn design.

        mcp_bridge.call_tool_stdio spawns a fresh subprocess per
        call and cleans it up synchronously. If a later phase adds
        keep-alive subprocess management, this hook becomes the
        place to terminate long-lived children gracefully.
        """

    # ------------------------------------------------------------------
    # Transport implementations
    # ------------------------------------------------------------------

    def _call_http(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """HTTP JSON-RPC via mcp_bridge.call_tool.

        The existing mcp_bridge.call_tool takes a peer_name + tool_name
        + arguments. We bypass the peer registry by injecting this
        provider's URL as an ad-hoc peer for the duration of the call.
        """
        # Parse host:port from URL for MCPPeer construction
        from urllib.parse import urlparse

        parsed = urlparse(self._url)
        if not parsed.hostname:
            logger.debug(
                "MCPConsumerProvider %r: could not parse hostname from %r",
                self._name,
                self._url,
            )
            return None
        host = parsed.hostname
        port = parsed.port or (443 if parsed.scheme == "https" else 80)

        # Lazy-register the peer in mcp_bridge's module-level dict
        try:
            from core import mcp_bridge

            mcp_bridge._get_peers()  # ensure the dict is initialized
            if self._name not in mcp_bridge._peers:  # type: ignore[operator]
                mcp_bridge._peers[self._name] = mcp_bridge.MCPPeer(  # type: ignore[index]
                    self._name, host, port
                )
            return mcp_bridge.call_tool(
                peer_name=self._name,
                tool_name=tool_name,
                arguments=arguments,
                timeout=self._timeout_seconds,
            )
        except Exception as exc:
            logger.debug(
                "MCPConsumerProvider %r: HTTP call to %r failed — %s",
                self._name,
                tool_name,
                exc,
            )
            return None

    def _call_stdio(self, tool_name: str, arguments: dict[str, Any]) -> Any:
        """stdio subprocess via mcp_bridge.call_tool_stdio."""
        try:
            from core import mcp_bridge

            # Build the full command: [command, *args]
            cmd = [self._command] + [str(a) for a in self._args]
            # mcp_bridge.call_tool_stdio takes the command list directly
            return mcp_bridge.call_tool_stdio(
                command=cmd,
                tool_name=tool_name,
                arguments=arguments,
                timeout=self._timeout_seconds,
                env=self._env or None,
            )
        except TypeError:
            # Older call_tool_stdio signature without env — retry without
            try:
                return mcp_bridge.call_tool_stdio(
                    command=cmd,
                    tool_name=tool_name,
                    arguments=arguments,
                    timeout=self._timeout_seconds,
                )
            except Exception as exc:
                logger.debug(
                    "MCPConsumerProvider %r: stdio call failed — %s",
                    self._name,
                    exc,
                )
                return None
        except Exception as exc:
            logger.debug(
                "MCPConsumerProvider %r: stdio call failed — %s",
                self._name,
                exc,
            )
            return None


__all__ = ["MCPConsumerProvider"]
