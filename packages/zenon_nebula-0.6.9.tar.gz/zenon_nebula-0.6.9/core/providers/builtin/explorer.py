# SPDX-License-Identifier: MIT
"""Block explorer provider wrapping ``core.explorer_api``.

Multi-chain explorer adapter. ``core.explorer_api`` already supports
ZenonHub, Etherscan, Blockchair, Mempool.space, and a generic REST
fallback; this wrapper exposes its public surface through the
provider abstraction.
"""

from __future__ import annotations

from typing import Any

from core import explorer_api
from core.providers.base import APIProvider


class ExplorerProvider(APIProvider):
    """Built-in provider for multi-chain block explorers."""

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "explorer"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "api-builtin"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "Multi-chain block explorer adapter (ZenonHub, Etherscan, Blockchair, Mempool.space)"

    def is_available(self) -> bool:
        """True if at least one explorer endpoint is configured.

        ``core.explorer_api.get_all_explorers()`` returns a dict of
        configured explorers. Empty dict → no explorers reachable →
        provider unavailable.
        """
        try:
            return bool(explorer_api.get_all_explorers())
        except Exception:
            return False

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch to a method on a specific explorer.

        ``method`` should be the name of an attribute on the
        ExplorerAPI subclass. ``kwargs`` should include either
        ``url`` or ``chain`` so the right explorer is selected.
        """
        url = kwargs.pop("url", "")
        chain = kwargs.pop("chain", "")
        api_key = kwargs.pop("api_key", "")
        try:
            explorer = explorer_api.get_explorer(url=url, chain=chain, api_key=api_key)
        except Exception:
            return None
        if explorer is None:
            return None
        fn = getattr(explorer, method, None)
        if fn is None or not callable(fn):
            return None
        try:
            return fn(**kwargs)
        except Exception:
            return None


PROVIDER = ExplorerProvider()
