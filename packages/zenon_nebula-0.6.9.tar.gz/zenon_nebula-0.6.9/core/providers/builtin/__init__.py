# SPDX-License-Identifier: MIT
"""Built-in provider wrappers shipped with Nebula.

Each module under this package wraps an existing ``core.*`` API
module behind the ``APIProvider`` interface. The
``ProviderRegistry._discover_builtins()`` walker imports every
module here and registers any top-level ``PROVIDER`` constant or
``provider()`` factory.

Wrappers are intentionally thin — they delegate to the existing
modules without adding logic — so engines that haven't migrated to
the registry keep working unchanged. The migration is opportunistic:
each engine moves to ``provider_registry.get(...)`` when it's
touched for unrelated reasons.

Phase A (v0.6.6) ships these 7 wrappers:

- ``github`` — wraps ``core.github_api``
- ``explorer`` — wraps ``core.explorer_api``
- ``market_data`` — wraps ``core.api_templates.market_data``
- ``vuln_feed`` — wraps ``core.vuln_feed``
- ``zenon_data`` — wraps ``core.zenon_data``
- ``wayback`` — wraps ``core.api_templates.wayback``
- ``llm_xai`` — wraps ``core.llm_provider``
"""
