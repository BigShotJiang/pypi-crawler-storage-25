# SPDX-License-Identifier: MIT
"""xAI Grok LLM provider wrapping ``core.llm_provider``.

The default and currently-only LLM provider Nebula ships with. Phase
G2 (v0.6.13) generalizes the lookup so a user-supplied alternative
LLMProvider (Anthropic, OpenAI, local Ollama) can replace this one
via the same plugin contract.
"""

from __future__ import annotations

import os

from core import llm_provider
from core.providers.base import LLMProvider


class XaiGrokProvider(LLMProvider):
    """Built-in LLM provider routing through xAI Grok.

    Wraps ``core.llm_provider.call_llm`` so existing engines that
    import ``call_llm`` directly keep working unchanged. The new
    path for engines is ``provider_registry.get("llm_xai").complete(
    prompt, ...)``.
    """

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "llm_xai"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "llm-xai"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "xAI Grok LLM (default Nebula LLM provider)"

    def is_available(self) -> bool:
        """True if XAI_API_KEY is set in the environment."""
        return bool(os.environ.get("XAI_API_KEY"))

    def complete(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str = "auto",
        max_tokens: int = 4000,
        temperature: float = 1.0,
        json_output: bool = False,
    ) -> dict | None:
        """Delegate to ``core.llm_provider.call_llm``.

        Returns the same dict shape (``text``, ``cost_usd``,
        ``input_tokens``, ``output_tokens``, ``model``) so callers
        can swap providers without changing parsing logic.
        """
        try:
            return llm_provider.call_llm(
                prompt=prompt,
                system=system,
                model=model,
                max_tokens=max_tokens,
                temperature=temperature,
                json_output=json_output,
            )
        except Exception:
            return None


PROVIDER = XaiGrokProvider()
