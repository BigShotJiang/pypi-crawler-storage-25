# SPDX-License-Identifier: MIT
"""Wayback Machine provider wrapping ``core.api_templates.wayback``."""

from __future__ import annotations

from typing import Any

from core.api_templates import wayback
from core.providers.base import APIProvider


class WaybackProvider(APIProvider):
    """Built-in provider for the Internet Archive Wayback Machine."""

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "wayback"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "api-builtin"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "Internet Archive Wayback Machine snapshot search + fetch"

    def is_available(self) -> bool:
        """Always True; Wayback is a public API."""
        return True

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch to a function in ``core.api_templates.wayback``.

        Supported methods include ``search_snapshots``,
        ``get_snapshot_content``.
        """
        fn = getattr(wayback, method, None)
        if fn is None or not callable(fn):
            return None
        try:
            return fn(**kwargs)
        except Exception:
            return None


PROVIDER = WaybackProvider()
