# SPDX-License-Identifier: MIT
"""GitHub API provider wrapping ``core.github_api``.

Thin wrapper. Delegates every call to the existing module so engines
that import ``core.github_api`` directly keep working unchanged. The
provider is the new path for engines that prefer the registry
abstraction.
"""

from __future__ import annotations

from typing import Any

from core import github_api
from core.providers.base import APIProvider


class GitHubProvider(APIProvider):
    """Built-in provider for the GitHub REST API v3."""

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "github"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "api-builtin"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "GitHub REST API v3 (repos, commits, issues, PRs, releases)"

    def is_available(self) -> bool:
        """Always True; ``core.github_api`` works unauthenticated.

        With ``GITHUB_TOKEN`` set, the rate limit is 5,000 req/hr.
        Without it, 60 req/hr. Engines depend on the rate-limit
        circuit breaker in ``core.github_api`` for graceful degrade.
        """
        return github_api.is_available()

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch to the named function in ``core.github_api``.

        Supported methods (mirror the public surface of the wrapped
        module): ``get_repo_info``, ``get_recent_issues``,
        ``get_recent_prs``, ``get_ci_status``, ``get_releases``,
        ``get_contributors``.
        """
        fn = getattr(github_api, method, None)
        if fn is None or not callable(fn):
            return None
        try:
            return fn(**kwargs)
        except Exception:
            # core.github_api already handles its own errors and
            # returns None on failure; this is belt-and-braces.
            return None


PROVIDER = GitHubProvider()
