# SPDX-License-Identifier: MIT
"""Market data provider wrapping ``core.api_templates.market_data``."""

from __future__ import annotations

from typing import Any

from core.api_templates import market_data
from core.providers.base import APIProvider


class MarketDataProvider(APIProvider):
    """Built-in provider for DeFi market data (DexScreener, CoinGecko, Uniswap)."""

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "market_data"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "api-builtin"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "DexScreener + CoinGecko + Uniswap V3 price/volume data"

    def is_available(self) -> bool:
        """Always True; CoinGecko + DexScreener are public APIs."""
        return True

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch to a function in ``core.api_templates.market_data``.

        Supported methods include ``get_dexscreener_pair``,
        ``get_coingecko_data``, ``get_uniswap_pool``.
        """
        fn = getattr(market_data, method, None)
        if fn is None or not callable(fn):
            return None
        try:
            return fn(**kwargs)
        except Exception:
            return None


PROVIDER = MarketDataProvider()
