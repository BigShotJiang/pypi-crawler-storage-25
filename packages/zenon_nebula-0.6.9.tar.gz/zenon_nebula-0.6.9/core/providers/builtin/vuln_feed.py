# SPDX-License-Identifier: MIT
"""Vulnerability feed provider wrapping ``core.vuln_feed``."""

from __future__ import annotations

from typing import Any

from core import vuln_feed
from core.providers.base import APIProvider


class VulnFeedProvider(APIProvider):
    """Built-in provider for OSV.dev + Go vulnerability database."""

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "vuln_feed"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "api-builtin"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "OSV.dev + Go vulnerability database queries"

    def is_available(self) -> bool:
        """Always True; OSV + Go vuln DB are public, no key required."""
        return True

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch to a function in ``core.vuln_feed``.

        Supported methods include ``check_osv``, ``check_go_vulns``,
        ``scan_go_mod``, ``scan_package_json``.
        """
        fn = getattr(vuln_feed, method, None)
        if fn is None or not callable(fn):
            return None
        try:
            return fn(**kwargs)
        except Exception:
            return None


PROVIDER = VulnFeedProvider()
