# SPDX-License-Identifier: MIT
"""Zenon chain data provider wrapping ``core.zenon_data``."""

from __future__ import annotations

from typing import Any

from core import zenon_data
from core.providers.base import APIProvider


class ZenonDataProvider(APIProvider):
    """Built-in provider for Zenon chain data via JSON-RPC."""

    def name(self) -> str:
        """Return the registry key for this provider."""
        return "zenon_data"

    def kind(self) -> str:
        """Return the registry kind discriminator."""
        return "api-builtin"

    def description(self) -> str:
        """Return a one-line operator-visible description."""
        return "Zenon chain data (pillars, tokens, momentum, network info)"

    def is_available(self) -> bool:
        """True if the Zenon node RPC endpoint is reachable.

        ``core.zenon_data.get_zenon_data()`` returns a singleton client
        that defaults to a public RPC endpoint, so this is almost
        always True. Network failure is handled inside the client.
        """
        try:
            return zenon_data.get_zenon_data() is not None
        except Exception:
            return False

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch to a method on the ZenonData singleton.

        Supported methods include ``get_frontier_momentum``,
        ``get_pillars``, ``get_tokens``, ``get_network_info``.
        """
        try:
            client = zenon_data.get_zenon_data()
        except Exception:
            return None
        if client is None:
            return None
        fn = getattr(client, method, None)
        if fn is None or not callable(fn):
            return None
        try:
            return fn(**kwargs)
        except Exception:
            return None


PROVIDER = ZenonDataProvider()
