# SPDX-License-Identifier: MIT
"""Provider call instrumentation — one-line telemetry for engines.

Engines that call providers via the registry can use ``call_with_telemetry``
to get latency tracking, error logging, and api_call_log persistence
without writing the boilerplate. The helper is intentionally tiny:

    from core.providers.instrument import call_with_telemetry

    repo_info = call_with_telemetry(
        provider_name="github",
        engine_name="contributor_tracker",
        method="get_repo_info",
        owner="zenon-network",
        repo="go-zenon",
    )

This is the v0.6.6 migration substrate. Engines that want to be
provider-aware just swap their direct imports for ``call_with_telemetry``
calls; everything else (telemetry, schema hashing, error handling)
happens automatically.

The helper returns ``None`` on any failure — provider not registered,
provider unavailable, call raised, etc. Same graceful-degrade contract
as direct ``core.github_api`` calls already follow.
"""

from __future__ import annotations

import json
import logging
import time
from typing import Any

from core.api_telemetry import compute_schema_hash, log_call
from core.providers.registry import get_registry

logger = logging.getLogger(__name__)


def call_with_telemetry(
    *,
    provider_name: str,
    engine_name: str,
    method: str,
    db_path: str | None = None,
    **kwargs: Any,
) -> Any:
    """Call a provider through the registry with full telemetry.

    Wraps the provider call in timing + error handling + telemetry
    persistence. The result is returned to the caller unchanged
    (typically a dict, list, or ``None``).

    Args:
        provider_name: Registered provider name (e.g. ``"github"``).
        engine_name: Calling engine, recorded in api_call_log for
            value-per-API attribution.
        method: Method name on the provider's underlying module.
        db_path: Optional DB path override. ``None`` uses the
            telemetry module's default.
        **kwargs: Forwarded to the provider's ``call(method, **kwargs)``.

    Returns:
        The provider's response, or ``None`` if the provider isn't
        registered, isn't available, or raised. The caller can treat
        ``None`` as "no result" and degrade.
    """
    registry = get_registry()
    provider = registry.get(provider_name)
    if provider is None:
        # Engine asked for a provider that doesn't exist. Log it as a
        # config error but don't crash — degrade gracefully.
        _log_telemetry(
            provider_name=provider_name,
            engine_name=engine_name,
            method=method,
            latency_ms=0,
            status="provider_missing",
            db_path=db_path,
        )
        return None

    if not provider.is_available():
        _log_telemetry(
            provider_name=provider_name,
            engine_name=engine_name,
            method=method,
            latency_ms=0,
            status="unavailable",
            db_path=db_path,
        )
        return None

    start = time.monotonic()
    try:
        result = provider.call(method, **kwargs)
    except Exception as exc:
        latency_ms = int((time.monotonic() - start) * 1000)
        _log_telemetry(
            provider_name=provider_name,
            engine_name=engine_name,
            method=method,
            latency_ms=latency_ms,
            status="error",
            raw_meta={"error_class": type(exc).__name__, "error": str(exc)[:200]},
            db_path=db_path,
        )
        logger.debug(
            "call_with_telemetry: %s.%s raised %s",
            provider_name,
            method,
            type(exc).__name__,
        )
        return None

    latency_ms = int((time.monotonic() - start) * 1000)
    response_bytes = 0
    schema_hash = None
    if result is not None:
        try:
            serialized = json.dumps(result, default=str)
            response_bytes = len(serialized.encode("utf-8"))
            schema_hash = compute_schema_hash(result)
        except (TypeError, ValueError):
            # Non-JSON-serializable result; log without schema hash.
            response_bytes = 0

    _log_telemetry(
        provider_name=provider_name,
        engine_name=engine_name,
        method=method,
        latency_ms=latency_ms,
        status="ok" if result is not None else "no_result",
        response_bytes=response_bytes,
        response_schema_hash=schema_hash,
        db_path=db_path,
    )
    return result


def _log_telemetry(*, db_path: str | None, **kwargs: Any) -> None:
    """Forward to ``api_telemetry.log_call`` honoring the optional db_path."""
    if db_path is not None:
        log_call(db_path=db_path, **kwargs)
    else:
        log_call(**kwargs)


__all__ = ["call_with_telemetry"]
