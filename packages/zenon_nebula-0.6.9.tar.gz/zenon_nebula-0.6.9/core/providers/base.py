# SPDX-License-Identifier: MIT
"""Provider base classes — the plugin boundary for external capabilities.

Every external service Nebula consults — HTTP APIs, MCP servers,
on-chain RPC nodes, LLM endpoints — is wrapped in a ``Provider``
subclass. Engines call the registry by name (``provider_registry.get(
"github")``) instead of importing concrete modules. This indirection
is the substrate for:

- Phase A (v0.6.6): API call telemetry — every provider call routes
  through ``api_telemetry.log_call`` so we can measure latency, error
  rate, and value-per-API after the fact.
- Phase A: provenance — every persisted finding records the providers
  the engine consulted via the ``api_sources`` column.
- Phase B (v0.6.7): user-extensible providers loaded from a TOML
  config file. The same ``APIProvider`` ABC the builtins implement.
- Phase D (v0.6.9): drift detection — ``api_awareness`` reads
  telemetry to flag providers whose schema or error rate has shifted.
- Phase G2 (v0.6.13): replaceable LLM — ``LLMProvider`` is a subclass
  of ``APIProvider`` so a user can swap xAI for Claude / Ollama via
  the same plugin contract.

The contract is intentionally minimal so plugin authors don't need to
import anything from the rest of Nebula. Sub-classes implement
``name``, ``kind``, ``is_available``, and ``call``. Everything else
is convenience built on top.
"""

from __future__ import annotations

from abc import ABC, abstractmethod
from typing import Any


class APIProvider(ABC):
    """Abstract base class for any external capability provider.

    Subclasses wrap a single external service (a HTTP API, an MCP
    server, an LLM endpoint). The registry queries them by name and
    by ``kind``; engines never import concrete provider modules.

    The ``kind`` field is the discriminator the registry uses for
    multi-provider lookups (e.g. "find any 'market_data' provider").
    Conventional kinds:

    - ``"api-builtin"`` — shipped HTTP API wrapper (github, coingecko, ...)
    - ``"api-user"`` — user-supplied HTTP API from providers.toml
    - ``"mcp-builtin"`` — shipped MCP server consumer
    - ``"mcp-user"`` — user-supplied MCP server consumer
    - ``"llm-xai"`` — the default xAI Grok LLM
    - ``"llm-<other>"`` — alternative LLM (Phase G2)

    The kind is also used by ``core.trust.cap_confidence_by_provider``
    (Phase B) to apply tighter trust caps to user-supplied providers.
    """

    @abstractmethod
    def name(self) -> str:
        """Return the unique provider name (lowercase, snake_case).

        The name is the registry key. Two providers with the same
        name cannot coexist; the registry raises on registration
        conflict. Convention: short, descriptive, no version suffix
        (versioning lives in ``api_telemetry``).
        """

    @abstractmethod
    def kind(self) -> str:
        """Return the provider kind discriminator.

        See the class docstring for the conventional kinds.
        """

    @abstractmethod
    def is_available(self) -> bool:
        """Return True if the provider can be called right now.

        Implementations check for required env vars (API keys),
        network reachability, subprocess health, etc. Engines that
        depend on a provider should call ``is_available()`` first
        and degrade gracefully if False.
        """

    @abstractmethod
    def call(self, method: str, **kwargs: Any) -> Any:
        """Call a provider method by name with keyword arguments.

        The method name maps to a function on the underlying service.
        For HTTP API providers, this is typically the wrapped function
        name (``"get_repo_info"``). For MCP providers, this is the
        tool name. For LLM providers, this is the operation
        (``"complete"``).

        Returns the provider's response (typically a dict, list, or
        ``None`` on failure). Implementations MUST graceful-degrade
        on errors — never raise into engine code, return ``None`` and
        log a debug message.
        """

    # ------------------------------------------------------------------
    # Optional convenience methods (implementations can override)
    # ------------------------------------------------------------------

    def description(self) -> str:
        """Return a one-line human-readable description.

        Default: empty string. Used by ``nebula providers list`` for
        operator visibility.
        """
        return ""

    def version(self) -> str:
        """Return the provider's version string.

        Default: empty string. Used by ``api_telemetry`` to detect
        schema drift across versions.
        """
        return ""

    def trust_tier(self) -> str:
        """Return the trust tier classification.

        One of: ``"builtin"``, ``"user"``, ``"peer"``, ``"unknown"``.
        Phase B uses this to cap confidence on findings derived from
        user-supplied providers.

        Default: ``"builtin"`` for shipped providers; user providers
        override to ``"user"``.
        """
        return "builtin"

    def shutdown(self) -> None:
        """Optional cleanup hook called on graceful shutdown.

        Default: no-op. Subclasses with subprocess or socket
        resources (MCP consumer, persistent HTTP session) override
        to release them cleanly.
        """


class MCPProvider(APIProvider):
    """Specialization of APIProvider for MCP server consumers.

    Adds ``list_tools()`` for dynamic tool discovery. The MCP
    protocol exposes a server's available tools at runtime via the
    ``tools/list`` request, so consumers can iterate without a
    hardcoded method list.

    Phase A ships no MCP consumer (the existing ``core.mcp_bridge``
    is wrapped in Phase B as a ``DeclarativeMCPProvider``). This
    class exists in Phase A so the type hierarchy is stable from
    the start.
    """

    def kind(self) -> str:
        """Default kind for MCP consumers."""
        return "mcp-builtin"

    @abstractmethod
    def list_tools(self) -> list[dict]:
        """Return the list of tools the MCP server exposes.

        Each tool dict has at minimum ``name`` and ``description``
        keys. Engines use this for dynamic dispatch.
        """


class LLMProvider(APIProvider):
    """Specialization of APIProvider for LLM endpoints.

    Standardizes the ``complete()`` interface so any LLM (xAI Grok,
    Anthropic Claude, OpenAI GPT, local Ollama, etc.) can be swapped
    in via the same provider contract.

    Phase A ships ``builtin/llm_xai.py`` as the default; Phase G2
    (v0.6.13) adds the user-config swap path so an operator can
    register their own ``LLMProvider`` subclass and route all of
    Nebula's LLM calls through it without touching ``call_llm``.
    """

    def kind(self) -> str:
        """Default kind for LLM providers — concrete subclasses override."""
        return "llm-builtin"

    @abstractmethod
    def complete(
        self,
        prompt: str,
        *,
        system: str = "",
        model: str = "auto",
        max_tokens: int = 4000,
        temperature: float = 1.0,
        json_output: bool = False,
    ) -> dict | None:
        """Generate a completion from the LLM.

        Returns a dict with at minimum ``text``, ``cost_usd``,
        ``input_tokens``, ``output_tokens``, ``model`` keys (matching
        the existing ``core.llm_provider.call_llm`` shape). ``None``
        on failure.
        """

    def call(self, method: str, **kwargs: Any) -> Any:
        """Dispatch ``call("complete", ...)`` to ``complete(...)``.

        Provided as a convenience so LLM providers don't need to
        re-implement ``call``. Other method names raise NotImplemented.
        """
        if method == "complete":
            return self.complete(**kwargs)
        raise NotImplementedError(f"LLMProvider {self.name()!r} does not support method {method!r}")


__all__ = ["APIProvider", "LLMProvider", "MCPProvider"]
