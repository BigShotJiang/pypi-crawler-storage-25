# SPDX-License-Identifier: MIT
"""Provider package — the plugin boundary for external capabilities.

Public surface:

- ``APIProvider``, ``MCPProvider``, ``LLMProvider`` — abstract base
  classes plugins implement.
- ``get_registry()`` — returns the singleton ``ProviderRegistry``.
- ``ProviderRegistry`` — the registry class for direct typing.

Engines should call ``get_registry().get(name)`` instead of importing
concrete provider modules. This indirection is the substrate for
telemetry, value-per-API scoring, and Phase B's user-extensible
provider config.
"""

from core.providers.base import APIProvider, LLMProvider, MCPProvider
from core.providers.registry import ProviderRegistry, get_registry

__all__ = [
    "APIProvider",
    "LLMProvider",
    "MCPProvider",
    "ProviderRegistry",
    "get_registry",
]
