# SPDX-License-Identifier: MIT
"""ActionSpec — machine-actionable shape embedded in findings.

Pulled forward from Phase I (v0.6.16) into the v0.6.6 MVP so every
finding written from now on is already structured for downstream
agent consumption. The full claim/complete protocol stays in Phase
I; this module just ships the *shape* so retrofitting structure to
existing findings later is unnecessary.

The vision: Nebula diagnoses what needs doing, executor agents
(Claude Code, custom executors, eventually fully autonomous) read
the priority queue, claim findings with action specs, do the work
in target repos (go-zenon, znn_sdk_dart, syrius, etc.), report
back. Nebula treats completions as new evidence and updates
hypothesis confidence accordingly. The loop closes.

For that loop to work, findings need a parseable description of the
work, not just prose. Today's WHAT/SO WHAT/NOW WHAT format is for
humans; ActionSpec is the machine-readable companion.

Engines opt in: pass ``action_spec=ActionSpec(...)`` to
``persist_finding``. Engines that don't pass an ActionSpec keep
working unchanged — the column is nullable and downstream agents
treat its absence as "no machine-actionable form, human review only."

Conservative scope for v0.6.6: just the dataclass + JSON
serialization. No claim queue, no priority math, no completion
verification — those land in Phase I.
"""

from __future__ import annotations

import json
from dataclasses import asdict, dataclass, field
from typing import Any

# Action types — what kind of work the finding asks for. Kept short
# and additive so new types can land in future phases without
# breaking existing consumers.
VALID_ACTION_TYPES = frozenset(
    {
        "fix_bug",
        "implement_feature",
        "harden_hypothesis",
        "verify_claim",
        "investigate_file",
        "add_test",
        "update_docs",
        "refactor",
        "review",
    }
)

# Effort + risk classifications. Operators map these to their own
# autonomy thresholds (Phase I autonomy spectrum).
VALID_EFFORT = frozenset({"trivial", "small", "medium", "large", "unknown"})
VALID_RISK = frozenset({"low", "medium", "high", "critical", "unknown"})


@dataclass(frozen=True)
class ActionSpec:
    """Structured action description embedded in a finding.

    Frozen dataclass so the same instance can be safely shared
    across the registry + persistence layers without aliasing
    surprises.

    Required fields:
        action_type: One of ``VALID_ACTION_TYPES``. The kind of
            work this finding asks for.
        target_repo: Canonical repo identity (e.g. ``go-zenon``,
            ``znn_sdk_dart``, ``knowledge/developer-commons``).
            **In OTHER repos, not Nebula itself** — Nebula is the
            brain, the work happens elsewhere.

    Optional fields:
        target_file: Relative path inside ``target_repo``.
        target_line: Line number for line-precise findings.
        success_criteria: List of testable predicates the executor
            agent should verify after doing the work. Each entry is
            a one-line natural-language criterion (e.g. "go test
            ./vm/embedded/htlc/... passes" or "ABI method matches
            spec section 2.3").
        effort_estimate: ``trivial`` | ``small`` | ``medium`` |
            ``large`` | ``unknown``.
        risk_estimate: ``low`` | ``medium`` | ``high`` | ``critical``
            | ``unknown``. Used by Phase I's autonomy spectrum to
            decide whether the action can auto-apply or needs
            human approval.
        parent_action_id: Optional finding ID that this action
            depends on. Lets agents handle action chains where one
            piece of work unblocks another.

    The dataclass is intentionally minimal. Phase I (v0.6.16+) adds
    the claim queue + completion protocol on top; Phase H1 adds
    creativity attribution; Phase G1's hooks can subscribe to
    action_spec events. Each layer extends without modifying.
    """

    action_type: str
    target_repo: str
    target_file: str | None = None
    target_line: int | None = None
    success_criteria: tuple[str, ...] = field(default_factory=tuple)
    effort_estimate: str = "unknown"
    risk_estimate: str = "unknown"
    parent_action_id: int | None = None

    def __post_init__(self) -> None:
        # Validate at construction so a malformed ActionSpec never
        # reaches persistence.
        if self.action_type not in VALID_ACTION_TYPES:
            raise ValueError(
                f"ActionSpec.action_type must be one of {sorted(VALID_ACTION_TYPES)}, "
                f"got {self.action_type!r}"
            )
        if not self.target_repo:
            raise ValueError("ActionSpec.target_repo is required")
        if self.effort_estimate not in VALID_EFFORT:
            raise ValueError(
                f"ActionSpec.effort_estimate must be one of {sorted(VALID_EFFORT)}, "
                f"got {self.effort_estimate!r}"
            )
        if self.risk_estimate not in VALID_RISK:
            raise ValueError(
                f"ActionSpec.risk_estimate must be one of {sorted(VALID_RISK)}, "
                f"got {self.risk_estimate!r}"
            )
        if self.target_line is not None and self.target_line < 0:
            raise ValueError(f"ActionSpec.target_line must be >= 0, got {self.target_line}")
        # Coerce list → tuple in case the caller passed a list literal.
        if not isinstance(self.success_criteria, tuple):
            object.__setattr__(self, "success_criteria", tuple(self.success_criteria))

    def to_dict(self) -> dict[str, Any]:
        """Return a JSON-serializable dict.

        Used by ``persist_finding`` to write the spec to the
        ``evidence.action_spec_json`` column.
        """
        return asdict(self)

    def to_json(self) -> str:
        """Return a canonical JSON string.

        ``sort_keys=True`` ensures the same spec produces the same
        string on every machine, which matters for content_hash
        determinism (Phase I uses spec hashes for dedup).
        """
        return json.dumps(self.to_dict(), sort_keys=True, separators=(",", ":"))

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> ActionSpec:
        """Reconstruct from a dict (e.g. from a DB row)."""
        # Filter to known fields so unknown future fields don't crash
        # older code reading newer DB rows.
        allowed = {k: v for k, v in data.items() if k in cls.__dataclass_fields__}
        # Coerce success_criteria from list to tuple
        if "success_criteria" in allowed and isinstance(allowed["success_criteria"], list):
            allowed["success_criteria"] = tuple(allowed["success_criteria"])
        return cls(**allowed)

    @classmethod
    def from_json(cls, json_str: str) -> ActionSpec:
        """Reconstruct from a canonical JSON string."""
        return cls.from_dict(json.loads(json_str))


__all__ = [
    "VALID_ACTION_TYPES",
    "VALID_EFFORT",
    "VALID_RISK",
    "ActionSpec",
]
