# SPDX-License-Identifier: MIT
"""Findings package — structured data shapes for evidence consumed by agents.

The MVP (v0.6.6) ships ``ActionSpec``: a lightweight dataclass that
engines optionally embed in findings so downstream executor agents
(Phase I, v0.6.16) can pick up the work without parsing prose. The
full claim/complete protocol stays in Phase I; this package just
ships the shape.
"""

from core.findings.action_spec import ActionSpec

__all__ = ["ActionSpec"]
