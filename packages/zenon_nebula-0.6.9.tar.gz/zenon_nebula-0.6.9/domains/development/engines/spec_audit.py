# SPDX-License-Identifier: MIT
"""
SpecAudit -- Quality auditor for the TminusZ developer-commons spec corpus.

Reads every markdown spec under ``knowledge/developer-commons/docs/specs/`` and
flags structural quality gaps that block implementers:

- missing threat model sections
- missing test vectors
- untestable claims (vague language inside ABI definitions)
- stale cross-spec references (broken links)
- underspecified boundary conditions on amount/timestamp parameters
- underspecified error paths on state-mutating ABI methods

Mirrors the pattern in ``domains/security/engines/adversarial_reviewer.py``:
per-check helpers -> ``audit_spec`` aggregator -> ``audit_all_specs``
orchestrator -> ``persist_audit_findings`` with full provenance + clickable
verification URLs back to TminusZ/zenon-developer-commons on GitHub.

Every check is deterministic and free (no LLM calls, no network). Findings
ship with WHAT/SO WHAT/NOW WHAT structure so TminusZ authors can act on them
in 30 seconds. The companion ``format_spec_audit_findings_as_issues`` helper
in ``core/spec_audit_contributions.py`` (re-exported from the contribution
engine module for backward compat) converts each finding into a
paste-ready GitHub issue body, closing the detect-to-PR loop.

This is the engine that lets the community help TminusZ tighten the spec
corpus without anyone having to do manual translation between Nebula
findings and upstream contributions.
"""

from __future__ import annotations

import logging
import re
from pathlib import Path

from core.persist_to_db import persist_finding
from core.workspace import workspace_root_or_nebula

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
ZENON_WORKSPACE = workspace_root_or_nebula()
SPECS_DIR = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"

# Upstream repo for verification URLs. The maintainer's fork lives at
# ZenonOrg/zenon-developer-commons but the canonical URL points at TminusZ.
UPSTREAM_OWNER = "TminusZ"
UPSTREAM_REPO = "zenon-developer-commons"


# ---------------------------------------------------------------------------
# Reusable helpers (provenance + URL building)
# ---------------------------------------------------------------------------


def _build_specs_url(spec_path: str, line: int, commit: str) -> str | None:
    """Build a clickable GitHub permalink to a spec section.

    ``spec_path`` may be absolute (full filesystem path) or relative to the
    workspace root. The function strips the workspace prefix and the
    ``knowledge/developer-commons/`` prefix so the resulting URL is relative
    to the repo root, which is what GitHub expects. Falls back to the
    ``main`` branch when the commit hash is unavailable.
    """
    if not spec_path:
        return None
    rel = spec_path
    # Strip absolute workspace root if present
    workspace_str = str(ZENON_WORKSPACE)
    if rel.startswith(workspace_str + "/"):
        rel = rel[len(workspace_str) + 1 :]
    # Strip the developer-commons repo prefix so what's left is in-repo
    if rel.startswith("knowledge/developer-commons/"):
        rel = rel[len("knowledge/developer-commons/") :]
    # URL-encode spaces (some spec dirs have spaces, e.g. "Zenon Portal")
    rel_encoded = rel.replace(" ", "%20")
    ref = commit or "main"
    url = f"https://github.com/{UPSTREAM_OWNER}/{UPSTREAM_REPO}/blob/{ref}/{rel_encoded}"
    if line and line > 0:
        url = f"{url}#L{line}"
    return url


def _read_spec(path: Path, max_bytes: int = 500_000) -> str:
    """Read a spec file, returning empty string on failure."""
    try:
        return path.read_text(encoding="utf-8", errors="replace")[:max_bytes]
    except (OSError, UnicodeDecodeError):
        return ""


def _spec_name_from_path(spec_path: Path) -> str:
    """Best-effort human-readable spec name from a file path.

    For files inside a spec directory (e.g. ``PTLC/ptlc_spec.md``), use the
    parent directory name. For top-level standalone specs (e.g.
    ``GALV_spec_draft.md``), use the file stem.
    """
    parent = spec_path.parent
    if parent.name and parent.name not in ("specs", "docs"):
        return parent.name
    return spec_path.stem


# ---------------------------------------------------------------------------
# Section / pattern detectors used by multiple checks
# ---------------------------------------------------------------------------


# Match a markdown heading line like "## Foo", "## 4. Foo", "### Foo".
# Captures the level (#'s) and the title text.
_HEADING_RE = re.compile(r"^(#{1,6})\s+(?:\d+(?:\.\d+)*\.?\s+)?(.+)$", re.MULTILINE)

# Heading-text patterns that count as a "threat model" section. Calibrated
# against the real TminusZ corpus: PTLC v2 / Bitcoin-SPV / Governance use
# "Security Model"; Streaming uses "Security Considerations". The regex is
# applied to the heading TITLE only (after stripping the numeric prefix),
# case-insensitive.
_THREAT_MODEL_TITLES = re.compile(
    r"\b(threat\s+model|security\s+model|security\s+considerations|"
    r"adversar(?:y|ial|ies)|attack\s+vectors?|trust\s+assumptions?)\b",
    re.IGNORECASE,
)

# Heading-text patterns that count as a test-vectors section. PTLC v2 /
# Bitcoin-SPV / Governance use "Conformance Tests"; the canonical
# alternatives are "Test Vectors", "Examples", "Reference Vectors".
_TEST_VECTOR_TITLES = re.compile(
    r"\b(test\s+vectors?|conformance\s+tests?|reference\s+vectors?|"
    r"worked\s+examples?|known[-\s]?answer\s+tests?)\b",
    re.IGNORECASE,
)

# Heading-text patterns that count as an explicit errors section.
_ERRORS_TITLES = re.compile(
    r"\b(errors?|error\s+returns?|failure\s+modes?|reverts?|"
    r"error\s+codes?|exception(?:s|al\s+cases))\b",
    re.IGNORECASE,
)

# Method names that look state-mutating. Used to decide whether the
# missing-errors / missing-threat-model checks should fire.
_STATE_MUTATING_VERBS = (
    "create",
    "update",
    "delete",
    "withdraw",
    "reclaim",
    "cancel",
    "vote",
    "submit",
    "send",
    "transfer",
    "mint",
    "burn",
    "deposit",
    "redeem",
    "unlock",
    "lock",
    "stake",
    "unstake",
    "register",
    "deregister",
    "set",
    "remove",
    "add",
)

# Untestable language an implementer can't translate into a deterministic
# check. Each phrase is checked as a whole-word match, case insensitive,
# only inside contexts that look like an ABI / method specification (not
# inside top-level prose, where vague language is legitimate).
_UNTESTABLE_PHRASES = (
    "reasonable",
    "appropriate",
    "sufficient",
    "sufficiently",
    "should normally",
    "in most cases",
    "typically",
    "usually",
    "as needed",
    "if necessary",
    "where applicable",
)

# Boundary keywords that, when present in the prose around a method, prove
# the spec author has thought about boundary semantics. These are the
# words that make _check_boundary_conditions NOT fire.
_BOUNDARY_KEYWORDS = re.compile(
    r"\b(zero|exactly|inclusive|exclusive|max(?:imum)?|min(?:imum)?|"
    r"strict\s+inequality|>=|<=|< expiry|>= expiry|boundary|edge\s+case)\b",
    re.IGNORECASE,
)

# Parameter names that signal "this method takes an amount or a deadline".
_BOUNDARY_PARAM_NAMES = re.compile(
    r"\b(amount|balance|value|timestamp|deadline|expir(?:ation|y|es)|"
    r"duration|expiration_?time|valid_?until|deadline_?seconds)\b",
    re.IGNORECASE,
)


def _iter_headings(source: str) -> list[tuple[int, int, str]]:
    """Return a list of ``(line_no, level, title)`` for every heading.

    Strips numeric section prefixes ("4.", "4.1") so the title text is
    just the human-readable label.
    """
    out: list[tuple[int, int, str]] = []
    for m in _HEADING_RE.finditer(source):
        line_no = source.count("\n", 0, m.start()) + 1
        level = len(m.group(1))
        title = m.group(2).strip()
        out.append((line_no, level, title))
    return out


def _find_section_with_title(source: str, title_re: re.Pattern[str]) -> tuple[int, str] | None:
    """Return the (line_no, title) of the first heading whose title matches.

    Used by the threat-model / test-vectors / errors checks.
    """
    for line_no, _level, title in _iter_headings(source):
        if title_re.search(title):
            return (line_no, title)
    return None


def _has_state_mutating_methods(source: str) -> bool:
    """Heuristic: does the spec define any state-mutating ABI method?

    Checks the spec for ABI table rows or code-block function signatures
    whose method name starts with one of the known mutating verbs.
    """
    # ABI table row: | `Create` | ... |
    abi_table_re = re.compile(r"\|\s*`?(\w+)`?\s*\|", re.MULTILINE)
    # Code-block signature: func (...) Create(...)
    sig_re = re.compile(r"\bfunc\s+\([^)]+\)\s+(\w+)\s*\(", re.MULTILINE)
    for pattern in (abi_table_re, sig_re):
        for match in pattern.finditer(source):
            name = match.group(1).lower()
            if any(name.startswith(verb) for verb in _STATE_MUTATING_VERBS):
                return True
    return False


def _count_abi_methods(source: str) -> int:
    """Best-effort count of ABI methods declared in the spec.

    Two sources:
    1. Markdown tables whose **header row** contains an ABI marker
       (``Method``, ``Function``, ``ABI``, ``Signature``). This filters
       out generic tables of fields, primitives, parameters, etc. that
       happen to share the markdown table syntax.
    2. Go function signatures in fenced code blocks (``func (recv) Name(...)``).
    The count is approximate; it's used to decide whether the
    missing-test-vectors check should fire.
    """
    methods: set[str] = set()

    # Walk markdown tables, only count rows from tables whose header
    # signals an ABI table.
    # Each row starts with `|` and ends at `\n`; `[^\n]` prevents `\s*`
    # from greedy-eating blank lines and merging adjacent tables into one
    # block (test_only_counts_abi_table_rows pins this behavior).
    table_blocks = re.findall(r"((?:^\|[^\n]*\n)+)", source, flags=re.MULTILINE)
    for block in table_blocks:
        block_lines = block.strip().split("\n")
        if not block_lines:
            continue
        header = block_lines[0].lower()
        if not re.search(r"\b(method|function|abi|signature|operation|api)\b", header):
            continue
        # First column of every row that's neither header nor separator
        for line in block_lines[2:]:
            cells = [c.strip() for c in line.strip().strip("|").split("|")]
            if not cells:
                continue
            name_cell = cells[0].strip("`").strip()
            if not name_cell or name_cell in ("---", "Method", "Name", "Function"):
                continue
            # Method names start with an uppercase letter (Go convention)
            if name_cell and name_cell[0].isupper() and re.match(r"^\w+$", name_cell):
                methods.add(name_cell)

    # Function signatures in code blocks
    sig_re = re.compile(r"\bfunc\s+\([^)]+\)\s+([A-Z]\w+)\s*\(", re.MULTILINE)
    for match in sig_re.finditer(source):
        methods.add(match.group(1))

    return len(methods)


# ---------------------------------------------------------------------------
# Per-check helpers
# ---------------------------------------------------------------------------


def _check_missing_threat_model(spec_path: Path, source: str) -> list[dict]:
    """Flag specs that define state-mutating methods but have no threat model.

    Calibrated against the real corpus: PTLC v2 / Bitcoin-SPV / Governance
    all have "Security Model" sections; Streaming uses "Security
    Considerations". Anything matching ``_THREAT_MODEL_TITLES`` counts as
    present and the check stays silent.
    """
    if not _has_state_mutating_methods(source):
        # No state mutation -> no threat model required
        return []
    if _find_section_with_title(source, _THREAT_MODEL_TITLES) is not None:
        return []
    spec_name = _spec_name_from_path(spec_path)
    return [
        {
            "category": "missing_threat_model",
            "severity": "high",
            "title": f"{spec_name}: missing threat model section",
            "description": (
                f"WHAT: {spec_name} defines state-mutating ABI methods but "
                f"has no Threat Model / Security Model / Security "
                f"Considerations section. "
                f"SO WHAT: Implementers and reviewers have no canonical "
                f"answer for 'what attacks does this defend against?', so "
                f"each implementation re-invents the threat model and "
                f"usually misses things the spec author would have caught. "
                f"NOW WHAT: Add a `## Threat Model` (or `## N. Security "
                f"Model`) section enumerating the explicit attacker "
                f"capabilities (chain reorg, mempool replay, frontrunning, "
                f"race conditions, exhausted plasma, hostile pillar) and "
                f"which ABI methods are defended against each."
            ),
            "line_hint": 1,
            "source_file": str(spec_path),
        }
    ]


def _check_missing_test_vectors(spec_path: Path, source: str) -> list[dict]:
    """Flag specs that define ABI methods but no test vectors / examples.

    Test vectors are the highest-leverage spec quality check — one good
    vector per method makes implementations across N SDKs deterministic
    instead of guesswork. The PTLC SDK rollout produced 3 wrong addresses
    and 5 wrong field names; vectors would have caught all of them at
    implementation time.
    """
    abi_count = _count_abi_methods(source)
    if abi_count == 0:
        return []
    if _find_section_with_title(source, _TEST_VECTOR_TITLES) is not None:
        return []
    spec_name = _spec_name_from_path(spec_path)
    return [
        {
            "category": "missing_test_vectors",
            "severity": "high",
            "title": f"{spec_name}: no test vectors for {abi_count} ABI methods",
            "description": (
                f"WHAT: {spec_name} defines {abi_count} ABI method(s) but "
                f"has no Test Vectors / Conformance Tests / Reference "
                f"Vectors / Examples section. "
                f"SO WHAT: Without machine-checkable input/output pairs "
                f"every SDK implementation guesses encoding, every CLI "
                f"guesses parameter order, every wallet guesses error "
                f"responses. The PTLC SDK rollout shipped 3 wrong contract "
                f"addresses and 5 wrong field names that test vectors "
                f"would have caught at implementation time. "
                f"NOW WHAT: Add at least one test vector per ABI method to "
                f"a `## Test Vectors` (or `## N. Conformance Tests`) "
                f"section. Format: `Input: 0x{{hex}} -> Expected output: "
                f"0x{{hex}}` so the vectors are mechanically verifiable "
                f"by every implementation."
            ),
            "line_hint": 1,
            "source_file": str(spec_path),
        }
    ]


def _check_untestable_claims(spec_path: Path, source: str) -> list[dict]:
    """Flag vague language inside ABI / method definition contexts.

    Looks for untestable phrases (`reasonable`, `appropriate`,
    `sufficiently`, etc.) that appear inside a method-definition section.
    Top-level prose vagueness is allowed because it's the rationale, not
    the contract — it's only flagged inside contexts an implementer would
    have to translate into a test.
    """
    findings: list[dict] = []
    headings = _iter_headings(source)
    if not headings:
        return findings

    # Build (start, end, title) ranges for sections that look like ABI /
    # method specifications. We only check vagueness inside these ranges.
    method_section_re = re.compile(
        r"\b(method|abi|contract|spec|interface|operations?)\b", re.IGNORECASE
    )
    method_ranges: list[tuple[int, int, str, int]] = []
    lines = source.split("\n")
    for i, (line_no, _level, title) in enumerate(headings):
        if not method_section_re.search(title):
            continue
        next_line = headings[i + 1][0] if i + 1 < len(headings) else len(lines) + 1
        method_ranges.append((line_no, next_line, title, line_no))

    if not method_ranges:
        return findings

    spec_name = _spec_name_from_path(spec_path)
    seen_per_section: set[tuple[str, str]] = set()

    for start, end, title, _ in method_ranges:
        section_text_lines = lines[start - 1 : end - 1]
        for offset, line in enumerate(section_text_lines):
            line_lower = line.lower()
            for phrase in _UNTESTABLE_PHRASES:
                if re.search(rf"\b{re.escape(phrase)}\b", line_lower):
                    key = (title, phrase)
                    if key in seen_per_section:
                        continue
                    seen_per_section.add(key)
                    line_no = start + offset
                    findings.append(
                        {
                            "category": "untestable_claim",
                            "severity": "medium",
                            "title": (f'{spec_name} {title}: untestable language "{phrase}"'),
                            "description": (
                                f"WHAT: Section '{title}' line {line_no} "
                                f"contains untestable language "
                                f'("{phrase}"). '
                                f"SO WHAT: An implementer reading this "
                                f"can't write a test that proves the "
                                f"spec is satisfied. The spec is "
                                f"technically silent on the actual "
                                f"behavior, so each SDK guesses. "
                                f"NOW WHAT: Replace the vague phrase "
                                f"with a numeric threshold, an explicit "
                                f"error condition, or a precise "
                                f"predicate the test suite can verify."
                            ),
                            "line_hint": line_no,
                            "source_file": str(spec_path),
                        }
                    )
                    break  # one finding per section per phrase
    return findings


def _check_stale_cross_refs(spec_path: Path, source: str, all_specs: set[str]) -> list[dict]:
    """Flag markdown links to spec files that don't exist in the corpus.

    Pattern: `[label](../OtherSpec/file.md)` or `[label](Foo/bar.md)`.
    Only checks links whose target ends in `.md` and is a relative path
    (not an external URL). Verifies the target resolves either against
    the absolute corpus root or relative to the source file's directory.
    """
    findings: list[dict] = []
    md_link_re = re.compile(r"\[([^\]]+)\]\(([^)]+\.md)(?:#[^)]*)?\)")
    lines = source.split("\n")
    spec_name = _spec_name_from_path(spec_path)

    seen: set[str] = set()
    for i, line in enumerate(lines, start=1):
        for match in md_link_re.finditer(line):
            target = match.group(2).strip()
            # Skip absolute URLs
            if target.startswith(("http://", "https://", "//")):
                continue
            if target in seen:
                continue
            seen.add(target)

            # Resolve the target relative to the source file's parent
            try:
                resolved = (spec_path.parent / target).resolve()
            except (OSError, RuntimeError):
                continue

            if resolved.exists():
                continue

            # Also try resolving against any known spec in the corpus
            target_basename = Path(target).name
            corpus_match = any(Path(rel).name == target_basename for rel in all_specs)
            if corpus_match:
                continue

            findings.append(
                {
                    "category": "stale_cross_ref",
                    "severity": "medium",
                    "title": (f"{spec_name}: broken cross-reference to {target}"),
                    "description": (
                        f"WHAT: {spec_name} line {i} references "
                        f"`{target}` which does not exist in the spec "
                        f"corpus. "
                        f"SO WHAT: Either the referenced spec was renamed "
                        f"or removed and this spec wasn't updated, or the "
                        f"reference is aspirational and points at a spec "
                        f"that hasn't been written. Either way, an "
                        f"implementer following the link hits a dead end. "
                        f"NOW WHAT: Either fix the path, remove the "
                        f"reference, or create the target spec."
                    ),
                    "line_hint": i,
                    "source_file": str(spec_path),
                }
            )
    return findings


def _check_boundary_conditions(spec_path: Path, source: str) -> list[dict]:
    """Flag ABI methods with amount/deadline params but no boundary semantics.

    Specifically: walk every code-block function signature, look at parameter
    names that match _BOUNDARY_PARAM_NAMES, then check whether the prose in
    the same section mentions any of _BOUNDARY_KEYWORDS. If not, the spec
    is silent on what happens at the edge.
    """
    findings: list[dict] = []
    headings = _iter_headings(source)
    if not headings:
        return findings

    spec_name = _spec_name_from_path(spec_path)
    lines = source.split("\n")
    func_sig_re = re.compile(r"\bfunc\s+(?:\([^)]+\)\s+)?(\w+)\s*\(([^)]*)\)", re.MULTILINE)

    # Walk top-level sections; only consider sections that look like
    # method/contract specifications.
    method_section_re = re.compile(
        r"\b(method|abi|contract|specification|operation|interface)\b",
        re.IGNORECASE,
    )

    seen_methods: set[str] = set()
    for i, (line_no, _level, title) in enumerate(headings):
        if not method_section_re.search(title):
            continue
        next_line = headings[i + 1][0] if i + 1 < len(headings) else len(lines) + 1
        section_text = "\n".join(lines[line_no - 1 : next_line - 1])
        has_boundary_clause = bool(_BOUNDARY_KEYWORDS.search(section_text))

        for match in func_sig_re.finditer(section_text):
            method_name = match.group(1)
            params_str = match.group(2)
            if method_name in seen_methods:
                continue
            if not _BOUNDARY_PARAM_NAMES.search(params_str):
                continue
            seen_methods.add(method_name)
            if has_boundary_clause:
                continue

            param_match = _BOUNDARY_PARAM_NAMES.search(params_str)
            param_name = param_match.group(0) if param_match else "amount"

            findings.append(
                {
                    "category": "missing_boundary_condition",
                    "severity": "high",
                    "title": (
                        f"{spec_name}.{method_name}: undefined behavior at {param_name} boundary"
                    ),
                    "description": (
                        f"WHAT: Method `{method_name}` in {spec_name} has "
                        f"a `{param_name}` parameter but the surrounding "
                        f"section doesn't define behavior at the boundary "
                        f"(zero / max / exactly-at-deadline). "
                        f"SO WHAT: Implementers each pick a convention. "
                        f"Two implementations may disagree on whether "
                        f"`expiration == now` means expired or "
                        f"still-valid, which becomes a fund-loss bug at "
                        f"the second of expiry. "
                        f"NOW WHAT: Add an explicit boundary clause: "
                        f"`expiration is exclusive — a reclaim at exactly "
                        f"expiration is rejected` (or whatever the right "
                        f"answer is). Use words like 'inclusive', "
                        f"'exclusive', 'strict inequality', '>=' / '<', "
                        f"or 'exactly at' so the test suite can verify."
                    ),
                    "line_hint": line_no,
                    "source_file": str(spec_path),
                }
            )
    return findings


def _check_underspecified_errors(spec_path: Path, source: str) -> list[dict]:
    """Flag specs that define state-mutating methods but no error enumeration.

    A spec must enumerate failure modes for every method that mutates
    state, otherwise each SDK invents its own error names + codes and
    end-users see different error messages depending on which client
    they used. The v0.2.23 audit found discarded errors at
    `bridge.go:259-261` of exactly this class — no spec authority on
    what errors should look like meant the implementation discarded them.
    """
    if not _has_state_mutating_methods(source):
        return []
    if _find_section_with_title(source, _ERRORS_TITLES) is not None:
        return []

    spec_name = _spec_name_from_path(spec_path)
    return [
        {
            "category": "underspecified_errors",
            "severity": "high",
            "title": f"{spec_name}: no enumerated error conditions",
            "description": (
                f"WHAT: {spec_name} defines state-mutating ABI methods "
                f"but has no `## Errors` / `## Error Returns` / "
                f"`## Failure Modes` section. "
                f"SO WHAT: Each implementation invents its own error "
                f"taxonomy, error names drift across SDKs, end-users see "
                f"different error messages depending on which client they "
                f"used. Worse, untested error paths often hide real "
                f"security issues — the v0.2.23 audit found discarded "
                f"errors at bridge.go:259-261 of exactly this class. "
                f"NOW WHAT: Add an `## Errors` subsection listing every "
                f"failure mode with a stable error code, what triggers "
                f"it, and the recommended client behavior. The "
                f"`vm/constants/errors.go` file in go-zenon is the "
                f"reference style for the codes themselves."
            ),
            "line_hint": 1,
            "source_file": str(spec_path),
        }
    ]


# ---------------------------------------------------------------------------
# Aggregator + orchestrator
# ---------------------------------------------------------------------------


def audit_spec(spec_path: Path, all_specs: set[str]) -> list[dict]:
    """Run **file-level** audit checks on a single spec file.

    File-level checks are ones whose findings are pinned to a specific
    line in a specific file: cross-reference resolution, untestable
    language inside an ABI section, boundary conditions on individual
    method signatures.

    The dir-level checks (missing threat model, missing test vectors,
    missing errors) are NOT run here — they're handled by
    ``audit_spec_dir`` which sees the whole directory and fires once
    per logical spec, not once per file. This is the v0.2.23 lesson
    applied: per-contract checks should run once on the canonical
    file, not on every file in the directory.

    Args:
        spec_path: Absolute path to a markdown spec file.
        all_specs: Set of relative paths of every spec file in the corpus,
            used by the cross-reference checker to detect broken links.

    Returns:
        Aggregated list of finding dicts. Each dict has keys ``category``,
        ``severity``, ``title``, ``description``, ``line_hint``, and
        ``source_file``.
    """
    source = _read_spec(spec_path)
    if not source:
        return []
    findings: list[dict] = []
    findings.extend(_check_untestable_claims(spec_path, source))
    findings.extend(_check_stale_cross_refs(spec_path, source, all_specs))
    findings.extend(_check_boundary_conditions(spec_path, source))
    return findings


def audit_spec_dir(spec_dir: Path, spec_files: list[Path]) -> list[dict]:
    """Run **dir-level** audit checks once per spec directory.

    Picks the "canonical" file (preferring v2 / latest version, then the
    file whose name matches the directory, then the largest file) and
    runs the missing-threat-model / missing-test-vectors / missing-errors
    checks against the concatenated source of every file in the
    directory. This ensures PTLC v1 + PTLC v2 don't double-fire the same
    finding twice with different source paths.
    """
    if not spec_files:
        return []
    canonical = _pick_canonical_spec_file(spec_dir, spec_files)
    if canonical is None:
        return []

    # Concatenate every file in the dir so checks like "is there a
    # threat model anywhere in this spec" see the whole picture.
    combined_source = "\n\n".join(_read_spec(f) for f in spec_files if f.is_file())
    if not combined_source:
        return []

    findings: list[dict] = []
    findings.extend(_check_missing_threat_model(canonical, combined_source))
    findings.extend(_check_missing_test_vectors(canonical, combined_source))
    findings.extend(_check_underspecified_errors(canonical, combined_source))
    return findings


def _pick_canonical_spec_file(spec_dir: Path, spec_files: list[Path]) -> Path | None:
    """Pick the file that should carry the dir-level findings.

    Preference order:
    1. A file with ``_v{N}`` suffix where N is highest (e.g. ``ptlc_spec_v2.md``)
    2. A file whose name matches the directory name (case-insensitive,
       normalised) — e.g. ``Bitcoin-SPV/bitcoin_spv_spec.md``
    3. The largest file by size
    4. The first file alphabetically
    """
    if not spec_files:
        return None

    # 1. Highest version suffix
    versioned: list[tuple[int, Path]] = []
    for f in spec_files:
        match = re.search(r"_v(\d+)\.md$", f.name, re.IGNORECASE)
        if match:
            versioned.append((int(match.group(1)), f))
    if versioned:
        return max(versioned, key=lambda x: x[0])[1]

    # 2. Name matching the directory
    dir_norm = re.sub(r"[\s_-]+", "", spec_dir.name).lower()
    for f in spec_files:
        stem_norm = re.sub(r"[\s_-]+", "", f.stem).lower()
        if dir_norm in stem_norm or stem_norm in dir_norm:
            return f

    # 3. Largest by size
    try:
        return max(spec_files, key=lambda f: f.stat().st_size)
    except OSError:
        return sorted(spec_files)[0]


def _discover_spec_files(specs_dir: Path) -> list[Path]:
    """Return every markdown spec file under the corpus root.

    Includes both nested specs (``PTLC/ptlc_spec.md``) and top-level
    standalone specs (``GALV_spec_draft.md``). Excludes ``README.md``
    files since those are corpus-level navigation, not specs.
    """
    if not specs_dir.is_dir():
        return []
    out: list[Path] = []
    for md in sorted(specs_dir.rglob("*.md")):
        if md.name.lower() == "readme.md":
            continue
        out.append(md)
    return out


def audit_all_specs(
    specs_dir: Path | None = None,
) -> dict:
    """Run audit checks across the entire spec corpus.

    Args:
        specs_dir: Override for the corpus root. Defaults to
            ``knowledge/developer-commons/docs/specs`` under the workspace.

    Returns:
        Dict with keys ``specs_scanned``, ``total_findings``, ``by_severity``,
        ``findings`` (per-spec dict), and ``summary`` (a single
        WHAT/SO WHAT/NOW WHAT string suitable for the evidence table).
    """
    if specs_dir is None:
        specs_dir = SPECS_DIR

    spec_files = _discover_spec_files(specs_dir)
    if not spec_files:
        return {
            "specs_scanned": 0,
            "total_findings": 0,
            "by_severity": {"critical": 0, "high": 0, "medium": 0, "low": 0},
            "findings": {},
            "summary": (
                "WHAT: spec_audit found no spec files to scan. "
                "SO WHAT: knowledge/developer-commons is not present in this "
                "workspace. NOW WHAT: clone TminusZ/zenon-developer-commons "
                "into knowledge/developer-commons or set ZENON_WORKSPACE_ROOT "
                "to a directory that contains it."
            ),
        }

    # Build the set of relative spec paths once for the cross-ref check
    all_specs_set = {str(p.relative_to(specs_dir)) for p in spec_files}

    # Group spec files by their parent directory so dir-level checks run
    # once per logical spec, not once per file. Top-level standalone
    # files (e.g. ``GALV_spec_draft.md``) get their own pseudo-group.
    grouped: dict[Path, list[Path]] = {}
    for spec_path in spec_files:
        parent = spec_path.parent
        # Treat any file directly inside the specs root as its own group
        # (it's a standalone spec, not a multi-file spec dir)
        if parent == specs_dir:
            grouped[spec_path] = [spec_path]
        else:
            grouped.setdefault(parent, []).append(spec_path)

    per_spec_findings: dict[str, list[dict]] = {}
    by_severity = {"critical": 0, "high": 0, "medium": 0, "low": 0}
    total = 0

    # File-level checks: run on every spec file individually
    for spec_path in spec_files:
        findings = audit_spec(spec_path, all_specs_set)
        if not findings:
            continue
        spec_key = _spec_name_from_path(spec_path)
        per_spec_findings.setdefault(spec_key, []).extend(findings)
        for f in findings:
            total += 1
            sev = f.get("severity", "low")
            by_severity[sev] = by_severity.get(sev, 0) + 1

    # Dir-level checks: run once per spec directory, on the canonical file
    for spec_dir, files in grouped.items():
        # If the "dir" is actually a file (top-level standalone spec),
        # treat the file itself as the spec_dir for naming purposes.
        if spec_dir.is_file():
            findings = audit_spec_dir(spec_dir.parent, files)
            spec_key = spec_dir.stem
        else:
            findings = audit_spec_dir(spec_dir, files)
            spec_key = spec_dir.name
        if not findings:
            continue
        per_spec_findings.setdefault(spec_key, []).extend(findings)
        for f in findings:
            total += 1
            sev = f.get("severity", "low")
            by_severity[sev] = by_severity.get(sev, 0) + 1

    summary = _build_audit_summary(len(spec_files), total, by_severity)

    return {
        "specs_scanned": len(spec_files),
        "total_findings": total,
        "by_severity": by_severity,
        "findings": per_spec_findings,
        "summary": summary,
    }


def _build_audit_summary(specs_scanned: int, total: int, by_severity: dict[str, int]) -> str:
    """Build the WHAT/SO WHAT/NOW WHAT summary persisted alongside findings."""
    if total == 0:
        return (
            f"WHAT: spec_audit scanned {specs_scanned} TminusZ specs and "
            f"found zero structural quality gaps. "
            f"SO WHAT: every spec in the corpus has a threat model section, "
            f"test vectors for its ABI methods, no untestable language, no "
            f"stale cross-references, and explicit boundary + error semantics. "
            f"NOW WHAT: nothing — the corpus is currently passing all "
            f"automated quality checks."
        )
    crit = by_severity.get("critical", 0)
    high = by_severity.get("high", 0)
    if crit > 0:
        sev_blurb = f"{crit} CRITICAL and {high} HIGH severity gaps"
    elif high > 0:
        sev_blurb = f"{high} HIGH severity gaps"
    else:
        sev_blurb = f"{total} medium-severity gaps"
    return (
        f"WHAT: spec_audit scanned {specs_scanned} TminusZ specs and found "
        f"{total} structural quality gaps ({sev_blurb}). "
        f"SO WHAT: each gap is a place where an implementer would have to "
        f"guess, and guessing is exactly how the PTLC SDK rollout produced "
        f"the wrong field names and wrong contract addresses that ate weeks "
        f"of /verify cycles. NOW WHAT: review the per-finding rows in the "
        f"evidence table (engine='spec_audit') and the paste-ready issue "
        f"files in data/contributions/tminusz/spec_audit/."
    )


# ---------------------------------------------------------------------------
# Persistence
# ---------------------------------------------------------------------------


def persist_audit_findings(
    results: dict,
    *,
    db_path: str = DEFAULT_DB,
) -> int:
    """Write every audit finding to the evidence table with full provenance.

    Mirrors ``adversarial_reviewer.persist_static_findings``: pulls the
    developer-commons HEAD once per persist call (so every finding gets the
    same source_commit), builds a clickable GitHub permalink for each
    finding, and persists via the canonical ``persist_finding`` helper.
    Adds a final summary row at confidence 0.85 so the War Room can pick
    up "spec_audit found N gaps" without scanning every per-finding row.
    """
    count = 0

    # Resolve developer-commons HEAD once per scan, not per finding.
    dc_commit = ""
    try:
        from core.git_cache import get_repo_head
        from core.workspace import workspace_repo

        dc_path = workspace_repo("knowledge/developer-commons")
        if dc_path is not None:
            dc_commit = get_repo_head(str(dc_path)) or ""
    except Exception as exc:  # pragma: no cover - graceful degrade
        logger.debug("Could not resolve developer-commons HEAD: %s", exc)

    severity_to_confidence = {
        "critical": 0.95,
        "high": 0.85,
        "medium": 0.70,
        "low": 0.55,
    }

    for spec_name, findings in results.get("findings", {}).items():
        for f in findings:
            line_hint = f.get("line_hint", 0) or 0
            file_path = f.get("source_file", "") or ""
            verification_url = _build_specs_url(file_path, line_hint, dc_commit)
            severity = f.get("severity", "medium")
            confidence = severity_to_confidence.get(severity, 0.70)

            persist_finding(
                db_path=db_path,
                domain="development",
                engine="spec_audit",
                evidence_type=f"spec_{f.get('category', 'gap')}",
                finding=f.get("description", ""),
                confidence=confidence,
                raw_data={
                    "spec_name": spec_name,
                    "category": f.get("category"),
                    "severity": severity,
                    "title": f.get("title"),
                    "line_hint": line_hint,
                },
                source_repo="knowledge/developer-commons",
                source_file=file_path or None,
                source_commit=dc_commit or None,
                source_line=line_hint or None,
                verification_url=verification_url,
            )
            count += 1

    # Persist the corpus-level summary row.
    persist_finding(
        db_path=db_path,
        domain="development",
        engine="spec_audit",
        evidence_type="spec_audit_summary",
        finding=results.get("summary", ""),
        confidence=0.85,
        raw_data={
            "specs_scanned": results.get("specs_scanned", 0),
            "total_findings": results.get("total_findings", 0),
            "by_severity": results.get("by_severity", {}),
        },
        source_repo="knowledge/developer-commons",
        source_commit=dc_commit or None,
    )
    count += 1

    logger.info(
        "spec_audit: persisted %d audit findings (commit=%s)",
        count,
        dc_commit[:8] if dc_commit else "unknown",
    )
    return count


# ---------------------------------------------------------------------------
# Auto-discoverable scheduler entry point
# ---------------------------------------------------------------------------


def run_spec_audit(
    *,
    db_path: str = DEFAULT_DB,
    specs_dir: Path | None = None,
    enable_contributions: bool = True,
    llm_call=None,  # accepted for scheduler signature compat, intentionally unused
) -> dict:
    """Auto-discoverable entry point the scheduler picks up.

    Args:
        db_path: Path to the engine SQLite database.
        specs_dir: Override for the spec corpus root (mainly for tests).
        enable_contributions: When True, format every finding as a paste-
            ready GitHub issue body in ``data/contributions/tminusz/
            spec_audit/`` via the contribution domain. Tests pass False
            to keep the filesystem clean.
        llm_call: Unused — accepted so the scheduler can call this engine
            with the same signature as the LLM-driven engines.

    Returns:
        The full results dict from ``audit_all_specs``, augmented with a
        ``persisted`` count and (when enabled) a
        ``contribution_files_written`` count.
    """
    results = audit_all_specs(specs_dir=specs_dir)
    persisted = persist_audit_findings(results, db_path=db_path)
    results["persisted"] = persisted

    contribution_count = 0
    if enable_contributions and results.get("total_findings", 0) > 0:
        try:
            # v0.6.9: formatter moved to core to satisfy Rule 2 (engines
            # must not import from peer engines). Both spec_audit and
            # tminusz_contributor now import from core.
            from core.spec_audit_contributions import (
                format_spec_audit_findings_as_issues,
            )

            contribution_count = format_spec_audit_findings_as_issues(results)
        except ImportError:
            # Core should always be importable, but degrade gracefully.
            logger.debug(
                "format_spec_audit_findings_as_issues not available — "
                "skipping contribution file generation"
            )
        except Exception as exc:
            logger.warning("contribution file generation failed: %s", exc)
    results["contribution_files_written"] = contribution_count

    return results
