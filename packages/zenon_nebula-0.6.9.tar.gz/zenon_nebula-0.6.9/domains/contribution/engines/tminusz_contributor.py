# SPDX-License-Identifier: MIT
"""
TminusZContributor -- Contributes back to TminusZ/developer-commons repo.

After implementing a spec:
- Extracts test vectors from Go tests
- Formats as test_vectors.json per contract
- Tracks which specs have been contributed back
- Generates implementation notes and errata
"""

import json
import logging
import re
from pathlib import Path

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
from core.workspace import workspace_root_or_nebula

ZENON_WORKSPACE = workspace_root_or_nebula()

GO_ZENON_PATHS = [
    ZENON_WORKSPACE / "core" / "go-zenon",
    ZENON_WORKSPACE / "network" / "go-zenon",
]

SPECS_DIR = ZENON_WORKSPACE / "knowledge" / "developer-commons" / "docs" / "specs"

# Pattern to extract test vector data from Go test files
GO_TEST_VECTOR_PATTERN = re.compile(
    r"(?:testCase|testVector|tc)\s*(?::=|=)\s*(?:struct\s*\{[^}]*\}\s*\{|\{)\s*"
    r"([^}]+)\}",
    re.DOTALL,
)

# Pattern to extract test table entries
GO_TABLE_TEST_PATTERN = re.compile(
    r'\{\s*name:\s*"([^"]+)"[^}]*\}',
    re.DOTALL,
)

# Pattern to extract hardcoded test values (addresses, hashes, amounts)
GO_TEST_VALUE_PATTERN = re.compile(
    r'(?:expected|want|result)\w*\s*(?::=|=)\s*(?:"([^"]+)"|\b(\d+)\b)',
)


def _find_test_files(contract_name: str) -> list[Path]:
    """Find Go test files related to a contract."""
    files = []
    for go_zenon in GO_ZENON_PATHS:
        if not go_zenon.is_dir():
            continue
        for test_file in go_zenon.rglob("*_test.go"):
            try:
                content = test_file.read_text(encoding="utf-8")
                if contract_name in content.lower():
                    files.append(test_file)
            except (OSError, UnicodeDecodeError):
                continue
    return files


def extract_test_vectors(contract_name: str) -> list[dict]:
    """Extract test vectors from Go test files for a contract.

    Returns list of test vector dicts with name, inputs, expected outputs.
    """
    test_files = _find_test_files(contract_name)
    vectors = []

    for test_file in test_files:
        try:
            content = test_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        # Extract table test entries
        for match in GO_TABLE_TEST_PATTERN.finditer(content):
            vectors.append(
                {
                    "name": match.group(1),
                    "source_file": str(test_file.name),
                    "contract": contract_name,
                }
            )

        # Extract standalone test values
        for match in GO_TEST_VALUE_PATTERN.finditer(content):
            value = match.group(1) or match.group(2)
            if (
                value
                and contract_name in content[max(0, match.start() - 200) : match.end()].lower()
            ):
                vectors.append(
                    {
                        "name": f"test_value_{len(vectors)}",
                        "expected_value": value,
                        "source_file": str(test_file.name),
                        "contract": contract_name,
                    }
                )

    return vectors


def format_test_vectors_json(
    contract_name: str,
    vectors: list[dict],
) -> str:
    """Format test vectors as a JSON string suitable for test_vectors.json."""
    output = {
        "contract": contract_name,
        "version": "1.0",
        "vectors": vectors,
    }
    return json.dumps(output, indent=2)


def get_spec_dir(contract_name: str) -> Path | None:
    """Find the spec directory for a contract in developer-commons."""
    if not SPECS_DIR.is_dir():
        return None

    # Try exact match first
    for spec_dir in SPECS_DIR.iterdir():
        if not spec_dir.is_dir():
            continue
        normalized = spec_dir.name.lower().replace("-", "_").replace(" ", "_")
        # Handle CamelCase
        normalized_camel = re.sub(
            r"(?<=[a-z])(?=[A-Z])",
            "_",
            spec_dir.name,
        ).lower()

        if contract_name in (normalized, normalized_camel, spec_dir.name.lower()):
            return spec_dir

    return None


def generate_implementation_notes(contract_name: str) -> dict:
    """Generate implementation notes for a contract.

    Returns dict with notes about the Go implementation that
    would be useful for other implementors.
    """
    notes = {
        "contract": contract_name,
        "implementation_language": "go",
        "notes": [],
        "errata": [],
    }

    for go_zenon in GO_ZENON_PATHS:
        impl_file = go_zenon / "vm" / "embedded" / "implementation" / f"{contract_name}.go"
        if not impl_file.is_file():
            continue

        try:
            content = impl_file.read_text(encoding="utf-8")
        except (OSError, UnicodeDecodeError):
            continue

        lines = content.split("\n")

        # Note special patterns
        for i, line in enumerate(lines, start=1):
            # DealWithErr usage
            if "DealWithErr" in line:
                notes["notes"].append(
                    {
                        "line": i,
                        "type": "error_handling",
                        "detail": "Uses DealWithErr pattern for error handling",
                    }
                )
            # TimeChallenge or time-based logic
            if "TimeChallenge" in line or "momentum.Timestamp" in line:
                notes["notes"].append(
                    {
                        "line": i,
                        "type": "time_dependent",
                        "detail": "Contains time-dependent logic",
                    }
                )
            # Cross-contract calls
            if "GetContract" in line or "CallContract" in line:
                notes["notes"].append(
                    {
                        "line": i,
                        "type": "cross_contract",
                        "detail": "Makes cross-contract call",
                    }
                )

    return notes


def check_contribution_status(contract_name: str) -> dict:
    """Check whether a spec has test vectors and impl notes contributed.

    Returns dict with contribution status.
    """
    spec_dir = get_spec_dir(contract_name)
    status = {
        "contract": contract_name,
        "spec_dir_found": spec_dir is not None,
        "has_test_vectors": False,
        "has_impl_notes": False,
    }

    if spec_dir is None:
        return status

    # Check for test_vectors.json
    tv_path = spec_dir / "test_vectors.json"
    status["has_test_vectors"] = tv_path.is_file()

    # Check for implementation_notes.md or similar
    for _note_file in spec_dir.glob("*impl*"):
        status["has_impl_notes"] = True
        break
    for _note_file in spec_dir.glob("*notes*"):
        status["has_impl_notes"] = True
        break

    return status


def check_all_contributions(
    contract_names: list[str] | None = None,
) -> list[dict]:
    """Check contribution status for all contracts."""
    if contract_names is None:
        contract_names = [
            "accelerator",
            "bridge",
            "htlc",
            "liquidity",
            "pillar",
            "plasma",
            "sentinel",
            "stake",
            "swap",
            "token",
        ]
    return [check_contribution_status(name) for name in contract_names]


def contribute_test_vectors(
    contract_name: str,
    *,
    dry_run: bool = True,
) -> dict:
    """Extract and optionally write test vectors for a contract.

    Args:
        contract_name: Name of the contract.
        dry_run: If True, only extract -- do not write files.

    Returns:
        Dict with vectors extracted and write status.
    """
    vectors = extract_test_vectors(contract_name)
    result = {
        "contract": contract_name,
        "vectors_extracted": len(vectors),
        "written": False,
    }

    if not vectors:
        return result

    json_content = format_test_vectors_json(contract_name, vectors)
    result["json_preview"] = json_content[:1000]

    if not dry_run:
        spec_dir = get_spec_dir(contract_name)
        if spec_dir:
            output_path = spec_dir / "test_vectors.json"
            try:
                output_path.write_text(json_content, encoding="utf-8")
                result["written"] = True
                result["output_path"] = str(output_path)
            except OSError as exc:
                result["write_error"] = str(exc)

    return result


# ---------------------------------------------------------------------------
# spec_audit -> ready-to-paste GitHub issue formatter
# ---------------------------------------------------------------------------
#
# The formatter itself lives in ``core/spec_audit_contributions.py`` so the
# ``spec_audit`` engine (in the development domain) can use it without
# importing across engine boundaries — that was a Rule 2 architecture
# violation present since v0.3.0. v0.6.9 extracted it to core.
#
# We keep the names re-exported here (``SPEC_AUDIT_CONTRIBUTIONS_DIR`` and
# ``format_spec_audit_findings_as_issues``) because existing tests
# (``tests/test_spec_audit.py``) and any downstream callers monkeypatch the
# contribution-engine module attribute to redirect output to a tmp_path.
# The re-export preserves that test contract without the cross-engine
# import.

from core.spec_audit_contributions import (  # noqa: F401  (re-export)
    SPEC_AUDIT_CONTRIBUTIONS_DIR,
    format_spec_audit_findings_as_issues,
)
