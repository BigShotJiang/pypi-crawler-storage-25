# SPDX-License-Identifier: MIT
"""Self-questioning loop — LLM-driven hypothesis follow-up generator (task #45).

Pattern: orchestrator-workers. Every cycle the engine picks one
high-confidence-but-unfinalized hypothesis from the ``hypotheses``
table, gathers its supporting evidence, and asks the LLM to propose
three follow-up investigations that would either harden or refute it.
Each proposal must name a specific file path inside a workspace repo.
Proposals that name a path which doesn't exist on disk are dropped by
the hallucination guard. Survivors get persisted as findings tagged
``self_question`` with a 10-cycle deadline embedded in ``raw_data``,
linked back to the parent hypothesis via ``supports_hypothesis``.

This is a true agent loop in the "Building Effective Agents" sense:
Nebula reads its own state, proposes actions to itself, filters the
proposals against reality, and writes the survivors back into the
evidence store where other engines can consume them. The loop is
deterministic in its filtering (hallucination guard is pure-function
file-exists check) so a garbage LLM response always results in zero
new findings, never in hallucinated constants being persisted.

Confidence is deliberately capped at 0.4 — a follow-up question is
speculative, not an answer. Other engines promote it to a real finding
by actually running the investigation and producing corroborating
evidence.

Why "self-questioning" and not "self-answering": the LLM only proposes
*where to look*, never *what the answer is*. The answer comes from
deterministic engines (architecture_analyzer, spec_verifier, etc.)
actually reading the pointed-at files. This keeps the anti-funnel
invariant: the LLM cannot bias findings by claiming facts; it can only
bias *which files get investigated more carefully*.
"""

from __future__ import annotations

import json
import logging
import sqlite3
from pathlib import Path
from typing import Any

from core.llm_provider import call_llm
from core.persistence import connect
from core.persistence.findings import persist_finding
from core.workspace import workspace_repo, workspace_root

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# Confidence band for hypotheses eligible for follow-up generation.
# Below the floor: too weak to spend LLM budget on.
# Above the ceiling: already strong, hardening is the hardener's job.
HYPOTHESIS_CONFIDENCE_FLOOR = 0.60
HYPOTHESIS_CONFIDENCE_CEILING = 0.85

# Maximum supporting evidence rows to include in the LLM prompt.
# Cap keeps the prompt bounded and cheap.
MAX_EVIDENCE_ROWS = 5

# Maximum follow-up proposals to request from the LLM.
MAX_PROPOSALS = 3

# Follow-up findings are speculative (they're questions, not answers).
FOLLOWUP_CONFIDENCE = 0.4

# Deadline (in cycles) after which an un-answered follow-up is
# considered stale. Embedded in raw_data so downstream engines can
# honor it; this engine doesn't enforce expiry itself (the hypothesis
# hardener and aspiration sweep handle that).
FOLLOWUP_DEADLINE_CYCLES = 10

# LLM call budget — tight on purpose. Self-questioning is a supporting
# feature, not a core investigation path. It should never dominate
# total LLM spend.
LLM_MAX_TOKENS = 800
LLM_TEMPERATURE = 0.3


def _pick_eligible_hypothesis(db_path: str) -> dict | None:
    """Return one hypothesis to propose follow-ups for, or None.

    Picks the oldest-updated INVESTIGATING hypothesis within the
    confidence band. Oldest-first rotates attention so the loop
    naturally covers every open hypothesis over time instead of
    hammering the same one every cycle.
    """
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            row = conn.execute(
                """
                SELECT id, domain, title, confidence, status, last_updated
                FROM hypotheses
                WHERE status = 'INVESTIGATING'
                  AND confidence >= ?
                  AND confidence <= ?
                ORDER BY COALESCE(last_updated, '1970-01-01') ASC
                LIMIT 1
                """,
                (HYPOTHESIS_CONFIDENCE_FLOOR, HYPOTHESIS_CONFIDENCE_CEILING),
            ).fetchone()
        finally:
            conn.close()
    except sqlite3.Error as exc:
        logger.debug("self_questioning_loop: hypothesis query failed — %s", exc)
        return None
    return dict(row) if row is not None else None


def _gather_evidence(db_path: str, hypothesis_id: str) -> list[dict]:
    """Return up to MAX_EVIDENCE_ROWS supporting the hypothesis.

    Sorted by confidence descending so the LLM sees the strongest
    supporting evidence first. Read-only query against the evidence
    table; never mutates state.
    """
    try:
        conn = connect(db_path)
        conn.row_factory = sqlite3.Row
        try:
            rows = conn.execute(
                """
                SELECT id, engine, evidence_type, finding, confidence,
                       source_repo, source_file, source_line
                FROM evidence
                WHERE supports_hypothesis = ?
                ORDER BY confidence DESC
                LIMIT ?
                """,
                (hypothesis_id, MAX_EVIDENCE_ROWS),
            ).fetchall()
        finally:
            conn.close()
    except sqlite3.Error as exc:
        logger.debug("self_questioning_loop: evidence query failed — %s", exc)
        return []
    return [dict(r) for r in rows]


def _build_prompt(hypothesis: dict, evidence: list[dict]) -> tuple[str, str]:
    """Return (system, prompt) for the follow-up LLM call.

    The prompt gives the LLM the hypothesis, its supporting evidence,
    and a strict JSON output contract. Every proposal must name a
    ``target_repo`` + ``target_file`` that actually exists — the
    hallucination guard enforces this downstream. The system message
    sets tight anti-hallucination rules.
    """
    system = (
        "You are a research assistant helping a code-analysis engine "
        "decide what file to read next. You do NOT answer questions — "
        "you propose where to look for answers. Every proposal must "
        "name a specific file path inside a named repo. Never invent "
        "file paths; only reference paths you are confident exist. If "
        "you cannot name concrete files, return an empty list. Answer "
        "in JSON only."
    )
    evidence_lines = []
    for row in evidence:
        src = ""
        if row.get("source_file"):
            src = f" ({row.get('source_repo', '?')}/{row['source_file']}"
            if row.get("source_line"):
                src += f":{row['source_line']}"
            src += ")"
        evidence_lines.append(
            f"- [{row.get('engine', '?')}] {(row.get('finding') or '')[:200]}{src}"
        )
    if not evidence_lines:
        evidence_lines.append("(no supporting evidence yet)")

    prompt = (
        f"Hypothesis ({hypothesis['domain']}, confidence "
        f"{hypothesis['confidence']:.2f}):\n"
        f"  {hypothesis['title']}\n\n"
        f"Supporting evidence ({len(evidence)} rows):\n" + "\n".join(evidence_lines) + "\n\n"
        f"Propose up to {MAX_PROPOSALS} concrete follow-up investigations "
        "that would either harden or refute this hypothesis. For each "
        "proposal, name a specific file path in a specific repo. Return "
        "JSON with this shape (and nothing else):\n"
        "{\n"
        '  "proposals": [\n'
        '    {"question": "...", "target_repo": "...", '
        '"target_file": "..."},\n'
        "    ...\n"
        "  ]\n"
        "}"
    )
    return system, prompt


def _parse_llm_response(response: dict | None) -> list[dict]:
    """Extract the proposal list from a call_llm response dict.

    call_llm returns {"text": "...", ...} or None. We parse the text
    as JSON and return the "proposals" list. Every parser failure
    returns the empty list — never raises — so upstream just sees
    "no survivors this cycle" and moves on.
    """
    if response is None:
        return []
    text = response.get("text", "") if isinstance(response, dict) else ""
    if not text:
        return []
    try:
        payload = json.loads(text)
    except (ValueError, TypeError):
        logger.debug(
            "self_questioning_loop: LLM response was not JSON (%d chars)",
            len(text),
        )
        return []
    if not isinstance(payload, dict):
        return []
    proposals = payload.get("proposals")
    if not isinstance(proposals, list):
        return []
    out: list[dict] = []
    for item in proposals:
        if len(out) >= MAX_PROPOSALS:
            break
        if not isinstance(item, dict):
            continue
        question = str(item.get("question") or "").strip()
        target_repo = str(item.get("target_repo") or "").strip()
        target_file = str(item.get("target_file") or "").strip()
        if not (question and target_repo and target_file):
            continue
        # Defence against path traversal in the target_file — the
        # workspace helper already rejects absolute paths, but we
        # also refuse ``..`` segments so an LLM can't wander out of
        # the workspace. This is belt-and-braces; core.workspace's
        # workspace_repo already pins the root.
        if target_file.startswith("/") or ".." in Path(target_file).parts:
            continue
        out.append(
            {
                "question": question[:400],
                "target_repo": target_repo[:200],
                "target_file": target_file[:400],
            }
        )
    return out


def _verify_file_exists(target_repo: str, target_file: str) -> Path | None:
    """Return the resolved Path if the target exists, else None.

    Uses core.workspace.workspace_repo to resolve the repo so the
    engine honours ZENON_WORKSPACE_ROOT. A proposal is only kept if
    the named file actually exists on disk — this is the
    hallucination guard for LLM-generated paths.
    """
    try:
        repo_path = workspace_repo(target_repo)
    except (OSError, ValueError) as exc:
        logger.debug(
            "self_questioning_loop: workspace_repo failed for %s — %s",
            target_repo,
            exc,
        )
        return None
    if repo_path is None:
        return None
    candidate = repo_path / target_file
    try:
        if candidate.is_file():
            return candidate
    except OSError:
        # is_file can raise on permission errors, unreadable mounts,
        # etc. Treat unreadable paths as non-existent.
        return None
    return None


def _format_finding(
    hypothesis: dict,
    proposal: dict,
    verified_path: Path,
) -> str:
    """Return the WHAT/SO WHAT/NOW WHAT body for a follow-up finding."""
    return (
        f"WHAT: Self-questioning loop proposed a follow-up for "
        f"hypothesis '{hypothesis['title']}': {proposal['question']}\n\n"
        f"SO WHAT: Investigating {proposal['target_repo']}/"
        f"{proposal['target_file']} could either harden this hypothesis "
        f"toward COMPELLING or refute it. The hypothesis currently sits "
        f"at confidence {hypothesis['confidence']:.2f} — high enough "
        f"that the cost of the follow-up scan is justified, but low "
        f"enough that there's real uncertainty to resolve.\n\n"
        f"NOW WHAT: A downstream engine (architecture_analyzer, "
        f"spec_verifier, adversarial_reviewer, etc.) should read "
        f"{verified_path} and emit a finding that either supports or "
        f"contradicts hypothesis {hypothesis['id']}. This self-question "
        f"finding carries a {FOLLOWUP_DEADLINE_CYCLES}-cycle deadline "
        f"after which it retires whether or not an answer came back."
    )


def run_self_questioning_loop(
    db_path: str = DEFAULT_DB,
    *,
    llm_call=None,
    current_cycle: int | None = None,
) -> dict:
    """Entry point — propose follow-up investigations for one hypothesis.

    Called once per cycle by the autonomous scheduler. Returns a
    summary dict. Never raises; every failure path returns a dict
    with ``findings_persisted=0`` so the scheduler can log + move on.

    Args:
        db_path: SQLite database path (defaults to live engine.db).
        llm_call: Optional injected LLM callable for tests. When None
            the module-level ``call_llm`` is used. Tests pass a
            lambda/Mock that returns a fixed dict.
        current_cycle: Optional current cycle number stamped into
            raw_data for the 10-cycle deadline. Defaults to None
            (deadline still recorded as relative cycles).

    Returns:
        Dict with keys:
            hypothesis_id: the hypothesis we targeted (or None)
            proposals_generated: how many the LLM returned (pre-guard)
            proposals_survived: how many passed hallucination guard
            findings_persisted: how many rows landed in evidence
            workspace_root: str path or None (graceful-degrade signal)
    """
    summary: dict[str, Any] = {
        "hypothesis_id": None,
        "proposals_generated": 0,
        "proposals_survived": 0,
        "findings_persisted": 0,
        "workspace_root": None,
    }
    ws = workspace_root()
    summary["workspace_root"] = str(ws) if ws is not None else None
    if ws is None:
        logger.info(
            "self_questioning_loop: workspace not installed — skipping "
            "LLM call (no way to verify file paths)"
        )
        return summary

    hypothesis = _pick_eligible_hypothesis(db_path)
    if hypothesis is None:
        logger.debug(
            "self_questioning_loop: no eligible hypothesis in band [%.2f, %.2f]",
            HYPOTHESIS_CONFIDENCE_FLOOR,
            HYPOTHESIS_CONFIDENCE_CEILING,
        )
        return summary
    summary["hypothesis_id"] = hypothesis["id"]

    evidence = _gather_evidence(db_path, hypothesis["id"])
    system, prompt = _build_prompt(hypothesis, evidence)

    llm = llm_call if llm_call is not None else call_llm
    try:
        response = llm(
            prompt,
            system=system,
            json_output=True,
            max_tokens=LLM_MAX_TOKENS,
            temperature=LLM_TEMPERATURE,
        )
    except (TypeError, ValueError, RuntimeError) as exc:
        logger.debug("self_questioning_loop: LLM call raised — %s", exc)
        return summary

    proposals = _parse_llm_response(response)
    summary["proposals_generated"] = len(proposals)

    for proposal in proposals:
        verified_path = _verify_file_exists(proposal["target_repo"], proposal["target_file"])
        if verified_path is None:
            logger.debug(
                "self_questioning_loop: hallucination guard rejected %s/%s (path does not exist)",
                proposal["target_repo"],
                proposal["target_file"],
            )
            continue
        summary["proposals_survived"] += 1

        body = _format_finding(hypothesis, proposal, verified_path)
        raw = {
            "hypothesis_id": hypothesis["id"],
            "question": proposal["question"],
            "target_repo": proposal["target_repo"],
            "target_file": proposal["target_file"],
            "deadline_cycles": FOLLOWUP_DEADLINE_CYCLES,
            "opened_at_cycle": current_cycle,
        }
        try:
            row_id = persist_finding(
                db_path=db_path,
                domain="investigation",
                engine="self_questioning_loop",
                evidence_type="self_question",
                finding=body,
                confidence=FOLLOWUP_CONFIDENCE,
                supports_hypothesis=hypothesis["id"],
                source_repo=proposal["target_repo"],
                source_file=proposal["target_file"],
                raw_data=raw,
            )
            if row_id and row_id > 0:
                summary["findings_persisted"] += 1
        except (sqlite3.Error, TypeError, ValueError) as exc:
            logger.debug(
                "self_questioning_loop: persist failed for %s/%s — %s",
                proposal["target_repo"],
                proposal["target_file"],
                exc,
            )

    logger.info(
        "self_questioning_loop: hypothesis=%s proposals=%d survived=%d persisted=%d",
        hypothesis["id"],
        summary["proposals_generated"],
        summary["proposals_survived"],
        summary["findings_persisted"],
    )
    return summary
