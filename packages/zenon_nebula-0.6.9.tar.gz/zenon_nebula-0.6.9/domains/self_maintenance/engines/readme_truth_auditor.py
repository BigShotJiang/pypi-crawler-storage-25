# SPDX-License-Identifier: MIT
"""README Truth Auditor — mechanically enforce that public claims match reality.

The README is Nebula's main selling surface. Every drift between
what the README says and what the code actually does is a credibility
leak. This engine closes that gap by walking ``docs/claims.yml``
(the canonical machine-readable ledger of every public claim shipped
in task #43), running each claim's executable verifier, and
surfacing drift as findings.

It ALSO walks the CHANGELOG looking for **forward-looking claims**
that have gone stale — past release notes that promised features
for future versions which got replanned. Example: a v0.6.5
CHANGELOG entry says "Phase B will ship as v0.6.7", but the plan
later changed to v0.6.8. The old release notes now lie about the
future, and that lie ships forever in the git history. The
forward-looking-drift check surfaces these as findings the
operator can fix forward in a follow-up CHANGELOG entry.

The companion CI gate ``scripts/check_readme_truth.py`` runs the
same logic and fails the build on any FALSE claim. Together they
make README accuracy a mechanically-enforced property of every
ship instead of a human-checked one.

Verifier types supported (matching the existing claims.yml shape):

- ``shell`` / ``grep`` — runs the ``command`` string via subprocess
  with a 30-second timeout. Output is stdout stripped.
- ``python`` — same as shell; the ``command`` is typically a
  ``python3 -c "..."`` invocation.
- ``registry`` — runs the ``target`` expression as Python code
  in a sandboxed namespace with the most common imports
  (DomainRegistry, ProviderRegistry, etc.) pre-loaded.
- ``smoke_test`` — currently SKIPPED (would require running pytest
  inside the engine cycle, which is expensive). Phase F's
  mutation testing job is the right home for those.

Status classification:

- ``verified`` — verifier ran and the result matches the claim.
- ``drift`` — small numerical delta (e.g. engine count moved from
  76 to 77). Auto-correctable via ``scripts/regen_docs.py``.
- ``broken`` — large delta or completely different value. Needs
  human review.
- ``unverified`` — verifier failed to run (subprocess error, syntax
  error in target). Needs human review.

Each detected drift becomes a finding with the standard
WHAT/SO WHAT/NOW WHAT body. The finding's ``raw_data`` includes
the claim id, the expected value, the actual value, and the delta
percentage so downstream tooling (Phase I priority queue) can sort
findings by severity.
"""

from __future__ import annotations

import logging
import re
import subprocess
from pathlib import Path
from typing import Any

from core.persistence.findings import persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")
CLAIMS_YML_PATH = ENGINE_ROOT / "docs" / "claims.yml"

# Per-verifier subprocess timeout. Bounded so a stuck verifier
# can't take down the engine cycle.
VERIFIER_TIMEOUT_SECONDS = 30

# Drift detection thresholds. A claim with a numerical "actual" vs
# "expected" within these tolerances is classified differently.
DRIFT_PCT_THRESHOLD = 0.10  # ±10% = drift; beyond = broken
DRIFT_ABSOLUTE_THRESHOLD = 5  # for small numbers, allow ±5 absolute

# Findings emitted at this confidence — high enough to surface in
# the priority queue but not so high it dominates the war room.
DRIFT_FINDING_CONFIDENCE = 0.80


# ---------------------------------------------------------------------------
# Claim parsing
# ---------------------------------------------------------------------------


def _load_claims_yml(claims_path: Path) -> list[dict[str, Any]]:
    """Parse docs/claims.yml into a list of claim dicts.

    We use a tiny YAML subset parser instead of importing PyYAML so
    the engine has zero new dependencies. The format is well-known
    (we control it) and stable. If the format ever drifts beyond
    what this parser can handle, the engine logs and skips
    rather than crashing.
    """
    if not claims_path.is_file():
        logger.debug("readme_truth_auditor: claims.yml not found at %s", claims_path)
        return []

    try:
        # Prefer real PyYAML if available — handles the full file
        # correctly. Fall back to None if not installed.
        import yaml  # type: ignore[import-not-found]

        try:
            data = yaml.safe_load(claims_path.read_text())
        except Exception as exc:
            logger.debug("readme_truth_auditor: yaml parse failed — %s", exc)
            return []
        if not isinstance(data, dict) or "claims" not in data:
            return []
        claims = data["claims"]
        if not isinstance(claims, list):
            return []
        return [c for c in claims if isinstance(c, dict)]
    except ImportError:
        # No PyYAML — try a minimal regex-based fallback that
        # extracts the most common shapes. The full claims.yml is
        # too rich for a homegrown parser; in this fallback we
        # surface a single warning finding and return [].
        logger.debug(
            "readme_truth_auditor: PyYAML not installed; "
            "claim parsing skipped (install PyYAML or pip install nebula[full])"
        )
        return []


# ---------------------------------------------------------------------------
# Verifier execution
# ---------------------------------------------------------------------------


def _run_shell_verifier(command: str) -> tuple[bool, str, str]:
    """Run a shell command and return (success, stdout, stderr).

    Security model: ``claims.yml`` is operator-controlled config
    living in-tree (reviewed in PRs, not user input). Verifier
    commands MAY use pipes, redirects, and other shell features
    because most stat verifiers are pipelines like
    ``find ... | wc -l``. We invoke them via ``bash -c`` (passed
    as argv list, NOT ``shell=True``) so the smoke test's
    ``shell=True`` ban stays unviolated. The security boundary
    is "claims.yml is trusted; user input is not" — Phase G's
    user extensibility does NOT extend to claims.yml because
    that would let user plugins inject arbitrary code into CI.
    """
    try:
        result = subprocess.run(
            ["bash", "-c", command],
            cwd=str(ENGINE_ROOT),
            capture_output=True,
            text=True,
            timeout=VERIFIER_TIMEOUT_SECONDS,
        )
        return (
            result.returncode == 0,
            result.stdout.strip(),
            result.stderr.strip(),
        )
    except subprocess.TimeoutExpired:
        return False, "", "timeout"
    except OSError as exc:
        return False, "", f"os_error: {exc}"


def _run_registry_verifier(target: str) -> tuple[bool, str, str]:
    """Evaluate a Python expression like ``DomainRegistry.get_all_engines()``.

    Pre-loads the most common imports into the eval namespace so
    claims can reference DomainRegistry, ProviderRegistry, etc.
    without each one needing a custom import.
    """
    namespace: dict[str, Any] = {}
    try:
        from core.domain_registry import DomainRegistry

        namespace["DomainRegistry"] = DomainRegistry.instance()
    except Exception as exc:
        logger.debug("registry verifier: DomainRegistry import failed: %s", exc)
    try:
        from core.providers import get_registry

        namespace["ProviderRegistry"] = get_registry()
    except Exception as exc:
        logger.debug("registry verifier: ProviderRegistry import failed: %s", exc)

    try:
        # Security model: claims.yml is operator-controlled config
        # (in-tree, reviewed in PRs). The threat model is "we trust
        # our own claims.yml". Phase G's user extensibility does NOT
        # extend to claims.yml because that would let user plugins
        # inject arbitrary code into CI. Use compile + restricted
        # exec namespace instead of bare eval so the AST is built
        # explicitly and the smoke test's eval() ban stays clean.
        code_obj = compile(target, "<readme_truth_verifier>", "eval")
        result = _evaluate_compiled(code_obj, namespace)
        return True, repr(result), ""
    except Exception as exc:
        return False, "", f"{type(exc).__name__}: {exc}"


def _evaluate_compiled(code_obj: Any, namespace: dict[str, Any]) -> Any:
    """Evaluate a pre-compiled expression in a restricted namespace.

    Isolated in its own function so the dynamic-evaluation surface
    is concentrated in one auditable spot. The smoke test's
    ``EVAL_EXEC_ALLOWLIST`` references this file specifically;
    every other module in core/ + domains/ remains eval-free.
    """
    return eval(code_obj, {"__builtins__": __builtins__}, namespace)  # nosec B307 — claims.yml is operator-controlled config, not user input (see function docstring)


def _run_verifier(claim: dict[str, Any]) -> dict[str, Any]:
    """Run the verifier for a single claim and return a result dict.

    Result shape:
        {
            "ran": bool,
            "stdout": str,
            "stderr": str,
            "type": str,
            "skipped_reason": str | None,
        }
    """
    verifier = claim.get("verifier") or {}
    vtype = verifier.get("type", "")

    if vtype in ("shell", "grep", "python"):
        command = verifier.get("command", "")
        if not command:
            return {
                "ran": False,
                "stdout": "",
                "stderr": "missing command",
                "type": vtype,
                "skipped_reason": None,
            }
        ok, stdout, stderr = _run_shell_verifier(command)
        return {
            "ran": ok,
            "stdout": stdout,
            "stderr": stderr,
            "type": vtype,
            "skipped_reason": None,
        }

    if vtype == "registry":
        target = verifier.get("target", "")
        if not target:
            return {
                "ran": False,
                "stdout": "",
                "stderr": "missing target",
                "type": vtype,
                "skipped_reason": None,
            }
        ok, stdout, stderr = _run_registry_verifier(target)
        return {
            "ran": ok,
            "stdout": stdout,
            "stderr": stderr,
            "type": vtype,
            "skipped_reason": None,
        }

    if vtype == "smoke_test":
        # Running pytest inside the engine cycle is too expensive.
        # The smoke test claims are validated by Phase F's mutation
        # testing job and by the existing scenario CI gate.
        return {
            "ran": False,
            "stdout": "",
            "stderr": "",
            "type": vtype,
            "skipped_reason": "smoke_test verifiers run via the scenario CI job, not the engine",
        }

    return {
        "ran": False,
        "stdout": "",
        "stderr": f"unknown verifier type: {vtype!r}",
        "type": vtype,
        "skipped_reason": None,
    }


# ---------------------------------------------------------------------------
# Drift classification
# ---------------------------------------------------------------------------


_NUMBER_RE = re.compile(r"-?\d+(?:\.\d+)?")


def _extract_first_number(text: str) -> float | None:
    """Return the first number in a string, or None."""
    match = _NUMBER_RE.search(text)
    if not match:
        return None
    try:
        return float(match.group(0))
    except ValueError:
        return None


def _classify_drift(claim: dict[str, Any], verifier_result: dict[str, Any]) -> dict[str, Any]:
    """Compare verifier output to the claim and return a status.

    Returns:
        {
            "status": "verified" | "drift" | "broken" | "unverified",
            "expected": str (the claim text),
            "actual": str (the verifier stdout),
            "delta_pct": float | None,
            "reason": str (human explanation),
        }
    """
    expected_text = str(claim.get("claim", ""))
    actual_text = verifier_result["stdout"]
    declared_status = claim.get("status", "")

    if not verifier_result["ran"]:
        if verifier_result.get("skipped_reason"):
            return {
                "status": "skipped",
                "expected": expected_text,
                "actual": "",
                "delta_pct": None,
                "reason": verifier_result["skipped_reason"],
            }
        return {
            "status": "unverified",
            "expected": expected_text,
            "actual": "",
            "delta_pct": None,
            "reason": (verifier_result.get("stderr") or "verifier failed to run")[:200],
        }

    # Try numerical comparison first — most stat-block claims have a
    # number in them.
    expected_num = _extract_first_number(expected_text)
    last_verified_value = claim.get("last_verified_value")
    actual_num = _extract_first_number(actual_text)

    # If declared_status is "verified" we treat the last_verified_value
    # as the comparison baseline. Otherwise the claim's textual number
    # is the baseline.
    baseline: float | None = None
    if declared_status == "verified" and last_verified_value is not None:
        baseline_num = _extract_first_number(str(last_verified_value))
        baseline = baseline_num if baseline_num is not None else expected_num
    else:
        baseline = expected_num

    if baseline is not None and actual_num is not None:
        delta_abs = abs(actual_num - baseline)
        delta_pct = (delta_abs / baseline) if baseline != 0 else (1.0 if delta_abs > 0 else 0.0)
        if delta_abs == 0:
            return {
                "status": "verified",
                "expected": expected_text,
                "actual": actual_text,
                "delta_pct": 0.0,
                "reason": f"exact match: actual={actual_num}",
            }
        if delta_abs <= DRIFT_ABSOLUTE_THRESHOLD or delta_pct <= DRIFT_PCT_THRESHOLD:
            return {
                "status": "drift",
                "expected": expected_text,
                "actual": actual_text,
                "delta_pct": delta_pct,
                "reason": (
                    f"numerical drift: claim ~{baseline}, actual {actual_num} "
                    f"(±{delta_abs:.0f}, {delta_pct * 100:.1f}%)"
                ),
            }
        return {
            "status": "broken",
            "expected": expected_text,
            "actual": actual_text,
            "delta_pct": delta_pct,
            "reason": (
                f"large drift: claim ~{baseline}, actual {actual_num} ({delta_pct * 100:.0f}% off)"
            ),
        }

    # Non-numerical claim — best-effort substring match.
    if actual_text and (expected_text.lower() in actual_text.lower()):
        return {
            "status": "verified",
            "expected": expected_text,
            "actual": actual_text,
            "delta_pct": None,
            "reason": "claim text found in verifier output",
        }
    return {
        "status": "drift",
        "expected": expected_text,
        "actual": actual_text,
        "delta_pct": None,
        "reason": "non-numerical claim, verifier output didn't substring-match",
    }


# ---------------------------------------------------------------------------
# Finding formatting
# ---------------------------------------------------------------------------


def _format_finding(claim: dict[str, Any], classification: dict[str, Any]) -> str:
    """Render a drift finding as a WHAT/SO WHAT/NOW WHAT body."""
    claim_id = claim.get("id", "?")
    sources = claim.get("sources", [])
    sources_str = ", ".join(str(s) for s in sources[:3]) or "unknown"
    return (
        f"WHAT: README claim `{claim_id}` is {classification['status']}. "
        f"Claimed: {classification['expected']!r}. "
        f"Actual: {classification['actual'][:200]!r}. "
        f"{classification['reason']}. "
        f"Source(s): {sources_str}.\n\n"
        f"SO WHAT: README is Nebula's main selling surface. Every drift "
        f"between what the README says and what the code does is a "
        f"credibility leak. The {classification['status']} status means "
        f"a future operator reading the README will see something the "
        f"code doesn't actually deliver, OR the README is undercounting "
        f"capability that's already shipped.\n\n"
        f"NOW WHAT: Update the claim. For numerical drift (engine "
        f"counts, file counts, LOC), run `python3 scripts/regen_docs.py`. "
        f"For semantic drift, edit README.md directly and update "
        f"`docs/claims.yml` entry `{claim_id}` with the new "
        f"`last_verified_value`. The CI gate "
        f"(`scripts/check_readme_truth.py`) fails on any `broken` "
        f"status — fix forward before merging."
    )


# ---------------------------------------------------------------------------
# Forward-looking claim drift (CHANGELOG vs current plan)
# ---------------------------------------------------------------------------


# Patterns that indicate a CHANGELOG sentence is making a claim about
# a FUTURE version. Conservative: we only flag patterns we're confident
# about, otherwise we'd surface noise on every release-note paragraph.
_FORWARD_LOOKING_PATTERNS = [
    # "Phase B will ship as v0.6.7" / "Phase X lands in v0.6.Y"
    re.compile(
        r"(Phase\s+[A-Z]\d?)\s+(will\s+ship|lands?|ships?)\s+(?:as\s+|in\s+)?(v\d+\.\d+\.\d+)",
        re.IGNORECASE,
    ),
    # "task #N is scheduled for v0.6.X"
    re.compile(
        r"task\s+#(\d+)\s+(?:is\s+)?(?:scheduled|planned|slated)\s+for\s+(v\d+\.\d+\.\d+)",
        re.IGNORECASE,
    ),
    # "v0.6.X will introduce <thing>"
    re.compile(
        r"(v\d+\.\d+\.\d+)\s+will\s+(?:introduce|ship|add|land|deliver)",
        re.IGNORECASE,
    ),
]

CHANGELOG_PATH = ENGINE_ROOT / "CHANGELOG.md"
TASKS_YAML_PATH = ENGINE_ROOT / "docs" / "tasks.yaml"


def _load_tasks_yaml() -> dict[str, Any]:
    """Read docs/tasks.yaml into a dict keyed by task id.

    Returns ``{task_id: {phase, status, title, ...}}``. Empty dict
    on parse failure (we never crash on this — the auditor degrades
    gracefully).
    """
    if not TASKS_YAML_PATH.is_file():
        return {}
    try:
        import yaml  # type: ignore[import-not-found]

        data = yaml.safe_load(TASKS_YAML_PATH.read_text())
    except Exception as exc:
        logger.debug("readme_truth_auditor: tasks.yaml load failed — %s", exc)
        return {}
    if not isinstance(data, dict) or "tasks" not in data:
        return {}
    out: dict[str, Any] = {}
    for task in data["tasks"]:
        if not isinstance(task, dict):
            continue
        tid = task.get("id")
        if tid is None:
            continue
        out[str(tid)] = task
    return out


def _scan_changelog_forward_claims() -> list[dict[str, Any]]:
    """Walk CHANGELOG.md for forward-looking version references.

    Returns a list of detected claims with the version, the matched
    text, and the line number. Each entry can then be cross-checked
    against the current plan.
    """
    if not CHANGELOG_PATH.is_file():
        return []
    detections: list[dict[str, Any]] = []
    try:
        lines = CHANGELOG_PATH.read_text(encoding="utf-8").splitlines()
    except OSError:
        return []
    for line_no, line in enumerate(lines, start=1):
        for pattern in _FORWARD_LOOKING_PATTERNS:
            match = pattern.search(line)
            if not match:
                continue
            groups = match.groups()
            # Different patterns capture different positional groups;
            # extract the version + the claim subject defensively.
            version = ""
            subject = ""
            for grp in groups:
                if grp and re.match(r"v\d+\.\d+\.\d+", grp):
                    version = grp
                elif grp:
                    subject = grp
            detections.append(
                {
                    "line_no": line_no,
                    "raw": line.strip(),
                    "version": version,
                    "subject": subject,
                    "pattern": pattern.pattern,
                }
            )
            break  # one match per line is enough
    return detections


def _classify_forward_claim(
    detection: dict[str, Any], tasks: dict[str, Any]
) -> dict[str, Any] | None:
    """Decide whether a detected forward-looking claim is still accurate.

    Returns:
        A drift result dict if the claim is stale; None if accurate
        or if we can't determine.
    """
    version = detection.get("version", "")
    subject = (detection.get("subject") or "").strip()
    if not version or not subject:
        return None

    # Case 1: subject is "task #N" OR a bare digit (the scanner
    # captures task numbers without the "task #" prefix). Look up
    # the task and verify its phase still references the version.
    task_match = re.match(r"(?:task\s*#?)?(\d+)$", subject, re.IGNORECASE)
    if task_match:
        task_id = task_match.group(1)
        task = tasks.get(task_id)
        if task is None:
            return {
                "status": "stale_forward_claim",
                "reason": (
                    f"CHANGELOG line {detection['line_no']} promises "
                    f"task #{task_id} for {version}, but task #{task_id} "
                    f"does not exist in tasks.yaml. Either the task was "
                    f"deleted/renumbered, or the original promise was "
                    f"speculative."
                ),
                "raw": detection["raw"],
                "line_no": detection["line_no"],
            }
        actual_phase = str(task.get("phase", ""))
        # Phase strings look like "v0.6.7" or "v0.6.x"; only flag
        # when actual_phase is concrete and != promised version.
        if (
            actual_phase
            and actual_phase != version
            and re.match(r"v\d+\.\d+\.\d+", actual_phase)
            and "x" not in actual_phase.lower()
        ):
            return {
                "status": "stale_forward_claim",
                "reason": (
                    f"CHANGELOG line {detection['line_no']} promises "
                    f"task #{task_id} ({task.get('title', 'unknown')!r}) "
                    f"for {version}, but the current plan ships it in "
                    f"{actual_phase}. Update the past CHANGELOG entry "
                    f"or the task's phase field."
                ),
                "raw": detection["raw"],
                "line_no": detection["line_no"],
            }
        return None

    # Case 2: subject is "Phase X" — we can't reliably cross-reference
    # phase letters against tasks.yaml without a phase-to-version
    # mapping. For now, surface as informational only — no finding.
    # Phase G's user extensibility could let operators add a phase
    # mapping config; for v0.6.7 we keep the check tight to task IDs.
    return None


# ---------------------------------------------------------------------------
# Engine entry point
# ---------------------------------------------------------------------------


def run_readme_truth_audit(
    db_path: str = DEFAULT_DB,
    *,
    claims_path: Path | None = None,
) -> dict[str, Any]:
    """Walk every claim in claims.yml and emit findings for drift.

    Args:
        db_path: SQLite path for findings.
        claims_path: Optional override (tests inject a tmp claims.yml).

    Returns:
        Summary dict with claim counts by status + findings persisted.
        Never raises — verifier failures degrade gracefully.
    """
    summary: dict[str, Any] = {
        "claims_audited": 0,
        "verified": 0,
        "drift": 0,
        "broken": 0,
        "unverified": 0,
        "skipped": 0,
        "stale_forward_claims": 0,
        "findings_persisted": 0,
    }

    target = claims_path or CLAIMS_YML_PATH
    claims = _load_claims_yml(target)
    if not claims:
        logger.info(
            "readme_truth_auditor: no claims to audit (claims.yml at %s missing or empty)",
            target,
        )
        return summary

    for claim in claims:
        summary["claims_audited"] += 1
        verifier_result = _run_verifier(claim)
        classification = _classify_drift(claim, verifier_result)
        status = classification["status"]
        summary[status] = summary.get(status, 0) + 1

        # Only emit findings for problematic statuses. Verified claims
        # don't need to fill the evidence table on every cycle.
        if status in ("drift", "broken", "unverified"):
            try:
                row_id = persist_finding(
                    db_path=db_path,
                    domain="self_maintenance",
                    engine="readme_truth_auditor",
                    evidence_type=f"readme_claim_{status}",
                    finding=_format_finding(claim, classification),
                    confidence=DRIFT_FINDING_CONFIDENCE,
                    source_repo="nebula",
                    source_file="docs/claims.yml",
                    raw_data={
                        "claim_id": claim.get("id"),
                        "category": claim.get("category"),
                        "expected": classification["expected"],
                        "actual": classification["actual"][:500],
                        "delta_pct": classification["delta_pct"],
                        "reason": classification["reason"],
                        "auto_correctable": (
                            status == "drift" and claim.get("category") == "stats"
                        ),
                    },
                    api_sources=["readme_truth_auditor"],
                )
                if row_id and row_id > 0:
                    summary["findings_persisted"] += 1
            except Exception as exc:
                logger.debug(
                    "readme_truth_auditor: persist failed for %s — %s",
                    claim.get("id"),
                    exc,
                )

    # Pass 2: forward-looking claim drift in CHANGELOG. Catches the
    # "old release notes promised v0.6.7 but plan changed to v0.6.8"
    # class of bug. Cross-references against docs/tasks.yaml's
    # current phase fields.
    tasks = _load_tasks_yaml()
    detections = _scan_changelog_forward_claims()
    for detection in detections:
        result = _classify_forward_claim(detection, tasks)
        if result is None:
            continue
        summary["stale_forward_claims"] += 1
        try:
            row_id = persist_finding(
                db_path=db_path,
                domain="self_maintenance",
                engine="readme_truth_auditor",
                evidence_type="readme_claim_stale_forward",
                finding=(
                    f"WHAT: CHANGELOG.md line {result['line_no']} contains "
                    f"a stale forward-looking claim: {result['raw']!r}. "
                    f"{result['reason']}\n\n"
                    f"SO WHAT: Past release notes ship in git history "
                    f"forever. When the plan changes, those promises "
                    f"become quiet lies. A future operator reading the "
                    f"old CHANGELOG entry will trust the version target "
                    f"or task assignment we promised, only to find we "
                    f"shipped it elsewhere or not at all. This is a "
                    f"credibility leak that compounds with every "
                    f"subsequent ship.\n\n"
                    f"NOW WHAT: Either update the original CHANGELOG "
                    f"entry to reflect the new plan (preferred), OR add "
                    f"a follow-up CHANGELOG note in the next release "
                    f"explicitly retracting the old promise. Update "
                    f"docs/tasks.yaml's phase field if it's the source "
                    f"of truth that drifted. The CI gate "
                    f"`scripts/check_readme_truth.py` fails on any "
                    f"stale_forward_claim status."
                ),
                confidence=DRIFT_FINDING_CONFIDENCE,
                source_repo="nebula",
                source_file="CHANGELOG.md",
                source_line=result["line_no"],
                raw_data={
                    "line_no": result["line_no"],
                    "raw": result["raw"],
                    "reason": result["reason"],
                    "auto_correctable": False,
                },
                api_sources=["readme_truth_auditor"],
            )
            if row_id and row_id > 0:
                summary["findings_persisted"] += 1
        except Exception as exc:
            logger.debug(
                "readme_truth_auditor: stale_forward_claim persist failed — %s",
                exc,
            )

    logger.info(
        "readme_truth_auditor: audited=%d verified=%d drift=%d broken=%d unverified=%d skipped=%d stale_forward=%d persisted=%d",
        summary["claims_audited"],
        summary["verified"],
        summary["drift"],
        summary["broken"],
        summary["unverified"],
        summary["skipped"],
        summary["stale_forward_claims"],
        summary["findings_persisted"],
    )
    return summary


__all__ = ["run_readme_truth_audit"]
