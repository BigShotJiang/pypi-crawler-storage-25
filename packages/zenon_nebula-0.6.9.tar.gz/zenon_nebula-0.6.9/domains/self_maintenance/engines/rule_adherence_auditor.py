# SPDX-License-Identifier: MIT
"""Rule adherence auditor — walks Nebula's own recent commits and flags rule drift.

Closes the "rule execution is not mechanical" gap: `.claude/rules/`
declares behavioral conventions (commit format, CHANGELOG discipline,
attack-vector-audit checklist, anti-hallucination for config/schema
edits, test-when-touching discipline) but nothing previously verified
that individual commits actually honored them. This engine is the
retrospective layer.

Each cycle it reads the last ``COMMIT_WINDOW`` commits from the
Nebula repo (via ``git log`` with a fixed format and a tight
timeout — never arbitrary user repos, never with ``--author``, never
anything identity-revealing), runs each commit through a fixed set
of structural checks, and persists a WHAT/SO WHAT/NOW WHAT finding
for every check that failed. The next session (human or agent)
sees the drift as a visible finding instead of it silently
accumulating.

Why this matters specifically: the v0.6.1 release had a
``continue-on-error`` hallucination in ``.github/workflows/release.yml``
that slipped past the anti-hallucination rule because the rule was
scoped to *code* constants, not *config/schema* edits. A workflow-file
edit without a "verified against the schema" note is exactly the
kind of pattern this engine catches — not by reading the content of
the edit, but by noting the structural fingerprint (touches
``.github/workflows/*.yml``) and flagging it for retrospective
review.

Design invariants:
    - Pure-function checks. Deterministic: same commit -> same findings.
    - Only reads from the Nebula repo (``ENGINE_ROOT``). Never touches
      user workspace repos.
    - Runs ``git log`` with ``--format`` and ``--name-only``, never
      ``--author`` (anti-doxxing rule + we're auditing OUR commits,
      so author identity is always mehowz — no information gained).
    - Timeouts bounded at 5 seconds per git invocation.
    - Graceful degradation: missing git, non-repo, empty log all
      return an empty summary.
    - Never modifies the repo state. Read-only.
    - Findings live in the ``self_maintenance`` domain with
      ``evidence_type`` = ``rule_adherence_drift``.
"""

from __future__ import annotations

import logging
import re
import subprocess
from dataclasses import dataclass
from pathlib import Path
from typing import Any

from core.persistence.findings import persist_finding

logger = logging.getLogger(__name__)

ENGINE_ROOT = Path(__file__).resolve().parents[3]
DEFAULT_DB = str(ENGINE_ROOT / "data" / "engine.db")

# How many commits to audit per cycle. 30 is enough to cover a
# reasonable session without blowing up the per-cycle cost.
COMMIT_WINDOW = 30

# Per-git-invocation timeout — tight to bound worst-case cost.
GIT_TIMEOUT_SECONDS = 5

# Confidence for rule-drift findings. Structural heuristics produce
# "probably a drift" signals, not "definitely a bug". An intentional
# WIP commit that skips CHANGELOG is not a bug, and the human reviewer
# should judge. 0.55 matches the curiosity_scanner tier: worth surfacing
# but not high enough to dominate hypothesis confidence updates.
DRIFT_CONFIDENCE = 0.55

# Conventional-commit regex. Must start with a type, optional scope,
# colon, space, imperative verb. Matches the format declared in
# .claude/rules/commit-discipline.md.
_CONVENTIONAL_TYPES = (
    "feat",
    "fix",
    "refactor",
    "perf",
    "docs",
    "test",
    "chore",
    "ci",
    "build",
    "release",
)
_CONVENTIONAL_RE = re.compile(
    r"^(" + "|".join(_CONVENTIONAL_TYPES) + r")(\[[a-z0-9_/\-.]+\])?: .+",
)

# Maximum length of the commit subject line, per commit-discipline.md.
MAX_SUBJECT_LENGTH = 72

# Paths that indicate the change is "non-trivial" and should have
# both a CHANGELOG entry and a test touch. Stat-block regeneration
# commits and pure docs commits are exempted so the rule doesn't
# drown itself in noise.
_NON_TRIVIAL_PREFIXES = (
    "core/",
    "domains/",
    "scripts/",
    ".github/workflows/",
)
_TRIVIAL_NAMES = {
    "CLAUDE.md",
    "README.md",
    "docs/DOMAINS.md",
    "docs/architecture/dependency-graph.md",
    "docs/architecture/dependency-report.md",
}

# Test touch is satisfied if any staged file matches.
_TEST_PREFIXES = ("tests/", "test_")

# Config/schema edit signal — .github/workflows/, pyproject.toml,
# config/*.json, *.toml, etc. Per the post-v0.6.1 lesson, these
# edits should carry an "attack-vector audit" section or a note
# proving the schema was verified externally.
_CONFIG_SCHEMA_PREFIXES = (
    ".github/workflows/",
    "config/",
)
_CONFIG_SCHEMA_EXTS = {".yml", ".yaml", ".toml", ".json"}


# ---------------------------------------------------------------------------
# Data model
# ---------------------------------------------------------------------------


@dataclass
class CommitRecord:
    """Minimal parsed view of one commit. Never includes author fields."""

    sha: str
    short_sha: str
    subject: str
    body: str
    files: list[str]


@dataclass
class DriftFinding:
    """One rule-adherence drift for one commit."""

    commit: CommitRecord
    rule: str
    reason: str
    severity: str  # "low" | "medium" | "high"


# ---------------------------------------------------------------------------
# Git readers
# ---------------------------------------------------------------------------


def _run_git(args: list[str], cwd: Path) -> str | None:
    """Run ``git <args>`` under ``cwd``. Return stdout or None on failure.

    Never raises. Timeouts, non-zero exits, and missing git all become
    None so the engine can graceful-degrade upstream.
    """
    try:
        result = subprocess.run(
            ["git", *args],
            cwd=str(cwd),
            capture_output=True,
            text=True,
            timeout=GIT_TIMEOUT_SECONDS,
        )
    except (OSError, subprocess.TimeoutExpired) as exc:
        logger.debug("rule_adherence_auditor: git %s failed — %s", args, exc)
        return None
    if result.returncode != 0:
        logger.debug(
            "rule_adherence_auditor: git %s exited %d — %s",
            args,
            result.returncode,
            result.stderr.strip()[:200],
        )
        return None
    return result.stdout


def _is_git_repo(path: Path) -> bool:
    """Return True if ``path`` contains a ``.git`` entry or is inside one."""
    try:
        if (path / ".git").exists():
            return True
    except OSError:
        return False
    return False


def _read_recent_commits(repo: Path, limit: int) -> list[CommitRecord]:
    """Return up to ``limit`` most-recent commits from ``repo``.

    Uses a two-step read: first ``git log --format`` for the sha +
    subject + body, then one ``git show --name-only`` per sha for
    the touched files. Splitting keeps each invocation cheap and
    lets us bound memory. Never calls ``--author`` or any
    identity-revealing format code.
    """
    # Use a sentinel separator the commit bodies cannot contain.
    sep = "\x1f\x1f\x1f"
    record_sep = "\x1e\x1e\x1e"
    fmt = f"%H{sep}%h{sep}%s{sep}%b{record_sep}"
    log = _run_git(
        ["log", f"-n{limit}", f"--format={fmt}"],
        cwd=repo,
    )
    if not log:
        return []
    records: list[CommitRecord] = []
    for raw in log.split(record_sep):
        chunk = raw.strip("\n\r")
        if not chunk:
            continue
        parts = chunk.split(sep)
        if len(parts) < 4:
            continue
        sha, short_sha, subject, body = parts[0], parts[1], parts[2], parts[3]
        files = _read_commit_files(repo, sha)
        records.append(
            CommitRecord(
                sha=sha,
                short_sha=short_sha,
                subject=subject,
                body=body,
                files=files,
            )
        )
    return records


def _read_commit_files(repo: Path, sha: str) -> list[str]:
    """Return the list of files touched by ``sha``."""
    out = _run_git(
        ["show", "--name-only", "--format=", sha],
        cwd=repo,
    )
    if not out:
        return []
    return [line.strip() for line in out.splitlines() if line.strip()]


# ---------------------------------------------------------------------------
# Rule checks (pure functions, each returns a list of DriftFinding)
# ---------------------------------------------------------------------------


def _check_commit_format(commit: CommitRecord) -> list[DriftFinding]:
    """R1 — commit subject matches conventional-commits format."""
    if not _CONVENTIONAL_RE.match(commit.subject):
        return [
            DriftFinding(
                commit=commit,
                rule="commit-discipline/format",
                reason=(
                    f"Subject '{commit.subject[:80]}' does not match the "
                    "conventional format `<type>[scope]: <imperative>`."
                ),
                severity="low",
            )
        ]
    return []


def _check_subject_length(commit: CommitRecord) -> list[DriftFinding]:
    """R2 — commit subject under 72 characters."""
    if len(commit.subject) > MAX_SUBJECT_LENGTH:
        return [
            DriftFinding(
                commit=commit,
                rule="commit-discipline/subject-length",
                reason=(
                    f"Subject is {len(commit.subject)} chars "
                    f"(> {MAX_SUBJECT_LENGTH}). Move detail into the body."
                ),
                severity="low",
            )
        ]
    return []


def _is_non_trivial(files: list[str]) -> bool:
    """Return True if the file list contains any non-trivial path."""
    for f in files:
        if f in _TRIVIAL_NAMES:
            continue
        if any(f.startswith(p) for p in _NON_TRIVIAL_PREFIXES):
            return True
    return False


def _check_changelog_for_non_trivial(commit: CommitRecord) -> list[DriftFinding]:
    """R3 — non-trivial commits update CHANGELOG.md."""
    if not _is_non_trivial(commit.files):
        return []
    if "CHANGELOG.md" in commit.files:
        return []
    return [
        DriftFinding(
            commit=commit,
            rule="autonomous-quality/changelog",
            reason=(
                "Non-trivial change (touches core/domains/scripts/workflows) "
                "but CHANGELOG.md was not updated in the same commit."
            ),
            severity="medium",
        )
    ]


def _touches_core_or_domains(files: list[str]) -> bool:
    """Return True if any file is under core/ or domains/."""
    return any(f.startswith("core/") or f.startswith("domains/") for f in files)


def _touches_tests(files: list[str]) -> bool:
    """Return True if any file looks like a test."""
    return any(
        f.startswith(p) or Path(f).name.startswith("test_") for f in files for p in _TEST_PREFIXES
    )


def _check_tests_accompany_code(commit: CommitRecord) -> list[DriftFinding]:
    """R4 — commits touching core/ or domains/ also touch tests/.

    Bug-fix commits get a narrower check: we expect a regression test.
    Refactors don't necessarily need new tests (the existing ones
    should still pass). Pure doc/comment edits are excluded via the
    trivial-names filter above.
    """
    if not _touches_core_or_domains(commit.files):
        return []
    if _touches_tests(commit.files):
        return []
    # Exempt pure-release commits (version bump + changelog only) and
    # revert commits — both legitimately touch code without new tests.
    if commit.subject.startswith(("release", "revert")):
        return []
    return [
        DriftFinding(
            commit=commit,
            rule="test-discipline/tests-accompany-code",
            reason=(
                "Touched core/ or domains/ without a corresponding "
                "change under tests/. New behavior without a test is "
                "coverage drift."
            ),
            severity="medium",
        )
    ]


def _is_config_or_schema(files: list[str]) -> bool:
    """Return True if the commit touches a config or schema file."""
    for f in files:
        if any(f.startswith(p) for p in _CONFIG_SCHEMA_PREFIXES):
            return True
        if Path(f).suffix in _CONFIG_SCHEMA_EXTS and f != "pyproject.toml":
            return True
    return False


def _check_config_schema_verification_note(
    commit: CommitRecord,
) -> list[DriftFinding]:
    """R5 — config/schema edits carry a verification note.

    Post-v0.6.1 lesson: CI/CD YAML and schema edits must be
    validated against the actual schema (GitHub's workflow schema,
    JSON Schema, TOML parser, etc.), not just "docs say this works."
    The commit body should acknowledge the verification — either an
    "Attack-vector audit" block or an explicit "verified against
    <source>" line. Absence of either is flagged.
    """
    if not _is_config_or_schema(commit.files):
        return []
    body_lower = commit.body.lower()
    if any(
        marker in body_lower
        for marker in (
            "attack-vector audit",
            "verified against",
            "validated against",
            "schema check",
        )
    ):
        return []
    return [
        DriftFinding(
            commit=commit,
            rule="anti-hallucination/config-schema-verification",
            reason=(
                "Touched a config/workflow/schema file but the commit "
                "body does not acknowledge external schema verification. "
                "Post-v0.6.1 lesson: assume unverified schema edits are "
                "hallucinations until proven otherwise."
            ),
            severity="high",
        )
    ]


def _check_unreferenced_todo(commit: CommitRecord) -> list[DriftFinding]:
    """R6 — commit message doesn't mention un-tracked TODO / FIXME.

    This is a lightweight check on the commit MESSAGE, not on the
    file content (file-content scanning is no-demo-code.md's job
    and is handled by pre-commit hook). We just flag commits whose
    message contains 'TODO' or 'FIXME' without a tracking reference.
    """
    subject_and_body = f"{commit.subject}\n{commit.body}"
    if "TODO" not in subject_and_body and "FIXME" not in subject_and_body:
        return []
    # Accept if paired with a tracking reference: #123, (#45), task #50.
    if re.search(r"#\d+|\btask\s*#?\d+", subject_and_body, re.IGNORECASE):
        return []
    return [
        DriftFinding(
            commit=commit,
            rule="no-demo-code/untracked-todo",
            reason=(
                "Commit message mentions TODO or FIXME without a "
                "tracking reference (#N or 'task #N'). Add the "
                "reference or resolve the item."
            ),
            severity="low",
        )
    ]


_ALL_CHECKS = (
    _check_commit_format,
    _check_subject_length,
    _check_changelog_for_non_trivial,
    _check_tests_accompany_code,
    _check_config_schema_verification_note,
    _check_unreferenced_todo,
)


def _audit_commit(commit: CommitRecord) -> list[DriftFinding]:
    """Run every check against one commit. Returns all drift findings."""
    out: list[DriftFinding] = []
    for check in _ALL_CHECKS:
        out.extend(check(commit))
    return out


# ---------------------------------------------------------------------------
# Finding formatting + persistence
# ---------------------------------------------------------------------------


def _format_finding_body(drift: DriftFinding) -> str:
    """Return the WHAT/SO WHAT/NOW WHAT body for a drift finding."""
    return (
        f"WHAT: Commit {drift.commit.short_sha} ('{drift.commit.subject[:80]}') "
        f"drifted from rule '{drift.rule}'. {drift.reason}\n\n"
        f"SO WHAT: Rules in `.claude/rules/` are the mechanical discipline "
        f"layer Nebula uses to keep its own code trustworthy. When a commit "
        f"skips a rule and nobody notices, the next session inherits the "
        f"drift silently — and rules that aren't enforced rot from "
        f"'behavioral convention' to 'decorative comment'. The v0.6.1 "
        f"continue-on-error hallucination is the canonical example of how "
        f"unchecked drift costs a release.\n\n"
        f"NOW WHAT: Review commit {drift.commit.short_sha}. If the drift is "
        f"a real gap, either fix it forward (next commit adds the missing "
        f"CHANGELOG / test / verification note) or amend the rule so it "
        f"matches the intent. If the drift is a false positive, strengthen "
        f"the check heuristic in `rule_adherence_auditor._ALL_CHECKS` so "
        f"the next session doesn't re-flag it."
    )


def run_rule_adherence_auditor(
    db_path: str = DEFAULT_DB,
    *,
    repo_root: Path | None = None,
    commit_limit: int = COMMIT_WINDOW,
) -> dict:
    """Entry point — audit the last N commits of the Nebula repo.

    Args:
        db_path: SQLite database path (defaults to live engine.db).
        repo_root: Optional override for the Nebula repo root. Tests
            inject a temp git repo here. Production always uses the
            package-installed ENGINE_ROOT.
        commit_limit: How many recent commits to audit. Defaults to
            ``COMMIT_WINDOW``.

    Returns:
        Dict with keys:
            commits_audited: how many commits were read from git
            drifts_detected: total rule-drift findings across all commits
            findings_persisted: how many rows landed in evidence
            repo_root: str path audited (None if not a git repo)
    """
    summary: dict[str, Any] = {
        "commits_audited": 0,
        "drifts_detected": 0,
        "findings_persisted": 0,
        "repo_root": None,
    }
    repo = repo_root if repo_root is not None else ENGINE_ROOT
    if not _is_git_repo(repo):
        logger.info(
            "rule_adherence_auditor: %s is not a git repo — skipping "
            "(pip-installed Nebula has no git history to audit)",
            repo,
        )
        return summary
    summary["repo_root"] = str(repo)

    commits = _read_recent_commits(repo, commit_limit)
    summary["commits_audited"] = len(commits)

    for commit in commits:
        drifts = _audit_commit(commit)
        summary["drifts_detected"] += len(drifts)
        for drift in drifts:
            body = _format_finding_body(drift)
            try:
                row_id = persist_finding(
                    db_path=db_path,
                    domain="self_maintenance",
                    engine="rule_adherence_auditor",
                    evidence_type=f"rule_drift_{drift.rule.split('/')[0]}",
                    finding=body,
                    confidence=DRIFT_CONFIDENCE,
                    source_repo="nebula",
                    source_commit=drift.commit.sha,
                )
                if row_id and row_id > 0:
                    summary["findings_persisted"] += 1
            except (TypeError, ValueError) as exc:
                logger.debug(
                    "rule_adherence_auditor: persist failed for %s/%s — %s",
                    drift.commit.short_sha,
                    drift.rule,
                    exc,
                )

    logger.info(
        "rule_adherence_auditor: audited %d commit(s), detected %d drift(s), "
        "persisted %d finding(s)",
        summary["commits_audited"],
        summary["drifts_detected"],
        summary["findings_persisted"],
    )
    return summary
