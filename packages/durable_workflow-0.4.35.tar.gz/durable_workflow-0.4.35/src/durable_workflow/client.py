"""Async client for the Durable Workflow server's control and worker planes.

The :class:`Client` wraps the server's HTTP/JSON protocol. Control-plane
methods (``start_workflow``, ``signal_workflow``, ``describe_workflow``,
schedule management, …) are what callers use to drive workflows from outside.
Worker-plane methods (``register_worker``, ``poll_workflow_task``,
``poll_query_task``, ``complete_activity_task``, …) are what the
:class:`~durable_workflow.Worker`
uses to run tasks; they are public so advanced users can build custom
workers, but most applications should not call them directly.

The module also defines the returned-value dataclasses (``WorkflowExecution``,
``WorkflowList``, ``ScheduleSpec``, ``ScheduleDescription``, …) and the
ergonomic handle classes (:class:`WorkflowHandle`, :class:`ScheduleHandle`)
that bind a workflow or schedule id to a :class:`Client` so you can call
methods without repeating the id on every call.
"""

from __future__ import annotations

import asyncio
import time
import uuid
import warnings
from collections.abc import AsyncIterator, Callable
from dataclasses import dataclass
from importlib.metadata import PackageNotFoundError
from importlib.metadata import version as _pkg_version
from typing import Any
from urllib.parse import quote, urlencode

import httpx

from . import serializer
from .errors import (
    ServerError,
    WorkflowCancelled,
    WorkflowFailed,
    WorkflowTerminated,
    _raise_for_status,
)
from .external_storage import ExternalPayloadCache, ExternalPayloadStoragePolicy, ExternalStorageDriver
from .metrics import CLIENT_REQUEST_DURATION_SECONDS, CLIENT_REQUESTS, NOOP_METRICS, MetricsRecorder
from .retry_policy import TransportRetryPolicy

PROTOCOL_VERSION = "1.1"
CONTROL_PLANE_VERSION = "2"
CONTROL_PLANE_REQUEST_CONTRACT_SCHEMA = "durable-workflow.v2.control-plane-request.contract"
CONTROL_PLANE_REQUEST_CONTRACT_VERSION = 1


def _default_sdk_version() -> str:
    try:
        return f"durable-workflow-python/{_pkg_version('durable-workflow')}"
    except PackageNotFoundError:
        return "durable-workflow-python/0.0.0+unknown"


DEFAULT_SDK_VERSION = _default_sdk_version()


def _route_for_metrics(path: str) -> str:
    clean_path = path.split("?", 1)[0]
    parts = [part for part in clean_path.strip("/").split("/") if part]
    if not parts:
        return "/"

    if parts[0] == "workflows" and len(parts) >= 2:
        parts[1] = "{workflow_id}"
        if len(parts) >= 4 and parts[2] in {"signal", "query", "update"}:
            parts[3] = "{name}"
        if len(parts) >= 4 and parts[2] == "runs":
            parts[3] = "{run_id}"
    elif parts[0] == "schedules" and len(parts) >= 2:
        parts[1] = "{schedule_id}"
    elif parts[0] in {"namespaces", "search-attributes"} and len(parts) >= 2:
        parts[1] = "{name}"
    elif parts[0] == "workers" and len(parts) >= 2:
        parts[1] = "{worker_id}"
    elif parts[:2] == ["bridge-adapters", "webhook"] and len(parts) >= 3:
        parts[2] = "{adapter}"
    elif (
        parts[:2] == ["worker", "workflow-tasks"]
        or parts[:2] == ["worker", "activity-tasks"]
        or parts[:2] == ["worker", "query-tasks"]
    ) and len(parts) >= 3:
        parts[2] = "{task_id}"

    return "/" + "/".join(parts)


def _resolve_namespace_name(
    name: str | None,
    namespace_alias: str | None,
    *,
    method: str,
) -> str:
    """Resolve the namespace name accepted via ``name=`` or the deprecated ``namespace=`` alias."""
    if namespace_alias is not None:
        if name is not None:
            raise TypeError(
                f"{method}() received both 'name' and the deprecated alias "
                "'namespace'; pass only 'name'."
            )
        warnings.warn(
            f"{method}() argument 'namespace' is deprecated since 0.4.1; "
            "use 'name' to match describe_namespace, create_namespace, and "
            "update_namespace.",
            DeprecationWarning,
            stacklevel=3,
        )
        name = namespace_alias
    if name is None:
        raise TypeError(f"{method}() missing required argument: 'name'")
    return name


@dataclass
class WorkflowExecution:
    """Current server view of one workflow execution."""

    workflow_id: str
    run_id: str | None
    workflow_type: str
    status: str | None = None
    namespace: str | None = None
    task_queue: str | None = None
    input: Any = None
    output: Any = None
    payload_codec: str | None = None


@dataclass
class WorkflowList:
    """One page of workflow visibility results."""

    executions: list[WorkflowExecution]
    next_page_token: str | None = None


@dataclass
class NamespaceDescription:
    """Server configuration for one workflow namespace."""

    name: str
    description: str | None = None
    retention_days: int | None = None
    status: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    external_payload_storage: ExternalPayloadStoragePolicy | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> NamespaceDescription:
        external_payload_storage = None
        if isinstance(data.get("external_payload_storage"), dict):
            external_payload_storage = ExternalPayloadStoragePolicy.from_dict(data)

        return cls(
            name=str(data.get("name", "")),
            description=data.get("description"),
            retention_days=data.get("retention_days"),
            status=data.get("status"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            external_payload_storage=external_payload_storage,
        )


@dataclass
class NamespaceList:
    """Namespaces visible to the current control-plane identity."""

    namespaces: list[NamespaceDescription]


@dataclass
class StoragePayloadTestResult:
    """Result for one payload size exercised by the server storage probe."""

    status: str
    bytes: int | None = None
    sha256: str | None = None
    reference_uri: str | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StoragePayloadTestResult:
        return cls(
            status=str(data.get("status", "")),
            bytes=data.get("bytes"),
            sha256=data.get("sha256"),
            reference_uri=data.get("reference_uri"),
        )


@dataclass
class StorageTestResult:
    """Server response for an external payload storage probe."""

    status: str
    namespace: str | None = None
    driver: str | None = None
    small_payload: StoragePayloadTestResult | None = None
    large_payload: StoragePayloadTestResult | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> StorageTestResult:
        small = data.get("small_payload")
        large = data.get("large_payload")

        return cls(
            status=str(data.get("status", "")),
            namespace=data.get("namespace"),
            driver=data.get("driver"),
            small_payload=StoragePayloadTestResult.from_dict(small) if isinstance(small, dict) else None,
            large_payload=StoragePayloadTestResult.from_dict(large) if isinstance(large, dict) else None,
            raw=data,
        )


@dataclass
class WorkflowRun:
    """Current server view of one durable run in a workflow execution chain."""

    workflow_id: str
    run_id: str
    workflow_type: str
    status: str | None = None
    namespace: str | None = None
    task_queue: str | None = None
    run_number: int | None = None
    run_count: int | None = None
    is_current_run: bool | None = None
    status_bucket: str | None = None
    business_key: str | None = None
    compatibility: str | None = None
    payload_codec: str | None = None
    input: Any = None
    output: Any = None
    memo: dict[str, Any] | None = None
    search_attributes: dict[str, Any] | None = None
    actions: dict[str, Any] | None = None
    started_at: str | None = None
    closed_at: str | None = None
    last_progress_at: str | None = None
    closed_reason: str | None = None
    wait_kind: str | None = None
    wait_reason: str | None = None
    execution_timeout_seconds: int | None = None
    run_timeout_seconds: int | None = None
    execution_deadline_at: str | None = None
    run_deadline_at: str | None = None

    @classmethod
    def from_dict(
        cls, data: dict[str, Any], *, workflow_id: str | None = None, run_id: str | None = None
    ) -> WorkflowRun:
        return cls(
            workflow_id=data.get("workflow_id", workflow_id or ""),
            run_id=data.get("run_id", run_id or ""),
            workflow_type=data.get("workflow_type", ""),
            status=data.get("status"),
            namespace=data.get("namespace"),
            task_queue=data.get("task_queue"),
            run_number=data.get("run_number"),
            run_count=data.get("run_count"),
            is_current_run=data.get("is_current_run"),
            status_bucket=data.get("status_bucket"),
            business_key=data.get("business_key"),
            compatibility=data.get("compatibility"),
            payload_codec=data.get("payload_codec"),
            input=data.get("input"),
            output=data.get("output"),
            memo=data.get("memo") if isinstance(data.get("memo"), dict) else None,
            search_attributes=(
                data.get("search_attributes") if isinstance(data.get("search_attributes"), dict) else None
            ),
            actions=data.get("actions") if isinstance(data.get("actions"), dict) else None,
            started_at=data.get("started_at"),
            closed_at=data.get("closed_at"),
            last_progress_at=data.get("last_progress_at"),
            closed_reason=data.get("closed_reason"),
            wait_kind=data.get("wait_kind"),
            wait_reason=data.get("wait_reason"),
            execution_timeout_seconds=data.get("execution_timeout_seconds"),
            run_timeout_seconds=data.get("run_timeout_seconds"),
            execution_deadline_at=data.get("execution_deadline_at"),
            run_deadline_at=data.get("run_deadline_at"),
        )


@dataclass
class WorkflowCommandResult:
    """Machine-readable outcome returned by workflow control commands."""

    workflow_id: str
    outcome: str
    command_status: str | None = None
    command_id: str | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any], *, workflow_id: str | None = None) -> WorkflowCommandResult:
        return cls(
            workflow_id=data.get("workflow_id", workflow_id or ""),
            outcome=data.get("outcome", ""),
            command_status=data.get("command_status"),
            command_id=data.get("command_id"),
            raw=data,
        )


@dataclass
class WorkflowRunList:
    """All known durable runs for one workflow execution, oldest first."""

    workflow_id: str
    run_count: int
    runs: list[WorkflowRun]


@dataclass
class StandaloneActivityExecution:
    """Server view of one standalone activity execution.

    Standalone activities run as top-level durable jobs anchored by a
    server-managed host run; this dataclass collapses the host-run state
    and the underlying activity execution state into one description so
    callers do not need to navigate between two surfaces to inspect a
    single job.
    """

    activity_id: str
    workflow_run_id: str | None
    activity_execution_id: str | None
    workflow_type: str
    activity_type: str | None
    activity_class: str | None
    task_queue: str | None
    namespace: str | None
    status: str | None
    activity_status: str | None
    closed_reason: str | None
    business_key: str | None
    payload_codec: str | None
    started_at: str | None
    closed_at: str | None
    last_progress_at: str | None
    last_heartbeat_at: str | None
    schedule_to_start_deadline_at: str | None
    schedule_to_close_deadline_at: str | None
    attempt_count: int | None
    result: Any = None

    @classmethod
    def from_dict(
        cls,
        data: dict[str, Any],
        *,
        activity_id: str | None = None,
        result: Any = None,
    ) -> StandaloneActivityExecution:
        return cls(
            activity_id=data.get("activity_id", activity_id or ""),
            workflow_run_id=data.get("workflow_run_id"),
            activity_execution_id=data.get("activity_execution_id"),
            workflow_type=data.get("workflow_type", ""),
            activity_type=data.get("activity_type"),
            activity_class=data.get("activity_class"),
            task_queue=data.get("task_queue"),
            namespace=data.get("namespace"),
            status=data.get("status"),
            activity_status=data.get("activity_status"),
            closed_reason=data.get("closed_reason"),
            business_key=data.get("business_key"),
            payload_codec=data.get("payload_codec"),
            started_at=data.get("started_at"),
            closed_at=data.get("closed_at"),
            last_progress_at=data.get("last_progress_at"),
            last_heartbeat_at=data.get("last_heartbeat_at"),
            schedule_to_start_deadline_at=data.get("schedule_to_start_deadline_at"),
            schedule_to_close_deadline_at=data.get("schedule_to_close_deadline_at"),
            attempt_count=data.get("attempt_count"),
            result=result,
        )


@dataclass
class StandaloneActivityList:
    """One page of standalone activity executions returned by the server."""

    activities: list[StandaloneActivityExecution]
    activity_count: int
    next_page_token: str | None = None


@dataclass
class SearchAttributeList:
    """Search attribute definitions available in the current namespace."""

    system_attributes: dict[str, str]
    custom_attributes: dict[str, str]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> SearchAttributeList:
        system = data.get("system_attributes")
        custom = data.get("custom_attributes")

        return cls(
            system_attributes=dict(system) if isinstance(system, dict) else {},
            custom_attributes=dict(custom) if isinstance(custom, dict) else {},
        )


@dataclass
class TaskQueueTaskAdmission:
    """Workflow/activity admission state for one task queue."""

    status: str | None = None
    budget_source: str | None = None
    server_budget_source: str | None = None
    active_worker_count: int | None = None
    configured_slot_count: int | None = None
    leased_count: int | None = None
    ready_count: int | None = None
    available_slot_count: int | None = None
    server_max_active_leases_per_queue: int | None = None
    server_active_lease_count: int | None = None
    server_remaining_active_lease_capacity: int | None = None
    server_max_active_leases_per_namespace: int | None = None
    server_namespace_active_lease_count: int | None = None
    server_remaining_namespace_active_lease_capacity: int | None = None
    server_max_dispatches_per_minute: int | None = None
    server_dispatch_count_this_minute: int | None = None
    server_remaining_dispatch_capacity: int | None = None
    server_max_dispatches_per_minute_per_namespace: int | None = None
    server_namespace_dispatch_count_this_minute: int | None = None
    server_remaining_namespace_dispatch_capacity: int | None = None
    server_dispatch_budget_group: str | None = None
    server_max_dispatches_per_minute_per_budget_group: int | None = None
    server_budget_group_dispatch_count_this_minute: int | None = None
    server_remaining_budget_group_dispatch_capacity: int | None = None
    server_lock_required: bool | None = None
    server_lock_supported: bool | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> TaskQueueTaskAdmission | None:
        if data is None:
            return None
        return cls(
            status=data.get("status"),
            budget_source=data.get("budget_source"),
            server_budget_source=data.get("server_budget_source"),
            active_worker_count=data.get("active_worker_count"),
            configured_slot_count=data.get("configured_slot_count"),
            leased_count=data.get("leased_count"),
            ready_count=data.get("ready_count"),
            available_slot_count=data.get("available_slot_count"),
            server_max_active_leases_per_queue=data.get("server_max_active_leases_per_queue"),
            server_active_lease_count=data.get("server_active_lease_count"),
            server_remaining_active_lease_capacity=data.get("server_remaining_active_lease_capacity"),
            server_max_active_leases_per_namespace=data.get("server_max_active_leases_per_namespace"),
            server_namespace_active_lease_count=data.get("server_namespace_active_lease_count"),
            server_remaining_namespace_active_lease_capacity=data.get(
                "server_remaining_namespace_active_lease_capacity"
            ),
            server_max_dispatches_per_minute=data.get("server_max_dispatches_per_minute"),
            server_dispatch_count_this_minute=data.get("server_dispatch_count_this_minute"),
            server_remaining_dispatch_capacity=data.get("server_remaining_dispatch_capacity"),
            server_max_dispatches_per_minute_per_namespace=data.get(
                "server_max_dispatches_per_minute_per_namespace"
            ),
            server_namespace_dispatch_count_this_minute=data.get("server_namespace_dispatch_count_this_minute"),
            server_remaining_namespace_dispatch_capacity=data.get("server_remaining_namespace_dispatch_capacity"),
            server_dispatch_budget_group=data.get("server_dispatch_budget_group"),
            server_max_dispatches_per_minute_per_budget_group=data.get(
                "server_max_dispatches_per_minute_per_budget_group"
            ),
            server_budget_group_dispatch_count_this_minute=data.get(
                "server_budget_group_dispatch_count_this_minute"
            ),
            server_remaining_budget_group_dispatch_capacity=data.get(
                "server_remaining_budget_group_dispatch_capacity"
            ),
            server_lock_required=data.get("server_lock_required"),
            server_lock_supported=data.get("server_lock_supported"),
        )


@dataclass
class TaskQueueQueryAdmission:
    """Worker-routed query-task admission state for one task queue."""

    status: str | None = None
    budget_source: str | None = None
    max_pending_per_queue: int | None = None
    approximate_pending_count: int | None = None
    remaining_pending_capacity: int | None = None
    lock_required: bool | None = None
    lock_supported: bool | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> TaskQueueQueryAdmission | None:
        if data is None:
            return None
        return cls(
            status=data.get("status"),
            budget_source=data.get("budget_source"),
            max_pending_per_queue=data.get("max_pending_per_queue"),
            approximate_pending_count=data.get("approximate_pending_count"),
            remaining_pending_capacity=data.get("remaining_pending_capacity"),
            lock_required=data.get("lock_required"),
            lock_supported=data.get("lock_supported"),
        )


@dataclass
class TaskQueueAdmission:
    """Server-side admission budgets for workflow, activity, and query tasks."""

    workflow_tasks: TaskQueueTaskAdmission | None = None
    activity_tasks: TaskQueueTaskAdmission | None = None
    query_tasks: TaskQueueQueryAdmission | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any] | None) -> TaskQueueAdmission:
        payload = data or {}
        return cls(
            workflow_tasks=TaskQueueTaskAdmission.from_dict(payload.get("workflow_tasks")),
            activity_tasks=TaskQueueTaskAdmission.from_dict(payload.get("activity_tasks")),
            query_tasks=TaskQueueQueryAdmission.from_dict(payload.get("query_tasks")),
            raw=payload,
        )


@dataclass
class TaskQueueDescription:
    """Current server visibility and admission state for one task queue."""

    name: str
    namespace: str | None = None
    stats: dict[str, Any] | None = None
    admission: TaskQueueAdmission | None = None
    pollers: list[dict[str, Any]] | None = None
    current_leases: list[dict[str, Any]] | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskQueueDescription:
        pollers = data.get("pollers")
        current_leases = data.get("current_leases")
        return cls(
            name=data.get("name", ""),
            namespace=data.get("namespace"),
            stats=data.get("stats"),
            admission=TaskQueueAdmission.from_dict(data.get("admission")),
            pollers=pollers if isinstance(pollers, list) else None,
            current_leases=current_leases if isinstance(current_leases, list) else None,
            raw=data,
        )


@dataclass
class TaskQueueList:
    """One task-queue visibility page returned by the server."""

    namespace: str | None
    task_queues: list[TaskQueueDescription]


@dataclass
class TaskQueueBuildIdCohort:
    """Per-build-id rollout state for one task queue.

    ``build_id`` is ``None`` for the cohort of workers that registered
    without a build identifier (the legacy unversioned default).
    """

    build_id: str | None
    rollout_status: str
    active_worker_count: int
    draining_worker_count: int
    stale_worker_count: int
    total_worker_count: int
    runtimes: list[str]
    sdk_versions: list[str]
    last_heartbeat_at: str | None = None
    first_seen_at: str | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskQueueBuildIdCohort:
        runtimes = data.get("runtimes")
        sdk_versions = data.get("sdk_versions")
        return cls(
            build_id=data.get("build_id"),
            rollout_status=str(data.get("rollout_status") or ""),
            active_worker_count=int(data.get("active_worker_count") or 0),
            draining_worker_count=int(data.get("draining_worker_count") or 0),
            stale_worker_count=int(data.get("stale_worker_count") or 0),
            total_worker_count=int(data.get("total_worker_count") or 0),
            runtimes=[r for r in runtimes if isinstance(r, str)] if isinstance(runtimes, list) else [],
            sdk_versions=[v for v in sdk_versions if isinstance(v, str)] if isinstance(sdk_versions, list) else [],
            last_heartbeat_at=data.get("last_heartbeat_at"),
            first_seen_at=data.get("first_seen_at"),
            raw=data,
        )


@dataclass
class TaskQueueBuildIdRollout:
    """Build-id rollout snapshot returned by the server for one task queue."""

    namespace: str | None
    task_queue: str
    stale_after_seconds: int | None
    build_ids: list[TaskQueueBuildIdCohort]

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskQueueBuildIdRollout:
        items = data.get("build_ids")
        return cls(
            namespace=data.get("namespace"),
            task_queue=str(data.get("task_queue") or ""),
            stale_after_seconds=(
                int(data["stale_after_seconds"])
                if isinstance(data.get("stale_after_seconds"), int)
                else None
            ),
            build_ids=[
                TaskQueueBuildIdCohort.from_dict(item)
                for item in (items if isinstance(items, list) else [])
                if isinstance(item, dict)
            ],
        )


@dataclass
class TaskQueueBuildIdRolloutState:
    """Operator-recorded drain intent for one ``(task_queue, build_id)`` cohort.

    Returned by ``drain_task_queue_build_id`` and ``resume_task_queue_build_id``.
    ``build_id`` is ``None`` for the unversioned cohort (workers registered
    without a build identifier). ``drain_intent`` is ``"active"`` or
    ``"draining"``. ``drained_at`` is set only when ``drain_intent`` is
    ``"draining"``; repeated drains do not shift the timestamp.
    """

    namespace: str | None
    task_queue: str
    build_id: str | None
    drain_intent: str
    drained_at: str | None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> TaskQueueBuildIdRolloutState:
        return cls(
            namespace=data.get("namespace"),
            task_queue=str(data.get("task_queue") or ""),
            build_id=data.get("build_id") if isinstance(data.get("build_id"), str) else None,
            drain_intent=str(data.get("drain_intent") or ""),
            drained_at=data.get("drained_at") if isinstance(data.get("drained_at"), str) else None,
            raw=data,
        )


@dataclass
class WorkerDescription:
    """Current server view of one registered worker."""

    worker_id: str
    task_queue: str | None = None
    runtime: str | None = None
    namespace: str | None = None
    sdk_version: str | None = None
    build_id: str | None = None
    status: str | None = None
    max_concurrent_workflow_tasks: int | None = None
    max_concurrent_activity_tasks: int | None = None
    supported_workflow_types: list[str] | None = None
    supported_activity_types: list[str] | None = None
    last_heartbeat_at: str | None = None
    registered_at: str | None = None
    updated_at: str | None = None
    task_slots: dict[str, int | None] | None = None
    process_metrics: dict[str, Any] | None = None
    heartbeat_interval_seconds: int | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any], *, worker_id: str | None = None) -> WorkerDescription:
        workflow_types = data.get("supported_workflow_types")
        activity_types = data.get("supported_activity_types")
        task_slots = data.get("task_slots")
        process_metrics = data.get("process_metrics")

        return cls(
            worker_id=data.get("worker_id", worker_id or ""),
            task_queue=data.get("task_queue"),
            runtime=data.get("runtime"),
            namespace=data.get("namespace"),
            sdk_version=data.get("sdk_version"),
            build_id=data.get("build_id"),
            status=data.get("status"),
            max_concurrent_workflow_tasks=data.get("max_concurrent_workflow_tasks"),
            max_concurrent_activity_tasks=data.get("max_concurrent_activity_tasks"),
            supported_workflow_types=workflow_types if isinstance(workflow_types, list) else None,
            supported_activity_types=activity_types if isinstance(activity_types, list) else None,
            last_heartbeat_at=data.get("last_heartbeat_at"),
            registered_at=data.get("registered_at"),
            updated_at=data.get("updated_at"),
            task_slots=task_slots if isinstance(task_slots, dict) else None,
            process_metrics=process_metrics if isinstance(process_metrics, dict) else None,
            heartbeat_interval_seconds=(
                int(data["heartbeat_interval_seconds"])
                if isinstance(data.get("heartbeat_interval_seconds"), int)
                else None
            ),
            raw=data,
        )


@dataclass
class WorkerList:
    """Registered worker roster for one namespace."""

    namespace: str | None
    workers: list[WorkerDescription]
    stale_after_seconds: int | None = None


@dataclass
class ScheduleSpec:
    """Calendar or interval rules for a scheduled workflow."""

    cron_expressions: list[str] | None = None
    intervals: list[dict[str, str]] | None = None
    timezone: str | None = None

    def to_dict(self) -> dict[str, Any]:
        d: dict[str, Any] = {}
        if self.cron_expressions is not None:
            d["cron_expressions"] = self.cron_expressions
        if self.intervals is not None:
            d["intervals"] = self.intervals
        if self.timezone is not None:
            d["timezone"] = self.timezone
        return d


@dataclass
class ScheduleAction:
    """Workflow start request issued whenever a schedule fires."""

    workflow_type: str
    task_queue: str | None = None
    input: list[Any] | None = None
    execution_timeout_seconds: int | None = None
    run_timeout_seconds: int | None = None

    def to_dict(
        self,
        *,
        input_encoder: Callable[[list[Any]], dict[str, str]] | None = None,
    ) -> dict[str, Any]:
        d: dict[str, Any] = {"workflow_type": self.workflow_type}
        if self.task_queue is not None:
            d["task_queue"] = self.task_queue
        if self.input is not None:
            d["input"] = input_encoder(self.input) if input_encoder else serializer.envelope(self.input)
        if self.execution_timeout_seconds is not None:
            d["execution_timeout_seconds"] = self.execution_timeout_seconds
        if self.run_timeout_seconds is not None:
            d["run_timeout_seconds"] = self.run_timeout_seconds
        return d


@dataclass
class ScheduleDescription:
    """Current server view of a schedule and its recent execution state."""

    schedule_id: str
    status: str | None = None
    spec: dict[str, Any] | None = None
    action: dict[str, Any] | None = None
    overlap_policy: str | None = None
    note: str | None = None
    memo: dict[str, Any] | None = None
    search_attributes: dict[str, Any] | None = None
    jitter_seconds: int | None = None
    max_runs: int | None = None
    remaining_actions: int | None = None
    fires_count: int = 0
    failures_count: int = 0
    next_fire_at: str | None = None
    last_fired_at: str | None = None
    latest_workflow_instance_id: str | None = None
    paused_at: str | None = None
    created_at: str | None = None
    updated_at: str | None = None
    info: dict[str, Any] | None = None


@dataclass
class ScheduleList:
    """One page of schedule visibility results."""

    schedules: list[ScheduleDescription]
    next_page_token: str | None = None


@dataclass
class ScheduleTriggerResult:
    """Outcome returned after manually triggering a schedule."""

    schedule_id: str
    outcome: str
    workflow_id: str | None = None
    run_id: str | None = None
    reason: str | None = None
    buffer_depth: int | None = None


@dataclass
class ScheduleBackfillResult:
    """Outcome returned after asking a schedule to backfill missed fires."""

    schedule_id: str
    outcome: str
    fires_attempted: int = 0
    results: list[dict[str, Any]] | None = None


@dataclass
class ScheduleHistoryEvent:
    """One entry in a schedule's audit history stream.

    Each event corresponds to a lifecycle transition recorded by the
    server (ScheduleCreated, SchedulePaused, ScheduleResumed,
    ScheduleUpdated, ScheduleTriggered, ScheduleTriggerSkipped, or
    ScheduleDeleted). The ``payload`` mirrors what the workflow engine
    recorded, including command-context attribution when the transition
    came from a mutating API call.
    """

    sequence: int
    event_type: str | None = None
    recorded_at: str | None = None
    workflow_instance_id: str | None = None
    workflow_run_id: str | None = None
    payload: dict[str, Any] | None = None
    id: str | None = None


@dataclass
class ScheduleHistoryPage:
    """One page of a schedule's audit history stream.

    ``next_cursor`` is the ``after_sequence`` value to request the next
    page when ``has_more`` is ``True``; it is ``None`` on the final page.
    """

    schedule_id: str
    events: list[ScheduleHistoryEvent]
    has_more: bool = False
    next_cursor: int | None = None
    namespace: str | None = None


@dataclass
class BridgeAdapterOutcome:
    """Machine-readable result returned by a bridge adapter event."""

    schema: str
    version: int
    adapter: str
    action: str | None
    accepted: bool
    outcome: str
    idempotency_key: str | None = None
    reason: str | None = None
    target: dict[str, Any] | None = None
    correlation: dict[str, Any] | None = None
    workflow_id: str | None = None
    run_id: str | None = None
    workflow_type: str | None = None
    control_plane_outcome: str | None = None
    raw: dict[str, Any] | None = None

    @classmethod
    def from_dict(cls, data: dict[str, Any]) -> BridgeAdapterOutcome:
        return cls(
            schema=str(data.get("schema", "")),
            version=int(data.get("version", 0)),
            adapter=str(data.get("adapter", "")),
            action=data.get("action"),
            accepted=bool(data.get("accepted", False)),
            outcome=str(data.get("outcome", "")),
            idempotency_key=data.get("idempotency_key"),
            reason=data.get("reason"),
            target=data.get("target") if isinstance(data.get("target"), dict) else None,
            correlation=data.get("correlation") if isinstance(data.get("correlation"), dict) else None,
            workflow_id=data.get("workflow_id"),
            run_id=data.get("run_id"),
            workflow_type=data.get("workflow_type"),
            control_plane_outcome=data.get("control_plane_outcome"),
            raw=data,
        )


class WorkflowHandle:
    """Convenience wrapper for operating on one workflow ID."""

    def __init__(self, client: Client, workflow_id: str, run_id: str | None = None, workflow_type: str = "") -> None:
        self._client = client
        self.workflow_id = workflow_id
        self.run_id = run_id
        self.workflow_type = workflow_type

    async def result(self, *, poll_interval: float = 0.5, timeout: float = 30.0) -> Any:
        """Block until this workflow terminates and return its result. See :meth:`Client.get_result`."""
        return await self._client.get_result(self, poll_interval=poll_interval, timeout=timeout)

    async def describe(self) -> WorkflowExecution:
        """Return the server's current view of this workflow. See :meth:`Client.describe_workflow`."""
        return await self._client.describe_workflow(self.workflow_id)

    async def get_history(self) -> Any:
        """Fetch this run's durable history. See :meth:`Client.get_history`."""
        if self.run_id is None:
            raise ValueError("run_id is required to fetch workflow history from a handle")
        return await self._client.get_history(self.workflow_id, self.run_id)

    async def export_history(self) -> Any:
        """Export this run's history as a replay bundle. See :meth:`Client.export_history`."""
        if self.run_id is None:
            raise ValueError("run_id is required to export workflow history from a handle")
        return await self._client.export_history(self.workflow_id, self.run_id)

    async def list_runs(self) -> WorkflowRunList:
        """List all runs in this workflow execution chain. See :meth:`Client.list_workflow_runs`."""
        return await self._client.list_workflow_runs(self.workflow_id)

    async def describe_run(self, run_id: str | None = None) -> WorkflowRun:
        """Return one run's detailed status. See :meth:`Client.describe_workflow_run`."""
        selected_run_id = run_id or self.run_id
        if selected_run_id is None:
            raise ValueError("run_id is required to describe a workflow run from a handle")
        return await self._client.describe_workflow_run(self.workflow_id, selected_run_id)

    async def signal(self, signal_name: str, args: list[Any] | None = None) -> None:
        """Deliver an external signal to this workflow. See :meth:`Client.signal_workflow`."""
        await self._client.signal_workflow(self.workflow_id, signal_name, args=args)

    async def query(self, query_name: str, args: list[Any] | None = None) -> Any:
        """Execute a read-only query against this workflow. See :meth:`Client.query_workflow`."""
        return await self._client.query_workflow(self.workflow_id, query_name, args=args)

    async def cancel(self, *, reason: str | None = None) -> None:
        """Request graceful cancellation of this workflow. See :meth:`Client.cancel_workflow`."""
        await self._client.cancel_workflow(self.workflow_id, reason=reason)

    async def terminate(self, *, reason: str | None = None) -> None:
        """Forcefully stop this workflow. See :meth:`Client.terminate_workflow`."""
        await self._client.terminate_workflow(self.workflow_id, reason=reason)

    async def repair(self) -> WorkflowCommandResult:
        """Ask the server to repair this workflow. See :meth:`Client.repair_workflow`."""
        return await self._client.repair_workflow(self.workflow_id)

    async def archive(self, *, reason: str | None = None) -> WorkflowCommandResult:
        """Move this terminal workflow into the archive tier. See :meth:`Client.archive_workflow`."""
        return await self._client.archive_workflow(self.workflow_id, reason=reason)

    async def update(
        self,
        update_name: str,
        args: list[Any] | None = None,
        *,
        wait_for: str | None = None,
        wait_timeout_seconds: int | None = None,
        request_id: str | None = None,
    ) -> Any:
        """Send a synchronous update to this workflow and wait for the result. See :meth:`Client.update_workflow`."""
        return await self._client.update_workflow(
            self.workflow_id,
            update_name,
            args=args,
            wait_for=wait_for,
            wait_timeout_seconds=wait_timeout_seconds,
            request_id=request_id,
        )


class StandaloneActivityHandle:
    """Convenience wrapper for operating on one standalone activity job.

    Returned by :meth:`Client.start_activity`. The underlying execution is
    a top-level durable job — the server records the activity inside its
    own host run so retries, deadlines, cancellation, and history surface
    through the existing activity infrastructure. The handle exposes the
    job-style operations (``describe``, ``result``, ``cancel``) without
    having to know that there is a host workflow run behind the scenes.
    """

    def __init__(
        self,
        client: Client,
        activity_id: str,
        *,
        workflow_run_id: str | None = None,
        activity_execution_id: str | None = None,
        workflow_type: str = "",
        activity_type: str = "",
    ) -> None:
        self._client = client
        self.activity_id = activity_id
        self.workflow_run_id = workflow_run_id
        self.activity_execution_id = activity_execution_id
        self.workflow_type = workflow_type
        self.activity_type = activity_type

    async def describe(self) -> StandaloneActivityExecution:
        """Fetch the server's current view of this standalone activity.

        See :meth:`Client.describe_activity`.
        """
        return await self._client.describe_activity(self.activity_id)

    async def result(
        self, *, poll_interval: float = 0.5, timeout: float = 30.0
    ) -> Any:
        """Block until the activity reaches a terminal outcome and return its result.

        See :meth:`Client.get_activity_result`.
        """
        return await self._client.get_activity_result(
            self, poll_interval=poll_interval, timeout=timeout
        )

    async def cancel(self, *, reason: str | None = None) -> None:
        """Request graceful cancellation of this standalone activity.

        Cancellation flows through the host run's workflow cancellation
        path; the next heartbeat or attempt boundary observes the request.
        """
        await self._client.cancel_workflow(self.activity_id, reason=reason)


class ScheduleHandle:
    """Convenience wrapper for operating on one schedule ID."""

    def __init__(self, client: Client, schedule_id: str) -> None:
        self._client = client
        self.schedule_id = schedule_id

    async def describe(self) -> ScheduleDescription:
        """Return the server's current view of this schedule. See :meth:`Client.describe_schedule`."""
        return await self._client.describe_schedule(self.schedule_id)

    async def update(
        self,
        *,
        spec: ScheduleSpec | None = None,
        action: ScheduleAction | None = None,
        overlap_policy: str | None = None,
        jitter_seconds: int | None = None,
        max_runs: int | None = None,
        memo: dict[str, Any] | None = None,
        search_attributes: dict[str, Any] | None = None,
        note: str | None = None,
    ) -> None:
        """Update one or more fields of this schedule. See :meth:`Client.update_schedule`."""
        await self._client.update_schedule(
            self.schedule_id,
            spec=spec,
            action=action,
            overlap_policy=overlap_policy,
            jitter_seconds=jitter_seconds,
            max_runs=max_runs,
            memo=memo,
            search_attributes=search_attributes,
            note=note,
        )

    async def pause(self, *, note: str | None = None) -> None:
        """Pause this schedule so it stops firing. See :meth:`Client.pause_schedule`."""
        await self._client.pause_schedule(self.schedule_id, note=note)

    async def resume(self, *, note: str | None = None) -> None:
        """Resume this paused schedule. See :meth:`Client.resume_schedule`."""
        await self._client.resume_schedule(self.schedule_id, note=note)

    async def trigger(self, *, overlap_policy: str | None = None) -> ScheduleTriggerResult:
        """Fire this schedule immediately. See :meth:`Client.trigger_schedule`."""
        return await self._client.trigger_schedule(self.schedule_id, overlap_policy=overlap_policy)

    async def delete(self) -> None:
        """Delete this schedule. See :meth:`Client.delete_schedule`."""
        await self._client.delete_schedule(self.schedule_id)

    async def backfill(
        self,
        *,
        start_time: str,
        end_time: str,
        overlap_policy: str | None = None,
    ) -> ScheduleBackfillResult:
        """Fire this schedule for every moment in a past time range. See :meth:`Client.backfill_schedule`."""
        return await self._client.backfill_schedule(
            self.schedule_id, start_time=start_time, end_time=end_time, overlap_policy=overlap_policy,
        )

    async def history(
        self,
        *,
        limit: int | None = None,
        after_sequence: int | None = None,
    ) -> ScheduleHistoryPage:
        """Return one page of this schedule's audit history. See :meth:`Client.get_schedule_history`."""
        return await self._client.get_schedule_history(
            self.schedule_id,
            limit=limit,
            after_sequence=after_sequence,
        )

    def iter_history(
        self,
        *,
        limit: int | None = None,
        after_sequence: int | None = None,
    ) -> AsyncIterator[ScheduleHistoryEvent]:
        """Iterate every audit event for this schedule. See :meth:`Client.iter_schedule_history`."""
        return self._client.iter_schedule_history(
            self.schedule_id,
            limit=limit,
            after_sequence=after_sequence,
        )


class Client:
    """Async HTTP client for Durable Workflow control-plane and worker APIs.

    The client owns one `httpx.AsyncClient` connection pool. Use it as an async
    context manager or call `aclose()` when finished.
    """

    def __init__(
        self,
        base_url: str,
        *,
        token: str | None = None,
        control_token: str | None = None,
        worker_token: str | None = None,
        namespace: str = "default",
        timeout: float = 60.0,
        retry_policy: TransportRetryPolicy | None = None,
        metrics: MetricsRecorder | None = None,
        payload_size_limit_bytes: int = serializer.DEFAULT_PAYLOAD_SIZE_BYTES,
        payload_size_warning_threshold_percent: int = serializer.DEFAULT_WARNING_THRESHOLD_PERCENT,
        payload_size_warnings: bool = True,
        external_storage: ExternalStorageDriver | None = None,
        external_storage_threshold_bytes: int | None = None,
        external_storage_cache: ExternalPayloadCache | None = None,
    ) -> None:
        self.base_url = base_url.rstrip("/")
        self.token = token
        self.control_token = control_token
        self.worker_token = worker_token
        self.namespace = namespace
        self.retry_policy = retry_policy or TransportRetryPolicy()
        self.metrics = metrics or NOOP_METRICS
        self.payload_size_warning_config = (
            serializer.PayloadSizeWarningConfig(
                limit_bytes=payload_size_limit_bytes,
                threshold_percent=payload_size_warning_threshold_percent,
            )
            if payload_size_warnings
            else None
        )
        if external_storage_threshold_bytes is not None and external_storage_threshold_bytes < 1:
            raise ValueError("external_storage_threshold_bytes must be at least 1 when provided")
        self.external_storage = external_storage
        self.external_storage_threshold_bytes = external_storage_threshold_bytes
        self.external_storage_cache = (
            external_storage_cache
            if external_storage_cache is not None
            else ExternalPayloadCache()
        )
        self._http = httpx.AsyncClient(base_url=self.base_url, timeout=timeout)

    async def aclose(self) -> None:
        """Close the underlying ``httpx`` connection pool.

        Equivalent to exiting the async-context-manager form of the client.
        Safe to call multiple times.
        """
        await self._http.aclose()

    async def __aenter__(self) -> Client:
        return self

    async def __aexit__(self, *exc: Any) -> None:
        await self.aclose()

    def _headers(self, *, worker: bool = False) -> dict[str, str]:
        h: dict[str, str] = {"Content-Type": "application/json", "Accept": "application/json"}
        token = self._auth_token(worker=worker)
        if token:
            h["Authorization"] = f"Bearer {token}"
        h["X-Namespace"] = self.namespace
        if worker:
            h["X-Durable-Workflow-Protocol-Version"] = PROTOCOL_VERSION
        else:
            h["X-Durable-Workflow-Control-Plane-Version"] = CONTROL_PLANE_VERSION
        return h

    def _auth_token(self, *, worker: bool = False) -> str | None:
        if worker:
            return self.worker_token or self.token or self.control_token
        return self.control_token or self.token or self.worker_token

    def _payload_context(
        self,
        *,
        kind: str,
        workflow_id: str | None = None,
        workflow_type: str | None = None,
        run_id: str | None = None,
        activity_name: str | None = None,
        signal_name: str | None = None,
        update_name: str | None = None,
        query_name: str | None = None,
        schedule_id: str | None = None,
        task_queue: str | None = None,
    ) -> serializer.PayloadSizeWarningContext:
        return serializer.PayloadSizeWarningContext(
            kind=kind,
            workflow_id=workflow_id,
            workflow_type=workflow_type,
            run_id=run_id,
            activity_name=activity_name,
            signal_name=signal_name,
            update_name=update_name,
            query_name=query_name,
            schedule_id=schedule_id,
            task_queue=task_queue,
            namespace=self.namespace,
        )

    def _payload_envelope(
        self,
        value: Any,
        *,
        kind: str,
        codec: str = serializer.AVRO_CODEC,
        workflow_id: str | None = None,
        workflow_type: str | None = None,
        run_id: str | None = None,
        activity_name: str | None = None,
        signal_name: str | None = None,
        update_name: str | None = None,
        query_name: str | None = None,
        schedule_id: str | None = None,
        task_queue: str | None = None,
        external_storage: ExternalStorageDriver | None = None,
        external_storage_threshold_bytes: int | None = None,
    ) -> dict[str, Any]:
        warning_context = self._payload_context(
            kind=kind,
            workflow_id=workflow_id,
            workflow_type=workflow_type,
            run_id=run_id,
            activity_name=activity_name,
            signal_name=signal_name,
            update_name=update_name,
            query_name=query_name,
            schedule_id=schedule_id,
            task_queue=task_queue,
        )
        if external_storage_threshold_bytes is not None and external_storage_threshold_bytes < 1:
            raise ValueError("external_storage_threshold_bytes must be at least 1 when provided")
        payload_storage = external_storage if external_storage is not None else self.external_storage
        payload_storage_threshold_bytes = (
            external_storage_threshold_bytes
            if external_storage_threshold_bytes is not None
            else self.external_storage_threshold_bytes
        )
        if payload_storage is not None and payload_storage_threshold_bytes is not None:
            return serializer.external_storage_envelope(
                value,
                external_storage=payload_storage,
                threshold_bytes=payload_storage_threshold_bytes,
                codec=codec,
                size_warning=self.payload_size_warning_config,
                warning_context=warning_context,
            )
        return serializer.envelope(
            value,
            codec=codec,
            size_warning=self.payload_size_warning_config,
            warning_context=warning_context,
        )

    def _warn_json_payload_size(
        self,
        value: Any,
        *,
        kind: str,
        workflow_id: str | None = None,
        schedule_id: str | None = None,
        task_queue: str | None = None,
    ) -> None:
        serializer.warn_if_json_payload_near_limit(
            value,
            size_warning=self.payload_size_warning_config,
            warning_context=self._payload_context(
                kind=kind,
                workflow_id=workflow_id,
                schedule_id=schedule_id,
                task_queue=task_queue,
            ),
        )

    async def _request(
        self,
        method: str,
        path: str,
        *,
        worker: bool = False,
        json: Any = None,
        timeout: float | None = None,
        context: str = "",
    ) -> Any:
        start = time.perf_counter()
        route = _route_for_metrics(path)
        plane = "worker" if worker else "control"
        status_code = "none"
        outcome = "pending"

        async def _do_request() -> httpx.Response:
            resp = await self._http.request(
                method,
                f"/api{path}",
                headers=self._headers(worker=worker),
                json=json,
                timeout=timeout,
            )
            # Raise HTTPStatusError for 4xx/5xx so retry policy can catch it
            resp.raise_for_status()
            return resp

        try:
            try:
                resp = await self.retry_policy.execute(_do_request)
            except httpx.HTTPStatusError as exc:
                status_code = str(exc.response.status_code)
                outcome = "http_error"
                # Convert to our custom exception types
                try:
                    body = exc.response.json()
                except ValueError:
                    body = exc.response.text
                _raise_for_status(exc.response.status_code, body, context=context)
                raise  # unreachable, but keeps type checker happy

            status_code = str(resp.status_code)
            if resp.status_code == 204 or not resp.content:
                outcome = "ok"
                return None
            result = resp.json()
            outcome = "ok"
            return result
        except Exception as exc:
            if outcome == "pending":
                outcome = type(exc).__name__
            raise
        finally:
            tags = {
                "method": method.upper(),
                "route": route,
                "plane": plane,
                "status_code": status_code,
                "outcome": outcome,
            }
            self.metrics.increment(CLIENT_REQUESTS, tags=tags)
            self.metrics.record(CLIENT_REQUEST_DURATION_SECONDS, time.perf_counter() - start, tags=tags)

    async def _request_bridge_outcome(self, path: str, *, json: Any = None, context: str = "") -> dict[str, Any]:
        start = time.perf_counter()
        route = _route_for_metrics(path)
        status_code = "none"
        outcome = "pending"

        async def _do_request() -> httpx.Response:
            resp = await self._http.request(
                "POST",
                f"/api{path}",
                headers=self._headers(worker=False),
                json=json,
            )
            if resp.status_code != 422:
                resp.raise_for_status()
            return resp

        try:
            try:
                resp = await self.retry_policy.execute(_do_request)
            except httpx.HTTPStatusError as exc:
                status_code = str(exc.response.status_code)
                outcome = "http_error"
                try:
                    body = exc.response.json()
                except ValueError:
                    body = exc.response.text
                _raise_for_status(exc.response.status_code, body, context=context)
                raise

            status_code = str(resp.status_code)
            if not resp.content:
                raise ServerError(
                    resp.status_code,
                    {"reason": "invalid_bridge_outcome", "message": "expected JSON object, got empty response"},
                )
            data = resp.json()
            if not isinstance(data, dict):
                raise ServerError(
                    resp.status_code,
                    {
                        "reason": "invalid_bridge_outcome",
                        "message": f"expected JSON object, got {type(data).__name__}",
                    },
                )
            outcome = "bridge_rejected" if resp.status_code == 422 else "ok"
            return data
        except Exception as exc:
            if outcome == "pending":
                outcome = type(exc).__name__
            raise
        finally:
            tags = {
                "method": "POST",
                "route": route,
                "plane": "control",
                "status_code": status_code,
                "outcome": outcome,
            }
            self.metrics.increment(CLIENT_REQUESTS, tags=tags)
            self.metrics.record(CLIENT_REQUEST_DURATION_SECONDS, time.perf_counter() - start, tags=tags)

    async def get_cluster_info(self) -> dict[str, Any]:
        """Fetch server build identity, capabilities, and protocol manifests."""
        result = await self._request("GET", "/cluster/info", worker=False, context="get_cluster_info")
        if not isinstance(result, dict):
            raise ServerError(
                200,
                {"reason": "invalid_cluster_info", "message": f"expected JSON object, got {type(result).__name__}"},
            )
        return result

    def get_workflow_handle(
        self, workflow_id: str, *, run_id: str | None = None, workflow_type: str = ""
    ) -> WorkflowHandle:
        """Return a :class:`WorkflowHandle` bound to an existing workflow instance.

        Does not round-trip to the server. Pass ``run_id`` to pin the handle to
        a specific run, otherwise the handle resolves to whichever run is
        current at the time each method is called. ``workflow_type`` is
        optional and used only in error messages.
        """
        return WorkflowHandle(self, workflow_id=workflow_id, run_id=run_id, workflow_type=workflow_type)

    # ── Health ─────────────────────────────────────────────────────────
    async def health(self) -> dict[str, Any]:
        """Call the server's ``/health`` endpoint and return the JSON response."""
        result = await self._request("GET", "/health")
        if not isinstance(result, dict):
            raise ServerError(
                200,
                {"reason": "invalid_health_response", "message": f"expected JSON object, got {type(result).__name__}"},
            )
        return result

    # ── Namespaces ────────────────────────────────────────────────────
    async def list_namespaces(self) -> NamespaceList:
        """List namespaces visible to the current control-plane identity."""
        data = await self._request("GET", "/namespaces")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_namespace_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        items = data.get("namespaces", [])
        return NamespaceList(
            namespaces=[
                NamespaceDescription.from_dict(item)
                for item in items
                if isinstance(item, dict)
            ],
        )

    async def describe_namespace(self, name: str) -> NamespaceDescription:
        """Return configuration and status for one namespace."""
        data = await self._request("GET", f"/namespaces/{quote(name, safe='')}", context=name)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_namespace_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return NamespaceDescription.from_dict(data)

    async def create_namespace(
        self,
        name: str,
        *,
        description: str | None = None,
        retention_days: int = 30,
    ) -> NamespaceDescription:
        """Create a workflow namespace and return the server representation."""
        data = await self._request(
            "POST",
            "/namespaces",
            json={
                "name": name,
                "description": description,
                "retention_days": retention_days,
            },
            context=name,
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_namespace_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return NamespaceDescription.from_dict(data)

    async def update_namespace(
        self,
        name: str,
        *,
        description: str | None = None,
        retention_days: int | None = None,
    ) -> NamespaceDescription:
        """Update namespace metadata. Only provided fields are sent."""
        body: dict[str, Any] = {}
        if description is not None:
            body["description"] = description
        if retention_days is not None:
            body["retention_days"] = retention_days

        data = await self._request("PUT", f"/namespaces/{quote(name, safe='')}", json=body, context=name)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_namespace_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return NamespaceDescription.from_dict(data)

    async def set_namespace_external_storage(
        self,
        name: str | None = None,
        *,
        driver: str,
        enabled: bool = True,
        threshold_bytes: int | None = None,
        config: dict[str, Any] | None = None,
        namespace: str | None = None,
    ) -> NamespaceDescription:
        """Configure external payload storage for a namespace.

        The first positional argument is the namespace ``name``, matching
        :meth:`describe_namespace`, :meth:`create_namespace`, and
        :meth:`update_namespace`. The ``namespace=`` keyword is accepted as a
        deprecated alias from the 0.4.0 release and emits a
        :class:`DeprecationWarning`; it will be removed in a future release.
        """
        name = _resolve_namespace_name(
            name, namespace, method="set_namespace_external_storage"
        )
        body: dict[str, Any] = {
            "driver": driver,
            "enabled": enabled,
        }
        if threshold_bytes is not None:
            body["threshold_bytes"] = threshold_bytes
        if config is not None:
            body["config"] = config

        data = await self._request(
            "PUT",
            f"/namespaces/{quote(name, safe='')}/external-storage",
            json=body,
            context=name,
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_namespace_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return NamespaceDescription.from_dict(data)

    async def test_external_storage(
        self,
        *,
        driver: str | None = None,
        small_payload_bytes: int | None = None,
        large_payload_bytes: int | None = None,
    ) -> StorageTestResult:
        """Ask the server to verify its configured external payload storage."""
        body: dict[str, Any] = {}
        if small_payload_bytes is not None:
            body["small_payload_bytes"] = small_payload_bytes
        if large_payload_bytes is not None:
            body["large_payload_bytes"] = large_payload_bytes
        if driver is not None:
            body["driver"] = driver

        data = await self._request("POST", "/storage/test", json=body, context=driver or "storage")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_storage_test_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return StorageTestResult.from_dict(data)

    # ── System maintenance ────────────────────────────────────────────
    async def repair_status(self) -> dict[str, Any]:
        """Return the current task repair policy and candidate snapshot.

        Mirrors ``dw system:repair-status``. Operator surface; the caller
        must be authenticated with admin scope.
        """
        data = await self._request("GET", "/system/repair", context="repair_status")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_repair_status_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    async def repair_pass(
        self,
        *,
        run_ids: list[str] | None = None,
        instance_id: str | None = None,
    ) -> dict[str, Any]:
        """Run one task repair sweep on the server.

        Mirrors ``dw system:repair-pass``. Without filters the server runs
        a full-scope pass; pass ``run_ids`` or ``instance_id`` to narrow
        the sweep. Operator surface; requires admin scope.
        """
        body: dict[str, Any] = {}
        if run_ids:
            body["run_ids"] = list(run_ids)
        if instance_id is not None:
            body["instance_id"] = instance_id

        data = await self._request("POST", "/system/repair/pass", json=body, context="repair_pass")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_repair_pass_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    async def retention_status(self) -> dict[str, Any]:
        """Return history-retention diagnostics for the current namespace.

        Mirrors ``dw system:retention-status``. The response reports the
        namespace retention window, the cutoff, and the run IDs currently
        eligible for pruning up to the server's scan limit. Operator
        surface; requires admin scope.
        """
        data = await self._request("GET", "/system/retention", context="retention_status")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_retention_status_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    async def retention_pass(
        self,
        *,
        run_ids: list[str] | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Run one history-retention enforcement sweep on the server.

        Mirrors ``dw system:retention-pass``. Without filters the server
        prunes expired terminal runs from the namespace up to its scan
        limit; pass ``run_ids`` to narrow the sweep or ``limit`` to bound
        how many runs a single pass processes. Operator surface; requires
        admin scope.
        """
        body: dict[str, Any] = {}
        if run_ids:
            body["run_ids"] = list(run_ids)
        if limit is not None:
            body["limit"] = limit

        data = await self._request("POST", "/system/retention/pass", json=body, context="retention_pass")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_retention_pass_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    async def activity_timeout_status(self) -> dict[str, Any]:
        """Return activity-timeout diagnostics for the current namespace.

        Mirrors ``dw system:activity-timeout-status``. The response lists
        activity execution IDs that have passed their start-to-close or
        schedule-to-close deadline and are eligible for forced timeout.
        Operator surface; requires admin scope.
        """
        data = await self._request(
            "GET", "/system/activity-timeouts", context="activity_timeout_status"
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_activity_timeout_status_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    async def activity_timeout_pass(
        self,
        *,
        execution_ids: list[str] | None = None,
        limit: int | None = None,
    ) -> dict[str, Any]:
        """Run one activity-timeout enforcement sweep on the server.

        Mirrors ``dw system:activity-timeout-pass``. Without filters the
        server enforces timeouts for any expired activity executions up
        to its scan limit; pass ``execution_ids`` to narrow the sweep or
        ``limit`` to bound how many executions a single pass processes.
        Operator surface; requires admin scope.
        """
        body: dict[str, Any] = {}
        if execution_ids:
            body["execution_ids"] = list(execution_ids)
        if limit is not None:
            body["limit"] = limit

        data = await self._request(
            "POST",
            "/system/activity-timeouts/pass",
            json=body,
            context="activity_timeout_pass",
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_activity_timeout_pass_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    # ── Task queues ────────────────────────────────────────────────────
    async def list_task_queues(self) -> TaskQueueList:
        """List task queues with server-side admission status.

        Admission data describes server budgets and observed backlog. Worker
        constructor limits remain local semaphores that are advertised during
        registration.
        """
        data = await self._request("GET", "/task-queues")
        items = data.get("task_queues", []) if isinstance(data, dict) else []
        return TaskQueueList(
            namespace=data.get("namespace") if isinstance(data, dict) else None,
            task_queues=[
                TaskQueueDescription.from_dict(item)
                for item in items
                if isinstance(item, dict)
            ],
        )

    async def describe_task_queue(self, name: str) -> TaskQueueDescription:
        """Return backlog, poller, lease, and admission detail for ``name``."""
        data = await self._request("GET", f"/task-queues/{quote(name, safe='')}", context=name)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_task_queue_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return TaskQueueDescription.from_dict(data)

    async def list_task_queue_build_ids(self, task_queue: str) -> TaskQueueBuildIdRollout:
        """Return the build-id rollout snapshot for ``task_queue``.

        Use this before draining or removing an older build to confirm which
        build cohorts can still claim work on the queue. Unversioned workers
        are grouped under a cohort whose ``build_id`` is ``None``.
        """
        data = await self._request(
            "GET",
            f"/task-queues/{quote(task_queue, safe='')}/build-ids",
            context=task_queue,
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_task_queue_build_ids_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return TaskQueueBuildIdRollout.from_dict(data)

    async def drain_task_queue_build_id(
        self,
        task_queue: str,
        build_id: str | None,
    ) -> TaskQueueBuildIdRolloutState:
        """Mark a build-id cohort as draining so it stops claiming new tasks.

        Workers registered under ``build_id`` keep running their in-flight
        work but are blocked from claiming fresh tasks, and future workers
        that heartbeat under the same ``build_id`` land as draining too.
        Pass ``None`` to drain the unversioned cohort (workers registered
        without a build identifier). Idempotent: repeated drains do not
        shift the recorded ``drained_at`` timestamp.
        """
        return await self._mutate_task_queue_build_id_rollout(
            task_queue,
            build_id,
            action="drain",
        )

    async def resume_task_queue_build_id(
        self,
        task_queue: str,
        build_id: str | None,
    ) -> TaskQueueBuildIdRolloutState:
        """Revert a previous drain so a build-id cohort can claim work again.

        Resuming clears both ``drain_intent`` and ``drained_at`` for the
        cohort and flips any still-running workers back to ``active``.
        Pass ``None`` to resume the unversioned cohort. Idempotent:
        resuming an already-active cohort is a no-op.
        """
        return await self._mutate_task_queue_build_id_rollout(
            task_queue,
            build_id,
            action="resume",
        )

    async def _mutate_task_queue_build_id_rollout(
        self,
        task_queue: str,
        build_id: str | None,
        *,
        action: str,
    ) -> TaskQueueBuildIdRolloutState:
        data = await self._request(
            "POST",
            f"/task-queues/{quote(task_queue, safe='')}/build-ids/{action}",
            json={"build_id": build_id},
            context=task_queue,
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": f"invalid_task_queue_build_id_{action}_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return TaskQueueBuildIdRolloutState.from_dict(data)

    # ── Search attributes ─────────────────────────────────────────────
    async def list_search_attributes(self) -> SearchAttributeList:
        """List system and custom search attribute definitions for this namespace."""
        data = await self._request("GET", "/search-attributes")
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_search_attribute_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return SearchAttributeList.from_dict(data)

    async def create_search_attribute(self, name: str, attribute_type: str) -> dict[str, Any]:
        """Register a custom search attribute and return the server response."""
        data = await self._request(
            "POST",
            "/search-attributes",
            json={"name": name, "type": attribute_type},
            context=name,
        )
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_search_attribute_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    async def delete_search_attribute(self, name: str) -> dict[str, Any]:
        """Remove a custom search attribute and return the server response."""
        data = await self._request("DELETE", f"/search-attributes/{quote(name, safe='')}", context=name)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_search_attribute_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    # ── Workers ───────────────────────────────────────────────────────
    async def list_workers(
        self,
        *,
        task_queue: str | None = None,
        status: str | None = None,
    ) -> WorkerList:
        """List registered workers in the current namespace."""
        params: dict[str, str] = {}
        if task_queue is not None:
            params["task_queue"] = task_queue
        if status is not None:
            params["status"] = status

        path = "/workers"
        if params:
            path = f"{path}?{urlencode(params)}"

        data = await self._request("GET", path)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_worker_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        items = data.get("workers", [])

        return WorkerList(
            namespace=data.get("namespace"),
            workers=[
                WorkerDescription.from_dict(item)
                for item in items
                if isinstance(item, dict)
            ],
            stale_after_seconds=(
                int(data["stale_after_seconds"])
                if isinstance(data.get("stale_after_seconds"), int)
                else None
            ),
        )

    async def describe_worker(self, worker_id: str) -> WorkerDescription:
        """Return runtime, capacity, heartbeat, and type support for one worker."""
        data = await self._request("GET", f"/workers/{quote(worker_id, safe='')}", context=worker_id)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_worker_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return WorkerDescription.from_dict(data, worker_id=worker_id)

    async def deregister_worker(self, worker_id: str) -> dict[str, Any]:
        """Remove a stale or retired worker from the server roster."""
        data = await self._request("DELETE", f"/workers/{quote(worker_id, safe='')}", context=worker_id)
        if not isinstance(data, dict):
            raise ServerError(
                200,
                {
                    "reason": "invalid_worker_response",
                    "message": f"expected JSON object, got {type(data).__name__}",
                },
            )
        return data

    # ── Workflows ──────────────────────────────────────────────────────
    async def start_workflow(
        self,
        *,
        workflow_type: str,
        task_queue: str,
        workflow_id: str,
        input: list[Any] | None = None,
        execution_timeout_seconds: int = 3600,
        run_timeout_seconds: int = 600,
        duplicate_policy: str | None = None,
        memo: dict[str, Any] | None = None,
        search_attributes: dict[str, Any] | None = None,
        priority: int | None = None,
        fairness_key: str | None = None,
        fairness_weight: int | None = None,
    ) -> WorkflowHandle:
        """Start a new workflow instance and return a handle bound to it.

        ``workflow_type`` is the language-neutral type key registered via
        :func:`durable_workflow.workflow.defn`. ``task_queue`` selects which
        worker pool picks up the workflow. ``workflow_id`` is the
        caller-supplied instance id — if it collides with an existing
        workflow, behavior depends on ``duplicate_policy``
        (``reject`` | ``allow`` | ``terminate_existing``).

        ``input`` is a list of positional arguments passed to the workflow's
        ``run`` method; the SDK encodes the list with the default payload
        codec (Avro). ``execution_timeout_seconds`` covers the entire workflow
        execution across all runs (including continue-as-new), while
        ``run_timeout_seconds`` applies to this single run only.

        ``memo`` and ``search_attributes`` attach operator-facing metadata to
        the instance; see the main docs site for the key/value rules.

        ``priority`` is an integer in the range ``0..9`` (lower numbers run
        first when workers on a shared task queue are saturated; default
        ``5``). ``fairness_key`` tags the workload class — typically a
        tenant id, team name, or workflow type — so dispatch on a shared
        task queue can be rebalanced across declared classes under
        contention; tasks without a key share one class. ``fairness_weight``
        (``1..1000``, default ``1``) lets a class take a proportionally
        larger share of dispatch slots versus other classes on the same
        queue.
        """
        body: dict[str, Any] = {
            "workflow_id": workflow_id,
            "workflow_type": workflow_type,
            "task_queue": task_queue,
            "input": self._payload_envelope(
                input if input is not None else [],
                kind="workflow_input",
                workflow_id=workflow_id,
                task_queue=task_queue,
            ),
            "execution_timeout_seconds": execution_timeout_seconds,
            "run_timeout_seconds": run_timeout_seconds,
        }
        if duplicate_policy is not None:
            body["duplicate_policy"] = duplicate_policy
        if memo is not None:
            body["memo"] = memo
        if search_attributes is not None:
            self._warn_json_payload_size(
                search_attributes,
                kind="search_attributes",
                workflow_id=workflow_id,
                task_queue=task_queue,
            )
            body["search_attributes"] = search_attributes
        if priority is not None:
            body["priority"] = priority
        if fairness_key is not None:
            body["fairness_key"] = fairness_key
        if fairness_weight is not None:
            body["fairness_weight"] = fairness_weight
        data = await self._request("POST", "/workflows", json=body, context=workflow_id)
        return WorkflowHandle(
            self,
            workflow_id=data["workflow_id"],
            run_id=data.get("run_id"),
            workflow_type=data["workflow_type"],
        )

    async def describe_workflow(self, workflow_id: str) -> WorkflowExecution:
        """Return the server's current view of a workflow instance.

        Resolves to the newest durable run in the instance's chain (including
        any continue-as-new runs). Decodes the recorded ``input`` and
        ``output`` envelopes when present.
        """
        data = await self._request("GET", f"/workflows/{workflow_id}", context=workflow_id)
        input_val = data.get("input")
        output_val = data.get("output")
        envelope_jobs: list[tuple[str, Any]] = []
        if data.get("input_envelope"):
            envelope_jobs.append(("input", data["input_envelope"]))
        if data.get("output_envelope"):
            envelope_jobs.append(("output", data["output_envelope"]))
        if envelope_jobs:
            decoded = serializer.decode_envelopes(
                [envelope for _, envelope in envelope_jobs],
                external_storage=self.external_storage,
                external_storage_cache=self.external_storage_cache,
            )
            for (field, _), value in zip(envelope_jobs, decoded, strict=True):
                if field == "input":
                    input_val = value
                else:
                    output_val = value
        return WorkflowExecution(
            workflow_id=data.get("workflow_id", workflow_id),
            run_id=data.get("run_id"),
            workflow_type=data.get("workflow_type", ""),
            status=data.get("status"),
            namespace=data.get("namespace"),
            task_queue=data.get("task_queue"),
            input=input_val,
            output=output_val,
            payload_codec=data.get("payload_codec"),
        )

    async def list_workflows(
        self,
        *,
        workflow_type: str | None = None,
        status: str | None = None,
        query: str | None = None,
        page_size: int | None = None,
        next_page_token: str | None = None,
    ) -> WorkflowList:
        """Page through workflow instances, optionally filtered by type, status, or query string.

        Pass the returned :attr:`WorkflowList.next_page_token` as
        ``next_page_token`` on the next call to fetch the following page; the
        token is ``None`` when there are no more pages.
        """
        params: dict[str, str] = {}
        if workflow_type is not None:
            params["workflow_type"] = workflow_type
        if status is not None:
            params["status"] = status
        if query is not None:
            params["query"] = query
        if page_size is not None:
            params["page_size"] = str(page_size)
        if next_page_token is not None:
            params["next_page_token"] = next_page_token

        qs = urlencode(params)
        path = f"/workflows?{qs}" if qs else "/workflows"
        data = await self._request("GET", path)
        items = data.get("workflows", [])
        executions = [
            WorkflowExecution(
                workflow_id=item.get("workflow_id", ""),
                run_id=item.get("run_id"),
                workflow_type=item.get("workflow_type", ""),
                status=item.get("status"),
            )
            for item in items
        ]
        return WorkflowList(
            executions=executions,
            next_page_token=data.get("next_page_token"),
        )

    async def get_history(self, workflow_id: str, run_id: str) -> Any:
        """Fetch the full durable history for one specific run of a workflow."""
        return await self._request(
            "GET", f"/workflows/{workflow_id}/runs/{run_id}/history", context=workflow_id
        )

    async def export_history(self, workflow_id: str, run_id: str) -> Any:
        """Export one workflow run history as a replay bundle."""
        return await self._request(
            "GET", f"/workflows/{workflow_id}/runs/{run_id}/history/export", context=workflow_id
        )

    async def list_workflow_runs(self, workflow_id: str) -> WorkflowRunList:
        """List all durable runs in one workflow execution chain, oldest first."""
        data = await self._request("GET", f"/workflows/{workflow_id}/runs", context=workflow_id)
        runs = [
            WorkflowRun.from_dict(item, workflow_id=data.get("workflow_id", workflow_id))
            for item in data.get("runs", [])
        ]
        return WorkflowRunList(
            workflow_id=data.get("workflow_id", workflow_id),
            run_count=data.get("run_count", len(runs)),
            runs=runs,
        )

    async def describe_workflow_run(self, workflow_id: str, run_id: str) -> WorkflowRun:
        """Return detailed status, payload, and actionability for one specific workflow run."""
        data = await self._request("GET", f"/workflows/{workflow_id}/runs/{run_id}", context=workflow_id)
        return WorkflowRun.from_dict(data, workflow_id=workflow_id, run_id=run_id)

    # ── Standalone Activities ─────────────────────────────────────────
    #
    # Activities can run as top-level durable jobs without a wrapper
    # workflow. The same activity definition registered via
    # ``@activity.defn(name=...)`` is reusable inside a workflow's
    # ``activity()`` invocation and as a standalone job — the server
    # handles dispatch, retry, deadline, cancellation, and history
    # projection through the existing activity infrastructure.

    async def start_activity(
        self,
        *,
        activity_type: str,
        task_queue: str,
        activity_id: str | None = None,
        activity_class: str | None = None,
        input: list[Any] | None = None,
        business_key: str | None = None,
        retry_policy: dict[str, Any] | None = None,
        start_to_close_timeout_seconds: int | None = None,
        schedule_to_start_timeout_seconds: int | None = None,
        schedule_to_close_timeout_seconds: int | None = None,
        heartbeat_timeout_seconds: int | None = None,
    ) -> StandaloneActivityHandle:
        """Start a standalone activity and return a handle bound to it.

        ``activity_type`` is the language-neutral activity type key
        registered via :func:`durable_workflow.activity.defn`. The same
        activity definition can be invoked inside a workflow with the
        worker's ``activity()`` call and also dispatched here as a
        top-level durable job — there is no separate "job activity"
        decorator. ``task_queue`` selects the worker pool that will run
        the activity.

        ``activity_id`` is an optional caller-supplied identifier (must be
        URL-safe; same character rules as ``workflow_id``). When omitted,
        the server generates one. ``activity_class`` is an optional
        free-form label that surfaces on the listing/show endpoints — it
        does not affect dispatch.

        ``input`` is a list of positional arguments passed to the
        activity, encoded with the default payload codec.
        ``retry_policy`` follows the same shape used inside a workflow
        (``max_attempts``, ``backoff_seconds``,
        ``non_retryable_error_types``). The four timeout knobs map
        one-to-one onto the same fields applied to activities scheduled
        from inside a workflow.

        Returns a :class:`StandaloneActivityHandle` so the caller can
        inspect the activity, await its result, or cancel it without
        having to know that the server records the work inside a host
        workflow run.
        """
        body: dict[str, Any] = {
            "activity_type": activity_type,
            "task_queue": task_queue,
        }
        if activity_id is not None:
            body["activity_id"] = activity_id
        if activity_class is not None:
            body["activity_class"] = activity_class
        if business_key is not None:
            body["business_key"] = business_key
        if input is not None:
            body["input"] = self._payload_envelope(
                input,
                kind="activity_input",
                activity_name=activity_type,
                task_queue=task_queue,
            )
        if retry_policy is not None:
            body["retry_policy"] = retry_policy
        if start_to_close_timeout_seconds is not None:
            body["start_to_close_timeout_seconds"] = start_to_close_timeout_seconds
        if schedule_to_start_timeout_seconds is not None:
            body["schedule_to_start_timeout_seconds"] = schedule_to_start_timeout_seconds
        if schedule_to_close_timeout_seconds is not None:
            body["schedule_to_close_timeout_seconds"] = schedule_to_close_timeout_seconds
        if heartbeat_timeout_seconds is not None:
            body["heartbeat_timeout_seconds"] = heartbeat_timeout_seconds

        data = await self._request(
            "POST",
            "/activities",
            json=body,
            context=activity_id or activity_type,
        )

        return StandaloneActivityHandle(
            self,
            activity_id=data.get("activity_id", activity_id or ""),
            workflow_run_id=data.get("workflow_run_id"),
            activity_execution_id=data.get("activity_execution_id"),
            workflow_type=data.get("workflow_type", ""),
            activity_type=data.get("activity_type", activity_type),
        )

    def get_activity_handle(
        self,
        activity_id: str,
        *,
        workflow_run_id: str | None = None,
        activity_execution_id: str | None = None,
        activity_type: str = "",
    ) -> StandaloneActivityHandle:
        """Return a :class:`StandaloneActivityHandle` bound to an existing
        standalone activity. Does not round-trip to the server.
        """
        return StandaloneActivityHandle(
            self,
            activity_id=activity_id,
            workflow_run_id=workflow_run_id,
            activity_execution_id=activity_execution_id,
            activity_type=activity_type,
        )

    async def describe_activity(self, activity_id: str) -> StandaloneActivityExecution:
        """Return the server's current view of one standalone activity.

        The returned ``result`` field is decoded from the server's payload
        envelope when the activity has completed; for not-yet-terminal
        activities it is ``None``.
        """
        data = await self._request(
            "GET", f"/activities/{quote(activity_id, safe='._:-')}", context=activity_id
        )
        result_envelope = data.get("result")
        result_value: Any = None
        if (
            isinstance(result_envelope, dict)
            and (result_envelope.get("blob") is not None or result_envelope.get("external_storage") is not None)
        ):
            result_value = serializer.decode_envelope(
                result_envelope,
                codec=result_envelope.get("codec") or data.get("payload_codec"),
                external_storage=self.external_storage,
                external_storage_cache=self.external_storage_cache,
            )
        return StandaloneActivityExecution.from_dict(
            data,
            activity_id=activity_id,
            result=result_value,
        )

    async def list_activities(
        self,
        *,
        status: str | None = None,
        page_size: int | None = None,
        next_page_token: str | None = None,
    ) -> StandaloneActivityList:
        """Page through standalone activities visible to the calling namespace.

        ``status`` filters on the host-run status bucket and accepts
        ``running``, ``completed``, or ``failed``.
        """
        params: dict[str, str] = {}
        if status is not None:
            params["status"] = status
        if page_size is not None:
            params["page_size"] = str(page_size)
        if next_page_token is not None:
            params["next_page_token"] = next_page_token

        qs = urlencode(params)
        path = f"/activities?{qs}" if qs else "/activities"
        data = await self._request("GET", path)
        items = data.get("activities", [])
        executions = [
            StandaloneActivityExecution.from_dict(item)
            for item in items
        ]
        return StandaloneActivityList(
            activities=executions,
            activity_count=data.get("activity_count", len(executions)),
            next_page_token=data.get("next_page_token"),
        )

    async def get_activity_result(
        self,
        handle: StandaloneActivityHandle,
        *,
        poll_interval: float = 0.5,
        timeout: float = 30.0,
    ) -> Any:
        """Poll a standalone activity until it reaches a terminal outcome.

        Returns the decoded activity result on success, raises
        :class:`~durable_workflow.errors.WorkflowFailed` on failure (the
        host run carries the activity's failure as its terminal state),
        :class:`~durable_workflow.errors.WorkflowCancelled` /
        :class:`~durable_workflow.errors.WorkflowTerminated` for the
        respective lifecycle outcomes, or :class:`TimeoutError` if the
        activity is still running after ``timeout`` seconds.
        """
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            desc = await self.describe_activity(handle.activity_id)
            status = desc.status
            if status in ("completed", "failed", "terminated", "canceled", "cancelled"):
                if status == "completed":
                    return desc.result
                if status == "failed":
                    raise WorkflowFailed(
                        f"standalone activity {handle.activity_id} failed",
                    )
                if status == "terminated":
                    raise WorkflowTerminated(
                        desc.closed_reason or "standalone activity was terminated",
                    )
                raise WorkflowCancelled(
                    desc.closed_reason or "standalone activity was cancelled",
                )
            if asyncio.get_running_loop().time() > deadline:
                raise TimeoutError(
                    f"standalone activity {handle.activity_id} not terminal after {timeout}s "
                    f"(status={status})"
                )
            await asyncio.sleep(poll_interval)

    async def send_webhook_bridge_event(
        self,
        adapter: str,
        *,
        action: str,
        idempotency_key: str,
        target: dict[str, Any],
        input: dict[str, Any] | None = None,
        correlation: dict[str, Any] | None = None,
    ) -> BridgeAdapterOutcome:
        """Send one bounded webhook bridge event and return its contract outcome.

        The bridge endpoint intentionally returns machine-readable rejected
        outcomes as HTTP 422. This method returns those outcomes instead of
        raising :class:`InvalidArgument`, while auth and unexpected server
        failures still use the normal SDK exception mapping.
        """
        body: dict[str, Any] = {
            "action": action,
            "idempotency_key": idempotency_key,
            "target": target,
        }
        if input is not None:
            body["input"] = input
        if correlation is not None:
            body["correlation"] = correlation

        data = await self._request_bridge_outcome(
            f"/bridge-adapters/webhook/{quote(adapter, safe='._:-')}",
            json=body,
            context=f"bridge adapter {adapter}",
        )
        return BridgeAdapterOutcome.from_dict(data)

    async def signal_workflow(
        self, workflow_id: str, signal_name: str, *, args: list[Any] | None = None
    ) -> None:
        """Deliver an external signal to a running workflow.

        Signals are fire-and-forget: the server records the signal in durable
        history and returns immediately. They do not wait for the workflow to
        observe the signal. See the main docs for how to declare the allowed
        signal names on a workflow type.
        """
        body: dict[str, Any] = {}
        if args:
            body["input"] = self._payload_envelope(
                args,
                kind="signal",
                workflow_id=workflow_id,
                signal_name=signal_name,
            )
        await self._request("POST", f"/workflows/{workflow_id}/signal/{signal_name}", json=body, context=workflow_id)

    async def query_workflow(
        self, workflow_id: str, query_name: str, *, args: list[Any] | None = None
    ) -> Any:
        """Execute a named read-only query against a workflow and return the result.

        Queries are synchronous and non-mutating. The server runs the named
        query handler inside the workflow process and returns the decoded
        result. Raises :class:`~durable_workflow.errors.QueryFailed` if the
        query was rejected or the handler errored.
        """
        body: dict[str, Any] = {}
        if args:
            body["input"] = self._payload_envelope(
                args,
                kind="query",
                workflow_id=workflow_id,
                query_name=query_name,
            )
        return await self._request(
            "POST", f"/workflows/{workflow_id}/query/{query_name}", json=body, context=workflow_id
        )

    async def cancel_workflow(self, workflow_id: str, *, reason: str | None = None) -> None:
        """Request graceful cancellation of a workflow's current run.

        Cancellation is cooperative: the server delivers a cancellation signal
        that the workflow can observe and handle (e.g. to roll back via a
        saga). Compare with :meth:`terminate_workflow`, which is forceful.
        """
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        await self._request("POST", f"/workflows/{workflow_id}/cancel", json=body, context=workflow_id)

    async def terminate_workflow(self, workflow_id: str, *, reason: str | None = None) -> None:
        """Forcefully stop a workflow without giving it a chance to clean up.

        Prefer :meth:`cancel_workflow` when the workflow code can implement
        graceful shutdown. Termination is an operator escape hatch.
        """
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        await self._request("POST", f"/workflows/{workflow_id}/terminate", json=body, context=workflow_id)

    async def repair_workflow(self, workflow_id: str) -> WorkflowCommandResult:
        """Ask the server to repair a stalled workflow, returning the command outcome."""
        data = await self._request("POST", f"/workflows/{workflow_id}/repair", json={}, context=workflow_id)
        return WorkflowCommandResult.from_dict(data, workflow_id=workflow_id)

    async def archive_workflow(self, workflow_id: str, *, reason: str | None = None) -> WorkflowCommandResult:
        """Move a terminal workflow into the archive tier, returning the command outcome."""
        body: dict[str, Any] = {}
        if reason is not None:
            body["reason"] = reason
        data = await self._request("POST", f"/workflows/{workflow_id}/archive", json=body, context=workflow_id)
        return WorkflowCommandResult.from_dict(data, workflow_id=workflow_id)

    async def update_workflow(
        self,
        workflow_id: str,
        update_name: str,
        *,
        args: list[Any] | None = None,
        wait_for: str | None = None,
        wait_timeout_seconds: int | None = None,
        request_id: str | None = None,
    ) -> Any:
        """Send a synchronous update to a running workflow and wait for the result.

        Updates are request/response calls to a named handler on the workflow;
        the handler may mutate durable workflow state and return a value.
        ``wait_for`` selects how long the server waits before returning —
        typically ``completed`` to block until the handler finishes, or
        ``accepted`` to return once the validator has approved it.

        ``request_id`` lets the caller deduplicate retries. Raises
        :class:`~durable_workflow.errors.UpdateRejected` when the workflow's
        validator rejects the update.
        """
        body: dict[str, Any] = {}
        if args:
            body["input"] = self._payload_envelope(
                args,
                kind="update",
                workflow_id=workflow_id,
                update_name=update_name,
            )
        if wait_for is not None:
            body["wait_for"] = wait_for
        if wait_timeout_seconds is not None:
            body["wait_timeout_seconds"] = wait_timeout_seconds
        if request_id is not None:
            body["request_id"] = request_id
        return await self._request(
            "POST", f"/workflows/{workflow_id}/update/{update_name}", json=body, context=workflow_id
        )

    async def get_result(
        self,
        handle: WorkflowHandle,
        *,
        poll_interval: float = 0.5,
        timeout: float = 30.0,
    ) -> Any:
        """Poll a workflow until it reaches a terminal state and return its result.

        Raises :class:`~durable_workflow.errors.WorkflowFailed`,
        :class:`~durable_workflow.errors.WorkflowCancelled`, or
        :class:`~durable_workflow.errors.WorkflowTerminated` if the workflow
        ended in a non-success state, or :class:`TimeoutError` if ``timeout``
        seconds elapse before the workflow terminates.
        """
        deadline = asyncio.get_running_loop().time() + timeout
        while True:
            desc = await self.describe_workflow(handle.workflow_id)
            status = desc.status
            if status in ("completed", "failed", "terminated", "canceled", "cancelled"):
                run_id = handle.run_id or desc.run_id
                if run_id is None:
                    raise WorkflowFailed("no run_id available to fetch history")
                history = await self.get_history(handle.workflow_id, run_id)
                events = history.get("events", [])
                for ev in reversed(events):
                    etype = ev.get("event_type")
                    payload = ev.get("payload") or {}
                    if etype == "WorkflowCompleted":
                        return serializer.decode_envelope(
                            payload.get("output"),
                            codec=payload.get("payload_codec") or desc.payload_codec,
                            external_storage=self.external_storage,
                            external_storage_cache=self.external_storage_cache,
                        )
                    if etype == "WorkflowFailed":
                        raise WorkflowFailed(
                            payload.get("message", "workflow failed"),
                            payload.get("exception_class"),
                        )
                    if etype == "WorkflowTerminated":
                        raise WorkflowTerminated(
                            payload.get("reason", "workflow was terminated")
                        )
                    if etype == "WorkflowCancelled":
                        raise WorkflowCancelled(
                            payload.get("reason", "workflow was cancelled")
                        )
                return None
            if asyncio.get_running_loop().time() > deadline:
                raise TimeoutError(
                    f"workflow {handle.workflow_id} not terminal after {timeout}s (status={status})"
                )
            await asyncio.sleep(poll_interval)

    # ── Schedules ─────────────────────────────────────────────────────
    def get_schedule_handle(self, schedule_id: str) -> ScheduleHandle:
        """Return a :class:`ScheduleHandle` bound to an existing schedule.

        Does not round-trip to the server. Use :meth:`describe_schedule` via
        the handle when you need to verify the schedule actually exists.
        """
        return ScheduleHandle(self, schedule_id=schedule_id)

    async def create_schedule(
        self,
        *,
        schedule_id: str | None = None,
        spec: ScheduleSpec,
        action: ScheduleAction,
        overlap_policy: str | None = None,
        jitter_seconds: int | None = None,
        max_runs: int | None = None,
        memo: dict[str, Any] | None = None,
        search_attributes: dict[str, Any] | None = None,
        paused: bool = False,
        note: str | None = None,
    ) -> ScheduleHandle:
        """Create a new schedule and return a handle bound to it.

        ``spec`` describes when the schedule fires (cron expressions,
        intervals, calendars); ``action`` describes what it starts (typically
        a workflow). ``overlap_policy`` controls what happens when a fire
        would overlap an already-running action — ``skip``, ``buffer_one``,
        ``buffer_all``, ``cancel_other``, or ``terminate_other``. Pass
        ``paused=True`` to create the schedule in a paused state and resume
        it later with :meth:`resume_schedule`.
        """
        body: dict[str, Any] = {
            "spec": spec.to_dict(),
            "action": action.to_dict(
                input_encoder=lambda value: self._payload_envelope(
                    value,
                    kind="schedule_input",
                    workflow_type=action.workflow_type,
                    schedule_id=schedule_id,
                    task_queue=action.task_queue,
                )
            ),
        }
        if schedule_id is not None:
            body["schedule_id"] = schedule_id
        if overlap_policy is not None:
            body["overlap_policy"] = overlap_policy
        if jitter_seconds is not None:
            body["jitter_seconds"] = jitter_seconds
        if max_runs is not None:
            body["max_runs"] = max_runs
        if memo is not None:
            body["memo"] = memo
        if search_attributes is not None:
            self._warn_json_payload_size(
                search_attributes,
                kind="schedule_search_attributes",
                schedule_id=schedule_id,
            )
            body["search_attributes"] = search_attributes
        if paused:
            body["paused"] = True
        if note is not None:
            body["note"] = note
        data = await self._request("POST", "/schedules", json=body)
        sid = data.get("schedule_id", schedule_id or "")
        return ScheduleHandle(self, schedule_id=sid)

    async def list_schedules(self) -> ScheduleList:
        """Return all schedules in the current namespace."""
        data = await self._request("GET", "/schedules")
        items = data.get("schedules", [])
        schedules = [
            ScheduleDescription(
                schedule_id=item.get("schedule_id", ""),
                status=item.get("status"),
                spec=item.get("spec"),
                action=item.get("action"),
                overlap_policy=item.get("overlap_policy"),
                note=item.get("note"),
                fires_count=item.get("fires_count", 0),
                next_fire_at=item.get("next_fire_at"),
                last_fired_at=item.get("last_fired_at"),
            )
            for item in items
        ]
        return ScheduleList(
            schedules=schedules,
            next_page_token=data.get("next_page_token"),
        )

    async def describe_schedule(self, schedule_id: str) -> ScheduleDescription:
        """Return the server's current view of a schedule, including status and fire counters."""
        data = await self._request("GET", f"/schedules/{schedule_id}", context=schedule_id)
        return ScheduleDescription(
            schedule_id=data.get("schedule_id", schedule_id),
            status=data.get("status"),
            spec=data.get("spec"),
            action=data.get("action"),
            overlap_policy=data.get("overlap_policy"),
            note=data.get("note"),
            memo=data.get("memo"),
            search_attributes=data.get("search_attributes"),
            jitter_seconds=data.get("jitter_seconds"),
            max_runs=data.get("max_runs"),
            remaining_actions=data.get("remaining_actions"),
            fires_count=data.get("fires_count", 0),
            failures_count=data.get("failures_count", 0),
            next_fire_at=data.get("next_fire_at"),
            last_fired_at=data.get("last_fired_at"),
            latest_workflow_instance_id=data.get("latest_workflow_instance_id"),
            paused_at=data.get("paused_at"),
            created_at=data.get("created_at"),
            updated_at=data.get("updated_at"),
            info=data.get("info"),
        )

    async def update_schedule(
        self,
        schedule_id: str,
        *,
        spec: ScheduleSpec | None = None,
        action: ScheduleAction | None = None,
        overlap_policy: str | None = None,
        jitter_seconds: int | None = None,
        max_runs: int | None = None,
        memo: dict[str, Any] | None = None,
        search_attributes: dict[str, Any] | None = None,
        note: str | None = None,
    ) -> None:
        """Update one or more fields of an existing schedule.

        Pass ``None`` for any field you don't want to change. Unknown fields
        are ignored by the server.
        """
        body: dict[str, Any] = {}
        if spec is not None:
            body["spec"] = spec.to_dict()
        if action is not None:
            body["action"] = action.to_dict(
                input_encoder=lambda value: self._payload_envelope(
                    value,
                    kind="schedule_input",
                    workflow_type=action.workflow_type,
                    schedule_id=schedule_id,
                    task_queue=action.task_queue,
                )
            )
        if overlap_policy is not None:
            body["overlap_policy"] = overlap_policy
        if jitter_seconds is not None:
            body["jitter_seconds"] = jitter_seconds
        if max_runs is not None:
            body["max_runs"] = max_runs
        if memo is not None:
            body["memo"] = memo
        if search_attributes is not None:
            self._warn_json_payload_size(
                search_attributes,
                kind="schedule_search_attributes",
                schedule_id=schedule_id,
            )
            body["search_attributes"] = search_attributes
        if note is not None:
            body["note"] = note
        await self._request("PUT", f"/schedules/{schedule_id}", json=body, context=schedule_id)

    async def pause_schedule(self, schedule_id: str, *, note: str | None = None) -> None:
        """Pause a schedule so it stops firing until resumed.

        Optional ``note`` is recorded as operator metadata on the pause
        event. Pausing does not cancel workflows that are already running.
        """
        body: dict[str, Any] = {}
        if note is not None:
            body["note"] = note
        await self._request("POST", f"/schedules/{schedule_id}/pause", json=body, context=schedule_id)

    async def resume_schedule(self, schedule_id: str, *, note: str | None = None) -> None:
        """Resume a paused schedule so it begins firing again."""
        body: dict[str, Any] = {}
        if note is not None:
            body["note"] = note
        await self._request("POST", f"/schedules/{schedule_id}/resume", json=body, context=schedule_id)

    async def trigger_schedule(
        self, schedule_id: str, *, overlap_policy: str | None = None
    ) -> ScheduleTriggerResult:
        """Fire a schedule immediately, outside its normal schedule.

        The ``overlap_policy`` override applies only to this one manual fire.
        The returned :class:`ScheduleTriggerResult` reports whether the fire
        was accepted or skipped (e.g. due to overlap).
        """
        body: dict[str, Any] = {}
        if overlap_policy is not None:
            body["overlap_policy"] = overlap_policy
        data = await self._request(
            "POST", f"/schedules/{schedule_id}/trigger", json=body, context=schedule_id,
        )
        return ScheduleTriggerResult(
            schedule_id=data.get("schedule_id", schedule_id),
            outcome=data.get("outcome", ""),
            workflow_id=data.get("workflow_id"),
            run_id=data.get("run_id"),
            reason=data.get("reason"),
            buffer_depth=data.get("buffer_depth"),
        )

    async def delete_schedule(self, schedule_id: str) -> None:
        """Delete a schedule. Running workflows the schedule already started are unaffected."""
        await self._request("DELETE", f"/schedules/{schedule_id}", context=schedule_id)

    async def backfill_schedule(
        self,
        schedule_id: str,
        *,
        start_time: str,
        end_time: str,
        overlap_policy: str | None = None,
    ) -> ScheduleBackfillResult:
        """Fire a schedule for every would-have-been moment in ``[start_time, end_time]``.

        Times are ISO-8601 strings. Useful to replay a period the schedule
        was paused or to seed historical runs. The returned
        :class:`ScheduleBackfillResult` reports how many fires were attempted
        and the outcome of each.
        """
        body: dict[str, Any] = {
            "start_time": start_time,
            "end_time": end_time,
        }
        if overlap_policy is not None:
            body["overlap_policy"] = overlap_policy
        data = await self._request(
            "POST", f"/schedules/{schedule_id}/backfill", json=body, context=schedule_id,
        )
        return ScheduleBackfillResult(
            schedule_id=data.get("schedule_id", schedule_id),
            outcome=data.get("outcome", ""),
            fires_attempted=data.get("fires_attempted", 0),
            results=data.get("results"),
        )

    async def get_schedule_history(
        self,
        schedule_id: str,
        *,
        limit: int | None = None,
        after_sequence: int | None = None,
    ) -> ScheduleHistoryPage:
        """Return one page of the audit history stream for a schedule.

        The page is ordered by ``sequence`` ascending. Use
        ``after_sequence=page.next_cursor`` to request the next page while
        ``page.has_more`` is ``True``, or call :meth:`iter_schedule_history`
        to walk every remaining event with paging hidden.

        History is available for deleted schedules: the audit stream
        records ``ScheduleDeleted`` and survives the schedule's removal
        exactly so operators can review what happened.

        ``limit`` is clamped by the server between 1 and 500 (default
        100). ``after_sequence`` must be a non-negative integer; invalid
        values raise :class:`~durable_workflow.errors.InvalidArgument`
        through the shared 4xx mapping.
        """
        if limit is not None and limit < 1:
            raise ValueError("limit must be >= 1")
        if after_sequence is not None and after_sequence < 0:
            raise ValueError("after_sequence must be >= 0")

        params: dict[str, str] = {}
        if limit is not None:
            params["limit"] = str(limit)
        if after_sequence is not None:
            params["after_sequence"] = str(after_sequence)

        path = f"/schedules/{schedule_id}/history"
        if params:
            path = f"{path}?{urlencode(params)}"

        data = await self._request("GET", path, context=schedule_id)
        raw_events = data.get("events") or []
        events = [
            ScheduleHistoryEvent(
                sequence=int(item.get("sequence", 0)),
                event_type=item.get("event_type"),
                recorded_at=item.get("recorded_at"),
                workflow_instance_id=item.get("workflow_instance_id"),
                workflow_run_id=item.get("workflow_run_id"),
                payload=item.get("payload") if isinstance(item.get("payload"), dict) else None,
                id=item.get("id"),
            )
            for item in raw_events
        ]

        raw_cursor = data.get("next_cursor")
        next_cursor: int | None
        if raw_cursor is None:
            next_cursor = None
        else:
            try:
                next_cursor = int(raw_cursor)
            except (TypeError, ValueError):
                next_cursor = None

        return ScheduleHistoryPage(
            schedule_id=data.get("schedule_id", schedule_id),
            events=events,
            has_more=bool(data.get("has_more", False)),
            next_cursor=next_cursor,
            namespace=data.get("namespace"),
        )

    async def iter_schedule_history(
        self,
        schedule_id: str,
        *,
        limit: int | None = None,
        after_sequence: int | None = None,
    ) -> AsyncIterator[ScheduleHistoryEvent]:
        """Yield every audit event for a schedule, paging under the hood.

        Each element is a :class:`ScheduleHistoryEvent`. Paging stops once
        the server reports ``has_more=False``.
        """
        cursor = after_sequence
        while True:
            page = await self.get_schedule_history(
                schedule_id,
                limit=limit,
                after_sequence=cursor,
            )
            for event in page.events:
                yield event
            if not page.has_more or page.next_cursor is None:
                return
            cursor = page.next_cursor

    # ── Worker protocol ────────────────────────────────────────────────
    async def register_worker(
        self,
        *,
        worker_id: str,
        task_queue: str,
        supported_workflow_types: list[str] | None = None,
        workflow_definition_fingerprints: dict[str, str] | None = None,
        supported_activity_types: list[str] | None = None,
        max_concurrent_workflow_tasks: int | None = None,
        max_concurrent_activity_tasks: int | None = None,
        runtime: str = "python",
        sdk_version: str | None = None,
        build_id: str | None = None,
    ) -> Any:
        """Register this process with the server as a worker for ``task_queue``.

        Called by :class:`~durable_workflow.Worker` at startup. Most
        applications should not call this directly — create a
        :class:`~durable_workflow.Worker` instead.
        """
        if sdk_version is None:
            sdk_version = DEFAULT_SDK_VERSION
        if max_concurrent_workflow_tasks is not None and max_concurrent_workflow_tasks < 1:
            raise ValueError("max_concurrent_workflow_tasks must be at least 1")
        if max_concurrent_activity_tasks is not None and max_concurrent_activity_tasks < 1:
            raise ValueError("max_concurrent_activity_tasks must be at least 1")

        body: dict[str, Any] = {
            "worker_id": worker_id,
            "task_queue": task_queue,
            "runtime": runtime,
            "sdk_version": sdk_version,
            "supported_workflow_types": supported_workflow_types or [],
            "supported_activity_types": supported_activity_types or [],
        }
        if workflow_definition_fingerprints is not None:
            body["workflow_definition_fingerprints"] = workflow_definition_fingerprints
        if build_id is not None:
            body["build_id"] = build_id
        if max_concurrent_workflow_tasks is not None:
            body["max_concurrent_workflow_tasks"] = max_concurrent_workflow_tasks
        if max_concurrent_activity_tasks is not None:
            body["max_concurrent_activity_tasks"] = max_concurrent_activity_tasks
        return await self._request("POST", "/worker/register", worker=True, json=body)

    async def heartbeat_worker(
        self,
        *,
        worker_id: str,
        task_slots: dict[str, int] | None = None,
        process_metrics: dict[str, Any] | None = None,
        heartbeat_interval_seconds: int | None = None,
    ) -> Any:
        """Send a worker-fleet heartbeat to refresh liveness and report state.

        Workers should call this on a steady cadence (default 60s, advertised
        by the server in the register/heartbeat acknowledgement) so operators
        can answer "what workers are polling task queue X right now, what's
        their slot capacity, when did each last check in" via the worker
        management API, the CLI worker listing, and the operator Worker
        Status view.

        ``task_slots`` is an optional dict with any subset of
        ``workflow_available``, ``activity_available``, ``session_available``
        — the count of currently free slots for each family. The server
        clamps each value into ``[0, max_concurrent_*]``.

        ``process_metrics`` is an optional dict with any subset of
        ``cpu_percent``, ``memory_bytes``, ``process_uptime_seconds``,
        ``process_id``, and ``host`` — the SDK reports only what it has
        cheap access to, and the server records exactly what was reported.

        Returns the server acknowledgement, which includes the advertised
        ``heartbeat_interval_seconds`` and ``stale_after_seconds`` so the
        worker can adapt its cadence on the fly.

        Most applications create a :class:`~durable_workflow.Worker`, which
        runs this on a background asyncio task — call this directly only when
        driving the worker protocol by hand (smoke tests, custom runtimes).
        """
        body: dict[str, Any] = {"worker_id": worker_id}
        if task_slots:
            body["task_slots"] = task_slots
        if process_metrics:
            body["process_metrics"] = process_metrics
        if heartbeat_interval_seconds is not None:
            body["heartbeat_interval_seconds"] = heartbeat_interval_seconds
        return await self._request("POST", "/worker/heartbeat", worker=True, json=body)

    async def poll_workflow_task(
        self, *, worker_id: str, task_queue: str, timeout: float = 35.0
    ) -> Any:
        """Long-poll for the next workflow task on ``task_queue``.

        Returns the task payload, or ``None`` on poll timeout. Worker-plane
        endpoint — most applications use :class:`~durable_workflow.Worker`
        rather than calling this directly.
        """
        body: dict[str, Any] = {
            "worker_id": worker_id,
            "task_queue": task_queue,
            "poll_request_id": f"wf-poll-{uuid.uuid4().hex}",
        }
        for _ in range(2):
            try:
                data = await self._request(
                    "POST", "/worker/workflow-tasks/poll", worker=True, json=body, timeout=timeout
                )
            except httpx.TimeoutException:
                continue

            return (data or {}).get("task")

        return None

    async def complete_workflow_task(
        self,
        *,
        task_id: str,
        lease_owner: str,
        workflow_task_attempt: int,
        commands: list[dict[str, Any]],
    ) -> Any:
        """Report successful execution of a workflow task with its emitted commands.

        Worker-plane endpoint, called by :class:`~durable_workflow.Worker`.
        ``commands`` is the list of serialized commands the workflow yielded
        for this task.
        """
        body: dict[str, Any] = {
            "lease_owner": lease_owner,
            "workflow_task_attempt": workflow_task_attempt,
            "commands": commands,
        }
        return await self._request(
            "POST", f"/worker/workflow-tasks/{task_id}/complete", worker=True, json=body
        )

    async def fail_workflow_task(
        self,
        *,
        task_id: str,
        lease_owner: str,
        workflow_task_attempt: int,
        message: str,
        failure_type: str | None = None,
        stack_trace: str | None = None,
    ) -> Any:
        """Report a workflow task failure so the server can schedule a retry.

        Worker-plane endpoint. Task failures (e.g. non-determinism) are
        distinct from workflow failures (``FailWorkflow`` commands).
        """
        failure: dict[str, Any] = {"message": message}
        if failure_type is not None:
            failure["type"] = failure_type
        if stack_trace is not None:
            failure["stack_trace"] = stack_trace
        body: dict[str, Any] = {
            "lease_owner": lease_owner,
            "workflow_task_attempt": workflow_task_attempt,
            "failure": failure,
        }
        return await self._request(
            "POST", f"/worker/workflow-tasks/{task_id}/fail", worker=True, json=body
        )

    async def workflow_task_history(
        self,
        *,
        task_id: str,
        next_history_page_token: str | None = None,
        page_token: str | None = None,
        lease_owner: str,
        workflow_task_attempt: int,
    ) -> Any:
        """Page through extra history events while the worker is executing a long task.

        Worker-plane endpoint. The first page of history is delivered inline
        with the workflow task; this endpoint fetches subsequent pages.
        """
        if next_history_page_token is None:
            next_history_page_token = page_token
        elif page_token is not None and page_token != next_history_page_token:
            raise ValueError("page_token must match next_history_page_token when both are provided")
        if next_history_page_token is None:
            raise ValueError("next_history_page_token is required")

        body: dict[str, Any] = {
            "next_history_page_token": next_history_page_token,
            "lease_owner": lease_owner,
            "workflow_task_attempt": workflow_task_attempt,
        }
        return await self._request(
            "POST", f"/worker/workflow-tasks/{task_id}/history", worker=True, json=body
        )

    async def poll_query_task(
        self, *, worker_id: str, task_queue: str, timeout: float = 35.0
    ) -> Any:
        """Long-poll for the next workflow query task on ``task_queue``.

        Query tasks are ephemeral worker-plane requests created when the server
        must route a control-plane query to a non-PHP workflow runtime.
        """
        body: dict[str, Any] = {"worker_id": worker_id, "task_queue": task_queue}
        try:
            data = await self._request(
                "POST", "/worker/query-tasks/poll", worker=True, json=body, timeout=timeout
            )
        except httpx.TimeoutException:
            return None
        return (data or {}).get("task")

    async def complete_query_task(
        self,
        *,
        query_task_id: str,
        lease_owner: str,
        query_task_attempt: int,
        result: Any,
        codec: str = serializer.AVRO_CODEC,
        workflow_id: str | None = None,
        run_id: str | None = None,
        query_name: str | None = None,
        external_storage: ExternalStorageDriver | None = None,
        external_storage_threshold_bytes: int | None = None,
    ) -> Any:
        """Submit the successful result for a worker-routed query task."""
        body: dict[str, Any] = {
            "lease_owner": lease_owner,
            "query_task_attempt": query_task_attempt,
            "result": result,
            "result_envelope": self._payload_envelope(
                result,
                codec=codec,
                kind="query_result",
                workflow_id=workflow_id,
                run_id=run_id,
                query_name=query_name,
                external_storage=external_storage,
                external_storage_threshold_bytes=external_storage_threshold_bytes,
            ),
        }
        return await self._request(
            "POST", f"/worker/query-tasks/{query_task_id}/complete", worker=True, json=body
        )

    async def fail_query_task(
        self,
        *,
        query_task_id: str,
        lease_owner: str,
        query_task_attempt: int,
        message: str,
        reason: str = "query_rejected",
        failure_type: str | None = None,
        stack_trace: str | None = None,
    ) -> Any:
        """Report a failed worker-routed query task."""
        failure: dict[str, Any] = {"message": message, "reason": reason}
        if failure_type is not None:
            failure["type"] = failure_type
        if stack_trace is not None:
            failure["stack_trace"] = stack_trace
        body: dict[str, Any] = {
            "lease_owner": lease_owner,
            "query_task_attempt": query_task_attempt,
            "failure": failure,
        }
        return await self._request(
            "POST", f"/worker/query-tasks/{query_task_id}/fail", worker=True, json=body
        )

    async def poll_activity_task(
        self, *, worker_id: str, task_queue: str, timeout: float = 35.0
    ) -> Any:
        """Long-poll for the next activity task on ``task_queue``.

        Returns the task payload, or ``None`` on poll timeout. Worker-plane
        endpoint — typically used by :class:`~durable_workflow.Worker`.
        """
        body: dict[str, Any] = {
            "worker_id": worker_id,
            "task_queue": task_queue,
            "poll_request_id": f"activity-poll-{uuid.uuid4().hex}",
        }
        for _ in range(2):
            try:
                data = await self._request(
                    "POST", "/worker/activity-tasks/poll", worker=True, json=body, timeout=timeout
                )
            except httpx.TimeoutException:
                continue

            return (data or {}).get("task")

        return None

    async def complete_activity_task(
        self,
        *,
        task_id: str,
        activity_attempt_id: str,
        lease_owner: str,
        result: Any,
        codec: str = serializer.AVRO_CODEC,
        activity_name: str | None = None,
        external_storage: ExternalStorageDriver | None = None,
        external_storage_threshold_bytes: int | None = None,
    ) -> Any:
        """Report successful activity execution and submit the encoded result."""
        body: dict[str, Any] = {
            "activity_attempt_id": activity_attempt_id,
            "lease_owner": lease_owner,
            "result": self._payload_envelope(
                result,
                codec=codec,
                kind="activity_result",
                activity_name=activity_name,
                external_storage=external_storage,
                external_storage_threshold_bytes=external_storage_threshold_bytes,
            ),
        }
        return await self._request(
            "POST", f"/worker/activity-tasks/{task_id}/complete", worker=True, json=body
        )

    async def fail_activity_task(
        self,
        *,
        task_id: str,
        activity_attempt_id: str,
        lease_owner: str,
        message: str,
        failure_type: str | None = None,
        stack_trace: str | None = None,
        non_retryable: bool = False,
        details: Any | None = None,
        codec: str = serializer.AVRO_CODEC,
        activity_name: str | None = None,
    ) -> Any:
        """Report a failed activity attempt.

        Pass ``non_retryable=True`` to signal that this class of error will
        not be fixed by retrying — the server then surfaces the failure to
        the workflow immediately instead of scheduling another attempt.
        """
        failure: dict[str, Any] = {"message": message}
        if failure_type is not None:
            failure["type"] = failure_type
        if stack_trace is not None:
            failure["stack_trace"] = stack_trace
        if non_retryable:
            failure["non_retryable"] = True
        if details is not None:
            failure["details"] = self._payload_envelope(
                details,
                codec=codec,
                kind="activity_failure_details",
                activity_name=activity_name,
            )
        body: dict[str, Any] = {
            "activity_attempt_id": activity_attempt_id,
            "lease_owner": lease_owner,
            "failure": failure,
        }
        return await self._request(
            "POST", f"/worker/activity-tasks/{task_id}/fail", worker=True, json=body
        )

    async def heartbeat_activity_task(
        self,
        *,
        task_id: str,
        activity_attempt_id: str,
        lease_owner: str,
        details: dict[str, Any] | None = None,
    ) -> Any:
        """Send a liveness heartbeat for a running activity attempt.

        Worker-plane endpoint. Most code calls
        :meth:`~durable_workflow.ActivityContext.heartbeat` instead, which
        additionally raises :class:`~durable_workflow.errors.ActivityCancelled`
        when the server reports the activity should stop.
        """
        body: dict[str, Any] = {
            "activity_attempt_id": activity_attempt_id,
            "lease_owner": lease_owner,
        }
        if details is not None:
            body["details"] = details
        return await self._request(
            "POST", f"/worker/activity-tasks/{task_id}/heartbeat", worker=True, json=body
        )
