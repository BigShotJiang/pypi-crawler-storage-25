"""Tests for Pydantic models."""
from datetime import datetime, timezone

import pytest
from pydantic import ValidationError

from auspicium.models import (
    OHLCV,
    CrossOHLCV,
    OrderBook,
    OrderBookLevel,
    PolymarketMarket,
    PolymarketPrice,
    StreamMessage,
    Trade,
)


def _utc(s: str) -> datetime:
    return datetime.fromisoformat(s).replace(tzinfo=timezone.utc)


def test_ohlcv_parses():
    o = OHLCV(
        time=_utc("2026-04-07T10:00:00"),
        symbol="BTC-USDT", exchange="binance",
        open=70000, high=70500, low=69800, close=70200, volume=12.5,
    )
    assert o.close == 70200.0


def test_trade_optional_fields():
    t = Trade(
        time=_utc("2026-04-07T10:00:00"),
        symbol="BTC-USDT", source="binance",
        price=70200, quantity=0.5, side="buy",
    )
    assert t.usd_amount is None
    assert t.tx_hash is None


def test_orderbook_levels():
    ob = OrderBook(
        time=_utc("2026-04-07T10:00:00"),
        symbol="BTC-USDT", exchange="binance",
        bids=[OrderBookLevel(price=70000, size=0.1)],
        asks=[OrderBookLevel(price=70100, size=0.2)],
        spread=100.0,
        mid_price=70050.0,
    )
    assert ob.bids[0].price == 70000


def test_polymarket_market_resolution_nullable():
    m = PolymarketMarket(
        condition_id="0xabc",
        question="BTC up?",
        base_asset="BTC",
        interval="1H",
        candle_open=_utc("2026-04-07T10:00:00"),
        candle_close=_utc("2026-04-07T11:00:00"),
        active=True,
        closed=False,
        resolution=None,
    )
    assert m.resolution is None


def test_cross_ohlcv_provisional_flag():
    c = CrossOHLCV(
        time=_utc("2026-04-07T10:00:00"),
        granularity="5m", base_asset="BTC", condition_id="0xabc",
        binance_open=70000, binance_high=70500, binance_low=69800,
        binance_close=70200, binance_volume=12.5,
        polymarket_up_open=0.52, polymarket_up_high=0.58,
        polymarket_up_low=0.50, polymarket_up_close=0.55,
        polymarket_up_volume=1200.0,
        poly_price_ticks=42, poly_trade_count=8,
        is_provisional=False,
    )
    assert c.is_provisional is False


def test_stream_message():
    msg = StreamMessage(
        channel="ohlcv", source="binance", symbol="BTC-USDT",
        payload={"close": 70200}, timestamp_ms=1712484000000,
    )
    assert msg.channel == "ohlcv"