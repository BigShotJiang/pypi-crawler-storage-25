"""Tests for config.py."""
import os

import pytest

from auspicium.config import get_config, reset_config
from auspicium.errors import AuthError


def test_reads_api_key_from_env(monkeypatch):
    monkeypatch.setenv("AUSP_API_KEY", "my-key")
    cfg = get_config()
    assert cfg.api_key == "my-key"


def test_raises_auth_error_when_no_key(tmp_path, monkeypatch):
    monkeypatch.delenv("AUSP_API_KEY", raising=False)
    monkeypatch.chdir(tmp_path)   # no .auspicium.yaml here
    reset_config()
    with pytest.raises(AuthError):
        get_config()
    # Restore so subsequent tests in the suite are not affected
    monkeypatch.setenv("AUSP_API_KEY", "sdk-test-pro-key-do-not-use-in-prod")


def test_gateway_url_is_set():
    cfg = get_config()
    assert cfg.gateway_url.startswith("http")   # any valid URL is fine


def test_env_takes_precedence_over_yaml(tmp_path, monkeypatch):
    yaml_file = tmp_path / ".auspicium.yaml"
    yaml_file.write_text("api_key: yaml-key\ngateway_url: http://yaml-gateway\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.setenv("AUSP_API_KEY", "env-key")
    monkeypatch.setenv("AUSP_GATEWAY_URL", "http://env-gateway")
    reset_config()
    cfg = get_config()
    assert cfg.api_key == "env-key"
    assert cfg.gateway_url == "http://env-gateway"


def test_yaml_fallback(tmp_path, monkeypatch):
    yaml_file = tmp_path / ".auspicium.yaml"
    yaml_file.write_text("api_key: from-yaml\n")
    monkeypatch.chdir(tmp_path)
    monkeypatch.delenv("AUSP_API_KEY", raising=False)
    reset_config()
    cfg = get_config()
    assert cfg.api_key == "from-yaml"


def test_singleton_cached():
    cfg1 = get_config()
    cfg2 = get_config()
    assert cfg1 is cfg2