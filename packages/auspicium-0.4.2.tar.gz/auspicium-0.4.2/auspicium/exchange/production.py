"""ProductionExchange — routes orders per market to the right adapter.

When ``AUSPICIUM_ENV=production`` the runner instantiates this single
adapter instead of picking between Polymarket and Binance upfront. On
each ``submit()`` it inspects ``order.market`` and dispatches to either
the Polymarket CLOB adapter or the Binance spot adapter, constructing
each sub-adapter lazily so a pure-Polymarket strategy never needs
``BINANCE_API_KEY`` set (and vice versa).

The per-order routing uses the same ``_is_binance()`` heuristic as
:class:`PaperExchange`, so the quality→production transition keeps
behavior consistent.
"""
from __future__ import annotations

import logging
from typing import TYPE_CHECKING

from auspicium.exchange.base import BaseExchange
from auspicium.exchange.binance import BinanceExchange
from auspicium.exchange.polymarket import PolymarketExchange

if TYPE_CHECKING:
    from auspicium.strategy.models import Fill, Order

log = logging.getLogger("auspicium.exchange.production")


class ProductionExchange(BaseExchange):
    """Per-market router across real exchange adapters."""

    def __init__(self, fill_callback=None) -> None:
        super().__init__(fill_callback=fill_callback)
        self._poly: PolymarketExchange | None = None
        self._binance: BinanceExchange | None = None
        # exchange-assigned order id → which sub-adapter owns it
        self._order_routes: dict[str, BaseExchange] = {}

    # ------------------------------------------------------------------ #
    # Callback propagation                                                 #
    # ------------------------------------------------------------------ #

    def set_fill_callback(self, callback) -> None:
        super().set_fill_callback(callback)
        if self._poly is not None:
            self._poly.set_fill_callback(callback)
        if self._binance is not None:
            self._binance.set_fill_callback(callback)

    # ------------------------------------------------------------------ #
    # Lazy sub-adapter construction                                        #
    # ------------------------------------------------------------------ #

    def _route(self, market: str) -> BaseExchange:
        """Return the adapter that handles ``market``.

        Constructs the sub-adapter on first use so strategies that only
        touch one venue never need credentials for the other.
        """
        # Lazy import: avoids a circular (exchange.__init__ → production →
        # strategy.paper → exchange.base) during package initialization.
        from auspicium.strategy.paper import _is_binance

        if _is_binance(market):
            if self._binance is None:
                self._binance = BinanceExchange(fill_callback=self._fill_callback)
                log.info("ProductionExchange: created BinanceExchange")
            return self._binance
        if self._poly is None:
            self._poly = PolymarketExchange(fill_callback=self._fill_callback)
            log.info("ProductionExchange: created PolymarketExchange")
        return self._poly

    # ------------------------------------------------------------------ #
    # BaseExchange interface                                               #
    # ------------------------------------------------------------------ #

    async def submit(self, order: Order) -> str:
        adapter = self._route(order.market)
        exchange_id = await adapter.submit(order)
        self._order_routes[exchange_id] = adapter
        return exchange_id

    async def cancel(self, order_id: str) -> bool:
        adapter = self._order_routes.get(order_id)
        if adapter is None:
            # Unknown order id — best-effort: ask both adapters.
            for candidate in (self._poly, self._binance):
                if candidate is None:
                    continue
                if await candidate.cancel(order_id):
                    return True
            return False
        ok = await adapter.cancel(order_id)
        if ok:
            self._order_routes.pop(order_id, None)
        return ok

    async def check_pending_orders(
        self, current_prices: dict[str, float]
    ) -> None:
        if self._poly is not None:
            await self._poly.check_pending_orders(current_prices)
        if self._binance is not None:
            await self._binance.check_pending_orders(current_prices)

    async def get_balance(self) -> float:
        total = 0.0
        if self._binance is not None:
            total += await self._binance.get_balance()
        if self._poly is not None:
            total += await self._poly.get_balance()
        return total

    async def emergency_close_all(self) -> list[Fill]:
        fills: list[Fill] = []
        if self._poly is not None:
            try:
                fills.extend(await self._poly.emergency_close_all())
            except Exception as exc:
                log.error("Polymarket emergency_close_all raised: %s", exc)
        if self._binance is not None:
            try:
                fills.extend(await self._binance.emergency_close_all())
            except Exception as exc:
                log.error("Binance emergency_close_all raised: %s", exc)
        self._order_routes.clear()
        return fills