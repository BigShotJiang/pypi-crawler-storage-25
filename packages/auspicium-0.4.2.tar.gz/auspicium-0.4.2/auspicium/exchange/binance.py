"""Binance spot exchange adapter.

Real spot order execution on Binance for ``AUSPICIUM_ENV=production``.
Wraps ``python-binance`` — lazy-imported so the SDK imports cleanly even
when ``auspicium[exchange]`` is not installed.

Credentials (all from environment variables):

    BINANCE_API_KEY     — Binance API key (required)
    BINANCE_API_SECRET  — Binance API secret (required)
    BINANCE_TESTNET     — "true" to target testnet (default: "false")

Symbol convention:
    Quants use dashed symbols in :class:`Order` (e.g. ``BTC-USDT``); this
    adapter normalises to Binance's concatenated form (``BTCUSDT``).

Partial fills:
    Market orders often return multiple partial fills in ``resp["fills"]``.
    :meth:`_resp_to_fill` computes a VWAP across them. Commissions are
    summed as-is — v1 does NOT convert non-stablecoin commission assets.
"""
from __future__ import annotations

import logging
import os
from datetime import datetime, timezone

from auspicium.errors import ExchangeError, OrderRejectedError
from auspicium.exchange.base import BaseExchange
from auspicium.strategy.models import Fill, Order

log = logging.getLogger("auspicium.exchange.binance")

# Stablecoin quote assets we never try to emergency-sell.
_STABLES = {"USDT", "USDC", "BUSD", "FDUSD", "TUSD", "DAI"}


def _import_binance_client():
    """Lazy-import python-binance symbols.

    Returns ``(Client, BinanceAPIException)``. Extracted into a module-level
    helper so tests can mock this single function rather than the import
    system.

    Raises:
        ExchangeError: If ``python-binance`` is not installed.
    """
    try:
        from binance.client import Client
        from binance.exceptions import BinanceAPIException
    except ImportError as exc:
        raise ExchangeError(
            "python-binance is not installed. "
            "Run `pip install auspicium[exchange]` to enable the Binance adapter."
        ) from exc
    return Client, BinanceAPIException


def _normalize_symbol(market: str) -> str:
    """Convert ``BTC-USDT`` → ``BTCUSDT`` (Binance's on-wire format)."""
    return market.replace("-", "").replace("/", "").upper()


class BinanceExchange(BaseExchange):
    """Real Binance spot exchange adapter."""

    def __init__(self, fill_callback=None) -> None:
        super().__init__(fill_callback=fill_callback)
        self._client = None  # lazy
        self._open_orders: dict[str, Order] = {}  # exchange_id (str) → Order

    # ------------------------------------------------------------------ #
    # Client bootstrap                                                     #
    # ------------------------------------------------------------------ #

    def _get_client(self):
        if self._client is not None:
            return self._client

        Client, _BinanceAPIException = _import_binance_client()

        api_key = os.environ.get("BINANCE_API_KEY")
        api_secret = os.environ.get("BINANCE_API_SECRET")
        if not api_key or not api_secret:
            raise ExchangeError(
                "BINANCE_API_KEY and BINANCE_API_SECRET must both be set in "
                "the environment to use the Binance exchange adapter."
            )

        testnet = os.environ.get("BINANCE_TESTNET", "false").lower() == "true"
        self._client = Client(api_key, api_secret, testnet=testnet)
        log.info("Binance client initialized (testnet=%s)", testnet)
        return self._client

    # ------------------------------------------------------------------ #
    # BaseExchange interface                                               #
    # ------------------------------------------------------------------ #

    async def submit(self, order: Order) -> str:
        """Submit a spot MARKET or LIMIT order."""
        client = self._get_client()
        Client, _BinanceAPIException = _import_binance_client()

        symbol = _normalize_symbol(order.market)
        side_str = order.side.upper()

        try:
            if order.order_type.upper() == "MARKET":
                if side_str == "BUY":
                    # Buy at market using quote notional (USDT amount)
                    resp = client.order_market_buy(
                        symbol=symbol,
                        quoteOrderQty=order.size * order.price,
                    )
                else:
                    resp = client.order_market_sell(
                        symbol=symbol,
                        quantity=order.size,
                    )
            else:
                resp = client.create_order(
                    symbol=symbol,
                    side=side_str,
                    type=Client.ORDER_TYPE_LIMIT,
                    timeInForce=Client.TIME_IN_FORCE_GTC,
                    quantity=order.size,
                    price=str(order.price),
                )
        except Exception as exc:
            raise OrderRejectedError(
                f"Binance order rejected: {type(exc).__name__}: {exc}"
            ) from exc

        exchange_order_id = str(resp.get("orderId") or order.id)

        # Market orders usually come back already FILLED — emit the fill now.
        if str(resp.get("status", "")).upper() == "FILLED":
            fill = self._resp_to_fill(resp, order)
            log.info(
                "Binance order filled immediately: %s %s %.6f @ %.4f → %s",
                side_str, symbol, fill.size, fill.price, exchange_order_id,
            )
            await self._notify_fill(fill)
            return exchange_order_id

        # Otherwise track it for polling.
        self._open_orders[exchange_order_id] = order
        log.info(
            "Binance order submitted: %s %s %.6f @ %.4f → %s",
            side_str, symbol, order.size, order.price, exchange_order_id,
        )
        return exchange_order_id

    def _resp_to_fill(self, resp: dict, order: Order) -> Fill:
        """Build a Fill from a Binance order response (handles partial fills)."""
        fills_data = resp.get("fills") or []
        if fills_data:
            total_qty = sum(float(f["qty"]) for f in fills_data)
            if total_qty > 0:
                avg_price = (
                    sum(float(f["price"]) * float(f["qty"]) for f in fills_data)
                    / total_qty
                )
            else:
                avg_price = float(resp.get("price") or order.price)
            total_fee = sum(float(f.get("commission", 0.0)) for f in fills_data)
        else:
            avg_price = float(resp.get("price") or order.price)
            total_qty = float(resp.get("executedQty") or order.size)
            total_fee = 0.0

        return Fill(
            order_id=str(resp.get("orderId") or order.id),
            market=order.market,
            side=order.side,
            outcome=order.outcome,
            price=avg_price,
            size=total_qty,
            fee=total_fee,
            timestamp=datetime.now(timezone.utc),
            status="CONFIRMED",
        )

    async def cancel(self, order_id: str) -> bool:
        """Cancel an open order. Requires the original order's symbol."""
        order = self._open_orders.get(order_id)
        if order is None:
            return False
        symbol = _normalize_symbol(order.market)
        try:
            client = self._get_client()
            client.cancel_order(symbol=symbol, orderId=int(order_id))
        except Exception as exc:
            log.warning("Binance cancel failed for %s: %s", order_id, exc)
            return False
        self._open_orders.pop(order_id, None)
        log.info("Binance order cancelled: %s", order_id)
        return True

    async def check_pending_orders(
        self, current_prices: dict[str, float]
    ) -> None:
        """Poll each open order's status and emit fills for filled orders."""
        if not self._open_orders:
            return
        try:
            client = self._get_client()
        except ExchangeError as exc:
            log.warning("Binance check_pending_orders: %s", exc)
            return

        for exchange_id, order in list(self._open_orders.items()):
            symbol = _normalize_symbol(order.market)
            try:
                status = client.get_order(symbol=symbol, orderId=int(exchange_id))
            except Exception as exc:
                log.warning(
                    "Binance get_order failed for %s: %s", exchange_id, exc
                )
                continue

            order_status = str(status.get("status", "")).upper()
            if order_status == "FILLED":
                fill = self._resp_to_fill(status, order)
                self._open_orders.pop(exchange_id, None)
                await self._notify_fill(fill)
            elif order_status in ("CANCELED", "CANCELLED", "EXPIRED", "REJECTED"):
                self._open_orders.pop(exchange_id, None)
                log.warning(
                    "Binance order %s terminal state: %s",
                    exchange_id, order_status,
                )

    async def get_balance(self) -> float:
        """Return the free USDT balance from the spot account."""
        try:
            client = self._get_client()
            account = client.get_account()
        except Exception as exc:
            log.warning("Binance get_balance failed: %s", exc)
            return 0.0
        for asset in account.get("balances", []) or []:
            if asset.get("asset") == "USDT":
                try:
                    return float(asset.get("free", 0.0))
                except (TypeError, ValueError):
                    return 0.0
        return 0.0

    async def emergency_close_all(self) -> list[Fill]:
        """Cancel all open orders and market-sell all non-stablecoin balances.

        Idempotent; never raises. Errors are logged and the loop continues.
        """
        fills: list[Fill] = []

        # Step 1: cancel every open order we know about.
        for exchange_id in list(self._open_orders.keys()):
            try:
                await self.cancel(exchange_id)
            except Exception as exc:
                log.error("Binance cancel during emergency: %s", exc)

        # Step 2: market-sell every non-stablecoin free balance.
        try:
            client = self._get_client()
            account = client.get_account()
        except Exception as exc:
            log.error("Binance emergency_close_all account fetch failed: %s", exc)
            return fills

        for asset in account.get("balances", []) or []:
            name = asset.get("asset")
            try:
                free = float(asset.get("free", 0.0))
            except (TypeError, ValueError):
                free = 0.0
            if free <= 0 or name in _STABLES or not name:
                continue
            symbol = f"{name}USDT"
            try:
                resp = client.order_market_sell(symbol=symbol, quantity=free)
            except Exception as exc:
                log.error("Binance emergency sell %s failed: %s", symbol, exc)
                continue
            if str(resp.get("status", "")).upper() == "FILLED":
                synthetic_order = Order(
                    market=f"{name}-USDT",
                    side="SELL",
                    size=free,
                    price=0.0,
                    order_type="MARKET",
                )
                fill = self._resp_to_fill(resp, synthetic_order)
                fills.append(fill)
                await self._notify_fill(fill)

        # After successful close, drop internal state so a second call is a no-op.
        self._positions.clear()
        self._open_orders.clear()
        return fills