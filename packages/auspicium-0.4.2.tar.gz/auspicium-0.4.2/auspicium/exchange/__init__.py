"""Auspicium exchange adapters — paper and real order execution.

The strategy framework talks to exchanges through the :class:`BaseExchange`
abstract interface. ``PaperExchange`` (in ``auspicium.strategy.paper``)
is used for ``AUSPICIUM_ENV=quality``. ``ProductionExchange`` is used for
``AUSPICIUM_ENV=production`` and routes orders per-market to
:class:`PolymarketExchange` or :class:`BinanceExchange`.

Real adapters lazy-import their third-party clients, so the SDK imports
cleanly even when ``auspicium[exchange]`` is not installed. Credentials
come from environment variables — never hard-coded.
"""
from auspicium.exchange.base import BaseExchange
from auspicium.exchange.binance import BinanceExchange
from auspicium.exchange.polymarket import PolymarketExchange
from auspicium.exchange.production import ProductionExchange

__all__ = [
    "BaseExchange",
    "BinanceExchange",
    "PolymarketExchange",
    "ProductionExchange",
]