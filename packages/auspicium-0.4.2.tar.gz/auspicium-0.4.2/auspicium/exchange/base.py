"""Abstract base class for all exchange adapters.

Every adapter — paper or real — implements this interface. The runner
instantiates one adapter based on ``AUSPICIUM_ENV`` and never references
a concrete subclass; strategies never touch the adapter at all (they use
``self.submit(order)`` on the :class:`Strategy` base class).
"""
from __future__ import annotations

import asyncio
import logging
from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, Awaitable, Callable

# Runtime imports of strategy models would create a circular import:
# exchange.base → strategy.models → strategy/__init__.py → runner → paper → exchange.base.
# With `from __future__ import annotations` all annotations are strings, so
# we only need the symbols for static type checkers.
if TYPE_CHECKING:
    from auspicium.strategy.models import Fill, Order, Position

log = logging.getLogger(__name__)


class BaseExchange(ABC):
    """Abstract exchange adapter contract.

    The ``fill_callback`` is registered by the runner AFTER the adapter and
    strategy are constructed (so it can close over the strategy). Adapters
    MUST call :meth:`_notify_fill` for every fill — the runner uses it to
    update the portfolio, persist state, and record Prometheus metrics.

    Concrete subclasses:
        - :class:`auspicium.strategy.paper.PaperExchange` — simulates fills
          against live market data (quality env).
        - :class:`auspicium.exchange.polymarket.PolymarketExchange` — real
          Polymarket CLOB orders via ``py-clob-client``.
        - :class:`auspicium.exchange.binance.BinanceExchange` — real Binance
          spot orders via ``python-binance``.
        - :class:`auspicium.exchange.production.ProductionExchange` — router
          that dispatches per-order to Polymarket or Binance based on market.
    """

    def __init__(
        self,
        fill_callback: Callable[[Fill], Awaitable[None]] | None = None,
    ) -> None:
        self._fill_callback = fill_callback
        self._positions: dict[str, Position] = {}
        self._cash: float = 0.0

    def set_fill_callback(
        self, callback: Callable[[Fill], Awaitable[None]]
    ) -> None:
        """Register the fill callback. Called by the runner after init."""
        self._fill_callback = callback

    @abstractmethod
    async def submit(self, order: Order) -> str:
        """Submit an order to the exchange.

        Returns:
            The exchange-assigned order id (or the internal ``order.id`` for
            paper/synchronous fills).

        Raises:
            OrderRejectedError: If the exchange rejects the order.
            ExchangeError:      For connectivity or authentication issues.
        """

    @abstractmethod
    async def cancel(self, order_id: str) -> bool:
        """Cancel an open order.

        Returns:
            True if cancelled, False if not found or already filled.
        """

    @abstractmethod
    async def check_pending_orders(
        self, current_prices: dict[str, float]
    ) -> None:
        """Poll or check the status of all pending orders.

        Paper: simulates fills against ``current_prices``.
        Real:  polls the exchange REST API for order status updates.
        Called by the runner after each data tick.
        """

    @abstractmethod
    async def get_balance(self) -> float:
        """Return the cash balance available for trading (in USD/USDT)."""

    @abstractmethod
    async def emergency_close_all(self) -> list[Fill]:
        """Cancel all open orders and market-close all positions.

        Called by the runner on SIGTERM or when the risk guardian triggers
        an auto-kill. MUST be idempotent — safe to call multiple times.
        MUST NOT raise — log errors internally and return whatever fills
        were captured.

        Returns:
            The fills generated while closing positions (empty list if
            nothing was open).
        """

    async def _notify_fill(self, fill: Fill) -> None:
        """Dispatch a fill to the registered callback.

        Handles both sync and async callbacks. Adapters call this from
        inside ``submit()`` / ``check_pending_orders()`` after every fill.
        """
        if self._fill_callback is None:
            return
        try:
            if asyncio.iscoroutinefunction(self._fill_callback):
                await self._fill_callback(fill)
            else:
                self._fill_callback(fill)
        except Exception as exc:
            log.error("fill_callback raised: %s", exc, exc_info=True)

    # ------------------------------------------------------------------ #
    # Accessors — useful for shutdown logic and monitoring                 #
    # ------------------------------------------------------------------ #

    @property
    def positions(self) -> dict[str, Position]:
        return self._positions

    @property
    def cash(self) -> float:
        return self._cash