"""Auspicium CLI — `ausp` command.

Usage:
    ausp status                          # show tier, limits, 30d usage
    ausp data ohlcv binance BTC-USDT     # last 100 1m candles
    ausp data trades binance BTC-USDT    # last hour of trades
    ausp data markets                    # active Polymarket markets
    ausp data cross-market BTC           # cross-OHLCV for BTC
    ausp backtest run ./my_strategy      # run a backtest
    ausp backtest report results.json    # display saved results
"""
from __future__ import annotations

import typer
from rich.console import Console
from rich.table import Table

app      = typer.Typer(name="ausp", help="Auspicium DaaS command-line interface", add_completion=False)
data     = typer.Typer(help="Fetch market data")
backtest = typer.Typer(help="Backtest trading strategies")
app.add_typer(data, name="data")
app.add_typer(backtest, name="backtest")

console = Console()


@app.command()
def status():
    """Show API key status, current tier, and 30-day usage."""
    from auspicium.connectors.rest import RestConnector
    try:
        info = RestConnector.me()
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    table = Table(title="Auspicium Account", show_header=False)
    table.add_column("Field", style="bold cyan")
    table.add_column("Value")
    table.add_row("Tier",        info.get("tier", "—"))
    table.add_row("Email",       info.get("email", "—"))
    table.add_row("Calls (30d)", str(info.get("usage_30d", {}).get("total_calls", "—")))
    limits = info.get("limits", {})
    table.add_row("RPM limit",   str(limits.get("rpm", "—")))
    table.add_row("Max rows",    str(limits.get("max_rows", "—")))
    table.add_row("Lookback",    f"{limits.get('lookback_days', '—')} days")
    table.add_row("Rate limit remaining", str(RestConnector.last_rate_limit.get("x-ratelimit-remaining", "—")))
    console.print(table)


@data.command("ohlcv")
def data_ohlcv(
    source: str = typer.Argument("binance"),
    symbol: str = typer.Argument("BTC-USDT"),
    interval: str = typer.Option("1m", "--interval", "-i"),
    limit: int  = typer.Option(100, "--limit",    "-n"),
):
    """OHLCV candles for a trading pair."""
    from auspicium.connectors.rest import RestConnector
    try:
        df = RestConnector.ohlcv(source, symbol, interval=interval, limit=limit)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    if df.empty:
        console.print("[yellow]No data returned.[/yellow]")
        return

    table = Table(title=f"OHLCV {source}/{symbol} ({interval})")
    for col in ["symbol", "open", "high", "low", "close", "volume"]:
        table.add_column(col, justify="right" if col != "symbol" else "left")
    for ts, row in df.iterrows():
        table.add_row(
            str(row.get("symbol", symbol)),
            f"{row.get('open', 0):.2f}",
            f"{row.get('high', 0):.2f}",
            f"{row.get('low',  0):.2f}",
            f"{row.get('close',0):.2f}",
            f"{row.get('volume',0):.4f}",
        )
    console.print(table)


@data.command("trades")
def data_trades(
    source: str = typer.Argument("binance"),
    symbol: str = typer.Argument("BTC-USDT"),
    hours:  int = typer.Option(1, "--hours", "-h"),
    limit:  int = typer.Option(50, "--limit", "-n"),
):
    """Recent trades for a symbol."""
    from auspicium.connectors.rest import RestConnector
    try:
        df = RestConnector.trades(source, symbol=symbol, hours=hours, limit=limit)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    if df.empty:
        console.print("[yellow]No trades returned.[/yellow]")
        return

    console.print(df.to_string())


@data.command("markets")
def data_markets(
    status:     str = typer.Option("active", "--status"),
    base_asset: str = typer.Option(None,     "--asset"),
):
    """Active Polymarket prediction markets."""
    from auspicium.connectors.rest import RestConnector
    try:
        df = RestConnector.markets(status=status, base_asset=base_asset)
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    if df.empty:
        console.print("[yellow]No markets returned.[/yellow]")
        return

    console.print(df[["condition_id", "base_asset", "active", "resolution"]].to_string())


@data.command("cross-market")
def data_cross(
    base_asset:   str = typer.Argument("BTC"),
    granularity:  str = typer.Option("5m", "--gran"),
    hours:        int = typer.Option(2,    "--hours"),
):
    """Joined Binance × Polymarket cross-OHLCV table."""
    from auspicium.connectors.rest import RestConnector
    try:
        df = RestConnector.cross_market(
            granularity=granularity, base_asset=base_asset, hours=hours
        )
    except Exception as exc:
        console.print(f"[red]Error:[/red] {exc}")
        raise typer.Exit(1)

    if df.empty:
        console.print("[yellow]No data returned.[/yellow]")
        return

    cols = ["base_asset", "binance_close", "polymarket_up_close", "poly_price_ticks", "is_provisional"]
    console.print(df[[c for c in cols if c in df.columns]].to_string())


@backtest.command("run")
def backtest_run(
    strategy_dir: str = typer.Argument(..., help="Path to strategy directory"),
    source: str = typer.Option("binance", "--source", "-s", help="Data source: binance or polymarket"),
    symbol: str = typer.Option("BTC-USDT", "--symbol", help="Trading pair or condition_id"),
    start: str = typer.Option("2024-01-01", "--start", help="Start date (ISO format)"),
    end: str = typer.Option("2024-12-31", "--end", help="End date (ISO format)"),
    interval: str = typer.Option("1h", "--interval", "-i", help="Bar interval: 1m, 5m, 1h, 1d"),
    capital: float = typer.Option(10_000.0, "--capital", "-c", help="Initial capital in USD"),
    class_name: str = typer.Option(None, "--class", help="Strategy class name (auto-detected if omitted)"),
    save: bool = typer.Option(True, "--save/--no-save", help="Save results JSON to strategy_dir/backtest_results/"),
):
    """Run a backtest on a strategy directory.

    Loads strategy.py and config.yaml from STRATEGY_DIR, runs the backtest,
    prints a tearsheet, and optionally saves results to backtest_results/.

    Example::

        ausp backtest run ./examples/btc_momentum --start 2024-06-01 --end 2024-12-31
    """
    import json
    import sys
    from pathlib import Path

    strategy_path = Path(strategy_dir)
    if not strategy_path.exists():
        console.print(f"[red]Error:[/red] Strategy directory '{strategy_dir}' not found.")
        raise typer.Exit(1)

    strategy_cls = _load_strategy_class(strategy_dir, class_name)
    if strategy_cls is None:
        console.print("[red]Error:[/red] No Strategy subclass found in strategy.py")
        raise typer.Exit(1)

    console.print(f"[cyan]Running backtest:[/cyan] {strategy_cls.__name__} "
                  f"{source}/{symbol} {start}→{end} interval={interval} capital=${capital:,.0f}")

    try:
        from auspicium.backtest import run_sync
        result = run_sync(
            strategy_cls,
            source=source,
            symbol=symbol,
            start=start,
            end=end,
            interval=interval,
            initial_capital=capital,
        )
    except Exception as exc:
        console.print(f"[red]Backtest failed:[/red] {exc}")
        raise typer.Exit(1)

    result.tearsheet()

    if save:
        results_dir = strategy_path / "backtest_results"
        results_dir.mkdir(exist_ok=True)
        from datetime import datetime
        ts = datetime.now().strftime("%Y%m%d_%H%M%S")
        out_path = results_dir / f"backtest_{ts}.json"
        out_path.write_text(json.dumps(result.to_dict(), indent=2))
        console.print(f"\n[green]Results saved:[/green] {out_path}")


@backtest.command("report")
def backtest_report(
    results_path: str = typer.Argument(..., help="Path to backtest results JSON file"),
):
    """Display a tearsheet from saved backtest results.

    Example::

        ausp backtest report ./examples/btc_momentum/backtest_results/backtest_20240601_120000.json
    """
    import json
    from pathlib import Path

    path = Path(results_path)
    if not path.exists():
        console.print(f"[red]Error:[/red] File not found: {results_path}")
        raise typer.Exit(1)

    try:
        data_raw = json.loads(path.read_text())
    except json.JSONDecodeError as exc:
        console.print(f"[red]Error:[/red] Invalid JSON: {exc}")
        raise typer.Exit(1)

    stats = data_raw.get("stats", {})

    table = Table(title=f"Backtest Report — {path.name}", show_header=False)
    table.add_column("Metric", style="bold cyan")
    table.add_column("Value", justify="right")

    def _pct(k):
        v = stats.get(k, 0)
        return f"{v * 100:.2f}%"

    def _fmt(k, decimals=2):
        return f"{stats.get(k, 0):.{decimals}f}"

    table.add_row("Initial Capital", f"${stats.get('initial_capital', 0):,.2f}")
    table.add_row("Final Value",     f"${stats.get('final_value', 0):,.2f}")
    table.add_row("Total Return",    _pct("total_return"))
    table.add_row("Ann. Return",     _pct("annualized_return"))
    table.add_row("Sharpe Ratio",    _fmt("sharpe_ratio"))
    table.add_row("Max Drawdown",    _pct("max_drawdown"))
    table.add_row("Total Trades",    str(stats.get("total_trades", 0)))
    table.add_row("Win Rate",        _pct("win_rate"))
    table.add_row("Commission Paid", f"${stats.get('commission_paid', 0):.2f}")
    console.print(table)


def _load_strategy_class(strategy_dir: str, class_name: str | None = None):
    """Dynamically import strategy.py from the directory and find the Strategy subclass.

    Search order:
        1. ``class_name`` argument (if given)
        2. Module-level ``strategy`` variable
        3. First Strategy subclass found in the module
    """
    import importlib.util
    from pathlib import Path

    strategy_file = Path(strategy_dir) / "strategy.py"
    if not strategy_file.exists():
        console.print(f"[red]Error:[/red] No strategy.py found in {strategy_dir}")
        return None

    spec = importlib.util.spec_from_file_location("user_strategy", strategy_file)
    module = importlib.util.module_from_spec(spec)
    try:
        spec.loader.exec_module(module)
    except Exception as exc:
        console.print(f"[red]Error loading strategy.py:[/red] {exc}")
        return None

    if class_name:
        cls = getattr(module, class_name, None)
        if cls is None:
            console.print(f"[red]Error:[/red] Class '{class_name}' not found in strategy.py")
        return cls

    if hasattr(module, "strategy"):
        return module.strategy

    from auspicium.strategy.base import Strategy
    for _name, obj in vars(module).items():
        if isinstance(obj, type) and issubclass(obj, Strategy) and obj is not Strategy:
            return obj

    return None


if __name__ == "__main__":
    app()