"""Auspicium DaaS SDK."""
import importlib

from auspicium._version import __version__

__all__ = ["__version__"]


def __getattr__(name):
    if name == "rest":
        from auspicium.connectors.rest import RestConnector
        return RestConnector
    if name == "stream":
        from auspicium.connectors.stream import StreamConnector
        return StreamConnector
    if name == "strategy":
        # Use importlib to avoid re-entering this __getattr__ via `from auspicium import strategy`
        return importlib.import_module("auspicium.strategy")
    if name == "Strategy":
        from auspicium.strategy.base import Strategy
        return Strategy
    if name == "backtest":
        return importlib.import_module("auspicium.backtest")
    raise AttributeError(f"module 'auspicium' has no attribute {name!r}")