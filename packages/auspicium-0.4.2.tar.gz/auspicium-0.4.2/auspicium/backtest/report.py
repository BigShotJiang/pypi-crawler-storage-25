"""Plotly tearsheet and text summary for backtest results.

Provides:
  - create_tearsheet(result) → plotly Figure (4-panel interactive chart)
  - print_tearsheet(result)  → rich text summary to terminal
  - result_to_json(result)   → JSON-safe dict for workspace-api

Install the optional extra to enable plots:
    pip install auspicium[backtest]
"""
from __future__ import annotations

import json
import logging
from typing import TYPE_CHECKING

import pandas as pd

if TYPE_CHECKING:
    from auspicium.backtest.engine import BacktestResult

log = logging.getLogger(__name__)


# ------------------------------------------------------------------ #
# Plotly tearsheet                                                     #
# ------------------------------------------------------------------ #

def create_tearsheet(result: "BacktestResult"):
    """Create an interactive plotly tearsheet from backtest results.

    4-panel layout:
        Row 1: Price chart with BUY (green ▲) / SELL (red ▼) trade markers
        Row 2: Equity curve (strategy vs buy-and-hold benchmark)
        Row 3: Drawdown chart
        Row 4: Monthly returns heatmap

    Args:
        result: BacktestResult from engine.run()

    Returns:
        plotly.graph_objects.Figure

    Raises:
        ImportError: if plotly is not installed (pip install auspicium[backtest])
    """
    try:
        import plotly.graph_objects as go
        from plotly.subplots import make_subplots
    except ImportError as exc:
        raise ImportError(
            "plotly is required for tearsheets. Install with: pip install auspicium[backtest]"
        ) from exc

    equity = result.equity_curve
    ohlcv = result.ohlcv
    trades = result.trades
    stats = result.stats_dict

    cum_max = equity.cummax()
    drawdown = (equity - cum_max) / cum_max

    fig = make_subplots(
        rows=4, cols=1,
        shared_xaxes=True,
        vertical_spacing=0.04,
        row_heights=[0.30, 0.25, 0.20, 0.25],
        subplot_titles=[
            "Price + Trades",
            "Equity Curve",
            "Drawdown",
            "Monthly Returns (%)",
        ],
    )

    # --- Row 1: Price chart ---
    if not ohlcv.empty and "close" in ohlcv.columns:
        fig.add_trace(
            go.Scatter(
                x=ohlcv.index,
                y=ohlcv["close"],
                name="Close",
                line={"color": "#636EFA", "width": 1},
                showlegend=True,
            ),
            row=1, col=1,
        )

    # Trade markers
    if not trades.empty and "time" in trades.columns and "price" in trades.columns:
        buys = trades[trades["side"] == "BUY"]
        sells = trades[trades["side"] == "SELL"]

        if not buys.empty:
            fig.add_trace(
                go.Scatter(
                    x=buys["time"],
                    y=buys["price"],
                    mode="markers",
                    name="BUY",
                    marker={
                        "symbol": "triangle-up",
                        "color": "green",
                        "size": 10,
                    },
                    showlegend=True,
                ),
                row=1, col=1,
            )

        if not sells.empty:
            fig.add_trace(
                go.Scatter(
                    x=sells["time"],
                    y=sells["price"],
                    mode="markers",
                    name="SELL",
                    marker={
                        "symbol": "triangle-down",
                        "color": "red",
                        "size": 10,
                    },
                    showlegend=True,
                ),
                row=1, col=1,
            )

    # --- Row 2: Equity curve ---
    fig.add_trace(
        go.Scatter(
            x=equity.index,
            y=equity.values,
            name="Portfolio",
            line={"color": "#00CC96", "width": 2},
            fill="tozeroy",
            fillcolor="rgba(0,204,150,0.1)",
            showlegend=True,
        ),
        row=2, col=1,
    )

    # Buy-and-hold benchmark (if price data available)
    if not ohlcv.empty and "close" in ohlcv.columns and len(ohlcv) > 0:
        bah = result.initial_capital * (ohlcv["close"] / float(ohlcv["close"].iloc[0]))
        # Align to equity index
        bah_aligned = bah.reindex(equity.index, method="ffill")
        fig.add_trace(
            go.Scatter(
                x=bah_aligned.index,
                y=bah_aligned.values,
                name="Buy & Hold",
                line={"color": "#AB63FA", "width": 1, "dash": "dash"},
                showlegend=True,
            ),
            row=2, col=1,
        )

    # --- Row 3: Drawdown ---
    fig.add_trace(
        go.Scatter(
            x=drawdown.index,
            y=drawdown.values * 100,
            name="Drawdown",
            line={"color": "#EF553B", "width": 1},
            fill="tozeroy",
            fillcolor="rgba(239,85,59,0.2)",
            showlegend=False,
        ),
        row=3, col=1,
    )

    # --- Row 4: Monthly returns heatmap ---
    monthly = _monthly_returns(equity)
    if monthly is not None and not monthly.empty:
        z_vals = monthly.values.tolist()
        fig.add_trace(
            go.Heatmap(
                z=z_vals,
                x=[str(m) for m in monthly.columns],
                y=[str(y) for y in monthly.index],
                colorscale="RdYlGn",
                zmid=0,
                text=[[f"{v:.1f}%" if pd.notna(v) else "" for v in row] for row in monthly.values],
                texttemplate="%{text}",
                showscale=False,
                name="Monthly Returns",
            ),
            row=4, col=1,
        )

    # --- Layout ---
    total_ret = stats.get("total_return", 0.0)
    sharpe = stats.get("sharpe_ratio", 0.0)
    max_dd = stats.get("max_drawdown", 0.0)
    n_trades = stats.get("total_trades", 0)

    title_text = (
        f"Backtest — Return: {total_ret*100:.1f}% | "
        f"Sharpe: {sharpe:.2f} | Max DD: {max_dd*100:.1f}% | "
        f"Trades: {n_trades}"
    )

    fig.update_layout(
        title=title_text,
        height=900,
        template="plotly_dark",
        legend={"orientation": "h", "y": 1.02},
        margin={"t": 80, "b": 40, "l": 60, "r": 40},
    )
    fig.update_yaxes(title_text="Price", row=1, col=1)
    fig.update_yaxes(title_text="USD", row=2, col=1)
    fig.update_yaxes(title_text="Drawdown %", row=3, col=1)

    return fig


def _monthly_returns(equity: pd.Series) -> pd.DataFrame | None:
    """Compute monthly returns pivot table (years × months)."""
    try:
        monthly = equity.resample("ME").last().pct_change().dropna() * 100
        if monthly.empty:
            return None
        df = monthly.to_frame("ret")
        df["year"] = df.index.year
        df["month"] = df.index.month
        pivot = df.pivot(index="year", columns="month", values="ret")
        pivot.columns = [
            ["Jan","Feb","Mar","Apr","May","Jun",
             "Jul","Aug","Sep","Oct","Nov","Dec"][m - 1]
            for m in pivot.columns
        ]
        return pivot
    except Exception as exc:
        log.debug("Monthly returns computation failed: %s", exc)
        return None


# ------------------------------------------------------------------ #
# Text tearsheet (rich)                                                #
# ------------------------------------------------------------------ #

def print_tearsheet(result: "BacktestResult") -> None:
    """Print a text tearsheet using rich tables.

    Sections:
        1. Performance summary (return, Sharpe, drawdown, …)
        2. Trade statistics (win rate, avg win/loss, …)
        3. Last 20 trades table
    """
    try:
        from rich.console import Console
        from rich.table import Table
    except ImportError:
        _print_tearsheet_plain(result)
        return

    console = Console()
    stats = result.stats_dict

    def _pct(v: float) -> str:
        return f"{v * 100:.2f}%"

    def _fmt(v: float, decimals: int = 2) -> str:
        return f"{v:.{decimals}f}"

    # --- Performance table ---
    perf = Table(title="Performance Summary", show_header=False)
    perf.add_column("Metric", style="bold cyan")
    perf.add_column("Value", justify="right")
    perf.add_row("Initial Capital", f"${stats.get('initial_capital', 0):,.2f}")
    perf.add_row("Final Value",     f"${stats.get('final_value', 0):,.2f}")
    perf.add_row("Total Return",    _pct(stats.get("total_return", 0)))
    perf.add_row("Ann. Return",     _pct(stats.get("annualized_return", 0)))
    perf.add_row("Sharpe Ratio",    _fmt(stats.get("sharpe_ratio", 0)))
    perf.add_row("Sortino Ratio",   _fmt(stats.get("sortino_ratio", 0)))
    perf.add_row("Max Drawdown",    _pct(stats.get("max_drawdown", 0)))
    console.print(perf)

    # --- Trade statistics table ---
    trade_tbl = Table(title="Trade Statistics", show_header=False)
    trade_tbl.add_column("Metric", style="bold cyan")
    trade_tbl.add_column("Value", justify="right")
    trade_tbl.add_row("Total Trades",    str(stats.get("total_trades", 0)))
    trade_tbl.add_row("Win Rate",        _pct(stats.get("win_rate", 0)))
    trade_tbl.add_row("Profit Factor",   _fmt(stats.get("profit_factor", 0)))
    trade_tbl.add_row("Avg Win",         f"${stats.get('avg_win', 0):.2f}")
    trade_tbl.add_row("Avg Loss",        f"${stats.get('avg_loss', 0):.2f}")
    trade_tbl.add_row("Best Trade",      f"${stats.get('best_trade', 0):.2f}")
    trade_tbl.add_row("Worst Trade",     f"${stats.get('worst_trade', 0):.2f}")
    trade_tbl.add_row("Commission Paid", f"${stats.get('commission_paid', 0):.2f}")
    console.print(trade_tbl)

    # --- Last 20 trades ---
    trades = result.trades
    if not trades.empty:
        last = trades.tail(20)
        t_tbl = Table(title="Last 20 Trades")
        for col in ["time", "side", "price", "size", "fee", "pnl"]:
            t_tbl.add_column(col.title(), justify="right" if col not in ("time", "side") else "left")
        for _, row in last.iterrows():
            t = str(row.get("time", ""))[:19]
            side = str(row.get("side", ""))
            price = f"{row.get('price', 0):.4f}"
            size = f"{row.get('size', 0):.4f}"
            fee = f"{row.get('fee', 0):.4f}"
            pnl_val = row.get("pnl", 0.0)
            pnl_str = f"[green]+${pnl_val:.2f}[/green]" if pnl_val > 0 else f"[red]-${abs(pnl_val):.2f}[/red]"
            t_tbl.add_row(t, side, price, size, fee, pnl_str)
        console.print(t_tbl)
    else:
        console.print("[yellow]No trades recorded.[/yellow]")


def _print_tearsheet_plain(result: "BacktestResult") -> None:
    """Fallback plain-text tearsheet when rich is not installed."""
    stats = result.stats_dict
    print("\n=== Backtest Results ===")
    print(f"Total Return:  {stats.get('total_return', 0)*100:.2f}%")
    print(f"Sharpe Ratio:  {stats.get('sharpe_ratio', 0):.2f}")
    print(f"Max Drawdown:  {stats.get('max_drawdown', 0)*100:.2f}%")
    print(f"Total Trades:  {stats.get('total_trades', 0)}")
    print(f"Win Rate:      {stats.get('win_rate', 0)*100:.2f}%")
    print(f"Final Value:   ${stats.get('final_value', 0):,.2f}")


# ------------------------------------------------------------------ #
# JSON serializer (re-export for convenience)                         #
# ------------------------------------------------------------------ #

def result_to_json(result: "BacktestResult") -> dict:
    """Serialize BacktestResult to JSON-safe dict.

    Returns:
        dict with keys: stats, equity_curve, trades, drawdown

    Each value is JSON-serializable (no numpy scalars, no Timestamps).
    """
    from auspicium.backtest.engine import result_to_dict
    return result_to_dict(result)
