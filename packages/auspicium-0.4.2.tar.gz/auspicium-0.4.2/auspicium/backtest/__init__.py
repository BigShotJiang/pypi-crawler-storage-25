"""Auspicium backtest module — historical strategy simulation.

Run historical backtests of Strategy subclasses using data from the DaaS REST API.
The same on_data() method runs in both backtest and live — zero code changes needed.

Quick start::

    from auspicium.backtest import run, run_sync, BacktestResult
    from my_strategy import BTCMomentum

    # Async (recommended)
    result = await run(BTCMomentum, symbol="BTC-USDT", start="2024-01-01", end="2024-06-30")

    # Sync (Jupyter notebooks)
    result = run_sync(BTCMomentum, symbol="BTC-USDT", start="2024-01-01")

    result.stats()          # pandas Series of performance metrics
    result.tearsheet()      # rich text summary
    result.plot()           # interactive plotly chart
    result.to_dict()        # JSON-safe dict for API responses
"""
from auspicium.backtest.engine import BacktestResult, run, run_sync
from auspicium.backtest.polymarket import PolymarketBacktest

__all__ = [
    "run",
    "run_sync",
    "BacktestResult",
    "PolymarketBacktest",
]
