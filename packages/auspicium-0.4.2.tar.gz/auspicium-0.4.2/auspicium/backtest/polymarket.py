"""Polymarket-specific backtest utilities.

Handles the unique aspects of prediction market data:
  - Loading resolved market data from DaaS
  - Converting YES/NO prices for vectorbt
  - Resolution handling (forced exit at market close)
  - Complement pricing: YES + NO = $1
  - Kelly criterion sizing grid
  - Single-market and multi-market backtest wrappers

Usage::

    from auspicium.backtest.polymarket import PolymarketBacktest

    # Load resolved markets
    markets = PolymarketBacktest.load_markets("BTC", start="2024-01-01", end="2024-06-30")

    # Load cross-OHLCV data
    cross = PolymarketBacktest.load_cross_ohlcv("BTC", granularity="5m", hours=720)

    # Prepare for vectorbt (adds no_price, injects resolution)
    prepared = PolymarketBacktest.prepare_for_vectorbt(
        cross, price_col="polymarket_up_close",
        resolution="Up", resolution_time=pd.Timestamp("2024-03-01")
    )

    # Kelly grid for parameter sweeps
    grid = PolymarketBacktest.kelly_grid(p_range=(0.4, 0.8), c_range=(0.2, 0.7))
"""
from __future__ import annotations

import asyncio
import logging
from datetime import datetime, timezone
from typing import TYPE_CHECKING

import numpy as np
import pandas as pd

if TYPE_CHECKING:
    from auspicium.backtest.engine import BacktestResult

log = logging.getLogger(__name__)


class PolymarketBacktest:
    """Polymarket-specific backtest utilities.

    All methods are static — this class is a namespace, not instantiated.
    """

    @staticmethod
    def load_markets(
        base_asset: str = "BTC",
        start: str = "2024-01-01",
        end: str = "2024-12-31",
        status: str = "closed",
    ) -> pd.DataFrame:
        """Load resolved Polymarket markets from DaaS.

        Args:
            base_asset: Underlying asset ("BTC", "ETH", "SOL", …)
            start:      ISO date string — earliest candle_open to include.
            end:        ISO date string — latest candle_open to include.
            status:     "closed" for resolved markets, "active" for live.

        Returns:
            DataFrame indexed by candle_open with columns:
            condition_id, question, base_asset, interval, candle_open,
            candle_close, active, closed, resolution
        """
        from auspicium.connectors.rest import RestConnector

        df = RestConnector.markets(status=status, base_asset=base_asset)
        if df.empty:
            return df

        # Filter by date range
        try:
            df = df[start:end]
        except Exception:
            pass

        return df

    @staticmethod
    def load_cross_ohlcv(
        base_asset: str = "BTC",
        granularity: str = "5m",
        hours: int = 720,
    ) -> pd.DataFrame:
        """Load joined Binance + Polymarket price data.

        Args:
            base_asset:   Underlying asset.
            granularity:  Bar interval ("1m" or "5m").
            hours:        Lookback window in hours (720 = 30 days).

        Returns:
            DataFrame with columns: base_asset, condition_id,
            binance_open/high/low/close/volume,
            polymarket_up_open/high/low/close/volume,
            poly_price_ticks, poly_trade_count, is_provisional
        """
        from auspicium.connectors.rest import RestConnector

        return RestConnector.cross_market(
            granularity=granularity,
            base_asset=base_asset,
            hours=hours,
        )

    @staticmethod
    def prepare_for_vectorbt(
        df: pd.DataFrame,
        price_col: str = "polymarket_up_close",
        resolution: str | None = None,
        resolution_time: datetime | None = None,
    ) -> pd.DataFrame:
        """Prepare a single market's price series for vectorbt.

        - Adds ``no_price`` column (1 - yes_price) for Down-outcome backtesting
        - Renames ``price_col`` to ``yes_price``
        - Truncates at ``resolution_time`` (if provided)
        - Injects resolution price (1.0 for Up win, 0.0 for Down win) as final bar

        Args:
            df:               Cross-OHLCV DataFrame (from load_cross_ohlcv).
            price_col:        Column to use as the YES price series.
            resolution:       "Up" or "Down" — determines final injected price.
            resolution_time:  If set, truncate data at this timestamp.

        Returns:
            DataFrame with columns: yes_price, no_price (plus original columns).
        """
        out = df.copy()

        # Truncate at resolution_time
        if resolution_time is not None:
            if not isinstance(resolution_time, pd.Timestamp):
                resolution_time = pd.Timestamp(resolution_time, tz="UTC")
            out = out[out.index <= resolution_time]

        # Rename price column to yes_price
        if price_col in out.columns and price_col != "yes_price":
            out = out.rename(columns={price_col: "yes_price"})
        elif "yes_price" not in out.columns:
            raise KeyError(f"Column '{price_col}' not found in DataFrame")

        # Drop NaN yes_prices
        out = out.dropna(subset=["yes_price"])

        # Add complement
        out["no_price"] = (1.0 - out["yes_price"]).clip(0.0, 1.0)

        # Inject resolution bar at the end
        if resolution is not None and not out.empty:
            yes_final = 1.0 if resolution.lower() == "up" else 0.0
            no_final = 1.0 - yes_final
            resolution_bar = pd.DataFrame(
                {"yes_price": [yes_final], "no_price": [no_final]},
                index=[out.index[-1] + pd.Timedelta(seconds=1)],
            )
            # Fill other columns with last known values
            for col in out.columns:
                if col not in ("yes_price", "no_price"):
                    resolution_bar[col] = out[col].iloc[-1]
            out = pd.concat([out, resolution_bar])

        return out

    @staticmethod
    def prepare_price_matrix(
        markets: pd.DataFrame,
        cross_data: pd.DataFrame,
    ) -> pd.DataFrame:
        """Build a price matrix for multi-market vectorbt backtesting.

        Rows = time (from cross_data index).
        Columns = condition_ids.
        Values = YES (Up) price from polymarket_up_close.

        Injects resolution values (1.0 for Up win, 0.0 for Down win) at market
        close time for each market. Markets not present in cross_data are skipped.

        Args:
            markets:    DataFrame from load_markets() — must have condition_id,
                        candle_close, and resolution columns.
            cross_data: DataFrame from load_cross_ohlcv() — must have
                        condition_id and polymarket_up_close columns.

        Returns:
            Wide DataFrame: columns = condition_ids, index = time.
        """
        if cross_data.empty or markets.empty:
            return pd.DataFrame()

        price_cols: dict[str, pd.Series] = {}

        for _, mkt in markets.iterrows():
            cid = mkt.get("condition_id")
            if cid is None:
                continue

            # Filter cross_data to this condition_id
            if "condition_id" in cross_data.columns:
                mkt_data = cross_data[cross_data["condition_id"] == cid]
            else:
                mkt_data = cross_data

            if mkt_data.empty or "polymarket_up_close" not in mkt_data.columns:
                continue

            series = mkt_data["polymarket_up_close"].dropna()

            # Inject resolution at candle_close
            resolution = mkt.get("resolution")
            candle_close = mkt.get("candle_close")
            if resolution is not None and candle_close is not None:
                yes_final = 1.0 if str(resolution).lower() == "up" else 0.0
                close_ts = pd.Timestamp(candle_close)
                if close_ts.tzinfo is None:
                    close_ts = close_ts.tz_localize("UTC")
                else:
                    close_ts = close_ts.tz_convert("UTC")
                series = series[series.index <= close_ts]
                resolution_ts = close_ts + pd.Timedelta(seconds=1)
                series.loc[resolution_ts] = yes_final

            price_cols[cid] = series

        if not price_cols:
            return pd.DataFrame()

        matrix = pd.DataFrame(price_cols)
        matrix.index.name = "time"
        return matrix.sort_index()

    @staticmethod
    def kelly_grid(
        p_range: tuple[float, float] = (0.3, 0.8),
        c_range: tuple[float, float] = (0.2, 0.7),
        n_points: int = 50,
        fraction: float = 0.5,
    ) -> pd.DataFrame:
        """Generate a Kelly criterion sizing grid for parameter sweeps.

        Formula: f* = (p - c) / (1 - c)
        Expected growth ≈ p * log(1 + f*(1-c)/c) + (1-p) * log(1 - f*)

        Args:
            p_range:  (min, max) estimated win probability.
            c_range:  (min, max) contract cost / price.
            n_points: Grid resolution per axis.
            fraction: Fractional Kelly multiplier (default 0.5 = half-Kelly).

        Returns:
            DataFrame with columns: p, c, edge, kelly_fraction, expected_growth.
        """
        p_vals = np.linspace(p_range[0], p_range[1], n_points)
        c_vals = np.linspace(c_range[0], c_range[1], n_points)

        records = []
        for p in p_vals:
            for c in c_vals:
                if c >= 1.0 or p <= c:
                    kelly_f = 0.0
                    growth = 0.0
                else:
                    kelly_f = fraction * (p - c) / (1.0 - c)
                    kelly_f = float(np.clip(kelly_f, 0.0, 1.0))
                    # Expected log growth per bet
                    win_payoff = kelly_f * (1.0 - c) / c  # gain per dollar risked
                    if kelly_f < 1.0 and win_payoff > -1.0:
                        try:
                            growth = float(
                                p * np.log1p(win_payoff) + (1 - p) * np.log1p(-kelly_f)
                            )
                        except Exception:
                            growth = 0.0
                    else:
                        growth = 0.0

                records.append({
                    "p": float(p),
                    "c": float(c),
                    "edge": float(p - c),
                    "kelly_fraction": kelly_f,
                    "expected_growth": growth,
                })

        return pd.DataFrame(records)

    @staticmethod
    def run_single_market(
        strategy_cls: type,
        condition_id: str,
        start: str = "2024-01-01",
        end: str = "2024-12-31",
        initial_capital: float = 1_000.0,
        **kwargs,
    ) -> "BacktestResult":
        """Backtest a strategy on a single Polymarket market (sync convenience).

        Loads cross-OHLCV for the market's base asset, filters to the
        condition_id, and runs the backtest using run_sync().

        Args:
            strategy_cls:   Strategy subclass.
            condition_id:   Polymarket condition_id.
            start:          ISO date string.
            end:            ISO date string.
            initial_capital: Starting cash.
            **kwargs:       Passed to run_sync (config, risk_limits, etc.)

        Returns:
            BacktestResult
        """
        from auspicium.backtest.engine import run_sync

        return run_sync(
            strategy_cls,
            source="polymarket",
            symbol=condition_id,
            start=start,
            end=end,
            initial_capital=initial_capital,
            **kwargs,
        )

    @staticmethod
    def run_multi_market(
        strategy_cls: type,
        base_asset: str = "BTC",
        start: str = "2024-01-01",
        end: str = "2024-12-31",
        max_markets: int = 50,
        initial_capital: float = 10_000.0,
        **kwargs,
    ) -> "BacktestResult":
        """Backtest a strategy across multiple resolved Polymarket markets.

        Loads all resolved markets for the base asset in the date range and
        combines fills/equity from all runs into a single BacktestResult.

        Note: each market gets an equal share of initial_capital
        (initial_capital / num_markets), preventing over-leverage.

        Args:
            strategy_cls:   Strategy subclass.
            base_asset:     Underlying asset ("BTC", "ETH", …).
            start:          ISO date string.
            end:            ISO date string.
            max_markets:    Cap on the number of markets to backtest.
            initial_capital: Total capital across all markets.
            **kwargs:       Passed to each run_sync call.

        Returns:
            Aggregated BacktestResult.
        """
        from auspicium.backtest.engine import BacktestResult, _compute_stats, _compute_trade_pnl, run_sync
        from auspicium.connectors.rest import RestConnector

        markets_df = RestConnector.markets(status="closed", base_asset=base_asset)
        if markets_df.empty:
            raise ValueError(f"No closed markets found for {base_asset}")

        try:
            markets_df = markets_df[start:end]
        except Exception:
            pass

        markets_df = markets_df.head(max_markets)
        if markets_df.empty:
            raise ValueError(f"No markets in range {start}→{end} for {base_asset}")

        per_market_capital = initial_capital / max(len(markets_df), 1)
        log.info(
            "Multi-market backtest: %d markets, %.2f each",
            len(markets_df), per_market_capital,
        )

        all_equities: list[pd.Series] = []
        all_trades: list[pd.DataFrame] = []
        ohlcv_ref: pd.DataFrame | None = None

        for _, mkt in markets_df.iterrows():
            cid = mkt.get("condition_id", "")
            try:
                result = run_sync(
                    strategy_cls,
                    source="polymarket",
                    symbol=cid,
                    start=start,
                    end=end,
                    initial_capital=per_market_capital,
                    **kwargs,
                )
                all_equities.append(result.equity_curve)
                all_trades.append(result.trades)
                if ohlcv_ref is None:
                    ohlcv_ref = result.ohlcv
            except Exception as exc:
                log.warning("Market %s failed: %s", cid, exc)

        if not all_equities:
            raise ValueError("All markets failed during multi-market backtest")

        # Combine equity curves by summing (aligned by outer join)
        combined = pd.concat(all_equities, axis=1).fillna(method="ffill").fillna(0.0).sum(axis=1)
        combined.name = "equity"

        combined_trades = pd.concat(all_trades, ignore_index=True) if all_trades else pd.DataFrame()
        returns = combined.pct_change().dropna()
        stats = _compute_stats(combined, combined_trades, initial_capital)

        return BacktestResult(
            equity_curve=combined,
            trades=combined_trades,
            returns=returns,
            ohlcv=ohlcv_ref or pd.DataFrame(),
            initial_capital=initial_capital,
            stats_dict=stats,
        )
