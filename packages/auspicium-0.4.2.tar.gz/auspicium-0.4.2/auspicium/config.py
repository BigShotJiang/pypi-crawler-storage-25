"""Central configuration for the Auspicium SDK.

Resolution order (highest → lowest priority):
  1. Environment variables (AUSP_*)
  2. .auspicium.yaml in current directory
  3. .auspicium.yaml in home directory
  4. Built-in defaults
"""
from __future__ import annotations

import os
from dataclasses import dataclass
from pathlib import Path

import yaml

from auspicium.errors import AuthError

_DEFAULTS = {
    "gateway_url": "https://api.auspicium.io",
    "ws_url":      "wss://api.auspicium.io/v1/ws",
    "env":         "design",
}


def _load_yaml() -> dict:
    for path in [Path.cwd() / ".auspicium.yaml", Path.home() / ".auspicium.yaml"]:
        if path.exists():
            try:
                return yaml.safe_load(path.read_text()) or {}
            except yaml.YAMLError:
                pass
    return {}


@dataclass(frozen=True)
class Config:
    api_key:     str
    gateway_url: str
    ws_url:      str
    env:         str   # design | quality | production


_config: Config | None = None


def get_config() -> Config:
    """Return the singleton Config, loading from env/yaml on first call."""
    global _config
    if _config is not None:
        return _config

    yaml_cfg = _load_yaml()

    def _get(env_key: str, yaml_key: str, default: str | None = None) -> str | None:
        return os.environ.get(env_key) or yaml_cfg.get(yaml_key) or default

    api_key = _get("AUSP_API_KEY", "api_key")
    if not api_key:
        raise AuthError(
            "No API key found. Set the AUSP_API_KEY environment variable "
            "or add 'api_key' to ~/.auspicium.yaml"
        )

    _config = Config(
        api_key=api_key,
        gateway_url=_get("AUSP_GATEWAY_URL", "gateway_url", _DEFAULTS["gateway_url"]),
        ws_url=_get("AUSP_WS_URL",      "ws_url",      _DEFAULTS["ws_url"]),
        env=_get("AUSP_ENV",             "env",          _DEFAULTS["env"]),
    )
    return _config


def reset_config() -> None:
    """Clear cached config (useful in tests)."""
    global _config
    _config = None