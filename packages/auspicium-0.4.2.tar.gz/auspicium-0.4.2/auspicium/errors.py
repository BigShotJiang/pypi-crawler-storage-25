"""Custom exceptions for the Auspicium SDK."""


class AuspiciumError(Exception):
    """Base exception for all SDK errors."""


class AuthError(AuspiciumError):
    """Invalid or missing API key (HTTP 401)."""


class RateLimitError(AuspiciumError):
    """Rate limit exceeded after all retries (HTTP 429)."""


class TierRestrictionError(AuspiciumError):
    """Feature or data source not available on current tier (HTTP 403)."""


class QueryTimeoutError(AuspiciumError):
    """Query exceeded the server-side timeout for this tier."""


class ConnectionError(AuspiciumError):
    """WebSocket or HTTP connection failed."""


class RiskLimitError(AuspiciumError):
    """Order rejected by risk guardian — a risk limit would be breached."""


class ExchangeError(AuspiciumError):
    """Exchange connectivity, authentication, or API error."""


class OrderRejectedError(ExchangeError):
    """Order was rejected by the exchange."""