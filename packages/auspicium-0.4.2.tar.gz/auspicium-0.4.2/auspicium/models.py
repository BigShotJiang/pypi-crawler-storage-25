"""Pydantic v2 data models for the Auspicium platform.

Only models that correspond to actual tables/endpoints in the platform are included:
  - OHLCV          → market.ohlcv / /v1/ohlcv
  - Trade          → market.trades / /v1/trades
  - OrderBookLevel → nested in OrderBook
  - OrderBook      → market.orderbook / /v1/orderbook
  - PolymarketMarket → polymarket.markets / /v1/markets
  - PolymarketPrice  → polymarket.prices
  - CrossOHLCV       → market.enriched_cross_ohlcv / /v1/cross-market
  - StreamMessage    → WebSocket push messages
"""
from __future__ import annotations

from datetime import datetime

from pydantic import BaseModel, field_validator


class OHLCV(BaseModel):
    time:     datetime
    symbol:   str
    exchange: str
    open:     float
    high:     float
    low:      float
    close:    float
    volume:   float


class Trade(BaseModel):
    time:        datetime
    symbol:      str        # e.g. "BTC-USDT" or "BTC-1H-UP"
    source:      str        # "binance" | "polymarket"
    price:       float
    quantity:    float      # token_amount (polymarket) or base qty (binance)
    side:        str        # "buy" | "sell" | "BUY" | "SELL"
    usd_amount:  float | None = None   # polymarket only
    tx_hash:     str | None  = None    # polymarket REST trades only


class OrderBookLevel(BaseModel):
    price: float
    size:  float


class OrderBook(BaseModel):
    time:      datetime
    symbol:    str
    exchange:  str
    bids:      list[OrderBookLevel]
    asks:      list[OrderBookLevel]
    spread:    float
    mid_price: float

    @field_validator("spread", "mid_price", mode="before")
    @classmethod
    def _compute_from_levels(cls, v):
        return v  # pre-computed by API


class PolymarketMarket(BaseModel):
    condition_id: str
    question:     str
    base_asset:   str         # "BTC" | "ETH" | "SOL"
    interval:     str         # "1H"
    candle_open:  datetime
    candle_close: datetime
    active:       bool
    closed:       bool
    resolution:   str | None  # "Up" | "Down" | None


class PolymarketPrice(BaseModel):
    time:         datetime
    token_id:     str
    condition_id: str
    outcome:      str         # "Up" | "Down"
    base_asset:   str
    price:        float       # implied probability [0, 1]
    best_bid:     float | None = None
    best_ask:     float | None = None
    spread:       float | None = None


class CrossOHLCV(BaseModel):
    """Joined Binance OHLCV + Polymarket Up-token implied-probability OHLCV.

    Source: market.enriched_cross_ohlcv — computed every 2 min by DAG.
    Down = 1 − Up (deterministic), so only Up columns are stored.
    """
    time:                 datetime
    granularity:          str      # "1m" | "5m"
    base_asset:           str
    condition_id:         str
    binance_open:         float | None
    binance_high:         float | None
    binance_low:          float | None
    binance_close:        float | None
    binance_volume:       float | None
    polymarket_up_open:   float | None
    polymarket_up_high:   float | None
    polymarket_up_low:    float | None
    polymarket_up_close:  float | None
    polymarket_up_volume: float | None
    poly_price_ticks:     int
    poly_trade_count:     int
    is_provisional:       bool


class StreamMessage(BaseModel):
    """Message pushed by the WebSocket server."""
    channel:      str           # "ohlcv" | "trades" | "orderbook" | "polymarket"
    source:       str           # "binance" | "polymarket"
    symbol:       str | None
    payload:      dict
    timestamp_ms: int