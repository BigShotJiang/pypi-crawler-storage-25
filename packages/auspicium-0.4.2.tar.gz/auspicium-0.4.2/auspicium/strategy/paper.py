"""Paper exchange — simulates order execution against live market data.

Used in quality environment (AUSPICIUM_ENV=quality).

Binance orders:
    Price sourced from RestConnector.orderbook() → fills at ask+slippage (BUY)
    or bid-slippage (SELL). Slippage = spread * 0.1. Fee = 0.1% taker.

Polymarket orders:
    No live price lookup — fills at the submitted order.price directly.
    (The markets API does not expose live bid/ask; the strategy sets the
    limit price itself from tick payloads.) Fee ≈ size * 0.02 * p * (1-p).
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Callable

from auspicium.exchange.base import BaseExchange
from auspicium.strategy.models import Fill, Order, Position

log = logging.getLogger(__name__)

# Heuristic: condition_ids are long hex strings (32+ chars); Binance symbols contain "-"
_BINANCE_MARKET_SIGNALS = ("-USDT", "-BTC", "-ETH", "-BNB")


def _is_binance(market: str) -> bool:
    return any(market.upper().endswith(s) for s in _BINANCE_MARKET_SIGNALS)


class PaperExchange(BaseExchange):
    """Simulates order execution for quality-mode live trading.

    Conforms to :class:`BaseExchange` so the runner can treat paper and
    real adapters uniformly.

    Args:
        initial_cash:   Starting cash in USD.
        fill_callback:  Async callable ``(fill: Fill) -> None`` registered by
                        the runner. Called immediately after each fill so the
                        runner can update portfolio state and call on_fill().
    """

    def __init__(
        self,
        initial_cash: float = 10_000.0,
        fill_callback: Callable[[Fill], None] | None = None,
    ) -> None:
        super().__init__(fill_callback=fill_callback)
        self._cash = initial_cash
        self._fills: list[Fill] = []
        self._open_orders: dict[str, Order] = {}

    # ------------------------------------------------------------------ #
    # Public interface (mirrors real exchange adapter contract)            #
    # ------------------------------------------------------------------ #

    async def submit(self, order: Order) -> str:
        """Submit an order and attempt immediate fill.

        For Binance: fetches live orderbook and fills at best ask/bid ± slippage.
        For Polymarket: fills immediately at submitted order.price.
        Limit orders that cannot fill immediately are queued in _open_orders.

        Returns:
            The order id (same as ``order.id`` for paper).
        """
        if _is_binance(order.market):
            await self._submit_binance(order)
        else:
            await self._submit_polymarket(order)
        return order.id

    async def cancel(self, order_id: str) -> bool:
        """Cancel a pending limit order. Returns True if found and cancelled."""
        if order_id in self._open_orders:
            del self._open_orders[order_id]
            log.info("Paper: cancelled order %s", order_id)
            return True
        return False

    async def check_pending_orders(self, current_prices: dict[str, float]) -> None:
        """Check if any queued limit orders can now be filled.

        Called by the runner after every data tick.

        Args:
            current_prices: mapping of market → current mid price
        """
        filled_ids = []
        for order_id, order in list(self._open_orders.items()):
            price = current_prices.get(order.market)
            if price is None:
                continue
            # BUY limit: fill when market price ≤ limit price
            if order.side == "BUY" and price <= order.price:
                await self._execute_fill(order, fill_price=order.price)
                filled_ids.append(order_id)
            # SELL limit: fill when market price ≥ limit price
            elif order.side == "SELL" and price >= order.price:
                await self._execute_fill(order, fill_price=order.price)
                filled_ids.append(order_id)
        for oid in filled_ids:
            self._open_orders.pop(oid, None)

    # ------------------------------------------------------------------ #
    # Internal                                                             #
    # ------------------------------------------------------------------ #

    async def _submit_binance(self, order: Order) -> None:
        """Fill Binance order against live orderbook snapshot."""
        try:
            from auspicium.connectors.rest import RestConnector
            # orderbook() returns dict: {bids: [{price, size}], asks: [{price, size}], ...}
            book = RestConnector.orderbook(
                source="binance", symbol=order.market.upper(), depth=1
            )
            bids = book.get("bids", [])
            asks = book.get("asks", [])

            if order.side == "BUY":
                if not asks:
                    log.warning("Paper: no asks for %s — queuing order", order.market)
                    self._open_orders[order.id] = order
                    return
                best_ask = float(asks[0]["price"]) if isinstance(asks[0], dict) else float(asks[0][0])
                spread = float(book.get("spread", best_ask * 0.0002))
                fill_price = best_ask + spread * 0.1
                if order.order_type == "LIMIT" and order.price < fill_price:
                    # Limit not yet reachable — queue it
                    self._open_orders[order.id] = order
                    return
            else:  # SELL
                if not bids:
                    log.warning("Paper: no bids for %s — queuing order", order.market)
                    self._open_orders[order.id] = order
                    return
                best_bid = float(bids[0]["price"]) if isinstance(bids[0], dict) else float(bids[0][0])
                spread = float(book.get("spread", best_bid * 0.0002))
                fill_price = best_bid - spread * 0.1
                if order.order_type == "LIMIT" and order.price > fill_price:
                    self._open_orders[order.id] = order
                    return

        except Exception as exc:
            log.warning("Paper: orderbook fetch failed (%s) — queuing order", exc)
            self._open_orders[order.id] = order
            return

        await self._execute_fill(order, fill_price=fill_price)

    async def _submit_polymarket(self, order: Order) -> None:
        """Fill Polymarket order at the submitted limit price immediately."""
        # Paper fills execute at submitted price — no live price lookup needed
        # (markets API has no live bid/ask; strategy sets price from tick payload)
        await self._execute_fill(order, fill_price=order.price)

    async def _execute_fill(self, order: Order, fill_price: float) -> None:
        """Record a fill, update cash/positions, and call the fill_callback."""
        # Compute fee
        if _is_binance(order.market):
            fee = order.size * fill_price * 0.001  # 0.1% taker
        else:
            # Polymarket fee ≈ 2% of expected value
            fee = order.size * 0.02 * fill_price * (1.0 - fill_price)

        fill = Fill(
            order_id=order.id,
            market=order.market,
            side=order.side,
            outcome=order.outcome,
            price=fill_price,
            size=order.size,
            fee=fee,
            timestamp=datetime.now(timezone.utc),
            status="CONFIRMED",
        )
        self._fills.append(fill)

        # Update internal cash
        cost = order.size * fill_price + fee
        if order.side == "BUY":
            self._cash -= cost
        else:
            self._cash += order.size * fill_price - fee

        # Update internal position
        self._update_position(order, fill_price)

        log.info(
            "Paper fill: %s %s %s %.4f @ %.4f (fee %.4f)",
            order.side, order.outcome, order.market, order.size, fill_price, fee,
        )

        # Notify runner (via BaseExchange helper — handles sync + async)
        await self._notify_fill(fill)

    def _update_position(self, order: Order, fill_price: float) -> None:
        """Update internal position tracker after a fill."""
        market = order.market
        existing = self._positions.get(market)

        if order.side == "BUY":
            if existing is None:
                self._positions[market] = Position(
                    market=market,
                    side="LONG",
                    outcome=order.outcome,
                    size=order.size,
                    entry_price=fill_price,
                )
            else:
                # Average in
                total_size = existing.size + order.size
                avg_price = (existing.entry_price * existing.size + fill_price * order.size) / total_size
                existing.size = total_size
                existing.entry_price = avg_price
        else:  # SELL
            if existing is None:
                self._positions[market] = Position(
                    market=market,
                    side="SHORT",
                    outcome=order.outcome,
                    size=order.size,
                    entry_price=fill_price,
                )
            else:
                remaining = existing.size - order.size
                if remaining <= 0:
                    del self._positions[market]
                else:
                    existing.size = remaining

    # ------------------------------------------------------------------ #
    # BaseExchange interface — balance + emergency shutdown                #
    # ------------------------------------------------------------------ #

    async def get_balance(self) -> float:
        """Return the paper cash balance."""
        return self._cash

    async def emergency_close_all(self) -> list[Fill]:
        """Cancel all pending orders and close all positions at last price.

        Idempotent; calling twice is a no-op after the first invocation.
        """
        self._open_orders.clear()
        fills: list[Fill] = []
        for market, pos in list(self._positions.items()):
            close_price = pos.current_price if pos.current_price > 0 else pos.entry_price
            fill = Fill(
                order_id=f"emergency-{market}",
                market=market,
                side="SELL" if pos.side == "LONG" else "BUY",
                outcome=pos.outcome,
                price=close_price,
                size=pos.size,
                fee=0.0,
                timestamp=datetime.now(timezone.utc),
                status="CONFIRMED",
            )
            self._fills.append(fill)
            fills.append(fill)
            await self._notify_fill(fill)
        self._positions.clear()
        return fills

    # ------------------------------------------------------------------ #
    # Accessors                                                            #
    # ------------------------------------------------------------------ #

    @property
    def open_orders(self) -> dict[str, Order]:
        return self._open_orders
