"""Auspicium strategy execution framework.

Quants subclass :class:`Strategy`, implement ``configure()`` and ``on_data()``,
and use the framework-provided helpers (submit, cancel, kelly_size, etc.).
The :class:`StrategyRunner` wires up the exchange adapter, state manager,
and risk guardian — the strategy never references them directly.

Quick start::

    from auspicium.strategy import Strategy, Order

    class MyStrategy(Strategy):
        def configure(self):
            self.subscribe("ohlcv", source="binance", symbol="BTC-USDT")

        async def on_data(self, tick):
            order = Order(market="BTC-USDT", side="BUY", size=0.01, price=tick.payload["close"])
            await self.submit(order)
"""
from __future__ import annotations

from auspicium.strategy.base import Strategy
from auspicium.strategy.models import Fill, Order, Portfolio, Position
from auspicium.strategy.runner import StrategyRunner

__all__ = [
    "Strategy",
    "StrategyRunner",
    "Order",
    "Fill",
    "Position",
    "Portfolio",
]
