"""Risk guardian — enforces position and loss limits on every order submission.

Limits are loaded from the strategy's manifest.yaml and cannot be bypassed
by the strategy code. Every call to Strategy.submit() passes through here.
"""
from __future__ import annotations

import logging

from auspicium.errors import RiskLimitError
from auspicium.strategy.models import Order, Portfolio

log = logging.getLogger(__name__)


class RiskGuardian:
    """Enforces risk limits declared in manifest.yaml.

    Wraps every order submission. Cannot be bypassed by the strategy.

    Manifest limits (all optional, with sensible defaults):
        max_position_usd:       maximum value of a single order
        max_total_exposure_usd: maximum sum of all open position values
        max_daily_loss_usd:     maximum loss allowed in a single day
        max_open_orders:        maximum number of pending orders at once
    """

    def __init__(self, limits: dict) -> None:
        self.max_position_usd = float(limits.get("max_position_usd", 1_000))
        self.max_total_exposure_usd = float(limits.get("max_total_exposure_usd", 5_000))
        self.max_daily_loss_usd = float(limits.get("max_daily_loss_usd", 500))
        self.max_open_orders = int(limits.get("max_open_orders", 20))

    def check(self, order: Order, portfolio: Portfolio, open_order_count: int = 0) -> None:
        """Validate an order against all risk limits.

        Args:
            order:            The order to validate.
            portfolio:        Current portfolio state (for exposure + daily PnL checks).
            open_order_count: Number of currently pending orders (from strategy._open_orders).

        Raises:
            RiskLimitError: If any limit would be breached.
        """
        order_value = order.size * order.price

        # 1. Single order size
        if order_value > self.max_position_usd:
            raise RiskLimitError(
                f"Order value ${order_value:.2f} exceeds max_position_usd "
                f"${self.max_position_usd:.2f}"
            )

        # 2. Total portfolio exposure
        current_exposure = sum(
            p.size * max(p.current_price, p.entry_price)
            for p in portfolio.positions.values()
        )
        if current_exposure + order_value > self.max_total_exposure_usd:
            raise RiskLimitError(
                f"Total exposure ${current_exposure + order_value:.2f} would exceed "
                f"max_total_exposure_usd ${self.max_total_exposure_usd:.2f}"
            )

        # 3. Daily loss limit
        if portfolio.daily_pnl < -self.max_daily_loss_usd:
            raise RiskLimitError(
                f"Daily loss ${-portfolio.daily_pnl:.2f} exceeds "
                f"max_daily_loss_usd ${self.max_daily_loss_usd:.2f} — trading halted"
            )

        # 4. Open order count
        if open_order_count >= self.max_open_orders:
            raise RiskLimitError(
                f"Open order count {open_order_count} would exceed "
                f"max_open_orders {self.max_open_orders}"
            )

        log.debug(
            "Risk check passed: %s %s %.4f @ %.4f (exposure %.2f / daily_pnl %.2f)",
            order.side, order.market, order.size, order.price,
            current_exposure + order_value, portfolio.daily_pnl,
        )

    def should_auto_kill(self, portfolio: Portfolio) -> bool:
        """Return True if the bot should be killed due to risk breach.

        Called by the runner after every tick to check for emergency shutdown.
        """
        breached = portfolio.daily_pnl < -self.max_daily_loss_usd
        if breached:
            log.error(
                "AUTO-KILL triggered: daily_pnl=%.2f exceeds limit=%.2f",
                portfolio.daily_pnl, self.max_daily_loss_usd,
            )
        return breached
