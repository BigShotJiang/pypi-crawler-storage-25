"""Entry point for ``python -m auspicium.strategy.runner``."""
from auspicium.strategy.runner import main

main()
