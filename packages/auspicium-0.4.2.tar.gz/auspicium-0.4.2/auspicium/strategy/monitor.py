"""Prometheus metrics for strategy monitoring.

Exposes metrics at :9090/metrics for scraping by the platform's Prometheus instance.
Gracefully degrades to a no-op if prometheus_client is not installed.

Install the optional extra to enable:
    pip install auspicium[strategy]
"""
from __future__ import annotations

import logging
import time

from auspicium.strategy.models import Fill, Portfolio

log = logging.getLogger(__name__)


class StrategyMonitor:
    """Exposes Prometheus metrics at :9090/metrics.

    All public methods are safe to call regardless of whether prometheus_client
    is installed — they become no-ops if the import fails.

    Metrics (all labelled by strategy name):
        bot_pnl_total           — gauge, current total realized PnL
        bot_daily_pnl           — gauge, today's PnL
        bot_trades_total        — counter, cumulative fills by side (BUY/SELL)
        bot_position_count      — gauge, number of open positions
        bot_open_orders         — gauge, number of pending orders
        bot_uptime_seconds      — gauge, seconds since monitor start
        bot_last_trade_ts       — gauge, unix timestamp of last fill
    """

    def __init__(self, strategy_name: str, port: int = 9090) -> None:
        self._name = strategy_name
        self._start_time = time.time()
        self._available = False

        try:
            from prometheus_client import Counter, Gauge, start_http_server

            self._pnl = Gauge("bot_pnl_total", "Total realized PnL (USD)", ["strategy"])
            self._daily_pnl = Gauge("bot_daily_pnl", "Daily PnL (USD)", ["strategy"])
            self._trades = Counter(
                "bot_trades_total", "Cumulative fills", ["strategy", "side"]
            )
            self._positions = Gauge(
                "bot_position_count", "Open position count", ["strategy"]
            )
            self._open_orders = Gauge(
                "bot_open_orders", "Pending order count", ["strategy"]
            )
            self._uptime = Gauge(
                "bot_uptime_seconds", "Seconds since start", ["strategy"]
            )
            self._last_trade_ts = Gauge(
                "bot_last_trade_ts", "Unix timestamp of last fill", ["strategy"]
            )

            start_http_server(port)
            self._available = True
            log.info("StrategyMonitor: Prometheus metrics at :%d/metrics", port)

        except ImportError:
            log.info(
                "StrategyMonitor: prometheus_client not installed — metrics disabled. "
                "Install with: pip install auspicium[strategy]"
            )
        except Exception as exc:
            log.warning("StrategyMonitor: failed to start metrics server: %s", exc)

    def update(self, portfolio: Portfolio, open_order_count: int = 0) -> None:
        """Update all gauges from the current portfolio state."""
        if not self._available:
            return
        self._pnl.labels(self._name).set(portfolio.realized_pnl)
        self._daily_pnl.labels(self._name).set(portfolio.daily_pnl)
        self._positions.labels(self._name).set(len(portfolio.positions))
        self._open_orders.labels(self._name).set(open_order_count)
        self._uptime.labels(self._name).set(time.time() - self._start_time)

    def record_fill(self, fill: Fill) -> None:
        """Increment trade counter and update last-trade timestamp."""
        if not self._available:
            return
        self._trades.labels(self._name, fill.side).inc()
        self._last_trade_ts.labels(self._name).set(
            fill.timestamp.timestamp()
        )
