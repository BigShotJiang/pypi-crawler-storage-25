"""Strategy framework data models.

Separate from auspicium/models.py (DaaS data models).
These models represent trading primitives: orders, fills, positions, portfolio.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

from pydantic import BaseModel, model_validator


class Order(BaseModel):
    """An order to submit to the exchange (paper or real)."""

    market: str                 # condition_id (Polymarket) or symbol (Binance, e.g. BTC-USDT)
    side: str                   # "BUY" or "SELL"
    outcome: str = "YES"        # "YES" or "NO" (Polymarket only, ignored for Binance)
    size: float                 # Number of shares/units
    price: float                # Limit price
    order_type: str = "LIMIT"   # "LIMIT" or "MARKET"
    id: str = ""                # Auto-generated if empty

    @model_validator(mode="after")
    def _generate_id(self) -> Order:
        if not self.id:
            self.id = uuid.uuid4().hex[:12]
        return self


class Fill(BaseModel):
    """A completed order fill (from paper or real exchange)."""

    order_id: str
    market: str
    side: str
    outcome: str
    price: float
    size: float
    fee: float = 0.0
    timestamp: datetime
    status: str = "CONFIRMED"   # "MATCHED" | "CONFIRMED" | "FAILED"

    @classmethod
    def now(cls, **kwargs: Any) -> Fill:
        """Convenience constructor that sets timestamp to now (UTC)."""
        return cls(timestamp=datetime.now(timezone.utc), **kwargs)


class Position(BaseModel):
    """A current position in a market."""

    market: str
    side: str                   # "LONG" or "SHORT"
    outcome: str = "YES"        # Polymarket outcome ("YES" / "NO")
    size: float
    entry_price: float
    current_price: float = 0.0
    unrealized_pnl: float = 0.0

    def update_price(self, price: float) -> None:
        """Update current_price and recompute unrealized PnL."""
        self.current_price = price
        direction = 1.0 if self.side == "LONG" else -1.0
        self.unrealized_pnl = direction * self.size * (price - self.entry_price)


class Portfolio(BaseModel):
    """Full portfolio state."""

    cash: float
    positions: dict[str, Position] = {}   # keyed by market (condition_id or symbol)
    total_value: float = 0.0
    realized_pnl: float = 0.0
    unrealized_pnl: float = 0.0
    daily_pnl: float = 0.0

    def recompute(self) -> None:
        """Recompute total_value and unrealized_pnl from current positions."""
        self.unrealized_pnl = sum(p.unrealized_pnl for p in self.positions.values())
        positions_value = sum(p.size * p.current_price for p in self.positions.values())
        self.total_value = self.cash + positions_value
