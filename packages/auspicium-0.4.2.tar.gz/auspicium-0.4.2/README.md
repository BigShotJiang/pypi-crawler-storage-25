# auspicium

Python SDK for the [Auspicium](https://auspicium.io) market data platform — crypto OHLCV, order books, trades, Polymarket prediction markets, and cross-market signals.

## Install

```bash
pip install auspicium
```

## Quick start

```python
import os
os.environ["AUSP_API_KEY"]     = "your-api-key"
os.environ["AUSP_GATEWAY_URL"] = "https://api.auspicium.io"

from auspicium import rest

# OHLCV candlestick data
df = rest.ohlcv("binance", "BTC-USDT", interval="5m", days=7)

# Order book snapshot
book = rest.orderbook("binance", "BTC-USDT", depth=20)

# Polymarket prediction markets
markets = rest.markets(status="active", base_asset="BTC")

# Cross-market signal (Binance x Polymarket)
cross = rest.cross_market(granularity="5m", base_asset="BTC", hours=48)
```

## WebSocket streaming

```python
from auspicium import stream

async with stream.connect() as ws:
    await ws.subscribe("ohlcv", source="binance", symbol="BTC-USDT")
    async for msg in ws:
        print(msg.channel, msg.payload)
```

## Get your API key

Sign up at [auspicium.io](https://auspicium.io) — free tier included.