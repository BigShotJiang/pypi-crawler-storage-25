import httpx
import asyncio
import logging
from typing import Optional
import time
import random
from .classes.users import User, VerifyingUser

logger = logging.getLogger("starryapi")


DEFAULT_BASE_URL = "https://api.starrybot.space"

class APIClient:
    def __init__(
        self,
        api_token: str,
        base_url: str = DEFAULT_BASE_URL,
        timeout: int = 10,
        max_retries: int = 5,
        rate_limit_per_sec: Optional[float] = None
    ):
        self.base_url = base_url.rstrip('/')
        self.api_token = api_token
        self.timeout = timeout
        self.max_retries = max_retries
        self.client: Optional[httpx.AsyncClient] = None
        self.rate_limit_per_sec = rate_limit_per_sec
        self._last_request = 0.0
        self._lock = asyncio.Lock()

    async def _get_client(self) -> httpx.AsyncClient:
        if self.client is None or self.client.is_closed:
            logger.debug("Creating new httpx.AsyncClient")
            self.client = httpx.AsyncClient(
                headers={"Authorization": f"Bearer {self.api_token}"},
                timeout=httpx.Timeout(self.timeout)
            )
        return self.client

    async def close(self):
        if self.client and not self.client.is_closed:
            logger.debug("Closing httpx client")
            await self.client.aclose()

    async def _rate_limit_wait(self):
        if self.rate_limit_per_sec:
            async with self._lock:
                now = asyncio.get_event_loop().time()
                wait = max(0, (1 / self.rate_limit_per_sec) - (now - self._last_request))
                if wait > 0:
                    await asyncio.sleep(wait)
                self._last_request = asyncio.get_event_loop().time()

    async def _request(self, method: str, path: str, **kwargs):
        url = f"{self.base_url}{path}"
        client = await self._get_client()
        retries = 0

        while True:
            await self._rate_limit_wait()  # respect global rate-limit
            try:
                response = await client.request(method, url, **kwargs)
            except (httpx.ConnectError, httpx.ReadTimeout, httpx.NetworkError) as e:
                retries += 1
                if retries > self.max_retries:
                    logger.error(
                        "Max retries exceeded for network error on %s %s", method, url
                    )
                    raise
                wait = min(2 ** retries + random.random(), 60)
                logger.warning("Network error: %s. Retrying after %.2f seconds (%d/%d)", e, wait, retries, self.max_retries)
                await asyncio.sleep(wait)
                continue

            if response.status_code == 429:
                retries += 1
                if retries > self.max_retries:
                    logger.error("Max retries exceeded for 429 on %s %s", method, url)
                    response.raise_for_status()
                retry_after = response.headers.get("Retry-After")
                wait = float(retry_after) if retry_after else min(2 ** retries + random.random(), 60)
                logger.warning("Rate limited (429). Retrying after %.2f seconds (%d/%d)", wait, retries, self.max_retries)
                await asyncio.sleep(wait)
                continue

            if response.status_code >= 400:
                response.raise_for_status()

            return response.json()

    # --------------------------
    # API Endpoints
    # --------------------------

    #async def list_api_keys(self, guild_id: int) -> list:
    #    logger.info("Getting API keys list for guild %s", guild_id)
    #    return await self._request("GET", f"/v1/{guild_id}/api-keys" )


    async def ping(self) -> float:
        """
        Ping the API and return latency in milliseconds.
        """
        logger.debug("Pinging API for latency...")
        start = time.perf_counter()
        await self._request("GET", "/v1/ping")
        latency_ms = (time.perf_counter() - start) * 1000  # convert to ms
        logger.debug("API latency: %s ms", latency_ms)
        return latency_ms


    async def get_user_by_discord_id(self, user_id: int) -> User | None:
        logger.debug("Getting Discord user info for user ID %s", user_id)
        try:
            data = await self._request("GET", f"/v1/users/discord/{user_id}")
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning("User with Discord ID %s not found", user_id)
                return None
            else:
                raise
        return User(self, data)

    async def get_user_by_luduvo_id(self, user_id: int) -> User | None:
        logger.debug("Getting Luduvo user info for user ID %s", user_id)
        try:
            data = await self._request("GET", f"/v1/users/luduvo/{user_id}")
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning("User with Luduvo ID %s not found", user_id)
                return None
            else:
                raise
        return User(self, data)

    async def create_verification_entry(
        self, discord_id: int, luduvo_id: int
    ) -> VerifyingUser:
        logger.debug("Creating verification entry for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
        try:
            data = await self._request(
                "POST",
                "/v1/users/verification",
                json={
                    "discord_id": discord_id,
                    "luduvo_id": luduvo_id,
                },
            )
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 409:
                logger.info("Verification entry already exists for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
                data = await self._request(
                    "GET",
                    f"/v1/users/verification/{discord_id}:{luduvo_id}"
                )
                return VerifyingUser(self, data)
            logger.error("Failed to create verification entry: %s", e)
            raise
        return VerifyingUser(self, data)

    async def check_verification(self, discord_id: int, luduvo_id: int) -> bool | None:
        logger.debug("Checking verification for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
        try:
            data = await self._request("POST", f"/v1/users/verification/{discord_id}:{luduvo_id}")
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.info("No verification entry found for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
                return None
            else:
                raise
        return data.get("verified", False)

    async def delete_verification_entry(self, discord_id: int, luduvo_id: int) -> bool:
        logger.debug("Deleting verification entry for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
        try:
            await self._request("DELETE", f"/v1/users/verification/{discord_id}:{luduvo_id}")
            logger.info("Verification entry deleted for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
            return True
        except httpx.HTTPStatusError as e:
            if e.response.status_code == 404:
                logger.warning("No verification entry to delete for Discord ID %s and Luduvo ID %s", discord_id, luduvo_id)
                return False
            else:
                logger.error("Failed to delete verification entry: %s", e)
                raise