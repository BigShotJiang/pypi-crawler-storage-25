from setuptools import setup, find_packages

setup(
    name='cm_textlab',
    version='1.0.1',
    author='Chen Mo',
    author_email='chenmoemail@126.com',
    description='计算概论C课程文本分析样本、常量、词频和词云工具',
    long_description=open('README.md', encoding='utf-8').read(),
    long_description_content_type='text/markdown',
    packages=find_packages(),
    install_requires=['jieba>=0.42', 'wordcloud>=1.9', 'matplotlib>=3.5'],
    python_requires='>=3.8',
    classifiers=[
        'Programming Language :: Python :: 3',
        'License :: OSI Approved :: MIT License',
        'Operating System :: OS Independent',
        'Natural Language :: Chinese (Simplified)',
        'Intended Audience :: Education',
    ],
)
