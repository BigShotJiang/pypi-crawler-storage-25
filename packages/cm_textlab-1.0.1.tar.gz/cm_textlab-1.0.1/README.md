# cm_textlab

文本分析样本、常量、词频和词云工具，适合文本处理专题使用。

```bash
pip install cm_textlab
```

```python
import cm_textlab

text = cm_textlab.load_sample_text('三国片段')
print(cm_textlab.CHINESE_PUNCTUATION)
print(cm_textlab.top_words(text, n=10))

freq = cm_textlab.word_frequency(text)
cm_textlab.save_wordfreq_csv(freq, '词频.csv')
cm_textlab.make_wordcloud(text, '词云.png')
```

这个库提供样本、停用词、分词和词云；学生仍然要自己写循环、字典统计、文件读取和结果解释。
