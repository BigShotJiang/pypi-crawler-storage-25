from datetime import datetime
class Colors:
  def __init__(self, **kwargs) -> None:
    self.colors: dict = {
      # Text colors (normal)
      'black'             : "\033[30m",
      'red'               : "\033[31m",
      'green'             : "\033[32m",
      'yellow'            : "\033[33m",
      'blue'              : "\033[34m",
      'magenta'           : "\033[35m",
      'cyan'              : "\033[36m",
      'white'             : "\033[37m",

      # Bright text colors
      'bright_black'      : "\033[90m",
      'bright_red'        : "\033[91m",
      'bright_green'      : "\033[92m",
      'bright_yellow'     : "\033[93m",
      'bright_blue'       : "\033[94m",
      'bright_magenta'    : "\033[95m",
      'bright_cyan'       : "\033[96m",
      'bright_white'      : "\033[97m",

      # Background colors (normal)
      'bg_black'          : "\033[40m",
      'bg_red'            : "\033[41m",
      'bg_green'          : "\033[42m",
      'bg_yellow'         : "\033[43m",
      'bg_blue'           : "\033[44m",
      'bg_magenta'        : "\033[45m",
      'bg_cyan'           : "\033[46m",
      'bg_white'          : "\033[47m",

      # Bright backgrounds
      'bg_bright_black'   : "\033[100m",
      'bg_bright_red'     : "\033[101m",
      'bg_bright_green'   : "\033[102m",
      'bg_bright_yellow'  : "\033[103m",
      'bg_bright_blue'    : "\033[104m",
      'bg_bright_magenta' : "\033[105m",
      'bg_bright_cyan'    : "\033[106m",
      'bg_bright_white'   : "\033[107m",

      # Styles
      'bold'              : "\033[1m",
      'italic'            : "\033[3m",
      'underline'         : "\033[4m",
      'double_underline'  : "\033[21m",
      'blink'             : "\033[5m",
      'reverse'           : "\033[7m",
      'hidden'            : "\033[8m",
      'strike'            : "\033[9m",

      # Reset
      'reset'             : "\033[0m",
      'normal'            : "\033[2m"
    }

    self.icons = {
      'void':              '',
      'info':             f'{chr(10069)} ',
      'error':            f'{chr(10060)} ',
      'debug':            f'{chr(10067)} ',
      'success':          f'{chr(9989)} ',
      'warning':          f'{chr(10071)} ',
      'highlight':        f'{chr(10062)} ',
    }

  # Métodos utilitários
  def color(self, name: str) -> str:
    return self.colors.get(name, self.colors['reset'])
  
  def icon(self, name: str) -> str:
    return self.icons.get(name, '')

  def reset(self) -> str:
    return self.colors['reset']
  
  def log(self, **kwargs) -> None:
    with open(kwargs['file'], 'a') as f:
      f.write(kwargs['msg'])
    return None

 # Sucesso
  def success(self, **kwargs) -> None:
    # msg: str 
    # style: str
    # icon: bool
    # icon_blink: bool
    # time_clock: bool
    # log: str
    # color: str
    _style: str = kwargs['style'] if kwargs['style'] else 'normal'
    _clock: str = f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] ' if kwargs['time_clock'] else ''
    _name_icon: str = 'void' if not kwargs['icon'] else 'success'
    __blink_icon: str = 'blink' if kwargs['icon_blink'] else 'normal'
    _color: str = self.colors[kwargs.get('color')] if kwargs.get('color') else 'bright_green'
    print(f"{_clock}{self.colors[__blink_icon]}{self.icons[_name_icon]}{self.colors[_color]}{self.colors[_style]}{kwargs['msg']}{self.reset()}")
    return None

  # Erro
  def error(self, **kwargs) -> None:
    # msg: str 
    # style: str
    # icon: bool
    # icon_blink: bool
    # time_clock: bool
    _style: str = kwargs['style'] if kwargs['style'] else 'normal'
    _clock: str = f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] ' if kwargs['time_clock'] else ''
    _name_icon: str = 'void' if not kwargs['icon'] else 'error'
    _blink_icon: str = 'blink' if kwargs['icon_blink'] else 'normal'
    _color: str = self.colors[kwargs.get('color')] if kwargs.get('color') else 'bright_red'
    print(f"{_clock}{self.colors[_blink_icon]}{self.icons[_name_icon]}{self.colors[_color]}{self.colors[_style]}{kwargs['msg']}{self.reset()}")
    return None

  # Aviso
  def warning(self, **kwargs) -> None:
    # msg: str 
    # style: str
    # icon: bool
    # icon_blink: bool
    # time_clock: bool
    _style: str = kwargs['style'] if kwargs['style'] else 'normal'
    _clock: str = f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] ' if kwargs['time_clock'] else ''
    _name_icon: str = 'void' if not kwargs['icon'] else 'warning'
    _blink_icon: str = 'blink' if kwargs['icon_blink'] else 'normal'
    _color: str = self.colors[kwargs.get('color')] if kwargs.get('color') else 'bright_yellow'
    print(f"{_clock}{self.colors[_blink_icon]}{self.icons[_name_icon]}{self.colors[_color]}{self.colors[_style]} {kwargs['msg']} {self.reset()}")
    return None

  # Informação
  def info(self, **kwargs) -> None:
    # msg: str 
    # style: str
    # icon: bool
    # icon_blink: bool
    # time_clock: bool
    _style = kwargs['style'] if kwargs['style'] else 'normal'
    _clock = f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] ' if kwargs['time_clock'] else ''
    _name_icon = 'void' if not kwargs['icon'] else 'info'
    _blink_icon = 'blink' if kwargs['icon_blink'] else 'normal'
    _color: str = self.colors[kwargs.get('color')] if kwargs.get('color') else 'bright_blue'
    print(f"{_clock}{self.colors[_blink_icon]}{self.icons[_name_icon]}{self.colors[_color]}{self.colors[_style]}{kwargs['msg']}{self.reset()}")
    return None

  # Debug
  def debug(self, **kwargs) -> None:
    # msg: str
    # style: str
    # icon: bool
    # icon_blink: bool
    # time_clock: bool    
    _style: str = kwargs.get('style', 'normal')
    _clock: str = f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] ' if kwargs.get('time_clock') else ''
    _name_icon: str = 'void' if not kwargs.get('icon') else 'debug'
    _blink_icon: str = 'blink' if kwargs.get('icon_blink') else 'normal'
    _color: str = self.colors[kwargs.get('color')] if kwargs.get('color') else 'reverse'
    print(f"{_clock}{self.colors[_blink_icon]}{self.icons[_name_icon]}{self.colors[_color]}{self.colors[_style]}{kwargs.get('msg')}{self.reset()}")
    return None

  # Importante / Destaque
  def highlight(self, **kwargs) -> None:
    _style: str = kwargs.get('style','normal')
    _clock: str = f'[{datetime.now().strftime("%Y-%m-%d %H:%M:%S")}] ' if kwargs.get('time_clock') else ''
    _name_icon: str = 'void' if not kwargs.get('icon') else 'highlight'
    _blink_icon: str = 'blink' if kwargs['icon_blink'] else 'normal'
    _color: str = self.colors[kwargs.get('color')] if kwargs.get('color') else 'bright_white'
    print(f"{_clock}{self.colors[_blink_icon]}{self.icons[_name_icon]}{self.colors[_color]}{self.colors[_style]}{kwargs['msg']}{self.reset()}")
    return None