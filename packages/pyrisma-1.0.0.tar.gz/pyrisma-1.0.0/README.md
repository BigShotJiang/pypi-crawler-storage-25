# 💬 Pyrisma

Uma biblioteca Python para exibir mensagens coloridas e estilizadas no terminal, com ícones e formatação moderna.  
Ideal para quem quer logs mais visuais, legíveis e com um toque de personalidade.

---

## 🚀 Instalação

Você pode instalar o Pyrisma facilmente via pip:

```bash
pip install pyrisma
```

## 🧠 Uso básico

A biblioteca `Pyrisma` utiliza argumentos nomeados (`kwargs`) para garantir flexibilidade e clareza na hora de formatar suas mensagens.

```python
from pyrisma import Colors

# Inicializando a classe
terminal = Colors()

# Exemplos de uso
terminal.info(msg="Sistema iniciado com sucesso!")
terminal.warning(msg="Atenção: configuração ausente.", icon=True)
terminal.error(msg="Erro crítico detectado!", style="bold", time_clock=True)
terminal.success(msg="Processo concluído com êxito.", icon=True, icon_blink=True)
```

### Saída esperada (com cores e formatação, dependendo do terminal):

```bash
ℹ️  Sistema iniciado com sucesso!
⚠️  Atenção: configuração ausente.
[2026-04-10 15:30:00] ❌ Erro crítico detectado!
✅ Processo concluído com êxito.
```

## ⚙️ Parâmetros Disponíveis

Todos os métodos de log (`success`, `error`, `warning`, `info`, `debug`, `highlight`) aceitam os seguintes argumentos:

| Parâmetro | Tipo | Descrição | Padrão |
| :--- | :---: | :--- | :--- |
| `msg` | `str` | **(Obrigatório)** A mensagem que será exibida no terminal. | - |
| `style` | `str` | Estilo da fonte (ex: `bold`, `italic`, `underline`). | `'normal'` |
| `icon` | `bool` | Define se o ícone correspondente ao método será exibido. | `False` |
| `icon_blink` | `bool`| Define se o ícone deve piscar (suporte depende do terminal).| `False` |
| `time_clock` | `bool`| Adiciona um timestamp `[YYYY-MM-DD HH:MM:SS]` antes da mensagem. | `False` |
| `color` | `str` | Substitui a cor padrão do método por uma cor customizada. | Padrão do método |

### Exemplo Avançado

```python
terminal.highlight(
  msg="Iniciando processamento de dados...",
  style="bold",
  color="bg_bright_blue",
  time_clock=True,
  icon=True
)
```

## 🎨 Cores e Estilos Suportados

Você pode usar as seguintes chaves no parâmetro `color` e `style`:

* **Cores de Texto:** `black`, `red`, `green`, `yellow`, `blue`, `magenta`, `cyan`, `white` (Adicione o prefixo `bright_` para versões mais claras, ex: `bright_red`).
* **Cores de Fundo:** Prefixo `bg_` (ex: `bg_blue`, `bg_bright_green`).
* **Estilos:** `bold`, `italic`, `underline`, `double_underline`, `blink`, `reverse`, `hidden`, `strike`, `normal`.

## 🛠️ Funcionalidades

* Mensagens com cores e ícones contextuais.
* Compatível com Linux e macOS.
* Zero dependências externas pesadas (usa apenas bibliotecas nativas do Python).

## 📄 Licença

Distribuído sob a licença **MIT**. Veja o arquivo `LICENSE` para mais informações.

---

## 👤 Autor

**Marley** *Desenvolvedor de Software* [![LinkedIn](https://img.shields.io/badge/LinkedIn-0077B5?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/marley-ben%C3%ADcio-b81a3424/) 📧 **Contato:** marleysbenicio@gmail.com
