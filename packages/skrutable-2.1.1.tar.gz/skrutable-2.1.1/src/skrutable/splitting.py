import re
import requests
from time import sleep
from typing import List, Tuple

from skrutable.config import load_config_dict_from_json_file
from skrutable.transliteration import Transliterator

config = load_config_dict_from_json_file()
PRESERVE_PUNCTUATION_DEFAULT = config["preserve_punctuation_default"]
PRESERVE_COMPOUND_HYPHENS_DEFAULT = config["preserve_compound_hyphens_default"]
SPLITTER_SERVER_URL = 'https://2018emnlp-sanskrit-splitter-server.dharma.cl/api/split/'

HEADERS = {'Content-Type': 'application/json'}
RETRY_DELAY_SEC = 5

class Splitter(object):

    def __init__(self):

        shared_items = r'।॥\|/\\.,—;\?!\[(<\t\r\n"'
        self.punctuation_regex = fr' *[{shared_items}][{shared_items}\d\])> ]*'
        self.max_char_limit = {
            ("splitter_2018", "don't preserve hyphens"): 128,
            ("dharmamitra_2024_sept", "don't preserve hyphens"): 350,
            ("dharmamitra_2024_sept", "preserve hyphens"): 150,
        }
        self.char_limit_split_regex_options = [r'(?:(?:[kgtdnpbmṃḥ])) ', r'(?:(?:e[nṇ]a|asya|[ie]va|api)) ', r' ', r'a']
        self.center_split_range = 0.8 # percentage distance measured from middle

    def _get_sentences_and_punctuation(self, text: str) -> Tuple[List[str], List[str]]:
        """
        Extract and return lists of sentences and punctuation from text.
        Also return list of markers for proper interleaving on restoration.
        """
        sentences = list(filter(None, re.split(self.punctuation_regex, text, flags=re.MULTILINE)))
        punctuation = re.findall(self.punctuation_regex, text)
        tokens = re.split(f'({self.punctuation_regex})', text)
        tokens = [token for token in tokens if token]
        markers = ['punctuation' if re.fullmatch(self.punctuation_regex, token) else 'content' for token in tokens]
        return sentences, punctuation, markers

    def _find_midpoint(self, text: str, split_regex: str) -> int:
        """
        Determine position of whitespace of centermost legal split of text based on split_regex.
        Return integer index.
        """
        space_indices = [m.end()-1 for m in re.finditer(split_regex, text)]
        Ds_from_mid = [abs(i - len(text)/2) for i in space_indices] # Distances
        try:
            most_mid_index = space_indices[Ds_from_mid.index(min(Ds_from_mid))]
            return most_mid_index
        except ValueError:
            return 0

    def _split_smart_half(self, text: str, split_regex_options: List[str], max_len: int) -> List[str]:
        """
        Recursively split text (string) according to split_regex_options
            (first go for m/ṃ or t/d, otherwise any space)
        until all resulting substrings conform to max_len.
        Return list of resulting substrings.
        """
        # remove initial and final spaces
        text = re.sub(u"(^ *| *$)",'', text)
        if len(text) <= max_len:
            return [text]
        else:
            for split_regex in split_regex_options:
                midpoint = self._find_midpoint(text, split_regex)
                if (
                    midpoint > (1.0 - (1.0 - self.center_split_range) / 2) * len(text)
                    or
                    midpoint < ((1.0 - self.center_split_range) / 2) * len(text)
                ): continue
                else: break

            part_a = self._split_smart_half( text[ : midpoint + 1] , split_regex_options, max_len)
            part_b = self._split_smart_half( text[midpoint + 1 : ] , split_regex_options, max_len)
            return part_a + part_b

    def _enforce_char_limit(self, text_lines: List[str], max_char_limit: int=128) -> Tuple[List[str], List[int]]:
        sentence_counts = []
        new_text_lines = []
        for i, line in enumerate(text_lines):
            if len(line) <= max_char_limit:
                new_text_lines.append(line)
                sentence_counts.append(1)
            else:
                new_text_lines.extend(
                    parts := self._split_smart_half(
                        line,
                        self.char_limit_split_regex_options,
                        max_char_limit
                    )
                )
                sentence_counts.append(len(parts))
        return new_text_lines, sentence_counts

    def _parse_dharmamitra_simple_result(self, response_json) -> List[str]:
        """Parse response from /api-tagging/tagging/ (flat underscore-delimited strings)."""
        sentence_results = []
        for result_str in response_json["results"]:
            new_sentence = result_str.replace('_', ' ').strip()
            sentence_results.append(new_sentence)
        return sentence_results

    def _parse_dharmamitra_parsed_result(self, response_json) -> List[str]:
        """Parse response from /api-tagging/tagging-parsed/ (structured grammatical analysis).
        Compound parts have trailing hyphens in their unsandhied field (e.g., 'dharma-')."""
        sentence_results = []
        for sentence_obj in response_json:
            new_sentence = ' '.join(
                w['unsandhied'] for w in sentence_obj['grammatical_analysis']
            )
            # clean up: "dharma- kṣetre" → "dharma-kṣetre"
            new_sentence = new_sentence.replace('- ', '-')
            sentence_results.append(new_sentence)
        return sentence_results

    def _get_dharmamitra_split(
            self,
            text_input: str,
            preserve_compound_hyphens: bool=True,
            batch_size: int=2000,
            retries: int=1,
        ) -> List[str]:
        """
        Two endpoints on the Dharmamitra tagging API:
        - /api-tagging/tagging/           simple, no compound distinction
        - /api-tagging/tagging-parsed/    rich, compounds marked with hyphens
        """
        if preserve_compound_hyphens:
            url = 'https://dharmamitra.org/api-tagging/tagging-parsed/'
        else:
            url = 'https://dharmamitra.org/api-tagging/tagging/'

        sentences = text_input.split('\n')
        results = []
        for i in range(0, len(sentences), batch_size):
            sentence_batch = sentences[i:i + batch_size]
            if preserve_compound_hyphens:
                data = {
                    "texts": sentence_batch,
                    "mode": "unsandhied-lemma-morphosyntax",
                    "human_readable_tags": False,
                    "grammar_type": "western",
                }
            else:
                data = {
                    "texts": sentence_batch,
                }
            for j in range(1+retries):
                response = requests.post(url, headers=HEADERS, json=data)
                if response.status_code == 200:
                    if preserve_compound_hyphens:
                        batch_result = self._parse_dharmamitra_parsed_result(response.json())
                    else:
                        batch_result = self._parse_dharmamitra_simple_result(response.json())
                    results.extend(batch_result)
                    break
                elif j < retries:
                    print(f"retrying batch in {RETRY_DELAY_SEC} sec")
                    sleep(RETRY_DELAY_SEC)
                    continue
                else:
                    print(f"batch failed:\n\n{sentence_batch}")
                    response.raise_for_status()

        return results

    def _post_string_2018(
            self,
            input_text: str,
            url: str=SPLITTER_SERVER_URL,
            batch_size: int=10000,
            retries: int=1,
        ):

        sentences = input_text.split('\n')
        results = []
        for i in range(0, len(sentences), batch_size):
            sentence_batch = sentences[i:i + batch_size]
            batch_text_input = '\n'.join(sentence_batch)
            data = {'input_text': batch_text_input}
            for i in range(1+retries):
                response = requests.post(url, headers=HEADERS, json=data)
                if response.status_code == 200:
                    batch_result = response.json()["output_text"]
                    results.append(batch_result)
                    break
                elif i < retries:
                    print(f"retrying batch in {RETRY_DELAY_SEC} sec")
                    sleep(RETRY_DELAY_SEC)
                    continue
                else:
                    print(f"batch failed:\n\n{batch_text_input}")
                    response.raise_for_status()

        return '\n'.join(results)

    def _clean_up_2018(self, split_sentences_str: str, split_appearance: str=' ') -> List[str]:
        for (r_1, r_2) in [
            ('-\n', '\n'), # remove line-final hyphens
            ('-', split_appearance), # modify appearance of splits ('-', ' ', '- ', etc.)
            ('=', ''), # QUESTION: what does this char in result even mean?
            ('=', ''), # repeat for good measure
            ('(\A\s*)|(\s*\Z)', '') # string-initial and -final whitespace
        ]:
            split_sentences_str = re.sub(r_1, r_2, split_sentences_str)
        return split_sentences_str.split('\n')

    def _restore_sentences(self, sentences: List[str], sentence_counts: List[int]) -> List[str]:
        restored_sentences = []
        i = 0
        for count in sentence_counts:
            restored_sentences.append(' '.join(sentences[i:i + count]))
            i += count
        return restored_sentences

    def _restore_punctuation(self, sentences: List[str], punctuation: List[str], markers: List[str]) -> str:
        new_sentences = []
        for marker in markers:
            if marker == 'content':
                new_sentences.append(sentences.pop(0))
            elif marker == 'punctuation':
                new_sentences.append(punctuation.pop(0))
        return ''.join(new_sentences)

    def split(
            self,
            text: str,
            from_scheme: str = None,
            to_scheme: str = None,
            splitter_model: str='dharmamitra_2024_sept',
            preserve_compound_hyphens: bool = PRESERVE_COMPOUND_HYPHENS_DEFAULT,
            preserve_punctuation: bool=PRESERVE_PUNCTUATION_DEFAULT,
    ) -> str:
        """
        Splits sandhi and compounds of multi-line Sanskrit string,
        passing maximum of max_char_limit characters to Splitter at a time,
        and preserving original newlines and punctuation.

        from_scheme: input transliteration scheme (None = auto-detect).
        to_scheme:   output transliteration scheme (None = IAST, the hub scheme).
        Processing always happens in IAST; transliteration wraps the call if needed.
        """

        # transliterate input to IAST (auto-detects if from_scheme is None)
        T = Transliterator()
        text = T.transliterate(text, from_scheme=from_scheme, to_scheme='IAST')

        # save original punctuation
        sentences: List[str]
        saved_punctuation: List[str]
        sentences, saved_punctuation, markers = self._get_sentences_and_punctuation(text)
        if len(saved_punctuation) - len(sentences) > 1:
            raise ValueError("Punctuation and sentence count mismatch")

        # split sentences that are too long for Splitter
        safe_sentences: List[str]
        sent_counts: List[int]
        safe_sentences, sent_counts = self._enforce_char_limit(
            sentences,
            self.max_char_limit.get(
                (splitter_model, "preserve hyphens" if preserve_compound_hyphens else "don't preserve hyphens"), 128
            )
        )

        sentences_str: str = '\n'.join(safe_sentences)

        split_sentences: List[str]

        if splitter_model == 'dharmamitra_2024_sept':

            split_sentences = self._get_dharmamitra_split(
                sentences_str,
                preserve_compound_hyphens=preserve_compound_hyphens
            )

        elif splitter_model == 'splitter_2018':

            split_sentences_str = self._post_string_2018(sentences_str)
            split_sentences = self._clean_up_2018(split_sentences_str)

        else:
            raise ValueError(f"Invalid splitter model {splitter_model}")

        # restore sentences split to enforce character limit
        restored_sentences: List[str] = self._restore_sentences(split_sentences, sent_counts)

        # restore punctuation
        if preserve_punctuation and saved_punctuation != []:
            final_results = self._restore_punctuation(restored_sentences, saved_punctuation, markers)
        else:
            final_results = '\n'.join(restored_sentences).replace('_', ' ')

        # transliterate output from IAST if requested
        if to_scheme is not None and to_scheme.upper() != 'IAST':
            final_results = T.transliterate(final_results, from_scheme='IAST', to_scheme=to_scheme)

        return final_results
