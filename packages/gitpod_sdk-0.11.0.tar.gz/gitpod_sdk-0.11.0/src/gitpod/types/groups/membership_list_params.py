# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["MembershipListParams", "Filter", "Pagination"]


class MembershipListParams(TypedDict, total=False):
    token: str

    page_size: Annotated[int, PropertyInfo(alias="pageSize")]

    filter: Filter
    """filter contains options for filtering the list of memberships."""

    group_id: Annotated[str, PropertyInfo(alias="groupId")]

    pagination: Pagination
    """pagination contains the pagination options for listing memberships"""


class Filter(TypedDict, total=False):
    """filter contains options for filtering the list of memberships."""

    search: str
    """
    search performs case-insensitive search across member name, email, ID, and
    service account name and description
    """


class Pagination(TypedDict, total=False):
    """pagination contains the pagination options for listing memberships"""

    token: str
    """
    Token for the next set of results that was returned as next_token of a
    PaginationResponse
    """

    page_size: Annotated[int, PropertyInfo(alias="pageSize")]
    """Page size is the maximum number of results to retrieve per page. Defaults to 25.

    Maximum 100.
    """
