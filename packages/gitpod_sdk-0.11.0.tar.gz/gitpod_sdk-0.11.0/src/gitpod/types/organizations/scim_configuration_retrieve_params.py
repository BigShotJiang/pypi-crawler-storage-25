# File generated from our OpenAPI spec by Stainless. See CONTRIBUTING.md for details.

from __future__ import annotations

from typing_extensions import Required, Annotated, TypedDict

from ..._utils import PropertyInfo

__all__ = ["ScimConfigurationRetrieveParams"]


class ScimConfigurationRetrieveParams(TypedDict, total=False):
    scim_configuration_id: Required[Annotated[str, PropertyInfo(alias="scimConfigurationId")]]
    """scim_configuration_id is the ID of the SCIM configuration to get"""
