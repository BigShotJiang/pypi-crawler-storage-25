__version__ = "0.1.0"
from .main import ScribitApp, main

__all__ = ["ScribitApp", "main"]
