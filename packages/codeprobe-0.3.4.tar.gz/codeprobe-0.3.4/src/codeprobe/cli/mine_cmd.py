"""codeprobe mine — extract eval tasks from repo history."""

from __future__ import annotations

import json
import re
import shutil
import subprocess
import sys
import tempfile
from pathlib import Path

import click

# ---------------------------------------------------------------------------
# URL → local clone
# ---------------------------------------------------------------------------

_GIT_URL_PATTERN = re.compile(
    r"^(?:https?://|git@)"  # https:// or git@
    r"|^[\w.-]+/[\w.-]+$"  # owner/repo shorthand
)


def _is_git_url(path_or_url: str) -> bool:
    """Return True if the argument looks like a git URL or owner/repo shorthand."""
    return bool(_GIT_URL_PATTERN.match(path_or_url))


def _normalize_url(url: str) -> str:
    """Expand owner/repo shorthand to a full GitHub URL."""
    if "/" in url and not url.startswith(("https://", "http://", "git@")):
        return f"https://github.com/{url}.git"
    return url


def _clone_repo(url: str) -> Path:
    """Shallow-clone a repo into a temp directory. Returns the clone path.

    Uses ``--filter=blob:none`` for a fast treeless clone. The temp directory
    persists until the process exits (the user sees the path in output).
    """
    url = _normalize_url(url)
    # Derive a directory name from the URL
    repo_name = url.rstrip("/").rstrip(".git").rsplit("/", 1)[-1]
    clone_dir = Path(tempfile.mkdtemp(prefix=f"codeprobe-{repo_name}-"))

    click.echo(f"Cloning {url} → {clone_dir} ...")
    try:
        subprocess.run(
            ["git", "clone", "--filter=blob:none", url, str(clone_dir)],
            check=True,
            capture_output=True,
            text=True,
            timeout=120,
        )
    except subprocess.CalledProcessError as exc:
        click.echo(f"Clone failed: {(exc.stderr or '').strip()}")
        raise SystemExit(1) from exc
    except subprocess.TimeoutExpired:
        click.echo("Clone timed out after 120s.")
        raise SystemExit(1)

    click.echo(f"Cloned to {clone_dir}")
    return clone_dir


# ---------------------------------------------------------------------------
# Interactive workflow (mirrors mine-tasks skill phases 0–6)
# ---------------------------------------------------------------------------

_EVAL_GOALS = {
    "1": ("Code quality comparison", 2, "mixed", "sdlc_code_change"),
    "2": ("Codebase navigation", 0, "mixed", "architecture_comprehension"),
    "3": ("MCP / tool benefit", 6, "hard", "mcp_tool_usage"),
    "4": ("General benchmarking", 0, "balanced", "mixed"),
}

# Map --goal flag values to _EVAL_GOALS keys
_GOAL_FLAG_MAP: dict[str, str] = {
    "quality": "1",
    "navigation": "2",
    "mcp": "3",
    "general": "4",
}

_COUNT_PRESETS = {
    "1": ("Quick look (3-5)", 5),
    "2": ("Standard (5-10)", 8),
    "3": ("Thorough (10-20)", 15),
}

_SOURCE_OPTIONS = {
    "1": ("Auto-detect", "auto"),
    "2": ("GitHub", "github"),
    "3": ("GitLab", "gitlab"),
    "4": ("Bitbucket", "bitbucket"),
    "5": ("Azure DevOps", "azure"),
    "6": ("Gitea/Forgejo", "gitea"),
    "7": ("Local only", "local"),
}


def _is_interactive() -> bool:
    """Return True if stdin is a TTY (interactive terminal)."""
    return sys.stdin.isatty()


def _ask_eval_goal() -> tuple[str, int, str, str]:
    """Phase 0: Ask what the user is trying to learn.

    Returns ``(goal_name, min_files, bias, task_type)``.
    """
    click.echo()
    click.echo("What are you trying to learn?")
    click.echo(
        "  [1] Code quality comparison — SDLC tasks to compare code change quality"
    )
    click.echo(
        "  [2] Codebase navigation — comprehension tasks for architecture understanding"
    )
    click.echo(
        "  [3] MCP / tool benefit — harder tasks requiring cross-file navigation"
    )
    click.echo("  [4] General benchmarking — balanced mix")
    click.echo()

    choice = click.prompt("Select goal", default="4", show_default=True)
    goal_name, min_files, bias, task_type = _EVAL_GOALS.get(choice, _EVAL_GOALS["4"])
    click.echo(f"  → {goal_name}")
    return goal_name, min_files, bias, task_type


def _ask_task_count() -> int:
    """Phase 1: Ask how many tasks to mine."""
    click.echo()
    click.echo("How many tasks?")
    click.echo("  [1] Quick look (5) — fast results, good for first experiment")
    click.echo("  [2] Standard (8) — good coverage, enough to see patterns")
    click.echo("  [3] Thorough (15) — statistical confidence for real decisions")
    click.echo()

    choice = click.prompt("Select count", default="2", show_default=True)
    _, count = _COUNT_PRESETS.get(choice, _COUNT_PRESETS["2"])
    return count


def _ask_source() -> str:
    """Phase 1: Ask which git host."""
    click.echo()
    click.echo("Git host?")
    click.echo("  [1] Auto-detect")
    click.echo("  [2] GitHub")
    click.echo("  [3] GitLab")
    click.echo("  [4] Bitbucket")
    click.echo("  [5] Azure DevOps")
    click.echo("  [6] Gitea/Forgejo")
    click.echo("  [7] Local only")
    click.echo()

    choice = click.prompt("Select host", default="1", show_default=True)
    _, source = _SOURCE_OPTIONS.get(choice, _SOURCE_OPTIONS["1"])
    return source


def _show_preflight(
    repo_path: Path,
    goal_name: str,
    count: int,
    source: str,
    min_files: int,
    bias: str,
    subsystems: tuple[str, ...],
) -> bool:
    """Phase 2: Show pre-flight summary and confirm."""
    click.echo()
    click.echo("=" * 50)
    click.echo("Mining plan")
    click.echo("=" * 50)
    click.echo(f"  Goal:       {goal_name}")
    click.echo(f"  Repo:       {repo_path}")
    click.echo(f"  Tasks:      {count}")
    click.echo(f"  Source:      {source}")
    click.echo(f"  Min files:   {min_files} (biasing toward {bias} tasks)")
    if subsystems:
        click.echo(f"  Subsystems: {', '.join(subsystems)}")
    click.echo("=" * 50)
    click.echo()

    return click.confirm("Proceed?", default=True)


def _quality_review(
    tasks: list["Task"],
    goal_name: str,
    bias: str,
) -> list[str]:
    """Phase 4: Review mined tasks for quality issues.

    Returns a list of warning strings.
    """
    from collections import Counter

    warnings: list[str] = []

    if not tasks:
        return warnings

    # Difficulty distribution
    difficulties = Counter(t.metadata.difficulty for t in tasks)
    total = len(tasks)

    if bias == "hard":
        easy_pct = difficulties.get("easy", 0) / total
        if easy_pct > 0.5:
            warnings.append(
                f"Difficulty mismatch: {easy_pct:.0%} easy tasks, but goal needs "
                "harder tasks. Try re-mining with higher --min-files."
            )
    elif bias == "mixed":
        if len(difficulties) == 1:
            only = list(difficulties.keys())[0]
            warnings.append(
                f"No difficulty variance: all tasks are '{only}'. "
                "Need a mix to differentiate models/prompts."
            )

    # Instruction quality — check for generic/thin instructions
    thin_count = 0
    for t in tasks:
        desc = t.metadata.description
        # Check if description is mostly template fragments
        if len(desc) < 50 or "reproduce changes from merge" in desc.lower():
            thin_count += 1
    if thin_count > 0:
        warnings.append(
            f"{thin_count}/{total} tasks have thin instructions. "
            "Consider running with --enrich to add problem context via LLM."
        )

    # Test quality — check for generic stubs
    stub_count = sum(1 for t in tasks if t.verification.command == "bash tests/test.sh")
    if stub_count > 0:
        warnings.append(
            f"{stub_count}/{total} tasks use generic test stubs instead of "
            "targeted test commands."
        )

    # Task diversity — check if clustered in one area
    if total >= 3:
        dirs = []
        for t in tasks:
            # Use the first test file path as a proxy for location
            cmd = t.verification.command
            parts = cmd.split()
            if len(parts) >= 2:
                first_path = parts[1] if not parts[1].startswith("-") else ""
                top_dir = first_path.split("/")[0] if "/" in first_path else ""
                if top_dir:
                    dirs.append(top_dir)
        if dirs:
            top_dir_count = Counter(dirs).most_common(1)
            if top_dir_count and top_dir_count[0][1] / total > 0.7:
                warnings.append(
                    f"Low diversity: {top_dir_count[0][1]}/{total} tasks are in "
                    f"'{top_dir_count[0][0]}/'. Consider --subsystem to spread coverage."
                )

    return warnings


def _show_results_table(tasks: list["Task"]) -> None:
    """Phase 5: Display mined tasks in a table."""
    click.echo()
    click.echo(f"Mined {len(tasks)} tasks:")
    click.echo()

    # Header
    click.echo(
        f"  {'#':>2}  {'Task ID':<14} {'Difficulty':<12} "
        f"{'Language':<12} {'Quality':>7}"
    )
    click.echo("  " + "-" * 52)

    for i, t in enumerate(tasks, 1):
        click.echo(
            f"  {i:>2}  {t.id:<14} {t.metadata.difficulty:<12} "
            f"{t.metadata.language or 'unknown':<12} "
            f"{t.metadata.quality_score:>6.0%}"
        )
    click.echo()


def _show_next_steps(repo_path: Path, min_files: int) -> None:
    """Phase 6: Show next steps."""
    click.echo("Next steps:")
    click.echo()
    click.echo("  1. Review and enrich task instructions (recommended):")
    click.echo("     codeprobe mine {path} --enrich".format(path=repo_path))
    click.echo()
    click.echo("  2. Run the eval:")
    click.echo("     codeprobe run {path} --agent claude".format(path=repo_path))
    click.echo()
    click.echo("  3. Try a different model:")
    click.echo(
        "     codeprobe run {path} --agent claude --model claude-sonnet-4-6".format(
            path=repo_path,
        )
    )
    click.echo()
    click.echo("  4. Set a cost budget:")
    click.echo(
        "     codeprobe run {path} --agent claude --max-cost-usd 5.00".format(
            path=repo_path,
        )
    )
    click.echo()
    if min_files > 0:
        click.echo("  5. Mine more tasks for better confidence:")
        click.echo(
            "     codeprobe mine {path} --count 15 --min-files {mf}".format(
                path=repo_path,
                mf=min_files,
            )
        )
        click.echo()


# ---------------------------------------------------------------------------
# Subsystem discovery (unchanged)
# ---------------------------------------------------------------------------


def _discover_and_select(
    repo_path: Path,
    source_hint: str,
) -> tuple[str, ...]:
    """List subsystems from merge history and let the user pick.

    Returns selected subsystem prefixes. Falls back to top 3 in
    non-interactive environments.
    """
    from codeprobe.mining import extract_subsystems
    from codeprobe.mining.extractor import list_merged_prs
    from codeprobe.mining.sources import RepoSource, detect_source

    if source_hint != "auto":
        source = RepoSource(
            host=source_hint, owner="", repo=repo_path.name, remote_url=""
        )
    else:
        source = detect_source(repo_path)

    prs = list_merged_prs(source, repo_path, limit=40)
    if not prs:
        click.echo("No merge commits found — cannot discover subsystems.")
        return ()

    subsystem_counts = extract_subsystems(prs, repo_path)
    if not subsystem_counts:
        click.echo("No subsystems detected in merge history.")
        return ()

    # Display the subsystem table
    entries = list(subsystem_counts.items())[:20]
    click.echo()
    click.echo("Subsystems (by merge activity):")
    for i, (prefix, count) in enumerate(entries, 1):
        click.echo(f"  [{i:2d}] {prefix:40s} ({count} merges)")
    click.echo()

    # Non-interactive fallback: pick top 3
    if not sys.stdin.isatty():
        top = tuple(p for p, _ in entries[:3])
        click.echo(f"Non-interactive: auto-selected {', '.join(top)}")
        return top

    raw = click.prompt(
        "Select subsystems (comma-separated numbers, or Enter for top 3)",
        default="",
        show_default=False,
    )

    if not raw.strip():
        return tuple(p for p, _ in entries[:3])

    selected: list[str] = []
    for token in raw.split(","):
        token = token.strip()
        try:
            idx = int(token)
            if 1 <= idx <= len(entries):
                selected.append(entries[idx - 1][0])
            else:
                click.echo(f"  Skipping out-of-range index: {idx}")
        except ValueError:
            # Treat as a literal prefix
            if not token.endswith("/"):
                token += "/"
            selected.append(token)

    if not selected:
        return tuple(p for p, _ in entries[:3])

    return tuple(selected)


# ---------------------------------------------------------------------------
# Shared helpers
# ---------------------------------------------------------------------------


def _clear_tasks_dir(repo_path: Path) -> Path:
    """Clear stale tasks and return the tasks directory path."""
    tasks_dir = repo_path / ".codeprobe" / "tasks"
    if tasks_dir.exists():
        shutil.rmtree(tasks_dir)
    return tasks_dir


def _record_task_ids_in_experiment(repo_path: Path, task_ids: list[str]) -> None:
    """Update the experiment's task_ids so ``run`` only executes these tasks.

    If exactly one experiment exists under ``<repo>/.codeprobe/``, its
    ``experiment.json`` is updated with the new task ID list.  When zero
    or multiple experiments exist, this is a no-op (the user must scope
    manually via ``--config``).
    """
    from codeprobe.core.experiment import load_experiment, save_experiment
    from codeprobe.models.experiment import Experiment

    codeprobe_dir = repo_path / ".codeprobe"
    if not codeprobe_dir.is_dir():
        return

    candidates = sorted(
        d
        for d in codeprobe_dir.iterdir()
        if d.is_dir() and (d / "experiment.json").is_file()
    )
    if len(candidates) != 1:
        return

    exp_dir = candidates[0]
    experiment = load_experiment(exp_dir)
    updated = Experiment(
        name=experiment.name,
        description=experiment.description,
        configs=experiment.configs,
        tasks_dir=experiment.tasks_dir,
        task_ids=tuple(sorted(task_ids)),
    )
    save_experiment(exp_dir, updated)


def _resolve_repo_path(path: str) -> Path:
    """Resolve a path or URL to a local repo directory."""
    if _is_git_url(path):
        return _clone_repo(path)
    repo_path = Path(path).resolve()
    if not repo_path.exists():
        click.echo(f"Path does not exist: {repo_path}")
        raise SystemExit(1)
    return repo_path


def _interactive_config(
    count: int,
    source: str,
    min_files: int,
    subsystems: tuple[str, ...],
    discover_subsystems: bool,
    repo_path: Path,
) -> tuple[str, int, str, int, str, str, tuple[str, ...], bool]:
    """Run interactive configuration phases 0-2. Returns updated params.

    Returns ``(goal_name, count, source, min_files, bias, task_type, subsystems,
    discover_subsystems)``.
    """
    goal_name, goal_min_files, bias, task_type = _ask_eval_goal()
    if min_files == 0:
        min_files = goal_min_files
    count = _ask_task_count()
    source = _ask_source()
    if not subsystems and not discover_subsystems:
        if click.confirm("\nDiscover and filter by subsystems?", default=False):
            discover_subsystems = True
    return (
        goal_name,
        count,
        source,
        min_files,
        bias,
        task_type,
        subsystems,
        discover_subsystems,
    )


def _enrich_sdlc_tasks(
    tasks: list["Task"],
    mine_result: "MineResult",
    no_llm: bool,
    enrich: bool,
) -> list["Task"]:
    """Apply LLM instruction generation or legacy enrichment to SDLC tasks."""
    if not no_llm:
        from codeprobe.core.llm import llm_available
        from codeprobe.mining import generate_instructions

        if llm_available():
            click.echo("Generating instructions via LLM...")
            return generate_instructions(
                tasks,
                pr_bodies=mine_result.pr_bodies,
                changed_files_map=mine_result.changed_files_map,
            )
        click.echo(
            "No LLM backend available — using regex fallback for instructions.\n"
            "Install an LLM backend for better quality: "
            "pip install codeprobe[anthropic]"
        )
    elif enrich:
        from codeprobe.mining.extractor import enrich_tasks

        click.echo("Enriching low-quality tasks via LLM...")
        return enrich_tasks(tasks)
    return tasks


import logging as _logging

_log = _logging.getLogger(__name__)


def _cold_start_check(repo_path: Path, source_hint: str) -> bool:
    """Return True when the repo has zero merge commits (cold-start)."""
    from codeprobe.mining.extractor import list_merged_prs
    from codeprobe.mining.sources import RepoSource, detect_source

    if source_hint != "auto":
        source = RepoSource(
            host=source_hint, owner="", repo=repo_path.name, remote_url=""
        )
    else:
        source = detect_source(repo_path)

    return len(list_merged_prs(source, repo_path, limit=1)) == 0


def _comprehension_generator_available() -> bool:
    """Return True when the comprehension generator module is importable."""
    try:
        from codeprobe.mining import comprehension_generator  # noqa: F401

        return True
    except (ImportError, AttributeError):
        return False


def _resolve_task_type(
    task_type: str,
    repo_path: Path,
    source_hint: str,
) -> str:
    """Apply cold-start and comprehension-availability fallbacks.

    Cold-start: when the repo has 0 merge commits, navigation and general
    goals fall back to ``micro_probe``.

    Comprehension fallback: when ``architecture_comprehension`` is selected
    but the comprehension generator is not yet available, fall back to
    ``micro_probe``.

    Returns the (possibly adjusted) *task_type*.
    """
    is_cold_start = _cold_start_check(repo_path, source_hint)

    if is_cold_start and task_type in ("architecture_comprehension", "mixed"):
        _log.warning(
            "Cold-start repo (0 merge commits): falling back to micro_probe "
            "for task_type=%s",
            task_type,
        )
        return "micro_probe"

    # --- Comprehension generator availability ---
    if task_type == "architecture_comprehension":
        if not _comprehension_generator_available():
            _log.warning(
                "Comprehension generator not available: falling back to "
                "micro_probe for task_type=architecture_comprehension"
            )
            return "micro_probe"

    return task_type


_CLI_DEFAULTS = {
    "count": 5,
    "source": "auto",
    "min_files": 0,
    "enrich": False,
    "org_scale": False,
    "mcp_families": False,
}

# Named presets — values are merged as defaults; explicit CLI flags override.
PRESETS: dict[str, dict] = {
    "quick": {"count": 3},
    "mcp": {
        "count": 8,
        "org_scale": True,
        "mcp_families": True,
        "enrich": True,
    },
}

# ---------------------------------------------------------------------------
# User-defined mine profiles
# ---------------------------------------------------------------------------

# Keys that profiles may contain (matching Click parameter names).
_PROFILE_KEYS = frozenset(_CLI_DEFAULTS) | {
    "subsystem",
    "discover_subsystems",
    "no_llm",
    "family",
    "repos",
    "scan_timeout",
    "validate_flag",
    "curate",
    "backends",
    "verify_curation_flag",
    "sg_repo",
    "interactive",
    "preset",
    "goal",
}


def _user_profiles_path() -> Path:
    """Return ~/.codeprobe/mine-profiles.json."""
    return Path.home() / ".codeprobe" / "mine-profiles.json"


def _project_profiles_path(repo_path: Path | None = None) -> Path:
    """Return .codeprobe/mine-profiles.json relative to *repo_path* or cwd."""
    base = repo_path if repo_path is not None else Path.cwd()
    return base / ".codeprobe" / "mine-profiles.json"


def _load_profiles_from(path: Path) -> dict[str, dict]:
    """Load profiles from a JSON file, returning an empty dict on missing/invalid."""
    if not path.is_file():
        return {}
    try:
        data = json.loads(path.read_text(encoding="utf-8"))
        if isinstance(data, dict):
            return {k: v for k, v in data.items() if isinstance(v, dict)}
    except (json.JSONDecodeError, OSError):
        pass
    return {}


def load_all_profiles(repo_path: Path | None = None) -> dict[str, tuple[dict, str]]:
    """Load profiles from user and project levels.

    Returns ``{name: (profile_dict, source_label)}`` where *source_label* is
    ``"user"`` or ``"project"``.  Project-level profiles override user-level
    profiles with the same name.
    """
    merged: dict[str, tuple[dict, str]] = {}
    for name, prof in _load_profiles_from(_user_profiles_path()).items():
        merged[name] = (prof, "user")
    for name, prof in _load_profiles_from(_project_profiles_path(repo_path)).items():
        merged[name] = (prof, "project")
    return merged


def load_profile(name: str, repo_path: Path | None = None) -> dict:
    """Load a single profile by *name*.

    Project-level profiles take precedence over user-level ones.
    Raises ``click.UsageError`` if the profile is not found.
    """
    all_profiles = load_all_profiles(repo_path)
    entry = all_profiles.get(name)
    if entry is None:
        available = ", ".join(sorted(all_profiles)) if all_profiles else "(none)"
        raise click.UsageError(
            f"Profile '{name}' not found. Available profiles: {available}"
        )
    return entry[0]


def save_profile(name: str, values: dict) -> Path:
    """Save *values* as profile *name* to the user-level config file.

    Creates ``~/.codeprobe/`` if it doesn't exist.  Returns the file path.
    """
    path = _user_profiles_path()
    path.parent.mkdir(parents=True, exist_ok=True)
    existing = _load_profiles_from(path)
    existing[name] = {k: v for k, v in values.items() if k in _PROFILE_KEYS}
    path.write_text(json.dumps(existing, indent=2) + "\n", encoding="utf-8")
    return path


def list_profiles(repo_path: Path | None = None) -> list[tuple[str, str, dict]]:
    """Return ``[(name, source_label, profile_dict), ...]`` sorted by name."""
    all_profiles = load_all_profiles(repo_path)
    return sorted((name, source, prof) for name, (prof, source) in all_profiles.items())


def _apply_preset(
    preset: str | None,
    *,
    count: int,
    source: str,
    min_files: int,
    enrich: bool,
    org_scale: bool,
    mcp_families: bool,
) -> dict:
    """Return a dict of effective parameter values after applying *preset*.

    Explicit CLI flags (values that differ from their Click defaults) take
    precedence over preset values.
    """
    effective: dict = {
        "count": count,
        "source": source,
        "min_files": min_files,
        "enrich": enrich,
        "org_scale": org_scale,
        "mcp_families": mcp_families,
    }
    if preset is None:
        return effective

    preset_values = PRESETS.get(preset, {})
    for key, preset_val in preset_values.items():
        # Only apply preset value when the CLI value is still the default
        if effective[key] == _CLI_DEFAULTS.get(key):
            effective[key] = preset_val

    return effective


# ---------------------------------------------------------------------------
# Task-type dispatch
# ---------------------------------------------------------------------------


def _dispatch_by_task_type(
    *,
    task_type: str,
    repo_path: Path,
    count: int,
    source: str,
    min_files: int,
    subsystems: tuple[str, ...],
    no_llm: bool,
    enrich: bool,
    goal_name: str,
    bias: str,
) -> None:
    """Route to the correct generation pipeline based on *task_type*.

    - ``sdlc_code_change`` / ``mcp_tool_usage`` → PR-based SDLC mining
    - ``micro_probe`` → probe generation (code-navigation micro-benchmarks)
    - ``architecture_comprehension`` → comprehension generator
    - ``mixed`` → SDLC mining + probe generation
    """
    from codeprobe.mining import mine_tasks, write_task_dir

    if task_type in ("sdlc_code_change", "mcp_tool_usage"):
        _dispatch_sdlc(
            repo_path=repo_path,
            count=count,
            source=source,
            min_files=min_files,
            subsystems=subsystems,
            no_llm=no_llm,
            enrich=enrich,
            goal_name=goal_name,
            bias=bias,
        )
    elif task_type == "micro_probe":
        _dispatch_probes(
            repo_path=repo_path,
            count=count,
            goal_name=goal_name,
            bias=bias,
        )
    elif task_type == "architecture_comprehension":
        _dispatch_comprehension(
            repo_path=repo_path,
            count=count,
            goal_name=goal_name,
            bias=bias,
        )
    elif task_type == "mixed":
        _dispatch_mixed(
            repo_path=repo_path,
            count=count,
            source=source,
            min_files=min_files,
            subsystems=subsystems,
            no_llm=no_llm,
            enrich=enrich,
            goal_name=goal_name,
            bias=bias,
        )
    else:
        _log.warning("Unknown task_type '%s'; falling back to SDLC mining", task_type)
        _dispatch_sdlc(
            repo_path=repo_path,
            count=count,
            source=source,
            min_files=min_files,
            subsystems=subsystems,
            no_llm=no_llm,
            enrich=enrich,
            goal_name=goal_name,
            bias=bias,
        )


def _dispatch_sdlc(
    *,
    repo_path: Path,
    count: int,
    source: str,
    min_files: int,
    subsystems: tuple[str, ...],
    no_llm: bool,
    enrich: bool,
    goal_name: str,
    bias: str,
) -> None:
    """Run PR-based SDLC mining pipeline."""
    from codeprobe.mining import mine_tasks, write_task_dir

    mine_result = mine_tasks(
        repo_path,
        count=count,
        source_hint=source,
        min_files=min_files,
        subsystems=subsystems,
    )
    tasks = mine_result.tasks

    if not tasks:
        click.echo(
            "No suitable tasks found. Try a repo with merged PRs that include tests."
        )
        return

    tasks = _enrich_sdlc_tasks(tasks, mine_result, no_llm, enrich)

    tasks_dir = _clear_tasks_dir(repo_path)
    for task in tasks:
        write_task_dir(task, tasks_dir, repo_path)

    _record_task_ids_in_experiment(repo_path, [t.id for t in tasks])
    _show_results_table(tasks)
    _finish_mine_output(tasks, tasks_dir, goal_name, bias, subsystems, repo_path)


def _dispatch_probes(
    *,
    repo_path: Path,
    count: int,
    goal_name: str,
    bias: str,
) -> None:
    """Generate micro-benchmark probe tasks."""
    from codeprobe.probe.adapter import ProbeTaskAdapter
    from codeprobe.probe.generator import generate_probes

    probes = generate_probes(repo_path, count=count)

    if not probes:
        click.echo(
            "No probes generated. The repo may not contain enough "
            "extractable symbols (functions, classes)."
        )
        return

    tasks_dir = _clear_tasks_dir(repo_path)
    created = ProbeTaskAdapter.convert_batch(
        probes, tasks_dir, repo_name=repo_path.name
    )

    _record_task_ids_in_experiment(repo_path, [p.name for p in created])

    click.echo()
    click.echo(f"Generated {len(created)} probe tasks:")
    click.echo()
    for i, p in enumerate(created, 1):
        click.echo(f"  {i:>2}  {p.name}")
    click.echo()
    click.echo(f"Tasks written to {tasks_dir}")
    click.echo()
    _show_next_steps(repo_path, 0)


def _dispatch_comprehension(
    *,
    repo_path: Path,
    count: int,
    goal_name: str,
    bias: str,
) -> None:
    """Generate architecture comprehension tasks."""
    from codeprobe.mining.comprehension import ComprehensionGenerator
    from codeprobe.mining.writer import write_task_dir

    generator = ComprehensionGenerator(repo_path)
    tasks = generator.generate(count=count)

    if not tasks:
        click.echo(
            "No comprehension tasks generated. The repo may not have enough "
            "import structure for transitive reasoning tasks."
        )
        return

    tasks_dir = _clear_tasks_dir(repo_path)
    for task in tasks:
        write_task_dir(task, tasks_dir, repo_path)

    _record_task_ids_in_experiment(repo_path, [t.id for t in tasks])
    _show_results_table(tasks)
    _finish_mine_output(tasks, tasks_dir, goal_name, bias, (), repo_path)


def _dispatch_mixed(
    *,
    repo_path: Path,
    count: int,
    source: str,
    min_files: int,
    subsystems: tuple[str, ...],
    no_llm: bool,
    enrich: bool,
    goal_name: str,
    bias: str,
) -> None:
    """Run SDLC mining + probe generation, combining results."""
    from codeprobe.mining import mine_tasks, write_task_dir as write_mining_task
    from codeprobe.probe.adapter import ProbeTaskAdapter
    from codeprobe.probe.generator import generate_probes

    # Split count: half SDLC, half probes (at least 1 each when count >= 2)
    sdlc_count = max(1, count // 2)
    probe_count = max(1, count - sdlc_count)

    tasks_dir = _clear_tasks_dir(repo_path)
    all_task_ids: list[str] = []
    sdlc_tasks: list = []

    # SDLC mining (may produce 0 tasks on cold-start repos)
    mine_result = mine_tasks(
        repo_path,
        count=sdlc_count,
        source_hint=source,
        min_files=min_files,
        subsystems=subsystems,
    )
    sdlc_tasks = mine_result.tasks
    if sdlc_tasks:
        sdlc_tasks = _enrich_sdlc_tasks(sdlc_tasks, mine_result, no_llm, enrich)
        for task in sdlc_tasks:
            write_mining_task(task, tasks_dir, repo_path)
        all_task_ids.extend(t.id for t in sdlc_tasks)

    # Probe generation
    probes = generate_probes(repo_path, count=probe_count)
    probe_dirs: list[Path] = []
    if probes:
        probe_dirs = ProbeTaskAdapter.convert_batch(
            probes, tasks_dir, repo_name=repo_path.name
        )
        all_task_ids.extend(p.name for p in probe_dirs)

    if not sdlc_tasks and not probes:
        click.echo(
            "No tasks generated. Try a repo with merged PRs or more "
            "extractable symbols."
        )
        return

    _record_task_ids_in_experiment(repo_path, all_task_ids)

    # Show combined results
    if sdlc_tasks:
        _show_results_table(sdlc_tasks)
    if probe_dirs:
        click.echo(f"Generated {len(probe_dirs)} probe tasks:")
        for i, p in enumerate(probe_dirs, 1):
            click.echo(f"  {i:>2}  {p.name}")
        click.echo()

    click.echo(f"Tasks written to {tasks_dir}")
    if subsystems:
        click.echo(f"Subsystems: {', '.join(subsystems)}")
    click.echo()
    _show_next_steps(repo_path, min_files)


def _finish_mine_output(
    tasks: list,
    tasks_dir: Path,
    goal_name: str,
    bias: str,
    subsystems: tuple[str, ...],
    repo_path: Path,
) -> None:
    """Shared output: quality warnings, path, subsystems, next steps."""
    warnings = _quality_review(tasks, goal_name, bias)
    if warnings:
        click.echo("Quality warnings:")
        for w in warnings:
            click.echo(f"  ! {w}")
        click.echo()

    click.echo(f"Tasks written to {tasks_dir}")
    if subsystems:
        click.echo(f"Subsystems: {', '.join(subsystems)}")
    click.echo()
    _show_next_steps(repo_path, 0)


def run_mine(
    path: str,
    preset: str | None = None,
    goal: str | None = None,
    count: int = 5,
    source: str = "auto",
    min_files: int = 0,
    subsystems: tuple[str, ...] = (),
    discover_subsystems: bool = False,
    enrich: bool = False,
    interactive: bool | None = None,
    no_llm: bool = False,
    org_scale: bool = False,
    families: tuple[str, ...] = (),
    repos: tuple[str, ...] = (),
    scan_timeout: int = 60,
    validate_flag: bool = False,
    curate: bool = False,
    backends: tuple[str, ...] = (),
    verify_curation_flag: bool = False,
    mcp_families: bool = False,
    sg_repo: str = "",
) -> None:
    """Mine eval tasks from a repository."""
    from codeprobe.mining import mine_tasks, write_task_dir

    # Apply preset defaults — explicit CLI flags override
    resolved = _apply_preset(
        preset,
        count=count,
        source=source,
        min_files=min_files,
        enrich=enrich,
        org_scale=org_scale,
        mcp_families=mcp_families,
    )
    count = resolved["count"]
    source = resolved["source"]
    min_files = resolved["min_files"]
    enrich = resolved["enrich"]
    org_scale = resolved["org_scale"]
    mcp_families = resolved["mcp_families"]

    # CLI validation: --backends agent --no-llm is incompatible
    if no_llm and "agent" in backends:
        raise click.UsageError(
            "Cannot use --backends agent with --no-llm: "
            "AgentSearchBackend requires an LLM backend."
        )

    repo_path = _resolve_repo_path(path)

    if org_scale:
        # Build repo_paths list: primary path + any --repos entries
        repo_paths = [repo_path]
        for r in repos:
            if _is_git_url(r):
                repo_paths.append(_clone_repo(r))
            else:
                rp = Path(r).resolve()
                if not rp.exists():
                    click.echo(f"Path does not exist: {rp}")
                    raise SystemExit(1)
                repo_paths.append(rp)
        _run_org_scale_mine(
            repo_paths,
            count=count,
            no_llm=no_llm,
            families=families,
            scan_timeout=scan_timeout,
            validate_flag=validate_flag,
            curate=curate,
            backends=backends,
            verify_curation_flag=verify_curation_flag,
            mcp_families=mcp_families,
            sg_repo=sg_repo,
        )
        return

    if interactive is None:
        interactive = _is_interactive()

    goal_name = "General benchmarking"
    bias = "balanced"
    task_type = "mixed"

    # --goal flag: resolve goal without interactive prompt
    if goal is not None:
        goal_key = _GOAL_FLAG_MAP.get(goal)
        if goal_key is None:
            raise click.UsageError(
                f"Unknown goal '{goal}'. "
                f"Choose from: {', '.join(sorted(_GOAL_FLAG_MAP))}"
            )
        goal_name, goal_min_files, bias, task_type = _EVAL_GOALS[goal_key]
        if min_files == 0:
            min_files = goal_min_files
    elif interactive:
        (
            goal_name,
            count,
            source,
            min_files,
            bias,
            task_type,
            subsystems,
            discover_subsystems,
        ) = _interactive_config(
            count, source, min_files, subsystems, discover_subsystems, repo_path
        )

    # Apply cold-start and comprehension-availability fallbacks
    task_type = _resolve_task_type(task_type, repo_path, source)

    if discover_subsystems:
        subsystems = _discover_and_select(repo_path, source)
        if not subsystems:
            return

    subsystems = tuple(s if s.endswith("/") else s + "/" for s in subsystems)

    if interactive and not _show_preflight(
        repo_path, goal_name, count, source, min_files, bias, subsystems
    ):
        click.echo("Aborted.")
        return

    if interactive:
        click.echo("\nMining tasks...")

    # Dispatch based on resolved task_type
    _dispatch_by_task_type(
        task_type=task_type,
        repo_path=repo_path,
        count=count,
        source=source,
        min_files=min_files,
        subsystems=subsystems,
        no_llm=no_llm,
        enrich=enrich,
        goal_name=goal_name,
        bias=bias,
    )


# ---------------------------------------------------------------------------
# Org-scale mining pipeline
# ---------------------------------------------------------------------------


def _run_org_scale_mine(
    repo_paths: list[Path],
    *,
    count: int = 5,
    no_llm: bool = False,
    families: tuple[str, ...] = (),
    scan_timeout: int = 60,
    validate_flag: bool = False,
    curate: bool = False,
    backends: tuple[str, ...] = (),
    verify_curation_flag: bool = False,
    mcp_families: bool = False,
    sg_repo: str = "",
) -> None:
    """Mine org-scale comprehension tasks with oracle verification."""
    from codeprobe.mining.org_scale import mine_org_scale_tasks
    from codeprobe.mining.org_scale_families import FAMILIES, FAMILY_BY_NAME, TaskFamily
    from codeprobe.mining.writer import write_task_dir

    primary_repo = repo_paths[0]
    repo_names = ", ".join(rp.name for rp in repo_paths)
    click.echo(f"Scanning {repo_names} for org-scale patterns...", err=True)

    # Filter families if specified
    selected_families: tuple[TaskFamily, ...] | None = None
    if families:
        selected = [FAMILY_BY_NAME[f] for f in families if f in FAMILY_BY_NAME]
        unknown = [f for f in families if f not in FAMILY_BY_NAME]
        if unknown:
            click.echo(f"Unknown families: {', '.join(unknown)}")
            click.echo(f"Available: {', '.join(FAMILY_BY_NAME)}")
            return
        selected_families = tuple(selected)

    # Interactive family selection when TTY and no explicit --family filter
    if not selected_families and _is_interactive():
        selected_families = _interactive_family_selection(repo_paths)
        if selected_families is not None and not selected_families:
            click.echo("No families selected. Aborted.")
            return

    # Default sg_repo from primary repo name if not explicitly provided
    effective_sg_repo = sg_repo
    if not effective_sg_repo and mcp_families:
        effective_sg_repo = f"github.com/sg-evals/{repo_paths[0].name}"

    result = mine_org_scale_tasks(
        repo_paths,
        count=count,
        families=selected_families,
        no_llm=no_llm,
        scan_timeout=scan_timeout,
        include_mcp_families=mcp_families,
        sg_repo=effective_sg_repo,
    )

    if not result.tasks:
        click.echo(
            "No org-scale tasks generated. Repo may not have enough pattern matches."
        )
        if result.scan_results:
            click.echo("\nScan results (below min_hits threshold):")
            for sr in result.scan_results:
                click.echo(f"  {sr.family.name}: {len(sr.matched_files)} files")
        return

    # Show scan summary
    click.echo()
    click.echo("Scan results:")
    for sr in result.scan_results:
        click.echo(f"  {sr.family.name}: {len(sr.matched_files)} files matched")
    click.echo()

    # Run MCP delta validation if requested
    if validate_flag:
        _run_validation(result, repo_paths)

    # Run curation pipeline if requested
    curation_backends_used: tuple[str, ...] = ()
    curated_tasks = result.tasks
    if curate:
        curated_tasks, curation_backends_used = _run_curation(
            result,
            repo_paths,
            backends=backends,
            no_llm=no_llm,
            verify_curation_flag=verify_curation_flag,
        )

    # Write tasks
    tasks_dir = _clear_tasks_dir(primary_repo)
    for task in curated_tasks:
        write_task_dir(
            task,
            tasks_dir,
            primary_repo,
            curation_backends=curation_backends_used,
        )

    _record_task_ids_in_experiment(primary_repo, [t.id for t in curated_tasks])

    _show_org_scale_results(
        curated_tasks, tasks_dir, primary_repo, curation_backends_used
    )


def _build_curation_backends(
    backends: tuple[str, ...],
    no_llm: bool,
) -> list[object]:
    """Build list of CurationBackend instances from backend names.

    When *backends* is empty, uses defaults (grep + pr_diff; agent_search
    only when LLM is available).
    """
    from codeprobe.mining.curator_backends import (
        AgentSearchBackend,
        GrepBackend,
        PRDiffBackend,
        SourcegraphBackend,
    )

    _BACKEND_MAP = {
        "grep": GrepBackend,
        "sourcegraph": SourcegraphBackend,
        "pr_diff": PRDiffBackend,
        "agent": AgentSearchBackend,
    }

    if backends:
        return [_BACKEND_MAP[name]() for name in backends if name in _BACKEND_MAP]

    # Defaults: grep + pr_diff; agent_search only if LLM available
    result: list[object] = [GrepBackend(), PRDiffBackend()]
    if not no_llm:
        result.append(AgentSearchBackend())
    return result


def _run_curation(
    result: "OrgScaleMineResult",
    repo_paths: list[Path],
    *,
    backends: tuple[str, ...] = (),
    no_llm: bool = False,
    verify_curation_flag: bool = False,
) -> tuple[list["Task"], tuple[str, ...]]:
    """Run curation pipeline on mined tasks, returning updated tasks and backends used."""
    from codeprobe.mining.curator import CurationPipeline
    from codeprobe.mining.curator_tiers import classify_tiers, verify_curation
    from codeprobe.mining.org_scale import generate_org_scale_task

    backend_instances = _build_curation_backends(backends, no_llm)
    pipeline = CurationPipeline(backends=backend_instances)

    curated_tasks: list["Task"] = []
    all_backends_used: set[str] = set()

    for sr in result.scan_results:
        # Run curation for this family
        curation_result = pipeline.curate(repos=repo_paths, family=sr.family)
        if not curation_result.files:
            # No curated files: keep original tasks for this family
            for task in result.tasks:
                if task.metadata.category == sr.family.name:
                    curated_tasks.append(task)
            continue

        all_backends_used.update(curation_result.backends_used)

        # Classify tiers
        tiered_files = classify_tiers(
            list(curation_result.files),
            sr.family,
            repo_paths,
            use_llm=not no_llm,
        )

        # Build updated CurationResult with tiered files
        from codeprobe.mining.curator import CurationResult

        tiered_result = CurationResult(
            family=curation_result.family,
            files=tuple(tiered_files),
            repo_paths=curation_result.repo_paths,
            commit_shas=curation_result.commit_shas,
            backends_used=curation_result.backends_used,
            merge_config=curation_result.merge_config,
            matched_files=frozenset(cf.path for cf in tiered_files),
        )

        # Verify curation if requested
        if verify_curation_flag and not no_llm:
            verdict = verify_curation(tiered_files, sr.family, repo_paths)
            click.echo(f"  Curation verification ({sr.family.name}): {verdict}")

        # Re-generate task with curation result
        for task in result.tasks:
            if task.metadata.category == sr.family.name:
                curated_task = generate_org_scale_task(
                    sr,
                    no_llm=no_llm,
                    curation_result=tiered_result,
                )
                if curated_task is not None:
                    curated_tasks.append(curated_task)
                    break  # One task per family/scan_result

    backends_tuple = tuple(sorted(all_backends_used))
    return curated_tasks, backends_tuple


def _interactive_family_selection(
    repo_paths: list[Path],
) -> tuple["TaskFamily", ...] | None:
    """Show detected families with hit counts and prompt for selection.

    Returns None to use all families (default), or a tuple of selected families.
    """
    from codeprobe.mining.org_scale_families import FAMILIES
    from codeprobe.mining.org_scale_scanner import get_tracked_files, scan_repo

    # Quick scan to show hit counts
    all_tracked: frozenset[str] = frozenset()
    for rp in repo_paths:
        all_tracked = all_tracked | get_tracked_files(rp)

    scan_results = scan_repo(repo_paths, FAMILIES, tracked_files=all_tracked)

    click.echo()
    click.echo("Detected task families:")
    entries = []
    for i, family in enumerate(FAMILIES, 1):
        sr = next((s for s in scan_results if s.family.name == family.name), None)
        hit_count = len(sr.matched_files) if sr else 0
        status = (
            f"{hit_count} files"
            if hit_count >= family.min_hits
            else f"{hit_count} files (below threshold)"
        )
        entries.append((family, hit_count))
        click.echo(f"  [{i}] {family.name:<30s} {status}")
    click.echo()

    raw = click.prompt(
        "Select families (comma-separated numbers, or Enter for all)",
        default="",
        show_default=False,
    )

    if not raw.strip():
        return None  # Use all families

    selected = []
    for token in raw.split(","):
        token = token.strip()
        try:
            idx = int(token)
            if 1 <= idx <= len(FAMILIES):
                selected.append(FAMILIES[idx - 1])
            else:
                click.echo(f"  Skipping out-of-range index: {idx}")
        except ValueError:
            click.echo(f"  Skipping invalid input: {token}")

    return tuple(selected) if selected else tuple()


def _run_validation(
    result: "OrgScaleMineResult",
    repo_paths: list[Path],
) -> None:
    """Run MCP delta validation and display results."""
    from codeprobe.mining.org_scale_validate import validate_families

    # Group tasks by family for validation
    family_tasks: dict[str, list] = {}
    for task in result.tasks:
        family_tasks.setdefault(task.metadata.category, []).append(task)

    families_to_validate = []
    tasks_per_family = []
    repos_per_family = []
    for sr in result.scan_results:
        tasks_for_family = family_tasks.get(sr.family.name, [])
        if tasks_for_family:
            families_to_validate.append(sr.family)
            tasks_per_family.append(tasks_for_family)
            repos_per_family.append(repo_paths)

    if not families_to_validate:
        click.echo("No families to validate.")
        return

    click.echo("Running MCP delta validation...")
    delta_results = validate_families(
        families_to_validate, tasks_per_family, repos_per_family
    )
    click.echo()
    click.echo("Validation results:")
    for dr in delta_results:
        status = "BASELINE-ONLY" if dr.is_baseline_only else "OK"
        click.echo(f"  {dr.family_name:<30s} grep_f1={dr.grep_f1:.3f} [{status}]")
    click.echo()


def _show_org_scale_results(
    tasks: list["Task"],
    tasks_dir: Path,
    repo_path: Path,
    curation_backends: tuple[str, ...] = (),
) -> None:
    """Display org-scale mining results table and next steps."""
    curated = bool(curation_backends)

    click.echo(f"Generated {len(tasks)} org-scale tasks:")
    click.echo()

    # Header — add Tiers column when curation is active
    if curated:
        click.echo(
            f"  {'#':>2}  {'Task ID':<14} {'Family':<24} {'Difficulty':<10} "
            f"{'Files':>5}  {'Tiers (R/S/C)':>13}"
        )
        click.echo("  " + "-" * 76)
    else:
        click.echo(
            f"  {'#':>2}  {'Task ID':<14} {'Family':<24} {'Difficulty':<10} "
            f"{'Files':>5}"
        )
        click.echo("  " + "-" * 60)

    for i, t in enumerate(tasks, 1):
        base = (
            f"  {i:>2}  {t.id:<14} {t.metadata.category:<24} "
            f"{t.metadata.difficulty:<10} "
            f"{len(t.verification.oracle_answer):>5}"
        )
        if curated and t.verification.oracle_tiers:
            tiers = dict(t.verification.oracle_tiers)
            req = sum(1 for v in tiers.values() if v == "required")
            sup = sum(1 for v in tiers.values() if v == "supplementary")
            ctx = sum(1 for v in tiers.values() if v == "context")
            click.echo(f"{base}  {req:>4}/{sup:>3}/{ctx:>3}")
        else:
            click.echo(base)

    click.echo()

    # Curation summary
    if curated:
        click.echo(f"Curation backends: {', '.join(curation_backends)}")
        click.echo()

    click.echo(f"Tasks written to {tasks_dir}")
    click.echo()
    click.echo("Next steps:")
    click.echo(f"  1. Run eval:     codeprobe run {repo_path} --agent claude")
    click.echo(f"  2. Check scores: codeprobe oracle-check {tasks_dir}/<task_id>")
    if curated:
        click.echo(
            f"  3. Weighted F1:  codeprobe oracle-check {tasks_dir}/<task_id> "
            f"--metric weighted_f1"
        )
    click.echo()
