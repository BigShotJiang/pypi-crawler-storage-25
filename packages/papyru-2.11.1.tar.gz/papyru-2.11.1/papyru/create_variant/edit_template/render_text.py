from dataclasses import dataclass
from enum import Enum
from os import path
from subprocess import run
from tempfile import TemporaryDirectory
from uuid import uuid4

import resi


@dataclass(frozen=True)
class RGBAColor:
    red: int
    green: int
    blue: int
    alpha: float


class VerticalAlignment(Enum):
    Center = 0x01
    Top = 0x02
    Bottom = 0x03


class HorizontalAlignment(Enum):
    Center = 0x01
    Left = 0x02
    Right = 0x03


@dataclass(frozen=True)
class Alignment:
    vertical: VerticalAlignment
    horizontal: HorizontalAlignment


@dataclass(frozen=True)
class TextConfig:
    text: str
    fg_color: RGBAColor
    bg_color: RGBAColor
    font_name: str
    alignment: Alignment
    width: int
    height: int


def render_text(config: TextConfig, resi_instance: resi.Instance) -> bytes:
    # see `convert -list gravity`
    def _get_gravity(alignment: Alignment) -> str:
        h = ''
        v = ''

        if alignment.horizontal == HorizontalAlignment.Left:
            h = 'West'
        elif alignment.horizontal == HorizontalAlignment.Right:
            h = 'East'

        if alignment.vertical == VerticalAlignment.Top:
            v = 'North'
        elif alignment.vertical == VerticalAlignment.Bottom:
            v = 'South'

        if h == '' and v == '':
            return 'Center'

        return '%s%s' % (v, h)

    def _get_font(font_name, resi_instance):
        fonts_dir = resi_instance.fonts_directory()

        if fonts_dir is None or not path.exists(fonts_dir):
            raise Exception('missing fonts directory')

        return path.join(fonts_dir, font_name)

    with TemporaryDirectory() as temp_dir:
        out_filename = path.join(temp_dir, '%s.png' % uuid4())

        text = config.text
        draw_operators = (
            ('-fill', _imagemagick_color_string(config.fg_color),
             '-font', '%s' % _get_font(config.font_name, resi_instance),
             '-gravity', _get_gravity(config.alignment),
             'label:%s' % text)
            if text != ''
            else ('xc:none',))

        resp = run([
            'magick',
            '-colorspace', 'RGB',
            '-size', '%sx%s' % (config.width, config.height),
            '-background', _imagemagick_color_string(config.bg_color),
            *draw_operators,
            'PNG32:%s' % out_filename
        ])

        if resp.returncode != 0:
            raise Exception('could not render text "%s"' % config.text)

        with open(out_filename, 'rb') as f:
            return f.read()


def _imagemagick_color_string(color: RGBAColor) -> str:
    return 'rgba(%d, %d, %d, %0.2f)' % (color.red,
                                        color.green,
                                        color.blue,
                                        color.alpha)
