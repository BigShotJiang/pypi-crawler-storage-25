from logging import getLogger

import resi

from papyru import XMLHelper
from papyru.create_variant.constants import (
    MANUFACTURER_ADDRESS_ALIGNMENT, MANUFACTURER_ADDRESS_COLOR_BACKGROUND,
    MANUFACTURER_ADDRESS_COLOR_FOREGROUND, MANUFACTURER_ADDRESS_FONT,
    MANUFACTURER_ADDRESS_PLACEHOLDER_ID)
from papyru.create_variant.resi import import_into_resi

from .render_text import TextConfig, render_text
from .xml import (ImageInfo, find_placeholder, fit_image,
                  replace_text_with_image)

log = getLogger(__name__)


def insert_manufacturer_address(doc: XMLHelper,
                                disposition: str,
                                resi_instance: resi.Instance,
                                resi_url: str,
                                ) -> XMLHelper:
    ph = find_placeholder(doc, 'text', MANUFACTURER_ADDRESS_PLACEHOLDER_ID)
    if ph is None:
        log.warning('no manufacturer address found')
        return doc

    width = float(doc.get_attribute(ph.wrapper, 'width'))
    height = float(doc.get_attribute(ph.wrapper, 'height'))

    address = '\n'.join(map(
        lambda tspan: tspan.text,
        ph.placeholder.findall(
            './/{%s}tspan' % doc.default_namespace)))
    location = _create_text_manufacturer_address(
                  address, width, height, disposition, resi_instance, resi_url)

    return fit_image(
        replace_text_with_image(doc, MANUFACTURER_ADDRESS_PLACEHOLDER_ID),
        MANUFACTURER_ADDRESS_PLACEHOLDER_ID,
        ImageInfo(location=location,
                  width=width,
                  height=height))


def _create_text_manufacturer_address(address: str,
                                      width: int,
                                      height: int,
                                      disposition: str,
                                      resi_instance: resi.Instance,
                                      resi_url: str) -> str:
    text_bytes = render_text(
        TextConfig(
            text=address,
            width=int(width),
            height=int(height),
            alignment=MANUFACTURER_ADDRESS_ALIGNMENT,
            font_name=MANUFACTURER_ADDRESS_FONT,
            fg_color=MANUFACTURER_ADDRESS_COLOR_FOREGROUND,
            bg_color=MANUFACTURER_ADDRESS_COLOR_BACKGROUND),
        resi_instance)

    return import_into_resi(
        text_bytes,
        resi_instance,
        resi_url,
        None,
        disposition)
