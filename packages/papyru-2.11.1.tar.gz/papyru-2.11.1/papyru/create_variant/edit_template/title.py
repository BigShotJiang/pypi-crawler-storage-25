from typing import Optional

import resi

from papyru import XMLHelper
from papyru.create_variant.constants import (TITLE_ALIGNMENT,
                                             TITLE_COLOR_BACKGROUND,
                                             TITLE_COLOR_FOREGROUND,
                                             TITLE_FONT, TITLE_PLACEHOLDER_ID)
from papyru.create_variant.resi import import_into_resi

from .render_text import TextConfig, render_text
from .xml import (ImageInfo, find_placeholder, fit_image,
                  replace_text_with_image)


def insert_title(doc: XMLHelper,
                 title: Optional[str] = None,
                 disposition: Optional[str] = None,
                 resi_instance: Optional[resi.Instance] = None,
                 resi_url: Optional[str] = None
                 ) -> XMLHelper:

    ph = find_placeholder(doc, 'text', TITLE_PLACEHOLDER_ID)

    if ph is None:
        return doc

    if title is None:
        for tspan in ph.placeholder.findall('./{%s}%s'
                                            % (doc.default_namespace,
                                               'tspan')):
            tspan.text = ''

        return doc

    width = float(doc.get_attribute(ph.wrapper, 'width'))
    height = float(doc.get_attribute(ph.wrapper, 'height'))

    title_location = _create_title_image(title, width, height, disposition,
                                         resi_instance, resi_url)

    return fit_image(
        replace_text_with_image(doc, TITLE_PLACEHOLDER_ID),
        TITLE_PLACEHOLDER_ID,
        ImageInfo(location=title_location,
                  width=width,
                  height=height))


def _create_title_image(title: str,
                        width: int,
                        height: int,
                        disposition: str,
                        resi_instance: resi.Instance,
                        resi_url: str
                        ) -> str:
    text_bytes = render_text(
        TextConfig(text=title,
                   width=int(width),
                   height=int(height),
                   alignment=TITLE_ALIGNMENT,
                   font_name=TITLE_FONT,
                   fg_color=TITLE_COLOR_FOREGROUND,
                   bg_color=TITLE_COLOR_BACKGROUND),
        resi_instance)

    return import_into_resi(
        text_bytes, resi_instance, resi_url, None, disposition)
