"""
DIFP NODE - initial release (structure placeholder).
"""
