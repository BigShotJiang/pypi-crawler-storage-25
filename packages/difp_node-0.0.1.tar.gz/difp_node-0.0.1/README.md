# DIFP NODE

Initial skeleton package for DIFP NODE.
