﻿# Dominian

> **Real-time codebase knowledge graph for AI agents. Query your code with natural language.**

---

## 🚀 Quick Start

### Installation

```bash
pip install dominian
```

### CLI Usage

```bash
# Initialize project (creates .dominian/ with isolated database)
dominian init

# Scan codebase into knowledge graph (10x faster with batch inserts)
dominian scan /path/to/your/project

# Watch files for live updates
dominian watch /path/to/project

# Start API server (auto-port 8000-9000)
dominian serve

# Query via CLI
dominian query "what does UserService depend on"

# Query without server (fastest)
dominian query "what does X depend on" --oneshot

# Check all running servers across projects
dominian status

# Stop this project's server
dominian stop

# View project statistics
dominian info
```

---

## 🎯 What is Dominian?

Dominian scans your codebase and builds a **living knowledge graph** that AI agents can query instantly.

**For Developers:** Use CLI commands to analyze code, find dependencies, detect issues.  
**For AI Agents:** Query via HTTP API for instant, token-optimized codebase intelligence.

---

## 💻 CLI Commands

### Init Command

```bash
# Initialize current directory
dominian init

# Initialize specific project with preferred port
dominian init /path/to/project --port 8000

# Creates .dominian/ folder with:
#   - config.yaml (port, database path)
#   - agentgraph.db (per-project SQLite database)
#   - server.pid (tracks running server)
```

### Scan Command

```bash
# Scan current directory
dominian scan .

# Scan specific path with file watching
dominian scan /path/to/project --watch

# Scan and start server after
dominian scan . --serve

# Incremental scan (skip unchanged files)
dominian scan . --incremental
```

### Watch Command

```bash
# Watch files for changes (no initial full scan)
dominian watch /path/to/project

# Use with specific database
dominian watch . --db ./myproject.db
```

### Query Command

```bash
# Natural language queries (requires running server)
dominian query "what does AuthService depend on"
dominian query "who uses DatabaseManager"
dominian query "find circular dependencies"
dominian query "show all classes in models.py"

# Query without server (--oneshot mode)
dominian query "what does X depend on" --oneshot

# Query specific server
dominian query "show hotspots" --server http://localhost:8001
```

### Server Command

```bash
# Start API server (auto-detects config, auto-assigns port if busy)
dominian serve

# With custom port
dominian serve --port 9000

# Server auto-finds free port if preferred is busy:
# "Port 8000 is busy (PID 1234). Finding next free port..."
# "Using port 8001."
```

### Status Command

```bash
# Show all running Dominian servers
dominian status

# Output:
# ┌─────────┬──────┬─────┬─────────┬────────────────────────┐
# │ Project │ Port │ PID │ Status  │ Database               │
# ├─────────┼──────┼─────┼─────────┼────────────────────────┤
# │ flask   │ 8000 │ 123 │ running │ .dominian/agentgraph.db │
# │ django  │ 8001 │ 456 │ running │ .dominian/agentgraph.db │
# └─────────┴──────┴─────┴─────────┴────────────────────────┘
```

### Stop Command

```bash
# Stop server for current project
dominian stop

# Stop with force (SIGKILL)
dominian stop --force

# Stop specific project
dominian stop /path/to/project
```

### Info Command

```bash
# Show project statistics
dominian info

# With specific database
dominian info --db /path/to/custom.db
```

---

## 🤖 Using with AI Agents (Claude Code, Codex, Cursor)

### Step 1: Start the Server

```bash
dominian serve
```

### Step 2: Tell Your Agent

**For Claude Code:**
```
Use Dominian at http://localhost:8000 to understand the codebase before making changes.
Query: what does UserService depend on
```

**For Codex (GitHub Copilot):**
```
Query the Dominian API at http://localhost:8000/query?q=what+breaks+if+I+change+UserService
```

**For Cursor:**
```
Ask Dominian: "show me all functions that call DatabaseManager"
```

### API Endpoints

| Endpoint | Description | Example |
|----------|-------------|---------|
| GET /query?q=... | Natural language query | /query?q=what+does+X+depend+on |
| GET /node/{name} | Get node details | /node/AuthService |
| GET /impact/{name} | Impact analysis | /impact/DatabasePool |
| POST /scan/sync | Scan directory | {"path": "/project", "watch": true} |
| GET /health | Health check | - |

---

## 🔌 MCP Server (Model Context Protocol)

Connect Dominian to any MCP-compatible AI agent (**Claude Desktop, Cursor, Windsurf**) for hands-free codebase analysis.

### Installation with MCP Support

```bash
pip install "dominian[mcp]"
```

Or install MCP separately:
```bash
pip install dominian mcp
```

### Configure Claude Desktop

Add to `claude_desktop_config.json`:

**Windows:** `%APPDATA%\Claude\claude_desktop_config.json`  
**Mac:** `~/Library/Application Support/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "dominian": {
      "command": "dominian-mcp"
    }
  }
}
```

### Configure Cursor

Add to Cursor MCP settings (Settings → MCP):

```json
{
  "mcpServers": {
    "dominian": {
      "command": "dominian-mcp"
    }
  }
}
```

### Available MCP Tools

Once configured, agents can use these tools:

| Tool | Purpose | Example |
|------|---------|---------|
| `initialize_project` | Setup project for analysis | Auto-runs when needed |
| `scan_codebase` | Build/update knowledge graph | Scans all code files |
| `query_codebase` | Natural language queries | "what does UserService depend on" |
| `get_codebase_status` | Check server/stats | Shows nodes, edges, health |

### MCP Usage Example

**User:** *"Analyze this codebase for me"*

**Claude:**
1. Calls `initialize_project(path=".")` → Creates `.dominian/`
2. Calls `scan_codebase(path=".")` → Parses all files
3. Calls `query_codebase(query="show all classes")` → Gets results
4. Responds: *"This project has 15 classes including UserService, OrderService..."*

### Token & Cost Efficiency with MCP

When agents need full codebase context:

| Scenario | Approach | Tokens | Typical Latency |
|----------|----------|--------|-----------------|
| **Baseline** | Reading 100 files directly | ~40,000-80,000 | 10-30s |
| **With Dominian** | Querying knowledge graph | ~500 | 0.1-0.5s |
| **Reduction** | Structured vs. raw access | **~95-99% fewer tokens** | **10-50x faster** |

*Actual savings depend on project size, query type, and file complexity.*

---

### Query Examples

```bash
# What does X depend on?
curl "http://localhost:8000/query?q=what+does+UserService+depend+on&agent=claude"

# Who uses X?
curl "http://localhost:8000/query?q=who+uses+DatabaseManager&agent=codex"

# Find hotspots (complex code)
curl "http://localhost:8000/hotspots?limit=10"

# Check for circular dependencies
curl "http://localhost:8000/cycles"

# Find orphaned code
curl "http://localhost:8000/orphans"
```

### Response Format (Token-Optimized)

```
SUMMARY: UserService depends on 4 nodes

FOCUS: UserService[class|auth/service.py:15-89|complexity:7|quality:85%]

DEPENDENCIES:
- UserRepository[class|db/repo.py|uses]
- TokenManager[class|auth/token.py|manages]
- PasswordHasher[function|utils/crypto.py|calls]
- Logger[class|core/log.py|injects]

LATENCY: 0.12ms
```

---

## 📊 Supported Languages

| Language | Parser | Notes |
|----------|--------|-------|
| Python | Tree-sitter + regex fallback | Best support (functions, classes, imports) |
| JavaScript/TypeScript | Tree-sitter | Functions, classes, ES6 modules |
| Java | Tree-sitter | Classes, methods, imports |
| Go | Tree-sitter | Functions, structs, interfaces |
| Rust | Tree-sitter | Functions, structs, traits |
| C/C++ | Tree-sitter | Functions, structs, includes |

*Parser accuracy varies by language complexity and code patterns.*

---

## ⚡ Performance

- **Scan Speed:** ~30 files/second (parallel parsing)
- **Query Latency:** 0.05-0.15ms average
- **Live Updates:** <100ms when files change
- **Memory:** <200MB for typical projects

---

## 🧪 Beta Status

**Why Beta?**

Dominian is classified as Beta (Development Status 4) because:

1. **Active Development:** Core features are stable, but API may evolve based on user feedback
2. **New Product:** Recently launched, gathering real-world usage data
3. **Future Features:** Planning advanced capabilities (cross-repo analysis, AI predictions)

**Production Ready?**
- ✅ Core functionality is stable and tested
- ✅ Used successfully on real codebases
- ⚠️ API contract may change in v2.0

**When will it be stable?**
- Target: v2.0 (stable release) after 3 months of production usage
- Your feedback helps shape the stable API!

---

## 📦 Installation & Setup

### From PyPI (Recommended)

```bash
pip install dominian
```

### From Source

```bash
git clone https://github.com/yourusername/dominian.git
cd dominian
pip install -r requirements.txt
pip install -e .
```

### Verify Installation

```bash
dominian --version
dominian --help
```

---

## 🛠️ Development

### Testing on TestPyPI (for contributors)

```bash
# Build package
python -m build

# Upload to TestPyPI
python -m twine upload --repository testpypi dist/*

# Install from TestPyPI
pip install --index-url https://test.pypi.org/simple/ dominian
```

### Running Tests

```bash
pytest tests/
```

---

## 🔧 Configuration

### Environment Variables

```bash
# Default port for server
DOMINIAN_PORT=8000

# Database location
DOMINIAN_DB_PATH=~/.dominian/agentgraph.db

# Log level
DOMINIAN_LOG_LEVEL=INFO
```

If port 8000 is busy (e.g., HTML server running):

```bash
cd /project
dominian serve
# ⚠️ Port 8000 is busy (PID 1234). Finding next free port...
# ✓ Using port 8001.
# ✓ Server: http://localhost:8001
```

Port is automatically persisted in `.dominian/config.yaml`.

---

## �📝 Example Workflows

### Workflow 1: Understanding a New Codebase

```bash
# 1. Scan the project
dominian scan /path/to/project

# 2. Start server
dominian serve

# 3. Ask questions
dominian query "show me the main entry points"
dominian query "what are the most complex files"
dominian query "find all database-related classes"
```

### Workflow 2: Refactoring with AI Agent

```bash
# 1. Start server in background
dominian serve &

# 2. Tell Claude/Codex:
# "Before refactoring UserService, query Dominian at 
#  http://localhost:8000 to understand its dependencies"

# 3. Agent automatically queries:
# GET /query?q=what+does+UserService+depend+on

# 4. After refactoring, graph updates automatically
# (file watcher detects changes)
```

### Workflow 3: Code Review

```bash
# Check for issues before committing
dominian query "find circular dependencies"
dominian query "show orphaned code"
dominian query "most complex functions"
```

---

## 🐛 Troubleshooting

### "command not found: dominian"

```bash
# Make sure pip bin directory is in PATH
# Or use:
python -m dominian --help
```

### "Permission denied" on scan

```bash
# Check file permissions
# Skip restricted directories:
dominian scan . --exclude-dir=node_modules --exclude-dir=.git
```

### Server won't start (port in use)

```bash
# Use different port
dominian serve --port 9000
```

---

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch
3. Make changes
4. Run tests
5. Submit PR

---

## 📄 License

MIT License - see LICENSE file

---

## 👤 Author

Created by **MaSh**

---

## 🔗 Links

- PyPI: https://pypi.org/project/dominian/
- Documentation: [Coming Soon]
- Issues: [GitHub Issues]

---

**Happy Coding! 🚀**
