# Dominian MCP Server - AI Agent Integration

Connect Dominian to any MCP-compatible AI agent (Claude Desktop, Cursor, Windsurf, etc.) for instant codebase intelligence.

## Installation

```bash
# Install with MCP support
pip install "dominian[mcp]"

# Or install MCP separately
pip install dominian
pip install mcp
```

## Claude Desktop Configuration

Add to `claude_desktop_config.json`:

**Mac:** `~/Library/Application Support/Claude/claude_desktop_config.json`
**Windows:** `%APPDATA%/Claude/claude_desktop_config.json`

```json
{
  "mcpServers": {
    "dominian": {
      "command": "dominian-mcp"
    }
  }
}
```

If `dominian-mcp` is not in PATH:

```json
{
  "mcpServers": {
    "dominian": {
      "command": "python",
      "args": ["-m", "mcp_server"],
      "cwd": "/path/to/dominian/install"
    }
  }
}
```

## Cursor Configuration

Add to Cursor MCP settings (Settings → MCP):

```json
{
  "mcpServers": {
    "dominian": {
      "command": "dominian-mcp"
    }
  }
}
```

## Available Tools

Once configured, Claude/Cursor can use these tools:

### 1. `initialize_project`
Sets up a new project for Dominian analysis.

```
Claude: "Initialize this codebase for analysis"
→ Calls: initialize_project(path=".")
```

### 2. `scan_codebase`
Scans the codebase and builds the knowledge graph.

```
Claude: "Scan the current project"
→ Calls: scan_codebase(path=".")
```

### 3. `query_codebase`
Query dependencies, impact, or code structure using natural language.

```
Claude: "What does UserService depend on?"
→ Calls: query_codebase(query="what does UserService depend on")

Claude: "What breaks if I change the AuthService?"
→ Calls: query_codebase(query="what breaks if I change AuthService")

Claude: "Show all database models"
→ Calls: query_codebase(query="show all database models")
```

### 4. `get_codebase_status`
Check server status and statistics.

```
Claude: "What's the status of the code analysis?"
→ Calls: get_codebase_status(path=".")
```

## Example Workflows

### New Project Setup
```
User: "Help me understand this codebase"

Claude:
1. initialize_project(path=".") 
2. scan_codebase(path=".")
3. query_codebase(query="show all classes")
4. "This project has 15 classes including UserService, OrderService..."
```

### Refactoring Assistant
```
User: "I want to refactor the authentication system"

Claude:
1. query_codebase(query="what depends on AuthService")
2. "AuthService is used by 12 functions across 5 files..."
3. "The impact would be: UserController, AdminController..."
4. query_codebase(query="circular dependencies AuthService")
5. "No circular dependencies found - safe to refactor"
```

### Code Review
```
User: "Review this new feature"

Claude:
1. scan_codebase(path=".")  // Update graph with new code
2. query_codebase(query="most complex new functions")
3. "The new PaymentProcessor.charge() has complexity 15..."
4. query_codebase(query="does this introduce circular dependencies")
5. "No new circular dependencies detected"
```

## Token & Cost Efficiency

When agents need codebase context:

| Approach | Tokens | Cost* | Time |
|----------|--------|-------|------|
| Reading 50 files directly | ~20,000-40,000 | $0.03-$0.60 | 10-30s |
| Querying Dominian graph | ~500 | $0.001 | 0.5-2s |
| **Reduction** | **~95-99% fewer tokens** | **Significant savings** | **5-20x faster** |

*Based on GPT-4/Claude token pricing. Actual savings vary by project size and query frequency.*

## Troubleshooting

### "dominian-mcp command not found"
```bash
# Check installation
which dominian-mcp
# or
python -c "import mcp_server; print('OK')"

# Use full path in config
{
  "command": "python",
  "args": ["/full/path/to/mcp_server.py"]
}
```

### "Project not initialized"
Claude will prompt you to run `initialize_project` first. This is normal for new codebases.

### "Database not found"
The project needs to be scanned first. Claude will automatically run `scan_codebase` after initialization.

### MCP Connection Issues
1. Restart Claude Desktop after config changes
2. Check JSON syntax in config file
3. Ensure `mcp` package is installed: `pip install mcp`

## How It Works

```
┌─────────────┐     stdio      ┌─────────────┐     CLI commands     ┌─────────────┐
│   Claude    │ ◀────────────▶  │  MCP Server │ ◀─────────────────▶ │  Dominian   │
│   Desktop   │   MCP protocol   │  (stdio)    │   subprocess calls  │   CLI/API   │
└─────────────┘                  └─────────────┘                     └─────────────┘
                                                                          │
                                                                          ▼
                                                                    ┌─────────────┐
                                                                    │   SQLite    │
                                                                    │   Graph DB  │
                                                                    └─────────────┘
```

**Key Points:**
- Runs locally on your machine (no cloud hosting)
- Communicates via stdin/stdout (MCP protocol)
- Uses existing Dominian CLI commands
- No additional servers or ports needed

## Supported Agents

| Agent | Status | Notes |
|-------|--------|-------|
| **Claude Desktop** | ✅ Supported | Full MCP support |
| **Cursor** | ✅ Supported | MCP support added recently |
| **Windsurf** | ✅ Supported | Via Cascade |
| **Claude Code** | ✅ Supported | CLI-based, same protocol |
| **Other MCP clients** | ✅ Should work | Any MCP-compatible agent |

## Next Steps

1. Install: `pip install "dominian[mcp]"`
2. Configure Claude Desktop with the JSON above
3. Open a project in Claude
4. Ask: "Analyze this codebase for me"
5. Claude will auto-initialize and query Dominian

---

**Result:** Any MCP-compatible AI agent can now query your codebase with significantly fewer tokens vs. reading raw files.
