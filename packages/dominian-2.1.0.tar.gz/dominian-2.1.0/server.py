"""
AgentGraph Intelligence - FastAPI Server
REST + WebSocket API. Every agent connects here.
Auto-detects agent type. Serves optimized output per agent.
"""

import asyncio
import json
import os
import time
import uuid
from pathlib import Path
from typing import Optional, List, Dict, Any

from fastapi import FastAPI, WebSocket, WebSocketDisconnect, HTTPException, Query, Header, BackgroundTasks
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, PlainTextResponse
from pydantic import BaseModel

from database            import GraphDatabase
from __init__             import ParserRegistry, CodebaseScanner
from file_watcher         import FileWatcher
from engine               import QueryEngine
from formatter            import (
    format_for_agent, format_json,
    parse_writeback_commands, apply_writeback_commands,
    detect_agent_type,
)


# ─────────────────────────────────────────────────────────────────────────────
# App + global state
# ─────────────────────────────────────────────────────────────────────────────

app = FastAPI(
    title       = "Dominian",
    description = "Real-time codebase knowledge graph with HTTP API for AI agents. Multi-project support, live file watching, and natural language queries.",
    version     = "2.1.0",
    docs_url    = "/docs",
    redoc_url   = "/redoc",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins     = ["*"],
    allow_credentials = True,
    allow_methods     = ["*"],
    allow_headers     = ["*"],
)

# Singletons — initialized on startup
_db:      GraphDatabase  = None
_scanner: CodebaseScanner = None
_watcher: FileWatcher     = None
_query:   QueryEngine     = None
_registry: ParserRegistry = None

# WebSocket connection manager
_ws_clients: Dict[str, WebSocket] = {}


@app.on_event("startup")
async def startup():
    global _db, _scanner, _watcher, _query, _registry

    # Support multi-project via environment variable
    db_path = os.environ.get("DOMINIAN_DB", "agentgraph.db")
    _db       = GraphDatabase(db_path)
    _registry = ParserRegistry()
    _scanner  = CodebaseScanner(_db, _registry)
    _watcher  = FileWatcher(_db, _scanner)
    _query    = QueryEngine(_db)

    # Push live events to all WebSocket clients
    _watcher.add_listener(_broadcast_ws_event)


@app.on_event("shutdown")
async def shutdown():
    if _watcher:
        _watcher.stop()
    if _db:
        _db.close()


# ─────────────────────────────────────────────────────────────────────────────
# REQUEST MODELS
# ─────────────────────────────────────────────────────────────────────────────

class ScanRequest(BaseModel):
    path:        str
    watch:       bool = True      # auto-watch after scan

class QueryRequest(BaseModel):
    query:       str
    agent:       str = "universal"
    session_id:  str = "default"
    limit:       int = 25
    format:      str = "auto"    # auto | claude | universal | json

class WritebackRequest(BaseModel):
    commands:    str              # raw text containing GRAPH_UPDATE:: commands
    agent:       str = "universal"
    session_id:  str = "default"

class WatchRequest(BaseModel):
    path:        str

class NodeUpdateRequest(BaseModel):
    name:        str
    file:        str
    complexity:  Optional[int]   = None
    quality:     Optional[float] = None


# ─────────────────────────────────────────────────────────────────────────────
# SCAN ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/scan")
async def scan_codebase(req: ScanRequest, background_tasks: BackgroundTasks):
    """
    Scan a codebase directory. Parses all supported files, builds the graph.
    Optionally starts the file watcher for live updates.
    """
    path = Path(req.path)
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {req.path}")

    def _do_scan():
        result = _scanner.scan(str(path))
        if req.watch:
            _watcher.watch(str(path))
        return result

    # Run scan in background, return job ID
    job_id = str(uuid.uuid4())[:8]
    background_tasks.add_task(_do_scan)

    return {
        "status":  "scanning",
        "job_id":  job_id,
        "path":    str(path),
        "watch":   req.watch,
        "message": "Scan started. Subscribe to /ws for live progress.",
    }


@app.post("/scan/sync")
async def scan_codebase_sync(req: ScanRequest):
    """
    Synchronous scan. Waits for completion. Use for small codebases.
    """
    path = Path(req.path)
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {req.path}")

    loop   = asyncio.get_event_loop()
    result = await loop.run_in_executor(None, _scanner.scan, str(path))

    if req.watch:
        _watcher.watch(str(path))

    return result


@app.post("/watch")
async def start_watching(req: WatchRequest):
    """Start watching a directory for live graph updates."""
    path = Path(req.path)
    if not path.exists():
        raise HTTPException(status_code=404, detail=f"Path not found: {req.path}")
    _watcher.watch(str(path))
    return {"status": "watching", "path": str(path)}


@app.delete("/watch")
async def stop_watching():
    """Stop all file watchers."""
    _watcher.stop()
    return {"status": "stopped"}


# ─────────────────────────────────────────────────────────────────────────────
# QUERY ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/query")
async def query_get(
    q:          str = Query(..., description="Natural language query"),
    agent:      str = Query("universal"),
    session_id: str = Query("default"),
    limit:      int = Query(25),
    user_agent: Optional[str] = Header(None),
):
    """
    Query the knowledge graph. Natural language supported.
    Returns agent-optimized output.
    """
    # Auto-detect agent if not specified
    if agent == "universal" and user_agent:
        agent = detect_agent_type(user_agent)

    result     = _query.query(q, session_id=session_id, limit=limit)
    formatted  = format_for_agent(agent, result)

    if isinstance(formatted, str):
        return PlainTextResponse(formatted)
    return JSONResponse(formatted)


@app.post("/query")
async def query_post(
    req: QueryRequest,
    user_agent: Optional[str] = Header(None),
):
    """POST version of query for larger payloads."""
    agent = req.agent
    if agent == "universal" and user_agent:
        agent = detect_agent_type(user_agent)

    result    = _query.query(req.query, session_id=req.session_id, limit=req.limit)
    formatted = format_for_agent(agent, result)

    if isinstance(formatted, str):
        return PlainTextResponse(formatted)
    return JSONResponse(formatted)


# ─────────────────────────────────────────────────────────────────────────────
# NODE ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/node/{name}")
async def get_node(
    name:  str,
    file:  Optional[str] = None,
    agent: str = Query("universal"),
):
    """Get a specific node with all its connections."""
    node = _db.get_node(name, file)
    if not node:
        nodes = _db.search_nodes(name, limit=1)
        node  = nodes[0] if nodes else None
    if not node:
        raise HTTPException(status_code=404, detail=f"Node '{name}' not found")

    deps    = _db.get_dependencies(node["name"], node["file"])
    used_by = _db.get_dependents(node["name"],   node["file"])
    impact  = _db.get_impact(node["name"],        node["file"])

    result = {
        "query":      name,
        "intent":     "node_lookup",
        "entity":     name,
        "message":    f"Node: {node['name']} ({node['type']})",
        "focus":      node,
        "items":      [node],
        "deps":       deps,
        "used_by":    used_by,
        "impact":     impact,
        "count":      1,
        "latency_ms": 0,
    }
    formatted = format_for_agent(agent, result)
    if isinstance(formatted, str):
        return PlainTextResponse(formatted)
    return JSONResponse(formatted)


@app.get("/nodes")
async def list_nodes(
    type:     Optional[str] = None,
    file:     Optional[str] = None,
    language: Optional[str] = None,
    limit:    int = 100,
    agent:    str = Query("json"),
):
    """List all nodes, optionally filtered."""
    conn = _db._get_conn()
    conditions, params = [], []

    if type:
        conditions.append("type=?"); params.append(type)
    if file:
        conditions.append("file LIKE ?"); params.append(f"%{file}%")
    if language:
        conditions.append("language=?"); params.append(language)

    where  = f"WHERE {' AND '.join(conditions)}" if conditions else ""
    rows   = conn.execute(
        f"SELECT * FROM nodes {where} ORDER BY quality DESC LIMIT ?",
        params + [limit]
    ).fetchall()
    nodes  = [_db._row_to_dict(r) for r in rows]
    return JSONResponse({"nodes": nodes, "count": len(nodes)})


@app.get("/graph")
async def full_graph(format: str = Query("json")):
    """Export the full graph. JSON only."""
    conn  = _db._get_conn()
    nodes = [_db._row_to_dict(r) for r in conn.execute("SELECT * FROM nodes").fetchall()]
    edges = [dict(r) for r in conn.execute("SELECT * FROM edges").fetchall()]
    return JSONResponse({
        "nodes": nodes,
        "edges": edges,
        "stats": _db.get_stats(),
    })


# ─────────────────────────────────────────────────────────────────────────────
# WRITE-BACK ENDPOINT
# ─────────────────────────────────────────────────────────────────────────────

@app.post("/update")
async def agent_writeback(req: WritebackRequest):
    """
    Agent write-back: parse and apply GRAPH_UPDATE:: commands.
    Agents send their response text; we extract and execute all commands.
    """
    commands = parse_writeback_commands(req.commands)
    if not commands:
        return {"status": "ok", "commands_found": 0, "results": []}

    results  = apply_writeback_commands(_db, commands)
    ok_count = sum(1 for r in results if r["status"] == "ok")

    # Broadcast update to WebSocket clients
    _broadcast_ws_event({
        "type":      "agent_update",
        "agent":     req.agent,
        "session":   req.session_id,
        "commands":  len(commands),
        "applied":   ok_count,
        "timestamp": time.time(),
    })

    return {
        "status":          "ok",
        "commands_found":  len(commands),
        "commands_applied": ok_count,
        "results":         results,
    }


@app.patch("/node")
async def update_node_metrics(req: NodeUpdateRequest):
    """Directly update node metrics (quality, complexity)."""
    ok = _db.update_node_metrics(
        req.name, req.file,
        complexity = req.complexity,
        quality    = req.quality,
    )
    if not ok:
        raise HTTPException(status_code=404, detail=f"Node '{req.name}' not found")
    return {"status": "ok", "node": req.name}


# ─────────────────────────────────────────────────────────────────────────────
# ANALYTICS ENDPOINTS
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/stats")
async def get_stats():
    return JSONResponse(_db.get_stats())

@app.get("/hotspots")
async def get_hotspots(limit: int = Query(10), agent: str = Query("json")):
    hotspots = _db.get_hotspots(limit)
    result   = {
        "query": "hotspots", "intent": "hotspots", "entity": "",
        "message": f"Top {len(hotspots)} complexity hotspots",
        "items": hotspots, "count": len(hotspots), "latency_ms": 0,
    }
    formatted = format_for_agent(agent, result)
    if isinstance(formatted, str):
        return PlainTextResponse(formatted)
    return JSONResponse(formatted)

@app.get("/cycles")
async def get_cycles():
    cycles = _db.find_cycles()
    return JSONResponse({
        "cycles": cycles,
        "count": len(cycles),
        "message": f"{'No circular' if not cycles else len(cycles)} dependencies detected",
    })

@app.get("/orphans")
async def get_orphans():
    orphans = _db.get_orphans()
    return JSONResponse({"orphans": orphans, "count": len(orphans)})

@app.get("/impact/{name}")
async def get_impact(name: str, depth: int = Query(3), agent: str = Query("json")):
    node = _db.get_node(name)
    if not node:
        raise HTTPException(status_code=404, detail=f"Node '{name}' not found")
    impact   = _db.get_impact(name, node["file"], depth=depth)
    result   = {
        "query": f"impact of {name}", "intent": "impact", "entity": name,
        "message": f"Changing {name} affects {impact['affected_count']} nodes ({impact['risk_level']} risk)",
        "focus": node, "items": impact["affected_nodes"],
        "risk_level": impact["risk_level"], "count": impact["affected_count"],
        "latency_ms": 0,
    }
    formatted = format_for_agent(agent, result)
    if isinstance(formatted, str):
        return PlainTextResponse(formatted)
    return JSONResponse(formatted)

@app.get("/search")
async def search(
    q:     str = Query(...),
    limit: int = Query(20),
    agent: str = Query("json"),
):
    results = _db.search_nodes(q, limit=limit)
    return JSONResponse({"results": results, "count": len(results), "query": q})


# ─────────────────────────────────────────────────────────────────────────────
# WEBSOCKET - Live updates for agents
# ─────────────────────────────────────────────────────────────────────────────

@app.websocket("/ws")
async def websocket_endpoint(ws: WebSocket, session_id: str = "default"):
    """
    WebSocket for real-time graph updates.
    Agents subscribe here to receive instant notifications when code changes.
    """
    await ws.accept()
    client_id = str(uuid.uuid4())[:8]
    _ws_clients[client_id] = ws

    try:
        # Send initial stats on connect
        await ws.send_json({
            "type":      "connected",
            "client_id": client_id,
            "stats":     _db.get_stats(),
            "timestamp": time.time(),
        })

        # Keep connection alive, handle incoming messages
        while True:
            data = await ws.receive_text()
            try:
                msg = json.loads(data)
                if msg.get("type") == "query":
                    result    = _query.query(msg.get("query", ""), session_id=session_id)
                    agent     = msg.get("agent", "universal")
                    formatted = format_for_agent(agent, result)
                    if isinstance(formatted, str):
                        await ws.send_text(formatted)
                    else:
                        await ws.send_json(formatted)
                elif msg.get("type") == "ping":
                    await ws.send_json({"type": "pong", "timestamp": time.time()})
            except json.JSONDecodeError:
                # Plain text query
                result = _query.query(data, session_id=session_id)
                await ws.send_text(format_for_agent("universal", result))

    except WebSocketDisconnect:
        pass
    finally:
        _ws_clients.pop(client_id, None)


def _broadcast_ws_event(event: Dict):
    """Sync broadcast to all WebSocket clients. Called from file watcher thread."""
    if not _ws_clients:
        return
    dead = []
    for client_id, ws in list(_ws_clients.items()):
        try:
            asyncio.create_task(ws.send_json(event))
        except Exception:
            dead.append(client_id)
    for d in dead:
        _ws_clients.pop(d, None)


# ─────────────────────────────────────────────────────────────────────────────
# HEALTH
# ─────────────────────────────────────────────────────────────────────────────

@app.get("/health")
async def health():
    return {
        "status":    "ok",
        "version":   "2.0.0",
        "db":        str(_db.db_path) if _db else "not initialized",
        "watching":  list(_watcher.watching) if _watcher else [],
        "ws_clients": len(_ws_clients),
        "stats":     _db.get_stats() if _db else {},
        "uptime":    time.time(),
    }

@app.get("/")
async def root():
    return {
        "name":        "AgentGraph Intelligence",
        "version":     "2.0.0",
        "description": "The AI brain for every coding agent.",
        "docs":        "/docs",
        "endpoints": {
            "scan":      "POST /scan, POST /scan/sync",
            "query":     "GET /query?q=..., POST /query",
            "node":      "GET /node/{name}",
            "nodes":     "GET /nodes",
            "graph":     "GET /graph",
            "update":    "POST /update (agent write-back)",
            "hotspots":  "GET /hotspots",
            "cycles":    "GET /cycles",
            "orphans":   "GET /orphans",
            "impact":    "GET /impact/{name}",
            "search":    "GET /search?q=...",
            "stats":     "GET /stats",
            "ws":        "WS /ws",
        }
    }