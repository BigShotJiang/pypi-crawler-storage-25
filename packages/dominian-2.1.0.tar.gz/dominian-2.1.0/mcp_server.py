"""
Dominian MCP Server - Model Context Protocol integration for AI agents.

This exposes Dominian as an MCP tool, enabling any MCP-compatible agent
(Claude Desktop, Cursor, Windsurf, etc.) to query and analyze codebases.

Usage:
    1. Install: pip install mcp
    2. Run: python -m dominian.mcp_server
    3. Or: dominian-mcp (if installed via pip)

Configuration (Claude Desktop):
    Add to claude_desktop_config.json:
    {
      "mcpServers": {
        "dominian": {
          "command": "dominian-mcp"
        }
      }
    }
"""

import asyncio
import subprocess
import json
from pathlib import Path
from typing import Sequence

from mcp.server import Server
from mcp.types import (
    TextContent,
    Tool,
    ListToolsRequest,
    CallToolRequest,
)
from mcp.server.stdio import stdio_server

app = Server("dominian")


def _run_dominian_command(args: list, cwd: str = ".") -> tuple:
    """Execute dominian CLI command and return (stdout, stderr, returncode)."""
    try:
        result = subprocess.run(
            ["python", "-m", "main"] + args,
            cwd=cwd,
            capture_output=True,
            text=True,
            timeout=60,
        )
        return result.stdout, result.stderr, result.returncode
    except subprocess.TimeoutExpired:
        return "", "Command timed out", 1
    except Exception as e:
        return "", str(e), 1


@app.list_tools()
async def list_tools(request: ListToolsRequest) -> list[Tool]:
    """Define available tools for MCP clients."""
    return [
        Tool(
            name="query_codebase",
            description="Query the codebase knowledge graph for dependencies, impact analysis, or code structure. "
                       "Examples: 'what does UserService depend on', 'what breaks if I change AuthService', "
                       "'show all classes', 'find circular dependencies'",
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Natural language query about the codebase"
                    },
                    "path": {
                        "type": "string",
                        "description": "Path to the project directory (default: current)",
                        "default": "."
                    }
                },
                "required": ["query"]
            }
        ),
        Tool(
            name="scan_codebase",
            description="Scan a codebase and build/update the knowledge graph. "
                       "Use this first if no graph exists or after significant code changes.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the project to scan (default: current)",
                        "default": "."
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="get_codebase_status",
            description="Get status of the Dominian server and codebase statistics. "
                       "Shows if server is running, node count, and project info.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to the project (default: current)",
                        "default": "."
                    }
                },
                "required": []
            }
        ),
        Tool(
            name="initialize_project",
            description="Initialize a new project for Dominian analysis. "
                       "Creates .dominian/ folder with config and database.",
            inputSchema={
                "type": "object",
                "properties": {
                    "path": {
                        "type": "string",
                        "description": "Path to initialize (default: current)",
                        "default": "."
                    },
                    "port": {
                        "type": "integer",
                        "description": "Preferred port (auto-assigned if not available)",
                        "default": 8000
                    }
                },
                "required": []
            }
        ),
    ]


@app.call_tool()
async def call_tool(request: CallToolRequest) -> Sequence[TextContent]:
    """Handle tool execution from MCP clients."""
    tool_name = request.params.name
    arguments = request.params.arguments or {}
    
    path = arguments.get("path", ".")
    
    if tool_name == "query_codebase":
        query = arguments.get("query", "")
        if not query:
            return [TextContent(type="text", text="Error: query parameter is required")]
        
        stdout, stderr, rc = _run_dominian_command(["query", query, "--oneshot"], cwd=path)
        
        if rc != 0:
            # Try to initialize if project not set up
            if "Database not found" in stderr or "config" in stderr.lower():
                return [TextContent(
                    type="text", 
                    text=f"Project not initialized. Run 'initialize_project' first for path: {path}"
                )]
            return [TextContent(type="text", text=f"Error: {stderr or stdout}")]
        
        return [TextContent(type="text", text=stdout or "Query completed successfully")]
    
    elif tool_name == "scan_codebase":
        stdout, stderr, rc = _run_dominian_command(["scan", path, "--no-watch"], cwd=path)
        
        if rc != 0:
            return [TextContent(type="text", text=f"Scan error: {stderr or stdout}")]
        
        return [TextContent(type="text", text=stdout or "Scan completed successfully")]
    
    elif tool_name == "get_codebase_status":
        stdout, stderr, rc = _run_dominian_command(["status"], cwd=path)
        
        # Also try to get info
        stdout2, stderr2, rc2 = _run_dominian_command(["info"], cwd=path)
        
        combined = f"Status:\n{stdout}\n\nInfo:\n{stdout2}"
        return [TextContent(type="text", text=combined)]
    
    elif tool_name == "initialize_project":
        port = arguments.get("port", 8000)
        
        # First init
        stdout, stderr, rc = _run_dominian_command(["init", path], cwd=path)
        
        if rc != 0 and "already initialized" not in stderr.lower():
            return [TextContent(type="text", text=f"Init error: {stderr or stdout}")]
        
        # Then scan
        stdout2, stderr2, rc2 = _run_dominian_command(["scan", path, "--no-watch"], cwd=path)
        
        return [TextContent(
            type="text", 
            text=f"Project initialized and scanned.\n\nInit: {stdout}\n\nScan: {stdout2}"
        )]
    
    else:
        return [TextContent(type="text", text=f"Unknown tool: {tool_name}")]


async def main():
    """Run MCP server over stdio."""
    async with stdio_server() as streams:
        await app.run(
            streams[0],
            streams[1],
            app.create_initialization_options()
        )


if __name__ == "__main__":
    asyncio.run(main())
