"""
AgentGraph Intelligence - Main Entry Point
Single command to rule them all.

Usage:
    dominian init                            # Initialize project (.dominian/ folder)
    dominian serve                           # Start API server (auto-port, auto-db)
    dominian scan /path/to/project           # Scan a codebase
    dominian query "what does X depend on"   # Query (--oneshot skips server)
    dominian watch /path/to/project          # Watch without full scan
    dominian status                          # Show running projects / ports / PIDs
    dominian stop                            # Stop server for this project
"""

import os
import sys
import json
import signal
import socket
import time
import typer
import uvicorn
from pathlib import Path
from typing import Optional, List

from rich.console import Console
from rich.progress import Progress, SpinnerColumn, TextColumn, BarColumn, TaskProgressColumn
from rich.table   import Table
from rich.panel   import Panel
from rich         import print as rprint

# ── Try to import yaml; fall back to a tiny built-in writer/reader ────────────
try:
    import yaml as _yaml
    def _load_yaml(path: Path) -> dict:
        with open(path) as f:
            return _yaml.safe_load(f) or {}
    def _dump_yaml(data: dict, path: Path):
        with open(path, "w") as f:
            _yaml.dump(data, f, default_flow_style=False)
except ImportError:
    # Minimal YAML r/w for simple flat dicts (no PyYAML needed)
    def _load_yaml(path: Path) -> dict:          # noqa
        result = {}
        for line in path.read_text().splitlines():
            line = line.strip()
            if not line or line.startswith("#"):
                continue
            if ":" in line:
                k, _, v = line.partition(":")
                result[k.strip()] = v.strip()
        return result

    def _dump_yaml(data: dict, path: Path):      # noqa
        with open(path, "w") as f:
            for k, v in data.items():
                f.write(f"{k}: {v}\n")


# ─────────────────────────────────────────────────────────────────────────────
# Constants
# ─────────────────────────────────────────────────────────────────────────────

DOMINIAN_DIR   = ".dominian"
CONFIG_FILE    = "config.yaml"
PID_FILE       = "server.pid"
PORT_RANGE     = range(8000, 9001)
DEFAULT_DB     = "agentgraph.db"


# ─────────────────────────────────────────────────────────────────────────────
# Helpers
# ─────────────────────────────────────────────────────────────────────────────

def _find_dominian_dir(start: Path = None) -> Optional[Path]:
    """Walk up directory tree looking for .dominian/."""
    cur = (start or Path.cwd()).resolve()
    for parent in [cur, *cur.parents]:
        candidate = parent / DOMINIAN_DIR
        if candidate.is_dir():
            return candidate
    return None


def _require_dominian_dir() -> Path:
    d = _find_dominian_dir()
    if d is None:
        console.print(
            "[red]No .dominian/ found.[/red] Run [cyan]dominian init[/cyan] first."
        )
        raise typer.Exit(1)
    return d


def _load_config(dominian_dir: Path) -> dict:
    cfg_path = dominian_dir / CONFIG_FILE
    if cfg_path.exists():
        return _load_yaml(cfg_path)
    return {}


def _save_config(dominian_dir: Path, data: dict):
    _dump_yaml(data, dominian_dir / CONFIG_FILE)


def _is_port_free(port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
            return True
        except OSError:
            return False


def _find_free_port(preferred: int = None) -> int:
    """Return first free port in PORT_RANGE, preferred first."""
    candidates = list(PORT_RANGE)
    if preferred and preferred in candidates:
        candidates.remove(preferred)
        candidates.insert(0, preferred)
    for port in candidates:
        if _is_port_free(port):
            return port
    console.print("[red]No free port found in range 8000-9000.[/red]")
    raise typer.Exit(1)


def _port_owner(port: int) -> Optional[int]:
    """Return PID using the port, or None."""
    try:
        import psutil
        for conn in psutil.net_connections(kind="inet"):
            if conn.laddr.port == port and conn.status == "LISTEN":
                return conn.pid
    except Exception:
        pass
    return None


def _write_pid(dominian_dir: Path, pid: int, port: int):
    pid_path = dominian_dir / PID_FILE
    pid_path.write_text(json.dumps({"pid": pid, "port": port, "started": time.time()}))


def _read_pid(dominian_dir: Path) -> Optional[dict]:
    pid_path = dominian_dir / PID_FILE
    if not pid_path.exists():
        return None
    try:
        return json.loads(pid_path.read_text())
    except Exception:
        return None


def _clear_pid(dominian_dir: Path):
    pid_path = dominian_dir / PID_FILE
    pid_path.unlink(missing_ok=True)


def _is_pid_alive(pid: int) -> bool:
    try:
        import psutil
        return psutil.pid_exists(pid)
    except Exception:
        # Fallback for systems without psutil
        try:
            os.kill(pid, 0)
            return True
        except (ProcessLookupError, PermissionError, OSError):
            return False


def _banner():
    console.print(Panel.fit(
        "[bold cyan]AgentGraph Intelligence[/bold cyan] [dim]v2.1.0[/dim]\n"
        "[dim]Superior to Graphify. Built for AI agents.[/dim]",
        border_style="cyan",
    ))


# ─────────────────────────────────────────────────────────────────────────────
# CLI app
# ─────────────────────────────────────────────────────────────────────────────

app_cli = typer.Typer(
    name           = "dominian",
    help           = "AgentGraph Intelligence — The AI brain for every coding agent.",
    add_completion = False,
)
console = Console()


# ─────────────────────────────────────────────────────────────────────────────
# INIT
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def init(
    path: str = typer.Argument(".", help="Project root (default: current directory)"),
    port: Optional[int] = typer.Option(None, help="Preferred port (auto-assigned if omitted)"),
    db:   Optional[str] = typer.Option(None, "--db", help="Database file name"),
):
    """Initialize a Dominian project — creates .dominian/config.yaml."""
    _banner()
    root = Path(path).resolve()
    if not root.exists():
        console.print(f"[red]Path not found:[/red] {path}")
        raise typer.Exit(1)

    dominian_dir = root / DOMINIAN_DIR
    dominian_dir.mkdir(exist_ok=True)

    cfg_path = dominian_dir / CONFIG_FILE
    existing = _load_config(dominian_dir) if cfg_path.exists() else {}

    preferred  = port or int(existing.get("port", 8000))
    free_port  = _find_free_port(preferred)
    db_name    = db or existing.get("db", DEFAULT_DB)
    db_path    = str(dominian_dir / db_name)

    config = {
        "port":     free_port,
        "db":       db_path,
        "root":     str(root),
        "version":  "2.0.0",
    }
    _save_config(dominian_dir, config)

    # .gitignore entry
    gitignore = root / ".gitignore"
    gi_entry  = f"\n# Dominian\n{DOMINIAN_DIR}/\n"
    if gitignore.exists():
        content = gitignore.read_text()
        if DOMINIAN_DIR not in content:
            gitignore.write_text(content + gi_entry)
    else:
        gitignore.write_text(gi_entry)

    table = Table(title="Project Initialized", border_style="cyan")
    table.add_column("Setting", style="dim")
    table.add_column("Value",   style="cyan bold")
    table.add_row("Config dir", str(dominian_dir))
    table.add_row("Config file", str(cfg_path))
    table.add_row("Port",       str(free_port))
    table.add_row("Database",   db_path)
    table.add_row("Root",       str(root))
    console.print(table)
    console.print("\n[green]Done.[/green] Run [cyan]dominian serve[/cyan] to start.")


# ─────────────────────────────────────────────────────────────────────────────
# SERVE
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def serve(
    host:   str            = typer.Option("0.0.0.0", help="Host to bind"),
    port:   Optional[int]  = typer.Option(None,      help="Port (auto if omitted)"),
    reload: bool           = typer.Option(False,     help="Auto-reload on code changes"),
    db:     Optional[str]  = typer.Option(None,      "--db", help="Override database file"),
):
    """Start the AgentGraph API server (auto-detects .dominian/ config)."""
    _banner()

    dominian_dir = _find_dominian_dir()
    config       = _load_config(dominian_dir) if dominian_dir else {}

    # Port resolution: CLI > config > auto
    preferred_port = port or int(config.get("port", 8000))
    final_port     = preferred_port if _is_port_free(preferred_port) else None

    if final_port is None:
        owner = _port_owner(preferred_port)
        owner_msg = f" (PID {owner})" if owner else ""
        console.print(
            f"[yellow]Port {preferred_port} is busy{owner_msg}.[/yellow] "
            f"Finding next free port..."
        )
        final_port = _find_free_port()
        console.print(f"[green]Using port {final_port}.[/green]")

        # Persist the new port
        if dominian_dir:
            config["port"] = final_port
            _save_config(dominian_dir, config)

    # DB resolution: CLI > config > default
    db_path = db or config.get("db") or DEFAULT_DB
    os.environ["DOMINIAN_DB"] = db_path

    # Write PID file
    if dominian_dir:
        _write_pid(dominian_dir, os.getpid(), final_port)

    console.print(f"[green]Starting server[/green] on [cyan]http://{host}:{final_port}[/cyan]")
    console.print(f"[dim]API docs:   http://{host}:{final_port}/docs[/dim]")
    console.print(f"[dim]Database:   {db_path}[/dim]")
    if dominian_dir:
        console.print(f"[dim]Config dir: {dominian_dir}[/dim]")

    def _cleanup(sig=None, frame=None):
        if dominian_dir:
            _clear_pid(dominian_dir)
        sys.exit(0)

    signal.signal(signal.SIGINT,  _cleanup)
    signal.signal(signal.SIGTERM, _cleanup)

    try:
        uvicorn.run(
            "server:app",
            host       = host,
            port       = final_port,
            reload     = reload,
            workers    = 1,
            loop       = "asyncio",
            access_log = False,
            log_level  = "warning",
        )
    finally:
        _cleanup()


# ─────────────────────────────────────────────────────────────────────────────
# SCAN
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def scan(
    path:        str  = typer.Argument(...,  help="Path to the codebase to scan"),
    watch:       bool = typer.Option(True,   help="Watch for changes after scanning"),
    serve_after: bool = typer.Option(False,  "--serve", help="Start API server after scan"),
    port:        Optional[int] = typer.Option(None, help="Port (if --serve)"),
    db_path:     str  = typer.Option("",    "--db", help="Database file (auto from config if omitted)"),
):
    """Scan a codebase and build the knowledge graph."""
    from database        import GraphDatabase
    from __init__        import ParserRegistry, CodebaseScanner
    from file_watcher    import FileWatcher

    _banner()
    root = Path(path).resolve()
    if not root.exists():
        console.print(f"[red]Path not found:[/red] {path}")
        raise typer.Exit(1)

    # Resolve DB: explicit > config > default
    dominian_dir = _find_dominian_dir(root)
    config       = _load_config(dominian_dir) if dominian_dir else {}
    resolved_db  = db_path or config.get("db") or DEFAULT_DB

    db       = GraphDatabase(resolved_db)
    registry = ParserRegistry()

    with Progress(
        SpinnerColumn(),
        TextColumn("[progress.description]{task.description}"),
        BarColumn(),
        TaskProgressColumn(),
        console=console,
    ) as progress:
        files = CodebaseScanner(db, registry)._collect_files(root)
        total = len(files)
        task  = progress.add_task(f"[cyan]Scanning {total} files...[/cyan]", total=total)

        def on_file(file_path):
            progress.update(task, advance=1,
                            description=f"[cyan]{Path(file_path).name}[/cyan]")

        scanner = CodebaseScanner(db, registry, on_file_scanned=on_file)
        t0      = time.perf_counter()
        result  = scanner.scan(str(root))
        elapsed = time.perf_counter() - t0

    table = Table(title="Scan Complete", border_style="cyan")
    table.add_column("Metric", style="dim")
    table.add_column("Value",  style="cyan bold")
    table.add_row("Files scanned", str(result["files"]))
    table.add_row("Nodes found",   str(result["nodes"]))
    table.add_row("Edges mapped",  str(result["edges"]))
    table.add_row("Parse errors",  str(result["errors"]))
    table.add_row("Duration",      f"{elapsed:.2f}s")
    table.add_row("Speed",         f"{result.get('files_per_s', 0):.0f} files/sec")
    table.add_row("Database",      resolved_db)
    console.print(table)

    if watch:
        watcher = FileWatcher(db, scanner)
        watcher.watch(str(root))
        console.print(f"\n[green]Watching[/green] {root} for changes...")

    if serve_after:
        dominian_dir2 = _find_dominian_dir(root)
        cfg2          = _load_config(dominian_dir2) if dominian_dir2 else {}
        preferred     = port or int(cfg2.get("port", 8000))
        final_port    = preferred if _is_port_free(preferred) else _find_free_port()
        os.environ["DOMINIAN_DB"] = resolved_db
        console.print(f"\n[green]Starting API server on port {final_port}...[/green]")
        uvicorn.run("server:app", port=final_port, log_level="warning")
    elif watch:
        console.print("[dim]Press Ctrl+C to stop.[/dim]")
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            watcher.stop()
            console.print("\n[yellow]Stopped.[/yellow]")

    db.close()


# ─────────────────────────────────────────────────────────────────────────────
# WATCH  (without initial full scan)
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def watch(
    path:    str  = typer.Argument(..., help="Path to the codebase to watch"),
    db_path: str  = typer.Option("", "--db", help="Database file (auto from config if omitted)"),
):
    """Watch files for changes without initial full scan."""
    from database        import GraphDatabase
    from __init__        import ParserRegistry, CodebaseScanner
    from file_watcher    import FileWatcher

    _banner()
    root = Path(path).resolve()
    if not root.exists():
        console.print(f"[red]Path not found:[/red] {path}")
        raise typer.Exit(1)

    # Resolve DB: explicit > config > default
    dominian_dir = _find_dominian_dir(root)
    config       = _load_config(dominian_dir) if dominian_dir else {}
    resolved_db  = db_path or config.get("db") or DEFAULT_DB

    if not Path(resolved_db).exists():
        console.print(
            f"[yellow]Database not found:[/yellow] {resolved_db}\n"
            "[dim]Run [cyan]dominian scan[/cyan] first, or watching may be limited.[/dim]"
        )

    db       = GraphDatabase(resolved_db)
    registry = ParserRegistry()
    scanner  = CodebaseScanner(db, registry)
    watcher  = FileWatcher(db, scanner)

    watcher.watch(str(root))
    console.print(f"[green]Watching[/green] {root} for changes...")
    console.print(f"[dim]Database: {resolved_db}[/dim]")
    console.print("[dim]Press Ctrl+C to stop.[/dim]")

    try:
        while True:
            time.sleep(1)
    except KeyboardInterrupt:
        watcher.stop()
        console.print("\n[yellow]Stopped.[/yellow]")

    db.close()


# ─────────────────────────────────────────────────────────────────────────────
# QUERY  (with --oneshot mode)
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def query(
    q:       str = typer.Argument(..., help="Natural language query"),
    agent:   str = typer.Option("claude", help="Agent type (claude|universal|json)"),
    db:      str = typer.Option("",       help="Database file (auto from config if omitted)"),
    oneshot: bool = typer.Option(False,   "--oneshot", help="Query without a running server"),
    server:  str = typer.Option("",       "--server",  help="Server URL for live query (default: from config)"),
):
    """Query the knowledge graph. Use --oneshot to skip the server entirely."""
    _banner()

    # ── oneshot: direct DB query, no HTTP ─────────────────────────
    if oneshot:
        dominian_dir = _find_dominian_dir()
        config       = _load_config(dominian_dir) if dominian_dir else {}
        resolved_db  = db or config.get("db") or DEFAULT_DB

        if not Path(resolved_db).exists():
            console.print(
                f"[red]Database not found:[/red] {resolved_db}\n"
                "[dim]Run [cyan]dominian scan[/cyan] first.[/dim]"
            )
            raise typer.Exit(1)

        from database    import GraphDatabase
        from engine      import QueryEngine
        from formatter   import format_for_claude, format_universal, format_json

        database = GraphDatabase(resolved_db)
        engine   = QueryEngine(database)
        result   = engine.query(q)

        if agent == "claude":
            output = format_for_claude(result)
        elif agent == "json":
            import json as _json
            output = _json.dumps(format_json(result), indent=2)
        else:
            output = format_universal(result)

        console.print(Panel(output, title=f"[cyan]{q}[/cyan]", border_style="cyan"))
        database.close()
        return

    # ── live query via HTTP ────────────────────────────────────────
    try:
        import httpx
    except ImportError:
        console.print(
            "[red]httpx not installed.[/red] Run: [cyan]pip install httpx[/cyan]\n"
            "[dim]Or use --oneshot to query database directly.[/dim]"
        )
        raise typer.Exit(1)
    dominian_dir = _find_dominian_dir()
    config       = _load_config(dominian_dir) if dominian_dir else {}
    base_url     = server or f"http://localhost:{config.get('port', 8000)}"

    try:
        resp = httpx.get(f"{base_url}/query", params={"q": q, "agent": agent}, timeout=10)
        resp.raise_for_status()
        console.print(Panel(resp.text, title=f"[cyan]{q}[/cyan]", border_style="cyan"))
    except httpx.ConnectError:
        console.print(
            f"[red]Cannot connect to server at {base_url}.[/red]\n"
            "[dim]Start it with [cyan]dominian serve[/cyan] "
            "or use [cyan]--oneshot[/cyan] to query directly.[/dim]"
        )
        raise typer.Exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# STATUS
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def status():
    """Show all running Dominian servers and their projects."""
    _banner()

    # Scan all .dominian/ dirs under home and cwd
    search_roots = [Path.cwd(), Path.home()]
    checked: set = set()
    rows: list   = []

    def _check_dir(dominian_dir: Path):
        if dominian_dir in checked:
            return
        checked.add(dominian_dir)
        config   = _load_config(dominian_dir)
        pid_info = _read_pid(dominian_dir)
        project  = config.get("root", str(dominian_dir.parent))
        port     = config.get("port", "?")
        db       = config.get("db", "?")

        if pid_info:
            pid     = int(pid_info["pid"])
            p_port  = pid_info.get("port", port)
            alive   = _is_pid_alive(pid)
            if not alive:
                _clear_pid(dominian_dir)
                state = "[dim]stopped[/dim]"
                pid_str = "—"
            else:
                state   = "[green]running[/green]"
                pid_str = str(pid)
        else:
            state   = "[dim]stopped[/dim]"
            pid_str = "—"
            p_port  = port

        rows.append((project, str(p_port), pid_str, state, str(db)))

    # Walk cwd parents
    cur = Path.cwd().resolve()
    for parent in [cur, *cur.parents]:
        d = parent / DOMINIAN_DIR
        if d.is_dir():
            _check_dir(d)

    # Walk home subdirectories (shallow)
    try:
        for child in Path.home().iterdir():
            if child.is_dir():
                d = child / DOMINIAN_DIR
                if d.is_dir():
                    _check_dir(d)
    except PermissionError:
        pass

    if not rows:
        console.print("[dim]No Dominian projects found.[/dim]")
        console.print("Run [cyan]dominian init[/cyan] to initialize one.")
        return

    table = Table(title="Dominian Projects", border_style="cyan")
    table.add_column("Project",  style="cyan")
    table.add_column("Port")
    table.add_column("PID")
    table.add_column("Status")
    table.add_column("Database", style="dim")
    for row in rows:
        table.add_row(*row)
    console.print(table)


# ─────────────────────────────────────────────────────────────────────────────
# STOP
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def stop(
    path: str = typer.Argument(".", help="Project root (default: current directory)"),
    force: bool = typer.Option(False, "--force", "-f", help="SIGKILL instead of SIGTERM"),
):
    """Stop the Dominian server for this project."""
    _banner()

    dominian_dir = _find_dominian_dir(Path(path).resolve())
    if dominian_dir is None:
        console.print("[red]No .dominian/ found.[/red] Nothing to stop.")
        raise typer.Exit(1)

    pid_info = _read_pid(dominian_dir)
    if not pid_info:
        console.print("[yellow]No server PID recorded.[/yellow] Server may not be running.")
        raise typer.Exit(0)

    pid  = int(pid_info["pid"])
    port = pid_info.get("port", "?")

    if not _is_pid_alive(pid):
        console.print(f"[yellow]PID {pid} is not running.[/yellow] Cleaning up stale PID file.")
        _clear_pid(dominian_dir)
        raise typer.Exit(0)

    sig = signal.SIGKILL if force else signal.SIGTERM
    try:
        os.kill(pid, sig)
        time.sleep(0.5)
        if _is_pid_alive(pid) and not force:
            console.print(f"[yellow]PID {pid} still alive after SIGTERM. Use --force to SIGKILL.[/yellow]")
        else:
            _clear_pid(dominian_dir)
            console.print(f"[green]Stopped[/green] server (PID {pid}, port {port}).")
    except PermissionError:
        console.print(f"[red]Permission denied stopping PID {pid}.[/red] Try with sudo.")
        raise typer.Exit(1)


# ─────────────────────────────────────────────────────────────────────────────
# INFO  (unchanged, wired to config-aware db)
# ─────────────────────────────────────────────────────────────────────────────

@app_cli.command()
def info(
    db: str = typer.Option("", help="Database file (auto from config if omitted)"),
):
    """Show codebase stats from the current graph database."""
    from database import GraphDatabase

    _banner()
    dominian_dir = _find_dominian_dir()
    config       = _load_config(dominian_dir) if dominian_dir else {}
    resolved_db  = db or config.get("db") or DEFAULT_DB

    if not Path(resolved_db).exists():
        console.print(f"[red]Database not found:[/red] {resolved_db}")
        raise typer.Exit(1)

    database = GraphDatabase(resolved_db)
    stats    = database.get_stats()
    hotspots = database.get_hotspots(5)
    cycles   = database.find_cycles()

    table = Table(title="Knowledge Graph Stats", border_style="cyan")
    table.add_column("Metric"); table.add_column("Value", style="cyan bold")
    table.add_row("Total nodes",    str(stats["nodes"]))
    table.add_row("Total edges",    str(stats["edges"]))
    table.add_row("Avg quality",    f"{stats['avg_quality']}%")
    table.add_row("Avg complexity", str(stats["avg_complexity"]))
    table.add_row("Circular deps",  str(len(cycles)))
    table.add_row("Cache hit rate", f"{stats['cache_hit_rate']}%")
    table.add_row("Database",       resolved_db)
    console.print(table)

    if stats.get("languages"):
        lang_table = Table(title="Languages", border_style="dim")
        lang_table.add_column("Language"); lang_table.add_column("Nodes", style="cyan")
        for lang, count in stats["languages"].items():
            lang_table.add_row(lang, str(count))
        console.print(lang_table)

    if hotspots:
        hs_table = Table(title="Top Complexity Hotspots", border_style="yellow")
        hs_table.add_column("Name"); hs_table.add_column("Type")
        hs_table.add_column("Complexity", style="yellow")
        hs_table.add_column("Quality",    style="cyan")
        hs_table.add_column("File",       style="dim")
        for h in hotspots:
            hs_table.add_row(
                h["name"], h["type"],
                str(h["complexity"]), f"{h['quality']:.0f}%",
                h["file"]
            )
        console.print(hs_table)

    database.close()


# ─────────────────────────────────────────────────────────────────────────────
# Entry point
# ─────────────────────────────────────────────────────────────────────────────

def main():
    app_cli()

if __name__ == "__main__":
    main()