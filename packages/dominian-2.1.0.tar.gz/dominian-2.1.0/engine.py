"""
AgentGraph Intelligence - Query Engine
Resolves natural language and structured queries against the graph.
"""

import re
import time
from typing import Dict, Any, List, Optional, Tuple


INTENT_PATTERNS = [
    # Impact
    (re.compile(r'\b(what|what\'s|whats)\s+(breaks?|is affected|changes?)\s+(?:if|when)\s+(?:i\s+)?(?:change|modify|edit|update|delete|remove)\s+(.+)', re.I), "impact"),
    (re.compile(r'\b(impact|blast radius|affects?)\s+(?:of\s+)?(.+)', re.I), "impact"),

    # Dependencies
    (re.compile(r'\bwhat\s+does\s+(.+?)\s+(?:depend|use|call|import|need|require)\b', re.I), "dependencies"),
    (re.compile(r'\b(?:depends?|uses?|imports?|calls?)\s+(?:of|by|in)\s+(.+)', re.I), "dependencies"),
    (re.compile(r'\b(.+?)\s+depends?\s+on\b', re.I), "dependencies"),

    # Dependents
    (re.compile(r'\bwho\s+(?:uses?|calls?|imports?|depends?\s+on|needs?)\s+(.+)', re.I), "dependents"),
    (re.compile(r'\bwhat\s+(?:uses?|calls?|imports?|depends?\s+on)\s+(.+)', re.I), "dependents"),
    (re.compile(r'\b(.+?)\s+is\s+used\s+by\b', re.I), "dependents"),

    # Cycles
    (re.compile(r'\b(circular|cycle|cycl(?:es|ic))\b', re.I), "cycles"),

    # Analytics — god nodes
    (re.compile(r'\b(god\s+nodes?|god-node|most\s+connected|highest\s+degree|hub)\b', re.I), "god_nodes"),
    (re.compile(r'\b(central|centrality|connector)\b', re.I), "god_nodes"),

    # Analytics — communities
    (re.compile(r'\b(communit(?:y|ies)|cluster|module\s+group)\b', re.I), "communities"),

    # Analytics — surprising connections
    (re.compile(r'\b(surprising|unexpected|cross.communit|architectural\s+anomal)\b', re.I), "surprising"),

    # Hotspots
    (re.compile(r'\b(hotspots?|most\s+complex|highest\s+complexity|problematic)\b', re.I), "hotspots"),
    (re.compile(r'\b(worst|bad|risky|dangerous)\s+(?:code|files?|nodes?|functions?|classes?)\b', re.I), "hotspots"),

    # Quality
    (re.compile(r'\b(low.?quality|poor\s+quality|lowest\s+quality)\b', re.I), "low_quality"),
    (re.compile(r'\b(best|highest)\s+quality\b', re.I), "high_quality"),

    # By type
    (re.compile(r'\ball\s+(classes|functions|methods|modules|interfaces|structs|traits|enums)\b', re.I), "by_type"),
    (re.compile(r'\b(?:show|list|find|get)\s+(?:all\s+)?(classes|functions|methods|structs|traits|enums)\b', re.I), "by_type"),

    # By file
    (re.compile(r'\b(?:in|from|inside)\s+(?:file\s+)?["\']?([/\w.\-]+\.\w+)["\']?\b', re.I), "by_file"),

    # Orphans
    (re.compile(r'\b(orphans?|unused|dead\s+code|unreferenced|isolated)\b', re.I), "orphans"),

    # Stats
    (re.compile(r'\b(stats?|statistics|overview|summary|report|analyze|analysis)\b', re.I), "stats"),

    # Node lookup — must be last
    (re.compile(r'\b(?:show|find|get|describe|explain|what\s+is|tell\s+me\s+about)\s+(.+)', re.I), "node_lookup"),
    (re.compile(r'^(.+)$', re.I), "node_lookup"),
]

TYPE_MAP = {
    "classes": "class", "class": "class",
    "functions": "function", "function": "function",
    "methods": "method", "method": "method",
    "modules": "module", "module": "module",
    "interfaces": "interface", "interface": "interface",
    "structs": "class",   # Go/Rust structs map to class
    "struct": "class",
    "traits": "interface",  # Rust traits map to interface
    "trait": "interface",
    "enums": "variable", "enum": "variable",
    "variables": "variable", "variable": "variable",
    "dependencies": "dependency", "dependency": "dependency",
}


class QueryEngine:
    def __init__(self, db):
        self.db = db

    def query(self, raw: str, session_id: str = "default", limit: int = 25) -> Dict[str, Any]:
        t0     = time.perf_counter()
        raw    = raw.strip()
        intent, entity = self._detect_intent(raw)
        result = self._resolve(intent, entity, limit)
        latency = (time.perf_counter() - t0) * 1000

        self.db.log_query(
            session_id=session_id, raw_query=raw,
            resolved=f"{intent}:{entity}",
            result_count=len(result.get("items", [])),
            latency_ms=round(latency, 3),
        )

        return {"query": raw, "intent": intent, "entity": entity,
                "latency_ms": round(latency, 3), **result}

    def _detect_intent(self, raw: str) -> Tuple[str, str]:
        raw_clean = raw.strip().rstrip("?.")
        for pattern, intent in INTENT_PATTERNS:
            m = pattern.search(raw_clean)
            if m:
                groups = [g for g in m.groups() if g]
                entity = groups[-1].strip() if groups else ""
                return intent, entity
        return "node_lookup", raw_clean

    def _resolve(self, intent: str, entity: str, limit: int) -> Dict[str, Any]:
        dispatch = {
            "dependencies": self._resolve_dependencies,
            "dependents":   self._resolve_dependents,
            "impact":       self._resolve_impact,
            "cycles":       lambda e: self._resolve_cycles(),
            "hotspots":     lambda e: self._resolve_hotspots(),
            "low_quality":  lambda e: self._resolve_quality("low", limit),
            "high_quality": lambda e: self._resolve_quality("high", limit),
            "by_type":      lambda e: self._resolve_by_type(e, limit),
            "by_file":      self._resolve_by_file,
            "orphans":      lambda e: self._resolve_orphans(),
            "stats":        lambda e: self._resolve_stats(),
            "god_nodes":    lambda e: self._resolve_god_nodes(limit),
            "communities":  lambda e: self._resolve_communities(),
            "surprising":   lambda e: self._resolve_surprising(),
        }
        fn = dispatch.get(intent)
        if fn:
            return fn(entity)
        return self._resolve_node_lookup(entity, limit)

    # ── Resolvers ─────────────────────────────────────────────────

    def _resolve_dependencies(self, entity: str) -> Dict:
        node = self._find_node(entity)
        if not node:
            return {"items": [], "message": f"Node '{entity}' not found"}
        deps = self.db.get_dependencies(node["name"], node["file"])
        return {"focus": node, "items": deps, "count": len(deps),
                "message": f"{node['name']} depends on {len(deps)} nodes"}

    def _resolve_dependents(self, entity: str) -> Dict:
        node = self._find_node(entity)
        if not node:
            return {"items": [], "message": f"Node '{entity}' not found"}
        used_by = self.db.get_dependents(node["name"], node["file"])
        return {"focus": node, "items": used_by, "count": len(used_by),
                "message": f"{node['name']} is used by {len(used_by)} nodes"}

    def _resolve_impact(self, entity: str) -> Dict:
        node = self._find_node(entity)
        if not node:
            return {"items": [], "message": f"Node '{entity}' not found"}
        impact = self.db.get_impact(node["name"], node["file"])
        return {
            "focus": node, "items": impact["affected_nodes"],
            "count": impact["affected_count"], "risk_level": impact["risk_level"],
            "message": f"Changing {node['name']} affects {impact['affected_count']} nodes ({impact['risk_level']} risk)",
        }

    def _resolve_cycles(self) -> Dict:
        cycles = self.db.find_cycles()
        return {"items": cycles, "count": len(cycles),
                "message": f"Found {len(cycles)} circular dependencies" if cycles else "No circular dependencies"}

    def _resolve_hotspots(self, limit: int = 10) -> Dict:
        hotspots = self.db.get_hotspots(limit)
        return {"items": hotspots, "count": len(hotspots),
                "message": f"Top {len(hotspots)} complexity hotspots"}

    def _resolve_quality(self, direction: str, limit: int) -> Dict:
        order = "ASC" if direction == "low" else "DESC"
        rows  = self.db._get_conn().execute(
            f"SELECT * FROM nodes WHERE type NOT IN ('dependency','module') "
            f"ORDER BY quality {order} LIMIT ?", (limit,)
        ).fetchall()
        items = [self.db._row_to_dict(r) for r in rows]
        label = "lowest" if direction == "low" else "highest"
        return {"items": items, "count": len(items),
                "message": f"Nodes with {label} quality scores"}

    def _resolve_by_type(self, entity: str, limit: int) -> Dict:
        key = TYPE_MAP.get(entity.lower().rstrip("s")) or \
              TYPE_MAP.get(entity.lower()) or entity.lower().rstrip("s")
        items = self.db.get_nodes_by_type(key)[:limit]
        return {"items": items, "count": len(items), "message": f"Found {len(items)} {key}s"}

    def _resolve_by_file(self, entity: str) -> Dict:
        items = self.db.get_nodes_by_file(entity)
        if not items:
            rows  = self.db._get_conn().execute(
                "SELECT * FROM nodes WHERE file LIKE ? ORDER BY line_start",
                (f"%{entity}%",)
            ).fetchall()
            items = [self.db._row_to_dict(r) for r in rows]
        return {"items": items, "count": len(items),
                "message": f"Found {len(items)} nodes in '{entity}'"}

    def _resolve_orphans(self) -> Dict:
        orphans = self.db.get_orphans()
        return {"items": orphans, "count": len(orphans),
                "message": f"Found {len(orphans)} orphaned nodes (no connections)"}

    def _resolve_stats(self) -> Dict:
        stats = self.db.get_stats()
        return {"items": [], "stats": stats,
                "message": f"Codebase: {stats['nodes']} nodes, {stats['edges']} edges"}

    def _resolve_god_nodes(self, limit: int = 10) -> Dict:
        """God nodes — highest degree, most connected."""
        god_nodes = self.db.find_god_nodes(limit)

        # Try NetworkX for richer results
        try:
            from analytics import GraphAnalytics
            nx_god = GraphAnalytics(self.db).find_god_nodes_nx(limit)
            if nx_god:
                god_nodes = nx_god
        except Exception:
            pass

        return {
            "items": god_nodes, "count": len(god_nodes),
            "message": f"Found {len(god_nodes)} god nodes (highest connectivity)",
        }

    def _resolve_communities(self) -> Dict:
        try:
            from analytics import GraphAnalytics
            communities = GraphAnalytics(self.db).detect_communities()
            comm_map: Dict[int, List[str]] = {}
            for node_id, comm_id in communities.items():
                comm_map.setdefault(comm_id, []).append(node_id)

            items = [
                {"community_id": cid, "size": len(members),
                 "members": members[:5], "total": len(members)}
                for cid, members in sorted(comm_map.items(), key=lambda x: -len(x[1]))
            ]
            return {
                "items": items, "count": len(items),
                "message": f"Detected {len(items)} communities",
                "raw_communities": communities,
            }
        except ImportError:
            return {"items": [], "count": 0,
                    "message": "Install networkx for community detection: pip install networkx"}

    def _resolve_surprising(self) -> Dict:
        try:
            from analytics import GraphAnalytics
            edges = GraphAnalytics(self.db).find_cross_community_edges()
        except Exception:
            edges = self.db.find_surprising_connections()

        return {
            "items": edges, "count": len(edges),
            "message": f"Found {len(edges)} surprising cross-community connections",
        }

    def _resolve_node_lookup(self, entity: str, limit: int) -> Dict:
        node = self.db.get_node(entity)
        if node:
            deps    = self.db.get_dependencies(node["name"], node["file"])
            used_by = self.db.get_dependents(node["name"], node["file"])
            impact  = self.db.get_impact(node["name"], node["file"])
            return {
                "focus": node, "items": [node],
                "deps": deps, "used_by": used_by, "impact": impact,
                "count": 1, "message": f"Found {node['name']} ({node['type']}) in {node['file']}",
            }
        results = self.db.search_nodes(entity, limit=limit)
        if results:
            return {"items": results, "count": len(results),
                    "message": f"Found {len(results)} matches for '{entity}'"}
        return {"items": [], "count": 0, "message": f"No results found for '{entity}'"}

    def _find_node(self, entity: str):
        node = self.db.get_node(entity)
        if not node:
            results = self.db.search_nodes(entity, limit=1)
            node = results[0] if results else None
        return node