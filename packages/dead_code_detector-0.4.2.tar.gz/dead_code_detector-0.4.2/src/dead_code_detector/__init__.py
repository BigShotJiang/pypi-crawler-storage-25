"""Dead code detector — find unused routines in Python codebases."""

from __future__ import annotations

from .cli import main

__all__ = ["main"]
