"""Allow running as `python -m dead_code_detector`."""

from __future__ import annotations

from .cli import main

main()
