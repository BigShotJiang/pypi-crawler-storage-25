"""CLI interface for dead code detector."""

from __future__ import annotations

import argparse
import pathlib
import sys
from typing import TYPE_CHECKING

from .ast_analyzer import analyze_references
from .discovery import import_entry_points
from .graph import build_graph_and_analyze
from .indexer import index_modules
from .reporter import (
    report_flat,
    report_json,
    report_stats,
    report_usage,
    report_verbose,
)

if TYPE_CHECKING:
    from types import ModuleType

    from .models import AnalysisResult


def main(argv: list[str] | None = None) -> None:
    """Entry point for the dead-code-detector CLI."""
    args = _parse_args(argv)

    modules = _discover_modules(args.entry_points, args.src_dir, args.exclude)
    result = _analyze(
        modules, args.entry_points, args.include_dunders, args.live_decorators
    )
    text = _format_output(result, args.format, args.verbose, args.stats, args.usage)
    _emit_output(text, args.output)

    if args.exit_code and result.dead:
        sys.exit(1)


def _parse_args(argv: list[str] | None) -> argparse.Namespace:
    """Parse command-line arguments."""
    parser = argparse.ArgumentParser(
        prog="dead-code-detector",
        description="Detect unused routines in a Python codebase.",
    )
    parser.add_argument(
        "entry_points",
        nargs="+",
        metavar="ENTRY_POINT",
        help="One or more module paths (e.g. myapp.main myapp.cli).",
    )
    parser.add_argument(
        "--src-dir",
        default="",
        help="Root directory for source discovery.",
    )
    parser.add_argument(
        "-v",
        "--verbose",
        action="store_true",
        help="Show detailed output.",
    )
    parser.add_argument(
        "--stats",
        action="store_true",
        help="Show per-module coverage statistics.",
    )
    parser.add_argument(
        "--usage",
        action="store_true",
        help="Show usage map: all definitions with their call paths.",
    )
    parser.add_argument(
        "--format",
        choices=["text", "json"],
        default="text",
        help="Output format (default: text).",
    )
    parser.add_argument(
        "--exclude",
        action="append",
        default=[],
        help="Module patterns to exclude (repeatable).",
    )
    parser.add_argument(
        "--include-dunders",
        action="store_true",
        help="Report unreachable dunder methods.",
    )
    parser.add_argument(
        "--live-decorators",
        action="store_true",
        help="Treat all decorated definitions as live (reachable).",
    )
    parser.add_argument(
        "-o",
        "--output",
        help="Write output to file.",
    )
    parser.add_argument(
        "--exit-code",
        action="store_true",
        help="Exit with code 1 if dead code is found.",
    )
    return parser.parse_args(argv)


def _discover_modules(
    entry_points: list[str],
    src_dir: str,
    exclude: list[str],
) -> dict[str, ModuleType]:
    """Import entry points and discover project modules."""
    try:
        modules = import_entry_points(entry_points, src_dir=src_dir)
    except ImportError as e:
        print(f"Error importing entry point: {e}", file=sys.stderr)
        sys.exit(2)

    if not modules:
        print(
            "No modules found for the given entry points.",
            file=sys.stderr,
        )
        sys.exit(2)

    if exclude:
        modules = {
            name: mod
            for name, mod in modules.items()
            if not any(pat in name for pat in exclude)
        }
    return modules


def _analyze(
    modules: dict[str, ModuleType],
    entry_points: list[str],
    include_dunders: bool,
    live_decorators: bool = False,
) -> AnalysisResult:
    """Run the full analysis pipeline."""
    definitions = index_modules(modules)
    if not definitions:
        print(
            "No definitions found in the discovered modules.",
            file=sys.stderr,
        )
        sys.exit(2)

    references = analyze_references(modules, definitions)
    return build_graph_and_analyze(
        definitions,
        references,
        entry_points,
        include_dunders=include_dunders,
        live_decorators=live_decorators,
    )


def _format_output(
    result: AnalysisResult,
    output_format: str,
    verbose: bool,
    stats: bool,
    usage: bool,
) -> str:
    """Format the analysis result for output."""
    if output_format == "json":
        return report_json(result)
    if usage:
        return report_usage(result)
    if verbose:
        text = report_verbose(result)
    elif stats:
        return report_stats(result)
    else:
        text = report_flat(result)

    if stats:
        text += "\n" + report_stats(result)
    return text


def _emit_output(text: str, output: str | None) -> None:
    """Write output to file or stdout."""
    if output:
        pathlib.Path(output).write_text(text, encoding="utf-8")
        print(f"Output written to {output}", file=sys.stderr)
    else:
        sys.stdout.write(text)
