"""Module discovery via runtime import."""

from __future__ import annotations

import importlib
import sys
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from types import ModuleType


def import_entry_points(
    entry_points: list[str],
    src_dir: str = "",
) -> dict[str, ModuleType]:
    """Import entry point modules and return all discovered project modules.

    Args:
        entry_points: Module paths to import (e.g. ["myapp.main", "myapp.cli"]).
        src_dir: Optional source directory to add to sys.path.

    Returns:
        Dict mapping module name to module object, for all modules
        belonging to the entry point packages.
    """
    if src_dir:
        src_path = str(Path(src_dir).resolve())
        if src_path not in sys.path:
            sys.path.insert(0, src_path)

    package_prefixes = _extract_package_prefixes(entry_points)

    for ep in entry_points:
        importlib.import_module(ep)

    return _collect_project_modules(package_prefixes)


def _extract_package_prefixes(entry_points: list[str]) -> set[str]:
    """Extract top-level package names from entry point paths."""
    prefixes = set()
    for ep in entry_points:
        top_package = ep.split(".")[0]
        prefixes.add(top_package)
    return prefixes


def _collect_project_modules(
    package_prefixes: set[str],
) -> dict[str, ModuleType]:
    """Collect modules that belong to our target packages."""
    result: dict[str, ModuleType] = {}
    for name, mod in sys.modules.items():
        if mod is None:
            continue
        is_project_module = any(
            name == prefix or name.startswith(f"{prefix}.")
            for prefix in package_prefixes
        )
        if is_project_module and _has_source_file(mod):
            result[name] = mod
    return result


def _has_source_file(mod: ModuleType) -> bool:
    """Check if a module has an associated Python source file."""
    filepath = getattr(mod, "__file__", None)
    if filepath is None:
        return False
    return filepath.endswith(".py")
