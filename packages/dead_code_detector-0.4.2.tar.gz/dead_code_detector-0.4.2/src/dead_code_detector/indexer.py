"""Definition extraction from imported modules using inspect + AST fallback."""

from __future__ import annotations

import ast
import inspect
from pathlib import Path
from typing import TYPE_CHECKING, Any

from .models import DefinitionInfo

if TYPE_CHECKING:
    from types import ModuleType


def index_modules(modules: dict[str, ModuleType]) -> dict[str, DefinitionInfo]:
    """Extract all definitions from imported modules.

    Uses inspect for runtime-visible definitions, then falls back to
    AST parsing to catch decorated functions that got transformed into
    non-function objects (e.g. click commands).

    Args:
        modules: Dict mapping module name to module object.

    Returns:
        Dict mapping FQN to DefinitionInfo for all functions, classes,
        and methods found.
    """
    definitions: dict[str, DefinitionInfo] = {}
    for mod_name, mod in modules.items():
        _index_module(mod_name, mod, definitions)
    # AST fallback for definitions that inspect missed
    for mod_name, mod in modules.items():
        _index_module_ast_fallback(mod_name, mod, definitions)
    return definitions


def _index_module(
    mod_name: str,
    mod: ModuleType,
    definitions: dict[str, DefinitionInfo],
) -> None:
    """Extract definitions from a single module."""
    mod_file = getattr(mod, "__file__", None)
    if mod_file is None:
        return
    filepath = Path(mod_file)

    for name, obj in inspect.getmembers(mod):
        # Only index things defined in this module
        if not _is_defined_in(obj, mod):
            continue

        if inspect.isclass(obj):
            fqn = f"{mod_name}:{name}"
            lineno, end_lineno = _get_source_lines(obj)
            definitions[fqn] = DefinitionInfo(
                fqn=fqn,
                name=name,
                kind="class",
                module=mod_name,
                filepath=filepath,
                lineno=lineno,
                end_lineno=end_lineno,
            )
            _index_class_members(mod_name, name, obj, filepath, definitions)

        elif inspect.isfunction(obj):
            fqn = f"{mod_name}:{name}"
            lineno, end_lineno = _get_source_lines(obj)
            definitions[fqn] = DefinitionInfo(
                fqn=fqn,
                name=name,
                kind="function",
                module=mod_name,
                filepath=filepath,
                lineno=lineno,
                end_lineno=end_lineno,
            )


def _index_class_members(
    mod_name: str,
    class_name: str,
    cls: type,
    filepath: Path,
    definitions: dict[str, DefinitionInfo],
) -> None:
    """Extract method definitions from a class."""
    for method_name, method_obj in inspect.getmembers(cls):
        raw = _unwrap_method(method_obj)
        if raw is None:
            continue
        if not inspect.isfunction(raw):
            continue
        # Only include methods actually defined in this class (not inherited)
        if method_name not in cls.__dict__:
            continue

        fqn = f"{mod_name}:{class_name}.{method_name}"
        lineno, end_lineno = _get_source_lines(raw)
        # Skip auto-generated methods (dataclass, attrs, etc.)
        if lineno == 0:
            continue
        # Skip methods whose source lives outside this module's file
        # (catches attrs @define, dataclass, and other code generators)
        if not _source_in_file(raw, filepath):
            continue
        definitions[fqn] = DefinitionInfo(
            fqn=fqn,
            name=method_name,
            kind="method",
            module=mod_name,
            filepath=filepath,
            lineno=lineno,
            end_lineno=end_lineno,
        )


def _unwrap_method(obj: object) -> object | None:
    """Unwrap staticmethod, classmethod, property to get the underlying function."""
    if isinstance(obj, staticmethod):
        return obj.__func__
    if isinstance(obj, classmethod):
        return obj.__func__
    if isinstance(obj, property):
        return obj.fget
    return obj


def _is_defined_in(obj: object, mod: ModuleType) -> bool:
    """Check if an object is defined in the given module."""
    obj_module = getattr(obj, "__module__", None)
    return obj_module == mod.__name__


def _source_in_file(obj: Any, filepath: Path) -> bool:
    """Check that an object's source code is in the expected file."""
    try:
        source_file = inspect.getfile(obj)
        return Path(source_file).resolve() == filepath.resolve()
    except (TypeError, OSError):
        return False


def _get_source_lines(obj: Any) -> tuple[int, int | None]:
    """Get source line range for an object."""
    try:
        lines, lineno = inspect.getsourcelines(obj)
        return lineno, lineno + len(lines) - 1
    except (OSError, TypeError):
        return 0, None


def _index_module_ast_fallback(
    mod_name: str,
    mod: ModuleType,
    definitions: dict[str, DefinitionInfo],
) -> None:
    """Use AST to find definitions that inspect missed.

    This catches decorated functions transformed into non-function
    objects (e.g. @click.command turns a function into a Command).
    """
    mod_file = getattr(mod, "__file__", None)
    if mod_file is None:
        return
    filepath = Path(mod_file)
    try:
        source = filepath.read_text(encoding="utf-8")
        tree = ast.parse(source, filename=str(filepath))
    except (OSError, SyntaxError):
        return

    for node in ast.iter_child_nodes(tree):
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            fqn = f"{mod_name}:{node.name}"
            has_decorators = bool(node.decorator_list)
            if fqn not in definitions:
                definitions[fqn] = DefinitionInfo(
                    fqn=fqn,
                    name=node.name,
                    kind="function",
                    module=mod_name,
                    filepath=filepath,
                    lineno=node.lineno,
                    end_lineno=node.end_lineno,
                    decorated=has_decorators,
                )
            elif has_decorators and not definitions[fqn].decorated:
                # Update existing definition with decorator info
                defn = definitions[fqn]
                definitions[fqn] = DefinitionInfo(
                    fqn=defn.fqn,
                    name=defn.name,
                    kind=defn.kind,
                    module=defn.module,
                    filepath=defn.filepath,
                    lineno=defn.lineno,
                    end_lineno=defn.end_lineno,
                    decorated=True,
                )
        elif isinstance(node, ast.ClassDef):
            fqn = f"{mod_name}:{node.name}"
            has_decorators = bool(node.decorator_list)
            if fqn not in definitions:
                definitions[fqn] = DefinitionInfo(
                    fqn=fqn,
                    name=node.name,
                    kind="class",
                    module=mod_name,
                    filepath=filepath,
                    lineno=node.lineno,
                    end_lineno=node.end_lineno,
                    decorated=has_decorators,
                )
            elif has_decorators and not definitions[fqn].decorated:
                defn = definitions[fqn]
                definitions[fqn] = DefinitionInfo(
                    fqn=defn.fqn,
                    name=defn.name,
                    kind=defn.kind,
                    module=defn.module,
                    filepath=defn.filepath,
                    lineno=defn.lineno,
                    end_lineno=defn.end_lineno,
                    decorated=True,
                )
            _index_class_methods_ast(mod_name, node.name, node, filepath, definitions)


def _index_class_methods_ast(
    mod_name: str,
    class_name: str,
    class_node: ast.ClassDef,
    filepath: Path,
    definitions: dict[str, DefinitionInfo],
) -> None:
    """AST fallback for class methods."""
    for item in class_node.body:
        if isinstance(item, ast.FunctionDef | ast.AsyncFunctionDef):
            fqn = f"{mod_name}:{class_name}.{item.name}"
            has_decorators = bool(item.decorator_list)
            if fqn not in definitions:
                definitions[fqn] = DefinitionInfo(
                    fqn=fqn,
                    name=item.name,
                    kind="method",
                    decorated=has_decorators,
                    module=mod_name,
                    filepath=filepath,
                    lineno=item.lineno,
                    end_lineno=item.end_lineno,
                )
