"""Output formatting for dead code analysis results."""

from __future__ import annotations

import json
from collections import defaultdict
from io import StringIO
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from .models import AnalysisResult, DefinitionInfo


def _rel_path(filepath: Path) -> str:
    """Return a path relative to cwd, or the absolute path if not under cwd."""
    try:
        return str(filepath.relative_to(Path.cwd()))
    except ValueError:
        return str(filepath)


# ---------------------------------------------------------------------------
# Main report: grouped by module, classes grouped with methods
# ---------------------------------------------------------------------------


def report_flat(result: AnalysisResult) -> str:
    """Generate a structured report grouped by module, then by class."""
    dead = _sorted_dead(result)
    if not dead:
        return "No unused routines found.\n"

    buf = StringIO()
    stats = result.module_stats()
    stats_sorted = sorted(stats, key=lambda s: s.dead, reverse=True)

    buf.write(f"UNUSED ROUTINES ({len(dead)} found):\n")

    # Index dead items by module
    dead_by_module: dict[str, list[DefinitionInfo]] = defaultdict(list)
    for d in dead:
        dead_by_module[d.module].append(d)

    # Determine which classes are 100% dead
    all_dead_fqns = {d.fqn for d in dead}
    fully_dead_classes = _find_fully_dead_classes(result, all_dead_fqns)

    for mod_stats in stats_sorted:
        mod = mod_stats.module
        mod_dead = dead_by_module.get(mod, [])
        if not mod_dead:
            continue

        buf.write(
            f"\n── {mod}"
            f"  ({mod_stats.dead}/{mod_stats.total} dead,"
            f" {100 - mod_stats.coverage:.0f}% unused)\n"
        )

        _write_module_items(buf, mod_dead, fully_dead_classes)

    buf.write("\n")
    return buf.getvalue()


def _write_module_items(
    buf: StringIO,
    mod_dead: list[DefinitionInfo],
    fully_dead_classes: set[str],
) -> None:
    """Write dead items for one module, grouping methods under classes."""
    # Separate into: standalone functions, classes, methods
    functions = [d for d in mod_dead if d.kind == "function"]
    classes = [d for d in mod_dead if d.kind == "class"]
    methods = [d for d in mod_dead if d.kind == "method"]

    # Group methods by class FQN
    methods_by_class: dict[str, list[DefinitionInfo]] = defaultdict(list)
    for m in methods:
        cls_fqn = m.class_fqn or ""
        methods_by_class[cls_fqn].append(m)

    # Track which classes we've printed (dead class + its methods)
    printed_class_fqns: set[str] = set()

    # Print dead classes with their dead methods
    for cls in sorted(classes, key=lambda d: d.lineno):
        printed_class_fqns.add(cls.fqn)
        path = _rel_path(cls.filepath)
        if cls.fqn in fully_dead_classes:
            buf.write(f"   {path}:{cls.lineno}  {cls.name}")
            buf.write("  [entirely unused]\n")
        else:
            buf.write(f"   {path}:{cls.lineno}  {cls.name}\n")
        # Print methods of this class
        cls_methods = methods_by_class.pop(cls.fqn, [])
        for m in sorted(cls_methods, key=lambda d: d.lineno):
            buf.write(f"     :{m.lineno}  .{m.name}()\n")

    # Print methods whose class is NOT dead (only some methods are dead)
    for _cls_fqn, cls_methods in sorted(methods_by_class.items()):
        if not cls_methods:
            continue
        # Get class name from first method
        cls_name = cls_methods[0].class_name or "?"
        path = _rel_path(cls_methods[0].filepath)
        buf.write(f"   {path}  {cls_name}  (class is used, methods dead):\n")
        for m in sorted(cls_methods, key=lambda d: d.lineno):
            buf.write(f"     :{m.lineno}  .{m.name}()\n")

    # Print standalone functions
    for fn in sorted(functions, key=lambda d: d.lineno):
        path = _rel_path(fn.filepath)
        buf.write(f"   {path}:{fn.lineno}  {fn.name}()\n")


def _find_fully_dead_classes(
    result: AnalysisResult,
    dead_fqns: set[str],
) -> set[str]:
    """Find classes where the class AND all its methods are dead."""
    fully_dead = set()
    for fqn, defn in result.definitions.items():
        if defn.kind != "class":
            continue
        if fqn not in dead_fqns:
            continue
        # Check all methods of this class
        all_methods_dead = all(
            m_fqn in dead_fqns
            for m_fqn, m_defn in result.definitions.items()
            if m_defn.kind == "method" and m_defn.class_fqn == fqn
        )
        if all_methods_dead:
            fully_dead.add(fqn)
    return fully_dead


# ---------------------------------------------------------------------------
# Usage map: for each definition, show call paths from entry points
# ---------------------------------------------------------------------------


def report_usage(result: AnalysisResult) -> str:
    """Show all definitions with call paths from entry points."""
    buf = StringIO()

    defs_by_module: dict[str, list[DefinitionInfo]] = defaultdict(list)
    for defn in result.definitions.values():
        defs_by_module[defn.module].append(defn)

    reachable = result.reachable
    total_defs = len(result.definitions)
    reachable_defs = sum(1 for fqn in result.definitions if fqn in reachable)
    buf.write(f"USAGE MAP ({reachable_defs}/{total_defs} reachable definitions):\n")

    for mod_name in sorted(defs_by_module):
        mod_defs = sorted(defs_by_module[mod_name], key=lambda d: d.lineno)
        buf.write(f"\n── {mod_name}\n")
        _write_usage_module(buf, mod_defs, result)

    buf.write("\n")
    return buf.getvalue()


def _write_usage_module(
    buf: StringIO,
    mod_defs: list[DefinitionInfo],
    result: AnalysisResult,
) -> None:
    """Write usage info for one module's definitions."""
    classes = [d for d in mod_defs if d.kind == "class"]
    functions = [d for d in mod_defs if d.kind == "function"]
    methods = [d for d in mod_defs if d.kind == "method"]

    methods_by_class: dict[str, list[DefinitionInfo]] = defaultdict(list)
    for m in methods:
        methods_by_class[m.class_fqn or ""].append(m)

    for cls in classes:
        _write_usage_item(buf, cls, "   ", result)
        cls_methods = methods_by_class.pop(cls.fqn, [])
        for m in sorted(cls_methods, key=lambda d: d.lineno):
            _write_usage_method(buf, m, result)

    for _cls_fqn, cls_methods in sorted(methods_by_class.items()):
        if not cls_methods:
            continue
        cls_name = cls_methods[0].class_name or "?"
        buf.write(f"   {cls_name}:\n")
        for m in sorted(cls_methods, key=lambda d: d.lineno):
            _write_usage_method(buf, m, result)

    for fn in functions:
        _write_usage_item(buf, fn, "   ", result)


def _write_usage_item(
    buf: StringIO,
    defn: DefinitionInfo,
    indent: str,
    result: AnalysisResult,
) -> None:
    """Write a single definition with its status and path."""
    status = "+" if defn.fqn in result.reachable else "-"
    name = defn.name if defn.kind == "class" else f"{defn.name}()"
    path_str = _format_path(defn.fqn, result)
    buf.write(f"{indent}{status} {name}")
    if path_str:
        buf.write(f"  {path_str}")
    buf.write("\n")


def _write_usage_method(
    buf: StringIO,
    defn: DefinitionInfo,
    result: AnalysisResult,
) -> None:
    """Write a method entry with its status and path."""
    status = "+" if defn.fqn in result.reachable else "-"
    path_str = _format_path(defn.fqn, result)
    buf.write(f"     {status} .{defn.name}()")
    if path_str:
        buf.write(f"  {path_str}")
    buf.write("\n")


def _format_path(fqn: str, result: AnalysisResult) -> str:
    """Format the call path from entry point to this definition."""
    path = result.paths.get(fqn)
    if not path or len(path) <= 1:
        return ""

    # Convert FQN path to readable labels at module granularity
    labels = _path_to_labels(path, result)
    if len(labels) <= 1:
        return ""
    # Skip the last element (it's the target itself)
    chain = labels[:-1]
    return "via: " + " -> ".join(chain)


def _path_to_labels(
    path: list[str],
    result: AnalysisResult,
) -> list[str]:
    """Convert FQN path to deduplicated readable labels.

    Consecutive entries in the same module are collapsed.
    """
    labels: list[str] = []
    prev_label = ""
    for fqn in path:
        label = _fqn_label(fqn, result)
        if label != prev_label:
            labels.append(label)
            prev_label = label
    return labels


def _fqn_label(fqn: str, result: AnalysisResult) -> str:
    """Create a short readable label for an FQN."""
    if fqn.endswith(":<module>"):
        mod = fqn.split(":", maxsplit=1)[0]
        return _short_module(mod)
    defn = result.definitions.get(fqn)
    if defn is None:
        return fqn
    mod = _short_module(defn.module)
    qual = fqn.split(":", maxsplit=1)[-1]
    return f"{mod}:{qual}"


def _short_module(mod: str) -> str:
    """Shorten a module name to last 2 components."""
    parts = mod.split(".")
    if len(parts) <= 2:  # noqa: PLR2004
        return mod
    return "..." + ".".join(parts[-2:])


# ---------------------------------------------------------------------------
# Verbose report
# ---------------------------------------------------------------------------


def report_verbose(result: AnalysisResult) -> str:
    """Generate a verbose list with metadata and cross-references."""
    dead = _sorted_dead(result)
    if not dead:
        return "No unused routines found.\n"

    dead_fqns = {d.fqn for d in dead}
    buf = StringIO()
    buf.write(f"UNUSED ROUTINES ({len(dead)} found):\n\n")

    for defn in dead:
        lines_info = f"{defn.num_lines} lines" if defn.num_lines else "? lines"
        path = _rel_path(defn.filepath)
        name = _display_name(defn)
        buf.write(f"  {path}:{defn.lineno}  [{defn.kind}, {lines_info}]  {name}\n")
        referrers = _find_dead_referrers(defn, result, dead_fqns)
        if referrers:
            for ref_defn in referrers:
                ref_path = _rel_path(ref_defn.filepath)
                ref_name = _display_name(ref_defn)
                buf.write(
                    f"    Referenced by: {ref_path}:{ref_defn.lineno}"
                    f"  {ref_name}  (also dead)\n"
                )
        else:
            buf.write("    Referenced by: (none)\n")
        buf.write("\n")

    return buf.getvalue()


# ---------------------------------------------------------------------------
# Stats report
# ---------------------------------------------------------------------------


def report_stats(result: AnalysisResult) -> str:
    """Generate per-module coverage statistics, sorted by most dead."""
    stats = result.module_stats()
    if not stats:
        return "No modules analyzed.\n"

    # Sort by dead count descending, then by module name
    stats_sorted = sorted(stats, key=lambda s: (-s.dead, s.module))

    buf = StringIO()
    buf.write("MODULE COVERAGE:\n\n")

    header = (
        f"  {'Module':<45} {'Definitions':>11} {'Reachable':>9}"
        f" {'Dead':>5} {'Coverage':>8}"
    )
    buf.write(header + "\n")
    buf.write("  " + "-" * (len(header) - 2) + "\n")

    total_defs = 0
    total_reachable = 0

    for s in stats_sorted:
        total_defs += s.total
        total_reachable += s.reachable
        buf.write(
            f"  {s.module:<45} {s.total:>11} {s.reachable:>9}"
            f" {s.dead:>5} {s.coverage:>7.1f}%\n"
        )

    total_dead = total_defs - total_reachable
    total_cov = (total_reachable / total_defs * 100) if total_defs else 100.0
    buf.write("  " + "-" * (len(header) - 2) + "\n")
    buf.write(
        f"  {'TOTAL':<45} {total_defs:>11} {total_reachable:>9}"
        f" {total_dead:>5} {total_cov:>7.1f}%\n"
    )

    return buf.getvalue()


# ---------------------------------------------------------------------------
# JSON report
# ---------------------------------------------------------------------------


def report_json(result: AnalysisResult) -> str:
    """Generate JSON output."""
    dead = _sorted_dead(result)
    data = {
        "unused": [
            {
                "fqn": d.fqn,
                "name": _display_name(d),
                "kind": d.kind,
                "module": d.module,
                "file": _rel_path(d.filepath),
                "line": d.lineno,
                "num_lines": d.num_lines,
            }
            for d in dead
        ],
        "stats": {
            "total_definitions": len(result.definitions),
            "reachable": len(result.reachable),
            "dead": len(dead),
        },
    }
    return json.dumps(data, indent=2) + "\n"


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _sorted_dead(result: AnalysisResult) -> list[DefinitionInfo]:
    """Get dead definitions sorted by file path then line number."""
    dead = list(result.dead.values())
    dead.sort(key=lambda d: (str(d.filepath), d.lineno))
    return dead


def _display_name(defn: DefinitionInfo) -> str:
    """Format a definition for display."""
    qual_part = defn.fqn.split(":", 1)[-1]
    if defn.kind == "class":
        return qual_part
    return f"{qual_part}()"


def _find_dead_referrers(
    target: DefinitionInfo,
    result: AnalysisResult,
    dead_fqns: set[str],
) -> list[DefinitionInfo]:
    """Find dead definitions that reference the target."""
    referrers = []
    for fqn, refs in result.references.items():
        if fqn not in dead_fqns:
            continue
        if fqn == target.fqn:
            continue
        for ref in refs:
            name_matches = ref.name == target.name or ref.name.endswith(
                f".{target.name}"
            )
            if name_matches and fqn in result.definitions:
                referrers.append(result.definitions[fqn])
                break
    return referrers
