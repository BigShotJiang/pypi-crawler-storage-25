"""Graph construction and reachability analysis."""

from __future__ import annotations

from collections import defaultdict, deque

from .models import AnalysisResult, DefinitionInfo, Reference


def build_graph_and_analyze(
    definitions: dict[str, DefinitionInfo],
    references: dict[str, list[Reference]],
    entry_points: list[str],
    include_dunders: bool = False,
    live_decorators: bool = False,
) -> AnalysisResult:
    """Build reference graph and compute reachability from entry points.

    Args:
        definitions: All known definitions.
        references: References found per scope.
        entry_points: Module paths that serve as roots.
        include_dunders: If False, dunder methods of reachable classes
            are automatically marked reachable.
        live_decorators: If True, treat all decorated definitions as
            additional entry points (reachable by default).

    Returns:
        AnalysisResult with reachable set computed.
    """
    edges = _resolve_edges(definitions, references)
    reachable, paths = _compute_reachability(
        definitions, edges, entry_points, include_dunders, live_decorators
    )
    return AnalysisResult(
        definitions=definitions,
        reachable=reachable,
        references=references,
        edges=edges,
        paths=paths,
    )


def _resolve_edges(
    definitions: dict[str, DefinitionInfo],
    references: dict[str, list[Reference]],
) -> dict[str, set[str]]:
    """Resolve references to definition FQNs, building an adjacency list."""
    # Build lookup indexes
    name_to_fqns: dict[str, list[str]] = defaultdict(list)
    for fqn, defn in definitions.items():
        name_to_fqns[defn.name].append(fqn)

    # Module-qualified lookup: "module.name" -> fqn
    qualified_to_fqn: dict[str, str] = {}
    for fqn, defn in definitions.items():
        qualified_to_fqn[f"{defn.module}.{defn.name}"] = fqn
        # Also add the full import path for classes
        if defn.kind == "class":
            qualified_to_fqn[f"{defn.module}.{defn.name}"] = fqn

    edges: dict[str, set[str]] = defaultdict(set)

    for source_fqn, refs in references.items():
        for ref in refs:
            resolved = _resolve_single_ref(
                ref, source_fqn, definitions, name_to_fqns, qualified_to_fqn
            )
            for target_fqn in resolved:
                edges[source_fqn].add(target_fqn)

    _add_polymorphic_edges(definitions, edges, references, name_to_fqns)

    return edges


def _resolve_single_ref(
    ref: Reference,
    source_fqn: str,
    definitions: dict[str, DefinitionInfo],
    name_to_fqns: dict[str, list[str]],
    qualified_to_fqn: dict[str, str],
) -> list[str]:
    """Try to resolve a reference to one or more definition FQNs."""
    # Try exact qualified match (for imports like "package.module.name")
    if ref.name in qualified_to_fqn:
        return [qualified_to_fqn[ref.name]]

    if ref.kind == "import":
        return _resolve_import_ref(ref, name_to_fqns, qualified_to_fqn)
    if ref.kind in {"name", "call"}:
        return _resolve_name_ref(ref, source_fqn, definitions, name_to_fqns)
    if ref.kind == "attribute":
        return list(name_to_fqns.get(ref.name, []))
    return []


def _resolve_import_ref(
    ref: Reference,
    name_to_fqns: dict[str, list[str]],
    qualified_to_fqn: dict[str, str],
) -> list[str]:
    """Resolve an import reference."""
    results: list[str] = []
    if ref.name in qualified_to_fqn:
        results.append(qualified_to_fqn[ref.name])
    short_name = ref.name.rsplit(".", maxsplit=1)[-1]
    for fqn in name_to_fqns.get(short_name, []):
        if fqn not in results:
            results.append(fqn)
    return results


def _resolve_name_ref(
    ref: Reference,
    source_fqn: str,
    definitions: dict[str, DefinitionInfo],
    name_to_fqns: dict[str, list[str]],
) -> list[str]:
    """Resolve a name/call reference, preferring same-module matches."""
    source_module = source_fqn.split(":", maxsplit=1)[0]
    results = [
        fqn
        for fqn in name_to_fqns.get(ref.name, [])
        if definitions[fqn].module == source_module
    ]
    if not results:
        results = list(name_to_fqns.get(ref.name, []))
    return results


def _add_polymorphic_edges(
    definitions: dict[str, DefinitionInfo],
    edges: dict[str, set[str]],
    references: dict[str, list[Reference]],
    name_to_fqns: dict[str, list[str]],
) -> None:
    """Add edges from base class methods to subclass overrides.

    When Base.method is reachable, all overrides Sub.method should
    also be reachable (polymorphic dispatch).
    """
    hierarchy = _build_class_hierarchy(definitions, references, name_to_fqns)
    _link_overrides(definitions, edges, hierarchy)


def _build_class_hierarchy(
    definitions: dict[str, DefinitionInfo],
    references: dict[str, list[Reference]],
    name_to_fqns: dict[str, list[str]],
) -> dict[str, set[str]]:
    """Build parent_class_fqn -> set[child_class_fqn] from base_class refs."""
    parent_to_children: dict[str, set[str]] = defaultdict(set)
    for scope_fqn, refs in references.items():
        if scope_fqn not in definitions:
            continue
        if definitions[scope_fqn].kind != "class":
            continue
        for ref in refs:
            if ref.kind != "base_class":
                continue
            for candidate_fqn in name_to_fqns.get(ref.name, []):
                if (
                    candidate_fqn in definitions
                    and definitions[candidate_fqn].kind == "class"
                ):
                    parent_to_children[candidate_fqn].add(scope_fqn)
    return parent_to_children


def _link_overrides(
    definitions: dict[str, DefinitionInfo],
    edges: dict[str, set[str]],
    hierarchy: dict[str, set[str]],
) -> None:
    """For each base class method, add edge to each child's override."""
    for parent_fqn, children_fqns in hierarchy.items():
        parent_methods = [
            defn
            for defn in definitions.values()
            if defn.kind == "method" and defn.class_fqn == parent_fqn
        ]
        for method_defn in parent_methods:
            for child_fqn in children_fqns:
                child_module = child_fqn.split(":", maxsplit=1)[0]
                child_class = child_fqn.split(":", maxsplit=1)[-1]
                override_fqn = f"{child_module}:{child_class}.{method_defn.name}"
                if override_fqn in definitions:
                    edges[method_defn.fqn].add(override_fqn)


def _compute_reachability(
    definitions: dict[str, DefinitionInfo],
    edges: dict[str, set[str]],
    entry_points: list[str],
    include_dunders: bool,
    live_decorators: bool = False,
) -> tuple[set[str], dict[str, list[str]]]:
    """BFS from entry points, recording shortest paths.

    Returns:
        Tuple of (reachable set, paths dict).
        paths maps each reachable FQN to the list of FQNs from root to it.
    """
    reachable, parent, queue = _seed_entry_points(definitions, entry_points)

    if live_decorators:
        _seed_decorated(definitions, reachable, parent, queue)

    # BFS — traverse definitions and intermediate scope nodes
    # (e.g. decorated functions that inspect sees as non-function objects)
    visited: set[str] = set(reachable)
    while queue:
        current = queue.popleft()
        for target in edges.get(current, set()):
            if target in visited:
                continue
            visited.add(target)
            if target in definitions:
                reachable.add(target)
                parent[target] = current
                # When we reach a definition, also queue its module's
                # <module> scope — importing a module runs module-level code
                _enqueue_module_scope(
                    definitions[target].module, visited, queue, parent, target
                )
            # Follow edges even for non-definition nodes — they may
            # have outgoing edges to real definitions
            if target in edges:
                queue.append(target)
                if target not in parent:
                    parent[target] = current

    if not include_dunders:
        _mark_dunder_methods_reachable(definitions, reachable, parent)

    paths = _reconstruct_paths(parent)

    return reachable, paths


def _seed_entry_points(
    definitions: dict[str, DefinitionInfo],
    entry_points: list[str],
) -> tuple[set[str], dict[str, str | None], deque[str]]:
    """Create the initial BFS state from entry points."""
    reachable: set[str] = set()
    parent: dict[str, str | None] = {}
    queue: deque[str] = deque()

    for ep in entry_points:
        module_scope = f"{ep}:<module>"
        queue.append(module_scope)
        reachable.add(module_scope)
        parent[module_scope] = None
        for fqn, defn in definitions.items():
            if defn.module == ep:
                queue.append(fqn)
                reachable.add(fqn)
                parent[fqn] = module_scope

    return reachable, parent, queue


def _seed_decorated(
    definitions: dict[str, DefinitionInfo],
    reachable: set[str],
    parent: dict[str, str | None],
    queue: deque[str],
) -> None:
    """Treat all decorated definitions as additional roots."""
    for fqn, defn in definitions.items():
        if defn.decorated and fqn not in reachable:
            reachable.add(fqn)
            queue.append(fqn)
            parent[fqn] = None


def _enqueue_module_scope(
    module: str,
    visited: set[str],
    queue: deque[str],
    parent: dict[str, str | None],
    reached_via: str,
) -> None:
    """Queue a module's <module> scope when any of its definitions is reached."""
    mod_scope = f"{module}:<module>"
    if mod_scope not in visited:
        visited.add(mod_scope)
        queue.append(mod_scope)
        if mod_scope not in parent:
            parent[mod_scope] = reached_via


def _reconstruct_paths(
    parent: dict[str, str | None],
) -> dict[str, list[str]]:
    """Reconstruct BFS paths from parent pointers."""
    paths: dict[str, list[str]] = {}
    for fqn in parent:
        path = []
        current: str | None = fqn
        while current is not None:
            path.append(current)
            current = parent.get(current)
        path.reverse()
        paths[fqn] = path
    return paths


def _mark_dunder_methods_reachable(
    definitions: dict[str, DefinitionInfo],
    reachable: set[str],
    parent: dict[str, str | None],
) -> None:
    """Mark dunder methods of reachable classes as reachable."""
    reachable_classes = {
        fqn
        for fqn in reachable
        if fqn in definitions and definitions[fqn].kind == "class"
    }
    for fqn, defn in definitions.items():
        is_reachable_dunder = (
            defn.kind == "method"
            and defn.is_dunder
            and defn.class_fqn in reachable_classes
        )
        if is_reachable_dunder:
            reachable.add(fqn)
            if fqn not in parent:
                parent[fqn] = defn.class_fqn
