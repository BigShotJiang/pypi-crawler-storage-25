"""AST-based reference analysis to find what each definition references."""

from __future__ import annotations

import ast
from pathlib import Path
from typing import TYPE_CHECKING

from .models import DefinitionInfo, Reference

if TYPE_CHECKING:
    from types import ModuleType


def analyze_references(
    modules: dict[str, ModuleType],
    definitions: dict[str, DefinitionInfo],
) -> dict[str, list[Reference]]:
    """Parse AST of all modules to extract references within each definition.

    Args:
        modules: Dict mapping module name to module object.
        definitions: All known definitions (used to scope references).

    Returns:
        Dict mapping definition FQN to list of references found within it.
    """
    references: dict[str, list[Reference]] = {}
    # Also track module-level references (outside any def/class)
    for mod_name, mod in modules.items():
        filepath = getattr(mod, "__file__", None)
        if filepath is None:
            continue
        source = Path(filepath).read_text(encoding="utf-8")
        tree = ast.parse(source, filename=filepath)
        visitor = _ReferenceVisitor(mod_name, definitions)
        visitor.visit(tree)
        references.update(visitor.references)
    return references


class _ReferenceVisitor(ast.NodeVisitor):
    """AST visitor that extracts references scoped to each definition."""

    def __init__(
        self,
        mod_name: str,
        definitions: dict[str, DefinitionInfo],
    ) -> None:
        self.mod_name = mod_name
        self.definitions = definitions
        self.references: dict[str, list[Reference]] = {}
        # Stack of current scope FQNs
        self._scope_stack: list[str] = [f"{mod_name}:<module>"]
        # Initialize module-level references
        self.references[self._scope_stack[0]] = []

    @property
    def _current_scope(self) -> str:
        return self._scope_stack[-1]

    def _add_ref(self, name: str, kind: str, lineno: int) -> None:
        scope = self._current_scope
        if scope not in self.references:
            self.references[scope] = []
        self.references[scope].append(
            Reference(name=name, kind=kind, lineno=lineno, source_fqn=scope)
        )

    def visit_Import(self, node: ast.Import) -> None:
        for alias in node.names:
            self._add_ref(alias.name, "import", node.lineno)
        self.generic_visit(node)

    def visit_ImportFrom(self, node: ast.ImportFrom) -> None:
        module = self._resolve_import_module(node)
        for alias in node.names:
            if alias.name == "*":
                self._add_ref(module, "import_star", node.lineno)
            else:
                full_name = f"{module}.{alias.name}" if module else alias.name
                self._add_ref(full_name, "import", node.lineno)
        self.generic_visit(node)

    def _resolve_import_module(self, node: ast.ImportFrom) -> str:
        """Resolve the base module for a from-import, handling relative imports."""
        level = node.level or 0
        module = node.module or ""
        if level == 0:
            return module
        # Relative import: go up `level` packages from current module
        parts = self.mod_name.split(".")
        # level=1 means current package, level=2 means parent, etc.
        # For "from .foo import bar" in "a.b.c", base is "a.b"
        base = ".".join(parts[:-level]) if level <= len(parts) else ""
        if module:
            return f"{base}.{module}" if base else module
        return base

    def visit_Name(self, node: ast.Name) -> None:
        self._add_ref(node.id, "name", node.lineno)
        self.generic_visit(node)

    def visit_Attribute(self, node: ast.Attribute) -> None:
        self._add_ref(node.attr, "attribute", node.lineno)
        self.generic_visit(node)

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._visit_func_or_class(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._visit_func_or_class(node)

    def visit_ClassDef(self, node: ast.ClassDef) -> None:
        self._visit_func_or_class(node)

    def _visit_func_or_class(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef | ast.ClassDef,
    ) -> None:
        """Enter a new scope for a function or class definition."""
        # Visit decorators in the enclosing scope
        for decorator in node.decorator_list:
            self.visit(decorator)

        # Build the FQN for this scope
        parent_scope = self._current_scope
        if parent_scope.endswith(":<module>"):
            fqn = f"{self.mod_name}:{node.name}"
        elif ":<module>" not in parent_scope:
            # Nested inside a class or function
            qual_part = parent_scope.split(":", 1)[-1]
            fqn = f"{self.mod_name}:{qual_part}.{node.name}"
        else:
            fqn = f"{self.mod_name}:{node.name}"

        self._scope_stack.append(fqn)
        if fqn not in self.references:
            self.references[fqn] = []

        # Visit base classes and emit "base_class" refs for hierarchy
        if isinstance(node, ast.ClassDef):
            for base in node.bases:
                self.visit(base)
                base_name = _extract_name(base)
                if base_name:
                    self._add_ref(base_name, "base_class", node.lineno)

        # Visit function annotations (parameter types and return type)
        if isinstance(node, ast.FunctionDef | ast.AsyncFunctionDef):
            self._visit_annotations(node)

        # Visit the body
        for child in node.body:
            self.visit(child)

        self._scope_stack.pop()

    def _visit_annotations(
        self,
        node: ast.FunctionDef | ast.AsyncFunctionDef,
    ) -> None:
        """Visit function parameter and return type annotations."""
        all_args = node.args.posonlyargs + node.args.args + node.args.kwonlyargs
        for arg in all_args:
            if arg.annotation:
                self.visit(arg.annotation)
        if node.args.vararg and node.args.vararg.annotation:
            self.visit(node.args.vararg.annotation)
        if node.args.kwarg and node.args.kwarg.annotation:
            self.visit(node.args.kwarg.annotation)
        if node.returns:
            self.visit(node.returns)


def _extract_name(node: ast.expr) -> str | None:
    """Extract a simple name from an AST expression node."""
    if isinstance(node, ast.Name):
        return node.id
    if isinstance(node, ast.Attribute):
        return node.attr
    return None
