"""Data models for dead code detection."""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path  # noqa: TC003 - used at runtime in dataclass fields


@dataclass(frozen=True)
class DefinitionInfo:
    """A function, method, or class definition found in the codebase."""

    fqn: str
    name: str
    kind: str  # "function" | "method" | "class"
    module: str
    filepath: Path
    lineno: int
    end_lineno: int | None = None
    decorated: bool = False

    @property
    def num_lines(self) -> int | None:
        if self.end_lineno is None:
            return None
        return self.end_lineno - self.lineno + 1

    @property
    def is_dunder(self) -> bool:
        return self.name.startswith("__") and self.name.endswith("__")

    @property
    def class_name(self) -> str | None:
        """Extract class name from FQN if this is a method."""
        if self.kind != "method":
            return None
        # FQN format: "module:ClassName.method_name"
        qual_part = self.fqn.split(":", 1)[-1]
        parts = qual_part.rsplit(".", 1)
        if len(parts) == 2:  # noqa: PLR2004
            return parts[0]
        return None

    @property
    def class_fqn(self) -> str | None:
        """Get the FQN of the containing class, if this is a method."""
        cls = self.class_name
        if cls is None:
            return None
        module_part = self.fqn.split(":", 1)[0]
        return f"{module_part}:{cls}"


@dataclass(frozen=True)
class Reference:
    """A reference to a name found in source code."""

    name: str
    kind: str  # "import" | "call" | "attribute" | "name"
    lineno: int
    source_fqn: str = ""  # FQN of the definition containing this reference


@dataclass
class ModuleStats:
    """Coverage statistics for a single module."""

    module: str
    total: int = 0
    reachable: int = 0

    @property
    def dead(self) -> int:
        return self.total - self.reachable

    @property
    def coverage(self) -> float:
        if self.total == 0:
            return 100.0
        return (self.reachable / self.total) * 100.0


@dataclass
class AnalysisResult:
    """Complete result of dead code analysis."""

    definitions: dict[str, DefinitionInfo] = field(default_factory=dict)
    reachable: set[str] = field(default_factory=set)
    references: dict[str, list[Reference]] = field(default_factory=dict)
    edges: dict[str, set[str]] = field(default_factory=dict)
    # BFS shortest path from entry point to each reachable FQN
    # Maps FQN -> list of FQNs forming the path (entry -> ... -> target)
    paths: dict[str, list[str]] = field(default_factory=dict)

    @property
    def dead(self) -> dict[str, DefinitionInfo]:
        return {
            fqn: defn
            for fqn, defn in self.definitions.items()
            if fqn not in self.reachable
        }

    def module_stats(self) -> list[ModuleStats]:
        """Compute per-module coverage statistics."""
        stats_by_module: dict[str, ModuleStats] = {}
        for fqn, defn in self.definitions.items():
            if defn.module not in stats_by_module:
                stats_by_module[defn.module] = ModuleStats(module=defn.module)
            stats = stats_by_module[defn.module]
            stats.total += 1
            if fqn in self.reachable:
                stats.reachable += 1
        return sorted(stats_by_module.values(), key=lambda s: s.module)
