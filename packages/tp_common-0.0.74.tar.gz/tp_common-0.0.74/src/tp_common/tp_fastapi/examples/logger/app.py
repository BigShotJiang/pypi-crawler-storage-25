"""
Пример: использование TpLogger в FastAPI.

Показывает:
  - инициализацию фабрики и setup_standard_loggers при старте (lifespan);
  - middleware TpMiddleware: trace_id (X-Trace-ID), лог каждого HTTP-запроса, dependency get_request_logger;
  - логи в эндпоинтах с trace_id в JSON;
  - наследование от ApiException и передачу trace_id.

Запуск:
  uvicorn tp_common.tp_fastapi.examples.logger.app:app --reload --port 8000

Проверка:
  curl -i http://127.0.0.1:8000/
  curl -i -H "X-Trace-ID: 00000000-0000-0000-0000-000000000123" http://127.0.0.1:8000/items/1
"""

from __future__ import annotations

import uuid
from collections.abc import AsyncGenerator
from contextlib import asynccontextmanager
from http import HTTPStatus

from fastapi import Depends, FastAPI

from tp_common.decorators.decorator_retry_forever import retry_forever
from tp_common.exceptions import ApiException
from tp_common.tp_logger.fastapi_integration import (
    TpMiddleware,
    get_request_logger,
)
from tp_common.tp_logger.schemas import EnvironmentType
from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory


class ExampleErrorException(ApiException):
    """Пример ошибки для демонстрации логов (эндпоинт /error)."""

    def __init__(
        self,
        *,
        trace_id: str | int | uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message="Пример ошибки для логов",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            trace_id=trace_id,
        )


class FlakyOperationException(ApiException):
    """Ошибка flaky-операции после исчерпания повторов (эндпоинт /flaky)."""

    def __init__(
        self,
        *,
        trace_id: str | int | uuid.UUID | None = None,
    ) -> None:
        super().__init__(
            message="Internal Server Error",
            status_code=HTTPStatus.INTERNAL_SERVER_ERROR,
            trace_id=trace_id,
        )


@asynccontextmanager
async def lifespan(app: FastAPI) -> AsyncGenerator[None]:
    env = EnvironmentType.DEV
    app.state.log_factory = TpLoggerFactory(env)
    TpLoggerFactory.setup_standard_loggers(env)
    yield


app = FastAPI(title="TpLogger FastAPI example", lifespan=lifespan)
app.add_middleware(TpMiddleware)


@app.get("/")
def root(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    logger.info("Обработка запроса к корню")
    return {
        "message": "ok",
        "trace_id": str(logger.trace_id) if logger.trace_id else "",
    }


@app.get("/items/{item_id}")
def get_item(
    item_id: int, logger: TpLogger = Depends(get_request_logger)
) -> dict[str, str | int]:
    logger.info("Запрос элемента", extra={"item_id": item_id})
    if item_id < 0:
        logger.warning("Отрицательный item_id", extra={"item_id": item_id})
    return {
        "item_id": item_id,
        "trace_id": str(logger.trace_id) if logger.trace_id else "",
    }


@app.get("/slow")
async def slow(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    logger.info("Начало медленной операции")
    import asyncio

    await asyncio.sleep(0.1)
    logger.info("Медленная операция завершена")
    return {
        "message": "done",
        "trace_id": str(logger.trace_id) if logger.trace_id else "",
    }


@app.get("/error")
def raise_error(logger: TpLogger = Depends(get_request_logger)) -> None:
    logger.error("Сейчас выбросим исключение")
    raise ExampleErrorException(trace_id=logger.trace_id)


class _FlakyService:
    def __init__(self, logger: TpLogger) -> None:
        self.logger = logger

    @retry_forever(
        start_message="Вызов flaky-операции",
        error_message="Ошибка flaky: {e}",
        max_errors=3,
        delay=1,
    )
    async def do_something(self) -> str:
        raise ValueError("Имитация сбоя (после 3 повторов исключение уйдёт в эндпоинт)")


@app.get("/flaky")
async def flaky(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    try:
        service = _FlakyService(logger)
        result = await service.do_something()
        return {"result": result}
    except Exception as e:
        logger.exception("Flaky-операция не удалась после повторов: %s", e)
        raise FlakyOperationException(trace_id=logger.trace_id) from e


@app.get("/explicit")
def explicit_depends(logger: TpLogger = Depends(get_request_logger)) -> dict[str, str]:
    logger.debug("Явная зависимость get_request_logger")
    return {"trace_id": str(logger.trace_id) if logger.trace_id else ""}


if __name__ == "__main__":
    import uvicorn

    uvicorn.run(
        "tp_common.tp_fastapi.examples.logger.app:app",
        host="0.0.0.0",
        port=8000,
        reload=True,
    )
