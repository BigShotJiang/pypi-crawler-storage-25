"""
Интеграция TpLogger с FastAPI: middleware для trace_id и dependency для логгера на запрос.

Использование:
    1. При старте приложения сохраните фабрику в app.state и настройте стандартные логгеры:
        app.state.log_factory = TpLoggerFactory(EnvironmentType.DEV)
        TpLoggerFactory.setup_standard_loggers(EnvironmentType.DEV)

    2. Подключите middleware (trace_id, лог каждого HTTP-запроса, перехват исключений):
        from tp_common.tp_logger.fastapi_integration import TpMiddleware
        app.add_middleware(TpMiddleware)

    3. В эндпоинтах инжектируйте логгер (тип — TpLogger, переменную называйте logger):
        from fastapi import Depends
        from tp_common.tp_logger.fastapi_integration import get_request_logger
        from tp_common.tp_logger.tp_logging import TpLogger
        @app.get("/")
        def root(logger: TpLogger = Depends(get_request_logger)):
            logger.info("Обработка запроса")
"""

from __future__ import annotations

import time
import uuid
from collections.abc import Awaitable, Callable
from typing import Annotated

from fastapi import Depends, Request
from starlette.middleware.base import BaseHTTPMiddleware
from starlette.responses import JSONResponse, Response

from tp_common.tp_logger.tp_logging import TpLogger, TpLoggerFactory, generate_trace_id

# Имена заголовков для передачи trace_id (клиент может передать свой id)
TRACE_ID_HEADERS = ("x-trace-id", "x-correlation-id")
RESPONSE_TRACE_HEADER = "x-trace-id"


def _get_trace_id_from_request(request: Request) -> uuid.UUID:
    """Достаёт trace_id из request.state (уже установлен middleware) или генерирует."""
    trace_id = getattr(request.state, "trace_id", None)
    if isinstance(trace_id, uuid.UUID):
        return trace_id
    return generate_trace_id()


class TpMiddleware(BaseHTTPMiddleware):
    """
    Middleware для trace_id, лога каждого HTTP-запроса и перехвата необработанных исключений.
    - Устанавливает trace_id из заголовка (X-Trace-ID и др.) или генерирует новый.
    - После ответа пишет в TpLogger строку: метод, путь, статус, длительность (с тем же trace_id).
    - Добавляет X-Trace-ID в ответ (успех и 500).
    - Перехватывает необработанные Exception, логирует через TpLogger с trace_id, возвращает 500.
    """

    async def dispatch(
        self,
        request: Request,
        call_next: Callable[[Request], Awaitable[Response]],
    ) -> Response:
        trace_id: uuid.UUID | None = None
        for header_name in TRACE_ID_HEADERS:
            value = request.headers.get(header_name)
            if value:
                try:
                    trace_id = uuid.UUID(value.strip())
                except ValueError:
                    trace_id = None
                break
        if trace_id is None:
            trace_id = generate_trace_id()
        request.state.trace_id = trace_id

        started = time.perf_counter()
        status_code = 500
        try:
            response = await call_next(request)
            status_code = response.status_code
            response.headers[RESPONSE_TRACE_HEADER] = str(trace_id)
            return response
        except Exception as exc:
            status_code = 500
            try:
                logger = get_request_logger(request)
                logger.exception("Необработанное исключение: %s", exc)
            except Exception:  # noqa: BLE001
                pass
            response = JSONResponse(
                status_code=500,
                content={
                    "message": "Internal Server Error",
                    "error": "internal_server_error",
                    "trace_id": str(trace_id),
                },
            )
            response.headers[RESPONSE_TRACE_HEADER] = str(trace_id)
            return response
        finally:
            _tp_log_http_request(request, status_code, time.perf_counter() - started)


def get_request_logger(request: Request) -> TpLogger:
    """
    Dependency: возвращает TpLogger с trace_id текущего запроса.
    Фабрика должна быть в request.app.state.log_factory (TpLoggerFactory).
    """
    factory: TpLoggerFactory | None = getattr(request.app.state, "log_factory", None)
    if factory is None:
        raise RuntimeError(
            "TpLoggerFactory not set on app.state.log_factory. "
            "Set it on startup, e.g. app.state.log_factory = TpLoggerFactory(env)."
        )
    trace_id = _get_trace_id_from_request(request)
    # Кэшируем логгер на запрос, чтобы не создавать новый при каждом вызове dependency
    logger = getattr(request.state, "_tp_logger", None)
    if logger is None:
        logger = factory.get_logger("api", trace_id=trace_id)
        request.state._tp_logger = logger
    return logger


def _tp_log_http_request(request: Request, status_code: int, duration_s: float) -> None:
    """Одна строка access-лога на запрос (вызывается из ``TpMiddleware``)."""
    try:
        logger = get_request_logger(request)
        client = request.client
        client_host = client.host if client else None
        duration_ms = duration_s * 1000
        logger.info(
            "%s %s -> %s",
            request.method,
            request.url.path,
            status_code,
            extra={
                "http_method": request.method,
                "http_path": request.url.path,
                "http_status": status_code,
                "duration_ms": round(duration_ms, 3),
                "client_host": client_host,
            },
        )
    except Exception:  # noqa: BLE001
        pass


# Для аннотации используйте: logger: TpLogger = Depends(get_request_logger)
# (Annotated-алиас может вызывать предупреждения типа "invalid type" в части IDE/checker.)
RequestLogger = Annotated[
    TpLogger, Depends(get_request_logger)
]  # опциональный короткий вариант


async def tp_logger_exception_handler(request: Request, exc: Exception) -> JSONResponse:
    """
    Обработчик исключений для add_exception_handler.
    Для необработанных 500 не вызывается — их перехватывает ServerErrorMiddleware.
    Используйте TpLoggerMiddleware — он перехватывает исключения и логирует с trace_id.
    """
    try:
        logger = get_request_logger(request)
        logger.exception("Необработанное исключение: %s", exc)
    except Exception:  # noqa: BLE001
        pass
    return JSONResponse(
        status_code=500,
        content={"detail": "Internal Server Error"},
    )
