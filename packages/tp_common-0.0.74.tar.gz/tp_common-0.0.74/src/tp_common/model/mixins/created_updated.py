"""Миксины с полями created_at / updated_at."""

from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy import text
from sqlalchemy.orm import Mapped, mapped_column

from tp_common.model.types import UTCDateTime


class CreatedUpdatedMixin:
    created_at: Mapped[datetime] = mapped_column(
        UTCDateTime(),
        server_default=text("TIMEZONE('utc', now())"),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
    updated_at: Mapped[datetime] = mapped_column(
        UTCDateTime(),
        server_default=text("TIMEZONE('utc', now())"),
        onupdate=text("TIMEZONE('utc', now())"),
        default=lambda: datetime.now(UTC),
        nullable=False,
    )
