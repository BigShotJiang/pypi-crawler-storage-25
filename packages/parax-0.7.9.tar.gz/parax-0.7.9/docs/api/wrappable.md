::: parax.AbstractWrappable

::: parax.wrap
