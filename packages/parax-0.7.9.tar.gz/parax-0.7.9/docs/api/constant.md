::: parax.constant.AbstractConstant
