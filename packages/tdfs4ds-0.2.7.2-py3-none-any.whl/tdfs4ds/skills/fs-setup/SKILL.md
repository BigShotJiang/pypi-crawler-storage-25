---
description: Generate code to connect to Teradata and initialise the tdfs4ds temporal feature store. Invoke when the user needs connection boilerplate, first-time setup, or wants to configure global feature store variables.
argument-hint: [schema] [data-domain]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to connect to a Teradata Vantage database and initialise the `tdfs4ds` temporal feature store.

User context: $ARGUMENTS

Ask for any missing values before generating code:
- **Schema / database name** — Teradata database hosting the feature store (e.g. `'demo_db'`).
- **Data domain** — project namespace isolating features across teams (e.g. `'Customer Transaction Analytics'`).

Emit the following pattern, substituting real values for every `<PLACEHOLDER>`:

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_HOST, TDML_USERNAME, TDML_PASSWORD,
#   TDML_DATABASE, TDML_TEMP_DATABASE).
# tdfs4ds settings are also auto-loaded from the same .env (TDFS4DS_DATA_DOMAIN,
#   TDFS4DS_SCHEMA, …) and from tdfs4ds.json — no extra load_dotenv call needed.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

# Import tdfs4ds AFTER create_context — it auto-detects SCHEMA from the session
# and loads any TDFS4DS_* settings from .env / tdfs4ds.json automatically.
import tdfs4ds
tdfs4ds.connect(database=Param['database'])

# Optional overrides — can also be set via TDFS4DS_* in .env or in tdfs4ds.json
# tdfs4ds.FEATURE_STORE_TIME = None     # None = current; '2024-01-01 00:00:00' = time travel
# tdfs4ds.DISPLAY_LOGS       = True
# tdfs4ds.DEBUG_MODE         = False
# tdfs4ds.STORE_FEATURE      = 'MERGE'  # or 'UPDATE_INSERT'

# First-time / administrator only (idempotent): deploy catalog tables and views
tdfs4ds.setup()

# Create the data domain (idempotent — warns if already present).
# Analytics notebooks activate it with select_data_domain instead.
tdfs4ds.create_data_domain('<DATA_DOMAIN>')
```

Add `tdml.remove_context()` at the end of every script or notebook.

## Rules

- `tdml.create_context(...)` must come **before** any `tdfs4ds` import or call.
- Use `tdfs4ds.create_data_domain(name)` in the **setup notebook** (creates the domain, idempotent). Use `tdfs4ds.select_data_domain(name)` in all **analytics/feature notebooks** (activates an existing domain; raises `ValueError` if not found). Never set `tdfs4ds.DATA_DOMAIN` directly.
- Never hard-code credentials; always use a `.env` file or OS environment variables.
- `tdfs4ds` auto-loads `TDFS4DS_*` variables from `.env` and `tdfs4ds.json` at import time. Call `tdfs4ds.load_config(path=..., dotenv_path=...)` to reload or point at a custom file.
- `tdfs4ds.setup()` is idempotent but is an administrator action — note this in a comment.
