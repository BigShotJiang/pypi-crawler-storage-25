---
description: Generate LLM-powered documentation for a registered tdfs4ds process — business logic, entity description, per-feature descriptions, and an EXPLAIN plan quality score (1-5). Documentation is persisted to the feature store. Invoke when the user wants to document or review a process.
argument-hint: [process-id] [llm-provider: openai|bedrock|vllm|azure]
allowed-tools: Read, Edit, Write, Bash, Glob, Grep
---

Generate Python code to produce and persist LLM-powered documentation for a registered `tdfs4ds` process, including an EXPLAIN plan quality score.

User context: $ARGUMENTS

Ask for any missing values before generating code:
- **Process ID or view name** — Either the UUID, or the qualified view name (e.g. `"demo_user"."FEAT_ENG_CUST"`). Prefer the view name when the user provides it — use `get_process_id` to resolve it (see pattern below).
- **LLM provider** — `'openai'`, `'azure'`, `'bedrock'`, or `'vllm'`. Credentials loaded from env vars.

`document_process` produces and uploads:
- Business logic description of the SQL query
- Entity description
- Per-feature column descriptions
- EXPLAIN plan analysis with a **quality score 1–5** (5 = optimal use of PI and partitioning)

Emit the following pattern, substituting real values:

```python
import warnings
warnings.filterwarnings("ignore")

import teradataml as tdml
import os
from dotenv import load_dotenv

# Teradata credentials from .env (TDML_*). TDFS4DS_* settings (DATA_DOMAIN,
# SCHEMA, INSTRUCT_MODEL_*, etc.) are auto-loaded from the same .env by
# `import tdfs4ds` — add them once and skip the explicit assignments below.
load_dotenv()
Param = {
    'host'              : os.getenv('TDML_HOST'),
    'user'              : os.getenv('TDML_USERNAME'),
    'password'          : os.getenv('TDML_PASSWORD'),
    'database'          : os.getenv('TDML_DATABASE'),
    'temp_database_name': os.getenv('TDML_TEMP_DATABASE'),
}
tdml.create_context(**Param)

import tdfs4ds
tdfs4ds.connect(database=Param['database'], create_if_missing=True)
tdfs4ds.select_data_domain('<DATA_DOMAIN>')   # or set TDFS4DS_DATA_DOMAIN in .env

# ---------------------------------------------------------------------------
# LLM configuration — choose one provider block.
# Preferred: set TDFS4DS_INSTRUCT_MODEL_* in .env — auto-loaded at import.
# The explicit assignments below override any file/env settings if needed.
# ---------------------------------------------------------------------------

# Option A: OpenAI-compatible (openai, vllm, azure)
tdfs4ds.INSTRUCT_MODEL_PROVIDER = '<PROVIDER>'                  # 'openai', 'vllm', or 'azure'
tdfs4ds.INSTRUCT_MODEL_URL      = os.getenv('FS_API_URL')       # None for default OpenAI endpoint
tdfs4ds.INSTRUCT_MODEL_API_KEY  = os.getenv('FS_API_KEY')       # or TDFS4DS_INSTRUCT_MODEL_API_KEY in .env
tdfs4ds.INSTRUCT_MODEL_MODEL    = os.getenv('FS_API_MODEL')

# Option B: AWS Bedrock
# tdfs4ds.INSTRUCT_MODEL_PROVIDER = 'bedrock'
# tdfs4ds.INSTRUCT_MODEL_MODEL    = 'anthropic.claude-3-sonnet-20240229-v1:0'
# (uses boto3 default credentials — no API key needed)

# ---------------------------------------------------------------------------
# 1. Inspect available processes
# ---------------------------------------------------------------------------
tdfs4ds.process_catalog()

# ---------------------------------------------------------------------------
# 2. Resolve process ID — two options
# ---------------------------------------------------------------------------

# Option A: you already have the UUID
process_id = '<PROCESS_ID>'

# Option B: resolve from a qualified view name (preferred when user supplies a view name)
from tdfs4ds.process_store.process_query_administration import get_process_id

process_id = get_process_id('"<DATABASE>"."<VIEW_NAME>"')
# get_process_id strips quotes, handles "db"."view" or plain view names,
# and falls back to tdfs4ds.SCHEMA when no database prefix is given.

# ---------------------------------------------------------------------------
# 3. Document the process
#    - Calls the LLM to generate business logic, entity, and feature docs
#    - Runs EXPLAIN on the process SQL and scores it 1–5
#    - Persists everything to the feature store documentation tables
# ---------------------------------------------------------------------------
from tdfs4ds.genai import document_process

process_info = document_process(
    process_id=process_id,
    show_sql_query=True,      # print the process SQL alongside the docs
    show_explain_plan=True,   # print the raw EXPLAIN plan
)

# The returned dict contains all generated documentation:
# process_info['DOCUMENTED_SQL']           — business logic + feature descriptions
# process_info['EXPLAIN_ANALYSIS']         — plain-text EXPLAIN plan analysis
# process_info['USER_SCORE']               — int 1–5: SQL quality (what you control)
# process_info['OPTIMIZATION_SCORE']       — int 1–5: overall execution quality (infra included)
# process_info['EXPLAIN_WARNINGS']         — list[str]: flagged issues
# process_info['EXPLAIN_RECOMMENDATIONS']  — list[str]: split [You] / [Data Engineer / DBA]

# ---------------------------------------------------------------------------
# 4. Document all processes in the current data domain (batch)
# ---------------------------------------------------------------------------
# process_ids = (
#     tdfs4ds.process_catalog()[['PROCESS_ID']].to_pandas().PROCESS_ID.values
# )
# for pid in process_ids:
#     document_process(process_id=pid)

# ---------------------------------------------------------------------------
# 5. Retrieve previously stored documentation (no LLM call)
# ---------------------------------------------------------------------------
from tdfs4ds.process_store.process_store_catalog_management import get_process_info

stored = get_process_info(process_id)
print(stored.get('DOCUMENTED_SQL'))
print(stored.get('EXPLAIN_ANALYSIS'))

tdml.remove_context()
```

## EXPLAIN score interpretation

| Score | Meaning |
|-------|---------|
| 5/5 | Query fully leverages primary index and/or partitioning — optimal |
| 3–4/5 | Partial optimisation — some full-AMP or full-partition scans remain |
| 1–2/5 | Full-table scans, product joins, or spool-heavy operations — consider rewriting or adding a FilterManager |

## Business dictionary

Two temporal tables store **business-oriented descriptions** for database objects and their columns, independently of the process documentation workflow. They are provisioned automatically by `tdfs4ds.connect(create_if_missing=True)`.

| Table | Key columns | Purpose |
|-------|-------------|---------|
| `FS_BUSINESS_DICTIONARY_OBJECTS` | `DATABASE_NAME`, `OBJECT_NAME` | One row per table or view |
| `FS_BUSINESS_DICTIONARY_COLUMNS` | `DATABASE_NAME`, `TABLE_NAME`, `COLUMN_NAME` | One row per column |

Both tables are VALIDTIME temporal — every write uses `CURRENT VALIDTIME MERGE`, so the full history of descriptions is preserved.

### Upload object descriptions

```python
import pandas as pd
from tdfs4ds.genai import upload_business_dictionary_objects

objects_df = pd.DataFrame([
    {
        'DATABASE_NAME'       : 'MY_DB',
        'OBJECT_NAME'         : 'CUSTOMER',
        'OBJECT_TYPE'         : 'T',           # 'T' = table, 'V' = view
        'BUSINESS_DESCRIPTION': 'Core customer table. Each row represents a unique customer enrolled in the loyalty programme.',
    },
    {
        'DATABASE_NAME'       : 'MY_DB',
        'OBJECT_NAME'         : 'V_CUSTOMER_ORDERS',
        'OBJECT_TYPE'         : 'V',
        'BUSINESS_DESCRIPTION': 'Business view joining customers with their order history for reporting.',
    },
])
upload_business_dictionary_objects(objects_df)
```

### Upload column descriptions

```python
from tdfs4ds.genai import upload_business_dictionary_columns

columns_df = pd.DataFrame([
    {
        'DATABASE_NAME'       : 'MY_DB',
        'TABLE_NAME'          : 'CUSTOMER',
        'COLUMN_NAME'         : 'CUSTOMER_ID',
        'BUSINESS_DESCRIPTION': 'Unique customer identifier assigned at enrolment.',
    },
    {
        'DATABASE_NAME'       : 'MY_DB',
        'TABLE_NAME'          : 'CUSTOMER',
        'COLUMN_NAME'         : 'BIRTH_DATE',
        'BUSINESS_DESCRIPTION': 'Customer date of birth, used for age-band segmentation.',
    },
])
upload_business_dictionary_columns(columns_df)
```

Both functions validate that all required columns are present and raise `ValueError` with the list of missing columns if not.

## Rules

- When the user provides a view name instead of a UUID, always use `get_process_id` from `tdfs4ds.process_store.process_query_administration` to resolve it — never ask the user to look up the UUID manually.
- `document_process` both generates **and persists** documentation — it is safe to re-run; it overwrites previous docs for the same `process_id`.
- LLM config can be set via `TDFS4DS_INSTRUCT_MODEL_*` in `.env` or `tdfs4ds.json` (auto-loaded at `import tdfs4ds`). Explicit programmatic assignment always wins and must appear before calling `document_process`.
- For `'bedrock'` provider, no `INSTRUCT_MODEL_URL` or `INSTRUCT_MODEL_API_KEY` is needed — it uses boto3 credentials.
- A low EXPLAIN score (1–2) is a signal to run `fs-analyze` to check for partition/PI opportunities and a possible FilterManager rewrite.
- `upload_business_dictionary_objects` / `upload_business_dictionary_columns` do **not** require an LLM — descriptions are provided by the user as plain text in a pandas DataFrame.
