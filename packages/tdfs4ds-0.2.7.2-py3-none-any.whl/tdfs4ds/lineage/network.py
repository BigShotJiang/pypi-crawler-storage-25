from __future__ import annotations

import re
from dataclasses import dataclass, asdict
from typing import Dict, List, Tuple, Set, Optional, Any

from tdfs4ds.lineage.lineage import analyze_sql_query
from tdfs4ds.lineage.indexing import analyze_teradata_ddl

from tdfs4ds import logger_safe
from tdfs4ds.utils.query_management import execute_query
import teradataml as tdml

from typing import Dict, Any, List, Tuple, Optional
import plotly.graph_objects as go
import plotly.io as pio


@dataclass
class NodeInfo:
    """Graph node metadata."""
    name: str                    # canonical name, e.g. '"db"."obj"' or '<DEFAULT_DATABASE>."obj"'
    object_type: str             # "view" | "table" | "unknown"
    database: Optional[str] = None
    object: Optional[str] = None
    ddl: Optional[str] = None    # optional, can disable storing for memory reasons
    table_info: Optional[Dict[str, Any]] = None  # output of analyze_teradata_ddl for tables
    error: Optional[str] = None  # if we couldn't show/parse


def _require_teradataml():
    if execute_query is None:
        raise RuntimeError(
            "teradataml execute_query is not available. "
            "Make sure teradataml is installed and imported correctly."
        )


def _strip_outer_quotes(s: str) -> str:
    s = s.strip()
    if len(s) >= 2 and ((s[0] == s[-1] == '"') or (s[0] == s[-1] == "'")):
        return s[1:-1]
    return s


def _parse_node_name(node_name: str) -> Tuple[Optional[str], str]:
    """
    Accepts names like:
      - '"sales"."orders"'
      - '<DEFAULT_DATABASE>."orders"'
      - 'sales.orders'
      - 'orders'  (rare; treat as object only)
    Returns (database, object).
    """
    s = node_name.strip()

    # canonical already (like your analyzer outputs)
    if s.startswith("<DEFAULT_DATABASE>"):
        # format: <DEFAULT_DATABASE>."obj"
        parts = s.split(".", 1)
        obj = parts[1] if len(parts) > 1 else s
        obj = _strip_outer_quotes(obj)
        return None, obj

    if s.startswith('"'):
        # format: "db"."obj" (assume exactly two quoted identifiers)
        # very small parser: split on "." between quoted segments
        # e.g. '"db"."obj"' -> ['"db"', '"obj"']
        bits = s.split(".")
        if len(bits) >= 2:
            db = _strip_outer_quotes(bits[0])
            obj = _strip_outer_quotes(bits[1])
            return db, obj

    # unquoted forms
    if "." in s:
        db, obj = s.split(".", 1)
        return db.strip(), obj.strip()

    return None, s


def _quote_ident(ident: str) -> str:
    # Teradata supports "quoted identifiers"; quoting is safest for mixed case / special chars.
    ident = ident.replace('"', '""')
    return f'"{ident}"'


def _qualified_name_for_show(node_name: str, default_database: Optional[str]) -> str:
    """
    Build a safe qualified name for SHOW statements.
    - If node_name includes db, use it.
    - If it is <DEFAULT_DATABASE>, use default_database.
    - If no db and default_database is given, qualify with it.
    """
    db, obj = _parse_node_name(node_name)
    if db is None:
        # <DEFAULT_DATABASE> or missing db
        if default_database:
            return f"{_quote_ident(default_database)}.{_quote_ident(obj)}"
        # If no default database, try unqualified (may work if session has a default DB)
        return _quote_ident(obj)
    return f"{_quote_ident(db)}.{_quote_ident(obj)}"


def _fetch_single_column_rows(sql: str) -> List[str]:
    """
    Executes SQL and returns a list of strings from the first column.
    Works for SHOW VIEW / SHOW TABLE outputs (usually one column with text lines).
    """
    _require_teradataml()
    return tdml.execute_sql(sql).fetchall()[0][0].replace('\r','\n')

def _fetch_dataset_registry(schema: Optional[str], catalog_view: str) -> Set[Tuple[str, str]]:
    """
    Pre-fetches all registered feature store datasets as a set of
    (DATASET_DATABASE.upper(), DATASET_NAME.upper()) tuples.
    Returns an empty set if the catalog is unreachable.
    """
    if not schema:
        return set()
    try:
        rows = tdml.execute_sql(
            f"SELECT DATASET_DATABASE, DATASET_NAME "
            f"FROM {_quote_ident(schema)}.{_quote_ident(catalog_view)}"
        ).fetchall()
        return {(row[0].upper(), row[1].upper()) for row in rows}
    except Exception:
        return set()


def _extract_process_ids_from_dataset_ddl(ddl: str) -> List[str]:
    """
    Parses a dataset view DDL and returns the unique FEATURE_VERSION values found in it.

    Dataset views embed lines like:
        WHERE (FEATURE_ID = 1 AND FEATURE_VERSION='3b3e3c87-2f0e-404b-82ae-c598e4addcd1')

    FEATURE_VERSION is the PROCESS_ID of the process that produced the feature,
    so this gives us all process UUIDs whose features are consumed by the dataset.
    Order-preserving deduplication is applied.
    """
    ids = re.findall(r"FEATURE_VERSION\s*=\s*'([^']+)'", ddl, re.IGNORECASE)
    return list(dict.fromkeys(ids))


def _fetch_view_names_for_process_ids(
    schema: str,
    process_catalog_view: str,
    process_ids: List[str],
) -> List[str]:
    """
    Given a list of PROCESS_IDs, returns the VIEW_NAME for each from the process catalog.
    VIEW_NAME is the feature-engineering view registered for that process
    (e.g. '"demo_user"."FEAT_ENG_CUST"'), not the internal feature-store storage tables.

    Returns an empty list if the catalog is unreachable or no rows are found.
    """
    if not schema or not process_ids:
        return []
    ids_csv = ", ".join(f"'{pid}'" for pid in process_ids)
    try:
        rows = tdml.execute_sql(
            f"SELECT DISTINCT VIEW_NAME "
            f"FROM {_quote_ident(schema)}.{_quote_ident(process_catalog_view)} "
            f"WHERE PROCESS_ID IN ({ids_csv})"
        ).fetchall()
        return [row[0].strip() for row in rows if row[0] and row[0].strip()]
    except Exception:
        return []


def _show_view_or_table(node_name: str, default_database: Optional[str]) -> Tuple[str, str]:
    """
    Try SHOW VIEW first; if fails, try SHOW TABLE.
    Returns (object_type, ddl_text).
    object_type is "view" or "table".
    """
    qualified = _qualified_name_for_show(node_name, default_database)

    # SHOW VIEW
    try:
        ddl = _fetch_single_column_rows(f"SHOW VIEW {qualified};")
        if ddl:
            return "view", ddl
    except Exception:
        pass

    # SHOW TABLE
    ddl = _fetch_single_column_rows(f"SHOW TABLE {qualified};")
    return "table", ddl


def build_teradata_dependency_graph(
    sql_query: str,
    *,
    default_database: Optional[str] = None,
    max_depth: int = 50,
    store_ddl: bool = False,
    stop_at_feature_store_datasets: bool = True,
    expand_datasets_via_process_catalog: bool = True,
) -> Dict[str, Any]:
    """
    Builds a dependency graph by:
      1) analyzing the initial SQL via analyze_sql_query
      2) for each discovered source object:
           - SHOW VIEW and re-run analyze_sql_query on its DDL to expand dependencies
           - or SHOW TABLE and run analyze_teradata_ddl to attach PI/partition metadata

    Feature store dataset views (registered in the FS_V_DATASET_CATALOG) are treated
    as named "dataset" nodes when stop_at_feature_store_datasets=True (the default).
    Instead of drilling into their underlying SQL, the graph queries the dataset feature
    catalog (FS_V_{catalog}_FEATURES) to find which registered process views contribute
    to the dataset (one process = one view), and adds edges to those views directly.
    Set expand_datasets_via_process_catalog=False to treat datasets as pure leaves.

    Graph edges are parent -> child (parent depends on child).

    Returns:
      {
        "nodes": { node_name: { ...NodeInfo... }, ... },
        "edges": [ (parent, child), ... ],
        "roots": [ ...targets from initial SQL... ],
      }
    """
    # Pre-fetch the feature store dataset registry once (empty set if unavailable/disabled)
    _schema: Optional[str] = None
    _process_catalog_view: Optional[str] = None
    dataset_registry: Set[Tuple[str, str]] = set()
    if stop_at_feature_store_datasets:
        import tdfs4ds as _tdfs4ds
        _schema = _tdfs4ds.SCHEMA or default_database
        _catalog_view = f"FS_V_{_tdfs4ds.DATASET_CATALOG_NAME}_CATALOG"
        _process_catalog_view = _tdfs4ds.PROCESS_CATALOG_NAME_VIEW
        dataset_registry = _fetch_dataset_registry(_schema, _catalog_view)

    initial = analyze_sql_query(sql_query)
    roots = list(initial.get("target", []) or [])
    first_sources = list(initial.get("source", []) or [])

    nodes: Dict[str, NodeInfo] = {}
    edges: List[Tuple[str, str]] = []
    visited: Set[str] = set()

    def ensure_node(name: str) -> NodeInfo:
        if name not in nodes:
            db, obj = _parse_node_name(name)
            nodes[name] = NodeInfo(
                name=name,
                object_type="unknown",
                database=db,
                object=obj,
            )
        return nodes[name]

    # If the SQL has targets, connect each target -> each source as first-level edges.
    # If there's no target (pure SELECT), we treat sources as roots to expand.
    if roots:
        for t in roots:
            ensure_node(t).object_type = "view"  # could be table too; we can resolve later if needed
            for s in first_sources:
                ensure_node(s)
                edges.append((t, s))
    else:
        for s in first_sources:
            ensure_node(s)

    def expand_from(parent: Optional[str], obj_name: str, depth: int) -> None:
        if depth > max_depth:
            ensure_node(obj_name).error = f"max_depth {max_depth} exceeded"
            return

        if obj_name in visited:
            return
        visited.add(obj_name)

        node = ensure_node(obj_name)

        try:
            obj_type, ddl = _show_view_or_table(obj_name, default_database)
            node.object_type = obj_type
            if store_ddl:
                node.ddl = ddl

            if obj_type == "view":
                # Detect feature store dataset views
                if dataset_registry:
                    db_part, obj_part = _parse_node_name(obj_name)
                    if db_part is None:
                        db_part = default_database
                    key = (db_part.upper() if db_part else "", obj_part.upper())
                    if key in dataset_registry:
                        node.object_type = "dataset"
                        if expand_datasets_via_process_catalog and _schema and _process_catalog_view:
                            # Purge the pre-added edges to raw FS_T_... storage tables
                            # so only process-view edges remain.
                            # The dataset DDL embeds FEATURE_VERSION='<process_id>' in every
                            # subquery — those UUIDs map directly to PROCESS_ID in the
                            # process catalog, which stores the feature-engineering VIEW_NAME.
                            edges[:] = [e for e in edges if e[0] != obj_name]
                            process_ids = _extract_process_ids_from_dataset_ddl(ddl)
                            view_names  = _fetch_view_names_for_process_ids(
                                _schema, _process_catalog_view, process_ids
                            )
                            for view_name in view_names:
                                child_name = view_name.strip()
                                ensure_node(child_name)
                                edges.append((obj_name, child_name))
                                expand_from(obj_name, child_name, depth + 1)
                        return

                parsed = analyze_sql_query(ddl)
                children = list(parsed.get("source", []) or [])
                for child in children:
                    ensure_node(child)
                    # edge: view -> dependency
                    edges.append((obj_name, child))
                    expand_from(obj_name, child, depth + 1)

            elif obj_type == "table":
                # attach PI/partition metadata
                try:
                    node.table_info = analyze_teradata_ddl(ddl)
                except Exception as e:
                    node.error = f"analyze_teradata_ddl failed: {e}"

            else:
                node.error = "unknown object type"

        except Exception as e:
            node.error = str(e)

    # Expand:
    if roots:
        # expand the target(s) as well if you want full drill-down starting from produced object
        # but most people expand from the sources; still, expanding targets can be useful
        for t in roots:
            expand_from(None, t, 0)
        for s in first_sources:
            expand_from(None, s, 0)
    else:
        for s in first_sources:
            expand_from(None, s, 0)

    # de-duplicate edges while preserving order
    seen_e = set()
    edges_dedup: List[Tuple[str, str]] = []
    for e in edges:
        if e not in seen_e:
            edges_dedup.append(e)
            seen_e.add(e)

    # Prune nodes that are disconnected from all edges and not an explicit root.
    # This removes FS_T_... storage-table nodes whose edges were purged when their
    # parent was identified as a dataset and replaced with process-view edges.
    edge_nodes: Set[str] = set()
    for p, c in edges_dedup:
        edge_nodes.add(p)
        edge_nodes.add(c)
    root_set = set(roots)
    nodes_pruned = {
        k: asdict(v)
        for k, v in nodes.items()
        if k in edge_nodes or k in root_set
    }

    return {
        "nodes": nodes_pruned,
        "edges": edges_dedup,
        "roots": roots,
    }


# ----------------------------
# Optional: helper to build a "children adjacency" map, if you prefer that form
def graph_to_adjacency(graph: Dict[str, Any]) -> Dict[str, List[str]]:
    adj: Dict[str, List[str]] = {}
    for parent, child in graph.get("edges", []):
        adj.setdefault(parent, []).append(child)
    return adj


def graph_to_migration_manifest(
    graph: Dict[str, Any],
    *,
    filter_database: Optional[str] = None,
) -> Dict[str, Any]:
    """
    Converts a lineage graph into a migration manifest — a JSON-serialisable dict
    that lists every view and table discovered, with optional filtering to a single
    database (e.g. the feature store database).

    Useful for planning a feature store migration: objects whose database matches
    ``filter_database`` are the ones that need to be recreated or moved; edges
    between them describe the recreation order.

    Parameters
    ----------
    graph : dict
        Output of ``build_teradata_dependency_graph``.
    filter_database : str, optional
        When given, only nodes whose ``database`` field matches (case-insensitive)
        are included.  Edges whose source *or* target falls outside the filter are
        also excluded.  When None every node and edge is returned.

    Returns
    -------
    dict with keys:
        "views"  : list of dicts {database, name, type}
                   type is "view" or "dataset"
        "tables" : list of dicts {database, name, type, primary_index, partition_columns}
                   type is "table"
        "edges"  : list of dicts {from, to}  (parent depends on child)
    """
    nodes: Dict[str, Dict[str, Any]] = graph.get("nodes", {}) or {}
    edges: List[Tuple[str, str]]     = graph.get("edges", [])  or []

    def _label(name: str, meta: Dict[str, Any]) -> str:
        db  = meta.get("database") or ""
        obj = meta.get("object")   or ""
        return f"{db}.{obj}" if db and obj else name

    def _matches(meta: Dict[str, Any]) -> bool:
        if filter_database is None:
            return True
        db = (meta.get("database") or "")
        return db.upper() == filter_database.upper()

    views:  List[Dict[str, Any]] = []
    tables: List[Dict[str, Any]] = []
    included_labels: Set[str]    = set()

    for node_name, meta in nodes.items():
        if not _matches(meta):
            continue
        obj_type = (meta.get("object_type") or "unknown").lower()
        label    = _label(node_name, meta)
        included_labels.add(label)

        if obj_type in ("view", "dataset"):
            views.append({
                "database": meta.get("database") or "",
                "name":     meta.get("object")   or node_name,
                "type":     obj_type,
            })
        elif obj_type == "table":
            ti = meta.get("table_info") or {}
            tables.append({
                "database":         meta.get("database") or "",
                "name":             meta.get("object")   or node_name,
                "type":             "table",
                "primary_index":    ti.get("primary_index_columns") or [],
                "partition_columns": ti.get("partition_columns")    or [],
            })

    edge_list: List[Dict[str, str]] = []
    for parent, child in edges:
        p_meta = nodes.get(parent, {}) or {}
        c_meta = nodes.get(child,  {}) or {}
        p_label = _label(parent, p_meta)
        c_label = _label(child,  c_meta)
        if filter_database is not None:
            if p_label not in included_labels or c_label not in included_labels:
                continue
        edge_list.append({"from": p_label, "to": c_label})

    return {
        "views":  views,
        "tables": tables,
        "edges":  edge_list,
    }





def plot_lineage_sankey(
    graph: Dict[str, Any],
    *,
    title: str = "Lineage Sankey",
    max_label_len: int = 45,
    show_full_name_in_hover: bool = True,
) -> go.Figure:
    """
    Plot an interactive Sankey from a lineage graph like:
      {
        "nodes": {name: {name, object_type, database, object, table_info, error, ...}, ...},
        "edges": [(parent, child), ...],  # parent depends on child
        "roots": [...]
      }

    Hover displays relevant info (no DDL).
    Returns a plotly Figure.
    """

    nodes: Dict[str, Dict[str, Any]] = graph.get("nodes", {}) or {}
    edges: List[Tuple[str, str]] = graph.get("edges", []) or []

    # --- helpers ---
    def shorten(s: str, n: int) -> str:
        s = str(s)
        return s if len(s) <= n else (s[: n - 1] + "…")

    def format_table_info(ti: Optional[Dict[str, Any]]) -> str:
        if not ti:
            return ""
        pi = ti.get("primary_index_columns") or []
        parts = ti.get("partition_columns") or []
        lvls = ti.get("partitioning_levels") or []

        lines = []
        if pi:
            lines.append(f"PI: {', '.join(pi)}")
        if parts:
            lines.append(f"Partitions: {', '.join(parts)}")
        if lvls:
            kinds = ", ".join(
                [f"L{lvl.get('level')}:{lvl.get('kind')}" for lvl in lvls if isinstance(lvl, dict)]
            )
            if kinds:
                lines.append(f"Partitioning: {kinds}")
        return "<br>".join(lines)

    def hover_for(node_name: str) -> str:
        meta = nodes.get(node_name, {}) or {}
        obj_type = meta.get("object_type", "unknown")
        db = meta.get("database")
        obj = meta.get("object")
        err = meta.get("error")

        lines = []
        if show_full_name_in_hover:
            lines.append(f"<b>{node_name}</b>")
        else:
            lines.append(f"<b>{db}.{obj}</b>" if db and obj else f"<b>{node_name}</b>")

        lines.append(f"Type: <b>{obj_type}</b>")
        if db is not None:
            lines.append(f"DB: {db}")
        if obj is not None:
            lines.append(f"Object: {obj}")

        if obj_type == "table":
            ti = meta.get("table_info")
            ti_txt = format_table_info(ti)
            if ti_txt:
                lines.append(ti_txt)

        if err:
            lines.append(f"<span style='color:#b00020'>Error: {err}</span>")

        return "<br>".join(lines)

    # Collect node names seen in edges; also include isolated roots if any
    node_names_set = set()
    for p, c in edges:
        node_names_set.add(p)
        node_names_set.add(c)
    for r in graph.get("roots", []) or []:
        node_names_set.add(r)

    node_names = sorted(node_names_set)
    idx = {name: i for i, name in enumerate(node_names)}

    # Build labels and hover text
    labels = []
    hovers = []
    node_colors = []

    for name in node_names:
        meta = nodes.get(name, {}) or {}
        obj_type = (meta.get("object_type") or "unknown").lower()

        # Sankey labels should stay readable
        if meta.get("database") and meta.get("object"):
            label = f'{meta["database"]}.{meta["object"]}'
        else:
            label = name
        labels.append(shorten(label, max_label_len))

        hovers.append(hover_for(name))

        # Simple type-based coloring (feel free to tweak)
        if obj_type == "dataset":
            node_colors.append("rgba(210,105,30,0.80)")  # chocolate-ish (feature store dataset)
        elif obj_type == "view":
            node_colors.append("rgba(70,130,180,0.75)")  # steelblue-ish
        elif obj_type == "table":
            node_colors.append("rgba(46,139,87,0.75)")   # seagreen-ish
        else:
            node_colors.append("rgba(128,128,128,0.65)")

    # Sankey links (parent -> child). Value=1 per dependency by default.
    sources = [idx[p] for p, _ in edges if p in idx]
    targets = [idx[c] for _, c in edges if c in idx]
    values = [1] * len(sources)

    link_hover = [
        f"<b>{shorten(node_names[s], 120)}</b><br>depends on<br><b>{shorten(node_names[t], 120)}</b>"
        for s, t in zip(sources, targets)
    ]

    fig = go.Figure(
        data=[
            go.Sankey(
                arrangement="snap",
                node=dict(
                    pad=18,
                    thickness=18,
                    label=labels,
                    color=node_colors,
                    customdata=hovers,
                    hovertemplate="%{customdata}<extra></extra>",
                ),
                link=dict(
                    source=sources,
                    target=targets,
                    value=values,
                    customdata=link_hover,
                    hovertemplate="%{customdata}<extra></extra>",
                ),
            )
        ]
    )

    fig.update_layout(
        title=title,
        font=dict(size=12),
        hoverlabel=dict(align="left"),
        margin=dict(l=20, r=20, t=60, b=20),
    )

    return fig



def show_plotly_robust(fig, *, html_path: Optional[str] = None) -> None:
    """
    Display Plotly figure robustly across environments.

    - Tries normal fig.show() (Jupyter mime rendering)
    - Falls back to browser renderer if nbformat is missing
    - Optionally writes an HTML file
    """
    try:
        fig.show()
        return
    except ValueError as e:
        msg = str(e).lower()
        if "nbformat" in msg and "mime type rendering requires" in msg:
            # Fallback: open in browser
            pio.renderers.default = "browser"
            fig.show()
        else:
            raise

    if html_path:
        fig.write_html(html_path, include_plotlyjs="cdn", full_html=True)
        print(f"Wrote HTML to: {html_path}")
