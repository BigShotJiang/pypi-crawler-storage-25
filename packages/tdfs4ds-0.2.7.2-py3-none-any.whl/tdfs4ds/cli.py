"""
Command-line interface for tdfs4ds.

Entry points registered in setup.py:
  tdfs4ds-install-skills   →  cli.install_skills_cmd
"""

import argparse
import shutil
from pathlib import Path


# Canonical location of bundled skills inside the installed package
_SKILLS_SRC = Path(__file__).parent / "skills"


def install_skills(target_dir=None):
    """
    Copy bundled SKILL.md files to *target_dir*.

    Parameters
    ----------
    target_dir : str or Path, optional
        Destination directory.  Defaults to ``~/.claude/skills/`` (Claude Code
        user-level skills directory).

    Returns
    -------
    list[Path]
        Destination paths of every SKILL.md that was installed.
    """
    if target_dir is None:
        target_dir = Path.home() / ".claude" / "skills"

    target_dir = Path(target_dir)
    installed = []

    for skill_dir in sorted(_SKILLS_SRC.iterdir()):
        src_md = skill_dir / "SKILL.md"
        if not src_md.exists():
            continue
        dest_dir = target_dir / skill_dir.name
        dest_dir.mkdir(parents=True, exist_ok=True)
        dest_md = dest_dir / "SKILL.md"
        shutil.copy2(src_md, dest_md)
        print(f"  installed {skill_dir.name} -> {dest_md}")
        installed.append(dest_md)

    print(f"\n{len(installed)} skill(s) installed to {target_dir}")
    return installed


def install_skills_cmd():
    """Entry point: ``tdfs4ds-install-skills``."""
    parser = argparse.ArgumentParser(
        prog="tdfs4ds-install-skills",
        description="Install tdfs4ds Claude Code skills to a target directory.",
    )
    parser.add_argument(
        "--target",
        metavar="DIR",
        default=None,
        help=(
            "Destination directory for SKILL.md files "
            "(default: ~/.claude/skills/)"
        ),
    )
    args = parser.parse_args()
    install_skills(target_dir=args.target)


if __name__ == "__main__":
    install_skills_cmd()
