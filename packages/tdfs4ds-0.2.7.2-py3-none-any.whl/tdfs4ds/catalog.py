"""
Read-only catalog accessor functions for the tdfs4ds feature store.

These functions let you browse what is registered in the feature store:
features, processes, and datasets.  For discovery of entity IDs and feature
versions before calling build_dataset(), the lower-level helpers from
feature_store.feature_query_retrieval are also re-exported here.
"""

import tdfs4ds

from tdfs4ds.dataset.dataset_catalog import DatasetCatalog
from tdfs4ds.feature_store.feature_query_retrieval import (
    get_list_entity,
    get_available_features,
    get_feature_versions,
)


def feature_catalog(all_data_domains=False):
    """
    Retrieve a Teradata DataFrame of features registered in the feature store
    at the current (or time-travelled) valid time.

    Parameters
    ----------
    all_data_domains : bool, optional
        If False (default), only features belonging to the current DATA_DOMAIN
        are returned.  Set to True to return features from all data domains.
    """
    df = tdfs4ds.feature_store.feature_query_retrieval.list_features()
    if all_data_domains:
        print("[feature_catalog] Showing features for all DATA_DOMAINs.")
    else:
        print(
            f"[feature_catalog] Showing features for DATA_DOMAIN = '{tdfs4ds.DATA_DOMAIN}'. "
            "If the feature you are looking for is not here, it may belong to a different DATA_DOMAIN. "
            "Use feature_catalog(all_data_domains=True) to see all."
        )
        df = df[df.DATA_DOMAIN == tdfs4ds.DATA_DOMAIN]
    return df


def process_catalog(all_data_domains=False):
    """
    Retrieve a Teradata DataFrame of processes registered in the process store
    at the current (or time-travelled) valid time.

    Parameters
    ----------
    all_data_domains : bool, optional
        If False (default), only processes belonging to the current DATA_DOMAIN
        are returned.  Set to True to return processes from all data domains.
    """
    df = tdfs4ds.process_store.process_query_administration.list_processes()
    if all_data_domains:
        print("[process_catalog] Showing processes for all DATA_DOMAINs.")
    else:
        print(
            f"[process_catalog] Showing processes for DATA_DOMAIN = '{tdfs4ds.DATA_DOMAIN}'. "
            "If the process you are looking for is not here, it may belong to a different DATA_DOMAIN. "
            "Use process_catalog(all_data_domains=True) to see all."
        )
        df = df[df.DATA_DOMAIN == tdfs4ds.DATA_DOMAIN]
    return df


def dataset_catalog():
    """
    Retrieve a Teradata DataFrame of all datasets registered in the dataset catalog.
    """
    return DatasetCatalog(schema_name=tdfs4ds.SCHEMA, name=tdfs4ds.DATASET_CATALOG_NAME).catalog


def get_dataset_entity(dataset_id=None):
    """
    Return the entity definition (columns and types) for the given dataset ID.
    If dataset_id is None, returns entity info for all registered datasets.
    """
    return DatasetCatalog(schema_name=tdfs4ds.SCHEMA, name=tdfs4ds.DATASET_CATALOG_NAME).get_dataset_entity(dataset_id)


def get_dataset_features(dataset_id=None):
    """
    Return the feature list for the given dataset ID.
    If dataset_id is None, returns feature info for all registered datasets.
    """
    return DatasetCatalog(schema_name=tdfs4ds.SCHEMA, name=tdfs4ds.DATASET_CATALOG_NAME).get_dataset_features(dataset_id)
