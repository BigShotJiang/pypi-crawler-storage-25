"""
Dataset construction functions for the tdfs4ds feature store.

Provides build_dataset(), build_dataset_opt(), and augment_source_with_features()
for generating Teradata views that join feature tables with source data.
"""

import re

import tdfs4ds
import teradataml as tdml

from tdfs4ds.dataset.dataset_catalog import DatasetCatalog, Dataset
from tdfs4ds.feature_store.feature_query_retrieval import (
    get_available_entity_id_records,
    get_feature_location,
)


def build_dataset(entity_id, selected_features, view_name, schema_name=None, comment=None,
                  return_query=False, feature_store_time=False, join_type='INNER'):
    """
    Generate a SQL query and create a Teradata view to retrieve records for the specified
    entity IDs based on selected features.

    Parameters:
    ----------
    entity_id : list, dict, or str
        The entity IDs for which records are needed. Can be a list, dictionary, or string.
        - If list: contains multiple entity IDs.
        - If dict: keys are the entity IDs.
        - If str: a single entity ID.

    selected_features : dict
        A dictionary where the keys are feature table names, and the values are lists of tuples
        (feature_id, feature_version, feature_name) specifying the features to retrieve.
        NOTE: feature_version may be either:
          - a single UUID string, or
          - a list of dicts like:
              {"process_id": <UUID>, "process_view_name": <str>}

    view_name : str
        The name of the view to be created in the database.

    schema_name : str, optional
        The name of the database schema where the view will be created.
        Defaults to the global `tdfs4ds.SCHEMA` if not provided.

    comment : str, optional
        A comment to attach to the created view for documentation purposes. Defaults to None.

    return_query : bool, optional
        If True, the function will return the SQL query string instead of executing it.
        Defaults to False.

    feature_store_time : bool, optional
        If True, the query will use a specific `VALIDTIME` based on `tdfs4ds.FEATURE_STORE_TIME`.
        If False, the query will use `CURRENT VALIDTIME`. Defaults to False.

    join_type : str, optional
        Specifies the type of join to use between features: 'INNER' (default) or 'FULL OUTER'.

    Returns:
    -------
    str or tdml.DataFrame
        - If `return_query` is True, returns the generated SQL query as a string.
        - Otherwise, returns a Teradata DataFrame containing the results.

    Raises:
    ------
    ValueError
        If an invalid `join_type` is provided.
    """

    # Validate the join type
    if join_type not in ['INNER', 'FULL OUTER']:
        tdfs4ds.logger.error(f"{join_type} is not valid. Only 'INNER' and 'FULL OUTER' are authorized.")
        raise ValueError("Invalid join type. Use 'INNER' or 'FULL OUTER'.")

    # Default schema fallback if not provided
    if schema_name is None:
        schema_name = tdfs4ds.SCHEMA

    # Define the VALIDTIME clause based on feature store time
    if feature_store_time:
        if tdfs4ds.FEATURE_STORE_TIME is None:
            validtime_statement = 'CURRENT VALIDTIME'
        else:
            validtime_statement = f"VALIDTIME AS OF TIMESTAMP '{tdfs4ds.FEATURE_STORE_TIME}'"
    else:
        validtime_statement = 'CURRENT VALIDTIME'
    tdfs4ds.logger.info(f"VALIDTIME for the query: {validtime_statement}")

    # Retrieve the locations of features from the feature store
    tdfs4ds.logger.info("Retrieving the tables where the features are located.")
    list_features = get_feature_location(entity_id, selected_features)

    # Normalize entity_id into a list format for consistent processing
    if isinstance(entity_id, list):
        list_entity_id = entity_id
    elif isinstance(entity_id, dict):
        list_entity_id = list(entity_id.keys())
    else:
        list_entity_id = [entity_id]

    # Sort the entity ID list for consistent query generation
    list_entity_id.sort()

    def _sanitize_identifier(name: str) -> str:
        return re.sub(r'[^0-9A-Za-z_]', '_', name)

    used_alias_counts = {}

    def _unique_alias(base: str) -> str:
        if base not in used_alias_counts:
            used_alias_counts[base] = 1
            return base
        used_alias_counts[base] += 1
        return f"{base}_{used_alias_counts[base]}"

    # Initialize sub-query construction
    tdfs4ds.logger.info("Generating the sub-queries for feature retrieval.")
    sub_queries = []

    # Format entity ID columns for SQL query
    txt_entity = '\n ,'.join(['B1.' + e for e in list_entity_id])

    # Construct sub-queries for each feature
    for k, v in list_features.items():
        for feature_id, feature_version, feature_name in v:

            # Multiple processes: list of dicts
            if isinstance(feature_version, list):
                for item in feature_version:
                    process_id = item.get("process_id")
                    process_view_name = item.get("process_view_name") or "PROCESS"
                    base_alias = _sanitize_identifier(f"{feature_name}_{process_view_name}")
                    alias = _unique_alias(base_alias)

                    txt_where = f"(FEATURE_ID = {feature_id} AND FEATURE_VERSION='{process_id}')"
                    feature_str = ',B1.FEATURE_VALUE AS ' + alias

                    sub_queries.append(
                        {
                            'feature_name': alias,
                            'query': f"""
                            SEQUENCED VALIDTIME
                            SELECT
                               {txt_entity}
                              {feature_str}
                            FROM {k} B1
                            WHERE {txt_where}
                            """
                        }
                    )

            # Single UUID
            else:
                base_alias = _sanitize_identifier(feature_name)
                alias = _unique_alias(base_alias)

                txt_where = f"(FEATURE_ID = {feature_id} AND FEATURE_VERSION='{feature_version}')"
                feature_str = ',B1.FEATURE_VALUE AS ' + alias
                sub_queries.append(
                    {
                        'feature_name': alias,
                        'query': f"""
                        SEQUENCED VALIDTIME
                        SELECT
                           {txt_entity}
                          {feature_str}
                        FROM {k} B1
                        WHERE {txt_where}
                        """
                    }
                )

    # Handle case where no features are available
    if len(sub_queries) == 0:
        tdfs4ds.logger.warning("No features available for the specified entity IDs.")
        return

    # Generate SELECT clause for the final query
    if join_type == 'INNER':
        txt_entity = '\n ,'.join(['A1.' + e for e in list_entity_id])
    elif join_type == 'FULL OUTER':
        txt_entity = '\n ,'.join(
            [f"COALESCE({','.join(['A' + str(i) + '.' + e for i, _ in enumerate(sub_queries, 1)])}) AS {e}"
             for e in list_entity_id])

    select_query = f"""
          {txt_entity}
        , A1.{sub_queries[0]['feature_name']}
    """

    # Generate FROM and JOIN clauses for the final query
    from_query = f"""
    FROM ({sub_queries[0]['query']}) A1
    """

    for i, query_ in enumerate(sub_queries[1:], 2):
        select_query += f"\t, A{i}.{query_['feature_name']}\n"
        on_clause = ' AND '.join(['A1.' + c + '= A' + str(i) + '.' + c for c in list_entity_id])
        from_query += f"""
        {join_type} JOIN ({query_['query']}) A{i}
        ON {on_clause}
        """

    # Combine the clauses into the final query
    query = f"""
    {validtime_statement}
    SELECT {select_query}
    {from_query}
    """

    # Wrap the query as a view creation statement
    query = f"""
    REPLACE VIEW {schema_name}.{view_name} AS
    LOCK ROW FOR ACCESS
    {query}
    """
    tdfs4ds.logger.info(f"Creating the view {view_name} in the {schema_name} database.")
    tdml.execute_sql(query)

    # Add a comment to the created view, if provided
    if comment:
        tdfs4ds.logger.info(f"Adding a comment to the view {view_name} in the {schema_name} database.")
        tdml.execute_sql(f"COMMENT ON VIEW {schema_name}.{view_name} IS '{comment}'")

    # Build the dataset object
    tdfs4ds.logger.info(f"Creation of the dataset object.")
    dataset = Dataset(view_name=view_name, schema_name=schema_name)
    tdfs4ds.logger.info(f"Registering of the dataset in the dataset catalog.")
    DatasetCatalog(schema_name=tdfs4ds.SCHEMA, name=tdfs4ds.DATASET_CATALOG_NAME).add_dataset(dataset=dataset)

    # Return the query or the DataFrame based on the `return_query` flag
    if return_query:
        tdfs4ds.logger.info("Returning the generated dataset query.")
        return query
    else:
        tdfs4ds.logger.info("Returning the dataset as a Teradata DataFrame.")
        return tdml.DataFrame.from_table(tdml.in_schema(schema_name, view_name))


def build_dataset_opt(entity_id, selected_features, view_name=None, schema_name=None,
                      comment='dataset', no_temporal=False, time_manager=None, query_only=False,
                      entity_null_substitute={}, other=None, time_column=None,
                      filtermanager=None, filter_conditions=None):
    if schema_name is None:
        schema_name = tdfs4ds.SCHEMA
    dataset = augment_source_with_features(
        source_schema      = None,
        source_name        = None,
        entity_id          = entity_id,
        feature_selection  = selected_features,
        output_view_name   = view_name,
        output_view_schema = schema_name
    )
    return dataset


def augment_source_with_features(source_schema, source_name, entity_id, feature_selection,
                                  output_view_schema, output_view_name, join_type='LEFT JOIN'):
    """
    Augment a source table with selected features by creating a view that joins the source data
    with feature tables based on specified entity identifiers and feature selections.

    The join type can be specified as either 'LEFT JOIN' or 'INNER JOIN':
    - 'LEFT JOIN': Retains all rows from the source table, with missing values for unmatched features.
    - 'INNER JOIN': Returns only rows where all specified features have matching, non-missing values.

    Parameters:
    source_schema (str): The schema of the source table to augment.
    source_name (str): The name of the source table to augment.
    entity_id (str or list of str): The entity ID(s) for joining the source data with feature tables.
    feature_selection (list): A list of features to select and join with the source data.
    output_view_schema (str): The schema in which to create the output view.
    output_view_name (str): The name of the output view to create with augmented features.
    join_type (str, optional): 'LEFT JOIN' or 'INNER JOIN'. Defaults to 'LEFT JOIN'.

    Returns:
    tdml.DataFrame: A DataFrame object that references the newly created view.
    """

    # Convert entity_id to a list if provided as a single string
    if isinstance(entity_id, str):
        entity_id = [entity_id]

    # Retrieve feature locations (tables) for the selected features based on entity_id
    locations = get_feature_location(entity_id=entity_id, selected_features=feature_selection)

    # Initialize the SELECT part of the query with all columns from the source table
    query_select = f"""
    REPLACE VIEW {output_view_schema}.{output_view_name}
    AS LOCK ROW FOR ACCESS
    SELECT
        SOURCE.*
    """
    query_join = []
    counter = 1

    # Loop through each feature table and the associated list of features
    for feature_store_view, list_features in locations.items():
        for feature in list_features:
            table_name = 'A' + str(counter)
            query_select += '\n, ' + table_name + '.' + feature[2]

            on_clause = ' AND '.join(['SOURCE.' + c + '=' + table_name + '.' + c for c in entity_id])

            query_join.append(
                f"""
                {join_type}
                (CURRENT VALIDTIME
                SEL
                    A.*
                  , A.FEATURE_VALUE AS {feature[2]}
                  FROM {feature_store_view} A
                  WHERE FEATURE_ID = {feature[0]} AND FEATURE_VERSION = '{feature[1]}'
                ) {table_name}
                ON {on_clause}
                """
            )
            counter += 1

    if source_schema is None and source_name is None:
        query_available_features, list_features = get_available_entity_id_records(entity_id, feature_selection)
        query = query_select + '\n' + f'FROM ({query_available_features}) SOURCE \n' + '\n'.join(query_join)
    else:
        query = query_select + '\n' + f'FROM {source_schema}.{source_name} SOURCE \n' + '\n'.join(query_join)

    # Execute the SQL query to create the augmented view
    tdml.execute_sql(query)

    # Return a DataFrame reference to the newly created view
    try:
        return tdml.DataFrame.from_table(tdml.in_schema(output_view_schema, output_view_name))
    except Exception as e:
        print(str(e))
        return None
