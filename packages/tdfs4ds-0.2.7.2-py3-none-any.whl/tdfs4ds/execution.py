"""
Feature ingestion and process execution for the tdfs4ds feature store.

Core execution call chain:

    upload_features(df, entity_id, feature_names, ...)
      → register_process_view.__wrapped__(...)
      → execute_query(query_insert / query_insert_dist / query_insert_filtermanager)
      → run(process_id)
          → SELECT * FROM process_catalog WHERE PROCESS_ID = ?
          → _upload_features(df, entity_id, feature_names, feature_versions=process_id, ...)
              → Gettdtypes / update_varchar_length / validate_feature_types
              → register_entity / register_features
              → _compute_features_batch(...)  [once, or per-filter loop]
                  → followup_open
                  → prepare_feature_ingestion   # unpivots df into volatile table
                  → store_feature               # MERGE/UPDATE_INSERT into feature tables
                  → followup_close (COMPLETED)
              → apply_collect_stats(...)        # called once after all batches

    roll_out(process_list, time_manager, ...)
      → iterates time steps → run(process_id) per step
"""

import inspect
import uuid

import tdfs4ds
import teradataml as tdml
from tqdm.auto import tqdm

from tdfs4ds.dataset.builder import build_dataset
from tdfs4ds.utils.filter_management import FilterManager

# Default feature version applied when no explicit version is provided
_FEATURE_VERSION_DEFAULT = 'dev.0.0'


# ---------------------------------------------------------------------------
# Internal helpers
# ---------------------------------------------------------------------------

def _compute_features_batch(
    df, entity_id, feature_names, selected_features,
    primary_index, partitioning, entity_null_substitute,
    process_id, filtermanager, dataset_view_name, dataset_already_created
):
    """
    Execute one feature ingestion batch:
    followup_open → prepare → store → followup_close (COMPLETED) → optional dataset build.

    Returns (features_infos, dataset_or_None) on success.
    On failure: logs the error, attempts to record FAILED in the followup table, then re-raises.
    Callers that want to continue after a failure (e.g. the filtermanager loop) should wrap
    this call in their own try/except and use `continue` rather than re-raising.

    Does NOT call apply_collect_stats — the caller is responsible for that.
    """
    from tdfs4ds.feature_store.feature_data_processing import prepare_feature_ingestion, store_feature

    tdfs4ds.process_store.process_followup.followup_open(
        run_id        = tdfs4ds.RUN_ID,
        process_type  = tdfs4ds.PROCESS_TYPE,
        process_id    = process_id,
        filtermanager = filtermanager
    )
    dataset = None
    try:
        _, volatile_table, features_infos = prepare_feature_ingestion(
            df, entity_id, feature_names,
            feature_versions       = selected_features,
            primary_index          = primary_index,
            entity_null_substitute = entity_null_substitute,
            partitioning           = partitioning
        )
        store_feature(entity_id, volatile_table, entity_null_substitute,
                      primary_index, partitioning, features_infos)

        tdfs4ds.process_store.process_followup.followup_close(
            run_id        = tdfs4ds.RUN_ID,
            process_type  = tdfs4ds.PROCESS_TYPE,
            process_id    = process_id,
            filtermanager = filtermanager
        )
        tdfs4ds.logger_safe("info", "Feature ingestion completed for entity=%s", entity_id)

        if not dataset_already_created and (
            tdfs4ds.BUILD_DATASET_AT_UPLOAD or dataset_view_name is not None
        ):
            tdfs4ds.logger_safe("info", "Building dataset for validation...")
            try:
                dataset = build_dataset(entity_id, selected_features, view_name=dataset_view_name)
            except Exception as e:
                tdfs4ds.logger_safe("error", "Dataset build failed: %s", str(e).split('\n')[0])
                tdfs4ds.logger_safe("error", "entity=%s features=%s", entity_id, selected_features)
        else:
            tdfs4ds.logger_safe("info", "Dataset build disabled (BUILD_DATASET_AT_UPLOAD=False) and no dataset view name provided.")

        return features_infos, dataset

    except Exception as e:
        tdfs4ds.logger_safe("exception", "Feature ingestion failed for entity=%s", entity_id)
        try:
            tdfs4ds.process_store.process_followup.followup_close(
                run_id        = tdfs4ds.RUN_ID,
                process_type  = tdfs4ds.PROCESS_TYPE,
                process_id    = process_id,
                status        = 'FAILED,' + str(e).split('\n')[0],
                filtermanager = filtermanager
            )
        except Exception:
            pass  # followup_close raises on FAILED; swallow to preserve original exception
        raise


def _upload_features(
    df, entity_id, feature_names,
    feature_versions     = _FEATURE_VERSION_DEFAULT,
    primary_index        = None,
    partitioning         = '',
    filtermanager        = None,
    entity_null_substitute = {},
    process_id           = None,
    force_compute        = False,
    force_varchar_length = None,
    dataset_view_name    = None
):
    """
    Uploads a set of features into the Feature Store for a given entity.

    This function registers an entity and its associated features in the feature catalog
    if they are not already defined, prepares the data for ingestion, and stores it in the
    feature store. It also supports incremental feature computation and conditional execution
    depending on prior runs.

    Parameters
    ----------
    df : pandas.DataFrame
        Input dataframe containing entity keys and feature columns to upload.
    entity_id : str, list, or dict
        Identifier(s) for the entity.
    feature_names : list of str
        List of feature column names to upload from `df`.
    feature_versions : dict or str, optional
        Feature version(s). Default is _FEATURE_VERSION_DEFAULT ('dev.0.0').
    primary_index : str or list, optional
        Primary index for Teradata feature tables.
    partitioning : str, optional
        Partitioning clause. Default is ''.
    filtermanager : FilterManager, optional
        If provided, features are built iteratively per filter step.
    entity_null_substitute : dict, optional
        Replacement values for nulls in entity keys.
    process_id : str, optional
        Process execution identifier for follow-up logging.
    force_compute : bool, optional
        If True, forces recomputation even if already completed. Default is False.
    force_varchar_length : int, optional
        If provided, all VARCHAR feature columns are resized to this length.
    dataset_view_name : str, optional
        Name of the output dataset view to create after ingestion.

    Returns
    -------
    pandas.DataFrame or None
        If BUILD_DATASET_AT_UPLOAD is enabled, returns the built dataset. Otherwise None.
    """

    from tdfs4ds.feature_store.entity_management        import register_entity
    from tdfs4ds.feature_store.feature_store_management import Gettdtypes, register_features
    from tdfs4ds.feature_store.feature_data_processing  import (
        prepare_feature_ingestion, store_feature, apply_collect_stats
    )
    from tdfs4ds.utils.info import get_column_types, update_varchar_length

    # Convert entity_id to a dictionary if not already
    if isinstance(entity_id, list):
        entity_id.sort()
        entity_id = get_column_types(df, entity_id)
        tdfs4ds.logger_safe("debug", "entity_id converted to dict: %s", entity_id)
    elif isinstance(entity_id, str):
        entity_id = get_column_types(df, [entity_id])
        tdfs4ds.logger_safe("debug", "entity_id converted to dict: %s", entity_id)

    # Map feature versions
    if isinstance(feature_versions, list):
        selected_features = dict(zip(feature_names, feature_versions))
    else:
        selected_features = {k: feature_versions for k in feature_names}

    # Get Teradata types for features
    feature_names_types = Gettdtypes(df, features_columns=feature_names, entity_id=entity_id)

    if force_varchar_length is not None:
        tdfs4ds.logger_safe("debug", "Updating VARCHAR lengths with force_varchar_length=%s", force_varchar_length)
        feature_names_types = update_varchar_length(feature_names_types, new_varchar_length=force_varchar_length)

    def validate_feature_types(feature_names_types):
        invalid = {
            k: v['type'] for k, v in feature_names_types.items()
            if any(x in v['type'].lower() for x in ['clob', 'blob', 'json'])
        }
        if invalid:
            raise ValueError(
                f"Unsupported data types found: {invalid}. "
                "CLOB/BLOB/JSON are not supported."
            )

    validate_feature_types(feature_names_types)

    tdfs4ds.logger_safe("info", "Registering entity %s in feature store", entity_id)
    register_entity(entity_id, feature_names_types, primary_index=primary_index, partitioning=partitioning)

    if getattr(tdfs4ds, "DEBUG_MODE", False):
        tdfs4ds.logger_safe(
            "debug",
            "_upload_features entity_id=%s null_substitute=%s features=%s primary_index=%s partitioning=%s",
            entity_id, entity_null_substitute, feature_names, primary_index, partitioning
        )
        tdfs4ds.logger_safe("debug", "selected_features=%s df.columns=%s", selected_features, df.columns)

    register_features(entity_id, feature_names_types, primary_index, partitioning)
    tdfs4ds.logger_safe("info", "Features registered in catalog: %s", feature_names)

    follow_up = None
    if process_id and tdfs4ds.FEATURE_STORE_TIME:
        follow_up = tdfs4ds.process_store.process_followup.follow_up_report()
        follow_up = follow_up[
            (follow_up.STATUS == 'COMPLETED') &
            (follow_up.VALIDTIME_DATE.isna() == False) &
            (follow_up.VALIDTIME_DATE == tdfs4ds.FEATURE_STORE_TIME) &
            (follow_up.PROCESS_ID == process_id)
        ]

    if filtermanager is None:
        dataset_created = False
        do_compute = not (process_id and follow_up is not None and follow_up.shape[0] > 0)
        if not do_compute and not force_compute:
            tdfs4ds.logger_safe(
                "info",
                "Skipping computation for process_id=%s at time %s (already exists, force_compute=False)",
                process_id, tdfs4ds.FEATURE_STORE_TIME
            )
        if do_compute or force_compute:
            tdfs4ds.logger_safe("info", "Beginning feature ingestion for entity=%s", entity_id)
            features_infos, dataset = _compute_features_batch(
                df, entity_id, feature_names, selected_features,
                primary_index, partitioning, entity_null_substitute,
                process_id, filtermanager=None,
                dataset_view_name=dataset_view_name,
                dataset_already_created=False
            )
            apply_collect_stats(entity_id, primary_index, partitioning, features_infos)
            dataset_created = dataset is not None

    else:
        tdfs4ds.logger_safe("info", "FilterManager detected: %s filters to process", filtermanager.nb_filters)
        something_computed = False
        features_infos = None
        pbar = tqdm(
            range(filtermanager.nb_filters),
            total=filtermanager.nb_filters,
            desc="Applying filters",
            unit="filter",
            leave=False
        )
        dataset_created = False
        for i in pbar:
            filter_id = i + 1
            filtermanager.update(filter_id)

            try:
                pbar.set_description(f"Applying filter {filter_id}/{filtermanager.nb_filters}")

                # Convert datetime columns to string
                df_bar = filtermanager.display().to_pandas().astype(object)
                for col in df_bar.select_dtypes(include=["datetime", "datetimetz"]).columns:
                    df_bar[col] = df_bar[col].dt.strftime("%Y-%m-%d %H:%M:%S")

                # Convert to JSON object (dict)
                bar_info = df_bar.iloc[0].to_dict()

                from datetime import date, datetime
                for key, value in bar_info.items():
                    if isinstance(value, (date, datetime)):
                        bar_info[key] = value.strftime("%Y-%m-%d %H:%M:%S")

                bar_info = str(bar_info)
                if len(bar_info) > 120:
                    bar_info = bar_info[:117] + "..."
                pbar.set_postfix_str(bar_info)

            except Exception:
                pass  # postfix is optional

            tdfs4ds.logger_safe("debug", "Applying filter %s/%s:\n%s",
                i + 1, filtermanager.nb_filters, filtermanager.display())

            do_compute = True
            if process_id and tdfs4ds.FEATURE_STORE_TIME:
                follow_up = tdfs4ds.process_store.process_followup.follow_up_report(
                    process_id=process_id, filtermanager=filtermanager
                )
                follow_up = follow_up[
                    (follow_up.STATUS == 'COMPLETED') &
                    (follow_up.VALIDTIME_DATE.isna() == False) &
                    (follow_up.VALIDTIME_DATE == tdfs4ds.FEATURE_STORE_TIME)
                ]
                if follow_up.shape[0] > 0:
                    do_compute = False

            if not do_compute and not force_compute:
                tdfs4ds.logger_safe(
                    "info",
                    "Skipping computation for process_id=%s at time %s (already exists, force_compute=False)",
                    process_id, tdfs4ds.FEATURE_STORE_TIME
                )
                pbar.colour = "green"
            if do_compute or force_compute:
                pbar.colour = "blue"
                try:
                    batch_infos, ds = _compute_features_batch(
                        df, entity_id, feature_names, selected_features,
                        primary_index, partitioning, entity_null_substitute,
                        process_id, filtermanager=filtermanager,
                        dataset_view_name=dataset_view_name,
                        dataset_already_created=dataset_created
                    )
                    something_computed = True
                    features_infos = batch_infos
                    if ds is not None:
                        dataset_created = True
                except Exception as e:
                    tdfs4ds.logger_safe("error", "Filter %s/%s failed, continuing with next filter: %s",
                                        filter_id, filtermanager.nb_filters, str(e).split('\n')[0])
                    pbar.colour = "red"

        if something_computed and features_infos is not None:
            apply_collect_stats(entity_id, primary_index, partitioning, features_infos)

        if dataset_created == False and tdfs4ds.BUILD_DATASET_AT_UPLOAD and dataset_view_name is None:
            tdfs4ds.logger_safe("info", "Building dataset for validation...")
            try:
                dataset = build_dataset(entity_id, selected_features, view_name=dataset_view_name)
                return dataset
            except Exception as e:
                tdfs4ds.logger_safe("error", "Dataset build failed: %s", str(e).split('\n')[0])
                tdfs4ds.logger_safe("error", "entity=%s features=%s", entity_id, selected_features)
        else:
            if tdfs4ds.BUILD_DATASET_AT_UPLOAD == False:
                tdfs4ds.logger_safe("info", "Dataset build disabled (BUILD_DATASET_AT_UPLOAD=False) and no dataset view name provided.")
            else:
                return

        return


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def run(process_id, return_dataset=False, force_compute=False, force_varchar_length=None,
        dataset_view_name=None):
    """
    Execute a specific process from the feature store identified by the process ID.
    Uses global `logger` for diagnostics (gated by tdfs4ds.DISPLAY_LOGS).
    """

    if tdfs4ds.PROCESS_TYPE is None:
        PROCESS_TYPE_ = 'RUN PROCESS'
        tdfs4ds.RUN_ID = str(uuid.uuid4())
    else:
        PROCESS_TYPE_ = tdfs4ds.PROCESS_TYPE

    if getattr(tdfs4ds, "DEBUG_MODE", False):
        tdfs4ds.logger_safe("debug", "def run | tdfs4ds.FEATURE_STORE_TIME=%s", tdfs4ds.FEATURE_STORE_TIME)

    if tdfs4ds.FEATURE_STORE_TIME is None:
        validtime_statement = 'CURRENT VALIDTIME'
    else:
        validtime_statement = f"VALIDTIME AS OF TIMESTAMP '{tdfs4ds.FEATURE_STORE_TIME}'"

    query = f"""
    SELECT *
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.PROCESS_CATALOG_NAME_VIEW} A
    WHERE A.PROCESS_ID = '{process_id}'
    """

    tdfs4ds.logger_safe(
        "info",
        "Starting run | run_id=%s | process_type=%s | process_id=%s | return_dataset=%s | force_compute=%s | force_varchar_length=%s",
        tdfs4ds.RUN_ID, PROCESS_TYPE_, process_id, return_dataset, force_compute, force_varchar_length
    )

    df = tdml.DataFrame.from_query(query).to_pandas()

    if df.shape[0] != 1:
        tdfs4ds.logger_safe(
            "error",
            "Process catalog lookup returned %s record(s); expected 1. Check table %s.%s. Query: %s",
            df.shape[0], tdfs4ds.SCHEMA, tdfs4ds.PROCESS_CATALOG_NAME_VIEW, query.strip()
        )
        return

    # Fetching the filter manager
    filter_schema_name = df['FILTER_DATABASE_NAME'].values[0]
    if filter_schema_name is None:
        filtermanager = None
    else:
        filter_view_name  = df['FILTER_VIEW_NAME'].values[0]
        filter_table_name = df['FILTER_TABLE_NAME'].values[0]  # kept for parity
        filtermanager = FilterManager(table_name=filter_view_name, schema_name=filter_schema_name)

    # Fetching process metadata
    process_type   = df['PROCESS_TYPE'].values[0]
    primary_index  = df['FOR_PRIMARY_INDEX'].values[0]
    if primary_index is not None:
        primary_index = [x.strip() for x in primary_index.split(',') if x.strip()]
    partitioning   = df['FOR_DATA_PARTITIONING'].values[0]
    DATA_DOMAIN    = df['DATA_DOMAIN'].values[0]

    tdfs4ds.logger_safe(
        "info",
        "Process metadata | process_id=%s | process_type=%s | primary_index=%s | partitioning=%s | data_domain=%s | validtime=%s",
        process_id, process_type, primary_index, partitioning, DATA_DOMAIN, validtime_statement
    )

    # Handling 'denormalized view' process type
    if process_type == 'denormalized view':
        view_name              = df['VIEW_NAME'].values[0]
        entity_id              = [x.strip() for x in df['ENTITY_ID'].values[0].split(',') if x.strip()]
        entity_null_substitute = eval(df['ENTITY_NULL_SUBSTITUTE'].values[0])
        feature_names          = [x.strip() for x in df['FEATURE_NAMES'].values[0].split(',') if x.strip()]

        df_data = tdml.DataFrame(tdml.in_schema(view_name.split('.')[0], view_name.split('.')[1]))

        if getattr(tdfs4ds, "DEBUG_MODE", False):
            tdfs4ds.logger_safe("debug", "run | entity_id=%s", entity_id)
            tdfs4ds.logger_safe("debug", "run | entity_null_substitute=%s", entity_null_substitute)
            tdfs4ds.logger_safe("debug", "run | feature_names=%s", feature_names)
            tdfs4ds.logger_safe("debug", "run | process_id=%s", process_id)
            tdfs4ds.logger_safe("debug", "run | primary_index=%s", primary_index)
            tdfs4ds.logger_safe("debug", "run | partitioning=%s", partitioning)

        dataset = _upload_features(
            df_data,
            entity_id,
            feature_names,
            feature_versions=process_id,
            primary_index=primary_index,
            partitioning=partitioning,
            filtermanager=filtermanager,
            entity_null_substitute=entity_null_substitute,
            process_id=process_id,
            force_compute=force_compute,
            force_varchar_length=force_varchar_length,
            dataset_view_name=dataset_view_name
        )

    elif process_type == 'tdstone2 view':
        tdfs4ds.logger_safe("warning", "Process type 'tdstone2 view' not implemented yet for process_id=%s", process_id)
        dataset = None

    else:
        tdfs4ds.logger_safe("error", "Unknown process type '%s' for process_id=%s", process_type, process_id)
        dataset = None

    if return_dataset:
        tdfs4ds.logger_safe("info", "Run finished with dataset | run_id=%s | process_id=%s", tdfs4ds.RUN_ID, process_id)
        return dataset
    else:
        tdfs4ds.logger_safe("info", "Run finished without dataset | run_id=%s | process_id=%s", tdfs4ds.RUN_ID, process_id)
        return


def upload_features(
    df,
    entity_id,
    feature_names,
    metadata={},
    primary_index=None,
    partitioning='',
    filtermanager=None,
    entity_null_substitute={},
    force_compute=True,
    force_varchar_length=1024,
    dataset_view_name=None
):
    """
    Upload feature data from a DataFrame to the feature store for a specified entity.
    All diagnostics go through `logger_safe()` which respects `tdfs4ds.DISPLAY_LOGS`.
    """

    from tdfs4ds.utils.info import get_column_types
    from tdfs4ds.utils.query_management import execute_query
    from tdfs4ds.process_store.process_registration_management import register_process_view

    # Convert entity_id to a dictionary if it's not already one
    if isinstance(entity_id, list):
        entity_id.sort()
        entity_id = get_column_types(df, entity_id)
        tdfs4ds.logger_safe("debug", "entity_id converted to dict: %s", entity_id)
    elif isinstance(entity_id, str):
        entity_id = [entity_id]
        entity_id = get_column_types(df, entity_id)
        tdfs4ds.logger_safe("debug", "entity_id converted to dict: %s", entity_id)

    # Normalize feature_names
    if not isinstance(feature_names, list):
        tdfs4ds.logger_safe("debug", "feature_names is not a list: %s", feature_names)
        if isinstance(feature_names, str) and ',' in feature_names:
            feature_names = [x.strip() for x in feature_names.split(',')]
        else:
            feature_names = [feature_names]
        tdfs4ds.logger_safe("debug", "feature_names converted to list: %s", feature_names)
        tdfs4ds.logger_safe("debug", "Check the conversion is as expected.")

    # Normalize primary_index
    if primary_index is not None and not isinstance(primary_index, list):
        tdfs4ds.logger_safe("debug", "primary_index is not a list: %s", primary_index)
        if isinstance(primary_index, str) and ',' in primary_index:
            primary_index = [x.strip() for x in primary_index.split(',')]
        else:
            primary_index = [primary_index]
        tdfs4ds.logger_safe("debug", "primary_index converted to list: %s", primary_index)
        tdfs4ds.logger_safe("debug", "Check the conversion is as expected.")

    # Partitioning
    partitioning = tdfs4ds.utils.info.generate_partitioning_clause(partitioning=partitioning)

    tdfs4ds.logger_safe("debug", "filtermanager: %s", filtermanager)

    # Register process -> get SQL(s) + process_id
    query_insert, process_id, query_insert_dist, query_insert_filtermanager = register_process_view.__wrapped__(
        view_name       = df,
        entity_id       = entity_id,
        feature_names   = feature_names,
        metadata        = metadata,
        with_process_id = True,
        primary_index   = primary_index,
        partitioning    = partitioning,
        filtermanager   = filtermanager,
        entity_null_substitute = entity_null_substitute
    )

    tdfs4ds.logger_safe("info", "Registered process (process_id=%s) for upload_features", process_id)

    # Execute queries
    try:
        execute_query(query_insert)
        tdfs4ds.logger_safe("info", "Executed main insert query for process_id=%s", process_id)
    except Exception as e:
        tdfs4ds.logger_safe("exception", "Main insert query failed for process_id=%s", process_id)
        raise

    try:
        execute_query(query_insert_dist)
        tdfs4ds.logger_safe("info", "Executed distribution insert query for process_id=%s", process_id)
    except Exception as e:
        tdfs4ds.logger_safe("exception", "Distribution insert query failed for process_id=%s", process_id)
        raise

    if getattr(tdfs4ds, "DEBUG_MODE", False):
        tdfs4ds.logger_safe("debug", "query_insert_filtermanager: %s", query_insert_filtermanager)

    if query_insert_filtermanager is not None:
        try:
            execute_query(query_insert_filtermanager)
            tdfs4ds.logger_safe("info", "Executed filtermanager insert query for process_id=%s", process_id)
        except Exception as e:
            tdfs4ds.logger_safe("exception", "Filtermanager insert query failed for process_id=%s", process_id)
            raise

    # Run the registered process (with/without dataset)
    PROCESS_TYPE = tdfs4ds.PROCESS_TYPE
    tdfs4ds.PROCESS_TYPE = 'UPLOAD_FEATURES'
    if getattr(tdfs4ds, "BUILD_DATASET_AT_UPLOAD", False):
        tdfs4ds.PROCESS_TYPE = 'UPLOAD_FEATURES WITH DATASET VALIDATION'
    tdfs4ds.RUN_ID = str(uuid.uuid4())

    tdfs4ds.logger_safe(
        "info",
        "Starting run (run_id=%s, process_type=%s, process_id=%s, force_compute=%s, force_varchar_length=%s)",
        tdfs4ds.RUN_ID, tdfs4ds.PROCESS_TYPE, process_id, force_compute, force_varchar_length
    )

    try:
        if getattr(tdfs4ds, "BUILD_DATASET_AT_UPLOAD", False):
            dataset = run(
                process_id           = process_id,
                return_dataset       = True,
                force_compute        = force_compute,
                force_varchar_length = force_varchar_length,
                dataset_view_name    = dataset_view_name
            )
            tdfs4ds.logger_safe("info", "Run completed with dataset (run_id=%s, process_id=%s)", tdfs4ds.RUN_ID, process_id)
            return dataset
        else:
            run(
                process_id           = process_id,
                return_dataset       = False,
                force_compute        = force_compute,
                force_varchar_length = force_varchar_length,
                dataset_view_name    = dataset_view_name
            )
            tdfs4ds.logger_safe("info", "Run completed without dataset (run_id=%s, process_id=%s)", tdfs4ds.RUN_ID, process_id)
            return

    except Exception as e:
        try:
            tdfs4ds.process_store.process_followup.followup_close(
                run_id       = tdfs4ds.RUN_ID,
                process_type = tdfs4ds.PROCESS_TYPE,
                process_id   = process_id,
                status       = 'FAILED,' + str(e).split('\n')[0]
            )
        finally:
            tdfs4ds.logger_safe("exception", "Run failed (run_id=%s, process_id=%s): %s",
                tdfs4ds.RUN_ID, process_id, str(e).split('\n')[0])
        raise
    finally:
        tdfs4ds.PROCESS_TYPE = PROCESS_TYPE


def upload_tdstone2_scores(model):
    """
    Upload features from a tdstone2 model's predictions to the feature store.

    Handles the full workflow: extract feature names/types, register in the feature catalog,
    prepare for ingestion, store in the feature store, and build a dataset view.

    Parameters:
    - model: The tdstone2 model object whose predictions contain features to upload.

    Returns:
    - DataFrame: A DataFrame representing the dataset view created in the feature store.
    """

    from tdfs4ds.feature_store.entity_management import register_entity, tdstone2_entity_id
    from tdfs4ds.feature_store.feature_store_management import tdstone2_Gettdtypes, register_features
    from tdfs4ds.feature_store.feature_data_processing import prepare_feature_ingestion_tdstone2, store_feature

    entity_id = tdstone2_entity_id(model)
    register_entity(entity_id)

    feature_names_types = tdstone2_Gettdtypes(model, entity_id)
    register_features(entity_id, feature_names_types)

    if 'score' in [x[0] for x in inspect.getmembers(type(model))]:
        prepared_features, volatile_table_name = prepare_feature_ingestion_tdstone2(
            model.get_model_predictions(), entity_id
        )
    else:
        prepared_features, volatile_table_name = prepare_feature_ingestion_tdstone2(
            model.get_computed_features(), entity_id
        )

    store_feature(entity_id, prepared_features)
    tdml.execute_sql(f'DROP TABLE {volatile_table_name}')

    if 'score' in [x[0] for x in inspect.getmembers(type(model))]:
        selected_features = model.get_model_predictions().groupby(['FEATURE_NAME', 'ID_PROCESS']).count().to_pandas()[
            ['FEATURE_NAME', 'ID_PROCESS']].set_index('FEATURE_NAME').to_dict()['ID_PROCESS']
    else:
        selected_features = model.get_computed_features().groupby(['FEATURE_NAME', 'ID_PROCESS']).count().to_pandas()[
            ['FEATURE_NAME', 'ID_PROCESS']].set_index('FEATURE_NAME').to_dict()['ID_PROCESS']

    dataset = build_dataset(entity_id, selected_features, view_name=None)
    return dataset


def roll_out(process_list, time_manager, time_id_start=1, time_id_end=None,
             force_compute=False, force_display_logs=False):
    """
    Execute a series of processes for each date in a time manager, managing time,
    computation settings, and logging.

    Iterates over a range of time steps, updating the TimeManager with each step,
    and executes all processes in process_list for that time step.

    Parameters:
    - process_list (list): List of process IDs to execute for each time step.
    - time_manager (TimeManager): Object that manages time-related operations.
    - time_id_start (int, optional): Starting time step ID. Default is 1.
    - time_id_end (int, optional): Ending time step ID. If None, runs until last step.
    - force_compute (bool, optional): Force recomputation even if results exist. Default False.
    - force_display_logs (bool, optional): Force log display during rollout. Default False.
    """

    temp_DISPLAY_LOGS = tdfs4ds.DISPLAY_LOGS
    tdfs4ds.DISPLAY_LOGS = False
    if force_display_logs:
        tdfs4ds.DISPLAY_LOGS = True
    PROCESS_TYPE = tdfs4ds.PROCESS_TYPE
    tdfs4ds.PROCESS_TYPE = 'ROLL_OUT'
    tdfs4ds.RUN_ID = str(uuid.uuid4())

    try:
        if time_id_end is None:
            time_range = range(time_id_start, time_manager.nb_time_steps + 1)
        else:
            time_range = range(time_id_start, min(time_manager.nb_time_steps + 1, time_id_end + 1))

        pbar = tqdm(time_range, desc="Starting rollout", unit="step")

        for i in pbar:
            time_manager.update(time_id=i)
            date_ = str(time_manager.display()['BUSINESS_DATE'].values[0])

            tdfs4ds.FEATURE_STORE_TIME = time_manager.get_date_in_the_past()
            pbar.set_postfix(time=date_, feature_time=tdfs4ds.FEATURE_STORE_TIME)

            if tdfs4ds.DEBUG_MODE:
                print("roll_out | date_:", date_)
                print("roll_out | feature_store_time:", tdfs4ds.FEATURE_STORE_TIME)

            for proc_id in process_list:
                pbar.set_description(f"Processing {date_} | proc {proc_id}")
                run(process_id=proc_id, force_compute=force_compute)

        tdfs4ds.DISPLAY_LOGS = temp_DISPLAY_LOGS

    except Exception as e:
        tdfs4ds.DISPLAY_LOGS = temp_DISPLAY_LOGS
        print(str(e).split('\n')[0])
        tdfs4ds.PROCESS_TYPE = PROCESS_TYPE
        raise

    tdfs4ds.PROCESS_TYPE = PROCESS_TYPE
