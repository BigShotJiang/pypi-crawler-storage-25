"""
LangGraph-based orchestration for the tdfs4ds consumer agent.

Flow::

    START -> node_classify -> node_detect_domain -> [conditional on intent] -> node_skill_* -> node_synthesize -> END
"""

from __future__ import annotations

from typing import Annotated, Optional, Union

from langchain_core.messages import HumanMessage
from langgraph.graph import StateGraph, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import MemorySaver
from typing_extensions import TypedDict

import tdfs4ds
from tdfs4ds.agent.consumer_agent import (
    intent_classifier,
    get_data_domain,
    detect_data_domain_for_object,
    skill_search,
    skill_definition,
    skill_usage,
    skill_freshness,
    skill_summary,
    skill_lineage,
    skill_explain,
    skill_dataset,
    skill_propose_features,
    skill_check_dataset_name,
    synthesize_answer,
)


# ═══════════════════════════════════════════════════════════════════════════
# State
# ═══════════════════════════════════════════════════════════════════════════

class AgentState(TypedDict):
    question: str
    intent: Optional[str]
    object_name: Optional[str]
    domain: Optional[str]
    skill_result: Optional[dict]
    answer: Optional[str]
    messages: Annotated[list, add_messages]
    # DATA_DOMAIN resolution
    resolved_data_domain: Optional[str]   # domain selected for this turn
    available_data_domains: Optional[list]  # all domains found in the store
    # Object resolution — persisted across turns for pronoun-only follow-ups
    resolved_object_name: Optional[str]   # last explicitly named feature/dataset (canonical)
    # Feature triplet — persisted after any successful catalog resolution
    resolved_feature_triplet: Optional[dict]  # {feature_name, entity_name, process_id, view_name}
    # Entity / feature-group context — persisted across turns
    resolved_entity_name: Optional[str]   # entity currently in focus (e.g. "CustomerID")
    resolved_feature_list: Optional[list]  # feature names in current focus (1 or many)
    # Multi-turn pending actions (e.g. dataset creation flow)
    pending_action: Optional[str]         # e.g. "awaiting_dataset_name"
    pending_action_context: Optional[dict]  # e.g. {"feature_name": "..."}


# ═══════════════════════════════════════════════════════════════════════════
# Nodes
# ═══════════════════════════════════════════════════════════════════════════

_DATASET_PENDING_ACTIONS = {
    "awaiting_feature_selection",
    "awaiting_feature_confirmation",
    "awaiting_dataset_name",
}


def node_classify(state: AgentState) -> dict:
    """Run intent classification on the user question.

    Short-circuits the LLM classifier for all dataset-creation pending states so
    that the user's reply is routed directly to the dataset skill without being
    misclassified.
    """
    if state.get("pending_action") in _DATASET_PENDING_ACTIONS:
        return {"intent": "DATASET", "object_name": state["question"].strip(), "domain": None}
    result = intent_classifier(state["question"])
    return {
        "intent": result.intent,
        "object_name": result.object_name,
        "domain": result.domain,
    }


def node_detect_domain(state: AgentState) -> dict:
    """Detect the DATA_DOMAIN for the requested object and list all available domains.

    Remembers the resolved domain and the last explicitly named object across turns
    (persisted via MemorySaver).  When a follow-up question uses a pronoun ("it",
    "cette feature") without naming an object, the previously resolved object and
    domain are reused automatically.
    """
    domains_df = get_data_domain()
    available = domains_df["DATA_DOMAIN"].tolist() if not domains_df.empty else []

    # Keep the domain/object already resolved unless we find explicit ones this turn
    current_resolved_domain = state.get("resolved_data_domain") or tdfs4ds.DATA_DOMAIN
    current_resolved_object = state.get("resolved_object_name")

    object_name = state.get("object_name")
    resolved_domain = current_resolved_domain
    resolved_object = object_name if object_name else current_resolved_object

    if object_name:
        detected = detect_data_domain_for_object(object_name)
        if detected:
            resolved_domain = detected

    return {
        "resolved_data_domain": resolved_domain,
        "available_data_domains": available,
        "resolved_object_name": resolved_object,
    }


def _with_domain(domain: Optional[str]):
    """Context manager that temporarily sets ``tdfs4ds.DATA_DOMAIN``."""
    from contextlib import contextmanager

    @contextmanager
    def _cm():
        if domain is None:
            yield
            return
        old = tdfs4ds.DATA_DOMAIN
        tdfs4ds.DATA_DOMAIN = domain
        try:
            yield
        finally:
            tdfs4ds.DATA_DOMAIN = old

    return _cm()


def _extract_triplet(skill_result: Optional[dict]) -> Optional[dict]:
    """Pull ``resolved_triplet`` from a skill result if present and non-empty."""
    if not skill_result:
        return None
    triplet = skill_result.get("resolved_triplet")
    if isinstance(triplet, dict) and triplet.get("feature_name"):
        return triplet
    return None


def _skill_with_triplet(skill_result: dict) -> dict:
    """Build state-update dict from a skill result, propagating triplet when resolved."""
    updates = {"skill_result": skill_result}
    triplet = _extract_triplet(skill_result)
    if triplet:
        updates["resolved_feature_triplet"] = triplet
        updates["resolved_object_name"] = triplet["feature_name"]
        if triplet.get("entity_name"):
            updates["resolved_entity_name"] = triplet["entity_name"]
        updates["resolved_feature_list"] = [triplet["feature_name"]]
    return updates


def _hint_view(state: AgentState) -> Optional[str]:
    """Return the remembered view_name only when this turn has no explicit object.

    When the user names something explicitly, we re-resolve rather than reuse
    the stale hint so that a new feature mentioned in the same thread is handled
    correctly.
    """
    if state.get("object_name"):
        return None
    triplet = state.get("resolved_feature_triplet") or {}
    return triplet.get("view_name") or None


def _effective_object(state: AgentState) -> str:
    """Return the object name: explicit > canonical from triplet > remembered raw."""
    explicit = state.get("object_name")
    if explicit:
        return explicit
    triplet = state.get("resolved_feature_triplet")
    if triplet and triplet.get("feature_name"):
        return triplet["feature_name"]
    return state.get("resolved_object_name") or ""


def node_skill_search(state: AgentState) -> dict:
    """Execute the search skill."""
    with _with_domain(state.get("resolved_data_domain")):
        return {"skill_result": skill_search(state["question"])}


def node_skill_definition(state: AgentState) -> dict:
    """Execute the definition skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_definition(
            state["question"],
            _effective_object(state),
            hint_entity_name=state.get("resolved_entity_name"),
        )
    return _skill_with_triplet(result)


def node_skill_usage(state: AgentState) -> dict:
    """Execute the usage skill."""
    with _with_domain(state.get("resolved_data_domain")):
        return {"skill_result": skill_usage(state["question"], _effective_object(state))}


def node_skill_freshness(state: AgentState) -> dict:
    """Execute the freshness skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_freshness(
            state["question"],
            _effective_object(state),
            hint_entity_name=state.get("resolved_entity_name"),
        )
    return _skill_with_triplet(result)


def node_skill_summary(state: AgentState) -> dict:
    """Execute the summary skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_summary(state["question"], state.get("domain"))
    updates: dict = {"skill_result": result}
    # Capture feature group context from summary results
    feature_names_by_entity = result.get("feature_names_by_entity") or {}
    all_feature_names = result.get("feature_names") or []
    if all_feature_names:
        updates["resolved_feature_list"] = all_feature_names
    # If the summary covered exactly one entity, remember it
    if len(feature_names_by_entity) == 1:
        updates["resolved_entity_name"] = next(iter(feature_names_by_entity))
    return updates


def node_skill_lineage(state: AgentState) -> dict:
    """Execute the lineage skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_lineage(state["question"], _effective_object(state), hint_view_name=_hint_view(state))
    return _skill_with_triplet(result)


def node_skill_explain(state: AgentState) -> dict:
    """Execute the explain skill."""
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_explain(state["question"], _effective_object(state), hint_view_name=_hint_view(state))
    return _skill_with_triplet(result)


def node_skill_dataset(state: AgentState) -> dict:
    """Execute the dataset availability skill — handles a 4-step creation flow.

    Step 0 (no pending): look up datasets that expose the feature.
    Step 1 (``awaiting_feature_selection``): user described their use case →
        LLM proposes top-20 relevant features (or all if ≤ 20).
    Step 2 (``awaiting_feature_confirmation``): user replied 'ok' or 'all' →
        record selection and ask for a dataset name.
    Step 3 (``awaiting_dataset_name``): user provided a name → validate it.
    """
    pending = state.get("pending_action")
    context = state.get("pending_action_context") or {}

    # ── Step 1: use-case → feature proposal ───────────────────────────────
    if pending == "awaiting_feature_selection":
        use_case = state["question"]
        entity_name = context.get("entity_name", "")
        all_features = context.get("all_features", [])
        with _with_domain(state.get("resolved_data_domain")):
            result = skill_propose_features(use_case, entity_name, all_features, top_n=20)
        new_context = {
            **context,
            "proposed_features": result.get("proposed_features", []),
            "include_all_offered": result.get("include_all_offered", False),
        }
        return {
            "skill_result": result,
            "pending_action": "awaiting_feature_confirmation",
            "pending_action_context": new_context,
        }

    # ── Step 2: confirm selection (ok / all) ──────────────────────────────
    if pending == "awaiting_feature_confirmation":
        user_msg = state["question"].strip().lower()
        include_all = any(w in user_msg.split() for w in ("all", "tout", "tous", "toutes"))
        new_context = {**context, "include_all": include_all}
        return {
            "skill_result": {
                "status": "features_confirmed",
                "include_all": include_all,
                "proposed_features": context.get("proposed_features", []),
                "feature_count": context.get("feature_count", 0),
            },
            "pending_action": "awaiting_dataset_name",
            "pending_action_context": new_context,
        }

    # ── Step 3: name check ────────────────────────────────────────────────
    if pending == "awaiting_dataset_name":
        proposed_name = state["question"].strip()
        feature_name = context.get("feature_name", "")
        with _with_domain(state.get("resolved_data_domain")):
            result = skill_check_dataset_name(proposed_name, feature_name)
        # Enrich available result with the feature selection context
        if result.get("status") == "name_available":
            result = {
                **result,
                "include_all": context.get("include_all", False),
                "proposed_features": context.get("proposed_features", []),
                "feature_count": context.get("feature_count", 0),
            }
        updates: dict = {"skill_result": result}
        if result.get("status") == "name_available":
            updates["pending_action"] = None
            updates["pending_action_context"] = None
        # name_taken → leave pending_action so the next turn loops back
        return updates

    # ── Step 0: initial lookup ────────────────────────────────────────────
    effective_obj = _effective_object(state)
    with _with_domain(state.get("resolved_data_domain")):
        result = skill_dataset(state["question"], effective_obj)
    updates = _skill_with_triplet(result)
    if result.get("status") == "no_dataset":
        updates["pending_action"] = "awaiting_feature_selection"
        updates["pending_action_context"] = {
            "feature_name": effective_obj,
            "entity_name": result.get("entity_name", ""),
            "all_features": result.get("all_features", []),
            "feature_count": result.get("feature_count", 0),
        }
    else:
        updates["pending_action"] = None
        updates["pending_action_context"] = None
    return updates


def node_synthesize(state: AgentState) -> dict:
    """Synthesize a natural language answer from the skill result."""
    answer = synthesize_answer(state["question"], state["skill_result"], state["intent"])
    return {"answer": answer}


# ═══════════════════════════════════════════════════════════════════════════
# Routing
# ═══════════════════════════════════════════════════════════════════════════

def _route_intent(state: AgentState) -> str:
    """Return the node name corresponding to the classified intent."""
    return {
        "SEARCH": "skill_search",
        "DEFINITION": "skill_definition",
        "USAGE": "skill_usage",
        "FRESHNESS": "skill_freshness",
        "SUMMARY": "skill_summary",
        "LINEAGE": "skill_lineage",
        "EXPLAIN": "skill_explain",
        "DATASET": "skill_dataset",
    }.get(state["intent"], "skill_search")


# ═══════════════════════════════════════════════════════════════════════════
# Graph builder
# ═══════════════════════════════════════════════════════════════════════════

def build_graph():
    """Build and compile the LangGraph StateGraph.

    Returns:
        A compiled LangGraph with MemorySaver checkpointer for multi-turn support.
    """
    graph = StateGraph(AgentState)

    # Add nodes
    graph.add_node("classify", node_classify)
    graph.add_node("detect_domain", node_detect_domain)
    graph.add_node("skill_search", node_skill_search)
    graph.add_node("skill_definition", node_skill_definition)
    graph.add_node("skill_usage", node_skill_usage)
    graph.add_node("skill_freshness", node_skill_freshness)
    graph.add_node("skill_summary", node_skill_summary)
    graph.add_node("skill_lineage", node_skill_lineage)
    graph.add_node("skill_explain", node_skill_explain)
    graph.add_node("skill_dataset", node_skill_dataset)
    graph.add_node("synthesize", node_synthesize)

    # Entry point
    graph.set_entry_point("classify")

    # classify always feeds into detect_domain
    graph.add_edge("classify", "detect_domain")

    # Conditional routing from detect_domain to skill nodes
    graph.add_conditional_edges(
        "detect_domain",
        _route_intent,
        {
            "skill_search": "skill_search",
            "skill_definition": "skill_definition",
            "skill_usage": "skill_usage",
            "skill_freshness": "skill_freshness",
            "skill_summary": "skill_summary",
            "skill_lineage": "skill_lineage",
            "skill_explain": "skill_explain",
            "skill_dataset": "skill_dataset",
        },
    )

    # All skill nodes lead to synthesize
    for skill_node in ("skill_search", "skill_definition", "skill_usage",
                       "skill_freshness", "skill_summary", "skill_lineage", "skill_explain",
                       "skill_dataset"):
        graph.add_edge(skill_node, "synthesize")

    # Synthesize leads to END
    graph.add_edge("synthesize", END)

    memory = MemorySaver()
    return graph.compile(checkpointer=memory)


# ═══════════════════════════════════════════════════════════════════════════
# Trace builder
# ═══════════════════════════════════════════════════════════════════════════

_SKILL_LABEL = {
    "SEARCH": "skill_search",
    "DEFINITION": "skill_definition",
    "USAGE": "skill_usage",
    "FRESHNESS": "skill_freshness",
    "SUMMARY": "skill_summary",
    "LINEAGE": "skill_lineage",
    "EXPLAIN": "skill_explain",
    "DATASET": "skill_dataset",
}


def _build_trace_md(state: dict) -> str:
    """Build a markdown trace of the agent execution from the final state.

    Args:
        state: Final state dict returned by the graph after invocation.

    Returns:
        Markdown-formatted string describing intent, skill, and result.
    """
    parts: list[str] = []

    # ── Intent classification ──────────────────────────────────────────────
    intent = state.get("intent") or "unknown"
    object_name = state.get("object_name")
    resolved_object = state.get("resolved_object_name")
    domain = state.get("domain")

    parts.append("## Intent Classification")
    parts.append(f"- **Intent**: `{intent}`")
    if object_name:
        parts.append(f"- **Object (this turn)**: `{object_name}`")
    if resolved_object and resolved_object != object_name:
        parts.append(f"- **Object (remembered)**: `{resolved_object}`")
    elif resolved_object and not object_name:
        parts.append(f"- **Object**: `{resolved_object}` _(remembered from previous turn)_")
    if domain:
        parts.append(f"- **Domain**: `{domain}`")

    # ── Resolved feature triplet ───────────────────────────────────────────
    triplet = state.get("resolved_feature_triplet")
    resolved_entity = state.get("resolved_entity_name")
    resolved_feature_list = state.get("resolved_feature_list") or []
    if triplet and triplet.get("feature_name"):
        parts.append("\n## Feature Context (remembered)")
        parts.append(f"- **Feature**: `{triplet['feature_name']}`")
        if triplet.get("entity_name"):
            parts.append(f"- **Entity**: `{triplet['entity_name']}`")
        if triplet.get("process_id"):
            parts.append(f"- **Process ID**: `{triplet['process_id']}`")
        if triplet.get("view_name"):
            parts.append(f"- **Process View**: `{triplet['view_name']}`")
    elif resolved_entity or resolved_feature_list:
        parts.append("\n## Feature Context (remembered)")
        if resolved_entity:
            parts.append(f"- **Entity**: `{resolved_entity}`")
    if resolved_feature_list and len(resolved_feature_list) > 1:
        parts.append(f"- **Feature group** ({len(resolved_feature_list)}): "
                     + ", ".join(f"`{f}`" for f in resolved_feature_list))

    # ── Pending action ─────────────────────────────────────────────────────
    pending = state.get("pending_action")
    if pending:
        ctx = state.get("pending_action_context") or {}
        parts.append("\n## Pending Action")
        parts.append(f"- **Action**: `{pending}`")
        for k, v in ctx.items():
            parts.append(f"- **{k}**: `{v}`")

    # ── DATA_DOMAIN detection ──────────────────────────────────────────────
    resolved_dd = state.get("resolved_data_domain")
    available_dd = state.get("available_data_domains") or []

    parts.append("\n## DATA_DOMAIN")
    if available_dd:
        parts.append(f"- **Available**: {', '.join(f'`{d}`' for d in available_dd)}")
    else:
        parts.append("- **Available**: _(none found)_")
    if resolved_dd:
        source = "detected from object" if object_name else "remembered from previous turn"
        parts.append(f"- **Active**: `{resolved_dd}` _{source}_")
    else:
        parts.append("- **Active**: _(fallback to tdfs4ds.DATA_DOMAIN)_")

    # ── Skill executed ─────────────────────────────────────────────────────
    skill_name = _SKILL_LABEL.get(intent, "skill_search")
    parts.append("\n## Skill Executed")
    parts.append(f"- **Skill**: `{skill_name}`")
    if object_name:
        parts.append(f"- **Input object**: `{object_name}`")
    if domain:
        parts.append(f"- **Input domain**: `{domain}`")

    # ── Skill result ───────────────────────────────────────────────────────
    skill_result = state.get("skill_result") or {}
    if skill_result:
        parts.append("\n## Skill Result")
        if "error" in skill_result:
            parts.append(f"- **Error**: `{skill_result['error']}`")
            if "diagnostic" in skill_result:
                parts.append("\n### Diagnostic steps")
                for step in skill_result["diagnostic"].split("; "):
                    parts.append(f"- {step}")
        else:
            for key, val in skill_result.items():
                if key in ("available_context", "plain_summary", "explanation", "docs_sources"):
                    continue
                if key == "dependencies" and isinstance(val, list):
                    parts.append(f"- **dependencies** ({len(val)} nodes):")
                    for dep in val:
                        indent = "  " * dep.get("depth", 0)
                        parts.append(f"  {indent}- `{dep['name']}` ({dep['type']})")
                elif isinstance(val, list):
                    parts.append(f"- **{key}**: {len(val)} item(s)")
                elif isinstance(val, dict):
                    parts.append(f"- **{key}**: {len(val)} entries")
                elif isinstance(val, str) and len(val) > 300:
                    parts.append(f"- **{key}**: {val[:300]}…")
                else:
                    parts.append(f"- **{key}**: {val}")

    # ── Documentation sources ──────────────────────────────────────────────
    docs_sources = (skill_result or {}).get("docs_sources") or []
    if docs_sources:
        parts.append("\n## Documentation Sources")
        for src in docs_sources:
            parts.append(f"- `{src}`")

    return "\n".join(parts)


# ═══════════════════════════════════════════════════════════════════════════
# Graph singleton — keeps MemorySaver alive across turns
# ═══════════════════════════════════════════════════════════════════════════

_graph_instance = None


def _get_graph():
    """Return the shared compiled graph, building it once on first call."""
    global _graph_instance
    if _graph_instance is None:
        _graph_instance = build_graph()
    return _graph_instance


# ═══════════════════════════════════════════════════════════════════════════
# Entry point
# ═══════════════════════════════════════════════════════════════════════════

def consumer_agent(
    question: str,
    thread_id: str = "default",
    return_trace: bool = False,
) -> Union[str, tuple[str, str]]:
    """Run the LangGraph agent for a single conversational turn.

    Args:
        question: User question in natural language (French or English).
        thread_id: Conversation thread ID for multi-turn memory.
        return_trace: When True, returns ``(answer, trace_md)`` where
            ``trace_md`` is a Markdown string describing the intent,
            skill, and result. When False (default), returns only the
            answer string.

    Returns:
        Answer string, or ``(answer, trace_md)`` tuple when
        ``return_trace=True``.
    """
    graph = _get_graph()
    result = graph.invoke(
        {"question": question, "messages": [HumanMessage(content=question)]},
        config={"configurable": {"thread_id": thread_id}},
    )
    answer = result["answer"]

    if return_trace:
        return answer, _build_trace_md(result)
    return answer
