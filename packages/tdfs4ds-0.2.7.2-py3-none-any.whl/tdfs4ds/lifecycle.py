"""
Lifecycle management for the tdfs4ds feature store.

Contains setup() and connect() — the two initialization functions that must
be called once at the start of every session.
"""

import tdfs4ds
import teradataml as tdml

from tdfs4ds.dataset.dataset_catalog import DatasetCatalog


def setup(database, if_exists='fail'):
    """
    Initialize the feature store environment by creating catalog tables and views.
    """

    from tdfs4ds.feature_store.feature_store_management import feature_store_catalog_creation
    from tdfs4ds.process_store.process_store_catalog_management import process_store_catalog_creation

    tdfs4ds.SCHEMA = database
    tdfs4ds.logger_safe("info", "Setting up feature store in database: %s", database)

    if if_exists == 'replace':
        tdfs4ds.logger_safe("info", "Replacing existing catalog tables if they exist.")
        for table in [tdfs4ds.FEATURE_CATALOG_NAME, tdfs4ds.PROCESS_CATALOG_NAME, tdfs4ds.DATA_DISTRIBUTION_NAME]:
            try:
                tdml.db_drop_table(table_name=table, schema_name=database)
                tdfs4ds.logger_safe("info", "Dropped table %s.%s", database, table)
            except Exception as e:
                tdfs4ds.logger_safe("warning", "Could not drop table %s.%s: %s", database, table, str(e).split('\n')[0])

        DatasetCatalog(schema_name=database, name=tdfs4ds.DATASET_CATALOG_NAME).drop_catalog()

    try:
        tdfs4ds.FEATURE_CATALOG_NAME = feature_store_catalog_creation()
        tdfs4ds.logger_safe("info", "Feature catalog table created: %s in database %s", tdfs4ds.FEATURE_CATALOG_NAME, database)
    except Exception as e:
        tdfs4ds.logger_safe("error", "Feature catalog creation failed: %s", str(e).split('\n')[0])

    try:
        (tdfs4ds.PROCESS_CATALOG_NAME,
         tdfs4ds.DATA_DISTRIBUTION_NAME,
         tdfs4ds.FILTER_MANAGER_NAME) = process_store_catalog_creation()

        tdfs4ds.logger_safe("info", "Process catalog table created: %s", tdfs4ds.PROCESS_CATALOG_NAME)
        tdfs4ds.logger_safe("info", "Data distribution table created: %s", tdfs4ds.DATA_DISTRIBUTION_NAME)
        tdfs4ds.logger_safe("info", "Filter manager table created: %s", tdfs4ds.FILTER_MANAGER_NAME)
    except Exception as e:
        tdfs4ds.logger_safe("error", "Process catalog creation failed: %s", str(e).split('\n')[0])

    try:
        tdfs4ds.process_store.process_followup.follow_up_table_creation()
        tdfs4ds.logger_safe("info", "Follow-up table created successfully.")
    except Exception as e:
        tdfs4ds.logger_safe("error", "Follow-up table creation failed: %s", str(e).split('\n')[0])

    tdfs4ds.feature_store.feature_store_management.feature_store_catalog_view_creation()
    tdfs4ds.process_store.process_store_catalog_management.process_store_catalog_view_creation()

    dataset_catalog = DatasetCatalog(schema_name=database, name=tdfs4ds.DATASET_CATALOG_NAME)
    if not dataset_catalog._exists():
        dataset_catalog.create_catalog()
        tdfs4ds.logger_safe("info", "Dataset catalog created: %s", tdfs4ds.DATASET_CATALOG_NAME)

    tdfs4ds.logger_safe("info", "Setup complete.")
    try:
        tdfs4ds.genai.documentation_tables_creation()
        tdfs4ds.logger_safe("info", "Documentation tables created successfully.")
    except Exception as e:
        tdfs4ds.logger_safe("error", "Documentation tables creation failed: %s", str(e).split('\n')[0])
    return


def connect(
    database                  = None,
    feature_catalog_name      = None,
    process_catalog_name      = None,
    data_distribution_name    = None,
    filter_manager_name       = None,
    followup_name             = None,
    feature_catalog_name_view = None,
    process_catalog_name_view = None,
    dataset_catalog_name      = None,
    documentation_process_business_logic      = None,
    documentation_process_features            = None,
    documentation_process_explain             = None,
    documentation_business_dictionary_objects  = None,
    documentation_business_dictionary_columns  = None,
    documentation_business_dictionary_sections = None,
    create_if_missing         = False
):
    # Apply defaults from package globals
    if database is None:
        database = tdfs4ds.SCHEMA
    if feature_catalog_name is None:
        feature_catalog_name = tdfs4ds.FEATURE_CATALOG_NAME
    if process_catalog_name is None:
        process_catalog_name = tdfs4ds.PROCESS_CATALOG_NAME
    if data_distribution_name is None:
        data_distribution_name = tdfs4ds.DATA_DISTRIBUTION_NAME
    if filter_manager_name is None:
        filter_manager_name = tdfs4ds.FILTER_MANAGER_NAME
    if followup_name is None:
        followup_name = tdfs4ds.FOLLOW_UP_NAME
    if feature_catalog_name_view is None:
        feature_catalog_name_view = tdfs4ds.FEATURE_CATALOG_NAME_VIEW
    if process_catalog_name_view is None:
        process_catalog_name_view = tdfs4ds.PROCESS_CATALOG_NAME_VIEW
    if dataset_catalog_name is None:
        dataset_catalog_name = tdfs4ds.DATASET_CATALOG_NAME
    if documentation_process_business_logic is None:
        documentation_process_business_logic = tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC
    if documentation_process_features is None:
        documentation_process_features = tdfs4ds.DOCUMENTATION_PROCESS_FEATURES
    if documentation_process_explain is None:
        documentation_process_explain = tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN
    if documentation_business_dictionary_objects is None:
        documentation_business_dictionary_objects = tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS
    if documentation_business_dictionary_columns is None:
        documentation_business_dictionary_columns = tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS
    if documentation_business_dictionary_sections is None:
        documentation_business_dictionary_sections = tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS

    if database is None:
        raise ValueError("database parameter is None.")
    tdfs4ds.SCHEMA = database
    tdfs4ds.logger_safe("info", "Connecting to feature store in database: %s", database)

    tables = [x.lower() for x in list(tdml.db_list_tables(schema_name=tdfs4ds.SCHEMA, object_type='table').TableName.values)]

    feature_exists = feature_catalog_name.lower() in tables
    process_exists = process_catalog_name.lower() in tables
    distrib_exists = data_distribution_name.lower() in tables
    filter_manager_exists = filter_manager_name.lower() in tables
    followup_name_exists = followup_name.lower() in tables
    documentation_process_business_logic_exist = documentation_process_business_logic.lower() in tables
    documentation_process_features_exist = documentation_process_features.lower() in tables
    documentation_process_explain_exist = documentation_process_explain.lower() in tables
    documentation_business_dictionary_objects_exist = documentation_business_dictionary_objects.lower() in tables
    documentation_business_dictionary_columns_exist = documentation_business_dictionary_columns.lower() in tables
    documentation_business_dictionary_sections_exist = documentation_business_dictionary_sections.lower() in tables

    if not (feature_exists and process_exists and distrib_exists and filter_manager_exists
            and documentation_process_business_logic_exist and documentation_process_features_exist
            and documentation_process_explain_exist
            and documentation_business_dictionary_objects_exist
            and documentation_business_dictionary_columns_exist
            and documentation_business_dictionary_sections_exist):
        if not create_if_missing:
            tdfs4ds.logger_safe("warning", "Feature store components missing and create_if_missing=False")
            return False
        tdfs4ds.logger_safe("info", "Missing components detected; creating missing parts...")
        if not feature_exists:
            tdfs4ds.logger_safe("info", "Creating feature catalog: %s", feature_catalog_name)
            tdfs4ds.feature_store.feature_store_management.feature_store_catalog_creation()
        if not process_exists:
            tdfs4ds.logger_safe("info", "Creating process catalog: %s", process_catalog_name)
            tdfs4ds.process_store.process_store_catalog_management.process_store_catalog_creation()
        if not distrib_exists:
            tdfs4ds.logger_safe("info", "Creating data distribution table: %s", data_distribution_name)
            tdfs4ds.data_distribution.data_distribution_catalog_creation()
        if not filter_manager_exists:
            tdfs4ds.logger_safe("info", "Creating filter manager table: %s", filter_manager_name)
            tdfs4ds.filter_manager.filter_manager_catalog_creation()
        if not (documentation_process_business_logic_exist and documentation_process_features_exist
                and documentation_process_explain_exist
                and documentation_business_dictionary_objects_exist
                and documentation_business_dictionary_columns_exist
                and documentation_business_dictionary_sections_exist):
            tdfs4ds.logger_safe("info", "Creating documentation tables.")
            tdfs4ds.genai.documentation_tables_creation()

    if not followup_name_exists:
        tdfs4ds.logger_safe("info", "Creating follow-up table: %s", followup_name)
        tdfs4ds.process_store.process_followup.follow_up_table_creation()
    tdfs4ds.FOLLOW_UP_NAME = followup_name

    # Schema migration — always run so backward-compatible upgrades are applied
    # even when create_if_missing=False.
    # Current migration: ensure USER_SCORE column exists in the explain table.
    if documentation_process_explain_exist:
        tdfs4ds.genai.migrate_documentation_explain_schema()

    # Set catalog names
    tdfs4ds.FEATURE_CATALOG_NAME = feature_catalog_name
    tdfs4ds.PROCESS_CATALOG_NAME = process_catalog_name
    tdfs4ds.DATA_DISTRIBUTION_NAME = data_distribution_name
    tdfs4ds.FILTER_MANAGER_NAME = filter_manager_name
    tdfs4ds.PROCESS_CATALOG_NAME_VIEW = process_catalog_name_view
    tdfs4ds.FEATURE_CATALOG_NAME_VIEW = feature_catalog_name_view
    tdfs4ds.DOCUMENTATION_PROCESS_BUSINESS_LOGIC = documentation_process_business_logic
    tdfs4ds.DOCUMENTATION_PROCESS_FEATURES = documentation_process_features
    tdfs4ds.DOCUMENTATION_PROCESS_EXPLAIN = documentation_process_explain
    tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS = documentation_business_dictionary_objects
    tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS = documentation_business_dictionary_columns
    tdfs4ds.DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS = documentation_business_dictionary_sections

    process_list = tdml.DataFrame(tdml.in_schema(database, process_catalog_name))
    if 'ENTITY_NULL_SUBSTITUTE' not in process_list.columns:
        tdfs4ds.logger_safe("warning", "ENTITY_NULL_SUBSTITUTE column missing. Upgrading catalog.")
        tdfs4ds.process_store.process_store_catalog_management.upgrade_process_catalog()

    tdfs4ds.feature_store.feature_store_management.feature_store_catalog_view_creation()
    tdfs4ds.process_store.process_store_catalog_management.process_store_catalog_view_creation()

    # Dataset Catalog
    tdfs4ds.DATASET_CATALOG_NAME = dataset_catalog_name
    dataset_catalog = DatasetCatalog(schema_name=database, name=dataset_catalog_name)
    if not dataset_catalog._exists():
        dataset_catalog.create_catalog()
        tdfs4ds.logger_safe("info", "Dataset catalog created: %s", dataset_catalog_name)

    # Detect temporal distribution
    def is_data_distribution_temporal():
        return 'PERIOD' in tdfs4ds.utils.lineage.get_ddl(
            view_name=tdfs4ds.DATA_DISTRIBUTION_NAME,
            schema_name=tdfs4ds.SCHEMA,
            object_type='table'
        )

    query_data_domain = f"""
    SELECT DISTINCT DATA_DOMAIN
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.PROCESS_CATALOG_NAME_VIEW}
    UNION
    SELECT DISTINCT DATA_DOMAIN
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME_VIEW}
    """
    data_domains = tdml.DataFrame.from_query(query_data_domain).to_pandas()['DATA_DOMAIN'].tolist()
    tdfs4ds.logger_safe("info", "Data domains in feature store: %d domain(s) found.", len(data_domains))
    tdfs4ds.logger_safe("debug", "Data domains: %s", data_domains)

    tdfs4ds.DATA_DISTRIBUTION_TEMPORAL = is_data_distribution_temporal()
    tdfs4ds.logger_safe("info", "Connected to feature store successfully.")
    return True
