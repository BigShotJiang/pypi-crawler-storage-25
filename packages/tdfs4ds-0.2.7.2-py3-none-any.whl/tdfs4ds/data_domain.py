"""
Data domain management for the tdfs4ds feature store.

A data domain is a logical namespace that isolates features by project or business unit.
Use these functions to list, select, or create data domains within the feature store.
"""

import difflib

import tdfs4ds
import teradataml as tdml


def get_data_domains(verbose=True):
    """
    Retrieve and display all data domains available in the feature store.

    Queries both the process catalog and the feature catalog for distinct DATA_DOMAIN values,
    then prints them with the currently active domain marked with an asterisk.

    Parameters:
    - verbose (bool): If True, prints the list of data domains with the current one marked.

    Returns:
    - list or None: When verbose=False, returns the list of data domain strings.
                    When verbose=True, prints the list and returns None.
    """

    query_data_domain = f"""
    SELECT DISTINCT DATA_DOMAIN
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.PROCESS_CATALOG_NAME_VIEW}
    UNION
    SELECT DISTINCT DATA_DOMAIN
    FROM {tdfs4ds.SCHEMA}.{tdfs4ds.FEATURE_CATALOG_NAME_VIEW}
    """
    data_domains = tdml.DataFrame.from_query(query_data_domain).to_pandas()['DATA_DOMAIN'].tolist()

    if verbose:
        print("Data Domains in Feature Store:")
        for d in data_domains:
            if d != tdfs4ds.DATA_DOMAIN:
                print('\t' + d)
            else:
                print('*\t' + d)
        if tdfs4ds.DATA_DOMAIN not in data_domains and tdfs4ds.DATA_DOMAIN is not None:
            print("\nCurrent data domain (%s) not available yet in feature store. It may be a new one" % tdfs4ds.DATA_DOMAIN)
        return
    return data_domains


def select_data_domain(data_domain):
    """
    Set the active data domain for feature store operations.

    All subsequent feature queries, registrations, and interactions with the feature store
    are scoped to this domain.

    Parameters:
    - data_domain (str): The name of the data domain to set as active.

    Raises:
    - ValueError: If the data domain does not exist in the feature store.
    """
    data_domains = get_data_domains(verbose=False)
    if data_domain not in data_domains:
        tdfs4ds.logger_safe("error", "Data domain '%s' not found in feature store.", data_domain)
        raise ValueError(f"Data domain '{data_domain}' not found in feature store.")
    # Suggest the closest domain if the exact one is not found
    closest_domain = difflib.get_close_matches(data_domain, data_domains, n=1)
    if data_domain in data_domains:
        tdfs4ds.DATA_DOMAIN = data_domain
    elif closest_domain:
        tdfs4ds.logger_safe("info", "Did you mean '%s'?", closest_domain[0])
        return
    tdfs4ds.DATA_DOMAIN = data_domain
    tdfs4ds.logger_safe("info", "Data domain set to: %s", data_domain)
    return


def create_data_domain(data_domain):
    """
    Create a new data domain in the feature store.

    A data domain serves as a logical grouping for features, isolating them by project,
    business unit, or data type. The domain is activated locally; features uploaded
    afterward will be tagged with this domain.

    Parameters:
    - data_domain (str): The name of the new data domain to be created.
    """
    existing_domains = get_data_domains(verbose=False)
    if data_domain in existing_domains:
        tdfs4ds.logger_safe("warning", "Data domain '%s' already exists in feature store.", data_domain)
        return data_domain
    tdfs4ds.DATA_DOMAIN = data_domain
    tdfs4ds.logger_safe("info", "Data domain '%s' created locally.", data_domain)
    return
