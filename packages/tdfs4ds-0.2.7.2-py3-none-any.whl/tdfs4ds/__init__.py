__version__ = '0.2.7.2'
import difflib
import logging
import json

# Setup the logger
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    datefmt='%Y-%m-%d %H:%M:%S'
)

# Helper: central logging gate controlled by tdfs4ds.DISPLAY_LOGS
def logger_safe(level, message, *args, **kwargs):
    """
    Wrapper around the global `logger` that only emits logs when
    tdfs4ds.DISPLAY_LOGS is True. `level` is a string like "info", "error", etc.
    """
    if getattr(tdfs4ds, "DISPLAY_LOGS", True):
        getattr(logger, level)(message, *args, **kwargs)

logger = logging.getLogger(__name__)

from tdfs4ds.feature_store.feature_query_retrieval import get_available_entity_id_records, write_where_clause_filter
from tdfs4ds.process_store.process_followup import follow_up_report
from tdfs4ds.dataset.dataset_catalog import DatasetCatalog, Dataset
from . import genai

# ---------------------------------------------------------------------------
# Global configuration variables
# ---------------------------------------------------------------------------

DATA_DOMAIN             = None
SCHEMA                  = None
FEATURE_CATALOG_NAME         = 'FS_FEATURE_CATALOG'
FEATURE_CATALOG_NAME_VIEW    = 'FS_V_FEATURE_CATALOG'
PROCESS_CATALOG_NAME         = 'FS_PROCESS_CATALOG'
PROCESS_CATALOG_NAME_VIEW    = 'FS_V_PROCESS_CATALOG'
PROCESS_CATALOG_NAME_VIEW_FEATURE_SPLIT    = 'FS_V_PROCESS_CATALOG_FEATURE_SPLIT'
DATASET_CATALOG_NAME         = 'FS_DATASET'

DATA_DISTRIBUTION_NAME  = 'FS_DATA_DISTRIBUTION'
FOLLOW_UP_NAME          = 'FS_FOLLOW_UP'
DATA_DISTRIBUTION_TEMPORAL = False
FILTER_MANAGER_NAME     = 'FS_FILTER_MANAGER'

END_PERIOD              = 'UNTIL_CHANGED'
FEATURE_STORE_TIME      = None
FEATURE_VERSION_DEFAULT = 'dev.0.0'
DISPLAY_LOGS            = True
DEBUG_MODE              = False

USE_VOLATILE_TABLE      = True
STORE_FEATURE           = 'MERGE'
REGISTER_FEATURE        = 'MERGE'
REGISTER_PROCESS        = 'MERGE'
BUILD_DATASET_AT_UPLOAD = False

FEATURE_PARTITION_N     = 20000
FEATURE_PARTITION_EACH  = 1

VARCHAR_SIZE            = 1024

INSTRUCT_MODEL_URL      = None
INSTRUCT_MODEL_API_KEY  = None
INSTRUCT_MODEL_MODEL    = None
INSTRUCT_MODEL_PROVIDER = None

# Embedding model — mirrors instruct model config pattern
# When EMBEDDING_MODEL_PROVIDER is None, falls back to INSTRUCT_MODEL_PROVIDER
EMBEDDING_MODEL_PROVIDER: str = None
EMBEDDING_MODEL_URL     : str = None
EMBEDDING_MODEL_API_KEY : str = None
EMBEDDING_MODEL_MODEL   : str = 'text-embedding-3-small'
EMBEDDING_MODEL_DIM     : int = 1536
CHROMA_MODE             : str = 'local'
CHROMA_PATH             : str = './tdfs4ds_chroma'
CHROMA_HOST             : str = 'localhost'
CHROMA_PORT             : int = 8000

DOCUMENTATION_PROCESS_BUSINESS_LOGIC      = 'FS_PROCESS_DOCUMENTATION_BUSINESS_LOGIC'
DOCUMENTATION_PROCESS_FEATURES            = 'FS_PROCESS_DOCUMENTATION_FEATURES'
DOCUMENTATION_PROCESS_BUSINESS_LOGIC_VIEW = 'FS_V_PROCESS_DOCUMENTATION_BUSINESS_LOGIC'
DOCUMENTATION_PROCESS_FEATURES_VIEW       = 'FS_V_PROCESS_DOCUMENTATION_FEATURES'
DOCUMENTATION_PROCESS_EXPLAIN             = 'FS_PROCESS_DOCUMENTATION_EXPLAIN'
DOCUMENTATION_PROCESS_EXPLAIN_VIEW        = 'FS_V_PROCESS_DOCUMENTATION_EXPLAIN'
DOCUMENTATION_BUSINESS_DICTIONARY_OBJECTS  = 'FS_BUSINESS_DICTIONARY_OBJECTS'
DOCUMENTATION_BUSINESS_DICTIONARY_COLUMNS  = 'FS_BUSINESS_DICTIONARY_COLUMNS'
DOCUMENTATION_BUSINESS_DICTIONARY_SECTIONS = 'FS_BUSINESS_DICTIONARY_SECTIONS'

import sys as _sys
from tdfs4ds.config import _load_config as _cfg_load, load_config
_cfg_load(_sys.modules[__name__])
del _sys, _cfg_load

import warnings
warnings.filterwarnings('ignore')

import teradataml as tdml
from tdfs4ds.utils.lineage import crystallize_view
from tdfs4ds.utils.filter_management import FilterManager
from tdfs4ds.utils.info import seconds_to_dhms
import tdfs4ds.feature_store
import tdfs4ds.process_store
import tdfs4ds.datasets
import time

import inspect
from tqdm.auto import tqdm

from tdfs4ds.feature_store.feature_data_processing import generate_on_clause

import uuid

# Generate a UUID
RUN_ID       = str(uuid.uuid4())
PROCESS_TYPE = 'RUN PROCESS'

import tdfs4ds

try:
    if SCHEMA is None:
        SCHEMA = tdml.context.context._get_current_databasename()
        if SCHEMA is None:
            logger.warning("No default database detected for feature store.")
            logger.warning('Please set it explicitly: tdfs4ds.SCHEMA = "<feature store database>"')
        else:
            logger.info("Default database detected for feature store: %s", SCHEMA)
            logger.info('tdfs4ds.SCHEMA = "%s"', SCHEMA)
    else:
        logger.info("SCHEMA already configured: %s", SCHEMA)

    if DATA_DOMAIN is None and SCHEMA is not None:
        DATA_DOMAIN = SCHEMA
        logger.info("DATA_DOMAIN not set. Defaulting to SCHEMA: %s", DATA_DOMAIN)
        logger.info('You can override it using: tdfs4ds.DATA_DOMAIN = "<your data domain>"')

except Exception as e:
    logger.error("Could not determine current database: %s", str(e).split('\n')[0])
    logger.warning("Please specify the feature store database manually:")
    logger.warning('tdfs4ds.SCHEMA = "<feature store database>"')


# ---------------------------------------------------------------------------
# Public API — imported from sub-modules and re-exported here so that all
# existing call sites (e.g. tdfs4ds.setup(), tdfs4ds.upload_features()) work
# without any changes.
# ---------------------------------------------------------------------------

from tdfs4ds.lifecycle import setup, connect

from tdfs4ds.data_domain import (
    get_data_domains,
    select_data_domain,
    create_data_domain,
)

from tdfs4ds.catalog import (
    feature_catalog,
    process_catalog,
    dataset_catalog,
    get_dataset_entity,
    get_dataset_features,
)

from tdfs4ds.process_store.process_query_administration import get_process_id

from tdfs4ds.execution import (
    run,
    upload_features,
    _upload_features,
    _compute_features_batch,
    upload_tdstone2_scores,
    roll_out,
)

from tdfs4ds.dataset.builder import (
    build_dataset,
    build_dataset_opt,
    augment_source_with_features,
)
