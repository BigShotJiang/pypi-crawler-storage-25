# Changelog

## [Unreleased]

## [2.3.1] - 2026-05-14

### Fixed
- Annotated `headers` dicts in `keep_github_workflow_active.py` as `dict[str, str | bytes]` so pyright accepts them as `requests` `HeadersType` (which is `MutableMapping[str, str | bytes]` and invariant on the value type). Restores green CI under types-requests 2.34.

### Security
- Refreshed pip-audit ignore list: removed resolved entries for gitpython (`CVE-2026-42215`, `CVE-2026-42284`, `CVE-2026-44244`) and python-multipart (`CVE-2026-42561`); kept the pip CVEs (`CVE-2026-3219`, `CVE-2026-6357`) since the CI runner still ships pip 26.0.1; added `CVE-2026-44405` (paramiko, no fix yet) and `CVE-2026-44431`/`CVE-2026-44432` (urllib3 2.6.3 in the local bmk toolchain, fixed in 2.7.0)

## [2.3.0] - 2026-05-03

### Added
- New `SkippedWorkflowType.UPDATE_GRAPH` enum value to skip GitHub-managed `update-graph` workflows during enablement (these can't be enabled via the standard Actions API)
- New pytest `integration` marker registered in `pyproject.toml`; live-API tests in `tests/test_github_integration.py` now carry both `local_only` and `integration` markers so `make testintegration` collects them

### Changed
- CI/CD workflow updated: `default_cicd_public.yml` matrix and codecov-action v6
- `updrootvol` automation cleanup: removed snyk badge from README

### Security
- Added `CVE-2026-3219` (pip 26.0.1 concatenated tar+ZIP confusion, no fix yet) to pip-audit ignore list
- Cleaned obsolete entries from pip-audit ignore list (resolved or not flagged): `GHSA-4xh5-x5gv-qwph`, `CVE-2026-4539`, `CVE-2026-25990`, `CVE-2025-8869`, `CVE-2026-1703`
- Restored `PYSEC-2022-42969` after verifying `py` 1.11.0 is still flagged in the local audit environment

## [2.2.0] - 2026-03-29

### Added
- Support for GitHub organisations in `get_repositories` (tries `/orgs/` endpoint first, falls back to `/users/`)
- New CI job to activate workflows and delete old runs for RotekHandelsGmbH organisation
- Dynamic workflow discovery in integration tests instead of hardcoded repo/workflow names

### Fixed
- Strip whitespace from config values at lookup time (fixes Python 3.14 `http.client` rejecting header values with trailing newlines)
- Integration tests now skip unconditionally in CI using `CI` env var detection
- Fixed masked credential detection to use substring check instead of equality

### Security
- Cleaned up CVE exclusion list: removed resolved entries (PYSEC-2022-43012, PYSEC-2025-49, CVE-2024-6345, CVE-2026-1703, CVE-2026-26007, CVE-2026-25990, CVE-2025-8869, CVE-2026-25645)

## [2.1.5] - 2026-03-25

### Changed
- Updated CI/CD workflows: improved artifact upload/download actions, updated runner configurations
- Updated Makefile with streamlined build targets

### Security
- Added CVE-2026-25990 (pillow), CVE-2025-8869 (pip), CVE-2026-25645 (requests) to pip-audit ignore list
- Added CVE-2026-4539 (pygments) to pip-audit ignore list

## [2.1.4] - 2026-02-13

### Fixed
- Fixed shellcheck SC1083 warning and shfmt formatting in `reset_git_history.sh`

### Changed
- Updated CI/CD workflows: added Bash 4+ support for macOS, streamlined metadata extraction action
- Updated README badge path

### Dependencies
- Bumped `lib_cli_exit_tools` to `>=2.3.0`
- Bumped `ruff` to `>=0.15.1`
- Bumped `import-linter` to `>=2.10`

### Security
- Added CVE-2026-1703 and CVE-2026-26007 (cryptography 46.0.3) to pip-audit ignore list

## [2.1.3] - 2026-02-01

### Fixed
- Fixed pyright errors in `test_metadata.py` by replacing `tomllib` (Python 3.11+) with `rtoml` for Python 3.10 compatibility

### Added
- Added `local_only` pytest marker for tests requiring GitHub credentials
- Created `test_github_integration.py` with dedicated GitHub API integration tests
- Tests marked `local_only` are excluded from public CI (`default_cicd_public.yml`) but run in `activate_workflows.yml` where secrets are available

### Changed
- Excluded `keep_github_workflow_active.py` from doctest collection (doctests access GitHub API when credentials available)
- Added setuptools vulnerability exceptions to pip-audit (PYSEC-2022-43012, PYSEC-2025-49, CVE-2024-6345) - transitive dependency pinned by build tools

## [2.1.2] - 2025-12-15

### Changed
- Migrated scripts to use `rtoml` for TOML parsing

### Dependencies
- Bumped `lib_cli_exit_tools` to `>=2.2.2`
- Bumped `ruff` to `>=0.14.9`
- Bumped `textual` to `>=6.9.0`
- Bumped `import-linter` to `>=2.9`
- Added `rtoml>=0.13.0` as dev dependency for improved TOML handling

## [2.1.1] - 2025-12-08

### Changed
- **Data Architecture Enforcement**: Refactored to follow strict Pydantic/Enum architecture rules.
  - `EnvConfig` now uses `__getattr__` for typed attribute access instead of dict-style `.get()` method
  - Added `PaginationLink` Pydantic model for typed pagination header handling
  - Replaced dict key access (`response.links.get("next")`) with typed model access (`link.url`)
  - Added `get_value()` method to `EnvConfig` for explicit key lookup

### Dependencies
- Added `pydantic>=2.10.0` as a runtime dependency for typed data models

### Documentation
- Updated `CLAUDE.md` with Data Architecture Rules section documenting:
  - Core principles (Pydantic at boundaries, no internal dicts, Enums for constants)
  - Key Pydantic models and Enums used in the project
  - Framework exceptions where dict usage is required
- Fixed incorrect path reference in Versioning section (`lib_cli_exit_tools` → `keep_github_workflows_active`)

## [2.1.0] - 2025-10-29
### Security
- **Added comprehensive credential sanitization** to prevent token leakage in logs.
  - New `sanitization` module with functions to redact sensitive data
  - All logging calls now sanitize messages before output
  - Protects GitHub tokens (ghp_*, gho_*, etc.), API keys, and authorization headers
  - Token pattern detection using regex for various formats (hex, base64, GitHub-specific)
  - Dictionary and nested structure sanitization for structured logging
  - 100% test coverage with 31 dedicated tests
  - Comprehensive security documentation in `docs/systemdesign/SECURITY.md`

## [2.0.0] - 2025-10-23
### Changed
- Removed pre-3.13 compatibility shims and migrated internal modules to native
  Python 3.13 type syntax (e.g., ``list[str]`` and ``Sequence[str] | None``).
- Hardened GitHub token discovery by falling back to project ``.env`` files
  when environment variables are unset.
- Surfaced workflow maintenance helpers as CLI commands
  (``enable-all-workflows`` and ``delete-old-workflow-runs``) with optional
  override parameters.
- Added explicit HTTP timeouts to GitHub workflow maintenance calls to avoid
  hanging requests.
- Simplified CI matrix to run only on ``ubuntu-latest`` with the rolling
  ``3.x`` CPython release.
- Updated CI packaging checks to execute the CLI from the pipx binary directory
  and via ``uv tool install --from dist/*.whl`` to confirm the built wheel
  exposes the console entry point correctly.
- Refined packaging verification to leverage the pipx binary directory and
  install the local wheel via ``uv tool install --from dist/*.whl``.
- Corrected the CI pipeline to use the current ``astral-sh/setup-uv@v6`` action
  tag.

### Dependencies
- Bumped ``ruff`` to ``>=0.14.1`` and ``textual`` to ``>=6.4.0``.
- Declared ``requests`` as a runtime dependency to support GitHub API calls when
  the package is installed.
