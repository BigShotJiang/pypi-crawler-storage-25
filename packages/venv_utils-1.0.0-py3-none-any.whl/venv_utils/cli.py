from __future__ import annotations

import argparse
import json
import sys

from venv_utils.utils import venv_info, list_packages, check_package, get_site_packages


def cmd_info(args: argparse.Namespace) -> None:
    info = venv_info()
    if args.json:
        print(json.dumps(info, indent=2))
    else:
        for k, v in info.items():
            print(f"{k:15}: {v}")


def cmd_list(args: argparse.Namespace) -> None:
    pkgs = list_packages()
    if args.json:
        print(json.dumps(pkgs, indent=2))
    else:
        for p in pkgs:
            print(f"{p['name']:40} {p['version']}")


def cmd_check(args: argparse.Namespace) -> None:
    ok = check_package(args.package)
    print("installed" if ok else "not found")
    sys.exit(0 if ok else 1)


def cmd_site(args: argparse.Namespace) -> None:
    for p in get_site_packages():
        print(p)


def main() -> None:
    parser = argparse.ArgumentParser(
        prog="venv-utils",
        description="Virtual environment inspection utilities",
    )
    parser.add_argument("--json", action="store_true", help="output as JSON")
    sub = parser.add_subparsers(dest="cmd")

    sub.add_parser("info",  help="show venv information")
    sub.add_parser("list",  help="list installed packages")
    sub.add_parser("site",  help="show site-packages paths")

    chk = sub.add_parser("check", help="check if a package is installed")
    chk.add_argument("package")

    args = parser.parse_args()

    if args.cmd == "info":    cmd_info(args)
    elif args.cmd == "list":  cmd_list(args)
    elif args.cmd == "site":  cmd_site(args)
    elif args.cmd == "check": cmd_check(args)
    else:
        parser.print_help()


if __name__ == "__main__":
    main()
