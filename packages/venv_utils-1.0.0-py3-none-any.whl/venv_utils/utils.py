from __future__ import annotations

import os
import sys
import subprocess
from pathlib import Path


def is_venv() -> bool:
    return sys.prefix != sys.base_prefix


def get_venv_root() -> Path | None:
    if is_venv():
        return Path(sys.prefix)
    return None


def get_python_version() -> str:
    return sys.version


def list_packages() -> list[dict]:
    result = subprocess.run(
        [sys.executable, "-m", "pip", "list", "--format=json"],
        capture_output=True, text=True,
    )
    if result.returncode == 0:
        import json
        try:
            return json.loads(result.stdout)
        except Exception:
            pass
    return []


def get_site_packages() -> list[Path]:
    import site
    return [Path(p) for p in site.getsitepackages()]


def check_package(name: str) -> bool:
    import importlib.util
    return importlib.util.find_spec(name) is not None


def venv_info() -> dict:
    return {
        "is_venv": is_venv(),
        "python": get_python_version(),
        "prefix": sys.prefix,
        "executable": sys.executable,
        "venv_root": str(get_venv_root()) if is_venv() else None,
    }
