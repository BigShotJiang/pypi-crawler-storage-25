from __future__ import annotations

import os
import sys


WINDOWS = os.name == "nt"
MACOS   = sys.platform == "darwin"
LINUX   = sys.platform.startswith("linux")

PY38_PLUS = sys.version_info >= (3, 8)
PY310_PLUS = sys.version_info >= (3, 10)
PY312_PLUS = sys.version_info >= (3, 12)


def scripts_dir(prefix: str) -> str:
    return os.path.join(prefix, "Scripts" if WINDOWS else "bin")


def python_bin(prefix: str) -> str:
    name = "python.exe" if WINDOWS else "python"
    return os.path.join(scripts_dir(prefix), name)


def pip_bin(prefix: str) -> str:
    name = "pip.exe" if WINDOWS else "pip"
    return os.path.join(scripts_dir(prefix), name)
