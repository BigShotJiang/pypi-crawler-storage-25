"""
nb_llm CLI entry point
Usage: python -m nb_llm [command]

Commands:
  chat    - Interactive chat
  ask     - Single query
  models  - List supported models
  version - Show version
"""
from __future__ import annotations

import argparse
import sys


def cmd_chat(args):
    """Interactive chat"""
    from nb_llm import Chat, ChatConfig

    config_kwargs = {'model': args.model}
    if args.system:
        config_kwargs['system'] = args.system
    if args.api_key:
        config_kwargs['api_key'] = args.api_key
    if args.base_url:
        config_kwargs['base_url'] = args.base_url
    if args.temperature is not None:
        config_kwargs['temperature'] = args.temperature

    chat = Chat(ChatConfig(**config_kwargs))
    print(f"nb_llm interactive mode (model: {args.model})")
    print("Type /quit to exit, /clear to clear history\n")

    while True:
        try:
            user_input = input("You: ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\nGoodbye!")
            break

        if not user_input:
            continue
        if user_input == '/quit':
            print("Goodbye!")
            break
        if user_input == '/clear':
            chat.clear()
            print("[History cleared]")
            continue

        if args.stream:
            print("AI: ", end="", flush=True)
            for chunk in chat.stream(user_input):
                print(chunk, end="", flush=True)
            print()
        else:
            response = chat.send(user_input)
            print(f"AI: {response}")

        if args.show_usage:
            print(f"  [tokens: {chat.last_usage.total_tokens}]")
        print()


def cmd_ask(args):
    """Single query"""
    from nb_llm import Chat, ChatConfig

    config_kwargs = {'model': args.model}
    if args.system:
        config_kwargs['system'] = args.system
    if args.api_key:
        config_kwargs['api_key'] = args.api_key
    if args.base_url:
        config_kwargs['base_url'] = args.base_url

    chat = Chat(ChatConfig(**config_kwargs))
    response = chat.ask(args.prompt)
    print(response)

    if args.show_usage:
        print(f"\n[tokens: {response.usage.total_tokens}]")


def cmd_models(args):
    """List supported models"""
    from nb_llm.providers.registry import MODEL_REGISTRY

    print("nb_llm built-in model aliases:\n")
    seen = set()
    for alias, (provider_type, model, url) in sorted(MODEL_REGISTRY.items()):
        if model not in seen:
            seen.add(model)
            base = url or '(native API)'
            print(f"  {alias:<25} → {model:<35} [{provider_type}]")


def cmd_version(args):
    """Show version"""
    from nb_llm import __version__
    print(f"nb_llm v{__version__}")


def main():
    parser = argparse.ArgumentParser(
        prog='nb_llm',
        description='nb_llm — A powerful LLM framework CLI',
    )
    subparsers = parser.add_subparsers(dest='command')

    # chat command
    p_chat = subparsers.add_parser('chat', help='Interactive chat')
    p_chat.add_argument('--model', '-m', default='gpt-4o', help='Model name')
    p_chat.add_argument('--system', '-s', help='System prompt')
    p_chat.add_argument('--api-key', help='API Key')
    p_chat.add_argument('--base-url', help='API Base URL')
    p_chat.add_argument('--temperature', '-t', type=float, help='Temperature')
    p_chat.add_argument('--stream', action='store_true', help='Streaming output')
    p_chat.add_argument('--show-usage', '-u', action='store_true', help='Show token usage')

    # ask command
    p_ask = subparsers.add_parser('ask', help='Single query')
    p_ask.add_argument('prompt', help='Query content')
    p_ask.add_argument('--model', '-m', default='gpt-4o', help='Model name')
    p_ask.add_argument('--system', '-s', help='System prompt')
    p_ask.add_argument('--api-key', help='API Key')
    p_ask.add_argument('--base-url', help='API Base URL')
    p_ask.add_argument('--show-usage', '-u', action='store_true', help='Show token usage')

    # models command
    subparsers.add_parser('models', help='List supported models')

    # version command
    subparsers.add_parser('version', help='Show version')

    args = parser.parse_args()

    if args.command == 'chat':
        cmd_chat(args)
    elif args.command == 'ask':
        cmd_ask(args)
    elif args.command == 'models':
        cmd_models(args)
    elif args.command == 'version':
        cmd_version(args)
    else:
        parser.print_help()


if __name__ == '__main__':
    main()
