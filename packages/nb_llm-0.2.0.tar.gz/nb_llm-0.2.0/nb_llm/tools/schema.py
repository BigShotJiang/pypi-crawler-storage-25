"""Auto-generate OpenAI Function Calling JSON Schema from Python function signatures"""
from __future__ import annotations

import inspect
import re
from typing import Any, Dict, List, Optional, get_type_hints

from nb_llm.exceptions import SchemaGenerationError


_PYTHON_TYPE_TO_JSON = {
    str: "string",
    int: "integer",
    float: "number",
    bool: "boolean",
    list: "array",
    dict: "object",
    type(None): "null",
}


def _type_to_json_schema(annotation: Any) -> dict:
    if annotation is inspect.Parameter.empty or annotation is None:
        return {"type": "string"}

    origin = getattr(annotation, '__origin__', None)

    if origin is list or origin is List:
        args = getattr(annotation, '__args__', None)
        if args:
            return {"type": "array", "items": _type_to_json_schema(args[0])}
        return {"type": "array"}

    if origin is dict or origin is Dict:
        return {"type": "object"}

    json_type = _PYTHON_TYPE_TO_JSON.get(annotation)
    if json_type:
        return {"type": json_type}

    return {"type": "string"}


def _parse_docstring_args(docstring: Optional[str]) -> dict:
    """Parse parameter descriptions from Args section of docstring"""
    if not docstring:
        return {}

    result = {}
    in_args = False
    current_param = None
    current_desc_lines = []

    for line in docstring.split('\n'):
        stripped = line.strip()

        if stripped.lower() in ('args:', 'arguments:', 'parameters:', 'params:'):
            in_args = True
            continue
        if in_args and stripped.lower() in ('returns:', 'return:', 'raises:', 'example:', 'examples:', 'note:', 'notes:'):
            if current_param:
                result[current_param] = ' '.join(current_desc_lines).strip()
            break

        if in_args:
            match = re.match(r'(\w+)\s*(?:\(.+?\))?\s*:\s*(.*)', stripped)
            if match:
                if current_param:
                    result[current_param] = ' '.join(current_desc_lines).strip()
                current_param = match.group(1)
                current_desc_lines = [match.group(2)] if match.group(2) else []
            elif current_param and stripped:
                current_desc_lines.append(stripped)

    if current_param:
        result[current_param] = ' '.join(current_desc_lines).strip()

    return result


def func_to_schema(func: Any) -> dict:
    """Convert a function to OpenAI Function Calling JSON Schema"""
    try:
        sig = inspect.signature(func)
    except (ValueError, TypeError) as e:
        raise SchemaGenerationError(f"Cannot parse signature of function '{func.__name__}': {e}")

    docstring = inspect.getdoc(func) or ''
    description = docstring.split('\n')[0].strip() if docstring else func.__name__

    try:
        type_hints = get_type_hints(func)
    except Exception:
        type_hints = {}

    arg_descriptions = _parse_docstring_args(docstring)

    properties = {}
    required = []

    for name, param in sig.parameters.items():
        if name == 'self':
            continue

        annotation = type_hints.get(name, param.annotation)
        prop = _type_to_json_schema(annotation)

        if name in arg_descriptions:
            prop['description'] = arg_descriptions[name]

        if param.default is not inspect.Parameter.empty:
            prop['default'] = param.default
        else:
            required.append(name)

        properties[name] = prop

    schema = {
        "type": "function",
        "function": {
            "name": func.__name__,
            "description": description,
            "parameters": {
                "type": "object",
                "properties": properties,
            },
        },
    }
    if required:
        schema["function"]["parameters"]["required"] = required

    return schema
