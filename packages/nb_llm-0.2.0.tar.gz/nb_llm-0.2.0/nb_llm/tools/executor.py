"""Tool execution engine"""
from __future__ import annotations

import json
import logging
import time
from typing import Any, Callable, Dict, List, Optional, Tuple

from nb_llm.core.data_types import ToolCallRecord, PendingToolCall, ToolCallRound
from nb_llm.exceptions import ToolExecutionError
from nb_llm.loggers import logger_tools as logger


class ToolExecutor:
    """Tool execution engine: receives tool_calls → executes → returns results"""

    def __init__(self) -> None:
        self._tools: Dict[str, dict] = {}

    def register(self, func: Callable, schema: dict,
                 auto_execute: bool = True) -> None:
        name = schema['function']['name']
        self._tools[name] = {
            'func': func,
            'schema': schema,
            'auto_execute': auto_execute,
        }

    def unregister(self, func_or_name: Any) -> bool:
        if isinstance(func_or_name, str):
            name = func_or_name
        else:
            name = getattr(func_or_name, '__name__', str(func_or_name))
        return self._tools.pop(name, None) is not None

    def clear(self) -> None:
        self._tools.clear()

    @property
    def schemas(self) -> List[dict]:
        return [t['schema'] for t in self._tools.values()]

    @property
    def tool_names(self) -> List[str]:
        return list(self._tools.keys())

    def _parse_tool_calls(self, response: dict) -> List[dict]:
        """Parse tool_calls from API response"""
        choices = response.get('choices', [{}])
        message = choices[0].get('message', {}) if choices else {}
        return message.get('tool_calls', []) or []

    def execute_single(self, name: str, args: dict) -> Tuple[Any, float, None]:
        tool_info = self._tools.get(name)
        if not tool_info:
            raise ToolExecutionError(name, args, KeyError(f"Tool '{name}' not registered"))
        start = time.time()
        try:
            result = tool_info['func'](**args)
            elapsed = time.time() - start
            return result, elapsed, None
        except Exception as e:
            raise ToolExecutionError(name, args, e)

    def _log_round_start(self, round_count: int, response: dict,
                         model_tc_info: list) -> None:
        """Log debug info at the start of each tool call round"""
        logger.debug("[Round %d] Model requested %d tool calls: %s",
                     round_count, len(model_tc_info),
                     [f"{tc['name']}({tc['arguments']})" for tc in model_tc_info])

    def _log_tool_result(self, round_count: int, fn_name: str,
                         result_str: str) -> None:
        """Log debug info for a single tool execution result"""
        logger.debug("[Round %d] Tool %s returned: %s", round_count, fn_name, result_str)

    def execute_loop(self, provider: Any, messages: list, response: dict,
                     config: Any = None, options: Any = None,
                     max_rounds: int = 10) -> Tuple[dict, List[ToolCallRecord], List[PendingToolCall]]:
        """Function Calling loop:
        1. Model returns tool_calls → execute → append results to messages → call model again
        2. Repeat until no tool_calls or max_rounds exceeded
        Returns (final_response, records, pending, rounds)
        """
        all_records: List[ToolCallRecord] = []
        all_pending: List[PendingToolCall] = []
        all_rounds: List[ToolCallRound] = []
        round_count = 0

        while round_count < max_rounds:
            tool_calls = self._parse_tool_calls(response)
            if not tool_calls:
                logger.debug("[Round %d] Model returned no tool_calls, loop ended", round_count)
                break

            choices = response.get('choices', [])
            if not choices:
                break
            assistant_msg = choices[0].get('message', {})
            messages.append(assistant_msg)

            model_tc_info = []
            for tc in tool_calls:
                try:
                    parsed_args = json.loads(tc['function']['arguments'])
                except (json.JSONDecodeError, TypeError):
                    parsed_args = {}
                model_tc_info.append({
                    'id': tc.get('id', ''),
                    'name': tc['function']['name'],
                    'arguments': parsed_args,
                })

            self._log_round_start(round_count, response, model_tc_info)

            round_tool_results = []
            has_auto = False
            for tc in tool_calls:
                fn_name = tc['function']['name']
                try:
                    fn_args = json.loads(tc['function']['arguments'])
                except (json.JSONDecodeError, TypeError):
                    fn_args = {}

                tool_info = self._tools.get(fn_name)
                if not tool_info:
                    tool_result_str = f"Error: Tool '{fn_name}' not registered"
                    messages.append({
                        'role': 'tool',
                        'tool_call_id': tc['id'],
                        'content': tool_result_str,
                    })
                    all_records.append(ToolCallRecord(
                        name=fn_name, args=fn_args, result=None,
                        error=f"Tool '{fn_name}' not registered",
                    ))
                    round_tool_results.append({'name': fn_name, 'result': tool_result_str, 'error': True})
                    self._log_tool_result(round_count, fn_name, tool_result_str)
                    has_auto = True
                    continue

                if not tool_info['auto_execute']:
                    pending = PendingToolCall(
                        name=fn_name,
                        args=fn_args,
                        tool_func=tool_info['func'],
                        tool_call_id=tc['id'],
                    )
                    all_pending.append(pending)
                    continue

                try:
                    result, elapsed, _ = self.execute_single(fn_name, fn_args)
                    messages.append({
                        'role': 'tool',
                        'tool_call_id': tc['id'],
                        'content': str(result),
                    })
                    all_records.append(ToolCallRecord(
                        name=fn_name, args=fn_args, result=result, elapsed=elapsed,
                    ))
                    round_tool_results.append({'name': fn_name, 'result': str(result)})
                    self._log_tool_result(round_count, fn_name, str(result))
                    has_auto = True
                except ToolExecutionError as e:
                    tool_err_str = f"Error: {e.original_error}"
                    messages.append({
                        'role': 'tool',
                        'tool_call_id': tc['id'],
                        'content': tool_err_str,
                    })
                    all_records.append(ToolCallRecord(
                        name=fn_name, args=fn_args,
                        error=str(e.original_error),
                    ))
                    round_tool_results.append({'name': fn_name, 'result': tool_err_str, 'error': True})
                    self._log_tool_result(round_count, fn_name, tool_err_str)
                    has_auto = True

            all_rounds.append(ToolCallRound(
                round_index=round_count,
                model_tool_calls=model_tc_info,
                tool_results=round_tool_results,
                raw_response=response,
            ))

            if all_pending and not has_auto:
                break

            if has_auto:
                response = provider.chat_completion(
                    messages, config=config, options=options, tools=self.schemas,
                )
                round_count += 1
            else:
                break

        return response, all_records, all_pending, all_rounds

    async def async_execute_loop(
            self, provider: Any, messages: list, response: dict,
            config: Any = None, options: Any = None,
            max_rounds: int = 10) -> Tuple[dict, List[ToolCallRecord], List[PendingToolCall]]:
        """Async version of tool execution loop"""
        all_records: List[ToolCallRecord] = []
        all_pending: List[PendingToolCall] = []
        all_rounds: List[ToolCallRound] = []
        round_count = 0

        while round_count < max_rounds:
            tool_calls = self._parse_tool_calls(response)
            if not tool_calls:
                logger.debug("[Async Round %d] Model returned no tool_calls, loop ended", round_count)
                break

            choices = response.get('choices', [])
            if not choices:
                break
            assistant_msg = choices[0].get('message', {})
            messages.append(assistant_msg)

            model_tc_info = []
            for tc in tool_calls:
                try:
                    parsed_args = json.loads(tc['function']['arguments'])
                except (json.JSONDecodeError, TypeError):
                    parsed_args = {}
                model_tc_info.append({
                    'id': tc.get('id', ''),
                    'name': tc['function']['name'],
                    'arguments': parsed_args,
                })

            self._log_round_start(round_count, response, model_tc_info)

            round_tool_results = []
            has_auto = False
            for tc in tool_calls:
                fn_name = tc['function']['name']
                try:
                    fn_args = json.loads(tc['function']['arguments'])
                except (json.JSONDecodeError, TypeError):
                    fn_args = {}

                tool_info = self._tools.get(fn_name)
                if not tool_info:
                    tool_result_str = f"Error: Tool '{fn_name}' not registered"
                    messages.append({
                        'role': 'tool',
                        'tool_call_id': tc['id'],
                        'content': tool_result_str,
                    })
                    all_records.append(ToolCallRecord(
                        name=fn_name, args=fn_args, result=None,
                        error=f"Tool '{fn_name}' not registered",
                    ))
                    round_tool_results.append({'name': fn_name, 'result': tool_result_str, 'error': True})
                    self._log_tool_result(round_count, fn_name, tool_result_str)
                    has_auto = True
                    continue

                if not tool_info['auto_execute']:
                    pending = PendingToolCall(
                        name=fn_name, args=fn_args,
                        tool_func=tool_info['func'],
                        tool_call_id=tc['id'],
                    )
                    all_pending.append(pending)
                    continue

                try:
                    result, elapsed, _ = self.execute_single(fn_name, fn_args)
                    messages.append({
                        'role': 'tool',
                        'tool_call_id': tc['id'],
                        'content': str(result),
                    })
                    all_records.append(ToolCallRecord(
                        name=fn_name, args=fn_args, result=result, elapsed=elapsed,
                    ))
                    round_tool_results.append({'name': fn_name, 'result': str(result)})
                    self._log_tool_result(round_count, fn_name, str(result))
                    has_auto = True
                except ToolExecutionError as e:
                    tool_err_str = f"Error: {e.original_error}"
                    messages.append({
                        'role': 'tool',
                        'tool_call_id': tc['id'],
                        'content': tool_err_str,
                    })
                    all_records.append(ToolCallRecord(
                        name=fn_name, args=fn_args,
                        error=str(e.original_error),
                    ))
                    round_tool_results.append({'name': fn_name, 'result': tool_err_str, 'error': True})
                    self._log_tool_result(round_count, fn_name, tool_err_str)
                    has_auto = True

            all_rounds.append(ToolCallRound(
                round_index=round_count,
                model_tool_calls=model_tc_info,
                tool_results=round_tool_results,
                raw_response=response,
            ))

            if all_pending and not has_auto:
                break

            if has_auto:
                response = await provider.aio_chat_completion(
                    messages, config=config, options=options, tools=self.schemas,
                )
                round_count += 1
            else:
                break

        return response, all_records, all_pending, all_rounds
