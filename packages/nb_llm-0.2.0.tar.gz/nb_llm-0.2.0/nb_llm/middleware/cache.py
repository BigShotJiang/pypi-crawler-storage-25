"""Cache middleware"""
from __future__ import annotations

import hashlib
import json
import time
from typing import Any, Dict, Optional, Tuple


class ResponseCache:
    """Simple in-memory cache based on message content + parameter hash"""

    def __init__(self, ttl: int = 3600, max_size: int = 1000) -> None:
        self.ttl = ttl
        self.max_size = max_size
        self._cache: Dict[str, Tuple[float, dict]] = {}

    def _make_key(self, messages: list, config: Any = None,
                  options: Any = None) -> str:
        key_data = json.dumps(messages, ensure_ascii=False, sort_keys=True)
        if config:
            key_data += str(getattr(config, 'model', ''))
            key_data += str(getattr(config, 'temperature', ''))
        if options:
            key_data += str(getattr(options, 'temperature', ''))
            key_data += str(getattr(options, 'max_tokens', ''))
        return hashlib.md5(key_data.encode('utf-8')).hexdigest()

    def get(self, messages: list, config: Any = None,
            options: Any = None) -> Optional[dict]:
        key = self._make_key(messages, config, options)
        if key in self._cache:
            ts, response = self._cache[key]
            if time.time() - ts < self.ttl:
                return response
            else:
                del self._cache[key]
        return None

    def set(self, messages: list, response: dict,
            config: Any = None, options: Any = None) -> None:
        if len(self._cache) >= self.max_size:
            oldest_key = min(self._cache, key=lambda k: self._cache[k][0])
            del self._cache[oldest_key]
        key = self._make_key(messages, config, options)
        self._cache[key] = (time.time(), response)

    def clear(self) -> None:
        self._cache.clear()

    def __len__(self) -> int:
        return len(self._cache)
