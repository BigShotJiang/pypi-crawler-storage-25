"""Embedding vectorization class"""
from __future__ import annotations

import json
import os
from typing import List, Optional, Union

from nb_llm.loggers import logger_embedding as logger

try:
    import requests as _requests
except ImportError:
    _requests = None

try:
    import openai as openai_sdk
except (ImportError, Exception):
    openai_sdk = None


_EMBEDDING_REGISTRY = {
    "text-embedding-3-small": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "text-embedding-3-large": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "text-embedding-ada-002": ("https://api.openai.com/v1", "OPENAI_API_KEY"),
    "bge-m3": ("https://dashscope.aliyuncs.com/compatible-mode/v1", "DASHSCOPE_API_KEY"),
    "bge-large-zh": ("https://dashscope.aliyuncs.com/compatible-mode/v1", "DASHSCOPE_API_KEY"),
    "text-embedding-v1": ("https://dashscope.aliyuncs.com/compatible-mode/v1", "DASHSCOPE_API_KEY"),
}


class Embedding:
    """Embedding vectorization.
    Supports string and string list input, returns vector or vector list.
    Prefers openai SDK, falls back to requests for direct HTTP calls.
    """

    def __init__(self, model: str = "text-embedding-3-small",
                 api_key: Optional[str] = None,
                 base_url: Optional[str] = None,
                 max_token_chars: int = 0) -> None:
        self.model = model
        self._max_token_chars = max_token_chars

        registry_entry = _EMBEDDING_REGISTRY.get(model)
        if registry_entry:
            default_base_url, key_env = registry_entry
        else:
            default_base_url, key_env = "https://api.openai.com/v1", "OPENAI_API_KEY"

        self.base_url = base_url or default_base_url
        self.api_key = api_key or os.environ.get(key_env, '') or os.environ.get('NB_LLM_API_KEY', '')
        self._client = None
        self._use_requests = (openai_sdk is None)

    def _get_client(self):
        if self._client is None:
            if openai_sdk is None:
                raise ImportError("Requires openai: pip install openai")
            self._client = openai_sdk.OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
            )
        return self._client

    @staticmethod
    def _summarize_response(raw_data: dict, preview_dims: int = 5) -> dict:
        """Generate response summary: preserve structure, show only first few dimensions of embedding vectors"""
        summary = {}
        for k, v in raw_data.items():
            if k == 'data':
                summary['data'] = []
                for item in v:
                    item_summary = {}
                    for ik, iv in item.items():
                        if ik == 'embedding' and isinstance(iv, list) and len(iv) > preview_dims * 2:
                            head = [round(x, 6) for x in iv[:preview_dims]]
                            tail = [round(x, 6) for x in iv[-2:]]
                            item_summary['embedding'] = f"{head} ... {tail}  ({len(iv)} dims)"
                        else:
                            item_summary[ik] = iv
                    summary['data'].append(item_summary)
            else:
                summary[k] = v
        return summary

    def _embed_via_requests(self, texts: List[str]) -> List[List[float]]:
        if _requests is None:
            raise ImportError("Requires requests or openai: pip install requests")
        url = self.base_url.rstrip('/') + '/embeddings'
        headers = {
            'Authorization': f'Bearer {self.api_key}',
            'Content-Type': 'application/json',
        }
        payload = {'model': self.model, 'input': texts}
        logger.debug("Sending Embedding request → %s\n%s",
                     self.model,
                     json.dumps(payload, ensure_ascii=False, indent=2))
        resp = _requests.post(url, headers=headers, json=payload, timeout=60)
        resp.raise_for_status()
        data = resp.json()
        logger.debug("Received Embedding response ← %s\n%s",
                     self.model,
                     json.dumps(self._summarize_response(data), ensure_ascii=False, indent=2))
        if not data.get('data'):
            raise ValueError(f"Embedding API returned empty data for model {self.model}")
        items = sorted(data['data'], key=lambda x: x['index'])
        vectors = [item['embedding'] for item in items]
        if len(vectors) != len(texts):
            logger.warning("Embedding count mismatch: sent %d texts, got %d vectors", len(texts), len(vectors))
        return vectors

    def embed(self, text: Union[str, List[str]],
              batch_size: int = 20) -> Union[List[float], List[List[float]]]:
        is_single = isinstance(text, str)
        texts = [text] if is_single else text

        if len(texts) <= batch_size:
            vectors = self._embed_batch(texts)
        else:
            vectors = []
            for i in range(0, len(texts), batch_size):
                batch = texts[i:i + batch_size]
                logger.debug("Batch Embedding: batch %d/%d (%d items)",
                             i // batch_size + 1,
                             (len(texts) + batch_size - 1) // batch_size,
                             len(batch))
                vectors.extend(self._embed_batch(batch))

        return vectors[0] if is_single else vectors

    def _truncate_texts(self, texts: List[str], max_chars: int) -> List[str]:
        if max_chars <= 0:
            return texts
        return [t[:max_chars] if len(t) > max_chars else t for t in texts]

    def _embed_single_safe(self, text: str) -> List[float]:
        """Embed a single text with auto-truncation on 413 (token limit exceeded)."""
        client = self._get_client()
        for ratio in (1.0, 0.7, 0.5, 0.3, 0.1):
            try:
                truncated = text[:int(len(text) * ratio)] if ratio < 1.0 else text
                resp = client.embeddings.create(model=self.model, input=[truncated])
                if not resp.data:
                    raise ValueError(f"Embedding API returned empty data for model {self.model}")
                return resp.data[0].embedding
            except Exception as e:
                if '413' in str(e) or 'less than 512' in str(e) or 'token' in str(e).lower():
                    logger.debug("Text too long (%d chars), truncating to %.0f%%", len(text), ratio * 100)
                    continue
                raise
        raise ValueError(
            f"Failed to embed text ({len(text)} chars) after all truncation attempts. "
            f"Model {self.model} may have a very low token limit."
        )

    def _embed_batch(self, texts: List[str]) -> List[List[float]]:
        if self._max_token_chars > 0:
            texts = self._truncate_texts(texts, self._max_token_chars)

        if self._use_requests:
            return self._embed_via_requests(texts)

        client = self._get_client()
        try:
            resp = client.embeddings.create(model=self.model, input=texts)
            if not resp.data:
                raise ValueError(f"Embedding API returned empty data for model {self.model}")
            vectors = [item.embedding for item in resp.data]
        except Exception as e:
            if '413' in str(e) or 'less than 512' in str(e):
                logger.debug("Batch 413, falling back to single-text mode with auto-truncation")
                vectors = [self._embed_single_safe(t) for t in texts]
            else:
                raise

        if not vectors:
            raise ValueError(f"No embedding vectors received from {self.model}")
        if len(vectors) != len(texts):
            logger.warning("Embedding count mismatch: sent %d texts, got %d vectors", len(texts), len(vectors))
        logger.debug("Embedded %d texts, dimensions: %d", len(vectors), len(vectors[0]))
        return vectors

    def __call__(self, text: Union[str, List[str]]) -> Union[List[float], List[List[float]]]:
        return self.embed(text)

    def __repr__(self):
        return f"Embedding(model={self.model!r})"
