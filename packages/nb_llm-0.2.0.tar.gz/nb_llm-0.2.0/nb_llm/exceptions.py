"""nb_llm exception hierarchy"""
from __future__ import annotations


class NbLLMError(Exception):
    """nb_llm base exception"""
    pass


class ProviderError(NbLLMError):
    """Provider API error"""
    pass


class RateLimitError(ProviderError):
    """Rate limit exceeded"""
    pass


class TokenLimitError(ProviderError):
    """Token limit exceeded"""

    def __init__(self, message, limit=None, used=None):
        self.limit = limit
        self.used = used
        super().__init__(message)


class AuthenticationError(ProviderError):
    """Authentication failed (invalid API Key)"""
    pass


class TimeoutError(ProviderError):
    """Request timeout"""
    pass


class ToolExecutionError(NbLLMError):
    """Tool execution failed"""

    def __init__(self, tool_name, args, original_error):
        self.tool_name = tool_name
        self.args = args
        self.original_error = original_error
        super().__init__(f"Tool '{tool_name}' failed: {original_error}")


class SchemaGenerationError(NbLLMError):
    """Failed to generate Schema from function signature"""
    pass


class JsonParseError(NbLLMError):
    """JSON parse failed (after retries when json=True)"""

    def __init__(self, message, raw_text=None, parse_error=None):
        self.raw_text = raw_text
        self.parse_error = parse_error
        super().__init__(message)


class SchemaValidationError(NbLLMError):
    """Structured output validation failed (after retries when response_type is set)"""

    def __init__(self, message, raw_text=None, validation_error=None, response_type=None):
        self.raw_text = raw_text
        self.validation_error = validation_error
        self.response_type = response_type
        super().__init__(message)
