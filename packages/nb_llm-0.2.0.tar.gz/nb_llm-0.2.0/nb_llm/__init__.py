"""
nb_llm — A powerful LLM framework
"""
from nb_llm.core.chat import Chat, ChatSession, Pipeline
from nb_llm.core.config import ChatConfig, SendOptions, RAGConfig
from nb_llm.core.response import ChatResponse, StreamResponse
from nb_llm.core.data_types import (
    UsageInfo, ToolCallRecord, PendingToolCall,
    SourceInfo, TeamMessage, TeamResult, CostTracker,
    DataMixin,
)
from nb_llm.core.base_model import NbBaseModel
from nb_llm.core.history_backends import (
    HistoryBackend, MemoryBackend, FileBackend, SqliteBackend, RedisBackend,
)
from nb_llm.middleware.cache import ResponseCache
from nb_llm.exceptions import (
    NbLLMError, ProviderError, RateLimitError, TokenLimitError,
    AuthenticationError, TimeoutError, ToolExecutionError,
    SchemaGenerationError, JsonParseError, SchemaValidationError,
)
from nb_llm.providers.registry import register_provider
from nb_llm.embedding.embedding import Embedding
from nb_llm.rag.rag import RAG
from nb_llm.rag.vectorstore import MemoryVectorStore, FaissVectorStore, ChromaVectorStore
from nb_llm.agents.router import Router
from nb_llm.agents.team import Team
from nb_llm.workflow.step import step
from nb_llm.loggers import (  # noqa: F401 - expose loggers for user discovery
    logger_request, logger_response, logger_tools,
    logger_history, logger_cache, logger_retry,
    logger_router, logger_team, logger_pipeline, logger_rag,
    logger_embedding,
)

__version__ = "0.1.0"

__all__ = [
    # Core
    "Chat", "ChatConfig", "SendOptions", "RAGConfig",
    # Response types
    "ChatResponse", "StreamResponse",
    "UsageInfo", "ToolCallRecord", "PendingToolCall",
    "SourceInfo", "TeamMessage", "TeamResult", "CostTracker",
    # Session & Pipeline
    "ChatSession", "Pipeline",
    # Agent capabilities
    "RAG", "Router", "Team", "Embedding", "step",
    # History backends
    "HistoryBackend", "MemoryBackend", "FileBackend", "SqliteBackend", "RedisBackend",
    # Middleware
    "ResponseCache",
    # Base
    "NbBaseModel", "DataMixin",
    # Exceptions
    "NbLLMError", "ProviderError", "RateLimitError", "TokenLimitError",
    "AuthenticationError", "TimeoutError", "ToolExecutionError",
    "SchemaGenerationError", "JsonParseError", "SchemaValidationError",
    # Utility functions
    "register_provider",
]
