"""Model registry & API Key auto-discovery"""
from __future__ import annotations

import os
from typing import Dict, List, Optional, Tuple

_ModelEntry = Tuple[str, str, Optional[str]]

MODEL_REGISTRY: Dict[str, _ModelEntry] = {
    # OpenAI
    "gpt-4o": ("openai_compatible", "gpt-4o", "https://api.openai.com/v1"),
    "gpt-4o-mini": ("openai_compatible", "gpt-4o-mini", "https://api.openai.com/v1"),
    "gpt4": ("openai_compatible", "gpt-4o", "https://api.openai.com/v1"),
    "gpt-4": ("openai_compatible", "gpt-4o", "https://api.openai.com/v1"),
    "gpt-3.5": ("openai_compatible", "gpt-3.5-turbo", "https://api.openai.com/v1"),
    "gpt-3.5-turbo": ("openai_compatible", "gpt-3.5-turbo", "https://api.openai.com/v1"),
    "o1": ("openai_compatible", "o1", "https://api.openai.com/v1"),
    "o1-mini": ("openai_compatible", "o1-mini", "https://api.openai.com/v1"),

    # DeepSeek
    "deepseek": ("openai_compatible", "deepseek-chat", "https://api.deepseek.com/v1"),
    "deepseek-chat": ("openai_compatible", "deepseek-chat", "https://api.deepseek.com/v1"),
    "deepseek-coder": ("openai_compatible", "deepseek-coder", "https://api.deepseek.com/v1"),
    "deepseek-reasoner": ("openai_compatible", "deepseek-reasoner", "https://api.deepseek.com/v1"),

    # Qwen (Alibaba)
    "qwen": ("openai_compatible", "qwen-plus", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
    "qwen-plus": ("openai_compatible", "qwen-plus", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
    "qwen-turbo": ("openai_compatible", "qwen-turbo", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
    "qwen-max": ("openai_compatible", "qwen-max", "https://dashscope.aliyuncs.com/compatible-mode/v1"),
    "qwen-long": ("openai_compatible", "qwen-long", "https://dashscope.aliyuncs.com/compatible-mode/v1"),

    # Zhipu GLM
    "glm": ("openai_compatible", "glm-4", "https://open.bigmodel.cn/api/paas/v4"),
    "glm-4": ("openai_compatible", "glm-4", "https://open.bigmodel.cn/api/paas/v4"),
    "glm-4-flash": ("openai_compatible", "glm-4-flash", "https://open.bigmodel.cn/api/paas/v4"),

    # SiliconFlow
    "siliconflow": ("openai_compatible", "deepseek-ai/DeepSeek-V3", "https://api.siliconflow.cn/v1"),

    # Anthropic Claude
    "claude": ("anthropic", "claude-sonnet-4-20250514", None),
    "claude-sonnet": ("anthropic", "claude-sonnet-4-20250514", None),
    "claude-opus": ("anthropic", "claude-opus-4-20250514", None),
    "claude-haiku": ("anthropic", "claude-3-5-haiku-20241022", None),

    # Ollama (local deployment)
    "ollama": ("openai_compatible", "llama3", "http://localhost:11434/v1"),
}

API_KEY_ENV_MAP: Dict[str, List[str]] = {
    "openai": ["OPENAI_API_KEY"],
    "deepseek": ["DEEPSEEK_API_KEY"],
    "qwen": ["DASHSCOPE_API_KEY", "QWEN_API_KEY"],
    "glm": ["ZHIPUAI_API_KEY", "GLM_API_KEY"],
    "anthropic": ["ANTHROPIC_API_KEY"],
    "siliconflow": ["SILICONFLOW_API_KEY"],
    "ollama": [],
}

_PREFIX_TO_KEY_GROUP = {
    "gpt": "openai",
    "o1": "openai",
    "deepseek": "deepseek",
    "qwen": "qwen",
    "glm": "glm",
    "claude": "anthropic",
    "anthropic": "anthropic",
    "siliconflow": "siliconflow",
    "ollama": "ollama",
}


def _load_dotenv_if_needed() -> None:
    try:
        from dotenv import load_dotenv
        load_dotenv()
    except ImportError:
        pass


def discover_api_key(model_alias: str) -> Optional[str]:
    """Auto-discover API Key by model name"""
    _load_dotenv_if_needed()

    key_group = None
    for prefix, group in _PREFIX_TO_KEY_GROUP.items():
        if model_alias.lower().startswith(prefix):
            key_group = group
            break

    if key_group:
        env_names = API_KEY_ENV_MAP.get(key_group, [])
        for name in env_names:
            val = os.environ.get(name)
            if val:
                return val

    return os.environ.get('NB_LLM_API_KEY')


def resolve_model(model_alias: str,
                  config: object = None) -> Tuple[str, str, str]:
    """
    Resolve model alias → (actual_model, base_url, api_key)
    Priority: config explicit values > registry > auto-discovery
    """
    from nb_llm.core.config import ChatConfig

    if config is None:
        config = ChatConfig()

    entry = MODEL_REGISTRY.get(model_alias.lower())
    if entry:
        _, actual_model, default_base_url = entry
    else:
        actual_model = model_alias
        default_base_url = None

    base_url = getattr(config, 'base_url', None) or default_base_url
    if not base_url:
        base_url = "https://api.openai.com/v1"

    api_key = getattr(config, 'api_key', None) or discover_api_key(model_alias)

    return actual_model, base_url, api_key or ''


def register_provider(name: str, model: str, base_url: str,
                      api_key_env: Optional[str] = None) -> None:
    """Register a custom provider"""
    MODEL_REGISTRY[name.lower()] = ("openai_compatible", model, base_url)
    if api_key_env:
        API_KEY_ENV_MAP[name.lower()] = [api_key_env]
        _PREFIX_TO_KEY_GROUP[name.lower()] = name.lower()
