"""Universal adapter for OpenAI-compatible APIs"""
from __future__ import annotations

import json
import logging
import time
from typing import TYPE_CHECKING, AsyncIterator, Iterator, Optional

from nb_llm.exceptions import (
    AuthenticationError, ProviderError, RateLimitError,
    TokenLimitError, TimeoutError as NbTimeoutError,
)
from nb_llm.loggers import logger_request, logger_response
from nb_llm.providers.base import BaseProvider

if TYPE_CHECKING:
    from nb_llm.core.config import ChatConfig, SendOptions

try:
    import httpx
except ImportError:
    httpx = None

try:
    import openai as openai_sdk
except ImportError:
    openai_sdk = None


def _merge_params(config: Optional[ChatConfig],
                  options: Optional[SendOptions]) -> dict:
    """Merge ChatConfig + SendOptions into API request parameters"""
    params: dict = {}
    if config:
        for attr in ('temperature', 'max_tokens', 'top_p', 'stop',
                      'frequency_penalty', 'presence_penalty', 'seed',
                      'logprobs', 'top_logprobs'):
            val = getattr(config, attr, None)
            if val is not None:
                params[attr] = val
    if options:
        for attr in ('temperature', 'max_tokens', 'top_p', 'stop',
                      'frequency_penalty', 'presence_penalty', 'seed',
                      'logprobs', 'top_logprobs'):
            val = getattr(options, attr, None)
            if val is not None:
                params[attr] = val
        if options.n and options.n > 1:
            params['n'] = options.n
    return params


def _handle_api_error(status_code: int, body_text: str) -> None:
    if status_code == 401:
        raise AuthenticationError(f"Invalid API Key (401): {body_text}")
    elif status_code == 429:
        raise RateLimitError(f"Rate limit exceeded (429): {body_text}")
    elif status_code >= 400:
        raise ProviderError(f"API error ({status_code}): {body_text}")


class OpenAICompatibleProvider(BaseProvider):
    """Universal adapter for OpenAI-compatible APIs.
    Covers: OpenAI, DeepSeek, Qwen(DashScope), GLM, SiliconFlow, Ollama, any v1/chat/completions compatible API.
    Prefers openai SDK, falls back to httpx raw requests.
    """

    def __init__(self, model: str, base_url: str, api_key: str,
                 timeout: Optional[float] = None) -> None:
        self.model = model
        self.base_url = base_url.rstrip('/')
        self.api_key = api_key or ''
        self.timeout = timeout or 120.0
        self._client = None
        self._async_client = None
        self._use_sdk = openai_sdk is not None

    def _get_sdk_client(self):
        if self._client is None:
            self._client = openai_sdk.OpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=self.timeout,
            )
        return self._client

    def _build_request_body(self, messages: list,
                            config: Optional[ChatConfig],
                            options: Optional[SendOptions],
                            tools: Optional[list],
                            stream: bool = False) -> dict:
        body = {
            'model': self.model,
            'messages': messages,
        }
        if stream:
            body['stream'] = True
            body['stream_options'] = {'include_usage': True}

        params = _merge_params(config, options)
        body.update(params)

        if tools:
            body['tools'] = tools
            if options and options.tool_choice != 'auto':
                tc = options.tool_choice
                if tc in ('none', 'required'):
                    body['tool_choice'] = tc
                else:
                    body['tool_choice'] = {'type': 'function', 'function': {'name': tc}}

        if options and options.json and not options.response_type:
            body['response_format'] = {'type': 'json_object'}

        return body

    def chat_completion(self, messages: list,
                        config: Optional[ChatConfig] = None,
                        options: Optional[SendOptions] = None,
                        tools: Optional[list] = None) -> dict:
        body = self._build_request_body(messages, config, options, tools)
        logger_request.debug("Sending request → %s\n%s",
                             self.model, json.dumps(body, ensure_ascii=False, indent=2))

        if self._use_sdk:
            result = self._sdk_chat(messages, config, options, tools)
        else:
            result = self._http_chat(messages, config, options, tools)

        logger_response.debug("Received response ← %s\n%s",
                              self.model, json.dumps(result, ensure_ascii=False, indent=2))
        return result

    def _sdk_chat(self, messages: list, config: Optional[ChatConfig],
                  options: Optional[SendOptions],
                  tools: Optional[list]) -> dict:
        client = self._get_sdk_client()
        body = self._build_request_body(messages, config, options, tools)
        body.pop('model', None)
        model = self.model

        try:
            resp = client.chat.completions.create(model=model, **body)
            return resp.model_dump() if hasattr(resp, 'model_dump') else resp.to_dict()
        except openai_sdk.AuthenticationError as e:
            raise AuthenticationError(str(e))
        except openai_sdk.RateLimitError as e:
            raise RateLimitError(str(e))
        except openai_sdk.APITimeoutError as e:
            raise NbTimeoutError(str(e))
        except openai_sdk.BadRequestError as e:
            if 'maximum context length' in str(e).lower() or 'token' in str(e).lower():
                raise TokenLimitError(str(e))
            raise ProviderError(str(e))
        except openai_sdk.APIError as e:
            raise ProviderError(str(e))

    def _http_chat(self, messages: list, config: Optional[ChatConfig],
                   options: Optional[SendOptions],
                   tools: Optional[list]) -> dict:
        if httpx is None:
            raise ImportError("Requires openai or httpx: pip install openai")

        body = self._build_request_body(messages, config, options, tools)
        url = f"{self.base_url}/chat/completions"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }

        try:
            with httpx.Client(timeout=self.timeout) as client:
                resp = client.post(url, json=body, headers=headers)
        except httpx.TimeoutException as e:
            raise NbTimeoutError(str(e))

        _handle_api_error(resp.status_code, resp.text)
        return resp.json()

    def stream_completion(self, messages: list,
                          config: Optional[ChatConfig] = None,
                          options: Optional[SendOptions] = None) -> Iterator[dict]:
        if self._use_sdk:
            yield from self._sdk_stream(messages, config, options)
        else:
            yield from self._http_stream(messages, config, options)

    def _sdk_stream(self, messages: list, config: Optional[ChatConfig],
                    options: Optional[SendOptions]) -> Iterator[dict]:
        client = self._get_sdk_client()
        body = self._build_request_body(messages, config, options, tools=None, stream=True)
        body.pop('model', None)
        body.pop('stream', None)
        body.pop('stream_options', None)
        model = self.model

        try:
            stream = client.chat.completions.create(
                model=model, stream=True,
                stream_options={'include_usage': True},
                **body,
            )
            for chunk in stream:
                chunk_dict = chunk.model_dump() if hasattr(chunk, 'model_dump') else chunk.to_dict()
                yield chunk_dict
        except openai_sdk.AuthenticationError as e:
            raise AuthenticationError(str(e))
        except openai_sdk.RateLimitError as e:
            raise RateLimitError(str(e))
        except openai_sdk.APITimeoutError as e:
            raise NbTimeoutError(str(e))
        except openai_sdk.APIError as e:
            raise ProviderError(str(e))

    def _http_stream(self, messages: list, config: Optional[ChatConfig],
                     options: Optional[SendOptions]) -> Iterator[dict]:
        if httpx is None:
            raise ImportError("Requires openai or httpx: pip install openai")

        body = self._build_request_body(messages, config, options, tools=None, stream=True)
        url = f"{self.base_url}/chat/completions"
        headers = {
            'Content-Type': 'application/json',
            'Authorization': f'Bearer {self.api_key}',
        }

        try:
            with httpx.Client(timeout=self.timeout) as client:
                with client.stream('POST', url, json=body, headers=headers) as resp:
                    _handle_api_error(resp.status_code, '')
                    for line in resp.iter_lines():
                        if not line or not line.startswith('data: '):
                            continue
                        data = line[6:]
                        if data.strip() == '[DONE]':
                            break
                        yield json.loads(data)
        except httpx.TimeoutException as e:
            raise NbTimeoutError(str(e))

    # ==================== Async Methods ====================

    def _get_async_sdk_client(self):
        if self._async_client is None:
            self._async_client = openai_sdk.AsyncOpenAI(
                api_key=self.api_key,
                base_url=self.base_url,
                timeout=self.timeout,
            )
        return self._async_client

    async def aio_chat_completion(self, messages: list,
                               config: Optional[ChatConfig] = None,
                               options: Optional[SendOptions] = None,
                               tools: Optional[list] = None) -> dict:
        body = self._build_request_body(messages, config, options, tools)
        logger_request.debug("[async] Sending request → %s\n%s",
                             self.model, json.dumps(body, ensure_ascii=False, indent=2))

        if self._use_sdk:
            result = await self._async_sdk_chat(messages, config, options, tools)
        else:
            result = self.chat_completion(messages, config, options, tools)

        logger_response.debug("[async] Received response ← %s\n%s",
                              self.model, json.dumps(result, ensure_ascii=False, indent=2))
        return result

    async def _async_sdk_chat(self, messages: list, config: Optional[ChatConfig],
                               options: Optional[SendOptions],
                               tools: Optional[list]) -> dict:
        client = self._get_async_sdk_client()
        body = self._build_request_body(messages, config, options, tools)
        body.pop('model', None)

        try:
            resp = await client.chat.completions.create(model=self.model, **body)
            return resp.model_dump() if hasattr(resp, 'model_dump') else resp.to_dict()
        except openai_sdk.AuthenticationError as e:
            raise AuthenticationError(str(e))
        except openai_sdk.RateLimitError as e:
            raise RateLimitError(str(e))
        except openai_sdk.APITimeoutError as e:
            raise NbTimeoutError(str(e))
        except openai_sdk.BadRequestError as e:
            if 'maximum context length' in str(e).lower() or 'token' in str(e).lower():
                raise TokenLimitError(str(e))
            raise ProviderError(str(e))
        except openai_sdk.APIError as e:
            raise ProviderError(str(e))

    async def aio_stream_completion(self, messages: list,
                                 config: Optional[ChatConfig] = None,
                                 options: Optional[SendOptions] = None) -> AsyncIterator[dict]:
        if self._use_sdk:
            async for chunk in self._async_sdk_stream(messages, config, options):
                yield chunk
        else:
            for chunk in self.stream_completion(messages, config, options):
                yield chunk

    async def _async_sdk_stream(self, messages: list, config: Optional[ChatConfig],
                                 options: Optional[SendOptions]) -> AsyncIterator[dict]:
        client = self._get_async_sdk_client()
        body = self._build_request_body(messages, config, options, tools=None, stream=True)
        body.pop('model', None)
        body.pop('stream', None)
        body.pop('stream_options', None)

        try:
            stream = await client.chat.completions.create(
                model=self.model, stream=True,
                stream_options={'include_usage': True},
                **body,
            )
            async for chunk in stream:
                chunk_dict = chunk.model_dump() if hasattr(chunk, 'model_dump') else chunk.to_dict()
                yield chunk_dict
        except openai_sdk.AuthenticationError as e:
            raise AuthenticationError(str(e))
        except openai_sdk.RateLimitError as e:
            raise RateLimitError(str(e))
        except openai_sdk.APITimeoutError as e:
            raise NbTimeoutError(str(e))
        except openai_sdk.APIError as e:
            raise ProviderError(str(e))
