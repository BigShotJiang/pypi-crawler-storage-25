"""Provider base class"""
from __future__ import annotations

from abc import ABC, abstractmethod
from typing import TYPE_CHECKING, AsyncIterator, Iterator, List, Optional

if TYPE_CHECKING:
    from nb_llm.core.config import ChatConfig, SendOptions


class BaseProvider(ABC):
    """Base class for all provider adapters"""

    @abstractmethod
    def chat_completion(self, messages: list,
                        config: Optional[ChatConfig] = None,
                        options: Optional[SendOptions] = None,
                        tools: Optional[list] = None) -> dict:
        ...

    @abstractmethod
    def stream_completion(self, messages: list,
                          config: Optional[ChatConfig] = None,
                          options: Optional[SendOptions] = None) -> Iterator[dict]:
        ...

    async def aio_chat_completion(self, messages: list,
                               config: Optional[ChatConfig] = None,
                               options: Optional[SendOptions] = None,
                               tools: Optional[list] = None) -> dict:
        return self.chat_completion(messages, config, options, tools)

    async def aio_stream_completion(self, messages: list,
                                 config: Optional[ChatConfig] = None,
                                 options: Optional[SendOptions] = None) -> AsyncIterator[dict]:
        for chunk in self.stream_completion(messages, config, options):
            yield chunk
