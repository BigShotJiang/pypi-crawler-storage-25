"""Anthropic (Claude) Provider adapter"""
from __future__ import annotations

from typing import Any, Dict, Iterator, List, Optional

from nb_llm.providers.base import BaseProvider


class AnthropicProvider(BaseProvider):
    """Anthropic Claude API adapter.
    Converts Anthropic message format to OpenAI-compatible format.
    Requires pip install anthropic
    """

    def __init__(self, model: str = 'claude-sonnet-4-20250514',
                 api_key: Optional[str] = None,
                 timeout: Optional[float] = None) -> None:
        self.model = model
        self._api_key = api_key
        self._timeout = timeout
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                import anthropic
            except ImportError:
                raise ImportError(
                    "Anthropic Provider requires anthropic package: pip install anthropic"
                )
            kwargs = {}
            if self._api_key:
                kwargs['api_key'] = self._api_key
            if self._timeout:
                kwargs['timeout'] = self._timeout
            self._client = anthropic.Anthropic(**kwargs)
        return self._client

    def chat_completion(self, messages: List[dict],
                        config: Any = None, options: Any = None,
                        tools: Optional[List[dict]] = None) -> dict:
        client = self._get_client()

        system_msg = None
        chat_messages = []
        for msg in messages:
            if msg['role'] == 'system':
                system_msg = msg['content']
            else:
                chat_messages.append({
                    'role': msg['role'],
                    'content': msg['content'],
                })

        kwargs: Dict[str, Any] = {
            'model': self.model,
            'messages': chat_messages,
            'max_tokens': 4096,
        }

        if system_msg:
            kwargs['system'] = system_msg

        temp = getattr(config, 'temperature', None) if config else None
        if options and getattr(options, 'temperature', None) is not None:
            temp = options.temperature
        if temp is not None:
            kwargs['temperature'] = temp

        max_tokens = getattr(config, 'max_tokens', None) if config else None
        if options and getattr(options, 'max_tokens', None) is not None:
            max_tokens = options.max_tokens
        if max_tokens is not None:
            kwargs['max_tokens'] = max_tokens

        response = client.messages.create(**kwargs)

        text = ''
        if response.content:
            for block in response.content:
                if hasattr(block, 'text'):
                    text += block.text

        return {
            'id': response.id,
            'model': response.model,
            'choices': [{
                'message': {'role': 'assistant', 'content': text},
                'finish_reason': response.stop_reason or 'stop',
            }],
            'usage': {
                'prompt_tokens': response.usage.input_tokens,
                'completion_tokens': response.usage.output_tokens,
                'total_tokens': (
                    response.usage.input_tokens + response.usage.output_tokens
                ),
            },
        }

    def stream_completion(self, messages: List[dict],
                          config: Any = None,
                          options: Any = None) -> Iterator[dict]:
        client = self._get_client()

        system_msg = None
        chat_messages = []
        for msg in messages:
            if msg['role'] == 'system':
                system_msg = msg['content']
            else:
                chat_messages.append({
                    'role': msg['role'],
                    'content': msg['content'],
                })

        kwargs: Dict[str, Any] = {
            'model': self.model,
            'messages': chat_messages,
            'max_tokens': 4096,
        }
        if system_msg:
            kwargs['system'] = system_msg

        with client.messages.stream(**kwargs) as stream:
            for text in stream.text_stream:
                yield {
                    'choices': [{
                        'delta': {'content': text},
                        'finish_reason': None,
                    }],
                }

            final_message = stream.get_final_message()
            yield {
                'choices': [{
                    'delta': {'content': ''},
                    'finish_reason': final_message.stop_reason or 'stop',
                }],
                'usage': {
                    'prompt_tokens': final_message.usage.input_tokens,
                    'completion_tokens': final_message.usage.output_tokens,
                    'total_tokens': (
                        final_message.usage.input_tokens
                        + final_message.usage.output_tokens
                    ),
                },
            }
