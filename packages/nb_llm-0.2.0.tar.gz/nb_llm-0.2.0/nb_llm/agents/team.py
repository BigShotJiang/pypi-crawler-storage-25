"""Team multi-agent collaboration"""
from __future__ import annotations

from typing import TYPE_CHECKING, List, Optional

from nb_llm.core.data_types import TeamMessage, TeamResult
from nb_llm.loggers import logger_team as logger

if TYPE_CHECKING:
    from nb_llm.core.chat import Chat


class Team:
    """Multi-agent collaboration team.
    Supports round-robin discussion where each agent can see all previous messages.
    """

    def __init__(self, *agents: Chat,
                 moderator: Optional[Chat] = None) -> None:
        if not agents:
            raise ValueError("Team requires at least one agent")
        self.agents = list(agents)
        self.moderator = moderator

    def discuss(self, topic: str, rounds: int = 3) -> TeamResult:
        logger.debug("Starting discussion, topic: %s, rounds: %d, agents: %d",
                     topic, rounds, len(self.agents))
        transcript: List[TeamMessage] = []
        shared_context = f"Discussion topic: {topic}\n\n"

        for round_num in range(rounds):
            for agent in self.agents:
                agent_name = agent.name or f"Agent-{id(agent) % 1000}"
                prompt = f"{shared_context}Please share your perspective as {agent_name}:"
                response = agent.ask(prompt)

                msg = TeamMessage(
                    agent_name=agent_name,
                    round=round_num + 1,
                    content=str(response),
                )
                transcript.append(msg)
                shared_context += f"[{msg.agent_name}] (Round {msg.round}): {msg.content}\n\n"
                logger.debug("[Round %d] %s: %.100s...",
                             round_num + 1, agent_name, msg.content)

        summarizer = self.moderator or self.agents[0]
        logger.debug("Summary phase, executed by %s",
                     getattr(summarizer, 'name', None) or 'moderator')
        conclusion = summarizer.ask(f"Please summarize the conclusions of the following discussion:\n{shared_context}")

        return TeamResult(
            conclusion=str(conclusion),
            transcript=transcript,
            rounds=rounds,
        )

    def __repr__(self):
        names = [a.name or '?' for a in self.agents]
        return f"Team({', '.join(names)})"
