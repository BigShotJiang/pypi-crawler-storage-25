"""Router intelligent router"""
from __future__ import annotations

from typing import TYPE_CHECKING, Dict, Optional

from nb_llm.loggers import logger_router as logger

if TYPE_CHECKING:
    from nb_llm.core.chat import Chat
    from nb_llm.core.config import SendOptions
    from nb_llm.core.response import ChatResponse


class Router:
    """Intelligent router.
    Automatically routes user input to the appropriate expert Chat.
    """

    def __init__(self, experts: Dict[str, Chat],
                 classifier: Chat) -> None:
        if not experts:
            raise ValueError("Router requires at least one expert")
        self.experts = experts
        self.classifier = classifier
        self.last_route: Optional[str] = None
        self.last_classify_raw: Optional[str] = None

    def send(self, prompt: str,
             options: Optional[SendOptions] = None) -> ChatResponse:
        expert_names = list(self.experts.keys())
        classify_prompt = (
            f"Classify the following user input into one of the categories. Reply with the category name only, no explanation.\n"
            f"Available categories: {', '.join(expert_names)}\n"
            f"User input: {prompt}"
        )
        logger.debug("Classification query: %s", classify_prompt)
        category = str(self.classifier.ask(classify_prompt)).strip().lower()
        self.last_classify_raw = category
        logger.debug("Model classification result: '%s'", category)

        matched_name = None
        expert = self.experts.get(category)
        if expert is not None:
            matched_name = category

        if expert is None:
            for name, chat in self.experts.items():
                if name.lower() in category or category in name.lower():
                    expert = chat
                    matched_name = name
                    break

        if expert is None:
            matched_name = list(self.experts.keys())[0]
            expert = list(self.experts.values())[0]
            logger.debug("No exact match, falling back to default expert: %s", matched_name)

        self.last_route = matched_name
        logger.debug("Final route → expert '%s'", matched_name)
        return expert.send(prompt, options)

    def __call__(self, prompt: str,
                 options: Optional[SendOptions] = None) -> ChatResponse:
        return self.send(prompt, options)

    def __repr__(self):
        names = list(self.experts.keys())
        return f"Router(experts={names})"
