"""@step observability decorator"""
from __future__ import annotations

import functools
import time
import uuid
from typing import Any, Callable, List, Optional

_event_listeners: List[Callable] = []


def on_step_event(listener: Callable) -> Callable:
    """Register step event listener"""
    _event_listeners.append(listener)
    return listener


def _emit_event(event_type: str, data: dict) -> None:
    for listener in _event_listeners:
        try:
            listener(event_type, data)
        except Exception:
            pass


class step:
    """@step decorator.
    Pure enhancement decorator, does not change function behavior, only adds observability.
    """

    def __init__(self, name_or_func: Any = None) -> None:
        if callable(name_or_func):
            self._name = name_or_func.__name__
            self._func = name_or_func
            functools.update_wrapper(self, name_or_func)
        else:
            self._name = name_or_func
            self._func = None

    def __call__(self, *args, **kwargs):
        if self._func is None:
            func = args[0]
            name = self._name or func.__name__

            @functools.wraps(func)
            def wrapper(*a, **kw):
                return self._execute(func, name, *a, **kw)
            return wrapper
        else:
            return self._execute(self._func, self._name, *args, **kwargs)

    @staticmethod
    def _execute(func: Callable, name: str, *args, **kwargs) -> Any:
        step_id = str(uuid.uuid4())[:8]
        start = time.time()

        _emit_event("step_start", {
            "step_id": step_id,
            "name": name,
        })

        try:
            result = func(*args, **kwargs)
            elapsed = time.time() - start

            _emit_event("step_end", {
                "step_id": step_id,
                "name": name,
                "elapsed": elapsed,
            })
            return result

        except Exception as e:
            elapsed = time.time() - start
            _emit_event("step_error", {
                "step_id": step_id,
                "name": name,
                "error": str(e),
                "elapsed": elapsed,
            })
            raise
