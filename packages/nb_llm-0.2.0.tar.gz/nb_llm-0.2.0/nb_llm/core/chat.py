"""Chat core class — the heart of nb_llm framework"""
from __future__ import annotations

import copy
import json as json_mod
from typing import Any, Callable, Dict, List, Optional, Union

from nb_llm.core.config import ChatConfig, SendOptions
from nb_llm.loggers import logger_cache, logger_retry, logger_pipeline
from nb_llm.core.data_types import (
    CostTracker, PendingToolCall, SourceInfo, UsageInfo,
)
from nb_llm.core.history_backends import HistoryBackend, create_backend
from nb_llm.core.response import ChatResponse, StreamResponse
from nb_llm.exceptions import (
    JsonParseError, ProviderError, SchemaValidationError,
)
from nb_llm.middleware.cache import ResponseCache
from nb_llm.providers.openai_provider import OpenAICompatibleProvider
from nb_llm.providers.registry import resolve_model
from nb_llm.tools.executor import ToolExecutor
from nb_llm.tools.schema import func_to_schema


def _schema_type_placeholder(ftype: str):
    """Generate placeholder value based on JSON Schema type"""
    placeholders = {
        'string': '...', 'integer': 0, 'number': 0.0,
        'boolean': True, 'array': [], 'object': {},
    }
    return placeholders.get(ftype, '...')


class Chat:
    """
    Core class of nb_llm. Acts as LLM client, conversation manager, and Agent.
    """

    def __init__(self, config: Union[ChatConfig, str, None] = None) -> None:
        if config is None:
            config = ChatConfig()
        elif isinstance(config, str):
            config = ChatConfig(model=config)

        self.config = config
        self._history: List[dict] = []
        self._tool_executor = ToolExecutor()
        self._cost_tracker: Optional[CostTracker] = None
        self._last_usage = UsageInfo()

        self._hooks_before: List[Callable] = []
        self._hooks_after: List[Callable] = []
        self._hooks_error: List[Callable] = []
        self._hooks_tool_call: List[Callable] = []

        self._sessions: Dict[str, ChatSession] = {}

        self._cache: Optional[ResponseCache] = None
        if config.cache:
            self._cache = ResponseCache(ttl=config.cache_ttl)

        self._history_backend: HistoryBackend = create_backend(
            config.history_backend, config.history_url,
        )
        stored = self._history_backend.load()
        if stored:
            self._history = stored

        self._provider = self._create_provider()

    def _create_provider(self):
        from nb_llm.providers.base import BaseProvider
        from nb_llm.providers.registry import MODEL_REGISTRY

        model_name = self.config.model
        if isinstance(model_name, list):
            model_name = model_name[0]
        if not model_name:
            model_name = 'gpt-4o'

        entry = MODEL_REGISTRY.get(model_name.lower())
        provider_type = entry[0] if entry else 'openai_compatible'

        actual_model, base_url, api_key = resolve_model(model_name, self.config)

        if provider_type == 'anthropic':
            from nb_llm.providers.anthropic_provider import AnthropicProvider
            return AnthropicProvider(
                model=actual_model,
                api_key=api_key,
                timeout=self.config.timeout,
            )

        return OpenAICompatibleProvider(
            model=actual_model,
            base_url=base_url,
            api_key=api_key,
            timeout=self.config.timeout,
        )

    # ==================== Core API ====================

    def send(self, prompt: str, options: Optional[SendOptions] = None) -> ChatResponse:
        messages = self._build_messages(prompt, options)
        response = self._call_with_hooks(messages, options)

        text = self._extract_text(response)
        chat_resp = self._build_chat_response(response, text, options)

        self._history.append({'role': 'user', 'content': prompt})
        self._history.append({'role': 'assistant', 'content': str(chat_resp)})
        self._trim_history()
        self._persist_history()

        return chat_resp

    def ask(self, prompt: str, options: Optional[SendOptions] = None) -> ChatResponse:
        messages = self._build_messages(prompt, options, include_history=False)
        response = self._call_with_hooks(messages, options)

        text = self._extract_text(response)
        return self._build_chat_response(response, text, options)

    def __call__(self, prompt: str, options: Optional[SendOptions] = None) -> ChatResponse:
        return self.send(prompt, options)

    # ==================== Streaming ====================

    def stream(self, prompt: str, options: Optional[SendOptions] = None,
               on_chunk: Optional[Callable] = None) -> StreamResponse:
        messages = self._build_messages(prompt, options)

        self._fire_before_hooks(messages, options)
        try:
            stream_iter = self._provider.stream_completion(messages, self.config, options)
        except Exception as e:
            self._fire_error_hooks(e)
            raise

        def _wrapped_iter():
            for chunk in stream_iter:
                if on_chunk:
                    on_chunk(chunk)
                yield chunk

        def _on_stream_done(full_text: str):
            self._history.append({'role': 'assistant', 'content': full_text})
            self._trim_history()
            self._persist_history()

        sr = StreamResponse(
            _wrapped_iter(), model_name=self._provider.model,
            on_done=_on_stream_done,
        )

        self._history.append({'role': 'user', 'content': prompt})
        return sr

    # ==================== Batch ====================

    def batch(self, prompts: List[str], options: Optional[SendOptions] = None,
              concurrency: int = 5) -> List[ChatResponse]:
        from concurrent.futures import ThreadPoolExecutor, as_completed
        results: List[Optional[ChatResponse]] = [None] * len(prompts)

        def _ask_one(idx: int, prompt: str):
            return idx, self.ask(prompt, options)

        with ThreadPoolExecutor(max_workers=concurrency) as pool:
            futures = {pool.submit(_ask_one, i, p): i for i, p in enumerate(prompts)}
            for future in as_completed(futures):
                idx, resp = future.result()
                results[idx] = resp

        return results

    # ==================== Async API ====================

    async def aio_send(self, prompt: str,
                    options: Optional[SendOptions] = None) -> ChatResponse:
        messages = self._build_messages(prompt, options)
        response = await self._async_call(messages, options)
        text = self._extract_text(response)
        chat_resp = self._build_chat_response(response, text, options)
        self._history.append({'role': 'user', 'content': prompt})
        self._history.append({'role': 'assistant', 'content': str(chat_resp)})
        self._trim_history()
        self._persist_history()
        return chat_resp

    async def aio_ask(self, prompt: str,
                   options: Optional[SendOptions] = None) -> ChatResponse:
        messages = self._build_messages(prompt, options, include_history=False)
        response = await self._async_call(messages, options)
        text = self._extract_text(response)
        return self._build_chat_response(response, text, options)

    async def aio_stream(self, prompt: str,
                      options: Optional[SendOptions] = None) -> StreamResponse:
        messages = self._build_messages(prompt, options)
        self._fire_before_hooks(messages, options)
        try:
            aiter = self._provider.aio_stream_completion(messages, self.config, options)
        except Exception as e:
            self._fire_error_hooks(e)
            raise

        async def _collect():
            async for chunk_data in aiter:
                yield chunk_data

        def _on_astream_done(full_text: str):
            self._history.append({'role': 'assistant', 'content': full_text})
            self._trim_history()
            self._persist_history()

        sr = StreamResponse(
            _SyncWrap(_collect()), model_name=self._provider.model,
            on_done=_on_astream_done,
        )
        self._history.append({'role': 'user', 'content': prompt})
        return sr

    async def aio_batch(self, prompts: List[str],
                     options: Optional[SendOptions] = None,
                     concurrency: int = 5) -> List[ChatResponse]:
        import asyncio
        sem = asyncio.Semaphore(concurrency)

        async def _ask_one(idx: int, prompt: str):
            async with sem:
                resp = await self.aio_ask(prompt, options)
                return idx, resp

        tasks = [_ask_one(i, p) for i, p in enumerate(prompts)]
        results: List[Optional[ChatResponse]] = [None] * len(prompts)
        for coro in asyncio.as_completed(tasks):
            idx, resp = await coro
            results[idx] = resp
        return results

    async def _async_call(self, messages: list,
                          options: Optional[SendOptions] = None) -> dict:
        self._fire_before_hooks(messages, options)
        try:
            tools_schema = self._tool_executor.schemas if self._tool_executor.schemas else None
            response = await self._provider.aio_chat_completion(
                messages, config=self.config, options=options, tools=tools_schema,
            )
            if tools_schema and self._tool_executor.schemas:
                max_rounds = options.max_tool_rounds if options else 10
                response, records, pending, rounds = await self._tool_executor.async_execute_loop(
                    self._provider, messages, response,
                    config=self.config, options=options, max_rounds=max_rounds,
                )
                response['_tool_calls_made'] = records
                response['_tool_calls_pending'] = pending
                response['_tool_call_rounds'] = rounds
            return response
        except Exception as e:
            self._fire_error_hooks(e)
            raise

    # ==================== Tool System ====================

    def tool(self, func: Optional[Callable] = None, *, auto_execute: bool = True):
        """Decorator: register a function as a Chat tool"""
        def decorator(f):
            schema = func_to_schema(f)
            self._tool_executor.register(f, schema, auto_execute=auto_execute)
            return f
        if func is not None:
            return decorator(func)
        return decorator

    def add_tool(self, func: Callable) -> None:
        schema = func_to_schema(func)
        self._tool_executor.register(func, schema, auto_execute=True)

    def add_tools(self, funcs: List[Callable]) -> None:
        for f in funcs:
            self.add_tool(f)

    def remove_tool(self, func_or_name: Any) -> bool:
        return self._tool_executor.unregister(func_or_name)

    def clear_tools(self) -> None:
        self._tool_executor.clear()

    @property
    def tools(self) -> List[dict]:
        return self._tool_executor.schemas

    # ==================== Conversation Management ====================

    @property
    def history(self) -> List[dict]:
        return list(self._history)

    def clear(self) -> None:
        self._history.clear()
        self._history_backend.clear()

    def clear_cache(self) -> None:
        if self._cache:
            self._cache.clear()

    def save(self, path: str) -> None:
        with open(path, 'w', encoding='utf-8') as f:
            json_mod.dump(self._history, f, ensure_ascii=False, indent=2)

    def load(self, path: str) -> None:
        with open(path, 'r', encoding='utf-8') as f:
            self._history = json_mod.load(f)

    # ==================== Middleware/Hooks ====================

    def on_before(self, func: Callable) -> Callable:
        self._hooks_before.append(func)
        return func

    def on_after(self, func: Callable) -> Callable:
        self._hooks_after.append(func)
        return func

    def on_error(self, func: Callable) -> Callable:
        self._hooks_error.append(func)
        return func

    def on_tool_call(self, func: Callable) -> Callable:
        self._hooks_tool_call.append(func)
        return func

    # ==================== Session Management ====================

    def session(self, session_id: str) -> ChatSession:
        if session_id not in self._sessions:
            self._sessions[session_id] = ChatSession(self, session_id)
        return self._sessions[session_id]

    def clone(self) -> Chat:
        new_config = copy.deepcopy(self.config)
        new_chat = Chat(new_config)
        for tool_info in self._tool_executor._tools.values():
            new_chat._tool_executor.register(
                tool_info['func'], tool_info['schema'], tool_info['auto_execute'],
            )
        return new_chat

    # ==================== Properties ====================

    @property
    def name(self) -> Optional[str]:
        return self.config.name

    @property
    def system(self) -> Optional[str]:
        return self.config.system

    @system.setter
    def system(self, value: str) -> None:
        self.config.system = value

    def append_system(self, text: str) -> None:
        if self.config.system:
            self.config.system = self.config.system + '\n' + text
        else:
            self.config.system = text

    # ==================== Helpers ====================

    @property
    def last_usage(self) -> UsageInfo:
        return self._last_usage

    def track_cost(self) -> CostTracker:
        tracker = CostTracker()
        tracker._chat = self
        self._cost_tracker = tracker
        return tracker

    def count_tokens(self, text: str) -> int:
        try:
            import tiktoken
            enc = tiktoken.encoding_for_model(self._provider.model)
            return len(enc.encode(text))
        except ImportError:
            return len(text) // 4

    def check_tokens(self, text: str, max_tokens: int) -> bool:
        return self.count_tokens(text) <= max_tokens

    # ==================== Pipeline ====================

    def __rshift__(self, other: Chat) -> Pipeline:
        return Pipeline([self, other])

    # ==================== Context Manager ====================

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self._history.clear()

    def __repr__(self):
        model = self.config.model or 'default'
        name = self.config.name or ''
        return f"Chat(model={model!r}, name={name!r})"

    # ==================== Internal Methods ====================

    def _build_messages(self, prompt: str, options: Optional[SendOptions] = None,
                        include_history: bool = True) -> list:
        messages = []

        if self.config.system:
            messages.append({'role': 'system', 'content': self.config.system})

        if include_history:
            messages.extend(self._history)

        final_prompt = prompt
        if options and (options.response_type or options.json):
            schema_hint = self._build_schema_hint(options)
            if schema_hint:
                final_prompt = f"{prompt}\n\n{schema_hint}"

        if options and (options.image or options.images):
            content_parts = [{'type': 'text', 'text': final_prompt}]
            image_urls = []
            if options.image:
                image_urls.append(options.image)
            if options.images:
                image_urls.extend(options.images)
            for url in image_urls:
                actual_url = self._resolve_image_url(url)
                content_parts.append({
                    'type': 'image_url',
                    'image_url': {'url': actual_url},
                })
            messages.append({'role': 'user', 'content': content_parts})
        else:
            messages.append({'role': 'user', 'content': final_prompt})

        return messages

    @staticmethod
    def _resolve_image_url(path_or_url: str) -> str:
        """Convert local file path to base64 data URL; URLs are returned as-is"""
        if path_or_url.startswith(('http://', 'https://', 'data:')):
            return path_or_url
        import base64
        import mimetypes
        mime, _ = mimetypes.guess_type(path_or_url)
        if not mime:
            mime = 'image/png'
        with open(path_or_url, 'rb') as f:
            data = base64.b64encode(f.read()).decode('utf-8')
        return f"data:{mime};base64,{data}"

    @staticmethod
    def _build_schema_hint(options: SendOptions) -> str:
        """Generate intuitive JSON format hint from response_type to inject into prompt"""
        if options.response_type:
            rt = options.response_type
            fields_desc = []
            example_obj = {}

            schema = None
            if hasattr(rt, 'get_json_schema'):
                schema = rt.get_json_schema()
            elif hasattr(rt, 'model_json_schema'):
                schema = rt.model_json_schema()
            elif hasattr(rt, 'schema') and callable(getattr(rt, 'schema', None)):
                schema = rt.schema()

            if schema is not None:
                props = schema.get('properties', {})
                required = schema.get('required', [])
                for fname, finfo in props.items():
                    ftype = finfo.get('type', 'string')
                    fdesc = finfo.get('description', finfo.get('title', ''))
                    req_mark = '(required)' if fname in required else '(optional)'
                    fields_desc.append(f"- {fname} ({ftype}): {fdesc} {req_mark}")
                    example_obj[fname] = _schema_type_placeholder(ftype)

            elif hasattr(rt, '__dataclass_fields__'):
                import dataclasses
                type_map = {
                    int: 'integer', float: 'number', str: 'string',
                    bool: 'boolean', list: 'array', dict: 'object',
                }
                for name, field in rt.__dataclass_fields__.items():
                    ft = field.type if isinstance(field.type, type) else str
                    ftype = type_map.get(ft, 'string')
                    is_required = (field.default is dataclasses.MISSING
                                   and field.default_factory is dataclasses.MISSING)
                    req_mark = '(required)' if is_required else '(optional)'
                    fields_desc.append(f"- {name} ({ftype}): {req_mark}")
                    example_obj[name] = _schema_type_placeholder(ftype)

            if fields_desc:
                fields_text = '\n'.join(fields_desc)
                example_text = json_mod.dumps(example_obj, ensure_ascii=False)
                return (
                    f"Please return a JSON object with the following fields:\n"
                    f"{fields_text}\n\n"
                    f"Output format example:\n{example_text}\n\n"
                    f"Note: return pure JSON only, do not wrap in markdown code blocks, do not return the JSON Schema itself."
                )

        if options.json:
            return "Please return pure JSON format (do not wrap in markdown code blocks)."
        return ""

    def _call_with_hooks(self, messages: list,
                         options: Optional[SendOptions] = None) -> dict:
        if self._cache:
            cached = self._cache.get(messages, self.config, options)
            if cached is not None:
                logger_cache.debug("Cache hit")
                return cached
            logger_cache.debug("Cache miss")

        self._fire_before_hooks(messages, options)

        try:
            if (isinstance(self.config.model, list) and len(self.config.model) > 1
                    and self.config.strategy in ('fastest', 'vote')):
                response = self._multi_model_call(messages, options)
            else:
                tools_schema = self._tool_executor.schemas if self._tool_executor.schemas else None
                response = self._do_call(messages, options, tools_schema)
        except Exception as e:
            self._fire_error_hooks(e)
            raise

        if self._cache:
            self._cache.set(messages, response, self.config, options)
            logger_cache.debug("Cache set")

        return response

    def _multi_model_call(self, messages: list,
                          options: Optional[SendOptions] = None) -> dict:
        """Multi-model strategy: fastest (race) or vote"""
        from concurrent.futures import ThreadPoolExecutor, as_completed
        models = self.config.model if isinstance(self.config.model, list) else [self.config.model]

        def _call_model(model_name: str) -> dict:
            from nb_llm.providers.registry import MODEL_REGISTRY
            entry = MODEL_REGISTRY.get(model_name.lower())
            provider_type = entry[0] if entry else 'openai_compatible'
            actual_model, base_url, api_key = resolve_model(model_name, self.config)
            if provider_type == 'anthropic':
                from nb_llm.providers.anthropic_provider import AnthropicProvider
                provider = AnthropicProvider(
                    model=actual_model, api_key=api_key,
                    timeout=self.config.timeout,
                )
            else:
                provider = OpenAICompatibleProvider(
                    model=actual_model, base_url=base_url,
                    api_key=api_key, timeout=self.config.timeout,
                )
            return provider.chat_completion(messages, config=self.config, options=options)

        if self.config.strategy == 'fastest':
            with ThreadPoolExecutor(max_workers=len(models)) as pool:
                futures = {pool.submit(_call_model, m): m for m in models}
                for future in as_completed(futures):
                    try:
                        return future.result()
                    except Exception:
                        continue
            raise ProviderError("All models failed")

        elif self.config.strategy == 'vote':
            results = []
            with ThreadPoolExecutor(max_workers=len(models)) as pool:
                futures = {pool.submit(_call_model, m): m for m in models}
                for future in as_completed(futures):
                    try:
                        results.append(future.result())
                    except Exception:
                        continue
            if not results:
                raise ProviderError("All models failed")

            texts = []
            for r in results:
                choices = r.get('choices', [{}])
                t = choices[0].get('message', {}).get('content', '') if choices else ''
                texts.append(t)

            from collections import Counter
            counts = Counter(texts)
            most_common_text = counts.most_common(1)[0][0]
            for r in results:
                choices = r.get('choices', [{}])
                t = choices[0].get('message', {}).get('content', '') if choices else ''
                if t == most_common_text:
                    return r

            return results[0]

        return self._do_call(messages, options, None)

    def _do_call(self, messages: list, options: Optional[SendOptions],
                 tools_schema: Optional[list]) -> dict:
        max_retries = self.config.retry
        last_error = None

        for attempt in range(max_retries + 1):
            try:
                response = self._provider.chat_completion(
                    messages, config=self.config, options=options, tools=tools_schema,
                )

                if tools_schema and self._tool_executor.schemas:
                    max_rounds = options.max_tool_rounds if options else 10
                    response, records, pending, rounds = self._tool_executor.execute_loop(
                        self._provider, messages, response,
                        config=self.config, options=options, max_rounds=max_rounds,
                    )
                    response['_tool_calls_made'] = records
                    response['_tool_calls_pending'] = pending
                    response['_tool_call_rounds'] = rounds

                return response

            except ProviderError as e:
                last_error = e
                if attempt < max_retries:
                    import time
                    delay = self.config.retry_delay * (2 ** attempt)
                    logger_retry.debug("Retry %d/%d failed: %s, backing off %.1fs",
                                       attempt + 1, max_retries, e, delay)
                    time.sleep(delay)
                    continue

                if self.config.fallback:
                    logger_retry.debug("Retries exhausted, triggering fallback → %s", self.config.fallback)
                    return self._call_fallback(messages, options)
                raise

        raise last_error

    def _call_fallback(self, messages: list,
                       options: Optional[SendOptions]) -> dict:
        fallback_model = self.config.fallback
        actual_model, base_url, api_key = resolve_model(fallback_model, self.config)
        fallback_provider = OpenAICompatibleProvider(
            model=actual_model, base_url=base_url, api_key=api_key,
            timeout=self.config.timeout,
        )
        return fallback_provider.chat_completion(messages, config=self.config, options=options)

    def _extract_text(self, response: dict) -> str:
        choices = response.get('choices', [{}])
        if choices:
            message = choices[0].get('message', {})
            return message.get('content', '') or ''
        return ''

    def _build_chat_response(self, response: dict, text: str,
                             options: Optional[SendOptions] = None) -> ChatResponse:
        usage = UsageInfo.from_dict(response.get('usage', {}))
        self._last_usage = usage

        if self._cost_tracker:
            self._cost_tracker._record(usage)

        choices = response.get('choices', [{}])
        first_choice = choices[0] if choices else {}

        tool_calls_made = response.pop('_tool_calls_made', [])
        tool_calls_pending = response.pop('_tool_calls_pending', [])
        tool_call_rounds = response.pop('_tool_call_rounds', [])

        resp = ChatResponse(
            text,
            id=response.get('id', ''),
            usage=usage,
            finish_reason=first_choice.get('finish_reason', 'stop'),
            tool_calls=tool_calls_pending,
            tool_calls_made=tool_calls_made,
            tool_call_rounds=tool_call_rounds,
            raw=response,
            model=response.get('model', self._provider.model),
            logprobs=first_choice.get('logprobs'),
        )

        if options and options.n > 1 and len(choices) > 1:
            resp.choices = []
            for c in choices:
                c_text = c.get('message', {}).get('content', '') or ''
                c_resp = ChatResponse(
                    c_text,
                    finish_reason=c.get('finish_reason', 'stop'),
                    logprobs=c.get('logprobs'),
                )
                resp.choices.append(c_resp)

        if options and options.response_type:
            resp.parsed = self._parse_structured(text, options.response_type, options)
        elif options and options.json:
            resp.parsed = self._parse_json(text)

        for record in tool_calls_made:
            self._fire_tool_call_hooks(record)

        self._fire_after_hooks(resp, usage)

        return resp

    @staticmethod
    def _strip_markdown_json(text: str) -> str:
        """Extract pure JSON from LLM response text: handle markdown code blocks, surrounding text, etc."""
        import re
        stripped = text.strip()

        match = re.search(r'```(?:json)?\s*\n(.*?)\n\s*```', stripped, re.DOTALL)
        if match:
            return match.group(1).strip()

        match = re.search(r'(\{[\s\S]*\})', stripped)
        if match:
            candidate = match.group(1)
            depth = 0
            end_pos = 0
            for i, ch in enumerate(candidate):
                if ch == '{':
                    depth += 1
                elif ch == '}':
                    depth -= 1
                    if depth == 0:
                        end_pos = i + 1
                        break
            if end_pos > 0:
                return candidate[:end_pos]

        match = re.search(r'(\[[\s\S]*\])', stripped)
        if match:
            return match.group(1)

        return stripped

    def _parse_structured(self, text: str, response_type: Any,
                          options: SendOptions,
                          original_prompt: Optional[str] = None) -> Any:
        max_retries = 2
        last_error = None
        clean_text = self._strip_markdown_json(text)

        for attempt in range(max_retries + 1):
            try:
                if hasattr(response_type, 'from_json'):
                    return response_type.from_json(clean_text)
                elif hasattr(response_type, 'model_validate_json'):
                    return response_type.model_validate_json(clean_text)
                elif hasattr(response_type, 'model_validate'):
                    data = json_mod.loads(clean_text)
                    return response_type.model_validate(data)
                else:
                    data = json_mod.loads(clean_text)
                    return response_type(**data)
            except (json_mod.JSONDecodeError, Exception) as e:
                last_error = e
                if attempt < max_retries:
                    retry_prompt = (
                        f"Your previous response had incorrect format, error: {e}\n"
                        f"Please strictly follow the required JSON format and return pure JSON only."
                    )
                    schema_hint = self._build_schema_hint(options)
                    if schema_hint:
                        retry_prompt += f"\n{schema_hint}"
                    try:
                        retry_resp = self._provider.chat_completion(
                            [{'role': 'user', 'content': retry_prompt}],
                            config=self.config, options=options,
                        )
                        retry_text = self._extract_text(retry_resp)
                        clean_text = self._strip_markdown_json(retry_text)
                    except Exception:
                        pass
                    continue

                if isinstance(e, json_mod.JSONDecodeError):
                    raise JsonParseError(
                        f"JSON parse failed (after {max_retries} retries)\n"
                        f"Raw response text: {text}\n"
                        f"Cleaned text: {clean_text}\n"
                        f"Parse error: {e}",
                        raw_text=text, parse_error=e,
                    )
                raise SchemaValidationError(
                    f"Structured output validation failed (after {max_retries} retries)\n"
                    f"Raw response text: {text}\n"
                    f"Cleaned text: {clean_text}\n"
                    f"Validation error: {e}",
                    raw_text=text, validation_error=e, response_type=response_type,
                )

    def _parse_json(self, text: str) -> Any:
        clean_text = self._strip_markdown_json(text)
        try:
            return json_mod.loads(clean_text)
        except json_mod.JSONDecodeError as e:
            raise JsonParseError(
                f"JSON parse failed\n"
                f"Raw response text: {text}\n"
                f"Cleaned text: {clean_text}\n"
                f"Parse error: {e}",
                raw_text=text, parse_error=e,
            )

    def _trim_history(self) -> None:
        max_turns = self.config.history_max_turns
        if max_turns and len(self._history) > max_turns * 2:
            self._history = self._history[-(max_turns * 2):]

        max_tokens = self.config.history_max_tokens
        if max_tokens:
            def _content_text(msg):
                c = msg.get('content', '')
                if isinstance(c, list):
                    return ' '.join(p.get('text', '') for p in c if isinstance(p, dict) and p.get('type') == 'text')
                return c or ''
            total = sum(self.count_tokens(_content_text(m)) for m in self._history)
            while total > max_tokens and len(self._history) >= 2:
                removed = self._history[:2]
                self._history = self._history[2:]
                total -= sum(self.count_tokens(_content_text(m)) for m in removed)

        if self.config.history_strategy == 'summary' and len(self._history) > 20:
            old_part = self._history[:-6]
            recent_part = self._history[-6:]
            old_text = '\n'.join(
                f"[{m.get('role')}] {m.get('content', '')}" for m in old_part
            )
            try:
                summary = self._provider.chat_completion(
                    [{'role': 'user',
                      'content': f'Please summarize the key points of the following conversation in 2-3 sentences:\n{old_text}'}],
                    config=self.config,
                )
                summary_text = self._extract_text(summary)
                self._history = [
                    {'role': 'system', 'content': f'[Conversation Summary] {summary_text}'},
                ] + recent_part
            except Exception:
                pass

    def _persist_history(self, session_id: str = 'default',
                         history: Optional[List[dict]] = None) -> None:
        if self.config.history_backend != 'memory':
            data = history if history is not None else self._history
            self._history_backend.save(data, session_id)

    def _fire_before_hooks(self, messages: list,
                           options: Optional[SendOptions]) -> None:
        for hook in self._hooks_before:
            hook(messages, options)

    def _fire_after_hooks(self, response: ChatResponse,
                          usage: UsageInfo) -> None:
        for hook in self._hooks_after:
            hook(response, usage)

    def _fire_error_hooks(self, error: Exception) -> None:
        for hook in self._hooks_error:
            hook(error)

    def _fire_tool_call_hooks(self, record) -> None:
        for hook in self._hooks_tool_call:
            hook(record.name, record.args)


class ChatSession:
    """Sub-session of Chat. Has independent conversation history, shares Chat config and tools."""

    def __init__(self, chat: Chat, session_id: str) -> None:
        self._chat = chat
        self.session_id = session_id
        self._history: List[dict] = chat._history_backend.load(session_id)

    def send(self, prompt: str,
             options: Optional[SendOptions] = None) -> ChatResponse:
        messages = self._build_messages(prompt, options)
        response = self._chat._call_with_hooks(messages, options)
        text = self._chat._extract_text(response)
        chat_resp = self._chat._build_chat_response(response, text, options)
        self._history.append({'role': 'user', 'content': prompt})
        self._history.append({'role': 'assistant', 'content': str(chat_resp)})
        self._chat._persist_history(self.session_id, self._history)
        return chat_resp

    def ask(self, prompt: str,
            options: Optional[SendOptions] = None) -> ChatResponse:
        messages = self._build_messages(prompt, options, include_history=False)
        response = self._chat._call_with_hooks(messages, options)
        text = self._chat._extract_text(response)
        return self._chat._build_chat_response(response, text, options)

    @property
    def history(self) -> List[dict]:
        return list(self._history)

    def clear(self) -> None:
        self._history.clear()
        self._chat._history_backend.clear(self.session_id)

    def _build_messages(self, prompt: str, options: Optional[SendOptions] = None,
                        include_history: bool = True) -> list:
        messages = []
        if self._chat.config.system:
            messages.append({'role': 'system', 'content': self._chat.config.system})
        if include_history:
            messages.extend(self._history)

        final_prompt = prompt
        if options and (options.response_type or options.json):
            schema_hint = Chat._build_schema_hint(options)
            if schema_hint:
                final_prompt = f"{prompt}\n\n{schema_hint}"

        if options and (options.image or options.images):
            content_parts = [{'type': 'text', 'text': final_prompt}]
            image_urls = []
            if options.image:
                image_urls.append(options.image)
            if options.images:
                image_urls.extend(options.images)
            for url in image_urls:
                actual_url = Chat._resolve_image_url(url)
                content_parts.append({
                    'type': 'image_url',
                    'image_url': {'url': actual_url},
                })
            messages.append({'role': 'user', 'content': content_parts})
        else:
            messages.append({'role': 'user', 'content': final_prompt})
        return messages

    def __repr__(self):
        return f"ChatSession(id={self.session_id!r})"


class Pipeline:
    """Chat >> Chat chaining pipeline"""

    def __init__(self, chats: Optional[List[Chat]] = None) -> None:
        self._chats = chats or []

    def __rshift__(self, other: Chat) -> Pipeline:
        return Pipeline(self._chats + [other])

    def run(self, prompt: str,
            options: Optional[SendOptions] = None) -> ChatResponse:
        if not self._chats:
            return ChatResponse(prompt)
        current = prompt
        last_resp = None
        for i, chat in enumerate(self._chats):
            step_name = chat.config.name or chat.config.model or f'step_{i}'
            logger_pipeline.debug("[Step %d/%d] %s input: %.100s...",
                                  i + 1, len(self._chats), step_name, str(current))
            last_resp = chat.ask(str(current), options)
            logger_pipeline.debug("[Step %d/%d] %s output: %.100s...",
                                  i + 1, len(self._chats), step_name, str(last_resp))
            current = last_resp
        return last_resp

    def __call__(self, prompt: str,
                 options: Optional[SendOptions] = None) -> ChatResponse:
        return self.run(prompt, options)

    def __repr__(self):
        names = [c.config.name or c.config.model or '?' for c in self._chats]
        return f"Pipeline({' >> '.join(names)})"


class _SyncWrap:
    """Wrap async iterator as sync iterator (for StreamResponse)"""

    def __init__(self, aiter):
        self._aiter = aiter

    def __iter__(self):
        return self

    def __next__(self):
        import asyncio
        try:
            loop = asyncio.get_event_loop()
            if loop.is_running():
                raise StopIteration
            return loop.run_until_complete(self._aiter.__anext__())
        except StopAsyncIteration:
            raise StopIteration
