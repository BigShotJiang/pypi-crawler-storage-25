"""nb_llm core data types: DataMixin, UsageInfo, ToolCallRecord and other response objects"""
from __future__ import annotations

import json
from typing import Any, List, Optional


class DataMixin:
    """
    Mixin base class for response objects.
    Supports: attribute access (IDE completion), .to_dict(), .to_json_str(), dict(obj), obj["key"]
    """

    def to_dict(self) -> dict:
        result = {}
        for k, v in self.__dict__.items():
            if k.startswith('_'):
                continue
            if isinstance(v, DataMixin):
                result[k] = v.to_dict()
            elif isinstance(v, list):
                result[k] = [
                    item.to_dict() if isinstance(item, DataMixin) else item
                    for item in v
                ]
            else:
                result[k] = v
        return result

    def to_json_str(self, indent=4, ensure_ascii=False, **kwargs) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii, **kwargs)

    def keys(self):
        return [k for k in self.__dict__ if not k.startswith('_')]

    def __iter__(self):
        return iter(self.to_dict().items())

    def __getitem__(self, key):
        return getattr(self, key)

    def __contains__(self, key):
        return hasattr(self, key)

    def __repr__(self):
        items = ', '.join(f"{k}={v!r}" for k, v in self.__dict__.items() if not k.startswith('_'))
        return f"{self.__class__.__name__}({items})"


class UsageInfo(DataMixin):
    """Token usage information"""

    def __init__(self, prompt_tokens: int = 0, completion_tokens: int = 0,
                 total_tokens: int = 0, cost: float = 0.0) -> None:
        self.prompt_tokens = prompt_tokens
        self.completion_tokens = completion_tokens
        self.total_tokens = total_tokens
        self.cost = cost

    @classmethod
    def from_dict(cls, d: Optional[dict]) -> UsageInfo:
        if not d:
            return cls()
        return cls(
            prompt_tokens=d.get('prompt_tokens', 0),
            completion_tokens=d.get('completion_tokens', 0),
            total_tokens=d.get('total_tokens', 0),
            cost=d.get('cost', 0.0),
        )


class ToolCallRecord(DataMixin):
    """Completed tool call record"""

    def __init__(self, name: str = '', args: Optional[dict] = None,
                 result: Any = None, elapsed: float = 0.0,
                 error: Optional[str] = None) -> None:
        self.name = name
        self.args = args or {}
        self.result = result
        self.elapsed = elapsed
        self.error = error


class PendingToolCall:
    """Pending tool call (used when auto_execute=False)"""

    def __init__(self, name: str, args: dict, tool_func: Any = None,
                 tool_call_id: Optional[str] = None) -> None:
        self.name = name
        self.args = args
        self._tool_func = tool_func
        self._tool_call_id = tool_call_id
        self._executed = False
        self._result = None

    def execute(self) -> Any:
        if self._executed:
            return self._result
        if self._tool_func is None:
            raise RuntimeError(f"No function registered for tool '{self.name}'")
        self._result = self._tool_func(**self.args)
        self._executed = True
        return self._result

    def reject(self) -> None:
        self._executed = True
        self._result = None

    def to_dict(self) -> dict:
        return {'name': self.name, 'args': self.args}

    def to_json_str(self, indent=4, ensure_ascii=False, **kwargs) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii, **kwargs)

    def __repr__(self):
        return f"PendingToolCall(name={self.name!r}, args={self.args!r})"


class ToolCallRound(DataMixin):
    """One round record in the tool call loop, for debugging/observing model behavior"""

    def __init__(self, round_index: int = 0,
                 model_tool_calls: Optional[List[dict]] = None,
                 tool_results: Optional[List[dict]] = None,
                 raw_response: Optional[dict] = None) -> None:
        self.round_index = round_index
        self.model_tool_calls = model_tool_calls or []
        self.tool_results = tool_results or []
        self.raw_response = raw_response or {}


class SourceInfo(DataMixin):
    """Source information retrieved by RAG"""

    def __init__(self, file: str = '', page: Optional[int] = None,
                 line: Optional[int] = None, chunk: str = '',
                 score: float = 0.0) -> None:
        self.file = file
        self.page = page
        self.line = line
        self.chunk = chunk
        self.score = score


class TeamMessage(DataMixin):
    """A single message in discussion transcript"""

    def __init__(self, agent_name: str = '', round: int = 0,
                 content: str = '') -> None:
        self.agent_name = agent_name
        self.round = round
        self.content = content


class TeamResult(DataMixin):
    """Return value of Team.discuss()"""

    def __init__(self, conclusion: str = '',
                 transcript: Optional[List[TeamMessage]] = None,
                 rounds: int = 0) -> None:
        self.conclusion = conclusion
        self.transcript = transcript or []
        self.rounds = rounds


class CostTracker(DataMixin):
    """Return value of track_cost(), Context Manager"""

    def __init__(self) -> None:
        self.total_tokens = 0
        self.prompt_tokens = 0
        self.completion_tokens = 0
        self.total_cost = 0.0
        self.call_count = 0
        self.details: List[UsageInfo] = []
        self._chat = None

    def _record(self, usage: UsageInfo) -> None:
        self.total_tokens += usage.total_tokens
        self.prompt_tokens += usage.prompt_tokens
        self.completion_tokens += usage.completion_tokens
        self.total_cost += usage.cost
        self.call_count += 1
        self.details.append(usage)

    def __enter__(self):
        return self

    def __exit__(self, *args):
        if self._chat is not None:
            self._chat._cost_tracker = None
