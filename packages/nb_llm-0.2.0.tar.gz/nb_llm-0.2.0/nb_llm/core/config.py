"""ChatConfig, SendOptions, RAGConfig dataclass definitions"""
from __future__ import annotations

from dataclasses import dataclass, field, field
from typing import List, Optional, Union


@dataclass
class ChatConfig:
    """
    The unified configuration class for Chat.
    Dataclass design: users may subclass and override; IDE completion covers all fields.
    """
    model: Union[str, List[str], None] = None
    system: Optional[str] = None
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    name: Optional[str] = None

    # Generation parameters
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stop: Optional[List[str]] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    seed: Optional[int] = None
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None

    # Fault tolerance
    retry: int = 0
    retry_delay: float = 1.0
    fallback: Optional[str] = None
    timeout: Optional[float] = None
    strategy: str = "fallback"  # "fallback" | "fastest" | "vote"

    # Conversation history management
    history_max_turns: Optional[int] = None
    history_max_tokens: Optional[int] = None
    history_strategy: str = "truncate"  # "truncate" | "summary"

    # Conversation history persistence
    history_backend: str = "memory"  # "memory" | "file" | "sqlite" | "redis"
    history_url: Optional[str] = None

    # Cache
    cache: bool = False
    cache_ttl: int = 3600

    # Observability
    trace: bool = False

    # RAG
    rag: object = None


@dataclass
class SendOptions:
    """
    Per-call options for send/ask.
    Dataclass design: after typing SendOptions(, IDE suggests all available fields.
    """
    json: bool = False
    response_type: object = None

    # Multimodal
    image: Optional[str] = None
    images: Optional[List[str]] = None

    # Parameter overrides
    temperature: Optional[float] = None
    max_tokens: Optional[int] = None
    top_p: Optional[float] = None
    stop: Optional[List[str]] = None
    frequency_penalty: Optional[float] = None
    presence_penalty: Optional[float] = None
    seed: Optional[int] = None
    logprobs: Optional[bool] = None
    top_logprobs: Optional[int] = None

    # Multi-candidate
    n: int = 1

    # Tool control
    tool_choice: str = "auto"  # "auto" | "none" | "required" | tool_name
    max_tool_rounds: int = 10

    # Tracking
    tags: Optional[List[str]] = None
    metadata: Optional[dict] = None


@dataclass
class RAGConfig:
    """
    Configuration class for RAG.
    Dataclass design: users may subclass and override; IDE completion covers all fields.

    Example::

        config = RAGConfig(
            model="deepseek",
            embedding_model="text-embedding-3-small",
            top_k=20,
        )
        rag = RAG(config)
    """
    model: str = "deepseek"
    api_key: Optional[str] = None
    base_url: Optional[str] = None
    system: Optional[str] = None  # None=default strict mode, ""=disabled

    # Embedding configuration
    embedding_model: str = "text-embedding-3-small"
    embedding_api_key: Optional[str] = None
    embedding_base_url: Optional[str] = None

    # Chunking parameters
    chunk_size: int = 500
    chunk_overlap: int = 50

    # Retrieval parameters
    top_k: int = 20

    # Embedding batch
    embedding_batch_size: int = 20
    embedding_max_token_chars: int = 0

    # Vector store
    vectorstore: str = "memory"  # "memory" | "faiss" | "chromadb"
    vectorstore_path: Optional[str] = None  # persist directory for chromadb / faiss
