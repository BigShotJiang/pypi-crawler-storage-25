"""
NbBaseModel — Pydantic v1/v2 compatible base class.

Subclass NbBaseModel instead of pydantic.BaseModel directly to use a
unified API regardless of Pydantic version differences.

Usage::

    from nb_llm import NbBaseModel
    from pydantic import Field

    class Movie(NbBaseModel):
        title: str = Field(description="movie title")
        year: int = Field(description="release year")

    movie = Movie(title="Interstellar", year=2014)
    print(movie.to_dict())          # {'title': 'Interstellar', 'year': 2014}
    print(movie.to_json_str())      # '{"title":"Interstellar","year":2014}'
    print(Movie.get_json_schema())  # JSON Schema dict
"""
from __future__ import annotations

import json as json_mod
from typing import Any, Dict, Type, TypeVar

from pydantic import BaseModel

T = TypeVar('T', bound='NbBaseModel')


class NbBaseModel(BaseModel):
    """Pydantic v1/v2 compatible base class with unified API."""

    def to_dict(self) -> Dict[str, Any]:
        """Convert to dict (compatible with v1 dict() and v2 model_dump())"""
        if hasattr(self, 'model_dump'):
            return self.model_dump()
        return self.dict()

    def to_json_str(self, **kwargs) -> str:
        """Convert to JSON string (compatible with v1 json() and v2 model_dump_json())"""
        if hasattr(self, 'model_dump_json'):
            return self.model_dump_json(**kwargs)
        return self.json(**kwargs)

    @classmethod
    def get_json_schema(cls) -> Dict[str, Any]:
        """Get JSON Schema (compatible with v1 schema() and v2 model_json_schema())"""
        if hasattr(cls, 'model_json_schema'):
            return cls.model_json_schema()
        return cls.schema()

    @classmethod
    def from_dict(cls: Type[T], data: Dict[str, Any]) -> T:
        """Construct from dict (compatible with v1 constructor and v2 model_validate())"""
        if hasattr(cls, 'model_validate'):
            return cls.model_validate(data)
        return cls(**data)

    @classmethod
    def from_json(cls: Type[T], json_str: str) -> T:
        """Construct from JSON string (compatible with v1 parse_raw() and v2 model_validate_json())"""
        if hasattr(cls, 'model_validate_json'):
            return cls.model_validate_json(json_str)
        if hasattr(cls, 'parse_raw'):
            return cls.parse_raw(json_str)
        data = json_mod.loads(json_str)
        return cls(**data)
