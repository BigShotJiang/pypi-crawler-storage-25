"""Conversation history persistence backends"""
from __future__ import annotations

import json
import os
from typing import Dict, List, Optional

from nb_llm.loggers import logger_history as logger


class HistoryBackend:
    """History backend base class"""

    def load(self, session_id: str = 'default') -> List[dict]:
        return []

    def save(self, history: List[dict], session_id: str = 'default') -> None:
        pass

    def clear(self, session_id: str = 'default') -> None:
        pass


class MemoryBackend(HistoryBackend):
    """Memory backend (default)"""

    def __init__(self) -> None:
        self._store: Dict[str, List[dict]] = {}

    def load(self, session_id: str = 'default') -> List[dict]:
        data = list(self._store.get(session_id, []))
        logger.debug("MemoryBackend.load(session=%s) → %d messages", session_id, len(data))
        return data

    def save(self, history: List[dict], session_id: str = 'default') -> None:
        self._store[session_id] = list(history)
        logger.debug("MemoryBackend.save(session=%s) ← %d messages", session_id, len(history))

    def clear(self, session_id: str = 'default') -> None:
        self._store.pop(session_id, None)
        logger.debug("MemoryBackend.clear(session=%s)", session_id)


class FileBackend(HistoryBackend):
    """File backend: one JSON file per session"""

    def __init__(self, directory: str = '.nb_llm_history') -> None:
        self.directory = directory
        os.makedirs(directory, exist_ok=True)

    def _path(self, session_id: str) -> str:
        safe_id = session_id.replace('/', '_').replace('\\', '_')
        return os.path.join(self.directory, f"{safe_id}.json")

    def load(self, session_id: str = 'default') -> List[dict]:
        path = self._path(session_id)
        if os.path.exists(path):
            with open(path, 'r', encoding='utf-8') as f:
                data = json.load(f)
            logger.debug("FileBackend.load(session=%s, path=%s) → %d messages", session_id, path, len(data))
            return data
        logger.debug("FileBackend.load(session=%s, path=%s) → file not found, returning empty", session_id, path)
        return []

    def save(self, history: List[dict], session_id: str = 'default') -> None:
        path = self._path(session_id)
        with open(path, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False, indent=2)
        logger.debug("FileBackend.save(session=%s, path=%s) ← %d messages", session_id, path, len(history))

    def clear(self, session_id: str = 'default') -> None:
        path = self._path(session_id)
        if os.path.exists(path):
            os.remove(path)
            logger.debug("FileBackend.clear(session=%s, path=%s) deleted", session_id, path)


class SqliteBackend(HistoryBackend):
    """SQLite backend"""

    def __init__(self, db_path: str = '.nb_llm_history.db') -> None:
        import sqlite3
        self.db_path = db_path
        self._conn = sqlite3.connect(db_path, check_same_thread=False)
        self._conn.execute(
            'CREATE TABLE IF NOT EXISTS history '
            '(session_id TEXT, messages TEXT, updated_at REAL)'
        )
        self._conn.commit()

    def load(self, session_id: str = 'default') -> List[dict]:
        cursor = self._conn.execute(
            'SELECT messages FROM history WHERE session_id = ?',
            (session_id,),
        )
        row = cursor.fetchone()
        if row:
            data = json.loads(row[0])
            logger.debug("SqliteBackend.load(session=%s, db=%s) → %d messages", session_id, self.db_path, len(data))
            return data
        logger.debug("SqliteBackend.load(session=%s, db=%s) → no records", session_id, self.db_path)
        return []

    def save(self, history: List[dict], session_id: str = 'default') -> None:
        import time
        messages_json = json.dumps(history, ensure_ascii=False)
        cursor = self._conn.execute(
            'SELECT 1 FROM history WHERE session_id = ?',
            (session_id,),
        )
        if cursor.fetchone():
            self._conn.execute(
                'UPDATE history SET messages = ?, updated_at = ? WHERE session_id = ?',
                (messages_json, time.time(), session_id),
            )
        else:
            self._conn.execute(
                'INSERT INTO history (session_id, messages, updated_at) VALUES (?, ?, ?)',
                (session_id, messages_json, time.time()),
            )
        self._conn.commit()
        logger.debug("SqliteBackend.save(session=%s, db=%s) ← %d messages", session_id, self.db_path, len(history))

    def clear(self, session_id: str = 'default') -> None:
        self._conn.execute('DELETE FROM history WHERE session_id = ?', (session_id,))
        self._conn.commit()
        logger.debug("SqliteBackend.clear(session=%s, db=%s)", session_id, self.db_path)

    def close(self) -> None:
        self._conn.close()


class RedisBackend(HistoryBackend):
    """Redis backend (requires pip install redis)"""

    def __init__(self, url: str = 'redis://localhost:6379/0',
                 prefix: str = 'nb_llm:history:') -> None:
        self._url = url
        self._prefix = prefix
        self._client = None

    def _get_client(self):
        if self._client is None:
            try:
                import redis
            except ImportError:
                raise ImportError(
                    "Redis backend requires redis package: pip install redis"
                )
            self._client = redis.from_url(self._url, decode_responses=True)
        return self._client

    def _key(self, session_id: str) -> str:
        return f"{self._prefix}{session_id}"

    def load(self, session_id: str = 'default') -> List[dict]:
        client = self._get_client()
        data = client.get(self._key(session_id))
        if data:
            return json.loads(data)
        return []

    def save(self, history: List[dict], session_id: str = 'default') -> None:
        client = self._get_client()
        client.set(
            self._key(session_id),
            json.dumps(history, ensure_ascii=False),
        )

    def clear(self, session_id: str = 'default') -> None:
        client = self._get_client()
        client.delete(self._key(session_id))


def create_backend(backend_type: str = 'memory',
                   url: Optional[str] = None) -> HistoryBackend:
    """Factory function: create backend by type"""
    if backend_type == 'memory':
        return MemoryBackend()
    elif backend_type == 'file':
        return FileBackend(url or '.nb_llm_history')
    elif backend_type == 'sqlite':
        return SqliteBackend(url or '.nb_llm_history.db')
    elif backend_type == 'redis':
        return RedisBackend(url or 'redis://localhost:6379/0')
    else:
        return MemoryBackend()
