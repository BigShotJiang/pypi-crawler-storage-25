"""ChatResponse and StreamResponse definitions"""
from __future__ import annotations

import json
from typing import Any, List, Optional, Iterator

from nb_llm.core.data_types import (
    UsageInfo, ToolCallRecord, PendingToolCall, SourceInfo, ToolCallRound,
)


class ChatResponse(str):
    """
    LLM response. Inherits str; can be used as a string in most cases.
    When needed, access full metadata via attributes with IDE completion.
    """

    id: str
    usage: UsageInfo
    finish_reason: str
    tool_calls: List[PendingToolCall]
    tool_calls_made: List[ToolCallRecord]
    tool_call_rounds: List[ToolCallRound]
    sources: List[SourceInfo]
    parsed: Any
    choices: Optional[List[ChatResponse]]
    logprobs: Any
    raw: dict
    model: str

    def __new__(cls, text: str = '', **kwargs) -> ChatResponse:
        instance = super().__new__(cls, text)
        instance.id = kwargs.get('id', '')
        instance.usage = kwargs.get('usage', UsageInfo())
        instance.finish_reason = kwargs.get('finish_reason', 'stop')
        instance.tool_calls = kwargs.get('tool_calls', [])
        instance.tool_calls_made = kwargs.get('tool_calls_made', [])
        instance.tool_call_rounds = kwargs.get('tool_call_rounds', [])
        instance.sources = kwargs.get('sources', [])
        instance.parsed = kwargs.get('parsed', None)
        instance.choices = kwargs.get('choices', None)
        instance.logprobs = kwargs.get('logprobs', None)
        instance.raw = kwargs.get('raw', {})
        instance.model = kwargs.get('model', '')
        return instance

    @property
    def text(self) -> str:
        """Get text content (equivalent to str(self), but more explicit)"""
        return str(self)

    def to_dict(self) -> dict:
        d = {
            'id': self.id,
            'text': self.text,
            'usage': self.usage.to_dict() if self.usage else {},
            'finish_reason': self.finish_reason,
            'tool_calls': [tc.to_dict() for tc in (self.tool_calls or [])],
            'tool_calls_made': [tc.to_dict() for tc in (self.tool_calls_made or [])],
            'sources': [s.to_dict() for s in (self.sources or [])],
            'model': self.model,
        }
        if self.parsed is not None:
            if hasattr(self.parsed, 'model_dump'):
                d['parsed'] = self.parsed.model_dump()
            elif hasattr(self.parsed, 'to_dict'):
                d['parsed'] = self.parsed.to_dict()
            else:
                d['parsed'] = self.parsed
        if self.choices is not None:
            d['choices'] = [c.to_dict() for c in self.choices]
        if self.logprobs is not None:
            d['logprobs'] = self.logprobs
        return d

    def to_json_str(self, indent=4, ensure_ascii=False, **kwargs) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii, **kwargs)

    @classmethod
    def _from_api_response(cls, raw_response: dict,
                            model_name: str = '') -> ChatResponse:
        """Build ChatResponse from raw API response"""
        choices = raw_response.get('choices', [{}])
        first_choice = choices[0] if choices else {}
        message = first_choice.get('message', {})
        text = message.get('content', '') or ''

        usage_data = raw_response.get('usage', {})
        usage = UsageInfo.from_dict(usage_data)

        resp = cls(
            text,
            id=raw_response.get('id', ''),
            usage=usage,
            finish_reason=first_choice.get('finish_reason', 'stop'),
            raw=raw_response,
            model=raw_response.get('model', model_name),
            logprobs=first_choice.get('logprobs'),
        )
        return resp


class StreamResponse:
    """
    Return value of stream(). Iterable; metadata is available after iteration completes.
    """

    def __init__(self, stream_iter: Iterator, model_name: str = '',
                 on_done: Any = None) -> None:
        self._stream_iter = stream_iter
        self._model_name = model_name
        self._chunks: List[str] = []
        self._done = False
        self._on_done = on_done
        self.usage: UsageInfo = UsageInfo()
        self.finish_reason: str = 'stop'
        self.text: str = ''
        self.tool_calls_made: List[ToolCallRecord] = []

    def __iter__(self):
        return self

    def __next__(self) -> str:
        try:
            chunk_data = next(self._stream_iter)
            if isinstance(chunk_data, dict):
                choices = chunk_data.get('choices', [{}])
                delta = choices[0].get('delta', {}) if choices else {}
                text = delta.get('content', '') or ''
                finish = choices[0].get('finish_reason') if choices else None
                if finish:
                    self.finish_reason = finish
                usage_data = chunk_data.get('usage')
                if usage_data:
                    self.usage = UsageInfo.from_dict(usage_data)
            else:
                text = str(chunk_data)

            self._chunks.append(text)
            return text
        except StopIteration:
            self._done = True
            self.text = ''.join(self._chunks)
            if self._on_done:
                self._on_done(self.text)
            raise

    def to_dict(self) -> dict:
        return {
            'text': self.text,
            'usage': self.usage.to_dict(),
            'finish_reason': self.finish_reason,
            'tool_calls_made': [tc.to_dict() for tc in self.tool_calls_made],
        }

    def to_json_str(self, indent=4, ensure_ascii=False, **kwargs) -> str:
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii, **kwargs)
