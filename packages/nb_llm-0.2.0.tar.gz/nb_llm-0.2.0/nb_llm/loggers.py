"""
nb_llm logging — central definition of all loggers

Usage:
    import logging
    logging.basicConfig(level=logging.WARNING, format='[%(name)s] %(message)s')

    # Enable a specific logger as needed
    logging.getLogger('nb_llm.request').setLevel(logging.DEBUG)
    logging.getLogger('nb_llm.response').setLevel(logging.DEBUG)

    # Or enable all nb_llm logging at once
    logging.getLogger('nb_llm').setLevel(logging.DEBUG)
"""
import logging

logger_request = logging.getLogger('nb_llm.request')
"""Full request body sent to LLM each time (messages + tools + parameters)"""

logger_response = logging.getLogger('nb_llm.response')
"""Full raw JSON response from LLM each time"""

logger_tools = logging.getLogger('nb_llm.tools')
"""Tool call loop: which tools the model requested, tool returns, number of rounds"""

logger_history = logging.getLogger('nb_llm.history')
"""History backend: save / load / clear operations"""

logger_cache = logging.getLogger('nb_llm.cache')
"""Response cache: hit / miss / set"""

logger_retry = logging.getLogger('nb_llm.retry')
"""Retry and fallback: retry count, backoff duration, fallback triggered"""

logger_router = logging.getLogger('nb_llm.router')
"""Intelligent routing: classification prompt, model-returned category, final expert route"""

logger_team = logging.getLogger('nb_llm.team')
"""Multi-agent collaboration: discussion content per round, agent messages, final summary"""

logger_pipeline = logging.getLogger('nb_llm.pipeline')
"""Pipeline execution: input/output of each step"""

logger_rag = logging.getLogger('nb_llm.rag')
"""RAG retrieval: query vector, retrieved top-K documents, similarity scores"""

logger_embedding = logging.getLogger('nb_llm.embedding')
"""Embedding vectorization: number of texts requested, model, returned vector dimensions"""
