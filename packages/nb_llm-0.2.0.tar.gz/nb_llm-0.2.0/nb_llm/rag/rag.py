"""RAG class: Retrieval-Augmented Generation"""
from __future__ import annotations

import os
from typing import TYPE_CHECKING, List, Optional

from nb_llm.core.config import ChatConfig, RAGConfig, SendOptions
from nb_llm.core.data_types import SourceInfo
from nb_llm.embedding.embedding import Embedding
from nb_llm.loggers import logger_rag as logger
from nb_llm.rag.loaders import get_loader, walk_files
from nb_llm.rag.splitter import SmartSplitter
from nb_llm.rag.vectorstore import MemoryVectorStore, create_vectorstore

if TYPE_CHECKING:
    from nb_llm.core.response import ChatResponse


class RAG:
    """RAG (Retrieval-Augmented Generation) all-in-one wrapper.
    Build a knowledge base in one line, auto-retrieve + inject context.

    Usage::

        rag = RAG(RAGConfig(model="deepseek", embedding_model="bce-embedding"))
        rag.add_text("knowledge content...")
        answer = rag.chat("question")
    """

    DEFAULT_SYSTEM = (
        'You are a knowledge base assistant. Answer user questions based on the reference materials provided below.\n'
        'Combine and summarize information from multiple references when relevant.\n'
        'If the references truly contain no related information at all, say so. Otherwise, try your best to answer.'
    )

    def __init__(
        self,
        config: Optional[RAGConfig] = None,
        sources: Optional[List[str]] = None,
    ) -> None:
        from nb_llm.core.chat import Chat

        if config is None:
            config = RAGConfig()
        self.config = config

        rag_system = config.system if config.system is not None else self.DEFAULT_SYSTEM
        self._chat = Chat(ChatConfig(
            model=config.model, api_key=config.api_key, base_url=config.base_url,
            system=rag_system,
        ))
        self.embedding = Embedding(
            model=config.embedding_model,
            api_key=config.embedding_api_key or config.api_key,
            base_url=config.embedding_base_url or config.base_url,
            max_token_chars=config.embedding_max_token_chars,
        )
        self.vectorstore = create_vectorstore(config.vectorstore, config.vectorstore_path)
        self.splitter = SmartSplitter(config.chunk_size, config.chunk_overlap)
        self.top_k = config.top_k
        self._file_map: dict = {}

        if sources:
            self._load_sources(sources)

    def _load_sources(self, sources: List[str]) -> None:
        for source in sources:
            if os.path.isdir(source):
                for file_path in walk_files(source):
                    self._load_file(file_path)
            elif os.path.isfile(source):
                self._load_file(source)

    def _load_file(self, path: str) -> None:
        loader = get_loader(path)
        text = loader.load(path)
        chunks = self.splitter.split(text)
        if not chunks:
            return

        logger.debug("Loading file: %s → %d chunks", path, len(chunks))
        vectors = self.embedding.embed(chunks, batch_size=self.config.embedding_batch_size)
        if isinstance(vectors[0], float):
            vectors = [vectors]

        if len(vectors) != len(chunks):
            raise ValueError(
                f"Embedding count mismatch for {path}: "
                f"{len(chunks)} chunks but got {len(vectors)} vectors"
            )

        start_idx = len(self.vectorstore)
        metadata = [{'file': path, 'chunk_index': start_idx + i} for i in range(len(chunks))]
        self.vectorstore.add(chunks, vectors, metadata)

    def retrieve(self, query: str,
                 top_k: Optional[int] = None) -> List[SourceInfo]:
        k = top_k or self.top_k
        logger.debug("Retrieving query: %.100s..., top_k=%d", query, k)
        query_vec = self.embedding.embed(query)
        results = self.vectorstore.search(query_vec, k)

        sources = []
        for chunk_text, score, meta in results:
            sources.append(SourceInfo(
                file=meta.get('file', ''),
                chunk=chunk_text,
                score=score,
            ))
        if sources:
            lines = [f"Retrieved {len(sources)} results:"]
            for i, src in enumerate(sources):
                preview = src.chunk[:100].replace('\n', ' ')
                lines.append(f"  [{i+1}] (similarity {src.score:.4f}) {preview}...")
            logger.debug("\n".join(lines))
        else:
            logger.debug("Retrieved 0 results")
        return sources

    def chat(self, prompt: str,
             options: Optional[SendOptions] = None) -> ChatResponse:
        sources = self.retrieve(prompt)
        context_parts = []
        for i, src in enumerate(sources):
            context_parts.append(f"[{i+1}] {src.chunk}")
        context = '\n\n'.join(context_parts)

        augmented_prompt = f"Reference materials:\n{context}\n\nUser question: {prompt}"
        logger.debug("Augmented prompt:\n%s", augmented_prompt)
        resp = self._chat.ask(augmented_prompt, options)
        resp.sources = sources
        return resp

    def add(self, source: str) -> None:
        if os.path.isfile(source):
            self._load_file(source)
        elif os.path.isdir(source):
            self._load_sources([source])

    def add_text(self, text: str) -> None:
        chunks = self.splitter.split(text)
        if not chunks:
            return
        vectors = self.embedding.embed(chunks, batch_size=self.config.embedding_batch_size)
        if isinstance(vectors[0], float):
            vectors = [vectors]
        if len(vectors) != len(chunks):
            raise ValueError(
                f"Embedding count mismatch: {len(chunks)} chunks but got {len(vectors)} vectors"
            )
        self.vectorstore.add(chunks, vectors)

    def __repr__(self):
        return f"RAG(docs={len(self.vectorstore)}, top_k={self.top_k})"
