"""Vector stores"""
from __future__ import annotations

import math
from typing import List, Optional, Tuple, Union


class MemoryVectorStore:
    """Pure Python in-memory vector store (zero dependencies, suitable for prototyping)"""

    def __init__(self) -> None:
        self._chunks: List[str] = []
        self._vectors: List[List[float]] = []
        self._metadata: List[dict] = []

    def add(self, chunks: List[str], vectors: List[List[float]],
            metadata: Optional[List[dict]] = None) -> None:
        self._chunks.extend(chunks)
        self._vectors.extend(vectors)
        if metadata:
            self._metadata.extend(metadata)
        else:
            self._metadata.extend([{}] * len(chunks))

    def search(self, query_vector: List[float],
               top_k: int = 5) -> List[Tuple[str, float, dict]]:
        if not self._vectors:
            return []

        scores = []
        for i, vec in enumerate(self._vectors):
            score = _cosine_similarity(query_vector, vec)
            scores.append((i, score))

        scores.sort(key=lambda x: x[1], reverse=True)
        results = []
        for idx, score in scores[:top_k]:
            results.append((self._chunks[idx], score, self._metadata[idx]))
        return results

    def clear(self) -> None:
        self._chunks.clear()
        self._vectors.clear()
        self._metadata.clear()

    def __len__(self) -> int:
        return len(self._chunks)


class FaissVectorStore:
    """High-performance vector store based on FAISS (Meta).
    Uses L2 normalization + Inner Product for cosine similarity search.
    Requires: pip install faiss-cpu
    """

    def __init__(self) -> None:
        try:
            import faiss as _faiss
            import numpy as _np
        except ImportError:
            raise ImportError("FaissVectorStore requires: pip install faiss-cpu")
        self._faiss = _faiss
        self._np = _np
        self._index = None
        self._dim = 0
        self._chunks: List[str] = []
        self._metadata: List[dict] = []

    def add(self, chunks: List[str], vectors: List[List[float]],
            metadata: Optional[List[dict]] = None) -> None:
        np = self._np
        arr = np.array(vectors, dtype=np.float32)
        self._faiss.normalize_L2(arr)

        if self._index is None:
            self._dim = arr.shape[1]
            self._index = self._faiss.IndexFlatIP(self._dim)
        self._index.add(arr)

        self._chunks.extend(chunks)
        if metadata:
            self._metadata.extend(metadata)
        else:
            self._metadata.extend([{}] * len(chunks))

    def search(self, query_vector: List[float],
               top_k: int = 5) -> List[Tuple[str, float, dict]]:
        if self._index is None or self._index.ntotal == 0:
            return []

        np = self._np
        query = np.array([query_vector], dtype=np.float32)
        self._faiss.normalize_L2(query)

        k = min(top_k, self._index.ntotal)
        scores, indices = self._index.search(query, k)

        results = []
        for score, idx in zip(scores[0], indices[0]):
            if idx < 0:
                continue
            results.append((self._chunks[idx], float(score), self._metadata[idx]))
        return results

    def clear(self) -> None:
        self._index = None
        self._chunks.clear()
        self._metadata.clear()

    def __len__(self) -> int:
        return len(self._chunks)


class ChromaVectorStore:
    """Vector store based on ChromaDB, supports in-memory and persistent modes.
    Requires: pip install chromadb
    """

    def __init__(self, persist_directory: Optional[str] = None) -> None:
        try:
            import chromadb as _chromadb
        except ImportError:
            raise ImportError("ChromaVectorStore requires: pip install chromadb")
        self._chromadb = _chromadb

        if persist_directory:
            self._client = _chromadb.PersistentClient(path=persist_directory)
        else:
            self._client = _chromadb.EphemeralClient()

        self._collection = self._client.get_or_create_collection(
            name="nb_llm_rag",
            metadata={"hnsw:space": "cosine"},
        )
        self._id_counter = self._collection.count()

    _MAX_BATCH = 5000

    def add(self, chunks: List[str], vectors: List[List[float]],
            metadata: Optional[List[dict]] = None) -> None:
        ids = [f"doc_{self._id_counter + i}" for i in range(len(chunks))]
        metas = metadata if metadata else [{}] * len(chunks)
        safe_metas = []
        for m in metas:
            safe = {}
            for k, v in m.items():
                if isinstance(v, (str, int, float, bool)):
                    safe[k] = v
            safe_metas.append(safe if safe else {"_placeholder": ""})

        total = len(chunks)
        for start in range(0, total, self._MAX_BATCH):
            end = min(start + self._MAX_BATCH, total)
            self._collection.add(
                ids=ids[start:end],
                embeddings=vectors[start:end],
                documents=chunks[start:end],
                metadatas=safe_metas[start:end],
            )
        self._id_counter += total

    def search(self, query_vector: List[float],
               top_k: int = 5) -> List[Tuple[str, float, dict]]:
        if self._collection.count() == 0:
            return []

        k = min(top_k, self._collection.count())
        result = self._collection.query(
            query_embeddings=[query_vector],
            n_results=k,
        )

        results = []
        docs = result.get('documents', [[]])[0]
        distances = result.get('distances', [[]])[0]
        metadatas = result.get('metadatas', [[]])[0]

        for doc, dist, meta in zip(docs, distances, metadatas):
            score = 1.0 - dist
            results.append((doc, score, meta or {}))
        return results

    def clear(self) -> None:
        self._client.delete_collection("nb_llm_rag")
        self._collection = self._client.get_or_create_collection(
            name="nb_llm_rag",
            metadata={"hnsw:space": "cosine"},
        )
        self._id_counter = 0

    def __len__(self) -> int:
        return self._collection.count()


def _cosine_similarity(a: List[float], b: List[float]) -> float:
    if len(a) != len(b):
        return 0.0
    dot = sum(x * y for x, y in zip(a, b))
    norm_a = math.sqrt(sum(x * x for x in a))
    norm_b = math.sqrt(sum(x * x for x in b))
    if norm_a == 0 or norm_b == 0:
        return 0.0
    return dot / (norm_a * norm_b)


def create_vectorstore(
    store_type: str = "memory",
    persist_directory: Optional[str] = None,
) -> Union[MemoryVectorStore, FaissVectorStore, ChromaVectorStore]:
    if store_type == "faiss":
        return FaissVectorStore()
    if store_type == "chromadb":
        return ChromaVectorStore(persist_directory=persist_directory)
    return MemoryVectorStore()
