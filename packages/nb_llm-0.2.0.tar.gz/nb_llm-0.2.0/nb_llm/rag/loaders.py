"""Document loaders: load text by file type"""
from __future__ import annotations

import csv
import json
import os
from typing import List, Optional


class TextLoader:
    @staticmethod
    def load(path: str, encoding: str = 'utf-8') -> str:
        with open(path, 'r', encoding=encoding, errors='ignore') as f:
            return f.read()


class MarkdownLoader(TextLoader):
    pass


class CSVLoader:
    @staticmethod
    def load(path: str, encoding: str = 'utf-8') -> str:
        with open(path, 'r', encoding=encoding, errors='ignore') as f:
            reader = csv.reader(f)
            rows = [', '.join(row) for row in reader]
            return '\n'.join(rows)


class JSONLoader:
    @staticmethod
    def load(path: str, encoding: str = 'utf-8') -> str:
        with open(path, 'r', encoding=encoding, errors='ignore') as f:
            data = json.load(f)
            return json.dumps(data, ensure_ascii=False, indent=2)


class PDFLoader:
    @staticmethod
    def load(path: str, encoding: Optional[str] = None) -> str:
        try:
            import fitz  # pymupdf
        except ImportError:
            raise ImportError("Loading PDF requires pymupdf: pip install pymupdf")
        doc = fitz.open(path)
        text_parts = []
        for page in doc:
            text_parts.append(page.get_text())
        doc.close()
        return '\n'.join(text_parts)


class DocxLoader:
    @staticmethod
    def load(path: str, encoding: Optional[str] = None) -> str:
        try:
            import docx
        except ImportError:
            raise ImportError("Loading docx requires python-docx: pip install python-docx")
        doc = docx.Document(path)
        return '\n'.join([p.text for p in doc.paragraphs])


class HTMLLoader:
    @staticmethod
    def load(path: str, encoding: str = 'utf-8') -> str:
        try:
            from bs4 import BeautifulSoup
        except ImportError:
            raise ImportError("Loading HTML requires beautifulsoup4: pip install beautifulsoup4")
        with open(path, 'r', encoding=encoding, errors='ignore') as f:
            soup = BeautifulSoup(f.read(), 'html.parser')
            return soup.get_text(separator='\n', strip=True)


_LOADER_MAP = {
    '.txt': TextLoader,
    '.md': MarkdownLoader,
    '.csv': CSVLoader,
    '.json': JSONLoader,
    '.jsonl': JSONLoader,
    '.pdf': PDFLoader,
    '.docx': DocxLoader,
    '.html': HTMLLoader,
    '.htm': HTMLLoader,
    '.py': TextLoader,
    '.js': TextLoader,
    '.ts': TextLoader,
    '.java': TextLoader,
    '.go': TextLoader,
    '.rs': TextLoader,
    '.c': TextLoader,
    '.cpp': TextLoader,
    '.h': TextLoader,
    '.yaml': TextLoader,
    '.yml': TextLoader,
    '.toml': TextLoader,
    '.ini': TextLoader,
    '.cfg': TextLoader,
    '.xml': TextLoader,
    '.sql': TextLoader,
    '.sh': TextLoader,
    '.bat': TextLoader,
    '.log': TextLoader,
    '.rst': TextLoader,
}


def get_loader(path: str):
    ext = os.path.splitext(path)[1].lower()
    loader_cls = _LOADER_MAP.get(ext, TextLoader)
    return loader_cls()


def walk_files(directory: str) -> List[str]:
    files = []
    for root, dirs, filenames in os.walk(directory):
        for fname in filenames:
            ext = os.path.splitext(fname)[1].lower()
            if ext in _LOADER_MAP:
                files.append(os.path.join(root, fname))
    return sorted(files)
