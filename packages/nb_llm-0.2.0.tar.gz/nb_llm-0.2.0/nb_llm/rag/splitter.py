"""Text splitter"""
from __future__ import annotations

from typing import List


class SmartSplitter:
    """Split by paragraphs first, maintaining semantic integrity"""

    def __init__(self, chunk_size: int = 500, chunk_overlap: int = 50) -> None:
        self.chunk_size = chunk_size
        self.chunk_overlap = chunk_overlap

    def split(self, text: str) -> List[str]:
        if not text:
            return []

        paragraphs = text.split('\n\n')
        chunks = []
        current_chunk = ''

        for para in paragraphs:
            para = para.strip()
            if not para:
                continue

            if len(current_chunk) + len(para) + 2 <= self.chunk_size:
                current_chunk = (current_chunk + '\n\n' + para).strip()
            else:
                if current_chunk:
                    chunks.append(current_chunk)
                if len(para) <= self.chunk_size:
                    current_chunk = para
                else:
                    sub_chunks = self._split_long_text(para)
                    chunks.extend(sub_chunks[:-1])
                    current_chunk = sub_chunks[-1] if sub_chunks else ''

        if current_chunk:
            chunks.append(current_chunk)

        if self.chunk_overlap > 0 and len(chunks) > 1:
            chunks = self._add_overlap(chunks)

        return chunks

    def _split_long_text(self, text: str) -> List[str]:
        """Split extra-long text (by sentence boundaries)"""
        sentences = []
        for sep in ['。', '！', '？', '. ', '! ', '? ', '\n']:
            if sep in text:
                parts = text.split(sep)
                sentences = [p.strip() + (sep if sep.strip() else '') for p in parts if p.strip()]
                break
        if not sentences:
            sentences = [text[i:i+self.chunk_size] for i in range(0, len(text), self.chunk_size)]

        chunks = []
        current = ''
        for sent in sentences:
            if len(current) + len(sent) <= self.chunk_size:
                current += sent
            else:
                if current:
                    chunks.append(current.strip())
                current = sent
        if current:
            chunks.append(current.strip())
        return chunks

    def _add_overlap(self, chunks: List[str]) -> List[str]:
        result = [chunks[0]]
        for i in range(1, len(chunks)):
            prev_tail = chunks[i-1][-self.chunk_overlap:]
            result.append(prev_tail + chunks[i])
        return result
