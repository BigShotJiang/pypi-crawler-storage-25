

import os


from dotenv import load_dotenv 


load_dotenv('/my_dotenv.env')



import nb_log

nb_log.get_logger('nb_llm')


# ------------------- siliconflow -------------------
# BASE_URL = "https://api.siliconflow.cn/v1"
# API_KEY = os.getenv('SILICONFLOW_API_KEY')
# MODEL_EMBEDDING = "netease-youdao/bce-embedding-base_v1"
MODEL_EMBEDDING = "BAAI/bge-m3"
MODEL_EMBEDDING = 'BAAI/bge-reranker-v2-m3'

# MODEL = "THUDM/GLM-4-9B-0414"
# MOMEL  = 'Qwen/Qwen3-8B'
# MODEL = 'Qwen/Qwen3.5-4B' # very slow
# MODEL = 'deepseek-ai/DeepSeek-R1-0528-Qwen3-8B'
# MODEL = 'deepseek-ai/DeepSeek-R1-Distill-Qwen-7B' 
# MODEL = 'tencent/Hunyuan-MT-7B' # fast
# MODEL = 'THUDM/GLM-Z1-9B-0414' 
# MODEL ='THUDM/GLM-4-9B-0414' # fast




# ------------------------- openrouter -------------------------

BASE_URL = 'https://openrouter.ai/api/v1'

API_KEY = os.getenv('OPENROUTER_API_KEY')

MODEL_EMBEDDING = 'nvidia/llama-nemotron-embed-vl-1b-v2'

MODEL = 'google/gemma-4-31b-it:free'
# MODEL = 'google/gemma-4-26b-a4b-it:free'
# MODEL = 'openrouter/elephant-alpha'
# MODEL = 'nvidia/nemotron-3-super-120b-a12b:free'
# MODEL = 'z-ai/glm-4.5-air:free'
# MODEL ='minimax/minimax-m2.5:free'
# MODEL = 'qwen/qwen3-coder:free'
# MODEL = 'qwen/qwen3-next-80b-a3b-instruct:free'
