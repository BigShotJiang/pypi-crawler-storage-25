"""Auto-title the first exchange of a thread (Haiku one-shot)."""
from __future__ import annotations

from meeting_helper.chat import store as chat_store


_DEFAULT_TITLES = {"New conversation", ""}


async def _haiku_one_shot(prompt: str) -> str:
    from meeting_helper.config import get_config
    from anthropic import AsyncAnthropic
    cfg = get_config()
    if not cfg.anthropic_api_key:
        return ""
    client = AsyncAnthropic(api_key=cfg.anthropic_api_key)
    msg = await client.messages.create(
        model="claude-haiku-4-5-20251001",
        max_tokens=40,
        messages=[{"role": "user", "content": prompt}],
    )
    return "".join(b.text for b in msg.content if b.type == "text").strip()


async def maybe_generate_title(thread_id: str) -> None:
    """If the thread is still on its default title and has at least one
    user+assistant exchange, replace the title with a Haiku summary.
    No-op otherwise so calls are idempotent."""
    th = chat_store.read_thread(thread_id)
    if th.title not in _DEFAULT_TITLES:
        return
    has_user = any(t.role == "user" for t in th.turns)
    has_assistant = any(t.role == "assistant" and t.text for t in th.turns)
    if not (has_user and has_assistant):
        return
    prompt = (
        "Summarise this exchange in <=8 words for a chat title. No punctuation, no quotes.\n\n"
        + "\n".join(
            f"{t.role.upper()}: {t.text}" for t in th.turns
            if t.role in ("user", "assistant") and t.text
        )
    )
    title = await _haiku_one_shot(prompt)
    if title:
        chat_store.rename_thread(thread_id, title[:60])
