"""Chat agent tool registry.

A tool has:
  - name (dotted; e.g. "tickets.search")
  - description (short; surfaced in tool-use schemas)
  - input_schema (dict mapping arg name -> JSON-schema-style type string)
  - run(args, ctx) -> dict  (must return {status: ok|error|rate_limited|not_configured|cancelled, ...})
  - is_mutation (bool; gates execution behind user confirmation)
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Any, Awaitable, Callable

ToolFn = Callable[[dict[str, Any], dict[str, Any]], Awaitable[dict[str, Any]]]


@dataclass
class Tool:
    name: str
    description: str
    input_schema: dict[str, Any]
    run: ToolFn
    is_mutation: bool = False


class Registry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(self, tool: Tool) -> None:
        self._tools[tool.name] = tool

    def tools(self) -> list[Tool]:
        return list(self._tools.values())

    def get(self, name: str) -> Tool:
        return self._tools[name]

    async def call(self, name: str, args: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
        if name not in self._tools:
            return {"status": "error", "error": f"unknown tool: {name}"}
        try:
            return await self._tools[name].run(args, ctx)
        except Exception as exc:
            return {"status": "error", "error": str(exc)}
