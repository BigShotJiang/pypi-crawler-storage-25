"""Dynamic local-todo MCP passthrough.

The hand-wrapped ``tickets.*`` tools cover the common read/write paths
with friendly descriptions and result-shape normalization. Everything
else (sprint admin, doc CRUD, board admin, custom fields, members…) is
exposed via this passthrough so the agent can reach the full MCP surface
without us hand-wrapping each tool.

At registry-build time:

1. Pull every tool definition from the connected MCP via ``list_tools()``.
2. Skip the ones we already hand-wrap (avoids duplicate, confusable tools).
3. For each remaining tool, build a chat :class:`~meeting_helper.chat.registry.Tool`
   that:
     - is named ``mcp.<original_name>``
     - passes the MCP's JSON Schema through verbatim (Anthropic + Gemini
       accept proper JSON Schema, and our provider adapters detect that
       shape and skip the compact-schema translation)
     - is flagged ``is_mutation=True`` when the name starts with a write
       prefix (create_/update_/delete_/add_/move_/start_/close_/remove_/
       revoke_/reorder_/rename_/replace_/favorite_), so the existing
       approval gate engages.

If the MCP is unreachable or empty, this builder returns an empty list —
the daemon stays usable, just without the extra tools.
"""
from __future__ import annotations

import logging
from typing import Any

from meeting_helper.chat.registry import Tool

logger = logging.getLogger(__name__)

# MCP tool names already exposed via dedicated ``tickets.*`` wrappers.
# These get richer descriptions + post-processing, so we don't surface a
# duplicate ``mcp.<name>`` for them — that would confuse the agent.
_HAND_WRAPPED: frozenset[str] = frozenset({
    "add_comment",
    "create_task",
    "get_doc",
    "get_task",
    "list_boards",
    "list_sprints",
    "list_subtasks",
    "list_task_doc_links",
    "move_task_to_sprint",
    "search_docs",
    "search_tasks",
    "task_activity",
    "update_task",
})

# Heuristic: any tool starting with one of these prefixes mutates state.
# The chat agent loop will route them through the user-approval gate.
_MUTATION_PREFIXES: tuple[str, ...] = (
    "add_",
    "close_",
    "create_",
    "delete_",
    "favorite_",
    "move_",
    "remove_",
    "rename_",
    "reorder_",
    "replace_",
    "revoke_",
    "start_",
    "update_",
)


def _is_mutation(name: str) -> bool:
    return name.startswith(_MUTATION_PREFIXES)


async def build_mcp_passthrough_tools(mcp: Any) -> list[Tool]:
    """Build chat tools for every uncovered MCP tool the server exposes.

    `mcp` is a :class:`~meeting_helper.local_todo.LocalTodoClient`. If
    introspection fails (server down, transport error), returns an empty
    list rather than raising — the curated ``tickets.*`` tools still work
    and the agent just won't have the extras until the next registry rebuild.
    """
    if mcp is None:
        return []
    try:
        # Ensure the underlying MCP session is connected, then enumerate.
        # _ensure_started is internal but stable — the chat tools already
        # call into _session for individual calls.
        await mcp._ensure_started()
        resp = await mcp._session.list_tools()
    except Exception as exc:  # noqa: BLE001 — degrading gracefully
        logger.warning("mcp_passthrough: list_tools failed: %s", exc)
        return []

    tools: list[Tool] = []
    for t in getattr(resp, "tools", []) or []:
        name = getattr(t, "name", "") or ""
        if not name or name in _HAND_WRAPPED:
            continue
        schema = getattr(t, "inputSchema", None) or {"type": "object", "properties": {}}
        description = (getattr(t, "description", "") or "").strip()
        chat_name = f"mcp.{name}"
        tools.append(_build_passthrough_tool(chat_name, name, description, schema))
    return tools


def _build_passthrough_tool(
    chat_name: str, mcp_name: str, description: str, schema: dict[str, Any]
) -> Tool:
    async def _run(args: dict[str, Any], ctx: dict[str, Any]) -> dict[str, Any]:
        mcp = ctx.get("local_todo")
        if mcp is None:
            return {"status": "error", "error": "local-todo not configured"}
        try:
            result = await mcp.call_tool(mcp_name, args or {})
        except Exception as exc:  # noqa: BLE001 — surface as tool result
            return {"status": "error", "error": str(exc)[:300]}
        return {"status": "ok", "result": result}

    return Tool(
        name=chat_name,
        description=description or f"MCP passthrough for `{mcp_name}`.",
        input_schema=schema,
        run=_run,
        is_mutation=_is_mutation(mcp_name),
    )
