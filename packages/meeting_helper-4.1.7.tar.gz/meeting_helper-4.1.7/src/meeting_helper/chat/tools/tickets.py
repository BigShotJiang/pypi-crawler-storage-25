"""local-todo MCP wrappers exposed as agent tools."""
from __future__ import annotations

from typing import Any

from meeting_helper.chat.registry import Tool


def _mcp(ctx: dict[str, Any]):
    mcp = ctx.get("local_todo")
    if mcp is None:
        raise RuntimeError("local-todo not configured")
    return mcp


def _err(exc: Exception) -> dict[str, Any]:
    return {"status": "error", "error": str(exc)[:200]}


async def _search(args, ctx):
    q = args.get("q", "")
    if not q:
        return {"status": "error", "error": "q is required"}
    limit = int(args.get("limit", 10))
    try:
        matches = await _mcp(ctx).search(q, limit=limit)
    except Exception as exc:  # noqa: BLE001 — surface MCP failures to the agent
        return _err(exc)
    if not matches:
        return {
            "status": "ok",
            "result": {
                "matches": [],
                "note": "no matches; consider broader or partial keywords",
            },
        }
    return {"status": "ok", "result": {"matches": matches}}


async def _get(args, ctx):
    tid = args.get("id")
    if not tid:
        return {"status": "error", "error": "id is required"}
    tid = str(tid)
    mcp = _mcp(ctx)

    # IDs in local-todo are short strings/integers per task — they don't
    # appear in titles, so mcp.search(tid) returns nothing useful. Go
    # straight to the direct mcp.get(kind, id, board_id) lookup, walking
    # every board the user has access to and trying both task and doc.
    try:
        boards = await mcp.list_boards()
    except Exception as exc:  # noqa: BLE001
        return _err(exc)

    board_ids = [b["board_id"] for b in boards]
    if args.get("board_id"):
        board_ids = [args["board_id"]] + [b for b in board_ids if b != args["board_id"]]

    task = None
    matched_board_id = None
    matched_kind = None
    last_error = None
    for kind in ("task", "doc"):
        for bid in board_ids:
            try:
                got = await mcp.get(kind, tid, bid)
            except Exception as exc:  # noqa: BLE001
                last_error = exc
                continue
            if got:
                task = got
                matched_board_id = bid
                matched_kind = kind
                break
        if task is not None:
            break

    if task is None:
        # Last-ditch: maybe the user gave a title fragment rather than an id —
        # fall back to a search so the agent still learns something.
        try:
            candidates = await mcp.search(tid, limit=5)
        except Exception as exc:  # noqa: BLE001
            return _err(exc)
        if not candidates:
            note = "no task or doc with that id; try `tickets.search` with a keyword, or check `library.search_meetings` if it's a PR/MR reference"
            if last_error:
                note += f" (last get error: {str(last_error)[:120]})"
            return {"status": "ok", "result": {"task": None, "note": note}}
        # Pick first task candidate.
        match = next((c for c in candidates if c.get("kind") == "task"), candidates[0])
        try:
            task = await mcp.get(match.get("kind", "task"), str(match["id"]), match["board_id"])
            matched_board_id = match["board_id"]
            matched_kind = match.get("kind", "task")
            tid = str(match["id"])
        except Exception as exc:  # noqa: BLE001
            return _err(exc)

    subtasks: list = []
    activity: list = []
    if matched_kind == "task":
        try:
            subtasks_payload = await mcp.call_tool(
                "list_subtasks", {"task_id": tid}
            )
            activity_payload = await mcp.call_tool(
                "task_activity", {"task_id": tid}
            )
        except Exception as exc:  # noqa: BLE001
            return _err(exc)
        if isinstance(subtasks_payload, dict):
            subtasks = subtasks_payload.get("subtasks", subtasks_payload.get("items", []))
        elif isinstance(subtasks_payload, list):
            subtasks = subtasks_payload
        if isinstance(activity_payload, dict):
            activity = activity_payload.get("events", activity_payload.get("items", []))
        elif isinstance(activity_payload, list):
            activity = activity_payload

    return {
        "status": "ok",
        "result": {
            "task": task,
            "kind": matched_kind,
            "board_id": matched_board_id,
            "activity": activity,
            "subtasks": subtasks,
        },
    }


async def _list_boards(args, ctx):
    try:
        boards = await _mcp(ctx).list_boards()
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"status": "ok", "result": {"boards": boards}}


async def _list_in_sprint(args, ctx):
    app_state = ctx.get("app_state")
    if app_state is None:
        return {"status": "error", "error": "app state unavailable"}
    return {
        "status": "ok",
        "result": {"tickets": list(getattr(app_state, "sprint_tickets", []))},
    }


async def _add_comment(args, ctx):
    tid = args.get("task_id")
    body = args.get("body")
    if not tid or not body:
        return {"status": "error", "error": "task_id and body are required"}
    try:
        res = await _mcp(ctx).call_tool(
            "add_comment", {"task_id": tid, "body": body}
        )
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"status": "ok", "result": res}


async def _create_task(args, ctx):
    bid = args.get("board_id")
    title = args.get("title")
    if not bid or not title:
        return {"status": "error", "error": "board_id and title are required"}
    payload: dict = {"board_id": int(bid), "title": str(title)}
    for opt in ("description", "status", "assignee_id", "sprint_id"):
        if opt in args and args[opt] is not None:
            payload[opt] = args[opt]
    try:
        res = await _mcp(ctx).call_tool("create_task", payload)
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"status": "ok", "result": res}


async def _update_task(args, ctx):
    tid = args.get("task_id")
    if not tid:
        return {"status": "error", "error": "task_id is required"}
    payload: dict = {"task_id": str(tid)}
    for opt in ("title", "description", "status", "assignee_id"):
        if opt in args and args[opt] is not None:
            payload[opt] = args[opt]
    if len(payload) == 1:
        return {"status": "error", "error": "at least one field to update is required"}
    try:
        res = await _mcp(ctx).call_tool("update_task", payload)
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"status": "ok", "result": res}


async def _move_to_sprint(args, ctx):
    tid = args.get("task_id")
    sid = args.get("sprint_id")
    if not tid or not sid:
        return {"status": "error", "error": "task_id and sprint_id are required"}
    try:
        res = await _mcp(ctx).call_tool(
            "move_task_to_sprint", {"task_id": str(tid), "sprint_id": int(sid)}
        )
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"status": "ok", "result": res}


async def _task_activity(args, ctx):
    """Comments + history + audit log for a task. Where PR/MR refs live."""
    tid = args.get("task_id")
    if not tid:
        return {"status": "error", "error": "task_id is required"}
    try:
        payload = await _mcp(ctx).call_tool("task_activity", {"task_id": str(tid)})
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    if isinstance(payload, dict):
        events = payload.get("events", payload.get("items", []))
    elif isinstance(payload, list):
        events = payload
    else:
        events = []
    return {"status": "ok", "result": {"events": events}}


async def _list_subtasks(args, ctx):
    tid = args.get("task_id")
    if not tid:
        return {"status": "error", "error": "task_id is required"}
    try:
        payload = await _mcp(ctx).call_tool("list_subtasks", {"task_id": str(tid)})
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    if isinstance(payload, dict):
        subs = payload.get("subtasks", payload.get("items", []))
    elif isinstance(payload, list):
        subs = payload
    else:
        subs = []
    return {"status": "ok", "result": {"subtasks": subs}}


async def _list_sprints(args, ctx):
    """Return every sprint on a board, plus a flat `active` field.

    The underlying MCP returns ``{"active": <sprint?>, "planned": [...], "closed": [...]}``.
    We pass that structure through verbatim (so the agent can read
    ``result.active.id`` directly) and also flatten the three buckets into
    a single ``sprints`` list so the agent can iterate without three lookups.
    """
    bid = args.get("board_id")
    if not bid:
        return {"status": "error", "error": "board_id is required"}
    try:
        payload = await _mcp(ctx).call_tool("list_sprints", {"board_id": int(bid)})
    except Exception as exc:  # noqa: BLE001
        return _err(exc)

    if isinstance(payload, list):
        # Older shape: a bare list of sprints with a `state` field.
        return {
            "status": "ok",
            "result": {
                "sprints": payload,
                "active": next((s for s in payload if s.get("state") == "active"), None),
                "planned": [s for s in payload if s.get("state") == "planned"],
                "closed": [s for s in payload if s.get("state") == "closed"],
            },
        }

    if not isinstance(payload, dict):
        return {"status": "ok", "result": {"sprints": [], "active": None, "planned": [], "closed": []}}

    active = payload.get("active")
    planned = payload.get("planned", []) or []
    closed = payload.get("closed", []) or []
    sprints = ([active] if active else []) + list(planned) + list(closed)
    # Fallback: respect legacy {sprints:[...]} / {items:[...]} shapes too.
    if not sprints:
        sprints = payload.get("sprints", payload.get("items", [])) or []
    return {
        "status": "ok",
        "result": {
            "sprints": sprints,
            "active": active,
            "planned": planned,
            "closed": closed,
        },
    }


async def _get_active_sprint(args, ctx):
    """Shortcut: return the active sprint for a board (or None)."""
    bid = args.get("board_id")
    if not bid:
        return {"status": "error", "error": "board_id is required"}
    try:
        payload = await _mcp(ctx).call_tool("list_sprints", {"board_id": int(bid)})
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    if isinstance(payload, dict):
        active = payload.get("active")
        if not active and isinstance(payload.get("sprints"), list):
            active = next(
                (s for s in payload["sprints"] if s.get("state") == "active"),
                None,
            )
    elif isinstance(payload, list):
        active = next((s for s in payload if s.get("state") == "active"), None)
    else:
        active = None
    if active is None:
        return {"status": "ok", "result": {"sprint": None, "note": "no active sprint on this board"}}
    return {"status": "ok", "result": {"sprint": active}}


async def _list_task_docs(args, ctx):
    tid = args.get("task_id")
    if not tid:
        return {"status": "error", "error": "task_id is required"}
    try:
        payload = await _mcp(ctx).call_tool("list_task_doc_links", {"task_id": str(tid)})
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    if isinstance(payload, dict):
        docs = payload.get("docs", payload.get("links", payload.get("items", [])))
    elif isinstance(payload, list):
        docs = payload
    else:
        docs = []
    return {"status": "ok", "result": {"docs": docs}}


async def _search_docs(args, ctx):
    q = (args.get("q") or "").strip()
    if not q:
        return {"status": "error", "error": "q is required"}
    bid = args.get("board_id")
    limit = int(args.get("limit", 10))
    try:
        if bid:
            payload = await _mcp(ctx).call_tool(
                "search_docs", {"board_id": int(bid), "q": q, "limit": limit}
            )
            docs = (
                payload.get("docs", payload.get("items", []))
                if isinstance(payload, dict)
                else (payload if isinstance(payload, list) else [])
            )
        else:
            # Iterate all accessible boards so the agent doesn't need to
            # call list_boards first.
            boards = await _mcp(ctx).list_boards()
            docs = []
            for b in boards:
                p = await _mcp(ctx).call_tool(
                    "search_docs", {"board_id": b["board_id"], "q": q, "limit": limit}
                )
                items = (
                    p.get("docs", p.get("items", []))
                    if isinstance(p, dict)
                    else (p if isinstance(p, list) else [])
                )
                for it in items:
                    docs.append(
                        {"board_id": b["board_id"], "board_name": b.get("name", ""), **it}
                    )
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    if not docs:
        return {
            "status": "ok",
            "result": {"matches": [], "note": "no docs matched; consider broader keywords"},
        }
    return {"status": "ok", "result": {"matches": docs}}


async def _get_doc(args, ctx):
    did = args.get("doc_id")
    bid = args.get("board_id")
    if not did or not bid:
        return {"status": "error", "error": "doc_id and board_id are required"}
    try:
        doc = await _mcp(ctx).get("doc", str(did), int(bid))
    except Exception as exc:  # noqa: BLE001
        return _err(exc)
    return {"status": "ok", "result": {"doc": doc}}


def build_tickets_search() -> Tool:
    return Tool(
        name="tickets.search",
        description=(
            "Search local-todo tickets by KEYWORD (matches against title/body — "
            "NOT by id). Use freely; no rate limit. Retry with broader / shorter / "
            "synonym keywords if the first attempt returns 0 matches. "
            "Note: PR/MR numbers (e.g. 'PR 3696') are usually NOT in ticket titles; "
            "search for the ticket's project code (e.g. 'ENGT-4212') or for related "
            "keywords (the component name, the feature) instead. To look up a "
            "specific ticket by id, use `tickets.get`."
        ),
        input_schema={"q": "string", "limit": "integer?"},
        run=_search,
    )


def build_tickets_get() -> Tool:
    return Tool(
        name="tickets.get",
        description=(
            "Fetch a ticket by its numeric id (e.g. '140'). Walks every board the "
            "user has access to and tries both task and doc kinds. Returns the "
            "full record + subtasks + activity for tasks. If the id doesn't exist, "
            "falls back to a keyword search on the same string as a courtesy."
        ),
        input_schema={"id": "string", "board_id": "integer?"},
        run=_get,
    )


def build_tickets_list_boards() -> Tool:
    return Tool(
        name="tickets.list_boards",
        description="List all local-todo boards the user has access to.",
        input_schema={},
        run=_list_boards,
    )


def build_tickets_list_in_sprint() -> Tool:
    return Tool(
        name="tickets.list_in_sprint",
        description="List tickets in the active sprint (already cached on the daemon).",
        input_schema={},
        run=_list_in_sprint,
    )


def build_tickets_add_comment() -> Tool:
    return Tool(
        name="tickets.add_comment",
        description="Post a comment on a ticket. Requires the user's explicit approval.",
        input_schema={"task_id": "string", "body": "string"},
        run=_add_comment,
        is_mutation=True,
    )


def build_tickets_task_activity() -> Tool:
    return Tool(
        name="tickets.task_activity",
        description=(
            "Get comments, status changes, and audit log for a task. USE THIS when "
            "the user references something that isn't in the title — PR/MR numbers, "
            "external links, decisions — these usually live in comments, not titles. "
            "After tickets.search returns matches, fetch task_activity for the top "
            "results to find what the user is actually asking about."
        ),
        input_schema={"task_id": "string"},
        run=_task_activity,
    )


def build_tickets_list_subtasks() -> Tool:
    return Tool(
        name="tickets.list_subtasks",
        description="List subtasks of a task. Useful for epics and ticket trees.",
        input_schema={"task_id": "string"},
        run=_list_subtasks,
    )


def build_tickets_list_sprints() -> Tool:
    return Tool(
        name="tickets.list_sprints",
        description=(
            "List sprints on a board. Returns `{active, planned, closed, sprints}` — "
            "read `result.active` for the CURRENT sprint (most common need). The "
            "active sprint has an `id` you can pass to `tickets.create_task` as "
            "`sprint_id` to put a new ticket directly into the current sprint."
        ),
        input_schema={"board_id": "integer"},
        run=_list_sprints,
    )


def build_tickets_get_active_sprint() -> Tool:
    return Tool(
        name="tickets.get_active_sprint",
        description=(
            "Get just the active sprint for a board (or `null` if none). "
            "Faster than `tickets.list_sprints` when you only need `sprint_id` "
            "to attach a new ticket to the current sprint."
        ),
        input_schema={"board_id": "integer"},
        run=_get_active_sprint,
    )


def build_tickets_list_task_docs() -> Tool:
    return Tool(
        name="tickets.list_task_docs",
        description=(
            "List handover docs / RFCs / notes linked to a task. Investigation notes "
            "often live here, not in the task body."
        ),
        input_schema={"task_id": "string"},
        run=_list_task_docs,
    )


def build_tickets_search_docs() -> Tool:
    return Tool(
        name="tickets.search_docs",
        description=(
            "Search local-todo DOCS by keyword across boards (or one specific board). "
            "Docs hold handover notes, RFCs, design discussions — search them when "
            "tickets.search doesn't find a topic."
        ),
        input_schema={"q": "string", "board_id": "integer?", "limit": "integer?"},
        run=_search_docs,
    )


def build_tickets_get_doc() -> Tool:
    return Tool(
        name="tickets.get_doc",
        description="Fetch a single doc by id (use ids returned by tickets.search_docs).",
        input_schema={"doc_id": "string", "board_id": "integer"},
        run=_get_doc,
    )


def build_tickets_create_task() -> Tool:
    return Tool(
        name="tickets.create_task",
        description="Create a new ticket on a board. Requires the user's approval.",
        input_schema={
            "board_id": "integer",
            "title": "string",
            "description": "string?",
            "status": "string?",
            "assignee_id": "string?",
            "sprint_id": "integer?",
        },
        run=_create_task,
        is_mutation=True,
    )


def build_tickets_update_task() -> Tool:
    return Tool(
        name="tickets.update_task",
        description=(
            "Modify a ticket's title / description / status / assignee. "
            "Requires the user's approval."
        ),
        input_schema={
            "task_id": "string",
            "title": "string?",
            "description": "string?",
            "status": "string?",
            "assignee_id": "string?",
        },
        run=_update_task,
        is_mutation=True,
    )


def build_tickets_move_to_sprint() -> Tool:
    return Tool(
        name="tickets.move_to_sprint",
        description="Move a ticket into a sprint. Requires the user's approval.",
        input_schema={"task_id": "string", "sprint_id": "integer"},
        run=_move_to_sprint,
        is_mutation=True,
    )
