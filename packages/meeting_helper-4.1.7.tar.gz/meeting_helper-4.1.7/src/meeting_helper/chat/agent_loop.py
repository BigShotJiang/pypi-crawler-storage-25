"""Provider-agnostic agent loop with tool use.

The loop is generic over the *provider* and the *registry*. The caller
plugs in:
  - provider: object with `async def stream_completion(system, messages, tools)`
    yielding event dicts: {type: chunk, text} / {type: tool_use, id, name, input} / {type: done, stop_reason}
  - registry: meeting_helper.chat.registry.Registry
  - on_chunk(text): broadcast a text chunk
  - on_tool_call(name, args) -> dict | None:
       * for non-mutating tools, returns None (proceed)
       * for mutating tools, returns {decision: "approve"|"cancel", edited_args?: dict}
  - on_tool_result(name, result): broadcast the result

Hard cap on tool-use cycles to prevent runaway.
"""
from __future__ import annotations

import json
from typing import Any, Awaitable, Callable

from meeting_helper.chat.registry import Registry


OnChunk = Callable[[str], Awaitable[None]]
OnToolCall = Callable[[str, dict[str, Any]], Awaitable[dict[str, Any] | None]]
OnToolResult = Callable[[str, dict[str, Any]], Awaitable[None]]


async def run_agent(
    *,
    system: str,
    messages: list[dict[str, Any]],
    registry: Registry,
    provider: Any,
    on_chunk: OnChunk,
    on_tool_call: OnToolCall,
    on_tool_result: OnToolResult,
    max_cycles: int = 30,
    ctx: dict[str, Any] | None = None,
) -> dict[str, Any]:
    ctx = ctx or {}
    text_acc: list[str] = []
    convo = list(messages)
    tools_schema = [
        {"name": t.name, "description": t.description, "input_schema": t.input_schema}
        for t in registry.tools()
    ]
    for cycle in range(max_cycles + 1):
        if cycle == max_cycles:
            return {"text": "".join(text_acc), "error": "tool_cycle_limit_exceeded"}
        pending_tool_uses: list[dict[str, Any]] = []
        async for ev in provider.stream_completion(
            system=system, messages=convo, tools=tools_schema
        ):
            if ev["type"] == "chunk":
                text_acc.append(ev["text"])
                await on_chunk(ev["text"])
            elif ev["type"] == "tool_use":
                pending_tool_uses.append(ev)
            elif ev["type"] == "done":
                break
        if not pending_tool_uses:
            return {"text": "".join(text_acc), "error": None}

        tool_results = []
        registered_names = [t.name for t in registry.tools()]
        for tu in pending_tool_uses:
            name, args, tu_id = tu["name"], tu["input"], tu["id"]
            tool = registry.get(name) if name in registered_names else None
            if tool is None:
                result = {"status": "error", "error": f"unknown tool: {name}"}
            elif tool.is_mutation:
                decision = await on_tool_call(name, args)
                if not decision or decision.get("decision") != "approve":
                    result = {"status": "cancelled"}
                else:
                    effective_args = decision.get("edited_args") or args
                    result = await registry.call(name, effective_args, ctx)
            else:
                await on_tool_call(name, args)
                result = await registry.call(name, args, ctx)
            await on_tool_result(name, result)
            tool_results.append({"tool_use_id": tu_id, "name": name, "result": result})

        # Append the tool_use + tool_result pair to the convo for the next call.
        convo.append({
            "role": "assistant",
            "content": [
                {"type": "tool_use", "id": tu["id"], "name": tu["name"], "input": tu["input"]}
                for tu in pending_tool_uses
            ],
        })
        convo.append({
            "role": "user",
            "content": [
                {"type": "tool_result", "tool_use_id": r["tool_use_id"], "content": json.dumps(r["result"])}
                for r in tool_results
            ],
        })

    return {"text": "".join(text_acc), "error": None}
