"""MeetingSession: orchestrates the detect → record → transcribe → stop lifecycle."""

from __future__ import annotations

import asyncio
import logging
import re
import threading
import time
from pathlib import Path
from typing import TYPE_CHECKING, Callable, Optional

from meeting_helper.live_transcript import LiveTranscriptWriter

if TYPE_CHECKING:
    from meeting_helper.buffer import SentenceBuffer
    from meeting_helper.config import AppConfig
    from meeting_helper.meeting_detector import MeetingInfo

logger = logging.getLogger(__name__)


# How long the meeting-end thread blocks waiting for the post-meeting
# auto-summary before giving up and letting the daemon restart. The summary
# coroutine isn't cancelled on timeout — it may still finish before os._exit.
SUMMARY_WAIT_SEC = 180.0
# Auto-rename is a single short LLM call — give it less budget than summary.
RENAME_WAIT_SEC = 60.0
# Auto-name-speakers is also a single short LLM call.
NAME_SPEAKERS_WAIT_SEC = 60.0


def _has_ai_provider(config: "AppConfig") -> bool:
    """True iff the workspace can reach SOME AI provider for a one-shot call."""
    if (config.anthropic_api_key or "").strip():
        return True
    if (config.google_api_key or "").strip():
        return True
    if (config.preferred_provider or "").strip().lower() == "local":
        return True
    return False


def _rename_meeting_artifacts(mp3_path: Path, new_label: str) -> Optional[Path]:
    """Rename mp3 + adjacent transcripts/summary/tasks by swapping the post-timestamp
    portion of the stem with a sanitized `new_label`. Returns the new mp3 Path on
    success, or None if rename was skipped (no timestamp prefix, empty label, or
    the destination already exists).
    """
    stem = mp3_path.stem  # e.g. "2026-05-13_143000_Old_Label" or "2026-05-13_143000"
    parts = stem.split("_", 2)
    if len(parts) < 2 or len(parts[0]) != 10 or "-" not in parts[0]:
        logger.info("Auto-rename skipped: stem %r has no recognizable timestamp prefix", stem)
        return None
    prefix = f"{parts[0]}_{parts[1]}"  # "YYYY-MM-DD_HHMMSS"
    sanitized = re.sub(r"[^\w\-]", "", new_label.replace(" ", "_")).strip("_-")
    if len(sanitized) > 50:
        sanitized = sanitized[:50].rstrip("_-")
    if not sanitized:
        logger.info("Auto-rename skipped: AI returned no usable name")
        return None
    new_stem = f"{prefix}_{sanitized}"
    if new_stem == stem:
        return None
    new_mp3 = mp3_path.with_name(f"{new_stem}.mp3")
    if new_mp3.exists() and new_mp3 != mp3_path:
        logger.info("Auto-rename skipped: %s already exists", new_mp3.name)
        return None

    renamed_mp3: Optional[Path] = None
    for suffix in (
        ".mp3",
        ".live.txt",
        ".transcript.txt",
        ".summary.txt",
        ".tasks.json",
        ".speakers.json",
    ):
        old = mp3_path.with_suffix(suffix)
        if not old.is_file():
            continue
        new = old.with_name(f"{new_stem}{suffix}")
        try:
            old.rename(new)
            if suffix == ".mp3":
                renamed_mp3 = new
        except OSError as exc:
            logger.warning("Auto-rename: failed to rename %s -> %s: %s", old.name, new.name, exc)
    return renamed_mp3


async def _broadcast_summarizing(active: bool, transcript_name: str) -> None:
    """Tell connected clients whether the post-meeting summary is in progress."""
    try:
        from meeting_helper.server.websocket import broadcast
        await broadcast({
            "type": "summarizing",
            "active": active,
            "transcript": transcript_name,
        })
    except Exception:
        pass


class ProactiveMonitor:
    """Watches the transcript buffer and fires Claude queries automatically.

    Trigger rule: new sentence ends with '?' + 1 second of silence after it.

    Constraints:
    - 60s minimum cooldown between proactive fires
    - 30s cooldown after any manual query
    - Never interrupts an in-progress response
    - Buffer is never cleared — manual queries still have full context
    """

    SILENCE_SECS = 2.0  # silence after question before firing

    def __init__(self, config, buffer) -> None:
        self._config = config
        self._buffer = buffer
        self._pending_sentence: str | None = None
        self._timer: threading.Timer | None = None
        self._fire_id: int = 0
        self._lock = threading.Lock()
        self._enabled: bool = True

    def set_enabled(self, enabled: bool) -> None:
        self._enabled = enabled
        if not enabled:
            self._cancel_pending()
        logger.info("Proactive monitor %s", "enabled" if enabled else "disabled")

    def is_enabled(self) -> bool:
        return self._enabled

    def notify_manual_query(self) -> None:
        """Cancel any pending proactive trigger when user manually queries."""
        self._cancel_pending()

    def on_sentence(self, sentence: str, _speaker: int | None = None) -> None:
        """Called by SentenceBuffer on every new final sentence."""
        if not self._enabled:
            return
        if not sentence.rstrip().endswith("?"):
            self._cancel_pending()
            return
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None
            self._pending_sentence = sentence
            self._fire_id += 1
            current_id = self._fire_id
        # Start the 1s silence timer, passing fire_id to detect stale firings
        t = threading.Timer(self.SILENCE_SECS, self._maybe_fire, args=(current_id,))
        t.daemon = True
        with self._lock:
            self._timer = t
        t.start()

    def _cancel_pending(self, cancel_sentence: bool = True) -> None:
        with self._lock:
            if self._timer:
                self._timer.cancel()
                self._timer = None
            if cancel_sentence:
                self._pending_sentence = None
                self._fire_id += 1  # invalidate any running timer

    def _maybe_fire(self, fire_id: int) -> None:
        with self._lock:
            if fire_id != self._fire_id:
                return  # Stale timer — a newer question arrived, skip
            sentence = self._pending_sentence
            self._pending_sentence = None
            self._timer = None

        if not sentence:
            return

        from meeting_helper.state import state
        if state.status == "processing":
            logger.debug("Proactive: skipped (response in progress)")
            return

        logger.info("Proactive: firing for question: %s", sentence[:80])

        loop = state.asyncio_loop
        if loop is not None:
            import asyncio
            asyncio.run_coroutine_threadsafe(
                self._fire(sentence), loop
            )

    async def _fire(self, question: str) -> None:
        from meeting_helper.ai.client import handle_query
        from meeting_helper.state import state
        await handle_query(state, self._config)

    def stop(self) -> None:
        self._cancel_pending()


def _transcriber_display_name(transcriber, config) -> str:
    """Return a human-readable name for the active transcriber."""
    from meeting_helper.audio.transcriber import RemoteWhisperTranscriber
    if transcriber is None:
        return "none"
    if isinstance(transcriber, RemoteWhisperTranscriber):
        return f"Whisper (remote: {config.whisper_host})"
    if config.deepgram_api_key and hasattr(transcriber, '_api_key'):
        return "Deepgram"
    return "Whisper (local)"


async def _maybe_auto_name_speakers(
    mp3_path: Path,
    live_transcript_path: Optional[Path],
    config,
) -> None:
    """Run the AI naming step on the just-written transcript.

    Writes ``<id>.speakers.json`` alongside the MP3. Merges with any
    pre-existing sidecar so manual edits survive an auto-name re-run.
    If ``config.user_display_name`` is set, SELF is forced to that value
    with ``source="manual"`` regardless of what the AI suggested.

    No-op when ``config.auto_name_speakers_on_end`` is False.
    """
    if not config.auto_name_speakers_on_end:
        return
    if live_transcript_path is None or not live_transcript_path.is_file():
        logger.info("auto-name-speakers: skipped — no live transcript")
        return
    from meeting_helper import speakers as _speakers
    from meeting_helper.ai.client import name_speakers_from_transcript

    try:
        ai_map = await name_speakers_from_transcript(str(live_transcript_path), config)
    except Exception as exc:
        logger.warning("auto-name-speakers: AI call failed: %s", exc, exc_info=True)
        return

    if not ai_map.names:
        logger.info("auto-name-speakers: model returned no labels — nothing written")
        return

    if config.user_display_name:
        ai_map.names["SELF"] = config.user_display_name
        ai_map.source["SELF"] = "manual"
        ai_map.evidence.pop("SELF", None)

    sidecar = _speakers.speakers_path_for(mp3_path)
    existing = _speakers.read_speaker_map(sidecar)
    merged = _speakers.merge_speaker_map(existing, ai_map)
    try:
        _speakers.write_speaker_map(
            sidecar,
            names=merged.names,
            evidence=merged.evidence,
            source=merged.source,
        )
        logger.info(
            "auto-name-speakers: wrote %s (%d labels)",
            sidecar.name, len(merged.names),
        )
    except Exception as exc:
        logger.warning("auto-name-speakers: write failed: %s", exc)


class MeetingSession:
    """Manages the full lifecycle of meeting recording and transcription.

    States: idle → active → stopping → idle
    Runs in its own background thread.
    """

    def __init__(
        self,
        config: AppConfig,
        self_buffer: SentenceBuffer,
        other_buffer: SentenceBuffer,
        on_meeting_start: Callable[[MeetingInfo], None],
        on_meeting_end: Callable[[Optional[Path]], None],
    ) -> None:
        self._config = config
        self._self_buffer = self_buffer
        self._other_buffer = other_buffer
        self._on_meeting_start = on_meeting_start
        self._on_meeting_end = on_meeting_end
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._self_transcriber = None
        self._other_transcriber = None
        self._capture = None
        # Single-session guard. Both `_run` (mic auto-detect) and
        # `_run_manual_session` (Start-button) can race to call
        # `_run_active_session` — without this lock both paths spawn a
        # parallel `RecordingSession`, producing two MP3s per meeting.
        # We try to acquire non-blocking at entry; a second concurrent
        # invocation simply logs and returns.
        self._active_session_lock = threading.Lock()

    def start(self) -> None:
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._run, daemon=True)
        self._thread.start()

    def stop(self) -> None:
        self._stop_event.set()

    def manual_start(self) -> None:
        """Kick off a full session manually (no mic detection)."""
        from meeting_helper.meeting_detector import MeetingInfo
        info = MeetingInfo(app_name="Manual", meeting_name="Manual Recording", window_title="", is_active=True)
        self._manual_stop = threading.Event()
        t = threading.Thread(target=self._run_manual_session, args=(info,), daemon=True)
        t.start()

    def swap_transcriber(self, preferred_transcriber: str, config: "AppConfig") -> str:
        """Hot-swap both transcribers mid-session. Returns new transcriber display name."""
        from meeting_helper.audio.transcriber import create_transcriber

        if self._self_transcriber is not None:
            self._self_transcriber.stop()
        if self._other_transcriber is not None:
            self._other_transcriber.stop()

        if self._capture is None:
            logger.warning("swap_transcriber: no active audio capture")
            return "none"

        self._self_transcriber = create_transcriber(
            audio_capture=self._capture.self_stream,
            transcript_buffer=self._self_buffer,
            deepgram_api_key=config.deepgram_api_key,
            transcription_language=config.transcription_language,
            preferred_transcriber=preferred_transcriber,
            whisper_host=config.whisper_host,
            diarize=config.deepgram_diarize_self,
        )
        self._other_transcriber = create_transcriber(
            audio_capture=self._capture.other_stream,
            transcript_buffer=self._other_buffer,
            deepgram_api_key=config.deepgram_api_key,
            transcription_language=config.transcription_language,
            preferred_transcriber=preferred_transcriber,
            whisper_host=config.whisper_host,
            diarize=config.deepgram_diarize_other,
        )
        t_name = _transcriber_display_name(self._self_transcriber, config)
        logger.info("Transcribers hot-swapped to: %s", t_name)
        return t_name

    def manual_stop(self) -> None:
        """Stop a manually-started session."""
        if hasattr(self, "_manual_stop"):
            self._manual_stop.set()

    def _run_manual_session(self, meeting_info: MeetingInfo) -> None:
        """Run a full session triggered manually — ends on manual_stop().

        Restarts the daemon after the session ends so the next manual start
        gets a fresh PortAudio context, matching the auto-detect path.
        Without this, subsequent manual starts fail silently because the
        PortAudio/CoreAudio state is stale after capture.stop().
        """
        ran = False
        try:
            ran = self._run_active_session(meeting_info, stop_event=self._manual_stop)
        except Exception as exc:
            logger.error("Manual session error: %s", exc, exc_info=True)
        if not ran:
            # Auto-detect already running a session — bail without
            # restarting the daemon, otherwise the in-flight session
            # would be killed mid-recording.
            return
        # _run_active_session's finally block already fired _on_meeting_end;
        # spawn a fresh daemon so the next manual session starts clean.
        self._restart_daemon()

    def _maybe_auto_rename(
        self,
        mp3_path: Path,
        live_transcript_path: Optional[Path],
        summary_text: str,
    ) -> Optional[Path]:
        """Generate a name from the summary (or transcript fallback) and rename the
        meeting artifacts. Returns the new mp3 Path on success; None if skipped or
        on failure. Same shutdown-blocking pattern as auto-summary: runs on the
        daemon loop and waits for the result so os._exit doesn't kill it.
        """
        if not _has_ai_provider(self._config):
            logger.info("Auto-rename enabled but no AI provider configured — skipping")
            return None

        source = (summary_text or "").strip()
        if not source and live_transcript_path is not None and live_transcript_path.is_file():
            try:
                source = live_transcript_path.read_text().strip()
            except OSError as exc:
                logger.warning("Auto-rename: could not read transcript: %s", exc)
                source = ""
        if not source:
            logger.info("Auto-rename skipped: no summary or transcript text available")
            return None

        try:
            import asyncio as _asyncio
            import concurrent.futures as _cf
            from meeting_helper.ai.client import name_meeting_from_text
            from meeting_helper.state import state as _app_state

            loop = _app_state.asyncio_loop
            if loop is not None and loop.is_running():
                fut = _asyncio.run_coroutine_threadsafe(
                    name_meeting_from_text(source, self._config), loop,
                )
                try:
                    new_label = fut.result(timeout=RENAME_WAIT_SEC)
                except _cf.TimeoutError:
                    logger.warning("Auto-rename timed out after %.0fs", RENAME_WAIT_SEC)
                    return None
            else:
                # Test context.
                new_label = _asyncio.run(name_meeting_from_text(source, self._config))
        except Exception as exc:
            logger.warning("Auto-rename: name generation failed: %s", exc, exc_info=True)
            return None

        if not new_label:
            logger.info("Auto-rename skipped: provider returned no name")
            return None

        new_mp3 = _rename_meeting_artifacts(mp3_path, new_label)
        if new_mp3 is not None:
            logger.info("Auto-rename: %s -> %s", mp3_path.name, new_mp3.name)
        return new_mp3

    def _maybe_auto_add_to_kb(self, mp3_path: Path) -> None:
        """Append the meeting's .summary.txt to the active workspace's
        kb_artifacts. The daemon holds an immutable AppConfig snapshot, so
        we re-open the file-backed Config to persist the change for the
        next daemon start. No-op if the summary file doesn't exist yet
        (auto-summarize disabled or failed) or if it's already in the list.
        """
        summary_path = mp3_path.with_suffix(".summary.txt")
        if not summary_path.is_file():
            logger.info(
                "Auto-add-to-KB skipped: no summary file at %s", summary_path.name,
            )
            return
        try:
            from meeting_helper.config import Config
            workspace_cfg = Config()
            if workspace_cfg.is_kb(summary_path.name):
                return
            workspace_cfg.add_kb(summary_path.name)
            logger.info("Auto-add-to-KB: indexed %s", summary_path.name)
        except Exception as exc:
            logger.warning("Auto-add-to-KB failed: %s", exc, exc_info=True)

    def _restart_daemon(self) -> None:
        """Spawn a fresh daemon process and exit, giving the next meeting a clean PortAudio state."""
        import subprocess, sys, os
        try:
            executable = sys.executable
            subprocess.Popen(
                [executable, "-m", "meeting_helper"],
                stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                start_new_session=True,
            )
            logger.info("MeetingSession: spawned fresh daemon — exiting current process")
            os._exit(0)
        except Exception as exc:
            logger.warning("MeetingSession: could not restart daemon: %s", exc)

    def _run(self) -> None:
        """Main loop: detect meeting → start capture/transcription → wait for end."""
        if not self._config.auto_start_record:
            logger.info("MeetingSession: auto_start_record disabled — waiting for manual start")
            self._stop_event.wait()
            return

        # ALL audio imports happen HERE (after daemon fork)
        from meeting_helper.meeting_detector import MeetingMonitor

        monitor = MeetingMonitor()
        logger.info("MeetingSession: watching for meetings (mic-based detection)...")

        while not self._stop_event.is_set():
            started, ended, meeting_info = monitor.check()

            if started and meeting_info:
                logger.info("Meeting detected: %s (%s)", meeting_info.app_name, meeting_info.meeting_name or "unnamed")
                _portaudio_retries = 0
                ran = False
                while not self._stop_event.is_set():
                    try:
                        ran = self._run_active_session(meeting_info)
                        break
                    except Exception as exc:
                        msg = str(exc)
                        if "PaErrorCode -9986" in msg or "PortAudio" in msg or "InputStream" in msg:
                            _portaudio_retries += 1
                            if _portaudio_retries <= 5:
                                logger.warning("PortAudio mic error (attempt %d/5) — retrying in 3s: %s", _portaudio_retries, exc)
                                self._stop_event.wait(timeout=3.0)
                                continue
                        logger.error("MeetingSession: session error: %s", exc, exc_info=True)
                        break
                if not ran:
                    # A manual session is in flight — the mic activity we
                    # saw is THEIRS. Skip post-meeting cleanup (would kill
                    # the daemon while the manual session is still
                    # recording) and just keep polling.
                    self._stop_event.wait(timeout=2.0)
                    continue
                monitor.set_meeting_ended()
                # Cooldown: wait for mic to fully release before re-monitoring
                logger.info("MeetingSession: cooldown before re-watching...")
                self._stop_event.wait(timeout=1.0)
                # Restart daemon to get a fresh PortAudio context for the next meeting
                self._restart_daemon()
                logger.info("MeetingSession: back to watching for meetings...")
            else:
                self._stop_event.wait(timeout=2.0)  # poll every 2s (matching meeting-noter)

    def _run_active_session(self, meeting_info: MeetingInfo,
                             stop_event: Optional[threading.Event] = None) -> bool:
        """Capture + transcribe + record until meeting app releases the mic.

        No silence detection — recording continues as long as the meeting app
        holds the microphone. Only MicProbe ends the session (or stop_event for manual).

        Single-session guard: if another invocation is already running (e.g.
        the mic-detect thread fired just as the user hit Start), bail out
        instead of opening a second RecordingSession and producing a
        duplicate MP3.

        Returns True when the session actually ran, False when it was
        skipped because the lock was already held. Callers must NOT run
        post-session cleanup (``monitor.set_meeting_ended`` / daemon
        restart) on a False return — that cleanup would kill the OTHER
        in-flight session.
        """
        if not self._active_session_lock.acquire(blocking=False):
            logger.warning(
                "_run_active_session: another session already active (%s / %s) — skipping",
                meeting_info.app_name, meeting_info.meeting_name,
            )
            return False
        try:
            self._run_active_session_locked(meeting_info, stop_event)
        finally:
            self._active_session_lock.release()
        return True

    def _run_active_session_locked(self, meeting_info: MeetingInfo,
                                    stop_event: Optional[threading.Event] = None) -> None:
        """Inner body; only reached after `_active_session_lock` is held."""
        from meeting_helper.audio.capture import CombinedAudioCapture
        from meeting_helper.audio.transcriber import create_transcriber
        from meeting_helper.audio.encoder import RecordingSession
        from meeting_helper.daemon import MicProbe

        from meeting_helper.state import state as app_state
        # Reset per-session task list before notifying anyone
        app_state.session_tasks = []
        self._on_meeting_start(meeting_info)

        self._capture = CombinedAudioCapture(sample_rate=16000)
        capture = self._capture
        self._self_transcriber = None
        self._other_transcriber = None
        recording = None
        saved_path = None
        live_transcript_path = None
        live_writer = None
        self_listener = None
        other_listener = None

        # Proactive monitor — only active when enabled in config
        # Watches user-side speech (self_buffer) for "?" triggers.
        proactive = None
        if self._config.proactive_answers:
            proactive = ProactiveMonitor(self._config, self._self_buffer)
            self._self_buffer.add_sentence_listener(proactive.on_sentence)
            app_state.proactive_monitor = proactive
            logger.info("Proactive answers enabled")

        # Topic worker — maintains state.current_topic from self-buffer speech (C3)
        topic_worker = None
        try:
            from meeting_helper.topic_worker import TopicWorker
            topic_worker = TopicWorker(self._config, self._self_buffer)
            topic_worker.start()
            app_state.topic_worker = topic_worker
        except Exception as exc:
            logger.warning("Failed to start topic worker: %s", exc)
            topic_worker = None

        # Pre-load the active-sprint ticket cache so the topic picker has its
        # candidate list ready from the first TopicWorker cycle (no cold-start
        # window where the banner is blank).
        try:
            from meeting_helper.ai.client import refresh_sprint_tickets
            loop = app_state.asyncio_loop
            if loop is not None:
                asyncio.run_coroutine_threadsafe(
                    refresh_sprint_tickets(app_state, force=True), loop
                )
        except Exception as exc:
            logger.warning("Failed to schedule sprint cache preload: %s", exc)

        try:
            capture.start()
            app_state.audio_active = True
            logger.info("Audio capture started (system_audio=%s)", capture.has_system_audio)

            # Start two transcribers — one per role (C2)
            self._self_transcriber = create_transcriber(
                audio_capture=capture.self_stream,
                transcript_buffer=self._self_buffer,
                deepgram_api_key=self._config.deepgram_api_key,
                transcription_language=self._config.transcription_language,
                preferred_transcriber=self._config.preferred_transcriber,
                whisper_host=self._config.whisper_host,
                diarize=self._config.deepgram_diarize_self,
            )
            self._other_transcriber = create_transcriber(
                audio_capture=capture.other_stream,
                transcript_buffer=self._other_buffer,
                deepgram_api_key=self._config.deepgram_api_key,
                transcription_language=self._config.transcription_language,
                preferred_transcriber=self._config.preferred_transcriber,
                whisper_host=self._config.whisper_host,
                diarize=self._config.deepgram_diarize_other,
            )

            # Update daemon metadata with transcriber name
            from meeting_helper.daemon import write_meta
            t_name = _transcriber_display_name(self._self_transcriber, self._config)
            write_meta(self._config, transcriber_name=t_name)
            app_state.transcriber_name = t_name
            # Mirror the active AI provider/model into state so the `info`
            # broadcast and the Copilot toolbar chips reflect what's in use
            # from the moment the meeting starts (not just after a /provider POST).
            app_state.ai_provider = self._config.preferred_provider or "claude"
            if self._config.preferred_provider == "local":
                app_state.ai_model = self._config.local_model
            elif self._config.preferred_provider == "gemini":
                app_state.ai_model = self._config.gemini_model
            else:
                app_state.ai_model = self._config.claude_model
            logger.info("Transcribers running: %s", t_name)

            # Broadcast info to overlay
            loop = app_state.asyncio_loop
            if loop:
                # Don't `import asyncio` here — Python's scoping makes asyncio
                # a *local* variable for the entire function once seen as an
                # import, which then breaks the use at line ~465 (sprint cache
                # preload) where asyncio is referenced earlier in the function.
                # The module-level `import asyncio` at the top of this file
                # already covers us.
                from meeting_helper.server.websocket import broadcast_info
                asyncio.run_coroutine_threadsafe(broadcast_info(), loop)

            # Always record to MP3
            recordings_dir = self._config.recordings_dir
            recordings_dir.mkdir(parents=True, exist_ok=True)
            recording = RecordingSession(
                output_dir=recordings_dir,
                sample_rate=capture.sample_rate,
                channels=capture.channels,
                meeting_name=meeting_info.meeting_name or meeting_info.app_name,
            )
            mp3_path = recording.start()
            live_transcript_path = mp3_path.with_suffix(".live.txt")
            logger.info("Recording to: %s", mp3_path.name)

            # Transcriber health monitor — periodic check. If either feed
            # thread is dead (e.g. Deepgram exhausted reconnects, Whisper
            # crashed without recovering), re-create + restart the transcriber
            # for that role so the user gets transcription back without
            # restarting the daemon. Without this, _broadcast_dead notifies
            # the GUI but nothing actually retries — the role's pipe stays
            # dark for the rest of the meeting.
            _health_stop = threading.Event()

            def _transcriber_health_monitor() -> None:
                while not self._stop_event.is_set() and not _health_stop.is_set():
                    if _health_stop.wait(10):
                        return
                    if self._stop_event.is_set():
                        return
                    for role in ("self", "other"):
                        attr = f"_{role}_transcriber"
                        t = getattr(self, attr, None)
                        if t is None:
                            continue
                        thread = getattr(t, "_thread", None)
                        if thread is None or thread.is_alive():
                            continue
                        logger.warning(
                            "Transcriber health monitor: %s feed thread is dead — "
                            "attempting respawn", role,
                        )
                        try:
                            stream = (
                                capture.self_stream if role == "self"
                                else capture.other_stream
                            )
                            buf = self._self_buffer if role == "self" else self._other_buffer
                            # Stop the corpse cleanly before swapping in a new one.
                            try:
                                t.stop()
                            except Exception as exc:
                                logger.warning(
                                    "Health monitor: stop on dead %s failed: %s",
                                    role, exc,
                                )
                            new_t = create_transcriber(
                                audio_capture=stream,
                                transcript_buffer=buf,
                                deepgram_api_key=self._config.deepgram_api_key,
                                transcription_language=self._config.transcription_language,
                                preferred_transcriber=self._config.preferred_transcriber,
                                whisper_host=self._config.whisper_host,
                                diarize=(
                                    self._config.deepgram_diarize_self
                                    if role == "self"
                                    else self._config.deepgram_diarize_other
                                ),
                            )
                            if new_t is None:
                                logger.error(
                                    "Health monitor: %s transcriber respawn FAILED — "
                                    "no transcriber available", role,
                                )
                                continue
                            setattr(self, attr, new_t)
                            logger.info(
                                "Health monitor: %s transcriber respawned successfully",
                                role,
                            )
                        except Exception as exc:
                            logger.exception(
                                "Health monitor: respawn of %s transcriber crashed: %s",
                                role, exc,
                            )

            health_thread = threading.Thread(
                target=_transcriber_health_monitor,
                daemon=True,
                name="transcriber-health-monitor",
            )
            health_thread.start()

            # Stream every finalized sentence to .live.txt as `[MM:SS] ROLE: text`.
            # Both transcribers fan out through SentenceBuffer's listener hook;
            # the writer serializes the cross-thread file access.
            live_writer = LiveTranscriptWriter(live_transcript_path, t0=time.monotonic())
            self_listener = lambda s, sp: live_writer.append("SELF", s, sp)
            other_listener = lambda s, sp: live_writer.append("OTHER", s, sp)
            self._self_buffer.add_sentence_listener(self_listener)
            self._other_buffer.add_sentence_listener(other_listener)

            # probe_interval=20s, not 2s: probing tears down the mic stream for
            # ~300ms (pause + settle + resume), so a 2s interval punched audible
            # holes in the mic track every couple seconds. 20s caps loss at ~1.5%
            # and end-of-meeting detection still completes within ~20s of the
            # other app releasing the mic — silence detection covers the rest.
            mic_probe = MicProbe(probe_interval=20.0, settle_time=0.3, required_off_count=1)
            is_manual = stop_event is not None

            while not self._stop_event.is_set():
                # Manual session: check stop_event
                if is_manual and stop_event.is_set():
                    logger.info("Manual session stopped by user")
                    break

                audio = capture.get_audio(timeout=0.5)
                if audio is None:
                    continue

                audio_flat = audio[:, 0] if audio.ndim > 1 else audio

                # Write to MP3 — pass the FLAT 1-D array. Passing the raw
                # (possibly 2-D) ndarray here doubled the byte count fed to
                # ffmpeg's stdin and corrupted the bitstream, eventually
                # crashing the encoder pipe.
                if recording.is_active:
                    recording.write(audio_flat)

                # MicProbe: only end auto sessions — manual sessions ignore mic release
                if not is_manual and mic_probe.should_probe(time.time()):
                    if mic_probe.probe(capture):
                        logger.info("MicProbe: meeting app released mic — ending session")
                        break

        except Exception:
            # logger.exception preserves the traceback — for the master
            # session loop, swallowing the trace turns "the daemon stopped
            # transcribing" reports into pure guessing. The traceback points
            # straight at the offending line.
            logger.exception("Session error — _run_active_session terminated abnormally")
        finally:
            # Stop the transcriber health monitor first so it doesn't try to
            # respawn a transcriber while we're tearing them down.
            try:
                _health_stop.set()
            except NameError:
                # Session blew up before we got far enough to declare it.
                pass
            if proactive is not None:
                proactive.stop()
                self._self_buffer.remove_sentence_listener(proactive.on_sentence)
                app_state.proactive_monitor = None
            if topic_worker is not None:
                try:
                    topic_worker.stop()
                except Exception as exc:
                    logger.warning("topic_worker stop failed: %s", exc)
                app_state.topic_worker = None
            # Clear any attached past Claude Code conversation so the next
            # meeting starts clean.
            app_state.attached_conversation = None
            if self._self_transcriber is not None:
                self._self_transcriber.stop()
                self._self_transcriber = None
            if self._other_transcriber is not None:
                self._other_transcriber.stop()
                self._other_transcriber = None

            capture.stop()
            self._capture = None
            app_state.audio_active = False

            # Detach the streaming writer and release the file handle. Every
            # finalized sentence has already been written by the listener.
            if self_listener is not None:
                self._self_buffer.remove_sentence_listener(self_listener)
            if other_listener is not None:
                self._other_buffer.remove_sentence_listener(other_listener)
            if live_writer is not None:
                try:
                    live_writer.close()
                except Exception as exc:
                    logger.warning("live_writer close failed: %s", exc)

            # Finalize MP3
            if recording is not None and recording.is_active:
                saved_path, duration = recording.stop()
                if saved_path:
                    logger.info("Recording saved: %s (%.1fs)", saved_path.name, duration)

            # Persist extracted tasks alongside the recording
            tasks_target = saved_path if saved_path is not None else live_transcript_path
            if tasks_target is not None and app_state.session_tasks:
                try:
                    from meeting_helper import tasks as tasks_mod
                    tasks_path = tasks_target.with_suffix(".tasks.json")
                    tasks_mod.save_tasks(tasks_path, list(app_state.session_tasks))
                    logger.info("Tasks saved: %s (%d items)",
                                tasks_path.name, len(app_state.session_tasks))
                except Exception as exc:
                    logger.warning("Failed to save tasks: %s", exc)
            app_state.session_tasks = []

            self._self_buffer.clear()
            self._other_buffer.clear()
            # Auto-summarize on meeting end if enabled. Submitted to the
            # daemon's asyncio loop so the meeting-end thread is never
            # blocked on the LLM call. The synchronous fallback only fires
            # in test contexts where there is no daemon loop.
            summary_text = ""
            if self._config.auto_summarize_on_end:
                have_transcript = (
                    live_transcript_path is not None
                    and live_transcript_path.exists()
                    and live_transcript_path.stat().st_size > 0
                )
                if not have_transcript:
                    # Visibility: explain why nothing happens, since the
                    # alternative is a silent no-op the user can't diagnose.
                    logger.info(
                        "Auto-summary enabled but skipped — no usable live transcript (%s)",
                        live_transcript_path if live_transcript_path is not None else "none",
                    )
                else:
                    try:
                        import asyncio as _asyncio
                        import concurrent.futures as _cf
                        from meeting_helper.ai.client import summarize_transcript
                        from meeting_helper.state import state as _app_state

                        transcript_name = live_transcript_path.name
                        loop = _app_state.asyncio_loop
                        if loop is not None and loop.is_running():
                            # Run the summary on the daemon's loop but BLOCK this
                            # meeting-end thread until it finishes — the caller
                            # restarts the daemon (os._exit) the moment we return,
                            # so a fire-and-forget task would be killed before it
                            # writes .summary.txt.
                            logger.info(
                                "Auto-summary started for %s — holding shutdown until done",
                                transcript_name,
                            )
                            _app_state.summarizing = True
                            try:
                                _asyncio.run_coroutine_threadsafe(
                                    _broadcast_summarizing(True, transcript_name), loop
                                )
                            except Exception:
                                pass
                            fut = _asyncio.run_coroutine_threadsafe(
                                summarize_transcript(
                                    str(live_transcript_path), self._config
                                ),
                                loop,
                            )
                            try:
                                summary_text = fut.result(timeout=SUMMARY_WAIT_SEC) or ""
                                logger.info("Auto-summary complete for %s", transcript_name)
                            except _cf.TimeoutError:
                                logger.warning(
                                    "Auto-summary still running after %.0fs for %s — "
                                    "proceeding with shutdown; re-run via POST /summarize if it didn't finish",
                                    SUMMARY_WAIT_SEC, transcript_name,
                                )
                            except Exception as exc:
                                logger.warning(
                                    "Auto-summary failed for %s: %s",
                                    transcript_name, exc, exc_info=True,
                                )
                            finally:
                                _app_state.summarizing = False
                                try:
                                    _asyncio.run_coroutine_threadsafe(
                                        _broadcast_summarizing(False, transcript_name), loop
                                    )
                                except Exception:
                                    pass
                        else:
                            # Test context only — no daemon loop. Run synchronously
                            # so tests can observe the side effect.
                            try:
                                summary_text = _asyncio.run(
                                    summarize_transcript(
                                        str(live_transcript_path), self._config
                                    )
                                ) or ""
                                logger.info("Auto-summary complete for %s", transcript_name)
                            except Exception as exc:
                                logger.warning(
                                    "Auto-summary failed for %s: %s",
                                    transcript_name, exc, exc_info=True,
                                )
                    except Exception as exc:
                        logger.warning(
                            "Auto-summary failed (scheduling): %s", exc, exc_info=True,
                        )

            # Auto-name speakers on meeting end. Runs after auto-summary so the
            # AI naming call doesn't compete with summary latency, and before
            # auto-rename so the renamer can use real names from the
            # substituted summary.
            if (
                self._config.auto_name_speakers_on_end
                and saved_path is not None
                and live_transcript_path is not None
            ):
                try:
                    import asyncio as _asyncio
                    import concurrent.futures as _cf
                    from meeting_helper.state import state as _app_state

                    loop = _app_state.asyncio_loop
                    if loop is not None and loop.is_running():
                        fut = _asyncio.run_coroutine_threadsafe(
                            _maybe_auto_name_speakers(
                                saved_path, live_transcript_path, self._config,
                            ),
                            loop,
                        )
                        try:
                            fut.result(timeout=NAME_SPEAKERS_WAIT_SEC)
                        except _cf.TimeoutError:
                            logger.warning(
                                "Auto-name-speakers timed out after %.0fs",
                                NAME_SPEAKERS_WAIT_SEC,
                            )
                        except Exception as exc:
                            logger.warning(
                                "Auto-name-speakers failed: %s", exc, exc_info=True,
                            )
                    else:
                        # Test context — no daemon loop.
                        try:
                            _asyncio.run(
                                _maybe_auto_name_speakers(
                                    saved_path, live_transcript_path, self._config,
                                )
                            )
                        except Exception as exc:
                            logger.warning(
                                "Auto-name-speakers failed: %s", exc, exc_info=True,
                            )
                except Exception as exc:
                    logger.warning(
                        "Auto-name-speakers (scheduling): %s", exc, exc_info=True,
                    )

            # Auto-rename on meeting end if enabled. Uses the summary when we
            # have one (cheaper, more signal-dense), falls back to the live
            # transcript otherwise. Silently skipped if no AI provider key is
            # configured — the user opted into the feature but can't use it
            # right now, and we don't want to spam errors.
            if self._config.auto_rename_on_end and saved_path is not None:
                from meeting_helper import speakers as _speakers
                sidecar = _speakers.speakers_path_for(saved_path)
                names = _speakers.read_speaker_map(sidecar).names
                summary_for_rename = (
                    _speakers.apply_speaker_map(summary_text, names)
                    if names else summary_text
                )
                final_mp3 = self._maybe_auto_rename(
                    saved_path, live_transcript_path, summary_for_rename,
                )
                if final_mp3 is not None:
                    saved_path = final_mp3

            # Auto-add to KB: once a summary exists on disk (post-rename), add
            # its filename to the workspace's kb_artifacts so future queries
            # can retrieve from it. Skipped silently if there's no summary —
            # nothing to index, no need to nag the user.
            if self._config.auto_add_to_kb and saved_path is not None:
                self._maybe_auto_add_to_kb(saved_path)

            self._on_meeting_end(saved_path)
