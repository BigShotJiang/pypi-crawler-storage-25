"""Meeting Helper — AI meeting assistant for macOS."""

__version__ = "4.1.7"
