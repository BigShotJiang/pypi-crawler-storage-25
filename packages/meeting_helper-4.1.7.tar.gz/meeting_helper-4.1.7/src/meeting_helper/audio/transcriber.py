"""Deepgram streaming transcriber (primary) with local Whisper fallback.

CRITICAL: Must be imported only after daemonize() — same as capture.py.
"""

from __future__ import annotations

import logging
import threading
import time
from typing import TYPE_CHECKING, Optional

import numpy as np

if TYPE_CHECKING:
    from meeting_helper.audio.capture import CombinedAudioCapture
    from meeting_helper.buffer import SentenceBuffer

logger = logging.getLogger(__name__)

SAMPLE_RATE = 16000


def _schedule_threadsafe(coro, loop, label: str) -> None:
    """Schedule *coro* on *loop* from a non-asyncio thread, with a done
    callback that surfaces exceptions to the log instead of swallowing them.

    `asyncio.run_coroutine_threadsafe` returns a `concurrent.futures.Future`
    whose exception is silently discarded if nobody calls `.result()` or
    `.exception()`. That's exactly what was happening across the transcription
    pipeline — broadcast errors, dead asyncio loops, JSON encoding faults
    all vanished without trace. This wrapper closes that hole.
    """
    import asyncio

    fut = asyncio.run_coroutine_threadsafe(coro, loop)

    def _on_done(f):
        try:
            exc = f.exception()
        except Exception:
            return
        if exc is not None:
            logger.warning("threadsafe coro %s failed: %s", label, exc)

    fut.add_done_callback(_on_done)


class DeepgramTranscriber:
    """Streams audio to Deepgram and appends final transcripts to the SentenceBuffer."""

    def __init__(
        self,
        audio_capture: CombinedAudioCapture,
        transcript_buffer: SentenceBuffer,
        api_key: str,
        language: str = "en",
        diarize: bool = False,
    ) -> None:
        self._capture = audio_capture
        self._buffer = transcript_buffer
        self._language = language
        self._api_key = api_key
        self._diarize = diarize
        self._stop_event = threading.Event()
        self._thread: Optional[threading.Thread] = None
        self._connection = None
        self._last_interim: Optional[str] = None
        self._last_transcript_time: float = 0.0
        # Reconnect signaling. The feed-loop thread owns reconnect — _on_error
        # and _on_close just set this Event so we never spawn a second thread
        # racing the live feed loop. Single-flight by construction.
        self._needs_reconnect = threading.Event()
        self._reconnect_max_attempts = 10

    def _on_message(self, sender, result=None, **kwargs):
        from collections import Counter
        try:
            if result is None:
                return
            self._last_transcript_time = time.time()
            alt = result.channel.alternatives[0]
            sentence = alt.transcript
            if not sentence:
                return

            from meeting_helper.state import state
            loop = state.asyncio_loop

            speaker: int | None = None
            if self._diarize and result.is_final:
                words = getattr(alt, "words", None) or []
                speakers = [getattr(w, "speaker", None) for w in words]
                speakers = [s for s in speakers if s is not None]
                if speakers:
                    speaker = Counter(speakers).most_common(1)[0][0]

            if result.is_final:
                logger.info(
                    "Deepgram final (speaker=%s): %s",
                    speaker, sentence[:120],
                )
                self._last_interim = None
                self._buffer.append_final(sentence, speaker=speaker)
                if loop is not None:
                    _schedule_threadsafe(
                        self._broadcast_transcript(
                            sentence, interim=False, role=self._buffer.role, speaker=speaker,
                        ),
                        loop,
                        f"broadcast_transcript(final, role={self._buffer.role})",
                    )
            else:
                self._last_interim = sentence
                self._buffer.set_interim(sentence)
                if loop is not None:
                    _schedule_threadsafe(
                        self._broadcast_transcript(
                            sentence, interim=True, role=self._buffer.role, speaker=None,
                        ),
                        loop,
                        f"broadcast_transcript(interim, role={self._buffer.role})",
                    )
        except Exception as exc:
            # Include payload shape so a future Deepgram SDK schema change is
            # diagnosable from logs instead of guesswork.
            result_type = type(result).__name__ if result is not None else "None"
            logger.warning(
                "Deepgram message parse error (result type=%s, role=%s): %s",
                result_type, self._buffer.role, exc,
            )

    @staticmethod
    async def _broadcast_transcript(
        sentence: str,
        interim: bool = False,
        role: str = "self",
        speaker: int | None = None,
    ) -> None:
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({
                "type": "transcript",
                "text": sentence,
                "interim": interim,
                "role": role,
                "speaker": speaker,
            })
        except Exception as exc:
            logger.warning("Broadcast error: %s", exc)

    def _on_utterance_end(self, sender, utterance_end=None, **kwargs):
        try:
            last = self._last_interim
            if last:
                logger.info("Deepgram utterance_end flush: %s", last[:80])
                self._buffer.append_final(last, speaker=None)
                from meeting_helper.state import state
                loop = state.asyncio_loop
                if loop is not None:
                    _schedule_threadsafe(
                        self._broadcast_transcript(
                            last, interim=False, role=self._buffer.role, speaker=None,
                        ),
                        loop,
                        f"broadcast_transcript(utterance_end, role={self._buffer.role})",
                    )
                self._last_interim = None
        except Exception as exc:
            logger.warning("Deepgram utterance_end error: %s", exc)

    def _on_speech_started(self, sender, speech_started=None, **kwargs):
        from meeting_helper.state import state
        loop = state.asyncio_loop
        if loop is not None:
            _schedule_threadsafe(
                self._broadcast_speech_started(), loop, "broadcast_speech_started",
            )

    @staticmethod
    async def _broadcast_speech_started() -> None:
        try:
            from meeting_helper.server.websocket import broadcast
            await broadcast({"type": "speech_started"})
        except Exception as exc:
            logger.debug("speech_started broadcast failed: %s", exc)

    def _on_error(self, sender, error=None, **kwargs):
        # Don't spawn a reconnect thread here — let the feed loop own reconnect.
        # _on_error and _on_close can both fire for the same drop; only one
        # signal is needed.
        logger.warning("Deepgram error event: %s (role=%s)", error, self._buffer.role)
        self._needs_reconnect.set()

    def _on_close(self, sender, close=None, **kwargs):
        logger.warning(
            "Deepgram connection closed (role=%s) — feed loop will reconnect",
            self._buffer.role,
        )
        self._needs_reconnect.set()

    def _reconnect_inline(self) -> bool:
        """Reconnect from inside the feed-loop thread. Returns True if the
        new connection is up; False if we gave up.

        Runs in the same thread as _feed_loop, which guarantees we never have
        two feed loops alive at once: the calling _feed_loop is paused here
        and only resumes (or returns) after this finishes.
        """
        attempts = 0
        while not self._stop_event.is_set() and attempts < self._reconnect_max_attempts:
            attempts += 1
            delay = min(2 ** attempts, 30)
            logger.info(
                "Deepgram reconnecting in %ds (attempt %d/%d, role=%s)",
                delay, attempts, self._reconnect_max_attempts, self._buffer.role,
            )
            # Interruptible sleep — stop() wakes us immediately instead of
            # waiting up to 30s.
            if self._stop_event.wait(delay):
                return False

            # Tear down whatever's left of the old connection.
            if self._connection is not None:
                try:
                    self._connection.finish()
                except Exception as exc:
                    logger.warning(
                        "Deepgram finish-before-reconnect failed (role=%s): %s",
                        self._buffer.role, exc,
                    )
                self._connection = None

            if self._start_connection():
                self._last_transcript_time = time.time()
                logger.info(
                    "Deepgram reconnected (attempt %d, role=%s)",
                    attempts, self._buffer.role,
                )
                return True

        logger.error(
            "Deepgram reconnect failed after %d attempts (role=%s) — transcription is dead for this stream",
            attempts, self._buffer.role,
        )
        # Notify the GUI so the user sees something is wrong instead of a
        # green "Deepgram" pill on a dead pipe.
        self._broadcast_dead()
        return False

    def _broadcast_dead(self) -> None:
        try:
            from meeting_helper.state import state
            loop = state.asyncio_loop
            if loop is None:
                return
            from meeting_helper.server.websocket import broadcast

            async def _send():
                try:
                    await broadcast({
                        "type": "transcriber_dead",
                        "role": self._buffer.role,
                        "reason": "reconnect_exhausted",
                    })
                except Exception as exc:
                    logger.warning("transcriber_dead broadcast failed: %s", exc)

            _schedule_threadsafe(
                _send(), loop, f"broadcast_transcriber_dead(role={self._buffer.role})",
            )
        except Exception as exc:
            logger.warning("transcriber_dead dispatch failed: %s", exc)

    def _feed_loop(self):
        last_keepalive = time.time()
        self._last_transcript_time = time.time()
        _WATCHDOG_TIMEOUT = 60

        while not self._stop_event.is_set():
            # Reconnect signal handling — runs in this thread, so the old
            # session is implicitly drained before a new one starts.
            if self._needs_reconnect.is_set():
                self._needs_reconnect.clear()
                if not self._reconnect_inline():
                    return  # gave up; feed loop exits cleanly

            chunk = self._capture.get_transcriber_audio(timeout=0.01)
            if self._connection is None:
                # Brief interruptible wait — stop() can break us out.
                if self._stop_event.wait(0.1):
                    return
                continue

            if chunk is None:
                if time.time() - last_keepalive > 8:
                    try:
                        self._connection.keep_alive()
                        last_keepalive = time.time()
                    except Exception as exc:
                        logger.warning(
                            "Deepgram keep_alive failed (role=%s) — connection likely stale: %s",
                            self._buffer.role, exc,
                        )
                        self._needs_reconnect.set()
                continue

            try:
                pcm = (chunk * 32767).astype(np.int16).tobytes()
                self._connection.send(pcm)
                last_keepalive = time.time()
            except Exception as exc:
                logger.warning("Deepgram send error (role=%s): %s", self._buffer.role, exc)
                self._needs_reconnect.set()
                continue  # drive reconnect on next iteration

            now = time.time()
            silence_duration = now - self._last_transcript_time
            if silence_duration > _WATCHDOG_TIMEOUT:
                # last_keepalive is refreshed on every successful send AND
                # every successful keep_alive (every 8 s during silence). So
                # if it's recent the connection is genuinely healthy and the
                # silence is "everyone is muted", not "WS is dead". Don't
                # burn a reconnect attempt on that — long quiet meetings
                # used to drain all 10 attempts every 60 s and leave the
                # transcriber permanently dead.
                keepalive_age = now - last_keepalive
                if keepalive_age < 15:
                    logger.debug(
                        "Deepgram watchdog: %ds silence but keep_alive %.1fs "
                        "ago — connection healthy, suppressing reconnect (role=%s)",
                        int(silence_duration), keepalive_age, self._buffer.role,
                    )
                    # Reset so we don't keep checking every tick.
                    self._last_transcript_time = now
                else:
                    logger.warning(
                        "Deepgram watchdog: %ds silence AND keep_alive %.1fs "
                        "stale — reconnecting (role=%s)",
                        int(silence_duration), keepalive_age, self._buffer.role,
                    )
                    self._last_transcript_time = now
                    self._needs_reconnect.set()

    def _start_connection(self) -> bool:
        try:
            import ssl
            import certifi
            import os
            os.environ.setdefault("SSL_CERT_FILE", certifi.where())
            os.environ.setdefault("REQUESTS_CA_BUNDLE", certifi.where())

            from deepgram import DeepgramClient, LiveTranscriptionEvents, LiveOptions

            dg = DeepgramClient(api_key=self._api_key)
            conn = dg.listen.live.v("1")
            conn.on(LiveTranscriptionEvents.Transcript, self._on_message)
            conn.on(LiveTranscriptionEvents.Error, self._on_error)
            try:
                conn.on(LiveTranscriptionEvents.Close, self._on_close)
                conn.on(LiveTranscriptionEvents.SpeechStarted, self._on_speech_started)
                conn.on(LiveTranscriptionEvents.UtteranceEnd, self._on_utterance_end)
            except Exception as exc:
                # If Close registration fails the watchdog still triggers
                # reconnect on silence — but we'll never know about it. Log
                # so SDK upgrades that rename events are diagnosable.
                logger.warning(
                    "Deepgram optional event registration failed (SDK version mismatch?): %s",
                    exc,
                )

            nova3_langs = {
                "en", "es", "fr", "de", "it", "pt", "nl", "hi", "ja",
                "ko", "zh", "sv", "da", "no", "fi", "pl", "ru", "tr",
                "uk", "id", "ms", "th", "vi", "cs", "ro", "hu", "el",
                "bg", "hr", "sk", "sl", "sr", "ca", "ta", "te",
            }
            model = "nova-3" if self._language in nova3_langs else "nova-2"
            logger.info(
                "Deepgram model: %s (language: %s, diarize: %s)",
                model, self._language, self._diarize,
            )

            options = LiveOptions(
                model=model,
                language=self._language,
                smart_format=False,
                no_delay=True,
                interim_results=True,
                endpointing=10,
                utterance_end_ms=1000,
                vad_events=True,
                encoding="linear16",
                channels=1,
                sample_rate=SAMPLE_RATE,
                diarize=self._diarize,
                # Diarization is only meaningful with punctuation — speaker
                # boundaries align to utterance ends. Off when diarize is off
                # so the SELF stream keeps its current latency profile.
                punctuate=self._diarize,
            )

            ok = conn.start(options)
            if not ok:
                logger.error("Deepgram connection failed to start")
                return False

            self._connection = conn
            logger.info("Deepgram connection established")
            return True

        except Exception as exc:
            logger.error("Deepgram connection error: %s", exc)
            return False

    def start(self) -> bool:
        self._stop_event.clear()
        self._needs_reconnect.clear()
        if not self._start_connection():
            return False
        self._thread = threading.Thread(target=self._feed_loop, daemon=True)
        self._thread.start()
        logger.info("Deepgram streaming transcriber started (role=%s)", self._buffer.role)
        return True

    def stop(self) -> None:
        self._stop_event.set()
        # Wakes any _stop_event.wait(delay) inside _reconnect_inline immediately.
        if self._connection:
            try:
                self._connection.finish()
            except Exception as exc:
                logger.warning(
                    "Deepgram finish (stop, role=%s) failed: %s",
                    self._buffer.role, exc,
                )
            self._connection = None
        if self._thread:
            # 5 s is plenty: _stop_event.wait(delay) inside _reconnect_inline
            # wakes immediately on stop, and the feed loop's next iteration
            # exits via the top-level `while not self._stop_event.is_set()`.
            # The old 35 s timeout was leftover from when reconnect used
            # time.sleep, which couldn't be interrupted. With 2 transcribers
            # stopped sequentially, that meant 70 s teardown blocking the
            # encoder finalize and risking truncated MP3s.
            self._thread.join(timeout=5.0)
            if self._thread.is_alive():
                logger.warning(
                    "Deepgram feed loop did not exit within 5s (role=%s) — "
                    "may indicate a stuck network call in _start_connection",
                    self._buffer.role,
                )


class WhisperTranscriber:
    """VAD-based local transcriber using faster-whisper.

    Instead of fixed-time chunks, uses energy-based voice activity detection:
    - Accumulates audio while speech is detected
    - Commits and transcribes immediately when silence follows speech (~0.4s latency)
    - Shows interim text every ~1s during long speech segments
    - Uses 'base' model for good accuracy/speed balance on CPU

    Hardening:
    - Interim transcription is bounded to the LAST INTERIM_WINDOW_SEC of audio
      (not the full growing buffer), so long uninterrupted speech can't make
      every interim slower than the previous one and fall behind real time.
    - The worker loop is wrapped in an outer respawn supervisor: any uncaught
      exception logs + restarts after a backoff, instead of silently killing
      the daemon thread (which presented as "Whisper just stopped").
    - A watchdog logs a warning when no audio chunks arrive for a while —
      that signals an upstream capture stall, not a Whisper bug.
    """

    # VAD tuning
    SPEECH_RMS_THRESHOLD = 0.0015  # RMS amplitude to consider as speech
    SILENCE_COMMIT_SEC = 0.35      # silence duration to commit a segment
    MAX_SEGMENT_SEC = 10.0         # force commit after this long regardless
    FAST_INTERIM_SEC = 0.5         # show a quick preview after this much speech
    INTERIM_SEC = 1.0              # then refresh interim every this many seconds
    MIN_SEGMENT_SEC = 0.3          # ignore segments shorter than this (noise)
    INTERIM_WINDOW_SEC = 3.0       # cap interim transcribe to last N sec of audio
    WATCHDOG_NO_AUDIO_SEC = 30.0   # warn if no audio chunks arrive for this long
    RESPAWN_BACKOFF_SEC = 2.0      # wait before restarting after a crash

    def __init__(
        self,
        audio_capture: "CombinedAudioCapture",
        transcript_buffer: "SentenceBuffer",
        model_name: str = "base",
        language: str = "en",
    ) -> None:
        self._capture = audio_capture
        self._buffer = transcript_buffer
        self._model_name = model_name
        self._language = language
        self._model = None
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()

    def _load_model(self):
        if self._model is None:
            logger.info("Loading faster-whisper model '%s'...", self._model_name)
            from meeting_helper.ssl_fix import patch_ssl
            patch_ssl()
            from faster_whisper import WhisperModel
            self._model = WhisperModel(self._model_name, device="cpu", compute_type="int8")
            logger.info("faster-whisper model '%s' loaded", self._model_name)
        return self._model

    def _transcribe(self, audio: np.ndarray) -> str:
        # condition_on_previous_text=False: with True, faster-whisper feeds
        # earlier output back as a prompt, which over a long meeting causes
        # repetition / hallucination loops where the model echoes the same
        # phrase and stops emitting new content.
        try:
            model = self._load_model()
            segments, _ = model.transcribe(
                audio,
                language=self._language if self._language != "auto" else None,
                beam_size=3,
                condition_on_previous_text=False,
                no_speech_threshold=0.45,
            )
            return " ".join(seg.text.strip() for seg in segments).strip()
        except Exception as exc:
            logger.error("Whisper error: %s", exc)
            return ""

    def _broadcast(self, text: str, interim: bool = False) -> None:
        from meeting_helper.state import state
        loop = state.asyncio_loop
        if loop is not None:
            _schedule_threadsafe(
                DeepgramTranscriber._broadcast_transcript(text, interim=interim, role=self._buffer.role),
                loop,
                f"broadcast_transcript(whisper, interim={interim}, role={self._buffer.role})",
            )

    @staticmethod
    def _tail_audio(speech_chunks: list[np.ndarray], max_samples: int) -> np.ndarray:
        """Return the last `max_samples` samples across `speech_chunks`.

        Walking from the tail avoids concatenating the entire (possibly long)
        buffer just to slice the end off — interim transcribe is on the hot
        path during continuous speech.
        """
        collected: list[np.ndarray] = []
        remaining = max_samples
        for chunk in reversed(speech_chunks):
            if remaining <= 0:
                break
            if len(chunk) <= remaining:
                collected.append(chunk)
                remaining -= len(chunk)
            else:
                collected.append(chunk[-remaining:])
                remaining = 0
        return np.concatenate(list(reversed(collected))) if collected else np.array([], dtype=np.float32)

    def _commit(self, speech_chunks: list[np.ndarray]) -> None:
        """Transcribe and broadcast a completed speech segment."""
        audio = np.concatenate(speech_chunks)
        if len(audio) < int(self.MIN_SEGMENT_SEC * SAMPLE_RATE):
            return
        text = self._transcribe(audio)
        if text:
            logger.debug("Whisper final: %s", text[:80])
            self._buffer.append_final(text)
            self._broadcast(text, interim=False)

    def _run(self) -> None:
        silence_commit = int(self.SILENCE_COMMIT_SEC * SAMPLE_RATE)
        max_segment = int(self.MAX_SEGMENT_SEC * SAMPLE_RATE)
        fast_interim = int(self.FAST_INTERIM_SEC * SAMPLE_RATE)
        interim_interval = int(self.INTERIM_SEC * SAMPLE_RATE)
        interim_window = int(self.INTERIM_WINDOW_SEC * SAMPLE_RATE)

        speech_chunks: list[np.ndarray] = []
        speech_samples = 0
        silence_samples = 0
        last_interim_at = 0
        fast_interim_done = False
        last_chunk_time = time.time()
        watchdog_logged = False

        while not self._stop_event.is_set():
            chunk = self._capture.get_transcriber_audio(timeout=0.05)
            if chunk is None:
                # Capture stall watchdog — log once per dry spell so we know
                # whether silence means "no speech" vs "audio pipeline died".
                if not watchdog_logged and time.time() - last_chunk_time > self.WATCHDOG_NO_AUDIO_SEC:
                    logger.warning(
                        "Whisper watchdog: no audio chunks for %.0fs — capture pipeline may be stalled",
                        time.time() - last_chunk_time,
                    )
                    watchdog_logged = True
                continue

            last_chunk_time = time.time()
            watchdog_logged = False

            rms = float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2)))
            is_speech = rms > self.SPEECH_RMS_THRESHOLD

            if is_speech:
                speech_chunks.append(chunk)
                speech_samples += len(chunk)
                silence_samples = 0

                # Fast preview after FAST_INTERIM_SEC (first interim for short sentences)
                if not fast_interim_done and speech_samples >= fast_interim:
                    text = self._transcribe(self._tail_audio(speech_chunks, interim_window))
                    if text:
                        self._buffer.set_interim(text)
                        self._broadcast(text, interim=True)
                    last_interim_at = speech_samples
                    fast_interim_done = True

                # Regular interim every INTERIM_SEC after the fast one. Only
                # transcribe the tail (last INTERIM_WINDOW_SEC) so long monologues
                # don't make each interim slower than the previous one.
                elif fast_interim_done and speech_samples - last_interim_at >= interim_interval:
                    text = self._transcribe(self._tail_audio(speech_chunks, interim_window))
                    if text:
                        self._buffer.set_interim(text)
                        self._broadcast(text, interim=True)
                    last_interim_at = speech_samples

                # Force commit on very long segments
                if speech_samples >= max_segment:
                    self._commit(speech_chunks)
                    speech_chunks, speech_samples, silence_samples, last_interim_at, fast_interim_done = [], 0, 0, 0, False

            elif speech_chunks:
                # Silence after speech — keep accumulating silence for context
                speech_chunks.append(chunk)
                silence_samples += len(chunk)

                if silence_samples >= silence_commit:
                    self._commit(speech_chunks)
                    speech_chunks, speech_samples, silence_samples, last_interim_at, fast_interim_done = [], 0, 0, 0, False

        # Flush on stop
        if speech_chunks:
            self._commit(speech_chunks)

    def _supervised_run(self) -> None:
        """Outer wrapper that keeps the worker alive across crashes.

        Without this, an uncaught exception inside `_run` silently kills the
        daemon thread and the GUI keeps showing "Whisper" while no transcripts
        flow — the symptom you saw as "Whisper stops recording after a while".
        """
        while not self._stop_event.is_set():
            try:
                self._run()
                return  # clean exit (stop_event set)
            except Exception:
                logger.exception("Whisper worker crashed — restarting after %.1fs", self.RESPAWN_BACKOFF_SEC)
                if self._stop_event.wait(self.RESPAWN_BACKOFF_SEC):
                    return

    def start(self) -> bool:
        try:
            import faster_whisper  # noqa: F401
        except ImportError:
            logger.warning("faster-whisper not installed — no transcription available.")
            return False
        self._stop_event.clear()
        self._thread = threading.Thread(target=self._supervised_run, daemon=True)
        self._thread.start()
        logger.info("Whisper VAD transcriber started (model=%s, silence_commit=%.2fs)",
                     self._model_name, self.SILENCE_COMMIT_SEC)
        return True

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5.0)


class RemoteWhisperTranscriber:
    """VAD-based transcriber that sends audio to a remote faster-whisper-server.

    Same VAD logic as WhisperTranscriber, but POSTs WAV audio to:
        POST {host}/v1/audio/transcriptions
    """

    SPEECH_RMS_THRESHOLD = 0.0015
    SILENCE_COMMIT_SEC   = 0.35
    MAX_SEGMENT_SEC      = 10.0
    FAST_INTERIM_SEC     = 0.5
    INTERIM_SEC          = 1.0
    MIN_SEGMENT_SEC      = 0.3
    INTERIM_WINDOW_SEC   = 3.0    # cap interim transcribe to last N sec of audio
    WATCHDOG_NO_AUDIO_SEC = 30.0  # warn if no audio chunks arrive for this long
    RESPAWN_BACKOFF_SEC  = 2.0    # wait before restarting after a crash

    def __init__(
        self,
        audio_capture: "CombinedAudioCapture",
        transcript_buffer: "SentenceBuffer",
        host: str,
        language: str = "en",
    ) -> None:
        self._capture = audio_capture
        self._buffer = transcript_buffer
        self._host = host.rstrip("/")
        self._language = language
        self._thread: Optional[threading.Thread] = None
        self._stop_event = threading.Event()
        self._conn = None

    def _get_conn(self):
        """Return a persistent HTTP connection, reconnecting if needed."""
        import http.client
        from urllib.parse import urlparse
        if self._conn is not None:
            return self._conn
        parsed = urlparse(self._host)
        self._conn = http.client.HTTPConnection(
            parsed.hostname, parsed.port or 8000, timeout=30,
        )
        return self._conn

    def _transcribe_remote(self, audio: np.ndarray) -> str:
        """Send audio to remote faster-whisper-server and return text."""
        import io
        import json
        import struct

        num_samples = len(audio)
        pcm = (audio * 32767).astype(np.int16)
        data_size = num_samples * 2
        wav_buf = io.BytesIO()
        wav_buf.write(b"RIFF")
        wav_buf.write(struct.pack("<I", 36 + data_size))
        wav_buf.write(b"WAVEfmt ")
        wav_buf.write(struct.pack("<IHHIIHH", 16, 1, 1, SAMPLE_RATE, SAMPLE_RATE * 2, 2, 16))
        wav_buf.write(b"data")
        wav_buf.write(struct.pack("<I", data_size))
        wav_buf.write(pcm.tobytes())
        wav_data = wav_buf.getvalue()

        boundary = "----WhisperBoundary"
        body = b""
        body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"file\"; filename=\"audio.wav\"\r\nContent-Type: audio/wav\r\n\r\n".encode()
        body += wav_data + b"\r\n"
        if self._language and self._language != "auto":
            body += f"--{boundary}\r\nContent-Disposition: form-data; name=\"language\"\r\n\r\n{self._language}\r\n".encode()
        body += f"--{boundary}--\r\n".encode()

        try:
            headers = {"Content-Type": f"multipart/form-data; boundary={boundary}"}

            for attempt in range(2):
                try:
                    conn = self._get_conn()
                    conn.request("POST", "/v1/audio/transcriptions", body=body, headers=headers)
                    resp = conn.getresponse()
                    break
                except Exception:
                    self._conn = None
                    if attempt == 1:
                        raise

            resp_data = resp.read()
            if resp.status != 200:
                logger.error("Remote whisper %d: %s", resp.status, resp_data[:200])
                return ""

            return json.loads(resp_data).get("text", "").strip()
        except Exception as exc:
            logger.error("Remote whisper error (%s): %s", self._host, exc)
            return ""

    def _broadcast(self, text: str, interim: bool = False) -> None:
        from meeting_helper.state import state
        loop = state.asyncio_loop
        if loop is not None:
            _schedule_threadsafe(
                DeepgramTranscriber._broadcast_transcript(text, interim=interim, role=self._buffer.role),
                loop,
                f"broadcast_transcript(remote_whisper, interim={interim}, role={self._buffer.role})",
            )

    def _commit(self, speech_chunks: list) -> None:
        audio = np.concatenate(speech_chunks)
        if len(audio) < int(self.MIN_SEGMENT_SEC * SAMPLE_RATE):
            return
        text = self._transcribe_remote(audio)
        if text:
            logger.debug("Remote Whisper final: %s", text[:80])
            self._buffer.append_final(text)
            self._broadcast(text, interim=False)

    def _run(self) -> None:
        silence_commit   = int(self.SILENCE_COMMIT_SEC * SAMPLE_RATE)
        max_segment      = int(self.MAX_SEGMENT_SEC * SAMPLE_RATE)
        fast_interim     = int(self.FAST_INTERIM_SEC * SAMPLE_RATE)
        interim_interval = int(self.INTERIM_SEC * SAMPLE_RATE)
        interim_window   = int(self.INTERIM_WINDOW_SEC * SAMPLE_RATE)

        speech_chunks: list = []
        speech_samples = 0
        silence_samples = 0
        last_interim_at = 0
        fast_interim_done = False
        last_chunk_time = time.time()
        watchdog_logged = False

        while not self._stop_event.is_set():
            chunk = self._capture.get_transcriber_audio(timeout=0.05)
            if chunk is None:
                if not watchdog_logged and time.time() - last_chunk_time > self.WATCHDOG_NO_AUDIO_SEC:
                    logger.warning(
                        "Remote-Whisper watchdog: no audio chunks for %.0fs — capture pipeline may be stalled",
                        time.time() - last_chunk_time,
                    )
                    watchdog_logged = True
                continue

            last_chunk_time = time.time()
            watchdog_logged = False

            rms = float(np.sqrt(np.mean(chunk.astype(np.float32) ** 2)))
            is_speech = rms > self.SPEECH_RMS_THRESHOLD

            if is_speech:
                speech_chunks.append(chunk)
                speech_samples += len(chunk)
                silence_samples = 0

                if not fast_interim_done and speech_samples >= fast_interim:
                    text = self._transcribe_remote(
                        WhisperTranscriber._tail_audio(speech_chunks, interim_window)
                    )
                    if text:
                        self._broadcast(text, interim=True)
                    last_interim_at = speech_samples
                    fast_interim_done = True

                elif fast_interim_done and speech_samples - last_interim_at >= interim_interval:
                    text = self._transcribe_remote(
                        WhisperTranscriber._tail_audio(speech_chunks, interim_window)
                    )
                    if text:
                        self._broadcast(text, interim=True)
                    last_interim_at = speech_samples

                if speech_samples >= max_segment:
                    self._commit(speech_chunks)
                    speech_chunks, speech_samples, silence_samples = [], 0, 0
                    last_interim_at, fast_interim_done = 0, False

            elif speech_chunks:
                speech_chunks.append(chunk)
                silence_samples += len(chunk)

                if silence_samples >= silence_commit:
                    self._commit(speech_chunks)
                    speech_chunks, speech_samples, silence_samples = [], 0, 0
                    last_interim_at, fast_interim_done = 0, False

        if speech_chunks:
            self._commit(speech_chunks)

    def _supervised_run(self) -> None:
        """Outer wrapper that respawns the worker on uncaught exceptions.

        Same rationale as `WhisperTranscriber._supervised_run` — without this
        a transient HTTP/parsing error can kill the daemon thread silently.
        """
        while not self._stop_event.is_set():
            try:
                self._run()
                return
            except Exception:
                logger.exception(
                    "Remote-Whisper worker crashed — restarting after %.1fs",
                    self.RESPAWN_BACKOFF_SEC,
                )
                if self._stop_event.wait(self.RESPAWN_BACKOFF_SEC):
                    return

    def start(self) -> bool:
        try:
            import urllib.request
            urllib.request.urlopen(f"{self._host}/health", timeout=3)
        except Exception:
            try:
                import urllib.request
                urllib.request.urlopen(self._host, timeout=3)
            except Exception:
                logger.error("Remote whisper server not reachable at %s", self._host)
                return False

        self._stop_event.clear()
        self._thread = threading.Thread(target=self._supervised_run, daemon=True)
        self._thread.start()
        logger.info("Remote Whisper transcriber started (host=%s)", self._host)
        return True

    def stop(self) -> None:
        self._stop_event.set()
        if self._thread:
            self._thread.join(timeout=5.0)
        if self._conn:
            try:
                self._conn.close()
            except Exception:
                pass
            self._conn = None


def create_transcriber(
    audio_capture: CombinedAudioCapture,
    transcript_buffer: SentenceBuffer,
    deepgram_api_key: str = "",
    transcription_language: str = "en",
    preferred_transcriber: str = "",
    whisper_host: str = "",
    diarize: bool = False,
):
    """Return a started transcriber.

    preferred_transcriber: "" or "auto" = Deepgram if key, else Whisper.
    "deepgram" = force Deepgram (fails if no key). "whisper" = local or remote Whisper.
    whisper_host: if set, use remote faster-whisper-server instead of local model.
    diarize: passed through to Deepgram only; Whisper paths ignore it.
    """
    pref = preferred_transcriber.lower().strip()

    def _make_whisper():
        """Create the best available Whisper transcriber (remote or local)."""
        if whisper_host:
            t = RemoteWhisperTranscriber(audio_capture, transcript_buffer, host=whisper_host, language=transcription_language)
            if t.start():
                return t
            logger.warning("Remote whisper at %s failed, falling back to local", whisper_host)
        t = WhisperTranscriber(audio_capture, transcript_buffer, model_name="base", language=transcription_language)
        if t.start():
            return t
        return None

    # Force Whisper
    if pref == "whisper":
        t = _make_whisper()
        if t:
            return t
        logger.warning("Whisper failed to start")
        return None

    # Try Deepgram (auto or forced)
    if deepgram_api_key and pref != "whisper":
        t = DeepgramTranscriber(
            audio_capture, transcript_buffer, deepgram_api_key,
            language=transcription_language, diarize=diarize,
        )
        if t.start():
            return t
        if pref == "deepgram":
            logger.error("Deepgram forced but failed to start")
            return None
        logger.warning("Deepgram failed, falling back to Whisper")

    # Whisper fallback (auto mode)
    t = _make_whisper()
    if t:
        return t

    logger.warning("No transcriber available.")
    return None
