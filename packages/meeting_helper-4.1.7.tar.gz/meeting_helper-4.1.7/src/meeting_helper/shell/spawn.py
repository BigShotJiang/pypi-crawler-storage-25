"""Daemon spawn helper.

Used by both the shell supervisor (when the daemon dies unexpectedly) and
by the pywebview JS API (so the UI can recover from a dead daemon by
clicking Start). Both paths need to spawn a detached `meeting-helper
start` subprocess that captures stderr to a known log file.
"""
from __future__ import annotations

import os
import subprocess
import sys


DAEMON_SPAWN_LOG = "~/.meeting-helper-daemon-spawn.log"


def spawn_daemon() -> None:
    """Spawn a detached daemon, capturing stderr to a log so failures are visible."""
    log_path = os.path.expanduser(DAEMON_SPAWN_LOG)
    try:
        log_fh = open(log_path, "a")
    except Exception:
        log_fh = subprocess.DEVNULL  # type: ignore[assignment]
    subprocess.Popen(
        [sys.executable, "-m", "meeting_helper.cli", "start"],
        stdout=log_fh,
        stderr=log_fh,
        stdin=subprocess.DEVNULL,
        start_new_session=True,
    )
