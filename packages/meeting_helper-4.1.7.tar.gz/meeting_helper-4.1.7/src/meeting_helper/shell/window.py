"""Pywebview window factory for the shell process.

Single-window app. The window points at the daemon's local server. Dev mode
(`MH_SHELL_DEV=1`) can point it at a Next.js dev server on :3000 instead;
that branch lives in __main__.py, not here.

The window also exposes a small JS API (`window.pywebview.api.*`) so the
web UI can ask the shell to spawn a fresh daemon when one isn't running —
otherwise a user with a disconnected daemon would have no way back into
the app from inside the GUI itself.
"""

from __future__ import annotations

import logging

logger = logging.getLogger(__name__)


class ShellAPI:
    """Methods exposed to the web UI via ``window.pywebview.api.<name>()``.

    Stays tiny on purpose: the shell shouldn't grow a parallel control
    plane. The only thing the UI fundamentally cannot do via the daemon's
    HTTP API is start the daemon when it isn't running. Everything else
    flows through the daemon.
    """

    def spawn_daemon(self) -> dict:
        """Spawn a detached `meeting-helper start` subprocess.

        Returns ``{"ok": true}`` on success, ``{"ok": false, "error": ...}``
        on failure. The caller (UI) should then poll ``/health`` until the
        daemon answers.
        """
        from meeting_helper.shell.spawn import spawn_daemon

        try:
            spawn_daemon()
            return {"ok": True}
        except Exception as exc:  # noqa: BLE001 — caller handles
            logger.warning("ShellAPI.spawn_daemon failed: %s", exc)
            return {"ok": False, "error": str(exc)}


WINDOW_TITLE = "Meeting Helper"
# Match the old Flet GUI default so existing users get the same canvas size
# they're used to. Below 900x600 the toolbar starts wrapping awkwardly, so
# that's the floor we enforce as the minimum resizable size.
DEFAULT_SIZE = (1200, 800)
MIN_SIZE = (900, 600)


def _center_position(width: int, height: int) -> tuple[int, int] | None:
    """Return top-left (x, y) that centers a `width x height` window on the
    main screen, or None when AppKit isn't usable.

    pywebview happily accepts None-equivalent (no x/y) and falls back to its
    own positioning, so we keep this best-effort: any failure on the AppKit
    path just means we don't center, not that startup fails.
    """
    try:
        from AppKit import NSScreen  # type: ignore
        screen = NSScreen.mainScreen()
        if screen is None:
            return None
        frame = screen.frame()
        sw = int(frame.size.width)
        sh = int(frame.size.height)
        return ((sw - width) // 2, (sh - height) // 2)
    except Exception:
        return None


def create_window(url: str) -> "webview.Window":
    """Construct the main app window. Import is local so tests can stub it."""
    import webview

    width, height = DEFAULT_SIZE
    logger.info("Opening shell window at %s", url)
    kwargs: dict[str, object] = {
        "url": url,
        "width": width,
        "height": height,
        "min_size": MIN_SIZE,
        "resizable": True,
        # text_select=True lets the user copy/select transcript text in the
        # WebView.
        "text_select": True,
        # Expose the shell API on window.pywebview.api in the page.
        "js_api": ShellAPI(),
    }
    pos = _center_position(width, height)
    if pos is not None:
        kwargs["x"], kwargs["y"] = pos
    return webview.create_window(WINDOW_TITLE, **kwargs)
