"""Tests for the dynamic MCP passthrough tool builder."""

from __future__ import annotations

import pytest

from meeting_helper.chat.tools.mcp_passthrough import (
    _HAND_WRAPPED,
    _is_mutation,
    build_mcp_passthrough_tools,
)


class _StubMCPTool:
    def __init__(self, name: str, description: str = "", input_schema=None):
        self.name = name
        self.description = description
        self.inputSchema = input_schema or {"type": "object", "properties": {}}


class _StubListToolsResponse:
    def __init__(self, tools):
        self.tools = tools


class _StubSession:
    def __init__(self, tools):
        self._tools = tools
        self.calls: list[tuple[str, dict]] = []

    async def list_tools(self):
        return _StubListToolsResponse(self._tools)

    async def call_tool(self, name, args):
        self.calls.append((name, args))
        return {"name": name, "args": args}


class _StubMCP:
    """Mimics the bits of LocalTodoClient that mcp_passthrough touches."""

    def __init__(self, tools):
        self._session = _StubSession(tools)

    async def _ensure_started(self):
        return None

    async def call_tool(self, name, args=None):
        return await self._session.call_tool(name, args or {})


def test_mutation_prefix_classifier():
    assert _is_mutation("create_task") is True
    assert _is_mutation("update_doc") is True
    assert _is_mutation("delete_sprint") is True
    assert _is_mutation("start_sprint") is True
    assert _is_mutation("add_comment") is True
    assert _is_mutation("move_task_to_sprint") is True
    assert _is_mutation("remove_board_member") is True
    assert _is_mutation("revoke_board_invitation") is True
    assert _is_mutation("reorder_custom_fields") is True
    assert _is_mutation("rename_board_column_key") is True
    assert _is_mutation("replace_custom_field_option") is True
    assert _is_mutation("favorite_doc") is True
    assert _is_mutation("close_sprint") is True

    # Reads
    assert _is_mutation("list_boards") is False
    assert _is_mutation("get_doc") is False
    assert _is_mutation("search_tasks") is False
    assert _is_mutation("task_activity") is False
    assert _is_mutation("global_search") is False


@pytest.mark.asyncio
async def test_passthrough_skips_hand_wrapped_tools():
    """Tools we already expose under ``tickets.*`` must NOT get a duplicate
    ``mcp.<name>`` — the agent would get confused which to use."""
    tools = [
        _StubMCPTool("create_task"),  # hand-wrapped → skipped
        _StubMCPTool("get_task"),  # hand-wrapped → skipped
        _StubMCPTool("create_sprint"),  # not hand-wrapped → included
        _StubMCPTool("close_sprint"),  # not hand-wrapped → included
    ]
    out = await build_mcp_passthrough_tools(_StubMCP(tools))
    names = {t.name for t in out}
    assert names == {"mcp.create_sprint", "mcp.close_sprint"}
    # Sanity: hand-wrapped set really excludes these
    assert "create_task" in _HAND_WRAPPED
    assert "get_task" in _HAND_WRAPPED


@pytest.mark.asyncio
async def test_passthrough_marks_mutations():
    tools = [
        _StubMCPTool("create_sprint"),
        _StubMCPTool("start_sprint"),
        _StubMCPTool("list_my_invitations"),
        _StubMCPTool("get_board"),
    ]
    out = await build_mcp_passthrough_tools(_StubMCP(tools))
    by_name = {t.name: t for t in out}
    assert by_name["mcp.create_sprint"].is_mutation is True
    assert by_name["mcp.start_sprint"].is_mutation is True
    assert by_name["mcp.list_my_invitations"].is_mutation is False
    assert by_name["mcp.get_board"].is_mutation is False


@pytest.mark.asyncio
async def test_passthrough_preserves_jsonschema_verbatim():
    """The MCP returns proper JSON Schema. We must pass it through so
    Anthropic/Gemini accept it directly — re-translating breaks it."""
    schema = {
        "type": "object",
        "required": ["board_id", "name"],
        "properties": {
            "board_id": {"type": "integer", "description": "Target board."},
            "name": {"type": "string"},
            "goal": {"type": "string", "description": "Optional goal."},
        },
    }
    tools = [_StubMCPTool("create_sprint", "Create a sprint.", schema)]
    out = await build_mcp_passthrough_tools(_StubMCP(tools))
    assert len(out) == 1
    assert out[0].input_schema == schema  # verbatim
    assert out[0].description == "Create a sprint."


@pytest.mark.asyncio
async def test_passthrough_run_invokes_mcp_with_args():
    schema = {"type": "object", "properties": {"board_id": {"type": "integer"}}}
    stub = _StubMCP([_StubMCPTool("create_sprint", "d", schema)])
    out = await build_mcp_passthrough_tools(stub)
    result = await out[0].run({"board_id": 1, "name": "S1"}, {"local_todo": stub})
    assert result["status"] == "ok"
    assert stub._session.calls[-1] == ("create_sprint", {"board_id": 1, "name": "S1"})


@pytest.mark.asyncio
async def test_passthrough_surfaces_mcp_errors_as_tool_results():
    class _Broken:
        async def _ensure_started(self):
            return None

        async def call_tool(self, name, args=None):
            raise RuntimeError("mcp blew up")

    schema = {"type": "object", "properties": {}}
    out = await build_mcp_passthrough_tools(
        _StubMCP([_StubMCPTool("create_sprint", "d", schema)])
    )
    result = await out[0].run({}, {"local_todo": _Broken()})
    assert result["status"] == "error"
    assert "mcp blew up" in result["error"]


@pytest.mark.asyncio
async def test_passthrough_empty_when_mcp_missing():
    out = await build_mcp_passthrough_tools(None)
    assert out == []


@pytest.mark.asyncio
async def test_passthrough_empty_when_introspection_fails():
    class _NoListTools:
        async def _ensure_started(self):
            raise RuntimeError("transport closed")

    out = await build_mcp_passthrough_tools(_NoListTools())
    assert out == []


@pytest.mark.asyncio
async def test_provider_passes_jsonschema_through_unchanged():
    """The ClaudeProvider's _to_jsonschema must detect already-valid
    JSON Schema and pass it through. Otherwise the mcp.* tools' schemas
    would get re-translated into garbage."""
    from meeting_helper.chat.providers import _to_jsonschema

    jsonschema = {
        "type": "object",
        "required": ["board_id"],
        "properties": {
            "board_id": {"type": "integer"},
            "title": {"type": "string"},
        },
    }
    assert _to_jsonschema(jsonschema) == jsonschema

    # Compact still works.
    compact = {"q": "string", "limit": "integer?"}
    out = _to_jsonschema(compact)
    assert out["type"] == "object"
    assert out["properties"]["q"] == {"type": "string"}
    assert out["required"] == ["q"]


def test_sanitize_for_gemini_collapses_union_types():
    """Real MCP schemas declare ``"type": ["string", "number", "null"]`` for
    nullable union fields. Gemini's FunctionDeclaration enum rejects lists,
    so the sanitizer must collapse to a single non-null type before sending."""
    from meeting_helper.chat.providers import _sanitize_for_gemini

    schema = {
        "type": "object",
        "properties": {
            "parent_doc_id": {"type": ["string", "number", "null"], "description": "Doc"},
            "name": {"type": "string"},
            "tags": {
                "type": "array",
                "items": {"type": ["string", "null"]},
            },
            "nested": {
                "type": "object",
                "properties": {
                    "opt": {"type": ["integer", "null"]},
                },
            },
        },
    }
    out = _sanitize_for_gemini(schema)
    # Union collapsed to the first non-null entry.
    assert out["properties"]["parent_doc_id"]["type"] == "string"
    # Plain string field untouched.
    assert out["properties"]["name"]["type"] == "string"
    # Array items recursed.
    assert out["properties"]["tags"]["items"]["type"] == "string"
    # Nested object properties recursed.
    assert out["properties"]["nested"]["properties"]["opt"]["type"] == "integer"


def test_friendly_gemini_error_rewrites_common_codes():
    """We don't want the raw `{'error': {'code': 503, ...}}` dict bubbling
    up to the chat UI. The provider replaces it with a one-line readable
    message that names a concrete action the user can take."""
    from meeting_helper.chat.providers import _friendly_gemini_error

    cases = [
        ("503 UNAVAILABLE. {'error': {'code': 503, 'status': 'UNAVAILABLE'}}", "overloaded"),
        ("429 RESOURCE_EXHAUSTED rate limit", "rate limit"),
        ("404 NOT_FOUND model gemini-3.0-flash not found", "model not available"),
        ("401 PERMISSION_DENIED invalid api key", "rejected the API key"),
    ]
    for raw, expected_phrase in cases:
        friendly = _friendly_gemini_error(RuntimeError(raw))
        assert expected_phrase.lower() in str(friendly).lower(), (raw, friendly)


def test_is_transient_gemini_error_handles_common_cases():
    """Retry on 5xx + 429, fail-fast on 4xx auth/validation."""
    from meeting_helper.chat.providers import _is_transient_gemini_error

    assert _is_transient_gemini_error(RuntimeError("503 UNAVAILABLE high demand"))
    assert _is_transient_gemini_error(RuntimeError("429 quota exhausted"))
    assert _is_transient_gemini_error(RuntimeError("502 BAD_GATEWAY"))
    assert _is_transient_gemini_error(RuntimeError("model is overloaded, retry"))

    assert not _is_transient_gemini_error(RuntimeError("404 NOT_FOUND model x"))
    assert not _is_transient_gemini_error(RuntimeError("401 PERMISSION_DENIED"))
    assert not _is_transient_gemini_error(RuntimeError("400 INVALID_ARGUMENT bad schema"))


def test_sanitize_for_gemini_drops_oneof_anyof():
    """oneOf / anyOf siblings are not modelable in Gemini's function-call
    schema. Keep the first variant and drop the rest."""
    from meeting_helper.chat.providers import _sanitize_for_gemini

    schema = {
        "type": "object",
        "properties": {
            "ref": {
                "oneOf": [
                    {"type": "string"},
                    {"type": "integer"},
                ],
            },
        },
    }
    out = _sanitize_for_gemini(schema)
    assert "oneOf" not in out["properties"]["ref"]
    assert out["properties"]["ref"]["type"] == "string"
