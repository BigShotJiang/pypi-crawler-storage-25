import pytest

from meeting_helper.chat.tools.tickets import (
    build_tickets_add_comment,
    build_tickets_create_task,
    build_tickets_get,
    build_tickets_get_doc,
    build_tickets_list_boards,
    build_tickets_list_in_sprint,
    build_tickets_list_sprints,
    build_tickets_list_subtasks,
    build_tickets_list_task_docs,
    build_tickets_move_to_sprint,
    build_tickets_search,
    build_tickets_search_docs,
    build_tickets_task_activity,
    build_tickets_update_task,
)


class _FakeMCP:
    """Fake LocalTodoClient surface: real methods (search, list_boards,
    get, call_tool), records calls, returns canned data, can be made to
    raise on a given method.
    """

    def __init__(self):
        self.calls: list[tuple[str, tuple, dict]] = []
        self.search_result: list[dict] = []
        self.list_boards_result: list[dict] = []
        self.get_result: dict = {}
        self.call_tool_result: dict | list = {}
        self.raise_on: set[str] = set()

    async def search(self, q, limit=5):
        self.calls.append(("search", (q,), {"limit": limit}))
        if "search" in self.raise_on:
            raise RuntimeError("boom-search")
        return self.search_result

    async def list_boards(self):
        self.calls.append(("list_boards", (), {}))
        if "list_boards" in self.raise_on:
            raise RuntimeError("boom-list_boards")
        return self.list_boards_result

    async def get(self, kind, id, board_id):
        self.calls.append(("get", (kind, id, board_id), {}))
        if "get" in self.raise_on:
            raise RuntimeError("boom-get")
        return self.get_result

    async def call_tool(self, name, args=None):
        self.calls.append(("call_tool", (name,), dict(args or {})))
        if "call_tool" in self.raise_on or name in self.raise_on:
            raise RuntimeError(f"boom-{name}")
        if isinstance(self.call_tool_result, dict):
            return self.call_tool_result.get(name, {})
        return self.call_tool_result


@pytest.mark.asyncio
async def test_search_returns_matches():
    mcp = _FakeMCP()
    mcp.search_result = [
        {"kind": "task", "board_id": 1, "board_name": "B",
         "id": "T-1", "title": "Gradle release plugin"}
    ]
    out = await build_tickets_search().run(
        {"q": "gradle"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["matches"][0]["id"] == "T-1"
    assert mcp.calls[0][0] == "search"
    assert mcp.calls[0][1] == ("gradle",)


@pytest.mark.asyncio
async def test_search_empty_returns_note():
    mcp = _FakeMCP()
    mcp.search_result = []
    out = await build_tickets_search().run({"q": "zzz"}, {"local_todo": mcp})
    assert out["status"] == "ok"
    assert out["result"]["matches"] == []
    assert "note" in out["result"]
    assert "broader" in out["result"]["note"].lower()


@pytest.mark.asyncio
async def test_search_requires_q():
    mcp = _FakeMCP()
    out = await build_tickets_search().run({"q": ""}, {"local_todo": mcp})
    assert out["status"] == "error"
    assert "q is required" in out["error"]


@pytest.mark.asyncio
async def test_search_handles_mcp_exception():
    mcp = _FakeMCP()
    mcp.raise_on = {"search"}
    out = await build_tickets_search().run({"q": "x"}, {"local_todo": mcp})
    assert out["status"] == "error"
    assert "boom-search" in out["error"]


@pytest.mark.asyncio
async def test_get_direct_lookup_finds_task_on_first_board():
    """The agent gives a bare id like '140'. We list boards then try
    mcp.get(kind, id, board_id) directly — no search-first dance."""
    mcp = _FakeMCP()
    mcp.list_boards_result = [{"board_id": 1, "name": "Grepr"}]
    mcp.get_result = {"id": "140", "title": "Strip user-variable values", "status": "in_review"}
    mcp.call_tool_result = {
        "list_subtasks": {"subtasks": [{"id": "S-1", "title": "subtask"}]},
        "task_activity": {"events": [{"type": "comment", "text": "hi"}]},
    }
    out = await build_tickets_get().run({"id": "140"}, {"local_todo": mcp})
    assert out["status"] == "ok"
    r = out["result"]
    assert r["task"]["id"] == "140"
    assert r["kind"] == "task"
    assert r["board_id"] == 1
    assert r["activity"][0]["text"] == "hi"
    assert r["subtasks"][0]["id"] == "S-1"

    kinds = [c[0] for c in mcp.calls]
    # list_boards then get(task, "140", 1) — no search call before
    assert kinds[0] == "list_boards"
    assert kinds[1] == "get"
    assert mcp.calls[1][1] == ("task", "140", 1)


@pytest.mark.asyncio
async def test_get_falls_back_to_search_when_no_id_match():
    """If the bare-id lookup misses on every board+kind, fall back to a
    keyword search so the agent still learns something."""
    mcp = _FakeMCP()
    mcp.list_boards_result = [{"board_id": 1, "name": "Grepr"}]
    mcp.raise_on = {"get"}  # every direct get fails — simulates "not found"
    mcp.search_result = [
        {"kind": "task", "board_id": 1, "id": "245", "title": "Some PR thing"}
    ]
    # Once search picks a candidate, the SECOND get (after raise_on is cleared) needs to succeed.
    # _FakeMCP isn't smart enough to flip mid-test, so emulate by checking that the search-then-error
    # path returns an error AT MINIMUM (still better than silent miss).
    out = await build_tickets_get().run({"id": "nonexistent"}, {"local_todo": mcp})
    # search was called as fallback
    kinds = [c[0] for c in mcp.calls]
    assert kinds[0] == "list_boards"
    # eventually search was attempted
    assert "search" in kinds


@pytest.mark.asyncio
async def test_get_no_id_and_no_search_match_returns_note():
    """Both direct lookups and fallback search return nothing — emit a
    helpful note pointing the agent at library.search_meetings."""
    mcp = _FakeMCP()
    mcp.list_boards_result = [{"board_id": 1, "name": "Grepr"}]
    mcp.raise_on = {"get"}
    mcp.search_result = []
    out = await build_tickets_get().run({"id": "PR-3696"}, {"local_todo": mcp})
    assert out["status"] == "ok"
    assert out["result"]["task"] is None
    note = out["result"]["note"].lower()
    assert "library.search_meetings" in note
    assert "pr/mr" in note


@pytest.mark.asyncio
async def test_get_requires_id():
    mcp = _FakeMCP()
    out = await build_tickets_get().run({}, {"local_todo": mcp})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_get_surfaces_list_boards_failure():
    mcp = _FakeMCP()
    mcp.raise_on = {"list_boards"}
    out = await build_tickets_get().run({"id": "T-1"}, {"local_todo": mcp})
    assert out["status"] == "error"
    assert "boom-list_boards" in out["error"]


@pytest.mark.asyncio
async def test_list_boards():
    mcp = _FakeMCP()
    mcp.list_boards_result = [{"board_id": 1, "name": "B"}]
    out = await build_tickets_list_boards().run({}, {"local_todo": mcp})
    assert out["status"] == "ok"
    assert out["result"]["boards"][0]["board_id"] == 1


@pytest.mark.asyncio
async def test_list_boards_handles_exception():
    mcp = _FakeMCP()
    mcp.raise_on = {"list_boards"}
    out = await build_tickets_list_boards().run({}, {"local_todo": mcp})
    assert out["status"] == "error"
    assert "boom-list_boards" in out["error"]


@pytest.mark.asyncio
async def test_list_in_sprint_uses_active_sprint_cache():
    app_state = type(
        "S", (), {"sprint_tickets": [{"id": "T-1"}, {"id": "T-2"}]}
    )()
    out = await build_tickets_list_in_sprint().run({}, {"app_state": app_state})
    assert len(out["result"]["tickets"]) == 2


@pytest.mark.asyncio
async def test_add_comment_is_mutation():
    tool = build_tickets_add_comment()
    assert tool.is_mutation is True


@pytest.mark.asyncio
async def test_add_comment_executes_after_call():
    mcp = _FakeMCP()
    mcp.call_tool_result = {"add_comment": {"id": "C-1"}}
    out = await build_tickets_add_comment().run(
        {"task_id": "T-1", "body": "hello"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert mcp.calls[0] == (
        "call_tool",
        ("add_comment",),
        {"task_id": "T-1", "body": "hello"},
    )


@pytest.mark.asyncio
async def test_add_comment_handles_exception():
    mcp = _FakeMCP()
    mcp.raise_on = {"add_comment"}
    out = await build_tickets_add_comment().run(
        {"task_id": "T-1", "body": "hello"}, {"local_todo": mcp}
    )
    assert out["status"] == "error"
    assert "boom-add_comment" in out["error"]


@pytest.mark.asyncio
async def test_add_comment_requires_fields():
    mcp = _FakeMCP()
    out = await build_tickets_add_comment().run(
        {"task_id": "T-1"}, {"local_todo": mcp}
    )
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_task_activity_returns_events():
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "task_activity": {"events": [{"type": "comment", "text": "hi"}]},
    }
    out = await build_tickets_task_activity().run(
        {"task_id": "140"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["events"][0]["text"] == "hi"
    assert mcp.calls[0] == ("call_tool", ("task_activity",), {"task_id": "140"})


@pytest.mark.asyncio
async def test_list_subtasks_returns_subtasks():
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "list_subtasks": {"subtasks": [{"id": "S-1", "title": "sub"}]},
    }
    out = await build_tickets_list_subtasks().run(
        {"task_id": "T-1"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["subtasks"][0]["id"] == "S-1"
    assert mcp.calls[0] == ("call_tool", ("list_subtasks",), {"task_id": "T-1"})


@pytest.mark.asyncio
async def test_list_sprints_handles_active_planned_closed_shape():
    """Real MCP returns ``{active, planned, closed}`` — our wrapper must
    expose ``result.active`` directly and flatten everything into ``sprints``."""
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "list_sprints": {
            "active": {"id": "15", "name": "Sprint 2", "state": "active"},
            "planned": [{"id": "16", "name": "Sprint 3", "state": "planned"}],
            "closed": [{"id": "14", "name": "Sprint 1", "state": "closed"}],
        },
    }
    out = await build_tickets_list_sprints().run(
        {"board_id": 1}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    r = out["result"]
    assert r["active"]["id"] == "15"
    assert len(r["sprints"]) == 3
    assert {s["id"] for s in r["planned"]} == {"16"}
    assert {s["id"] for s in r["closed"]} == {"14"}


@pytest.mark.asyncio
async def test_list_sprints_handles_no_active_sprint():
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "list_sprints": {"active": None, "planned": [], "closed": []},
    }
    out = await build_tickets_list_sprints().run(
        {"board_id": 1}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["active"] is None
    assert out["result"]["sprints"] == []


@pytest.mark.asyncio
async def test_get_active_sprint_returns_active():
    from meeting_helper.chat.tools.tickets import build_tickets_get_active_sprint
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "list_sprints": {
            "active": {"id": "15", "name": "Sprint 2"},
            "planned": [],
            "closed": [],
        },
    }
    out = await build_tickets_get_active_sprint().run(
        {"board_id": 1}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["sprint"]["id"] == "15"


@pytest.mark.asyncio
async def test_get_active_sprint_none_when_absent():
    from meeting_helper.chat.tools.tickets import build_tickets_get_active_sprint
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "list_sprints": {"active": None, "planned": [], "closed": []},
    }
    out = await build_tickets_get_active_sprint().run(
        {"board_id": 1}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["sprint"] is None
    assert "no active sprint" in out["result"]["note"]


@pytest.mark.asyncio
async def test_list_task_docs_returns_docs():
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "list_task_doc_links": {"docs": [{"id": "D-1", "title": "Handover"}]},
    }
    out = await build_tickets_list_task_docs().run(
        {"task_id": "T-1"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["docs"][0]["id"] == "D-1"
    assert mcp.calls[0] == ("call_tool", ("list_task_doc_links",), {"task_id": "T-1"})


@pytest.mark.asyncio
async def test_search_docs_iterates_boards_when_no_board_given():
    mcp = _FakeMCP()
    mcp.list_boards_result = [{"board_id": 1, "name": "B"}]
    mcp.call_tool_result = {
        "search_docs": {"docs": [{"id": "D-1", "title": "Handover doc"}]},
    }
    out = await build_tickets_search_docs().run(
        {"q": "handover", "limit": 3}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    matches = out["result"]["matches"]
    assert matches[0]["id"] == "D-1"
    assert matches[0]["board_id"] == 1
    assert matches[0]["board_name"] == "B"
    # list_boards then one search_docs call
    assert mcp.calls[0][0] == "list_boards"
    assert mcp.calls[1] == (
        "call_tool",
        ("search_docs",),
        {"board_id": 1, "q": "handover", "limit": 3},
    )


@pytest.mark.asyncio
async def test_search_docs_with_specific_board():
    mcp = _FakeMCP()
    mcp.call_tool_result = {
        "search_docs": {"docs": [{"id": "D-9", "title": "Spec"}]},
    }
    out = await build_tickets_search_docs().run(
        {"q": "spec", "board_id": 2, "limit": 5}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["matches"][0]["id"] == "D-9"
    # Only one call: search_docs (no list_boards needed)
    assert mcp.calls[0] == (
        "call_tool",
        ("search_docs",),
        {"board_id": 2, "q": "spec", "limit": 5},
    )


@pytest.mark.asyncio
async def test_get_doc_returns_doc():
    mcp = _FakeMCP()
    mcp.get_result = {"id": "D-1", "title": "RFC", "body": "..."}
    out = await build_tickets_get_doc().run(
        {"doc_id": "D-1", "board_id": 1}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert out["result"]["doc"]["id"] == "D-1"
    assert mcp.calls[0] == ("get", ("doc", "D-1", 1), {})


@pytest.mark.asyncio
async def test_create_task_is_mutation():
    assert build_tickets_create_task().is_mutation is True


@pytest.mark.asyncio
async def test_create_task_happy_path():
    mcp = _FakeMCP()
    mcp.call_tool_result = {"create_task": {"id": "T-99", "title": "Hello"}}
    out = await build_tickets_create_task().run(
        {
            "board_id": 1,
            "title": "Hello",
            "description": "do it",
            "status": "todo",
            "assignee_id": "u-1",
            "sprint_id": 5,
        },
        {"local_todo": mcp},
    )
    assert out["status"] == "ok"
    assert out["result"]["id"] == "T-99"
    assert mcp.calls[0] == (
        "call_tool",
        ("create_task",),
        {
            "board_id": 1,
            "title": "Hello",
            "description": "do it",
            "status": "todo",
            "assignee_id": "u-1",
            "sprint_id": 5,
        },
    )


@pytest.mark.asyncio
async def test_create_task_only_required_fields():
    mcp = _FakeMCP()
    mcp.call_tool_result = {"create_task": {"id": "T-1"}}
    out = await build_tickets_create_task().run(
        {"board_id": 2, "title": "Bare"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert mcp.calls[0] == (
        "call_tool",
        ("create_task",),
        {"board_id": 2, "title": "Bare"},
    )


@pytest.mark.asyncio
async def test_create_task_requires_board_and_title():
    mcp = _FakeMCP()
    out = await build_tickets_create_task().run({"title": "x"}, {"local_todo": mcp})
    assert out["status"] == "error"
    out = await build_tickets_create_task().run({"board_id": 1}, {"local_todo": mcp})
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_create_task_handles_exception():
    mcp = _FakeMCP()
    mcp.raise_on = {"create_task"}
    out = await build_tickets_create_task().run(
        {"board_id": 1, "title": "x"}, {"local_todo": mcp}
    )
    assert out["status"] == "error"
    assert "boom-create_task" in out["error"]


@pytest.mark.asyncio
async def test_update_task_is_mutation():
    assert build_tickets_update_task().is_mutation is True


@pytest.mark.asyncio
async def test_update_task_happy_path():
    mcp = _FakeMCP()
    mcp.call_tool_result = {"update_task": {"id": "T-1", "title": "New"}}
    out = await build_tickets_update_task().run(
        {
            "task_id": "T-1",
            "title": "New",
            "description": "desc",
            "status": "done",
            "assignee_id": "u-2",
        },
        {"local_todo": mcp},
    )
    assert out["status"] == "ok"
    assert mcp.calls[0] == (
        "call_tool",
        ("update_task",),
        {
            "task_id": "T-1",
            "title": "New",
            "description": "desc",
            "status": "done",
            "assignee_id": "u-2",
        },
    )


@pytest.mark.asyncio
async def test_update_task_one_field_only():
    mcp = _FakeMCP()
    mcp.call_tool_result = {"update_task": {"id": "T-1"}}
    out = await build_tickets_update_task().run(
        {"task_id": "T-1", "status": "in_review"}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert mcp.calls[0] == (
        "call_tool",
        ("update_task",),
        {"task_id": "T-1", "status": "in_review"},
    )


@pytest.mark.asyncio
async def test_update_task_requires_task_id():
    mcp = _FakeMCP()
    out = await build_tickets_update_task().run(
        {"title": "x"}, {"local_todo": mcp}
    )
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_update_task_requires_at_least_one_field():
    mcp = _FakeMCP()
    out = await build_tickets_update_task().run(
        {"task_id": "T-1"}, {"local_todo": mcp}
    )
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_move_to_sprint_is_mutation():
    assert build_tickets_move_to_sprint().is_mutation is True


@pytest.mark.asyncio
async def test_move_to_sprint_happy_path():
    mcp = _FakeMCP()
    mcp.call_tool_result = {"move_task_to_sprint": {"ok": True}}
    out = await build_tickets_move_to_sprint().run(
        {"task_id": "T-1", "sprint_id": 5}, {"local_todo": mcp}
    )
    assert out["status"] == "ok"
    assert mcp.calls[0] == (
        "call_tool",
        ("move_task_to_sprint",),
        {"task_id": "T-1", "sprint_id": 5},
    )


@pytest.mark.asyncio
async def test_move_to_sprint_requires_fields():
    mcp = _FakeMCP()
    out = await build_tickets_move_to_sprint().run(
        {"task_id": "T-1"}, {"local_todo": mcp}
    )
    assert out["status"] == "error"
    out = await build_tickets_move_to_sprint().run(
        {"sprint_id": 5}, {"local_todo": mcp}
    )
    assert out["status"] == "error"


@pytest.mark.asyncio
async def test_move_to_sprint_handles_exception():
    mcp = _FakeMCP()
    mcp.raise_on = {"move_task_to_sprint"}
    out = await build_tickets_move_to_sprint().run(
        {"task_id": "T-1", "sprint_id": 5}, {"local_todo": mcp}
    )
    assert out["status"] == "error"
    assert "boom-move_task_to_sprint" in out["error"]
