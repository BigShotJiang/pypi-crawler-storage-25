"""End-to-end: spin up the daemon test client + a stub provider, send a
message, assert thread state + WS events."""
import asyncio
import pytest
from aiohttp import web
from aiohttp.test_utils import TestClient, TestServer

from meeting_helper.chat import paths as chat_paths, handlers as chat_handlers
from meeting_helper.chat.registry import Registry


def _isolate(monkeypatch, tmp_path):
    monkeypatch.setattr(chat_paths, "CHAT_ROOT", tmp_path / "chat")
    monkeypatch.setattr(chat_paths, "_active_workspace_name", lambda: "test")


@pytest.mark.asyncio
async def test_e2e_create_thread_send_message_receive_response(monkeypatch, tmp_path):
    _isolate(monkeypatch, tmp_path)

    class _Prov:
        async def stream_completion(self, *, system, messages, tools):
            for w in ["I'", "ll ", "help."]:
                yield {"type": "chunk", "text": w}
            yield {"type": "done"}

    monkeypatch.setattr("meeting_helper.chat.handlers._build_provider", lambda cfg, **_: _Prov())
    monkeypatch.setattr("meeting_helper.chat.handlers._build_registry", lambda: Registry())

    app = web.Application()
    app.router.add_post("/chat/threads", chat_handlers.threads_create_handler)
    app.router.add_get("/chat/threads", chat_handlers.threads_list_handler)
    app.router.add_get(r"/chat/threads/{thread_id}", chat_handlers.threads_get_handler)
    app.router.add_post(r"/chat/threads/{thread_id}/messages", chat_handlers.messages_post_handler)

    broadcasts = []
    async def _b(m): broadcasts.append(m)
    monkeypatch.setattr("meeting_helper.server.websocket.broadcast", _b)

    async with TestClient(TestServer(app)) as client:
        r = await client.post("/chat/threads", json={"title": "E2E"})
        thr = await r.json()
        tid = thr["id"]
        r = await client.post(f"/chat/threads/{tid}/messages", json={"text": "Hi"})
        assert r.status == 202

        # Wait for completion.
        for _ in range(40):
            await asyncio.sleep(0.05)
            if any(b["type"] == "chat.turn_done" for b in broadcasts):
                break

        r = await client.get(f"/chat/threads/{tid}")
        got = await r.json()
    chunks = [b["text"] for b in broadcasts if b["type"] == "chat.chunk"]
    assert "".join(chunks) == "I'll help."
    assistant_turns = [t for t in got["turns"] if t["role"] == "assistant"]
    assert assistant_turns[-1]["text"] == "I'll help."
