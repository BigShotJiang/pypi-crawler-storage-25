"""Top-level package for geocif."""

# tqdm.rich is alpha and prints a TqdmExperimentalWarning on first instantiation.
# 17 submodules use it directly via `from tqdm.rich import tqdm` (analysis,
# geocif, geocif_runner, indices_runner, utils, ml/*, cid/*, agmet/*, risk/*,
# progress); silencing it once here at package import covers all of them
# without per-file filters.
import warnings as _warnings
try:
    from tqdm import TqdmExperimentalWarning as _TqdmExperimentalWarning
    _warnings.filterwarnings("ignore", category=_TqdmExperimentalWarning)
except ImportError:
    pass

__author__ = """Ritvik Sahajpal"""
__email__ = "ritvik@umd.edu"
__version__ = "0.4.669"

__all__ = ["ml", "cid", "viz", "agmet", "fdw_export", "dashboard"]
