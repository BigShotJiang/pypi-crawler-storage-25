"""Seedream CLI core modules."""
