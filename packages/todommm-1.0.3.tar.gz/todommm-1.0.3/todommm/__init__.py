import os
import sys
import subprocess

def run():
    # get the directory where this file is located
    dir = os.path.dirname(os.path.abspath(__file__))
    exe = os.path.join(dir, "todoapp.exe")
    subprocess.run([exe])

if __name__ == "__main__":
    run()