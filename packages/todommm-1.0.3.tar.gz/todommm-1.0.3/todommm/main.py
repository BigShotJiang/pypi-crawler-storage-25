import os
import subprocess

def run():
    dir = os.path.dirname(os.path.abspath(__file__))
    exe = os.path.join(dir, "todoapp.exe")
    subprocess.run([exe])

if __name__ == "__main__":
    run()