from setuptools import setup, find_packages
setup(
    name="todommm",
    version="1.0.3",
    author="Muhammad Maaz",
    author_email="muhammadmaaz0166@gmail.com",
    description="A simple To Do List app built in C++",
    long_description=open("README.md").read(),
    long_description_content_type="text/markdown",
    packages=find_packages(),
    package_data={"todommm": ["*.exe"]},  # ← changed
    include_package_data=True,
    entry_points={
        "console_scripts": [
            "todommm=todommm.main:run",   # ← changed
        ],
    },
    python_requires=">=3.6",
)