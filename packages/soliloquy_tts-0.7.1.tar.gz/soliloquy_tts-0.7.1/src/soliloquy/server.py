"""
Soliloquy — A text-to-speech MCP server powered by Kokoro.
Gives Claude Code a voice.
"""

import os
import re
import sys

import numpy as np

os.environ["PYTORCH_ENABLE_MPS_FALLBACK"] = "1"

from mcp.server.fastmcp import FastMCP

from .audio import _playback, stop_playback, stream_play_audio
from .chunking import _inference_lock, adaptive_chunks, normalize_for_speech, split_sentences

mcp = FastMCP("soliloquy")

# ---------------------------------------------------------------------------
# Model loading — happens once at import time so the pipeline stays warm
# ---------------------------------------------------------------------------

from kokoro import KPipeline

PIPELINES: dict[str, KPipeline] = {}

LANG_MAP = {
    "en-us": "a",
    "en-gb": "b",
    "ja": "j",
    "zh": "z",
    "es": "e",
    "fr": "f",
    "hi": "h",
    "it": "i",
    "pt-br": "p",
}

VOICES = {
    "af_heart", "af_bella", "af_nova", "af_sky", "af_nicole",
    "af_sarah", "af_river", "af_alloy", "af_aoede", "af_jessica", "af_kore",
    "am_adam", "am_echo", "am_eric", "am_fenrir", "am_liam",
    "am_michael", "am_onyx", "am_puck", "am_santa",
    "bf_alice", "bf_emma", "bf_isabella", "bf_lily",
    "bm_daniel", "bm_fable", "bm_george", "bm_lewis",
}

DEFAULT_VOICE = "af_heart"
DEFAULT_LANG = "en-us"


def _get_pipeline(lang_code: str) -> KPipeline:
    """Get or create a pipeline for the given language."""
    if lang_code not in PIPELINES:
        short = LANG_MAP.get(lang_code, lang_code)
        PIPELINES[lang_code] = KPipeline(lang_code=short, repo_id="hexgrad/Kokoro-82M")
    return PIPELINES[lang_code]


# ---------------------------------------------------------------------------
# Model warmup — called explicitly by the backend, not at import time
# ---------------------------------------------------------------------------

def _ensure_spacy_model():
    """Install en_core_web_sm if missing. Works in pip-less environments (uvx)."""
    try:
        __import__("en_core_web_sm")
        return
    except ImportError:
        pass

    print("Downloading spaCy model (en_core_web_sm)...", file=sys.stderr, flush=True)
    import site
    import tempfile
    import urllib.request
    import zipfile

    url = "https://github.com/explosion/spacy-models/releases/download/en_core_web_sm-3.8.0/en_core_web_sm-3.8.0-py3-none-any.whl"
    target = site.getsitepackages()[0]
    with tempfile.NamedTemporaryFile(suffix=".whl", delete=False) as tmp:
        urllib.request.urlretrieve(url, tmp.name)
        with zipfile.ZipFile(tmp.name) as z:
            z.extractall(target)
        os.unlink(tmp.name)


def warm_up():
    """Load the default pipeline and run a warmup generation."""
    print("Loading Kokoro model...", file=sys.stderr, flush=True)
    # Redirect stdout to stderr during model load — third-party libraries
    # (kokoro, torch, transformers) may print warnings that corrupt MCP stdio.
    old_stdout = sys.stdout
    sys.stdout = sys.stderr
    try:
        _ensure_spacy_model()
        pipeline = _get_pipeline(DEFAULT_LANG)
        for _ in pipeline("warmup", voice=DEFAULT_VOICE):
            pass
    finally:
        sys.stdout = old_stdout
    print("Model ready.", file=sys.stderr, flush=True)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _validate_params(voice: str, speed: float, lang: str) -> str | None:
    """Validate voice, speed, and language. Returns error message or None."""
    if voice not in VOICES:
        return f"Unknown voice '{voice}'. Available: {', '.join(sorted(VOICES))}"
    if not (0.5 <= speed <= 2.0):
        return "Speed must be between 0.5 and 2.0."
    if lang not in LANG_MAP:
        return f"Unknown language '{lang}'. Available: {', '.join(sorted(LANG_MAP.keys()))}"
    return None


def _synthesize_and_play(text: str, voice: str, speed: float, lang: str) -> None:
    """Synthesize text and start async playback. Returns immediately."""
    stop_playback()  # Stop any current playback before starting new
    pipeline = _get_pipeline(lang)
    sentences = split_sentences(text, lang=lang)

    if len(sentences) <= 2:
        def audio_chunks():
            with _inference_lock:
                for _gs, _ps, audio in pipeline(text, voice=voice, speed=speed):
                    if _playback.stop_event.is_set():
                        return
                    if not isinstance(audio, np.ndarray):
                        audio = np.array(audio, dtype=np.float32)
                    yield audio.copy()
        stream_play_audio(audio_chunks(), blocking=False)
    else:
        def chunk_factory(buffer):
            return adaptive_chunks(
                sentences, pipeline, voice, speed, buffer,
                stop_event=_playback.stop_event,
            )
        stream_play_audio(chunk_factory, blocking=False)


def _strip_markdown(text: str) -> str:
    """Strip markdown and normalize text for natural speech.

    Delegates to the full speech normalization pipeline in chunking.py.
    """
    return normalize_for_speech(text)


# ---------------------------------------------------------------------------
# MCP Tools
# ---------------------------------------------------------------------------

@mcp.tool()
def speak(
    text: str,
    voice: str = DEFAULT_VOICE,
    speed: float = 1.0,
    lang: str = DEFAULT_LANG,
) -> str:
    """Speak text aloud using Kokoro text-to-speech.

    Use this tool to read text aloud to the user. Great for:
    - Reading summaries, explanations, or code reviews aloud
    - Giving voice feedback on completed tasks
    - Narrating documentation or changelogs
    - Any time the user might benefit from hearing the output

    Args:
        text: The text to speak aloud.
        voice: Voice ID. Default "af_heart" (American female, highest quality).
               Other options: af_bella, af_nova, am_adam, am_michael, etc.
        speed: Speaking speed multiplier. 1.0 is normal, 0.8 is slower, 1.2 is faster.
        lang: Language code. Default "en-us". Options: en-gb, ja, zh, es, fr, hi, it, pt-br.
    """
    error = _validate_params(voice, speed, lang)
    if error:
        return error

    _synthesize_and_play(text, voice, speed, lang)

    word_count = len(text.split())
    est_duration = word_count / (150 * speed) * 60
    return f"Playing audio (~{est_duration:.0f}s estimated, voice={voice}, speed={speed}x)"


@mcp.tool()
def read_aloud(
    path: str,
    voice: str = DEFAULT_VOICE,
    speed: float = 1.0,
    lang: str = DEFAULT_LANG,
) -> str:
    """Read a file aloud using Kokoro text-to-speech.

    Reads the file directly on the server — no need for Claude to process
    the content first. Supports plain text and markdown files. Use this
    for reading documents, chapters, articles, or any text file aloud.

    Args:
        path: Path to the file to read aloud.
        voice: Voice ID. Default "af_heart" (American female, highest quality).
        speed: Speaking speed multiplier. 1.0 is normal, 0.8 is slower, 1.2 is faster.
        lang: Language code. Default "en-us". Options: en-gb, ja, zh, es, fr, hi, it, pt-br.
    """
    error = _validate_params(voice, speed, lang)
    if error:
        return error

    path = os.path.expanduser(path)
    if not os.path.isfile(path):
        return f"File not found: {path}"

    try:
        with open(path, "r", encoding="utf-8") as f:
            text = f.read()
    except (OSError, UnicodeDecodeError) as e:
        return f"Error reading file: {e}"

    if path.endswith((".md", ".markdown")):
        text = _strip_markdown(text)

    text = text.strip()
    if not text:
        return "File is empty."

    _synthesize_and_play(text, voice, speed, lang)

    word_count = len(text.split())
    est_duration = word_count / (150 * speed) * 60
    return f"Reading aloud (~{est_duration:.0f}s estimated, voice={voice}, speed={speed}x)"


@mcp.tool()
def stop() -> str:
    """Stop audio playback immediately.

    Kills the currently playing audio and cancels any queued audio.
    Use this when the user asks you to stop talking or be quiet.
    """
    was_playing = stop_playback()
    if was_playing:
        return "Playback stopped."
    return "Nothing is currently playing."


@mcp.tool()
def auto_speak() -> str:
    """Toggle automatic voicing of all Claude responses.

    When ON, every response Claude gives is automatically spoken aloud
    via the Stop hook — zero token overhead, no tool call needed.
    When OFF (default), responses are text only unless you use the speak tool.

    Just say "turn on auto speak" or "turn off auto speak".
    """
    from .setup import AUTO_SPEAK_FLAG

    if AUTO_SPEAK_FLAG.exists():
        AUTO_SPEAK_FLAG.unlink()
        return "Auto-speak OFF. Responses will not be voiced automatically."
    else:
        AUTO_SPEAK_FLAG.parent.mkdir(parents=True, exist_ok=True)
        AUTO_SPEAK_FLAG.touch()
        return "Auto-speak ON. All responses will be voiced automatically."


@mcp.tool()
def list_voices() -> str:
    """List all available Kokoro TTS voices with their language and gender."""
    lines = ["Available voices:", ""]
    for v in sorted(VOICES):
        prefix = v[:2]
        lang = "American" if prefix[0] == "a" else "British"
        gender = "Female" if prefix[1] == "f" else "Male"
        marker = " ★" if v == DEFAULT_VOICE else ""
        lines.append(f"  {v:<16} {lang} {gender}{marker}")
    lines.append("")
    lines.append("★ = default (highest quality)")
    return "\n".join(lines)


