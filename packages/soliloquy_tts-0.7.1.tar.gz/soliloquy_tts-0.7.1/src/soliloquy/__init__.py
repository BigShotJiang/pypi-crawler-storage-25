"""Soliloquy — A text-to-speech MCP server powered by Kokoro."""

__version__ = "0.7.1"

from .main import main

__all__ = ["main", "__version__"]
