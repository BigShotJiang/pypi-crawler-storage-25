# CLAUDE.md

This file provides guidance to Claude Code (claude.ai/code) when working with code in this repository.

## What This Is

Soliloquy is a text-to-speech MCP server powered by Kokoro that gives Claude Code a voice. It exposes five MCP tools (`speak`, `read_aloud`, `stop`, `auto_speak`, and `list_voices`) over stdio transport. Distributed as `soliloquy-tts` on PyPI.

## Development

```bash
python3.11 -m venv .venv
source .venv/bin/activate
pip install -e .[dev]

# Run setup (from terminal — TTY detection routes to setup mode)
soliloquy

# Run tests
pytest tests/ -v

# Run benchmarks
python scripts/benchmark_tts.py

# Uninstall (removes MCP registration, hooks, and config)
soliloquy --uninstall
```

## Architecture

```
src/soliloquy/
  __init__.py   — version, re-exports main()
  __main__.py   — python -m soliloquy support
  main.py       — entry point: --uninstall flag, TTY detection (terminal → setup, Claude Code → server)
  setup.py      — one-command install/uninstall: registers MCP, writes hook script, configures auto-speak (--uninstall reverses all)
  server.py     — FastMCP tool definitions (speak, read_aloud, stop, auto_speak, list_voices)
  chunking.py   — speech normalization, sentence splitting, adaptive chunk sizing
  backend.py    — dual-mode runner (SSE server + stdio, concurrent via anyio)
  proxy.py      — lightweight stdio-to-SSE stream bridge (~30 lines)
  lock.py       — lock file protocol for backend discovery
  audio.py      — gapless audio playback via sounddevice (PortAudio), producer-consumer queue
  player.py     — macOS menu bar app (rumps), separate process, polls backend status
scripts/
  benchmark_tts.py    — performance benchmarking (not part of package)
  debug_chunking.py   — chunking diagnostics (not part of package)
  auto-speak-hook.sh  — reference hook script for Claude Code Stop hook
```

### Smart Install

Running `soliloquy` (or `uvx soliloquy-tts`) from a terminal triggers setup mode via TTY detection. Setup registers the MCP server, writes the auto-speak hook script to `~/.soliloquy/`, and configures the Stop hook in `~/.claude/settings.json`. When Claude Code runs it (stdin is a pipe), it starts as the MCP server instead.

Running `soliloquy --uninstall` reverses setup: unregisters the MCP server, removes the Stop hook from settings, and deletes `~/.soliloquy/`.

### Hybrid Backend

Multiple Claude Code sessions share a single Kokoro model instance:

1. **First `soliloquy` process** — loads model, starts SSE server on a dynamic port, runs stdio for the launching session, writes lock to `~/.soliloquy/backend.lock`
2. **Subsequent processes** — detect the lock, skip model loading, run as lightweight stdio-to-SSE proxies (near-instant startup)
3. **Stale lock recovery** — if the backend dies, next process detects it via PID + health probe and takes over

The proxy (`proxy.py`) is a transparent stream bridge — it forwards raw MCP messages between stdio and SSE without understanding the protocol. It imports only `mcp` and `anyio`, never `kokoro` or `torch`.

### Speech Normalization

All text passes through `normalize_for_speech()` in `chunking.py` before reaching Kokoro. This pipeline:
- Replaces code blocks with natural cues ("See the code below")
- Summarizes tables ("There's a table here with 5 rows")
- Maps symbols to speech (arrows → "to", URLs → "a link")
- Converts lists to natural enumeration ("First... Second... Third...")
- Inserts pauses at paragraph breaks via ellipsis

### Thread Safety

PyTorch's CPU allocator is not thread-safe for concurrent LSTM inference. All Kokoro pipeline calls are serialized behind `_inference_lock` in `chunking.py`, and output arrays are `.copy()`'d to detach from PyTorch's memory pool. The audio stream uses `stream.stop()` (not `stream.abort()`) to avoid CoreAudio buffer crashes.

### Auto-Speak

The Stop hook fires after every Claude response, POSTing to the backend's `/auto-speak` endpoint. The endpoint checks for a flag file (`~/.soliloquy/auto-speak.enabled`) and skips if audio is already playing (so it doesn't interrupt explicit speak/read_aloud calls). The `auto_speak` MCP tool toggles the flag file.

## Dev vs Global Install Warning

This project runs a local editable install of Soliloquy. The user also has Soliloquy installed globally (via `uvx soliloquy-tts`) for all other projects.

Both share the same lock file at `~/.soliloquy/backend.lock`. If a global instance is already running as the backend, the local dev version will connect to it as a proxy — meaning your local code changes won't be active. Conversely, if the dev version starts first, global sessions will proxy through your dev code.

**On session start**: Check `~/.soliloquy/backend.lock`. If it exists and was started by a non-dev instance (different PID/path), the dev server here is proxying to the published version, not running local code. Kill the other backend first if you need to test local changes.

## Releasing

Main branch is protected — no direct pushes, no merging without a passing pipeline.

### Workflow

1. **Branch** — create a release branch from main
   ```bash
   git checkout -b release/v0.X.Y
   ```

2. **Bump version** — update both `pyproject.toml` and `src/soliloquy/__init__.py`

3. **Commit and push**
   ```bash
   git add pyproject.toml src/soliloquy/__init__.py
   git commit -m "Bump version to 0.X.Y"
   git push -u origin release/v0.X.Y
   ```

4. **Create MR** — this triggers the test pipeline
   ```bash
   glab mr create --title "Release v0.X.Y" --target-branch main
   ```

5. **Wait for tests to pass** — the merge button is blocked until the pipeline succeeds

6. **Merge the MR** — either in the GitLab UI or via CLI

7. **Tag and publish** — the tag triggers a publish-only pipeline (no re-testing)
   ```bash
   git checkout main && git pull
   git tag v0.X.Y
   git push origin v0.X.Y
   ```

### CI Pipeline

- **Branch push / MR**: runs tests (gates the merge)
- **Version tag**: publishes to PyPI (tests already passed to reach main)

Repository hosted on GitLab (private): `gitlab.com/bw-stovall/soliloquy`

## Key Details

- **Cross-platform audio**: Uses `sounddevice` (PortAudio) for gapless playback on macOS, Windows, and Linux
- **MPS fallback**: `PYTORCH_ENABLE_MPS_FALLBACK=1` must be set before torch import (handled at top of `server.py`)
- **Import weight**: `server.py` imports `kokoro` at module level (triggers torch/transformers). Proxy mode avoids importing `server.py` entirely.
- **28 voices** across American/British, male/female. Default is `af_heart`
- **9 languages**: en-us, en-gb, ja, zh, es, fr, hi, it, pt-br
- **Test suite**: 176 unit tests covering lock protocol, validation, audio, chunking, speech normalization, setup, uninstall, auto-speak, and version checks. Run with `pytest tests/ -v`
- **Heavy install** (~2GB) due to PyTorch and model weights
- **First run** downloads Kokoro-82M from HuggingFace
