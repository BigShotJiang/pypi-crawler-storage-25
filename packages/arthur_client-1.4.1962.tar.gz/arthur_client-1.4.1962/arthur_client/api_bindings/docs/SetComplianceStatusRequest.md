# SetComplianceStatusRequest


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**compliance_status** | [**ComplianceStatus**](ComplianceStatus.md) | The new compliance status. | 

## Example

```python
from arthur_client.api_bindings.models.set_compliance_status_request import SetComplianceStatusRequest

# TODO update the JSON string below
json = "{}"
# create an instance of SetComplianceStatusRequest from a JSON string
set_compliance_status_request_instance = SetComplianceStatusRequest.from_json(json)
# print the JSON string representation of the object
print(SetComplianceStatusRequest.to_json())

# convert the object into a dict
set_compliance_status_request_dict = set_compliance_status_request_instance.to_dict()
# create an instance of SetComplianceStatusRequest from a dict
set_compliance_status_request_from_dict = SetComplianceStatusRequest.from_dict(set_compliance_status_request_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


