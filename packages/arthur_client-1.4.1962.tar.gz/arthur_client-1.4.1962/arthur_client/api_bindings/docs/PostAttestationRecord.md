# PostAttestationRecord


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**attestation_rule_id** | **str** | The ID of the attestation rule this attestation satisfies. | 
**notes** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.post_attestation_record import PostAttestationRecord

# TODO update the JSON string below
json = "{}"
# create an instance of PostAttestationRecord from a JSON string
post_attestation_record_instance = PostAttestationRecord.from_json(json)
# print the JSON string representation of the object
print(PostAttestationRecord.to_json())

# convert the object into a dict
post_attestation_record_dict = post_attestation_record_instance.to_dict()
# create an instance of PostAttestationRecord from a dict
post_attestation_record_from_dict = PostAttestationRecord.from_dict(post_attestation_record_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


