# PolicyAssignment


## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**created_at** | **datetime** | Time of record creation. | 
**updated_at** | **datetime** | Time of last record update. | 
**id** | **str** | The ID of the policy assignment. | 
**policy** | [**PolicySummary**](PolicySummary.md) | Summary of the assigned policy. | 
**model** | [**ModelSummary**](ModelSummary.md) | Summary of the assigned model. | 
**applied_at** | **datetime** | When the policy was applied to the model. | 
**applied_by_user_id** | **str** |  | [optional] 
**enforcement_starts_at** | **datetime** | When enforcement starts. | 
**compliance_status** | [**ComplianceStatus**](ComplianceStatus.md) | Current compliance status. | 
**compliance_job_id** | **str** |  | [optional] 

## Example

```python
from arthur_client.api_bindings.models.policy_assignment import PolicyAssignment

# TODO update the JSON string below
json = "{}"
# create an instance of PolicyAssignment from a JSON string
policy_assignment_instance = PolicyAssignment.from_json(json)
# print the JSON string representation of the object
print(PolicyAssignment.to_json())

# convert the object into a dict
policy_assignment_dict = policy_assignment_instance.to_dict()
# create an instance of PolicyAssignment from a dict
policy_assignment_from_dict = PolicyAssignment.from_dict(policy_assignment_dict)
```
[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


