### Proposed Changes
1.  **CLI Implementation**: Use the `argparse` module from the Python standard library to handle command-line inputs.
2.  **Parameters**:
    * `--string`: Accepts a raw text string for processing.
    * `--file`: Accepts a path to a local text file.
3.  **Core Logic**:
    * Implement a function to read and process content from a text file.
    * **Priority Rule**: If both parameters are provided, `--file` takes higher priority, and the `--string` input is ignored.
4.  **Unit Testing**:
    * Develop a comprehensive suite of unit tests to ensure the application behaves correctly under different input scenarios.
5. Packaging and Distribution
   * Transform the application into a standard Python package using the `src-layout`.
   * Use `pyproject.toml` with `hatchling` as the build backend.
   * Define an entry point `char-counter` in the `[project.scripts]` section to allow the tool to be run as a standalone command after installation.
