from typing import Any

import pytest

from char_counter_pkg.char_counter.char_count import count_char


def test_char_count() -> None:
    assert count_char("abc") == 3


@pytest.mark.parametrize("value", [1, None])
def test_count_char_invalid_types(value: Any) -> None:
    with pytest.raises(TypeError):
        count_char(value)


def test_count_char_cache() -> None:
    count_char.cache_clear()
    count_char("abc")
    count_char("abc")
    info_cache = count_char.cache_info()
    assert info_cache.hits == 1
    assert info_cache.misses == 1
