from unittest.mock import MagicMock, mock_open

from pytest_mock import MockerFixture

from char_counter_pkg.cli.comand_line import read_file, run_cli


def test_priority_file_over_string(mocker: MockerFixture) -> None:
    mock_args = MagicMock()
    mock_args.string = "ignore me"
    mock_args.file = "test.txt"

    mocker.patch("argparse.ArgumentParser.parse_args", return_value=mock_args)

    mocker.patch("cli.comand_line.read_file", return_value="text from file")
    mock_count = mocker.patch("cli.comand_line.count_char", return_value=5)
    mock_print = mocker.patch("builtins.print")

    run_cli()

    mock_count.assert_called_once_with("text from file")
    mock_print.assert_called_with(5)


def test_only_string_parameter(mocker: MockerFixture) -> None:
    mock_args = MagicMock()
    mock_args.string = "hello"
    mock_args.file = None

    mocker.patch("argparse.ArgumentParser.parse_args", return_value=mock_args)
    mock_count = mocker.patch("cli.comand_line.count_char", return_value=2)
    mock_print = mocker.patch("builtins.print")

    run_cli()

    mock_count.assert_called_once_with("hello")
    mock_print.assert_called_with(2)


def test_read_file_success(mocker: MockerFixture) -> None:
    mocker.patch("builtins.open", mock_open(read_data="file data"))

    result = read_file("fake_path.txt")
    assert result == "file data"


def test_read_file_not_found(mocker: MockerFixture) -> None:
    mocker.patch("builtins.open", side_effect=FileNotFoundError)
    mock_print = mocker.patch("builtins.print")

    result = read_file("missing.txt")

    assert result is None
    mock_print.assert_called_with("File not found")


def test_no_arguments_prints_help(mocker: MockerFixture) -> None:
    mock_args = MagicMock()
    mock_args.string = None
    mock_args.file = None

    mocker.patch("argparse.ArgumentParser.parse_args", return_value=mock_args)
    mock_help = mocker.patch("argparse.ArgumentParser.print_help")

    run_cli()

    mock_help.assert_called_once()
