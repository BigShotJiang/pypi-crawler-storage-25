# Character Counter Package

A professional Python CLI tool for counting unique characters in strings and text files. Built with modern standards using `src-layout` and `uv`.

## Features

- **Flexible Input**: Process raw text strings or local files.
- **Priority Rule**: If both parameters are provided, `--file` takes higher priority, and the `--string` input is ignored.
- **CLI Ready**: Once installed, the tool is available as a standalone command.
- **Robustness**: Fully covered by unit tests.

## Installation

To install the package from the local directory using `uv`, run:

```bash
uv pip install .
uv pip install -e . development mode
```
## Usage
- **After installation, you can use the char-counter command directly from your terminal.**
### using string
``` bash
char-counter --string "your string"
  ```

### using file
``` bash
char-counter --file path/to/your/file.txt
```
### Priority Logic
The application follows a strict priority rule: if both arguments are provided, the tool will process the file and ignore the string input.
``` bash
char-counter --file data.txt --string "this text will be ignored"
```
## Help
To see all available options and command descriptions, run:

``` bash
char-counter --help
```

## Documentation
Technical specifications and design decisions are documented separately in the RFC.md file.
