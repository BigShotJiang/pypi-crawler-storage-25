from collections import Counter
from functools import lru_cache


@lru_cache
def count_char(sentence: str) -> int:
    if not isinstance(sentence, str):
        raise TypeError("Sentence must be a string")
    count_symbols = Counter(sentence)
    count_once_symbol = len(list(filter(lambda x: x == 1, count_symbols.values())))
    return count_once_symbol
