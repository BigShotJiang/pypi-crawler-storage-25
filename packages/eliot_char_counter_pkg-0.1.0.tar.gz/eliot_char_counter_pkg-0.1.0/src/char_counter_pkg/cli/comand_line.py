import argparse

from char_counter_pkg.char_counter.char_count import count_char


def run_cli() -> None:
    parser = argparse.ArgumentParser(description="Count symbols in line")
    parser.add_argument("--string", type=str, help="line to count")
    parser.add_argument("--file", type=str, help="path to file")
    args = parser.parse_args()
    if args.file is None and args.string is None:
        parser.print_help()
    elif args.file is not None:
        source_text = read_file(args.file)
        if source_text is not None:
            print(count_char(source_text))
    elif args.string is not None:
        print(count_char(args.string))


def read_file(path_to_file: str) -> str | None:
    try:
        with open(path_to_file, "r") as file:
            return file.read()
    except FileNotFoundError:
        print("File not found")
        return None
