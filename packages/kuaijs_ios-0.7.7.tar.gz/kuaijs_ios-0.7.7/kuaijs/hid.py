from typing import List, Optional, Literal, Union, TypedDict


class AppInfo(TypedDict):
    """应用信息"""

    name: str  # 应用名称
    bundleId: str  # 应用 Bundle ID


class HIDKey:
    """HID 按键常量映射"""

    COMMAND = 0
    LEFT_CTRL = 0
    LEFT_SHIFT = 0
    LEFT_ALT = 0
    RIGHT_CTRL = 0
    RIGHT_SHIFT = 0
    RIGHT_ALT = 0
    UP_ARROW = 0
    DOWN_ARROW = 0
    LEFT_ARROW = 0
    RIGHT_ARROW = 0
    SPACE = 0
    BACKSPACE = 0
    TAB = 0
    RETURN = 0
    ESC = 0
    INSERT = 0
    DELETE = 0
    PAGE_UP = 0
    PAGE_DOWN = 0
    HOME = 0
    END = 0
    CAPS_LOCK = 0
    F1 = 0
    F2 = 0
    F3 = 0
    F4 = 0
    F5 = 0
    F6 = 0
    F7 = 0
    F8 = 0
    F9 = 0
    F10 = 0
    F11 = 0
    F12 = 0

    def __getitem__(self, key: str) -> int:
        return getattr(self, key, 0)


hidKey = HIDKey()
"""HID 按键常量映射。

用于组合键发送：可通过 hidKey.COMMAND、hidKey.LEFT_CTRL 等取得修饰键代码，
也支持字典访问 hidKey["COMMAND"] 与直接传入字符串名称（如 "COMMAND"）。
示例：
    from kuaijs import hid
    hid.sendKey([hid.hidKey.COMMAND, "c"])    # 复制（点属性）
    hid.sendKey([hid.hidKey["COMMAND"], "c"])  # 复制（字典）
    hid.sendKey(["COMMAND", "v"])             # 粘贴（字符串键名）
"""


def openRecordScreen() -> bool:
    """打开录屏界面

    返回:
      bool: 是否成功开始录屏界面

    示例:
        from kuaijs import hid
        hid.openRecordScreen()
    """
    return True


def isRecording() -> bool:
    """录屏是否开启

    返回:
      bool: 是否正在录屏

    示例:
        from kuaijs import hid
        if hid.isRecording():
            ...
    """
    return True


def isBLEConnected() -> bool:
    """是否连接了蓝牙HID设备

    返回:
      bool: 是否连接了蓝牙HID设备

    示例:
        from kuaijs import hid
        if hid.isBLEConnected():
            ...
    """
    return True


def isUSBConnected() -> bool:
    """是否连接了USB HID设备

    返回:
      bool: 是否连接了USB HID设备

    示例:
        from kuaijs import hid
        if hid.isUSBConnected():
            ...
    """
    return True


def getBLEHIDDeviceName() -> str:
    """获取蓝牙 HID 设备名称

    返回:
      str: 蓝牙 HID 设备名称，未连接时可能为空字符串或“未知设备”

    示例:
        from kuaijs import hid
        name = hid.getBLEHIDDeviceName()
        print(name)
    """
    return ""


def setBLEHIDDeviceName(name: str) -> bool:
    """设置蓝牙 HID 设备名称

    参数:
      name: 要设置的蓝牙 HID 设备名称
    返回:
      bool: 是否设置成功

    示例:
        from kuaijs import hid
        hid.setBLEHIDDeviceName("KuaiJS-HID")
    """
    return True


def getDeviceMac() -> str:
    """获取设备 MAC 字符串

    返回:
      str: 设备返回的 MAC 字符串

    示例:
        from kuaijs import hid
        mac = hid.getDeviceMac()
        print(mac)
    """
    return ""


def getDeviceModel() -> str:
    """获取设备型号

    返回:
      str: 当前 HID 设备型号

    示例:
        from kuaijs import hid
        model = hid.getDeviceModel()
        print(model)
    """
    return ""


def getDeviceVersion() -> str:
    """获取设备版本

    返回:
      str: 当前 HID 设备版本

    示例:
        from kuaijs import hid
        version = hid.getDeviceVersion()
        print(version)
    """
    return ""


def resetPosition() -> bool:
    """复位坐标到初始位置

    返回:
      bool: 是否复位成功

    示例:
        from kuaijs import hid
        hid.resetPosition()
    """
    return True


def restartDevice() -> bool:
    """重启当前连接的 HID 设备

    返回:
      bool: 是否成功发送重启指令

    示例:
        from kuaijs import hid
        hid.restartDevice()
    """
    return True


# 设置动作抖动值（像素，随屏幕 scale 适配）
def setJitterValue(value: int):
    """设置动作抖动值（像素，随屏幕 scale 适配）"""
    pass


def move(x: int, y: int) -> bool:
    """移动坐标

    参数:
      x/y: 坐标
    返回:
      bool: 是否成功
    """
    return True


def click(x: int, y: int, duration: int = 10, jitter: bool = False) -> bool:
    """点击指定坐标

    参数:
      x/y: 坐标
      duration: 按下时长（毫秒，默认 20ms）
      jitter: 是否启用抖动（默认 False）
    返回:
      bool: 是否成功
    """
    return True


def mouseDown() -> bool:
    """按下鼠标左键

    返回:
      bool: 是否成功发送鼠标按下指令

    示例:
        from kuaijs import hid
        hid.mouseDown()
    """
    return True


def mouseUp() -> bool:
    """抬起鼠标左键

    返回:
      bool: 是否成功发送鼠标抬起指令

    示例:
        from kuaijs import hid
        hid.mouseUp()
    """
    return True


def clickRandom(x1: int, y1: int, x2: int, y2: int, duration: int = 20) -> bool:
    """随机点击指定矩形区域

    参数:
      x1/y1/x2/y2: 矩形区域坐标
      duration: 按下时长（毫秒，默认 20ms）
    返回:
      bool: 是否成功
    """
    return True


def doubleClick(
    x: int, y: int, duration: int = 20, interval: int = 20, jitter: bool = False
) -> bool:
    """双击指定坐标

    参数:
      x/y: 坐标
      duration: 每次按下时长（毫秒，默认 20ms）
      interval: 两次点击间隔（毫秒，默认 20ms）
      jitter: 是否启用抖动（默认 False）
    返回:
      bool: 是否成功
    """
    return True


def doubleClickRandom(
    x1: int, y1: int, x2: int, y2: int, duration: int = 20, interval: int = 20
) -> bool:
    """随机双击矩形区域

    参数:
      x1/y1/x2/y2: 矩形区域坐标
      duration: 每次按下时长（毫秒，默认 20ms）
      interval: 两次点击间隔（毫秒，默认 20ms）
    返回:
      bool: 是否成功
    """
    return True


def swipe(
    x: int, y: int, ex: int, ey: int, jitter: bool = False, steps: int = 6
) -> bool:
    """直线滑动

    参数:
      x/y: 起点坐标
      ex/ey: 终点坐标
      jitter: 是否启用抖动（默认 False）
      steps: 轨迹点数量（默认 6）
    """
    return True


def swipeCurve(
    startX: int, startY: int, midX: int, midY: int, endX: int, endY: int
) -> bool:
    """3 点曲线滑动
    参数:
      startX/startY: 起点坐标
      midX/midY: 中间点坐标
      endX/endY: 终点坐标
    返回:
      bool: 是否成功
    """
    return True


def pressAndSwipe(
    startX: int,
    startY: int,
    endX: int,
    endY: int,
    duration: int = 500,
    jitter: bool = False,
    steps: int = 6,
) -> bool:
    """长按并滑动

    参数:
      startX/startY: 起点坐标
      endX/endY: 终点坐标
      duration: 长按时间（毫秒，默认 500ms）
      jitter: 是否启用抖动（默认 False）
      steps: 轨迹点数量（默认 6）
    返回:
      bool: 是否成功
    """
    return True


def homeScreen() -> bool:
    """回主页
    返回:
      bool: 是否成功
    """
    return True


def input(text: str) -> bool:
    """输入文本

    参数:
      text: 要输入的文本
    返回:
      bool: 是否成功
    """
    return True


def inputSimple(text: str) -> bool:
    """输入基础文本（不支持中文），等价于键盘逐字输出

    参数:
      text: 要输入的基础文本（建议 ASCII）
    返回:
      bool: 是否成功
    """
    return True


def space() -> bool:
    """空格键
    返回:
      bool: 是否成功
    """
    return True


def backspace(count: int = 1) -> bool:
    """删除键
    参数:
      count: 删除次数（可选，默认值为1）
    返回:
      bool: 是否成功
    """
    return True


def enter() -> bool:
    """回车键
    返回:
      bool: 是否成功
    """
    return True


def sendKey(keys: List[Union[int, str]]) -> bool:
    """发送组合按键（支持数字或字符）
    参数:
      keys: 按键列表（数字或字符）
    返回:
      bool: 是否成功
    """
    return True


def pressButton(
    button: Literal[
        "home",
        "volumeup",
        "volumedown",
        "mute",
        "playpause",
        "next",
        "prev",
        "eject",
        "globe",
        "search",
    ],
) -> bool:
    """按按钮（home/volumeup/volumedown/mute/playpause/next/prev/eject/globe/search 等）

    参数:
      button: 按钮名称
    返回:
      bool: 是否成功
    """
    return True


def copyText() -> bool:
    """复制文本（Command+C）
    返回:
      bool: 是否成功
    """
    return True


def pasteText() -> bool:
    """粘贴文本（Command+V）
    返回:
      bool: 是否成功
    """
    return True


def back() -> bool:
    """返回（Tab+B）
    返回:
      bool: 是否成功
    """
    return True


def recent() -> bool:
    """APP 切换器
    返回:
      bool: 是否成功
    """
    return True


def lock() -> bool:
    """锁屏
    返回:
      bool: 是否成功
    """
    return True


def unlock() -> bool:
    """解锁
    返回:
      bool: 是否成功
    """
    return True


def openURL(url: str) -> bool:
    """打开 URL
    参数:
      url: URL 地址
    返回:
      bool: 是否成功
    """
    return True


def openApp(name: str) -> bool:
    """打开 App
    参数:
      name: App 名称 支持 app name 或 bundleId
    返回:
      bool: 是否成功
    """
    return True


def closeApp(name: str) -> bool:
    """关闭 App
    参数:
      name: App 名称 支持 app name 或 bundleId
    返回:
      bool: 是否成功
    """
    return True


def takeMeToFront() -> bool:
    """切到前台
    返回:
      bool: 是否成功
    """
    return True


def currentAppInfo() -> Optional[AppInfo]:
    """当前应用信息（仅 iOS18.6+）
    返回:
      AppInfo: 当前应用信息
    """
    return None


def setClipboard(text: str) -> bool:
    """设置剪贴板
    参数:
      text: 要设置的文本
    返回:
      bool: 是否成功
    """
    return True


def getClipboard() -> str:
    """获取剪贴板
    返回:
      str: 剪贴板文本
    """
    return ""
