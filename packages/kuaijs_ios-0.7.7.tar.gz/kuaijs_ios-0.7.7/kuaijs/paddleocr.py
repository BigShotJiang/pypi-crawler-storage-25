from typing import List, TypedDict


class OCRResult(TypedDict):
    """OCR 识别结果"""

    text: str  # 识别文本
    confidence: float  # 置信度（0-1）
    x: int  # 左边界
    y: int  # 上边界
    ex: int  # 右边界
    ey: int  # 下边界
    width: int  # 宽度
    height: int  # 高度
    centerX: int  # 中心 X 坐标
    centerY: int  # 中心 Y 坐标
    angle: float  # 旋转角度（顺时针）
    orientation: int  # 方向（0=水平，1=垂直）


def loadV5(maxSideLen: int = 640, useGpu: bool = False) -> bool:
    """加载 PP-OCRv5 模型（maxSideLen 默认 640, useGpu 默认 False）"""
    return True


def recognize(
    input: str,
    x: int = 0,
    y: int = 0,
    ex: int = 0,
    ey: int = 0,
    confidenceThreshold: float = 0.6,
) -> List[OCRResult]:
    """执行 OCR 识别（返回 OCRResult 列表）

    参数默认值:
      x/y/ex/ey: 0（全屏）
      confidenceThreshold: 0.6
    """
    return []


def findText(
    input: str,
    targetTexts: List[str],
    x: int = 0,
    y: int = 0,
    ex: int = 0,
    ey: int = 0,
    confidenceThreshold: float = 0.6,
) -> List[OCRResult]:
    """查找目标文本并返回对应子串坐标

    Args:
      input: 输入源（imageId、URL字符串、文件路径或"screen"）
      targetTexts: 目标文本数组，例如 ["你好", "确定"]
      x: 边界框左上角x坐标，默认0
      y: 边界框左上角y坐标，默认0
      ex: 边界框右下角x坐标，默认0
      ey: 边界框右下角y坐标，默认0
      confidenceThreshold: 置信度阈值，默认0.6

    Returns:
      匹配到的子串结果数组（text 为目标文本）

    Example:
      results = paddleocr.findText("screen", ["你好"], 0, 0, 0, 0, 0.6)
    """
    return []


def free() -> None:
    """释放模型资源"""
    pass
