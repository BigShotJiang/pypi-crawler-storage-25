from typing import List, Optional, TypedDict


class YoloResult(TypedDict):
    """YOLO 目标检测结果"""

    x: int  # 左边界
    y: int  # 上边界
    ex: int  # 右边界
    ey: int  # 下边界
    centerX: int  # 中心 X 坐标
    centerY: int  # 中心 Y 坐标
    width: int  # 宽度
    height: int  # 高度
    confidence: float  # 置信度（0-1）
    classId: int  # 类别 ID


def load(
    paramPath: str,
    binPath: str,
    nc: int,
    version: int = 11,
    useGpu: bool = False,
) -> Optional[str]:
    """加载 YOLO 模型。

    Args:
        paramPath: 模型 param 文件绝对路径。
        binPath: 模型 bin 文件绝对路径。
        nc: 标签类别数量。
        version: 模型版本，默认 11。
        useGpu: 是否启用 GPU 推理，默认 False。

    Returns:
        Optional[str]: 模型 ID，失败时返回 None。

    Example:
        modelId = yolo.load("/tmp/a.param", "/tmp/a.bin", 80, 11, True)
    """
    return None


def loadV11(
    paramPath: str, binPath: str, nc: int, useGpu: bool = False
) -> Optional[str]:
    """加载 YOLOv11 模型。

    Args:
        paramPath: 模型 param 文件绝对路径。
        binPath: 模型 bin 文件绝对路径。
        nc: 标签类别数量。
        useGpu: 是否启用 GPU 推理，默认 False。

    Returns:
        Optional[str]: 模型 ID，失败时返回 None。

    Example:
        modelId = yolo.loadV11("/tmp/a.param", "/tmp/a.bin", 80, True)
    """
    return None


def detect(
    modelId: str,
    img: str,
    targetSize: int = 640,
    threshold: float = 0.4,
    nmsThreshold: float = 0.5,
) -> List[YoloResult]:
    """目标检测（返回边框/置信度/类别等）

    参数默认值:
      targetSize: 640
      threshold: 0.4
      nmsThreshold: 0.5
    """
    return []


def free(modelId: str):
    """释放指定模型资源"""
    pass


def freeAll():
    """释放所有模型资源"""
    pass
