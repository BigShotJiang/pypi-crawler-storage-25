"""Semantic embedding index for template KB pages.

Uses sentence-transformers to build a local vector index over template
summaries.  Falls back gracefully when the optional ``[search]`` extra
is not installed.

Phase70 deliverable.
"""

from __future__ import annotations

import hashlib
import json
import logging
from pathlib import Path
from typing import Any, Dict, List, Optional

from core.template_kb import (
    GlobalTemplateWikiStore,
    TemplateHit,
    _LoadedPage,
    _make_excerpt,
)

logger = logging.getLogger("scribe")

DEFAULT_MODEL = "paraphrase-multilingual-MiniLM-L12-v2"


def is_semantic_available() -> bool:
    try:
        import sentence_transformers  # noqa: F401

        return True
    except ImportError:
        return False


def _onnx_available() -> bool:
    try:
        import onnxruntime  # noqa: F401

        return True
    except ImportError:
        return False


def _page_embedding_text(page: _LoadedPage) -> str:
    summary_end = page.body.find("\n## ")
    if summary_end == -1:
        summary_end = min(len(page.body), 300)
    summary = page.body[:summary_end].strip()
    return f"{page.title}。{summary}"


def _page_content_hash(page: _LoadedPage) -> str:
    payload = f"{page.page_id}:{page.title}:{page.body[:500]}"
    return hashlib.md5(payload.encode()).hexdigest()


class TemplateEmbeddingIndex:
    """Lazy-loading embedding index backed by a numpy cache file."""

    def __init__(
        self,
        store: GlobalTemplateWikiStore,
        model_name: str = DEFAULT_MODEL,
    ) -> None:
        self._store = store
        self._model_name = model_name
        self._page_ids: List[str] = []
        self._page_kinds: List[str] = []
        self._vectors: Any = None
        self._model: Any = None
        self._use_onnx: bool = _onnx_available()

    def _load_model(self) -> Any:
        from sentence_transformers import SentenceTransformer

        if self._use_onnx:
            logger.info("Loading embedding model with ONNX backend ...")
            return SentenceTransformer(self._model_name, backend="onnx")
        logger.info("Loading embedding model with PyTorch backend ...")
        return SentenceTransformer(self._model_name)

    def _cache_dir(self) -> Path:
        try:
            import core.template_kb as _self

            harness_root = Path(_self.__file__).parent.parent
        except (ImportError, AttributeError):
            harness_root = Path(__file__).parent.parent
        d = harness_root / "data" / "kb" / "embeddings"
        d.mkdir(parents=True, exist_ok=True)
        return d

    def _cache_prefix(self) -> str:
        safe = self._model_name.replace("/", "_").replace("\\", "_")
        return safe

    def _npz_path(self) -> Path:
        return self._cache_dir() / f"{self._cache_prefix()}.npz"

    def _meta_path(self) -> Path:
        return self._cache_dir() / f"{self._cache_prefix()}.meta.json"

    def is_ready(self) -> bool:
        return self._vectors is not None and len(self._page_ids) > 0

    def build(self) -> None:
        if self._load_cache():
            logger.info("Embedding cache loaded from %s", self._npz_path())
            return

        logger.info("Building embedding index with model %s ...", self._model_name)
        model = self._load_model()

        pages = self._store.pages()
        texts = [_page_embedding_text(p) for p in pages]

        logger.info("Encoding %d template pages ...", len(texts))
        vectors = model.encode(texts, show_progress_bar=True, normalize_embeddings=True)

        self._page_ids = [p.page_id for p in pages]
        self._page_kinds = [p.template_kind for p in pages]
        self._vectors = vectors
        self._model = model

        self._save_cache(pages)
        logger.info("Embedding index built and cached (%d pages)", len(pages))

    def _load_cache(self) -> bool:
        npz = self._npz_path()
        meta = self._meta_path()
        if not npz.exists() or not meta.exists():
            return False

        try:
            with open(meta, encoding="utf-8") as f:
                meta_data = json.load(f)
        except (json.JSONDecodeError, OSError):
            return False

        current_pages = self._store.pages()
        if len(current_pages) != meta_data.get("page_count", 0):
            return False

        cached_hashes: Dict[str, str] = meta_data.get("page_hashes", {})
        for p in current_pages:
            if cached_hashes.get(p.page_id) != _page_content_hash(p):
                logger.info("Cache stale for %s, will rebuild", p.page_id)
                return False

        import numpy as np

        data = np.load(str(npz), allow_pickle=False)
        self._vectors = data["vectors"]
        self._page_ids = list(meta_data["page_ids"])
        self._page_kinds = list(meta_data["page_kinds"])
        return True

    def _save_cache(self, pages: List[_LoadedPage]) -> None:
        import numpy as np

        np.savez_compressed(str(self._npz_path()), vectors=self._vectors)

        page_hashes = {p.page_id: _page_content_hash(p) for p in pages}
        meta_data = {
            "model_name": self._model_name,
            "dim": int(self._vectors.shape[1]) if self._vectors is not None else 0,
            "page_count": len(pages),
            "page_ids": self._page_ids,
            "page_kinds": self._page_kinds,
            "page_hashes": page_hashes,
        }
        with open(self._meta_path(), "w", encoding="utf-8") as f:
            json.dump(meta_data, f, ensure_ascii=False, indent=2)

    def search(
        self,
        query: str,
        kind: Optional[str] = None,
        top_k: int = 5,
    ) -> List[TemplateHit]:
        if not self.is_ready():
            return []

        if self._model is None:
            self._model = self._load_model()

        query_vec = self._model.encode([query], normalize_embeddings=True)
        scores = (self._vectors @ query_vec.T).flatten()

        indices_by_kind = [i for i, k in enumerate(self._page_kinds) if kind is None or k == kind]
        if not indices_by_kind:
            return []

        scored = [(i, float(scores[i])) for i in indices_by_kind]
        scored.sort(key=lambda x: x[1], reverse=True)
        top = scored[:top_k]

        all_pages = self._store.pages()
        page_map = {p.page_id: p for p in all_pages}

        hits: List[TemplateHit] = []
        for idx, score in top:
            pid = self._page_ids[idx]
            page = page_map.get(pid)
            if page is None:
                continue
            hits.append(
                TemplateHit(
                    page_id=page.page_id,
                    template_id=page.template_id,
                    template_kind=page.template_kind,
                    title=page.title,
                    lang=page.lang,
                    score=round(score * 100, 2),
                    excerpt=_make_excerpt(page.body),
                )
            )
        return hits
