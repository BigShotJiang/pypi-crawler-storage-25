"""Minimal Runtime kernel loop implementation."""

from __future__ import annotations

import json
import logging
from collections.abc import Callable
from pathlib import Path
from typing import Any

from core.hooks import HookEvent, HookEventBus, HookEventPayload, HookSubscription
from core.llm_client import MultiLLMClient

from .error_taxonomy import RuntimeErrorCategory, build_error_payload, classify_exception
from .guardrails import GuardrailEngine
from .memory_bridge import MemoryBridge
from .models import (
    RuntimeOutcome,
    RuntimeState,
    RuntimeTask,
    RuntimeTurnResult,
    SubagentResult,
    SubagentTask,
)
from .output_parser import RuntimeOutputParser
from .prompt_assembler import PromptAssembler
from .subagent_manager import SubagentManager
from .tool_protocol import ToolExecutor, ToolRegistry
from .turn_checkpoint import RuntimeTurnCheckpointStore
from .verification_hooks import RuntimeVerificationSuite

InferFn = Callable[[str, str], str]


class AgentRuntime:
    """Runtime kernel that executes a minimal dumb turn loop.

    This scaffold intentionally keeps orchestration logic simple:
    assemble prompt -> infer -> parse output -> update state.
    """

    def __init__(
        self,
        infer_fn: InferFn,
        prompt_assembler: PromptAssembler | None = None,
        output_parser: RuntimeOutputParser | None = None,
        context_bus: Any | None = None,
        memory_bridge: MemoryBridge | None = None,
        tool_registry: ToolRegistry | None = None,
        tool_executor: ToolExecutor | None = None,
        guardrail_engine: GuardrailEngine | None = None,
        turn_checkpoint_store: RuntimeTurnCheckpointStore | None = None,
        verification_suite: RuntimeVerificationSuite | None = None,
        subagent_manager: SubagentManager | None = None,
        hook_event_bus: HookEventBus | None = None,
        auto_feedback_enabled: bool = True,
        max_feedback_rounds: int = 1,
    ) -> None:
        """Initialize runtime with injectable functions.

        Args:
            infer_fn: Function that invokes model inference and returns raw text.
            prompt_assembler: Optional custom prompt assembler.
            output_parser: Optional custom output parser.
            context_bus: Optional context bus for context retrieval/budget validation.
            memory_bridge: Optional memory bridge for injection/writeback.
            tool_registry: Optional runtime tool registry.
            tool_executor: Optional runtime tool executor.
            guardrail_engine: Optional input/output/tool guardrail engine.
            turn_checkpoint_store: Optional turn-level checkpoint store.
            verification_suite: Optional verification hook suite.
            subagent_manager: Optional subagent orchestration manager.
            hook_event_bus: Optional runtime hook event bus.
            auto_feedback_enabled: Whether failed verification auto-injects feedback.
            max_feedback_rounds: Max auto-feedback retries per task.
        """
        self._infer_fn = infer_fn
        self._prompt_assembler = prompt_assembler or PromptAssembler()
        self._output_parser = output_parser or RuntimeOutputParser()
        self._context_bus = context_bus
        self._memory_bridge = memory_bridge
        self._tool_registry = tool_registry
        self._tool_executor = tool_executor
        self._guardrail_engine = guardrail_engine
        self._turn_checkpoint_store = turn_checkpoint_store
        self._verification_suite = verification_suite
        self._subagent_manager = subagent_manager
        self._hook_event_bus = hook_event_bus or HookEventBus()
        self._auto_feedback_enabled = auto_feedback_enabled
        self._max_feedback_rounds = max_feedback_rounds
        self._logger = logging.getLogger(__name__)

    @classmethod
    def from_llm_client(
        cls,
        llm_client: MultiLLMClient,
        context_bus: Any | None = None,
        memory_bus: Any | None = None,
    ) -> "AgentRuntime":
        """Create runtime instance from existing multi-LLM client.

        Args:
            llm_client: Existing LLM client used by current executors.
            context_bus: Optional context bus used by existing executors.
            memory_bus: Optional memory bus used by existing executors.

        Returns:
            Configured runtime instance using llm_client.generate().
        """

        def _infer(system_prompt: str, user_prompt: str) -> str:
            response = llm_client.generate(system_prompt=system_prompt, user_prompt=user_prompt)
            return response.content

        memory_bridge = MemoryBridge(memory_bus) if memory_bus is not None else None
        guardrail_engine = GuardrailEngine()
        return cls(
            infer_fn=_infer,
            context_bus=context_bus,
            memory_bridge=memory_bridge,
            guardrail_engine=guardrail_engine,
        )

    def run_turn_loop(self, task: RuntimeTask, state: RuntimeState) -> RuntimeOutcome:
        """Run minimal runtime loop without tool-calling.

        Args:
            task: Runtime task to execute.
            state: Mutable runtime state container.

        Returns:
            RuntimeOutcome containing success/error and updated state.
        """
        turns_executed = 0
        feedback_rounds = 0
        try:
            self._ensure_checkpoint_store(task)
            if task.metadata.get("resume_from_checkpoint") and state.turn_index == 0:
                resumed = self.load_latest_turn_state(task.task_id)
                if resumed is not None:
                    state = resumed

            for _ in range(max(task.max_turns, 1)):
                if state.finished:
                    break

                if state.turn_index == 0:
                    subagent_outcome = self._execute_subagents_if_needed(task, state)
                    if subagent_outcome is not None:
                        if not subagent_outcome.success:
                            self._emit_runtime_hook_event(
                                event=HookEvent.RUNTIME_TURN_FAILED.value,
                                task=task,
                                state=state,
                                metadata={
                                    "error": subagent_outcome.error or "Subagent execution failed",
                                    "turn_index": state.turn_index,
                                },
                                raise_on_required_failure=False,
                            )
                        return subagent_outcome

                input_guard = self._validate_input_guardrail(task, state)
                if input_guard is not None:
                    self._emit_runtime_hook_event(
                        event=HookEvent.RUNTIME_TURN_FAILED.value,
                        task=task,
                        state=state,
                        metadata={
                            "error": input_guard.error or "Input guardrail blocked runtime turn",
                            "turn_index": state.turn_index,
                        },
                        raise_on_required_failure=False,
                    )
                    return input_guard
                self._save_turn_checkpoint(task, state, phase="turn_start")

                if self._tool_registry is not None:
                    task.tool_definitions = self._tool_registry.list_for_model()
                context_str, context_meta = self._build_context(task)
                memory_str, memory_meta = self._build_memory_context(task, state, context_str)
                history_str = self._build_history_context(state)
                assembly = self._prompt_assembler.assemble(
                    task=task,
                    state=state,
                    memory_context=memory_str,
                    history_context=history_str,
                )

                system_prompt, user_prompt = assembly.system_prompt, assembly.user_prompt
                if self._memory_bridge is not None:
                    self._memory_bridge.mark_turn_start()
                self._emit_runtime_hook_event(
                    event=HookEvent.RUNTIME_BEFORE_TURN.value,
                    task=task,
                    state=state,
                    metadata={
                        "turn_index": state.turn_index + 1,
                        "agent_name": task.agent_name,
                    },
                )
                raw_output = self._infer_with_transient_retry(system_prompt, user_prompt, task)
                turn_result = self._output_parser.parse(raw_output)
                final_output = self._resolve_final_output(raw_output, turn_result)

                state.last_system_prompt = system_prompt
                state.last_user_prompt = user_prompt
                state.last_raw_output = raw_output
                state.last_final_output = final_output
                state.turn_index += 1
                turns_executed += 1
                state.metadata["prompt_sections"] = assembly.sections
                state.metadata["context_budget"] = context_meta
                state.metadata["memory"] = memory_meta
                state.metadata["runtime_turn_result"] = turn_result.model_dump(mode="json")

                state.conversation_history.append({"role": "user", "content": user_prompt})
                state.conversation_history.append({"role": "assistant", "content": raw_output})

                if turn_result.tool_calls:
                    tool_results = self._execute_tool_calls(turn_result, task, state)
                    tool_payload = json.dumps(tool_results, ensure_ascii=True)
                    state.metadata["last_tool_results"] = tool_results
                    state.conversation_history.append({"role": "tool", "content": tool_payload})
                    failed = [item for item in tool_results if not item.get("success", False)]
                    if failed:
                        first_error = failed[0].get("error", "Tool execution failed")
                        self._emit_runtime_hook_event(
                            event=HookEvent.RUNTIME_TURN_FAILED.value,
                            task=task,
                            state=state,
                            metadata={
                                "error": str(first_error),
                                "turn_index": state.turn_index,
                                "tool_results": tool_results,
                            },
                            raise_on_required_failure=False,
                        )
                        return RuntimeOutcome(
                            success=False,
                            turns_executed=turns_executed,
                            final_output=state.last_final_output or None,
                            error=str(first_error),
                            state=state,
                        )
                    continue

                if turn_result.recoverable_error:
                    error_payload = build_error_payload(
                        message=turn_result.recoverable_error,
                        category=RuntimeErrorCategory.RECOVERABLE_MODEL,
                        retryable=False,
                    )
                    state.metadata["error"] = error_payload
                    self._emit_runtime_hook_event(
                        event=HookEvent.RUNTIME_TURN_FAILED.value,
                        task=task,
                        state=state,
                        metadata={
                            "error": turn_result.recoverable_error,
                            "turn_index": state.turn_index,
                            "error_payload": error_payload,
                        },
                        raise_on_required_failure=False,
                    )
                    return RuntimeOutcome(
                        success=False,
                        turns_executed=turns_executed,
                        final_output=state.last_final_output or None,
                        error=turn_result.recoverable_error,
                        state=state,
                    )

                state.last_final_output = final_output
                output_guard = self._validate_output_guardrail(final_output, state, turns_executed)
                if output_guard is not None:
                    self._emit_runtime_hook_event(
                        event=HookEvent.RUNTIME_TURN_FAILED.value,
                        task=task,
                        state=state,
                        metadata={
                            "error": output_guard.error or "Output guardrail blocked runtime turn",
                            "turn_index": state.turn_index,
                        },
                        raise_on_required_failure=False,
                    )
                    return output_guard

                verification_outcome = self._run_verification_hooks(task, state, final_output)
                if verification_outcome is not None:
                    verification_passed, feedback_prompt = verification_outcome
                    if not verification_passed:
                        if (
                            self._auto_feedback_enabled
                            and feedback_rounds < self._max_feedback_rounds
                        ):
                            task.user_input = f"{task.user_input}\n\n{feedback_prompt}"
                            feedback_rounds += 1
                            state.metadata["feedback_rounds"] = feedback_rounds
                            self._save_turn_checkpoint(task, state, phase="verification_retry")
                            continue
                        self._emit_runtime_hook_event(
                            event=HookEvent.RUNTIME_TURN_FAILED.value,
                            task=task,
                            state=state,
                            metadata={
                                "error": "Verification failed and exceeded feedback retry policy",
                                "turn_index": state.turn_index,
                                "verification": state.metadata.get("verification", {}),
                            },
                            raise_on_required_failure=False,
                        )
                        return RuntimeOutcome(
                            success=False,
                            turns_executed=turns_executed,
                            final_output=state.last_final_output or None,
                            error="Verification failed and exceeded feedback retry policy",
                            state=state,
                        )

                self._write_memory(task, state, final_output)
                self._save_turn_checkpoint(task, state, phase="turn_complete")
                self._emit_runtime_hook_event(
                    event=HookEvent.RUNTIME_AFTER_TURN.value,
                    task=task,
                    state=state,
                    metadata={
                        "turn_index": state.turn_index,
                        "final_output": final_output,
                        "verification": state.metadata.get("verification", {}),
                    },
                )
                state.finished = True

            if not state.finished:
                self._emit_runtime_hook_event(
                    event=HookEvent.RUNTIME_TURN_FAILED.value,
                    task=task,
                    state=state,
                    metadata={
                        "error": "Runtime loop exceeded max turns without final answer",
                        "turn_index": state.turn_index,
                    },
                    raise_on_required_failure=False,
                )
                return RuntimeOutcome(
                    success=False,
                    turns_executed=turns_executed,
                    final_output=state.last_final_output or None,
                    error="Runtime loop exceeded max turns without final answer",
                    state=state,
                )

            return RuntimeOutcome(
                success=True,
                turns_executed=turns_executed,
                final_output=state.last_final_output or None,
                state=state,
            )
        except Exception as exc:
            self._logger.error("Runtime turn loop failed: %s", exc)
            category, retryable = classify_exception(exc)
            state.metadata["error"] = build_error_payload(
                message=str(exc),
                category=category,
                retryable=retryable,
            )
            self._emit_runtime_hook_event(
                event=HookEvent.RUNTIME_TURN_FAILED.value,
                task=task,
                state=state,
                metadata={
                    "error": str(exc),
                    "turn_index": state.turn_index,
                    "error_category": category.value,
                },
                raise_on_required_failure=False,
            )
            return RuntimeOutcome(
                success=False,
                turns_executed=turns_executed,
                final_output=state.last_final_output or None,
                error=str(exc),
                state=state,
            )

    def _resolve_final_output(self, raw_output: str, turn_result: RuntimeTurnResult) -> str:
        """Resolve final output fallback when structured final answer missing."""
        if turn_result.final_answer is not None:
            return turn_result.final_answer.strip()
        return raw_output.strip()

    def _infer_with_transient_retry(
        self, system_prompt: str, user_prompt: str, task: RuntimeTask
    ) -> str:
        """Call inference with automatic retry on transient errors.

        Configurable via task.metadata:
        - auto_retry_transient: bool (default True)
        - auto_retry_max: int (default 2)
        """
        auto_retry = task.metadata.get("auto_retry_transient", True)
        max_retries = task.metadata.get("auto_retry_max", 2)

        if not auto_retry:
            return self._infer_fn(system_prompt, user_prompt)

        last_exc: Exception | None = None
        for attempt in range(1, max_retries + 2):
            try:
                return self._infer_fn(system_prompt, user_prompt)
            except (TimeoutError, ConnectionError, OSError) as exc:
                last_exc = exc
                if attempt <= max_retries:
                    self._logger.warning(
                        "Transient inference error (attempt %d/%d): %s",
                        attempt,
                        max_retries + 1,
                        exc,
                    )
                    continue
                break

        raise last_exc  # type: ignore[misc]

    def _build_context(self, task: RuntimeTask) -> tuple[str, dict[str, Any]]:
        """Build runtime context before prompt assembly."""
        if self._context_bus is None:
            return "", {}

        try:
            result = self._context_bus.build_context_with_metadata(
                agent_name=task.agent_name,
                provider=task.provider,
                model_config=task.llm_config,
            )
            metadata = {
                "original_tokens": result.original_tokens,
                "compressed_tokens": result.compressed_tokens,
                "tier_used": str(result.tier_used),
            }
            return result.context_str, metadata
        except Exception as exc:
            self._logger.debug("Context build failed: %s", exc)
            return "", {}

    def _build_memory_context(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        context_str: str,
    ) -> tuple[str, dict[str, Any]]:
        """Build memory section including runtime context output."""
        memory_text = ""
        metadata: dict[str, Any] = {}
        if self._memory_bridge is not None:
            memory_text, metadata = self._memory_bridge.build_memory_context(task, state)

        if context_str:
            context_block = f"### Runtime Context\n{context_str}"
            memory_text = f"{context_block}\n\n{memory_text}".strip()

        return memory_text, metadata

    def _build_history_context(self, state: RuntimeState) -> str:
        """Build compact history section from runtime state."""
        recent = state.conversation_history[-6:]
        if not recent:
            return ""
        return "\n".join(
            f"- {item.get('role', 'unknown')}: {item.get('content', '')}" for item in recent
        ).strip()

    def _write_memory(self, task: RuntimeTask, state: RuntimeState, final_output: str) -> None:
        """Persist runtime output to memory systems when available."""
        if self._memory_bridge is None:
            return
        self._memory_bridge.writeback(task, state, final_output)

    def _execute_tool_calls(
        self,
        turn_result: RuntimeTurnResult,
        task: RuntimeTask,
        state: RuntimeState,
    ) -> list[dict[str, Any]]:
        """Execute parsed tool calls and return structured results."""
        if self._tool_executor is None:
            return [
                {
                    "name": call.name,
                    "success": False,
                    "error": "No tool executor configured",
                }
                for call in turn_result.tool_calls
            ]

        results: list[dict[str, Any]] = []
        context = {
            "project_name": task.metadata.get("project_name", ""),
            "task_id": task.task_id,
            "turn_index": state.turn_index,
        }
        for call in turn_result.tool_calls:
            if self._guardrail_engine is not None and self._tool_registry is not None:
                spec = self._tool_registry.get(call.name)
                permission = spec.permission if spec is not None else "unknown"
                decision = self._guardrail_engine.validate_tool_call(call.name, permission)
                if not decision.allowed:
                    result_payload = {
                        "name": call.name,
                        "success": False,
                        "error": decision.reason,
                        "error_category": RuntimeErrorCategory.USER_FIXABLE.value,
                        "audit": {"status": "blocked_by_guardrail", "guardrail": decision.metadata},
                    }
                    results.append(result_payload)
                    state.metadata["error"] = build_error_payload(
                        message=decision.reason,
                        category=RuntimeErrorCategory.USER_FIXABLE,
                        retryable=False,
                    )
                    state.metadata["tool_guardrail"] = {
                        "allowed": False,
                        "decision": decision.model_dump(mode="json"),
                    }
                    continue

            result = self._tool_executor.execute(call, context=context)
            result_payload = result.model_dump(mode="json")
            results.append(result_payload)
            if not result.success:
                state.metadata["error"] = build_error_payload(
                    message=result.error or "Tool call failed",
                    category=RuntimeErrorCategory(
                        result.error_category or RuntimeErrorCategory.USER_FIXABLE.value
                    ),
                    retryable=False,
                )
            else:
                state.metadata["tool_guardrail"] = {"allowed": True}
        return results

    def _run_verification_hooks(
        self,
        task: RuntimeTask,
        state: RuntimeState,
        final_output: str,
    ) -> tuple[bool, str] | None:
        """Execute verification hooks and return pass flag with feedback prompt."""
        if self._verification_suite is None:
            return None
        bundle = self._verification_suite.run_hooks(
            task=task, state=state, final_output=final_output
        )
        state.metadata["verification"] = bundle.model_dump(mode="json")
        if bundle.passed:
            return True, ""
        return False, self._verification_suite.build_feedback_prompt(bundle)

    def _ensure_checkpoint_store(self, task: RuntimeTask) -> None:
        """Ensure turn-level checkpoint store is available."""
        if self._turn_checkpoint_store is not None:
            return
        project_dir = task.metadata.get("project_dir")
        if project_dir:
            checkpoint_dir = Path(project_dir) / ".runtime_checkpoints"
        else:
            checkpoint_dir = Path.cwd() / ".runtime_checkpoints"
        self._turn_checkpoint_store = RuntimeTurnCheckpointStore(checkpoint_dir=checkpoint_dir)

    def _save_turn_checkpoint(self, task: RuntimeTask, state: RuntimeState, phase: str) -> None:
        """Save current turn-level checkpoint when store is configured."""
        if self._turn_checkpoint_store is None:
            return
        self._turn_checkpoint_store.save(task=task, state=state, phase=phase)

    def load_latest_turn_state(self, task_id: str) -> RuntimeState | None:
        """Load latest turn-level checkpoint state for a task id."""
        if self._turn_checkpoint_store is None:
            return None
        return self._turn_checkpoint_store.load_latest_state(task_id)

    def _validate_input_guardrail(
        self, task: RuntimeTask, state: RuntimeState
    ) -> RuntimeOutcome | None:
        """Validate input guardrail and return failure outcome when blocked."""
        if self._guardrail_engine is None:
            return None
        decision = self._guardrail_engine.validate_input(task.user_input)
        if decision.allowed:
            state.metadata["input_guardrail"] = {"allowed": True}
            return None

        state.metadata["input_guardrail"] = {
            "allowed": False,
            "decision": decision.model_dump(mode="json"),
        }
        state.metadata["error"] = build_error_payload(
            message=decision.reason,
            category=RuntimeErrorCategory.USER_FIXABLE,
            retryable=False,
        )
        return RuntimeOutcome(
            success=False,
            turns_executed=0,
            final_output=None,
            error=decision.reason,
            state=state,
        )

    def _validate_output_guardrail(
        self,
        final_output: str,
        state: RuntimeState,
        turns_executed: int,
    ) -> RuntimeOutcome | None:
        """Validate output guardrail and return failure outcome when blocked."""
        if self._guardrail_engine is None:
            return None
        decision = self._guardrail_engine.validate_output(final_output)
        if decision.allowed:
            state.metadata["output_guardrail"] = {"allowed": True}
            return None

        state.metadata["output_guardrail"] = {
            "allowed": False,
            "decision": decision.model_dump(mode="json"),
        }
        state.metadata["error"] = build_error_payload(
            message=decision.reason,
            category=RuntimeErrorCategory.USER_FIXABLE,
            retryable=False,
        )
        return RuntimeOutcome(
            success=False,
            turns_executed=turns_executed,
            final_output=None,
            error=decision.reason,
            state=state,
        )

    def _execute_subagents_if_needed(
        self, task: RuntimeTask, state: RuntimeState
    ) -> RuntimeOutcome | None:
        """Run subagent orchestration once at turn 0 when task metadata requests it."""
        if task.metadata.get("is_subagent"):
            return None

        manager = self._subagent_manager or SubagentManager()
        parsed_tasks = manager.parse_tasks(task.metadata.get("subagents"))
        if not parsed_tasks:
            return None

        batch = manager.execute(
            parsed_tasks, runner=lambda sub_task: self._run_subagent(sub_task, task)
        )
        state.metadata["subagent_execution"] = batch.model_dump(mode="json")

        failed = [record for record in batch.records if not record.success]
        if failed:
            first_error = failed[0].error or "Subagent execution failed"
            return RuntimeOutcome(
                success=False,
                turns_executed=0,
                final_output=None,
                error=first_error,
                state=state,
            )

        if batch.teammate_notes:
            teammate_context = "\n".join(batch.teammate_notes)
            task.user_input = f"{task.user_input}\n\nSubagent teammate context:\n{teammate_context}"

        if batch.handoff_output:
            state.last_final_output = batch.handoff_output
            state.finished = True
            return RuntimeOutcome(
                success=True,
                turns_executed=0,
                final_output=batch.handoff_output,
                state=state,
            )

        return None

    def _run_subagent(self, sub_task: SubagentTask, parent_task: RuntimeTask) -> SubagentResult:
        """Execute one subagent task with shared governance components."""
        child_runtime = AgentRuntime(
            infer_fn=self._infer_fn,
            prompt_assembler=self._prompt_assembler,
            output_parser=self._output_parser,
            context_bus=self._context_bus,
            memory_bridge=self._memory_bridge,
            tool_registry=self._tool_registry,
            tool_executor=self._tool_executor,
            guardrail_engine=self._guardrail_engine,
            turn_checkpoint_store=self._turn_checkpoint_store,
            verification_suite=self._verification_suite,
            subagent_manager=None,
            hook_event_bus=self._hook_event_bus,
            auto_feedback_enabled=self._auto_feedback_enabled,
            max_feedback_rounds=self._max_feedback_rounds,
        )
        merged_metadata = dict(parent_task.metadata)
        merged_metadata.update(sub_task.metadata)
        merged_metadata.update(
            {
                "is_subagent": True,
                "parent_task_id": parent_task.task_id,
                "subagent_name": sub_task.name,
            }
        )
        child_task = RuntimeTask(
            user_input=sub_task.user_input,
            system_prompt=sub_task.system_prompt or parent_task.system_prompt,
            agent_name=parent_task.agent_name,
            provider=parent_task.provider,
            llm_config=dict(parent_task.llm_config),
            tool_definitions=list(parent_task.tool_definitions),
            memory_query=parent_task.memory_query,
            max_turns=sub_task.max_turns,
            metadata=merged_metadata,
        )
        child_state = RuntimeState()
        outcome = child_runtime.run_turn_loop(child_task, child_state)
        return SubagentResult(
            name=sub_task.name,
            mode=sub_task.mode,
            task_id=child_task.task_id,
            success=outcome.success,
            turns_executed=outcome.turns_executed,
            final_output=outcome.final_output,
            error=outcome.error,
            replay_events=list(child_state.conversation_history),
        )

    def _emit_runtime_hook_event(
        self,
        event: str,
        task: RuntimeTask,
        state: RuntimeState,
        metadata: dict[str, Any],
        *,
        raise_on_required_failure: bool = True,
    ) -> None:
        """Emit runtime lifecycle hook event and store report in state metadata."""
        subscriptions = self._resolve_runtime_subscriptions(task)
        if not subscriptions:
            return
        payload = HookEventPayload(event=event, context_id=task.task_id, metadata=metadata)
        report = self._hook_event_bus.dispatch(
            event=event,
            payload=payload,
            subscriptions=subscriptions,
            raise_on_required_failure=raise_on_required_failure,
        )
        reports = state.metadata.setdefault("runtime_hook_reports", [])
        if isinstance(reports, list):
            reports.append(report.model_dump(mode="json"))

    @staticmethod
    def _resolve_runtime_subscriptions(task: RuntimeTask) -> list[HookSubscription]:
        """Resolve runtime hook subscriptions from task metadata."""
        raw_subscriptions = task.metadata.get("hooks_subscriptions", [])
        if not isinstance(raw_subscriptions, list):
            return []

        subscriptions: list[HookSubscription] = []
        for item in raw_subscriptions:
            if isinstance(item, HookSubscription):
                subscriptions.append(item)
                continue
            if isinstance(item, dict):
                try:
                    subscriptions.append(HookSubscription(**item))
                except Exception:
                    continue
        return subscriptions
