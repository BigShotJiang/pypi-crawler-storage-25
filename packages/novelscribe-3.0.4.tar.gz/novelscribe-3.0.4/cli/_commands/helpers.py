"""Shared helpers for CLI commands."""

from __future__ import annotations

import logging
import os
import sys

PROVIDER_DEFAULT_MODELS: dict[str, str] = {
    "openai": "gpt-4o",
    "anthropic": "claude-sonnet-4-20250514",
    "google": "gemini-2.0-flash",
    "ollama": "llama3.2",
    "lm_studio": "lmstudio-community/llama3.2-3b-instruct",
    "minimax": "abab6.5s-chat",
    "zhipuai": "glm-4",
    "moonshot": "moonshot-v1-8k",
}


ENV_PROVIDER_KEYS: list[tuple[str, str]] = [
    ("openai", "OPENAI_API_KEY"),
    ("anthropic", "ANTHROPIC_API_KEY"),
    ("google", "GOOGLE_API_KEY"),
    ("minimax", "MINIMAX_API_KEY"),
    ("zhipuai", "ZHIPUAI_API_KEY"),
    ("moonshot", "MOONSHOT_API_KEY"),
    ("ollama", "OLLAMA_BASE_URL"),
    ("lm_studio", "LM_STUDIO_BASE_URL"),
]


def configure_logging(verbose: int = 0, debug: bool = False) -> None:
    """Configure logging based on verbosity level."""
    log_level = logging.DEBUG if debug else logging.INFO

    if verbose == 0:
        log_format = "%(message)s"
    elif verbose == 1:
        log_format = "%(levelname)s: %(message)s"
    else:
        log_format = "%(levelname)s [%(name)s]: %(message)s"

    logging.basicConfig(
        level=log_level,
        format=log_format,
        stream=sys.stdout,
        force=True,
    )


def _canonicalize_provider(provider: str) -> str:
    """Normalize provider aliases to canonical IDs."""
    normalized = (provider or "").strip().lower()
    if normalized in {"lm-studio", "lmstudio"}:
        return "lm_studio"
    return normalized


def _detect_provider_from_setup() -> str:
    """Detect provider from configured environment variables."""
    for provider, env_key in ENV_PROVIDER_KEYS:
        if os.getenv(env_key):
            return _canonicalize_provider(provider)
    return ""


def _default_model_for_provider(provider: str) -> str:
    """Return default model for known provider."""
    return PROVIDER_DEFAULT_MODELS.get(_canonicalize_provider(provider), "gpt-4o")


def _resolve_new_project_llm(provider: str, model: str) -> tuple[str, str]:
    """Resolve provider/model for `new` with setup inheritance."""
    explicit_provider = _canonicalize_provider(provider)
    explicit_model = (model or "").strip()

    setup_provider = _canonicalize_provider(os.getenv("SCRIBE_DEFAULT_PROVIDER", ""))
    setup_model = (os.getenv("SCRIBE_DEFAULT_MODEL", "") or "").strip()

    resolved_provider = (
        explicit_provider or setup_provider or _detect_provider_from_setup() or "openai"
    )

    if explicit_model:
        resolved_model = explicit_model
    elif setup_provider and setup_provider == resolved_provider and setup_model:
        resolved_model = setup_model
    else:
        resolved_model = _default_model_for_provider(resolved_provider)

    return resolved_provider, resolved_model
