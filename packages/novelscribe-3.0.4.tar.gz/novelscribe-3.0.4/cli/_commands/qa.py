"""CLI Commands for Quality Assurance System."""

import json
from pathlib import Path
from typing import Optional

import click

from core.benchmark_engine import BenchmarkingEngine
from core.benchmarking import BenchmarkType
from core.quality_gate import QualityGate, QualityLevel
from core.quality_metrics import QualityMetricsCalculator
from core.validation_system import RuleCategory, Severity, ValidationSystem
from qa_reporting_helpers import (
    build_comprehensive_report,
)
from services.quality_service import QualityService

__all__ = [
    "qa",
    "QualityGate",
    "BenchmarkingEngine",
    "QualityMetricsCalculator",
    "ValidationSystem",
    "QualityLevel",
    "BenchmarkType",
]


@click.group()
def qa():
    """Quality assurance commands for novel generation."""
    pass


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Specific chapter to analyze")
@click.option("--version", "-v", type=int, default=1, help="Draft version to analyze")
@click.option("--output", "-o", type=click.Path(), help="Output file for metrics")
@click.option(
    "--format",
    "-f",
    type=click.Choice(["text", "json", "markdown"]),
    default="text",
    help="Output format",
)
def analyze(
    project_name: str, chapter: Optional[int], version: int, output: Optional[str], format: str
):
    """Run quality analysis on project content."""
    svc = QualityService()
    project_path = svc.get_project_path(project_name)

    if chapter:
        content_path = project_path / f"chapter_{chapter:03d}.md"
        if not content_path.exists():
            click.echo(f"Error: Chapter {chapter} not found at {content_path}")
            return
        content = content_path.read_text()
        calc = QualityMetricsCalculator(project_root=project_path)
        metrics = calc.calculate_metrics(content, chapter, version)
        results = [metrics]
    else:
        results = []
        for content_file in sorted(project_path.glob("chapter_*.md")):
            chapter_num = int(content_file.stem.split("_")[1])
            content = content_file.read_text()
            calc = QualityMetricsCalculator(project_root=project_path)
            m = calc.calculate_metrics(content, chapter_num, version)
            results.append(m)

    if format == "json":
        output_data = [m.model_dump() for m in results]
        if output:
            Path(output).write_text(json.dumps(output_data, indent=2, default=str))
        else:
            click.echo(json.dumps(output_data, indent=2, default=str))
    elif format == "markdown":
        calc = QualityMetricsCalculator(project_root=project_path)
        for metrics in results:
            summary = calc.get_metrics_summary(metrics)
            if output:
                Path(output).write_text(summary)
            else:
                click.echo(summary)
                click.echo("---")
                click.echo()
    else:
        for metrics in results:
            click.echo(f"\n=== Chapter {metrics.chapter_number} (v{metrics.version}) ===")
            click.echo(f"Overall Quality Score: {metrics.overall_quality_score:.1%}")
            click.echo(f"Word Count: {metrics.word_count:,}")
            click.echo(f"Readability (Flesch-Kincaid): {metrics.flesch_kincaid:.1f}")
            click.echo(f"Dialogue Ratio: {metrics.dialogue_ratio:.1%}")
            click.echo(f"Speaker Clarity: {metrics.speaker_clarity:.1%}")
            click.echo(f"Vocabulary Diversity: {metrics.vocabulary_diversity:.1%}")
            click.echo(f"Passive Voice: {metrics.passive_voice_ratio:.1%}")

    click.echo(f"\n✅ Analyzed {len(results)} chapter(s)")


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, help="Specific chapter to validate")
@click.option("--rules", "-r", help="Comma-separated list of rule IDs to validate")
@click.option(
    "--category", "-cat", type=click.Choice(["content", "structure", "style", "continuity"])
)
@click.option("--severity", "-s", type=click.Choice(["error", "warning", "info"]))
@click.option("--output", "-o", type=click.Path(), help="Output file for report")
def validate(
    project_name: str,
    chapter: Optional[int],
    rules: Optional[str],
    category: Optional[str],
    severity: Optional[str],
    output: Optional[str],
):
    """Run validation checks on project content."""
    svc = QualityService()
    project_path = svc.get_project_path(project_name)
    validator = ValidationSystem(project_root=project_path)

    rule_ids = [r.strip() for r in rules.split(",")] if rules else None
    if category:
        validator.rules = {
            rid: rule
            for rid, rule in validator.rules.items()
            if rule.category == RuleCategory(category)
        }

    severity_filter = Severity(severity) if severity else None
    content_path = project_path

    if chapter:
        content_files = [content_path / f"chapter_{chapter:03d}.md"]
    else:
        content_files = sorted(content_path.glob("chapter_*.md"))

    all_results = []
    for content_file in content_files:
        if not content_file.exists():
            click.echo(f"Warning: {content_file} not found")
            continue
        content = content_file.read_text()
        report = validator.validate_content(
            content, context={"content_path": str(content_file)}, rule_ids=rule_ids
        )
        if severity_filter:
            report.results = [
                r for r in report.results if not r.passed and r.rule.severity == severity_filter
            ]
        all_results.append(report)

    for report in all_results:
        click.echo(validator.generate_report_summary(report))
        click.echo()

    if output:
        Path(output).write_text(
            json.dumps(
                {"timestamp": "now", "reports": [r.model_dump() for r in all_results]},
                indent=2,
                default=str,
            )
        )

    total_errors = sum(r.errors for r in all_results)
    total_warnings = sum(r.warnings for r in all_results)

    if total_errors > 0:
        click.echo(
            f"❌ Validation failed with {total_errors} error(s) and {total_warnings} warning(s)"
        )
    elif total_warnings > 0:
        click.echo(f"⚠️  Validation passed with {total_warnings} warning(s)")
    else:
        click.echo(f"✅ All validation checks passed for {len(all_results)} file(s)")


@qa.command()
@click.argument("project_name")
@click.option(
    "--category", "-cat", type=click.Choice(["performance", "quality", "style", "readability"])
)
@click.option("--benchmark", "-b", type=str, default="published_novel")
@click.option("--genre", "-g", type=str)
@click.option("--export", "-e", type=click.Path(), help="Export benchmark data to file")
def benchmark(
    project_name: str,
    category: Optional[str],
    benchmark: str,
    genre: Optional[str],
    export: Optional[str],
):
    """Run performance and quality benchmarks."""
    svc = QualityService()
    result = svc.run_benchmark(
        project_name, category=category, benchmark_type=category, genre=genre
    )

    click.echo(f"\n=== Benchmark Report: {project_name} ===")
    click.echo(f"Generated: {result.get('timestamp', 'N/A')}")
    click.echo(f"Performance Score: {result.get('performance_score', 'N/A')}")
    click.echo(f"Quality Score: {result.get('quality_score', 'N/A')}")
    click.echo(f"\n✅ Benchmark complete for {len(result.get('results', []))} results")

    if export:
        click.echo(f"\n✅ Benchmark data exported to {export}")


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True)
@click.option("--version", "-v", type=int, default=1)
@click.option(
    "--level", "-l", type=click.Choice(["bronze", "silver", "gold", "platinum"]), default="silver"
)
@click.option("--auto-fix", "-a", is_flag=True)
@click.option("--output", "-o", type=click.Path())
def gate_check(
    project_name: str, chapter: int, version: int, level: str, auto_fix: bool, output: Optional[str]
):
    """Check if content meets quality gate requirements."""
    svc = QualityService()
    try:
        result = svc.gate_check(project_name, chapter, tier=level)
        click.echo(f"✅ Gate check: {'PASSED' if result['passed'] else 'FAILED'}")
        click.echo(f"   Score: {result['overall_score']:.2%}")
        for rec in result.get("recommendations", [])[:3]:
            click.echo(f"   - {rec}")
    except FileNotFoundError as e:
        click.echo(f"Error: {e}")
    except Exception as e:
        click.echo(f"Error: {e}")


@qa.command()
@click.argument("project_name")
@click.option("--chapter", "-c", type=int, required=True)
@click.option("--from", "from_version", type=int, required=True)
@click.option("--to", "to_version", type=int, required=True)
@click.option("--output", "-o", type=click.Path())
def compare(
    project_name: str, chapter: int, from_version: int, to_version: int, output: Optional[str]
):
    """Compare quality metrics between two versions."""
    svc = QualityService()
    result = svc.compare_chapters(project_name, from_version, to_version)
    click.echo(f"Comparison: chapter_{result['ch1']} vs chapter_{result['ch2']}")
    click.echo(f"Winner: {result['winner']}")
    click.echo(f"Overall change: {result['comparison'].get('overall_quality_change', 0):.2%}")


@qa.command()
@click.argument("project_name")
@click.option("--output", "-o", type=click.Path())
def report(project_name: str, output: Optional[str]):
    """Generate comprehensive quality report."""
    svc = QualityService()
    project_path = svc.get_project_path(project_name)
    calc = QualityMetricsCalculator(project_root=project_path)
    validator = ValidationSystem(project_root=project_path)

    from core.benchmarking import BenchmarkingEngine
    from core.quality_gate import QualityGate

    engine = BenchmarkingEngine(project_root=project_path)
    gate = QualityGate(project_root=project_path)

    report_text, chapter_count = build_comprehensive_report(
        project_name=project_name,
        content_dir=project_path,
        calculator=calc,
        validator=validator,
        engine=engine,
        gate=gate,
        quality_level=QualityLevel.SILVER,
    )

    if output:
        Path(output).write_text(report_text)
        click.echo(f"✅ Comprehensive quality report saved to {output}")
    else:
        click.echo(report_text)
    click.echo(f"\n✅ Generated report for {chapter_count} chapter(s)")
