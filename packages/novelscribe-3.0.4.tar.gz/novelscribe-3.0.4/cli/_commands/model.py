"""AI model management commands — list, switch, show current model."""

from __future__ import annotations

import logging
import os
from pathlib import Path

import click

from cli._commands.helpers import (
    ENV_PROVIDER_KEYS,
    PROVIDER_DEFAULT_MODELS,
    _canonicalize_provider,
    _detect_provider_from_setup,
)
from cli._helpers.error_handling import handle_cli_exception


def _read_env_file() -> dict[str, str]:
    """Read .env file from novel_harness root."""
    env_file = Path(__file__).parent.parent / ".env"
    result: dict[str, str] = {}
    if not env_file.exists():
        return result
    for line in env_file.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if line and not line.startswith("#") and "=" in line:
            k, _, v = line.partition("=")
            result[k.strip()] = v.strip()
    return result


def _write_env_file(updates: dict[str, str]) -> Path:
    """Write updated .env file, preserving existing entries."""
    env_file = Path(__file__).parent.parent / ".env"
    existing = _read_env_file()
    existing.update(updates)
    lines = [f"{k}={v}" for k, v in existing.items() if v]
    env_file.write_text("\n".join(lines) + "\n", encoding="utf-8")
    return env_file


def _configured_providers() -> list[str]:
    """Return list of providers that have credentials configured."""
    configured: list[str] = []
    for provider, env_key in ENV_PROVIDER_KEYS:
        if os.getenv(env_key):
            configured.append(_canonicalize_provider(provider))
    return configured


@click.group()
def model():
    """AI model management — list, switch, show current model."""
    pass


@model.command("list")
@click.pass_context
def model_list(ctx: click.Context) -> None:
    """List all available models grouped by provider.

    Configured providers are marked with ✓. The active provider/model is
    highlighted with ★.
    """
    logger = logging.getLogger("scribe")

    configured = _configured_providers()
    active_provider = _canonicalize_provider(os.getenv("SCRIBE_DEFAULT_PROVIDER", ""))
    active_model = (os.getenv("SCRIBE_DEFAULT_MODEL", "") or "").strip()
    if not active_provider:
        active_provider = _detect_provider_from_setup()
    if not active_model and active_provider:
        active_model = PROVIDER_DEFAULT_MODELS.get(active_provider, "")

    logger.info("Available AI Models")
    logger.info("")

    for provider, default_model in sorted(PROVIDER_DEFAULT_MODELS.items()):
        is_configured = provider in configured
        is_active = provider == active_provider

        marker = "★" if is_active else ("✓" if is_configured else " ")
        provider_label = f"{marker} {provider}"
        model_label = default_model

        if is_active and active_model and active_model != default_model:
            model_label = f"{active_model} (default: {default_model})"
        elif is_active:
            model_label = f"{active_model}"

        logger.info(f"  {provider_label:20s} {model_label}")

    logger.info("")
    logger.info("  ★ = active   ✓ = configured")
    logger.info("  Use `scribe model switch <provider> [model]` to change.")


@model.command("switch")
@click.argument("provider")
@click.argument("model_name", required=False, default="")
@click.pass_context
def model_switch(ctx: click.Context, provider: str, model_name: str) -> None:
    """Switch the active AI provider and model.

    \b
    Switch to a provider (uses its default model):
      scribe model switch anthropic
      scribe model switch openai

    \b
    Switch to a specific model:
      scribe model switch anthropic claude-sonnet-4-20250514
      scribe model switch openai gpt-4o-mini
    """
    logger = logging.getLogger("scribe")
    debug = ctx.obj.get("debug", False)

    try:
        canonical = _canonicalize_provider(provider)
        if canonical not in PROVIDER_DEFAULT_MODELS:
            valid = ", ".join(sorted(PROVIDER_DEFAULT_MODELS.keys()))
            logger.error(f"Unknown provider: {provider}")
            logger.info(f"Valid providers: {valid}")
            return

        resolved_model = (
            model_name.strip() if model_name.strip() else PROVIDER_DEFAULT_MODELS[canonical]
        )

        env_updates = {
            "SCRIBE_DEFAULT_PROVIDER": canonical,
            "SCRIBE_DEFAULT_MODEL": resolved_model,
        }
        env_file = _write_env_file(env_updates)

        os.environ["SCRIBE_DEFAULT_PROVIDER"] = canonical
        os.environ["SCRIBE_DEFAULT_MODEL"] = resolved_model

        logger.info(f"✅ Switched to {canonical} / {resolved_model}")
        logger.info(f"   Saved to: {env_file}")

    except Exception as e:
        handle_cli_exception(logger, f"Failed to switch model: {e}", e, debug=debug)


@model.command("current")
@click.pass_context
def model_current(ctx: click.Context) -> None:
    """Show the currently active provider and model."""
    logger = logging.getLogger("scribe")

    provider = _canonicalize_provider(os.getenv("SCRIBE_DEFAULT_PROVIDER", ""))
    model_name = (os.getenv("SCRIBE_DEFAULT_MODEL", "") or "").strip()

    if not provider:
        provider = _detect_provider_from_setup()
    if not model_name and provider:
        model_name = PROVIDER_DEFAULT_MODELS.get(provider, "")

    if not provider:
        logger.info("No AI provider configured.")
        logger.info("Run `scribe setup apikey <provider> <key>` to configure one.")
        return

    configured = _configured_providers()
    has_key = provider in configured

    logger.info(f"Provider:  {provider} {'(key ✓)' if has_key else '(no key)'}")
    logger.info(f"Model:     {model_name}")

    if not has_key:
        logger.info("")
        logger.info(f"⚠️  No API key detected for {provider}.")
        logger.info(f"   Run `scribe setup apikey {provider} <your-key>` to add one.")
