from __future__ import annotations

import enum
import os
import pathlib
import typing
from typing import Union


# Types

Filename = Union[str, pathlib.Path]
IO: typing.TypeAlias = Union[typing.IO[str], typing.IO[bytes]]  # type: ignore[name-defined]


# Exceptions

class LockException(Exception):
	LOCK_FAILED = 1

	def __init__(self, *args: typing.Any, fh: Union[IO, int, None] = None, **kwargs: typing.Any) -> None:
		self.fh = fh
		super().__init__(*args)


class AlreadyLocked(LockException):
	pass


# Constants / Flags

if os.name == 'nt':
	import msvcrt
	_EX, _SH, _NB, _UN = 0x1, 0x2, 0x4, msvcrt.LK_UNLCK  # type: ignore[attr-defined]
elif os.name == 'posix':
	import fcntl
	_EX, _SH, _NB, _UN = fcntl.LOCK_EX, fcntl.LOCK_SH, fcntl.LOCK_NB, fcntl.LOCK_UN
else:
	raise RuntimeError('filelock only supports nt and posix platforms')


class LockFlags(enum.IntFlag):
	EXCLUSIVE    = _EX
	SHARED       = _SH
	NON_BLOCKING = _NB
	UNBLOCK      = _UN


# lock / unlock

if os.name == 'nt':
	import pywintypes, win32con, win32file, winerror

	_overlapped = pywintypes.OVERLAPPED()

	def lock(file: IO, flags: LockFlags = LockFlags.EXCLUSIVE | LockFlags.NON_BLOCKING) -> None:
		mode = 0
		if flags & LockFlags.NON_BLOCKING:
			mode |= win32con.LOCKFILE_FAIL_IMMEDIATELY
		if flags & LockFlags.EXCLUSIVE:
			mode |= win32con.LOCKFILE_EXCLUSIVE_LOCK

		pos = file.tell()
		if pos:
			file.seek(0)
		try:
			win32file.LockFileEx(msvcrt.get_osfhandle(file.fileno()), mode, 0, -0x10000, _overlapped)  # type: ignore[attr-defined]
		except pywintypes.error as e:
			if e.winerror == winerror.ERROR_LOCK_VIOLATION:
				raise AlreadyLocked(LockException.LOCK_FAILED, e.strerror, fh=file) from e
			raise
		finally:
			if pos:
				file.seek(pos)

	def unlock(file: IO) -> None:
		pos = file.tell()
		if pos:
			file.seek(0)
		try:
			win32file.UnlockFileEx(msvcrt.get_osfhandle(file.fileno()), 0, -0x10000, _overlapped)  # type: ignore[attr-defined]
		except pywintypes.error as e:
			if e.winerror != winerror.ERROR_NOT_LOCKED:
				raise
		finally:
			if pos:
				file.seek(pos)

else:  # posix
	import errno

	LOCKER: typing.Callable[[int | IO, int], typing.Any] = fcntl.flock

	def lock(file: Union[int, IO], flags: LockFlags = LockFlags.EXCLUSIVE | LockFlags.NON_BLOCKING) -> None:  # type: ignore[misc]
		if (flags & LockFlags.NON_BLOCKING) and not (flags & (LockFlags.SHARED | LockFlags.EXCLUSIVE)):
			raise RuntimeError('NON_BLOCKING requires SHARED or EXCLUSIVE to be set')
		try:
			LOCKER(file, flags)
		except OSError as e:
			if e.errno in (errno.EACCES, errno.EAGAIN):
				raise AlreadyLocked(e, fh=file) from e
			raise LockException(e, fh=file) from e
		except EOFError as e:
			raise LockException(e, fh=file) from e

	def unlock(file: IO) -> None:  # type: ignore[misc]
		LOCKER(file.fileno(), LockFlags.UNBLOCK)