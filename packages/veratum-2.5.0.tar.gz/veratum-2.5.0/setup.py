#!/usr/bin/env python
"""Setup configuration for Veratum SDK."""

from setuptools import setup, find_packages

with open("README.md", "r", encoding="utf-8") as fh:
    long_description = fh.read()

setup(
    name="veratum",
    version="2.5.0",
    author="Ali Ashkir",
    author_email="ali@veratum.ai",
    description="Litigation-grade evidence infrastructure for EU AI Act compliance",
    long_description=long_description,
    long_description_content_type="text/markdown",
    url="https://veratum.ai",
    project_urls={
        "Bug Tracker": "https://github.com/Alithecoder1/veratum-v2/issues",
        "Documentation": "https://docs.veratum.ai",
        "Source Code": "https://github.com/Alithecoder1/veratum-v2/tree/main/packages/sdk-python",
    },
    packages=find_packages(),
    classifiers=[
        "Development Status :: 4 - Beta",
        "Intended Audience :: Developers",
        "Topic :: Software Development :: Libraries :: Python Modules",
        "Topic :: Office/Business",
        "Topic :: Legal",
        "License :: OSI Approved :: MIT License",
        "Programming Language :: Python :: 3",
        "Programming Language :: Python :: 3.8",
        "Programming Language :: Python :: 3.9",
        "Programming Language :: Python :: 3.10",
        "Programming Language :: Python :: 3.11",
        "Programming Language :: Python :: 3.12",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.8",
    install_requires=[
        "requests>=2.28.0",
    ],
    extras_require={
        "dev": [
            "pytest>=7.0",
            "pytest-cov>=4.0",
            "black>=23.0",
            "mypy>=1.0",
            "ruff>=0.1.0",
        ],
    },
    keywords="veratum audit ai compliance evidence security",
    include_package_data=True,
    zip_safe=False,
)
