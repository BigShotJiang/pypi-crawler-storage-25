"""OpenTelemetry integration for Veratum evidence infrastructure.

Schema v2.5.0 — Bridges OTel GenAI semantic conventions (v1.37+) with
Veratum cryptographic receipts. Every gen_ai.* span automatically gets
a litigation-grade evidence receipt.

OTel GenAI semantic conventions define standardized attributes for AI
inference operations. This module maps those attributes to Veratum receipt
fields, creating a cryptographic audit trail from existing observability
instrumentation.

Attribute mapping (OTel GenAI → Veratum receipt):
    gen_ai.system           → provider
    gen_ai.request.model    → model
    gen_ai.usage.input_tokens  → tokens_in
    gen_ai.usage.output_tokens → tokens_out
    gen_ai.request.temperature → temperature
    gen_ai.request.top_p       → top_p
    gen_ai.request.seed        → seed
    gen_ai.response.model      → model_version_pin
    gen_ai.operation.name      → decision_type

References:
    - OpenTelemetry GenAI Semantic Conventions v1.37+
      https://opentelemetry.io/docs/specs/semconv/gen-ai/
    - ISO/IEC DIS 24970:2025 (AI system logging)
    - EU AI Act Article 12 (automatic logging)

Usage:
    from opentelemetry import trace
    from opentelemetry.sdk.trace import TracerProvider
    from veratum.otel import VeratumSpanProcessor

    provider = TracerProvider()
    provider.add_span_processor(VeratumSpanProcessor(
        api_key="vsk_...",
        endpoint="https://api.veratum.ai/v1",
        vertical="hiring",
    ))
    trace.set_tracer_provider(provider)

    # Now any gen_ai.* span automatically creates a Veratum receipt
"""

from __future__ import annotations

import hashlib
import logging
import threading
from typing import Any, Dict, List, Optional

logger = logging.getLogger(__name__)

# GenAI semantic convention attribute names (OTel v1.37+)
_GENAI_SYSTEM = "gen_ai.system"
_GENAI_REQUEST_MODEL = "gen_ai.request.model"
_GENAI_RESPONSE_MODEL = "gen_ai.response.model"
_GENAI_OPERATION = "gen_ai.operation.name"
_GENAI_INPUT_TOKENS = "gen_ai.usage.input_tokens"
_GENAI_OUTPUT_TOKENS = "gen_ai.usage.output_tokens"
_GENAI_TEMPERATURE = "gen_ai.request.temperature"
_GENAI_TOP_P = "gen_ai.request.top_p"
_GENAI_SEED = "gen_ai.request.seed"
_GENAI_PROMPT = "gen_ai.prompt"
_GENAI_COMPLETION = "gen_ai.completion"

# OTel GenAI system values → Veratum provider names
_SYSTEM_MAP = {
    "openai": "openai",
    "anthropic": "anthropic",
    "google_ai": "google",
    "google_vertex_ai": "google",
    "aws_bedrock": "bedrock",
    "azure_openai": "azure",
    "mistral_ai": "mistral",
    "cohere": "cohere",
    "meta": "meta",
}


def _hash_text(text: str) -> str:
    """SHA-256 hash a string, returning lowercase hex."""
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def span_to_receipt_fields(span) -> Optional[Dict[str, Any]]:
    """Extract Veratum receipt fields from a finished OTel span.

    Only processes spans that contain gen_ai.* attributes. Non-GenAI
    spans are silently skipped (returns None).

    Args:
        span: A finished ReadableSpan from the OTel SDK.

    Returns:
        Dict of receipt fields ready for VeratumSDK.create_receipt(),
        or None if the span is not a GenAI span.
    """
    attrs = dict(span.attributes or {})

    # Only process GenAI spans
    system = attrs.get(_GENAI_SYSTEM)
    model = attrs.get(_GENAI_REQUEST_MODEL)
    if not system and not model:
        return None

    # Map provider
    provider = _SYSTEM_MAP.get(str(system), str(system)) if system else "unknown"

    # Extract token counts
    tokens_in = int(attrs.get(_GENAI_INPUT_TOKENS, 0))
    tokens_out = int(attrs.get(_GENAI_OUTPUT_TOKENS, 0))

    # Hash prompt/completion if available (never store plaintext)
    prompt_text = attrs.get(_GENAI_PROMPT, "")
    completion_text = attrs.get(_GENAI_COMPLETION, "")
    prompt_hash = _hash_text(str(prompt_text)) if prompt_text else _hash_text("")
    response_hash = _hash_text(str(completion_text)) if completion_text else _hash_text("")

    # Map operation name to decision type
    operation = attrs.get(_GENAI_OPERATION, "chat")
    decision_type_map = {
        "chat": "content_generation",
        "text_completion": "content_generation",
        "embeddings": "embedding",
        "create_agent": "agent_action",
        "execute_tool": "tool_use",
    }
    decision_type = decision_type_map.get(str(operation), str(operation))

    # Build receipt fields
    fields: Dict[str, Any] = {
        "model": str(model or "unknown"),
        "provider": provider,
        "tokens_in": tokens_in,
        "tokens_out": tokens_out,
        "prompt_hash": prompt_hash,
        "response_hash": response_hash,
        "decision_type": decision_type,
    }

    # v2.5.0: Capture OTel trace/span IDs for cross-correlation
    ctx = span.context
    if ctx and ctx.trace_id:
        fields["otel_trace_id"] = format(ctx.trace_id, "032x")
    if ctx and ctx.span_id:
        fields["otel_span_id"] = format(ctx.span_id, "016x")

    # Model reproducibility fields
    response_model = attrs.get(_GENAI_RESPONSE_MODEL)
    if response_model:
        fields["model_version_pin"] = str(response_model)

    temperature = attrs.get(_GENAI_TEMPERATURE)
    if temperature is not None:
        fields["temperature"] = float(temperature)

    top_p = attrs.get(_GENAI_TOP_P)
    if top_p is not None:
        fields["top_p"] = float(top_p)

    seed = attrs.get(_GENAI_SEED)
    if seed is not None:
        fields["seed"] = int(seed)

    # Capture span timing as metadata
    if span.start_time and span.end_time:
        latency_ns = span.end_time - span.start_time
        fields["metadata"] = {
            "otel_span_name": span.name,
            "otel_latency_ms": latency_ns / 1_000_000,
        }

    return fields


class VeratumSpanProcessor:
    """OTel SpanProcessor that creates Veratum receipts from GenAI spans.

    Implements the OpenTelemetry SpanProcessor interface. When a GenAI
    span ends, it extracts the standardized gen_ai.* attributes and
    creates a cryptographic evidence receipt via the Veratum SDK.

    Non-GenAI spans are silently ignored — this processor can safely
    coexist with other span processors in the same TracerProvider.

    This processor is designed to fail open: if receipt creation fails
    (network error, auth error, etc.), the span export continues normally.
    Errors are logged but never propagated to the application.

    Args:
        api_key: Veratum API key (vsk_...).
        endpoint: Veratum API endpoint. Defaults to VERATUM_ENDPOINT env
            or https://api.veratum.ai/v1.
        vertical: Industry vertical for receipts (default: 'general').
        audit_level: AuditLevel.LIGHT or AuditLevel.FULL.
        batch_size: Number of receipts to buffer before flushing.
        flush_interval: Seconds between automatic flushes.

    Example:
        >>> from opentelemetry.sdk.trace import TracerProvider
        >>> provider = TracerProvider()
        >>> provider.add_span_processor(VeratumSpanProcessor(api_key="vsk_test_..."))
    """

    def __init__(
        self,
        api_key: str,
        endpoint: Optional[str] = None,
        vertical: str = "general",
        audit_level: Optional[Any] = None,
        batch_size: int = 2048,
        flush_interval: float = 1.0,
    ) -> None:
        self._api_key = api_key
        self._endpoint = endpoint
        self._vertical = vertical
        self._audit_level = audit_level
        self._batch_size = batch_size
        self._flush_interval = flush_interval
        self._sdk = None  # Lazy init
        self._init_lock = threading.Lock()
        self._receipt_count = 0
        self._error_count = 0

    def _ensure_sdk(self):
        """Lazy-initialize the Veratum SDK on first GenAI span."""
        if self._sdk is not None:
            return
        with self._init_lock:
            if self._sdk is not None:
                return
            try:
                from .core.sdk import VeratumSDK
                from .core.tiers import AuditLevel

                kwargs = {
                    "api_key": self._api_key,
                    "vertical": self._vertical,
                    "buffered": True,
                    "buffer_size": self._batch_size,
                    "flush_interval": self._flush_interval,
                }
                if self._endpoint:
                    kwargs["endpoint"] = self._endpoint
                if self._audit_level:
                    kwargs["audit_level"] = self._audit_level

                self._sdk = VeratumSDK(**kwargs)
                logger.info("Veratum OTel SpanProcessor initialized (endpoint=%s)", self._endpoint)
            except Exception:
                logger.exception("Failed to initialize Veratum SDK for OTel integration")

    def on_start(self, span, parent_context=None) -> None:
        """Called when a span starts. No-op for Veratum."""
        pass

    def on_end(self, span) -> None:
        """Called when a span ends. Creates a Veratum receipt for GenAI spans."""
        try:
            fields = span_to_receipt_fields(span)
            if fields is None:
                return  # Not a GenAI span

            self._ensure_sdk()
            if self._sdk is None:
                return  # SDK init failed — fail open

            # Create receipt via the evidence engine (non-blocking, buffered)
            from .core.evidence import get_evidence_engine

            engine = get_evidence_engine()
            if engine:
                receipt = engine.create_evidence(
                    prompt_hash=fields["prompt_hash"],
                    response_hash=fields["response_hash"],
                    model=fields["model"],
                    provider=fields["provider"],
                    tokens_in=fields["tokens_in"],
                    tokens_out=fields["tokens_out"],
                    decision_type=fields["decision_type"],
                    vertical=self._vertical,
                    otel_trace_id=fields.get("otel_trace_id"),
                    otel_span_id=fields.get("otel_span_id"),
                    model_version_pin=fields.get("model_version_pin"),
                    temperature=fields.get("temperature"),
                    top_p=fields.get("top_p"),
                    seed=fields.get("seed"),
                    metadata=fields.get("metadata"),
                )
                if receipt:
                    self._receipt_count += 1
                    logger.debug(
                        "Veratum receipt created from OTel span: %s (total: %d)",
                        receipt.get("entry_hash", "")[:16],
                        self._receipt_count,
                    )
        except Exception:
            self._error_count += 1
            logger.debug("Veratum receipt creation failed (errors: %d)", self._error_count)

    def shutdown(self) -> None:
        """Flush pending receipts and shut down the SDK."""
        if self._sdk:
            try:
                self._sdk.flush(timeout=10.0)
                self._sdk.close()
            except Exception:
                logger.exception("Error during Veratum OTel processor shutdown")
        logger.info(
            "Veratum OTel SpanProcessor shut down (receipts: %d, errors: %d)",
            self._receipt_count,
            self._error_count,
        )

    def force_flush(self, timeout_millis: int = 30000) -> bool:
        """Flush pending receipts.

        Args:
            timeout_millis: Maximum time to wait for flush.

        Returns:
            True if flush completed within timeout.
        """
        if self._sdk:
            try:
                self._sdk.flush(timeout=timeout_millis / 1000)
                return True
            except Exception:
                logger.exception("Error during Veratum OTel force_flush")
                return False
        return True

    @property
    def stats(self) -> Dict[str, int]:
        """Return processor statistics."""
        return {
            "receipts_created": self._receipt_count,
            "errors": self._error_count,
        }
