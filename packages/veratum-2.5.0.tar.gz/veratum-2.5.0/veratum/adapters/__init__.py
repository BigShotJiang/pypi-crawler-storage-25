"""
Veratum Adapters Package - Model inference adapters for various backends.

This package provides adapters for model inference across different deployment
scenarios:

- LocalModelAdapter: Locally-hosted models (Ollama, vLLM, Transformers, llama.cpp)
- [CloudAPIAdapter]: Cloud API providers (OpenAI, Anthropic, etc.) - coming in Phase 4
- [CustomAdapter]: User-defined custom inference backends - coming in Phase 5

Each adapter provides:
1. Unified inference interface via generate()
2. Automatic token counting
3. Model versioning through model_version_pin
4. Veratum receipt generation via generate_with_receipt()
"""

from .local_model import LocalModelAdapter, wrap_local_model

__all__ = [
    "LocalModelAdapter",
    "wrap_local_model",
]

__version__ = "2.0.0"
