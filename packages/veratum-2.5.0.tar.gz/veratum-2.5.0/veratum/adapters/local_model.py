"""
Local Model Adapter (Phase 3) for Veratum Python SDK.

Enables Veratum receipt generation for locally-hosted models including:
- Ollama
- vLLM
- llama.cpp
- HuggingFace Transformers

This adapter auto-detects available backends and provides a unified interface
for model inference with automatic receipt generation.
"""

import hashlib
import json
import logging
from abc import ABC, abstractmethod
from pathlib import Path
from typing import Any, Dict, Optional, Tuple

logger = logging.getLogger(__name__)


class LocalModelAdapter:
    """
    Adapter for locally-hosted language models with Veratum receipt support.

    Supports automatic backend detection and unified inference interface across
    Ollama, vLLM, llama.cpp, and HuggingFace Transformers.

    Attributes:
        model_path: Path to model weights or model identifier (e.g., "llama2" for Ollama)
        backend: Detected or specified backend ("ollama", "vllm", "transformers", "llama_cpp")
        temperature: Sampling temperature (0.0 = deterministic, >0 = sampling)
        max_tokens: Maximum tokens to generate
        top_p: Nucleus sampling parameter
        top_k: Top-k sampling parameter
    """

    SUPPORTED_BACKENDS = ["ollama", "vllm", "transformers", "llama_cpp"]

    def __init__(
        self,
        model_path: str,
        backend: str = "auto",
        temperature: float = 0.7,
        max_tokens: int = 512,
        top_p: float = 0.95,
        top_k: int = 40,
        **kwargs: Any,
    ) -> None:
        """
        Initialize LocalModelAdapter with model configuration.

        Args:
            model_path: Path to model weights file or model identifier string.
                For Ollama, this is the model name (e.g., "llama2", "mistral").
                For vLLM/Transformers, this is a file path or HuggingFace model ID.
            backend: Backend to use ("auto", "ollama", "vllm", "transformers", "llama_cpp").
                If "auto", backends are tried in order: ollama → vllm → transformers → llama_cpp.
            temperature: Sampling temperature. 0.0 for deterministic, >0 for sampling.
            max_tokens: Maximum number of tokens to generate.
            top_p: Nucleus sampling parameter.
            top_k: Top-k sampling parameter.
            **kwargs: Additional backend-specific arguments.

        Raises:
            RuntimeError: If no supported backend is available.
            ValueError: If specified backend is not supported.
        """
        self.model_path = model_path
        self.temperature = temperature
        self.max_tokens = max_tokens
        self.top_p = top_p
        self.top_k = top_k
        self.extra_kwargs = kwargs

        # Validate backend parameter
        if backend != "auto" and backend not in self.SUPPORTED_BACKENDS:
            raise ValueError(
                f"Unsupported backend: {backend}. "
                f"Must be one of: auto, {', '.join(self.SUPPORTED_BACKENDS)}"
            )

        # Detect or validate backend
        if backend == "auto":
            self.backend = self._detect_backend()
        else:
            self.backend = backend

        if not self.backend:
            raise RuntimeError(
                "No supported backend available. Please install one of: "
                "ollama, vllm, transformers, or llama-cpp-python."
            )

        logger.info(f"LocalModelAdapter initialized with backend: {self.backend}")
        logger.info(f"Model path/identifier: {self.model_path}")

        # Cache model version pin
        self._model_version_pin: Optional[str] = None

    def _detect_backend(self) -> Optional[str]:
        """
        Auto-detect available backend by attempting imports in priority order.

        Priority order:
        1. ollama - lightweight, simple API
        2. vllm - high-throughput inference server
        3. transformers - HuggingFace standard library
        4. llama_cpp - pure C++ implementation

        Returns:
            Detected backend name or None if no backends available.
        """
        backends_to_try = ["ollama", "vllm", "transformers", "llama_cpp"]

        for backend in backends_to_try:
            try:
                if backend == "ollama":
                    import ollama  # noqa: F401
                    logger.debug("Detected ollama backend")
                    return "ollama"
                elif backend == "vllm":
                    from vllm import LLM  # noqa: F401
                    logger.debug("Detected vllm backend")
                    return "vllm"
                elif backend == "transformers":
                    from transformers import pipeline  # noqa: F401
                    logger.debug("Detected transformers backend")
                    return "transformers"
                elif backend == "llama_cpp":
                    from llama_cpp import Llama  # noqa: F401
                    logger.debug("Detected llama_cpp backend")
                    return "llama_cpp"
            except ImportError:
                logger.debug(f"Backend {backend} not available")
                continue

        return None

    def _hash_model_weights(self, path: str, chunk_size: int = 8192) -> str:
        """
        Compute SHA-256 hash of model weights file.

        For local models, the weight hash serves as the definitive version pin,
        ensuring reproducibility and cache invalidation.

        Args:
            path: Path to model weights file.
            chunk_size: Bytes to read per iteration for memory efficiency.

        Returns:
            Hex-encoded SHA-256 hash (first 16 characters used as version pin).

        Raises:
            FileNotFoundError: If model file does not exist.
            IOError: If file cannot be read.
        """
        model_file = Path(path)

        if not model_file.exists():
            raise FileNotFoundError(f"Model file not found: {path}")

        hasher = hashlib.sha256()
        try:
            with open(model_file, "rb") as f:
                while chunk := f.read(chunk_size):
                    hasher.update(chunk)
            full_hash = hasher.hexdigest()
            logger.debug(f"Computed model hash for {path}: {full_hash}")
            return full_hash
        except IOError as e:
            raise IOError(f"Failed to read model file {path}: {e}")

    def _get_model_version_pin(self) -> str:
        """
        Get or compute model version pin.

        For local models, version pin = SHA-256 hash of weights (first 16 chars).
        Result is cached after first computation.

        Returns:
            Model version pin string.
        """
        if self._model_version_pin:
            return self._model_version_pin

        # For Ollama/vLLM with remote identifiers, use the model path as-is
        if self.backend in ["ollama", "vllm"] and not Path(self.model_path).exists():
            self._model_version_pin = hashlib.sha256(
                self.model_path.encode()
            ).hexdigest()[:16]
            return self._model_version_pin

        # For local weight files, hash the file
        try:
            full_hash = self._hash_model_weights(self.model_path)
            self._model_version_pin = full_hash[:16]
        except (FileNotFoundError, IOError) as e:
            logger.warning(f"Could not hash model weights: {e}. Using path hash.")
            self._model_version_pin = hashlib.sha256(
                self.model_path.encode()
            ).hexdigest()[:16]

        return self._model_version_pin

    def _call_ollama(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Call Ollama backend for inference.

        Args:
            prompt: Input prompt text.
            **kwargs: Additional inference parameters.

        Returns:
            Response dict with keys: response, tokens_in, tokens_out.

        Raises:
            RuntimeError: If Ollama call fails or cannot parse response.
        """
        try:
            import ollama
        except ImportError:
            raise RuntimeError("ollama library not installed")

        try:
            response = ollama.generate(
                model=self.model_path,
                prompt=prompt,
                temperature=self.temperature,
                num_predict=self.max_tokens,
                top_p=self.top_p,
                top_k=self.top_k,
                stream=False,
            )

            # Extract token counts from Ollama response
            tokens_in = response.get("prompt_eval_count", 0)
            tokens_out = response.get("eval_count", 0)

            return {
                "response": response.get("response", ""),
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
            }
        except Exception as e:
            raise RuntimeError(f"Ollama inference failed: {e}")

    def _call_vllm(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Call vLLM backend for inference.

        Args:
            prompt: Input prompt text.
            **kwargs: Additional inference parameters.

        Returns:
            Response dict with keys: response, tokens_in, tokens_out.

        Raises:
            RuntimeError: If vLLM call fails or cannot parse response.
        """
        try:
            from vllm import LLM, SamplingParams
        except ImportError:
            raise RuntimeError("vllm library not installed")

        try:
            llm = LLM(model=self.model_path)
            sampling_params = SamplingParams(
                temperature=self.temperature,
                top_p=self.top_p,
                top_k=self.top_k,
                max_tokens=self.max_tokens,
            )

            outputs = llm.generate([prompt], sampling_params)

            if not outputs:
                raise RuntimeError("vLLM returned empty output")

            output = outputs[0]
            response_text = output.outputs[0].text

            # Extract token counts from vLLM
            tokens_in = len(output.prompt_token_ids)
            tokens_out = sum(len(o.token_ids) for o in output.outputs)

            return {
                "response": response_text,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
            }
        except Exception as e:
            raise RuntimeError(f"vLLM inference failed: {e}")

    def _call_transformers(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Call HuggingFace Transformers backend for inference.

        Args:
            prompt: Input prompt text.
            **kwargs: Additional inference parameters.

        Returns:
            Response dict with keys: response, tokens_in, tokens_out.

        Raises:
            RuntimeError: If Transformers call fails or cannot parse response.
        """
        try:
            from transformers import pipeline, AutoTokenizer
        except ImportError:
            raise RuntimeError("transformers library not installed")

        try:
            # Initialize pipeline and tokenizer
            pipe = pipeline(
                "text-generation",
                model=self.model_path,
                device_map="auto",
            )
            tokenizer = AutoTokenizer.from_pretrained(self.model_path)

            # Tokenize input
            input_ids = tokenizer.encode(prompt, return_tensors="pt")
            tokens_in = input_ids.shape[1]

            # Generate
            outputs = pipe(
                prompt,
                max_new_tokens=self.max_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                top_k=self.top_k,
                do_sample=self.temperature > 0,
                return_full_text=False,
            )

            if not outputs or not outputs[0]:
                raise RuntimeError("Transformers returned empty output")

            response_text = outputs[0].get("generated_text", "")

            # Estimate output tokens
            output_ids = tokenizer.encode(response_text, return_tensors="pt")
            tokens_out = output_ids.shape[1]

            return {
                "response": response_text,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
            }
        except Exception as e:
            raise RuntimeError(f"Transformers inference failed: {e}")

    def _call_llama_cpp(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Call llama.cpp backend for inference.

        Args:
            prompt: Input prompt text.
            **kwargs: Additional inference parameters.

        Returns:
            Response dict with keys: response, tokens_in, tokens_out.

        Raises:
            RuntimeError: If llama.cpp call fails or cannot parse response.
        """
        try:
            from llama_cpp import Llama
        except ImportError:
            raise RuntimeError("llama-cpp-python library not installed")

        try:
            llm = Llama(
                model_path=self.model_path,
                n_gpu_layers=-1,  # Use GPU acceleration if available
                verbose=False,
            )

            # Generate
            output = llm(
                prompt=prompt,
                max_tokens=self.max_tokens,
                temperature=self.temperature,
                top_p=self.top_p,
                top_k=self.top_k,
                echo=False,
            )

            response_text = output.get("choices", [{}])[0].get("text", "")

            # Extract token counts
            usage = output.get("usage", {})
            tokens_in = usage.get("prompt_tokens", 0)
            tokens_out = usage.get("completion_tokens", 0)

            return {
                "response": response_text,
                "tokens_in": tokens_in,
                "tokens_out": tokens_out,
            }
        except Exception as e:
            raise RuntimeError(f"llama.cpp inference failed: {e}")

    def generate(self, prompt: str, **kwargs: Any) -> Dict[str, Any]:
        """
        Generate text using the local model with full metadata.

        Calls the appropriate backend and returns a comprehensive response including
        token counts, model information, and inference metadata.

        Args:
            prompt: Input prompt text.
            **kwargs: Additional inference parameters (override instance defaults).

        Returns:
            Dict with keys:
                - response: Generated text
                - tokens_in: Input token count
                - tokens_out: Output token count
                - model: Model identifier/path
                - provider: Always "local/{backend}"
                - model_version_pin: SHA-256 hash of weights (first 16 chars)
                - inference_mode: "deterministic" if temp=0, else "sampling"
                - temperature: Sampling temperature used
                - backend: Backend used ("ollama", "vllm", "transformers", "llama_cpp")

        Raises:
            RuntimeError: If inference fails.
        """
        # Merge kwargs with instance defaults
        temp = kwargs.get("temperature", self.temperature)

        # Call appropriate backend
        backend_method = getattr(self, f"_call_{self.backend}", None)
        if not backend_method:
            raise RuntimeError(f"Backend method not found for {self.backend}")

        try:
            result = backend_method(prompt, **kwargs)
        except RuntimeError as e:
            logger.error(f"Inference failed with {self.backend}: {e}")
            raise

        # Add metadata
        inference_mode = "deterministic" if temp == 0 else "sampling"
        model_version_pin = self._get_model_version_pin()

        response = {
            "response": result["response"],
            "tokens_in": result["tokens_in"],
            "tokens_out": result["tokens_out"],
            "model": self.model_path,
            "provider": f"local/{self.backend}",
            "model_version_pin": model_version_pin,
            "inference_mode": inference_mode,
            "temperature": temp,
            "backend": self.backend,
        }

        logger.info(
            f"Generated {result['tokens_out']} tokens "
            f"(input: {result['tokens_in']}) via {self.backend}"
        )

        return response

    def generate_with_receipt(
        self,
        prompt: str,
        receipt_generator: Any,
        **kwargs: Any,
    ) -> Tuple[str, Dict[str, Any]]:
        """
        Generate text and create a Veratum receipt automatically.

        Combines generation with receipt creation in a single atomic operation.

        Args:
            prompt: Input prompt text.
            receipt_generator: Veratum receipt generator instance with
                create_receipt(inference_metadata) method.
            **kwargs: Additional inference parameters.

        Returns:
            Tuple of:
                - Generated response text (str)
                - Receipt dict from receipt_generator.create_receipt()

        Raises:
            RuntimeError: If generation or receipt creation fails.
            TypeError: If receipt_generator lacks required methods.
        """
        if not hasattr(receipt_generator, "create_receipt"):
            raise TypeError(
                "receipt_generator must have create_receipt(inference_metadata) method"
            )

        # Generate with full metadata
        generation_result = self.generate(prompt, **kwargs)

        # Create receipt from metadata
        inference_metadata = {
            "model": generation_result["model"],
            "provider": generation_result["provider"],
            "model_version_pin": generation_result["model_version_pin"],
            "inference_mode": generation_result["inference_mode"],
            "temperature": generation_result["temperature"],
            "tokens_in": generation_result["tokens_in"],
            "tokens_out": generation_result["tokens_out"],
            "backend": generation_result["backend"],
        }

        try:
            receipt = receipt_generator.create_receipt(inference_metadata)
        except Exception as e:
            logger.error(f"Receipt creation failed: {e}")
            raise RuntimeError(f"Receipt creation failed: {e}")

        logger.info(f"Generated response with receipt: {receipt.get('id', 'unknown')}")

        return generation_result["response"], receipt


def wrap_local_model(model_path: str, **kwargs: Any) -> LocalModelAdapter:
    """
    Convenience function to create and configure a LocalModelAdapter.

    Simplifies the common case of initializing a local model with standard settings.

    Args:
        model_path: Path to model weights file or model identifier.
        **kwargs: Configuration options passed to LocalModelAdapter.__init__()
            Supported: backend, temperature, max_tokens, top_p, top_k, etc.

    Returns:
        Configured LocalModelAdapter instance ready for inference.

    Example:
        >>> adapter = wrap_local_model(
        ...     "models/llama2-7b.gguf",
        ...     backend="llama_cpp",
        ...     temperature=0.7,
        ...     max_tokens=256
        ... )
        >>> result = adapter.generate("What is AI?")
        >>> print(result["response"])
    """
    return LocalModelAdapter(model_path, **kwargs)


__all__ = [
    "LocalModelAdapter",
    "wrap_local_model",
]
