# Veratum SDK Integration Examples

## Basic Integration with Anthropic

```python
from veratum import VeratumSDK
import anthropic

# Initialize Veratum SDK
sdk = VeratumSDK(
    endpoint="https://api.veratum.ai/v1",
    api_key="vsk_your_api_key_here",
    vertical="hiring"
)

# Create Anthropic client
client = anthropic.Anthropic(api_key="sk_your_anthropic_key")

# Wrap the client - all calls are now audited
wrapped_client = sdk.wrap(client)

# Use as normal - receipts generated automatically
response = wrapped_client.messages.create(
    model="claude-3-opus-20250219",
    max_tokens=1024,
    messages=[
        {
            "role": "user",
            "content": "Evaluate this candidate profile..."
        }
    ]
)

# Response is returned transparently
print(response.content[0].text)

# Cleanup
sdk.close()
```

## Context Manager Pattern (Recommended)

```python
from veratum import VeratumSDK
import anthropic

with VeratumSDK(
    endpoint="https://api.veratum.ai/v1",
    api_key="vsk_your_api_key_here",
    vertical="hiring"
) as sdk:
    client = anthropic.Anthropic(api_key="sk_your_key")
    wrapped_client = sdk.wrap(client)

    response = wrapped_client.messages.create(
        model="claude-3-opus-20250219",
        messages=[{"role": "user", "content": "Hello"}]
    )

# SDK automatically cleaned up
```

## Multiple Clients

```python
from veratum import VeratumSDK
import anthropic

sdk = VeratumSDK(
    endpoint="https://api.veratum.ai/v1",
    api_key="vsk_your_api_key_here",
    vertical="hiring"
)

# Wrap multiple clients with same SDK
client1 = anthropic.Anthropic(api_key="sk_key1")
client2 = anthropic.Anthropic(api_key="sk_key2")

wrapped1 = sdk.wrap(client1)
wrapped2 = sdk.wrap(client2)

# All calls from both clients are audited
response1 = wrapped1.messages.create(
    model="claude-3-opus-20250219",
    messages=[{"role": "user", "content": "Request 1"}]
)

response2 = wrapped2.messages.create(
    model="claude-3-opus-20250219",
    messages=[{"role": "user", "content": "Request 2"}]
)
```

## Checking Chain State

```python
from veratum import VeratumSDK
import anthropic

sdk = VeratumSDK(
    endpoint="https://api.veratum.ai/v1",
    api_key="vsk_your_api_key_here"
)

client = anthropic.Anthropic(api_key="sk_...")
wrapped = sdk.wrap(client)

# Make some calls
for i in range(3):
    wrapped.messages.create(
        model="claude-3-opus-20250219",
        messages=[{"role": "user", "content": f"Message {i}"}]
    )

# Check chain integrity
state = sdk.get_chain_state()
print(f"Sequence number: {state['sequence_no']}")  # 3
print(f"Previous hash: {state['prev_hash']}")      # Last entry_hash
```

## Error Handling

```python
from veratum import VeratumSDK
import anthropic

sdk = VeratumSDK(
    endpoint="https://api.veratum.ai/v1",
    api_key="vsk_your_api_key_here"
)

client = anthropic.Anthropic(api_key="sk_...")
wrapped = sdk.wrap(client)

try:
    response = wrapped.messages.create(
        model="claude-3-opus-20250219",
        messages=[{"role": "user", "content": "Test"}]
    )
    print("Response received and receipt uploaded")
except Exception as e:
    # API call error - receipt may or may not have been created
    print(f"Error: {e}")
finally:
    sdk.close()
```

## Environment Variables

```bash
# Set environment variables
export VERATUM_ENDPOINT="https://api.veratum.ai/v1"
export VERATUM_API_KEY="vsk_your_api_key"
export VERATUM_VERTICAL="hiring"
```

```python
import os
from veratum import VeratumSDK
import anthropic

# Load from environment
sdk = VeratumSDK(
    endpoint=os.getenv("VERATUM_ENDPOINT"),
    api_key=os.getenv("VERATUM_API_KEY"),
    vertical=os.getenv("VERATUM_VERTICAL", "hiring")
)

client = anthropic.Anthropic()
wrapped = sdk.wrap(client)
```

## Receipt Upload Details

When you call the wrapped client:

1. **Prompt Captured**: The input message is hashed (SHA256)
2. **API Called**: Original API call proceeds normally
3. **Response Captured**: Response text is hashed (SHA256)
4. **Receipt Generated**: Includes all Article 12 & ISO 24970 fields
5. **Chain Integrity**: Links to previous receipt via hash chain
6. **Upload**: Receipt posted to Veratum endpoint
7. **Return**: Original response returned transparently

All of this happens automatically without modifying your code!

## Vertical Classifications

Choose the appropriate vertical for your use case:

```python
# Hiring/recruitment decisions
sdk = VeratumSDK(..., vertical="hiring")

# Lending/credit decisions
sdk = VeratumSDK(..., vertical="lending")

# Content moderation
sdk = VeratumSDK(..., vertical="content_moderation")

# Advertising/ad delivery
sdk = VeratumSDK(..., vertical="ad_delivery")

# Healthcare
sdk = VeratumSDK(..., vertical="healthcare")

# General purpose
sdk = VeratumSDK(..., vertical="general")
```

## Zero-Code Integration

The beauty of the Veratum SDK is that it requires zero changes to existing code:

```python
# Before: Regular Anthropic client
client = anthropic.Anthropic(api_key="sk_...")
response = client.messages.create(
    model="claude-3-opus-20250219",
    messages=[{"role": "user", "content": "Hello"}]
)

# After: Just add 3 lines
from veratum import VeratumSDK

sdk = VeratumSDK(endpoint="...", api_key="...")
client = anthropic.Anthropic(api_key="sk_...")
client = sdk.wrap(client)  # ← Add this one line!

response = client.messages.create(
    model="claude-3-opus-20250219",
    messages=[{"role": "user", "content": "Hello"}]
)

# Everything else stays the same!
```
