"""
Integration tests for Veratum SDK plugins: LiteLLM, Portkey, and MCP.

Tests cover:
1. EvidenceEngine - Core evidence creation and hash chain linkage
2. VeratumLiteLLMCallback - LiteLLM plugin for 140+ providers
3. VeratumPortkeyMiddleware - Portkey AI Gateway wrapper
4. VeratumMCPServer - MCP server tools and resources

All external dependencies (litellm, portkey_ai, mcp) are mocked.
No API keys or network access required.
"""

import json
import pytest
import threading
import time
import os
from unittest.mock import Mock, patch, MagicMock
from datetime import datetime, timezone
import hashlib
import uuid

# Import the modules we're testing
from veratum.core.evidence import EvidenceEngine


class TestEvidenceEngine:
    """Test suite for core EvidenceEngine."""

    def test_evidence_engine_init_with_defaults(self):
        """EvidenceEngine initializes with default endpoint."""
        engine = EvidenceEngine()
        assert engine.endpoint == "https://api.veratum.ai"
        assert engine.api_key is None
        assert engine.customer_id is None

    def test_evidence_engine_init_with_custom_values(self):
        """EvidenceEngine initializes with custom values."""
        engine = EvidenceEngine(
            api_key="test_key_123",
            endpoint="https://custom.veratum.ai",
            customer_id="cust_456",
        )
        assert engine.api_key == "test_key_123"
        assert engine.endpoint == "https://custom.veratum.ai"
        assert engine.customer_id == "cust_456"

    def test_create_evidence_produces_valid_receipt(self):
        """create_evidence() produces a receipt with required fields."""
        engine = EvidenceEngine()

        request = {
            "messages": [
                {"role": "user", "content": "What is 2+2?"}
            ],
        }
        response = {
            "choices": [
                {"message": {"content": "4"}}
            ],
            "usage": {
                "prompt_tokens": 10,
                "completion_tokens": 1,
            }
        }

        receipt = engine.create_evidence(
            request=request,
            response=response,
            provider="openai",
            model="gpt-4o",
            decision_type="ai_inference",
            vertical="general",
        )

        # Verify required fields
        assert "entry_hash" in receipt
        assert "timestamp" in receipt
        assert "prompt_hash" in receipt or "request" in receipt or "prompt" in receipt
        assert "response_hash" in receipt or "response" in receipt
        assert receipt["model"] == "gpt-4o"
        assert receipt["provider"] == "openai"
        assert receipt["decision_type"] == "ai_inference"
        assert receipt["vertical"] == "general"

    def test_hash_chain_linkage(self):
        """Hash chain: second receipt's prev_hash equals first receipt's entry_hash."""
        engine = EvidenceEngine()

        request1 = {
            "messages": [{"role": "user", "content": "First"}]
        }
        response1 = {
            "choices": [{"message": {"content": "Response 1"}}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 5}
        }

        request2 = {
            "messages": [{"role": "user", "content": "Second"}]
        }
        response2 = {
            "choices": [{"message": {"content": "Response 2"}}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 5}
        }

        # Create first receipt
        receipt1 = engine.create_evidence(
            request=request1,
            response=response1,
            provider="openai",
            model="gpt-4o",
        )

        # Create second receipt
        receipt2 = engine.create_evidence(
            request=request2,
            response=response2,
            provider="openai",
            model="gpt-4o",
        )

        # Verify chain linkage
        assert "entry_hash" in receipt1
        assert "prev_hash" in receipt2 or "previous_hash" in receipt2

        # Extract the prev_hash field (could be prev_hash or previous_hash)
        prev_hash_field = "prev_hash" if "prev_hash" in receipt2 else "previous_hash"
        assert receipt2[prev_hash_field] is not None

    def test_thread_safety_concurrent_create_evidence(self):
        """Concurrent create_evidence calls don't corrupt state."""
        engine = EvidenceEngine()
        receipts = []
        errors = []

        def create_receipt(request_id):
            try:
                request = {
                    "messages": [{"role": "user", "content": f"Request {request_id}"}]
                }
                response = {
                    "choices": [{"message": {"content": f"Response {request_id}"}}],
                    "usage": {"prompt_tokens": 5, "completion_tokens": 5}
                }
                receipt = engine.create_evidence(
                    request=request,
                    response=response,
                    provider="openai",
                    model="gpt-4o",
                )
                receipts.append(receipt)
            except Exception as e:
                errors.append(e)

        # Create 10 concurrent requests
        threads = []
        for i in range(10):
            t = threading.Thread(target=create_receipt, args=(i,))
            threads.append(t)
            t.start()

        for t in threads:
            t.join()

        # Verify no errors occurred
        assert len(errors) == 0, f"Concurrent access errors: {errors}"
        assert len(receipts) == 10

        # Verify sequence numbers are unique and increasing
        sequence_numbers = []
        for receipt in receipts:
            if "sequence_no" in receipt:
                sequence_numbers.append(receipt["sequence_no"])

        # If sequence numbers exist, they should be unique
        if sequence_numbers:
            assert len(sequence_numbers) == len(set(sequence_numbers))

    def test_fails_open_without_api_key(self):
        """Engine works even without API key (creates receipt locally)."""
        engine = EvidenceEngine(api_key=None)

        request = {
            "messages": [{"role": "user", "content": "Test"}]
        }
        response = {
            "choices": [{"message": {"content": "Response"}}],
            "usage": {"prompt_tokens": 5, "completion_tokens": 5}
        }

        # Should not raise exception
        receipt = engine.create_evidence(
            request=request,
            response=response,
            provider="openai",
            model="gpt-4o",
        )

        # Should have created a receipt
        assert receipt is not None
        assert "entry_hash" in receipt

    def test_upload_without_api_key_returns_error(self):
        """upload_evidence without API key returns error gracefully."""
        engine = EvidenceEngine(api_key=None)

        receipt = {
            "receipt_id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "entry_hash": "abcd1234",
        }

        result = engine.upload_evidence(receipt)

        assert result["success"] is False
        assert "error" in result
        assert "no_api_key" in result.get("error_code", "")

    @patch('veratum.core.evidence.urlopen')
    def test_upload_success(self, mock_urlopen):
        """upload_evidence successfully uploads receipt."""
        # Mock the HTTP response
        mock_response = MagicMock()
        mock_response.read.return_value = json.dumps({
            "receipt_id": "receipt_123",
            "timestamp": "2026-04-07T10:00:00Z",
            "xrpl_tx_hash": "0xabc123",
        }).encode('utf-8')
        mock_response.__enter__.return_value = mock_response
        mock_urlopen.return_value = mock_response

        engine = EvidenceEngine(api_key="test_key_123")
        receipt = {
            "receipt_id": str(uuid.uuid4()),
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "entry_hash": "abcd1234",
        }

        result = engine.upload_evidence(receipt)

        assert result["success"] is True
        assert "receipt_id" in result

    def test_extract_from_openai_messages_format(self):
        """_extract_from_openai handles messages format correctly."""
        request = {
            "messages": [
                {"role": "system", "content": "You are helpful"},
                {"role": "user", "content": "What is 2+2?"},
            ]
        }
        response = {
            "choices": [
                {"message": {"content": "The answer is 4"}}
            ],
            "usage": {
                "prompt_tokens": 20,
                "completion_tokens": 5,
            }
        }

        prompt, response_text, tokens_in, tokens_out, provider_response_id = EvidenceEngine._extract_from_openai(
            request, response
        )

        assert "What is 2+2?" in prompt
        assert response_text == "The answer is 4"
        assert tokens_in == 20
        assert tokens_out == 5
        # No id in this fixture — provider_response_id may be None
        assert provider_response_id is None or isinstance(provider_response_id, str)

    def test_extract_from_anthropic(self):
        """_extract_from_anthropic handles Anthropic format."""
        request = {
            "messages": [
                {"role": "user", "content": "Hello"}
            ]
        }
        response = {
            "content": [
                {"type": "text", "text": "Hi there!"}
            ],
            "usage": {
                "input_tokens": 10,
                "output_tokens": 3,
            }
        }

        prompt, response_text, tokens_in, tokens_out, provider_response_id = EvidenceEngine._extract_from_anthropic(
            request, response
        )

        assert "Hello" in prompt
        assert response_text == "Hi there!"
        assert tokens_in == 10
        assert tokens_out == 3
        assert provider_response_id is None or isinstance(provider_response_id, str)

    def test_extract_from_generic(self):
        """_extract_from_generic handles generic LLM format."""
        request = {
            "prompt": "Explain AI",
            "temperature": 0.7,
        }
        response = {
            "text": "AI is artificial intelligence...",
        }

        prompt, response_text, tokens_in, tokens_out, provider_response_id = EvidenceEngine._extract_from_generic(
            request, response
        )

        assert prompt == "Explain AI"
        assert response_text == "AI is artificial intelligence..."
        assert provider_response_id is None or isinstance(provider_response_id, str)


@pytest.mark.skipif(
    not os.path.exists('../integrations/litellm_plugin.py'),
    reason="LiteLLM plugin not in expected location"
)
class TestLiteLLMPlugin:
    """Test suite for VeratumLiteLLMCallback plugin.

    Note: These tests use dynamic imports to handle the integrations package
    being in a separate location. Mock external dependencies.
    """

    @staticmethod
    def try_import_litellm_plugin():
        """Try to import litellm plugin from various locations."""
        import sys
        try:
            # Try standard location
            from veratum.integrations.litellm_plugin import VeratumLiteLLMCallback, enable_veratum
            return VeratumLiteLLMCallback, enable_veratum
        except (ModuleNotFoundError, ImportError):
            # Try relative import for tests
            try:
                sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'integrations'))
                import litellm_plugin
                return litellm_plugin.VeratumLiteLLMCallback, litellm_plugin.enable_veratum
            except (ModuleNotFoundError, ImportError):
                pytest.skip("LiteLLM plugin not available")

    def test_litellm_callback_init_default_endpoint(self):
        """VeratumLiteLLMCallback initializes with default endpoint."""
        VeratumLiteLLMCallback, _ = self.try_import_litellm_plugin()

        callback = VeratumLiteLLMCallback()
        assert callback.endpoint == "https://api.veratum.ai"
        assert callback.api_key is None
        assert callback.queue_receipts is True
        assert callback.queue_size == 10

    def test_litellm_callback_init_custom_values(self):
        """VeratumLiteLLMCallback initializes with custom values."""
        VeratumLiteLLMCallback, _ = self.try_import_litellm_plugin()

        callback = VeratumLiteLLMCallback(
            api_key="key_123",
            endpoint="https://custom.api",
            queue_size=20,
        )
        assert callback.api_key == "key_123"
        assert callback.endpoint == "https://custom.api"
        assert callback.queue_size == 20

    def test_litellm_callback_log_success_event_creates_receipt(self):
        """log_success_event creates a receipt."""
        VeratumLiteLLMCallback, _ = self.try_import_litellm_plugin()

        # Use queueing enabled to test queue behavior
        callback = VeratumLiteLLMCallback(queue_receipts=True, queue_size=10)

        kwargs = {
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Test"}],
            "temperature": 0.7,
        }
        response_obj = {
            "choices": [{"message": {"content": "Response"}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5}
        }
        start_time = time.time()
        end_time = start_time + 0.1

        # Call log_success_event
        callback.log_success_event(kwargs, response_obj, start_time, end_time)

        # Verify receipt was created (will be in queue since queue_size is 10)
        with callback._queue_lock:
            # Receipt should be in queue (not flushed yet due to queue_size=10)
            assert len(callback._receipt_queue) > 0
            receipt = callback._receipt_queue[0]
            assert receipt.status == "SUCCESS"
            assert receipt.model == "gpt-4o"

    def test_litellm_callback_log_failure_event_creates_failed_receipt(self):
        """log_failure_event creates a receipt with status FAILED."""
        VeratumLiteLLMCallback, _ = self.try_import_litellm_plugin()

        # Use queueing enabled to test queue behavior
        callback = VeratumLiteLLMCallback(queue_receipts=True, queue_size=10)

        kwargs = {
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Test"}],
        }
        response_obj = Exception("API Error")
        start_time = time.time()
        end_time = start_time + 0.1

        # Call log_failure_event
        callback.log_failure_event(kwargs, response_obj, start_time, end_time)

        # Verify receipt was created with FAILED status
        with callback._queue_lock:
            assert len(callback._receipt_queue) > 0
            receipt = callback._receipt_queue[0]
            assert receipt.status == "FAILED"

    def test_litellm_enable_veratum_returns_callback(self):
        """enable_veratum() returns a callback instance."""
        VeratumLiteLLMCallback, enable_veratum = self.try_import_litellm_plugin()

        # Mock litellm module in sys.modules
        mock_litellm = MagicMock()
        with patch.dict('sys.modules', {'litellm': mock_litellm}):
            callback = enable_veratum()
            assert callback is not None
            assert isinstance(callback, VeratumLiteLLMCallback)

    def test_litellm_thread_list_cleanup(self):
        """Thread list cleanup works (threads are removed when finished)."""
        VeratumLiteLLMCallback, _ = self.try_import_litellm_plugin()

        callback = VeratumLiteLLMCallback(queue_receipts=True, queue_size=1)

        kwargs = {
            "model": "gpt-4o",
            "messages": [{"role": "user", "content": "Test"}],
        }
        response_obj = {
            "choices": [{"message": {"content": "Response"}}],
            "usage": {"prompt_tokens": 10, "completion_tokens": 5}
        }
        start_time = time.time()
        end_time = start_time + 0.1

        # Trigger log_success_event which will queue and flush
        callback.log_success_event(kwargs, response_obj, start_time, end_time)

        # Small delay for thread to start
        time.sleep(0.05)

        # Give threads time to finish
        time.sleep(0.5)

        # Thread cleanup should have removed finished threads
        # (This is best-effort; we just verify the mechanism exists)
        assert hasattr(callback, '_upload_threads')


@pytest.mark.skipif(
    not os.path.exists('../integrations/portkey_plugin.py'),
    reason="Portkey plugin not in expected location"
)
class TestPortkeyPlugin:
    """Test suite for VeratumPortkeyMiddleware.

    Note: Tests use dynamic imports to handle the integrations package
    being in a separate location.
    """

    @staticmethod
    def try_import_portkey_plugin():
        """Try to import portkey plugin from various locations."""
        import sys
        try:
            from veratum.integrations.portkey_plugin import VeratumPortkeyMiddleware, wrap_portkey
            return VeratumPortkeyMiddleware, wrap_portkey
        except (ModuleNotFoundError, ImportError):
            try:
                sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', 'integrations'))
                import portkey_plugin
                return portkey_plugin.VeratumPortkeyMiddleware, portkey_plugin.wrap_portkey
            except (ModuleNotFoundError, ImportError):
                pytest.skip("Portkey plugin not available")

    def test_portkey_middleware_init(self):
        """VeratumPortkeyMiddleware wraps client without error."""
        VeratumPortkeyMiddleware, _ = self.try_import_portkey_plugin()

        # Create mock Portkey client
        mock_client = MagicMock()
        mock_client.chat.completions.create = MagicMock(return_value={"id": "test"})

        middleware = VeratumPortkeyMiddleware(
            portkey_client=mock_client,
            api_key="test_key",
            endpoint="https://api.veratum.ai",
        )

        assert middleware.portkey_client is mock_client
        assert middleware.api_key == "test_key"
        assert middleware.endpoint == "https://api.veratum.ai"

    def test_portkey_middleware_stores_original_create(self):
        """_original_create is stored (no infinite recursion)."""
        VeratumPortkeyMiddleware, _ = self.try_import_portkey_plugin()

        mock_client = MagicMock()
        original_create = MagicMock(return_value={"id": "test"})
        mock_client.chat.completions.create = original_create

        middleware = VeratumPortkeyMiddleware(portkey_client=mock_client)

        # Verify _original_create is stored
        assert middleware._original_create is not None
        assert middleware._original_create == original_create

    def test_portkey_streaming_accumulates_tool_calls(self):
        """Streaming accumulates tool_calls correctly."""
        VeratumPortkeyMiddleware, _ = self.try_import_portkey_plugin()

        mock_client = MagicMock()

        # Create mock streaming chunks
        chunks = []

        chunk1 = MagicMock()
        chunk1.id = "chatcmpl_123"
        chunk1.choices = [MagicMock()]
        chunk1.choices[0].delta = MagicMock()
        chunk1.choices[0].delta.content = "Hello"
        chunk1.choices[0].delta.tool_calls = None
        chunks.append(chunk1)

        chunk2 = MagicMock()
        chunk2.id = "chatcmpl_123"
        chunk2.choices = [MagicMock()]
        chunk2.choices[0].delta = MagicMock()
        chunk2.choices[0].delta.content = " world"
        chunk2.choices[0].delta.tool_calls = None
        chunks.append(chunk2)

        # Mock the original create to return streaming
        mock_client.chat.completions.create = MagicMock(return_value=iter(chunks))

        middleware = VeratumPortkeyMiddleware(portkey_client=mock_client)

        # Call the wrapper
        stream_result = list(middleware.portkey_client.chat.completions.create(
            model="gpt-4o",
            messages=[{"role": "user", "content": "Hi"}],
            stream=True,
        ))

        # Verify chunks were streamed
        assert len(stream_result) > 0

    def test_portkey_wrap_convenience_function(self):
        """wrap_portkey convenience function works."""
        VeratumPortkeyMiddleware, wrap_portkey = self.try_import_portkey_plugin()

        mock_client = MagicMock()
        mock_client.chat.completions.create = MagicMock(return_value={"id": "test"})

        wrapped = wrap_portkey(mock_client, api_key="test_key")

        assert wrapped is not None
        assert isinstance(wrapped, VeratumPortkeyMiddleware)


@pytest.mark.skipif(
    not os.path.exists('../../../mcp-server/server.py'),
    reason="MCP server not in expected location"
)
class TestMCPServer:
    """Test suite for VeratumMCPServer tools and validation.

    Note: Tests use dynamic imports to handle the MCP package
    being in a separate location.
    """

    @staticmethod
    def try_import_mcp_server():
        """Try to import MCP server from various locations."""
        import sys
        try:
            # Mock mcp module first
            sys.modules['mcp'] = MagicMock()
            sys.modules['mcp.server'] = MagicMock()
            sys.modules['mcp.types'] = MagicMock()

            from veratum.mcp_server.server import VeratumMCPServer
            return VeratumMCPServer
        except (ModuleNotFoundError, ImportError):
            # Try relative import
            try:
                sys.path.insert(0, os.path.join(os.path.dirname(__file__), '..', '..', '..', 'mcp-server'))
                # Mock mcp module
                sys.modules['mcp'] = MagicMock()
                sys.modules['mcp.server'] = MagicMock()
                sys.modules['mcp.types'] = MagicMock()

                import server as mcp_server_module
                return mcp_server_module.VeratumMCPServer
            except (ModuleNotFoundError, ImportError):
                pytest.skip("MCP server not available")

    @pytest.mark.asyncio
    async def test_mcp_input_validation_rejects_large_payloads(self):
        """Input validation rejects payloads over 100KB."""
        VeratumMCPServer = self.try_import_mcp_server()

        server = VeratumMCPServer()

        # Create oversized prompt (101 KB)
        large_prompt = "x" * (101 * 1024)

        result = await server._create_receipt_impl(
            prompt=large_prompt,
            response="test",
            model="gpt-4",
            provider="openai",
            decision_type="ai_inference",
            vertical="general",
            tokens_in=0,
            tokens_out=0,
        )

        # Should return error
        assert "error" in result or "receipt" not in result

    @pytest.mark.asyncio
    async def test_mcp_hash_chain_validation_catches_missing_prev_hash(self):
        """Hash chain validation catches missing prev_hash on non-genesis receipts."""
        VeratumMCPServer = self.try_import_mcp_server()

        server = VeratumMCPServer()

        # Create first receipt (genesis)
        result1 = await server._create_receipt_impl(
            prompt="First",
            response="Response 1",
            model="gpt-4",
            provider="openai",
            decision_type="ai_inference",
            vertical="general",
            tokens_in=0,
            tokens_out=0,
        )

        # Create second receipt
        result2 = await server._create_receipt_impl(
            prompt="Second",
            response="Response 2",
            model="gpt-4",
            provider="openai",
            decision_type="ai_inference",
            vertical="general",
            tokens_in=0,
            tokens_out=0,
        )

        # Verify chain validation
        chain_result = await server._get_receipt_chain_impl(limit=10)

        # Second receipt should have previous_hash
        if "receipts" in chain_result and len(chain_result["receipts"]) > 1:
            # Check chain errors
            assert isinstance(chain_result.get("chain_errors", []), list)

    @pytest.mark.asyncio
    async def test_mcp_negative_limit_clamped_to_one(self):
        """Negative limit values are clamped to 1."""
        VeratumMCPServer = self.try_import_mcp_server()

        server = VeratumMCPServer()

        # Create a receipt
        await server._create_receipt_impl(
            prompt="Test",
            response="Response",
            model="gpt-4",
            provider="openai",
            decision_type="ai_inference",
            vertical="general",
            tokens_in=0,
            tokens_out=0,
        )

        # Call with negative limit
        result = await server._get_receipt_chain_impl(limit=-5)

        # Should clamp to 1
        assert result["count"] >= 0

    @pytest.mark.asyncio
    async def test_mcp_date_parsing_handles_invalid_dates_gracefully(self):
        """Date parsing handles invalid dates gracefully."""
        VeratumMCPServer = self.try_import_mcp_server()

        server = VeratumMCPServer()

        # Call with invalid date format
        result = await server._audit_report_impl(
            start_date="invalid-date",
            end_date="2026-04-07T00:00:00",
        )

        # Should return error or fallback gracefully
        assert isinstance(result, dict)


class TestIntegrationScenarios:
    """Integration scenarios testing multiple components."""

    def test_end_to_end_evidence_flow(self):
        """End-to-end: create evidence, verify, export."""
        engine = EvidenceEngine()

        # Create multiple receipts
        receipts = []
        for i in range(3):
            request = {
                "messages": [{"role": "user", "content": f"Request {i}"}]
            }
            response = {
                "choices": [{"message": {"content": f"Response {i}"}}],
                "usage": {"prompt_tokens": 10, "completion_tokens": 5}
            }

            receipt = engine.create_evidence(
                request=request,
                response=response,
                provider="openai",
                model="gpt-4o",
            )
            receipts.append(receipt)

        # Verify we have receipts
        assert len(receipts) == 3

        # Each receipt should have entry_hash
        for receipt in receipts:
            assert "entry_hash" in receipt
            assert isinstance(receipt["entry_hash"], str)
            assert len(receipt["entry_hash"]) == 64  # SHA-256 is 64 hex chars

    def test_concurrent_providers_mixed_requests(self):
        """Mixed provider requests in concurrent threads."""
        engine = EvidenceEngine()
        receipts = []
        lock = threading.Lock()

        def create_for_provider(provider_name, model_name):
            for i in range(3):
                if provider_name == "openai":
                    request = {
                        "messages": [{"role": "user", "content": f"OpenAI {i}"}]
                    }
                    response = {
                        "choices": [{"message": {"content": "Response"}}],
                        "usage": {"prompt_tokens": 10, "completion_tokens": 5}
                    }
                elif provider_name == "anthropic":
                    request = {
                        "messages": [{"role": "user", "content": f"Anthropic {i}"}]
                    }
                    response = {
                        "content": [{"type": "text", "text": "Response"}],
                        "usage": {"input_tokens": 10, "output_tokens": 5}
                    }
                else:
                    request = {"prompt": f"Generic {i}"}
                    response = {"text": "Response"}

                receipt = engine.create_evidence(
                    request=request,
                    response=response,
                    provider=provider_name,
                    model=model_name,
                )

                with lock:
                    receipts.append(receipt)

        # Run concurrent threads
        threads = []
        threads.append(threading.Thread(target=create_for_provider, args=("openai", "gpt-4o")))
        threads.append(threading.Thread(target=create_for_provider, args=("anthropic", "claude-3")))
        threads.append(threading.Thread(target=create_for_provider, args=("generic", "unknown")))

        for t in threads:
            t.start()
        for t in threads:
            t.join()

        # Verify we got receipts from all providers
        assert len(receipts) == 9
        providers = set(r.get("provider") for r in receipts if "provider" in r)
        assert len(providers) >= 1  # At least some receipts have provider info


if __name__ == "__main__":
    pytest.main([__file__, "-v"])
