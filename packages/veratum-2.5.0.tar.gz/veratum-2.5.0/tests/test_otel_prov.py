"""Tests for v2.5.0 OTel integration and W3C PROV export.

Tests cover:
- OTel GenAI span → receipt field extraction
- W3C PROV-JSON single receipt conversion
- W3C PROV-JSON bundle generation
- Edge cases (non-GenAI spans, missing fields, chain derivation)
"""

import json
import pytest
from unittest.mock import MagicMock, patch
from datetime import datetime, timezone

# ── PROV export tests (no OTel dependency needed) ────────────────────────

from veratum.prov import receipt_to_prov, receipts_to_prov_bundle, prov_to_json


def _make_receipt(**overrides):
    """Create a minimal valid receipt for testing."""
    base = {
        "schema_version": "2.5.0",
        "receipt_id": "018e4f3a-c8b1-7abc-9def-0123456789ab",
        "entry_hash": "a" * 64,
        "entry_hash_sha3": "b" * 64,
        "prev_hash": "0" * 64,
        "sequence_no": 0,
        "timestamp": "2026-04-12T10:00:00.000Z",
        "model": "claude-3-opus",
        "provider": "anthropic",
        "sdk_version": "2.5.0",
        "prompt_hash": "c" * 64,
        "response_hash": "d" * 64,
        "tokens_in": 100,
        "tokens_out": 200,
        "decision_type": "content_generation",
        "vertical": "hiring",
    }
    base.update(overrides)
    return base


class TestReceiptToProv:
    """Test single receipt → PROV-JSON conversion."""

    def test_basic_conversion(self):
        """Core fields map correctly to PROV entities/activities/agents."""
        receipt = _make_receipt()
        prov = receipt_to_prov(receipt)

        # Should have all PROV types
        assert "prefix" in prov
        assert "entity" in prov
        assert "activity" in prov
        assert "agent" in prov

        # Check namespaces
        assert prov["prefix"]["prov"] == "http://www.w3.org/ns/prov#"
        assert prov["prefix"]["veratum"] == "https://veratum.ai/ns/prov/"

        # Check entity
        entities = list(prov["entity"].values())
        assert len(entities) == 1
        entity = entities[0]
        assert entity["veratum:receiptId"] == "018e4f3a-c8b1-7abc-9def-0123456789ab"
        assert entity["veratum:decisionType"] == "content_generation"
        assert entity["veratum:vertical"] == "hiring"

        # Check activity
        activities = list(prov["activity"].values())
        assert len(activities) == 1
        assert "claude-3-opus" in activities[0]["prov:label"]

        # Check agents (model + veratum + provider org)
        assert len(prov["agent"]) >= 3

    def test_otel_fields_included(self):
        """v2.5.0 OTel trace/span IDs appear in PROV entity."""
        receipt = _make_receipt(
            otel_trace_id="a" * 32,
            otel_span_id="b" * 16,
        )
        prov = receipt_to_prov(receipt)
        entity = list(prov["entity"].values())[0]
        assert entity["otel:traceId"] == "a" * 32
        assert entity["otel:spanId"] == "b" * 16

    def test_inclusion_proof_fields(self):
        """v2.5.0 inclusion proof maps to PROV entity attributes."""
        receipt = _make_receipt(
            inclusion_proof={
                "batch_id": "batch-001",
                "merkle_root": "e" * 64,
                "leaf_index": 7,
                "tree_size": 128,
                "proof_path": ["f" * 64, "0" * 64],
            }
        )
        prov = receipt_to_prov(receipt)
        entity = list(prov["entity"].values())[0]
        assert entity["veratum:inclusionProof"] == receipt["inclusion_proof"]

    def test_hashes_excluded_when_disabled(self):
        """include_hashes=False strips cryptographic data."""
        receipt = _make_receipt()
        prov = receipt_to_prov(receipt, include_hashes=False)
        entity = list(prov["entity"].values())[0]
        assert "veratum:entryHash" not in entity
        assert "veratum:prevHash" not in entity

    def test_chain_derivation(self):
        """Non-genesis receipt creates wasDerivedFrom relation."""
        receipt = _make_receipt(prev_hash="e" * 64, sequence_no=5)
        prov = receipt_to_prov(receipt)
        assert "wasDerivedFrom" in prov
        derivation = list(prov["wasDerivedFrom"].values())[0]
        assert "veratum:receipt/" in derivation["prov:generatedEntity"]
        assert "veratum:receipt/" in derivation["prov:usedEntity"]

    def test_genesis_no_derivation(self):
        """Genesis receipt (prev_hash all zeros) has no wasDerivedFrom."""
        receipt = _make_receipt(prev_hash="0" * 64, sequence_no=0)
        prov = receipt_to_prov(receipt)
        assert "wasDerivedFrom" not in prov

    def test_human_reviewer_agent(self):
        """Human reviewer creates a prov:Person agent."""
        receipt = _make_receipt(
            reviewer_id="rev-001",
            reviewer_name="Dr. Smith",
            reviewer_role="Senior Auditor",
            human_review_state="completed",
        )
        prov = receipt_to_prov(receipt)
        agents = prov["agent"]
        reviewer_found = False
        for agent_id, agent_data in agents.items():
            if "reviewer" in agent_id:
                reviewer_found = True
                assert agent_data["prov:label"] == "Dr. Smith"
        assert reviewer_found

    def test_model_reproducibility_fields(self):
        """v2.4.0 model reproducibility fields map to PROV."""
        receipt = _make_receipt(
            model_version_pin="claude-3-opus-20240229",
            temperature=0.7,
            top_p=0.9,
            seed=42,
            inference_mode="sampling",
        )
        prov = receipt_to_prov(receipt)
        entity = list(prov["entity"].values())[0]
        assert entity["veratum:modelVersionPin"] == "claude-3-opus-20240229"
        assert entity["veratum:temperature"] == 0.7
        assert entity["veratum:seed"] == 42

    def test_relations_present(self):
        """All core PROV relations are generated."""
        receipt = _make_receipt()
        prov = receipt_to_prov(receipt)
        assert "wasGeneratedBy" in prov
        assert "wasAssociatedWith" in prov
        assert "wasAttributedTo" in prov
        assert "actedOnBehalfOf" in prov


class TestProvBundle:
    """Test multi-receipt → PROV-JSON bundle conversion."""

    def test_bundle_merges_receipts(self):
        """Bundle combines multiple receipts into one document."""
        receipts = [
            _make_receipt(receipt_id=f"r{i}", entry_hash=f"{i}" * 64, sequence_no=i)
            for i in range(3)
        ]
        bundle = receipts_to_prov_bundle(receipts, bundle_id="test:bundle")

        assert "bundle" in bundle
        assert "test:bundle" in bundle["bundle"]
        inner = bundle["bundle"]["test:bundle"]
        assert len(inner["entity"]) == 3
        assert len(inner["activity"]) == 3

    def test_bundle_auto_id(self):
        """Bundle auto-generates ID when none provided."""
        receipts = [_make_receipt()]
        bundle = receipts_to_prov_bundle(receipts)
        assert "bundle" in bundle
        bundle_ids = list(bundle["bundle"].keys())
        assert len(bundle_ids) == 1
        assert "veratum:bundle/" in bundle_ids[0]

    def test_bundle_unique_relation_ids(self):
        """Each receipt's relations get unique IDs to avoid collisions."""
        receipts = [
            _make_receipt(entry_hash=f"{i}" * 64, sequence_no=i)
            for i in range(2)
        ]
        bundle = receipts_to_prov_bundle(receipts)
        inner = bundle["bundle"][list(bundle["bundle"].keys())[0]]
        gen_keys = list(inner["wasGeneratedBy"].keys())
        assert len(gen_keys) == 2
        assert gen_keys[0] != gen_keys[1]


class TestProvJson:
    """Test PROV-JSON serialization."""

    def test_serialization(self):
        """prov_to_json returns valid JSON."""
        receipt = _make_receipt()
        prov = receipt_to_prov(receipt)
        json_str = prov_to_json(prov)
        parsed = json.loads(json_str)
        assert "prefix" in parsed
        assert "entity" in parsed


# ── OTel span extraction tests ───────────────────────────────────────────

class TestSpanToReceiptFields:
    """Test OTel GenAI span → receipt field extraction."""

    def _make_span(self, attributes=None, trace_id=None, span_id=None, name="chat"):
        """Create a mock OTel span."""
        span = MagicMock()
        span.attributes = attributes or {}
        span.name = name
        span.start_time = 1000000000
        span.end_time = 1500000000

        ctx = MagicMock()
        ctx.trace_id = trace_id or 0xAABBCCDDEEFF00112233445566778899
        ctx.span_id = span_id or 0xAABBCCDDEEFF0011
        span.context = ctx

        return span

    def test_genai_span_extraction(self):
        """GenAI attributes are correctly extracted."""
        from veratum.otel import span_to_receipt_fields

        span = self._make_span(attributes={
            "gen_ai.system": "anthropic",
            "gen_ai.request.model": "claude-3-opus",
            "gen_ai.response.model": "claude-3-opus-20240229",
            "gen_ai.usage.input_tokens": 150,
            "gen_ai.usage.output_tokens": 300,
            "gen_ai.request.temperature": 0.7,
            "gen_ai.request.top_p": 0.9,
            "gen_ai.request.seed": 42,
            "gen_ai.operation.name": "chat",
        })

        fields = span_to_receipt_fields(span)
        assert fields is not None
        assert fields["provider"] == "anthropic"
        assert fields["model"] == "claude-3-opus"
        assert fields["model_version_pin"] == "claude-3-opus-20240229"
        assert fields["tokens_in"] == 150
        assert fields["tokens_out"] == 300
        assert fields["temperature"] == 0.7
        assert fields["top_p"] == 0.9
        assert fields["seed"] == 42
        assert fields["decision_type"] == "content_generation"

    def test_otel_ids_captured(self):
        """OTel trace and span IDs are formatted as hex strings."""
        from veratum.otel import span_to_receipt_fields

        span = self._make_span(
            attributes={
                "gen_ai.system": "openai",
                "gen_ai.request.model": "gpt-4o",
            },
            trace_id=0x00112233445566778899AABBCCDDEEFF,
            span_id=0x0011223344556677,
        )

        fields = span_to_receipt_fields(span)
        assert fields is not None
        assert fields["otel_trace_id"] == "00112233445566778899aabbccddeeff"
        assert fields["otel_span_id"] == "0011223344556677"

    def test_non_genai_span_returns_none(self):
        """Spans without gen_ai attributes are skipped."""
        from veratum.otel import span_to_receipt_fields

        span = self._make_span(attributes={
            "http.method": "GET",
            "http.url": "https://example.com",
        })

        fields = span_to_receipt_fields(span)
        assert fields is None

    def test_provider_mapping(self):
        """OTel system names map to Veratum provider names."""
        from veratum.otel import span_to_receipt_fields

        for otel_system, expected_provider in [
            ("openai", "openai"),
            ("anthropic", "anthropic"),
            ("google_ai", "google"),
            ("aws_bedrock", "bedrock"),
            ("azure_openai", "azure"),
        ]:
            span = self._make_span(attributes={
                "gen_ai.system": otel_system,
                "gen_ai.request.model": "test-model",
            })
            fields = span_to_receipt_fields(span)
            assert fields["provider"] == expected_provider, f"Failed for {otel_system}"

    def test_operation_name_mapping(self):
        """OTel operation names map to Veratum decision types."""
        from veratum.otel import span_to_receipt_fields

        for operation, expected_type in [
            ("chat", "content_generation"),
            ("embeddings", "embedding"),
            ("execute_tool", "tool_use"),
        ]:
            span = self._make_span(attributes={
                "gen_ai.system": "openai",
                "gen_ai.request.model": "gpt-4o",
                "gen_ai.operation.name": operation,
            })
            fields = span_to_receipt_fields(span)
            assert fields["decision_type"] == expected_type

    def test_latency_metadata(self):
        """Span timing is captured in metadata."""
        from veratum.otel import span_to_receipt_fields

        span = self._make_span(
            attributes={
                "gen_ai.system": "openai",
                "gen_ai.request.model": "gpt-4o",
            },
            name="chat gpt-4o",
        )
        span.start_time = 1_000_000_000  # 1s in nanoseconds
        span.end_time = 1_500_000_000    # 1.5s

        fields = span_to_receipt_fields(span)
        assert fields["metadata"]["otel_latency_ms"] == 500.0
        assert fields["metadata"]["otel_span_name"] == "chat gpt-4o"
