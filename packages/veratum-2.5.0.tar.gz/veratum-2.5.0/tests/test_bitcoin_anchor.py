"""
Unit tests for ``veratum.crypto.bitcoin_anchor``.

Covers:
  * Return-value schema of ``anchor_hash`` on success, failure, and
    ImportError fallback paths.
  * Graceful failure: the module must NEVER raise, even when every
    calendar is unreachable.
  * Hex-input validation.
  * ``upgrade_proof`` stub existence + round-trip behavior on a
    valid calendar-submitted proof.
  * ``BatchAnchor.anchor_root()`` wraps ``anchor_hash`` cleanly and
    includes both Bitcoin and XRPL sub-results.

The opentimestamps library is optional at test time. If it's not
installed the tests exercising the happy path skip cleanly.
"""
from __future__ import annotations

import base64
import hashlib
import sys
import os

import pytest
from unittest.mock import patch, MagicMock

# Make the SDK importable
sys.path.insert(
    0, os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
)

from veratum.crypto.bitcoin_anchor import anchor_hash, upgrade_proof  # noqa: E402
from veratum.crypto import bitcoin_anchor as ba  # noqa: E402
from veratum.crypto.merkle import BatchAnchor  # noqa: E402


# Detect whether the real OTS library is available so we can skip
# happy-path tests in minimal environments.
try:
    import opentimestamps  # noqa: F401
    OTS_AVAILABLE = True
except ImportError:
    OTS_AVAILABLE = False


EXPECTED_KEYS = {
    "anchored",
    "ots_proof_base64",
    "calendars_contacted",
    "calendars_succeeded",
    "calendars_failed",
    "submitted_at",
    "bitcoin_confirmed",
    "bitcoin_block_height",
    "bitcoin_txid",
    "error",
}


def _valid_hash() -> str:
    return hashlib.sha256(b"veratum").hexdigest()


# ---------------------------------------------------------------------------
# Schema shape — every return value must carry every key.
# ---------------------------------------------------------------------------
def test_anchor_hash_schema_shape_on_import_error():
    """If opentimestamps-client is missing, the result still has the full shape."""
    with patch.dict(sys.modules, {"opentimestamps": None}):
        with patch("builtins.__import__", side_effect=_fake_import_error):
            result = anchor_hash(_valid_hash())
    assert set(result.keys()) >= EXPECTED_KEYS
    assert result["anchored"] is False
    assert result["bitcoin_confirmed"] is False
    assert result["bitcoin_block_height"] is None
    assert result["ots_proof_base64"] is None
    assert "not installed" in (result["error"] or "").lower()


def _fake_import_error(name, *args, **kwargs):
    if name.startswith("opentimestamps"):
        raise ImportError(f"No module named {name}")
    return __import__(name, *args, **kwargs)


# ---------------------------------------------------------------------------
# Hex validation — invalid hex input is rejected cleanly.
# ---------------------------------------------------------------------------
def test_anchor_hash_rejects_non_hex():
    result = anchor_hash("not-valid-hex!!")
    assert result["anchored"] is False
    assert "invalid hex" in result["error"]
    # Must still return the full schema
    assert set(result.keys()) >= EXPECTED_KEYS


def test_anchor_hash_rejects_wrong_length():
    # 32 hex chars = 16 bytes, not 32 — wrong for SHA-256
    result = anchor_hash("a" * 32)
    assert result["anchored"] is False
    assert "32-byte" in result["error"]


# ---------------------------------------------------------------------------
# Happy path — calendars accept, proof is serialized.
# Requires the real opentimestamps library for the Timestamp class.
# ---------------------------------------------------------------------------
@pytest.mark.skipif(not OTS_AVAILABLE, reason="opentimestamps-client not installed")
def test_anchor_hash_success_path():
    """When at least one calendar accepts, anchored=True and the proof exists."""
    from opentimestamps.core.timestamp import Timestamp
    from opentimestamps.core.notary import PendingAttestation

    def fake_submit(self, timestamp):
        # A real calendar attaches a PendingAttestation so the
        # timestamp serializes cleanly. Mirror that behavior.
        attestation = PendingAttestation("https://alice.example.org")
        timestamp.attestations.add(attestation)

    with patch("opentimestamps.calendar.RemoteCalendar.submit", new=fake_submit):
        result = anchor_hash(_valid_hash())

    assert set(result.keys()) >= EXPECTED_KEYS
    assert result["anchored"] is True
    assert result["bitcoin_confirmed"] is False  # Stage 1 never confirms
    assert result["bitcoin_block_height"] is None
    assert result["error"] is None
    assert result["ots_proof_base64"] is not None
    assert len(result["calendars_succeeded"]) == 3
    assert result["calendars_failed"] == []

    # The proof must round-trip through base64
    proof_bytes = base64.b64decode(result["ots_proof_base64"])
    assert len(proof_bytes) > 0


# ---------------------------------------------------------------------------
# Graceful failure — every calendar raises, wrapper returns error dict.
# ---------------------------------------------------------------------------
@pytest.mark.skipif(not OTS_AVAILABLE, reason="opentimestamps-client not installed")
def test_anchor_hash_graceful_when_all_calendars_fail():
    def fake_submit(self, timestamp):
        raise ConnectionError("network error")

    with patch("opentimestamps.calendar.RemoteCalendar.submit", new=fake_submit):
        result = anchor_hash(_valid_hash())

    assert set(result.keys()) >= EXPECTED_KEYS
    assert result["anchored"] is False
    assert result["ots_proof_base64"] is None
    assert result["error"] is not None
    assert "unreachable" in result["error"].lower()
    assert result["calendars_succeeded"] == []
    assert len(result["calendars_failed"]) == 3
    # Most importantly: the function did not raise.


# ---------------------------------------------------------------------------
# Mixed success — one calendar works, others fail. Still anchored.
# ---------------------------------------------------------------------------
@pytest.mark.skipif(not OTS_AVAILABLE, reason="opentimestamps-client not installed")
def test_anchor_hash_partial_success(monkeypatch):
    from opentimestamps.core.notary import PendingAttestation

    call_count = {"n": 0}

    def fake_submit(self, timestamp):
        call_count["n"] += 1
        if call_count["n"] == 1:
            # First calendar succeeds
            timestamp.attestations.add(PendingAttestation("https://alice.example.org"))
            return
        raise ConnectionError("other calendars offline")

    with patch("opentimestamps.calendar.RemoteCalendar.submit", new=fake_submit):
        result = anchor_hash(_valid_hash())

    assert result["anchored"] is True
    assert len(result["calendars_succeeded"]) == 1
    assert len(result["calendars_failed"]) == 2


# ---------------------------------------------------------------------------
# upgrade_proof — stub existence + handles missing library
# ---------------------------------------------------------------------------
def test_upgrade_proof_is_callable():
    assert callable(upgrade_proof)


def test_upgrade_proof_handles_import_error():
    """If the library is missing, upgrade_proof returns an unupgraded dict."""
    with patch("builtins.__import__", side_effect=_fake_import_error):
        result = upgrade_proof("AAAA")
    assert result["upgraded"] is False
    assert result["bitcoin_confirmed"] is False
    assert "not installed" in (result["error"] or "").lower()


def test_upgrade_proof_handles_invalid_base64():
    """Garbage input must not raise — return an error dict."""
    result = upgrade_proof("!!!not base64!!!")
    # Either the b64 decode fails, or the deserialize fails — both are
    # caught and reported.
    assert result["upgraded"] is False
    assert result["error"] is not None or result["bitcoin_confirmed"] is False


# ---------------------------------------------------------------------------
# BatchAnchor.anchor_root — wraps anchor_hash + XRPL fallback
# ---------------------------------------------------------------------------
def test_batch_anchor_anchor_root_calls_bitcoin(monkeypatch):
    """BatchAnchor.anchor_root delegates to bitcoin_anchor.anchor_hash."""
    fake_result = {
        "anchored": True,
        "ots_proof_base64": "Zm9v",
        "calendars_contacted": ["a", "b"],
        "calendars_succeeded": ["a", "b"],
        "calendars_failed": [],
        "submitted_at": "2026-04-09T00:00:00+00:00",
        "bitcoin_confirmed": False,
        "bitcoin_block_height": None,
        "bitcoin_txid": None,
        "error": None,
    }
    monkeypatch.setattr(ba, "anchor_hash", lambda h: fake_result)

    tree = BatchAnchor(max_batch_size=4)
    tree.add("a" * 64)
    tree.add("b" * 64)
    tree.seal()

    result = tree.anchor_root()

    assert "merkle_root" in result
    assert result["primary_anchor"] == "bitcoin"
    assert result["anchors"]["bitcoin"]["anchored"] is True
    # XRPL is optional — absence is NOT an error
    assert "xrpl" in result["anchors"]


def test_batch_anchor_anchor_root_bitcoin_failure_still_returns(monkeypatch):
    """A failed Bitcoin anchor does NOT raise and still records XRPL."""
    fake_result = {
        "anchored": False,
        "error": "all calendars down",
        "calendars_contacted": [],
        "calendars_succeeded": [],
        "calendars_failed": [],
        "submitted_at": "2026-04-09T00:00:00+00:00",
        "bitcoin_confirmed": False,
        "bitcoin_block_height": None,
        "bitcoin_txid": None,
        "ots_proof_base64": None,
    }
    monkeypatch.setattr(ba, "anchor_hash", lambda h: fake_result)

    tree = BatchAnchor(max_batch_size=2)
    tree.add("a" * 64)
    tree.seal()

    result = tree.anchor_root()
    assert result["anchors"]["bitcoin"]["anchored"] is False
    assert result["primary_anchor"] == "bitcoin"


def test_batch_anchor_anchor_root_without_xrpl(monkeypatch):
    monkeypatch.setattr(ba, "anchor_hash", lambda h: {
        "anchored": True,
        "ots_proof_base64": "Zm9v",
        "calendars_contacted": [],
        "calendars_succeeded": [],
        "calendars_failed": [],
        "submitted_at": "2026-04-09T00:00:00+00:00",
        "bitcoin_confirmed": False,
        "bitcoin_block_height": None,
        "bitcoin_txid": None,
        "error": None,
    })

    tree = BatchAnchor(max_batch_size=2)
    tree.add("a" * 64)
    tree.seal()

    result = tree.anchor_root(include_xrpl=False)
    assert result["secondary_anchor"] is None
    assert "xrpl" not in result["anchors"]
