"""Tests for multi-provider LLM client detection and wrapping."""

import unittest
from unittest.mock import Mock, MagicMock, patch
from veratum.providers import (
    detect_provider,
    auto_wrap,
    WrapConfig,
    UnsupportedProviderError,
    wrap_openai,
    wrap_anthropic,
    wrap_google,
    wrap_mistral,
    wrap_cohere,
    wrap_bedrock,
)


class TestProviderDetection(unittest.TestCase):
    """Tests for detect_provider function."""

    def test_detect_openai(self):
        """Test OpenAI client detection."""
        client = Mock()
        client.__class__.__name__ = "OpenAI"
        client.__class__.__module__ = "openai.client"

        provider = detect_provider(client)
        self.assertEqual(provider, "openai")

    def test_detect_openai_async(self):
        """Test async OpenAI client detection."""
        client = Mock()
        client.__class__.__name__ = "AsyncOpenAI"
        client.__class__.__module__ = "openai.client"

        provider = detect_provider(client)
        self.assertEqual(provider, "openai")

    def test_detect_anthropic(self):
        """Test Anthropic client detection."""
        client = Mock()
        client.__class__.__name__ = "Anthropic"
        client.__class__.__module__ = "anthropic"

        provider = detect_provider(client)
        self.assertEqual(provider, "anthropic")

    def test_detect_google(self):
        """Test Google GenerativeAI detection."""
        client = Mock()
        client.__class__.__name__ = "GenerativeModel"
        client.__class__.__module__ = "google.generativeai"

        provider = detect_provider(client)
        self.assertEqual(provider, "google")

    def test_detect_mistral(self):
        """Test Mistral AI client detection."""
        client = Mock()
        client.__class__.__name__ = "Mistral"
        client.__class__.__module__ = "mistralai.client"

        provider = detect_provider(client)
        self.assertEqual(provider, "mistral")

    def test_detect_cohere(self):
        """Test Cohere client detection."""
        client = Mock()
        client.__class__.__name__ = "Client"
        client.__class__.__module__ = "cohere.client"

        provider = detect_provider(client)
        self.assertEqual(provider, "cohere")

    def test_detect_bedrock_service_model(self):
        """Test AWS Bedrock detection via service model."""
        client = Mock()
        client.__class__.__module__ = "botocore.client"
        client.__class__.__name__ = "BedrockRuntime"
        client._service_model = Mock()
        client._service_model.service_name = "bedrock-runtime"

        provider = detect_provider(client)
        self.assertEqual(provider, "bedrock")

    def test_detect_bedrock_direct(self):
        """Test AWS Bedrock detection via module name."""
        client = Mock()
        client.__class__.__module__ = "boto3.bedrock.runtime"
        client.__class__.__name__ = "Client"

        provider = detect_provider(client)
        self.assertEqual(provider, "bedrock")

    def test_detect_unknown(self):
        """Test unknown provider returns 'unknown'."""
        client = Mock()
        client.__class__.__name__ = "UnknownClient"
        client.__class__.__module__ = "unknown_module"

        provider = detect_provider(client)
        self.assertEqual(provider, "unknown")

    def test_detect_none_client(self):
        """Test None client returns 'unknown'."""
        provider = detect_provider(None)
        self.assertEqual(provider, "unknown")


class TestWrapConfig(unittest.TestCase):
    """Tests for WrapConfig dataclass."""

    def test_default_config(self):
        """Test WrapConfig defaults."""
        config = WrapConfig()

        self.assertTrue(config.capture_prompts)
        self.assertTrue(config.capture_responses)
        self.assertFalse(config.redact_pii)
        self.assertFalse(config.run_prompt_guard)
        self.assertFalse(config.track_cost)
        self.assertEqual(config.max_prompt_length, 10000)
        self.assertEqual(config.max_response_length, 10000)
        self.assertEqual(config.metadata, {})

    def test_custom_config(self):
        """Test WrapConfig with custom values."""
        config = WrapConfig(
            capture_prompts=False,
            max_prompt_length=5000,
            metadata={"app": "test"}
        )

        self.assertFalse(config.capture_prompts)
        self.assertEqual(config.max_prompt_length, 5000)
        self.assertEqual(config.metadata, {"app": "test"})


class TestOpenAIWrapper(unittest.TestCase):
    """Tests for OpenAI wrapper."""

    def test_wrap_openai_chat_completions(self):
        """Test OpenAI chat.completions.create wrapping."""
        client = Mock()
        client.chat = Mock()
        client.chat.completions = Mock()

        original_create = Mock(return_value=Mock(
            choices=[Mock(message=Mock(content="Hello"))],
            usage=Mock(prompt_tokens=10, completion_tokens=5)
        ))
        client.chat.completions.create = original_create

        receipt_fn = Mock()
        config = WrapConfig()

        wrap_openai(client, receipt_fn, config)

        # Verify wrapper was installed
        self.assertNotEqual(client.chat.completions.create, original_create)

    def test_wrap_openai_calls_receipt_callback(self):
        """Test that wrapped OpenAI calls receipt callback."""
        client = Mock()
        client.chat = Mock()
        client.chat.completions = Mock()

        response = Mock(
            choices=[Mock(message=Mock(content="Response"))],
            usage=Mock(prompt_tokens=20, completion_tokens=10)
        )
        original_create = Mock(return_value=response)
        client.chat.completions.create = original_create

        receipt_fn = Mock()
        config = WrapConfig()

        wrap_openai(client, receipt_fn, config)

        # Call wrapped method
        result = client.chat.completions.create(
            model="gpt-4",
            messages=[{"role": "user", "content": "Hello"}]
        )

        # Verify receipt callback was called
        receipt_fn.assert_called_once()
        call_kwargs = receipt_fn.call_args[1]
        self.assertEqual(call_kwargs["model"], "gpt-4")
        self.assertEqual(call_kwargs["tokens_in"], 20)
        self.assertEqual(call_kwargs["tokens_out"], 10)
        self.assertEqual(call_kwargs["provider"], "openai")

        # Verify response is returned unchanged
        self.assertEqual(result, response)


class TestAnthropicWrapper(unittest.TestCase):
    """Tests for Anthropic wrapper."""

    def test_wrap_anthropic_messages_create(self):
        """Test Anthropic messages.create wrapping."""
        client = Mock()
        client.messages = Mock()

        original_create = Mock(return_value=Mock(
            content=[Mock(text="Hello")],
            usage=Mock(input_tokens=10, output_tokens=5)
        ))
        client.messages.create = original_create

        receipt_fn = Mock()
        config = WrapConfig()

        wrap_anthropic(client, receipt_fn, config)

        # Verify wrapper was installed
        self.assertNotEqual(client.messages.create, original_create)

    def test_wrap_anthropic_calls_receipt_callback(self):
        """Test that wrapped Anthropic calls receipt callback."""
        client = Mock()
        client.messages = Mock()

        response = Mock(
            content=[Mock(text="Response")],
            usage=Mock(input_tokens=15, output_tokens=8)
        )
        original_create = Mock(return_value=response)
        client.messages.create = original_create

        receipt_fn = Mock()
        config = WrapConfig()

        wrap_anthropic(client, receipt_fn, config)

        # Call wrapped method
        result = client.messages.create(
            model="claude-3-opus",
            messages=[{"role": "user", "content": "Hello"}]
        )

        # Verify receipt callback was called
        receipt_fn.assert_called_once()
        call_kwargs = receipt_fn.call_args[1]
        self.assertEqual(call_kwargs["model"], "claude-3-opus")
        self.assertEqual(call_kwargs["tokens_in"], 15)
        self.assertEqual(call_kwargs["tokens_out"], 8)
        self.assertEqual(call_kwargs["provider"], "anthropic")

        # Verify response is returned unchanged
        self.assertEqual(result, response)


class TestAutoWrap(unittest.TestCase):
    """Tests for auto_wrap function."""

    def test_auto_wrap_openai(self):
        """Test auto_wrap detects and wraps OpenAI."""
        client = Mock()
        client.__class__.__name__ = "OpenAI"
        client.__class__.__module__ = "openai.client"
        client.chat = Mock()
        client.chat.completions = Mock()
        client.chat.completions.create = Mock()

        receipt_fn = Mock()
        config = WrapConfig()

        provider = auto_wrap(client, receipt_fn, config)
        self.assertEqual(provider, "openai")

    def test_auto_wrap_anthropic(self):
        """Test auto_wrap detects and wraps Anthropic."""
        client = Mock()
        client.__class__.__name__ = "Anthropic"
        client.__class__.__module__ = "anthropic"
        client.messages = Mock()
        client.messages.create = Mock()

        receipt_fn = Mock()
        config = WrapConfig()

        provider = auto_wrap(client, receipt_fn, config)
        self.assertEqual(provider, "anthropic")

    def test_auto_wrap_unknown_raises_error(self):
        """Test auto_wrap raises UnsupportedProviderError for unknown."""
        client = Mock()
        client.__class__.__name__ = "UnknownClient"
        client.__class__.__module__ = "unknown_module"

        receipt_fn = Mock()
        config = WrapConfig()

        with self.assertRaises(UnsupportedProviderError):
            auto_wrap(client, receipt_fn, config)

    def test_auto_wrap_without_config(self):
        """Test auto_wrap creates default config if not provided."""
        client = Mock()
        client.__class__.__name__ = "OpenAI"
        client.__class__.__module__ = "openai.client"
        client.chat = Mock()
        client.chat.completions = Mock()
        client.chat.completions.create = Mock()

        receipt_fn = Mock()

        # No config provided
        provider = auto_wrap(client, receipt_fn)
        self.assertEqual(provider, "openai")


class TestPromptExtraction(unittest.TestCase):
    """Tests for prompt extraction from different message formats."""

    def test_extract_prompt_from_list_messages(self):
        """Test prompt extraction from message list."""
        client = Mock()
        client.__class__.__name__ = "OpenAI"
        client.__class__.__module__ = "openai.client"
        client.chat = Mock()
        client.chat.completions = Mock()

        response = Mock(
            choices=[Mock(message=Mock(content="Response"))],
            usage=Mock(prompt_tokens=10, completion_tokens=5)
        )
        original_create = Mock(return_value=response)
        client.chat.completions.create = original_create

        receipt_fn = Mock()
        wrap_openai(client, receipt_fn, WrapConfig())

        # Call with messages
        client.chat.completions.create(
            model="gpt-4",
            messages=[
                {"role": "system", "content": "You are helpful"},
                {"role": "user", "content": "What is AI?"}
            ]
        )

        # Verify prompt was extracted and passed to callback
        receipt_fn.assert_called_once()
        prompt = receipt_fn.call_args[1]["prompt"]
        self.assertIn("You are helpful", prompt)
        self.assertIn("What is AI?", prompt)


class TestTruncation(unittest.TestCase):
    """Tests for text truncation in receipts."""

    def test_truncate_long_prompt(self):
        """Test that long prompts are truncated."""
        from veratum.providers import _truncate

        long_text = "x" * 20000
        truncated = _truncate(long_text, 10000)

        # Verify truncation happened
        self.assertGreater(len(truncated), 10000)
        self.assertIn("[truncated", truncated)
        self.assertTrue(truncated.startswith("x" * 10000))

    def test_truncate_short_text(self):
        """Test that short text is not truncated."""
        from veratum.providers import _truncate

        short_text = "Hello world"
        result = _truncate(short_text, 100)

        self.assertEqual(result, short_text)

    def test_truncate_none(self):
        """Test truncation of None returns None."""
        from veratum.providers import _truncate

        result = _truncate(None, 100)
        self.assertIsNone(result)


if __name__ == "__main__":
    unittest.main()
