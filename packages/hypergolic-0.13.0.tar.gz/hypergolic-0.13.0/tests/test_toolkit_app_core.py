"""Tests for hypergolic.toolkit.app.core — App class."""

from unittest.mock import MagicMock, patch

import pytest

from hypergolic.enums import ModelTier
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.primitives import Role, Skill, Tool, Workflow, WorkflowState
from hypergolic.toolkit.project import Project


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

async def _noop(inp, ctx):
    return "ok"


def _tool(tid: str = "t1") -> Tool:
    return Tool(id=tid, name=tid, description="d", run=_noop)


def _role(rid: str = "r1") -> Role:
    return Role(id=rid, name=rid, prompt="test")


def _skill(sid: str = "s1") -> Skill:
    return Skill(id=sid, name=sid, description="d")


def _project(pid: str = "p1") -> Project:
    return Project(id=pid, name=pid, description="d", git_root="/tmp/p1")


def _workflow(wid: str = "wf1") -> Workflow:
    return Workflow(
        id=wid,
        name=wid,
        description="d",
        initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
    )


# ---------------------------------------------------------------------------
# Construction and defaults
# ---------------------------------------------------------------------------


def test_app_default_construction():
    app = App()
    assert app.db_path == "~/.hypergolic/hypergolic.db"
    assert app.truncate_token_threshold == 200_000
    assert app.default_model_tier == ModelTier.HIGH
    assert app.projects == []
    assert app.tools == []
    assert app.roles == []
    assert app.skills == []
    assert app.workflows == []
    assert app._mcp_servers == {}


def test_app_custom_construction():
    app = App(
        db_path="/tmp/test.db",
        truncate_token_threshold=100_000,
        default_model_tier=ModelTier.MEDIUM,
    )
    assert app.db_path == "/tmp/test.db"
    assert app.truncate_token_threshold == 100_000
    assert app.default_model_tier == ModelTier.MEDIUM


# ---------------------------------------------------------------------------
# Register / get projects
# ---------------------------------------------------------------------------


def test_register_project():
    app = App()
    p = _project("p1")
    app.register_project(p)
    assert len(app.projects) == 1
    assert app.projects[0].id == "p1"


def test_register_projects():
    app = App()
    app.register_projects([_project("p1"), _project("p2")])
    assert len(app.projects) == 2


def test_get_project_found():
    app = App()
    p = _project("p1")
    app.register_project(p)
    result = app.get_project("p1")
    assert result is p


def test_get_project_not_found():
    app = App()
    assert app.get_project("nonexistent") is None


# ---------------------------------------------------------------------------
# Register / get roles
# ---------------------------------------------------------------------------


def test_register_role():
    app = App()
    r = _role("generalist")
    app.register_role(r)
    assert len(app.roles) == 1


def test_register_roles():
    app = App()
    app.register_roles([_role("generalist"), _role("r2")])
    assert len(app.roles) == 2


def test_get_role_found():
    app = App()
    r = _role("generalist")
    app.register_role(r)
    result = app.get_role("generalist")
    assert result is r


def test_get_role_not_found():
    app = App()
    assert app.get_role("nonexistent") is None


# ---------------------------------------------------------------------------
# Register / get skills
# ---------------------------------------------------------------------------


def test_register_skill():
    app = App()
    s = _skill("s1")
    app.register_skill(s)
    assert len(app.skills) == 1


def test_register_skills():
    app = App()
    app.register_skills([_skill("s1"), _skill("s2")])
    assert len(app.skills) == 2


def test_get_skill_found():
    app = App()
    s = _skill("s1")
    app.register_skill(s)
    result = app.get_skill("s1")
    assert result is s


def test_get_skill_not_found():
    app = App()
    assert app.get_skill("nonexistent") is None


# ---------------------------------------------------------------------------
# Register tools
# ---------------------------------------------------------------------------


def test_register_tool():
    app = App()
    t = _tool("t1")
    app.register_tool(t)
    assert len(app.tools) == 1


def test_register_tools():
    app = App()
    app.register_tools([_tool("t1"), _tool("t2")])
    assert len(app.tools) == 2


# ---------------------------------------------------------------------------
# Register workflows
# ---------------------------------------------------------------------------


def test_register_workflow():
    app = App()
    wf = _workflow("wf1")
    app.register_workflow(wf)
    assert len(app.workflows) == 1


def test_register_workflows():
    app = App()
    app.register_workflows([_workflow("wf1"), _workflow("wf2")])
    assert len(app.workflows) == 2


# ---------------------------------------------------------------------------
# MCP servers
# ---------------------------------------------------------------------------


def test_register_mcp_server():
    app = App()
    app.register_mcp_server("my-mcp", url="http://localhost:8080", token="abc")
    assert "my-mcp" in app._mcp_servers
    assert app._mcp_servers["my-mcp"]["url"] == "http://localhost:8080"


# ---------------------------------------------------------------------------
# Internal delegates
# ---------------------------------------------------------------------------


def test_validate_delegates_to_validate_app():
    with patch("hypergolic.toolkit.app.core.validate_app", return_value=[]) as mock:
        app = App()
        result = app._validate()
    mock.assert_called_once_with(app)
    assert result == []


def test_expand_paths_delegates():
    with patch("hypergolic.toolkit.app.core.expand_paths") as mock:
        app = App()
        app._expand_paths()
    mock.assert_called_once_with(app)


def test_register_projects_in_db_delegates():
    with patch("hypergolic.toolkit.app.core.register_projects_in_db") as mock:
        app = App()
        app._register_projects_in_db()
    mock.assert_called_once_with(app)


def test_call_delegates_to_run_app():
    with patch("hypergolic.toolkit.app.core.run_app") as mock:
        app = App()
        app()
    mock.assert_called_once_with(app)
