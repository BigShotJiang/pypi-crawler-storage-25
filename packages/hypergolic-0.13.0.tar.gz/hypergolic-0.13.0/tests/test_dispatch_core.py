"""Tests for hypergolic.dispatch.core."""

import asyncio
from typing import cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from anthropic.types import Message, TextBlock, Usage

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.dispatch.core import (
    CONCLUDE_INSTRUCTION,
    DispatchResult,
    _child_to_parent,
    _extract_final_text,
    _pending_dispatches,
    auto_conclude_if_needed,
    cancel_child_dispatches,
    dispatch,
    fail_dispatch_if_child,
    register_turn_runner,
    resolve_dispatch,
)
from hypergolic.enums import ModelTier, SessionStatus
from hypergolic.messages.types import BroadcastEvent
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _seed(sid: str = "s1", project_id: str = "p1", parent_id: str | None = None):
    with get_db() as db:
        if not db.get(DBProject, project_id):
            db.add(DBProject(id=project_id, name="Proj", path=f"/tmp/{project_id}"))
        if parent_id and not db.get(DBSession, parent_id):
            db.add(DBSession(
                id=parent_id,
                model_tier="Medium",
                system_prompt=[],
                project_id=project_id,
            ))
        if not db.get(DBSession, sid):
            db.add(DBSession(
                id=sid,
                model_tier="Medium",
                system_prompt=[],
                project_id=project_id,
                parent_id=parent_id,
            ))


def _make_message(text: str = "hello") -> Message:
    return Message(
        id="msg-1",
        type="message",
        role="assistant",
        content=[TextBlock(type="text", text=text)],
        model="claude-3-5-sonnet-20241022",
        stop_reason="end_turn",
        stop_sequence=None,
        usage=Usage(input_tokens=1, output_tokens=1),
    )


def _clear_state():
    """Clear module-level dispatch state to avoid test cross-contamination."""
    _pending_dispatches.clear()
    _child_to_parent.clear()


# ---------------------------------------------------------------------------
# _extract_final_text
# ---------------------------------------------------------------------------


def test_extract_final_text_with_text_block():
    msg = _make_message("My final answer")
    result = _extract_final_text(msg)
    assert "My final answer" in result


def test_extract_final_text_no_text_blocks():
    msg = Message(
        id="msg-1",
        type="message",
        role="assistant",
        content=[],
        model="claude",
        stop_reason="end_turn",
        stop_sequence=None,
        usage=Usage(input_tokens=1, output_tokens=1),
    )
    result = _extract_final_text(msg)
    assert result == "<no text content>"


def test_extract_final_text_multiple_text_blocks():
    msg = Message(
        id="msg-1",
        type="message",
        role="assistant",
        content=[
            TextBlock(type="text", text="Part one"),
            TextBlock(type="text", text="Part two"),
        ],
        model="claude",
        stop_reason="end_turn",
        stop_sequence=None,
        usage=Usage(input_tokens=1, output_tokens=1),
    )
    result = _extract_final_text(msg)
    assert "Part one" in result
    assert "Part two" in result


# ---------------------------------------------------------------------------
# resolve_dispatch
# ---------------------------------------------------------------------------


def test_resolve_dispatch_resolves_future():
    _clear_state()
    loop = asyncio.new_event_loop()
    try:
        future = loop.create_future()
        _pending_dispatches["child-1"] = future
        _child_to_parent["child-1"] = "parent-1"

        result = resolve_dispatch("child-1", DispatchResult(outcome="success", conclusion="done"))
        assert result is True
        assert future.result().outcome == "success"
        assert "child-1" not in _pending_dispatches
        assert "child-1" not in _child_to_parent
    finally:
        loop.close()


def test_resolve_dispatch_returns_false_when_no_future():
    _clear_state()
    result = resolve_dispatch("nonexistent", DispatchResult(outcome="success", conclusion="done"))
    assert result is False


def test_resolve_dispatch_returns_false_when_future_done():
    _clear_state()
    loop = asyncio.new_event_loop()
    try:
        future = loop.create_future()
        future.set_result(DispatchResult(outcome="success", conclusion="already done"))
        _pending_dispatches["child-2"] = future

        result = resolve_dispatch("child-2", DispatchResult(outcome="failure", conclusion="late"))
        assert result is False
    finally:
        loop.close()


# ---------------------------------------------------------------------------
# auto_conclude_if_needed
# ---------------------------------------------------------------------------


def test_auto_conclude_if_needed_no_parent():
    _clear_state()
    msg = _make_message("hello")
    result = auto_conclude_if_needed("s1", None, msg)
    assert result is False


def test_auto_conclude_if_needed_no_pending_future():
    _clear_state()
    msg = _make_message("hello")
    result = auto_conclude_if_needed("s1", "parent-1", msg)
    assert result is False


def test_auto_conclude_if_needed_future_already_done():
    _clear_state()
    loop = asyncio.new_event_loop()
    try:
        future = loop.create_future()
        future.set_result(DispatchResult(outcome="success", conclusion="done"))
        _pending_dispatches["child-done"] = future

        msg = _make_message("final text")
        result = auto_conclude_if_needed("child-done", "parent-1", msg)
        assert result is False
    finally:
        loop.close()
        _clear_state()


def test_auto_conclude_if_needed_concludes_pending():
    _clear_state()
    loop = asyncio.new_event_loop()
    try:
        future = loop.create_future()
        _pending_dispatches["child-3"] = future

        msg = _make_message("the final message")
        result = auto_conclude_if_needed("child-3", "parent-1", msg)

        assert result is True
        dr = future.result()
        assert dr.outcome == "success"
        assert "child-3" in dr.conclusion
        assert "the final message" in dr.conclusion
    finally:
        loop.close()
        _clear_state()


# ---------------------------------------------------------------------------
# fail_dispatch_if_child
# ---------------------------------------------------------------------------


def test_fail_dispatch_if_child_no_parent():
    _clear_state()
    result = fail_dispatch_if_child("orphan", "some error")
    assert result is False


def test_fail_dispatch_if_child_with_parent():
    _clear_state()
    loop = asyncio.new_event_loop()
    try:
        future = loop.create_future()
        _pending_dispatches["child-fail"] = future
        _child_to_parent["child-fail"] = "parent-fail"

        with patch("hypergolic.dispatch.core._schedule_sandbox_cleanup"):
            result = fail_dispatch_if_child("child-fail", "DB crashed")

        assert result is True
        dr = future.result()
        assert dr.outcome == "failure"
        assert "DB crashed" in dr.conclusion
    finally:
        loop.close()
        _clear_state()


# ---------------------------------------------------------------------------
# cancel_child_dispatches
# ---------------------------------------------------------------------------


def test_cancel_child_dispatches_interrupts_children():
    _clear_state()
    loop = asyncio.new_event_loop()
    try:
        future = loop.create_future()
        _pending_dispatches["child-c"] = future
        _child_to_parent["child-c"] = "parent-c"

        with (
            patch("hypergolic.dispatch.core.set_session_status") as mock_status,
            patch("hypergolic.dispatch.core._schedule_sandbox_cleanup"),
        ):
            cancel_child_dispatches("parent-c")

        dr = future.result()
        assert dr.outcome == "suppressed"
        assert "child-c" not in _pending_dispatches
        assert "child-c" not in _child_to_parent
        mock_status.assert_called_once_with("child-c", SessionStatus.INTERRUPTED)
    finally:
        loop.close()
        _clear_state()


def test_cancel_child_dispatches_noop_when_no_children():
    _clear_state()
    # Should not raise
    cancel_child_dispatches("parent-with-no-children")


# ---------------------------------------------------------------------------
# register_turn_runner
# ---------------------------------------------------------------------------


def test_register_turn_runner():
    from hypergolic.dispatch import core as dispatch_core
    original = dispatch_core._turn_runner
    try:
        runner = MagicMock()
        register_turn_runner(runner)
        assert dispatch_core._turn_runner is runner
    finally:
        dispatch_core._turn_runner = original


# ---------------------------------------------------------------------------
# dispatch
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_dispatch_raises_without_turn_runner():
    _clear_state()
    from hypergolic.dispatch import core as dispatch_core
    original = dispatch_core._turn_runner
    try:
        dispatch_core._turn_runner = None
        with pytest.raises(RuntimeError, match="No turn runner registered"):
            await dispatch(
                parent_session_id="p1",
                content_blocks=[],
                dispatch_prompt="do something",
                broadcast=AsyncMock(),
                role="worker",
            )
    finally:
        dispatch_core._turn_runner = original


@pytest.mark.anyio
async def test_dispatch_creates_child_and_awaits_result():
    _clear_state()
    from hypergolic.toolkit.app.core import App
    from hypergolic.toolkit.app.state import set_app
    from hypergolic.toolkit.primitives import Role
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    set_app(app)

    make_project("p1")
    parent_sid = make_session(project_id="p1", sid="parent-1")

    resolved_result = DispatchResult(outcome="success", conclusion="All done")
    broadcast = AsyncMock()

    def fake_runner(session_id: str, user_message) -> None:
        # Immediately resolve the future
        future = _pending_dispatches.get(session_id)
        if future and not future.done():
            future.set_result(resolved_result)

    with patch(
        "hypergolic.dispatch.core._schedule_sandbox_cleanup"
    ):
        register_turn_runner(fake_runner)
        result = await dispatch(
            parent_session_id=parent_sid,
            content_blocks=[{"type": "text", "text": "Do it"}],
            dispatch_prompt="You are a worker",
            broadcast=broadcast,
            role="worker",
            model_tier=ModelTier.MEDIUM,  # avoid get_app() for model_tier
        )

    assert result.outcome == "success"
    assert result.conclusion == "All done"
    # broadcast should have been called with dispatch_started
    broadcast.assert_called()
    event = broadcast.call_args[0][0]
    assert event.type == "dispatch_started"


@pytest.mark.anyio
async def test_dispatch_conclude_instruction_appended_to_prompt():
    _clear_state()
    from hypergolic.toolkit.app.core import App
    from hypergolic.toolkit.app.state import set_app
    from hypergolic.toolkit.primitives import Role
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    set_app(app)

    make_project("p1")
    parent_sid = make_session(project_id="p1", sid="parent-2")

    resolved_result = DispatchResult(outcome="success", conclusion="ok")
    received_prompts: list[str] = []

    from hypergolic.sessions.operations import load_session

    def fake_runner(session_id: str, user_message) -> None:
        session = load_session(session_id)
        if session.dispatch_prompt:
            received_prompts.append(session.dispatch_prompt)
        future = _pending_dispatches.get(session_id)
        if future and not future.done():
            future.set_result(resolved_result)

    with patch("hypergolic.dispatch.core._schedule_sandbox_cleanup"):
        register_turn_runner(fake_runner)
        await dispatch(
            parent_session_id=parent_sid,
            content_blocks=[],
            dispatch_prompt="Base prompt",
            broadcast=AsyncMock(),
            role="worker",
            model_tier=ModelTier.MEDIUM,
        )

    assert len(received_prompts) == 1
    assert CONCLUDE_INSTRUCTION in received_prompts[0]
