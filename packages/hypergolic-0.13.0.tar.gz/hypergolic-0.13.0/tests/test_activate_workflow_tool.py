"""Tests for hypergolic.tools.activate_workflow."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import Workflow, WorkflowState
from hypergolic.tools.activate_workflow import (
    build_activate_workflow_tool,
    build_workflow_description,
    handle_activate_workflow,
)
from hypergolic.tools.schemas import ToolContext, ToolOutput
from hypergolic.workflows.engine import WorkflowError
from tests._factories import build_output_schema, build_session as _session
from tests.conftest import make_project, make_session


def _ctx(session: Session | None = None) -> ToolContext:
    return ToolContext(
        session=session or _session(),
        broadcast=AsyncMock(),
        tool_id="activate_workflow",
    )


def _inp(workflow_id: str) -> MagicMock:
    inp = MagicMock()
    inp.workflow_id = workflow_id
    return inp


def _workflow(
    wf_id: str = "wf-1",
    state_id: str = "st-1",
    with_prompt_path: bool = False,
) -> Workflow:
    state = WorkflowState(
        id=state_id,
        name="Initial",
        prompt=None if with_prompt_path else "p",
        prompt_path="/tmp/prompt.md" if with_prompt_path else None,
        output_schemas=[build_output_schema()],
    )
    return Workflow(
        id=wf_id,
        name="My Workflow",
        description="A cool workflow",
        initial_state=state_id,
        states=[state],
    )


# ---------------------------------------------------------------------------
# handle_activate_workflow
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_handle_session_already_has_workflow():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    ctx = _ctx(session)

    with patch(
        "hypergolic.tools.activate_workflow.get_session_workflow",
        return_value=("wf-existing", "st-1"),
    ):
        result = await handle_activate_workflow(_inp("wf-1"), ctx)

    assert result.is_error is True
    assert "already has active workflow" in result.first_text()


@pytest.mark.anyio
async def test_handle_workflow_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    ctx = _ctx(session)

    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.get_workflow",
            return_value=None,
        ),
    ):
        result = await handle_activate_workflow(_inp("wf-missing"), ctx)

    assert result.is_error is True
    assert "not found" in result.first_text()


@pytest.mark.anyio
async def test_handle_workflow_error_from_engine():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    ctx = _ctx(session)
    wf = _workflow()

    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.get_workflow",
            return_value=wf,
        ),
        patch(
            "hypergolic.workflows.engine.activate_workflow",
            side_effect=WorkflowError("engine blew up"),
        ),
    ):
        result = await handle_activate_workflow(_inp("wf-1"), ctx)

    assert result.is_error is True
    assert "engine blew up" in result.first_text()


@pytest.mark.anyio
async def test_handle_successful_activation():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    ctx = _ctx(session)
    wf = _workflow()

    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.get_workflow",
            return_value=wf,
        ),
        patch(
            "hypergolic.workflows.engine.activate_workflow",
            new_callable=AsyncMock,
        ),
    ):
        result = await handle_activate_workflow(_inp("wf-1"), ctx)

    assert result.is_error is False
    text = result.first_text()
    assert "My Workflow" in text
    assert "activated" in text


@pytest.mark.anyio
async def test_handle_successful_activation_shows_initial_state():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    ctx = _ctx(session)
    wf = _workflow()

    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.get_workflow",
            return_value=wf,
        ),
        patch(
            "hypergolic.workflows.engine.activate_workflow",
            new_callable=AsyncMock,
        ),
    ):
        result = await handle_activate_workflow(_inp("wf-1"), ctx)

    text = result.first_text()
    assert "Initial" in text
    assert "st-1" in text


@pytest.mark.anyio
async def test_handle_successful_activation_with_prompt_path():
    """When initial state has a prompt_path, output mentions it."""
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    ctx = _ctx(session)
    wf = _workflow(with_prompt_path=True)

    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.get_workflow",
            return_value=wf,
        ),
        patch(
            "hypergolic.workflows.engine.activate_workflow",
            new_callable=AsyncMock,
        ),
    ):
        result = await handle_activate_workflow(_inp("wf-1"), ctx)

    text = result.first_text()
    assert "prompt" in text.lower()


# ---------------------------------------------------------------------------
# build_workflow_description
# ---------------------------------------------------------------------------


def test_build_workflow_description_single():
    wfs = [{"id": "wf-a", "description": "Does A things"}]
    desc = build_workflow_description(wfs)
    assert "wf-a" in desc
    assert "Does A things" in desc


def test_build_workflow_description_multiple():
    wfs = [
        {"id": "wf-a", "description": "Alpha"},
        {"id": "wf-b", "description": "Beta"},
    ]
    desc = build_workflow_description(wfs)
    assert "wf-a" in desc
    assert "wf-b" in desc
    assert "Alpha" in desc
    assert "Beta" in desc


def test_build_workflow_description_starts_with_header():
    wfs = [{"id": "wf-x", "description": "X"}]
    desc = build_workflow_description(wfs)
    assert desc.startswith("Activate a workflow")


# ---------------------------------------------------------------------------
# build_activate_workflow_tool
# ---------------------------------------------------------------------------


def test_build_activate_workflow_tool_returns_none_when_session_has_workflow():
    with patch(
        "hypergolic.tools.activate_workflow.get_session_workflow",
        return_value=("wf-existing", "st-1"),
    ):
        tool = build_activate_workflow_tool(session_id="s-1")
    assert tool is None


def test_build_activate_workflow_tool_returns_none_when_no_workflows():
    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.resolve_workflows",
            return_value=[],
        ),
    ):
        tool = build_activate_workflow_tool(session_id="s-1")
    assert tool is None


def test_build_activate_workflow_tool_returns_tool_when_workflows_exist():
    wf = _workflow()
    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.resolve_workflows",
            return_value=[wf],
        ),
    ):
        tool = build_activate_workflow_tool(session_id="s-1")
    assert tool is not None
    assert tool.id == "activate_workflow"


def test_build_activate_workflow_tool_no_session_id():
    """Without session_id, still returns tool if workflows exist."""
    wf = _workflow()
    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.resolve_workflows",
            return_value=[wf],
        ),
    ):
        tool = build_activate_workflow_tool(session_id=None)
    assert tool is not None


def test_build_activate_workflow_tool_description_contains_workflow_info():
    wf = _workflow()
    with (
        patch(
            "hypergolic.tools.activate_workflow.get_session_workflow",
            return_value=None,
        ),
        patch(
            "hypergolic.tools.activate_workflow.resolve_workflows",
            return_value=[wf],
        ),
    ):
        tool = build_activate_workflow_tool(session_id="s-1")
    assert tool is not None
    assert "wf-1" in tool.description
    assert "A cool workflow" in tool.description
