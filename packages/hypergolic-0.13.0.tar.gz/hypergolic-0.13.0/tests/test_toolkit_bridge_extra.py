"""Additional tests for hypergolic.toolkit.bridge covering remaining lines."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.bridge import (
    _EmptyInput,
    _build_call_tool,
    _param_count,
    _result_to_output,
    convert_tool,
    convert_tools,
)
from hypergolic.toolkit.primitives import (
    InputSchema,
    Tool as ToolkitTool,
    ToolContext as ToolkitToolContext,
    ToolResult,
)
from hypergolic.tools.schemas import ToolContext as InternalToolContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _session() -> Session:
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )


class SampleInput(InputSchema):
    value: str


async def _run_with_input(inp: SampleInput, ctx: ToolkitToolContext) -> ToolResult:
    return ToolResult(content=[{"type": "text", "text": inp.value}], outcome="SUCCESS")


async def _run_no_input(ctx: ToolkitToolContext) -> ToolResult:
    return ToolResult(content=[{"type": "text", "text": "ok"}], outcome="SUCCESS")


async def _run_failure(ctx: ToolkitToolContext) -> ToolResult:
    return ToolResult(content=[{"type": "text", "text": "fail"}], outcome="FAILURE")


async def _run_raises(ctx: ToolkitToolContext) -> ToolResult:
    raise RuntimeError("exploded")


def _make_toolkit_tool(
    run,
    input_schema=None,
    tid: str = "test-tool",
) -> ToolkitTool:
    return ToolkitTool(
        id=tid,
        name="Test Tool",
        description="A test tool",
        run=run,
        input_schema=input_schema,
    )


def _make_internal_ctx() -> InternalToolContext:
    return InternalToolContext(
        session=_session(),
        broadcast=AsyncMock(),
        tool_id="test-tool",
    )


# ---------------------------------------------------------------------------
# _param_count
# ---------------------------------------------------------------------------


def test_param_count_one_param():
    async def fn(ctx): ...
    assert _param_count(fn) == 1


def test_param_count_two_params():
    async def fn(inp, ctx): ...
    assert _param_count(fn) == 2


def test_param_count_no_params():
    async def fn(): ...
    assert _param_count(fn) == 0


# ---------------------------------------------------------------------------
# _EmptyInput
# ---------------------------------------------------------------------------


def test_empty_input_instantiates():
    inp = _EmptyInput()
    assert isinstance(inp, _EmptyInput)


# ---------------------------------------------------------------------------
# _result_to_output
# ---------------------------------------------------------------------------


def test_result_to_output_success():
    result = ToolResult(content=[{"type": "text", "text": "done"}], outcome="SUCCESS")
    output = _result_to_output(result)
    assert output.is_error is False
    assert output.first_text() == "done"


def test_result_to_output_failure():
    result = ToolResult(content=[{"type": "text", "text": "err"}], outcome="FAILURE")
    output = _result_to_output(result)
    assert output.is_error is True


# ---------------------------------------------------------------------------
# _build_call_tool — with input
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_build_call_tool_with_input_calls_run():
    toolkit_tool = _make_toolkit_tool(run=_run_with_input, input_schema=SampleInput)
    call_fn = _build_call_tool(toolkit_tool)

    inp = SampleInput(value="hello")
    ctx = _make_internal_ctx()

    output = await call_fn(inp, ctx)
    assert output.is_error is False
    assert output.first_text() == "hello"


@pytest.mark.anyio
async def test_build_call_tool_without_input_calls_run():
    toolkit_tool = _make_toolkit_tool(run=_run_no_input)
    call_fn = _build_call_tool(toolkit_tool)

    inp = _EmptyInput()
    ctx = _make_internal_ctx()

    output = await call_fn(inp, ctx)
    assert output.is_error is False
    assert output.first_text() == "ok"


@pytest.mark.anyio
async def test_build_call_tool_failure_outcome():
    toolkit_tool = _make_toolkit_tool(run=_run_failure)
    call_fn = _build_call_tool(toolkit_tool)

    inp = _EmptyInput()
    ctx = _make_internal_ctx()

    output = await call_fn(inp, ctx)
    assert output.is_error is True


@pytest.mark.anyio
async def test_build_call_tool_exception_returns_error_output():
    toolkit_tool = _make_toolkit_tool(run=_run_raises)
    call_fn = _build_call_tool(toolkit_tool)

    inp = _EmptyInput()
    ctx = _make_internal_ctx()

    output = await call_fn(inp, ctx)
    assert output.is_error is True
    assert "Error: exploded" in output.first_text()


@pytest.mark.anyio
async def test_build_call_tool_passes_correct_context():
    received_ctx = {}

    async def _capture_ctx(ctx: ToolkitToolContext) -> ToolResult:
        received_ctx["session"] = ctx.session
        received_ctx["tool_id"] = ctx.tool_id
        return ToolResult(content=[], outcome="SUCCESS")

    toolkit_tool = _make_toolkit_tool(run=_capture_ctx, tid="my-tool")
    call_fn = _build_call_tool(toolkit_tool)

    session = _session()
    ctx = InternalToolContext(session=session, broadcast=AsyncMock(), tool_id="my-tool")
    await call_fn(_EmptyInput(), ctx)

    assert received_ctx["session"] is session
    assert received_ctx["tool_id"] == "my-tool"


# ---------------------------------------------------------------------------
# convert_tool
# ---------------------------------------------------------------------------


def test_convert_tool_basic_properties():
    toolkit_tool = _make_toolkit_tool(run=_run_no_input, tid="my-id")
    internal_tool = convert_tool(toolkit_tool)

    assert internal_tool.id == "my-id"
    assert internal_tool.name == "Test Tool"
    assert internal_tool.description == "A test tool"
    assert internal_tool.source == "toolkit"


def test_convert_tool_with_input_schema():
    toolkit_tool = _make_toolkit_tool(run=_run_with_input, input_schema=SampleInput)
    internal_tool = convert_tool(toolkit_tool)

    assert internal_tool.input is SampleInput


def test_convert_tool_without_input_schema_uses_empty_input():
    toolkit_tool = _make_toolkit_tool(run=_run_no_input)
    internal_tool = convert_tool(toolkit_tool)

    assert internal_tool.input is _EmptyInput


# ---------------------------------------------------------------------------
# convert_tools
# ---------------------------------------------------------------------------


def test_convert_tools_empty():
    result = convert_tools([])
    assert result == []


def test_convert_tools_multiple():
    async def _run_a(ctx): return ToolResult(content=[], outcome="SUCCESS")
    async def _run_b(ctx): return ToolResult(content=[], outcome="SUCCESS")

    t1 = _make_toolkit_tool(run=_run_a, tid="tool-a")
    t2 = _make_toolkit_tool(run=_run_b, tid="tool-b")

    result = convert_tools([t1, t2])
    assert len(result) == 2
    ids = {t.id for t in result}
    assert ids == {"tool-a", "tool-b"}
