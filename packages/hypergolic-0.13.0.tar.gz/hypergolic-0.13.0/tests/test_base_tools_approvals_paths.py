"""Tests for src/hypergolic/base/tools/approvals/paths.py missing branches.

Targets:
- _is_within lines 34-35: the ValueError/TypeError except branch
- in_project_or_toolkit lines 70-71: toolkit project path branch returning False
"""

from pathlib import Path
from unittest.mock import patch

from hypergolic.base.tools.approvals.paths import (
    _is_within,
    in_project,
    in_project_or_readonly_allowlist,
    in_project_or_toolkit,
)
from hypergolic.base.tools.approvals.constants import HYPERGOLIC_TOOLKIT_DIR
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session


def _session(project_path: str = "/tmp/myproject") -> Session:
    return Session(
        id="sess-1",
        model_tier=ModelTier.MEDIUM,
        project_id="proj-1",
        project_path=project_path,
        role="generalist",
    )


def _worktree_session(
    project_path: str = "/tmp/myproject",
    worktree_path: str = "/tmp/myworktree",
) -> Session:
    return Session(
        id="sess-wt",
        model_tier=ModelTier.MEDIUM,
        project_id="proj-1",
        project_path=project_path,
        role="generalist",
        worktree_path=worktree_path,
        worktree_branch="hyp/sess-wt",
        base_branch="main",
    )


# ---------------------------------------------------------------------------
# _is_within — exception branch (lines 34-35)
# ---------------------------------------------------------------------------


def test_is_within_raises_type_error_returns_false():
    """When is_relative_to raises TypeError, _is_within returns False."""
    path = Path("/a/b/c")
    parent = Path("/a")

    with patch.object(Path, "is_relative_to", side_effect=TypeError("bad type")):
        result = _is_within(path, parent)

    assert result is False


def test_is_within_raises_value_error_returns_false():
    """When is_relative_to raises ValueError, _is_within returns False."""
    path = Path("/a/b/c")
    parent = Path("/a")

    with patch.object(Path, "is_relative_to", side_effect=ValueError("bad value")):
        result = _is_within(path, parent)

    assert result is False


# Make sure the exception is only triggered when path != parent
def test_is_within_same_path_no_exception_needed():
    """Equal paths short-circuit before calling is_relative_to."""
    p = Path("/a/b")
    # Should return True without calling is_relative_to (short-circuit)
    assert _is_within(p, p) is True


# ---------------------------------------------------------------------------
# in_project_or_toolkit — toolkit project path branch
# ---------------------------------------------------------------------------


def test_in_project_or_toolkit_toolkit_is_project_and_path_in_toolkit():
    """When session project IS the toolkit, a path inside toolkit is allowed."""
    toolkit_path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser())
    session = _session(project_path=toolkit_path)
    toolkit_file = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "prompts" / "roles" / "generalist.md")

    result = in_project_or_toolkit(toolkit_file, session)
    assert result is True


def test_in_project_or_toolkit_toolkit_is_project_but_path_outside():
    """When session project IS toolkit, but path is elsewhere, return False."""
    toolkit_path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser())
    session = _session(project_path=toolkit_path)

    result = in_project_or_toolkit("/etc/passwd", session)
    assert result is False


def test_in_project_or_toolkit_non_toolkit_project_outside_returns_false():
    """When project is NOT toolkit, external path returns False (line 71)."""
    session = _session(project_path="/tmp/some-other-project")
    toolkit_file = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "main.py")

    result = in_project_or_toolkit(toolkit_file, session)
    assert result is False


# ---------------------------------------------------------------------------
# Worktree sessions — the worktree directory counts as "in the project"
# ---------------------------------------------------------------------------


def test_in_project_allows_path_inside_worktree(tmp_path):
    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    target = worktree / "hello_world.txt"
    assert in_project(str(target), session) is True


def test_in_project_allows_relative_path_in_worktree(tmp_path):
    """Relative paths resolve against session.working_directory() — the worktree."""
    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    # Relative path — resolves via session.working_directory() to worktree/hello.txt
    assert in_project("hello.txt", session) is True


def test_in_project_rejects_path_in_original_project_when_worktree_set(tmp_path):
    """For a worktree session, the ORIGINAL project path is out of scope.

    The worktree replaces the project dir; the agent's sandbox is strictly
    its own worktree, and reaching back into the parent's tree is exactly
    what worktree isolation is meant to prevent.
    """
    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    assert in_project(str(project / "README.md"), session) is False


def test_in_project_rejects_outside_both_roots(tmp_path):
    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    outside = tmp_path / "elsewhere" / "file.txt"
    assert in_project(str(outside), session) is False


def test_in_project_or_readonly_allowlist_honors_worktree(tmp_path):
    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    assert in_project_or_readonly_allowlist(
        str(worktree / "hello.txt"), session,
    ) is True


def test_in_project_without_worktree_unchanged(tmp_path):
    """Non-worktree sessions behave exactly as before."""
    project = tmp_path / "proj"
    project.mkdir()
    session = _session(project_path=str(project))
    assert in_project(str(project / "x.txt"), session) is True
    assert in_project("/etc/passwd", session) is False


# ---------------------------------------------------------------------------
# decide_write / decide_read — approval decisions
# ---------------------------------------------------------------------------


def test_decide_write_allows_path_inside_scope_for_normal_session(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_write

    project = tmp_path / "proj"
    project.mkdir()
    session = _session(project_path=str(project))
    decision = decide_write([str(project / "a.txt")], session)
    assert decision.decision == "ALLOW"


def test_decide_write_requires_approval_outside_scope_for_normal_session(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_write

    project = tmp_path / "proj"
    project.mkdir()
    session = _session(project_path=str(project))
    decision = decide_write(["/etc/passwd"], session)
    assert decision.decision == "REQUIRE_APPROVAL"


def test_decide_write_allows_path_inside_worktree(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_write

    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    decision = decide_write([str(worktree / "new.txt")], session)
    assert decision.decision == "ALLOW"


def test_decide_write_denies_outside_worktree_with_message(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_write

    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    # Attempting to write into the original project tree — denied.
    decision = decide_write([str(project / "leaked.txt")], session)
    assert decision.decision == "DENY"
    assert decision.reason is not None
    assert "worktree" in decision.reason.lower()


def test_decide_write_denies_outside_worktree_for_arbitrary_paths(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_write

    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    decision = decide_write(["/etc/passwd"], session)
    assert decision.decision == "DENY"


def test_decide_read_allows_worktree_path(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_read

    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    decision = decide_read([str(worktree / "README.md")], session)
    assert decision.decision == "ALLOW"


def test_decide_read_denies_outside_worktree_with_message(tmp_path):
    from hypergolic.base.tools.approvals.paths import decide_read

    project = tmp_path / "proj"
    project.mkdir()
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _worktree_session(
        project_path=str(project), worktree_path=str(worktree),
    )
    decision = decide_read(["/etc/passwd"], session)
    assert decision.decision == "DENY"
    assert decision.reason is not None
