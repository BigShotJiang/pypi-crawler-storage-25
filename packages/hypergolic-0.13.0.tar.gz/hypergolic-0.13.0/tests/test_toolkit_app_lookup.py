"""Tests for hypergolic.toolkit.app.lookup."""

import pytest

from hypergolic.toolkit.app.lookup import (
    _find_in_skill,
    collect_top_level_skills,
    find_skill,
)
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.primitives import Role, Skill, Workflow, WorkflowState
from hypergolic.toolkit.project import Project


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _skill(sid: str, children: list[Skill] | None = None) -> Skill:
    return Skill(id=sid, name=sid, description="d", skills=children or [])


# ---------------------------------------------------------------------------
# _find_in_skill
# ---------------------------------------------------------------------------


def test_find_in_skill_matches_self():
    s = _skill("a")
    assert _find_in_skill("a", s) is s


def test_find_in_skill_matches_direct_child():
    child = _skill("child")
    parent = _skill("parent", children=[child])
    assert _find_in_skill("child", parent) is child


def test_find_in_skill_matches_deep_child():
    grandchild = _skill("gc")
    child = _skill("child", children=[grandchild])
    parent = _skill("parent", children=[child])
    assert _find_in_skill("gc", parent) is grandchild


def test_find_in_skill_not_found():
    s = _skill("a", children=[_skill("b")])
    assert _find_in_skill("z", s) is None


# ---------------------------------------------------------------------------
# collect_top_level_skills
# ---------------------------------------------------------------------------


def test_collect_top_level_skills_empty_app():
    app = App()
    result = collect_top_level_skills(app)
    assert result == []


def test_collect_top_level_skills_from_app():
    app = App()
    s = _skill("app-s")
    app.register_skill(s)
    result = collect_top_level_skills(app)
    assert s in result


def test_collect_top_level_skills_from_projects():
    app = App()
    s = _skill("proj-s")
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp", skills=[s])
    app.register_project(proj)
    result = collect_top_level_skills(app)
    assert s in result


def test_collect_top_level_skills_from_roles():
    app = App()
    s = _skill("role-s")
    role = Role(id="r1", name="R1", prompt="t", skills=[s])
    app.register_role(role)
    result = collect_top_level_skills(app)
    assert s in result


def test_collect_top_level_skills_from_workflow():
    app = App()
    s = _skill("wf-s")
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
        skills=[s],
    )
    app.register_workflow(wf)
    result = collect_top_level_skills(app)
    assert s in result


def test_collect_top_level_skills_from_workflow_state():
    app = App()
    s = _skill("state-s")
    state = WorkflowState(id="s1", name="S1", prompt="t", skills=[s])
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[state],
    )
    app.register_workflow(wf)
    result = collect_top_level_skills(app)
    assert s in result


def test_collect_top_level_skills_from_project_workflow():
    app = App()
    s = _skill("pw-s")
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
        skills=[s],
    )
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp", workflows=[wf])
    app.register_project(proj)
    result = collect_top_level_skills(app)
    assert s in result


def test_collect_top_level_skills_from_project_workflow_state():
    app = App()
    s = _skill("pws-s")
    state = WorkflowState(id="s1", name="S1", prompt="t", skills=[s])
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[state],
    )
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp", workflows=[wf])
    app.register_project(proj)
    result = collect_top_level_skills(app)
    assert s in result


# ---------------------------------------------------------------------------
# find_skill
# ---------------------------------------------------------------------------


def test_find_skill_found_at_app_level():
    app = App()
    s = _skill("target")
    app.register_skill(s)
    assert find_skill("target", app) is s


def test_find_skill_found_nested():
    app = App()
    child = _skill("nested")
    parent = _skill("parent", children=[child])
    app.register_skill(parent)
    assert find_skill("nested", app) is child


def test_find_skill_not_found_returns_none():
    app = App()
    assert find_skill("missing", app) is None


def test_find_skill_found_in_project():
    app = App()
    s = _skill("proj-skill")
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp", skills=[s])
    app.register_project(proj)
    assert find_skill("proj-skill", app) is s


def test_find_skill_found_in_role():
    app = App()
    s = _skill("role-skill")
    role = Role(id="r1", name="R1", prompt="t", skills=[s])
    app.register_role(role)
    assert find_skill("role-skill", app) is s
