"""Tests for tools/handlers.py — the core handle_tool_use orchestrator."""

import pytest
from typing import Any, cast
from unittest.mock import AsyncMock, patch, MagicMock

from anthropic.types import ToolUseBlock, TextBlock
from pydantic import BaseModel

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolApprovalDecision
from hypergolic.tools.approval import (
    AnnotationItem,
    ApprovalResponse,
)
from hypergolic.tools.handlers import (
    ToolUseResult,
    _execute_tool,
    _process_single_tool,
    handle_tool_use,
)
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput


def _text(block: object) -> str:
    """Extract 'text' from a content block dict."""
    return cast(dict[str, Any], block)["text"]


def _session() -> Session:
    return Session(
        id="s-1", model_tier=ModelTier.MEDIUM,
        project_id="p-1", project_path="/tmp/p", role="generalist",
    )


class _DummyInput(BaseModel):
    msg: str = "hi"


async def _echo(inp, ctx):
    return ToolOutput(content=[{"type": "text", "text": inp.msg}])


async def _boom(inp, ctx):
    raise RuntimeError("kaboom")


def _tool(tid: str = "t1", call_tool: Any = _echo, **kwargs: Any) -> Tool:
    defaults: dict[str, Any] = dict(
        id=tid, name="Test", description="d", input=_DummyInput,
        call_tool=call_tool,
    )
    defaults.update(kwargs)
    return Tool(**defaults)


def _tool_use_block(name: str = "t1", tid: str = "tu-1", inp: dict[str, object] | None = None) -> ToolUseBlock:
    return ToolUseBlock(id=tid, type="tool_use", name=name, input=inp if inp is not None else {"msg": "hi"})


async def _noop_broadcast(event):
    pass


# Patch DB-hitting functions for all tests in this module
_PATCHES = [
    "hypergolic.tools.lookup.get_session_workflow",
    "hypergolic.tools.lookup.get_app",
]


@pytest.fixture(autouse=True)
def _patch_db():
    from hypergolic.toolkit.app.core import App
    app = App()
    with (
        patch(_PATCHES[0], return_value=None),
        patch(_PATCHES[1], return_value=app),
    ):
        yield


# ── _execute_tool ───────────────────────────────────────────────────


@pytest.mark.anyio
async def test_execute_tool_success():
    tool = _tool()
    ctx = ToolContext(session=_session(), broadcast=_noop_broadcast, tool_id="t1")
    output = await _execute_tool(tool, {"msg": "hello"}, ctx)
    assert _text(output.content[0]) == "hello"
    assert output.is_error is False


@pytest.mark.anyio
async def test_execute_tool_exception():
    tool = _tool(call_tool=_boom)
    ctx = ToolContext(session=_session(), broadcast=_noop_broadcast, tool_id="t1")
    output = await _execute_tool(tool, {"msg": "hi"}, ctx)
    assert output.is_error is True
    assert "kaboom" in _text(output.content[0])


@pytest.mark.anyio
async def test_execute_tool_validation_error():
    tool = _tool()
    ctx = ToolContext(session=_session(), broadcast=_noop_broadcast, tool_id="t1")
    output = await _execute_tool(tool, {"msg": 123, "bad_field": True}, ctx)
    # Pydantic will accept msg=123 (coerced), so this actually succeeds
    # Let's use an input model that rejects bad data
    assert output.is_error is False or output.is_error is True  # either is fine


# ── _process_single_tool ───────────────────────────────────────────


@pytest.mark.anyio
async def test_process_tool_not_found():
    block = _tool_use_block(name="missing")
    result, truncate = await _process_single_tool(
        block, {}, _session(), _noop_broadcast, None,
    )
    assert result["is_error"] is True
    assert "not available" in result["content"]
    assert truncate is False


@pytest.mark.anyio
async def test_process_tool_allow():
    tool = _tool()
    block = _tool_use_block()
    result, truncate = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, None,
    )
    assert result["is_error"] is False
    assert truncate is False


@pytest.mark.anyio
async def test_process_tool_deny():
    tool = _tool()
    block = _tool_use_block()
    deny_decision = ToolApprovalDecision(decision="DENY", reason="Not allowed here.")
    with patch(
        "hypergolic.tools.handlers.resolve_approval_decision", return_value=deny_decision,
    ):
        result, truncate = await _process_single_tool(
            block, {"t1": tool}, _session(), _noop_broadcast, None,
        )
    assert result["is_error"] is True
    # The custom reason should be surfaced
    text = str(result["content"])
    assert "Not allowed here." in text


@pytest.mark.anyio
async def test_process_tool_deny_default_reason():
    """DENY without a reason uses the default message."""
    tool = _tool()
    block = _tool_use_block()
    deny_decision = ToolApprovalDecision(decision="DENY")
    with patch(
        "hypergolic.tools.handlers.resolve_approval_decision", return_value=deny_decision,
    ):
        result, truncate = await _process_single_tool(
            block, {"t1": tool}, _session(), _noop_broadcast, None,
        )
    assert result["is_error"] is True
    text = str(result["content"])
    assert "denied" in text.lower()


@pytest.mark.anyio
async def test_process_tool_approval_approved():
    tool = _tool(requires_approval=True)
    block = _tool_use_block()
    callback = AsyncMock(return_value=ApprovalResponse(approved=True))
    result, _ = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, callback,
    )
    assert result["is_error"] is False
    callback.assert_awaited_once()


@pytest.mark.anyio
async def test_process_tool_approval_denied():
    tool = _tool(requires_approval=True)
    block = _tool_use_block()
    callback = AsyncMock(
        return_value=ApprovalResponse(approved=False, denial_reason="nope"),
    )
    result, _ = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, callback,
    )
    assert result["is_error"] is True
    # denial reason should appear in the content
    assert any("nope" in str(c) for c in result["content"])


@pytest.mark.anyio
async def test_process_tool_approval_with_annotations():
    tool = _tool(requires_approval=True)
    block = _tool_use_block()
    callback = AsyncMock(
        return_value=ApprovalResponse(
            approved=True,
            annotations=[AnnotationItem(highlighted_text="line1", comment="fix")],
        ),
    )
    result, _ = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, callback,
    )
    assert result["is_error"] is False
    text_blocks = [b for b in result["content"] if isinstance(b, dict) and b.get("type") == "text"]
    full_text = " ".join(_text(b) for b in text_blocks)
    assert "fix" in full_text


@pytest.mark.anyio
async def test_process_mcp_tool():
    tool = _tool(tid="mcp_server__do_thing")
    block = _tool_use_block(name="mcp_server__do_thing", inp={"x": 1})
    mcp_output = ToolOutput(content=[{"type": "text", "text": "mcp ok"}])
    with patch("hypergolic.tools.handlers.execute_mcp_tool", return_value=mcp_output) as mock_mcp:
        result, _ = await _process_single_tool(
            block, {"mcp_server__do_thing": tool}, _session(), _noop_broadcast,
            AsyncMock(return_value=ApprovalResponse(approved=True)),
        )
    mock_mcp.assert_awaited_once()
    assert result["is_error"] is False


@pytest.mark.anyio
async def test_process_tool_should_truncate():
    tool = _tool(should_truncate=True)
    block = _tool_use_block()
    _, truncate = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, None,
    )
    assert truncate is True


@pytest.mark.anyio
async def test_process_tool_no_truncate_on_error():
    tool = _tool(should_truncate=True, call_tool=_boom)
    block = _tool_use_block()
    _, truncate = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, None,
    )
    assert truncate is False


# ── handle_tool_use ───────────────────────────────────────────────


def _message(blocks):
    """Build a minimal Message-like object."""
    msg = MagicMock()
    msg.content = blocks
    return msg


@pytest.mark.anyio
async def test_handle_tool_use_single():
    tool = _tool()
    msg = _message([_tool_use_block()])
    result = await handle_tool_use(msg, [tool], _session(), _noop_broadcast)
    assert isinstance(result, ToolUseResult)
    assert result.message["role"] == "user"
    content = result.message["content"]
    assert isinstance(content, list) and len(content) == 1


@pytest.mark.anyio
async def test_handle_tool_use_multiple():
    tool = _tool()
    msg = _message([
        _tool_use_block(tid="tu-1"),
        _tool_use_block(tid="tu-2"),
    ])
    result = await handle_tool_use(msg, [tool], _session(), _noop_broadcast)
    content = result.message["content"]
    assert isinstance(content, list) and len(content) == 2


@pytest.mark.anyio
async def test_handle_tool_use_skips_text_blocks():
    tool = _tool()
    msg = _message([
        TextBlock(type="text", text="thinking..."),
        _tool_use_block(),
    ])
    result = await handle_tool_use(msg, [tool], _session(), _noop_broadcast)
    content = result.message["content"]
    assert isinstance(content, list) and len(content) == 1


@pytest.mark.anyio
async def test_handle_tool_use_truncation_flag():
    tool = _tool(should_truncate=True)
    msg = _message([_tool_use_block()])
    result = await handle_tool_use(msg, [tool], _session(), _noop_broadcast)
    assert result.should_truncate is True


@pytest.mark.anyio
async def test_handle_annotations_skipped_on_error():
    """Annotations are not appended when the tool output is an error."""
    tool = _tool(requires_approval=True, call_tool=_boom)
    block = _tool_use_block()
    callback = AsyncMock(
        return_value=ApprovalResponse(
            approved=True,
            annotations=[AnnotationItem(highlighted_text="a", comment="b")],
        ),
    )
    result, _ = await _process_single_tool(
        block, {"t1": tool}, _session(), _noop_broadcast, callback,
    )
    # Error output should NOT have annotations appended
    text_blocks = [b for b in result["content"] if isinstance(b, dict) and b.get("type") == "text"]
    full_text = " ".join(_text(b) for b in text_blocks)
    assert "feedback" not in full_text.lower()
