"""Tests for tools/approval.py."""

from typing import Any, cast
from unittest.mock import MagicMock

from pydantic import BaseModel

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.approval import (
    AnnotationItem,
    ApprovalResponse,
    append_annotations,
    build_resolved_view,
    format_denial,
    resolve_approval_decision,
)
from hypergolic.tools.approval_view import ApprovalView, CodeBlock
from hypergolic.tools.schemas import Tool, ToolOutput


def _text(block: object) -> str:
    """Extract 'text' from a content block dict."""
    return cast(dict[str, Any], block)["text"]


def _session(**overrides: object) -> Session:
    defaults: dict[str, object] = dict(
        id="s-1", model_tier=ModelTier.MEDIUM,
        project_id="p-1", project_path="/tmp/p", role="generalist",
    )
    defaults.update(overrides)
    return Session.model_validate(defaults)


class _DummyInput(BaseModel):
    x: int = 1


async def _noop(inp, ctx):
    return ToolOutput(content=[])


def _tool(**kwargs: Any) -> Tool:
    defaults: dict[str, Any] = dict(
        id="t1", name="Test", description="d", input=_DummyInput, call_tool=_noop,
    )
    defaults.update(kwargs)
    return Tool(**defaults)


# ── resolve_approval_decision ────────────────────────────────────


def test_resolve_decision_toolkit_tool_delegates():
    """When a toolkit_tool is present the decision comes from evaluate_toolkit_approval."""
    toolkit_tool = MagicMock()
    toolkit_tool.approval = "ALLOW"
    toolkit_tool.input_schema = None
    decision = resolve_approval_decision(
        _tool(), {}, toolkit_tool, _session(), is_mcp=False,
    )
    assert decision.decision == "ALLOW"


def test_resolve_decision_mcp_requires_approval():
    decision = resolve_approval_decision(
        _tool(), {}, None, _session(), is_mcp=True,
    )
    assert decision.decision == "REQUIRE_APPROVAL"


def test_resolve_decision_tool_requires_approval():
    decision = resolve_approval_decision(
        _tool(requires_approval=True), {}, None, _session(), is_mcp=False,
    )
    assert decision.decision == "REQUIRE_APPROVAL"


def test_resolve_decision_tool_auto_allow():
    decision = resolve_approval_decision(
        _tool(requires_approval=False), {}, None, _session(), is_mcp=False,
    )
    assert decision.decision == "ALLOW"


def test_resolve_decision_toolkit_deny_with_reason():
    """Toolkit DENY decisions preserve reason."""
    toolkit_tool = MagicMock()
    toolkit_tool.approval = "DENY"
    toolkit_tool.input_schema = None
    decision = resolve_approval_decision(
        _tool(), {}, toolkit_tool, _session(), is_mcp=False,
    )
    assert decision.decision == "DENY"


# ── build_resolved_view ──────────────────────────────────────────


def test_build_resolved_view_no_view():
    assert build_resolved_view(_tool(approval_view=None), {}) is None


def test_build_resolved_view_with_view():
    view = ApprovalView(blocks=[CodeBlock(field="cmd", language="bash")])
    tool = _tool(approval_view=view)
    resolved = build_resolved_view(tool, {"cmd": "ls"})
    assert resolved is not None
    assert resolved.blocks[0]["value"] == "ls"
    assert resolved.blocks[0]["language"] == "bash"
    assert resolved.show_raw_json is True


# ── format_denial ───────────────────────────────────────────────


def test_format_denial_simple():
    resp = ApprovalResponse(approved=False)
    assert format_denial(resp) == "User denied tool call."


def test_format_denial_with_reason():
    resp = ApprovalResponse(approved=False, denial_reason="not needed")
    text = format_denial(resp)
    assert "Reason: not needed" in text


def test_format_denial_with_annotations():
    resp = ApprovalResponse(
        approved=False,
        annotations=[AnnotationItem(highlighted_text="foo", comment="bar")],
    )
    text = format_denial(resp)
    assert '"foo"' in text
    assert "bar" in text
    assert "annotations" in text.lower()


def test_format_denial_with_reason_and_annotations():
    resp = ApprovalResponse(
        approved=False,
        denial_reason="wrong",
        annotations=[AnnotationItem(highlighted_text="x", comment="y")],
    )
    text = format_denial(resp)
    assert "Reason: wrong" in text
    assert '"x": y' in text


# ── append_annotations ──────────────────────────────────────────


def test_append_annotations():
    output = ToolOutput(content=[{"type": "text", "text": "result"}])
    ann = [AnnotationItem(highlighted_text="code", comment="fix this")]
    result = append_annotations(output, ann)
    assert len(result.content) == 2
    assert "fix this" in _text(result.content[1])
    assert result.is_error is False


def test_append_annotations_preserves_flags():
    output = ToolOutput(
        content=[{"type": "text", "text": "r"}],
        is_error=True, should_truncate=True,
    )
    ann = [AnnotationItem(highlighted_text="a", comment="b")]
    result = append_annotations(output, ann)
    assert result.is_error is True
    assert result.should_truncate is True
