"""Tests for tools/python_search.py."""

import re
from pathlib import Path

import pytest

from hypergolic.tools.python_search import (
    PythonSearchParams,
    _compile_pattern,
    _is_context_line,
    python_search,
)


# ── _compile_pattern ───────────────────────────────────────────────


def test_compile_fixed_string():
    params = PythonSearchParams(pattern="foo.bar", fixed_string=True)
    regex = _compile_pattern(params)
    assert regex.search("foo.bar")
    assert not regex.search("fooXbar")  # dot was escaped


def test_compile_regex():
    params = PythonSearchParams(pattern="fo+\.bar")
    regex = _compile_pattern(params)
    assert regex.search("fooo.bar")
    assert not regex.search("fooXbar")


def test_compile_case_insensitive():
    params = PythonSearchParams(pattern="Hello", case_sensitive=False)
    regex = _compile_pattern(params)
    assert regex.search("HELLO")


def test_compile_multiline():
    params = PythonSearchParams(pattern="a.b", multiline=True)
    regex = _compile_pattern(params)
    assert regex.search("a\nb")  # dot matches newline in DOTALL mode


def test_compile_case_sensitive():
    params = PythonSearchParams(pattern="Hello")
    regex = _compile_pattern(params)
    assert not regex.search("hello")


# ── _is_context_line ───────────────────────────────────────────────


def test_is_context_line_true():
    assert _is_context_line("file.py-5-context text") is True


def test_is_context_line_false_match():
    assert _is_context_line("file.py:5:match text") is False


def test_is_context_line_false_no_number():
    assert _is_context_line("file.py-abc-text") is False


def test_is_context_line_separator():
    assert _is_context_line("--") is False


def test_is_context_line_single_part():
    assert _is_context_line("nodelimiter") is False


# ── python_search ───────────────────────────────────────────────────


def test_python_search_basic(tmp_path):
    (tmp_path / "a.py").write_text("hello world\n")
    params = PythonSearchParams(pattern="hello", directory=str(tmp_path))
    result = python_search(params)
    assert result.returncode == 0
    assert "hello" in result.stdout


def test_python_search_no_match(tmp_path):
    (tmp_path / "a.py").write_text("nothing\n")
    params = PythonSearchParams(pattern="zzz", directory=str(tmp_path))
    result = python_search(params)
    assert result.returncode == 1
    assert result.stdout == ""


def test_python_search_fixed_string(tmp_path):
    (tmp_path / "a.py").write_text("foo.bar\n")
    params = PythonSearchParams(pattern="foo.bar", directory=str(tmp_path), fixed_string=True)
    result = python_search(params)
    assert result.returncode == 0


def test_python_search_files_only(tmp_path):
    (tmp_path / "a.py").write_text("match\n")
    (tmp_path / "b.py").write_text("no\n")
    params = PythonSearchParams(pattern="match", directory=str(tmp_path), files_only=True)
    result = python_search(params)
    assert result.returncode == 0
    assert "a.py" in result.stdout
    assert "b.py" not in result.stdout


def test_python_search_max_results(tmp_path):
    for i in range(10):
        (tmp_path / f"f{i}.py").write_text("match\n")
    params = PythonSearchParams(
        pattern="match", directory=str(tmp_path), files_only=True, max_results=3,
    )
    result = python_search(params)
    assert result.returncode == 0
    lines = [l for l in result.stdout.splitlines() if l]
    assert len(lines) <= 3


def test_python_search_context_lines(tmp_path):
    (tmp_path / "a.py").write_text("before\nMATCH\nafter\n")
    params = PythonSearchParams(
        pattern="MATCH", directory=str(tmp_path), context_lines=1,
    )
    result = python_search(params)
    assert "before" in result.stdout
    assert "after" in result.stdout


def test_python_search_max_results_with_context(tmp_path):
    """max_results counts match lines, not context lines."""
    content = "ctx\nMATCH1\nctx\n" + "x\n" * 5 + "ctx\nMATCH2\nctx\n"
    (tmp_path / "a.py").write_text(content)
    params = PythonSearchParams(
        pattern="MATCH", directory=str(tmp_path), context_lines=1, max_results=2,
    )
    result = python_search(params)
    assert result.returncode == 0
