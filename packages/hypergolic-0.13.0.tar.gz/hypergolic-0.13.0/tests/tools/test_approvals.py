"""Tests for file-tool path-based approval logic."""

from pathlib import Path

from hypergolic.base.tools.approvals.constants import HYPERGOLIC_TOOLKIT_DIR, READONLY_ALLOWLIST
from hypergolic.base.tools.approvals.paths import (
    in_project,
    in_project_or_toolkit,
    in_project_or_readonly_allowlist,
    _is_toolkit_project,
    _is_within,
    _resolved_allowlist,
)
from hypergolic.base.tools.delete_files import DeleteFilesInput, delete_files_approval
from hypergolic.base.tools.edit_files import EditFileEntry, EditFilesInput, edit_files_approval
from hypergolic.base.tools.list_files import ListFilesInput, list_files_approval
from hypergolic.base.tools.make_directory import MakeDirectoryInput, make_directory_approval
from hypergolic.base.tools.read_files import ReadFilesInput, read_files_approval
from hypergolic.base.tools.search_files import SearchFilesInput, search_files_approval
from hypergolic.base.tools.write_files import WriteFileEntry, WriteFilesInput, write_files_approval
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ApprovalContext
from hypergolic.tools.paths import resolve_path


def _session(project_path: str = "/tmp/myproject") -> Session:
    return Session(
        id="sess-1",
        model_tier=ModelTier.MEDIUM,
        project_id="proj-1",
        project_path=project_path,
        role="generalist",
    )


def _ctx(inp, session: Session) -> ApprovalContext:
    return ApprovalContext(
        input=inp,
        session=session,
        active_skill_ids=session.active_skill_ids,
    )


# ── constants ──────────────────────────────────────────────────────


def test_readonly_allowlist_is_list():
    assert isinstance(READONLY_ALLOWLIST, list)
    assert len(READONLY_ALLOWLIST) >= 2


def test_hypergolic_toolkit_dir():
    assert HYPERGOLIC_TOOLKIT_DIR == Path("~/.hypergolic")


# ── resolve_path ─────────────────────────────────────────────────


def test_resolve_path_absolute(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    result = resolve_path("/usr/local/bin", session)
    assert result == Path("/usr/local/bin").resolve()
    assert result.is_absolute()


def test_resolve_path_tilde():
    session = _session(project_path="/tmp/proj")
    result = resolve_path("~/foo", session)
    assert result.is_absolute()
    assert "~" not in str(result)


def test_resolve_path_relative(tmp_path: Path):
    """Relative paths resolve against the session's project directory."""
    session = _session(project_path=str(tmp_path))
    result = resolve_path("src/main.py", session)
    assert result == (tmp_path / "src" / "main.py").resolve()


def test_resolve_path_dot(tmp_path: Path):
    """'.' resolves to the project directory itself."""
    session = _session(project_path=str(tmp_path))
    result = resolve_path(".", session)
    assert result == tmp_path.resolve()


def test_resolve_path_dotdot_stays_resolved(tmp_path: Path):
    """Paths with .. components are resolved cleanly."""
    session = _session(project_path=str(tmp_path))
    result = resolve_path("src/../README.md", session)
    assert result == (tmp_path / "README.md").resolve()
    assert ".." not in str(result)


# ── _resolved_allowlist ──────────────────────────────────────────


def test_resolved_allowlist_returns_absolute_paths():
    session = _session()
    result = _resolved_allowlist(session)
    for p in result:
        assert p.is_absolute()


# ── _is_within ───────────────────────────────────────────────


def test_is_within_same_path():
    assert _is_within(Path("/a/b"), Path("/a/b")) is True


def test_is_within_child():
    assert _is_within(Path("/a/b/c"), Path("/a/b")) is True


def test_is_within_not_child():
    assert _is_within(Path("/a/b"), Path("/a/b/c")) is False


def test_is_within_sibling():
    assert _is_within(Path("/a/x"), Path("/a/b")) is False


# ── _is_toolkit_project ──────────────────────────────────────────


def test_is_toolkit_project_true():
    toolkit_path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser())
    session = _session(project_path=toolkit_path)
    assert _is_toolkit_project(session) is True


def test_is_toolkit_project_false():
    session = _session(project_path="/tmp/other")
    assert _is_toolkit_project(session) is False


# ── in_project ──────────────────────────────────────────────


def test_in_project_within(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    assert in_project(str(tmp_path / "src" / "main.py"), session) is True


def test_in_project_outside(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    assert in_project("/etc/passwd", session) is False


def test_in_project_exact_match(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    assert in_project(str(tmp_path), session) is True


def test_in_project_relative_path(tmp_path: Path):
    """Relative paths resolve against project dir and are recognized as in-project."""
    session = _session(project_path=str(tmp_path))
    assert in_project("src/main.py", session) is True


def test_in_project_relative_dot(tmp_path: Path):
    """'.' resolves to the project directory itself."""
    session = _session(project_path=str(tmp_path))
    assert in_project(".", session) is True


def test_in_project_relative_dotdot_escapes(tmp_path: Path):
    """'../' escapes the project directory and is correctly denied."""
    session = _session(project_path=str(tmp_path))
    assert in_project("../etc/passwd", session) is False


# ── in_project_or_readonly_allowlist ───────────────────────────


def test_in_project_or_allowlist_project_path(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    assert in_project_or_readonly_allowlist(str(tmp_path / "file.py"), session) is True


def test_in_project_or_allowlist_hypergolic_dir():
    session = _session(project_path="/tmp/other")
    path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "main.py")
    assert in_project_or_readonly_allowlist(path, session) is True


def test_in_project_or_allowlist_aws_config():
    session = _session(project_path="/tmp/other")
    aws_config = str(Path("~/.aws/config").expanduser())
    assert in_project_or_readonly_allowlist(aws_config, session) is True


def test_in_project_or_allowlist_aws_credentials_denied():
    """~/.aws/credentials is NOT on the allowlist (only ~/.aws/config is)."""
    session = _session(project_path="/tmp/other")
    aws_creds = str(Path("~/.aws/credentials").expanduser())
    assert in_project_or_readonly_allowlist(aws_creds, session) is False


def test_in_project_or_allowlist_random_path():
    session = _session(project_path="/tmp/project")
    assert in_project_or_readonly_allowlist("/etc/passwd", session) is False


def test_in_project_or_allowlist_relative_path(tmp_path: Path):
    """Relative paths are recognized as in-project via resolve_path."""
    session = _session(project_path=str(tmp_path))
    assert in_project_or_readonly_allowlist("src/file.py", session) is True


# ── in_project_or_toolkit ───────────────────────────────────────


def test_in_project_or_toolkit_in_project(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    assert in_project_or_toolkit(str(tmp_path / "file.py"), session) is True


def test_in_project_or_toolkit_toolkit_project():
    toolkit_path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser())
    session = _session(project_path=toolkit_path)
    toolkit_file = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "main.py")
    assert in_project_or_toolkit(toolkit_file, session) is True


def test_in_project_or_toolkit_non_toolkit_project():
    """When project is NOT the toolkit, writing to ~/.hypergolic is denied."""
    session = _session(project_path="/tmp/other")
    toolkit_file = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "main.py")
    assert in_project_or_toolkit(toolkit_file, session) is False


def test_in_project_or_toolkit_external_path(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    assert in_project_or_toolkit("/etc/passwd", session) is False


def test_in_project_or_toolkit_relative_path(tmp_path: Path):
    """Relative paths resolve against project dir."""
    session = _session(project_path=str(tmp_path))
    assert in_project_or_toolkit("src/file.py", session) is True


# ── read_files_approval ──────────────────────────────────────────


def test_read_files_approval_project_files(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = ReadFilesInput(paths=[str(tmp_path / "a.py"), str(tmp_path / "b.py")])
    assert read_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_read_files_approval_external_file(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = ReadFilesInput(paths=["/etc/passwd"])
    assert read_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_read_files_approval_mixed(tmp_path: Path):
    """One allowed + one external = REQUIRE_APPROVAL."""
    session = _session(project_path=str(tmp_path))
    inp = ReadFilesInput(paths=[str(tmp_path / "ok.py"), "/etc/passwd"])
    assert read_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_read_files_approval_allowlisted():
    session = _session(project_path="/tmp/other")
    path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "prompts" / "roles" / "generalist.md")
    inp = ReadFilesInput(paths=[path])
    assert read_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_read_files_approval_relative_paths(tmp_path: Path):
    """Relative paths resolve against project dir and are auto-approved."""
    session = _session(project_path=str(tmp_path))
    inp = ReadFilesInput(paths=["api/cases/blurb_builder.py", "api/common/time.py"])
    assert read_files_approval(_ctx(inp, session)).decision == "ALLOW"


# ── search_files_approval ───────────────────────────────────────


def test_search_files_approval_project_dir(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = SearchFilesInput(pattern="test", directory=str(tmp_path / "src"))
    assert search_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_search_files_approval_default_dir(tmp_path: Path):
    """directory=None means '.', which resolves to the project directory."""
    session = _session(project_path=str(tmp_path))
    inp = SearchFilesInput(pattern="test", directory=None)
    assert search_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_search_files_approval_relative_dir(tmp_path: Path):
    """Relative directory resolves against project dir."""
    session = _session(project_path=str(tmp_path))
    inp = SearchFilesInput(pattern="test", directory="src")
    assert search_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_search_files_approval_external_dir():
    session = _session(project_path="/tmp/project")
    inp = SearchFilesInput(pattern="test", directory="/etc")
    assert search_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_search_files_approval_allowlisted():
    session = _session(project_path="/tmp/other")
    inp = SearchFilesInput(pattern="test", directory=str(HYPERGOLIC_TOOLKIT_DIR.expanduser()))
    assert search_files_approval(_ctx(inp, session)).decision == "ALLOW"


# ── list_files_approval ──────────────────────────────────────────


def test_list_files_approval_always_allows():
    session = _session(project_path="/tmp/project")
    inp = ListFilesInput(directory=".")
    assert list_files_approval(_ctx(inp, session)).decision == "ALLOW"


# ── write_files_approval ─────────────────────────────────────────


def test_write_files_approval_in_project(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = WriteFilesInput(files=[WriteFileEntry(path=str(tmp_path / "out.txt"), content="")])
    assert write_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_write_files_approval_outside_project(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = WriteFilesInput(files=[WriteFileEntry(path="/etc/evil", content="")])
    assert write_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_write_files_approval_toolkit_project():
    toolkit_path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser())
    session = _session(project_path=toolkit_path)
    inp = WriteFilesInput(files=[WriteFileEntry(path=toolkit_path + "/main.py", content="")])
    assert write_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_write_files_approval_toolkit_not_project():
    """Writing to ~/.hypergolic when project is something else."""
    session = _session(project_path="/tmp/other")
    toolkit_file = str(HYPERGOLIC_TOOLKIT_DIR.expanduser() / "main.py")
    inp = WriteFilesInput(files=[WriteFileEntry(path=toolkit_file, content="")])
    assert write_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_write_files_approval_relative_path(tmp_path: Path):
    """Relative paths resolve against project dir and are auto-approved."""
    session = _session(project_path=str(tmp_path))
    inp = WriteFilesInput(files=[WriteFileEntry(path="src/new_file.py", content="hello")])
    assert write_files_approval(_ctx(inp, session)).decision == "ALLOW"


# ── edit_files_approval ──────────────────────────────────────────


def test_edit_files_approval_in_project(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = EditFilesInput(
        files=[EditFileEntry(path=str(tmp_path / "main.py"), old_string="", new_string="")]
    )
    assert edit_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_edit_files_approval_outside(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = EditFilesInput(
        files=[EditFileEntry(path="/etc/hosts", old_string="", new_string="")]
    )
    assert edit_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_edit_files_approval_relative_path(tmp_path: Path):
    """Relative paths resolve against project dir and are auto-approved."""
    session = _session(project_path=str(tmp_path))
    inp = EditFilesInput(
        files=[EditFileEntry(path="src/main.py", old_string="old", new_string="new")]
    )
    assert edit_files_approval(_ctx(inp, session)).decision == "ALLOW"


# ── delete_files_approval ───────────────────────────────────────


def test_delete_files_approval_in_project(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = DeleteFilesInput(paths=[str(tmp_path / "junk.py")])
    assert delete_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_delete_files_approval_outside(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = DeleteFilesInput(paths=["/etc/important"])
    assert delete_files_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_delete_files_approval_toolkit_project():
    toolkit_path = str(HYPERGOLIC_TOOLKIT_DIR.expanduser())
    session = _session(project_path=toolkit_path)
    inp = DeleteFilesInput(paths=[toolkit_path + "/old_tool.py"])
    assert delete_files_approval(_ctx(inp, session)).decision == "ALLOW"


def test_delete_files_approval_relative_path(tmp_path: Path):
    """Relative paths resolve against project dir and are auto-approved."""
    session = _session(project_path=str(tmp_path))
    inp = DeleteFilesInput(paths=["src/old_file.py"])
    assert delete_files_approval(_ctx(inp, session)).decision == "ALLOW"


# ── make_directory_approval ──────────────────────────────────────


def test_make_directory_approval_in_project(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = MakeDirectoryInput(path=str(tmp_path / "newdir"))
    assert make_directory_approval(_ctx(inp, session)).decision == "ALLOW"


def test_make_directory_approval_outside(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = MakeDirectoryInput(path="/tmp/elsewhere")
    assert make_directory_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_make_directory_approval_multiple_paths(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = MakeDirectoryInput(paths=[str(tmp_path / "a"), str(tmp_path / "b")])
    assert make_directory_approval(_ctx(inp, session)).decision == "ALLOW"


def test_make_directory_approval_mixed_paths(tmp_path: Path):
    session = _session(project_path=str(tmp_path))
    inp = MakeDirectoryInput(paths=[str(tmp_path / "ok"), "/etc/nope"])
    assert make_directory_approval(_ctx(inp, session)).decision == "REQUIRE_APPROVAL"


def test_make_directory_approval_empty_input():
    session = _session(project_path="/tmp/project")
    inp = MakeDirectoryInput()  # no path or paths
    assert make_directory_approval(_ctx(inp, session)).decision == "ALLOW"


def test_make_directory_approval_relative_path(tmp_path: Path):
    """Relative paths resolve against project dir and are auto-approved."""
    session = _session(project_path=str(tmp_path))
    inp = MakeDirectoryInput(path="src/newdir")
    assert make_directory_approval(_ctx(inp, session)).decision == "ALLOW"
