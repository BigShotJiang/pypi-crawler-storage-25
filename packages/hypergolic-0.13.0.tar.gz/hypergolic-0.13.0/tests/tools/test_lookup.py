"""Tests for tools/lookup.py."""

import pytest
from typing import Any
from unittest.mock import patch, MagicMock

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.primitives import Skill, Tool as ToolkitTool, Workflow, WorkflowState, Role
from hypergolic.toolkit.project import Project
from hypergolic.tools.lookup import find_toolkit_tool, _find_in_list


def _session(**kwargs: Any) -> Session:
    defaults: dict[str, Any] = dict(
        id="s-1", model_tier=ModelTier.MEDIUM,
        project_id="p-1", project_path="/tmp/p", role="test-role",
    )
    defaults.update(kwargs)
    return Session(**defaults)


async def _noop(ctx):
    pass


def _toolkit_tool(tid: str) -> ToolkitTool:
    return ToolkitTool(id=tid, name=tid, description="d", run=_noop)


# ── _find_in_list ───────────────────────────────────────────────────


def test_find_in_list_found():
    t = _toolkit_tool("a")
    assert _find_in_list("a", [t]) is t


def test_find_in_list_not_found():
    assert _find_in_list("x", [_toolkit_tool("a")]) is None


def test_find_in_list_empty():
    assert _find_in_list("x", []) is None


# ── find_toolkit_tool ───────────────────────────────────────────


@pytest.fixture
def app():
    a = App()
    set_app(a)
    return a


def _patch_db(session_workflow=None):
    """Context manager that patches DB-hitting resolvers."""
    from contextlib import ExitStack
    stack = ExitStack()
    stack.enter_context(
        patch("hypergolic.tools.lookup.get_session_workflow", return_value=session_workflow)
    )
    return stack


def test_find_in_app_tools(app):
    t = _toolkit_tool("app-tool")
    app.tools.append(t)
    with _patch_db():
        assert find_toolkit_tool("app-tool", _session()) is t


def test_find_in_project_tools(app):
    t = _toolkit_tool("proj-tool")
    proj = Project(id="p-1", name="P", description="d", git_root="/tmp/p", tools=[t])
    app.register_project(proj)
    with _patch_db():
        assert find_toolkit_tool("proj-tool", _session()) is t


def test_find_in_role_tools(app):
    t = _toolkit_tool("role-tool")
    role = Role(id="test-role", name="Test", tools=[t])
    app.register_role(role)
    with _patch_db():
        assert find_toolkit_tool("role-tool", _session()) is t


def test_find_in_active_skill_tools(app):
    t = _toolkit_tool("skill-tool")
    skill = Skill(id="sk-1", name="SK", description="d", tools=[t])
    app.register_skill(skill)
    session = _session(active_skill_ids={"sk-1"})
    with _patch_db():
        assert find_toolkit_tool("skill-tool", session) is t


def test_find_in_workflow_tools(app):
    t = _toolkit_tool("wf-tool")
    wf = Workflow(
        id="wf-1", name="WF", description="d", initial_state="st-1",
        tools=[t], states=[WorkflowState(id="st-1", name="S")],
    )
    app.register_workflow(wf)
    with _patch_db(session_workflow=("wf-1", "st-1")):
        assert find_toolkit_tool("wf-tool", _session()) is t


def test_find_in_workflow_state_tools(app):
    t = _toolkit_tool("state-tool")
    wf = Workflow(
        id="wf-1", name="WF", description="d", initial_state="st-1",
        states=[WorkflowState(id="st-1", name="S", tools=[t])],
    )
    app.register_workflow(wf)
    with _patch_db(session_workflow=("wf-1", "st-1")):
        assert find_toolkit_tool("state-tool", _session()) is t


def test_find_in_project_workflow_tools(app):
    t = _toolkit_tool("proj-wf-tool")
    wf = Workflow(
        id="wf-2", name="WF2", description="d", initial_state="st-1",
        tools=[t], states=[WorkflowState(id="st-1", name="S")],
    )
    proj = Project(id="p-1", name="P", description="d", git_root="/tmp/p", workflows=[wf])
    app.register_project(proj)
    with _patch_db(session_workflow=("wf-2", "st-1")):
        assert find_toolkit_tool("proj-wf-tool", _session()) is t


def test_find_returns_none_when_missing(app):
    with _patch_db():
        assert find_toolkit_tool("nope", _session()) is None


def test_find_skips_skill_without_tool(app):
    """Active skill exists but has no matching tool."""
    skill = Skill(id="sk-empty", name="Empty", description="d")
    app.register_skill(skill)
    session = _session(active_skill_ids={"sk-empty"})
    with _patch_db():
        assert find_toolkit_tool("nope", session) is None


def test_find_workflow_no_project(app):
    """Workflow lookup works even when project is None."""
    t = _toolkit_tool("wf-tool")
    wf = Workflow(
        id="wf-1", name="WF", description="d", initial_state="st-1",
        tools=[t], states=[],
    )
    app.register_workflow(wf)
    session = _session(project_id="nonexistent")
    with _patch_db(session_workflow=("wf-1", "st-1")):
        assert find_toolkit_tool("wf-tool", session) is t
