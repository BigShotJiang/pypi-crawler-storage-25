"""Tests for tools/file_search.py."""

import re
from pathlib import Path

import pytest

from hypergolic.tools.file_search import (
    is_binary,
    search_file,
    search_file_multiline,
)


# ── is_binary ──────────────────────────────────────────────────────


def test_is_binary_text_file(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("hello")
    assert is_binary(f) is False


def test_is_binary_binary_file(tmp_path):
    f = tmp_path / "b.bin"
    f.write_bytes(b"\x00\x01\x02")
    assert is_binary(f) is True


def test_is_binary_nonexistent():
    assert is_binary(Path("/nonexistent/file")) is True


def test_is_binary_empty_file(tmp_path):
    f = tmp_path / "empty"
    f.write_bytes(b"")
    assert is_binary(f) is False


# ── search_file_multiline ───────────────────────────────────────────


def test_search_multiline_match(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("line1\nline2\n")
    regex = re.compile(r"line1.*line2", re.DOTALL)
    result = search_file_multiline(f, tmp_path, regex)
    assert len(result) == 1
    assert result[0].startswith("a.py:1:")


def test_search_multiline_files_only(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("match")
    regex = re.compile("match")
    result = search_file_multiline(f, tmp_path, regex, files_only=True)
    assert result == ["a.py"]


def test_search_multiline_no_match(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("nothing")
    regex = re.compile("zzz")
    assert search_file_multiline(f, tmp_path, regex) == []


def test_search_multiline_read_error(tmp_path):
    assert search_file_multiline(Path("/nonexistent"), tmp_path, re.compile("x")) == []


def test_search_multiline_empty_content(tmp_path):
    f = tmp_path / "empty.py"
    f.write_text("")
    regex = re.compile(".*", re.DOTALL)  # matches empty string
    result = search_file_multiline(f, tmp_path, regex)
    assert len(result) == 1
    assert result[0] == "empty.py:1:"


# ── search_file ────────────────────────────────────────────────────


def test_search_file_basic(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("hello\nworld\n")
    regex = re.compile("hello")
    result = search_file(f, tmp_path, regex)
    assert len(result) == 1
    assert "a.py:1:hello" in result[0]


def test_search_file_binary_skipped(tmp_path):
    f = tmp_path / "bin"
    f.write_bytes(b"\x00binary")
    result = search_file(f, tmp_path, re.compile("binary"))
    assert result == []


def test_search_file_multiline_flag(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("foo\nbar\n")
    regex = re.compile(r"foo.*bar", re.DOTALL)
    result = search_file(f, tmp_path, regex, multiline=True)
    assert len(result) == 1


def test_search_file_files_only(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("match\n")
    result = search_file(f, tmp_path, re.compile("match"), files_only=True)
    assert result == ["a.py"]


def test_search_file_files_only_no_match(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("nothing\n")
    result = search_file(f, tmp_path, re.compile("zzz"), files_only=True)
    assert result == []


def test_search_file_invert_match(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("yes\nno\n")
    result = search_file(f, tmp_path, re.compile("yes"), invert_match=True)
    assert len(result) == 1
    assert "no" in result[0]


def test_search_file_invert_match_files_only(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("yes\nno\n")
    result = search_file(f, tmp_path, re.compile("zzz"), invert_match=True, files_only=True)
    assert result == ["a.py"]


def test_search_file_context_lines(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("line1\nline2\nMATCH\nline4\nline5\n")
    result = search_file(f, tmp_path, re.compile("MATCH"), context_lines=1)
    assert len(result) == 3  # line2, MATCH, line4


def test_search_file_context_separator(tmp_path):
    """Non-contiguous context regions get '--' separators."""
    f = tmp_path / "a.py"
    f.write_text("A\n" + "x\n" * 5 + "B\n")
    result = search_file(f, tmp_path, re.compile("[AB]"), context_lines=0)
    assert result[0].endswith("A")
    assert result[-1].endswith("B")
    assert "--" in result


def test_search_file_max_results(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("match\nmatch\nmatch\n")
    result = search_file(f, tmp_path, re.compile("match"), max_results=2)
    match_lines = [l for l in result if l != "--"]
    assert len(match_lines) == 2


def test_search_file_no_line_numbers(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("hello\n")
    result = search_file(f, tmp_path, re.compile("hello"), show_line_numbers=False)
    assert result == ["a.py:hello"]  # sep is ":" for match lines


def test_search_file_no_match(tmp_path):
    f = tmp_path / "a.py"
    f.write_text("nothing\n")
    result = search_file(f, tmp_path, re.compile("zzz"))
    assert result == []


def test_search_file_read_error():
    """Binary check passes but read_text fails."""
    result = search_file(Path("/nonexistent"), Path("/"), re.compile("x"))
    assert result == []


def test_search_file_read_text_permission_error(tmp_path):
    """File is not binary but read_text raises PermissionError."""
    from unittest.mock import patch
    f = tmp_path / "ok.py"
    f.write_text("hello")
    # is_binary returns False; read_text in search_file raises
    with patch("hypergolic.tools.file_search.is_binary", return_value=False):
        with patch.object(Path, "read_text", side_effect=PermissionError):
            result = search_file(f, tmp_path, re.compile("hello"))
    assert result == []


def test_search_file_context_no_line_numbers(tmp_path):
    """Context lines without line numbers use '-' separator."""
    f = tmp_path / "a.py"
    f.write_text("ctx\nMATCH\n")
    result = search_file(f, tmp_path, re.compile("MATCH"), context_lines=1, show_line_numbers=False)
    assert any("-ctx" in line or "ctx" in line for line in result)
    assert len(result) == 2
