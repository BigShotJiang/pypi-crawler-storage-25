"""Tests for tools/truncation.py."""

from typing import Any, cast

from hypergolic.tools.schemas import ToolOutput
from hypergolic.tools.truncation import result_block, truncate_tool_output


def _text(block: object) -> str:
    """Extract 'text' from a content block dict."""
    return cast(dict[str, Any], block)["text"]


def _texts(output: ToolOutput) -> list[str]:
    """Extract all text values from text blocks in output."""
    return [_text(b) for b in output.content if isinstance(b, dict) and b.get("type") == "text"]


# ── result_block ────────────────────────────────────────────────────


def test_result_block_basic():
    output = ToolOutput(content=[{"type": "text", "text": "ok"}], is_error=False)
    block = result_block("tu-1", output)
    assert block["tool_use_id"] == "tu-1"
    assert block["type"] == "tool_result"
    assert block["content"] == output.content
    assert block["is_error"] is False


def test_result_block_error():
    output = ToolOutput(content=[{"type": "text", "text": "bad"}], is_error=True)
    block = result_block("tu-2", output)
    assert block["is_error"] is True


# ── truncate_tool_output ────────────────────────────────────────────


def test_truncate_under_limit():
    output = ToolOutput(content=[{"type": "text", "text": "short"}])
    result = truncate_tool_output(output, limit=1000)
    assert result is output  # returned unchanged


def test_truncate_over_limit_single_block():
    output = ToolOutput(content=[{"type": "text", "text": "a" * 100}])
    result = truncate_tool_output(output, limit=50)
    texts = _texts(result)
    assert len(texts[0]) == 50  # truncated
    assert "truncated" in texts[-1].lower()


def test_truncate_over_limit_multiple_blocks():
    output = ToolOutput(content=[
        {"type": "text", "text": "a" * 30},
        {"type": "text", "text": "b" * 30},
    ])
    result = truncate_tool_output(output, limit=40)
    texts = _texts(result)
    # First block fits entirely (30 <= 40), second is truncated to 10
    assert texts[0] == "a" * 30
    assert texts[1] == "b" * 10
    assert "truncated" in texts[-1].lower()


def test_truncate_preserves_non_text_blocks():
    content: list[Any] = [
        {"type": "image", "data": "img"},
        {"type": "text", "text": "x" * 100},
    ]
    output = ToolOutput(content=content)
    result = truncate_tool_output(output, limit=10)
    assert result.content[0] == {"type": "image", "data": "img"}


def test_truncate_preserves_is_error():
    output = ToolOutput(content=[{"type": "text", "text": "x" * 100}], is_error=True)
    result = truncate_tool_output(output, limit=10)
    assert result.is_error is True


def test_truncate_with_zero_remaining_skips_later_blocks():
    """When remaining reaches 0, later text blocks are dropped entirely."""
    output = ToolOutput(content=[
        {"type": "text", "text": "a" * 50},
        {"type": "text", "text": "b" * 50},
    ])
    result = truncate_tool_output(output, limit=50)
    texts = _texts(result)
    # First block exactly uses the limit; second block is skipped (remaining=0)
    assert texts[0] == "a" * 50
    assert "truncated" in texts[-1].lower()
    assert len(texts) == 2  # the original first block + the truncation notice
