"""Tests for JSON-schema transforms in ``hypergolic.tools.json_schema``.

These are the token-efficiency passes applied to every tool schema sent to
the model. Semantics must be preserved while the wire form shrinks.
"""

from typing import Optional

from pydantic import BaseModel, Field

from hypergolic.tools.json_schema import (
    collapse_nullable_anyof,
    drop_default_null,
    optimize_schema,
    resolve_refs,
    strip_schema_noise,
)


# --- collapse_nullable_anyof ------------------------------------------------


def test_collapse_nullable_anyof_simple():
    schema = {
        "type": "object",
        "properties": {
            "max_depth": {
                "anyOf": [{"type": "integer"}, {"type": "null"}],
                "default": None,
            }
        },
    }
    collapse_nullable_anyof(schema)
    prop = schema["properties"]["max_depth"]
    assert "anyOf" not in prop
    assert prop["type"] == ["integer", "null"]
    # default untouched by this transform
    assert prop["default"] is None


def test_collapse_nullable_anyof_preserves_non_null_anyof():
    """anyOf with no null branch should be left alone."""
    schema = {
        "type": "object",
        "properties": {
            "x": {"anyOf": [{"type": "integer"}, {"type": "string"}]}
        },
    }
    before = {"anyOf": [{"type": "integer"}, {"type": "string"}]}
    collapse_nullable_anyof(schema)
    assert schema["properties"]["x"] == before


def test_collapse_nullable_anyof_preserves_complex_branch():
    """anyOf where a branch has more than just a ``type`` key should be left alone."""
    # e.g. Optional[list[str]] — the non-null branch carries ``items``
    schema = {
        "type": "object",
        "properties": {
            "xs": {
                "anyOf": [
                    {"type": "array", "items": {"type": "string"}},
                    {"type": "null"},
                ],
            }
        },
    }
    before = dict(schema["properties"]["xs"])
    collapse_nullable_anyof(schema)
    assert schema["properties"]["xs"] == before


def test_collapse_nullable_anyof_recurses_into_nested():
    schema = {
        "type": "object",
        "properties": {
            "outer": {
                "type": "object",
                "properties": {
                    "inner": {"anyOf": [{"type": "string"}, {"type": "null"}]}
                },
            }
        },
    }
    collapse_nullable_anyof(schema)
    inner = schema["properties"]["outer"]["properties"]["inner"]
    assert inner["type"] == ["string", "null"]
    assert "anyOf" not in inner


# --- drop_default_null ------------------------------------------------------


def test_drop_default_null_on_nullable_type_list():
    """After collapse, ``type: [T, null]`` makes ``default: null`` redundant."""
    schema = {
        "type": "object",
        "properties": {
            "x": {"type": ["integer", "null"], "default": None}
        },
    }
    drop_default_null(schema)
    assert "default" not in schema["properties"]["x"]


def test_drop_default_null_on_anyof_null():
    """Pre-collapse shape: anyOf with null branch is also nullable."""
    schema = {
        "type": "object",
        "properties": {
            "x": {
                "anyOf": [{"type": "integer"}, {"type": "null"}],
                "default": None,
            }
        },
    }
    drop_default_null(schema)
    assert "default" not in schema["properties"]["x"]


def test_drop_default_null_preserves_non_null_defaults():
    """A real default (e.g. 0, False, '') must be preserved."""
    schema = {
        "type": "object",
        "properties": {
            "a": {"type": ["integer", "null"], "default": 0},
            "b": {"type": "boolean", "default": False},
        },
    }
    drop_default_null(schema)
    assert schema["properties"]["a"]["default"] == 0
    assert schema["properties"]["b"]["default"] is False


def test_drop_default_null_keeps_default_on_non_nullable():
    """``default: null`` on a non-nullable field is weird but keep it — it changes semantics."""
    schema = {
        "type": "object",
        "properties": {
            "x": {"type": "integer", "default": None},
        },
    }
    drop_default_null(schema)
    # Nothing marks it nullable, so we do not drop.
    assert schema["properties"]["x"]["default"] is None


# --- optimize_schema (end to end) -------------------------------------------


def test_optimize_schema_on_pydantic_optional_field():
    """Real Pydantic output for Optional[int] with default None gets fully minified."""

    class MyInput(BaseModel):
        name: str
        max_depth: Optional[int] = None
        pattern: Optional[str] = Field(default=None, description="Glob pattern")

    schema = MyInput.model_json_schema()
    optimize_schema(schema)

    assert "title" not in schema
    assert schema["additionalProperties"] is False

    max_depth = schema["properties"]["max_depth"]
    assert max_depth["type"] == ["integer", "null"]
    assert "anyOf" not in max_depth
    assert "default" not in max_depth
    assert "title" not in max_depth

    pattern = schema["properties"]["pattern"]
    assert pattern["type"] == ["string", "null"]
    assert "anyOf" not in pattern
    assert "default" not in pattern
    # Field-level description must survive.
    assert pattern["description"] == "Glob pattern"


def test_optimize_schema_resolves_refs():
    """``$ref`` fields are inlined and ``$defs`` dropped."""
    schema = {
        "$defs": {"MyEnum": {"enum": ["a", "b"], "type": "string"}},
        "properties": {"x": {"$ref": "#/$defs/MyEnum"}},
        "type": "object",
    }
    optimize_schema(schema)
    assert "$defs" not in schema
    assert schema["properties"]["x"] == {"enum": ["a", "b"], "type": "string"}


# --- backward-compat exports from tools.schemas -----------------------------


def test_tools_schemas_reexports_strip_and_resolve():
    """Legacy underscored names are still importable from tools.schemas."""
    from hypergolic.tools.schemas import _resolve_refs, _strip_schema_noise

    assert _resolve_refs is resolve_refs
    assert _strip_schema_noise is strip_schema_noise
