"""Tests for $ref resolution in tool schemas."""

from enum import Enum
from typing import Any, cast

from pydantic import BaseModel

from hypergolic.tools.schemas import _resolve_refs, _strip_schema_noise


def test_resolve_refs_inlines_enum():
    """$ref to an enum in $defs should be inlined."""
    schema = {
        "$defs": {
            "SkillIdEnum": {
                "enum": ["toolkit-engineer", "prompt-engineer"],
                "type": "string",
            }
        },
        "properties": {
            "skill_ids": {
                "items": {"$ref": "#/$defs/SkillIdEnum"},
                "type": "array",
            }
        },
        "required": ["skill_ids"],
        "type": "object",
    }
    _resolve_refs(schema)
    assert "$defs" not in schema
    items = schema["properties"]["skill_ids"]["items"]
    assert items == {"enum": ["toolkit-engineer", "prompt-engineer"], "type": "string"}


def test_resolve_refs_no_defs():
    """When there are no $defs, schema is unchanged."""
    schema = {
        "properties": {"name": {"type": "string"}},
        "type": "object",
    }
    original = dict(schema)
    _resolve_refs(schema)
    assert schema == original


def test_resolve_refs_nested():
    """$ref inside anyOf should also be resolved."""
    schema = {
        "$defs": {
            "MyEnum": {"enum": ["a", "b"], "type": "string"}
        },
        "properties": {
            "value": {
                "anyOf": [
                    {"$ref": "#/$defs/MyEnum"},
                    {"type": "null"},
                ],
            }
        },
        "type": "object",
    }
    _resolve_refs(schema)
    assert "$defs" not in schema
    any_of = schema["properties"]["value"]["anyOf"]
    assert any_of[0] == {"enum": ["a", "b"], "type": "string"}
    assert any_of[1] == {"type": "null"}


def test_strip_schema_noise_resolves_refs():
    """_strip_schema_noise should resolve $ref before stripping."""
    schema = {
        "$defs": {
            "ColorEnum": {"enum": ["red", "blue"], "title": "ColorEnum", "type": "string"}
        },
        "properties": {
            "colors": {
                "items": {"$ref": "#/$defs/ColorEnum"},
                "title": "Colors",
                "type": "array",
            }
        },
        "required": ["colors"],
        "title": "MyModel",
        "type": "object",
    }
    _strip_schema_noise(schema)
    # $defs removed
    assert "$defs" not in schema
    # title removed
    assert "title" not in schema
    # additionalProperties added
    assert schema["additionalProperties"] is False
    # items inlined with enum values (title stripped)
    items = schema["properties"]["colors"]["items"]
    assert items["enum"] == ["red", "blue"]
    assert items["type"] == "string"
    assert "title" not in items


def test_to_param_with_enum_field():
    """Tool.to_param() should inline enum $refs from Pydantic models."""
    from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput

    MyEnum = Enum("MyEnum", {"alpha": "alpha", "beta": "beta"}, type=str)

    class MyInput(BaseModel):
        items: list[MyEnum]  # type: ignore[valid-type]

    async def noop(inp: BaseModel, ctx: ToolContext) -> ToolOutput:
        return ToolOutput()

    tool = Tool(
        id="test",
        name="Test",
        description="test",
        input=MyInput,
        call_tool=noop,
    )
    param = tool.to_param()
    # to_param returns ToolUnionParam; for custom tools it's a ToolParam dict
    schema: dict[str, Any] = cast(dict[str, Any], param)["input_schema"]
    # $defs should be resolved away
    assert "$defs" not in schema
    items_schema = schema["properties"]["items"]["items"]
    assert "enum" in items_schema
    assert sorted(items_schema["enum"]) == ["alpha", "beta"]
