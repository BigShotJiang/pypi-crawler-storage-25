"""Tests for ``shorten_path`` in ``hypergolic.tools.paths``.

Covers the D-strategy described in ``docs/path-rewrite-efficiency-findings.md``:
project-relative preferred, ``~`` fallback for paths under ``$HOME``, absolute
otherwise. Trailing-slash preservation and sibling-prefix non-match are
exercised explicitly.
"""

from pathlib import Path

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.paths import _is_under, shorten_path


def _session(project_path: str, worktree_path: str | None = None) -> Session:
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=project_path,
        role="generalist",
        worktree_path=worktree_path,
    )


# -- _is_under ----------------------------------------------------------------


def test_is_under_exact():
    assert _is_under("/a/b", "/a/b") is True


def test_is_under_child():
    assert _is_under("/a/b/c", "/a/b") is True


def test_is_under_sibling_prefix_false():
    # The headline bug the findings doc calls out explicitly.
    assert _is_under("/Users/RTownleyOther/foo", "/Users/RTownley") is False


def test_is_under_trailing_slash_on_root():
    assert _is_under("/a/b", "/a/") is True


# -- shorten_path: project-relative ------------------------------------------


def test_shorten_under_project_root(tmp_path):
    session = _session(str(tmp_path))
    p = str(tmp_path.resolve() / "src" / "app.py")
    assert shorten_path(p, session) == "src/app.py"


def test_shorten_equal_to_project_root_returns_dot(tmp_path):
    session = _session(str(tmp_path))
    assert shorten_path(str(tmp_path.resolve()), session) == "."


def test_shorten_trailing_slash_preserved_for_directories(tmp_path):
    session = _session(str(tmp_path))
    sub = tmp_path.resolve() / "sub"
    assert shorten_path(f"{sub}/", session) == "sub/"


def test_shorten_project_root_with_trailing_slash(tmp_path):
    session = _session(str(tmp_path))
    assert shorten_path(f"{tmp_path.resolve()}/", session) == "./"


# -- shorten_path: home-relative ---------------------------------------------


def test_shorten_home_relative_when_outside_project(tmp_path):
    # Project is tmp_path; target is under $HOME but NOT under project.
    session = _session(str(tmp_path))
    home = Path.home()
    target = str(home / "docs-notes.md")
    assert shorten_path(target, session) == "~/docs-notes.md"


def test_shorten_path_equal_to_home(tmp_path):
    session = _session(str(tmp_path))
    assert shorten_path(str(Path.home()), session) == "~"


def test_shorten_home_with_trailing_slash(tmp_path):
    session = _session(str(tmp_path))
    assert shorten_path(f"{Path.home()}/", session) == "~/"


# -- shorten_path: absolute fallback -----------------------------------------


def test_shorten_outside_both_returns_absolute(tmp_path):
    session = _session(str(tmp_path))
    # /etc is neither under tmp_path nor under $HOME on any sane system.
    assert shorten_path("/etc/hosts", session) == "/etc/hosts"


def test_shorten_sibling_prefix_not_rewritten_as_project(tmp_path):
    """A path that shares a string prefix with the project root but sits in a
    sibling directory must NOT be treated as in-project.

    If the sibling happens to live under ``$HOME`` it's fine for it to pick up
    the ``~`` rewrite — what we're guarding against is the more dangerous
    case of stripping the project prefix mid-segment.
    """
    project = tmp_path / "project"
    project.mkdir()
    sibling = tmp_path / "project-other"
    sibling.mkdir()
    (sibling / "foo.py").write_text("")
    session = _session(str(project))
    out = shorten_path(str((sibling / "foo.py").resolve()), session)
    # The project prefix is NOT stripped: output should contain 'project-other'
    # in its entirety rather than a bare '-other/foo.py'.
    assert "project-other/foo.py" in out
    assert not out.startswith("-other")


def test_shorten_empty_string(tmp_path):
    session = _session(str(tmp_path))
    assert shorten_path("", session) == ""


# -- shorten_path: no session ------------------------------------------------


def test_shorten_without_session_home_still_works():
    target = str(Path.home() / "x.txt")
    assert shorten_path(target, None) == "~/x.txt"


def test_shorten_without_session_outside_home_absolute():
    assert shorten_path("/etc/hosts", None) == "/etc/hosts"


# -- shorten_path: worktree sessions -----------------------------------------


def test_shorten_uses_worktree_not_project_path_in_worktree_session(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    worktree = tmp_path / "worktrees" / "CXSESSION"
    worktree.mkdir(parents=True)
    session = _session(str(project), worktree_path=str(worktree))
    target = str((worktree / "src" / "app.py").resolve())
    assert shorten_path(target, session) == "src/app.py"


def test_shorten_worktree_root_returns_dot(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    worktree = tmp_path / "worktrees" / "CXSESSION"
    worktree.mkdir(parents=True)
    session = _session(str(project), worktree_path=str(worktree))
    assert shorten_path(str(worktree.resolve()), session) == "."


def test_shorten_path_outside_worktree_still_falls_back_to_home(tmp_path):
    project = tmp_path / "project"
    project.mkdir()
    worktree = tmp_path / "worktrees" / "CXSESSION"
    worktree.mkdir(parents=True)
    session = _session(str(project), worktree_path=str(worktree))
    target = str(Path.home() / "notes.md")
    assert shorten_path(target, session) == "~/notes.md"


# -- shorten_path: resolve / home failure paths ------------------------------


def test_shorten_falls_back_when_project_resolve_fails(tmp_path, monkeypatch):
    """If resolving the project root raises, we still fall back to ``~``/absolute."""
    session = _session(str(tmp_path))
    real_resolve = Path.resolve
    target_str = str(tmp_path)

    def boom(self, *a, **kw):
        if str(self) == target_str:
            raise OSError("nope")
        return real_resolve(self, *a, **kw)

    monkeypatch.setattr(Path, "resolve", boom)
    # Target under home -> still gets the ~ rewrite.
    target = str(Path.home() / "a.txt")
    assert shorten_path(target, session) == "~/a.txt"


def test_shorten_falls_back_when_home_fails(tmp_path, monkeypatch):
    session = _session(str(tmp_path))

    def raising_home(cls):
        raise OSError("no home")

    monkeypatch.setattr(Path, "home", classmethod(raising_home))
    # With project still working, in-project path still rewrites.
    p = str(tmp_path.resolve() / "x.py")
    assert shorten_path(p, session) == "x.py"
    # Outside project, without home, falls through to absolute.
    assert shorten_path("/etc/hosts", session) == "/etc/hosts"
