"""Tests for hypergolic.tools.schemas.ToolOutput helpers."""

from typing import Any, cast

import pytest

from hypergolic.tools.schemas import ToolOutput


# ---------------------------------------------------------------------------
# ToolOutput.text / append_text
# ---------------------------------------------------------------------------


def test_text_constructor_builds_single_text_block():
    output = ToolOutput.text("hello")
    assert output.content == [{"type": "text", "text": "hello"}]
    assert output.is_error is False
    assert output.should_truncate is False


def test_text_constructor_with_flags():
    output = ToolOutput.text("boom", is_error=True, should_truncate=True)
    assert output.is_error is True
    assert output.should_truncate is True


def test_append_text_returns_new_instance_with_block_appended():
    original = ToolOutput.text("first")
    appended = original.append_text("second")

    assert appended is not original
    assert appended.content == [
        {"type": "text", "text": "first"},
        {"type": "text", "text": "second"},
    ]
    # Original unchanged
    assert original.content == [{"type": "text", "text": "first"}]


def test_append_text_preserves_flags():
    original = ToolOutput.text("x", is_error=True, should_truncate=True)
    appended = original.append_text("y")
    assert appended.is_error is True
    assert appended.should_truncate is True


# ---------------------------------------------------------------------------
# ToolOutput.iter_text_blocks / total_text_chars
# ---------------------------------------------------------------------------


def test_iter_text_blocks_yields_only_text_blocks():
    output = ToolOutput(content=[
        {"type": "text", "text": "a"},
        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "xxx"}},
        {"type": "text", "text": "b"},
    ])
    blocks = list(output.iter_text_blocks())
    assert len(blocks) == 2
    assert [b["text"] for b in blocks] == ["a", "b"]


def test_iter_text_blocks_empty_content():
    output = ToolOutput()
    assert list(output.iter_text_blocks()) == []


def test_total_text_chars_sums_across_text_blocks():
    output = ToolOutput(content=[
        {"type": "text", "text": "hello"},
        {"type": "text", "text": "world!"},
    ])
    assert output.total_text_chars() == len("hello") + len("world!")


def test_total_text_chars_ignores_non_text_blocks():
    output = ToolOutput(content=[
        {"type": "text", "text": "abc"},
        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "xxx"}},
    ])
    assert output.total_text_chars() == 3


def test_total_text_chars_empty():
    assert ToolOutput().total_text_chars() == 0


# ---------------------------------------------------------------------------
# ToolOutput.first_text
# ---------------------------------------------------------------------------


def test_first_text_returns_text_of_first_block():
    output = ToolOutput.text("hello")
    assert output.first_text() == "hello"


def test_first_text_raises_on_empty_content():
    output = ToolOutput()
    with pytest.raises(IndexError, match="no content blocks"):
        output.first_text()


def test_first_text_raises_when_first_block_is_not_text():
    output = ToolOutput(content=[
        {"type": "image", "source": {"type": "base64", "media_type": "image/png", "data": "xxx"}},
    ])
    with pytest.raises(TypeError, match="Expected text block, got 'image'"):
        output.first_text()


def test_first_text_raises_when_first_block_is_not_a_dict():
    # Bypass the type annotation to exercise the non-dict branch of the guard.
    output = ToolOutput(content=cast(Any, ["not a dict"]))
    with pytest.raises(TypeError, match="Expected text block, got 'str'"):
        output.first_text()
