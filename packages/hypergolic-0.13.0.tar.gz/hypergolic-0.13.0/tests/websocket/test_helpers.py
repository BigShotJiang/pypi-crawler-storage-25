from typing import Any, cast
from typing import Any, cast
from unittest.mock import patch, MagicMock

from anthropic import APIConnectionError, APIStatusError
from pydantic import BaseModel

from hypergolic.messages.types import BroadcastEvent
from hypergolic.websocket.helpers import (
    build_content_blocks,
    format_error_detail,
    persist_error,
    persist_error_message,
    serialize_event,
)
from hypergolic.websocket.schemas import ConnectMessage


def _text(block: object) -> str:
    """Extract 'text' from a content block dict."""
    return cast(dict[str, Any], block)["text"]


def test_serialize_event_basic():
    event = BroadcastEvent(
        type="test",
        role="user",
        content=[{"key": "val"}],
    )
    result = serialize_event(event)
    assert result["type"] == "test"
    assert result["role"] == "user"
    assert result["content"] == [{"key": "val"}]
    assert "session_id" not in result
    assert "model" not in result


def test_serialize_event_with_optional_fields():
    event = BroadcastEvent(
        type="t",
        role="assistant",
        content=[],
        session_id="s-1",
        model="claude",
        stop_reason="end_turn",
        message_id="m-1",
        usage={"input": 10, "output": 20},
    )
    result = serialize_event(event)
    assert result["session_id"] == "s-1"
    assert result["model"] == "claude"
    assert result["stop_reason"] == "end_turn"
    assert result["message_id"] == "m-1"
    assert result["usage"] == {"input": 10, "output": 20}


def test_serialize_event_pydantic_content():
    class Foo(BaseModel):
        x: int = 1

    event = BroadcastEvent(type="t", role="r", content=[Foo()])
    result = serialize_event(event)
    assert result["content"] == [{"x": 1}]


def test_serialize_event_non_dict_content():
    event = BroadcastEvent(type="t", role="r", content=[42])
    result = serialize_event(event)
    assert result["content"] == ["42"]


def test_build_content_blocks_text_only():
    req = ConnectMessage(message="hello")
    blocks = build_content_blocks(req)
    assert len(blocks) == 1
    assert blocks[0]["type"] == "text"
    assert blocks[0]["text"] == "hello"


def test_build_content_blocks_with_text_block():
    req = ConnectMessage(
        message="hello",
        content_blocks=[{"type": "text", "text": "preamble"}],
    )
    blocks = build_content_blocks(req)
    assert len(blocks) == 2
    assert blocks[0]["type"] == "text"
    assert cast(dict[str, Any], blocks[0])["text"] == "preamble"
    assert cast(dict[str, Any], blocks[1])["text"] == "hello"


def test_build_content_blocks_with_image_block():
    req = ConnectMessage(
        message="describe",
        content_blocks=[{
            "type": "image",
            "source": {"type": "base64", "media_type": "image/png", "data": "abc"},
        }],
    )
    blocks = build_content_blocks(req)
    assert len(blocks) == 2
    assert blocks[0]["type"] == "image"
    assert cast(dict[str, Any], blocks[1])["text"] == "describe"


def test_format_error_detail_generic():
    assert format_error_detail(ValueError("oops")) == "oops"


def test_format_error_detail_api_connection():
    exc = APIConnectionError(request=MagicMock())
    result = format_error_detail(exc)
    assert "Lost connection" in result


def test_format_error_detail_api_status():
    exc = APIStatusError(
        message="overloaded",
        response=MagicMock(status_code=529),
        body=None,
    )
    result = format_error_detail(exc)
    assert "529" in result
    assert "overloaded" in result



def test_format_error_detail_generic_empty_falls_back_to_class():
    class Weird(Exception):
        pass

    result = format_error_detail(Weird())
    assert result == "Weird"


def test_format_error_detail_api_connection_empty_inner():
    """APIConnectionError with empty str() should still surface something."""
    exc = APIConnectionError(request=MagicMock())
    # Force empty str representation
    exc.message = ""
    result = format_error_detail(exc)
    assert result.strip() != ""
    assert "Lost connection" in result


def test_persist_error_message():
    with patch("hypergolic.websocket.helpers.get_db") as mock_db:
        ctx = MagicMock()
        mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
        mock_db.return_value.__exit__ = MagicMock(return_value=False)
        persist_error_message("s-1", "something broke")
        ctx.add.assert_called_once()
        added = ctx.add.call_args[0][0]
        assert added.session_id == "s-1"
        assert added.role == "assistant"
        assert added.stop_reason == "error"
        assert added.content == [{"type": "text", "text": "something broke"}]


def test_persist_error_message_empty_detail_uses_fallback():
    """Empty detail must not produce an empty text block (breaks cache_control replay)."""
    with patch("hypergolic.websocket.helpers.get_db") as mock_db:
        ctx = MagicMock()
        mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
        mock_db.return_value.__exit__ = MagicMock(return_value=False)
        persist_error_message("s-1", "")
        added = ctx.add.call_args[0][0]
        assert added.content[0]["text"] != ""


def test_persist_error_message_whitespace_detail_uses_fallback():
    with patch("hypergolic.websocket.helpers.get_db") as mock_db:
        ctx = MagicMock()
        mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
        mock_db.return_value.__exit__ = MagicMock(return_value=False)
        persist_error_message("s-1", "   \n\t  ")
        added = ctx.add.call_args[0][0]
        assert added.content[0]["text"].strip() != ""


def test_persist_error():
    with patch("hypergolic.websocket.helpers.get_db") as mock_db:
        ctx = MagicMock()
        mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
        mock_db.return_value.__exit__ = MagicMock(return_value=False)
        persist_error("s-1", ValueError("boom"))
        ctx.add.assert_called_once()
        added = ctx.add.call_args[0][0]
        assert added.session_id == "s-1"
        assert added.error_type == "ValueError"


def test_persist_error_swallows_exception():
    with patch("hypergolic.websocket.helpers.get_db", side_effect=RuntimeError):
        # Should not raise
        persist_error("s-1", ValueError("boom"))
