import asyncio
from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

from anthropic.types import MessageParam

from hypergolic.messages.types import UserInterrupt
from hypergolic.websocket.session_turn import run_session_turn


def _make_deps():
    ws = AsyncMock()
    broadcast = AsyncMock()
    approval_callback = AsyncMock()
    client = MagicMock()
    cancel_event = asyncio.Event()
    return ws, broadcast, approval_callback, client, cancel_event


def _user_message() -> MessageParam:
    """Build a simple user message."""
    msg: MessageParam = {"role": "user", "content": [{"type": "text", "text": "hi"}]}
    return msg


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.finalize_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.get_git_status")
async def test_successful_turn(mock_git, mock_finalize, mock_create, mock_load):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_session = MagicMock()
    mock_session.working_directory.return_value = "/tmp"
    mock_load.return_value = mock_session
    mock_git.return_value = MagicMock(model_dump=lambda: {"branch": "main"})

    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)

    mock_create.assert_called_once()
    mock_finalize.assert_called_once()
    # done message sent
    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "done"
    assert sent["git_status"] == {"branch": "main"}


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.finalize_turn", new_callable=AsyncMock)
async def test_successful_turn_git_fails(mock_finalize, mock_create, mock_load):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_session = MagicMock()
    # First call for create_message, second for git status which fails
    mock_load.side_effect = [mock_session, Exception("no git")]

    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)

    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "done"
    assert "git_status" not in sent


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.set_session_status_and_broadcast", new_callable=AsyncMock)
async def test_user_interrupt(mock_status, mock_create, mock_load):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.return_value = MagicMock()
    mock_create.side_effect = UserInterrupt(partial_text="partial...")

    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)

    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "interrupted"
    assert sent["partial_text"] == "partial..."


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.set_session_status_and_broadcast", new_callable=AsyncMock)
async def test_user_interrupt_no_partial(mock_status, mock_create, mock_load):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.return_value = MagicMock()
    mock_create.side_effect = UserInterrupt()

    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)

    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "interrupted"
    assert "partial_text" not in sent


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.set_session_status_and_broadcast", new_callable=AsyncMock)
async def test_user_interrupt_send_fails(mock_status, mock_create, mock_load):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.return_value = MagicMock()
    mock_create.side_effect = UserInterrupt()
    ws.send_json.side_effect = Exception("ws closed")

    # Should not raise
    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.set_session_status_and_broadcast", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.persist_error_message")
@patch("hypergolic.websocket.session_turn.persist_error")
@patch("hypergolic.websocket.session_turn.fail_dispatch_if_child")
async def test_error_during_turn(mock_fail, mock_perr, mock_perr_msg, mock_status, mock_create, mock_load):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.return_value = MagicMock()
    mock_create.side_effect = RuntimeError("model exploded")

    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)

    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "error"
    assert "model exploded" in sent["detail"]
    mock_perr_msg.assert_called_once()
    mock_perr.assert_called_once()
    mock_fail.assert_called_once()


@patch("hypergolic.websocket.session_turn.load_session")
@patch("hypergolic.websocket.session_turn.create_message", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.set_session_status_and_broadcast", new_callable=AsyncMock)
@patch("hypergolic.websocket.session_turn.persist_error_message")
@patch("hypergolic.websocket.session_turn.persist_error")
@patch("hypergolic.websocket.session_turn.fail_dispatch_if_child")
async def test_error_during_turn_send_fails(
    mock_fail, mock_perr, mock_perr_msg, mock_status, mock_create, mock_load,
):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.return_value = MagicMock()
    mock_create.side_effect = RuntimeError("boom")
    ws.send_json.side_effect = Exception("ws closed")

    # Should not raise despite send failure
    await run_session_turn("s-1", _user_message(), cancel, client, ws, broadcast, approval_callback)
