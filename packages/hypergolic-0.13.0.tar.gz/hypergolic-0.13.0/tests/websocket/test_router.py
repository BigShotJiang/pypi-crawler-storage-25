import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from fastapi import WebSocketDisconnect

from hypergolic.websocket.router import websocket_endpoint


async def test_unauthorized():
    ws = AsyncMock()
    ws.cookies = {"h_token": "bad"}

    with patch("hypergolic.websocket.router.verify_token", return_value=False):
        await websocket_endpoint(ws)

    ws.close.assert_called_once_with(code=4003, reason="Unauthorized")
    ws.accept.assert_not_called()


async def test_unauthorized_no_token():
    ws = AsyncMock()
    ws.cookies = {}

    with patch("hypergolic.websocket.router.verify_token", return_value=False):
        await websocket_endpoint(ws)

    ws.close.assert_called_once_with(code=4003, reason="Unauthorized")


@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_disconnect(mock_verify, mock_register):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}
    ws.receive_json.side_effect = WebSocketDisconnect()

    await websocket_endpoint(ws)

    ws.accept.assert_called_once()


@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_unexpected_error(mock_verify, mock_register):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}
    ws.receive_json.side_effect = RuntimeError("boom")

    await websocket_endpoint(ws)

    ws.accept.assert_called_once()


@patch("hypergolic.websocket.router.handle_conclude_session", new_callable=AsyncMock)
@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_conclude_message(mock_verify, mock_register, mock_conclude):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}
    ws.receive_json.side_effect = [
        {"type": "conclude_session", "session_id": "s-1", "rating": 5},
        WebSocketDisconnect(),
    ]

    await websocket_endpoint(ws)
    mock_conclude.assert_called_once()


@patch("hypergolic.websocket.router.resolve_approval_response")
@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_approval_message(mock_verify, mock_register, mock_resolve):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}
    ws.receive_json.side_effect = [
        {"type": "tool_approval_response", "tool_use_id": "tu-1", "approved": True},
        WebSocketDisconnect(),
    ]

    await websocket_endpoint(ws)
    mock_resolve.assert_called_once()


@patch("hypergolic.websocket.router.handle_connect", new_callable=AsyncMock)
@patch("hypergolic.websocket.router.cancel_child_dispatches")
@patch("hypergolic.websocket.router.get_client", return_value=MagicMock())
@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_chat_message(mock_verify, mock_register, mock_client, mock_cancel, mock_connect):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}

    call_count = [0]
    async def receive_json_side_effect():
        call_count[0] += 1
        if call_count[0] == 1:
            return {"type": "chat", "message": "hello", "session_id": "s-1"}
        # Give the task time to run before disconnecting
        await asyncio.sleep(0.05)
        raise WebSocketDisconnect()

    ws.receive_json = receive_json_side_effect

    await websocket_endpoint(ws)

    mock_cancel.assert_called_once_with("s-1")
    mock_connect.assert_called_once()


@patch("hypergolic.websocket.router.handle_connect", new_callable=AsyncMock)
@patch("hypergolic.websocket.router.cancel_child_dispatches")
@patch("hypergolic.websocket.router.get_client", return_value=MagicMock())
@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_chat_new_session(mock_verify, mock_register, mock_client, mock_cancel, mock_connect):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}

    call_count = [0]
    async def receive_json_side_effect():
        call_count[0] += 1
        if call_count[0] == 1:
            return {"type": "chat", "message": "hello", "project_id": "p-1"}
        await asyncio.sleep(0.05)
        raise WebSocketDisconnect()

    ws.receive_json = receive_json_side_effect

    await websocket_endpoint(ws)

    mock_cancel.assert_called_once_with("__new__")


@patch("hypergolic.websocket.router.verify_token", return_value=True)
@patch("hypergolic.websocket.router.register_turn_runner")
async def test_close_failure_swallowed(mock_register, mock_verify):
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}
    ws.receive_json.side_effect = WebSocketDisconnect()
    ws.close.side_effect = Exception("already closed")

    # Should not raise
    await websocket_endpoint(ws)


@patch("hypergolic.websocket.router.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.router.get_client", return_value=MagicMock())
@patch("hypergolic.websocket.router.serialize_event", return_value={"type": "t"})
@patch("hypergolic.websocket.router.register_turn_runner")
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_broadcast_closure(mock_verify, mock_register, mock_serial, mock_client, mock_run):
    """Exercise the broadcast inner function (line 39)."""
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}

    from hypergolic.messages.types import BroadcastEvent

    async def fake_handle_connect(req, cancel_event, client, ws_arg, broadcast, approval_callback):
        # Call the real broadcast closure to cover line 39
        await broadcast(BroadcastEvent(type="test", role="system", content=[]))

    call_count = [0]
    async def receive_json_side_effect():
        call_count[0] += 1
        if call_count[0] == 1:
            return {"type": "chat", "message": "hi", "session_id": "s-1"}
        await asyncio.sleep(0.05)
        raise WebSocketDisconnect()

    ws.receive_json = receive_json_side_effect

    with patch("hypergolic.websocket.router.handle_connect", side_effect=fake_handle_connect):
        with patch("hypergolic.websocket.router.cancel_child_dispatches"):
            await websocket_endpoint(ws)

    # broadcast should have called ws.send_json with serialized event
    assert any(
        call.args[0] == {"type": "t"}
        for call in ws.send_json.call_args_list
    )


@patch("hypergolic.websocket.router.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.router.get_client", return_value=MagicMock())
@patch("hypergolic.websocket.router.verify_token", return_value=True)
async def test_start_child_turn_closure(mock_verify, mock_client, mock_run):
    """Exercise the start_child_turn closure (lines 44-51)."""
    ws = AsyncMock()
    ws.cookies = {"h_token": "ok"}

    captured_runner = [None]

    def capture_runner(runner):
        captured_runner[0] = runner

    ws.receive_json.side_effect = WebSocketDisconnect()

    with patch("hypergolic.websocket.router.register_turn_runner", side_effect=capture_runner):
        await websocket_endpoint(ws)

    # Now call the captured turn runner outside the endpoint
    runner = captured_runner[0]
    assert runner is not None

    # We need to run the child turn in an event loop context
    # The runner calls tm.start_turn which creates a task
    # But tm is local to the websocket_endpoint, so we can't directly test.
    # Instead, let's test it indirectly by calling the runner function.
    # The runner is start_child_turn(child_session_id, message)
    # It will try to create a task, which needs an event loop.
    runner("child-1", {"role": "user", "content": [{"type": "text", "text": "hi"}]})
    # Give the task a chance to run
    await asyncio.sleep(0.05)
    mock_run.assert_called_once()
