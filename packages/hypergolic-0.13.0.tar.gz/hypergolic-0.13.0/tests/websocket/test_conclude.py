import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.websocket.conclude import handle_conclude_session
from hypergolic.websocket.schemas import ConcludeSessionMessage
from hypergolic.websocket.turn_manager import TurnManager


def _make_msg(session_id="s-1", rating=4, feedback="good"):
    return ConcludeSessionMessage(
        session_id=session_id,
        rating=rating,
        feedback=feedback,
    )


@patch("hypergolic.websocket.conclude.cancel_child_dispatches")
@patch("hypergolic.websocket.conclude.get_db")
async def test_conclude_basic(mock_db, mock_cancel):
    ws = AsyncMock()
    tm = TurnManager()
    broadcast = AsyncMock()

    ctx = MagicMock()
    # Return no children
    ctx.execute.return_value.all.return_value = []
    mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
    mock_db.return_value.__exit__ = MagicMock(return_value=False)

    msg = _make_msg()
    await handle_conclude_session(msg, ws, tm, broadcast)

    mock_cancel.assert_called_once_with("s-1")
    broadcast.assert_called_once()
    event = broadcast.call_args[0][0]
    assert event.type == "session_status_change"

    # session_concluded sent to ws
    ws.send_json.assert_called_once()
    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "session_concluded"
    assert sent["conclusion_rating"] == 4
    assert sent["conclusion_feedback"] == "good"


@patch("hypergolic.websocket.conclude.cancel_child_dispatches")
@patch("hypergolic.websocket.conclude.get_db")
async def test_conclude_with_children(mock_db, mock_cancel):
    ws = AsyncMock()
    tm = TurnManager()
    broadcast = AsyncMock()

    ctx = MagicMock()
    # First call: child query, second call: conclusion update
    child_result = MagicMock()
    child_result.all.return_value = [("child-1", "idle")]
    update_result = MagicMock()

    call_count = [0]
    def fake_execute(stmt):
        call_count[0] += 1
        if call_count[0] == 1:
            return child_result  # select children
        return update_result  # update child / update parent

    ctx.execute = fake_execute
    mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
    mock_db.return_value.__exit__ = MagicMock(return_value=False)

    msg = _make_msg()
    await handle_conclude_session(msg, ws, tm, broadcast)

    # Should have concluded child session too
    assert call_count[0] >= 2


@pytest.mark.timeout(2)
@patch("hypergolic.websocket.conclude.cancel_child_dispatches")
@patch("hypergolic.websocket.conclude.get_db")
async def test_conclude_cancels_active_turn(mock_db, mock_cancel):
    ws = AsyncMock()
    tm = TurnManager()
    broadcast = AsyncMock()

    # Start an active turn
    async def long_coro(cancel_event: asyncio.Event) -> None:
        await asyncio.sleep(10)

    tm.start_turn("s-1", long_coro)

    ctx = MagicMock()
    ctx.execute.return_value.all.return_value = []
    mock_db.return_value.__enter__ = MagicMock(return_value=ctx)
    mock_db.return_value.__exit__ = MagicMock(return_value=False)

    msg = _make_msg()
    await handle_conclude_session(msg, ws, tm, broadcast)

    # Turn should have been cancelled
    assert "s-1" not in tm.session_tasks or tm.session_tasks["s-1"].done()
