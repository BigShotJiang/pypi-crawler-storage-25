import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

from hypergolic.websocket.connect import handle_connect
from hypergolic.websocket.schemas import ConnectMessage


def _make_deps():
    ws = AsyncMock()
    broadcast = AsyncMock()
    approval_callback = AsyncMock()
    client = MagicMock()
    cancel_event = asyncio.Event()
    return ws, broadcast, approval_callback, client, cancel_event


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.load_session")
async def test_existing_session(mock_load, mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    session = MagicMock()
    session.id = "s-1"
    mock_load.return_value = session

    req = ConnectMessage(message="hello", session_id="s-1")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    mock_load.assert_called_once_with("s-1")
    mock_run.assert_called_once()


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.create_session")
async def test_new_session(mock_create, mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    session = MagicMock()
    session.id = "s-new"
    mock_create.return_value = session

    req = ConnectMessage(message="hello", project_id="p-1")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    mock_create.assert_called_once()
    mock_run.assert_called_once()


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
async def test_new_session_missing_project_id(mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()

    req = ConnectMessage(message="hello")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    # Should send error
    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "error"
    assert "project_id" in sent["detail"]
    mock_run.assert_not_called()


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.activate_workflow", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.load_session")
async def test_with_workflow(mock_load, mock_wf, mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    session = MagicMock()
    session.id = "s-1"
    mock_load.return_value = session

    req = ConnectMessage(message="go", session_id="s-1", workflow_id="wf-1")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    mock_wf.assert_called_once()
    mock_run.assert_called_once()


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.activate_workflow", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.load_session")
async def test_workflow_error(mock_load, mock_wf, mock_run):
    from hypergolic.workflows.engine import WorkflowError

    ws, broadcast, approval_callback, client, cancel = _make_deps()
    session = MagicMock()
    session.id = "s-1"
    mock_load.return_value = session
    mock_wf.side_effect = WorkflowError("not found")

    req = ConnectMessage(message="go", session_id="s-1", workflow_id="wf-bad")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "error"
    assert "not found" in sent["detail"]
    mock_run.assert_not_called()


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.load_session")
@patch("hypergolic.websocket.connect.set_session_status_and_broadcast", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.persist_error_message")
@patch("hypergolic.websocket.connect.persist_error")
async def test_error_persisted(mock_perr, mock_perr_msg, mock_status, mock_load, mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.side_effect = RuntimeError("db fail")

    req = ConnectMessage(message="go", session_id="s-1")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    sent = ws.send_json.call_args[0][0]
    assert sent["type"] == "error"
    assert "db fail" in sent["detail"]


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.create_session")
@patch("hypergolic.websocket.connect.set_session_status_and_broadcast", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.persist_error_message")
@patch("hypergolic.websocket.connect.persist_error")
async def test_error_with_session_id_persists(mock_perr, mock_perr_msg, mock_status, mock_create, mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    session = MagicMock()
    session.id = "s-1"
    mock_create.return_value = session
    mock_run.side_effect = RuntimeError("turn fail")

    req = ConnectMessage(message="go", project_id="p-1")
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)

    mock_status.assert_called_once()
    mock_perr_msg.assert_called_once()
    mock_perr.assert_called_once()


@patch("hypergolic.websocket.connect.run_session_turn", new_callable=AsyncMock)
@patch("hypergolic.websocket.connect.load_session")
async def test_error_send_fails(mock_load, mock_run):
    ws, broadcast, approval_callback, client, cancel = _make_deps()
    mock_load.side_effect = RuntimeError("fail")
    ws.send_json.side_effect = Exception("ws closed")

    req = ConnectMessage(message="go", session_id="s-1")
    # Should not raise
    await handle_connect(req, cancel, client, ws, broadcast, approval_callback)
