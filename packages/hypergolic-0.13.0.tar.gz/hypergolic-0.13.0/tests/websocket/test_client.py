from unittest.mock import patch, MagicMock

from hypergolic.websocket.client import get_client, reset_client


def test_get_client_creates_once():
    reset_client()
    mock = MagicMock()
    with patch("hypergolic.websocket.client.create_client", return_value=mock) as factory:
        c1 = get_client()
        c2 = get_client()
    assert c1 is mock
    assert c2 is mock
    factory.assert_called_once()
    reset_client()


def test_reset_client():
    reset_client()
    with patch("hypergolic.websocket.client.create_client", return_value=MagicMock()) as factory:
        get_client()
        reset_client()
        get_client()
    assert factory.call_count == 2
    reset_client()
