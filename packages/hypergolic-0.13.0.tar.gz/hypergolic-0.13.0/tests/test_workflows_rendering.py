"""Tests for hypergolic.workflows.rendering."""

import json

from hypergolic.workflows.rendering import render_artifact_text


# ---------------------------------------------------------------------------
# render_artifact_text
# ---------------------------------------------------------------------------


def test_render_artifact_text_basic():
    result = render_artifact_text("art-1", {"summary": "All done"}, "2024-01-01T00:00:00")
    assert "# Artifact: art-1 (2024-01-01T00:00:00)" in result
    assert "All done" in result


def test_render_artifact_text_string_value_not_bolded():
    """String values are inserted as-is (no bold key heading)."""
    result = render_artifact_text("a", {"notes": "plain text"}, "ts")
    # String values should appear directly
    assert "plain text" in result
    # Key should NOT appear as a bolded heading for string values
    assert "**Notes:**" not in result


def test_render_artifact_text_list_value():
    result = render_artifact_text("a", {"items": ["x", "y"]}, "ts")
    assert "**Items:**" in result
    assert json.dumps(["x", "y"]) in result


def test_render_artifact_text_dict_value():
    result = render_artifact_text("a", {"meta_data": {"key": "val"}}, "ts")
    assert "**Meta Data:**" in result
    assert json.dumps({"key": "val"}) in result


def test_render_artifact_text_integer_value():
    result = render_artifact_text("a", {"count": 42}, "ts")
    assert "**Count:**" in result
    assert "42" in result


def test_render_artifact_text_boolean_value():
    result = render_artifact_text("a", {"done": True}, "ts")
    assert "**Done:**" in result
    assert "true" in result.lower()


def test_render_artifact_text_multiple_keys():
    content = {"title": "Hello", "tags": ["a", "b"], "score": 99}
    result = render_artifact_text("art-x", content, "2025-01-01")
    assert "# Artifact: art-x (2025-01-01)" in result
    # All entries should appear
    assert "Hello" in result
    assert "**Tags:**" in result
    assert "**Score:**" in result


def test_render_artifact_text_empty_content():
    result = render_artifact_text("art-empty", {}, "ts")
    assert "# Artifact: art-empty (ts)" in result
    # No extra content beyond the header
    lines = [l for l in result.split("\n") if l.strip()]
    assert len(lines) == 1


def test_render_artifact_text_multiword_key():
    """Keys with underscores are title-cased."""
    result = render_artifact_text("a", {"final_output": [1, 2, 3]}, "ts")
    assert "**Final Output:**" in result
