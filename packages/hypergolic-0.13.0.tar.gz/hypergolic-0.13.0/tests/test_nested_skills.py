"""Tests for nested skills, skill tool refactor, and validation.

Covers:
- Skill model nesting
- Validation: collect_all_skills, detect_skill_cycles, duplicate IDs
- Lookup: _find_in_skill, find_skill with nested skills
- Resolver: _flatten_skills, resolve_skills with nested skills
- Skill handlers: handle_activate_skill, handle_deactivate_skill
- Tool builders: resolve_session_skills, _build_activate_skill_tool,
  _build_deactivate_skill_tool, and integration with build_tools
"""

import asyncio
from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock, patch

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.schemas import Session
from hypergolic.skills.resolver import _flatten_skills, resolve_session_skills, resolve_skills
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.lookup import (
    _find_in_skill,
    collect_top_level_skills,
    find_skill,
)
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.app.validation import _collect_all_skills, _detect_skill_cycles
from hypergolic.toolkit.primitives import Role, Skill, Workflow, WorkflowState
from hypergolic.toolkit.project import Project
from hypergolic.tools.schemas import ToolContext
from hypergolic.tools.skills import (
    build_activate_skill_description,
    build_deactivate_skill_description,
    handle_activate_skill,
    handle_deactivate_skill,
)
from hypergolic.tools.tool_list import (
    _build_activate_skill_tool,
    _build_deactivate_skill_tool,
    build_tools,
)
from tests._factories import build_session, build_skill as _skill
from tests.conftest import make_project, make_session


def _make_session_obj(
    sid: str = "s1",
    project_id: str = "p1",
    role: str = "generalist",
    parent_id: str | None = None,
    active_skill_ids: set[str] | None = None,
) -> Session:
    return build_session(
        sid=sid,
        project_id=project_id,
        project_path="/tmp/p1",
        role=role,
        parent_id=parent_id,
        active_skill_ids=active_skill_ids,
    )


def _text(block: object) -> str:
    return cast(dict[str, Any], block)["text"]


def _make_tool_context(session: Session) -> ToolContext:
    return ToolContext(session=session, broadcast=AsyncMock(), tool_id="activate_skill")


def _make_input(**kwargs) -> MagicMock:
    inp = MagicMock()
    for k, v in kwargs.items():
        setattr(inp, k, v)
    return inp


def _setup_app_with_skills() -> App:
    """Create an app with skills, roles, and set it as the global app."""
    from hypergolic.base.roles.registry import ALL_BASE_ROLES
    from hypergolic.base.tools.registry import UNIVERSAL_TOOLS

    app = App()
    app.register_roles(ALL_BASE_ROLES)
    app.register_tools(UNIVERSAL_TOOLS)

    child = _skill("child-skill", prompt="Child prompt")
    parent = _skill("parent-skill", prompt="Parent prompt", children=[child])
    app.register_skill(parent)
    set_app(app)
    return app


# --- Skill model ---------------------------------------------------------


def test_skill_with_no_children():
    s = Skill(id="solo", name="Solo", description="A skill")
    assert s.skills == []


def test_skill_with_children():
    child = _skill("child")
    parent = _skill("parent", children=[child])
    assert len(parent.skills) == 1
    assert parent.skills[0].id == "child"


def test_skill_deep_nesting():
    c = _skill("c")
    b = _skill("b", children=[c])
    a = _skill("a", children=[b])
    assert a.skills[0].id == "b"
    assert a.skills[0].skills[0].id == "c"


# --- Validation ----------------------------------------------------------


def test_validate_unique_skill_ids_pass():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_skill(_skill("a"))
    app.register_skill(_skill("b"))
    errors = app._validate()
    assert [e for e in errors if "skill" in e.lower()] == []


def test_validate_duplicate_skill_ids():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_skill(_skill("dup"))
    app.register_skill(_skill("dup"))
    errors = app._validate()
    assert any("Duplicate skill ID" in e and "dup" in e for e in errors)


def test_validate_duplicate_nested_skill_ids():
    """A nested child with the same ID as a top-level skill → error."""
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    child = _skill("same-id")
    parent = _skill("parent", children=[child])
    app.register_skill(parent)
    app.register_skill(_skill("same-id"))
    errors = app._validate()
    assert any("Duplicate skill ID" in e and "same-id" in e for e in errors)


def test_validate_cycle_direct():
    # A has child B (via separate object); B has child A — IDs form a cycle.
    a = _skill("a", children=[_skill("b")])
    b = _skill("b", children=[_skill("a")])
    all_skills = [a, a.skills[0], b, b.skills[0]]

    errors = _detect_skill_cycles(all_skills)
    assert any("Circular skill dependency" in e for e in errors)


def test_validate_cycle_indirect():
    # A→B, B→C, C→A
    a = _skill("a", children=[_skill("b")])
    b = _skill("b", children=[_skill("c")])
    c = _skill("c", children=[_skill("a")])
    all_skills = [a, a.skills[0], b, b.skills[0], c, c.skills[0]]

    errors = _detect_skill_cycles(all_skills)
    assert any("Circular skill dependency" in e for e in errors)


def test_validate_no_cycle():
    b = _skill("b")
    a = _skill("a", children=[b])
    d = _skill("d")
    c = _skill("c", children=[d])

    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_skill(a)
    app.register_skill(c)
    errors = app._validate()
    assert [e for e in errors if "Circular" in e] == []


def test_collect_all_skills():
    c = _skill("c")
    b = _skill("b", children=[c])
    a = _skill("a", children=[b])

    all_skills = _collect_all_skills([a])
    assert [s.id for s in all_skills] == ["a", "b", "c"]


def test_detect_skill_cycles_empty():
    assert _detect_skill_cycles([]) == []


def test_detect_skill_cycles_diamond_no_cycle():
    """Diamond: A→B, A→C, B→D, C→D — no cycle."""
    a = _skill("a", children=[_skill("b"), _skill("c")])
    b = _skill("b", children=[_skill("d")])
    c = _skill("c", children=[_skill("d")])
    d = _skill("d")
    all_skills = [a, a.skills[0], a.skills[1], b, b.skills[0], c, c.skills[0], d]

    assert _detect_skill_cycles(all_skills) == []


# --- Lookup --------------------------------------------------------------


def test_find_in_skill_direct():
    a = _skill("a")
    assert _find_in_skill("a", a) is a


def test_find_in_skill_nested():
    c = _skill("c")
    b = _skill("b", children=[c])
    a = _skill("a", children=[b])
    assert _find_in_skill("c", a) is c


def test_find_in_skill_not_found():
    a = _skill("a")
    assert _find_in_skill("nonexistent", a) is None


def test_find_skill_in_nested_app_skills():
    child = _skill("nested-child")
    parent = _skill("top", children=[child])

    app = App()
    app.register_skill(parent)
    assert find_skill("nested-child", app) is child


def test_find_skill_in_nested_project_skills():
    child = _skill("proj-nested")
    parent = _skill("proj-top", children=[child])
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp/p1", skills=[parent])
    app = App()
    app.register_project(proj)
    assert find_skill("proj-nested", app) is child


def test_find_skill_in_nested_role_skills():
    child = _skill("role-nested")
    parent = _skill("role-top", children=[child])
    role = Role(id="r1", name="R1", prompt="test", skills=[parent])
    app = App()
    app.register_role(role)
    assert find_skill("role-nested", app) is child


def test_find_skill_in_nested_workflow_skills():
    child = _skill("wf-nested")
    parent = _skill("wf-top", children=[child])
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
        skills=[parent],
    )
    app = App()
    app.register_workflow(wf)
    assert find_skill("wf-nested", app) is child


def test_find_skill_in_nested_workflow_state_skills():
    child = _skill("state-nested")
    parent = _skill("state-top", children=[child])
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t", skills=[parent])],
    )
    app = App()
    app.register_workflow(wf)
    assert find_skill("state-nested", app) is child


def test_find_skill_in_nested_project_workflow_skills():
    child = _skill("pw-nested")
    parent = _skill("pw-top", children=[child])
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
        skills=[parent],
    )
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp/p1", workflows=[wf])
    app = App()
    app.register_project(proj)
    assert find_skill("pw-nested", app) is child


def test_find_skill_in_nested_project_workflow_state_skills():
    child = _skill("pws-nested")
    parent = _skill("pws-top", children=[child])
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t", skills=[parent])],
    )
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp/p1", workflows=[wf])
    app = App()
    app.register_project(proj)
    assert find_skill("pws-nested", app) is child


def test_find_skill_returns_none_when_not_found():
    app = App()
    assert find_skill("nonexistent", app) is None


# --- collect_top_level_skills --------------------------------------------


def test_collect_top_level_skills_all_sources():
    app_skill = _skill("app-skill")
    proj_skill = _skill("proj-skill")
    role_skill = _skill("role-skill")
    wf_skill = _skill("wf-skill")
    state_skill = _skill("state-skill")
    proj_wf_skill = _skill("proj-wf-skill")
    proj_state_skill = _skill("proj-state-skill")

    app = App()
    app.register_skill(app_skill)
    app.register_project(Project(
        id="p1", name="P1", description="d", git_root="/tmp/p1",
        skills=[proj_skill],
        workflows=[Workflow(
            id="pwf", name="PWF", description="d", initial_state="ps1",
            states=[WorkflowState(id="ps1", name="PS1", prompt="t", skills=[proj_state_skill])],
            skills=[proj_wf_skill],
        )],
    ))
    app.register_role(Role(id="r1", name="R1", prompt="t", skills=[role_skill]))
    app.register_workflow(Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t", skills=[state_skill])],
        skills=[wf_skill],
    ))

    result = collect_top_level_skills(app)
    assert {s.id for s in result} == {
        "app-skill", "proj-skill", "role-skill",
        "wf-skill", "state-skill", "proj-wf-skill", "proj-state-skill",
    }


def test_collect_top_level_skills_empty():
    app = App()
    assert collect_top_level_skills(app) == []


# --- Resolver ------------------------------------------------------------


def test_flatten_skills():
    c = _skill("c", prompt="c-prompt")
    b = _skill("b", prompt="b-prompt", children=[c])
    a = _skill("a", prompt="a-prompt", children=[b])

    result: list[dict] = []
    seen: set[str] = set()
    _flatten_skills([a], seen, result)

    assert [s["id"] for s in result] == ["a", "b", "c"]
    assert seen == {"a", "b", "c"}


def test_flatten_skills_deduplicates():
    shared = _skill("shared", prompt="p")
    a = _skill("a", children=[shared])
    b = _skill("b", children=[shared])

    result: list[dict] = []
    seen: set[str] = set()
    _flatten_skills([a, b], seen, result)

    assert [s["id"] for s in result].count("shared") == 1


def test_resolve_skills_includes_nested():
    child = _skill("nested-child", prompt="child prompt")
    parent = _skill("parent", prompt="parent prompt", children=[child])

    app = App()
    app.register_skill(parent)
    set_app(app)

    ids = [s["id"] for s in resolve_skills()]
    assert "parent" in ids
    assert "nested-child" in ids


def test_flatten_skills_with_prompt_path():
    s = Skill(id="with-path", name="WithPath", description="d", prompt_path="~/some/path.md")
    result: list[dict] = []
    seen: set[str] = set()
    _flatten_skills([s], seen, result)

    assert result[0]["prompt_path"] != ""
    assert "~" not in result[0]["prompt_path"]


def test_resolve_skills_includes_role_skills():
    role_skill = _skill("role-only", prompt="role prompt")
    role = Role(id="r1", name="R1", prompt="t", skills=[role_skill])

    app = App()
    app.register_role(role)
    set_app(app)

    assert "role-only" in [s["id"] for s in resolve_skills()]


def test_resolve_skills_includes_workflow_skills():
    wf_skill = _skill("wf-only", prompt="wf prompt")
    state_skill = _skill("state-only", prompt="state prompt")
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t", skills=[state_skill])],
        skills=[wf_skill],
    )

    app = App()
    app.register_workflow(wf)
    set_app(app)

    ids = [s["id"] for s in resolve_skills()]
    assert "wf-only" in ids
    assert "state-only" in ids


def test_resolve_skills_includes_project_workflow_skills():
    proj_wf_skill = _skill("proj-wf-skill", prompt="pwf")
    proj_state_skill = _skill("proj-state-skill", prompt="pws")
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t", skills=[proj_state_skill])],
        skills=[proj_wf_skill],
    )
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp/p1", workflows=[wf])

    app = App()
    app.register_project(proj)
    set_app(app)

    ids = [s["id"] for s in resolve_skills()]
    assert "proj-wf-skill" in ids
    assert "proj-state-skill" in ids


def test_resolve_skills_deduplicates_across_sources():
    shared = _skill("shared-skill", prompt="shared")

    app = App()
    app.register_skill(shared)
    app.register_role(Role(id="r1", name="R1", prompt="t", skills=[shared]))
    set_app(app)

    assert [s["id"] for s in resolve_skills()].count("shared-skill") == 1


# --- Skill handlers ------------------------------------------------------


def test_handle_activate_skill_single():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    ctx = _make_tool_context(_make_session_obj(sid=sid))
    inp = _make_input(skill_ids=["my-skill"])

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        return_value=("My Skill", "Prompt content"),
    ):
        result = asyncio.run(handle_activate_skill(inp, ctx))

    assert "My Skill" in _text(result.content[0])
    assert "Prompt content" in _text(result.content[0])

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == sid)
        ).scalars().all()
        assert len(rows) == 1
        assert rows[0].skill_id == "my-skill"


def test_handle_activate_skill_multiple():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    ctx = _make_tool_context(_make_session_obj(sid=sid))
    inp = _make_input(skill_ids=["skill-a", "skill-b"])

    def mock_prompt(skill_id):
        return {
            "skill-a": ("Alpha", "Alpha prompt"),
            "skill-b": ("Beta", "Beta prompt"),
        }[skill_id]

    with patch("hypergolic.tools.skills.get_skill_prompt_content", side_effect=mock_prompt):
        result = asyncio.run(handle_activate_skill(inp, ctx))

    text = _text(result.content[0])
    assert "Alpha" in text
    assert "Beta" in text
    assert "---" in text


def test_handle_activate_skill_already_active():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id=sid, skill_id="active-skill"))

    ctx = _make_tool_context(_make_session_obj(sid=sid))
    inp = _make_input(skill_ids=["active-skill"])

    result = asyncio.run(handle_activate_skill(inp, ctx))
    assert "already active" in _text(result.content[0])


def test_handle_activate_skill_not_found():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    ctx = _make_tool_context(_make_session_obj(sid=sid))
    inp = _make_input(skill_ids=["nonexistent"])

    with patch("hypergolic.tools.skills.get_skill_prompt_content", return_value=None):
        result = asyncio.run(handle_activate_skill(inp, ctx))

    assert "not found" in _text(result.content[0])


def test_handle_activate_skill_no_prompt():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    ctx = _make_tool_context(_make_session_obj(sid=sid))
    inp = _make_input(skill_ids=["no-prompt"])

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        return_value=("No Prompt Skill", None),
    ):
        result = asyncio.run(handle_activate_skill(inp, ctx))

    assert "prompt file not found" in _text(result.content[0])


def test_handle_deactivate_skill():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id=sid, skill_id="sk-to-remove"))

    ctx = _make_tool_context(_make_session_obj(sid=sid))
    inp = _make_input(skill_ids=["sk-to-remove"])

    result = asyncio.run(handle_deactivate_skill(inp, ctx))
    assert "Deactivated" in _text(result.content[0])
    assert "sk-to-remove" in _text(result.content[0])

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == sid)
        ).scalars().all()
        assert len(rows) == 0


# --- Tool builders -------------------------------------------------------


def test_resolve_session_skills_basic():
    app = App()
    app.register_skill(_skill("app-skill"))

    proj = Project(
        id="p1", name="P1", description="d", git_root="/tmp/p1",
        skills=[_skill("proj-skill")],
    )
    app.register_project(proj)

    role = Role(id="r1", name="R1", prompt="t", skills=[_skill("role-skill")])
    app.register_role(role)
    set_app(app)

    session = _make_session_obj(role="r1")

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "app-skill" in ids
    assert "proj-skill" in ids
    assert "role-skill" in ids


def test_resolve_session_skills_workflow_state():
    wf_skill = _skill("wf-skill")
    state_skill = _skill("state-skill")
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t", skills=[state_skill])],
        skills=[wf_skill],
    )

    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_workflow(wf)
    set_app(app)

    session = _make_session_obj()

    with patch(
        "hypergolic.workflows.resolver.get_session_workflow",
        return_value=("wf1", "s1"),
    ):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "wf-skill" in ids
    assert "state-skill" in ids


def test_resolve_session_skills_active_children():
    child = _skill("child-skill")
    parent = _skill("parent-skill", children=[child])

    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_skill(parent)
    set_app(app)

    session = _make_session_obj(active_skill_ids={"parent-skill"})

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "parent-skill" in ids
    assert "child-skill" in ids


def test_build_activate_skill_tool_present():
    _setup_app_with_skills()
    set_app(App())  # reset
    app = _setup_app_with_skills()

    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    session = _make_session_obj(sid=sid)

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        tool = _build_activate_skill_tool(app, session)

    assert tool is not None
    assert tool.id == "activate_skill"


def test_build_activate_skill_tool_none_when_all_active():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_skill(_skill("only-skill"))
    set_app(app)

    session = _make_session_obj(active_skill_ids={"only-skill"})

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        tool = _build_activate_skill_tool(app, session)

    assert tool is None


def test_build_deactivate_skill_tool_present():
    session = _make_session_obj(active_skill_ids={"active-skill"})
    tool = _build_deactivate_skill_tool(session)

    assert tool is not None
    assert tool.id == "deactivate_skill"


def test_build_deactivate_skill_tool_none():
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    session = _make_session_obj(sid=sid)

    assert _build_deactivate_skill_tool(session) is None


def test_build_tools_has_activate_skill():
    _setup_app_with_skills()

    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    session = _make_session_obj(sid=sid)

    with (
        patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None),
        patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None),
        patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()),
    ):
        tools = build_tools(session)

    assert "activate_skill" in {t.id for t in tools}


def test_build_tools_has_deactivate_skill():
    _setup_app_with_skills()

    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    session = _make_session_obj(sid=sid, active_skill_ids={"parent-skill"})

    with (
        patch("hypergolic.tools.tool_list.get_session_workflow", return_value=None),
        patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None),
        patch("hypergolic.tools.tool_list.get_enabled_servers", return_value=set()),
    ):
        tools = build_tools(session)

    assert "deactivate_skill" in {t.id for t in tools}


# --- Skill description helpers -------------------------------------------


def test_build_activate_skill_description():
    desc = build_activate_skill_description([{"id": "sk1", "name": "Sk1"}])
    assert isinstance(desc, str) and len(desc) > 0


def test_build_deactivate_skill_description():
    desc = build_deactivate_skill_description()
    assert isinstance(desc, str) and len(desc) > 0
