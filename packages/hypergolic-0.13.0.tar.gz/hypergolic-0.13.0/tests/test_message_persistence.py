"""Tests for hypergolic.messages.persistence (uncovered paths)."""

from typing import Any, cast

import pytest
from anthropic.types import Message, MessageParam, TextBlock, ToolUseBlock, Usage

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages.persistence import (
    _extract_tool_use_ids,
    _make_error_tool_results,
    _to_block_list,
    _try_parse_json_string,
    load_session_messages,
    parse_agent_message,
    persist_agent_message,
    persist_user_message,
    sanitize_tool_input,
    strip_excluded_fields,
)
from sqlalchemy import select
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# _try_parse_json_string
# ---------------------------------------------------------------------------


def test_try_parse_json_string_valid_array():
    result = _try_parse_json_string('[1, 2, 3]')
    assert result == [1, 2, 3]


def test_try_parse_json_string_valid_object():
    result = _try_parse_json_string('{"key": "value"}')
    assert result == {"key": "value"}


def test_try_parse_json_string_invalid_json():
    result = _try_parse_json_string('not json at all')
    assert result is None


def test_try_parse_json_string_json_with_trailing_garbage():
    """JSON with trailing garbage gets the closing bracket stripped."""
    result = _try_parse_json_string('[1, 2, 3] trailing garbage')
    assert result == [1, 2, 3]


def test_try_parse_json_string_object_with_trailing_garbage():
    result = _try_parse_json_string('{"a": 1} extra stuff')
    assert result == {"a": 1}


def test_try_parse_json_string_not_starting_with_bracket_or_brace():
    """Strings not starting with [ or { return None even if they look like JSON."""
    result = _try_parse_json_string('"plain string"')
    assert result is None


def test_try_parse_json_string_plain_number():
    result = _try_parse_json_string('42')
    assert result is None


# ---------------------------------------------------------------------------
# sanitize_tool_input
# ---------------------------------------------------------------------------


def test_sanitize_tool_input_string_parses_as_json_array():
    result = sanitize_tool_input({"paths": '["a.py", "b.py"]'})
    assert result == {"paths": ["a.py", "b.py"]}


def test_sanitize_tool_input_string_parses_as_json_object():
    result = sanitize_tool_input({"config": '{"key": "value"}'})
    assert result == {"config": {"key": "value"}}


def test_sanitize_tool_input_non_json_string_left_alone():
    result = sanitize_tool_input({"name": "plain string"})
    assert result == {"name": "plain string"}


def test_sanitize_tool_input_non_string_values_left_alone():
    result = sanitize_tool_input({"count": 42, "flag": True, "data": [1, 2, 3]})
    assert result == {"count": 42, "flag": True, "data": [1, 2, 3]}


def test_sanitize_tool_input_empty_string_left_alone():
    result = sanitize_tool_input({"key": ""})
    assert result == {"key": ""}


# ---------------------------------------------------------------------------
# strip_excluded_fields
# ---------------------------------------------------------------------------


def test_strip_excluded_fields_removes_parsed_output():
    content = [{"type": "text", "text": "hello", "parsed_output": {"foo": 1}}]
    result = strip_excluded_fields(content)
    assert result == [{"type": "text", "text": "hello"}]


def test_strip_excluded_fields_removes_caller():
    content = [{"type": "tool_use", "id": "t1", "caller": "agent"}]
    result = strip_excluded_fields(content)
    assert result == [{"type": "tool_use", "id": "t1"}]


def test_strip_excluded_fields_non_dict_items_pass_through():
    """Non-dict items in the content list are included unchanged."""
    block = object()
    result = strip_excluded_fields([block])
    assert result == [block]


def test_strip_excluded_fields_mixed_content():
    non_dict = object()
    content = [
        {"type": "text", "text": "hi", "parsed_output": "x"},
        non_dict,
        {"type": "tool_use", "caller": "me"},
    ]
    result = strip_excluded_fields(content)
    assert result[0] == {"type": "text", "text": "hi"}
    assert result[1] is non_dict
    assert result[2] == {"type": "tool_use"}


# ---------------------------------------------------------------------------
# persist_agent_message
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_persist_agent_message_creates_db_entry():
    make_project()
    session_id = make_session()

    message = Message(
        id="msg-test-1",
        content=[TextBlock(type="text", text="Hello from agent")],
        model="claude-opus-4-5",
        role="assistant",
        stop_reason="end_turn",
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=10, output_tokens=20),
    )

    await persist_agent_message(session_id=session_id, message=message)

    with get_db() as db:
        rows = db.execute(
            select(DBMessage).where(DBMessage.session_id == session_id)
        ).scalars().all()

    assert len(rows) == 1
    row = rows[0]
    assert row.id == "msg-test-1"
    assert row.role == "assistant"
    assert row.model == "claude-opus-4-5"
    assert row.stop_reason == "end_turn"
    assert row.usage is not None
    assert row.usage["input_tokens"] == 10
    assert row.usage["output_tokens"] == 20
    assert any(b.get("type") == "text" for b in row.content)


@pytest.mark.asyncio
async def test_persist_agent_message_with_tool_use_block():
    make_project()
    session_id = make_session()

    message = Message(
        id="msg-test-2",
        content=[
            ToolUseBlock(type="tool_use", id="tu-1", name="read_files", input={"paths": ["a.py"]})
        ],
        model="claude-opus-4-5",
        role="assistant",
        stop_reason="tool_use",
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=5, output_tokens=15),
    )

    await persist_agent_message(session_id=session_id, message=message)

    with get_db() as db:
        rows = db.execute(
            select(DBMessage).where(DBMessage.session_id == session_id)
        ).scalars().all()

    assert len(rows) == 1
    row = rows[0]
    assert any(b.get("type") == "tool_use" for b in row.content)


# ---------------------------------------------------------------------------
# persist_user_message
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_persist_user_message_string_content():
    make_project()
    session_id = make_session()

    message = cast(MessageParam, {"role": "user", "content": "Hello from user"})

    await persist_user_message(session_id=session_id, message=message)

    with get_db() as db:
        rows = db.execute(
            select(DBMessage).where(DBMessage.session_id == session_id)
        ).scalars().all()

    assert len(rows) == 1
    row = rows[0]
    assert row.role == "user"
    assert row.content == [{"type": "text", "text": "Hello from user"}]


@pytest.mark.asyncio
async def test_persist_user_message_list_content():
    make_project()
    session_id = make_session()

    message = cast(
        MessageParam,
        {
            "role": "user",
            "content": [{"type": "text", "text": "block content"}],
        },
    )

    await persist_user_message(session_id=session_id, message=message)

    with get_db() as db:
        rows = db.execute(
            select(DBMessage).where(DBMessage.session_id == session_id)
        ).scalars().all()

    assert len(rows) == 1
    row = rows[0]
    assert row.content == [{"type": "text", "text": "block content"}]


@pytest.mark.asyncio
async def test_persist_user_message_basemodel_blocks():
    """BaseModel blocks are converted via model_dump."""
    from pydantic import BaseModel as PydanticBaseModel

    class FakeBlock(PydanticBaseModel):
        type: str = "text"
        text: str

    make_project()
    session_id = make_session()

    block = FakeBlock(text="pydantic block")
    message = cast(MessageParam, {"role": "user", "content": [block]})

    await persist_user_message(session_id=session_id, message=message)

    with get_db() as db:
        rows = db.execute(
            select(DBMessage).where(DBMessage.session_id == session_id)
        ).scalars().all()

    assert len(rows) == 1
    row = rows[0]
    assert row.content == [{"type": "text", "text": "pydantic block"}]


# ---------------------------------------------------------------------------
# parse_agent_message
# ---------------------------------------------------------------------------


def test_parse_agent_message_text_block():
    message = Message(
        id="msg-parse-1",
        content=[TextBlock(type="text", text="parsed text")],
        model="claude-sonnet-4-20250514",
        role="assistant",
        stop_reason="end_turn",
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=5, output_tokens=10),
    )

    result = parse_agent_message(message)
    assert result["role"] == "assistant"
    blocks = cast(list[dict[str, Any]], result["content"])
    assert any(b.get("type") == "text" and b.get("text") == "parsed text" for b in blocks)


def test_parse_agent_message_tool_use_block():
    message = Message(
        id="msg-parse-2",
        content=[
            ToolUseBlock(type="tool_use", id="tu-x", name="read_files", input={"paths": ["x.py"]})
        ],
        model="claude-sonnet-4-20250514",
        role="assistant",
        stop_reason="tool_use",
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=5, output_tokens=10),
    )

    result = parse_agent_message(message)
    assert result["role"] == "assistant"
    blocks = cast(list[dict[str, Any]], result["content"])
    assert any(b.get("type") == "tool_use" for b in blocks)
