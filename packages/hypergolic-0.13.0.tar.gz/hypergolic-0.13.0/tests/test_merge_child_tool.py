"""Tests for hypergolic.base.tools.merge_child — parent-side branch merge tool."""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any, cast
from unittest.mock import AsyncMock

import pytest

pytestmark = pytest.mark.timeout(10)

from hypergolic.base.tools.merge_child import (  # noqa: E402
    build_merge_child_tool,
    find_merge_candidates,
)
from hypergolic.db.engine import get_db  # noqa: E402
from hypergolic.db.models import DBProject, DBSession  # noqa: E402
from hypergolic.enums import ModelTier, SessionStatus  # noqa: E402
from hypergolic.git.worktree import create_worktree  # noqa: E402
from hypergolic.schemas import Session  # noqa: E402
from hypergolic.toolkit.primitives import ToolContext  # noqa: E402


def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-b", "main", str(path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(path), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(path), "config", "user.name", "t"], check=True)
    (path / "README.md").write_text("readme\n")
    subprocess.run(["git", "-C", str(path), "add", "-A"], check=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True, capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    project = tmp_path / "project"
    project.mkdir()
    _init_repo(project)
    return project


@pytest.fixture
def worktrees_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home / ".hypergolic" / "worktrees"


def _seed_parent_and_child(*, parent_id: str, child_id: str, project_path: Path, branch: str) -> None:
    with get_db() as db:
        if not db.get(DBProject, "proj-mc"):
            db.add(DBProject(id="proj-mc", name="P", path=str(project_path)))
        db.add(DBSession(
            id=parent_id, model_tier="Medium", system_prompt=[], project_id="proj-mc",
        ))
        db.add(DBSession(
            id=child_id, model_tier="Medium", system_prompt=[], project_id="proj-mc",
            parent_id=parent_id, status=SessionStatus.CONCLUDED,
            worktree_branch=branch, base_branch="main",
        ))


def _make_parent_session(parent_id: str, project_path: Path) -> Session:
    return Session(
        id=parent_id,
        model_tier=ModelTier.MEDIUM,
        project_id="proj-mc",
        project_path=str(project_path),
    )


def test_find_merge_candidates_empty_when_no_children(repo: Path, worktrees_home: Path) -> None:
    with get_db() as db:
        db.add(DBProject(id="proj-mc", name="P", path=str(repo)))
        db.add(DBSession(
            id="parent-1", model_tier="Medium", system_prompt=[], project_id="proj-mc",
        ))
    assert find_merge_candidates("parent-1") == []


def test_find_merge_candidates_returns_concluded_with_branch(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="child-a", project_path=repo)
    _seed_parent_and_child(
        parent_id="parent-a", child_id="child-a",
        project_path=repo, branch=info.branch,
    )
    candidates = find_merge_candidates("parent-a")
    assert len(candidates) == 1
    assert candidates[0].session_id == "child-a"
    assert candidates[0].worktree_branch == info.branch


def test_build_merge_child_tool_none_when_no_candidates(
    repo: Path, worktrees_home: Path,
) -> None:
    with get_db() as db:
        db.add(DBProject(id="proj-mc", name="P", path=str(repo)))
        db.add(DBSession(
            id="parent-empty", model_tier="Medium", system_prompt=[], project_id="proj-mc",
        ))
    session = _make_parent_session("parent-empty", repo)
    assert build_merge_child_tool(session) is None


@pytest.mark.anyio
async def test_merge_tool_merge_strategy_applies_commit(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="child-m", project_path=repo)
    # Commit in the worktree.
    (info.worktree_path / "new.txt").write_text("hi")
    subprocess.run(
        ["git", "-C", str(info.worktree_path), "add", "new.txt"], check=True,
    )
    subprocess.run(
        ["git", "-C", str(info.worktree_path), "commit", "-m", "child work"],
        check=True, capture_output=True,
    )
    # At conclude time the worktree directory is removed; simulate that so
    # the branch isn't locked to a live checkout.
    subprocess.run(
        ["git", "-C", str(repo), "worktree", "remove", "--force", str(info.worktree_path)],
        check=True, capture_output=True,
    )

    _seed_parent_and_child(
        parent_id="parent-m", child_id="child-m",
        project_path=repo, branch=info.branch,
    )
    session = _make_parent_session("parent-m", repo)
    tool = build_merge_child_tool(session)
    assert tool is not None

    # Build the input via the tool's input_schema enum.
    input_cls = cast(Any, tool.input_schema)
    assert input_cls is not None
    inp = input_cls(child_session_id="child-m", strategy="merge")

    ctx = ToolContext(session=session, broadcast=AsyncMock(), tool_id="merge_child")
    result = await tool.run(inp, ctx)
    assert result.outcome == "SUCCESS"
    assert (repo / "new.txt").exists()
    # Branch should be gone after a successful merge.
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert info.branch not in branches


@pytest.mark.anyio
async def test_merge_tool_discard_strategy_drops_branch(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="child-d", project_path=repo)
    (info.worktree_path / "new.txt").write_text("hi")
    subprocess.run(
        ["git", "-C", str(info.worktree_path), "add", "new.txt"], check=True,
    )
    subprocess.run(
        ["git", "-C", str(info.worktree_path), "commit", "-m", "child"],
        check=True, capture_output=True,
    )

    # Remove the worktree directory so branch deletion is legal.
    subprocess.run(
        ["git", "-C", str(repo), "worktree", "remove", "--force", str(info.worktree_path)],
        check=True, capture_output=True,
    )

    _seed_parent_and_child(
        parent_id="parent-d", child_id="child-d",
        project_path=repo, branch=info.branch,
    )
    session = _make_parent_session("parent-d", repo)
    tool = build_merge_child_tool(session)
    assert tool is not None
    input_cls = cast(Any, tool.input_schema)
    assert input_cls is not None
    inp = input_cls(child_session_id="child-d", strategy="discard")

    ctx = ToolContext(session=session, broadcast=AsyncMock(), tool_id="merge_child")
    result = await tool.run(inp, ctx)
    assert result.outcome == "SUCCESS"
    # File should NOT be in the parent's tree.
    assert not (repo / "new.txt").exists()
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert info.branch not in branches
