"""Tests for hypergolic.toolkit.app.onboarding."""

from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest

from hypergolic.toolkit.app.onboarding import (
    PROMPTS_DIR,
    get_builtin_toolkit_project,
    toolkit_prompt_fn,
)
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.project import Project


# ---------------------------------------------------------------------------
# toolkit_prompt_fn
# ---------------------------------------------------------------------------


def test_toolkit_prompt_fn_no_user_projects_uses_onboarding(tmp_path):
    """When no user projects (only 'toolkit'), uses onboarding.md."""
    onboarding = tmp_path / "onboarding.md"
    onboarding.write_text("Welcome to onboarding!")

    app = App()
    # Only the toolkit project itself
    toolkit_proj = Project(
        id="toolkit", name="Toolkit", description="d", git_root=str(tmp_path)
    )
    app.register_project(toolkit_proj)

    with patch("hypergolic.toolkit.app.onboarding.PROMPTS_DIR", tmp_path):
        result = toolkit_prompt_fn(app)

    assert result == "Welcome to onboarding!"


def test_toolkit_prompt_fn_with_user_projects_uses_toolkit_md(tmp_path):
    """When user projects exist, uses toolkit.md."""
    toolkit_md = tmp_path / "toolkit.md"
    toolkit_md.write_text("Toolkit prompt content.")

    app = App()
    # Has a real user project
    user_proj = Project(
        id="my-project", name="My Project", description="d", git_root=str(tmp_path)
    )
    app.register_project(user_proj)

    with patch("hypergolic.toolkit.app.onboarding.PROMPTS_DIR", tmp_path):
        result = toolkit_prompt_fn(app)

    assert result == "Toolkit prompt content."


def test_toolkit_prompt_fn_file_not_found_returns_empty(tmp_path):
    """When the prompt file doesn't exist, returns empty string."""
    app = App()  # No projects -> would use onboarding.md, but it doesn't exist

    with patch("hypergolic.toolkit.app.onboarding.PROMPTS_DIR", tmp_path):
        result = toolkit_prompt_fn(app)

    assert result == ""


def test_toolkit_prompt_fn_ignores_toolkit_project_for_user_check(tmp_path):
    """The 'toolkit' project itself is NOT counted as a user project."""
    onboarding = tmp_path / "onboarding.md"
    onboarding.write_text("onboarding")

    app = App()
    # Only toolkit project
    toolkit_proj = Project(
        id="toolkit", name="Toolkit", description="d", git_root=str(tmp_path)
    )
    app.register_project(toolkit_proj)

    with patch("hypergolic.toolkit.app.onboarding.PROMPTS_DIR", tmp_path):
        result = toolkit_prompt_fn(app)

    # Should use onboarding.md, not toolkit.md
    assert result == "onboarding"


# ---------------------------------------------------------------------------
# get_builtin_toolkit_project
# ---------------------------------------------------------------------------


def test_get_builtin_toolkit_project_returns_project():
    proj = get_builtin_toolkit_project()
    assert isinstance(proj, Project)
    assert proj.id == "toolkit"
    assert proj.name == "My Toolkit"
    assert ".hypergolic" in proj.git_root


def test_get_builtin_toolkit_project_has_prompt_fn():
    proj = get_builtin_toolkit_project()
    assert proj.prompt_fn is not None
    assert callable(proj.prompt_fn)


def test_get_builtin_toolkit_project_prompt_fn_is_toolkit_prompt_fn():
    from hypergolic.toolkit.app.onboarding import toolkit_prompt_fn
    proj = get_builtin_toolkit_project()
    assert proj.prompt_fn is toolkit_prompt_fn


def test_get_builtin_toolkit_project_description_mentions_toolkit():
    proj = get_builtin_toolkit_project()
    assert "toolkit" in proj.description.lower() or "configuration" in proj.description.lower()


def test_toolkit_prompt_fn_both_user_and_toolkit_projects(tmp_path):
    """When both toolkit and user projects exist, still uses toolkit.md."""
    toolkit_md = tmp_path / "toolkit.md"
    toolkit_md.write_text("For users")

    app = App()
    app.register_project(Project(
        id="toolkit", name="Toolkit", description="d", git_root=str(tmp_path)
    ))
    app.register_project(Project(
        id="user-proj", name="User Proj", description="d", git_root=str(tmp_path)
    ))

    with patch("hypergolic.toolkit.app.onboarding.PROMPTS_DIR", tmp_path):
        result = toolkit_prompt_fn(app)

    assert result == "For users"
