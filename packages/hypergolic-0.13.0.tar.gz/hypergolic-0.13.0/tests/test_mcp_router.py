from types import SimpleNamespace
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.mcptools.sessions import enabled_servers_by_session
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _mock_config(transport: str = "stdio", auth_type: str = "none") -> SimpleNamespace:
    return SimpleNamespace(transport=transport, auth=SimpleNamespace(type=auth_type))


def _mock_tool(name: str, description: str = "", schema: dict | None = None) -> SimpleNamespace:
    return SimpleNamespace(
        name=name,
        description=description,
        inputSchema=schema or {"type": "object"},
    )


def _mock_server(
    name: str,
    source: str = "user",
    tools: list | None = None,
) -> SimpleNamespace:
    return SimpleNamespace(name=name, source=source, tools=tools or [])


def _make_manager(**overrides) -> MagicMock:
    mgr = MagicMock()
    mgr.get_available_servers = MagicMock(return_value=overrides.get("available", {}))
    mgr.get_connected_server = MagicMock(return_value=overrides.get("connected", None))
    mgr.get_auth_status = MagicMock(return_value=overrides.get("auth_status", "not_required"))
    mgr.connect = AsyncMock(return_value=overrides.get("connect_result", None))
    mgr.disconnect = AsyncMock()
    mgr.is_connected = MagicMock(return_value=overrides.get("is_connected", False))
    return mgr


# ---------------------------------------------------------------------------
# Tests — GET /api/mcp/servers
# ---------------------------------------------------------------------------

def test_list_servers_empty(api_client):
    mgr = _make_manager(available={})
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.get("/api/mcp/servers")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_servers_with_entries(api_client):
    config = _mock_config(transport="stdio", auth_type="none")
    available = {"my-server": (config, "user")}
    server_obj = _mock_server("my-server", tools=[_mock_tool("greet")])
    mgr = _make_manager(available=available, connected=server_obj, auth_status="not_required")
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.get("/api/mcp/servers")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    assert data[0]["name"] == "my-server"
    assert data[0]["source"] == "user"
    assert data[0]["connected"] is True
    assert data[0]["tool_count"] == 1
    assert data[0]["transport"] == "stdio"
    assert data[0]["auth_type"] == "none"
    assert data[0]["auth_status"] == "not_required"


# ---------------------------------------------------------------------------
# Tests — POST /api/mcp/servers/{name}/connect
# ---------------------------------------------------------------------------

def test_connect_server_success(api_client):
    enabled_servers_by_session.clear()
    config = _mock_config()
    server_obj = _mock_server("srv", tools=[_mock_tool("t1")])
    available = {"srv": (config, "user")}
    mgr = _make_manager(available=available, connect_result=server_obj)
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/srv/connect",
            json={"session_id": "sess-1"},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "srv"
    assert data["connected"] is True
    assert data["tool_count"] == 1
    # Session should now have this server enabled
    assert "srv" in enabled_servers_by_session.get("sess-1", set())


def test_connect_server_not_found(api_client):
    mgr = _make_manager()
    mgr.connect = AsyncMock(side_effect=ValueError("MCP server 'nope' not found"))
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/nope/connect",
            json={"session_id": "sess-1"},
        )
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"]


def test_connect_server_error(api_client):
    mgr = _make_manager()
    mgr.connect = AsyncMock(side_effect=RuntimeError("connection refused"))
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/broken/connect",
            json={"session_id": "sess-1"},
        )
    assert resp.status_code == 502
    assert "connection refused" in resp.json()["detail"]


def test_connect_server_exception_group_nested(api_client):
    """ExceptionGroup with a nested ExceptionGroup extracts the inner error."""
    inner = OSError("socket closed")
    nested = ExceptionGroup("inner group", [inner])
    exc_group = ExceptionGroup("connect errors", [nested])
    mgr = _make_manager()
    mgr.connect = AsyncMock(side_effect=exc_group)
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/broken/connect",
            json={"session_id": "sess-1"},
        )
    assert resp.status_code == 502
    assert "socket closed" in resp.json()["detail"]


def test_connect_server_exception_group_simple(api_client):
    """ExceptionGroup with only simple exceptions falls back to first exception."""
    inner = OSError("plain error")
    exc_group = ExceptionGroup("connect errors", [inner])
    mgr = _make_manager()
    mgr.connect = AsyncMock(side_effect=exc_group)
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/broken/connect",
            json={"session_id": "sess-1"},
        )
    assert resp.status_code == 502
    assert "plain error" in resp.json()["detail"]


def test_connect_with_project_id(api_client):
    enabled_servers_by_session.clear()
    proj = make_project(pid="proj-mcp", name="MCPProj", path="/tmp/mcptest")
    config = _mock_config()
    server_obj = _mock_server("proj-srv", source="project", tools=[])
    available = {"proj-srv": (config, "project")}
    mgr = _make_manager(available=available, connect_result=server_obj)
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/proj-srv/connect?project_id=proj-mcp",
            json={"session_id": "sess-2"},
        )
    assert resp.status_code == 200
    assert resp.json()["source"] == "project"
    # Manager should have been called with the resolved project path
    mgr.connect.assert_awaited_once_with("proj-srv", "/tmp/mcptest")


# ---------------------------------------------------------------------------
# Tests — POST /api/mcp/servers/{name}/disconnect
# ---------------------------------------------------------------------------

def test_disconnect_server(api_client):
    enabled_servers_by_session.clear()
    enabled_servers_by_session["sess-d"] = {"disc-srv"}
    config = _mock_config()
    available = {"disc-srv": (config, "user")}
    mgr = _make_manager(available=available, is_connected=False, auth_status="not_required")
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/disc-srv/disconnect",
            json={"session_id": "sess-d"},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "disc-srv"
    assert data["connected"] is False
    # Session should no longer have this server
    assert "disc-srv" not in enabled_servers_by_session.get("sess-d", set())
    # Since no other session uses it, disconnect should have been called
    mgr.disconnect.assert_awaited_once_with("disc-srv")


def test_disconnect_server_still_needed(api_client):
    """If another session still uses the server, manager.disconnect is NOT called."""
    enabled_servers_by_session.clear()
    enabled_servers_by_session["sess-a"] = {"shared-srv"}
    enabled_servers_by_session["sess-b"] = {"shared-srv"}
    config = _mock_config()
    available = {"shared-srv": (config, "user")}
    mgr = _make_manager(available=available, is_connected=True, auth_status="not_required")
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/shared-srv/disconnect",
            json={"session_id": "sess-a"},
        )
    assert resp.status_code == 200
    # Server still connected because sess-b needs it
    mgr.disconnect.assert_not_awaited()


# ---------------------------------------------------------------------------
# Tests — GET /api/mcp/servers/{name}/tools
# ---------------------------------------------------------------------------

def test_list_server_tools_connected(api_client):
    tools = [
        _mock_tool("tool-a", "Does A", {"type": "object", "properties": {}}),
        _mock_tool("tool-b", "Does B"),
    ]
    server_obj = _mock_server("tooled", tools=tools)
    mgr = _make_manager(connected=server_obj)
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.get("/api/mcp/servers/tooled/tools")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    assert data[0]["server_name"] == "tooled"
    assert data[0]["tool_name"] == "tool-a"
    assert data[0]["description"] == "Does A"
    assert data[0]["input_schema"] == {"type": "object", "properties": {}}
    assert data[1]["tool_name"] == "tool-b"


def test_list_server_tools_not_connected(api_client):
    mgr = _make_manager(connected=None)
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.get("/api/mcp/servers/offline/tools")
    assert resp.status_code == 200
    assert resp.json() == []


# ---------------------------------------------------------------------------
# Tests — GET /api/mcp/sessions/{session_id}/enabled
# ---------------------------------------------------------------------------

def test_get_session_enabled_servers(api_client):
    enabled_servers_by_session.clear()
    enabled_servers_by_session["sess-x"] = {"alpha", "beta"}
    resp = api_client.get("/api/mcp/sessions/sess-x/enabled")
    assert resp.status_code == 200
    data = resp.json()
    assert set(data) == {"alpha", "beta"}


def test_get_session_enabled_servers_empty(api_client):
    enabled_servers_by_session.clear()
    resp = api_client.get("/api/mcp/sessions/sess-none/enabled")
    assert resp.status_code == 200
    assert resp.json() == []


# ---------------------------------------------------------------------------
# Tests — _resolve_project_path
# ---------------------------------------------------------------------------

def test_list_servers_with_bad_project_id(api_client):
    """project_id that doesn't exist in DB → 404."""
    mgr = _make_manager()
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.get("/api/mcp/servers?project_id=nonexistent")
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


def test_disconnect_unknown_server(api_client):
    """Disconnect a server not in available config — uses defaults."""
    enabled_servers_by_session.clear()
    mgr = _make_manager(available={}, is_connected=False, auth_status="not_required")
    with patch("hypergolic.mcptools.router.get_mcp_manager", return_value=mgr):
        resp = api_client.post(
            "/api/mcp/servers/unknown/disconnect",
            json={"session_id": "sess-u"},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "unknown"
    assert data["source"] == "user"  # fallback
    assert data["transport"] == "stdio"  # fallback
