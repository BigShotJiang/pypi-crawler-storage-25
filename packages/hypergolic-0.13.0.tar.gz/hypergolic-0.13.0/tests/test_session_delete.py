from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import (
    DBError, DBMessage, DBProject, DBSession,
    DBSessionSkill,
)


def _seed(project_id="proj-1"):
    with get_db() as db:
        db.add(DBProject(id=project_id, name="Test", path="/tmp/test"))


def _add_session(sid, project_id="proj-1", parent_id=None):
    with get_db() as db:
        db.add(DBSession(
            id=sid, model_tier="Medium", system_prompt=[],
            project_id=project_id, parent_id=parent_id,
        ))


def _add_child_data(sid):
    with get_db() as db:
        db.add(DBMessage(content=[], session_id=sid, role="user"))
        db.add(DBSessionSkill(session_id=sid, skill_id="test-skill"))
        db.add(DBError(session_id=sid, error_type="test", message="err"))


def _session_exists(sid):
    with get_db() as db:
        return db.execute(
            select(DBSession).where(DBSession.id == sid)
        ).scalar_one_or_none() is not None


def test_delete_session_simple(api_client):
    _seed()
    _add_session("s1")
    _add_child_data("s1")
    resp = api_client.delete("/api/sessions/s1")
    assert resp.status_code == 200
    assert not _session_exists("s1")


def test_delete_session_with_child(api_client):
    _seed()
    _add_session("parent")
    _add_session("child", parent_id="parent")
    _add_child_data("parent")
    _add_child_data("child")
    resp = api_client.delete("/api/sessions/parent")
    assert resp.status_code == 200
    assert not _session_exists("parent")
    assert not _session_exists("child")


def test_delete_session_with_grandchildren(api_client):
    _seed()
    _add_session("root")
    _add_session("mid", parent_id="root")
    _add_session("leaf", parent_id="mid")
    resp = api_client.delete("/api/sessions/root")
    assert resp.status_code == 200
    assert not _session_exists("root")
    assert not _session_exists("mid")
    assert not _session_exists("leaf")


def test_delete_session_nonexistent(api_client):
    resp = api_client.delete("/api/sessions/does-not-exist")
    assert resp.status_code == 200


def test_delete_child_preserves_parent(api_client):
    _seed()
    _add_session("parent")
    _add_session("child", parent_id="parent")
    resp = api_client.delete("/api/sessions/child")
    assert resp.status_code == 200
    assert _session_exists("parent")
    assert not _session_exists("child")
