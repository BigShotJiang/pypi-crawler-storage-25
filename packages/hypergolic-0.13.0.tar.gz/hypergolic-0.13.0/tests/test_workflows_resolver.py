"""Tests for hypergolic.workflows.resolver."""

from unittest.mock import patch

import pytest

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionWorkflow
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.primitives import Workflow
from hypergolic.toolkit.project import Project
from hypergolic.workflows.resolver import (
    get_session_workflow,
    get_workflow,
    resolve_workflows,
)
from tests._factories import build_workflow
from tests.conftest import make_project, make_session


def _make_workflow(wid: str = "wf-1") -> Workflow:
    return build_workflow(wid, state_id="s1")


# ---------------------------------------------------------------------------
# resolve_workflows
# ---------------------------------------------------------------------------


def test_resolve_workflows_empty():
    app = App()
    set_app(app)
    workflows = resolve_workflows()
    assert workflows == []


def test_resolve_workflows_app_level():
    app = App()
    app.register_workflow(_make_workflow("wf-1"))
    app.register_workflow(_make_workflow("wf-2"))
    set_app(app)

    workflows = resolve_workflows()
    ids = [w.id for w in workflows]
    assert "wf-1" in ids
    assert "wf-2" in ids


def test_resolve_workflows_project_level():
    app = App()
    proj = Project(
        id="p1",
        name="P1",
        description="d",
        git_root="/tmp/p1",
        workflows=[_make_workflow("proj-wf")],
    )
    app.register_project(proj)
    set_app(app)

    workflows = resolve_workflows()
    ids = [w.id for w in workflows]
    assert "proj-wf" in ids


def test_resolve_workflows_deduplicates():
    """Same workflow ID registered at app and project level — appears only once."""
    app = App()
    app.register_workflow(_make_workflow("shared-wf"))
    proj = Project(
        id="p1",
        name="P1",
        description="d",
        git_root="/tmp/p1",
        workflows=[_make_workflow("shared-wf")],
    )
    app.register_project(proj)
    set_app(app)

    workflows = resolve_workflows()
    ids = [w.id for w in workflows]
    assert ids.count("shared-wf") == 1


def test_resolve_workflows_mixed_sources():
    app = App()
    app.register_workflow(_make_workflow("app-wf"))
    proj = Project(
        id="p1",
        name="P1",
        description="d",
        git_root="/tmp/p1",
        workflows=[_make_workflow("proj-wf")],
    )
    app.register_project(proj)
    set_app(app)

    workflows = resolve_workflows()
    ids = [w.id for w in workflows]
    assert "app-wf" in ids
    assert "proj-wf" in ids


# ---------------------------------------------------------------------------
# get_workflow
# ---------------------------------------------------------------------------


def test_get_workflow_found():
    app = App()
    wf = _make_workflow("target-wf")
    app.register_workflow(wf)
    set_app(app)

    result = get_workflow("target-wf")
    assert result is not None
    assert result.id == "target-wf"


def test_get_workflow_not_found():
    app = App()
    set_app(app)
    result = get_workflow("nonexistent")
    assert result is None


def test_get_workflow_from_project():
    app = App()
    proj = Project(
        id="p1",
        name="P1",
        description="d",
        git_root="/tmp/p1",
        workflows=[_make_workflow("proj-only-wf")],
    )
    app.register_project(proj)
    set_app(app)

    result = get_workflow("proj-only-wf")
    assert result is not None
    assert result.id == "proj-only-wf"


# ---------------------------------------------------------------------------
# get_session_workflow
# ---------------------------------------------------------------------------


def test_get_session_workflow_none_when_no_row():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    result = get_session_workflow("s-1")
    assert result is None


def test_get_session_workflow_returns_tuple():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-test",
            current_state_id="state-a",
        ))

    result = get_session_workflow("s-1")
    assert result is not None
    workflow_id, current_state_id = result
    assert workflow_id == "wf-test"
    assert current_state_id == "state-a"


def test_get_session_workflow_ignores_deleted():
    """Rows with deleted_at set are not returned."""
    from datetime import datetime, timezone
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-deleted",
            current_state_id="st-x",
            deleted_at=datetime.now(timezone.utc),
        ))

    result = get_session_workflow("s-1")
    assert result is None


def test_get_session_workflow_returns_active_over_deleted():
    """When one row is deleted and another is active, only active is returned."""
    from datetime import datetime, timezone
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-old",
            current_state_id="st-old",
            deleted_at=datetime.now(timezone.utc),
        ))
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-active",
            current_state_id="st-new",
        ))

    result = get_session_workflow("s-1")
    assert result is not None
    assert result[0] == "wf-active"
