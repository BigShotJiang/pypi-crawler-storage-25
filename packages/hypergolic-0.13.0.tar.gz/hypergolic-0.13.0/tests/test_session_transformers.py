"""Tests for hypergolic.sessions.transformers — pure helpers extracted from the router."""

from datetime import datetime, timezone
from types import SimpleNamespace

from hypergolic.enums import ModelTier, SessionStatus
from hypergolic.toolkit.primitives import InputSchema, Tool as ToolkitTool, ToolApprovalDecision
from hypergolic.sessions.transformers import (
    build_skill_infos,
    build_tool_info,
    check_requires_approval,
    session_response,
)


def _make_db_session(**overrides):
    now = datetime(2025, 1, 1, tzinfo=timezone.utc)
    defaults = dict(
        id="sess-1",
        model_tier=ModelTier.MEDIUM,
        project_id="proj-1",
        role="generalist",
        status=SessionStatus.IDLE,
        created_at=now,
        updated_at=now,
        parent_id=None,
        description=None,
        conclusion_rating=None,
        conclusion_feedback=None,
        concluded_at=None,
        worktree_path=None,
        worktree_branch=None,
        base_branch=None,
        worktree_seed_status=None,
    )
    defaults.update(overrides)
    return SimpleNamespace(**defaults)


def _make_internal_tool(**overrides):
    """Build a minimal Tool-like object for build_tool_info."""
    defaults = dict(
        id="my_tool",
        name="My Tool",
        description="Does stuff",
        requires_approval=False,
    )
    defaults.update(overrides)
    ns = SimpleNamespace(**defaults)
    ns.to_param = lambda: {"input_schema": {"type": "object", "properties": {}}}
    return ns


async def _noop_run(ctx):
    return "ok"


async def _noop_run_with_input(inp, ctx):
    return "ok"


def _toolkit_tool(
    *,
    id: str = "t",
    name: str = "T",
    description: str = "d",
    run=_noop_run,
    approval="ALLOW",
    input_schema=None,
) -> ToolkitTool:
    return ToolkitTool(
        id=id, name=name, description=description,
        run=run, approval=approval, input_schema=input_schema,
    )


# --- session_response ---


def test_session_response_basic():
    row = _make_db_session()
    resp = session_response(row, "My Project")
    assert resp.id == "sess-1"
    assert resp.project_name == "My Project"
    assert resp.model_tier == ModelTier.MEDIUM
    assert resp.role == "generalist"
    assert resp.status == SessionStatus.IDLE
    assert resp.message_count == 0
    assert resp.workflow_id is None
    assert resp.workflow_name is None
    assert resp.parent_id is None
    assert resp.concluded_at is None


def test_session_response_with_workflow():
    row = _make_db_session()
    resp = session_response(
        row, "P",
        message_count=5,
        workflow_id="wf-1",
        workflow_state_id="state-a",
        workflow_name="My Workflow",
        workflow_state_name="Draft",
    )
    assert resp.message_count == 5
    assert resp.workflow_id == "wf-1"
    assert resp.workflow_state_id == "state-a"
    assert resp.workflow_name == "My Workflow"
    assert resp.workflow_state_name == "Draft"


def test_session_response_with_conclusion():
    concluded = datetime(2025, 6, 15, 12, 0, tzinfo=timezone.utc)
    row = _make_db_session(
        description="test desc",
        conclusion_rating=4,
        conclusion_feedback="good",
        concluded_at=concluded,
    )
    resp = session_response(row, "P")
    assert resp.description == "test desc"
    assert resp.conclusion_rating == 4
    assert resp.conclusion_feedback == "good"
    assert resp.concluded_at is not None


# --- check_requires_approval ---


def test_check_requires_approval_both_none():
    """No toolkit tool, no internal tool → deny-by-default."""
    assert check_requires_approval(None) is True


def test_check_requires_approval_internal_tool_no_approval():
    """No toolkit tool, internal tool with requires_approval=False → allow."""
    internal = _make_internal_tool(requires_approval=False)
    assert check_requires_approval(None, internal) is False


def test_check_requires_approval_internal_tool_requires():
    """No toolkit tool, internal tool with requires_approval=True → require."""
    internal = _make_internal_tool(requires_approval=True)
    assert check_requires_approval(None, internal) is True


def test_check_requires_approval_allow_string():
    tool = _toolkit_tool(approval="ALLOW")
    assert check_requires_approval(tool) is False


def test_check_requires_approval_deny_string():
    tool = _toolkit_tool(approval="DENY")
    assert check_requires_approval(tool) is True


def test_check_requires_approval_require_string():
    tool = _toolkit_tool(approval="REQUIRE_APPROVAL")
    assert check_requires_approval(tool) is True


def test_check_requires_approval_callable_always_conservative():
    """Any callable approval is reported as True (conservative, context-dependent)."""
    tool = _toolkit_tool(
        approval=lambda ctx: ToolApprovalDecision(decision="ALLOW"),
    )
    assert check_requires_approval(tool) is True


def test_check_requires_approval_callable_with_schema_conservative():
    """Callable approval with input_schema is also conservative."""
    class MyInput(InputSchema):
        x: int

    tool = _toolkit_tool(
        run=_noop_run_with_input,
        input_schema=MyInput,
        approval=lambda ctx: ToolApprovalDecision(decision="ALLOW"),
    )
    assert check_requires_approval(tool) is True


# --- build_tool_info ---


def test_build_tool_info_basic():
    tool = _make_internal_tool()
    info = build_tool_info(tool, "base", None)
    assert info.id == "my_tool"
    assert info.name == "My Tool"
    assert info.description == "Does stuff"
    assert info.reason == "base"
    assert info.requires_approval is False
    assert info.mcp_server is None
    assert info.input_schema == {"type": "object", "properties": {}}


def test_build_tool_info_mcp_tool():
    tool = _make_internal_tool(id="mcp_myserver__do_thing")
    info = build_tool_info(tool, "mcp", None)
    assert info.mcp_server == "myserver"


def test_build_tool_info_with_toolkit_deny():
    tool = _make_internal_tool()
    toolkit = _toolkit_tool(id="my_tool", approval="DENY")
    info = build_tool_info(tool, "base", toolkit)
    assert info.requires_approval is True


def test_build_tool_info_schema_error():
    """When to_param() raises, schema should be None."""
    tool = _make_internal_tool()
    tool.to_param = lambda: (_ for _ in ()).throw(RuntimeError("bad"))
    info = build_tool_info(tool, "base", None)
    assert info.input_schema is None


def test_build_tool_info_schema_none():
    """When to_param() returns no input_schema, schema should be None."""
    tool = _make_internal_tool()
    tool.to_param = lambda: {}
    info = build_tool_info(tool, "base", None)
    assert info.input_schema is None


# --- build_skill_infos ---


def test_build_skill_infos_empty():
    assert build_skill_infos([], set()) == []


def test_build_skill_infos_marks_active():
    skills = [
        {"id": "s1", "name": "Skill 1", "description": "d1", "source": "base"},
        {"id": "s2", "name": "Skill 2", "description": "d2", "source": "user"},
    ]
    result = build_skill_infos(skills, {"s1"})
    assert len(result) == 2
    assert result[0].id == "s1"
    assert result[0].active is True
    assert result[1].id == "s2"
    assert result[1].active is False


def test_build_skill_infos_all_active():
    skills = [
        {"id": "a", "name": "A", "description": "", "source": "base"},
        {"id": "b", "name": "B", "description": "", "source": "base"},
    ]
    result = build_skill_infos(skills, {"a", "b"})
    assert all(s.active for s in result)


def test_build_skill_infos_none_active():
    skills = [
        {"id": "a", "name": "A", "description": "", "source": "base"},
    ]
    result = build_skill_infos(skills, set())
    assert result[0].active is False
