"""Tests for hypergolic.messages.content_blocks."""

import json
from unittest.mock import MagicMock

import pytest

from hypergolic.messages.content_blocks import (
    serialize_anthropic_content_block,
    serialize_content_blocks,
    serialize_image_block,
    serialize_text_block,
    serialize_tool_call_block,
    serialize_tool_result_block,
)


# ---------------------------------------------------------------------------
# serialize_text_block
# ---------------------------------------------------------------------------


def test_serialize_text_block_basic():
    result = serialize_text_block("hello world")
    assert result == {"type": "text", "text": "hello world"}


def test_serialize_text_block_empty():
    result = serialize_text_block("")
    assert result == {"type": "text", "text": ""}


# ---------------------------------------------------------------------------
# serialize_image_block
# ---------------------------------------------------------------------------


def test_serialize_image_block():
    result = serialize_image_block(media_type="image/png", data="base64data")
    assert result == {
        "type": "image",
        "source": {"type": "base64", "media_type": "image/png", "data": "base64data"},
    }


# ---------------------------------------------------------------------------
# serialize_tool_call_block
# ---------------------------------------------------------------------------


def test_serialize_tool_call_block_basic():
    result = serialize_tool_call_block(
        id="tu-1", name="read_files", input={"paths": ["a.py"]}
    )
    assert result == {
        "type": "tool_call",
        "id": "tu-1",
        "name": "read_files",
        "display_name": "read_files",
        "input": {"paths": ["a.py"]},
    }


def test_serialize_tool_call_block_with_display_name():
    result = serialize_tool_call_block(
        id="tu-2", name="read_files", input={}, display_name="Read Files"
    )
    assert result["display_name"] == "Read Files"


def test_serialize_tool_call_block_no_display_name_uses_name():
    result = serialize_tool_call_block(id="tu-3", name="my_tool", input={}, display_name=None)
    assert result["display_name"] == "my_tool"


# ---------------------------------------------------------------------------
# serialize_tool_result_block
# ---------------------------------------------------------------------------


def test_serialize_tool_result_block_basic():
    content = [{"type": "text", "text": "result text"}]
    result = serialize_tool_result_block(tool_use_id="tu-1", content=content)
    assert result == {
        "type": "tool_result",
        "tool_use_id": "tu-1",
        "content": content,
        "is_error": False,
    }


def test_serialize_tool_result_block_with_error():
    result = serialize_tool_result_block(tool_use_id="tu-2", content=[], is_error=True)
    assert result["is_error"] is True


# ---------------------------------------------------------------------------
# serialize_anthropic_content_block — text block
# ---------------------------------------------------------------------------


def test_serialize_anthropic_content_block_text_dict():
    block = {"type": "text", "text": "hello"}
    result = serialize_anthropic_content_block(block)
    assert result == {"type": "text", "text": "hello"}


def test_serialize_anthropic_content_block_text_with_model_dump():
    mock_block = MagicMock()
    mock_block.model_dump.return_value = {"type": "text", "text": "from model"}
    result = serialize_anthropic_content_block(mock_block)
    assert result == {"type": "text", "text": "from model"}
    mock_block.model_dump.assert_called_once_with(mode="json")


# ---------------------------------------------------------------------------
# serialize_anthropic_content_block — tool_use block
# ---------------------------------------------------------------------------


def test_serialize_anthropic_content_block_tool_use_dict_input():
    block = {
        "type": "tool_use",
        "id": "tu-1",
        "name": "read_files",
        "input": {"paths": ["x.py"]},
    }
    result = serialize_anthropic_content_block(block)
    assert result["type"] == "tool_call"
    assert result["id"] == "tu-1"
    assert result["name"] == "read_files"
    assert result["input"] == {"paths": ["x.py"]}
    assert result["display_name"] == "read_files"  # no mapping


def test_serialize_anthropic_content_block_tool_use_with_display_name_mapping():
    block = {
        "type": "tool_use",
        "id": "tu-2",
        "name": "write_files",
        "input": {},
    }
    result = serialize_anthropic_content_block(
        block, tool_display_names={"write_files": "Write Files"}
    )
    assert result["display_name"] == "Write Files"


def test_serialize_anthropic_content_block_tool_use_string_input_valid_json():
    block = {
        "type": "tool_use",
        "id": "tu-3",
        "name": "tool",
        "input": json.dumps({"key": "value"}),
    }
    result = serialize_anthropic_content_block(block)
    assert result["input"] == {"key": "value"}


def test_serialize_anthropic_content_block_tool_use_string_input_invalid_json():
    block = {
        "type": "tool_use",
        "id": "tu-4",
        "name": "tool",
        "input": "not json at all",
    }
    result = serialize_anthropic_content_block(block)
    assert result["input"] == {}


# ---------------------------------------------------------------------------
# serialize_anthropic_content_block — image block
# ---------------------------------------------------------------------------


def test_serialize_anthropic_content_block_image():
    block = {
        "type": "image",
        "source": {"type": "base64", "media_type": "image/jpeg", "data": "abc123"},
    }
    result = serialize_anthropic_content_block(block)
    assert result["type"] == "image"
    assert result["source"]["media_type"] == "image/jpeg"
    assert result["source"]["data"] == "abc123"


# ---------------------------------------------------------------------------
# serialize_anthropic_content_block — tool_result block
# ---------------------------------------------------------------------------


def test_serialize_anthropic_content_block_tool_result_list_content():
    block = {
        "type": "tool_result",
        "tool_use_id": "tu-1",
        "content": [{"type": "text", "text": "result"}],
        "is_error": False,
    }
    result = serialize_anthropic_content_block(block)
    assert result["type"] == "tool_result"
    assert result["tool_use_id"] == "tu-1"
    assert result["content"] == [{"type": "text", "text": "result"}]
    assert result["is_error"] is False


def test_serialize_anthropic_content_block_tool_result_string_content():
    block = {
        "type": "tool_result",
        "tool_use_id": "tu-2",
        "content": "plain string result",
        "is_error": False,
    }
    result = serialize_anthropic_content_block(block)
    assert result["content"] == [{"type": "text", "text": "plain string result"}]


def test_serialize_anthropic_content_block_tool_result_is_error():
    block = {
        "type": "tool_result",
        "tool_use_id": "tu-3",
        "content": "error message",
        "is_error": True,
    }
    result = serialize_anthropic_content_block(block)
    assert result["is_error"] is True


# ---------------------------------------------------------------------------
# serialize_anthropic_content_block — unknown block type
# ---------------------------------------------------------------------------


def test_serialize_anthropic_content_block_unknown_type_returns_dumped():
    block = {"type": "unknown_custom", "data": "something"}
    result = serialize_anthropic_content_block(block)
    assert result["type"] == "unknown_custom"
    assert result["data"] == "something"


# ---------------------------------------------------------------------------
# serialize_anthropic_content_block — non-dict, non-model fallback
# ---------------------------------------------------------------------------


def test_serialize_anthropic_content_block_plain_string_fallback():
    result = serialize_anthropic_content_block("just a string")
    assert result == {"type": "text", "text": "just a string"}


def test_serialize_anthropic_content_block_integer_fallback():
    result = serialize_anthropic_content_block(42)
    assert result == {"type": "text", "text": "42"}


# ---------------------------------------------------------------------------
# serialize_content_blocks — string input
# ---------------------------------------------------------------------------


def test_serialize_content_blocks_string_input():
    result = serialize_content_blocks("hello")
    assert result == [{"type": "text", "text": "hello"}]


# ---------------------------------------------------------------------------
# serialize_content_blocks — iterable input
# ---------------------------------------------------------------------------


def test_serialize_content_blocks_iterable_text_blocks():
    blocks = [
        {"type": "text", "text": "a"},
        {"type": "text", "text": "b"},
    ]
    result = serialize_content_blocks(blocks)
    assert result == [
        {"type": "text", "text": "a"},
        {"type": "text", "text": "b"},
    ]


def test_serialize_content_blocks_with_tool_display_names():
    blocks = [
        {"type": "tool_use", "id": "tu-1", "name": "read_files", "input": {}}
    ]
    result = serialize_content_blocks(blocks, tool_display_names={"read_files": "Read Files"})
    assert result[0]["display_name"] == "Read Files"


def test_serialize_content_blocks_empty_iterable():
    result = serialize_content_blocks([])
    assert result == []
