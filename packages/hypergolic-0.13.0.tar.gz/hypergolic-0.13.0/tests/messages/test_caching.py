"""Tests for hypergolic.messages.caching."""

from copy import deepcopy
from typing import Any, cast

from anthropic.types import MessageParam

from hypergolic.messages.caching import _strip_cache_control, set_message_cache_breakpoint


def _msgs(*messages: Any) -> list[MessageParam]:
    """Coerce test-shaped dicts to list[MessageParam] for the type checker.

    The test fixtures use raw dict literals that structurally match
    MessageParam but aren't nominally one. `cast` tells ty to trust us.
    """
    return cast(list[MessageParam], list(messages))


# ---------------------------------------------------------------------------
# _strip_cache_control
# ---------------------------------------------------------------------------


def test_strip_cache_control_removes_from_content_blocks():
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "hello", "cache_control": {"type": "ephemeral"}},
                {"type": "text", "text": "world"},
            ],
        }
    )
    _strip_cache_control(messages)
    content = cast(list[dict[str, Any]], messages[0]["content"])
    assert "cache_control" not in content[0]
    assert content[1] == {"type": "text", "text": "world"}


def test_strip_cache_control_multiple_messages():
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "a", "cache_control": {"type": "ephemeral"}},
            ],
        },
        {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "b", "cache_control": {"type": "ephemeral"}},
            ],
        },
    )
    _strip_cache_control(messages)
    c0 = cast(list[dict[str, Any]], messages[0]["content"])
    c1 = cast(list[dict[str, Any]], messages[1]["content"])
    assert "cache_control" not in c0[0]
    assert "cache_control" not in c1[0]


def test_strip_cache_control_skips_non_dict_messages():
    """Non-dict entries in the message list are skipped without error."""
    messages = cast(list[MessageParam], ["not a dict"])
    _strip_cache_control(messages)  # should not raise


def test_strip_cache_control_skips_message_without_content():
    messages = _msgs({"role": "user"})  # no "content" key
    _strip_cache_control(messages)  # should not raise


def test_strip_cache_control_skips_string_content():
    """String content (not a list) is skipped."""
    messages = _msgs({"role": "user", "content": "plain string"})
    _strip_cache_control(messages)  # should not raise


def test_strip_cache_control_skips_non_dict_blocks():
    """Non-dict blocks inside content are skipped."""
    messages = _msgs({"role": "user", "content": ["string block"]})
    _strip_cache_control(messages)  # should not raise


def test_strip_cache_control_no_cache_control_key_unchanged():
    messages = _msgs(
        {
            "role": "user",
            "content": [{"type": "text", "text": "hello"}],
        }
    )
    original = deepcopy(messages)
    _strip_cache_control(messages)
    assert messages == original


# ---------------------------------------------------------------------------
# set_message_cache_breakpoint
# ---------------------------------------------------------------------------


def _blocks(msg: MessageParam) -> list[dict[str, Any]]:
    return cast(list[dict[str, Any]], msg["content"])


def test_set_message_cache_breakpoint_two_or_more_messages_sets_on_second_to_last():
    messages = _msgs(
        {
            "role": "user",
            "content": [{"type": "text", "text": "first"}],
        },
        {
            "role": "assistant",
            "content": [{"type": "text", "text": "second"}],
        },
    )
    result = set_message_cache_breakpoint(messages)
    # Breakpoint set on [-2] i.e. index 0
    assert _blocks(result[0])[-1]["cache_control"] == {"type": "ephemeral"}
    # [-1] should NOT have cache_control
    assert "cache_control" not in _blocks(result[1])[-1]


def test_set_message_cache_breakpoint_one_message_sets_on_last():
    messages = _msgs(
        {
            "role": "user",
            "content": [{"type": "text", "text": "only message"}],
        }
    )
    result = set_message_cache_breakpoint(messages)
    assert _blocks(result[0])[-1]["cache_control"] == {"type": "ephemeral"}


def test_set_message_cache_breakpoint_returns_deep_copy():
    messages = _msgs(
        {
            "role": "user",
            "content": [{"type": "text", "text": "hello"}],
        }
    )
    result = set_message_cache_breakpoint(messages)
    # Modifying result must not affect original
    _blocks(result[0])[0]["cache_control"] = {"type": "ephemeral"}
    assert "cache_control" not in _blocks(messages[0])[0]


def test_set_message_cache_breakpoint_strips_existing_cache_control_first():
    """Existing cache_control entries are stripped before the new one is set."""
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "first", "cache_control": {"type": "ephemeral"}},
            ],
        },
        {
            "role": "assistant",
            "content": [
                {"type": "text", "text": "second"},
            ],
        },
    )
    result = set_message_cache_breakpoint(messages)
    # [-2] = index 0 — old cache_control replaced (stripped then re-set)
    assert _blocks(result[0])[-1]["cache_control"] == {"type": "ephemeral"}


def test_set_message_cache_breakpoint_empty_content_list_returns_result():
    """When the target message has an empty content list, return result without error."""
    messages = _msgs(
        {"role": "user", "content": []},
        {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
    )
    result = set_message_cache_breakpoint(messages)
    # No cache_control set on first message (empty content)
    assert result[0]["content"] == []


def test_set_message_cache_breakpoint_non_dict_target_content_returns_result():
    """If target message content is a plain string, skip setting cache_control."""
    messages = _msgs(
        {"role": "user", "content": "string content"},
        {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
    )
    result = set_message_cache_breakpoint(messages)
    # Should return without raising; first message content unchanged
    assert result[0]["content"] == "string content"


def test_set_message_cache_breakpoint_last_block_non_dict():
    """If the last content block is not a dict, cache_control is not set."""
    messages = _msgs(
        {"role": "user", "content": ["a plain string block"]},
    )
    result = set_message_cache_breakpoint(messages)
    assert result[0]["content"] == ["a plain string block"]


def test_set_message_cache_breakpoint_skips_empty_text_block():
    """Empty text blocks must not receive cache_control (API rejects it)."""
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "real content"},
                {"type": "text", "text": ""},
            ],
        },
        {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
    )
    result = set_message_cache_breakpoint(messages)
    blocks = _blocks(result[0])
    # Empty trailing block must remain bare
    assert "cache_control" not in blocks[1]
    # Breakpoint falls back to the last non-empty block
    assert blocks[0]["cache_control"] == {"type": "ephemeral"}


def test_set_message_cache_breakpoint_all_empty_text_blocks_skips_silently():
    """If every block is non-cacheable, no cache_control is set anywhere."""
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": ""},
                {"type": "text", "text": ""},
            ],
        },
        {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
    )
    result = set_message_cache_breakpoint(messages)
    for block in _blocks(result[0]):
        assert "cache_control" not in block


def test_set_message_cache_breakpoint_tool_use_block_is_cacheable():
    """Non-text block types (tool_use, tool_result, image) remain cacheable."""
    messages = _msgs(
        {
            "role": "assistant",
            "content": [
                {"type": "tool_use", "id": "t1", "name": "x", "input": {}},
            ],
        },
        {"role": "user", "content": [{"type": "text", "text": "ok"}]},
    )
    result = set_message_cache_breakpoint(messages)
    assert _blocks(result[0])[0]["cache_control"] == {"type": "ephemeral"}


def test_set_message_cache_breakpoint_non_string_text_treated_as_empty():
    """A text block whose 'text' is missing/None is not cacheable."""
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {"type": "text", "text": "kept"},
                {"type": "text"},  # no text key
            ],
        },
        {"role": "assistant", "content": [{"type": "text", "text": "hi"}]},
    )
    result = set_message_cache_breakpoint(messages)
    blocks = _blocks(result[0])
    assert "cache_control" not in blocks[1]
    assert blocks[0]["cache_control"] == {"type": "ephemeral"}
