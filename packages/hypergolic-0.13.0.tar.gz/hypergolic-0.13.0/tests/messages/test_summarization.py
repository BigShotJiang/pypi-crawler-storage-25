"""Tests for hypergolic.messages.summarization."""

from typing import Any, cast
from unittest.mock import MagicMock, patch

import pytest
from anthropic.types import Message, MessageParam, TextBlock, Usage

from hypergolic.messages.summarization import (
    TOOL_RESULT_MAX_CHARS,
    _build_artifact_context_block,
    _build_system_prompt,
    _truncate_tool_result,
    build_conversation_transcript,
    extract_summary_text,
)


def _msgs(*messages: Any) -> list[MessageParam]:
    return cast(list[MessageParam], list(messages))


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _make_session(**overrides: Any):
    """Return a minimal Session-like MagicMock."""
    from hypergolic.enums import ModelTier
    from hypergolic.schemas import Session

    defaults: dict[str, Any] = dict(
        id="sess-1",
        model_tier=ModelTier.LOW,
        project_id="proj-1",
        project_path="/tmp/test",
        role="generalist",
    )
    defaults.update(overrides)
    return Session(**defaults)


def _make_response(content_blocks) -> Message:
    return Message(
        id="msg-1",
        content=content_blocks,
        model="claude-sonnet-4-20250514",
        role="assistant",
        stop_reason="end_turn",
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=10, output_tokens=20),
    )


# ---------------------------------------------------------------------------
# _truncate_tool_result
# ---------------------------------------------------------------------------


def test_truncate_tool_result_under_limit():
    text = "short text"
    result = _truncate_tool_result(text)
    assert result == text


def test_truncate_tool_result_at_exact_limit():
    text = "x" * TOOL_RESULT_MAX_CHARS
    result = _truncate_tool_result(text)
    assert result == text  # exactly at limit — no truncation


def test_truncate_tool_result_over_limit():
    text = "x" * (TOOL_RESULT_MAX_CHARS + 100)
    result = _truncate_tool_result(text)
    assert result.startswith("x" * TOOL_RESULT_MAX_CHARS)
    assert "truncated" in result


def test_truncate_tool_result_custom_max():
    text = "hello world"
    result = _truncate_tool_result(text, max_chars=5)
    assert result.startswith("hello")
    assert "truncated" in result


# ---------------------------------------------------------------------------
# build_conversation_transcript
# ---------------------------------------------------------------------------


def test_build_conversation_transcript_user_text_message():
    messages = _msgs({"role": "user", "content": [{"type": "text", "text": "hello there"}]})
    result = build_conversation_transcript(messages)
    assert len(result) == 1
    assert result[0]["text"] == "[user]: hello there"


def test_build_conversation_transcript_assistant_text_message():
    messages = _msgs(
        {"role": "assistant", "content": [{"type": "text", "text": "hi back"}]}
    )
    result = build_conversation_transcript(messages)
    assert len(result) == 1
    assert result[0]["text"] == "[assistant]: hi back"


def test_build_conversation_transcript_tool_use_block():
    messages = _msgs(
        {
            "role": "assistant",
            "content": [
                {"type": "tool_use", "name": "read_files", "input": {"paths": ["a.py"]}}
            ],
        }
    )
    result = build_conversation_transcript(messages)
    assert len(result) == 1
    assert "[Tool call: read_files" in result[0]["text"]


def test_build_conversation_transcript_tool_result_string_content():
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "tu-1",
                    "content": "the result text",
                    "is_error": False,
                }
            ],
        }
    )
    result = build_conversation_transcript(messages)
    assert len(result) == 1
    assert "[Tool result: the result text]" in result[0]["text"]


def test_build_conversation_transcript_tool_result_list_content():
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "tu-1",
                    "content": [{"type": "text", "text": "list result"}],
                    "is_error": False,
                }
            ],
        }
    )
    result = build_conversation_transcript(messages)
    assert len(result) == 1
    assert "[Tool result: list result]" in result[0]["text"]


def test_build_conversation_transcript_tool_result_is_error():
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "tu-1",
                    "content": "something broke",
                    "is_error": True,
                }
            ],
        }
    )
    result = build_conversation_transcript(messages)
    assert "[Tool error: something broke]" in result[0]["text"]


def test_build_conversation_transcript_empty_text_block_skipped():
    """Text blocks with only whitespace are skipped."""
    messages = _msgs({"role": "user", "content": [{"type": "text", "text": "   "}]})
    result = build_conversation_transcript(messages)
    assert result == []


def test_build_conversation_transcript_empty_content_list():
    messages = _msgs({"role": "user", "content": []})
    result = build_conversation_transcript(messages)
    assert result == []


def test_build_conversation_transcript_string_content_message():
    """Messages with string content (not list) are handled."""
    messages = _msgs({"role": "user", "content": "plain string content"})
    result = build_conversation_transcript(messages)
    assert len(result) == 1
    assert result[0]["text"] == "[user]: plain string content"


def test_build_conversation_transcript_string_content_whitespace_only_skipped():
    messages = _msgs({"role": "user", "content": "   "})
    result = build_conversation_transcript(messages)
    assert result == []


def test_build_conversation_transcript_non_dict_block_skipped():
    """Non-dict blocks inside content list are skipped."""
    messages = _msgs({"role": "user", "content": ["not a dict"]})
    result = build_conversation_transcript(messages)
    assert result == []


def test_build_conversation_transcript_multiple_messages():
    messages = _msgs(
        {"role": "user", "content": [{"type": "text", "text": "question"}]},
        {"role": "assistant", "content": [{"type": "text", "text": "answer"}]},
    )
    result = build_conversation_transcript(messages)
    assert len(result) == 2
    assert "[user]:" in result[0]["text"]
    assert "[assistant]:" in result[1]["text"]


def test_build_conversation_transcript_tool_result_long_string_truncated():
    long_text = "x" * (TOOL_RESULT_MAX_CHARS + 100)
    messages = _msgs(
        {
            "role": "user",
            "content": [
                {
                    "type": "tool_result",
                    "tool_use_id": "tu-1",
                    "content": long_text,
                    "is_error": False,
                }
            ],
        }
    )
    result = build_conversation_transcript(messages)
    assert "truncated" in result[0]["text"]


# ---------------------------------------------------------------------------
# _build_system_prompt
# ---------------------------------------------------------------------------


def test_build_system_prompt_includes_file_when_exists():
    session = _make_session()
    prompt_text = "You are a summarization assistant."
    with patch(
        "hypergolic.messages.summarization.SUMMARIZE_PROMPT_PATH"
    ) as mock_path:
        mock_path.exists.return_value = True
        mock_path.read_text.return_value = prompt_text
        result = _build_system_prompt(session)

    assert len(result) == 1
    assert result[0]["type"] == "text"
    assert result[0]["text"] == prompt_text


def test_build_system_prompt_empty_when_file_missing():
    session = _make_session()
    with patch(
        "hypergolic.messages.summarization.SUMMARIZE_PROMPT_PATH"
    ) as mock_path:
        mock_path.exists.return_value = False
        result = _build_system_prompt(session)

    assert result == []


# ---------------------------------------------------------------------------
# extract_summary_text
# ---------------------------------------------------------------------------


def test_extract_summary_text_returns_text_from_blocks():
    response = _make_response([TextBlock(type="text", text="This is the summary.")])
    result = extract_summary_text(response)
    assert result == "This is the summary."


def test_extract_summary_text_concatenates_multiple_text_blocks():
    response = _make_response(
        [
            TextBlock(type="text", text="Part one. "),
            TextBlock(type="text", text="Part two."),
        ]
    )
    result = extract_summary_text(response)
    assert result == "Part one. Part two."


def test_extract_summary_text_raises_on_empty_response():
    response = _make_response([])
    with pytest.raises(ValueError, match="empty response"):
        extract_summary_text(response)


def test_extract_summary_text_raises_on_whitespace_only_response():
    response = _make_response([TextBlock(type="text", text="   ")])
    with pytest.raises(ValueError, match="empty response"):
        extract_summary_text(response)


def test_extract_summary_text_skips_non_text_blocks():
    """Blocks without type=='text' (e.g. ToolUseBlock) are skipped."""
    non_text = MagicMock()
    non_text.type = "tool_use"
    # We can't instantiate ToolUseBlock easily without all required args,
    # so use a simple mock with a different type attribute.
    response = _make_response([TextBlock(type="text", text="summary here")])
    # Replace content with our mixed list via a MagicMock response
    mock_response = MagicMock()
    mock_response.content = [non_text, TextBlock(type="text", text="summary here")]
    result = extract_summary_text(mock_response)
    assert result == "summary here"


# ---------------------------------------------------------------------------
# _build_artifact_context_block
# ---------------------------------------------------------------------------


def test_build_artifact_context_block_empty_list_returns_none():
    result = _build_artifact_context_block([])
    assert result is None


def test_build_artifact_context_block_non_empty_returns_text_block():
    artifacts = [
        ("art-1", {"field_a": "val", "field_b": 42}, "2024-01-01T00:00:00"),
    ]
    result = _build_artifact_context_block(artifacts)
    assert result is not None
    assert result["type"] == "text"
    assert "art-1" in result["text"]
    assert "field_a" in result["text"]
    assert "field_b" in result["text"]


def test_build_artifact_context_block_multiple_artifacts():
    artifacts = [
        ("art-1", {"x": 1}, "2024-01-01T00:00:00"),
        ("art-2", {"y": 2, "z": 3}, "2024-01-02T00:00:00"),
    ]
    result = _build_artifact_context_block(artifacts)
    assert result is not None
    assert "art-1" in result["text"]
    assert "art-2" in result["text"]
    assert "y" in result["text"]
    assert "z" in result["text"]


def test_build_artifact_context_block_empty_dict_shows_empty():
    artifacts = [
        ("art-1", {}, "2024-01-01T00:00:00"),
    ]
    result = _build_artifact_context_block(artifacts)
    assert result is not None
    assert "empty" in result["text"]


def test_build_artifact_context_block_includes_created_at():
    artifacts = [
        ("art-1", {"key": "val"}, "2024-06-15T12:00:00"),
    ]
    result = _build_artifact_context_block(artifacts)
    assert result is not None
    assert "2024-06-15T12:00:00" in result["text"]
