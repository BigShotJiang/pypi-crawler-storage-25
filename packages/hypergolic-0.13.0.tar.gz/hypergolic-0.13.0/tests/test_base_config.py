"""Ensure the base registries never contain duplicate IDs.

This catches mistakes like a skill appearing in both ALL_BASE_SKILLS
and a role's skills list, or duplicate tool/role IDs across registries.
"""

from hypergolic.base.skills.registry import ALL_BASE_SKILLS, REVIEWER_SKILLS
from hypergolic.base.roles.registry import ALL_BASE_ROLES
from hypergolic.base.tools.registry import (
    UNIVERSAL_TOOLS,
    TOOLKIT_ENGINEER_TOOLS,
)
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.validation import validate_app


def test_no_duplicate_skill_ids():
    """Every skill ID must be unique across all base registries."""
    app = App()
    app.register_tools(UNIVERSAL_TOOLS)
    app.register_roles(ALL_BASE_ROLES)
    app.register_skills(ALL_BASE_SKILLS)

    errors = validate_app(app)
    skill_errors = [e for e in errors if "Duplicate skill ID" in e]
    assert skill_errors == [], f"Duplicate skills in base config: {skill_errors}"


def test_no_duplicate_tool_ids():
    """Every tool ID must be unique across all base registries."""
    app = App()
    app.register_tools(UNIVERSAL_TOOLS)
    app.register_roles(ALL_BASE_ROLES)
    app.register_skills(ALL_BASE_SKILLS)

    errors = validate_app(app)
    tool_errors = [e for e in errors if "Duplicate tool ID" in e]
    assert tool_errors == [], f"Duplicate tools in base config: {tool_errors}"


def test_no_duplicate_role_ids():
    """Every role ID must be unique in ALL_BASE_ROLES."""
    ids = [r.id for r in ALL_BASE_ROLES]
    assert len(ids) == len(set(ids)), f"Duplicate role IDs: {[x for x in ids if ids.count(x) > 1]}"


def test_base_config_validates_cleanly():
    """The full base config should pass validation with zero errors."""
    app = App()
    app.register_tools(UNIVERSAL_TOOLS)
    app.register_roles(ALL_BASE_ROLES)
    app.register_skills(ALL_BASE_SKILLS)

    errors = validate_app(app)
    assert errors == [], f"Base config validation errors: {errors}"
