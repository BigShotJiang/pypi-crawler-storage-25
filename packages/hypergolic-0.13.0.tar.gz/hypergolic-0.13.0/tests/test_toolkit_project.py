"""Tests for hypergolic.toolkit.project.Project."""

import pytest
from pydantic import ValidationError

from hypergolic.toolkit.primitives import Skill, Tool, Workflow, WorkflowState
from hypergolic.toolkit.project import Project


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _noop(inp, ctx):
    return "ok"


def _tool(tid: str = "t1") -> Tool:
    return Tool(id=tid, name=tid, description="d", run=_noop)


def _skill(sid: str = "s1") -> Skill:
    return Skill(id=sid, name=sid, description="d")


def _workflow(wid: str = "wf1") -> Workflow:
    return Workflow(
        id=wid, name=wid, description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
    )


# ---------------------------------------------------------------------------
# Construction
# ---------------------------------------------------------------------------


def test_project_minimal_construction():
    p = Project(id="p1", name="P1", description="desc", git_root="/tmp")
    assert p.id == "p1"
    assert p.name == "P1"
    assert p.description == "desc"
    assert p.git_root == "/tmp"
    assert p.prompt_path is None
    assert p.prompt is None
    assert p.prompt_fn is None
    assert p.tools == []
    assert p.skills == []
    assert p.workflows == []


def test_project_with_prompt():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp", prompt="Hello")
    assert p.prompt == "Hello"


def test_project_with_prompt_path():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp", prompt_path="/some/path.md")
    assert p.prompt_path == "/some/path.md"


def test_project_with_prompt_fn():
    fn = lambda app: "dynamic"
    p = Project(id="p1", name="P1", description="d", git_root="/tmp", prompt_fn=fn)
    assert p.prompt_fn is fn


def test_project_prompt_exclusivity_raises():
    """Specifying more than one prompt source raises ValidationError."""
    with pytest.raises(ValidationError):
        Project(
            id="p1", name="P1", description="d", git_root="/tmp",
            prompt="inline",
            prompt_path="/some/path.md",
        )


def test_project_prompt_fn_and_prompt_raises():
    with pytest.raises(ValidationError):
        Project(
            id="p1", name="P1", description="d", git_root="/tmp",
            prompt="inline",
            prompt_fn=lambda app: "fn",
        )


# ---------------------------------------------------------------------------
# Tools
# ---------------------------------------------------------------------------


def test_register_tool():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp")
    t = _tool("t1")
    p.register_tool(t)
    assert len(p.tools) == 1
    assert p.tools[0].id == "t1"


def test_register_tools():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp")
    p.register_tools([_tool("t1"), _tool("t2")])
    assert len(p.tools) == 2


# ---------------------------------------------------------------------------
# Skills
# ---------------------------------------------------------------------------


def test_register_skill():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp")
    s = _skill("s1")
    p.register_skill(s)
    assert len(p.skills) == 1
    assert p.skills[0].id == "s1"


def test_register_skills():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp")
    p.register_skills([_skill("s1"), _skill("s2")])
    assert len(p.skills) == 2


# ---------------------------------------------------------------------------
# Workflows
# ---------------------------------------------------------------------------


def test_register_workflow():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp")
    wf = _workflow("wf1")
    p.register_workflow(wf)
    assert len(p.workflows) == 1
    assert p.workflows[0].id == "wf1"


def test_register_workflows():
    p = Project(id="p1", name="P1", description="d", git_root="/tmp")
    p.register_workflows([_workflow("wf1"), _workflow("wf2")])
    assert len(p.workflows) == 2


# ---------------------------------------------------------------------------
# Construction with inline lists
# ---------------------------------------------------------------------------


def test_project_with_initial_tools():
    p = Project(
        id="p1", name="P1", description="d", git_root="/tmp",
        tools=[_tool("t1")],
    )
    assert len(p.tools) == 1


def test_project_with_initial_skills():
    p = Project(
        id="p1", name="P1", description="d", git_root="/tmp",
        skills=[_skill("s1")],
    )
    assert len(p.skills) == 1


def test_project_with_initial_workflows():
    p = Project(
        id="p1", name="P1", description="d", git_root="/tmp",
        workflows=[_workflow("wf1")],
    )
    assert len(p.workflows) == 1
