"""Test that the conversation loop breaks when a session enters terminal status.

This tests the fix for the bug where a child session calling `conclude`
would have its CONCLUDED status overwritten by the next iteration of
the conversation loop (which would set THINKING, make another API call,
and eventually set IDLE).
"""
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from anthropic.types import Message, TextBlock, Usage

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.enums import ModelTier, SessionStatus
from hypergolic.messages.conversation.loop import create_message
from hypergolic.schemas import Session


def _seed(sid="s1", parent_id=None):
    with get_db() as db:
        if not db.get(DBProject, "p1"):
            db.add(DBProject(id="p1", name="Proj", path="/tmp/p"))
        if parent_id and not db.get(DBSession, parent_id):
            db.add(DBSession(
                id=parent_id, model_tier="Medium", system_prompt=[], project_id="p1",
            ))
        db.add(DBSession(
            id=sid, model_tier="Medium", system_prompt=[], project_id="p1",
            parent_id=parent_id,
        ))


def _make_session(sid="s1", parent_id=None):
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path="/tmp/p",
        parent_id=parent_id,
    )


def _make_response(stop_reason="end_turn"):
    return Message(
        id="msg-1",
        type="message",
        model="claude-sonnet-4-20250514",
        role="assistant",
        content=[TextBlock(type="text", text="Done")],
        stop_reason=stop_reason,
        usage=Usage(input_tokens=10, output_tokens=5, cache_creation_input_tokens=0, cache_read_input_tokens=0),
    )


@pytest.mark.asyncio
async def test_loop_breaks_on_terminal_status_after_tool_use():
    """After a tool sets status to CONCLUDED, the loop should not continue."""
    _seed("child", parent_id="parent")
    session = _make_session("child", parent_id="parent")

    tool_use_response = _make_response(stop_reason="tool_use")
    broadcast = AsyncMock()
    stream_call_count = 0

    async def mock_stream(*args, **kwargs):
        nonlocal stream_call_count
        stream_call_count += 1
        return tool_use_response

    with (
        patch("hypergolic.messages.conversation.loop.build_session_prompt", return_value=[]),
        patch("hypergolic.messages.conversation.loop.build_tools", return_value=[]),
        patch("hypergolic.messages.conversation.loop.get_tool_schemas", return_value=[]),
        patch("hypergolic.messages.conversation.loop.set_tools_cache_breakpoint", side_effect=lambda x: x),
        patch("hypergolic.messages.conversation.loop.persist_user_message", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.persist_agent_message", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.maybe_generate_description"),
        patch("hypergolic.messages.conversation.loop.should_truncate", return_value=False),
        patch("hypergolic.messages.conversation.loop.set_session_status_and_broadcast", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.load_session_messages", return_value=[]),
        patch("hypergolic.messages.conversation.loop.set_message_cache_breakpoint", side_effect=lambda x: x),
        patch("hypergolic.messages.conversation.loop.stream_response", new=AsyncMock(side_effect=mock_stream)),
        patch("hypergolic.messages.conversation.loop.dispatch_stop_reason", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.get_session_status", return_value=SessionStatus.CONCLUDED),
        patch("hypergolic.messages.conversation.loop.auto_conclude_if_needed", return_value=False),
    ):
        result = await create_message(
            client=MagicMock(),
            session=session,
            message={"role": "user", "content": [{"type": "text", "text": "hi"}]},
            broadcast=broadcast,
        )

    # stream_response should only be called once — the loop should break
    # after discovering the terminal status instead of looping again
    assert stream_call_count == 1
    assert result == tool_use_response


@pytest.mark.asyncio
async def test_loop_continues_when_status_is_not_terminal():
    """When status is not terminal, the loop continues until end_turn."""
    _seed("s1")
    session = _make_session("s1")

    tool_use_response = _make_response(stop_reason="tool_use")
    end_turn_response = _make_response(stop_reason="end_turn")
    broadcast = AsyncMock()
    stream_call_count = 0

    async def mock_stream(*args, **kwargs):
        nonlocal stream_call_count
        stream_call_count += 1
        if stream_call_count == 1:
            return tool_use_response
        return end_turn_response

    with (
        patch("hypergolic.messages.conversation.loop.build_session_prompt", return_value=[]),
        patch("hypergolic.messages.conversation.loop.build_tools", return_value=[]),
        patch("hypergolic.messages.conversation.loop.get_tool_schemas", return_value=[]),
        patch("hypergolic.messages.conversation.loop.set_tools_cache_breakpoint", side_effect=lambda x: x),
        patch("hypergolic.messages.conversation.loop.persist_user_message", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.persist_agent_message", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.maybe_generate_description"),
        patch("hypergolic.messages.conversation.loop.should_truncate", return_value=False),
        patch("hypergolic.messages.conversation.loop.set_session_status_and_broadcast", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.load_session_messages", return_value=[]),
        patch("hypergolic.messages.conversation.loop.set_message_cache_breakpoint", side_effect=lambda x: x),
        patch("hypergolic.messages.conversation.loop.stream_response", new=AsyncMock(side_effect=mock_stream)),
        patch("hypergolic.messages.conversation.loop.dispatch_stop_reason", new=AsyncMock()),
        patch("hypergolic.messages.conversation.loop.get_session_status", return_value=SessionStatus.TOOL_USE),
        patch("hypergolic.messages.conversation.loop.auto_conclude_if_needed", return_value=False),
    ):
        result = await create_message(
            client=MagicMock(),
            session=session,
            message={"role": "user", "content": [{"type": "text", "text": "hi"}]},
            broadcast=broadcast,
        )

    # stream_response should be called twice: once for tool_use, once for end_turn
    assert stream_call_count == 2
    assert result == end_turn_response
