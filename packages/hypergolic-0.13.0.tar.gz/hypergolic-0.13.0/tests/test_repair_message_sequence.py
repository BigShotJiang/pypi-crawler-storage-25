import logging
from typing import Any, cast

from anthropic.types import MessageParam, TextBlockParam, ToolUseBlockParam

from hypergolic.messages.persistence import _repair_message_sequence


def _user(text: str) -> MessageParam:
    block: TextBlockParam = {"type": "text", "text": text}
    return MessageParam(role="user", content=[block])


def _assistant(text: str) -> MessageParam:
    block: TextBlockParam = {"type": "text", "text": text}
    return MessageParam(role="assistant", content=[block])


def _assistant_tool_use(tool_id: str) -> MessageParam:
    block: ToolUseBlockParam = {"type": "tool_use", "id": tool_id, "name": "test", "input": {}}
    return MessageParam(role="assistant", content=[block])


def _content_list(msg: MessageParam) -> list[Any]:
    return cast(list[Any], msg["content"])


def test_empty_list():
    assert _repair_message_sequence([]) == []


def test_no_repair_needed():
    msgs = [_user("hello"), _assistant("hi")]
    result = _repair_message_sequence(msgs)
    assert len(result) == 2
    assert result[0]["role"] == "user"
    assert result[1]["role"] == "assistant"


def test_consecutive_user_messages_merged(caplog: Any):
    msgs = [_user("a"), _user("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        result = _repair_message_sequence(msgs)
    assert len(result) == 1
    assert result[0]["role"] == "user"
    assert len(_content_list(result[0])) == 2
    assert "merging consecutive user messages" in caplog.text


def test_consecutive_assistant_messages_merged(caplog: Any):
    msgs = [_user("start"), _assistant("a"), _assistant("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        result = _repair_message_sequence(msgs)
    assert len(result) == 2
    assert result[1]["role"] == "assistant"
    assert len(_content_list(result[1])) == 2
    assert "merging consecutive assistant messages" in caplog.text


def test_assistant_tool_use_followed_by_assistant_inserts_synthetic(caplog: Any):
    msgs = [_user("go"), _assistant_tool_use("tool_1"), _assistant("done")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        result = _repair_message_sequence(msgs)
    # user, assistant(tool_use), user(synthetic tool_result), assistant(done)
    assert len(result) == 4
    assert result[2]["role"] == "user"
    content = _content_list(result[2])
    tool_result = content[0]
    assert tool_result["type"] == "tool_result"
    assert tool_result["tool_use_id"] == "tool_1"
    assert tool_result["is_error"] is True
    assert "inserting synthetic tool_results" in caplog.text


def test_trailing_tool_use_gets_synthetic_result(caplog: Any):
    msgs = [_user("go"), _assistant_tool_use("tool_2")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        result = _repair_message_sequence(msgs)
    assert len(result) == 3
    assert result[2]["role"] == "user"
    content = _content_list(result[2])
    assert content[0]["tool_use_id"] == "tool_2"
    assert "appending synthetic tool_results for trailing tool_use" in caplog.text


def test_log_includes_session_id(caplog: Any):
    msgs = [_user("a"), _user("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(msgs, session_id="sess-123")
    assert "session=sess-123" in caplog.text


def test_log_includes_message_id(caplog: Any):
    msgs = [_user("a"), _user("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(msgs, message_ids=["msg-1", "msg-2"])
    assert "message=msg-2" in caplog.text


def test_log_includes_session_and_message_id(caplog: Any):
    msgs = [_user("a"), _user("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(msgs, session_id="sess-456", message_ids=["msg-A", "msg-B"])
    assert "session=sess-456" in caplog.text
    assert "message=msg-B" in caplog.text


def test_no_context_when_no_ids_provided(caplog: Any):
    msgs = [_user("a"), _user("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(msgs)
    assert "session=" not in caplog.text
    assert "message=" not in caplog.text
    assert "merging consecutive user messages" in caplog.text


def test_tool_use_repair_logs_context(caplog: Any):
    msgs = [_user("go"), _assistant_tool_use("t1"), _assistant("done")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(
            msgs, session_id="sess-789", message_ids=["m1", "m2", "m3"]
        )
    assert "session=sess-789" in caplog.text
    assert "message=m2" in caplog.text


def test_trailing_tool_use_logs_context(caplog: Any):
    msgs = [_user("go"), _assistant_tool_use("t1")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(
            msgs, session_id="sess-trail", message_ids=["m1", "m2"]
        )
    assert "session=sess-trail" in caplog.text
    assert "message=m2" in caplog.text


def test_assistant_merge_logs_context(caplog: Any):
    msgs = [_user("start"), _assistant("a"), _assistant("b")]
    with caplog.at_level(logging.WARNING, logger="hypergolic.messages.persistence"):
        _repair_message_sequence(
            msgs, session_id="sess-merge", message_ids=["m1", "m2", "m3"]
        )
    assert "session=sess-merge" in caplog.text
    assert "message=m3" in caplog.text


def test_string_content_converted_to_blocks():
    msg = MessageParam(role="user", content="hello")
    msgs = [msg, _user("world")]
    result = _repair_message_sequence(msgs)
    assert len(result) == 1
    content = _content_list(result[0])
    assert content[0] == {"type": "text", "text": "hello"}
    assert content[1] == {"type": "text", "text": "world"}


def test_none_message_ids_handled():
    msgs = [_user("a"), _user("b")]
    # message_ids with None entries should not crash
    result = _repair_message_sequence(msgs, session_id="s1", message_ids=[None, None])
    assert len(result) == 1
