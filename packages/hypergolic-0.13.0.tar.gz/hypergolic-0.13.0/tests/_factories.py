"""Canonical factory helpers for tests.

Use these instead of redefining per-file `_skill`, `_session`, `_workflow`,
etc. helpers. All factories have permissive defaults so call sites only
specify the fields that matter for the test.

Naming convention:
    * `build_*` — returns an in-memory object (no DB write).
    * `make_*` (in tests/conftest.py) — writes a row to the DB.

`build_session` is distinct from `make_session` (conftest) because many
tests need a `Session` domain object that matches (or doesn't match) a
separately-seeded DB row.
"""
from __future__ import annotations

from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import (
    OutputSchema,
    Skill,
    Workflow,
    WorkflowState,
)


def build_skill(
    sid: str,
    *,
    name: str | None = None,
    description: str | None = None,
    prompt: str | None = None,
    prompt_path: str | None = None,
    children: list[Skill] | None = None,
    tools: list | None = None,
) -> Skill:
    """Construct a Skill with sensible defaults."""
    return Skill(
        id=sid,
        name=name or sid,
        description=description or f"Description for {sid}",
        prompt=prompt,
        prompt_path=prompt_path,
        skills=children or [],
        tools=tools or [],
    )


def build_session(
    sid: str = "s-1",
    *,
    project_id: str = "p-1",
    project_path: str = "/tmp/p",
    role: str = "generalist",
    model_tier: ModelTier = ModelTier.MEDIUM,
    parent_id: str | None = None,
    active_skill_ids: set[str] | None = None,
) -> Session:
    """Construct a Session domain object (does not touch the DB)."""
    return Session(
        id=sid,
        model_tier=model_tier,
        project_id=project_id,
        project_path=project_path,
        role=role,
        parent_id=parent_id,
        active_skill_ids=active_skill_ids or set(),
    )


def build_output_schema(
    outcome: str = "done",
    *,
    next_state: str | None = None,
    artifact_id: str | None = None,
) -> OutputSchema:
    return OutputSchema(
        outcome=outcome,
        next_state=next_state,
        artifact_id=artifact_id,
        schema={"type": "object", "properties": {}},
    )


def build_workflow_state(
    sid: str = "st-1",
    *,
    name: str | None = None,
    prompt: str | None = "prompt",
    prompt_path: str | None = None,
    skills: list[Skill] | None = None,
    output_schemas: list[OutputSchema] | None = None,
    truncate_on_entry: bool = False,
) -> WorkflowState:
    return WorkflowState(
        id=sid,
        name=name or sid,
        prompt=prompt if prompt_path is None else None,
        prompt_path=prompt_path,
        skills=skills or [],
        output_schemas=output_schemas or [],
        truncate_on_entry=truncate_on_entry,
    )


def build_workflow(
    wf_id: str = "wf-1",
    *,
    name: str | None = None,
    description: str = "A test workflow",
    state_id: str = "st-1",
    next_state_id: str | None = None,
    outcome: str = "done",
    artifact_id: str | None = None,
    wf_skills: list[Skill] | None = None,
    state_skills: list[Skill] | None = None,
    truncate_on_entry: bool = False,
    states: list[WorkflowState] | None = None,
) -> Workflow:
    """Construct a Workflow.

    The default shape is a two-state workflow when `next_state_id` is given,
    otherwise a single-state workflow. Pass `states=[...]` to fully override
    the state list.
    """
    if states is None:
        output_schemas = [
            build_output_schema(outcome, next_state=next_state_id, artifact_id=artifact_id)
        ]
        first = build_workflow_state(
            state_id,
            name="State One",
            skills=state_skills,
            output_schemas=output_schemas,
        )
        states = [first]
        if next_state_id:
            states.append(
                build_workflow_state(
                    next_state_id,
                    name="State Two",
                    truncate_on_entry=truncate_on_entry,
                )
            )
    return Workflow(
        id=wf_id,
        name=name or f"Workflow {wf_id}",
        description=description,
        initial_state=state_id,
        states=states,
        skills=wf_skills or [],
    )
