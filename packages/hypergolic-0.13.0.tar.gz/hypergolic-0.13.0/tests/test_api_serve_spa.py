"""Tests for hypergolic.api serve_spa endpoint (lines 122-128)."""

from pathlib import Path
from unittest.mock import patch

import pytest


def test_serve_spa_root_serves_index(api_client):
    """GET / returns the SPA index.html."""
    resp = api_client.get("/")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]


def test_serve_spa_unknown_path_falls_back_to_index(api_client):
    """GET /some/unknown/path returns index.html (SPA fallback)."""
    resp = api_client.get("/some/unknown/path")
    assert resp.status_code == 200
    assert "text/html" in resp.headers["content-type"]


def test_serve_spa_existing_file_returns_file(api_client, tmp_path):
    """GET with a full_path that exists as a file returns the file directly."""
    from hypergolic import api as api_module

    # Create a real temp file and redirect _UI_DIST to tmp_path
    static_file = tmp_path / "testfile.txt"
    static_file.write_text("static content")

    with patch.object(api_module, "_UI_DIST", tmp_path):
        resp = api_client.get("/testfile.txt")

    assert resp.status_code == 200
    assert b"static content" in resp.content


def test_serve_spa_path_traversal_falls_back_to_index(api_client, tmp_path):
    """Path traversal attempts (/../../etc/passwd) fall back to SPA index."""
    from hypergolic import api as api_module

    # Even with a patched _UI_DIST, a traversal should fall back to index
    with patch.object(api_module, "_UI_DIST", tmp_path):
        # Create a real index.html in tmp_path for the fallback
        (tmp_path / "index.html").write_text("<html><body>SPA</body></html>")
        resp = api_client.get("/../../etc/passwd")

    assert resp.status_code == 200


def test_serve_spa_with_bootstrap_token_sets_cookie(unauth_client):
    """Passing a valid bootstrap token sets the auth cookie."""
    import hypergolic.auth as auth_module
    token = auth_module.init_bootstrap_token()
    resp = unauth_client.get(f"/?token={token}", follow_redirects=False)
    assert resp.status_code == 200
    assert "h_token" in resp.headers.get("set-cookie", "")


def test_serve_spa_with_invalid_token_no_cookie(unauth_client):
    """Passing an invalid token does not set the auth cookie."""
    import hypergolic.auth as auth_module
    auth_module.init_bootstrap_token()  # initialize so _bootstrap_token is non-empty
    resp = unauth_client.get("/?token=invalid-token", follow_redirects=False)
    assert resp.status_code == 200
    assert "h_token" not in resp.headers.get("set-cookie", "")
