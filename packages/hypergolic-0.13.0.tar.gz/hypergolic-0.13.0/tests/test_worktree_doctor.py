"""Tests for hypergolic.git.worktree_doctor — reconcile orphan worktrees."""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

pytestmark = pytest.mark.timeout(10)

from hypergolic.db.engine import get_db  # noqa: E402
from hypergolic.db.models import DBProject, DBSession  # noqa: E402
from hypergolic.git.worktree import create_worktree, worktrees_root  # noqa: E402
from hypergolic.git.worktree_doctor import reconcile_worktrees  # noqa: E402


def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-b", "main", str(path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(path), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(path), "config", "user.name", "t"], check=True)
    (path / "README.md").write_text("readme\n")
    subprocess.run(["git", "-C", str(path), "add", "-A"], check=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True, capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    project = tmp_path / "project"
    project.mkdir()
    _init_repo(project)
    return project


@pytest.fixture
def worktrees_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home / ".hypergolic" / "worktrees"


def test_reconcile_is_noop_on_clean_state(repo: Path, worktrees_home: Path) -> None:
    report = reconcile_worktrees()
    assert report.is_clean()


def test_reconcile_removes_orphan_directory(
    repo: Path, worktrees_home: Path,
) -> None:
    root = worktrees_root()
    root.mkdir(parents=True, exist_ok=True)
    orphan = root / "orphan-session-id"
    orphan.mkdir()
    (orphan / "stuff").write_text("x")

    report = reconcile_worktrees()
    assert len(report.orphan_dirs_removed) == 1
    assert not orphan.exists()


def test_reconcile_dry_run_does_not_mutate(
    repo: Path, worktrees_home: Path,
) -> None:
    root = worktrees_root()
    root.mkdir(parents=True, exist_ok=True)
    orphan = root / "orphan-2"
    orphan.mkdir()

    report = reconcile_worktrees(dry_run=True)
    assert len(report.orphan_dirs_removed) == 1
    assert orphan.exists()  # still there


def test_reconcile_removes_orphan_branch(
    repo: Path, worktrees_home: Path,
) -> None:
    with get_db() as db:
        db.add(DBProject(id="proj-orphan", name="P", path=str(repo)))

    # Create a hyp/* branch with no session row pointing at it.
    subprocess.run(
        ["git", "-C", str(repo), "branch", "hyp/orphan01"],
        check=True, capture_output=True,
    )
    report = reconcile_worktrees()
    assert any("hyp/orphan01" in b for b in report.orphan_branches_removed)
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert "hyp/orphan01" not in branches


def test_reconcile_clears_stale_worktree_path(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-stale", project_path=repo)
    with get_db() as db:
        db.add(DBProject(id="proj-stale", name="P", path=str(repo)))
        db.add(DBSession(
            id="s-stale", model_tier="Medium", system_prompt=[], project_id="proj-stale",
            worktree_path=str(info.worktree_path),
            worktree_branch=info.branch,
            base_branch="main",
        ))

    # Manually nuke the directory so it's "stale."
    import shutil
    shutil.rmtree(info.worktree_path)

    report = reconcile_worktrees()
    assert "s-stale" in report.stale_rows_cleared

    with get_db() as db:
        row = db.get(DBSession, "s-stale")
        assert row is not None
        assert row.worktree_path is None
        assert row.worktree_branch == info.branch  # branch field preserved


def test_reconcile_preserves_live_session(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-live", project_path=repo)
    with get_db() as db:
        db.add(DBProject(id="proj-live", name="P", path=str(repo)))
        db.add(DBSession(
            id="s-live", model_tier="Medium", system_prompt=[], project_id="proj-live",
            worktree_path=str(info.worktree_path),
            worktree_branch=info.branch,
            base_branch="main",
        ))
    report = reconcile_worktrees()
    assert info.worktree_path.exists()
    assert not report.orphan_dirs_removed
    assert not report.orphan_branches_removed
    assert not report.stale_rows_cleared
