"""End-to-end test that create_session(worktree=True) wires everything up.

Covers: branch creation, worktree directory, seeding, and dispatched
teardown at session deletion.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

pytestmark = pytest.mark.timeout(10)

from hypergolic.db.engine import get_db  # noqa: E402
from hypergolic.db.models import DBProject, DBSession  # noqa: E402
from hypergolic.enums import ModelTier  # noqa: E402
from hypergolic.schemas import Session  # noqa: E402
from hypergolic.sessions.operations import (  # noqa: E402
    create_session,
    delete_session_tree,
)


def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-b", "main", str(path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(path), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(path), "config", "user.name", "t"], check=True)
    (path / "README.md").write_text("readme\n")
    subprocess.run(["git", "-C", str(path), "add", "-A"], check=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True, capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    project = tmp_path / "project"
    project.mkdir()
    _init_repo(project)
    return project


@pytest.fixture
def worktrees_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home / ".hypergolic" / "worktrees"


@pytest.fixture
def project_row(repo: Path) -> str:
    with get_db() as db:
        db.add(DBProject(id="proj-e2e", name="P", path=str(repo)))
    return "proj-e2e"


def test_create_session_without_worktree_has_no_worktree_fields(
    repo: Path, worktrees_home: Path, project_row: str,
) -> None:
    session = create_session(project_id=project_row, model_tier=ModelTier.MEDIUM)
    assert session.worktree_path is None
    assert session.worktree_branch is None
    assert session.base_branch is None
    assert session.working_directory() == repo


def test_create_session_with_worktree_populates_fields(
    repo: Path, worktrees_home: Path, project_row: str,
) -> None:
    session = create_session(
        project_id=project_row, model_tier=ModelTier.MEDIUM, worktree=True,
    )
    assert session.worktree_path is not None
    assert session.worktree_branch is not None
    assert session.worktree_branch.startswith("hyp/")
    assert session.base_branch == "main"
    assert Path(session.worktree_path).exists()
    # working_directory() now returns the worktree path.
    assert session.working_directory() == Path(session.worktree_path)
    # Seeding is scheduled synchronously since no loop is running.
    assert session.worktree_seed_status in ("pending", "ready")

    # DB row persists these fields.
    with get_db() as db:
        row = db.get(DBSession, session.id)
        assert row is not None
        assert row.worktree_path == session.worktree_path
        assert row.worktree_branch == session.worktree_branch


def test_delete_session_tree_removes_worktree_and_branch(
    repo: Path, worktrees_home: Path, project_row: str,
) -> None:
    session: Session = create_session(
        project_id=project_row, model_tier=ModelTier.MEDIUM, worktree=True,
    )
    assert session.worktree_path is not None
    assert session.worktree_branch is not None
    assert Path(session.worktree_path).exists()

    delete_session_tree(session.id)

    assert not Path(session.worktree_path).exists()
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert session.worktree_branch not in branches
