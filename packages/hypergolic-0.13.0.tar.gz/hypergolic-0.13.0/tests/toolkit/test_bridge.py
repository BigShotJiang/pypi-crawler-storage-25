"""Tests for evaluate_toolkit_approval with ApprovalContext."""

from hypergolic.enums import ModelTier
from hypergolic.toolkit.bridge import evaluate_toolkit_approval
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool as ToolkitTool,
    ToolApprovalDecision,
)
from hypergolic.schemas import Session


async def _noop_run(ctx):
    return "ok"


async def _noop_run_with_input(inp, ctx):
    return "ok"


def _session(**overrides: object) -> Session:
    defaults: dict[str, object] = dict(
        id="sess-1",
        model_tier=ModelTier.MEDIUM,
        project_id="proj-1",
        project_path="/tmp/testproject",
        role="generalist",
    )
    defaults.update(overrides)
    return Session.model_validate(defaults)


class SampleInput(InputSchema):
    path: str


def _tool(
    *,
    approval="ALLOW",
    input_schema=None,
    run=_noop_run,
) -> ToolkitTool:
    return ToolkitTool(
        id="t",
        name="T",
        description="d",
        run=run,
        approval=approval,
        input_schema=input_schema,
    )


# ── String approval ──────────────────────────────────────────────────────────────────


def test_string_allow():
    tool = _tool(approval="ALLOW")
    assert evaluate_toolkit_approval(tool, {}).decision == "ALLOW"


def test_string_deny():
    tool = _tool(approval="DENY")
    assert evaluate_toolkit_approval(tool, {}).decision == "DENY"


def test_string_require():
    tool = _tool(approval="REQUIRE_APPROVAL")
    assert evaluate_toolkit_approval(tool, {}).decision == "REQUIRE_APPROVAL"


def test_string_unknown_defaults_require():
    tool = _tool(approval="SOMETHING_ELSE")
    assert evaluate_toolkit_approval(tool, {}).decision == "REQUIRE_APPROVAL"


# ── Callable approval with ApprovalContext ───────────────────────────────


def test_callable_receives_approval_context():
    """Approval callable receives an ApprovalContext with input, session, and active_skill_ids."""
    received = {}

    def approve(ctx: ApprovalContext) -> ToolApprovalDecision:
        received["path"] = ctx.input.path
        received["project"] = ctx.session.project_path
        received["skills"] = ctx.active_skill_ids
        return ToolApprovalDecision(decision="ALLOW")

    tool = _tool(
        approval=approve,
        input_schema=SampleInput,
        run=_noop_run_with_input,
    )
    session = _session(active_skill_ids={"my-skill"})
    result = evaluate_toolkit_approval(tool, {"path": "/foo"}, session)
    assert result.decision == "ALLOW"
    assert received["path"] == "/foo"
    assert received["project"] == "/tmp/testproject"
    assert received["skills"] == {"my-skill"}


def test_callable_input_based_decision():
    """Approval callable can make decisions based on parsed input."""
    def approve(ctx: ApprovalContext) -> ToolApprovalDecision:
        if ctx.input.path.startswith("/safe"):
            return ToolApprovalDecision(decision="ALLOW")
        return ToolApprovalDecision(decision="REQUIRE_APPROVAL")

    tool = _tool(
        approval=approve,
        input_schema=SampleInput,
        run=_noop_run_with_input,
    )
    result = evaluate_toolkit_approval(tool, {"path": "/safe/file.py"}, _session())
    assert result.decision == "ALLOW"

    result = evaluate_toolkit_approval(tool, {"path": "/danger/file.py"}, _session())
    assert result.decision == "REQUIRE_APPROVAL"


def test_callable_skill_gated_deny():
    """Approval callable can deny based on missing active skills."""
    def approve(ctx: ApprovalContext) -> ToolApprovalDecision:
        if "required-skill" not in ctx.active_skill_ids:
            return ToolApprovalDecision(
                decision="DENY",
                reason="Activate 'required-skill' first.",
            )
        return ToolApprovalDecision(decision="ALLOW")

    tool = _tool(
        approval=approve,
        input_schema=SampleInput,
        run=_noop_run_with_input,
    )

    # Without the skill: denied
    result = evaluate_toolkit_approval(tool, {"path": "/foo"}, _session())
    assert result.decision == "DENY"
    assert result.reason == "Activate 'required-skill' first."

    # With the skill: allowed
    result = evaluate_toolkit_approval(
        tool, {"path": "/foo"}, _session(active_skill_ids={"required-skill"}),
    )
    assert result.decision == "ALLOW"


def test_callable_no_input_schema():
    """Callable with no input_schema gets ctx.input=None."""
    received = {}

    def approve(ctx: ApprovalContext) -> ToolApprovalDecision:
        received["input"] = ctx.input
        return ToolApprovalDecision(decision="ALLOW")

    tool = _tool(approval=approve)
    result = evaluate_toolkit_approval(tool, {}, _session())
    assert result.decision == "ALLOW"
    assert received["input"] is None


def test_callable_no_session():
    """When session is None, ctx.session is None and active_skill_ids is empty."""
    received = {}

    def approve(ctx: ApprovalContext) -> ToolApprovalDecision:
        received["session"] = ctx.session
        received["skills"] = ctx.active_skill_ids
        return ToolApprovalDecision(decision="REQUIRE_APPROVAL")

    tool = _tool(
        approval=approve,
        input_schema=SampleInput,
        run=_noop_run_with_input,
    )
    result = evaluate_toolkit_approval(tool, {"path": "/foo"}, session=None)
    assert result.decision == "REQUIRE_APPROVAL"
    assert received["session"] is None
    assert received["skills"] == set()


def test_callable_exception_defaults_require():
    def approve(ctx: ApprovalContext) -> ToolApprovalDecision:
        raise RuntimeError("boom")

    tool = _tool(
        approval=approve,
        input_schema=SampleInput,
        run=_noop_run_with_input,
    )
    result = evaluate_toolkit_approval(tool, {"path": "/foo"}, _session())
    assert result.decision == "REQUIRE_APPROVAL"
