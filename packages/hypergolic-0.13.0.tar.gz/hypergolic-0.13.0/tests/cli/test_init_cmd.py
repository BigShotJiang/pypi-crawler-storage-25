"""Tests for hypergolic.cli.init_cmd — 100% coverage."""

import subprocess
from pathlib import Path
from unittest.mock import patch, MagicMock

import pytest
import typer

from hypergolic.cli import init_cmd
from hypergolic.cli.init_cmd import (
    _initial_git_commit,
    _is_dev_mode,
    _package_base_dir,
    _package_root,
    _package_source_dir,
    _default_shell_configs,
    _run_uv_sync,
    _setup_shell_alias,
    generate_pyproject,
    init,
    init_impl,
    setup_gitignore,
    sync_base,
    sync_ref,
    _REQUIRED_GITIGNORE_ENTRIES,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _make_base(base_dir: Path) -> None:
    """Create a minimal fake base directory."""
    base_dir.mkdir(parents=True, exist_ok=True)
    (base_dir / "main_template.py").write_text("# template\n")
    (base_dir / ".gitignore").write_text("__pycache__/\n")


def _make_source(source_dir: Path) -> None:
    """Create a minimal fake source directory."""
    source_dir.mkdir(parents=True, exist_ok=True)
    (source_dir / "dummy.py").write_text("# source\n")


# ---------------------------------------------------------------------------
# _package_base_dir / _package_source_dir / _package_root
# ---------------------------------------------------------------------------

def test_package_base_dir():
    result = _package_base_dir()
    assert result.name == "base"
    assert result.parent.name == "hypergolic"


def test_package_source_dir():
    result = _package_source_dir()
    assert result.name == "hypergolic"


def test_package_root():
    result = _package_root()
    # Four parents up from init_cmd.py: cli -> hypergolic -> src -> root
    assert result.is_dir()


def test_default_shell_configs():
    configs = _default_shell_configs()
    assert len(configs) == 2
    assert configs[0].name == ".zshrc"
    assert configs[1].name == ".bashrc"


# ---------------------------------------------------------------------------
# _is_dev_mode
# ---------------------------------------------------------------------------

def test_is_dev_mode_false():
    with patch.dict("os.environ", {}, clear=True):
        assert _is_dev_mode() is False


def test_is_dev_mode_true():
    with patch.dict("os.environ", {"HYPERGOLIC_DEV_MODE": "1"}):
        assert _is_dev_mode() is True


def test_is_dev_mode_true_variants():
    for val in ("true", "True", "yes", "YES"):
        with patch.dict("os.environ", {"HYPERGOLIC_DEV_MODE": val}):
            assert _is_dev_mode() is True


def test_is_dev_mode_other_value():
    with patch.dict("os.environ", {"HYPERGOLIC_DEV_MODE": "nope"}):
        assert _is_dev_mode() is False


# ---------------------------------------------------------------------------
# sync_base
# ---------------------------------------------------------------------------

def test_sync_base_copies_tree(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    base_src = tmp_path / "base_src"
    base_src.mkdir()
    (base_src / "file.txt").write_text("hello")

    sync_base(root_dir=root, base_dir=base_src)

    assert (root / "base" / "file.txt").read_text() == "hello"


def test_sync_base_replaces_existing(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    old_base = root / "base"
    old_base.mkdir()
    (old_base / "old.txt").write_text("old")

    base_src = tmp_path / "base_src"
    base_src.mkdir()
    (base_src / "new.txt").write_text("new")

    sync_base(root_dir=root, base_dir=base_src)

    assert not (root / "base" / "old.txt").exists()
    assert (root / "base" / "new.txt").read_text() == "new"


def test_sync_base_noop_when_source_missing(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    sync_base(root_dir=root, base_dir=tmp_path / "nonexistent")
    assert not (root / "base").exists()


# ---------------------------------------------------------------------------
# sync_ref
# ---------------------------------------------------------------------------

def test_sync_ref_copies_tree(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    source = tmp_path / "source"
    source.mkdir()
    (source / "code.py").write_text("# code")

    sync_ref(root_dir=root, source_dir=source)

    assert (root / ".ref" / "code.py").read_text() == "# code"


def test_sync_ref_replaces_existing(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    old_ref = root / ".ref"
    old_ref.mkdir()
    (old_ref / "old.py").write_text("old")

    source = tmp_path / "source"
    source.mkdir()
    (source / "new.py").write_text("new")

    sync_ref(root_dir=root, source_dir=source)

    assert not (root / ".ref" / "old.py").exists()
    assert (root / ".ref" / "new.py").read_text() == "new"


def test_sync_ref_noop_when_source_missing(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    sync_ref(root_dir=root, source_dir=tmp_path / "nonexistent")
    assert not (root / ".ref").exists()


# ---------------------------------------------------------------------------
# setup_gitignore
# ---------------------------------------------------------------------------

def test_setup_gitignore_copies_from_base(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    base = root / "base"
    base.mkdir()
    (base / ".gitignore").write_text("*.pyc\nmcp_tokens/\n")

    setup_gitignore(root_dir=root)

    assert (root / ".gitignore").read_text() == "*.pyc\nmcp_tokens/\n"


def test_setup_gitignore_noop_when_no_base(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    # No base/.gitignore exists
    setup_gitignore(root_dir=root)
    assert not (root / ".gitignore").exists()


def test_setup_gitignore_appends_missing_entries(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    (root / ".gitignore").write_text("*.pyc\n")

    setup_gitignore(root_dir=root)

    content = (root / ".gitignore").read_text()
    for entry in _REQUIRED_GITIGNORE_ENTRIES:
        assert entry in content
    assert "# Added by hypergolic update" in content


def test_setup_gitignore_no_append_when_entries_present(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    required = "".join(f"{entry}\n" for entry in _REQUIRED_GITIGNORE_ENTRIES)
    original = f"*.pyc\n{required}"
    (root / ".gitignore").write_text(original)

    setup_gitignore(root_dir=root)

    # Content should be unchanged — no append
    assert (root / ".gitignore").read_text() == original


def test_required_gitignore_entries_include_worktree_and_db_sidecars():
    """Guard against regressions: worktrees/ and SQLite WAL sidecars must be ignored
    so the My Toolkit project doesn't show them as untracked."""
    assert "worktrees/" in _REQUIRED_GITIGNORE_ENTRIES
    assert "*.db-shm" in _REQUIRED_GITIGNORE_ENTRIES
    assert "*.db-wal" in _REQUIRED_GITIGNORE_ENTRIES


# ---------------------------------------------------------------------------
# generate_pyproject
# ---------------------------------------------------------------------------

def test_generate_pyproject_creates_new(tmp_path):
    root = tmp_path / "home"
    root.mkdir()

    with patch.dict("os.environ", {}, clear=True):
        generate_pyproject(root_dir=root)

    content = (root / "pyproject.toml").read_text()
    assert "my-hypergolic" in content
    assert "hypergolic>=" in content


def test_generate_pyproject_updates_existing(tmp_path):
    root = tmp_path / "home"
    root.mkdir()
    (root / "pyproject.toml").write_text(
        '[project]\nname = "my-hypergolic"\ndependencies = ["hypergolic>=0.1.0"]\n'
    )

    with patch.dict("os.environ", {}, clear=True):
        generate_pyproject(root_dir=root)

    content = (root / "pyproject.toml").read_text()
    assert "hypergolic>=0.1.0" not in content or content.count("hypergolic>=") == 1


def test_generate_pyproject_dev_mode(tmp_path):
    root = tmp_path / "home"
    root.mkdir()

    with patch.dict("os.environ", {"HYPERGOLIC_DEV_MODE": "1"}):
        generate_pyproject(root_dir=root)

    content = (root / "pyproject.toml").read_text()
    assert "editable = true" in content
    assert "[tool.uv.sources]" in content


# ---------------------------------------------------------------------------
# _initial_git_commit
# ---------------------------------------------------------------------------

def test_initial_git_commit_inits_and_commits(tmp_path):
    d = tmp_path / "repo"
    d.mkdir()
    (d / "file.txt").write_text("content")

    with patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run:
        # git init, git add, git diff --cached --quiet (return non-zero), git commit
        mock_run.side_effect = [
            MagicMock(),  # git init
            MagicMock(),  # git add -A
            MagicMock(returncode=1),  # git diff --cached --quiet -> changes staged
            MagicMock(),  # git commit
        ]
        _initial_git_commit(d)

    assert mock_run.call_count == 4
    assert mock_run.call_args_list[0][0][0] == ["git", "init"]
    assert mock_run.call_args_list[3][0][0][0:3] == ["git", "commit", "-m"]


def test_initial_git_commit_skips_init_when_git_exists(tmp_path):
    d = tmp_path / "repo"
    d.mkdir()
    (d / ".git").mkdir()  # Simulate existing git repo

    with patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run:
        mock_run.side_effect = [
            MagicMock(),  # git add -A
            MagicMock(returncode=0),  # git diff --cached --quiet -> nothing staged
        ]
        _initial_git_commit(d)

    # Should NOT call git init
    assert mock_run.call_count == 2
    assert mock_run.call_args_list[0][0][0] == ["git", "add", "-A"]


def test_initial_git_commit_no_commit_when_clean(tmp_path):
    d = tmp_path / "repo"
    d.mkdir()

    with patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run:
        mock_run.side_effect = [
            MagicMock(),  # git init
            MagicMock(),  # git add -A
            MagicMock(returncode=0),  # git diff --cached --quiet -> clean
        ]
        _initial_git_commit(d)

    assert mock_run.call_count == 3


# ---------------------------------------------------------------------------
# _run_uv_sync
# ---------------------------------------------------------------------------

def test_run_uv_sync_success(tmp_path):
    with patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=0, stderr="")
        _run_uv_sync(root_dir=tmp_path)
    mock_run.assert_called_once_with(
        ["uv", "sync"], cwd=tmp_path, capture_output=True, text=True
    )


def test_run_uv_sync_failure_prints_warning(tmp_path):
    with patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(returncode=1, stderr="some error")
        _run_uv_sync(root_dir=tmp_path)  # Should not raise


# ---------------------------------------------------------------------------
# _setup_shell_alias
# ---------------------------------------------------------------------------

def test_setup_shell_alias_adds_to_existing_config_confirmed(tmp_path):
    zshrc = tmp_path / ".zshrc"
    zshrc.write_text("# existing config\n")

    with patch("typer.confirm", return_value=True):
        _setup_shell_alias(root_dir=tmp_path, shell_configs=[zshrc])

    content = zshrc.read_text()
    assert "alias h=" in content
    assert "# Hypergolic" in content


def test_setup_shell_alias_adds_to_existing_config_declined(tmp_path):
    zshrc = tmp_path / ".zshrc"
    zshrc.write_text("# existing config\n")

    with patch("typer.confirm", return_value=False):
        _setup_shell_alias(root_dir=tmp_path, shell_configs=[zshrc])

    # File should be unchanged — user declined
    assert "alias h=" not in zshrc.read_text()


def test_setup_shell_alias_updates_existing_alias_confirmed(tmp_path):
    zshrc = tmp_path / ".zshrc"
    zshrc.write_text("alias h='old value'\n")

    with patch("typer.confirm", return_value=True):
        _setup_shell_alias(root_dir=tmp_path, shell_configs=[zshrc])

    content = zshrc.read_text()
    assert "old value" not in content
    assert "uv run" in content


def test_setup_shell_alias_updates_existing_alias_declined(tmp_path):
    zshrc = tmp_path / ".zshrc"
    zshrc.write_text("alias h='old value'\n")

    with patch("typer.confirm", return_value=False):
        _setup_shell_alias(root_dir=tmp_path, shell_configs=[zshrc])

    # File should be unchanged — user declined
    assert "old value" in zshrc.read_text()


def test_setup_shell_alias_same_alias_no_prompt(tmp_path):
    """When alias is already up-to-date, no confirm prompt and no write."""
    root = tmp_path / "home"
    root.mkdir()
    alias_line = f"alias h='uv run {root / 'main.py'}'"
    zshrc = tmp_path / ".zshrc"
    zshrc.write_text(f"{alias_line}\n")

    with patch("typer.confirm") as mock_confirm:
        _setup_shell_alias(root_dir=root, shell_configs=[zshrc])

    mock_confirm.assert_not_called()
    assert zshrc.read_text() == f"{alias_line}\n"


def test_setup_shell_alias_skips_missing_configs(tmp_path):
    # No config files exist — should print fallback message
    missing = tmp_path / ".zshrc"
    _setup_shell_alias(root_dir=tmp_path, shell_configs=[missing])
    # No crash; fallback message printed


def test_setup_shell_alias_no_configs_at_all(tmp_path):
    _setup_shell_alias(root_dir=tmp_path, shell_configs=[])
    # No crash; "Could not find shell config" printed


def test_setup_shell_alias_picks_first_existing(tmp_path):
    zshrc = tmp_path / ".zshrc"
    bashrc = tmp_path / ".bashrc"
    zshrc.write_text("# zsh\n")
    bashrc.write_text("# bash\n")

    with patch("typer.confirm", return_value=True):
        _setup_shell_alias(root_dir=tmp_path, shell_configs=[zshrc, bashrc])

    # Should modify zshrc only (returns after first match)
    assert "alias h=" in zshrc.read_text()
    assert "alias h=" not in bashrc.read_text()


# ---------------------------------------------------------------------------
# init_impl (full integration)
# ---------------------------------------------------------------------------

def test_init_impl_fresh_directory(tmp_path):
    root = tmp_path / "toolkit"
    base_dir = tmp_path / "base_src"
    source_dir = tmp_path / "source_src"
    _make_base(base_dir)
    _make_source(source_dir)
    zshrc = tmp_path / ".zshrc"
    zshrc.write_text("# shell\n")

    with (
        patch("hypergolic.cli.init_cmd._run_uv_sync"),
        patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run,
        patch("typer.confirm", return_value=True),
    ):
        mock_run.side_effect = [
            MagicMock(),  # git init
            MagicMock(),  # git add -A
            MagicMock(returncode=1),  # git diff --cached --quiet
            MagicMock(),  # git commit
        ]
        init_impl(
            root_dir=root,
            base_dir=base_dir,
            source_dir=source_dir,
            shell_configs=[zshrc],
        )

    # Directory structure created
    assert (root / "prompts" / "roles").is_dir()
    assert (root / "prompts" / "skills").is_dir()
    assert (root / "projects").is_dir()
    # main.py copied from template
    assert (root / "main.py").exists()
    # base synced
    assert (root / "base" / "main_template.py").exists()
    # ref synced
    assert (root / ".ref" / "dummy.py").exists()
    # gitignore copied
    assert (root / ".gitignore").exists()
    # pyproject created
    assert (root / "pyproject.toml").exists()
    # shell alias added
    assert "alias h=" in zshrc.read_text()


def test_init_impl_existing_directory_confirm_yes(tmp_path):
    root = tmp_path / "toolkit"
    root.mkdir()  # Pre-existing
    base_dir = tmp_path / "base_src"
    source_dir = tmp_path / "source_src"
    _make_base(base_dir)
    _make_source(source_dir)

    with (
        patch("typer.confirm", return_value=True),
        patch("hypergolic.cli.init_cmd._run_uv_sync"),
        patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run,
    ):
        mock_run.side_effect = [
            MagicMock(),  # git init
            MagicMock(),  # git add -A
            MagicMock(returncode=0),  # clean
        ]
        init_impl(
            root_dir=root,
            base_dir=base_dir,
            source_dir=source_dir,
            shell_configs=[],
        )

    assert (root / "base").is_dir()


def test_init_impl_existing_directory_confirm_no(tmp_path):
    root = tmp_path / "toolkit"
    root.mkdir()  # Pre-existing
    base_dir = tmp_path / "base_src"
    source_dir = tmp_path / "source_src"
    _make_base(base_dir)
    _make_source(source_dir)

    with (
        patch("typer.confirm", return_value=False),
        pytest.raises(typer.Exit),
    ):
        init_impl(
            root_dir=root,
            base_dir=base_dir,
            source_dir=source_dir,
            shell_configs=[],
        )


def test_init_impl_main_py_already_exists(tmp_path):
    root = tmp_path / "toolkit"
    root.mkdir()
    (root / "main.py").write_text("# existing\n")
    base_dir = tmp_path / "base_src"
    source_dir = tmp_path / "source_src"
    _make_base(base_dir)
    _make_source(source_dir)

    with (
        patch("typer.confirm", return_value=True),
        patch("hypergolic.cli.init_cmd._run_uv_sync"),
        patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run,
    ):
        mock_run.side_effect = [
            MagicMock(),
            MagicMock(),
            MagicMock(returncode=0),
        ]
        init_impl(
            root_dir=root,
            base_dir=base_dir,
            source_dir=source_dir,
            shell_configs=[],
        )

    # main.py should NOT be overwritten
    assert (root / "main.py").read_text() == "# existing\n"


def test_init_impl_no_template(tmp_path):
    """init_impl when base_dir has no main_template.py."""
    root = tmp_path / "toolkit"
    base_dir = tmp_path / "base_src"
    base_dir.mkdir()
    # No main_template.py
    (base_dir / ".gitignore").write_text("*.pyc\nmcp_tokens/\n")
    source_dir = tmp_path / "source_src"
    _make_source(source_dir)

    with (
        patch("hypergolic.cli.init_cmd._run_uv_sync"),
        patch("hypergolic.cli.init_cmd.subprocess.run") as mock_run,
    ):
        mock_run.side_effect = [
            MagicMock(),
            MagicMock(),
            MagicMock(returncode=0),
        ]
        init_impl(
            root_dir=root,
            base_dir=base_dir,
            source_dir=source_dir,
            shell_configs=[],
        )

    # main.py should NOT be created (no template)
    assert not (root / "main.py").exists()


# ---------------------------------------------------------------------------
# init() (thin wrapper)
# ---------------------------------------------------------------------------

def test_init_delegates_to_init_impl():
    with patch("hypergolic.cli.init_cmd.init_impl") as mock_impl:
        init()
    mock_impl.assert_called_once()
    kwargs = mock_impl.call_args[1]
    assert "root_dir" in kwargs
    assert "base_dir" in kwargs
    assert "source_dir" in kwargs
    assert "shell_configs" in kwargs
