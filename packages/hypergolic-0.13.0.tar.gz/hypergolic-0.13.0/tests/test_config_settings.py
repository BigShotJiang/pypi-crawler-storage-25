"""Tests for hypergolic.config.settings."""

from pathlib import Path
from unittest.mock import patch

import pytest

from hypergolic.config.settings import Settings, settings


# ---------------------------------------------------------------------------
# Settings defaults (using fresh instances with cleared env)
# ---------------------------------------------------------------------------


def test_settings_is_singleton_instance():
    """The module-level `settings` is a Settings instance."""
    assert isinstance(settings, Settings)


def test_settings_default_api_key():
    with patch.dict("os.environ", {}, clear=True):
        s = Settings()
    assert s.HYPERGOLIC_API_KEY == ""


def test_settings_default_base_url():
    with patch.dict("os.environ", {}, clear=True):
        s = Settings()
    assert s.HYPERGOLIC_BASE_URL == "https://api.anthropic.com"


def test_settings_default_max_tokens():
    with patch.dict("os.environ", {}, clear=True):
        s = Settings()
    assert s.MAX_TOKENS == 64000


def test_settings_default_database_url_contains_hypergolic():
    with patch.dict("os.environ", {}, clear=True):
        s = Settings()
    assert "hypergolic" in s.HYPERGOLIC_DATABASE_URL


# ---------------------------------------------------------------------------
# Settings overrides via environment variables
# ---------------------------------------------------------------------------


def test_settings_api_key_from_env():
    with patch.dict("os.environ", {"HYPERGOLIC_API_KEY": "sk-test-key"}):
        s = Settings()
    assert s.HYPERGOLIC_API_KEY == "sk-test-key"


def test_settings_base_url_from_env():
    with patch.dict("os.environ", {"HYPERGOLIC_BASE_URL": "https://custom.api.com"}):
        s = Settings()
    assert s.HYPERGOLIC_BASE_URL == "https://custom.api.com"


def test_settings_database_url_from_env():
    with patch.dict("os.environ", {"HYPERGOLIC_DATABASE_URL": "sqlite:///:memory:"}):
        s = Settings()
    assert s.HYPERGOLIC_DATABASE_URL == "sqlite:///:memory:"


def test_settings_max_tokens_from_env():
    with patch.dict("os.environ", {"MAX_TOKENS": "8192"}):
        s = Settings()
    assert s.MAX_TOKENS == 8192


# ---------------------------------------------------------------------------
# PROMPTS_DIR
# ---------------------------------------------------------------------------


def test_prompts_dir_is_path():
    from hypergolic.config.settings import PROMPTS_DIR
    assert isinstance(PROMPTS_DIR, Path)


def test_prompts_dir_points_to_base_prompts():
    from hypergolic.config.settings import PROMPTS_DIR
    assert PROMPTS_DIR.name == "prompts"
    assert PROMPTS_DIR.parent.name == "base"
