"""Tests for hypergolic.messages.conversation.interrupts."""

from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from anthropic.types import Message, TextBlock, ToolUseBlock, Usage

from hypergolic.messages.conversation.interrupts import (
    _build_interrupt_tool_results,
    _extract_partial_text,
    _persist_partial_assistant_message,
    persist_interrupt_tool_results,
)
from hypergolic.messages.types import INTERRUPTED_SUFFIX
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from sqlalchemy import select
from tests.conftest import make_project, make_session


def _make_message(
    content: Any = None,
    stop_reason: Any = "end_turn",
) -> Message:
    if content is None:
        content = [TextBlock(type="text", text="hello")]
    return Message(
        id="msg-1",
        content=cast(Any, content),
        model="claude-sonnet-4-20250514",
        role="assistant",
        stop_reason=stop_reason,
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=5, output_tokens=10),
    )


# ---------------------------------------------------------------------------
# _extract_partial_text
# ---------------------------------------------------------------------------


def test_extract_partial_text_with_text_block():
    stream = MagicMock()
    snapshot = MagicMock()
    block = MagicMock()
    block.type = "text"
    block.text = "partial response"
    snapshot.content = [block]
    stream.current_message_snapshot = snapshot

    result = _extract_partial_text(stream)
    assert result == "partial response"


def test_extract_partial_text_multiple_text_blocks():
    stream = MagicMock()
    snapshot = MagicMock()
    block1 = MagicMock()
    block1.type = "text"
    block1.text = "first"
    block2 = MagicMock()
    block2.type = "text"
    block2.text = "second"
    snapshot.content = [block1, block2]
    stream.current_message_snapshot = snapshot

    result = _extract_partial_text(stream)
    assert result == "first\n\nsecond"


def test_extract_partial_text_no_text_blocks():
    """Snapshot with only non-text blocks returns None."""
    stream = MagicMock()
    snapshot = MagicMock()
    block = MagicMock()
    block.type = "tool_use"
    block.text = None
    snapshot.content = [block]
    stream.current_message_snapshot = snapshot

    result = _extract_partial_text(stream)
    assert result is None


def test_extract_partial_text_empty_snapshot():
    """Snapshot with empty content returns None."""
    stream = MagicMock()
    snapshot = MagicMock()
    snapshot.content = []
    stream.current_message_snapshot = snapshot

    result = _extract_partial_text(stream)
    assert result is None


def test_extract_partial_text_none_snapshot():
    """Snapshot is None returns None."""
    stream = MagicMock()
    stream.current_message_snapshot = None

    result = _extract_partial_text(stream)
    assert result is None


def test_extract_partial_text_stream_raises_exception():
    """If accessing current_message_snapshot raises an exception, return None."""
    stream = MagicMock()
    type(stream).current_message_snapshot = property(lambda self: (_ for _ in ()).throw(RuntimeError("stream error")))

    result = _extract_partial_text(stream)
    assert result is None


# ---------------------------------------------------------------------------
# _persist_partial_assistant_message
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_persist_partial_assistant_message_creates_db_entry():
    make_project()
    session_id = make_session()

    await _persist_partial_assistant_message(session_id, "partial text")

    with get_db() as db:
        rows = db.execute(
            select(DBMessage).where(DBMessage.session_id == session_id)
        ).scalars().all()

    assert len(rows) == 1
    msg = rows[0]
    assert msg.role == "assistant"
    assert msg.stop_reason == "interrupted"
    assert len(msg.content) == 1
    assert msg.content[0]["type"] == "text"
    assert INTERRUPTED_SUFFIX in msg.content[0]["text"]
    assert "partial text" in msg.content[0]["text"]


# ---------------------------------------------------------------------------
# _build_interrupt_tool_results
# ---------------------------------------------------------------------------


def test_build_interrupt_tool_results_with_tool_use_blocks():
    response = _make_message(
        content=[
            TextBlock(type="text", text="thinking..."),
            ToolUseBlock(type="tool_use", id="tu-1", name="read_files", input={"paths": ["a.py"]}),
            ToolUseBlock(type="tool_use", id="tu-2", name="write_files", input={"files": []}),
        ]
    )

    result = _build_interrupt_tool_results(response)
    assert result is not None
    assert result["role"] == "user"
    content = cast(list[dict[str, Any]], result["content"])
    assert len(content) == 2
    assert content[0]["type"] == "tool_result"
    assert content[0]["tool_use_id"] == "tu-1"
    assert content[0]["is_error"] is True
    assert content[1]["tool_use_id"] == "tu-2"


def test_build_interrupt_tool_results_without_tool_use_blocks():
    response = _make_message(
        content=[TextBlock(type="text", text="just text")]
    )

    result = _build_interrupt_tool_results(response)
    assert result is None


def test_build_interrupt_tool_results_tool_result_content():
    """The interrupt tool result content says 'Interrupted by user'."""
    response = _make_message(
        content=[
            ToolUseBlock(type="tool_use", id="tu-abc", name="my_tool", input={}),
        ]
    )

    result = _build_interrupt_tool_results(response)
    assert result is not None
    content = cast(list[dict[str, Any]], result["content"])
    inner = cast(list[dict[str, Any]], content[0]["content"])
    assert inner[0]["text"] == "Interrupted by user"


# ---------------------------------------------------------------------------
# persist_interrupt_tool_results
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_persist_interrupt_tool_results_calls_persist_when_tool_blocks():
    """When response has tool_use blocks, persist_user_message is called."""
    make_project()
    session_id = make_session()

    response = _make_message(
        content=[
            ToolUseBlock(type="tool_use", id="tu-1", name="read_files", input={}),
        ]
    )

    with patch(
        "hypergolic.messages.conversation.interrupts.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await persist_interrupt_tool_results(session_id, response)

    mock_persist.assert_awaited_once()
    call_kwargs = mock_persist.call_args[1]
    assert call_kwargs["session_id"] == session_id


@pytest.mark.asyncio
async def test_persist_interrupt_tool_results_no_call_when_no_tool_blocks():
    """When response has no tool_use blocks, persist_user_message is NOT called."""
    make_project()
    session_id = make_session()

    response = _make_message(
        content=[TextBlock(type="text", text="no tools here")]
    )

    with patch(
        "hypergolic.messages.conversation.interrupts.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await persist_interrupt_tool_results(session_id, response)

    mock_persist.assert_not_awaited()
