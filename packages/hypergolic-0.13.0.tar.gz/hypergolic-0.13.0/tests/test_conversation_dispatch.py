"""Tests for hypergolic.messages.conversation.dispatch."""

import asyncio
from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from anthropic.types import Message, TextBlock, Usage

from hypergolic.enums import ModelTier
from hypergolic.messages.conversation.dispatch import (
    broadcast_response,
    dispatch_stop_reason,
)
from hypergolic.messages.types import BroadcastEvent, UserInterrupt
from hypergolic.schemas import Session


def _make_session(**overrides: Any) -> Session:
    defaults: dict[str, Any] = dict(
        id="sess-1",
        model_tier=ModelTier.LOW,
        project_id="proj-1",
        project_path="/tmp/test",
        role="generalist",
    )
    defaults.update(overrides)
    return Session(**defaults)


def _make_response(stop_reason: Any = "end_turn", text: str = "hello") -> Message:
    return Message(
        id="msg-1",
        content=[TextBlock(type="text", text=text)],
        model="claude-sonnet-4-20250514",
        role="assistant",
        stop_reason=stop_reason,
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=10, output_tokens=20),
    )


# ---------------------------------------------------------------------------
# broadcast_response
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_broadcast_response():
    response = _make_response()
    broadcast = AsyncMock()

    await broadcast_response(response, "sess-1", broadcast)

    broadcast.assert_awaited_once()
    event: BroadcastEvent = broadcast.call_args[0][0]
    assert event.type == "assistant_message"
    assert event.role == "assistant"
    assert event.session_id == "sess-1"
    assert event.model == "claude-sonnet-4-20250514"
    assert event.stop_reason == "end_turn"
    assert event.message_id == "msg-1"
    assert event.usage is not None
    assert event.usage["input_tokens"] == 10
    assert event.usage["output_tokens"] == 20


@pytest.mark.asyncio
async def test_broadcast_response_no_usage():
    response = _make_response()
    response.__dict__["usage"] = None
    broadcast = AsyncMock()

    await broadcast_response(response, "sess-1", broadcast)

    event: BroadcastEvent = broadcast.call_args[0][0]
    assert event.usage is None


@pytest.mark.asyncio
async def test_broadcast_response_with_tool_display_names():
    response = _make_response()
    broadcast = AsyncMock()
    tool_names = {"tool-1": "My Tool"}

    await broadcast_response(response, "sess-1", broadcast, tool_names)

    broadcast.assert_awaited_once()


# ---------------------------------------------------------------------------
# dispatch_stop_reason — end_turn
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_end_turn():
    response = _make_response(stop_reason="end_turn")
    session = _make_session()
    broadcast = AsyncMock()

    await dispatch_stop_reason(
        "end_turn", response, [], session, broadcast,
        None, MagicMock(), MagicMock(),
    )

    # Should just broadcast the response, nothing else
    broadcast.assert_awaited_once()


# ---------------------------------------------------------------------------
# dispatch_stop_reason — tool_use
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_tool_use():
    response = _make_response(stop_reason="tool_use")
    session = _make_session()
    broadcast = AsyncMock()
    refresh_tools = MagicMock()

    mock_result = MagicMock()
    mock_result.message = {"content": [], "role": "user"}
    mock_result.should_truncate = False

    with patch(
        "hypergolic.messages.conversation.dispatch.handle_tool_use_stop",
        new=AsyncMock(return_value=mock_result),
    ) as mock_handle:
        await dispatch_stop_reason(
            "tool_use", response, ["tool1"], session, broadcast,
            None, MagicMock(), refresh_tools,
        )

    mock_handle.assert_awaited_once()
    refresh_tools.assert_called_once()


# ---------------------------------------------------------------------------
# dispatch_stop_reason — max_tokens / pause_turn
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_max_tokens():
    response = _make_response(stop_reason="max_tokens")
    session = _make_session()
    broadcast = AsyncMock()
    refresh_tools = MagicMock()

    with patch(
        "hypergolic.messages.conversation.dispatch.handle_continue",
        new=AsyncMock(),
    ) as mock_handle:
        await dispatch_stop_reason(
            "max_tokens", response, [], session, broadcast,
            None, MagicMock(), refresh_tools,
        )

    mock_handle.assert_awaited_once()
    assert mock_handle.call_args[0][0] == "max_tokens"
    assert mock_handle.call_args[1]["response"] is response
    refresh_tools.assert_not_called()


@pytest.mark.asyncio
async def test_dispatch_pause_turn():
    response = _make_response(stop_reason="pause_turn")
    session = _make_session()
    broadcast = AsyncMock()
    refresh_tools = MagicMock()

    with patch(
        "hypergolic.messages.conversation.dispatch.handle_continue",
        new=AsyncMock(),
    ) as mock_handle:
        await dispatch_stop_reason(
            "pause_turn", response, [], session, broadcast,
            None, MagicMock(), refresh_tools,
        )

    mock_handle.assert_awaited_once()
    assert mock_handle.call_args[0][0] == "pause_turn"
    assert mock_handle.call_args[1]["response"] is response
    refresh_tools.assert_not_called()


# ---------------------------------------------------------------------------
# dispatch_stop_reason — unhandled
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_unhandled_stop_reason():
    response = _make_response(stop_reason="end_turn")
    session = _make_session()
    broadcast = AsyncMock()

    from anthropic.types import StopReason
    weird_reason = cast(StopReason, "weird_reason")
    with pytest.raises(Exception, match="Unhandled stop reason: weird_reason"):
        await dispatch_stop_reason(
            weird_reason, response, [], session, broadcast,
            None, MagicMock(), MagicMock(),
        )


# ---------------------------------------------------------------------------
# dispatch_stop_reason — interrupt during tool_use
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_tool_use_interrupted():
    response = _make_response(stop_reason="tool_use")
    session = _make_session()
    broadcast = AsyncMock()

    with (
        patch(
            "hypergolic.messages.conversation.dispatch.handle_tool_use_stop",
            new=AsyncMock(side_effect=UserInterrupt()),
        ),
        patch(
            "hypergolic.messages.conversation.dispatch.persist_interrupt_tool_results",
            new=AsyncMock(),
        ) as mock_persist_interrupt,
    ):
        with pytest.raises(UserInterrupt):
            await dispatch_stop_reason(
                "tool_use", response, [], session, broadcast,
                None, MagicMock(), MagicMock(),
            )

    mock_persist_interrupt.assert_awaited_once_with(session.id, response)


@pytest.mark.asyncio
async def test_dispatch_tool_use_cancelled():
    response = _make_response(stop_reason="tool_use")
    session = _make_session()
    broadcast = AsyncMock()

    with (
        patch(
            "hypergolic.messages.conversation.dispatch.handle_tool_use_stop",
            new=AsyncMock(side_effect=asyncio.CancelledError()),
        ),
        patch(
            "hypergolic.messages.conversation.dispatch.persist_interrupt_tool_results",
            new=AsyncMock(),
        ) as mock_persist_interrupt,
    ):
        with pytest.raises(UserInterrupt):
            await dispatch_stop_reason(
                "tool_use", response, [], session, broadcast,
                None, MagicMock(), MagicMock(),
            )

    mock_persist_interrupt.assert_awaited_once_with(session.id, response)


@pytest.mark.asyncio
async def test_dispatch_tool_use_exception_persists_interrupt():
    response = _make_response(stop_reason="tool_use")
    session = _make_session()
    broadcast = AsyncMock()

    with (
        patch(
            "hypergolic.messages.conversation.dispatch.handle_tool_use_stop",
            new=AsyncMock(side_effect=RuntimeError("boom")),
        ),
        patch(
            "hypergolic.messages.conversation.dispatch.persist_interrupt_tool_results",
            new=AsyncMock(),
        ) as mock_persist_interrupt,
    ):
        with pytest.raises(RuntimeError, match="boom"):
            await dispatch_stop_reason(
                "tool_use", response, [], session, broadcast,
                None, MagicMock(), MagicMock(),
            )

    mock_persist_interrupt.assert_awaited_once_with(session.id, response)


# ---------------------------------------------------------------------------
# dispatch_stop_reason — interrupt during non-tool_use does NOT persist
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_dispatch_end_turn_interrupted_no_persist():
    response = _make_response(stop_reason="end_turn")
    session = _make_session()
    broadcast = AsyncMock(side_effect=UserInterrupt())

    with patch(
        "hypergolic.messages.conversation.dispatch.persist_interrupt_tool_results",
        new=AsyncMock(),
    ) as mock_persist_interrupt:
        with pytest.raises(UserInterrupt):
            await dispatch_stop_reason(
                "end_turn", response, [], session, broadcast,
                None, MagicMock(), MagicMock(),
            )

    mock_persist_interrupt.assert_not_awaited()


@pytest.mark.asyncio
async def test_dispatch_max_tokens_interrupted_no_persist():
    response = _make_response(stop_reason="max_tokens")
    session = _make_session()
    broadcast = AsyncMock()

    with (
        patch(
            "hypergolic.messages.conversation.dispatch.handle_continue",
            new=AsyncMock(side_effect=UserInterrupt()),
        ),
        patch(
            "hypergolic.messages.conversation.dispatch.persist_interrupt_tool_results",
            new=AsyncMock(),
        ) as mock_persist_interrupt,
    ):
        with pytest.raises(UserInterrupt):
            await dispatch_stop_reason(
                "max_tokens", response, [], session, broadcast,
                None, MagicMock(), MagicMock(),
            )

    mock_persist_interrupt.assert_not_awaited()


@pytest.mark.asyncio
async def test_dispatch_max_tokens_exception_no_persist():
    """Non-tool_use exception path should not persist interrupt tool results."""
    response = _make_response(stop_reason="max_tokens")
    session = _make_session()
    broadcast = AsyncMock()

    with (
        patch(
            "hypergolic.messages.conversation.dispatch.handle_continue",
            new=AsyncMock(side_effect=RuntimeError("oops")),
        ),
        patch(
            "hypergolic.messages.conversation.dispatch.persist_interrupt_tool_results",
            new=AsyncMock(),
        ) as mock_persist_interrupt,
    ):
        with pytest.raises(RuntimeError, match="oops"):
            await dispatch_stop_reason(
                "max_tokens", response, [], session, broadcast,
                None, MagicMock(), MagicMock(),
            )

    mock_persist_interrupt.assert_not_awaited()
