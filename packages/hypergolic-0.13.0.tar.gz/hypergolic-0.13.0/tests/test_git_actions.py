"""Tests for git/actions.py."""

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

from hypergolic.git.actions import (
    _current_branch,
    _has_upstream,
    git_commit,
    git_discard,
    git_pull,
    git_push,
    git_stage,
    git_unstage,
)
from hypergolic.git.commands import GitCommandError


def _ok(stdout=""):
    return subprocess.CompletedProcess([], 0, stdout=stdout, stderr="")


def _fail(stderr="err"):
    return subprocess.CompletedProcess([], 1, stdout="", stderr=stderr)


# ── git_stage ──────────────────────────────────────────────────────


def test_git_stage_success(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok()) as mock:
        git_stage(["a.py"], repo=tmp_path)
    mock.assert_called_once_with("add", "--", "a.py", cwd=tmp_path, check=True)


def test_git_stage_error(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", side_effect=GitCommandError("add", 1, "err")):
        with pytest.raises(GitCommandError):
            git_stage(["bad.py"], repo=tmp_path)


# ── git_unstage ────────────────────────────────────────────────────


def test_git_unstage_success(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok()) as mock:
        git_unstage(["a.py"], repo=tmp_path)
    mock.assert_called_once_with("reset", "HEAD", "--", "a.py", cwd=tmp_path, check=True)


# ── git_discard ────────────────────────────────────────────────────


def test_git_discard_success(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok()) as mock:
        git_discard(["a.py"], repo=tmp_path)
    mock.assert_called_once_with("checkout", "--", "a.py", cwd=tmp_path, check=True)


# ── git_commit ─────────────────────────────────────────────────────


def test_git_commit_success(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok("[main abc1234] fix\n")):
        result = git_commit("fix", repo=tmp_path)
    assert result == "[main abc1234] fix"


# ── _current_branch ────────────────────────────────────────────────


def test_current_branch_named(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok("feature\n")):
        assert _current_branch(tmp_path) == "feature"


def test_current_branch_detached(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok("\n")):
        assert _current_branch(tmp_path) == "HEAD"


# ── git_push ───────────────────────────────────────────────────────


def test_git_push_stdout(tmp_path):
    call_count = 0

    def mock_run(*args, cwd=None, check=False):
        nonlocal call_count
        call_count += 1
        if call_count == 1:  # branch --show-current
            return _ok("main\n")
        return _ok("pushed ok\n")

    with patch("hypergolic.git.actions.run_git_command", side_effect=mock_run):
        assert git_push(repo=tmp_path) == "pushed ok"


def test_git_push_stderr_fallback(tmp_path):
    call_count = 0

    def mock_run(*args, cwd=None, check=False):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return _ok("main\n")
        return subprocess.CompletedProcess([], 0, stdout="", stderr="remote info")

    with patch("hypergolic.git.actions.run_git_command", side_effect=mock_run):
        assert git_push(repo=tmp_path) == "remote info"


# ── _has_upstream ───────────────────────────────────────────────────


def test_has_upstream_true(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_ok()):
        assert _has_upstream(tmp_path) is True


def test_has_upstream_false(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_fail()):
        assert _has_upstream(tmp_path) is False


# ── git_pull ───────────────────────────────────────────────────────


def test_git_pull_success(tmp_path):
    call_count = 0

    def mock_run(*args, cwd=None, check=False):
        nonlocal call_count
        call_count += 1
        if call_count == 1:  # _has_upstream check
            return _ok()
        return _ok("Already up to date.\n")

    with patch("hypergolic.git.actions.run_git_command", side_effect=mock_run):
        assert git_pull(repo=tmp_path) == "Already up to date."


def test_git_pull_no_upstream(tmp_path):
    with patch("hypergolic.git.actions.run_git_command", return_value=_fail()):
        result = git_pull(repo=tmp_path)
    assert "No upstream" in result


def test_git_pull_stderr_fallback(tmp_path):
    call_count = 0

    def mock_run(*args, cwd=None, check=False):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return _ok()
        return subprocess.CompletedProcess([], 0, stdout="", stderr="From remote\n")

    with patch("hypergolic.git.actions.run_git_command", side_effect=mock_run):
        assert git_pull(repo=tmp_path) == "From remote"


# ── default repo fallbacks ──────────────────────────────────────────


def test_stage_default_repo():
    with (
        patch("hypergolic.git.actions.git_repo_root", return_value=Path("/r")),
        patch("hypergolic.git.actions.run_git_command", return_value=_ok()),
    ):
        git_stage(["x"])


def test_unstage_default_repo():
    with (
        patch("hypergolic.git.actions.git_repo_root", return_value=Path("/r")),
        patch("hypergolic.git.actions.run_git_command", return_value=_ok()),
    ):
        git_unstage(["x"])


def test_discard_default_repo():
    with (
        patch("hypergolic.git.actions.git_repo_root", return_value=Path("/r")),
        patch("hypergolic.git.actions.run_git_command", return_value=_ok()),
    ):
        git_discard(["x"])


def test_commit_default_repo():
    with (
        patch("hypergolic.git.actions.git_repo_root", return_value=Path("/r")),
        patch("hypergolic.git.actions.run_git_command", return_value=_ok("ok\n")),
    ):
        git_commit("msg")


def test_push_default_repo():
    call_count = 0

    def mock_run(*args, cwd=None, check=False):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return _ok("main\n")
        return _ok("ok\n")

    with (
        patch("hypergolic.git.actions.git_repo_root", return_value=Path("/r")),
        patch("hypergolic.git.actions.run_git_command", side_effect=mock_run),
    ):
        git_push()


def test_pull_default_repo():
    with (
        patch("hypergolic.git.actions.git_repo_root", return_value=Path("/r")),
        patch("hypergolic.git.actions.run_git_command", return_value=_fail()),
    ):
        git_pull()
