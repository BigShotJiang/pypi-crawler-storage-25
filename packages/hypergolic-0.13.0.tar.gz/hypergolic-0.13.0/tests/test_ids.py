"""Tests for `hypergolic.ids`."""
from __future__ import annotations

import re
import time

from hypergolic.ids import (
    ID_LENGTH,
    _ALPHABET,
    is_valid_id,
    new_id,
)

_ALPHABET_RE = re.compile(f"^[{_ALPHABET}]+$")


def test_length_is_twelve() -> None:
    assert len(new_id()) == ID_LENGTH == 12


def test_only_uses_crockford_alphabet() -> None:
    # Generate a batch to cover a wide range of characters.
    for _ in range(200):
        value = new_id()
        assert _ALPHABET_RE.match(value), value
        # Crockford omits these ambiguous chars.
        for forbidden in "ILOU":
            assert forbidden not in value


def test_ids_are_unique_in_a_tight_burst() -> None:
    # With 18 random bits per ms (262_144 slots), 500 draws within a single
    # millisecond have a birthday expectation <1 collision. In practice a
    # burst this size spans multiple ms anyway, so uniqueness is overwhelming
    # but not guaranteed. Allow a razor-thin margin to keep the test stable.
    batch = {new_id() for _ in range(500)}
    assert len(batch) >= 499


def test_injected_timestamp_is_respected() -> None:
    ts = 1_700_000_000_000  # 2023-11-14T22:13:20Z, well within 42 bits
    ids = [new_id(now_ms=ts) for _ in range(20)]
    # 42 timestamp bits span 8 full chars (40 bits) plus 2 bits of char index 8,
    # which mixes with random bits. Only the first 8 chars are guaranteed stable.
    prefixes = {value[:8] for value in ids}
    assert len(prefixes) == 1


def test_lexicographic_order_matches_time_order() -> None:
    earlier = new_id(now_ms=1_000_000_000_000)
    middle = new_id(now_ms=1_500_000_000_000)
    later = new_id(now_ms=2_000_000_000_000)
    assert earlier < middle < later


def test_monotonic_across_real_time() -> None:
    a = new_id()
    time.sleep(0.005)  # 5ms: larger than 1ms tick, smaller than test overhead budget
    b = new_id()
    assert a < b


def test_sort_stable_across_many_timestamps() -> None:
    # Strictly increasing timestamps should yield strictly increasing IDs
    # regardless of random suffix.
    timestamps = [1_700_000_000_000 + i * 1000 for i in range(50)]
    ids = [new_id(now_ms=ts) for ts in timestamps]
    assert ids == sorted(ids)


def test_is_valid_id_accepts_generated() -> None:
    assert is_valid_id(new_id())


def test_is_valid_id_rejects_wrong_length() -> None:
    assert not is_valid_id("ABC")
    assert not is_valid_id("A" * (ID_LENGTH + 1))


def test_is_valid_id_rejects_forbidden_chars() -> None:
    # Same length as a real ID but contains 'I', which Crockford excludes.
    assert not is_valid_id("I" + "0" * (ID_LENGTH - 1))
    assert not is_valid_id("L" + "0" * (ID_LENGTH - 1))
    assert not is_valid_id("O" + "0" * (ID_LENGTH - 1))
    assert not is_valid_id("U" + "0" * (ID_LENGTH - 1))


def test_is_valid_id_rejects_lowercase() -> None:
    # Our generator emits uppercase only; be strict at the boundary.
    assert not is_valid_id("abcdefghij")
