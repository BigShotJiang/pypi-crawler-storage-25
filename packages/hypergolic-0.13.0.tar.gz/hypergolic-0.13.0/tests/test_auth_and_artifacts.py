from unittest.mock import patch

import hypergolic.auth as auth_module
from hypergolic.auth import init_bootstrap_token, redeem_bootstrap_token, verify_token
from hypergolic.toolkit.primitives import Workflow, WorkflowState
from tests.conftest import make_artifact, make_project, make_session

# ---------------------------------------------------------------------------
# Auth middleware tests (use unauth_client — no token bypass)
# ---------------------------------------------------------------------------


def test_health_endpoint_no_auth_required(unauth_client):
    resp = unauth_client.get("/api/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


def test_protected_endpoint_rejects_without_token(unauth_client):
    resp = unauth_client.get("/api/projects")
    assert resp.status_code == 403


def test_protected_endpoint_rejects_invalid_token(unauth_client):
    unauth_client.cookies.set("h_token", "wrong-token")
    resp = unauth_client.get("/api/projects")
    assert resp.status_code == 403


def test_bootstrap_token_empty_value():
    """redeem_bootstrap_token with empty string returns None."""
    result = redeem_bootstrap_token("")
    assert result is None


def test_verify_token_no_session():
    """verify_token returns False when _session_token is empty."""
    original = auth_module._session_token
    try:
        auth_module._session_token = ""
        assert verify_token("anything") is False
    finally:
        auth_module._session_token = original


def test_bootstrap_token_redemption(unauth_client):
    token = init_bootstrap_token()
    resp = unauth_client.get(f"/?token={token}", follow_redirects=False)
    assert resp.status_code == 200
    set_cookie = resp.headers.get("set-cookie", "")
    assert "h_token=" in set_cookie


# ---------------------------------------------------------------------------
# Attachment router tests (use api_client — authenticated)
# ---------------------------------------------------------------------------


def test_upload_image_too_large(api_client):
    """File exceeding 20MB limit returns 413."""
    oversized_data = b"x" * (20 * 1024 * 1024 + 1)
    resp = api_client.post(
        "/api/attachments/upload",
        files={"file": ("big.png", oversized_data, "image/png")},
    )
    assert resp.status_code == 413
    assert "too large" in resp.json()["detail"].lower()


def test_upload_image_processing_error(api_client):
    """process_image raising ValueError returns 400."""
    with patch(
        "hypergolic.attachments.router.process_image",
        side_effect=ValueError("corrupt image data"),
    ):
        resp = api_client.post(
            "/api/attachments/upload",
            files={"file": ("bad.png", b"\x89PNG\r\n\x1a\nfakedata", "image/png")},
        )
    assert resp.status_code == 400
    assert "corrupt image data" in resp.json()["detail"]


# ---------------------------------------------------------------------------
# Artifact router tests (use api_client — authenticated)
# ---------------------------------------------------------------------------


def test_list_artifacts_empty(api_client):
    resp = api_client.get("/api/artifacts")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_artifacts_with_data(api_client):
    make_project()
    sid = make_session()
    make_artifact(sid, workflow_id="wf-1", state_id="s1", outcome="success", artifact_id="a1")
    make_artifact(sid, workflow_id="wf-1", state_id="s2", outcome="failure", artifact_id="a2")

    resp = api_client.get("/api/artifacts")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    # Ordered by created_at desc — a2 was created second
    assert data[0]["artifact_id"] == "a2"
    assert data[1]["artifact_id"] == "a1"


def test_list_artifacts_filters(api_client):
    make_project()
    sid1 = make_session(sid="sess-1")
    sid2 = make_session(sid="sess-2")
    make_artifact(sid1, workflow_id="wf-A", state_id="s1", outcome="success", artifact_id="a1")
    make_artifact(sid2, workflow_id="wf-B", state_id="s1", outcome="failure", artifact_id="a2")

    # Filter by session_id
    resp = api_client.get("/api/artifacts", params={"session_id": sid1})
    data = resp.json()
    assert len(data) == 1
    assert data[0]["session_id"] == sid1

    # Filter by workflow_id
    resp = api_client.get("/api/artifacts", params={"workflow_id": "wf-B"})
    data = resp.json()
    assert len(data) == 1
    assert data[0]["workflow_id"] == "wf-B"


def test_list_artifacts_pagination(api_client):
    make_project()
    sid = make_session()
    for i in range(5):
        make_artifact(sid, artifact_id=f"art-{i}")

    # limit=2
    resp = api_client.get("/api/artifacts", params={"limit": 2})
    data = resp.json()
    assert len(data) == 2

    # offset=3, limit=10 → should get 2 remaining
    resp = api_client.get("/api/artifacts", params={"offset": 3, "limit": 10})
    data = resp.json()
    assert len(data) == 2


def test_get_artifact_success(api_client):
    make_project()
    sid = make_session()
    db_id = make_artifact(sid, workflow_id="wf-1", state_id="s1", outcome="success",
                          artifact_id="a1", content={"key": "value"})

    resp = api_client.get(f"/api/artifacts/{db_id}")
    assert resp.status_code == 200
    data = resp.json()
    assert data["id"] == db_id
    assert data["artifact_id"] == "a1"
    assert data["content"] == {"key": "value"}


def test_get_artifact_not_found(api_client):
    resp = api_client.get("/api/artifacts/nonexistent-id")
    assert resp.status_code == 404


# ---------------------------------------------------------------------------
# Workflows prompt-content tests
# ---------------------------------------------------------------------------


def test_get_prompt_content_not_in_workflow(api_client):
    with patch("hypergolic.workflows.routers.resolve_workflows", return_value=[]):
        resp = api_client.get("/api/workflows/prompt-content", params={"path": "/tmp/nope.md"})
    assert resp.status_code == 404
    assert "not found in any workflow" in resp.json()["detail"]


def test_get_prompt_content_success(api_client, tmp_path):
    prompt_file = tmp_path / "my_prompt.md"
    prompt_file.write_text("# Hello prompt")

    wf = Workflow(
        id="wf-test",
        name="Test Workflow",
        description="A test workflow",
        initial_state="draft",
        states=[
            WorkflowState(id="draft", name="Draft", prompt_path=str(prompt_file)),
        ],
    )

    with patch("hypergolic.workflows.routers.resolve_workflows", return_value=[wf]):
        resp = api_client.get("/api/workflows/prompt-content",
                              params={"path": str(prompt_file)})
    assert resp.status_code == 200
    data = resp.json()
    assert data["path"] == str(prompt_file)
    assert data["content"] == "# Hello prompt"
