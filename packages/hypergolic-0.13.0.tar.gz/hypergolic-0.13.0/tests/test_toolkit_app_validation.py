"""Tests for hypergolic.toolkit.app.validation."""

from pathlib import Path
from unittest.mock import patch

import pytest

from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.validation import (
    _collect_all_skills,
    _detect_skill_cycles,
    validate_app,
)
from hypergolic.toolkit.primitives import (
    OutputSchema,
    Role,
    Skill,
    Tool,
    Workflow,
    WorkflowState,
)
from hypergolic.toolkit.project import Project


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


async def _noop(inp, ctx):
    return "ok"


def _skill(sid: str, children: list | None = None) -> Skill:
    return Skill(id=sid, name=sid, description="d", skills=children or [])


def _tool(tid: str) -> Tool:
    return Tool(id=tid, name=tid, description="d", run=_noop)


def _generalist_role() -> Role:
    return Role(id="generalist", name="Generalist", prompt="test")


# ---------------------------------------------------------------------------
# _collect_all_skills
# ---------------------------------------------------------------------------


def test_collect_all_skills_flat():
    a = _skill("a")
    b = _skill("b")
    result = _collect_all_skills([a, b])
    assert [s.id for s in result] == ["a", "b"]


def test_collect_all_skills_nested():
    c = _skill("c")
    b = _skill("b", children=[c])
    a = _skill("a", children=[b])
    result = _collect_all_skills([a])
    assert [s.id for s in result] == ["a", "b", "c"]


def test_collect_all_skills_empty():
    assert _collect_all_skills([]) == []


# ---------------------------------------------------------------------------
# _detect_skill_cycles
# ---------------------------------------------------------------------------


def test_detect_no_cycles_linear():
    a = _skill("a", children=[_skill("b")])
    b = _skill("b")
    errors = _detect_skill_cycles([a, a.skills[0], b])
    assert errors == []


def test_detect_direct_cycle():
    # A->B and B->A in adjacency graph
    a = _skill("a", children=[_skill("b")])
    b = _skill("b", children=[_skill("a")])
    all_skills = [a, a.skills[0], b, b.skills[0]]
    errors = _detect_skill_cycles(all_skills)
    assert any("Circular skill dependency" in e for e in errors)


def test_detect_indirect_cycle():
    a = _skill("a", children=[_skill("b")])
    b = _skill("b", children=[_skill("c")])
    c = _skill("c", children=[_skill("a")])
    all_skills = [
        a, a.skills[0],
        b, b.skills[0],
        c, c.skills[0],
    ]
    errors = _detect_skill_cycles(all_skills)
    assert any("Circular skill dependency" in e for e in errors)


def test_detect_cycles_empty():
    assert _detect_skill_cycles([]) == []


# ---------------------------------------------------------------------------
# validate_app — roles
# ---------------------------------------------------------------------------


def test_validate_no_roles_error():
    app = App()
    errors = validate_app(app)
    assert any("No roles registered" in e for e in errors)


def test_validate_missing_generalist_role():
    app = App()
    app.register_role(Role(id="other", name="Other", prompt="test"))
    errors = validate_app(app)
    assert any("generalist" in e for e in errors)


def test_validate_roles_ok():
    app = App()
    app.register_role(_generalist_role())
    # Just check no role-related errors
    errors = validate_app(app)
    role_errors = [e for e in errors if "role" in e.lower() or "Role" in e]
    assert role_errors == []


# ---------------------------------------------------------------------------
# validate_app — duplicate tool IDs
# ---------------------------------------------------------------------------


def test_validate_duplicate_tool_ids_app_level(tmp_path):
    app = App()
    app.register_role(_generalist_role())
    app.register_tool(_tool("dup"))
    app.register_tool(_tool("dup"))
    errors = validate_app(app)
    assert any("Duplicate tool ID" in e and "dup" in e for e in errors)


def test_validate_duplicate_tool_ids_across_project(tmp_path):
    git_root = str(tmp_path)
    (tmp_path / ".git").mkdir()
    app = App()
    app.register_role(_generalist_role())
    app.register_tool(_tool("shared"))
    proj = Project(id="p1", name="P1", description="d", git_root=git_root)
    proj.register_tool(_tool("shared"))
    app.register_project(proj)
    errors = validate_app(app)
    assert any("Duplicate tool ID" in e and "shared" in e for e in errors)


def test_validate_tool_ids_in_workflow(tmp_path):
    git_root = str(tmp_path)
    (tmp_path / ".git").mkdir()
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
        tools=[_tool("wf-tool"), _tool("wf-tool")],
    )
    app = App()
    app.register_role(_generalist_role())
    app.register_workflow(wf)
    errors = validate_app(app)
    assert any("Duplicate tool ID" in e and "wf-tool" in e for e in errors)


def test_validate_tool_ids_in_project_workflow(tmp_path):
    git_root = str(tmp_path)
    (tmp_path / ".git").mkdir()
    wf = Workflow(
        id="wf1", name="WF", description="d", initial_state="s1",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
        tools=[_tool("pt"), _tool("pt")],
    )
    proj = Project(id="p1", name="P1", description="d", git_root=git_root, workflows=[wf])
    app = App()
    app.register_role(_generalist_role())
    app.register_project(proj)
    errors = validate_app(app)
    assert any("Duplicate tool ID" in e for e in errors)


# ---------------------------------------------------------------------------
# validate_app — duplicate project IDs
# ---------------------------------------------------------------------------


def test_validate_duplicate_project_ids(tmp_path):
    git_root = str(tmp_path)
    (tmp_path / ".git").mkdir()
    p1 = Project(id="same", name="A", description="d", git_root=git_root)
    p2 = Project(id="same", name="B", description="d", git_root=git_root)
    app = App()
    app.register_role(_generalist_role())
    app.register_projects([p1, p2])
    errors = validate_app(app)
    assert any("Duplicate project ID" in e and "same" in e for e in errors)


# ---------------------------------------------------------------------------
# validate_app — project git_root
# ---------------------------------------------------------------------------


def test_validate_project_git_root_not_exist():
    app = App()
    app.register_role(_generalist_role())
    app.register_project(Project(
        id="p1", name="P1", description="d",
        git_root="/nonexistent/path/that/does/not/exist",
    ))
    errors = validate_app(app)
    assert any("git_root does not exist" in e for e in errors)


def test_validate_project_git_root_not_a_repo(tmp_path):
    app = App()
    app.register_role(_generalist_role())
    app.register_project(Project(
        id="p1", name="P1", description="d",
        git_root=str(tmp_path),
    ))
    errors = validate_app(app)
    assert any("not a git repo" in e for e in errors)


def test_validate_project_git_root_ok(tmp_path):
    (tmp_path / ".git").mkdir()
    app = App()
    app.register_role(_generalist_role())
    app.register_project(Project(
        id="p1", name="P1", description="d",
        git_root=str(tmp_path),
    ))
    errors = validate_app(app)
    git_errors = [e for e in errors if "git_root" in e or "git repo" in e]
    assert git_errors == []


# ---------------------------------------------------------------------------
# validate_app — prompt_path
# ---------------------------------------------------------------------------


def test_validate_project_prompt_path_not_found(tmp_path):
    (tmp_path / ".git").mkdir()
    app = App()
    app.register_role(_generalist_role())
    app.register_project(Project(
        id="p1", name="P1", description="d",
        git_root=str(tmp_path),
        prompt_path=str(tmp_path / "nonexistent.md"),
    ))
    errors = validate_app(app)
    assert any("prompt_path not found" in e for e in errors)


def test_validate_project_prompt_path_found(tmp_path):
    (tmp_path / ".git").mkdir()
    prompt_file = tmp_path / "prompt.md"
    prompt_file.write_text("hello")
    app = App()
    app.register_role(_generalist_role())
    app.register_project(Project(
        id="p1", name="P1", description="d",
        git_root=str(tmp_path),
        prompt_path=str(prompt_file),
    ))
    errors = validate_app(app)
    prompt_errors = [e for e in errors if "prompt_path" in e]
    assert prompt_errors == []


# ---------------------------------------------------------------------------
# validate_app — workflow initial_state
# ---------------------------------------------------------------------------


def test_validate_workflow_initial_state_missing():
    app = App()
    app.register_role(_generalist_role())
    wf = Workflow(
        id="wf1", name="WF", description="d",
        initial_state="nonexistent",
        states=[WorkflowState(id="s1", name="S1", prompt="t")],
    )
    app.register_workflow(wf)
    errors = validate_app(app)
    assert any("initial_state" in e and "nonexistent" in e for e in errors)


def test_validate_workflow_output_references_unknown_state():
    app = App()
    app.register_role(_generalist_role())
    output = OutputSchema(
        outcome="done",
        schema={"type": "object", "properties": {}},
        next_state="ghost-state",
    )
    state = WorkflowState(id="s1", name="S1", prompt="t", output_schemas=[output])
    wf = Workflow(
        id="wf1", name="WF", description="d",
        initial_state="s1",
        states=[state],
    )
    app.register_workflow(wf)
    errors = validate_app(app)
    assert any("ghost-state" in e for e in errors)


def test_validate_workflow_output_next_state_none_ok():
    """Output with next_state=None is valid."""
    app = App()
    app.register_role(_generalist_role())
    output = OutputSchema(
        outcome="done",
        schema={"type": "object", "properties": {}},
        next_state=None,
    )
    state = WorkflowState(id="s1", name="S1", prompt="t", output_schemas=[output])
    wf = Workflow(
        id="wf1", name="WF", description="d",
        initial_state="s1",
        states=[state],
    )
    app.register_workflow(wf)
    # Should not raise workflow state errors
    errors = validate_app(app)
    wf_state_errors = [e for e in errors if "ghost" in e or "unknown state" in e]
    assert wf_state_errors == []


# ---------------------------------------------------------------------------
# validate_app — duplicate skill IDs
# ---------------------------------------------------------------------------


def test_validate_duplicate_skill_ids_top_level():
    app = App()
    app.register_role(_generalist_role())
    app.register_skill(_skill("dup"))
    app.register_skill(_skill("dup"))
    errors = validate_app(app)
    assert any("Duplicate skill ID" in e and "dup" in e for e in errors)


def test_validate_same_skill_instance_on_app_and_role_is_not_duplicate():
    """Registering the same Skill object on the app and a role is allowed."""
    shared = _skill("shared")
    role = _generalist_role()
    role.skills.append(shared)
    app = App()
    app.register_role(role)
    app.register_skill(shared)
    errors = validate_app(app)
    assert not any("Duplicate skill ID" in e for e in errors)


def test_validate_same_skill_instance_on_multiple_roles_is_not_duplicate():
    """Same Skill attached to multiple roles should not trigger duplicate errors."""
    shared = _skill("shared")
    generalist = _generalist_role()
    generalist.skills.append(shared)
    other = Role(id="other", name="Other", prompt="p", skills=[shared])
    app = App()
    app.register_roles([generalist, other])
    errors = validate_app(app)
    assert not any("Duplicate skill ID" in e for e in errors)


def test_validate_no_errors_clean_app(tmp_path):
    """A well-configured app produces no errors."""
    (tmp_path / ".git").mkdir()
    app = App()
    app.register_role(_generalist_role())
    app.register_project(Project(
        id="p1", name="P1", description="d",
        git_root=str(tmp_path),
    ))
    errors = validate_app(app)
    assert errors == []
