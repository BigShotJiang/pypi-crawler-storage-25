"""Tests for hypergolic.git.worktree — worktree lifecycle primitives.

Each test shells out to git several times; the suite-wide default timeout
of 0.5s is too aggressive for these so we relax it.
"""

from __future__ import annotations

import subprocess
from pathlib import Path

import pytest

pytestmark = pytest.mark.timeout(10)

from hypergolic.git.worktree import (  # noqa: E402
    WorktreeCreationError,
    create_worktree,
    delete_branch,
    list_gitignored_entries,
    remove_worktree,
    seed_worktree_environment,
    teardown_worktree_on_delete,
    worktree_branch_name,
    worktree_path_for,
    worktrees_root,
)


def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-b", "main", str(path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(path), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(path), "config", "user.name", "t"], check=True)
    (path / "README.md").write_text("readme\n")
    subprocess.run(["git", "-C", str(path), "add", "-A"], check=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True,
        capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    project = tmp_path / "project"
    project.mkdir()
    _init_repo(project)
    return project


@pytest.fixture
def worktrees_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home / ".hypergolic" / "worktrees"


def test_worktree_branch_name_uses_full_session_id() -> None:
    sid = "019d9f3b-db57-708d-b0ec-4ca8b31a87a7"
    assert worktree_branch_name(sid) == f"hyp/{sid}"


def test_worktree_branch_name_no_dashes() -> None:
    assert worktree_branch_name("abcdefghijklmnop") == "hyp/abcdefghijklmnop"


def test_worktrees_root_under_hypergolic_dir(worktrees_home: Path) -> None:
    assert worktrees_root() == worktrees_home


def test_create_worktree_creates_branch_and_dir(
    repo: Path, worktrees_home: Path,
) -> None:
    sid = "abc12345-x"
    info = create_worktree(session_id=sid, project_path=repo)
    assert info.branch == f"hyp/{sid}"
    assert info.base_branch == "main"
    assert info.worktree_path.exists()
    assert (info.worktree_path / "README.md").exists()

    # Branch was created in the repo.
    result = subprocess.run(
        ["git", "-C", str(repo), "branch", "--list", f"hyp/{sid}"],
        check=True, capture_output=True, text=True,
    )
    assert f"hyp/{sid}" in result.stdout


def test_create_worktree_fails_when_not_repo(
    tmp_path: Path, worktrees_home: Path,
) -> None:
    with pytest.raises(WorktreeCreationError, match="Not a git repository"):
        create_worktree(session_id="s-1", project_path=tmp_path / "nope")


def test_create_worktree_fails_on_detached_head(
    repo: Path, worktrees_home: Path,
) -> None:
    # Check out a commit by SHA so HEAD is detached.
    sha = subprocess.run(
        ["git", "-C", str(repo), "rev-parse", "HEAD"],
        capture_output=True, text=True, check=True,
    ).stdout.strip()
    subprocess.run(
        ["git", "-C", str(repo), "checkout", sha],
        check=True, capture_output=True,
    )
    with pytest.raises(WorktreeCreationError, match="detached HEAD"):
        create_worktree(session_id="s-1", project_path=repo)


def test_create_worktree_fails_when_path_exists(
    repo: Path, worktrees_home: Path,
) -> None:
    target = worktree_path_for("s-1")
    target.parent.mkdir(parents=True, exist_ok=True)
    target.mkdir()
    with pytest.raises(WorktreeCreationError, match="already exists"):
        create_worktree(session_id="s-1", project_path=repo)


def test_remove_worktree_removes_directory(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-rm", project_path=repo)
    assert info.worktree_path.exists()
    remove_worktree(worktree_path=info.worktree_path, project_path=repo)
    assert not info.worktree_path.exists()


def test_delete_branch_removes_branch(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-del", project_path=repo)
    remove_worktree(worktree_path=info.worktree_path, project_path=repo)
    delete_branch(branch=info.branch, project_path=repo, force=True)
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert info.branch not in branches


def test_teardown_worktree_on_delete_nonexistent_is_noop(repo: Path) -> None:
    # Shouldn't raise on None fields.
    teardown_worktree_on_delete(
        worktree_path=None,
        worktree_branch=None,
        project_path=str(repo),
    )


def test_teardown_worktree_on_delete_cleans_both(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-td", project_path=repo)
    teardown_worktree_on_delete(
        worktree_path=str(info.worktree_path),
        worktree_branch=info.branch,
        project_path=str(repo),
    )
    assert not info.worktree_path.exists()
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert info.branch not in branches


def test_list_gitignored_entries_returns_only_ignored(repo: Path) -> None:
    (repo / ".gitignore").write_text(".venv\nnode_modules/\n.env\n")
    (repo / ".venv").mkdir()
    (repo / ".venv" / "pyvenv.cfg").write_text("")
    (repo / ".env").write_text("SECRET=1\n")
    (repo / "tracked.txt").write_text("hi")
    subprocess.run(["git", "-C", str(repo), "add", ".gitignore", "tracked.txt"], check=True)
    subprocess.run(
        ["git", "-C", str(repo), "commit", "-m", "ignore rules"],
        check=True, capture_output=True,
    )

    entries = list_gitignored_entries(repo)
    assert ".env" in entries
    assert ".venv" in entries
    assert "tracked.txt" not in entries
    # .git should never appear
    assert not any(e.startswith(".git/") or e == ".git" for e in entries)


def test_seed_worktree_environment_copies_ignored(
    repo: Path, worktrees_home: Path,
) -> None:
    (repo / ".gitignore").write_text(".env\n.venv\n")
    (repo / ".env").write_text("SECRET=1")
    (repo / ".venv").mkdir()
    (repo / ".venv" / "marker").write_text("x")
    subprocess.run(["git", "-C", str(repo), "add", ".gitignore"], check=True)
    subprocess.run(
        ["git", "-C", str(repo), "commit", "-m", "ignore"],
        check=True, capture_output=True,
    )

    info = create_worktree(session_id="s-seed", project_path=repo)
    seed_worktree_environment(
        project_path=repo, worktree_path=info.worktree_path,
    )

    assert (info.worktree_path / ".env").read_text() == "SECRET=1"
    assert (info.worktree_path / ".venv" / "marker").read_text() == "x"


def test_seed_worktree_environment_respects_skip(
    repo: Path, worktrees_home: Path,
) -> None:
    (repo / ".gitignore").write_text("skipme\nkeepme\n")
    (repo / "skipme").write_text("no")
    (repo / "keepme").write_text("yes")
    subprocess.run(["git", "-C", str(repo), "add", ".gitignore"], check=True)
    subprocess.run(
        ["git", "-C", str(repo), "commit", "-m", "ignore"],
        check=True, capture_output=True,
    )

    info = create_worktree(session_id="s-skip", project_path=repo)
    seed_worktree_environment(
        project_path=repo,
        worktree_path=info.worktree_path,
        skip_entries=("skipme",),
    )
    assert not (info.worktree_path / "skipme").exists()
    assert (info.worktree_path / "keepme").read_text() == "yes"
