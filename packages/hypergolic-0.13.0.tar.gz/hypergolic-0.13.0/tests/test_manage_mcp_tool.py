"""Tests for hypergolic.base.tools.manage_mcp."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch

from hypergolic.base.tools.manage_mcp import ManageMCPInput, run_manage_mcp
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _session(sid: str = "s-1") -> Session:
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )


def _ctx(session: Session | None = None) -> ToolContext:
    return ToolContext(
        session=session or _session(),
        broadcast=AsyncMock(),
        tool_id="manage_mcp",
    )


def _make_manager(
    available: dict | None = None,
    connected: dict | None = None,
) -> MagicMock:
    manager = MagicMock()
    manager.get_available_servers.return_value = available or {}
    manager.is_connected.side_effect = lambda name: name in (connected or {})
    manager.get_connected_server.side_effect = lambda name: (connected or {}).get(name)
    return manager


def _make_server(tool_count: int = 2) -> MagicMock:
    server = MagicMock()
    server.tools = [MagicMock()] * tool_count
    return server


# ---------------------------------------------------------------------------
# list command
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_list_no_servers():
    manager = _make_manager(available={})
    inp = ManageMCPInput(command="list")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch("hypergolic.base.tools.manage_mcp.get_enabled_servers", return_value=set()),
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "No MCP servers" in result.content[0]["text"]


@pytest.mark.anyio
async def test_list_available_server_not_connected():
    server_config = MagicMock()
    manager = _make_manager(
        available={"my-server": (server_config, "user")},
        connected={},
    )
    manager.get_connected_server.return_value = None
    inp = ManageMCPInput(command="list")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch("hypergolic.base.tools.manage_mcp.get_enabled_servers", return_value=set()),
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "SUCCESS"
    text = result.content[0]["text"]
    assert "my-server" in text
    assert "available" in text


@pytest.mark.anyio
async def test_list_connected_server_not_in_session():
    """A connected server not in the session shows 'connected' status."""
    server_config = MagicMock()
    connected_server = _make_server(tool_count=3)
    manager = _make_manager(
        available={"srv": (server_config, "user")},
        connected={"srv": connected_server},
    )
    inp = ManageMCPInput(command="list")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch(
            "hypergolic.base.tools.manage_mcp.get_enabled_servers",
            return_value=set(),  # not in session
        ),
    ):
        result = await run_manage_mcp(inp, ctx)

    text = result.content[0]["text"]
    assert "connected" in text
    assert "srv" in text


@pytest.mark.anyio
async def test_list_enabled_server_shows_enabled_status():
    """A server that is in the enabled set shows 'enabled' status."""
    server_config = MagicMock()
    connected_server = _make_server(tool_count=5)
    manager = _make_manager(
        available={"enabled-srv": (server_config, "user")},
        connected={"enabled-srv": connected_server},
    )
    inp = ManageMCPInput(command="list")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch(
            "hypergolic.base.tools.manage_mcp.get_enabled_servers",
            return_value={"enabled-srv"},
        ),
    ):
        result = await run_manage_mcp(inp, ctx)

    text = result.content[0]["text"]
    assert "enabled" in text
    assert "enabled-srv" in text
    assert "5" in text  # tool count


@pytest.mark.anyio
async def test_list_multiple_servers():
    server_config = MagicMock()
    manager = _make_manager(
        available={
            "srv-a": (server_config, "user"),
            "srv-b": (server_config, "user"),
        },
        connected={},
    )
    manager.get_connected_server.return_value = None
    inp = ManageMCPInput(command="list")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch("hypergolic.base.tools.manage_mcp.get_enabled_servers", return_value=set()),
    ):
        result = await run_manage_mcp(inp, ctx)

    text = result.content[0]["text"]
    assert "srv-a" in text
    assert "srv-b" in text


# ---------------------------------------------------------------------------
# enable command
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_enable_missing_server_name():
    manager = _make_manager()
    inp = ManageMCPInput(command="enable", server_name=None)
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch("hypergolic.base.tools.manage_mcp.get_enabled_servers", return_value=set()),
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "server_name is required" in result.content[0]["text"]


@pytest.mark.anyio
async def test_enable_success():
    connected_server = _make_server(tool_count=4)
    manager = MagicMock()
    manager.connect = AsyncMock(return_value=connected_server)
    inp = ManageMCPInput(command="enable", server_name="good-server")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch(
            "hypergolic.base.tools.manage_mcp.get_enabled_servers",
            return_value=set(),
        ),
        patch("hypergolic.base.tools.manage_mcp.set_enabled_servers") as mock_set,
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "SUCCESS"
    text = result.content[0]["text"]
    assert "good-server" in text
    assert "4" in text
    mock_set.assert_called_once()
    # Verify the server name was added to the enabled set
    _, call_args = mock_set.call_args
    # called as set_enabled_servers(session_id, enabled_set)
    call_positional = mock_set.call_args[0]
    assert "good-server" in call_positional[1]


@pytest.mark.anyio
async def test_enable_connection_failure():
    manager = MagicMock()
    manager.connect = AsyncMock(side_effect=Exception("connection refused"))
    inp = ManageMCPInput(command="enable", server_name="bad-server")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch("hypergolic.base.tools.manage_mcp.get_enabled_servers", return_value=set()),
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "FAILURE"
    text = result.content[0]["text"]
    assert "bad-server" in text
    assert "connection refused" in text


# ---------------------------------------------------------------------------
# disable command
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_disable_missing_server_name():
    manager = _make_manager()
    inp = ManageMCPInput(command="disable", server_name=None)
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch("hypergolic.base.tools.manage_mcp.get_enabled_servers", return_value=set()),
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "server_name is required" in result.content[0]["text"]


@pytest.mark.anyio
async def test_disable_removes_from_enabled():
    manager = MagicMock()
    inp = ManageMCPInput(command="disable", server_name="srv-to-disable")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch(
            "hypergolic.base.tools.manage_mcp.get_enabled_servers",
            return_value={"srv-to-disable", "other-srv"},
        ),
        patch("hypergolic.base.tools.manage_mcp.set_enabled_servers") as mock_set,
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "srv-to-disable" in result.content[0]["text"]
    # set_enabled_servers called with the server removed
    call_positional = mock_set.call_args[0]
    assert "srv-to-disable" not in call_positional[1]
    assert "other-srv" in call_positional[1]


@pytest.mark.anyio
async def test_disable_server_not_in_enabled_is_noop():
    """Disabling a server not in the enabled set is a no-op (discard)."""
    manager = MagicMock()
    inp = ManageMCPInput(command="disable", server_name="not-enabled")
    ctx = _ctx()

    with (
        patch("hypergolic.base.tools.manage_mcp.get_mcp_manager", return_value=manager),
        patch(
            "hypergolic.base.tools.manage_mcp.get_enabled_servers",
            return_value=set(),
        ),
        patch("hypergolic.base.tools.manage_mcp.set_enabled_servers") as mock_set,
    ):
        result = await run_manage_mcp(inp, ctx)

    assert result.outcome == "SUCCESS"
    call_positional = mock_set.call_args[0]
    assert "not-enabled" not in call_positional[1]


# ---------------------------------------------------------------------------
# ManageMCPInput schema
# ---------------------------------------------------------------------------


def test_manage_mcp_input_list_command():
    inp = ManageMCPInput(command="list")
    assert inp.command == "list"
    assert inp.server_name is None


def test_manage_mcp_input_enable_with_server():
    inp = ManageMCPInput(command="enable", server_name="my-srv")
    assert inp.command == "enable"
    assert inp.server_name == "my-srv"


def test_manage_mcp_input_disable_with_server():
    inp = ManageMCPInput(command="disable", server_name="my-srv")
    assert inp.command == "disable"
