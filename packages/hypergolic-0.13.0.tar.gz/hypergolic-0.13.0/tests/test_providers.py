from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.config.settings import settings
from hypergolic.enums import ModelTier
from hypergolic.providers import (
    create_client,
    generate_text,
    tier_to_model_id,
)


def test_create_client_disables_sdk_retries():
    with patch("hypergolic.providers.AsyncAnthropic") as mock_cls:
        create_client()
    kwargs = mock_cls.call_args.kwargs
    # SDK retries disabled — we retry ourselves.
    assert kwargs["max_retries"] == 0
    assert "timeout" not in kwargs


def test_create_client_bedrock_provider():
    with (
        patch.object(settings, "HYPERGOLIC_PROVIDER", "bedrock"),
        patch.object(settings, "AWS_REGION", "us-west-2"),
        patch.object(settings, "AWS_ACCESS_KEY_ID", "AKID"),
        patch.object(settings, "AWS_SECRET_ACCESS_KEY", "secret"),
        patch.object(settings, "AWS_SESSION_TOKEN", ""),
        patch.object(settings, "AWS_PROFILE", ""),
        patch("hypergolic.providers.AsyncAnthropicBedrock") as mock_cls,
    ):
        create_client()
    kwargs = mock_cls.call_args.kwargs
    assert kwargs["aws_region"] == "us-west-2"
    assert kwargs["aws_access_key"] == "AKID"
    assert kwargs["aws_secret_key"] == "secret"
    # Empty strings become None (falsy)
    assert kwargs["aws_session_token"] is None
    assert kwargs["aws_profile"] is None
    assert kwargs["max_retries"] == 0
    assert "timeout" not in kwargs


def test_tier_to_model_id_bedrock():
    with patch.object(settings, "HYPERGOLIC_PROVIDER", "bedrock"):
        assert tier_to_model_id(ModelTier.LOW) == "us.anthropic.claude-haiku-4-5-v1:0"
        assert tier_to_model_id(ModelTier.MEDIUM) == "us.anthropic.claude-sonnet-4-6-v1:0"
        assert tier_to_model_id(ModelTier.HIGH) == "us.anthropic.claude-opus-4-7-v1:0"


def test_tier_to_model_id_anthropic():
    with patch.object(settings, "HYPERGOLIC_PROVIDER", "anthropic"):
        assert tier_to_model_id(ModelTier.LOW) == "claude-haiku-4-5"
        assert tier_to_model_id(ModelTier.MEDIUM) == "claude-sonnet-4-6"
        assert tier_to_model_id(ModelTier.HIGH) == "claude-opus-4-7"


@pytest.mark.asyncio
async def test_generate_text_returns_text():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "Hello world"
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        result = await generate_text(
            system="You are helpful.",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )

    assert result == "Hello world"
    call_kwargs = mock_client.return_value.messages.create.call_args[1]
    assert call_kwargs["system"] == "You are helpful."
    assert call_kwargs["max_tokens"] == 100
    assert call_kwargs["messages"] == [{"role": "user", "content": "Hi"}]
    # LOW tier (default) should not set output_config / effort.
    assert "output_config" not in call_kwargs


@pytest.mark.asyncio
async def test_generate_text_returns_none_on_empty_response():
    mock_response = MagicMock()
    mock_response.content = []

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        result = await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )

    assert result is None


@pytest.mark.asyncio
async def test_generate_text_returns_none_on_whitespace_only():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "   \n  "
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        result = await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
        )

    assert result is None


@pytest.mark.asyncio
async def test_generate_text_uses_model_tier():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "result"
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
            model_tier=ModelTier.HIGH,
        )

    call_kwargs = mock_client.return_value.messages.create.call_args[1]
    assert call_kwargs["model"] == "claude-opus-4-7"
    assert call_kwargs["output_config"] == {"effort": "xhigh"}


@pytest.mark.asyncio
async def test_generate_text_medium_tier_omits_output_config():
    mock_block = MagicMock()
    mock_block.type = "text"
    mock_block.text = "result"
    mock_response = MagicMock()
    mock_response.content = [mock_block]

    with patch("hypergolic.providers.create_client") as mock_client:
        mock_client.return_value.messages.create = AsyncMock(return_value=mock_response)
        await generate_text(
            system="sys",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=100,
            model_tier=ModelTier.MEDIUM,
        )

    call_kwargs = mock_client.return_value.messages.create.call_args[1]
    assert call_kwargs["model"] == "claude-sonnet-4-6"
    assert "output_config" not in call_kwargs
