"""Additional tests for hypergolic.dispatch.conclude (ConcludeTool extra coverage)."""

from typing import Any, cast
from unittest.mock import AsyncMock, patch

import pytest

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.dispatch.conclude import (
    ConcludeInput,
    ConcludeTool,
    _set_concluded_at,
    _handle_conclude,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.schemas import ToolContext


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _text(block: object) -> str:
    return cast(dict[str, Any], block)["text"]


def _seed(sid="s1", parent_id=None, project_id="p1"):
    with get_db() as db:
        if not db.get(DBProject, project_id):
            db.add(DBProject(id=project_id, name="Proj", path=f"/tmp/{project_id}"))
        if parent_id and not db.get(DBSession, parent_id):
            db.add(DBSession(
                id=parent_id, model_tier="Medium", system_prompt=[], project_id=project_id,
            ))
        db.add(DBSession(
            id=sid, model_tier="Medium", system_prompt=[], project_id=project_id,
            parent_id=parent_id,
        ))


def _make_session(sid="s1", parent_id=None):
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path="/tmp/p",
        parent_id=parent_id,
    )


def _make_ctx(session, broadcast=None):
    return ToolContext(
        session=session,
        broadcast=broadcast or AsyncMock(),
        tool_id="conclude",
    )


# ---------------------------------------------------------------------------
# ConcludeTool properties
# ---------------------------------------------------------------------------


def test_conclude_tool_id():
    assert ConcludeTool.id == "conclude"


def test_conclude_tool_input_is_conclude_input():
    assert ConcludeTool.input is ConcludeInput


def test_conclude_tool_source():
    assert ConcludeTool.source == "dispatch"


def test_conclude_tool_description_mentions_suppressed():
    assert "suppressed" in ConcludeTool.description


# ---------------------------------------------------------------------------
# ConcludeInput model
# ---------------------------------------------------------------------------


def test_conclude_input_valid_success():
    inp = ConcludeInput(outcome="success", conclusion="All done")
    assert inp.outcome == "success"
    assert inp.conclusion == "All done"


def test_conclude_input_valid_failure():
    inp = ConcludeInput(outcome="failure", conclusion="Failed")
    assert inp.outcome == "failure"


def test_conclude_input_valid_suppressed():
    inp = ConcludeInput(outcome="suppressed", conclusion="Cancelled")
    assert inp.outcome == "suppressed"


def test_conclude_input_invalid_outcome():
    import pydantic
    with pytest.raises(pydantic.ValidationError):
        ConcludeInput(outcome=cast(Any, "invalid"), conclusion="x")


# ---------------------------------------------------------------------------
# _safe_cleanup_sandboxes (indirectly via _handle_conclude)
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_conclude_schedules_cleanup_on_resolved():
    _seed("child-cleanup", parent_id="parent-cleanup")
    session = _make_session("child-cleanup", parent_id="parent-cleanup")
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ConcludeInput(outcome="success", conclusion="Done")

    ensure_future_called = []

    import asyncio
    original_ensure_future = asyncio.ensure_future

    def mock_ensure_future(coro):
        ensure_future_called.append(coro)
        # Don't actually schedule it to avoid cleanup side effects
        coro.close()
        return MagicMock()

    from unittest.mock import MagicMock

    with (
        patch("hypergolic.dispatch.conclude.resolve_dispatch", return_value=True),
        patch("hypergolic.dispatch.conclude.set_session_status_and_broadcast", new=AsyncMock()),
        patch("hypergolic.dispatch.conclude._set_concluded_at", return_value=MagicMock()),
        patch("asyncio.ensure_future", side_effect=mock_ensure_future),
    ):
        output = await _handle_conclude(inp, ctx)

    assert not output.is_error
    # ensure_future was called (for sandbox cleanup)
    assert len(ensure_future_called) >= 1


@pytest.mark.anyio
async def test_conclude_not_resolved_with_parent_schedules_cleanup():
    _seed("child-c2", parent_id="parent-c2")
    session = _make_session("child-c2", parent_id="parent-c2")
    broadcast = AsyncMock()
    ctx = _make_ctx(session, broadcast)
    inp = ConcludeInput(outcome="failure", conclusion="Couldn't finish")

    ensure_future_called = []

    def mock_ensure_future(coro):
        ensure_future_called.append(coro)
        coro.close()
        return MagicMock()

    from unittest.mock import MagicMock

    with (
        patch("hypergolic.dispatch.conclude.resolve_dispatch", return_value=False),
        patch("hypergolic.dispatch.conclude.set_session_status_and_broadcast", new=AsyncMock()),
        patch("hypergolic.dispatch.conclude._set_concluded_at", return_value=MagicMock()),
        patch("asyncio.ensure_future", side_effect=mock_ensure_future),
    ):
        output = await _handle_conclude(inp, ctx)

    assert not output.is_error
    assert len(ensure_future_called) >= 1
