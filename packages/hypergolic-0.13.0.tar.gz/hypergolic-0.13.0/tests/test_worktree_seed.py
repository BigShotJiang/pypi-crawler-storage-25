"""Tests for hypergolic.git.worktree_seed — env seeding status orchestration."""

from __future__ import annotations

import subprocess
from pathlib import Path
from unittest.mock import patch

import pytest

pytestmark = pytest.mark.timeout(10)

from hypergolic.db.engine import get_db  # noqa: E402
from hypergolic.db.models import DBProject, DBSession  # noqa: E402
from hypergolic.git.worktree import create_worktree  # noqa: E402
from hypergolic.git.worktree_seed import (  # noqa: E402
    run_seed_task,
    schedule_seed_task,
    set_seed_status,
)


def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-b", "main", str(path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(path), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(path), "config", "user.name", "t"], check=True)
    (path / "README.md").write_text("readme\n")
    (path / ".gitignore").write_text(".env\n")
    (path / ".env").write_text("SECRET=1")
    subprocess.run(["git", "-C", str(path), "add", "-A"], check=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True, capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    project = tmp_path / "project"
    project.mkdir()
    _init_repo(project)
    return project


@pytest.fixture
def worktrees_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home / ".hypergolic" / "worktrees"


def _seed_session_row(session_id: str, project_path: str) -> None:
    with get_db() as db:
        if not db.get(DBProject, "proj-seed"):
            db.add(DBProject(id="proj-seed", name="P", path=project_path))
        db.add(DBSession(
            id=session_id, model_tier="Medium", system_prompt=[], project_id="proj-seed",
            worktree_seed_status="pending",
        ))


def test_set_seed_status_updates_row(
    repo: Path, worktrees_home: Path,
) -> None:
    _seed_session_row("s-set", str(repo))
    set_seed_status("s-set", "ready")
    with get_db() as db:
        row = db.get(DBSession, "s-set")
        assert row is not None
        assert row.worktree_seed_status == "ready"


def test_run_seed_task_marks_ready_on_success(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-seed-ok", project_path=repo)
    _seed_session_row("s-seed-ok", str(repo))
    run_seed_task(
        session_id="s-seed-ok",
        project_path=repo,
        worktree_path=info.worktree_path,
    )
    with get_db() as db:
        row = db.get(DBSession, "s-seed-ok")
        assert row is not None
        assert row.worktree_seed_status == "ready"
    # .env was copied in.
    assert (info.worktree_path / ".env").read_text() == "SECRET=1"


def test_run_seed_task_marks_failed_on_error(
    repo: Path, worktrees_home: Path,
) -> None:
    _seed_session_row("s-seed-fail", str(repo))
    with patch(
        "hypergolic.git.worktree_seed.seed_worktree_environment",
        side_effect=RuntimeError("boom"),
    ):
        run_seed_task(
            session_id="s-seed-fail",
            project_path=repo,
            worktree_path=repo,  # not used due to mock
        )
    with get_db() as db:
        row = db.get(DBSession, "s-seed-fail")
        assert row is not None
        assert row.worktree_seed_status == "failed"


def test_schedule_seed_task_runs_inline_without_loop(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-sched", project_path=repo)
    _seed_session_row("s-sched", str(repo))
    schedule_seed_task(
        session_id="s-sched",
        project_path=repo,
        worktree_path=info.worktree_path,
    )
    # With no running loop, schedule_seed_task is synchronous.
    with get_db() as db:
        row = db.get(DBSession, "s-sched")
        assert row is not None
        assert row.worktree_seed_status == "ready"
