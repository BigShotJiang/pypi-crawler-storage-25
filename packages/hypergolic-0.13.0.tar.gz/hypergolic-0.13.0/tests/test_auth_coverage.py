"""Targeted coverage for hypergolic.auth missing lines 28, 34, 40."""

import hypergolic.auth as auth_module
from hypergolic.auth import (
    get_session_token,
    init_bootstrap_token,
    redeem_bootstrap_token,
    verify_token,
)


def test_redeem_bootstrap_token_wrong_value_returns_none():
    """Line 28: redeem returns None when value doesn't match (token is cleared anyway)."""
    init_bootstrap_token()  # sets a real bootstrap token
    result = redeem_bootstrap_token("wrong-value")
    assert result is None
    # Bootstrap token should be cleared even on failure
    assert auth_module._bootstrap_token == ""


def test_get_session_token_returns_current_session_token():
    """Line 34: get_session_token() returns the current _session_token."""
    # Redeem a token to set _session_token
    init_bootstrap_token()
    token = auth_module._bootstrap_token
    session_tok = redeem_bootstrap_token(token)
    assert session_tok is not None

    result = get_session_token()
    assert result == session_tok
    assert result == auth_module._session_token


def test_verify_token_valid_token_returns_true():
    """Line 40: secrets.compare_digest path — valid token."""
    init_bootstrap_token()
    boot_token = auth_module._bootstrap_token
    session_tok = redeem_bootstrap_token(boot_token)
    assert session_tok is not None

    result = verify_token(session_tok)
    assert result is True


def test_verify_token_wrong_value_returns_false():
    """Line 40: secrets.compare_digest path — wrong value."""
    # Ensure _session_token is non-empty so we reach line 40
    init_bootstrap_token()
    boot_token = auth_module._bootstrap_token
    redeem_bootstrap_token(boot_token)
    # _session_token is now set
    assert auth_module._session_token != ""

    result = verify_token("definitely-wrong-token")
    assert result is False


def test_get_session_token_before_any_redemption():
    """get_session_token returns empty string when no token has been redeemed."""
    original = auth_module._session_token
    try:
        auth_module._session_token = ""
        result = get_session_token()
        assert result == ""
    finally:
        auth_module._session_token = original
