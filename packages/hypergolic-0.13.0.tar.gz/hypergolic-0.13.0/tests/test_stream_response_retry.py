"""Retry behavior of hypergolic.messages.conversation.retry.stream_response.

Covers the regression where a mid-stream httpx.ReadTimeout (raised after
some bytes have flowed, so it's past APIConnectionError wrapping) was not
in RETRYABLE_EXCEPTIONS and failed the turn instead of retrying.
"""
from unittest.mock import AsyncMock, MagicMock, patch

import httpx
import pytest
from anthropic.types import Message, TextBlock, Usage

from hypergolic.enums import ModelTier
from hypergolic.messages.conversation.retry import (
    RETRYABLE_EXCEPTIONS,
    stream_response,
)
from hypergolic.messages.types import MAX_STREAM_RETRIES, RETRY_BASE_DELAY
from hypergolic.schemas import Session


def _session():
    return Session(
        id="s1",
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path="/tmp/p",
    )


def _final_message():
    return Message(
        id="m1",
        type="message",
        model="claude-sonnet-4-20250514",
        role="assistant",
        content=[TextBlock(type="text", text="ok")],
        stop_reason="end_turn",
        usage=Usage(
            input_tokens=1, output_tokens=1,
            cache_creation_input_tokens=0, cache_read_input_tokens=0,
        ),
    )


class _FakeStream:
    """Async context manager + async iterator matching client.messages.stream()."""

    def __init__(self, *, raise_on_iter: Exception | None = None, final: Message | None = None):
        self._raise = raise_on_iter
        self._final = final

    async def __aenter__(self):
        return self

    async def __aexit__(self, exc_type, exc, tb):
        return False

    def __aiter__(self):
        return self

    async def __anext__(self):
        if self._raise is not None:
            raise self._raise
        raise StopAsyncIteration

    async def get_final_message(self):
        assert self._final is not None
        return self._final


def _client_with_streams(*streams: _FakeStream) -> MagicMock:
    client = MagicMock()
    client.messages = MagicMock()
    client.messages.stream = MagicMock(side_effect=streams)
    return client


def test_read_timeout_is_retryable():
    """httpx.ReadTimeout must be in RETRYABLE_EXCEPTIONS (regression guard)."""
    assert issubclass(httpx.ReadTimeout, tuple(RETRYABLE_EXCEPTIONS))  # type: ignore[arg-type]


@pytest.mark.asyncio
async def test_stream_response_retries_on_read_timeout():
    final = _final_message()
    client = _client_with_streams(
        _FakeStream(raise_on_iter=httpx.ReadTimeout("stalled")),
        _FakeStream(final=final),
    )

    with (
        patch("hypergolic.messages.conversation.retry.asyncio.sleep", new=AsyncMock()),
        patch(
            "hypergolic.messages.conversation.retry.set_session_status_and_broadcast",
            new=AsyncMock(),
        ),
    ):
        result = await stream_response(
            client=client,
            session=_session(),
            prompt=[],
            tool_schemas=[],
            messages=[],
            broadcast=AsyncMock(),
            check_cancelled=lambda: None,
        )

    assert result is final
    assert client.messages.stream.call_count == 2


@pytest.mark.asyncio
async def test_stream_response_uses_linear_backoff():
    """Delays between attempts are linear: 1s, 2s, 3s (not exponential)."""
    final = _final_message()
    client = _client_with_streams(
        _FakeStream(raise_on_iter=httpx.ReadTimeout("")),
        _FakeStream(raise_on_iter=httpx.ReadTimeout("")),
        _FakeStream(raise_on_iter=httpx.ReadTimeout("")),
        _FakeStream(final=final),
    )
    sleep_mock = AsyncMock()

    with (
        patch("hypergolic.messages.conversation.retry.asyncio.sleep", new=sleep_mock),
        patch(
            "hypergolic.messages.conversation.retry.set_session_status_and_broadcast",
            new=AsyncMock(),
        ),
    ):
        result = await stream_response(
            client=client,
            session=_session(),
            prompt=[],
            tool_schemas=[],
            messages=[],
            broadcast=AsyncMock(),
            check_cancelled=lambda: None,
        )

    assert result is final
    assert client.messages.stream.call_count == 4
    delays = [call.args[0] for call in sleep_mock.call_args_list]
    assert delays == [
        RETRY_BASE_DELAY * 1,
        RETRY_BASE_DELAY * 2,
        RETRY_BASE_DELAY * 3,
    ]


def test_max_stream_retries_allows_three_retries():
    """Pin the configured retry count so the knob can't silently regress."""
    assert MAX_STREAM_RETRIES == 3
