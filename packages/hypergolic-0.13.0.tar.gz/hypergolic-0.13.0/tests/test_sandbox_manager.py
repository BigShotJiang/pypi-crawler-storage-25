"""Tests for hypergolic.sandbox.manager."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.sandbox.manager import (
    ExecResult,
    SandboxError,
    SandboxUnavailableError,
    _compose_project_name,
    _find_default_service,
    _get_sandbox,
    _parse_config,
    _run_compose,
    _run_docker,
    _set_sandbox_status,
    cleanup_orphaned_sandboxes,
    cleanup_session_sandboxes,
    ensure_docker_available,
    exec_in_sandbox,
    start_sandbox,
    stop_sandbox,
)
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSandbox
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _create_sandbox_row(
    session_id: str,
    tool_id: str = "my-tool",
    status: str = "running",
    config_path: str = "/fake/sandbox.yaml",
    compose_project: str = "hg-my_tool-abc123",
) -> DBSandbox:
    with get_db() as db:
        sandbox = DBSandbox(
            session_id=session_id,
            tool_id=tool_id,
            status=status,
            config_path=config_path,
            compose_project=compose_project,
        )
        db.add(sandbox)
        db.flush()
        return sandbox


# ---------------------------------------------------------------------------
# _compose_project_name
# ---------------------------------------------------------------------------


def test_compose_project_name_format():
    name = _compose_project_name("abc123-def456", "my-tool")
    assert name.startswith("hg-my_tool-")
    assert "-" not in name.split("-", 2)[2]  # session part has no hyphens


def test_compose_project_name_truncates_session():
    long_session = "a" * 40
    name = _compose_project_name(long_session, "tool")
    # session portion should be at most 12 chars
    parts = name.split("-")
    assert len(parts[-1]) <= 12


# ---------------------------------------------------------------------------
# _parse_config
# ---------------------------------------------------------------------------


def test_parse_config_file_not_found():
    with pytest.raises(SandboxError, match="Sandbox config not found"):
        _parse_config("/nonexistent/path.yaml")


def test_parse_config_invalid_no_services(tmp_path):
    config_file = tmp_path / "bad.yaml"
    config_file.write_text("key: value\n")
    with pytest.raises(SandboxError, match="Invalid sandbox config"):
        _parse_config(str(config_file))


def test_parse_config_empty_file(tmp_path):
    config_file = tmp_path / "empty.yaml"
    config_file.write_text("")
    with pytest.raises(SandboxError, match="Invalid sandbox config"):
        _parse_config(str(config_file))


def test_parse_config_valid(tmp_path):
    config_file = tmp_path / "valid.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")
    config = _parse_config(str(config_file))
    assert "services" in config


# ---------------------------------------------------------------------------
# _find_default_service
# ---------------------------------------------------------------------------


def test_find_default_service_with_label_dict():
    config = {
        "services": {
            "app": {"image": "ubuntu", "labels": {"hypergolic.default": "true"}},
            "db": {"image": "postgres"},
        }
    }
    assert _find_default_service(config) == "app"


def test_find_default_service_with_label_list():
    config = {
        "services": {
            "app": {"image": "ubuntu", "labels": ["hypergolic.default=true"]},
        }
    }
    assert _find_default_service(config) == "app"


def test_find_default_service_fallback_to_first_non_proxy():
    config = {
        "services": {
            "proxy": {"image": "nginx", "labels": {"hypergolic.role": "proxy"}},
            "app": {"image": "ubuntu"},
        }
    }
    assert _find_default_service(config) == "app"


def test_find_default_service_fallback_to_first_non_proxy_list_label():
    config = {
        "services": {
            "proxy": {"image": "nginx", "labels": ["hypergolic.role=proxy"]},
            "app": {"image": "ubuntu"},
        }
    }
    assert _find_default_service(config) == "app"


def test_find_default_service_no_suitable_service():
    config = {"services": {}}
    with pytest.raises(SandboxError, match="No suitable service"):
        _find_default_service(config)


def test_find_default_service_all_proxies():
    config = {
        "services": {
            "proxy1": {"image": "nginx", "labels": {"hypergolic.role": "proxy"}},
        }
    }
    # Only proxy, no non-proxy — should raise
    with pytest.raises(SandboxError, match="No suitable service"):
        _find_default_service(config)


# ---------------------------------------------------------------------------
# _run_docker
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_run_docker_success():
    mock_proc = MagicMock()
    mock_proc.returncode = 0
    mock_proc.communicate = AsyncMock(return_value=(b"output", b""))

    with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)):
        result = await _run_docker("info")

    assert result.returncode == 0
    assert result.stdout == "output"


@pytest.mark.anyio
async def test_run_docker_timeout():
    mock_proc = MagicMock()
    mock_proc.kill = MagicMock()
    mock_proc.communicate = AsyncMock(return_value=(b"", b""))

    with (
        patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)),
        patch(
            "hypergolic.sandbox.manager.asyncio.wait_for",
            AsyncMock(side_effect=asyncio.TimeoutError()),
        ),
    ):
        with pytest.raises(SandboxError, match="timed out"):
            await _run_docker("info", timeout=1)


@pytest.mark.anyio
async def test_run_docker_none_returncode():
    """returncode=None gets normalized to 0."""
    mock_proc = MagicMock()
    mock_proc.returncode = None
    mock_proc.communicate = AsyncMock(return_value=(b"out", b"err"))

    with patch("asyncio.create_subprocess_exec", AsyncMock(return_value=mock_proc)):
        result = await _run_docker("info")

    assert result.returncode == 0


# ---------------------------------------------------------------------------
# ensure_docker_available
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_ensure_docker_available_ok():
    good_result = ExecResult(stdout="Docker info...", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_result)):
        await ensure_docker_available()  # No exception


@pytest.mark.anyio
async def test_ensure_docker_available_not_running():
    bad_result = ExecResult(stdout="", stderr="Cannot connect", returncode=1)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=bad_result)):
        with pytest.raises(SandboxUnavailableError, match="not running"):
            await ensure_docker_available()


@pytest.mark.anyio
async def test_ensure_docker_available_file_not_found():
    with patch(
        "hypergolic.sandbox.manager._run_docker",
        AsyncMock(side_effect=FileNotFoundError()),
    ):
        with pytest.raises(SandboxUnavailableError, match="not found"):
            await ensure_docker_available()


@pytest.mark.anyio
async def test_ensure_docker_available_sandbox_error():
    with patch(
        "hypergolic.sandbox.manager._run_docker",
        AsyncMock(side_effect=SandboxError("timed out")),
    ):
        with pytest.raises(SandboxUnavailableError, match="not responding"):
            await ensure_docker_available()


# ---------------------------------------------------------------------------
# _get_sandbox / _set_sandbox_status
# ---------------------------------------------------------------------------


def test_get_sandbox_returns_none_when_not_exists():
    make_project("p1")
    sid = make_session(project_id="p1")
    result = _get_sandbox(sid, "nonexistent-tool")
    assert result is None


def test_get_sandbox_returns_row():
    make_project("p1")
    sid = make_session(project_id="p1")
    _create_sandbox_row(sid, tool_id="my-tool")
    result = _get_sandbox(sid, "my-tool")
    assert result is not None
    assert result.tool_id == "my-tool"


def test_set_sandbox_status():
    make_project("p1")
    sid = make_session(project_id="p1")
    sandbox = _create_sandbox_row(sid, status="running")
    _set_sandbox_status(sandbox.id, "stopped")
    updated = _get_sandbox(sid, "my-tool")
    assert updated is not None
    assert updated.status == "stopped"


# ---------------------------------------------------------------------------
# start_sandbox
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_start_sandbox_already_running():
    """Returns existing project name when sandbox is already running."""
    make_project("p1")
    sid = make_session(project_id="p1")
    _create_sandbox_row(
        sid, tool_id="t1", status="running", compose_project="existing-project"
    )

    good_docker = ExecResult(stdout="", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_docker)):
        result = await start_sandbox(sid, "t1", "/fake/path", "/workspace")

    assert result == "existing-project"


@pytest.mark.anyio
async def test_start_sandbox_creates_and_starts(tmp_path):
    """start_sandbox creates a sandbox row and starts the container."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    good_docker = ExecResult(stdout="", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_docker)):
        result = await start_sandbox(sid, "new-tool", str(config_file), str(tmp_path))

    assert result.startswith("hg-")
    # Verify DB row exists
    sandbox = _get_sandbox(sid, "new-tool")
    assert sandbox is not None
    assert sandbox.status == "running"


@pytest.mark.anyio
async def test_start_sandbox_docker_fails(tmp_path):
    """SandboxError raised when docker compose up fails."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    good_info = ExecResult(stdout="", stderr="", returncode=0)
    fail_compose = ExecResult(stdout="", stderr="Container failed", returncode=1)

    call_count = 0

    async def mock_run(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:  # docker info
            return good_info
        return fail_compose  # docker compose up

    with (
        patch("hypergolic.sandbox.manager._run_docker", side_effect=mock_run),
        pytest.raises(SandboxError, match="Failed to start"),
    ):
        await start_sandbox(sid, "fail-tool", str(config_file), str(tmp_path))

    # Status should be 'error'
    sandbox = _get_sandbox(sid, "fail-tool")
    assert sandbox is not None
    assert sandbox.status == "error"


@pytest.mark.anyio
async def test_start_sandbox_existing_non_running(tmp_path):
    """Existing sandbox in error state gets restarted."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, tool_id="t2", status="error",
        config_path=str(config_file), compose_project="old-project"
    )

    good_docker = ExecResult(stdout="", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_docker)):
        result = await start_sandbox(sid, "t2", str(config_file), str(tmp_path))

    sandbox = _get_sandbox(sid, "t2")
    assert sandbox is not None
    assert sandbox.status == "running"


@pytest.mark.anyio
async def test_start_sandbox_unexpected_exception(tmp_path):
    """Non-SandboxError exceptions are wrapped in SandboxError."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    call_count = 0

    async def mock_run(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        if call_count == 1:
            return ExecResult(stdout="", stderr="", returncode=0)  # docker info
        raise RuntimeError("unexpected")

    with (
        patch("hypergolic.sandbox.manager._run_docker", side_effect=mock_run),
        pytest.raises(SandboxError, match="unexpected"),
    ):
        await start_sandbox(sid, "err-tool", str(config_file), str(tmp_path))


# ---------------------------------------------------------------------------
# exec_in_sandbox
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_exec_in_sandbox_no_sandbox_row():
    make_project("p1")
    sid = make_session(project_id="p1")

    with pytest.raises(SandboxError, match="No sandbox found"):
        await exec_in_sandbox(sid, "no-tool", "ls")


@pytest.mark.anyio
async def test_exec_in_sandbox_error_status():
    make_project("p1")
    sid = make_session(project_id="p1")
    _create_sandbox_row(sid, status="error")

    with pytest.raises(SandboxError, match="error state"):
        await exec_in_sandbox(sid, "my-tool", "ls")


@pytest.mark.anyio
async def test_exec_in_sandbox_not_running_status():
    make_project("p1")
    sid = make_session(project_id="p1")
    _create_sandbox_row(sid, status="pending")

    with pytest.raises(SandboxError, match="'pending' state"):
        await exec_in_sandbox(sid, "my-tool", "ls")


@pytest.mark.anyio
async def test_exec_in_sandbox_no_compose_project():
    make_project("p1")
    sid = make_session(project_id="p1")
    with get_db() as db:
        sandbox = DBSandbox(
            session_id=sid,
            tool_id="no-proj",
            status="running",
            config_path="/fake",
            compose_project=None,
        )
        db.add(sandbox)

    with pytest.raises(SandboxError, match="no compose project"):
        await exec_in_sandbox(sid, "no-proj", "ls")


@pytest.mark.anyio
async def test_exec_in_sandbox_success(tmp_path):
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, status="running",
        config_path=str(config_file),
        compose_project="hg-my_tool-abc",
    )

    exec_result = ExecResult(stdout="hello", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=exec_result)):
        result = await exec_in_sandbox(sid, "my-tool", "echo hello")

    assert result.stdout == "hello"
    assert result.returncode == 0


# ---------------------------------------------------------------------------
# stop_sandbox
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_stop_sandbox_no_row():
    make_project("p1")
    sid = make_session(project_id="p1")
    # Should not raise
    await stop_sandbox(sid, "nonexistent")


@pytest.mark.anyio
async def test_stop_sandbox_already_stopped():
    make_project("p1")
    sid = make_session(project_id="p1")
    _create_sandbox_row(sid, status="stopped")
    # Should return early without calling docker
    with patch("hypergolic.sandbox.manager._run_docker") as mock:
        await stop_sandbox(sid, "my-tool")
    mock.assert_not_called()


@pytest.mark.anyio
async def test_stop_sandbox_running(tmp_path):
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, status="running",
        config_path=str(config_file),
        compose_project="hg-my_tool-abc",
    )

    good_result = ExecResult(stdout="", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_result)):
        await stop_sandbox(sid, "my-tool")

    sandbox = _get_sandbox(sid, "my-tool")
    assert sandbox is not None
    assert sandbox.status == "stopped"


@pytest.mark.anyio
async def test_stop_sandbox_down_fails(tmp_path):
    """Even if docker down fails, sandbox status is set to stopped."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, status="running",
        config_path=str(config_file),
        compose_project="hg-my_tool-abc",
    )

    fail_result = ExecResult(stdout="", stderr="Error", returncode=1)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=fail_result)):
        await stop_sandbox(sid, "my-tool")  # Should not raise

    sandbox = _get_sandbox(sid, "my-tool")
    assert sandbox is not None
    assert sandbox.status == "stopped"


@pytest.mark.anyio
async def test_stop_sandbox_exception_still_marks_stopped(tmp_path):
    """If docker raises an exception, sandbox is still marked stopped."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, status="running",
        config_path=str(config_file),
        compose_project="hg-my_tool-abc",
    )

    with patch(
        "hypergolic.sandbox.manager._run_docker",
        AsyncMock(side_effect=Exception("boom")),
    ):
        await stop_sandbox(sid, "my-tool")  # Should not raise

    sandbox = _get_sandbox(sid, "my-tool")
    assert sandbox is not None
    assert sandbox.status == "stopped"


# ---------------------------------------------------------------------------
# cleanup_session_sandboxes
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_cleanup_session_sandboxes(tmp_path):
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, tool_id="t1", status="running",
        config_path=str(config_file), compose_project="hg-t1-abc"
    )
    _create_sandbox_row(
        sid, tool_id="t2", status="pending",
        config_path=str(config_file), compose_project="hg-t2-abc"
    )

    good_result = ExecResult(stdout="", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_result)):
        await cleanup_session_sandboxes(sid)

    r1 = _get_sandbox(sid, "t1")
    r2 = _get_sandbox(sid, "t2")
    assert r1 is not None and r1.status == "stopped"
    assert r2 is not None and r2.status == "stopped"


# ---------------------------------------------------------------------------
# cleanup_orphaned_sandboxes
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_cleanup_orphaned_sandboxes_none():
    """Does nothing when no orphaned sandboxes exist."""
    with patch("hypergolic.sandbox.manager.stop_sandbox") as mock_stop:
        await cleanup_orphaned_sandboxes()
    mock_stop.assert_not_called()


@pytest.mark.anyio
async def test_cleanup_orphaned_sandboxes_cleans_up(tmp_path):
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, tool_id="orphan", status="running",
        config_path=str(config_file), compose_project="hg-orphan-abc"
    )

    good_result = ExecResult(stdout="", stderr="", returncode=0)
    with patch("hypergolic.sandbox.manager._run_docker", AsyncMock(return_value=good_result)):
        await cleanup_orphaned_sandboxes()

    sandbox = _get_sandbox(sid, "orphan")
    assert sandbox is not None
    assert sandbox.status == "stopped"


@pytest.mark.anyio
async def test_cleanup_orphaned_sandboxes_stop_fails(tmp_path):
    """When stop_sandbox raises, the sandbox is force-marked stopped."""
    make_project("p1")
    sid = make_session(project_id="p1")

    config_file = tmp_path / "sandbox.yaml"
    config_file.write_text("services:\n  app:\n    image: ubuntu\n")

    _create_sandbox_row(
        sid, tool_id="orphan2", status="running",
        config_path=str(config_file), compose_project="hg-orphan2-abc"
    )

    with patch(
        "hypergolic.sandbox.manager.stop_sandbox",
        AsyncMock(side_effect=Exception("stop failed")),
    ):
        await cleanup_orphaned_sandboxes()  # Should not raise

    # Status should be force-set to stopped
    sandbox = _get_sandbox(sid, "orphan2")
    assert sandbox is not None
    assert sandbox.status == "stopped"
