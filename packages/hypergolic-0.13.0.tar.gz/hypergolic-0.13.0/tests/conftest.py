"""Importable helpers for seeding the test database.

Fixtures live at the repo root (`conftest.py`) so they are visible to
colocated tests under `hypergolic/**/tests/`. This module holds regular
functions that tests import explicitly:

    from tests.conftest import make_project, make_session
"""
from __future__ import annotations

import uuid

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBArtifact, DBMessage, DBProject, DBSession


def make_project(pid: str = "proj-1", name: str = "Test", path: str = "/tmp/test") -> DBProject:
    with get_db() as db:
        p = DBProject(id=pid, name=name, path=path)
        db.add(p)
        db.flush()
        return p


def make_session(
    project_id: str = "proj-1",
    sid: str | None = None,
    model_tier: str = "Medium",
    role: str = "generalist",
    parent_id: str | None = None,
) -> str:
    session_id = sid or str(uuid.uuid4())
    with get_db() as db:
        db.add(DBSession(
            id=session_id,
            model_tier=model_tier,
            system_prompt=[],
            role=role,
            project_id=project_id,
            parent_id=parent_id,
        ))
    return session_id


def make_message(
    session_id: str,
    role: str = "user",
    text: str = "hello",
    model: str | None = None,
    usage: dict | None = None,
) -> str:
    with get_db() as db:
        m = DBMessage(
            content=[{"type": "text", "text": text}],
            session_id=session_id,
            role=role,
            model=model,
            usage=usage,
        )
        db.add(m)
        db.flush()
        return m.id


def make_artifact(
    session_id: str,
    workflow_id: str = "wf-1",
    state_id: str = "state-1",
    outcome: str = "success",
    artifact_id: str = "art-1",
    content: dict | None = None,
) -> str:
    with get_db() as db:
        a = DBArtifact(
            session_id=session_id,
            workflow_id=workflow_id,
            state_id=state_id,
            outcome=outcome,
            artifact_id=artifact_id,
            content=content or {"result": "ok"},
        )
        db.add(a)
        db.flush()
        return a.id
