"""Tests for hypergolic.skills.resolver."""

from unittest.mock import patch

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.skills.resolver import (
    get_active_skill_ids,
    get_skill_prompt_content,
    resolve_roles,
    resolve_session_skills,
    resolve_skills,
)
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.primitives import (
    Role,
    Skill,
    Workflow,
    WorkflowState,
)
from hypergolic.toolkit.project import Project
from tests._factories import build_session as _session, build_skill as _skill
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# resolve_roles
# ---------------------------------------------------------------------------


def test_resolve_roles_empty():
    app = App()
    set_app(app)
    roles = resolve_roles()
    assert roles == []


def test_resolve_roles_returns_roles():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="test"))
    app.register_role(Role(id="worker", name="Worker", prompt="worker prompt"))
    set_app(app)

    roles = resolve_roles()
    ids = [r["id"] for r in roles]
    assert "generalist" in ids
    assert "worker" in ids


def test_resolve_roles_includes_tools():
    app = App()
    from hypergolic.toolkit.primitives import Tool as ToolkitTool
    async def _run(ctx): ...
    tool = ToolkitTool(
        id="my-tool",
        name="My Tool",
        description="d",
        run=_run,
    )
    role = Role(id="generalist", name="Generalist", prompt="test", tools=[tool])
    app.register_role(role)
    set_app(app)

    roles = resolve_roles()
    assert any("my-tool" in r["tools"] for r in roles)


def test_resolve_roles_includes_skills():
    app = App()
    skill = _skill("sk-1")
    role = Role(id="generalist", name="Generalist", prompt="test", skills=[skill])
    app.register_role(role)
    set_app(app)

    roles = resolve_roles()
    generalist = next(r for r in roles if r["id"] == "generalist")
    assert "sk-1" in generalist["skills"]


def test_resolve_roles_deduplicates():
    app = App()
    app.register_role(Role(id="dupe", name="Dupe", prompt="test"))
    app.register_role(Role(id="dupe", name="Dupe Again", prompt="test"))
    set_app(app)

    roles = resolve_roles()
    ids = [r["id"] for r in roles]
    assert ids.count("dupe") == 1


def test_resolve_roles_with_prompt_path_expanded():
    """prompt_path is expanded when present."""
    app = App()
    role = Role(id="r1", name="R1", prompt_path="~/some/path.md")
    app.register_role(role)
    set_app(app)

    roles = resolve_roles()
    r = next(r for r in roles if r["id"] == "r1")
    # Expanded path should not have a tilde
    assert "~" not in r["prompt_path"]


# ---------------------------------------------------------------------------
# resolve_skills
# ---------------------------------------------------------------------------


def test_resolve_skills_empty():
    app = App()
    set_app(app)
    skills = resolve_skills()
    assert skills == []


def test_resolve_skills_from_app():
    app = App()
    app.register_skill(_skill("app-sk", prompt="p"))
    set_app(app)

    skills = resolve_skills()
    ids = [s["id"] for s in skills]
    assert "app-sk" in ids


# ---------------------------------------------------------------------------
# get_skill_prompt_content
# ---------------------------------------------------------------------------


def test_get_skill_prompt_content_found():
    app = App()
    app.register_skill(_skill("sk-test", name="Test Skill", prompt="The prompt text"))
    set_app(app)

    result = get_skill_prompt_content("sk-test")
    assert result is not None
    name, content = result
    assert name == "Test Skill"
    assert content == "The prompt text"


def test_get_skill_prompt_content_not_found():
    app = App()
    set_app(app)

    result = get_skill_prompt_content("nonexistent")
    assert result is None


def test_get_skill_prompt_content_skill_no_prompt():
    """Skill exists but has no prompt — returns (name, None)."""
    app = App()
    app.register_skill(Skill(
        id="no-prompt-sk",
        name="No Prompt Skill",
        description="d",
        # no prompt, no prompt_path, no prompt_fn
    ))
    set_app(app)

    result = get_skill_prompt_content("no-prompt-sk")
    assert result is not None
    name, content = result
    assert name == "No Prompt Skill"
    assert content is None


def test_get_skill_prompt_content_skill_in_role():
    """Skill registered on a role is found by get_skill_prompt_content."""
    app = App()
    sk = _skill("role-sk", name="Role Skill", prompt="Role skill prompt")
    role = Role(id="r1", name="R1", prompt="test", skills=[sk])
    app.register_role(role)
    set_app(app)

    result = get_skill_prompt_content("role-sk")
    assert result is not None
    name, content = result
    assert name == "Role Skill"
    assert content == "Role skill prompt"


# ---------------------------------------------------------------------------
# get_active_skill_ids
# ---------------------------------------------------------------------------


def test_get_active_skill_ids_empty():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")

    result = get_active_skill_ids("s-1")
    assert result == set()


def test_get_active_skill_ids_with_records():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-a"))
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-b"))

    result = get_active_skill_ids("s-1")
    assert result == {"sk-a", "sk-b"}


# ---------------------------------------------------------------------------
# resolve_session_skills
# ---------------------------------------------------------------------------


def test_resolve_session_skills_app_level():
    app = App()
    app.register_skill(_skill("app-sk"))
    set_app(app)
    session = _session()

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "app-sk" in ids


def test_resolve_session_skills_project_level():
    app = App()
    proj = Project(
        id="p-1", name="P", description="d", git_root="/tmp/p",
        skills=[_skill("proj-sk")],
    )
    app.register_project(proj)
    set_app(app)
    session = _session(project_id="p-1")

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "proj-sk" in ids


def test_resolve_session_skills_role_level():
    app = App()
    role = Role(id="my-role", name="My Role", prompt="test", skills=[_skill("role-sk")])
    app.register_role(role)
    set_app(app)
    session = _session(role="my-role")

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "role-sk" in ids


def test_resolve_session_skills_workflow_level():
    app = App()
    wf_skill = _skill("wf-sk")
    state_skill = _skill("state-sk")
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="st-1",
        states=[WorkflowState(id="st-1", name="S", prompt="p", skills=[state_skill])],
        skills=[wf_skill],
    )
    app.register_workflow(wf)
    set_app(app)
    session = _session()

    with patch(
        "hypergolic.workflows.resolver.get_session_workflow",
        return_value=("wf-1", "st-1"),
    ):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    assert "wf-sk" in ids
    assert "state-sk" in ids


def test_resolve_session_skills_active_skill_children():
    app = App()
    child = _skill("child-sk")
    parent = Skill(
        id="parent-sk",
        name="Parent",
        description="d",
        skills=[child],
    )
    app.register_skill(parent)
    set_app(app)
    session = _session(active_skill_ids={"parent-sk"})

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = {s["id"] for s in skills}
    # child-sk should appear because parent is active
    assert "child-sk" in ids


def test_resolve_session_skills_deduplicates():
    app = App()
    sk = _skill("shared-sk")
    app.register_skill(sk)
    proj = Project(
        id="p-1", name="P", description="d", git_root="/tmp/p",
        skills=[sk],
    )
    app.register_project(proj)
    set_app(app)
    session = _session(project_id="p-1")

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)

    ids = [s["id"] for s in skills]
    assert ids.count("shared-sk") == 1


def test_resolve_session_skills_no_project():
    """When the session\'s project is not in the app, project skills are skipped."""
    app = App()
    set_app(app)
    session = _session(project_id="unknown-project")

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)
    # Should not raise
    assert isinstance(skills, list)


def test_resolve_session_skills_no_role():
    """When the session\'s role is not in the app, role skills are skipped."""
    app = App()
    set_app(app)
    session = _session(role="unknown-role")

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)
    assert isinstance(skills, list)


def test_resolve_session_skills_workflow_not_found_in_resolver():
    """When active workflow doesn\'t exist in app config, no crash."""
    app = App()
    set_app(app)
    session = _session()

    with patch(
        "hypergolic.workflows.resolver.get_session_workflow",
        return_value=("nonexistent-wf", "st-1"),
    ):
        skills = resolve_session_skills(session)
    assert isinstance(skills, list)


def test_resolve_session_skills_workflow_active_skill_not_in_app():
    """Active skill_id not in app — skipped gracefully."""
    app = App()
    set_app(app)
    session = _session(active_skill_ids={"ghost-parent"})

    with patch("hypergolic.workflows.resolver.get_session_workflow", return_value=None):
        skills = resolve_session_skills(session)
    assert isinstance(skills, list)
