from datetime import datetime, timedelta, timezone

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBProject, DBSession


def _seed_project(pid="proj-1", name="TestProject", path="/tmp/test"):
    with get_db() as db:
        db.add(DBProject(id=pid, name=name, path=path))


def _add_session(sid, project_id="proj-1", updated_at=None):
    with get_db() as db:
        s = DBSession(
            id=sid, model_tier="Medium", system_prompt=[],
            project_id=project_id,
        )
        if updated_at:
            s.updated_at = updated_at
        db.add(s)


def _add_message(session_id, role, text, msg_id=None):
    with get_db() as db:
        kwargs = {"content": [{"type": "text", "text": text}],
                  "session_id": session_id, "role": role}
        if msg_id:
            kwargs["id"] = msg_id
        db.add(DBMessage(**kwargs))


def test_search_matching_query(api_client):
    _seed_project()
    _add_session("s1")
    _add_message("s1", "user", "hello world")

    resp = api_client.post("/api/sessions/search", json={"query": "hello"})
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["matches"]) == 1
    m = data["matches"][0]
    assert m["session_id"] == "s1"
    assert m["project_id"] == "proj-1"
    assert m["project_name"] == "TestProject"
    assert m["model_tier"] == "Medium"
    assert "hello world" in m["match_text"]
    assert m["match_role"] == "user"
    assert m["message_count"] == 1


def test_search_no_matches(api_client):
    _seed_project()
    _add_session("s1")
    _add_message("s1", "user", "hello world")

    resp = api_client.post("/api/sessions/search", json={"query": "zzzznotfound"})
    assert resp.status_code == 200
    assert resp.json()["matches"] == []


def test_search_project_filter(api_client):
    _seed_project("p1", "Proj1", "/tmp/p1")
    _seed_project("p2", "Proj2", "/tmp/p2")
    _add_session("s1", project_id="p1")
    _add_session("s2", project_id="p2")
    _add_message("s1", "user", "common keyword")
    _add_message("s2", "user", "common keyword")

    resp = api_client.post(
        "/api/sessions/search", json={"query": "common", "project_id": "p1"}
    )
    assert resp.status_code == 200
    matches = resp.json()["matches"]
    assert len(matches) == 1
    assert matches[0]["session_id"] == "s1"
    assert matches[0]["project_name"] == "Proj1"


def test_search_deduplication(api_client):
    _seed_project()
    _add_session("s1")
    _add_message("s1", "user", "the keyword here")
    _add_message("s1", "assistant", "the keyword again")
    _add_message("s1", "user", "keyword third time")

    resp = api_client.post("/api/sessions/search", json={"query": "keyword"})
    assert resp.status_code == 200
    matches = resp.json()["matches"]
    assert len(matches) == 1


def test_search_max_results(api_client):
    _seed_project()
    for i in range(5):
        sid = f"s{i}"
        _add_session(sid)
        _add_message(sid, "user", "findme")

    resp = api_client.post(
        "/api/sessions/search", json={"query": "findme", "max_results": 2}
    )
    assert resp.status_code == 200
    assert len(resp.json()["matches"]) == 2


def test_search_match_text_truncated(api_client):
    _seed_project()
    _add_session("s1")
    long_text = "x" * 300
    _add_message("s1", "user", long_text)

    resp = api_client.post("/api/sessions/search", json={"query": "xxx"})
    assert resp.status_code == 200
    match_text = resp.json()["matches"][0]["match_text"]
    assert len(match_text) == 200


def test_search_first_message_populated(api_client):
    _seed_project()
    _add_session("s1")
    _add_message("s1", "assistant", "searchable response")
    _add_message("s1", "user", "my first user message")

    resp = api_client.post("/api/sessions/search", json={"query": "searchable"})
    assert resp.status_code == 200
    m = resp.json()["matches"][0]
    assert m["first_message"] == "my first user message"
    assert m["match_role"] == "assistant"


def test_search_first_message_none_when_no_user_messages(api_client):
    _seed_project()
    _add_session("s1")
    _add_message("s1", "assistant", "only assistant searchterm")

    resp = api_client.post("/api/sessions/search", json={"query": "searchterm"})
    assert resp.status_code == 200
    assert resp.json()["matches"][0]["first_message"] is None


def test_search_string_content_blocks(api_client):
    """Cover the branch where content blocks are plain strings."""
    _seed_project()
    _add_session("s1")
    with get_db() as db:
        db.add(DBMessage(
            content=["plain string searchword"],
            session_id="s1", role="user",
        ))

    resp = api_client.post("/api/sessions/search", json={"query": "searchword"})
    assert resp.status_code == 200
    matches = resp.json()["matches"]
    assert len(matches) == 1
    assert "plain string searchword" in matches[0]["match_text"]


def test_search_ordered_by_updated_at_desc(api_client):
    _seed_project()
    now = datetime.now(tz=timezone.utc)
    _add_session("s-old", updated_at=now - timedelta(hours=2))
    _add_session("s-new", updated_at=now)
    _add_session("s-mid", updated_at=now - timedelta(hours=1))
    _add_message("s-old", "user", "target")
    _add_message("s-new", "user", "target")
    _add_message("s-mid", "user", "target")

    resp = api_client.post("/api/sessions/search", json={"query": "target"})
    assert resp.status_code == 200
    ids = [m["session_id"] for m in resp.json()["matches"]]
    assert ids == ["s-new", "s-mid", "s-old"]
