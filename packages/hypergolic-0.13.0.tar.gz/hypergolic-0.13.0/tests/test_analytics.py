from datetime import datetime, timedelta, timezone

from hypergolic.analytics.queries import (
    build_where_clause,
    compute_cost,
    date_filter,
)
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBSession


def _seed(project_id="proj-1", model_tier="High"):
    with get_db() as db:
        session = DBSession(
            model_tier=model_tier,
            system_prompt=[],
            role="generalist",
            status="idle",
            project_id=project_id,
        )
        db.add(session)
        db.flush()
        db.add(
            DBMessage(
                session_id=session.id,
                role="assistant",
                model="claude",
                content=[
                    {
                        "type": "tool_use",
                        "name": "read_files",
                        "id": "x",
                        "input": {},
                    }
                ],
                usage={
                    "input_tokens": 1000,
                    "output_tokens": 500,
                    "cache_creation_input_tokens": 200,
                    "cache_read_input_tokens": 100,
                },
            )
        )
        db.flush()
        return session.id


# ── Unit tests for helper functions ──────────────────────────────────────


def test_date_filter_none():
    assert date_filter(None) is None


def test_date_filter_returns_datetime():
    result = date_filter(7)
    assert isinstance(result, datetime)
    assert result.tzinfo is not None
    expected = datetime.now(timezone.utc) - timedelta(days=7)
    assert abs((result - expected).total_seconds()) < 2


def test_compute_cost_known_values():
    # High tier: input=5.0, output=25.0, cache_write=6.25, cache_read=0.50
    cost = compute_cost(1_000_000, 1_000_000, 1_000_000, 1_000_000, "High")
    expected = 5.0 + 25.0 + 6.25 + 0.50
    assert cost == expected


def test_compute_cost_unknown_tier_defaults_to_high():
    cost_unknown = compute_cost(1000, 500, 200, 100, "Unknown")
    cost_high = compute_cost(1000, 500, 200, 100, "High")
    assert cost_unknown == cost_high


def test_build_where_clause_no_filters():
    where_sql, params = build_where_clause(None, None)
    assert where_sql == ""
    assert params == {}


def test_build_where_clause_project_only():
    where_sql, params = build_where_clause("proj-1", None)
    assert "s.project_id = :project_id" in where_sql
    assert where_sql.startswith("WHERE")
    assert params == {"project_id": "proj-1"}


def test_build_where_clause_cutoff_only():
    cutoff = datetime(2025, 1, 1, tzinfo=timezone.utc)
    where_sql, params = build_where_clause(None, cutoff)
    assert "s.created_at >= :cutoff" in where_sql
    assert where_sql.startswith("WHERE")
    assert params["cutoff"] == cutoff.isoformat()


def test_build_where_clause_both():
    cutoff = datetime(2025, 1, 1, tzinfo=timezone.utc)
    where_sql, params = build_where_clause("proj-1", cutoff)
    assert "s.project_id = :project_id" in where_sql
    assert "s.created_at >= :cutoff" in where_sql
    assert " AND " in where_sql
    assert params["project_id"] == "proj-1"
    assert params["cutoff"] == cutoff.isoformat()


def test_build_where_clause_with_extra():
    where_sql, params = build_where_clause(
        None, None, extra=["m.role = 'assistant'"]
    )
    assert "m.role = 'assistant'" in where_sql
    assert where_sql.startswith("WHERE")
    assert params == {}


# ── Integration tests via api_client ─────────────────────────────────────


def test_summary_empty_db(api_client, seed_project):
    resp = api_client.get("/api/analytics/summary")
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_sessions"] == 0
    assert data["total_messages"] == 0
    assert data["total_cost"] == 0.0


def test_summary_with_data(api_client, seed_project):
    _seed()
    resp = api_client.get("/api/analytics/summary")
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_sessions"] == 1
    assert data["total_messages"] == 1
    assert data["total_input_tokens"] == 1000
    assert data["total_output_tokens"] == 500
    assert data["total_cache_write_tokens"] == 200
    assert data["total_cache_read_tokens"] == 100
    # Verify cost: High tier
    expected_cost = compute_cost(1000, 500, 200, 100, "High")
    assert data["total_cost"] == round(expected_cost, 4)


def test_summary_project_filter(api_client, seed_project):
    # Create a second project and seed data to both
    with get_db() as db:
        from hypergolic.db.models import DBProject

        db.add(DBProject(id="proj-2", name="Other", path="/tmp/other"))
    _seed(project_id="proj-1")
    _seed(project_id="proj-2")

    resp = api_client.get("/api/analytics/summary", params={"project_id": "proj-1"})
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_sessions"] == 1


def test_summary_days_filter(api_client, seed_project):
    _seed()
    # With days=0 (cutoff = now), should return no messages matching
    # Sessions still exist but were created "just now" so they may or may not match
    # Use days=9999 to ensure all data is included
    resp = api_client.get("/api/analytics/summary", params={"days": 9999})
    assert resp.status_code == 200
    data = resp.json()
    assert data["total_sessions"] >= 1


def test_timeseries_empty(api_client, seed_project):
    resp = api_client.get("/api/analytics/timeseries")
    assert resp.status_code == 200
    assert resp.json() == []


def test_timeseries_day_granularity(api_client, seed_project):
    _seed()
    resp = api_client.get("/api/analytics/timeseries")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1
    point = data[0]
    assert "period" in point
    assert point["sessions"] == 1
    assert point["messages"] == 1


def test_timeseries_week_granularity(api_client, seed_project):
    _seed()
    resp = api_client.get(
        "/api/analytics/timeseries", params={"granularity": "week"}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1
    assert "-W" in data[0]["period"]


def test_timeseries_month_granularity(api_client, seed_project):
    _seed()
    resp = api_client.get(
        "/api/analytics/timeseries", params={"granularity": "month"}
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1
    # Month format: YYYY-MM
    assert len(data[0]["period"]) == 7


def test_timeseries_with_filters(api_client, seed_project):
    _seed()
    resp = api_client.get(
        "/api/analytics/timeseries",
        params={"project_id": "proj-1", "days": 9999},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1


def test_tool_usage_empty(api_client, seed_project):
    resp = api_client.get("/api/analytics/tools")
    assert resp.status_code == 200
    assert resp.json() == []


def test_tool_usage_with_data(api_client, seed_project):
    _seed()
    resp = api_client.get("/api/analytics/tools")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1
    assert data[0]["tool_name"] == "read_files"
    assert data[0]["count"] == 1


def test_tool_usage_with_filters(api_client, seed_project):
    _seed()
    resp = api_client.get(
        "/api/analytics/tools",
        params={"project_id": "proj-1", "days": 9999},
    )
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) >= 1
    assert data[0]["tool_name"] == "read_files"
