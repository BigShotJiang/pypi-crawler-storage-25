"""Tests for hypergolic.workflows.engine."""

import pytest
from unittest.mock import AsyncMock, MagicMock, patch
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBArtifact, DBSessionSkill, DBSessionWorkflow
from hypergolic.toolkit.primitives import OutputSchema, Workflow, WorkflowState
from hypergolic.workflows.engine import (
    WorkflowError,
    _activate_state_skills,
    _deactivate_state_skills,
    _transition_skills,
    activate_workflow,
    deactivate_workflow,
    handle_workflow_transition,
    load_artifacts,
)
from tests._factories import (
    build_session as _session,
    build_skill as _skill,
    build_workflow as _workflow,
    build_output_schema as _output_schema,
)
from tests.conftest import make_artifact, make_project, make_session


def _make_broadcast() -> AsyncMock:
    return AsyncMock()


# ---------------------------------------------------------------------------
# activate_workflow
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_activate_workflow_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    broadcast = _make_broadcast()

    with patch("hypergolic.workflows.engine.get_workflow", return_value=None):
        with pytest.raises(WorkflowError, match="not found"):
            await activate_workflow(session, "nonexistent", broadcast)


@pytest.mark.anyio
async def test_activate_workflow_already_active():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    # Seed an existing workflow for the session
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-existing",
            current_state_id="st-x",
        ))

    session = _session()
    broadcast = _make_broadcast()
    wf = _workflow()

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        with pytest.raises(WorkflowError, match="already has active workflow"):
            await activate_workflow(session, "wf-1", broadcast)


@pytest.mark.anyio
async def test_activate_workflow_initial_state_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    broadcast = _make_broadcast()

    # Workflow whose initial_state doesn't match any state in the states list
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="missing-state",
        states=[WorkflowState(id="other-state", name="Other", prompt="p")],
    )

    with (
        patch("hypergolic.workflows.engine.get_workflow", return_value=wf),
        patch("hypergolic.workflows.engine.get_session_workflow", return_value=None),
    ):
        with pytest.raises(WorkflowError, match="Initial state"):
            await activate_workflow(session, "wf-1", broadcast)


@pytest.mark.anyio
async def test_activate_workflow_success():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    broadcast = _make_broadcast()
    wf = _workflow()

    with (
        patch("hypergolic.workflows.engine.get_workflow", return_value=wf),
        patch("hypergolic.workflows.engine.get_session_workflow", return_value=None),
    ):
        await activate_workflow(session, "wf-1", broadcast)

    # DB row created
    with get_db() as db:
        row = db.execute(
            select(DBSessionWorkflow).where(DBSessionWorkflow.session_id == "s-1")
        ).scalar_one_or_none()
    assert row is not None
    assert row.workflow_id == "wf-1"
    assert row.current_state_id == "st-1"

    # Broadcast called once
    broadcast.assert_awaited_once()
    event = broadcast.call_args[0][0]
    assert event.type == "workflow_state_change"


@pytest.mark.anyio
async def test_activate_workflow_with_workflow_level_skills():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    broadcast = _make_broadcast()

    sk = _skill("sk-wf")
    wf = _workflow(wf_skills=[sk])

    with (
        patch("hypergolic.workflows.engine.get_workflow", return_value=wf),
        patch("hypergolic.workflows.engine.get_session_workflow", return_value=None),
    ):
        await activate_workflow(session, "wf-1", broadcast)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    skill_ids = {r.skill_id for r in rows}
    assert "sk-wf" in skill_ids


@pytest.mark.anyio
async def test_activate_workflow_with_state_level_skills():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    broadcast = _make_broadcast()

    sk = _skill("sk-state")
    wf = _workflow(state_skills=[sk])

    with (
        patch("hypergolic.workflows.engine.get_workflow", return_value=wf),
        patch("hypergolic.workflows.engine.get_session_workflow", return_value=None),
    ):
        await activate_workflow(session, "wf-1", broadcast)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    skill_ids = {r.skill_id for r in rows}
    assert "sk-state" in skill_ids


# ---------------------------------------------------------------------------
# handle_workflow_transition
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_transition_workflow_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()

    with patch("hypergolic.workflows.engine.get_workflow", return_value=None):
        result = await handle_workflow_transition(
            session, "wf-missing", "st-1", "done", {}
        )
    assert result.is_error is True
    assert "not found" in result.first_text()


@pytest.mark.anyio
async def test_transition_state_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    wf = _workflow()

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-missing", "done", {}
        )
    assert result.is_error is True
    assert "not found" in result.first_text()


@pytest.mark.anyio
async def test_transition_outcome_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    wf = _workflow(outcome="success")

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "unknown-outcome", {}
        )
    assert result.is_error is True
    assert "not defined" in result.first_text()


@pytest.mark.anyio
async def test_transition_to_next_state():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    # Seed active workflow row
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    session = _session()
    wf = _workflow(next_state_id="st-2")

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}
        )
    assert result.is_error is False
    assert "st-2" in result.first_text()

    # DB updated
    with get_db() as db:
        row = db.execute(
            select(DBSessionWorkflow).where(DBSessionWorkflow.session_id == "s-1")
        ).scalar_one_or_none()
    assert row is not None
    assert row.current_state_id == "st-2"


@pytest.mark.anyio
async def test_transition_to_completion():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    session = _session()
    broadcast = _make_broadcast()
    # next_state=None signals completion
    wf = _workflow(next_state_id=None)

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}, broadcast=broadcast
        )
    assert result.is_error is False
    assert "completed" in result.first_text()
    broadcast.assert_awaited_once()


@pytest.mark.anyio
async def test_transition_with_artifact_storage():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    session = _session()
    wf = _workflow(next_state_id="st-2", artifact_id="my-artifact")

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {"key": "value"}
        )
    assert result.is_error is False

    with get_db() as db:
        art = db.execute(
            select(DBArtifact).where(DBArtifact.session_id == "s-1")
        ).scalar_one_or_none()
    assert art is not None
    assert art.artifact_id == "my-artifact"
    assert art.content == {"key": "value"}


@pytest.mark.anyio
async def test_transition_truncate_on_entry():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    session = _session()
    wf = _workflow(next_state_id="st-2", truncate_on_entry=True)

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}
        )
    assert result.should_truncate is True
    assert "truncated" in result.first_text()


@pytest.mark.anyio
async def test_transition_next_state_not_found_in_workflow():
    """If output_schema has a next_state that doesn't exist in states list."""
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()

    # Manually create a workflow with a broken next_state reference
    broken_os = OutputSchema(
        outcome="done",
        next_state="ghost-state",
        schema={"type": "object", "properties": {}},
    )
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="st-1",
        states=[
            WorkflowState(
                id="st-1",
                name="One",
                prompt="p",
                output_schemas=[broken_os],
            )
        ],
    )

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}
        )
    assert result.is_error is True
    assert "ghost-state" in result.first_text()


@pytest.mark.anyio
async def test_transition_broadcast_event():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    session = _session()
    broadcast = _make_broadcast()
    wf = _workflow(next_state_id="st-2")

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}, broadcast=broadcast
        )

    broadcast.assert_awaited_once()
    event = broadcast.call_args[0][0]
    assert event.type == "workflow_state_change"
    assert event.content[0]["workflow_state_id"] == "st-2"


@pytest.mark.anyio
async def test_transition_no_broadcast_when_none():
    """No broadcast call when broadcast=None."""
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))
    session = _session()
    wf = _workflow(next_state_id="st-2")

    with patch("hypergolic.workflows.engine.get_workflow", return_value=wf):
        result = await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}, broadcast=None
        )
    assert result.is_error is False


@pytest.mark.anyio
async def test_transition_completion_deactivates_wf_skills():
    """Workflow skills are removed when workflow completes."""
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-wf"))

    session = _session()
    sk = _skill("sk-wf")
    wf = _workflow(next_state_id=None, wf_skills=[sk])

    with (
        patch("hypergolic.workflows.engine.get_workflow", return_value=wf),
        patch("hypergolic.skills.resolver.resolve_roles", return_value=[]),
    ):
        await handle_workflow_transition(
            session, "wf-1", "st-1", "done", {}
        )

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    assert len(rows) == 0


# ---------------------------------------------------------------------------
# deactivate_workflow
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_deactivate_workflow():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    await deactivate_workflow("s-1")

    with get_db() as db:
        row = db.execute(
            select(DBSessionWorkflow)
            .where(DBSessionWorkflow.session_id == "s-1")
            .where(DBSessionWorkflow.deleted_at.is_(None))
        ).scalar_one_or_none()
    assert row is None


@pytest.mark.anyio
async def test_deactivate_workflow_sets_deleted_at():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id="s-1",
            workflow_id="wf-1",
            current_state_id="st-1",
        ))

    await deactivate_workflow("s-1")

    with get_db() as db:
        row = db.execute(
            select(DBSessionWorkflow).where(DBSessionWorkflow.session_id == "s-1")
        ).scalar_one_or_none()
    assert row is not None
    assert row.deleted_at is not None


# ---------------------------------------------------------------------------
# load_artifacts
# ---------------------------------------------------------------------------


def test_load_artifacts_returns_matching():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    make_artifact(
        session_id="s-1",
        workflow_id="wf-1",
        state_id="st-1",
        outcome="success",
        artifact_id="art-a",
        content={"data": 1},
    )
    make_artifact(
        session_id="s-1",
        workflow_id="wf-1",
        state_id="st-2",
        outcome="success",
        artifact_id="art-b",
        content={"data": 2},
    )

    results = load_artifacts("s-1", ["art-a"])
    assert len(results) == 1
    aid, content, ts = results[0]
    assert aid == "art-a"
    assert content == {"data": 1}
    assert isinstance(ts, str)


def test_load_artifacts_multiple():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    make_artifact(session_id="s-1", artifact_id="art-x", content={"x": 1})
    make_artifact(session_id="s-1", artifact_id="art-y", content={"y": 2})

    results = load_artifacts("s-1", ["art-x", "art-y"])
    assert len(results) == 2


def test_load_artifacts_empty_when_no_match():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")

    results = load_artifacts("s-1", ["nonexistent"])
    assert results == []


def test_load_artifacts_empty_list():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")

    results = load_artifacts("s-1", [])
    assert results == []


# ---------------------------------------------------------------------------
# _activate_state_skills
# ---------------------------------------------------------------------------


def test_activate_state_skills_adds_new():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")

    skills = [_skill("sk-a"), _skill("sk-b")]
    _activate_state_skills("s-1", skills)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    ids = {r.skill_id for r in rows}
    assert ids == {"sk-a", "sk-b"}


def test_activate_state_skills_skips_already_active():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-a"))

    skills = [_skill("sk-a"), _skill("sk-b")]
    _activate_state_skills("s-1", skills)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    # sk-a not duplicated
    skill_ids = [r.skill_id for r in rows]
    assert skill_ids.count("sk-a") == 1
    assert "sk-b" in skill_ids


# ---------------------------------------------------------------------------
# _deactivate_state_skills
# ---------------------------------------------------------------------------


def test_deactivate_state_skills_removes():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-remove"))

    session = _session()
    with patch("hypergolic.skills.resolver.resolve_roles", return_value=[]):
        _deactivate_state_skills("s-1", [_skill("sk-remove")], session)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    assert rows == []


def test_deactivate_state_skills_empty_list_noop():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-keep"))

    session = _session()
    # Passing an empty list should not touch the DB at all
    _deactivate_state_skills("s-1", [], session)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    assert len(rows) == 1


def test_deactivate_state_skills_protects_role_skills():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-role"))

    session = _session(role="my-role")
    role_dict = {"id": "my-role", "skills": ["sk-role"]}
    with patch("hypergolic.skills.resolver.resolve_roles", return_value=[role_dict]):
        _deactivate_state_skills("s-1", [_skill("sk-role")], session)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    # Protected by role — should remain
    assert len(rows) == 1


def test_deactivate_state_skills_respects_protected_ids():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-protected"))

    session = _session()
    with patch("hypergolic.skills.resolver.resolve_roles", return_value=[]):
        _deactivate_state_skills(
            "s-1", [_skill("sk-protected")], session,
            protected_ids={"sk-protected"}
        )

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    assert len(rows) == 1


# ---------------------------------------------------------------------------
# _transition_skills
# ---------------------------------------------------------------------------


def test_transition_skills_removes_old_adds_new():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-old"))

    session = _session()
    old_skills = [_skill("sk-old")]
    new_skills = [_skill("sk-new")]

    with patch("hypergolic.skills.resolver.resolve_roles", return_value=[]):
        _transition_skills("s-1", old_skills, new_skills, session)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    ids = {r.skill_id for r in rows}
    assert "sk-new" in ids
    assert "sk-old" not in ids


def test_transition_skills_keeps_common_skills():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-shared"))

    session = _session()
    old_skills = [_skill("sk-shared"), _skill("sk-old")]
    new_skills = [_skill("sk-shared"), _skill("sk-new")]

    with patch("hypergolic.skills.resolver.resolve_roles", return_value=[]):
        _transition_skills("s-1", old_skills, new_skills, session)

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    ids = {r.skill_id for r in rows}
    assert "sk-shared" in ids
    assert "sk-new" in ids
    assert "sk-old" not in ids


def test_transition_skills_respects_protected_ids():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id="s-1", skill_id="sk-protected"))

    session = _session()
    old_skills = [_skill("sk-protected")]
    new_skills = []

    with patch("hypergolic.skills.resolver.resolve_roles", return_value=[]):
        _transition_skills(
            "s-1", old_skills, new_skills, session,
            protected_ids={"sk-protected"}
        )

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == "s-1")
        ).scalars().all()
    assert len(rows) == 1


def test_transition_skills_empty_to_empty():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    # Should not raise
    _transition_skills("s-1", [], [], session)
