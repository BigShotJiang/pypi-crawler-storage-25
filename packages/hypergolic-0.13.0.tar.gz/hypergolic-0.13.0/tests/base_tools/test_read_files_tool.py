"""Tests for base/tools/read_files.py — run_read_files."""

from unittest.mock import patch

import pytest

from hypergolic.base.tools.read_files import ReadFilesInput, run_read_files
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="read_files",
    )


# ── read existing file ────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_read_existing_file(tmp_path):
    f = tmp_path / "hello.txt"
    f.write_text("world")
    inp = ReadFilesInput(paths=["hello.txt"])
    result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert any("world" in b["text"] for b in result.content)


# ── multiple files ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_read_multiple_files(tmp_path):
    (tmp_path / "a.txt").write_text("aaa")
    (tmp_path / "b.txt").write_text("bbb")
    inp = ReadFilesInput(paths=["a.txt", "b.txt"])
    result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    combined = " ".join(b["text"] for b in result.content)
    assert "aaa" in combined
    assert "bbb" in combined


# ── file not found ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_read_file_not_found(tmp_path):
    inp = ReadFilesInput(paths=["missing.txt"])
    result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("not found" in b["text"].lower() for b in result.content)


# ── not a file (directory) ────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_read_directory_not_file(tmp_path):
    d = tmp_path / "mydir"
    d.mkdir()
    inp = ReadFilesInput(paths=["mydir"])
    result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("not a file" in b["text"].lower() for b in result.content)


# ── UnicodeDecodeError (binary file) ─────────────────────────────────────────


@pytest.mark.anyio
async def test_read_binary_file(tmp_path):
    f = tmp_path / "binary.bin"
    f.write_bytes(b"\xff\xfe\x00\x01")
    inp = ReadFilesInput(paths=["binary.bin"])
    result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("not valid utf-8" in b["text"].lower() for b in result.content)


# ── PermissionError ───────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_read_permission_error(tmp_path):
    f = tmp_path / "secret.txt"
    f.write_text("private")
    inp = ReadFilesInput(paths=["secret.txt"])
    with patch("hypergolic.base.tools.read_files.resolve_path") as mock_rp:
        mock_path = mock_rp.return_value
        mock_path.exists.return_value = True
        mock_path.is_file.return_value = True
        mock_path.read_text.side_effect = PermissionError()
        result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("permission denied" in b["text"].lower() for b in result.content)


# ── empty paths list ──────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_read_empty_paths(tmp_path):
    inp = ReadFilesInput(paths=[])
    result = await run_read_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("no files" in b["text"].lower() for b in result.content)
