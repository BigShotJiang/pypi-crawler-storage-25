"""Tests for base/tools/search_files.py — _truncate_line, _format_result, run_search_files."""

import subprocess
from unittest.mock import AsyncMock, patch

import pytest

from hypergolic.base.tools.search_files import (
    DEFAULT_MAX_RESULTS,
    SearchFilesInput,
    _format_result,
    _rewrite_line,
    _truncate_line,
    run_search_files,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="search_files",
    )


def _completed(returncode=0, stdout="", stderr=""):
    return subprocess.CompletedProcess(
        args=[],
        returncode=returncode,
        stdout=stdout,
        stderr=stderr,
    )


# ── _truncate_line ────────────────────────────────────────────────────────────


def test_truncate_line_under_limit():
    line = "a" * 100
    assert _truncate_line(line) == line


def test_truncate_line_over_limit():
    line = "a" * 1100
    result = _truncate_line(line)
    assert "truncated" in result
    assert len(result) < len(line)


def test_truncate_line_separator():
    # "--" separator is never truncated
    assert _truncate_line("--") == "--"


def test_truncate_line_exactly_at_limit():
    from hypergolic.base.tools.search_files import MAX_LINE_LENGTH
    line = "a" * MAX_LINE_LENGTH
    assert _truncate_line(line) == line


# ── _format_result ────────────────────────────────────────────────────────────


def test_format_result_no_matches_rc1(tmp_path):
    inp = SearchFilesInput(pattern="foo")
    result = _format_result(_completed(returncode=1, stdout="", stderr=""), inp, _session(tmp_path))
    assert result.outcome == "SUCCESS"
    assert any("no matches" in b["text"].lower() for b in result.content)


def test_format_result_error_rc_gt1(tmp_path):
    inp = SearchFilesInput(pattern="foo")
    result = _format_result(_completed(returncode=2, stdout="", stderr="bad pattern"), inp, _session(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("error" in b["text"].lower() for b in result.content)


def test_format_result_empty_stdout(tmp_path):
    inp = SearchFilesInput(pattern="foo")
    result = _format_result(_completed(returncode=0, stdout="", stderr=""), inp, _session(tmp_path))
    assert result.outcome == "SUCCESS"
    assert any("no matches" in b["text"].lower() for b in result.content)


def test_format_result_with_matches(tmp_path):
    stdout = "\n".join(f"file.py:{i}:match line {i}" for i in range(5))
    inp = SearchFilesInput(pattern="match")
    result = _format_result(_completed(returncode=0, stdout=stdout), inp, _session(tmp_path))
    assert result.outcome == "SUCCESS"
    assert any("5" in b["text"] for b in result.content)


def test_format_result_truncates_excess_results(tmp_path):
    # Create more matches than DEFAULT_MAX_RESULTS
    stdout = "\n".join(f"file.py:{i}:match {i}" for i in range(DEFAULT_MAX_RESULTS + 10))
    inp = SearchFilesInput(pattern="match")
    result = _format_result(_completed(returncode=0, stdout=stdout), inp, _session(tmp_path))
    assert result.outcome == "SUCCESS"
    combined = " ".join(b["text"] for b in result.content)
    assert "more results available" in combined.lower()
    # Should show DEFAULT_MAX_RESULTS in the summary
    assert str(DEFAULT_MAX_RESULTS) in combined


def test_format_result_with_context_lines(tmp_path):
    # Lines with context lines (--) separators should be handled
    stdout = "file.py:1:match\n--\nfile.py:5:another match"
    inp = SearchFilesInput(pattern="match", context_lines=1)
    result = _format_result(_completed(returncode=0, stdout=stdout), inp, _session(tmp_path))
    assert result.outcome == "SUCCESS"


# ── _rewrite_line ──────────────────────────────────────────────────────


def test_rewrite_line_non_absolute_unchanged(tmp_path):
    assert _rewrite_line("rel/path:1:text", _session(tmp_path)) == "rel/path:1:text"


def test_rewrite_line_empty_unchanged(tmp_path):
    assert _rewrite_line("", _session(tmp_path)) == ""


def test_rewrite_line_no_colon_unchanged(tmp_path):
    # An absolute path with no ':' (shouldn't happen with rg, but defensive)
    line = str(tmp_path / "weird")
    assert _rewrite_line(line, _session(tmp_path)) == line


def test_rewrite_line_absolute_in_project_becomes_relative(tmp_path):
    line = f"{tmp_path.resolve()}/src/a.py:10:hello"
    assert _rewrite_line(line, _session(tmp_path)) == "src/a.py:10:hello"


def test_format_result_rewrites_paths_in_project(tmp_path):
    resolved = tmp_path.resolve()
    stdout = f"{resolved}/src/a.py:1:hello\n{resolved}/src/b.py:2:world"
    inp = SearchFilesInput(pattern="hello")
    result = _format_result(_completed(returncode=0, stdout=stdout), inp, _session(tmp_path))
    combined = " ".join(b["text"] for b in result.content)
    assert "src/a.py:1:hello" in combined
    assert "src/b.py:2:world" in combined
    assert str(resolved) not in combined


# ── run_search_files ──────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_run_search_files_rg_path(tmp_path):
    (tmp_path / "file.txt").write_text("hello world")
    resolved = tmp_path.resolve()
    fake_result = _completed(
        returncode=0,
        stdout=f"{resolved}/file.txt:1:hello world",
    )
    inp = SearchFilesInput(pattern="hello", directory=".")
    with (
        patch("hypergolic.base.tools.search_files.has_ripgrep", return_value=True),
        patch(
            "hypergolic.base.tools.search_files.run_subprocess",
            new=AsyncMock(return_value=fake_result),
        ),
    ):
        result = await run_search_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    combined = " ".join(b["text"] for b in result.content)
    # In-project absolute paths are rewritten to project-relative form.
    assert "file.txt:1:hello world" in combined
    assert str(resolved) not in combined


@pytest.mark.anyio
async def test_run_search_files_python_path(tmp_path):
    (tmp_path / "file.txt").write_text("hello world")
    inp = SearchFilesInput(pattern="hello", directory=".")
    with patch("hypergolic.base.tools.search_files.has_ripgrep", return_value=False):
        result = await run_search_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"


@pytest.mark.anyio
async def test_run_search_files_no_match_python(tmp_path):
    (tmp_path / "file.txt").write_text("hello world")
    inp = SearchFilesInput(pattern="zzznomatch", directory=".")
    with patch("hypergolic.base.tools.search_files.has_ripgrep", return_value=False):
        result = await run_search_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert any("no matches" in b["text"].lower() for b in result.content)


@pytest.mark.anyio
async def test_run_search_files_timeout(tmp_path):
    inp = SearchFilesInput(pattern="foo", directory=".")
    with (
        patch("hypergolic.base.tools.search_files.has_ripgrep", return_value=True),
        patch(
            "hypergolic.base.tools.search_files.run_subprocess",
            side_effect=subprocess.TimeoutExpired(cmd="rg", timeout=30),
        ),
    ):
        result = await run_search_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("timed out" in b["text"].lower() for b in result.content)


@pytest.mark.anyio
async def test_run_search_files_unexpected_exception(tmp_path):
    inp = SearchFilesInput(pattern="foo", directory=".")
    with (
        patch("hypergolic.base.tools.search_files.has_ripgrep", return_value=True),
        patch(
            "hypergolic.base.tools.search_files.run_subprocess",
            side_effect=RuntimeError("unexpected"),
        ),
    ):
        result = await run_search_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("error" in b["text"].lower() for b in result.content)
