"""Tests for base/tools/list_files.py — run_list_files, _python_list_files, _collect_directories."""

from pathlib import Path
from unittest.mock import AsyncMock, patch

import pytest

from hypergolic.base.tools.list_files import (
    ListFilesInput,
    _collect_directories,
    _python_list_files,
    run_list_files,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="list",
    )


# ── run_list_files: directory not found ───────────────────────────────────────


@pytest.mark.anyio
async def test_list_files_dir_not_found(tmp_path):
    inp = ListFilesInput(directory="nonexistent")
    result = await run_list_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("does not exist" in b["text"] for b in result.content)


# ── run_list_files: not a directory ───────────────────────────────────────────


@pytest.mark.anyio
async def test_list_files_not_a_directory(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("content")
    inp = ListFilesInput(directory="file.txt")
    result = await run_list_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("not a directory" in b["text"] for b in result.content)


# ── run_list_files: empty directory ───────────────────────────────────────────


@pytest.mark.anyio
async def test_list_files_empty_directory(tmp_path):
    empty = tmp_path / "emptydir"
    empty.mkdir()
    inp = ListFilesInput(directory="emptydir")
    with patch("hypergolic.base.tools.list_files.has_ripgrep", return_value=False):
        result = await run_list_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert any("no entries" in b["text"].lower() for b in result.content)


# ── run_list_files: python path (no rg) ───────────────────────────────────────


@pytest.mark.anyio
async def test_list_files_python_path(tmp_path):
    d = tmp_path / "myproject"
    d.mkdir()
    (d / "main.py").write_text("x")
    (d / "readme.md").write_text("y")
    inp = ListFilesInput(directory="myproject")
    with patch("hypergolic.base.tools.list_files.has_ripgrep", return_value=False):
        result = await run_list_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    combined = " ".join(b["text"] for b in result.content)
    assert "main.py" in combined
    assert "readme.md" in combined


# ── run_list_files: rg path ───────────────────────────────────────────────────


@pytest.mark.anyio
async def test_list_files_rg_path(tmp_path):
    d = tmp_path / "myproject"
    d.mkdir()
    (d / "main.py").write_text("x")

    import subprocess
    resolved = tmp_path.resolve()
    fake_result = subprocess.CompletedProcess(
        args=[],
        returncode=0,
        stdout=str(resolved / "myproject" / "main.py") + "\n",
        stderr="",
    )
    inp = ListFilesInput(directory="myproject")
    with (
        patch("hypergolic.base.tools.list_files.has_ripgrep", return_value=True),
        patch(
            "hypergolic.base.tools.list_files.run_subprocess",
            new=AsyncMock(return_value=fake_result),
        ),
    ):
        result = await run_list_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    combined = " ".join(b["text"] for b in result.content)
    # In-project absolute paths are rewritten to project-relative form.
    assert "myproject/main.py" in combined
    assert str(resolved) not in combined


# ── run_list_files: rg error ──────────────────────────────────────────────────


@pytest.mark.anyio
async def test_list_files_rg_error(tmp_path):
    d = tmp_path / "myproject"
    d.mkdir()
    import subprocess
    fake_result = subprocess.CompletedProcess(
        args=[],
        returncode=1,
        stdout="",
        stderr="some rg error",
    )
    inp = ListFilesInput(directory="myproject")
    with (
        patch("hypergolic.base.tools.list_files.has_ripgrep", return_value=True),
        patch(
            "hypergolic.base.tools.list_files.run_subprocess",
            new=AsyncMock(return_value=fake_result),
        ),
    ):
        result = await run_list_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"


# ── _python_list_files: pattern filter ───────────────────────────────────────


def test_python_list_files_pattern_filter(tmp_path):
    (tmp_path / "a.py").write_text("x")
    (tmp_path / "b.txt").write_text("y")
    inp = ListFilesInput(directory=str(tmp_path), pattern="*.py")
    entries = _python_list_files(tmp_path, inp)
    assert any(e.endswith(".py") for e in entries)
    assert not any(e.endswith(".txt") for e in entries)


# ── _python_list_files: depth ────────────────────────────────────────────────


def test_python_list_files_depth(tmp_path):
    deep = tmp_path / "a" / "b"
    deep.mkdir(parents=True)
    (deep / "deep.py").write_text("x")
    (tmp_path / "a" / "shallow.py").write_text("y")
    inp = ListFilesInput(directory=str(tmp_path), depth=2)
    entries = _python_list_files(tmp_path, inp)
    names = {Path(e).name for e in entries}
    assert "shallow.py" in names
    assert "deep.py" not in names


def test_python_list_files_default_depth_is_one(tmp_path):
    """Default depth=1 acts like `ls` — only immediate children."""
    (tmp_path / "top.py").write_text("x")
    sub = tmp_path / "sub"
    sub.mkdir()
    (sub / "nested.py").write_text("y")
    inp = ListFilesInput(directory=str(tmp_path))
    entries = _python_list_files(tmp_path, inp)
    names = {Path(e).name for e in entries}
    assert "top.py" in names
    assert "sub" in names
    assert "nested.py" not in names


# ── _python_list_files: include_hidden ───────────────────────────────────────


def test_python_list_files_hidden_excluded(tmp_path):
    (tmp_path / ".hidden.py").write_text("x")
    (tmp_path / "visible.py").write_text("y")
    inp = ListFilesInput(directory=str(tmp_path), include_hidden=False)
    entries = _python_list_files(tmp_path, inp)
    assert not any(".hidden" in e for e in entries)
    assert any("visible.py" in e for e in entries)


def test_python_list_files_hidden_included(tmp_path):
    (tmp_path / ".hidden.py").write_text("x")
    (tmp_path / "visible.py").write_text("y")
    inp = ListFilesInput(directory=str(tmp_path), include_hidden=True)
    entries = _python_list_files(tmp_path, inp)
    assert any(".hidden" in e for e in entries)


# ── _python_list_files: directories included ─────────────────────────────────


def test_python_list_files_includes_dirs(tmp_path):
    d = tmp_path / "subdir"
    d.mkdir()
    (d / "file.py").write_text("x")
    inp = ListFilesInput(directory=str(tmp_path))
    entries = _python_list_files(tmp_path, inp)
    assert any(e.endswith("subdir/") for e in entries)


# ── _collect_directories ─────────────────────────────────────────────────────


def test_collect_directories_basic(tmp_path):
    d = tmp_path / "subdir"
    d.mkdir()
    (d / "file.py").write_text("x")
    inp = ListFilesInput(directory=str(tmp_path))
    dirs = _collect_directories(tmp_path, inp)
    assert any("subdir/" in d for d in dirs)


def test_collect_directories_hidden_excluded(tmp_path):
    d = tmp_path / ".hidden_dir"
    d.mkdir()
    inp = ListFilesInput(directory=str(tmp_path), include_hidden=False)
    dirs = _collect_directories(tmp_path, inp)
    assert not any(".hidden_dir" in d for d in dirs)


def test_collect_directories_hidden_included(tmp_path):
    d = tmp_path / ".hidden_dir"
    d.mkdir()
    inp = ListFilesInput(directory=str(tmp_path), include_hidden=True)
    dirs = _collect_directories(tmp_path, inp)
    assert any(".hidden_dir" in d for d in dirs)


def test_collect_directories_depth(tmp_path):
    deep = tmp_path / "a" / "b" / "c"
    deep.mkdir(parents=True)
    inp = ListFilesInput(directory=str(tmp_path), depth=2)
    dirs = _collect_directories(tmp_path, inp)
    dir_names = [Path(d).parts for d in dirs]
    # depth 3 directories shouldn't appear
    assert not any("c" in parts and len(parts) > 2 for parts in dir_names)


def test_collect_directories_with_prefix(tmp_path):
    d = tmp_path / "sub"
    d.mkdir()
    inp = ListFilesInput(directory=str(tmp_path))
    dirs = _collect_directories(tmp_path, inp, prefix="/base/")
    assert all(d.startswith("/base/") for d in dirs)
