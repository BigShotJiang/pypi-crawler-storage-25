"""Tests for base/tools/git.py — _first_subcommand, git_approval, _run_git_tool_command, run_git."""

import subprocess
from pathlib import Path
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.base.tools.git import (
    GitInput,
    _first_subcommand,
    _run_git_tool_command,
    git_approval,
    git_tool,
    run_git,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ApprovalContext, ToolContext


def _make_session() -> Session:
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )


def _make_ctx(session: Session | None = None) -> ToolContext:
    return ToolContext(
        session=session or _make_session(),
        broadcast=AsyncMock(),
        tool_id="git",
    )


def _completed(returncode: int = 0, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess([], returncode, stdout=stdout, stderr=stderr)


# ---------------------------------------------------------------------------
# Tool metadata
# ---------------------------------------------------------------------------


def test_git_tool_id():
    assert git_tool.id == "git"


def test_git_tool_name():
    assert git_tool.name == "Git"


# ---------------------------------------------------------------------------
# _first_subcommand
# ---------------------------------------------------------------------------


def test_first_subcommand_simple():
    assert _first_subcommand("status") == "status"


def test_first_subcommand_with_args():
    assert _first_subcommand("diff --staged") == "diff"


def test_first_subcommand_with_flags_first():
    """Flags before the subcommand are skipped."""
    assert _first_subcommand("--no-pager log --oneline") == "log"


def test_first_subcommand_empty_string():
    assert _first_subcommand("") == ""


def test_first_subcommand_only_flags():
    assert _first_subcommand("--version --help") == ""


def test_first_subcommand_push():
    assert _first_subcommand("push origin main") == "push"


def test_first_subcommand_quoted_args():
    assert _first_subcommand('log --format="%H"') == "log"


# ---------------------------------------------------------------------------
# git_approval
# ---------------------------------------------------------------------------


def _make_approval_ctx(args: str) -> ApprovalContext:
    inp = GitInput(args=args)
    return ApprovalContext(input=inp, session=_make_session(), active_skill_ids=set())


@pytest.mark.parametrize(
    "args",
    [
        "status",
        "diff --staged",
        "log --oneline",
        "show HEAD",
        "branch -a",
        "stash list",
        "shortlog -s",
        "describe --tags",
        "rev-parse HEAD",
        "ls-files",
        "ls-tree HEAD",
        "cat-file -p HEAD",
        "blame README.md",
        "reflog",
    ],
)
def test_git_approval_read_only_allows(args: str):
    ctx = _make_approval_ctx(args)
    decision = git_approval(ctx)
    assert decision.decision == "ALLOW"


@pytest.mark.parametrize(
    "args",
    [
        "push origin main",
        "commit -m 'msg'",
        "merge main",
        "rebase main",
        "reset --hard HEAD",
        "checkout -b new-branch",
        "fetch origin",
        "pull",
        "add .",
    ],
)
def test_git_approval_write_requires_approval(args: str):
    ctx = _make_approval_ctx(args)
    decision = git_approval(ctx)
    assert decision.decision == "REQUIRE_APPROVAL"


def test_git_approval_empty_args_requires_approval():
    """When there's no subcommand, default to REQUIRE_APPROVAL."""
    ctx = _make_approval_ctx("")
    decision = git_approval(ctx)
    assert decision.decision == "REQUIRE_APPROVAL"


# ---------------------------------------------------------------------------
# Worktree-session approval
# ---------------------------------------------------------------------------


def _worktree_session() -> Session:
    return Session(
        id="s-wt",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
        worktree_path="/tmp/wt",
        worktree_branch="hyp/abc12345",
        base_branch="main",
    )


def _worktree_approval_ctx(args: str) -> ApprovalContext:
    return ApprovalContext(
        input=GitInput(args=args),
        session=_worktree_session(),
        active_skill_ids=set(),
    )


@pytest.mark.parametrize(
    "args",
    [
        "add .",
        "commit -m 'msg'",
        "reset --hard",
        "rm file.txt",
        "mv a b",
        "restore file.txt",
        "clean -fd",
        "tag v1",
        "stash push",
    ],
)
def test_git_approval_worktree_allow_list(args: str) -> None:
    decision = git_approval(_worktree_approval_ctx(args))
    assert decision.decision == "ALLOW"


@pytest.mark.parametrize(
    "args",
    [
        "checkout main",
        "switch main",
        "merge feature",
        "rebase main",
        "pull origin",
        "worktree remove x",
    ],
)
def test_git_approval_worktree_deny_list(args: str) -> None:
    decision = git_approval(_worktree_approval_ctx(args))
    assert decision.decision == "DENY"
    assert decision.reason is not None
    assert "worktree" in decision.reason.lower()


def test_git_approval_worktree_push_still_requires_approval() -> None:
    """push has external side effects — not auto-allowed even in a worktree."""
    decision = git_approval(_worktree_approval_ctx("push origin hyp/abc12345"))
    assert decision.decision == "REQUIRE_APPROVAL"


# ---------------------------------------------------------------------------
# _run_git_tool_command
# ---------------------------------------------------------------------------


def test_run_git_tool_command_success():
    session = _make_session()
    inp = GitInput(args="status")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        return_value=_completed(returncode=0, stdout="On branch main"),
    ) as mock:
        result = _run_git_tool_command(inp, session)

    assert result.outcome == "SUCCESS"
    assert "On branch main" in result.content[0]["text"]
    mock.assert_called_once_with("status", cwd=Path("/tmp/p"))


def test_run_git_tool_command_failure():
    session = _make_session()
    inp = GitInput(args="diff HEAD~999")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        return_value=_completed(returncode=128, stderr="bad revision"),
    ):
        result = _run_git_tool_command(inp, session)

    assert result.outcome == "FAILURE"
    assert "bad revision" in result.content[0]["text"]


def test_run_git_tool_command_no_output():
    """Falls back to '(no output)' when stdout and stderr are empty."""
    session = _make_session()
    inp = GitInput(args="status")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        return_value=_completed(returncode=0, stdout="", stderr=""),
    ):
        result = _run_git_tool_command(inp, session)

    assert "(no output)" in result.content[0]["text"]


def test_run_git_tool_command_multi_word_args():
    """Args string is shlex-split before passing to run_git_command."""
    session = _make_session()
    inp = GitInput(args="log --oneline -5")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        return_value=_completed(returncode=0, stdout="abc123 fix"),
    ) as mock:
        _run_git_tool_command(inp, session)

    mock.assert_called_once_with("log", "--oneline", "-5", cwd=Path("/tmp/p"))


# ---------------------------------------------------------------------------
# run_git (async wrapper)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_git_success():
    ctx = _make_ctx()
    inp = GitInput(args="status")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        return_value=_completed(returncode=0, stdout="clean"),
    ):
        result = await run_git(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "clean" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_run_git_failure_returncode():
    ctx = _make_ctx()
    inp = GitInput(args="push")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        return_value=_completed(returncode=1, stderr="rejected"),
    ):
        result = await run_git(inp, ctx)

    assert result.outcome == "FAILURE"


@pytest.mark.asyncio
async def test_run_git_exception_returns_failure():
    ctx = _make_ctx()
    inp = GitInput(args="status")

    with patch(
        "hypergolic.base.tools.git.run_git_command",
        side_effect=RuntimeError("git not found"),
    ):
        result = await run_git(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Git error" in result.content[0]["text"]
    assert "git not found" in result.content[0]["text"]
