"""Tests for base/tools/move_files.py — run_move_files and its approval."""

from unittest.mock import patch

import pytest

from hypergolic.base.tools.move_files import (
    MoveEntry,
    MoveFilesInput,
    move_files_approval,
    run_move_files,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ApprovalContext, ToolContext


def _session(tmp_path, worktree_path: str | None = None):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
        worktree_path=worktree_path,
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="move",
    )


# ── happy path ────────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_move_renames_file(tmp_path):
    src = tmp_path / "a.txt"
    src.write_text("hello")
    inp = MoveFilesInput(moves=[MoveEntry(src="a.txt", dst="b.txt")])

    result = await run_move_files(inp, _ctx(tmp_path))

    assert result.outcome == "SUCCESS"
    assert not src.exists()
    assert (tmp_path / "b.txt").read_text() == "hello"


@pytest.mark.anyio
async def test_move_creates_parent_dirs(tmp_path):
    src = tmp_path / "a.txt"
    src.write_text("x")
    inp = MoveFilesInput(moves=[MoveEntry(src="a.txt", dst="nested/deep/b.txt")])

    result = await run_move_files(inp, _ctx(tmp_path))

    assert result.outcome == "SUCCESS"
    assert (tmp_path / "nested" / "deep" / "b.txt").read_text() == "x"


@pytest.mark.anyio
async def test_move_multiple(tmp_path):
    (tmp_path / "a.txt").write_text("1")
    (tmp_path / "b.txt").write_text("2")
    inp = MoveFilesInput(moves=[
        MoveEntry(src="a.txt", dst="a2.txt"),
        MoveEntry(src="b.txt", dst="b2.txt"),
    ])

    result = await run_move_files(inp, _ctx(tmp_path))

    assert result.outcome == "SUCCESS"
    assert (tmp_path / "a2.txt").read_text() == "1"
    assert (tmp_path / "b2.txt").read_text() == "2"


# ── failures ──────────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_move_source_missing(tmp_path):
    inp = MoveFilesInput(moves=[MoveEntry(src="missing.txt", dst="b.txt")])
    result = await run_move_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("source not found" in b["text"].lower() for b in result.content)


@pytest.mark.anyio
async def test_move_refuses_to_clobber(tmp_path):
    (tmp_path / "a.txt").write_text("new")
    (tmp_path / "b.txt").write_text("existing")
    inp = MoveFilesInput(moves=[MoveEntry(src="a.txt", dst="b.txt")])

    result = await run_move_files(inp, _ctx(tmp_path))

    assert result.outcome == "FAILURE"
    assert (tmp_path / "a.txt").exists()
    assert (tmp_path / "b.txt").read_text() == "existing"
    assert any("already exists" in b["text"].lower() for b in result.content)


@pytest.mark.anyio
async def test_move_permission_error(tmp_path):
    (tmp_path / "a.txt").write_text("x")
    inp = MoveFilesInput(moves=[MoveEntry(src="a.txt", dst="b.txt")])
    with patch("hypergolic.base.tools.move_files.resolve_path") as mock_rp:
        src_mock = mock_rp.return_value
        src_mock.exists.return_value = True
        src_mock.rename.side_effect = PermissionError()
        # Both resolve_path calls return the same mock; dst.exists() above
        # is True which would trip the clobber check. Make it False.
        src_mock.exists.side_effect = [True, False]
        result = await run_move_files(inp, _ctx(tmp_path))

    assert result.outcome == "FAILURE"
    assert any("permission denied" in b["text"].lower() for b in result.content)


# ── approval ─────────────────────────────────────────────────────────────────


def _approval_ctx(tmp_path, moves, session=None):
    return ApprovalContext(
        input=MoveFilesInput(moves=moves),
        session=session or _session(tmp_path),
        active_skill_ids=set(),
    )


def test_approval_allows_in_project_move(tmp_path):
    ctx = _approval_ctx(
        tmp_path,
        [MoveEntry(src="a.txt", dst="sub/b.txt")],
    )
    assert move_files_approval(ctx).decision == "ALLOW"


def test_approval_requires_when_dst_outside_project(tmp_path):
    ctx = _approval_ctx(
        tmp_path,
        [MoveEntry(src="a.txt", dst="/tmp/elsewhere.txt")],
    )
    assert move_files_approval(ctx).decision == "REQUIRE_APPROVAL"


def test_approval_requires_when_src_outside_project(tmp_path):
    ctx = _approval_ctx(
        tmp_path,
        [MoveEntry(src="/etc/hosts", dst="hosts.bak")],
    )
    assert move_files_approval(ctx).decision == "REQUIRE_APPROVAL"


def test_approval_denies_worktree_escape(tmp_path):
    worktree = tmp_path / "wt"
    worktree.mkdir()
    session = _session(tmp_path, worktree_path=str(worktree))
    ctx = _approval_ctx(
        tmp_path,
        [MoveEntry(src="a.txt", dst="/tmp/escape.txt")],
        session=session,
    )
    decision = move_files_approval(ctx)
    assert decision.decision == "DENY"
    assert decision.reason and "worktree" in decision.reason.lower()
