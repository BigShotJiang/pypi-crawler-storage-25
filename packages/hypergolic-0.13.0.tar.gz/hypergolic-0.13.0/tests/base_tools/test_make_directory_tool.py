"""Tests for base/tools/make_directory.py — _make_single_directory and run_make_directory."""

from unittest.mock import patch

import pytest

from hypergolic.base.tools.make_directory import (
    MakeDirectoryInput,
    _make_single_directory,
    run_make_directory,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="make_directory",
    )


# ── _make_single_directory ────────────────────────────────────────────────────


def test_make_single_directory_creates(tmp_path):
    session = _session(tmp_path)
    result = _make_single_directory("newdir", session)
    assert result is None
    assert (tmp_path / "newdir").is_dir()


def test_make_single_directory_nested(tmp_path):
    session = _session(tmp_path)
    result = _make_single_directory("a/b/c", session)
    assert result is None
    assert (tmp_path / "a" / "b" / "c").is_dir()


def test_make_single_directory_already_exists(tmp_path):
    d = tmp_path / "existing"
    d.mkdir()
    session = _session(tmp_path)
    result = _make_single_directory("existing", session)
    # exist_ok=True, so no error
    assert result is None


def test_make_single_directory_permission_error(tmp_path):
    session = _session(tmp_path)
    with patch("hypergolic.base.tools.make_directory.resolve_path") as mock_rp:
        mock_path = mock_rp.return_value
        mock_path.mkdir.side_effect = PermissionError()
        result = _make_single_directory("blocked", session)
    assert result is not None
    assert "permission denied" in result.lower()


# ── run_make_directory: path ──────────────────────────────────────────────────


@pytest.mark.anyio
async def test_run_make_directory_with_path(tmp_path):
    inp = MakeDirectoryInput(path="singledir")
    result = await run_make_directory(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert (tmp_path / "singledir").is_dir()


# ── run_make_directory: paths ─────────────────────────────────────────────────


@pytest.mark.anyio
async def test_run_make_directory_with_paths(tmp_path):
    inp = MakeDirectoryInput(paths=["dir1", "dir2", "dir3"])
    result = await run_make_directory(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert (tmp_path / "dir1").is_dir()
    assert (tmp_path / "dir2").is_dir()
    assert (tmp_path / "dir3").is_dir()


# ── run_make_directory: neither path nor paths ────────────────────────────────


@pytest.mark.anyio
async def test_run_make_directory_neither(tmp_path):
    inp = MakeDirectoryInput()
    result = await run_make_directory(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("required" in b["text"].lower() for b in result.content)


# ── run_make_directory: PermissionError ───────────────────────────────────────


@pytest.mark.anyio
async def test_run_make_directory_permission_error(tmp_path):
    inp = MakeDirectoryInput(path="blocked")
    with patch("hypergolic.base.tools.make_directory.resolve_path") as mock_rp:
        mock_path = mock_rp.return_value
        mock_path.mkdir.side_effect = PermissionError()
        result = await run_make_directory(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("permission denied" in b["text"].lower() for b in result.content)
