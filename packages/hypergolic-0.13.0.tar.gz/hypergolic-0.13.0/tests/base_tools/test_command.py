"""Tests for base/tools/command.py — run_command."""

import os
import subprocess
from unittest.mock import AsyncMock, patch

import pytest

from hypergolic.base.tools.command import (
    CommandInput,
    command_approval,
    command_tool,
    run_command,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ApprovalContext, ToolContext


def _make_session() -> Session:
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )


def _make_ctx(session: Session | None = None) -> ToolContext:
    return ToolContext(
        session=session or _make_session(),
        broadcast=AsyncMock(),
        tool_id="command",
    )


def _completed(returncode: int = 0, stdout: str = "", stderr: str = "") -> subprocess.CompletedProcess:
    return subprocess.CompletedProcess([], returncode, stdout=stdout, stderr=stderr)


# ---------------------------------------------------------------------------
# Tool metadata
# ---------------------------------------------------------------------------


def test_command_tool_id():
    assert command_tool.id == "command"


def test_command_tool_approval():
    """Non-worktree sessions require approval for shell commands."""
    session = _make_session()
    decision = command_approval(ApprovalContext(
        input=CommandInput(command="ls"),
        session=session,
        active_skill_ids=set(),
    ))
    assert decision.decision == "REQUIRE_APPROVAL"


def test_command_tool_allows_in_worktree_session():
    """Worktree sessions run commands freely — no human is there to approve."""
    session = Session(
        id="s-wt",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
        worktree_path="/tmp/wt",
        worktree_branch="hyp/s-wt",
        base_branch="main",
    )
    decision = command_approval(ApprovalContext(
        input=CommandInput(command="ls"),
        session=session,
        active_skill_ids=set(),
    ))
    assert decision.decision == "ALLOW"


def test_command_tool_has_callable_approval():
    """The tool itself exposes a callable so the engine evaluates per-session."""
    assert callable(command_tool.approval)


# ---------------------------------------------------------------------------
# Success cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_command_success_stdout_only():
    ctx = _make_ctx()
    inp = CommandInput(command="echo hello")

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(return_value=_completed(returncode=0, stdout="hello\n")),
    ):
        result = await run_command(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "STDOUT:" in result.content[0]["text"]
    assert "hello" in result.content[0]["text"]
    assert "Exit code: 0" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_run_command_success_stderr_included():
    ctx = _make_ctx()
    inp = CommandInput(command="some cmd")

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(return_value=_completed(returncode=0, stdout="out", stderr="warn")),
    ):
        result = await run_command(inp, ctx)

    text = result.content[0]["text"]
    assert "STDOUT:" in text
    assert "STDERR:" in text
    assert result.outcome == "SUCCESS"


@pytest.mark.asyncio
async def test_run_command_no_output():
    """When stdout and stderr are both empty, only exit code line appears."""
    ctx = _make_ctx()
    inp = CommandInput(command="true")

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(return_value=_completed(returncode=0)),
    ):
        result = await run_command(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "Exit code: 0" in result.content[0]["text"]


# ---------------------------------------------------------------------------
# Failure cases
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_command_nonzero_exit_code():
    ctx = _make_ctx()
    inp = CommandInput(command="false")

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(return_value=_completed(returncode=1, stderr="error message")),
    ):
        result = await run_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Exit code: 1" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_run_command_timeout():
    ctx = _make_ctx()
    inp = CommandInput(command="sleep 100", timeout=1)

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(side_effect=subprocess.TimeoutExpired("sleep", 1)),
    ):
        result = await run_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "timed out" in result.content[0]["text"]
    assert "1 seconds" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_run_command_file_not_found():
    ctx = _make_ctx()
    inp = CommandInput(command="ls", working_directory="/nonexistent/path")

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(side_effect=FileNotFoundError()),
    ):
        result = await run_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "/nonexistent/path" in result.content[0]["text"]


@pytest.mark.asyncio
async def test_run_command_generic_exception():
    ctx = _make_ctx()
    inp = CommandInput(command="something")

    with patch(
        "hypergolic.base.tools.command.run_subprocess",
        new=AsyncMock(side_effect=RuntimeError("unexpected failure")),
    ):
        result = await run_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "unexpected failure" in result.content[0]["text"]


# ---------------------------------------------------------------------------
# Working directory
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_command_uses_session_working_directory():
    """When working_directory is not provided, uses session.working_directory()."""
    ctx = _make_ctx()  # project_path="/tmp/p"
    inp = CommandInput(command="pwd")

    captured_kwargs: dict = {}

    async def mock_run_subprocess(*args, **kwargs):
        captured_kwargs.update(kwargs)
        return _completed(returncode=0, stdout="/tmp/p\n")

    with patch("hypergolic.base.tools.command.run_subprocess", new=mock_run_subprocess):
        await run_command(inp, ctx)

    assert captured_kwargs["cwd"] == "/tmp/p"


@pytest.mark.asyncio
async def test_run_command_working_directory_override():
    """Explicit working_directory overrides session default."""
    ctx = _make_ctx()
    inp = CommandInput(command="pwd", working_directory="/custom/dir")

    captured_kwargs: dict = {}

    async def mock_run_subprocess(*args, **kwargs):
        captured_kwargs.update(kwargs)
        return _completed(returncode=0, stdout="/custom/dir\n")

    with patch("hypergolic.base.tools.command.run_subprocess", new=mock_run_subprocess):
        await run_command(inp, ctx)

    assert captured_kwargs["cwd"] == "/custom/dir"


# ---------------------------------------------------------------------------
# Environment merging
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_command_env_overrides_merged():
    """Custom env keys are merged with os.environ."""
    ctx = _make_ctx()
    inp = CommandInput(command="env", env={"MY_CUSTOM_VAR": "hello"})

    captured_kwargs: dict = {}

    async def mock_run_subprocess(*args, **kwargs):
        captured_kwargs.update(kwargs)
        return _completed(returncode=0)

    with patch("hypergolic.base.tools.command.run_subprocess", new=mock_run_subprocess):
        await run_command(inp, ctx)

    env = captured_kwargs["env"]
    assert env["MY_CUSTOM_VAR"] == "hello"
    # Original env vars should still be present
    assert "PATH" in env or len(env) > 1


@pytest.mark.asyncio
async def test_run_command_no_env_uses_os_environ():
    """Without env overrides, base env is os.environ copy."""
    ctx = _make_ctx()
    inp = CommandInput(command="env")

    captured_kwargs: dict = {}

    async def mock_run_subprocess(*args, **kwargs):
        captured_kwargs.update(kwargs)
        return _completed(returncode=0)

    with patch("hypergolic.base.tools.command.run_subprocess", new=mock_run_subprocess):
        await run_command(inp, ctx)

    # env is always passed (copy of os.environ)
    assert "env" in captured_kwargs
