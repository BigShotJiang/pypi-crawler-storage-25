"""Tests for base/tools/history.py — read-only SQL tool."""

import json
from unittest.mock import AsyncMock

import pytest

from hypergolic.base.tools.history import (
    HistoryInput,
    history_tool,
    run_history,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext
from tests.conftest import make_message, make_project, make_session


def _ctx() -> ToolContext:
    return ToolContext(
        session=Session(
            id="s-1",
            model_tier=ModelTier.MEDIUM,
            project_id="p-1",
            project_path="/tmp/p",
            role="generalist",
        ),
        broadcast=AsyncMock(),
        tool_id="history",
    )


async def _run(query: str):
    result = await run_history(HistoryInput(query=query), _ctx())
    text = result.content[0]["text"] if result.content else ""
    if result.outcome == "SUCCESS":
        return result, json.loads(text)
    return result, text


# ---------------------------------------------------------------------------
# Tool metadata
# ---------------------------------------------------------------------------


def test_history_tool_metadata():
    assert history_tool.id == "history"
    assert history_tool.name == "History"
    assert history_tool.input_schema is HistoryInput


# ---------------------------------------------------------------------------
# Basic SELECT
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_select_returns_columns_and_rows():
    make_project("p-basic", path="/tmp/basic")
    make_session(project_id="p-basic", sid="s-basic")

    result, payload = await _run("SELECT id, project_id FROM sessions")
    assert result.outcome == "SUCCESS"
    assert payload["columns"] == ["id", "project_id"]
    assert {"id": "s-basic", "project_id": "p-basic"} in payload["rows"]


@pytest.mark.asyncio
async def test_select_empty_result():
    result, payload = await _run("SELECT id FROM sessions WHERE id = 'nope'")
    assert result.outcome == "SUCCESS"
    assert payload == {"columns": ["id"], "rows": []}


@pytest.mark.asyncio
async def test_datetime_columns_serialized_as_iso():
    make_project("p-dt", path="/tmp/dt")
    make_session(project_id="p-dt", sid="s-dt")

    _result, payload = await _run("SELECT created_at FROM sessions WHERE id='s-dt'")
    created = payload["rows"][0]["created_at"]
    assert isinstance(created, str)
    # ISO 8601 starts with YYYY-MM-DD
    assert created[:4].isdigit() and created[4] == "-"


@pytest.mark.asyncio
async def test_json_column_returned_as_string():
    """SQLite stores JSON as TEXT; we pass it through as-is."""
    make_project("p-json", path="/tmp/json")
    sid = make_session(project_id="p-json", sid="s-json")
    make_message(sid, role="user", text="hello world")

    _r, payload = await _run(
        f"SELECT content FROM messages WHERE session_id='{sid}'"
    )
    raw = payload["rows"][0]["content"]
    assert "hello world" in raw


@pytest.mark.asyncio
async def test_json_extract_works():
    make_project("p-jx", path="/tmp/jx")
    sid = make_session(project_id="p-jx", sid="s-jx")
    make_message(sid, role="user", text="findable")

    _r, payload = await _run(
        f"SELECT json_extract(content, '$[0].text') AS t "
        f"FROM messages WHERE session_id='{sid}'"
    )
    assert payload["rows"][0]["t"] == "findable"


# ---------------------------------------------------------------------------
# Schema discoverability
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_sqlite_master_lists_tables():
    _r, payload = await _run(
        "SELECT name FROM sqlite_master WHERE type='table' ORDER BY name"
    )
    names = {row["name"] for row in payload["rows"]}
    assert "sessions" in names
    assert "messages" in names


@pytest.mark.asyncio
async def test_pragma_table_info_works():
    _r, payload = await _run("PRAGMA table_info(sessions)")
    col_names = {row["name"] for row in payload["rows"]}
    assert "id" in col_names
    assert "project_id" in col_names


# ---------------------------------------------------------------------------
# Read-only enforcement
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_insert_is_rejected():
    make_project("p-ro", path="/tmp/ro")
    result, _payload = await _run(
        "INSERT INTO projects (id, name, path, created_at, updated_at) "
        "VALUES ('x', 'x', '/x', '2024-01-01', '2024-01-01')"
    )
    assert result.outcome == "FAILURE"


@pytest.mark.asyncio
async def test_update_is_rejected():
    make_project("p-upd", path="/tmp/upd")
    result, _payload = await _run("UPDATE projects SET name='hacked'")
    assert result.outcome == "FAILURE"


@pytest.mark.asyncio
async def test_delete_is_rejected():
    make_project("p-del", path="/tmp/del")
    result, _payload = await _run("DELETE FROM projects")
    assert result.outcome == "FAILURE"


@pytest.mark.asyncio
async def test_drop_is_rejected():
    result, _payload = await _run("DROP TABLE sessions")
    assert result.outcome == "FAILURE"


@pytest.mark.asyncio
async def test_writes_still_work_after_readonly_query():
    """query_only must be reset so the app's writes keep working afterward."""
    make_project("p-after", path="/tmp/after")
    await _run("SELECT 1")
    # This would fail if query_only leaked onto the shared connection.
    sid = make_session(project_id="p-after", sid="s-after")
    assert sid == "s-after"


# ---------------------------------------------------------------------------
# Error handling
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_malformed_sql_returns_failure():
    result, _payload = await _run("SELEKT * FROM nowhere")
    assert result.outcome == "FAILURE"
    assert result.content[0]["text"]  # non-empty error message


@pytest.mark.asyncio
async def test_unknown_table_returns_failure():
    result, _payload = await _run("SELECT * FROM does_not_exist")
    assert result.outcome == "FAILURE"
