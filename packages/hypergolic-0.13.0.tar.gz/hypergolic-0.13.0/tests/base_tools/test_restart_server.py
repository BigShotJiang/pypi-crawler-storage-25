"""Tests for base/tools/restart_server.py — _restart_after_delay, run_restart_server."""

import threading
from unittest.mock import AsyncMock, MagicMock, call, patch

import pytest

from hypergolic.base.tools.restart_server import (
    _restart_after_delay,
    restart_server_tool,
    run_restart_server,
)
from hypergolic.enums import ModelTier, SessionStatus
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext
from tests.conftest import make_project, make_session


def _make_session() -> Session:
    return Session(
        id="s-rs",
        model_tier=ModelTier.MEDIUM,
        project_id="p-rs",
        project_path="/tmp/rs",
        role="generalist",
    )


def _make_ctx(session: Session | None = None) -> ToolContext:
    return ToolContext(
        session=session or _make_session(),
        broadcast=AsyncMock(),
        tool_id="restart_server",
    )


# ---------------------------------------------------------------------------
# Tool metadata
# ---------------------------------------------------------------------------


def test_restart_server_tool_id():
    assert restart_server_tool.id == "restart_server"


def test_restart_server_tool_approval():
    assert restart_server_tool.approval == "REQUIRE_APPROVAL"


# ---------------------------------------------------------------------------
# _restart_after_delay
# ---------------------------------------------------------------------------


def test_restart_after_delay_calls_execv():
    """_restart_after_delay should sleep then call os.execv."""
    import sys
    with (
        patch("time.sleep") as mock_sleep,
        patch("hypergolic.base.tools.restart_server.os.execv") as mock_execv,
    ):
        _restart_after_delay(delay=0.0)

    mock_sleep.assert_called_once_with(0.0)
    mock_execv.assert_called_once()
    # First arg should be sys.executable
    args = mock_execv.call_args[0]
    assert args[0] == sys.executable


def test_restart_after_delay_default_delay():
    """Default delay is 1.0 seconds."""
    with (
        patch("time.sleep") as mock_sleep,
        patch("hypergolic.base.tools.restart_server.os.execv"),
    ):
        _restart_after_delay()

    mock_sleep.assert_called_once_with(1.0)


def test_restart_after_delay_passes_sys_argv():
    """execv is called with [sys.executable] + sys.argv as args list."""
    import sys
    with (
        patch("time.sleep"),
        patch("hypergolic.base.tools.restart_server.os.execv") as mock_execv,
    ):
        _restart_after_delay(delay=0.0)

    args_list = mock_execv.call_args[0][1]
    assert args_list[0] == sys.executable
    assert args_list[1:] == sys.argv


# ---------------------------------------------------------------------------
# run_restart_server
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_run_restart_server_returns_success():
    make_project("p-rsr", path="/tmp/rsr")
    make_session(project_id="p-rsr", sid="s-rsr")
    session = Session(
        id="s-rsr",
        model_tier=ModelTier.MEDIUM,
        project_id="p-rsr",
        project_path="/tmp/rsr",
        role="generalist",
    )
    ctx = _make_ctx(session)

    with (
        patch("hypergolic.base.tools.restart_server.set_session_status") as mock_status,
        patch("hypergolic.base.tools.restart_server._restart_after_delay"),
        patch("threading.Thread") as mock_thread_cls,
    ):
        mock_thread = MagicMock()
        mock_thread_cls.return_value = mock_thread
        result = await run_restart_server(ctx)

    assert result.outcome == "SUCCESS"
    assert "restart" in result.content[0]["text"].lower()


@pytest.mark.asyncio
async def test_run_restart_server_sets_session_idle():
    """run_restart_server calls set_session_status with IDLE before starting thread."""
    make_project("p-rss", path="/tmp/rss")
    make_session(project_id="p-rss", sid="s-rss")
    session = Session(
        id="s-rss",
        model_tier=ModelTier.MEDIUM,
        project_id="p-rss",
        project_path="/tmp/rss",
        role="generalist",
    )
    ctx = _make_ctx(session)

    with (
        patch("hypergolic.base.tools.restart_server.set_session_status") as mock_status,
        patch("threading.Thread") as mock_thread_cls,
    ):
        mock_thread = MagicMock()
        mock_thread_cls.return_value = mock_thread
        await run_restart_server(ctx)

    mock_status.assert_called_once_with("s-rss", SessionStatus.IDLE)


@pytest.mark.asyncio
async def test_run_restart_server_starts_thread():
    """run_restart_server starts a daemon thread."""
    make_project("p-rst", path="/tmp/rst")
    make_session(project_id="p-rst", sid="s-rst")
    session = Session(
        id="s-rst",
        model_tier=ModelTier.MEDIUM,
        project_id="p-rst",
        project_path="/tmp/rst",
        role="generalist",
    )
    ctx = _make_ctx(session)

    with (
        patch("hypergolic.base.tools.restart_server.set_session_status"),
        patch("hypergolic.base.tools.restart_server.threading.Thread") as mock_thread_cls,
    ):
        mock_thread = MagicMock()
        mock_thread_cls.return_value = mock_thread
        await run_restart_server(ctx)

    mock_thread.start.assert_called_once()
