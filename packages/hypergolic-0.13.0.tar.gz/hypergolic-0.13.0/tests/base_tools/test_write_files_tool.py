"""Tests for base/tools/write_files.py — run_write_files."""

from unittest.mock import patch, MagicMock

import pytest

from hypergolic.base.tools.write_files import WriteFileEntry, WriteFilesInput, run_write_files
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="write_files",
    )


# ── write new file ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_write_new_file(tmp_path):
    inp = WriteFilesInput(files=[WriteFileEntry(path="new.txt", content="hello")])
    result = await run_write_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert (tmp_path / "new.txt").read_text() == "hello"


# ── overwrite existing file ───────────────────────────────────────────────────


@pytest.mark.anyio
async def test_overwrite_existing_file(tmp_path):
    f = tmp_path / "existing.txt"
    f.write_text("old content")
    inp = WriteFilesInput(files=[WriteFileEntry(path="existing.txt", content="new content")])
    result = await run_write_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert f.read_text() == "new content"


# ── creates parent directories ────────────────────────────────────────────────


@pytest.mark.anyio
async def test_write_creates_parent_dirs(tmp_path):
    inp = WriteFilesInput(
        files=[WriteFileEntry(path="a/b/c/file.txt", content="deep")]
    )
    result = await run_write_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert (tmp_path / "a" / "b" / "c" / "file.txt").read_text() == "deep"


# ── PermissionError ───────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_write_permission_error(tmp_path):
    inp = WriteFilesInput(files=[WriteFileEntry(path="blocked.txt", content="x")])
    with patch("hypergolic.base.tools.write_files.resolve_path") as mock_rp:
        mock_path = mock_rp.return_value
        mock_path.parent = MagicMock()
        mock_path.parent.mkdir.return_value = None
        mock_path.write_text.side_effect = PermissionError()
        result = await run_write_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("permission denied" in b["text"].lower() for b in result.content)
