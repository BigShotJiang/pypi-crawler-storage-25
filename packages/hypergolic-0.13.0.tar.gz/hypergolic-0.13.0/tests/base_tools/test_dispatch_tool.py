"""Tests for the unified dispatch tool."""

from enum import Enum
from typing import Any
from unittest.mock import AsyncMock, patch

import pytest

from hypergolic.base.tools.dispatch import (
    DISPATCH_PROMPT,
    _render_file_reference,
    build_dispatch_tool,
)
from hypergolic.dispatch.core import DispatchResult
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext


def _input_schema(tool: Tool) -> type[InputSchema]:
    schema = tool.input_schema
    assert schema is not None
    return schema


def _make_input(tool: Tool, **kwargs: Any) -> InputSchema:
    schema = _input_schema(tool)
    role = kwargs.pop("role", None)
    if role is not None:
        RoleEnum = schema.model_fields["role"].annotation
        kwargs["role"] = RoleEnum(role)
    return schema(**kwargs)


def _session(tmp_path, role: str = "generalist") -> Session:
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role=role,
    )


def _ctx(tmp_path, broadcast: AsyncMock | None = None) -> ToolContext:
    return ToolContext(
        session=_session(tmp_path),
        broadcast=broadcast or AsyncMock(),
        tool_id="dispatch",
    )


# ── build_dispatch_tool ───────────────────────────────────────────────────────


def test_build_dispatch_tool_empty_role_list_returns_none():
    assert build_dispatch_tool([], {}) is None


def test_build_dispatch_tool_has_expected_metadata():
    tool = build_dispatch_tool(["worker"], {"worker": {"read_files"}})
    assert tool is not None
    assert tool.id == "dispatch"
    assert tool.name == "Dispatch"


def test_dispatch_input_role_is_enum():
    tool = build_dispatch_tool(
        ["worker", "researcher"], {"worker": set(), "researcher": set()}
    )
    assert tool is not None
    schema = _input_schema(tool).model_json_schema()
    assert "role" in schema["properties"]


# ── _render_file_reference ────────────────────────────────────────────────────


def test_render_file_reference_no_read_files_tool(tmp_path):
    f = tmp_path / "a.txt"
    f.write_text("secret")
    text = _render_file_reference("a.txt", _session(tmp_path, "worker"), set())
    assert "lacks read_files" in text
    assert "secret" not in text


def test_render_file_reference_outside_project_requires_approval(tmp_path):
    # path that won't be in the project or readonly allowlist
    outside = "/etc/passwd"
    text = _render_file_reference(
        outside, _session(tmp_path, "worker"), {"read_files"}
    )
    assert "not permitted" in text


def test_render_file_reference_allowed_inlines_contents(tmp_path):
    f = tmp_path / "note.md"
    f.write_text("hello world")
    text = _render_file_reference(
        "note.md", _session(tmp_path, "worker"), {"read_files"}
    )
    assert "hello world" in text
    assert "note.md" in text


def test_render_file_reference_missing_file(tmp_path):
    text = _render_file_reference(
        "missing.txt", _session(tmp_path, "worker"), {"read_files"}
    )
    assert "file not found" in text


def test_render_file_reference_directory(tmp_path):
    (tmp_path / "d").mkdir()
    text = _render_file_reference(
        "d", _session(tmp_path, "worker"), {"read_files"}
    )
    assert "not a file" in text


def test_render_file_reference_binary(tmp_path):
    f = tmp_path / "bin.dat"
    f.write_bytes(b"\xff\xfe\x00\x01")
    text = _render_file_reference(
        "bin.dat", _session(tmp_path, "worker"), {"read_files"}
    )
    assert "UTF-8" in text


# ── run_dispatch integration ──────────────────────────────────────────────────


def _get_run(tool):
    # toolkit Tool has `.run`
    return tool.run


@pytest.mark.anyio
async def test_run_dispatch_forwards_to_dispatch_core(tmp_path):
    tool = build_dispatch_tool(
        ["worker"], {"worker": {"read_files"}}
    )
    assert tool is not None
    ctx = _ctx(tmp_path)
    inp = _make_input(tool, role="worker", prompt="do the thing")

    with patch(
        "hypergolic.base.tools.dispatch.dispatch",
        new=AsyncMock(return_value=DispatchResult(outcome="success", conclusion="ok")),
    ) as mock_dispatch:
        result = await _get_run(tool)(inp, ctx)

    assert result.outcome == "SUCCESS"
    call_kwargs = mock_dispatch.call_args[1]
    assert call_kwargs["role"] == "worker"
    assert call_kwargs["dispatch_prompt"] == DISPATCH_PROMPT
    # The first content block is the prompt
    assert call_kwargs["content_blocks"][0]["text"] == "do the thing"
    # No file references → no second block
    assert len(call_kwargs["content_blocks"]) == 1


@pytest.mark.anyio
async def test_run_dispatch_attaches_file_references(tmp_path):
    (tmp_path / "ctx.txt").write_text("reference content")
    tool = build_dispatch_tool(["worker"], {"worker": {"read_files"}})
    assert tool is not None
    ctx = _ctx(tmp_path)
    inp = _make_input(
        tool, role="worker", prompt="task", file_references=["ctx.txt"]
    )

    with patch(
        "hypergolic.base.tools.dispatch.dispatch",
        new=AsyncMock(return_value=DispatchResult(outcome="success", conclusion="done")),
    ) as mock_dispatch:
        await _get_run(tool)(inp, ctx)

    blocks = mock_dispatch.call_args[1]["content_blocks"]
    assert len(blocks) == 2
    assert "reference content" in blocks[1]["text"]
    assert "ctx.txt" in blocks[1]["text"]


@pytest.mark.anyio
async def test_run_dispatch_marks_unreadable_files(tmp_path):
    tool = build_dispatch_tool(["reviewer"], {"reviewer": set()})
    assert tool is not None
    ctx = _ctx(tmp_path)
    inp = _make_input(
        tool,
        role="reviewer",
        prompt="please review",
        file_references=["secret.txt"],
    )

    with patch(
        "hypergolic.base.tools.dispatch.dispatch",
        new=AsyncMock(return_value=DispatchResult(outcome="success", conclusion="ok")),
    ) as mock_dispatch:
        await _get_run(tool)(inp, ctx)

    blocks = mock_dispatch.call_args[1]["content_blocks"]
    # Second block is the attached references with a "not provided" marker
    assert "not provided" in blocks[1]["text"]
    assert "lacks read_files" in blocks[1]["text"]


@pytest.mark.anyio
async def test_run_dispatch_failure_outcome(tmp_path):
    tool = build_dispatch_tool(["worker"], {"worker": {"read_files"}})
    assert tool is not None
    ctx = _ctx(tmp_path)
    inp = _make_input(tool, role="worker", prompt="task")

    with patch(
        "hypergolic.base.tools.dispatch.dispatch",
        new=AsyncMock(return_value=DispatchResult(outcome="failure", conclusion="nope")),
    ):
        result = await _get_run(tool)(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Dispatch failed" in result.content[0]["text"]
    assert "nope" in result.content[0]["text"]


@pytest.mark.anyio
async def test_run_dispatch_suppressed_outcome(tmp_path):
    tool = build_dispatch_tool(["worker"], {"worker": {"read_files"}})
    assert tool is not None
    ctx = _ctx(tmp_path)
    inp = _make_input(tool, role="worker", prompt="task")

    with patch(
        "hypergolic.base.tools.dispatch.dispatch",
        new=AsyncMock(return_value=DispatchResult(outcome="suppressed", conclusion="interrupted")),
    ):
        result = await _get_run(tool)(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "interrupted" in result.content[0]["text"].lower()


@pytest.mark.anyio
async def test_run_dispatch_passes_model_tier(tmp_path):
    tool = build_dispatch_tool(["worker"], {"worker": {"read_files"}})
    assert tool is not None
    ctx = _ctx(tmp_path)
    inp = _make_input(
        tool, role="worker", prompt="task", model_tier=ModelTier.LOW
    )

    with patch(
        "hypergolic.base.tools.dispatch.dispatch",
        new=AsyncMock(return_value=DispatchResult(outcome="success", conclusion="ok")),
    ) as mock_dispatch:
        await _get_run(tool)(inp, ctx)

    assert mock_dispatch.call_args[1]["model_tier"] == ModelTier.LOW


def test_dispatch_role_enum_excludes_invalid_values():
    tool = build_dispatch_tool(["worker"], {"worker": {"read_files"}})
    assert tool is not None
    RoleEnum = _input_schema(tool).model_fields["role"].annotation
    assert RoleEnum is not None and issubclass(RoleEnum, Enum)
    with pytest.raises(ValueError):
        RoleEnum("generalist")
