"""Tests for base/tools/delete_files.py — run_delete_files."""

from unittest.mock import patch

import pytest

from hypergolic.base.tools.delete_files import DeleteFilesInput, run_delete_files
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="delete",
    )


# ── delete existing file ──────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_delete_existing_file(tmp_path):
    f = tmp_path / "to_delete.txt"
    f.write_text("bye")
    inp = DeleteFilesInput(paths=["to_delete.txt"])
    result = await run_delete_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert not f.exists()


# ── path not found ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_delete_path_not_found(tmp_path):
    inp = DeleteFilesInput(paths=["nonexistent.txt"])
    result = await run_delete_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("not found" in b["text"].lower() for b in result.content)


# ── directories ───────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_delete_empty_directory(tmp_path):
    d = tmp_path / "mydir"
    d.mkdir()
    inp = DeleteFilesInput(paths=["mydir"])
    result = await run_delete_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert not d.exists()


@pytest.mark.anyio
async def test_delete_directory_recursive(tmp_path):
    d = tmp_path / "mydir" / "nested"
    d.mkdir(parents=True)
    (d / "file.txt").write_text("x")
    inp = DeleteFilesInput(paths=["mydir"])
    result = await run_delete_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert not (tmp_path / "mydir").exists()


@pytest.mark.anyio
async def test_delete_symlink_to_directory_does_not_recurse(tmp_path):
    target = tmp_path / "target"
    target.mkdir()
    (target / "keep.txt").write_text("keep me")
    link = tmp_path / "link"
    link.symlink_to(target)
    inp = DeleteFilesInput(paths=["link"])
    result = await run_delete_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert not link.exists()
    assert (target / "keep.txt").read_text() == "keep me"


# ── PermissionError ───────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_delete_permission_error(tmp_path):
    f = tmp_path / "locked.txt"
    f.write_text("locked")
    inp = DeleteFilesInput(paths=["locked.txt"])
    with patch("hypergolic.base.tools.delete_files._target_path") as mock_tp:
        mock_path = mock_tp.return_value
        mock_path.exists.return_value = True
        mock_path.is_symlink.return_value = False
        mock_path.is_dir.return_value = False
        mock_path.unlink.side_effect = PermissionError()
        result = await run_delete_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("permission denied" in b["text"].lower() for b in result.content)
