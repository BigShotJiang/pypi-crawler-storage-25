"""Tests for base/tools/edit_files.py — _edit_single_file and run_edit_files."""

from unittest.mock import patch, MagicMock

import pytest

from hypergolic.base.tools.edit_files import (
    EditFileEntry,
    EditFilesInput,
    _edit_single_file,
    run_edit_files,
)
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import ToolContext


def _session(tmp_path):
    return Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path=str(tmp_path),
        role="generalist",
    )


async def _noop_broadcast(event):
    pass


def _ctx(tmp_path):
    return ToolContext(
        session=_session(tmp_path),
        broadcast=_noop_broadcast,
        tool_id="edit_files",
    )


# ── _edit_single_file ─────────────────────────────────────────────────────────


def test_edit_file_not_found(tmp_path):
    session = _session(tmp_path)
    entry = EditFileEntry(path="missing.txt", old_string="x", new_string="y")
    result = _edit_single_file(entry, session)
    assert result is not None
    assert "does not exist" in result


def test_edit_not_a_file(tmp_path):
    d = tmp_path / "mydir"
    d.mkdir()
    session = _session(tmp_path)
    entry = EditFileEntry(path="mydir", old_string="x", new_string="y")
    result = _edit_single_file(entry, session)
    assert result is not None
    assert "not a file" in result


def test_edit_old_string_not_found(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("hello world")
    session = _session(tmp_path)
    entry = EditFileEntry(path="file.txt", old_string="goodbye", new_string="hi")
    result = _edit_single_file(entry, session)
    assert result is not None
    assert "not found" in result


def test_edit_multiple_occurrences(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("foo foo foo")
    session = _session(tmp_path)
    entry = EditFileEntry(path="file.txt", old_string="foo", new_string="bar")
    result = _edit_single_file(entry, session)
    assert result is not None
    assert "3" in result  # appears 3 times
    assert "times" in result


def test_edit_successful(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("hello world")
    session = _session(tmp_path)
    entry = EditFileEntry(path="file.txt", old_string="world", new_string="earth")
    result = _edit_single_file(entry, session)
    assert result is None
    assert f.read_text() == "hello earth"


def test_edit_permission_error_on_read(tmp_path):
    session = _session(tmp_path)
    entry = EditFileEntry(path="file.txt", old_string="x", new_string="y")
    with patch("hypergolic.base.tools.edit_files.resolve_path") as mock_rp:
        mock_path = mock_rp.return_value
        mock_path.exists.return_value = True
        mock_path.is_file.return_value = True
        mock_path.read_text.side_effect = PermissionError()
        result = _edit_single_file(entry, session)
    assert result is not None
    assert "permission denied" in result.lower()


def test_edit_permission_error_on_write(tmp_path):
    session = _session(tmp_path)
    entry = EditFileEntry(path="file.txt", old_string="old", new_string="new")
    with patch("hypergolic.base.tools.edit_files.resolve_path") as mock_rp:
        mock_path = mock_rp.return_value
        mock_path.exists.return_value = True
        mock_path.is_file.return_value = True
        mock_path.read_text.return_value = "old content"
        mock_path.write_text.side_effect = PermissionError()
        result = _edit_single_file(entry, session)
    assert result is not None
    assert "permission denied" in result.lower()


# ── run_edit_files ────────────────────────────────────────────────────────────


@pytest.mark.anyio
async def test_run_edit_empty_files(tmp_path):
    inp = EditFilesInput(files=[])
    result = await run_edit_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("no edits" in b["text"].lower() for b in result.content)


@pytest.mark.anyio
async def test_run_edit_batch_with_errors(tmp_path):
    f = tmp_path / "file.txt"
    f.write_text("hello world")
    inp = EditFilesInput(
        files=[
            EditFileEntry(path="file.txt", old_string="world", new_string="earth"),
            EditFileEntry(path="missing.txt", old_string="x", new_string="y"),
        ]
    )
    result = await run_edit_files(inp, _ctx(tmp_path))
    assert result.outcome == "FAILURE"
    assert any("does not exist" in b["text"] for b in result.content)


@pytest.mark.anyio
async def test_run_edit_successful_batch(tmp_path):
    f1 = tmp_path / "a.txt"
    f2 = tmp_path / "b.txt"
    f1.write_text("alpha")
    f2.write_text("beta")
    inp = EditFilesInput(
        files=[
            EditFileEntry(path="a.txt", old_string="alpha", new_string="ALPHA"),
            EditFileEntry(path="b.txt", old_string="beta", new_string="BETA"),
        ]
    )
    result = await run_edit_files(inp, _ctx(tmp_path))
    assert result.outcome == "SUCCESS"
    assert f1.read_text() == "ALPHA"
    assert f2.read_text() == "BETA"
