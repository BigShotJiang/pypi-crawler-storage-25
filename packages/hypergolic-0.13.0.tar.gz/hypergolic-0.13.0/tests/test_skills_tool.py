"""Tests for hypergolic.tools.skills (handle_activate_skill, handle_deactivate_skill).

Note: The core skill handler tests already live in tests/test_nested_skills.py.
This module focuses on the remaining coverage targets in tools/skills.py.
"""

import asyncio
from typing import Any, cast
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.tools.skills import handle_activate_skill, handle_deactivate_skill
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _session(sid: str = "s-1") -> Session:
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )


def _ctx(session: Session | None = None):
    from hypergolic.tools.schemas import ToolContext
    return ToolContext(
        session=session or _session(),
        broadcast=AsyncMock(),
        tool_id="activate_skill",
    )


def _inp(**kwargs: Any) -> MagicMock:
    inp = MagicMock()
    for k, v in kwargs.items():
        setattr(inp, k, v)
    return inp


def _text(block: object) -> str:
    return cast(dict[str, Any], block)["text"]


# ---------------------------------------------------------------------------
# handle_activate_skill
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_activate_skill_new():
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    session = _session(sid)
    ctx = _ctx(session)

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        return_value=("My Skill", "The prompt text"),
    ):
        result = await handle_activate_skill(_inp(skill_ids=["sk-new"]), ctx)

    assert result.is_error is False
    text = _text(result.content[0])
    assert "My Skill" in text
    assert "The prompt text" in text

    with get_db() as db:
        row = db.execute(
            select(DBSessionSkill)
            .where(DBSessionSkill.session_id == sid)
            .where(DBSessionSkill.skill_id == "sk-new")
        ).scalar_one_or_none()
    assert row is not None


@pytest.mark.anyio
async def test_activate_skill_already_active():
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id=sid, skill_id="sk-already"))

    session = _session(sid)
    ctx = _ctx(session)

    result = await handle_activate_skill(_inp(skill_ids=["sk-already"]), ctx)
    assert "already active" in _text(result.content[0])


@pytest.mark.anyio
async def test_activate_skill_not_found():
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    session = _session(sid)
    ctx = _ctx(session)

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        return_value=None,
    ):
        result = await handle_activate_skill(_inp(skill_ids=["nonexistent"]), ctx)

    assert "not found" in _text(result.content[0])


@pytest.mark.anyio
async def test_activate_skill_prompt_not_found():
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    session = _session(sid)
    ctx = _ctx(session)

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        return_value=("No Prompt Skill", None),
    ):
        result = await handle_activate_skill(_inp(skill_ids=["sk-noprompt"]), ctx)

    assert "prompt file not found" in _text(result.content[0])


@pytest.mark.anyio
async def test_activate_skill_multiple_mixed():
    """Some found, some not found, combined output."""
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    session = _session(sid)
    ctx = _ctx(session)

    def side_effect(skill_id):
        if skill_id == "sk-good":
            return ("Good Skill", "Good prompt")
        return None

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        side_effect=side_effect,
    ):
        result = await handle_activate_skill(
            _inp(skill_ids=["sk-good", "sk-bad"]), ctx
        )

    text = _text(result.content[0])
    assert "Good Skill" in text
    assert "not found" in text


@pytest.mark.anyio
async def test_activate_skill_separator_for_multiple():
    """Multiple results are joined with separator."""
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    session = _session(sid)
    ctx = _ctx(session)

    def side_effect(skill_id):
        return (skill_id, f"Prompt for {skill_id}")

    with patch(
        "hypergolic.tools.skills.get_skill_prompt_content",
        side_effect=side_effect,
    ):
        result = await handle_activate_skill(
            _inp(skill_ids=["sk-a", "sk-b"]), ctx
        )

    text = _text(result.content[0])
    assert "---" in text


# ---------------------------------------------------------------------------
# handle_deactivate_skill
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_deactivate_skill_removes_from_db():
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id=sid, skill_id="sk-to-remove"))

    session = _session(sid)
    ctx = _ctx(session)

    result = await handle_deactivate_skill(_inp(skill_ids=["sk-to-remove"]), ctx)
    assert "Deactivated" in _text(result.content[0])
    assert "sk-to-remove" in _text(result.content[0])

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == sid)
        ).scalars().all()
    assert rows == []


@pytest.mark.anyio
async def test_deactivate_skill_multiple():
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    with get_db() as db:
        db.add(DBSessionSkill(session_id=sid, skill_id="sk-1"))
        db.add(DBSessionSkill(session_id=sid, skill_id="sk-2"))

    session = _session(sid)
    ctx = _ctx(session)

    result = await handle_deactivate_skill(_inp(skill_ids=["sk-1", "sk-2"]), ctx)
    text = _text(result.content[0])
    assert "sk-1" in text
    assert "sk-2" in text

    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill).where(DBSessionSkill.session_id == sid)
        ).scalars().all()
    assert rows == []


@pytest.mark.anyio
async def test_deactivate_skill_nonexistent_is_noop():
    """Deactivating a skill that is not active does not raise."""
    make_project("p-1")
    sid = make_session(project_id="p-1", sid="s-1")
    session = _session(sid)
    ctx = _ctx(session)

    result = await handle_deactivate_skill(_inp(skill_ids=["never-existed"]), ctx)
    assert result.is_error is False
    assert "never-existed" in _text(result.content[0])
