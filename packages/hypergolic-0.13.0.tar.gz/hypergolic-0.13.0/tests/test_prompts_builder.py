"""Tests for hypergolic.prompts.builder."""

from pathlib import Path
from unittest.mock import MagicMock, patch

from hypergolic.enums import ModelTier
from hypergolic.prompts.builder import (
    DEFAULT_SYSTEM_PROMPT,
    PromptBlock,
    _build_session_context,
    _build_workflow_prompt_blocks,
    _git_branch,
    build_prompt_blocks,
    build_session_prompt,
)
from hypergolic.schemas import Session
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.primitives import (
    Role,
    Workflow,
    WorkflowState,
)
from hypergolic.toolkit.project import Project
from tests.conftest import make_artifact, make_project, make_session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _session(
    sid: str = "s-1",
    project_id: str = "p-1",
    role: str = "generalist",
    dispatch_prompt: str | None = None,
    active_skill_ids: set[str] | None = None,
) -> Session:
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id=project_id,
        project_path="/tmp/p",
        role=role,
        dispatch_prompt=dispatch_prompt,
        active_skill_ids=active_skill_ids or set(),
    )


def _basic_app() -> App:
    """Create an App with a generalist role and set it as current."""
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="You are Hypergolic."))
    set_app(app)
    return app


# ---------------------------------------------------------------------------
# PromptBlock
# ---------------------------------------------------------------------------


def test_prompt_block_to_text_block():
    block = PromptBlock(source="test", text="hello world")
    result = block.to_text_block()
    assert result == {"type": "text", "text": "hello world"}


# ---------------------------------------------------------------------------
# _git_branch
# ---------------------------------------------------------------------------


def test_git_branch_returns_string_on_success():
    import subprocess
    with patch("hypergolic.prompts.builder.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(stdout="main\n", returncode=0)
        result = _git_branch(Path("/tmp"))
    assert result == "main"


def test_git_branch_returns_none_on_error():
    import subprocess
    with patch(
        "hypergolic.prompts.builder.subprocess.run",
        side_effect=subprocess.CalledProcessError(1, "git"),
    ):
        result = _git_branch(Path("/tmp"))
    assert result is None


def test_git_branch_returns_none_on_file_not_found():
    with patch(
        "hypergolic.prompts.builder.subprocess.run",
        side_effect=FileNotFoundError,
    ):
        result = _git_branch(Path("/tmp"))
    assert result is None


def test_git_branch_returns_none_for_empty_output():
    with patch("hypergolic.prompts.builder.subprocess.run") as mock_run:
        mock_run.return_value = MagicMock(stdout="", returncode=0)
        result = _git_branch(Path("/tmp"))
    assert result is None


# ---------------------------------------------------------------------------
# _build_session_context
# ---------------------------------------------------------------------------


def test_build_session_context_includes_working_directory():
    _basic_app()
    session = _session()
    with patch("hypergolic.prompts.builder._git_branch", return_value=None):
        ctx = _build_session_context(session)
    assert "/tmp/p" in ctx


def test_build_session_context_includes_git_branch_when_present():
    _basic_app()
    session = _session()
    with patch("hypergolic.prompts.builder._git_branch", return_value="feature-branch"):
        ctx = _build_session_context(session)
    assert "feature-branch" in ctx


def test_build_session_context_no_git_branch_when_none():
    _basic_app()
    session = _session()
    with patch("hypergolic.prompts.builder._git_branch", return_value=None):
        ctx = _build_session_context(session)
    assert "Git Branch" not in ctx


def test_build_session_context_includes_hypergolic_config_note():
    _basic_app()
    session = _session()
    with patch("hypergolic.prompts.builder._git_branch", return_value=None):
        ctx = _build_session_context(session)
    assert "~/.hypergolic/" in ctx


def test_build_session_context_omits_session_id_and_os():
    _basic_app()
    session = _session()
    with patch("hypergolic.prompts.builder._git_branch", return_value=None):
        ctx = _build_session_context(session)
    assert "s-1" not in ctx
    assert "OS:" not in ctx
    assert "Hypergolic Source Dir" not in ctx


# ---------------------------------------------------------------------------
# build_prompt_blocks
# ---------------------------------------------------------------------------


def test_build_prompt_blocks_includes_base_prompt():
    app = _basic_app()
    session = _session()

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "Base prompt" in sources


def test_build_prompt_blocks_base_prompt_default_when_no_generalist():
    app = App()
    # No roles at all
    set_app(app)
    session = _session()

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    base = next(b for b in blocks if b.source == "Base prompt")
    assert base.text == DEFAULT_SYSTEM_PROMPT


def test_build_prompt_blocks_non_generalist_role_adds_role_block():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="Base"))
    app.register_role(Role(id="worker", name="Worker", prompt="Worker prompt"))
    set_app(app)
    session = _session(role="worker")

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert any("Role prompt" in s for s in sources)


def test_build_prompt_blocks_non_generalist_role_no_prompt_skipped():
    """Non-generalist role with no resolvable prompt doesn\'t add a role block."""
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="Base"))
    # worker has no prompt/prompt_path/prompt_fn
    app.register_role(Role(id="worker", name="Worker"))
    set_app(app)
    session = _session(role="worker")

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert not any("Role prompt" in s for s in sources)


def test_build_prompt_blocks_non_generalist_role_not_found_skipped():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="Base"))
    set_app(app)
    session = _session(role="nonexistent-role")

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert not any("Role prompt" in s for s in sources)


def test_build_prompt_blocks_project_prompt_included():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="Base"))
    proj = Project(
        id="p-1",
        name="P",
        description="d",
        git_root="/tmp",
        prompt="Project-level prompt",
    )
    app.register_project(proj)
    set_app(app)
    session = _session()

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "User-project guidance" in sources


def test_build_prompt_blocks_project_no_prompt_skipped():
    app = App()
    app.register_role(Role(id="generalist", name="Generalist", prompt="Base"))
    proj = Project(id="p-1", name="P", description="d", git_root="/tmp")
    app.register_project(proj)
    set_app(app)
    session = _session()

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "User-project guidance" not in sources


def test_build_prompt_blocks_no_project_in_app():
    app = _basic_app()
    session = _session(project_id="p-unknown")

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "Session context" in sources


def test_build_prompt_blocks_includes_session_context():
    app = _basic_app()
    session = _session()

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "Session context" in sources


def test_build_prompt_blocks_includes_dispatch_prompt():
    app = _basic_app()
    session = _session(dispatch_prompt="You are a worker")

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "Dispatch context" in sources
    dispatch_block = next(b for b in blocks if b.source == "Dispatch context")
    assert "You are a worker" in dispatch_block.text


def test_build_prompt_blocks_no_dispatch_prompt_when_none():
    app = _basic_app()
    session = _session(dispatch_prompt=None)

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "Dispatch context" not in sources


def test_build_prompt_blocks_does_not_inject_active_skill_prompts():
    app = _basic_app()
    session = _session(active_skill_ids={"some-skill"})

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        blocks = build_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert not any(s.startswith("Skill:") for s in sources)


# ---------------------------------------------------------------------------
# _build_workflow_prompt_blocks
# ---------------------------------------------------------------------------


def test_build_workflow_prompt_blocks_no_active_workflow():
    app = _basic_app()
    session = _session()

    with patch("hypergolic.prompts.builder.get_session_workflow", return_value=None):
        blocks = _build_workflow_prompt_blocks(session)

    assert blocks == []


def test_build_workflow_prompt_blocks_workflow_not_found():
    app = _basic_app()
    session = _session()

    with (
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=("wf-x", "st-1")),
        patch("hypergolic.prompts.builder.get_workflow", return_value=None),
    ):
        blocks = _build_workflow_prompt_blocks(session)

    assert blocks == []


def test_build_workflow_prompt_blocks_workflow_with_prompt():
    app = _basic_app()
    session = _session()
    wf = Workflow(
        id="wf-1",
        name="Test WF",
        description="d",
        initial_state="st-1",
        prompt="Workflow prompt content",
        states=[WorkflowState(id="st-1", name="State One", prompt="state prompt")],
    )

    with (
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=("wf-1", "st-1")),
        patch("hypergolic.prompts.builder.get_workflow", return_value=wf),
    ):
        blocks = _build_workflow_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert any("Workflow: Test WF" in s for s in sources)


def test_build_workflow_prompt_blocks_state_with_prompt():
    app = _basic_app()
    session = _session()
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="st-1",
        states=[WorkflowState(id="st-1", name="State One", prompt="state specific prompt")],
    )

    with (
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=("wf-1", "st-1")),
        patch("hypergolic.prompts.builder.get_workflow", return_value=wf),
    ):
        blocks = _build_workflow_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert any("Workflow State: State One" in s for s in sources)


def test_build_workflow_prompt_blocks_state_not_found_in_workflow():
    app = _basic_app()
    session = _session()
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="st-1",
        states=[WorkflowState(id="st-1", name="S", prompt="p")],
    )

    with (
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=("wf-1", "st-missing")),
        patch("hypergolic.prompts.builder.get_workflow", return_value=wf),
    ):
        blocks = _build_workflow_prompt_blocks(session)

    # Returns early with whatever workflow-level blocks exist
    assert isinstance(blocks, list)


def test_build_workflow_prompt_blocks_with_artifacts():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    make_artifact(
        session_id="s-1",
        artifact_id="art-123",
        content={"result": "some result"},
    )

    app = _basic_app()
    session = Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="st-2",
        states=[
            WorkflowState(
                id="st-2",
                name="State Two",
                prompt="p",
                include_artifacts=["art-123"],
            )
        ],
    )

    with (
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=("wf-1", "st-2")),
        patch("hypergolic.prompts.builder.get_workflow", return_value=wf),
    ):
        blocks = _build_workflow_prompt_blocks(session)

    sources = [b.source for b in blocks]
    # Artifact preamble should be present
    assert "Artifact preamble" in sources
    # Artifact block should be present
    assert any("Artifact: art-123" in s for s in sources)


def test_build_workflow_prompt_blocks_no_artifacts_when_empty():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")

    app = _basic_app()
    session = Session(
        id="s-1",
        model_tier=ModelTier.MEDIUM,
        project_id="p-1",
        project_path="/tmp/p",
        role="generalist",
    )
    wf = Workflow(
        id="wf-1",
        name="WF",
        description="d",
        initial_state="st-1",
        states=[
            WorkflowState(
                id="st-1",
                name="State One",
                prompt="p",
                include_artifacts=["nonexistent-art"],
            )
        ],
    )

    with (
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=("wf-1", "st-1")),
        patch("hypergolic.prompts.builder.get_workflow", return_value=wf),
    ):
        blocks = _build_workflow_prompt_blocks(session)

    sources = [b.source for b in blocks]
    assert "Artifact preamble" not in sources


# ---------------------------------------------------------------------------
# build_session_prompt
# ---------------------------------------------------------------------------


def test_build_session_prompt_returns_text_blocks():
    app = _basic_app()
    session = _session()

    with (
        patch("hypergolic.prompts.builder._git_branch", return_value=None),
        patch("hypergolic.prompts.builder.get_session_workflow", return_value=None),
    ):
        result = build_session_prompt(session)

    assert isinstance(result, list)
    assert all(b["type"] == "text" for b in result)
    assert all(isinstance(b["text"], str) for b in result)
    assert len(result) >= 1
