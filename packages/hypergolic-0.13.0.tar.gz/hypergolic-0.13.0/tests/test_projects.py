import subprocess
from unittest.mock import MagicMock, patch

import pytest
from fastapi import HTTPException

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBProject, DBSession
from hypergolic.projects.operations import (
    build_project_response,
    validate_git_root,
)


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------

def _seed_project(pid: str = "proj-1", name: str = "Test", path: str = "/tmp/test") -> DBProject:
    with get_db() as db:
        p = DBProject(id=pid, name=name, path=path)
        db.add(p)
        db.flush()
        return p


def _seed_session(project_id: str = "proj-1") -> str:
    with get_db() as db:
        s = DBSession(
            model_tier="High",
            system_prompt=[],
            role="generalist",
            status="idle",
            project_id=project_id,
        )
        db.add(s)
        db.flush()
        return s.id


def _seed_message(session_id: str) -> str:
    with get_db() as db:
        m = DBMessage(
            content=[{"type": "text", "text": "hello"}],
            session_id=session_id,
            role="user",
        )
        db.add(m)
        db.flush()
        return m.id


# ---------------------------------------------------------------------------
# Unit tests — build_project_response
# ---------------------------------------------------------------------------

def test_build_project_response():
    with get_db() as db:
        p = DBProject(id="p-1", name="Proj", path="/tmp/proj")
        db.add(p)
        db.flush()
        resp = build_project_response(p, last_session_at="2025-01-01T00:00:00+00:00")
    assert resp.id == "p-1"
    assert resp.name == "Proj"
    assert resp.path == "/tmp/proj"
    assert resp.last_session_at == "2025-01-01T00:00:00+00:00"
    assert resp.created_at is not None


def test_build_project_response_no_last_session():
    with get_db() as db:
        p = DBProject(id="p-2", name="Proj2", path="/tmp/proj2")
        db.add(p)
        db.flush()
        resp = build_project_response(p)
    assert resp.last_session_at is None


# ---------------------------------------------------------------------------
# Unit tests — validate_git_root
# ---------------------------------------------------------------------------

def test_validate_git_root_success():
    mock_result = MagicMock()
    mock_result.stdout = "/tmp/myrepo\n"
    with patch("hypergolic.projects.operations.subprocess.run", return_value=mock_result):
        validate_git_root("/tmp/myrepo")  # should not raise


def test_validate_git_root_mismatch():
    mock_result = MagicMock()
    mock_result.stdout = "/tmp/other\n"
    with patch("hypergolic.projects.operations.subprocess.run", return_value=mock_result):
        with pytest.raises(HTTPException) as exc_info:
            validate_git_root("/tmp/myrepo")
    assert exc_info.value.status_code == 400
    assert "not a git root" in exc_info.value.detail


def test_validate_git_root_not_git_repo():
    with patch(
        "hypergolic.projects.operations.subprocess.run",
        side_effect=subprocess.CalledProcessError(128, "git"),
    ):
        with pytest.raises(HTTPException) as exc_info:
            validate_git_root("/tmp/notgit")
    assert exc_info.value.status_code == 400
    assert "not a valid git repository" in exc_info.value.detail


def test_validate_git_root_not_found():
    with patch(
        "hypergolic.projects.operations.subprocess.run",
        side_effect=FileNotFoundError("git not found"),
    ):
        with pytest.raises(HTTPException) as exc_info:
            validate_git_root("/tmp/nope")
    assert exc_info.value.status_code == 400
    assert "not a valid git repository" in exc_info.value.detail


def test_validate_git_root_os_error():
    with patch(
        "hypergolic.projects.operations.subprocess.run",
        side_effect=OSError("something broke"),
    ):
        with pytest.raises(HTTPException) as exc_info:
            validate_git_root("/tmp/broken")
    assert exc_info.value.status_code == 400
    assert "not a valid git repository" in exc_info.value.detail


# ---------------------------------------------------------------------------
# Integration tests via api_client
# ---------------------------------------------------------------------------

def test_list_projects_empty(api_client):
    resp = api_client.get("/api/projects")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_projects_with_data(api_client):
    _seed_project("p-a", "Alpha", "/tmp/alpha")
    _seed_project("p-b", "Beta", "/tmp/beta")
    resp = api_client.get("/api/projects")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    # Ordered by name when no sessions
    assert data[0]["name"] == "Alpha"
    assert data[1]["name"] == "Beta"
    assert data[0]["last_session_at"] is None


def test_list_projects_with_sessions(api_client):
    _seed_project("p-a", "Alpha", "/tmp/alpha")
    _seed_project("p-b", "Beta", "/tmp/beta")
    _seed_session("p-b")  # Beta has a session, so it comes first
    resp = api_client.get("/api/projects")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    assert data[0]["name"] == "Beta"
    assert data[0]["last_session_at"] is not None
    assert data[1]["name"] == "Alpha"
    assert data[1]["last_session_at"] is None


def test_create_project_success(api_client):
    mock_result = MagicMock()
    mock_result.stdout = "/tmp/newproject\n"
    with patch(
        "hypergolic.projects.operations.subprocess.run",
        return_value=mock_result,
    ):
        resp = api_client.post(
            "/api/projects",
            json={"name": "New", "path": "/tmp/newproject"},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["name"] == "New"
    assert data["path"] == "/tmp/newproject"
    assert data["id"] is not None
    assert data["created_at"] is not None
    assert data["last_session_at"] is None


def test_create_project_duplicate_path(api_client):
    _seed_project("p-dup", "Existing", "/tmp/dup")
    mock_result = MagicMock()
    mock_result.stdout = "/tmp/dup\n"
    with patch(
        "hypergolic.projects.operations.subprocess.run",
        return_value=mock_result,
    ):
        resp = api_client.post(
            "/api/projects",
            json={"name": "Dupe", "path": "/tmp/dup"},
        )
    assert resp.status_code == 409
    assert "already exists" in resp.json()["detail"]


def test_delete_project_success(api_client):
    _seed_project("p-del", "ToDelete", "/tmp/del")
    resp = api_client.delete("/api/projects/p-del")
    assert resp.status_code == 200
    assert resp.json() == {"status": "deleted"}
    # Verify gone
    resp2 = api_client.get("/api/projects")
    assert resp2.json() == []


def test_delete_project_not_found(api_client):
    resp = api_client.delete("/api/projects/nonexistent")
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


def test_delete_project_with_sessions_and_messages(api_client):
    _seed_project("p-cas", "Cascade", "/tmp/cascade")
    sid = _seed_session("p-cas")
    _seed_message(sid)
    _seed_message(sid)

    resp = api_client.delete("/api/projects/p-cas")
    assert resp.status_code == 200
    assert resp.json() == {"status": "deleted"}

    # Verify everything is cleaned up
    with get_db() as db:
        from sqlalchemy import select

        assert db.execute(select(DBProject)).scalars().all() == []
        assert db.execute(select(DBSession)).scalars().all() == []
        assert db.execute(select(DBMessage)).scalars().all() == []
