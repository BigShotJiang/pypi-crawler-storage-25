"""Tests for hypergolic.messages.conversation.stop_reasons."""

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest
from anthropic.types import Message, TextBlock, ToolUseBlock, Usage

from hypergolic.enums import ModelTier
from hypergolic.messages.conversation.stop_reasons import (
    CONTINUE_MESSAGES,
    TRUNCATED_TOOL_USE_ERROR,
    _build_truncated_tool_results,
    handle_continue,
)
from hypergolic.messages.types import BroadcastEvent, UserInterrupt
from hypergolic.schemas import Session


def _make_session(**overrides: Any) -> Session:
    defaults: dict[str, Any] = dict(
        id="sess-1",
        model_tier=ModelTier.LOW,
        project_id="proj-1",
        project_path="/tmp/test",
        role="generalist",
    )
    defaults.update(overrides)
    return Session(**defaults)


def _make_response(
    stop_reason: Any = "max_tokens",
    content: list[Any] | None = None,
) -> Message:
    default_content: list[Any] = [TextBlock(type="text", text="hello")]
    return Message(
        id="msg-1",
        content=content or default_content,
        model="claude-sonnet-4-20250514",
        role="assistant",
        stop_reason=stop_reason,
        stop_sequence=None,
        type="message",
        usage=Usage(input_tokens=10, output_tokens=20),
    )


# ---------------------------------------------------------------------------
# CONTINUE_MESSAGES
# ---------------------------------------------------------------------------


def test_continue_messages_has_max_tokens():
    assert "max_tokens" in CONTINUE_MESSAGES
    assert "max_tokens" in CONTINUE_MESSAGES["max_tokens"]


def test_continue_messages_has_pause_turn():
    assert "pause_turn" in CONTINUE_MESSAGES
    assert "pause_turn" in CONTINUE_MESSAGES["pause_turn"]


# ---------------------------------------------------------------------------
# _build_truncated_tool_results
# ---------------------------------------------------------------------------


def test_build_truncated_tool_results_no_tool_use():
    response = _make_response(content=[TextBlock(type="text", text="hello")])
    assert _build_truncated_tool_results(response) == []


def test_build_truncated_tool_results_with_tool_use():
    response = _make_response(
        content=[
            TextBlock(type="text", text="Let me do that"),
            ToolUseBlock(type="tool_use", id="tu-1", name="read_files", input={"paths": ["a.py"]}),
            ToolUseBlock(type="tool_use", id="tu-2", name="write_files", input={"files": []}),
        ]
    )
    results = _build_truncated_tool_results(response)
    assert len(results) == 2
    assert results[0]["type"] == "tool_result"
    assert results[0]["tool_use_id"] == "tu-1"
    assert results[0]["is_error"] is True
    content_blocks = list(results[0]["content"])  # type: ignore[arg-type]
    assert content_blocks[0]["text"] == TRUNCATED_TOOL_USE_ERROR
    assert results[1]["tool_use_id"] == "tu-2"


# ---------------------------------------------------------------------------
# handle_continue — max_tokens (no tool_use in response)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_continue_max_tokens_persists_and_broadcasts():
    session = _make_session()
    broadcast = AsyncMock()
    check_cancelled = MagicMock()
    response = _make_response(stop_reason="max_tokens")

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await handle_continue("max_tokens", session, broadcast, check_cancelled, response=response)

    check_cancelled.assert_called_once()

    # Verify persisted message
    mock_persist.assert_awaited_once()
    call_kwargs = mock_persist.call_args[1]
    assert call_kwargs["session_id"] == "sess-1"
    persisted = call_kwargs["message"]
    assert persisted["role"] == "user"
    # Only one block — the continuation text (no tool_results)
    assert len(persisted["content"]) == 1
    assert persisted["content"][0]["text"] == CONTINUE_MESSAGES["max_tokens"]

    # Verify broadcast
    broadcast.assert_awaited_once()
    event: BroadcastEvent = broadcast.call_args[0][0]
    assert event.type == "tool_result"
    assert event.role == "user"
    assert event.session_id == "sess-1"
    assert len(event.content) == 1
    assert event.content[0]["text"] == CONTINUE_MESSAGES["max_tokens"]


# ---------------------------------------------------------------------------
# handle_continue — max_tokens with truncated tool_use blocks
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_continue_max_tokens_with_tool_use_injects_tool_results():
    """When max_tokens truncates a response mid-tool-call, synthetic error
    tool_results must be injected so the API doesn't reject the next request."""
    session = _make_session()
    broadcast = AsyncMock()
    check_cancelled = MagicMock()
    response = _make_response(
        stop_reason="max_tokens",
        content=[
            TextBlock(type="text", text="Let me call that tool"),
            ToolUseBlock(type="tool_use", id="tu-abc", name="read_files", input={"paths": ["x.py"]}),
        ],
    )

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await handle_continue("max_tokens", session, broadcast, check_cancelled, response=response)

    # Verify persisted message has tool_result + continuation text
    persisted = mock_persist.call_args[1]["message"]
    assert persisted["role"] == "user"
    assert len(persisted["content"]) == 2
    # First block: synthetic tool_result
    assert persisted["content"][0]["type"] == "tool_result"
    assert persisted["content"][0]["tool_use_id"] == "tu-abc"
    assert persisted["content"][0]["is_error"] is True
    assert persisted["content"][0]["content"][0]["text"] == TRUNCATED_TOOL_USE_ERROR
    # Second block: continuation text
    assert persisted["content"][1]["type"] == "text"
    assert persisted["content"][1]["text"] == CONTINUE_MESSAGES["max_tokens"]

    # Broadcast should match
    event: BroadcastEvent = broadcast.call_args[0][0]
    assert len(event.content) == 2
    assert event.content[0]["type"] == "tool_result"
    assert event.content[1]["text"] == CONTINUE_MESSAGES["max_tokens"]


@pytest.mark.asyncio
async def test_handle_continue_max_tokens_multiple_tool_use_blocks():
    """All tool_use blocks in the truncated response get error tool_results."""
    session = _make_session()
    broadcast = AsyncMock()
    check_cancelled = MagicMock()
    response = _make_response(
        stop_reason="max_tokens",
        content=[
            ToolUseBlock(type="tool_use", id="tu-1", name="tool_a", input={}),
            ToolUseBlock(type="tool_use", id="tu-2", name="tool_b", input={}),
        ],
    )

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await handle_continue("max_tokens", session, broadcast, check_cancelled, response=response)

    persisted = mock_persist.call_args[1]["message"]
    # 2 tool_results + 1 continuation text
    assert len(persisted["content"]) == 3
    assert persisted["content"][0]["tool_use_id"] == "tu-1"
    assert persisted["content"][1]["tool_use_id"] == "tu-2"
    assert persisted["content"][2]["type"] == "text"


# ---------------------------------------------------------------------------
# handle_continue — no response passed (backward compat)
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_continue_no_response_still_works():
    """When response is None (backward compat), just inject continuation text."""
    session = _make_session()
    broadcast = AsyncMock()
    check_cancelled = MagicMock()

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await handle_continue("max_tokens", session, broadcast, check_cancelled)

    persisted = mock_persist.call_args[1]["message"]
    assert len(persisted["content"]) == 1
    assert persisted["content"][0]["text"] == CONTINUE_MESSAGES["max_tokens"]


# ---------------------------------------------------------------------------
# handle_continue — pause_turn
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_continue_pause_turn_persists_and_broadcasts():
    session = _make_session()
    broadcast = AsyncMock()
    check_cancelled = MagicMock()
    response = _make_response(stop_reason="pause_turn")

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        await handle_continue("pause_turn", session, broadcast, check_cancelled, response=response)

    check_cancelled.assert_called_once()

    mock_persist.assert_awaited_once()
    call_kwargs = mock_persist.call_args[1]
    persisted = call_kwargs["message"]
    assert persisted["content"][-1]["text"] == CONTINUE_MESSAGES["pause_turn"]

    broadcast.assert_awaited_once()
    event: BroadcastEvent = broadcast.call_args[0][0]
    assert event.content[-1]["text"] == CONTINUE_MESSAGES["pause_turn"]


# ---------------------------------------------------------------------------
# handle_continue — check_cancelled fires first
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_continue_checks_cancelled_before_persisting():
    session = _make_session()
    broadcast = AsyncMock()

    def raise_interrupt():
        raise UserInterrupt()

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ) as mock_persist:
        with pytest.raises(UserInterrupt):
            await handle_continue("max_tokens", session, broadcast, raise_interrupt)

    mock_persist.assert_not_awaited()
    broadcast.assert_not_awaited()


# ---------------------------------------------------------------------------
# handle_continue — unknown stop reason raises KeyError
# ---------------------------------------------------------------------------


@pytest.mark.asyncio
async def test_handle_continue_unknown_reason_raises_key_error():
    session = _make_session()
    broadcast = AsyncMock()
    check_cancelled = MagicMock()

    with patch(
        "hypergolic.messages.conversation.stop_reasons.persist_user_message",
        new=AsyncMock(),
    ):
        with pytest.raises(KeyError):
            await handle_continue("unknown_reason", session, broadcast, check_cancelled)
