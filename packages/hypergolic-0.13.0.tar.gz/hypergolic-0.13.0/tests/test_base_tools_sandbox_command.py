"""Tests for hypergolic.base.tools.sandbox_command."""

import asyncio
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.base.tools.sandbox_command import (
    SandboxCommandInput,
    _resolve_sandbox_config_path,
    make_sandbox_command_tool,
    run_sandbox_command,
    sandbox_command_tool,
)
from hypergolic.enums import ModelTier
from hypergolic.sandbox.manager import ExecResult, SandboxError, SandboxUnavailableError
from hypergolic.schemas import Session
from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.primitives import Role, Skill, Tool, ToolContext
from hypergolic.toolkit.project import Project
from tests.conftest import make_project, make_session


# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------


def _session(sid: str = "s1", project_path: str = "/tmp/p1") -> Session:
    return Session(
        id=sid,
        model_tier=ModelTier.MEDIUM,
        project_id="p1",
        project_path=project_path,
        role="generalist",
    )


def _context(session: Session, tool_id: str = "sandbox_command") -> ToolContext:
    return ToolContext(
        session=session,
        broadcast=AsyncMock(),
        tool_id=tool_id,
    )


async def _noop(inp, ctx):
    return "ok"


def _tool_with_config(tid: str, config_path: str) -> Tool:
    return Tool(
        id=tid, name=tid, description="d",
        run=_noop,
        sandbox_config_path=config_path,
    )


# ---------------------------------------------------------------------------
# make_sandbox_command_tool / sandbox_command_tool
# ---------------------------------------------------------------------------


def test_make_sandbox_command_tool_returns_tool():
    tool = make_sandbox_command_tool("/path/to/sandbox.yaml")
    assert isinstance(tool, Tool)
    assert tool.id == "sandbox_command"
    assert tool.sandbox_config_path == "/path/to/sandbox.yaml"


def test_sandbox_command_tool_default_config():
    assert sandbox_command_tool.id == "sandbox_command"
    assert sandbox_command_tool.sandbox_config_path is not None
    assert "sandbox.yaml" in sandbox_command_tool.sandbox_config_path


# ---------------------------------------------------------------------------
# _resolve_sandbox_config_path
# ---------------------------------------------------------------------------


def test_resolve_config_path_from_app_tools():
    app = App()
    t = _tool_with_config("sc-tool", "/app/sandbox.yaml")
    app.register_tool(t)
    set_app(app)

    result = _resolve_sandbox_config_path("sc-tool")
    assert result == "/app/sandbox.yaml"


def test_resolve_config_path_from_project_tools():
    app = App()
    proj = Project(id="p1", name="P1", description="d", git_root="/tmp")
    t = _tool_with_config("proj-sc", "/proj/sandbox.yaml")
    proj.register_tool(t)
    app.register_project(proj)
    set_app(app)

    result = _resolve_sandbox_config_path("proj-sc")
    assert result == "/proj/sandbox.yaml"


def test_resolve_config_path_from_role_tools():
    app = App()
    t = _tool_with_config("role-sc", "/role/sandbox.yaml")
    role = Role(id="r1", name="R1", prompt="t", tools=[t])
    app.register_role(role)
    set_app(app)

    result = _resolve_sandbox_config_path("role-sc")
    assert result == "/role/sandbox.yaml"


def test_resolve_config_path_from_skill_tools():
    app = App()
    t = _tool_with_config("skill-sc", "/skill/sandbox.yaml")
    skill = Skill(id="sk1", name="sk1", description="d", tools=[t])
    app.register_skill(skill)
    set_app(app)

    result = _resolve_sandbox_config_path("skill-sc")
    assert result == "/skill/sandbox.yaml"


def test_resolve_config_path_not_found():
    app = App()
    set_app(app)

    result = _resolve_sandbox_config_path("nonexistent-tool")
    assert result is None


def test_resolve_config_path_tool_exists_but_no_config():
    """Tool exists but sandbox_config_path is None — should not return it."""
    app = App()
    t = Tool(id="no-config", name="no-config", description="d", run=_noop)
    app.register_tool(t)
    set_app(app)

    result = _resolve_sandbox_config_path("no-config")
    assert result is None


# ---------------------------------------------------------------------------
# run_sandbox_command — no config path
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_run_sandbox_command_no_config_path():
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="no-cfg")
    inp = SandboxCommandInput(command="ls")

    with patch(
        "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
        return_value=None,
    ):
        result = await run_sandbox_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "No sandbox_config_path" in result.content[0]["text"]


# ---------------------------------------------------------------------------
# run_sandbox_command — sandbox not running, start it
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_run_sandbox_command_starts_sandbox_then_executes():
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="echo hello")

    exec_result = ExecResult(stdout="hello", stderr="", returncode=0)

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(return_value="hg-sc-abc"),
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.exec_in_sandbox",
            AsyncMock(return_value=exec_result),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    assert result.outcome == "SUCCESS"
    assert "hello" in result.content[0]["text"]


@pytest.mark.anyio
async def test_run_sandbox_command_sandbox_already_running():
    """When sandbox is running, skips start and goes straight to exec."""
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="ls")

    mock_sandbox = MagicMock()
    mock_sandbox.status = "running"

    exec_result = ExecResult(stdout="file.txt", stderr="", returncode=0)

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=mock_sandbox,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(),
        ) as mock_start,
        patch(
            "hypergolic.base.tools.sandbox_command.exec_in_sandbox",
            AsyncMock(return_value=exec_result),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    mock_start.assert_not_called()
    assert result.outcome == "SUCCESS"


# ---------------------------------------------------------------------------
# run_sandbox_command — start failures
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_run_sandbox_command_sandbox_unavailable():
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="ls")

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(side_effect=SandboxUnavailableError("Docker not found")),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Docker not found" in result.content[0]["text"]


@pytest.mark.anyio
async def test_run_sandbox_command_start_error():
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="ls")

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(side_effect=SandboxError("Container failed to start")),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Sandbox startup failed" in result.content[0]["text"]


# ---------------------------------------------------------------------------
# run_sandbox_command — exec failures
# ---------------------------------------------------------------------------


@pytest.mark.anyio
async def test_run_sandbox_command_exec_failure_nonzero():
    """Non-zero exit code produces FAILURE outcome."""
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="exit 1")

    exec_result = ExecResult(stdout="", stderr="error output", returncode=1)

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(return_value="hg-sc-abc"),
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.exec_in_sandbox",
            AsyncMock(return_value=exec_result),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "STDERR" in result.content[0]["text"]
    assert "Exit code: 1" in result.content[0]["text"]


@pytest.mark.anyio
async def test_run_sandbox_command_exec_sandbox_error():
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="ls")

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(return_value="hg-sc-abc"),
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.exec_in_sandbox",
            AsyncMock(side_effect=SandboxError("container died")),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    assert result.outcome == "FAILURE"
    assert "Sandbox error" in result.content[0]["text"]


@pytest.mark.anyio
async def test_run_sandbox_command_with_stdout_and_stderr():
    """Both stdout and stderr are included in output."""
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="cmd")

    exec_result = ExecResult(stdout="output line", stderr="warning", returncode=0)

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(return_value="hg-sc-abc"),
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.exec_in_sandbox",
            AsyncMock(return_value=exec_result),
        ),
    ):
        result = await run_sandbox_command(inp, ctx)

    text = result.content[0]["text"]
    assert "STDOUT" in text
    assert "STDERR" in text
    assert "output line" in text
    assert "warning" in text


@pytest.mark.anyio
async def test_run_sandbox_command_custom_timeout():
    """Custom timeout is passed through to exec_in_sandbox."""
    make_project("p1")
    sid = make_session(project_id="p1")
    session = _session(sid=sid)
    ctx = _context(session, tool_id="sc")
    inp = SandboxCommandInput(command="ls", timeout=60)

    exec_result = ExecResult(stdout="", stderr="", returncode=0)
    mock_exec = AsyncMock(return_value=exec_result)

    with (
        patch(
            "hypergolic.base.tools.sandbox_command._resolve_sandbox_config_path",
            return_value="/fake/sandbox.yaml",
        ),
        patch(
            "hypergolic.base.tools.sandbox_command._get_sandbox",
            return_value=None,
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.start_sandbox",
            AsyncMock(return_value="hg-sc-abc"),
        ),
        patch(
            "hypergolic.base.tools.sandbox_command.exec_in_sandbox",
            mock_exec,
        ),
    ):
        await run_sandbox_command(inp, ctx)

    call_kwargs = mock_exec.call_args[1]
    assert call_kwargs["timeout"] == 60
