from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage, DBProject, DBSession
from hypergolic.sessions.description.generate import (
    DESCRIPTION_CHAR_THRESHOLD,
    _generate_description,
    _get_dispatch_prompt,
    maybe_generate_description,
)
from hypergolic.sessions.description.store import (
    get_session_description,
    save_description,
)
from hypergolic.sessions.description.text import (
    count_user_text_chars,
    get_user_text_preview,
)


def _seed(sid="s1", parent_id=None, dispatch_prompt=None):
    with get_db() as db:
        if not db.get(DBProject, "p1"):
            db.add(DBProject(id="p1", name="Proj", path="/tmp/p"))
        db.add(DBSession(
            id=sid, model_tier="Medium", system_prompt=[], project_id="p1",
            parent_id=parent_id, dispatch_prompt=dispatch_prompt,
        ))


def _add_msg(sid, role, text, truncated=False):
    with get_db() as db:
        db.add(DBMessage(
            session_id=sid, role=role, truncated=truncated,
            content=[{"type": "text", "text": text}],
        ))


def test_count_user_text_chars_basic():
    _seed()
    _add_msg("s1", "user", "hello world")
    assert count_user_text_chars("s1") == 11


def test_count_ignores_assistant_messages():
    _seed()
    _add_msg("s1", "user", "hi")
    _add_msg("s1", "assistant", "long assistant response here")
    assert count_user_text_chars("s1") == 2


def test_count_ignores_truncated_messages():
    _seed()
    _add_msg("s1", "user", "visible", truncated=False)
    _add_msg("s1", "user", "hidden", truncated=True)
    assert count_user_text_chars("s1") == 7


def test_count_ignores_non_text_blocks():
    _seed()
    with get_db() as db:
        db.add(DBMessage(
            session_id="s1", role="user",
            content=[
                {"type": "text", "text": "abc"},
                {"type": "tool_result", "tool_use_id": "t1", "content": "big data"},
            ],
        ))
    assert count_user_text_chars("s1") == 3


def test_extract_text_returns_empty_for_unexpected_types():
    from hypergolic.sessions.description.text import extract_text
    assert extract_text(12345) == ""
    assert extract_text(None) == ""


def test_count_handles_string_content():
    _seed()
    with get_db() as db:
        db.add(DBMessage(
            session_id="s1", role="user", content="raw string",
        ))
    assert count_user_text_chars("s1") == 10


def test_get_session_description_none():
    _seed()
    assert get_session_description("s1") is None


def test_save_and_get_description():
    _seed()
    save_description("s1", "my description")
    assert get_session_description("s1") == "my description"


def test_get_user_text_preview():
    _seed()
    _add_msg("s1", "user", "first message")
    _add_msg("s1", "assistant", "ignored")
    _add_msg("s1", "user", "second message")
    preview = get_user_text_preview("s1")
    assert "first message" in preview
    assert "second message" in preview
    assert "ignored" not in preview


def test_get_user_text_preview_truncated():
    _seed()
    _add_msg("s1", "user", "x" * 3000)
    preview = get_user_text_preview("s1")
    assert len(preview) == 2000


def test_get_user_text_preview_string_content():
    _seed()
    with get_db() as db:
        db.add(DBMessage(
            session_id="s1", role="user", content="raw string msg",
        ))
    preview = get_user_text_preview("s1")
    assert "raw string msg" in preview


@pytest.mark.asyncio
async def test_generate_description_calls_api():
    _seed()
    _add_msg("s1", "user", "I want to build a session description feature")

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.generate_text", new=AsyncMock(return_value="Session description feature")):
        await _generate_description("s1", broadcast)

    assert get_session_description("s1") == "Session description feature"
    broadcast.assert_called_once()
    event = broadcast.call_args[0][0]
    assert event.type == "session_description_update"
    assert event.session_id == "s1"
    assert event.content == [{"description": "Session description feature"}]


@pytest.mark.asyncio
async def test_generate_description_strips_quotes():
    _seed()
    _add_msg("s1", "user", "I want to build a session description feature")

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.generate_text", new=AsyncMock(return_value='"Session description feature"')):
        await _generate_description("s1", broadcast)

    assert get_session_description("s1") == "Session description feature"


@pytest.mark.asyncio
async def test_generate_description_strips_leading_dash():
    _seed()
    _add_msg("s1", "user", "Fix pagination in list view")

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.generate_text", new=AsyncMock(return_value="- Fix list pagination")):
        await _generate_description("s1", broadcast)

    assert get_session_description("s1") == "Fix list pagination"


@pytest.mark.asyncio
async def test_generate_description_strips_to_empty():
    _seed()
    _add_msg("s1", "user", "some content")

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.generate_text", new=AsyncMock(return_value='""')):
        await _generate_description("s1", broadcast)

    assert get_session_description("s1") is None
    broadcast.assert_not_called()


@pytest.mark.asyncio
async def test_generate_description_handles_empty_preview():
    _seed()
    broadcast = AsyncMock()
    await _generate_description("s1", broadcast)
    assert get_session_description("s1") is None
    broadcast.assert_not_called()


@pytest.mark.asyncio
async def test_generate_description_handles_empty_response():
    _seed()
    _add_msg("s1", "user", "some content here")

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.generate_text", new=AsyncMock(return_value=None)):
        await _generate_description("s1", broadcast)

    assert get_session_description("s1") is None
    broadcast.assert_not_called()


@pytest.mark.asyncio
async def test_generate_description_handles_api_error():
    _seed()
    _add_msg("s1", "user", "some content here")

    broadcast = AsyncMock()
    with patch(
        "hypergolic.sessions.description.generate.generate_text",
        new=AsyncMock(side_effect=RuntimeError("API down")),
    ):
        await _generate_description("s1", broadcast)

    assert get_session_description("s1") is None
    broadcast.assert_not_called()


def test_maybe_generate_skips_if_description_exists():
    _seed()
    save_description("s1", "already set")
    _add_msg("s1", "user", "x" * 200)

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.asyncio") as mock_asyncio:
        maybe_generate_description("s1", broadcast)
        mock_asyncio.create_task.assert_not_called()


def test_maybe_generate_skips_below_threshold():
    _seed()
    _add_msg("s1", "user", "x" * (DESCRIPTION_CHAR_THRESHOLD - 1))

    broadcast = AsyncMock()
    with patch("hypergolic.sessions.description.generate.asyncio") as mock_asyncio:
        maybe_generate_description("s1", broadcast)
        mock_asyncio.create_task.assert_not_called()


def test_maybe_generate_fires_at_threshold():
    _seed()
    _add_msg("s1", "user", "x" * DESCRIPTION_CHAR_THRESHOLD)

    broadcast = AsyncMock()
    sentinel = object()
    with patch(
        "hypergolic.sessions.description.generate._generate_description",
        new=MagicMock(return_value=sentinel),
    ):
        with patch("hypergolic.sessions.description.generate.asyncio") as mock_asyncio:
            maybe_generate_description("s1", broadcast)
            mock_asyncio.create_task.assert_called_once_with(sentinel)


def test_session_response_includes_description(api_client, seed_project):
    from hypergolic.sessions.operations import create_session

    session = create_session(project_id=seed_project)
    save_description(session.id, "Test description")

    resp = api_client.get("/api/sessions")
    assert resp.status_code == 200
    sessions = resp.json()
    match = [s for s in sessions if s["id"] == session.id]
    assert len(match) == 1
    assert match[0]["description"] == "Test description"


def test_session_response_description_null_by_default(api_client, seed_project):
    from hypergolic.sessions.operations import create_session

    create_session(project_id=seed_project)

    resp = api_client.get("/api/sessions")
    assert resp.status_code == 200
    sessions = resp.json()
    assert sessions[0]["description"] is None


# --- Child session (dispatch) description tests ---

def test_get_dispatch_prompt_returns_none_for_normal_session():
    _seed()
    assert _get_dispatch_prompt("s1") is None


def test_get_dispatch_prompt_strips_conclude_instruction():
    _seed("parent")
    raw = (
        "Research the architecture of the project"
        "\n\nCRITICAL: You MUST call `conclude` as your final action"
        " \u2014 the parent session is deadlocked until you do. "
        "Never end your turn without calling conclude."
    )
    _seed("child", parent_id="parent", dispatch_prompt=raw)
    result = _get_dispatch_prompt("child")
    assert result == "Research the architecture of the project"


def test_get_dispatch_prompt_returns_full_prompt_if_no_marker():
    _seed("parent")
    _seed("child", parent_id="parent", dispatch_prompt="Do the thing")
    assert _get_dispatch_prompt("child") == "Do the thing"


def test_maybe_generate_fires_immediately_for_child_session():
    """Child sessions should attempt description generation immediately
    (using dispatch_prompt) without waiting for DESCRIPTION_CHAR_THRESHOLD."""
    _seed("parent")
    _seed("child", parent_id="parent", dispatch_prompt="Investigate the bug in module X")

    broadcast = AsyncMock()
    sentinel = object()
    with patch(
        "hypergolic.sessions.description.generate._generate_description",
        new=MagicMock(return_value=sentinel),
    ):
        with patch("hypergolic.sessions.description.generate.asyncio") as mock_asyncio:
            maybe_generate_description("child", broadcast)
            mock_asyncio.create_task.assert_called_once_with(sentinel)


@pytest.mark.asyncio
async def test_generate_description_uses_dispatch_prompt_for_child():
    _seed("parent")
    _seed("child", parent_id="parent", dispatch_prompt="Analyze the database schema")

    broadcast = AsyncMock()
    mock_generate = AsyncMock(return_value="Database schema analysis")
    with patch("hypergolic.sessions.description.generate.generate_text", new=mock_generate):
        await _generate_description("child", broadcast)

    assert get_session_description("child") == "Database schema analysis"
    # Verify the dispatch prompt was sent as input (not user messages)
    call_kwargs = mock_generate.call_args[1]
    assert "Analyze the database schema" in call_kwargs["messages"][0]["content"]
    assert "<session_messages>" in call_kwargs["messages"][0]["content"]
