"""Tests for hypergolic CLI modules: app, doctor_cmd, setup, update_cmd, version."""

import subprocess
from pathlib import Path
from unittest.mock import MagicMock, patch

import pytest
import typer
from typer.testing import CliRunner

from hypergolic.cli.app import app, _version_callback
from hypergolic.cli.version import get_version


# ===========================================================================
# version.py
# ===========================================================================


def test_get_version_returns_string():
    v = get_version()
    assert isinstance(v, str)
    assert len(v) > 0


def test_get_version_returns_unknown_on_exception():
    with patch("hypergolic.cli.version.pkg_version", side_effect=Exception("not found")):
        v = get_version()
    assert v == "unknown"


# ===========================================================================
# app.py — CLI entry point
# ===========================================================================


def test_app_version_flag():
    runner = CliRunner()
    result = runner.invoke(app, ["--version"])
    assert result.exit_code == 0
    assert "hypergolic" in result.output


def test_app_short_version_flag():
    runner = CliRunner()
    result = runner.invoke(app, ["-v"])
    assert result.exit_code == 0
    assert "hypergolic" in result.output


def test_version_callback_false_does_nothing():
    """Calling the callback with value=False should not raise Exit."""
    _version_callback(False)
    # No exception means pass


def test_version_callback_true_exits():
    """Calling the callback with value=True raises typer.Exit."""
    with pytest.raises(typer.Exit):
        _version_callback(True)


def test_app_has_init_command():
    runner = CliRunner()
    # init requires interaction; just confirm it exists and is registered
    result = runner.invoke(app, ["--help"])
    assert "init" in result.output


def test_app_has_update_command():
    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert "update" in result.output


def test_app_has_doctor_command():
    runner = CliRunner()
    result = runner.invoke(app, ["--help"])
    assert "doctor" in result.output


# ===========================================================================
# doctor_cmd.py
# ===========================================================================


def _make_doctor_dir(root: Path) -> None:
    """Create a fully-valid doctor check directory."""
    (root / "main.py").write_text("# valid python\n")
    (root / "pyproject.toml").write_text("[project]\n")
    base = root / "base"
    base.mkdir()
    tools = base / "tools"
    tools.mkdir()
    (tools / "__init__.py").write_text("")
    (root / "hypergolic.db").write_text("")
    (root / ".ref").mkdir()


def test_doctor_all_checks_pass(tmp_path):
    """All checks pass when directory is fully set up."""
    _make_doctor_dir(tmp_path)

    from hypergolic.cli.doctor_cmd import HYPERGOLIC_DIR
    with patch("hypergolic.cli.doctor_cmd.HYPERGOLIC_DIR", tmp_path):
        from hypergolic.cli import doctor_cmd
        old_dir = doctor_cmd.HYPERGOLIC_DIR
        doctor_cmd.HYPERGOLIC_DIR = tmp_path
        try:
            # Invoke via typer runner
            from typer.testing import CliRunner as TRunner
            import typer
            app2 = typer.Typer()
            app2.command()(doctor_cmd.doctor)
            runner = TRunner()
            with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
                mock_rec.return_value.is_clean.return_value = True
                result = runner.invoke(app2, [])
        finally:
            doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 0


def test_doctor_missing_main_py(tmp_path):
    """When main.py is missing, doctor reports an issue."""
    # No main.py
    (tmp_path / "pyproject.toml").write_text("[project]\n")
    (tmp_path / "base").mkdir()
    (tmp_path / "base" / "tools").mkdir()
    (tmp_path / "base" / "tools" / "__init__.py").write_text("")

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 1
    assert "main.py" in result.output


def test_doctor_syntax_error_in_main_py(tmp_path):
    """When main.py has a syntax error, doctor reports it."""
    (tmp_path / "main.py").write_text("def broken(:\n")
    (tmp_path / "pyproject.toml").write_text("[project]\n")
    (tmp_path / "base").mkdir()
    (tmp_path / "base" / "tools").mkdir()
    (tmp_path / "base" / "tools" / "__init__.py").write_text("")

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 1
    assert "syntax error" in result.output.lower() or "main.py" in result.output


def test_doctor_missing_pyproject(tmp_path):
    """Missing pyproject.toml is reported as an issue."""
    (tmp_path / "main.py").write_text("# ok\n")
    # No pyproject.toml
    (tmp_path / "base").mkdir()
    (tmp_path / "base" / "tools").mkdir()
    (tmp_path / "base" / "tools" / "__init__.py").write_text("")

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 1
    assert "pyproject.toml" in result.output


def test_doctor_missing_base_dir(tmp_path):
    """Missing base/ directory is reported as an issue."""
    (tmp_path / "main.py").write_text("# ok\n")
    (tmp_path / "pyproject.toml").write_text("[project]\n")
    # No base/ dir

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 1
    assert "base/" in result.output


def test_doctor_missing_base_tools_init(tmp_path):
    """Missing base/tools/__init__.py reported as issue."""
    (tmp_path / "main.py").write_text("# ok\n")
    (tmp_path / "pyproject.toml").write_text("[project]\n")
    base = tmp_path / "base"
    base.mkdir()
    tools = base / "tools"
    tools.mkdir()
    # No __init__.py in tools

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 1
    assert "__init__.py" in result.output


def test_doctor_missing_db_is_warning(tmp_path):
    """Missing database is a warning, not an error."""
    _make_doctor_dir(tmp_path)
    # Remove the db file
    (tmp_path / "hypergolic.db").unlink()

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 0
    assert "warning" in result.output.lower() or "Database not found" in result.output


def test_doctor_missing_ref_is_warning(tmp_path):
    """Missing .ref/ directory is a warning, not an error."""
    _make_doctor_dir(tmp_path)
    import shutil
    shutil.rmtree(tmp_path / ".ref")

    from hypergolic.cli import doctor_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    old_dir = doctor_cmd.HYPERGOLIC_DIR
    doctor_cmd.HYPERGOLIC_DIR = tmp_path
    try:
        app2 = typer.Typer()
        app2.command()(doctor_cmd.doctor)
        runner = TRunner()
        with patch("hypergolic.cli.doctor_cmd.reconcile_worktrees") as mock_rec:
            mock_rec.return_value.is_clean.return_value = True
            result = runner.invoke(app2, [])
    finally:
        doctor_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 0
    assert ".ref/" in result.output or "warning" in result.output.lower()


# ===========================================================================
# setup.py
# ===========================================================================


def test_setup_run_migrations(tmp_path):
    """run_migrations calls alembic upgrade head."""
    from hypergolic.cli.setup import run_migrations

    with patch("hypergolic.cli.setup.alembic_command.upgrade") as mock_upgrade:
        run_migrations()

    mock_upgrade.assert_called_once()
    args = mock_upgrade.call_args[0]
    assert args[1] == "head"


def test_setup_build_ui_no_source(tmp_path):
    """build_ui raises Exit(1) when no UI source found."""
    from hypergolic.cli.setup import build_ui
    import click

    with (
        patch("hypergolic.cli.setup._find_ui_source_dir", return_value=None),
        pytest.raises((SystemExit, typer.Exit, click.exceptions.Exit)),
    ):
        build_ui()


def test_setup_build_ui_pnpm_install_fails(tmp_path):
    """build_ui raises Exit(1) when pnpm install fails."""
    from hypergolic.cli.setup import build_ui
    import click

    fake_ui = tmp_path / "ui"
    fake_ui.mkdir()
    (fake_ui / "package.json").write_text("{}")

    with (
        patch("hypergolic.cli.setup._find_ui_source_dir", return_value=fake_ui),
        patch("hypergolic.cli.setup.subprocess.run", return_value=MagicMock(returncode=1)),
        pytest.raises((SystemExit, typer.Exit, click.exceptions.Exit)),
    ):
        build_ui()


def test_setup_build_ui_pnpm_build_fails(tmp_path):
    """build_ui raises Exit(1) when pnpm build fails."""
    from hypergolic.cli.setup import build_ui
    import click

    fake_ui = tmp_path / "ui"
    fake_ui.mkdir()
    (fake_ui / "package.json").write_text("{}")

    call_count = 0

    def mock_run(*args, **kwargs):
        nonlocal call_count
        call_count += 1
        # install succeeds, build fails
        return MagicMock(returncode=0 if call_count == 1 else 1)

    with (
        patch("hypergolic.cli.setup._find_ui_source_dir", return_value=fake_ui),
        patch("hypergolic.cli.setup.subprocess.run", side_effect=mock_run),
        pytest.raises((SystemExit, typer.Exit, click.exceptions.Exit)),
    ):
        build_ui()


def test_setup_build_ui_success(tmp_path):
    """build_ui succeeds when both pnpm commands succeed."""
    from hypergolic.cli.setup import build_ui

    fake_ui = tmp_path / "ui"
    fake_ui.mkdir()
    (fake_ui / "package.json").write_text("{}")

    with (
        patch("hypergolic.cli.setup._find_ui_source_dir", return_value=fake_ui),
        patch("hypergolic.cli.setup.subprocess.run", return_value=MagicMock(returncode=0)),
    ):
        build_ui()  # Should not raise


def test_find_ui_source_dir_cwd_candidate(tmp_path):
    """_find_ui_source_dir returns the ui/ subdir in cwd if it has package.json."""
    from hypergolic.cli.setup import _find_ui_source_dir

    ui_dir = tmp_path / "ui"
    ui_dir.mkdir()
    (ui_dir / "package.json").write_text("{}")

    with patch("hypergolic.cli.setup.Path.cwd", return_value=tmp_path):
        result = _find_ui_source_dir()

    assert result == ui_dir


def test_find_ui_source_dir_none_when_missing(tmp_path):
    """_find_ui_source_dir returns None when no ui/ found."""
    from hypergolic.cli.setup import _find_ui_source_dir

    with (
        patch("hypergolic.cli.setup.Path.cwd", return_value=tmp_path),
        patch("hypergolic.cli.setup._package_root", return_value=tmp_path),
    ):
        result = _find_ui_source_dir()

    assert result is None


# ===========================================================================
# update_cmd.py
# ===========================================================================


def test_update_no_hypergolic_dir(tmp_path):
    """update exits with 1 if HYPERGOLIC_DIR doesn't exist."""
    from hypergolic.cli import update_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    non_existent = tmp_path / "nonexistent_dir"
    old_dir = update_cmd.HYPERGOLIC_DIR
    update_cmd.HYPERGOLIC_DIR = non_existent
    try:
        app3 = typer.Typer()
        app3.command()(update_cmd.update)
        runner = TRunner()
        result = runner.invoke(app3, [])
    finally:
        update_cmd.HYPERGOLIC_DIR = old_dir

    assert result.exit_code == 1
    assert "Run `hypergolic init`" in result.output or "does not exist" in result.output


def test_update_syncs_base_and_ref(tmp_path):
    """update syncs base and .ref directories."""
    from hypergolic.cli import update_cmd
    import typer
    from typer.testing import CliRunner as TRunner

    base_src = tmp_path / "fake_base"
    base_src.mkdir()
    src_dir = tmp_path / "fake_source"
    src_dir.mkdir()

    # Also need to patch generate_pyproject and setup_gitignore to avoid filesystem issues
    with (
        patch("hypergolic.cli.update_cmd.HYPERGOLIC_DIR", tmp_path),
        patch("hypergolic.cli.update_cmd._package_base_dir", return_value=base_src),
        patch("hypergolic.cli.update_cmd._package_source_dir", return_value=src_dir),
        patch("hypergolic.cli.update_cmd.generate_pyproject") as mock_gen,
        patch("hypergolic.cli.update_cmd.setup_gitignore") as mock_gi,
    ):
        app3 = typer.Typer()
        app3.command()(update_cmd.update)
        runner = TRunner()
        result = runner.invoke(app3, [])

    assert result.exit_code == 0
    assert mock_gen.called
    assert mock_gi.called
