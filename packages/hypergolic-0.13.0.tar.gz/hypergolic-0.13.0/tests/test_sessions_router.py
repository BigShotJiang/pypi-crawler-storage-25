"""Integration tests for the sessions router.

Covers: list, create, roles, messages, context, prompt,
skill activate/deactivate, workflows, skills list.
Delete is tested in test_session_delete.py; search in test_session_search.py.
"""

from unittest.mock import MagicMock, patch

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionWorkflow
from tests.conftest import make_message, make_project, make_session


# ── List sessions ──────────────────────────────────────────────────────

def test_list_sessions_empty(api_client):
    resp = api_client.get("/api/sessions")
    assert resp.status_code == 200
    assert resp.json() == []


def test_list_sessions_with_data(api_client):
    make_project("p1", "Project1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    make_message(sid, role="user", text="hi")
    make_message(sid, role="assistant", text="hello")

    resp = api_client.get("/api/sessions")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    s = data[0]
    assert s["id"] == "s1"
    assert s["project_id"] == "p1"
    assert s["project_name"] == "Project1"
    assert s["message_count"] == 2


def test_list_sessions_project_filter(api_client):
    make_project("p1", "P1", "/tmp/p1")
    make_project("p2", "P2", "/tmp/p2")
    make_session(project_id="p1", sid="s1")
    make_session(project_id="p2", sid="s2")

    resp = api_client.get("/api/sessions", params={"project_id": "p1"})
    assert resp.status_code == 200
    ids = [s["id"] for s in resp.json()]
    assert ids == ["s1"]


def test_list_sessions_with_workflow(api_client):
    from hypergolic.toolkit.primitives import Workflow, WorkflowState, OutputSchema

    make_project("p1", "Project1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    # Create a DBSessionWorkflow record
    with get_db() as db:
        db.add(DBSessionWorkflow(
            session_id=sid,
            workflow_id="wf-test",
            current_state_id="state-a",
            deleted_at=None,
        ))

    mock_wf = Workflow(
        id="wf-test",
        name="Test Workflow",
        description="desc",
        prompt_path=None,
        initial_state="state-a",
        states=[
            WorkflowState(
                id="state-a",
                name="Alpha State",
                prompt_path=None,
                output_schemas=[
                    OutputSchema(outcome="done", next_state=None, schema={}),
                ],
            ),
        ],
    )

    with patch("hypergolic.sessions.router.get_workflow", return_value=mock_wf):
        resp = api_client.get("/api/sessions")

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    s = data[0]
    assert s["workflow_id"] == "wf-test"
    assert s["workflow_name"] == "Test Workflow"
    assert s["workflow_state_name"] == "Alpha State"


# ── Create session ─────────────────────────────────────────────────────

def test_create_session(api_client):
    make_project("p1", "TestProj", "/tmp/test")

    resp = api_client.post("/api/sessions", json={
        "project_id": "p1",
        "model_tier": "Medium",
        "role": "generalist",
    })

    assert resp.status_code == 200
    data = resp.json()
    assert data["project_id"] == "p1"
    assert data["project_name"] == "TestProj"
    assert data["role"] == "generalist"
    assert data["model_tier"] == "Medium"
    assert data["message_count"] == 0


# ── List roles ─────────────────────────────────────────────────────────

def test_list_roles(api_client):
    mock_roles = [
        {"id": "generalist", "name": "Generalist", "source": "toolkit"},
        {"id": "worker", "name": "Worker", "source": "toolkit"},
    ]
    with patch("hypergolic.sessions.router.resolve_roles", return_value=mock_roles):
        resp = api_client.get("/api/sessions/roles")

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    assert data[0]["id"] == "generalist"
    assert data[1]["name"] == "Worker"


# ── Get messages ───────────────────────────────────────────────────────

def test_get_messages(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    make_message(sid, role="user", text="first")
    make_message(sid, role="assistant", text="second")

    # Mock _build_tool_display_names to avoid loading full toolkit
    with patch("hypergolic.sessions.router._build_tool_display_names", return_value={}):
        resp = api_client.get(f"/api/sessions/{sid}/messages")

    assert resp.status_code == 200
    msgs = resp.json()
    assert len(msgs) == 2
    assert msgs[0]["role"] == "user"
    assert msgs[1]["role"] == "assistant"
    # Content should be serialized
    assert msgs[0]["content"][0]["type"] == "text"
    assert msgs[0]["content"][0]["text"] == "first"


def test_get_messages_with_tool_display_names(api_client):
    """Cover _build_tool_display_names without mocking it."""
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")
    make_message(sid, role="user", text="hi")

    mock_session = MagicMock()
    mock_tool = MagicMock()
    mock_tool.id = "tool-1"
    mock_tool.name = "My Tool"

    with (
        patch("hypergolic.sessions.router.load_session", return_value=mock_session),
        patch("hypergolic.sessions.router.build_tools", return_value=[mock_tool]),
    ):
        resp = api_client.get(f"/api/sessions/{sid}/messages")

    assert resp.status_code == 200
    msgs = resp.json()
    assert len(msgs) == 1


# ── Get context ────────────────────────────────────────────────────────

def test_get_context(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    mock_tool = MagicMock()
    mock_tool.id = "test-tool"
    mock_tool.name = "Test Tool"
    mock_tool.description = "A tool"
    mock_tool.source = "internal"
    mock_tool.requires_approval = False
    mock_tool.to_param.return_value = {"input_schema": {"type": "object"}}

    from hypergolic.prompts.builder import PromptBlock

    with (
        patch("hypergolic.sessions.router.build_tools_with_reasons",
              return_value=[(mock_tool, "role")]),
        patch("hypergolic.tools.handlers.find_toolkit_tool", return_value=None),
        patch("hypergolic.sessions.router.resolve_session_skills", return_value=[
            {"id": "sk1", "name": "Skill 1", "description": "d", "source": "toolkit"},
        ]),
        patch("hypergolic.sessions.router.get_enabled_servers", return_value=[]),
        patch("hypergolic.sessions.router.build_prompt_blocks", return_value=[
            PromptBlock(source="base", text="Hello " * 100),
        ]),
    ):
        resp = api_client.get(f"/api/sessions/{sid}/context")

    assert resp.status_code == 200
    data = resp.json()
    assert data["tools_count"] == 1
    assert data["tools"][0]["id"] == "test-tool"
    assert data["skills_summary"]["total"] == 1
    assert data["skills_summary"]["active"] == 0
    assert data["skills_summary"]["active_skills"] == []
    assert data["mcp_enabled"] == []
    assert data["prompt_token_estimate"] > 0


def test_get_context_with_active_skills(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    # Activate a skill first
    mock_skills_for_activate = [{"id": "sk1", "name": "Alpha"}]
    with patch("hypergolic.sessions.router.resolve_skills", return_value=mock_skills_for_activate):
        api_client.post(f"/api/sessions/{sid}/skills/sk1/activate")

    mock_tool = MagicMock()
    mock_tool.id = "test-tool"
    mock_tool.name = "Test Tool"
    mock_tool.description = "A tool"
    mock_tool.source = "internal"
    mock_tool.requires_approval = False
    mock_tool.to_param.return_value = {"input_schema": {"type": "object"}}

    from hypergolic.prompts.builder import PromptBlock

    with (
        patch("hypergolic.sessions.router.build_tools_with_reasons",
              return_value=[(mock_tool, "role")]),
        patch("hypergolic.tools.handlers.find_toolkit_tool", return_value=None),
        patch("hypergolic.sessions.router.resolve_session_skills", return_value=[
            {"id": "sk1", "name": "Alpha", "description": "d", "source": "toolkit"},
            {"id": "sk2", "name": "Beta", "description": "d2", "source": "toolkit"},
        ]),
        patch("hypergolic.sessions.router.get_enabled_servers", return_value=[]),
        patch("hypergolic.sessions.router.build_prompt_blocks", return_value=[
            PromptBlock(source="base", text="Hello " * 100),
        ]),
    ):
        resp = api_client.get(f"/api/sessions/{sid}/context")

    assert resp.status_code == 200
    data = resp.json()
    assert data["skills_summary"]["total"] == 2
    assert data["skills_summary"]["active"] == 1
    assert data["skills_summary"]["active_skills"] == [{"id": "sk1", "name": "Alpha"}]


# ── Get prompt ─────────────────────────────────────────────────────────

def test_get_prompt(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    from hypergolic.prompts.builder import PromptBlock

    mock_blocks = [
        PromptBlock(source="Base prompt", text="You are helpful"),
        PromptBlock(source="Session context", text="Session info here"),
    ]
    with patch("hypergolic.sessions.router.build_prompt_blocks", return_value=mock_blocks):
        resp = api_client.get(f"/api/sessions/{sid}/prompt")

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    assert data[0]["source"] == "Base prompt"
    assert data[0]["content"] == "You are helpful"
    assert data[0]["token_estimate"] == len("You are helpful") // 4


# ── Skill activate / deactivate ────────────────────────────────────────

def test_activate_skill(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    mock_skills = [{"id": "my-skill", "name": "My Skill"}]
    with patch("hypergolic.sessions.router.resolve_skills", return_value=mock_skills):
        resp = api_client.post(f"/api/sessions/{sid}/skills/my-skill/activate")

    assert resp.status_code == 200
    assert resp.json()["status"] == "activated"

    # Activating again should be idempotent
    with patch("hypergolic.sessions.router.resolve_skills", return_value=mock_skills):
        resp2 = api_client.post(f"/api/sessions/{sid}/skills/my-skill/activate")
    assert resp2.status_code == 200


def test_activate_skill_not_found(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    with patch("hypergolic.sessions.router.resolve_skills", return_value=[]):
        resp = api_client.post(f"/api/sessions/{sid}/skills/nonexistent/activate")

    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"]


def test_deactivate_skill(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    # First activate, then deactivate
    mock_skills = [{"id": "my-skill", "name": "My Skill"}]
    with patch("hypergolic.sessions.router.resolve_skills", return_value=mock_skills):
        api_client.post(f"/api/sessions/{sid}/skills/my-skill/activate")

    resp = api_client.post(f"/api/sessions/{sid}/skills/my-skill/deactivate")
    assert resp.status_code == 200
    assert resp.json()["status"] == "deactivated"


# ── Workflows ──────────────────────────────────────────────────────────

def test_get_session_workflows(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    from hypergolic.toolkit.primitives import Workflow, WorkflowState, OutputSchema

    mock_wf = Workflow(
        id="wf-1",
        name="Test Workflow",
        description="A test workflow",
        prompt_path=None,
        initial_state="s1",
        states=[
            WorkflowState(
                id="s1",
                name="Start",
                prompt_path=None,
                output_schemas=[
                    OutputSchema(outcome="success", next_state=None, schema={}),
                ],
            ),
        ],
    )
    with patch("hypergolic.sessions.router.resolve_workflows", return_value=[mock_wf]):
        resp = api_client.get(f"/api/sessions/{sid}/workflows")

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 1
    assert data[0]["id"] == "wf-1"
    assert data[0]["name"] == "Test Workflow"
    assert data[0]["initial_state"] == "s1"
    assert len(data[0]["states"]) == 1
    assert data[0]["states"][0]["id"] == "s1"


# ── Skills list ────────────────────────────────────────────────────────

def test_get_session_skills(api_client):
    make_project("p1", "P1", "/tmp/p1")
    sid = make_session(project_id="p1", sid="s1")

    mock_skills = [
        {"id": "sk1", "name": "Alpha", "description": "First", "source": "toolkit"},
        {"id": "sk2", "name": "Beta", "description": "Second", "source": "toolkit"},
    ]

    # Activate sk1 so we can verify the active flag
    all_skills_for_activate = [{"id": "sk1", "name": "Alpha"}]
    with patch("hypergolic.sessions.router.resolve_skills", return_value=all_skills_for_activate):
        api_client.post(f"/api/sessions/{sid}/skills/sk1/activate")

    with patch("hypergolic.sessions.router.resolve_session_skills", return_value=mock_skills):
        resp = api_client.get(f"/api/sessions/{sid}/skills")

    assert resp.status_code == 200
    data = resp.json()
    assert len(data) == 2
    sk1 = next(s for s in data if s["id"] == "sk1")
    sk2 = next(s for s in data if s["id"] == "sk2")
    assert sk1["active"] is True
    assert sk2["active"] is False
