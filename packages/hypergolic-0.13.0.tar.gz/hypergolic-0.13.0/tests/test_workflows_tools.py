"""Tests for hypergolic.workflows.tools."""

from typing import Any
from unittest.mock import AsyncMock, MagicMock, patch

import pytest

from hypergolic.toolkit.primitives import OutputSchema, Workflow, WorkflowState
from hypergolic.tools.schemas import ToolContext
from hypergolic.workflows.tools import (
    _build_transition_tool,
    _json_schema_to_pydantic_fields,
    build_transition_tools,
)
from tests._factories import build_session as _session, build_workflow
from tests.conftest import make_project, make_session


def _output_schema(
    outcome: str = "done",
    next_state: str | None = None,
    requires_approval: bool = False,
    properties: dict | None = None,
) -> OutputSchema:
    return OutputSchema(
        outcome=outcome,
        next_state=next_state,
        requires_approval=requires_approval,
        schema={"type": "object", "properties": properties or {}},
    )


def _workflow(
    wf_id: str = "wf-1",
    state_id: str = "st-1",
    output_schemas: list[OutputSchema] | None = None,
) -> Workflow:
    return build_workflow(
        wf_id,
        state_id=state_id,
        states=[
            WorkflowState(
                id=state_id,
                name="State One",
                prompt="p",
                output_schemas=output_schemas or [_output_schema()],
            )
        ],
    )


# --- _json_schema_to_pydantic_fields -------------------------------------


def test_json_schema_to_pydantic_fields_empty():
    fields = _json_schema_to_pydantic_fields({"type": "object", "properties": {}})
    assert fields == {}


def test_json_schema_to_pydantic_fields_required_string():
    schema = {
        "type": "object",
        "properties": {"name": {"type": "string"}},
        "required": ["name"],
    }
    fields = _json_schema_to_pydantic_fields(schema)
    assert "name" in fields
    python_type, default = fields["name"]
    assert python_type is str
    assert default is ...


def test_json_schema_to_pydantic_fields_optional_string():
    schema = {"type": "object", "properties": {"notes": {"type": "string"}}}
    _, default = _json_schema_to_pydantic_fields(schema)["notes"]
    assert default is None


def test_json_schema_to_pydantic_fields_integer():
    schema = {
        "type": "object",
        "properties": {"count": {"type": "integer"}},
        "required": ["count"],
    }
    python_type, _ = _json_schema_to_pydantic_fields(schema)["count"]
    assert python_type is int


def test_json_schema_to_pydantic_fields_number():
    schema = {
        "type": "object",
        "properties": {"ratio": {"type": "number"}},
        "required": ["ratio"],
    }
    python_type, _ = _json_schema_to_pydantic_fields(schema)["ratio"]
    assert python_type is float


def test_json_schema_to_pydantic_fields_boolean():
    schema = {
        "type": "object",
        "properties": {"flag": {"type": "boolean"}},
        "required": ["flag"],
    }
    python_type, _ = _json_schema_to_pydantic_fields(schema)["flag"]
    assert python_type is bool


def test_json_schema_to_pydantic_fields_array():
    schema = {
        "type": "object",
        "properties": {"tags": {"type": "array"}},
        "required": ["tags"],
    }
    python_type, _ = _json_schema_to_pydantic_fields(schema)["tags"]
    assert python_type == list[str]


def test_json_schema_to_pydantic_fields_object():
    schema = {
        "type": "object",
        "properties": {"meta": {"type": "object"}},
        "required": ["meta"],
    }
    python_type, _ = _json_schema_to_pydantic_fields(schema)["meta"]
    assert python_type == dict[str, Any]


def test_json_schema_to_pydantic_fields_unknown_type_defaults_str_required():
    schema = {
        "type": "object",
        "properties": {"weird": {"type": "exotic_type"}},
        "required": ["weird"],
    }
    python_type, default = _json_schema_to_pydantic_fields(schema)["weird"]
    assert python_type is str
    assert default is ...


def test_json_schema_to_pydantic_fields_no_type_defaults_str_required():
    schema = {
        "type": "object",
        "properties": {"anything": {}},
        "required": ["anything"],
    }
    python_type, default = _json_schema_to_pydantic_fields(schema)["anything"]
    assert python_type is str
    assert default is ...


# --- _build_transition_tool ----------------------------------------------


def test_build_transition_tool_basic():
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema("success"),
        state_name="My State",
    )
    assert tool.id == "workflow_transition_success"
    assert "My State" in tool.description
    assert "success" in tool.description


def test_build_transition_tool_with_next_state_in_description():
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema("approve", next_state="st-2"),
        state_name="Review",
    )
    assert "st-2" in tool.description


def test_build_transition_tool_exit_workflow_in_description():
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema("done", next_state=None),
        state_name="Final",
    )
    assert "exit workflow" in tool.description


def test_build_transition_tool_requires_approval():
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema("confirm", requires_approval=True),
        state_name="Confirm",
    )
    assert tool.requires_approval is True


def test_build_transition_tool_with_fields_in_schema():
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema(
            "submit",
            properties={"summary": {"type": "string"}, "score": {"type": "integer"}},
        ),
        state_name="Submit",
    )
    assert hasattr(tool.input, "model_fields")


def test_build_transition_tool_empty_schema_uses_placeholder():
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema("done"),
        state_name="Done",
    )
    instance = tool.input(_placeholder=None)
    assert hasattr(instance, "_placeholder")


@pytest.mark.anyio
async def test_build_transition_tool_handle_removes_placeholder():
    """_handle strips _placeholder from output before calling transition."""
    tool = _build_transition_tool(
        workflow_id="wf-1",
        state_id="st-1",
        output_schema=_output_schema("done"),
        state_name="Done",
    )

    mock_transition = AsyncMock(return_value=MagicMock(is_error=False))
    ctx = ToolContext(session=_session(), broadcast=AsyncMock(), tool_id=tool.id)
    inp = tool.input(_placeholder=None)
    with patch(
        "hypergolic.workflows.engine.handle_workflow_transition",
        new=mock_transition,
    ):
        await tool.call_tool(inp, ctx)

    output_data = mock_transition.call_args[1]["output"]
    assert "_placeholder" not in output_data


# --- build_transition_tools ----------------------------------------------


def test_build_transition_tools_no_active_workflow():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()

    with patch("hypergolic.workflows.tools.get_session_workflow", return_value=None):
        tools, state_id = build_transition_tools(session)

    assert tools == []
    assert state_id is None


def test_build_transition_tools_workflow_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()

    with (
        patch("hypergolic.workflows.tools.get_session_workflow", return_value=("wf-x", "st-1")),
        patch("hypergolic.workflows.tools.get_workflow", return_value=None),
    ):
        tools, state_id = build_transition_tools(session)

    assert tools == []
    assert state_id == "st-1"


def test_build_transition_tools_state_not_found():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    wf = _workflow(state_id="st-1")

    with (
        patch("hypergolic.workflows.tools.get_session_workflow", return_value=("wf-1", "st-missing")),
        patch("hypergolic.workflows.tools.get_workflow", return_value=wf),
    ):
        tools, state_id = build_transition_tools(session)

    assert tools == []
    assert state_id == "st-missing"


def test_build_transition_tools_returns_tools():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    wf = _workflow(
        output_schemas=[_output_schema("approve"), _output_schema("reject")]
    )

    with (
        patch("hypergolic.workflows.tools.get_session_workflow", return_value=("wf-1", "st-1")),
        patch("hypergolic.workflows.tools.get_workflow", return_value=wf),
    ):
        tools, state_id = build_transition_tools(session)

    assert {t.id for t in tools} == {
        "workflow_transition_approve",
        "workflow_transition_reject",
    }
    assert state_id == "st-1"


def test_build_transition_tools_no_output_schemas():
    make_project("p-1")
    make_session(project_id="p-1", sid="s-1")
    session = _session()
    wf = Workflow(
        id="wf-1", name="WF", description="d", initial_state="st-1",
        states=[WorkflowState(id="st-1", name="S", prompt="p", output_schemas=[])],
    )

    with (
        patch("hypergolic.workflows.tools.get_session_workflow", return_value=("wf-1", "st-1")),
        patch("hypergolic.workflows.tools.get_workflow", return_value=wf),
    ):
        tools, _ = build_transition_tools(session)

    assert tools == []
