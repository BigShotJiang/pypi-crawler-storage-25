"""Tests for the worktree-aware pieces of hypergolic.dispatch.conclude.

Shells out to git, so we relax the default 0.5s timeout.
"""

from __future__ import annotations

import subprocess
from pathlib import Path
from typing import Any
from unittest.mock import AsyncMock

import pytest

pytestmark = pytest.mark.timeout(10)

from hypergolic.dispatch.conclude import (  # noqa: E402
    ConcludeInput,
    _format_dirty_error,
    _handle_conclude,
    _teardown_worktree_at_conclude,
    DirtyWorktreeError,
)
from hypergolic.enums import ModelTier  # noqa: E402
from hypergolic.git.worktree import create_worktree  # noqa: E402
from hypergolic.schemas import Session  # noqa: E402
from hypergolic.tools.schemas import ToolContext  # noqa: E402


def _init_repo(path: Path) -> None:
    subprocess.run(["git", "init", "-b", "main", str(path)], check=True, capture_output=True)
    subprocess.run(["git", "-C", str(path), "config", "user.email", "t@t"], check=True)
    subprocess.run(["git", "-C", str(path), "config", "user.name", "t"], check=True)
    (path / "README.md").write_text("readme\n")
    subprocess.run(["git", "-C", str(path), "add", "-A"], check=True)
    subprocess.run(
        ["git", "-C", str(path), "commit", "-m", "init"],
        check=True, capture_output=True,
    )


@pytest.fixture
def repo(tmp_path: Path) -> Path:
    project = tmp_path / "project"
    project.mkdir()
    _init_repo(project)
    return project


@pytest.fixture
def worktrees_home(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> Path:
    home = tmp_path / "home"
    home.mkdir()
    monkeypatch.setenv("HOME", str(home))
    return home / ".hypergolic" / "worktrees"


def _seed_session_row(session_id: str, project_path: str) -> None:
    from hypergolic.db.engine import get_db
    from hypergolic.db.models import DBProject, DBSession

    with get_db() as db:
        if not db.get(DBProject, "proj-wt"):
            db.add(DBProject(id="proj-wt", name="P", path=project_path))
        db.add(DBSession(
            id=session_id, model_tier="Medium", system_prompt=[], project_id="proj-wt",
        ))


def _make_session_with_worktree(session_id: str, project_path: Path, wt_path: Path, branch: str) -> Session:
    return Session(
        id=session_id,
        model_tier=ModelTier.MEDIUM,
        project_id="proj-wt",
        project_path=str(project_path),
        worktree_path=str(wt_path),
        worktree_branch=branch,
        base_branch="main",
    )


def test_dirty_worktree_error_carries_status() -> None:
    err = DirtyWorktreeError("?? foo.txt")
    assert "foo.txt" in err.porcelain_output


def test_format_dirty_error_hints_at_remediation() -> None:
    err = DirtyWorktreeError("?? foo.txt")
    msg = _format_dirty_error(err)
    assert "commit" in msg
    assert "reset" in msg
    assert "foo.txt" in msg


def test_teardown_clean_branch_without_commits_deletes_branch(
    repo: Path, worktrees_home: Path, tmp_path: Path,
) -> None:
    info = create_worktree(session_id="s-empty", project_path=repo)
    _seed_session_row("s-empty", str(repo))

    session = _make_session_with_worktree("s-empty", repo, info.worktree_path, info.branch)
    surviving = _teardown_worktree_at_conclude(session)

    assert surviving is None  # branch deleted because no commits
    assert not info.worktree_path.exists()
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert info.branch not in branches


def test_teardown_clean_branch_with_commits_preserves_branch(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-work", project_path=repo)
    _seed_session_row("s-work", str(repo))

    # Make a commit in the worktree.
    (info.worktree_path / "new.txt").write_text("hello")
    subprocess.run(
        ["git", "-C", str(info.worktree_path), "add", "new.txt"],
        check=True,
    )
    subprocess.run(
        ["git", "-C", str(info.worktree_path), "commit", "-m", "work"],
        check=True, capture_output=True,
    )

    session = _make_session_with_worktree("s-work", repo, info.worktree_path, info.branch)
    surviving = _teardown_worktree_at_conclude(session)

    assert surviving == info.branch
    assert not info.worktree_path.exists()
    branches = subprocess.run(
        ["git", "-C", str(repo), "branch"],
        capture_output=True, text=True, check=True,
    ).stdout
    assert info.branch in branches


def test_teardown_dirty_worktree_raises(
    repo: Path, worktrees_home: Path,
) -> None:
    info = create_worktree(session_id="s-dirty", project_path=repo)
    _seed_session_row("s-dirty", str(repo))

    # Leave an untracked file to make status dirty.
    (info.worktree_path / "scratch.txt").write_text("not committed")

    session = _make_session_with_worktree("s-dirty", repo, info.worktree_path, info.branch)
    with pytest.raises(DirtyWorktreeError):
        _teardown_worktree_at_conclude(session)
    assert info.worktree_path.exists()  # not torn down


@pytest.mark.anyio
async def test_handle_conclude_rejects_dirty_worktree(
    repo: Path, worktrees_home: Path, tmp_path: Path,
) -> None:
    info = create_worktree(session_id="s-dirty2", project_path=repo)
    _seed_session_row("s-dirty2", str(repo))
    (info.worktree_path / "scratch.txt").write_text("x")

    session = _make_session_with_worktree("s-dirty2", repo, info.worktree_path, info.branch)
    ctx = ToolContext(
        session=session,
        broadcast=AsyncMock(),
        tool_id="conclude",
    )
    inp = ConcludeInput(outcome="success", conclusion="tried")

    output = await _handle_conclude(inp, ctx)

    assert output.is_error is True
    text = output.first_text()
    assert "uncommitted" in text.lower()
    # worktree still there so the agent can fix it
    assert info.worktree_path.exists()


def _ok(stdout: str = "") -> Any:
    return subprocess.CompletedProcess([], 0, stdout=stdout, stderr="")
