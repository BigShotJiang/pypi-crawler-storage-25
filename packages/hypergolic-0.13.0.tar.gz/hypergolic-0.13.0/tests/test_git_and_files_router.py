"""Integration tests for git and attachments routers.

Files router tests have moved to ``hypergolic/files/tests/test_router.py``.
"""

from pathlib import Path
from unittest.mock import patch

from hypergolic.git.operations import GitCommandError
from hypergolic.git.schemas import (
    ChangedFile,
    GitCommitDetailResponse,
    GitDiffResponse,
    GitLogEntry,
    GitLogResponse,
    GitStatusResponse,
)
from tests.conftest import make_project


# ---------------------------------------------------------------------------
# Git router tests
# ---------------------------------------------------------------------------


def test_git_status(api_client):
    status = GitStatusResponse(
        branch="main",
        ahead=1,
        behind=0,
        staged=[ChangedFile(path="a.py", status="M", staged=True, additions=3, deletions=1)],
        unstaged=[ChangedFile(path="b.py", status="M", staged=False, additions=0, deletions=2)],
        untracked=["new.txt"],
    )
    with patch("hypergolic.git.router.get_git_status", return_value=status):
        resp = api_client.get("/api/git/status")
    assert resp.status_code == 200
    data = resp.json()
    assert data["branch"] == "main"
    assert data["ahead"] == 1
    assert len(data["staged"]) == 1
    assert data["staged"][0]["path"] == "a.py"
    assert len(data["unstaged"]) == 1
    assert data["untracked"] == ["new.txt"]


def test_git_diff(api_client):
    diff_resp = GitDiffResponse(path="file.py", diff="--- a/file.py\n+++ b/file.py\n@@ -1 +1 @@")
    with patch("hypergolic.git.router.get_git_diff", return_value=diff_resp):
        resp = api_client.post("/api/git/diff", json={"path": "file.py", "staged": False})
    assert resp.status_code == 200
    data = resp.json()
    assert data["path"] == "file.py"
    assert "---" in data["diff"]


def test_git_stage_success(api_client):
    with patch("hypergolic.git.router.git_stage") as mock_stage:
        resp = api_client.post("/api/git/stage", json={"paths": ["a.py", "b.py"]})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
    mock_stage.assert_called_once_with(["a.py", "b.py"], repo=None)


def test_git_stage_error(api_client):
    err = GitCommandError(command="add", returncode=128, stderr="fatal: not a git repo", stdout="")
    with patch("hypergolic.git.router.git_stage", side_effect=err):
        resp = api_client.post("/api/git/stage", json={"paths": ["bad.py"]})
    assert resp.status_code == 422
    assert "fatal: not a git repo" in resp.json()["detail"]


def test_git_commit_success(api_client):
    with patch("hypergolic.git.router.git_commit", return_value="[main abc1234] fix stuff"):
        resp = api_client.post("/api/git/commit", json={"message": "fix stuff"})
    assert resp.status_code == 200
    assert resp.json()["output"] == "[main abc1234] fix stuff"


def test_git_commit_error(api_client):
    err = GitCommandError(command="commit", returncode=1, stderr="nothing to commit", stdout="")
    with patch("hypergolic.git.router.git_commit", side_effect=err):
        resp = api_client.post("/api/git/commit", json={"message": "oops"})
    assert resp.status_code == 422
    assert "nothing to commit" in resp.json()["detail"]


def test_git_push_and_pull(api_client):
    with patch("hypergolic.git.router.git_push", return_value="Everything up-to-date"):
        resp = api_client.post("/api/git/push")
    assert resp.status_code == 200
    assert resp.json()["output"] == "Everything up-to-date"

    with patch("hypergolic.git.router.git_pull", return_value="Already up to date."):
        resp = api_client.post("/api/git/pull")
    assert resp.status_code == 200
    assert resp.json()["output"] == "Already up to date."


def test_git_log(api_client):
    log = GitLogResponse(entries=[
        GitLogEntry(
            hash="abc123def456", short_hash="abc123d",
            author="Dev", date="2025-01-01T00:00:00+00:00",
            message="init commit", refs="HEAD -> main",
        ),
    ])
    with patch("hypergolic.git.router.get_git_log", return_value=log):
        resp = api_client.get("/api/git/log?count=10")
    assert resp.status_code == 200
    data = resp.json()
    assert len(data["entries"]) == 1
    assert data["entries"][0]["message"] == "init commit"


def test_git_show_commit(api_client):
    detail = GitCommitDetailResponse(
        hash="abc123def456", short_hash="abc123d",
        author="Dev", date="2025-01-01T00:00:00+00:00",
        message="fix bug", diff="diff --git a/x b/x",
    )
    with patch("hypergolic.git.router.get_git_commit_detail", return_value=detail):
        resp = api_client.get("/api/git/show/abc123def456")
    assert resp.status_code == 200
    data = resp.json()
    assert data["hash"] == "abc123def456"
    assert data["message"] == "fix bug"
    assert "diff" in data["diff"]


def test_git_with_project_id(api_client):
    """Test that project_id resolves to the project's path for git operations."""
    make_project(pid="git-proj", name="GitTest", path="/tmp/gitrepo")
    status = GitStatusResponse(
        branch="dev", ahead=0, behind=0,
        staged=[], unstaged=[], untracked=[],
    )
    with patch("hypergolic.git.router.get_git_status", return_value=status) as mock_status:
        resp = api_client.get("/api/git/status", params={"project_id": "git-proj"})
    assert resp.status_code == 200
    # The resolved path should be passed to the operation
    mock_status.assert_called_once_with(repo=Path("/tmp/gitrepo"))


def test_git_unstage_and_discard(api_client):
    """Cover the unstage and discard endpoints."""
    with patch("hypergolic.git.router.git_unstage") as mock_unstage:
        resp = api_client.post("/api/git/unstage", json={"paths": ["c.py"]})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
    mock_unstage.assert_called_once_with(["c.py"], repo=None)

    with patch("hypergolic.git.router.git_discard") as mock_discard:
        resp = api_client.post("/api/git/discard", json={"paths": ["d.py"]})
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}
    mock_discard.assert_called_once_with(["d.py"], repo=None)


def test_git_unstage_error(api_client):
    err = GitCommandError(command="reset", returncode=128, stderr="fatal: unstage failed", stdout="")
    with patch("hypergolic.git.router.git_unstage", side_effect=err):
        resp = api_client.post("/api/git/unstage", json={"paths": ["bad.py"]})
    assert resp.status_code == 422
    assert "fatal: unstage failed" in resp.json()["detail"]


def test_git_discard_error(api_client):
    err = GitCommandError(command="checkout", returncode=1, stderr="error: discard failed", stdout="")
    with patch("hypergolic.git.router.git_discard", side_effect=err):
        resp = api_client.post("/api/git/discard", json={"paths": ["bad.py"]})
    assert resp.status_code == 422
    assert "error: discard failed" in resp.json()["detail"]


def test_git_pull_error(api_client):
    err = GitCommandError(command="pull", returncode=1, stderr="error: pull failed", stdout="")
    with patch("hypergolic.git.router.git_pull", side_effect=err):
        resp = api_client.post("/api/git/pull")
    assert resp.status_code == 422
    assert "error: pull failed" in resp.json()["detail"]


def test_git_error_detail_fallback(api_client):
    """When stdout and stderr are both empty, _error_detail uses fallback message."""
    err = GitCommandError(command="push", returncode=1, stderr="", stdout="")
    with patch("hypergolic.git.router.git_push", side_effect=err):
        resp = api_client.post("/api/git/push")
    assert resp.status_code == 422
    assert "git push failed (exit 1)" in resp.json()["detail"]


def test_git_project_not_found(api_client):
    """Passing a non-existent project_id returns 404."""
    resp = api_client.get("/api/git/status", params={"project_id": "no-such-proj"})
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


# ---------------------------------------------------------------------------
# Attachments router tests
# ---------------------------------------------------------------------------


def test_upload_image_success(api_client):
    with patch(
        "hypergolic.attachments.router.process_image",
        return_value=("base64encodeddata", "image/png"),
    ):
        resp = api_client.post(
            "/api/attachments/upload",
            files={"file": ("test.png", b"\x89PNG\r\n\x1a\nfakedata", "image/png")},
        )
    assert resp.status_code == 200
    data = resp.json()
    assert data["type"] == "image"
    assert data["source"]["type"] == "base64"
    assert data["source"]["media_type"] == "image/png"
    assert data["source"]["data"] == "base64encodeddata"


def test_upload_unsupported_type(api_client):
    resp = api_client.post(
        "/api/attachments/upload",
        files={"file": ("doc.pdf", b"fake pdf content", "application/pdf")},
    )
    assert resp.status_code == 400
    assert "Unsupported media type" in resp.json()["detail"]


def test_upload_empty_file(api_client):
    resp = api_client.post(
        "/api/attachments/upload",
        files={"file": ("empty.png", b"", "image/png")},
    )
    assert resp.status_code == 400
    assert "Empty file" in resp.json()["detail"]
