"""Sandbox lifecycle management.

Handles Docker container lifecycle for sandboxed tool execution.
Containers are backed by a DBSandbox row keyed on (session_id, tool_id).
"""

import asyncio
import logging
import os
from dataclasses import dataclass
from pathlib import Path

import yaml
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSandbox

logger = logging.getLogger(__name__)


class SandboxUnavailableError(Exception):
    """Raised when Docker is not available."""


class SandboxError(Exception):
    """Raised when a sandbox operation fails."""


@dataclass
class ExecResult:
    stdout: str
    stderr: str
    returncode: int


def _compose_project_name(session_id: str, tool_id: str) -> str:
    """Generate a unique compose project name for a sandbox."""
    short_session = session_id.replace("-", "")[:12]
    safe_tool = tool_id.replace("-", "_")
    return f"hg-{safe_tool}-{short_session}"


def _parse_config(config_path: str) -> dict:
    """Parse a sandbox compose YAML file."""
    path = Path(config_path).expanduser()
    if not path.exists():
        raise SandboxError(f"Sandbox config not found: {path}")
    with open(path) as f:
        config = yaml.safe_load(f)
    if not config or "services" not in config:
        raise SandboxError(f"Invalid sandbox config (no services): {path}")
    return config


def _find_default_service(config: dict) -> str:
    """Find the default service from a compose config.

    Looks for hypergolic.default label, falls back to first non-proxy service.
    """
    services = config.get("services", {})
    for name, svc in services.items():
        labels = svc.get("labels", {})
        if isinstance(labels, dict) and labels.get("hypergolic.default") == "true":
            return name
        if isinstance(labels, list):
            for label in labels:
                if label == "hypergolic.default=true":
                    return name

    # Fall back to first non-proxy service
    for name, svc in services.items():
        labels = svc.get("labels", {})
        is_proxy = False
        if isinstance(labels, dict):
            is_proxy = labels.get("hypergolic.role") == "proxy"
        elif isinstance(labels, list):
            is_proxy = "hypergolic.role=proxy" in labels
        if not is_proxy:
            return name

    raise SandboxError("No suitable service found in sandbox config")


async def _run_docker(*args: str, timeout: int = 60) -> ExecResult:
    """Run a docker command and return the result."""
    proc = await asyncio.create_subprocess_exec(
        "docker", *args,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.PIPE,
    )
    try:
        stdout_bytes, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=timeout
        )
    except asyncio.TimeoutError:
        proc.kill()
        await proc.communicate()
        raise SandboxError(f"Docker command timed out after {timeout}s: docker {' '.join(args)}")

    return ExecResult(
        stdout=stdout_bytes.decode("utf-8", errors="replace") if stdout_bytes else "",
        stderr=stderr_bytes.decode("utf-8", errors="replace") if stderr_bytes else "",
        returncode=proc.returncode or 0,
    )


async def _run_compose(
    *args: str,
    project_name: str,
    config_path: str,
    timeout: int = 120,
) -> ExecResult:
    """Run a docker compose command."""
    full_args = [
        "compose",
        "-p", project_name,
        "-f", config_path,
        *args,
    ]
    return await _run_docker(*full_args, timeout=timeout)


async def ensure_docker_available() -> None:
    """Check that Docker is running. Raises SandboxUnavailableError if not."""
    try:
        result = await _run_docker("info", timeout=10)
    except FileNotFoundError:
        raise SandboxUnavailableError(
            "Docker CLI not found. Install Docker or ensure it's on your PATH."
        )
    except SandboxError:
        raise SandboxUnavailableError(
            "Docker is not responding. Start your container runtime "
            "and try again, or ask the user to start it."
        )
    if result.returncode != 0:
        raise SandboxUnavailableError(
            "Docker is not running. Start your container runtime "
            "and try again, or ask the user to start it.\n"
            f"Docker output: {result.stderr.strip()}"
        )


def _get_sandbox(session_id: str, tool_id: str) -> DBSandbox | None:
    """Get the sandbox row for a session/tool pair."""
    with get_db() as db:
        return db.execute(
            select(DBSandbox)
            .where(DBSandbox.session_id == session_id)
            .where(DBSandbox.tool_id == tool_id)
        ).scalar_one_or_none()


def _create_sandbox_row(
    session_id: str,
    tool_id: str,
    config_path: str,
    compose_project: str,
) -> DBSandbox:
    """Create a pending sandbox row."""
    with get_db() as db:
        sandbox = DBSandbox(
            session_id=session_id,
            tool_id=tool_id,
            status="pending",
            compose_project=compose_project,
            config_path=config_path,
        )
        db.add(sandbox)
        # Read back to get the generated id
        db.flush()
        sandbox_id = sandbox.id

    return _get_sandbox_by_id(sandbox_id)


def _get_sandbox_by_id(sandbox_id: str) -> DBSandbox:
    """Get a sandbox by its primary key."""
    with get_db() as db:
        return db.execute(
            select(DBSandbox).where(DBSandbox.id == sandbox_id)
        ).scalar_one()


def _set_sandbox_status(sandbox_id: str, status: str) -> None:
    """Update the status of a sandbox row."""
    with get_db() as db:
        db.execute(
            update(DBSandbox)
            .where(DBSandbox.id == sandbox_id)
            .values(status=status)
        )


async def start_sandbox(
    session_id: str,
    tool_id: str,
    config_path: str,
    project_root: str,
) -> str:
    """Start a sandbox container for the given session and tool.

    Returns the compose project name. Creates the DBSandbox row and
    starts the container via docker compose.

    If a sandbox already exists and is running, returns its compose project.
    """
    await ensure_docker_available()

    existing = _get_sandbox(session_id, tool_id)
    if existing and existing.status == "running" and existing.compose_project:
        return existing.compose_project

    # Parse config to validate
    resolved_path = str(Path(config_path).expanduser())
    _parse_config(resolved_path)

    compose_project = _compose_project_name(session_id, tool_id)

    if existing:
        _set_sandbox_status(existing.id, "pending")
        sandbox_id = existing.id
    else:
        row = _create_sandbox_row(
            session_id=session_id,
            tool_id=tool_id,
            config_path=resolved_path,
            compose_project=compose_project,
        )
        sandbox_id = row.id

    # Set workspace env var for the compose file to reference
    os.environ["HYPERGOLIC_WORKSPACE"] = project_root

    try:
        result = await _run_compose(
            "up", "-d", "--remove-orphans",
            project_name=compose_project,
            config_path=resolved_path,
            timeout=120,
        )

        if result.returncode != 0:
            _set_sandbox_status(sandbox_id, "error")
            raise SandboxError(
                f"Failed to start sandbox: {result.stderr.strip()}"
            )

        _set_sandbox_status(sandbox_id, "running")
        logger.info(
            "Sandbox started: session=%s tool=%s project=%s",
            session_id, tool_id, compose_project,
        )
        return compose_project

    except SandboxError:
        raise
    except Exception as e:
        _set_sandbox_status(sandbox_id, "error")
        raise SandboxError(f"Failed to start sandbox: {e}") from e


async def exec_in_sandbox(
    session_id: str,
    tool_id: str,
    command: str,
    timeout: int = 30,
) -> ExecResult:
    """Execute a command in a running sandbox container.

    If the sandbox isn't running yet, starts it first.
    """
    sandbox = _get_sandbox(session_id, tool_id)

    if sandbox is None:
        raise SandboxError(
            "No sandbox found for this session. This is a bug — "
            "the sandbox should have been created when the tool was invoked."
        )

    if sandbox.status == "error":
        raise SandboxError(
            "Sandbox is in error state. The container failed to start. "
            "Check Docker logs or ask the user to investigate."
        )

    if sandbox.status != "running":
        raise SandboxError(
            f"Sandbox is in '{sandbox.status}' state, expected 'running'. "
            "This may indicate a startup failure."
        )

    if not sandbox.compose_project:
        raise SandboxError("Sandbox has no compose project name. This is a bug.")

    config = _parse_config(sandbox.config_path)
    service_name = _find_default_service(config)

    result = await _run_compose(
        "exec", "-T", service_name, "sh", "-c", command,
        project_name=sandbox.compose_project,
        config_path=sandbox.config_path,
        timeout=timeout,
    )

    return result


async def stop_sandbox(session_id: str, tool_id: str) -> None:
    """Stop and remove a sandbox container."""
    sandbox = _get_sandbox(session_id, tool_id)
    if sandbox is None:
        return

    if sandbox.status == "stopped":
        return

    _set_sandbox_status(sandbox.id, "stopping")

    try:
        if sandbox.compose_project and sandbox.config_path:
            result = await _run_compose(
                "down", "--remove-orphans", "-v",
                project_name=sandbox.compose_project,
                config_path=sandbox.config_path,
                timeout=30,
            )
            if result.returncode != 0:
                logger.warning(
                    "Failed to stop sandbox %s: %s",
                    sandbox.compose_project, result.stderr.strip(),
                )
    except Exception:
        logger.warning("Error stopping sandbox %s", sandbox.compose_project, exc_info=True)
    finally:
        _set_sandbox_status(sandbox.id, "stopped")
        logger.info(
            "Sandbox stopped: session=%s tool=%s project=%s",
            session_id, tool_id, sandbox.compose_project,
        )


async def cleanup_session_sandboxes(session_id: str) -> None:
    """Stop all running sandboxes for a session."""
    with get_db() as db:
        sandboxes = db.execute(
            select(DBSandbox)
            .where(DBSandbox.session_id == session_id)
            .where(DBSandbox.status.in_(["pending", "running", "starting", "stopping"]))
        ).scalars().all()

    for sandbox in sandboxes:
        await stop_sandbox(session_id, sandbox.tool_id)


async def cleanup_orphaned_sandboxes() -> None:
    """Find and clean up any sandboxes left running from a previous process.

    Called on app startup.
    """
    with get_db() as db:
        orphans = db.execute(
            select(DBSandbox)
            .where(DBSandbox.status.in_(["pending", "running", "starting", "stopping"]))
        ).scalars().all()

    if not orphans:
        return

    logger.info("Found %d orphaned sandbox(es), cleaning up...", len(orphans))

    for sandbox in orphans:
        try:
            await stop_sandbox(sandbox.session_id, sandbox.tool_id)
        except Exception:
            logger.warning(
                "Failed to clean up orphaned sandbox %s",
                sandbox.compose_project,
                exc_info=True,
            )
            # Force status to stopped even if cleanup failed
            _set_sandbox_status(sandbox.id, "stopped")
