enabled_servers_by_session: dict[str, set[str]] = {}


def get_enabled_servers(session_id: str) -> set[str]:
    return enabled_servers_by_session.get(session_id, set()).copy()


def set_enabled_servers(session_id: str, servers: set[str]) -> None:
    enabled_servers_by_session[session_id] = servers
