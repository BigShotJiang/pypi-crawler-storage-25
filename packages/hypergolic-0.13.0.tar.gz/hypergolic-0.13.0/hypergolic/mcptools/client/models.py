from contextlib import AsyncExitStack
from dataclasses import dataclass

from mcp import ClientSession
from mcp.types import Tool as MCPTool


@dataclass
class ConnectedServer:
    name: str
    source: str
    session: ClientSession
    tools: list[MCPTool]
    _exit_stack: AsyncExitStack
