import asyncio
import logging
import os
from contextlib import AsyncExitStack
from typing import Any

from hypergolic.config.schemas import MCPServerConfig
from hypergolic.toolkit.app.state import get_app
from hypergolic.mcptools.client.models import ConnectedServer
from hypergolic.mcptools.client.transports import connect_sse, connect_stdio, connect_streamable_http
from hypergolic.mcptools.oauth import FileTokenStorage

logger = logging.getLogger(__name__)


class MCPManager:
    def __init__(self) -> None:
        self._servers: dict[str, ConnectedServer] = {}
        self._lock = asyncio.Lock()

    def get_available_servers(self, project_path: str | None = None) -> dict[str, tuple[MCPServerConfig, str]]:
        raw_servers = get_app()._mcp_servers
        return {
            name: (MCPServerConfig(**config), "user")
            for name, config in raw_servers.items()
        }

    def is_connected(self, server_name: str) -> bool:
        return server_name in self._servers

    def get_connected_server(self, server_name: str) -> ConnectedServer | None:
        return self._servers.get(server_name)

    def get_all_connected(self) -> dict[str, ConnectedServer]:
        return dict(self._servers)

    def get_auth_status(self, server_name: str, project_path: str | None = None) -> str:
        available = self.get_available_servers(project_path)
        if server_name not in available:
            return "unknown"
        config, _ = available[server_name]
        if config.auth.type == "none":
            return "not_required"
        if config.auth.type == "token":
            env_var = config.auth.token_env_var
            if env_var and os.environ.get(env_var):
                return "ready"
            return "missing_token"
        if config.auth.type == "oauth":
            storage = FileTokenStorage(server_name)
            if storage._tokens_path.exists():
                return "ready"
            return "needs_oauth"
        return "unknown"

    async def connect(self, server_name: str, project_path: str | None = None) -> ConnectedServer:
        async with self._lock:
            if server_name in self._servers:
                return self._servers[server_name]

            available = self.get_available_servers(project_path)
            if server_name not in available:
                raise ValueError(f"MCP server '{server_name}' not found in configuration")

            config, source = available[server_name]
            exit_stack = AsyncExitStack()

            try:
                if config.transport == "stdio":
                    session = await connect_stdio(config, exit_stack)
                elif config.transport == "streamable_http":
                    session = await connect_streamable_http(
                        server_name, config, exit_stack
                    )
                elif config.transport == "sse":
                    session = await connect_sse(
                        server_name, config, exit_stack
                    )
                else:
                    raise ValueError(f"Unknown transport: {config.transport}")

                await session.initialize()
                tools_result = await session.list_tools()
                tools = tools_result.tools

                server = ConnectedServer(
                    name=server_name,
                    source=source,
                    session=session,
                    tools=tools,
                    _exit_stack=exit_stack,
                )
                self._servers[server_name] = server
                logger.info(
                    "Connected to MCP server '%s' (%s) with %d tools",
                    server_name, config.transport, len(tools),
                )
                return server

            except Exception:
                await exit_stack.aclose()
                logger.error("Failed to connect to MCP server '%s'", server_name, exc_info=True)
                raise

    async def disconnect(self, server_name: str) -> None:
        async with self._lock:
            server = self._servers.pop(server_name, None)
            if server:
                try:
                    await server._exit_stack.aclose()
                except Exception:
                    logger.warning(
                        "Error closing MCP server '%s'", server_name, exc_info=True
                    )
                logger.info("Disconnected from MCP server '%s'", server_name)

    async def call_tool(
        self, server_name: str, tool_name: str, arguments: dict[str, Any]
    ) -> dict[str, Any]:
        server = self._servers.get(server_name)
        if not server:
            raise ValueError(f"MCP server '{server_name}' is not connected")

        result = await server.session.call_tool(tool_name, arguments)
        content_parts: list[dict[str, Any]] = []
        for item in result.content:
            if hasattr(item, "text"):
                content_parts.append({"type": "text", "text": item.text})
            elif hasattr(item, "data") and hasattr(item, "mimeType"):
                content_parts.append({"type": "text", "text": f"[Binary content: {item.mimeType}]"})
            else:
                content_parts.append({"type": "text", "text": str(item)})

        return {"content": content_parts, "is_error": result.isError}

    async def shutdown(self) -> None:
        names = list(self._servers.keys())
        for name in names:
            await self.disconnect(name)


_manager: MCPManager | None = None


def get_mcp_manager() -> MCPManager:
    global _manager
    if _manager is None:
        _manager = MCPManager()
    return _manager
