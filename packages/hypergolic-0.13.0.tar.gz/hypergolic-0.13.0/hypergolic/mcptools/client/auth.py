import os
from typing import Any

import httpx
from mcp.client.auth import OAuthClientProvider
from mcp.shared.auth import OAuthClientMetadata
from pydantic import AnyUrl

from hypergolic.config.schemas import MCPServerConfig
from hypergolic.mcptools.oauth import (
    FileTokenStorage,
    OAUTH_REDIRECT_URI,
    open_browser_for_oauth,
    wait_for_oauth_callback,
)


def build_http_auth(
    server_name: str, config: MCPServerConfig
) -> tuple[dict[str, str] | None, Any]:
    auth_config = config.auth
    headers: dict[str, str] | None = None
    auth: httpx.Auth | None = None

    if auth_config.type == "token":
        token = resolve_token(auth_config)
        if token:
            prefix = auth_config.token_prefix
            value = f"{prefix} {token}" if prefix else token
            headers = {auth_config.token_header: value}

    elif auth_config.type == "oauth":
        storage = FileTokenStorage(server_name)
        redirect_uri = AnyUrl(OAUTH_REDIRECT_URI)
        client_metadata = OAuthClientMetadata(
            redirect_uris=[redirect_uri],
            client_name="Hypergolic",
            grant_types=["authorization_code", "refresh_token"],
            response_types=["code"],
        )
        auth = OAuthClientProvider(
            server_url=config.url or "",
            client_metadata=client_metadata,
            storage=storage,
            redirect_handler=open_browser_for_oauth,
            callback_handler=wait_for_oauth_callback,
        )

    return headers, auth


def resolve_token(auth_config: Any) -> str | None:
    if auth_config.token_env_var:
        return os.environ.get(auth_config.token_env_var)
    return None
