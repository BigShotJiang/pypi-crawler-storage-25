from contextlib import AsyncExitStack

from mcp import ClientSession, StdioServerParameters
from mcp.client.sse import sse_client
from mcp.client.stdio import stdio_client
from mcp.client.streamable_http import streamable_http_client

from hypergolic.config.schemas import MCPServerConfig
from hypergolic.mcptools.client.auth import build_http_auth
from hypergolic.mcptools.client.http import make_http_client


async def connect_stdio(
    config: MCPServerConfig, exit_stack: AsyncExitStack
) -> ClientSession:
    if not config.command:
        raise ValueError("stdio transport requires 'command'")
    params = StdioServerParameters(
        command=config.command,
        args=config.args,
        env=config.env or None,
    )
    stdio_transport = await exit_stack.enter_async_context(
        stdio_client(params)
    )
    read_stream, write_stream = stdio_transport
    return await exit_stack.enter_async_context(
        ClientSession(read_stream, write_stream)
    )


async def connect_streamable_http(
    server_name: str,
    config: MCPServerConfig,
    exit_stack: AsyncExitStack,
) -> ClientSession:
    if not config.url:
        raise ValueError("streamable_http transport requires 'url'")

    headers, auth = build_http_auth(server_name, config)
    client = make_http_client(headers=headers, auth=auth)

    transport = await exit_stack.enter_async_context(
        streamable_http_client(url=config.url, http_client=client)
    )
    read_stream, write_stream, _ = transport
    return await exit_stack.enter_async_context(
        ClientSession(read_stream, write_stream)
    )


async def connect_sse(
    server_name: str,
    config: MCPServerConfig,
    exit_stack: AsyncExitStack,
) -> ClientSession:
    if not config.url:
        raise ValueError("sse transport requires 'url'")

    headers, auth = build_http_auth(server_name, config)

    transport = await exit_stack.enter_async_context(
        sse_client(
            url=config.url,
            headers=headers,
            auth=auth,
            httpx_client_factory=make_http_client,
        )
    )
    read_stream, write_stream = transport
    return await exit_stack.enter_async_context(
        ClientSession(read_stream, write_stream)
    )
