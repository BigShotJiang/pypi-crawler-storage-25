import logging
from pathlib import Path
from typing import Any

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.schemas import Session
from hypergolic.toolkit.app.lookup import collect_top_level_skills
from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.primitives import Skill, Workflow, resolve_prompt
from hypergolic.toolkit.project import Project

logger = logging.getLogger(__name__)


def resolve_roles() -> list[dict[str, Any]]:
    app = get_app()
    roles: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    for role in app.roles:
        if role.id not in seen_ids:
            prompt_path = ""
            if role.prompt_path:
                prompt_path = str(Path(role.prompt_path).expanduser())
            roles.append({
                "id": role.id,
                "name": role.name,
                "prompt_path": prompt_path,
                "prompt": role.prompt if hasattr(role, "prompt") else None,
                "tools": [t.id for t in role.tools] if role.tools else [],
                "skills": [s.id for s in role.skills] if role.skills else [],
                "source": "toolkit",
            })
            seen_ids.add(role.id)

    return roles


def _flatten_skills(
    skills: list[Skill],
    seen_ids: set[str],
    result: list[dict[str, Any]],
) -> None:
    """Recursively flatten skills and their children into dicts."""
    for skill in skills:
        if skill.id not in seen_ids:
            prompt_path = ""
            if skill.prompt_path:
                prompt_path = str(Path(skill.prompt_path).expanduser())
            result.append({
                "id": skill.id,
                "name": skill.name,
                "description": skill.description,
                "prompt_path": prompt_path,
                "prompt": skill.prompt if hasattr(skill, "prompt") else None,
                "tools": [t.id for t in skill.tools] if skill.tools else [],
                "source": "toolkit",
            })
            seen_ids.add(skill.id)
            _flatten_skills(skill.skills, seen_ids, result)


def resolve_skills() -> list[dict[str, Any]]:
    app = get_app()
    skills: list[dict[str, Any]] = []
    seen_ids: set[str] = set()

    _flatten_skills(collect_top_level_skills(app), seen_ids, skills)

    return skills


def _find_workflow(
    app: Any, project: Project | None, workflow_id: str
) -> Workflow | None:
    for wf in app.workflows:
        if wf.id == workflow_id:
            return wf
    if project:
        for wf in project.workflows:
            if wf.id == workflow_id:
                return wf
    return None


def resolve_session_skills(session: Session) -> list[dict[str, Any]]:
    """Collect skills available to a specific session.

    Unlike resolve_skills() which returns ALL skills across every role,
    project, and workflow, this function is session-aware: it only returns
    skills from the session's own project, role, active workflow, and
    active skill children.
    """
    from hypergolic.workflows.resolver import get_session_workflow

    app = get_app()
    skills_data: list[dict[str, Any]] = []
    seen: set[str] = set()

    def _add_skill(s: Any) -> None:
        if s.id not in seen:
            skills_data.append({
                "id": s.id,
                "name": s.name,
                "description": s.description or "",
                "source": "toolkit",
            })
            seen.add(s.id)

    # 1. App-level skills
    for s in app.skills:
        _add_skill(s)

    # 2. Project skills
    project = app.get_project(session.project_id)
    if project:
        for s in project.skills:
            _add_skill(s)

    # 3. Role skills
    role = app.get_role(session.role)
    if role:
        for s in role.skills:
            _add_skill(s)

    # 4. Workflow and workflow state skills
    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, current_state_id = wf_state
        wf = _find_workflow(app, project, workflow_id)
        if wf:
            for s in wf.skills:
                _add_skill(s)
            for state in wf.states:
                if state.id == current_state_id:
                    for s in state.skills:
                        _add_skill(s)
                    break

    # 5. Active skill children
    for sid in session.active_skill_ids:
        skill_obj = app.get_skill(sid)
        if skill_obj:
            for child in skill_obj.skills:
                _add_skill(child)

    return skills_data


def get_skill_prompt_content(skill_id: str) -> tuple[str, str | None] | None:
    """Returns (name, prompt_content) for a skill, or None if not found.

    If the skill exists but its prompt file is missing, returns (name, None).
    """
    app = get_app()
    for skill_data in resolve_skills():
        if skill_data["id"] == skill_id:
            skill_obj = app.get_skill(skill_id)
            if skill_obj:
                content = resolve_prompt(skill_obj, app)
                if content:
                    return skill_data["name"], content
            return skill_data["name"], None
    return None


def get_active_skill_ids(session_id: str) -> set[str]:
    with get_db() as db:
        rows = db.execute(
            select(DBSessionSkill.skill_id)
            .where(DBSessionSkill.session_id == session_id)
        ).scalars().all()
    return set(rows)
