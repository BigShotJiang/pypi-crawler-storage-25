"""Background task orchestration for worktree environment seeding.

Seeding (copying ``.venv``, ``node_modules``, etc. into a fresh worktree) can
take anywhere from milliseconds (APFS clone) to minutes (non-CoW tree of a
large Node project). Session creation must not block on it, so we run
seeding off the request path and persist progress on the session row.

This module owns:

- The status-update DB writes (pending → seeding → ready/failed).
- A synchronous :func:`run_seed_task` entrypoint — easy to test.
- An :func:`schedule_seed_task` helper that kicks the work onto the event
  loop when one exists, or runs inline as a fallback.
"""

from __future__ import annotations

import asyncio
import logging
from pathlib import Path

from sqlalchemy import update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.git.worktree import seed_worktree_environment
from hypergolic.schemas import WorktreeSeedStatus

logger = logging.getLogger(__name__)


def set_seed_status(session_id: str, status: WorktreeSeedStatus) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(worktree_seed_status=status)
        )


def run_seed_task(
    *,
    session_id: str,
    project_path: Path,
    worktree_path: Path,
    skip_entries: tuple[str, ...] = (),
) -> None:
    """Seed the worktree synchronously, updating status along the way."""
    set_seed_status(session_id, "seeding")
    try:
        seed_worktree_environment(
            project_path=project_path,
            worktree_path=worktree_path,
            skip_entries=skip_entries,
        )
    except Exception:
        logger.exception(
            "Worktree environment seeding failed for session %s", session_id
        )
        set_seed_status(session_id, "failed")
        return
    set_seed_status(session_id, "ready")


def schedule_seed_task(
    *,
    session_id: str,
    project_path: Path,
    worktree_path: Path,
    skip_entries: tuple[str, ...] = (),
) -> None:
    """Run seeding off the current event loop if possible; inline otherwise.

    Using ``asyncio.to_thread`` keeps the blocking ``cp`` subprocess calls
    off the event loop so request-serving tasks stay responsive.
    """
    def _do() -> None:
        run_seed_task(
            session_id=session_id,
            project_path=project_path,
            worktree_path=worktree_path,
            skip_entries=skip_entries,
        )

    try:
        loop = asyncio.get_event_loop()
    except RuntimeError:
        loop = None

    if loop is not None and loop.is_running():
        asyncio.ensure_future(asyncio.to_thread(_do))
        return
    _do()
