"""Low-level git command runner and error type."""

import subprocess
from pathlib import Path


class GitCommandError(Exception):
    def __init__(
        self, command: str, returncode: int, stderr: str, stdout: str = "",
    ):
        self.command = command
        self.returncode = returncode
        self.stderr = stderr
        self.stdout = stdout
        super().__init__(f"git {command} failed (exit {returncode}): {stderr}")


def git_repo_root() -> Path:
    """Return the root of the current git repository, or cwd as fallback."""
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, check=True,
        )
        return Path(result.stdout.strip())
    except (subprocess.CalledProcessError, FileNotFoundError):
        return Path.cwd()


def run_git_command(
    *args: str, cwd: Path | None = None, check: bool = False,
) -> subprocess.CompletedProcess[str]:
    """Run a git command and optionally raise on failure."""
    repo = cwd or git_repo_root()
    result = subprocess.run(
        ["git", *args],
        capture_output=True, text=True, cwd=repo,
    )
    if check and result.returncode != 0:
        raise GitCommandError(
            command=args[0] if args else "unknown",
            returncode=result.returncode,
            stderr=result.stderr.strip(),
            stdout=result.stdout.strip(),
        )
    return result
