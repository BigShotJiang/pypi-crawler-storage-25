"""Worktree session lifecycle: create, seed, teardown.

Responsibilities:

- Create a git worktree at ``~/.hypergolic/worktrees/<session_id>/`` on a
  new branch ``hyp/<short-id>`` rooted at the current branch.
- Seed the worktree with gitignored entries from the project root so tools
  like ``pytest``, ``npm``, or anything that needs ``.venv``/``node_modules``
  just work.
- Tear down the worktree directory and (optionally) the branch at session
  conclude or delete time, matching the rules in the PRD.

Env seeding is intentionally a synchronous API here; callers that want
background behaviour dispatch it to a task runner (see
``hypergolic.git.worktree_seed``).
"""

from __future__ import annotations

import logging
import shutil
import subprocess
from dataclasses import dataclass
from pathlib import Path

from hypergolic.git.commands import GitCommandError, run_git_command

logger = logging.getLogger(__name__)


class WorktreeCreationError(Exception):
    """Raised when a worktree cannot be created."""


@dataclass(frozen=True)
class WorktreeInfo:
    worktree_path: Path
    branch: str
    base_branch: str


def worktrees_root() -> Path:
    """Location all Hypergolic-managed worktrees live under."""
    return Path.home() / ".hypergolic" / "worktrees"


def worktree_branch_name(session_id: str) -> str:
    """The branch name created for a given session."""
    return f"hyp/{session_id}"


def worktree_path_for(session_id: str) -> Path:
    return worktrees_root() / session_id


def _current_branch(project_path: Path) -> str:
    result = run_git_command(
        "rev-parse", "--abbrev-ref", "HEAD", cwd=project_path
    )
    if result.returncode != 0:
        raise WorktreeCreationError(
            f"Could not determine current branch in {project_path}: {result.stderr.strip()}"
        )
    branch = result.stdout.strip()
    if not branch or branch == "HEAD":
        raise WorktreeCreationError(
            f"Project at {project_path} is not on a named branch (detached HEAD)"
        )
    return branch


def create_worktree(*, session_id: str, project_path: Path) -> WorktreeInfo:
    """Create a new branch and worktree for *session_id*.

    Does NOT seed environment files; callers are responsible for scheduling
    :func:`seed_worktree_environment` separately.
    """
    project_path = project_path.resolve()
    if not (project_path / ".git").exists():
        raise WorktreeCreationError(f"Not a git repository: {project_path}")

    base_branch = _current_branch(project_path)
    branch = worktree_branch_name(session_id)
    target = worktree_path_for(session_id)

    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists():
        raise WorktreeCreationError(
            f"Worktree path already exists: {target}"
        )

    result = run_git_command(
        "worktree", "add", str(target), "-b", branch,
        cwd=project_path,
    )
    if result.returncode != 0:
        raise WorktreeCreationError(
            f"git worktree add failed: {result.stderr.strip() or result.stdout.strip()}"
        )

    return WorktreeInfo(worktree_path=target, branch=branch, base_branch=base_branch)


def remove_worktree(
    *,
    worktree_path: Path | str,
    project_path: Path | str,
    force: bool = False,
) -> None:
    """Remove *worktree_path* via ``git worktree remove``.

    Falls back to rmtree if git reports the worktree is unknown (the directory
    was moved or the metadata was already pruned).
    """
    worktree_path = Path(worktree_path)
    project_path = Path(project_path)

    args = ["worktree", "remove"]
    if force:
        args.append("--force")
    args.append(str(worktree_path))
    result = run_git_command(*args, cwd=project_path)
    if result.returncode != 0:
        stderr = result.stderr.strip()
        logger.warning(
            "git worktree remove failed for %s: %s", worktree_path, stderr,
        )
        # Best-effort fallback: if git no longer tracks the worktree, scrub
        # the directory ourselves.
        if worktree_path.exists():
            shutil.rmtree(worktree_path, ignore_errors=True)
        # Prune stale metadata regardless.
        run_git_command("worktree", "prune", cwd=project_path)


def delete_branch(
    *,
    branch: str,
    project_path: Path | str,
    force: bool = False,
) -> None:
    """Delete *branch* using ``git branch -d`` (or ``-D`` if *force*).

    Silently ignores failures — callers use this for opportunistic cleanup.
    Prunes stale worktree metadata first so a branch whose worktree was
    already removed can still be deleted.
    """
    project_path = Path(project_path)
    run_git_command("worktree", "prune", cwd=project_path)
    flag = "-D" if force else "-d"
    result = run_git_command("branch", flag, branch, cwd=project_path)
    if result.returncode != 0:
        logger.warning(
            "git branch %s %s failed: %s", flag, branch, result.stderr.strip(),
        )


def teardown_worktree_on_delete(
    *,
    worktree_path: str | None,
    worktree_branch: str | None,
    project_path: str | None,
) -> None:
    """Cleanup hook for session deletion.

    Both the directory and the branch are blown away (with ``--force`` /
    ``-D``) because this runs when the user is explicitly discarding the
    session — data-loss is the desired outcome.
    """
    if not project_path:
        return
    if worktree_path:
        try:
            remove_worktree(
                worktree_path=worktree_path,
                project_path=project_path,
                force=True,
            )
        except GitCommandError:  # pragma: no cover - run_git_command doesn't raise here
            logger.warning("Error removing worktree %s", worktree_path, exc_info=True)
    if worktree_branch:
        delete_branch(
            branch=worktree_branch,
            project_path=project_path,
            force=True,
        )


def list_gitignored_entries(project_path: Path) -> list[str]:
    """Return project-root-relative paths that git considers ignored.

    Uses ``--directory`` so whole ignored directories (like ``node_modules``)
    are returned as single entries instead of one line per file.
    """
    result = run_git_command(
        "ls-files", "--others", "--ignored", "--exclude-standard", "--directory",
        cwd=project_path,
    )
    if result.returncode != 0:
        logger.warning(
            "git ls-files for ignored entries failed in %s: %s",
            project_path, result.stderr.strip(),
        )
        return []
    entries: list[str] = []
    for line in result.stdout.splitlines():
        line = line.strip().rstrip("/")
        if not line:
            continue
        # Never copy .git — git worktree handles this already.
        if line == ".git" or line.startswith(".git/"):
            continue
        entries.append(line)
    return entries


def _cow_copy(src: Path, dst: Path) -> bool:
    """Try a copy-on-write copy. Returns True on success.

    macOS: ``cp -c`` (APFS clone). Linux: ``cp --reflink=auto``.
    """
    import sys

    if sys.platform == "darwin":
        cmd = ["cp", "-c", "-R", str(src), str(dst)]
    else:
        cmd = ["cp", "--reflink=auto", "-R", str(src), str(dst)]
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
    except FileNotFoundError:
        return False
    return result.returncode == 0


def _plain_copy(src: Path, dst: Path) -> None:
    if src.is_dir():
        shutil.copytree(src, dst, symlinks=True, dirs_exist_ok=False)
    else:
        dst.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(src, dst, follow_symlinks=False)


def seed_worktree_environment(
    *,
    project_path: Path,
    worktree_path: Path,
    skip_entries: tuple[str, ...] = (),
) -> None:
    """Copy every gitignored entry from *project_path* into *worktree_path*.

    Uses copy-on-write (APFS clone / reflink) where the filesystem supports
    it; otherwise falls back to a full recursive copy.

    *skip_entries* is a list of project-root-relative paths that should
    never be copied (e.g. the Hypergolic DB or state directory if it lives
    under the project root).
    """
    project_path = project_path.resolve()
    worktree_path = worktree_path.resolve()
    skips = set(skip_entries)

    for rel in list_gitignored_entries(project_path):
        if rel in skips:
            continue
        src = project_path / rel
        if not src.exists() and not src.is_symlink():
            continue
        dst = worktree_path / rel
        if dst.exists():
            continue  # tracked file already in place or earlier pass copied it
        dst.parent.mkdir(parents=True, exist_ok=True)
        if not _cow_copy(src, dst):
            try:
                _plain_copy(src, dst)
            except Exception:
                logger.warning(
                    "Failed to copy %s into worktree %s", rel, worktree_path,
                    exc_info=True,
                )
