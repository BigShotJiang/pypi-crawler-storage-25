"""Re-exports for backward compatibility.

The actual implementations live in git/commands.py, git/status.py,
git/diff.py, git/actions.py, and git/log.py.
"""

from hypergolic.git.actions import (  # noqa: F401
    git_commit,
    git_discard,
    git_pull,
    git_push,
    git_stage,
    git_unstage,
)
from hypergolic.git.commands import (  # noqa: F401
    GitCommandError,
    git_repo_root,
    run_git_command,
)
from hypergolic.git.diff import get_git_diff  # noqa: F401
from hypergolic.git.log import get_git_commit_detail, get_git_log  # noqa: F401
from hypergolic.git.status import get_git_status  # noqa: F401
