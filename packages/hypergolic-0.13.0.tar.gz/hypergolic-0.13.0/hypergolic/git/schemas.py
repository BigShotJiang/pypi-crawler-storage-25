from pydantic import BaseModel


class ChangedFile(BaseModel):
    path: str
    status: str
    staged: bool
    additions: int = 0
    deletions: int = 0


class GitStatusResponse(BaseModel):
    branch: str
    ahead: int
    behind: int
    staged: list[ChangedFile]
    unstaged: list[ChangedFile]
    untracked: list[str]


class GitDiffResponse(BaseModel):
    path: str = ""
    diff: str


class GitLogEntry(BaseModel):
    hash: str
    short_hash: str
    author: str
    date: str
    message: str
    refs: str


class GitLogResponse(BaseModel):
    entries: list[GitLogEntry]


class GitCommitDetailResponse(BaseModel):
    hash: str
    short_hash: str
    author: str
    date: str
    message: str
    diff: str
