"""Git mutating actions: stage, unstage, discard, commit, push, pull."""

from pathlib import Path

from hypergolic.git.commands import git_repo_root, run_git_command


def git_stage(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    run_git_command("add", "--", *paths, cwd=repo, check=True)


def git_unstage(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    run_git_command("reset", "HEAD", "--", *paths, cwd=repo, check=True)


def git_discard(paths: list[str], repo: Path | None = None) -> None:
    repo = repo or git_repo_root()
    run_git_command("checkout", "--", *paths, cwd=repo, check=True)


def git_commit(message: str, repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    result = run_git_command("commit", "-m", message, cwd=repo, check=True)
    return result.stdout.strip()


def _current_branch(repo: Path) -> str:
    result = run_git_command("branch", "--show-current", cwd=repo)
    return result.stdout.strip() or "HEAD"


def git_push(repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    branch = _current_branch(repo)
    result = run_git_command("push", "-u", "origin", branch, cwd=repo, check=True)
    return result.stdout.strip() or result.stderr.strip()


def _has_upstream(repo: Path) -> bool:
    result = run_git_command(
        "rev-parse", "--abbrev-ref", "--symbolic-full-name", "@{upstream}",
        cwd=repo,
    )
    return result.returncode == 0


def git_pull(repo: Path | None = None) -> str:
    repo = repo or git_repo_root()
    if not _has_upstream(repo):
        return "No upstream branch to pull from (push first to create it)."
    result = run_git_command("pull", cwd=repo, check=True)
    return result.stdout.strip() or result.stderr.strip()
