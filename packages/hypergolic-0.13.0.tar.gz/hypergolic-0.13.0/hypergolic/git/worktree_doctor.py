"""Reconcile worktree filesystem/git/DB state.

Called from ``hyp doctor`` to clean up orphans left by crashes or manual
mucking-around. The three axes we reconcile:

1. Directories in ``~/.hypergolic/worktrees/`` without a live session row.
2. Local ``hyp/*`` branches without a corresponding session row.
3. Session rows whose ``worktree_path`` points at a missing directory.
"""

from __future__ import annotations

import logging
import shutil
from dataclasses import dataclass, field
from pathlib import Path

from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.git.commands import run_git_command
from hypergolic.git.worktree import worktrees_root

logger = logging.getLogger(__name__)


@dataclass
class WorktreeReconcileReport:
    orphan_dirs_removed: list[str] = field(default_factory=list)
    orphan_branches_removed: list[str] = field(default_factory=list)
    stale_rows_cleared: list[str] = field(default_factory=list)

    def is_clean(self) -> bool:
        return not (
            self.orphan_dirs_removed
            or self.orphan_branches_removed
            or self.stale_rows_cleared
        )


def _list_hyp_branches(project_path: Path) -> list[str]:
    result = run_git_command(
        "for-each-ref", "--format=%(refname:short)", "refs/heads/hyp/",
        cwd=project_path,
    )
    if result.returncode != 0:
        return []
    return [line.strip() for line in result.stdout.splitlines() if line.strip()]


def reconcile_worktrees(*, dry_run: bool = False) -> WorktreeReconcileReport:
    """Reconcile worktree state across all projects.

    With ``dry_run=True`` nothing is modified; the report describes what
    *would* change.
    """
    report = WorktreeReconcileReport()
    root = worktrees_root()

    # Snapshot DB state.
    with get_db() as db:
        active_sessions = {
            row.id: row
            for row in db.execute(
                select(DBSession).where(
                    (DBSession.worktree_path.is_not(None))
                    | (DBSession.worktree_branch.is_not(None))
                )
            ).scalars().all()
        }
        project_paths = {
            row[0]: row[1]
            for row in db.execute(select(DBProject.id, DBProject.path)).all()
        }

    live_worktree_dirs = {
        Path(s.worktree_path).resolve()
        for s in active_sessions.values()
        if s.worktree_path
    }
    live_branches_by_project: dict[str, set[str]] = {}
    for s in active_sessions.values():
        if s.worktree_branch:
            live_branches_by_project.setdefault(s.project_id, set()).add(s.worktree_branch)

    # 1. Orphan directories.
    if root.exists():
        for entry in root.iterdir():
            if not entry.is_dir():
                continue
            resolved = entry.resolve()
            if resolved in live_worktree_dirs:
                continue
            report.orphan_dirs_removed.append(str(entry))
            if not dry_run:
                shutil.rmtree(entry, ignore_errors=True)

    # 2. Orphan hyp/* branches per project.
    for project_id, project_path in project_paths.items():
        p = Path(project_path)
        if not (p / ".git").exists():
            continue
        branches = _list_hyp_branches(p)
        live = live_branches_by_project.get(project_id, set())
        for branch in branches:
            if branch in live:
                continue
            report.orphan_branches_removed.append(f"{project_id}:{branch}")
            if not dry_run:
                run_git_command("worktree", "prune", cwd=p)
                run_git_command("branch", "-D", branch, cwd=p)

    # 3. DB rows with missing worktree directories.
    for sid, s in active_sessions.items():
        if not s.worktree_path:
            continue
        if Path(s.worktree_path).exists():
            continue
        report.stale_rows_cleared.append(sid)
        if not dry_run:
            with get_db() as db:
                db.execute(
                    update(DBSession)
                    .where(DBSession.id == sid)
                    .values(worktree_path=None)
                )

    return report
