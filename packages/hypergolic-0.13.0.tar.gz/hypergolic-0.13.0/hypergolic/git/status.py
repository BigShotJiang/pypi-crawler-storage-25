"""Git status and numstat parsing."""

from pathlib import Path

from hypergolic.git.commands import git_repo_root, run_git_command
from hypergolic.git.schemas import ChangedFile, GitStatusResponse


def _parse_numstat(repo: Path, staged: bool) -> dict[str, tuple[int, int]]:
    """Parse `git diff --numstat` output into {path: (additions, deletions)}."""
    args = ["diff", "--numstat"]
    if staged:
        args.append("--cached")
    result = run_git_command(*args, cwd=repo)
    stats: dict[str, tuple[int, int]] = {}
    for line in result.stdout.splitlines():
        parts = line.split("\t")
        if len(parts) == 3:
            adds = int(parts[0]) if parts[0] != "-" else 0
            dels = int(parts[1]) if parts[1] != "-" else 0
            stats[parts[2]] = (adds, dels)
    return stats


def get_git_status(repo: Path | None = None) -> GitStatusResponse:
    """Return structured git status for a repository."""
    repo = repo or git_repo_root()

    branch_result = run_git_command("branch", "--show-current", cwd=repo)
    branch = branch_result.stdout.strip() or "HEAD"

    ahead = 0
    behind = 0
    ab_result = run_git_command(
        "rev-list", "--left-right", "--count", "@{upstream}...HEAD", cwd=repo,
    )
    if ab_result.returncode == 0:
        parts = ab_result.stdout.strip().split()
        if len(parts) == 2:
            behind = int(parts[0])
            ahead = int(parts[1])

    status_result = run_git_command("status", "--porcelain", "-uall", cwd=repo)
    staged_stats = _parse_numstat(repo, staged=True)
    unstaged_stats = _parse_numstat(repo, staged=False)

    staged: list[ChangedFile] = []
    unstaged: list[ChangedFile] = []
    untracked: list[str] = []

    for line in status_result.stdout.splitlines():
        if len(line) < 4:
            continue
        index_status = line[0]
        worktree_status = line[1]
        filepath = line[3:].strip()
        if " -> " in filepath:
            filepath = filepath.split(" -> ", 1)[1]

        if index_status == "?" and worktree_status == "?":
            untracked.append(filepath)
            continue

        if index_status not in (" ", "?"):
            adds, dels = staged_stats.get(filepath, (0, 0))
            staged.append(ChangedFile(
                path=filepath, status=index_status, staged=True,
                additions=adds, deletions=dels,
            ))

        if worktree_status not in (" ", "?"):
            adds, dels = unstaged_stats.get(filepath, (0, 0))
            unstaged.append(ChangedFile(
                path=filepath, status=worktree_status, staged=False,
                additions=adds, deletions=dels,
            ))

    return GitStatusResponse(
        branch=branch, ahead=ahead, behind=behind,
        staged=staged, unstaged=unstaged, untracked=untracked,
    )
