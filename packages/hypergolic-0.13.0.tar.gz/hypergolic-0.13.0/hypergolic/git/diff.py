"""Git diff operations."""

from pathlib import Path

from hypergolic.git.commands import git_repo_root, run_git_command
from hypergolic.git.schemas import GitDiffResponse


def _is_tracked(path: str, repo: Path) -> bool:
    result = run_git_command("ls-files", "--error-unmatch", "--", path, cwd=repo)
    return result.returncode == 0


def get_git_diff(
    path: str | None, staged: bool, repo: Path | None = None,
) -> GitDiffResponse:
    """Return the diff for *path* (or the whole repo if None)."""
    repo = repo or git_repo_root()
    args = ["diff"]
    if staged:
        args.append("--cached")
    if path:
        args.extend(["--", path])
    result = run_git_command(*args, cwd=repo)
    diff_text = result.stdout
    if path and not diff_text and not staged and not _is_tracked(path, repo):
        new_result = run_git_command(
            "diff", "--no-index", "/dev/null", path, cwd=repo,
        )
        diff_text = new_result.stdout
    return GitDiffResponse(path=path or "", diff=diff_text)
