"""add session worktree fields

Revision ID: 0007
Revises: 0006
Create Date: 2026-04-18 06:30:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0007"
down_revision: Union[str, Sequence[str], None] = "0006"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("sessions") as batch_op:
        batch_op.add_column(sa.Column("worktree_path", sa.String(), nullable=True))
        batch_op.add_column(sa.Column("worktree_branch", sa.String(), nullable=True))
        batch_op.add_column(sa.Column("base_branch", sa.String(), nullable=True))
        batch_op.add_column(sa.Column("worktree_seed_status", sa.String(), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("sessions") as batch_op:
        batch_op.drop_column("worktree_seed_status")
        batch_op.drop_column("base_branch")
        batch_op.drop_column("worktree_branch")
        batch_op.drop_column("worktree_path")
