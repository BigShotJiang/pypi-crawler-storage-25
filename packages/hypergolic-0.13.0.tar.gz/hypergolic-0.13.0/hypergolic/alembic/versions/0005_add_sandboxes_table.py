"""add sandboxes table

Revision ID: 0005
Revises: 0004
Create Date: 2025-07-27 00:00:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0005"
down_revision: Union[str, Sequence[str], None] = "0004"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "sandboxes",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("tool_id", sa.String(), nullable=False),
        sa.Column("status", sa.String(), nullable=False, server_default="pending"),
        sa.Column("compose_project", sa.String(), nullable=True),
        sa.Column("config_path", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), server_default=sa.func.now(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.ForeignKeyConstraint(
            ["session_id"], ["sessions.id"],
            name="fk_sandboxes_sessions",
            ondelete="CASCADE",
        ),
    )
    op.create_index("ix_sandboxes_session_id", "sandboxes", ["session_id"])


def downgrade() -> None:
    op.drop_index("ix_sandboxes_session_id", table_name="sandboxes")
    op.drop_table("sandboxes")
