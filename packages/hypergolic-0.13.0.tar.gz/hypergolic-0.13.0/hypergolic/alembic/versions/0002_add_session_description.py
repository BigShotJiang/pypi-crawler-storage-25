"""add session description

Revision ID: 0002
Revises: 0001
Create Date: 2025-07-27 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0002"
down_revision: Union[str, Sequence[str], None] = "0001"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.add_column("sessions", sa.Column("description", sa.String(), nullable=True))


def downgrade() -> None:
    op.drop_column("sessions", "description")
