"""add session conclusion fields

Revision ID: 0004
Revises: 0003
Create Date: 2025-07-23 00:00:00.000000

"""

from typing import Sequence, Union

import sqlalchemy as sa
from alembic import op


revision: str = "0004"
down_revision: Union[str, Sequence[str], None] = "0003"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("sessions") as batch_op:
        batch_op.add_column(sa.Column("conclusion_rating", sa.Integer(), nullable=True))
        batch_op.add_column(sa.Column("conclusion_feedback", sa.String(), nullable=True))
        batch_op.add_column(sa.Column("conclusion_summary", sa.String(), nullable=True))
        batch_op.add_column(sa.Column("concluded_at", sa.DateTime(timezone=True), nullable=True))


def downgrade() -> None:
    with op.batch_alter_table("sessions") as batch_op:
        batch_op.drop_column("concluded_at")
        batch_op.drop_column("conclusion_summary")
        batch_op.drop_column("conclusion_feedback")
        batch_op.drop_column("conclusion_rating")
