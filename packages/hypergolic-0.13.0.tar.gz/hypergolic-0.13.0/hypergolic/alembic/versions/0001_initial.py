"""initial

Revision ID: 0001
Revises:
Create Date: 2025-07-26 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op
import sqlalchemy as sa


revision: str = "0001"
down_revision: Union[str, Sequence[str], None] = None
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    op.create_table(
        "projects",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.Column("path", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("path"),
    )
    op.create_index(op.f("ix_projects_created_at"), "projects", ["created_at"])

    op.create_table(
        "tags",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("name", sa.String(), nullable=False),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("name"),
    )
    op.create_index(op.f("ix_tags_created_at"), "tags", ["created_at"])

    op.create_table(
        "sessions",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("model_tier", sa.String(), nullable=False),
        sa.Column("system_prompt", sa.JSON(), nullable=False),
        sa.Column("role", sa.String(), nullable=False, server_default="generalist"),
        sa.Column("status", sa.String(), nullable=False, server_default="idle"),
        sa.Column("project_id", sa.String(), nullable=False),
        sa.Column("parent_id", sa.String(), nullable=True),
        sa.Column("dispatch_prompt", sa.String(), nullable=True),
        sa.ForeignKeyConstraint(
            ["project_id"],
            ["projects.id"],
            name="fk_sessions_projects",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["parent_id"],
            ["sessions.id"],
            name="fk_sessions_parent",
            ondelete="SET NULL",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_sessions_created_at"), "sessions", ["created_at"])
    op.create_index(op.f("ix_sessions_project_id"), "sessions", ["project_id"])
    op.create_index(op.f("ix_sessions_parent_id"), "sessions", ["parent_id"])

    op.create_table(
        "messages",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("content", sa.JSON(), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("model", sa.String(), nullable=True),
        sa.Column("role", sa.String(), nullable=False),
        sa.Column("stop_reason", sa.String(), nullable=True),
        sa.Column("stop_sequence", sa.String(), nullable=True),
        sa.Column("usage", sa.JSON(), nullable=True),
        sa.Column(
            "truncated", sa.Boolean(), nullable=False, server_default=sa.text("0")
        ),
        sa.ForeignKeyConstraint(
            ["session_id"],
            ["sessions.id"],
            name="fk_messages_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_messages_created_at"), "messages", ["created_at"])
    op.create_index(op.f("ix_messages_session_id"), "messages", ["session_id"])

    op.create_table(
        "knowledge",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("content", sa.String(), nullable=False),
        sa.Column("scope", sa.String(), nullable=False),
        sa.Column("source", sa.String(), nullable=True),
        sa.Column("project_id", sa.String(), nullable=True),
        sa.Column("session_id", sa.String(), nullable=True),
        sa.ForeignKeyConstraint(
            ["project_id"],
            ["projects.id"],
            name="fk_knowledge_projects",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["session_id"],
            ["sessions.id"],
            name="fk_knowledge_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_knowledge_created_at"), "knowledge", ["created_at"])
    op.create_index(op.f("ix_knowledge_project_id"), "knowledge", ["project_id"])
    op.create_index(op.f("ix_knowledge_session_id"), "knowledge", ["session_id"])

    op.create_table(
        "knowledge_tags",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("knowledge_id", sa.String(), nullable=False),
        sa.Column("tag_id", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["knowledge_id"],
            ["knowledge.id"],
            name="fk_knowledge_tags_knowledge",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["tag_id"], ["tags.id"], name="fk_knowledge_tags_tags", ondelete="CASCADE"
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint("knowledge_id", "tag_id", name="uq_knowledge_tag"),
    )
    op.create_index(
        op.f("ix_knowledge_tags_created_at"), "knowledge_tags", ["created_at"]
    )
    op.create_index(
        op.f("ix_knowledge_tags_knowledge_id"), "knowledge_tags", ["knowledge_id"]
    )
    op.create_index(op.f("ix_knowledge_tags_tag_id"), "knowledge_tags", ["tag_id"])

    op.create_table(
        "knowledge_relationships",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("source_id", sa.String(), nullable=False),
        sa.Column("target_id", sa.String(), nullable=False),
        sa.Column("relation_type", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["source_id"],
            ["knowledge.id"],
            name="fk_knowledge_rel_source",
            ondelete="CASCADE",
        ),
        sa.ForeignKeyConstraint(
            ["target_id"],
            ["knowledge.id"],
            name="fk_knowledge_rel_target",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
        sa.UniqueConstraint(
            "source_id", "target_id", "relation_type", name="uq_knowledge_relationship"
        ),
    )
    op.create_index(
        op.f("ix_knowledge_relationships_created_at"),
        "knowledge_relationships",
        ["created_at"],
    )
    op.create_index(
        op.f("ix_knowledge_relationships_source_id"),
        "knowledge_relationships",
        ["source_id"],
    )
    op.create_index(
        op.f("ix_knowledge_relationships_target_id"),
        "knowledge_relationships",
        ["target_id"],
    )

    op.create_table(
        "session_skills",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("skill_id", sa.String(), nullable=False),
        sa.ForeignKeyConstraint(
            ["session_id"],
            ["sessions.id"],
            name="fk_session_skills_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_session_skills_created_at"), "session_skills", ["created_at"]
    )
    op.create_index(
        op.f("ix_session_skills_session_id"), "session_skills", ["session_id"]
    )

    op.create_table(
        "session_workflows",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("workflow_id", sa.String(), nullable=False),
        sa.Column("current_state_id", sa.String(), nullable=False),
        sa.Column("deleted_at", sa.DateTime(timezone=True), nullable=True),
        sa.ForeignKeyConstraint(
            ["session_id"],
            ["sessions.id"],
            name="fk_session_workflows_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(
        op.f("ix_session_workflows_created_at"), "session_workflows", ["created_at"]
    )
    op.create_index(
        op.f("ix_session_workflows_session_id"), "session_workflows", ["session_id"]
    )

    op.create_table(
        "artifacts",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("workflow_id", sa.String(), nullable=False),
        sa.Column("state_id", sa.String(), nullable=False),
        sa.Column("outcome", sa.String(), nullable=False),
        sa.Column("artifact_id", sa.String(), nullable=False),
        sa.Column("content", sa.JSON(), nullable=False),
        sa.ForeignKeyConstraint(
            ["session_id"],
            ["sessions.id"],
            name="fk_artifacts_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_artifacts_created_at"), "artifacts", ["created_at"])
    op.create_index(op.f("ix_artifacts_session_id"), "artifacts", ["session_id"])
    op.create_index(op.f("ix_artifacts_artifact_id"), "artifacts", ["artifact_id"])

    op.create_table(
        "errors",
        sa.Column("id", sa.String(), nullable=False),
        sa.Column("created_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("updated_at", sa.DateTime(timezone=True), nullable=False),
        sa.Column("session_id", sa.String(), nullable=False),
        sa.Column("error_type", sa.String(), nullable=False),
        sa.Column("message", sa.String(), nullable=False),
        sa.Column("traceback", sa.String(), nullable=True),
        sa.ForeignKeyConstraint(
            ["session_id"],
            ["sessions.id"],
            name="fk_errors_sessions",
            ondelete="CASCADE",
        ),
        sa.PrimaryKeyConstraint("id"),
    )
    op.create_index(op.f("ix_errors_created_at"), "errors", ["created_at"])
    op.create_index(op.f("ix_errors_session_id"), "errors", ["session_id"])


def downgrade() -> None:
    op.drop_table("errors")
    op.drop_table("artifacts")
    op.drop_table("session_workflows")
    op.drop_table("session_skills")
    op.drop_table("knowledge_relationships")
    op.drop_table("knowledge_tags")
    op.drop_table("knowledge")
    op.drop_table("messages")
    op.drop_table("sessions")
    op.drop_table("tags")
    op.drop_table("projects")
