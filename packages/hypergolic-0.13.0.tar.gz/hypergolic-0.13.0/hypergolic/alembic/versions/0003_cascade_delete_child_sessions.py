"""cascade delete child sessions

Revision ID: 0003
Revises: 0002
Create Date: 2025-04-13 00:00:00.000000

"""

from typing import Sequence, Union

from alembic import op


revision: str = "0003"
down_revision: Union[str, Sequence[str], None] = "0002"
branch_labels: Union[str, Sequence[str], None] = None
depends_on: Union[str, Sequence[str], None] = None


def upgrade() -> None:
    with op.batch_alter_table("sessions") as batch_op:
        batch_op.drop_constraint("fk_sessions_parent", type_="foreignkey")
        batch_op.create_foreign_key(
            "fk_sessions_parent",
            "sessions",
            ["parent_id"],
            ["id"],
            ondelete="CASCADE",
        )


def downgrade() -> None:
    with op.batch_alter_table("sessions") as batch_op:
        batch_op.drop_constraint("fk_sessions_parent", type_="foreignkey")
        batch_op.create_foreign_key(
            "fk_sessions_parent",
            "sessions",
            ["parent_id"],
            ["id"],
            ondelete="SET NULL",
        )

