from pathlib import Path
from typing import Literal

from pydantic_settings import BaseSettings

PROMPTS_DIR = Path(__file__).parent.parent / "base" / "prompts"


class Settings(BaseSettings):
    HYPERGOLIC_API_KEY: str = ""
    HYPERGOLIC_BASE_URL: str = "https://api.anthropic.com"
    HYPERGOLIC_DATABASE_URL: str = f"sqlite:///{Path.home() / '.hypergolic' / 'hypergolic.db'}"
    MAX_TOKENS: int = 64000

    # Provider selection: "anthropic" (direct API) or "bedrock" (AWS Bedrock).
    HYPERGOLIC_PROVIDER: Literal["anthropic", "bedrock"] = "anthropic"

    # Bedrock-specific settings (only used when HYPERGOLIC_PROVIDER="bedrock").
    # If left empty, the SDK uses the default AWS credential chain
    # (env vars, ~/.aws/credentials, instance profile, etc.).
    AWS_REGION: str = "us-east-1"
    AWS_ACCESS_KEY_ID: str = ""
    AWS_SECRET_ACCESS_KEY: str = ""
    AWS_SESSION_TOKEN: str = ""
    AWS_PROFILE: str = ""


settings = Settings()
