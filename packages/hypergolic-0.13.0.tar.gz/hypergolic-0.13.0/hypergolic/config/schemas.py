from typing import Literal

from pydantic import BaseModel, Field


class MCPAuthConfig(BaseModel):
    type: Literal["none", "token", "oauth"] = "none"
    token_env_var: str | None = None
    token_header: str = "Authorization"
    token_prefix: str = "Bearer"


class MCPServerConfig(BaseModel):
    transport: Literal["stdio", "streamable_http", "sse"] = "stdio"
    command: str | None = None
    args: list[str] = Field(default_factory=list)
    env: dict[str, str] = Field(default_factory=dict)
    url: str | None = None
    auth: MCPAuthConfig = Field(default_factory=MCPAuthConfig)

