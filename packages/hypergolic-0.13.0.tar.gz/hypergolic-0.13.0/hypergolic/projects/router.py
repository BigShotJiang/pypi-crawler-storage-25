from fastapi import APIRouter

from hypergolic.projects.operations import (
    list_all_projects,
    create_new_project,
    delete_project_by_id,
)
from hypergolic.projects.schemas import CreateProjectRequest, ProjectResponse

router = APIRouter(prefix="/api/projects", tags=["projects"])


@router.get("", response_model=list[ProjectResponse])
def list_projects():
    return list_all_projects()


@router.post("", response_model=ProjectResponse)
def create_project(req: CreateProjectRequest):
    return create_new_project(req.name, req.path)


@router.delete("/{project_id}")
def delete_project(project_id: str):
    delete_project_by_id(project_id)
    return {"status": "deleted"}
