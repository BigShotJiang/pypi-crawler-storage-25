import subprocess

from fastapi import HTTPException
from sqlalchemy import select, delete as sa_delete, func

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession, DBMessage
from hypergolic.db.utils import to_iso_utc
from hypergolic.projects.schemas import ProjectResponse


def validate_git_root(path: str) -> None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--show-toplevel"],
            capture_output=True,
            text=True,
            cwd=path,
            check=True,
        )
        actual_root = result.stdout.strip()
        if actual_root != path:
            raise HTTPException(
                status_code=400,
                detail=f"Path is not a git root. The git root is: {actual_root}",
            )
    except (subprocess.CalledProcessError, FileNotFoundError, OSError):
        raise HTTPException(
            status_code=400,
            detail=f"Path is not a valid git repository: {path}",
        )


def build_project_response(
    project: DBProject, last_session_at: str | None = None
) -> ProjectResponse:
    return ProjectResponse(
        id=project.id,
        name=project.name,
        path=project.path,
        created_at=to_iso_utc(project.created_at),
        last_session_at=last_session_at,
    )


def list_all_projects() -> list[ProjectResponse]:
    with get_db() as db:
        latest_session = (
            select(
                DBSession.project_id,
                func.max(DBSession.created_at).label("last_session_at"),
            )
            .group_by(DBSession.project_id)
            .subquery()
        )
        rows = db.execute(
            select(DBProject, latest_session.c.last_session_at)
            .outerjoin(
                latest_session, DBProject.id == latest_session.c.project_id
            )
            .order_by(
                latest_session.c.last_session_at.desc().nullslast(),
                DBProject.name,
            )
        ).all()
        return [
            build_project_response(
                project,
                to_iso_utc(last_session_at) if last_session_at else None,
            )
            for project, last_session_at in rows
        ]


def create_new_project(name: str, path: str) -> ProjectResponse:
    validate_git_root(path)
    with get_db() as db:
        existing = db.execute(
            select(DBProject).where(DBProject.path == path)
        ).scalar_one_or_none()
        if existing:
            raise HTTPException(
                status_code=409,
                detail=f"A project already exists for path: {path}",
            )
        project = DBProject(name=name, path=path)
        db.add(project)
        db.flush()
        return build_project_response(project)


def delete_project_by_id(project_id: str) -> None:
    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one_or_none()
        if not project:
            raise HTTPException(status_code=404, detail="Project not found")
        sessions = (
            db.execute(
                select(DBSession.id).where(DBSession.project_id == project_id)
            )
            .scalars()
            .all()
        )
        if sessions:
            db.execute(
                sa_delete(DBMessage).where(DBMessage.session_id.in_(sessions))
            )
            db.execute(
                sa_delete(DBSession).where(DBSession.project_id == project_id)
            )
        db.delete(project)
