from pydantic import BaseModel


class CreateProjectRequest(BaseModel):
    name: str
    path: str


class ProjectResponse(BaseModel):
    id: str
    name: str
    path: str
    created_at: str
    last_session_at: str | None = None
