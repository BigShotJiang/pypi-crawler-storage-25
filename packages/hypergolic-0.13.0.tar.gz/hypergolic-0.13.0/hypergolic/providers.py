from anthropic import AsyncAnthropic
from anthropic import AsyncAnthropicBedrock
from anthropic.types import MessageParam, ModelParam
from anthropic.types.output_config_param import OutputConfigParam

from hypergolic.config.settings import settings
from hypergolic.enums import ModelTier

AsyncClient = AsyncAnthropic | AsyncAnthropicBedrock


def _create_bedrock_client() -> AsyncAnthropicBedrock:
    return AsyncAnthropicBedrock(
        aws_region=settings.AWS_REGION or None,
        aws_access_key=settings.AWS_ACCESS_KEY_ID or None,
        aws_secret_key=settings.AWS_SECRET_ACCESS_KEY or None,
        aws_session_token=settings.AWS_SESSION_TOKEN or None,
        aws_profile=settings.AWS_PROFILE or None,
        max_retries=0,
    )


def _create_anthropic_client() -> AsyncAnthropic:
    return AsyncAnthropic(
        api_key=settings.HYPERGOLIC_API_KEY,
        base_url=settings.HYPERGOLIC_BASE_URL,
        # We run our own retry loop (with partial-message persistence and
        # session status broadcasting) in `messages.conversation.retry`, so
        # disable the SDK's built-in retries to avoid double-retrying.
        max_retries=0,
    )


def create_client() -> AsyncClient:
    if settings.HYPERGOLIC_PROVIDER == "bedrock":
        return _create_bedrock_client()
    return _create_anthropic_client()


_BEDROCK_MODEL_IDS: dict[ModelTier, str] = {
    ModelTier.LOW: "us.anthropic.claude-haiku-4-5-v1:0",
    ModelTier.MEDIUM: "us.anthropic.claude-sonnet-4-6-v1:0",
    ModelTier.HIGH: "us.anthropic.claude-opus-4-7-v1:0",
}

_ANTHROPIC_MODEL_IDS: dict[ModelTier, ModelParam] = {
    ModelTier.LOW: "claude-haiku-4-5",
    ModelTier.MEDIUM: "claude-sonnet-4-6",
    ModelTier.HIGH: "claude-opus-4-7",
}


def tier_to_model_id(tier: ModelTier) -> ModelParam:
    if settings.HYPERGOLIC_PROVIDER == "bedrock":
        return _BEDROCK_MODEL_IDS[tier]  # type: ignore[return-value]
    return _ANTHROPIC_MODEL_IDS[tier]


def tier_to_output_config(tier: ModelTier) -> OutputConfigParam | None:
    if tier == ModelTier.HIGH:
        return {"effort": "xhigh"}
    return None


async def generate_text(
    *,
    system: str,
    messages: list[MessageParam],
    max_tokens: int,
    model_tier: ModelTier = ModelTier.LOW,
) -> str | None:
    client = create_client()
    output_config = tier_to_output_config(model_tier)
    kwargs: dict = {
        "max_tokens": max_tokens,
        "model": tier_to_model_id(model_tier),
        "messages": messages,
        "system": system,
    }
    if output_config is not None:
        kwargs["output_config"] = output_config
    response = await client.messages.create(**kwargs)  # type: ignore[arg-type]
    text = "".join(
        getattr(b, "text", "") for b in response.content
        if getattr(b, "type", None) == "text"
    ).strip()
    return text or None
