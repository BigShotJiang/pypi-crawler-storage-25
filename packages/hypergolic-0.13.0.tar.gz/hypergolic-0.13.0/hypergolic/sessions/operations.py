import logging
from pathlib import Path
from typing import cast

from sqlalchemy import select, delete as sa_delete

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession, DBSessionSkill
from hypergolic.enums import ModelTier
from hypergolic.ids import new_id
from hypergolic.git.worktree import (
    WorktreeCreationError,
    create_worktree,
    teardown_worktree_on_delete,
)
from hypergolic.git.worktree_seed import schedule_seed_task
from hypergolic.schemas import Session, WorktreeSeedStatus
from hypergolic.toolkit.app.state import get_app

logger = logging.getLogger(__name__)


def _db_to_session(db_session: DBSession, project_path: str, active_skill_ids: set[str]) -> Session:
    seed_status = cast(
        WorktreeSeedStatus | None, db_session.worktree_seed_status
    ) if db_session.worktree_seed_status else None
    return Session(
        id=db_session.id,
        model_tier=db_session.model_tier,
        project_id=db_session.project_id,
        project_path=project_path,
        role=db_session.role,
        parent_id=db_session.parent_id,
        dispatch_prompt=db_session.dispatch_prompt,
        active_skill_ids=active_skill_ids,
        worktree_path=db_session.worktree_path,
        worktree_branch=db_session.worktree_branch,
        base_branch=db_session.base_branch,
        worktree_seed_status=seed_status,
    )


def load_session(session_id: str) -> Session:
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.path)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session_id)
        ).one()
        db_session, project_path = row
        active_skill_ids = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
            ).scalars().all()
        )
        return _db_to_session(db_session, project_path, active_skill_ids)


def delete_session_tree(session_id: str) -> None:
    """Delete a session and all descendants (via FK CASCADE).

    If the session (or any descendant) has worktree metadata, the worktree
    directory and branch are cleaned up first so we don't leak filesystem or
    git state when the DB rows disappear.
    """
    with get_db() as db:
        descendants = _collect_descendants(db, session_id)
        project_paths: dict[str, str] = {
            row[0]: row[1]
            for row in db.execute(select(DBProject.id, DBProject.path)).all()
        }
        for desc in descendants:
            project_path = project_paths.get(desc.project_id)
            try:
                teardown_worktree_on_delete(
                    worktree_path=desc.worktree_path,
                    worktree_branch=desc.worktree_branch,
                    project_path=project_path,
                )
            except Exception:  # pragma: no cover - defensive
                logger.warning(
                    "Failed to tear down worktree for session %s", desc.id, exc_info=True
                )
        db.execute(sa_delete(DBSession).where(DBSession.id == session_id))


def _collect_descendants(db, root_id: str) -> list[DBSession]:
    """Return the root session and all descendants (pre-cascade snapshot)."""
    result: list[DBSession] = []
    frontier = [root_id]
    while frontier:
        rows = db.execute(
            select(DBSession).where(DBSession.id.in_(frontier))
        ).scalars().all()
        result.extend(rows)
        next_frontier = list(
            db.execute(
                select(DBSession.id).where(DBSession.parent_id.in_(frontier))
            ).scalars().all()
        )
        frontier = next_frontier
    return result


def create_session(
    project_id: str,
    model_tier: ModelTier | None = None,
    role: str = "generalist",
    parent_id: str | None = None,
    dispatch_prompt: str | None = None,
    worktree: bool = False,
) -> Session:
    if model_tier is None:
        model_tier = get_app().default_model_tier
    session_id = new_id()
    system_prompt = [{"type": "text", "text": "placeholder"}]

    with get_db() as db:
        project = db.execute(
            select(DBProject).where(DBProject.id == project_id)
        ).scalar_one()
        project_path_str: str = project.path

        worktree_path: str | None = None
        worktree_branch: str | None = None
        base_branch: str | None = None
        worktree_seed_status: WorktreeSeedStatus | None = None

        _created_worktree: Path | None = None
        if worktree:
            try:
                info = create_worktree(
                    session_id=session_id,
                    project_path=Path(project_path_str),
                )
                worktree_path = str(info.worktree_path)
                worktree_branch = info.branch
                base_branch = info.base_branch
                worktree_seed_status = "pending"
                _created_worktree = info.worktree_path
            except WorktreeCreationError:
                logger.exception(
                    "Failed to create worktree for session %s; falling back to shared tree",
                    session_id,
                )
                # Fall through — session is created without a worktree.

        db_session = DBSession(
            id=session_id,
            model_tier=model_tier,
            system_prompt=system_prompt,
            role=role,
            project_id=project_id,
            parent_id=parent_id,
            dispatch_prompt=dispatch_prompt,
            worktree_path=worktree_path,
            worktree_branch=worktree_branch,
            base_branch=base_branch,
            worktree_seed_status=worktree_seed_status,
        )
        db.add(db_session)

        session_obj = Session(
            id=session_id,
            model_tier=model_tier,
            project_id=project_id,
            project_path=project_path_str,
            role=role,
            parent_id=parent_id,
            dispatch_prompt=dispatch_prompt,
            worktree_path=worktree_path,
            worktree_branch=worktree_branch,
            base_branch=base_branch,
            worktree_seed_status=worktree_seed_status,
        )

    if _created_worktree is not None:
        schedule_seed_task(
            session_id=session_id,
            project_path=Path(project_path_str),
            worktree_path=_created_worktree,
        )

    return session_obj
