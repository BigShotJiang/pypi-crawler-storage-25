from fastapi import APIRouter, HTTPException
from sqlalchemy import select, delete as sa_delete, func

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession, DBMessage, DBProject, DBSessionSkill, DBSessionWorkflow
from hypergolic.db.utils import to_iso_utc
from hypergolic.toolkit.primitives import Workflow
from hypergolic.messages.content_blocks import serialize_content_blocks
from hypergolic.prompts.builder import build_prompt_blocks
from hypergolic.schemas import Session
from hypergolic.sessions.operations import create_session, delete_session_tree, load_session
from hypergolic.sessions.schemas import (
    ActiveSkillSummary,
    CreateSessionRequest,
    MessageResponse,
    PromptPartInfo,
    RoleInfo,
    SessionContextResponse,
    SessionResponse,
    SessionSearchRequest,
    SessionSearchResponse,
    SkillInfo,
    SkillsSummary,
    ToolInfo,
)
from hypergolic.sessions.search import search_sessions
from hypergolic.sessions.transformers import (
    build_skill_infos,
    build_tool_info,
    session_response,
)
from hypergolic.skills.resolver import resolve_roles, resolve_session_skills, resolve_skills
from hypergolic.mcptools.sessions import get_enabled_servers
from hypergolic.tools.tool_list import build_tools, build_tools_with_reasons
from hypergolic.workflows.resolver import get_session_workflow, get_workflow, resolve_workflows
from hypergolic.workflows.schemas import WorkflowDetailResponse, WorkflowSkillDetail, WorkflowStateDetail, WorkflowToolDetail, WorkflowOutputSchemaDetail

router = APIRouter(prefix="/api/sessions", tags=["sessions"])


@router.get("", response_model=list[SessionResponse])
def list_sessions(project_id: str | None = None):
    with get_db() as db:
        msg_count_subq = (
            select(
                DBMessage.session_id,
                func.count(DBMessage.id).label("msg_count"),
            )
            .group_by(DBMessage.session_id)
            .subquery()
        )
        active_wf_subq = (
            select(
                DBSessionWorkflow.session_id,
                DBSessionWorkflow.workflow_id,
                DBSessionWorkflow.current_state_id,
            )
            .where(DBSessionWorkflow.deleted_at.is_(None))
            .subquery()
        )
        stmt = (
            select(
                DBSession,
                DBProject.name,
                msg_count_subq.c.msg_count,
                active_wf_subq.c.workflow_id,
                active_wf_subq.c.current_state_id,
            )
            .join(DBProject, DBSession.project_id == DBProject.id)
            .outerjoin(msg_count_subq, DBSession.id == msg_count_subq.c.session_id)
            .outerjoin(active_wf_subq, DBSession.id == active_wf_subq.c.session_id)
            .order_by(
                (func.coalesce(msg_count_subq.c.msg_count, 0) == 0).desc(),
                DBSession.updated_at.desc(),
            )
        )
        if project_id:
            stmt = stmt.where(DBSession.project_id == project_id)
        rows = db.execute(stmt).all()

    wf_configs: dict[str, Workflow | None] = {}
    results: list[SessionResponse] = []
    for session, project_name, msg_count, wf_id, wf_state_id in rows:
        workflow_name = None
        workflow_state_name = None
        if wf_id:
            if wf_id not in wf_configs:
                wf_configs[wf_id] = get_workflow(wf_id)
            wf = wf_configs[wf_id]
            if wf:
                workflow_name = wf.name
                for s in wf.states:
                    if s.id == wf_state_id:
                        workflow_state_name = s.name
                        break
        results.append(
            session_response(
                session, project_name, msg_count or 0,
                workflow_id=wf_id,
                workflow_state_id=wf_state_id,
                workflow_name=workflow_name,
                workflow_state_name=workflow_state_name,
            )
        )
    return results


@router.post("", response_model=SessionResponse)
def create_session_endpoint(req: CreateSessionRequest):
    session = create_session(
        project_id=req.project_id,
        model_tier=req.model_tier,
        role=req.role,
        worktree=req.worktree,
    )
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.name)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == session.id)
        ).one()
        session_row, proj_name = row
        wf_state = get_session_workflow(session_row.id)
        wf_id = wf_state[0] if wf_state else None
        wf_state_id = wf_state[1] if wf_state else None
        wf_name = None
        wf_state_name = None
        if wf_state and wf_id:
            wf = get_workflow(wf_id)
            if wf:
                wf_name = wf.name
                for s in wf.states:
                    if s.id == wf_state_id:
                        wf_state_name = s.name
                        break
        return session_response(
            session_row, proj_name,
            workflow_id=wf_id,
            workflow_state_id=wf_state_id,
            workflow_name=wf_name,
            workflow_state_name=wf_state_name,
        )


@router.get("/roles", response_model=list[RoleInfo])
def list_roles(project_id: str | None = None):
    roles = resolve_roles()
    return [RoleInfo(id=r["id"], name=r["name"], source=r["source"]) for r in roles]


@router.post("/search", response_model=SessionSearchResponse)
def search_sessions_endpoint(req: SessionSearchRequest):
    matches = search_sessions(req.query, req.project_id, req.max_results)
    return SessionSearchResponse(matches=matches)


@router.delete("/{session_id}")
def delete_session_endpoint(session_id: str):
    delete_session_tree(session_id)
    return {"status": "deleted"}


def _build_tool_display_names(session_id: str) -> dict[str, str]:
    try:
        session = load_session(session_id)
        tools = build_tools(session=session)
        return {t.id: t.name for t in tools}
    except Exception:
        return {}


@router.get("/{session_id}/messages", response_model=list[MessageResponse])
def get_session_messages(session_id: str):
    tool_display_names = _build_tool_display_names(session_id)

    with get_db() as db:
        rows = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .order_by(DBMessage.created_at)
        ).scalars().all()
        return [
            MessageResponse(
                id=r.id,
                session_id=r.session_id,
                role=r.role,
                content=serialize_content_blocks(r.content, tool_display_names),
                model=r.model,
                stop_reason=r.stop_reason,
                usage=r.usage,
                truncated=r.truncated,
                created_at=to_iso_utc(r.created_at),
            )
            for r in rows
        ]


def _build_session_context(session: Session) -> SessionContextResponse:
    from hypergolic.tools.handlers import find_toolkit_tool

    tools_with_reasons = build_tools_with_reasons(session=session)

    tool_infos: list[ToolInfo] = []
    for t, reason in tools_with_reasons:
        toolkit_tool = find_toolkit_tool(t.id, session)
        tool_infos.append(build_tool_info(t, reason, toolkit_tool))

    with get_db() as db:
        active_skill_ids = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session.id)
            ).scalars().all()
        )

    all_skills = resolve_session_skills(session)

    mcp_enabled = list(get_enabled_servers(session.id))

    blocks = build_prompt_blocks(session)
    prompt_tokens = sum(len(b.text) // 4 for b in blocks)

    active_skill_list = [
        ActiveSkillSummary(id=s["id"], name=s["name"])
        for s in all_skills
        if s["id"] in active_skill_ids
    ]

    return SessionContextResponse(
        tools=tool_infos,
        tools_count=len(tool_infos),
        skills_summary=SkillsSummary(
            total=len(all_skills),
            active=len(active_skill_list),
            active_skills=active_skill_list,
        ),
        mcp_enabled=mcp_enabled,
        prompt_token_estimate=prompt_tokens,
    )


@router.get("/{session_id}/context", response_model=SessionContextResponse)
def get_session_context(session_id: str):
    session = load_session(session_id)
    return _build_session_context(session)


@router.get("/{session_id}/prompt", response_model=list[PromptPartInfo])
def get_session_prompt(session_id: str):
    session = load_session(session_id)

    blocks = build_prompt_blocks(session)

    return [
        PromptPartInfo(
            source=block.source,
            content=block.text,
            token_estimate=len(block.text) // 4,
        )
        for block in blocks
    ]


@router.post("/{session_id}/skills/{skill_id}/activate")
def activate_skill(session_id: str, skill_id: str):
    all_skills = {s["id"]: s for s in resolve_skills()}
    if skill_id not in all_skills:
        raise HTTPException(status_code=404, detail=f"Skill '{skill_id}' not found")

    with get_db() as db:
        already = db.execute(
            select(DBSessionSkill)
            .where(DBSessionSkill.session_id == session_id)
            .where(DBSessionSkill.skill_id == skill_id)
        ).scalar_one_or_none()
        if not already:
            db.add(DBSessionSkill(session_id=session_id, skill_id=skill_id))

    return {"status": "activated"}


@router.post("/{session_id}/skills/{skill_id}/deactivate")
def deactivate_skill(session_id: str, skill_id: str):
    with get_db() as db:
        db.execute(
            sa_delete(DBSessionSkill)
            .where(DBSessionSkill.session_id == session_id)
            .where(DBSessionSkill.skill_id == skill_id)
        )
    return {"status": "deactivated"}


@router.get("/{session_id}/workflows", response_model=list[WorkflowDetailResponse])
def get_session_workflows(session_id: str):
    workflows = resolve_workflows()
    return [
        WorkflowDetailResponse(
            id=wf.id,
            name=wf.name,
            description=wf.description or "",
            prompt_path=wf.prompt_path,
            initial_state=wf.initial_state,
            states=[
                WorkflowStateDetail(
                    id=s.id,
                    name=s.name,
                    prompt_path=s.prompt_path,
                    skills=[WorkflowSkillDetail(id=sk.id, name=sk.name) for sk in s.skills],
                    tools=[
                        WorkflowToolDetail(id=t.id, name=t.name, description=t.description)
                        for t in s.tools
                    ],
                    truncate_on_entry=s.truncate_on_entry,
                    include_artifacts=s.include_artifacts,
                    output_schemas=[
                        WorkflowOutputSchemaDetail(
                            outcome=o.outcome,
                            next_state=o.next_state,
                            artifact_id=o.artifact_id,
                            requires_approval=o.requires_approval,
                            has_approval_view=o.approval_view is not None,
                            schema_def=o.schema_def,
                        )
                        for o in s.output_schemas
                    ],
                )
                for s in wf.states
            ],
        )
        for wf in workflows
    ]


@router.get("/{session_id}/skills", response_model=list[SkillInfo])
def get_session_skills(session_id: str):
    session = load_session(session_id)

    with get_db() as db:
        active_skill_ids = set(
            db.execute(
                select(DBSessionSkill.skill_id)
                .where(DBSessionSkill.session_id == session_id)
            ).scalars().all()
        )

    all_skills = resolve_session_skills(session)
    return build_skill_infos(all_skills, active_skill_ids)
