from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.enums import SessionStatus
from hypergolic.messages.types import BroadcastEvent, BroadcastFn


TERMINAL_STATUSES = frozenset({SessionStatus.CONCLUDED, SessionStatus.INTERRUPTED})


def get_session_status(session_id: str) -> SessionStatus:
    with get_db() as db:
        row = db.execute(
            select(DBSession.status).where(DBSession.id == session_id)
        ).scalar_one()
    return SessionStatus(row)


async def finalize_turn(session_id: str, broadcast: BroadcastFn) -> None:
    current = get_session_status(session_id)
    if current not in TERMINAL_STATUSES:
        await set_session_status_and_broadcast(session_id, SessionStatus.IDLE, broadcast)


def set_session_status(session_id: str, status: SessionStatus) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(status=status)
        )


async def set_session_status_and_broadcast(
    session_id: str,
    status: SessionStatus,
    broadcast: BroadcastFn,
) -> None:
    set_session_status(session_id, status)
    await broadcast(
        BroadcastEvent(
            type="session_status_change",
            role="system",
            content=[{"status": status.value}],
            session_id=session_id,
        )
    )
