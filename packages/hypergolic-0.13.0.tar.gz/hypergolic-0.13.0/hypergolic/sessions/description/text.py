from typing import cast

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage

PREVIEW_MAX_CHARS = 2000


def extract_text(content: object) -> str:
    """Extract plain text from a message content field."""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        parts: list[str] = []
        for block in content:
            if isinstance(block, dict):
                typed_block = cast(dict[str, object], block)
                if typed_block.get("type") == "text":
                    text = typed_block.get("text", "")
                    if isinstance(text, str):
                        parts.append(text)
        return "".join(parts)
    return ""


def _user_content_rows(session_id: str, ordered: bool = False):
    with get_db() as db:
        stmt = (
            select(DBMessage.content)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.role == "user")
            .where(DBMessage.truncated == False)  # noqa: E712
        )
        if ordered:
            stmt = stmt.order_by(DBMessage.created_at)
        return db.execute(stmt).scalars().all()


def count_user_text_chars(session_id: str) -> int:
    return sum(len(extract_text(c)) for c in _user_content_rows(session_id))


def get_user_text_preview(session_id: str) -> str:
    parts = [extract_text(c) for c in _user_content_rows(session_id, ordered=True)]
    return "\n".join(p for p in parts if p)[:PREVIEW_MAX_CHARS]
