from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession


def get_session_description(session_id: str) -> str | None:
    with get_db() as db:
        return db.execute(
            select(DBSession.description).where(DBSession.id == session_id)
        ).scalar_one()


def save_description(session_id: str, description: str) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession).where(DBSession.id == session_id)
            .values(description=description)
        )
