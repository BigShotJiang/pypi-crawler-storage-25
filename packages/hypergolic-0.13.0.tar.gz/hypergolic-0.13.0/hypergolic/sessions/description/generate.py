import asyncio
import logging

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.providers import generate_text
from hypergolic.sessions.description.store import get_session_description, save_description
from hypergolic.sessions.description.text import count_user_text_chars, get_user_text_preview

logger = logging.getLogger(__name__)
DESCRIPTION_CHAR_THRESHOLD = 100
DESCRIPTION_MAX_TOKENS = 100

# Suffix appended to dispatch prompts that should be stripped for description input
_CONCLUDE_MARKER = "\n\nCRITICAL: You MUST call"

_DESCRIPTION_PROMPT = (
    "<session_messages>\n"
    "{preview}\n"
    "</session_messages>\n\n"
    "Write a short label (under 35 characters) describing what this session is about. "
    "Respond with only the label.\n\n"
    "Examples:\n"
    "- Fix list pagination\n"
    "- Add dark mode toggle\n"
    "- Refactor auth middleware"
)


def _get_dispatch_prompt(session_id: str) -> str | None:
    with get_db() as db:
        row = db.execute(
            select(DBSession.dispatch_prompt, DBSession.parent_id)
            .where(DBSession.id == session_id)
        ).one()
    if not row.parent_id or not row.dispatch_prompt:
        return None
    prompt = row.dispatch_prompt
    marker_pos = prompt.find(_CONCLUDE_MARKER)
    if marker_pos > 0:
        prompt = prompt[:marker_pos]
    return prompt.strip() or None


def _build_description_input(session_id: str) -> str | None:
    dispatch = _get_dispatch_prompt(session_id)
    if dispatch:
        return dispatch
    return get_user_text_preview(session_id) or None


async def _generate_description(session_id: str, broadcast: BroadcastFn) -> None:
    try:
        preview = _build_description_input(session_id)
        if not preview or not preview.strip():
            return
        description = await generate_text(
            system="",
            messages=[{"role": "user", "content": _DESCRIPTION_PROMPT.format(preview=preview)}],
            max_tokens=DESCRIPTION_MAX_TOKENS,
        )
        if not description:
            return
        description = description.strip().lstrip('"\'‘“-*# ').rstrip('"\'’”.# ')
        if not description:
            return
        save_description(session_id, description)
        await broadcast(BroadcastEvent(
            type="session_description_update", role="system",
            content=[{"description": description}], session_id=session_id,
        ))
    except Exception:
        logger.exception("Failed to generate description for %s", session_id)


def maybe_generate_description(session_id: str, broadcast: BroadcastFn) -> None:
    if get_session_description(session_id) is not None:
        return
    if not _get_dispatch_prompt(session_id):
        if count_user_text_chars(session_id) < DESCRIPTION_CHAR_THRESHOLD:
            return
    asyncio.create_task(_generate_description(session_id, broadcast))
