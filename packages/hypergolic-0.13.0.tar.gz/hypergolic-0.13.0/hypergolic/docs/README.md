# Hypergolic

A framework for toolkit engineering.

Hypergolic makes it easy to build your own AI coding assistant, tailored to how you work. It gives you:

- **Building blocks** for configuring how your agent operates — prompts, tools, skills, roles, and workflows, all defined in Python
- **An ergonomic UI** for working with your agents — session management, tool approval, knowledge graph, and more
- **A complete starter template** that bootstraps a working assistant in minutes

## Key Features

- **Tool loop** — File operations, shell, git, browser automation, and more, with configurable approval policies.
- **Persistent knowledge graph** — Accumulates corrections, preferences, and project context across sessions.
- **Session continuity** — Conversations persist and are resumable. Run multiple sessions in parallel.
- **Skills and roles** — Activate specialized expertise (debugging, frontend, product thinking, etc.) on demand.
- **Workflows** — Multi-phase state machines with structured handoffs and artifact passing.
- **MCP integration** — Connect external tool servers via Model Context Protocol.
- **Custom tools** — Define tools as Python functions with typed inputs, structured outputs, and approval policies.

## Quick Start

```bash
# Install uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh

# Optional: install ripgrep for faster file search
brew install ripgrep

# Install Hypergolic
uv tool install hypergolic

# Save your API credentials to your shell profile (~/.zshrc, ~/.bashrc, etc.)
# HYPERGOLIC_API_KEY="your-api-key"
# HYPERGOLIC_BASE_URL="https://api.anthropic.com"

# Initialize your assistant
hypergolic init

# Launch
h
```

See the [Installation Guide](installation.md) for full details.

## Documentation

- [Installation](installation.md)
- [Getting Started](getting-started.md)
- [Conversing with Your Assistant](conversing.md)
- [Configuration](configuration.md)
- [Tools](tools.md)
- [Advanced Usage](advanced-usage.md)
- [Workflows](workflows.md)
- [Workflow Reference](workflow-reference.md)

## Why "Hypergolic"?

In chemistry, hypergolic propellants are two distinct compounds that ignite on impact. Their most common application is as rocket fuel, where hydrazine and dinitrogen tetroxide ignite upon touching. Used carelessly, they're hazardously toxic and explosive. Used right, they help us reach the stars. Those same opportunities and risks exist within modern agentic tools.

In several domains, human <> ML collaboration is more effective than either acting alone. One famous example is "Centaur Chess" where a human using a moderately-powerful AI can outperform advanced AI models. Whether or not this remains true in the future, I think the metaphor holds for agentic coding. Humans benefit from the velocity, depth, and breadth LLMs bring to the table. At the same time, human review and ideation can bring judgment and rigor to technical outcomes beyond purely vibe-coded approaches. In a way, humans and AI agents are hypergolic.

Hypergolic strives to help humans and agents get the most out of their work. The two-sided UX encourages seamless agent<>human interaction. The project's approach towards transparent configuration and sensible defaults lets both entities refine their tooling. And an extensible, shared approach means that both the agent and the human become more knowledgeable and productive over time.
