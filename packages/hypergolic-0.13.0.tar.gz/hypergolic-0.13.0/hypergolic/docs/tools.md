# Tools

Hypergolic gives the assistant access to a set of tools it can invoke during conversation. The assistant decides which tools to use based on the task.

## Built-in Tools

| Tool | Description | Requires Approval |
|------|-------------|-------------------|
| `read_files` | Read contents of one or more files | No |
| `write_files` | Create or overwrite files | Yes |
| `edit_files` | Find-and-replace exact strings in files | Yes |
| `rm` | Delete files or directories (recursive) | Yes |
| `mv` | Move or rename files or directories within the project | Yes |
| `ls` | List directory contents with glob filtering | No |
| `search_files` | Ripgrep-powered search across files (regex or literal) | No |
| `make_directory` | Create directories | No |
| `command` | Execute a shell command | Yes |
| `git` | Git operations (status, diff, log, show, branch, checkout, etc.) | Read-only: No; Mutating: Yes |
| `browser` | Control a headless Chrome browser via [rodney](https://github.com/nichochar/rodney) | Varies |
| `knowledge` | Create, search, delete, tag, and link knowledge graph items | No |
| `history` | Read-only SQL over past sessions, messages, and related tables | No |
| `skills` | Activate a specialized skill for the session | No |
| `manage_mcp` | List, enable, or disable MCP servers | No |

`ls` and `search_files` shorten paths in their results: paths under the
project root are returned project-relative, paths under `$HOME` use `~/…`,
anything else stays absolute.

## How Tool Approval Works

Tools that modify your filesystem or execute arbitrary commands require explicit approval. When the assistant wants to use one, you'll see an approval prompt with the full details of what it wants to do.

You can:
- **Approve** (`Y`) — Let the tool run
- **Deny** (`N`) — Block the tool silently
- **Deny with message** (`D`) — Block and explain why
- **Configure** (`C`) — Open a toolkit session to configure an approval policy for this tool

### Configuring Approval Policies

Approval behavior is defined in Python when you register a tool. Each tool's `approval` field can be a string shortcut (`"ALLOW"`, `"DENY"`, `"REQUIRE_APPROVAL"`) or a callable that decides dynamically based on the input:

```python
from hypergolic import Tool, ToolApprovalDecision, ApprovalContext

def git_approval(ctx: ApprovalContext):
    read_only = ["status", "diff", "log", "show", "branch"]
    if any(ctx.input.args.startswith(cmd) for cmd in read_only):
        return ToolApprovalDecision(decision="ALLOW")
    return ToolApprovalDecision(decision="REQUIRE_APPROVAL")

git_tool = Tool(
    id="git",
    name="Git",
    description="Run git commands",
    input_schema=GitInput,
    run=run_git,
    approval=git_approval,
)
```

To change how approval works for a tool, either edit the tool registration in `~/.hypergolic/main.py` directly, or press `C` during an approval prompt to open a toolkit engineering session.

## Custom Tools

You can define your own tools as Python functions with typed inputs, structured outputs, and approval policies. See [Advanced Usage](advanced-usage.md#custom-tools) for the full pattern.

## MCP Tools

Tools from connected MCP servers appear alongside built-in tools. See [Advanced Usage](advanced-usage.md#mcp-servers).

## Tool Scoping

Tool availability depends on where a tool is registered:

| Registered on | Available when |
|---------------|----------------|
| `app` | All sessions, always |
| `project` | Only in that project's sessions |
| `skill.tools` | Only when that skill is active |
| `role.tools` | Only when that role is active |
| `workflow_state.tools` | Only during that workflow state |

At runtime, available tools = global + project + role + active skills + workflow state.
