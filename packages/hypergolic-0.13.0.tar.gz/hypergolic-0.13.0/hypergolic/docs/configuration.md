# Configuration

Hypergolic is configured through a Python-based toolkit that lives at `~/.hypergolic/`. Your toolkit defines everything: tools, skills, roles, workflows, projects, and prompts.

## File Locations

| Path | Purpose |
|------|---------|
| `~/.hypergolic/main.py` | Your toolkit entry point — registers all tools, skills, roles, workflows, and projects |
| `~/.hypergolic/base/` | Default tools, prompts, and registries (managed by `hypergolic update`) |
| `~/.hypergolic/base/prompts/roles/*.md` | Role prompts (e.g., generalist, reviewer) |
| `~/.hypergolic/base/prompts/skills/*.md` | Skill prompts (e.g., toolkit engineering, product management) |
| `~/.hypergolic/prompts/` | Your custom prompts |
| `~/.hypergolic/projects/<id>/PROMPT.md` | Per-project prompts |
| `~/.hypergolic/pyproject.toml` | Python dependencies (managed by uv) |
| `~/.hypergolic/hypergolic.db` | SQLite database |

**`base/`** is managed by the framework. `hypergolic update` regenerates everything in it. Put your customizations anywhere else.

## The Toolkit (`main.py`)

Your toolkit is a Python script that creates an `App` instance and registers your configuration:

```python
from hypergolic import App, Project
from base.tools.registry import UNIVERSAL_TOOLS
from base.roles.registry import ALL_BASE_ROLES
from base.skills.registry import ALL_BASE_SKILLS

app = App()

# Register standard tools, roles, and skills
app.register_tools(UNIVERSAL_TOOLS)
app.register_roles(ALL_BASE_ROLES)
app.register_skills(ALL_BASE_SKILLS)

# Register your projects
project = Project(
    id="my-app",
    name="My App",
    description="A web application",
    git_root="/Users/me/code/my-app",
    prompt_path="~/.hypergolic/projects/my-app/PROMPT.md",
)
app.register_project(project)

if __name__ == "__main__":
    app()
```

When you run `h`, this script validates all registrations, runs database migrations, starts a FastAPI server, and opens the desktop UI.

## Projects

A project is a git repository the agent can work in. Register projects on the `App` to make them available in the UI:

```python
project = Project(
    id="my-app",
    name="My App",
    description="A web application",
    git_root="/Users/me/code/my-app",
    prompt_path="~/.hypergolic/projects/my-app/PROMPT.md",
)
app.register_project(project)
```

Tools, skills, and workflows registered on a project are only available in that project's sessions. Register on `app` for global availability.

## System Prompt Assembly

The system prompt is assembled from multiple sources, concatenated in order:

1. **Role prompt** — The active role's prompt file (e.g., `~/.hypergolic/base/prompts/roles/generalist.md`)
2. **User prompt** — Your personal prompt, if configured
3. **Project prompt** — Per-project guidance from `projects/<id>/PROMPT.md`
4. **Session context** — Auto-generated: session ID, working directory, OS, git branch
5. **Active skills** — Prompt content from any skills activated during the session
6. **Workflow context** — Workflow and state prompts, if a workflow is active

Each layer adds specificity. The role sets baseline behavior, user and project prompts add preferences and conventions, and skills inject domain expertise on demand.

### Prompt Sources

Prompts can be provided in three mutually exclusive ways (on any object that accepts them):

```python
# From a file
Role(id="reviewer", name="Reviewer", prompt_path="~/.hypergolic/prompts/roles/reviewer.md")

# Inline
Role(id="reviewer", name="Reviewer", prompt="You are a code reviewer. Focus on...")

# Dynamic (computed at runtime)
Role(id="reviewer", name="Reviewer", prompt_fn=lambda: generate_prompt())
```

### Example Role Prompt (`~/.hypergolic/base/prompts/roles/generalist.md`)

```markdown
You are a generalist coding assistant.

Communicate concisely.
Research before beginning a task.
Fix pre-existing errors or failures.
```

### Example Project Prompt (`~/.hypergolic/projects/my-app/PROMPT.md`)

```markdown
# My App

This is a Django 5.1 project using PostgreSQL.
Run `./bin/validate` after making changes to verify the build.
Never modify files in the `generated/` directory.
```

## App Options

The `App` constructor accepts a few top-level settings:

```python
from hypergolic import App, ModelTier

app = App(
    db_path="~/.hypergolic/hypergolic.db",       # SQLite database location
    truncate_token_threshold=200_000,              # Token limit before context truncation
    default_model_tier=ModelTier.HIGH,             # Default model tier for sessions
)
```

## Viewing Config

From the UI, use the **Config** panel in the left sidebar (`⌘/Ctrl + 6`) to see your current configuration, including registered tools, skills, roles, and projects.
