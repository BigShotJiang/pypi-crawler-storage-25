# Installation

## Requirements

- **Python 3.14+**
- **macOS** (primary support; Linux may work but is untested)
- [uv](https://docs.astral.sh/uv/) — fast Python package manager and tool installer
- [ripgrep](https://github.com/BurntSushi/ripgrep) (`rg`) — *optional*, speeds up `search_files` (a Python fallback is used when not installed)

## Install Dependencies

```bash
# uv (Python package manager)
curl -LsSf https://astral.sh/uv/install.sh | sh

# ripgrep (optional, for faster file search)
brew install ripgrep
```

## Install Hypergolic

```bash
uv tool install hypergolic
```

## Set Environment Variables

Hypergolic needs an API key and base URL. Add these to your shell profile (`~/.zshrc`, `~/.bashrc`, etc.) so they persist across sessions:

```bash
export HYPERGOLIC_API_KEY="your-api-key"
export HYPERGOLIC_BASE_URL="https://api.anthropic.com"
```

You can get an API key at [console.anthropic.com](https://console.anthropic.com/).

## Initialize Your Assistant

```bash
hypergolic init
```

This creates `~/.hypergolic/` with a complete default configuration: standard tools (file operations, git, browser, search, knowledge graph), prompts, skills, roles, and workflows. It also sets up a `uv` virtual environment and adds a shell alias so you can launch with `h`.

Restart your shell (or run the `source` command printed by init).

## Verify Installation

```bash
h
```

This launches the assistant, running database migrations, starting the local server, and opening the desktop window.

## Updating

```bash
uv tool install --upgrade hypergolic
hypergolic update
```

The first command updates the `hypergolic` package. The second regenerates `~/.hypergolic/base/` with any new or improved default tools and prompts. Your files outside `base/` are never touched.

## Development Installation

To work on Hypergolic itself:

```bash
git clone https://github.com/RTownley/hypergolic.git
cd hypergolic
uv sync
```

Run in dev mode (rebuilds UI from source on each launch):

```bash
HYPERGOLIC_DEV_MODE=true uv run hypergolic-dev
```
