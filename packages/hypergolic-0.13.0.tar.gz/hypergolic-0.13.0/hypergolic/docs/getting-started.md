# Getting Started

## Launch

`cd` into a git repository and run:

```bash
h
```

This runs database migrations, seeds default knowledge tags, detects the current git project, starts the local server on port 54321, and opens the native desktop window.

## The Interface

Hypergolic is a two-panel layout:

- **Left sidebar** — Tabbed panels for Source Control, File Explorer, Knowledge Graph, Projects, Help, Config, and Analytics.
- **Main area** — The chat conversation. Messages stream in real time, including tool calls and their results.

## Your First Conversation: Onboarding

When you launch Hypergolic for the first time, you'll land in the **My Toolkit** project with no other projects configured. The assistant detects this and starts an **onboarding conversation** — a guided setup that configures your toolkit through natural dialogue.

The onboarding agent will:

1. **Ask about you** — what you do, what kind of work you're focused on, and how you like to work with an AI assistant.
2. **Walk through your projects one at a time** — for each codebase, it asks where it lives, explores the repo with its tools to understand the stack and structure, and sets up the project configuration.
3. **Configure as it goes** — it creates project prompts, registers projects in your `main.py`, and builds any custom tools your projects need.
4. **Summarize what it built** — at the end, it shows you the directory structure it created under `~/.hypergolic/` and suggests next steps.

Onboarding typically takes 5–10 minutes. Answer its questions naturally — it asks one thing at a time and follows up to go deeper before moving on.

Once onboarding is complete, start a new session (`⌘/Ctrl + N`) and select one of your newly configured projects. From there, you're working with a fully personalized assistant.

> **Tip:** You can return to the **My Toolkit** project anytime to refine your setup — add projects, tweak prompts, build new tools, or adjust approval policies.

## Tool Approval

When the assistant wants to execute a potentially dangerous operation (shell commands, file writes), an approval prompt appears with keyboard shortcuts:

| Key | Action |
|-----|--------|
| `Y` | Approve |
| `N` | Deny |
| `D` | Deny with a message |
| `C` | Open a toolkit session to configure approval policy |

Approval policies are defined in your toolkit's Python code (`~/.hypergolic/main.py`). Press `C` to open a toolkit engineering session where you can configure tool approval behavior.

## Keyboard Shortcuts

| Shortcut | Action |
|----------|--------|
| `⌘/Ctrl + 1` | Source Control panel |
| `⌘/Ctrl + 2` | File Explorer panel |
| `⌘/Ctrl + 3` | Knowledge Graph panel |
| `⌘/Ctrl + 4` | Projects panel |
| `⌘/Ctrl + 5` | Help panel |
| `⌘/Ctrl + 6` | Config panel |
| `⌘/Ctrl + 7` | Analytics panel |
| `⌘/Ctrl + 9` | Sessions panel |
| `⌘/Ctrl + /` | Focus chat input |
| `⌘/Ctrl + N` | New session |
| `⌘/Ctrl + J` | Jump to next session needing attention |
| `⌘/Ctrl + Enter` | Conclude current session |
| `⌘/Ctrl + P` | File finder |

## File Attachments

Drag files or images into the chat input. The assistant can read images (screenshots, diagrams, error messages) and use them as context.

## Sessions

Conversations are persistent. Each session has its own context and history. Previous sessions are listed in the right sidebar and can be resumed.

### Creating Sessions

Use `⌘/Ctrl + N` to start a fresh session. Each session is tied to the current project and runs independently — you can have multiple sessions active at the same time.

### Jumping Between Sessions (`⌘/Ctrl + J`)

When you're running multiple sessions in parallel, `⌘/Ctrl + J` jumps to the session that most needs your attention. Sessions are prioritized by urgency:

1. **Awaiting approval** — a tool needs your yes/no to proceed
2. **Idle / Interrupted** — waiting for your input
3. **Error** — something went wrong and needs attention
4. **Running** (thinking, streaming, tool use) — working fine, doesn't need you yet
5. **Concluded** — done

Within each tier, the most recently updated session wins. This lets you kick off work in several sessions, then use `⌘/Ctrl + J` to cycle through them as they surface questions or finish.

### Concluding Sessions (`⌘/Ctrl + Enter`)

When a task is complete, press `⌘/Ctrl + Enter` to conclude the session. A modal appears where you can:

- **Rate** the session (1–5)
- **Leave feedback** — optional notes on what went well or poorly

After you submit, the session is marked as concluded and auto-navigates you to the next active session so you can keep moving through parallel work.

The assistant can also conclude sessions on its own using the `conclude` tool when it finishes a dispatched task.

### Session Lifecycle

| Status | Meaning |
|--------|--------|
| **Idle** | Waiting for user input |
| **Thinking / Streaming** | Assistant is generating a response |
| **Tool Use** | Assistant is executing a tool |
| **Awaiting Approval** | A tool needs your approval to proceed |
| **Error** | Something went wrong |
| **Concluded** | Session is finished |
| **Interrupted** | Session was cancelled mid-turn |

## Next Steps

- [Conversing with Your Assistant](conversing.md) — Practical techniques for effective sessions
- [Configuration](configuration.md) — Set up your toolkit, prompts, and projects
- [Tools](tools.md) — Understand what the assistant can do
- [Advanced Usage](advanced-usage.md) — Custom tools, MCP servers, skills, and roles
