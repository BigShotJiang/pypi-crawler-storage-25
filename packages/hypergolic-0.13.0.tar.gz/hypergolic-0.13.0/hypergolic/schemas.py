from pathlib import Path
from typing import Literal

from pydantic import BaseModel

from hypergolic.enums import ModelTier


WorktreeSeedStatus = Literal["pending", "seeding", "ready", "failed"]


class SessionMessage(BaseModel):
    id: str
    session_id: str


class Session(BaseModel):
    id: str
    model_tier: ModelTier
    project_id: str
    project_path: str
    role: str = "generalist"
    parent_id: str | None = None
    dispatch_prompt: str | None = None
    active_skill_ids: set[str] = set()
    worktree_path: str | None = None
    worktree_branch: str | None = None
    base_branch: str | None = None
    worktree_seed_status: WorktreeSeedStatus | None = None

    def working_directory(self) -> Path:
        if self.worktree_path:
            return Path(self.worktree_path)
        return Path(self.project_path)
