"""Short, sortable, alphanumeric IDs.

Generates 12-character IDs using Crockford Base32 (`0-9A-Z` minus I, L, O, U).
Layout: 42 bits of millisecond timestamp (good through ~year 2109) followed by
18 bits of randomness. Total 60 bits = 12 base32 chars.

Lexicographic order matches chronological order, giving UUIDv7-like sortability
in one third of the characters. 18 random bits per millisecond puts the
birthday-collision bound at ~640 IDs within a single ms, which is well beyond
any realistic per-ms insert rate for this app.
"""
from __future__ import annotations

import secrets
import time

# Crockford Base32 alphabet: 0-9 then A-Z excluding I, L, O, U.
# Sorts lexicographically in the same order as numerically.
_ALPHABET = "0123456789ABCDEFGHJKMNPQRSTVWXYZ"

ID_LENGTH = 12
_TIMESTAMP_BITS = 42
_RANDOM_BITS = ID_LENGTH * 5 - _TIMESTAMP_BITS  # 18
_RANDOM_MAX = 1 << _RANDOM_BITS
_TIMESTAMP_MAX = 1 << _TIMESTAMP_BITS


def _encode(value: int, length: int) -> str:
    chars = ["0"] * length
    for i in range(length - 1, -1, -1):
        chars[i] = _ALPHABET[value & 0x1F]
        value >>= 5
    return "".join(chars)


def new_id(now_ms: int | None = None) -> str:
    """Return a new 12-char Crockford Base32 sortable ID.

    `now_ms` lets tests inject a deterministic timestamp.
    """
    ts = time.time_ns() // 1_000_000 if now_ms is None else now_ms
    ts &= _TIMESTAMP_MAX - 1  # defensive; real timestamps won't exceed 42 bits until ~2109
    rand = secrets.randbelow(_RANDOM_MAX)
    combined = (ts << _RANDOM_BITS) | rand
    return _encode(combined, ID_LENGTH)


def is_valid_id(value: str) -> bool:
    """True if `value` is shaped like an ID produced by `new_id`."""
    if len(value) != ID_LENGTH:
        return False
    return all(c in _ALPHABET for c in value)
