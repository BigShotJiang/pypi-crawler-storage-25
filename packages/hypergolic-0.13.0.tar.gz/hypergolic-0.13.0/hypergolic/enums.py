from enum import Enum


class ModelTier(str, Enum):
    LOW = "Low"
    MEDIUM = "Medium"
    HIGH = "High"


class SessionStatus(str, Enum):
    IDLE = "idle"
    THINKING = "thinking"
    STREAMING = "streaming"
    TOOL_USE = "tool_use"
    TRUNCATING = "truncating"
    AWAITING_APPROVAL = "awaiting_approval"
    ERROR = "error"
    CONCLUDED = "concluded"
    INTERRUPTED = "interrupted"


class WorkflowOutcome(str, Enum):
    SUCCESS = "success"
    FAILURE = "failure"
    SUPPRESSED = "suppressed"
