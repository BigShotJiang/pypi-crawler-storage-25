from pydantic import BaseModel


class AnalyticsSummary(BaseModel):
    total_sessions: int
    total_messages: int
    total_cost: float
    total_input_tokens: int
    total_output_tokens: int
    total_cache_write_tokens: int
    total_cache_read_tokens: int


class TimeseriesPoint(BaseModel):
    period: str
    sessions: int
    messages: int
    cost: float
    input_tokens: int
    output_tokens: int
    cache_write_tokens: int
    cache_read_tokens: int


class ToolCount(BaseModel):
    tool_name: str
    count: int
