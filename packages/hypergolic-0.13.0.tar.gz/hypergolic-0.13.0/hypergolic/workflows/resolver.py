import logging

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionWorkflow
from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.primitives import Workflow

logger = logging.getLogger(__name__)


def resolve_workflows() -> list[Workflow]:
    app = get_app()
    workflows: list[Workflow] = []
    seen_ids: set[str] = set()

    for wf in app.workflows:
        if wf.id not in seen_ids:
            workflows.append(wf)
            seen_ids.add(wf.id)

    for project in app.projects:
        for wf in project.workflows:
            if wf.id not in seen_ids:
                workflows.append(wf)
                seen_ids.add(wf.id)

    return workflows


def get_workflow(workflow_id: str) -> Workflow | None:
    for wf in resolve_workflows():
        if wf.id == workflow_id:
            return wf
    return None


def get_session_workflow(session_id: str) -> tuple[str, str] | None:
    with get_db() as db:
        row = db.execute(
            select(DBSessionWorkflow)
            .where(DBSessionWorkflow.session_id == session_id)
            .where(DBSessionWorkflow.deleted_at.is_(None))
        ).scalar_one_or_none()
        if row is None:
            return None
        return (row.workflow_id, row.current_state_id)
