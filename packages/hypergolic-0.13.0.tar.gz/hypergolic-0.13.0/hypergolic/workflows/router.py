from fastapi import APIRouter, HTTPException, Query
from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBArtifact
from hypergolic.db.utils import to_iso_utc
from hypergolic.workflows.schemas import ArtifactResponse

router = APIRouter(prefix="/api/artifacts", tags=["artifacts"])


@router.get("", response_model=list[ArtifactResponse])
def list_artifacts(
    session_id: str | None = Query(None),
    workflow_id: str | None = Query(None),
    state_id: str | None = Query(None),
    outcome: str | None = Query(None),
    artifact_id: str | None = Query(None),
    limit: int = Query(50, ge=1, le=200),
    offset: int = Query(0, ge=0),
):
    with get_db() as db:
        stmt = select(DBArtifact).order_by(DBArtifact.created_at.desc())
        if session_id:
            stmt = stmt.where(DBArtifact.session_id == session_id)
        if workflow_id:
            stmt = stmt.where(DBArtifact.workflow_id == workflow_id)
        if state_id:
            stmt = stmt.where(DBArtifact.state_id == state_id)
        if outcome:
            stmt = stmt.where(DBArtifact.outcome == outcome)
        if artifact_id:
            stmt = stmt.where(DBArtifact.artifact_id == artifact_id)
        stmt = stmt.offset(offset).limit(limit)
        rows = db.execute(stmt).scalars().all()
        return [
            ArtifactResponse(
                id=row.id,
                session_id=row.session_id,
                workflow_id=row.workflow_id,
                state_id=row.state_id,
                outcome=row.outcome,
                artifact_id=row.artifact_id,
                content=row.content,
                created_at=to_iso_utc(row.created_at),
            )
            for row in rows
        ]


@router.get("/{artifact_db_id}", response_model=ArtifactResponse)
def get_artifact(artifact_db_id: str):
    with get_db() as db:
        row = db.execute(
            select(DBArtifact).where(DBArtifact.id == artifact_db_id)
        ).scalar_one_or_none()
        if row is None:
            raise HTTPException(status_code=404, detail="Artifact not found")
        return ArtifactResponse(
            id=row.id,
            session_id=row.session_id,
            workflow_id=row.workflow_id,
            state_id=row.state_id,
            outcome=row.outcome,
            artifact_id=row.artifact_id,
            content=row.content,
            created_at=to_iso_utc(row.created_at),
        )
