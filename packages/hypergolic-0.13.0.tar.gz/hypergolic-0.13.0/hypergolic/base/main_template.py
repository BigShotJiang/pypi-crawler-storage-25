"""
Hypergolic toolkit configuration.

This file is the entry point — it imports and registers, not implements.
As your toolkit grows, put tools in tools/, skills in skills/, and
project setup in projects/<id>/tools.py.

Run with: h (shell alias set up by `hypergolic init`)
"""
from hypergolic import App, Project

from base.tools.registry import UNIVERSAL_TOOLS
from base.roles.registry import ALL_BASE_ROLES
from base.skills.registry import ALL_BASE_SKILLS

app = App()

app.register_tools(UNIVERSAL_TOOLS)
app.register_roles(ALL_BASE_ROLES)
app.register_skills(ALL_BASE_SKILLS)

# --- Projects ---
# Register your projects here. Example:
#
# from projects.my_project.tools import setup_my_project
# setup_my_project(app)

if __name__ == "__main__":
    app()
