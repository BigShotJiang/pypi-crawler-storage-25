from hypergolic.toolkit.primitives import Role
from hypergolic.base.tools.command import command_tool
from hypergolic.base.tools.delete_files import delete_files_tool
from hypergolic.base.tools.edit_files import edit_files_tool
from hypergolic.base.tools.make_directory import make_directory_tool
from hypergolic.base.tools.manage_mcp import manage_mcp_tool
from hypergolic.base.tools.move_files import move_files_tool
from hypergolic.base.tools.write_files import write_files_tool
from hypergolic.base.tools.sandbox_command import sandbox_command_tool
from hypergolic.base.skills.registry import product_management_skill, REVIEWER_SKILLS

generalist_role = Role(
    id="generalist",
    name="Generalist",
    prompt_path="~/.hypergolic/base/prompts/roles/generalist.md",
    tools=[write_files_tool, edit_files_tool, make_directory_tool, move_files_tool, delete_files_tool, manage_mcp_tool, command_tool],
    skills=[product_management_skill],
)

worker_role = Role(
    id="worker",
    name="Worker",
    prompt_path="~/.hypergolic/base/prompts/roles/worker.md",
    tools=[write_files_tool, edit_files_tool, make_directory_tool, move_files_tool, delete_files_tool],
)

reviewer_role = Role(
    id="reviewer",
    name="Reviewer",
    prompt_path="~/.hypergolic/base/prompts/roles/reviewer.md",
    skills=REVIEWER_SKILLS,
)

researcher_role = Role(
    id="researcher",
    name="Researcher",
    prompt_path="~/.hypergolic/base/prompts/roles/researcher.md",
    tools=[sandbox_command_tool],
)

ALL_BASE_ROLES = [
    generalist_role,
    researcher_role,
    reviewer_role,
    worker_role,
]
