from hypergolic.base.tools.registry import TOOLKIT_ENGINEER_TOOLS
from hypergolic.toolkit.primitives import Skill

toolkit_engineer_skill = Skill(
    id="toolkit-engineer",
    name="Toolkit Engineering",
    description="Build, improve, and maintain the user's Hypergolic toolkit \u2014 tools, skills, roles, workflows, prompts, and projects",
    prompt_path="~/.hypergolic/base/prompts/skills/toolkit-engineer.md",
    tools=TOOLKIT_ENGINEER_TOOLS,
)

product_management_skill = Skill(
    id="product-management",
    name="Product Management",
    description="Collaborate on requirements, challenge assumptions, define scope, and produce a PRD before implementation begins",
    prompt_path="~/.hypergolic/base/prompts/skills/product-management.md",
)

prompt_engineer_skill = Skill(
    id="prompt-engineer",
    name="Prompt Engineering",
    description="Write, evaluate, and refine prompts for LLM-based systems \u2014 system prompts, role prompts, skill prompts, workflow state prompts, and project prompts",
    prompt_path="~/.hypergolic/base/prompts/skills/prompt-engineer.md",
)

security_review_skill = Skill(
    id="security-review",
    name="Security Review",
    description="Analyze changes for security vulnerabilities: injection, auth gaps, data exposure, OWASP Top 10",
    prompt_path="~/.hypergolic/base/prompts/skills/security-review.md",
)

performance_review_skill = Skill(
    id="performance-review",
    name="Performance Review",
    description="Evaluate changes for runtime performance, algorithmic complexity, N+1 queries, memory usage, and scalability",
    prompt_path="~/.hypergolic/base/prompts/skills/performance-review.md",
)

code_conventions_skill = Skill(
    id="code-conventions",
    name="Code Conventions",
    description="Check pattern consistency, appropriate DRY, and adherence to the codebase's existing conventions",
    prompt_path="~/.hypergolic/base/prompts/skills/code-conventions.md",
)

code_complexity_skill = Skill(
    id="code-complexity",
    name="Code Complexity",
    description="Spot excessive cyclomatic/cognitive complexity, deep nesting, long functions, and suggest simplification patterns",
    prompt_path="~/.hypergolic/base/prompts/skills/code-complexity.md",
)

REVIEWER_SKILLS = [
    security_review_skill,
    performance_review_skill,
    code_conventions_skill,
    code_complexity_skill,
]

ALL_BASE_SKILLS = [
    toolkit_engineer_skill,
    prompt_engineer_skill,
]
