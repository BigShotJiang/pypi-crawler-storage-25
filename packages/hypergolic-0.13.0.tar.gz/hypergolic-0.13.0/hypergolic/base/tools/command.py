import os
import subprocess
from typing import Optional


from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.tools.approval_view import ApprovalView, BadgeBlock, CodeBlock
from hypergolic.tools.subprocess_util import run_subprocess


class CommandInput(InputSchema):
    command: str
    working_directory: Optional[str] = None
    timeout: Optional[int] = 10
    env: Optional[dict[str, str]] = None


async def run_command(inp: CommandInput, ctx: ToolContext) -> ToolResult:
    env = os.environ.copy()
    if inp.env:
        env.update(inp.env)

    cwd = inp.working_directory or str(ctx.session.working_directory())

    try:
        result = await run_subprocess(
            inp.command,
            shell=True,
            timeout=inp.timeout,
            cwd=cwd,
            env=env,
        )

        output_parts = []

        if result.stdout:
            output_parts.append(f"STDOUT:\n{result.stdout}")

        if result.stderr:
            output_parts.append(f"STDERR:\n{result.stderr}")

        output_parts.append(f"Exit code: {result.returncode}")

        text = "\n\n".join(output_parts)
        return ToolResult(
            content=[{"type": "text", "text": text}],
            outcome="FAILURE" if result.returncode != 0 else "SUCCESS",
        )

    except subprocess.TimeoutExpired:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Command timed out after {inp.timeout} seconds.",
                }
            ],
            outcome="FAILURE",
        )
    except FileNotFoundError:
        return ToolResult(
            content=[{"type": "text", "text": f"Working directory not found: {cwd}"}],
            outcome="FAILURE",
        )
    except Exception as e:
        return ToolResult(
            content=[{"type": "text", "text": f"Error executing command: {str(e)}"}],
            outcome="FAILURE",
        )


def command_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    """Worktree sessions run commands freely — the filesystem *is* the sandbox.

    Shell commands can't be statically analyzed for path safety, but in a
    worktree session the agent's default cwd is the worktree and the worktree
    itself is disposable. Requiring approval here would make the tool
    functionally unusable in dispatched children (no user to approve).

    Non-worktree sessions keep the require-approval behaviour.
    """
    if getattr(ctx.session, "worktree_path", None):
        return ToolApprovalDecision(decision="ALLOW")
    return ToolApprovalDecision(decision="REQUIRE_APPROVAL")


command_tool = Tool(
    id="command",
    name="Command",
    description="Execute a shell command. Requires approval. Only use when no other tool can accomplish the task",
    input_schema=CommandInput,
    run=run_command,
    approval=command_approval,
    approval_view=ApprovalView(blocks=[
        CodeBlock(field="command", language="bash", max_height="half"),
        BadgeBlock(field="working_directory", label="CWD", tone="info"),
        BadgeBlock(field="timeout", label="Timeout"),
    ]),
)
