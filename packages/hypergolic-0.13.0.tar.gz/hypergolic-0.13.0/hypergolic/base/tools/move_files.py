"""Move (or rename) files or directories within the project.

Works for both regular files and directories — ``Path.rename`` handles both.
Saves the agent from round-tripping through read/write/delete or shelling
out to ``mv``. A move is allowed only when BOTH the source and destination
paths satisfy the same write-boundary check used by ``write_files`` and
``delete_files``.
"""

from hypergolic.base.tools.approvals.paths import decide_write
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.tools.approval_view import ApprovalView, ForEachBlock, TextBlock
from hypergolic.tools.paths import resolve_path


class MoveEntry(InputSchema):
    src: str
    dst: str


class MoveFilesInput(InputSchema):
    moves: list[MoveEntry]


async def run_move_files(inp: MoveFilesInput, ctx: ToolContext) -> ToolResult:
    errors: list[str] = []

    for entry in inp.moves:
        src = resolve_path(entry.src, ctx.session)
        dst = resolve_path(entry.dst, ctx.session)
        try:
            if not src.exists():
                errors.append(f"Source not found: {entry.src}")
                continue
            if dst.exists():
                errors.append(f"Destination already exists: {entry.dst}")
                continue
            dst.parent.mkdir(parents=True, exist_ok=True)
            src.rename(dst)
        except PermissionError:
            errors.append(f"Permission denied moving {entry.src} -> {entry.dst}")
        except Exception as e:
            errors.append(f"Error moving {entry.src} -> {entry.dst}: {e}")

    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def move_files_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    """Allow a move only when BOTH src and dst pass the write-boundary check.

    Any path out of scope -> DENY (worktree) or REQUIRE_APPROVAL (otherwise),
    via ``decide_write``.
    """
    paths = [p for entry in ctx.input.moves for p in (entry.src, entry.dst)]
    return decide_write(paths, ctx.session, verb="move")


move_files_tool = Tool(
    id="move",
    name="Move Files",
    description="",
    input_schema=MoveFilesInput,
    run=run_move_files,
    approval=move_files_approval,
    approval_view=ApprovalView(blocks=[
        ForEachBlock(
            field="moves",
            item_heading="src",
            template=[TextBlock(field="dst", label="->", mono=True)],
            separator="none",
            empty_text="No files to move.",
        ),
    ]),
)
