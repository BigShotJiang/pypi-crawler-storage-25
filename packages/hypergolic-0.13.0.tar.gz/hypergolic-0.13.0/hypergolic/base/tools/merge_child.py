"""Dynamic merge_child tool.

Injected into a parent session when one or more of its concluded children
has a surviving worktree branch (i.e. the child committed work and the
branch still exists). Lets the parent pull the child's work into its own
branch via ``merge``, ``squash``, or ``discard``.

Built from :func:`hypergolic.tools.tool_list.build_tools` when the parent
session is generalist (same eligibility rule as ``dispatch``).
"""
from __future__ import annotations

import logging
from enum import Enum
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.git.commands import run_git_command
from hypergolic.git.worktree import delete_branch
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult

logger = logging.getLogger(__name__)


class MergeCandidate(BaseModel):
    session_id: str
    worktree_branch: str
    merge_ready: bool
    description: str | None = None
    conclusion_feedback: str | None = None


def find_merge_candidates(parent_session_id: str) -> list[MergeCandidate]:
    """Return concluded children of *parent_session_id* whose branch still exists."""
    from hypergolic.enums import SessionStatus

    with get_db() as db:
        rows = db.execute(
            select(DBSession).where(
                DBSession.parent_id == parent_session_id,
                DBSession.status == SessionStatus.CONCLUDED,
                DBSession.worktree_branch.is_not(None),
            )
        ).scalars().all()
    return [
        MergeCandidate(
            session_id=r.id,
            worktree_branch=r.worktree_branch or "",
            # merge_ready is not persisted on the row (it's a message-only
            # recommendation). Default to False \u2014 surface via description
            # if we ever persist it.
            merge_ready=False,
            description=r.description,
            conclusion_feedback=r.conclusion_feedback,
        )
        for r in rows
        if r.worktree_branch
    ]


def _clear_branch_fields(session_id: str) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(worktree_branch=None, base_branch=None)
        )


def _describe_candidates(candidates: list[MergeCandidate]) -> str:
    lines = [
        "Merge a concluded worktree-child's branch into your current branch.",
        "",
        "Eligible children:",
    ]
    for c in candidates:
        label = c.description or c.session_id
        lines.append(f"- `{c.session_id}` (branch `{c.worktree_branch}`): {label}")
    lines.append("")
    lines.append(
        "Strategies: `merge` (default), `squash` (single commit), `discard` "
        "(throw the branch away without merging)."
    )
    return "\n".join(lines)


def build_merge_child_tool(parent_session: Session) -> Tool | None:
    candidates = find_merge_candidates(parent_session.id)
    if not candidates:
        return None

    SessionIdEnum = Enum(  # type: ignore[misc]
        "SessionIdEnum",
        {c.session_id: c.session_id for c in candidates},
        type=str,
    )
    by_id = {c.session_id: c for c in candidates}

    class MergeChildInput(InputSchema):
        child_session_id: SessionIdEnum  # type: ignore[valid-type]
        strategy: Literal["merge", "squash", "discard"] = Field(default="merge")
        commit_message: str | None = Field(
            default=None,
            description="Commit message for `squash` strategy. Ignored for merge/discard.",
        )

    async def run(inp: MergeChildInput, ctx: ToolContext) -> ToolResult:
        child_id = (
            inp.child_session_id.value
            if isinstance(inp.child_session_id, Enum)
            else str(inp.child_session_id)
        )
        candidate = by_id.get(child_id)
        if candidate is None:
            return ToolResult(
                content=[{"type": "text", "text": f"No merge-eligible child with id {child_id}"}],
                outcome="FAILURE",
            )
        return await _run_merge(
            parent_session=ctx.session,
            candidate=candidate,
            strategy=inp.strategy,
            commit_message=inp.commit_message,
        )

    return Tool(
        id="merge_child",
        name="Merge Child Branch",
        description=_describe_candidates(candidates),
        input_schema=MergeChildInput,
        run=run,
    )


async def _run_merge(
    *,
    parent_session: Session,
    candidate: MergeCandidate,
    strategy: Literal["merge", "squash", "discard"],
    commit_message: str | None,
) -> ToolResult:
    project_path = Path(parent_session.project_path)
    branch = candidate.worktree_branch

    if strategy == "discard":
        delete_branch(branch=branch, project_path=project_path, force=True)
        _clear_branch_fields(candidate.session_id)
        return ToolResult(
            content=[
                {"type": "text", "text": f"Discarded branch `{branch}` without merging."}
            ],
            outcome="SUCCESS",
        )

    if strategy == "squash":
        result = run_git_command("merge", "--squash", branch, cwd=project_path)
        if result.returncode != 0:
            return ToolResult(
                content=[
                    {
                        "type": "text",
                        "text": (
                            f"git merge --squash {branch} failed:\n"
                            f"{result.stderr.strip() or result.stdout.strip()}"
                        ),
                    }
                ],
                outcome="FAILURE",
            )
        msg = commit_message or f"Squash merge of {branch}"
        commit = run_git_command("commit", "-m", msg, cwd=project_path)
        if commit.returncode != 0:
            return ToolResult(
                content=[
                    {
                        "type": "text",
                        "text": (
                            "Squash staged, but commit failed:\n"
                            f"{commit.stderr.strip() or commit.stdout.strip()}"
                        ),
                    }
                ],
                outcome="FAILURE",
            )
        delete_branch(branch=branch, project_path=project_path, force=True)
        _clear_branch_fields(candidate.session_id)
        return ToolResult(
            content=[
                {"type": "text", "text": f"Squash-merged `{branch}` and cleaned up the branch."}
            ],
            outcome="SUCCESS",
        )

    # Default: regular merge
    result = run_git_command("merge", branch, cwd=project_path)
    if result.returncode != 0:
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": (
                        f"git merge {branch} failed \u2014 resolve conflicts in "
                        f"{project_path} and commit, or run `git merge --abort`.\n\n"
                        f"{result.stderr.strip() or result.stdout.strip()}"
                    ),
                }
            ],
            outcome="FAILURE",
        )
    delete_branch(branch=branch, project_path=project_path)
    _clear_branch_fields(candidate.session_id)
    return ToolResult(
        content=[
            {"type": "text", "text": f"Merged `{branch}` and cleaned up the branch."}
        ],
        outcome="SUCCESS",
    )


__all__ = [
    "MergeCandidate",
    "build_merge_child_tool",
    "find_merge_candidates",
]
