from typing import Literal


from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult
from hypergolic.mcptools.client.manager import get_mcp_manager
from hypergolic.mcptools.sessions import get_enabled_servers, set_enabled_servers


class ManageMCPInput(InputSchema):
    command: Literal["list", "enable", "disable"]
    server_name: str | None = None


async def run_manage_mcp(inp: ManageMCPInput, ctx: ToolContext) -> ToolResult:
    manager = get_mcp_manager()
    session_id = ctx.session.id
    project_path = ctx.session.project_path

    if inp.command == "list":
        available = manager.get_available_servers(project_path)
        enabled = get_enabled_servers(session_id)
        if not available:
            return ToolResult(
                content=[{"type": "text", "text": "No MCP servers configured."}],
                outcome="SUCCESS",
            )
        lines = []
        for name, (config, source) in available.items():
            connected = manager.is_connected(name)
            in_session = name in enabled
            status = (
                "enabled" if in_session else ("connected" if connected else "available")
            )
            server = manager.get_connected_server(name)
            tool_count = len(server.tools) if server else 0
            line = f"- {name} (source: {source}, status: {status}, tools: {tool_count})"
            if status == "connected":
                line += f" \u2192 call enable with server_name='{name}' to use its tools in this session"
            elif status == "available":
                line += f" \u2192 call enable with server_name='{name}' to connect and use its tools"
            lines.append(line)
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(lines)}],
            outcome="SUCCESS",
        )

    if not inp.server_name:
        return ToolResult(
            content=[
                {"type": "text", "text": "server_name is required for enable/disable."}
            ],
            outcome="FAILURE",
        )

    if inp.command == "enable":
        try:
            server = await manager.connect(inp.server_name, project_path)
        except Exception as e:
            return ToolResult(
                content=[
                    {
                        "type": "text",
                        "text": f"Failed to connect MCP server '{inp.server_name}': {e}",
                    }
                ],
                outcome="FAILURE",
            )
        enabled = get_enabled_servers(session_id)
        enabled.add(inp.server_name)
        set_enabled_servers(session_id, enabled)
        tool_count = len(server.tools)
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Enabled MCP server '{inp.server_name}' with {tool_count} tools. "
                    f"Its tools are now available for this session.",
                }
            ],
            outcome="SUCCESS",
        )

    if inp.command == "disable":
        enabled = get_enabled_servers(session_id)
        enabled.discard(inp.server_name)
        set_enabled_servers(session_id, enabled)
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Disabled MCP server '{inp.server_name}' for this session.",
                }
            ],
            outcome="SUCCESS",
        )

    return ToolResult(
        content=[{"type": "text", "text": f"Unknown command: {inp.command}"}],
        outcome="FAILURE",
    )


manage_mcp_tool = Tool(
    id="manage_mcp",
    name="Manage MCP Servers",
    description="Manage MCP servers for this session",
    input_schema=ManageMCPInput,
    run=run_manage_mcp,
)
