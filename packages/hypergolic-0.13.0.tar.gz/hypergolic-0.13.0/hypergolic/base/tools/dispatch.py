"""Unified dispatch tool.

Replaces the separate ``assign`` / ``research`` / ``review`` tools with a
single ``dispatch`` tool that accepts a target role, a prompt, and an
optional list of file references.

Only the ``generalist`` role can dispatch, and it may dispatch to any
registered non-generalist role. The ``role`` field is an enum of those
role IDs, computed from the app at tool-build time.
"""
from __future__ import annotations

import logging
from enum import Enum
from typing import Iterable

from pydantic import Field

from hypergolic.base.tools.read_files import ReadFilesInput, read_files_approval
from hypergolic.dispatch.core import dispatch
from hypergolic.enums import ModelTier
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolContext,
    ToolResult,
)
from hypergolic.tools.paths import resolve_path

logger = logging.getLogger(__name__)

DISPATCH_PROMPT = """You are an agent dispatched to complete a task. Your parent session is blocked waiting for you to complete it.

Guidelines:
- The user can see your conversation, but strongly prefer to work autonomously
- The prompt from your parent is your specification — follow it precisely
- Be thorough but efficient — the parent session is blocked waiting for your result
- Use outcome "success" with a summary of what you did, or "failure" with the reason you couldn't complete it"""


def _render_file_reference(
    raw_path: str,
    child_session: Session,
    receiver_tool_ids: set[str],
) -> str:
    """Load *raw_path* for inclusion in the dispatched prompt.

    Permission model:
    - If the receiving role has no ``read_files`` tool, mark as missing.
    - If the path's approval for the receiving role is not ALLOW, mark as
      missing (REQUIRE_APPROVAL and DENY both count as "not allowed
      without user intervention").
    - Otherwise read and inline the file contents.
    """
    if "read_files" not in receiver_tool_ids:
        return (
            f"=== {raw_path} ===\n"
            f"[not provided: receiving role lacks read_files permission]"
        )

    approval_input = ReadFilesInput(paths=[raw_path])
    ctx = ApprovalContext(
        input=approval_input,
        session=child_session,
        active_skill_ids=set(),
    )
    decision = read_files_approval(ctx)
    if decision.decision != "ALLOW":
        return (
            f"=== {raw_path} ===\n"
            f"[not provided: receiving role is not permitted to read this path]"
        )

    path = resolve_path(raw_path, child_session)
    if not path.exists():
        return f"=== {raw_path} ===\n[not provided: file not found]"
    if not path.is_file():
        return f"=== {raw_path} ===\n[not provided: not a file]"
    try:
        content = path.read_text(encoding="utf-8")
    except UnicodeDecodeError:
        return f"=== {raw_path} ===\n[not provided: file is not valid UTF-8 text]"
    except PermissionError:
        return f"=== {raw_path} ===\n[not provided: permission denied]"
    except Exception as e:
        return f"=== {raw_path} ===\n[not provided: {e}]"
    return f"=== {raw_path} ===\n{content}"


def _build_child_session_view(parent_session: Session, role: str) -> Session:
    """Build a Session mirroring what the child will see.

    Used only for permission evaluation — no DB row is created here.
    """
    return Session(
        id=f"{parent_session.id}:dispatch-probe",
        model_tier=parent_session.model_tier,
        project_id=parent_session.project_id,
        project_path=parent_session.project_path,
        role=role,
    )


def build_dispatch_tool(
    available_role_ids: Iterable[str],
    receiver_tool_ids_by_role: dict[str, set[str]],
) -> Tool | None:
    """Build a ``dispatch`` tool bound to the given role set.

    ``receiver_tool_ids_by_role`` maps each role ID to the set of tool IDs
    that role would have available — used to check whether the receiver
    can read requested files.
    """
    role_ids = list(available_role_ids)
    if not role_ids:
        return None

    DispatchRoleEnum = Enum(  # type: ignore[misc]
        "DispatchRoleEnum", {rid: rid for rid in role_ids}, type=str
    )

    class DispatchInput(InputSchema):
        role: DispatchRoleEnum  # type: ignore[valid-type]
        prompt: str
        file_references: list[str] = Field(
            default_factory=list,
            description="Unreadable paths are marked missing, not included.",
        )
        model_tier: ModelTier = ModelTier.MEDIUM
        worktree: bool = True

    async def run_dispatch(inp: DispatchInput, ctx: ToolContext) -> ToolResult:
        role_value = (
            inp.role.value if isinstance(inp.role, Enum) else str(inp.role)
        )

        child_view = _build_child_session_view(ctx.session, role_value)
        receiver_tool_ids = receiver_tool_ids_by_role.get(role_value, set())

        content_blocks: list[dict] = [{"type": "text", "text": inp.prompt}]
        if inp.file_references:
            rendered = [
                _render_file_reference(ref, child_view, receiver_tool_ids)
                for ref in inp.file_references
            ]
            content_blocks.append(
                {
                    "type": "text",
                    "text": "## Attached file references\n\n"
                    + "\n\n".join(rendered),
                }
            )

        result = await dispatch(
            parent_session_id=ctx.session.id,
            content_blocks=content_blocks,
            dispatch_prompt=DISPATCH_PROMPT,
            broadcast=ctx.broadcast,
            role=role_value,
            model_tier=inp.model_tier,
            worktree=inp.worktree,
        )

        if result.outcome == "success":
            return ToolResult(
                content=[{"type": "text", "text": result.conclusion}],
                outcome="SUCCESS",
            )
        if result.outcome == "failure":
            return ToolResult(
                content=[
                    {"type": "text", "text": f"Dispatch failed: {result.conclusion}"}
                ],
                outcome="FAILURE",
            )
        return ToolResult(
            content=[
                {
                    "type": "text",
                    "text": f"Dispatch was interrupted: {result.conclusion}",
                }
            ],
            outcome="FAILURE",
        )

    return Tool(
        id="dispatch",
        name="Dispatch",
        description=(
            "Dispatch a sub-agent in its own session with its role's tools."
        ),
        input_schema=DispatchInput,
        run=run_dispatch,
    )


__all__ = [
    "DISPATCH_PROMPT",
    "build_dispatch_tool",
]
