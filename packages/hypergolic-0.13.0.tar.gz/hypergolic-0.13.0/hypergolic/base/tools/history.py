import json
from datetime import date, datetime
from decimal import Decimal
from typing import Any

from sqlalchemy import create_engine, event, text
from sqlalchemy.engine import Engine
from sqlalchemy.pool import NullPool

from hypergolic.config.settings import settings
from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult


class HistoryInput(InputSchema):
    query: str


def _is_shared_memory_sqlite(url: str) -> bool:
    return url in ("sqlite://", "sqlite:///:memory:")


def _get_engine_for_query() -> tuple[Engine, bool]:
    """Return (engine, owned). ``owned`` means the caller should dispose it.

    For file/network DBs we build a fresh read-only engine per call so the
    ``PRAGMA query_only=ON`` listener doesn't affect the app's main engine.
    For in-memory SQLite (tests) we must reuse the main engine — a separate
    engine would point at a different in-memory DB and see no data — and
    toggle ``query_only`` around the query.
    """
    url = settings.HYPERGOLIC_DATABASE_URL
    if _is_shared_memory_sqlite(url):
        from hypergolic.db.engine import get_engine

        return get_engine(), False

    connect_args: dict[str, Any] = {}
    if url.startswith("sqlite"):
        connect_args["check_same_thread"] = False
    engine = create_engine(url, connect_args=connect_args, poolclass=NullPool)

    @event.listens_for(engine, "connect")
    def _set_query_only(dbapi_conn, _record):
        cursor = dbapi_conn.cursor()
        cursor.execute("PRAGMA query_only=ON")
        cursor.close()

    return engine, True


def _jsonable(value: Any) -> Any:
    if isinstance(value, (datetime, date)):
        return value.isoformat()
    if isinstance(value, Decimal):
        return str(value)
    if isinstance(value, bytes):
        try:
            return value.decode("utf-8")
        except UnicodeDecodeError:
            return value.hex()
    return value


async def run_history(inp: HistoryInput, ctx: ToolContext) -> ToolResult:
    engine, owned = _get_engine_for_query()
    try:
        with engine.connect() as conn:
            if not owned:
                conn.exec_driver_sql("PRAGMA query_only=ON")
            try:
                result = conn.execute(text(inp.query))
                if result.returns_rows:
                    columns = list(result.keys())
                    rows = [
                        {col: _jsonable(val) for col, val in zip(columns, row)}
                        for row in result.fetchall()
                    ]
                    payload: dict[str, Any] = {"columns": columns, "rows": rows}
                else:
                    payload = {"rowcount": result.rowcount}
            finally:
                if not owned:
                    conn.exec_driver_sql("PRAGMA query_only=OFF")
    except Exception as e:
        return ToolResult(
            content=[{"type": "text", "text": f"{type(e).__name__}: {e}"}],
            outcome="FAILURE",
        )
    finally:
        if owned:
            engine.dispose()

    return ToolResult(
        content=[{"type": "text", "text": json.dumps(payload, default=str)}],
        outcome="SUCCESS",
    )


history_tool = Tool(
    id="history",
    name="History",
    description="Read-only SQL over the Hypergolic SQLite DB.",
    input_schema=HistoryInput,
    run=run_history,
)
