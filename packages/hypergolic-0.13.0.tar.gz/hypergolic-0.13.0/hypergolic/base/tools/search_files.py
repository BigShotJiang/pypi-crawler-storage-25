import asyncio
import subprocess
from typing import Optional

from pydantic import Field

from hypergolic.base.tools.approvals.paths import (
    ALLOW,
    REQUIRE_APPROVAL,
    in_project_or_readonly_allowlist,
)
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path, shorten_path
from hypergolic.tools.python_search import PythonSearchParams, python_search
from hypergolic.tools.subprocess_util import has_ripgrep, run_subprocess

MAX_LINE_LENGTH = 1000
DEFAULT_MAX_RESULTS = 50


class SearchFilesInput(InputSchema):
    pattern: str = Field(description="Regex pattern")
    directory: Optional[str] = "."
    context_lines: Optional[int] = 0


def _truncate_line(line: str, limit: int = MAX_LINE_LENGTH) -> str:
    if len(line) <= limit or line == "--":
        return line
    return line[:limit] + " \u2026 [line truncated]"


def _rewrite_line(line: str, session: Session) -> str:
    """Shorten the path prefix of a ripgrep-style ``path:lineno:text`` line.

    Non-path lines (empty, ``--`` separators, anything not starting with ``/``)
    are returned unchanged.
    """
    if not line.startswith("/"):
        return line
    head, sep, tail = line.partition(":")
    if not sep:
        return line
    return f"{shorten_path(head, session)}:{tail}"


def _format_result(
    result: subprocess.CompletedProcess,
    inp: SearchFilesInput,
    session: Session,
) -> ToolResult:
    if result.returncode == 1 and not result.stderr:
        return ToolResult(
            content=[{"type": "text", "text": f"No matches found for pattern: {inp.pattern}"}],
            outcome="SUCCESS",
        )

    if result.returncode > 1 and result.stderr:
        return ToolResult(
            content=[{"type": "text", "text": f"Search error: {result.stderr.strip()}"}],
            outcome="FAILURE",
        )

    output = result.stdout.strip()
    if not output:
        return ToolResult(
            content=[{"type": "text", "text": f"No matches found for pattern: {inp.pattern}"}],
            outcome="SUCCESS",
        )

    lines = output.split("\n")
    lines = [_truncate_line(_rewrite_line(line, session)) for line in lines]
    non_context_lines = [line for line in lines if line and not line.startswith("--")]
    match_count = len(non_context_lines)
    has_more = match_count > DEFAULT_MAX_RESULTS
    shown = min(match_count, DEFAULT_MAX_RESULTS)

    if has_more:
        kept_lines: list[str] = []
        kept_count = 0
        for line in lines:
            is_context = not line or line.startswith("--")
            if is_context:
                if kept_count < DEFAULT_MAX_RESULTS:
                    kept_lines.append(line)
            else:
                kept_count += 1
                if kept_count <= DEFAULT_MAX_RESULTS:
                    kept_lines.append(line)
        lines = kept_lines

    summary = f"Found {shown} matching lines:\n\n"
    footer = f"\n\n{shown} results shown. More results available." if has_more else ""

    truncated_output = "\n".join(lines)
    return ToolResult(
        content=[{"type": "text", "text": summary + truncated_output + footer}],
        outcome="SUCCESS",
    )


async def _search_with_rg(inp: SearchFilesInput, directory: str) -> subprocess.CompletedProcess:
    cmd = ["rg"]

    cmd.append("--hidden")
    cmd.extend(["--max-count", str(DEFAULT_MAX_RESULTS + 1)])
    if inp.context_lines is not None and inp.context_lines > 0:
        cmd.extend(["-C", str(inp.context_lines)])
    cmd.append("--line-number")

    cmd.append("--color=never")
    cmd.append(inp.pattern)
    cmd.append(directory)

    return await run_subprocess(cmd, timeout=30)


async def _search_with_python(inp: SearchFilesInput, directory: str) -> subprocess.CompletedProcess:
    params = PythonSearchParams(
        pattern=inp.pattern,
        directory=directory,
        case_sensitive=True,
        include_hidden=True,
        context_lines=inp.context_lines or 0,
        max_results=DEFAULT_MAX_RESULTS + 1,
        show_line_numbers=True,
    )
    return await asyncio.to_thread(python_search, params)


async def run_search_files(inp: SearchFilesInput, ctx: ToolContext) -> ToolResult:
    directory = str(resolve_path(inp.directory or ".", ctx.session))

    try:
        if has_ripgrep():
            result = await _search_with_rg(inp, directory)
        else:
            result = await _search_with_python(inp, directory)
        return _format_result(result, inp, ctx.session)

    except subprocess.TimeoutExpired:
        return ToolResult(
            content=[{"type": "text", "text": "Search timed out after 30 seconds. Try a more specific pattern or directory."}],
            outcome="FAILURE",
        )
    except Exception as e:
        return ToolResult(
            content=[{"type": "text", "text": f"Error during search: {str(e)}"}],
            outcome="FAILURE",
        )


def search_files_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    """Allow searches inside the project or readonly-allowlisted paths."""
    directory = ctx.input.directory or "."
    if not in_project_or_readonly_allowlist(directory, ctx.session):
        return REQUIRE_APPROVAL
    return ALLOW


search_files_tool = Tool(
    id="search_files",
    name="Search Files",
    description="Search file contents using regex",
    input_schema=SearchFilesInput,
    run=run_search_files,
    approval=search_files_approval,
)
