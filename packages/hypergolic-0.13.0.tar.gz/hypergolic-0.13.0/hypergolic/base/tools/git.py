import asyncio
import shlex

from pydantic import Field

from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.schemas import Session
from hypergolic.git.operations import run_git_command

READ_ONLY_SUBCOMMANDS = {
    "status", "diff", "log", "show", "branch", "stash",
    "shortlog", "describe", "rev-parse", "ls-files", "ls-tree",
    "cat-file", "blame", "reflog",
}

# Subcommands auto-allowed inside a worktree session (the branch is isolated
# so there's nothing to protect). Kept small so that anything unexpected still
# goes through the normal approval path.
WORKTREE_ALLOW_SUBCOMMANDS = {
    "add", "commit", "reset", "rm", "mv", "restore", "clean", "tag", "stash",
}

# Subcommands explicitly refused inside a worktree session because they would
# break the isolation contract (the agent is not allowed to leave its branch).
WORKTREE_DENY_SUBCOMMANDS = {
    "checkout", "switch", "merge", "rebase", "pull", "worktree",
}


class GitInput(InputSchema):
    args: str = Field(description="e.g. 'status' or 'diff --staged'")


def _first_subcommand(args: str) -> str:
    parts = shlex.split(args)
    for part in parts:
        if not part.startswith("-"):
            return part
    return ""


def git_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    subcommand = _first_subcommand(ctx.input.args)
    if subcommand in READ_ONLY_SUBCOMMANDS:
        return ToolApprovalDecision(decision="ALLOW")

    session = ctx.session
    if getattr(session, "worktree_path", None):
        if subcommand in WORKTREE_ALLOW_SUBCOMMANDS:
            return ToolApprovalDecision(decision="ALLOW")
        if subcommand in WORKTREE_DENY_SUBCOMMANDS:
            return ToolApprovalDecision(
                decision="DENY",
                reason=(
                    f"'git {subcommand}' is not allowed in a worktree session. "
                    "You are on an isolated branch \u2014 commit your changes and "
                    "conclude with `merge_ready: true` so the parent can merge."
                ),
            )

    return ToolApprovalDecision(decision="REQUIRE_APPROVAL")


def _run_git_tool_command(inp: GitInput, session: Session) -> ToolResult:
    repo_path = session.working_directory()
    parts = shlex.split(inp.args)

    result = run_git_command(*parts, cwd=repo_path)
    output = result.stdout.strip() or result.stderr.strip() or "(no output)"

    return ToolResult(
        content=[{"type": "text", "text": output}],
        outcome="FAILURE" if result.returncode != 0 else "SUCCESS",
    )


async def run_git(inp: GitInput, ctx: ToolContext) -> ToolResult:
    try:
        return await asyncio.to_thread(_run_git_tool_command, inp, ctx.session)
    except Exception as e:
        return ToolResult(
            content=[{"type": "text", "text": f"Git error: {e}"}],
            outcome="FAILURE",
        )


git_tool = Tool(
    id="git",
    name="Git",
    description="",
    input_schema=GitInput,
    run=run_git,
    approval=git_approval,
)
