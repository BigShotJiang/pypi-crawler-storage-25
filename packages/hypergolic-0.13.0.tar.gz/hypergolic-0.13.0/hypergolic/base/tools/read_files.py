
from hypergolic.base.tools.approvals.paths import decide_read
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.tools.paths import resolve_path


class ReadFilesInput(InputSchema):
    paths: list[str]


async def run_read_files(inp: ReadFilesInput, ctx: ToolContext) -> ToolResult:
    results = []
    has_error = False

    for file_path in inp.paths:
        path = resolve_path(file_path, ctx.session)

        if not path.exists():
            results.append(
                {"type": "text", "text": f"Error reading {file_path}: File not found"}
            )
            has_error = True
            continue

        if not path.is_file():
            results.append(
                {"type": "text", "text": f"Error reading {file_path}: Not a file"}
            )
            has_error = True
            continue

        try:
            content = path.read_text(encoding="utf-8")
            results.append({"type": "text", "text": f"=== {file_path} ===\n{content}"})
        except UnicodeDecodeError:
            results.append(
                {
                    "type": "text",
                    "text": f"Error reading {file_path}: File is not valid UTF-8 text",
                }
            )
            has_error = True
        except PermissionError:
            results.append(
                {
                    "type": "text",
                    "text": f"Error reading {file_path}: Permission denied",
                }
            )
            has_error = True
        except Exception as e:
            results.append(
                {"type": "text", "text": f"Error reading {file_path}: {str(e)}"}
            )
            has_error = True

    if not results:
        return ToolResult(
            content=[{"type": "text", "text": "No files provided to read."}],
            outcome="FAILURE",
        )

    return ToolResult(content=results, outcome="FAILURE" if has_error else "SUCCESS")


def read_files_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    """Allow reads inside the project (or worktree) or the readonly allowlist.

    Worktree sessions can only read inside their own worktree or the
    readonly allowlist; anything else is denied with a message.
    """
    return decide_read(ctx.input.paths, ctx.session)


read_files_tool = Tool(
    id="read_files",
    name="Read Files",
    description="",
    input_schema=ReadFilesInput,
    run=run_read_files,
    approval=read_files_approval,
)
