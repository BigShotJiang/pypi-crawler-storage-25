from hypergolic.base.tools.delete_files import delete_files_tool
from hypergolic.base.tools.edit_files import edit_files_tool
from hypergolic.base.tools.git import git_tool
from hypergolic.base.tools.toolkit_validate import validate_toolkit_tool
from hypergolic.base.tools.restart_server import restart_server_tool
from hypergolic.base.tools.history import history_tool
from hypergolic.base.tools.list_files import list_files_tool
from hypergolic.base.tools.make_directory import make_directory_tool
from hypergolic.base.tools.read_files import read_files_tool
from hypergolic.base.tools.search_files import search_files_tool
from hypergolic.base.tools.write_files import write_files_tool

# Universal tools — registered on app, available to all roles
UNIVERSAL_TOOLS = [
    list_files_tool,
    read_files_tool,
    search_files_tool,
    git_tool,
    history_tool,
]

# Backwards compatibility alias
ALL_BASE_TOOLS = UNIVERSAL_TOOLS

TOOLKIT_ENGINEER_TOOLS = [
    validate_toolkit_tool,
    restart_server_tool,
]
