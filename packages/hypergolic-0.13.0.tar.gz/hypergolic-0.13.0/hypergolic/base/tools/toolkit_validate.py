import ast
import asyncio
import sys
from pathlib import Path

from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.app.validation import validate_app
from hypergolic.toolkit.primitives import Tool, ToolContext, ToolResult

TOOLKIT_DIR = Path.home() / ".hypergolic"


def _check_filesystem() -> tuple[list[str], int]:
    """Check toolkit filesystem health. Returns (issues, checks_passed)."""
    issues: list[str] = []
    checks_passed = 0

    main_py = TOOLKIT_DIR / "main.py"
    if not main_py.exists():
        issues.append(f"main.py not found at {main_py}")
    else:
        checks_passed += 1
        try:
            ast.parse(main_py.read_text())
            checks_passed += 1
        except SyntaxError as e:
            issues.append(f"main.py syntax error: {e}")

    pyproject = TOOLKIT_DIR / "pyproject.toml"
    if not pyproject.exists():
        issues.append("pyproject.toml not found")
    else:
        checks_passed += 1

    base_dir = TOOLKIT_DIR / "base"
    if not base_dir.exists():
        issues.append("base/ directory not found")
    else:
        checks_passed += 1

    base_tools = base_dir / "tools" / "__init__.py"
    if base_dir.exists() and not base_tools.exists():
        issues.append("base/tools/__init__.py not found")
    elif base_dir.exists():
        checks_passed += 1

    return issues, checks_passed


async def _check_import() -> tuple[list[str], int]:
    """Try importing main.py in a subprocess. Returns (issues, checks_passed)."""
    issues: list[str] = []
    checks_passed = 0

    try:
        proc = await asyncio.create_subprocess_exec(
            sys.executable,
            "-c",
            "import main",
            cwd=str(TOOLKIT_DIR),
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.PIPE,
        )
        _, stderr_bytes = await asyncio.wait_for(
            proc.communicate(), timeout=15
        )
        if proc.returncode != 0:
            stderr_text = stderr_bytes.decode(errors="replace").strip()
            lines = stderr_text.splitlines()
            if len(lines) > 20:
                stderr_text = "\n".join(lines[-20:])
            issues.append(f"main.py import failed:\n{stderr_text}")
        else:
            checks_passed += 1
    except TimeoutError:
        issues.append("main.py import timed out (>15s)")
    except Exception as e:
        issues.append(f"main.py import check error: {e}")

    return issues, checks_passed


async def run_validate_toolkit(ctx: ToolContext) -> ToolResult:
    issues: list[str] = []
    checks_passed = 0

    # 1. Filesystem checks
    fs_issues, fs_passed = _check_filesystem()
    issues.extend(fs_issues)
    checks_passed += fs_passed

    # 2. Import check (only if main.py has valid syntax)
    has_valid_syntax = (TOOLKIT_DIR / "main.py").exists() and not any(
        "main.py" in i for i in issues
    )
    if has_valid_syntax:
        import_issues, import_passed = await _check_import()
        issues.extend(import_issues)
        checks_passed += import_passed

    # 3. App config validation (duplicate IDs, missing paths, workflow integrity, etc.)
    try:
        app = get_app()
        config_errors = validate_app(app)
        if config_errors:
            issues.extend(config_errors)
        else:
            checks_passed += 1
    except RuntimeError:
        pass  # No app initialized (shouldn't happen at runtime)

    if issues:
        text = f"{len(issues)} issue(s) found:\n" + "\n".join(
            f"  \u2022 {i}" for i in issues
        )
        text += f"\n\n{checks_passed} check(s) passed"
        return ToolResult(content=[{"type": "text", "text": text}], outcome="FAILURE")

    return ToolResult(
        content=[
            {
                "type": "text",
                "text": f"All {checks_passed} checks passed. Toolkit is healthy.",
            }
        ],
        outcome="SUCCESS",
    )


validate_toolkit_tool = Tool(
    id="validate_toolkit",
    name="Validate Toolkit",
    description=(
        "Run validation checks on the ~/.hypergolic/ toolkit: "
        "filesystem health (main.py syntax, base/ structure), "
        "import check, and app config validation (duplicate IDs, "
        "missing paths, workflow integrity, role requirements)"
    ),
    run=run_validate_toolkit,
)
