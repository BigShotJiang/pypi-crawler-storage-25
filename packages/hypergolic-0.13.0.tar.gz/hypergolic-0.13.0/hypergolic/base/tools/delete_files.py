import shutil
from pathlib import Path

from hypergolic.base.tools.approvals.paths import decide_write
from hypergolic.schemas import Session
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.tools.approval_view import ApprovalView, ForEachBlock


class DeleteFilesInput(InputSchema):
    paths: list[str]


def _target_path(raw: str, session: Session) -> Path:
    """Resolve *raw* without following a trailing symlink.

    ``hypergolic.tools.paths.resolve_path`` calls ``Path.resolve()`` which
    follows symlinks. For delete we want to operate on the symlink itself,
    not its target, so we resolve the parent directory and re-attach the
    final component.
    """
    p = Path(raw).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    return p.parent.resolve() / p.name


async def run_delete_files(inp: DeleteFilesInput, ctx: ToolContext) -> ToolResult:
    errors: list[str] = []

    for file_path in inp.paths:
        path = _target_path(file_path, ctx.session)
        try:
            if path.is_symlink():
                path.unlink()
            elif not path.exists():
                errors.append(f"Path not found: {file_path}")
            elif path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
        except PermissionError:
            errors.append(f"Permission denied: {file_path}")
        except Exception as e:
            errors.append(f"Error deleting {file_path}: {e}")

    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def delete_files_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    """Allow deletes inside the project (or worktree, for worktree sessions)."""
    return decide_write(ctx.input.paths, ctx.session, verb="delete")


delete_files_tool = Tool(
    id="delete",
    name="Delete Files",
    description="",
    input_schema=DeleteFilesInput,
    run=run_delete_files,
    approval=delete_files_approval,
    approval_view=ApprovalView(blocks=[
        ForEachBlock(
            field="paths",
            item_heading=".",
            template=[],
            separator="none",
            empty_text="No files to delete.",
        ),
    ]),
)
