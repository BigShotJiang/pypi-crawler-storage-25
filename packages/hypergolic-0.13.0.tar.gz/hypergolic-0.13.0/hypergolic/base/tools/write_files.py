from pydantic import Field

from hypergolic.base.tools.approvals.paths import decide_write
from hypergolic.toolkit.primitives import (
    ApprovalContext,
    InputSchema,
    Tool,
    ToolApprovalDecision,
    ToolContext,
    ToolResult,
)
from hypergolic.tools.approval_view import ApprovalView, CodeBlock, ForEachBlock
from hypergolic.tools.paths import resolve_path


class WriteFileEntry(InputSchema):
    path: str
    content: str = Field(description="Complete file contents (replaces existing)")


class WriteFilesInput(InputSchema):
    files: list[WriteFileEntry]


async def run_write_files(inp: WriteFilesInput, ctx: ToolContext) -> ToolResult:
    errors: list[str] = []

    for entry in inp.files:
        path = resolve_path(entry.path, ctx.session)
        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            path.write_text(entry.content, encoding="utf-8")
        except PermissionError:
            errors.append(f"Error writing {entry.path}: Permission denied")
        except Exception as e:
            errors.append(f"Error writing {entry.path}: {e}")

    if errors:
        return ToolResult(
            content=[{"type": "text", "text": "\n".join(errors)}],
            outcome="FAILURE",
        )

    return ToolResult(content=[{"type": "text", "text": "OK"}], outcome="SUCCESS")


def write_files_approval(ctx: ApprovalContext) -> ToolApprovalDecision:
    """Allow writes inside the project (or worktree, for worktree sessions).

    Worktree sessions can only write inside their own worktree directory;
    anything else is denied with a message. Non-worktree sessions fall back
    to REQUIRE_APPROVAL for out-of-scope paths.
    """
    return decide_write(
        [entry.path for entry in ctx.input.files],
        ctx.session,
        verb="write to",
    )


write_files_tool = Tool(
    id="write_files",
    name="Write Files",
    description="",
    input_schema=WriteFilesInput,
    run=run_write_files,
    approval=write_files_approval,
    approval_view=ApprovalView(blocks=[
        ForEachBlock(
            field="files",
            item_heading="path",
            template=[CodeBlock(
                field="content",
                language_from_path="path",
                max_height="third",
            )],
            empty_text="No files to write.",
        ),
    ]),
)
