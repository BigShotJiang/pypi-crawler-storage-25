"""Shared path-resolution and boundary-check helpers for tool approval functions.

The per-tool approval callbacks live **in each tool file** alongside the tool
they guard.  This module provides the reusable building blocks those callbacks
import.

## Worktree sessions

When ``session.worktree_path`` is set, the worktree directory **replaces**
the project directory as the session's scope. This means:

- Writes/edits/deletes inside the worktree are ALLOWed (no approval needed).
- Writes/edits/deletes outside the worktree are DENIed with a message
  explaining that worktree sessions can only modify their own directory.
  We never REQUIRE_APPROVAL in a worktree session because there is no user
  to approve (or because falling back to approval would subvert the whole
  isolation contract).
- Reads inside the worktree or on the readonly allowlist are ALLOWed.
- Reads outside both are DENIed, same reasoning as writes.
"""

from pathlib import Path

from hypergolic.base.tools.approvals.constants import (
    HYPERGOLIC_TOOLKIT_DIR,
    READONLY_ALLOWLIST,
)
from hypergolic.toolkit.primitives import ToolApprovalDecision
from hypergolic.schemas import Session
from hypergolic.tools.paths import resolve_path

ALLOW = ToolApprovalDecision(decision="ALLOW")
REQUIRE_APPROVAL = ToolApprovalDecision(decision="REQUIRE_APPROVAL")


def _worktree_deny(verb: str) -> ToolApprovalDecision:
    """A DENY decision with a message explaining the worktree sandbox."""
    return ToolApprovalDecision(
        decision="DENY",
        reason=(
            f"Worktree sessions can only {verb} paths inside their own "
            "worktree directory. If you need something outside, ask your "
            "parent session via `conclude` instead of attempting it here."
        ),
    )


def _resolved_allowlist(session: Session) -> list[Path]:
    return [resolve_path(p, session) for p in READONLY_ALLOWLIST]


def _project_dir(session: Session) -> Path:
    return Path(session.project_path).expanduser().resolve()


def _worktree_dir(session: Session) -> Path | None:
    worktree = getattr(session, "worktree_path", None)
    if not worktree:
        return None
    try:
        return Path(worktree).expanduser().resolve()
    except (OSError, RuntimeError):
        return None


def _is_within(path: Path, parent: Path) -> bool:
    """Return True if *path* is equal to or nested inside *parent*."""
    try:
        return path == parent or path.is_relative_to(parent)
    except (ValueError, TypeError):
        return False


def _is_toolkit_project(session: Session) -> bool:
    """Return True if the session's project IS the ~/.hypergolic toolkit."""
    toolkit = Path(str(HYPERGOLIC_TOOLKIT_DIR)).expanduser().resolve()
    project = _project_dir(session)
    return project == toolkit


# ---------------------------------------------------------------------------
# Boolean membership predicates
# ---------------------------------------------------------------------------


def in_worktree(raw_path: str, session: Session) -> bool:
    """True if *raw_path* is inside the session's worktree directory.

    False for sessions that don't have a worktree.
    """
    worktree = _worktree_dir(session)
    if worktree is None:
        return False
    return _is_within(resolve_path(raw_path, session), worktree)


def in_project_or_readonly_allowlist(
    raw_path: str,
    session: Session,
) -> bool:
    """True if *raw_path* is inside the project dir or on the readonly allowlist.

    For worktree sessions, the worktree directory replaces the project dir.
    """
    resolved = resolve_path(raw_path, session)
    worktree = _worktree_dir(session)
    if worktree is not None:
        if _is_within(resolved, worktree):
            return True
    else:
        if _is_within(resolved, _project_dir(session)):
            return True
    for allowed in _resolved_allowlist(session):
        if _is_within(resolved, allowed):
            return True
    return False


def in_project(raw_path: str, session: Session) -> bool:
    """True if *raw_path* is inside the project (or worktree) directory.

    For worktree sessions, the worktree directory replaces the project dir;
    the original project path does NOT count as "in the project" for a
    worktree child.
    """
    resolved = resolve_path(raw_path, session)
    worktree = _worktree_dir(session)
    if worktree is not None:
        return _is_within(resolved, worktree)
    return _is_within(resolved, _project_dir(session))


def in_project_or_toolkit(raw_path: str, session: Session) -> bool:
    """True if *raw_path* is in the project dir, or in ~/.hypergolic when the
    session's project IS the toolkit.

    For worktree sessions, the worktree replaces the project.
    """
    if in_project(raw_path, session):
        return True
    # Toolkit fallback only applies to non-worktree sessions; a worktree
    # session is strictly sandboxed to its own directory.
    if _worktree_dir(session) is not None:
        return False
    if _is_toolkit_project(session):
        toolkit = Path(str(HYPERGOLIC_TOOLKIT_DIR)).expanduser().resolve()
        return _is_within(resolve_path(raw_path, session), toolkit)
    return False


# ---------------------------------------------------------------------------
# Approval-decision helpers — centralize the "worktree DENY, else REQUIRE"
# branch so every tool's approval callback stays a one-liner.
# ---------------------------------------------------------------------------


def decide_write(
    raw_paths: list[str],
    session: Session,
    verb: str = "write to",
) -> ToolApprovalDecision:
    """Approval decision for a write/delete/mkdir-style tool.

    - All paths inside scope: ALLOW.
    - Worktree session with any out-of-scope path: DENY with message.
    - Non-worktree session with any out-of-scope path: REQUIRE_APPROVAL.
    """
    worktree = _worktree_dir(session)
    for p in raw_paths:
        if not in_project_or_toolkit(p, session):
            if worktree is not None:
                return _worktree_deny(verb)
            return REQUIRE_APPROVAL
    return ALLOW


def decide_read(
    raw_paths: list[str],
    session: Session,
) -> ToolApprovalDecision:
    """Approval decision for a read-style tool.

    - All paths inside scope or on the readonly allowlist: ALLOW.
    - Worktree session with any out-of-scope path: DENY with message.
    - Non-worktree session with any out-of-scope path: REQUIRE_APPROVAL.
    """
    worktree = _worktree_dir(session)
    for p in raw_paths:
        if not in_project_or_readonly_allowlist(p, session):
            if worktree is not None:
                return _worktree_deny("read")
            return REQUIRE_APPROVAL
    return ALLOW
