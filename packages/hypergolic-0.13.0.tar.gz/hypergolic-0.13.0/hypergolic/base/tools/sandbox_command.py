"""Sandbox command tool.

Executes shell commands inside a Docker sandbox container.
The sandbox is started lazily on first invocation and persists
for the lifetime of the session.
"""

import logging
from typing import Optional

from hypergolic.sandbox.manager import (
    ExecResult,
    SandboxError,
    SandboxUnavailableError,
    exec_in_sandbox,
    start_sandbox,
    _get_sandbox,
)
from hypergolic.toolkit.primitives import InputSchema, Tool, ToolContext, ToolResult

logger = logging.getLogger(__name__)


class SandboxCommandInput(InputSchema):
    command: str
    timeout: Optional[int] = 30


async def run_sandbox_command(inp: SandboxCommandInput, ctx: ToolContext) -> ToolResult:
    """Execute a command in the sandbox container.

    On first call, starts the sandbox container. Subsequent calls
    reuse the running container.
    """
    session_id = ctx.session.id
    tool_id = ctx.tool_id

    # Resolve the config path - the tool carries its sandbox_config_path
    # We look it up from the app's tool registry
    config_path = _resolve_sandbox_config_path(tool_id)
    if config_path is None:
        return ToolResult(
            content=[{"type": "text", "text": "No sandbox_config_path configured for this tool."}],
            outcome="FAILURE",
        )

    # Ensure sandbox is running (lazy start)
    sandbox = _get_sandbox(session_id, tool_id)
    if sandbox is None or sandbox.status not in ("running",):
        try:
            project_root = str(ctx.session.working_directory())
            await start_sandbox(
                session_id=session_id,
                tool_id=tool_id,
                config_path=config_path,
                project_root=project_root,
            )
        except SandboxUnavailableError as e:
            return ToolResult(
                content=[{"type": "text", "text": str(e)}],
                outcome="FAILURE",
            )
        except SandboxError as e:
            return ToolResult(
                content=[{"type": "text", "text": f"Sandbox startup failed: {e}"}],
                outcome="FAILURE",
            )

    # Execute the command
    try:
        result: ExecResult = await exec_in_sandbox(
            session_id=session_id,
            tool_id=tool_id,
            command=inp.command,
            timeout=inp.timeout or 30,
        )

        output_parts = []
        if result.stdout:
            output_parts.append(f"STDOUT:\n{result.stdout}")
        if result.stderr:
            output_parts.append(f"STDERR:\n{result.stderr}")
        output_parts.append(f"Exit code: {result.returncode}")

        text = "\n\n".join(output_parts)
        return ToolResult(
            content=[{"type": "text", "text": text}],
            outcome="FAILURE" if result.returncode != 0 else "SUCCESS",
        )

    except SandboxError as e:
        return ToolResult(
            content=[{"type": "text", "text": f"Sandbox error: {e}"}],
            outcome="FAILURE",
        )


def _resolve_sandbox_config_path(tool_id: str) -> str | None:
    """Look up the sandbox_config_path for a tool from the app registry."""
    from hypergolic.toolkit.app.state import get_app

    app = get_app()
    # Search all tools across app, projects, roles, skills
    for tool in app.tools:
        if tool.id == tool_id and tool.sandbox_config_path:
            return tool.sandbox_config_path
    for project in app.projects:
        for tool in project.tools:
            if tool.id == tool_id and tool.sandbox_config_path:
                return tool.sandbox_config_path
    for role in app.roles:
        for tool in role.tools:
            if tool.id == tool_id and tool.sandbox_config_path:
                return tool.sandbox_config_path
    for skill in app.skills:
        for tool in skill.tools:
            if tool.id == tool_id and tool.sandbox_config_path:
                return tool.sandbox_config_path
    return None


def make_sandbox_command_tool(config_path: str) -> Tool:
    """Create a sandbox command tool with a specific config path.

    This is the preferred way to create sandbox command tools,
    allowing different roles/skills to use different sandbox configs.
    """
    return Tool(
        id="sandbox_command",
        name="Sandbox Command",
        description=(
            "Run a command in a sandboxed Docker container that persists "
            "for your session. The project is mounted read-only at /workspace."
        ),
        input_schema=SandboxCommandInput,
        run=run_sandbox_command,
        approval="ALLOW",
        sandbox_config_path=config_path,
    )


# Default sandbox command tool for the base researcher role
sandbox_command_tool = make_sandbox_command_tool("~/.hypergolic/base/sandbox.yaml")
