import os
import sys
import threading

from hypergolic.enums import SessionStatus
from hypergolic.toolkit.primitives import Tool, ToolContext, ToolResult
from hypergolic.sessions.status import set_session_status


def _restart_after_delay(delay: float = 1.0) -> None:
    """Replace the current process with a fresh invocation after a delay."""
    import time

    time.sleep(delay)
    os.execv(sys.executable, [sys.executable, *sys.argv])


async def run_restart_server(ctx: ToolContext) -> ToolResult:
    set_session_status(ctx.session.id, SessionStatus.IDLE)

    thread = threading.Thread(target=_restart_after_delay, daemon=True)
    thread.start()

    return ToolResult(
        content=[
            {
                "type": "text",
                "text": "Server restart initiated. The process will re-launch in ~1 second.",
            }
        ],
        outcome="SUCCESS",
    )


restart_server_tool = Tool(
    id="restart_server",
    name="Restart Server",
    description="Restart the Hypergolic server to pick up toolkit changes (new tools, skills, configs). Use after editing ~/.hypergolic/main.py",
    run=run_restart_server,
    approval="REQUIRE_APPROVAL",
)
