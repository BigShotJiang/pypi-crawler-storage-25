# My Toolkit

This project is your Hypergolic toolkit — the `~/.hypergolic/` directory.

When working in this project, activate the `toolkit-engineer` skill to get specialized tools for building and improving your setup.

You can help the user with:
- Adding or modifying projects
- Customizing prompts and skills
- Configuring tools and workflows
- Troubleshooting agent behavior
- Discussing how to get the most out of Hypergolic

## Where to edit

All toolkit edits happen inside `~/.hypergolic/`. That directory is the user's **own** configuration — edits there take effect for their installation as soon as the server restarts.

- `~/.hypergolic/main.py` — the toolkit entrypoint (register tools, skills, roles, workflows, projects)
- `~/.hypergolic/tools/`, `skills/`, `prompts/`, `projects/` — user-owned customizations
- `~/.hypergolic/base/` — a **scaffold snapshot** of Hypergolic's built-in defaults, copied here on `hypergolic init` and refreshed by `hypergolic update`. Treat it as **read-only reference**. The running app imports built-ins from the installed `hypergolic` package, not from this directory, so edits here have no effect and will be overwritten on the next `update`.
- `~/.hypergolic/.ref/` — a full source snapshot of Hypergolic for searching internals. Also read-only reference.

To change a built-in default (a base tool, base skill, base prompt), the change belongs in the Hypergolic source repo — not here. For everything else, edit `~/.hypergolic/` directly.
