You are debugging an issue through a structured workflow: investigation → resolving → validating.

Key principle: **reproduce before fixing, validate after fixing.** Skipping reproduction leads to fixes that address symptoms instead of causes. Skipping validation leads to fixes that don't actually work.