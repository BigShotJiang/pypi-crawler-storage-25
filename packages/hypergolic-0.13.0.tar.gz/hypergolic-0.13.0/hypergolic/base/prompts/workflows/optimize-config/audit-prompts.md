You are auditing all prompt layers for quality, placement, and completeness.

## Prompt layers to evaluate

Read each prompt file in the assembly order:
1. **Role prompt** — the active role's prompt (usually default)
2. **User system prompt** — `~/.hypergolic/base/prompts/system.md`
3. **User custom prompts** — any prompts in `~/.hypergolic/prompts/`
4. **Project prompt** — the path specified by `Project.prompt_path` in `~/.hypergolic/main.py`
5. **Skill prompts** — any active skills' prompts

Use `read_toolkit_config` to inspect `~/.hypergolic/main.py` to find prompt paths for each project and skill.


## What to check

**Redundancy:** Is the same information repeated across layers? Content should live at exactly one level.

**Misplacement:** Is project-specific information in the user system prompt? Are personal preferences in the project prompt (which gets committed)? Common mistakes:
- Code style preferences in the project prompt when they're personal (should be user or user-level custom prompt)
- Project architecture in a user custom prompt when the team should see it (should be project prompt)
- Generic instructions in the project prompt that apply to all projects (should be user system prompt)

**Gaps:** What information is missing entirely?
- Does the project prompt explain the architecture, tech stack, key conventions?
- Does it document how to run tests, build, lint?
- Are there domain concepts the agent needs to understand?
- Are there team conventions (PR format, commit style, naming) that aren't documented?

**Verbosity:** Are prompts unnecessarily long? Every token in a prompt is consumed in every message. Remove instructions that don't pull their weight — things the agent would do anyway, or that apply so rarely they should be a skill instead.

**Quality:** Are instructions clear and actionable? Do they explain *why* not just *what*? Are there contradictions between layers?

## What to produce

A findings report with specific, actionable recommendations. For each issue:
- **location**: Which prompt file
- **issue**: What's wrong
- **recommendation**: What to change
- **priority**: high (actively hurting), medium (room for improvement), low (nice to have)