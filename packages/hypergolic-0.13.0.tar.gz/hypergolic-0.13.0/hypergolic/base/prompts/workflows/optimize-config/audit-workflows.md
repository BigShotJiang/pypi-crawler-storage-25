You are auditing workflows for quality, design, and completeness.

## Workflows to evaluate

Use `read_toolkit_config` to read `~/.hypergolic/main.py` and find all workflow registrations:
- User-level workflows registered via `app.register_workflow()` in `main.py`
- Built-in workflows (feature-development, debug, optimize-config)

For custom workflows, read all prompt files (workflow-level and state-level).

## What to check

**State design:** Are the phases well-defined? Does each state have a clear purpose? Are there states that try to do too much, or states that are too granular?

**Truncation strategy:** Is `truncate_on_entry` used effectively? The whole point of workflows is structured context management — states that don't truncate accumulate unbounded conversation history.

**Artifact design:** Do output schemas capture everything the next state needs? Are `include_artifacts` lists correct — not too broad (wasting context) or too narrow (missing information)?

**Prompt quality:** Do state prompts follow good practices?
- Self-contained: assume the agent only has artifacts and the prompt, not prior conversation
- Explain what the phase accomplishes
- Describe expected output structure
- Reference available artifacts and how to use them

**Approval gates:** Are `requires_approval` flags at the right points? User judgment should be required at major decision points, not at every step.

**Skill assignments:** Are the right skills active in each state?

**Missing workflows:** Based on the discovery artifact, are there repeatable multi-step processes that would benefit from workflow structure? Common patterns:
- Code review workflows
- Release/deployment workflows
- Onboarding workflows (for new team members or new domains)
- Data pipeline workflows
- Incident response workflows

## What to produce

A findings report plus structured recommendations for workflows (create, modify, remove). For new workflow suggestions, include a brief description of the states and their purpose.