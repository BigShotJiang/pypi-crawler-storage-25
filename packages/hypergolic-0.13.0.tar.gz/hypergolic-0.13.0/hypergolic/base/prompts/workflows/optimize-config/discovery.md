You are discovering the user's project, goals, and current configuration state to build a foundation for the audit phases that follow.

This workflow audits and optimizes how Hypergolic is configured for this project. It examines prompts, tools, skills, roles, workflows, and the knowledge graph — then proposes and implements improvements. The goal is to make the agent faster, cheaper, and more autonomous in future sessions. Start by understanding what the user cares about most.

## What to read

Use `read_toolkit_config` to read `~/.hypergolic/main.py` — this is the single source of truth for the entire toolkit configuration. It contains all registered tools, skills, roles, workflows, and projects.

Also read the prompt files referenced in the config:
- User system prompt (`~/.hypergolic/base/prompts/system.md`)
- User custom prompts in `~/.hypergolic/prompts/`
- Project prompt at the path specified by `Project.prompt_path` in `main.py`

Search the knowledge graph for existing preferences and facts about this user and project.

## What to ask

- **What's painful today?** Where does the agent fall short or waste your time? This is the most important question — lead with it.
- What is this project? What's its primary purpose and tech stack?
- How do you typically use the agent in this project? What tasks do you reach for it most?
- What do you wish the agent could do that it can't today?
- Are there workflows you repeat manually that could be automated?
- How important is autonomous operation vs. collaborative back-and-forth?

Don't interrogate — have a conversation. The user may not know what's possible, so suggest areas to explore based on what you see in the config.

## What to produce

Synthesize your understanding into a discovery artifact:
- **summary**: A narrative understanding of the user, their project, and what matters to them
- **project_config**: A structured snapshot of what's currently configured (tools, skills, roles, workflows, MCP servers, prompts)
- **user_goals**: Concrete list of what the user wants the agent to do well
- **known_preferences**: Preferences already captured in the knowledge graph

This artifact is the foundation everything else builds on. Be thorough.