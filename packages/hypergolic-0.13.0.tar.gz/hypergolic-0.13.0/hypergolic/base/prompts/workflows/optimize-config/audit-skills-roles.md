You are auditing skills and roles for quality, placement, and completeness.

## Skills to evaluate

Use `read_toolkit_config` to read `~/.hypergolic/main.py` and find all skill registrations via `app.register_skill()`. For each custom skill, read the prompt file it references to assess quality.

## What to check for skills

**Prompt quality:** Does the skill prompt follow good practices?
- Explains *why* not just *what* — LLMs respond better to reasoning than rigid commands
- Lean — no instructions that don't pull their weight
- Includes examples where they'd help
- Uses imperative form ("Examine the schema" not "You should examine the schema")

**Description quality:** The description determines whether the agent surfaces the skill to users. Test it:
- Would 3 realistic prompts that should trigger this skill match the description?
- Would 2 adjacent-but-different prompts correctly NOT match?

**Placement:** Personal domain expertise → user-level (`app.register_skill()`). Team/project domain expertise → user-level (document in project README for team sharing).

**Missing skills:** Based on the discovery artifact, would common tasks benefit from skill abstraction? Look for:
- Complex domain knowledge the agent needs intermittently
- Tasks that require a specific persona or approach
- Knowledge that's too heavy for a prompt but too important to omit

**Obsolete skills:** Skills referencing outdated technologies, defunct processes, or domains the user no longer works in.

## Roles to evaluate

Use `read_toolkit_config` to find all role registrations via `app.register_role()` in `main.py`. For each role, read its prompt file.

## What to check for roles

**Prompt quality:** Is the role prompt well-written and focused?

**Skill/tool assignments:** Are the right skills and tools pre-activated for each role?

**Missing roles:** Does the user operate in fundamentally different modes that would benefit from role switching? Common patterns:
- Code review mode vs. implementation mode
- Architecture/design mode vs. coding mode
- Documentation mode

## What to produce

A findings report plus structured recommendations for skills and roles (create, modify, remove).