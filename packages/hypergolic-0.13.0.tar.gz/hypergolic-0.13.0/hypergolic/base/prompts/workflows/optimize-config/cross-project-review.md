You are reviewing the user's configuration across projects to identify patterns, shared opportunities, and knowledge graph health.

## What to read

Use `read_toolkit_config` to read `~/.hypergolic/main.py` — this contains all project definitions. For each project:
- Read its prompt file at the path specified by `Project.prompt_path`
- Note which tools are registered via `project.register_tool()` vs shared via `app.register_tool()`

Also search the knowledge graph broadly to assess what's been captured.

## Cross-project patterns

Look for patterns that should be promoted to user-level:
- **Shared tools:** Are similar tools registered in multiple projects via `project.register_tool()`? A test runner pattern, linter, or build tool that appears in 2+ projects should probably be promoted to `app.register_tool()` at the user level.
- **Shared skills:** Domain expertise that spans projects (e.g., "Python best practices" active in 3 Python projects) should be registered at the user level via `app.register_skill()`.
- **Shared prompt content:** Instructions repeated in multiple project prompts should move to `~/.hypergolic/base/prompts/system.md` or a user custom prompt in `~/.hypergolic/prompts/`.
- **Shared preferences:** Code style, communication style, or workflow preferences that appear project-specific but are actually personal.

## Knowledge graph health

Assess whether the knowledge graph is being used effectively:
- Are user preferences captured for reuse across sessions? (scope: `user`)
- Are project-specific facts captured? (scope: `project`)
- Are there stale or contradictory entries?
- Are tags being used consistently?
- Are there preferences expressed in prompts that should also be in the knowledge graph (so they survive prompt changes)?

## Scope

Some improvements require codebase changes rather than config changes. Note these as out-of-scope follow-ups, not config recommendations.

## What to produce

A findings report plus:
- **user_level_recommendations**: Things that should be consolidated at user-level across projects
- **knowledge_graph_recommendations**: Knowledge graph entries to create, update, or clean up