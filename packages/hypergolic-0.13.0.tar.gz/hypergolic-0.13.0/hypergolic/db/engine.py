from contextlib import contextmanager
from typing import Iterator

from sqlalchemy import create_engine, event, Engine
from sqlalchemy.orm import Session
from sqlalchemy.pool import NullPool, StaticPool

from hypergolic.config.settings import settings

_engine: Engine | None = None


def _is_in_memory_sqlite(url: str) -> bool:
    return url in ("sqlite://", "sqlite:///:memory:")


def get_engine() -> Engine:
    global _engine
    if _engine is None:
        url = settings.HYPERGOLIC_DATABASE_URL
        if url.startswith("sqlite"):
            if _is_in_memory_sqlite(url):
                _engine = create_engine(
                    url,
                    connect_args={"check_same_thread": False},
                    poolclass=StaticPool,
                )
            else:
                _engine = create_engine(
                    url,
                    connect_args={"check_same_thread": False},
                    poolclass=NullPool,
                )

            @event.listens_for(_engine, "connect")
            def set_sqlite_pragma(dbapi_conn, connection_record):
                cursor = dbapi_conn.cursor()
                cursor.execute("PRAGMA journal_mode=WAL")
                cursor.execute("PRAGMA synchronous=NORMAL")
                cursor.execute("PRAGMA foreign_keys=ON")
                cursor.close()
        else:
            _engine = create_engine(url, poolclass=NullPool)
    return _engine


def reset_engine() -> None:
    global _engine
    if _engine is not None:
        _engine.dispose()
        _engine = None


@contextmanager
def get_db() -> Iterator[Session]:
    with Session(get_engine(), expire_on_commit=False) as session:
        with session.begin():
            yield session
