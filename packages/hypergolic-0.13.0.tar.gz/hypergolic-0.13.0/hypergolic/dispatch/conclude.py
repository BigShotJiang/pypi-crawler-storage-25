import asyncio
import logging
from datetime import datetime, timezone
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, Field
from sqlalchemy import update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.dispatch.core import DispatchResult, resolve_dispatch
from hypergolic.enums import SessionStatus
from hypergolic.git.commands import run_git_command
from hypergolic.git.worktree import delete_branch, remove_worktree
from hypergolic.messages.types import BroadcastEvent
from hypergolic.sandbox.manager import cleanup_session_sandboxes
from hypergolic.schemas import Session
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput

logger = logging.getLogger(__name__)


async def _safe_cleanup_sandboxes(session_id: str) -> None:
    """Clean up sandboxes, logging but not raising on failure."""
    try:
        await cleanup_session_sandboxes(session_id)
    except Exception:
        logger.warning(
            "Failed to clean up sandboxes for session %s",
            session_id,
            exc_info=True,
        )


class ConcludeInput(BaseModel):
    outcome: Literal["success", "failure", "suppressed"]
    conclusion: str
    merge_ready: bool = Field(
        default=False,
        description=(
            "Worktree sessions only. A recommendation to the parent that "
            "this branch is ready to be merged. Purely advisory \u2014 it does "
            "not authorize any destructive action."
        ),
    )


def _set_concluded_at(session_id: str) -> datetime:
    concluded_at = datetime.now(timezone.utc)
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(concluded_at=concluded_at)
        )
    return concluded_at


def _clear_worktree_path(session_id: str) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(worktree_path=None)
        )


def _clear_worktree_branch(session_id: str) -> None:
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(worktree_branch=None, base_branch=None)
        )


def _worktree_is_dirty(worktree_path: Path) -> tuple[bool, str]:
    """Return (dirty, porcelain_output) for the worktree."""
    result = run_git_command(
        "status", "--porcelain", "-uall", cwd=worktree_path
    )
    output = result.stdout.strip()
    return bool(output), output


def _branch_has_commits(worktree_path: Path, branch: str, base_branch: str) -> bool:
    """True if *branch* has at least one commit beyond *base_branch*."""
    result = run_git_command(
        "rev-list", "--count", f"{base_branch}..{branch}",
        cwd=worktree_path,
    )
    if result.returncode != 0:
        # If we can't compute, assume there are commits so we don't auto-delete.
        return True
    try:
        return int(result.stdout.strip() or "0") > 0
    except ValueError:
        return True


def _teardown_worktree_at_conclude(session: Session) -> str | None:
    """Apply the PRD section 6b teardown rules.

    Returns the branch name that survives (for :class:`DispatchResult`), or
    ``None`` if the branch was deleted or there was no worktree to begin with.

    Raises :class:`DirtyWorktreeError` if the worktree has uncommitted
    changes \u2014 the caller should surface this back to the agent as a
    tool-level error.
    """
    worktree_path = session.worktree_path
    branch = session.worktree_branch
    base_branch = session.base_branch
    project_path = session.project_path

    if not worktree_path or not branch or not base_branch:
        return branch

    wt = Path(worktree_path)
    if not wt.exists():
        # Directory already gone \u2014 keep branch metadata as-is.
        _clear_worktree_path(session.id)
        return branch

    dirty, status_text = _worktree_is_dirty(wt)
    if dirty:
        raise DirtyWorktreeError(status_text)

    has_commits = _branch_has_commits(wt, branch, base_branch)

    # Remove the directory in either case.
    try:
        remove_worktree(worktree_path=wt, project_path=project_path)
    except Exception:
        logger.warning("remove_worktree failed for %s", wt, exc_info=True)

    _clear_worktree_path(session.id)

    if not has_commits:
        # Branch has nothing worth preserving \u2014 drop it.
        delete_branch(branch=branch, project_path=project_path, force=True)
        _clear_worktree_branch(session.id)
        return None

    return branch


class DirtyWorktreeError(Exception):
    """Raised when conclude is called on a worktree with uncommitted changes."""

    def __init__(self, porcelain_output: str) -> None:
        super().__init__("worktree has uncommitted changes")
        self.porcelain_output = porcelain_output


def _format_dirty_error(err: DirtyWorktreeError) -> str:
    return (
        "Cannot conclude: the worktree has uncommitted changes. "
        "Either commit them (`git add -A && git commit -m ...`) to preserve "
        "the work on your branch, or discard them explicitly "
        "(`git reset --hard && git clean -fd`), then call conclude again.\n\n"
        "```\n"
        f"{err.porcelain_output}\n"
        "```"
    )


async def _handle_conclude(inp: ConcludeInput, ctx: ToolContext) -> ToolOutput:
    session = ctx.session

    # Worktree guardrail + teardown, if applicable.
    surviving_branch: str | None = None
    if session.worktree_path:
        try:
            surviving_branch = _teardown_worktree_at_conclude(session)
        except DirtyWorktreeError as err:
            return ToolOutput.text(_format_dirty_error(err), is_error=True)
    else:
        surviving_branch = session.worktree_branch

    result = DispatchResult(
        outcome=inp.outcome,
        conclusion=inp.conclusion,
        merge_ready=inp.merge_ready,
        worktree_branch=surviving_branch,
    )
    resolved = resolve_dispatch(session.id, result)

    if not resolved:
        parent_id = session.parent_id
        if parent_id:
            await set_session_status_and_broadcast(
                session.id, SessionStatus.CONCLUDED, ctx.broadcast,
            )
            _set_concluded_at(session.id)
            asyncio.ensure_future(_safe_cleanup_sandboxes(session.id))
            return ToolOutput.text(f"Session concluded with outcome: {inp.outcome}")
        return ToolOutput.text("No pending dispatch to conclude.", is_error=True)

    await set_session_status_and_broadcast(
        session.id, SessionStatus.CONCLUDED, ctx.broadcast,
    )
    _set_concluded_at(session.id)

    # Clean up any sandbox containers for this session
    asyncio.ensure_future(_safe_cleanup_sandboxes(session.id))

    parent_id = session.parent_id
    if parent_id:
        await ctx.broadcast(BroadcastEvent(
            type="dispatch_concluded",
            role="system",
            content=[],
            session_id=session.id,
        ))

    return ToolOutput.text(f"Session concluded with outcome: {inp.outcome}")


ConcludeTool = Tool(
    id="conclude",
    name="conclude",
    description="Conclude this dispatched session and return the result to the parent session. Use 'success' when you have an answer, 'failure' when you cannot answer, or 'suppressed' to cancel",
    input=ConcludeInput,
    call_tool=_handle_conclude,
    source="dispatch",
)
