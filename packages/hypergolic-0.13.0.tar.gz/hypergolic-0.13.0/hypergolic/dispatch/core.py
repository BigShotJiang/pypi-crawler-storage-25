import asyncio
import logging
from dataclasses import dataclass
from typing import Any, Callable

from anthropic.types import Message, MessageParam, TextBlock, TextBlockParam

from sqlalchemy import select

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject, DBSession
from hypergolic.db.utils import to_iso_utc
from hypergolic.enums import ModelTier, SessionStatus
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.sandbox.manager import cleanup_session_sandboxes
from hypergolic.sessions.operations import create_session, load_session
from hypergolic.sessions.status import set_session_status


def _build_child_session_payload(child_session_id: str, parent_session_id: str) -> dict:
    with get_db() as db:
        row = db.execute(
            select(DBSession, DBProject.name)
            .join(DBProject, DBSession.project_id == DBProject.id)
            .where(DBSession.id == child_session_id)
        ).one()
        child_db, project_name = row

    return {
        "id": child_db.id,
        "model_tier": child_db.model_tier,
        "project_id": child_db.project_id,
        "project_name": project_name,
        "role": child_db.role,
        "status": child_db.status,
        "created_at": to_iso_utc(child_db.created_at),
        "updated_at": to_iso_utc(child_db.updated_at),
        "message_count": 0,
        "workflow_id": None,
        "workflow_name": None,
        "workflow_state_id": None,
        "workflow_state_name": None,
        "parent_id": parent_session_id,
        "description": None,
        "conclusion_rating": None,
        "conclusion_feedback": None,
        "concluded_at": None,
    }

logger = logging.getLogger(__name__)

TurnRunnerFn = Callable[[str, MessageParam], Any]


@dataclass
class DispatchResult:
    outcome: str  # "success", "failure", "suppressed"
    conclusion: str
    merge_ready: bool = False
    worktree_branch: str | None = None


_pending_dispatches: dict[str, asyncio.Future[DispatchResult]] = {}
_child_to_parent: dict[str, str] = {}
_turn_runner: TurnRunnerFn | None = None


def register_turn_runner(runner: TurnRunnerFn) -> None:
    global _turn_runner
    _turn_runner = runner


def resolve_dispatch(session_id: str, result: DispatchResult) -> bool:
    future = _pending_dispatches.pop(session_id, None)
    if future and not future.done():
        future.set_result(result)
        _child_to_parent.pop(session_id, None)
        return True
    return False


def _extract_final_text(response: Message) -> str:
    parts = []
    for block in response.content:
        if isinstance(block, TextBlock):
            parts.append(block.text)
    return "\n".join(parts) if parts else "<no text content>"


def auto_conclude_if_needed(session_id: str, parent_id: str | None, response: Message) -> bool:
    if not parent_id:
        return False
    future = _pending_dispatches.get(session_id)
    if not future or future.done():
        return False

    final_text = _extract_final_text(response)
    conclusion = (
        f"Child session ({session_id}) ended its turn without calling conclude. "
        f"Final message content:\n{final_text}"
    )
    logger.warning("Auto-concluding child session %s (parent: %s)", session_id, parent_id)
    resolve_dispatch(session_id, DispatchResult(outcome="success", conclusion=conclusion))
    return True


def fail_dispatch_if_child(session_id: str, error_detail: str) -> bool:
    parent_id = _child_to_parent.get(session_id)
    if not parent_id:
        return False
    conclusion = f"Child session ({session_id}) failed with error: {error_detail}"
    logger.warning("Failing child dispatch %s (parent: %s): %s", session_id, parent_id, error_detail)
    # Schedule sandbox cleanup (fire-and-forget)
    _schedule_sandbox_cleanup(session_id)
    return resolve_dispatch(session_id, DispatchResult(outcome="failure", conclusion=conclusion))


def cancel_child_dispatches(parent_session_id: str) -> None:
    children_to_cancel = [
        child_id for child_id, parent_id in _child_to_parent.items()
        if parent_id == parent_session_id
    ]
    for child_id in children_to_cancel:
        future = _pending_dispatches.pop(child_id, None)
        if future and not future.done():
            future.set_result(DispatchResult(outcome="suppressed", conclusion="Parent session was interrupted"))
        _child_to_parent.pop(child_id, None)
        set_session_status(child_id, SessionStatus.INTERRUPTED)
        # Schedule sandbox cleanup (fire-and-forget)
        _schedule_sandbox_cleanup(child_id)
        logger.info("Interrupted child session %s (parent: %s)", child_id, parent_session_id)


def _schedule_sandbox_cleanup(session_id: str) -> None:
    """Schedule sandbox cleanup as a fire-and-forget task."""
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            asyncio.ensure_future(_safe_cleanup_sandboxes(session_id))
        else:
            loop.run_until_complete(_safe_cleanup_sandboxes(session_id))
    except RuntimeError:
        logger.warning(
            "Could not schedule sandbox cleanup for session %s (no event loop)",
            session_id,
        )


async def _safe_cleanup_sandboxes(session_id: str) -> None:
    """Clean up sandboxes, logging but not raising on failure."""
    try:
        await cleanup_session_sandboxes(session_id)
    except Exception:
        logger.warning(
            "Failed to clean up sandboxes for session %s",
            session_id,
            exc_info=True,
        )


CONCLUDE_INSTRUCTION = (
    "\n\nCRITICAL: You MUST call `conclude` as your final action "
    "\u2014 the parent session is deadlocked until you do. "
    "Never end your turn without calling conclude."
)


async def dispatch(
    parent_session_id: str,
    content_blocks: list[dict[str, Any]],
    dispatch_prompt: str,
    broadcast: BroadcastFn,
    role: str,
    model_tier: ModelTier | None = None,
    worktree: bool = False,
) -> DispatchResult:
    if not _turn_runner:
        raise RuntimeError("No turn runner registered. Dispatch is not available in this context.")

    parent_session = load_session(parent_session_id)
    full_prompt = dispatch_prompt + CONCLUDE_INSTRUCTION

    child_session = create_session(
        project_id=parent_session.project_id,
        model_tier=model_tier,
        role=role,
        parent_id=parent_session_id,
        dispatch_prompt=full_prompt,
        worktree=worktree,
    )

    blocks: list[TextBlockParam] = [
        TextBlockParam(type="text", text=b["text"]) for b in content_blocks if b.get("type") == "text"
    ]
    user_message: MessageParam = {
        "role": "user",
        "content": blocks,
    }

    loop = asyncio.get_event_loop()
    future: asyncio.Future[DispatchResult] = loop.create_future()
    _pending_dispatches[child_session.id] = future
    _child_to_parent[child_session.id] = parent_session_id

    child_payload = _build_child_session_payload(child_session.id, parent_session_id)

    await broadcast(BroadcastEvent(
        type="dispatch_started",
        role="system",
        content=[{
            "child_session_id": child_session.id,
            "child_session": child_payload,
        }],
        session_id=parent_session_id,
    ))

    _turn_runner(child_session.id, user_message)

    try:
        return await future
    except asyncio.CancelledError:
        _pending_dispatches.pop(child_session.id, None)
        _child_to_parent.pop(child_session.id, None)
        set_session_status(child_session.id, SessionStatus.INTERRUPTED)
        return DispatchResult(outcome="suppressed", conclusion="Parent session was interrupted")
    finally:
        _pending_dispatches.pop(child_session.id, None)
        _child_to_parent.pop(child_session.id, None)
