import logging

from anthropic.types import Message, MessageParam, TextBlockParam

from hypergolic.config.settings import PROMPTS_DIR, settings
from hypergolic.messages.block_guards import (
    is_text_block,
    is_tool_result_block,
    is_tool_use_block,
    iter_content_blocks,
)
from hypergolic.providers import create_client, tier_to_model_id
from hypergolic.schemas import Session

logger = logging.getLogger(__name__)

TOOL_RESULT_MAX_CHARS = 2000
SUMMARIZE_PROMPT_PATH = PROMPTS_DIR / "summarize_prompt.md"


def _truncate_tool_result(text: str, max_chars: int = TOOL_RESULT_MAX_CHARS) -> str:
    if len(text) <= max_chars:
        return text
    return text[:max_chars] + "\n\u2026 (content truncated for brevity)"


def build_conversation_transcript(messages: list[MessageParam]) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    for msg in messages:
        role = msg.get("role", "user")
        raw_content = msg.get("content", [])

        if isinstance(raw_content, str):
            if raw_content.strip():
                blocks.append({"type": "text", "text": f"[{role}]: {raw_content}"})
            continue

        text_parts: list[str] = []
        for block in iter_content_blocks(raw_content):
            if is_text_block(block):
                text = block.get("text", "")
                if text.strip():
                    text_parts.append(text)
            elif is_tool_use_block(block):
                name = block.get("name", "unknown")
                inp = block.get("input", {})
                text_parts.append(f"[Tool call: {name}({inp})]")
            elif is_tool_result_block(block):
                tool_content = block.get("content", [])
                is_error = block.get("is_error", False)
                prefix = "Tool error" if is_error else "Tool result"
                if isinstance(tool_content, str):
                    text_parts.append(f"[{prefix}: {_truncate_tool_result(tool_content)}]")
                elif isinstance(tool_content, list):
                    for sub in tool_content:
                        if is_text_block(sub):
                            text_parts.append(
                                f"[{prefix}: {_truncate_tool_result(sub.get('text', ''))}]"
                            )

        if text_parts:
            combined = "\n".join(text_parts)
            blocks.append({"type": "text", "text": f"[{role}]: {combined}"})

    return blocks


def _build_system_prompt(session: Session) -> list[TextBlockParam]:
    blocks: list[TextBlockParam] = []

    if SUMMARIZE_PROMPT_PATH.exists():
        blocks.append({"type": "text", "text": SUMMARIZE_PROMPT_PATH.read_text()})

    return blocks


def extract_summary_text(response: Message) -> str:
    summary_text = ""
    for block in response.content:
        if getattr(block, "type", None) == "text":
            summary_text += getattr(block, "text", "")

    if not summary_text.strip():
        raise ValueError("Summarization model returned empty response.")

    return summary_text


def _build_artifact_context_block(artifacts: list[tuple[str, dict, str]]) -> TextBlockParam | None:
    if not artifacts:
        return None
    lines = [
        "The agent receiving this summary will already have the following workflow artifacts "
        "injected into its system prompt. Do NOT duplicate their content in your summary \u2014 "
        "instead, refer to them by name. Focus on conversational context, decisions, progress, "
        "and current state that the artifacts don't capture.",
        "",
    ]
    for artifact_id, content, created_at in artifacts:
        keys = list(content.keys()) if isinstance(content, dict) else []
        lines.append(f"- **{artifact_id}** (created {created_at}): fields: {', '.join(keys) or 'empty'}")
    return {"type": "text", "text": "\n".join(lines)}


async def call_summarization_model(
    session: Session,
    messages: list[MessageParam],
    available_artifacts: list[tuple[str, dict, str]] | None = None,
) -> Message:
    client = create_client()
    model_id = tier_to_model_id(session.model_tier)
    system_prompt = _build_system_prompt(session)

    artifact_block = _build_artifact_context_block(available_artifacts or [])
    if artifact_block:
        system_prompt.append(artifact_block)

    transcript_blocks = build_conversation_transcript(messages)
    if not transcript_blocks:
        raise ValueError("No message content to summarize after flattening.")

    transcript_blocks.append({
        "type": "text",
        "text": "Please summarize this conversation now.",
    })

    summarize_messages: list[MessageParam] = [
        {"role": "user", "content": transcript_blocks},
    ]

    response = await client.messages.create(
        max_tokens=settings.MAX_TOKENS,
        model=model_id,
        messages=summarize_messages,
        system=system_prompt,
    )

    extract_summary_text(response)
    return response
