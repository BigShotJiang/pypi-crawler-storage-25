from dataclasses import dataclass
from typing import Any, Awaitable, Callable


# Up to MAX_STREAM_RETRIES + 1 total attempts. Delays between attempts are
# linear: RETRY_BASE_DELAY * (attempt + 1) → 1s, 2s, 3s, ...
MAX_STREAM_RETRIES = 3
RETRY_BASE_DELAY = 1.0

EXCLUDED_CONTENT_FIELDS = {"parsed_output", "caller"}
EXCLUDED_FIELDS = {"parsed_output", "caller"}

INTERRUPTED_SUFFIX = "\n\n---\n*[Response interrupted by user]*"


class UserInterrupt(Exception):
    def __init__(self, partial_text: str | None = None):
        super().__init__()
        self.partial_text = partial_text


# TODO: type `content` more strictly — currently Any because each event type
# (content_block_start, tool_result, session_status_change, workflow_state_change, etc.)
# puts different shapes in here. A union of typed event dataclasses would be ideal.
@dataclass
class BroadcastEvent:
    type: str
    role: str
    content: Any
    session_id: str | None = None
    model: str | None = None
    stop_reason: str | None = None
    message_id: str | None = None
    usage: dict | None = None


BroadcastFn = Callable[[BroadcastEvent], Awaitable[None]]
