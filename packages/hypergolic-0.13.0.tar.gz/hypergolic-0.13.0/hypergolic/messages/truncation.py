import logging

from anthropic.types import MessageParam, TextBlockParam
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.enums import SessionStatus
from hypergolic.toolkit.app.state import get_app
from hypergolic.messages.persistence import (
    load_session_messages,
    persist_agent_message,
    persist_user_message,
)
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.schemas import Session
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.messages.summarization import call_summarization_model, extract_summary_text
from hypergolic.workflows.engine import load_artifacts
from hypergolic.workflows.resolver import get_session_workflow, get_workflow

logger = logging.getLogger(__name__)

DEFAULT_TRUNCATE_TOKEN_THRESHOLD = 200_000


def _get_threshold() -> int:
    try:
        return get_app().truncate_token_threshold
    except RuntimeError:
        return DEFAULT_TRUNCATE_TOKEN_THRESHOLD


def should_truncate(session_id: str) -> bool:
    with get_db() as db:
        row = db.execute(
            select(DBMessage)
            .where(DBMessage.session_id == session_id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .where(DBMessage.role == "assistant")
            .order_by(DBMessage.created_at.desc())
            .limit(1)
        ).scalar_one_or_none()

        if row is None or row.usage is None:
            return False

        input_tokens = (
            row.usage.get("input_tokens", 0)
            + row.usage.get("cache_read_input_tokens", 0)
            + row.usage.get("cache_creation_input_tokens", 0)
        )
        return input_tokens > _get_threshold()


def _get_workflow_artifact_ids(session: Session) -> list[str]:
    wf_state = get_session_workflow(session.id)
    if not wf_state:
        return []

    workflow_id, current_state_id = wf_state
    wf = get_workflow(workflow_id)
    if not wf:
        return []

    for s in wf.states:
        if s.id == current_state_id:
            return s.include_artifacts
    return []


async def truncate_conversation(
    session: Session, broadcast: BroadcastFn
) -> None:
    logger.info("Truncating conversation for session %s", session.id)

    await set_session_status_and_broadcast(
        session.id, SessionStatus.TRUNCATING, broadcast
    )

    messages = load_session_messages(session.id)
    if not messages:
        return

    included_artifact_ids = _get_workflow_artifact_ids(session)
    artifacts = load_artifacts(session.id, included_artifact_ids) if included_artifact_ids else []

    response = await call_summarization_model(
        session=session,
        messages=messages,
        available_artifacts=artifacts,
    )
    await persist_agent_message(session_id=session.id, message=response)
    summary_text = f"[Conversation Summary]\n\n{extract_summary_text(response)}"

    with get_db() as db:
        db.execute(
            update(DBMessage)
            .where(DBMessage.session_id == session.id)
            .where(DBMessage.truncated == False)  # noqa: E712
            .values(truncated=True)
        )

    summary_message = MessageParam(
        role="user",
        content=[
            TextBlockParam(
                type="text",
                text=summary_text,
            )
        ],
    )
    await persist_user_message(session_id=session.id, message=summary_message)

    logger.info("Conversation truncated for session %s", session.id)

    await broadcast(
        BroadcastEvent(
            type="truncated",
            role="system",
            content=[],
            session_id=session.id,
        )
    )
