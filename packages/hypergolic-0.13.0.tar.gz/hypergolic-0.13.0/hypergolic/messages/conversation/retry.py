import asyncio
import logging
from typing import Any, Callable

import httpx
from anthropic import APIConnectionError, APIStatusError
from anthropic.types import (
    Message,
    MessageParam,
    RawContentBlockStartEvent,
)

from hypergolic.enums import SessionStatus
from hypergolic.messages.conversation.interrupts import (
    _extract_partial_text,
    _persist_partial_assistant_message,
)
from hypergolic.messages.streaming import handle_streaming_event
from hypergolic.messages.types import (
    MAX_STREAM_RETRIES,
    RETRY_BASE_DELAY,
    BroadcastFn,
    UserInterrupt,
)
from hypergolic.config.settings import settings
from hypergolic.providers import AsyncClient, tier_to_model_id
from hypergolic.schemas import Session
from hypergolic.sessions.status import set_session_status_and_broadcast

logger = logging.getLogger(__name__)

# httpx.ReadTimeout is listed explicitly: when a timeout occurs mid-stream
# (after some bytes have flowed), it propagates as a raw httpx error rather
# than being wrapped as APIConnectionError by the Anthropic SDK.
RETRYABLE_EXCEPTIONS = (APIConnectionError, httpx.ReadTimeout)


def _is_retryable_status(exc: APIStatusError) -> bool:
    return exc.status_code in (429, 500, 502, 503, 529)


async def stream_response(
    client: AsyncClient,
    session: Session,
    prompt: list[Any],
    tool_schemas: list[Any],
    messages: list[MessageParam],
    broadcast: BroadcastFn,
    check_cancelled: Callable[[], None],
    tool_display_names: dict[str, str] | None = None,
) -> Message:
    streaming_started = False
    last_stream_error: Exception | None = None

    for attempt in range(MAX_STREAM_RETRIES + 1):
        try:
            async with client.messages.stream(
                max_tokens=settings.MAX_TOKENS,
                model=tier_to_model_id(session.model_tier),
                messages=messages,
                system=prompt,
                tools=tool_schemas,
            ) as stream:
                async for event in stream:
                    check_cancelled()
                    if not streaming_started and isinstance(
                        event, RawContentBlockStartEvent
                    ):
                        streaming_started = True
                        await set_session_status_and_broadcast(
                            session.id, SessionStatus.STREAMING, broadcast
                        )
                    await handle_streaming_event(event, broadcast, session.id, tool_display_names)
                response = await stream.get_final_message()
            return response
        except UserInterrupt:
            partial_text = _extract_partial_text(stream)
            if partial_text:
                await _persist_partial_assistant_message(
                    session_id=session.id, text=partial_text
                )
            raise UserInterrupt(partial_text=partial_text)
        except RETRYABLE_EXCEPTIONS as exc:
            last_stream_error = exc
            if attempt < MAX_STREAM_RETRIES:
                delay = RETRY_BASE_DELAY * (attempt + 1)
                logger.warning(
                    "Stream attempt %d failed (%s), retrying in %.1fs",
                    attempt + 1,
                    exc,
                    delay,
                )
                await asyncio.sleep(delay)
                continue
        except APIStatusError as exc:
            if _is_retryable_status(exc) and attempt < MAX_STREAM_RETRIES:
                last_stream_error = exc
                delay = RETRY_BASE_DELAY * (attempt + 1)
                logger.warning(
                    "Stream attempt %d failed (HTTP %d), retrying in %.1fs",
                    attempt + 1,
                    exc.status_code,
                    delay,
                )
                await asyncio.sleep(delay)
                continue
            raise

    assert last_stream_error is not None
    raise last_stream_error
