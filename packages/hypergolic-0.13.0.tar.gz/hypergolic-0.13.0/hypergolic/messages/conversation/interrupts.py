from typing import Any

from anthropic.types import (
    Message,
    MessageParam,
    TextBlockParam,
    ToolResultBlockParam,
    ToolUseBlock,
)

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBMessage
from hypergolic.messages.persistence import persist_user_message
from hypergolic.messages.types import INTERRUPTED_SUFFIX


def _extract_partial_text(stream: Any) -> str | None:
    try:
        snapshot = stream.current_message_snapshot
    except Exception:
        return None
    if not snapshot or not snapshot.content:
        return None
    text_parts = [
        block.text
        for block in snapshot.content
        if getattr(block, "type", None) == "text" and getattr(block, "text", None)
    ]
    return "\n\n".join(text_parts) if text_parts else None


async def _persist_partial_assistant_message(session_id: str, text: str) -> None:
    with get_db() as db:
        db_message = DBMessage(
            session_id=session_id,
            content=[{"type": "text", "text": text + INTERRUPTED_SUFFIX}],
            model=None,
            role="assistant",
            stop_reason="interrupted",
            stop_sequence=None,
            usage=None,
        )
        db.add(db_message)


def _build_interrupt_tool_results(response: Message) -> MessageParam | None:
    tool_blocks = [b for b in response.content if isinstance(b, ToolUseBlock)]
    if not tool_blocks:
        return None
    result_blocks: list[ToolResultBlockParam] = [
        ToolResultBlockParam(
            tool_use_id=b.id,
            type="tool_result",
            content=[TextBlockParam(type="text", text="Interrupted by user")],
            is_error=True,
        )
        for b in tool_blocks
    ]
    return MessageParam(role="user", content=result_blocks)


async def persist_interrupt_tool_results(session_id: str, response: Message) -> None:
    interrupt_result = _build_interrupt_tool_results(response)
    if interrupt_result:
        await persist_user_message(session_id=session_id, message=interrupt_result)
