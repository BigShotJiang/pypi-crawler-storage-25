from copy import deepcopy
from typing import Any, cast

from anthropic.types import MessageParam


def _strip_cache_control(messages: list[MessageParam]) -> None:
    for message in messages:
        if not isinstance(message, dict):
            continue
        raw_content = message.get("content")
        if not raw_content or not isinstance(raw_content, list):
            continue
        for block in raw_content:
            if isinstance(block, dict) and "cache_control" in block:
                raw = cast(dict[str, Any], block)
                del raw["cache_control"]


def _is_cacheable_block(block: Any) -> bool:
    """Return True if a breakpoint can be pinned on this block.

    The Anthropic API rejects ``cache_control`` on empty text blocks with
    ``400 invalid_request_error``. Non-dict blocks can't carry the key at all.
    Text blocks must have non-empty ``text``; other block types (tool_use,
    tool_result, image, ...) are accepted as-is.
    """
    if not isinstance(block, dict):
        return False
    if block.get("type") == "text":
        text = block.get("text")
        return isinstance(text, str) and text != ""
    return True


def set_message_cache_breakpoint(
    messages: list[MessageParam],
) -> list[MessageParam]:
    result = deepcopy(messages)
    _strip_cache_control(result)

    if len(result) >= 2:
        target_msg = result[-2]
    else:
        target_msg = result[-1]

    if not isinstance(target_msg, dict):
        return result
    raw_content = target_msg.get("content")
    # Only tag when the content is an actual list of blocks. A string or
    # non-list content (or an empty list) has nothing to pin a breakpoint to.
    if not isinstance(raw_content, list) or len(raw_content) == 0:
        return result

    # Walk blocks from the end and pin the breakpoint on the last *cacheable*
    # block. Empty text blocks must be skipped — the API rejects
    # cache_control on them. If no block is cacheable, skip silently.
    for block in reversed(raw_content):
        if _is_cacheable_block(block):
            raw = cast(dict[str, Any], block)
            raw["cache_control"] = {"type": "ephemeral"}
            break
    return result
