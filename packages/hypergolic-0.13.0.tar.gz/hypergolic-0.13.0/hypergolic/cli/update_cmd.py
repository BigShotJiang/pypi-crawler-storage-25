import shutil
from pathlib import Path

import typer
from rich.console import Console

from hypergolic.cli.init_cmd import generate_pyproject, setup_gitignore
from hypergolic.cli.version import get_version

console = Console()

HYPERGOLIC_DIR = Path.home() / ".hypergolic"


def _package_base_dir() -> Path:
    return Path(__file__).resolve().parent.parent / "base"


def _package_source_dir() -> Path:
    return Path(__file__).resolve().parent.parent


def update() -> None:
    """Regenerate ~/.hypergolic/base/ and sync .ref/ from installed package."""
    if not HYPERGOLIC_DIR.exists():
        console.print(f"[red]Error:[/] {HYPERGOLIC_DIR} does not exist. Run `hypergolic init` first.")
        raise typer.Exit(1)

    version = get_version()
    console.print(f"Updating base files (hypergolic {version})...")

    base_dest = HYPERGOLIC_DIR / "base"
    if base_dest.exists():
        shutil.rmtree(base_dest)
    base_src = _package_base_dir()
    if base_src.exists():
        shutil.copytree(base_src, base_dest)
        console.print(f"  Synced {base_dest}")

    ref_dest = HYPERGOLIC_DIR / ".ref"
    if ref_dest.exists():
        shutil.rmtree(ref_dest)
    source = _package_source_dir()
    if source.exists():
        shutil.copytree(source, ref_dest, ignore=shutil.ignore_patterns("__pycache__", "*.pyc", "ui_dist"))
        console.print(f"  Synced {ref_dest}")

    generate_pyproject()
    setup_gitignore()

    console.print(f"\n[green]\u2713 Base files updated to {version}[/]")
