"""Tests for hypergolic.files.router."""

from pathlib import Path
from unittest.mock import patch

import pytest

from hypergolic.files.router import _detect_language, _resolve_project_path
from hypergolic.files.schemas import FileNode, FileSearchMatch
from tests.conftest import make_project

ROUTER = "hypergolic.files.router"


# ── GET /api/files/tree ───────────────────────────────────────────────


def test_file_tree_returns_nested_nodes(api_client):
    tree = [
        FileNode(name="src", path="src", is_dir=True, children=[
            FileNode(name="main.py", path="src/main.py", is_dir=False, git_status="M"),
        ]),
        FileNode(name="README.md", path="README.md", is_dir=False),
    ]
    with (
        patch(f"{ROUTER}.get_repo_root", return_value="/tmp/repo"),
        patch(f"{ROUTER}.build_file_tree", return_value=tree),
    ):
        resp = api_client.get("/api/files/tree")
    assert resp.status_code == 200
    data = resp.json()
    assert data["root"] == "/tmp/repo"
    assert data["tree"][0]["children"][0]["git_status"] == "M"


def test_file_tree_resolves_project_id_to_path(api_client):
    make_project(pid="file-proj", name="FileTest", path="/tmp/filerepo")
    with (
        patch(f"{ROUTER}.get_repo_root", return_value="/tmp/filerepo") as mock_root,
        patch(f"{ROUTER}.build_file_tree", return_value=[]) as mock_tree,
    ):
        resp = api_client.get("/api/files/tree", params={"project_id": "file-proj"})
    assert resp.status_code == 200
    mock_root.assert_called_once_with(Path("/tmp/filerepo"))
    mock_tree.assert_called_once_with(Path("/tmp/filerepo"))


def test_project_id_not_found_returns_404(api_client):
    resp = api_client.get("/api/files/tree", params={"project_id": "no-such-proj"})
    assert resp.status_code == 404
    assert "not found" in resp.json()["detail"].lower()


# ── GET /api/files/read ───────────────────────────────────────────────


def test_read_file_returns_content_and_language(api_client, tmp_path):
    (tmp_path / "hello.py").write_text("print('hello')\n")
    with patch(f"{ROUTER}.get_repo_root", return_value=str(tmp_path)):
        resp = api_client.get("/api/files/read", params={"path": "hello.py"})
    assert resp.status_code == 200
    data = resp.json()
    assert data == {"path": "hello.py", "content": "print('hello')\n", "language": "python"}


def test_read_file_missing_returns_404(api_client, tmp_path):
    with patch(f"{ROUTER}.get_repo_root", return_value=str(tmp_path)):
        resp = api_client.get("/api/files/read", params={"path": "nope.py"})
    assert resp.status_code == 404


def test_read_file_path_traversal_denied(api_client, tmp_path):
    with patch(f"{ROUTER}.get_repo_root", return_value=str(tmp_path)):
        resp = api_client.get("/api/files/read", params={"path": "../../../etc/passwd"})
    assert resp.status_code == 403


def test_read_file_oserror_returns_500(api_client, tmp_path):
    target = tmp_path / "a.py"
    target.write_text("x")
    original_read = Path.read_text

    def _read(self, *args, **kwargs):
        if self == target.resolve():
            raise OSError("boom")
        return original_read(self, *args, **kwargs)

    with (
        patch(f"{ROUTER}.get_repo_root", return_value=str(tmp_path)),
        patch.object(Path, "read_text", _read),
    ):
        resp = api_client.get("/api/files/read", params={"path": "a.py"})
    assert resp.status_code == 500
    assert "boom" in resp.json()["detail"]


# ── _detect_language ────────────────────────────────────────────────


@pytest.mark.parametrize(
    "filename,expected",
    [
        ("app.py", "python"),
        ("app.ts", "typescript"),
        ("style.css", "css"),
        ("config.yaml", "yaml"),
        ("Dockerfile", "docker"),
        ("Makefile", "makefile"),
        ("data.xml", "xml"),
        ("unknown.zzz", "text"),
    ],
)
def test_detect_language(filename, expected):
    assert _detect_language(filename) == expected


# ── POST /api/files/search ──────────────────────────────────────────────


def test_search_all_combines_names_and_contents(api_client):
    name_matches = [FileSearchMatch(path="src/utils.py"), FileSearchMatch(path="src/helpers.py")]
    content_matches = [FileSearchMatch(path="src/main.py", line=10, text="import utils")]
    with (
        patch(f"{ROUTER}.get_repo_root", return_value="/tmp/repo"),
        patch(f"{ROUTER}.search_file_names", return_value=name_matches),
        patch(f"{ROUTER}.search_file_contents", return_value=content_matches),
    ):
        resp = api_client.post("/api/files/search", json={"query": "utils", "mode": "all"})
    assert resp.status_code == 200
    assert len(resp.json()["matches"]) == 3


def test_search_contents_only_skips_name_search(api_client):
    with (
        patch(f"{ROUTER}.get_repo_root", return_value="/tmp/repo"),
        patch(f"{ROUTER}.search_file_names") as mock_names,
        patch(f"{ROUTER}.search_file_contents", return_value=[]) as mock_contents,
    ):
        resp = api_client.post("/api/files/search", json={"query": "x", "mode": "contents"})
    assert resp.status_code == 200
    mock_names.assert_not_called()
    mock_contents.assert_called_once()


def test_search_all_passes_remaining_budget_to_contents(api_client):
    name_matches = [FileSearchMatch(path=f"f{i}.py") for i in range(3)]
    with (
        patch(f"{ROUTER}.get_repo_root", return_value="/tmp/repo"),
        patch(f"{ROUTER}.search_file_names", return_value=name_matches),
        patch(f"{ROUTER}.search_file_contents", return_value=[]) as mock_contents,
    ):
        api_client.post("/api/files/search", json={"query": "x", "mode": "all", "max_results": 5})
    # 5 max - 3 name matches = 2 remaining budget for content search
    assert mock_contents.call_args[0][4] == 2


def test_search_empty_query_short_circuits(api_client):
    resp = api_client.post("/api/files/search", json={"query": "  ", "mode": "files"})
    assert resp.status_code == 200
    assert resp.json()["matches"] == []


# ── GET /api/files/watch (SSE) ─────────────────────────────────────────


def _fake_awatch_factory(batches):
    """Return an async generator factory that yields the given batches then stops."""
    async def _awatch(_root, *args, **kwargs):
        for b in batches:
            yield b

    return _awatch


@pytest.mark.timeout(5)
def test_watch_streams_connected_and_change_events(api_client, tmp_path):
    from watchfiles import Change

    batches = [{(Change.added, str(tmp_path / "a.py")),
                (Change.modified, str(tmp_path / "b.py")),
                (Change.deleted, str(tmp_path / "c.py"))}]
    with (
        patch(f"{ROUTER}.get_repo_root", return_value=str(tmp_path)),
        patch(f"{ROUTER}.awatch", _fake_awatch_factory(batches)),
    ):
        with api_client.stream("GET", "/api/files/watch") as resp:
            assert resp.status_code == 200
            body = b"".join(resp.iter_bytes())
    text = body.decode()
    assert '"type": "connected"' in text
    assert '"type": "changes"' in text
    assert '"change": "added"' in text
    assert '"change": "modified"' in text
    assert '"change": "deleted"' in text


@pytest.mark.timeout(5)
def test_watch_handles_cancellation(api_client, tmp_path):
    import asyncio

    class _CancellingAwatch:
        def __aiter__(self):
            return self

        async def __anext__(self):
            raise asyncio.CancelledError

    def _factory(_root, *args, **kwargs):
        return _CancellingAwatch()

    with (
        patch(f"{ROUTER}.get_repo_root", return_value=str(tmp_path)),
        patch(f"{ROUTER}.awatch", _factory),
    ):
        with api_client.stream("GET", "/api/files/watch") as resp:
            assert resp.status_code == 200
            body = b"".join(resp.iter_bytes())
    # The connected event is still sent before cancellation.
    assert '"type": "connected"' in body.decode()


# ── _resolve_project_path (unit) ─────────────────────────────────────────


def test_resolve_project_path_returns_none_without_id():
    assert _resolve_project_path(None) is None
