"""Tests for hypergolic.files.operations (re-export module)."""

from hypergolic.files import operations
from hypergolic.files.search import search_file_contents, search_file_names
from hypergolic.files.tree import build_file_tree, get_repo_root


def test_operations_reexports_tree_helpers():
    assert operations.build_file_tree is build_file_tree
    assert operations.get_repo_root is get_repo_root


def test_operations_reexports_search_helpers():
    assert operations.search_file_names is search_file_names
    assert operations.search_file_contents is search_file_contents
