from pydantic import BaseModel, Field


class FileNode(BaseModel):
    name: str
    path: str
    is_dir: bool
    git_status: str | None = None
    children: list["FileNode"] | None = None


class FileSearchMatch(BaseModel):
    path: str
    line: int | None = None
    text: str | None = None


class FileSearchRequest(BaseModel):
    query: str
    mode: str = Field(default="files", description="'files', 'contents', or 'all'")
    respect_gitignore: bool = True
    include_hidden: bool = False
    max_results: int = 50


class FileSearchResponse(BaseModel):
    matches: list[FileSearchMatch]
