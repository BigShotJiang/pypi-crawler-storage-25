"""Re-exports for backward compatibility.

The actual implementations live in files/tree.py and files/search.py.
"""

from hypergolic.files.search import (  # noqa: F401
    search_file_contents,
    search_file_names,
)
from hypergolic.files.tree import (  # noqa: F401
    build_file_tree,
    get_repo_root,
)
