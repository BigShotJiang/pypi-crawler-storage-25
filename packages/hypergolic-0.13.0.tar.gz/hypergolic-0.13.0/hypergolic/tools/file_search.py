"""Single-file search logic: binary detection, line-by-line and multiline."""

import re
from pathlib import Path


def is_binary(path: Path) -> bool:
    """Return True if *path* appears to be a binary file."""
    try:
        chunk = path.read_bytes()[:8192]
        return b"\x00" in chunk
    except (OSError, PermissionError):
        return True


def search_file_multiline(
    path: Path, root: Path, regex: re.Pattern, *, files_only: bool = False,
) -> list[str]:
    """Search *path* with multiline regex and return matching output lines."""
    try:
        content = path.read_text(errors="replace")
    except (OSError, PermissionError):
        return []

    if not regex.search(content):
        return []

    rel = str(path.relative_to(root))
    if files_only:
        return [rel]
    first_line = content.splitlines()[0] if content.splitlines() else ""
    return [f"{rel}:1:{first_line}"]


def search_file(
    path: Path,
    root: Path,
    regex: re.Pattern,
    *,
    files_only: bool = False,
    invert_match: bool = False,
    context_lines: int = 0,
    max_results: int | None = None,
    show_line_numbers: bool = True,
    multiline: bool = False,
) -> list[str]:
    """Search a single file and return formatted output lines."""
    if is_binary(path):
        return []

    if multiline:
        return search_file_multiline(path, root, regex, files_only=files_only)

    try:
        lines = path.read_text(errors="replace").splitlines()
    except (OSError, PermissionError):
        return []

    rel = str(path.relative_to(root))

    if files_only:
        for line in lines:
            matched = (regex.search(line) is not None) != invert_match
            if matched:
                return [rel]
        return []

    matching_indices: list[int] = []
    for i, line in enumerate(lines):
        matched = (regex.search(line) is not None) != invert_match
        if matched:
            matching_indices.append(i)
            if max_results is not None and len(matching_indices) >= max_results:
                break

    if not matching_indices:
        return []

    output_indices: set[int] = set()
    for idx in matching_indices:
        start = max(0, idx - context_lines)
        end = min(len(lines) - 1, idx + context_lines)
        for i in range(start, end + 1):
            output_indices.add(i)

    result: list[str] = []
    sorted_indices = sorted(output_indices)
    prev_idx = -2
    for i in sorted_indices:
        if prev_idx >= 0 and i > prev_idx + 1:
            result.append("--")
        sep = ":" if i in matching_indices else "-"
        if show_line_numbers:
            result.append(f"{rel}:{i + 1}{sep}{lines[i]}")
        else:
            result.append(f"{rel}{sep}{lines[i]}")
        prev_idx = i

    return result
