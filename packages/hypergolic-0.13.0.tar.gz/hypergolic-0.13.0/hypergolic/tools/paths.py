from pathlib import Path

from hypergolic.schemas import Session


def resolve_path(path: str, session: Session) -> Path:
    """Resolve a user-supplied path to an absolute, symlink-resolved Path.

    Handles three forms:
    - Absolute paths: ``/foo/bar`` → resolved as-is
    - Home-relative paths: ``~/foo`` → expanded then resolved
    - Relative paths: ``src/main.py`` → resolved against ``session.working_directory()``
    """
    p = Path(path).expanduser()
    if not p.is_absolute():
        p = session.working_directory() / p
    return p.resolve()


def _is_under(path: str, root: str) -> bool:
    """True if *path* equals *root* or is nested inside it.

    Uses strict boundary matching so sibling-prefix directories like
    ``/Users/RTownleyOther`` are NOT treated as being under ``/Users/RTownley``.
    """
    root = root.rstrip("/")
    return path == root or path.startswith(root + "/")


def shorten_path(abs_path: str, session: Session | None) -> str:
    """Shorten an absolute path for display in tool results."""
    if not abs_path:
        return abs_path

    trailing = "/" if abs_path.endswith("/") and len(abs_path) > 1 else ""
    core = abs_path[:-1] if trailing else abs_path

    if session is not None:
        try:
            scope_root = str(Path(session.working_directory()).expanduser().resolve())
        except (OSError, RuntimeError):
            scope_root = None
        if scope_root and _is_under(core, scope_root):
            rel = core[len(scope_root):].lstrip("/") or "."
            return rel + trailing

    try:
        home = str(Path.home())
    except (OSError, RuntimeError):
        home = ""
    if home and _is_under(core, home):
        rel = core[len(home):].lstrip("/")
        return (f"~/{rel}" if rel else "~") + trailing

    return abs_path
