"""Toolkit tool lookup across app, project, role, skill, and workflow scopes."""

from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.primitives import Tool as ToolkitTool
from hypergolic.schemas import Session
from hypergolic.workflows.resolver import get_session_workflow


def _find_in_list(tool_id: str, tools: list[ToolkitTool]) -> ToolkitTool | None:
    for t in tools:
        if t.id == tool_id:
            return t
    return None


def find_toolkit_tool(tool_id: str, session: Session) -> ToolkitTool | None:
    """Search all scopes for a ToolkitTool matching *tool_id*."""
    app = get_app()

    found = _find_in_list(tool_id, app.tools)
    if found:
        return found

    project = app.get_project(session.project_id)
    if project:
        found = _find_in_list(tool_id, project.tools)
        if found:
            return found

    role = app.get_role(session.role)
    if role:
        found = _find_in_list(tool_id, role.tools)
        if found:
            return found

    for skill_id in session.active_skill_ids:
        skill = app.get_skill(skill_id)
        if skill:
            found = _find_in_list(tool_id, skill.tools)
            if found:
                return found

    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, current_state_id = wf_state
        all_workflows = [*app.workflows, *(project.workflows if project else [])]
        for wf in all_workflows:
            if wf.id == workflow_id:
                found = _find_in_list(tool_id, wf.tools)
                if found:
                    return found
                for state in wf.states:
                    if state.id == current_state_id:
                        found = _find_in_list(tool_id, state.tools)
                        if found:
                            return found

    return None
