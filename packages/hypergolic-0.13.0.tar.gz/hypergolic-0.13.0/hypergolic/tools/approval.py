"""Tool approval dataclasses and helpers."""

from dataclasses import dataclass
from typing import Any, Awaitable, Callable

from hypergolic.toolkit.bridge import evaluate_toolkit_approval
from hypergolic.toolkit.primitives import Tool as ToolkitTool, ToolApprovalDecision
from hypergolic.tools.approval_view_resolver import resolve_approval_view
from hypergolic.tools.approval_view import ResolvedView
from hypergolic.tools.schemas import Tool, ToolOutput
from hypergolic.schemas import Session

_REQUIRE_APPROVAL = "REQUIRE_APPROVAL"
_ALLOW = "ALLOW"
_DENY = "DENY"


@dataclass
class ApprovalRequest:
    tool_use_id: str
    tool_name: str
    tool_input: dict[str, Any]
    session_id: str | None = None
    approval_view: ResolvedView | None = None
    tool_display_name: str | None = None


@dataclass
class AnnotationItem:
    highlighted_text: str
    comment: str


@dataclass
class ApprovalResponse:
    approved: bool
    denial_reason: str | None = None
    annotations: list[AnnotationItem] | None = None


ApprovalCallback = Callable[[ApprovalRequest], Awaitable[ApprovalResponse]]


def resolve_approval_decision(
    tool: Tool,
    tool_input: dict[str, Any],
    toolkit_tool: ToolkitTool | None,
    session: Session,
    is_mcp: bool,
) -> ToolApprovalDecision:
    """Return a ToolApprovalDecision for a tool invocation."""
    if toolkit_tool:
        return evaluate_toolkit_approval(toolkit_tool, tool_input, session)
    if is_mcp:
        return ToolApprovalDecision(decision=_REQUIRE_APPROVAL)
    if tool.requires_approval:
        return ToolApprovalDecision(decision=_REQUIRE_APPROVAL)
    return ToolApprovalDecision(decision=_ALLOW)


def build_resolved_view(
    tool: Tool, tool_input: dict[str, Any],
) -> ResolvedView | None:
    """Resolve ``tool.approval_view`` against ``tool_input``; ``None`` if unset."""
    if tool.approval_view is None:
        return None
    return resolve_approval_view(tool.approval_view, tool_input)


def format_denial(response: ApprovalResponse) -> str:
    """Format a human-readable denial message from an ApprovalResponse."""
    denial_text = "User denied tool call."
    if response.denial_reason:
        denial_text += f" Reason: {response.denial_reason}"
    if response.annotations:
        denial_text += "\n\nUser annotations:\n"
        for ann in response.annotations:
            denial_text += f'- "{ann.highlighted_text}": {ann.comment}\n'
    return denial_text


def append_annotations(output: ToolOutput, annotations: list[AnnotationItem]) -> ToolOutput:
    """Append user annotations to a ToolOutput."""
    annotation_text = "\n\nUser feedback on this artifact:\n"
    for ann in annotations:
        annotation_text += f'- "{ann.highlighted_text}": {ann.comment}\n'
    return output.append_text(annotation_text)
