from typing import Any

from pydantic import BaseModel
from sqlalchemy import select, delete as sa_delete

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSessionSkill
from hypergolic.skills.resolver import get_skill_prompt_content
from hypergolic.tools.schemas import ToolContext, ToolOutput


async def handle_activate_skill(inp: BaseModel, ctx: ToolContext) -> ToolOutput:
    skill_ids: list[str] = getattr(inp, "skill_ids")
    session = ctx.session

    results: list[str] = []
    all_already_active = True

    for skill_id in skill_ids:
        with get_db() as db:
            already_active = db.execute(
                select(DBSessionSkill)
                .where(DBSessionSkill.session_id == session.id)
                .where(DBSessionSkill.skill_id == skill_id)
            ).scalar_one_or_none()
            if already_active:
                continue

        all_already_active = False

        result = get_skill_prompt_content(skill_id)
        if result is None:
            results.append(f"Skill '{skill_id}' not found.")
            continue

        skill_name, prompt_content = result

        if prompt_content is None:
            results.append(f"Skill '{skill_id}' prompt file not found.")
            continue

        with get_db() as db:
            db.add(DBSessionSkill(
                session_id=ctx.session.id,
                skill_id=skill_id,
            ))

        results.append(f"Skill Added: {skill_name}\n\n{prompt_content}")

    if all_already_active:
        return ToolOutput.text("All requested skills are already active.")

    combined = "\n\n---\n\n".join(results)
    return ToolOutput.text(combined)


async def handle_deactivate_skill(inp: BaseModel, ctx: ToolContext) -> ToolOutput:
    skill_ids: list[str] = getattr(inp, "skill_ids")
    session = ctx.session

    deactivated: list[str] = []

    for skill_id in skill_ids:
        with get_db() as db:
            db.execute(
                sa_delete(DBSessionSkill)
                .where(DBSessionSkill.session_id == session.id)
                .where(DBSessionSkill.skill_id == skill_id)
            )
        deactivated.append(skill_id)

    text = "Deactivated skills: " + ", ".join(deactivated)
    return ToolOutput.text(text)


def build_activate_skill_description(skills: list[dict[str, Any]]) -> str:
    return "Activate a skill for specialized knowledge and tools"


def build_deactivate_skill_description() -> str:
    return "Deactivate skills frequently when no longer in use"
