"""Pure-Python grep replacement used as fallback when ripgrep is unavailable."""

import re
import subprocess
from dataclasses import dataclass
from pathlib import Path

from hypergolic.tools.file_search import search_file
from hypergolic.tools.file_walker import walk_files


@dataclass
class PythonSearchParams:
    pattern: str
    directory: str = "."
    fixed_string: bool = False
    case_sensitive: bool = True
    include_hidden: bool = False
    file_glob: str | None = None
    max_depth: int | None = None
    context_lines: int = 0
    max_results: int | None = None
    invert_match: bool = False
    files_only: bool = False
    multiline: bool = False
    show_line_numbers: bool = True


def _compile_pattern(params: PythonSearchParams) -> re.Pattern:
    """Build a compiled regex from the search params."""
    pat = re.escape(params.pattern) if params.fixed_string else params.pattern
    flags = re.DOTALL if params.multiline else 0
    if not params.case_sensitive:
        flags |= re.IGNORECASE
    return re.compile(pat, flags)


def _is_context_line(line: str) -> bool:
    """Return True if *line* looks like a context (non-match) line."""
    parts = line.split("-", 2)
    if len(parts) >= 2:
        try:
            int(parts[1])
            return True
        except ValueError:
            pass
    return False


def python_search(params: PythonSearchParams) -> subprocess.CompletedProcess:
    """Search files and return a CompletedProcess mimicking ripgrep output."""
    root = Path(params.directory).resolve()
    regex = _compile_pattern(params)

    all_output: list[str] = []
    match_count = 0

    for file_path in walk_files(
        root,
        include_hidden=params.include_hidden,
        file_glob=params.file_glob,
        max_depth=params.max_depth,
    ):
        file_results = search_file(
            file_path, root, regex,
            files_only=params.files_only,
            invert_match=params.invert_match,
            context_lines=params.context_lines,
            max_results=params.max_results,
            show_line_numbers=params.show_line_numbers,
            multiline=params.multiline,
        )
        if file_results:
            if params.files_only:
                match_count += len(file_results)
            else:
                match_count += sum(
                    1 for line in file_results
                    if line != "--" and not _is_context_line(line)
                )
            all_output.extend(file_results)

            if params.max_results is not None and match_count >= params.max_results:
                break

    stdout = "\n".join(all_output) if all_output else ""
    returncode = 0 if all_output else 1

    return subprocess.CompletedProcess(
        args=["python-search"], returncode=returncode, stdout=stdout, stderr="",
    )
