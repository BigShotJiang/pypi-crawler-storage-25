"""Runtime tool schemas used by the engine when invoking tools.

The JSON-schema transforms (``_resolve_refs``, ``_strip_schema_noise``, plus
newer token-efficiency passes) live in :mod:`hypergolic.tools.json_schema`.
We re-export the underscored names as thin aliases so existing callers and
tests keep working.
"""

from collections.abc import Iterator
from dataclasses import dataclass, field
from typing import Awaitable, Callable, Generic, TypeVar, Type, cast

from anthropic.types import TextBlockParam, ToolUnionParam
from anthropic.types.tool_result_block_param import Content
from pydantic import BaseModel

from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session
from hypergolic.tools.approval_view import ApprovalView
from hypergolic.tools.json_schema import (
    optimize_schema,
    resolve_refs as _resolve_refs,
    strip_schema_noise as _strip_schema_noise,
)

__all__ = [
    "Tool",
    "ToolContext",
    "ToolContent",
    "ToolOutput",
    "_resolve_refs",
    "_strip_schema_noise",
]

T = TypeVar("T", bound=BaseModel)


ToolContent = list[Content]


@dataclass
class ToolContext:
    session: Session
    broadcast: BroadcastFn
    tool_id: str


@dataclass
class ToolOutput:
    content: list[Content] = field(default_factory=list)
    is_error: bool = False
    should_truncate: bool = False

    # --- Construction helpers ------------------------------------------------

    @classmethod
    def text(
        cls,
        text: str,
        *,
        is_error: bool = False,
        should_truncate: bool = False,
    ) -> "ToolOutput":
        """Build a ToolOutput containing a single text block."""
        block: TextBlockParam = {"type": "text", "text": text}
        return cls(
            content=[block],
            is_error=is_error,
            should_truncate=should_truncate,
        )

    def append_text(self, text: str) -> "ToolOutput":
        """Return a new ToolOutput with an additional text block appended."""
        block: TextBlockParam = {"type": "text", "text": text}
        return ToolOutput(
            content=[*self.content, block],
            is_error=self.is_error,
            should_truncate=self.should_truncate,
        )

    # --- Narrowing accessors -------------------------------------------------

    def iter_text_blocks(self) -> Iterator[TextBlockParam]:
        """Yield only the TextBlockParam entries from content, properly typed."""
        for block in self.content:
            if isinstance(block, dict) and block.get("type") == "text":
                yield cast(TextBlockParam, block)

    def total_text_chars(self) -> int:
        """Sum the character count of all text blocks."""
        return sum(len(b["text"]) for b in self.iter_text_blocks())

    def first_text(self) -> str:
        """Text of the first content block. Raises if it is not a text block."""
        if not self.content:
            raise IndexError("ToolOutput has no content blocks")
        block = self.content[0]
        if not (isinstance(block, dict) and block.get("type") == "text"):
            actual = block.get("type") if isinstance(block, dict) else type(block).__name__
            raise TypeError(f"Expected text block, got {actual!r}")
        return cast(TextBlockParam, block)["text"]


class Tool(BaseModel, Generic[T]):
    id: str
    name: str
    description: str
    input: Type[T]
    call_tool: Callable[[T, ToolContext], Awaitable[ToolOutput]]
    should_truncate: bool = False
    requires_approval: bool = False
    approval_view: ApprovalView | None = None
    source: str = "standard"

    model_config = {"arbitrary_types_allowed": True}

    def to_param(self) -> ToolUnionParam:
        schema = self.input.model_json_schema()
        schema["additionalProperties"] = False
        optimize_schema(schema)

        return {
            "name": self.id,
            "description": self.description,
            "input_schema": schema,
        }
