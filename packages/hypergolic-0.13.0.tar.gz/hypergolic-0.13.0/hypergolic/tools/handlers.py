"""Core tool-use handling: execute tools and process an agent message."""

import asyncio
import logging
from dataclasses import dataclass
from typing import Any

from anthropic.types import MessageParam, ToolResultBlockParam, ToolUseBlock
from anthropic.types.message import Message

from hypergolic.mcptools.tool_bridge import execute_mcp_tool
from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session
from hypergolic.tools.approval import (  # noqa: F401 — re-exported
    AnnotationItem,
    ApprovalCallback,
    ApprovalRequest,
    ApprovalResponse,
    append_annotations,
    build_resolved_view,
    format_denial,
    resolve_approval_decision,
)
from hypergolic.tools.lookup import find_toolkit_tool  # noqa: F401 — re-exported
from hypergolic.tools.schemas import Tool, ToolContext, ToolOutput
from hypergolic.tools.truncation import result_block, truncate_tool_output

logger = logging.getLogger(__name__)

# Re-export public types so existing imports keep working.
__all__ = [
    "AnnotationItem",
    "ApprovalCallback",
    "ApprovalRequest",
    "ApprovalResponse",
    "ToolUseResult",
    "find_toolkit_tool",
    "handle_tool_use",
]

_DENY = "DENY"
_REQUIRE_APPROVAL = "REQUIRE_APPROVAL"


@dataclass
class ToolUseResult:
    message: MessageParam
    should_truncate: bool = False


async def _execute_tool(tool: Tool, raw_input: Any, ctx: ToolContext) -> ToolOutput:
    """Validate input and call the tool, returning an error ToolOutput on failure."""
    try:
        parsed_input = tool.input.model_validate(raw_input)
        return await tool.call_tool(parsed_input, ctx)
    except Exception as e:
        logger.error("Tool '%s' failed: %s", tool.id, e, exc_info=True)
        return ToolOutput.text(f"Error with tool call: {e}", is_error=True)


async def _process_single_tool(
    content: ToolUseBlock,
    tool_map: dict[str, Tool],
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None,
) -> tuple[ToolResultBlockParam, bool]:
    tool = tool_map.get(content.name)
    if tool is None:
        logger.error(
            "Tool '%s' not found in tool_map (available: %s)",
            content.name, list(tool_map.keys()),
        )
        block = ToolResultBlockParam(
            tool_use_id=content.id,
            type="tool_result",
            content=f"Tool '{content.name}' is not available. Check active skills and available tools.",
            is_error=True,
        )
        return block, False

    tool_input: dict = content.input  # type: ignore[assignment]
    is_mcp = content.name.startswith("mcp_")
    toolkit_tool = find_toolkit_tool(content.name, session)
    approval_decision = resolve_approval_decision(tool, tool_input, toolkit_tool, session, is_mcp)

    if approval_decision.decision == _DENY:
        reason = approval_decision.reason or "Tool call denied by approval rule."
        return result_block(content.id, ToolOutput.text(reason, is_error=True)), False

    approved_annotations: list[AnnotationItem] | None = None
    if approval_decision.decision == _REQUIRE_APPROVAL and approval_callback:
        request = ApprovalRequest(
            tool_use_id=content.id,
            tool_name=content.name,
            tool_input=tool_input,
            session_id=session.id,
            approval_view=build_resolved_view(tool, tool_input),
            tool_display_name=tool.name,
        )
        response = await approval_callback(request)

        if not response.approved:
            return result_block(
                content.id,
                ToolOutput.text(format_denial(response), is_error=True),
            ), False

        approved_annotations = response.annotations

    if is_mcp:
        output = await execute_mcp_tool(content.name, tool_input)
    else:
        ctx = ToolContext(session=session, broadcast=broadcast, tool_id=tool.id)
        output = await _execute_tool(tool, content.input, ctx)

    output = truncate_tool_output(output)
    trigger_truncation = (tool.should_truncate or output.should_truncate) and not output.is_error

    if approved_annotations and not output.is_error:
        output = append_annotations(output, approved_annotations)

    return result_block(content.id, output), trigger_truncation


async def handle_tool_use(
    agent_message: Message,
    tools: list[Tool],
    session: Session,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback | None = None,
) -> ToolUseResult:
    """Process all tool-use blocks in *agent_message* and return results."""
    tool_map = {tool.id: tool for tool in tools}

    tool_use_blocks = [
        block for block in agent_message.content
        if isinstance(block, ToolUseBlock)
    ]

    results = await asyncio.gather(*[
        _process_single_tool(block, tool_map, session, broadcast, approval_callback)
        for block in tool_use_blocks
    ])

    tool_result_blocks: list[ToolResultBlockParam] = []
    trigger_truncation = False
    for block, should_truncate in results:
        tool_result_blocks.append(block)
        if should_truncate:
            trigger_truncation = True

    return ToolUseResult(
        message=MessageParam(role="user", content=tool_result_blocks),
        should_truncate=trigger_truncation,
    )
