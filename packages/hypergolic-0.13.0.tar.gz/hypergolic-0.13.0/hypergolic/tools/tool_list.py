import logging
from copy import deepcopy
from enum import Enum
from typing import Any

from anthropic.types import ToolUnionParam
from pydantic import BaseModel

from hypergolic.toolkit.app.core import App
from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.bridge import convert_tools
from hypergolic.toolkit.primitives import Workflow as ToolkitWorkflow
from hypergolic.toolkit.project import Project as ToolkitProject
from hypergolic.mcptools.tool_bridge import get_mcp_tools_for_session, parse_mcp_tool_id
from hypergolic.schemas import Session
from hypergolic.mcptools.sessions import get_enabled_servers
from hypergolic.skills.resolver import resolve_session_skills
from hypergolic.tools.schemas import Tool
from hypergolic.tools.skills import (
    handle_activate_skill,
    handle_deactivate_skill,
    build_activate_skill_description,
    build_deactivate_skill_description,
)
from hypergolic.tools.activate_workflow import handle_activate_workflow, build_workflow_description
from hypergolic.base.tools.dispatch import build_dispatch_tool as _build_dispatch_toolkit_tool
from hypergolic.base.tools.merge_child import build_merge_child_tool as _build_merge_child_toolkit_tool
from hypergolic.dispatch.conclude import ConcludeTool
from hypergolic.workflows.resolver import get_session_workflow
from hypergolic.workflows.tools import build_transition_tools

logger = logging.getLogger(__name__)


def _find_workflow(
    app: App, project: ToolkitProject | None, workflow_id: str
) -> ToolkitWorkflow | None:
    for wf in app.workflows:
        if wf.id == workflow_id:
            return wf
    if project:
        for wf in project.workflows:
            if wf.id == workflow_id:
                return wf
    return None


def _build_activate_skill_tool(app: App, session: Session) -> Tool | None:
    all_skills = resolve_session_skills(session)
    activatable = [s for s in all_skills if s["id"] not in session.active_skill_ids]

    if not activatable:
        return None

    skill_ids = [s["id"] for s in activatable]
    SkillIdEnum = Enum("SkillIdEnum", {sid: sid for sid in skill_ids}, type=str)

    class ActivateSkillInput(BaseModel):
        skill_ids: list[SkillIdEnum]  # type: ignore[valid-type]

    return Tool(
        id="activate_skill",
        name="Activate Skill",
        description=build_activate_skill_description(activatable),
        input=ActivateSkillInput,
        call_tool=handle_activate_skill,
    )


def _build_deactivate_skill_tool(session: Session) -> Tool | None:
    if not session.active_skill_ids:
        return None

    skill_ids = sorted(session.active_skill_ids)
    SkillIdEnum = Enum("SkillIdEnum", {sid: sid for sid in skill_ids}, type=str)

    class DeactivateSkillInput(BaseModel):
        skill_ids: list[SkillIdEnum]  # type: ignore[valid-type]

    return Tool(
        id="deactivate_skill",
        name="Deactivate Skill",
        description=build_deactivate_skill_description(),
        input=DeactivateSkillInput,
        call_tool=handle_deactivate_skill,
    )


def _build_dispatch_tool_for_session(app: App, session: Session) -> Tool | None:
    """Build the unified ``dispatch`` tool if *session* is a generalist.

    Only generalists can dispatch. Valid targets are all registered roles
    other than ``generalist``. For each target role we also compute the
    set of tool IDs that role would see — used by the dispatch tool to
    check whether attached file references are readable by the receiver.
    """
    if session.role != "generalist":
        return None

    target_role_ids: list[str] = []
    receiver_tool_ids_by_role: dict[str, set[str]] = {}
    for role in app.roles:
        if role.id == "generalist":
            continue
        target_role_ids.append(role.id)
        tool_ids: set[str] = {t.id for t in app.tools}
        tool_ids.update(t.id for t in role.tools)
        receiver_tool_ids_by_role[role.id] = tool_ids

    toolkit_tool = _build_dispatch_toolkit_tool(
        target_role_ids, receiver_tool_ids_by_role
    )
    if toolkit_tool is None:
        return None
    from hypergolic.toolkit.bridge import convert_tool
    return convert_tool(toolkit_tool)


def _build_activate_workflow_tool_from_app(
    app: App, project: ToolkitProject | None, session: Session
) -> Tool | None:
    wf_state = get_session_workflow(session.id)
    if wf_state is not None:
        return None

    wf_dicts: list[dict[str, Any]] = []
    wf_ids: list[str] = []
    seen: set[str] = set()

    for wf in app.workflows:
        if wf.id not in seen:
            wf_dicts.append({"id": wf.id, "name": wf.name, "description": wf.description})
            wf_ids.append(wf.id)
            seen.add(wf.id)

    if project:
        for wf in project.workflows:
            if wf.id not in seen:
                wf_dicts.append({"id": wf.id, "name": wf.name, "description": wf.description})
                wf_ids.append(wf.id)
                seen.add(wf.id)

    if not wf_dicts:
        return None

    WorkflowIdEnum = Enum("WorkflowIdEnum", {wid: wid for wid in wf_ids}, type=str)

    class ActivateWorkflowInput(BaseModel):
        workflow_id: WorkflowIdEnum  # type: ignore[valid-type]

    return Tool(
        id="activate_workflow",
        name="Activate Workflow",
        description=build_workflow_description(wf_dicts),
        input=ActivateWorkflowInput,
        call_tool=handle_activate_workflow,
    )


def build_tools_with_reasons(session: Session) -> list[tuple[Tool, str]]:
    """Build the full tool list for a session, pairing each tool with the
    origin that introduced it.

    When a tool is re-introduced by a later source (e.g. a role overrides an
    app-level tool), the later reason wins — matching the way the tool dict
    is overwritten in insertion order.
    """
    app = get_app()
    tools: dict[str, Tool] = {}
    reasons: dict[str, str] = {}

    def add(tool: Tool, reason: str) -> None:
        tools[tool.id] = tool
        reasons[tool.id] = reason

    def add_if_new(tool: Tool, reason: str) -> None:
        if tool.id not in tools:
            tools[tool.id] = tool
            reasons[tool.id] = reason

    for t in convert_tools(app.tools):
        add(t, "app")

    project = app.get_project(session.project_id)
    if project:
        for t in convert_tools(project.tools):
            add(t, "project")

    role = app.get_role(session.role)
    assert role is not None, f"Role '{session.role}' not found"
    for t in convert_tools(role.tools):
        add(t, "role")

    for skill_id in session.active_skill_ids:
        skill = app.get_skill(skill_id)
        if skill and skill.tools:
            for t in convert_tools(skill.tools):
                add(t, f"skill:{skill_id}")

    wf_state = get_session_workflow(session.id)
    if wf_state:
        workflow_id, current_state_id = wf_state
        wf = _find_workflow(app, project, workflow_id)
        if wf:
            for t in convert_tools(wf.tools):
                add(t, f"workflow:{workflow_id}")
            for state in wf.states:
                if state.id == current_state_id and state.tools:
                    for t in convert_tools(state.tools):
                        add(t, f"workflow_state:{current_state_id}")

    activate_skill_tool = _build_activate_skill_tool(app, session)
    if activate_skill_tool:
        add(activate_skill_tool, "app")

    deactivate_skill_tool = _build_deactivate_skill_tool(session)
    if deactivate_skill_tool:
        add(deactivate_skill_tool, "app")

    workflow_tool = _build_activate_workflow_tool_from_app(app, project, session)
    if workflow_tool:
        add(workflow_tool, "app")

    dispatch_tool = _build_dispatch_tool_for_session(app, session)
    if dispatch_tool:
        add(dispatch_tool, "role")

    if session.role == "generalist":
        merge_child_toolkit = _build_merge_child_toolkit_tool(session)
        if merge_child_toolkit is not None:
            from hypergolic.toolkit.bridge import convert_tool
            merge_child_tool = convert_tool(merge_child_toolkit)
            add(merge_child_tool, "app")

    enabled_servers = get_enabled_servers(session.id)
    if enabled_servers:
        for t in get_mcp_tools_for_session(enabled_servers):
            t.source = "mcp"
            parsed = parse_mcp_tool_id(t.id)
            server_name = parsed[0] if parsed else "unknown"
            add(t, f"mcp:{server_name}")

    workflow_transition_tools, transition_state_id = build_transition_tools(session)
    transition_reason = (
        f"workflow_state:{transition_state_id}" if transition_state_id else "app"
    )
    for wt in workflow_transition_tools:
        add_if_new(wt, transition_reason)

    if session.parent_id:
        add_if_new(ConcludeTool, "app")

    return [(tool, reasons[tool.id]) for tool in tools.values()]


def build_tools(session: Session) -> list[Tool]:
    return [tool for tool, _ in build_tools_with_reasons(session)]


def get_tool_schemas(tools: list[Tool]) -> list[ToolUnionParam]:
    return [t.to_param() for t in tools]


def set_tools_cache_breakpoint(
    tool_schemas: list[ToolUnionParam],
) -> list[ToolUnionParam]:
    schemas = deepcopy(tool_schemas)
    schemas[-1]["cache_control"] = {"type": "ephemeral"}
    return schemas
