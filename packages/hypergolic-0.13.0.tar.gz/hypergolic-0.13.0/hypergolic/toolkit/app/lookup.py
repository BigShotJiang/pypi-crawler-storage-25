from __future__ import annotations

from typing import Protocol

from hypergolic.toolkit.primitives import Role, Skill, Workflow
from hypergolic.toolkit.project import Project


class _SkillSearchable(Protocol):
    skills: list[Skill]
    projects: list[Project]
    roles: list[Role]
    workflows: list[Workflow]


def collect_top_level_skills(app: _SkillSearchable) -> list[Skill]:
    """Collect all top-level Skill objects from every registration point.

    Walks: app skills, project skills, role skills, workflow skills,
    workflow state skills, project workflow skills, project workflow state skills.

    Returns top-level skills only (not recursively flattened children).
    """
    result: list[Skill] = []
    result.extend(app.skills)
    for p in app.projects:
        result.extend(p.skills)
    for r in app.roles:
        result.extend(r.skills)
    for wf in app.workflows:
        result.extend(wf.skills)
        for state in wf.states:
            result.extend(state.skills)
    for p in app.projects:
        for wf in p.workflows:
            result.extend(wf.skills)
            for state in wf.states:
                result.extend(state.skills)
    return result


def _find_in_skill(skill_id: str, skill: Skill) -> Skill | None:
    """Recursively search a skill and its children for a matching ID."""
    if skill.id == skill_id:
        return skill
    for child in skill.skills:
        found = _find_in_skill(skill_id, child)
        if found:
            return found
    return None


def find_skill(skill_id: str, app: _SkillSearchable) -> Skill | None:
    for s in collect_top_level_skills(app):
        found = _find_in_skill(skill_id, s)
        if found:
            return found
    return None
