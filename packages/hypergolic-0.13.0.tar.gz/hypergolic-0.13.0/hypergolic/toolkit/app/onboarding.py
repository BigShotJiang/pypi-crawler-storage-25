from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from hypergolic.toolkit.project import Project

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App

PROMPTS_DIR = Path.home() / ".hypergolic" / "base" / "prompts"


def toolkit_prompt_fn(app: App) -> str:
    """Return the appropriate toolkit prompt based on whether user has other projects."""
    user_projects = [p for p in app.projects if p.id != "toolkit"]
    if not user_projects:
        path = PROMPTS_DIR / "onboarding.md"
    else:
        path = PROMPTS_DIR / "toolkit.md"
    if path.exists():
        return path.read_text()
    return ""


def get_builtin_toolkit_project() -> Project:
    """Return the built-in toolkit project."""
    return Project(
        id="toolkit",
        name="My Toolkit",
        description="Your agent configuration \u2014 tools, skills, prompts, and projects",
        git_root=str(Path.home() / ".hypergolic"),
        prompt_fn=toolkit_prompt_fn,
    )
