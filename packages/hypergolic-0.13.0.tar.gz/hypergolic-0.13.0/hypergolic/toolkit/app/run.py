from __future__ import annotations

import os
import subprocess
import sys
from pathlib import Path
from typing import TYPE_CHECKING

from rich.console import Console
from sqlalchemy import select

from hypergolic.cli.init_cmd import setup_gitignore, sync_base, sync_ref
from hypergolic.cli.setup import build_ui
from hypergolic.db.engine import get_db
from hypergolic.db.models import DBProject
from hypergolic.toolkit.app.launcher import launch
from hypergolic.toolkit.app.onboarding import get_builtin_toolkit_project
from hypergolic.toolkit.app.safe_mode import enter_safe_mode
from hypergolic.toolkit.app.state import set_app
from hypergolic.toolkit.app.validation import validate_app
from hypergolic.logging import setup_error_logging

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App


def expand_paths(app: App) -> None:
    app.db_path = str(Path(app.db_path).expanduser())

    for p in app.projects:
        p.git_root = str(Path(p.git_root).expanduser())
        if p.prompt_path:
            p.prompt_path = str(Path(p.prompt_path).expanduser())


def register_projects_in_db(app: App) -> None:
    with get_db() as db:
        for project in app.projects:
            resolved = str(Path(project.git_root).resolve())
            existing = db.execute(
                select(DBProject).where(DBProject.id == project.id)
            ).scalar_one_or_none()
            if existing:
                if existing.path != resolved:
                    existing.path = resolved
                if existing.name != project.name:
                    existing.name = project.name
            else:
                db.add(DBProject(id=project.id, name=project.name, path=resolved))


def run_app(app: App) -> None:
    console = Console()
    safe = "--safe" in sys.argv

    setup_error_logging()

    set_app(app)

    if os.environ.get("HYPERGOLIC_DEV_MODE", "").lower() in ("1", "true", "yes"):
        console.print("[dim]Dev mode: rebuilding frontend...[/]")
        build_ui()

        console.print("[dim]Dev mode: syncing base files...[/]")
        sync_base()
        sync_ref()
        setup_gitignore()

    if safe:
        enter_safe_mode(app)
        launch(app, safe=True)
        return

    toolkit_dir = Path.home() / ".hypergolic"
    if not (toolkit_dir / ".git").exists():
        subprocess.run(["git", "init"], cwd=toolkit_dir, capture_output=True)

    if not app.get_project("toolkit"):
        app.register_project(get_builtin_toolkit_project())

    errors = validate_app(app)
    if errors:
        console.print("\n[red]Configuration errors:[/]")
        for err in errors:
            console.print(f"  [red]\u2022[/] {err}")
        try:
            answer = input("\nLaunch in safe mode? (base tools only, no user config) [Y/n] ").strip().lower()
        except (EOFError, KeyboardInterrupt):
            answer = "n"
        if answer in ("n", "no"):
            console.print("\n[red]Fix the errors in your main.py and try again.[/]")
            return
        enter_safe_mode(app)
        launch(app, safe=True)
        return

    launch(app, safe=False)
