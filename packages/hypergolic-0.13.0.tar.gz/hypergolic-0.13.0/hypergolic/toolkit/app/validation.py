from __future__ import annotations

from pathlib import Path
from typing import TYPE_CHECKING

from hypergolic.toolkit.app.lookup import collect_top_level_skills
from hypergolic.toolkit.primitives import Skill

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App


def _collect_all_skills(skills: list[Skill]) -> list[Skill]:
    """Recursively collect all skills including nested children."""
    result: list[Skill] = []
    for skill in skills:
        result.append(skill)
        result.extend(_collect_all_skills(skill.skills))
    return result


def _detect_skill_cycles(all_skills: list[Skill]) -> list[str]:
    """Detect circular dependencies in skill nesting. Returns cycle path strings."""
    # Build adjacency list
    graph: dict[str, list[str]] = {}
    for skill in all_skills:
        if skill.id not in graph:
            graph[skill.id] = []
        for child in skill.skills:
            graph[skill.id].append(child.id)

    errors: list[str] = []
    visited: set[str] = set()
    in_stack: set[str] = set()
    path: list[str] = []

    def dfs(node: str) -> None:
        if node in in_stack:
            # Found a cycle — extract the cycle portion of the path
            cycle_start = path.index(node)
            cycle = path[cycle_start:] + [node]
            errors.append(f"Circular skill dependency detected: {' -> '.join(cycle)}")
            return
        if node in visited:
            return

        visited.add(node)
        in_stack.add(node)
        path.append(node)

        for neighbor in graph.get(node, []):
            dfs(neighbor)

        path.pop()
        in_stack.remove(node)

    for node in graph:
        if node not in visited:
            dfs(node)

    return errors


def validate_app(app: App) -> list[str]:
    """Return a list of configuration error strings (empty = valid)."""
    errors: list[str] = []

    if not app.roles:
        errors.append("No roles registered. Register at least the base roles with app.register_roles(ALL_BASE_ROLES).")

    role_ids = [r.id for r in app.roles]
    if app.roles and "generalist" not in role_ids:
        errors.append("No 'generalist' role registered. The generalist role is required as the default session role.")

    tool_ids: list[str] = []
    for t in app.tools:
        tool_ids.append(t.id)
    for p in app.projects:
        for t in p.tools:
            tool_ids.append(t.id)
    for wf in app.workflows:
        for t in wf.tools:
            tool_ids.append(t.id)
    for p in app.projects:
        for wf in p.workflows:
            for t in wf.tools:
                tool_ids.append(t.id)
    seen: set[str] = set()
    for tid in tool_ids:
        if tid in seen:
            errors.append(f"Duplicate tool ID: '{tid}'")
        seen.add(tid)

    proj_ids = [p.id for p in app.projects]
    seen_proj: set[str] = set()
    for pid in proj_ids:
        if pid in seen_proj:
            errors.append(f"Duplicate project ID: '{pid}'")
        seen_proj.add(pid)

    for p in app.projects:
        root = Path(p.git_root).expanduser()
        if not root.exists():
            errors.append(f"Project '{p.id}' git_root does not exist: {root}")
        elif not (root / ".git").exists():
            errors.append(f"Project '{p.id}' git_root is not a git repo: {root}")

    for p in app.projects:
        if p.prompt_path:
            path = Path(p.prompt_path).expanduser()
            if not path.exists():
                errors.append(f"Project '{p.id}' prompt_path not found: {path}")

    for wf in app.workflows:
        state_ids = {s.id for s in wf.states}
        if wf.initial_state not in state_ids:
            errors.append(f"Workflow '{wf.id}' initial_state '{wf.initial_state}' not found in states")
        for s in wf.states:
            for o in s.output_schemas:
                if o.next_state and o.next_state not in state_ids:
                    errors.append(f"Workflow '{wf.id}' state '{s.id}' output references unknown state '{o.next_state}'")

    # Collect all skills from every registration point
    all_skill_sources = collect_top_level_skills(app)

    # Flatten to include nested skills
    all_skills = _collect_all_skills(all_skill_sources)

    # Deduplicate by object identity: the same Skill instance may be attached
    # to multiple registration points (e.g., app + role), which is allowed.
    # Only distinct instances sharing an id count as a true duplicate.
    unique_skills: list[Skill] = []
    seen_ids_by_object: set[int] = set()
    for skill in all_skills:
        if id(skill) in seen_ids_by_object:
            continue
        seen_ids_by_object.add(id(skill))
        unique_skills.append(skill)

    # Check for duplicate skill IDs across distinct instances
    seen_skill_ids: set[str] = set()
    for skill in unique_skills:
        if skill.id in seen_skill_ids:
            errors.append(f"Duplicate skill ID: '{skill.id}'")
        seen_skill_ids.add(skill.id)

    # Detect circular skill dependencies (use deduped list)
    errors.extend(_detect_skill_cycles(unique_skills))

    return errors
