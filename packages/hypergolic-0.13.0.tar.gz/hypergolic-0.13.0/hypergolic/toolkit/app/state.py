from __future__ import annotations

from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App

_current_app: App | None = None


def set_app(app: App) -> None:
    global _current_app
    _current_app = app


def get_app() -> App:
    if _current_app is None:
        raise RuntimeError("No App has been initialized. Call set_app() first.")
    return _current_app
