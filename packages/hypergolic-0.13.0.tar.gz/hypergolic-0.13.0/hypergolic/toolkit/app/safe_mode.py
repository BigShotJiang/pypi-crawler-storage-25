from __future__ import annotations

from typing import TYPE_CHECKING

from hypergolic.base.roles.registry import ALL_BASE_ROLES
from hypergolic.base.skills.registry import ALL_BASE_SKILLS
from hypergolic.base.tools.registry import UNIVERSAL_TOOLS

if TYPE_CHECKING:
    from hypergolic.toolkit.app.core import App


def enter_safe_mode(app: App) -> None:
    app.projects = []
    app.roles = list(ALL_BASE_ROLES)
    app.workflows = []
    app.tools = list(UNIVERSAL_TOOLS)
    app.skills = list(ALL_BASE_SKILLS)
