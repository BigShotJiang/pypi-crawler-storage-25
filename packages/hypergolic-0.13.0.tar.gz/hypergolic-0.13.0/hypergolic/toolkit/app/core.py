from __future__ import annotations

from hypergolic.enums import ModelTier
from hypergolic.toolkit.app.lookup import find_skill
from hypergolic.toolkit.app.run import expand_paths, register_projects_in_db, run_app
from hypergolic.toolkit.app.validation import validate_app
from hypergolic.toolkit.primitives import Role, Skill, Tool, ToolRegistryMixin, Workflow
from hypergolic.toolkit.project import Project


class App(ToolRegistryMixin):
    tools: list[Tool]

    def __init__(
        self,
        db_path: str = "~/.hypergolic/hypergolic.db",
        truncate_token_threshold: int = 200_000,
        default_model_tier: ModelTier = ModelTier.HIGH,
    ) -> None:
        self.db_path = db_path
        self.truncate_token_threshold = truncate_token_threshold
        self.default_model_tier = default_model_tier
        self.projects: list[Project] = []
        self.tools = []
        self.roles: list[Role] = []
        self.skills: list[Skill] = []
        self.workflows: list[Workflow] = []
        self._mcp_servers: dict[str, dict] = {}

    def register_project(self, project: Project) -> None:
        self.projects.append(project)

    def register_projects(self, projects: list[Project]) -> None:
        self.projects.extend(projects)

    def register_role(self, role: Role) -> None:
        self.roles.append(role)

    def register_roles(self, roles: list[Role]) -> None:
        self.roles.extend(roles)

    def register_skill(self, skill: Skill) -> None:
        self.skills.append(skill)

    def register_skills(self, skills: list[Skill]) -> None:
        self.skills.extend(skills)

    def register_workflow(self, workflow: Workflow) -> None:
        self.workflows.append(workflow)

    def register_workflows(self, workflows: list[Workflow]) -> None:
        self.workflows.extend(workflows)

    def register_mcp_server(self, id: str, **kwargs: object) -> None:
        self._mcp_servers[id] = kwargs

    def get_project(self, project_id: str) -> Project | None:
        return next((p for p in self.projects if p.id == project_id), None)

    def get_role(self, role_id: str) -> Role | None:
        return next((r for r in self.roles if r.id == role_id), None)

    def get_skill(self, skill_id: str) -> Skill | None:
        return find_skill(skill_id, self)

    def _validate(self) -> list[str]:
        return validate_app(self)

    def _expand_paths(self) -> None:
        expand_paths(self)

    def _register_projects_in_db(self) -> None:
        register_projects_in_db(self)

    def __call__(self) -> None:
        run_app(self)
