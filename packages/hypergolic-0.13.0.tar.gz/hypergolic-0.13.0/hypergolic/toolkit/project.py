from typing import Callable

from pydantic import BaseModel, Field, model_validator

from hypergolic.toolkit.primitives import Skill, Tool, ToolRegistryMixin, Workflow, validate_prompt_exclusivity


class Project(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    description: str
    git_root: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    tools: list[Tool] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)
    workflows: list[Workflow] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)

    def register_skill(self, skill: Skill) -> None:
        self.skills.append(skill)

    def register_skills(self, skills: list[Skill]) -> None:
        self.skills.extend(skills)

    def register_workflow(self, workflow: Workflow) -> None:
        self.workflows.append(workflow)

    def register_workflows(self, workflows: list[Workflow]) -> None:
        self.workflows.extend(workflows)
