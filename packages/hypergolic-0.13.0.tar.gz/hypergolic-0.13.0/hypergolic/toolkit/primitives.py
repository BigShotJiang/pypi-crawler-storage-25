from __future__ import annotations

import inspect
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Callable, Literal, cast

from anthropic.types import ToolUnionParam
from pydantic import BaseModel, Field, model_validator

from hypergolic.messages.types import BroadcastFn
from hypergolic.schemas import Session
from hypergolic.tools.approval_view import ApprovalView
from hypergolic.tools.json_schema import optimize_schema


class InputSchema(BaseModel):
    pass


class ToolResult(BaseModel):
    content: list[dict]
    outcome: Literal["SUCCESS", "FAILURE"]


class ToolApprovalDecision(BaseModel):
    decision: Literal["ALLOW", "DENY", "REQUIRE_APPROVAL"]
    reason: str | None = None
    context: str | None = None


@dataclass
class ApprovalContext:
    """Context passed to approval callables.

    Contains everything an approval function needs to make a decision:
    the parsed tool input, the session (with active_skill_ids), etc.
    """

    input: Any
    session: Any  # hypergolic.schemas.Session (avoid circular import)
    active_skill_ids: set[str]


@dataclass
class ToolContext:
    session: Session
    broadcast: BroadcastFn
    tool_id: str


class Tool(BaseModel):
    id: str
    name: str
    description: str
    timeout: int = 30
    input_schema: type[InputSchema] | None = None
    run: Callable
    approval: Callable | str = "ALLOW"
    approval_view: ApprovalView | None = None
    sandbox_config_path: str | None = None

    model_config = {"arbitrary_types_allowed": True}

    @model_validator(mode="after")
    def _validate_run_is_async(self) -> "Tool":
        if not inspect.iscoroutinefunction(self.run):
            fn_name = getattr(self.run, "__name__", "<unknown>")
            raise ValueError(
                f"Tool '{self.id}' run function must be async. "
                f"Change 'def {fn_name}(...)' to 'async def {fn_name}(...)'."
            )
        return self

    def to_param(self) -> ToolUnionParam:
        if self.input_schema:
            schema = self.input_schema.model_json_schema()
            schema["additionalProperties"] = False
            optimize_schema(schema)
        else:
            schema = {"type": "object", "properties": {}, "additionalProperties": False}
        param: dict = {"name": self.id, "input_schema": schema}
        if self.description:
            param["description"] = self.description
        return cast(ToolUnionParam, param)


class ToolRegistryMixin:
    tools: list[Tool]

    def register_tool(self, tool: Tool) -> None:
        self.tools.append(tool)

    def register_tools(self, tools: list[Tool]) -> None:
        self.tools.extend(tools)


class OutputSchema(BaseModel):
    model_config = {"populate_by_name": True, "arbitrary_types_allowed": True}

    outcome: str
    artifact_id: str | None = None
    requires_approval: bool = False
    approval_view: ApprovalView | None = None
    schema_def: dict = Field(alias="schema")
    next_state: str | None = None


def validate_prompt_exclusivity(self: Any) -> Any:
    set_count = sum(1 for x in [self.prompt, self.prompt_path, self.prompt_fn] if x is not None)
    if set_count > 1:
        raise ValueError("Specify at most one of 'prompt', 'prompt_path', or 'prompt_fn'")
    return self


class Skill(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    tools: list[Tool] = Field(default_factory=list)
    skills: list["Skill"] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


Skill.model_rebuild()


class WorkflowState(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    truncate_on_entry: bool = False
    include_artifacts: list[str] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)
    tools: list[Tool] = Field(default_factory=list)
    output_schemas: list[OutputSchema] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


class Workflow(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    description: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    initial_state: str
    states: list[WorkflowState] = Field(default_factory=list)
    tools: list[Tool] = Field(default_factory=list)
    skills: list[Skill] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


class Role(ToolRegistryMixin, BaseModel):
    id: str
    name: str
    prompt_path: str | None = None
    prompt: str | None = None
    prompt_fn: Callable[..., str] | None = None
    skills: list[Skill] = Field(default_factory=list)
    tools: list[Tool] = Field(default_factory=list)

    model_config = {"arbitrary_types_allowed": True}

    _validate_prompt = model_validator(mode="after")(validate_prompt_exclusivity)


def resolve_prompt(obj: Any, app: Any) -> str | None:
    """Resolve prompt content from prompt_fn, prompt, or prompt_path (in that order)."""
    if hasattr(obj, "prompt_fn") and obj.prompt_fn is not None:
        return obj.prompt_fn(app)
    if hasattr(obj, "prompt") and obj.prompt is not None:
        return obj.prompt
    if hasattr(obj, "prompt_path") and obj.prompt_path is not None:
        path = Path(obj.prompt_path).expanduser()
        if path.exists():
            return path.read_text()
    return None
