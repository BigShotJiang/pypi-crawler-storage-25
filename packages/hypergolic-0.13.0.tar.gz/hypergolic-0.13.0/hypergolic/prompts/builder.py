import logging
import subprocess
from dataclasses import dataclass
from pathlib import Path

from anthropic.types import TextBlockParam

from hypergolic.toolkit.app.state import get_app
from hypergolic.toolkit.primitives import resolve_prompt
from hypergolic.schemas import Session
from hypergolic.workflows.resolver import get_session_workflow, get_workflow
from hypergolic.workflows.engine import load_artifacts
from hypergolic.workflows.rendering import render_artifact_text

logger = logging.getLogger(__name__)

DEFAULT_SYSTEM_PROMPT = "You are Hypergolic, an AI collaborator"


@dataclass
class PromptBlock:
    source: str
    text: str

    def to_text_block(self) -> TextBlockParam:
        return {"type": "text", "text": self.text}


def _git_branch(cwd: Path) -> str | None:
    try:
        result = subprocess.run(
            ["git", "rev-parse", "--abbrev-ref", "HEAD"],
            capture_output=True,
            text=True,
            check=True,
            cwd=cwd,
        )
        return result.stdout.strip() or None
    except (subprocess.CalledProcessError, FileNotFoundError):
        return None


def _build_session_context(session: Session) -> str:
    project_path = session.working_directory()
    lines = [
        "# Session Context",
        "",
        f"- Working Directory: `{project_path}`",
    ]

    branch = _git_branch(project_path)
    if branch:
        lines.append(f"- Git Branch: `{branch}`")

    if session.worktree_path:
        lines.extend(_worktree_context_lines(session))

    lines.append("- Hypergolic config: `~/.hypergolic/` (roles, project prompts, skills, workflows)")

    return "\n".join(lines) + "\n"


def _worktree_context_lines(session: Session) -> list[str]:
    lines = [
        f"- Worktree Path: `{session.worktree_path}`",
    ]
    if session.worktree_branch:
        lines.append(f"- Worktree Branch: `{session.worktree_branch}`")
    if session.base_branch:
        lines.append(f"- Base Branch: `{session.base_branch}`")
    lines.append(f"- Base Project Path: `{session.project_path}`")
    if session.worktree_seed_status and session.worktree_seed_status != "ready":
        lines.append(
            f"- Environment Seeding Status: `{session.worktree_seed_status}` "
            "(tools that need `.venv`/`node_modules` may need to wait briefly)"
        )
    lines.append("")
    lines.append(
        "> You are working in an isolated git worktree on your own branch. "
        "You can use `git add` and `git commit` freely without approval. "
        "Do not switch branches. The environment (`.venv`, `node_modules`, "
        "`.env`, etc.) has been copied from the base project. When finished, "
        "call `conclude` with `merge_ready: true` to recommend that the parent "
        "merge your branch."
    )
    return lines


def build_prompt_blocks(session: Session) -> list[PromptBlock]:
    blocks: list[PromptBlock] = []
    app = get_app()

    # Always lead with the base system prompt
    base_role = app.get_role("generalist")
    base_content = resolve_prompt(base_role, app) if base_role else None
    blocks.append(PromptBlock(
        source="Base prompt",
        text=base_content or DEFAULT_SYSTEM_PROMPT,
    ))

    # Add role-specific prompt if using a non-generalist role
    if session.role != "generalist":
        role = app.get_role(session.role)
        if role:
            role_content = resolve_prompt(role, app)
            if role_content:
                blocks.append(PromptBlock(
                    source=f"Role prompt ({session.role})",
                    text=role_content,
                ))

    project = app.get_project(session.project_id)
    if project:
        project_prompt = resolve_prompt(project, app)
        if project_prompt:
            blocks.append(PromptBlock(
                source="User-project guidance",
                text=project_prompt,
            ))

    blocks.append(PromptBlock(source="Session context", text=_build_session_context(session)))

    if session.dispatch_prompt:
        blocks.append(PromptBlock(source="Dispatch context", text=session.dispatch_prompt))

    workflow_blocks = _build_workflow_prompt_blocks(session)
    blocks.extend(workflow_blocks)

    return blocks


def _build_workflow_prompt_blocks(session: Session) -> list[PromptBlock]:
    blocks: list[PromptBlock] = []
    app = get_app()

    wf_state = get_session_workflow(session.id)
    if wf_state is None:
        return blocks

    workflow_id, current_state_id = wf_state
    wf = get_workflow(workflow_id)
    if wf is None:
        return blocks

    wf_content = resolve_prompt(wf, app)
    if wf_content:
        blocks.append(PromptBlock(
            source=f"Workflow: {wf.name}",
            text=wf_content,
        ))

    state = None
    for s in wf.states:
        if s.id == current_state_id:
            state = s
            break

    if state is None:
        return blocks

    state_content = resolve_prompt(state, app)
    if state_content:
        blocks.append(PromptBlock(
            source=f"Workflow State: {state.name}",
            text=state_content,
        ))

    if state.include_artifacts:
        artifacts = load_artifacts(session.id, state.include_artifacts)
        if artifacts:
            blocks.append(PromptBlock(
                source="Artifact preamble",
                text="The following artifacts from prior states are the source of truth for this state.",
            ))
            for artifact_id, content, created_at in artifacts:
                blocks.append(PromptBlock(
                    source=f"Artifact: {artifact_id} ({created_at})",
                    text=render_artifact_text(artifact_id, content, created_at),
                ))

    return blocks


def build_session_prompt(session: Session) -> list[TextBlockParam]:
    return [block.to_text_block() for block in build_prompt_blocks(session)]
