import asyncio
import logging
from typing import Any

from fastapi import WebSocket

from hypergolic.enums import SessionStatus
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.messages.types import BroadcastFn
from hypergolic.tools.handlers import (
    AnnotationItem,
    ApprovalRequest,
    ApprovalResponse,
)
from hypergolic.websocket.turn_manager import TurnManager
from hypergolic.websocket.schemas import ApprovalResponseMessage

logger = logging.getLogger(__name__)


def build_approval_callback(
    ws: WebSocket,
    tm: TurnManager,
    broadcast: BroadcastFn,
):
    """Return an async approval_callback bound to this connection."""

    async def approval_callback(req: ApprovalRequest) -> ApprovalResponse:
        if req.session_id:
            await set_session_status_and_broadcast(
                req.session_id, SessionStatus.AWAITING_APPROVAL, broadcast,
            )
        payload: dict[str, Any] = {
            "type": "tool_approval_request",
            "tool_use_id": req.tool_use_id,
            "tool_name": req.tool_name,
            "tool_display_name": req.tool_display_name or req.tool_name,
            "tool_input": req.tool_input,
            "session_id": req.session_id,
        }
        if req.approval_view is not None:
            payload["approval_view"] = req.approval_view.to_dict()
        await ws.send_json(payload)

        loop = asyncio.get_running_loop()
        future: asyncio.Future[ApprovalResponse] = loop.create_future()
        tm.pending_approvals[req.tool_use_id] = (req.session_id or "", future)

        try:
            response = await future
            if req.session_id:
                await set_session_status_and_broadcast(
                    req.session_id, SessionStatus.TOOL_USE, broadcast,
                )
            return response
        finally:
            tm.pending_approvals.pop(req.tool_use_id, None)

    return approval_callback


def resolve_approval_response(
    msg: ApprovalResponseMessage,
    tm: TurnManager,
) -> None:
    """Resolve a pending approval future from a client message."""
    entry = tm.pending_approvals.get(msg.tool_use_id)
    if not entry:
        return
    _sid, future = entry
    if future.done():
        return
    annotations = None
    if msg.annotations:
        annotations = [
            AnnotationItem(
                highlighted_text=a.highlighted_text,
                comment=a.comment,
            )
            for a in msg.annotations
        ]
    future.set_result(ApprovalResponse(
        approved=msg.approved,
        denial_reason=msg.denial_reason,
        annotations=annotations,
    ))
