import asyncio
import logging
from typing import Any

from anthropic.types import MessageParam
from fastapi import WebSocket

from hypergolic.enums import SessionStatus
from hypergolic.messages.types import BroadcastFn
from hypergolic.sessions.operations import create_session, load_session
from hypergolic.sessions.status import set_session_status_and_broadcast
from hypergolic.tools.handlers import ApprovalCallback
from hypergolic.websocket.helpers import build_content_blocks, format_error_detail, persist_error, persist_error_message
from hypergolic.websocket.schemas import ConnectMessage
from hypergolic.websocket.session_turn import run_session_turn
from hypergolic.workflows.engine import activate_workflow, WorkflowError

logger = logging.getLogger(__name__)


async def handle_connect(
    request: ConnectMessage,
    cancel_event: asyncio.Event,
    client: Any,
    ws: WebSocket,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback,
) -> None:
    """Handle a new chat message: create/load session, optionally activate workflow, run turn."""
    session_id: str | None = None
    try:
        if request.session_id:
            session = load_session(request.session_id)
        else:
            if not request.project_id:
                raise ValueError("project_id is required to create a new session")
            session = create_session(project_id=request.project_id, model_tier=request.model_tier)

        session_id = session.id

        if request.workflow_id:
            try:
                await activate_workflow(session, request.workflow_id, broadcast)
            except WorkflowError as wfe:
                await ws.send_json({"type": "error", "detail": str(wfe), "session_id": session.id})
                return

        content_blocks = build_content_blocks(request)
        user_message: MessageParam = {
            "role": "user",
            "content": content_blocks,
        }

        await run_session_turn(
            session.id, user_message, cancel_event,
            client, ws, broadcast, approval_callback,
        )
    except Exception as exc:
        logger.error("Error during WebSocket turn", exc_info=True)
        detail = format_error_detail(exc)
        if session_id:
            await set_session_status_and_broadcast(session_id, SessionStatus.ERROR, broadcast)
            persist_error_message(session_id, detail)
            persist_error(session_id, exc)
        try:
            await ws.send_json({"type": "error", "detail": detail, "session_id": session_id})
        except Exception:
            logger.warning("Failed to send error payload to WebSocket", exc_info=True)
