import asyncio
import logging
from typing import Any

from anthropic.types import MessageParam
from fastapi import WebSocket

from hypergolic.dispatch.core import fail_dispatch_if_child
from hypergolic.enums import SessionStatus
from hypergolic.git.operations import get_git_status
from hypergolic.messages.conversation.loop import create_message
from hypergolic.messages.types import BroadcastFn, UserInterrupt
from hypergolic.schemas import Session
from hypergolic.sessions.operations import load_session
from hypergolic.sessions.status import finalize_turn, set_session_status_and_broadcast
from hypergolic.tools.handlers import ApprovalCallback
from hypergolic.websocket.helpers import format_error_detail, persist_error, persist_error_message

logger = logging.getLogger(__name__)


async def run_session_turn(
    session_id: str,
    message: MessageParam,
    cancel_event: asyncio.Event,
    client: Any,
    ws: WebSocket,
    broadcast: BroadcastFn,
    approval_callback: ApprovalCallback,
) -> None:
    """Execute a single conversation turn for a session."""
    session: Session = load_session(session_id)

    try:
        await create_message(
            client=client,
            session=session,
            message=message,
            broadcast=broadcast,
            cancel_event=cancel_event,
            approval_callback=approval_callback,
        )

        await finalize_turn(session_id, broadcast)
        done_payload: dict[str, Any] = {"type": "done", "session_id": session_id}
        try:
            session_obj = load_session(session_id)
            git_status = get_git_status(repo=session_obj.working_directory())
            done_payload["git_status"] = git_status.model_dump()
        except Exception:
            logger.debug("Failed to include git_status in done event", exc_info=True)
        await ws.send_json(done_payload)
    except UserInterrupt as ui:
        await set_session_status_and_broadcast(session_id, SessionStatus.IDLE, broadcast)
        try:
            payload: dict[str, Any] = {"type": "interrupted", "session_id": session_id}
            if ui.partial_text:
                payload["partial_text"] = ui.partial_text
            await ws.send_json(payload)
        except Exception:
            logger.warning("Failed to send interrupt payload to WebSocket", exc_info=True)
    except Exception as exc:
        logger.error("Error during session turn %s", session_id, exc_info=True)
        detail = format_error_detail(exc)
        await set_session_status_and_broadcast(session_id, SessionStatus.ERROR, broadcast)
        persist_error_message(session_id, detail)
        persist_error(session_id, exc)
        fail_dispatch_if_child(session_id, detail)
        try:
            await ws.send_json({"type": "error", "detail": detail, "session_id": session_id})
        except Exception:
            logger.warning("Failed to send error payload to WebSocket", exc_info=True)
