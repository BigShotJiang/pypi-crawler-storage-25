import asyncio
import logging

from anthropic.types import MessageParam
from fastapi import APIRouter, WebSocket, WebSocketDisconnect

from hypergolic.auth import verify_token
from hypergolic.dispatch.core import cancel_child_dispatches, register_turn_runner
from hypergolic.messages.types import BroadcastEvent
from hypergolic.websocket.approval import build_approval_callback, resolve_approval_response
from hypergolic.websocket.client import get_client
from hypergolic.websocket.conclude import handle_conclude_session
from hypergolic.websocket.connect import handle_connect
from hypergolic.websocket.helpers import serialize_event
from hypergolic.websocket.schemas import (
    ApprovalResponseMessage,
    ConcludeSessionMessage,
    ConnectMessage,
    parse_client_message,
)
from hypergolic.websocket.session_turn import run_session_turn
from hypergolic.websocket.turn_manager import TurnManager

logger = logging.getLogger(__name__)

router = APIRouter()


@router.websocket("/ws")
async def websocket_endpoint(ws: WebSocket):
    token = ws.cookies.get("h_token", "")
    if not verify_token(token):
        await ws.close(code=4003, reason="Unauthorized")
        return
    await ws.accept()
    tm = TurnManager()

    async def broadcast(event: BroadcastEvent) -> None:
        await ws.send_json(serialize_event(event))

    approval_callback = build_approval_callback(ws, tm, broadcast)

    def start_child_turn(child_session_id: str, message: MessageParam) -> None:
        async def _child_coro(cancel_event: asyncio.Event) -> None:
            client = get_client()
            await run_session_turn(
                child_session_id, message, cancel_event,
                client, ws, broadcast, approval_callback,
            )

        tm.start_turn(child_session_id, _child_coro)

    register_turn_runner(start_child_turn)

    try:
        while True:
            raw = await ws.receive_json()
            msg = parse_client_message(raw)

            if isinstance(msg, ApprovalResponseMessage):
                resolve_approval_response(msg, tm)
                continue

            if isinstance(msg, ConcludeSessionMessage):
                await handle_conclude_session(msg, ws, tm, broadcast)
                continue

            request = msg
            target_session_id = request.session_id or "__new__"

            cancel_child_dispatches(target_session_id)
            await tm.cancel_existing_turn(target_session_id)

            async def _bound_run_turn(cancel_event: asyncio.Event, req: ConnectMessage = request) -> None:
                client = get_client()
                await handle_connect(req, cancel_event, client, ws, broadcast, approval_callback)

            tm.start_turn(target_session_id, _bound_run_turn)
    except WebSocketDisconnect:
        logger.info("WebSocket client disconnected")
    except Exception:
        logger.error("Unexpected WebSocket error", exc_info=True)
    finally:
        await tm.cleanup()
        try:
            await ws.close()
        except Exception:
            logger.debug("Failed to close WebSocket cleanly", exc_info=True)
