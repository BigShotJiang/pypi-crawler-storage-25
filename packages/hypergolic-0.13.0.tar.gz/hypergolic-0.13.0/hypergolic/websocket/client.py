from hypergolic.providers import create_client

_client = None


def get_client():
    global _client
    if _client is None:
        _client = create_client()
    return _client


def reset_client() -> None:
    """Reset the cached client (used in tests)."""
    global _client
    _client = None
