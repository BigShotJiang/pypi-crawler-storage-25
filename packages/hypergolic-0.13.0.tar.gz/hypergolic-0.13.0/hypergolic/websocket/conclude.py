import logging
from datetime import datetime, timezone

from fastapi import WebSocket
from sqlalchemy import select, update

from hypergolic.db.engine import get_db
from hypergolic.db.models import DBSession
from hypergolic.dispatch.core import cancel_child_dispatches
from hypergolic.enums import SessionStatus
from hypergolic.messages.types import BroadcastEvent, BroadcastFn
from hypergolic.websocket.schemas import ConcludeSessionMessage
from hypergolic.websocket.turn_manager import TurnManager

logger = logging.getLogger(__name__)


async def handle_conclude_session(
    msg: ConcludeSessionMessage,
    ws: WebSocket,
    tm: TurnManager,
    broadcast: BroadcastFn,
) -> None:
    """Conclude a session: cancel turns, update DB, broadcast."""
    session_id = msg.session_id

    # 1. Interrupt active turn if any
    await tm.cancel_existing_turn(session_id)

    # 2. Cancel any active child dispatches
    cancel_child_dispatches(session_id)

    # Also conclude any child sessions that are still active
    with get_db() as db:
        child_rows = db.execute(
            select(DBSession.id, DBSession.status)
            .where(DBSession.parent_id == session_id)
            .where(DBSession.status.notin_([SessionStatus.CONCLUDED.value, SessionStatus.INTERRUPTED.value]))
        ).all()
        for child_id, _status in child_rows:
            await tm.cancel_existing_turn(child_id)
            db.execute(
                update(DBSession)
                .where(DBSession.id == child_id)
                .values(status=SessionStatus.CONCLUDED.value)
            )

    # 3. Set conclusion fields on the session
    concluded_at = datetime.now(timezone.utc)
    with get_db() as db:
        db.execute(
            update(DBSession)
            .where(DBSession.id == session_id)
            .values(
                conclusion_rating=msg.rating,
                conclusion_feedback=msg.feedback,
                concluded_at=concluded_at,
                status=SessionStatus.CONCLUDED.value,
            )
        )

    # 4. Broadcast status change
    await broadcast(BroadcastEvent(
        type="session_status_change",
        role="system",
        content=[{"status": SessionStatus.CONCLUDED.value}],
        session_id=session_id,
    ))

    # 5. Send session_concluded event
    await ws.send_json({
        "type": "session_concluded",
        "session_id": session_id,
        "conclusion_rating": msg.rating,
        "conclusion_feedback": msg.feedback,
        "concluded_at": concluded_at.isoformat(),
    })
