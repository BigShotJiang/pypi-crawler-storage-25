from fastapi import APIRouter, HTTPException, UploadFile, File
from pydantic import BaseModel

from hypergolic.attachments.processing import process_image, SUPPORTED_MEDIA_TYPES

router = APIRouter(prefix="/api/attachments", tags=["attachments"])

MAX_UPLOAD_BYTES = 20 * 1024 * 1024  # 20 MB


class AttachmentResponse(BaseModel):
    type: str = "image"
    source: dict[str, str]


@router.post("/upload", response_model=AttachmentResponse)
async def upload_attachment(file: UploadFile = File(...)):
    content_type = file.content_type or "application/octet-stream"
    if content_type not in SUPPORTED_MEDIA_TYPES:
        raise HTTPException(
            status_code=400,
            detail=f"Unsupported media type: {content_type}. Supported: {', '.join(sorted(SUPPORTED_MEDIA_TYPES))}",
        )

    data = await file.read(MAX_UPLOAD_BYTES + 1)
    if not data:
        raise HTTPException(status_code=400, detail="Empty file")
    if len(data) > MAX_UPLOAD_BYTES:
        raise HTTPException(
            status_code=413,
            detail=f"File too large. Maximum size is {MAX_UPLOAD_BYTES // (1024 * 1024)} MB.",
        )

    try:
        b64_data, final_media_type = process_image(data, content_type)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    return AttachmentResponse(
        type="image",
        source={
            "type": "base64",
            "media_type": final_media_type,
            "data": b64_data,
        },
    )
