"""Discovery mixin: trending statuses, accounts, links, directory, and custom emojis."""

import json
import logging

from httpx import HTTPError

from longwei._base import __display_name__
from longwei.exceptions import NetworkError
from longwei.models import Account
from longwei.models import Card
from longwei.models import Emoji
from longwei.models import Status
from longwei.types import APClientClass
from longwei.utils import _check_exception

logger = logging.getLogger(__display_name__)


class _DiscoveryMixin:
    """Mixin providing discovery and trending content methods."""

    async def get_trending_statuses(
        self: APClientClass,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[Status]:
        """Get trending statuses on the instance.

        :param limit: Maximum number of results to return (default 20, max 40).
        :param offset: Skip the first N results.

        :returns: A list of trending statuses.

        Note:
            Implements ``GET /api/v1/trends/statuses`` (Mastodon).

        """
        logger.debug("APClient.get_trending_statuses(limit=%s, offset=%s)", limit, offset)

        await self._pre_call_checks()

        params: dict[str, int] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        url = f"{self.instance}/api/v1/trends/statuses"
        logger.debug("APClient.get_trending_statuses - url=%s, params=%s", url, params)
        try:
            response = await self.client.get(url=url, headers=self.headers, params=params, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = [Status.model_validate(s) for s in response.json()]
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.get_trending_statuses -> result:\n%s",
            json.dumps([s.model_dump() for s in result], indent=4),
        )
        return result

    async def get_trending_accounts(
        self: APClientClass,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[Account]:
        """Get accounts that are trending on the instance.

        :param limit: Maximum number of results to return.
        :param offset: Skip the first N results.

        :returns: A list of trending accounts.

        Note:
            Implements ``GET /api/v1/trends/accounts`` (Mastodon).

        """
        logger.debug("APClient.get_trending_accounts(limit=%s, offset=%s)", limit, offset)

        await self._pre_call_checks()

        params: dict[str, int] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        url = f"{self.instance}/api/v1/trends/accounts"
        logger.debug("APClient.get_trending_accounts - url=%s, params=%s", url, params)
        try:
            response = await self.client.get(url=url, headers=self.headers, params=params, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = [Account.model_validate(a) for a in response.json()]
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.get_trending_accounts -> result:\n%s",
            json.dumps([a.model_dump() for a in result], indent=4),
        )
        return result

    async def get_trending_links(
        self: APClientClass,
        limit: int | None = None,
        offset: int | None = None,
    ) -> list[Card]:
        """Get trending links (news articles and URLs) shared on the instance.

        :param limit: Maximum number of results to return.
        :param offset: Skip the first N results.

        :returns: A list of trending link preview cards.

        Note:
            Implements ``GET /api/v1/trends/links`` (Mastodon).

        """
        logger.debug("APClient.get_trending_links(limit=%s, offset=%s)", limit, offset)

        await self._pre_call_checks()

        params: dict[str, int] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset

        url = f"{self.instance}/api/v1/trends/links"
        logger.debug("APClient.get_trending_links - url=%s, params=%s", url, params)
        try:
            response = await self.client.get(url=url, headers=self.headers, params=params, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = [Card.model_validate(c) for c in response.json()]
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.get_trending_links -> result:\n%s",
            json.dumps([c.model_dump() for c in result], indent=4),
        )
        return result

    async def get_directory(
        self: APClientClass,
        limit: int | None = None,
        offset: int | None = None,
        order: str | None = None,
        local: bool | None = None,
    ) -> list[Account]:
        """Get accounts from the instance's profile directory.

        :param limit: Maximum number of results to return (default 40, max 80).
        :param offset: Skip the first N results.
        :param order: Sort order: ``active`` (recently posted, default) or ``new`` (recently joined).
        :param local: Limit results to accounts on this instance only.

        :returns: A list of accounts in the profile directory.

        Note:
            Implements ``GET /api/v1/directory`` (Mastodon).

        """
        logger.debug("APClient.get_directory(limit=%s, offset=%s, order=%s, local=%s)", limit, offset, order, local)

        await self._pre_call_checks()

        params: dict[str, int | str | bool] = {}
        if limit is not None:
            params["limit"] = limit
        if offset is not None:
            params["offset"] = offset
        if order is not None:
            params["order"] = order
        if local is not None:
            params["local"] = "true" if local else "false"

        url = f"{self.instance}/api/v1/directory"
        logger.debug("APClient.get_directory - url=%s, params=%s", url, params)
        try:
            response = await self.client.get(url=url, headers=self.headers, params=params, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            self._parse_next_prev(links=response.headers.get("Link"))
            result = [Account.model_validate(a) for a in response.json()]
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.get_directory -> result:\n%s",
            json.dumps([a.model_dump() for a in result], indent=4),
        )
        return result

    async def get_custom_emojis(self: APClientClass) -> list[Emoji]:
        """Get the list of custom emoji available on the instance.

        :returns: A list of custom emoji.

        Note:
            Implements ``GET /api/v1/custom_emojis`` (Mastodon).

        """
        logger.debug("APClient.get_custom_emojis()")

        await self._pre_call_checks()

        url = f"{self.instance}/api/v1/custom_emojis"
        logger.debug("APClient.get_custom_emojis - url=%s", url)
        try:
            response = await self.client.get(url=url, headers=self.headers, timeout=self.timeout)
            self._update_ratelimit(response.headers)
            await _check_exception(response=response)
            result = [Emoji.model_validate(e) for e in response.json()]
        except HTTPError as error:
            raise NetworkError from error

        logger.debug(
            "APClient.get_custom_emojis -> result:\n%s",
            json.dumps([e.model_dump() for e in result], indent=4),
        )
        return result
