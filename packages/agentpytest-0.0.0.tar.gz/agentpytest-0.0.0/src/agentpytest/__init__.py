"""agentpytest — pytest for AI agents.

This is a placeholder release (v0.0.0). The full library is in active design;
see the architectural spec and roadmap at:

    https://github.com/piyushbhavsarr/agentpytest

Installing this package today only registers the name and prints a notice on
import. The first functional release will be v0.1.0-alpha.
"""

from __future__ import annotations

__version__ = "0.0.0"
__all__ = ["__version__"]


def _placeholder_notice() -> str:
    return (
        "agentpytest 0.0.0 is a placeholder release. "
        "The functional library lands at v0.1.0-alpha. "
        "Track progress at https://github.com/piyushbhavsarr/agentpytest"
    )
