# 90-day launch plan

Concrete, dated, accountable. Each week has one goal and a single success metric.

## Phase 0 — Pre-launch (week -2 to 0)

**Goal:** ship a working `0.1.0-alpha` to PyPI with everything reviewers need to evaluate it.

| Day | Action | Done when |
|---|---|---|
| -14 | Reserve `agentpytest` on PyPI, GitHub org, `agentpytest.dev` domain | All three reserved |
| -13 | `git init`, scaffold per `package-layout.md`, push to private repo | CI green on empty scaffold |
| -12 to -8 | Implement core + record + 5 scorers + regression_test | `pytest` green |
| -7 to -5 | Implement `fork_from` + OTel export + CLI | End-to-end demo runs locally |
| -4 | Build coding-agent example, record demo cassette | Example green via `pytest` |
| -3 | Write README + quickstart + concepts docs | docs site renders |
| -2 | Record 90-second demo (per `demo-script.md`) | Video on YouTube unlisted |
| -1 | Show to 5 trusted devs; iterate on README based on confusion points | All 5 can install + run quickstart unaided |
| 0 | Publish `0.1.0-alpha` to PyPI; flip repo public; flip docs public | `pip install agentpytest` works |

**Phase 0 success metric:** a fresh dev can go from `pip install` to a passing test in under 5 minutes following the README.

## Phase 1 — Launch week (week 1)

**Goal:** maximum awareness in the developer-facing AI community.

| Day | Channel | Asset |
|---|---|---|
| Mon | HN "Show HN" | Title: *"Show HN: agentpytest – pytest for AI agents (records, scores, regresses)"*. Body: 4-paragraph problem→solution. Link demo video. |
| Mon | Twitter/X thread | 8 tweets: hook → comparison table → demo GIF → code snippet → repo harness teaser → judge-flexibility → install → CTA |
| Mon | LinkedIn | 60-second LinkedIn cut of demo + B2B framing (CI, regression detection, on-prem judging) |
| Tue | r/MachineLearning | Long-form post; lean academic ("statistical regression detection in agent eval") |
| Tue | r/Python | Lean Python angle: "a pytest plugin for AI agents" |
| Wed | r/LocalLLaMA | Lead with "works with Ollama / vLLM / local Qwen as judge" |
| Wed | dev.to article | Tutorial: "Add regression tests to your AI agent in 10 minutes" |
| Thu | Lobsters | Cross-post HN |
| Thu | Substack writeup | "Why agent eval needs to live in your repo, not someone else's dashboard" |
| Fri | Latent Space Discord, MLOps Community Slack, LangChain Discord, Anthropic Discord | Soft mention, link demo |

**Phase 1 success metric:** 500 GitHub stars and 1000 PyPI downloads by end of week 1.

## Phase 2 — Domain expansion (weeks 2-6)

**Goal:** prove "works for any domain" with five runnable example repos.

| Week | Ship |
|---|---|
| 2 | `agentpytest-examples-sre` — incident-response agent (kubectl + datadog mock). Blog post. |
| 3 | `agentpytest-examples-sales` — outbound prospecting agent. Blog post. |
| 4 | `agentpytest-examples-healthcare` — appointment scheduling with PHI-leak rubric. Blog post. |
| 5 | `agentpytest-examples-finance` — expense classification with policy adherence. Blog post. |
| 6 | `agentpytest-examples-coding` (polish + extend the v0.1 example). Blog post. |

Each blog post:
- Real-looking domain agent in 50–100 LoC
- 5 tests using `agentpytest`
- One staged regression caught by the lib
- SEO-targeted title: *"How to write regression tests for your <domain> AI agent"*

**Phase 2 success metric:** each domain blog post ranks on page 1 of Google for "evaluate <domain> AI agent" within 6 weeks of publication.

## Phase 3 — Repo harness ship (weeks 5-8)

**Goal:** ship `0.2.0` with `evaluate_on_repo` — the unique-in-the-market feature.

| Week | Ship |
|---|---|
| 5 | `evaluate_on_repo` API + git-worktree isolation |
| 6 | `diff_minimality`, `edit_churn`, `files_read_efficiency`, `test_regression_rate` scorers |
| 7 | Container isolation option, per-PR caching |
| 8 | Cookbook: *"Evaluating Claude Code on your own repo's PRs"* + record updated demo |

Bonus: partner with one well-known OSS project (OpenHands? Aider? smolagents?) to publish a public eval report using `0.2.0`. That report becomes the canonical citation.

**Phase 3 success metric:** at least one external publication or thread shares an `evaluate_on_repo` report on a real codebase.

## Phase 4 — Conferences & podcasts (weeks 8-12)

**Goal:** durable distribution beyond launch-day spike.

- Submit lightning talks: PyCon, EuroPython, MLOps World
- Pitch podcast appearances: Latent Space, Practical AI, Changelog, Software Engineering Daily, MLOps Community Podcast
- Submit to awesome lists: `awesome-llm-evals`, `awesome-agents`, `awesome-pytest`, `awesome-ai-evaluation`
- Conference booth at one events: AI Engineer Summit (likely sponsor a track or do a sponsored workshop)

**Phase 4 success metric:** 3 podcast appearances + 1 conference talk accepted by week 12.

## Phase 5 — Stickiness (weeks 10-12)

**Goal:** turn launch traffic into sustained users.

- [ ] First "case study" page on the docs site — anonymous if needed
- [ ] Discord server (only after there are 1k+ stars; empty Discords kill momentum)
- [ ] Monthly office hours — 30 minutes, public Zoom, demo-and-Q&A
- [ ] Newsletter (substack) — monthly: roadmap, releases, community PRs
- [ ] Launch `agentpytest@v0.3.0` with TRAIL detectors

## Distribution KPIs (90-day targets)

| Metric | Target |
|---|---|
| GitHub stars | 2000 |
| PyPI downloads (cumulative) | 50,000 |
| External case studies / blog posts mentioning the lib | 20 |
| Active contributors (≥1 merged PR) | 10 |
| Issues opened by external users | 100 |
| Domain example repos shipped | 5 |
| Conference talks / podcasts | 4 |
| Pages on agentpytest.dev | 30 |

## What we explicitly will not do

- Pay for Twitter promotions or GitHub-star-buying
- "Pivot" to SaaS based on early signals
- Add features in response to non-user demand (only ship for actual users in production)
- Take VC money before v1.0
- Compete with Phoenix/Langfuse/Weave on observability

## Single biggest risk

**Apathy.** Launch posts get a polite reception; the project plateaus at 200 stars. Mitigation: the domain expansion in phase 2 is the lever. One viral SRE post, one viral healthcare post, one viral finance post — each opens a new audience that wasn't reached on launch day. The launch is a beat, not the destination.
