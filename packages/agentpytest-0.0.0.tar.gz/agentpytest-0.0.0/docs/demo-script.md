# 90-second demo script

**Goal:** in under 90 seconds, show a viewer (a) what `agentpytest` does, (b) why they want it, (c) the wow moment.

**Format:** screen recording with voice-over. No talking head. asciinema or Loom. Aim for ≤95 seconds.

**Audience:** ML/dev engineers building agents who already know what pytest is.

---

## Storyboard

| Time | Screen | Voice-over (read at normal pace) |
|---|---|---|
| **0:00–0:08** | Open terminal. `pip install agentpytest`. | "agentpytest is a pytest plugin for AI agents. Install it like any Python package." |
| **0:08–0:20** | `cat tests/test_refactor.py` shows a 10-line test with `@trajectory_test`, `goal_completion`, `right_tool`, `redundant_call`. Highlight `Judge("gemini/gemini-2.5-pro")`. | "You write a test like this. Pick any judge — Gemini, Claude, GPT, local Llama, anything. Score the agent's trajectory with built-in scorers." |
| **0:20–0:30** | Run `pytest`. First run, no cassette. Output: `recording new cassette… PASSED`. | "First run records a cassette — a JSON snapshot of the agent's full trajectory. This is your baseline. Commit it to git." |
| **0:30–0:42** | Open `cassettes/refactor.json` briefly — show spans, tool calls, judge verdicts. Close. | "The cassette has every LLM call, every tool call, the final diff, and the judge's reasoning. Reproducible. Reviewable. Diffable." |
| **0:42–0:55** | Edit the agent's prompt slightly to introduce a regression. Run `pytest` again. Output: `FAILED — right_tool dropped 0.92 → 0.74, redundant_call rose 0.05 → 0.31`. | "Change the agent. Re-run pytest. The cassette diff catches that the agent now calls the wrong tool and makes redundant calls — without you writing a single label." |
| **0:55–1:08** | Run `agentpytest regress --baseline runs/main.json --candidate runs/pr-412.json`. Output: `right_tool Δ -0.04 p=0.03 d=0.41 REGRESSION`. | "In CI, run a paired-permutation test across many epochs. Get a real p-value with effect size — not just a flaky pass-rate. Statistical rigor in the open-source core." |
| **1:08–1:22** | Run `agentpytest replay fork --at-span tool_call:read_file#3 --mutate '{"error":"ENOENT"}'`. Show new trajectory branch. | "Debug a failure by forking the cassette at any span, mutating one tool response, and replaying forward. Counterfactual debugging in one command." |
| **1:22–1:30** | Show the 5 example repos: coding, SRE, sales, healthcare, finance. Cut to the GitHub repo. End card: "agentpytest.dev". | "Works for coding agents, SRE, sales, healthcare, finance. Same library, different rubrics. MIT licensed. agentpytest dot dev." |

---

## Recording notes

- **Font:** 16pt minimum. Solarized Dark or similar — high contrast.
- **Cursor:** large, slow movements. No fast scrolling.
- **No mouse zoom-ins.** Use terminal-only; if you must show a browser, full-frame.
- **Cuts:** every 8–12 seconds. No long unbroken takes.
- **Audio:** record voice-over separately, layer on top. Background music optional and quiet.
- **Pre-record:** stage the project so the failing-test moment looks dramatic but realistic.
- **Captions:** burned-in subtitles (auto-gen via Whisper, hand-edit). Many viewers watch muted.

## Distribution checklist for the video

- [ ] Hosted on YouTube (high quality master)
- [ ] Embedded as GIF in README (first 30s loop)
- [ ] asciinema cast for the terminal-only segments (zero buffering)
- [ ] 30-second Twitter cut for launch
- [ ] 60-second LinkedIn cut for B2B reach
- [ ] Unedited 90-second cut for HN / docs site

## Pre-launch dry-run

Run the script in front of one engineer who has never seen the project. If they can't restate "it's pytest for agents, with a cassette and statistical regressions" within 10 seconds of the video ending, the script needs a rewrite.
