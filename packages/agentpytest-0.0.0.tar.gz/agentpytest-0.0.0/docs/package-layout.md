# v0.1.0-alpha package layout

The minimum shippable PyPI package. Small, sharp, demoable. Everything beyond this scope goes in `ROADMAP.md`.

## Directory tree

```
agentpytest/
├── pyproject.toml
├── README.md
├── LICENSE                          # MIT
├── CHANGELOG.md
├── ROADMAP.md
├── CONTRIBUTING.md
├── .github/
│   └── workflows/
│       ├── test.yml                 # pytest on 3.10/3.11/3.12/3.13
│       └── publish.yml              # PyPI release on tag
├── src/
│   └── agentpytest/
│       ├── __init__.py              # public API surface
│       ├── core/
│       │   ├── __init__.py
│       │   ├── plugin.py            # pytest plugin entry point
│       │   ├── decorator.py         # @trajectory_test
│       │   ├── trajectory.py        # Trajectory, Span, FinalState models
│       │   └── markers.py           # cost_budget, flaky_trajectory
│       ├── record/
│       │   ├── __init__.py
│       │   ├── cassette.py          # cassette read/write/diff
│       │   ├── tool_lock.py         # tools.lock.json
│       │   └── fixtures.py          # frozen_clock, seeded_rng
│       ├── judge/
│       │   ├── __init__.py
│       │   ├── client.py            # Judge class wrapping LiteLLM
│       │   ├── ensemble.py          # Judge.ensemble
│       │   └── cache.py             # verdict caching by content hash
│       ├── scorers/
│       │   ├── __init__.py
│       │   ├── base.py              # Score type, scorer protocol
│       │   ├── tool_use.py          # right_tool, right_args, redundant_call,
│       │   │                        # dependency_order, tool_arg_drift
│       │   ├── outcome.py           # goal_completion, plan_quality
│       │   └── llm_judge.py         # generic llm_judge(rubric=...)
│       ├── stats/
│       │   ├── __init__.py
│       │   ├── permutation.py       # paired-permutation test
│       │   ├── bootstrap.py         # bootstrap CI
│       │   └── report.py            # regression_test entrypoint
│       ├── replay/
│       │   ├── __init__.py
│       │   └── fork.py              # fork_from
│       ├── export/
│       │   ├── __init__.py
│       │   └── otel.py              # OTLP exporter
│       └── cli/
│           ├── __init__.py
│           ├── __main__.py          # `agentpytest` entry
│           ├── regress.py           # `agentpytest regress`
│           └── replay.py            # `agentpytest replay`
├── tests/                           # our own tests
│   ├── conftest.py
│   ├── test_decorator.py
│   ├── test_cassette.py
│   ├── test_judge.py
│   ├── test_scorers_tool_use.py
│   ├── test_stats.py
│   └── test_replay.py
├── examples/                        # in-repo, runnable
│   ├── README.md
│   └── coding-agent/
│       ├── agent.py                 # toy claude-code-style agent
│       ├── tests/
│       │   └── test_refactor.py
│       └── cassettes/
│           └── refactor.json
└── docs/                            # MkDocs Material
    ├── mkdocs.yml
    ├── index.md                     # mirror of README
    ├── quickstart.md
    ├── concepts.md
    ├── scorers.md
    ├── repo-harness.md
    ├── ci.md
    └── cookbooks/
        ├── coding.md
        ├── sre.md
        ├── sales.md
        ├── healthcare.md
        └── finance.md
```

## v0.1.0-alpha shipped surface

```python
# Public API — everything importable from agentpytest
agentpytest.trajectory_test
agentpytest.Judge
agentpytest.Trajectory
agentpytest.Span
agentpytest.Score

agentpytest.scorers.right_tool
agentpytest.scorers.right_args
agentpytest.scorers.redundant_call
agentpytest.scorers.dependency_order
agentpytest.scorers.goal_completion
agentpytest.scorers.llm_judge

agentpytest.stats.regression_test
agentpytest.replay.fork_from
```

CLI:

```bash
agentpytest regress --baseline <file> --candidate <file> [--gate "..."]
agentpytest replay fork --cassette <file> --at-span <id> --mutate <json>
```

Pytest options:

```bash
pytest --update-trajectories
pytest --epochs N
pytest --cost-budget USD
```

## pyproject.toml essentials

```toml
[build-system]
requires = ["hatchling"]
build-backend = "hatchling.build"

[project]
name = "agentpytest"
version = "0.1.0a0"
description = "Pytest for AI agents — record, score, replay, regress."
readme = "README.md"
license = {text = "MIT"}
requires-python = ">=3.10"
authors = [{name = "Piyush Bhagat", email = "..."}]
keywords = ["pytest", "agents", "llm", "evaluation", "testing"]
classifiers = [
  "Development Status :: 3 - Alpha",
  "Framework :: Pytest",
  "Intended Audience :: Developers",
  "License :: OSI Approved :: MIT License",
  "Programming Language :: Python :: 3.10",
  "Programming Language :: Python :: 3.11",
  "Programming Language :: Python :: 3.12",
  "Programming Language :: Python :: 3.13",
  "Topic :: Software Development :: Testing",
]
dependencies = [
  "pytest>=7.4",
  "litellm>=1.50",
  "numpy>=1.26",
  "opentelemetry-sdk>=1.25",
  "opentelemetry-exporter-otlp>=1.25",
  "pydantic>=2.5",
  "rich>=13.7",
]

[project.optional-dependencies]
dev = ["ruff", "mypy", "pytest-cov", "hatch"]
docs = ["mkdocs-material", "mkdocstrings[python]"]

[project.entry-points.pytest11]
agentpytest = "agentpytest.core.plugin"

[project.scripts]
agentpytest = "agentpytest.cli.__main__:main"

[project.urls]
Homepage = "https://agentpytest.dev"
Repository = "https://github.com/agentpytest/agentpytest"
Documentation = "https://agentpytest.dev"
Changelog = "https://github.com/agentpytest/agentpytest/blob/main/CHANGELOG.md"
```

## CI workflow (publish on tag)

`.github/workflows/publish.yml`:

```yaml
name: publish
on:
  push:
    tags: ["v*"]
jobs:
  publish:
    runs-on: ubuntu-latest
    environment: pypi
    permissions:
      id-token: write
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-python@v5
        with: { python-version: "3.12" }
      - run: pip install hatch
      - run: hatch build
      - uses: pypa/gh-action-pypi-publish@release/v1
```

Trusted-publishing via OIDC — no API tokens stored. Set up at https://pypi.org/manage/account/publishing/ before first release.

## Versioning policy

- `0.x.y` until API stabilizes. No semver guarantees pre-1.0.
- Every breaking change in alpha bumps `y`; minor additions bump `y`.
- `1.0.0` ships when: 100+ stars, 5+ external users in production, scorer protocol frozen, repo-harness shipped.

## What's deliberately NOT in v0.1.0-alpha

- `repo_harness` (lands in 0.2.0 — needs polish)
- TRAIL detectors beyond goal_completion (lands in 0.3.0)
- Domain harness adapters — separate packages
- Streaming / long-running trajectory support
- Web UI of any kind (never)

## Pre-publish checklist

- [ ] Reserve `agentpytest` on PyPI (upload empty 0.0.0 placeholder)
- [ ] Reserve GitHub org `agentpytest` and repo
- [ ] Reserve domain `agentpytest.dev`
- [ ] Set up PyPI trusted publisher
- [ ] Write `CHANGELOG.md` for 0.1.0-alpha
- [ ] Tag `v0.1.0a0`, push, watch publish workflow run
- [ ] Verify `pip install agentpytest==0.1.0a0` works in a fresh venv
- [ ] Run the demo script end-to-end against the published package
- [ ] Open issue tracker, label `good-first-issue` on 5 starter tasks
