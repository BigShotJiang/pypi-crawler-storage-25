# agentpytest — planning docs

Working directory for the `agentpytest` design and launch. Read in this order.

## Core design

1. [`spec.md`](./spec.md) — full architectural spec
2. [`../README.md`](../README.md) — public-facing project README
3. [`../ROADMAP.md`](../ROADMAP.md) — versioned plan from v0.1.0-alpha to v1.0

## Build artifacts

4. [`package-layout.md`](./package-layout.md) — PyPI package structure, `pyproject.toml`, CI workflows
5. [`../CONTRIBUTING.md`](../CONTRIBUTING.md) — contribution guidelines

## Distribution

6. [`demo-script.md`](./demo-script.md) — 90-second demo video storyboard
7. [`launch-plan.md`](./launch-plan.md) — 90-day rollout, KPIs, channels
8. [`cookbook-domains.md`](./cookbook-domains.md) — five domain examples (coding, SRE, sales, healthcare, finance)

## At a glance

| Question | Answer doc |
|---|---|
| What is the lib doing? | [README.md](../README.md) |
| Why does it exist? | [spec §1, §2](./spec.md) |
| What's the architecture? | [spec §4–§5](./spec.md) |
| How do I use it? | [README.md](../README.md) quickstart |
| Does it work for my domain? | [cookbook-domains.md](./cookbook-domains.md) |
| When does X ship? | [ROADMAP.md](../ROADMAP.md) |
| How does it get adopted? | [launch-plan.md](./launch-plan.md) |
| How do I contribute? | [CONTRIBUTING.md](../CONTRIBUTING.md) |
| What's our code-quality bar? | [spec §10](./spec.md) |
