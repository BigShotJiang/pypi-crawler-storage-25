# spec-agentpytest

**Status:** draft v0.2 · 2026-04-29
**One-liner:** Pytest for AI agents — record, score, replay, regress. Vendorable, judge-agnostic, domain-neutral.

---

## 1. Thesis

The OSS agent-eval stack has converged everywhere except the test layer. **LiteLLM** owns model abstraction, **Phoenix/Langfuse/Weave** own trace storage and UI, **Inspect AI** owns benchmark harnessing, **agent-vcr** owns wire-level record/replay. The hole is the *pytest layer* a developer drops into their own repo to make agent behavior regression-testable like any other code. `agentpytest` fills that hole. **It is a library, not a platform.**

Universal across domains: SRE incident response, outbound sales, healthcare scheduling, finance automation, coding agents. Same primitives, different rubrics.

## 2. Non-goals

- Hosted dashboards, UI, auth, multi-tenant storage.
- New model abstraction (use LiteLLM).
- New benchmark dataset or leaderboard.
- New trace store (export OTel; let Phoenix render).
- Replacing prompt-management / annotation tools.
- Account or login flow of any kind.

If a user wants those, they compose `agentpytest` with the tool that owns the layer.

## 3. Design principles

1. **Vendorable.** `pip install agentpytest`, zero server, runs offline, no telemetry. Cassettes + scorers live in the user's repo under git.
2. **Pytest-native.** Standard collection, fixtures, markers, exit codes. No bespoke runner.
3. **Judge-first scoring.** Scorers are LLM-driven by default. Heuristics exist only where there's nothing to judge (cost counters, span counts, graph topology).
4. **Model-agnostic.** Any judge: Anthropic, OpenAI, Gemini, Groq, xAI, DeepSeek, Mistral, local vLLM/Ollama. One config flag swaps them. Built on LiteLLM so we inherit ~100 providers for free.
5. **Domain-neutral core.** No coding-agent assumptions in the data model. Domain specifics ship as separate harness packages.
6. **Composable scorers.** Each scorer is `(trajectory, judge) -> Score`. No framework lock-in.
7. **OTel out, never in.** Emit OTLP spans so Phoenix/Langfuse render unchanged. Never require an inbound integration.
8. **Snapshot semantics, not exact match.** Trajectories are noisy; diffs are semantic via judge, with cached verdicts.
9. **Statistical honesty.** Stochastic agents need N≥1 epochs and a regression test that distinguishes signal from noise — built in, not a paid feature.
10. **Smart onboarding, dumb defaults.** Auto-scaffolding lowers the cold-start cost; the resulting tests are still plain pytest files the user owns and edits.

## 3.1 Decoupling: agent under test vs judge

The agent's models and the judge's model are **independent configs**. `agentpytest` never instantiates or assumes anything about the models inside the user's agent. It only reads the resulting trajectory and asks a separately-configured judge to score it.

```
┌──────────────────────────────┐         ┌─────────────────────────┐
│  user's agentic system       │         │   agentpytest           │
│  (e.g. OpenAI planner +      │ ──────▶ │   judge = Gemini        │
│   Gemini executor +          │ traj    │                         │
│   Claude critic)             │         │   reads trajectory,     │
│                              │         │   scores via Gemini     │
│  agentpytest never touches   │         │                         │
│  these model configs         │         │                         │
└──────────────────────────────┘         └─────────────────────────┘
```

Consequences:

1. **Judge ≠ agent on purpose.** Judging with the same model that produced the output biases the verdict (self-preference). Different family for the judge is the recommended default.
2. **Per-scorer judge override.** Cheap local Qwen for `right_tool`; frontier Gemini for `goal_completion`. Each scorer call takes its own `judge=`.
3. **Provenance in the cassette.** Trajectory records which models the agent used; judge verdicts record which judge produced them. The two are never conflated.

## 3.2 What the end user must provide

A deliberately small surface. The library favors **rubrics and cassettes over labeled data**, so adoption is a single test file, not a corpus-curation project.

| Input | Required? | Notes |
|---|---|---|
| Agent function `agent(task) -> result` (or HTTP endpoint) | ✅ | The thing under test |
| Task / prompt | ✅ | What the agent should do |
| Judge model + credentials | ✅ | Any LiteLLM provider |
| Hand-labeled expected output | ❌ | Judge scores against rubric, not label |
| Golden answer / reference string | ❌ | Cassette captures first good run as baseline |
| Expected tool sequence | ⚠️ opt-in | Only for strict `right_tool(expected=[...])` |
| Past PR list | ⚠️ opt-in | Only for `repo_harness`; already in git |
| Custom rubric text | ⚠️ opt-in | Built-in scorers ship tuned rubrics |

Mental shift: classical eval asks *"here's the right answer, did the model produce it?"*; `agentpytest` asks *"here's a rubric (or the past trajectory), does this run still satisfy it?"* The cassette **is** the ground truth, bootstrapped from the first run the developer accepts.

## 3.3 Domain generality

Same primitives, different rubrics. Built-in scorers cover the universal axes (tool use, dependency order, goal completion, redundant calls); domain specifics are rubrics or harness plugins.

| Primitive | SRE | Sales | Healthcare | Finance | Coding |
|---|---|---|---|---|---|
| `right_tool` | kubectl_rollout vs delete | enrich before email | insurance check before book | policy_check before approve | read before edit |
| `dependency_order` | diagnose → remediate | research → personalize → send | verify → check → book → notify | classify → check → approve → post | read → plan → edit → test |
| `goal_completion` | incident triaged | meeting booked | appointment scheduled | journal entry posted | task done, tests green |
| Domain rubric (judge) | "no destructive op without approval" | "CAN-SPAM compliant" | "no PHI in outbound" | "no auto-approval > $5k" | "diff matches PR intent" |
| Ground-truth source | PagerDuty post-mortems | Salesforce closed-won | EHR audit log | NetSuite GL | Merged PRs in git |

The library ships with the universal scorers; domain harnesses (`agentpytest-harness-pagerduty`, `-salesforce`, `-netsuite`, `-fhir`, repo) ship as separate packages.

## 3.4 Three usage modes

The library supports three onboarding paths, in increasing order of automation:

**Mode 1 — manual.** User writes a `@trajectory_test`, picks a judge, asserts on built-in scorers. The base case.

**Mode 2 — scaffold.** User points the lib at their agent (endpoint, LiteLLM proxy, or imported traces); the lib captures real trajectories, infers a system map, and generates a draft test suite. User reviews, edits, commits. (See §5.9.)

**Mode 3 — CI.** User runs `agentpytest init github`; the lib writes a workflow file. Every PR runs the suite, computes a paired-permutation regression against main, posts a markdown comment, blocks merge on regression. (See §5.10.)

These compose: scaffold to bootstrap the suite, then push to a repo with the GitHub Action active. End-to-end: 60 seconds of CLI, 5 minutes of review, regression gating live.

## 4. Architecture

```
┌──────────────────────────────────────────────────────────────────┐
│                    user's repo (vendor)                           │
│  tests/                                                           │
│    test_my_agent.py    ← @trajectory_test                         │
│    cassettes/*.json    ← golden trajectories (git-tracked)        │
│    rubrics/*.md        ← domain rubrics (optional)                │
│    .agentpytest/       ← config, system map (scaffold output)     │
│  .github/workflows/agentpytest.yml  ← CI (init output)            │
└──────────────────────────────────────────────────────────────────┘
                                │
   ┌────────────┬───────────────┼───────────────┬────────────┐
   ▼            ▼               ▼               ▼            ▼
┌──────┐  ┌─────────┐  ┌─────────────┐  ┌──────────┐  ┌──────────┐
│ core │  │ scorers │  │   replay    │  │ scaffold │  │   init   │
│ pytest│  │ (judge) │  │ fork+mutate │  │  capture │  │ CI YAML  │
│ plugin│  │ +rubrics│  │             │  │  analyze │  │  wizard  │
└──────┘  └─────────┘  └─────────────┘  │  generate│  └──────────┘
   │           │              │         └──────────┘
   ▼           ▼              ▼              │
┌──────┐  ┌─────────┐  ┌─────────────┐       │
│record│  │  stats  │  │    trail    │       │
│ +tool│  │ permu-  │  │ failure-mode│       │
│ lock │  │ tation  │  │  detectors  │       │
└──────┘  └─────────┘  └─────────────┘       │
   │                                          │
   ▼                                          ▼
┌────────────┐                         ┌──────────────┐
│ harnesses  │ (separate packages)     │   judge      │
│ repo / sre │                         │ (LiteLLM)    │
│ sales / ... │                        │ ensembles    │
└────────────┘                         └──────────────┘
   │                                          │
   ▼                                          ▼
            OTLP exporter ──→ user's Phoenix/Langfuse/Weave
```

Ten modules, ~5 kLoC v1 target. Required deps: `pytest`, `litellm`, `agent-vcr`, `numpy`, `opentelemetry-sdk`, `pydantic`, `rich`. Optional: `httpx` (for endpoint capture), `gitpython` (for repo harness).

## 5. Module specs

### 5.1 `core` — pytest plugin and `AgentClient`

The user declares their agent integration in **code**, not configuration. `AgentClient` is a small base class with two override points; everything else is defaulted.

```python
# tests/conftest.py
from agentpytest import AgentClient, Trajectory
import os, httpx

class MyAgent(AgentClient):
    url = "http://localhost:8000/agent/run"
    timeout = 120

    def build_request(self, task: str, session_id: str) -> dict:
        return {
            "json": {"input": task, "session_id": session_id},
            "headers": {"Authorization": f"Bearer {os.environ['MY_AGENT_KEY']}"},
        }

    def parse_response(self, response: httpx.Response, session_id: str) -> Trajectory:
        body = response.json()
        return Trajectory.from_otel_spans(
            spans=body["trace"],
            final_output=body["result"]["message"],
            session_id=session_id,
        )
```

Three flavors cover production cases:

| Class | When |
|---|---|
| `AgentClient` | Sync HTTP endpoint (most production agents) |
| `AsyncAgentClient` | Async / streaming (override `parse_stream` for SSE / chunked) |
| `LocalAgentClient` | In-process callable (notebooks, monoliths, demos) |

Base classes provide retries, timeouts, connection pooling, session-id generation, cost/latency timing, OTel emission, and cassette plumbing. Users override only what's specific to their agent.

Test usage is unchanged regardless of integration mode:

```python
from agentpytest import trajectory_test, Judge
from agentpytest.scorers import goal_completion, right_tool

agent = MyAgent()
judge = Judge("anthropic/claude-sonnet-4-6")

@trajectory_test(cassette="cassettes/refactor.json", epochs=10)
def test_refactor():
    r = agent.run("Refactor auth.py to use TokenStore")
    assert goal_completion(r, judge=judge).value > 0.8
    assert right_tool(r, judge=judge).value > 0.9
```

Pytest plugin behavior:

- Records first run to cassette; subsequent runs diff against it.
- `pytest --update-trajectories` regenerates cassettes (like `--snapshot-update`).
- `epochs=N` runs the test N times; result is the per-scorer distribution, not a single value.
- Markers: `@pytest.mark.flaky_trajectory(tolerance=0.2)`, `@pytest.mark.cost_budget(usd=0.50)`.
- Diff format is structural: `spans[]`, `tool_calls[]`, `final_state`, with field-level tolerance.

Validation: `agentpytest probe MyAgent` runs a single test task end-to-end and reports which scorers will work given the data the client surfaces. Run before any test suite to catch integration bugs early.

### 5.2 `record` — cassette format

Built on `agent-vcr` for the wire layer; adds:

- **Tool-version manifest** (`tools.lock.json`) hashing MCP server versions and tool schemas. Cassette fails fast if tool surface changed.
- **Frozen RNG + frozen time** as pytest fixtures (`frozen_clock`, `seeded_rng`).
- **Cassette schema v1**: `{meta, tools_lock, spans[], final_state, judge_verdicts[]}`. Spans are OTel-shaped so they round-trip to Phoenix.
- **Multi-agent aware.** Spans carry `agent_name` and `parent_id`, so multi-agent systems (orchestrator + sub-agents) record as a single coherent trajectory.

Explicitly *not* solving model determinism — record/replay handles it; we don't pretend LLMs are seedable.

### 5.3 `scorers` — judge-driven functions over a trajectory

```python
from agentpytest import Judge
from agentpytest.scorers import (
    right_tool, right_args, redundant_call, dependency_order, tool_arg_drift,
    goal_completion, plan_quality, llm_judge,
)

judge = Judge("anthropic/claude-sonnet-4-6")

@trajectory_test(cassette="cassettes/incident.json", epochs=10)
def test_incident_response():
    r = sre_system({"alert": "payments-api 5xx spike"})
    assert right_tool(r, agent="DiagnoseAgent", judge=judge).value > 0.9
    assert dependency_order(r, expected_dag={"diagnose": [], "remediate": ["diagnose"]}).value == 1.0
    assert goal_completion(r, judge=judge).value > 0.85
```

Contract: `def scorer(trajectory: Trajectory, *, judge: Judge | None, agent: str | None, **opts) -> Score`. `Score = {value: float in [0,1], detail: dict, reasoning: str, failures: list[Failure]}`. Composable via `composite([...], weights=...)`.

- `agent=` filter restricts the scorer to spans from one sub-agent (multi-agent support).
- Rubrics ship tuned per scorer; users override via `llm_judge.with_rubric(...)`.
- Verdicts cached in cassette keyed on `(trajectory_hash, rubric_hash, judge_model)`.

Deterministic metrics (cost, latency, span counts) are exposed as `metrics`, not `scorers` — no judgment involved.

**`Judge` abstraction:**

```python
Judge(
    model="anthropic/claude-sonnet-4-6",   # any LiteLLM model id
    temperature=0.0,
    max_retries=3,
    structured_output=True,
    fallback=Judge("ollama/qwen2.5:32b"),
)

# ensembles
Judge.ensemble(
    [Judge("anthropic/claude-sonnet-4-6"), Judge("openai/gpt-5"), Judge("gemini/gemini-2.5-pro")],
    aggregation="median",   # or "majority", "mean", "worst"
)
```

Disagreement across the ensemble surfaces as `Score.detail["judge_variance"]` and is gateable separately in CI.

### 5.4 `stats` — regression with statistical honesty

```python
from agentpytest.stats import regression_test

result = regression_test(
    baseline=load_runs("baseline/"),
    candidate=load_runs("candidate/"),
    method="paired_permutation",  # or "bootstrap"
    alpha=0.05,
)
# result: {p_value, effect_size, ci_low, ci_high, is_regression}
```

- Paired permutation when same prompts run on both sides; bootstrap otherwise.
- Reports effect size (Cohen's d / rank-biserial) so reviewers see practical significance.
- CLI: `agentpytest regress --baseline runs/main.json --candidate runs/pr-123.json --gate "accuracy>=baseline,cost<=baseline*1.1"`. Exit code drives CI.
- CLI refuses to print bare p-values — effect size + CI always shown.

### 5.5 `replay` — trace mutate-and-replay

```python
from agentpytest.replay import fork_from

new_traj = fork_from(
    cassette="cassettes/incident.json",
    at_span="tool_call:datadog_query#2",
    mutate=lambda span: span.with_response({"error": "rate_limited"}),
)
```

- Replays the cassette deterministically up to `at_span`, applies the mutation, then runs the live agent for the suffix.
- Supports counterfactual debugging and reduced-trajectory tests.
- Output is a new cassette + diff against the original.

Nothing in OSS does this today.

### 5.6 `trail` — failure-mode detectors

Port of the **TRAIL taxonomy** (Patronus, public paper) as ~20 detectors, all driven by the `Judge` abstraction. Each detector ships a rubric + structured-output schema and runs against the relevant span window.

Categories: reasoning failures (hallucination, misinterpretation, wrong-problem-identification, goal-deviation, poor-retrieval, format-error, instruction-noncompliance), execution failures (bad-tool-definition, env-setup, http-loops, resource-exhaustion, timeout-loop), planning failures (context-handling, orchestration-error, tool-call-repetition).

Each returns `Failure(kind, span_ids, evidence, severity, judge_reasoning)`. Cheap local judge for always-on detection; frontier judge for CI gates.

### 5.7 `harnesses` — domain-specific ground-truth sources

A `Harness` interface in core; concrete implementations ship as separate packages. Each harness replays past tasks and feeds them to the user's agent for scoring.

```python
from agentpytest.harnesses import Harness   # protocol

class Harness(Protocol):
    def list_tasks(self) -> list[Task]: ...
    def setup(self, task: Task) -> Context: ...
    def teardown(self, ctx: Context) -> None: ...
    def ground_truth(self, task: Task) -> Trajectory | FinalState: ...
```

Reference implementations:

| Package | Source of truth |
|---|---|
| `agentpytest-harness-repo` | Past merged PRs (git) — coding agents |
| `agentpytest-harness-pagerduty` | Past incidents + post-mortems — SRE |
| `agentpytest-harness-salesforce` | Closed-won deals — sales |
| `agentpytest-harness-netsuite` | Audited transactions — finance |
| `agentpytest-harness-fhir` | EHR audit log — healthcare (no-egress mode) |

The repo harness is the v0.2 reference implementation:

```python
from agentpytest.harnesses.repo import evaluate_on_repo

report = evaluate_on_repo(
    repo="/path/to/myrepo",
    pr_list=["#412", "#418", "#431"],
    agent_fn=my_agent,
    isolation="git_worktree",  # or "container"
)
```

For each task, harness sets up context (worktree, PagerDuty replay, etc.), runs the agent, scores its trajectory against ground truth — judge-based semantic equivalence, not byte equality.

### 5.8 `export` — OTel only

Spans serialize to OTLP. That's it. No proprietary backend. Users point `OTEL_EXPORTER_OTLP_ENDPOINT` at Phoenix/Langfuse/Weave. We do not own the UI.

### 5.9 `scaffold` — auto-discovery and test generation

Lowers cold-start cost from "write a test suite" to "review a generated draft." Three sub-stages:

```bash
# Stage 1: capture real trajectories
agentpytest scaffold capture --endpoint http://localhost:8000/agent --probe-tasks probes.txt --runs 20
# OR
agentpytest scaffold proxy --duration 1h     # LiteLLM proxy mode
# OR
agentpytest scaffold import --from phoenix --project sre-agent

# Stage 2: analyze with meta-LLM
agentpytest scaffold analyze --judge anthropic/claude-sonnet-4-6
# emits .agentpytest/system-map.yaml — agents, tools, inferred DAG, invariants, risks

# Stage 3: generate draft test suite
agentpytest scaffold generate
# emits tests/, rubrics/, prompts/, cassettes/ (empty until first run)
```

Capture modes:

| Mode | How | Use when |
|---|---|---|
| `endpoint` | Black-box probe with N synthetic tasks | Fastest to set up, shallow coverage |
| `proxy` | LiteLLM proxy in front of user's LLM calls | Deepest signal — captures real prompts + tools |
| `import` | Pull from Phoenix/Langfuse/Weave/OTLP | Zero code change for users with existing tracing |

System map is human-editable YAML. Generated tests carry a `REVIEW BEFORE SHIPPING` header until the user removes it; CLI refuses to use unreviewed tests as CI baselines. Generation is **always grounded in captured trajectories**, never from prompts alone — hallucinated rubrics are the #1 risk and trajectories are the truth-ground.

### 5.10 `init` — scaffolding wizards

Two wizards, both write Python and YAML the user owns and edits.

```bash
agentpytest init agent --url http://localhost:8000/run --auth bearer
# generates a starter AgentClient subclass in tests/conftest.py
# auto-detects common API shapes (OpenAI-compatible, Anthropic-compatible,
# LangChain Server, FastAPI). User edits if their API doesn't match.

agentpytest init github
# 60-second wizard → writes .github/workflows/agentpytest.yml + tests/conftest.py
# Prints which secrets to set (e.g., ANTHROPIC_API_KEY)
```

Generates a workflow that, on every PR:
1. Runs the eval suite with N epochs.
2. Restores main's baseline run from GitHub Actions cache.
3. Runs `agentpytest regress` against the baseline.
4. Posts a markdown PR comment via `GITHUB_TOKEN` (no third-party app).
5. Exits non-zero on regression → branch protection blocks merge.

On main push: saves the new baseline to the cache.

Providers: `github`, `gitlab`, `circleci`, `bitbucket`, `jenkins`. All call the same `agentpytest run` and `agentpytest regress` CLI commands. **No hosted GitHub App** — the user's CI runs everything; the lib provides only YAML + CLI.

Baseline storage options (configurable):
- GitHub Actions cache (default — free, ephemeral)
- Dedicated `agentpytest-baselines` git branch (permanent, auditable)
- S3/R2/GCS (advanced, for teams with shared baselines across repos)

## 6. Data model

Domain-neutral. The core trajectory carries no coding-agent assumptions; domain-specific fields live in `final_state.attrs` or harness extensions.

```python
class Trajectory:
    meta: Meta                    # agents, models, tools_lock_hash, seed, started_at
    spans: list[Span]             # OTel-shaped, ordered; multi-agent aware
    final_state: FinalState       # status + free-form attrs
    cost: Cost                    # tokens_in, tokens_out, usd, latency_ms (per agent + total)
    judge_verdicts: list[Verdict] # cached scorer outputs

class Span:
    span_id: str
    parent_id: str | None
    agent_name: str | None        # for multi-agent filtering
    kind: Literal["llm", "tool_call", "tool_result", "agent_step", "delegation"]
    name: str
    attrs: dict
    start_ns: int
    end_ns: int

class FinalState:
    status: Literal["success", "failure", "escalated", "incomplete"]
    attrs: dict                   # domain-specific (diff, booking_id, journal_entry, etc.)
```

The DAG is implicit in `parent_id` + `delegation` spans — graph scorers walk it. Multi-agent systems are first-class.

## 7. Public API surface

```
# core
agentpytest.trajectory_test
agentpytest.AgentClient
agentpytest.AsyncAgentClient
agentpytest.LocalAgentClient
agentpytest.Judge
agentpytest.Trajectory
agentpytest.Span
agentpytest.Score

# scorers (judge-driven unless noted)
agentpytest.scorers.right_tool
agentpytest.scorers.right_args
agentpytest.scorers.redundant_call           # heuristic
agentpytest.scorers.dependency_order          # heuristic
agentpytest.scorers.tool_arg_drift
agentpytest.scorers.goal_completion
agentpytest.scorers.plan_quality
agentpytest.scorers.llm_judge                 # generic rubric

# stats / replay / trail
agentpytest.stats.regression_test
agentpytest.replay.fork_from
agentpytest.trail.detect_*                    # ~20 detectors

# harnesses (in-tree reference; rest as separate packages)
agentpytest.harnesses.Harness                 # protocol
agentpytest.harnesses.repo.evaluate_on_repo

# CLI
agentpytest run
agentpytest regress
agentpytest replay
agentpytest probe                           # validate AgentClient end-to-end
agentpytest scaffold {capture, proxy, import, analyze, generate, refine}
agentpytest init {agent, github, gitlab, circleci, bitbucket, jenkins}
```

If it doesn't fit on this page, it doesn't ship in v1.

## 8. Roadmap (versioned)

| Version | Theme | Modules added |
|---|---|---|
| **0.1.0-alpha** | Core MVP | `core`, `record`, `scorers` (5 universal), `stats`, `replay`, `export`, CLI (run, regress, replay) |
| **0.2.0** | Repo harness + CI | `harnesses.repo`, `init github`, GitHub Action template, baseline storage |
| **0.3.0** | TRAIL detectors | `trail.detect_*` (all ~20), local-judge defaults |
| **0.4.0** | Domain harnesses | `Harness` protocol, `agentpytest-harness-pagerduty`, `-salesforce`, `-netsuite`, `-fhir` (separate packages) |
| **0.5.0** | Scaffold mode | `scaffold capture/proxy/import/analyze/generate/refine` |
| **0.6.0** | Long-running / async | Cassette schema v2, pause/resume, streaming events |
| **1.0.0** | Stable | Scorer contract frozen, conformance suite, 5+ external prod users |

Detail in `agentpytest/ROADMAP.md`.

## 9. Risks and how we kill them

- **Cassette rot.** Tool-lock manifest, semantic diff with judge tolerance, easy regen via `--update-trajectories`.
- **Judge cost.** Verdicts cached in cassette by content hash; cheap-local-judge default; ensembles only at CI gates; per-test `cost_budget` marker.
- **Judge flakiness / bias.** Structured output with retries, ensemble aggregation, `judge_variance` exposed as separate signal, swappable per scorer.
- **Auto-generated tests are bad.** Scaffold tests carry `REVIEW BEFORE SHIPPING` header; CLI refuses unreviewed-tests-as-baselines; generation is always grounded in captured trajectories, not just prompts.
- **CI lock-in.** All `init` providers compile to the same CLI calls; switching providers is a YAML swap.
- **Privacy in regulated domains.** Local-judge mode (Ollama/vLLM) ships first-class; healthcare/finance docs lead with no-egress configuration.
- **Repo-harness ground-truth quality.** Merged PR ≠ optimal solution. Judge-based semantic equivalence; ensemble scoring; documented as *agreement with team's past behavior*, not absolute correctness.
- **Stats misuse.** CLI always shows effect size + CI alongside p-value; refuses bare p-values.
- **Scope creep into "platform."** Every PR that adds a server, dashboard, or hosted feature is closed without review. README states this explicitly.

## 10. Engineering standards

The reference bar: **`pytest`, `httpx`, `pydantic`, `rich`, `ruff`, `litellm`**. Libraries developers actually enjoy adopting share traits — small surface, typed, fast, testable, predictable. We hit the same bar from day one or we don't ship.

### 10.1 Code style

- **`ruff format` + `ruff check`** as the only formatter and linter. Config in `pyproject.toml`. CI rejects unformatted code.
- **Line length 100.** No exceptions hidden in noqa.
- **Sorted imports** via ruff's isort rules.
- **No `print`** in library code — `logging` with structured fields, or `rich` for CLI output.
- **No `TODO`/`FIXME`** in shipped code. If it's worth a TODO, it's worth a tracked issue.
- **No dead code, no commented-out blocks.** Git remembers; the file shouldn't.

### 10.2 Type discipline

- **`mypy --strict`** on `src/agentpytest/`. CI fails on any type error.
- **`pydantic v2`** for all data models (`Trajectory`, `Span`, `Score`, `Verdict`, etc.). No raw dicts in public APIs.
- **`Protocol`** for plugin contracts (`Scorer`, `Harness`, `Judge`). Duck typing is for tests, not interfaces.
- **`Literal`** for enum-like fields; no string magic.
- **No `Any`** in public type signatures except where unavoidable (and then justified in a comment).

### 10.3 API design

- **Small surface, sensible defaults.** Every public function should be callable with one or two arguments for the common case.
- **Keyword-only args** for anything beyond the first two positional ones. `def scorer(traj, *, judge, agent=None, rubric=None)`.
- **Composability over configuration.** New behavior comes from composing primitives, not from new flags.
- **Stable contracts.** Public types frozen at `1.0`; new fields are additive only.
- **No magic.** No metaclasses, no monkey-patching, no import-time side effects, no global state.
- **Errors are typed.** `agentpytest.errors.{ConfigError, JudgeError, CassetteError, RegressionError}` — never raw `RuntimeError`.

### 10.4 Testing

- **Library coverage ≥ 90%** measured on `src/agentpytest/`. Below that, CI fails.
- **`pytest` for unit tests, `hypothesis` for property tests** on cassette diff/merge logic and stats math.
- **Snapshot tests** for CLI output (`syrupy`).
- **VCR-style fixtures** for any test that touches an LLM — no live model calls in CI by default; an opt-in `--live` flag for nightlies.
- **Mutation testing** (`mutmut`) on `stats/` — math modules cannot have silent regressions.
- **Multi-version matrix:** Python 3.10, 3.11, 3.12, 3.13. Linux, macOS, Windows.

### 10.5 Performance

- **Hot paths benchmarked.** `pytest-benchmark` for `Trajectory` parsing, cassette diff, span graph traversal.
- **No N² scans** on spans. Indexed access via `span_id` map built once.
- **Concurrent capture and judge calls** via `asyncio` where the user-facing API stays sync (`run_until_complete` internally).
- **Caching is content-addressed.** Judge verdicts keyed on `sha256(rubric + trajectory_excerpt + judge_model)`; never invalidated by accident.

### 10.6 Dependencies

- **Minimum required deps** for the library to import: `pytest`, `litellm`, `pydantic`, `httpx`, `numpy`, `opentelemetry-sdk`, `rich`.
- **Optional extras** for less-common paths: `[harness]` for `gitpython`, `[scaffold]` for capture deps, `[stats]` only if numpy isn't enough.
- **No left-pad-class deps.** Every transitive dep is reviewed; `pip-audit` runs in CI.
- **Pin lower bounds, not upper.** Don't break for users who upgrade their Python or numpy.

### 10.7 Documentation

- **Every public function has a docstring** with: one-line summary, Args, Returns, Raises, one example. Enforced by `ruff` (`D` rules).
- **Examples are tested** via `pytest --doctest-modules`. If the example breaks, the build breaks.
- **Architecture decisions** live in `docs/decisions/NNNN-title.md` (ADR format). Important "why we didn't do X" lives here.
- **Changelog is curated**, not autogenerated. Each entry says what users need to know.

### 10.8 Repository hygiene

- **Conventional commits** (loose). `feat:`, `fix:`, `docs:`, `refactor:`, `test:`, `perf:`, `chore:`.
- **One PR, one concern.** No drive-by refactors.
- **Branch protection on `main`:** required CI green, 1 review, no force push.
- **Trusted publishing to PyPI** via OIDC. No long-lived API tokens.
- **Release tags signed.** `git tag -s vX.Y.Z`.
- **Reproducible builds.** `hatch build` produces identical artifacts on identical input.

### 10.9 Observability of the library itself

- Library emits its own OTel spans for `Judge.call`, `cassette.read`, `cassette.write`, `regression.compute`. Users debugging the lib see exactly where time is spent.
- `--verbose` flag on every CLI command shows full trace including judge prompts and verdicts (with cost).
- Errors carry context: which test, which span, which judge, which rubric. Stack traces are user-actionable.

### 10.10 What we will not do

- No 5000-line modules. Hard cap at ~500 lines per file; split when it grows.
- No clever code where readable code works. Optimize for the next maintainer, not for terseness.
- No silent fallbacks. If the configured judge fails and there's no `fallback=`, raise — don't pretend it worked.
- No string-based config DSLs. If it's complex enough to need a DSL, it should be Python.
- No vendored copies of upstream libraries. If we need to fork, we contribute back first.

The goal: a developer reading our source for the first time should think *"this is the codebase I want my own project to look like."* That's the reputation we ship for.

## 11. License + governance

MIT. No CLA. Single-maintainer to start. Conformance tests for `Scorer` and `Harness` contracts published from day one so third-party plugins stay drop-in.

---

**TL;DR:** A pytest plugin with ten modules. Records and diffs trajectories; scores them with any LLM judge across ~100 providers; runs paired-permutation regression tests; forks-and-mutates traces for counterfactual debugging; auto-scaffolds a draft test suite from a user's running agent; one-command CI integration with PR-comment regression reports; harness plugins for SRE, sales, healthcare, finance, coding. Domain-neutral core, vendorable, MIT, no SaaS. Composes with everything; replaces nothing.
