# Roadmap

Versioned, dated, opinionated. Things ship in this order. Things not on this list are not on the roadmap — open an issue first.

## v0.1.0-alpha — *core* (target: launch week)

The MVP. Demoable, vendorable, useful.

- [x] `@trajectory_test` pytest decorator
- [x] Cassette format v1 (JSON, OTel-shaped spans)
- [x] `Judge` class wrapping LiteLLM (~100 providers)
- [x] 5 scorers: `right_tool`, `right_args`, `redundant_call`, `dependency_order`, `goal_completion`
- [x] Generic `llm_judge(rubric=...)` escape hatch
- [x] `regression_test` (paired permutation + bootstrap CI)
- [x] `fork_from` for trace mutate-and-replay
- [x] OTLP exporter (Phoenix/Langfuse/Weave compatible)
- [x] CLI: `agentpytest regress`, `agentpytest replay`
- [x] One runnable example: coding agent

## v0.2.0 — *repo harness* (+4 weeks)

The differentiator. Eval an agent on your team's actual past PRs.

- [ ] `evaluate_on_repo(repo, pr_list, agent_fn, scorers)`
- [ ] Git worktree isolation
- [ ] Container isolation option (Docker)
- [ ] Scorers: `diff_minimality`, `edit_churn`, `files_read_efficiency`, `test_regression_rate`
- [ ] Per-PR caching of setup state
- [ ] `tools.lock.json` integration
- [ ] Cookbook: "evaluating Claude Code on your repo"

## v0.3.0 — *TRAIL detectors* (+8 weeks)

Failure-mode taxonomy. Ports public Patronus research as opt-in scorers.

- [ ] 7 reasoning detectors (hallucination, misinterpretation, wrong-problem, goal-deviation, poor-retrieval, format-error, instruction-noncompliance)
- [ ] 5 execution detectors (bad-tool-def, env-setup, http-loops, resource-exhaustion, timeout-loop)
- [ ] 3 planning detectors (context-handling, orchestration-error, tool-call-repetition)
- [ ] All driven by pluggable judge — local Qwen as default
- [ ] Severity-aware aggregation

## v0.4.0 — *domain harnesses* (+12 weeks)

`Harness` plugin protocol. Each domain ships as a separate package so core stays small.

- [ ] `Harness` interface in core
- [ ] `agentpytest-harness-pagerduty` (SRE)
- [ ] `agentpytest-harness-salesforce` (sales)
- [ ] `agentpytest-harness-netsuite` (finance)
- [ ] FHIR-based `agentpytest-harness-healthcare` (with strict no-PHI-egress mode)
- [ ] Cookbook per domain

## v0.5.0 — *judge ensembles + variance* (+16 weeks)

- [ ] `Judge.ensemble([...], aggregation=)` with median/majority/worst/mean
- [ ] `judge_variance` exposed as separate gateable signal
- [ ] Self-consistency scorer (same judge, N samples, agreement rate)
- [ ] Documentation on bias and judge selection

## v0.6.0 — *long-running / async trajectories* (+20 weeks)

The hardest engineering work. Cassettes today assume bounded synchronous runs.

- [ ] Cassette format v2: pause/resume, async event ingestion
- [ ] Wall-clock vs logical-clock distinction
- [ ] Streaming-event trajectories (SRE on-call, sales sequences)
- [ ] Webhook ingest for trigger-based agents

## v1.0.0 — *stable* (no date)

Ships when:
- 100+ GitHub stars
- 5+ external users running in production CI
- Scorer protocol frozen for one full minor cycle
- Repo harness battle-tested on 3+ public projects
- Public conformance test suite

Until then, treat the API as evolving.

## Explicitly not on the roadmap

- Web UI / dashboard (Phoenix/Langfuse own this layer)
- Hosted SaaS (the whole USP is "stays a library")
- New trace storage backend (we export OTel; backends already exist)
- New model abstraction (LiteLLM owns this)
- Benchmark/leaderboard (Inspect AI / SWE-bench own this)
- Auth / multi-tenant features
- Auto-prompt-tuning
