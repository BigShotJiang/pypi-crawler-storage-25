# Changelog

All notable changes to `agentpytest` are recorded here. The format follows
[Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and the project
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [Unreleased]

- Core `@trajectory_test` decorator
- `AgentClient` / `AsyncAgentClient` / `LocalAgentClient` base classes
- `Judge` abstraction over LiteLLM (~100 providers)
- Universal scorers: `right_tool`, `right_args`, `redundant_call`,
  `dependency_order`, `goal_completion`
- `regression_test` (paired-permutation + bootstrap)
- `fork_from` mutate-and-replay
- OTLP exporter
- CLI: `run`, `regress`, `replay`, `probe`

## [0.0.0] — 2026-04-29

Initial placeholder release. Reserves the project name on PyPI and
publishes the architectural spec and roadmap. No functional code yet.

[Unreleased]: https://github.com/piyushbhavsarr/agentpytest/compare/v0.0.0...HEAD
[0.0.0]: https://github.com/piyushbhavsarr/agentpytest/releases/tag/v0.0.0
