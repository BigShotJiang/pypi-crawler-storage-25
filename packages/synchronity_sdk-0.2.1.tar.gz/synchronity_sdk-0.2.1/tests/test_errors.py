"""Tests for error handling and the error hierarchy."""
from __future__ import annotations

import pytest
import respx
import httpx

from agentmesh.errors import (
    AgentMeshError,
    AuthenticationError,
    AuthorizationError,
    ConnectorError,
    NetworkError,
    NotFoundError,
    RateLimitError,
    TimeoutError,
    ValidationError,
    parse_error_response,
)
from tests.conftest import BASE_URL, ERROR_BODY, make_client


def _error(code: str = "ERR", message: str = "Something went wrong") -> dict:
    return {"error": {"code": code, "message": message}}


async def test_401_raises_authentication_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(401, json=_error("UNAUTHORIZED", "Invalid token"))
        )
        client = make_client()
        with pytest.raises(AuthenticationError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 401
        assert exc_info.value.code == "UNAUTHORIZED"


async def test_403_raises_authorization_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(403, json=_error("FORBIDDEN", "Access denied"))
        )
        client = make_client()
        with pytest.raises(AuthorizationError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 403


async def test_404_raises_not_found_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(404, json=_error("NOT_FOUND", "Product not found"))
        )
        client = make_client()
        with pytest.raises(NotFoundError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 404


async def test_410_raises_not_found_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(410, json=_error("GONE", "Resource gone"))
        )
        client = make_client()
        with pytest.raises(NotFoundError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 410


async def test_422_raises_connector_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(422, json=_error("CONNECTOR_ERROR", "Upstream failure"))
        )
        client = make_client()
        with pytest.raises(ConnectorError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 422


async def test_429_raises_rate_limit_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(
                429,
                json=_error("RATE_LIMITED", "Too many requests"),
                headers={"Retry-After": "30"},
            )
        )
        client = make_client()
        with pytest.raises(RateLimitError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 429


async def test_429_sets_retry_after():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(
                429,
                json=_error("RATE_LIMITED", "Too many requests"),
                headers={"Retry-After": "45"},
            )
        )
        client = make_client()
        with pytest.raises(RateLimitError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.retry_after == 45


async def test_500_raises_agentmesh_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(500, json=_error("INTERNAL_ERROR", "Server error"))
        )
        client = make_client()
        with pytest.raises(AgentMeshError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.status_code == 500


async def test_validation_error_400():
    with respx.mock:
        respx.post(f"{BASE_URL}/v1/sites/site_123/cart").mock(
            return_value=httpx.Response(400, json=_error("INVALID_INPUT", "Bad request"))
        )
        client = make_client()
        with pytest.raises(ValidationError) as exc_info:
            await client.cart.create("site_123")
        assert exc_info.value.status_code == 400


async def test_network_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            side_effect=httpx.ConnectError("Connection refused")
        )
        client = make_client()
        with pytest.raises(NetworkError):
            await client.products.get_by_id("site_123", "p1")


async def test_timeout_error():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            side_effect=httpx.TimeoutException("Request timed out")
        )
        client = make_client()
        with pytest.raises(TimeoutError):
            await client.products.get_by_id("site_123", "p1")


async def test_error_has_request_id():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/p1").mock(
            return_value=httpx.Response(
                404,
                json=_error("NOT_FOUND", "Not found"),
                headers={"X-AgentMesh-Request-Id": "req_abc123"},
            )
        )
        client = make_client()
        with pytest.raises(NotFoundError) as exc_info:
            await client.products.get_by_id("site_123", "p1")
        assert exc_info.value.request_id == "req_abc123"


def test_parse_error_response_400():
    err = parse_error_response(400, {"error": {"code": "BAD", "message": "bad"}})
    assert isinstance(err, ValidationError)
    assert err.status_code == 400


def test_parse_error_response_401():
    err = parse_error_response(401, {"error": {"code": "UNAUTH", "message": "nope"}})
    assert isinstance(err, AuthenticationError)


def test_parse_error_response_403():
    err = parse_error_response(403, {"error": {"code": "FORBID", "message": "no"}})
    assert isinstance(err, AuthorizationError)


def test_parse_error_response_404():
    err = parse_error_response(404, {"error": {"code": "NF", "message": "gone"}})
    assert isinstance(err, NotFoundError)


def test_parse_error_response_410():
    err = parse_error_response(410, {"error": {"code": "GONE", "message": "gone"}})
    assert isinstance(err, NotFoundError)


def test_parse_error_response_422():
    err = parse_error_response(422, {"error": {"code": "CONN", "message": "upstream"}})
    assert isinstance(err, ConnectorError)


def test_parse_error_response_429_default_retry_after():
    err = parse_error_response(429, {"error": {"code": "RL", "message": "slow down"}})
    assert isinstance(err, RateLimitError)
    assert err.retry_after == 60


def test_parse_error_response_429_custom_retry_after():
    err = parse_error_response(429, {"error": {"code": "RL", "message": "slow down"}}, retry_after=120)
    assert isinstance(err, RateLimitError)
    assert err.retry_after == 120


def test_parse_error_response_500():
    err = parse_error_response(500, {"error": {"code": "ISE", "message": "boom"}})
    assert isinstance(err, AgentMeshError)
    assert not isinstance(err, (ValidationError, AuthenticationError, NotFoundError))
    assert err.status_code == 500


def test_parse_error_response_with_request_id():
    err = parse_error_response(404, {"error": {"code": "NF", "message": "missing"}}, request_id="req_xyz")
    assert err.request_id == "req_xyz"


def test_rate_limit_error_inherits_agentmesh_error():
    err = RateLimitError("slow", "RL", 429, retry_after=30)
    assert isinstance(err, AgentMeshError)
    assert err.retry_after == 30


def test_network_error_has_zero_status():
    err = NetworkError("no connection")
    assert err.status_code == 0
    assert err.code == "NETWORK_ERROR"


def test_timeout_error_has_zero_status():
    err = TimeoutError("timed out")
    assert err.status_code == 0
    assert err.code == "TIMEOUT"
