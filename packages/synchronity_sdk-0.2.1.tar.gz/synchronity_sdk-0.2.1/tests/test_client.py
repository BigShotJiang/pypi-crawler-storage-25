"""Tests for AgentMeshClient initialisation."""
from __future__ import annotations

import pytest
import respx
import httpx

from agentmesh import AgentMeshClient, AgentMeshConfig
from agentmesh.config import DEFAULT_BASE_URL
from agentmesh.http import HttpClient
from tests.conftest import TEST_CONFIG, make_client, BASE_URL


def test_client_init():
    client = make_client()
    assert client.discovery is not None
    assert client.products is not None
    assert client.cart is not None
    assert client.checkout is not None
    assert client.orders is not None


def test_client_default_base_url():
    config = AgentMeshConfig(agent_token="tok")
    assert config.base_url == DEFAULT_BASE_URL


def test_client_config_stored():
    config = AgentMeshConfig(agent_token="tok", timeout=10.0, retries=1)
    assert config.timeout == 10.0
    assert config.retries == 1


async def test_client_as_async_context_manager():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/prod_1").mock(
            return_value=httpx.Response(200, json={
                "product_id": "prod_1",
                "site_id": "site_123",
                "title": "Widget",
                "price": {"amount": "9.99", "currency": "USD"},
                "availability": "in_stock",
                "sku": "W1",
                "categories": [],
                "tags": [],
                "attributes": [],
                "variants": [],
                "images": [],
            })
        )
        async with make_client() as client:
            product = await client.products.get_by_id("site_123", "prod_1")
            assert product.product_id == "prod_1"


def test_client_with_http_client():
    http = HttpClient(TEST_CONFIG, http_client=httpx.AsyncClient())
    client = AgentMeshClient.with_http_client(TEST_CONFIG, http)
    assert client._http is http
    assert client.discovery is not None
    assert client.products is not None
    assert client.cart is not None
    assert client.checkout is not None
    assert client.orders is not None
