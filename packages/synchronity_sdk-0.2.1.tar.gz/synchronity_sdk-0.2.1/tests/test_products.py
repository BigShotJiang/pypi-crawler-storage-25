"""Tests for ProductsModule."""
from __future__ import annotations

import pytest
import respx
import httpx

from tests.conftest import (
    BASE_URL,
    PAGINATION,
    PRODUCT_PAYLOAD,
    make_client,
)


def paginated(products: list) -> dict:
    return {"data": products, "pagination": PAGINATION}


async def test_search_products():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products").mock(
            return_value=httpx.Response(200, json=paginated([PRODUCT_PAYLOAD]))
        )
        client = make_client()
        result = await client.products.search("site_123")
        assert len(result["products"]) == 1
        assert result["products"][0]["product_id"] == "prod_1"


async def test_search_products_with_filters():
    with respx.mock:
        route = respx.get(f"{BASE_URL}/v1/sites/site_123/products").mock(
            return_value=httpx.Response(200, json=paginated([PRODUCT_PAYLOAD]))
        )
        client = make_client()
        await client.products.search(
            "site_123",
            q="widget",
            category="gadgets",
            min_price=5.0,
            max_price=50.0,
            in_stock=True,
            page=1,
            limit=10,
        )
        request = route.calls[0].request
        assert b"q=widget" in request.url.query
        assert b"in_stock=True" in request.url.query
        assert b"min_price=5.0" in request.url.query


async def test_get_product():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/prod_1").mock(
            return_value=httpx.Response(200, json=PRODUCT_PAYLOAD)
        )
        client = make_client()
        product = await client.products.get_by_id("site_123", "prod_1")
        assert product.product_id == "prod_1"
        assert product.title == "Test Widget"
        assert product.price.amount == "19.99"


async def test_compare_products():
    with respx.mock:
        respx.post(f"{BASE_URL}/v1/multi/products/compare").mock(
            return_value=httpx.Response(200, json={
                "results": [
                    {"site_id": "site_123", "products": [PRODUCT_PAYLOAD]},
                ]
            })
        )
        client = make_client()
        result = await client.products.compare(
            site_ids=["site_123"],
            query="widget",
        )
        assert "results" in result
        assert result["results"][0]["site_id"] == "site_123"


async def test_compare_products_with_filters():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/multi/products/compare").mock(
            return_value=httpx.Response(200, json={"results": []})
        )
        client = make_client()
        await client.products.compare(
            site_ids=["site_123", "site_456"],
            query="laptop",
            min_price=100.0,
            max_price=2000.0,
            in_stock=True,
        )
        import json
        body = json.loads(route.calls[0].request.content)
        assert body["query"] == "laptop"
        assert body["site_ids"] == ["site_123", "site_456"]
        assert body["filters"]["min_price"] == 100.0
        assert body["filters"]["in_stock"] is True


async def test_search_returns_pagination():
    big_pagination = {"page": 2, "limit": 5, "total": 42, "has_next": True}
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products").mock(
            return_value=httpx.Response(200, json={"data": [], "pagination": big_pagination})
        )
        client = make_client()
        result = await client.products.search("site_123", page=2, limit=5)
        assert result["total"] == 42
        assert result["page"] == 2
        assert result["total_pages"] == 9  # ceil(42/5)


async def test_get_product_returns_model():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/products/prod_1").mock(
            return_value=httpx.Response(200, json=PRODUCT_PAYLOAD)
        )
        client = make_client()
        from agentmesh.types.amps import AMPSProduct
        product = await client.products.get_by_id("site_123", "prod_1")
        assert isinstance(product, AMPSProduct)
