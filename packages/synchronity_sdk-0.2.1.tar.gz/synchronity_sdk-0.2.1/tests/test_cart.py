"""Tests for CartModule."""
from __future__ import annotations

import json
import pytest
import respx
import httpx

from tests.conftest import BASE_URL, CART_PAYLOAD, make_client


def cart_with_discount() -> dict:
    return {
        **CART_PAYLOAD,
        "discounts": [{"code": "SAVE10", "description": "10% off", "amount": {"amount": "2.00", "currency": "USD"}}],
        "total": {"amount": "17.99", "currency": "USD"},
    }


async def test_create_cart():
    with respx.mock:
        respx.post(f"{BASE_URL}/v1/sites/site_123/cart").mock(
            return_value=httpx.Response(200, json=CART_PAYLOAD)
        )
        client = make_client()
        cart = await client.cart.create("site_123")
        assert cart.cart_id == "cart_abc"
        assert cart.currency == "USD"


async def test_create_cart_with_currency():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/cart").mock(
            return_value=httpx.Response(200, json={**CART_PAYLOAD, "currency": "EUR"})
        )
        client = make_client()
        cart = await client.cart.create("site_123", currency="EUR")
        body = json.loads(route.calls[0].request.content)
        assert body["currency"] == "EUR"
        assert cart.currency == "EUR"


async def test_get_cart():
    with respx.mock:
        respx.get(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc").mock(
            return_value=httpx.Response(200, json=CART_PAYLOAD)
        )
        client = make_client()
        cart = await client.cart.get("site_123", "cart_abc")
        assert cart.cart_id == "cart_abc"
        assert len(cart.items) == 1


async def test_add_item():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc/items").mock(
            return_value=httpx.Response(200, json=CART_PAYLOAD)
        )
        client = make_client()
        cart = await client.cart.add_item("site_123", "cart_abc", "prod_1", 2)
        body = json.loads(route.calls[0].request.content)
        assert body["product_id"] == "prod_1"
        assert body["quantity"] == 2
        assert "variant_id" not in body
        assert cart.cart_id == "cart_abc"


async def test_add_item_with_variant():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc/items").mock(
            return_value=httpx.Response(200, json=CART_PAYLOAD)
        )
        client = make_client()
        await client.cart.add_item("site_123", "cart_abc", "prod_1", 1, variant_id="var_red")
        body = json.loads(route.calls[0].request.content)
        assert body["variant_id"] == "var_red"


async def test_remove_item():
    with respx.mock:
        respx.delete(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc/items/item_1").mock(
            return_value=httpx.Response(200, json={**CART_PAYLOAD, "items": []})
        )
        client = make_client()
        cart = await client.cart.remove_item("site_123", "cart_abc", "item_1")
        assert cart.items == []


async def test_apply_coupon():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc/coupon").mock(
            return_value=httpx.Response(200, json=cart_with_discount())
        )
        client = make_client()
        cart = await client.cart.apply_coupon("site_123", "cart_abc", "SAVE10")
        body = json.loads(route.calls[0].request.content)
        assert body["code"] == "SAVE10"
        assert cart.discounts is not None
        assert cart.discounts[0].code == "SAVE10"


async def test_full_cart_flow():
    with respx.mock:
        respx.post(f"{BASE_URL}/v1/sites/site_123/cart").mock(
            return_value=httpx.Response(200, json=CART_PAYLOAD)
        )
        respx.post(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc/items").mock(
            return_value=httpx.Response(200, json=CART_PAYLOAD)
        )
        respx.post(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc/coupon").mock(
            return_value=httpx.Response(200, json=cart_with_discount())
        )
        respx.get(f"{BASE_URL}/v1/sites/site_123/cart/cart_abc").mock(
            return_value=httpx.Response(200, json=cart_with_discount())
        )

        client = make_client()
        cart = await client.cart.create("site_123")
        assert cart.cart_id == "cart_abc"

        cart = await client.cart.add_item("site_123", cart.cart_id, "prod_1", 1)
        assert len(cart.items) == 1

        cart = await client.cart.apply_coupon("site_123", cart.cart_id, "SAVE10")
        assert cart.discounts is not None

        cart = await client.cart.get("site_123", cart.cart_id)
        assert cart.total.amount == "17.99"
