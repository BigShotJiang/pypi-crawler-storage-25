"""Tests for CheckoutModule."""
from __future__ import annotations

import json
import pytest
import respx
import httpx

from agentmesh.modules.checkout import ShippingAddressParams
from tests.conftest import BASE_URL, ORDER_PAYLOAD, make_client


SHIPPING = ShippingAddressParams(
    name="Jane Smith",
    line1="123 Main St",
    city="San Francisco",
    state="CA",
    postal_code="94102",
    country="US",
)


async def test_execute_checkout():
    with respx.mock:
        respx.post(f"{BASE_URL}/v1/sites/site_123/checkout").mock(
            return_value=httpx.Response(200, json=ORDER_PAYLOAD)
        )
        client = make_client()
        order = await client.checkout.execute(
            site_id="site_123",
            cart_id="cart_abc",
            buyer_delegation_token="buyer-tok",
            shipping_address=SHIPPING,
        )
        assert order.order_id == "order_001"
        assert order.status.value == "completed"


async def test_checkout_maps_shipping_address():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/checkout").mock(
            return_value=httpx.Response(200, json=ORDER_PAYLOAD)
        )
        client = make_client()
        await client.checkout.execute(
            site_id="site_123",
            cart_id="cart_abc",
            buyer_delegation_token="buyer-tok",
            shipping_address=SHIPPING,
        )
        body = json.loads(route.calls[0].request.content)
        addr = body["shipping_address"]
        # SDK maps `country` -> `country_code` for the AMPS API
        assert addr["country_code"] == "US"
        assert addr["name"] == "Jane Smith"
        assert addr["line1"] == "123 Main St"
        assert addr["city"] == "San Francisco"
        assert addr["state"] == "CA"
        assert addr["postal_code"] == "94102"
        assert "line2" not in addr


async def test_checkout_with_optional_line2():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/checkout").mock(
            return_value=httpx.Response(200, json=ORDER_PAYLOAD)
        )
        client = make_client()
        shipping_with_line2 = ShippingAddressParams(
            name="Bob Jones",
            line1="456 Oak Ave",
            line2="Apt 7B",
            city="New York",
            state="NY",
            postal_code="10001",
            country="US",
        )
        await client.checkout.execute(
            site_id="site_123",
            cart_id="cart_abc",
            buyer_delegation_token="buyer-tok",
            shipping_address=shipping_with_line2,
        )
        body = json.loads(route.calls[0].request.content)
        assert body["shipping_address"]["line2"] == "Apt 7B"


async def test_checkout_sends_correct_body():
    with respx.mock:
        route = respx.post(f"{BASE_URL}/v1/sites/site_123/checkout").mock(
            return_value=httpx.Response(200, json=ORDER_PAYLOAD)
        )
        client = make_client()
        await client.checkout.execute(
            site_id="site_123",
            cart_id="cart_xyz",
            buyer_delegation_token="my-token",
            shipping_address=SHIPPING,
        )
        body = json.loads(route.calls[0].request.content)
        assert body["cart_id"] == "cart_xyz"
        assert body["buyer_delegation_token"] == "my-token"
