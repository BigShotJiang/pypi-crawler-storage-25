from __future__ import annotations

from typing import Any

from .config import AgentMeshConfig
from .http import HttpClient
from .modules.cart import CartModule
from .modules.checkout import CheckoutModule
from .modules.discovery import DiscoveryModule
from .modules.orders import OrdersModule
from .modules.products import ProductsModule


class AgentMeshClient:
    def __init__(self, config: AgentMeshConfig) -> None:
        self._http = HttpClient(config)
        self.discovery = DiscoveryModule(self._http)
        self.products = ProductsModule(self._http)
        self.cart = CartModule(self._http)
        self.checkout = CheckoutModule(self._http)
        self.orders = OrdersModule(self._http)

    async def __aenter__(self) -> "AgentMeshClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self._http.close()

    async def close(self) -> None:
        await self._http.close()

    @classmethod
    def with_http_client(
        cls, config: AgentMeshConfig, http_client: HttpClient
    ) -> "AgentMeshClient":
        """Inject a pre-built HttpClient — useful for testing."""
        instance = cls.__new__(cls)
        instance._http = http_client
        instance.discovery = DiscoveryModule(http_client)
        instance.products = ProductsModule(http_client)
        instance.cart = CartModule(http_client)
        instance.checkout = CheckoutModule(http_client)
        instance.orders = OrdersModule(http_client)
        return instance
