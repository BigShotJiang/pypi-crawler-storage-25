from __future__ import annotations
from typing import List

from ._defs import _TOOL_DEFS

anthropic_tools: List[dict] = [
    {
        "name": t["name"],
        "description": t["description"],
        "input_schema": t["parameters"],
    }
    for t in _TOOL_DEFS
]
