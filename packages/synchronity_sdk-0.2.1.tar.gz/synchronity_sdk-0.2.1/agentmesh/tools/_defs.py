from __future__ import annotations

# Canonical tool definitions shared across all LLM framework adapters.
_TOOL_DEFS = [
    {
        "name": "search_products",
        "description": (
            "Search for products on a registered AgentMesh site. "
            "Returns a paginated list of matching products with prices, availability, and variants."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID to search."},
                "query": {"type": "string", "description": 'Full-text search query, e.g. "laptop" or "red sneakers size 10".'},
                "category": {"type": "string", "description": "Filter by product category slug."},
                "min_price": {"type": "number", "description": "Minimum price filter in the site's default currency."},
                "max_price": {"type": "number", "description": "Maximum price filter in the site's default currency."},
                "in_stock": {"type": "boolean", "description": "When true, only return in-stock products."},
                "page": {"type": "integer", "description": "Page number (1-based). Defaults to 1."},
                "limit": {"type": "integer", "description": "Number of results per page (max 100). Defaults to 20."},
            },
            "required": ["site_id"],
        },
    },
    {
        "name": "get_product",
        "description": (
            "Get full details for a specific product by its ID, "
            "including all variants, images, attributes, and pricing."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "product_id": {"type": "string", "description": "The unique product ID."},
            },
            "required": ["site_id", "product_id"],
        },
    },
    {
        "name": "compare_products",
        "description": (
            "Compare products matching a query across one or more AgentMesh sites. "
            "Useful for finding the best price or availability across multiple stores."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "site_ids": {
                    "type": "array",
                    "description": "List of AgentMesh site IDs to compare across.",
                    "items": {"type": "string"},
                },
                "query": {"type": "string", "description": "The product search query to compare across sites."},
                "min_price": {"type": "number", "description": "Minimum price filter."},
                "max_price": {"type": "number", "description": "Maximum price filter."},
                "in_stock": {"type": "boolean", "description": "Only include in-stock results."},
            },
            "required": ["site_ids", "query"],
        },
    },
    {
        "name": "create_cart",
        "description": (
            "Create a new shopping cart on a site. "
            "Returns a cart_id that must be used in subsequent cart operations."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "currency": {"type": "string", "description": 'ISO 4217 currency code (e.g. "USD", "EUR"). Defaults to the site\'s primary currency.'},
            },
            "required": ["site_id"],
        },
    },
    {
        "name": "add_to_cart",
        "description": "Add a product (and optionally a specific variant) to an existing cart.",
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "cart_id": {"type": "string", "description": "The cart ID returned by create_cart."},
                "product_id": {"type": "string", "description": "The product ID to add."},
                "quantity": {"type": "integer", "description": "Number of units to add."},
                "variant_id": {"type": "string", "description": "Optional variant ID (e.g. for a specific size/color)."},
            },
            "required": ["site_id", "cart_id", "product_id", "quantity"],
        },
    },
    {
        "name": "remove_from_cart",
        "description": "Remove a specific line item from the cart by its item_id.",
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "cart_id": {"type": "string", "description": "The cart ID."},
                "item_id": {"type": "string", "description": "The item_id of the cart line item to remove (from cart.items[].item_id)."},
            },
            "required": ["site_id", "cart_id", "item_id"],
        },
    },
    {
        "name": "apply_coupon",
        "description": "Apply a discount coupon code to a cart. Returns the updated cart with the discount reflected.",
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "cart_id": {"type": "string", "description": "The cart ID."},
                "code": {"type": "string", "description": "The coupon/promo code string."},
            },
            "required": ["site_id", "cart_id", "code"],
        },
    },
    {
        "name": "get_cart",
        "description": "Retrieve the current contents of a cart, including items, subtotal, discounts, and total.",
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "cart_id": {"type": "string", "description": "The cart ID."},
            },
            "required": ["site_id", "cart_id"],
        },
    },
    {
        "name": "execute_checkout",
        "description": (
            "Execute checkout for a cart. Requires a buyer delegation token "
            "(obtained via the AgentMesh auth flow), shipping address, and payment method. "
            "Returns a confirmed order."
        ),
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "cart_id": {"type": "string", "description": "The cart ID to check out."},
                "buyer_delegation_token": {"type": "string", "description": "The buyer's delegation token from the AgentMesh auth flow."},
                "shipping_name": {"type": "string", "description": "Full name of the shipping recipient."},
                "shipping_line1": {"type": "string", "description": "Shipping address line 1."},
                "shipping_line2": {"type": "string", "description": "Shipping address line 2 (optional)."},
                "shipping_city": {"type": "string", "description": "Shipping city."},
                "shipping_state": {"type": "string", "description": "Shipping state or province."},
                "shipping_postal_code": {"type": "string", "description": "Shipping postal/ZIP code."},
                "shipping_country": {"type": "string", "description": 'ISO 3166-1 alpha-2 country code for the shipping address (e.g. "US", "GB").'},
            },
            "required": [
                "site_id",
                "cart_id",
                "buyer_delegation_token",
                "shipping_name",
                "shipping_line1",
                "shipping_city",
                "shipping_state",
                "shipping_postal_code",
                "shipping_country",
            ],
        },
    },
    {
        "name": "get_order",
        "description": "Get the details of a specific order by its order ID, including items, status, and tracking info.",
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "order_id": {"type": "string", "description": "The unique order ID."},
            },
            "required": ["site_id", "order_id"],
        },
    },
    {
        "name": "list_orders",
        "description": "List recent orders, optionally filtered by status.",
        "parameters": {
            "type": "object",
            "properties": {
                "site_id": {"type": "string", "description": "The AgentMesh site ID."},
                "status": {
                    "type": "string",
                    "description": "Filter by order status.",
                    "enum": ["pending", "processing", "completed", "cancelled", "refunded"],
                },
                "page": {"type": "integer", "description": "Page number (1-based)."},
                "limit": {"type": "integer", "description": "Number of results per page (max 100)."},
            },
            "required": ["site_id"],
        },
    },
]
