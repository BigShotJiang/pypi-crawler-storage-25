from __future__ import annotations

from typing import TYPE_CHECKING, Any

if TYPE_CHECKING:
    from ..client import AgentMeshClient

from ..modules.checkout import ShippingAddressParams


class ToolExecutor:
    def __init__(self, client: "AgentMeshClient") -> None:
        self._client = client

    async def execute(self, name: str, args: dict) -> Any:
        if name == "search_products":
            return await self._client.products.search(
                site_id=args["site_id"],
                q=args.get("query"),
                category=args.get("category"),
                min_price=args.get("min_price"),
                max_price=args.get("max_price"),
                in_stock=args.get("in_stock"),
                page=args.get("page"),
                limit=args.get("limit"),
            )
        elif name == "get_product":
            product = await self._client.products.get_by_id(
                site_id=args["site_id"],
                product_id=args["product_id"],
            )
            return product.model_dump()
        elif name == "compare_products":
            return await self._client.products.compare(
                site_ids=args["site_ids"],
                query=args["query"],
                min_price=args.get("min_price"),
                max_price=args.get("max_price"),
                in_stock=args.get("in_stock"),
            )
        elif name == "create_cart":
            cart = await self._client.cart.create(
                site_id=args["site_id"],
                currency=args.get("currency"),
            )
            return cart.model_dump()
        elif name == "add_to_cart":
            cart = await self._client.cart.add_item(
                site_id=args["site_id"],
                cart_id=args["cart_id"],
                product_id=args["product_id"],
                quantity=args["quantity"],
                variant_id=args.get("variant_id"),
            )
            return cart.model_dump()
        elif name == "remove_from_cart":
            cart = await self._client.cart.remove_item(
                site_id=args["site_id"],
                cart_id=args["cart_id"],
                item_id=args["item_id"],
            )
            return cart.model_dump()
        elif name == "apply_coupon":
            cart = await self._client.cart.apply_coupon(
                site_id=args["site_id"],
                cart_id=args["cart_id"],
                code=args["code"],
            )
            return cart.model_dump()
        elif name == "get_cart":
            cart = await self._client.cart.get(
                site_id=args["site_id"],
                cart_id=args["cart_id"],
            )
            return cart.model_dump()
        elif name == "execute_checkout":
            shipping = ShippingAddressParams(
                name=args["shipping_name"],
                line1=args["shipping_line1"],
                line2=args.get("shipping_line2"),
                city=args["shipping_city"],
                state=args["shipping_state"],
                postal_code=args["shipping_postal_code"],
                country=args["shipping_country"],
            )
            order = await self._client.checkout.execute(
                site_id=args["site_id"],
                cart_id=args["cart_id"],
                buyer_delegation_token=args["buyer_delegation_token"],
                shipping_address=shipping,
            )
            return order.model_dump()
        elif name == "get_order":
            order = await self._client.orders.get(
                site_id=args["site_id"],
                order_id=args["order_id"],
            )
            return order.model_dump()
        elif name == "list_orders":
            return await self._client.orders.list(
                site_id=args["site_id"],
                status=args.get("status"),
                page=args.get("page"),
                limit=args.get("limit"),
            )
        else:
            raise ValueError(f"Unknown tool: {name!r}")
