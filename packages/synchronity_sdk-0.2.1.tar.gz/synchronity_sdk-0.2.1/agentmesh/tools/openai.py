from __future__ import annotations
from typing import List

from ._defs import _TOOL_DEFS

openai_tools: List[dict] = [
    {
        "type": "function",
        "function": {
            "name": t["name"],
            "description": t["description"],
            "parameters": t["parameters"],
        },
    }
    for t in _TOOL_DEFS
]
