from __future__ import annotations

from enum import Enum
from typing import Any, Dict, List, Optional, Union

from pydantic import BaseModel, ConfigDict, Field


class MonetaryAmount(BaseModel):
    amount: str  # decimal string e.g. "19.99"
    currency: str  # ISO 4217


class AvailabilityStatus(str, Enum):
    IN_STOCK = "in_stock"
    OUT_OF_STOCK = "out_of_stock"
    BACKORDER = "backorder"


class AMPSProductAttribute(BaseModel):
    name: str
    value: str


class AMPSProductImage(BaseModel):
    url: str
    alt: Optional[str] = None


class AMPSProductVariant(BaseModel):
    variant_id: str
    title: str
    sku: Optional[str] = None
    price: MonetaryAmount
    compare_at_price: Optional[MonetaryAmount] = None
    availability: AvailabilityStatus
    stock_quantity: Optional[int] = None
    attributes: Optional[List[AMPSProductAttribute]] = None
    image_url: Optional[str] = None


class AMPSProduct(BaseModel):
    product_id: str
    site_id: str
    title: str
    description: Optional[str] = None
    price: MonetaryAmount
    compare_at_price: Optional[MonetaryAmount] = None
    availability: AvailabilityStatus
    stock_quantity: Optional[int] = None
    sku: str
    categories: List[str]
    tags: List[str]
    attributes: List[AMPSProductAttribute]
    variants: List[AMPSProductVariant]
    image_url: Optional[str] = None
    images: List[AMPSProductImage]
    url: Optional[str] = None
    metadata: Optional[Dict[str, Any]] = None


class AMPSDiscount(BaseModel):
    code: str
    description: Optional[str] = None
    amount: MonetaryAmount


class AMPSCartItem(BaseModel):
    item_id: str
    product_id: str
    variant_id: Optional[str] = None
    title: str
    quantity: int
    unit_price: MonetaryAmount
    line_total: MonetaryAmount


class AMPSCart(BaseModel):
    cart_id: str
    site_id: str
    items: List[AMPSCartItem]
    subtotal: MonetaryAmount
    discounts: Optional[List[AMPSDiscount]] = None
    total: MonetaryAmount
    currency: str
    expires_at: str


class AMPSOrderStatus(str, Enum):
    PENDING = "pending"
    PROCESSING = "processing"
    COMPLETED = "completed"
    CANCELLED = "cancelled"
    REFUNDED = "refunded"


class AMPSAddress(BaseModel):
    line1: str
    line2: Optional[str] = None
    city: str
    state: Optional[str] = None
    postal_code: Optional[str] = None
    country_code: str  # ISO 3166-1 alpha-2


class AMPSOrderItem(BaseModel):
    item_id: str
    product_id: str
    variant_id: Optional[str] = None
    title: str
    quantity: int
    unit_price: MonetaryAmount
    line_total: MonetaryAmount


class AMPSOrder(BaseModel):
    order_id: str
    site_id: str
    status: AMPSOrderStatus
    items: List[AMPSOrderItem]
    subtotal: MonetaryAmount
    discounts: Optional[List[AMPSDiscount]] = None
    total: MonetaryAmount
    currency: str
    shipping_address: Optional[AMPSAddress] = None
    tracking_number: Optional[str] = None
    estimated_delivery: Optional[str] = None
    created_at: str
    updated_at: Optional[str] = None


class AMPSPlatform(str, Enum):
    WOOCOMMERCE = "woocommerce"
    SHOPIFY = "shopify"
    MAGENTO = "magento"
    BIGCOMMERCE = "bigcommerce"
    CUSTOM = "custom"


class AMPSCapabilities(BaseModel):
    model_config = ConfigDict(extra="allow")

    # Capability flag names as stored by TypeScript connectors
    product_search: Optional[bool] = None
    product_compare: Optional[bool] = None
    cart_management: Optional[bool] = None
    coupon_support: Optional[bool] = None
    checkout_execution: Optional[bool] = None
    order_tracking: Optional[bool] = None
    real_time_inventory: Optional[bool] = None
    guest_checkout: Optional[bool] = None
    authenticated_checkout: Optional[bool] = None

    # Scope-based keys stored by WooCommerce and other connectors
    read_products: Optional[bool] = None
    manage_cart: Optional[bool] = None
    execute_checkout: Optional[bool] = None
    read_orders: Optional[bool] = None

    def supports(self, capability: str) -> bool:
        """Check if a capability flag is truthy (works for both naming conventions)."""
        val = getattr(self, capability, None)
        if val is None:
            val = (self.model_extra or {}).get(capability)
        return bool(val)


class AMPSShippingZone(BaseModel):
    country_code: str  # ISO 3166-1 alpha-2
    regions: Optional[List[str]] = None


class AMPSRateLimits(BaseModel):
    requests_per_minute: int
    requests_per_day: int


class AMPSCapabilityManifest(BaseModel):
    site_id: str
    platform: AMPSPlatform
    platform_version: str
    agentmesh_version: str
    capabilities: AMPSCapabilities
    api_base_url: str
    supported_currencies: List[str]
    shipping_zones: List[AMPSShippingZone]


class SiteListItem(BaseModel):
    site_id: str
    name: str
    platform: AMPSPlatform
    api_base_url: str
    description: Optional[str] = None
    capabilities: Optional[AMPSCapabilities] = None


class AgentScope(str, Enum):
    READ_PRODUCTS = "read_products"
    MANAGE_CART = "manage_cart"
    EXECUTE_CHECKOUT = "execute_checkout"
    READ_ORDERS = "read_orders"


class PaginationMeta(BaseModel):
    page: int
    limit: int
    total: int
    has_next: bool


class PaginatedProductResponse(BaseModel):
    data: List[AMPSProduct]
    pagination: PaginationMeta


class PaginatedOrderResponse(BaseModel):
    data: List[AMPSOrder]
    pagination: PaginationMeta


class PaginatedSiteResponse(BaseModel):
    data: List[SiteListItem]
    pagination: PaginationMeta


class AMPSError(BaseModel):
    code: str
    message: str
    details: Optional[Dict[str, Any]] = None


class AMPSErrorResponse(BaseModel):
    error: AMPSError
