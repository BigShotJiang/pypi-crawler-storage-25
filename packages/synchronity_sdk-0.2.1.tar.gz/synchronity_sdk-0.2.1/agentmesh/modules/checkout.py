from __future__ import annotations
from typing import Optional, Union

from dataclasses import dataclass

from ..http import HttpClient
from ..types.amps import AMPSOrder


@dataclass
class ShippingAddressParams:
    name: str
    line1: str
    city: str
    state: str
    postal_code: str
    country: str
    line2: Optional[str] = None


class CheckoutModule:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def execute(
        self,
        site_id: str,
        cart_id: str,
        buyer_delegation_token: str,
        shipping_address: ShippingAddressParams,
    ) -> AMPSOrder:
        address: dict = {
            "name": shipping_address.name,
            "line1": shipping_address.line1,
            "city": shipping_address.city,
            "state": shipping_address.state,
            "postal_code": shipping_address.postal_code,
            "country_code": shipping_address.country,
        }
        if shipping_address.line2 is not None:
            address["line2"] = shipping_address.line2

        body = {
            "cart_id": cart_id,
            "buyer_delegation_token": buyer_delegation_token,
            "shipping_address": address,
        }
        raw = await self._http.post(f"/v1/sites/{site_id}/checkout", body)
        return AMPSOrder.model_validate(raw)
