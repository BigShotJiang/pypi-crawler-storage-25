from __future__ import annotations
from typing import Optional, Union

from ..http import HttpClient
from ..types.amps import AMPSCart


class CartModule:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def create(self, site_id: str, currency: Optional[str] = None) -> AMPSCart:
        body: dict = {}
        if currency is not None:
            body["currency"] = currency
        raw = await self._http.post(f"/v1/sites/{site_id}/cart", body)
        return AMPSCart.model_validate(raw)

    async def get(self, site_id: str, cart_id: str) -> AMPSCart:
        raw = await self._http.get(f"/v1/sites/{site_id}/cart/{cart_id}")
        return AMPSCart.model_validate(raw)

    async def add_item(
        self,
        site_id: str,
        cart_id: str,
        product_id: str,
        quantity: int,
        variant_id: Optional[str] = None,
    ) -> AMPSCart:
        body: dict = {"product_id": product_id, "quantity": quantity}
        if variant_id is not None:
            body["variant_id"] = variant_id
        raw = await self._http.post(f"/v1/sites/{site_id}/cart/{cart_id}/items", body)
        return AMPSCart.model_validate(raw)

    async def remove_item(
        self, site_id: str, cart_id: str, item_id: str
    ) -> AMPSCart:
        raw = await self._http.delete(
            f"/v1/sites/{site_id}/cart/{cart_id}/items/{item_id}"
        )
        return AMPSCart.model_validate(raw)

    async def apply_coupon(
        self, site_id: str, cart_id: str, code: str
    ) -> AMPSCart:
        raw = await self._http.post(
            f"/v1/sites/{site_id}/cart/{cart_id}/coupon", {"code": code}
        )
        return AMPSCart.model_validate(raw)
