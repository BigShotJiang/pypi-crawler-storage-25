from __future__ import annotations
from typing import Optional, Union, List

from ..http import HttpClient
from ..types.amps import AMPSCapabilityManifest, PaginatedSiteResponse


class DiscoveryModule:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def list_sites(
        self,
        category: Optional[str] = None,
        ships_to: Optional[str] = None,
        capabilities: Optional[List[str]] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> dict:
        params: dict = {}
        if category is not None:
            params["category"] = category
        if ships_to is not None:
            params["ships_to"] = ships_to
        if capabilities is not None:
            params["capabilities"] = capabilities
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        raw = await self._http.get("/v1/sites", params or None)
        response = PaginatedSiteResponse.model_validate(raw)
        return {
            "sites": [s.model_dump() for s in response.data],
            "total": response.pagination.total,
            "page": response.pagination.page,
        }

    async def get_manifest(self, site_id: str) -> AMPSCapabilityManifest:
        raw = await self._http.get(f"/v1/sites/{site_id}/manifest")
        return AMPSCapabilityManifest.model_validate(raw)
