from __future__ import annotations
from typing import Optional, Union

from ..http import HttpClient
from ..types.amps import AMPSOrder, AMPSOrderStatus, PaginatedOrderResponse


class OrdersModule:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def get(self, site_id: str, order_id: str) -> AMPSOrder:
        raw = await self._http.get(f"/v1/sites/{site_id}/orders/{order_id}")
        return AMPSOrder.model_validate(raw)

    async def list(
        self,
        site_id: str,
        page: Optional[int] = None,
        limit: Optional[int] = None,
        status: AMPSOrderStatus | Optional[str] = None,
    ) -> dict:
        params: dict = {}
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit
        if status is not None:
            params["status"] = str(status.value if isinstance(status, AMPSOrderStatus) else status)

        raw = await self._http.get(f"/v1/sites/{site_id}/orders", params or None)
        response = PaginatedOrderResponse.model_validate(raw)
        return {
            "orders": [o.model_dump() for o in response.data],
            "total": response.pagination.total,
        }
