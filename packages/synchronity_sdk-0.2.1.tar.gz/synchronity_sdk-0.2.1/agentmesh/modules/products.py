from __future__ import annotations
from typing import Optional, Union, List

from ..http import HttpClient
from ..types.amps import AMPSProduct, PaginatedProductResponse


class ProductsModule:
    def __init__(self, http: HttpClient) -> None:
        self._http = http

    async def search(
        self,
        site_id: str,
        q: Optional[str] = None,
        category: Optional[str] = None,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        in_stock: Optional[bool] = None,
        page: Optional[int] = None,
        limit: Optional[int] = None,
    ) -> dict:
        params: dict = {}
        if q is not None:
            params["q"] = q
        if category is not None:
            params["category"] = category
        if min_price is not None:
            params["min_price"] = min_price
        if max_price is not None:
            params["max_price"] = max_price
        if in_stock is not None:
            params["in_stock"] = in_stock
        if page is not None:
            params["page"] = page
        if limit is not None:
            params["limit"] = limit

        raw = await self._http.get(f"/v1/sites/{site_id}/products", params or None)
        response = PaginatedProductResponse.model_validate(raw)
        pg = response.pagination
        total_pages = (pg.total + pg.limit - 1) // pg.limit if pg.limit > 0 else 1
        return {
            "products": [p.model_dump() for p in response.data],
            "total": pg.total,
            "page": pg.page,
            "total_pages": total_pages,
        }

    async def get_by_id(self, site_id: str, product_id: str) -> AMPSProduct:
        raw = await self._http.get(f"/v1/sites/{site_id}/products/{product_id}")
        return AMPSProduct.model_validate(raw)

    async def compare(
        self,
        site_ids: List[str],
        query: str,
        min_price: Optional[float] = None,
        max_price: Optional[float] = None,
        in_stock: Optional[bool] = None,
    ) -> dict:
        body: dict = {"query": query, "site_ids": site_ids}
        filters: dict = {}
        if min_price is not None:
            filters["min_price"] = min_price
        if max_price is not None:
            filters["max_price"] = max_price
        if in_stock is not None:
            filters["in_stock"] = in_stock
        if filters:
            body["filters"] = filters

        return await self._http.post("/v1/multi/products/compare", body)
