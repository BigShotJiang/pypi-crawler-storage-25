from __future__ import annotations
from typing import Optional, Union


class AgentMeshError(Exception):
    def __init__(
        self,
        message: str,
        code: str,
        status_code: int,
        request_id: Optional[str] = None,
    ) -> None:
        super().__init__(message)
        self.code = code
        self.status_code = status_code
        self.request_id = request_id


class AuthenticationError(AgentMeshError):
    """Raised on HTTP 401 responses."""


class AuthorizationError(AgentMeshError):
    """Raised on HTTP 403 responses."""


class NotFoundError(AgentMeshError):
    """Raised on HTTP 404 / 410 responses."""


class ValidationError(AgentMeshError):
    """Raised on HTTP 400 responses."""


class RateLimitError(AgentMeshError):
    """Raised on HTTP 429 responses."""

    def __init__(
        self,
        message: str,
        code: str,
        status_code: int,
        request_id: Optional[str] = None,
        retry_after: int = 60,
    ) -> None:
        super().__init__(message, code, status_code, request_id)
        self.retry_after = retry_after


class ConnectorError(AgentMeshError):
    """Raised on HTTP 422 responses (upstream connector failure)."""


class NetworkError(AgentMeshError):
    """Raised on network-level failures (connection errors, etc.)."""

    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "NETWORK_ERROR", 0, request_id)


class TimeoutError(AgentMeshError):
    """Raised when a request times out."""

    def __init__(self, message: str, request_id: Optional[str] = None) -> None:
        super().__init__(message, "TIMEOUT", 0, request_id)


def parse_error_response(
    status: int,
    body: dict,
    request_id: Optional[str] = None,
    retry_after: Optional[int] = None,
) -> AgentMeshError:
    error = body.get("error", {})
    code = error.get("code", "UNKNOWN_ERROR")
    message = error.get("message", f"HTTP {status}")

    if status == 400:
        return ValidationError(message, code, status, request_id)
    elif status == 401:
        return AuthenticationError(message, code, status, request_id)
    elif status == 403:
        return AuthorizationError(message, code, status, request_id)
    elif status in (404, 410):
        return NotFoundError(message, code, status, request_id)
    elif status == 422:
        return ConnectorError(message, code, status, request_id)
    elif status == 429:
        return RateLimitError(
            message,
            code,
            status,
            request_id,
            retry_after=retry_after if retry_after is not None else 60,
        )
    else:
        return AgentMeshError(message, code, status, request_id)
