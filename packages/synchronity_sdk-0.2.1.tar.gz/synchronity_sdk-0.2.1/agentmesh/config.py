from __future__ import annotations

from dataclasses import dataclass, field

SDK_VERSION = "0.1.0"
DEFAULT_BASE_URL = "https://gateway.agentmesh.ai"
DEFAULT_TIMEOUT = 30.0
DEFAULT_RETRIES = 3
DEFAULT_RETRY_DELAY = 1.0


@dataclass
class AgentMeshConfig:
    agent_token: str
    base_url: str = DEFAULT_BASE_URL
    timeout: float = DEFAULT_TIMEOUT
    retries: int = DEFAULT_RETRIES
    retry_delay: float = DEFAULT_RETRY_DELAY
