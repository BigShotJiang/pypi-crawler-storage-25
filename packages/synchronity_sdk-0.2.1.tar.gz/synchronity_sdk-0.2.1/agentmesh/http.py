from __future__ import annotations

import asyncio
from typing import Any, Dict, Optional, Union

import httpx

from .config import AgentMeshConfig, SDK_VERSION
from .errors import (
    AgentMeshError,
    NetworkError,
    TimeoutError,
    parse_error_response,
)


class HttpClient:
    def __init__(
        self,
        config: AgentMeshConfig,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        self._config = config
        self._base_url = config.base_url.rstrip("/")
        self._headers = {
            "Authorization": f"Bearer {config.agent_token}",
            "User-Agent": f"agentmesh-python/{SDK_VERSION}",
            "Accept": "application/json",
        }
        self._owned = http_client is None
        self._client = http_client or httpx.AsyncClient(
            timeout=config.timeout,
        )

    async def __aenter__(self) -> "HttpClient":
        return self

    async def __aexit__(self, *args: Any) -> None:
        await self.close()

    async def close(self) -> None:
        if self._owned:
            await self._client.aclose()

    async def get(self, path: str, params: Optional[Dict[str, Any]] = None) -> dict:
        return await self._request("GET", path, params=params)

    async def post(self, path: str, body: Optional[dict] = None) -> dict:
        return await self._request("POST", path, body=body)

    async def delete(self, path: str) -> dict:
        return await self._request("DELETE", path)

    def _build_url(self, path: str) -> str:
        return f"{self._base_url}{path}"

    def _clean_params(
        self, params: Optional[Dict[str, Any]]
    ) -> Optional[Dict[str, str]]:
        if not params:
            return None
        result: Dict[str, str] = {}
        for k, v in params.items():
            if v is None:
                continue
            if isinstance(v, list):
                result[k] = ",".join(str(i) for i in v)
            else:
                result[k] = str(v)
        return result or None

    async def _request(
        self,
        method: str,
        path: str,
        params: Optional[Dict[str, Any]] = None,
        body: Optional[dict] = None,
        attempt: int = 0,
    ) -> dict:
        url = self._build_url(path)
        cleaned_params = self._clean_params(params)

        headers = dict(self._headers)
        if body is not None:
            headers["Content-Type"] = "application/json"

        try:
            response = await self._client.request(
                method,
                url,
                params=cleaned_params,
                json=body,
                headers=headers,
            )
        except httpx.TimeoutException as exc:
            raise TimeoutError(f"Request timed out: {method} {path}") from exc
        except httpx.RequestError as exc:
            raise NetworkError(f"Network error: {method} {path}: {exc}") from exc

        request_id = response.headers.get("X-AgentMesh-Request-Id")

        if response.is_success:
            if response.status_code == 204:
                return {}
            return response.json()

        # Parse retry-after header for 429
        retry_after: Optional[int] = None
        raw_retry = response.headers.get("Retry-After")
        if raw_retry is not None:
            try:
                retry_after = int(raw_retry)
            except ValueError:
                retry_after = 60

        # Retry on 429 and 5xx
        should_retry = attempt < self._config.retries and (
            response.status_code == 429 or response.status_code >= 500
        )

        if should_retry:
            if response.status_code == 429 and retry_after is not None:
                delay = float(retry_after)
            else:
                delay = self._config.retry_delay * (2**attempt)
            await asyncio.sleep(delay)
            return await self._request(method, path, params=params, body=body, attempt=attempt + 1)

        try:
            error_body = response.json()
        except Exception:
            error_body = {
                "error": {
                    "code": "UNKNOWN_ERROR",
                    "message": f"HTTP {response.status_code}: {response.text}",
                }
            }

        raise parse_error_response(response.status_code, error_body, request_id, retry_after)
