from __future__ import annotations

from pathlib import Path

DEFAULT_MANIFEST_FILE = Path(".ai-opencodex.json")
LEGACY_MANIFEST_FILE = Path(".ai-codex.json")
INSTRUCTION_FILE = Path(".ai-opencodex.md")
LEGACY_INSTRUCTION_FILE = Path(".ai-codex.md")
SCHEMA_URL = "https://svange.github.io/augint-opencodex/ai-opencodex.schema.json"

MANAGED_FILE_PATHS = (
    Path(".codex/config.toml"),
    INSTRUCTION_FILE,
    Path("opencode.json"),
    Path("tui.json"),
    Path(".pi/settings.json"),
    Path(".pi/skills/augint-workflow/SKILL.md"),
    Path(".agents/skills/README.md"),
    Path(".agents/skills/org-python-tooling/SKILL.md"),
    LEGACY_INSTRUCTION_FILE,
)
