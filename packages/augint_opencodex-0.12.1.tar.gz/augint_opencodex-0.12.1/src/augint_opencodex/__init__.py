"""augint-opencodex package."""

__version__ = "0.12.1"
