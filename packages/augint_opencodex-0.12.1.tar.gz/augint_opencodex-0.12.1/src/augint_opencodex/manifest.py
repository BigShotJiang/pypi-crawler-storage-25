from __future__ import annotations

import json
from pathlib import Path
from typing import Literal

from pydantic import BaseModel, ConfigDict, Field, ValidationError


class ManifestError(ValueError):
    """Raised when `.ai-opencodex.json` cannot be loaded or validated."""


class ContentPolicy(BaseModel):
    """Output-style constraints applied by the generated profile."""

    model_config = ConfigDict(extra="forbid")

    no_emojis: bool = True
    no_ai_mentions: bool = True


class ShellGuardrails(BaseModel):
    """Shell command patterns that should prompt or be denied."""

    model_config = ConfigDict(extra="forbid")

    ask: list[str] = Field(default_factory=list)
    deny: list[str] = Field(default_factory=list)


class PatternFlags(BaseModel):
    """Named organizational patterns that can influence generated output."""

    model_config = ConfigDict(extra="forbid")

    org_python_library: bool = False


class LocalProvider(BaseModel):
    """OpenAI-compatible local provider (e.g. Ollama) for OpenCode."""

    model_config = ConfigDict(extra="forbid")

    kind: Literal["openai-compatible"] = "openai-compatible"
    name: str = "ollama"
    base_url: str = "http://host.docker.internal:11434/v1"


class ModelEntry(BaseModel):
    """Curated model catalog entry for an OpenCode provider."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str | None = None


class BedrockConfig(BaseModel):
    """Amazon Bedrock provider toggle and model list for OpenCode."""

    model_config = ConfigDict(extra="forbid")

    enabled: bool = False
    models: list[str] = Field(default_factory=list)


OpenCodeExtra = Literal[
    "serve",
    "lsp_pyright",
    "formatter_off",
    "plugin_snip",
    "plugin_dcp",
    "plugin_oh_my",
    "plugin_pty",
    "plugin_vibeguard",
]


class PiModelEntry(BaseModel):
    """Model slot entry for Pi agent configuration."""

    model_config = ConfigDict(extra="forbid")

    id: str
    name: str | None = None
    provider: str = "ollama"


class PiConfig(BaseModel):
    """Pi coding agent generation settings.

    The `augint-opencodex` tool owns the generated `.pi/settings.json`
    and `.pi/skills/` directory.  Ollama provider registration
    (`~/.pi/agent/models.json`) and runtime concerns remain with
    `augint-shell`.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    default_model: str | None = None
    models: list[PiModelEntry] = Field(default_factory=list)
    thinking: bool = True
    extensions: list[str] = Field(default_factory=list)


class OpenCodeConfig(BaseModel):
    """OpenCode generation settings.

    The `augint-opencodex` tool owns the generated `opencode.json` file.
    Runtime launch concerns (container mounts, credential injection) remain
    with `augint-shell`.
    """

    model_config = ConfigDict(extra="forbid")

    enabled: bool = True
    default_model: str | None = None
    small_model: str | None = None
    local_provider: LocalProvider | None = Field(default_factory=LocalProvider)
    models: list[ModelEntry] = Field(default_factory=list)
    bedrock: BedrockConfig = Field(default_factory=BedrockConfig)
    extras: list[OpenCodeExtra] = Field(default_factory=list)


class CodexConfig(BaseModel):
    """Codex generation settings.

    The `augint-opencodex` tool owns the generated `.codex/config.toml` file.
    Secrets (`OPENAI_API_KEY`, AWS credentials) are intentionally out of scope
    and must be provided by `augint-shell` at runtime.
    """

    model_config = ConfigDict(extra="forbid")

    provider: Literal["openai", "aws"] = "openai"
    model: str | None = None
    approval_policy: str | None = None
    sandbox_mode: str | None = None
    web_search: str | None = None


class Manifest(BaseModel):
    """Tracked repo manifest used to render local agent config."""

    model_config = ConfigDict(extra="forbid", populate_by_name=True)

    schema_uri: str | None = Field(default=None, alias="$schema")
    version: Literal[1]
    profile: Literal["augint", "gov"]
    references: list[str] = Field(default_factory=list)
    blocked_paths: list[str] = Field(default_factory=list)
    content_policy: ContentPolicy = Field(default_factory=ContentPolicy)
    shell_guardrails: ShellGuardrails = Field(default_factory=ShellGuardrails)
    patterns: PatternFlags = Field(default_factory=PatternFlags)
    opencode: OpenCodeConfig = Field(default_factory=OpenCodeConfig)
    codex: CodexConfig = Field(default_factory=CodexConfig)
    pi: PiConfig = Field(default_factory=PiConfig)


def load_manifest(path: Path) -> Manifest:
    """Load and validate a manifest file from disk."""

    resolved_path = path.resolve()
    if not resolved_path.exists():
        raise ManifestError(f"Manifest not found: {resolved_path}")

    try:
        payload = json.loads(resolved_path.read_text(encoding="utf-8"))
    except json.JSONDecodeError as exc:
        raise ManifestError(f"Manifest is not valid JSON: {resolved_path}") from exc
    except OSError as exc:
        raise ManifestError(f"Unable to read manifest: {resolved_path}") from exc

    try:
        return Manifest.model_validate(payload)
    except ValidationError as exc:
        raise ManifestError(f"Manifest validation failed for {resolved_path}: {exc}") from exc
