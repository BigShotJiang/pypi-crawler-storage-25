"""MoonTime package (staging extraction)

Exports the `MoonTime` class and `moontime()` convenience function from the
standalone implementation in `.core`. During staging, the implementation still
delegates to legacy `mooncal` helpers for planetary-day and calendar lookup.
"""

from .core import MoonTime, moontime

__all__ = ["MoonTime", "moontime"]
