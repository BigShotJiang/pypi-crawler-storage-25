from __future__ import annotations

"""Thin wrapper around root-level aetherfield for staging/decoupling.

This allows the `moontime` package to depend on a simple indirection. In a
fully standalone repo, this module can be replaced by a vendored AetherField
implementation or an optional dependency.
"""

try:
    # Prefer the host project's implementation
    import aetherfield

    from aetherfield import aether_sign, aether_alignments, moon_phase, sunrise_sunset  # type: ignore
except Exception as exc:  # pragma: no cover - offline fallback
    # Minimal no-op fallbacks to keep module importable in test-only contexts
    def aether_sign(dt, body: str) -> str:  # type: ignore
        return "Unknown"

    def aether_alignments(dt):  # type: ignore
        return {}

    def moon_phase(dt):  # type: ignore
        return 0, {"name": "New Moon", "illum": 0, "angle_deg": 0.0}

    def sunrise_sunset(zone, coords, date=None, depression_deg: float = -0.833):  # type: ignore
        return None, None

__all__ = ["aether_sign", "aether_alignments", "moon_phase", "sunrise_sunset"]
