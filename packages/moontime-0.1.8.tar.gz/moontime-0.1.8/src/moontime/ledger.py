from __future__ import annotations

from datetime import datetime, timedelta, timezone, date
from typing import Optional, Dict, Any

import os
import json
import pytz
from dateutil import parser
import aetherfield as _aether

CACHE_PATH = os.path.join(os.path.expanduser("~"), ".cache", "moontime", "all_lunar_years.json")
REMOTE_URL = "https://pythoness.duckdns.org/v1/moontime/all_years"

def _sun_provider_preference() -> str:
    return "aether"
    v = os.getenv("MOONTIME_SUN_PROVIDER", "aether").strip().lower()
    return v if v in ("auto", "aether", "twilight") else "aether"


def get_pytz_timezone(zone) -> pytz.BaseTzInfo:
    try:
        if hasattr(zone, "localize"):
            return zone
        if isinstance(zone, str) and zone:
            return pytz.timezone(zone)
    except Exception:
        pass
    return pytz.UTC


# ------- Planetary rulers -------
PLANET_ORDER = ["Saturn", "Jupiter", "Mars", "Sun", "Venus", "Mercury", "Moon"]


def planet_for_index(day_idx: int) -> str:
    return PLANET_ORDER[(int(day_idx) - 1) % 7]


# ------- Sunrise/Sunset helpers via twilight grid -------
def _twilight(zone, coords, target_date: Optional[date] = None, now_local: Optional[datetime] = None):
    try:
        from skyfieldcomm import twilight  # type: ignore
    except Exception as exc:  # pragma: no cover
        return None
        #raise RuntimeError("skyfieldcomm.twilight is required for sunrise/sunset computation") from exc
    if now_local is not None:
        return twilight(zone, coords, now_local)
    return twilight(zone, coords, target_date=target_date)


def _get_sunrise_sunset_times(times, events, zone):
    local_tz = get_pytz_timezone(zone)
    sunrise_local = None
    sunset_local = None
    for t, ev in zip(times, events):
        # Normalize time entries: strings from skyfieldcomm.twilight are UTC naive
        if isinstance(t, str):
            try:
                dt = parser.parse(t)
            except Exception:
                continue
            if dt.tzinfo is None:
                import pytz as _p
                dt = dt.replace(tzinfo=_p.UTC)
            t_dt = dt
        else:
            t_dt = t
        if ev == 3:  # CIVIL_TWILIGHT
            sunrise_local = t_dt.astimezone(local_tz)
        elif ev == 4:  # SUN_IS_UP (sunset marker in this convention)
            sunset_local = t_dt.astimezone(local_tz)
        if sunrise_local and sunset_local:
            break
    if not (sunrise_local and sunset_local):  # pragma: no cover
        raise RuntimeError("Could not determine sunrise/sunset from twilight data.")
    return sunrise_local, sunset_local


def local_sunrise(date_local, zone, coords):
    pref = _sun_provider_preference()
    if pref in ("auto", "aether"):
        try:
            sr, _ = _aether.sunrise_sunset(zone, coords, date=date_local)
            if sr is not None:
                return sr
        except Exception:
            if pref == "aether":
                raise
    # twilight fallback
    data = _twilight(zone, coords, target_date=date_local)
    sunrise, _ = _get_sunrise_sunset_times(data["times"], data["events"], zone)
    return sunrise


def local_sunset(date_local, zone, coords):
    pref = _sun_provider_preference()
    if pref in ("auto", "aether"):
        try:
            _, ss = _aether.sunrise_sunset(zone, coords, date=date_local)
            if ss is not None:
                return ss
        except Exception:
            if pref == "aether":
                raise
    data = _twilight(zone, coords, target_date=date_local)
    _, sunset = _get_sunrise_sunset_times(data["times"], data["events"], zone)
    return sunset


# ------- Ledger-backed planetary day -------
def _load_all_lunar_years() -> Optional[Dict[str, Any]]:


    # 1. Local cache
    if os.path.exists(CACHE_PATH):
        try:
            with open(CACHE_PATH, "r", encoding="utf-8") as f:
                return json.load(f)
        except Exception:
            pass

    # 2. Remote fetch
    try:
        import urllib.request

        with urllib.request.urlopen(REMOTE_URL, timeout=5) as response:
            data = json.load(response)

        # 4. Save to cache
        os.makedirs(os.path.dirname(CACHE_PATH), exist_ok=True)
        with open(CACHE_PATH, "w", encoding="utf-8") as f:
            json.dump(data, f)

        return data

    except Exception:
        pass

    return None


def load_calendar_for_date(current_date: datetime, data: Optional[Dict[str, Any]] = None):
    all_data = data if data is not None else _load_all_lunar_years()
    if not all_data:
        return None

    g_year = current_date.year
    candidate_years = [y for y in (g_year - 1, g_year, g_year + 1) if str(y) in all_data]
    if current_date.tzinfo is None:
        current_date = current_date.replace(tzinfo=timezone.utc)
    else:
        current_date = current_date.astimezone(timezone.utc)

    for year_str in map(str, candidate_years):
        year_obj = all_data[year_str]
        months = year_obj["months"]
        for i, m in enumerate(months):
            start_dt = datetime.fromisoformat(m["start"])  # UTC stored
            if i + 1 < len(months):
                end_dt = datetime.fromisoformat(months[i + 1]["start"])  # UTC
            else:
                end_dt = start_dt + timedelta(days=int(m["days"]))
            if start_dt <= current_date < end_dt:
                day_number = (current_date.date() - start_dt.date()).days + 1
                return {
                    "lunar_year": year_obj["approximate_year"],
                    "gregorian_year": int(year_str),
                    "month_index": m["index"],
                    "month_name": m["name"],
                    "sun_sign": m.get("sun_sign", "Unknown"),
                    "day_in_month": day_number,
                    "weekday": ("Nycturia",),  # not needed for MoonTime display
                }
    return None


def planetary_day_for(moment: Optional[datetime] = None, zone=None, coords=None) -> Optional[dict]:
    if not moment:
        moment = datetime.now()  # naive

    local_tz = get_pytz_timezone(zone)
    if moment.tzinfo is None:
        moment = local_tz.localize(moment)
    else:
        moment = moment.astimezone(local_tz)

    all_data = _load_all_lunar_years()
    if not all_data:
        return None

    pd_entry = None
    for block in all_data.values():
        for pd in block.get("planetary_days", []):
            ss = parser.isoparse(pd["sunset"]).astimezone(local_tz)
            nss = parser.isoparse(pd["next_sunset"]).astimezone(local_tz)
            if ss <= moment < nss:
                pd_entry = pd
                break
        if pd_entry:
            break

    if not pd_entry:
        return None

    sunset = parser.isoparse(pd_entry["sunset"]).astimezone(local_tz)
    next_sunset = parser.isoparse(pd_entry["next_sunset"]).astimezone(local_tz)
    sunrise = local_sunrise(sunset.date() + timedelta(days=1), zone, coords)

    # Optionally override next_sunset using Aether provider
    nss_provider = None
    if _sun_provider_preference() in ("auto", "aether"):
        try:
            # compute sunset on the same local date as sunrise
            a_sr, a_ss = _aether.sunrise_sunset(zone, coords, date=sunrise.date())
            if a_ss is not None:
                next_sunset = a_ss
                nss_provider = "aether"
        except Exception:
            pass

    night_len = (sunrise - sunset).total_seconds() / 12
    day_len = (next_sunset - sunrise).total_seconds() / 12

    def hour_bounds(h_idx: int):  # 1-based
        if h_idx <= 12:
            start = sunset + timedelta(seconds=(h_idx - 1) * night_len)
            end = start + timedelta(seconds=night_len)
        else:
            start = sunrise + timedelta(seconds=(h_idx - 13) * day_len)
            end = start + timedelta(seconds=day_len)
        return start, end

    for h in range(1, 25):
        h_start, h_end = hour_bounds(h)
        if h_start <= moment < h_end:
            hour_index = h
            hour_start = h_start
            hour_end = h_end
            break

    day_index = pd_entry["day_index"]
    day_ruler = planet_for_index(day_index)
    hour_ruler = planet_for_index(day_index + hour_index - 1)

    hour_seconds = (hour_end - hour_start).total_seconds()
    minute_seconds = hour_seconds / 60.0
    second_seconds = minute_seconds / 60.0

    elapsed_sec = (moment - hour_start).total_seconds()
    minute_index = int(elapsed_sec // minute_seconds) + 1
    if minute_index > 60:
        minute_index = 60
    minute_start = hour_start + timedelta(seconds=(minute_index - 1) * minute_seconds)
    minute_end = minute_start + timedelta(seconds=minute_seconds)
    if minute_end > hour_end:
        minute_end = hour_end

    elapsed_in_min = (moment - minute_start).total_seconds()
    if elapsed_in_min < 0:
        elapsed_in_min = 0
    second_index = int(elapsed_in_min // second_seconds) + 1
    if second_index > 60:
        second_index = 60
    second_start = minute_start + timedelta(seconds=(second_index - 1) * second_seconds)
    second_end = second_start + timedelta(seconds=second_seconds)
    if second_end > minute_end:
        second_end = minute_end

    return {
        "day_index": day_index,
        "day_ruler": day_ruler,
        "hour_index": hour_index,
        "hour_ruler": hour_ruler,
        "hour_start": hour_start,
        "hour_end": hour_end,
        "hour_length_seconds": hour_seconds,
        "minute_index": minute_index,
        "minute_start": minute_start,
        "minute_end": minute_end,
        "minute_length_seconds": minute_seconds,
        "second_index": second_index,
        "second_start": second_start,
        "second_end": second_end,
        "second_length_seconds": second_seconds,
    }
