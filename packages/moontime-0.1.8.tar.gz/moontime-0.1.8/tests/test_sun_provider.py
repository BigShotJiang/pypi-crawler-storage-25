from datetime import datetime, date, timedelta
import pytz


def test_local_sunrise_prefers_aether(monkeypatch):
    import os
    import moontime.ledger as ledger
    import moontime.aether as aether

    os.environ["MOONTIME_SUN_PROVIDER"] = "aether"
    tz = pytz.timezone("Europe/Athens")
    sentinel = tz.localize(datetime(2025, 4, 2, 6, 0, 0))

    def fake_sr_ss(zone, coords, date=None, depression_deg=-0.833):
        return sentinel, None

    monkeypatch.setattr(aether, "sunrise_sunset", fake_sr_ss, raising=True)
    sr = ledger.local_sunrise(date(2025, 4, 2), "Europe/Athens", "37.24,25.1603")
    assert sr == sentinel


def test_local_sunrise_twilight_fallback(monkeypatch):
    import os
    import moontime.ledger as ledger

    os.environ["MOONTIME_SUN_PROVIDER"] = "twilight"
    tz = pytz.timezone("Europe/Athens")
    sunrise = tz.localize(datetime(2025, 4, 2, 6, 1, 0)).astimezone(pytz.UTC)
    sunset = tz.localize(datetime(2025, 4, 2, 19, 42, 0)).astimezone(pytz.UTC)

    # Provide strings similar to skyfieldcomm.twilight output
    twi = {
        "times": [sunrise.strftime("%Y-%m-%d %H:%M:%S"), sunset.strftime("%Y-%m-%d %H:%M:%S")],
        "events": [3, 4],
    }

    monkeypatch.setattr(ledger, "_twilight", lambda zone, coords, target_date=None: twi, raising=True)
    sr = ledger.local_sunrise(date(2025, 4, 2), "Europe/Athens", "37.24,25.1603")
    # Convert to Europe/Athens tz then compare hour:min
    sr_local = sr.astimezone(tz)
    assert sr_local.hour == 6 and sr_local.minute == 1


def test_planetary_day_uses_aether_next_sunset(monkeypatch):
    import os
    import moontime.ledger as ledger

    os.environ["MOONTIME_SUN_PROVIDER"] = "aether"
    tz = pytz.timezone("Europe/Athens")

    # Stub lunar years with a planetary day spanning Apr 1 19:00 -> Apr 2 20:00
    pd = {
        "2025": {
            "months": [],
            "planetary_days": [
                {
                    "day_index": 2,
                    "name": "Jupiter",
                    "sunset": tz.localize(datetime(2025, 4, 1, 19, 0, 0)).isoformat(),
                    "sunset_greg": "2025-04-01",
                    "next_sunset": tz.localize(datetime(2025, 4, 2, 20, 0, 0)).isoformat(),
                }
            ],
        }
    }
    monkeypatch.setattr(ledger, "_load_all_lunar_years", lambda: pd, raising=True)

    # Force aether sunrise/sunset for Apr 2: 06:00/18:00
    def fake_sr_ss(zone, coords, date=None, depression_deg=-0.833):
        base = tz.localize(datetime(date.year, date.month, date.day, 0, 0, 0))
        return base.replace(hour=6), base.replace(hour=18)

    import moontime.aether as aether
    monkeypatch.setattr(aether, "sunrise_sunset", fake_sr_ss, raising=True)

    # Choose a moment clearly in the day half
    moment = tz.localize(datetime(2025, 4, 2, 12, 0, 0))
    info = ledger.planetary_day_for(moment, "Europe/Athens", "37.24,25.1603")
    assert info is not None
    # At noon, it should be a day hour ~1.0 hours long from aether override
    assert 3500 <= info["hour_length_seconds"] <= 3700

