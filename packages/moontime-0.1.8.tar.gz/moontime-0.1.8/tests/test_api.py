from datetime import datetime, timedelta


def _stub_planetary_day_for(moment, zone, coords):
    tz = moment.tzinfo
    hour_start = moment.replace(minute=0, second=0, microsecond=0)
    hour_end = hour_start + timedelta(hours=1)
    hour_len = 3600.0
    minute_index = moment.minute + 1
    second_index = moment.second + 1
    minute_start = hour_start + timedelta(minutes=moment.minute)
    minute_end = minute_start + timedelta(minutes=1)
    second_start = minute_start + timedelta(seconds=moment.second)
    second_end = second_start + timedelta(seconds=1)
    hour_idx = (moment.hour % 24) + 1
    return {
        "day_index": 1,
        "day_ruler": "Saturn",
        "hour_index": hour_idx,
        "hour_ruler": "Sun",
        "hour_start": hour_start,
        "hour_end": hour_end,
        "hour_length_seconds": hour_len,
        "minute_index": minute_index,
        "minute_start": minute_start,
        "minute_end": minute_end,
        "minute_length_seconds": 60.0,
        "second_index": second_index,
        "second_start": second_start,
        "second_end": second_end,
        "second_length_seconds": 1.0,
    }


def test_import_and_now(monkeypatch):
    import moontime as mt
    import moontime.core as core
    import moontime.ledger as ledger
    import moontime.aether as aether

    monkeypatch.setattr(ledger, "planetary_day_for", _stub_planetary_day_for, raising=True)
    monkeypatch.setattr(ledger, "load_calendar_for_date", lambda dt: None, raising=True)
    monkeypatch.setattr(aether, "moon_phase", lambda dt: (4, {"name": "Full Moon", "illum": 100, "angle_deg": 180.0}), raising=True)

    m = mt.MoonTime.now()
    assert hasattr(m, "temporal_hms")
    assert hasattr(m, "isoformat")
    s = m.isoformat()
    assert isinstance(s, str) and s.startswith("mt:")


def test_temporal_arithmetic(monkeypatch):
    import moontime as mt
    import moontime.ledger as ledger
    import moontime.aether as aether

    monkeypatch.setattr(ledger, "planetary_day_for", _stub_planetary_day_for, raising=True)
    monkeypatch.setattr(ledger, "load_calendar_for_date", lambda dt: None, raising=True)
    monkeypatch.setattr(aether, "moon_phase", lambda dt: (4, {"name": "Full Moon", "illum": 100, "angle_deg": 180.0}), raising=True)

    m = mt.MoonTime.now()
    m2 = m.add_temporal(minutes=1)
    tsec = m.temporal_seconds_to(m2)
    assert 59.0 <= tsec <= 61.0
