"""Composable system prompt builder.

PromptBuilder manages a collection of PromptLayer instances and orchestrates
two-phase rendering: CONFIGURE (static vars resolved once) and REQUEST
(dynamic vars resolved per call).

Replaces the monolithic system_prompt_template + create_system_prompt()
string concatenation approach.

See spec: sdd/specs/composable-prompt-layer.spec.md (Section 3.3)
"""
from __future__ import annotations

from copy import deepcopy
from typing import Optional, Dict, Any, List

from .layers import PromptLayer, LayerPriority, RenderPhase
from .segments import CacheableSegment


class PromptBuilder:
    """Composable system prompt builder.

    Usage:
        builder = PromptBuilder.default()
        builder.remove("tools")           # no tools for this agent
        builder.add(my_custom_layer)      # add domain-specific layer

        # Phase 1: resolve static vars once
        builder.configure({"name": "Bot", "role": "helper", ...})

        # Phase 2: resolve dynamic vars per request
        prompt = builder.build({"knowledge_content": "...", ...})
    """

    def __init__(
        self,
        layers: Optional[List[PromptLayer]] = None,
        *,
        prompt_caching: bool = False,
    ):
        self._layers: Dict[str, PromptLayer] = {}
        self._configured: bool = False
        # FEAT-181: store prompt_caching flag for AbstractBot to inspect.
        self.prompt_caching: bool = prompt_caching
        if layers:
            for layer in layers:
                self._layers[layer.name] = layer

    # ── Factory methods ────────────────────────────────────────

    @classmethod
    def default(cls) -> PromptBuilder:
        """Standard layer stack for most bots."""
        from .layers import (
            IDENTITY_LAYER, PRE_INSTRUCTIONS_LAYER, SECURITY_LAYER,
            KNOWLEDGE_LAYER, USER_SESSION_LAYER, TOOLS_LAYER,
            OUTPUT_LAYER, BEHAVIOR_LAYER,
        )
        return cls([
            IDENTITY_LAYER, PRE_INSTRUCTIONS_LAYER, SECURITY_LAYER,
            KNOWLEDGE_LAYER, USER_SESSION_LAYER, TOOLS_LAYER,
            OUTPUT_LAYER, BEHAVIOR_LAYER,
        ])

    @classmethod
    def minimal(cls) -> PromptBuilder:
        """Lightweight stack: identity + security + user_session only."""
        from .layers import IDENTITY_LAYER, SECURITY_LAYER, USER_SESSION_LAYER
        return cls([IDENTITY_LAYER, SECURITY_LAYER, USER_SESSION_LAYER])

    @classmethod
    def voice(cls) -> PromptBuilder:
        """Voice-optimized stack with voice behavior layer."""
        from .layers import (
            IDENTITY_LAYER, PRE_INSTRUCTIONS_LAYER, SECURITY_LAYER,
            KNOWLEDGE_LAYER, USER_SESSION_LAYER, TOOLS_LAYER,
        )
        voice_behavior = PromptLayer(
            name="behavior",
            priority=LayerPriority.BEHAVIOR,
            phase=RenderPhase.CONFIGURE,
            template="""<response_style>
Keep responses concise and conversational.
Speak naturally, as in a face-to-face conversation.
Avoid long lists or complex formatting.
Use conversational transitions and acknowledgments.
$rationale
</response_style>""",
            condition=lambda ctx: True,
        )
        return cls([
            IDENTITY_LAYER, PRE_INSTRUCTIONS_LAYER, SECURITY_LAYER,
            KNOWLEDGE_LAYER, USER_SESSION_LAYER, TOOLS_LAYER,
            voice_behavior,
        ])

    @classmethod
    def agent(cls) -> PromptBuilder:
        """Agent stack with general-purpose grounding behavior."""
        from .domain_layers import AGENT_BEHAVIOR_LAYER
        builder = cls.default()
        builder.add(AGENT_BEHAVIOR_LAYER)
        return builder

    @classmethod
    def rag(cls) -> PromptBuilder:
        """RAG-only stack: anchors the agent to <knowledge_context> and the
        backstory-declared KB scope, forbids out-of-context knowledge.

        Tools layer is removed because RAG-only agents have no callable
        tools beyond the retriever (whose output already lands in the
        knowledge layer).
        """
        from .domain_layers import KNOWLEDGE_SCOPE_LAYER, RAG_GROUNDING_LAYER
        builder = cls.default()
        builder.remove("tools")
        builder.add(KNOWLEDGE_SCOPE_LAYER)
        builder.add(RAG_GROUNDING_LAYER)
        return builder

    @classmethod
    def from_system_prompt(cls, system_prompt: str) -> PromptBuilder:
        """Default stack with the identity layer replaced by ``system_prompt``.

        Targets YAML-defined agents whose ``system_prompt`` already declares
        the agent's identity ("You are an assistant for X...") and would
        therefore conflict with the canned IDENTITY_LAYER. The user's text
        takes over the identity slot; the rest of the default stack
        (security, knowledge, user_session, tools, output, behavior) wraps
        around it unchanged.

        Args:
            system_prompt: Raw system prompt text. ``$variable`` placeholders
                are still substituted via ``string.Template`` at render time.

        Returns:
            A fresh PromptBuilder with the identity layer overridden.
        """
        from .layers import PromptLayer, LayerPriority, RenderPhase
        builder = cls.default()
        builder.add(PromptLayer(
            name="identity",
            priority=LayerPriority.IDENTITY,
            phase=RenderPhase.CONFIGURE,
            template=system_prompt,
        ))
        return builder

    # ── Mutation API ────────────────────────────────────────────

    def add(self, layer: PromptLayer) -> PromptBuilder:
        """Add or replace a layer by name.

        Args:
            layer: The PromptLayer to add.

        Returns:
            Self for method chaining.
        """
        self._layers[layer.name] = layer
        return self

    def remove(self, name: str) -> PromptBuilder:
        """Remove a layer by name. No-op if not present.

        Args:
            name: The layer name to remove.

        Returns:
            Self for method chaining.
        """
        self._layers.pop(name, None)
        return self

    def replace(self, name: str, layer: PromptLayer) -> PromptBuilder:
        """Replace an existing layer. Raises KeyError if not found.

        Args:
            name: The layer name to replace.
            layer: The new PromptLayer.

        Returns:
            Self for method chaining.

        Raises:
            KeyError: If the named layer is not in the builder.
        """
        if name not in self._layers:
            raise KeyError(
                f"Layer '{name}' not found. Use add() instead. "
                f"Available: {list(self._layers.keys())}"
            )
        self._layers[name] = layer
        return self

    def get(self, name: str) -> Optional[PromptLayer]:
        """Get a layer by name.

        Args:
            name: The layer name to retrieve.

        Returns:
            The PromptLayer, or None if not found.
        """
        return self._layers.get(name)

    def clone(self) -> PromptBuilder:
        """Deep copy for per-agent customization.

        Returns:
            A new independent PromptBuilder with the same layers.
        """
        new_builder = PromptBuilder(
            list(deepcopy(self._layers).values()),
            prompt_caching=self.prompt_caching,
        )
        new_builder._configured = self._configured
        return new_builder

    # ── Build ───────────────────────────────────────────────────

    def configure(self, context: Dict[str, Any]) -> None:
        """Phase 1: Resolve CONFIGURE-phase variables once.

        Called during bot.configure(). Resolves static variables
        (name, role, goal, backstory, rationale, dynamic_values, etc.)
        via partial_render(), caching the partially-resolved layers.
        REQUEST-phase $placeholders survive intact for build().

        Args:
            context: Dictionary of static variable values.
        """
        configured_layers: Dict[str, PromptLayer] = {}
        for name, layer in self._layers.items():
            if layer.phase == RenderPhase.CONFIGURE:
                configured_layers[name] = layer.partial_render(context)
            else:
                configured_layers[name] = layer
        self._layers = configured_layers
        self._configured = True

    def build(self, context: Dict[str, Any]) -> str:
        """Phase 2: Resolve REQUEST-phase variables and assemble final prompt.

        Called on every ask()/ask_stream(). Only resolves dynamic
        variables (knowledge_content, user_context, chat_history, etc.)
        because CONFIGURE-phase layers already have their static
        variables baked in from configure().

        If configure() was never called, all layers are rendered
        with the full context (single-phase fallback).

        Args:
            context: Dictionary of dynamic variable values.

        Returns:
            The assembled system prompt string.
        """
        sorted_layers = sorted(self._layers.values(), key=lambda l: l.priority)

        parts: List[str] = []
        for layer in sorted_layers:
            rendered = layer.render(context)
            if rendered is not None:
                stripped = rendered.strip()
                if stripped:
                    parts.append(stripped)

        return "\n\n".join(parts)

    def build_segments(self, context: Dict[str, Any]) -> List[CacheableSegment]:
        """Phase 2 (caching): Produce a list of CacheableSegment objects.

        FEAT-181 — Provider-Agnostic Prompt Caching.

        Mirrors the iteration in :meth:`build` but produces
        :class:`~parrot.bots.prompts.segments.CacheableSegment` objects tagged
        with ``layer.cacheable`` instead of joining strings. Empty rendered
        layers are excluded (same behaviour as :meth:`build`).

        This method can be called regardless of the ``prompt_caching`` flag
        value. The flag is inspected by ``AbstractBot`` to decide whether to
        call ``build()`` or ``build_segments()``.

        Args:
            context: Dictionary of dynamic variable values (same as
                :meth:`build`).

        Returns:
            Ordered list of :class:`CacheableSegment` objects corresponding
            to non-empty rendered layers, preserving priority order.
        """
        sorted_layers = sorted(self._layers.values(), key=lambda lyr: lyr.priority)
        segments: List[CacheableSegment] = []
        for layer in sorted_layers:
            rendered = layer.render(context)
            if rendered is not None:
                stripped = rendered.strip()
                if stripped:
                    segments.append(
                        CacheableSegment(
                            text=stripped,
                            cacheable=bool(layer.cacheable),
                        )
                    )
        return segments

    @property
    def is_configured(self) -> bool:
        """Whether configure() has been called."""
        return self._configured

    @property
    def layer_names(self) -> List[str]:
        """List of layer names currently in the builder."""
        return list(self._layers.keys())
