"""Top-level test configuration and shared fixtures."""

from __future__ import annotations
