# loadtester

High‑performance, configurable HTTP load testing library.

## Features
- Rate‑limited traffic
- Retry with exponential backoff
- Thread‑pooled execution
- CSV result export
- Fully customizable payloads & headers

## Usage
See `examples/basic_run.py`
