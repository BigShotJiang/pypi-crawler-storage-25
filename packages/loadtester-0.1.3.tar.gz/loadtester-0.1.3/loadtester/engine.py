from .runner import run_for_rp
from .summary import print_summary_table

class LoadTester:
    def __init__(self, config):
        self.config = config

    def run(self, print_summary: bool = True):
        results = []

        for rp in self.config.rp_values:
            result = run_for_rp(self.config, rp)
            results.append(result)

        if print_summary:
            print_summary_table(results, self.config)

        return results
