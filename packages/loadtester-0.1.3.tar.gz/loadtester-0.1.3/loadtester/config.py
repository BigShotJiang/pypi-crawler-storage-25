from dataclasses import dataclass
from typing import Callable, Dict, Any, List, Tuple, Set, Optional


@dataclass
class LoadTestConfig:
    # Required
    url: str
    http_method: str                # ✅ NEW: "GET" or "POST"
    total_requests: int
    concurrency_window_ms: int
    rp_values: List[int]

    make_headers: Callable[[str], Dict[str, str]]

    # Payload builders
    build_body: Optional[Callable[[str], Dict[str, Any]]] = None   # POST
    build_params: Optional[Callable[[str], Dict[str, Any]]] = None # GET

    # Optional tuning
    batch_size: int = 10_000
    max_workers: int = 2000
    request_timeout: Tuple[int, int] = (5, 20)
    log_every: int = 1000

    max_attempts: int = 5
    backoff_base: float = 0.5
    retriable_status: Set[int] = (429, 500, 502, 503, 504)

    # Logging
    verbose: bool = False
    log_every_request: bool = False
