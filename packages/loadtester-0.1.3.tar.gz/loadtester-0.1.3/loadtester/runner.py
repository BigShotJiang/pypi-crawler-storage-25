import time
import uuid
import random
from concurrent.futures import ThreadPoolExecutor, as_completed
import requests

from .rate_limiter import WindowedRateLimiter
from .session import build_session


def run_for_rp(config, rp: int):
    max_rps = (rp / config.concurrency_window_ms) * 1000
    rate_limiter = WindowedRateLimiter(rp, config.concurrency_window_ms)
    session = build_session(config.max_workers)

    total_ok = total_fail = 0
    latencies = []

    remaining = config.total_requests
    global_index = 0

    while remaining > 0:
        batch = min(config.batch_size, remaining)

        with ThreadPoolExecutor(max_workers=config.max_workers) as executor:
            futures = {
                executor.submit(
                    submit_task,
                    session,
                    config,
                    global_index + i,
                    rate_limiter,
                )
                for i in range(batch)
            }

            for fut in as_completed(futures):
                ok, latency_ms = fut.result()
                latencies.append(latency_ms)
                total_ok += ok
                total_fail += not ok

        global_index += batch
        remaining -= batch

    latencies.sort()
    n = len(latencies)

    return {
        "rp": rp,
        "rps_ceiling": max_rps,
        "total_ok": total_ok,
        "total_fail": total_fail,
        "total_time_ms": round(sum(latencies), 2),
        "avg_latency_ms": round(sum(latencies) / n, 2),
        "min_latency_ms": round(latencies[0], 2),
        "max_latency_ms": round(latencies[-1], 2),
        "p95_ms": round(latencies[int(n * 0.95)], 2),
        "p99_ms": round(latencies[int(n * 0.99)], 2),
    }


def submit_task(session, config, index, rate_limiter):
    x_req_uid = uuid.uuid4().hex
    entity_id = f"ENTITY-{index}"

    headers = config.make_headers(x_req_uid)

    attempt = 0
    method = config.http_method.upper()

    while True:
        attempt += 1
        rate_limiter.acquire()
        time.sleep(random.uniform(0.0, 0.005))

        start = time.perf_counter()

        try:
            # ✅ METHOD-AWARE REQUEST
            if method == "GET":
                resp = session.get(
                    config.url,
                    headers=headers,
                    params=config.build_params(entity_id) if config.build_params else None,
                    timeout=config.request_timeout,
                )

            elif method == "POST":
                resp = session.post(
                    config.url,
                    headers=headers,
                    json=config.build_body(entity_id) if config.build_body else None,
                    timeout=config.request_timeout,
                    verify=False
                )

            else:
                raise ValueError(f"Unsupported HTTP method: {method}")

            latency_ms = (time.perf_counter() - start) * 1000
            ok = resp.ok

            snippet = resp.text[:300] if resp.text else ""
            status  = resp.status_code

            print(
                f"HTTP {status} | latency={latency_ms:.1f}ms"
            )

            if config.verbose and (
                config.log_every_request or index % config.log_every == 0
            ):
                print(
                    f"[REQ {index}] "
                    f"req_id={x_req_uid} "
                    f"method={method} "
                    f"status={resp.status_code} "
                    f"latency={latency_ms:.2f}ms "
                    f"{'OK' if ok else 'FAIL'}"
                )

            return ok, latency_ms

        except requests.RequestException as e:
            latency_ms = (time.perf_counter() - start) * 1000

            if attempt < config.max_attempts:
                time.sleep(config.backoff_base * (2 ** (attempt - 1)))
                continue

            return False, latency_ms
