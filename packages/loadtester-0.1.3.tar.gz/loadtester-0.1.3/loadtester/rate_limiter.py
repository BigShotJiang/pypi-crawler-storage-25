import threading
import time

class WindowedRateLimiter:
    def __init__(self, max_requests: int, window_ms: int):
        self.max_requests = max_requests
        self.window_sec = window_ms / 1000.0
        self.lock = threading.Lock()
        self.timestamps = []

    def acquire(self):
        while True:
            with self.lock:
                now = time.perf_counter()
                cutoff = now - self.window_sec
                self.timestamps = [t for t in self.timestamps if t > cutoff]
                if len(self.timestamps) < self.max_requests:
                    self.timestamps.append(now)
                    return
            time.sleep(self.window_sec / self.max_requests * 0.5)
