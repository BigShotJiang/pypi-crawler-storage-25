import requests
from requests.adapters import HTTPAdapter

def build_session(max_workers: int) -> requests.Session:
    session = requests.Session()
    adapter = HTTPAdapter(
        pool_connections=max_workers * 2,
        pool_maxsize=max_workers * 4,
    )
    session.mount("http://", adapter)
    session.mount("https://", adapter)
    return session
