import csv

def print_summary_table(results, config):
    print("\n" + "=" * 90)
    print(" LOAD TEST SUMMARY")
    print(f" TOTAL_REQUESTS={config.total_requests:,} "
          f"| WINDOW={config.concurrency_window_ms}ms")
    print("=" * 90)

    print(
        f"{'RP':<8}{'RPS':<12}{'Total(ms)':<15}"
        f"{'Avg(ms)':<12}{'p95':<10}{'p99':<10}"
        f"{'OK':<10}{'FAIL':<10}"
    )
    print("-" * 90)

    for r in results:
        print(
            f"{r['rp']:<8}"
            f"{r['rps_ceiling']:<12.0f}"
            f"{r['total_time_ms']:<15.2f}"
            f"{r['avg_latency_ms']:<12.2f}"
            f"{r['p95_ms']:<10.2f}"
            f"{r['p99_ms']:<10.2f}"
            f"{r['total_ok']:<10}"
            f"{r['total_fail']:<10}"
        )

    with open("load_test_results.csv", "w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=results[0].keys())
        writer.writeheader()
        writer.writerows(results)

    print("\nResults saved → load_test_results.csv")
