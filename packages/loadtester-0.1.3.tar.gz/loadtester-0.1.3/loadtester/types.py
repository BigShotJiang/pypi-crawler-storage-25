from typing import TypedDict

class RunResult(TypedDict):
    rp: int
    rps_ceiling: float
    total_ok: int
    total_fail: int
    total_time_ms: float
    avg_latency_ms: float
    min_latency_ms: float
    max_latency_ms: float
    p95_ms: float
    p99_ms: float
