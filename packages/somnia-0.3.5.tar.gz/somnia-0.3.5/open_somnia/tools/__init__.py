"""Tool implementations."""
