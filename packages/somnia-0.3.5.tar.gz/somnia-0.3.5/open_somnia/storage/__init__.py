"""Persistent stores."""
