"""Collaboration primitives."""
