"""MCP client integration."""
