"""CLI entrypoints for OpenAgent."""
