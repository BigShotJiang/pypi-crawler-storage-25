from datetime import datetime
from typing import Literal

from nonebot_plugin_orm import Model
from sqlalchemy import JSON, String
from sqlalchemy.orm import Mapped, MappedAsDataclass, mapped_column

from ....db.models import PydanticType
from ....db.types import UTCDateTime
from .schemas.base import SuccessModel
from .typedefs import Records, Summaries


class TETRIOHistoricalData(MappedAsDataclass, Model):
    __tablename__ = 'nb_t_io_hist_data'

    id: Mapped[int] = mapped_column(init=False, primary_key=True)
    user_unique_identifier: Mapped[str] = mapped_column(String(24), index=True)
    api_type: Mapped[Literal['User Info', Records, Summaries]] = mapped_column(String(32), index=True)
    data: Mapped[SuccessModel] = mapped_column(PydanticType(get_model=[SuccessModel.__subclasses__], models=set()))
    update_time: Mapped[datetime] = mapped_column(UTCDateTime(), index=True)
    query_params: Mapped[dict | None] = mapped_column(JSON, nullable=True, default=None)
