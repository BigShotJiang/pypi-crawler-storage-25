# Changelog · `causeway-deploy-docker`

All notable changes to the `causeway-deploy-docker` Python package will be documented in
this file. Managed automatically by [release-please](https://github.com/googleapis/release-please)
from [Conventional Commits](https://www.conventionalcommits.org/).

The format follows [Keep a Changelog](https://keepachangelog.com/en/1.1.0/) and
adheres to [Semantic Versioning](https://semver.org/spec/v2.0.0.html).

## [0.6.0](https://github.com/tamimbinhakim/causeway/compare/causeway-deploy-docker-v0.5.0...causeway-deploy-docker-v0.6.0) (2026-05-19)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway:** reshape events/webhooks around subscribers and a typed Event ([#21](https://github.com/tamimbinhakim/causeway/issues/21)) ([646564f](https://github.com/tamimbinhakim/causeway/commit/646564f66973aba67dd13fc4904ceb924b73c694))
* **causeway:** v0.2 — pagination, batch, idempotency, permissions, webhooks, binary export ([45852fd](https://github.com/tamimbinhakim/causeway/commit/45852fd2d6f80aa69d99770e4acdec0aeb67bf03))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [0.5.0](https://github.com/tamimbinhakim/causeway/compare/causeway-deploy-docker-v0.4.0...causeway-deploy-docker-v0.5.0) (2026-05-18)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway:** v0.2 — pagination, batch, idempotency, permissions, webhooks, binary export ([45852fd](https://github.com/tamimbinhakim/causeway/commit/45852fd2d6f80aa69d99770e4acdec0aeb67bf03))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [0.4.0](https://github.com/tamimbinhakim/causeway/compare/causeway-deploy-docker-v0.3.0...causeway-deploy-docker-v0.4.0) (2026-05-18)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway:** v0.2 — pagination, batch, idempotency, permissions, webhooks, binary export ([45852fd](https://github.com/tamimbinhakim/causeway/commit/45852fd2d6f80aa69d99770e4acdec0aeb67bf03))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [0.3.0](https://github.com/tamimbinhakim/causeway/compare/causeway-deploy-docker-v0.2.0...causeway-deploy-docker-v0.3.0) (2026-05-18)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway:** v0.2 — pagination, batch, idempotency, permissions, webhooks, binary export ([45852fd](https://github.com/tamimbinhakim/causeway/commit/45852fd2d6f80aa69d99770e4acdec0aeb67bf03))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [0.2.0](https://github.com/tamimbinhakim/causeway/compare/causeway-deploy-docker-v0.1.0...causeway-deploy-docker-v0.2.0) (2026-05-17)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Features

* **causeway:** v0.2 — pagination, batch, idempotency, permissions, webhooks, binary export ([45852fd](https://github.com/tamimbinhakim/causeway/commit/45852fd2d6f80aa69d99770e4acdec0aeb67bf03))


### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## 0.1.0 (2026-05-16)


### ⚠ BREAKING CHANGES

* drops the 0.1.0a0 pre-release line. The first published versions on PyPI will be 0.1.0.
* the framework is now distributed as `causeway` (and `causeway-<role>-<impl>` for plugins). Every public surface moves:

### Chores

* prep first 0.1.0 release across all 13 packages ([11ef338](https://github.com/tamimbinhakim/causeway/commit/11ef3382a6263cbe541455dd169a28cf162ebb3d))
* rename quay → causeway across the repo ([83f1213](https://github.com/tamimbinhakim/causeway/commit/83f1213a2176e8338305f8b30f43379d6a614238))

## [Unreleased]
