import logging
from pathlib import Path
from typing import Unpack

from fluidattacks_core.models.scanners import (
    SbomAwsCredentials,
    SbomDockerCredentials,
    SbomOutputConfig,
    SbomPlatformOverrides,
    ScanConfig,
    SourceType,
    build_config,
)
from pydantic import StrictBool

from labels.model.core import (
    LabelsSbomSubConfig,
    OutputFormat,
    SbomConfig,
    ScanArgs,
)
from labels.utils.exceptions import InvalidConfigFileError

LOGGER = logging.getLogger(__name__)


class LabelsStaticScanConfig(ScanConfig):
    source_type: SourceType = SourceType.DIRECTORY
    working_dir: str = "./"
    source: str | None = None
    execution_id: str | None = None
    docker_credentials: SbomDockerCredentials | None = None
    platform_overrides: SbomPlatformOverrides | None = None
    aws_credentials: SbomAwsCredentials | None = None
    debug: StrictBool = False
    sbom: LabelsSbomSubConfig


def build_labels_config_from_args(arg: str, **kwargs: Unpack[ScanArgs]) -> SbomConfig:
    docker_user = kwargs["docker_user"]
    docker_password = kwargs["docker_password"]
    os_ = kwargs["os"]
    arch = kwargs["arch"]
    aws_external_id = kwargs["aws_external_id"]
    aws_role = kwargs["aws_role"]
    aws_region = kwargs["aws_region"]

    output_format = OutputFormat.from_string(kwargs["format"])
    return SbomConfig(
        sbom=LabelsSbomSubConfig(
            source=arg,
            source_type=SourceType(kwargs["source"]),
            output=SbomOutputConfig(name=kwargs["output"], format=output_format.value),
            docker_credentials=SbomDockerCredentials(username=docker_user, password=docker_password)
            if docker_user or docker_password
            else None,
            platform_overrides=SbomPlatformOverrides(os_override=os_, arch_override=arch)
            if os_ or arch
            else None,
            aws_credentials=SbomAwsCredentials(
                external_id=aws_external_id,
                role=aws_role,
                region=aws_region,
            )
            if aws_external_id or aws_role or aws_region
            else None,
            feature_preview=kwargs["feature_preview"],
        ),
        debug=kwargs["debug"],
    )


def build_labels_config_from_file(
    config_file_path: str,
    *,
    static_scan: bool = False,
) -> SbomConfig:
    if Path(config_file_path).is_file():
        if not config_file_path.endswith((".yaml", ".yml")):
            error_msg = "The configuration file must be a YAML format"
            raise InvalidConfigFileError(config_file_path, error_msg)
        if static_scan:
            return _load_config_from_static_scan(config_file_path)
        return build_config(config_file_path, SbomConfig)

    raise InvalidConfigFileError(config_file_path)


def _load_config_from_static_scan(config_path: str) -> SbomConfig:
    config = build_config(config_path, LabelsStaticScanConfig)

    source = (
        config.working_dir
        if config.source_type == SourceType.DIRECTORY or config.source is None
        else config.source
    )

    return SbomConfig(
        sbom=LabelsSbomSubConfig(
            source=source,
            source_type=config.source_type,
            include=config.sbom.include,
            exclude=config.sbom.exclude,
            output=config.sbom.output,
            docker_credentials=config.docker_credentials,
            platform_overrides=config.platform_overrides,
            aws_credentials=config.aws_credentials,
            include_package_metadata=config.sbom.include_package_metadata,
            include_package_advisories=config.sbom.include_package_advisories,
            feature_preview=config.sbom.feature_preview,
        ),
        execution_id=config.execution_id,
        debug=bool(config.debug),
    )
