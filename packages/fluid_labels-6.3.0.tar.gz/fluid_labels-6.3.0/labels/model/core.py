from enum import Enum
from typing import TypedDict

from fluidattacks_core.models.scanners import (
    SbomAwsCredentials as FaCoreSbomAwsCredentials,
)
from fluidattacks_core.models.scanners import (
    SbomConfig as FaCoreSbomConfig,
)
from fluidattacks_core.models.scanners import (
    SbomDockerCredentials as FaCoreSbomDockerCredentials,
)
from fluidattacks_core.models.scanners import (
    SbomOutputConfig as FaCoreSbomOutputConfig,
)
from fluidattacks_core.models.scanners import (
    SbomPlatformOverrides as FaCoreSbomPlatformOverrides,
)
from fluidattacks_core.models.scanners import (
    ScanConfig as FaCoreScanConfig,
)
from fluidattacks_core.models.scanners import (
    SourceType as FaCoreSourceType,
)
from pydantic import Field

SbomAwsCredentials = FaCoreSbomAwsCredentials
SbomDockerCredentials = FaCoreSbomDockerCredentials
SbomOutputConfig = FaCoreSbomOutputConfig
SbomPlatformOverrides = FaCoreSbomPlatformOverrides
SourceType = FaCoreSourceType


class OutputFormat(Enum):
    FLUID_JSON = "fluid-json"
    CYCLONEDX_JSON = "cyclonedx-json"
    CYCLONEDX_XML = "cyclonedx-xml"
    SPDX_JSON = "spdx-json"
    SPDX_XML = "spdx-xml"

    @classmethod
    def from_string(cls: type["OutputFormat"], value: str) -> "OutputFormat":
        for member in cls:
            if member.value == value.lower():
                return member

        error_msg = f"{value} is not a valid {cls.__name__}"
        raise ValueError(error_msg)


class ScanArgs(TypedDict):
    source: str
    format: str
    output: str
    docker_user: str | None
    docker_password: str | None
    os: str | None
    arch: str | None
    aws_external_id: str | None
    aws_role: str | None
    aws_region: str | None
    feature_preview: bool
    debug: bool


class LabelsSbomSubConfig(FaCoreSbomConfig):
    include: list[str] = Field(default_factory=lambda: ["."])
    exclude: list[str] = Field(default_factory=list)
    include_package_metadata: bool = True
    include_package_advisories: bool = True
    feature_preview: bool = False


class SbomConfig(FaCoreScanConfig):
    debug: bool = False
    sbom: LabelsSbomSubConfig | None = None

    @property
    def source(self) -> str:
        return self.sbom.source if self.sbom and self.sbom.source is not None else ""

    @property
    def source_type(self) -> FaCoreSourceType:
        return (
            self.sbom.source_type
            if self.sbom and self.sbom.source_type is not None
            else FaCoreSourceType.DIRECTORY
        )

    @property
    def include(self) -> list[str]:
        return self.sbom.include if self.sbom else ["."]

    @property
    def exclude(self) -> list[str]:
        return self.sbom.exclude if self.sbom else []

    @property
    def docker_credentials(self) -> FaCoreSbomDockerCredentials | None:
        return self.sbom.docker_credentials if self.sbom else None

    @property
    def platform_overrides(self) -> FaCoreSbomPlatformOverrides | None:
        return self.sbom.platform_overrides if self.sbom else None

    @property
    def aws_credentials(self) -> FaCoreSbomAwsCredentials | None:
        return self.sbom.aws_credentials if self.sbom else None

    @property
    def include_package_metadata(self) -> bool:
        return self.sbom.include_package_metadata if self.sbom else True

    @property
    def include_package_advisories(self) -> bool:
        return self.sbom.include_package_advisories if self.sbom else True

    @property
    def feature_preview(self) -> bool:
        return self.sbom.feature_preview if self.sbom else False

    @property
    def output_name(self) -> str:
        if self.sbom is None or self.sbom.output is None:
            msg = "output not set"
            raise ValueError(msg)
        return self.sbom.output.name

    @property
    def output_format(self) -> OutputFormat:
        if self.sbom is None or self.sbom.output is None:
            msg = "output not set"
            raise ValueError(msg)
        return OutputFormat.from_string(self.sbom.output.format)

    @property
    def docker_user(self) -> str | None:
        return self.docker_credentials.username if self.docker_credentials else None

    @property
    def docker_password(self) -> str | None:
        return self.docker_credentials.password if self.docker_credentials else None

    @property
    def os_override(self) -> str | None:
        return self.platform_overrides.os_override if self.platform_overrides else None

    @property
    def arch_override(self) -> str | None:
        return self.platform_overrides.arch_override if self.platform_overrides else None

    @property
    def aws_role(self) -> str | None:
        return self.aws_credentials.role if self.aws_credentials else None

    @property
    def aws_external_id(self) -> str | None:
        return self.aws_credentials.external_id if self.aws_credentials else None

    @property
    def aws_region(self) -> str | None:
        return self.aws_credentials.region if self.aws_credentials else None
