# My Dash App

Install:

pip install prakhar-nft-app

Run:

prakhar-nft-app


1. from prakhar_nft_app import main
2. app = main.launch_app()
3. app.run()