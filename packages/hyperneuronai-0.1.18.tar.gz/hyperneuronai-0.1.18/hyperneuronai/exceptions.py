from __future__ import annotations

from typing import Optional


class HyperNeuronError(Exception):
    """Base exception for all HyperNeuron SDK errors."""


class APIError(HyperNeuronError):
    """Raised when the API returns an error response."""

    def __init__(self, message: str, status_code: int, body: Optional[dict] = None) -> None:
        super().__init__(message)
        self.status_code = status_code
        self.body = body or {}

    def __repr__(self) -> str:
        return f"{type(self).__name__}(status_code={self.status_code}, message={str(self)!r})"


class AuthenticationError(APIError):
    """401 — invalid or missing API key."""


class PermissionError(APIError):
    """403 — API key lacks permission for this resource."""


class NotFoundError(APIError):
    """404 — resource not found."""


class RateLimitError(APIError):
    """429 — rate limit exceeded."""


class ServiceUnavailableError(APIError):
    """503 — service temporarily unavailable (models loading, etc.)."""


class APIConnectionError(HyperNeuronError):
    """Network-level error (timeout, DNS failure, etc.)."""


def _raise_for_status(status_code: int, body: dict, raw: str) -> None:
    message = body.get("detail") or body.get("message") or raw or f"HTTP {status_code}"
    cls_map = {
        401: AuthenticationError,
        403: PermissionError,
        404: NotFoundError,
        429: RateLimitError,
        503: ServiceUnavailableError,
    }
    cls = cls_map.get(status_code, APIError)
    raise cls(message, status_code, body)
