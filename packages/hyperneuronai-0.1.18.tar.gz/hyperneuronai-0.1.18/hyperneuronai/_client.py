from __future__ import annotations

from typing import Any, Iterator, AsyncIterator, Optional
import warnings

import httpx

from hyperneuronai.exceptions import APIConnectionError, _raise_for_status

_DEFAULT_TIMEOUT = httpx.Timeout(connect=10.0, read=120.0, write=30.0, pool=10.0)
_DEFAULT_BASE_URL = "https://ai.hyperneuron.in"
_MAX_RESPONSE_BYTES = 64 * 1024 * 1024  # 64 MB hard cap on non-streaming responses


def _validate_base_url(url: str) -> None:
    if url.startswith("http://"):
        warnings.warn(
            "base_url uses plain HTTP — your API key will be sent unencrypted. "
            "Use HTTPS in production.",
            stacklevel=3,
        )


def _auth_headers(api_key: str) -> dict[str, str]:
    return {"Authorization": f"Bearer {api_key}"}


# ── Sync ──────────────────────────────────────────────────────────────────────


class SyncHTTPClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: Optional[httpx.Timeout] = None,
        http_client: Optional[httpx.Client] = None,
    ) -> None:
        _validate_base_url(base_url)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = http_client or httpx.Client(
            timeout=timeout or _DEFAULT_TIMEOUT,
            headers={"User-Agent": "hyperneuronai-python/0.1.0"},
        )

    def _url(self, path: str) -> str:
        return f"{self._base_url}{path}"

    def _headers(self, extra: Optional[dict] = None) -> dict[str, str]:
        h = _auth_headers(self._api_key)
        if extra:
            h.update(extra)
        return h

    def post(self, path: str, *, json_body: Any = None) -> dict:
        try:
            r = self._client.post(
                self._url(path),
                json=json_body,
                headers=self._headers({"Content-Type": "application/json"}),
            )
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc
        self._check(r)
        return r.json()

    def get(self, path: str) -> dict:
        try:
            r = self._client.get(self._url(path), headers=self._headers())
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc
        self._check(r)
        return r.json()

    def delete(self, path: str) -> dict:
        try:
            r = self._client.delete(self._url(path), headers=self._headers())
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc
        self._check(r)
        return r.json()

    def stream_bytes(self, path: str, *, json_body: Any = None) -> Iterator[bytes]:
        try:
            with self._client.stream(
                "POST",
                self._url(path),
                json=json_body,
                headers=self._headers({"Content-Type": "application/json"}),
            ) as r:
                self._check(r)
                yield from r.iter_bytes(chunk_size=4096)
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc

    def _check(self, r: httpx.Response) -> None:
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = {}
            # Truncate raw text to avoid leaking large server error pages.
            _raise_for_status(r.status_code, body, r.text[:300])

    def close(self) -> None:
        self._client.close()

    def __enter__(self) -> "SyncHTTPClient":
        return self

    def __repr__(self) -> str:
        return f"SyncHTTPClient(base_url={self._base_url!r}, api_key='***')"

    def __exit__(self, *_: Any) -> None:
        self.close()


# ── Async ─────────────────────────────────────────────────────────────────────


class AsyncHTTPClient:
    def __init__(
        self,
        api_key: str,
        base_url: str = _DEFAULT_BASE_URL,
        timeout: Optional[httpx.Timeout] = None,
        http_client: Optional[httpx.AsyncClient] = None,
    ) -> None:
        _validate_base_url(base_url)
        self._api_key = api_key
        self._base_url = base_url.rstrip("/")
        self._client = http_client or httpx.AsyncClient(
            timeout=timeout or _DEFAULT_TIMEOUT,
            headers={"User-Agent": "hyperneuronai-python/0.1.0"},
        )

    def _url(self, path: str) -> str:
        return f"{self._base_url}{path}"

    def _headers(self, extra: Optional[dict] = None) -> dict[str, str]:
        h = _auth_headers(self._api_key)
        if extra:
            h.update(extra)
        return h

    async def post(self, path: str, *, json_body: Any = None) -> dict:
        try:
            r = await self._client.post(
                self._url(path),
                json=json_body,
                headers=self._headers({"Content-Type": "application/json"}),
            )
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc
        self._check(r)
        return r.json()

    async def get(self, path: str) -> dict:
        try:
            r = await self._client.get(self._url(path), headers=self._headers())
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc
        self._check(r)
        return r.json()

    async def delete(self, path: str) -> dict:
        try:
            r = await self._client.delete(self._url(path), headers=self._headers())
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc
        self._check(r)
        return r.json()

    async def stream_bytes(self, path: str, *, json_body: Any = None) -> AsyncIterator[bytes]:
        try:
            async with self._client.stream(
                "POST",
                self._url(path),
                json=json_body,
                headers=self._headers({"Content-Type": "application/json"}),
            ) as r:
                self._check(r)
                async for chunk in r.aiter_bytes(chunk_size=4096):
                    yield chunk
        except httpx.RequestError as exc:
            raise APIConnectionError(str(exc)) from exc

    def _check(self, r: httpx.Response) -> None:
        if r.status_code >= 400:
            try:
                body = r.json()
            except Exception:
                body = {}
            _raise_for_status(r.status_code, body, r.text[:300])

    def __repr__(self) -> str:
        return f"AsyncHTTPClient(base_url={self._base_url!r}, api_key='***')"

    async def aclose(self) -> None:
        await self._client.aclose()

    async def __aenter__(self) -> "AsyncHTTPClient":
        return self

    async def __aexit__(self, *_: Any) -> None:
        await self.aclose()
