"""
hyperneuronai — Official Python SDK for HyperNeuron AI services.

Quick start (sync)::

    import hyperneuronai

    client = hyperneuronai.HyperNeuron(api_key="hn_key_xxxx")

    # TTS — save to file
    audio = client.tts.generate("Hello, world!", voice="sanjana")
    with open("hello.wav", "wb") as f:
        f.write(audio)

    # TTS — stream in real-time
    for chunk in client.tts.stream("Hello, world!", voice="sanjana"):
        your_speaker.write(chunk)

    # One-way outbound call
    call = client.telephony.outbound(
        to="+919876543210",
        text="Hi! Your order has shipped and arrives tomorrow.",
        voice="sanjana",
    )
    print(call.call_uuid)

Quick start (async)::

    import asyncio
    import hyperneuronai

    async def main():
        client = hyperneuronai.AsyncHyperNeuron(api_key="hn_key_xxxx")

        audio = await client.tts.generate("Hello!", voice="sanjana")

        async for chunk in client.tts.stream("Hello!"):
            await speaker.write(chunk)

        call = await client.telephony.outbound(
            to="+919876543210",
            text="Hi! Your order has shipped.",
        )

    asyncio.run(main())
"""

from hyperneuronai._hyperneuron import HyperNeuron, AsyncHyperNeuron
from hyperneuronai.exceptions import (
    HyperNeuronError,
    APIError,
    AuthenticationError,
    PermissionError,
    NotFoundError,
    RateLimitError,
    ServiceUnavailableError,
    APIConnectionError,
)
from hyperneuronai.types import (
    TTSRequest,
    TTSResponse,
    AudioFormat,
    Voice,
    OutboundCallRequest,
    CallResponse,
    CallStatus,
    CallState,
)

__version__ = "0.1.0"

__all__ = [
    # Clients
    "HyperNeuron",
    "AsyncHyperNeuron",
    # Exceptions
    "HyperNeuronError",
    "APIError",
    "AuthenticationError",
    "PermissionError",
    "NotFoundError",
    "RateLimitError",
    "ServiceUnavailableError",
    "APIConnectionError",
    # Types
    "TTSRequest",
    "TTSResponse",
    "AudioFormat",
    "Voice",
    "OutboundCallRequest",
    "CallResponse",
    "CallStatus",
    "CallState",
]
