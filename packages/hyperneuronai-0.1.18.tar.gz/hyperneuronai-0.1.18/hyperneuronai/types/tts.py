from __future__ import annotations

from typing import Literal, Optional
from pydantic import BaseModel, Field


Voice = Literal[
    "sanjana", "arjun", "priya", "rahul", "ananya",
    "leela", "dev", "kavya", "rohan", "meera",
]

AudioFormat = Literal["wav", "pcm_f32le", "pcm_s16le"]


class TTSRequest(BaseModel):
    text: str = Field(..., min_length=1, max_length=4096)
    voice: str = Field(default="sanjana")
    language: Optional[str] = Field(default=None, description="BCP-47 language tag, e.g. 'en', 'hi'. None = auto.")
    temperature: float = Field(default=0.65, ge=0.0, le=1.0)
    repetition_penalty: float = Field(default=1.1, ge=1.0, le=2.0)
    top_p: float = Field(default=0.95, ge=0.0, le=1.0)
    max_tokens: int = Field(default=2000, ge=7, le=4096)
    format: AudioFormat = Field(default="wav")
    sample_rate: int = Field(default=24000, ge=8000, le=48000, description="Output sample rate in Hz.")


class TTSResponse(BaseModel):
    audio: bytes = Field(..., description="Raw audio bytes in the requested format.")
    format: AudioFormat
    sample_rate: int
    duration_seconds: float
    voice: str
    text: str
