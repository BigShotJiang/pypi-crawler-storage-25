from __future__ import annotations

import re
from typing import Optional
from pydantic import BaseModel, ConfigDict, Field, field_validator


# Kept as str so unexpected server values don't raise ValidationError.
# Common values: "queued", "dialling", "ringing", "in_progress", "completed", "failed", "cancelled"
CallState = str

_E164_RE = re.compile(r"^\+[1-9]\d{6,14}$")


class OutboundCallRequest(BaseModel):
    """Request model for a one-way outbound call."""

    to_number: str = Field(..., description="E.164 phone number, e.g. '+919876543210'.")
    text: str = Field(..., min_length=1, max_length=4096, description="Message text to synthesize and deliver.")
    voice: str = Field(default="sanjana")
    language: str = Field(default="en", description="BCP-47 language code or 'auto'.")
    metadata: dict = Field(
        default_factory=dict,
        description="Arbitrary key/value pairs for your own tracking.",
    )

    @field_validator("to_number")
    @classmethod
    def _validate_e164(cls, v: str) -> str:
        if not _E164_RE.match(v):
            raise ValueError(
                f"Phone number must be in E.164 format (e.g. '+919876543210'), got {v!r}."
            )
        return v


class CallResponse(BaseModel):
    # Server sends "status"; SDK exposes it as "state" for consistency.
    model_config = ConfigDict(populate_by_name=True)

    call_uuid: str
    state: CallState = Field(alias="status")
    to_number: str
    sse_url: str


class CallStatus(BaseModel):
    model_config = ConfigDict(populate_by_name=True)

    call_uuid: str
    state: CallState = Field(alias="status")
    to_number: str
    duration_seconds: Optional[float] = None
    started_at: Optional[str] = None
    ended_at: Optional[str] = None
