from __future__ import annotations

import io
import struct
import wave
from typing import Iterator, AsyncIterator, Optional

from hyperneuronai._client import SyncHTTPClient, AsyncHTTPClient, _MAX_RESPONSE_BYTES
from hyperneuronai.exceptions import APIError
from hyperneuronai.types.tts import TTSRequest, TTSResponse, AudioFormat


def _make_wav_bytes(pcm_f32_bytes: bytes, sample_rate: int) -> bytes:
    """Convert raw float32-LE PCM bytes to a WAV file in memory."""
    n_samples = len(pcm_f32_bytes) // 4
    pcm_s16 = bytearray(n_samples * 2)
    for i in range(n_samples):
        sample_f32 = struct.unpack_from("<f", pcm_f32_bytes, i * 4)[0]
        sample_s16 = max(-32768, min(32767, int(sample_f32 * 32767)))
        struct.pack_into("<h", pcm_s16, i * 2, sample_s16)
    buf = io.BytesIO()
    with wave.open(buf, "wb") as wf:
        wf.setnchannels(1)
        wf.setsampwidth(2)
        wf.setframerate(sample_rate)
        wf.writeframes(bytes(pcm_s16))
    return buf.getvalue()


def _build_payload(request: TTSRequest) -> dict:
    return request.model_dump(exclude_none=True)


# ── Sync ──────────────────────────────────────────────────────────────────────


class TTS:
    """
    Synchronous TTS resource.

    Usage::

        audio_bytes = client.tts.generate("Hello world", voice="sanjana")
        with open("out.wav", "wb") as f:
            f.write(audio_bytes)

        for chunk in client.tts.stream("Hello world", voice="sanjana"):
            speaker.play(chunk)
    """

    def __init__(self, http: SyncHTTPClient) -> None:
        self._http = http

    def generate(
        self,
        text: str,
        *,
        voice: str = "sanjana",
        language: Optional[str] = None,
        temperature: float = 0.65,
        repetition_penalty: float = 1.1,
        top_p: float = 0.95,
        max_tokens: int = 2000,
        format: AudioFormat = "wav",
        sample_rate: int = 24000,
    ) -> bytes:
        """
        Generate speech and return the complete audio as bytes.

        Returns WAV bytes by default (``format="wav"``).
        Use ``format="pcm_f32le"`` or ``format="pcm_s16le"`` for raw PCM.
        """
        req = TTSRequest(
            text=text,
            voice=voice,
            language=language,
            temperature=temperature,
            repetition_penalty=repetition_penalty,
            top_p=top_p,
            max_tokens=max_tokens,
            format=format,
            sample_rate=sample_rate,
        )
        chunks: list[bytes] = []
        total = 0
        for chunk in self._http.stream_bytes("/tts/stream", json_body=_build_payload(req)):
            total += len(chunk)
            if total > _MAX_RESPONSE_BYTES:
                raise APIError(
                    f"TTS response exceeded {_MAX_RESPONSE_BYTES // (1024*1024)} MB limit.",
                    status_code=0,
                )
            chunks.append(chunk)
        raw = b"".join(chunks)
        if format == "wav" and not raw.startswith(b"RIFF"):
            raw = _make_wav_bytes(raw, sample_rate)
        return raw

    def stream(
        self,
        text: str,
        *,
        voice: str = "sanjana",
        language: Optional[str] = None,
        temperature: float = 0.65,
        repetition_penalty: float = 1.1,
        top_p: float = 0.95,
        max_tokens: int = 2000,
        sample_rate: int = 24000,
    ) -> Iterator[bytes]:
        """
        Stream speech audio chunks as they are generated.

        Yields raw PCM float32-LE bytes. First chunk typically arrives within 200 ms.
        Useful for real-time playback where you want minimal latency.
        """
        req = TTSRequest(
            text=text,
            voice=voice,
            language=language,
            temperature=temperature,
            repetition_penalty=repetition_penalty,
            top_p=top_p,
            max_tokens=max_tokens,
            format="pcm_f32le",
            sample_rate=sample_rate,
        )
        yield from self._http.stream_bytes("/tts/stream", json_body=_build_payload(req))

    def voices(self) -> list[dict]:
        """Return available voices and their metadata."""
        return self._http.get("/tts/voices")


# ── Async ─────────────────────────────────────────────────────────────────────


class AsyncTTS:
    """
    Async TTS resource.

    Usage::

        audio_bytes = await client.tts.generate("Hello world", voice="sanjana")

        async for chunk in client.tts.stream("Hello world", voice="sanjana"):
            await speaker.play(chunk)
    """

    def __init__(self, http: AsyncHTTPClient) -> None:
        self._http = http

    async def generate(
        self,
        text: str,
        *,
        voice: str = "sanjana",
        language: Optional[str] = None,
        temperature: float = 0.65,
        repetition_penalty: float = 1.1,
        top_p: float = 0.95,
        max_tokens: int = 2000,
        format: AudioFormat = "wav",
        sample_rate: int = 24000,
    ) -> bytes:
        """Generate speech and return the complete audio as bytes."""
        req = TTSRequest(
            text=text,
            voice=voice,
            language=language,
            temperature=temperature,
            repetition_penalty=repetition_penalty,
            top_p=top_p,
            max_tokens=max_tokens,
            format=format,
            sample_rate=sample_rate,
        )
        chunks: list[bytes] = []
        total = 0
        async for chunk in self._http.stream_bytes("/tts/stream", json_body=_build_payload(req)):
            total += len(chunk)
            if total > _MAX_RESPONSE_BYTES:
                raise APIError(
                    f"TTS response exceeded {_MAX_RESPONSE_BYTES // (1024*1024)} MB limit.",
                    status_code=0,
                )
            chunks.append(chunk)
        raw = b"".join(chunks)
        if format == "wav" and not raw.startswith(b"RIFF"):
            raw = _make_wav_bytes(raw, sample_rate)
        return raw

    async def stream(
        self,
        text: str,
        *,
        voice: str = "sanjana",
        language: Optional[str] = None,
        temperature: float = 0.65,
        repetition_penalty: float = 1.1,
        top_p: float = 0.95,
        max_tokens: int = 2000,
        sample_rate: int = 24000,
    ) -> AsyncIterator[bytes]:
        """Stream speech audio chunks as they are generated."""
        req = TTSRequest(
            text=text,
            voice=voice,
            language=language,
            temperature=temperature,
            repetition_penalty=repetition_penalty,
            top_p=top_p,
            max_tokens=max_tokens,
            format="pcm_f32le",
            sample_rate=sample_rate,
        )
        async for chunk in self._http.stream_bytes("/tts/stream", json_body=_build_payload(req)):
            yield chunk

    async def voices(self) -> list[dict]:
        """Return available voices and their metadata."""
        return await self._http.get("/tts/voices")
