# hyperneuronai

Official Python SDK for [HyperNeuron AI](https://www.hyperneuronai.com) — TTS streaming and AI telephony services.

## Install

```bash
pip install hyperneuronai
```

## Quick start

```python
import hyperneuronai

client = hyperneuronai.HyperNeuron(
    api_key="hn_key_xxxx",
    base_url="https://ai.hyperneuron.in",
)

# TTS — save to WAV
audio = client.tts.generate("Hello, world!", voice="sanjana")
with open("hello.wav", "wb") as f:
    f.write(audio)

# TTS — stream in real time
for chunk in client.tts.stream("Hello, world!", voice="sanjana"):
    your_speaker.write(chunk)

# One-way outbound call
call = client.telephony.outbound(
    to="+91<10digitIndianNumber>",
    text="Hi! Your order has shipped and arrives tomorrow.",
    voice="sanjana",
)
print(call.call_uuid, call.state)
```

## Async

```python
import asyncio
import hyperneuronai

async def main():
    async with hyperneuronai.AsyncHyperNeuron(api_key="hn_key_xxxx") as client:
        audio = await client.tts.generate("Hello!")
        call  = await client.telephony.outbound(to="+91<10digitIndianNumber>", text="Hi there!")

asyncio.run(main())
```

## License

MIT
