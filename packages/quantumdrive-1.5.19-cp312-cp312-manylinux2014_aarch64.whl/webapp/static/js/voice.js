/**
 * QuantumDrive Voice Module
 *
 * Toggle mode: click mic to start recording, click again to stop and transcribe.
 * Auto-speaks bot responses when enabled.
 */
(function () {
  "use strict";

  var CONFIG = {
    enabled: false,
    stt_provider: "openai",
    tts_provider: "openai",
    tts_voice: "sage",
    voice_mode: "toggle",
    auto_speak: true,
    stream_tts: true,
  };

  var state = "idle"; // idle | recording | processing | speaking
  var mediaRecorder = null;
  var audioChunks = [];
  var currentAudio = null;
  var ttsAbortController = null;
  var recordingStartTime = 0;

  var micBtn, speakerBtn, chatInput, chatForm, statusEl;
  var voicePickerBtn, voicePickerPopup, voiceOptionsList;

  // ── Init ──────────────────────────────────────────────────────────────

  async function init() {
    micBtn = document.getElementById("voice-mic-btn");
    speakerBtn = document.getElementById("voice-speaker-btn");
    chatInput = document.querySelector('textarea[name="task"]');
    chatForm = document.querySelector("form");
    statusEl = document.getElementById("voice-status");
    voicePickerBtn = document.getElementById("voice-picker-btn");
    voicePickerPopup = document.getElementById("voice-picker-popup");
    voiceOptionsList = document.getElementById("voice-options-list");

    if (!micBtn) return;

    try {
      var resp = await fetch("/api/voice/config");
      CONFIG = await resp.json();
    } catch (e) {
      hide(micBtn); hide(speakerBtn);
      return;
    }

    if (!CONFIG.enabled) {
      hide(micBtn); hide(speakerBtn);
      return;
    }

    // Mode indicator
    var modeEl = document.getElementById("voice-mode-indicator");
    if (modeEl) modeEl.textContent = { toggle: "Click to talk", push_to_talk: "Hold to talk", vad: "Auto-detect" }[CONFIG.voice_mode] || "";

    // Mic: toggle click
    micBtn.addEventListener("click", onMicClick);

    // Speaker toggle
    if (speakerBtn) {
      updateSpeakerBtn();
      speakerBtn.addEventListener("click", function () {
        CONFIG.auto_speak = !CONFIG.auto_speak;
        updateSpeakerBtn();
      });
    }

    // Voice picker — icon button with popup list
    var savedVoice = sessionStorage.getItem("qd_tts_voice");
    if (savedVoice) CONFIG.tts_voice = savedVoice;

    if (voicePickerBtn && voicePickerPopup && voiceOptionsList) {
      buildVoicePicker();
      voicePickerBtn.addEventListener("click", function (e) {
        e.stopPropagation();
        var open = voicePickerPopup.style.display !== "none";
        voicePickerPopup.style.display = open ? "none" : "block";
      });
      // Close popup when clicking outside
      document.addEventListener("click", function () {
        voicePickerPopup.style.display = "none";
      });
      voicePickerPopup.addEventListener("click", function (e) {
        e.stopPropagation();
      });
    }

    // Check mic availability
    if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
      micBtn.disabled = true;
      micBtn.title = "Microphone requires HTTPS or localhost";
      setStatus("Mic unavailable");
    }

    // Auto-speak last bot message (once per page load)
    hookAutoSpeak();
  }

  // ── Mic click handler ─────────────────────────────────────────────────

  async function onMicClick() {
    sessionStorage.setItem("qd_voice_interacted", "1");
    if (state === "recording") {
      doStop();
    } else if (state === "idle" || state === "speaking") {
      if (state === "speaking") stopPlayback();
      if (CONFIG.stt_provider === "browser") {
        doBrowserSTTDirect();
      } else {
        await doStart();
      }
    }
    // Ignore clicks during "processing"
  }

  var activeStream = null;
  var audioContext = null;
  var audioProcessor = null;
  var rawChunks = [];

  async function doStart() {
    stopPlayback();
    setState("processing");
    setStatus("Starting mic...");

    try {
      activeStream = await navigator.mediaDevices.getUserMedia({ audio: true });
      var tracks = activeStream.getAudioTracks();
      console.log("getUserMedia OK:", tracks.length, "track(s)",
        tracks.map(function(t) { return t.label + " muted=" + t.muted; }).join(", "));

      // Use Web Audio API to capture raw PCM — more reliable than MediaRecorder on some platforms
      audioContext = new (window.AudioContext || window.webkitAudioContext)({ sampleRate: 16000 });
      var source = audioContext.createMediaStreamSource(activeStream);

      rawChunks = [];
      // ScriptProcessorNode is deprecated but universally supported;
      // AudioWorklet requires a separate file and HTTPS
      audioProcessor = audioContext.createScriptProcessor(4096, 1, 1);
      audioProcessor.onaudioprocess = function (e) {
        var data = e.inputBuffer.getChannelData(0);
        rawChunks.push(new Float32Array(data));
      };
      source.connect(audioProcessor);
      audioProcessor.connect(audioContext.destination);

      recordingStartTime = Date.now();
      setState("recording");
      setStatus("Listening... click mic to stop");
    } catch (err) {
      console.error("doStart failed:", err);
      setStatus("Mic access denied");
      setState("idle");
    }
  }

  function doStop() {
    if (state !== "recording") return;

    // Stop browser speech recognition if active
    if (browserRecognition) {
      browserRecognition.stop();
      // onresult or onend will handle the rest
      return;
    }

    // Stop Web Audio recording
    if (audioProcessor) {
      audioProcessor.disconnect();
      audioProcessor = null;
    }
    if (audioContext) {
      audioContext.close().catch(function () {});
      audioContext = null;
    }
    if (activeStream) {
      activeStream.getTracks().forEach(function (t) { t.stop(); });
      activeStream = null;
    }

    onRecordingStopped();
  }

  function rawChunksToWavBlob() {
    // Merge all Float32Array chunks into one
    var totalLength = rawChunks.reduce(function (s, c) { return s + c.length; }, 0);
    var merged = new Float32Array(totalLength);
    var offset = 0;
    for (var i = 0; i < rawChunks.length; i++) {
      merged.set(rawChunks[i], offset);
      offset += rawChunks[i].length;
    }

    // Encode as 16-bit PCM WAV
    var sampleRate = 16000;
    var buffer = new ArrayBuffer(44 + merged.length * 2);
    var view = new DataView(buffer);
    // RIFF header
    writeStr(view, 0, "RIFF");
    view.setUint32(4, 36 + merged.length * 2, true);
    writeStr(view, 8, "WAVE");
    writeStr(view, 12, "fmt ");
    view.setUint32(16, 16, true);
    view.setUint16(20, 1, true); // PCM
    view.setUint16(22, 1, true); // mono
    view.setUint32(24, sampleRate, true);
    view.setUint32(28, sampleRate * 2, true);
    view.setUint16(32, 2, true);
    view.setUint16(34, 16, true);
    writeStr(view, 36, "data");
    view.setUint32(40, merged.length * 2, true);
    for (var j = 0; j < merged.length; j++) {
      var s = Math.max(-1, Math.min(1, merged[j]));
      view.setInt16(44 + j * 2, s < 0 ? s * 0x8000 : s * 0x7FFF, true);
    }
    return new Blob([buffer], { type: "audio/wav" });
  }

  function writeStr(view, offset, string) {
    for (var i = 0; i < string.length; i++) {
      view.setUint8(offset + i, string.charCodeAt(i));
    }
  }

  async function onRecordingStopped() {
    var elapsed = Date.now() - recordingStartTime;

    console.log("Recording stopped: elapsed=" + elapsed + "ms, rawChunks=" + rawChunks.length);

    if (rawChunks.length === 0 || elapsed < 400) {
      setStatus("Too short — speak longer");
      setState("idle");
      return;
    }

    setState("processing");
    setStatus("Transcribing...");

    if (CONFIG.stt_provider === "browser") {
      doBrowserSTT();
      return;
    }

    var blob = rawChunksToWavBlob();
    console.log("WAV blob: " + blob.size + " bytes (" + (elapsed / 1000).toFixed(1) + "s of audio)");

    try {
      var fd = new FormData();
      fd.append("audio", blob, "recording.wav");
      var resp = await fetch("/api/voice/transcribe", { method: "POST", body: fd });
      var data = await resp.json();
      console.log("Transcription result:", data);

      if (data.ok && data.text && data.text.trim()) {
        chatInput.value = data.text;
        chatForm.requestSubmit ? chatForm.requestSubmit() : chatForm.submit();
      } else {
        setStatus("Could not understand — try again");
        setState("idle");
      }
    } catch (err) {
      setStatus("Transcription error");
      setState("idle");
    }
  }

  var browserRecognition = null;

  var sttFailCount = 0;

  function doBrowserSTTDirect() {
    var SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) {
      setStatus("Speech recognition not available — type your message instead");
      setState("idle");
      focusChatInput();
      return;
    }

    browserRecognition = new SR();
    browserRecognition.lang = "en-US";
    browserRecognition.interimResults = false;
    browserRecognition.continuous = true;

    browserRecognition.onstart = function () {
      setState("recording");
      setStatus("Listening... speak then click mic to stop");
    };
    browserRecognition.onresult = function (e) {
      // Collect all final results
      var transcript = "";
      for (var i = 0; i < e.results.length; i++) {
        if (e.results[i].isFinal) {
          transcript += e.results[i][0].transcript;
        }
      }
      console.log("Browser STT result:", transcript);
      if (transcript && transcript.trim()) {
        sttFailCount = 0;
        browserRecognition.stop();
        browserRecognition = null;
        setState("processing");
        setStatus("Submitting...");
        chatInput.value = transcript.trim();
        chatForm.requestSubmit ? chatForm.requestSubmit() : chatForm.submit();
      }
    };
    browserRecognition.onerror = function (e) {
      console.error("Browser STT error:", e.error);
      browserRecognition = null;
      sttFailCount++;

      if (e.error === "no-speech" || e.error === "audio-capture" || e.error === "not-allowed") {
        if (sttFailCount >= 2) {
          setStatus("Microphone not available in this environment — type your message instead");
          micBtn.disabled = true;
          micBtn.title = "Voice input unavailable — use the text box";
        } else {
          setStatus("No speech detected — try again, or type your message");
        }
      } else {
        setStatus("Speech error: " + e.error);
      }
      setState("idle");
      focusChatInput();
    };
    browserRecognition.onend = function () {
      if (state === "recording") {
        // Recognition ended without a result (user clicked stop before speaking)
        setStatus("No speech captured — type your message or try again");
        setState("idle");
        focusChatInput();
      }
      browserRecognition = null;
    };

    setState("processing");
    setStatus("Starting speech recognition...");
    browserRecognition.start();
  }

  function doBrowserSTT() {
    doBrowserSTTDirect();
  }

  function focusChatInput() {
    if (chatInput) {
      chatInput.focus();
      chatInput.placeholder = "Type your message here...";
    }
  }

  // ── Voice picker ──────────────────────────────────────────────────────

  var VOICES = [
    { id: "sage", label: "Sage", desc: "Warm, confident" },
    { id: "nova", label: "Nova", desc: "Energetic, bright" },
    { id: "alloy", label: "Alloy", desc: "Balanced, neutral" },
    { id: "echo", label: "Echo", desc: "Smooth, measured" },
    { id: "fable", label: "Fable", desc: "Expressive, British" },
    { id: "onyx", label: "Onyx", desc: "Deep, authoritative" },
    { id: "shimmer", label: "Shimmer", desc: "Light, clear" },
    { id: "ash", label: "Ash", desc: "Calm, composed" },
    { id: "ballad", label: "Ballad", desc: "Soft, gentle" },
    { id: "coral", label: "Coral", desc: "Clear, professional" },
  ];

  function buildVoicePicker() {
    if (!voiceOptionsList) return;
    voiceOptionsList.innerHTML = VOICES.map(function (v) {
      var active = v.id === CONFIG.tts_voice ? " active" : "";
      return '<button type="button" class="voice-option' + active + '" data-voice="' + v.id + '">' +
        v.label + ' <small class="text-muted">— ' + v.desc + '</small></button>';
    }).join("");

    voiceOptionsList.addEventListener("click", function (e) {
      var btn = e.target.closest(".voice-option");
      if (!btn) return;
      var voice = btn.dataset.voice;
      CONFIG.tts_voice = voice;
      sessionStorage.setItem("qd_tts_voice", voice);
      // Update active state
      voiceOptionsList.querySelectorAll(".voice-option").forEach(function (b) {
        b.classList.toggle("active", b.dataset.voice === voice);
      });
      // Close popup
      voicePickerPopup.style.display = "none";
    });
  }

  // ── TTS playback ──────────────────────────────────────────────────────

  async function speakText(text) {
    if (!text || !CONFIG.auto_speak) return;

    if (CONFIG.tts_provider === "browser") {
      speakBrowser(text); return;
    }

    setState("speaking");
    ttsAbortController = new AbortController();

    var endpoint = CONFIG.stream_tts ? "/api/voice/synthesize-stream" : "/api/voice/synthesize";
    var body = { text: text };
    // Pass the selected voice
    if (CONFIG.tts_voice) body.voice = CONFIG.tts_voice;

    try {
      var resp = await fetch(endpoint, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body),
        signal: ttsAbortController.signal,
      });
      if (resp.headers.get("X-TTS-Provider") === "browser") { speakBrowser(text); return; }
      if (!resp.ok) { setState("idle"); return; }

      var blob = await resp.blob();
      var url = URL.createObjectURL(blob);
      currentAudio = new Audio(url);
      currentAudio.onended = function () { URL.revokeObjectURL(url); setState("idle"); };
      currentAudio.onerror = function () { URL.revokeObjectURL(url); setState("idle"); };
      currentAudio.play().catch(function () {
        // Browser blocked autoplay — user hasn't interacted with the page yet
        URL.revokeObjectURL(url);
        setState("idle");
      });
    } catch (err) {
      if (err.name !== "AbortError") setState("idle");
    }
  }

  function speakBrowser(text) {
    if (!window.speechSynthesis) return;
    window.speechSynthesis.cancel();
    var u = new SpeechSynthesisUtterance(text);
    u.lang = "en-US";
    u.onstart = function () { setState("speaking"); };
    u.onend = function () { setState("idle"); };
    u.onerror = function () { setState("idle"); };
    window.speechSynthesis.speak(u);
  }

  function stopPlayback() {
    if (currentAudio) { currentAudio.pause(); currentAudio.src = ""; currentAudio = null; }
    if (ttsAbortController) { ttsAbortController.abort(); ttsAbortController = null; }
    if (window.speechSynthesis) window.speechSynthesis.cancel();
  }

  // ── Auto-speak on page load ───────────────────────────────────────────

  function hookAutoSpeak() {
    if (!CONFIG.auto_speak) return;
    // Chrome blocks audio.play() until the user has interacted with the page.
    // Only auto-speak if we know the user has interacted (they submitted a form,
    // which means sessionStorage has a marker from a prior interaction).
    if (!sessionStorage.getItem("qd_voice_interacted")) return;

    var bots = document.querySelectorAll(".chat-bubble.bot");
    if (!bots.length) return;

    var last = bots[bots.length - 1];
    var text = last.textContent.trim();
    if (!text) return;

    var key = "voice_spoken_" + bots.length + "_" + text.length;
    if (sessionStorage.getItem(key)) return;
    sessionStorage.setItem(key, "1");

    setTimeout(function () { speakText(text); }, 300);
  }

  // ── State & UI ────────────────────────────────────────────────────────

  function setState(s) {
    state = s;
    if (!micBtn) return;

    micBtn.className = "btn btn-outline-secondary voice-" + s;

    if (s === "recording") {
      micBtn.innerHTML = SVG_MIC_ACTIVE;
      micBtn.title = "Recording — click to stop";
    } else if (s === "processing") {
      micBtn.innerHTML = SVG_SPINNER;
      micBtn.title = "Processing...";
    } else if (s === "speaking") {
      micBtn.innerHTML = SVG_MIC;
      micBtn.title = "Speaking — click to interrupt";
    } else {
      micBtn.innerHTML = SVG_MIC;
      micBtn.title = "Click to start recording";
    }
  }

  function setStatus(msg) {
    if (statusEl) statusEl.textContent = msg || "";
    if (msg) setTimeout(function () {
      if (statusEl && statusEl.textContent === msg) statusEl.textContent = "";
    }, 5000);
  }

  function updateSpeakerBtn() {
    if (!speakerBtn) return;
    speakerBtn.innerHTML = CONFIG.auto_speak ? SVG_SPEAKER_ON : SVG_SPEAKER_OFF;
    speakerBtn.title = CONFIG.auto_speak ? "Auto-speak on" : "Auto-speak off";
    speakerBtn.className = "btn " + (CONFIG.auto_speak ? "btn-outline-primary" : "btn-outline-secondary");
  }

  function hide(el) { if (el) el.style.display = "none"; }

  // ── SVG icons ─────────────────────────────────────────────────────────

  var SVG_MIC = '<svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>';

  var SVG_MIC_ACTIVE = '<svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 1a3 3 0 0 0-3 3v8a3 3 0 0 0 6 0V4a3 3 0 0 0-3-3z"/><path d="M19 10v2a7 7 0 0 1-14 0v-2"/><line x1="12" y1="19" x2="12" y2="23"/><line x1="8" y1="23" x2="16" y2="23"/></svg>';

  var SVG_SPINNER = '<span class="spinner-border spinner-border-sm" role="status"></span>';

  var SVG_SPEAKER_ON = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><path d="M19.07 4.93a10 10 0 0 1 0 14.14"/><path d="M15.54 8.46a5 5 0 0 1 0 7.07"/></svg>';

  var SVG_SPEAKER_OFF = '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"/><line x1="23" y1="9" x2="17" y2="15"/><line x1="17" y1="9" x2="23" y2="15"/></svg>';

  // ── Boot ──────────────────────────────────────────────────────────────
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", init);
  else init();
})();
