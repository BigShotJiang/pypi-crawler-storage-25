/**
 * QuantumDrive shared studio helpers.
 *
 * Exposes a tiny global ``QDStudio`` namespace used by studio-style pages
 * (presentation, video, etc.) to keep empty/running/success/failed state
 * transitions and user-facing feedback consistent across workflows.
 *
 * Usage::
 *
 *     // State transitions (container holds .studio-state-{empty,running,success,failed})
 *     QDStudio.showState(container, 'running');
 *
 *     // Global toast
 *     QDStudio.toast({ message: 'Saved', level: 'success' });
 */
(function () {
  'use strict';

  var STATES = ['empty', 'running', 'success', 'failed'];

  function showState(container, stateName) {
    if (!container) return;
    STATES.forEach(function (s) {
      var el = container.querySelector('.studio-state-' + s);
      if (!el) return;
      el.classList.toggle('is-active', s === stateName);
    });
  }

  function ensureToastContainer() {
    var c = document.getElementById('qd-toast-container');
    if (c) return c;
    c = document.createElement('div');
    c.id = 'qd-toast-container';
    document.body.appendChild(c);
    return c;
  }

  var VALID_LEVELS = { info: 1, success: 1, warning: 1, danger: 1 };

  function toast(options) {
    options = options || {};
    var message = options.message || '';
    var level = VALID_LEVELS[options.level] ? options.level : 'info';
    var duration = typeof options.duration === 'number' ? options.duration : 4000;
    if (!message) return;

    var c = ensureToastContainer();
    var el = document.createElement('div');
    el.className = 'qd-toast ' + level;
    el.setAttribute('role', level === 'danger' ? 'alert' : 'status');
    el.textContent = message;
    c.appendChild(el);

    var timer = setTimeout(function () {
      el.classList.add('is-leaving');
      setTimeout(function () { el.remove(); }, 250);
    }, duration);

    el.addEventListener('click', function () {
      clearTimeout(timer);
      el.remove();
    });
  }

  // Format an elapsed millisecond count into a short human string.
  function formatElapsed(ms) {
    var s = Math.max(0, Math.floor((ms || 0) / 1000));
    if (s < 60) return s + 's';
    var m = Math.floor(s / 60);
    return m + 'm ' + (s % 60) + 's';
  }

  window.QDStudio = {
    showState: showState,
    toast: toast,
    formatElapsed: formatElapsed,
  };
})();
