"""WhitePaper generation capability.

Mirrors the layout of :mod:`capabilities.presentation` and
:mod:`capabilities.threat_mitigation`:

- :mod:`models` — Pydantic request/result/template/job models.
- :mod:`template_store` — Neptune-backed template persistence under the
  ``quantumdrive/whitepaper`` namespace.
- :mod:`reference_store` — Milvus-backed reference document chunk index
  (one logical bucket per upload, filtered by ``whitepaper_ref_id``).
- :mod:`q_whitepaper_planner` — Per-template structured-output outline.
- :mod:`q_whitepaper_writer` — Sequential section drafter with retrieval.
- :mod:`q_whitepaper_renderer` — ``.docx`` + ``.md`` emitter.
- :mod:`job_store` — Thread-safe JSONL-backed job registry with progress.
- :mod:`q_whitepaper_service` — Façade tying everything together.
"""

from __future__ import annotations
