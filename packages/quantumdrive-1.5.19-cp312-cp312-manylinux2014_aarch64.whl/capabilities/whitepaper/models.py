"""Pydantic models for the WhitePaper generation subsystem."""

from __future__ import annotations

from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field


# ── Enumerations ──────────────────────────────────────────────────────────────

class JobStatus(str, Enum):
    QUEUED      = "queued"
    PLANNING    = "planning"
    WRITING     = "writing"
    RENDERING   = "rendering"
    COMPLETED   = "completed"
    FAILED      = "failed"
    INTERRUPTED = "interrupted"


class OutputFormat(str, Enum):
    DOCX = "docx"
    MARKDOWN = "md"


# ── Template models ───────────────────────────────────────────────────────────

class WhitePaperSection(BaseModel):
    """One section of a WhitePaper template."""

    section_id: str
    """URL-safe stable id (e.g. 'innovativeness_uniqueness')."""

    name: str
    """Human-readable section heading."""

    guidance: str = ""
    """Author-facing guidance: what the section should cover."""

    evaluation_criteria: str = ""
    """Evaluator-facing criteria from the RFI/RFP. Surfaces in the LLM
    system prompt and is rendered as a footnote in the final document."""

    max_words: Optional[int] = None
    """Soft word cap fed into the LLM prompt; falls back to
    ``WhitePaperConfig.section_max_words`` when None."""


class WhitePaperTemplate(BaseModel):
    """A reusable WhitePaper template (sections + rubric)."""

    template_id: str
    name: str
    description: str = ""
    sections: List[WhitePaperSection] = Field(default_factory=list)
    rubric: str = ""
    """Free-text appendix rendered after the body — typically the full
    grading rubric pasted from the solicitation."""

    is_seed: bool = False
    """True for seed templates shipped with QuantumDrive."""

    created_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )
    updated_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ── Reference document models ─────────────────────────────────────────────────

class ReferenceDocument(BaseModel):
    """Metadata for one uploaded reference / criteria document."""

    ref_id: str
    """Stable id used as a metadata tag in Milvus."""

    filename: str
    content_type: str = "text/plain"
    chunk_count: int = 0
    char_count: int = 0
    uploaded_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


class KnowledgeBaseDocument(BaseModel):
    """Metadata for one persistent WhitePaper knowledge-base document.

    Distinct from :class:`ReferenceDocument`: KB docs are a long-lived
    corpus available across all whitepaper jobs and are mirrored into
    both the Vector Store and the Knowledge Graph.
    """

    doc_id: str
    """Stable id; tags every chunk in Milvus and is the entity_id in the KG."""

    filename: str
    content_type: str = "text/plain"
    chunk_count: int = 0
    char_count: int = 0
    uploaded_at: str = Field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )


# ── Generation request / result ───────────────────────────────────────────────

class WhitePaperRequest(BaseModel):
    """Inbound request describing the WhitePaper to generate."""

    title: str
    subtitle: Optional[str] = None
    template_id: str
    """ID of the :class:`WhitePaperTemplate` to use."""

    brief: str = ""
    """Free-text brief from the user — the topic and any positioning."""

    reference_ids: List[str] = Field(default_factory=list)
    """``ReferenceDocument.ref_id`` values to consult during writing."""

    audience: str = "evaluators"
    author: str = "QuantumDrive"
    company: str = "AlphaSix"
    output_basename: Optional[str] = None
    formats: List[OutputFormat] = Field(
        default_factory=lambda: [OutputFormat.DOCX, OutputFormat.MARKDOWN]
    )
    project_id: Optional[str] = None
    repo_id: Optional[str] = None
    metadata: Dict[str, Any] = Field(default_factory=dict)

    def normalized_basename(self) -> str:
        raw = self.output_basename or self.title or self.template_id
        parts = [
            seg
            for seg in "".join(c if c.isalnum() else "_" for c in raw).split("_")
            if seg
        ]
        return "_".join(parts[:12]) or "whitepaper"


class WhitePaperSectionDraft(BaseModel):
    """LLM-produced draft for a single section."""

    section_id: str
    name: str
    body_markdown: str
    citations: List[str] = Field(default_factory=list)
    """``ReferenceDocument.ref_id`` values the LLM said it relied on."""


class SectionOutline(BaseModel):
    """One per-section outline entry on a :class:`WhitePaperPlan`.

    Modeled as an explicit list-of-objects (rather than a
    ``Dict[str, str]``) so the schema is compatible with OpenAI's strict
    structured-output mode, which forbids open-ended dicts
    (``additionalProperties: <schema>``). ``extra="forbid"`` is also
    required by strict mode — it generates ``additionalProperties:
    false`` on the object schema, which OpenAI rejects requests without.
    """

    model_config = ConfigDict(extra="forbid")

    section_id: str
    outline: str


class WhitePaperPlan(BaseModel):
    """Structured plan returned by the LLM before writing."""

    model_config = ConfigDict(extra="forbid")

    title: str
    summary: str
    section_outlines: List[SectionOutline]
    """Per-section outlines keyed by ``section_id`` via :meth:`outline_for`.

    Required (no default) so OpenAI's strict structured-output mode —
    which demands every key in ``properties`` also appear in
    ``required`` — accepts the schema. Callers must always supply this;
    the planner's deterministic fallback does, and the LLM is instructed
    to fill it for every section."""

    def outline_for(self, section_id: str) -> str:
        """Return the outline string for ``section_id`` (empty when unset)."""
        for entry in self.section_outlines:
            if entry.section_id == section_id:
                return entry.outline
        return ""


class WhitePaperResult(BaseModel):
    """Generation outcome — surfaced on the job and over the wire."""

    ok: bool
    summary: str = ""
    docx_filename: Optional[str] = None
    md_filename: Optional[str] = None
    section_count: int = 0
    word_count: int = 0
    warnings: List[str] = Field(default_factory=list)
    errors: List[str] = Field(default_factory=list)


# ── Job models ────────────────────────────────────────────────────────────────

class SectionProgress(BaseModel):
    """Per-section progress state, surfaced to the UI for a progress bar."""

    section_id: str
    name: str
    status: str = "pending"
    """One of: pending | running | completed | failed."""

    word_count: int = 0
    error: Optional[str] = None


class WhitePaperJob(BaseModel):
    """Runtime state of a WhitePaper generation job."""

    job_id: str
    request: WhitePaperRequest
    status: JobStatus = JobStatus.QUEUED
    progress: List[SectionProgress] = Field(default_factory=list)
    result: Optional[WhitePaperResult] = None
    started_at: Optional[str] = None
    finished_at: Optional[str] = None
    error: Optional[str] = None

    def overall_progress(self) -> float:
        """Fraction of completed sections in [0.0, 1.0]."""
        if not self.progress:
            return 0.0
        done = sum(1 for p in self.progress if p.status == "completed")
        return done / len(self.progress)
