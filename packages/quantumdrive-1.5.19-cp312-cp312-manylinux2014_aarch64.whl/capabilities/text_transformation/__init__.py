"""QuantumDrive text-transformation capability.

Generic LLM-driven text-polish utilities:

* :func:`humanize` — rewrite AI-generated prose to sound more naturally
  human-written, with a configurable style.
* :func:`apply_elements_of_style` — revise text using Strunk & White's
  *Elements of Style* principles (clear, vigorous prose).

These used to live as methods on :class:`core.ai.q_assistant.QAssistant`.
They are now plain functions that take a QAssistant as their first argument
so any capability or webapp endpoint can invoke them without reaching back
into core for text-polish behaviour.
"""

from __future__ import annotations

import logging
import time
from typing import TYPE_CHECKING, Optional

if TYPE_CHECKING:  # pragma: no cover - typing only
    from agentfoundry.cancellation import CancellationToken
    from core.ai.q_assistant import QAssistant


_VALID_HUMANIZE_STYLES = frozenset({"professional", "conversational", "casual"})


def humanize(
    assistant: "QAssistant",
    text: str,
    style: str = "professional",
    cancel_token: "Optional[CancellationToken]" = None,
) -> str:
    """Rewrite AI-generated text to sound more naturally human-written.

    Raises ``ValueError`` for empty text or an invalid style. Uses the
    formatter LLM (``model_role="formatting"``) with no tools or memory.
    """
    logger = assistant.logger
    if not text or not text.strip():
        logger.warning("humanize called with empty text")
        raise ValueError("Cannot humanize empty text.")

    style = style.strip().lower() if isinstance(style, str) else "professional"
    if style not in _VALID_HUMANIZE_STYLES:
        logger.warning("humanize called with invalid style=%r", style)
        raise ValueError(
            f"Invalid style {style!r}. Choose from: {', '.join(sorted(_VALID_HUMANIZE_STYLES))}"
        )

    from core.ai.prompts import PromptPartials

    prompt = (
        "You are an expert editor and writer who transforms AI-generated "
        "text into natural, human-sounding prose.\n\n"
        f"{PromptPartials.HUMANIZE}\n\n"
        f"Style: {style}\n\n"
        f"Text to humanize:\n\n{text}"
    )

    logger.info(
        "Humanizing text (style=%s, input_len=%d, user_id=%s, org_id=%s)",
        style, len(text), assistant.user_id, assistant.org_id,
    )
    logger.debug("humanize prompt_len=%d, model_role=formatting", len(prompt))

    _t0 = time.perf_counter()
    try:
        result = assistant.run_task(
            prompt,
            use_memory=False,
            allow_tools=False,
            model_role="formatting",
            cancel_token=cancel_token,
        )
    except Exception:
        elapsed = time.perf_counter() - _t0
        logger.exception(
            "Humanize failed after %.3f s (style=%s, input_len=%d)",
            elapsed, style, len(text),
        )
        raise

    reply = result[0] if isinstance(result, tuple) else result
    elapsed = time.perf_counter() - _t0
    logger.info("Humanize complete (output_len=%d, elapsed=%.3f s)", len(str(reply)), elapsed)
    return reply


def apply_elements_of_style(
    assistant: "QAssistant",
    text: str,
    cancel_token: "Optional[CancellationToken]" = None,
) -> str:
    """Revise text using Strunk & White's *Elements of Style* principles.

    Raises ``ValueError`` for empty text. Uses the formatter LLM with no
    tools or memory.
    """
    logger = assistant.logger
    if not text or not text.strip():
        logger.warning("apply_elements_of_style called with empty text")
        raise ValueError("Cannot revise empty text.")

    from core.ai.prompts import PromptPartials

    prompt = (
        "You are an expert copyeditor who applies the principles of "
        "Strunk & White's Elements of Style to produce vigorous, clear prose.\n\n"
        f"{PromptPartials.ELEMENTS_OF_STYLE}\n\n"
        f"Text to revise:\n\n{text}"
    )

    logger.info(
        "Applying Elements of Style (input_len=%d, user_id=%s, org_id=%s)",
        len(text), assistant.user_id, assistant.org_id,
    )
    logger.debug("elements_of_style prompt_len=%d, model_role=formatting", len(prompt))

    _t0 = time.perf_counter()
    try:
        result = assistant.run_task(
            prompt,
            use_memory=False,
            allow_tools=False,
            model_role="formatting",
            cancel_token=cancel_token,
        )
    except Exception:
        elapsed = time.perf_counter() - _t0
        logger.exception(
            "Elements of Style revision failed after %.3f s (input_len=%d)",
            elapsed, len(text),
        )
        raise

    reply = result[0] if isinstance(result, tuple) else result
    elapsed = time.perf_counter() - _t0
    logger.info(
        "Elements of Style revision complete (output_len=%d, elapsed=%.3f s)",
        len(str(reply)), elapsed,
    )
    return reply


__all__ = ["humanize", "apply_elements_of_style"]
