"""Development capability package for QuantumDrive."""

from __future__ import annotations

from core.ai.capability_agent import CapabilityAgent

from capabilities.development.architecture_verifier import ArchitectureVerifier
from capabilities.development.q_cross_project_insight_service import (
    CrossProjectInsightConfig,
    CrossProjectInsightMatch,
    CrossProjectReferenceRecord,
    QCrossProjectInsightService,
    get_q_cross_project_insight_service,
)
from capabilities.development.q_memory_router import (
    PromotionDecision,
    QMemoryRouter,
    WavePromotionInput,
)
from capabilities.development.q_reuse_validation_service import (
    QReuseValidationService,
    ReuseValidationCheck,
    ReuseValidationResult,
    get_q_reuse_validation_service,
)
from capabilities.development.q_development_service import (
    QDevelopmentService,
    get_q_development_service,
)


def _register_development_tools(assistant, service: QDevelopmentService) -> None:
    """Register the dev capability's tools on the assistant's tool_registry.

    Adds code-graph search, CI/CD tools, and the five new dev-specific
    tools (architecture_verifier, security_scan, pytest_run,
    cross_project_reference_search, reuse_validation).
    """
    tool_registry = getattr(assistant, "tool_registry", None)
    logger = getattr(assistant, "logger", None)
    if tool_registry is None:
        return

    if service.code_graph_tool is not None:
        try:
            tool_registry.register_tool(service.code_graph_tool.as_tool())
        except Exception as exc:  # pragma: no cover - defensive
            if logger:
                logger.warning("Code graph tool registration failed: %s", exc)

    try:
        from core.integrations.tools.api_contract_diff_tool import ApiContractDiffTool
        from core.integrations.tools.cicd_tools import DeploymentManifestTool, PipelineTriggerTool
        tool_registry.register_tool(ApiContractDiffTool.create_tool())
        tool_registry.register_tool(DeploymentManifestTool.create_tool())
        tool_registry.register_tool(PipelineTriggerTool.create_tool())
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Enterprise delivery tool registration failed: %s", exc)

    # Five dev-specific tool wrappers.
    try:
        from capabilities.development.tools import (
            ArchitectureVerifierTool,
            SecurityScanTool,
            PytestRunTool,
            CrossProjectReferenceSearchTool,
            ReuseValidationTool,
        )
        tool_registry.register_tool(ArchitectureVerifierTool.create_tool())
        tool_registry.register_tool(SecurityScanTool.create_tool())
        tool_registry.register_tool(PytestRunTool.create_tool())
        if service.cross_project_insight_service is not None:
            tool_registry.register_tool(
                CrossProjectReferenceSearchTool.create_tool(
                    service=service.cross_project_insight_service,
                    org_id_provider=lambda: assistant.org_id,
                )
            )
        if service.reuse_validation_service is not None:
            tool_registry.register_tool(
                ReuseValidationTool.create_tool(
                    service=service.reuse_validation_service,
                    org_id_provider=lambda: assistant.org_id,
                )
            )
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Development tool-wrapper registration failed: %s", exc)


# Shared tool bundles used by multiple dev agents.
_MEMORY_READ_WRITE_TOOLS = (
    "save_thread_memory", "search_thread_memory",
    "save_user_memory", "search_user_memory",
    "search_org_memory", "summarize_any_memory",
)
_MEMORY_READ_ONLY_TOOLS = (
    "search_thread_memory", "search_user_memory", "search_org_memory", "summarize_any_memory",
)


def _register_development_agents(assistant) -> None:
    """Register the ten development-family capability agents.

    Role IDs deliberately match AgentFoundry's specialist-class registry
    (``_ROLE_AGENT_MAP``) so the HierarchicalOrchestrator routes to the
    correct specialist implementation, scoped by the RolePolicy we install
    via QAssistant's ``_apply_capability_role_policies``.
    """
    register = assistant.register_capability_agent

    register(CapabilityAgent(
        role_id="requirements",
        summary="Ingest requirements docs / solicitations; extract user stories and acceptance criteria.",
        system_prompt=(
            "You are the Requirements specialist. Extract, organize, and cite requirements "
            "from the provided documents. Return structured findings with traceable source references."
        ),
        tool_names=(
            "document_reader", "unzip_tool", "pdf_creator",
            "rest_api_tool", "web_search_tool",
            "system_introspection", "current_date_time_tool",
        ) + _MEMORY_READ_ONLY_TOOLS,
        request_types=(),
        keywords=("requirements", "user stories", "acceptance criteria", "solicitation"),
    ))

    register(CapabilityAgent(
        role_id="architecture",
        summary="Propose and validate architecture; check cross-boundary imports; draft ADRs.",
        system_prompt=(
            "You are the Architecture specialist. Design, validate, and document system "
            "architecture. Use the architecture_verifier tool to enforce boundary rules."
        ),
        tool_names=(
            "code_graph_search", "architecture_verifier",
            "document_reader", "pdf_creator",
            "system_introspection",
        ) + _MEMORY_READ_ONLY_TOOLS,
        request_types=(),
        keywords=("architecture", "boundary", "adr", "component design"),
    ))

    register(CapabilityAgent(
        role_id="backend",
        summary="Backend implementation — services, data models, APIs.",
        system_prompt=(
            "You are the Backend specialist. Implement service-side features, APIs, and "
            "data layers. Reference the code graph before making structural changes."
        ),
        tool_names=(
            "code_graph_search", "document_reader",
            "gitlab_read_api", "gitlab_merge_request_api",
            "http_request_tool", "rest_api_tool",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=(),
        approval_actions=("write",),
        keywords=("backend", "api", "service", "data model", "migration"),
    ))

    register(CapabilityAgent(
        role_id="frontend",
        summary="Frontend implementation — UI components, pages, client state.",
        system_prompt=(
            "You are the Frontend specialist. Implement UI components and client-side "
            "behavior. Align with existing patterns in the code graph."
        ),
        tool_names=(
            "code_graph_search", "document_reader",
            "gitlab_read_api", "gitlab_merge_request_api",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=(),
        approval_actions=("write",),
        keywords=("frontend", "ui", "component", "page", "client state"),
    ))

    register(CapabilityAgent(
        role_id="code_review",
        summary="PR review; flag style / correctness / security issues; produce review comments.",
        system_prompt=(
            "You are the Code Review specialist. Evaluate diffs for correctness, style, "
            "security, and maintainability. Use security_scan for static checks."
        ),
        tool_names=(
            "code_graph_search", "document_reader",
            "gitlab_read_api", "gitlab_merge_request_api",
            "security_scan",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=(),
        keywords=("review", "pr", "pull request", "code review", "lint"),
    ))

    register(CapabilityAgent(
        role_id="testing",
        summary="Author and execute unit / integration tests; interpret failures.",
        system_prompt=(
            "You are the Testing specialist. Write and run tests. Use pytest_run to "
            "execute targeted tests and interpret failures back to root causes."
        ),
        tool_names=(
            "code_graph_search", "document_reader",
            "pytest_run", "gitlab_read_api",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=(),
        approval_actions=("write",),
        keywords=("test", "pytest", "unit test", "integration test", "regression"),
    ))

    register(CapabilityAgent(
        role_id="debugging",
        summary="Root-cause investigation; reproduce bugs; propose fixes.",
        system_prompt=(
            "You are the Debugging specialist. Investigate failures, reproduce bugs, "
            "and propose fixes. Use the code graph plus system introspection to narrow "
            "the blast radius of a change."
        ),
        tool_names=(
            "code_graph_search", "document_reader",
            "system_introspection",
            "http_request_tool", "rest_api_tool",
            "gitlab_read_api",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=(),
        approval_actions=("write",),
        keywords=("debug", "root cause", "traceback", "exception", "bug"),
    ))

    register(CapabilityAgent(
        role_id="security_compliance",
        summary="Static security scanning, secret-scanning, license / compliance checks.",
        system_prompt=(
            "You are the Security & Compliance specialist. Run static security scans, "
            "inspect dependencies, and flag policy violations."
        ),
        tool_names=(
            "security_scan", "code_graph_search",
            "document_reader", "system_introspection",
        ) + _MEMORY_READ_ONLY_TOOLS,
        request_types=(),
        keywords=("security", "compliance", "bandit", "vulnerability", "license"),
    ))

    register(CapabilityAgent(
        role_id="release",
        summary="Multi-repo delivery — plan, wave execution, CI/CD and deploy orchestration.",
        system_prompt=(
            "You are the Release / Delivery specialist. Coordinate multi-repo rollouts, "
            "generate deployment artifacts, and trigger CI/CD. All trigger_cicd_pipeline "
            "and deployment actions must be approved before execution."
        ),
        tool_names=(
            "api_contract_diff", "generate_deployment_manifest", "trigger_cicd_pipeline",
            "gitlab_merge_request_api", "gitlab_read_api",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=("release",),
        approval_actions=("write", "build", "deploy"),
        keywords=("release", "deploy", "rollout", "cutover", "pipeline", "ci/cd", "runbook"),
    ))

    register(CapabilityAgent(
        role_id="codebase_analysis",
        summary="Code-graph search; cross-project reuse discovery and validation.",
        system_prompt=(
            "You are the Codebase Analysis specialist. Explore the code graph, "
            "surface reusable artifacts from prior projects, and validate their "
            "applicability to the current project."
        ),
        tool_names=(
            "code_graph_search",
            "cross_project_reference_search", "reuse_validation",
            "document_reader",
        ) + _MEMORY_READ_WRITE_TOOLS,
        request_types=(),
        keywords=("codebase", "cross-project", "reuse", "similar", "prior art"),
    ))


def _bootstrap_development(assistant) -> QDevelopmentService:
    """Attach a QDevelopmentService to a QAssistant and wire its contributions.

    Invoked automatically by ``QAssistant.__init__`` via the bootstrap-hook
    registry. Capability code must not be imported by ``core.ai`` — instead,
    importing this package (e.g. from ``webapp/app.py`` or from a test)
    registers the hook, and every subsequent ``QAssistant()`` call picks it up.

    Contributions wired by this hook:
    - Dev-capability tools registered on the assistant's tool_registry
      (code_graph_search, api_contract_diff, deployment/CI tools,
      architecture_verifier, security_scan, pytest_run, and the two
      cross-project tool wrappers when their services are available).
    - A context enricher that returns code-graph + cross-project discovery +
      validated-reuse blocks for code-development request types.
    - Ten capability agents covering requirements / architecture / backend /
      frontend / code_review / testing / debugging / security_compliance /
      release / codebase_analysis.
    """
    existing = getattr(assistant, "_development_service", None)
    if existing is not None:
        return existing
    service = QDevelopmentService(assistant)
    object.__setattr__(assistant, "_development_service", service)
    assistant.register_context_enricher(service.enrich_context)

    _register_development_tools(assistant, service)
    _register_development_agents(assistant)
    return service


# Register the bootstrap hook so every newly-constructed QAssistant gets the
# development capability wired in automatically. Import-deferred to avoid
# cycles during capability package initialization.
from core.ai.q_assistant import QAssistant as _QAssistant  # noqa: E402

_QAssistant.register_bootstrap_hook(_bootstrap_development)


__all__ = [
    "ArchitectureVerifier",
    "CrossProjectInsightConfig",
    "CrossProjectInsightMatch",
    "CrossProjectReferenceRecord",
    "PromotionDecision",
    "QCrossProjectInsightService",
    "QDevelopmentService",
    "QMemoryRouter",
    "QReuseValidationService",
    "ReuseValidationCheck",
    "ReuseValidationResult",
    "WavePromotionInput",
    "get_q_cross_project_insight_service",
    "get_q_development_service",
    "get_q_reuse_validation_service",
]

