"""Langchain tool over :class:`capabilities.development.architecture_verifier.ArchitectureVerifier`.

Used by the ``architecture`` capability agent to check that a given set of
source directories does not import from forbidden module prefixes (the
cross-boundary rule).
"""

from __future__ import annotations

from typing import List

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from capabilities.development.architecture_verifier import ArchitectureVerifier


class ArchitectureVerifierInput(BaseModel):
    source_dirs: List[str] = Field(
        ..., description="Project-relative source directories to scan (e.g. ['webapp'])."
    )
    forbidden_imports: List[str] = Field(
        ..., description="Import prefixes that must not appear in the scanned files (e.g. ['core.ai'])."
    )
    project_root: str = Field(
        ".", description="Project root against which *source_dirs* are resolved. Defaults to CWD."
    )


def verify_no_cross_boundary_imports(
    source_dirs: List[str],
    forbidden_imports: List[str],
    project_root: str = ".",
) -> dict:
    """Return ``{"passed": bool, "violations": list[str]}`` for the boundary check."""
    verifier = ArchitectureVerifier(project_root)
    passed, violations = verifier.verify_no_cross_boundary_imports(
        list(source_dirs), list(forbidden_imports)
    )
    return {"passed": bool(passed), "violations": list(violations)}


class ArchitectureVerifierTool:
    """Cross-boundary import checker exposed as a langchain tool."""

    @classmethod
    def create_tool(cls) -> StructuredTool:
        return StructuredTool.from_function(
            func=verify_no_cross_boundary_imports,
            name="architecture_verifier",
            description=(
                "Statically verifies that the given source directories do not import "
                "from any forbidden module prefixes. Returns the list of violations."
            ),
            args_schema=ArchitectureVerifierInput,
        )
