"""Langchain tool over :class:`capabilities.development.q_cross_project_insight_service.QCrossProjectInsightService`.

Lets the ``codebase_analysis`` agent search for reusable artifacts from
other projects. The tool is stateful — its factory captures the service
plus an ``org_id_provider`` so each invocation can forward the running
assistant's org scope without requiring the LLM to supply it.
"""

from __future__ import annotations

from typing import Callable, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from capabilities.development.q_cross_project_insight_service import (
    QCrossProjectInsightService,
)


class CrossProjectReferenceSearchInput(BaseModel):
    query: str = Field(..., description="Natural-language description of the artifact, pattern, or component to look for.")
    current_project_id: Optional[str] = Field(
        default=None,
        description="Project ID of the active project — used to exclude same-project matches.",
    )
    current_repo_id: Optional[str] = Field(
        default=None,
        description="Repository ID of the active repo — used to exclude same-repo matches.",
    )
    bounded_context: Optional[str] = Field(default=None, description="Bounded-context scope filter.")
    environment: Optional[str] = Field(default=None, description="Environment scope filter.")
    top_k: Optional[int] = Field(default=None, description="Maximum number of matches to return.")


def _format_matches(matches) -> dict:
    out_items = []
    for match in matches:
        record = match.record
        out_items.append({
            "score": round(float(match.score), 4),
            "project_id": record.project_id,
            "repo_id": record.repo_id,
            "reference_kind": record.reference_kind,
            "entity_type": record.entity_type,
            "entity_id": record.entity_id,
            "symbol_id": record.symbol_id,
            "file_path": record.file_path,
            "summary": record.summary,
        })
    return {"count": len(out_items), "matches": out_items}


class CrossProjectReferenceSearchTool:
    """Cross-project reuse discovery exposed as a langchain tool."""

    @classmethod
    def create_tool(
        cls,
        *,
        service: QCrossProjectInsightService,
        org_id_provider: Callable[[], str],
    ) -> StructuredTool:
        def _search(
            query: str,
            current_project_id: Optional[str] = None,
            current_repo_id: Optional[str] = None,
            bounded_context: Optional[str] = None,
            environment: Optional[str] = None,
            top_k: Optional[int] = None,
        ) -> dict:
            matches = service.discover_related_project_artifacts(
                query,
                org_id=org_id_provider(),
                current_project_id=current_project_id,
                current_repo_id=current_repo_id,
                bounded_context=bounded_context,
                environment=environment,
                top_k=top_k,
            )
            return _format_matches(matches)

        return StructuredTool.from_function(
            func=_search,
            name="cross_project_reference_search",
            description=(
                "Search across prior projects for reusable references — patterns, "
                "algorithms, components, bug fixes — that match a natural-language "
                "query. Returns a ranked list with project/repo/entity identifiers."
            ),
            args_schema=CrossProjectReferenceSearchInput,
        )
