"""Langchain tool over :class:`core.verification.security_verifier.SecurityVerifier`.

Runs Bandit across the given targets and returns the report text plus a
pass/fail verdict. Used by ``security_compliance`` and ``code_review`` agents.
"""

from __future__ import annotations

from typing import List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from core.verification.security_verifier import SecurityVerifier


class SecurityScanInput(BaseModel):
    targets: Optional[List[str]] = Field(
        default=None,
        description="Directories to scan. Defaults to ['core', 'webapp'] when omitted.",
    )
    project_root: str = Field(
        ".", description="Project root directory. Defaults to the current working directory."
    )


def run_security_scan(
    targets: Optional[List[str]] = None,
    project_root: str = ".",
) -> dict:
    """Return ``{"passed": bool, "report": str}`` from a Bandit invocation."""
    verifier = SecurityVerifier(project_root=project_root)
    passed, report = verifier.verify_with_bandit(list(targets) if targets else None)
    return {"passed": bool(passed), "report": str(report)}


class SecurityScanTool:
    """Bandit static-security scanner exposed as a langchain tool."""

    @classmethod
    def create_tool(cls) -> StructuredTool:
        return StructuredTool.from_function(
            func=run_security_scan,
            name="security_scan",
            description=(
                "Runs Bandit static security analysis against the given targets "
                "(defaults to core and webapp). Returns a pass/fail verdict and "
                "the scanner report."
            ),
            args_schema=SecurityScanInput,
        )
