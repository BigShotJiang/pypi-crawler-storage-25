"""Langchain tool over :class:`capabilities.development.q_reuse_validation_service.QReuseValidationService`.

Validates a discovered cross-project reference against the active project
(code graph, scope filters, reference resolution). Used by
``codebase_analysis`` and ``code_review`` agents.

Consumers supply a reference metadata dict describing the candidate — the
tool reconstructs a :class:`CrossProjectReferenceRecord` and forwards to
the underlying service.
"""

from __future__ import annotations

from typing import Any, Callable, Dict, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from capabilities.development.q_cross_project_insight_service import (
    CrossProjectReferenceRecord,
)
from capabilities.development.q_reuse_validation_service import QReuseValidationService


class ReuseValidationInput(BaseModel):
    reference: Dict[str, Any] = Field(
        ...,
        description=(
            "Reference metadata dict — typically one of the entries returned by "
            "cross_project_reference_search (must include at least 'project_id')."
        ),
    )
    query: str = Field(..., description="The originating query / task description that surfaced the reference.")
    project_id: str = Field(..., description="Active project id to validate against.")
    repo_id: Optional[str] = Field(default=None, description="Active repo id to validate against.")
    bounded_context: Optional[str] = Field(default=None, description="Active bounded-context scope.")
    environment: Optional[str] = Field(default=None, description="Active environment scope.")


def _coerce_reference(data: Dict[str, Any]) -> CrossProjectReferenceRecord:
    if "project_id" not in data:
        raise ValueError("reference metadata must include 'project_id'")
    return CrossProjectReferenceRecord(
        project_id=str(data["project_id"]),
        repo_id=data.get("repo_id"),
        bounded_context=data.get("bounded_context"),
        environment=data.get("environment"),
        entity_type=data.get("entity_type"),
        entity_id=data.get("entity_id"),
        symbol_id=data.get("symbol_id"),
        file_path=data.get("file_path"),
        reference_kind=data.get("reference_kind"),
        summary=str(data.get("summary") or ""),
        provenance_pointer=data.get("provenance_pointer"),
    )


def _serialize_result(result) -> dict:
    return {
        "compatible": bool(getattr(result, "compatible", False)),
        "recommendation": getattr(result, "recommendation", None),
        "score": round(float(getattr(result, "score", 0.0) or 0.0), 4),
        "target_repo_ids": list(getattr(result, "target_repo_ids", []) or []),
        "resolved_reference_source_path": getattr(result, "resolved_reference_source_path", None),
        "checks": [
            {"name": c.name, "status": c.status, "summary": c.summary}
            for c in (getattr(result, "checks", []) or [])
        ],
    }


class ReuseValidationTool:
    """Cross-project reuse validator exposed as a langchain tool."""

    @classmethod
    def create_tool(
        cls,
        *,
        service: QReuseValidationService,
        org_id_provider: Callable[[], str],
    ) -> StructuredTool:
        def _validate(
            reference: Dict[str, Any],
            query: str,
            project_id: str,
            repo_id: Optional[str] = None,
            bounded_context: Optional[str] = None,
            environment: Optional[str] = None,
        ) -> dict:
            record = _coerce_reference(reference)
            result = service.validate_reference(
                record,
                query=query,
                org_id=org_id_provider(),
                project_id=project_id,
                repo_id=repo_id,
                bounded_context=bounded_context,
                environment=environment,
            )
            return _serialize_result(result)

        return StructuredTool.from_function(
            func=_validate,
            name="reuse_validation",
            description=(
                "Validate a candidate cross-project reference against the active "
                "project's code graph and workspace. Returns a compatibility "
                "verdict, recommendation, and per-check findings."
            ),
            args_schema=ReuseValidationInput,
        )
