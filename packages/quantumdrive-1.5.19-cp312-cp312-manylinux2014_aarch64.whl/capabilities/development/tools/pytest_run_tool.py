"""Langchain tool that runs pytest as a subprocess.

Used by the ``testing`` capability agent to execute the project's test
suite (or a targeted subset). Returns the pass/fail verdict, the return
code, and the captured stdout/stderr.
"""

from __future__ import annotations

import os
import subprocess
from typing import List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field


class PytestRunInput(BaseModel):
    targets: Optional[List[str]] = Field(
        default=None,
        description="pytest node ids or file paths to run. Defaults to the full 'tests/' suite when omitted.",
    )
    extra_args: Optional[List[str]] = Field(
        default=None,
        description="Additional CLI flags to pass through to pytest (e.g. ['-x', '-k', 'pattern']).",
    )
    project_root: str = Field(
        ".", description="Directory pytest runs in. Defaults to the current working directory."
    )
    timeout_seconds: int = Field(
        600, description="Max wall-clock seconds for the pytest invocation."
    )


def run_pytest(
    targets: Optional[List[str]] = None,
    extra_args: Optional[List[str]] = None,
    project_root: str = ".",
    timeout_seconds: int = 600,
) -> dict:
    """Run pytest and return structured result info."""
    executable = os.environ.get("PYTHON", "python3")
    argv: list[str] = [executable, "-m", "pytest"]
    argv.extend(list(targets) if targets else ["tests"])
    if extra_args:
        argv.extend(str(arg) for arg in extra_args)
    try:
        proc = subprocess.run(
            argv,
            cwd=project_root,
            capture_output=True,
            text=True,
            check=False,
            timeout=timeout_seconds,
        )
    except subprocess.TimeoutExpired as exc:
        return {
            "passed": False,
            "returncode": None,
            "timed_out": True,
            "stdout": str(exc.stdout or ""),
            "stderr": str(exc.stderr or ""),
            "command": argv,
        }
    return {
        "passed": proc.returncode == 0,
        "returncode": proc.returncode,
        "timed_out": False,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
        "command": argv,
    }


class PytestRunTool:
    """Pytest runner exposed as a langchain tool."""

    @classmethod
    def create_tool(cls) -> StructuredTool:
        return StructuredTool.from_function(
            func=run_pytest,
            name="pytest_run",
            description=(
                "Runs pytest against the given targets (defaults to the full 'tests/' "
                "suite). Returns pass/fail, return code, and captured output."
            ),
            args_schema=PytestRunInput,
        )
