/*
 * Minimal tracked renderer primitives for QuantumDrive presentation specs.
 */

const THEMES = {
  dark: {
    bg: "0D1117",
    cardBg: "161B22",
    accent: "00D4FF",
    primary: "0066B3",
    border: "30363D",
    white: "FFFFFF",
    muted: "9CA3AF",
    text: "D1D5DB",
  },
  light: {
    bg: "FFFFFF",
    cardBg: "F8FAFC",
    accent: "0891B2",
    primary: "2563EB",
    border: "CBD5E1",
    white: "FFFFFF",
    muted: "64748B",
    text: "334155",
  },
  corporate: {
    bg: "FAFAFA",
    cardBg: "FFFFFF",
    accent: "2980B9",
    primary: "1E3A5F",
    border: "BDC3C7",
    white: "FFFFFF",
    muted: "7F8C8D",
    text: "2C3E50",
  },
};

function defaultTheme(name) {
  return THEMES[name] || THEMES.dark;
}

function addFooter(slide, footerText, theme) {
  slide.addText(footerText, {
    x: 0.5,
    y: 7.05,
    w: 12.33,
    h: 0.25,
    fontFace: "Arial",
    fontSize: 9,
    color: theme.muted,
    align: "center",
  });
}

function addHeader(slide, title, subtitle, theme) {
  slide.addText(title, {
    x: 0.5,
    y: 0.3,
    w: 12.0,
    h: 0.45,
    fontFace: "Arial",
    fontSize: 26,
    bold: true,
    color: theme.accent,
  });
  slide.addShape("line", {
    x: 0.5,
    y: 0.82,
    w: 12.33,
    h: 0,
    line: { color: theme.accent, width: 1 },
  });
  if (subtitle) {
    slide.addText(subtitle, {
      x: 0.5,
      y: 0.92,
      w: 12.0,
      h: 0.3,
      fontFace: "Arial",
      fontSize: 11,
      color: theme.muted,
    });
  }
}

function renderTitleSlide(slide, spec, options) {
  const theme = options.theme;
  slide.background = { color: theme.bg };
  slide.addText(spec.title || "Untitled Presentation", {
    x: 0.5,
    y: 2.1,
    w: 12.33,
    h: 0.9,
    fontFace: "Arial",
    fontSize: 34,
    bold: true,
    color: theme.white,
    align: "center",
  });
  slide.addShape("line", {
    x: 5.15,
    y: 3.2,
    w: 3.0,
    h: 0,
    line: { color: theme.accent, width: 3 },
  });
  if (spec.subtitle) {
    slide.addText(spec.subtitle, {
      x: 0.8,
      y: 3.45,
      w: 11.7,
      h: 0.4,
      fontFace: "Arial",
      fontSize: 16,
      color: theme.muted,
      align: "center",
    });
  }
  addFooter(slide, options.footerText, theme);
}

function renderBulletListSlide(slide, spec, options) {
  const theme = options.theme;
  slide.background = { color: theme.bg };
  addHeader(slide, spec.title || "Summary", spec.subtitle, theme);
  const bullets = Array.isArray(spec.bullets) ? spec.bullets : [];
  bullets.slice(0, 8).forEach((item, index) => {
    slide.addText("\u2022", {
      x: 0.8,
      y: 1.55 + index * 0.55,
      w: 0.2,
      h: 0.3,
      fontFace: "Arial",
      fontSize: 18,
      color: theme.accent,
    });
    slide.addText(String(item), {
      x: 1.05,
      y: 1.5 + index * 0.55,
      w: 11.2,
      h: 0.4,
      fontFace: "Arial",
      fontSize: 18,
      color: theme.text,
    });
  });
  addFooter(slide, options.footerText, theme);
}

function renderArchitectureSlide(slide, spec, options) {
  const theme = options.theme;
  slide.background = { color: theme.bg };
  addHeader(slide, spec.title || "Architecture", spec.subtitle, theme);
  slide.addShape("roundRect", {
    x: 0.8,
    y: 1.55,
    w: 3.2,
    h: 1.0,
    fill: { color: theme.cardBg },
    line: { color: theme.primary, width: 1.5 },
    rectRadius: 0.08,
  });
  slide.addText("Inputs / Users", {
    x: 0.8,
    y: 1.9,
    w: 3.2,
    h: 0.3,
    align: "center",
    fontFace: "Arial",
    fontSize: 16,
    bold: true,
    color: theme.text,
  });
  slide.addShape("roundRect", {
    x: 5.05,
    y: 1.55,
    w: 3.2,
    h: 1.0,
    fill: { color: theme.cardBg },
    line: { color: theme.accent, width: 1.5 },
    rectRadius: 0.08,
  });
  slide.addText("QuantumDrive Service Layer", {
    x: 5.05,
    y: 1.9,
    w: 3.2,
    h: 0.3,
    align: "center",
    fontFace: "Arial",
    fontSize: 16,
    bold: true,
    color: theme.text,
  });
  slide.addShape("roundRect", {
    x: 9.3,
    y: 1.55,
    w: 3.2,
    h: 1.0,
    fill: { color: theme.cardBg },
    line: { color: theme.primary, width: 1.5 },
    rectRadius: 0.08,
  });
  slide.addText("Artifacts / Output", {
    x: 9.3,
    y: 1.9,
    w: 3.2,
    h: 0.3,
    align: "center",
    fontFace: "Arial",
    fontSize: 16,
    bold: true,
    color: theme.text,
  });
  slide.addShape("line", {
    x: 4.0,
    y: 2.05,
    w: 1.05,
    h: 0,
    line: { color: theme.accent, width: 2, endArrowType: "triangle" },
  });
  slide.addShape("line", {
    x: 8.25,
    y: 2.05,
    w: 1.05,
    h: 0,
    line: { color: theme.accent, width: 2, endArrowType: "triangle" },
  });
  const bullets = Array.isArray(spec.bullets) ? spec.bullets : [];
  bullets.slice(0, 6).forEach((item, index) => {
    slide.addText("\u2022", {
      x: 1.1,
      y: 3.05 + index * 0.45,
      w: 0.2,
      h: 0.25,
      fontFace: "Arial",
      fontSize: 14,
      color: theme.accent,
    });
    slide.addText(String(item), {
      x: 1.35,
      y: 3.0 + index * 0.45,
      w: 10.8,
      h: 0.3,
      fontFace: "Arial",
      fontSize: 13,
      color: theme.text,
    });
  });
  addFooter(slide, options.footerText, theme);
}

function renderClosingSlide(slide, spec, options) {
  const theme = options.theme;
  slide.background = { color: theme.bg };
  slide.addText(spec.title || "Next Steps", {
    x: 0.5,
    y: 2.0,
    w: 12.33,
    h: 0.9,
    fontFace: "Arial",
    fontSize: 34,
    bold: true,
    color: theme.white,
    align: "center",
  });
  if (spec.subtitle) {
    slide.addText(spec.subtitle, {
      x: 0.8,
      y: 3.15,
      w: 11.7,
      h: 0.4,
      fontFace: "Arial",
      fontSize: 18,
      color: theme.muted,
      align: "center",
    });
  }
  const bullets = Array.isArray(spec.bullets) ? spec.bullets : [];
  bullets.slice(0, 4).forEach((item, index) => {
    slide.addText(String(item), {
      x: 1.6,
      y: 4.15 + index * 0.35,
      w: 10.1,
      h: 0.25,
      fontFace: "Arial",
      fontSize: 13,
      color: theme.text,
      align: "center",
    });
  });
  addFooter(slide, options.footerText, theme);
}

function renderSlides(pptx, slides, options) {
  slides.forEach((spec) => {
    const slide = pptx.addSlide();
    const slideType = spec.type || "bullet_list";
    if (slideType === "title") {
      renderTitleSlide(slide, spec, options);
      return;
    }
    if (slideType === "architecture_diagram") {
      renderArchitectureSlide(slide, spec, options);
      return;
    }
    if (slideType === "closing") {
      renderClosingSlide(slide, spec, options);
      return;
    }
    renderBulletListSlide(slide, spec, options);
  });
}

module.exports = {
  defaultTheme,
  renderSlides,
};
