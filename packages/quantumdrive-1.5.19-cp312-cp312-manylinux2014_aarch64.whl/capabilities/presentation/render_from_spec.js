#!/usr/bin/env node
/*
 * Render a normalized QuantumDrive presentation spec into a native .pptx file.
 *
 * This script intentionally lives in tracked source so QD does not depend on
 * the temporary reference material directory that informed the initial design.
 */

const fs = require("fs");
const path = require("path");

function fail(message, code = 1) {
  console.error(message);
  process.exit(code);
}

if (process.argv.includes("--check")) {
  try {
    require("pptxgenjs");
  } catch (error) {
    fail(
      `pptxgenjs dependency missing for presentation renderer: ${error.message}`,
      2,
    );
  }
  console.log("presentation renderer ready");
  process.exit(0);
}

let PptxGenJS;
try {
  PptxGenJS = require("pptxgenjs");
} catch (error) {
  fail(`Failed to load pptxgenjs: ${error.message}`, 2);
}

const { renderSlides, defaultTheme } = require("./spec_renderers");

if (process.argv.length < 3) {
  fail("Usage: node render_from_spec.js <spec-path> [--thumbnails <dir>]");
}

const specPath = path.resolve(process.argv[2]);
if (!fs.existsSync(specPath)) {
  fail(`Spec file not found: ${specPath}`);
}

let thumbnailDir = null;
const thumbIndex = process.argv.indexOf("--thumbnails");
if (thumbIndex > -1 && thumbIndex + 1 < process.argv.length) {
  thumbnailDir = path.resolve(process.argv[thumbIndex + 1]);
}

let rawSpec;
try {
  rawSpec = JSON.parse(fs.readFileSync(specPath, "utf8"));
} catch (error) {
  fail(`Failed to read spec ${specPath}: ${error.message}`);
}

const meta = rawSpec.meta || {};
const slides = Array.isArray(rawSpec.slides) ? rawSpec.slides : [];
if (!meta.output_path) {
  fail("Spec missing meta.output_path");
}
if (!slides.length) {
  fail("Spec missing slides");
}

const pptx = new PptxGenJS();
pptx.layout = "LAYOUT_WIDE";
pptx.title = meta.title || "QuantumDrive Presentation";
pptx.author = meta.author || "QuantumDrive";
pptx.company = meta.company || "AlphaSix";

const theme = defaultTheme(meta.theme);
try {
  renderSlides(pptx, slides, {
    theme,
    footerText: meta.footer_text || "Proprietary & Confidential",
  });
} catch (error) {
  fail(`Failed while rendering slides: ${error.message}`);
}

const outputPath = path.resolve(meta.output_path);
fs.mkdirSync(path.dirname(outputPath), { recursive: true });

pptx
  .writeFile({ fileName: outputPath })
  .then(() => {
    if (thumbnailDir) {
      const { execSync } = require("child_process");
      try {
        const tempPdfDir = fs.mkdtempSync(path.join(require("os").tmpdir(), "qd-ppt-"));
        execSync(`libreoffice --headless --convert-to pdf --outdir "${tempPdfDir}" "${outputPath}"`, { stdio: 'ignore' });
        const pdfPath = path.join(tempPdfDir, path.basename(outputPath, ".pptx") + ".pdf");
        
        fs.mkdirSync(thumbnailDir, { recursive: true });
        execSync(`pdftoppm -jpeg "${pdfPath}" "${path.join(thumbnailDir, "slide")}"`, { stdio: 'ignore' });
        
        // Cleanup temp
        fs.rmSync(tempPdfDir, { recursive: true, force: true });
      } catch (err) {
        console.error(`Thumbnail generation failed: ${err.message}`);
      }
    }
    console.log(JSON.stringify({ ok: true, output_path: outputPath, slide_count: slides.length }));
  })
  .catch((error) => {
    fail(`Failed to write presentation: ${error.message}`);
  });
