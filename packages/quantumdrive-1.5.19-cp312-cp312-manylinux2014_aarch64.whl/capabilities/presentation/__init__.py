"""QuantumDrive presentation generation services."""

from __future__ import annotations

from core.ai.capability_agent import CapabilityAgent
from core.ai.q_request_type_registry import RequestTypeRegistry

from .models import (
    PresentationArtifact,
    PresentationAudience,
    PresentationDeckType,
    PresentationDiagnostics,
    PresentationRequest,
    PresentationResult,
    SlideSpec,
)
from .q_presentation_planner import QPresentationPlanner
from .q_presentation_renderer import QPresentationRenderer
from .q_presentation_service import QPresentationService, get_q_presentation_service
from .presentation_generation_tool import PresentationGenerationTool


RequestTypeRegistry.register(
    "presentation",
    keywords=(
        "slide", "deck", "presentation", "powerpoint", "keynote", "pitch",
    ),
    backend="flat",
    default_role="presentation_agent",
)


def _bootstrap_presentation(assistant) -> None:
    """Register the presentation-generation tool and CapabilityAgent."""
    qd_config = getattr(assistant, "qd_config", None)
    tool_registry = getattr(assistant, "tool_registry", None)
    logger = getattr(assistant, "logger", None)
    if tool_registry is None:
        return
    try:
        tool = PresentationGenerationTool(config=qd_config)
        tool_registry.register_tool(tool.as_tool())
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Presentation tool registration failed: %s", exc)
        return

    assistant.register_capability_agent(CapabilityAgent(
        role_id="presentation_agent",
        summary="Plan and render audience-targeted slide decks (PowerPoint) with diagrams and code examples.",
        system_prompt=(
            "You are the Presentation specialist. Produce audience-appropriate slide decks: "
            "plan the narrative, draft slide content, and render via presentation_generation_tool. "
            "Cite source material in speaker notes so slides remain traceable."
        ),
        tool_names=(
            "presentation_generation_tool",
            "document_reader", "pdf_creator", "web_search_tool",
            "code_graph_search",
            "save_thread_memory", "search_thread_memory",
            "search_user_memory", "summarize_any_memory",
        ),
        request_types=("presentation",),
        approval_actions=("write",),
        keywords=("slide", "deck", "presentation", "powerpoint"),
    ))


from core.ai.q_assistant import QAssistant as _QAssistant  # noqa: E402

_QAssistant.register_bootstrap_hook(_bootstrap_presentation)


__all__ = [
    "PresentationArtifact",
    "PresentationAudience",
    "PresentationDeckType",
    "PresentationDiagnostics",
    "PresentationRequest",
    "PresentationResult",
    "SlideSpec",
    "QPresentationPlanner",
    "QPresentationRenderer",
    "QPresentationService",
    "PresentationGenerationTool",
    "get_q_presentation_service",
]
