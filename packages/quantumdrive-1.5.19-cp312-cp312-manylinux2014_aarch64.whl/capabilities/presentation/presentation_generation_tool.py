"""Tool wrapper for QuantumDrive presentation generation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from capabilities.presentation.models import (
    PresentationAudience,
    PresentationDeckType,
    PresentationRequest,
)
from capabilities.presentation.q_presentation_service import (
    QPresentationService,
    get_q_presentation_service,
)
from core.config import QDConfig

logger = logging.getLogger(__name__)


class PresentationGenerationInput(BaseModel):
    title: str = Field(..., description="Presentation title.")
    deck_type: str = Field(
        PresentationDeckType.ARCHITECTURE.value,
        description="Deck type such as architecture_deck or delivery_status_deck.",
    )
    audience: str = Field(
        PresentationAudience.TECHNICAL.value,
        description="Audience profile such as technical, executive, or mixed.",
    )
    theme: str = Field("dark", description="Theme name for the generated deck.")
    subtitle: Optional[str] = Field(None, description="Optional presentation subtitle.")
    project_id: Optional[str] = Field(None, description="Optional project scope id.")
    repo_id: Optional[str] = Field(None, description="Optional repository scope id.")
    bounded_context: Optional[str] = Field(None, description="Optional bounded context.")
    environment: Optional[str] = Field(None, description="Optional environment label.")
    include_thumbnails: bool = Field(
        False,
        description="Whether preview thumbnails should be requested.",
    )
    content_brief: Optional[str] = Field(
        None,
        description="Free-form source brief for the planner.",
    )
    bullets: List[str] = Field(
        default_factory=list,
        description="Optional bullet points to seed the deck outline.",
    )
    source_paths: List[str] = Field(
        default_factory=list,
        description="Optional source file paths referenced by the request.",
    )
    source_artifact_ids: List[str] = Field(
        default_factory=list,
        description="Optional source artifact ids referenced by the request.",
    )


class PresentationGenerationTool:
    """Expose presentation generation to the agent tool registry."""

    def __init__(
        self,
        config: QDConfig | None = None,
        *,
        service: QPresentationService | None = None,
        project_root: str | Path | None = None,
    ) -> None:
        self.config = config or QDConfig.from_toml()
        self.service = service or get_q_presentation_service(
            self.config,
            project_root=project_root,
        )
        logger.debug(
            "Initialized PresentationGenerationTool service=%s project_root=%s",
            type(self.service).__name__,
            project_root,
        )

    def generate(
        self,
        title: str,
        deck_type: str = PresentationDeckType.ARCHITECTURE.value,
        audience: str = PresentationAudience.TECHNICAL.value,
        theme: str = "dark",
        subtitle: Optional[str] = None,
        project_id: Optional[str] = None,
        repo_id: Optional[str] = None,
        bounded_context: Optional[str] = None,
        environment: Optional[str] = None,
        include_thumbnails: bool = False,
        content_brief: Optional[str] = None,
        bullets: Optional[List[str]] = None,
        source_paths: Optional[List[str]] = None,
        source_artifact_ids: Optional[List[str]] = None,
    ) -> dict:
        logger.info(
            "PresentationGenerationTool invoked title=%r deck_type=%s audience=%s",
            title,
            deck_type,
            audience,
        )
        request = PresentationRequest(
            title=title,
            deck_type=PresentationDeckType(deck_type),
            audience=PresentationAudience(audience),
            theme=theme,
            subtitle=subtitle,
            project_id=project_id,
            repo_id=repo_id,
            bounded_context=bounded_context,
            environment=environment,
            include_thumbnails=include_thumbnails,
            content_brief=content_brief,
            bullets=list(bullets or []),
            source_paths=list(source_paths or []),
            source_artifact_ids=list(source_artifact_ids or []),
        )
        result = self.service.generate_presentation(request)
        logger.info(
            "PresentationGenerationTool completed title=%r ok=%s slide_count=%d",
            title,
            result.ok,
            result.slide_count,
        )
        return result.as_dict()

    def as_tool(self) -> StructuredTool:
        return StructuredTool.from_function(
            func=self.generate,
            name="presentation_generation_tool",
            description=(
                "Generate a PowerPoint presentation deck from a structured request. "
                "Returns artifact paths, diagnostics, and renderer warnings."
            ),
            args_schema=PresentationGenerationInput,
        )
