"""
Blog Generator state management and persistence service.
"""

from __future__ import annotations

import json
import logging
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional
import uuid

from pydantic import BaseModel, Field
from core.config import QDConfig

logger = logging.getLogger(__name__)

class BlogStatus(str, Enum):
    DRAFT = "DRAFT"
    PUBLISHED = "PUBLISHED"
    ARCHIVED = "ARCHIVED"

class BlogAudience(str, Enum):
    MARKETING = "MARKETING"
    GENERAL = "GENERAL"
    TECHNICAL = "TECHNICAL"
    DEEP_TECHNICAL = "DEEP_TECHNICAL"

class BlogLength(str, Enum):
    SHORT = "SHORT"
    MEDIUM = "MEDIUM"
    LONG = "LONG"

class BlogPost(BaseModel):
    """Pydantic model representing a generated blog post."""
    id: str = Field(default_factory=lambda: str(uuid.uuid4()))
    title: str
    content: str
    status: BlogStatus = BlogStatus.DRAFT
    audience: BlogAudience = BlogAudience.GENERAL
    length: BlogLength = BlogLength.MEDIUM
    tone: str = "Professional"
    features_covered: List[str] = Field(default_factory=list)
    created_at: str = Field(default_factory=lambda: datetime.now(timezone.utc).isoformat())
    published_at: Optional[str] = None
    
    def as_dict(self) -> Dict[str, Any]:
        return self.model_dump(mode="json")

class QBlogService:
    """Service to persist and manage Blog Posts via a JSON registry."""

    def __init__(self, config: QDConfig) -> None:
        self._config = config
        self._registry_path = config.blog_registry_path
        
    def _ensure_parent(self) -> None:
        self._registry_path.parent.mkdir(parents=True, exist_ok=True)
        
    def _load_registry(self) -> List[BlogPost]:
        if not self._registry_path.exists():
            return []
        try:
            payload = json.loads(self._registry_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            logger.warning("Blog registry is invalid JSON; treating as empty: %s", self._registry_path)
            return []
        return [BlogPost.model_validate(item) for item in payload]
        
    def _write_registry(self, records: List[BlogPost]) -> None:
        self._ensure_parent()
        payload = [record.model_dump(mode="json") for record in records]
        self._registry_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        
    def list_posts(self) -> List[BlogPost]:
        """Return all blog posts sorted by creation date descending."""
        posts = self._load_registry()
        posts.sort(key=lambda p: p.created_at, reverse=True)
        return posts
        
    def get_post(self, post_id: str) -> Optional[BlogPost]:
        """Get a single blog post by ID."""
        for post in self._load_registry():
            if post.id == post_id:
                return post
        return None
        
    def create_post(self, post: BlogPost) -> BlogPost:
        """Create a new blog post."""
        posts = self._load_registry()
        posts.append(post)
        self._write_registry(posts)
        return post
        
    def update_post(self, updated_post: BlogPost) -> BlogPost:
        """Update an existing post."""
        posts = self._load_registry()
        for i, post in enumerate(posts):
            if post.id == updated_post.id:
                posts[i] = updated_post
                self._write_registry(posts)
                return updated_post
        raise ValueError(f"Blog post {updated_post.id} not found.")
        
    def delete_post(self, post_id: str) -> None:
        """Delete a blog post."""
        posts = self._load_registry()
        initial_len = len(posts)
        posts = [p for p in posts if p.id != post_id]
        if len(posts) < initial_len:
            self._write_registry(posts)
            
    def get_last_publish_date(self) -> Optional[datetime]:
        """Find the date of the most recently published post."""
        posts = self._load_registry()
        published = [p for p in posts if p.status == BlogStatus.PUBLISHED and p.published_at]
        if not published:
            return None
        published.sort(key=lambda p: p.published_at, reverse=True) # type: ignore
        return datetime.fromisoformat(published[0].published_at) # type: ignore

_service_singleton: Optional[QBlogService] = None

def get_q_blog_service(config: QDConfig) -> QBlogService:
    global _service_singleton
    if _service_singleton is None:
        _service_singleton = QBlogService(config)
    return _service_singleton
