"""QuantumDrive blog generation and management services."""

from __future__ import annotations

from core.ai.capability_agent import CapabilityAgent
from core.ai.q_request_type_registry import RequestTypeRegistry

from .q_blog_service import (
    BlogAudience,
    BlogLength,
    BlogPost,
    BlogStatus,
    QBlogService,
    get_q_blog_service,
)
from .q_blog_generator import QBlogGeneratorService


RequestTypeRegistry.register(
    "blog",
    keywords=(
        "blog", "blog post", "blog draft", "write a post", "write a blog", "newsletter",
    ),
    backend="flat",
    default_role="blog_agent",
)


def _bootstrap_blog(assistant) -> None:
    """Register blog tool wrappers + CapabilityAgent."""
    qd_config = getattr(assistant, "qd_config", None)
    tool_registry = getattr(assistant, "tool_registry", None)
    logger = getattr(assistant, "logger", None)
    if qd_config is None or tool_registry is None:
        return
    try:
        from capabilities.blog.tools import SuggestBlogTopicsTool, GenerateBlogDraftTool

        def _factory():
            # Lazily construct the generator so the active assistant (this one)
            # is reused — avoiding recursive QAssistant construction.
            return QBlogGeneratorService(
                config=qd_config,
                user_id=assistant.user_id,
                org_id=assistant.org_id,
                assistant=assistant,
            )

        tool_registry.register_tool(SuggestBlogTopicsTool.create_tool(generator_factory=_factory))
        tool_registry.register_tool(GenerateBlogDraftTool.create_tool(generator_factory=_factory))
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Blog tool registration failed: %s", exc)
        return

    assistant.register_capability_agent(CapabilityAgent(
        role_id="blog_agent",
        summary="Propose blog topics from recent git activity and generate drafts with configurable audience / length / tone.",
        system_prompt=(
            "You are the Blog specialist. Suggest topics from the project's recent git "
            "history and produce drafts that match a chosen audience, length, and tone. "
            "Keep the draft accurate — base it on actual commit evidence rather than "
            "invention."
        ),
        tool_names=(
            "suggest_blog_topics", "generate_blog_draft",
            "document_reader", "web_search_tool",
            "save_thread_memory", "search_thread_memory",
            "search_user_memory", "summarize_any_memory",
        ),
        request_types=("blog",),
        approval_actions=("write",),
        keywords=("blog", "post", "newsletter", "write-up"),
    ))


from core.ai.q_assistant import QAssistant as _QAssistant  # noqa: E402

_QAssistant.register_bootstrap_hook(_bootstrap_blog)


__all__ = [
    "BlogAudience",
    "BlogLength",
    "BlogPost",
    "BlogStatus",
    "QBlogService",
    "QBlogGeneratorService",
    "get_q_blog_service",
]
