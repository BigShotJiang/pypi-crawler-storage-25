"""Langchain tool over :meth:`QBlogGeneratorService.generate_draft`.

Produces a full blog-post draft from a topic list and audience/length/tone knobs.
"""

from __future__ import annotations

from datetime import datetime
from typing import Callable, List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from capabilities.blog.q_blog_service import BlogAudience, BlogLength


class GenerateBlogDraftInput(BaseModel):
    topics: List[str] = Field(..., description="Topics / themes to cover, one per list entry.")
    audience: str = Field(
        default=BlogAudience.GENERAL.value,
        description=f"Target audience — one of: {', '.join(a.value for a in BlogAudience)}.",
    )
    length: str = Field(
        default=BlogLength.MEDIUM.value,
        description=f"Target length — one of: {', '.join(l.value for l in BlogLength)}.",
    )
    tone: str = Field(default="Professional", description="Writing tone (e.g. 'Professional', 'Witty', 'Conversational').")
    additional_features: Optional[List[str]] = Field(
        default=None,
        description="Optional additional features / bullet points to mention beyond git context.",
    )
    since: Optional[str] = Field(
        default=None,
        description="Optional ISO-8601 datetime to bound the commit context window.",
    )


class GenerateBlogDraftTool:
    """Produce a langchain tool that writes a full blog draft."""

    @classmethod
    def create_tool(
        cls,
        *,
        generator_factory: Callable[[], "object"],
    ) -> StructuredTool:

        def _draft(
            topics: List[str],
            audience: str = BlogAudience.GENERAL.value,
            length: str = BlogLength.MEDIUM.value,
            tone: str = "Professional",
            additional_features: Optional[List[str]] = None,
            since: Optional[str] = None,
        ) -> dict:
            try:
                audience_enum = BlogAudience(audience)
            except ValueError:
                return {"error": f"Invalid audience {audience!r}. Options: {[a.value for a in BlogAudience]}"}
            try:
                length_enum = BlogLength(length)
            except ValueError:
                return {"error": f"Invalid length {length!r}. Options: {[l.value for l in BlogLength]}"}
            since_dt: Optional[datetime] = None
            if since:
                try:
                    since_dt = datetime.fromisoformat(since)
                except ValueError:
                    return {"error": f"Could not parse 'since' as ISO-8601: {since!r}"}
            generator = generator_factory()
            draft = generator.generate_draft(
                topics=list(topics),
                audience=audience_enum,
                length=length_enum,
                tone=tone,
                additional_features=list(additional_features) if additional_features else None,
                since_date=since_dt,
            )
            return {
                "id": draft.id,
                "title": draft.title,
                "audience": draft.audience.value,
                "length": draft.length.value,
                "tone": draft.tone,
                "content": draft.content,
                "features_covered": list(draft.features_covered),
                "status": draft.status.value,
            }

        return StructuredTool.from_function(
            func=_draft,
            name="generate_blog_draft",
            description=(
                "Generate a blog-post draft from a topic list, with configurable audience, "
                "length, and tone. Uses recent git activity as context."
            ),
            args_schema=GenerateBlogDraftInput,
        )
