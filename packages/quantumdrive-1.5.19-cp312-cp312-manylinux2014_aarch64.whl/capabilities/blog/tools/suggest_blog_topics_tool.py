"""Langchain tool over :meth:`QBlogGeneratorService.suggest_topics`.

Scans recent git history and asks the LLM to propose blog topics.
"""

from __future__ import annotations

from datetime import datetime
from typing import Callable, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field


class SuggestBlogTopicsInput(BaseModel):
    since: Optional[str] = Field(
        default=None,
        description="Optional ISO-8601 datetime; only commits after this are considered. Omit for 'since last publish'.",
    )


class SuggestBlogTopicsTool:
    """Produce a langchain tool that surfaces candidate blog topics from git history."""

    @classmethod
    def create_tool(
        cls,
        *,
        generator_factory: Callable[[], "object"],
    ) -> StructuredTool:
        """``generator_factory`` is called lazily to produce a QBlogGeneratorService."""

        def _suggest(since: Optional[str] = None) -> dict:
            since_dt: Optional[datetime] = None
            if since:
                try:
                    since_dt = datetime.fromisoformat(since)
                except ValueError:
                    return {"error": f"Could not parse 'since' as ISO-8601: {since!r}"}
            generator = generator_factory()
            topics = generator.suggest_topics(since_date=since_dt)
            return {"count": len(topics), "topics": list(topics)}

        return StructuredTool.from_function(
            func=_suggest,
            name="suggest_blog_topics",
            description=(
                "Scan recent git history and return candidate blog-post topics. "
                "Pass an ISO-8601 'since' datetime to restrict the commit window."
            ),
            args_schema=SuggestBlogTopicsInput,
        )
