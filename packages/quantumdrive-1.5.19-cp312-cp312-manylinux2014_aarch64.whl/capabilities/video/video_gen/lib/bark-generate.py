#!/usr/bin/env python3
"""
Batch generate speech audio using Bark TTS (Suno AI).

Reads a JSON array from stdin:
  [{"text": "...", "output": "/path/to/out.wav", "speaker": "v2/en_speaker_6"}, ...]

Loads the Bark model once and generates all clips sequentially.
Long text is split on sentence boundaries to avoid hallucination.
"""

import json
import os
import re
import sys

# Use small models by default to reduce memory requirements (~4GB vs ~12GB).
# Set SUNO_USE_SMALL_MODELS=false to use full-size models when RAM allows.
if os.environ.get("SUNO_USE_SMALL_MODELS", "true").lower() != "false":
    os.environ["SUNO_USE_SMALL_MODELS"] = "True"

# PyTorch 2.6+ defaults torch.load to weights_only=True, but Bark's
# model checkpoints contain numpy globals that aren't in the safe list.
# Bark models come from Suno's official HuggingFace repository.
import torch
_original_torch_load = torch.load
def _patched_torch_load(*args, **kwargs):
    kwargs.setdefault('weights_only', False)
    return _original_torch_load(*args, **kwargs)
torch.load = _patched_torch_load

import numpy as np
import scipy.io.wavfile


def split_sentences(text):
    """Split text into sentences, each short enough for Bark to handle cleanly."""
    # Split on sentence-ending punctuation followed by whitespace
    parts = re.split(r'(?<=[.!?])\s+', text.strip())
    sentences = []
    for part in parts:
        part = part.strip()
        if not part:
            continue
        # If a sentence is still very long, split on commas too
        if len(part) > 180:
            sub = re.split(r',\s+', part)
            for s in sub:
                s = s.strip()
                if s:
                    sentences.append(s)
        else:
            sentences.append(part)
    return sentences


def generate_clip(text, output_path, speaker, sample_rate):
    """Generate a single WAV file from text, splitting into sentences."""
    from bark import generate_audio

    sentences = split_sentences(text)
    chunks = []

    for sentence in sentences:
        audio = generate_audio(sentence, history_prompt=speaker)
        chunks.append(audio)
        # Brief pause between sentences (0.12s)
        chunks.append(np.zeros(int(sample_rate * 0.12)))

    if not chunks:
        # Fallback: generate the whole text as-is
        audio = generate_audio(text, history_prompt=speaker)
        chunks.append(audio)

    # Remove trailing silence
    if len(chunks) > 1:
        chunks.pop()

    full_audio = np.concatenate(chunks)

    # Normalize to int16 range for WAV output
    full_audio = np.clip(full_audio, -1.0, 1.0)
    full_audio = (full_audio * 32767).astype(np.int16)

    scipy.io.wavfile.write(output_path, sample_rate, full_audio)


def main():
    items = json.loads(sys.stdin.read())

    print(f"[bark] Loading model...", flush=True)
    from bark import SAMPLE_RATE, preload_models
    preload_models()
    print(f"[bark] Model loaded. Generating {len(items)} clip(s)...", flush=True)

    for i, item in enumerate(items):
        text = item["text"]
        output = item["output"]
        speaker = item.get("speaker", "v2/en_speaker_6")

        truncated = text[:60] + "..." if len(text) > 60 else text
        print(f"[bark] [{i + 1}/{len(items)}] \"{truncated}\"", flush=True)

        generate_clip(text, output, speaker, SAMPLE_RATE)

    print("[bark] Done.", flush=True)


if __name__ == "__main__":
    main()
