#!/usr/bin/env node

/**
 * CLI entry point for AlphaSix Video Generation Process.
 *
 * Orchestrates a three-stage pipeline:
 *   1. Voice — generate narration audio clips with Piper TTS
 *   2. Record — drive a headless browser through scripted steps
 *   3. Compose — merge the screen recording with narration audio
 *
 * Usage:
 *   node generate.js <video-name>     # Generate one video
 *   node generate.js --all            # Generate all videos
 *   node generate.js <video-name> --no-cache  # Skip voice cache, regenerate all clips
 */

import { readFile, readdir, stat } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import yaml from 'js-yaml';
import { generateVoice } from './lib/voice.js';
import { record } from './lib/recorder.js';
import { compose } from './lib/composer.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));

// ---------------------------------------------------------------------------
// Config & script loading
// ---------------------------------------------------------------------------

/**
 * Load the global config.yaml from the demo-videos directory.
 *
 * @returns {Promise<Object>} Parsed global config with `_configPath` attached
 */
async function loadConfig() {
  const configPath = path.join(__dirname, 'config.yaml');
  const raw = await readFile(configPath, 'utf-8');
  const config = yaml.load(raw);
  config._configPath = configPath;
  return config;
}

/**
 * Load a video's script.yaml from its directory.
 *
 * @param {string} videoDir - Absolute path to the video directory
 * @returns {Promise<Object>} Parsed script with `meta` and `steps`
 */
async function loadScript(videoDir) {
  const scriptPath = path.join(videoDir, 'script.yaml');
  const raw = await readFile(scriptPath, 'utf-8');
  return yaml.load(raw);
}

/**
 * Merge global config defaults with per-script meta overrides.
 *
 * Per-script meta can override defaults like viewport, baseUrl, voice, etc.
 * Global-only keys (credentials, paths, pronunciations) are always preserved
 * from the global config and cannot be overridden per-script.
 *
 * @param {Object} globalConfig - Parsed global config.yaml
 * @param {Object} scriptMeta - The `meta` section from a script.yaml (may be undefined)
 * @returns {Object} Merged config ready for pipeline stages
 */
function mergeConfig(globalConfig, scriptMeta) {
  return {
    ...globalConfig.defaults,
    ...scriptMeta,
    credentials: globalConfig.credentials,
    paths: globalConfig.paths,
    pronunciations: globalConfig.pronunciations,
    _configPath: globalConfig._configPath,
  };
}

// ---------------------------------------------------------------------------
// Video generation
// ---------------------------------------------------------------------------

/**
 * Generate a single demo video through the three-stage pipeline.
 *
 * @param {string} videoName - Directory name under src/demo-videos/
 * @param {Object} globalConfig - Parsed global config
 */
async function generateVideo(videoName, globalConfig) {
  const videoDir = path.join(__dirname, videoName);
  const outputDir = path.join(videoDir, 'output');

  const script = await loadScript(videoDir);
  const config = mergeConfig(globalConfig, script.meta);
  config._videoDir = videoDir;

  console.log(`\n=== Generating: ${videoName} ===\n`);

  // Stage 1: Voice — generate narration audio clips (skip in visual-only mode)
  let timeline = [];
  if (!config.visualOnly) {
    timeline = await generateVoice(script.steps, outputDir, config);
  } else {
    console.log('[generate] Visual-only mode — skipping voice generation');
  }

  // Stage 2: Record — drive browser and capture screen recording
  const { videoPath, audioOffsets } = await record(script.steps, timeline, outputDir, config);

  // Stage 3: Compose — merge video with narration audio
  const finalPath = await compose(videoPath, timeline, script.steps, outputDir, config, audioOffsets);

  console.log(`\n=== Done: ${finalPath} ===\n`);
}

// ---------------------------------------------------------------------------
// Discovery
// ---------------------------------------------------------------------------

/**
 * Find all video directories (those containing a script.yaml file).
 *
 * @returns {Promise<string[]>} Array of directory names
 */
async function findAllVideos() {
  const entries = await readdir(__dirname, { withFileTypes: true });
  const videos = [];

  for (const entry of entries) {
    if (!entry.isDirectory()) continue;
    if (entry.name === 'node_modules' || entry.name === 'lib' || entry.name === 'bundle-patches') continue;

    if (entry.name === 'examples') {
      // Scan inside examples/ for video subdirectories
      const exEntries = await readdir(path.join(__dirname, 'examples'), { withFileTypes: true });
      for (const ex of exEntries) {
        if (!ex.isDirectory()) continue;
        try {
          const scriptPath = path.join(__dirname, 'examples', ex.name, 'script.yaml');
          await stat(scriptPath);
          videos.push(path.join('examples', ex.name));
        } catch {
          // No script.yaml — skip
        }
      }
      continue;
    }

    try {
      const scriptPath = path.join(__dirname, entry.name, 'script.yaml');
      await stat(scriptPath);
      videos.push(entry.name);
    } catch {
      // No script.yaml — skip this directory
    }
  }

  return videos.sort();
}

// ---------------------------------------------------------------------------
// Main
// ---------------------------------------------------------------------------

async function main() {
  const args = process.argv.slice(2);
  const flags = args.filter((a) => a.startsWith('--'));
  const positional = args.filter((a) => !a.startsWith('--'));

  if (positional.length === 0 && !flags.includes('--all')) {
    console.log('Usage:');
    console.log('  node generate.js <video-name>                Generate one video');
    console.log('  node generate.js --all                       Generate all videos');
    console.log('  node generate.js <video-name> --no-cache     Skip voice cache');
    console.log('  node generate.js <video-name> --visual-only  Skip voice, video only');
    process.exit(1);
  }

  const globalConfig = await loadConfig();

  if (flags.includes('--no-cache')) {
    globalConfig.defaults = globalConfig.defaults || {};
    globalConfig.defaults.noCache = true;
  }

  if (flags.includes('--visual-only')) {
    globalConfig.defaults = globalConfig.defaults || {};
    globalConfig.defaults.visualOnly = true;
  }

  if (flags.includes('--all')) {
    const videos = await findAllVideos();
    if (videos.length === 0) {
      console.log('No video directories found (no script.yaml files).');
      process.exit(0);
    }
    console.log(`Found ${videos.length} video(s): ${videos.join(', ')}`);
    for (const videoName of videos) {
      await generateVideo(videoName, globalConfig);
    }
  } else {
    const videoName = positional[0];
    await generateVideo(videoName, globalConfig);
  }
}

main().catch((err) => {
  console.error(err);
  process.exit(1);
});
