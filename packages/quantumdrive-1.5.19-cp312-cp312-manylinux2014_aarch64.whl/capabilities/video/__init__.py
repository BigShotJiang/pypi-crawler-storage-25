"""QuantumDrive video generation services."""

from __future__ import annotations

from core.ai.capability_agent import CapabilityAgent
from core.ai.q_request_type_registry import RequestTypeRegistry

from .models import (
    BatchVideoResult,
    InteractionSpec,
    SceneSpec,
    SceneType,
    TTSEngine,
    VideoArtifact,
    VideoAudience,
    VideoDiagnostics,
    VideoRequest,
    VideoResult,
    VideoType,
)
from .provenance import (
    link_video_to_source,
    record_video_artifact,
    record_video_generation,
)
from .agents import MarketingAgent, MarketingOutputContract, TrainingAgent, TrainingOutputContract
from .diagram_generator import DiagramGenerator
from .q_video_planner import KGQueryFn, LLMRefineFn, QVideoPlanner
from .q_video_renderer import QVideoRenderer
from .q_video_script_generator import QVideoScriptGenerator
from .q_video_service import QVideoService, get_q_video_service
from .video_generation_tool import VideoGenerationTool


RequestTypeRegistry.register(
    "video",
    keywords=(
        "video", "animation", "clip", "narrated", "storyboard", "screencast",
        "marketing video", "training video",
    ),
    backend="flat",
    default_role="video_agent",
)


def _register_video_specialists_with_agentfoundry() -> None:
    """Insert the MarketingAgent / TrainingAgent manifests into AgentFoundry's
    specialist registries at import time.

    AgentFoundry's ``SPECIALIST_TOOL_MANIFESTS`` and
    ``HierarchicalOrchestrator._ROLE_AGENT_MAP`` are closed dicts defined as
    module globals with no public ``register`` API. QuantumDrive capabilities
    that ship their own specialist agents (like video's marketing and training)
    contribute them here so the hierarchical orchestrator can route to them
    and the security layer can scope their tools.
    """
    try:
        from agentfoundry.agents.specialist_manifests import (
            SPECIALIST_TOOL_MANIFESTS,
            SpecialistToolManifest,
        )
        import agentfoundry.agents.hierarchical_orchestrator as _hier
    except Exception:  # pragma: no cover - defensive, AF may not be present during some tooling
        return

    if "marketing" not in SPECIALIST_TOOL_MANIFESTS:
        SPECIALIST_TOOL_MANIFESTS["marketing"] = SpecialistToolManifest(
            role="marketing",
            summary="Plan and generate marketing / sales videos from product context.",
            allowed_tools=("video_generation_tool",),
            authority_level="propose_changes",
            allowed_action_classes=("read", "write"),
            approval_required_actions=("write",),
            required_inputs=("product_context_or_url",),
            environment_requirements=("video_render_runtime",),
            max_recursion=12,
        )
    if "training" not in SPECIALIST_TOOL_MANIFESTS:
        SPECIALIST_TOOL_MANIFESTS["training"] = SpecialistToolManifest(
            role="training",
            summary="Plan and generate training / tutorial videos from task or feature context.",
            allowed_tools=("video_generation_tool",),
            authority_level="propose_changes",
            allowed_action_classes=("read", "write"),
            approval_required_actions=("write",),
            required_inputs=("tutorial_brief_or_steps",),
            environment_requirements=("video_render_runtime",),
            max_recursion=12,
        )

    role_map = getattr(_hier, "_ROLE_AGENT_MAP", None)
    if isinstance(role_map, dict):
        role_map.setdefault("marketing", MarketingAgent)
        role_map.setdefault("training", TrainingAgent)

    handoff = getattr(_hier, "_HANDOFF_ROLE_ORDER", ())
    if isinstance(handoff, tuple):
        extra = tuple(r for r in ("marketing", "training") if r not in handoff)
        if extra:
            _hier._HANDOFF_ROLE_ORDER = handoff + extra
    # The hierarchical decomposer now sources its role list from the
    # ``agent_catalog`` kwarg on ``HierarchicalOrchestrator`` (seeded by
    # QAssistant from the live CapabilityAgent registry). No more
    # ``_DECOMPOSITION_PROMPT`` mutation — capability-contributed roles
    # flow through the catalog.


_register_video_specialists_with_agentfoundry()


def _bootstrap_video(assistant) -> None:
    """Register video-generation tool and CapabilityAgent."""
    qd_config = getattr(assistant, "qd_config", None)
    tool_registry = getattr(assistant, "tool_registry", None)
    logger = getattr(assistant, "logger", None)
    if tool_registry is None:
        return
    try:
        tool = VideoGenerationTool(config=qd_config)
        tool_registry.register_tool(tool.as_tool())
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Video tool registration failed: %s", exc)
        return

    assistant.register_capability_agent(CapabilityAgent(
        role_id="video_agent",
        summary="Script, plan, generate assets for, and render short-form videos (marketing or technical).",
        system_prompt=(
            "You are the Video specialist. Produce audience-appropriate videos: draft scripts, "
            "plan scene-by-scene flow with interactions, generate diagrams as needed, and "
            "render via video_generation_tool. Narration and visuals must stay in sync."
        ),
        tool_names=(
            "video_generation_tool",
            "document_reader", "pdf_creator", "web_search_tool",
            "code_graph_search",
            "save_thread_memory", "search_thread_memory",
            "search_user_memory", "summarize_any_memory",
        ),
        request_types=("video",),
        approval_actions=("write",),
        keywords=("video", "animation", "clip", "narration"),
    ))


from core.ai.q_assistant import QAssistant as _QAssistant  # noqa: E402

_QAssistant.register_bootstrap_hook(_bootstrap_video)


__all__ = [
    "InteractionSpec",
    "SceneSpec",
    "SceneType",
    "TTSEngine",
    "VideoArtifact",
    "VideoAudience",
    "VideoDiagnostics",
    "VideoRequest",
    "VideoResult",
    "VideoType",
    "MarketingAgent",
    "MarketingOutputContract",
    "TrainingAgent",
    "TrainingOutputContract",
    "BatchVideoResult",
    "DiagramGenerator",
    "KGQueryFn",
    "LLMRefineFn",
    "QVideoPlanner",
    "QVideoRenderer",
    "QVideoScriptGenerator",
    "QVideoService",
    "VideoGenerationTool",
    "get_q_video_service",
    "link_video_to_source",
    "record_video_artifact",
    "record_video_generation",
]
