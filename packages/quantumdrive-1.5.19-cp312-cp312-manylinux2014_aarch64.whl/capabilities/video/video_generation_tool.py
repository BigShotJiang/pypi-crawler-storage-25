"""Tool wrapper for QuantumDrive video generation."""

from __future__ import annotations

import logging
from pathlib import Path
from typing import List, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field

from capabilities.video.models import (
    TTSEngine,
    VideoAudience,
    VideoRequest,
    VideoType,
)
from capabilities.video.q_video_service import (
    QVideoService,
    get_q_video_service,
)
from core.config import QDConfig

logger = logging.getLogger(__name__)


class VideoGenerationInput(BaseModel):
    title: str = Field(..., description="Video title.")
    video_type: str = Field(
        VideoType.MARKETING.value,
        description="Video type: marketing, sales_demo, tutorial, architecture_overview, or delivery_status.",
    )
    audience: str = Field(
        VideoAudience.TECHNICAL.value,
        description="Target audience: technical, executive, sales, or end_user.",
    )
    tts_engine: str = Field(
        TTSEngine.OPENAI.value,
        description="TTS engine: openai, piper, or bark.",
    )
    voice: str = Field("sage", description="TTS voice identifier.")
    theme: str = Field("dark", description="Visual theme.")
    base_url: str = Field(
        "",
        description="Web app URL for walkthroughs. Empty for diagram-only videos.",
    )
    content_brief: Optional[str] = Field(
        None,
        description="Free-form brief describing what the video should cover.",
    )
    bullets: List[str] = Field(
        default_factory=list,
        description="Key points to narrate.",
    )
    project_id: Optional[str] = Field(None, description="Project scope id.")
    repo_id: Optional[str] = Field(None, description="Repository scope id.")
    bounded_context: Optional[str] = Field(None, description="Optional bounded context.")
    environment: Optional[str] = Field(None, description="Optional environment label.")
    source_presentation_path: Optional[str] = Field(
        None,
        description="Path to existing presentation spec to convert to video.",
    )
    source_doc_paths: List[str] = Field(
        default_factory=list,
        description="Paths to documentation files to convert to video scenes.",
    )
    visual_only: bool = Field(
        False,
        description="Generate video without audio.",
    )


class VideoGenerationTool:
    """Expose video generation to the agent tool registry."""

    def __init__(
        self,
        config: QDConfig | None = None,
        *,
        service: QVideoService | None = None,
        project_root: str | Path | None = None,
    ) -> None:
        self.config = config or QDConfig.from_toml()
        self.service = service or get_q_video_service(
            self.config,
            project_root=project_root,
        )
        logger.debug(
            "Initialized VideoGenerationTool service=%s project_root=%s",
            type(self.service).__name__,
            project_root,
        )

    def generate(
        self,
        title: str,
        video_type: str = VideoType.MARKETING.value,
        audience: str = VideoAudience.TECHNICAL.value,
        tts_engine: str = TTSEngine.OPENAI.value,
        voice: str = "sage",
        theme: str = "dark",
        base_url: str = "",
        content_brief: Optional[str] = None,
        bullets: Optional[List[str]] = None,
        project_id: Optional[str] = None,
        repo_id: Optional[str] = None,
        bounded_context: Optional[str] = None,
        environment: Optional[str] = None,
        source_presentation_path: Optional[str] = None,
        source_doc_paths: Optional[List[str]] = None,
        visual_only: bool = False,
    ) -> dict:
        logger.info(
            "VideoGenerationTool invoked title=%r video_type=%s audience=%s",
            title,
            video_type,
            audience,
        )

        if source_presentation_path:
            result = self.service.generate_from_presentation(
                presentation_path=source_presentation_path,
                title=title,
                video_type=VideoType(video_type),
                audience=VideoAudience(audience),
                tts_engine=TTSEngine(tts_engine),
            )
        elif source_doc_paths:
            result = self.service.generate_from_docs(
                doc_paths=list(source_doc_paths),
                title=title,
                video_type=VideoType(video_type),
                audience=VideoAudience(audience),
                tts_engine=TTSEngine(tts_engine),
            )
        else:
            request = VideoRequest(
                title=title,
                video_type=VideoType(video_type),
                audience=VideoAudience(audience),
                tts_engine=TTSEngine(tts_engine),
                voice=voice,
                theme=theme,
                base_url=base_url,
                content_brief=content_brief,
                bullets=list(bullets or []),
                project_id=project_id,
                repo_id=repo_id,
                bounded_context=bounded_context,
                environment=environment,
                visual_only=visual_only,
            )
            result = self.service.generate_video(request)

        logger.info(
            "VideoGenerationTool completed title=%r ok=%s scene_count=%d",
            title,
            result.ok,
            result.scene_count,
        )
        return result.as_dict()

    def as_tool(self) -> StructuredTool:
        return StructuredTool.from_function(
            func=self.generate,
            name="video_generation_tool",
            description=(
                "Generate a video from a structured request. "
                "Supports marketing, sales demo, tutorial, architecture overview, "
                "and delivery status videos. Can also convert an existing presentation "
                "into a narrated video. Returns artifact paths, diagnostics, and renderer output."
            ),
            args_schema=VideoGenerationInput,
        )
