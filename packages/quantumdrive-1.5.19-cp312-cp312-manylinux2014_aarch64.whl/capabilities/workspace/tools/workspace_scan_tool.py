"""Langchain tool over :meth:`QWorkspaceService.inspect_repository`.

Produces a summary profile of a repository — branch, commit, tracked/untracked
file counts, top-level directories, language breakdown — for the workspace
agent to reason over.
"""

from __future__ import annotations

from typing import Callable, Optional

from langchain_core.tools import StructuredTool
from pydantic import BaseModel, Field


class WorkspaceScanInput(BaseModel):
    repo_id: str = Field(..., description="Logical repository identifier (free-form; used for attribution).")
    repo_root: Optional[str] = Field(
        default=None,
        description="Filesystem path to the repo. If omitted, the tool asks the workspace service to resolve repo_id.",
    )


def _serialize_profile(profile) -> dict:
    return {
        "repo_id": profile.repo_id,
        "repo_root": profile.repo_root,
        "is_git_repo": bool(profile.is_git_repo),
        "branch": profile.branch,
        "commit_sha": profile.commit_sha,
        "tracked_file_count": profile.tracked_file_count,
        "untracked_file_count": profile.untracked_file_count,
        "sample_files": list(profile.sample_files),
        "top_level_dirs": dict(profile.top_level_dirs),
        "extensions": dict(profile.extensions),
    }


class WorkspaceScanTool:
    """Repository-inspection tool — lightweight wrapper over QWorkspaceService."""

    @classmethod
    def create_tool(
        cls,
        *,
        service_factory: Callable[[], "object"],
    ) -> StructuredTool:

        def _scan(repo_id: str, repo_root: Optional[str] = None) -> dict:
            service = service_factory()
            resolved_root = repo_root or service.resolve_repo_root(repo_id)
            if not resolved_root:
                return {"error": f"Could not resolve repo root for repo_id={repo_id!r}."}
            try:
                profile = service.inspect_repository(repo_id=repo_id, repo_root=resolved_root)
            except FileNotFoundError as exc:
                return {"error": str(exc)}
            return _serialize_profile(profile)

        return StructuredTool.from_function(
            func=_scan,
            name="workspace_scan",
            description=(
                "Inspect a repository and return a profile: branch, commit, file counts, "
                "top-level directories, and language-extension breakdown."
            ),
            args_schema=WorkspaceScanInput,
        )
