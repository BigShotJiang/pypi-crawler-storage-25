"""Langchain tool wrappers for the workspace capability."""

from __future__ import annotations

from capabilities.workspace.tools.workspace_scan_tool import WorkspaceScanTool

__all__ = ["WorkspaceScanTool"]
