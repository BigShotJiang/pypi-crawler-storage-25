"""
Workspace and artifact services for QuantumDrive delivery execution.
"""

from __future__ import annotations

from core.ai.capability_agent import CapabilityAgent
from core.ai.q_request_type_registry import RequestTypeRegistry

from capabilities.workspace.q_workspace_service import (
    QWorkspaceService,
    RepositoryIngestionResult,
    WaveWorkspaceCapture,
    WorkspaceOnboardingInventory,
    WorkspaceRepositoryProfile,
    WorkspaceRepositorySpec,
    get_q_workspace_service,
)


RequestTypeRegistry.register(
    "workspace",
    keywords=(
        "workspace", "scan repository", "inspect repo", "onboard repo",
        "repository profile", "repo inventory",
    ),
    backend="flat",
    default_role="workspace_agent",
)


def _bootstrap_workspace(assistant) -> None:
    """Register workspace tool wrapper + CapabilityAgent."""
    qd_config = getattr(assistant, "qd_config", None)
    af_config = getattr(assistant, "af_config", None)
    tool_registry = getattr(assistant, "tool_registry", None)
    logger = getattr(assistant, "logger", None)
    if tool_registry is None:
        return
    try:
        from capabilities.workspace.tools import WorkspaceScanTool

        def _factory() -> QWorkspaceService:
            return get_q_workspace_service(qd_config, agent_config=af_config)

        tool_registry.register_tool(WorkspaceScanTool.create_tool(service_factory=_factory))
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Workspace tool registration failed: %s", exc)
        return

    assistant.register_capability_agent(CapabilityAgent(
        role_id="workspace_agent",
        summary="Scan and profile repositories — branches, file counts, language mix, top-level structure.",
        system_prompt=(
            "You are the Workspace specialist. Inspect repositories to profile their "
            "structure, language mix, and state. Surface concise findings other agents "
            "can use as context for planning or analysis."
        ),
        tool_names=(
            "workspace_scan",
            "document_reader", "unzip_tool",
            "code_graph_search",
            "save_thread_memory", "search_thread_memory",
            "search_user_memory", "summarize_any_memory",
        ),
        request_types=("workspace",),
        keywords=("workspace", "repository", "repo", "inventory"),
    ))


from core.ai.q_assistant import QAssistant as _QAssistant  # noqa: E402

_QAssistant.register_bootstrap_hook(_bootstrap_workspace)


__all__ = [
    "QWorkspaceService",
    "RepositoryIngestionResult",
    "WaveWorkspaceCapture",
    "WorkspaceOnboardingInventory",
    "WorkspaceRepositoryProfile",
    "WorkspaceRepositorySpec",
    "get_q_workspace_service",
]
