"""QuantumDrive Threat Mitigation subsystem.

Provides the TMAPI — a service-to-service REST API that Qato (the AlphaSix
Cyber Analysis product) calls to trigger real-time security mitigations once
threats have been identified.

Phased roll-out:
  Phase 1 — Job lifecycle: models, job store, audit service, Flask Blueprint.
  Phase 2 — Tool execution: port lockdown, IP blacklist, patching, quarantine, etc.
  Phase 3 — Approval workflow integration via the existing KGraph approval system.
  Phase 4 — AI strategy: QAssistant reasoning for let_agent_decide=True requests.
  Phase 5 — Lab environment branches (per-tool ``_execute_lab`` paths) and
            optional PQ-signed completion webhooks (``X-QuantumDrive-Signature``).
"""

from __future__ import annotations

from core.ai.capability_agent import CapabilityAgent
from core.ai.q_request_type_registry import RequestTypeRegistry


# Request type contributed by this capability — routed to threat_mitigation_agent.
RequestTypeRegistry.register(
    "threat_response",
    keywords=(
        "threat", "mitigation", "mitigate", "incident", "isolate",
        "block ip", "quarantine", "port lockdown", "dns block", "patch vulnerability",
    ),
    backend="flat",
    default_role="threat_mitigation_agent",
)


# Tool names produced by MitigationService.get_registered_tools().
_MITIGATION_TOOL_NAMES = (
    "port_lockdown",
    "ip_blacklist",
    "dns_block",
    "patch",
    "service_quarantine",
    "evidence_capture",
    "credential_rotation",
    "alert_escalation",
    "traffic_block",
)


def _bootstrap_threat_mitigation(assistant) -> None:
    """Register mitigation tools + CapabilityAgent on a QAssistant.

    Invoked by ``QAssistant.__init__`` via the bootstrap-hook registry. No
    action is taken unless ``qd_config.threat_mitigation.enabled`` is true.
    When enabled, registers the 9 mitigation tools plus a capability agent
    that owns them.
    """
    qd_config = getattr(assistant, "qd_config", None)
    logger = getattr(assistant, "logger", None)
    tool_registry = getattr(assistant, "tool_registry", None)
    if qd_config is None or tool_registry is None:
        return
    cfg = getattr(qd_config, "threat_mitigation", None)
    if not cfg or not getattr(cfg, "enabled", False):
        return
    try:
        from capabilities.threat_mitigation.mitigation_service import MitigationService
        from capabilities.threat_mitigation.job_store import MitigationJobStore
        from capabilities.threat_mitigation.audit_service import MitigationAuditService

        job_store = MitigationJobStore(
            store_path=qd_config.threat_mitigation_job_store_path,
            approval_required_actions=set(cfg.approval_required_actions),
        )
        audit = MitigationAuditService(
            audit_log_path=qd_config.threat_mitigation_audit_log_path,
        )
        mit_svc = MitigationService(job_store=job_store, audit=audit, config=qd_config)
        mit_tools = mit_svc.get_registered_tools()
        for tool in mit_tools:
            tool_registry.register_tool(tool)
        if logger:
            logger.info("Threat mitigation tools registered (%d tools).", len(mit_tools))
    except Exception as exc:  # pragma: no cover - defensive
        if logger:
            logger.warning("Threat mitigation tool registration failed: %s", exc)
        return

    assistant.register_capability_agent(CapabilityAgent(
        role_id="threat_mitigation_agent",
        summary="Execute real-time security mitigations (TMAPI) — port lockdown, IP blacklist, patching, quarantine, etc.",
        system_prompt=(
            "You are the Threat Mitigation specialist, invoked by Qato or a human operator "
            "when a threat has been identified. Select the minimum-viable combination of "
            "mitigation actions that contains the threat without unnecessary collateral "
            "damage. Every mutating action requires approval — surface the plan clearly "
            "before execution."
        ),
        tool_names=_MITIGATION_TOOL_NAMES + ("system_introspection", "current_date_time_tool"),
        request_types=("threat_response",),
        approval_actions=("mitigate", "write", "deploy"),
        keywords=("threat", "mitigation", "incident", "isolate", "quarantine"),
    ))


# Register the bootstrap hook so every newly-constructed QAssistant evaluates
# whether to wire the threat-mitigation tools. Import-deferred to avoid cycles.
from core.ai.q_assistant import QAssistant as _QAssistant  # noqa: E402

_QAssistant.register_bootstrap_hook(_bootstrap_threat_mitigation)


__all__ = ["_bootstrap_threat_mitigation"]
