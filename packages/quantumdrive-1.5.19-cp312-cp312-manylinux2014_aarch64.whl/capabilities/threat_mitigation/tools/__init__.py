"""Threat mitigation tool implementations.

Each tool class exposes an ``as_tool()`` method that returns a LangChain
``StructuredTool`` for registration in the AgentFoundry tool registry.

Phase 2 will add the concrete tool implementations:
  port_lockdown_tool.py     — AWS SG / iptables
  ip_blacklist_tool.py      — WAF + NACL + fail2ban / /etc/hosts
  patch_tool.py             — SSM RunCommand / apt-get
  quarantine_tool.py        — ECS stop_task / docker stop / systemctl
  credential_rotation_tool.py — IAM key + SecretsManager rotation
  traffic_block_tool.py     — WAF rate rules / iptables rate-limit
  dns_block_tool.py         — Route53 / hosts file + dnsmasq sinkhole
  alert_escalation_tool.py  — SNS + Slack + PagerDuty
  evidence_capture_tool.py  — CloudWatch logs + EBS snapshots + netstat
"""
