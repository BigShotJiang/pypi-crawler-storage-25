"""Pydantic models and audit dataclass for the Threat Mitigation subsystem."""

from __future__ import annotations

from dataclasses import asdict, dataclass, field
from datetime import datetime, timezone
from enum import Enum
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, Field


# ── Enumerations ──────────────────────────────────────────────────────────────

class ThreatSeverity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"
    CRITICAL = "critical"


class MitigationAction(str, Enum):
    PORT_LOCKDOWN        = "port_lockdown"
    IP_BLACKLIST         = "ip_blacklist"
    PATCH                = "patch"
    SERVICE_QUARANTINE   = "service_quarantine"
    CREDENTIAL_ROTATION  = "credential_rotation"
    TRAFFIC_BLOCK        = "traffic_block"
    DNS_BLOCK            = "dns_block"
    ALERT_ESCALATION     = "alert_escalation"
    EVIDENCE_CAPTURE     = "evidence_capture"


class JobStatus(str, Enum):
    QUEUED           = "queued"
    PENDING_APPROVAL = "pending_approval"
    RUNNING          = "running"
    COMPLETED        = "completed"
    FAILED           = "failed"
    ROLLING_BACK     = "rolling_back"
    ROLLED_BACK      = "rolled_back"
    INTERRUPTED      = "interrupted"


# ── Request models ────────────────────────────────────────────────────────────

class TargetSpec(BaseModel):
    """Specifies the assets/resources that mitigation actions should target."""

    ports: Optional[List[int]] = None
    """TCP/UDP ports to lock down."""

    ips: Optional[List[str]] = None
    """IPv4/IPv6 addresses or CIDR blocks to blacklist."""

    instance_id: Optional[str] = None
    """AWS EC2 instance ID (e.g. i-0abc1234)."""

    sg_id: Optional[str] = None
    """AWS Security Group ID (e.g. sg-0def5678)."""

    nacl_id: Optional[str] = None
    """AWS Network ACL ID."""

    web_acl_arn: Optional[str] = None
    """AWS WAF Web ACL ARN for traffic blocking rules."""

    container_id: Optional[str] = None
    """Docker container ID or ECS task ARN to quarantine."""

    service_name: Optional[str] = None
    """Systemd service name to stop/isolate."""

    hostname: Optional[str] = None
    """Hostname for DNS-based blocks or remote commands."""

    package_names: Optional[List[str]] = None
    """Package names to patch (e.g. ['openssl', 'curl'])."""

    secret_arns: Optional[List[str]] = None
    """AWS Secrets Manager ARNs for credential rotation."""

    hosted_zone_id: Optional[str] = None
    """Route53 hosted zone ID for DNS-based blocks."""


class MitigationRequest(BaseModel):
    """Inbound request from Qato asking QD to execute one or more mitigations."""

    threat_id: str
    """Qato's unique identifier for the threat that triggered this request."""

    threat_summary: str
    """Human-readable summary of the threat (used for audit and AI strategy)."""

    severity: ThreatSeverity
    """Threat severity level."""

    environment: str = "aws"
    """Target environment: 'aws', 'lab', or 'hybrid'."""

    requested_actions: List[MitigationAction]
    """Ordered list of mitigation actions to execute."""

    targets: TargetSpec = Field(default_factory=TargetSpec)
    """Resources the actions should be applied to."""

    rollback_on_failure: bool = True
    """If True, completed actions are reversed when any subsequent action fails."""

    webhook_url: Optional[str] = None
    """URL for QD to POST a completion/failure notification to Qato."""

    let_agent_decide: bool = False
    """If True, ignore requested_actions and let QAssistant derive the strategy."""


# ── Job models ────────────────────────────────────────────────────────────────

class MitigationJob(BaseModel):
    """Runtime state of a mitigation job, persisted in the JSONL job store."""

    job_id: str
    """Unique job identifier: 'mitigation:{threat_id}:{epoch_ms}'."""

    threat_id: str
    """Mirrors MitigationRequest.threat_id for quick filtering."""

    request: MitigationRequest
    """The original request from Qato."""

    status: JobStatus = JobStatus.QUEUED

    requires_approval: bool = False
    """True when any requested action is in the approval-required set."""

    approval_request_id: Optional[str] = None
    """KGraph approval node ID created by MitigationApprovalBridge (Phase 3)."""

    actions_completed: List[str] = Field(default_factory=list)
    """Action values that have completed successfully."""

    actions_pending: List[str] = Field(default_factory=list)
    """Action values that have not yet started."""

    actions_failed: List[str] = Field(default_factory=list)
    """Action values that failed."""

    rollback_state: Dict[str, Any] = Field(default_factory=dict)
    """Pre-action state captured for rollback, keyed by action value."""

    agent_reasoning: Optional[str] = None
    """QAssistant's strategy reasoning (populated when let_agent_decide=True)."""

    requested_by: str = "qato"
    """Caller identity — always 'qato' for Qato-initiated jobs."""

    started_at: Optional[str] = None
    """ISO-8601 UTC timestamp when the job transitioned to RUNNING."""

    completed_at: Optional[str] = None
    """ISO-8601 UTC timestamp when the job reached a terminal status."""

    error: Optional[str] = None
    """Error message if the job failed."""


# ── Audit dataclass ───────────────────────────────────────────────────────────

@dataclass
class MitigationAuditEvent:
    """Single audit event written as a JSONL line to the audit log."""

    event_type: str
    """
    One of:
      job_created | action_started | action_completed | action_failed |
      rollback_requested | rollback_completed | job_completed | job_failed
    """

    job_id: str
    threat_id: str
    environment: str
    requested_by: str
    status: str

    action: Optional[str] = None
    """Populated for action-level events."""

    detail: Dict[str, Any] = field(default_factory=dict)
    """Arbitrary event-specific metadata (no secrets)."""

    created_at: str = field(
        default_factory=lambda: datetime.now(timezone.utc).isoformat()
    )

    def as_dict(self) -> Dict[str, Any]:
        return asdict(self)
