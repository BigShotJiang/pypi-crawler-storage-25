"""Application-specific capabilities layered on top of the QuantumDrive core."""

from __future__ import annotations
