"""QuantumDrive core module initialization."""

from __future__ import annotations

import os
import sys


class LicenseError(RuntimeError):
    """Custom error for license issues."""
    pass


# Skip license enforcement for development by default
os.environ.setdefault('QUANTUMDRIVE_ENFORCE_LICENSE', '0')

# Import license modules only if enforcement is enabled
if os.getenv('QUANTUMDRIVE_ENFORCE_LICENSE', '0') != '0':
    try:
        from core.license.license import enforce_license as _qd_enforce_license
        _qd_enforce_license()
    except Exception as _lic_err:
        raise LicenseError(f"{_lic_err}") from _lic_err


def __getattr__(name: str):
    """Lazy import of license-related attributes."""
    if name in {"enforce_license", "get_machine_id", "verify_license"}:
        from core.license.license import enforce_license, get_machine_id, verify_license
        return {"enforce_license": enforce_license, "get_machine_id": get_machine_id, "verify_license": verify_license}[name]
    if name in {"KeyManager", "get_license_key"}:
        from core.license.key_manager import KeyManager, get_license_key
        return {"KeyManager": KeyManager, "get_license_key": get_license_key}[name]
    raise AttributeError(name)


__all__ = ["LicenseError"]
