"""
QuantumDrive Configuration Module

This module provides configuration handling for QuantumDrive. It accepts
configuration dictionaries from host applications (like Quantify) and
extracts the appropriate subsets for QuantumDrive and AgentForge components.

Configuration Namespaces:
- QD_* : QuantumDrive-specific settings
- AF_* : AgentForge settings (passed through to AgentForge)
"""

from __future__ import annotations

import logging
import os
import warnings
from importlib import resources as importlib_resources
from pathlib import Path
from typing import Any, Dict, Optional

from pydantic import BaseModel, ConfigDict, Field, SecretStr

logger = logging.getLogger(__name__)


def _pydantic_ignored_marker():
    """Helper used to capture the runtime function descriptor type.

    In source builds this is a normal Python ``function``. In compiled wheel
    builds it may be a Cython ``cython_function_or_method``. Pydantic 2 must be
    told to ignore that descriptor type when inspecting ``BaseModel``
    subclasses, otherwise model methods can be misclassified as fields.
    """


_PYDANTIC_IGNORED_TYPES = (
    type(_pydantic_ignored_marker),
    classmethod,
    staticmethod,
    property,
)

try:
    import tomli
except ImportError:
    try:
        import tomllib as tomli  # Python 3.11+
    except ImportError:
        tomli = None  # type: ignore


class QDMicrosoftConfig(BaseModel):
    """Microsoft 365 / Entra ID configuration."""
    tenant_id: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[SecretStr] = None
    redirect_uri: Optional[str] = None
    scopes: Optional[str | list[str]] = None  # JSON array or comma-separated
    token_cache_file: Optional[str] = None


class QDConfig(BaseModel):
    """
    QuantumDrive configuration object.
    
    This is the standard way to configure QuantumDrive components. Host applications
    (like Quantify) should create a QDConfig and pass it to QuantumDrive entry points.
    """
    # Microsoft 365 / SSO
    microsoft: QDMicrosoftConfig = Field(default_factory=QDMicrosoftConfig)
    
    # Flask settings (if using webapp)
    flask_debug: bool = False
    flask_port: int = 5000
    flask_secret_key: Optional[SecretStr] = None
    
    # Legacy vector-store hints kept for backward compatibility with older configs.
    vector_collection_name: str = "quantumdrive"
    embedding_model_name: str = "sentence-transformers/all-MiniLM-L6-v2"
    
    # Data directory
    data_dir: Optional[str] = None
    
    # Raw config dict for passthrough to AgentForge
    raw_config: Dict[str, Any] = Field(default_factory=dict, exclude=True)
    
    model_config = ConfigDict(
        arbitrary_types_allowed=True,
        ignored_types=_PYDANTIC_IGNORED_TYPES,
    )

    @classmethod
    def from_dict(cls, config: Dict[str, Any], prefix: str = "QD_") -> "QDConfig":
        """
        Create QDConfig from a flat dictionary with prefixed keys.
        
        This is the primary factory method for host applications like Quantify
        that load configuration from secrets backends and TOML files.
        
        Args:
            config: Flat dictionary with prefixed keys (e.g., QD_MS_TENANT_ID)
            prefix: Key prefix to strip (default: "QD_")
        
        Returns:
            QDConfig instance
        
        Example:
            config = {
                'QD_MS_TENANT_ID': '...',
                'QD_MS_CLIENT_ID': '...',
                'QD_MS_CLIENT_SECRET': '...',
                'AF_OPENAI_API_KEY': 'sk-...',
                'AF_LLM_PROVIDER': 'openai',
            }
            qd_config = QDConfig.from_dict(config)
        """
        def get(key: str, default=None):
            """Get value with or without prefix."""
            return config.get(f"{prefix}{key}") or config.get(key) or default
        
        def get_secret(key: str) -> Optional[SecretStr]:
            """Get value as SecretStr if present."""
            val = get(key)
            return SecretStr(val) if val else None
        
        return cls(
            microsoft=QDMicrosoftConfig(
                tenant_id=get("MS_TENANT_ID"),
                client_id=get("MS_CLIENT_ID"),
                client_secret=get_secret("MS_CLIENT_SECRET"),
                redirect_uri=get("MS_REDIRECT_URI"),
                scopes=get("MS_SCOPES"),
                token_cache_file=get("MS_TOKEN_CACHE_FILE"),
            ),
            flask_debug=str(get("FLASK_DEBUG", "false")).lower() in ("true", "1", "yes"),
            flask_port=int(get("FLASK_PORT", 5000)),
            flask_secret_key=get_secret("FLASK_SECRET_KEY"),
            vector_collection_name=get("VECTOR_COLLECTION_NAME", get("CHROMA_COLLECTION_NAME", "quantumdrive")),
            embedding_model_name=get("EMBEDDING_MODEL_NAME", "sentence-transformers/all-MiniLM-L6-v2"),
            data_dir=get("DATA_DIR"),
            raw_config=config,
        )

    @classmethod
    def from_env(cls) -> "QDConfig":
        """
        Create QDConfig from environment variables.
        
        This is for backward compatibility and standalone usage.
        """
        config = {k: v for k, v in os.environ.items()}
        return cls.from_dict(config, prefix="QD_")
    
    @classmethod
    def from_toml(cls, toml_path: Optional[str] = None) -> "QDConfig":
        """
        Create QDConfig from TOML file.
        
        Loads configuration from TOML file and merges with environment variables.
        Environment variables take precedence over TOML values.
        
        Args:
            toml_path: Path to TOML file. If None, searches for (in order):
                1. ./quantumdrive.toml (project root)
                2. ~/.config/quantumdrive/quantumdrive.toml (user config)
                3. quantumdrive/resources/default_quantumdrive.toml (built-in default)
        
        Returns:
            QDConfig instance
        """
        if tomli is None:
            logger.warning("tomli/tomllib not available; falling back to environment variables")
            return cls.from_env()
        
        # Determine TOML file path
        if toml_path is None:
            # Check explicit config file env vars first.
            env_config = os.environ.get("QUANTUMDRIVE_CONFIG_FILE") or os.environ.get("AGENTFOUNDRY_CONFIG_FILE")
            if env_config and Path(env_config).is_file():
                toml_path = env_config
                logger.info(f"Loading config from env override: {toml_path}")
        if toml_path is None:
            # Try project root first (for development)
            project_config = Path.cwd() / "quantumdrive.toml"
            if project_config.exists():
                toml_path = str(project_config)
                logger.info(f"Loading config from project root: {toml_path}")
            else:
                # Try user config directory
                user_config = Path.home() / ".config" / "quantumdrive" / "quantumdrive.toml"
                if user_config.exists():
                    toml_path = str(user_config)
                    logger.info(f"Loading config from user directory: {toml_path}")
                else:
                    default_config = Path(__file__).parent.parent.parent / "resources" / "default_quantumdrive.toml"
                    if default_config.exists():
                        toml_path = str(default_config)
                        logger.info(f"Loading config from source default file: {toml_path}")
                    else:
                        try:
                            packaged_default = (
                                importlib_resources.files("core.resources") / "default_quantumdrive.toml"
                            )
                            if packaged_default.is_file():
                                toml_path = str(packaged_default)
                                logger.info("Loading config from packaged default file")
                        except (FileNotFoundError, ModuleNotFoundError):
                            toml_path = None

                    if toml_path is None:
                        logger.warning("No TOML config found; using environment variables only")
                        return cls.from_env()
        
        # Load TOML file
        try:
            with open(toml_path, "rb") as f:
                toml_data = tomli.load(f)
            logger.debug(f"Loaded TOML config from {toml_path}")
        except Exception as e:
            logger.error(f"Failed to load TOML file {toml_path}: {e}")
            return cls.from_env()
        
        # Flatten TOML structure to match expected format
        flat_config = cls._flatten_toml(toml_data)
        
        # Merge with environment variables (env vars take precedence)
        for key, value in os.environ.items():
            flat_config[key] = value
        
        return cls.from_dict(flat_config, prefix="QD_")
    
    @staticmethod
    def _flatten_toml(data: Dict[str, Any], parent_key: str = "") -> Dict[str, Any]:
        """
        Flatten nested TOML structure to flat dictionary with prefixes.
        
        Example:
            {"MICROSOFT": {"TENANT_ID": "..."}} -> {"QD_MS_TENANT_ID": "..."}
            {"AF_LLM": {"PROVIDER": "openai"}} -> {"AF_LLM_PROVIDER": "openai"}
        """
        flat = {}
        
        for key, value in data.items():
            # Build the full key
            if parent_key:
                # Handle special cases for section names
                if parent_key == "MICROSOFT":
                    full_key = f"QD_MS_{key}"
                elif parent_key == "FLASK":
                    full_key = f"QD_FLASK_{key}"
                elif parent_key == "EMBEDDING":
                    full_key = f"QD_EMBEDDING_{key}"
                elif parent_key == "LOGGING":
                    full_key = f"QD_LOG_{key}"
                elif parent_key in (
                    "WEBAPP_LLM",
                    "FEATURES",
                    "PROCESSING",
                    "AWS",
                    "CODE_GRAPH",
                    "VERIFICATION",
                    "CROSS_PROJECT_INSIGHTS",
                    "WORKSPACE",
                    "THREAT_MITIGATION",
                    "QATO_AUTH",
                ):
                    full_key = f"QD_{parent_key}_{key}"
                elif parent_key == "AF_LLM":
                    if key == "PROVIDER":
                        full_key = "AF_LLM_PROVIDER"
                    else:
                        full_key = f"AF_{key}"
                elif parent_key.startswith("AF_"):
                    # AgentForge sections
                    section = parent_key[3:]  # Remove AF_ prefix
                    if section in (
                        "LLM",
                        "PATHS",
                        "VECTORSTORE",
                        "MILVUS",
                        "CHROMA",
                        "FAISS",
                        "KGRAPH",
                        "NEPTUNE",
                        "EMBEDDING",
                        "LOGGING",
                        "ORCHESTRATOR",
                        "HIERARCHY",
                        "PROJECT",
                        "PARTITIONING",
                    ):
                        full_key = f"AF_{section}_{key}"
                    else:
                        full_key = f"{parent_key}_{key}"
                else:
                    full_key = f"QD_{parent_key}_{key}"
            else:
                # Top-level keys
                if key in ("DATA_DIR",):
                    full_key = f"QD_{key}"
                else:
                    full_key = key
            
            # Recursively flatten nested dicts
            if isinstance(value, dict):
                flat.update(QDConfig._flatten_toml(value, full_key))
            else:
                flat[full_key] = value
        
        return flat
    
    def get_af_config_dict(self) -> Dict[str, Any]:
        """
        Extract AgentForge configuration from the raw config.
        
        Returns a dictionary with AF_* prefixed keys that can be passed
        to AgentConfig.from_dict().
        """
        af_config = {k: v for k, v in self.raw_config.items() if k.startswith("AF_")}

        def _copy_if_missing(target_key: str, *source_keys: str) -> None:
            if af_config.get(target_key) not in (None, ""):
                return
            value = self._get_raw(*source_keys)
            if value not in (None, ""):
                af_config[target_key] = value

        # AgentFoundry's explicit config builder accepts both AF_* and plain
        # keys. Quantify's host config mostly uses plain legacy keys loaded into
        # the environment (e.g. MILVUS_HOST, OPENAI_MODEL), so forward them
        # here to avoid silently dropping vector-store and path settings.
        legacy_passthroughs: dict[str, tuple[str, ...]] = {
            "ORG_ID": ("ORG_ID",),
            "LLM_PROVIDER": ("LLM_PROVIDER",),
            "OPENAI_MODEL": ("OPENAI_MODEL",),
            "OPENAI_API_KEY": ("OPENAI_API_KEY",),
            "OLLAMA_MODEL": ("OLLAMA_MODEL",),
            "OLLAMA_HOST": ("OLLAMA_HOST",),
            "XAI_API_KEY": ("XAI_API_KEY",),
            "SERPAPI_API_KEY": ("SERPAPI_API_KEY",),
            "HF_TOKEN": ("HF_TOKEN",),
            "GOOGLE_API_KEY": ("GOOGLE_API_KEY",),
            "GEMINI_API_KEY": ("GEMINI_API_KEY",),
            "VECTORSTORE_PROVIDER": ("VECTORSTORE_PROVIDER", "QD_VECTORSTORE_PROVIDER"),
            "COLLECTION_NAME": ("COLLECTION_NAME", "CHROMA_COLLECTION_NAME", "QD_CHROMA_COLLECTION_NAME"),
            "MILVUS_URI": ("MILVUS_URI", "QD_MILVUS_URI"),
            "MILVUS_HOST": ("MILVUS_HOST", "QD_MILVUS_HOST"),
            "MILVUS_PORT": ("MILVUS_PORT", "QD_MILVUS_PORT"),
            "MILVUS_SECURE": ("MILVUS_SECURE", "QD_MILVUS_SECURE"),
            "MILVUS_USER": ("MILVUS_USER", "QD_MILVUS_USER"),
            "MILVUS_PASSWORD": ("MILVUS_PASSWORD", "QD_MILVUS_PASSWORD"),
            "MILVUS_TOKEN": ("MILVUS_TOKEN", "QD_MILVUS_TOKEN"),
            "MILVUS_COLLECTION_PREFIX": (
                "MILVUS_COLLECTION_PREFIX",
                "QD_MILVUS_COLLECTION_PREFIX",
                "AF_MILVUS_COLLECTION_PREFIX",
            ),
            "MILVUS_TIMEOUT": ("MILVUS_TIMEOUT", "QD_MILVUS_TIMEOUT"),
            "MILVUS_AUTO_ID": ("MILVUS_AUTO_ID", "QD_MILVUS_AUTO_ID"),
            "MILVUS_EMBEDDING_MODEL": ("MILVUS_EMBEDDING_MODEL", "QD_MILVUS_EMBEDDING_MODEL"),
            "MILVUS_FALLBACK_DIM": ("MILVUS_FALLBACK_DIM", "QD_MILVUS_FALLBACK_DIM"),
            "EMBEDDING_MODEL_NAME": ("EMBEDDING_MODEL_NAME", "QD_EMBEDDING_MODEL_NAME"),
            "KGRAPH_BACKEND": ("KGRAPH_BACKEND", "QD_KGRAPH_BACKEND"),
            "NEPTUNE_ENDPOINT": ("NEPTUNE_ENDPOINT", "QD_NEPTUNE_ENDPOINT"),
            "NEPTUNE_READER_ENDPOINT": ("NEPTUNE_READER_ENDPOINT", "QD_NEPTUNE_READER_ENDPOINT"),
            "NEPTUNE_REGION": ("NEPTUNE_REGION", "QD_NEPTUNE_REGION"),
            "NEPTUNE_PORT": ("NEPTUNE_PORT", "QD_NEPTUNE_PORT"),
            "NEPTUNE_USE_HTTPS": ("NEPTUNE_USE_HTTPS", "QD_NEPTUNE_USE_HTTPS"),
            "NEPTUNE_IAM_AUTH": ("NEPTUNE_IAM_AUTH", "QD_NEPTUNE_IAM_AUTH"),
            "NEPTUNE_QUERY_LANGUAGE": ("NEPTUNE_QUERY_LANGUAGE", "QD_NEPTUNE_QUERY_LANGUAGE"),
            "NEPTUNE_TIMEOUT": ("NEPTUNE_TIMEOUT", "QD_NEPTUNE_TIMEOUT"),
            "NEPTUNE_USE_SSH_TUNNEL": ("NEPTUNE_USE_SSH_TUNNEL", "QD_NEPTUNE_USE_SSH_TUNNEL"),
            "NEPTUNE_SSH_HOST": ("NEPTUNE_SSH_HOST", "QD_NEPTUNE_SSH_HOST"),
            "NEPTUNE_SSH_USER": ("NEPTUNE_SSH_USER", "QD_NEPTUNE_SSH_USER"),
            "NEPTUNE_SSH_KEY_PATH": ("NEPTUNE_SSH_KEY_PATH", "QD_NEPTUNE_SSH_KEY_PATH"),
            "NEPTUNE_SSH_KEY_PASSPHRASE": ("NEPTUNE_SSH_KEY_PASSPHRASE", "QD_NEPTUNE_SSH_KEY_PASSPHRASE"),
            "DATA_DIR": ("AF_DATA_DIR", "AF_PATHS_DATA_DIR", "DATA_DIR", "QD_DATA_DIR"),
            "TOOLS_DIR": ("AF_TOOLS_DIR", "AF_PATHS_TOOLS_DIR", "TOOLS_DIR"),
            "REGISTRY_DB": ("AF_REGISTRY_DB", "AF_PATHS_REGISTRY_DB", "REGISTRY_DB"),
            "AWS_REGION": ("QD_AWS_REGION", "AWS_REGION"),
            "AWS_ACCESS_KEY_ID": ("QD_AWS_ACCESS_KEY_ID", "AWS_ACCESS_KEY_ID"),
            "AWS_SECRET_ACCESS_KEY": ("QD_AWS_SECRET_ACCESS_KEY", "AWS_SECRET_ACCESS_KEY"),
            "AWS_SESSION_TOKEN": ("QD_AWS_SESSION_TOKEN", "AWS_SESSION_TOKEN"),
            "AWS_PROFILE": ("QD_AWS_PROFILE", "AWS_PROFILE"),
        }
        for target_key, source_keys in legacy_passthroughs.items():
            _copy_if_missing(target_key, *source_keys)

        _copy_if_missing("AF_ORG_ID", "ORG_ID")
        _copy_if_missing(
            "AF_MILVUS_COLLECTION_PREFIX",
            "MILVUS_COLLECTION_PREFIX",
            "QD_MILVUS_COLLECTION_PREFIX",
        )
        aws_region = self._get_str("QD_AWS_REGION", "AWS_REGION")
        aws_access_key_id = self._get_str("QD_AWS_ACCESS_KEY_ID", "AWS_ACCESS_KEY_ID")
        aws_secret_access_key = self._get_str("QD_AWS_SECRET_ACCESS_KEY", "AWS_SECRET_ACCESS_KEY")
        aws_session_token = self._get_str("QD_AWS_SESSION_TOKEN", "AWS_SESSION_TOKEN")
        aws_profile = self._get_str("QD_AWS_PROFILE", "AWS_PROFILE")
        if aws_region and "AF_AWS_REGION" not in af_config:
            af_config["AF_AWS_REGION"] = aws_region
        if aws_access_key_id and "AF_AWS_ACCESS_KEY_ID" not in af_config:
            af_config["AF_AWS_ACCESS_KEY_ID"] = aws_access_key_id
        if aws_secret_access_key and "AF_AWS_SECRET_ACCESS_KEY" not in af_config:
            af_config["AF_AWS_SECRET_ACCESS_KEY"] = aws_secret_access_key
        if aws_session_token and "AF_AWS_SESSION_TOKEN" not in af_config:
            af_config["AF_AWS_SESSION_TOKEN"] = aws_session_token
        if aws_profile and "AF_AWS_PROFILE" not in af_config:
            af_config["AF_AWS_PROFILE"] = aws_profile

        backend = str(af_config.get("KGRAPH_BACKEND") or "").strip().lower()
        neptune_endpoint = af_config.get("NEPTUNE_ENDPOINT") or af_config.get("NEPTUNE_READER_ENDPOINT")
        if backend == "neptune" and not neptune_endpoint:
            message = (
                "KGRAPH_BACKEND is set to 'Neptune' but neither NEPTUNE_ENDPOINT "
                "nor NEPTUNE_READER_ENDPOINT is configured."
            )
            logger.error("QDConfig: %s", message)
            raise RuntimeError(message)
        return af_config

    def get_af_agent_config(self):
        """Build an explicit AgentFoundry config from the loaded AF_* values."""
        from agentfoundry.utils.agent_config import AgentConfig

        return AgentConfig.from_dict(self.get_af_config_dict())

    def get_ms_tenant_id(self) -> Optional[str]:
        """Get Microsoft tenant ID."""
        return self.microsoft.tenant_id or os.getenv("MS_TENANT_ID")
    
    def get_ms_client_id(self) -> Optional[str]:
        """Get Microsoft client ID."""
        return self.microsoft.client_id or os.getenv("MS_CLIENT_ID")
    
    def get_ms_client_secret(self) -> Optional[str]:
        """Get Microsoft client secret."""
        if self.microsoft.client_secret:
            return self.microsoft.client_secret.get_secret_value()
        return os.getenv("MS_CLIENT_SECRET")
    
    def get_ms_redirect_uri(self) -> Optional[str]:
        """Get Microsoft redirect URI."""
        return self.microsoft.redirect_uri or os.getenv("MS_REDIRECT_URI")
    
    def get_ms_scopes(self) -> Optional[str | list[str]]:
        """Get Microsoft scopes."""
        return self.microsoft.scopes or os.getenv("MS_SCOPES")

    def get_ms_token_cache_file(self) -> str:
        """Get the local token cache path for Microsoft auth flows."""
        return self.microsoft.token_cache_file or self._get_str("QD_MS_TOKEN_CACHE_FILE", default="token_cache.json")

    def get_flask_secret_key(self) -> Optional[str]:
        """Get Flask secret key."""
        if self.flask_secret_key:
            return self.flask_secret_key.get_secret_value()
        return os.getenv("FLASK_SECRET_KEY")

    def _get_raw(self, *keys: str, default=None):
        for key in keys:
            if key in self.raw_config:
                value = self.raw_config[key]
                if value is not None and value != "":
                    return value
            env_value = os.getenv(key)
            if env_value not in (None, ""):
                return env_value
        return default

    def _get_str(self, *keys: str, default: Optional[str] = None) -> Optional[str]:
        value = self._get_raw(*keys, default=default)
        if value is None:
            return default
        return str(value)

    def _get_bool(self, *keys: str, default: bool = False) -> bool:
        value = self._get_raw(*keys)
        if value is None:
            return default
        if isinstance(value, bool):
            return value
        return str(value).strip().lower() in ("1", "true", "yes", "on")

    def _get_int(self, *keys: str, default: int) -> int:
        value = self._get_raw(*keys)
        if value is None:
            return default
        try:
            return int(value)
        except (TypeError, ValueError):
            return default

    def _get_list(self, *keys: str) -> list[str]:
        value = self._get_raw(*keys)
        if value is None:
            return []
        if isinstance(value, list):
            return [str(item).strip() for item in value if str(item).strip()]
        text = str(value).strip()
        if not text:
            return []
        if text.startswith("[") and text.endswith("]"):
            try:
                decoded = tomli.loads(f"value = {text}").get("value", []) if tomli else []
            except Exception:
                decoded = []
            if isinstance(decoded, list):
                return [str(item).strip() for item in decoded if str(item).strip()]
        return [item.strip() for item in text.split(",") if item.strip()]

    def get_flask_host(self) -> str:
        """Get Flask bind host."""
        return self._get_str("QD_FLASK_HOST", default="0.0.0.0") or "0.0.0.0"

    def get_local_dev_base_url(self) -> str:
        """Get the base URL used to detect local development requests."""
        default_url = f"http://localhost:{self.flask_port}"
        return self._get_str("QD_FLASK_LOCAL_DEV_BASE_URL", default=default_url) or default_url

    def get_local_dev_bypass_enabled(self) -> bool:
        """Whether localhost requests bypass SSO in development."""
        return self._get_bool("QD_FLASK_LOCAL_DEV_BYPASS_ENABLED", default=True)

    def get_local_dev_name(self) -> str:
        """Local development display name for bypassed auth."""
        return self._get_str("QD_FLASK_LOCAL_DEV_NAME", default="Local Developer") or "Local Developer"

    def get_local_dev_email(self) -> str:
        """Local development email for bypassed auth."""
        return self._get_str("QD_FLASK_LOCAL_DEV_EMAIL", default="local@example.com") or "local@example.com"

    def get_memory_org_id(self) -> str:
        """Preferred org_id for memory/KG/vector scoping."""
        return self._get_str("AF_ORG_ID", "ORG_ID", default="default") or "default"

    def get_webapp_llm_provider(self) -> str:
        """Provider used by the demo web app autonomy agent."""
        provider = self._get_str("QD_WEBAPP_LLM_PROVIDER")
        if provider:
            return provider
        return self._get_str("AF_LLM_PROVIDER", default="openai") or "openai"

    def get_webapp_llm_model(self) -> str:
        """Model used by the demo web app autonomy agent."""
        model = self._get_str("QD_WEBAPP_LLM_MODEL")
        if model:
            return model
        provider = self.get_webapp_llm_provider().lower()
        provider_model_keys = {
            "openai": ("AF_OPENAI_MODEL", "AF_LLM_OPENAI_MODEL"),
            "ollama": ("AF_OLLAMA_MODEL", "AF_LLM_OLLAMA_MODEL"),
            "grok": ("AF_GROK_MODEL", "AF_LLM_GROK_MODEL"),
            "gemini": ("AF_GEMINI_MODEL", "AF_LLM_GEMINI_MODEL"),
        }
        provider_keys = provider_model_keys.get(provider)
        if provider_keys:
            for provider_key in provider_keys:
                model_value = self._get_str(provider_key)
                if model_value:
                    return model_value
            return "gpt-5.4"
        return "gpt-5.4"

    def get_webapp_llm_init_kwargs(self) -> Dict[str, Any]:
        """Provider-specific kwargs for initializing the web app chat model."""
        provider = self.get_webapp_llm_provider().lower()
        if provider == "openai":
            api_key = self._get_str("AF_OPENAI_API_KEY", "OPENAI_API_KEY")
            return {"api_key": api_key} if api_key else {}
        if provider == "grok":
            api_key = self._get_str("AF_XAI_API_KEY", "XAI_API_KEY")
            return {"api_key": api_key} if api_key else {}
        if provider == "gemini":
            api_key = self._get_str(
                "AF_GEMINI_API_KEY",
                "AF_GOOGLE_API_KEY",
                "GEMINI_API_KEY",
                "GOOGLE_API_KEY",
            )
            return {"api_key": api_key} if api_key else {}
        if provider == "ollama":
            base_url = self._get_str("AF_OLLAMA_HOST", default="http://127.0.0.1:11434")
            return {"base_url": base_url} if base_url else {}
        return {}

    def get_enable_fact_block(self) -> bool:
        """Whether QAssistant preloads fact blocks."""
        return self._get_bool("QD_FEATURES_ENABLE_FACT_BLOCK", default=False)

    def get_enable_contract_management(self) -> bool:
        """Whether contract-management UI should be exposed."""
        return self._get_bool("QD_FEATURES_ENABLE_CONTRACT_MANAGEMENT", default=False)

    def get_enable_initiate_workflow(self) -> bool:
        """Whether the initiate-workflow UI should be exposed."""
        return self._get_bool("QD_FEATURES_ENABLE_INITIATE_WORKFLOW", default=True)

    def get_enable_fact_extraction(self) -> bool:
        """Whether document ingestion extracts graph facts."""
        return self._get_bool("QD_FEATURES_ENABLE_FACT_EXTRACTION", default=True)

    def get_heading_llm_chunk_size(self) -> int:
        """Chunk size for heading detection LLM calls."""
        return self._get_int("QD_PROCESSING_HEADING_LLM_CHUNK_SIZE", default=12000)

    def get_heading_llm_overlap(self) -> int:
        """Chunk overlap for heading detection LLM calls."""
        return self._get_int("QD_PROCESSING_HEADING_LLM_OVERLAP", default=800)

    def get_aws_config_secret_name(self) -> str:
        """Default AWS Secrets Manager secret name for app config."""
        return self._get_str("QD_AWS_CONFIG_SECRET_NAME", "QUANTIFY_CONFIG_SECRET", default="quantify/app/config") or "quantify/app/config"

    def get_aws_region(self) -> str:
        """Default AWS region for QuantumDrive integrations."""
        return self._get_str("QD_AWS_REGION", "AWS_REGION", default="us-east-1") or "us-east-1"

    def get_data_dir_path(self) -> Path:
        """Resolved QuantumDrive data directory."""
        raw_value = self.data_dir or self._get_str("QD_DATA_DIR")
        if raw_value:
            return Path(os.path.expanduser(str(raw_value)))
        return Path(os.path.expanduser("~/.config/quantumdrive/data"))

    def get_connections_dir_path(self) -> Path:
        """Directory for persisted connected-systems metadata and local secret storage."""
        raw_value = self._get_str("QD_CONNECTIONS_DIR")
        if raw_value:
            return Path(os.path.expanduser(raw_value))
        return self.get_data_dir_path() / "connections"

    def get_connections_registry_path(self) -> Path:
        """File path for persisted connection metadata."""
        raw_value = self._get_str("QD_CONNECTIONS_REGISTRY_PATH")
        if raw_value:
            return Path(os.path.expanduser(raw_value))
        return self.get_connections_dir_path() / "registry.json"

    def get_connections_secret_store_path(self) -> Path:
        """File path for the local connection secret store."""
        raw_value = self._get_str("QD_CONNECTIONS_SECRET_STORE_PATH")
        if raw_value:
            return Path(os.path.expanduser(raw_value))
        return self.get_connections_dir_path() / "secrets.json"

    def get_connections_secret_backend(self) -> str:
        """Secret backend for saved connection credentials."""
        return self._get_str("QD_CONNECTIONS_SECRET_BACKEND", default="local") or "local"

    def get_connections_secret_prefix(self) -> str:
        """AWS Secrets Manager prefix for saved connections."""
        return (
            self._get_str("QD_CONNECTIONS_SECRET_PREFIX", default="quantumdrive/connections")
            or "quantumdrive/connections"
        )

    def get_connections_audit_log_path(self) -> Path:
        """File path for connected-systems audit events."""
        raw_value = self._get_str("QD_CONNECTIONS_AUDIT_LOG_PATH")
        if raw_value:
            return Path(os.path.expanduser(raw_value))
        return self.get_connections_dir_path() / "audit.jsonl"

    def get_connections_recipe_registry_path(self) -> Path:
        """File path for persisted connected-systems recipes."""
        raw_value = self._get_str("QD_CONNECTIONS_RECIPE_REGISTRY_PATH")
        if raw_value:
            return Path(os.path.expanduser(raw_value))
        return self.get_connections_dir_path() / "recipes.json"

    def get_connections_query_history_path(self) -> Path:
        """File path for connected-systems query history."""
        raw_value = self._get_str("QD_CONNECTIONS_QUERY_HISTORY_PATH")
        if raw_value:
            return Path(os.path.expanduser(raw_value))
        return self.get_connections_dir_path() / "query_history.jsonl"

    def get_connections_shared_publisher_ids(self) -> list[str]:
        """Users allowed to publish or manage org-shared connected-system assets."""
        return self._get_list("QD_CONNECTIONS_SHARED_PUBLISHER_IDS")

    def get_blog_registry_path(self) -> Path:
        """File path for persisted generated blog posts."""
        raw_value = self._get_str("QD_BLOG_REGISTRY_PATH")
        if raw_value:
            return Path(raw_value).expanduser()
        return self.get_data_dir_path() / "blogs" / "registry.json"

    def get_code_graph_kgraph_path(self) -> str:
        """Path to the code graph persistence directory."""
        return (
            self._get_str("QD_CODE_GRAPH_KGRAPH_PATH")
            or self._get_str("AF_PATHS_DATA_DIR")
            or "~/.config/agentfoundry/data"
        )

    def get_code_graph_backend(self) -> str:
        """Backend used for the code-graph subsystem."""
        return (
            self._get_str("QD_CODE_GRAPH_BACKEND")
            or self._get_str("KGRAPH_BACKEND", "QD_KGRAPH_BACKEND")
            or "duckdb_sqlite"
        )

    def get_default_project_scope(self) -> Dict[str, Optional[str]]:
        """Return default project-scoping values for centralized hosted backends."""
        return {
            "project_id": self._get_str("AF_PROJECT_DEFAULT_PROJECT_ID"),
            "repo_id": self._get_str("AF_PROJECT_DEFAULT_REPO_ID"),
            "bounded_context": self._get_str("AF_PROJECT_DEFAULT_BOUNDED_CONTEXT"),
            "environment": self._get_str("AF_PROJECT_DEFAULT_ENVIRONMENT"),
        }

    def get_partitioning_config(self) -> Dict[str, Any]:
        """Return hosted logical-partitioning settings passed through to AgentFoundry."""
        return {
            "enabled": self._get_bool("AF_PARTITIONING_ENABLED", default=True),
            "mode": self._get_str("AF_PARTITIONING_MODE", default="logical") or "logical",
            "central_vector_backend": self._get_bool("AF_PARTITIONING_CENTRAL_VECTOR_BACKEND", default=True),
            "central_kgraph_backend": self._get_bool("AF_PARTITIONING_CENTRAL_KGRAPH_BACKEND", default=True),
            "vector_partition_key": self._get_str("AF_PARTITIONING_VECTOR_PARTITION_KEY", default="project_id") or "project_id",
            "vector_namespace_template": self._get_str(
                "AF_PARTITIONING_VECTOR_NAMESPACE_TEMPLATE",
                default="{org_id}:{project_id}",
            ) or "{org_id}:{project_id}",
            "kgraph_partition_key": self._get_str("AF_PARTITIONING_KGRAPH_PARTITION_KEY", default="project_id") or "project_id",
            "kgraph_namespace_template": self._get_str(
                "AF_PARTITIONING_KGRAPH_NAMESPACE_TEMPLATE",
                default="{org_id}:{project_id}",
            ) or "{org_id}:{project_id}",
        }

    def get_verification_default_profile(self) -> str:
        """Default verification profile for delivery-wave execution."""
        return self._get_str("QD_VERIFICATION_DEFAULT_PROFILE", default="default") or "default"

    def get_verification_project_root(self) -> str:
        """Project root used by the verification runner."""
        return self._get_str("QD_VERIFICATION_PROJECT_ROOT", default=".") or "."

    def get_cross_project_insight_config(self) -> Dict[str, Any]:
        """Return QD-side settings for cross-project reference discovery."""
        return {
            "enabled": self._get_bool("QD_CROSS_PROJECT_INSIGHTS_ENABLED", default=False),
            "top_k": self._get_int("QD_CROSS_PROJECT_INSIGHTS_TOP_K", default=5),
            "discoverable_only": self._get_bool("QD_CROSS_PROJECT_INSIGHTS_DISCOVERABLE_ONLY", default=True),
            "reference_document_type": (
                self._get_str(
                    "QD_CROSS_PROJECT_INSIGHTS_REFERENCE_DOCUMENT_TYPE",
                    default="cross_project_reference",
                )
                or "cross_project_reference"
            ),
            "max_summary_chars": self._get_int("QD_CROSS_PROJECT_INSIGHTS_MAX_SUMMARY_CHARS", default=400),
            "allow_local_source_resolution": self._get_bool(
                "QD_CROSS_PROJECT_INSIGHTS_ALLOW_LOCAL_SOURCE_RESOLUTION",
                default=True,
            ),
            "publish_verified_artifacts": self._get_bool(
                "QD_CROSS_PROJECT_INSIGHTS_PUBLISH_VERIFIED_ARTIFACTS",
                default=True,
            ),
            "publish_code_descriptors": self._get_bool(
                "QD_CROSS_PROJECT_INSIGHTS_PUBLISH_CODE_DESCRIPTORS",
                default=True,
            ),
            "publish_bug_fixes": self._get_bool(
                "QD_CROSS_PROJECT_INSIGHTS_PUBLISH_BUG_FIXES",
                default=True,
            ),
            "publish_environment_lessons": self._get_bool(
                "QD_CROSS_PROJECT_INSIGHTS_PUBLISH_ENVIRONMENT_LESSONS",
                default=True,
            ),
            "publish_onboarding_insights": self._get_bool(
                "QD_CROSS_PROJECT_INSIGHTS_PUBLISH_ONBOARDING_INSIGHTS",
                default=True,
            ),
        }

    def get_workspace_config(self) -> Dict[str, Any]:
        """Return workspace/artifact service settings."""
        return {
            "enabled": self._get_bool("QD_WORKSPACE_ENABLED", default=True),
            "default_repo_root": self._get_str("QD_WORKSPACE_DEFAULT_REPO_ROOT", default=".") or ".",
            "build_code_graph_on_ingest": self._get_bool(
                "QD_WORKSPACE_BUILD_CODE_GRAPH_ON_INGEST",
                default=True,
            ),
            "ingest_max_sample_files": self._get_int(
                "QD_WORKSPACE_INGEST_MAX_SAMPLE_FILES",
                default=250,
            ),
            "capture_max_changed_files": self._get_int(
                "QD_WORKSPACE_CAPTURE_MAX_CHANGED_FILES",
                default=200,
            ),
        }

    # ── Qato service-to-service authentication ────────────────────────────────

    def get_qato_api_key_hash(self) -> Optional[str]:
        """SHA-256 hex digest of the Qato API key (never the key itself).

        Store the digest in ``[QATO_AUTH] API_KEY_HASH`` in TOML or in
        AWS Secrets Manager under the key name configured in
        ``[AWS] CONFIG_SECRET_NAME``.
        """
        return self._get_str("QD_QATO_AUTH_API_KEY_HASH")

    def get_qato_api_key_header(self) -> str:
        """HTTP header name Qato uses to send its API key."""
        return (
            self._get_str("QD_QATO_AUTH_API_KEY_HEADER", default="X-Qato-Api-Key")
            or "X-Qato-Api-Key"
        )

    # ── Threat Mitigation subsystem ───────────────────────────────────────────

    def get_threat_mitigation_enabled(self) -> bool:
        """Whether the TMAPI Blueprint is active."""
        return self._get_bool("QD_THREAT_MITIGATION_ENABLED", default=False)

    def get_threat_mitigation_environment(self) -> str:
        """Default target environment when not specified per-request."""
        return (
            self._get_str("QD_THREAT_MITIGATION_ENVIRONMENT", default="aws") or "aws"
        )

    def get_threat_mitigation_approval_required_actions(self) -> list[str]:
        """Actions that halt execution until a human approves via the UI."""
        return self._get_list(
            "QD_THREAT_MITIGATION_APPROVAL_REQUIRED_ACTIONS"
        ) or ["credential_rotation", "port_lockdown", "patch"]

    def get_threat_mitigation_job_store_path(self) -> "Path":
        """JSONL file used to persist mitigation job state."""
        from pathlib import Path

        raw = self._get_str("QD_THREAT_MITIGATION_JOB_STORE_PATH")
        if raw:
            return Path(os.path.expanduser(raw))
        return self.get_data_dir_path() / "threat_mitigation" / "jobs.jsonl"

    def get_threat_mitigation_audit_log_path(self) -> "Path":
        """JSONL file used to persist mitigation audit events."""
        from pathlib import Path

        raw = self._get_str("QD_THREAT_MITIGATION_AUDIT_LOG_PATH")
        if raw:
            return Path(os.path.expanduser(raw))
        return self.get_data_dir_path() / "threat_mitigation" / "audit.jsonl"

    def get_threat_mitigation_aws_waf_web_acl_arn(self) -> Optional[str]:
        """ARN of the AWS WAF Web ACL used for traffic blocking."""
        return self._get_str("QD_THREAT_MITIGATION_AWS_WAF_WEB_ACL_ARN")

    def get_threat_mitigation_aws_default_sg_id(self) -> Optional[str]:
        """Default AWS Security Group ID for port lockdown actions."""
        return self._get_str("QD_THREAT_MITIGATION_AWS_DEFAULT_SG_ID")

    def get_threat_mitigation_aws_default_nacl_id(self) -> Optional[str]:
        """Default AWS Network ACL ID for IP blacklist actions."""
        return self._get_str("QD_THREAT_MITIGATION_AWS_DEFAULT_NACL_ID")

    def get_threat_mitigation_aws_route53_hosted_zone_id(self) -> Optional[str]:
        """Default Route53 hosted zone ID for DNS block actions."""
        return self._get_str("QD_THREAT_MITIGATION_AWS_ROUTE53_HOSTED_ZONE_ID")

    def get_threat_mitigation_aws_ssm_document(self) -> str:
        """SSM document name used for remote patching."""
        return (
            self._get_str(
                "QD_THREAT_MITIGATION_AWS_SSM_DOCUMENT",
                default="AWS-RunShellScript",
            )
            or "AWS-RunShellScript"
        )

    def get_threat_mitigation_sns_alert_topic_arn(self) -> Optional[str]:
        """SNS topic ARN for alert escalation."""
        return self._get_str("QD_THREAT_MITIGATION_SNS_ALERT_TOPIC_ARN")

    def get_threat_mitigation_slack_webhook_url(self) -> Optional[str]:
        """Slack incoming webhook URL for alert escalation."""
        return self._get_str("QD_THREAT_MITIGATION_SLACK_WEBHOOK_URL")

    def get_threat_mitigation_dns_sinkhole_ip(self) -> str:
        """IP address used as the DNS sinkhole target."""
        return (
            self._get_str("QD_THREAT_MITIGATION_DNS_SINKHOLE_IP", default="0.0.0.0")
            or "0.0.0.0"
        )

    def get_threat_mitigation_pagerduty_routing_key(self) -> Optional[str]:
        """PagerDuty routing key for high-severity escalations."""
        return self._get_str("QD_THREAT_MITIGATION_PAGERDUTY_ROUTING_KEY")
