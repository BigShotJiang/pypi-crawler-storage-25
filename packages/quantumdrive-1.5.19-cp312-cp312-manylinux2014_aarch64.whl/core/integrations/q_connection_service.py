"""Persistence and testing for saved external-system connections."""

from __future__ import annotations

import json
import logging
import os
import sqlite3
import types
import uuid
from dataclasses import dataclass
from datetime import datetime, timezone
from enum import Enum
from pathlib import Path
from typing import Any, Dict, List, Optional

import boto3
import requests
from botocore.exceptions import ClientError

from pydantic import BaseModel, ConfigDict, Field
try:
    import psycopg2
except ImportError:  # pragma: no cover - optional runtime dependency
    psycopg2 = types.SimpleNamespace(connect=None)

from core.config import QDConfig

logger = logging.getLogger(__name__)


def _utc_now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


class _PydanticIgnoredTypeProbe:
    def method(self) -> None:
        return None


# Cython changes the runtime type of plain `def` methods in class namespaces.
# Pydantic needs those method object types in `ignored_types` so methods are not
# interpreted as fields.
_EXTRA_IGNORED: tuple[type, ...] = tuple(
    dict.fromkeys(
        (
            types.FunctionType,
            type(_utc_now_iso),
            type(_PydanticIgnoredTypeProbe.__dict__["method"]),
        )
    )
)


class ConnectionSystemType(str, Enum):
    ELASTIC_REST = "elastic_rest"
    ELASTIC_ESQL = "elastic_esql"
    OPENSEARCH = "opensearch"
    SQLITE = "sqlite"
    GENERIC_REST = "generic_rest"
    POSTGRES = "postgres"
    GITLAB_API = "gitlab_api"


class ConnectionAuthType(str, Enum):
    NONE = "none"
    BASIC = "basic"
    BEARER_TOKEN = "bearer_token"
    API_KEY_HEADER = "api_key_header"
    API_KEY_QUERY = "api_key_query"
    CUSTOM_HEADERS = "custom_headers"


class SavedConnectionDraft(BaseModel):
    model_config = ConfigDict(ignored_types=_EXTRA_IGNORED)

    name: str
    system_type: ConnectionSystemType
    description: Optional[str] = None
    base_url: Optional[str] = None
    resource_path: Optional[str] = None
    default_index: Optional[str] = None
    default_database: Optional[str] = None
    default_schema: Optional[str] = None
    openapi_spec_url: Optional[str] = None
    auth_type: ConnectionAuthType = ConnectionAuthType.NONE
    username: Optional[str] = None
    password: Optional[str] = None
    token: Optional[str] = None
    api_key: Optional[str] = None
    api_key_name: Optional[str] = None
    default_headers: Dict[str, str] = Field(default_factory=dict)
    default_query_params: Dict[str, str] = Field(default_factory=dict)
    sharing_scope: str = "private"
    environment: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    owner_user_id: Optional[str] = None
    org_id: Optional[str] = None

    def validate_for_save(self) -> None:
        if not self.name.strip():
            raise ValueError("Connection name is required.")
        if self.system_type in {
            ConnectionSystemType.ELASTIC_REST,
            ConnectionSystemType.ELASTIC_ESQL,
            ConnectionSystemType.OPENSEARCH,
            ConnectionSystemType.GENERIC_REST,
            ConnectionSystemType.GITLAB_API,
        }:
            if not (self.base_url or "").strip():
                raise ValueError("A base URL is required for web-based systems.")
        if self.system_type == ConnectionSystemType.SQLITE:
            if not (self.resource_path or "").strip():
                raise ValueError("A SQLite file path is required.")
        if self.system_type == ConnectionSystemType.POSTGRES:
            if not ((self.resource_path or "").strip() or (self.base_url or "").strip()):
                raise ValueError("A Postgres DSN or connection URL is required.")
        if self.auth_type == ConnectionAuthType.BASIC:
            if not (self.username or "").strip() or not (self.password or "").strip():
                raise ValueError("Username and password are required for basic auth.")
        if self.auth_type == ConnectionAuthType.BEARER_TOKEN and not (self.token or "").strip():
            raise ValueError("A token is required for bearer auth.")
        if self.auth_type in {ConnectionAuthType.API_KEY_HEADER, ConnectionAuthType.API_KEY_QUERY}:
            if not (self.api_key or "").strip():
                raise ValueError("An API key is required for API key auth.")


class SavedConnection(BaseModel):
    model_config = ConfigDict(ignored_types=_EXTRA_IGNORED)

    connection_id: str
    name: str
    system_type: ConnectionSystemType
    description: Optional[str] = None
    base_url: Optional[str] = None
    resource_path: Optional[str] = None
    default_index: Optional[str] = None
    default_database: Optional[str] = None
    default_schema: Optional[str] = None
    openapi_spec_url: Optional[str] = None
    auth_type: ConnectionAuthType
    credential_ref: Optional[str] = None
    default_headers: Dict[str, str] = Field(default_factory=dict)
    default_query_params: Dict[str, str] = Field(default_factory=dict)
    owner_user_id: Optional[str] = None
    org_id: Optional[str] = None
    sharing_scope: str = "private"
    environment: Optional[str] = None
    tags: List[str] = Field(default_factory=list)
    last_test_status: Optional[str] = None
    last_test_message: Optional[str] = None
    last_test_at: Optional[str] = None
    created_at: str
    updated_at: str

    def masked_summary(self) -> Dict[str, Any]:
        credential_backend = None
        if self.credential_ref and ":" in self.credential_ref:
            credential_backend = self.credential_ref.split(":", 1)[0]
        return {
            "connection_id": self.connection_id,
            "name": self.name,
            "system_type": self.system_type.value,
            "auth_type": self.auth_type.value,
            "base_url": self.base_url,
            "resource_path": self.resource_path,
            "default_index": self.default_index,
            "default_database": self.default_database,
            "default_schema": self.default_schema,
            "openapi_spec_url": self.openapi_spec_url,
            "owner_user_id": self.owner_user_id,
            "org_id": self.org_id,
            "sharing_scope": self.sharing_scope,
            "environment": self.environment,
            "tags": list(self.tags),
            "last_test_status": self.last_test_status,
            "last_test_message": self.last_test_message,
            "last_test_at": self.last_test_at,
            "created_at": self.created_at,
            "updated_at": self.updated_at,
            "has_credentials": bool(self.credential_ref),
            "credential_backend": credential_backend,
        }


@dataclass
class ConnectionTestResult:
    ok: bool
    message: str
    detail: Optional[Dict[str, Any]] = None

    def as_dict(self) -> Dict[str, Any]:
        return {
            "ok": self.ok,
            "message": self.message,
            "detail": self.detail or {},
        }


@dataclass
class ConnectionAuditEvent:
    action: str
    connection_id: str
    org_id: Optional[str]
    owner_user_id: Optional[str]
    status: str
    detail: Dict[str, Any]
    created_at: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "action": self.action,
            "connection_id": self.connection_id,
            "org_id": self.org_id,
            "owner_user_id": self.owner_user_id,
            "status": self.status,
            "detail": dict(self.detail),
            "created_at": self.created_at,
        }


class SavedConnectionRecipe(BaseModel):
    model_config = ConfigDict(ignored_types=_EXTRA_IGNORED)

    recipe_id: str
    connection_id: str
    title: str
    question: str
    description: Optional[str] = None
    owner_user_id: Optional[str] = None
    org_id: Optional[str] = None
    sharing_scope: str = "private"
    created_at: str
    updated_at: str

    def as_dict(self) -> Dict[str, Any]:
        return self.model_dump(mode="json")


@dataclass
class QueryHistoryEntry:
    query_run_id: str
    connection_id: str
    connection_name: str
    question: str
    interpreted_intent: str
    final_answer: str
    status: str
    user_id: Optional[str]
    org_id: Optional[str]
    tool_name: Optional[str]
    method: Optional[str]
    generated_query: Optional[str]
    raw_response_summary: Any
    started_at: str
    completed_at: str

    def as_dict(self) -> Dict[str, Any]:
        return {
            "query_run_id": self.query_run_id,
            "connection_id": self.connection_id,
            "connection_name": self.connection_name,
            "question": self.question,
            "interpreted_intent": self.interpreted_intent,
            "final_answer": self.final_answer,
            "status": self.status,
            "user_id": self.user_id,
            "org_id": self.org_id,
            "tool_name": self.tool_name,
            "method": self.method,
            "generated_query": self.generated_query,
            "raw_response_summary": self.raw_response_summary,
            "started_at": self.started_at,
            "completed_at": self.completed_at,
        }


class BaseConnectionSecretService:
    def put_secret(self, connection_id: str, secret_payload: Dict[str, Any]) -> str:  # pragma: no cover - interface
        raise NotImplementedError

    def get_secret(self, credential_ref: Optional[str]) -> Dict[str, Any]:  # pragma: no cover - interface
        raise NotImplementedError

    def delete_secret(self, credential_ref: Optional[str]) -> None:  # pragma: no cover - interface
        raise NotImplementedError


class LocalConnectionSecretService(BaseConnectionSecretService):
    """Stores connection secrets in a local, separate file."""

    def __init__(self, config: QDConfig) -> None:
        self._path = config.connections_secret_store_path

    def _ensure_parent(self) -> None:
        self._path.parent.mkdir(parents=True, exist_ok=True)

    def _load(self) -> Dict[str, Dict[str, Any]]:
        if not self._path.exists():
            return {}
        try:
            return json.loads(self._path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            logger.warning("Connection secret store is invalid JSON; treating as empty: %s", self._path)
            return {}

    def _write(self, payload: Dict[str, Dict[str, Any]]) -> None:
        self._ensure_parent()
        self._path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")
        try:
            os.chmod(self._path, 0o600)
        except OSError:
            logger.debug("Unable to chmod local secret store: %s", self._path)

    def put_secret(self, connection_id: str, secret_payload: Dict[str, Any]) -> str:
        store = self._load()
        store[connection_id] = secret_payload
        self._write(store)
        return f"local:{connection_id}"

    def get_secret(self, credential_ref: Optional[str]) -> Dict[str, Any]:
        if not credential_ref:
            return {}
        if not credential_ref.startswith("local:"):
            raise ValueError(f"Unsupported credential_ref backend: {credential_ref}")
        connection_id = credential_ref.split(":", 1)[1]
        return dict(self._load().get(connection_id) or {})

    def delete_secret(self, credential_ref: Optional[str]) -> None:
        if not credential_ref or not credential_ref.startswith("local:"):
            return
        connection_id = credential_ref.split(":", 1)[1]
        store = self._load()
        if connection_id in store:
            del store[connection_id]
            self._write(store)


class AWSConnectionSecretService(BaseConnectionSecretService):
    """Stores connection secrets in AWS Secrets Manager."""

    def __init__(self, config: QDConfig) -> None:
        self._prefix = config.connections.secret_prefix.rstrip("/")
        self._region = config.aws.region
        self._client = boto3.client("secretsmanager", region_name=self._region)

    def _secret_name(self, connection_id: str) -> str:
        return f"{self._prefix}/{connection_id}"

    def put_secret(self, connection_id: str, secret_payload: Dict[str, Any]) -> str:
        secret_name = self._secret_name(connection_id)
        secret_string = json.dumps(secret_payload)
        try:
            self._client.describe_secret(SecretId=secret_name)
            self._client.update_secret(SecretId=secret_name, SecretString=secret_string)
        except ClientError as exc:
            error_code = exc.response.get("Error", {}).get("Code")
            if error_code not in {"ResourceNotFoundException", "DecryptionFailure"}:
                raise
            self._client.create_secret(Name=secret_name, SecretString=secret_string)
        return f"aws:{secret_name}"

    def get_secret(self, credential_ref: Optional[str]) -> Dict[str, Any]:
        if not credential_ref:
            return {}
        if not credential_ref.startswith("aws:"):
            raise ValueError(f"Unsupported credential_ref backend: {credential_ref}")
        secret_name = credential_ref.split(":", 1)[1]
        response = self._client.get_secret_value(SecretId=secret_name)
        secret_string = response.get("SecretString") or "{}"
        return dict(json.loads(secret_string))

    def delete_secret(self, credential_ref: Optional[str]) -> None:
        if not credential_ref or not credential_ref.startswith("aws:"):
            return
        secret_name = credential_ref.split(":", 1)[1]
        try:
            self._client.delete_secret(SecretId=secret_name, ForceDeleteWithoutRecovery=True)
        except ClientError as exc:
            logger.warning("Unable to delete connection secret '%s': %s", secret_name, exc)


class QConnectionService:
    """Persist, retrieve, and test saved external-system connections."""

    def __init__(self, config: QDConfig) -> None:
        self._config = config
        self._registry_path = config.connections_registry_path
        self._audit_log_path = config.connections_audit_log_path
        self._recipe_registry_path = config.connections_recipe_registry_path
        self._query_history_path = config.connections_query_history_path
        backend = config.connections.secret_backend.strip().lower()
        if backend == "aws":
            self._secrets: BaseConnectionSecretService = AWSConnectionSecretService(config)
        else:
            self._secrets = LocalConnectionSecretService(config)
        self._secret_backend = backend

    @staticmethod
    def _normalize_user_id(user_id: Optional[str]) -> Optional[str]:
        text = str(user_id or "").strip().lower()
        return text or None

    def _ensure_parent(self) -> None:
        self._registry_path.parent.mkdir(parents=True, exist_ok=True)

    def _load_registry(self) -> List[SavedConnection]:
        if not self._registry_path.exists():
            return []
        try:
            payload = json.loads(self._registry_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            logger.warning("Connection registry is invalid JSON; treating as empty: %s", self._registry_path)
            return []
        return [SavedConnection.model_validate(item) for item in payload]

    def _write_registry(self, records: List[SavedConnection]) -> None:
        self._ensure_parent()
        payload = [record.model_dump(mode="json") for record in records]
        self._registry_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    @staticmethod
    def _postgres_dsn(connection: SavedConnection) -> str:
        return str(connection.resource_path or connection.base_url or "").strip()

    @staticmethod
    def _credential_payload_from_draft(draft: SavedConnectionDraft) -> Dict[str, Any]:
        return {
            key: value
            for key, value in {
                "username": draft.username,
                "password": draft.password,
                "token": draft.token,
                "api_key": draft.api_key,
                "api_key_name": draft.api_key_name,
            }.items()
            if value not in (None, "")
        }

    def _append_audit_event(self, event: ConnectionAuditEvent) -> None:
        self._audit_log_path.parent.mkdir(parents=True, exist_ok=True)
        with self._audit_log_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(event.as_dict(), sort_keys=True) + "\n")

    def _load_recipe_registry(self) -> List[SavedConnectionRecipe]:
        if not self._recipe_registry_path.exists():
            return []
        try:
            payload = json.loads(self._recipe_registry_path.read_text(encoding="utf-8"))
        except json.JSONDecodeError:
            logger.warning("Connection recipe registry is invalid JSON; treating as empty: %s", self._recipe_registry_path)
            return []
        return [SavedConnectionRecipe.model_validate(item) for item in payload]

    def _write_recipe_registry(self, records: List[SavedConnectionRecipe]) -> None:
        self._recipe_registry_path.parent.mkdir(parents=True, exist_ok=True)
        payload = [record.model_dump(mode="json") for record in records]
        self._recipe_registry_path.write_text(json.dumps(payload, indent=2, sort_keys=True), encoding="utf-8")

    def _append_query_history(self, entry: QueryHistoryEntry) -> None:
        self._query_history_path.parent.mkdir(parents=True, exist_ok=True)
        with self._query_history_path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(entry.as_dict(), sort_keys=True) + "\n")

    def _audit(
        self,
        *,
        action: str,
        connection_id: str,
        org_id: Optional[str],
        owner_user_id: Optional[str],
        status: str,
        detail: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._append_audit_event(
            ConnectionAuditEvent(
                action=action,
                connection_id=connection_id,
                org_id=org_id,
                owner_user_id=owner_user_id,
                status=status,
                detail=detail or {},
                created_at=_utc_now_iso(),
            )
        )

    @staticmethod
    def _validate_plain_metadata_map(mapping: Dict[str, str], *, field_name: str) -> Dict[str, str]:
        blocked = {"authorization", "proxy-authorization", "cookie", "set-cookie"}
        sanitized: Dict[str, str] = {}
        for key, value in mapping.items():
            key_text = str(key).strip()
            value_text = str(value).strip()
            if not key_text:
                raise ValueError(f"{field_name} keys must be non-empty strings.")
            if "\n" in key_text or "\r" in key_text or "\n" in value_text or "\r" in value_text:
                raise ValueError(f"{field_name} values must not contain newline characters.")
            if field_name == "default_headers" and key_text.lower() in blocked:
                raise ValueError(
                    f"{field_name} may not include secret-bearing header '{key_text}'. Use auth fields instead."
                )
            sanitized[key_text] = value_text
        return sanitized

    def can_access_connection(
        self,
        connection: SavedConnection,
        *,
        org_id: Optional[str],
        owner_user_id: Optional[str],
    ) -> bool:
        if org_id and connection.org_id not in (None, org_id):
            return False
        if connection.sharing_scope == "org_shared":
            return True
        if owner_user_id is None:
            return connection.owner_user_id is None
        return connection.owner_user_id in (None, owner_user_id)

    def is_shared_publisher(self, user_id: Optional[str]) -> bool:
        actor = self._normalize_user_id(user_id)
        if not actor:
            return False
        allowed = {
            item.lower()
            for item in self._config.connections.shared_publisher_ids
            if str(item).strip()
        }
        return actor in allowed

    def can_manage_connection(
        self,
        connection: SavedConnection,
        *,
        org_id: Optional[str],
        owner_user_id: Optional[str],
    ) -> bool:
        if not self.can_access_connection(connection, org_id=org_id, owner_user_id=owner_user_id):
            return False
        actor = self._normalize_user_id(owner_user_id)
        owner = self._normalize_user_id(connection.owner_user_id)
        if actor and actor == owner:
            return True
        if connection.sharing_scope == "org_shared" and self.is_shared_publisher(actor):
            return True
        if owner is None and self.is_shared_publisher(actor):
            return True
        return False

    def can_manage_recipe(
        self,
        recipe: SavedConnectionRecipe,
        *,
        org_id: Optional[str],
        owner_user_id: Optional[str],
    ) -> bool:
        if org_id and recipe.org_id not in (None, org_id):
            return False
        actor = self._normalize_user_id(owner_user_id)
        owner = self._normalize_user_id(recipe.owner_user_id)
        if actor and actor == owner:
            return True
        if recipe.sharing_scope == "org_shared" and self.is_shared_publisher(actor):
            return True
        if owner is None and self.is_shared_publisher(actor):
            return True
        return False

    def list_connections(
        self,
        *,
        org_id: Optional[str] = None,
        owner_user_id: Optional[str] = None,
    ) -> List[SavedConnection]:
        records = self._load_registry()
        visible: List[SavedConnection] = []
        for record in records:
            if self.can_access_connection(record, org_id=org_id, owner_user_id=owner_user_id):
                visible.append(record)
        return sorted(visible, key=lambda item: (item.name.lower(), item.created_at))

    def get_connection(self, connection_id: str) -> Optional[SavedConnection]:
        for record in self._load_registry():
            if record.connection_id == connection_id:
                return record
        return None

    def save_connection(self, draft: SavedConnectionDraft, *, connection_id: Optional[str] = None) -> SavedConnection:
        draft.validate_for_save()
        now = _utc_now_iso()
        records = self._load_registry()
        existing = self.get_connection(connection_id) if connection_id else None
        headers = self._validate_plain_metadata_map(dict(draft.default_headers or {}), field_name="default_headers")
        query_params = self._validate_plain_metadata_map(
            dict(draft.default_query_params or {}),
            field_name="default_query_params",
        )
        resolved_connection_id = connection_id or str(uuid.uuid4())
        credential_payload = self._credential_payload_from_draft(draft)
        credential_ref = existing.credential_ref if existing else None
        if credential_payload:
            credential_ref = self._secrets.put_secret(resolved_connection_id, credential_payload)
        elif draft.auth_type == ConnectionAuthType.NONE:
            if existing and existing.credential_ref:
                self._secrets.delete_secret(existing.credential_ref)
            credential_ref = None
        elif existing and existing.credential_ref:
            credential_ref = existing.credential_ref

        saved = SavedConnection(
            connection_id=resolved_connection_id,
            name=draft.name.strip(),
            system_type=draft.system_type,
            description=(draft.description or "").strip() or None,
            base_url=(draft.base_url or "").strip() or None,
            resource_path=(draft.resource_path or "").strip() or None,
            default_index=(draft.default_index or "").strip() or None,
            default_database=(draft.default_database or "").strip() or None,
            default_schema=(draft.default_schema or "").strip() or None,
            openapi_spec_url=(draft.openapi_spec_url or "").strip() or None,
            auth_type=draft.auth_type,
            credential_ref=credential_ref,
            default_headers=headers,
            default_query_params=query_params,
            owner_user_id=draft.owner_user_id,
            org_id=draft.org_id,
            sharing_scope=(draft.sharing_scope or "private").strip() or "private",
            environment=(draft.environment or "").strip() or None,
            tags=list(draft.tags or []),
            last_test_status=existing.last_test_status if existing else None,
            last_test_message=existing.last_test_message if existing else None,
            last_test_at=existing.last_test_at if existing else None,
            created_at=existing.created_at if existing else now,
            updated_at=now,
        )
        updated: List[SavedConnection] = []
        replaced = False
        for record in records:
            if record.connection_id == resolved_connection_id:
                updated.append(saved)
                replaced = True
            else:
                updated.append(record)
        if not replaced:
            updated.append(saved)
        self._write_registry(updated)
        self._audit(
            action="save",
            connection_id=saved.connection_id,
            org_id=saved.org_id,
            owner_user_id=saved.owner_user_id,
            status="ok",
            detail={"secret_backend": self._secret_backend, "system_type": saved.system_type.value},
        )
        return saved

    def replace_connection_credentials(
        self,
        connection_id: str,
        *,
        auth_type: ConnectionAuthType,
        username: Optional[str] = None,
        password: Optional[str] = None,
        token: Optional[str] = None,
        api_key: Optional[str] = None,
        api_key_name: Optional[str] = None,
    ) -> Optional[SavedConnection]:
        existing = self.get_connection(connection_id)
        if existing is None:
            return None
        draft = SavedConnectionDraft(
            name=existing.name,
            system_type=existing.system_type,
            description=existing.description,
            base_url=existing.base_url,
            resource_path=existing.resource_path,
            default_index=existing.default_index,
            default_database=existing.default_database,
            default_schema=existing.default_schema,
            openapi_spec_url=existing.openapi_spec_url,
            auth_type=auth_type,
            username=username,
            password=password,
            token=token,
            api_key=api_key,
            api_key_name=api_key_name,
            default_headers=dict(existing.default_headers or {}),
            default_query_params=dict(existing.default_query_params or {}),
            sharing_scope=existing.sharing_scope,
            environment=existing.environment,
            tags=list(existing.tags or []),
            owner_user_id=existing.owner_user_id,
            org_id=existing.org_id,
        )
        credential_payload = self._credential_payload_from_draft(draft)
        if auth_type != ConnectionAuthType.NONE and not credential_payload:
            raise ValueError("Credential material is required for the selected auth type.")
        if existing.credential_ref:
            self._secrets.delete_secret(existing.credential_ref)
        saved = self.save_connection(draft, connection_id=connection_id)
        self._audit(
            action="replace_credentials",
            connection_id=saved.connection_id,
            org_id=saved.org_id,
            owner_user_id=saved.owner_user_id,
            status="ok",
            detail={"auth_type": saved.auth_type.value},
        )
        return saved

    def clear_connection_credentials(self, connection_id: str) -> Optional[SavedConnection]:
        existing = self.get_connection(connection_id)
        if existing is None:
            return None
        if existing.credential_ref:
            self._secrets.delete_secret(existing.credential_ref)
        records = self._load_registry()
        updated: List[SavedConnection] = []
        saved: Optional[SavedConnection] = None
        for record in records:
            if record.connection_id == connection_id:
                saved = record.model_copy(update={"credential_ref": None, "auth_type": ConnectionAuthType.NONE, "updated_at": _utc_now_iso()})
                updated.append(saved)
            else:
                updated.append(record)
        if saved is not None:
            self._write_registry(updated)
            self._audit(
                action="clear_credentials",
                connection_id=saved.connection_id,
                org_id=saved.org_id,
                owner_user_id=saved.owner_user_id,
                status="ok",
                detail={},
            )
        return saved

    def clone_connection(
        self,
        connection_id: str,
        *,
        new_owner_user_id: Optional[str],
        new_org_id: Optional[str],
        new_name: Optional[str] = None,
        include_credentials: bool = True,
    ) -> Optional[SavedConnection]:
        existing = self.get_connection(connection_id)
        if existing is None:
            return None
        clone_id = str(uuid.uuid4())
        now = _utc_now_iso()
        cloned_name = (new_name or f"{existing.name} Copy").strip()
        credential_ref = None
        if include_credentials and existing.credential_ref:
            secret_payload = self._secrets.get_secret(existing.credential_ref)
            if secret_payload:
                credential_ref = self._secrets.put_secret(clone_id, secret_payload)
        clone = SavedConnection(
            connection_id=clone_id,
            name=cloned_name,
            system_type=existing.system_type,
            description=existing.description,
            base_url=existing.base_url,
            resource_path=existing.resource_path,
            default_index=existing.default_index,
            default_database=existing.default_database,
            default_schema=existing.default_schema,
            openapi_spec_url=existing.openapi_spec_url,
            auth_type=existing.auth_type if credential_ref else ConnectionAuthType.NONE,
            credential_ref=credential_ref,
            default_headers=dict(existing.default_headers or {}),
            default_query_params=dict(existing.default_query_params or {}),
            owner_user_id=new_owner_user_id,
            org_id=new_org_id or existing.org_id,
            sharing_scope="private",
            environment=existing.environment,
            tags=list(existing.tags or []),
            last_test_status=None,
            last_test_message=None,
            last_test_at=None,
            created_at=now,
            updated_at=now,
        )
        records = self._load_registry()
        records.append(clone)
        self._write_registry(records)
        self._audit(
            action="clone",
            connection_id=clone.connection_id,
            org_id=clone.org_id,
            owner_user_id=clone.owner_user_id,
            status="ok",
            detail={"source_connection_id": existing.connection_id, "included_credentials": bool(credential_ref)},
        )
        return clone

    def delete_connection(self, connection_id: str) -> bool:
        records = self._load_registry()
        remaining = [record for record in records if record.connection_id != connection_id]
        if len(remaining) == len(records):
            return False
        existing = self.get_connection(connection_id)
        if existing:
            self._secrets.delete_secret(existing.credential_ref)
        self._write_registry(remaining)
        if existing:
            self._audit(
                action="delete",
                connection_id=existing.connection_id,
                org_id=existing.org_id,
                owner_user_id=existing.owner_user_id,
                status="ok",
                detail={"system_type": existing.system_type.value},
            )
        return True

    def _auth_kwargs(self, connection: SavedConnection) -> Dict[str, Any]:
        secret = self._secrets.get_secret(connection.credential_ref)
        headers = dict(connection.default_headers or {})
        params = dict(connection.default_query_params or {})
        kwargs: Dict[str, Any] = {"headers": headers, "params": params}
        if connection.auth_type == ConnectionAuthType.BASIC:
            kwargs["auth"] = (
                secret.get("username") or "",
                secret.get("password") or "",
            )
        elif connection.auth_type == ConnectionAuthType.BEARER_TOKEN:
            token = secret.get("token")
            if token:
                headers["Authorization"] = f"Bearer {token}"
        elif connection.auth_type == ConnectionAuthType.API_KEY_HEADER:
            api_key = secret.get("api_key")
            api_key_name = secret.get("api_key_name") or "Authorization"
            if api_key:
                headers[api_key_name] = api_key
        elif connection.auth_type == ConnectionAuthType.API_KEY_QUERY:
            api_key = secret.get("api_key")
            api_key_name = secret.get("api_key_name") or "api_key"
            if api_key:
                params[api_key_name] = api_key
        elif connection.auth_type == ConnectionAuthType.CUSTOM_HEADERS:
            pass
        return kwargs

    def build_request_kwargs(self, connection: SavedConnection) -> Dict[str, Any]:
        """Return resolved request kwargs with auth headers/params applied."""
        resolved = self._auth_kwargs(connection)
        return {
            "headers": dict(resolved.get("headers") or {}),
            "params": dict(resolved.get("params") or {}),
            **({"auth": resolved["auth"]} if "auth" in resolved else {}),
        }

    def record_audit_event(
        self,
        *,
        action: str,
        connection: SavedConnection,
        status: str,
        detail: Optional[Dict[str, Any]] = None,
    ) -> None:
        self._audit(
            action=action,
            connection_id=connection.connection_id,
            org_id=connection.org_id,
            owner_user_id=connection.owner_user_id,
            status=status,
            detail=detail or {},
        )

    def list_audit_events(
        self,
        *,
        org_id: Optional[str] = None,
        owner_user_id: Optional[str] = None,
        connection_id: Optional[str] = None,
        limit: int = 25,
    ) -> List[Dict[str, Any]]:
        if not self._audit_log_path.exists():
            return []
        entries: List[Dict[str, Any]] = []
        with self._audit_log_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                raw = line.strip()
                if not raw:
                    continue
                try:
                    item = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if connection_id and item.get("connection_id") != connection_id:
                    continue
                entry_org_id = item.get("org_id")
                if org_id and entry_org_id not in (None, org_id):
                    continue
                if owner_user_id is not None and item.get("owner_user_id") not in (None, owner_user_id):
                    if item.get("status") != "ok":
                        continue
                entries.append(item)
        return list(reversed(entries[-limit:]))

    def save_recipe(
        self,
        *,
        connection: SavedConnection,
        title: str,
        question: str,
        description: Optional[str] = None,
        owner_user_id: Optional[str] = None,
        org_id: Optional[str] = None,
        sharing_scope: str = "private",
    ) -> SavedConnectionRecipe:
        if not title.strip():
            raise ValueError("Recipe title is required.")
        if not question.strip():
            raise ValueError("Recipe question is required.")
        now = _utc_now_iso()
        records = self._load_recipe_registry()
        saved = SavedConnectionRecipe(
            recipe_id=str(uuid.uuid4()),
            connection_id=connection.connection_id,
            title=title.strip(),
            question=question.strip(),
            description=(description or "").strip() or None,
            owner_user_id=owner_user_id,
            org_id=org_id or connection.org_id,
            sharing_scope=sharing_scope or "private",
            created_at=now,
            updated_at=now,
        )
        records.append(saved)
        self._write_recipe_registry(records)
        self.record_audit_event(
            action="save_recipe",
            connection=connection,
            status="ok",
            detail={"recipe_id": saved.recipe_id, "sharing_scope": saved.sharing_scope},
        )
        return saved

    def update_recipe_sharing_scope(
        self,
        *,
        recipe_id: str,
        sharing_scope: str,
    ) -> Optional[SavedConnectionRecipe]:
        normalized_scope = (sharing_scope or "private").strip() or "private"
        records = self._load_recipe_registry()
        updated: List[SavedConnectionRecipe] = []
        saved: Optional[SavedConnectionRecipe] = None
        for record in records:
            if record.recipe_id == recipe_id:
                saved = record.model_copy(update={"sharing_scope": normalized_scope, "updated_at": _utc_now_iso()})
                updated.append(saved)
            else:
                updated.append(record)
        if saved is not None:
            self._write_recipe_registry(updated)
        return saved

    def delete_recipe(self, recipe_id: str) -> bool:
        records = self._load_recipe_registry()
        remaining = [record for record in records if record.recipe_id != recipe_id]
        if len(remaining) == len(records):
            return False
        self._write_recipe_registry(remaining)
        return True

    def list_recipes(
        self,
        *,
        connection_id: Optional[str] = None,
        org_id: Optional[str] = None,
        owner_user_id: Optional[str] = None,
    ) -> List[SavedConnectionRecipe]:
        records = self._load_recipe_registry()
        visible: List[SavedConnectionRecipe] = []
        for record in records:
            if connection_id and record.connection_id != connection_id:
                continue
            if org_id and record.org_id not in (None, org_id):
                continue
            if record.sharing_scope == "org_shared":
                visible.append(record)
                continue
            if owner_user_id is None:
                if record.owner_user_id is None:
                    visible.append(record)
                continue
            if record.owner_user_id in (None, owner_user_id):
                visible.append(record)
        return sorted(visible, key=lambda item: (item.title.lower(), item.created_at))

    def append_query_history(
        self,
        *,
        connection: SavedConnection,
        question: str,
        interpreted_intent: str,
        final_answer: str,
        status: str,
        user_id: Optional[str],
        org_id: Optional[str],
        tool_name: Optional[str],
        method: Optional[str],
        generated_query: Optional[str],
        raw_response_summary: Any,
        started_at: str,
        completed_at: str,
    ) -> None:
        entry = QueryHistoryEntry(
            query_run_id=str(uuid.uuid4()),
            connection_id=connection.connection_id,
            connection_name=connection.name,
            question=question,
            interpreted_intent=interpreted_intent,
            final_answer=final_answer,
            status=status,
            user_id=user_id,
            org_id=org_id or connection.org_id,
            tool_name=tool_name,
            method=method,
            generated_query=generated_query,
            raw_response_summary=raw_response_summary,
            started_at=started_at,
            completed_at=completed_at,
        )
        self._append_query_history(entry)

    def list_query_history(
        self,
        *,
        connection_id: Optional[str] = None,
        org_id: Optional[str] = None,
        owner_user_id: Optional[str] = None,
        limit: int = 20,
    ) -> List[Dict[str, Any]]:
        if not self._query_history_path.exists():
            return []
        entries: List[Dict[str, Any]] = []
        with self._query_history_path.open("r", encoding="utf-8") as handle:
            for line in handle:
                raw = line.strip()
                if not raw:
                    continue
                try:
                    item = json.loads(raw)
                except json.JSONDecodeError:
                    continue
                if connection_id and item.get("connection_id") != connection_id:
                    continue
                if org_id and item.get("org_id") not in (None, org_id):
                    continue
                if owner_user_id is not None and item.get("user_id") not in (None, owner_user_id):
                    continue
                entries.append(item)
        return list(reversed(entries[-limit:]))

    def get_usage_summary(
        self,
        *,
        org_id: Optional[str] = None,
        owner_user_id: Optional[str] = None,
    ) -> Dict[str, Any]:
        visible_connections = self.list_connections(org_id=org_id, owner_user_id=owner_user_id)
        visible_ids = {item.connection_id for item in visible_connections}
        recipe_counts = {item.connection_id: 0 for item in visible_connections}
        for recipe in self.list_recipes(org_id=org_id, owner_user_id=owner_user_id):
            if recipe.connection_id in visible_ids:
                recipe_counts[recipe.connection_id] = recipe_counts.get(recipe.connection_id, 0) + 1

        query_stats = {
            item.connection_id: {
                "query_count": 0,
                "failed_query_count": 0,
                "last_query_at": None,
            }
            for item in visible_connections
        }
        if self._query_history_path.exists():
            with self._query_history_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    raw = line.strip()
                    if not raw:
                        continue
                    try:
                        item = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    connection_id = item.get("connection_id")
                    if connection_id not in visible_ids:
                        continue
                    stats = query_stats.setdefault(
                        connection_id,
                        {"query_count": 0, "failed_query_count": 0, "last_query_at": None},
                    )
                    stats["query_count"] += 1
                    if item.get("status") != "ok":
                        stats["failed_query_count"] += 1
                    completed_at = item.get("completed_at")
                    if completed_at and (stats["last_query_at"] is None or completed_at > stats["last_query_at"]):
                        stats["last_query_at"] = completed_at

        audit_stats = {
            item.connection_id: {"audit_event_count": 0, "last_audit_at": None}
            for item in visible_connections
        }
        if self._audit_log_path.exists():
            with self._audit_log_path.open("r", encoding="utf-8") as handle:
                for line in handle:
                    raw = line.strip()
                    if not raw:
                        continue
                    try:
                        item = json.loads(raw)
                    except json.JSONDecodeError:
                        continue
                    connection_id = item.get("connection_id")
                    if connection_id not in visible_ids:
                        continue
                    stats = audit_stats.setdefault(connection_id, {"audit_event_count": 0, "last_audit_at": None})
                    stats["audit_event_count"] += 1
                    created_at = item.get("created_at")
                    if created_at and (stats["last_audit_at"] is None or created_at > stats["last_audit_at"]):
                        stats["last_audit_at"] = created_at

        items = []
        for connection in visible_connections:
            query_item = query_stats.get(connection.connection_id, {})
            audit_item = audit_stats.get(connection.connection_id, {})
            items.append(
                {
                    "connection_id": connection.connection_id,
                    "name": connection.name,
                    "system_type": connection.system_type.value,
                    "sharing_scope": connection.sharing_scope,
                    "owner_user_id": connection.owner_user_id,
                    "last_test_status": connection.last_test_status or "unknown",
                    "query_count": query_item.get("query_count", 0),
                    "failed_query_count": query_item.get("failed_query_count", 0),
                    "recipe_count": recipe_counts.get(connection.connection_id, 0),
                    "audit_event_count": audit_item.get("audit_event_count", 0),
                    "last_query_at": query_item.get("last_query_at"),
                    "last_audit_at": audit_item.get("last_audit_at"),
                }
            )

        return {
            "total_connections": len(visible_connections),
            "private_connections": sum(1 for item in visible_connections if item.sharing_scope != "org_shared"),
            "org_shared_connections": sum(1 for item in visible_connections if item.sharing_scope == "org_shared"),
            "saved_recipes": sum(recipe_counts.values()),
            "total_queries": sum(item["query_count"] for item in items),
            "failed_queries": sum(item["failed_query_count"] for item in items),
            "unhealthy_connections": sum(1 for item in visible_connections if (item.last_test_status or "unknown") != "ok"),
            "items": sorted(items, key=lambda item: (item["name"].lower(), item["connection_id"])),
        }

    def get_connection_health_summary(self, connection: SavedConnection) -> Dict[str, Any]:
        status = connection.last_test_status or "unknown"
        retry_recommended = status in {"failed", "unknown"} or not connection.last_test_at
        return {
            "status": status,
            "message": connection.last_test_message,
            "last_test_at": connection.last_test_at,
            "retry_recommended": retry_recommended,
            "has_credentials": bool(connection.credential_ref),
        }

    def test_connection(self, connection: SavedConnection) -> ConnectionTestResult:
        try:
            if connection.system_type == ConnectionSystemType.SQLITE:
                path = Path(os.path.expanduser(connection.resource_path or ""))
                if not path.exists():
                    return ConnectionTestResult(False, f"SQLite file not found: {path}")
                with sqlite3.connect(path) as conn:
                    conn.execute("SELECT 1")
                result = ConnectionTestResult(True, "SQLite connection verified.", {"path": str(path)})
                self._audit(
                    action="test",
                    connection_id=connection.connection_id,
                    org_id=connection.org_id,
                    owner_user_id=connection.owner_user_id,
                    status="ok",
                    detail={"system_type": connection.system_type.value},
                )
                return result

            if connection.system_type == ConnectionSystemType.POSTGRES:
                if psycopg2 is None:
                    return ConnectionTestResult(False, "psycopg2 is not installed; Postgres support is unavailable.")
                dsn = self._postgres_dsn(connection)
                if not dsn:
                    return ConnectionTestResult(False, "No Postgres DSN configured.")
                with psycopg2.connect(dsn) as conn:
                    with conn.cursor() as cur:
                        cur.execute("SELECT 1")
                        cur.fetchone()
                result = ConnectionTestResult(True, "Postgres connection verified.", {"dsn": dsn})
                self._audit(
                    action="test",
                    connection_id=connection.connection_id,
                    org_id=connection.org_id,
                    owner_user_id=connection.owner_user_id,
                    status="ok",
                    detail={"system_type": connection.system_type.value},
                )
                return result

            base_url = (connection.base_url or "").strip()
            if not base_url:
                return ConnectionTestResult(False, "No base URL configured.")

            url = base_url.rstrip("/")
            if connection.system_type in {ConnectionSystemType.ELASTIC_REST, ConnectionSystemType.OPENSEARCH}:
                target_url = f"{url}/_cat/indices?format=json"
            elif connection.system_type == ConnectionSystemType.ELASTIC_ESQL:
                target_url = f"{url}/_query"
            elif connection.system_type == ConnectionSystemType.GITLAB_API:
                target_url = f"{url}/api/v4/user"
            else:
                target_url = url

            kwargs = self._auth_kwargs(connection)
            timeout = 10
            if connection.system_type == ConnectionSystemType.ELASTIC_ESQL:
                response = requests.post(
                    target_url,
                    json={"query": "ROW 1 | LIMIT 1"},
                    timeout=timeout,
                    **kwargs,
                )
            else:
                response = requests.get(target_url, timeout=timeout, **kwargs)
            if response.ok:
                detail: Dict[str, Any] = {"status_code": response.status_code}
                content_type = response.headers.get("content-type") or ""
                if "json" in content_type.lower():
                    try:
                        payload = response.json()
                        if isinstance(payload, list):
                            detail["preview_count"] = len(payload)
                        elif isinstance(payload, dict):
                            detail["preview_keys"] = sorted(list(payload.keys()))[:10]
                    except ValueError:
                        pass
                result = ConnectionTestResult(True, f"Connection verified ({response.status_code}).", detail)
                self._audit(
                    action="test",
                    connection_id=connection.connection_id,
                    org_id=connection.org_id,
                    owner_user_id=connection.owner_user_id,
                    status="ok",
                    detail={"system_type": connection.system_type.value, "status_code": response.status_code},
                )
                return result
            result = ConnectionTestResult(
                False,
                f"Connection test failed with status {response.status_code}.",
                {"status_code": response.status_code, "response_text": response.text[:500]},
            )
            self._audit(
                action="test",
                connection_id=connection.connection_id,
                org_id=connection.org_id,
                owner_user_id=connection.owner_user_id,
                status="failed",
                detail={"system_type": connection.system_type.value, "status_code": response.status_code},
            )
            return result
        except requests.RequestException as exc:
            self._audit(
                action="test",
                connection_id=connection.connection_id,
                org_id=connection.org_id,
                owner_user_id=connection.owner_user_id,
                status="failed",
                detail={"system_type": connection.system_type.value, "error": str(exc)},
            )
            return ConnectionTestResult(False, f"HTTP connection test failed: {exc}")
        except sqlite3.Error as exc:
            self._audit(
                action="test",
                connection_id=connection.connection_id,
                org_id=connection.org_id,
                owner_user_id=connection.owner_user_id,
                status="failed",
                detail={"system_type": connection.system_type.value, "error": str(exc)},
            )
            return ConnectionTestResult(False, f"SQLite connection test failed: {exc}")
        except Exception as exc:
            if connection.system_type == ConnectionSystemType.POSTGRES:
                self._audit(
                    action="test",
                    connection_id=connection.connection_id,
                    org_id=connection.org_id,
                    owner_user_id=connection.owner_user_id,
                    status="failed",
                    detail={"system_type": connection.system_type.value, "error": str(exc)},
                )
                return ConnectionTestResult(False, f"Postgres connection test failed: {exc}")
            raise

    def test_draft(self, draft: SavedConnectionDraft) -> ConnectionTestResult:
        """Test a not-yet-saved connection without persisting it."""
        draft.validate_for_save()
        temp = SavedConnection(
            connection_id="draft",
            name=draft.name.strip(),
            system_type=draft.system_type,
            description=draft.description,
            base_url=(draft.base_url or "").strip() or None,
            resource_path=(draft.resource_path or "").strip() or None,
            default_index=draft.default_index,
            default_database=draft.default_database,
            default_schema=draft.default_schema,
            openapi_spec_url=draft.openapi_spec_url,
            auth_type=draft.auth_type,
            credential_ref=None,
            default_headers=dict(draft.default_headers or {}),
            default_query_params=dict(draft.default_query_params or {}),
            owner_user_id=draft.owner_user_id,
            org_id=draft.org_id,
            sharing_scope=draft.sharing_scope,
            environment=draft.environment,
            tags=list(draft.tags or []),
            created_at=_utc_now_iso(),
            updated_at=_utc_now_iso(),
        )
        secret_payload = {
            key: value
            for key, value in {
                "username": draft.username,
                "password": draft.password,
                "token": draft.token,
                "api_key": draft.api_key,
                "api_key_name": draft.api_key_name,
            }.items()
            if value not in (None, "")
        }
        if secret_payload:
            temp = temp.model_copy(update={"credential_ref": self._secrets.put_secret("__draft__", secret_payload)})
        try:
            return self.test_connection(temp)
        finally:
            self._secrets.delete_secret(temp.credential_ref)

    def update_test_result(self, connection_id: str, result: ConnectionTestResult) -> Optional[SavedConnection]:
        records = self._load_registry()
        updated: List[SavedConnection] = []
        saved: Optional[SavedConnection] = None
        for record in records:
            if record.connection_id == connection_id:
                saved = record.model_copy(
                    update={
                        "last_test_status": "ok" if result.ok else "failed",
                        "last_test_message": result.message,
                        "last_test_at": _utc_now_iso(),
                        "updated_at": _utc_now_iso(),
                    }
                )
                updated.append(saved)
            else:
                updated.append(record)
        if saved is not None:
            self._write_registry(updated)
        return saved
