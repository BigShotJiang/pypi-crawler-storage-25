"""QuantumDrive-owned LangChain tools registered with QAssistant."""

from __future__ import annotations
