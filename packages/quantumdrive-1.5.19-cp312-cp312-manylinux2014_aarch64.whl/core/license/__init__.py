__all__ = ["KeyManager", "enforce_license", "get_license_key", "get_machine_id", "verify_license"]


def __getattr__(name: str):
    if name in {"enforce_license", "get_machine_id", "verify_license"}:
        from core.license.license import enforce_license, get_machine_id, verify_license

        return {
            "enforce_license": enforce_license,
            "get_machine_id": get_machine_id,
            "verify_license": verify_license,
        }[name]
    if name in {"KeyManager", "get_license_key"}:
        from core.license.key_manager import KeyManager, get_license_key

        return {
            "KeyManager": KeyManager,
            "get_license_key": get_license_key,
        }[name]
    raise AttributeError(name)
