"""QuantumDrive voice services — STT and TTS for the chat interface."""

from .tts_service import TTSService, get_tts_service
from .stt_service import STTService, get_stt_service
from .text_preprocessor import preprocess_for_tts
from .pronunciations import load_pronunciations, apply_pronunciations
from .cleanup import (
    cleanup_old_files,
    get_voice_tmp_dir,
    start_cleanup_thread,
    stop_cleanup_thread,
)

__all__ = [
    "TTSService",
    "get_tts_service",
    "STTService",
    "get_stt_service",
    "preprocess_for_tts",
    "load_pronunciations",
    "apply_pronunciations",
    "cleanup_old_files",
    "get_voice_tmp_dir",
    "start_cleanup_thread",
    "stop_cleanup_thread",
]
