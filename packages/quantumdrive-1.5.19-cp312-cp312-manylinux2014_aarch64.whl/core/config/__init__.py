"""Public API for QuantumDrive configuration.

Host applications (Quantify, internal scripts) and QuantumDrive entry
points (``webapp/app.py``, CLIs, test fixtures) import from here::

    from core.config import QDConfig, set_module_config, get_module_config

Factories:

- :meth:`QDConfig.from_dict` — nested dict only.
- :meth:`QDConfig.from_toml` — nested TOML file; merges shipped defaults
  and optionally overlays ``QD__*`` + ``AF__*`` env vars.
- :meth:`QDConfig.from_env` — shipped defaults + env overlays.

Runtime: :func:`set_module_config` publishes the process-wide config;
:func:`get_module_config` raises if unset; :func:`get_module_config_or_none`
returns ``None`` for callers that want to probe without raising.

Typical bootstrap::

    from core.config import QDConfig, set_module_config
    from agentfoundry.config import set_module_config as set_af_module_config

    cfg = QDConfig.from_toml("quantumdrive.toml", apply_env=True)
    set_module_config(cfg)
    set_af_module_config(cfg.agentfoundry)
"""

from __future__ import annotations

from core.config.env import env_overlay
from core.config.models import (
    DEFAULT_OPENAI_REASONING_MAX_TOKENS,
    BlogConfig,
    CodeGraphConfig,
    ConnectionsConfig,
    CrossProjectInsightsConfig,
    FeaturesConfig,
    FlaskConfig,
    LogConfig,
    MicrosoftConfig,
    PresentationConfig,
    ProcessingConfig,
    QDAWSConfig,
    QDConfig,
    QDEmbeddingConfig,
    QDPathsConfig,
    QatoAuthConfig,
    RegistryConfig,
    ResolvedWebappLLMConfig,
    ThreatMitigationConfig,
    VerificationConfig,
    VideoConfig,
    VoiceConfig,
    WebappLLMConfig,
    WhitePaperConfig,
    WorkspaceConfig,
    load_shipped_defaults,
)
from core.config.runtime import (
    get_module_config,
    get_module_config_or_load,
    get_module_config_or_none,
    reset_module_config,
    set_module_config,
)
from core.config.toml import load_toml, resolve_toml_path


__all__ = [
    # Top-level + sub-models
    "QDConfig",
    "BlogConfig",
    "CodeGraphConfig",
    "ConnectionsConfig",
    "CrossProjectInsightsConfig",
    "FeaturesConfig",
    "FlaskConfig",
    "LogConfig",
    "MicrosoftConfig",
    "PresentationConfig",
    "ProcessingConfig",
    "QDAWSConfig",
    "QDEmbeddingConfig",
    "QDPathsConfig",
    "QatoAuthConfig",
    "RegistryConfig",
    "ResolvedWebappLLMConfig",
    "ThreatMitigationConfig",
    "VerificationConfig",
    "VideoConfig",
    "VoiceConfig",
    "WebappLLMConfig",
    "WhitePaperConfig",
    "WorkspaceConfig",
    # Constants + shipped defaults
    "DEFAULT_OPENAI_REASONING_MAX_TOKENS",
    "load_shipped_defaults",
    # Env overlay
    "env_overlay",
    # TOML loader + path resolution
    "load_toml",
    "resolve_toml_path",
    # Runtime helpers
    "get_module_config",
    "get_module_config_or_load",
    "get_module_config_or_none",
    "reset_module_config",
    "set_module_config",
]
