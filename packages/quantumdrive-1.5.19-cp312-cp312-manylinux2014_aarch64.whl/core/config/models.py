"""Pydantic models for QuantumDrive configuration.

Single source of truth for :class:`QDConfig` and its sub-models. Every
class sets ``extra="forbid"`` so typoed keys raise ``ValidationError`` at
load time. AgentFoundry lives as a nested field — :attr:`QDConfig.agentfoundry` —
so ``[agentfoundry.*]`` sub-tables in the host TOML flow straight into
``AgentConfig`` without any flattening or translation layer.

Factories (:meth:`QDConfig.from_dict`, :meth:`QDConfig.from_toml`,
:meth:`QDConfig.from_env`) live at the bottom of the file.
"""

from __future__ import annotations

import logging
import os
from pathlib import Path
from typing import Any, Dict, List, Optional

from pydantic import BaseModel, ConfigDict, Field, SecretStr

from agentfoundry.config import AgentConfig
from agentfoundry.config.models import _deep_merge as _af_deep_merge


logger = logging.getLogger(__name__)


DEFAULT_OPENAI_REASONING_MAX_TOKENS = 16384


_STRICT = ConfigDict(
    extra="forbid",
    validate_assignment=True,
    str_strip_whitespace=True,
)


# ---------------------------------------------------------------------------
# Leaf sub-models
# ---------------------------------------------------------------------------


class MicrosoftConfig(BaseModel):
    """Microsoft 365 / Entra ID configuration."""

    model_config = _STRICT

    tenant_id: Optional[str] = None
    client_id: Optional[str] = None
    client_secret: Optional[SecretStr] = None
    redirect_uri: Optional[str] = None
    scopes: List[str] = Field(default_factory=list)
    token_cache_file: str = "token_cache.json"


class FlaskConfig(BaseModel):
    """Flask webapp configuration."""

    model_config = _STRICT

    debug: bool = False
    port: int = 5000
    host: str = "0.0.0.0"
    secret_key: Optional[SecretStr] = None
    local_dev_base_url: Optional[str] = None
    local_dev_bypass_enabled: bool = True
    local_dev_name: str = "Local Developer"
    local_dev_email: str = "local@example.com"


def _supports_openai_reasoning_model(model_name: Optional[str]) -> bool:
    """Return whether an OpenAI model family supports reasoning controls."""
    model_lower = str(model_name or "").strip().lower()
    return model_lower.startswith(("gpt-5", "o1", "o3", "o4"))


class ResolvedWebappLLMConfig(BaseModel):
    """Effective webapp LLM settings after fallback to ``agentfoundry.llm``.

    Returned by :meth:`WebappLLMConfig.resolved`. Consumed by webapp
    routes that need a concrete snapshot of every knob.
    """

    model_config = _STRICT

    provider: str
    model: str
    reasoning_effort: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    reasoning: Optional[Dict[str, Any]] = None
    verbosity: Optional[str] = None
    with_structured_output: bool = True
    bind_tools: bool = True
    parallel_tool_calls: bool = False


class WebappLLMConfig(BaseModel):
    """Overrides for the demo webapp autonomy agent's LLM.

    Every field is optional. Unset fields inherit from
    ``cfg.agentfoundry.llm`` via :meth:`resolved`; the webapp reads the
    resolved projection rather than this raw sub-model.
    """

    model_config = _STRICT

    provider: Optional[str] = None
    model: Optional[str] = None
    reasoning_effort: Optional[str] = None
    max_tokens: Optional[int] = None
    temperature: Optional[float] = None
    reasoning: Optional[Dict[str, Any]] = None
    reasoning_summary: Optional[str] = None
    verbosity: Optional[str] = None
    with_structured_output: Optional[bool] = None
    bind_tools: Optional[bool] = None
    parallel_tool_calls: Optional[bool] = None

    def resolved(self, af_llm) -> ResolvedWebappLLMConfig:
        """Merge webapp-specific overrides with ``agentfoundry.llm`` defaults.

        Only OpenAI-family models get the reasoning / verbosity / token
        knobs populated; other providers return ``None`` for those.
        """
        provider = self.provider or af_llm.provider or "openai"
        model = self.model or af_llm.model_name or "gpt-5.4"

        is_openai = provider.lower() == "openai"
        supports_reasoning = is_openai and _supports_openai_reasoning_model(model)

        reasoning_effort = (
            (self.reasoning_effort or af_llm.reasoning_effort or "high")
            if is_openai
            else None
        )
        max_tokens = (
            (self.max_tokens if self.max_tokens is not None else af_llm.max_tokens)
            if is_openai
            else None
        )
        temperature = (
            (self.temperature if self.temperature is not None else af_llm.temperature)
            if is_openai
            else None
        )

        reasoning: Optional[Dict[str, Any]] = None
        if is_openai:
            raw = dict(self.reasoning or af_llm.reasoning or {})
            explicit_summary = self.reasoning_summary
            if supports_reasoning or raw or explicit_summary not in (None, ""):
                summary = (
                    str(explicit_summary).strip().lower()
                    if explicit_summary not in (None, "")
                    else (raw.get("summary") or "auto")
                )
                raw["effort"] = str(
                    raw.get("effort") or (reasoning_effort or "high")
                ).strip().lower()
                raw["summary"] = str(summary).strip().lower()
                reasoning = raw

        verbosity: Optional[str] = None
        if is_openai:
            explicit = self.verbosity or af_llm.verbosity
            if explicit:
                verbosity = explicit
            elif supports_reasoning:
                verbosity = "high"

        with_structured = (
            self.with_structured_output
            if self.with_structured_output is not None
            else af_llm.with_structured_output
        )
        bind = self.bind_tools if self.bind_tools is not None else af_llm.bind_tools
        parallel = (
            self.parallel_tool_calls
            if self.parallel_tool_calls is not None
            else af_llm.parallel_tool_calls
        )

        return ResolvedWebappLLMConfig(
            provider=provider,
            model=model,
            reasoning_effort=reasoning_effort,
            max_tokens=max_tokens,
            temperature=temperature,
            reasoning=reasoning,
            verbosity=verbosity,
            with_structured_output=bool(with_structured),
            bind_tools=bool(bind),
            parallel_tool_calls=bool(parallel),
        )

    def init_kwargs(self, af_cfg) -> Dict[str, Any]:
        """Provider-specific kwargs for LangChain ``init_chat_model``."""
        resolved = self.resolved(af_cfg.llm)
        provider = resolved.provider.lower()
        if provider == "openai":
            kwargs: Dict[str, Any] = {
                "max_tokens": resolved.max_tokens,
                "temperature": resolved.temperature,
                "model_kwargs": {
                    "parallel_tool_calls": resolved.parallel_tool_calls,
                },
            }
            if resolved.reasoning:
                kwargs["reasoning"] = resolved.reasoning
            elif _supports_openai_reasoning_model(resolved.model):
                kwargs["reasoning_effort"] = resolved.reasoning_effort or "high"
            if resolved.verbosity:
                kwargs["verbosity"] = resolved.verbosity
            api_key = af_cfg.get_api_key("openai")
            if api_key:
                kwargs["api_key"] = api_key
            return kwargs
        if provider == "grok":
            api_key = af_cfg.get_api_key("grok")
            return {"api_key": api_key} if api_key else {}
        if provider == "gemini":
            api_key = af_cfg.get_api_key("gemini")
            return {"api_key": api_key} if api_key else {}
        if provider == "ollama":
            base_url = af_cfg.llm.api_base or "http://127.0.0.1:11434"
            return {"base_url": base_url} if base_url else {}
        return {}


class FeaturesConfig(BaseModel):
    """Feature toggles for the QuantumDrive UI and ingestion."""

    model_config = _STRICT

    enable_fact_block: bool = False
    enable_contract_management: bool = False
    enable_initiate_workflow: bool = True
    enable_fact_extraction: bool = True


class ProcessingConfig(BaseModel):
    """Document-processing knobs."""

    model_config = _STRICT

    heading_llm_chunk_size: int = 12000
    heading_llm_overlap: int = 800


class QDPathsConfig(BaseModel):
    """QuantumDrive filesystem paths.

    ``data_dir`` is the single root. Per-subsystem directories
    (connections, blogs, presentations, videos, threat-mitigation, etc.)
    derive from it as read-only properties on the owning sub-models. Only
    override these on the sub-model when you need to put one subsystem on
    a different disk/path.
    """

    model_config = _STRICT

    data_dir: str = "~/.config/quantumdrive/data"

    @property
    def data_dir_path(self) -> Path:
        return Path(os.path.expanduser(self.data_dir))


class LogConfig(BaseModel):
    """Logging configuration for QuantumDrive.

    Distinct from ``cfg.agentfoundry.log`` — QD owns Flask/MSAL/urllib
    per-logger overrides that AF doesn't know about. The primary ``level``
    is read by :func:`core.utils.logger.setup_logging`.
    """

    model_config = _STRICT

    level: str = "INFO"
    level_msal: str = "INFO"
    level_werkzeug: str = "WARNING"
    level_urllib3: str = "WARNING"
    level_quantumdrive: str = "DEBUG"


class QDAWSConfig(BaseModel):
    """AWS credentials used by QuantumDrive (distinct from ``cfg.agentfoundry.aws``).

    Kept on the QD side because QD-specific subsystems (Secrets Manager
    config loader, threat-mitigation) read these independently of
    AgentFoundry's AWS-backed services (Neptune, etc.). When both are
    set, downstream code resolves in the order documented by each
    subsystem.
    """

    model_config = _STRICT

    region: str = "us-east-1"
    access_key_id: Optional[SecretStr] = None
    secret_access_key: Optional[SecretStr] = None
    session_token: Optional[SecretStr] = None
    profile: Optional[str] = None
    config_secret_name: str = "quantify/app/config"


class CodeGraphConfig(BaseModel):
    """Code-graph subsystem settings."""

    model_config = _STRICT

    backend: Optional[str] = None
    kgraph_path: Optional[str] = None


class VerificationConfig(BaseModel):
    """Delivery-wave verification runner settings."""

    model_config = _STRICT

    default_profile: str = "default"
    project_root: str = "."


class CrossProjectInsightsConfig(BaseModel):
    """Settings for cross-project reference discovery / publication."""

    model_config = _STRICT

    enabled: bool = False
    top_k: int = 5
    discoverable_only: bool = True
    reference_document_type: str = "cross_project_reference"
    max_summary_chars: int = 400
    allow_local_source_resolution: bool = True
    publish_verified_artifacts: bool = True
    publish_code_descriptors: bool = True
    publish_bug_fixes: bool = True
    publish_environment_lessons: bool = True
    publish_onboarding_insights: bool = True


class WorkspaceConfig(BaseModel):
    """Workspace / artifact service settings."""

    model_config = _STRICT

    enabled: bool = True
    default_repo_root: str = "."
    build_code_graph_on_ingest: bool = True
    ingest_max_sample_files: int = 250
    capture_max_changed_files: int = 200


class PresentationConfig(BaseModel):
    """PowerPoint generation subsystem settings."""

    model_config = _STRICT

    enabled: bool = True
    project_root: str = "."
    node_binary: str = "node"
    renderer_script_path: Optional[str] = None
    dir: Optional[str] = None
    output_dir: Optional[str] = None
    spec_dir: Optional[str] = None
    thumbnail_dir: Optional[str] = None


class VideoConfig(BaseModel):
    """Video generation subsystem settings."""

    model_config = _STRICT

    enabled: bool = True
    project_root: str = "."
    node_binary: str = "node"
    ffmpeg_binary: str = "ffmpeg"
    gen_script_path: Optional[str] = None
    gen_dir: Optional[str] = None
    dir: Optional[str] = None
    output_dir: Optional[str] = None
    script_dir: Optional[str] = None
    working_dir: Optional[str] = None
    tts_engine: str = "openai"
    voice: str = "sage"
    tts_speed: float = 0.9
    viewport_width: int = 1920
    viewport_height: int = 1080


class VoiceConfig(BaseModel):
    """Voice interface settings."""

    model_config = _STRICT

    enabled: bool = False
    stt_provider: str = "browser"
    whisper_model_size: str = "base.en"
    mode: str = "toggle"
    tts_provider: str = "openai"
    tts_voice: str = "sage"
    tts_speed: float = 1.0
    tts_model: str = "tts-1"
    auto_speak_responses: bool = False
    skip_code_blocks: bool = True
    stream_tts: bool = True
    pronunciations_file: str = ""


class QatoAuthConfig(BaseModel):
    """Qato service-to-service authentication settings.

    The SHA-256 hex digest of the Qato API key is stored here (never the
    key itself). The actual key lives in AWS Secrets Manager.
    """

    model_config = _STRICT

    api_key_hash: Optional[str] = None
    api_key_header: str = "X-Qato-Api-Key"


class ThreatMitigationConfig(BaseModel):
    """Threat mitigation (TMAPI) subsystem settings."""

    model_config = _STRICT

    enabled: bool = False
    environment: str = "aws"
    approval_required_actions: List[str] = Field(
        default_factory=lambda: ["credential_rotation", "port_lockdown", "patch"]
    )
    job_store_path: Optional[str] = None
    audit_log_path: Optional[str] = None
    aws_waf_web_acl_arn: Optional[str] = None
    aws_default_sg_id: Optional[str] = None
    aws_default_nacl_id: Optional[str] = None
    aws_route53_hosted_zone_id: Optional[str] = None
    aws_ssm_document: str = "AWS-RunShellScript"
    sns_alert_topic_arn: Optional[str] = None
    slack_webhook_url: Optional[SecretStr] = None
    pagerduty_routing_key: Optional[SecretStr] = None
    dns_sinkhole_ip: str = "0.0.0.0"
    webhook_pq_sign_enabled: bool = False
    """When true, completion webhooks are signed with a post-quantum key
    so the recipient (Qato) can verify QD's identity and that the
    payload was not tampered with. Fails closed: if signing is enabled
    but the key cannot be loaded, the webhook is not delivered."""

    webhook_pq_signing_key_path: Optional[str] = None
    """Filesystem path to the PQ signing private key. Loaded once and
    cached. Generate via :class:`core.crypto.QPQCService`'s
    ``generate_signing_keypair`` + ``save_keypair``."""

    webhook_pq_signature_alg: str = "dilithium"
    """Informational header value advertising the signing algorithm —
    matches the QPQCService default."""

    webhook_pq_key_id: Optional[str] = None
    """Optional opaque key identifier surfaced in
    ``X-QuantumDrive-Signature-KeyId``. Lets the recipient pin a
    specific public key during rotation."""


class WhitePaperConfig(BaseModel):
    """WhitePaper generation subsystem settings."""

    model_config = _STRICT

    enabled: bool = True
    project_root: str = "."
    dir: Optional[str] = None
    output_dir: Optional[str] = None
    templates_dir: Optional[str] = None
    references_dir: Optional[str] = None
    job_store_path: Optional[str] = None
    llm_role: str = "reasoning"
    section_max_words: int = 800
    reference_top_k: int = 6
    reference_chunk_chars: int = 1500
    milvus_collection_prefix: str = "quantumdrive_whitepaper_refs"
    kgraph_namespace: str = "quantumdrive/whitepaper"


class ConnectionsConfig(BaseModel):
    """Connected-systems studio settings."""

    model_config = _STRICT

    dir: Optional[str] = None
    registry_path: Optional[str] = None
    secret_store_path: Optional[str] = None
    secret_backend: str = "local"
    secret_prefix: str = "quantumdrive/connections"
    audit_log_path: Optional[str] = None
    recipe_registry_path: Optional[str] = None
    query_history_path: Optional[str] = None
    shared_publisher_ids: List[str] = Field(default_factory=list)


class BlogConfig(BaseModel):
    """Blog generator settings."""

    model_config = _STRICT

    registry_path: Optional[str] = None


class RegistryConfig(BaseModel):
    """Agent registry persistence."""

    model_config = _STRICT

    db_path: str = "data/registry.db"


class QDEmbeddingConfig(BaseModel):
    """Legacy QuantumDrive embedding hint.

    Separate from :attr:`AgentConfig.embedding` — this is consumed by
    ``core.utils.q_memory_service`` as a fallback-default hint for the
    vector-store collection name. Collapsing into
    ``cfg.agentfoundry.embedding`` is a live open question in the
    redesign plan.
    """

    model_config = _STRICT

    model_name: str = "text-embedding-3-small"
    dimensions: int = 1536


# ---------------------------------------------------------------------------
# Top-level QDConfig
# ---------------------------------------------------------------------------


class QDConfig(BaseModel):
    """Canonical QuantumDrive configuration object.

    Construct via :meth:`from_dict`, :meth:`from_toml`, or :meth:`from_env`,
    then publish via :func:`core.config.set_module_config`. Every sub-model
    uses ``extra="forbid"``; typoed or renamed keys raise at load time.

    AgentFoundry configuration is a nested field (``agentfoundry``). The
    ``[agentfoundry.*]`` sub-tables in the host TOML map 1:1 to
    :class:`AgentConfig` sub-models — no flattening, no translation. Host
    bootstraps should call ``agentfoundry.config.set_module_config(cfg.agentfoundry)``
    immediately after ``set_module_config(cfg)`` so AF subsystems pick up
    the same instance.
    """

    model_config = _STRICT

    # AgentFoundry lives as a nested tree.
    agentfoundry: AgentConfig = Field(default_factory=AgentConfig)

    # QD sub-models
    microsoft: MicrosoftConfig = Field(default_factory=MicrosoftConfig)
    flask: FlaskConfig = Field(default_factory=FlaskConfig)
    webapp_llm: WebappLLMConfig = Field(default_factory=WebappLLMConfig)
    features: FeaturesConfig = Field(default_factory=FeaturesConfig)
    processing: ProcessingConfig = Field(default_factory=ProcessingConfig)
    paths: QDPathsConfig = Field(default_factory=QDPathsConfig)
    log: LogConfig = Field(default_factory=LogConfig)
    aws: QDAWSConfig = Field(default_factory=QDAWSConfig)
    code_graph: CodeGraphConfig = Field(default_factory=CodeGraphConfig)
    verification: VerificationConfig = Field(default_factory=VerificationConfig)
    cross_project_insights: CrossProjectInsightsConfig = Field(
        default_factory=CrossProjectInsightsConfig
    )
    workspace: WorkspaceConfig = Field(default_factory=WorkspaceConfig)
    presentation: PresentationConfig = Field(default_factory=PresentationConfig)
    video: VideoConfig = Field(default_factory=VideoConfig)
    voice: VoiceConfig = Field(default_factory=VoiceConfig)
    qato_auth: QatoAuthConfig = Field(default_factory=QatoAuthConfig)
    threat_mitigation: ThreatMitigationConfig = Field(
        default_factory=ThreatMitigationConfig
    )
    whitepaper: WhitePaperConfig = Field(default_factory=WhitePaperConfig)
    connections: ConnectionsConfig = Field(default_factory=ConnectionsConfig)
    blog: BlogConfig = Field(default_factory=BlogConfig)
    registry: RegistryConfig = Field(default_factory=RegistryConfig)
    embedding: QDEmbeddingConfig = Field(default_factory=QDEmbeddingConfig)

    # ------------------------------------------------------------------
    # Factories
    # ------------------------------------------------------------------
    @classmethod
    def from_dict(cls, data: Optional[Dict[str, Any]] = None) -> "QDConfig":
        """Build a QDConfig from a nested dict.

        The dict must mirror the model hierarchy exactly; unknown keys at
        any level raise ``pydantic.ValidationError`` thanks to
        ``extra="forbid"``.
        """
        return cls.model_validate(data or {})

    @classmethod
    def from_toml(
        cls,
        path: Optional[str | os.PathLike] = None,
        *,
        apply_env: bool = True,
        include_defaults: bool = True,
    ) -> "QDConfig":
        """Load a QDConfig from a TOML file.

        Merge order (later wins): shipped defaults → user TOML → QD env
        overlay (``QD__*``) → AF env overlay (``AF__*`` + bare secret
        aliases) spliced into the ``agentfoundry`` sub-tree.

        Args:
            path: Explicit TOML path. When ``None``, searches
                ``./quantumdrive.toml`` then
                ``~/.config/quantumdrive/quantumdrive.toml`` then the
                shipped default. Raises ``ConfigurationError`` if
                ``path`` is given but missing.
            apply_env: Overlay ``QD__*`` and ``AF__*`` env vars on top of
                the file.
            include_defaults: Pre-merge the packaged default TOML. Disable
                only in tests that want to inspect the file in isolation.
        """
        from core.config.env import env_overlay as qd_env_overlay
        from core.config.toml import load_toml, resolve_toml_path
        from agentfoundry.config.env import env_overlay as af_env_overlay

        merged: Dict[str, Any] = {}
        if include_defaults:
            merged = _af_deep_merge(merged, _load_shipped_defaults())

        resolved_path = resolve_toml_path(path)
        if resolved_path is not None and (
            # Skip re-loading the shipped default if include_defaults already covered it.
            not include_defaults
            or resolved_path.resolve() != _shipped_defaults_path().resolve()
        ):
            merged = _af_deep_merge(merged, load_toml(resolved_path))

        if apply_env:
            merged = _af_deep_merge(merged, qd_env_overlay())
            af_overlay = af_env_overlay()
            if af_overlay:
                merged.setdefault("agentfoundry", {})
                merged["agentfoundry"] = _af_deep_merge(
                    merged.get("agentfoundry", {}) or {}, af_overlay
                )

        return cls.from_dict(merged)

    @classmethod
    def from_env(cls, *, include_defaults: bool = True) -> "QDConfig":
        """Build a QDConfig purely from environment variables.

        Equivalent to merging shipped defaults with QD + AF env overlays.
        """
        from core.config.env import env_overlay as qd_env_overlay
        from agentfoundry.config.env import env_overlay as af_env_overlay

        merged: Dict[str, Any] = {}
        if include_defaults:
            merged = _af_deep_merge(merged, _load_shipped_defaults())
        merged = _af_deep_merge(merged, qd_env_overlay())
        af_overlay = af_env_overlay()
        if af_overlay:
            merged.setdefault("agentfoundry", {})
            merged["agentfoundry"] = _af_deep_merge(
                merged.get("agentfoundry", {}) or {}, af_overlay
            )
        return cls.from_dict(merged)

    # ------------------------------------------------------------------
    # Derived path helpers
    # ------------------------------------------------------------------
    # Each helper returns the explicit override from the sub-model when set,
    # otherwise a conventional default rooted at ``paths.data_dir_path``.
    # Keeping these on :class:`QDConfig` (rather than on the individual
    # sub-models) avoids having sub-models reference their parent.

    # ── Connections ────────────────────────────────────────────────────
    @property
    def connections_dir_path(self) -> Path:
        if self.connections.dir:
            return Path(os.path.expanduser(self.connections.dir))
        return self.paths.data_dir_path / "connections"

    @property
    def connections_registry_path(self) -> Path:
        if self.connections.registry_path:
            return Path(os.path.expanduser(self.connections.registry_path))
        return self.connections_dir_path / "registry.json"

    @property
    def connections_secret_store_path(self) -> Path:
        if self.connections.secret_store_path:
            return Path(os.path.expanduser(self.connections.secret_store_path))
        return self.connections_dir_path / "secrets.json"

    @property
    def connections_audit_log_path(self) -> Path:
        if self.connections.audit_log_path:
            return Path(os.path.expanduser(self.connections.audit_log_path))
        return self.connections_dir_path / "audit.jsonl"

    @property
    def connections_recipe_registry_path(self) -> Path:
        if self.connections.recipe_registry_path:
            return Path(os.path.expanduser(self.connections.recipe_registry_path))
        return self.connections_dir_path / "recipes.json"

    @property
    def connections_query_history_path(self) -> Path:
        if self.connections.query_history_path:
            return Path(os.path.expanduser(self.connections.query_history_path))
        return self.connections_dir_path / "query_history.jsonl"

    # ── Blog ────────────────────────────────────────────────────────────
    @property
    def blog_registry_path(self) -> Path:
        if self.blog.registry_path:
            return Path(self.blog.registry_path).expanduser()
        return self.paths.data_dir_path / "blogs" / "registry.json"

    # ── Presentation ───────────────────────────────────────────────────
    @property
    def presentation_dir_path(self) -> Path:
        if self.presentation.dir:
            return Path(os.path.expanduser(self.presentation.dir))
        return self.paths.data_dir_path / "presentations"

    @property
    def presentation_output_dir(self) -> Path:
        if self.presentation.output_dir:
            return Path(os.path.expanduser(self.presentation.output_dir))
        return self.presentation_dir_path / "output"

    @property
    def presentation_spec_dir(self) -> Path:
        if self.presentation.spec_dir:
            return Path(os.path.expanduser(self.presentation.spec_dir))
        return self.presentation_dir_path / "specs"

    @property
    def presentation_thumbnail_dir(self) -> Path:
        if self.presentation.thumbnail_dir:
            return Path(os.path.expanduser(self.presentation.thumbnail_dir))
        return self.presentation_dir_path / "thumbnails"

    @property
    def presentation_renderer_script_path(self) -> Path:
        if self.presentation.renderer_script_path:
            return Path(os.path.expanduser(self.presentation.renderer_script_path))
        return (
            Path(__file__).resolve().parent.parent.parent
            / "core"
            / "presentation"
            / "render_from_spec.js"
        )

    # ── Video ──────────────────────────────────────────────────────────
    @property
    def video_dir_path(self) -> Path:
        if self.video.dir:
            return Path(os.path.expanduser(self.video.dir))
        return self.paths.data_dir_path / "videos"

    @property
    def video_output_dir(self) -> Path:
        if self.video.output_dir:
            return Path(os.path.expanduser(self.video.output_dir))
        return self.video_dir_path / "output"

    @property
    def video_script_dir(self) -> Path:
        if self.video.script_dir:
            return Path(os.path.expanduser(self.video.script_dir))
        return self.video_dir_path / "scripts"

    @property
    def video_working_dir(self) -> Path:
        if self.video.working_dir:
            return Path(os.path.expanduser(self.video.working_dir))
        return self.video_dir_path / "working"

    @property
    def video_gen_script_path(self) -> Path:
        if self.video.gen_script_path:
            return Path(os.path.expanduser(self.video.gen_script_path))
        return (
            Path(__file__).resolve().parent.parent.parent
            / "core"
            / "video"
            / "video_gen"
            / "generate.js"
        )

    @property
    def video_gen_dir(self) -> Path:
        if self.video.gen_dir:
            return Path(os.path.expanduser(self.video.gen_dir))
        return (
            Path(__file__).resolve().parent.parent.parent
            / "core"
            / "video"
            / "video_gen"
        )

    # ── Threat mitigation ──────────────────────────────────────────────
    @property
    def threat_mitigation_job_store_path(self) -> Path:
        if self.threat_mitigation.job_store_path:
            return Path(os.path.expanduser(self.threat_mitigation.job_store_path))
        return self.paths.data_dir_path / "threat_mitigation" / "jobs.jsonl"

    @property
    def threat_mitigation_audit_log_path(self) -> Path:
        if self.threat_mitigation.audit_log_path:
            return Path(os.path.expanduser(self.threat_mitigation.audit_log_path))
        return self.paths.data_dir_path / "threat_mitigation" / "audit.jsonl"

    # ── WhitePaper ─────────────────────────────────────────────────────
    @property
    def whitepaper_dir_path(self) -> Path:
        if self.whitepaper.dir:
            return Path(os.path.expanduser(self.whitepaper.dir))
        return self.paths.data_dir_path / "whitepapers"

    @property
    def whitepaper_output_dir(self) -> Path:
        if self.whitepaper.output_dir:
            return Path(os.path.expanduser(self.whitepaper.output_dir))
        return self.whitepaper_dir_path / "output"

    @property
    def whitepaper_templates_dir(self) -> Path:
        if self.whitepaper.templates_dir:
            return Path(os.path.expanduser(self.whitepaper.templates_dir))
        return self.whitepaper_dir_path / "templates"

    @property
    def whitepaper_references_dir(self) -> Path:
        if self.whitepaper.references_dir:
            return Path(os.path.expanduser(self.whitepaper.references_dir))
        return self.whitepaper_dir_path / "references"

    @property
    def whitepaper_kb_dir(self) -> Path:
        return self.whitepaper_dir_path / "knowledge_base"

    @property
    def whitepaper_job_store_path(self) -> Path:
        if self.whitepaper.job_store_path:
            return Path(os.path.expanduser(self.whitepaper.job_store_path))
        return self.whitepaper_dir_path / "jobs.jsonl"

    # ── Code graph ─────────────────────────────────────────────────────
    @property
    def code_graph_kgraph_path(self) -> str:
        """Filesystem path for the code-graph subsystem.

        Falls back to ``agentfoundry.paths.state_dir`` when no explicit
        ``code_graph.kgraph_path`` is set.
        """
        if self.code_graph.kgraph_path:
            return self.code_graph.kgraph_path
        af_state = self.agentfoundry.paths.state_dir
        if af_state is not None:
            return str(af_state)
        return "~/.config/agentfoundry/data"

    @property
    def code_graph_backend(self) -> str:
        return (
            self.code_graph.backend
            or self.agentfoundry.kgraph.backend
            or "duckdb_sqlite"
        )


# ---------------------------------------------------------------------------
# Shipped defaults
# ---------------------------------------------------------------------------


def _shipped_defaults_path() -> Path:
    return Path(__file__).parent / "resources" / "default_quantumdrive.toml"


_DEFAULTS_CACHE: Optional[Dict[str, Any]] = None


def _load_shipped_defaults() -> Dict[str, Any]:
    """Load and cache the packaged default TOML."""
    global _DEFAULTS_CACHE
    if _DEFAULTS_CACHE is not None:
        return dict(_DEFAULTS_CACHE)
    from core.config.toml import load_toml

    path = _shipped_defaults_path()
    try:
        _DEFAULTS_CACHE = load_toml(path)
    except Exception as exc:  # pragma: no cover - packaged resource should exist
        logger.warning("Could not load shipped QD defaults at %s: %s", path, exc)
        _DEFAULTS_CACHE = {}
    return dict(_DEFAULTS_CACHE)


def _reset_defaults_cache() -> None:
    """Reset the cached shipped defaults. Test-only."""
    global _DEFAULTS_CACHE
    _DEFAULTS_CACHE = None


# Public re-export for symmetry with ``agentfoundry.config.load_shipped_defaults``.
load_shipped_defaults = _load_shipped_defaults
