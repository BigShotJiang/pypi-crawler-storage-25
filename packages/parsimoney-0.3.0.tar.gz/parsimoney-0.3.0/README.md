# parsimoney

A strict money parser. Reads what humans write, preserves what they meant.

```python
from parsimoney import parse_money

parse_money("$45.00")        # Money(amount=45.0, currency="$", iso=None)
parse_money("45 dollars")    # Money(amount=45.0, currency="dollars", iso=None, currency_after=True)
parse_money("EUR 1,234.56")  # Money(amount=1234.56, currency="EUR", iso="EUR")
parse_money("\u20ac100")      # Money(amount=100.0, currency="\u20ac", iso="EUR")
parse_money("1000 yen")      # Money(amount=1000.0, currency="yen", iso="JPY")
```

Strict: the entire input must be accounted for. No silent data loss.

```python
parse_money("$45.00 worth of stuff")  # raises ValueError
```

## ISO Resolution

Unambiguous currencies resolve automatically. Ambiguous ones like `$`
and "dollars" (USD? CAD? AUD?) resolve via application-provided defaults
or locale:

```python
parse_money("$100", defaults={"$": "CAD"})
# Money(amount=100.0, currency="$", iso="CAD")

parse_money("100 dollars", defaults={"dollars": "AUD"})
# Money(amount=100.0, currency="dollars", iso="AUD", currency_after=True)
```

Without an explicit default, ambiguous currencies check the system
locale. If the locale doesn't resolve it either, `iso` is `None` -
parsimoney never guesses.

## CLI

```
$ python -m parsimoney '$45.00' '100 euros' '1,234 USD'
'$45.00' -> $45
'100 euros' -> 100 euros
'1,234 USD' -> 1234 USD
```
