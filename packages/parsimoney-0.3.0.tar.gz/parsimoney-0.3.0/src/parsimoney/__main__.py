"""parsimoney CLI - parse money values from the command line.

Usage: python -m parsimoney "$45.00" "1,234 EUR" "50 dollars"
"""

import sys

from parsimoney import parse_money


def main() -> None:
    if len(sys.argv) < 2:
        print("Usage: python -m parsimoney <value> [<value> ...]", file=sys.stderr)
        sys.exit(1)

    for arg in sys.argv[1:]:
        try:
            result = parse_money(arg)
            print(f"{arg!r} -> {result}")
        except ValueError as err:
            print(f"{arg!r} -> ERROR: {err}", file=sys.stderr)
            sys.exit(1)


if __name__ == "__main__":
    main()
