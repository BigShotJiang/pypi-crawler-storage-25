"""parsimoney - A strict money parser.

Parses human-written money values into structured (amount, currency) pairs.
Strict: the entire input must be accounted for. No silent data loss.
"""

from importlib.metadata import metadata, version

from parsimoney.currencies import resolve_iso
from parsimoney.parser import parse_money
from parsimoney.types import Money

__version__ = version(__name__)
__author__ = metadata(__name__)["Author-email"]
__all__ = ["__version__", "__author__", "parse_money", "Money", "resolve_iso"]
