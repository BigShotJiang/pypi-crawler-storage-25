Thanks for using PyVoice!

Example code:

import PyVoice.pyvoice as pyvoice

speak = pyvoice.Voice.speak
speak("You text here or without quotes your variable or list.")