from colorama import Fore, Back, Style

print(Fore.YELLOW + "Thanks for using PyVoice!")