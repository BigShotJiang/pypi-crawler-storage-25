import pyttsx3

class Voice:
    def speak(text):
        pyttsx3.speak(text)
    