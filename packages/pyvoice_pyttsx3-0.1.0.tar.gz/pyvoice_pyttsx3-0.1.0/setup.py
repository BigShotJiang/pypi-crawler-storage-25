from setuptools import setup, find_packages

setup(
    name="pyvoice-pyttsx3",
    version="0.1.0",
    packages=find_packages(),
    install_requires=[
        "pyttsx3",
        "colorama",
    ],
    author="DoorsProYT",
    description="Text-to-speech",
    long_description="My-first-library",
    long_description_content_type="text/plain",
    python_requires='>=3.13.1',
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
)
