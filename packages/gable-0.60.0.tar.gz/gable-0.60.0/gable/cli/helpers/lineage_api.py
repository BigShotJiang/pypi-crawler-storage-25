"""Helper functions for uploading lineage data via API."""

import os
from typing import Optional, Union

import click
from loguru import logger

from gable.api.client import GableAPIClient, gzip_payload
from gable.common_types import LineageDataFile
from gable.openapi import (
    CrossServiceDataStore,
    CrossServiceDataStoreApiRequest,
    CrossServiceEdge,
    CrossServiceEdgeApiRequest,
    ErrorResponse,
    Metadata1,
    Metadata3,
    ScaResultsUploadRequest,
    StaticAnalysisDataFlowPath,
    StaticAnalysisPathsApiRequest,
)

# Default chunk size in bytes (4 MiB).
# Keep a healthy buffer below the 6 MiB API Gateway limit so the serialized
# request body stays comfortably under the cap across different payload shapes.
DEFAULT_MAX_CHUNK_SIZE_BYTES = 4 * 1024 * 1024


def _get_max_chunk_size_bytes() -> int:
    env_value = os.getenv("GABLE_MAX_CHUNK_SIZE_BYTES")
    if env_value is None:
        return DEFAULT_MAX_CHUNK_SIZE_BYTES

    try:
        chunk_size = int(env_value)
    except ValueError:
        logger.warning(
            "Invalid GABLE_MAX_CHUNK_SIZE_BYTES value '{}'; using default {}",
            env_value,
            DEFAULT_MAX_CHUNK_SIZE_BYTES,
        )
        return DEFAULT_MAX_CHUNK_SIZE_BYTES

    if chunk_size <= 0:
        logger.warning(
            "GABLE_MAX_CHUNK_SIZE_BYTES must be > 0 (got {}); using default {}",
            chunk_size,
            DEFAULT_MAX_CHUNK_SIZE_BYTES,
        )
        return DEFAULT_MAX_CHUNK_SIZE_BYTES

    return chunk_size


MAX_CHUNK_SIZE_BYTES = _get_max_chunk_size_bytes()


def _convert_metadata3_to_metadata1(
    metadata: Optional[Metadata3],
) -> Optional[Metadata1]:
    """Convert Metadata3 to Metadata1 (they have the same structure)."""
    if metadata is None:
        return None
    return Metadata1(extras=metadata.extras)


def _get_compressed_upload_request_size_bytes(
    api_request: Union[
        StaticAnalysisPathsApiRequest,
        CrossServiceDataStoreApiRequest,
        CrossServiceEdgeApiRequest,
    ],
) -> int:
    """Return the gzipped byte size of the serialized SCA upload request."""
    payload = ScaResultsUploadRequest(root=api_request).model_dump_json(
        by_alias=True, exclude_none=True
    )
    return len(gzip_payload(payload))


def _build_static_analysis_paths_request(
    lineage_data_file: LineageDataFile,
    run_id: str,
    paths: list[StaticAnalysisDataFlowPath],
) -> StaticAnalysisPathsApiRequest:
    """
    Build a CODE SCA request for the provided path chunk.

    Args:
        lineage_data_file: The original lineage data file containing metadata and other fields
        run_id: The ID of the run to include in the request
        paths: The specific chunk of paths to include in this request

    Returns:
        A StaticAnalysisPathsApiRequest object ready for upload
    """
    return StaticAnalysisPathsApiRequest(
        paths=paths,
        run_id=run_id,
        external_component_id=lineage_data_file.external_component_id,
        type="CODE",
        metadata=_convert_metadata3_to_metadata1(lineage_data_file.metadata),
        name=lineage_data_file.name,
    )


def _find_largest_compressed_chunk_end(
    lineage_data_file: LineageDataFile,
    run_id: str,
    chunk_start: int,
) -> int:
    """
    Find the largest chunk of paths that fits within the maximum compressed request size.

    Algorithm:
        Try all remaining paths first,
        then binary search for the largest compressed prefix that fits
        while always allowing one oversized path to make progress.

    Tradeoff:
        Minimizes upload count by packing chunks close to the limit,
        at the cost of extra serialization and compression checks.

    Args:
        lineage_data_file: The lineage data file containing paths
        run_id: The ID of the run
        chunk_start: The starting index of the chunk

    Returns:
        The ending index of the largest chunk that fits within the size limit
    """
    paths = lineage_data_file.paths
    total_paths = len(paths)

    remaining_request = _build_static_analysis_paths_request(
        lineage_data_file, run_id, paths[chunk_start:total_paths]
    )
    if (
        _get_compressed_upload_request_size_bytes(remaining_request)
        <= MAX_CHUNK_SIZE_BYTES
    ):
        return total_paths

    low = chunk_start + 1
    high = total_paths
    chunk_end = low

    while low <= high:
        mid = (low + high) // 2
        test_request = _build_static_analysis_paths_request(
            lineage_data_file, run_id, paths[chunk_start:mid]
        )
        test_size = _get_compressed_upload_request_size_bytes(test_request)

        if test_size <= MAX_CHUNK_SIZE_BYTES:
            chunk_end = mid
            low = mid + 1
        else:
            high = mid - 1

    while chunk_end > chunk_start + 1:
        chunk_request = _build_static_analysis_paths_request(
            lineage_data_file, run_id, paths[chunk_start:chunk_end]
        )
        if (
            _get_compressed_upload_request_size_bytes(chunk_request)
            <= MAX_CHUNK_SIZE_BYTES
        ):
            break
        chunk_end -= 1

    return chunk_end


def _upload_api_request(
    client: GableAPIClient,
    api_request: Union[
        StaticAnalysisPathsApiRequest,
        CrossServiceDataStoreApiRequest,
        CrossServiceEdgeApiRequest,
    ],
    request_type: str,
) -> None:
    """Helper function to upload an API request and handle errors.

    Args:
        client: The Gable API client
        api_request: The API request object to upload
        request_type: A string describing the request type (for error messages)
    """
    upload_request = ScaResultsUploadRequest(root=api_request)
    response, success, status_code = client.post_sca_results(upload_request)

    if not success:
        error_msg = (
            f"API upload failed for {request_type}: "
            f"{response.message if isinstance(response, ErrorResponse) else response}"
        )
        raise click.ClickException(error_msg)

    logger.debug(f"Successfully uploaded {request_type} via API")


def upload_sca_results_via_api(
    client: GableAPIClient,
    run_id: str,
    lineage_data_file: Union[CrossServiceDataStore, CrossServiceEdge, LineageDataFile],
) -> None:
    """Upload SCA results via the API endpoint with chunking support.

    For CODE type (LineageDataFile), chunks the paths array to keep each chunk
    under the configured request-size limit.
    For DATA_STORE and EDGE types, sends the data as-is since they are single objects.

    Args:
        client: The Gable API client
        run_id: The ID of the run
        lineage_data_file: The lineage object to serialize and upload
    """
    if isinstance(lineage_data_file, LineageDataFile):
        # Chunk the paths array for CODE type
        paths = lineage_data_file.paths
        total_paths = len(paths)
        if total_paths == 0:
            empty_chunk_request = _build_static_analysis_paths_request(
                lineage_data_file, run_id, paths
            )
            _upload_api_request(client, empty_chunk_request, "chunk 1")
            logger.debug(f"Successfully uploaded empty chunk via API")
            return

        chunk_start = 0
        chunk_index = 0

        logger.debug(f"Uploading {total_paths} paths via API with chunking")

        while chunk_start < total_paths:
            chunk_end = _find_largest_compressed_chunk_end(
                lineage_data_file, run_id, chunk_start
            )
            chunk_paths = paths[chunk_start:chunk_end]
            chunk_request = _build_static_analysis_paths_request(
                lineage_data_file, run_id, chunk_paths
            )

            # Upload this chunk
            _upload_api_request(client, chunk_request, f"chunk {chunk_index + 1}")

            logger.debug(
                f"Uploaded chunk {chunk_index + 1} with {len(chunk_paths)} paths "
                f"({chunk_start + 1}-{chunk_end} of {total_paths})"
            )

            chunk_start = chunk_end
            chunk_index += 1

        logger.debug(f"Successfully uploaded {chunk_index} chunk(s) via API")

    elif isinstance(lineage_data_file, CrossServiceDataStore):
        # DATA_STORE type - send as single request
        payload = lineage_data_file.model_dump(by_alias=True, exclude_none=True)
        payload["run_id"] = run_id  # ensure we use the run_id from the SCA run
        api_request = CrossServiceDataStoreApiRequest.model_validate(payload)
        _upload_api_request(client, api_request, "DATA_STORE")

    elif isinstance(lineage_data_file, CrossServiceEdge):
        # EDGE type - send as single request
        payload = lineage_data_file.model_dump(by_alias=True, exclude_none=True)
        payload["run_id"] = run_id  # ensure we use the run_id from the SCA run
        req = CrossServiceEdgeApiRequest.model_validate(payload)
        _upload_api_request(client, req, "EDGE")

    else:
        raise ValueError(
            f"Unsupported lineage_data_file type: {type(lineage_data_file)}"
        )
