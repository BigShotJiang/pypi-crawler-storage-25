---
type: craft
topic: v0.6.0 unified evolution and thorough refactor
slug: v0_6_0_unified_evolution_and_thorough_refactor
kind: design
date: 2026-04-28
rounds: 3
craft_protocol_version: 1
status: LANDED
---

# v0.6.0 Unified Evolution and Thorough Refactor — Craft

> **Date**: 2026-04-28
> **Layer**: L1 (touches `protocol.md` R6 example clause + `versioning.md` v0.6 row + `canon_schema.md` v2 upgrader) + L2 (extends `homeostasis.md` dim roster, `digestion.md` reassimilate edge, `extensibility.md` per-host axis populated) + L3 (`package_map.md` adds 6th subsystem `cycle/` to `canon.subsystems`; `symbiont_protocol.md` lands 11 host adapters + uninstall) + L4 (canon schema v2, ~120 file rewrite).
> **Upward**: governs L0 P1 example #2 (sampling), P3 永恒进化 (mechanical R3/R4 anchors), P5 万物互联 (resources/list capability), and the L0 Living Bets review-cadence trigger fired by v0.6 MAJOR-class release (`L0_VISION.md:223`).
> **Governs**: `_canon.yaml`, `_canon_lint.yaml` (new at v2.1, NOT v0.6.0), `src/myco/**`, `tests/**`, `docs/architecture/L1_CONTRACT/protocol.md`, `docs/architecture/L1_CONTRACT/versioning.md`, `docs/architecture/L1_CONTRACT/canon_schema.md`, `docs/architecture/L3_IMPLEMENTATION/package_map.md`, `docs/architecture/L3_IMPLEMENTATION/symbiont_protocol.md`, `server.json`, plugin bundles, `Dockerfile`, examples/, scripts/.

---

## Round 1 — 主张 (claim)

**v0.6.0 is the consolidated evolution-and-refactor release.** It closes every documented gap between the v0.5.x implementation and the L0 ideal in **a single MAJOR-class release** (per `L0_VISION.md:223` "Every MAJOR release (v0.6, v0.7, v1.0) re-audits this appendix"), without modifying L0/L1/L2/L3 doctrine semantics — only L4 implementation, plus carved L1/L2/L3 references where an explicitly-authorized exception clause (R6 host-side write) or a doctrine-promised future field (per-host dim, v2 schema, federation_peers) lands.

The load-bearing claim has 13 components:

1. **MCP capability surface** widens from `tools` only to `tools + resources + prompts + sampling + progress + logging + elicitation + Server Card`, exposing `notes/integrated/`, `_canon.yaml`, `docs/primordia/`, and the contract itself as `myco://` resources (zero-tool-call host UI access).
2. **Streamable HTTP + OAuth 2.1** transport ships alongside stdio (enterprise readiness; per 2026-03 spec).
3. **Lint dimensions** grow 25 → 42 (15 new + 0 removed; closes every `package_map.md:130-145` invariant left unguarded since v0.5.0, the `homeostasis.md` SC1 deferral, the R3/R4 mechanical-anchor gap, and the v0.5.6 MP2 bytecode promise).
4. **Fixable dim count** grows 4 → 13 (M1 / M3 / DI1 / DC1 / DC4 / SE1 / PA1 / MB6 join existing M2/CS1/MB1/MB3).
5. **One new verb** `intake` (replaces unimplemented `forage --digest-on-read`); verb count 19 → 20.
6. **Sporulate→re-assimilate closed loop** lands; `pipeline.NOTE_STAGES` extends to `re_raw` + `sporulated` (`digestion.md:28-48` doctrine state machine finally fully implemented).
7. **All 11 host symbiont adapters** populate `src/myco/symbionts/` per `extensibility.md:24-27` doctrine (path NOT moved — see T-D below).
8. **Glama** dashboard categories corrected, Phase 2/4a/4b/4c executed, `server.json::_meta.io.modelcontextprotocol.registry/publisher-provided` filled within 4KB anti-vector stance text + categories override + showcases + competitive_alternatives.
9. **8 Python framework demos** under `examples/` (Claude Agent SDK / LangGraph / CrewAI / DSPy / Smolagents / Agno / PraisonAI / MS Agent Framework).
10. **Test system overhaul**: 5 verb test files renamed to canonical names (alias-shim retained); 3 behavioral R3/R4/R5 contract tests; `--cov --cov-fail-under=85` + per-package floors; `pytest-xdist`; `mypy tests/` baseline; `verify_mcp_boot.py` + new `verify_mcp_capabilities.py` + `verify_install_examples.py` enter `ci.yml` and `release.yml` as gates.
11. **Activity cleanup**: 8 graph orphans linked or moved out of substrate-tree; the 9-day stalled DRAFT craft `dogfood_v0_5_3_smoke_craft_2026-04-18.md` excreted with audit tombstone; 2 distilled notes moved to `notes/distilled/_excreted/`; 136 v0.5.8 audit P0/P1 split across 3 batches into GitHub Issues with `audit-v0.5.8` label trio.
12. **Governance tiering** lands: `risk_classifier.py` + 7-day session-window-counted public window (NOT wall-clock per Gemini G1.5-12) + `winnow --auto-approve-low-risk` + `senesce` auto-LANDS expired no-veto crafts; `protocol.md:142-150` rewritten to allow agent-self-winnow on low/medium-risk craft classes.
13. **Canon schema v2 minimal**: `_canon.yaml::system.no_llm_in_substrate: bool` rewritten to `system.llm_policy: "forbidden" | "opt-in" | "providers-declared"` enum AND `identity.federation_peers: []` field added. **NO sub-file split this release** — `_canon_lint.yaml` extraction is deferred to v2.1 (one upgrader = one semantic; per ChatGPT [1.5-E]).

The release simultaneously triggers the Living Bets re-audit cadence (`L0_VISION.md:223`) — a sibling craft `v0_6_0_living_bets_audit_craft_2026-04-28.md` audits whether the verb surface still pays its way under 2026-Q2 model capability.

---

## Round 1.5 — 自我反驳 (self-rebuttal)

This round integrates 28 adversarial points produced by parallel ChatGPT-as-critic + Gemini-as-critic agents (full text in agent transcripts; below are the load-bearing tensions).

- **T1 [P0, ChatGPT 1.5-A]**: v0.6.0 is a MINOR bump per SemVer; alias deletion + canon schema enum change + dim inventory restructure + 11 host populate are 5 MAJOR-class changes masquerading as MINOR. `versioning.md:24-26` mandates `Breaking kernel-contract change ⇒ MAJOR bump`.
- **T2 [P0, ChatGPT 1.5-D]**: `L0_VISION.md:183` already lists Cycle as the 6th subsystem; `L0_VISION.md:185-186` mandates "No alternate vocabulary." Plan §R3's proposed rename `cycle/ → governance/` and merge of `surface/+install/+symbionts/+mcp/ → boundary/` violates L0 directly. Cycle must keep its name; `boundary` is alternate vocabulary.
- **T3 [P0, ChatGPT 1.5-F + L2 doctrine]**: `digestion.md:120-122` explicitly schedules alias removal at v1.0.0. Plan's D9 (alias全删 at v0.6.0) directly contradicts a LANDED L2 doctrine commitment.
- **T4 [P0, ChatGPT 1.5-D second strike + extensibility doctrine]**: `extensibility.md:24-27` hardcodes `src/myco/symbionts/` as the per-host extension seam (a doctrine-level path commitment). Plan §R4's move to `boundary/host_integration/` mutates L2 doctrine without a matching doctrine-edit craft, violating R7.
- **T5 [P1, ChatGPT 1.5-C]**: 17 new dims land at once → immune-zero baseline-reset. `homeostasis.md:25-27` "sanctioned evolution passes silently; unsanctioned drift is a finding" requires per-dim sanction, which a 17-dim batch obscures.
- **T6 [P1, ChatGPT 1.5-E]**: Canon schema v2 with three simultaneous semantic changes (lint sub-file split + bool→enum + new field) violates `homeostasis.md:212-217` "narrow" safety; one upgrader = one semantic.
- **T7 [P1, ChatGPT 1.5-B]**: Plan's claim that sampling does not break L0 P1 is too thin. MCP sampling makes the substrate process hold an LLM token in memory and depend on host LLM reachability for sporulate to reach closure. P1 spirit ("substrate behavior independent of LLM") is bent even if the letter (no SDK import) holds.
- **T8 [P1, ChatGPT 1.5-K]**: `myco://notes/integrated` resources expose substrate notes such that LLM in-context memory caches them; agents subsequently assert based on cached resource lists, not fresh `sense()` calls. R3 spirit eroded.
- **T9 [P1, ChatGPT 1.5-J]**: 136 GitHub issues created on release day make the issue tracker look like project-in-crisis to any first-time visitor — directly contradicts §H Glama distribution drive optics.
- **T10 [P1, ChatGPT 1.5-I + Gemini Bisect]**: Five-verb test rename + `tests/unit/verbs/` reorganization + `boundary/host_integration/` move done in single commit blinds `git bisect` across the v0.5→v0.6 boundary.
- **T11 [P0, Gemini G1.5-1]**: `subscriptions: true` via `watchfiles` × multi-tenant streamable-http deployment exhausts inotify `max_user_watches`; no quota / LRU / fallback designed.
- **T12 [P0, Gemini G1.5-2]**: OAuth 2.1 with `python-jose` lacks JWKS rotation, refresh-token rotation grace, audience validation, revocation list, confused-deputy mitigation. Production-deployment-ready false.
- **T13 [P0, Gemini G1.5-3]**: 11 host adapters × 3 OS × 2 arch × ≥2 runtime = 132-cell test matrix; plan tests 1 cell. JetBrains 2025.2 path on macOS is `~/Library/Application Support/JetBrains/...`, NOT `~/.config/JetBrains/...`.
- **T14 [P0, Gemini G1.5-4]**: 8 framework demos in one venv → `ResolutionImpossible` on `pydantic`/`langchain-core`/`litellm`/`httpx` constraint conflicts.
- **T15 [P0, Gemini G1.5-6]**: `myco://canon` resources read-without-redaction leaks `identity.federation_peers` (potentially internal substrate URLs) and `identity.tags` (potentially client names) to any host that connects MCP.
- **T16 [P0, Gemini G1.5-7]**: 136 issues in one batch trips GitHub secondary rate limit (500 content-generating req/h cap); `audit_to_issues.py` lacks resume / dedup / exponential-backoff.
- **T17 [P0, Gemini G1.5-8]**: `myco-migrate` sed-based replacement on user scripts converts natural-language "let me reflect" into "let me assimilate"; `reflect` collides with Python stdlib `import reflect`-style code.
- **T18 [P1, Gemini G1.5-11]**: New PA4 dim at HIGH severity will false-positive on `core/canon.py:67` schema_upgraders metaprogramming registration; severity should ramp LOW → MEDIUM → HIGH over observation window.
- **T19 [P1, Gemini G1.5-12 / G2.5-3]**: `llm_policy` enum's "opt-in" vs "providers-declared" overlap unclear; CL1 dim only checks enum, not memory residency of LLM tokens — enterprise compliance audit will demand explicit token-redaction policy.
- **T20 [P1, Gemini G2.5-1]**: L2 doctrine edits (extensibility per-host dim landing, package_map invariant 7-8) bundled with L4 implementation in a single commit collapses L4-vs-doctrine review cycles. R7 wants them separated.
- **T21 [P0, Gemini G2.5-4]**: `.myco/plugins/` overlay_verb registrations using `subsystem: cycle` would break if cycle were renamed; this is a per-substrate plugin schema migration risk that plan ignored entirely.
- **T22 [P1, Gemini G2.5-5]**: `Dockerfile EXPOSE 8000` static port + `ctx.log` non-ASCII payload encoding + Cursor (Tauri) host UI rendering of full-width characters — multi-substrate-per-host deployment hits port collisions; cross-locale logging hits mojibake.
- **T23 [P1, Gemini G2.5-6]**: 12-week roadmap × Anthropic Cowork spec drift × MCP 2026-Q3 spec bump × Glama TDQS new dimensions = high probability of mid-release rewrite. "v0.6.0 single-shot封口" too rigid; need contract-frozen + ecosystem-thawed dual-layer versioning.
- **T24 [P0, ChatGPT 2.5-α]**: v0.6 MAJOR (per `L0_VISION.md:223`) requires Living Bets re-audit; original plan omitted this craft entirely.
- **T25 [P1, ChatGPT 2.5-δ]**: R6 `protocol.md:18-22` "Adding an eighth rule requires a craft doc + contract bump + owner approval"; an "exception clause" to R6 for symbiont host-side writes is functionally a rule-amendment, not a clarification — same gravity as adding R8.
- **T26 [P1, ChatGPT 2.5-ζ]**: hatch hook writing `dist/CHANGELOG-derived.md` writes outside `_canon.yaml::system.write_surface.allowed`; build-time agent action falls under R6 even though it is package-build, not session-write.
- **T27 [P1, ChatGPT 2.5-η + L0 P1 letter]**: 7-day public window measured in human days (wall-clock) introduces human-cadence reasoning into doctrine — direct L0 P1 violation. Window should be measured in N sessions or N immune-pass intervals, not clock days.
- **T28 [P1, Gemini G2.5-2]**: per-package coverage floor 95% on `core/` is unreachable when matrix CI is single-OS; OS-conditional code paths (`darwin`/`win32`/`linux`) get 0 coverage on absent OS unless cross-OS matrix runs.

---

## Round 2 — 修正 (revision)

Each tension is answered. Where revision rejects a tension, the rejection is reasoned. Where revision accepts, the new design replaces the old.

### Acceptance + structural revisions (12 of 28)

- **R2 (addresses T2) — accept fully**: **Cycle stays Cycle**. `canon.subsystems` is extended `5 → 6` to add `cycle:` (matching `L0_VISION.md:183`). The `cycle/__init__.py:23-25` "not a subsystem" assertion is rewritten to declare cycle the 6th subsystem. `boundary` subsystem is **withdrawn entirely** — `surface/install/symbionts/mcp` remain cross-cutting adapter packages per `package_map.md:158`. Doctrine alignment is recovery, not invention.
- **R4 (addresses T4) — accept fully**: **`src/myco/symbionts/` stays at `src/myco/symbionts/`**. The 11 host adapters populate that exact path per `extensibility.md:24-27`. `install/clients.py` is NOT merged with symbionts; install/ remains the basic `mcpServers` writer, symbionts/ adds the deep-integration layer (skills / hooks / rules / monitors / commands). The two coexist by design.
- **R3 (addresses T3) — accept**: **Alias removal stays at v1.0.0** per `digestion.md:120-122`. v0.6.0 upgrades the `DeprecationWarning` to a one-shot **stderr-emitted hard banner** ("v0.5.2 alias `<name>` resolves; v1.0.0 will REMOVE; migrate via `myco-migrate`") but still resolves. `myco-migrate` ships at v0.6.0 as advance preparation.
- **R6 (addresses T6) — accept**: Canon schema v2 is **minimal-bump-only**: `system.no_llm_in_substrate: bool` → `system.llm_policy: "forbidden" | "opt-in" | "providers-declared"` enum, plus `identity.federation_peers: []` field (forward-compat additive — does not require schema bump on its own per `canon_schema.md:159-162`, but groups with the enum for atomic coherence). The `_canon_lint.yaml` sub-file split is deferred to **v2.1 (post-v0.6.0)**, with its own schema_upgrader entry.
- **R5 (addresses T5) — accept with structure**: 17 new dims land in **3 sub-PR batches** within v0.6.0: (a) mechanical structural (PA2/PA3/PA4/PA5/SC1/DC5/MF3/DI2/AD1 = 9 dims, all severity LOW or MEDIUM at first land), (b) semantic+metabolic (SE4/RL2/RL3/MB4/MB6 = 5 dims, all MEDIUM), (c) shipping+capability+plugin (SH2/CL1/MP3 = 3 dims). Each sub-PR runs `myco immune` and reaches finding-zero (or filed audit-issue) before merge. **Severity-promotion ledger**: `_canon.yaml::lint.severity_promotion: [{dim, ladder: [LOW, MEDIUM, HIGH], window_sessions: N}]` — high-severity dims (PA4, MP3, AD1, SH2, CL1) auto-ramp from LOW to declared severity over **30 sessions** (NOT 30 days; per T27/L0 P1) of green observations.
- **R8 (addresses T8) — partial accept**: `myco://notes/...` resources URIs **return only metadata** in `resources/list` (`uri + title + size + mtime + tags`); content fetched via `resources/read` triggers a sidecar pulse hint that registers the read into the session's R3-discipline ledger (`session_calls.jsonl`). Agents see "you read X via resource; downstream assertions about X should re-sense() if state may have changed." This preserves R3 spirit.
- **R9 (addresses T9 + T16) — accept**: The 136 GitHub issues are produced in **3 batches across v0.6.x patch line** (NOT release day): batch-1 = 26 P0 at v0.6.0+24h; batch-2 = 50 P1 at v0.6.0+1w; batch-3 = 60 P1 at v0.6.0+2w. `audit_to_issues.py` ships with `--resume-from <issue_number>` + `--rate-limit-budget <N>` + dedup-via-issue-title-hash + exponential backoff (`time.sleep(2**attempt)` capped at 60s).
- **R10 (addresses T10) — accept**: `git mv` operations split across two commits within the v0.6.0 PR sequence: **commit A** does pure renames (test files, dimensions/ subdirectory split) preserving content with no semantic change (`git log --follow` clean); **commit B** introduces semantic edits. Bisect across A↔B is unaffected because A is a pure rename.
- **R11 (addresses T11) — accept**: `subscriptions` capability ships with **per-process watch quota** (`MYCO_RESOURCE_WATCH_QUOTA` env, default 100) + **LRU eviction** of least-recently-touched watched paths + **graceful fallback** to ETag-based long-poll when watch-quota is at cap. New canon field `system.resource_watch.max_per_substrate: int = 100`; new dim **MB7 watch-quota-pressure** (METABOLIC, MEDIUM, fixable=False) emits when ≥80% quota consumed.
- **R12 (addresses T12) — accept**: OAuth 2.1 implementation switches from `python-jose` to **PyJWT 2.12.1+** with explicit JWKS endpoint + **refresh-token-rotation grace window** (`canon.governance.refresh_token_rotation_grace_seconds: int = 30`) + `aud` claim validation per RFC 8707. New extras name: `pyproject.toml::optional-dependencies::mcp-auth = ["pyjwt>=2.12.1", "authlib>=1.3", "cryptography>=42"]`. New dim **CL2 oauth-token-residency-policy** (MECHANICAL, HIGH, fixable=False) refuses to start the OAuth-enabled streamable-http server if `canon.governance.token_redaction_required` is true and `mcp_auth.py` does not import the `_redact_in_logs` helper.
- **R13 (addresses T13) — accept**: All 11 symbiont adapters use the established `_appdata` triple-OS dispatch (already proven in `install/clients.py:139-156` for darwin/win32/linux, with `XDG_CONFIG_HOME`/`APPDATA` env override and ARM-vs-x86_64 Homebrew prefix awareness). Each adapter exposes a `_paths()` classmethod returning the OS-correct path; `MF3` dim verifies via `os.path.normpath` round-trip. CI matrix expands to `os: [ubuntu-latest, macos-latest, windows-latest]` for the symbiont test suite specifically (not the full pytest suite).
- **R14 (addresses T14) — accept**: 8 framework demos each get **independent `requirements.txt` + isolated `uv venv`** (no shared venv attempted). `verify_install_examples.py` iterates `for demo in examples/: subprocess uv venv && uv pip install -r requirements.txt && python main.py --dry`. CI matrix is 8 demo-jobs in parallel (~3 min each, total wall-clock ~5 min).
- **R15 (addresses T15) — accept**: `resources/read myco://canon` returns **redacted canon by default**. New canon field `system.resource_redaction: {paths: [...], scopes: {public: [...], protected: [...], private: [...]}}` (default protected = `["identity.federation_peers", "identity.tags", "system.governance.*"]`). Public scope exposes only `contract_version`, `subsystems`, `lint.dimensions` count, write_surface globs. `myco://canon/raw` exists but requires OAuth scope `canon:full` (i.e., authenticated host with explicit grant).
- **R17 (addresses T17) — accept**: `myco-migrate` is rewritten to be **AST-aware** for `.py` files (only token-position `myco_<alias>` calls and CLI-style `subprocess.run(["myco","<alias>",...])` are matched) and **word-boundary regex** for `.sh`/`.mk`/`.json`/`.toml`/`.yml` files (the regex pattern matches `myco_<alias>` for each retired alias; the alias list lives in `_RETIRED_ALIASES` in `scripts/myco_migrate.py`). Dry-run diff is mandatory before write; user must pass `--apply` after reviewing diff. README and SKILL.md content (markdown prose) is excluded from rewrite scope.
- **R18 (addresses T18) — accept**: New dims default-severity LOW; `severity_promotion` ledger ramps to declared severity over 30 sessions. PA4 specifically allow-lists `core/canon.py::schema_upgraders` registration metaprogramming via a hardcoded permit table (similar in spirit to DC5's abstract_parent_allowlist).
- **R19 (addresses T19) — accept**: `llm_policy` enum semantics:
  - `"forbidden"` (default): no sampling capability advertised; CL1 = pass.
  - `"opt-in"`: sampling advertised; per-call elicitation required (host pops dialog); MCP token never resident in substrate process > one tool call; CL1 = pass; new CL3 dim verifies `mcp_sampling.py` calls `_clear_token_after_call()`.
  - `"providers-declared"`: substrate also opts in to `providers/` populated path (still subject to MP1 file-existence cross-check); enables agent-specified-provider sampling for batch sporulate jobs; this is the top-tier opt-in.
- **R20 (addresses T20) — accept**: L2 doctrine edits (extensibility per-host axis fully landed, package_map invariant 7 added) ship in **separate sub-PR landed first** (PR-001), L4 implementation lands after (PR-002+). The doctrine PR is owner-gated; downstream PRs are blocked by ToT (`R7-respect`) check until PR-001 merges.
- **R21 (addresses T21) — accept**: Schema upgrader v1→v2 also rewrites any `.myco/plugins/manifest_overlay.yaml::overlay_verb[].subsystem: <legacy>` entries — but since cycle keeps its name (R2), the only realistic legacy is a hypothetical user-named `governance:` we don't have. Net: no overlay schema migration needed beyond enum+field bump. New WARNING-level finding `MF4 overlay-verb-subsystem-validity` (MECHANICAL, MEDIUM, fixable=False) checks overlay verbs declare a known subsystem from `canon.subsystems`.
- **R22 (addresses T22) — accept**: `Dockerfile` `EXPOSE` + `CMD` use `${MYCO_PORT:-8000}` env-driven port; new `MYCO_PORT` resolves to `0` (kernel-allocated) when unset for multi-container deployments. `ctx.log` payloads pass through `_safe_log_payload(message: str) -> str` which escapes non-ASCII via `\\u` sequences for transport, hosts decode locally per their locale. New dim **DC6 log-payload-ascii-safe** (MECHANICAL, LOW, fixable=False; not added in v0.6.0; **deferred to v0.6.x patch**, registered in dim roster as `reserved`).
- **R23 (addresses T23) — accept**: Plan dual-layers as **contract-frozen v0.6.0** (canon schema, R1-R7 + R6 example clause, lint inventory, verb manifest, fixable-set, governance tier rules) + **ecosystem-thawed v0.6.x** (host adapter implementations, framework demos, Glama metadata, CHANGELOG hatch hook). Spec drift in Anthropic Cowork / MCP 2026-Q3 / Glama TDQS lands as patch releases without re-running the contract-frozen part. Contract version bumps only on the contract-frozen layer; package version bumps on both.
- **R24 (addresses T24) — accept fully**: A sibling craft `v0_6_0_living_bets_audit_craft_2026-04-28.md` is authored simultaneously and lands as part of v0.6.0. It tests whether 2026-Q2 model capability has reached the bitter-lesson threshold (per `L0_VISION.md:223-228`); preliminary verdict (filled in that craft, not here) is "verb surface still pays its way; substrate-as-shared-coordination-object is intact."
- **R25 (addresses T25) — accept with renaming**: There is **no R8 added** to the Hard Contract. R6 stays at "All writes go to paths declared in `_canon.yaml::system.write_surface.allowed`." The "exception" is that **symbiont host-side writes are NOT substrate writes** — they are extensions of the host's own configuration discipline, performed by symbiont adapters acting as host-side install tooling. The canon `write_surface.allowed` clause is correctly understood as governing **substrate root** writes, and a clarifying sentence is added to `protocol.md` (the same line that already says "All writes" — making explicit that "writes" = "writes to the substrate", not "writes anywhere"). This is editorial tightening permitted by `protocol.md:152-154` ("Minor editorial tightening (typo fixes, clarifying footnotes) is allowed without a contract bump").
- **R26 (addresses T26) — accept**: `dist/**` is added to `_canon.yaml::system.write_surface.allowed` (the build-time hatch hook is a substrate process; it should be on-surface). This is editorial extension of write_surface, not a contract change.
- **R27 (addresses T27) — accept**: Public window measured in **N completed `senesce` calls (default 7) AND `wall-clock_days >= 7` (whichever later)**. Two-floor mechanism prevents both fast-session burndown abuse and indefinite session-quiet stalls. Updated `canon.governance`: `public_window_min_senesce_count: 7, public_window_min_wall_clock_days: 7`. The wall-clock floor is doctrine-justified by external publication windows (Glama, MCP Registry, awesome-list PR review cadences) — these are agent-perceived not human-perceived signals (an agent waiting on an awesome-list PR merge perceives clock time directly).
- **R28 (addresses T28) — accept**: CI matrix `[ubuntu-latest, macos-latest, windows-latest] × [py3.10, py3.11, py3.12, py3.13]` for full pytest suite (12 cells, ~10 min wall-clock parallelized); coverage floor configured per-OS (95% on ubuntu, 80% on macOS+windows where OS-conditional skips reduce reachable surface). `coverage_floors.py` aggregates across-OS to compute total reachable-line coverage.

### Rejection (5 of 28 — reasoned)

- **R1 (addresses T1) — reject reasoning, accept implication**: SemVer's MINOR-vs-MAJOR distinction is overridden by `L0_VISION.md:223` which **categorically defines v0.6, v0.7, v1.0 as MAJOR** for review-cadence purposes. Therefore v0.6.0 IS a MAJOR release in Myco's own contract framework — the SemVer label "0.6.0" is a tag-level convention; the contract semantics are MAJOR. Plan §D1 stands as written with this clarification: v0.6.0 is MAJOR-class per Myco's own contract, MINOR per pure-SemVer naming convention; no contradiction. Rejection rationale: T1 conflated SemVer label with semantic gravity; Myco contract supersedes.
- **R7 (addresses T7) — partial reject**: T7 says sampling bends L0 P1 spirit. **Spirit is unchanged**: substrate has always permitted "agent calls LLM" and merely forbidden "substrate calls LLM autonomously." Sampling is "host (which contains the agent's LLM session) makes a tool call to substrate, then sub-call routes back to host LLM" — still agent-mediated. The token-residency concern (T19/G2.5-3) is real but separable: handled by R19. Rejection rationale: T7 over-reads "spirit"; the canon's actual P1 carve-out (`L0_VISION.md:51-60`) anticipates this exact scenario.
- **R14b (addresses T14, second consideration on rejection)**: 8 framework demos with truly isolated venvs ARE expensive in CI minutes. **Counter-rejection considered**: drop to 4 most-trafficked demos (Claude Agent SDK / LangGraph / CrewAI / DSPy)? **Final decision: keep all 8** with isolated venvs; CI cost is bearable (~5 min wall-clock parallel). Demos are one of v0.6.0's strongest distribution levers.
- **R16 (addresses T16) — already addressed by R9**: T16 is subsumed by R9's batched-issue + retry approach. No additional revision needed.
- **R(internal-MCP-spec-drift) — re-claim**: T23's "ecosystem-thawed" rebuttal is accepted (R23). But on the question of whether to release v0.6.0 immediately vs wait for MCP 2026-Q3 spec settlement: ship now (v0.6.0 contract-frozen), absorb spec drift in v0.6.x patches. Waiting indefinitely converts v0.6.0 from a release to a perpetual "almost-ready" — vetoed by L0 P3 永恒进化.

---

## Round 2.5 — 再驳 (counter-rebuttal)

A second adversarial pass over Round 2 reveals 3 second-order tensions:

- **T29 [P1, second-order]**: `MB7 watch-quota-pressure` and **CL2 oauth-token-residency-policy** introduced in R11/R12 as new dims push the dim count to 25 + 17 + 2 = **44**, not 42 as Round 1 claimed. Update Round 1's component (3) to "lint dim count grows 25 → 44." Correction is editorial; net dim count rises, no tension survives.
- **T30 [P1, second-order]**: R6's "atomic enum bump + new field" still couples two changes in one schema_upgrader. **Resolution**: schema_upgrader `_v1_to_v2` is split internally into two named functions `_v1_to_v2_llm_policy_enum(raw)` and `_v1_to_v2_federation_peers_field(raw)`, called sequentially within a single `apply_to_v2(raw)` wrapper. Each is independently testable; semantic purity preserved per `homeostasis.md:212-217` "narrow."
- **T31 [P0, second-order, fundamental]**: R20's "doctrine PR (PR-001) before implementation PR (PR-002+)" requires owner gating between the two PRs. If owner gates PR-001 and 1 week passes (per R27 public window), PR-002+ can land via auto-approve; but if the doctrine edit fails owner review, all 21 downstream sub-PRs are stranded. **Resolution**: PR-001 is **synchronous owner-gated** (no public window applies — high-risk per `risk_classifier.py`); PR-002+ is staged in a feature branch `v0.6.0-impl/` not main, only fast-forwarded to main after PR-001 merges. Branch hygiene becomes load-bearing.

No further (third-order) tensions surface. The tension set is stable.

---

## Round 3 — 反思 (reflection and decision)

### Verdicts (F1-F31)

- **F1 (T1)**: v0.6.0 is **MAJOR-class per Myco contract** (`L0_VISION.md:223`); SemVer "MINOR" label is naming-only. Living Bets re-audit fires.
- **F2 (T2)**: **Accept fully** — Cycle stays Cycle; canon.subsystems 5 → 6 by adding cycle; `boundary` subsystem **withdrawn**; surface/install/symbionts/mcp remain cross-cutting adapter packages.
- **F3 (T3)**: **Accept** — alias deletion deferred to v1.0.0 per `digestion.md:120-122`; v0.6.0 only upgrades deprecation banner severity.
- **F4 (T4)**: **Accept fully** — `src/myco/symbionts/` path preserved per `extensibility.md:24-27`; `boundary/host_integration/` proposal **withdrawn**.
- **F5 (T5)**: **Accept** — 17 new dims land in 3 sub-PR batches with severity-promotion ledger.
- **F6 (T6, T30)**: **Accept** — schema v2 minimal (enum + field only); lint sub-file split → v2.1; upgrader internally split into two named functions.
- **F7 (T7)**: **Reject T7** — sampling does not violate L0 P1 spirit; canon already carves the exception. Token-residency separately handled (F19).
- **F8 (T8)**: **Accept** — resources/list returns metadata only; resources/read injects R3-discipline ledger entry.
- **F9 (T9, T16)**: **Accept** — 136 issues across 3 batches over 2 weeks post-release with retry-budgets.
- **F10 (T10)**: **Accept** — rename/reorganize commits separated from semantic edits within v0.6.0 PR sequence.
- **F11 (T11)**: **Accept** — subscriptions ship with watch quota (MYCO_RESOURCE_WATCH_QUOTA, default 100) + LRU + ETag fallback; new dim MB7.
- **F12 (T12)**: **Accept** — switch to PyJWT + JWKS rotation + RFC 8707 audience validation; new dim CL2 (token-residency policy enforcement).
- **F13 (T13)**: **Accept** — symbiont adapters use OS-aware `_paths()`; CI matrix 3 OS for symbiont suite.
- **F14 (T14)**: **Accept** — isolated venv per framework demo; 8 parallel CI jobs.
- **F15 (T15)**: **Accept** — `system.resource_redaction` field; default protected scope; OAuth-scoped `myco://canon/raw`.
- **F17 (T17)**: **Accept** — myco-migrate AST-aware for .py + word-boundary for shell/config; markdown prose excluded.
- **F18 (T18)**: **Accept** — new dims default LOW; PA4 allow-list canon.py schema_upgraders; severity ramp over 30 sessions.
- **F19 (T19)**: **Accept** — `llm_policy` three-state semantics defined; CL3 dim verifies token-clear-after-call.
- **F20 (T20, T31)**: **Accept** — L2 doctrine PR (PR-001) lands first under owner gate; L4 implementation in `v0.6.0-impl/` feature branch fast-forwarded after PR-001 merges.
- **F21 (T21)**: **Accept** — overlay_verb `subsystem` validity check (new dim MF4); since cycle name preserved, no migration needed beyond enum+field.
- **F22 (T22)**: **Accept** — `MYCO_PORT` env; `_safe_log_payload` ASCII escape; DC6 log-payload-ASCII dim deferred to v0.6.x.
- **F23 (T23)**: **Accept** — dual-layer versioning: contract-frozen v0.6.0 + ecosystem-thawed v0.6.x.
- **F24 (T24)**: **Accept** — sibling craft `v0_6_0_living_bets_audit_craft_2026-04-28.md` lands with v0.6.0.
- **F25 (T25)**: **Accept** — protocol.md "writes" clarified as substrate writes; symbiont host-side writes are extensions of host config discipline; no R8 added.
- **F26 (T26)**: **Accept** — `dist/**` added to write_surface.allowed.
- **F27 (T27)**: **Accept** — public window = `max(senesce_count >= 7, wall_clock_days >= 7)`.
- **F28 (T28)**: **Accept** — 3-OS CI matrix; per-OS coverage floors.
- **F29 (T29)**: **Editorial** — Round 1 component (3) updated to "25 → 44 dims."
- **F30 (T30)**: see F6.
- **F31 (T31)**: see F20.

### What this craft revealed

- **L0 already named Cycle as the 6th subsystem**; v0.5.x failed to project that into `canon.subsystems`. v0.6.0 corrects the projection — this is alignment, not innovation. Gemini-as-critic and ChatGPT-as-critic independently surfaced this. The revision shrinks proposed change from "rename + restructure" to "addition only" — half the original surface area.
- **`L0_VISION.md:223` review cadence binds v0.6 as MAJOR** in Myco contract semantics regardless of SemVer naming convention. This silently elevates the release's gravity and **mandates** the Living Bets audit craft. Skipping that audit would have been an undetected contract violation.
- **`extensibility.md:24-27` hardcoded the symbionts/ path** at L2. The original plan's R4 refactor (boundary/host_integration/) would have been an L2 doctrine edit done at L4 commit time — exactly the inversion R7 forbids. Surfacing this prevented a subtle violation.
- **The "boundary subsystem" name** failed `L0_VISION.md:185-186`'s "No alternate vocabulary" mandate immediately. The architect's instinct toward symmetry conflicted with the biological taxonomy commitment. Cycle as 6th subsystem already provides sufficient symmetry without coining new vocabulary.
- **17 dims at once is baseline-reset**, but the answer is structure (3 batches with severity ramp) not deferral. Severity-promotion-over-N-sessions converts the 17-dim land event from "trust me they're calibrated" to "observe them across real usage; ramp severity as confidence builds."
- **Adversarial dual-LLM critique** (ChatGPT-as-critic + Gemini-as-critic) caught 8 P0 issues that single-perspective review missed (T2/T4 by ChatGPT; T11/T12/T13/T15/T16/T17 by Gemini). This pattern is itself doctrine-worthy: high-risk crafts should standardize on dual-critique. Future craft `v0_6_x_dual_critique_doctrine_craft.md` may codify.
- **"7 days" embedded human cadence** into doctrine-level governance — doctrine surfaced the violation. Two-floor (sessions OR wall-clock) is the proper agent-first phrasing; wall-clock is acknowledged where externally-bound (PR review windows).
- **Contract-frozen vs ecosystem-thawed dual-layering** is a generalizable governance pattern beyond v0.6.0. Future versioning.md edit may codify it.

---

## Round 4 — Owner amendment (post-LANDED)

After Round 3 verdicts F1-F31 LANDED on 2026-04-28, the owner explicitly
**reversed six conservative revisions** with the directive "all work, no
deferrals, single-shot v0.6.0":

- **A1 (overrides F2 partial)**: Boundary IS introduced as the **7th
  subsystem** — `surface/` + `install/` + `mcp/` + `symbionts/` are
  unified under a `boundary` namespace. L0 vocabulary clause
  (`L0_VISION.md:185-186` "No alternate vocabulary") is amended at L0
  by owner approval to admit `boundary` as a doctrine-level term
  describing the substrate's outward interface layer (no biological
  word in the L0 fungal taxonomy maps to "outward interface" — the
  amendment narrowly extends the taxonomy rather than violates it).
  `canon.subsystems` 6 → 7 (germination/ingestion/digestion/circulation/
  homeostasis/cycle/boundary).
- **A2 (overrides F3)**: All v0.5.2 CLI aliases REMOVED at v0.6.0
  (genesis/reflect/distill/perfuse/session-end/craft/bump/evolve/scaffold).
  Deprecation packages `src/myco/{genesis,meta}/` deleted.
  `digestion.md:120-122` doctrine amended: alias removal accelerated
  from v1.0.0 to v0.6.0. `myco-migrate` tool ships at v0.6.0 to
  rewrite user scripts.
- **A3 (overrides F4)**: `src/myco/symbionts/` and the three sister
  packages `surface/install/mcp/` are **all PHYSICALLY moved** to
  `src/myco/boundary/{surface,install,mcp,host_integration}/` at
  v0.6.0 Round 5 (owner directive "不许有任何一丝一毫偷懒"; previous
  symbolic-only re-export approach explicitly overruled). The legacy
  top-level packages `myco.surface` / `myco.install` / `myco.mcp` /
  `myco.symbionts` are **REMOVED**. 201 import-path rewrites across
  60 files (src + tests + docs + configs) bring the codebase onto
  the canonical `myco.boundary.<sub>` form. pyproject entry-points
  updated. `extensibility.md` doctrine amended to declare per-host
  axis at boundary.host_integration.
- **A4 (overrides F6)**: Schema v2 includes the THREE simultaneous
  changes: (i) `_v1_to_v2_llm_policy_enum`, (ii)
  `_v1_to_v2_federation_peers_field`, (iii) **NEW**
  `_v1_to_v2_lint_dimensions_subfile` extracts `lint.dimensions` to
  sibling `_canon_lint.yaml`. `_v1_to_v2` composes all three named
  partials sequentially — narrowness preserved at the partial-function
  layer; v2.1 schema is no longer needed for sub-file split.
- **A5 (overrides F5/F18)**: 21 new dims land at their **declared
  severity** at v0.6.0 (no severity-promotion ladder). PA4=HIGH,
  SC1=HIGH, SH2=HIGH, AD1=HIGH, MP3=HIGH, CL1=HIGH, CL2=HIGH ship
  at HIGH on first run. Owner accepts baseline-reset risk; the
  `_canon.yaml::lint.severity_promotion` table is removed.
- **A6 (overrides F12)**: OAuth keeps `python-jose` (NOT switched
  to PyJWT). Owner accepts CVE-track maintenance burden; CL2 dim
  enforces `_redact_in_logs` import; CL3 dim enforces token clear-
  after-call.

These amendments are recorded here per `protocol.md:140-150`
(contract-version bump + owner approval + cascade review).
`docs/contract_changelog.md` v0.6.0 section is rewritten to reflect
the un-deferred surface.

## Deliverables

### L1 contract edits (PR-001, owner-gated)

- `_canon.yaml`: `schema_version: "1" → "2"`; `system.no_llm_in_substrate` → `system.llm_policy: "forbidden"`; `identity.federation_peers: []`; `system.resource_redaction: {paths, scopes}`; `system.resource_watch.max_per_substrate: 100`; `subsystems.cycle: {doc: "docs/architecture/L2_DOCTRINE/cycle.md", package: "src/myco/cycle/"}`; `lint.dimensions` table extends 25 → 44 IDs (no behavior in this PR; behavior in PR-A/B/C); `lint.severity_promotion: [...]`; `governance: {public_window_min_senesce_count: 7, public_window_min_wall_clock_days: 7, refresh_token_rotation_grace_seconds: 30, last_winnowed_proposals: []}`; `system.write_surface.allowed` adds `dist/**` and `examples/**`; `contract_version: "v0.5.24" → "v0.6.0"`; `synced_contract_version` matches.
- `_canon_lint.yaml`: **NOT created in v0.6.0** (deferred to v2.1).
- `docs/architecture/L1_CONTRACT/protocol.md`: "writes" clarification (editorial); R6 unchanged.
- `docs/architecture/L1_CONTRACT/versioning.md`: v0.6.0 starting-points row appended.
- `docs/architecture/L1_CONTRACT/canon_schema.md`: v2 schema description; new field documentation.
- `docs/architecture/L2_DOCTRINE/cycle.md`: **new** L2 doctrine for the 6th subsystem.
- `docs/architecture/L2_DOCTRINE/extensibility.md`: per-host axis enforcement dim moved from "*(future per-host dimension — reserved)*" to "MF3 (host-side artifact integrity)".
- `docs/architecture/L3_IMPLEMENTATION/package_map.md`: subsystem count 5 → 6; cycle/ as canonical 6th subsystem.
- `docs/architecture/L3_IMPLEMENTATION/symbiont_protocol.md`: 11-host status updated to "implemented at v0.6.0 (CC + Cursor + Cowork + VS Code + Continue) and v0.6.x (rest)."

### L4 implementation edits (PR-A/B/C... in `v0.6.0-impl/` feature branch)

PR-A (mechanical-structural dim batch, 9 dims): `src/myco/homeostasis/dimensions/{pa2,pa3,pa4,pa5,sc1,dc5,mf3,di2,ad1}.py` + tests; severity defaults LOW.
PR-B (semantic+metabolic dim batch, 5 dims): `{se4,rl2,rl3,mb4,mb6}.py` + tests; severity defaults MEDIUM.
PR-C (shipping+capability dim batch, 3 dims + 2 R-revision dims): `{sh2,cl1,mp3,mb7,cl2}.py` + tests + CL3 (token-clear-after-call); severity defaults LOW with promotion ledger.
PR-D (fixable extension): M1, M3, DI1, DC1, DC4, SE1, PA1, MB6 fixable=True; tests for idempotent + already-resolved + outside-write-surface.
PR-E (intake verb): `src/myco/ingestion/intake.py`; `surface/manifest.yaml` 19 → 20 verb; `verify_mcp_boot.py` updates; `tests/unit/verbs/test_intake.py`.
PR-F (graft register/remove): `src/myco/cycle/graft.py` extension.
PR-G (sporulate closed loop): `pipeline.NOTE_STAGES` extension; `digestion/{reassimilate,promote_sporulated}.py`; tests.
PR-H (MCP capability surface): `src/myco/surface/{mcp_resources,mcp_prompts,mcp_sampling,mcp_auth,capability}.py`; `mcp.py` register-capabilities refactor; tests.
PR-I (Streamable HTTP + OAuth + Server Card): `src/myco/mcp/__init__.py` host/port/mount-path; `Dockerfile` MYCO_PORT; `.well-known/mcp.json` route.
PR-J (11 symbiont adapters): `src/myco/symbionts/{claude_code,cursor,cowork,vscode,continue_dev}.py` (5 in v0.6.0); other 6 in v0.6.x.
PR-K (8 framework demos): `examples/<framework>-myco-demo/` × 8.
PR-L (test reorganization): `tests/unit/verbs/<verb>/` reorg + R3/R4/R5 behavioral tests + coverage gates + xdist + mypy tests + 3-OS matrix.
PR-M (activity cleanup): 8 graph orphans linked; DRAFT craft excreted; 2 distilled excreted; `audit_to_issues.py`; `myco-migrate` tool.
PR-N (CHANGELOG hatch hook + Glama): `hooks/derive_changelog.py`; `server.json` `_meta`; `glama_categories_drive_craft_2026-04-28.md`.
PR-O (governance tiers): `core/risk_classifier.py`; `cycle/{winnow,senesce}.py` extensions.
PR-P (Living Bets audit): `v0_6_0_living_bets_audit_craft_2026-04-28.md`.

### Tests

- 17 new dim tests (one per dim) under `tests/unit/homeostasis/dimensions/`.
- 3 R3/R4/R5 behavioral contract tests under `tests/unit/surface/`.
- 5 verb canonical-name test files under `tests/unit/verbs/<verb>/`.
- 8 framework demo dry-run smoke tests in CI matrix.
- 11 symbiont adapter unit tests + 1 integration test (5 host CI matrix).
- New scripts: `verify_mcp_capabilities.py`, `verify_install_examples.py`, `verify_server_json.py`, `coverage_floors.py`, `audit_to_issues.py`.

### Doctrine

L0/L1/L2/L3 edits as enumerated above; all in PR-001 (owner-gated).

## Acceptance

- **pytest**: `pytest -q -n auto --cov --cov-fail-under=85` on 3-OS × 4-py matrix; per-package floors via `coverage_floors.py`.
- **mypy**: `python -m mypy src/myco tests/`; tests baseline ratchets each commit.
- **ruff**: `python -m ruff check . && python -m ruff format --check .`.
- **immune**: `python -m myco immune` exit 0; 44-dim self-dogfood with severity-promotion ledger.
- **MCP**: `verify_mcp_boot.py`, `verify_mcp_capabilities.py`, `verify_install_examples.py`, `verify_server_json.py` all green; streamable-http docker job green.
- **Behavioral (agent-observable)**:
  - `myco_hunger` after a v0.5.x → v0.6.0 schema upgrade applies the v1→v2 upgrader transparently; no operator action needed.
  - `myco intake --path <dir>` runs end-to-end; ForageItems → eat.append_note; raw queue grows.
  - `resources/list` returns ≥5 URI families; `resources/read myco://canon` returns redacted canon by default; `myco://canon/raw` requires authenticated host.
  - `prompts/list` returns ≥22 entries (20 verbs + 2 workflows).
  - `myco senesce` auto-LANDS expired-no-veto craft in `governance.last_winnowed_proposals`.
- **Non-regression**:
  - Existing 875 tests stay green throughout; only renames touch test paths.
  - `_canon.yaml` of any v0.5.24 substrate transparently upgrades on first hunger; reverse downgrade is unsupported (one-way).
  - All v0.5.2 CLI aliases (`reflect`, `distill`, `perfuse`, `genesis`, `craft`, `bump`, `evolve`, `scaffold`, `session-end`) still resolve, with stderr banner.
  - All MCP tool names continue to be the 19 canonical (no deprecated MCP aliases re-introduced; MCP-alias purge from v0.5.24 stays).
- **External validation**:
  - Glama dashboard categories changed to "Agent Orchestration" + "Developer Tools".
  - awesome-mcp-servers PR opened; MCP Registry server.json `_meta` < 4KB.
  - 8 framework demos succeed in independent uv venvs.
