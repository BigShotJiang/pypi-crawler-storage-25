#!/usr/bin/env bash
# agent-chat-gateway installer
# Usage:  bash install.sh [--no-onboard]
# Or:     curl -fsSL https://raw.githubusercontent.com/HammerMei/agent-chat-gateway/main/install.sh | bash
# Or:     curl -fsSL https://raw.githubusercontent.com/HammerMei/agent-chat-gateway/main/install.sh | bash -s -- --no-onboard
#
# Flags:
#   --no-onboard   Skip the interactive setup wizard (for AI agents / automated installs)
set -euo pipefail

# ---------------------------------------------------------------------------
# Parse flags
# ---------------------------------------------------------------------------
NO_ONBOARD=false
for arg in "$@"; do
  case "$arg" in
    --no-onboard) NO_ONBOARD=true ;;
  esac
done

# ---------------------------------------------------------------------------
# Helpers
# ---------------------------------------------------------------------------
info()    { printf '\033[0;36m[ACG]\033[0m %s\n' "$*"; }
success() { printf '\033[0;32m[ACG]\033[0m %s\n' "$*"; }
warn()    { printf '\033[0;33m[ACG]\033[0m %s\n' "$*" >&2; }
error()   { printf '\033[0;31m[ACG] Error:\033[0m %s\n' "$*" >&2; exit 1; }

# ---------------------------------------------------------------------------
# OS / architecture detection
# ---------------------------------------------------------------------------
OS="$(uname -s)"
ARCH="$(uname -m)"

case "$OS" in
  Darwin) OS_NAME="macos" ;;
  Linux)  OS_NAME="linux" ;;
  *)      error "Unsupported OS: $OS. This installer supports macOS and Linux." ;;
esac

info "Detected OS: $OS_NAME ($ARCH)"

# ---------------------------------------------------------------------------
# uv check / install (must come before Python check — uv can manage Python)
# ---------------------------------------------------------------------------
if ! command -v uv &>/dev/null; then
  warn "uv not found. Installing uv..."
  curl -LsSf https://astral.sh/uv/install.sh | sh
  # Add to PATH for this session
  export PATH="$HOME/.cargo/bin:$HOME/.local/bin:$PATH"
  if ! command -v uv &>/dev/null; then
    error "uv installation failed. Install manually: https://docs.astral.sh/uv/getting-started/installation/"
  fi
  success "uv installed."
else
  info "uv found: $(uv --version)"
fi

# ---------------------------------------------------------------------------
# Python 3.12+ check — use uv to install if system Python is too old
# ---------------------------------------------------------------------------
PYTHON_OK=false
if command -v python3 &>/dev/null; then
  PYTHON_VERSION="$(python3 --version 2>&1 | awk '{print $2}')"
  PYTHON_MAJOR="$(echo "$PYTHON_VERSION" | cut -d. -f1)"
  PYTHON_MINOR="$(echo "$PYTHON_VERSION" | cut -d. -f2)"
  if [ "$PYTHON_MAJOR" -gt 3 ] || { [ "$PYTHON_MAJOR" -eq 3 ] && [ "$PYTHON_MINOR" -ge 12 ]; }; then
    PYTHON_OK=true
    info "Python $PYTHON_VERSION — OK"
  fi
fi

if [ "$PYTHON_OK" = false ]; then
  warn "Python 3.12+ not found on system. Using uv to install Python 3.12..."
  uv python install 3.12
  success "Python 3.12 installed via uv."
fi

# ---------------------------------------------------------------------------
# Determine repo directory
# Detect curl|bash mode: BASH_SOURCE[0] is empty or is /dev/stdin or "bash"
# ---------------------------------------------------------------------------
SCRIPT_SOURCE="${BASH_SOURCE[0]:-}"
CURL_PIPE=false

if [ -z "$SCRIPT_SOURCE" ] || [ "$SCRIPT_SOURCE" = "/dev/stdin" ] || [ "$SCRIPT_SOURCE" = "bash" ] || [ "$SCRIPT_SOURCE" = "-bash" ]; then
  CURL_PIPE=true
fi

if [ "$CURL_PIPE" = true ]; then
  REPO_DIR="$HOME/.agent-chat-gateway/repo"
  mkdir -p "$HOME/.agent-chat-gateway"
  info "Running via curl|bash — will clone to $REPO_DIR"
  if [ -d "$REPO_DIR/.git" ]; then
    info "Repo already exists at $REPO_DIR — pulling latest..."
    git -C "$REPO_DIR" pull
  else
    git clone https://github.com/HammerMei/agent-chat-gateway.git "$REPO_DIR"
  fi
else
  # Running as a local script — use the script's own directory
  SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
  REPO_DIR="$SCRIPT_DIR"
  info "Running locally — using repo at $REPO_DIR"
fi

# ---------------------------------------------------------------------------
# uv sync
# ---------------------------------------------------------------------------
info "Installing Python dependencies (uv sync)..."
uv sync --project "$REPO_DIR"

# ---------------------------------------------------------------------------
# Symlink into ~/.local/bin
# ---------------------------------------------------------------------------
VENV_BIN="$REPO_DIR/.venv/bin/agent-chat-gateway"
if [ ! -f "$VENV_BIN" ]; then
  error "Expected binary not found: $VENV_BIN"
fi

mkdir -p "$HOME/.local/bin"
ln -sf "$VENV_BIN" "$HOME/.local/bin/agent-chat-gateway"
success "Symlink created: ~/.local/bin/agent-chat-gateway → $VENV_BIN"

# ---------------------------------------------------------------------------
# PATH setup — add ~/.local/bin if missing
# ---------------------------------------------------------------------------
case ":$PATH:" in
  *":$HOME/.local/bin:"*)
    info "~/.local/bin is already in PATH."
    ;;
  *)
    warn "~/.local/bin is not in PATH. Adding to shell rc files..."
    PATH_LINE='export PATH="$HOME/.local/bin:$PATH"'
    for RC in "$HOME/.bashrc" "$HOME/.zshrc"; do
      if [ -f "$RC" ]; then
        # Only add if not already present
        if ! grep -qF '.local/bin' "$RC" 2>/dev/null; then
          printf '\n# Added by agent-chat-gateway installer\n%s\n' "$PATH_LINE" >> "$RC"
          info "  Added to $RC"
        fi
      fi
    done
    export PATH="$HOME/.local/bin:$PATH"
    ;;
esac

# ---------------------------------------------------------------------------
# Ensure runtime dir exists (needed by both context copy and install_meta.json)
# ---------------------------------------------------------------------------
RUNTIME_DIR="$HOME/.agent-chat-gateway"
mkdir -p "$RUNTIME_DIR"

# ---------------------------------------------------------------------------
# Copy bundled context files to runtime dir
# These are reference files (e.g. rc-gateway-context.md) that config.yaml
# points to.  Copied (not symlinked) so users can safely edit them without
# touching the git repo.  Upgrade handles smart merge via upgrade.py.
# ---------------------------------------------------------------------------
if [ -d "$REPO_DIR/contexts" ]; then
    mkdir -p "$RUNTIME_DIR/contexts"
    cp "$REPO_DIR/contexts/"* "$RUNTIME_DIR/contexts/"
    success "Copied context files to $RUNTIME_DIR/contexts/"
fi

# ---------------------------------------------------------------------------
# Write install_meta.json — always, regardless of --no-onboard
# This is required by `agent-chat-gateway upgrade` to locate the repo.
# ---------------------------------------------------------------------------
ACG_VERSION=$(grep '^version' "$REPO_DIR/pyproject.toml" | sed 's/version = "\(.*\)"/\1/')
cat > "$RUNTIME_DIR/install_meta.json" << EOF
{
  "method": "git",
  "repo_path": "$REPO_DIR",
  "version": "$ACG_VERSION"
}
EOF
success "Wrote install_meta.json (version=$ACG_VERSION, repo=$REPO_DIR)"

# ---------------------------------------------------------------------------
# Run onboard wizard (skipped when --no-onboard is passed)
# ---------------------------------------------------------------------------
if [ "$NO_ONBOARD" = true ]; then
  info "Skipping setup wizard (--no-onboard). Configure manually:"
  info "  1. Create ~/.agent-chat-gateway/.env with RC_URL, RC_USERNAME, RC_PASSWORD"
  info "  2. Create ~/.agent-chat-gateway/config.yaml"
  info "  3. Run: agent-chat-gateway start"
else
  info "Launching setup wizard..."
  "$VENV_BIN" onboard --repo-path "$REPO_DIR"
fi

# ---------------------------------------------------------------------------
# Detect shell config file for source hint
# ---------------------------------------------------------------------------
case "$SHELL" in
  */zsh)  SHELL_RC="~/.zshrc" ;;
  */fish) SHELL_RC="~/.config/fish/config.fish" ;;
  *)      SHELL_RC="~/.bashrc" ;;
esac

# ---------------------------------------------------------------------------
# Next steps
# ---------------------------------------------------------------------------
printf '\n'
success "Installation complete!"
printf '\n'
printf '  Repository cloned to:    ~/.agent-chat-gateway/repo\n'
printf '  Executable installed at: ~/.local/bin/agent-chat-gateway\n'
printf '\n'
printf '  To use agent-chat-gateway in your current shell, run:\n'
printf '    source %s\n' "$SHELL_RC"
printf '  Or restart your terminal.\n'
printf '\n'
printf '  Start the gateway:   agent-chat-gateway start\n'
printf '  Check status:        agent-chat-gateway status\n'
printf '  View logs:           tail -f ~/.agent-chat-gateway/gateway.log\n'
printf '\n'
