#!/usr/bin/env bash
set -euo pipefail

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
cd "$REPO_ROOT"

echo "Cleaning previous builds..."
rm -rf dist/ build/ src/*.egg-info

echo "Building sdist and wheel..."
python -m build

echo ""
echo "Build complete. Contents of dist/:"
ls -lh dist/
