#!/usr/bin/env bash
set -euo pipefail

usage() {
    echo "Usage: $0 --test | --prod"
    echo ""
    echo "  --test    Upload to TestPyPI"
    echo "  --prod    Upload to PyPI"
    exit 1
}

if [[ $# -ne 1 ]]; then
    usage
fi

REPO_ROOT="$(cd "$(dirname "$0")/.." && pwd)"
DIST_DIR="$REPO_ROOT/dist"

if [[ ! -d "$DIST_DIR" ]] || [[ -z "$(ls -A "$DIST_DIR" 2>/dev/null)" ]]; then
    echo "Error: dist/ is empty or missing. Run build.sh first."
    exit 1
fi

case "$1" in
    --test)
        echo "Uploading to TestPyPI..."
        twine upload --repository testpypi "$DIST_DIR"/*
        echo ""
        echo "Done. Install with:"
        echo "  pip install --index-url https://test.pypi.org/simple/ django-suppressor"
        ;;
    --prod)
        echo "Uploading to PyPI..."
        twine upload "$DIST_DIR"/*
        echo ""
        echo "Done. Install with:"
        echo "  pip install django-suppressor"
        ;;
    *)
        usage
        ;;
esac
