document.addEventListener("DOMContentLoaded", function () {
    console.log("[main] app initialized");

    document.querySelectorAll(".card").forEach(function (card) {
        card.addEventListener("mouseenter", function () {
            card.style.boxShadow = "0 4px 12px rgba(0, 0, 0, 0.15)";
        });
        card.addEventListener("mouseleave", function () {
            card.style.boxShadow = "";
        });
    });
});
