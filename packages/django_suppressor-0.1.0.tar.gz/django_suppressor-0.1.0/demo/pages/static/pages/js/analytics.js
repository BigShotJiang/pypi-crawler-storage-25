function trackEvent(category, action, label) {
    console.log(`[analytics] ${category} / ${action}`, label || "");
}

document.addEventListener("click", function (event) {
    const btn = event.target.closest(".btn");
    if (btn) {
        trackEvent("ui", "click", btn.textContent.trim());
    }
});
