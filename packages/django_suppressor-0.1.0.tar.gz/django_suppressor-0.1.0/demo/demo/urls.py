from django.urls import include, path

urlpatterns = [
    path("", include("suppressor.urls")),
    path("", include("pages.urls")),
]
