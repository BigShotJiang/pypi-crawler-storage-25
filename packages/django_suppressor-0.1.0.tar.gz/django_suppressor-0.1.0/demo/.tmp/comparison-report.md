# Suppressor ON vs OFF Comparison Report

## Terminology Clarification
- `http://localhost:8000/` = Individual files (NO bundling)
- `http://localhost:8000/?_suppress` = Bundled files (suppressor ACTIVE)

## CSS File Order

### Original (individual files) - order in HTML:
1. /static/admin/css/base.css
2. /static/admin/css/dark_mode.css
3. /static/admin/css/nav_sidebar.css
4. [inline <style> - admin-interface CSS variables]
5-31. /static/admin_interface/css/*.css (27 files)
32. /static/ui/css/admin-customizations.css
33. /static/admin/css/dashboard.css
34. /static/ui/css/admin-customizations.css (DUPLICATE)
35. [inline <style> - .dcops-actions button styles]    <-- THIS IS KEY
36. /static/admin/css/responsive.css
37. /static/admin/css/responsive.css?v=... (DUPLICATE with version)
38. /static/admin/css/responsive_rtl.css?v=...
39. /static/admin_interface/foldable-apps/foldable-apps.css?v=...
40. /static/admin_interface/magnific-popup/magnific-popup.css?v=...
41. /static/admin_interface/related-modal/related-modal.css?v=...

### Bundled (suppressor active) - order in HTML:
1. [inline <style> - admin-interface CSS variables]   (preserved, not bundled)
2-38. All <link> tags COMMENTED OUT (<!-- ... -->)
3. [inline <style> - .dcops-actions button styles]    (preserved, not bundled)
4. /_suppressor/css/hash.css  <-- SINGLE BUNDLE containing all 41 CSS files  <-- THIS IS KEY
5. debug_toolbar CSS (not bundled)

### Bundle internal order (from file markers):
Same as original - order is preserved within the bundle.

## JS File Order

### Original: theme.js, nav_sidebar.js, dcops-qr-scanner.js, clickable-checkbox-cells.js, foldable-apps.js, jquery.magnific-popup.js, related-modal.js
### Bundle: Same order - preserved.

## Issue 1: CSS Cascade Order Change (ROOT CAUSE of visual differences)

In the ORIGINAL version:
```
... admin_interface/css/admin-interface.css ...     <-- sets .admin-interface a:link color to generic-link-color
... [inline <style> .dcops-actions a:link ...] ...  <-- overrides button text to white (WINS by cascade)
... responsive.css ...
```

In the BUNDLED version:
```
... [inline <style> .dcops-actions a:link ...] ...  <-- sets button text to white
... /_suppressor/css/bundle.css ...                  <-- contains admin-interface.css which sets a:link back to blue (WINS by cascade!)
```

The inline <style> blocks are NOT bundled (correctly, as they are not <link> tags).
But this means the bundle, placed AFTER the inline styles, overrides them.

Specific conflicting rule in admin-interface.css:
```css
.admin-interface a:link,
.admin-interface a:visited {
    color: var(--admin-interface-generic-link-color);  /* #334FB4 = blue */
}
```

vs inline <style>:
```css
.dcops-actions a:link { color: var(--admin-interface-save-button-text-color, #fff); }
```

Both have the same specificity (2 classes + 1 pseudo-class), so cascade order determines the winner.
- Without bundling: inline <style> comes AFTER admin-interface.css -> white text wins
- With bundling: bundle comes AFTER inline <style> -> blue text wins -> invisible on blue background

## Issue 2: Broken Relative URLs in CSS

The bundled CSS contains relative url() paths like:
- url(../img/icon-addlink.svg)
- url(../img/icon-changelink.svg)
- url(../img/icon-viewlink.svg)

When served from `/_suppressor/css/hash.css`, `../img/` resolves to `/_suppressor/img/` which doesn't exist.
This causes 3 x 404 errors and missing icons in the admin interface.

## Issue 3: Duplicate CSS Files

Both versions include duplicates:
- /static/ui/css/admin-customizations.css appears TWICE
- /static/admin/css/responsive.css appears TWICE (once with and once without version param)

## Console Errors

- Without bundling: None
- With bundling: 3 errors
  - GET /_suppressor/img/icon-addlink.svg 404
  - GET /_suppressor/img/icon-changelink.svg 404
  - GET /_suppressor/img/icon-viewlink.svg 404

## Visual Differences

1. Action buttons (Scan, New Order, Dashboard, Notifications): Text becomes INVISIBLE
   (blue text on blue background due to cascade order change)
2. Add/Change/View icons in the model list: Missing (broken relative URLs)

## Screenshots
- Without bundling: .tmp/screenshot-suppressor-on.png  (looks correct)
- With bundling: .tmp/screenshot-suppressor-off.png (visual issues)
