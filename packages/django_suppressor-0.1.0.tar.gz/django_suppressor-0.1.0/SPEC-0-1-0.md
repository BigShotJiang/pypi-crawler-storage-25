# Django Suppressor - HTML Asset Capture and Runtime Bundling

Suppress redundant JS and CSS fetches.

## Specification Draft for v0.1.0

## 1. Document Status

- **Status:** Draft
- **Intended version:** 0.1.0
- **Audience:** Maintainers, implementers, reviewers
- **Purpose:** Define the outcome, scope, behavior, and implementation approach for a Django package that captures literal HTML asset tags from rendered template regions, bundles eligible assets at runtime, and emits external content-addressed bundle URLs.

---

## 2. Executive Summary

This package aims to reduce repeated CSS and JavaScript asset tags in Django-rendered pages without requiring asset declarations to be rewritten as custom template tags.

The package will work by:

1. Wrapping explicit template regions in custom block tags.
2. Rendering the enclosed region normally through Django’s template system.
3. Parsing only the resulting HTML fragment within that region.
4. Detecting eligible literal asset tags such as:
   - `<script src="..."></script>`
   - `<link rel="stylesheet" href="...">`
5. Removing eligible tags from the fragment and collecting their referenced content.
6. Generating content-addressed runtime bundles.
7. Emitting clean replacement URLs pointing to a bundle-serving Django view.

This design deliberately avoids two rejected approaches:

- requiring all assets to be declared through custom asset tags
- parsing and rewriting the entire final HTML response body

Instead, it uses **region-scoped post-render fragment processing** inside the template system.

---

## 3. Goals

### 3.1 Primary goals

- Support **literal** HTML asset tags emitted by Django templates, including those originating in child templates.
- Avoid requiring child templates to duplicate or override centralized bundle declarations.
- Keep template author burden minimal.
- Limit HTML parsing to explicit wrapped template regions.
- Preserve asset encounter order.
- Produce external bundle URLs rather than inline JS/CSS.
- Remain compatible with Content Security Policy setups that disallow inline scripts or styles.
- Keep v0.1.0 implementation intentionally simple and conservative.
- Fail safely by preserving original behavior when bundling cannot be performed.

### 3.2 Secondary goals

- Provide a clean migration path to future bundle caching.
- Provide a clean migration path to CSS URL rewriting.
- Provide a predictable foundation for future escape hatches and advanced grouping rules.

---

## 4. Non-goals for v0.1.0

The following are explicitly out of scope for v0.1.0:

- Full-response HTML rewriting
- Automatic discovery outside explicitly wrapped template regions
- Parsing or transforming inline `<script>` or `<style>` content
- JavaScript minification or transpilation
- CSS minification
- Sourcemap generation
- Persistent bundle caching or advanced bundle reuse strategy
- Duplicate asset detection or deduplication
- CSS `url(...)` rewriting
- Support for `async` scripts
- Support for `type="module"` scripts
- Support for `nomodule` scripts
- Support for `integrity` attributes
- Support for third-party or cross-origin asset URLs
- Support for preload, prefetch, or non-stylesheet `<link>` relations
- Advanced reordering or dependency analysis

---

## 5. Problem Statement

Django templates allow literal asset tags to be introduced at many points in a template hierarchy, especially through block inheritance and includes. Existing mainstream asset bundling approaches typically require explicit bundle declarations in templates or settings and do not naturally collect literal tags from child templates without extra coordination.

The package described here addresses that gap by operating on **rendered HTML fragments within bounded template regions**. This provides a practical middle ground:

- more robust than scanning template source or attempting to inspect Django node internals for HTML semantics
- safer and faster than parsing the entire rendered page
- compatible with ordinary Django template inheritance

---

## 6. Key Design Conclusions

The design in this document is based on the following settled conclusions:

1. **Literal asset tags must be supported.**
   Requiring template authors to replace asset tags with custom asset registration tags is not acceptable for the primary use case.

2. **The stock Django template engine does not expose an HTML AST phase.**
   Literal HTML is rendered as text, so there is no built-in phase where all final HTML tags are available as structured elements before string output.

3. **Per-node interception is too brittle.**
   Because tags can be split across node boundaries through variables, template tags, includes, and inheritance, intercepting individual node output introduces avoidable complexity.

4. **Region-scoped fragment capture is preferable.**
   Wrapping a template region in a custom block tag and rendering its enclosed `nodelist` to a final fragment string provides a reliable boundary for parsing.

5. **External bundle URLs are preferred over inline content.**
   This avoids CSP issues and keeps output HTML cleaner.

6. **v0.1.0 should be runtime-only.**
   Advanced caching, persistence, and invalidation are deferred to future versions, though the design should not block them.

7. **Failure behavior must preserve original output.**
   Any ambiguity or processing failure should leave the original asset tag behavior intact.

---

## 7. User-Facing Conceptual Model

Template authors will explicitly mark regions whose rendered HTML may contain eligible asset tags.

Example conceptual usage:

```django
{% load suppressor_capture %}

<head>
    {% suppressor_capture "head" %}
        {% block head %}{% endblock %}
    {% endsuppressor_capture %}

    {% suppressor_emit_css "head" %}
    {% suppressor_emit_js "head" %}
</head>

<body>
    {% block content %}{% endblock %}

    {% suppressor_capture "body_js" only_js %}
        {% block body_js %}{% endblock %}
    {% endsuppressor_capture %}

    {% suppressor_emit_js "body_js" %}
</body>
```

Child templates remain free to emit literal tags such as:

```html
<link rel="stylesheet" href="/static/css/page.css">
<script src="/static/js/page.js"></script>
```

The package will capture eligible tags from the rendered region, bundle them by type, and emit replacement bundle URLs at the corresponding emit points. CSS and JS are emitted separately, giving the template author control over placement (e.g., CSS in `<head>`, JS before `</body>`).

---

## 8. Terminology

### 8.1 Capture region
A template fragment explicitly wrapped in the custom block tag responsible for rendering and scanning a bounded HTML fragment.

### 8.2 Emit point
A template location where the package outputs replacement bundle tags or a placeholder marker for later substitution.

### 8.3 Eligible asset
A literal external asset tag that matches the v0.1.0 support rules.

### 8.4 Bundle
A runtime-generated concatenation of one or more eligible asset files of the same compatible type.

### 8.5 Content-addressed URL
A bundle URL whose path is derived from a hash of bundle content and metadata.

---

## 9. High-Level Architecture

### 9.1 Core components

The implementation is expected to contain the following conceptual pieces:

1. **Capture block tag**
   - Renders enclosed template content to a fragment string.
   - Parses the fragment for eligible asset tags.
   - Removes or replaces eligible tags in the fragment.
   - Stores collected asset metadata in per-render state.
   - Returns the modified fragment.

2. **Emit tag**
   - Emits a unique placeholder marker or, where feasible, a final bundle tag.
   - In v0.1.0, placeholder emission is preferred because emit points may appear before capture regions.

3. **Per-render collector state**
   - Stores captured assets grouped by region and type.
   - Must live in request/render-local state, not global mutable objects.

4. **Post-render finalization step**
   - Replaces emitted placeholders with final bundle tags after the page or response is fully rendered.

5. **Bundle content builder**
   - Resolves eligible asset URLs to asset content.
   - Concatenates bytes in encounter order.
   - Computes content hash.
   - Stores content in a runtime-addressable backend.

6. **Bundle serving view**
   - Serves runtime-generated JS or CSS content based on hash-addressed URL lookup.

---

## 10. Template API Shape

The final public API is not yet fixed, but the intended shape is:

### 10.1 Capture block tag

```django
{% suppressor_capture "region_name" %}
    ... arbitrary template content ...
{% endsuppressor_capture %}
```

Optional type-filtering arguments restrict which asset types are captured:

```django
{% suppressor_capture "body_js" only_js %}
    ... only script tags are captured; stylesheet tags are left in place ...
{% endsuppressor_capture %}

{% suppressor_capture "head_css" only_css %}
    ... only stylesheet tags are captured; script tags are left in place ...
{% endsuppressor_capture %}
```

When neither `only_js` nor `only_css` is specified, both asset types are captured (default behavior).

Requirements:

- Must accept a region identifier.
- Must accept an optional `only_js` or `only_css` argument (mutually exclusive).
- Must render enclosed content exactly once.
- Must only inspect the resulting HTML fragment.
- Must not require child templates to opt in beyond ordinary literal asset tags.

### 10.2 Emit tags

Separate emit tags are provided for CSS and JS output:

```django
{% suppressor_emit_css "region_name" %}
{% suppressor_emit_js "region_name" %}
```

This gives template authors explicit control over where each asset type is emitted. A capture region may contain both CSS and JS assets; the template author places each emit tag where that asset type belongs (e.g., CSS in `<head>`, JS before `</body>`).

A single capture region may have both a `suppressor_emit_css` and a `suppressor_emit_js` tag, or only one of the two. If a region captures assets of a type with no matching emit tag, those assets are handled per section 20.4.

Requirements:

- Must support appearing before or after the matching capture region.
- Must not require direct knowledge of captured assets at template authoring time.
- Must participate safely in final placeholder substitution.
- Each emit tag produces output only for its declared asset type (CSS or JS).

### 10.3 Region strategy

v0.1.0 assumes explicit region naming rather than global automatic collection.

Rationale:

- simpler mental model
- safer parsing boundaries
- clearer ordering semantics
- easier debugging

---

## 11. Rendering and Processing Model

### 11.1 Region capture flow

For each capture region:

1. The custom block tag renders the enclosed `nodelist` through Django’s normal rendering process.
2. The fully rendered fragment string is obtained.
3. The fragment is parsed for eligible asset tags.
4. Each eligible tag is collected into region-local ordered state.
5. Eligible tags are removed from the fragment or replaced by inert debug comments.
6. The modified fragment is returned as the capture tag’s output.

### 11.2 Emit flow

For each emit tag (`suppressor_emit_css` or `suppressor_emit_js`):

1. The tag emits a unique placeholder marker tied to the region and asset type.
2. The placeholder survives normal template rendering.
3. During finalization, each placeholder is replaced with final bundle tag output for the matching asset type only.

### 11.3 Finalization flow

After template rendering completes:

1. The collected assets are grouped into compatible bundles.
2. Bundle contents are resolved and concatenated.
3. Bundle hashes are computed.
4. Bundle content is stored in the runtime bundle backend.
5. Placeholders are replaced with generated bundle tags.

### 11.4 Finalization scope

The finalization step must operate after all relevant template regions have rendered.

This may be implemented through:

- a post-render callback for `TemplateResponse`, and/or
- response middleware fallback for HTML responses

The implementation mechanism is flexible; the behavioral requirement is not.

### 11.5 Streaming response handling

Finalization requires access to the full response body for placeholder replacement. `StreamingHttpResponse` does not provide a response body buffer.

The middleware must check `response.streaming` and skip finalization entirely for streaming responses. In practice, streaming responses are used for file downloads, SSE, and similar non-template use cases, so suppressor template tags would not normally appear in their content.

This is a documented limitation, not a failure case.

---

## 12. Asset Eligibility Rules for v0.1.0

### 12.1 Supported JavaScript tags

Supported JS tags are limited to classic external script tags of the form:

```html
<script src="..."></script>
```

Eligibility requirements:

- `src` attribute present
- no `async`
- no `type="module"`
- no `nomodule`
- no `integrity`
- URL must be same-origin and considered locally resolvable

### 12.2 Supported CSS tags

Supported CSS tags are limited to stylesheet links of the form:

```html
<link rel="stylesheet" href="...">
```

Eligibility requirements:

- `rel="stylesheet"`
- `href` attribute present
- no `integrity`
- URL must be same-origin and considered locally resolvable

### 12.3 Unsupported tags

The following must be ignored and preserved unchanged:

- inline `<script>` tags
- inline `<style>` tags
- scripts with `async`
- scripts with `type="module"`
- scripts with `nomodule`
- tags with `integrity`
- third-party or cross-origin URLs
- preload/prefetch links
- non-stylesheet links
- any tag the parser cannot classify with confidence

---

## 13. Parsing Strategy

### 13.1 Scope

Parsing must be limited to the rendered HTML fragment inside a capture region.

Rationale:

- reduces accidental matches outside intended boundaries
- avoids full-document parse cost
- avoids full-response rewriting complexity
- creates a predictable and explicit operating envelope

### 13.2 Parser behavior

The parser must operate on HTML fragments, not entire documents.

The parser should be tolerant of ordinary template-generated HTML.

### 13.3 Regex policy

Regex may be acceptable as a temporary implementation aid for narrow cases, but the design intent favors a tolerant HTML fragment parser over regex-only matching.

### 13.4 Unknown or ambiguous cases

If the parser cannot confidently classify a tag as eligible, it must leave that tag unchanged.

---

## 14. Ordering Rules

### 14.1 Encounter order

Within a capture region, eligible assets must be recorded and concatenated in the exact order encountered.

### 14.2 Cross-region ordering

v0.1.0 does not attempt to merge ordering across different named regions.

Each region is treated as an independent asset stream.

### 14.3 Repeated tags

Repeated asset tags must be preserved semantically by repeated inclusion of their content in v0.1.0.

No deduplication will occur.

Rationale:

- simplest behavior
- least surprising for early versions
- avoids accidentally changing execution or cascade behavior

Future versions may define opt-in deduplication or explicit escape hatches.

---

## 15. Grouping Rules

### 15.1 v0.1.0 grouping philosophy

Grouping must remain intentionally conservative.

### 15.2 JavaScript grouping

All eligible classic external script tags in a given region may be concatenated into a single JS bundle for that region.

### 15.3 CSS grouping

All eligible stylesheet tags in a given region may be concatenated into a single CSS bundle for that region, subject to known limitations regarding relative `url(...)` references.

### 15.4 Future grouping expansion

Future versions may split groups by attributes such as:

- `media`
- defer-like semantics
- module/non-module behavior
- explicit escape-hatch markers

These are not part of v0.1.0.

---

## 16. Asset Resolution Strategy

### 16.1 Resolution strategy

Eligible same-origin asset URLs are resolved through Django’s staticfiles storage backend. There is a single resolution path with no dev/prod distinction — the package delegates environment-specific behavior to the storage backend and other staticfiles infrastructure.

Resolution flow:

1. Verify URL begins with `STATIC_URL`.
2. Strip `STATIC_URL` prefix to obtain a storage-relative path.
3. Open the file via the configured staticfiles storage backend (`storage.open(path)`).
4. Read content bytes.

If storage lookup fails, the asset is unresolvable and the original tag is preserved per section 16.3.

This approach works correctly with `ManifestStaticFilesStorage` and other post-processing storage backends. Hashed filenames (e.g., `page.abc123.js`) exist as actual files in `STATIC_ROOT`, so no reverse mapping from hashed to original filenames is needed. Importantly, this means the bundler operates on the **post-processed** file content — if another staticfiles processor has minified or transformed the file, the bundle contains the processed output, not the original source.

Users who enable suppressor locally must run `collectstatic` first, as the package reads exclusively from storage, not from finders.

### 16.2 Explicit rejection of self-HTTP fetch as primary strategy

v0.1.0 must not rely on issuing local HTTP GET requests back to the application as the primary asset resolution mechanism.

Rationale:

- brittle across hosts, schemes, ports, and environments
- couples bundling to full HTTP request behavior
- complicates authentication and middleware interactions
- less predictable operationally

### 16.3 Resolution failure behavior

If an eligible-looking asset URL cannot be resolved to content, the original asset tag must remain unchanged.

---

## 17. Bundle Content Generation

### 17.1 Runtime-only model for v0.1.0

Bundle generation occurs at runtime during page rendering/finalization.

There is no requirement in v0.1.0 to persist bundles across deploys or across long time horizons.

### 17.2 Bundle content

Bundle content is the ordered concatenation of asset file bytes for a compatibility group.

### 17.3 Hashing

Each generated bundle must be assigned a deterministic content hash derived from:

- bundle type (`js` or `css`)
- concatenated content bytes
- internal format/version identifier

The asset identity list (URLs) is deliberately excluded from hash inputs. Identical content must produce the same hash regardless of the URL paths used to reference it.

### 17.4 Output representation

For each generated bundle, the final HTML should contain a single replacement tag:

```html
<script src="/_suppressor/js/<hash>.js"></script>
```

or

```html
<link rel="stylesheet" href="/_suppressor/css/<hash>.css">
```

The exact URL pattern is configurable implementation detail, but content-addressed external URLs are required.

---

## 18. Runtime Bundle Storage

### 18.1 v0.1.0 storage intent

Although advanced caching is deferred, v0.1.0 requires a runtime-accessible storage mechanism so emitted bundle URLs can be served later.

This is not considered full bundle caching in the roadmap sense. It is minimal runtime bundle storage.

Before generating a bundle, the storage backend should be checked for an existing entry with the same hash. If found, bundle generation is skipped. This is not persistent caching — it is basic short-circuiting to avoid redundant work on repeated page renders.

### 18.2 Stored payload

Each stored bundle entry should include at least:

- bundle type (`js` or `css`)
- content bytes
- content hash
- MIME type
- optional diagnostic metadata such as original asset list

### 18.3 Backend: Django cache with dedicated alias

Bundle storage uses Django's cache framework with a dedicated cache alias (`suppressor`).

The default backend is `FileBasedCache`, which works correctly in multi-worker deployments without requiring external services. Users may override the `suppressor` cache alias in `CACHES` to use Redis, Memcached, or any other Django cache backend.

If no `suppressor` alias is configured in `CACHES`, the package should provide a sensible `FileBasedCache` default automatically (e.g., using a subdirectory of the system temp directory).

### 18.4 Multi-process consideration

`FileBasedCache` is shared across processes via the filesystem, making it safe for multi-worker deployments (gunicorn, uwsgi, etc.) out of the box.

Per-process in-memory backends (`LocMemCache`) are explicitly unsuitable as the default because the page response and subsequent bundle asset request may be handled by different workers.

---

## 19. Bundle Serving View

### 19.1 Purpose

The package must provide a Django view capable of serving runtime-generated bundle content by hash-addressed URL.

### 19.2 Requirements

The view must:

- accept a bundle type and hash identifier
- retrieve the stored bundle content
- verify bundle type matches route expectations
- return the correct MIME type
- return a failure response when the bundle is not found

### 19.3 Cache headers

Because URLs are content-addressed, the implementation should be able to serve long-lived cache headers.

Exact header defaults may remain implementation-defined in v0.1.0 but should be noted in the design.

---

## 20. Placeholder and Final HTML Replacement

### 20.1 Placeholder requirement

`suppressor_emit_css` and `suppressor_emit_js` must support use before the corresponding `suppressor_capture` region.

Therefore, the emitted output must initially be a stable placeholder marker that encodes both the region name and the asset type (CSS or JS).

### 20.2 Replacement requirement

During finalization, each placeholder marker must be replaced with the final bundle tag for the matching region and asset type. Each placeholder produces at most one bundle tag (one CSS bundle or one JS bundle).

### 20.3 Unused emit points

If no eligible assets of the declared type were captured for a region, the emit point should resolve to an empty string.

### 20.4 Missing emit points

If assets are captured for a region but no matching emit tag exists for that asset type, those assets are lost — they were removed from the capture region output during extraction and have no emit destination to restore them.

This is a **template authoring error**, not a graceful degradation scenario. For example, if a region captures both CSS and JS but only `suppressor_emit_js` is placed, the CSS tags are extracted from the fragment but never emitted.

For v0.1.0, the implementation must log a warning when this occurs, identifying the region name and the orphaned asset type. The `only_js` and `only_css` arguments on `suppressor_capture` (section 10.1) can prevent this by restricting capture to only the asset types that have matching emit tags.

This must be documented prominently as a common misconfiguration.

---

## 21. Failure Policy

Failure behavior is critical.

### 21.1 General rule

On ambiguity or failure, preserve original page behavior.

### 21.2 Required fallback cases

If any of the following occur, the system must preserve the original relevant tag or region output rather than removing functionality:

- fragment parsing failure
- asset resolution failure
- bundle generation failure
- runtime storage failure
- placeholder replacement failure
- unsupported attribute detection
- unsupported URL form

### 21.3 Failure granularity

Fallback should be as narrow as practical.

Examples:

- one unresolvable asset should not necessarily invalidate other eligible assets in the same region if safe partial processing is possible
- if safe partial processing is not practical, preserving the full original region is acceptable for v0.1.0

The chosen fallback granularity must be documented by implementation.

---

## 22. Debug and Development Behavior

### 22.1 Enable setting

Bundling is controlled by a dedicated setting (`SUPPRESSOR_ENABLED`), separate from Django's `DEBUG` setting.

`SUPPRESSOR_ENABLED` defaults to `not DEBUG`, so bundling is off in development and on in production without configuration. However, either direction can be overridden:

- set `SUPPRESSOR_ENABLED = True` with `DEBUG = True` to test bundling locally
- set `SUPPRESSOR_ENABLED = False` with `DEBUG = False` to disable bundling in a staging environment

When disabled, capture regions render their content unchanged (no asset extraction), and emit tags render as empty strings. The middleware skips finalization.

### 22.2 Optional diagnostic output

When enabled, implementations may optionally support diagnostic comments or logging indicating:

- which assets were captured
- which assets were skipped
- which bundle URLs were emitted

This is optional for v0.1.0.

---

## 23. CSP Considerations

### 23.1 v0.1.0 strategy

v0.1.0 avoids inline bundle emission specifically to improve compatibility with Content Security Policy configurations that disallow inline scripts and styles.

### 23.2 Remaining caveats

CSP compatibility still depends on site policy allowing the emitted bundle URLs under the relevant script and style source directives.

This package does not attempt to modify CSP policy.

### 23.3 Non-goals

v0.1.0 does not attempt to provide:

- nonce management
- hash-based inline CSP support
- CSP header rewriting

---

## 24. CSS-Specific Limitation: Relative `url(...)`

### 24.1 Known limitation

Concatenating CSS files into a new bundle location can break relative `url(...)` references inside those CSS files.

### 24.2 v0.1.0 behavior

v0.1.0 will not rewrite CSS URLs.

This is a known implementation gap and must be documented prominently.

### 24.3 Roadmap

Relative `url(...)` rewriting is planned for v0.1.1.

### 24.4 Impact

CSS bundling in v0.1.0 should be considered limited or experimental where relative asset paths are present.

---

## 25. Security and Trust Boundaries

### 25.1 Eligible source boundary

Only same-origin, locally resolvable static assets are eligible.

### 25.2 Exclusions

Do not fetch or merge:

- arbitrary external URLs
- authenticated application endpoints
- user-controlled arbitrary URLs

### 25.3 Rationale

This package is an asset bundler, not a generic content fetcher.

---

## 26. Template Author Ergonomics

The design should preserve the following authoring experience:

- base template authors wrap a small number of known asset regions
- base template authors place corresponding emit tags
- child templates continue writing ordinary literal `<script src>` and `<link rel="stylesheet">` tags
- no bundle manifests are required for v0.1.0
- no child-template duplication of asset declarations is required

This ergonomic goal is central to the package’s value proposition.

---

## 27. Open Implementation Choices

The following implementation decisions remain open but do not alter core behavior:

- exact placeholder marker format
- exact fragment parser library
- exact URL route pattern for bundle serving
- exact logging strategy
- exact fallback granularity for partially valid regions

The following decisions are now settled:

- template tag names: `suppressor_capture`/`endsuppressor_capture`, `suppressor_emit_css`, `suppressor_emit_js`
- capture type filtering: optional `only_js` / `only_css` arguments on `suppressor_capture`
- runtime storage backend: Django cache framework with dedicated `suppressor` alias, defaulting to `FileBasedCache`
- asset resolution: strip `STATIC_URL`, `storage.open()` only (no finders fallback)
- enable control: `SUPPRESSOR_ENABLED` setting, defaults to `not DEBUG`

Remaining open choices may be finalized during implementation.

---

## 28. Recommended v0.1.0 Milestones

### 28.1 Minimum viable implementation

- capture block tag (`suppressor_capture` / `endsuppressor_capture`) with optional `only_js` / `only_css` type filtering
- separate emit tags with placeholder behavior (`suppressor_emit_css`, `suppressor_emit_js`)
- warning on orphaned captured assets (captured type with no matching emit tag)
- fragment parsing for eligible JS and CSS tags
- per-render collection by region and asset type
- asset resolution via `storage.open()` (no finders fallback; `collectstatic` required)
- runtime bundle creation with hash-before-rebuild short-circuiting
- content hashing (type + content bytes + format version)
- runtime bundle storage via Django cache (`suppressor` alias, `FileBasedCache` default)
- bundle serving view
- final placeholder substitution (skipped for streaming responses)
- safe fallback behavior
- `SUPPRESSOR_ENABLED` setting (defaults to `not DEBUG`)

### 28.2 Recommended initial exclusions in code

Implementation should explicitly skip and preserve unchanged:

- `async`
- `module`
- `nomodule`
- `integrity`
- external URLs
- inline assets

---

## 29. Roadmap

### 29.1 v0.1.1

Planned improvements:

- CSS relative `url(...)` rewriting
- improved CSS safety and reliability

### 29.2 v0.2.0

Planned improvements:

- persistent/reusable bundle caching
- stronger invalidation strategy
- bundle reuse across requests and deploy cycles where appropriate

### 29.3 v0.3.0

Planned improvements:

- escape hatches for advanced cases
- explicit opt-outs
- repeated-tag handling policy expansion
- more advanced grouping controls

### 29.4 Possible future areas

- media-aware CSS grouping
- defer-aware script grouping
- optional deduplication
- diagnostics tooling
- alternative storage backends
- management/inspection commands

---

## 30. Risks

### 30.1 HTML parsing complexity

Even within bounded fragments, HTML parsing remains a source of edge cases.

### 30.2 CSS relocation breakage

Without URL rewriting, some CSS bundles will be incorrect.

### 30.3 Runtime cost

Runtime bundling adds per-request work in v0.1.0.

### 30.4 Distributed deployment complexity

Bundle content must be available when the browser requests the generated URL.

### 30.5 Partial-support confusion

Users may assume support for all script/link variants unless exclusions are clearly documented.

---

## 31. Success Criteria

v0.1.0 should be considered successful if it can reliably do the following in ordinary Django template inheritance scenarios:

- capture literal stylesheet and classic script tags from child templates within wrapped regions
- preserve original asset encounter order
- replace captured tags with one generated external bundle URL per compatible type and region
- serve generated content successfully by hash-addressed URL
- avoid inline CSP issues
- fail safely when it cannot process an asset
- remain straightforward for template authors to adopt

---

## 32. Recommended Documentation Notes for First Release

The first public documentation should prominently state:

- this package only processes explicitly wrapped template regions
- v0.1.0 supports only classic external JS and standard stylesheet links
- unsupported tags are preserved unchanged
- CSS relative `url(...)` rewriting is not yet implemented
- bundling is controlled by `SUPPRESSOR_ENABLED` (defaults to `not DEBUG`)
- bundle content is runtime-generated and served through package URLs
- the default storage backend (`FileBasedCache`) works in multi-worker deployments; users may configure any Django cache backend via the `suppressor` cache alias
- streaming responses (`StreamingHttpResponse`) are not processed
- separate emit tags (`suppressor_emit_css`, `suppressor_emit_js`) control where each asset type appears in the output
- `only_js` / `only_css` arguments on `suppressor_capture` restrict which asset types are extracted
- capturing assets without a matching emit tag is a misconfiguration that produces a warning and loses those assets — use `only_js` / `only_css` to prevent this
- `collectstatic` must be run before enabling suppressor; the package reads from staticfiles storage only

---

## 33. Final Recommendation

Proceed with the region-scoped runtime bundling design described in this document.

It is the best current fit for the stated requirements because it:

- supports literal asset tags
- works with Django template inheritance
- avoids full-response parsing
- avoids brittle per-node interception
- avoids CSP issues caused by inline bundles
- keeps v0.1.0 small enough to build and evaluate

The implementation should be conservative, explicit about non-goals, and optimized for correctness-preserving fallback behavior.
