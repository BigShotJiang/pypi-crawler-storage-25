import hashlib
import logging
from dataclasses import dataclass, field

from .collector import AssetEntry
from .conf import FORMAT_VERSION
from .resolver import resolve_asset

logger = logging.getLogger(__name__)

MIME_TYPES = {
    "js": "application/javascript",
    "css": "text/css",
}

SEPARATORS = {
    "js": b";\n",
    "css": b"\n",
}


@dataclass
class BundleResult:
    content: bytes
    hash_hex: str
    asset_type: str
    mime_type: str
    failed_assets: list[AssetEntry] = field(default_factory=list)


def compute_hash(asset_type, content):
    digest = hashlib.sha256()
    digest.update(asset_type.encode())
    digest.update(content)
    digest.update(FORMAT_VERSION.encode())
    return digest.hexdigest()


COMMENT_FORMATS = {
    "js": "/* {url} */\n",
    "css": "/* {url} */\n",
}


def build_bundle(assets, asset_type, comments=False):
    resolved_chunks = []
    failed = []

    inline_labels = {"js": "/* inline <script> */\n", "css": "/* inline <style> */\n"}

    for asset in assets:
        if asset.inline_content is not None:
            content = asset.inline_content.encode()
            if comments:
                label = inline_labels.get(asset_type, "/* inline */\n")
                content = label.encode() + content
            resolved_chunks.append(content)
        else:
            content = resolve_asset(asset.url)
            if content is None:
                failed.append(asset)
            else:
                if comments:
                    fmt = COMMENT_FORMATS.get(asset_type, "/* {url} */\n")
                    header = fmt.format(url=asset.url).encode()
                    content = header + content
                resolved_chunks.append(content)

    if not resolved_chunks:
        return None

    separator = SEPARATORS.get(asset_type, b"\n")
    combined = separator.join(resolved_chunks)
    hash_hex = compute_hash(asset_type, combined)

    return BundleResult(
        content=combined,
        hash_hex=hash_hex,
        asset_type=asset_type,
        mime_type=MIME_TYPES.get(asset_type, "application/octet-stream"),
        failed_assets=failed,
    )
