import contextvars
from dataclasses import dataclass, field


@dataclass
class AssetEntry:
    url: str
    tag_html: str
    asset_type: str  # "js" or "css"
    inline_content: str | None = None


@dataclass
class Collector:
    assets: dict[tuple[str, str], list[AssetEntry]] = field(default_factory=dict)
    emitted: set[tuple[str, str]] = field(default_factory=set)

    def add_asset(self, region, asset_type, entry):
        key = (region, asset_type)
        self.assets.setdefault(key, []).append(entry)

    def mark_emitted(self, region, asset_type):
        self.emitted.add((region, asset_type))

    def get_assets(self, region, asset_type):
        return self.assets.get((region, asset_type), [])

    def get_orphaned_keys(self):
        return [
            key for key in self.assets if key not in self.emitted and self.assets[key]
        ]


_collector_var = contextvars.ContextVar("suppressor_collector", default=None)


def get_collector():
    return _collector_var.get()


def set_collector(collector):
    return _collector_var.set(collector)
