import os
import tempfile

from django.apps import AppConfig


class SuppressorConfig(AppConfig):
    name = "suppressor"
    verbose_name = "Suppressor"

    def ready(self):
        self._ensure_cache_config()

    def _ensure_cache_config(self):
        from django.conf import settings

        if not hasattr(settings, "CACHES"):
            settings.CACHES = {}
        if "suppressor" not in settings.CACHES:
            settings.CACHES["suppressor"] = {
                "BACKEND": "django.core.cache.backends.filebased.FileBasedCache",
                "LOCATION": os.path.join(tempfile.gettempdir(), "suppressor_cache"),
            }
