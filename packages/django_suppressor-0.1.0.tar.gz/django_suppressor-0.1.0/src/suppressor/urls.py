from django.urls import re_path

from . import views

app_name = "suppressor"

urlpatterns = [
    re_path(
        r"^_suppressor/(?P<asset_type>js|css)/(?P<hash_hex>[0-9a-f]+)\.(js|css)$",
        views.serve_bundle,
        name="serve_bundle",
    ),
]
