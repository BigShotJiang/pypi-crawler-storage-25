import logging

from django.conf import settings
from django.contrib.staticfiles.storage import staticfiles_storage

logger = logging.getLogger(__name__)


def resolve_asset(url):
    static_url = settings.STATIC_URL
    if not url.startswith(static_url):
        logger.debug("Suppressor: URL %r does not start with STATIC_URL", url)
        return None

    path = url[len(static_url) :]
    # Strip query string (e.g. cache-busting ?v=1.2)
    path = path.split("?", 1)[0]
    try:
        with staticfiles_storage.open(path) as handle:
            return handle.read()
    except Exception:
        logger.warning("Suppressor: could not resolve asset %r", url)
        return None
