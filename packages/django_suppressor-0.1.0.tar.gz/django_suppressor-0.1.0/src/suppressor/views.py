from django.http import Http404, HttpResponse

from .storage import retrieve_bundle

MIME_TYPES = {
    "js": "application/javascript",
    "css": "text/css",
}


def serve_bundle(request, asset_type, hash_hex):
    if asset_type not in MIME_TYPES:
        raise Http404

    bundle = retrieve_bundle(asset_type, hash_hex)
    if bundle is None:
        raise Http404

    if bundle["type"] != asset_type:
        raise Http404

    response = HttpResponse(
        bundle["content"],
        content_type=f"{MIME_TYPES[asset_type]}; charset=utf-8",
    )
    response["Cache-Control"] = "public, max-age=31536000, immutable"
    return response
