import logging

from .conf import get_cache

logger = logging.getLogger(__name__)

CACHE_KEY_PREFIX = "suppressor:v1"


def _cache_key(asset_type, hash_hex):
    return f"{CACHE_KEY_PREFIX}:{asset_type}:{hash_hex}"


def store_bundle(bundle):
    cache = get_cache()
    key = _cache_key(bundle.asset_type, bundle.hash_hex)

    if cache.get(key) is not None:
        return

    cache.set(
        key,
        {
            "type": bundle.asset_type,
            "content": bundle.content,
            "hash": bundle.hash_hex,
            "mime_type": bundle.mime_type,
        },
        timeout=None,
    )


def retrieve_bundle(asset_type, hash_hex):
    cache = get_cache()
    key = _cache_key(asset_type, hash_hex)
    return cache.get(key)
