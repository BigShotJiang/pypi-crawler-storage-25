from django import template
from django.utils.safestring import mark_safe

from .. import conf
from ..collector import get_collector
from ..parser import extract_assets

register = template.Library()

PLACEHOLDER_FORMAT = "<!-- __SUPPRESSOR:{region}:{asset_type}__ -->"


class SuppressorCaptureNode(template.Node):
    def __init__(self, nodelist, region_name, capture_types):
        self.nodelist = nodelist
        self.region_name = region_name
        self.capture_types = capture_types

    def render(self, context):
        fragment = self.nodelist.render(context)

        collector = get_collector()
        if collector is None:
            return fragment

        modified, extracted = extract_assets(
            fragment, self.capture_types, comments=conf.get_comments()
        )

        for entry in extracted:
            collector.add_asset(self.region_name, entry.asset_type, entry)

        return modified


@register.tag("suppressor_capture")
def do_suppressor_capture(parser, token):
    bits = token.split_contents()
    tag_name = bits[0]

    if len(bits) < 2:
        raise template.TemplateSyntaxError(
            f"'{tag_name}' tag requires a region name argument"
        )

    region_name = bits[1]
    # Strip quotes if present
    if (region_name.startswith('"') and region_name.endswith('"')) or (
        region_name.startswith("'") and region_name.endswith("'")
    ):
        region_name = region_name[1:-1]

    capture_types = {"js", "css"}
    if len(bits) > 2:
        modifier = bits[2]
        if modifier == "only_js":
            capture_types = {"js"}
        elif modifier == "only_css":
            capture_types = {"css"}
        else:
            raise template.TemplateSyntaxError(
                f"'{tag_name}' tag got unexpected argument '{modifier}'. "
                "Expected 'only_js' or 'only_css'."
            )

    if len(bits) > 3:
        raise template.TemplateSyntaxError(
            f"'{tag_name}' tag takes at most 2 arguments"
        )

    nodelist = parser.parse(("endsuppressor_capture",))
    parser.delete_first_token()

    return SuppressorCaptureNode(nodelist, region_name, capture_types)


def _emit_tag(region_name, asset_type):
    collector = get_collector()
    if collector is None:
        return ""

    collector.mark_emitted(region_name, asset_type)
    return mark_safe(
        PLACEHOLDER_FORMAT.format(region=region_name, asset_type=asset_type)
    )


@register.simple_tag
def suppressor_emit_css(region_name):
    return _emit_tag(region_name, "css")


@register.simple_tag
def suppressor_emit_js(region_name):
    return _emit_tag(region_name, "js")
