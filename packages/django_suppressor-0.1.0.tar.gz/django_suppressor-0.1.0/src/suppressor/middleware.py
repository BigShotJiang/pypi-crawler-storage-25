import logging
import re

from django.http import StreamingHttpResponse

from . import bundler, storage
from .collector import Collector, get_collector, set_collector
from .conf import get_comments, get_enabled, get_query_param

logger = logging.getLogger(__name__)

PLACEHOLDER_RE = re.compile(r"<!-- __SUPPRESSOR:([\w]+):(css|js)__ -->")


class SuppressorMiddleware:
    def __init__(self, get_response):
        self.get_response = get_response

    def _is_enabled(self, request):
        enabled = get_enabled()
        param = get_query_param()
        if param and param in request.GET:
            enabled = not enabled
        return enabled

    def __call__(self, request):
        if not self._is_enabled(request):
            return self.get_response(request)

        collector = Collector()
        set_collector(collector)
        try:
            response = self.get_response(request)
        finally:
            set_collector(None)

        if isinstance(response, StreamingHttpResponse):
            return response

        content_type = response.get("Content-Type", "")
        if "text/html" not in content_type:
            return response

        self._warn_orphaned(collector)

        content = response.content.decode(response.charset)
        if PLACEHOLDER_RE.search(content) is None:
            return response

        content = self._replace_placeholders(content, collector)
        response.content = content.encode(response.charset)
        return response

    def _warn_orphaned(self, collector):
        for region, asset_type in collector.get_orphaned_keys():
            logger.warning(
                "Suppressor: region %r captured %s assets but no "
                "suppressor_emit_%s tag was found. Those assets are lost.",
                region,
                asset_type,
                asset_type,
            )

    def _replace_placeholders(self, content, collector):
        def replacer(match):
            region = match.group(1)
            asset_type = match.group(2)
            assets = collector.get_assets(region, asset_type)

            if not assets:
                return ""

            bundle = bundler.build_bundle(
                assets, asset_type, comments=get_comments()
            )
            if bundle is None:
                # Total failure — restore all original tags
                return "\n".join(asset.tag_html for asset in assets)

            storage.store_bundle(bundle)

            parts = []
            # Re-inject failed assets' original tags
            for failed in bundle.failed_assets:
                parts.append(failed.tag_html)

            # Add bundle tag
            url = f"/_suppressor/{asset_type}/{bundle.hash_hex}.{asset_type}"
            if asset_type == "js":
                parts.append(f'<script src="{url}"></script>')
            else:
                parts.append(f'<link rel="stylesheet" href="{url}">')

            return "\n".join(parts)

        return PLACEHOLDER_RE.sub(replacer, content)
