from django.conf import settings

FORMAT_VERSION = "s1"


def get_enabled():
    return getattr(settings, "SUPPRESSOR_ENABLED", not settings.DEBUG)


def get_comments():
    return getattr(settings, "SUPPRESSOR_COMMENTS", False)


def get_query_param():
    return getattr(settings, "SUPPRESSOR_QUERY_PARAM", None)


def get_cache():
    from django.core.cache import caches

    return caches["suppressor"]
