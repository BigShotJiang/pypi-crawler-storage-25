from concurrent.futures import ThreadPoolExecutor, as_completed

from allianceauth.services.hooks import get_extension_logger
from celery import shared_task

from eve_sde.models import ItemType

from fittings import __title__
from fittings.models import Fitting, FittingItem
from fittings.providers import AppLogger

logger = AppLogger(my_logger=get_extension_logger(name=__name__), prefix=__title__)


class EftParser:
    def __init__(self, eft_text):
        self.eft_lines = eft_text.strip().splitlines()

    def parse(self):
        # Remove /OFFLINE mentions due to pyfa when an offlined module is exported
        # Add fitting notes that the module is offlined
        parsed_fitting_notes = _removeOfflinedModulesMention(self.eft_lines)
        sections = []

        for section in _importSectionIter(parsed_fitting_notes['eft_lines']):
            sections.append(section)

        modules = []
        cargo = []
        drone_bay = []
        fighter_bay = []
        ship_type = ''
        fit_name = ''
        counter = 0  # Slot flag number
        last_line = ''

        for section in sections:
            counter = 0

            if section.isDroneBay():
                for line in section.lines:
                    quantity = line.split()[-1]
                    item_name = line.split(quantity)[0].strip()

                    drone_bay.append({'name': item_name, 'quantity': int(quantity.strip('x')), 'section_name': 'DroneBay'})
            elif section.isFighterBay():
                for line in section.lines:
                    quantity = line.split()[-1]
                    item_name = line.split(quantity)[0].strip()

                    fighter_bay.append({'name': item_name, 'quantity': int(quantity.strip('x')), 'section_name': 'FighterBay'})
            else:
                for line in section.lines:
                    if line.strip() == '':
                        continue

                    if line.startswith('['):
                        if ',' in line:
                            ship_type = line[1:-1].split(',', 1)[0].strip()
                            fit_name =line[1:-1].split(',', 1)[1].strip()

                            continue

                        if 'empty' in line.strip('[]').lower():
                            continue
                    else:
                        if ',' in line:
                            module, charge = line.split(',')
                            modules.append({'name': module, 'charge': charge.strip(), 'count': counter})
                        else:
                            quantity = line.split()[-1]  # Quantity will always be the last element, if it is there.

                            if 'x' in quantity and quantity[1:].isdigit():
                                item_name = line.split(quantity)[0].strip()
                                cargo.append({'name': item_name, 'quantity': int(quantity.strip('x')), 'section_name': 'Cargo'})
                            else:
                                modules.append({'name': line.strip(), 'charge': '', 'count': counter})

                    counter += 1

        return {
            'ship': ship_type,
            'name': fit_name,
            'modules': modules,
            'cargo': cargo,
            'drone_bay': drone_bay,
            'fighter_bay': fighter_bay,
            'fitting_notes': parsed_fitting_notes['fitting_notes']
        }



def _importSectionIter(lines):
    section = Section()

    for line in lines:
        # Make sure to strip whitespace
        line = line.strip()

        if not line:
            if section.lines:
                yield section
                section = Section()
        else:
            section.lines.append(line)

    if section.lines:
        yield section


def _removeOfflinedModulesMention(lines):
    fitting_notes = ''
    eft_lines = []

    for line in lines:
        if '/OFFLINE' in line:
            line = line.replace(' /OFFLINE', '')

            if ',' in line:
                item_name = line.split(',')[0].strip()
                fitting_notes += '{} is offlined \n'.format(item_name)
            else:
                quantity = line.split()[-1]

                if 'x' in quantity and quantity[1:].isdigit():
                    item_name = line.split(quantity)[0].strip()
                    fitting_notes += '{} is offlined \n'.format(item_name)
                else:
                    item_name = line.strip()
                    fitting_notes += '{} is offlined \n'.format(item_name)

        eft_lines.append(line)

    return {'fitting_notes': fitting_notes, 'eft_lines': eft_lines}


class Section:
    def __init__(self):
        self.lines = []

    def isDroneBay(self):
        types = []

        for line in self.lines:
            if line.startswith('['):
                return False

            if ',' in line:
                types.append(_get_type(line.split(',')[0].strip()))
            else:
                quantity = line.split()[-1]

                if 'x' in quantity and quantity[1:].isdigit():
                    types.append(_get_type(line.split(quantity)[0].strip()))
                else:
                    types.append(_get_type(line.strip()))

        return all(_type is not None and _type.group.category.id == 18 for _type in types)

    def isFighterBay(self):
        types = []

        for line in self.lines:
            if line.startswith('['):
                return False
            if ',' in line:
                types.append(_get_type(line.split(',')[0].strip()))

            else:
                quantity = line.split()[-1]

                if 'x' in quantity and quantity[1:].isdigit():
                    types.append(_get_type(line.split(quantity)[0].strip()))
                else:
                    types.append(_get_type(line.strip()))

        return all(_type is not None and _type.group.category.id == 87 for _type in types)


def _get_type(type_name):
    try:
        type_obj = ItemType.objects.filter(published=1).get(name=type_name)

        return type_obj
    except ItemType.DoesNotExist as e:
            logger.error(
                f"Type ID for {type_name} not found in SDE. Consider removing this from your fit."
            )

            raise e


@shared_task()
def create_fitting_item(fit, item):
    count = None
    quantity = None

    if 'count' in item:
        count = item['count']

    type_obj = _get_type(item['name'])

    # Dogma Effects
    flags = {
        11: 'LoSlot',
        12: 'HiSlot',
        13: 'MedSlot',
        2663: 'RigSlot',
        3772: 'SubSystemSlot',
        6306: 'ServiceSlot',
    }
    # @TODO: Dogma Effects not yet in SDE…
    effects = type_obj.effect.filter(dogma_effect_id__in=flags).values_list('dogma_effect_id', flat=True)
    effects = list(effects)

    if count is None:
        flag = item['section_name']
        quantity = item['quantity']

    # Check due to active drug from pyfa not showing quantities
    elif len(effects) == 0:
        flag = 'Cargo'
        quantity = 1
    else:
        flag = flags[effects[0]] + str(count)

    FittingItem.objects.create(
        flag=flag,
        quantity=quantity if quantity else 1,
        type_fk=type_obj,
        type_id=type_obj.pk,
        fit=fit
    )


@shared_task
def create_fit(eft_text, description=None):
    parsed_eft = EftParser(eft_text).parse()

    if description is None or len(description) == 0:
        description += '{}'.format(parsed_eft['fitting_notes'])
    else:
        description += '\n {}'.format(parsed_eft['fitting_notes'])

    logger.info("Creating fit.")
    logger.debug(f"Fit name: {parsed_eft['name']}, Type: {parsed_eft['ship']}")


    def __create_fit(ship_type, name, description):
        type_obj = _get_type(ship_type)

        if name == " " or name == "":
            name = "Unnamed " + ship_type + " fitting"

        fit = Fitting.objects.create(
            ship_type=type_obj,
            ship_type_type_id=type_obj.pk,
            name=name,
            description=description
        )

        return fit

    fit = __create_fit(parsed_eft['ship'], parsed_eft['name'], description)
    create_fitting_items(fit, parsed_eft)

    logger.info("Done creating fit.")


@shared_task
def create_fitting_items(fit, parsed_eft):
    # Create the fitting items
    for module in parsed_eft['modules']:
        logger.debug(f'Creating fitting item for module {module}')
        create_fitting_item(fit, module)

    for item in parsed_eft['cargo']:
        logger.debug(f'Creating fitting item for cargo {item}')
        create_fitting_item(fit, item)

    for item in parsed_eft['drone_bay']:
        logger.debug(f'Creating fitting item for drone bay {item}')
        create_fitting_item(fit, item)

    for item in parsed_eft['fighter_bay']:
        logger.debug(f'Creating fitting item for fighter bay {item}')
        create_fitting_item(fit, item)


@shared_task
def update_fit(eft_text, fit_id, description=None):
    parsed_eft = EftParser(eft_text).parse()
    fit = Fitting.objects.get(id=fit_id)

    if parsed_eft['ship'] != fit.ship_type.name:
        logger.info("Cannot update a fitting with different ship type")

        return

    logger.info("Updating Fit name: {parsed_eft['name']}, Type: {parsed_eft['ship']}")

    FittingItem.objects.filter(fit__id=fit_id).delete()

    create_fitting_items(fit, parsed_eft)

    fit.name = parsed_eft['name']
    fit.description = description
    fit.save()

    logger.info("Done updating fit " + fit_id)
