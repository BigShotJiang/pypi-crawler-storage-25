__version__ = '2.3.2'
__title__ = "Fittings"

__esi_compatibility_date__ = "2025-12-16"  # ESI compatibility date, see https://esi.evetech.net/meta/compatibility-dates

__app_name__ = "fittings"
__app_name_verbose__ = "Alliance Auth Fittings"
__app_name_useragent__ = "Alliance-Auth-Fittings"

__git_repo_url__ = "https://gitlab.com/colcrunch/fittings"
