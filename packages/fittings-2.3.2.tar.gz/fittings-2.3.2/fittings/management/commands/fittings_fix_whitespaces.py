from django.core.management.base import BaseCommand

from fittings.models import Fitting


class Command(BaseCommand):
    help = "Fixes unnecessary whitespaces in fitting names."

    def handle(self, *args, **kwargs):
        fittings = Fitting.objects.all()

        for fitting in fittings:
            original_name = fitting.name
            fixed_name = " ".join(original_name.split())

            if original_name != fixed_name:
                fitting.name = fixed_name
                fitting.save()
                self.stdout.write(
                    f'Fixed whitespace in fitting name: "{original_name}" -> "{fixed_name}"'
                )
