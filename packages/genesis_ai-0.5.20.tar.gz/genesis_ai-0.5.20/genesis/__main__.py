"""Allow running genesis via `python -m genesis`."""

from genesis import main

main()
