from types import SimpleNamespace

import httpx
import pytest
import respx
from httpx import Response

from auth_guardian.config import AuthConfig, TokenValidationMode
from auth_guardian.core import AuthGuardian
from auth_guardian.exceptions import KeycloakAPIError, TokenValidationError
from auth_guardian.token_validator import AuthTokenValidator


@pytest.mark.asyncio
async def test_local_mode_no_http_call() -> None:
    auth = AuthGuardian(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        client_secret="my-secret",
        state_secret="state-secret",
        token_validation=TokenValidationMode.LOCAL,
    )

    class FakeValidator:
        def __init__(self) -> None:
            self.config = SimpleNamespace(token_validation=TokenValidationMode.LOCAL)
            self.decode_calls = 0
            self.introspect_calls = 0

        async def decode_access_token(self, token: str) -> dict[str, str]:
            self.decode_calls += 1
            return {"sub": "user-1", "jti": "jti-1"}

        async def introspect_token(self, token: str) -> dict[str, str]:
            self.introspect_calls += 1
            raise AssertionError("introspect_token should not be called in local mode")

    class FakeResponse:
        def set_cookie(self, *args: object, **kwargs: object) -> None:
            return None

    fake_validator = FakeValidator()
    auth.validator = fake_validator  # type: ignore[assignment]
    auth._tenants_cache[auth.config.realm] = (fake_validator, auth.oidc_client)  # type: ignore[assignment]

    payload = await auth.get_current_user(
        request=SimpleNamespace(cookies={}),
        response=FakeResponse(),
        credentials=SimpleNamespace(credentials="access-token"),
    )

    assert payload["sub"] == "user-1"
    assert fake_validator.decode_calls == 1
    assert fake_validator.introspect_calls == 0


@pytest.mark.asyncio
@respx.mock
async def test_introspection_active_token() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        client_secret="my-secret",
        verify_tls=False,
        token_validation=TokenValidationMode.INTROSPECTION,
    )
    validator = AuthTokenValidator(config)

    route = respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token/introspect"
    ).mock(return_value=Response(200, json={"active": True, "sub": "user-123", "jti": "jti-123"}))

    payload = await validator.introspect_token("access-token")

    assert payload["sub"] == "user-123"
    assert route.called
    await validator.shutdown()


@pytest.mark.asyncio
@respx.mock
async def test_introspection_inactive_token() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        verify_tls=False,
        token_validation=TokenValidationMode.INTROSPECTION,
    )
    validator = AuthTokenValidator(config)

    respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token/introspect"
    ).mock(return_value=Response(200, json={"active": False}))

    with pytest.raises(TokenValidationError, match="Token revoked or inactive"):
        await validator.introspect_token("access-token")

    await validator.shutdown()


@pytest.mark.asyncio
@respx.mock
async def test_introspection_keycloak_timeout() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        verify_tls=False,
        token_validation=TokenValidationMode.INTROSPECTION,
    )
    validator = AuthTokenValidator(config)

    respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token/introspect"
    ).mock(side_effect=httpx.ReadTimeout("timeout"))

    with pytest.raises(KeycloakAPIError, match="Introspection endpoint unavailable") as exc:
        await validator.introspect_token("access-token")

    assert exc.value.status_code == 503
    await validator.shutdown()


@pytest.mark.asyncio
@respx.mock
async def test_introspection_keycloak_401() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        verify_tls=False,
        token_validation=TokenValidationMode.INTROSPECTION,
    )
    validator = AuthTokenValidator(config)

    respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token/introspect"
    ).mock(return_value=Response(401, json={"error": "unauthorized_client"}))

    with pytest.raises(KeycloakAPIError) as exc:
        await validator.introspect_token("access-token")

    assert "KEYCLOAK_CLIENT_SECRET" in exc.value.detail
    await validator.shutdown()


def test_env_var_sets_introspection_mode(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("AUTH_TOKEN_VALIDATION", "introspection")

    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
    )

    assert config.token_validation == TokenValidationMode.INTROSPECTION


def test_authguardian_logs_missing_required_env(
    monkeypatch: pytest.MonkeyPatch,
    caplog: pytest.LogCaptureFixture,
) -> None:
    monkeypatch.delenv("AUTH_BASE_URL", raising=False)
    monkeypatch.delenv("KEYCLOAK_BASE_URL", raising=False)
    monkeypatch.delenv("AUTH_REALM", raising=False)
    monkeypatch.delenv("KEYCLOAK_REALM", raising=False)
    monkeypatch.delenv("AUTH_CLIENT_ID", raising=False)
    monkeypatch.delenv("KEYCLOAK_CLIENT_ID", raising=False)
    monkeypatch.delenv("KEYCLOAK_CLIENT_SECRET", raising=False)
    caplog.set_level("ERROR")

    with pytest.raises(ValueError) as exc:
        AuthGuardian()

    assert "KEYCLOAK_CLIENT_SECRET" in str(exc.value)
    assert any(
        "Missing required environment variables for AuthGuardian" in message
        for message in caplog.messages
    )


@pytest.mark.asyncio
@respx.mock
async def test_http_client_reused_across_requests() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        client_secret="my-secret",
        verify_tls=False,
        token_validation=TokenValidationMode.INTROSPECTION,
    )
    validator = AuthTokenValidator(config)

    respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token/introspect"
    ).mock(return_value=Response(200, json={"active": True, "sub": "user-123"}))

    await validator.introspect_token("token-1")
    first_client = await validator.get_http_client()

    await validator.introspect_token("token-2")
    second_client = await validator.get_http_client()

    assert first_client is second_client
    await validator.shutdown()
