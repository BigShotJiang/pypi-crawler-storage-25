import pytest
import respx
from httpx import Response

from auth_guardian import AuthConfig, AuthOIDCClient
from auth_guardian.exceptions import KeycloakAPIError


@pytest.mark.asyncio
@respx.mock
async def test_exchange_authorization_code_ok() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        client_secret="my-secret",
        verify_tls=False,
    )
    client = AuthOIDCClient(config)

    route = respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token"
    ).mock(return_value=Response(200, json={"access_token": "abc", "id_token": "def"}))

    result = await client.exchange_authorization_code("code-123", "https://app.example.com/auth/callback")

    assert result["access_token"] == "abc"
    assert route.called


def test_build_authorization_url_contains_prompt_and_client() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
    )
    client = AuthOIDCClient(config)

    url = client.build_authorization_url(
        redirect_uri="https://app.example.com/auth/callback",
        state_value="state-123",
        prompt="create",
    )

    assert "client_id=my-client" in url
    assert "prompt=create" in url
    assert "state=state-123" in url


@pytest.mark.asyncio
@respx.mock
async def test_exchange_authorization_code_fails_on_non_200() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        verify_tls=False,
    )
    client = AuthOIDCClient(config)

    respx.post(
        f"{config.backend_realm_url}/protocol/openid-connect/token"
    ).mock(return_value=Response(401, json={"error": "invalid_grant"}))

    with pytest.raises(KeycloakAPIError, match="No se pudo completar autenticacion"):
        await client.exchange_authorization_code("bad", "https://app.example.com/auth/callback")
