from auth_guardian.state import generate_signed_state, verify_signed_state


def test_generate_and_verify_state_roundtrip() -> None:
    secret = "super-secret"
    state, signature = generate_signed_state(secret)

    assert state
    assert signature
    assert verify_signed_state(secret, state, signature) is True


def test_verify_state_fails_for_modified_state() -> None:
    secret = "super-secret"
    state, signature = generate_signed_state(secret)

    assert verify_signed_state(secret, state + "x", signature) is False
