from auth_guardian.roles import extract_client_roles


def test_extract_client_roles_unique_sorted() -> None:
    payload = {
        "resource_access": {
            "my-client": {
                "roles": ["viewer", "admin", "viewer"],
            }
        }
    }

    roles = extract_client_roles(payload, "my-client")

    assert roles == ["admin", "viewer"]


def test_extract_client_roles_missing_client() -> None:
    payload = {"resource_access": {"other": {"roles": ["admin"]}}}

    roles = extract_client_roles(payload, "my-client")

    assert roles == []
