import asyncio
import logging
from types import SimpleNamespace

import pytest
from fastapi import HTTPException

from auth_guardian.core import AuthGuardian
from auth_guardian.revocation.memory import MemoryRevocationBackend
from auth_guardian.revocation.null import NullRevocationBackend
from auth_guardian.router import create_auth_router


@pytest.mark.asyncio
async def test_null_backend_logs_warning(caplog: pytest.LogCaptureFixture) -> None:
    caplog.set_level(logging.WARNING)
    backend = NullRevocationBackend()
    await backend.startup()
    await backend.shutdown()

    assert any(
        "tokens remain valid until expiry after logout" in message.lower()
        for message in caplog.messages
    )


@pytest.mark.asyncio
async def test_memory_backend_ttl_expiry() -> None:
    backend = MemoryRevocationBackend(cleanup_interval_seconds=1)
    await backend.startup()
    await backend.revoke("abc", ttl=1)

    assert await backend.is_revoked("abc") is True

    await asyncio.sleep(1.2)
    await backend.cleanup()

    assert await backend.is_revoked("abc") is False
    await backend.shutdown()


@pytest.mark.asyncio
async def test_memory_backend_thread_safe() -> None:
    backend = MemoryRevocationBackend()
    await backend.startup()

    async def _revoke(index: int) -> None:
        await backend.revoke(f"jti-{index}", ttl=300)

    await asyncio.gather(*[_revoke(i) for i in range(300)])

    results = await asyncio.gather(*[backend.is_revoked(f"jti-{i}") for i in range(300)])

    assert all(results)
    await backend.shutdown()


@pytest.mark.asyncio
async def test_logout_revokes_keycloak_refresh_token() -> None:
    auth = AuthGuardian(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        client_secret="my-secret",
        state_secret="state-secret",
        revocation_backend=MemoryRevocationBackend(),
    )

    class FakeOIDCClient:
        def __init__(self) -> None:
            self.revoked_tokens: list[str] = []

        def build_logout_url(self, post_logout_redirect_uri: str, id_token_hint: str | None) -> str:
            return "https://sso.example.com/logout"

        async def revoke_refresh_token(self, refresh_token: str) -> None:
            self.revoked_tokens.append(refresh_token)

    fake_oidc = FakeOIDCClient()

    async def fake_get_tenant_clients(request: object):
        return auth.validator, fake_oidc

    revoked_access_tokens: list[str] = []

    async def fake_revoke_token(token: str) -> None:
        revoked_access_tokens.append(token)

    auth.get_tenant_clients = fake_get_tenant_clients  # type: ignore[assignment]
    auth.revoke_token = fake_revoke_token  # type: ignore[assignment]

    router = create_auth_router(auth=auth, oidc_state_secret="state-secret")
    logout_endpoint = next(
        route.endpoint for route in router.routes if getattr(route, "path", "") == "/logout"
    )

    request = SimpleNamespace(
        cookies={
            "id_token": "id-token-1",
            "access_token": "access-token-1",
            "refresh_token": "refresh-token-1",
        },
        base_url="https://app.example.com/",
    )

    response = await logout_endpoint(request)

    assert response.status_code == 302
    assert fake_oidc.revoked_tokens == ["refresh-token-1"]
    assert revoked_access_tokens == ["access-token-1"]


@pytest.mark.asyncio
async def test_revoked_token_rejected_on_validation() -> None:
    backend = MemoryRevocationBackend()
    await backend.startup()
    await backend.revoke("f0f7b112-262e-44cd-b562-524fec3fc7b7", ttl=60)

    auth = AuthGuardian(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        client_secret="my-secret",
        state_secret="state-secret",
        revocation_backend=backend,
    )

    class FakeValidator:
        def __init__(self) -> None:
            from auth_guardian.config import TokenValidationMode

            self.config = SimpleNamespace(token_validation=TokenValidationMode.LOCAL)

        async def decode_access_token(self, token: str) -> dict[str, str]:
            return {"jti": "f0f7b112-262e-44cd-b562-524fec3fc7b7", "preferred_username": "john"}

        async def introspect_token(self, token: str) -> dict[str, str]:
            return {"jti": "f0f7b112-262e-44cd-b562-524fec3fc7b7", "preferred_username": "john"}

    class FakeResponse:
        def set_cookie(self, *args: object, **kwargs: object) -> None:
            return None

    auth.validator = FakeValidator()  # type: ignore[assignment]
    auth._tenants_cache[auth.config.realm] = (auth.validator, auth.oidc_client)  # type: ignore[assignment]

    request = SimpleNamespace(cookies={})
    response = FakeResponse()
    credentials = SimpleNamespace(credentials="access-token")

    with pytest.raises(HTTPException) as exc:
        await auth.get_current_user(request, response, credentials)

    assert exc.value.status_code == 401
    assert "revoked" in str(exc.value.detail).lower()
    await backend.shutdown()
