import base64
import time
from typing import Any

import pytest
import respx
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from httpx import Response
from jose import jwt

from auth_guardian import AuthConfig, AuthTokenValidator
from auth_guardian.exceptions import TokenValidationError


def _b64url_uint(value: int) -> str:
    raw = value.to_bytes((value.bit_length() + 7) // 8, "big")
    return base64.urlsafe_b64encode(raw).rstrip(b"=").decode("ascii")


def _build_rsa_fixture(config: AuthConfig) -> dict[str, Any]:
    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_numbers = private_key.public_key().public_numbers()

    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")

    kid = "test-kid"
    jwk = {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": _b64url_uint(public_numbers.n),
        "e": _b64url_uint(public_numbers.e),
    }

    token_payload = {
        "iss": config.expected_issuer,
        "azp": config.client_id,
        "exp": int(time.time()) + 600,
        "preferred_username": "jane.doe",
    }
    token = jwt.encode(token_payload, private_pem, algorithm="RS256", headers={"kid": kid})

    return {
        "jwk": jwk,
        "token": token,
    }


@pytest.mark.asyncio
@respx.mock
async def test_decode_access_token_ok_and_cache() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        verify_tls=False,
    )
    validator = AuthTokenValidator(config)
    fixture = _build_rsa_fixture(config)

    route = respx.get(
        f"{config.backend_realm_url}/protocol/openid-connect/certs"
    ).mock(return_value=Response(200, json={"keys": [fixture["jwk"]]}))

    decoded_1 = await validator.decode_access_token(fixture["token"])
    decoded_2 = await validator.decode_access_token(fixture["token"])

    assert decoded_1["preferred_username"] == "jane.doe"
    assert decoded_2["preferred_username"] == "jane.doe"
    assert route.call_count == 1


@pytest.mark.asyncio
@respx.mock
async def test_decode_access_token_rejects_wrong_client() -> None:
    config = AuthConfig(
        base_url="https://sso.example.com",
        realm="myrealm",
        client_id="my-client",
        verify_tls=False,
    )
    validator = AuthTokenValidator(config)

    private_key = rsa.generate_private_key(public_exponent=65537, key_size=2048)
    public_numbers = private_key.public_key().public_numbers()
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")

    kid = "test-kid-2"
    jwk = {
        "kty": "RSA",
        "kid": kid,
        "alg": "RS256",
        "use": "sig",
        "n": _b64url_uint(public_numbers.n),
        "e": _b64url_uint(public_numbers.e),
    }

    payload = {
        "iss": config.expected_issuer,
        "azp": "other-client",
        "exp": int(time.time()) + 600,
        "preferred_username": "john.doe",
    }
    token = jwt.encode(payload, private_pem, algorithm="RS256", headers={"kid": kid})

    respx.get(
        f"{config.backend_realm_url}/protocol/openid-connect/certs"
    ).mock(return_value=Response(200, json={"keys": [jwk]}))

    with pytest.raises(TokenValidationError, match="Token emitido para otro cliente"):
        await validator.decode_access_token(token)
