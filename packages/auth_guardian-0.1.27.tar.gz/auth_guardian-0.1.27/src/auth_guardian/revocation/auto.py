"""Compatibility auto backend.

This module is kept for backwards compatibility. The backend defaults to
in-memory revocation and does not use external infrastructure.
"""

from __future__ import annotations

from auth_guardian.revocation.memory import MemoryRevocationBackend


class AutoRevocationBackend(MemoryRevocationBackend):
    """Backward-compatible alias that currently resolves to memory revocation."""

