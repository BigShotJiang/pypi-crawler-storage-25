"""In-memory revocation backend."""

from __future__ import annotations

import asyncio
import time
from contextlib import suppress

from auth_guardian.revocation.base import RevocationBackend


class MemoryRevocationBackend(RevocationBackend):
    """
    Garantiza: revocacion inmediata en single instance / single process.
    No garantiza: revocacion entre multiples instancias/pods.
    Usar cuando: desarrollo, single instance, o access tokens de vida corta.
    Para multi-instancia: implementa RevocationBackend con tu propio backend compartido.
    """

    def __init__(self, *, cleanup_interval_seconds: int = 60) -> None:
        """Build an in-memory revocation backend with periodic cleanup."""
        self._store: dict[str, float] = {}
        self._lock = asyncio.Lock()
        self._cleanup_interval_seconds = max(5, cleanup_interval_seconds)
        self._cleanup_task: asyncio.Task[None] | None = None
        self._stop_event = asyncio.Event()

    async def revoke(self, jti: str, ttl: int) -> None:
        """Store ``jti`` in local memory until TTL expires."""
        if ttl <= 0:
            return

        expires_at = time.time() + ttl
        async with self._lock:
            self._store[jti] = expires_at

    async def is_revoked(self, jti: str) -> bool:
        """Return ``True`` when ``jti`` exists and has not expired locally."""
        now = time.time()
        async with self._lock:
            await self._purge_expired_locked(now)
            expires_at = self._store.get(jti)
            if expires_at is None:
                return False
            if expires_at <= now:
                self._store.pop(jti, None)
                return False
            return True

    async def startup(self) -> None:
        """Start background cleanup task for expired entries."""
        if self._cleanup_task and not self._cleanup_task.done():
            return

        self._stop_event.clear()
        self._cleanup_task = asyncio.create_task(self._cleanup_loop())

    async def shutdown(self) -> None:
        """Stop background cleanup task gracefully."""
        self._stop_event.set()
        task = self._cleanup_task
        self._cleanup_task = None

        if task is None:
            return

        task.cancel()
        with suppress(asyncio.CancelledError):
            await task

    async def cleanup(self) -> None:
        """Remove expired JTIs from local memory."""
        now = time.time()
        async with self._lock:
            await self._purge_expired_locked(now)

    async def _cleanup_loop(self) -> None:
        while not self._stop_event.is_set():
            try:
                await asyncio.wait_for(
                    self._stop_event.wait(),
                    timeout=self._cleanup_interval_seconds,
                )
            except TimeoutError:
                await self.cleanup()

    async def _purge_expired_locked(self, now: float) -> None:
        expired = [key for key, expires_at in self._store.items() if expires_at <= now]
        for key in expired:
            self._store.pop(key, None)
