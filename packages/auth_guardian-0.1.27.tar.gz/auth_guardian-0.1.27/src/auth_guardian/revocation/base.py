"""Base contracts for token revocation backends."""

from __future__ import annotations

from abc import ABC, abstractmethod


class RevocationBackend(ABC):
    """Abstract backend used to store and check revoked token identifiers."""

    @abstractmethod
    async def revoke(self, jti: str, ttl: int) -> None:
        """Store ``jti`` as revoked for ``ttl`` seconds."""

    @abstractmethod
    async def is_revoked(self, jti: str) -> bool:
        """Return ``True`` when ``jti`` has been revoked and is still active."""

    @abstractmethod
    async def startup(self) -> None:
        """Initialize backend resources and background workers."""

    @abstractmethod
    async def shutdown(self) -> None:
        """Close backend resources gracefully."""

    async def cleanup(self) -> None:
        """Backward-compatible cleanup hook.

        New backends should use ``startup``/``shutdown`` lifecycle methods.
        """
        return None
