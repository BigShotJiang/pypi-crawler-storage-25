"""Compatibility exports for revocation backends."""

from __future__ import annotations

import logging

from auth_guardian.revocation.auto import AutoRevocationBackend
from auth_guardian.revocation.memory import MemoryRevocationBackend
from auth_guardian.revocation.null import NullRevocationBackend

log = logging.getLogger(__name__)


class DatabaseRevocationBackend(MemoryRevocationBackend):
    """Backward-compatible stub that falls back to in-memory revocation.

    Built-in database revocation storage was removed to avoid touching user
    infrastructure by default. Provide a custom ``RevocationBackend`` when you
    need shared revocation state.
    """

    def __init__(self, database_url: str, **kwargs: object) -> None:
        self.database_url = database_url
        super().__init__(**kwargs)
        log.warning(
            "DatabaseRevocationBackend is deprecated and now falls back to in-memory revocation. "
            "Provide a custom RevocationBackend for shared revocation state."
        )


__all__ = [
    "AutoRevocationBackend",
    "DatabaseRevocationBackend",
    "MemoryRevocationBackend",
    "NullRevocationBackend",
]

