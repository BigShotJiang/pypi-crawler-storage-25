"""No-op revocation backend."""

from __future__ import annotations

import logging

from auth_guardian.revocation.base import RevocationBackend

log = logging.getLogger(__name__)


class NullRevocationBackend(RevocationBackend):
    """
    Garantiza: cero estado local y cero persistencia de revocacion.
    No garantiza: revocacion inmediata del access token tras logout.
    Usar cuando: quieras desactivar explicitamente la blacklist local.
    """

    async def revoke(self, jti: str, ttl: int) -> None:
        """Ignore revocation requests."""
        return None

    async def is_revoked(self, jti: str) -> bool:
        """Always return ``False`` because state is never persisted."""
        return False

    async def startup(self) -> None:
        """Emit explicit warning about token revocation trade-off."""
        log.warning("NullRevocationBackend: tokens remain valid until expiry after logout.")

    async def shutdown(self) -> None:
        """No shutdown operations are required."""
        return None
