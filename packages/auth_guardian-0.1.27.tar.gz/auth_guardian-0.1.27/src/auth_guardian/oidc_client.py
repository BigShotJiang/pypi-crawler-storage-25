from typing import Any, cast
from urllib.parse import urlencode

import httpx

from auth_guardian.config import AuthConfig
from auth_guardian.exceptions import KeycloakAPIError


class AuthOIDCClient:
    def __init__(self, config: AuthConfig):
        self.config = config

    def build_authorization_url(
        self,
        redirect_uri: str,
        state_value: str,
        prompt: str = "login",
    ) -> str:
        params = {
            "client_id": self.config.client_id,
            "response_type": "code",
            "redirect_uri": redirect_uri,
            "scope": "openid profile email",
            "state": state_value,
            "prompt": prompt,
        }
        return (
            f"{self.config.frontend_realm_url}/protocol/openid-connect/auth?"
            f"{urlencode(params)}"
        )

    async def exchange_authorization_code(self, code: str, redirect_uri: str) -> dict[str, Any]:
        token_url = f"{self.config.backend_realm_url}/protocol/openid-connect/token"
        payload = {
            "grant_type": "authorization_code",
            "code": code,
            "redirect_uri": redirect_uri,
            "client_id": self.config.client_id,
        }
        if self.config.client_secret:
            payload["client_secret"] = self.config.client_secret

        async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
            response = await client.post(
                token_url,
                data=payload,
                timeout=self.config.request_timeout_seconds,
            )

        if response.status_code != 200:
            raise KeycloakAPIError("No se pudo completar autenticacion", status_code=401)

        data = cast(dict[str, Any], response.json())
        if not data.get("access_token"):
            raise KeycloakAPIError("Keycloak no devolvio access_token", status_code=401)

        return data

    async def refresh_access_token(self, refresh_token: str) -> dict[str, Any]:
        token_url = f"{self.config.backend_realm_url}/protocol/openid-connect/token"
        payload = {
            "grant_type": "refresh_token",
            "refresh_token": refresh_token,
            "client_id": self.config.client_id,
        }
        if self.config.client_secret:
            payload["client_secret"] = self.config.client_secret

        async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
            response = await client.post(
                token_url,
                data=payload,
                timeout=self.config.request_timeout_seconds,
            )

        if response.status_code != 200:
            raise KeycloakAPIError("No se pudo refrescar el token", status_code=401)

        data = cast(dict[str, Any], response.json())
        if not data.get("access_token"):
            raise KeycloakAPIError(
                "Keycloak no devolvio access_token al refrescar",
                status_code=401,
            )

        return data

    async def revoke_refresh_token(self, refresh_token: str) -> None:
        """Revoke a refresh token in Keycloak so it cannot mint new access tokens."""
        revoke_url = f"{self.config.backend_realm_url}/protocol/openid-connect/revoke"
        payload = {
            "token": refresh_token,
            "token_type_hint": "refresh_token",
            "client_id": self.config.client_id,
        }
        if self.config.client_secret:
            payload["client_secret"] = self.config.client_secret

        async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
            response = await client.post(
                revoke_url,
                data=payload,
                timeout=self.config.request_timeout_seconds,
            )

        if response.status_code not in (200, 204):
            raise KeycloakAPIError("No se pudo revocar refresh token en Keycloak", status_code=502)

    def build_logout_url(self, post_logout_redirect_uri: str, id_token_hint: str | None) -> str:
        params = {
            "client_id": self.config.client_id,
            "post_logout_redirect_uri": post_logout_redirect_uri,
        }
        if id_token_hint:
            params["id_token_hint"] = id_token_hint

        return (
            f"{self.config.frontend_realm_url}/protocol/openid-connect/logout?"
            f"{urlencode(params)}"
        )

    async def get_admin_access_token(self, admin_client_id: str, admin_client_secret: str) -> str:
        token_url = f"{self.config.backend_realm_url}/protocol/openid-connect/token"
        data = {
            "grant_type": "client_credentials",
            "client_id": admin_client_id,
            "client_secret": admin_client_secret,
        }

        async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
            response = await client.post(
                token_url,
                data=data,
                timeout=self.config.request_timeout_seconds,
            )

        if response.status_code != 200:
            raise KeycloakAPIError("No se pudo obtener token admin de Keycloak")

        token_data = cast(dict[str, Any], response.json())
        token = token_data.get("access_token")
        if not token:
            raise KeycloakAPIError("Keycloak admin no devolvio access_token")

        return cast(str, token)

    async def _find_user_id_by_username(self, admin_token: str, username: str) -> str | None:
        users_url = f"{self.config.admin_realm_url}/users"
        headers = {"Authorization": f"Bearer {admin_token}"}

        async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
            response = await client.get(
                users_url,
                headers=headers,
                params={"username": username, "exact": "true"},
                timeout=self.config.request_timeout_seconds,
            )

        if response.status_code != 200:
            return None

        users = cast(list[dict[str, Any]], response.json() or [])
        if not users:
            return None

        return cast(str | None, users[0].get("id"))

    @staticmethod
    def _extract_user_id_from_location(location_header: str | None) -> str | None:
        if not location_header:
            return None
        return location_header.rstrip("/").split("/")[-1] or None

    async def create_user_via_admin_api(
        self,
        *,
        admin_client_id: str,
        admin_client_secret: str,
        username: str,
        email: str,
        first_name: str = "",
        last_name: str = "",
        password: str = "",
        enabled: bool = True,
        email_verified: bool = False,
    ) -> dict[str, Any]:
        admin_token = await self.get_admin_access_token(admin_client_id, admin_client_secret)

        users_url = f"{self.config.admin_realm_url}/users"
        headers = {
            "Authorization": f"Bearer {admin_token}",
            "Content-Type": "application/json",
        }

        user_payload = {
            "username": username,
            "email": email,
            "firstName": first_name,
            "lastName": last_name,
            "enabled": enabled,
            "emailVerified": email_verified,
        }

        async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
            create_response = await client.post(
                users_url,
                json=user_payload,
                headers=headers,
                timeout=self.config.request_timeout_seconds,
            )

        if create_response.status_code == 409:
            raise KeycloakAPIError("Usuario ya existe en Keycloak", status_code=409)

        if create_response.status_code not in (201, 204):
            raise KeycloakAPIError("Keycloak rechazo la creacion de usuario")

        user_id = self._extract_user_id_from_location(create_response.headers.get("Location"))
        if not user_id:
            user_id = await self._find_user_id_by_username(
                admin_token=admin_token,
                username=username,
            )

        if password and user_id:
            password_url = f"{users_url}/{user_id}/reset-password"
            password_payload = {
                "type": "password",
                "value": password,
                "temporary": False,
            }
            async with httpx.AsyncClient(verify=self.config.verify_tls) as client:
                pass_response = await client.put(
                    password_url,
                    json=password_payload,
                    headers=headers,
                    timeout=self.config.request_timeout_seconds,
                )

            if pass_response.status_code != 204:
                raise KeycloakAPIError("Usuario creado pero no se pudo asignar password")

        return {
            "id": user_id,
            "username": username,
            "email": email,
            "name": f"{first_name} {last_name}".strip(),
            "roles": [],
        }
