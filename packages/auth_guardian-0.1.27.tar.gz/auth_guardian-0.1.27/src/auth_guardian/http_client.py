"""Reusable HTTP client utilities for auth-guardian."""

from __future__ import annotations

import asyncio

import httpx


class SharedHTTPClient:
    """Lazily-created shared ``httpx.AsyncClient`` with explicit lifecycle."""

    def __init__(self, *, verify: bool = True, default_timeout_seconds: float = 5.0) -> None:
        self._verify = verify
        self._default_timeout_seconds = default_timeout_seconds
        self._client: httpx.AsyncClient | None = None
        self._lock = asyncio.Lock()

    async def startup(self) -> None:
        """Ensure the underlying HTTP client is created."""
        await self.get_client()

    async def get_client(self) -> httpx.AsyncClient:
        """Return a reusable ``httpx.AsyncClient`` instance."""
        if self._client is not None:
            return self._client

        async with self._lock:
            if self._client is None:
                self._client = httpx.AsyncClient(
                    verify=self._verify,
                    timeout=self._default_timeout_seconds,
                )

        return self._client

    async def shutdown(self) -> None:
        """Close and release the underlying HTTP client."""
        async with self._lock:
            client = self._client
            self._client = None

        if client is not None:
            await client.aclose()
