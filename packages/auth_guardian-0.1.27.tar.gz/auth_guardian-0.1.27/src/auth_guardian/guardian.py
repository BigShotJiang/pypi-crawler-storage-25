"""Compatibility module for AuthGuardian imports."""

from auth_guardian.core import AuthGuardian

__all__ = ["AuthGuardian"]

