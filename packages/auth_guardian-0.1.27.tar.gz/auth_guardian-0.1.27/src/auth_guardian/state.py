import hashlib
import hmac
import secrets


def generate_signed_state(secret: str) -> tuple[str, str]:
    state_value = secrets.token_urlsafe(32)
    signature = hmac.new(
        secret.encode("utf-8"),
        state_value.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return state_value, signature


def verify_signed_state(secret: str, state_value: str, signature: str) -> bool:
    if not state_value or not signature:
        return False
    expected = hmac.new(
        secret.encode("utf-8"),
        state_value.encode("utf-8"),
        hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, signature)
