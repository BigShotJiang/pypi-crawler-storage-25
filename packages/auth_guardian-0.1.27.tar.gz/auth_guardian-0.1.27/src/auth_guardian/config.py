import os
from dataclasses import dataclass, field
from enum import Enum
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from auth_guardian.revocation.base import RevocationBackend


class TokenValidationMode(str, Enum):
    """Token validation modes supported by AuthGuardian."""

    LOCAL = "local"
    INTROSPECTION = "introspection"


def _default_client_secret() -> str | None:
    """Read optional client secret from environment."""
    secret = os.getenv("KEYCLOAK_CLIENT_SECRET")
    return secret or None


def _default_state_secret() -> str | None:
    """Use Keycloak client secret as default OIDC state signer secret."""
    secret = os.getenv("KEYCLOAK_CLIENT_SECRET")
    return secret or None


def _default_token_validation() -> TokenValidationMode:
    """Resolve token validation mode from environment with safe fallback."""
    raw = (
        os.getenv("AUTH_TOKEN_VALIDATION")
        or TokenValidationMode.INTROSPECTION.value
    ).strip().lower()
    try:
        return TokenValidationMode(raw)
    except ValueError:
        return TokenValidationMode.INTROSPECTION


def _default_revocation_backend() -> "RevocationBackend":
    from auth_guardian.revocation.memory import MemoryRevocationBackend

    return MemoryRevocationBackend()


@dataclass(frozen=True)
class AuthConfig:
    base_url: str
    realm: str
    client_id: str
    client_secret: str | None = field(default_factory=_default_client_secret)
    issuer: str | None = None
    internal_url: str | None = None
    state_secret: str | None = field(default_factory=_default_state_secret)
    verify_tls: bool = True
    request_timeout_seconds: float = 20.0
    jwks_cache_ttl_seconds: int = 300
    access_token_lifespan_warning: int = 300
    token_validation: TokenValidationMode = field(default_factory=_default_token_validation)
    revocation_backend: "RevocationBackend" = field(default_factory=_default_revocation_backend)

    @property
    def frontend_realm_url(self) -> str:
        return f"{self.base_url.rstrip('/')}/realms/{self.realm}"

    @property
    def backend_realm_url(self) -> str:
        base = (self.internal_url or self.base_url).rstrip("/")
        return f"{base}/realms/{self.realm}"

    @property
    def admin_realm_url(self) -> str:
        base = (self.internal_url or self.base_url).rstrip("/")
        return f"{base}/admin/realms/{self.realm}"

    @property
    def expected_issuer(self) -> str:
        return self.issuer or self.frontend_realm_url
