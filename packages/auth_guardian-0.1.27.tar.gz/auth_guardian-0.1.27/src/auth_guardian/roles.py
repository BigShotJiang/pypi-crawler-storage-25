from typing import Any


def extract_client_roles(payload: dict[str, Any], client_id: str) -> list[str]:
    resource_access = payload.get("resource_access", {}) or {}
    roles = resource_access.get(client_id, {}).get("roles", []) or []
    return sorted(set(roles))
