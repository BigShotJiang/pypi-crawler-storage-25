"""Compatibility module for token validator imports."""

from auth_guardian.token_validator import AuthTokenValidator

__all__ = ["AuthTokenValidator"]

