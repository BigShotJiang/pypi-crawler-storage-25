import inspect
import logging
import os
import time
from collections.abc import AsyncIterator, Awaitable, Callable
from contextlib import asynccontextmanager
from typing import Any

from fastapi import HTTPException, Request, Response, Security
from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer

from auth_guardian.config import AuthConfig, TokenValidationMode
from auth_guardian.exceptions import KeycloakAPIError, TokenValidationError
from auth_guardian.oidc_client import AuthOIDCClient
from auth_guardian.revocation.base import RevocationBackend
from auth_guardian.revocation.memory import MemoryRevocationBackend
from auth_guardian.roles import extract_client_roles
from auth_guardian.token_validator import AuthTokenValidator

security = HTTPBearer(auto_error=False)
security_dependency = Security(security)
log = logging.getLogger(__name__)


class AuthGuardian:
    """
    A simple facade to integrate authentication into FastAPI applications.
    It automatically reads from environment variables if not explicitly provided.
    """

    def __init__(
        self,
        base_url: str | None = None,
        realm: str | None = None,
        client_id: str | None = None,
        state_secret: str | None = None,
        database_url: str | None = None,
        revocation_backend: RevocationBackend | None = None,
        tenant_resolver: Callable[[Request], str | Awaitable[str]] | None = None,
        **kwargs: Any,
    ):
        base_url = (
            base_url
            or os.getenv("AUTH_BASE_URL")
            or os.getenv("KEYCLOAK_BASE_URL")
            or ""
        )
        realm = realm or os.getenv("AUTH_REALM") or os.getenv("KEYCLOAK_REALM") or ""
        client_id = (
            client_id
            or os.getenv("AUTH_CLIENT_ID")
            or os.getenv("KEYCLOAK_CLIENT_ID")
            or ""
        )
        client_secret = kwargs.get("client_secret") or os.getenv("KEYCLOAK_CLIENT_SECRET") or ""
        state_secret = (
            state_secret
            or kwargs.get("state_secret")
            or client_secret
        )
        database_url = database_url or os.getenv("AUTH_DATABASE_URL")

        missing_vars: list[str] = []
        if not base_url:
            missing_vars.append("KEYCLOAK_BASE_URL")
        if not realm:
            missing_vars.append("KEYCLOAK_REALM")
        if not client_id:
            missing_vars.append("KEYCLOAK_CLIENT_ID")
        if not client_secret:
            missing_vars.append("KEYCLOAK_CLIENT_SECRET")

        if missing_vars:
            missing_list = ", ".join(missing_vars)
            log.error(
                "Missing required environment variables for AuthGuardian: %s",
                missing_list,
            )
            raise ValueError(
                "Missing required configuration variables: "
                f"{missing_list}. "
                "Set them in your environment before starting the app."
            )

        if database_url and revocation_backend is None:
            log.warning(
                "AUTH_DATABASE_URL/database_url is ignored by default. "
                "Provide your own RevocationBackend implementation "
                "if you need shared revocation state."
            )

        selected_backend = revocation_backend or MemoryRevocationBackend()
        self.revocation_backend = selected_backend
        kwargs["client_secret"] = client_secret
        kwargs["state_secret"] = state_secret

        self.config = AuthConfig(
            base_url=base_url,
            realm=realm,
            client_id=client_id,
            revocation_backend=self.revocation_backend,
            **kwargs,
        )
        self.validator = AuthTokenValidator(self.config)
        self.oidc_client = AuthOIDCClient(self.config)

        self.tenant_resolver = tenant_resolver
        self._tenants_cache: dict[str, tuple[AuthTokenValidator, AuthOIDCClient]] = {}
        if self.config.realm:
            self._tenants_cache[self.config.realm] = (self.validator, self.oidc_client)

        self._started = False

    def get_validator(self) -> AuthTokenValidator:
        """Return the default token validator instance."""
        return self.validator

    async def startup(self) -> None:
        """Initialize revocation backend and HTTP resources."""
        if self._started:
            return

        await self.revocation_backend.startup()
        for validator in self._iter_validators():
            await validator.startup()

        if (
            self.config.token_validation == TokenValidationMode.INTROSPECTION
            and not self.config.client_secret
        ):
            log.warning(
                "token_validation=introspection without KEYCLOAK_CLIENT_SECRET. "
                "If your Keycloak client is confidential, introspection can fail with 401/403."
            )

        await self._warn_access_token_lifespan()
        self._started = True

    async def shutdown(self) -> None:
        """Release HTTP resources and backend workers."""
        for validator in self._iter_validators():
            try:
                await validator.shutdown()
            except Exception as exc:  # pragma: no cover - defensive logging
                log.error("Error while shutting down token validator: %s", exc)

        try:
            await self.revocation_backend.shutdown()
        except Exception as exc:  # pragma: no cover - defensive logging
            log.error("Error while shutting down revocation backend: %s", exc)

        self._started = False

    def lifespan(self) -> Callable[[Any], AsyncIterator[None]]:
        """Return a FastAPI lifespan handler for startup/shutdown integration."""

        @asynccontextmanager
        async def _lifespan(_: Any) -> AsyncIterator[None]:
            await self.startup()
            try:
                yield
            finally:
                await self.shutdown()

        return _lifespan

    async def get_tenant_clients(
        self,
        request: Request,
    ) -> tuple[AuthTokenValidator, AuthOIDCClient]:
        """
        Dynamically resolves the AuthTokenValidator and AuthOIDCClient based on the request.
        Caches the instances per realm.
        """
        if not self.tenant_resolver:
            return self.validator, self.oidc_client

        if inspect.iscoroutinefunction(self.tenant_resolver):
            realm = await self.tenant_resolver(request)
        else:
            realm = self.tenant_resolver(request)

        if not realm:
            realm = self.config.realm

        if realm not in self._tenants_cache:
            new_config = AuthConfig(
                base_url=self.config.base_url,
                realm=realm,
                client_id=self.config.client_id,
                client_secret=self.config.client_secret,
                issuer=self.config.issuer,
                internal_url=self.config.internal_url,
                state_secret=self.config.state_secret,
                verify_tls=self.config.verify_tls,
                request_timeout_seconds=self.config.request_timeout_seconds,
                jwks_cache_ttl_seconds=self.config.jwks_cache_ttl_seconds,
                access_token_lifespan_warning=self.config.access_token_lifespan_warning,
                token_validation=self.config.token_validation,
                revocation_backend=self.revocation_backend,
            )
            validator = AuthTokenValidator(new_config)
            oidc_client = AuthOIDCClient(new_config)
            if self._started:
                await validator.startup()
            self._tenants_cache[realm] = (validator, oidc_client)

        return self._tenants_cache[realm]

    async def get_current_user(
        self,
        request: Request,
        response: Response,
        credentials: HTTPAuthorizationCredentials | None = security_dependency,
    ) -> dict[str, Any]:
        """
        FastAPI dependency to get the authenticated user's token payload.
        Handles silent token refreshing if the token is expired and a valid refresh token exists.
        """
        token = credentials.credentials if credentials else request.cookies.get("access_token")
        cookie_name = "access_token"
        if not token:
            token = request.cookies.get("pfx_token")
            if token:
                cookie_name = "pfx_token"

        if not token:
            raise HTTPException(status_code=401, detail="Not authenticated")

        validator, oidc_client = await self.get_tenant_clients(request)

        try:
            return await self._resolve_payload(validator, token)
        except KeycloakAPIError as exc:
            log.error("Token validation upstream error: %s", exc.detail)
            raise HTTPException(
                status_code=503,
                detail="Authentication service temporarily unavailable",
            ) from exc
        except TokenValidationError as exc:
            if self._is_token_expired_error(exc):
                refresh_token = request.cookies.get("refresh_token")
                if not refresh_token:
                    refresh_token = request.cookies.get("pfx_refresh_token")

                if refresh_token:
                    try:
                        token_data = await oidc_client.refresh_access_token(refresh_token)
                        new_access_token = token_data["access_token"]
                        new_refresh_token = token_data.get("refresh_token", refresh_token)

                        is_prod = os.getenv("IS_PROD", "false").lower() == "true"
                        response.set_cookie(
                            cookie_name,
                            new_access_token,
                            httponly=True,
                            samesite="lax",
                            secure=is_prod,
                        )
                        response.set_cookie(
                            (
                                "refresh_token"
                                if not request.cookies.get("pfx_refresh_token")
                                else "pfx_refresh_token"
                            ),
                            new_refresh_token,
                            httponly=True,
                            samesite="lax",
                            secure=is_prod,
                        )

                        return await self._resolve_payload(validator, new_access_token)
                    except (KeycloakAPIError, TokenValidationError):
                        pass

            raise HTTPException(status_code=exc.status_code, detail=exc.detail) from exc

    def require_role(self, *required_roles: str) -> Callable[..., Awaitable[dict[str, Any]]]:
        """
        FastAPI dependency factory to require specific roles.
        """

        async def _role_guard(
            request: Request,
            response: Response,
            credentials: HTTPAuthorizationCredentials | None = security_dependency,
        ) -> dict[str, Any]:
            user = await self.get_current_user(request, response, credentials)
            roles = set(extract_client_roles(user, self.config.client_id))
            if not roles.intersection(required_roles):
                raise HTTPException(status_code=403, detail="Insufficient permissions")
            return user

        return _role_guard

    async def revoke_token(self, token: str) -> None:
        """
        Revoke an access token by storing its JTI until token expiration.
        """
        try:
            payload = await self.validator.decode_access_token(token)
            jti = payload.get("jti")
            exp = payload.get("exp")

            if not jti or not exp:
                return

            ttl = int(exp) - int(time.time())
            if ttl <= 0:
                return

            if ttl > self.config.access_token_lifespan_warning:
                log.warning(
                    "Access token TTL (%ss) is higher than recommended (%ss). "
                    "Consider shorter access token lifespan in Keycloak.",
                    ttl,
                    self.config.access_token_lifespan_warning,
                )

            await self.revocation_backend.revoke(str(jti), ttl)
        except Exception as exc:
            log.error("Failed to revoke token in backend: %s", exc)

    async def _resolve_payload(self, validator: AuthTokenValidator, token: str) -> dict[str, Any]:
        if validator.config.token_validation == TokenValidationMode.INTROSPECTION:
            return await validator.introspect_token(token)

        payload = await validator.decode_access_token(token)
        jti = payload.get("jti")
        if not jti:
            return payload

        try:
            if await self.revocation_backend.is_revoked(str(jti)):
                raise TokenValidationError("Token revoked")
        except TokenValidationError:
            raise
        except Exception as exc:
            log.error("Failed to check token revocation backend: %s", exc)
            raise TokenValidationError(
                "No se pudo validar revocacion del token",
                status_code=503,
            ) from exc

        return payload

    async def _warn_access_token_lifespan(self) -> None:
        metadata_url = f"{self.config.backend_realm_url}/.well-known/openid-configuration"
        try:
            client = await self.validator.get_http_client()
            response = await client.get(metadata_url, timeout=self.config.request_timeout_seconds)
            if response.status_code != 200:
                return
            metadata = response.json()
            if not isinstance(metadata, dict):
                return
        except Exception:
            return

        lifespan = self._extract_access_token_lifespan(metadata)
        if lifespan is None:
            return

        if lifespan > self.config.access_token_lifespan_warning:
            log.warning(
                "ACCESS TOKEN LIFESPAN is %ss. "
                "Recommend <= %ss for secure revocation without shared storage.",
                lifespan,
                self.config.access_token_lifespan_warning,
            )

    def _iter_validators(self) -> list[AuthTokenValidator]:
        validators: list[AuthTokenValidator] = []
        seen: set[int] = set()
        for validator, _ in self._tenants_cache.values():
            key = id(validator)
            if key in seen:
                continue
            seen.add(key)
            validators.append(validator)
        return validators

    @staticmethod
    def _extract_access_token_lifespan(metadata: dict[str, Any]) -> int | None:
        candidates = (
            "access_token_lifespan",
            "accessTokenLifespan",
            "access_token_lifespan_seconds",
            "accessTokenLifespanSeconds",
        )
        for key in candidates:
            value = metadata.get(key)
            if isinstance(value, (int, float)):
                return int(value)
            if isinstance(value, str) and value.isdigit():
                return int(value)
        return None

    @staticmethod
    def _is_token_expired_error(exc: TokenValidationError) -> bool:
        detail = exc.detail.lower()
        return "expirado" in detail or "expired" in detail
