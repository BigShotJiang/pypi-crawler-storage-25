import logging
import os
from collections.abc import Callable
from typing import Any

from fastapi import APIRouter, Query, Request, status
from fastapi.responses import RedirectResponse

from auth_guardian.core import AuthGuardian
from auth_guardian.state import generate_signed_state, verify_signed_state

log = logging.getLogger(__name__)


def create_auth_router(
    auth: AuthGuardian,
    oidc_state_secret: str | None = None,
    cookie_name: str = "access_token",
    cookie_id_name: str = "id_token",
    cookie_refresh_name: str = "refresh_token",
    login_redirect_url: str = "/",
    logout_redirect_url: str = "/login",
    on_login_success: Callable[[dict[str, Any]], Any] | None = None,
) -> APIRouter:
    """
    Creates a pre-configured FastAPI router with /login, /logout, and /oidc/callback routes
    for seamless integration of AuthGuardian.
    """
    router = APIRouter(tags=["Auth"])

    state_secret = oidc_state_secret or auth.config.state_secret
    if not state_secret:
        raise ValueError(
            "oidc_state_secret must be provided "
            "or KEYCLOAK_CLIENT_SECRET must be set"
        )

    def _generate_state() -> tuple[str, str]:
        return generate_signed_state(state_secret)

    def _verify_state(state_value: str, signature: str) -> bool:
        return verify_signed_state(state_secret, state_value, signature)

    def _delete_cookies(response: RedirectResponse) -> None:
        response.delete_cookie(cookie_name)
        response.delete_cookie(cookie_id_name)
        response.delete_cookie(cookie_refresh_name)
        response.delete_cookie("oidc_state")
        response.delete_cookie("oidc_state_sig")

    def _get_redirect_uri(request: Request) -> str:
        return str(request.url_for("auth_guardian_oidc_callback"))

    @router.get("/login", summary="Initiate OIDC Login")
    async def login(request: Request):
        _, oidc_client = await auth.get_tenant_clients(request)
        redirect_uri = _get_redirect_uri(request)
        state_value, state_signature = _generate_state()

        auth_url = oidc_client.build_authorization_url(
            redirect_uri=redirect_uri,
            state_value=state_value,
            prompt="login",
        )

        response = RedirectResponse(url=auth_url)
        response.set_cookie(
            "oidc_state",
            state_value,
            httponly=True,
            samesite="lax",
            max_age=600,
        )
        response.set_cookie(
            "oidc_state_sig",
            state_signature,
            httponly=True,
            samesite="lax",
            max_age=600,
        )
        return response

    @router.get("/oidc/callback", include_in_schema=False, name="auth_guardian_oidc_callback")
    async def callback(
        request: Request,
        code: str | None = Query(default=None),
        state: str | None = Query(default=None),
        error: str | None = Query(default=None),
        error_description: str | None = Query(default=None),
    ):
        if error or not code:
            log.warning(f"OIDC callback error: {error} - {error_description}")
            resp = RedirectResponse(url=f"{logout_redirect_url}?error=auth_failed", status_code=303)
            _delete_cookies(resp)
            return resp

        stored_state = request.cookies.get("oidc_state")
        stored_signature = request.cookies.get("oidc_state_sig")

        if (
            not stored_state
            or not stored_signature
            or state != stored_state
            or not _verify_state(stored_state, stored_signature)
        ):
            log.error("OIDC state mismatch or invalid signature.")
            resp = RedirectResponse(url=f"{logout_redirect_url}?error=csrf_error", status_code=303)
            _delete_cookies(resp)
            return resp

        try:
            _, oidc_client = await auth.get_tenant_clients(request)
            token_data = await oidc_client.exchange_authorization_code(
                code=code,
                redirect_uri=_get_redirect_uri(request),
            )
        except Exception as exc:
            log.error(f"Error exchanging token: {exc}")
            resp = RedirectResponse(url=f"{logout_redirect_url}?error=auth_retry", status_code=303)
            _delete_cookies(resp)
            return resp

        access_token = token_data.get("access_token")
        id_token = token_data.get("id_token")
        refresh_token = token_data.get("refresh_token")

        if not access_token:
            resp = RedirectResponse(url=f"{logout_redirect_url}?error=auth_retry", status_code=303)
            _delete_cookies(resp)
            return resp

        if on_login_success:
            try:
                validator, _ = await auth.get_tenant_clients(request)
                payload = await validator.decode_access_token(access_token)
                await on_login_success(payload)
            except Exception as exc:
                log.error("Error in on_login_success hook: %s", exc)

        is_prod = os.getenv("IS_PROD", "false").lower() == "true"
        response = RedirectResponse(url=login_redirect_url, status_code=303)
        response.set_cookie(
            cookie_name,
            access_token,
            httponly=True,
            samesite="lax",
            secure=is_prod,
        )
        if id_token:
            response.set_cookie(
                cookie_id_name,
                id_token,
                httponly=True,
                samesite="lax",
                secure=is_prod,
            )
        if refresh_token:
            response.set_cookie(
                cookie_refresh_name,
                refresh_token,
                httponly=True,
                samesite="lax",
                secure=is_prod,
            )

        response.delete_cookie("oidc_state")
        response.delete_cookie("oidc_state_sig")
        return response

    @router.get("/logout", summary="Logout user")
    async def logout(request: Request):
        _, oidc_client = await auth.get_tenant_clients(request)
        id_token = request.cookies.get(cookie_id_name)
        access_token = request.cookies.get(cookie_name)
        refresh_token = request.cookies.get(cookie_refresh_name)

        keycloak_logout_url = oidc_client.build_logout_url(
            post_logout_redirect_uri=str(request.base_url).rstrip("/") + logout_redirect_url,
            id_token_hint=id_token,
        )

        resp = RedirectResponse(url=keycloak_logout_url, status_code=status.HTTP_302_FOUND)
        _delete_cookies(resp)

        if access_token:
            await auth.revoke_token(access_token)

        if refresh_token:
            try:
                await oidc_client.revoke_refresh_token(refresh_token)
            except Exception as exc:
                log.warning("Could not revoke refresh token in Keycloak: %s", exc)

        return resp

    return router
