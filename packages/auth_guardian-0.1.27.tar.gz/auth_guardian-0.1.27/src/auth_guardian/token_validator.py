import time
from typing import Any, cast

import httpx
from jose import JWTError, jwt

from auth_guardian.config import AuthConfig
from auth_guardian.exceptions import KeycloakAPIError, TokenValidationError
from auth_guardian.http_client import SharedHTTPClient


class AuthTokenValidator:
    def __init__(self, config: AuthConfig):
        self.config = config
        self._jwks_cache: dict[str, tuple[dict[str, Any], float]] = {}
        self._http_client = SharedHTTPClient(
            verify=self.config.verify_tls,
            default_timeout_seconds=5.0,
        )

    async def startup(self) -> None:
        """Initialize reusable HTTP resources."""
        await self._http_client.startup()

    async def shutdown(self) -> None:
        """Release reusable HTTP resources."""
        await self._http_client.shutdown()

    async def get_http_client(self) -> httpx.AsyncClient:
        """Expose the shared HTTP client used by validator operations."""
        return await self._http_client.get_client()

    def _cache_get(self, kid: str) -> dict[str, Any] | None:
        item = self._jwks_cache.get(kid)
        if not item:
            return None
        key_data, expires_at = item
        if time.time() > expires_at:
            self._jwks_cache.pop(kid, None)
            return None
        return key_data

    def _cache_set(self, kid: str, key_data: dict[str, Any]) -> None:
        expires_at = time.time() + max(30, self.config.jwks_cache_ttl_seconds)
        self._jwks_cache[kid] = (key_data, expires_at)

    async def _get_public_key(self, token: str) -> dict[str, Any]:
        try:
            header = jwt.get_unverified_header(token)
        except Exception as exc:
            raise TokenValidationError("Token malformado") from exc

        kid = header.get("kid")
        if not kid:
            raise TokenValidationError("Token sin kid")

        cached = self._cache_get(kid)
        if cached:
            return cached

        certs_url = f"{self.config.backend_realm_url}/protocol/openid-connect/certs"

        try:
            client = await self.get_http_client()
            response = await client.get(certs_url, timeout=self.config.request_timeout_seconds)
            response.raise_for_status()
            jwks = cast(dict[str, Any], response.json())
        except Exception as exc:
            raise TokenValidationError("No se pudo validar firma del token") from exc

        for key_dict in jwks.get("keys", []):
            if key_dict.get("kid") == kid:
                self._cache_set(kid, key_dict)
                return cast(dict[str, Any], key_dict)

        self._jwks_cache.clear()
        raise TokenValidationError("Firma del token no valida")

    async def decode_access_token(self, token: str) -> dict[str, Any]:
        if not token:
            raise TokenValidationError("No autenticado")

        public_key = await self._get_public_key(token)

        try:
            payload = cast(
                dict[str, Any],
                jwt.decode(
                    token,
                    public_key,
                    algorithms=["RS256"],
                    issuer=self.config.expected_issuer,
                    options={"verify_aud": False},
                ),
            )
        except JWTError as exc:
            raise TokenValidationError("Token invalido o expirado") from exc

        azp = payload.get("azp")
        if azp and azp != self.config.client_id:
            raise TokenValidationError("Token emitido para otro cliente")

        if payload.get("typ") == "ID":
            raise TokenValidationError("Se esperaba access token")

        return payload

    async def introspect_token(self, token: str) -> dict[str, Any]:
        """
        Validate token status using Keycloak token introspection.

        Guarantees: immediate global revocation checks delegated to Keycloak.
        Does not guarantee: availability when Keycloak is down or unreachable.
        Trade-off: one HTTP call per request in exchange for instant revocation
        without local shared state.
        """
        if not token:
            raise TokenValidationError("No autenticado")

        introspect_url = (
            f"{self.config.backend_realm_url}/protocol/openid-connect/token/introspect"
        )
        payload: dict[str, str] = {
            "token": token,
            "client_id": self.config.client_id,
        }
        if self.config.client_secret:
            payload["client_secret"] = self.config.client_secret

        try:
            client = await self.get_http_client()
            response = await client.post(introspect_url, data=payload)
        except httpx.TimeoutException as exc:
            raise KeycloakAPIError("Introspection endpoint unavailable", status_code=503) from exc
        except httpx.HTTPError as exc:
            raise KeycloakAPIError("Introspection endpoint unavailable", status_code=503) from exc

        if response.status_code in (401, 403):
            raise KeycloakAPIError(
                "Token introspection denied by Keycloak. "
                "Check KEYCLOAK_CLIENT_SECRET for confidential clients.",
                status_code=503,
            )
        if response.status_code >= 500:
            raise KeycloakAPIError("Introspection endpoint unavailable", status_code=503)
        if response.status_code >= 400:
            raise KeycloakAPIError("Token introspection failed", status_code=503)

        data = cast(dict[str, Any], response.json())
        if not bool(data.get("active")):
            raise TokenValidationError("Token revoked or inactive")

        return data
