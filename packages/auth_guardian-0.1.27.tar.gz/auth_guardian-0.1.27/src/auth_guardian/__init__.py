"""Public contract for auth-guardian.

Keep this module intentionally small and stable to avoid breaking microservices.
"""

from __future__ import annotations

from importlib.metadata import PackageNotFoundError, version

from auth_guardian.config import AuthConfig, TokenValidationMode
from auth_guardian.core import AuthGuardian
from auth_guardian.exceptions import KeycloakAPIError, KeycloakAuthError, TokenValidationError
from auth_guardian.oidc_client import AuthOIDCClient
from auth_guardian.revocation import (
    AutoRevocationBackend,
    DatabaseRevocationBackend,
    MemoryRevocationBackend,
    NullRevocationBackend,
    RevocationBackend,
)
from auth_guardian.roles import extract_client_roles
from auth_guardian.router import create_auth_router
from auth_guardian.state import generate_signed_state, verify_signed_state
from auth_guardian.token_validator import AuthTokenValidator

try:
    __version__ = version("auth-guardian")
except PackageNotFoundError:
    __version__ = "0.0.0+local"

__all__ = [
    "__version__",
    "AuthGuardian",
    "AuthConfig",
    "TokenValidationMode",
    "AuthTokenValidator",
    "AuthOIDCClient",
    "RevocationBackend",
    "AutoRevocationBackend",
    "NullRevocationBackend",
    "MemoryRevocationBackend",
    "DatabaseRevocationBackend",
    "TokenValidationError",
    "KeycloakAuthError",
    "KeycloakAPIError",
    "create_auth_router",
    "extract_client_roles",
    "generate_signed_state",
    "verify_signed_state",
]
