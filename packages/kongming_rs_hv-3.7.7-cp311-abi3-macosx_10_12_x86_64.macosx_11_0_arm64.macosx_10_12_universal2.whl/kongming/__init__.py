# kongming — top-level import path for kongming-rs-hv
#
# The native extension lives in kongming_rs (PyO3). This package
# re-exports everything so users can write:
#   from kongming import hv
#   from kongming import memory
from kongming_rs import (  # noqa: F401
    REASON_NOT_FOUND,
    HvError,
    __version__,
    hv,
)

try:
    from kongming_rs import memory  # noqa: F401
except ImportError:
    pass  # memory module may not be available in minimal builds

try:
    from kongming_rs import lisp  # noqa: F401
except ImportError:
    pass
