# ![Image](./_d29623d8-088c-480c-8d70-0b831a2c23a6.jpg "PythonCoordinates") PythonCoordinates

During the development of code to construct the source noise directivity patterns from my dissertation, it became 
apparent that on limitation of coding of physical elements was units. Whether it was the code I wrote myself, or 
what I found online it was difficult to know the specific units that we expected, and how to convert them for the 
appropriate unit base used within the function.

This code is part of a larger sweet of tools for the determination of physical phenomena that propagate through the
atmosphere from a source to a receiver.

Dr. Frank Mobley

This code was cleared for public release on 15 March 2023 with originator Reference Number: RH-23-124158, Case Reviewer: 
Katie Brakeville using Case Number: AFRL-2023-1262

# Usage
## Conversion of Temperature Units

	from PythonCoordinates.measurables.physical_quantities import Temperature
	
	t = Temperature(59, Temperature.Units.Fahrenheit)
	print(t.kelvin)
	