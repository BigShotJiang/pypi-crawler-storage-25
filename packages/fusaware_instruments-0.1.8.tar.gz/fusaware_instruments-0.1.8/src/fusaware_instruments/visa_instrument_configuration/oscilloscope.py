# pyright: strict

import time
import os
import csv
from typing import Any
from enum import Enum

from pydantic import BaseModel, validate_call

from fusaware_instruments.visa_instrument_configuration.analog_probe import State, Units
from fusaware_instruments.visa_instrument_hal.hal_oscilloscope import (
    HALOscilloscope,
    Preamble as HalPreamble,
    TriggerCoupling,
    TriggerMode,
    TriggerSlope,
    TriggerSweep,
    ImageFormat,
    WaveformEncoding,
    Units as HalUnits,
    AcquisitionState,
    AcquisitionCondition,
)
from fusaware_instruments.utils import MappingException, compare_floats


class WaveformSource(Enum):
    CH1 = "CH1"
    CH2 = "CH2"
    CH3 = "CH3"
    CH4 = "CH4"
    CH5 = "CH5"
    CH6 = "CH6"
    CH7 = "CH7"
    CH8 = "CH8"


class TimebaseState(BaseModel):
    scale: float
    offset: float


class TriggerState(BaseModel):
    coupling: TriggerCoupling
    holdoff: float
    mode: TriggerMode
    slope: TriggerSlope
    threshold: float
    state: State
    sweep: TriggerSweep


class OscilloscopeConversion:
    @classmethod
    def probe_state_to_hal(cls, state: State) -> bool:
        match state:
            case State.Enabled:
                return True
            case State.Disabled:
                return False

    @classmethod
    def probe_state_from_hal(cls, hal_state: bool) -> State:
        match hal_state:
            case True:
                return State.Enabled
            case False:
                return State.Disabled

    @classmethod
    def channel_to_hal(cls, channel: WaveformSource) -> int:
        return int(channel.value[-1])

    @classmethod
    def channel_from_hal(cls, hal_channel: int) -> WaveformSource:
        return WaveformSource(f"CH{hal_channel}")


@validate_call
def configure_oscope_timebase(
    oscope: HALOscilloscope,
    scale: float,
    offset: float,
) -> tuple[TimebaseState, list[str]]:
    initial_scale = oscope.get_timebase_scale()
    initial_offset = oscope.get_timebase_offset()

    if not compare_floats(initial_scale, scale):
        oscope.set_timebase_scale(scale)
        oscope.sync()
        initial_offset = oscope.get_timebase_offset()
    if not compare_floats(initial_offset, offset):
        oscope.set_timebase_offset(offset)

    oscope.sync()

    final_scale = oscope.get_timebase_scale()
    final_offset = oscope.get_timebase_offset()

    errors: list[str] = []

    if not compare_floats(final_scale, scale):
        errors.append(
            f"Failed to set timebase scale. Expected: {scale}, Got: {final_scale}"
        )
    if not compare_floats(final_offset, offset):
        errors.append(
            f"Failed to set timebase offset. Expected: {offset}, Got: {final_offset}"
        )

    return TimebaseState(
        scale=final_scale,
        offset=final_offset,
    ), errors


@validate_call
def configure_oscope_trigger(
    oscope: HALOscilloscope,
    coupling: TriggerCoupling,
    holdoff: float,
    mode: TriggerMode,
    slope: TriggerSlope,
    threshold: float,
    state: State,
    sweep: TriggerSweep,
) -> tuple[TriggerState, list[str]]:
    initial_coupling = oscope.get_trigger_coupling()
    initial_holdoff = oscope.get_trigger_holdoff()
    initial_mode = oscope.get_trigger_mode()
    initial_slope = oscope.get_trigger_slope()
    initial_threshold = oscope.get_trigger_threshold()
    initial_state = OscilloscopeConversion.probe_state_from_hal(
        oscope.get_probe_display()
    )
    try:
        initial_sweep = oscope.get_trigger_sweep()
    except MappingException:
        initial_sweep = None

    if initial_coupling != coupling:
        oscope.set_trigger_coupling(coupling)
    if not compare_floats(initial_holdoff, holdoff):
        oscope.set_trigger_holdoff(holdoff)
    if initial_mode != mode:
        oscope.set_trigger_mode(mode)
    if initial_slope != slope:
        oscope.set_trigger_slope(slope)
    if not compare_floats(initial_threshold, threshold):
        oscope.set_trigger_threshold(threshold)
    if initial_state != state:
        oscope.set_probe_display(OscilloscopeConversion.probe_state_to_hal(state))
    if initial_sweep != sweep:
        oscope.set_trigger_sweep(sweep)

    oscope.sync()

    final_coupling = oscope.get_trigger_coupling()
    final_holdoff = oscope.get_trigger_holdoff()
    final_mode = oscope.get_trigger_mode()
    final_slope = oscope.get_trigger_slope()
    final_threshold = oscope.get_trigger_threshold()
    final_state = OscilloscopeConversion.probe_state_from_hal(
        oscope.get_probe_display()
    )
    try:
        final_sweep = oscope.get_trigger_sweep()
    except MappingException:
        final_sweep = None

    errors: list[str] = []

    if final_coupling != coupling:
        errors.append(
            f"Failed to set trigger coupling. Expected: {coupling}, Got: {final_coupling}"
        )
    if not compare_floats(final_holdoff, holdoff):
        errors.append(
            f"Failed to set trigger holdoff. Expected: {holdoff}, Got: {final_holdoff}"
        )
    if final_mode != mode:
        errors.append(
            f"Failed to set trigger mode. Expected: {mode}, Got: {final_mode}"
        )
    if final_slope != slope:
        errors.append(
            f"Failed to set trigger slope. Expected: {slope}, Got: {final_slope}"
        )
    if not compare_floats(final_threshold, threshold, tolerance=1e-1):
        errors.append(
            f" Failed to set trigger threshold. Expected: {threshold}, Got: {final_threshold}"
        )
    if final_state != state:
        errors.append(
            f"Failed to set trigger state. Expected: {state}, Got: {final_state}"
        )
    if final_sweep != sweep:
        errors.append(
            f"Failed to set trigger sweep. Expected: {sweep}, Got: {final_sweep}"
        )

    return (
        TriggerState(
            coupling=final_coupling,
            holdoff=final_holdoff,
            mode=final_mode,
            slope=final_slope,
            threshold=final_threshold,
            state=final_state,
            sweep=final_sweep,  # pyright: ignore[reportArgumentType]
        ),
        errors,
    )


class AcquisitionResponse(BaseModel):
    state: AcquisitionState
    condition: AcquisitionCondition
    sample_rate: float
    sample_count: float


@validate_call
def configure_oscope_acquisition(
    oscope: HALOscilloscope,
    state: AcquisitionState,
    condition: AcquisitionCondition,
    min_sample_rate: float,
    max_sample_count: float,
) -> tuple[AcquisitionResponse, list[str]]:
    initial_state = oscope.get_acquisition_state()
    initial_condition = oscope.get_acquisition_condition()
    initial_acquisition_info = oscope.get_acquisition_info(min_sample_rate)

    if initial_acquisition_info.should_update:
        oscope.set_acquisition_info(min_sample_rate)
    if initial_state != state:
        oscope.set_acquisition_state(state)
        oscope.sync()
        initial_condition = oscope.get_acquisition_condition()
    if initial_condition != condition:
        oscope.set_acquisition_condition(condition)

    oscope.sync()

    final_sample_rate = oscope.get_sample_rate()
    final_sample_count = oscope.get_sample_count()
    final_state = oscope.get_acquisition_state()
    final_condition = oscope.get_acquisition_condition()

    errors: list[str] = []

    if min_sample_rate > final_sample_rate:
        errors.append(
            f"Failed to set sample rate >= minimum: {min_sample_rate}. Final sample rate: {final_sample_rate}"
        )
    if max_sample_count < final_sample_count:
        errors.append(
            f"Failed to set sample count <= maximum: {max_sample_count}. Final sample count: {final_sample_count}"
        )
    if final_state != state:
        errors.append(
            f"Failed to set acquisition state: {state}. Final state: {final_state}"
        )
    if final_condition != condition:
        errors.append(
            f"Failed to set acquisition condition: {condition}. Final condition: {final_condition}"
        )

    return AcquisitionResponse(
        sample_rate=final_sample_rate,
        sample_count=final_sample_count,
        state=final_state,
        condition=final_condition,
    ), errors


class CaptureResponse(BaseModel):
    file_name: str
    path: str


IMAGE_FORMAT = ImageFormat.BMP


def _image_format_extension(image_format: ImageFormat) -> str:
    match image_format:
        case ImageFormat.PNG:
            return "png"
        case ImageFormat.BMP:
            return "bmp"
        case ImageFormat.JPG:
            return "jpg"


@validate_call
def capture_screenshot(
    oscope: HALOscilloscope, data_path: str
) -> tuple[CaptureResponse, list[str]]:
    initial_format = oscope.get_image_format()

    if initial_format != IMAGE_FORMAT:
        oscope.set_image_format(IMAGE_FORMAT)

    oscope.sync()

    final_format = oscope.get_image_format()

    file_name = f"{time.time_ns()}.{_image_format_extension(final_format)}"
    host_path = os.path.join(data_path, file_name)

    errors: list[str] = []

    if final_format != IMAGE_FORMAT:
        errors.append(
            f"Failed to set image format. Expected: {IMAGE_FORMAT}, Got: {final_format}"
        )

    if errors:
        return CaptureResponse(file_name="", path=""), errors

    screenshot_bytes = oscope.get_screenshot()

    with open(host_path, mode="wb") as file:
        file.write(screenshot_bytes)

    return CaptureResponse(
        file_name=file_name,
        path=host_path,
    ), []


class Preamble(BaseModel):
    source: WaveformSource
    format: WaveformEncoding
    count: int
    x_increment: float
    x_origin: float
    x_reference: int
    x_zero: float
    x_units: str
    y_increment: float
    y_origin: float
    y_reference: int
    y_zero: float
    y_units: Units

    def to_dict(self) -> dict[str, Any]:
        return {
            "format": self.format.value,
            "count": self.count,
            "x_increment": self.x_increment,
            "x_origin": self.x_origin,
            "x_reference": self.x_reference,
            "x_zero": self.x_zero,
            "x_units": self.x_units,
            "y_increment": self.y_increment,
            "y_origin": self.y_origin,
            "y_reference": self.y_reference,
            "y_zero": self.y_zero,
            "y_units": self.y_units.value,
        }


class PointsResponse(BaseModel):
    path: str
    format: str
    count: int
    preamble: dict[str, Any]


DATA_FORMAT = WaveformEncoding.BINARY


def preamble_from_hal(hal_preamble: HalPreamble) -> Preamble:
    match hal_preamble.y_units:
        case HalUnits.VOLTS:
            y_units = Units.Volts
        case HalUnits.AMPS:
            y_units = Units.Amps
        case HalUnits.WATTS:
            y_units = Units.Other
        case HalUnits.CUSTOM:
            y_units = Units.Other

    return Preamble(
        source=OscilloscopeConversion.channel_from_hal(hal_preamble.source),
        format=hal_preamble.format,
        count=hal_preamble.count,
        x_increment=hal_preamble.x_increment,
        x_origin=hal_preamble.x_origin,
        x_reference=hal_preamble.x_reference,
        x_zero=hal_preamble.x_zero,
        x_units=hal_preamble.x_units,
        y_increment=hal_preamble.y_increment,
        y_origin=hal_preamble.y_origin,
        y_reference=hal_preamble.y_reference,
        y_zero=hal_preamble.y_zero,
        y_units=y_units,
    )


@validate_call
def capture_waveform(
    oscope: HALOscilloscope, data_path: str
) -> tuple[PointsResponse, list[str]]:
    file_name = str(time.time_ns()) + ".csv"
    full_path = os.path.join(data_path, file_name)

    oscope.apply_waveform_source()

    initial_preamble = oscope.get_waveform_preamble()
    initial_start_point = oscope.get_waveform_start_index()
    initial_stop_point = oscope.get_waveform_stop_index()
    initial_sample_count = int(oscope.get_sample_count())

    if initial_start_point != 1:
        oscope.set_waveform_start_index(1)
    if initial_stop_point != initial_sample_count:
        oscope.set_waveform_stop_index(initial_sample_count)
    if initial_preamble.format != DATA_FORMAT:
        oscope.set_waveform_encoding(WaveformEncoding(DATA_FORMAT))

    oscope.sync()

    final_preamble = oscope.get_waveform_preamble()
    final_start_point = oscope.get_waveform_start_index()
    final_stop_point = oscope.get_waveform_stop_index()
    final_sample_count = int(oscope.get_sample_count())

    errors: list[str] = []

    if final_start_point != 1:
        errors.append(
            f"Failed to set waveform start point. Expected: 1, Got: {final_start_point}"
        )
    if final_stop_point != final_sample_count:
        errors.append(
            f"Failed to set waveform stop point. Expected: {final_sample_count}, Got: {final_stop_point}"
        )
    if final_preamble.format != DATA_FORMAT:
        errors.append(
            f"Failed to set waveform encoding. Expected: {DATA_FORMAT}, Got: {final_preamble.format}"
        )

    if errors:
        return PointsResponse(
            path=full_path,
            format=final_preamble.format.value,
            count=final_preamble.count,
            preamble=preamble_from_hal(final_preamble).to_dict(),
        ), errors

    data = oscope.get_waveform_data()

    if len(data) != final_preamble.count:
        errors.append(
            f"Number of points received does not match preamble information. Expected: {final_preamble.count}, Got: {len(data)}"
        )

    timestamps = [
        final_preamble.x_zero + final_preamble.x_increment * i for i in range(len(data))
    ]
    csv_data = zip(timestamps, data)

    with open(full_path, mode="w", newline="") as file:
        writer = csv.writer(file)
        writer.writerows(csv_data)

    return PointsResponse(
        path=str(full_path),
        format="csv",
        count=len(data),
        preamble=preamble_from_hal(final_preamble).to_dict(),
    ), errors
