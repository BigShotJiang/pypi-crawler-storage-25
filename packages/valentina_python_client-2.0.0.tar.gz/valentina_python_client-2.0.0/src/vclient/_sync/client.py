# AUTO-GENERATED — do not edit. Run 'uv run duty generate_sync' to regenerate.
"""Main API client for Valentina."""

import os
import platform
from types import TracebackType
from typing import TYPE_CHECKING, Self

import httpx
from loguru import logger

from vclient.config import _APIConfig
from vclient.constants import (
    API_KEY_HEADER,
    DEFAULT_MAX_RETRIES,
    DEFAULT_RETRY_DELAY,
    DEFAULT_RETRY_STATUSES,
    DEFAULT_TIMEOUT,
    ENV_API_KEY,
    ENV_BASE_URL,
    ENV_DEFAULT_COMPANY_ID,
)

if TYPE_CHECKING:
    from vclient._sync.services import (
        SyncBooksService,
        SyncCampaignsService,
        SyncChaptersService,
        SyncCharacterAutogenService,
        SyncCharacterBlueprintService,
        SyncCharactersService,
        SyncCharacterTraitsService,
        SyncCompaniesService,
        SyncDeveloperService,
        SyncDicerollService,
        SyncDictionaryService,
        SyncGlobalAdminService,
        SyncOptionsService,
        SyncSystemService,
        SyncUserLookupService,
        SyncUserSelfRegistrationService,
        SyncUsersService,
    )


class SyncVClient:
    """Async API client for the Valentina API.

    This is the main entry point for interacting with the API. It manages
    the HTTP session and provides access to domain-specific services.

    By default, the client automatically registers itself as the default client
    for use with factory functions like `sync_companies_service()`.

    Example:
        ```python
        from vclient import SyncVClient, sync_companies_service

        # Client auto-registers as default
        client = SyncVClient(api_key="...")

        # Use factory functions from any module
        companies = sync_companies_service()
        all_companies = await companies.list_all()

        # Use scoped services
        users = client.users("company_id")
        all_users = await users.list_all()

        campaigns = client.campaigns("company_id", "user_id")
        all_campaigns = await campaigns.list_all()
        ```
    """

    def __init__(
        self,
        base_url: str | None = None,
        api_key: str | None = None,
        *,
        timeout: float = DEFAULT_TIMEOUT,
        max_retries: int = DEFAULT_MAX_RETRIES,
        retry_delay: float = DEFAULT_RETRY_DELAY,
        auto_retry_rate_limit: bool = True,
        auto_idempotency_keys: bool = False,
        retry_statuses: set[int] | frozenset[int] | None = None,
        default_company_id: str | None = None,
        headers: dict[str, str] | None = None,
        set_as_default: bool = True,
    ) -> None:
        """Initialize the API client.

        Values for ``base_url``, ``api_key``, and ``default_company_id`` can be
        provided as constructor arguments or via environment variables. Explicit
        arguments always take precedence over environment variables.

        Environment variables:
            VALENTINA_CLIENT_BASE_URL: Base URL for the API.
            VALENTINA_CLIENT_API_KEY: API key for authentication.
            VALENTINA_CLIENT_DEFAULT_COMPANY_ID: Default company ID.

        Args:
            base_url: Base URL for the API. Falls back to VALENTINA_CLIENT_BASE_URL.
            api_key: API key for authentication. Falls back to VALENTINA_CLIENT_API_KEY.
            timeout: Request timeout in seconds.
            max_retries: Maximum number of retry attempts for failed requests.
            retry_delay: Base delay between retries in seconds.
            auto_retry_rate_limit: Automatically retry requests that hit rate limits.
            auto_idempotency_keys: Automatically generate idempotency keys for
                POST/PUT/PATCH requests.
            retry_statuses: HTTP status codes that trigger automatic retries.
                Defaults to {429, 500, 502, 503, 504}.
            default_company_id: Default company ID to use when not explicitly provided
                to service factory methods. Falls back to
                VALENTINA_CLIENT_DEFAULT_COMPANY_ID.
            headers: Additional headers to include with all requests.
            set_as_default: If True, register this client as the default for factory
                functions. Set to False when creating multiple clients or when using
                the context manager pattern exclusively.

        Raises:
            ValueError: If base_url or api_key is not provided and the corresponding
                environment variable is not set.
        """
        resolved_base_url = base_url or os.environ.get(ENV_BASE_URL)
        if resolved_base_url is None:
            msg = "base_url is required (set it directly or via the VALENTINA_CLIENT_BASE_URL environment variable)"
            raise ValueError(msg)
        resolved_api_key = api_key or os.environ.get(ENV_API_KEY)
        if resolved_api_key is None:
            msg = "api_key is required (set it directly or via the VALENTINA_CLIENT_API_KEY environment variable)"
            raise ValueError(msg)
        resolved_company_id = default_company_id or os.environ.get(ENV_DEFAULT_COMPANY_ID)
        self._config = _APIConfig(
            base_url=resolved_base_url,
            api_key=resolved_api_key,
            timeout=timeout,
            max_retries=max_retries,
            retry_delay=retry_delay,
            auto_retry_rate_limit=auto_retry_rate_limit,
            auto_idempotency_keys=auto_idempotency_keys,
            retry_statuses=frozenset(retry_statuses)
            if retry_statuses is not None
            else DEFAULT_RETRY_STATUSES,
            default_company_id=resolved_company_id,
            headers=headers or {},
        )
        self._http: httpx.Client = self._create_http_client()
        self._companies: SyncCompaniesService | None = None
        self._developer: SyncDeveloperService | None = None
        self._global_admin: SyncGlobalAdminService | None = None
        self._system: SyncSystemService | None = None
        self._user_lookup: SyncUserLookupService | None = None
        if set_as_default:
            from vclient._sync.registry import sync_configure_default_client

            sync_configure_default_client(self)
        logger.bind(
            base_url=self._config.base_url,
            timeout=self._config.timeout,
            max_retries=self._config.max_retries,
        ).info("Initialize SyncVClient")

    def _create_http_client(self) -> httpx.Client:
        """Create and configure the HTTP client."""
        from vclient import __version__

        user_agent = f"vclient/{__version__} Python/{platform.python_version()}"
        headers = {"Accept": "application/json", "User-Agent": user_agent, **self._config.headers}
        if self._config.api_key:
            headers[API_KEY_HEADER] = self._config.api_key
        return httpx.Client(
            base_url=self._config.base_url,
            headers=headers,
            timeout=httpx.Timeout(self._config.timeout),
        )

    def __enter__(self) -> Self:
        """Enter async context manager."""
        return self

    def __exit__(
        self,
        exc_type: type[BaseException] | None,
        exc_val: BaseException | None,
        exc_tb: TracebackType | None,
    ) -> None:
        """Exit async context manager."""
        self.close()

    def close(self) -> None:
        """Close the HTTP client and release resources."""
        from vclient._sync.registry import sync_clear_default_client

        logger.bind(base_url=self._config.base_url).info("Close SyncVClient")
        self._http.close()
        sync_clear_default_client(self)

    @property
    def is_closed(self) -> bool:
        """Check if the client has been closed."""
        return self._http.is_closed

    @property
    def default_company_id(self) -> str | None:
        """Return the default company ID from config."""
        return self._config.default_company_id

    def _resolve_company_id(self, company_id: str | None) -> str:
        """Resolve company_id, falling back to default if not provided.

        Args:
            company_id: Explicitly provided company ID, or None to use default.

        Returns:
            The resolved company ID.

        Raises:
            ValueError: If no company_id provided and no default configured.
        """
        resolved = company_id or self._config.default_company_id
        if resolved is None:
            msg = "company_id is required (no default_company_id configured)"
            raise ValueError(msg)
        return resolved

    @property
    def companies(self) -> "SyncCompaniesService":
        """Access the Companies service for managing companies.

        Returns:
            The SyncCompaniesService instance for company operations.
        """
        if self._companies is None:
            from vclient._sync.services.companies import SyncCompaniesService

            self._companies = SyncCompaniesService(self)
        return self._companies

    @property
    def developer(self) -> "SyncDeveloperService":
        """Access the Developer service for managing your own profile.

        Provides methods to view and update your developer account,
        as well as regenerate your API key.

        Returns:
            The SyncDeveloperService instance for self-service operations.
        """
        if self._developer is None:
            from vclient._sync.services.developers import SyncDeveloperService

            self._developer = SyncDeveloperService(self)
        return self._developer

    @property
    def global_admin(self) -> "SyncGlobalAdminService":
        """Access the Global Admin service for managing developers.

        Requires global admin privileges. Operations will fail with AuthorizationError
        if the authenticated developer does not have global admin status.

        Returns:
            The SyncGlobalAdminService instance for developer management operations.
        """
        if self._global_admin is None:
            from vclient._sync.services.global_admin import SyncGlobalAdminService

            self._global_admin = SyncGlobalAdminService(self)
        return self._global_admin

    @property
    def system(self) -> "SyncSystemService":
        """Access the System service for system-level operations.

        Returns:
            The SyncSystemService instance for system operations like health checks.
        """
        if self._system is None:
            from vclient._sync.services.system import SyncSystemService

            self._system = SyncSystemService(self)
        return self._system

    @property
    def user_lookup(self) -> "SyncUserLookupService":
        """Access the User Lookup service for cross-company user discovery.

        Returns:
            The SyncUserLookupService instance for user lookup operations.
        """
        if self._user_lookup is None:
            from vclient._sync.services.user_lookup import SyncUserLookupService

            self._user_lookup = SyncUserLookupService(self)
        return self._user_lookup

    def users(self, on_behalf_of: str, *, company_id: str | None = None) -> "SyncUsersService":
        """Get a SyncUsersService scoped to a specific company.

        Provides methods to create, retrieve, update, and delete users,
        as well as access user statistics and assets.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Returns:
            A SyncUsersService instance scoped to the specified company.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> users = client.users("user_id", "company_id")
            >>> all_users = await users.list_all()
            >>> user = await users.get("user_id")
        """
        from vclient._sync.services.users import SyncUsersService

        return SyncUsersService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def user_self_registration(
        self, *, company_id: str | None = None
    ) -> "SyncUserSelfRegistrationService":
        """Get a SyncUserSelfRegistrationService scoped to a specific company.

        Handles user self-registration via SSO onboarding. Does not require
        an acting user — only developer API key authentication.

        Args:
            company_id: The ID of the company to register users in. If not
                provided, uses the default_company_id from config.

        Returns:
            A SyncUserSelfRegistrationService instance.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> registration = client.user_self_registration()
            >>> user = await registration.register(username="alice", email="a@b.com")
        """
        from vclient._sync.services.user_self_registration import SyncUserSelfRegistrationService

        return SyncUserSelfRegistrationService(self, self._resolve_company_id(company_id))

    def campaigns(
        self, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncCampaignsService":
        """Get a SyncCampaignsService scoped to a specific company.

        Provides methods to create, retrieve, update, and delete campaigns,
        as well as access campaign statistics, assets, and notes.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Returns:
            A SyncCampaignsService instance scoped to the specified company.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> campaigns = client.campaigns("user_id")
            >>> all_campaigns = await campaigns.list_all()
            >>> campaign = await campaigns.get("campaign_id")
        """
        from vclient._sync.services.campaigns import SyncCampaignsService

        return SyncCampaignsService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def books(
        self, campaign_id: str, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncBooksService":
        """Get a SyncBooksService scoped to a specific company and campaign.

        Provides methods to create, retrieve, update, and delete campaign books,
        as well as access book notes and assets.

        Args:
            campaign_id: The ID of the campaign to operate within.
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Returns:
            A SyncBooksService instance scoped to the specified context.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> books = client.books("campaign_id", "user_id")
            >>> all_books = await books.list_all()
            >>> book = await books.get("book_id")
        """
        from vclient._sync.services.campaign_books import SyncBooksService

        return SyncBooksService(
            self,
            company_id=self._resolve_company_id(company_id),
            campaign_id=campaign_id,
            on_behalf_of=on_behalf_of,
        )

    def chapters(
        self, campaign_id: str, book_id: str, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncChaptersService":
        """Get a SyncChaptersService scoped to a specific company, campaign, and book.

        Provides methods to create, retrieve, update, and delete campaign book chapters,
        as well as access chapter notes and assets.

        Args:
            campaign_id: The ID of the campaign to operate within.
            book_id: The ID of the book to operate within.
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Returns:
            A SyncChaptersService instance scoped to the specified context.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> chapters = client.chapters("campaign_id", "book_id", "user_id")
            >>> all_chapters = await chapters.list_all()
            >>> chapter = await chapters.get("chapter_id")
        """
        from vclient._sync.services.campaign_book_chapters import SyncChaptersService

        return SyncChaptersService(
            self,
            company_id=self._resolve_company_id(company_id),
            campaign_id=campaign_id,
            book_id=book_id,
            on_behalf_of=on_behalf_of,
        )

    def characters(
        self, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncCharactersService":
        """Get a SyncCharactersService scoped to a specific company.

        Provides methods to create, retrieve, update, and delete characters.
        Use the optional ``campaign_id`` filter on list methods to scope to a campaign.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Returns:
            A SyncCharactersService instance scoped to the specified context.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> characters = client.characters("user_id")
            >>> all_characters = await characters.list_all()
            >>> character = await characters.get("character_id")
        """
        from vclient._sync.services.characters import SyncCharactersService

        return SyncCharactersService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def character_traits(
        self, character_id: str, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncCharacterTraitsService":
        """Get a SyncCharacterTraitsService scoped to a specific company and character.

        Provides methods to create, retrieve, update, and delete character traits within
        a character.

        Args:
            character_id: The ID of the character to operate within.
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Returns:
            A SyncCharacterTraitsService instance scoped to the specified context.

        Raises:
            ValueError: If no company_id provided and no default configured.

        Example:
            >>> character_traits = client.character_traits("character_id", "user_id")
            >>> all_character_traits = await character_traits.list_all()
            >>> character_trait = await character_traits.get("character_trait_id")
        """
        from vclient._sync.services.character_traits import SyncCharacterTraitsService

        return SyncCharacterTraitsService(
            self,
            company_id=self._resolve_company_id(company_id),
            character_id=character_id,
            on_behalf_of=on_behalf_of,
        )

    def character_blueprint(
        self, on_behalf_of: str | None = None, *, company_id: str | None = None
    ) -> "SyncCharacterBlueprintService":
        """Get a SyncCharacterBlueprintService scoped to a specific company.

        Provides methods to create, retrieve, update, and delete character blueprint sections,
        categories, and traits.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Raises:
            ValueError: If no company_id provided and no default configured.
        """
        from vclient._sync.services.character_blueprint import SyncCharacterBlueprintService

        return SyncCharacterBlueprintService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def dictionary(
        self, on_behalf_of: str | None = None, *, company_id: str | None = None
    ) -> "SyncDictionaryService":
        """Get a SyncDictionaryService scoped to a specific company.

        Provides methods to create, retrieve, update, and delete dictionary terms.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Raises:
            ValueError: If no company_id provided and no default configured.
        """
        from vclient._sync.services.dictionary import SyncDictionaryService

        return SyncDictionaryService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def dicerolls(
        self, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncDicerollService":
        """Get a SyncDicerollService scoped to a specific company.

        Provides methods to create, retrieve, and list dice rolls.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Raises:
            ValueError: If no company_id provided and no default configured.
        """
        from vclient._sync.services.dicerolls import SyncDicerollService

        return SyncDicerollService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def options(
        self, on_behalf_of: str | None = None, *, company_id: str | None = None
    ) -> "SyncOptionsService":
        """Get a SyncOptionsService scoped to a specific company.

        Provides methods to retrieve all options and enumerations for the api.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Raises:
            ValueError: If no company_id provided and no default configured.
        """
        from vclient._sync.services.options import SyncOptionsService

        return SyncOptionsService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )

    def character_autogen(
        self, on_behalf_of: str, *, company_id: str | None = None
    ) -> "SyncCharacterAutogenService":
        """Get a SyncCharacterAutogenService scoped to a specific company.

        Provides methods to autogenerate characters and manage chargen sessions.
        Pass ``campaign_id`` directly to ``generate_character()`` and
        ``start_chargen_session()`` to scope each call to a specific campaign.

        Args:
            on_behalf_of: User ID to impersonate via On-Behalf-Of header.
            company_id: The ID of the company to operate within. If not provided,
                uses the default_company_id from config.

        Raises:
            ValueError: If no company_id provided and no default configured.
        """
        from vclient._sync.services.character_autogen import SyncCharacterAutogenService

        return SyncCharacterAutogenService(
            self, company_id=self._resolve_company_id(company_id), on_behalf_of=on_behalf_of
        )
