from __future__ import annotations

from pathlib import Path

import typer
from typer.testing import CliRunner

from pdf_joiner.cli import join

app = typer.Typer()
app.command()(join)

runner = CliRunner()


class TestCliHelp:
    def test_help(self) -> None:
        result = runner.invoke(app, ["--help"])
        assert result.exit_code == 0
        assert "--output" in result.output
        assert "--sort" in result.output
        assert "--reverse" in result.output


class TestCliJoin:
    def test_join_single_file(self, tmp_pdf: Path) -> None:
        output = tmp_pdf.parent / "output.pdf"
        result = runner.invoke(app, [str(tmp_pdf), "-o", str(output)])
        assert result.exit_code == 0
        assert output.exists()
        assert "PDF generated" in result.output

    def test_join_multiple_files(self, multi_pdfs: list[Path]) -> None:
        output = multi_pdfs[0].parent / "output.pdf"
        args = [str(p) for p in multi_pdfs] + ["-o", str(output)]
        result = runner.invoke(app, args)
        assert result.exit_code == 0
        assert output.exists()
        assert "Files merged: 3" in result.output

    def test_join_directory(self, pdf_dir: Path) -> None:
        output = pdf_dir.parent / "output.pdf"
        result = runner.invoke(app, [str(pdf_dir), "-o", str(output)])
        assert result.exit_code == 0
        assert output.exists()
        assert "Files merged: 3" in result.output

    def test_join_with_sort_name(self, multi_pdfs: list[Path]) -> None:
        output = multi_pdfs[0].parent / "output.pdf"
        args = [str(p) for p in multi_pdfs] + ["-o", str(output), "--sort", "name"]
        result = runner.invoke(app, args)
        assert result.exit_code == 0
        assert "Applied sort: name" in result.output

    def test_join_with_sort_natural(self, multi_pdfs_natural: list[Path]) -> None:
        output = multi_pdfs_natural[0].parent / "output.pdf"
        args = [str(p) for p in multi_pdfs_natural] + ["-o", str(output), "--sort", "natural"]
        result = runner.invoke(app, args)
        assert result.exit_code == 0
        assert "Applied sort: natural" in result.output

    def test_join_with_reverse(self, multi_pdfs: list[Path]) -> None:
        output = multi_pdfs[0].parent / "output.pdf"
        args = [str(p) for p in multi_pdfs] + ["-o", str(output), "--reverse"]
        result = runner.invoke(app, args)
        assert result.exit_code == 0

    def test_join_default_output(self, tmp_pdf: Path, tmp_path: Path) -> None:
        import os
        os.chdir(tmp_path)
        result = runner.invoke(app, [str(tmp_pdf)])
        assert result.exit_code == 0
        assert (tmp_path / "merged.pdf").exists()


class TestCliErrors:
    def test_nonexistent_file(self, tmp_path: Path) -> None:
        result = runner.invoke(app, [str(tmp_path / "nonexistent.pdf")])
        assert result.exit_code != 0

    def test_invalid_output_extension(self, tmp_pdf: Path, tmp_path: Path) -> None:
        result = runner.invoke(app, [str(tmp_pdf), "-o", str(tmp_path / "out.txt")])
        assert result.exit_code != 0
        assert ".pdf" in result.output.lower()

    def test_output_is_input(self, multi_pdfs: list[Path]) -> None:
        output = multi_pdfs[0]
        args = [str(p) for p in multi_pdfs] + ["-o", str(output)]
        result = runner.invoke(app, args)
        assert result.exit_code != 0
        assert "output" in result.output.lower()

    def test_no_inputs(self) -> None:
        result = runner.invoke(app, [])
        assert result.exit_code != 0

    def test_non_pdf_file(self, tmp_path: Path) -> None:
        txt = tmp_path / "note.txt"
        txt.write_text("hello")
        result = runner.invoke(app, [str(txt)])
        assert result.exit_code != 0
