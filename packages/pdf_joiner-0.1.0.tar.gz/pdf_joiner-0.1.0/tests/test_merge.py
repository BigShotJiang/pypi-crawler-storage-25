from __future__ import annotations

import re
from pathlib import Path

import pytest
from pypdf import PdfReader, PdfWriter

from pdf_joiner.merge import (
    SortMode,
    choose_default_sort,
    filter_output_path,
    merge_pdfs,
    natural_sort_key,
    resolve_input_files,
    sort_pdf_files,
    unique_paths,
)


class TestResolveInputFiles:
    def test_single_pdf(self, tmp_pdf: Path) -> None:
        result = resolve_input_files([tmp_pdf])
        assert len(result) == 1
        assert result[0].resolve() == tmp_pdf.resolve()

    def test_multiple_pdfs(self, multi_pdfs: list[Path]) -> None:
        result = resolve_input_files(multi_pdfs)
        assert len(result) == 3

    def test_directory_with_pdfs(self, pdf_dir: Path) -> None:
        result = resolve_input_files([pdf_dir])
        assert len(result) == 3
        for pdf in result:
            assert pdf.suffix.lower() == ".pdf"

    def test_mixed_files_and_dirs(self, tmp_pdf: Path, pdf_dir: Path) -> None:
        result = resolve_input_files([tmp_pdf, pdf_dir])
        assert len(result) == 4

    def test_nonexistent_path(self, tmp_path: Path) -> None:
        with pytest.raises(FileNotFoundError, match="does not exist"):
            resolve_input_files([tmp_path / "nonexistent.pdf"])

    def test_non_pdf_file(self, tmp_path: Path) -> None:
        txt = tmp_path / "note.txt"
        txt.write_text("hello")
        with pytest.raises(ValueError, match="not a PDF"):
            resolve_input_files([txt])

    def test_empty_directory(self, empty_dir: Path) -> None:
        with pytest.raises(ValueError, match="contains no PDFs"):
            resolve_input_files([empty_dir])

    def test_deduplication(self, tmp_pdf: Path) -> None:
        result = resolve_input_files([tmp_pdf, tmp_pdf, tmp_pdf])
        assert len(result) == 1

    def test_directory_and_file_same_pdf(self, tmp_pdf: Path) -> None:
        pdf_dir = tmp_pdf.parent
        result = resolve_input_files([tmp_pdf, pdf_dir])
        assert len(result) == 1


class TestUniquePaths:
    def test_no_duplicates(self, multi_pdfs: list[Path]) -> None:
        result = unique_paths(multi_pdfs)
        assert len(result) == 3

    def test_with_duplicates(self, multi_pdfs: list[Path]) -> None:
        duplicated = multi_pdfs + multi_pdfs
        result = unique_paths(duplicated)
        assert len(result) == 3

    def test_empty(self) -> None:
        assert unique_paths([]) == []

    def test_preserves_order(self, multi_pdfs: list[Path]) -> None:
        result = unique_paths(multi_pdfs)
        assert result == [p.resolve() for p in multi_pdfs]


class TestChooseDefaultSort:
    def test_files_default_none(self, multi_pdfs: list[Path]) -> None:
        assert choose_default_sort(multi_pdfs) == SortMode.NONE

    def test_dir_default_natural(self, pdf_dir: Path) -> None:
        assert choose_default_sort([pdf_dir]) == SortMode.NATURAL

    def test_mixed_default_natural(self, tmp_pdf: Path, pdf_dir: Path) -> None:
        assert choose_default_sort([tmp_pdf, pdf_dir]) == SortMode.NATURAL

    def test_empty_input(self) -> None:
        assert choose_default_sort([]) == SortMode.NONE


class TestSortPdfFiles:
    def test_no_sort(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.NONE)
        assert result == list(multi_pdfs)

    def test_no_sort_reverse(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.NONE, reverse=True)
        assert result == list(reversed(multi_pdfs))

    def test_sort_name(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.NAME)
        names = [p.name for p in result]
        assert names == sorted(names, key=str.lower)

    def test_sort_name_reverse(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.NAME, reverse=True)
        names = [p.name for p in result]
        assert names == sorted(names, key=str.lower, reverse=True)

    def test_sort_natural(self, multi_pdfs_natural: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs_natural, SortMode.NATURAL)
        names = [p.stem for p in result]
        expected_nums = [1, 2, 10, 20]
        actual_nums = [int(re.sub(r"doc", "", name)) for name in names]
        assert actual_nums == expected_nums

    def test_sort_natural_reverse(self, multi_pdfs_natural: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs_natural, SortMode.NATURAL, reverse=True)
        names = [p.stem for p in result]
        actual_nums = [int(re.sub(r"doc", "", name)) for name in names]
        assert actual_nums == [20, 10, 2, 1]

    def test_sort_mtime(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.MTIME)
        assert len(result) == 3

    def test_sort_mtime_reverse(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.MTIME, reverse=True)
        assert len(result) == 3

    def test_sort_ctime(self, multi_pdfs: list[Path]) -> None:
        result = sort_pdf_files(multi_pdfs, SortMode.CTIME)
        assert len(result) == 3

    def test_invalid_sort_mode(self, multi_pdfs: list[Path]) -> None:
        with pytest.raises(ValueError, match="not supported"):
            sort_pdf_files(multi_pdfs, "invalid")  # type: ignore[arg-type]


class TestNaturalSortKey:
    def test_simple_string(self) -> None:
        assert natural_sort_key("abc") == ["abc"]

    def test_numbers_split(self) -> None:
        key = natural_sort_key("file10doc")
        assert key == ["file", 10, "doc"]

    def test_natural_ordering(self) -> None:
        items = ["file10.pdf", "file2.pdf", "file1.pdf", "file20.pdf"]
        sorted_items = sorted(items, key=natural_sort_key)
        assert sorted_items == ["file1.pdf", "file2.pdf", "file10.pdf", "file20.pdf"]

    def test_case_insensitive(self) -> None:
        items = ["B.pdf", "a.pdf", "C.pdf"]
        sorted_items = sorted(items, key=natural_sort_key)
        assert sorted_items == ["a.pdf", "B.pdf", "C.pdf"]

    def test_mixed_numbers(self) -> None:
        result = natural_sort_key("v1.2.3")
        assert result[:5] == ["v", 1, ".", 2, "."]
        assert result[5] == 3


class TestFilterOutputPath:
    def test_output_not_in_inputs(self, multi_pdfs: list[Path], tmp_path: Path) -> None:
        output = tmp_path / "output.pdf"
        result = filter_output_path(multi_pdfs, output)
        assert len(result) == 3

    def test_output_in_inputs(self, multi_pdfs: list[Path]) -> None:
        output = multi_pdfs[0]
        result = filter_output_path(multi_pdfs, output)
        assert len(result) == 2
        assert output.resolve() not in result

    def test_output_not_present(self, multi_pdfs: list[Path], tmp_path: Path) -> None:
        output = tmp_path / "completely_different.pdf"
        result = filter_output_path(multi_pdfs, output)
        assert result == list(multi_pdfs)


class TestMergePdfs:
    def test_merge_two_pdfs(self, tmp_pdf: Path, tmp_path: Path) -> None:
        pdf2 = tmp_path / "second.pdf"
        writer = PdfWriter()
        writer.add_blank_page(width=200, height=200)
        with open(pdf2, "wb") as f:
            writer.write(f)

        output = tmp_path / "merged.pdf"
        result = merge_pdfs([tmp_pdf, pdf2], output)
        assert result.resolve() == output.resolve()

        reader = PdfReader(str(result))
        assert len(reader.pages) == 2

    def test_merge_creates_parent_dirs(self, tmp_pdf: Path, tmp_path: Path) -> None:
        output = tmp_path / "nested" / "deep" / "merged.pdf"
        merge_pdfs([tmp_pdf], output)
        assert output.exists()

    def test_merge_empty_list(self, tmp_path: Path) -> None:
        with pytest.raises(ValueError, match="No PDFs"):
            merge_pdfs([], tmp_path / "out.pdf")

    def test_merge_single_pdf(self, tmp_pdf: Path, tmp_path: Path) -> None:
        output = tmp_path / "out.pdf"
        result = merge_pdfs([tmp_pdf], output)
        reader = PdfReader(str(result))
        assert len(reader.pages) == 1

    def test_merge_three_pdfs(self, multi_pdfs: list[Path], tmp_path: Path) -> None:
        output = tmp_path / "out.pdf"
        merge_pdfs(multi_pdfs, output)
        reader = PdfReader(str(output))
        assert len(reader.pages) == 3
