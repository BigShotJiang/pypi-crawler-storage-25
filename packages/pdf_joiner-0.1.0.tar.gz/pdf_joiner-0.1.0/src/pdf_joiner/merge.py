from __future__ import annotations

import re
from enum import Enum
from pathlib import Path
from typing import Iterable

from pypdf import PdfWriter


class SortMode(str, Enum):
    NONE = "none"
    NAME = "name"
    NATURAL = "natural"
    MTIME = "mtime"
    CTIME = "ctime"


def resolve_input_files(inputs: Iterable[Path]) -> list[Path]:
    resolved_files: list[Path] = []

    for raw_path in inputs:
        path = raw_path.expanduser()

        if not path.exists():
            raise FileNotFoundError(f"Path does not exist: {path}")

        if path.is_file():
            if path.suffix.lower() != ".pdf":
                raise ValueError(f"File is not a PDF: {path}")
            resolved_files.append(path.resolve())
            continue

        if path.is_dir():
            pdfs_in_dir = [
                child.resolve()
                for child in path.iterdir()
                if child.is_file() and child.suffix.lower() == ".pdf"
            ]
            if not pdfs_in_dir:
                raise ValueError(f"Directory contains no PDFs: {path}")
            resolved_files.extend(pdfs_in_dir)
            continue

        raise ValueError(f"Unsupported path: {path}")

    return unique_paths(resolved_files)


def unique_paths(paths: Iterable[Path]) -> list[Path]:
    seen: set[Path] = set()
    unique: list[Path] = []

    for path in paths:
        resolved = path.resolve()
        if resolved in seen:
            continue
        seen.add(resolved)
        unique.append(resolved)

    return unique


def choose_default_sort(inputs: Iterable[Path]) -> SortMode:
    for path in inputs:
        if path.expanduser().is_dir():
            return SortMode.NATURAL
    return SortMode.NONE


def sort_pdf_files(
    pdf_files: Iterable[Path],
    sort_mode: SortMode,
    reverse: bool = False,
) -> list[Path]:
    pdf_list = list(pdf_files)

    if sort_mode == SortMode.NONE:
        return list(reversed(pdf_list)) if reverse else pdf_list

    if sort_mode == SortMode.NAME:
        key = lambda item: item.name.lower()
    elif sort_mode == SortMode.NATURAL:
        key = lambda item: natural_sort_key(item.name)
    elif sort_mode == SortMode.MTIME:
        key = lambda item: (item.stat().st_mtime, natural_sort_key(item.name))
    elif sort_mode == SortMode.CTIME:
        key = lambda item: (item.stat().st_ctime, natural_sort_key(item.name))
    else:
        raise ValueError(f"Unsupported sort mode: {sort_mode}")

    return sorted(pdf_list, key=key, reverse=reverse)


def natural_sort_key(value: str) -> list[int | str]:
    parts = re.split(r"(\d+)", value.lower())
    return [int(part) if part.isdigit() else part for part in parts]


def filter_output_path(pdf_files: Iterable[Path], output_path: Path) -> list[Path]:
    resolved_output = output_path.expanduser().resolve()
    return [path for path in pdf_files if path.resolve() != resolved_output]


def merge_pdfs(pdf_files: Iterable[Path], output_path: Path) -> Path:
    files = list(pdf_files)
    if not files:
        raise ValueError("No PDFs to merge.")

    output = output_path.expanduser()
    output.parent.mkdir(parents=True, exist_ok=True)

    writer = PdfWriter()
    try:
        for pdf_file in files:
            writer.append(str(pdf_file))

        with output.open("wb") as file_handle:
            writer.write(file_handle)
    finally:
        writer.close()

    return output.resolve()
