from __future__ import annotations

from pathlib import Path
from typing import Annotated, Optional

import typer

from pdf_joiner.merge import (
    SortMode,
    choose_default_sort,
    filter_output_path,
    merge_pdfs,
    resolve_input_files,
    sort_pdf_files,
)


def join(
    inputs: Annotated[
        list[Path],
        typer.Argument(
            ...,
            exists=True,
            readable=True,
            resolve_path=False,
            help="PDF files or folders containing PDFs.",
        ),
    ],
    output: Annotated[
        Path,
        typer.Option(
            "--output",
            "-o",
            help="Path for the final output PDF.",
        ),
    ] = Path("merged.pdf"),
    sort_by: Annotated[
        Optional[SortMode],
        typer.Option(
            "--sort",
            help="Sort order: none, name, natural, mtime or ctime.",
            case_sensitive=False,
        ),
    ] = None,
    reverse: Annotated[
        bool,
        typer.Option(
            "--reverse",
            help="Reverse the selected sort order.",
        ),
    ] = False,
) -> None:
    """Merge PDFs from individual files or folders."""
    try:
        if output.suffix and output.suffix.lower() != ".pdf":
            raise typer.BadParameter("Output file must have a .pdf extension.")

        pdf_files = resolve_input_files(inputs)

        resolved_output = output.expanduser().resolve()
        if resolved_output in {path.resolve() for path in pdf_files}:
            raise typer.BadParameter(
                "Output file cannot be part of the input."
            )

        effective_sort = sort_by or choose_default_sort(inputs)
        ordered_files = sort_pdf_files(pdf_files, effective_sort, reverse=reverse)
        final_files = filter_output_path(ordered_files, output)

        if not final_files:
            raise typer.BadParameter("No valid PDFs left to merge.")

        result_path = merge_pdfs(final_files, output)

        typer.echo(f"PDF generated: {result_path}")
        typer.echo(f"Files merged: {len(final_files)}")
        typer.echo(f"Applied sort: {effective_sort.value}")
    except (FileNotFoundError, ValueError) as exc:
        raise typer.BadParameter(str(exc)) from exc


def run() -> None:
    typer.run(join)
