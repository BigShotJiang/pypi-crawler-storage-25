"""Notifier Thread."""
