"""Comic cover operations."""
