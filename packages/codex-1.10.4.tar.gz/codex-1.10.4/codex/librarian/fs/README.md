# File System Watcher & Poller

Filesystem watching for Codex libraries using
[watchfiles](https://github.com/samuelcolvin/watchfiles) (Rust `notify`
backend).

## Architecture

- **`watcher`** — A single thread watches all event-enabled library paths using
  `watchfiles.watch()`. Multiple paths go into one `watch()` call, so N
  libraries = 1 watcher thread. When library config changes, the watch is
  restarted with updated paths.

- **`poller`** — Periodically compares database snapshots against disk snapshots
  to detect changes that filesystem events might miss (e.g. network mounts,
  Docker volumes).

- **`event_batcherd.py`** — `WatcherEventBatcherThread`: Aggregates events from
  both the watcher and poller into batched `ImportTask` instances for the
  importer.
