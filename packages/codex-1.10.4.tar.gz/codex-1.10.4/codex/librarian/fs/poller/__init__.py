"""Codex Filesystem Poller."""
