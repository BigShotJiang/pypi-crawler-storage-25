"""Codex restarter."""
