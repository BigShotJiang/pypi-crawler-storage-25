"""Special Redirect Error."""

from collections.abc import Iterable, Mapping, MutableMapping
from copy import deepcopy
from pprint import pformat

from caseconverter import camelcase
from django.core.validators import EMPTY_VALUES
from django.http.response import HttpResponseRedirect
from django.shortcuts import redirect
from django.urls import reverse
from loguru import logger
from rest_framework.exceptions import APIException
from rest_framework.status import HTTP_303_SEE_OTHER

from codex.choices.browser import DEFAULT_BROWSER_ROUTE
from codex.serializers.route import RouteSerializer
from codex.views.util import pop_name

_OPDS_REDIRECT_SETTINGS_SNAKE_CASE_KEYS = {
    "filter",
    "top_group",
    "order_by",
    "order_reverse",
}
_OPDS_REDIRECT_SETTINGS_KEYS = tuple(
    sorted(
        _OPDS_REDIRECT_SETTINGS_SNAKE_CASE_KEYS
        | {camelcase(key) for key in _OPDS_REDIRECT_SETTINGS_SNAKE_CASE_KEYS}
    )
)
_REDIRECT_SETTINGS_KEYS = _OPDS_REDIRECT_SETTINGS_KEYS


class SeeOtherRedirectError(APIException):
    """Redirect for 303."""

    status_code = HTTP_303_SEE_OTHER
    default_code = "redirect"
    default_detail = "redirect to a valid route"

    @staticmethod
    def _copy_params_into(
        params: Mapping, keys: Iterable[str], final_params: MutableMapping
    ) -> None:
        """Copy and filter params into another map as camelcase."""
        for key in keys:
            value = params.get(key)
            if value in EMPTY_VALUES:
                continue
            final_params[camelcase(key)] = value

    def __init__(self, detail) -> None:
        """Create a response to pass to the exception handler."""
        super().__init__(detail)
        # Copy to edit and not write over refs
        detail = dict(detail)

        # Get route params
        route = detail.get("route", {})
        params = route.get("params", DEFAULT_BROWSER_ROUTE)
        params = pop_name(params)
        route = deepcopy(route)
        route["params"] = params

        # For OPDS
        self.route_kwargs = params

        serializer = RouteSerializer(params)
        route["params"] = serializer.data
        detail["route"] = route

        settings = detail.get("settings", {})
        filtered_settings = {}
        self._copy_params_into(settings, _REDIRECT_SETTINGS_KEYS, filtered_settings)
        detail["settings"] = filtered_settings

        self.detail = detail

        logger.debug(f"redirect {pformat(self.detail)}")

    def _get_query_params(self) -> dict:
        """Change OPDS settings like the frontend does with error.detail."""
        settings = (
            self.detail.get("settings", {}) if isinstance(self.detail, Mapping) else {}  # ty: ignore[no-matching-overload]
        )
        query_params = {}
        self._copy_params_into(settings, _OPDS_REDIRECT_SETTINGS_KEYS, query_params)
        return query_params

    def get_response(self, url_name) -> HttpResponseRedirect:
        """Return a Django Redirect Response."""
        # only used in codex_exception_handler for opds stuff
        query = self._get_query_params()
        url = reverse(url_name, kwargs=dict(self.route_kwargs), query=query)
        return redirect(url, permanent=False)


class NoContent(APIException):
    """Provide a 204 response."""
