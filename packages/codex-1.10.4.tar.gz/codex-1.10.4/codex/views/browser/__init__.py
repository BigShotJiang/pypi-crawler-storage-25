"""Browser views."""
