"""Browser annotation methods."""
