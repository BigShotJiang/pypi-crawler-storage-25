"""Browser filter mixins."""
