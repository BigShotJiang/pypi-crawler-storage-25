"""OpenSearch Views."""
