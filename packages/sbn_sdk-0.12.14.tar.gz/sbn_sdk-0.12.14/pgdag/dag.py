"""
PGDAGRunner — The proof-gated DAG execution engine.

Orchestrates template execution: slot management, step sequencing,
proof collection, interruption handling, and slot closure.

Supports two DAG models:
  - Linear: steps run in declared order (simple, most templates)
  - Topological: steps run based on dependency graph (parallel branches)

The runner is product-agnostic.  Products provide:
  - DAGTemplate (step sequence or dependency graph)
  - StepFn implementations (the business logic)
  - Domain/frontier configuration

The kernel provides:
  - Slot open/close via SBN Gateway
  - Step sequencing with interruption checks
  - Proof collection + Merkle root computation
  - RunResult with full proof chain
"""

from __future__ import annotations

import asyncio
import inspect
import logging
import uuid
from dataclasses import dataclass, field
from datetime import datetime, timezone
from typing import Any, Awaitable, Callable, Dict, List, Mapping, Optional, Sequence, Set

from .artifact import ProofArtifact, ProofStatus, canonical_fingerprint, merkle_root
from .envelope import StepEnvelopeBuilder
from .gate import IdempotencyGate
from .interrupt import InterruptionHandler
from .reducer import Reducer, ReducerStatus, RunState
from .runner import ProofWriter, StepContext, StepFn, StepRunner

logger = logging.getLogger(__name__)


# ---------------------------------------------------------------------------
# WaitForEvent — pause DAG execution for external events
# ---------------------------------------------------------------------------

class WaitForEvent(Exception):
    """Raised by a step function to pause the DAG until an external event arrives.

    When a step raises this, the runner treats the node as *not failed* but
    *not completed* — the RunResult will carry ``waiting=True`` so the caller
    can persist the waiting state and an event bridge can resume the run later.

    Attributes:
        event_type: The event bus topic to wait for (e.g. "slot.completed").
        event_key:  An identifier the bridge uses to match the event
                    (e.g. the slot_id that must complete).
        node_id:    Populated automatically by the runner — the step that is waiting.
        partial_outputs: Any outputs the step wants merged before pausing.
    """

    def __init__(
        self,
        event_type: str,
        event_key: str,
        partial_outputs: Dict[str, Any] | None = None,
    ) -> None:
        self.event_type = event_type
        self.event_key = event_key
        self.node_id = ""  # set by the runner
        self.partial_outputs = partial_outputs or {}
        super().__init__(f"Waiting for {event_type} key={event_key}")


# ---------------------------------------------------------------------------
# DAG template definitions
# ---------------------------------------------------------------------------

@dataclass
class DAGNode:
    """A node in a DAG template.

    For linear templates, nodes are executed in list order.
    For topological templates, edges determine execution order.
    """
    id: str
    label: str = ""
    step_type: str = ""  # "ingestion" | "validation" | "computation" | "execution" | etc.
    metadata: Dict[str, Any] = field(default_factory=dict)


@dataclass
class DAGEdge:
    """A directed edge in a DAG template.

    edge_type:
      - "sequence": source must complete before target starts
      - "fork": source fans out to multiple targets (parallel)
      - "join": multiple sources must complete before target starts

    The ``condition`` parameter is a backward-compatible alias for
    ``edge_type`` (used by Grid templates).
    """
    source: str
    target: str
    edge_type: str = "sequence"
    condition: str | None = None

    def __post_init__(self) -> None:
        if self.condition and self.edge_type == "sequence":
            self.edge_type = self.condition


@dataclass
class DAGTemplate:
    """A reusable workflow definition for PG-DAG execution.

    Products register templates with their step sequences.
    The PGDAGRunner executes templates by looking up registered StepFns.

    Two modes:
      - Linear: just nodes, executed in list order (no edges needed)
      - Topological: nodes + edges, executed by dependency resolution
    """
    name: str
    version: str = "1.0"
    nodes: List[DAGNode] = field(default_factory=list)
    edges: List[DAGEdge] = field(default_factory=list)
    domain: str = "general"
    metadata: Dict[str, Any] = field(default_factory=dict)

    @property
    def node_ids(self) -> List[str]:
        return [n.id for n in self.nodes]

    @property
    def is_linear(self) -> bool:
        """True if no edges defined — execute nodes in list order."""
        return len(self.edges) == 0

    def dependency_map(self) -> Dict[str, Set[str]]:
        """Build a map of node_id → set of prerequisite node_ids."""
        deps: Dict[str, Set[str]] = {n.id: set() for n in self.nodes}
        for edge in self.edges:
            if edge.target in deps:
                deps[edge.target].add(edge.source)
        return deps

    def ready_steps(self, completed: Set[str]) -> List[str]:
        """Return steps whose dependencies are all satisfied."""
        if self.is_linear:
            # Linear: return next uncompleted step
            for nid in self.node_ids:
                if nid not in completed:
                    return [nid]
            return []
        # Topological: return all steps with satisfied dependencies
        deps = self.dependency_map()
        ready = []
        for nid in self.node_ids:
            if nid not in completed and deps[nid].issubset(completed):
                ready.append(nid)
        return ready


# ---------------------------------------------------------------------------
# Node result (Grid-compatible per-step result shape)
# ---------------------------------------------------------------------------

@dataclass
class NodeResult:
    """Execution result for a single DAG node.

    Grid compatibility layer — maps proof artifacts to the simple
    success/outputs/error shape that Grid's _persist_dag_result expects.
    """
    node_id: str
    success: bool = False
    outputs: Dict[str, Any] = field(default_factory=dict)
    error: Optional[str] = None
    duration_ms: float = 0.0


# ---------------------------------------------------------------------------
# Run result
# ---------------------------------------------------------------------------

@dataclass
class RunResult:
    """Complete result of a DAG template execution."""
    run_id: str
    template_name: str
    status: ReducerStatus
    proofs: Dict[str, ProofArtifact]
    merkle_root_hash: str
    slot_id: Optional[str] = None
    slot_receipt_id: Optional[str] = None
    started_at: datetime = field(default_factory=lambda: datetime.now(timezone.utc))
    completed_at: Optional[datetime] = None
    # WaitForEvent support
    waiting: bool = False
    wait_event: Optional[WaitForEvent] = None
    final_outputs: Dict[str, Any] = field(default_factory=dict)
    duration_ms: float = 0.0

    @property
    def success(self) -> bool:
        """True if all expected steps completed successfully."""
        return self.status == ReducerStatus.COMPLETE

    @property
    def node_results(self) -> Dict[str, NodeResult]:
        """Convert proof chain to Grid-compatible NodeResult dict."""
        results: Dict[str, NodeResult] = {}
        for step_id, proof in self.proofs.items():
            results[step_id] = NodeResult(
                node_id=step_id,
                success=proof.succeeded,
                outputs={},
                error=proof.metrics.get("error") if proof.metrics else None,
                duration_ms=proof.metrics.get("duration_ms", 0.0) if proof.metrics else 0.0,
            )
        return results

    def to_dict(self) -> Dict[str, Any]:
        return {
            "run_id": self.run_id,
            "template_name": self.template_name,
            "status": self.status.value,
            "proofs": {k: v.to_dict() for k, v in self.proofs.items()},
            "merkle_root_hash": self.merkle_root_hash,
            "slot_id": self.slot_id,
            "slot_receipt_id": self.slot_receipt_id,
            "started_at": self.started_at.isoformat(),
            "completed_at": self.completed_at.isoformat() if self.completed_at else None,
            "waiting": self.waiting,
            "final_outputs": self.final_outputs,
        }


# Grid backward-compatibility alias
DAGResult = RunResult


# ---------------------------------------------------------------------------
# PGDAGRunner
# ---------------------------------------------------------------------------

class PGDAGRunner:
    """Proof-Gated DAG execution engine.

    Product-agnostic.  Products register step functions and execute templates.

    Usage:
        runner = PGDAGRunner(
            snapchore=sbn_client.snapchore,
            gateway=sbn_client.gateway,
            blocks=sbn_client.blocks,
            domain="treasury.execution",
            spec_version="1.0",
        )

        runner.register_steps({
            "acquire_rates": my_acquire_rates_fn,
            "seal_risk_envelope": my_seal_risk_fn,
            ...
        })

        result = await runner.execute(yield_capture_template, inputs={...}, actor="sp-engine-yield")
    """

    def __init__(
        self,
        snapchore: Any = None,
        gateway: Any = None,
        bitblocks: Any = None,
        blocks: Any = None,
        *,
        domain: str = "general",
        spec_version: str = "1.0",
    ) -> None:
        self._snapchore = snapchore
        self._gateway = gateway
        self._bitblocks = bitblocks
        self._domain = domain
        self._spec_version = spec_version
        self._steps: Dict[str, StepFn] = {}
        self._templates: Dict[str, DAGTemplate] = {}
        self._edge_emitter: Any = None  # Optional EdgeEmitter for Lattice edges
        self._lattice_client: Any = None  # Optional LatticeClient for proof-aware outcomes

        # Build internal components
        from .envelope import SnapChoreCapture
        self._envelope_builder = StepEnvelopeBuilder(
            snapchore=snapchore if isinstance(snapchore, SnapChoreCapture) else None,
        )

        # Choose seal backend
        if snapchore is not None or bitblocks is not None or blocks is not None:
            from .runner import SbnSealBackend
            backend = SbnSealBackend(sbn_client=type("_SBN", (), {
                "snapchore": snapchore,
                "gateway": gateway,
                "bitblocks": bitblocks,
                "blocks": blocks,
            })())
        else:
            from .runner import LocalSealBackend
            backend = LocalSealBackend()

        self._writer = ProofWriter(backend)
        self._gate = IdempotencyGate(snapchore=snapchore)
        self._interruption = InterruptionHandler()

    def _bind_active_slot(self, slot_id: Optional[str]) -> None:
        """Propagate the live slot id into runtime-aware proof backends."""
        backend = getattr(self._writer, "_backend", None)
        if backend is None:
            return
        setter = getattr(backend, "set_slot_id", None)
        if callable(setter):
            setter(slot_id)

    @property
    def interruption_handler(self) -> InterruptionHandler:
        return self._interruption

    @property
    def idempotency_gate(self) -> IdempotencyGate:
        return self._gate

    # ── Step registration ─────────────────────────────────────────────

    def register_step(self, step_id: str, step_fn: StepFn) -> None:
        """Register a step function by ID."""
        self._steps[step_id] = step_fn

    def register_steps(self, steps: Dict[str, StepFn]) -> None:
        """Register multiple step functions at once."""
        self._steps.update(steps)

    def register_template(self, template: DAGTemplate) -> None:
        """Register a reusable child workflow template by name and id."""
        self._templates[template.name] = template
        self._templates[template.name.lower()] = template
        if getattr(template, "name", None):
            self._templates[str(template.name)] = template

    def register_templates(
        self,
        templates: Mapping[str, DAGTemplate] | Sequence[DAGTemplate],
    ) -> None:
        """Register multiple child workflow templates."""
        if isinstance(templates, Mapping):
            for key, template in templates.items():
                self._templates[str(key)] = template
                self.register_template(template)
            return
        for template in templates:
            self.register_template(template)

    def _node_by_id(self, template: DAGTemplate) -> Dict[str, DAGNode]:
        return {node.id: node for node in template.nodes}

    def _is_subworkflow_node(self, node: Optional[DAGNode]) -> bool:
        normalized = str(getattr(node, "step_type", "") or "").strip().lower()
        return normalized in {"subworkflow", "delegated_workflow"}

    def _resolve_subworkflow_template(
        self,
        node: DAGNode,
        run_config: Dict[str, Any],
    ) -> DAGTemplate:
        metadata = node.metadata or {}
        templates = run_config.get("subworkflow_templates") or {}

        candidates: List[Any] = [
            metadata.get("workflow_template"),
            metadata.get("template_name"),
            metadata.get("template"),
        ]
        if isinstance(templates, Mapping):
            candidates.extend(
                [
                    templates.get(node.id),
                    templates.get(str(metadata.get("template_name") or "").strip()),
                ]
            )

        for candidate in candidates:
            if isinstance(candidate, DAGTemplate):
                return candidate
            if isinstance(candidate, str):
                template = self._templates.get(candidate) or self._templates.get(candidate.lower())
                if template is not None:
                    return template

        raise KeyError(f"Subworkflow template not registered for step: {node.id}")

    def _subworkflow_inputs(
        self,
        node: DAGNode,
        step_inputs: Dict[str, Any],
    ) -> Dict[str, Any]:
        metadata = node.metadata or {}
        child_inputs = dict(step_inputs)

        input_keys = metadata.get("input_keys")
        if isinstance(input_keys, Sequence) and not isinstance(input_keys, (str, bytes)):
            child_inputs = {
                str(key): step_inputs[str(key)]
                for key in input_keys
                if str(key) in step_inputs
            }

        explicit_inputs = metadata.get("inputs")
        if isinstance(explicit_inputs, Mapping):
            child_inputs.update(dict(explicit_inputs))

        return child_inputs

    def _spawn_child_runner(self, *, domain: str) -> PGDAGRunner:
        child = PGDAGRunner(
            snapchore=self._snapchore,
            gateway=self._gateway,
            bitblocks=self._bitblocks,
            blocks=None,
            domain=domain,
            spec_version=self._spec_version,
        )
        child._steps = self._steps
        child._templates = self._templates
        child._lattice_client = self._lattice_client
        child._edge_emitter = self._edge_emitter
        return child

    def _proof_from_subworkflow(
        self,
        *,
        step_id: str,
        inputs: Dict[str, Any],
        child_template: DAGTemplate,
        child_result: RunResult,
        child_workflow_id: str | None,
    ) -> ProofArtifact:
        anchor_hash = str(child_result.slot_receipt_id or "").strip()
        anchor_type = "receipt_hash"
        degraded = False
        if not anchor_hash:
            anchor_hash = str(child_result.merkle_root_hash or "").strip()
            anchor_type = "merkle_root" if anchor_hash else ""
            degraded = True

        child_summary = {
            "child_workflow_id": child_workflow_id,
            "child_template_name": child_template.name,
            "child_run_id": child_result.run_id,
            "child_slot_id": child_result.slot_id,
            "child_slot_receipt_id": child_result.slot_receipt_id,
            "child_merkle_root_hash": child_result.merkle_root_hash,
            "child_status": child_result.status.value,
            "subworkflow": True,
            "degraded_anchor": degraded,
        }
        proof_hash = anchor_hash or canonical_fingerprint(child_summary)
        status = (
            ProofStatus.COMPLETED
            if child_result.status == ReducerStatus.COMPLETE
            else ProofStatus.INTERRUPTED
            if child_result.status == ReducerStatus.INTERRUPTED
            else ProofStatus.FAILED
        )
        return ProofArtifact(
            step_id=step_id,
            spec_version=self._spec_version,
            inputs_fingerprint=canonical_fingerprint(inputs),
            outputs_fingerprint=canonical_fingerprint(child_result.final_outputs or {}),
            proof_hash=proof_hash,
            block_ref=str(child_result.slot_id or child_result.slot_receipt_id or ""),
            status=status,
            anchor_hash=anchor_hash or proof_hash,
            anchor_type=anchor_type or "proof_hash",
            receipt_id=str(child_result.slot_receipt_id or ""),
            metrics=child_summary,
        )

    async def _execute_subworkflow_step(
        self,
        *,
        parent_template: DAGTemplate,
        node: DAGNode,
        step_inputs: Dict[str, Any],
        run_config: Dict[str, Any],
        actor: str,
        run_id: str,
        slot_id: Optional[str],
    ) -> tuple[ProofArtifact, Dict[str, Any]]:
        child_template = self._resolve_subworkflow_template(node, run_config)
        child_inputs = self._subworkflow_inputs(node, step_inputs)

        child_config = dict(run_config)
        child_meta_config = node.metadata.get("config")
        if isinstance(child_meta_config, Mapping):
            child_config.update(dict(child_meta_config))
        child_config.update(
            {
                "parent_run_id": run_id,
                "parent_step_id": node.id,
                "parent_template_name": parent_template.name,
                "parent_slot_id": slot_id,
            }
        )

        child_actor = str(node.metadata.get("actor") or actor or "").strip()
        child_run_id = f"{run_id}:{node.id}:{uuid.uuid4().hex[:8]}"
        child_runner = self._spawn_child_runner(domain=child_template.domain or self._domain)
        child_workflow_id = child_runner._resolve_workflow_id(child_template, child_config)
        child_result = await child_runner.execute(
            child_template,
            child_inputs,
            actor=child_actor,
            config=child_config,
            run_id=child_run_id,
        )
        if child_result.waiting and child_result.wait_event is not None:
            wait = child_result.wait_event
            wait.node_id = node.id
            wait.partial_outputs.update(child_result.final_outputs or {})
            raise wait

        proof = self._proof_from_subworkflow(
            step_id=node.id,
            inputs=child_inputs,
            child_template=child_template,
            child_result=child_result,
            child_workflow_id=child_workflow_id,
        )
        self._bind_active_slot(slot_id)
        child_outputs = {
            **(child_result.final_outputs or {}),
            f"{node.id}_child_workflow_id": child_workflow_id,
            f"{node.id}_child_run_id": child_result.run_id,
            f"{node.id}_child_slot_id": child_result.slot_id,
            f"{node.id}_child_receipt_id": child_result.slot_receipt_id,
            f"{node.id}_child_merkle_root_hash": child_result.merkle_root_hash,
        }
        return proof, child_outputs

    def _resolve_workflow_id(
        self,
        template: DAGTemplate,
        run_config: Dict[str, Any],
    ) -> Optional[str]:
        """Resolve the linked Lattice workflow id from runtime config or template metadata."""
        candidates = [
            run_config.get("workflow_id"),
            run_config.get("lattice_workflow_id"),
            template.metadata.get("workflow_id"),
            template.metadata.get("lattice_workflow_id"),
        ]
        lattice_meta = template.metadata.get("lattice")
        if isinstance(lattice_meta, dict):
            candidates.extend(
                [
                    lattice_meta.get("workflow_id"),
                    lattice_meta.get("lattice_workflow_id"),
                ]
            )
        for value in candidates:
            if value is None:
                continue
            workflow_id = str(value).strip()
            if workflow_id:
                return workflow_id
        return None

    def _proof_stage_for_artifact(self, proof: ProofArtifact) -> str:
        """Infer the best proof stage from the artifact shape."""
        if proof.status == ProofStatus.INTERRUPTED:
            return "interrupted"
        if str(proof.anchor_type or "").strip().lower() == "receipt_hash":
            return "attested"
        block_ref = str(proof.block_ref or "").strip().lower()
        if block_ref and not block_ref.startswith(("local:", "unpublished:", "no-blocks:")):
            return "published"
        return "sealed"

    async def _call_with_retries(
        self,
        label: str,
        fn: Callable[..., Any],
        *args: Any,
        attempts: int = 4,
        base_delay_seconds: float = 0.75,
        **kwargs: Any,
    ) -> Any:
        """Call a sync/async function with small backoff for transient write flaps."""
        last_exc: Optional[Exception] = None
        for attempt in range(1, attempts + 1):
            try:
                if inspect.iscoroutinefunction(fn):
                    return await fn(*args, **kwargs)
                result = await asyncio.to_thread(fn, *args, **kwargs)
                if inspect.isawaitable(result):
                    return await result
                return result
            except Exception as exc:  # pragma: no cover - exercised via callers
                last_exc = exc
                if attempt >= attempts:
                    break
                logger.warning(
                    "%s attempt %s/%s failed: %s",
                    label,
                    attempt,
                    attempts,
                    exc,
                )
                await asyncio.sleep(base_delay_seconds * attempt)
        assert last_exc is not None
        raise last_exc

    async def _call_lattice(self, method_name: str, *args: Any, **kwargs: Any) -> Any:
        """Call a Lattice client method, awaiting it if needed."""
        if self._lattice_client is None:
            return None
        method = getattr(self._lattice_client, method_name, None)
        if method is None:
            return None
        return await self._call_with_retries(
            f"lattice.{method_name}",
            method,
            *args,
            **kwargs,
        )

    async def _report_step_outcome(
        self,
        workflow_id: Optional[str],
        *,
        template: DAGTemplate,
        run_id: str,
        slot_id: Optional[str],
        actor: str,
        step_id: str,
        proof: ProofArtifact,
        duration_seconds: Optional[float] = None,
        outcome_override: Optional[str] = None,
        signal_hash: Optional[str] = None,
    ) -> None:
        """Best-effort bridge from pgDAG proof artifacts into Lattice outcomes."""
        if not workflow_id or self._lattice_client is None:
            return

        outcome = outcome_override or ("completed" if proof.succeeded else "failed")
        proof_stage = self._proof_stage_for_artifact(proof)
        error_message = None
        if isinstance(proof.metrics, dict):
            raw_error = proof.metrics.get("error")
            if raw_error is not None:
                error_message = str(raw_error)

        meta = {
            "run_id": run_id,
            "template_name": template.name,
            "template_version": template.version,
            "slot_id": slot_id,
            "actor": actor,
            "proof_status": proof.status.value,
            "proof_anchor_hash": proof.anchor_hash or proof.proof_hash,
            "proof_anchor_type": proof.anchor_type or "proof_hash",
            "inputs_fingerprint": proof.inputs_fingerprint,
            "outputs_fingerprint": proof.outputs_fingerprint,
            "proof_spec_version": proof.spec_version,
            "receipt_id": proof.receipt_id or None,
        }
        if isinstance(proof.metrics, dict):
            for key in (
                "subworkflow",
                "child_workflow_id",
                "child_template_name",
                "child_run_id",
                "child_slot_id",
                "child_slot_receipt_id",
                "child_merkle_root_hash",
                "child_status",
            ):
                value = proof.metrics.get(key)
                if value is not None:
                    meta[key] = value
        if signal_hash:
            meta["signal_hash"] = signal_hash

        try:
            await self._call_lattice(
                "record_step_outcome",
                workflow_id,
                step_id,
                agent_id=actor or None,
                outcome=outcome,
                duration_seconds=duration_seconds,
                error_message=error_message,
                proof_hash=proof.proof_hash or None,
                proof_stage=proof_stage,
                block_ref=proof.block_ref or None,
                signal_hash=signal_hash,
                anchor_hash=proof.anchor_hash or proof.proof_hash or None,
                anchor_type=proof.anchor_type or None,
                receipt_id=proof.receipt_id or None,
                degraded=bool((proof.metrics or {}).get("degraded_anchor", False)),
                meta=meta,
            )
        except Exception as exc:
            logger.warning("Lattice outcome reporting failed for %s: %s", step_id, exc)

    async def _mark_workflow_complete(self, workflow_id: Optional[str]) -> None:
        """Best-effort mark linked Lattice workflow complete after full reduction."""
        if not workflow_id or self._lattice_client is None:
            return
        try:
            await self._call_lattice("mark_workflow_complete", workflow_id)
        except Exception as exc:
            logger.warning("Failed to mark workflow %s complete: %s", workflow_id, exc)

    async def _report_run_close(
        self,
        workflow_id: Optional[str],
        *,
        template: DAGTemplate,
        run_id: str,
        slot_id: Optional[str],
        actor: str,
        reducer_status: ReducerStatus,
        merkle_root_hash: str,
        slot_receipt_id: Optional[str],
        signal_hash: Optional[str] = None,
    ) -> None:
        """Best-effort terminal run-close event for run ledger and receipt visibility."""
        if not workflow_id or self._lattice_client is None:
            return

        proof_stage = "reduced"
        outcome = "completed"
        if reducer_status == ReducerStatus.INTERRUPTED:
            proof_stage = "interrupted"
            outcome = "skipped"
        elif reducer_status == ReducerStatus.FAILED:
            proof_stage = "failed"
            outcome = "failed"

        meta = {
            "event_kind": "run_close",
            "run_id": run_id,
            "template_name": template.name,
            "template_version": template.version,
            "slot_id": slot_id,
            "actor": actor,
            "merkle_root_hash": merkle_root_hash,
            "slot_receipt_id": slot_receipt_id,
            "reducer_status": reducer_status.value,
            "proof_status": reducer_status.value,
        }
        if signal_hash:
            meta["signal_hash"] = signal_hash

        try:
            await self._call_lattice(
                "record_step_outcome",
                workflow_id,
                "__run_close__",
                agent_id=actor or None,
                outcome=outcome,
                proof_stage=proof_stage,
                signal_hash=signal_hash,
                meta=meta,
            )
        except Exception as exc:
            logger.warning("Failed to record run close for %s: %s", workflow_id, exc)

    # ── Template execution ────────────────────────────────────────────

    async def execute(
        self,
        template: DAGTemplate,
        inputs: Dict[str, Any],
        *,
        actor: str = "",
        config: Optional[Dict[str, Any]] = None,
        run_id: Optional[str] = None,
    ) -> RunResult:
        """Execute a DAG template and return a RunResult.

        1. Open SBN slot
        2. Resolve step order (linear or topological)
        3. For each step: check interruption → run → collect proof
        4. Reduce proofs → compute Merkle root
        5. Close SBN slot with attestation
        """
        run_id = run_id or f"run-{uuid.uuid4().hex[:12]}"
        run_config = config or {}
        started_at = datetime.now(timezone.utc)
        domain = template.domain or self._domain
        workflow_id = self._resolve_workflow_id(template, run_config)

        # Reset interruption handler for this run
        self._interruption.reset()

        # Open slot
        slot_id = await self._open_slot(run_id, template.name, actor)
        self._bind_active_slot(slot_id)

        # Build step runner for this run
        step_runner = StepRunner(
            envelope_builder=self._envelope_builder,
            proof_writer=self._writer,
            gate=self._gate,
            domain=domain,
        )

        # Execute steps
        proofs: Dict[str, ProofArtifact] = {}
        current_outputs = dict(inputs)
        completed: Set[str] = set()
        node_map = self._node_by_id(template)

        while True:
            # Check for interruption between steps
            if self._interruption.is_triggered:
                last = list(completed)[-1] if completed else ""
                int_proof = self._interruption.build_interruption_proof(
                    last_completed_step=last,
                    run_id=run_id,
                    spec_version=self._spec_version,
                )
                proofs["interrupted"] = int_proof
                signal = self._interruption.signal
                await self._report_step_outcome(
                    workflow_id,
                    template=template,
                    run_id=run_id,
                    slot_id=slot_id,
                    actor=actor,
                    step_id=int_proof.step_id,
                    proof=int_proof,
                    outcome_override="skipped",
                    signal_hash=signal.signal_hash if signal is not None else None,
                )
                break

            # Get ready steps
            ready = template.ready_steps(completed)
            if not ready:
                break

            # Execute ready steps (sequentially for now; parallel TODO)
            for step_id in ready:
                node = node_map.get(step_id)
                if not self._is_subworkflow_node(node) and step_id not in self._steps:
                    logger.error("No registered function for step: %s", step_id)
                    proof = ProofArtifact(
                        step_id=step_id,
                        spec_version=self._spec_version,
                        inputs_fingerprint="",
                        outputs_fingerprint="",
                        proof_hash="",
                        block_ref="",
                        status=ProofStatus.FAILED,
                        metrics={"error": f"Step function not registered: {step_id}"},
                    )
                    proofs[step_id] = proof
                    completed.add(step_id)
                    await self._report_step_outcome(
                        workflow_id,
                        template=template,
                        run_id=run_id,
                        slot_id=slot_id,
                        actor=actor,
                        step_id=step_id,
                        proof=proof,
                    )
                    continue

                # Build step inputs: run inputs + outputs from prior steps
                step_inputs = self._build_step_inputs(
                    step_id, current_outputs, proofs, template,
                )

                context = StepContext(
                    inputs=step_inputs,
                    prior_proofs=dict(proofs),
                    config=run_config,
                    actor=actor,
                    run_id=run_id,
                    slot_id=slot_id,
                    node_id=step_id,
                )

                # Execute step — catch WaitForEvent before proof sealing
                step_started = datetime.now(timezone.utc)
                try:
                    if self._is_subworkflow_node(node):
                        proof, child_outputs = await self._execute_subworkflow_step(
                            parent_template=template,
                            node=node or DAGNode(id=step_id),
                            step_inputs=step_inputs,
                            run_config=run_config,
                            actor=actor,
                            run_id=run_id,
                            slot_id=slot_id,
                        )
                        context.inputs.update(child_outputs)
                    else:
                        proof = await step_runner.run(
                            step_id=step_id,
                            spec_version=self._spec_version,
                            step_fn=self._steps[step_id],
                            context=context,
                        )
                except WaitForEvent as wait:
                    # Step needs an external event — pause the DAG
                    wait.node_id = step_id
                    current_outputs.update(wait.partial_outputs)
                    return RunResult(
                        run_id=run_id,
                        template_name=template.name,
                        status=ReducerStatus.WAITING,
                        proofs=proofs,
                        merkle_root_hash="",
                        slot_id=slot_id,
                        started_at=started_at,
                        waiting=True,
                        wait_event=wait,
                        final_outputs=current_outputs,
                        duration_ms=(datetime.now(timezone.utc) - started_at).total_seconds() * 1000,
                    )

                proofs[step_id] = proof
                completed.add(step_id)
                step_duration = (datetime.now(timezone.utc) - step_started).total_seconds()
                await self._report_step_outcome(
                    workflow_id,
                    template=template,
                    run_id=run_id,
                    slot_id=slot_id,
                    actor=actor,
                    step_id=step_id,
                    proof=proof,
                    duration_seconds=step_duration,
                )

                # Emit Lattice edge for successful proofs
                if self._edge_emitter and proof.succeeded:
                    try:
                        if self._is_subworkflow_node(node) and isinstance(proof.metrics, dict):
                            await self._edge_emitter.emit_subworkflow(
                                parent_template=template.name,
                                parent_step_id=step_id,
                                child_template=str(proof.metrics.get("child_template_name") or ""),
                                child_workflow_id=str(
                                    proof.metrics.get("child_workflow_id")
                                    or (run_config.get("child_workflow_ids") or {}).get(step_id)
                                    or ""
                                )
                                or None,
                                parent_run_id=run_id,
                                child_run_id=str(proof.metrics.get("child_run_id") or ""),
                                child_slot_id=str(proof.metrics.get("child_slot_id") or "") or None,
                                child_receipt_id=str(proof.metrics.get("child_slot_receipt_id") or "") or None,
                                child_merkle_root=str(proof.metrics.get("child_merkle_root_hash") or "") or None,
                            )
                        await self._edge_emitter.emit(
                            step_id, proof,
                            run_id=run_id, template_name=template.name,
                        )
                    except Exception:
                        logger.warning("Edge emission failed for %s", step_id)

                # Thread outputs forward
                if proof.succeeded and context.inputs:
                    current_outputs.update(context.inputs)

                # If step failed, stop the run
                if not proof.succeeded:
                    break

            # Check if any step in this batch failed
            if any(
                proofs.get(s) and not proofs[s].succeeded
                for s in ready
                if s in proofs
            ):
                break

        # Reduce
        reducer = Reducer(expected_steps=template.node_ids, run_id=run_id)
        for proof in proofs.values():
            reducer.fold(proof)
        state = reducer.state()

        terminal_signal_hash = None
        interrupted_proof = proofs.get("interrupted")
        if interrupted_proof is not None and isinstance(interrupted_proof.metrics, dict):
            signal_meta = interrupted_proof.metrics.get("signal")
            raw_signal_hash = None
            if isinstance(signal_meta, dict):
                raw_signal_hash = signal_meta.get("signal_hash")
            if raw_signal_hash is None:
                raw_signal_hash = interrupted_proof.metrics.get("signal_hash")
            if raw_signal_hash is not None:
                terminal_signal_hash = str(raw_signal_hash).strip() or None

        # Close slot
        receipt_id = await self._close_slot(
            slot_id, run_id, state.merkle_root_hash, proofs,
        )
        await self._report_run_close(
            workflow_id,
            template=template,
            run_id=run_id,
            slot_id=slot_id,
            actor=actor,
            reducer_status=state.status,
            merkle_root_hash=state.merkle_root_hash,
            slot_receipt_id=receipt_id,
            signal_hash=terminal_signal_hash,
        )
        if state.status == ReducerStatus.COMPLETE:
            await self._mark_workflow_complete(workflow_id)

        completed_at = datetime.now(timezone.utc)
        return RunResult(
            run_id=run_id,
            template_name=template.name,
            status=state.status,
            proofs=proofs,
            merkle_root_hash=state.merkle_root_hash,
            slot_id=slot_id,
            slot_receipt_id=receipt_id,
            started_at=started_at,
            completed_at=completed_at,
            final_outputs=current_outputs,
            duration_ms=(completed_at - started_at).total_seconds() * 1000,
        )

    # ── Slot management ───────────────────────────────────────────────

    async def _open_slot(
        self,
        run_id: str,
        template_name: str,
        actor: str,
    ) -> Optional[str]:
        """Open an SBN execution slot for this run."""
        if self._gateway is None:
            return f"local-{uuid.uuid4().hex[:12]}"
        try:
            result = self._gateway.create_slot(
                worker_id=actor,
                task_type=template_name or "workflow",
                generation_interval=60,
                metadata={
                    "slot_type": "execution",
                    "run_id": run_id,
                    "template": template_name,
                    "actor": actor,
                },
            )
            slot_id = getattr(result, "slot_id", "") or getattr(result, "id", "")
            logger.info("Opened slot %s for run %s", slot_id, run_id)
            return slot_id
        except Exception as exc:
            logger.warning("Failed to open SBN slot: %s — using local", exc)
            return f"local-{uuid.uuid4().hex[:12]}"

    async def _close_slot(
        self,
        slot_id: Optional[str],
        run_id: str,
        root: str,
        proofs: Dict[str, ProofArtifact],
    ) -> Optional[str]:
        """Close the SBN slot with Merkle root and request attestation."""
        if self._gateway is None or not slot_id or slot_id.startswith("local-"):
            return None
        try:
            backend = getattr(self._writer, "_backend", None)
            close_via_backend = getattr(backend, "close_slot", None)
            if callable(close_via_backend):
                result = await self._call_with_retries(
                    "stream.close_slot",
                    close_via_backend,
                )
            else:
                result = await self._call_with_retries(
                    "gateway.close_slot",
                    self._gateway.close_slot,
                    slot_id,
                )
            receipt_id = (
                getattr(result, "receipt_id", "")
                or getattr(result, "attestation_id", "")
            )
            logger.info("Closed slot %s — receipt %s", slot_id, receipt_id)
            return receipt_id
        except Exception as exc:
            logger.warning("Failed to close SBN slot %s: %s", slot_id, exc)
            return None

    # ── Input threading ───────────────────────────────────────────────

    def _build_step_inputs(
        self,
        step_id: str,
        run_inputs: Dict[str, Any],
        proofs: Dict[str, ProofArtifact],
        template: DAGTemplate,
    ) -> Dict[str, Any]:
        """Build inputs for a step by merging run inputs + prior proof metadata."""
        inputs = dict(run_inputs)

        # Add proof hashes from dependencies
        if not template.is_linear:
            deps = template.dependency_map().get(step_id, set())
            for dep_id in deps:
                if dep_id in proofs:
                    inputs[f"{dep_id}_proof_hash"] = proofs[dep_id].proof_hash
                    inputs[f"{dep_id}_anchor_hash"] = (
                        proofs[dep_id].anchor_hash or proofs[dep_id].proof_hash
                    )
                    inputs[f"{dep_id}_anchor_type"] = (
                        proofs[dep_id].anchor_type or "proof_hash"
                    )
                    inputs[f"{dep_id}_outputs_fingerprint"] = proofs[dep_id].outputs_fingerprint
        else:
            # Linear: thread all prior proof hashes
            for pid, proof in proofs.items():
                if proof.succeeded:
                    inputs[f"{pid}_proof_hash"] = proof.proof_hash
                    inputs[f"{pid}_anchor_hash"] = proof.anchor_hash or proof.proof_hash
                    inputs[f"{pid}_anchor_type"] = proof.anchor_type or "proof_hash"

        return inputs
