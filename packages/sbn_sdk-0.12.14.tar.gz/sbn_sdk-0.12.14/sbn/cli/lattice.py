"""sbn lattice - workflow DAG and graph operations."""
from __future__ import annotations

import json
from dataclasses import asdict, is_dataclass
from pathlib import Path
from typing import Any, Optional

import typer

from sbn._http import SbnError, SbnTransportError
from sbn.cli._config import get_sbn_client, load_config
from sbn.cli._output import print_error, print_json, print_kv, print_quiet, print_success, print_table

lattice_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
workflows_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
edges_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)

lattice_app.add_typer(workflows_app, name="workflows", help="Workflow lifecycle and traversal.")
lattice_app.add_typer(edges_app, name="edges", help="Cross-workflow graph edges.")


def _die(exc: Exception) -> None:
    print_error(str(exc))
    raise typer.Exit(1)


def _workflow_id(item: dict[str, Any]) -> str:
    return str(item.get("workflow_id") or item.get("id") or "")


def _load_json_file(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _optional_json_file(path: Optional[Path]) -> Any:
    if path is None:
        return None
    return _load_json_file(path)


def _workflow_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "workflow_id": _workflow_id(item),
                "name": str(item.get("name") or ""),
                "domain": str(item.get("domain") or ""),
                "state": str(item.get("state") or ""),
                "topology": str(item.get("topology") or ""),
                "project_id": str(item.get("project_id") or ""),
            }
        )
    return rows


def _edge_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "id": str(item.get("id") or ""),
                "source_id": str(item.get("source_id") or ""),
                "target_id": str(item.get("target_id") or ""),
                "edge_type": str(item.get("edge_type") or ""),
                "weight": str(item.get("weight") or ""),
            }
        )
    return rows


def _run_rows(items: list[dict[str, Any]]) -> list[dict[str, str]]:
    rows: list[dict[str, str]] = []
    for item in items:
        rows.append(
            {
                "run_id": str(item.get("run_id") or ""),
                "status": str(item.get("status_label") or item.get("status") or ""),
                "phase": str(item.get("phase") or ""),
                "proof_stage": str(item.get("proof_stage") or ""),
                "events": str(item.get("event_count") or 0),
                "steps": str(item.get("step_count") or 0),
                "last_event_at": str(item.get("last_event_at") or ""),
            }
        )
    return rows


def _template_payload(template: Any) -> dict[str, Any]:
    """Serialize a pgDAG template dataclass for CLI output."""
    if is_dataclass(template):
        return asdict(template)
    if hasattr(template, "__dict__"):
        return dict(template.__dict__)
    raise TypeError("Expected a dataclass-like pgDAG template payload")


@workflows_app.command("create")
def workflows_create(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", "-n", help="Workflow name."),
    domain: str = typer.Option(..., "--domain", "-d", help="Workflow domain."),
    nodes_file: Path = typer.Option(
        ...,
        "--nodes-file",
        exists=True,
        dir_okay=False,
        readable=True,
        help="JSON file containing workflow nodes.",
    ),
    edges_file: Optional[Path] = typer.Option(
        None,
        "--edges-file",
        exists=True,
        dir_okay=False,
        readable=True,
        help="Optional JSON file containing workflow edges.",
    ),
    meta_file: Optional[Path] = typer.Option(
        None,
        "--meta-file",
        exists=True,
        dir_okay=False,
        readable=True,
        help="Optional JSON file for workflow meta, such as runtime_binding or proof_contract.",
    ),
    gec_frontier_file: Optional[Path] = typer.Option(
        None,
        "--gec-frontier-file",
        exists=True,
        dir_okay=False,
        readable=True,
        help="Optional JSON file for gec_frontier settings.",
    ),
    topology: str = typer.Option("series", "--topology", help="Workflow topology, e.g. series or dag."),
    activate: bool = typer.Option(False, "--activate", help="Activate the workflow after creation."),
) -> None:
    """Create a workflow directly in Lattice from node/edge JSON."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        nodes = _load_json_file(nodes_file)
        edges = _optional_json_file(edges_file)
        meta = _optional_json_file(meta_file)
        gec_frontier = _optional_json_file(gec_frontier_file)
        result = client.lattice.create_workflow(
            domain=domain,
            name=name,
            nodes=nodes,
            edges=edges,
            topology=topology,
            meta=meta,
            gec_frontier=gec_frontier,
        )
        if activate:
            result = client.lattice.activate_workflow(_workflow_id(result) or str(result.get("id") or ""))
    except (OSError, SbnError, SbnTransportError, TypeError, ValueError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _workflow_id(result)
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Created workflow {resolved_id or '(unknown id)'}")
    print_kv(
        {
            "Name": name,
            "Domain": domain,
            "Topology": topology,
            "Nodes": len(nodes or []),
            "Edges": len(edges or []),
            "State": result.get("state", "draft"),
        },
        highlights={"State"},
    )


@workflows_app.command("list")
def workflows_list(
    ctx: typer.Context,
    domain: Optional[str] = typer.Option(None, "--domain", help="Filter by domain."),
    state: Optional[str] = typer.Option(None, "--state", help="Filter by workflow state."),
    scopes: Optional[str] = typer.Option(None, "--scopes", help="Comma-separated scope patterns."),
    limit: int = typer.Option(50, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List workflows visible in the current project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    scope_list = [scope.strip() for scope in scopes.split(",") if scope.strip()] if scopes else None
    try:
        result = client.lattice.list_workflows(domain=domain, state=state, scopes=scope_list, limit=limit)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"workflows": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(filter(None, (_workflow_id(item) for item in result))), nl=False)
        return

    print_success(f"Fetched {len(result)} workflow(s)")
    print_table(_workflow_rows(result), ["workflow_id", "name", "domain", "state", "topology", "project_id"])


@workflows_app.command("get")
def workflows_get(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
) -> None:
    """Fetch one workflow with node and edge detail."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.get_workflow(workflow_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _workflow_id(result) or workflow_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Workflow {resolved_id}")
    print_kv(
        {
            "Name": result.get("name", ""),
            "Domain": result.get("domain", ""),
            "State": result.get("state", ""),
            "Topology": result.get("topology", ""),
            "Nodes": len(result.get("nodes") or []),
            "Edges": len(result.get("edges") or []),
            "Project": result.get("project_id", ""),
        },
        highlights={"State"},
    )


@workflows_app.command("activate")
def workflows_activate(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
) -> None:
    """Activate a workflow."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.activate_workflow(workflow_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _workflow_id(result) or workflow_id
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Activated workflow {resolved_id}")
    print_kv({"State": result.get("state", "active")}, highlights={"State"})


@workflows_app.command("clone")
def workflows_clone(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    target_project_id: str = typer.Option(..., "--target-project-id", help="Project to clone into."),
) -> None:
    """Clone a workflow into another project."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.clone_workflow(workflow_id, target_project_id)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    resolved_id = _workflow_id(result)
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(resolved_id)
        return

    print_success(f"Cloned workflow into {resolved_id or '(unknown id)'}")
    print_kv({"Target Project": target_project_id})


@workflows_app.command("export")
def workflows_export(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    output: Optional[Path] = typer.Option(None, "--output", "-o", dir_okay=False, help="Write JSON export to a file."),
) -> None:
    """Export a workflow as portable JSON."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.export_workflow(workflow_id)
        if output:
            output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    except (OSError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "quiet" and output is not None:
        print_quiet(str(output))
        return
    if fmt == "json" or output is None:
        print_json(result)
        return

    print_success(f"Exported workflow to {output}")


@workflows_app.command("import")
def workflows_import(
    ctx: typer.Context,
    source: Path = typer.Argument(..., exists=True, dir_okay=False, readable=True, help="Workflow or bundle JSON file."),
    activate: bool = typer.Option(False, "--activate", help="Activate imported workflows after import."),
) -> None:
    """Import a workflow export or workflow bundle into Lattice."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        payload = _load_json_file(source)
        if payload.get("format") == "sbn_lattice_bundle_v1" or (
            "workflows" in payload and "workflow" not in payload
        ):
            result = client.lattice.import_workflows(payload, activate=activate)
            bundle = True
        else:
            result = client.lattice.import_workflow(payload, activate=activate)
            bundle = False
    except (OSError, SbnError, SbnTransportError, json.JSONDecodeError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        if bundle:
            print_quiet(str(result.get("imported") or result.get("count") or ""))
        else:
            print_quiet(_workflow_id(result))
        return

    if bundle:
        print_success("Imported workflow bundle")
        print_kv(
            {
                "Source": str(source),
                "Imported": result.get("imported", result.get("count", "")),
                "Activated": activate,
            },
            highlights={"Imported"},
        )
        return

    print_success(f"Imported workflow {_workflow_id(result) or '(unknown id)'}")
    print_kv(
        {
            "Source": str(source),
            "State": result.get("state", "draft"),
        },
        highlights={"State"},
    )


@workflows_app.command("template")
def workflows_template(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    output: Optional[Path] = typer.Option(None, "--output", "-o", dir_okay=False, help="Write the pgDAG template JSON to a file."),
) -> None:
    """Build a pgDAG template payload from a stored Lattice workflow."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        template = client.lattice.build_pgdag_template(workflow_id)
        payload = _template_payload(template)
        if output:
            output.write_text(json.dumps(payload, indent=2), encoding="utf-8")
    except (OSError, SbnError, SbnTransportError, ValueError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "quiet" and output is not None:
        print_quiet(str(output))
        return
    if fmt == "json":
        print_json(payload)
        return
    if output is not None:
        print_success(f"Built pgDAG template for {workflow_id}")
        print_kv({"Output": str(output)})
        return

    print_success(f"Built pgDAG template for {workflow_id}")
    print_kv(
        {
            "Name": payload.get("name", ""),
            "Domain": payload.get("domain", ""),
            "Version": payload.get("version", ""),
            "Nodes": len(payload.get("nodes") or []),
            "Edges": len(payload.get("edges") or []),
            "Linked workflow_id": str((payload.get("metadata") or {}).get("workflow_id") or ""),
        },
        highlights={"Linked workflow_id"},
    )


@workflows_app.command("ready")
def workflows_ready(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    completed: Optional[str] = typer.Option(None, "--completed", help="Comma-separated completed step IDs."),
) -> None:
    """Get steps ready to execute for a workflow."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    completed_steps = [item.strip() for item in completed.split(",") if item.strip()] if completed else None
    try:
        result = client.lattice.get_ready_steps(workflow_id, completed=completed_steps)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"ready_steps": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("id") or item.get("step_id") or "") for item in result), nl=False)
        return

    rows = [
        {
            "step_id": str(item.get("step_id") or item.get("id") or ""),
            "name": str(item.get("name") or ""),
            "skill": str(item.get("skill") or ""),
            "dept": str(item.get("dept") or ""),
        }
        for item in result
    ]
    print_success(f"Ready steps: {len(rows)}")
    print_table(rows, ["step_id", "name", "skill", "dept"])


@workflows_app.command("runs")
def workflows_runs(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    limit: int = typer.Option(10, "--limit", min=1, help="Maximum runs to return."),
) -> None:
    """List recent grouped run ledgers for a workflow."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.list_workflow_runs(workflow_id, limit=limit)
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"runs": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("run_id") or "") for item in result), nl=False)
        return

    print_success(f"Fetched {len(result)} run(s) for {workflow_id}")
    print_table(
        _run_rows(result),
        ["run_id", "status", "phase", "proof_stage", "events", "steps", "last_event_at"],
    )


@workflows_app.command("evidence-packet")
def workflows_evidence_packet(
    ctx: typer.Context,
    workflow_id: str = typer.Argument(..., help="Workflow ID."),
    run_id: str = typer.Argument(..., help="Run ID."),
    output: Optional[Path] = typer.Option(None, "--output", "-o", dir_okay=False, help="Write JSON packet to a file."),
) -> None:
    """Fetch a server-signed evidence packet for one workflow run."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.get_workflow_run_evidence_packet(workflow_id, run_id)
        if output:
            output.write_text(json.dumps(result, indent=2), encoding="utf-8")
    except (OSError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "quiet" and output is not None:
        print_quiet(str(output))
        return
    if fmt == "json" or output is None:
        print_json(result)
        return

    print_success(f"Fetched evidence packet for run {run_id}")
    print_kv(
        {
            "Workflow": workflow_id,
            "Run": run_id,
            "Output": str(output),
            "Digest": str((result.get("share_manifest") or {}).get("packet_digest") or ""),
            "Signature Key": str((result.get("signature") or {}).get("key_id") or ""),
        },
        highlights={"Run", "Digest"},
    )


@workflows_app.command("verify-packet")
def workflows_verify_packet(
    ctx: typer.Context,
    file: Optional[Path] = typer.Option(None, "--file", exists=True, dir_okay=False, readable=True, help="Path to a packet JSON file."),
    packet_json: Optional[str] = typer.Option(None, "--json", help="Raw packet JSON string."),
) -> None:
    """Verify a signed evidence packet envelope."""
    if not file and not packet_json:
        print_error("Provide --file or --json.")
        raise typer.Exit(1)
    if file and packet_json:
        print_error("Choose either --file or --json, not both.")
        raise typer.Exit(1)

    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        data = _load_json_file(file) if file else json.loads(packet_json or "{}")
        result = client.lattice.verify_evidence_packet(data)
    except (OSError, json.JSONDecodeError, SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(str(result.get("verified", False)).lower())
        return

    print_success("Verified evidence packet")
    print_kv(
        {
            "Verified": result.get("verified", False),
            "Digest Match": result.get("digest_match", False),
            "Signature Valid": result.get("signature_valid", False),
            "Packet Digest": result.get("packet_digest", ""),
            "Signature Key": result.get("signature_key_id", ""),
        },
        highlights={"Verified", "Digest Match", "Signature Valid"},
    )


@edges_app.command("list")
def edges_list(
    ctx: typer.Context,
    source_id: Optional[str] = typer.Option(None, "--source-id", help="Filter by source."),
    target_id: Optional[str] = typer.Option(None, "--target-id", help="Filter by target."),
    edge_type: Optional[str] = typer.Option(None, "--edge-type", help="Filter by edge type."),
    limit: int = typer.Option(100, "--limit", min=1, help="Maximum rows to return."),
) -> None:
    """List cross-workflow lattice edges."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    try:
        result = client.lattice.list_edges(
            source_id=source_id,
            target_id=target_id,
            edge_type=edge_type,
            limit=limit,
        )
    except (SbnError, SbnTransportError) as exc:
        _die(exc)

    fmt = config.output_format
    if fmt == "json":
        print_json({"edges": result})
        return
    if fmt == "quiet":
        typer.echo("\n".join(str(item.get("id") or "") for item in result), nl=False)
        return

    print_success(f"Fetched {len(result)} edge(s)")
    print_table(_edge_rows(result), ["id", "source_id", "target_id", "edge_type", "weight"])
