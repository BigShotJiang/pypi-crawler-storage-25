"""sbn atlas — frontier provisioning, resolution, app management."""
from __future__ import annotations

import json
from pathlib import Path
from typing import Any, Optional

import typer

from sbn.cli._config import load_config, get_sbn_client, get_atlas
from sbn.cli._output import (
    print_json,
    print_kv,
    print_quiet,
    print_table,
    print_csk_bars,
    print_success,
    print_error,
)

atlas_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
keys_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
bindings_app = typer.Typer(no_args_is_help=True, pretty_exceptions_enable=False)
atlas_app.add_typer(keys_app, name="keys")
atlas_app.add_typer(bindings_app, name="bindings")


def _load_json_file(path: Path) -> Any:
    return json.loads(path.read_text(encoding="utf-8"))


def _parse_assignment_map(values: list[str], *, option_name: str) -> dict[str, str]:
    parsed: dict[str, str] = {}
    for value in values:
        raw = (value or "").strip()
        if not raw or "=" not in raw:
            raise typer.BadParameter(
                f"{option_name} entries must use workflow=value syntax",
                param_hint=option_name,
            )
        workflow, mapped = raw.split("=", 1)
        workflow = workflow.strip()
        mapped = mapped.strip()
        if not workflow or not mapped:
            raise typer.BadParameter(
                f"{option_name} entries must use workflow=value syntax",
                param_hint=option_name,
            )
        parsed[workflow] = mapped
    return parsed


def _parse_event_map(values: list[str]) -> dict[str, list[str]]:
    parsed: dict[str, list[str]] = {}
    for workflow, raw_events in _parse_assignment_map(values, option_name="--events").items():
        parsed[workflow] = [item.strip() for item in raw_events.split(",") if item.strip()]
    return parsed


def _build_workflow_specs(
    *,
    workflows_csv: str | None,
    workflows: list[str] | None,
    workflow_spec_entries: list[str] | None,
    workflow_specs_file: Path | None,
    binds: list[str] | None,
    pulses: list[str] | None,
    event_entries: list[str] | None,
) -> tuple[list[str], list[dict[str, Any]] | None]:
    declared_workflows: list[str] = []
    if workflows_csv:
        declared_workflows.extend([w.strip() for w in workflows_csv.split(",") if w.strip()])
    declared_workflows.extend([w.strip() for w in (workflows or []) if w.strip()])

    normalized_specs: list[dict[str, Any]] = []

    def _clean_text(value: Any, *, lower: bool = False) -> str | None:
        text = str(value or "").strip()
        if not text:
            return None
        return text.lower() if lower else text

    def _clean_list(values: Any, *, lower: bool = False) -> list[str]:
        cleaned: list[str] = []
        seen: set[str] = set()
        for value in values or []:
            item = _clean_text(value, lower=lower)
            if item and item not in seen:
                cleaned.append(item)
                seen.add(item)
        return cleaned

    def _normalize_spec(item: dict[str, Any]) -> dict[str, Any]:
        return {
            "workflow": str(item.get("workflow") or "").strip(),
            "frontier_id": _clean_text(item.get("frontier_id") or item.get("frontier")),
            "pulse_type": _clean_text(item.get("pulse_type"), lower=True),
            "event_types": _clean_list(item.get("event_types")),
            "derives_from_frontiers": _clean_list(item.get("derives_from_frontiers")),
            "accepted_pulse_types": _clean_list(item.get("accepted_pulse_types"), lower=True),
            "weighting_strategy": _clean_text(item.get("weighting_strategy"), lower=True),
            "rollup_mode": _clean_text(item.get("rollup_mode"), lower=True),
            "anchor_requirement": _clean_text(item.get("anchor_requirement"), lower=True),
            "fallback_policy": _clean_text(item.get("fallback_policy"), lower=True),
        }

    if workflow_specs_file:
        loaded = _load_json_file(workflow_specs_file)
        if isinstance(loaded, dict):
            loaded = loaded.get("workflow_specs", loaded.get("items", loaded))
        if not isinstance(loaded, list):
            raise typer.BadParameter(
                "--workflow-specs-file must contain a JSON array or {\"workflow_specs\": [...]}",
                param_hint="--workflow-specs-file",
            )
        for item in loaded:
            if not isinstance(item, dict) or not str(item.get("workflow") or "").strip():
                raise typer.BadParameter(
                    "--workflow-specs-file contains an invalid workflow spec",
                    param_hint="--workflow-specs-file",
                )
            normalized_specs.append(_normalize_spec(item))

    for entry in workflow_spec_entries or []:
        try:
            item = json.loads(entry)
        except json.JSONDecodeError as exc:
            raise typer.BadParameter(
                f"--workflow-spec must be valid JSON: {exc}",
                param_hint="--workflow-spec",
            ) from exc
        if not isinstance(item, dict) or not str(item.get("workflow") or "").strip():
            raise typer.BadParameter(
                "--workflow-spec must include a workflow field",
                param_hint="--workflow-spec",
            )
        normalized_specs.append(_normalize_spec(item))

    spec_by_workflow: dict[str, dict[str, Any]] = {
        spec["workflow"]: dict(spec)
        for spec in normalized_specs
        if spec.get("workflow")
    }
    bind_map = _parse_assignment_map(binds or [], option_name="--bind")
    pulse_map = _parse_assignment_map(pulses or [], option_name="--pulse")
    events_map = _parse_event_map(event_entries or [])

    workflow_order = []
    for workflow in declared_workflows:
        if workflow not in workflow_order:
            workflow_order.append(workflow)
    for workflow in list(spec_by_workflow) + list(bind_map) + list(pulse_map) + list(events_map):
        workflow = workflow.strip()
        if workflow and workflow not in workflow_order:
            workflow_order.append(workflow)

    for workflow in workflow_order:
        spec = spec_by_workflow.setdefault(
            workflow,
            {
                "workflow": workflow,
                "frontier_id": None,
                "pulse_type": None,
                "event_types": [],
                "derives_from_frontiers": [],
                "accepted_pulse_types": [],
                "weighting_strategy": None,
                "rollup_mode": None,
                "anchor_requirement": None,
                "fallback_policy": None,
            },
        )
        if workflow in bind_map:
            spec["frontier_id"] = bind_map[workflow]
        if workflow in pulse_map:
            spec["pulse_type"] = pulse_map[workflow]
        if workflow in events_map:
            spec["event_types"] = events_map[workflow]

    if not workflow_order:
        return [], None

    workflow_specs = [spec_by_workflow[workflow] for workflow in workflow_order]
    return workflow_order, workflow_specs


def _find_app_record(client: Any, app_id: str) -> dict[str, Any]:
    apps = (client.atlas.list_apps() or {}).get("apps") or []
    for item in apps:
        if str(item.get("app_id") or "").strip() == app_id:
            return item
    raise typer.BadParameter(f"Atlas app not found: {app_id}", param_hint="app_id")


def _find_workflow_spec(app: dict[str, Any], workflow: str) -> dict[str, Any]:
    for spec in app.get("workflow_specs") or []:
        if str(spec.get("workflow") or "").strip() == workflow:
            return spec
    raise typer.BadParameter(
        f"Workflow lane not found on app: {workflow}",
        param_hint="--workflow",
    )


def _ordered_contract_history(spec: dict[str, Any]) -> list[dict[str, Any]]:
    history = [dict(item) for item in (spec.get("contract_history") or []) if isinstance(item, dict)]
    return sorted(
        history,
        key=lambda item: str(item.get("changed_at") or ""),
        reverse=True,
    )


# ── Resolve ──────────────────────────────────────────────────────────

@atlas_app.command("resolve")
def resolve(
    ctx: typer.Context,
    workflow: str = typer.Option(..., "--workflow", "-w", help="Workflow family (e.g. code, chat, delivery)"),
    event_type: Optional[str] = typer.Option(None, "--event-type", "-e", help="Specific event type"),
    frontier_hint: Optional[str] = typer.Option(None, "--frontier-hint", help="Explicit frontier path to resolve"),
) -> None:
    """Resolve the best frontier for a workflow context."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)

    result = client.atlas.resolve(
        workflow=workflow,
        event_type=event_type,
        frontier_hint=frontier_hint,
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(result.get("scoring_frontier", ""))
        return

    # Table format
    print_success(f"Resolved: {result.get('scoring_frontier', '?')}")
    typer.echo("")
    print_kv({
        "Frontier": result.get("scoring_frontier", "?"),
        "C_max": result.get("c_max", "?"),
        "Regime": result.get("regime", "?"),
        "Metallic": result.get("metallic_label", "?"),
        "Lambda": result.get("lambda_score", "?"),
        "Steering": result.get("steering_layer", "?"),
    }, highlights={"Frontier", "Regime"})

    csk = result.get("csk")
    if csk:
        typer.echo("\nCSK Vector:")
        print_csk_bars(csk)

    guidance = result.get("regime_guidance")
    if guidance:
        typer.echo(f"\nGuidance: {guidance}")

    hints = result.get("intervention_hints")
    if hints:
        typer.echo("\nIntervention Hints:")
        for h in hints:
            sev = h.get("severity", "?")
            dim = h.get("dimension", "?")
            score = h.get("score", 0)
            msg = h.get("message", "")
            marker = "!" if sev == "critical" else "~"
            typer.echo(f"  {marker} [{sev}] {dim}={score:.2f}: {msg}")


# ── Register ─────────────────────────────────────────────────────────

@atlas_app.command("register")
def register(
    ctx: typer.Context,
    name: str = typer.Option(..., "--name", "-n", help="App name"),
    family: str = typer.Option(..., "--family", "-f", help="App family (e.g. ai.assistant, grid)"),
    workflows: Optional[str] = typer.Option(None, "--workflows", "-w", help="Comma-separated workflow list"),
    workflow: list[str] = typer.Option(None, "--workflow", help="Repeatable workflow name"),
    workflow_spec: list[str] = typer.Option(
        None,
        "--workflow-spec",
        help="Repeatable JSON workflow spec ({\"workflow\":\"pushup_session\",\"frontier_id\":\"kinetic.pushup.amrap.v1\",\"pulse_type\":\"slot_stream\"})",
    ),
    workflow_specs_file: Optional[Path] = typer.Option(
        None,
        "--workflow-specs-file",
        exists=True,
        dir_okay=False,
        readable=True,
        help="JSON file containing workflow specs",
    ),
    bind: list[str] = typer.Option(
        None,
        "--bind",
        help="Repeatable workflow frontier binding (workflow=frontier_id)",
    ),
    pulse: list[str] = typer.Option(
        None,
        "--pulse",
        help="Repeatable workflow pulse assignment (workflow=slot_stream|pgdag|batch)",
    ),
    events: list[str] = typer.Option(
        None,
        "--events",
        help="Repeatable workflow event mapping (workflow=event_a,event_b)",
    ),
    ttl: int = typer.Option(3600, "--ttl", help="Token TTL in seconds"),
) -> None:
    """Register a new Atlas app with auto-provisioned frontier bindings."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)

    wf_list, workflow_specs = _build_workflow_specs(
        workflows_csv=workflows,
        workflows=workflow,
        workflow_spec_entries=workflow_spec,
        workflow_specs_file=workflow_specs_file,
        binds=bind,
        pulses=pulse,
        event_entries=events,
    )
    if not wf_list:
        print_error("Provide --workflows, one or more --workflow values, or workflow specs")
        raise typer.Exit(1)

    result = client.atlas.register_app(
        app_name=name,
        app_family=family,
        declared_workflows=wf_list,
        workflow_specs=workflow_specs,
        token_ttl_seconds=ttl,
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return

    print_success(f"App registered: {name}")
    typer.echo("")
    typer.echo(f"  Client ID:     {result.get('client_id', '?')}")
    typer.echo(f"  Client Secret: {result.get('client_secret', '?')}  (save this — shown once)")
    typer.echo("")

    bindings = result.get("bindings", [])
    if bindings:
        typer.echo("  Auto-bound frontiers:")
        for b in bindings:
            typer.echo(f"    {b.get('workflow', '?')} -> {b.get('frontier', '?')}")

    workflow_specs_result = result.get("workflow_specs", [])
    if workflow_specs_result:
        typer.echo("\n  Workflow Specs:")
        for spec in workflow_specs_result:
            wf = spec.get("workflow", "?")
            frontier = spec.get("frontier_id") or "(auto)"
            pulse_type = spec.get("pulse_type") or "(default)"
            event_types = ", ".join(spec.get("event_types") or []) or "(none)"
            typer.echo(f"    {wf}: frontier={frontier} pulse={pulse_type} events={event_types}")

    typer.echo(f"\n  Next: sbn atlas token --client-id {result.get('client_id', '...')}")


# ── Token ────────────────────────────────────────────────────────────

@atlas_app.command("token")
def token(
    ctx: typer.Context,
    client_id: Optional[str] = typer.Option(None, "--client-id", envvar="ATLAS_CLIENT_ID"),
    client_secret: Optional[str] = typer.Option(None, "--client-secret", envvar="ATLAS_CLIENT_SECRET"),
) -> None:
    """Exchange client credentials for a short-lived bearer token."""
    config = load_config(ctx.obj)

    cid = client_id or config.atlas_client_id
    csec = client_secret or config.atlas_client_secret
    if not cid or not csec:
        print_error("Provide --client-id + --client-secret or set ATLAS_CLIENT_ID + ATLAS_CLIENT_SECRET")
        raise typer.Exit(1)

    client = get_sbn_client(config)
    result = client.atlas.exchange_token(client_id=cid, client_secret=csec)

    fmt = config.output_format
    if fmt == "quiet":
        print_quiet(result.get("access_token", ""))
        return
    if fmt == "json":
        print_json(result)
        return

    print_success(f"Token issued (expires in {result.get('expires_in', '?')}s)")
    typer.echo(f"\n  Bearer: {result.get('access_token', '?')}")


# ── Env ──────────────────────────────────────────────────────────────

@atlas_app.command("env")
def env(
    ctx: typer.Context,
    app_id: Optional[str] = typer.Option(None, "--app-id", help="App ID (auto-detected from Atlas credentials if omitted)"),
    format: str = typer.Option("dotenv", "--format", "-f", help="Output format: dotenv or json"),
) -> None:
    """Get provisioned environment variables for a registered Atlas app."""
    config = load_config(ctx.obj)

    if app_id:
        client = get_sbn_client(config)
        result = client.atlas.get_env(app_id, format=format)
    else:
        atlas = get_atlas(config)
        if format == "dotenv":
            result = atlas.dotenv()
        else:
            result = atlas.get_env(format=format)

    if isinstance(result, str):
        typer.echo(result, nl=False)
    else:
        print_json(result)


# ── Apps ─────────────────────────────────────────────────────────────

@atlas_app.command("apps")
def apps_list(ctx: typer.Context) -> None:
    """List registered Atlas apps."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.list_apps()

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return

    apps = result.get("apps", [])
    print_table(
        apps,
        [
            "app_name",
            "client_id",
            "declared_workflows",
            "bound_key_count",
            "attestation_ready",
            "status",
            "created_at",
        ],
    )


@atlas_app.command("revoke")
def revoke(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="App ID to revoke"),
    yes: bool = typer.Option(False, "--yes", "-y", help="Skip confirmation"),
) -> None:
    """Revoke an Atlas app and invalidate all its tokens."""
    if not yes:
        confirm = typer.confirm(f"Revoke app {app_id}? All tokens will be invalidated.")
        if not confirm:
            raise typer.Abort()

    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    client.atlas.revoke_app(app_id)
    print_success(f"App {app_id} revoked")


@keys_app.command("mint")
def keys_mint(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="Atlas app ID"),
    label: Optional[str] = typer.Option(None, "--label", "-l", help="Label for the new network key"),
    scope: list[str] = typer.Option(
        None,
        "--scope",
        help="Repeatable scope override (defaults to attest.write + receipts.read)",
    ),
) -> None:
    """Mint a new network key bound to an Atlas app."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.mint_bound_key(
        app_id,
        label=label,
        scopes=scope or None,
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(result.get("api_key", ""))
        return

    record = result.get("record", {})
    print_success(f"Minted Atlas key for app {app_id}")
    typer.echo("")
    print_kv(
        {
            "API Key": result.get("api_key", ""),
            "Prefix": result.get("prefix", record.get("prefix", "")),
            "Plan": record.get("plan", ""),
            "Scopes": ", ".join(record.get("scopes", []) or []),
            "Attestation Ready": result.get("attestation_ready", False),
        },
        highlights={"API Key", "Attestation Ready"},
    )
    effective_frontiers = result.get("effective_frontiers", [])
    if effective_frontiers:
        typer.echo("\n  Effective frontiers:")
        for frontier in effective_frontiers:
            typer.echo(f"    {frontier}")


@keys_app.command("bind")
def keys_bind(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="Atlas app ID"),
    key_id: str = typer.Argument(..., help="Existing network API key UUID"),
) -> None:
    """Bind an existing network key to an Atlas app."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.bind_existing_key(app_id, key_id=key_id)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(result.get("record", {}).get("id", ""))
        return

    record = result.get("record", {})
    print_success(f"Bound key {key_id} to app {app_id}")
    typer.echo("")
    print_kv(
        {
            "Key ID": record.get("id", key_id),
            "Prefix": record.get("prefix", ""),
            "Plan": record.get("plan", ""),
            "Attestation Ready": result.get("attestation_ready", False),
        },
        highlights={"Key ID", "Attestation Ready"},
    )
    effective_frontiers = result.get("effective_frontiers", [])
    if effective_frontiers:
        typer.echo("\n  Effective frontiers:")
        for frontier in effective_frontiers:
            typer.echo(f"    {frontier}")


@bindings_app.command("set")
def bindings_set(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="Atlas app ID"),
    workflow: str = typer.Option(..., "--workflow", "-w", help="Workflow lane name"),
    frontier: str = typer.Option(..., "--frontier", "-f", help="Frontier ID or canonical path"),
    pulse: Optional[str] = typer.Option(None, "--pulse", help="Pulse type for the workflow lane."),
    events: Optional[str] = typer.Option(None, "--events", help="Comma-separated declared event types."),
    history_action: Optional[str] = typer.Option(None, "--history-action", help="History action label, e.g. updated or restored."),
) -> None:
    """Set or replace a workflow frontier binding for an Atlas app."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    event_types = [item.strip() for item in events.split(",") if item.strip()] if events is not None else None
    result = client.atlas.upsert_binding(
        app_id,
        workflow=workflow,
        frontier_id=frontier,
        pulse_type=pulse,
        event_types=event_types,
        history_action=history_action,
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        binding = result.get("binding", {})
        print_quiet(binding.get("frontier", ""))
        return

    binding = result.get("binding", {})
    print_success(f"Bound workflow {workflow} to {binding.get('frontier', frontier)}")
    typer.echo("")
    print_kv(
        {
            "Workflow": binding.get("workflow", workflow),
            "Frontier": binding.get("frontier", frontier),
            "Pulse": binding.get("pulse_type", pulse or ""),
            "Events": ", ".join(binding.get("event_types") or event_types or []),
            "Source": binding.get("source_kind", ""),
            "Auto Provisioned": binding.get("auto_provisioned", False),
            "Attestation Ready": result.get("attestation_ready", False),
        },
        highlights={"Frontier", "Pulse", "Attestation Ready"},
    )


@bindings_app.command("history")
def bindings_history(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="Atlas app ID"),
    workflow: str = typer.Option(..., "--workflow", "-w", help="Workflow lane name"),
) -> None:
    """Show contract history for one Atlas workflow lane."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    app = _find_app_record(client, app_id)
    spec = _find_workflow_spec(app, workflow)
    history = _ordered_contract_history(spec)
    rows = []
    for idx, item in enumerate(history, start=1):
        rows.append(
            {
                "index": str(idx),
                "changed_at": str(item.get("changed_at") or ""),
                "action": str(item.get("action") or ""),
                "frontier": str(item.get("frontier_id") or ""),
                "pulse": str(item.get("pulse_type") or ""),
                "events": ", ".join(item.get("event_types") or []),
            }
        )

    fmt = config.output_format
    if fmt == "json":
        print_json({"app_id": app_id, "workflow": workflow, "history": history})
        return
    if fmt == "quiet":
        typer.echo("\n".join(row["changed_at"] for row in rows), nl=False)
        return

    print_success(f"Contract history for {workflow}")
    print_table(rows, ["index", "changed_at", "action", "frontier", "pulse", "events"])


@bindings_app.command("restore")
def bindings_restore(
    ctx: typer.Context,
    app_id: str = typer.Argument(..., help="Atlas app ID"),
    workflow: str = typer.Option(..., "--workflow", "-w", help="Workflow lane name"),
    index: int = typer.Option(..., "--index", min=1, help="History row number from `bindings history` (1 = newest)."),
) -> None:
    """Restore a workflow lane contract from one history snapshot."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    app = _find_app_record(client, app_id)
    spec = _find_workflow_spec(app, workflow)
    ordered = _ordered_contract_history(spec)
    if index > len(ordered):
        raise typer.BadParameter(
            f"History index {index} is out of range for workflow {workflow}",
            param_hint="--index",
        )
    snapshot = ordered[index - 1]
    result = client.atlas.upsert_binding(
        app_id,
        workflow=workflow,
        frontier_id=str(snapshot.get("frontier_id") or ""),
        pulse_type=str(snapshot.get("pulse_type") or "").strip() or None,
        event_types=[str(item).strip() for item in (snapshot.get("event_types") or []) if str(item).strip()],
        history_action="restored",
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(str(snapshot.get("frontier_id") or ""))
        return

    binding = result.get("binding", {})
    print_success(f"Restored workflow {workflow} from history row {index}")
    print_kv(
        {
            "Workflow": binding.get("workflow", workflow),
            "Frontier": binding.get("frontier", snapshot.get("frontier_id") or ""),
            "Pulse": binding.get("pulse_type", snapshot.get("pulse_type") or ""),
            "Events": ", ".join(binding.get("event_types") or snapshot.get("event_types") or []),
            "Changed At": snapshot.get("changed_at", ""),
            "Action": "restored",
        },
        highlights={"Frontier", "Pulse", "Action"},
    )


# ── Frontiers ────────────────────────────────────────────────────────

@atlas_app.command("frontiers")
def frontiers_list(
    ctx: typer.Context,
    family: Optional[str] = typer.Option(None, "--family", help="Filter by app family"),
    regime: Optional[str] = typer.Option(None, "--regime", help="Filter by regime (slack/intermediate/saturated)"),
    kind: Optional[str] = typer.Option(None, "--kind", help="Filter by frontier kind"),
) -> None:
    """List all frontiers in the Atlas registry."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.list_frontiers(kind=kind, family=family, regime=regime)

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return

    frontiers = result.get("frontiers", [])
    print_table(frontiers, ["canonical_path", "c_max", "regime", "metallic_label", "pulse_type"])


@atlas_app.command("tree")
def frontiers_tree(ctx: typer.Context) -> None:
    """Display frontier tree grouped by app family."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.list_frontiers()

    frontiers = result.get("frontiers", [])
    groups: dict[str, list] = {}
    for f in frontiers:
        family = f.get("app_family", "other")
        groups.setdefault(family, []).append(f)

    for family, items in sorted(groups.items()):
        typer.echo(f"\n{family}")
        for f in sorted(items, key=lambda x: x.get("canonical_path", "")):
            path = f.get("canonical_path", "?")
            subpath = path.replace(f"{family}.", "  ") if path != family else path
            kind = f.get("frontier_kind", "?")
            label = f.get("metallic_label", "")
            cmax = f.get("c_max")
            marker = " *" if kind == "scoring" else ""
            cmax_str = f", C_max={cmax}" if cmax else ""
            label_str = f", {label}" if label else ""
            typer.echo(f"  {subpath}{marker} ({kind}{cmax_str}{label_str})")


# ── Couplings ────────────────────────────────────────────────────────

@atlas_app.command("couplings")
def couplings_list(
    ctx: typer.Context,
    frontier_id: Optional[str] = typer.Option(None, "--frontier-id", help="Filter by frontier"),
    min_strength: float = typer.Option(0.0, "--min-strength", help="Minimum coupling strength"),
) -> None:
    """List detected frontier couplings."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.list_couplings(
        frontier_id=frontier_id,
        min_strength=min_strength,
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return

    couplings = result.get("couplings", [])
    print_table(couplings, ["frontier_a_id", "frontier_b_id", "coupling_type", "strength", "direction"])


@atlas_app.command("instrumentation")
def instrumentation(
    ctx: typer.Context,
    family: Optional[str] = typer.Option(None, "--family", help="Filter by app family"),
    frontier_id: Optional[str] = typer.Option(None, "--frontier-id", help="Filter by frontier canonical path"),
    event_type: Optional[str] = typer.Option(None, "--event-type", help="Filter by event type"),
    source_app: Optional[str] = typer.Option(None, "--source-app", help="Filter by source app"),
    window_days: int = typer.Option(14, "--window-days", help="Lookback window in days"),
    only_weak: bool = typer.Option(True, "--only-weak/--all", help="Show only weak instrumentation rows"),
    limit: int = typer.Option(10, "--limit", help="Max weak segments to return"),
) -> None:
    """Inspect Atlas instrumentation quality and weak frontier payload segments."""
    config = load_config(ctx.obj)
    atlas = get_atlas(config)
    result = atlas.get_instrumentation_report(
        family=family,
        frontier_id=frontier_id,
        event_type=event_type,
        source_app=source_app,
        window_days=window_days,
        only_weak=only_weak,
        limit=limit,
    )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return
    if fmt == "quiet":
        print_quiet(result.get("summary", {}).get("weak_events", 0))
        return

    summary = result.get("summary", {})
    print_success("Atlas instrumentation report")
    typer.echo("")
    print_kv(
        {
            "Family": result.get("family") or "(all)",
            "Frontier": result.get("frontier_id") or "(all)",
            "Source App": result.get("source_app") or "(all)",
            "Event Type": result.get("event_type") or "(all)",
            "Window Days": result.get("window_days", window_days),
            "Observed Events": summary.get("total_events", 0),
            "Strong Events": summary.get("strong_events", 0),
            "Weak Events": summary.get("weak_events", 0),
            "Weak Rate": f"{float(summary.get('weak_rate', 0.0)) * 100:.1f}%",
        },
        highlights={"Weak Events", "Weak Rate"},
    )

    status_counts = summary.get("status_counts") or {}
    if status_counts:
        typer.echo("\nContract Status Mix:")
        for status, count in sorted(status_counts.items(), key=lambda item: item[1], reverse=True):
            typer.echo(f"  {status}: {count}")

    missing_dimensions = summary.get("missing_dimension_counts") or {}
    if missing_dimensions:
        typer.echo("\nTop Missing Dimensions:")
        for dimension, count in sorted(missing_dimensions.items(), key=lambda item: item[1], reverse=True)[:6]:
            typer.echo(f"  {dimension}: {count}")

    weak_segments = result.get("weak_segments", [])
    if weak_segments:
        typer.echo("")
        print_table(
            [
                {
                    "frontier_id": row.get("frontier_id", ""),
                    "event_type": row.get("event_type", ""),
                    "source_app": row.get("source_app", ""),
                    "weak_rate": f"{float(row.get('weak_rate', 0.0)) * 100:.1f}%",
                    "weak_events": f"{row.get('weak_events', 0)}/{row.get('total_events', 0)}",
                    "missing_dims": ", ".join(row.get("sample_missing_dimensions", [])[:3]),
                }
                for row in weak_segments
            ],
            ["frontier_id", "event_type", "source_app", "weak_rate", "weak_events", "missing_dims"],
        )
    else:
        typer.echo("\nNo weak segments matched the current filters.")


@atlas_app.command("calibrate")
def calibrate(
    ctx: typer.Context,
    frontier_id: Optional[str] = typer.Option(None, "--frontier", "-f", help="Specific frontier to calibrate (omit for all)"),
    window_days: int = typer.Option(7, "--window", "-w", help="Lookback window in days"),
    force: bool = typer.Option(False, "--force", help="Skip cooldown check"),
) -> None:
    """Trigger CSK calibration from live efficiency data.

    Computes rolling C_max, CSK vector, metallic params, and regime.
    Creates new frontier_version, retires old one.
    """
    config = load_config(ctx.obj)
    client = get_sbn_client(config)

    if frontier_id:
        result = client.atlas.calibrate_frontier(
            frontier_id=frontier_id,
            window_days=window_days,
            force=force,
        )
    else:
        result = client.atlas.calibrate_all(
            window_days=window_days,
            force=force,
        )

    fmt = config.output_format
    if fmt == "json":
        print_json(result)
        return

    if frontier_id:
        print_success(f"Calibrated: {result.get('frontier', '?')}")
        typer.echo("")
        print_kv({
            "C_max": f"{result.get('previous_cmax', '?')} -> {result.get('c_max', '?')}",
            "Regime": result.get("regime", "?"),
            "Metallic": result.get("metallic_label", "?"),
            "Lambda": result.get("lambda_score", "?"),
            "Observations": result.get("observations", 0),
            "Version": result.get("version_tag", "?"),
        })
        csk = result.get("csk")
        if csk:
            typer.echo("\nCSK Vector:")
            print_csk_bars(csk)
    else:
        results = result.get("results", [])
        print_success(f"Calibrated {len(results)} frontiers")
        for r in results:
            typer.echo(f"  {r.get('frontier', '?')}: {r.get('previous_cmax', '?')} -> {r.get('c_max', '?')} ({r.get('regime', '?')})")


@atlas_app.command("detect")
def couplings_detect(ctx: typer.Context) -> None:
    """Manually trigger coupling detection."""
    config = load_config(ctx.obj)
    client = get_sbn_client(config)
    result = client.atlas.detect_couplings()

    detected = result.get("detected", 0)
    print_success(f"Coupling detection complete: {detected} new couplings detected")
    if config.output_format == "json":
        print_json(result)
