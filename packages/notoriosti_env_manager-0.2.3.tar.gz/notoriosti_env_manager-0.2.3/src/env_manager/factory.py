"""Factory helpers for building secret loaders."""

from __future__ import annotations

from typing import Optional

from env_manager.base import SecretLoader
from env_manager.environment import ORIGIN_ALIASES
from env_manager.loaders import DotEnvLoader, GCPSecretLoader

from env_manager.utils import logger


def create_loader(
    secret_origin: str,
    *,
    gcp_project_id: Optional[str] = None,
    dotenv_path: Optional[str] = None,
    encrypted: bool = False,
    environment_name: Optional[str] = None,
    explicit_private_key: Optional[str] = None,
) -> SecretLoader:
    """Instantiate the appropriate loader for ``secret_origin``."""

    origin = (secret_origin or "local").strip().lower()
    origin = ORIGIN_ALIASES.get(origin, origin)

    if origin == "local":
        logger.info("Loading secrets from .env")
        return DotEnvLoader(
            dotenv_path=dotenv_path,
            encrypted=encrypted,
            environment_name=environment_name,
            explicit_private_key=explicit_private_key,
        )

    if origin == "gcp":
        if not gcp_project_id:
            raise ValueError(
                "GCP project ID must be provided when SECRET_ORIGIN is 'gcp'."
            )
        logger.info("Loading secrets from GCP Secret Manager")
        return GCPSecretLoader(project_id=gcp_project_id)

    raise ValueError(
        f"Unsupported SECRET_ORIGIN '{secret_origin}'. "
        "Expected 'local' (aliases: 'dotenv', 'env-file', '.env') "
        "or 'gcp' (aliases: 'gcp-secretmanager', 'gcp-secret-manager', 'secretmanager')."
    )
