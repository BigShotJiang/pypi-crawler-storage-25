# logomesh

## What This Is
CLI / GitHub App / MCP server that finds logic bugs and edge-case failures in Python code by inferring invariants, then attacking them with adversarial inputs in a Docker sandbox. Only reports when it has concrete, reproducible evidence.

Primary surface: `logomesh repro <sentry-url>` — paste a Sentry issue URL, get a failing pytest against your current branch with audit-ready post-incident evidence mapped to **SOC2 CC7.3 + CC7.4 + PCI DSS 12.10.5** (incident response). Earlier docs referenced PCI 6.3.2 — that control covers pre-release code review and is the wrong mapping for a post-incident product. Corrected.

## Output Format
Lead with the violated property and the evidence.

```
## logomesh found 1 issue

### Negative quantity bypasses checkout validation
**Property:** Order total should always be ≥ 0
**I called:** `checkout(item_id=1, qty=-5)`
**Got:** Order created with total `-$49.95`
**Location:** checkout.py, line 42
```

No score. No preliminary comment. Silence = clean.

## Key Paths
- `src/cli/` — `repro.py`, `artifact.py`, `draft_pr.py`, `check.py`, `main.py`
- `src/oracles/sentry_replay.py` — Sentry event fetch, frame locals → pytest synthesis
- `src/business_logic/generator/` — inference, ast_analysis, codegen, models
- `src/business_logic/sandbox/` — Docker sandbox + `_TRACE_HOOK` injection
- `src/business_logic/classifier/` — pytest-output → findings, artifact suppression
- `src/business_logic/validator/`, `src/business_logic/scaffold_filter/` — LLM reachability + static drops
- `src/business_logic/deep_checks/` — static signals + deep probes
- `src/core/` — llm_utils, logomesh_log, usage_tracker, config
- `src/capture/` — runtime capture hooks (FastAPI, Django, SQLAlchemy, Redis, Stripe)
- `tests/` — 500 unit tests
- `docs/pipeline.md` — full pipeline walkthrough for contributors
- `Dockerfile.sandbox` — sandbox image (python:3.12-slim + pytest + pytest-json-report)
- `logomesh_legacy/` — archived GitHub App, MCP server, benchmark data (kept for reference)

## Architecture
Single-pass pipeline per changed Python file:
1. AST extracts public functions + testable dunders
2. **Passthrough gate** drops trivial wrappers (`_is_trivial_passthrough`)
3. LLM infers properties/invariants per surviving function
4. **Counter-impl probe** drops weak properties a wrong-impl could satisfy (1 batched LLM call/function)
5. Adversarial tests generated targeting remaining properties + edge-case / metamorphic / toxic variants
6. Executed in Docker sandbox (airgapped, nobody user, memory/PID limits, randomized report filename)
7. **Time-Travel Trace** hook captures `f_locals` at crash inside `target.py`
8. Classifier parses pytest output, drops automock-leak / Py2-builtin / scope-slice artifacts
9. Validator: LLM confirms crash is caller-reachable (1 call per finding)
10. Repro + base regression + two-signal gates
11. Formatter posts only if evidence survives

`logomesh repro` path:
1. Fetch Sentry event → extract innermost app frame + locals
2. PII redact frame locals (PAN regex + field-name matching)
3. Synthesize pytest from locals (deterministic) or LLM (default)
4. Run in sandbox → retry once on no-repro
5. Emit result / compliance artifact / draft PR

## Dev Commands
```bash
uv sync                    # install deps
uv run pytest tests/ -v    # run tests (500 passing)
docker build -t logomesh-startup-sandbox:latest -f Dockerfile.sandbox .
uv run logomesh repro <sentry-url>           # reproduce a crash
uv run logomesh repro <url> --artifact       # + PCI/SOC2 envelope
uv run logomesh repro <url> --draft-pr       # + open GitHub draft PR
uv run logomesh check <path>                 # run check pipeline on local file
```

## Key Design Rules
- Only report findings with concrete evidence (violated property + reproducible input/output)
- Never pip install from PR/user code in sandbox
- Webhook must ACK in <10s — enqueue and process asynchronously
- Semaphore(3) concurrency limit, 120s pipeline timeout
- Graceful degradation: no Docker → subprocess fallback; LLM fails → edge-case tests only
- Tests must NOT wrap calls in try/except
- Sandbox: path traversal protection, 512KB file size cap, binary rejection
- Generator input capped at 4000 chars; retry once on LLM failure
- PII redaction runs before any frame locals reach LLM or generated test code

## What Was Removed (do not resurrect)
- `red_logic/` — MCTS orchestrator, dependency_analyzer, semantic_analyzer, constraint_breaker
- `scoring.py` / CIS formula — meaningless for PRs
- `compare_vectors.py` / VectorScorer — 400MB model, not needed
- `analyzer.py` / SemanticAuditor — not used in pipeline
- Two-pass pipeline / preliminary comment — post nothing until crash confirmed
- `src/github_app/`, `src/mcp_server/` — moved to `logomesh_legacy/` (deprioritized surfaces)
