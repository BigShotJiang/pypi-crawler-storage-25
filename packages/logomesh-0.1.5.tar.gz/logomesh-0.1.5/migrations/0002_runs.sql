-- Per-run audit log. One row per orchestrator dispatch.
--
-- The wizard reads this via GET /api/installations/{id}/runs to show
-- "your last 20 runs" with status + verdict + cost. It is also the
-- source of truth for the artifact endpoint
-- (GET /api/installations/{id}/runs/{run_id}/artifact).

create table if not exists runs (
    run_id                    uuid primary key default gen_random_uuid(),
    installation_id           uuid not null
        references installations(installation_id) on delete cascade,
    sentry_issue_id           text not null,
    status                    text not null,
        -- shipped | human_review | error | in_progress
    verified_exception_match  boolean,
    sandbox_exception_type    text,
    expected_exception_type   text,
    duration_s                numeric,
    pr_url                    text,
    sentry_comment_url        text,
    test_sha256_first16       text,
    needs_human_review        boolean,
    human_review_reason       text,
    cost_usd                  numeric,
    tokens_in                 int,
    tokens_out                int,
    artifact                  jsonb,
        -- optional: full artifact envelope for /artifact endpoint
    created_at                timestamptz not null default now(),
    finished_at               timestamptz
);

create index if not exists runs_installation_created_idx
    on runs (installation_id, created_at desc);

alter table runs enable row level security;
drop policy if exists "service role full access" on runs;
create policy "service role full access"
    on runs
    for all
    using (auth.role() = 'service_role')
    with check (auth.role() = 'service_role');
