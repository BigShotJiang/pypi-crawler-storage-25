-- LogoMesh — installations + per-install secrets.
--
-- This migration replaces the old numeric-id schema with a UUID
-- primary key so the public wizard URL doesn't expose a sequential
-- counter. The orchestrator and Sentry webhook layer use the same
-- UUID throughout.
--
-- Idempotent: re-runnable. Encryption: the application encrypts each
-- secret value with AES-256-GCM before writing. The DB sees only
-- opaque base64 blobs prefixed with `lmsec-v1:`.

create extension if not exists "pgcrypto";

create table if not exists installations (
    installation_id uuid primary key default gen_random_uuid(),
    owner           text,
    account_type    text default 'organization',
    created_at      timestamptz not null default now(),
    deleted_at      timestamptz
);

create table if not exists installation_secrets (
    installation_id        uuid primary key
        references installations(installation_id) on delete cascade,
    sentry_auth_token      text,
    sentry_client_secret   text,
    github_token           text,
    github_repo            text,                  -- plaintext: owner/repo identifier
    openai_api_key         text,
    slack_webhook_url      text,
    repo_path              text,                  -- plaintext: filesystem path
    created_at             timestamptz not null default now(),
    updated_at             timestamptz not null default now(),
    rotated_at             timestamptz
);

create index if not exists installation_secrets_rotated_at_idx
    on installation_secrets (rotated_at);

alter table installation_secrets enable row level security;
drop policy if exists "service role full access" on installation_secrets;
create policy "service role full access"
    on installation_secrets
    for all
    using (auth.role() = 'service_role')
    with check (auth.role() = 'service_role');
