package docker.security.no_root

import future.keywords.in

# Deny explicit USER root
deny[msg] {
    stage := input.Stages[_]
    cmd := stage.Commands[_]
    cmd.Cmd == "user"
    lower(cmd.Value[0]) == "root"
    msg := sprintf("Stage '%s': USER root is prohibited. Containers must run as a non-root user.", [stage.BaseName])
}

# Warn if no USER instruction exists at all (defaults to root in Docker)
warn[msg] {
    stage := input.Stages[_]
    not _has_user(stage.Commands)
    not _is_scratch(stage.BaseName)
    msg := sprintf("Stage '%s': no USER instruction found — container will run as root by default.", [stage.BaseName])
}

_has_user(cmds) {
    cmd := cmds[_]
    cmd.Cmd == "user"
    lower(cmd.Value[0]) != "root"
}

_is_scratch(base) {
    lower(base) == "scratch"
}
