package docker.security.registry_allowlist

import future.keywords.in

# Only images from these registries are permitted as base images.
# Mirrors the Gatekeeper AllowedRepos constraint used in production clusters.
_allowed_prefixes := {
    "python:",
    "python@sha256:",
    "gcr.io/distroless/python",
    "ghcr.io/",
    "scratch",
}

deny[msg] {
    stage := input.Stages[_]
    base := lower(stage.BaseName)
    not _is_allowed(base)
    msg := sprintf(
        "Stage '%s': base image '%s' is not in the allowlist. Use an image from: %v",
        [stage.BaseName, stage.BaseName, _allowed_prefixes],
    )
}

_is_allowed(base) {
    prefix := _allowed_prefixes[_]
    startswith(base, prefix)
}
