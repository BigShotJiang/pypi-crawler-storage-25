package docker.security.secure_defaults

import future.keywords.in

# ADD with a URL bypasses content verification — use COPY or RUN curl + checksum.
deny[msg] {
    stage := input.Stages[_]
    cmd := stage.Commands[_]
    cmd.Cmd == "add"
    val := cmd.Value[_]
    startswith(lower(val), "http")
    msg := sprintf(
        "Stage '%s': ADD with URL '%s' is prohibited. Use COPY or verify the download with a checksum.",
        [stage.BaseName, val],
    )
}

# EXPOSE of privileged ports (<1024) is a red flag in sandbox images.
warn[msg] {
    stage := input.Stages[_]
    cmd := stage.Commands[_]
    cmd.Cmd == "expose"
    port_str := cmd.Value[_]
    port := to_number(split(port_str, "/")[0])
    port < 1024
    msg := sprintf(
        "Stage '%s': EXPOSE port %d is a privileged port (<1024). Sandbox images should not listen on privileged ports.",
        [stage.BaseName, port],
    )
}

# ENV vars whose key names look like secrets risk baking credentials into the image layer.
# Handles both ENV key=value (new form) and ENV key value (old form) by splitting on "=".
_secret_patterns := {"password", "secret", "token", "api_key", "private_key", "auth_key", "access_key"}

warn[msg] {
    stage := input.Stages[_]
    cmd := stage.Commands[_]
    cmd.Cmd == "env"
    val := cmd.Value[_]
    key := lower(split(val, "=")[0])
    pattern := _secret_patterns[_]
    contains(key, pattern)
    msg := sprintf(
        "Stage '%s': ENV key '%s' looks like a secret. Use build-time secrets (--secret) or runtime injection instead.",
        [stage.BaseName, split(val, "=")[0]],
    )
}
