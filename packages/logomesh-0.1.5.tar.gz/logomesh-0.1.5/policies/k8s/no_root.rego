package k8s.security.no_root

import future.keywords.in

# Mirrors Gatekeeper's K8sPSPNoRootUsers ConstraintTemplate.
# Applied to Pod, Deployment, Job, CronJob specs.

deny[msg] {
    container := _containers[_]
    sc := object.get(container, "securityContext", {})
    object.get(sc, "runAsNonRoot", false) == false
    not object.get(sc, "runAsUser", null)
    msg := sprintf("Container '%s': securityContext.runAsNonRoot must be true or runAsUser must be non-zero.", [container.name])
}

deny[msg] {
    container := _containers[_]
    sc := object.get(container, "securityContext", {})
    object.get(sc, "runAsUser", null) == 0
    msg := sprintf("Container '%s': runAsUser 0 (root) is not allowed.", [container.name])
}

_containers[c] {
    c := input.spec.containers[_]
}

_containers[c] {
    c := input.spec.template.spec.containers[_]
}

_containers[c] {
    c := input.spec.jobTemplate.spec.template.spec.containers[_]
}
