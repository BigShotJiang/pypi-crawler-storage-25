package k8s.security.resource_limits

import future.keywords.in

# Mirrors Gatekeeper's K8sRequiredResources ConstraintTemplate.
# Without limits, a single runaway container can OOM a node —
# critical in multi-tenant fintech clusters.

deny[msg] {
    container := _containers[_]
    resources := object.get(container, "resources", {})
    limits := object.get(resources, "limits", {})
    not object.get(limits, "memory", null)
    msg := sprintf("Container '%s': resources.limits.memory is required.", [container.name])
}

deny[msg] {
    container := _containers[_]
    resources := object.get(container, "resources", {})
    limits := object.get(resources, "limits", {})
    not object.get(limits, "cpu", null)
    msg := sprintf("Container '%s': resources.limits.cpu is required.", [container.name])
}

warn[msg] {
    container := _containers[_]
    resources := object.get(container, "resources", {})
    not object.get(resources, "requests", null)
    msg := sprintf("Container '%s': resources.requests is recommended alongside limits.", [container.name])
}

_containers[c] {
    c := input.spec.containers[_]
}

_containers[c] {
    c := input.spec.template.spec.containers[_]
}

_containers[c] {
    c := input.spec.jobTemplate.spec.template.spec.containers[_]
}
