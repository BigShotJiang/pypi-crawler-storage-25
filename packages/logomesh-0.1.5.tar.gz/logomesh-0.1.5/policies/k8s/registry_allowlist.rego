package k8s.security.registry_allowlist

import future.keywords.in

# Mirrors Gatekeeper's K8sAllowedRepos ConstraintTemplate.
# Only images from these prefixes are permitted in the cluster.
_allowed_prefixes := {
    "python:",
    "python@sha256:",
    "gcr.io/distroless/",
    "ghcr.io/logomesh/",
    "docker.io/library/python",
}

deny[msg] {
    container := _containers[_]
    image := container.image
    not _image_allowed(lower(image))
    msg := sprintf(
        "Container '%s': image '%s' is not from an approved registry. Allowed prefixes: %v",
        [container.name, image, _allowed_prefixes],
    )
}

_image_allowed(image) {
    prefix := _allowed_prefixes[_]
    startswith(image, prefix)
}

_containers[c] {
    c := input.spec.containers[_]
}

_containers[c] {
    c := input.spec.template.spec.containers[_]
}

_containers[c] {
    c := input.spec.jobTemplate.spec.template.spec.containers[_]
}
