package k8s.security.readonly_rootfs

import future.keywords.in

# Mirrors Gatekeeper's K8sPSPReadOnlyRootFilesystem ConstraintTemplate.
# Production fintech clusters enforce this universally — writable rootfs
# allows post-exploit persistence (dropping binaries, modifying configs).

deny[msg] {
    container := _containers[_]
    sc := object.get(container, "securityContext", {})
    object.get(sc, "readOnlyRootFilesystem", false) != true
    msg := sprintf(
        "Container '%s': securityContext.readOnlyRootFilesystem must be true. Mount writable volumes explicitly via volumeMounts.",
        [container.name],
    )
}

_containers[c] {
    c := input.spec.containers[_]
}

_containers[c] {
    c := input.spec.template.spec.containers[_]
}

_containers[c] {
    c := input.spec.jobTemplate.spec.template.spec.containers[_]
}
