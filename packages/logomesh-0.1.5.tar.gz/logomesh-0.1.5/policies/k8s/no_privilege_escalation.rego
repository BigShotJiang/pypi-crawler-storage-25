package k8s.security.no_privilege_escalation

import future.keywords.in

# Mirrors Gatekeeper's K8sPSPPrivilegeEscalationDeny ConstraintTemplate.
# allowPrivilegeEscalation: false prevents a container from gaining
# more privileges than its parent process (setuid, capabilities, etc.).

deny[msg] {
    container := _containers[_]
    sc := object.get(container, "securityContext", {})
    object.get(sc, "allowPrivilegeEscalation", true) != false
    msg := sprintf(
        "Container '%s': securityContext.allowPrivilegeEscalation must be false.",
        [container.name],
    )
}

deny[msg] {
    container := _containers[_]
    sc := object.get(container, "securityContext", {})
    object.get(sc, "privileged", false) == true
    msg := sprintf("Container '%s': privileged mode is not permitted.", [container.name])
}

# Cap drop ALL is the companion to allowPrivilegeEscalation: false.
warn[msg] {
    container := _containers[_]
    sc := object.get(container, "securityContext", {})
    caps := object.get(sc, "capabilities", {})
    drop := object.get(caps, "drop", [])
    not "ALL" in drop
    msg := sprintf(
        "Container '%s': capabilities.drop should include 'ALL'. Drop all, then add back only what's needed.",
        [container.name],
    )
}

_containers[c] {
    c := input.spec.containers[_]
}

_containers[c] {
    c := input.spec.template.spec.containers[_]
}

_containers[c] {
    c := input.spec.jobTemplate.spec.template.spec.containers[_]
}
