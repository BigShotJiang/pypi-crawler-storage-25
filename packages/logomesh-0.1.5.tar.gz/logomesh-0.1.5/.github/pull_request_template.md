## What does this PR do?

<!-- Brief description of the change -->

## Related issue

<!-- Link to the issue this PR addresses, e.g. Fixes #123 -->

## How was this tested?

<!-- Describe how you verified the change works -->

## Checklist

- [ ] My changes don't break existing functionality
- [ ] I've tested locally with `uv run pytest tests/ -v`
