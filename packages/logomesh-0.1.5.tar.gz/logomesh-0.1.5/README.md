# logomesh

![PyPI](https://img.shields.io/pypi/v/logomesh) ![License: MIT](https://img.shields.io/badge/license-MIT-green) ![Status: Alpha](https://img.shields.io/badge/status-alpha-orange)

Paste a Sentry URL. Get a failing pytest back.

```bash
pip install logomesh
logomesh repro https://sentry.io/organizations/your-org/issues/12345678/
```

---

## Why logomesh

- **Deterministic test synthesis** — no LLM touches the test bytes. The pytest comes from a pure function of your frame locals.
- **Verified reproduction** — the sandbox must raise the same exception type Sentry captured. If it doesn't, it refuses to ship.
- **Runs on your machine** — your Sentry token, your Docker, your repo. Nothing phones home.
- **PII redaction built in** — strips card numbers, emails, JWTs, API keys, and sensitive field names before anything hits an LLM.
- **Audit-ready** — every artifact carries `llm_in_evidence_path: false`, a SHA-256 stamp, and SOC2/PCI control mapping.

---

## Requirements

- Python 3.11+
- Docker running locally
- Sentry auth token with `event:read` scope (`Settings → API Keys`)
- OpenAI API key (powers the agent — context recovery, dep pinning, source resolution, retries)

```bash
export SENTRY_AUTH_TOKEN=sntryu_...
export OPENAI_API_KEY=sk-...
```

Or drop them in a `.env` file in your project root.

---

## Usage

```bash
logomesh repro <sentry-url>                  # reproduce a crash
logomesh repro <url> --no-llm               # deterministic only, skip LLM
logomesh repro <url> --artifact             # emit SOC2/PCI audit artifact
logomesh repro <url> --draft-pr             # open GitHub draft PR with failing test
logomesh repro <url> --json                 # machine-readable output
logomesh repro <url> --repo /path/to/repo   # point at local repo (default: cwd)
logomesh repro <url> --timeout 120          # wall-clock timeout in seconds
```

Supported Sentry URL formats:
```
https://sentry.io/organizations/{org}/issues/{id}/
https://sentry.io/issues/{id}/
https://{org}.sentry.io/issues/{id}/
```

---

## Example output

```
  ✓ Reproduced: ZeroDivisionError at billing/calc.py:18
     division by zero
     rate = total / count
```

```
  ✗ Cannot reproduce ValueError at checkout.py:42
     The synthesized test passed against the current branch.
     Either the bug is fixed, or the captured locals are insufficient.
```

---

## How it works

1. Fetches the innermost in-app frame + locals from your Sentry event
2. PII redaction runs before any data touches an LLM
3. Builds a pytest deterministically from the captured locals
4. Runs it in an airgapped Docker sandbox (128 MB, no network, `nobody` user)
5. Verifies the sandbox raised the same exception type Sentry captured
6. Emits the failing test — or a structured reason it couldn't reproduce

A LangGraph agent handles context recovery, dep pinning, source resolution, and retries. It's advisory — it never writes the test or the artifact.

Full architecture details → [GitHub](https://github.com/LogoMesh/LogoMesh-Dev)

---

## What reproduces well

- Input validation bugs, `NoneType` mismatches, type coercion errors
- Off-by-one, ordering, idempotency issues
- Anything where the crash inputs are captured in the Sentry frame

## What doesn't

- Race conditions, distributed failures, live DB/Redis state not in the frame
- C extension crashes, timezone/DST edge cases (sandbox runs `TZ=UTC`)

When it can't reproduce, it says so with a structured reason. Never guesses.

---

## Sentry setup

Frame locals must be enabled:

```python
sentry_sdk.init(dsn="...", send_default_pii=True)
```

Or: `Project Settings → SDK Setup → Enable "Send default PII"`

---

## License

MIT
