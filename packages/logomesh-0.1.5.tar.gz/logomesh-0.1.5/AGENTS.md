# AGENTS.md

## Mission and product constraints
- logomesh is post-incident **deterministic repro with proof**: only ship artifacts/PRs/comments when `deterministic_repro` reproduces and the exception type matches (`logomesh_orchestrator.py`, `src/oracles/sentry_replay_v2.py`, `src/cli/artifact.py`).
- Keep output evidence-first and terse (repro call -> observed result, expected property, location/state) and never add scores or "looks good" comments; non-repro or mismatch should stay silent or `needs_human_review` (`src/cli/repro.py`, `src/server/sentry_comment.py`, `src/server/github_comment.py`).
- LLM output is advisory only; evidence-path test bytes are deterministic from frame locals (`logomesh_orchestrator.py`, `src/oracles/sentry_replay_v2.py`).

## Pipeline mental model (read this first)
- Sentry webhook ingress is fast-ACK + async dispatch: verify HMAC signature + timestamp window + idempotency, then 202 ACK and semaphore-limited dispatch (`src/server/sentry_webhook.py`).
- Core repro flow: fetch event -> innermost in-app frame -> resolve source -> build deterministic test -> sandbox run -> verify exception match (`src/oracles/sentry_replay.py`, `src/oracles/sentry_replay_v2.py`, `src/business_logic/sandbox/__init__.py`).
- LangGraph orchestrator wraps the deterministic core: only `deterministic_repro` yields sealed bytes; other tools are advisory (context, deps prep, commenting) (`logomesh_orchestrator.py`).
- `logomesh repro` is the primary product path; `logomesh check` runs the single-file verify pipeline (`src/cli/repro.py`, `src/cli/check.py`, `src/core/pipeline.py`).

## Project-specific conventions that matter
- Single-file verification in `verify_file`: build change scope -> pack parseable source -> make sandbox importable -> generate tests -> cap tests -> inject target stubs -> dependency-aware sandbox run -> classify -> validate -> repro/regression gate -> `VerifyResult` (`src/core/pipeline.py`, `src/core/repro_gate.py`).
- Property-inference preprocessing gates (fire before any LLM call): (a) `_is_trivial_passthrough` drops wrapper functions whose body is a single delegation (`return self.inner(...)`); (b) arity filter drops properties whose `input_code` doesn't match the function signature; (c) `_is_identity_dunder_property` drops no-op assertions on dunders; (d) `_counter_impl_probe` (one batched LLM call per function, gated by `ENABLE_COUNTER_IMPL_PROBE`, default on) drops properties that a semantically-wrong implementation could still satisfy — bias toward keeping on parse failure. These gates live in `src/business_logic/generator/inference.py` and are wired into BOTH `inference.infer_properties` and the legacy compat shim `src/business_logic/legacy/generator.py` (where `PropertyTestGenerator` actually resolves `infer_properties` / `infer_metamorphic_properties` from). Do not edit legacy's copy without also updating or re-importing from inference.
- Spotlighting is on by default in inference (`ENABLE_SPOTLIGHTING`): untrusted source is sentinel-rewritten per call before prompt assembly to blunt prompt-injection instructions embedded in code/comments (`_spotlight` in `src/business_logic/generator/inference.py`).
- Time-Travel Trace: the sandbox conftest (`_TRACE_HOOK` injected in both `_CONFTEST_AUTOMOCK` and `_CONFTEST_STRICT`) installs a `pytest_exception_interact` hook that walks the traceback to the frame inside `target.py`, captures its `f_locals` (with size/type guards), and writes `{func, lineno, locals}` into `finding.trace` (`src/business_logic/sandbox/__init__.py`, `src/business_logic/classifier/core.py`).
- Classifier artifact suppressors in `src/business_logic/classifier/core.py`: (a) `_trace_has_automock_leak` drops findings whose trace shows `MagicMock` in `target.py` locals (sandbox automock leaked into user code); (b) `_PY2_BUILTINS` set drops `NameError` for Py2-only names (`unicode`, `basestring`, ...) that are unreachable under Python 3 execution; (c) salt dunder globals (`__opts__`, `__salt__`, ...) are dropped as SaltStack-runtime-injected symbols. These filters must stay — they are the reason fabric-style Py2-compat guard FPs stay suppressed.
- Files with import chains known to fail sandbox collection are skipped early as structurally untestable (`is_structurally_untestable`, currently Twisted/Scrapy fragments) and counted in taxonomy (`src/business_logic/generator/inference.py`).
- Test generation must **not** wrap calls in `try/except`; failures should surface to pytest/classifier (`src/business_logic/generator/`).
- Function extraction is underscore-aware but not "public-only": runtime dunders in `_TESTABLE_DUNDERS` and modified `__init__` paths are intentionally testable; don't reintroduce blanket `_` filtering (`src/business_logic/generator/ast_analysis.py`).
- Diff-aware scope is semantic, not raw line fuzzing: changed symbols are extracted and packed into parseable source slices (`src/business_logic/change_scope/`, `src/core/pipeline.py`).
- Sandbox importability is intentionally rewritten: relative imports/external bases/module-level call assignments are mocked to keep `target.py` importable (`make_sandbox_importable` in `src/business_logic/legacy/generator.py`).
- Sandbox runs are dependency-aware: `Sandbox.run_dependency_aware` accepts dependency files and optional `deps_snapshot` mounts; orchestrator `prepare_environment` can build a snapshot when imports fail (`src/business_logic/sandbox/__init__.py`, `logomesh_orchestrator.py`).
- Logs are structured JSON only (`log.info/warn/error`) via `src/logomesh_log.py`; preserve `component` names for grepability.

## External integrations and boundaries
- Sentry webhook auth uses HMAC-SHA256 + timestamp replay window; idempotency is `(issue_id, sha256(payload))` with a 24h in-process LRU; concurrency is capped via `LOGOMESH_MAX_CONCURRENT_RUNS` (`src/server/sentry_webhook.py`).
- Supabase-backed installations + runs: secrets are AES-256-GCM encrypted and `resolve_secrets()` falls back to env vars; `supabase_client` uses an in-memory shim when credentials are missing (`src/core/installation_secrets.py`, `src/core/supabase_client.py`, `migrations/`).
- GitHub draft PRs use `gh` CLI first, then REST with `GITHUB_TOKEN` + `GITHUB_REPO`; server comment posting uses per-install tokens (`src/cli/draft_pr.py`, `src/server/github_comment.py`).
- Sentry + Slack comments are posted from the server layer using per-install secrets (`src/server/sentry_comment.py`, `src/server/slack_summary.py`).
- LLM provider selection is env-driven (`OPENAI_API_KEY` preferred, Anthropic/Gemini-compatible fallback); temperature/reasoning args come from `src/llm_utils.py`.
- Sandbox supports Docker hardened runs with subprocess fallback for local dev; path traversal protections and output redaction live in the sandbox (`src/business_logic/sandbox/__init__.py`).

## Developer workflows (high signal)
- Install deps: `uv sync`
- Run tests: `uv run pytest tests/ -v`
- Build sandbox image (required for realistic runs): `docker build -t logomesh-startup-sandbox:latest -f Dockerfile.sandbox .`
- Run repro: `uv run logomesh repro <sentry-url>`
- Emit artifact: `uv run logomesh repro <url> --artifact`
- Draft PR: `uv run logomesh repro <url> --draft-pr`
- Run local verify: `uv run logomesh check <path>`
- Run API server locally: `LOGOMESH_ENV=production uv run uvicorn src.server.app:app --port 8080`
- Replay a historical run: `uv run python scripts/replay_run.py --from results/real_prs_run_3.json --out results/replay_from_run3_current.json`
- Enforce quality gates (also in CI): `UV_CACHE_DIR=/tmp/uv-cache uv run python scripts/quality_gates.py --run results/real_prs_run_6.json --replay results/replay_from_run3_current.json --out results/quality_gates_latest.json --strict`
- Apply Supabase migrations: `psql $SUPABASE_DB_URL -f migrations/0001_installation_secrets.sql` and `psql $SUPABASE_DB_URL -f migrations/0002_runs.sql` (or `supabase db push`)
- CI (`.github/workflows/ci.yml`) runs `pytest tests/ -v` on every push/PR; quality gates run only when `ENFORCE_LOGOMESH_QUALITY_GATES=1` is set

## Where to look before editing
- Orchestrator + compliance gates: `logomesh_orchestrator.py`
- Deterministic repro + Sentry parsing: `src/oracles/sentry_replay_v2.py`, `src/oracles/sentry_replay.py`
- CLI entrypoints + artifact/PR output: `src/cli/repro.py`, `src/cli/check.py`, `src/cli/artifact.py`, `src/cli/draft_pr.py`
- Core verify pipeline + repro gate: `src/core/pipeline.py`, `src/core/repro_gate.py`
- Webhooks/API + comment channels: `src/server/sentry_webhook.py`, `src/server/installations_api.py`, `src/server/github_comment.py`, `src/server/sentry_comment.py`, `src/server/slack_summary.py`
- Secrets + persistence: `src/core/installation_secrets.py`, `src/core/supabase_client.py`, `migrations/`
- Sandbox security and execution modes: `src/business_logic/sandbox/__init__.py`
- Generation + validation: `src/business_logic/generator/`, `src/business_logic/validator/`, `src/business_logic/scaffold_filter/__init__.py`
- Diff/change-scope logic: `src/business_logic/change_scope/`
- Deep debug walkthrough: `docs/pipeline.md`
- Launch/replay gate definitions: `docs/refs/QUALITY_GATES.md`
- Production deployment runbook (systemd/nginx/webhook wiring): `docs/refs/DEPLOYMENT.md`
