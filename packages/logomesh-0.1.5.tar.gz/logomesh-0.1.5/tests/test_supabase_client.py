import os
os.environ["ENABLE_SUPABASE"] = "0"  # disable for unit tests

import supabase_client

def test_noop_when_disabled():
    # All methods should be silent no-ops when ENABLE_SUPABASE=0
    supabase_client.upsert_installation(1, "acme", "Organization")
    supabase_client.purge_installation(1)
    supabase_client.log_usage(1, "acme", "api", 1, 2, 0, 100, 50, 0.001)
    result = supabase_client.get_usage_summary()
    assert result == []
