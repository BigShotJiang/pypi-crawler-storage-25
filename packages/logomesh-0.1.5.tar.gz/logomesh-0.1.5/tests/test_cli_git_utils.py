"""Tests for src/cli/git_utils.py — git diff helpers used by `logomesh check`."""

import subprocess
from pathlib import Path

from cli.git_utils import (
    get_base_content,
    get_repo_relative_path,
    get_repo_root,
    get_staged_python_files,
)


def _git(*args, cwd):
    return subprocess.run(["git", "-C", str(cwd), *args],
                          capture_output=True, text=True, check=True)


def _init_repo(tmp_path: Path) -> Path:
    _git("init", "-q", "-b", "main", cwd=tmp_path)
    _git("config", "user.email", "test@example.com", cwd=tmp_path)
    _git("config", "user.name", "Test", cwd=tmp_path)
    return tmp_path


def test_get_repo_root_inside_git_repo(tmp_path):
    repo = _init_repo(tmp_path)
    sub = repo / "src" / "billing"
    sub.mkdir(parents=True)
    assert get_repo_root(sub) == repo.resolve()


def test_get_repo_root_returns_none_outside_git(tmp_path):
    # tmp_path is not a git repo
    assert get_repo_root(tmp_path) is None


def test_get_base_content_returns_committed_version(tmp_path):
    repo = _init_repo(tmp_path)
    f = repo / "x.py"
    f.write_text("def f(): return 1\n")
    _git("add", "x.py", cwd=repo)
    _git("commit", "-q", "-m", "initial", cwd=repo)

    # Modify working tree
    f.write_text("def f(): return 2\n")

    base = get_base_content(f)
    assert base == "def f(): return 1\n"


def test_get_base_content_empty_for_untracked_file(tmp_path):
    repo = _init_repo(tmp_path)
    f = repo / "new.py"
    f.write_text("def new(): pass\n")
    # never `git add`'d → empty base
    assert get_base_content(f) == ""


def test_get_base_content_empty_when_not_in_repo(tmp_path):
    f = tmp_path / "loose.py"
    f.write_text("def x(): pass\n")
    assert get_base_content(f) == ""


def test_get_repo_relative_path_inside_repo(tmp_path):
    repo = _init_repo(tmp_path)
    sub = repo / "src"
    sub.mkdir()
    f = sub / "foo.py"
    f.write_text("")
    assert get_repo_relative_path(f) == "src/foo.py"


def test_get_repo_relative_path_falls_back_to_basename(tmp_path):
    f = tmp_path / "loose.py"
    f.write_text("")
    assert get_repo_relative_path(f) == "loose.py"


def test_get_staged_python_files_returns_added_modified_only(tmp_path, monkeypatch):
    repo = _init_repo(tmp_path)
    (repo / "tracked.py").write_text("def f(): return 1\n")
    (repo / "README.md").write_text("not python")
    _git("add", ".", cwd=repo)
    _git("commit", "-q", "-m", "init", cwd=repo)

    # Stage a modification + a new file + a non-python file
    (repo / "tracked.py").write_text("def f(): return 2\n")
    (repo / "new.py").write_text("def g(): pass\n")
    (repo / "doc.md").write_text("not python either")
    _git("add", "tracked.py", "new.py", "doc.md", cwd=repo)

    monkeypatch.chdir(repo)
    staged = get_staged_python_files()
    names = sorted(p.name for p in staged)
    assert names == ["new.py", "tracked.py"]
