"""Unit tests for _tool_prepare_environment.

Coverage:
  1. parses repo manifests into specs
  2. extracts missing modules from sandbox stderr
  3. PyPI-name mapping (PIL→Pillow, sklearn→scikit-learn, etc.)
  4. dedup against already-declared specs
  5. graceful degradation when docker/dep_installer is unavailable
  6. compliance: artifact stamps environment_prep OUTSIDE evidence_path_seal
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from unittest import mock

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))
sys.path.insert(0, str(_REPO_ROOT / "src"))

import logomesh_orchestrator as o  # noqa: E402


def test_missing_modules_regex_basic():
    text = (
        "ImportError while loading conftest...\n"
        "E   ModuleNotFoundError: No module named 'stripe'\n"
        "E   ModuleNotFoundError: No module named 'redis'\n"
    )
    assert o._missing_modules_from_error(text) == ["stripe", "redis"]


def test_missing_modules_strips_submodule():
    text = "E   ModuleNotFoundError: No module named 'sqlalchemy.orm'"
    assert o._missing_modules_from_error(text) == ["sqlalchemy"]


def test_missing_modules_handles_cannot_import_name():
    text = (
        "ImportError: cannot import name 'foo' from 'bar.baz'"
    )
    assert "bar" in o._missing_modules_from_error(text)


def test_module_to_pypi_known_mapping():
    assert o._module_to_pypi("PIL") == "Pillow"
    assert o._module_to_pypi("cv2") == "opencv-python"
    assert o._module_to_pypi("yaml") == "PyYAML"
    # Unknown falls through.
    assert o._module_to_pypi("totally_made_up_pkg") == "totally_made_up_pkg"


def test_gather_repo_dependency_files(tmp_path: Path):
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "x"\nversion = "0"\n'
        'dependencies = ["stripe>=12", "redis"]\n'
    )
    (tmp_path / "requirements.txt").write_text("httpx==0.27\n")
    out = o._gather_repo_dependency_files(str(tmp_path))
    assert "pyproject.toml" in out
    assert "requirements.txt" in out
    assert "stripe" in out["pyproject.toml"]


def test_prepare_environment_no_specs_no_missing(tmp_path: Path):
    """Empty repo + no sandbox error → success with empty snapshot."""
    sid = "test_sess_1"
    o._AUDIT_REGISTRY[sid] = o.AuditSession(sid)
    try:
        raw = asyncio.run(o._tool_prepare_environment(
            session_id=sid, repo_path=str(tmp_path),
            sandbox_error="",
        ))
        out = json.loads(raw)
        assert out["snapshot_path"] == ""
        assert out["added"] == []
        assert out["advisory_only"] is True
    finally:
        o._AUDIT_REGISTRY.pop(sid, None)
        o._ENV_REGISTRY.pop(sid, None)


def test_prepare_environment_dedup_against_manifest(tmp_path: Path):
    """If pyproject already declares stripe, missing-stripe should NOT be re-added."""
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "x"\nversion = "0"\n'
        'dependencies = ["stripe>=12"]\n'
    )
    sid = "test_sess_dedup"
    o._AUDIT_REGISTRY[sid] = o.AuditSession(sid)
    error = "E   ModuleNotFoundError: No module named 'stripe'\n"

    # Mock the snapshot builder + pypi probe — we only test the spec selection.
    with mock.patch("business_logic.sandbox.dep_installer.prepare_snapshot",
                    return_value=None), \
         mock.patch("business_logic.sandbox.dep_installer.fetch_latest_pypi_version",
                    return_value="12.4.0"):
        try:
            raw = asyncio.run(o._tool_prepare_environment(
                session_id=sid, repo_path=str(tmp_path),
                sandbox_error=error,
            ))
            out = json.loads(raw)
            # stripe was already in manifest → should NOT appear in `added`.
            assert all("stripe" not in s.lower() for s in out.get("added", []))
        finally:
            o._AUDIT_REGISTRY.pop(sid, None)
            o._ENV_REGISTRY.pop(sid, None)


def test_prepare_environment_adds_missing(tmp_path: Path):
    """Missing module not in manifest → added with PyPI version pin."""
    (tmp_path / "pyproject.toml").write_text(
        '[project]\nname = "x"\nversion = "0"\ndependencies = []\n'
    )
    sid = "test_sess_add"
    o._AUDIT_REGISTRY[sid] = o.AuditSession(sid)
    error = "E   ModuleNotFoundError: No module named 'redis'\n"

    with mock.patch("business_logic.sandbox.dep_installer.prepare_snapshot",
                    return_value=None), \
         mock.patch("business_logic.sandbox.dep_installer.fetch_latest_pypi_version",
                    return_value="5.0.1"):
        try:
            raw = asyncio.run(o._tool_prepare_environment(
                session_id=sid, repo_path=str(tmp_path),
                sandbox_error=error,
            ))
            out = json.loads(raw)
            assert "redis==5.0.1" in out.get("added", [])
        finally:
            o._AUDIT_REGISTRY.pop(sid, None)
            o._ENV_REGISTRY.pop(sid, None)


def test_compliance_environment_prep_outside_seal():
    """environment_prep block is advisory; never inside evidence_path_seal."""
    sid = "test_compliance"
    audit = o.AuditSession(sid)
    o._AUDIT_REGISTRY[sid] = audit
    o._ENV_REGISTRY[sid] = {
        "snapshot_path": "/tmp/fake_snapshot",
        "added": ["redis==5.0.1"],
        "base_specs": ["stripe>=12"],
        "cve_advisories": [],
    }
    # Build a sealed ReproResult and a minimal event so build_artifact runs.
    from oracles.sentry_replay import SentryException, SentryFrame  # type: ignore
    frame = SentryFrame(
        filename="x.py", function="f", lineno=1,
        context_line="", variables={},
    )
    exc = SentryException(
        issue_id="9999", issue_url="https://sentry.io/issues/9999/",
        error_type="ValueError", error_message="bad",
        last_seen="2026-05-06T00:00:00", event_count=1,
        frames=[frame],
    )
    o._EVENT_REGISTRY[sid] = {"exc": exc, "frame": frame,
                              "snapshot": {"issue_id": "9999"}}
    o._REPRO_REGISTRY[sid] = o.ReproResult(
        test_code="def test_x(): pass",
        sandbox_output="", sandbox_mode="docker",
        passed=0, failed=1, total=1, duration=0.1,
        reproduced=True,
        target_path="x.py", target_lineno=1, target_function="f",
        error_type="ValueError", error_message="bad",
        sandbox_exception_type="ValueError",
        verified_exception_match=True,
        sealed=True,
    )
    try:
        # render_artifact talks to git; mock it.
        with mock.patch("logomesh_orchestrator.get_git_metadata",
                        return_value=("main", "deadbeef")), \
             mock.patch("logomesh_orchestrator.render_artifact",
                        return_value={"control_mappings": [
                            "SOC2 CC7.3", "SOC2 CC7.4", "PCI DSS 12.10.5",
                        ]}):
            raw = asyncio.run(o._tool_build_artifact(
                session_id=sid, repo_path=".", pr_url="",
            ))
            artifact = json.loads(raw)

            # Compliance contract checks:
            seal = artifact["evidence_path_seal"]
            assert seal["llm_in_evidence_path"] is False
            assert "deps_added" not in seal           # MUST NOT be in seal
            assert "snapshot_path" not in seal        # MUST NOT be in seal

            env = artifact["environment_prep"]
            assert env["in_evidence_path"] is False
            assert env["deps_added"] == ["redis==5.0.1"]
            assert env["snapshot_path"] == "/tmp/fake_snapshot"
    finally:
        for r in (o._AUDIT_REGISTRY, o._ENV_REGISTRY,
                  o._EVENT_REGISTRY, o._REPRO_REGISTRY):
            r.pop(sid, None)
