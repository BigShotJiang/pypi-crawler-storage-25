"""Stripe metadata parsing — pure functions, defensive on bad input."""

from __future__ import annotations

import json

from capture.stripe_meta import (
    extract_event_meta,
    is_stripe_api_url,
    parse_stripe_signature,
)


def test_parse_stripe_signature_typical_header():
    h = "t=1700000000,v1=abc123,v1=def456,v0=oldsig"
    out = parse_stripe_signature(h)
    assert out["t"] == 1700000000
    assert out["v1"] == ["abc123", "def456"]
    assert out["v0"] == ["oldsig"]


def test_parse_stripe_signature_handles_garbage():
    for h in [None, "", "junk", "t=notanint", "v1=", ",,,"]:
        out = parse_stripe_signature(h)
        # Total: never raises, always returns the documented shape.
        assert set(out.keys()) == {"t", "v1", "v0"}
        assert isinstance(out["v1"], list)
        assert isinstance(out["v0"], list)


def test_extract_event_meta_full_webhook_payload():
    body = json.dumps({
        "id": "evt_test_123",
        "type": "invoice.payment_failed",
        "livemode": False,
        "api_version": "2024-06-20",
        "data": {
            "object": {
                "object": "invoice",
                "id": "in_test_456",
                "amount_due": 4995,
            }
        },
        "request": {"id": "req_xyz", "idempotency_key": "idem_888"},
    })
    meta = extract_event_meta(body)
    assert meta["event_id"] == "evt_test_123"
    assert meta["event_type"] == "invoice.payment_failed"
    assert meta["livemode"] is False
    assert meta["api_version"] == "2024-06-20"
    assert meta["object_type"] == "invoice"
    assert meta["object_id"] == "in_test_456"
    assert meta["request_idempotency_key"] == "idem_888"


def test_extract_event_meta_handles_non_json():
    meta = extract_event_meta("not json at all")
    assert all(v is None for v in meta.values())


def test_extract_event_meta_handles_bytes():
    body = json.dumps({"id": "evt_b", "type": "x"}).encode("utf-8")
    meta = extract_event_meta(body)
    assert meta["event_id"] == "evt_b"
    assert meta["event_type"] == "x"


def test_is_stripe_api_url():
    assert is_stripe_api_url("https://api.stripe.com/v1/charges")
    assert is_stripe_api_url("HTTPS://API.STRIPE.COM/v1/customers")
    assert not is_stripe_api_url("https://example.com/charges")
    assert not is_stripe_api_url(None)
    assert not is_stripe_api_url("")
