"""Unit tests for the structured hypothesis report (Phases A + B + C)."""

from __future__ import annotations

from oracles.hypothesis_report import (
    HypothesisReport,
    build_hypothesis_report,
    classify_crash,
    extract_race_signals,
    suggest_fix_pattern,
    suggest_invariants,
    suggest_repro_approach,
)


# ---- Phase B: classifier ---------------------------------------------------

def test_classify_optimistic_lock():
    cls, conf = classify_crash(
        error_type="StaleDataError",
        error_message="Optimistic lock failed for order=abc; expected version=3",
        raw_locals={"order_id": "abc", "expected_version": 3},
    )
    assert cls == "race_condition_optimistic_lock"
    assert conf > 0.7


def test_classify_integrity_with_celery_locals():
    cls, conf = classify_crash(
        error_type="IntegrityError",
        error_message='duplicate key value violates unique constraint "payments_payment_order_id_key"',
        raw_locals={"order_id": "ORD-9182", "task_id": "celery-abc", "retries": 0},
    )
    assert cls == "race_condition_write_write"
    assert conf > 0.7


def test_classify_fk_violation():
    cls, _ = classify_crash(
        error_type="IntegrityError",
        error_message="insert violates foreign key constraint fk_settlement_payment",
        raw_locals={"payment_id": "00000000-0000-0000-0000-000000000000"},
    )
    assert cls == "fk_ordering"


def test_classify_framework_bootstrap_needed():
    cls, _ = classify_crash(
        error_type="AttributeError",
        error_message="'NoneType' object has no attribute 'amount_cents'",
        raw_locals={"order": "<Order: ORD-9182>", "self": "<process_payment task>"},
    )
    assert cls == "framework_bootstrap_required"


def test_classify_input_validation_fallback():
    cls, _ = classify_crash(
        error_type="ValueError",
        error_message="invalid currency=ZZZ",
        raw_locals={"amount_cents": 100, "currency": "ZZZ"},
    )
    assert cls == "input_validation"


def test_classify_unknown_on_empty_signal():
    cls, _ = classify_crash(
        error_type="WeirdCustomError",
        error_message="",
        raw_locals={},
    )
    assert cls == "unknown"


# ---- Phase B: race signal extraction ---------------------------------------

def test_extract_race_signals_picks_up_state_overwrites():
    bc = [
        {"message": "process_payment_started", "data": {"task_id": "a"}},
        {"message": "order_state_overwrite", "data": {"task_id": "b"}},
    ]
    lines = extract_race_signals(
        breadcrumbs=bc,
        audit_events=[],
        raw_locals={"version": 3, "expected_version": 3},
    )
    sources = {e.source for e in lines}
    assert "breadcrumb" in sources
    assert "frame_local" in sources
    assert any("state-overwrite" in e.text for e in lines)
    assert any("version" in e.text.lower() for e in lines)


def test_extract_race_signals_empty_when_no_evidence():
    lines = extract_race_signals(
        breadcrumbs=[],
        audit_events=[],
        raw_locals={"amount_cents": 100},
    )
    assert lines == []


# ---- Phase B: invariant suggestion ----------------------------------------

def test_invariant_for_integrity_pulls_constraint_name():
    invs = suggest_invariants(
        crash_class="race_condition_write_write",
        error_type="IntegrityError",
        error_message='duplicate key violates unique constraint "payments_payment_order_id_key"',
        raw_locals={},
    )
    assert any("payments_payment_order_id_key" in i.statement for i in invs)


def test_invariant_for_optimistic_lock():
    invs = suggest_invariants(
        crash_class="race_condition_optimistic_lock",
        error_type="StaleDataError",
        error_message="",
        raw_locals={},
    )
    assert any("version" in i.statement.lower() for i in invs)


# ---- Phase C: fix pattern + repro approach lookups ------------------------

def test_fix_pattern_covers_all_known_classes():
    for cls in (
        "race_condition_write_write",
        "race_condition_optimistic_lock",
        "race_condition_read_after_write",
        "fk_ordering",
        "timing_dependent",
        "external_state_required",
        "framework_bootstrap_required",
        "input_validation",
        "unknown",
    ):
        pattern = suggest_fix_pattern(cls)  # type: ignore[arg-type]
        assert pattern and len(pattern) > 40, f"empty / too short fix pattern for {cls}"


def test_repro_approach_covers_all_known_classes():
    for cls in (
        "race_condition_write_write",
        "race_condition_optimistic_lock",
        "race_condition_read_after_write",
        "fk_ordering",
        "timing_dependent",
        "external_state_required",
        "framework_bootstrap_required",
        "input_validation",
        "unknown",
    ):
        approach = suggest_repro_approach(cls)  # type: ignore[arg-type]
        assert approach and len(approach) > 40


# ---- Phase A: full report builder ------------------------------------------

def test_build_report_optimistic_lock_full_path():
    evidence = {
        "function": "_optimistic_mark_paid",
        "file": "payments/tasks.py",
        "lineno": 213,
        "error_type": "StaleDataError",
        "error_message": "Optimistic lock failed for order=abc; expected version=3",
        "frame_locals": {"order": "<Order: abc>", "expected_version": 3, "simulate": "stale_race"},
        "hypotheses": [
            {"rank": 1, "confidence": 0.7, "description": "Concurrency race",
             "evidence": "StaleDataError", "investigation": "thread it"},
        ],
    }
    report = build_hypothesis_report(
        evidence=evidence,
        audit_events=[],
        breadcrumbs=[{"message": "order_state_overwrite", "data": {"task_id": "b"}}],
        related_files=["payments/tasks.py", "payments/models.py"],
        out_of_scope_reason="race condition out of scope today",
    )
    assert isinstance(report, HypothesisReport)
    assert report.crash_class == "race_condition_optimistic_lock"
    assert report.confidence > 0.7
    assert report.in_evidence_path is False
    assert "Optimistic-lock" in report.one_line_summary
    assert report.hypotheses
    assert report.hypotheses[0].repro_difficulty == "needs_real_db"
    assert report.violated_invariants
    assert "version" in report.suggested_fix_pattern.lower()
    assert "version" in report.suggested_repro_approach.lower() or \
           "session" in report.suggested_repro_approach.lower()
    assert report.related_files == ["payments/tasks.py", "payments/models.py"]
    assert report.out_of_scope_reason


def test_build_report_serializes_to_dict():
    evidence = {
        "function": "checkout",
        "file": "billing/checkout.py",
        "lineno": 42,
        "error_type": "ValueError",
        "error_message": "qty must be positive",
        "frame_locals": {"item_id": 1, "qty": -5},
        "hypotheses": [],
    }
    report = build_hypothesis_report(evidence=evidence)
    d = report.to_dict()
    assert d["crash_class"] == "input_validation"
    assert d["in_evidence_path"] is False
    assert "suggested_fix_pattern" in d
    assert "suggested_repro_approach" in d


def test_build_report_handles_empty_evidence():
    report = build_hypothesis_report(evidence={})
    assert report.crash_class == "unknown"
    assert report.in_evidence_path is False
    assert report.suggested_fix_pattern
    assert report.suggested_repro_approach


# ---- PR3: structured thread + breadcrumb signals --------------------------

from oracles.hypothesis_report import (
    build_breadcrumb_timeline,
    _summarize_threads,
)
from oracles.sentry_replay import SentryBreadcrumb, SentryThread


def test_classify_deadlock_when_two_holders_and_one_blocked():
    threads = [
        SentryThread(id=1, name="A", crashed=False, state="BLOCKED",
                     held_locks=["lock_x"]),
        SentryThread(id=2, name="B", crashed=True, state="RUNNABLE",
                     held_locks=["lock_y"]),
    ]
    cls, conf = classify_crash(
        error_type="RuntimeError",
        error_message="thread hung waiting on lock",
        raw_locals={},
        threads=threads,
    )
    assert cls == "deadlock"
    assert conf > 0.8


def test_classify_race_boost_with_held_locks_present():
    # Without locks
    cls1, conf1 = classify_crash(
        error_type="IntegrityError",
        error_message='duplicate key violates unique constraint "k"',
        raw_locals={"task_id": "t"},
    )
    # With locks (no deadlock — only one holder)
    threads = [SentryThread(id=1, crashed=True, state="RUNNABLE",
                            held_locks=["payments.order_lock"])]
    cls2, conf2 = classify_crash(
        error_type="IntegrityError",
        error_message='duplicate key violates unique constraint "k"',
        raw_locals={"task_id": "t"},
        threads=threads,
    )
    assert cls1 == cls2 == "race_condition_write_write"
    assert conf2 > conf1  # held_locks promotes confidence


def test_classify_optimistic_lock_boost_with_held_locks():
    threads = [SentryThread(id=1, crashed=True, state="RUNNABLE",
                            held_locks=["payments.cas"])]
    _, conf_no = classify_crash(
        error_type="StaleDataError",
        error_message="optimistic version=3",
        raw_locals={},
    )
    cls, conf_with = classify_crash(
        error_type="StaleDataError",
        error_message="optimistic version=3",
        raw_locals={},
        threads=threads,
    )
    assert cls == "race_condition_optimistic_lock"
    assert conf_with > conf_no


def test_classify_unaffected_when_threads_empty_or_unstructured():
    cls, conf = classify_crash(
        error_type="ValueError",
        error_message="bad",
        raw_locals={"qty": -1},
        threads=[],
    )
    assert cls == "input_validation"
    # Same call with no threads kwarg
    cls2, conf2 = classify_crash(
        error_type="ValueError",
        error_message="bad",
        raw_locals={"qty": -1},
    )
    assert cls2 == cls
    assert abs(conf - conf2) < 1e-9


def test_extract_race_signals_accepts_structured_breadcrumbs():
    bc = [
        SentryBreadcrumb(message="order_state_overwrite", data={"task_id": "a"}),
        SentryBreadcrumb(message="process_payment_started", data={"task_id": "b"}),
    ]
    lines = extract_race_signals(
        breadcrumbs=bc,
        audit_events=[],
        raw_locals={"version": 3},
    )
    sources = {e.source for e in lines}
    assert "breadcrumb" in sources
    assert any("state-overwrite" in e.text.lower() for e in lines)
    assert any("distinct task ids" in e.text for e in lines)


def test_extract_race_signals_picks_up_race_window_marker():
    bc = [SentryBreadcrumb(message="race_window_open", data={})]
    lines = extract_race_signals(
        breadcrumbs=bc, audit_events=[], raw_locals={},
    )
    assert any("race_window_open" in e.text for e in lines)


def test_extract_race_signals_held_lock_evidence():
    th = [
        SentryThread(id=1, crashed=True, held_locks=["payments_order_lock"]),
    ]
    lines = extract_race_signals(
        breadcrumbs=[], audit_events=[], raw_locals={}, threads=th,
    )
    assert any(e.source == "thread" and "held lock" in e.text.lower() for e in lines)


def test_extract_race_signals_deadlock_evidence():
    th = [
        SentryThread(id=1, state="BLOCKED", held_locks=["a"]),
        SentryThread(id=2, state="BLOCKED", held_locks=["b"]),
    ]
    lines = extract_race_signals(
        breadcrumbs=[], audit_events=[], raw_locals={}, threads=th,
    )
    assert any("deadlock signature" in e.text.lower() for e in lines)


def test_summarize_threads_dict_shape():
    th = [
        {"id": 1, "state": "BLOCKED", "heldLocks": ["lock1"]},
        {"id": 2, "state": "RUNNABLE", "held_locks": ["lock2"]},
    ]
    summary = _summarize_threads(th)
    assert summary["any_held_locks"] is True
    assert summary["lock_holders"] == 2
    assert summary["blocked_threads"] == 1
    assert summary["deadlock_likely"] is True


def test_breadcrumb_timeline_computes_deltas_iso():
    bc = [
        SentryBreadcrumb(timestamp="2026-05-10T00:00:00.000Z", message="a"),
        SentryBreadcrumb(timestamp="2026-05-10T00:00:00.020Z", message="b"),
        SentryBreadcrumb(timestamp="2026-05-10T00:00:01.000Z", message="c"),
    ]
    tl = build_breadcrumb_timeline(bc)
    assert tl[0]["delta_ms"] is None
    assert tl[1]["delta_ms"] is not None and 15 <= tl[1]["delta_ms"] <= 25
    assert tl[2]["delta_ms"] is not None and 950 <= tl[2]["delta_ms"] <= 1000


def test_breadcrumb_timeline_handles_epoch_timestamps():
    bc = [
        {"timestamp": "1700000000.000", "message": "x"},
        {"timestamp": "1700000000.030", "message": "y"},
    ]
    tl = build_breadcrumb_timeline(bc)
    assert tl[1]["delta_ms"] is not None and 25 <= tl[1]["delta_ms"] <= 35


def test_breadcrumb_timeline_handles_bad_timestamps():
    bc = [
        SentryBreadcrumb(timestamp="not-a-time", message="a"),
        SentryBreadcrumb(timestamp="", message="b"),
    ]
    tl = build_breadcrumb_timeline(bc)
    assert tl[0]["delta_ms"] is None
    assert tl[1]["delta_ms"] is None


def test_extract_race_signals_tight_cluster_flag():
    bc = [
        SentryBreadcrumb(timestamp="2026-05-10T00:00:00.000Z", message="start"),
        SentryBreadcrumb(timestamp="2026-05-10T00:00:00.010Z", message="step1"),
        SentryBreadcrumb(timestamp="2026-05-10T00:00:00.020Z", message="step2"),
        SentryBreadcrumb(timestamp="2026-05-10T00:00:00.030Z", message="step3"),
    ]
    lines = extract_race_signals(
        breadcrumbs=bc, audit_events=[], raw_locals={},
    )
    assert any("<50ms apart" in e.text for e in lines)


def test_build_report_deadlock_full_path():
    threads = [
        SentryThread(id=1, name="A", state="BLOCKED", held_locks=["lock_x"]),
        SentryThread(id=2, name="B", state="BLOCKED", held_locks=["lock_y"]),
    ]
    bc = [SentryBreadcrumb(message="lock_acquire_attempted", data={})]
    evidence = {
        "function": "transfer_funds",
        "file": "banking/tasks.py",
        "lineno": 88,
        "error_type": "RuntimeError",
        "error_message": "hung waiting on lock",
        "frame_locals": {},
        "hypotheses": [],
    }
    report = build_hypothesis_report(
        evidence=evidence,
        breadcrumbs=bc,
        threads=threads,
    )
    assert report.crash_class == "deadlock"
    assert report.confidence > 0.8
    assert "Deadlock" in report.one_line_summary
    assert "lock-acquisition order" in report.suggested_fix_pattern
    assert "opposite" in report.suggested_repro_approach
    assert any(i.statement.startswith("Threads should") for i in report.violated_invariants)
    # Difficulty for deadlock is needs_threads
    if report.hypotheses:
        assert report.hypotheses[0].repro_difficulty == "needs_threads"


def test_deadlock_present_in_phase_c_lookups():
    # Round-trip: every CrashClass must be in both lookup tables
    pattern = suggest_fix_pattern("deadlock")
    approach = suggest_repro_approach("deadlock")
    assert pattern and "lock" in pattern.lower()
    assert approach and "thread" in approach.lower()


def test_build_report_threads_dict_shape_still_works():
    # Ensure raw-dict shape (from JSON event) is accepted alongside dataclass
    threads = [
        {"id": 1, "state": "BLOCKED", "heldLocks": ["a"]},
        {"id": 2, "state": "BLOCKED", "held_locks": ["b"]},
    ]
    report = build_hypothesis_report(
        evidence={"error_type": "RuntimeError", "error_message": "hung"},
        threads=threads,
    )
    assert report.crash_class == "deadlock"
