"""Tests for src/core/config.py — `.logomesh.toml` loader and application."""

from pathlib import Path

import pytest

from core.config import (
    CONFIG_FILENAME,
    Invariant,
    LogomeshConfig,
    from_dict,
    load,
    requirements_from_deps,
)


# ---- from_dict: schema validation ----

def test_empty_dict_yields_default_config():
    cfg = from_dict({})
    assert cfg.version == 1
    assert cfg.deps == []
    assert cfg.focus == []
    assert cfg.skip == []
    assert cfg.invariants == []
    assert cfg.max_findings_per_pr == 0
    assert cfg.silent_on_clean is False


def test_full_config_parses_correctly():
    cfg = from_dict({
        "version": 1,
        "deps": ["openai", "pydantic", "stripe"],
        "focus": ["src/billing/**"],
        "skip": ["src/legacy/**"],
        "framework": "fastapi",
        "invariants": [
            {"function": "apply_discount", "returns": ">= 0"},
            {"function": "charge", "args": "amount > 0", "returns": "Decimal"},
        ],
        "output": {"max_findings_per_pr": 5, "silent_on_clean": True},
    })
    assert cfg.deps == ["openai", "pydantic", "stripe"]
    assert cfg.focus == ["src/billing/**"]
    assert cfg.skip == ["src/legacy/**"]
    assert cfg.framework == "fastapi"
    assert len(cfg.invariants) == 2
    assert cfg.invariants[0].function == "apply_discount"
    assert cfg.invariants[0].returns == ">= 0"
    assert cfg.invariants[1].args == "amount > 0"
    assert cfg.max_findings_per_pr == 5
    assert cfg.silent_on_clean is True


def test_unknown_top_level_key_rejected():
    """Typos like 'dep' vs 'deps' should fail loudly, not silently no-op.
    This is the #1 way config files go wrong."""
    with pytest.raises(ValueError, match="unknown .logomesh.toml keys"):
        from_dict({"dep": ["openai"]})  # typo — should error


def test_unsupported_version_rejected():
    with pytest.raises(ValueError, match="unsupported .logomesh.toml version"):
        from_dict({"version": 2})


def test_deps_must_be_list_of_strings():
    with pytest.raises(ValueError, match="deps must be a list"):
        from_dict({"deps": "openai"})
    with pytest.raises(ValueError, match=r"deps\[0\] must be a string"):
        from_dict({"deps": [123]})


def test_invariant_missing_function_rejected():
    with pytest.raises(ValueError, match="'function' is required"):
        from_dict({"invariants": [{"returns": ">= 0"}]})


def test_negative_max_findings_rejected():
    with pytest.raises(ValueError, match="max_findings_per_pr must be >= 0"):
        from_dict({"output": {"max_findings_per_pr": -1}})


# ---- should_verify: glob matching ----

def test_empty_config_verifies_everything_except_defaults():
    """No user rules — still skips tests/, cli/, mcp_server/, scripts/ etc."""
    cfg = LogomeshConfig()
    assert cfg.should_verify("src/billing/invoice.py") is True
    assert cfg.should_verify("src/cli/check.py") is False
    assert cfg.should_verify("src/mcp_server/server.py") is False
    assert cfg.should_verify("tests/test_foo.py") is False
    assert cfg.should_verify("scripts/bootstrap.py") is False
    assert cfg.should_verify("migrations/0001.py") is False


def test_focus_restricts_to_matching_paths():
    cfg = LogomeshConfig(focus=["src/billing/**"])
    assert cfg.should_verify("src/billing/invoice.py") is True
    assert cfg.should_verify("src/billing/nested/deep.py") is True
    assert cfg.should_verify("src/auth/login.py") is False
    assert cfg.should_verify("src/core/pipeline.py") is False


def test_user_skip_appends_to_defaults():
    cfg = LogomeshConfig(skip=["src/legacy/**"])
    assert cfg.should_verify("src/legacy/old.py") is False
    # defaults still in effect
    assert cfg.should_verify("tests/test_foo.py") is False
    # other code still verified
    assert cfg.should_verify("src/billing/invoice.py") is True


def test_skip_wins_over_focus():
    """If focus and skip match the same path, skip wins — treating skip as
    a hard veto matches developer intent."""
    cfg = LogomeshConfig(
        focus=["src/**"],
        skip=["src/experimental/**"],
    )
    assert cfg.should_verify("src/billing/invoice.py") is True
    assert cfg.should_verify("src/experimental/draft.py") is False


# ---- invariants application ----

def test_invariants_for_function_returns_matching_only():
    cfg = LogomeshConfig(invariants=[
        Invariant(function="apply_discount", returns=">= 0"),
        Invariant(function="charge", returns="Decimal"),
    ])
    assert len(cfg.invariants_for("apply_discount")) == 1
    assert cfg.invariants_for("apply_discount")[0].returns == ">= 0"
    assert cfg.invariants_for("missing") == []


def test_render_invariants_prompt_is_empty_when_no_invariants():
    cfg = LogomeshConfig()
    assert cfg.render_invariants_prompt() == ""


def test_render_invariants_prompt_includes_all_fields():
    cfg = LogomeshConfig(invariants=[
        Invariant(
            function="apply_discount",
            args="amount > 0, pct in [0, 100]",
            returns=">= 0",
            description="Total after discount must never be negative",
        )
    ])
    prompt = cfg.render_invariants_prompt()
    assert "apply_discount" in prompt
    assert "amount > 0, pct in [0, 100]" in prompt
    assert ">= 0" in prompt
    assert "Total after discount must never be negative" in prompt
    assert "hard requirements" in prompt.lower()


# ---- requirements_from_deps ----

def test_requirements_from_deps_empty():
    assert requirements_from_deps([]) == {}


def test_requirements_from_deps_builds_requirements_file():
    out = requirements_from_deps(["openai", "pydantic>=2.0", "stripe"])
    assert "requirements.txt" in out
    body = out["requirements.txt"]
    assert "openai" in body
    assert "pydantic>=2.0" in body
    assert "stripe" in body
    # newline-separated
    assert body.count("\n") == 3


def test_requirements_from_deps_strips_whitespace():
    out = requirements_from_deps(["  openai  ", "", "stripe"])
    body = out["requirements.txt"]
    assert "openai" in body
    assert "stripe" in body
    # Empty string is filtered
    assert "\n\n" not in body.replace("\n\n", "")


# ---- load from disk ----

def test_load_returns_default_when_no_file(tmp_path):
    cfg = load(tmp_path)
    assert cfg == LogomeshConfig()


def test_load_parses_real_toml_file(tmp_path):
    (tmp_path / CONFIG_FILENAME).write_text("""
version = 1
deps = ["openai", "pydantic"]
focus = ["src/billing/**"]
skip = ["src/legacy/**"]
framework = "fastapi"

[[invariants]]
function = "apply_discount"
returns = ">= 0"

[[invariants]]
function = "charge"
args = "amount > 0"
returns = "Decimal"

[output]
max_findings_per_pr = 3
silent_on_clean = true
""")
    cfg = load(tmp_path)
    assert cfg.deps == ["openai", "pydantic"]
    assert cfg.focus == ["src/billing/**"]
    assert cfg.framework == "fastapi"
    assert len(cfg.invariants) == 2
    assert cfg.invariants[0].function == "apply_discount"
    assert cfg.max_findings_per_pr == 3
    assert cfg.silent_on_clean is True


def test_load_malformed_toml_raises_with_path(tmp_path):
    (tmp_path / CONFIG_FILENAME).write_text("this is = not valid TOML [[")
    with pytest.raises(ValueError, match="invalid TOML"):
        load(tmp_path)


def test_load_defaults_to_cwd_when_no_root_given(tmp_path, monkeypatch):
    (tmp_path / CONFIG_FILENAME).write_text('deps = ["openai"]\n')
    monkeypatch.chdir(tmp_path)
    cfg = load()
    assert cfg.deps == ["openai"]
