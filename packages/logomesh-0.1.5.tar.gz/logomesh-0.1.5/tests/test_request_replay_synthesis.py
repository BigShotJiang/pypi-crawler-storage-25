"""Tests for the request-context replay synthesizer (PR2 part A).

The synthesizer emits a HTTP-replay pytest from `exc.request`. It must:
  - never name a framework (Django / FastAPI / Flask) in test bytes
  - emit `client.request(method=..., url=..., ...)` so any test client
    fixture supplied via conftest can serve it
  - use only values that originated in the captured Sentry payload
  - return None when there's nothing useful to emit
"""

from __future__ import annotations

from oracles.sentry_replay import SentryException, SentryFrame, SentryRequest
from oracles.sentry_replay_v2 import build_request_replay_test_v2


def _exc(*, request: SentryRequest | None, issue_id: str = "7470722069") -> SentryException:
    return SentryException(
        issue_id=issue_id,
        issue_url=f"https://sentry.io/issues/{issue_id}/",
        error_type="ValueError",
        error_message="amount must be positive",
        last_seen="2026-05-10T00:00:00Z",
        event_count=1,
        frames=[],
        request=request,
    )


def _frame(function: str = "create_order") -> SentryFrame:
    return SentryFrame(
        filename="payments/views.py",
        function=function,
        lineno=42,
        context_line="raise ValueError(...)",
        variables={},
    )


def test_returns_none_when_request_absent():
    exc = _exc(request=None)
    assert build_request_replay_test_v2(exc, _frame()) is None


def test_returns_none_when_method_or_url_missing():
    exc = _exc(request=SentryRequest(method="", url="/x"))
    assert build_request_replay_test_v2(exc, _frame()) is None
    exc2 = _exc(request=SentryRequest(method="POST", url=""))
    assert build_request_replay_test_v2(exc2, _frame()) is None


def test_emits_test_body_with_method_and_url():
    exc = _exc(request=SentryRequest(
        method="POST", url="/api/orders",
        headers={}, data={"qty": -1}, query_string=None,
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "client.request(" in out
    assert "method='POST'" in out
    assert "url='/api/orders'" in out
    assert "json={'qty': -1}" in out
    # No framework names in the body
    body_lower = out.lower()
    assert "django" not in body_lower
    assert "fastapi" not in body_lower
    assert "flask" not in body_lower
    assert "starlette" not in body_lower


def test_strips_scheme_and_host_from_absolute_url():
    exc = _exc(request=SentryRequest(
        method="GET",
        url="https://example.com/api/orders?ref=abc",
        headers={}, data=None,
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "https://" not in out
    assert "example.com" not in out
    # path is preserved
    assert "/api/orders" in out


def test_keeps_only_allowlisted_headers():
    exc = _exc(request=SentryRequest(
        method="POST", url="/x",
        headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer secret",
            "X-Custom": "secret-too",
            "Accept": "*/*",
        },
        data=None,
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "Content-Type" in out
    assert "Accept" in out
    assert "Authorization" not in out
    assert "X-Custom" not in out


def test_drops_redacted_header_values():
    exc = _exc(request=SentryRequest(
        method="POST", url="/x",
        headers={
            "Content-Type": "[REDACTED:HEADER]",
        },
        data=None,
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    # Redacted placeholder must not appear inside the test (would crash parser)
    assert "[REDACTED" not in out


def test_query_string_dict_becomes_params_kwarg():
    exc = _exc(request=SentryRequest(
        method="GET", url="/api/orders",
        headers={}, data=None,
        query_string={"ref": "abc", "limit": "10"},
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "params={" in out
    assert "'ref': 'abc'" in out


def test_query_string_raw_is_parsed():
    exc = _exc(request=SentryRequest(
        method="GET", url="/api/orders",
        headers={}, data=None,
        query_string="page=2&sort=-created",
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "params=" in out
    assert "'page': '2'" in out


def test_string_body_with_json_content_type_uses_content_kwarg():
    exc = _exc(request=SentryRequest(
        method="POST", url="/x",
        headers={"Content-Type": "application/json"},
        data='{"qty": -1}',
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "content=" in out
    # Don't double-encode as json= when body is already raw JSON string
    assert "json='" not in out


def test_string_body_without_json_ct_uses_data_kwarg():
    exc = _exc(request=SentryRequest(
        method="POST", url="/x",
        headers={"Content-Type": "application/x-www-form-urlencoded"},
        data="qty=-1&item_id=1",
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "data='qty=-1" in out


def test_function_signature_includes_client_fixture():
    exc = _exc(request=SentryRequest(method="GET", url="/x"))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    # Test must take `client` as a fixture so the conftest can wire it
    assert "def test_sentry_replay_request_" in out
    assert "(client):" in out


def test_safe_issue_id_strips_non_identifier_chars():
    exc = _exc(
        request=SentryRequest(method="GET", url="/x"),
        issue_id="747-072-2069",
    )
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    # Hyphens become underscores; digits-at-start get an `id_` prefix
    # so the function name is a valid Python identifier
    assert "test_sentry_replay_request_id_747_072_2069" in out


def test_no_assertion_in_body_propagates_naturally():
    # No assertEqual / assertRaises — server exception propagates through
    # the test client and pytest reports FAILED.
    exc = _exc(request=SentryRequest(
        method="POST", url="/x", data={"qty": -1},
    ))
    out = build_request_replay_test_v2(exc, _frame())
    assert out is not None
    assert "assert " not in out
    assert "pytest.raises" not in out
