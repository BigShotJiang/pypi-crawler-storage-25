import json
import logging

from logomesh_log import _JsonFormatter


def _record(message: str) -> logging.LogRecord:
    return logging.LogRecord(
        name="logomesh",
        level=logging.INFO,
        pathname=__file__,
        lineno=1,
        msg=message,
        args=(),
        exc_info=None,
    )


def test_formatter_defaults_to_json_passthrough(monkeypatch):
    monkeypatch.delenv("LOGOMESH_LOG_PRETTY", raising=False)
    fmt = _JsonFormatter()
    payload = {
        "time": "2026-04-12T03:27:21.565398+00:00",
        "level": "info",
        "component": "generator",
        "msg": "properties inferred",
        "func": "zadd",
        "count": 3,
    }
    raw = json.dumps(payload)

    assert fmt.format(_record(raw)) == raw


def test_formatter_pretty_mode_renders_human_line(monkeypatch):
    monkeypatch.setenv("LOGOMESH_LOG_PRETTY", "1")
    fmt = _JsonFormatter()
    payload = {
        "time": "2026-04-12T03:27:21.565398+00:00",
        "level": "info",
        "component": "generator",
        "msg": "properties inferred",
        "func": "zadd",
        "count": 3,
    }

    line = fmt.format(_record(json.dumps(payload)))

    assert line.startswith("[03:27:21] INFO  generator")
    assert "properties inferred" in line
    assert "count=3" in line
    assert "func=zadd" in line

