"""Tests for the Sentry webhook endpoint.

Coverage:
  1. signature verification (good / bad / missing)
  2. timestamp replay window (in-window / outside / missing / malformed)
  3. unsigned mode env-gated
  4. malformed JSON → 400
  5. missing issue id → 400
  6. valid payload → 202 + does not block on orchestrator
  7. idempotency: same (issue_id, payload) → second request returns "duplicate"
  8. concurrency: dispatcher acquires + releases the semaphore (smoke)
  9. constant-time signature compare
"""

from __future__ import annotations

import hashlib
import hmac
import json
import os
import sys
import time
from pathlib import Path
from unittest import mock

import pytest
from fastapi.testclient import TestClient

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))
sys.path.insert(0, str(_REPO_ROOT / "src"))


SECRET = "test_secret_2026"


def _sign(body: bytes, secret: str = SECRET) -> str:
    return hmac.new(secret.encode("utf-8"), body, hashlib.sha256).hexdigest()


def _now_ts() -> str:
    return str(int(time.time()))


def _signed_headers(body: bytes, *, ts: str | None = None) -> dict:
    return {
        "Sentry-Hook-Signature": _sign(body),
        "Sentry-Hook-Timestamp": ts or _now_ts(),
        "Sentry-Hook-Resource": "issue",
        "Content-Type": "application/json",
    }


@pytest.fixture
def client(monkeypatch):
    """TestClient with orchestrator dispatch stubbed.

    Each test gets fresh idempotency state + a fresh semaphore.
    """
    monkeypatch.setenv("LOGOMESH_SENTRY_CLIENT_SECRET", SECRET)
    monkeypatch.delenv("LOGOMESH_ALLOW_UNSIGNED", raising=False)

    for mod in list(sys.modules):
        if mod.startswith("src.server") or mod == "logomesh_orchestrator":
            del sys.modules[mod]

    from src.server import sentry_webhook as sw
    from src.server.app import app

    sw._reset_state_for_tests()

    async def _noop_dispatch(payload, issue_id, url_installation_id="", **_kw):
        return None

    with mock.patch.object(sw, "_dispatch_to_orchestrator", _noop_dispatch):
        yield TestClient(app)


def _good_body(issue_id: str = "9999") -> bytes:
    return json.dumps({"data": {"issue": {"id": issue_id}}}).encode("utf-8")


# ---- signature -----------------------------------------------------------

def test_valid_signed_request_returns_202(client):
    body = _good_body()
    resp = client.post("/webhooks/sentry", content=body, headers=_signed_headers(body))
    assert resp.status_code == 202
    j = resp.json()
    assert j["status"] == "accepted"
    assert j["issue_id"] == "9999"


def test_bad_signature_returns_401(client):
    body = _good_body()
    headers = _signed_headers(body)
    headers["Sentry-Hook-Signature"] = "deadbeef" * 8
    resp = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp.status_code == 401
    assert "invalid sentry signature" in resp.text


def test_missing_signature_returns_401(client):
    body = _good_body()
    resp = client.post("/webhooks/sentry", content=body)
    assert resp.status_code == 401


# ---- timestamp replay window --------------------------------------------

def test_expired_timestamp_returns_401(client):
    body = _good_body()
    headers = _signed_headers(body, ts=str(int(time.time()) - 600))  # 10 min old
    resp = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp.status_code == 401
    assert "replay window" in resp.text


def test_future_timestamp_returns_401(client):
    body = _good_body()
    headers = _signed_headers(body, ts=str(int(time.time()) + 600))  # 10 min ahead
    resp = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp.status_code == 401


def test_missing_timestamp_returns_401(client):
    body = _good_body()
    headers = {
        "Sentry-Hook-Signature": _sign(body),
        "Sentry-Hook-Resource": "issue",
        "Content-Type": "application/json",
    }
    resp = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp.status_code == 401


def test_malformed_timestamp_returns_401(client):
    body = _good_body()
    headers = _signed_headers(body, ts="not-a-number")
    resp = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp.status_code == 401


def test_window_is_configurable(client, monkeypatch):
    monkeypatch.setenv("LOGOMESH_TIMESTAMP_WINDOW_S", "60")
    body = _good_body()
    headers = _signed_headers(body, ts=str(int(time.time()) - 120))
    resp = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp.status_code == 401


# ---- idempotency ---------------------------------------------------------

def test_duplicate_payload_returns_duplicate_status(client):
    body = _good_body()
    headers = _signed_headers(body)
    resp1 = client.post("/webhooks/sentry", content=body, headers=headers)
    assert resp1.status_code == 202
    resp2 = client.post(
        "/webhooks/sentry", content=body,
        headers=_signed_headers(body),  # fresh ts, same body
    )
    assert resp2.status_code == 202
    assert resp2.json()["status"] == "duplicate"


def test_different_issue_not_deduped(client):
    body1 = _good_body("1111")
    body2 = _good_body("2222")
    r1 = client.post("/webhooks/sentry", content=body1, headers=_signed_headers(body1))
    r2 = client.post("/webhooks/sentry", content=body2, headers=_signed_headers(body2))
    assert r1.json()["status"] == "accepted"
    assert r2.json()["status"] == "accepted"


def test_different_payload_same_issue_not_deduped(client):
    """Idempotency key includes payload hash, not just issue id."""
    body1 = json.dumps(
        {"data": {"issue": {"id": "9999"}}, "v": 1},
    ).encode("utf-8")
    body2 = json.dumps(
        {"data": {"issue": {"id": "9999"}}, "v": 2},
    ).encode("utf-8")
    r1 = client.post("/webhooks/sentry", content=body1, headers=_signed_headers(body1))
    r2 = client.post("/webhooks/sentry", content=body2, headers=_signed_headers(body2))
    assert r1.json()["status"] == "accepted"
    assert r2.json()["status"] == "accepted"


# ---- concurrency cap -----------------------------------------------------

def test_dispatch_uses_semaphore(client, monkeypatch):
    """_dispatch_to_orchestrator should acquire the process semaphore."""
    monkeypatch.setenv("LOGOMESH_MAX_CONCURRENT_RUNS", "2")
    from src.server import sentry_webhook as sw
    sw._reset_state_for_tests()
    sem = sw._get_dispatch_semaphore()
    # Default value is hard to introspect on asyncio.Semaphore across versions;
    # smoke: acquire twice, ensure third blocks (via locked()).
    import asyncio

    async def _drain():
        await sem.acquire()
        await sem.acquire()
        return sem.locked()

    locked = asyncio.run(_drain())
    assert locked is True


# ---- unsigned mode -------------------------------------------------------

def test_unsigned_mode_allows_through(monkeypatch):
    monkeypatch.setenv("LOGOMESH_ALLOW_UNSIGNED", "1")
    monkeypatch.setenv("LOGOMESH_SENTRY_CLIENT_SECRET", SECRET)
    for mod in list(sys.modules):
        if mod.startswith("src.server"):
            del sys.modules[mod]
    from src.server import sentry_webhook as sw
    from src.server.app import app

    sw._reset_state_for_tests()

    async def _noop(payload, issue_id, url_installation_id="", **_kw):
        return None

    with mock.patch.object(sw, "_dispatch_to_orchestrator", _noop):
        c = TestClient(app)
        # No timestamp/signature headers required when ALLOW_UNSIGNED=1.
        resp = c.post("/webhooks/sentry", content=_good_body())
    assert resp.status_code == 202


# ---- payload errors ------------------------------------------------------

def test_malformed_json_returns_400(client):
    body = b"not json{{{"
    resp = client.post(
        "/webhooks/sentry", content=body, headers=_signed_headers(body),
    )
    assert resp.status_code == 400
    assert "malformed" in resp.text.lower()


def test_missing_issue_id_returns_400(client):
    body = json.dumps({"data": {"event": {}}}).encode("utf-8")
    resp = client.post(
        "/webhooks/sentry", content=body, headers=_signed_headers(body),
    )
    assert resp.status_code == 400
    assert "missing" in resp.text.lower()


def test_health_endpoint(client):
    resp = client.get("/health")
    assert resp.status_code == 200
    assert resp.json() == {"status": "ok"}


# ---- primitive checks ----------------------------------------------------

def test_constant_time_comparison_on_signature():
    """Defense-in-depth: hmac.compare_digest, not ==."""
    from src.server.sentry_webhook import verify_sentry_signature
    os.environ["LOGOMESH_SENTRY_CLIENT_SECRET"] = SECRET
    body = b"hello"
    good = _sign(body)
    assert verify_sentry_signature(body, good) is True
    assert verify_sentry_signature(body, good[:-1] + "x") is False
    assert verify_sentry_signature(body, "") is False
    os.environ.pop("LOGOMESH_SENTRY_CLIENT_SECRET", None)
    assert verify_sentry_signature(body, good) is False


def test_verify_timestamp_unit():
    from src.server.sentry_webhook import verify_sentry_timestamp
    assert verify_sentry_timestamp(str(int(time.time()))) is True
    assert verify_sentry_timestamp(str(int(time.time()) - 1000)) is False
    assert verify_sentry_timestamp(None) is False
    assert verify_sentry_timestamp("") is False
    assert verify_sentry_timestamp("garbage") is False
