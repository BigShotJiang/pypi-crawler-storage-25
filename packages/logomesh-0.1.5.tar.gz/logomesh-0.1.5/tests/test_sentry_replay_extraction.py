"""Tests for the extended Sentry event extraction.

Validates that `_parse_event_to_exception` pulls request / modules /
breadcrumbs / threads / runtime / release / transaction from realistic
Sentry payloads, and that PII redaction fires on every high-risk
surface (headers, request body, breadcrumb data, query string).
"""

from __future__ import annotations

from oracles.sentry_replay import (
    SentryBreadcrumb,
    SentryRequest,
    SentryRuntime,
    SentryThread,
    _parse_event_to_exception,
    _redact_headers,
)


def _base_event(extra_entries: list[dict] | None = None, **top_level) -> dict:
    """Minimal event with an exception entry; tests merge in more entries."""
    entries = [
        {
            "type": "exception",
            "data": {
                "values": [
                    {
                        "type": "ValueError",
                        "value": "invalid input",
                        "stacktrace": {
                            "frames": [
                                {
                                    "filename": "app/views.py",
                                    "function": "checkout",
                                    "lineNo": 42,
                                    "contextLine": "raise ValueError('invalid input')",
                                    "vars": {"qty": "-1", "item_id": "1"},
                                }
                            ]
                        },
                    }
                ]
            },
        }
    ]
    if extra_entries:
        entries.extend(extra_entries)
    base = {
        "entries": entries,
        "dateCreated": "2026-05-10T00:00:00Z",
        "groupID": "GROUP-1",
    }
    base.update(top_level)
    return base


# ---- Request extraction ---------------------------------------------------

def test_parse_request_from_entries_data():
    event = _base_event(
        extra_entries=[
            {
                "type": "request",
                "data": {
                    "method": "POST",
                    "url": "https://api.example/v1/orders",
                    "headers": {
                        "Authorization": "Bearer sk_live_secret",
                        "Content-Type": "application/json",
                        "X-Api-Key": "secret",
                    },
                    "data": {"amount": 100, "customer_email": "buyer@example.com"},
                    "queryString": "ref=abc&token=hide-me",
                },
            }
        ]
    )
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    r = exc.request
    assert isinstance(r, SentryRequest)
    assert r.method == "POST"
    assert r.url == "https://api.example/v1/orders"
    assert r.headers["Content-Type"] == "application/json"
    # Authorization header is masked, header NAME kept
    assert r.headers["Authorization"] == "[REDACTED:HEADER]"
    assert r.headers["X-Api-Key"] == "[REDACTED:HEADER]"
    # Body is dict — recursively redacted; email is scrubbed by value-side regex
    assert isinstance(r.data, dict)
    assert r.data["amount"] == 100
    assert r.data["customer_email"] != "buyer@example.com"


def test_parse_request_from_top_level():
    event = _base_event(
        request={
            "method": "GET",
            "url": "https://example/",
            "headers": [["User-Agent", "tester/1"], ["Cookie", "session=abc"]],
            "data": "raw body",
        },
    )
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None and exc.request is not None
    assert exc.request.method == "GET"
    assert exc.request.headers["User-Agent"] == "tester/1"
    assert exc.request.headers["Cookie"] == "[REDACTED:HEADER]"


def test_parse_request_absent_returns_none():
    exc = _parse_event_to_exception(_base_event(), "1", "https://sentry.io")
    assert exc is not None
    assert exc.request is None


# ---- Modules extraction ---------------------------------------------------

def test_parse_modules_pulls_pip_freeze_map():
    event = _base_event(modules={"django": "5.0.1", "celery": "5.4.0", "stripe": "11.1.0"})
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert exc.modules["django"] == "5.0.1"
    assert exc.modules["celery"] == "5.4.0"
    assert exc.modules["stripe"] == "11.1.0"


def test_parse_modules_missing_returns_empty_dict():
    exc = _parse_event_to_exception(_base_event(), "1", "https://sentry.io")
    assert exc is not None
    assert exc.modules == {}


# ---- Breadcrumbs extraction ----------------------------------------------

def test_parse_breadcrumbs_redacts_data():
    event = _base_event(
        extra_entries=[
            {
                "type": "breadcrumbs",
                "data": {
                    "values": [
                        {
                            "timestamp": "2026-05-10T00:00:00Z",
                            "category": "celery",
                            "type": "info",
                            "level": "info",
                            "message": "process_payment_started",
                            "data": {
                                "task_id": "abc-123",
                                "customer_email": "leak@example.com",
                                "amount_cents": 1499,
                            },
                        },
                        {
                            "timestamp": "2026-05-10T00:00:01Z",
                            "category": "celery",
                            "type": "info",
                            "level": "info",
                            "message": "process_payment_failed",
                            "data": {"task_id": "abc-123", "error_type": "IntegrityError"},
                        },
                    ]
                },
            }
        ]
    )
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert len(exc.breadcrumbs) == 2
    first = exc.breadcrumbs[0]
    assert isinstance(first, SentryBreadcrumb)
    assert first.category == "celery"
    assert first.message == "process_payment_started"
    # Email in breadcrumb data is scrubbed by value-side regex
    assert first.data["task_id"] == "abc-123"
    assert first.data["customer_email"] != "leak@example.com"
    assert first.data["amount_cents"] == 1499


def test_parse_breadcrumbs_top_level_shape():
    event = _base_event(breadcrumbs={"values": [{"category": "auth", "message": "login"}]})
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert len(exc.breadcrumbs) == 1
    assert exc.breadcrumbs[0].category == "auth"


# ---- Threads extraction ---------------------------------------------------

def test_parse_threads_with_locks_and_state():
    event = _base_event(
        extra_entries=[
            {
                "type": "threads",
                "data": {
                    "values": [
                        {
                            "id": 1,
                            "name": "MainThread",
                            "crashed": True,
                            "current": True,
                            "state": "RUNNABLE",
                            "heldLocks": ["payments_order_lock"],
                            "stacktrace": {
                                "frames": [
                                    {"filename": "x.py", "function": "f", "lineNo": 1, "vars": {}}
                                ]
                            },
                        },
                        {
                            "id": 2,
                            "name": "Worker-1",
                            "crashed": False,
                            "state": "BLOCKED",
                            "held_locks": [],
                        },
                    ]
                },
            }
        ]
    )
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert len(exc.threads) == 2
    main = exc.threads[0]
    assert isinstance(main, SentryThread)
    assert main.crashed is True
    assert main.held_locks == ["payments_order_lock"]
    assert main.state == "RUNNABLE"
    assert len(main.frames) == 1
    worker = exc.threads[1]
    assert worker.state == "BLOCKED"
    assert worker.crashed is False


# ---- Runtime + release + transaction --------------------------------------

def test_parse_runtime_context():
    event = _base_event(contexts={"runtime": {"name": "CPython", "version": "3.12.5", "build": "main"}})
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert isinstance(exc.runtime, SentryRuntime)
    assert exc.runtime.name == "CPython"
    assert exc.runtime.version == "3.12.5"


def test_parse_runtime_missing_returns_none():
    exc = _parse_event_to_exception(_base_event(), "1", "https://sentry.io")
    assert exc is not None
    assert exc.runtime is None


def test_parse_release_top_level():
    event = _base_event(release="payments@a1b2c3d4")
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert exc.release == "payments@a1b2c3d4"


def test_parse_transaction_from_top_level():
    event = _base_event(transaction="payments.views.checkout")
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert exc.transaction == "payments.views.checkout"


def test_parse_transaction_from_tags_dict():
    event = _base_event(tags={"transaction": "/api/v1/orders"})
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert exc.transaction == "/api/v1/orders"


def test_parse_transaction_from_tags_list_of_pairs():
    event = _base_event(tags=[["environment", "prod"], ["transaction", "celery.process_payment"]])
    exc = _parse_event_to_exception(event, "1", "https://sentry.io")
    assert exc is not None
    assert exc.transaction == "celery.process_payment"


# ---- Header redaction unit test -------------------------------------------

def test_redact_headers_allowlist():
    h = _redact_headers({
        "Content-Type": "application/json",
        "Accept": "text/html",
        "Authorization": "Bearer xyz",
        "X-Custom": "secret",
    })
    assert h["Content-Type"] == "application/json"
    assert h["Accept"] == "text/html"
    assert h["Authorization"] == "[REDACTED:HEADER]"
    assert h["X-Custom"] == "[REDACTED:HEADER]"


def test_redact_headers_list_of_pairs():
    h = _redact_headers([["User-Agent", "tester"], ["Cookie", "session=abc"]])
    assert h["User-Agent"] == "tester"
    assert h["Cookie"] == "[REDACTED:HEADER]"


def test_redact_headers_empty_or_invalid():
    assert _redact_headers(None) == {}
    assert _redact_headers([]) == {}
    assert _redact_headers([["only-one-item"]]) == {}


# ---- Backwards compatibility: existing single-frame path still works -----

def test_minimal_event_no_extras_still_parses():
    exc = _parse_event_to_exception(_base_event(), "1", "https://sentry.io")
    assert exc is not None
    assert exc.error_type == "ValueError"
    assert exc.error_message == "invalid input"
    assert len(exc.frames) == 1
    assert exc.frames[0].function == "checkout"
    # All new fields default to empty / None
    assert exc.request is None
    assert exc.modules == {}
    assert exc.breadcrumbs == []
    assert exc.threads == []
    assert exc.runtime is None
    assert exc.release == ""
    assert exc.transaction == ""
