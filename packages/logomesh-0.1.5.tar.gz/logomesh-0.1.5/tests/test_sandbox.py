import sys
from types import SimpleNamespace

from business_logic.sandbox import Sandbox, _extract_collection_error


def test_extract_collection_error_module_not_found():
    output = """
ERROR collecting test_target.py
E   ModuleNotFoundError: No module named 'django'
"""
    kind, msg = _extract_collection_error(output, report={"summary": {"total": 0, "collected": 0}})
    assert kind == "dependency_import_error"
    assert "No module named 'django'" in msg


def test_extract_collection_error_syntax_error():
    output = """
ERROR collecting test_target.py
E   SyntaxError: invalid syntax
"""
    kind, msg = _extract_collection_error(output, report={"summary": {"total": 0, "collected": 0}})
    assert kind == "test_syntax_error"
    assert "invalid syntax" in msg


def test_extract_collection_error_importing_test_module_pattern():
    output = """
ERROR collecting test_target.py
ImportError while importing test module '/workspace/test_target.py'.
E   ImportError: cannot import name 'Settings' from 'app.config'
"""
    kind, msg = _extract_collection_error(output, report={"summary": {"total": 0, "collected": 0}})
    assert kind == "dependency_import_error"
    assert "cannot import name" in msg


def test_extract_collection_error_timeout_bucket():
    output = "TIMEOUT: exceeded 15s"
    kind, msg = _extract_collection_error(output, report={"summary": {"total": 0, "collected": 0}})
    assert kind == "sandbox_timeout"
    assert "timeout" in msg


def test_run_subprocess_uses_current_interpreter_and_no_json_report(monkeypatch):
    seen = {}

    def _fake_run(cmd, cwd, capture_output, text, timeout, env):
        seen["cmd"] = cmd
        return SimpleNamespace(returncode=0, stdout="1 passed\n", stderr="")

    monkeypatch.setattr("business_logic.sandbox.subprocess.run", _fake_run)

    sandbox = Sandbox()
    result = sandbox._run_subprocess(
        {
            "target.py": "def f():\n    return 1\n",
            "test_target.py": "from target import f\n\ndef test_ok():\n    assert f() == 1\n",
            "conftest.py": "",
        },
        "test_target.py",
    )

    assert seen["cmd"][0] == sys.executable
    assert "--json-report" not in seen["cmd"]
    assert "test_target.py" in seen["cmd"]
    assert "test_*.py" not in seen["cmd"]
    assert result["success"] is True
    assert result["passed"] == 1
