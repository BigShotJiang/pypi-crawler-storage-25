from usage_tracker import reset_usage, add_usage, get_usage, estimate_cost_usd

def test_accumulates():
    reset_usage()
    add_usage(100, 50)
    add_usage(200, 80)
    ti, to = get_usage()
    assert ti == 300
    assert to == 130

def test_reset():
    add_usage(999, 999)
    reset_usage()
    ti, to = get_usage()
    assert ti == 0
    assert to == 0

def test_cost_estimate_default_rate():
    # No model specified → falls back to claude-sonnet baseline
    # ($3/M input + $15/M output = $18 per 1M+1M tokens).
    cost = estimate_cost_usd(1_000_000, 1_000_000)
    assert abs(cost - 18.0) < 0.001

def test_cost_estimate_known_model():
    # gpt-5-mini = $0.25/M in + $2.00/M out = $2.25 per 1M+1M.
    cost = estimate_cost_usd(1_000_000, 1_000_000, model="gpt-5-mini")
    assert abs(cost - 2.25) < 0.01

def test_cost_estimate_local_model_zero():
    # Self-hosted Qwen has zero list price.
    assert estimate_cost_usd(1_000_000, 1_000_000, model="qwen-coder") == 0.0

def test_zero_cost():
    assert estimate_cost_usd(0, 0) == 0.0


def test_budget_exceeded_input_tokens():
    import os
    from usage_tracker import check_budget, TokenBudgetExceeded
    os.environ["LOGOMESH_TOKEN_BUDGET_IN"] = "100"
    os.environ["LOGOMESH_TOKEN_BUDGET_OUT"] = "100"
    os.environ["LOGOMESH_USD_BUDGET"] = "1000"
    reset_usage()
    add_usage(200, 0)
    try:
        check_budget()
        raise AssertionError("expected TokenBudgetExceeded")
    except TokenBudgetExceeded as e:
        assert "input tokens" in str(e)


def test_budget_exceeded_usd():
    import os
    from usage_tracker import check_budget, TokenBudgetExceeded
    os.environ["LOGOMESH_TOKEN_BUDGET_IN"] = "999999999"
    os.environ["LOGOMESH_TOKEN_BUDGET_OUT"] = "999999999"
    os.environ["LOGOMESH_USD_BUDGET"] = "0.10"
    reset_usage()
    # 1M+1M @ default sonnet rate = $18 → trips $0.10 cap.
    add_usage(1_000_000, 1_000_000)
    try:
        check_budget()
        raise AssertionError("expected TokenBudgetExceeded")
    except TokenBudgetExceeded as e:
        assert "estimated cost" in str(e)


def test_usage_summary_shape():
    from usage_tracker import usage_summary
    reset_usage()
    add_usage(500, 100, model="gpt-5-mini")
    s = usage_summary()
    assert s["tokens_in"] == 500
    assert s["tokens_out"] == 100
    assert s["model"] == "gpt-5-mini"
    assert s["cost_usd"] >= 0
    assert "budget_in" in s and "budget_out" in s and "budget_usd" in s
