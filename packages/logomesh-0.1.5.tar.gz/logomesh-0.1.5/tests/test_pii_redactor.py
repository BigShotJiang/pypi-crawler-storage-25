"""Unit tests for ``core.pii_redactor``.

Coverage targets:
* PAN: Luhn-validated positive + negative cases (real card prefixes,
  separators, variable lengths 13/15/16/19).
* SSN, email, JWT, all known API-key prefixes.
* Field-name token-split policy (PCI-allowed ``card_last4`` not redacted,
  ``user_email`` and ``billing_card_number`` redacted).
* Idempotency on every primitive.
* Recursive ``redact_value`` / ``redact_mapping`` semantics.
* Free-text ``key=value`` scrubber preserves more-specific type markers
  (PAN > FIELD downgrade is forbidden).
"""

from core.pii_redactor import (
    is_sensitive_key,
    luhn_valid,
    redact_mapping,
    redact_text,
    redact_value,
)


# ---------------------------------------------------------------------------
# Luhn
# ---------------------------------------------------------------------------

class TestLuhn:
    def test_visa_test_card_4242(self):
        assert luhn_valid("4242424242424242") is True

    def test_visa_4111(self):
        assert luhn_valid("4111111111111111") is True

    def test_mastercard_test(self):
        assert luhn_valid("5555555555554444") is True

    def test_amex_15_digit(self):
        assert luhn_valid("378282246310005") is True

    def test_discover_19_digit(self):
        # Discover allows up to 19 digits; example check digit
        assert luhn_valid("6011000990139424") is True  # 16-digit Discover test

    def test_invalid_one_digit_off(self):
        assert luhn_valid("4111111111114242") is False

    def test_too_short(self):
        assert luhn_valid("411111111111") is False

    def test_too_long(self):
        assert luhn_valid("4" * 20) is False

    def test_non_digit_rejected(self):
        assert luhn_valid("4111-1111-1111-1111") is False  # dashes not allowed in helper


# ---------------------------------------------------------------------------
# PAN regex + Luhn
# ---------------------------------------------------------------------------

class TestPan:
    def test_pan_raw_redacted(self):
        assert redact_text("card 4111111111111111 here") == "card [REDACTED:PAN] here"

    def test_pan_with_dashes(self):
        assert redact_text("4111-1111-1111-1111") == "[REDACTED:PAN]"

    def test_pan_with_spaces(self):
        assert redact_text("4111 1111 1111 1111") == "[REDACTED:PAN]"

    def test_amex_15_digit_raw(self):
        # AmEx grouping 4-6-5 = 15 digits; 378282246310005 is Luhn-valid
        assert redact_text("amex 378282246310005") == "amex [REDACTED:PAN]"

    def test_non_luhn_long_id_not_redacted(self):
        # A 14-digit transaction id that fails Luhn must NOT be over-redacted.
        # 12345678901234 → Luhn check should fail
        out = redact_text("transaction 12345678901234 failed")
        assert "[REDACTED:PAN]" not in out
        assert "12345678901234" in out

    def test_short_digit_sequence_not_redacted(self):
        # 4-digit last4 stays
        assert redact_text("card_last4=4242") == "card_last4=4242"

    def test_pan_idempotent(self):
        s = "4111-1111-1111-1111 / 5555555555554444"
        assert redact_text(redact_text(s)) == redact_text(s)


# ---------------------------------------------------------------------------
# SSN
# ---------------------------------------------------------------------------

class TestSsn:
    def test_dashed_ssn(self):
        assert redact_text("ssn 123-45-6789") == "ssn [REDACTED:SSN]"

    def test_word_boundary(self):
        # 9 raw digits with no dashes is ambiguous; we only match the
        # canonical dashed form to avoid false-positives on phone numbers.
        out = redact_text("number 123456789")
        assert "[REDACTED:SSN]" not in out


# ---------------------------------------------------------------------------
# Email
# ---------------------------------------------------------------------------

class TestEmail:
    def test_simple_email(self):
        assert redact_text("alice@example.com") == "[REDACTED:EMAIL]"

    def test_email_in_sentence(self):
        out = redact_text("contact alice.cooper+sales@example.co.uk for info")
        assert out == "contact [REDACTED:EMAIL] for info"

    def test_no_false_positive_on_at_sign(self):
        # "@channel" alone shouldn't trigger
        out = redact_text("ping @channel")
        assert "[REDACTED:EMAIL]" not in out


# ---------------------------------------------------------------------------
# API key prefixes — every prefix declared in the regex
# ---------------------------------------------------------------------------

class TestApiKeyPrefixes:
    def test_stripe_secret(self):
        assert redact_text("sk_test_" + "a" * 24) == "[REDACTED:API_KEY]"
        assert redact_text("sk_live_" + "b" * 24) == "[REDACTED:API_KEY]"

    def test_stripe_publishable(self):
        assert redact_text("pk_test_" + "a" * 24) == "[REDACTED:API_KEY]"

    def test_stripe_restricted(self):
        assert redact_text("rk_live_" + "a" * 24) == "[REDACTED:API_KEY]"

    def test_stripe_webhook_signing(self):
        assert redact_text("whsec_" + "a" * 24) == "[REDACTED:API_KEY]"

    def test_openai_anthropic_secret(self):
        assert redact_text("sk-" + "a" * 32) == "[REDACTED:API_KEY]"

    def test_github_personal_token(self):
        assert redact_text("ghp_" + "a" * 36) == "[REDACTED:API_KEY]"

    def test_github_oauth(self):
        assert redact_text("gho_" + "a" * 36) == "[REDACTED:API_KEY]"

    def test_github_user_to_server(self):
        assert redact_text("ghu_" + "a" * 36) == "[REDACTED:API_KEY]"

    def test_github_server_to_server(self):
        assert redact_text("ghs_" + "a" * 36) == "[REDACTED:API_KEY]"

    def test_github_refresh(self):
        assert redact_text("ghr_" + "a" * 36) == "[REDACTED:API_KEY]"

    def test_github_fine_grained_pat(self):
        assert redact_text("github_pat_" + "a" * 24) == "[REDACTED:API_KEY]"

    def test_slack_bot_user_app(self):
        assert redact_text("xoxb-" + "1" * 25) == "[REDACTED:API_KEY]"
        assert redact_text("xoxp-" + "1" * 25) == "[REDACTED:API_KEY]"
        assert redact_text("xoxa-" + "1" * 25) == "[REDACTED:API_KEY]"
        assert redact_text("xoxr-" + "1" * 25) == "[REDACTED:API_KEY]"
        assert redact_text("xoxs-" + "1" * 25) == "[REDACTED:API_KEY]"

    def test_aws_access_key_id(self):
        assert redact_text("AKIA1234567890ABCDEF") == "[REDACTED:API_KEY]"

    def test_aws_sts_access_key_id(self):
        assert redact_text("ASIA1234567890ABCDEF") == "[REDACTED:API_KEY]"

    def test_google_api_key(self):
        assert redact_text("AIza" + "X" * 35) == "[REDACTED:API_KEY]"

    def test_api_key_in_authorization_header(self):
        out = redact_text("Authorization: Bearer sk_test_" + "x" * 24)
        # Both the header field-name match and the Bearer token redaction
        # fire; either way the key itself doesn't survive.
        assert "sk_test_" not in out


# ---------------------------------------------------------------------------
# JWT
# ---------------------------------------------------------------------------

class TestJwt:
    def test_jwt_shape(self):
        token = (
            "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
            ".eyJzdWIiOiIxMjM0NSIsImlhdCI6MTUxNjIzOTAyMn0"
            ".SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
        )
        assert redact_text(token) == "[REDACTED:JWT]"

    def test_jwt_in_text(self):
        token = "eyJhbGciOiJ.eyJzdWIiOiI.signature_here"
        out = redact_text(f"token={token} expires=soon")
        assert "[REDACTED:JWT]" in out
        assert "eyJ" not in out


# ---------------------------------------------------------------------------
# Field-name policy
# ---------------------------------------------------------------------------

class TestFieldName:
    def test_exact_match(self):
        assert is_sensitive_key("cvv") is True
        assert is_sensitive_key("card_number") is True
        assert is_sensitive_key("password") is True
        assert is_sensitive_key("ssn") is True

    def test_case_insensitive(self):
        assert is_sensitive_key("CVV") is True
        assert is_sensitive_key("Card_Number") is True
        assert is_sensitive_key("AUTHORIZATION") is True

    def test_token_split(self):
        assert is_sensitive_key("user_email") is True
        assert is_sensitive_key("billing-card_number") is True
        assert is_sensitive_key("partial_pan") is True
        assert is_sensitive_key("x_api_key") is True

    def test_pci_allowed_card_last4_not_sensitive(self):
        assert is_sensitive_key("card_last4") is False

    def test_no_substring_false_positive(self):
        assert is_sensitive_key("japan") is False
        assert is_sensitive_key("panel") is False
        assert is_sensitive_key("status_panel") is False

    def test_non_string_returns_false(self):
        assert is_sensitive_key(None) is False
        assert is_sensitive_key(42) is False


# ---------------------------------------------------------------------------
# redact_mapping / redact_value
# ---------------------------------------------------------------------------

class TestRedactMapping:
    def test_field_name_match(self):
        out = redact_mapping({"cvv": "123", "amount": "10.0"})
        assert out["cvv"] == "[REDACTED:FIELD]"
        assert out["amount"] == "10.0"

    def test_recursive_mapping(self):
        nested = {"outer": {"password": "hunter2", "ok": "yes"}}
        out = redact_mapping(nested)
        assert out["outer"]["password"] == "[REDACTED:FIELD]"
        assert out["outer"]["ok"] == "yes"

    def test_value_pan_scrubbed(self):
        out = redact_mapping({"customer_token": "4242424242424242"})
        # field-name match wins (token is sensitive)
        assert out["customer_token"] == "[REDACTED:FIELD]"

    def test_value_pan_via_non_sensitive_field(self):
        # Field name not on the list, but value is a Luhn-valid PAN.
        out = redact_mapping({"note": "card 4242424242424242 declined"})
        assert "4242424242424242" not in out["note"]
        assert "[REDACTED:PAN]" in out["note"]

    def test_card_last4_preserved(self):
        out = redact_mapping({"card_last4": "4242"})
        assert out["card_last4"] == "4242"

    def test_idempotent(self):
        d = {"cvv": "123", "user_email": "a@b.co", "amount": "10.0",
             "scenario": {"partial_pan": "4111111111114242"}}
        once = redact_mapping(d)
        twice = redact_mapping(once)
        assert once == twice

    def test_list_recursion(self):
        out = redact_value([{"cvv": "x"}, {"ok": "y"}])
        assert out == [{"cvv": "[REDACTED:FIELD]"}, {"ok": "y"}]

    def test_tuple_preserved(self):
        out = redact_value(("a@b.co", "ok"))
        assert isinstance(out, tuple)
        assert out[0] == "[REDACTED:EMAIL]"

    def test_decimal_pan_shape_caught(self):
        # str(Decimal("4111111111111111")) == "4111111111111111" → Luhn-valid
        from decimal import Decimal
        out = redact_value(Decimal("4111111111111111"))
        assert out == "[REDACTED:PAN]"


# ---------------------------------------------------------------------------
# Free-text field=value scrubber + type-marker preservation
# ---------------------------------------------------------------------------

class TestFreeText:
    def test_field_value_in_message(self):
        msg = "amount must be > 0, got -1.0 (card_last4=4242, partial_pan=4111111111114242)"
        out = redact_text(msg)
        assert "4111111111114242" not in out
        assert "card_last4=4242" in out  # PCI-allowed, untouched
        assert "partial_pan=[REDACTED:FIELD]" in out

    def test_pan_type_not_downgraded(self):
        # Luhn-valid PAN should remain `[REDACTED:PAN]`, not `[REDACTED:FIELD]`.
        msg = "card 4111-1111-1111-1111 declined"
        out = redact_text(msg)
        assert "[REDACTED:PAN]" in out

    def test_idempotent_field_value(self):
        msg = "user_email=alice@example.com cvv=123 partial_pan=4242"
        a = redact_text(msg)
        b = redact_text(a)
        c = redact_text(b)
        assert a == b == c

    def test_colon_separator(self):
        out = redact_text("password: hunter2")
        assert "hunter2" not in out
        assert "[REDACTED:FIELD]" in out


# ---------------------------------------------------------------------------
# Idempotency (universal)
# ---------------------------------------------------------------------------

class TestIdempotency:
    def test_text_idempotent_complex(self):
        s = (
            "alice@example.com contacted; sk_test_" + "a" * 24
            + " was used; card 4242-4242-4242-4242 declined; "
            + "ssn 123-45-6789; partial_pan=4111111111114242; "
            + "Authorization: Bearer ghp_" + "x" * 36
        )
        a = redact_text(s)
        b = redact_text(a)
        c = redact_text(b)
        assert a == b == c
        # Nothing PII-shaped survived
        for needle in [
            "alice@example.com", "sk_test_", "4242-4242-4242-4242",
            "123-45-6789", "4111111111114242", "ghp_",
        ]:
            assert needle not in c, f"{needle!r} survived in: {c!r}"
