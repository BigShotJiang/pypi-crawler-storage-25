"""install() entrypoint behavior — idempotency + default-redact merge."""

from __future__ import annotations

import capture
from capture.serializer import DEFAULT_REDACT_FIELDS, merge_redact_fields


def test_install_is_idempotent():
    capture.install()
    capture.install(redact_fields=["custom"])
    # Calling twice doesn't raise.


def test_default_redact_list_merge_keeps_user_extras_and_baseline():
    merged = merge_redact_fields(["x_custom_secret"])
    assert "x_custom_secret" in merged
    # Baseline still in place.
    for f in DEFAULT_REDACT_FIELDS:
        assert f in merged
