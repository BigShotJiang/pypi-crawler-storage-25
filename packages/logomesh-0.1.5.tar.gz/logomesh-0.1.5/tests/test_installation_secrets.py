"""Tests for src/core/installation_secrets.py.

Supabase is mocked at the `_get_client` layer so these run offline.
"""
import base64
import os

import pytest

from core import installation_secrets as ins


@pytest.fixture
def master_key(monkeypatch):
    key = base64.urlsafe_b64encode(os.urandom(32)).decode()
    monkeypatch.setenv("LOGOMESH_MASTER_KEY", key)
    return key


def test_encrypt_decrypt_roundtrip(master_key):
    blob = ins.encrypt_value("sk-test-1234567890")
    assert blob.startswith("lmsec-v1:")
    assert ins.decrypt_value(blob) == "sk-test-1234567890"


def test_encrypt_unique_nonce(master_key):
    a = ins.encrypt_value("same")
    b = ins.encrypt_value("same")
    assert a != b
    assert ins.decrypt_value(a) == ins.decrypt_value(b) == "same"


def test_decrypt_with_wrong_key_yields_empty(master_key, monkeypatch):
    blob = ins.encrypt_value("hello")
    new_key = base64.urlsafe_b64encode(os.urandom(32)).decode()
    monkeypatch.setenv("LOGOMESH_MASTER_KEY", new_key)
    assert ins.decrypt_value(blob) == ""


def test_decrypt_with_no_key_yields_empty(monkeypatch):
    monkeypatch.delenv("LOGOMESH_MASTER_KEY", raising=False)
    assert ins.decrypt_value("lmsec-v1:" + base64.urlsafe_b64encode(b"x" * 30).decode()) == ""


def test_encrypt_with_no_key_raises(monkeypatch):
    monkeypatch.delenv("LOGOMESH_MASTER_KEY", raising=False)
    with pytest.raises(RuntimeError, match="LOGOMESH_MASTER_KEY"):
        ins.encrypt_value("anything")


def test_decrypt_unknown_prefix_returns_empty(master_key):
    assert ins.decrypt_value("plaintext") == ""
    assert ins.decrypt_value("") == ""
    assert ins.decrypt_value("notourblob:abc") == ""


def test_is_encrypted_recognises_blob(master_key):
    assert ins.is_encrypted(ins.encrypt_value("x"))
    assert not ins.is_encrypted("plaintext")
    assert not ins.is_encrypted("")
    assert not ins.is_encrypted(None)


def test_master_key_accepts_hex(monkeypatch):
    raw = os.urandom(32)
    monkeypatch.setenv("LOGOMESH_MASTER_KEY", raw.hex())
    assert ins._master_key_bytes() == raw


def test_resolve_secrets_falls_back_to_env(monkeypatch, master_key):
    monkeypatch.setenv("LOGOMESH_SENTRY_AUTH_TOKEN", "env-sentry-token")
    monkeypatch.setenv("GITHUB_TOKEN", "env-gh-token")
    monkeypatch.setenv("OPENAI_API_KEY", "env-openai")
    sec = ins.resolve_secrets(installation_id=None)
    assert sec.sentry_auth_token == "env-sentry-token"
    assert sec.github_token == "env-gh-token"
    assert sec.openai_api_key == "env-openai"


def test_redacted_dict_masks_secrets(master_key):
    sec = ins.InstallationSecrets(
        installation_id="11111111-2222-3333-4444-555555555555",
        sentry_auth_token="sk_secret_token_value_xxxx",
        github_token="abc12",
        openai_api_key="",
        repo_path="/srv/repos/customer-x",
        github_repo="acme/billing",
    )
    d = sec.as_redacted_dict()
    assert d["installation_id"] == "11111111-2222-3333-4444-555555555555"
    assert d["repo_path"] == "/srv/repos/customer-x"
    assert d["github_repo"] == "acme/billing"
    assert d["sentry_auth_token"] == "sk_s…xx"
    assert d["github_token"] == "***"
    assert d["openai_api_key"] == ""


def test_resolve_secrets_supabase_first(monkeypatch, master_key):
    monkeypatch.setenv("LOGOMESH_SENTRY_AUTH_TOKEN", "env-token")
    monkeypatch.setenv("GITHUB_TOKEN", "env-gh")
    fake = ins.InstallationSecrets(
        installation_id="abc-uuid", sentry_auth_token="db-token",
    )
    monkeypatch.setattr(ins, "fetch_installation_secrets",
                        lambda _i: fake)
    sec = ins.resolve_secrets(installation_id="abc-uuid")
    assert sec.sentry_auth_token == "db-token"   # DB wins
    assert sec.github_token == "env-gh"          # env fills the gap
