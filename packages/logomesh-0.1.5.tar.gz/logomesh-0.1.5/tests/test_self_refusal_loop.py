"""Tests for the agent self-refusal loop (Fix 5).

When `resolve_source_fuzzy` cannot find the target file on disk, the tool
must:
  1. On first attempt: return retryable=True with module_guess + basename
     so the supervisor can web_search/rag_search and re-invoke with
     path_hints=[...].
  2. On second attempt that also fails: return human_review=True with
     reason=source_not_found_retry_exhausted.
  3. If the supplied path_hints resolve to a real file: synthesize and
     run normally.

Also covers the standalone resolver helper.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from unittest import mock

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))
sys.path.insert(0, str(_REPO_ROOT / "src"))

from oracles.sentry_replay_v2 import (  # noqa: E402
    resolve_source_fuzzy,
    resolve_source_with_hints,
)
import logomesh_orchestrator as o  # noqa: E402


# ---- standalone resolver -------------------------------------------------

def test_resolve_with_hints_uses_hint_first(tmp_path: Path):
    (tmp_path / "deep").mkdir()
    real = tmp_path / "deep" / "billing.py"
    real.write_text("# real\n")
    out = resolve_source_with_hints(
        "/app/src/billing.py", tmp_path, path_hints=["deep/billing.py"],
    )
    assert "# real" in out


def test_resolve_with_hints_falls_back(tmp_path: Path):
    (tmp_path / "src").mkdir()
    real = tmp_path / "src" / "billing.py"
    real.write_text("# fallback\n")
    out = resolve_source_with_hints(
        "/app/src/billing.py", tmp_path, path_hints=["does/not/exist.py"],
    )
    assert "# fallback" in out


def test_resolve_with_hints_returns_empty_when_nothing_works(tmp_path: Path):
    out = resolve_source_with_hints(
        "/app/missing.py", tmp_path, path_hints=["nope.py"],
    )
    assert out == ""


# ---- self-refusal loop ---------------------------------------------------

def _seed_session(sid: str, filename: str = "/app/src/missing.py"):
    """Push a SentryException into _EVENT_REGISTRY so deterministic_repro
    finds something to work with. Frame points at a file that won't resolve."""
    from oracles.sentry_replay import SentryException, SentryFrame  # type: ignore
    frame = SentryFrame(
        filename=filename, function="apply_discount", lineno=42,
        context_line="    return price * (1 - pct/100)",
        variables={"price": "49.95", "pct": "-50"},
    )
    exc = SentryException(
        issue_id="9999", issue_url="https://sentry.io/issues/9999/",
        error_type="ValueError", error_message="bad",
        last_seen="2026-05-06T00:00:00", event_count=1,
        frames=[frame],
    )
    o._EVENT_REGISTRY[sid] = {"exc": exc, "frame": frame,
                              "snapshot": {"issue_id": "9999"}}
    o._AUDIT_REGISTRY[sid] = o.AuditSession(sid)


def _cleanup(sid: str):
    for r in (o._AUDIT_REGISTRY, o._EVENT_REGISTRY,
              o._REPRO_REGISTRY, o._ENV_REGISTRY, o._RESOLVE_REGISTRY):
        r.pop(sid, None)


def test_first_failure_returns_retryable(tmp_path: Path):
    sid = "test_self_refusal_1"
    _seed_session(sid)
    try:
        raw = asyncio.run(o._tool_deterministic_repro(
            session_id=sid, repo_path=str(tmp_path), timeout_s=5,
        ))
        out = json.loads(raw)
        assert out.get("retryable") is True
        assert out.get("reason") == "source_not_found"
        assert out.get("basename") == "missing.py"
        assert "module_guess" in out
        assert out["attempts"] == 1
        assert out["max_attempts"] == 2
        assert "next_action" in out
        # Critically: NOT human_review on the first attempt.
        assert out.get("human_review") is not True
    finally:
        _cleanup(sid)


def test_second_failure_exhausts_retry(tmp_path: Path):
    sid = "test_self_refusal_exhaust"
    _seed_session(sid)
    try:
        # First call → retryable.
        raw1 = asyncio.run(o._tool_deterministic_repro(
            session_id=sid, repo_path=str(tmp_path), timeout_s=5,
        ))
        out1 = json.loads(raw1)
        assert out1.get("retryable") is True

        # Second call (with bogus hints) → exhausted.
        raw2 = asyncio.run(o._tool_deterministic_repro(
            session_id=sid, repo_path=str(tmp_path), timeout_s=5,
            path_hints=["bogus_a.py", "bogus_b.py"],
        ))
        out2 = json.loads(raw2)
        assert out2.get("human_review") is True
        assert out2.get("reason") == "source_not_found_retry_exhausted"
        assert "bogus_a.py" in out2.get("tried_hints", [])
    finally:
        _cleanup(sid)


def test_retry_with_real_hint_resolves(tmp_path: Path):
    """If supervisor recovers the right path, repro should proceed past
    the resolver. We mock Sandbox.run so we don't actually exec pytest.

    The frame names a file `unfindable_xyz.py`. We place the real source
    under a different basename `actual_billing.py` so rglob can't find
    it on first pass — only the explicit path_hint resolves it.
    """
    sid = "test_self_refusal_resolve"
    deep = tmp_path / "src" / "billing"
    deep.mkdir(parents=True)
    target = deep / "actual_billing.py"
    target.write_text(
        "def apply_discount(price, pct):\n"
        "    if pct < 0: raise ValueError('bad pct')\n"
        "    return price * (1 - pct/100)\n"
    )
    _seed_session(sid, filename="/app/src/billing/unfindable_xyz.py")
    try:
        # First call — fails.
        raw1 = asyncio.run(o._tool_deterministic_repro(
            session_id=sid, repo_path=str(tmp_path), timeout_s=5,
        ))
        assert json.loads(raw1).get("retryable") is True

        # Mock the Sandbox so we don't shell out to docker. We assert that
        # the path resolution succeeded (no source_not_found return).
        fake_run = mock.MagicMock(return_value={
            "passed": 0, "failed": 1, "total": 1, "duration": 0.1,
            "output": "E   ValueError: bad pct\n",
            "success": True,
        })

        class FakeSandbox:
            def __init__(self, *a, **k): self.mode = "subprocess"
            def run(self, *a, **k): return fake_run(*a, **k)

        with mock.patch("business_logic.sandbox.Sandbox", FakeSandbox):
            raw2 = asyncio.run(o._tool_deterministic_repro(
                session_id=sid, repo_path=str(tmp_path), timeout_s=5,
                path_hints=["src/billing/actual_billing.py"],
            ))
            out2 = json.loads(raw2)
            # Should NOT be a source-not-found error anymore.
            assert "source_not_found" not in (out2.get("reason") or "")
            # Should have produced a sealed result.
            assert out2.get("sealed") is True
            assert out2.get("verified_exception_match") is True
    finally:
        _cleanup(sid)
