"""Tests for oracles.api_error_fixtures."""
from oracles.api_error_fixtures import (
    match_from_locals,
    url_from_locals,
    STRIPE_ERRORS,
)


def test_all_stripe_codes_present():
    assert "card_declined" in STRIPE_ERRORS
    assert "rate_limit" in STRIPE_ERRORS
    assert "expired_card" in STRIPE_ERRORS


def test_stripe_nested_error_match():
    vars_ = {"resp": {"error": {"decline_code": "insufficient_funds"}}}
    result = match_from_locals(vars_)
    assert result is not None
    _, status, body = result
    assert status == 402


def test_no_match_plain_dict():
    vars_ = {"data": {"foo": "bar", "x": 1}}
    assert match_from_locals(vars_) is None


def test_url_prefers_stripe():
    vars_ = {
        "other": "https://example.com",
        "api_url": "https://api.stripe.com/v1/charges",
    }
    result = url_from_locals(vars_)
    assert "stripe" in result


def test_url_fallback_any_http():
    vars_ = {"endpoint": "https://example.com/api/v2"}
    assert url_from_locals(vars_) == "https://example.com/api/v2"


def test_url_empty_when_no_url():
    vars_ = {"amount": 100, "user_id": 42}
    assert url_from_locals(vars_) == ""
