"""Tests for src/server/sentry_comment.py."""

from __future__ import annotations

import sys
from pathlib import Path
from unittest import mock

import asyncio

import httpx
import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from src.server.sentry_comment import (  # noqa: E402
    post_sentry_comment,
    post_verdict_to_sentry,
    render_verdict_markdown,
)


# ---- markdown rendering --------------------------------------------------

def test_verdict_markdown_verified():
    md = render_verdict_markdown({
        "artifact": {
            "evidence_path_seal": {
                "verified_exception_match": True,
                "sandbox_exception_type": "ValueError",
                "expected_exception_type": "ValueError",
                "test_sha256_first16": "abc123def456ab12",
                "synthesizer": "frame-locals → pytest (deterministic)",
                "llm_in_evidence_path": False,
            },
        },
        "pr_url": "https://github.com/x/y/pull/42",
        "duration_s": 38.1,
    })
    assert "✅" in md
    assert "ValueError" in md
    assert "abc123def456" in md
    assert "github.com/x/y/pull/42" in md
    assert "38s" in md


def test_verdict_markdown_mismatch():
    md = render_verdict_markdown({
        "artifact": {
            "evidence_path_seal": {
                "verified_exception_match": False,
                "sandbox_exception_type": "NameError",
                "expected_exception_type": "ValueError",
            },
        },
    })
    assert "❌" in md
    assert "did not verify" in md
    assert "NameError" in md


def test_verdict_markdown_human_review():
    md = render_verdict_markdown({
        "needs_human_review": True,
        "human_review_reason": "source_not_found_retry_exhausted",
    })
    assert "⚠️" in md
    assert "source_not_found_retry_exhausted" in md


# ---- POST behavior -------------------------------------------------------

def test_post_sentry_comment_calls_correct_url(monkeypatch):
    monkeypatch.setenv("LOGOMESH_SENTRY_AUTH_TOKEN", "tok_abc")
    captured = {}

    async def fake_post(self, url, headers=None, content=None, **kw):
        captured["url"] = url
        captured["headers"] = headers
        captured["content"] = content
        req = httpx.Request("POST", url)
        return httpx.Response(201, request=req, json={"id": "c_1"})

    with mock.patch.object(httpx.AsyncClient, "post", fake_post):
        out = asyncio.run(post_sentry_comment("9999", "hello"))
        assert out == {"id": "c_1"}
        assert "/api/0/issues/9999/comments/" in captured["url"]
        assert captured["headers"]["Authorization"] == "Bearer tok_abc"
        assert "hello" in captured["content"]


def test_post_sentry_comment_raises_without_token(monkeypatch):
    monkeypatch.delenv("LOGOMESH_SENTRY_AUTH_TOKEN", raising=False)
    with pytest.raises(RuntimeError):
        asyncio.run(post_sentry_comment("9999", "hi"))


def test_post_verdict_swallows_errors(monkeypatch):
    """post_verdict_to_sentry runs in detached task — must NEVER raise."""
    monkeypatch.delenv("LOGOMESH_SENTRY_AUTH_TOKEN", raising=False)
    # Should not raise even though token is missing.
    asyncio.run(post_verdict_to_sentry("9999", {"artifact": {}}))


def test_post_sentry_comment_uses_custom_host(monkeypatch):
    monkeypatch.setenv("LOGOMESH_SENTRY_AUTH_TOKEN", "tok")
    monkeypatch.setenv("LOGOMESH_SENTRY_HOST", "https://sentry.acme.io/")
    captured = {}

    async def fake_post(self, url, headers=None, content=None, **kw):
        captured["url"] = url
        return httpx.Response(201, request=httpx.Request("POST", url), json={"id": "c"})

    with mock.patch.object(httpx.AsyncClient, "post", fake_post):
        asyncio.run(post_sentry_comment("123", "x"))
        assert captured["url"].startswith("https://sentry.acme.io/api/0/issues/123/")
