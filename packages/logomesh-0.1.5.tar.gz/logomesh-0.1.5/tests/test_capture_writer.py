"""Atomic state-file writer."""

from __future__ import annotations

import json

from capture.writer import write_state


def test_write_state_uses_event_id_filename(tmp_path):
    state = {"event_id": "abc-123", "schema_version": "1"}
    out = write_state(state, tmp_path)
    assert out.name == "abc-123.json"
    assert json.loads(out.read_text()) == state


def test_write_state_sanitizes_unsafe_event_ids(tmp_path):
    state = {"event_id": "../../etc/passwd", "schema_version": "1"}
    out = write_state(state, tmp_path)
    # No traversal: file lands inside tmp_path.
    assert out.parent == tmp_path
    assert "/" not in out.name
    assert ".." not in out.name


def test_write_state_falls_back_when_no_event_id(tmp_path):
    state = {"schema_version": "1"}
    out = write_state(state, tmp_path)
    assert out.suffix == ".json"
    assert out.parent == tmp_path
