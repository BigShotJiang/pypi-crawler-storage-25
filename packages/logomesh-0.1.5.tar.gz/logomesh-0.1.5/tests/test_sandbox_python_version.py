"""Tests for sandbox `python_version` override (PR2 part C).

The sandbox accepts `python_version="3.11"` on `.run()` and swaps its
image for that run, restoring the original image after. Pure-Python
mapping is exposed via `image_for_python_version` so callers can
prevalidate without spinning up Docker.
"""

from __future__ import annotations

from business_logic.sandbox import Sandbox


def test_image_for_known_versions():
    assert Sandbox.image_for_python_version("3.10") == "python:3.10-slim"
    assert Sandbox.image_for_python_version("3.11") == "python:3.11-slim"
    assert Sandbox.image_for_python_version("3.12") == "python:3.12-slim"
    assert Sandbox.image_for_python_version("3.13") == "python:3.13-slim"


def test_image_for_unknown_versions_returns_none():
    assert Sandbox.image_for_python_version("2.7") is None
    assert Sandbox.image_for_python_version("3.9") is None
    assert Sandbox.image_for_python_version("3.99") is None
    assert Sandbox.image_for_python_version("") is None
    assert Sandbox.image_for_python_version("not-a-version") is None


def test_image_lookup_strips_whitespace():
    assert Sandbox.image_for_python_version("  3.11  ") == "python:3.11-slim"


def test_image_lookup_works_without_docker():
    # The classmethod must be safe to call from contexts that have no
    # Docker daemon — it does not touch the docker client.
    # Calling it directly (no `Sandbox()` construction) proves it.
    assert isinstance(Sandbox.image_for_python_version("3.12"), str)
