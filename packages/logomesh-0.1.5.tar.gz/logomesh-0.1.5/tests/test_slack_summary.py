"""Tests for src/server/slack_summary.py."""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from unittest import mock

import httpx
import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from src.server.slack_summary import (  # noqa: E402
    post_slack_summary,
    post_verdict_to_slack,
    render_verdict_blocks,
)


# ---- Block Kit rendering -------------------------------------------------

def test_blocks_verified_includes_pr_button():
    payload = render_verdict_blocks(
        {
            "artifact": {
                "evidence_path_seal": {
                    "verified_exception_match": True,
                    "sandbox_exception_type": "ValueError",
                    "expected_exception_type": "ValueError",
                    "test_sha256_first16": "abcd1234567890ab",
                },
            },
            "pr_url": "https://github.com/x/y/pull/1",
            "duration_s": 38.0,
        },
        sentry_issue_id="9999",
    )
    s = json.dumps(payload)
    assert ":white_check_mark:" in s
    assert "verified" in payload["text"].lower()
    assert "ValueError" in s
    assert "abcd1234567890ab" in s
    assert "pull/1" in s
    assert "9999" in s
    # Compliance footer must always be present (post-incident controls).
    assert "PCI DSS 12.10.5" in s
    assert "CC7.3" in s


def test_blocks_mismatch_no_button():
    payload = render_verdict_blocks({
        "artifact": {
            "evidence_path_seal": {
                "verified_exception_match": False,
                "sandbox_exception_type": "NameError",
                "expected_exception_type": "ValueError",
            },
        },
    })
    s = json.dumps(payload)
    assert ":x:" in s
    assert "NameError" in s
    assert "did NOT verify" in s
    # No PR button when there's no PR.
    assert "Open draft PR" not in s


def test_blocks_human_review():
    payload = render_verdict_blocks({
        "needs_human_review": True,
        "human_review_reason": "source_not_found_retry_exhausted",
    })
    s = json.dumps(payload)
    assert ":warning:" in s
    assert "source_not_found_retry_exhausted" in s


def test_blocks_fallback_text_present():
    """Mobile/notification preview uses `text`, not `blocks`."""
    payload = render_verdict_blocks({"artifact": {}})
    assert "text" in payload
    assert isinstance(payload["text"], str)
    assert len(payload["text"]) > 10


# ---- POST behavior -------------------------------------------------------

def test_post_slack_summary_calls_webhook(monkeypatch):
    monkeypatch.setenv(
        "LOGOMESH_SLACK_WEBHOOK_URL",
        "https://hooks.slack.com/services/T/B/X",
    )
    captured = {}

    async def fake_post(self, url, headers=None, content=None, **kw):
        captured["url"] = url
        captured["content"] = content
        captured["headers"] = headers
        return httpx.Response(200, request=httpx.Request("POST", url), text="ok")

    with mock.patch.object(httpx.AsyncClient, "post", fake_post):
        asyncio.run(post_slack_summary({"text": "hi"}))
        assert captured["url"] == "https://hooks.slack.com/services/T/B/X"
        assert captured["headers"]["Content-Type"] == "application/json"
        assert "hi" in captured["content"]


def test_post_slack_summary_raises_without_url(monkeypatch):
    monkeypatch.delenv("LOGOMESH_SLACK_WEBHOOK_URL", raising=False)
    with pytest.raises(RuntimeError):
        asyncio.run(post_slack_summary({"text": "hi"}))


def test_post_verdict_swallows_errors(monkeypatch):
    """Background task — must NEVER raise."""
    monkeypatch.delenv("LOGOMESH_SLACK_WEBHOOK_URL", raising=False)
    asyncio.run(post_verdict_to_slack({"artifact": {}}))


def test_post_verdict_uses_explicit_webhook_url(monkeypatch):
    """Per-installation override (used by the dashboard later)."""
    monkeypatch.delenv("LOGOMESH_SLACK_WEBHOOK_URL", raising=False)
    captured = {}

    async def fake_post(self, url, headers=None, content=None, **kw):
        captured["url"] = url
        return httpx.Response(200, request=httpx.Request("POST", url), text="ok")

    with mock.patch.object(httpx.AsyncClient, "post", fake_post):
        asyncio.run(post_verdict_to_slack(
            {"artifact": {}},
            webhook_url="https://hooks.slack.com/services/T2/B2/Y",
        ))
        assert captured["url"] == "https://hooks.slack.com/services/T2/B2/Y"
