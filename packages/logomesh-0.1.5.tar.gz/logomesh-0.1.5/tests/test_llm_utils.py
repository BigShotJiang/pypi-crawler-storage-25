"""Lock down llm_utils behavior — in particular get_seed_kwargs determinism.

The seed helper is what turns the A/B variance problem (run 518/519/520 on
the same payflow-api PR gave 1/0/3 findings) into a stable-ish signal. If
the seed ever stops being content-derived or stops being emitted for OpenAI
models, determinism regresses silently.
"""

import os

from llm_utils import get_seed_kwargs


def test_seed_is_deterministic_for_same_content():
    s1 = get_seed_kwargs("hello world", model="gpt-5-mini")
    s2 = get_seed_kwargs("hello world", model="gpt-5-mini")
    assert s1 == s2
    assert "seed" in s1


def test_seed_differs_for_different_content():
    s1 = get_seed_kwargs("prompt A", model="gpt-5-mini")
    s2 = get_seed_kwargs("prompt B", model="gpt-5-mini")
    assert s1["seed"] != s2["seed"]


def test_seed_is_in_int_range():
    """OpenAI expects a 32-bit non-negative int for the seed parameter."""
    s = get_seed_kwargs("x" * 10000, model="gpt-4o-mini")
    seed = s["seed"]
    assert isinstance(seed, int)
    assert 0 <= seed < 2**31


def test_seed_omitted_for_gemini():
    assert get_seed_kwargs("prompt", model="gemini-pro") == {}


def test_seed_omitted_for_claude():
    assert get_seed_kwargs("prompt", model="claude-sonnet-4-6") == {}


def test_seed_omitted_for_empty_content():
    assert get_seed_kwargs("", model="gpt-5-mini") == {}


def test_seed_disabled_by_env(monkeypatch):
    monkeypatch.setenv("LOGOMESH_DISABLE_SEED", "1")
    assert get_seed_kwargs("prompt", model="gpt-5-mini") == {}


def test_seed_enabled_when_env_unset(monkeypatch):
    monkeypatch.delenv("LOGOMESH_DISABLE_SEED", raising=False)
    assert "seed" in get_seed_kwargs("prompt", model="gpt-5-mini")
