from core import supabase_client as sc


def _clear(monkeypatch):
    for k in (
        "SUPABASE_URL",
        "SUPABASE_PROJECT_REF",
        "SUPABASE_SERVICE_KEY",
        "SUPABASE_SERVICE_ROLE_KEY",
    ):
        monkeypatch.delenv(k, raising=False)


def test_supabase_url_prefers_explicit_url(monkeypatch):
    _clear(monkeypatch)
    monkeypatch.setenv("SUPABASE_PROJECT_REF", "esrzdbksqcabfforbwpe")
    monkeypatch.setenv("SUPABASE_URL", " https://custom.supabase.co ")
    assert sc._supabase_url() == "https://custom.supabase.co"


def test_supabase_url_falls_back_to_project_ref(monkeypatch):
    _clear(monkeypatch)
    monkeypatch.setenv("SUPABASE_PROJECT_REF", "esrzdbksqcabfforbwpe")
    assert sc._supabase_url() == "https://esrzdbksqcabfforbwpe.supabase.co"


def test_service_key_supports_both_env_names(monkeypatch):
    _clear(monkeypatch)
    monkeypatch.setenv("SUPABASE_SERVICE_ROLE_KEY", "role-key")
    assert sc._service_key() == "role-key"

    monkeypatch.setenv("SUPABASE_SERVICE_KEY", "service-key")
    assert sc._service_key() == "service-key"


def test_both_unset_returns_empty(monkeypatch):
    _clear(monkeypatch)
    assert sc._supabase_url() == ""
    assert sc._service_key() == ""
