from __future__ import annotations

import sys
import asyncio
from pathlib import Path

import pytest
from langchain_core.messages import AIMessage

ROOT = Path(__file__).resolve().parents[1]
if str(ROOT) not in sys.path:
    sys.path.insert(0, str(ROOT))

import logomesh_orchestrator as o


def test_max_supervisor_steps_default_and_override(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("LOGOMESH_MAX_SUPERVISOR_STEPS", "11")
    assert o._max_supervisor_steps({"max_tool_calls": 0}) == 11
    assert o._max_supervisor_steps({"max_tool_calls": 4}) == 4


def test_supervisor_router_forces_finalizer_on_step_cap(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("LOGOMESH_MAX_SUPERVISOR_STEPS", "10")
    state: o.OrchestratorState = {
        "step_count": 10,
        "audit_session_id": "sid-no-repro",
        "messages": [AIMessage(content="loop")],
    }
    assert o.supervisor_router(state) == "finalizer"


def test_supervisor_router_forces_critic_with_repro(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setenv("LOGOMESH_MAX_SUPERVISOR_STEPS", "10")
    sid = "sid-with-repro"
    o._REPRO_REGISTRY[sid] = object()  # type: ignore[assignment]
    try:
        state: o.OrchestratorState = {
            "step_count": 10,
            "audit_session_id": sid,
            "messages": [AIMessage(content="loop")],
            "critic_report": None,
        }
        assert o.supervisor_router(state) == "critic_gate"
    finally:
        o._REPRO_REGISTRY.pop(sid, None)


def test_finalizer_keeps_forced_human_review_reason(monkeypatch: pytest.MonkeyPatch) -> None:
    async def _fake_human_review_evidence(sid: str, reason: str) -> dict[str, object]:
        return {"sid": sid, "reason": reason}

    monkeypatch.setattr(o, "_build_human_review_evidence", _fake_human_review_evidence)

    sid = "sid-finalizer-step-cap"
    out = asyncio.run(
        o.finalizer_node(
            {
                "audit_session_id": sid,
                "repo_path": ".",
                "needs_human_review": True,
                "human_review_reason": "orchestrator_max_steps_exceeded",
            }
        )
    )

    assert out["needs_human_review"] is True
    assert out["human_review_reason"] == "orchestrator_max_steps_exceeded"
