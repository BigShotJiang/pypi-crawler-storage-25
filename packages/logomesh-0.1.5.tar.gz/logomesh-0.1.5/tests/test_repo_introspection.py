"""Tests for the generic repo introspection scanner.

All assertions verify that NO framework name is hardcoded into the
scanner — it just reports evidence. The agent decides what to do.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

import pytest

from business_logic.repo_introspection import scan_repo


def _write(root: Path, rel: str, content: str) -> None:
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(textwrap.dedent(content).lstrip())


def test_scan_empty_repo(tmp_path):
    intro = scan_repo(tmp_path)
    assert intro.files_scanned == 0
    assert intro.manifests == []
    assert intro.evidence == []


def test_scan_picks_up_pyproject_deps(tmp_path):
    _write(tmp_path, "pyproject.toml", """
        [project]
        name = "demo"
        requires-python = ">=3.11"
        dependencies = ["django>=5.0", "celery>=5.4", "stripe"]
    """)
    intro = scan_repo(tmp_path)
    assert len(intro.manifests) == 1
    deps = intro.manifests[0].dependencies
    assert any(d.startswith("django") for d in deps)
    assert any(d.startswith("celery") for d in deps)
    # No hardcoded routing — just evidence
    manifest_ev = intro.evidence_for("manifest_dep")
    assert len(manifest_ev) >= 3


def test_scan_finds_class_with_bases_and_fields(tmp_path):
    _write(tmp_path, "payments/models.py", """
        from django.db import models

        class Order(models.Model):
            id = models.UUIDField(primary_key=True)
            amount_cents = models.IntegerField()
            currency = models.CharField(max_length=3, default="USD")
            customer_email = models.EmailField(null=True, blank=True)
    """)
    intro = scan_repo(tmp_path)
    orders = [c for c in intro.classes if c.name == "Order"]
    assert orders
    o = orders[0]
    assert any("models.Model" in b for b in o.bases)
    field_names = {f["name"] for f in o.fields}
    assert {"id", "amount_cents", "currency", "customer_email"}.issubset(field_names)


def test_scan_finds_decorated_callables(tmp_path):
    _write(tmp_path, "payments/tasks.py", """
        from celery import shared_task

        @shared_task(bind=True)
        def process_payment(self, *, order_id: str):
            return order_id

        async def helper():
            pass
    """)
    intro = scan_repo(tmp_path)
    names = {c.name: c for c in intro.callables}
    assert "process_payment" in names
    assert "helper" in names
    assert any("shared_task" in d for d in names["process_payment"].decorators)
    assert names["helper"].is_async is True


def test_scan_records_imports_by_module(tmp_path):
    _write(tmp_path, "a.py", """
        import django.db
        from celery import shared_task
        from .models import Order
    """)
    intro = scan_repo(tmp_path)
    # imports_seen records the actual module string we saw
    assert any(m.startswith("django") for m in intro.imports_seen)
    # imports_matching does regex matching, agent uses this for RAG
    assert intro.imports_matching(r"^django")
    assert intro.imports_matching(r"^celery")


def test_scan_finds_config_and_entrypoint_modules(tmp_path):
    _write(tmp_path, "project/settings.py", "DATABASES = {}\n")
    _write(tmp_path, "manage.py", "import sys\n")
    _write(tmp_path, "asgi.py", "import sys\n")

    intro = scan_repo(tmp_path)
    assert any("settings.py" in c for c in intro.config_files)
    entry_names = {Path(e).name for e in intro.entrypoint_modules}
    assert "manage.py" in entry_names
    assert "asgi.py" in entry_names


def test_scan_skips_venv_and_node_modules(tmp_path):
    _write(tmp_path, ".venv/site-packages/x.py", "x = 1\n")
    _write(tmp_path, "node_modules/y/y.py", "y = 1\n")
    _write(tmp_path, "src/real.py", "import sys\n")

    intro = scan_repo(tmp_path)
    files = {ev.source for ev in intro.evidence_for("import")}
    assert all(".venv" not in f and "node_modules" not in f for f in files)


def test_classes_with_base_pattern(tmp_path):
    _write(tmp_path, "m.py", """
        from sqlalchemy.orm import declarative_base
        Base = declarative_base()

        class User(Base):
            __tablename__ = "users"
    """)
    intro = scan_repo(tmp_path)
    matches = intro.classes_with_base(r"^Base$")
    assert any(c.name == "User" for c in matches)


def test_callables_with_decorator_pattern(tmp_path):
    _write(tmp_path, "t.py", """
        from celery import shared_task

        @shared_task
        def foo(): pass

        def bar(): pass
    """)
    intro = scan_repo(tmp_path)
    decorated = intro.callables_with_decorator(r"shared_task")
    decorated_names = {c.name for c in decorated}
    assert "foo" in decorated_names
    assert "bar" not in decorated_names


def test_missing_repo_raises(tmp_path):
    with pytest.raises(FileNotFoundError):
        scan_repo(tmp_path / "does_not_exist")
