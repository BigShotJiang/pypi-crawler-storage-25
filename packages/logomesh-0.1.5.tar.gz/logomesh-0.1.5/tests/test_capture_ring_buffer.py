"""Ring-buffer correctness: contextvar isolation across asyncio tasks +
max-events bounding."""

from __future__ import annotations

import asyncio

from capture import ring_buffer


def test_record_and_drain_roundtrip():
    ring_buffer.drain()  # clean slate for this context
    ring_buffer.record({"type": "db", "sql": "SELECT 1"})
    ring_buffer.record({"type": "http", "url": "https://api.stripe.com"})

    out = ring_buffer.drain()
    assert [e["type"] for e in out] == ["db", "http"]
    # Drain clears.
    assert ring_buffer.drain() == []


def test_max_events_caps_buffer():
    ring_buffer.set_max_events(3)
    # Fresh contextvar so the new cap takes effect.
    ring_buffer._buffer.set(None)  # type: ignore[attr-defined]
    for i in range(10):
        ring_buffer.record({"type": "db", "i": i})
    out = ring_buffer.drain()
    assert len(out) == 3
    assert [e["i"] for e in out] == [7, 8, 9]
    # Restore default for the rest of the suite.
    ring_buffer.set_max_events(50)
    ring_buffer._buffer.set(None)  # type: ignore[attr-defined]


def test_async_tasks_have_isolated_buffers():
    """Two concurrent asyncio tasks must NOT see each other's ring buffer.
    This is the property threading.local would silently break."""
    ring_buffer.drain()

    async def worker(label: str, n: int) -> list[dict]:
        for i in range(n):
            ring_buffer.record({"label": label, "i": i})
        # Yield so the other task interleaves.
        await asyncio.sleep(0)
        return ring_buffer.drain()

    async def main() -> tuple[list[dict], list[dict]]:
        a, b = await asyncio.gather(worker("a", 3), worker("b", 5))
        return a, b

    a_drain, b_drain = asyncio.run(main())
    assert {e["label"] for e in a_drain} == {"a"}
    assert {e["label"] for e in b_drain} == {"b"}
    assert len(a_drain) == 3
    assert len(b_drain) == 5
