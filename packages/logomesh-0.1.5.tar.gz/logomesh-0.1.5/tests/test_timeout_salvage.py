"""Regression guard for the timeout-salvage pattern in test_real_prs.py.

The real-PR harness passes a mutable `progress` dict into the pipeline and
reads salvaged findings from it when asyncio.wait_for fires. This test
locks in the core invariant: writes to the shared dict BEFORE an await
that gets cancelled remain visible to the caller after TimeoutError.

Without this behavior, any validated finding produced late in a slow
pipeline would be silently discarded with the cancelled task (the bug
that hid a real finding on twilio-python PR #896 token_pagination.py).
"""

import asyncio

import pytest


def test_progress_dict_survives_asyncio_cancellation():
    progress: dict = {}

    async def slow_pipeline():
        progress["confirmed_findings"] = ["early_finding"]
        progress["tests_consumed"] = 3
        await asyncio.sleep(0)
        progress["confirmed_findings"] = ["early_finding", "mid_finding"]
        await asyncio.sleep(5.0)  # cancelled here
        progress["confirmed_findings"] = ["should_not_be_reached"]

    async def runner():
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(slow_pipeline(), timeout=0.05)

    asyncio.run(runner())

    assert progress.get("confirmed_findings") == ["early_finding", "mid_finding"]
    assert progress.get("tests_consumed") == 3


def test_progress_dict_empty_when_cancelled_before_first_write():
    """If the pipeline is cancelled before the first checkpoint, the caller
    must see an empty findings list — NOT a stale list from a prior run."""
    progress: dict = {}

    async def slow_pipeline():
        await asyncio.sleep(5.0)  # cancelled before any write
        progress["confirmed_findings"] = ["should_not_be_reached"]

    async def runner():
        with pytest.raises(asyncio.TimeoutError):
            await asyncio.wait_for(slow_pipeline(), timeout=0.05)

    asyncio.run(runner())

    assert progress.get("confirmed_findings") is None
