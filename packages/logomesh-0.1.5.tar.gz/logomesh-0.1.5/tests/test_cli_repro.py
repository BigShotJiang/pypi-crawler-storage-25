"""Tests for src/cli/repro.py — `logomesh repro <sentry-url>`."""

import argparse
from pathlib import Path

import pytest

from cli.repro import parse_sentry_url, run_repro


def _ns(url: str, **overrides) -> argparse.Namespace:
    base = dict(
        sentry_url=url,
        repo=Path("."),
        output_json=False,
        timeout=60,
    )
    base.update(overrides)
    return argparse.Namespace(**base)


class TestParseSentryUrl:
    def test_organizations_form(self):
        assert parse_sentry_url(
            "https://sentry.io/organizations/foo/issues/123/"
        ) == ("foo", "123")

    def test_short_form(self):
        assert parse_sentry_url("https://sentry.io/issues/456/") == (None, "456")

    def test_subdomain_form(self):
        assert parse_sentry_url("https://acme.sentry.io/issues/789/") == ("acme", "789")

    def test_subdomain_with_org_path_prefers_path(self):
        url = "https://acme.sentry.io/organizations/other/issues/1/"
        org, issue = parse_sentry_url(url)
        assert issue == "1"
        assert org == "other"

    def test_trailing_slash_optional(self):
        assert parse_sentry_url("https://sentry.io/issues/123") == (None, "123")

    def test_invalid_host_raises(self):
        with pytest.raises(ValueError):
            parse_sentry_url("https://github.com/x/y/issues/1/")

    def test_non_url_raises(self):
        with pytest.raises(ValueError):
            parse_sentry_url("not-a-url")

    def test_no_issue_id_raises(self):
        with pytest.raises(ValueError):
            parse_sentry_url("https://sentry.io/organizations/foo/")


class TestRunRepro:
    def test_missing_token_returns_2(self, monkeypatch, capsys):
        monkeypatch.delenv("SENTRY_AUTH_TOKEN", raising=False)
        rc = run_repro(_ns("https://sentry.io/issues/123/"))
        assert rc == 2
        err = capsys.readouterr().err
        assert "SENTRY_AUTH_TOKEN" in err

    def test_blank_token_returns_2(self, monkeypatch):
        monkeypatch.setenv("SENTRY_AUTH_TOKEN", "   ")
        rc = run_repro(_ns("https://sentry.io/issues/123/"))
        assert rc == 2

    def test_bad_url_returns_2(self, monkeypatch, capsys):
        monkeypatch.setenv("SENTRY_AUTH_TOKEN", "tok")
        rc = run_repro(_ns("https://github.com/x/y"))
        assert rc == 2
        err = capsys.readouterr().err
        assert "unrecognized" in err.lower()

    def test_bad_url_json_emits_error_payload(self, monkeypatch, capsys):
        monkeypatch.setenv("SENTRY_AUTH_TOKEN", "tok")
        rc = run_repro(_ns("https://example.com/", output_json=True))
        assert rc == 2
        out = capsys.readouterr().out
        assert '"status": "error"' in out
