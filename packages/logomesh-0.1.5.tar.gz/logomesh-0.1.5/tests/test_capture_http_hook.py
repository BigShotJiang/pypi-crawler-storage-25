"""HTTP hook: Stripe-shaped capture with header redaction."""

from __future__ import annotations

import json

import httpx
import pytest

from capture import ring_buffer
from capture.hooks import http_hook


@pytest.fixture(autouse=True)
def _clean_buffer():
    ring_buffer.drain()
    yield
    ring_buffer.drain()


def _stripe_handler(request: httpx.Request) -> httpx.Response:
    return httpx.Response(
        200,
        headers={
            "Stripe-Version": "2024-06-20",
            "Request-Id": "req_abc",
            "content-type": "application/json",
        },
        content=json.dumps({
            "id": "ch_test_123",
            "amount": 4995,
            "currency": "usd",
            "status": "succeeded",
        }).encode("utf-8"),
    )


def test_httpx_capture_records_stripe_request_with_redaction():
    http_hook.install(redact_fields=[
        "authorization", "card_number", "cvv",
    ])

    transport = httpx.MockTransport(_stripe_handler)
    with httpx.Client(transport=transport) as client:
        client.post(
            "https://api.stripe.com/v1/charges",
            headers={
                "Authorization": "Bearer sk_live_supersecret",
                "Idempotency-Key": "idem_42",
                "Stripe-Version": "2024-06-20",
                "Stripe-Account": "acct_123",
            },
            content=json.dumps({
                "amount": 4995,
                "currency": "usd",
                "card_number": "4242424242424242",
                "cvv": "123",
            }),
        )

    entries = ring_buffer.drain()
    http_entries = [e for e in entries if e.get("type") == "http"]
    assert len(http_entries) == 1
    e = http_entries[0]

    assert e["method"] == "POST"
    assert e["url"].endswith("/v1/charges")
    assert e["status_code"] == 200

    # Stripe debugging needs these visible.
    assert e["request_headers"].get("idempotency-key") == "idem_42"
    assert e["request_headers"].get("stripe-version") == "2024-06-20"
    assert e["request_headers"].get("stripe-account") == "acct_123"

    # Authorization redacted in request headers.
    assert e["request_headers"].get("authorization") == "[REDACTED]"

    # Response headers preserved (Stripe-Version case-folded by httpx).
    resp_headers_lower = {k.lower(): v for k, v in e["response_headers"].items()}
    assert resp_headers_lower.get("stripe-version") == "2024-06-20"

    # Body redaction strips card data but keeps amount.
    body = json.loads(e["request_body"])
    assert body["amount"] == 4995
    assert body["card_number"] == "[REDACTED]"
    assert body["cvv"] == "[REDACTED]"

    # Response body intact.
    resp = json.loads(e["response_body"])
    assert resp["id"] == "ch_test_123"

    # Stripe + idempotency identity surfaced as top-level fields so the
    # repro pipeline doesn't have to re-parse headers downstream.
    assert e["is_stripe"] is True
    assert e["idempotency_key"] == "idem_42"
    assert e["stripe_account"] == "acct_123"
    assert e["stripe_version"] == "2024-06-20"


def test_httpx_capture_marks_non_stripe_calls():
    from capture import ring_buffer
    from capture.hooks import http_hook
    ring_buffer.drain()
    http_hook.install()

    def handler(request):
        return httpx.Response(200, content=b"{}")

    transport = httpx.MockTransport(handler)
    with httpx.Client(transport=transport) as client:
        client.get("https://api.example.com/health")

    entries = [e for e in ring_buffer.drain() if e.get("type") == "http"]
    assert entries[-1]["is_stripe"] is False
    assert entries[-1]["idempotency_key"] is None
