from cli.artifact import render_artifact


class _Exc:
    issue_id = "999"
    issue_url = "https://sentry.io/issues/999/"
    error_type = "ValueError"
    error_message = "bad input"
    last_seen = "2026-04-30T00:00:00Z"
    event_count = 3


class _Frame:
    filename = "examples/fintech_billing/checkout.py"
    function = "apply_discount"
    lineno = 22


def test_render_artifact_uses_subprocess_description():
    artifact = render_artifact(
        _Exc(),
        _Frame(),
        {"total": 1, "failed": 1},
        branch="main",
        commit="abc123",
        sandbox_mode="subprocess",
    )

    assert artifact["reproduction"]["sandbox"] == "Local subprocess fallback, not isolated"
    assert "Local subprocess fallback, not isolated" in artifact["evidence_chain"][2]


def test_render_artifact_defaults_to_docker_description():
    artifact = render_artifact(
        _Exc(),
        _Frame(),
        {"total": 1, "failed": 0},
        branch="main",
        commit="abc123",
    )

    assert artifact["reproduction"]["sandbox"] == "Docker python:3.12-slim, airgapped, nobody user"
    assert "Docker python:3.12-slim, airgapped, nobody user" in artifact["evidence_chain"][2]
