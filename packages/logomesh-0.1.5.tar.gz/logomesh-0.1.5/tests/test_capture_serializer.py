"""JSON-safe coercion + PII/secret redaction."""

from __future__ import annotations

import datetime
import decimal
import json
import uuid

from capture.serializer import (
    DEFAULT_REDACT_FIELDS,
    _safe_serialize,
    merge_redact_fields,
    redact,
    redact_row,
)


def test_safe_serialize_handles_finance_types():
    val = {
        "amount": decimal.Decimal("19.99"),
        "id": uuid.UUID("12345678-1234-5678-1234-567812345678"),
        "ts": datetime.datetime(2026, 4, 29, 12, 0, 0),
        "delta": datetime.timedelta(seconds=30),
        "raw": b"\x00\x01ok",
    }
    out = _safe_serialize(val)
    # JSON-roundtrippable.
    json.dumps(out)
    assert out["amount"] == "19.99"
    assert out["id"] == "12345678-1234-5678-1234-567812345678"
    assert out["ts"].startswith("2026-04-29T12:00:00")
    assert out["delta"] == 30.0
    assert "ok" in out["raw"]


def test_redact_is_case_insensitive_and_recursive():
    body = {
        "Authorization": "Bearer sk_live_abc",
        "user": {"email": "x@y.com", "name": "ok"},
        "meta": [{"Token": "t1"}, {"safe": "yes"}],
    }
    out = redact(body, ["authorization", "email", "token"])
    assert out["Authorization"] == "[REDACTED]"
    assert out["user"]["email"] == "[REDACTED]"
    assert out["user"]["name"] == "ok"
    assert out["meta"][0]["Token"] == "[REDACTED]"
    assert out["meta"][1]["safe"] == "yes"


def test_redact_row_aligned_to_columns():
    cols = ["id", "email", "amount"]
    row = [1, "x@y.com", decimal.Decimal("9.99")]
    out = redact_row(cols, row, ["email"])
    assert out[0] == 1
    assert out[1] == "[REDACTED]"
    assert out[2] == decimal.Decimal("9.99")


def test_merge_redact_fields_includes_defaults_and_user_extras():
    merged = merge_redact_fields(["custom_field", "Authorization"])
    # Defaults present.
    for f in ("password", "authorization", "card_number", "cvv"):
        assert f in merged
    # User extras merged, lowercased, no duplicates.
    assert "custom_field" in merged
    # No duplicate of authorization.
    assert merged.count("authorization") == 1


def test_default_redact_list_covers_billing_critical_fields():
    """Tripwire: if anyone removes a known-sensitive field from the default
    list we want a loud test failure."""
    must_include = {
        "authorization", "cookie", "password", "token", "api_key",
        "card_number", "cvv", "ssn", "client_secret",
    }
    assert must_include.issubset(set(DEFAULT_REDACT_FIELDS))
