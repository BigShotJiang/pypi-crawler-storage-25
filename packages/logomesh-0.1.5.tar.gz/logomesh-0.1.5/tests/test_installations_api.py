"""Integration tests for the wizard-facing /api/installations.

Supabase + the orchestrator are mocked so these run offline. The
fastapi.testclient hits the actual FastAPI app, exercising routing,
auth, and JSON shape.
"""
import base64
import os
from typing import Any

import pytest
from fastapi.testclient import TestClient


@pytest.fixture
def app(monkeypatch):
    monkeypatch.setenv(
        "LOGOMESH_MASTER_KEY",
        base64.urlsafe_b64encode(os.urandom(32)).decode(),
    )
    monkeypatch.setenv("SUPABASE_URL", "https://stub.supabase.co")
    monkeypatch.setenv("SUPABASE_SERVICE_KEY", "stub-key")
    monkeypatch.setenv("LOGOMESH_PUBLIC_HOST", "https://api.logomesh.dev")
    # PUT /sentry-token, /github, /slack run live token checks by default
    # (Item 1). Tests are offline → opt out; individual tests that
    # exercise the validators delenv these and inject a fake validator.
    monkeypatch.setenv("LOGOMESH_SKIP_SENTRY_TOKEN_VALIDATION", "1")
    monkeypatch.setenv("LOGOMESH_SKIP_GITHUB_TOKEN_VALIDATION", "1")
    monkeypatch.setenv("LOGOMESH_SKIP_SLACK_VALIDATION", "1")

    state: dict[str, dict[str, Any]] = {
        "installations": {}, "installation_secrets": {}, "runs": {},
    }

    class _Result:
        def __init__(self, data, count=None):
            self.data = data
            self.count = count

    class _Q:
        def __init__(self, table, store):
            self.table = table
            self.store = store
            self._eq: list[tuple[str, Any]] = []
            self._mode = None
            self._payload = None
            self._desc = False
            self._limit_val = None

        def select(self, *_a, **_kw):
            self._mode = "select"
            return self

        def upsert(self, p):
            self._mode = "upsert"
            self._payload = p
            return self

        def insert(self, p):
            self._mode = "insert"
            self._payload = p
            return self

        def update(self, p):
            self._mode = "update"
            self._payload = p
            return self

        def delete(self):
            self._mode = "delete"
            return self

        def eq(self, k, v):
            self._eq.append((k, v))
            return self

        def gte(self, *_a, **_kw):
            return self

        def order(self, _col, desc=False):
            self._desc = desc
            return self

        def limit(self, n):
            self._limit_val = n
            return self

        def _filter(self, rows):
            for k, v in self._eq:
                rows = [r for r in rows if r.get(k) == v]
            return rows

        def execute(self):
            tbl = self.store.setdefault(self.table, {})
            if self._mode == "upsert":
                p = self._payload
                pk = p.get("installation_id") or p.get("run_id")
                tbl[pk] = {**tbl.get(pk, {}), **p}
                return _Result([tbl[pk]])
            if self._mode == "insert":
                p = self._payload
                pk = p.get("run_id") or p.get("installation_id")
                tbl[pk] = p
                return _Result([p])
            if self._mode == "update":
                rows = self._filter(list(tbl.values()))
                for r in rows:
                    r.update(self._payload)
                return _Result(rows)
            if self._mode == "delete":
                rows = self._filter(list(tbl.values()))
                for r in rows:
                    pk = r.get("installation_id") or r.get("run_id")
                    tbl.pop(pk, None)
                return _Result(rows)
            if self._mode == "select":
                rows = self._filter(list(tbl.values()))
                rows.sort(key=lambda r: r.get("created_at", ""),
                          reverse=self._desc)
                if self._limit_val is not None:
                    rows = rows[: self._limit_val]
                return _Result(rows, count=len(rows))
            raise RuntimeError(f"unhandled mode {self._mode}")

    class _Stub:
        def __init__(self, store):
            self._store = store

        def table(self, name):
            return _Q(name, self._store)

    monkeypatch.setattr("core.supabase_client._get_client",
                        lambda: _Stub(state))

    from server.app import app as fastapi_app
    return TestClient(fastapi_app)


# ---------------------------------------------------------------------------
# POST /api/installations
# ---------------------------------------------------------------------------

def test_create_returns_id_secret_and_webhook_url(app):
    r = app.post("/api/installations", json={})
    assert r.status_code == 201, r.text
    body = r.json()
    assert body["id"]
    assert body["client_secret"].startswith("lms_secret_")
    assert body["webhook_url"].startswith("https://api.logomesh.dev/webhooks/sentry/")
    assert body["webhook_url"].endswith(body["id"])
    assert "created_at" in body


def test_create_with_owner(app):
    r = app.post("/api/installations", json={"owner": "acme-corp"})
    assert r.status_code == 201


# ---------------------------------------------------------------------------
# Bearer auth on subsequent calls
# ---------------------------------------------------------------------------

def test_get_requires_bearer(app):
    create = app.post("/api/installations", json={}).json()
    r = app.get(f"/api/installations/{create['id']}")
    assert r.status_code == 401

    r = app.get(
        f"/api/installations/{create['id']}",
        headers={"Authorization": f"Bearer {create['client_secret']}"},
    )
    assert r.status_code == 200


def test_get_returns_summary_shape(app):
    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.get(f"/api/installations/{c['id']}", headers=h)
    assert r.status_code == 200
    body = r.json()
    assert body["id"] == c["id"]
    assert body["sentry"] == {"configured": False, "last_event_at": None}
    assert body["github"] == {"configured": False, "repo": None}
    assert body["slack"] == {"configured": False}
    assert body["runs_count"] == 0


def test_wrong_bearer_401(app):
    c = app.post("/api/installations", json={}).json()
    r = app.get(
        f"/api/installations/{c['id']}",
        headers={"Authorization": "Bearer wrong"},
    )
    assert r.status_code == 401


def test_unknown_install_404(app):
    r = app.get(
        "/api/installations/00000000-0000-0000-0000-000000000000",
        headers={"Authorization": "Bearer anything"},
    )
    assert r.status_code == 404


# ---------------------------------------------------------------------------
# PUT secrets
# ---------------------------------------------------------------------------

def test_set_sentry_token(app):
    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/sentry-token",
                headers=h, json={"token": "sntrys_FullSentryAuthToken"})
    assert r.status_code == 200
    assert r.json() == {"configured": True}

    s = app.get(f"/api/installations/{c['id']}", headers=h).json()
    assert s["sentry"]["configured"] is True


def test_set_github(app):
    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/github",
                headers=h, json={"token": "ghp_LongPATValue", "repo": "acme/billing"})
    assert r.status_code == 200
    body = r.json()
    assert body == {"configured": True, "repo": "acme/billing"}

    s = app.get(f"/api/installations/{c['id']}", headers=h).json()
    assert s["github"] == {"configured": True, "repo": "acme/billing"}


def test_set_github_validates_repo_format(app):
    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/github",
                headers=h, json={"token": "ghp_x", "repo": "nope"})
    assert r.status_code == 422


def test_set_slack_validates_url(app):
    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/slack",
                headers=h, json={"webhook_url": "not-a-slack-url"})
    assert r.status_code == 400

    r2 = app.put(f"/api/installations/{c['id']}/slack",
                 headers=h, json={"webhook_url": "https://hooks.slack.com/services/T/B/X"})
    assert r2.status_code == 200
    assert r2.json() == {"configured": True}


# ---------------------------------------------------------------------------
# /test  /runs  /artifact
# ---------------------------------------------------------------------------

def test_test_endpoint_returns_run_id(app, monkeypatch):
    """`POST /test` enqueues a real orchestrator run. We patch the
    orchestrator entry point so the test runs offline."""
    async def _fake_handle(event):
        return {
            "status": "shipped",
            "artifact": {
                "evidence_path_seal": {
                    "verified_exception_match": True,
                    "sandbox_exception_type": "AssertionError",
                    "expected_exception_type": "AssertionError",
                    "test_sha256_first16": "abcd1234",
                    "llm_in_evidence_path": False,
                    "synthesizer": "frame-locals → pytest (deterministic)",
                },
            },
            "pr_url": "",
            "needs_human_review": False,
            "human_review_reason": "",
            "duration_s": 12.3,
            "usage": {"tokens_in": 1000, "tokens_out": 200,
                      "cost_usd": 0.012, "model": "gpt-5-mini"},
            "installation_id": "irrelevant",
        }

    # Provide a fake fixture so _resolve_test_fixture doesn't 503.
    fix_path = "/tmp/lm_wizard_fixture.json"
    open(fix_path, "w").write("{}")
    monkeypatch.setenv("LOGOMESH_WIZARD_TEST_FIXTURE", fix_path)
    # logomesh_orchestrator lives at repo root, not under src/.
    import sys
    from pathlib import Path
    repo_root = Path(__file__).resolve().parent.parent
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    import logomesh_orchestrator as o  # type: ignore
    monkeypatch.setattr(o, "handle_sentry_webhook", _fake_handle)

    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}

    r = app.post(f"/api/installations/{c['id']}/test", headers=h, json={})
    assert r.status_code == 202, r.text
    body = r.json()
    assert "run_id" in body and len(body["run_id"]) >= 8

    # The background task should have completed by now (fastapi.testclient
    # runs tasks synchronously after the response in TestClient).
    runs_r = app.get(f"/api/installations/{c['id']}/runs", headers=h)
    assert runs_r.status_code == 200
    runs = runs_r.json()["runs"]
    assert len(runs) >= 1
    assert runs[0]["sentry_issue_id"] == "logomesh-wizard-test"


def test_runs_unauth(app):
    c = app.post("/api/installations", json={}).json()
    r = app.get(f"/api/installations/{c['id']}/runs")
    assert r.status_code == 401


# ---------------------------------------------------------------------------
# Live-validation paths (Item 1) — validators are stubbed via monkeypatch
# ---------------------------------------------------------------------------

def test_sentry_token_validation_rejects_401(app, monkeypatch):
    """When LOGOMESH_SKIP_SENTRY_TOKEN_VALIDATION is unset, PUT
    /sentry-token must hit the Sentry API and surface 400 with a
    helpful reason on a bad token."""
    monkeypatch.delenv("LOGOMESH_SKIP_SENTRY_TOKEN_VALIDATION", raising=False)

    async def fake_validate(_token):
        return False, "401 unauthorized — token is invalid or revoked"

    from server import installations_api
    monkeypatch.setattr(installations_api, "_validate_sentry_token", fake_validate)

    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/sentry-token",
                headers=h, json={"token": "sntrys_revoked"})
    assert r.status_code == 400
    assert "401 unauthorized" in r.json()["detail"]


def test_github_token_validation_rejects_no_push(app, monkeypatch):
    monkeypatch.delenv("LOGOMESH_SKIP_GITHUB_TOKEN_VALIDATION", raising=False)

    async def fake_validate(_token, _repo):
        return False, "PAT can read but cannot push — draft PRs need push permission"

    from server import installations_api
    monkeypatch.setattr(installations_api, "_validate_github_token", fake_validate)

    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/github",
                headers=h, json={"token": "ghp_readonly", "repo": "acme/billing"})
    assert r.status_code == 400
    assert "cannot push" in r.json()["detail"]


def test_slack_validation_rejects_404(app, monkeypatch):
    monkeypatch.delenv("LOGOMESH_SKIP_SLACK_VALIDATION", raising=False)

    async def fake_validate(_url):
        return False, "404 — webhook URL is invalid or revoked"

    from server import installations_api
    monkeypatch.setattr(installations_api, "_validate_slack_webhook", fake_validate)

    c = app.post("/api/installations", json={}).json()
    h = {"Authorization": f"Bearer {c['client_secret']}"}
    r = app.put(f"/api/installations/{c['id']}/slack",
                headers=h, json={"webhook_url": "https://hooks.slack.com/services/dead"})
    assert r.status_code == 400
    assert "404" in r.json()["detail"]
