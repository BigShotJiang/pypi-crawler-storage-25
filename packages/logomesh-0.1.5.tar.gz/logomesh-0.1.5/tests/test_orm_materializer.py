"""Tests for the generic ORM/dataclass/Pydantic materializer.

The materializer makes ZERO assumptions about which framework owns
the class. It reads the AST, classifies each field as required vs
optional based on default presence + nullable kwargs, and emits a
constructor call seeded from frame locals.
"""

from __future__ import annotations

import textwrap

from business_logic.orm_materializer import (
    analyze_class_source,
    synthesize_constructor_call,
)


def _src(code: str) -> str:
    return textwrap.dedent(code).lstrip()


# --- Pydantic-style ---------------------------------------------------------

def test_analyze_pydantic_required_vs_optional():
    src = _src("""
        from pydantic import BaseModel

        class Order(BaseModel):
            id: str
            amount_cents: int
            currency: str = "USD"
            note: str | None = None
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    names = {f.name: f for f in shape.fields}
    assert names["id"].is_required is True
    assert names["amount_cents"].is_required is True
    assert names["currency"].is_required is False  # has default
    assert names["note"].is_required is False      # has default + None type


# --- Django-style ----------------------------------------------------------

def test_analyze_django_style_marks_nullable_optional():
    src = _src("""
        from django.db import models

        class Order(models.Model):
            id = models.UUIDField(primary_key=True)
            amount_cents = models.IntegerField()
            currency = models.CharField(max_length=3, default="USD")
            note = models.TextField(null=True, blank=True)
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    names = {f.name: f for f in shape.fields}
    assert names["id"].is_pk is True
    assert names["amount_cents"].is_required is True
    assert names["currency"].is_required is False  # has default kwarg
    assert names["note"].is_required is False      # null=True


def test_analyze_picks_first_class_if_no_name():
    src = _src("""
        class A: x: int
        class B: y: int
    """)
    shape = analyze_class_source(src)
    assert shape is not None
    assert shape.name == "A"


# --- Constructor synthesis -------------------------------------------------

def test_synthesize_uses_frame_locals_first():
    src = _src("""
        class Order:
            id: str
            amount_cents: int
            currency: str = "USD"
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, notes, unresolved = synthesize_constructor_call(
        shape=shape,
        raw_locals={"id": "ORD-9182", "amount_cents": 14999, "currency": "EUR", "unrelated": "x"},
    )
    assert "Order(" in call
    assert "id='ORD-9182'" in call
    assert "amount_cents=14999" in call
    assert "currency='EUR'" in call
    assert unresolved == []
    assert any("frame local" in n for n in notes)


def test_synthesize_returns_unresolved_for_missing_required_by_default():
    src = _src("""
        class Order:
            id: str
            amount_cents: int
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, _, unresolved = synthesize_constructor_call(shape=shape, raw_locals={})
    # Agent-led: missing fields are surfaced, not silently placeholdered
    assert set(unresolved) == {"id", "amount_cents"}
    assert "id=" not in call
    assert "amount_cents=" not in call


def test_synthesize_placeholder_opt_in_still_works():
    src = _src("""
        class Order:
            id: str
            amount_cents: int
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, notes, unresolved = synthesize_constructor_call(
        shape=shape, raw_locals={}, placeholder_for_missing=True,
    )
    # Legacy path — agent opts into placeholders explicitly
    assert "id=\"\"" in call or 'id=""' in call
    assert "amount_cents=0" in call
    assert unresolved == []
    assert any("placeholder" in n for n in notes)


def test_synthesize_skips_primary_key_field():
    src = _src("""
        class Order:
            id = Column(Integer, primary_key=True)
            amount_cents = Column(Integer)
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, _, _ = synthesize_constructor_call(shape=shape, raw_locals={"amount_cents": 100})
    assert "id=" not in call
    assert "amount_cents=100" in call


def test_synthesize_quotes_strings_safely():
    src = _src("""
        class Order:
            note: str
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, _, _ = synthesize_constructor_call(shape=shape, raw_locals={"note": "needs quoting"})
    assert "note='needs quoting'" in call or 'note="needs quoting"' in call


def test_synthesize_custom_constructor_callable():
    src = _src("""
        class Order:
            amount_cents: int
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, _, _ = synthesize_constructor_call(
        shape=shape, raw_locals={"amount_cents": 100},
        constructor_callable="Order.objects.create",
    )
    assert call.startswith("Order.objects.create(")


# --- Case-insensitive matching for ORM field naming ------------------------

def test_synthesize_case_insensitive_local_match():
    src = _src("""
        class Order:
            order_id: str
    """)
    shape = analyze_class_source(src, "Order")
    assert shape is not None
    call, _, _ = synthesize_constructor_call(shape=shape, raw_locals={"Order_Id": "abc"})
    assert "order_id='abc'" in call


# --- Robustness on broken input --------------------------------------------

def test_analyze_returns_none_on_syntax_error():
    shape = analyze_class_source("class Broken(:", "Broken")
    assert shape is None


def test_analyze_returns_none_when_class_missing():
    shape = analyze_class_source("x = 1", "Missing")
    assert shape is None
