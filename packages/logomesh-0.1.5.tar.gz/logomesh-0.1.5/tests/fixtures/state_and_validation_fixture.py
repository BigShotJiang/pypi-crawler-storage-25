"""Fixture source covering validation guards plus side-effect traps.

Used by regression tests to ensure validator + static signal policy stays stable.
"""

_MODEL_CACHE = {}


def setup_training_config(device_type: str, resume: bool, data_yaml: str):
    if device_type not in ("cpu", "cuda", "mps"):
        raise ValueError(f"Unknown device type: {device_type}")
    _MODEL_CACHE[device_type] = True
    return {"device": device_type, "resume": resume, "data": data_yaml}


def execute_session(path: str):
    f = open("telemetry.log", "a")
    try:
        if not path:
            return "missing"
        f.close()
        return "ok"
    except Exception:
        return "caught"

