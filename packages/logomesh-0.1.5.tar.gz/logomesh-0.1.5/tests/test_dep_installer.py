"""Unit tests for dep_installer parse layer (no Docker required)."""
from business_logic.sandbox.dep_installer import parse_dep_specs, _normalize_spec


def test_pyproject_deps_parsed():
    pyproject = """
[project]
name = "thing"
dependencies = [
    "requests>=2.30",
    "pandas",
]
[project.optional-dependencies]
test = ["pytest>=8.0", "numpy<2"]
"""
    specs = parse_dep_specs({"pyproject.toml": pyproject})
    assert "requests>=2.30" in specs
    assert "pandas" in specs
    assert "pytest>=8.0" in specs
    assert "numpy<2" in specs


def test_requirements_txt_parsed():
    req = """
# comment
requests==2.31.0
pandas  # inline comment
--index-url https://example.com/
-e ./local
"""
    specs = parse_dep_specs({"requirements.txt": req})
    assert "requests==2.31.0" in specs
    assert "pandas" in specs
    assert all("-e" not in s and "index-url" not in s for s in specs)


def test_rejects_url_and_path_specs():
    assert _normalize_spec("git+https://github.com/x/y") is None
    assert _normalize_spec("pkg @ https://example.com/pkg.tar.gz") is None
    assert _normalize_spec("file:./local") is None
    assert _normalize_spec("./local_pkg") is None
    assert _normalize_spec("-e .") is None
    assert _normalize_spec("/abs/path") is None


def test_rejects_bad_names():
    assert _normalize_spec("!!!bad") is None
    assert _normalize_spec("") is None
    assert _normalize_spec(" ") is None


def test_accepts_extras():
    assert _normalize_spec("pkg[test,extra]") == "pkg[test,extra]"
    assert _normalize_spec("pkg[test]>=1.0") == "pkg[test]>=1.0"


def test_accepts_version_specs():
    for s in ("pkg>=1.0", "pkg==1.2.3", "pkg<2", "pkg~=1.0", "pkg!=1.1"):
        assert _normalize_spec(s) == s


def test_strips_env_markers():
    specs = parse_dep_specs({"requirements.txt": "pkg; python_version<'3.11'\n"})
    assert "pkg" in specs


def test_dedupes_across_manifests():
    specs = parse_dep_specs({
        "pyproject.toml": '[project]\nname="x"\ndependencies=["requests>=2.30"]\n',
        "requirements.txt": "requests\n",
    })
    # First occurrence wins; only one requests spec in output.
    matches = [s for s in specs if s.lower().startswith("requests")]
    assert len(matches) == 1


def test_max_specs_cap():
    lines = "\n".join(f"pkg{i}" for i in range(100))
    specs = parse_dep_specs({"requirements.txt": lines})
    assert len(specs) <= 50


def test_empty_input():
    assert parse_dep_specs({}) == []
    assert parse_dep_specs({"pyproject.toml": ""}) == []


def test_malformed_pyproject_ignored():
    specs = parse_dep_specs({"pyproject.toml": "this is {{ not toml"})
    assert specs == []


def test_setup_py_skipped():
    # setup.py parsing is ambiguous; we skip entirely rather than risk false specs.
    specs = parse_dep_specs({"setup.py": "setup(install_requires=['requests'])"})
    assert specs == []
