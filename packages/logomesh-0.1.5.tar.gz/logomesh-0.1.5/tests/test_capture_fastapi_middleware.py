"""FastAPI / Starlette ASGI middleware capture."""

from __future__ import annotations

import asyncio
import json

import pytest

fastapi = pytest.importorskip("fastapi")
httpx = pytest.importorskip("httpx")

from capture import ring_buffer  # noqa: E402
from capture.hooks.fastapi_hook import logomeshMiddleware  # noqa: E402


@pytest.fixture(autouse=True)
def _clean_buffer():
    # Materialize the deque in this thread's contextvars so the asyncio child
    # context inherits the same object reference and middleware appends are
    # visible after asyncio.run() returns.
    ring_buffer.get_buffer()
    ring_buffer.drain()
    yield
    ring_buffer.drain()


def _build_app(redact_fields=None):
    app = fastapi.FastAPI()

    @app.post("/v1/checkout")
    async def checkout(payload: dict):  # type: ignore[type-arg]
        return {"ok": True, "echo_qty": payload.get("qty")}

    app.add_middleware(logomeshMiddleware, redact_fields=redact_fields or [])
    return app


def _run(coro):
    return asyncio.run(coro)


def test_middleware_captures_method_url_headers_and_body():
    app = _build_app(redact_fields=["authorization", "card_number"])

    async def go():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport,
                                     base_url="http://testserver") as client:
            return await client.post(
                "/v1/checkout?promo=spring",
                headers={
                    "Authorization": "Bearer sk_test_xyz",
                    "Idempotency-Key": "idem_99",
                    "content-type": "application/json",
                },
                content=json.dumps({
                    "qty": 3, "card_number": "4242424242424242",
                }),
            )

    resp = _run(go())
    assert resp.status_code == 200
    assert resp.json()["echo_qty"] == 3

    requests = [e for e in ring_buffer.drain() if e.get("type") == "request"]
    assert len(requests) == 1
    req = requests[0]
    assert req["method"] == "POST"
    assert req["path"] == "/v1/checkout"
    assert "promo=spring" in req["query_string"]
    assert req["headers"].get("authorization") == "[REDACTED]"
    assert req["headers"].get("idempotency-key") == "idem_99"
    body = json.loads(req["body"])
    assert body["qty"] == 3
    assert body["card_number"] == "[REDACTED]"
    assert req["body_truncated"] is False


def test_middleware_does_not_break_handler_when_body_consumed():
    app = _build_app()

    async def go():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport,
                                     base_url="http://testserver") as client:
            return await client.post(
                "/v1/checkout",
                content=json.dumps({"qty": 7}),
                headers={"content-type": "application/json"},
            )

    resp = _run(go())
    assert resp.status_code == 200
    assert resp.json() == {"ok": True, "echo_qty": 7}


def test_middleware_truncates_oversized_body():
    app = fastapi.FastAPI()

    @app.post("/echo")
    async def echo(req: fastapi.Request):
        body = await req.body()
        return {"len": len(body)}

    app.add_middleware(logomeshMiddleware, max_body_bytes=128)

    big = "x" * 4096

    async def go():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport,
                                     base_url="http://testserver") as client:
            return await client.post("/echo", content=big.encode("utf-8"))

    resp = _run(go())
    assert resp.status_code == 200
    assert resp.json()["len"] == 4096

    requests = [e for e in ring_buffer.drain() if e.get("type") == "request"]
    assert len(requests) == 1
    req = requests[0]
    assert len(req["body"]) <= 128
    assert req["body_truncated"] is True


def test_middleware_surfaces_stripe_webhook_metadata():
    """Inbound Stripe webhook delivery: event id / type / signature / attempt
    must be lifted to top-level fields on the request entry."""
    app = fastapi.FastAPI()

    @app.post("/stripe/webhook")
    async def webhook(req: fastapi.Request):
        body = await req.body()
        # Force handler to actually consume body so middleware sees the
        # full receive cycle.
        return {"len": len(body)}

    app.add_middleware(logomeshMiddleware)

    body = json.dumps({
        "id": "evt_test_dup_42",
        "type": "invoice.payment_failed",
        "livemode": False,
        "api_version": "2024-06-20",
        "data": {"object": {"object": "invoice", "id": "in_test_9"}},
        "request": {"id": "req_a", "idempotency_key": "idem_777"},
    })

    async def go():
        transport = httpx.ASGITransport(app=app)
        async with httpx.AsyncClient(transport=transport,
                                     base_url="http://testserver") as client:
            return await client.post(
                "/stripe/webhook",
                content=body,
                headers={
                    "content-type": "application/json",
                    "Stripe-Signature": "t=1700000000,v1=abc123",
                    "Stripe-Webhook-Attempt": "3",
                },
            )

    resp = _run(go())
    assert resp.status_code == 200

    requests = [e for e in ring_buffer.drain() if e.get("type") == "request"]
    assert len(requests) == 1
    req = requests[0]
    assert req["is_stripe_webhook"] is True
    assert req["stripe_event_id"] == "evt_test_dup_42"
    assert req["stripe_event_type"] == "invoice.payment_failed"
    assert req["stripe_event_object_type"] == "invoice"
    assert req["stripe_event_object_id"] == "in_test_9"
    assert req["stripe_request_idempotency_key"] == "idem_777"
    assert req["stripe_signature_t"] == 1700000000
    assert req["stripe_webhook_attempt"] == 3
    assert req["stripe_livemode"] is False
    assert req["stripe_api_version"] == "2024-06-20"


def test_non_http_scope_passes_through():
    captured = []

    async def inner(scope, receive, send):
        captured.append(scope["type"])

    mw = logomeshMiddleware(inner)

    async def fake_recv():
        return {"type": "lifespan.startup"}

    async def fake_send(_):
        return None

    asyncio.run(mw({"type": "lifespan"}, fake_recv, fake_send))
    assert captured == ["lifespan"]
    assert [e for e in ring_buffer.drain() if e.get("type") == "request"] == []
