"""Tests for oracles.signal_detectors."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class _Frame:
    filename: str = ""
    function: str = "process"
    lineno: int = 10
    context_line: str = ""
    variables: dict = field(default_factory=dict)


@dataclass
class _Exc:
    issue_id: str = "123"
    issue_url: str = ""
    error_type: str = "ValueError"
    error_message: str = ""
    last_seen: str = "2026-03-15T14:30:00Z"
    event_count: int = 1
    frames: list = field(default_factory=list)
    timezone: str = ""


from oracles.signal_detectors import (
    memory_error_fixture,
    fd_exhaustion_fixture,
    hashseed_metadata,
    hashseed_preamble,
    gc_cycle_fixture,
    toctou_barrier_fixture,
    asyncio_race_fixture,
    unicode_fixture,
    build_signal_harnesses,
)


# ---------------------------------------------------------------------------
# memory_error_fixture
# ---------------------------------------------------------------------------

def test_memory_error_no_match():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ValueError")
    assert memory_error_fixture(frame, exc) == ""


def test_memory_error_match():
    frame = _Frame(variables={"data": [1, 2, 3]})
    exc = _Exc(error_type="MemoryError", error_message="")
    result = memory_error_fixture(frame, exc)
    assert "setrlimit" in result
    assert "RLIMIT_AS" in result
    assert "tracemalloc" in result
    assert "cgroup" in result


def test_memory_error_collection_hint():
    frame = _Frame(variables={"big_list": [1, 2, 3, 4, 5]})
    exc = _Exc(error_type="MemoryError")
    result = memory_error_fixture(frame, exc)
    assert "big_list" in result


def test_memory_error_in_message():
    frame = _Frame(variables={})
    exc = _Exc(error_type="RuntimeError", error_message="MemoryError raised during allocation")
    result = memory_error_fixture(frame, exc)
    assert "setrlimit" in result


# ---------------------------------------------------------------------------
# fd_exhaustion_fixture
# ---------------------------------------------------------------------------

def test_fd_exhaustion_no_match():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ValueError", error_message="bad value")
    assert fd_exhaustion_fixture(frame, exc) == ""


def test_fd_exhaustion_errno24():
    frame = _Frame(variables={}, function="open_file")
    exc = _Exc(error_type="OSError", error_message="[Errno 24] Too many open files")
    result = fd_exhaustion_fixture(frame, exc)
    assert "RLIMIT_NOFILE" in result
    assert "64" in result
    assert "_assert_no_fd_leak" in result


def test_fd_exhaustion_resource_warning():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ResourceWarning", error_message="unclosed file <_io.TextIOWrapper>")
    result = fd_exhaustion_fixture(frame, exc)
    assert "RLIMIT_NOFILE" in result


def test_fd_exhaustion_emfile():
    frame = _Frame(variables={})
    exc = _Exc(error_type="OSError", error_message="[Errno 23] No more file descriptors")
    result = fd_exhaustion_fixture(frame, exc)
    assert "RLIMIT_NOFILE" in result


# ---------------------------------------------------------------------------
# hashseed_metadata
# ---------------------------------------------------------------------------

def test_hashseed_no_keyerror():
    frame = _Frame(variables={"x": 1})
    exc = _Exc(error_type="ValueError")
    assert hashseed_metadata(frame, exc) == {}


def test_hashseed_keyerror_no_dict():
    frame = _Frame(variables={"amount": 100, "user_id": 42})
    exc = _Exc(error_type="KeyError")
    assert hashseed_metadata(frame, exc) == {}


def test_hashseed_keyerror_with_dict():
    frame = _Frame(variables={"data": {"a": 1, "b": 2}})
    exc = _Exc(error_type="KeyError", error_message="'missing_key'")
    result = hashseed_metadata(frame, exc)
    assert "try_hashseeds" in result
    assert len(result["try_hashseeds"]) == 20
    assert 0 in result["try_hashseeds"]


def test_hashseed_preamble():
    result = hashseed_preamble(42)
    assert "PYTHONHASHSEED=42" in result


# ---------------------------------------------------------------------------
# gc_cycle_fixture
# ---------------------------------------------------------------------------

def test_gc_no_match():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ValueError")
    assert gc_cycle_fixture(frame, exc) == ""


def test_gc_resource_warning():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ResourceWarning", error_message="unclosed file")
    result = gc_cycle_fixture(frame, exc)
    assert "weakref" in result
    assert "_gc.collect" in result or "gc.collect" in result


def test_gc_del_in_message():
    frame = _Frame(variables={})
    exc = _Exc(error_type="RuntimeError", error_message="__del__ called during shutdown")
    result = gc_cycle_fixture(frame, exc)
    assert "weakref" in result


def test_gc_locals_signal():
    frame = _Frame(variables={"ref": "weakref.ref object at 0x...", "cycle": "yes"})
    exc = _Exc(error_type="Exception")
    result = gc_cycle_fixture(frame, exc)
    assert "weakref" in result


# ---------------------------------------------------------------------------
# toctou_barrier_fixture
# ---------------------------------------------------------------------------

def test_toctou_no_match():
    frame = _Frame(variables={})
    assert toctou_barrier_fixture(frame, "x = 1\ny = 2") == ""


def test_toctou_exists_pattern():
    frame = _Frame(variables={}, function="create_order")
    source = "if not Order.objects.filter(id=order_id).exists():\n    Order.objects.create(id=order_id)"
    result = toctou_barrier_fixture(frame, source)
    assert "_RACE_BARRIER" in result
    assert "threading" in result
    assert "setswitchinterval" in result


def test_toctou_get_or_create():
    frame = _Frame(variables={})
    source = "obj, created = User.objects.get_or_create(email=email)"
    result = toctou_barrier_fixture(frame, source)
    assert "_RACE_BARRIER" in result


def test_toctou_filter_without_lock():
    frame = _Frame(variables={})
    source = "existing = Account.objects.filter(user=user).first()\nif existing:\n    existing.balance += amount"
    result = toctou_barrier_fixture(frame, source)
    assert "_run_toctou_test" in result


# ---------------------------------------------------------------------------
# asyncio_race_fixture
# ---------------------------------------------------------------------------

def test_async_no_match():
    frame = _Frame(variables={})
    assert asyncio_race_fixture(frame, "def sync_func(): pass") == ""


def test_async_match():
    frame = _Frame(variables={}, function="handle_request")
    source = "async def handle_request():\n    result = await fetch_data()\n    return result"
    result = asyncio_race_fixture(frame, source)
    assert "_run_concurrent" in result
    assert "asyncio.sleep(0)" in result


def test_async_toctou_detection():
    frame = _Frame(variables={})
    source = "async def handler():\n    if key not in await cache.get_all():\n        await cache.set(key, value)"
    result = asyncio_race_fixture(frame, source)
    assert "TOCTOU" in result


def test_async_create_task():
    frame = _Frame(variables={})
    source = "task = asyncio.create_task(process(item))\nawait task"
    result = asyncio_race_fixture(frame, source)
    assert "_run_concurrent" in result


# ---------------------------------------------------------------------------
# unicode_fixture
# ---------------------------------------------------------------------------

def test_unicode_no_match():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ValueError")
    assert unicode_fixture(frame, exc) == ""


def test_unicode_decode_error():
    frame = _Frame(variables={"raw": b"\xff\xfe bad bytes"})
    exc = _Exc(error_type="UnicodeDecodeError", error_message="'utf-8' codec can't decode byte 0xff")
    result = unicode_fixture(frame, exc)
    assert "_CRASH_ENCODING" in result
    assert "utf-8" in result


def test_unicode_bytes_in_locals():
    frame = _Frame(variables={"content": b"\x80\x81\x82"})
    exc = _Exc(error_type="UnicodeDecodeError", error_message="invalid byte sequence")
    result = unicode_fixture(frame, exc)
    assert "CRASH_BYTES" in result


def test_unicode_encode_error():
    frame = _Frame(variables={})
    exc = _Exc(error_type="UnicodeEncodeError", error_message="codec can't encode character")
    result = unicode_fixture(frame, exc)
    assert "ENCODING" in result or "encoding" in result.lower()


# ---------------------------------------------------------------------------
# build_signal_harnesses (composite)
# ---------------------------------------------------------------------------

def test_composite_empty():
    frame = _Frame(variables={})
    exc = _Exc(error_type="ValueError")
    code, meta = build_signal_harnesses(frame, exc, "")
    assert code == ""
    assert meta == {}


def test_composite_memory():
    frame = _Frame(variables={"buf": b"x" * 100})
    exc = _Exc(error_type="MemoryError")
    code, meta = build_signal_harnesses(frame, exc, "")
    assert "setrlimit" in code
    assert meta == {}


def test_composite_toctou_and_keyerror():
    frame = _Frame(variables={"cache": {"a": 1}})
    exc = _Exc(error_type="KeyError")
    source = "if not Order.objects.filter(id=x).exists():\n    Order.objects.create(id=x)"
    code, meta = build_signal_harnesses(frame, exc, source)
    assert "_RACE_BARRIER" in code
    assert "try_hashseeds" in meta


def test_composite_fd_and_async():
    frame = _Frame(variables={}, function="stream_response")
    exc = _Exc(error_type="OSError", error_message="[Errno 24] Too many open files")
    source = "async def stream_response():\n    data = await fetch()\n    return data"
    code, meta = build_signal_harnesses(frame, exc, source)
    assert "RLIMIT_NOFILE" in code
    assert "_run_concurrent" in code
