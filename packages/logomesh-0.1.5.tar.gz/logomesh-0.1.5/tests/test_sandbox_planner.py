"""Tests for sandbox-spec primitives.

The planner is agent-led: the agent builds a SandboxSpec by calling
the explicit primitives (`build_sandbox_spec`, `make_env_step`, ...)
with its own decisions. The optional `suggest_starter_spec()` is a
low-confidence hint, never a decision-maker.
"""

from __future__ import annotations

import textwrap
from pathlib import Path

from business_logic.repo_introspection import scan_repo
from business_logic.sandbox_planner import (
    BootstrapStep,
    SandboxSpec,
    build_sandbox_spec,
    dependencies_from_manifests,
    make_conftest_step,
    make_env_step,
    make_exec_step,
    python_version_from_manifests,
    suggest_starter_spec,
)


def _write(root: Path, rel: str, content: str) -> None:
    p = root / rel
    p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(textwrap.dedent(content).lstrip())


# --- Agent-led primitives ---------------------------------------------------

def test_build_sandbox_spec_uses_agent_inputs():
    step = make_env_step(
        vars={"DATABASE_URL": "sqlite:///:memory:"},
        reason="agent decided to route DB to in-memory SQLite for this Django repo",
        evidence_refs=["payments/models.py:1"],
    )
    spec = build_sandbox_spec(
        python_version="3.12",
        dependencies=["django>=5.0"],
        env={"DJANGO_SETTINGS_MODULE": "project.settings"},
        bootstrap_steps=[step],
        notes=["agent reasoning recorded here"],
        confidence=0.85,
    )
    assert isinstance(spec, SandboxSpec)
    assert spec.python_version == "3.12"
    assert spec.dependencies == ["django>=5.0"]
    assert spec.env["DJANGO_SETTINGS_MODULE"] == "project.settings"
    # Hygiene defaults always added
    assert spec.env["PYTHONDONTWRITEBYTECODE"] == "1"
    assert spec.env["PYTHONUNBUFFERED"] == "1"
    assert spec.bootstrap_steps == [step]
    assert spec.confidence == 0.85


def test_build_sandbox_spec_clamps_confidence():
    s1 = build_sandbox_spec(python_version="3.12", confidence=99.0)
    s2 = build_sandbox_spec(python_version="3.12", confidence=-5.0)
    assert s1.confidence == 1.0
    assert s2.confidence == 0.0


def test_make_env_step_records_agent_reason_and_refs():
    step = make_env_step(
        vars={"REDIS_URL": "memory://"},
        reason="agent chose memory broker because no live Redis is available",
        evidence_refs=["tasks.py:5"],
    )
    assert step.kind == "set_env"
    assert step.payload["vars"]["REDIS_URL"] == "memory://"
    assert "agent chose" in step.reason
    assert step.evidence_refs == ["tasks.py:5"]


def test_make_conftest_step_uses_agent_content():
    step = make_conftest_step(
        content="import os\nos.environ['DJANGO_SETTINGS_MODULE'] = 'project.settings'\n",
        reason="bootstrap Django before test imports",
        evidence_refs=["project/settings.py"],
    )
    assert step.kind == "write_file"
    assert "DJANGO_SETTINGS_MODULE" in step.payload["content"]
    assert step.payload["path"] == "conftest.py"


def test_make_exec_step_uses_agent_code():
    step = make_exec_step(
        code="import django; django.setup()",
        reason="agent decided to run django.setup() before test import",
    )
    assert step.kind == "exec_python"
    assert "django.setup()" in step.payload["code"]


# --- Pure utility extractors -----------------------------------------------

def test_dependencies_from_manifests_dedups(tmp_path):
    _write(tmp_path, "pyproject.toml", """
        [project]
        requires-python = ">=3.12"
        dependencies = ["fastapi", "uvicorn"]
    """)
    _write(tmp_path, "requirements.txt", "fastapi==0.110\nstripe>=7\n")
    intro = scan_repo(tmp_path)
    deps_lower = [d.lower() for d in dependencies_from_manifests(intro)]
    assert sum(1 for d in deps_lower if d.startswith("fastapi")) == 1
    assert any(d.startswith("uvicorn") for d in deps_lower)
    assert any(d.startswith("stripe") for d in deps_lower)


def test_python_version_extracts_first_seen(tmp_path):
    _write(tmp_path, "pyproject.toml", """
        [project]
        requires-python = ">=3.11"
    """)
    intro = scan_repo(tmp_path)
    assert python_version_from_manifests(intro) == "3.11"


def test_python_version_empty_when_no_manifest(tmp_path):
    intro = scan_repo(tmp_path)
    assert python_version_from_manifests(intro) == ""


# --- Optional starter suggestion is low-confidence -------------------------

def test_starter_spec_low_confidence_and_no_routing(tmp_path):
    _write(tmp_path, "pyproject.toml", """
        [project]
        requires-python = ">=3.12"
        dependencies = ["django>=5.0", "celery>=5.4"]
    """)
    _write(tmp_path, "payments/models.py", """
        from django.db import models
        class Order(models.Model): pass
    """)
    intro = scan_repo(tmp_path)
    spec = suggest_starter_spec(introspection=intro)

    # Confidence is deliberately low — the agent should override
    assert spec.confidence <= 0.4
    # Starter does NOT make framework decisions — no DATABASE_URL routing
    assert "DATABASE_URL" not in spec.env
    assert "CELERY_TASK_ALWAYS_EAGER" not in spec.env
    # But it carries the verbatim deps + python version so the agent has a base
    assert spec.python_version.startswith("3.")
    assert any("django" in d.lower() for d in spec.dependencies)
    assert any("starter" in n.lower() for n in spec.notes)


def test_starter_spec_empty_repo_is_minimal():
    from tempfile import TemporaryDirectory
    with TemporaryDirectory() as td:
        intro = scan_repo(td)
        spec = suggest_starter_spec(introspection=intro)
        assert spec.dependencies == []
        assert spec.bootstrap_steps == []
        assert spec.env == {"PYTHONDONTWRITEBYTECODE": "1", "PYTHONUNBUFFERED": "1"}


def test_spec_serializes_with_agent_reasons(tmp_path):
    import json
    step = make_env_step(
        vars={"DATABASE_URL": "sqlite:///:memory:"},
        reason="agent reasoning string",
        evidence_refs=["x.py:1"],
    )
    spec = build_sandbox_spec(
        python_version="3.12",
        bootstrap_steps=[step],
    )
    encoded = json.loads(json.dumps(spec.to_dict()))
    assert encoded["bootstrap_steps"][0]["reason"] == "agent reasoning string"
    assert encoded["bootstrap_steps"][0]["evidence_refs"] == ["x.py:1"]
