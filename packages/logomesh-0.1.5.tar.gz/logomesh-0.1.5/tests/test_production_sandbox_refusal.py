"""LOGOMESH_ENV=production must refuse subprocess fallback.

Subprocess mode is not isolated. The compliance artifact preamble
claims a sealed Docker airgap; emitting `sandbox_mode: subprocess`
in a customer-facing artifact would be a false claim. We fail loud
at Sandbox construction (and at server startup) rather than degrade.
"""

from __future__ import annotations

import importlib
import os
import sys
from pathlib import Path
from unittest import mock

import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))
sys.path.insert(0, str(_REPO_ROOT / "src"))


def _reload_sandbox():
    for mod in list(sys.modules):
        if mod.startswith("business_logic.sandbox"):
            del sys.modules[mod]
    return importlib.import_module("business_logic.sandbox")


def test_sandbox_refuses_to_construct_without_docker_in_prod(monkeypatch):
    monkeypatch.setenv("LOGOMESH_ENV", "production")
    sb_mod = _reload_sandbox()
    # Force docker unavailable.
    monkeypatch.setattr(sb_mod, "DOCKER_AVAILABLE", False)
    with pytest.raises(RuntimeError, match="LOGOMESH_ENV=production"):
        sb_mod.Sandbox()


def test_sandbox_refuses_when_docker_install_present_but_daemon_unreachable(monkeypatch):
    monkeypatch.setenv("LOGOMESH_ENV", "production")
    sb_mod = _reload_sandbox()
    monkeypatch.setattr(sb_mod, "DOCKER_AVAILABLE", True)

    class _FakeDocker:
        @staticmethod
        def from_env():
            class _C:
                def ping(self_):
                    raise OSError("daemon unreachable")
            return _C()

    monkeypatch.setattr(sb_mod, "docker", _FakeDocker)
    with pytest.raises(RuntimeError):
        sb_mod.Sandbox()


def test_sandbox_dev_mode_allows_subprocess_fallback(monkeypatch):
    monkeypatch.delenv("LOGOMESH_ENV", raising=False)
    sb_mod = _reload_sandbox()
    monkeypatch.setattr(sb_mod, "DOCKER_AVAILABLE", False)
    sb = sb_mod.Sandbox()  # MUST NOT raise in dev
    assert sb.mode == "subprocess"


def test_sandbox_other_env_values_do_not_trigger_refusal(monkeypatch):
    """staging / dev / test must NOT trigger the production refusal."""
    sb_mod = _reload_sandbox()
    monkeypatch.setattr(sb_mod, "DOCKER_AVAILABLE", False)
    for value in ("dev", "staging", "test", "ci", ""):
        monkeypatch.setenv("LOGOMESH_ENV", value)
        sb = sb_mod.Sandbox()
        assert sb.mode == "subprocess"


def test_server_startup_check_exits_in_prod_without_docker(monkeypatch):
    """LOGOMESH_ENV=production + no Docker → sys.exit at module import."""
    monkeypatch.setenv("LOGOMESH_ENV", "production")
    for mod in list(sys.modules):
        if mod.startswith("src.server"):
            del sys.modules[mod]

    # Mock docker to raise so the ping inside _verify_production_sandbox fails.
    fake_docker = mock.MagicMock()
    fake_docker.from_env.side_effect = OSError("no docker")
    sys.modules["docker"] = fake_docker

    try:
        with pytest.raises(SystemExit) as exc_info:
            importlib.import_module("src.server.app")
        assert exc_info.value.code == 2
    finally:
        sys.modules.pop("docker", None)


def test_server_startup_check_skips_when_env_is_not_production(monkeypatch):
    """Dev / test boots fine even with no Docker."""
    monkeypatch.setenv("LOGOMESH_ENV", "dev")
    for mod in list(sys.modules):
        if mod.startswith("src.server"):
            del sys.modules[mod]
    # Module should import without sys.exit.
    importlib.import_module("src.server.app")
