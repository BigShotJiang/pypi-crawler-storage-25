"""Tests for the Sentry Replay oracle lane."""

import pytest
from unittest.mock import AsyncMock, patch, MagicMock

from oracles.sentry_replay import (
    SentryException,
    SentryFrame,
    _build_call_from_frame,
    _exception_to_test,
    _extract_replay_call,
    _find_target_frame,
    _safe_repr,
)


# ---------------------------------------------------------------------------
# SentryFrame / call building
# ---------------------------------------------------------------------------


def test_build_call_from_frame_with_variables():
    frame = SentryFrame(
        filename="checkout.py",
        function="process_order",
        lineno=42,
        context_line="total = qty * price",
        variables={"qty": -5, "price": "9.99", "user_id": 123},
    )
    call = _build_call_from_frame(frame, "")
    assert call is not None
    assert "process_order(" in call
    assert "qty=-5" in call
    assert "price=" in call
    assert "user_id=123" in call


def test_build_call_from_frame_skips_self_and_cls():
    frame = SentryFrame(
        filename="service.py",
        function="run",
        lineno=10,
        context_line="",
        variables={"self": "<Service>", "cls": "<type>", "x": 1},
    )
    call = _build_call_from_frame(frame, "")
    assert "self" not in call
    assert "cls" not in call
    assert "x=1" in call


def test_build_call_from_frame_no_variables():
    frame = SentryFrame(
        filename="utils.py",
        function="cleanup",
        lineno=5,
        context_line="",
        variables={},
    )
    call = _build_call_from_frame(frame, "")
    assert call == "cleanup()"


def test_build_call_from_frame_no_function():
    frame = SentryFrame(
        filename="utils.py",
        function="",
        lineno=5,
        context_line="",
        variables={},
    )
    assert _build_call_from_frame(frame, "") is None


# ---------------------------------------------------------------------------
# Frame finding
# ---------------------------------------------------------------------------


def test_find_target_frame_picks_innermost():
    exc = SentryException(
        issue_id="1", issue_url="", error_type="ValueError",
        error_message="bad", last_seen="", event_count=1,
        frames=[
            SentryFrame(filename="lib/checkout.py", function="outer", lineno=10, context_line="", variables={}),
            SentryFrame(filename="lib/other.py", function="helper", lineno=20, context_line="", variables={}),
            SentryFrame(filename="lib/checkout.py", function="inner", lineno=30, context_line="", variables={}),
        ],
    )
    frame = _find_target_frame(exc, "lib/checkout.py")
    assert frame is not None
    assert frame.function == "inner"
    assert frame.lineno == 30


def test_find_target_frame_none_when_no_match():
    exc = SentryException(
        issue_id="1", issue_url="", error_type="KeyError",
        error_message="key", last_seen="", event_count=1,
        frames=[
            SentryFrame(filename="other.py", function="f", lineno=1, context_line="", variables={}),
        ],
    )
    assert _find_target_frame(exc, "checkout.py") is None


# ---------------------------------------------------------------------------
# Exception → test code
# ---------------------------------------------------------------------------


def test_exception_to_test_generates_valid_pytest():
    exc = SentryException(
        issue_id="42", issue_url="", error_type="ZeroDivisionError",
        error_message="division by zero", last_seen="2026-04-01", event_count=15,
        frames=[
            SentryFrame(
                filename="billing/calc.py", function="compute_rate",
                lineno=18, context_line="rate = total / count",
                variables={"total": 100, "count": 0},
            ),
        ],
    )
    code = _exception_to_test(exc, "def compute_rate(): pass", "billing/calc.py")
    assert code is not None
    assert "def test_sentry_replay_42" in code
    assert "pytest.raises" not in code
    assert "compute_rate(" in code


def test_exception_to_test_returns_none_for_module_level():
    exc = SentryException(
        issue_id="99", issue_url="", error_type="ImportError",
        error_message="no module", last_seen="", event_count=1,
        frames=[
            SentryFrame(filename="app.py", function="<module>", lineno=1, context_line="", variables={}),
        ],
    )
    assert _exception_to_test(exc, "", "app.py") is None


def test_exception_to_test_returns_none_for_no_matching_frame():
    exc = SentryException(
        issue_id="99", issue_url="", error_type="KeyError",
        error_message="key", last_seen="", event_count=1,
        frames=[
            SentryFrame(filename="other.py", function="f", lineno=1, context_line="", variables={}),
        ],
    )
    assert _exception_to_test(exc, "", "app.py") is None


# ---------------------------------------------------------------------------
# safe_repr
# ---------------------------------------------------------------------------


def test_safe_repr_primitives():
    assert _safe_repr(None) == "None"
    assert _safe_repr(42) == "42"
    assert _safe_repr(-3.14) == "-3.14"
    assert _safe_repr("True") == "True"
    assert _safe_repr("False") == "False"


def test_safe_repr_strings():
    assert _safe_repr("'hello'") == "'hello'"
    result = _safe_repr("some object")
    assert isinstance(result, str)


# ---------------------------------------------------------------------------
# extract_replay_call
# ---------------------------------------------------------------------------


def test_extract_replay_call():
    code = (
        'def test_replay():\n'
        '    """Replay: ValueError"""\n'
        '    with pytest.raises(ValueError):\n'
        '        process_order(qty=-5, price=9.99)\n'
    )
    call = _extract_replay_call(code)
    assert "process_order" in call


# ---------------------------------------------------------------------------
