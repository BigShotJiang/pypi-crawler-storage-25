"""Tests for src/server/github_comment.py."""

from __future__ import annotations

import asyncio
import sys
from pathlib import Path
from unittest import mock

import httpx
import pytest

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))

from src.server.github_comment import (  # noqa: E402
    parse_pr_url,
    post_pr_comment,
    post_verdict_to_pr,
)


# ---- URL parsing ---------------------------------------------------------

def test_parse_pr_url_standard():
    out = parse_pr_url("https://github.com/acme/widgets/pull/42")
    assert out == ("acme", "widgets", 42)


def test_parse_pr_url_issues():
    out = parse_pr_url("https://github.com/acme/widgets/issues/7")
    assert out == ("acme", "widgets", 7)


def test_parse_pr_url_with_extra_path():
    out = parse_pr_url("https://github.com/acme/widgets/pull/42/files")
    assert out == ("acme", "widgets", 42)


def test_parse_pr_url_enterprise():
    out = parse_pr_url("https://gh.acme.io/github.com/acme/widgets/pull/42")
    # The regex requires "github.com" in path; for true enterprise we'd
    # need a separate parser. v1 enterprise customers route through
    # api.github.com via PAT, so this is fine.
    assert out == ("acme", "widgets", 42)


def test_parse_pr_url_returns_none_on_garbage():
    assert parse_pr_url("not a url") is None
    assert parse_pr_url("") is None
    assert parse_pr_url("https://gitlab.com/x/y/-/merge_requests/1") is None


# ---- POST behavior -------------------------------------------------------

def test_post_pr_comment_calls_correct_url(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_xxx")
    captured = {}

    async def fake_post(self, url, headers=None, content=None, **kw):
        captured["url"] = url
        captured["headers"] = headers
        captured["content"] = content
        req = httpx.Request("POST", url)
        return httpx.Response(201, request=req, json={"id": 999})

    with mock.patch.object(httpx.AsyncClient, "post", fake_post):
        out = asyncio.run(post_pr_comment(
            "https://github.com/acme/widgets/pull/42", "hello",
        ))
        assert out == {"id": 999}
        assert captured["url"] == (
            "https://api.github.com/repos/acme/widgets/issues/42/comments"
        )
        assert captured["headers"]["Authorization"] == "Bearer ghp_xxx"
        assert captured["headers"]["X-GitHub-Api-Version"] == "2022-11-28"
        assert "hello" in captured["content"]


def test_post_pr_comment_raises_on_bad_url(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "ghp_xxx")
    with pytest.raises(ValueError):
        asyncio.run(post_pr_comment("not a url", "x"))


def test_post_pr_comment_raises_without_token(monkeypatch):
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    with pytest.raises(RuntimeError):
        asyncio.run(post_pr_comment(
            "https://github.com/acme/widgets/pull/42", "x",
        ))


def test_post_verdict_swallows_errors(monkeypatch):
    """Detached background task must NEVER raise."""
    monkeypatch.delenv("GITHUB_TOKEN", raising=False)
    asyncio.run(post_verdict_to_pr(
        "https://github.com/acme/widgets/pull/42",
        {"artifact": {"evidence_path_seal": {}}},
    ))
    # Empty pr_url path:
    asyncio.run(post_verdict_to_pr("", {}))


def test_post_pr_comment_uses_custom_api_host(monkeypatch):
    monkeypatch.setenv("GITHUB_TOKEN", "ghp")
    monkeypatch.setenv("LOGOMESH_GITHUB_API", "https://gh.acme.io/api/v3/")
    captured = {}

    async def fake_post(self, url, headers=None, content=None, **kw):
        captured["url"] = url
        return httpx.Response(201, request=httpx.Request("POST", url), json={"id": 1})

    with mock.patch.object(httpx.AsyncClient, "post", fake_post):
        asyncio.run(post_pr_comment(
            "https://github.com/acme/widgets/pull/42", "x",
        ))
        assert captured["url"].startswith("https://gh.acme.io/api/v3/repos/acme/widgets")
