"""Tests for oracles.crash_context and oracles.api_error_fixtures."""
from __future__ import annotations

from dataclasses import dataclass, field


@dataclass
class _Frame:
    filename: str = ""
    function: str = "process"
    lineno: int = 10
    context_line: str = ""
    variables: dict = field(default_factory=dict)


@dataclass
class _Exc:
    issue_id: str = "123"
    issue_url: str = "https://sentry.io/issues/123/"
    error_type: str = "ValueError"
    error_message: str = "bad value"
    last_seen: str = "2026-03-15T14:30:00Z"
    event_count: int = 1
    frames: list = field(default_factory=list)
    timezone: str = ""


from oracles.crash_context import (
    http_mock_from_locals,
    freeze_time_from_event,
    inject_freeze_time_decorator,
    tz_for_sandbox,
    db_fixture_hints,
    sqlalchemy_savepoint_code,
    race_wrapper_from_locals,
    build_supplementary_mock_code,
    _is_near_dst_transition,
)
from oracles.api_error_fixtures import match_from_locals, url_from_locals


# ---------------------------------------------------------------------------
# api_error_fixtures
# ---------------------------------------------------------------------------

def test_match_stripe_card_declined():
    vars_ = {"response": {"error": {"code": "card_declined", "type": "card_error"}}}
    result = match_from_locals(vars_)
    assert result is not None
    url, status, body = result
    assert "stripe" in url
    assert status == 402
    assert body["error"]["code"] == "card_declined"


def test_match_stripe_rate_limit():
    vars_ = {"resp": {"error": {"code": "rate_limit", "type": "invalid_request_error"}}}
    result = match_from_locals(vars_)
    assert result is not None
    _, status, _ = result
    assert status == 429


def test_match_none_on_no_match():
    vars_ = {"amount": 100, "user_id": 42}
    assert match_from_locals(vars_) is None


def test_url_from_locals_stripe():
    vars_ = {"url": "https://api.stripe.com/v1/charges", "amount": 100}
    assert "stripe" in url_from_locals(vars_)


def test_url_from_locals_fallback():
    vars_ = {"endpoint": "https://example.com/api", "x": 1}
    assert url_from_locals(vars_).startswith("https://")


# ---------------------------------------------------------------------------
# http_mock_from_locals
# ---------------------------------------------------------------------------

def test_http_mock_empty_vars():
    frame = _Frame(variables={})
    assert http_mock_from_locals(frame) == ""


def test_http_mock_no_response_locals():
    frame = _Frame(variables={"user_id": 42, "amount": 100})
    assert http_mock_from_locals(frame) == ""


def test_http_mock_known_stripe_shape():
    frame = _Frame(variables={
        "url": "https://api.stripe.com/v1/charges",
        "response": {"error": {"code": "card_declined", "type": "card_error"}},
    })
    result = http_mock_from_locals(frame)
    assert "_responses" in result or "responses" in result
    assert "_MOCK_BODY" in result
    assert "card_declined" in result


def test_http_mock_uses_respx_for_httpx():
    frame = _Frame(variables={"resp": {"status_code": 500, "error": "oops"}})
    source = "import httpx\nclient = httpx.AsyncClient()"
    result = http_mock_from_locals(frame, source)
    assert "respx" in result or "_respx" in result


def test_http_mock_generic_dict():
    frame = _Frame(variables={
        "response": {"status_code": 404, "body": "not found"},
    })
    result = http_mock_from_locals(frame)
    assert "responses" in result


def test_http_mock_json_string():
    frame = _Frame(variables={"result": '{"error": "rate_limit"}'})
    result = http_mock_from_locals(frame)
    assert "responses" in result


# ---------------------------------------------------------------------------
# freeze_time_from_event  (now time-machine)
# ---------------------------------------------------------------------------

def test_freeze_time_no_timestamp():
    exc = _Exc(last_seen="")
    assert freeze_time_from_event(exc) == ""


def test_freeze_time_invalid():
    exc = _Exc(last_seen="not-a-date")
    assert freeze_time_from_event(exc) == ""


def test_freeze_time_uses_time_machine():
    exc = _Exc(last_seen="2026-03-15T14:30:00Z")
    result = freeze_time_from_event(exc)
    assert "time_machine" in result
    assert "2026-03-15T14:30:00" in result
    assert "_CRASH_TIMESTAMP" in result


def test_freeze_time_includes_tz():
    exc = _Exc(last_seen="2026-03-15T02:00:00Z", timezone="America/New_York")
    result = freeze_time_from_event(exc)
    assert "America/New_York" in result


def test_freeze_time_dst_warning():
    # US fall-back 2024: 2024-11-03T06:00:00 UTC
    exc = _Exc(last_seen="2024-11-03T06:00:00Z")
    result = freeze_time_from_event(exc)
    assert "DST" in result


def test_freeze_time_no_dst_warning_normal():
    exc = _Exc(last_seen="2026-07-15T12:00:00Z")
    result = freeze_time_from_event(exc)
    assert "DST" not in result


# ---------------------------------------------------------------------------
# tz_for_sandbox
# ---------------------------------------------------------------------------

def test_tz_for_sandbox_present():
    exc = _Exc(timezone="America/Chicago")
    assert tz_for_sandbox(exc) == "America/Chicago"


def test_tz_for_sandbox_empty():
    exc = _Exc(timezone="")
    assert tz_for_sandbox(exc) == ""


# ---------------------------------------------------------------------------
# inject_freeze_time_decorator  (now time-machine)
# ---------------------------------------------------------------------------

def test_inject_no_timestamp():
    exc = _Exc(last_seen="")
    code = "from target import *\n\ndef test_foo():\n    foo(x=1)\n"
    assert inject_freeze_time_decorator(code, exc) == code


def test_inject_uses_time_machine():
    exc = _Exc(last_seen="2026-03-15T14:30:00Z")
    code = "from target import *\n\ndef test_foo():\n    foo(x=1)\n"
    result = inject_freeze_time_decorator(code, exc)
    assert "time_machine" in result
    assert "@_time_machine.travel" in result
    assert "2026-03-15T14:30:00Z" in result


def test_inject_idempotent_time_machine():
    exc = _Exc(last_seen="2026-03-15T14:30:00Z")
    code = "import time_machine\n@time_machine.travel('x')\ndef test_foo():\n    foo()\n"
    result = inject_freeze_time_decorator(code, exc)
    assert result.count("time_machine") >= 1


def test_inject_idempotent_freezegun():
    exc = _Exc(last_seen="2026-03-15T14:30:00Z")
    code = "from freezegun import freeze_time\n@freeze_time('x')\ndef test_foo():\n    foo()\n"
    result = inject_freeze_time_decorator(code, exc)
    assert "@_time_machine" not in result  # already has freeze_time, skip


# ---------------------------------------------------------------------------
# DST detection
# ---------------------------------------------------------------------------

def test_dst_detection_hits():
    assert _is_near_dst_transition("2024-11-03T06:00:00")  # exact US fall-back
    assert _is_near_dst_transition("2024-11-03T06:30:00")  # 30min after


def test_dst_detection_miss():
    assert not _is_near_dst_transition("2026-07-15T12:00:00")


# ---------------------------------------------------------------------------
# db_fixture_hints
# ---------------------------------------------------------------------------

def test_db_hints_empty():
    frame = _Frame(variables={})
    assert db_fixture_hints(frame) == ""


def test_db_hints_non_numeric():
    frame = _Frame(variables={"user_id": "abc"})
    assert db_fixture_hints(frame) == ""


def test_db_hints_emits_fixture():
    frame = _Frame(variables={"user_id": 42, "order_id": "1337"})
    result = db_fixture_hints(frame)
    assert "sqlalchemy_mock_config" in result
    assert "users" in result
    assert "42" in result


def test_db_hints_no_repo():
    frame = _Frame(variables={"account_id": "99"})
    result = db_fixture_hints(frame, repo_root=None)
    assert "sqlalchemy_mock_config" in result


# ---------------------------------------------------------------------------
# sqlalchemy_savepoint_code
# ---------------------------------------------------------------------------

def test_sqla_none():
    frame = _Frame(variables={"x": 1})
    assert sqlalchemy_savepoint_code(frame, "") == ""


def test_sqla_session_local():
    frame = _Frame(variables={"session": "<Session>"})
    result = sqlalchemy_savepoint_code(frame, "")
    assert "_savepoint_listener" in result
    assert "LOGOMESH_COMMIT_LIMIT" in result


def test_sqla_source_detection():
    frame = _Frame(variables={})
    result = sqlalchemy_savepoint_code(frame, "from sqlalchemy.orm import Session\nsession.commit()")
    assert "_savepoint_listener" in result


# ---------------------------------------------------------------------------
# race_wrapper_from_locals
# ---------------------------------------------------------------------------

def test_race_none():
    frame = _Frame(variables={})
    assert race_wrapper_from_locals(frame, "") == ""


def test_race_threading_source():
    frame = _Frame(variables={})
    result = race_wrapper_from_locals(frame, "import threading\nt = threading.Thread(target=fn)")
    assert "_slow_wrap" in result
    assert "frontrun" in result


def test_race_asyncio_source():
    frame = _Frame(variables={})
    result = race_wrapper_from_locals(frame, "import asyncio\nasync def handler():\n    await asyncio.gather(a(), b())")
    assert "_slow_wrap" in result


def test_race_lock_local():
    frame = _Frame(variables={"lock": "<Lock object>"})
    result = race_wrapper_from_locals(frame, "")
    assert "_slow_wrap" in result


# ---------------------------------------------------------------------------
# build_supplementary_mock_code (composite)
# ---------------------------------------------------------------------------

def test_composite_empty():
    frame = _Frame(variables={})
    exc = _Exc(last_seen="")
    assert build_supplementary_mock_code(frame, exc, "") == ""


def test_composite_timezone_only():
    frame = _Frame(variables={"amount": 50})
    exc = _Exc(last_seen="2026-01-01T00:00:00Z")
    result = build_supplementary_mock_code(frame, exc, "")
    assert "time_machine" in result


def test_composite_all_detectors():
    frame = _Frame(variables={
        "session": "<Session>",
        "user_id": "7",
        "url": "https://api.stripe.com/charge",
        "response": {"error": {"code": "card_declined", "type": "card_error"}},
    })
    exc = _Exc(last_seen="2026-03-15T14:30:00Z", timezone="UTC")
    source = "import threading\nfrom sqlalchemy.orm import Session\nsession.commit()"
    result = build_supplementary_mock_code(frame, exc, source)
    assert "time_machine" in result
    assert "responses" in result or "_MOCK_BODY" in result
    assert "_savepoint_listener" in result
    assert "sqlalchemy_mock_config" in result
    assert "_slow_wrap" in result
