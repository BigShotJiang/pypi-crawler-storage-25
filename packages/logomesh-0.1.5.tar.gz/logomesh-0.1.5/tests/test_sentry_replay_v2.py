from oracles.sentry_replay_v2 import parse_sandbox_exception_type


def test_parse_sandbox_exception_type_ignores_postgres_detail_lines() -> None:
    output = (
        'E       target.IntegrityError: duplicate key value violates unique constraint "payments_payment_order_id_key"\n'
        'E       DETAIL:  Key (order_id)=(ORD-9182) already exists.\n'
    )
    assert parse_sandbox_exception_type(output) == "target.IntegrityError"


def test_parse_sandbox_exception_type_falls_back_to_failed_summary() -> None:
    output = 'FAILED test_target.py::test_x - ValueError: bad input\n'
    assert parse_sandbox_exception_type(output) == "ValueError"
