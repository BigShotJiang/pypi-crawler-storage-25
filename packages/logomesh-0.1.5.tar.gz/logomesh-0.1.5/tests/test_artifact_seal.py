"""Round-trip regression: PII in synthetic Sentry event must NOT survive
into the sealed evidence artifact, the deterministic test code, the
sandbox output, or the artifact JSON envelope.

This test is the compliance safety-net. If it fails, the SOC2
CC7.3/CC7.4 + PCI DSS 12.10.5 attestation in the artifact preamble is
no longer truthful and the pilot must not ship.
"""

import json

import pytest

from cli.artifact import render_artifact
from oracles.sentry_replay import (
    SentryException,
    SentryFrame,
    fetch_event_by_issue,
    find_innermost_app_frame,
)
from oracles.sentry_replay_v2 import build_replay_test_v2


# Synthetic but production-shaped payload. Every field below is a known
# PII / secret type:
#   - PAN (Luhn-valid, 16 digits — Visa test card)
#   - PAN with separators
#   - Stripe secret key
#   - Stripe webhook signing secret
#   - GitHub personal token
#   - SSN
#   - email
#   - JWT
#   - non-Luhn digit-shaped value under a sensitive field name
PII_FIXTURES = {
    "card_number": "4242424242424242",
    "cvv": "123",
    "ssn_value": "123-45-6789",
    "user_email": "alice@example.com",
    "stripe_key": "sk_live_" + "x" * 24,
    "webhook_secret": "whsec_" + "y" * 24,
    "github_token": "ghp_" + "z" * 36,
    "jwt": (
        "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9"
        ".eyJzdWIiOiIxMjM0NSIsImlhdCI6MTUxNjIzOTAyMn0"
        ".SflKxwRJSMeKKF2QT4fwpMeJf36POk6yJV_adQssw5c"
    ),
    "partial_pan_field": "4111111111114242",   # Luhn-INVALID — relies on field-name scrub
    "pan_with_dashes_in_message_text": "4111-1111-1111-1111",
    "card_last4": "4242",                       # PCI-allowed, must remain intact
    "amount": "-1.0",
    "username": "alice",
}


def _build_synthetic_exception() -> SentryException:
    """Build a SentryException whose innermost frame contains every PII fixture
    above as a frame local. Goes through the parse path so the chokepoint
    fires."""
    raw_event = {
        "dateCreated": "2026-05-07T00:00:00Z",
        "groupID": "synth-1",
        "entries": [{
            "type": "exception",
            "data": {"values": [{
                "type": "ValueError",
                "value": (
                    "amount must be > 0, got -1.0 "
                    "(card_last4=4242, partial_pan=4111111111114242, "
                    "card 4111-1111-1111-1111, ssn=123-45-6789, "
                    "email=alice@example.com)"
                ),
                "stacktrace": {"frames": [{
                    "function": "process_card_payment",
                    "filename": "billing/charge.py",
                    "lineNo": 42,
                    "contextLine": "raise ValueError(...)",
                    "vars": {
                        "card_number": PII_FIXTURES["card_number"],
                        "cvv": PII_FIXTURES["cvv"],
                        "ssn": PII_FIXTURES["ssn_value"],
                        "user_email": PII_FIXTURES["user_email"],
                        "stripe_secret_key": PII_FIXTURES["stripe_key"],
                        "webhook_secret": PII_FIXTURES["webhook_secret"],
                        "github_token": PII_FIXTURES["github_token"],
                        "auth_jwt": PII_FIXTURES["jwt"],
                        "partial_pan": PII_FIXTURES["partial_pan_field"],
                        "card_last4": PII_FIXTURES["card_last4"],
                        "amount": PII_FIXTURES["amount"],
                        "username": PII_FIXTURES["username"],
                    },
                }]},
            }]},
        }],
    }
    return _parse_via_chokepoint(raw_event)


def _parse_via_chokepoint(raw_event: dict) -> SentryException:
    """Round-trip the raw event through the actual parse function so the
    parse-time redaction chokepoint is exercised (this is the property
    under test)."""
    import json as _json
    import os
    from pathlib import Path

    p = Path("/tmp/_logomesh_pii_seal_fixture.json")
    p.write_text(_json.dumps(raw_event))
    os.environ["LOGOMESH_SENTRY_FIXTURE"] = str(p)
    try:
        import asyncio
        return asyncio.run(fetch_event_by_issue("synth-1", org="acme"))
    finally:
        os.environ.pop("LOGOMESH_SENTRY_FIXTURE", None)
        try:
            p.unlink()
        except OSError:
            pass


# Strings that MUST NOT appear anywhere in the sealed bytes / artifact JSON.
RAW_NEEDLES = [
    PII_FIXTURES["card_number"],
    PII_FIXTURES["ssn_value"],
    PII_FIXTURES["user_email"],
    PII_FIXTURES["stripe_key"],
    PII_FIXTURES["webhook_secret"],
    PII_FIXTURES["github_token"],
    PII_FIXTURES["jwt"],
    PII_FIXTURES["partial_pan_field"],
    PII_FIXTURES["pan_with_dashes_in_message_text"],
    "4111111111111111",
    "4242-4242-4242-4242",
]


# Strings that MUST appear (or at least their type marker MUST appear)
# proving redaction took place.
EXPECTED_MARKERS = [
    "[REDACTED:",  # at minimum, *some* type marker is present
]


def _assert_no_raw_pii(blob: str, label: str) -> None:
    for needle in RAW_NEEDLES:
        assert needle not in blob, (
            f"raw PII {needle!r} survived in {label}: ...{blob[max(0, blob.find(needle) - 40):blob.find(needle) + 80]}..."
        )


# ---------------------------------------------------------------------------
# Frame-level: parse-time chokepoint
# ---------------------------------------------------------------------------

def test_parse_time_chokepoint_redacts_frame_variables():
    exc = _build_synthetic_exception()
    frame = find_innermost_app_frame(exc)
    assert frame is not None
    assert frame.function == "process_card_payment"
    blob = json.dumps(frame.variables, default=str)
    _assert_no_raw_pii(blob, "frame.variables")
    # Field-name match should fire on the whole sensitive set
    for k in (
        "card_number", "cvv", "ssn", "user_email",
        "stripe_secret_key", "webhook_secret",
        "github_token", "auth_jwt", "partial_pan",
    ):
        assert frame.variables[k] == "[REDACTED:FIELD]", (
            f"{k!r} not redacted: {frame.variables[k]!r}"
        )
    # PCI-allowed fields stay intact (modulo str-quote normalization)
    assert "4242" in str(frame.variables["card_last4"])
    assert "alice" in str(frame.variables["username"])


def test_all_frames_redacted_not_just_innermost():
    """Parse-time chokepoint runs on every frame, not just innermost.

    Regression guard: an earlier design considered wrapping
    ``find_innermost_app_frame`` instead. Parse-time wrap is broader.
    """
    exc = _build_synthetic_exception()
    for fr in exc.frames:
        blob = json.dumps(fr.variables, default=str)
        _assert_no_raw_pii(blob, f"frame {fr.function}().variables")


# ---------------------------------------------------------------------------
# Test-code level: deterministic synthesizer never emits raw PII
# ---------------------------------------------------------------------------

def test_synthesized_test_code_has_no_raw_pii():
    exc = _build_synthetic_exception()
    frame = find_innermost_app_frame(exc)
    fn_source = (
        "def process_card_payment(card_number, cvv, ssn, user_email,\n"
        "                         stripe_secret_key, webhook_secret,\n"
        "                         github_token, auth_jwt, partial_pan,\n"
        "                         card_last4, amount, username):\n"
        "    raise ValueError('boom')\n"
    )
    test_code = build_replay_test_v2(exc, frame, fn_source)
    assert test_code is not None
    _assert_no_raw_pii(test_code, "test_code")
    assert "[REDACTED:FIELD]" in test_code


# ---------------------------------------------------------------------------
# Artifact level: end-to-end stamping
# ---------------------------------------------------------------------------

def test_render_artifact_strips_pii_from_error_message():
    exc = _build_synthetic_exception()
    frame = find_innermost_app_frame(exc)
    artifact = render_artifact(
        exc, frame,
        result={"total": 1, "failed": 1, "duration": 0.1, "output": ""},
        branch="main", commit="abc123", sandbox_mode="docker",
    )
    serialized = json.dumps(artifact, sort_keys=True)
    _assert_no_raw_pii(serialized, "artifact JSON")
    # Affirmative: the sentry message field went through the scrubber and
    # carries at least one type marker now.
    assert "[REDACTED:" in artifact["incident"]["message"]


def test_artifact_message_keeps_card_last4_and_amount():
    """Repro fidelity check — auditors need to see *what* was scrubbed and
    *what* was kept (PCI-allowed fields like ``card_last4`` should remain
    intact because reading them doesn't violate PCI DSS).
    """
    exc = _build_synthetic_exception()
    frame = find_innermost_app_frame(exc)
    artifact = render_artifact(
        exc, frame,
        result={"total": 1, "failed": 1, "duration": 0.1, "output": ""},
        branch="main", commit="abc123", sandbox_mode="docker",
    )
    msg = artifact["incident"]["message"]
    assert "card_last4=4242" in msg
    assert "amount" in msg


# ---------------------------------------------------------------------------
# Sandbox output level: defense-in-depth scrub
# ---------------------------------------------------------------------------

def test_sandbox_output_scrubbed_in_parse_result():
    """The sandbox's ``_parse_result`` chokepoint must scrub PII out of
    pytest stdout/stderr before returning.

    Simulated by building a bogus pytest output containing PII directly,
    then calling _parse_result via Sandbox(). We don't actually run pytest
    here — we exercise the parse function on a string that mimics what
    pytest would emit.
    """
    from business_logic.sandbox import Sandbox
    fake_pytest_output = (
        "============================== test session starts ==============================\n"
        "FAILED test_target.py::test_replay - ValueError: card 4111111111111111 declined\n"
        "E   ValueError: rejected card_number=4242424242424242 ssn=123-45-6789\n"
        "E   email leaked: alice@example.com\n"
        "E   token: sk_live_xxxxxxxxxxxxxxxxxxxxxxxxx\n"
        "============================== 1 failed in 0.01s ===============================\n"
    )
    sb = Sandbox.__new__(Sandbox)  # bypass __init__ (no Docker probe)
    parsed = sb._parse_result(success=False, output=fake_pytest_output, duration=0.1)
    out = parsed["output"]
    _assert_no_raw_pii(out, "Sandbox._parse_result output")
    assert "[REDACTED:" in out


# ---------------------------------------------------------------------------
# Evidence-path seal: hash is computed over redacted bytes
# ---------------------------------------------------------------------------

def test_evidence_seal_hash_is_over_redacted_bytes():
    """The hash that auditors use to verify the sealed test must be a hash
    of the redacted bytes — not raw bytes. Otherwise, an auditor with
    knowledge of the PII pattern could brute-force the pre-image.

    We assert this by computing the hash, then re-running redaction on
    the input that produced it, and verifying the hash hasn't changed
    (idempotency proves redaction was already applied at hash time).
    """
    import hashlib
    exc = _build_synthetic_exception()
    frame = find_innermost_app_frame(exc)
    fn_source = "def process_card_payment(**kw): pass\n"
    test_code = build_replay_test_v2(exc, frame, fn_source)
    h1 = hashlib.sha256(test_code.encode()).hexdigest()[:16]
    # Re-run a synthesizer pass: same exc/frame (already redacted), same
    # fn_source → same bytes → same hash. Confirms determinism.
    test_code_2 = build_replay_test_v2(exc, frame, fn_source)
    h2 = hashlib.sha256(test_code_2.encode()).hexdigest()[:16]
    assert h1 == h2
    # Confirm the test_code itself is PII-free
    _assert_no_raw_pii(test_code, "evidence-sealed test_code")
