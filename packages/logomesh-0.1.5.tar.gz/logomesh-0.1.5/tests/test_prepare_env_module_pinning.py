"""Tests for `_tool_prepare_environment` accepting `module_versions` (PR2 part B).

The orchestrator's prepare_environment now optionally overrides
manifest-declared dependency versions with the exact prod pip-freeze
captured by Sentry (`exc.modules`). This closes the prod-vs-dev drift
gap that otherwise lets sandbox repros pass while prod still crashes.

We mock the snapshot builder so we can inspect the synthesized
pyproject string (which contains the final spec list) without
spinning up Docker. The synthesizer's input here is the
ground-truth-equivalent: when those bytes get to the wheel-building
step, that's the version set the sandbox will install.
"""

from __future__ import annotations

import asyncio
import json
import sys
from pathlib import Path
from unittest import mock

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))
sys.path.insert(0, str(_REPO_ROOT / "src"))

import logomesh_orchestrator as o  # noqa: E402


def _write_manifest(tmp_path: Path, deps: list[str]) -> None:
    text = '[project]\nname = "x"\nversion = "0"\n'
    text += "dependencies = [\n"
    for d in deps:
        text += f'  "{d}",\n'
    text += "]\n"
    (tmp_path / "pyproject.toml").write_text(text)


def _run(*, tmp_path, module_versions, sandbox_error="", sid="sess-mod-pin"):
    """Call the tool; capture the synthesized pyproject sent to prepare_snapshot."""
    captured: dict = {"pyproject": ""}

    def _fake_prepare_snapshot(files, include_prior_pin=False):
        captured["pyproject"] = files.get("pyproject.toml", "")
        return "/tmp/fake_snapshot"

    o._AUDIT_REGISTRY[sid] = o.AuditSession(sid)
    try:
        with mock.patch(
            "business_logic.sandbox.dep_installer.prepare_snapshot",
            side_effect=_fake_prepare_snapshot,
        ), mock.patch(
            "business_logic.sandbox.dep_installer.fetch_latest_pypi_version",
            return_value="9.9.9",
        ):
            raw = asyncio.run(o._tool_prepare_environment(
                session_id=sid,
                repo_path=str(tmp_path),
                sandbox_error=sandbox_error,
                module_versions=module_versions,
            ))
        return captured["pyproject"], json.loads(raw)
    finally:
        o._AUDIT_REGISTRY.pop(sid, None)
        o._ENV_REGISTRY.pop(sid, None)


def test_no_module_versions_keeps_manifest_specs(tmp_path):
    _write_manifest(tmp_path, ["django>=5.0", "celery>=5.4", "stripe"])
    pyproject, out = _run(tmp_path=tmp_path, module_versions={})
    assert "django>=5.0" in pyproject
    assert "celery>=5.4" in pyproject
    assert "stripe" in pyproject
    assert out["pinned_from_sentry_modules"] == 0


def test_module_versions_pin_manifest_deps(tmp_path):
    _write_manifest(tmp_path, ["django>=5.0", "celery>=5.4", "stripe"])
    pyproject, out = _run(
        tmp_path=tmp_path,
        module_versions={
            "django": "5.0.4",
            "celery": "5.4.0",
            "stripe": "11.2.1",
            "unrelated": "1.2.3",  # not in manifest, not in stderr — should NOT appear
        },
    )
    assert "django==5.0.4" in pyproject
    assert "celery==5.4.0" in pyproject
    assert "stripe==11.2.1" in pyproject
    assert "django>=5.0" not in pyproject
    assert "celery>=5.4" not in pyproject
    assert out["pinned_from_sentry_modules"] == 3
    assert "unrelated" not in pyproject


def test_module_versions_pin_extras_from_stderr(tmp_path):
    _write_manifest(tmp_path, ["django"])
    stderr = "E   ModuleNotFoundError: No module named 'redis'\n"
    pyproject, out = _run(
        tmp_path=tmp_path,
        module_versions={"redis": "5.0.1"},
        sandbox_error=stderr,
    )
    assert "redis==5.0.1" in pyproject
    # Should NOT fall back to PyPI's "latest" version when we have a pin
    assert "redis==9.9.9" not in pyproject
    assert out["pinned_from_sentry_modules"] >= 1


def test_module_versions_case_insensitive_match(tmp_path):
    _write_manifest(tmp_path, ["django>=5.0", "celery>=5.4"])
    pyproject, out = _run(
        tmp_path=tmp_path,
        module_versions={"Django": "5.0.4", "CELERY": "5.4.0"},
    )
    assert "django==5.0.4" in pyproject
    assert "celery==5.4.0" in pyproject
    assert out["pinned_from_sentry_modules"] == 2


def test_empty_or_blank_module_versions_skip_pinning(tmp_path):
    _write_manifest(tmp_path, ["django>=5.0", "celery>=5.4"])
    pyproject, out = _run(
        tmp_path=tmp_path,
        module_versions={"django": "", "celery": "  "},
    )
    # Original specs preserved
    assert "django>=5.0" in pyproject
    assert "celery>=5.4" in pyproject
    assert out["pinned_from_sentry_modules"] == 0


def test_pinned_count_in_env_registry(tmp_path):
    _write_manifest(tmp_path, ["django>=5.0"])
    _run(tmp_path=tmp_path, module_versions={"django": "5.0.4"}, sid="sess-reg")
    # Re-registered for the next call — pinned_count survives to env state
    # for downstream artifact stamping
    # (We popped the registry in `_run` finally, so just assert the JSON path
    # exposed it.)
