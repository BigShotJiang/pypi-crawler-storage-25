"""Circuit breaker + LOGOMESH_DISABLED kill switch."""

from __future__ import annotations

import os

import pytest

from capture import ring_buffer, safety


@pytest.fixture(autouse=True)
def _reset_safety():
    safety.reset_for_tests()
    # Drop any lingering env override.
    os.environ.pop("LOGOMESH_DISABLED", None)
    yield
    safety.reset_for_tests()
    os.environ.pop("LOGOMESH_DISABLED", None)


def test_breaker_trips_after_n_consecutive_failures():
    hook = "test.hook.a"
    assert safety.is_hook_enabled(hook)
    for i in range(safety.DEFAULT_FAILURE_THRESHOLD - 1):
        tripped = safety.record_failure(hook)
        assert tripped is False, f"premature trip at i={i}"
        assert safety.is_hook_enabled(hook)
    # The Nth failure trips the breaker.
    tripped = safety.record_failure(hook)
    assert tripped is True
    assert not safety.is_hook_enabled(hook)


def test_breaker_resets_on_success_before_threshold():
    hook = "test.hook.b"
    for _ in range(safety.DEFAULT_FAILURE_THRESHOLD - 1):
        safety.record_failure(hook)
    safety.record_success(hook)
    # Counter cleared — must take another full N failures to trip.
    for _ in range(safety.DEFAULT_FAILURE_THRESHOLD - 1):
        safety.record_failure(hook)
    assert safety.is_hook_enabled(hook)


def test_global_kill_switch_disables_every_hook_and_record():
    hook = "test.hook.c"
    os.environ["LOGOMESH_DISABLED"] = "1"
    assert not safety.is_globally_enabled()
    assert not safety.is_hook_enabled(hook)
    # ring_buffer.record must be a no-op while disabled.
    ring_buffer.drain()
    ring_buffer.record({"type": "db", "sql": "x"})
    assert ring_buffer.drain() == []


def test_global_kill_switch_recognizes_truthy_variants():
    for v in ("1", "true", "TRUE", "yes", "on"):
        os.environ["LOGOMESH_DISABLED"] = v
        assert not safety.is_globally_enabled(), f"failed for {v!r}"
    for v in ("0", "false", "no", "", "off"):
        os.environ["LOGOMESH_DISABLED"] = v
        assert safety.is_globally_enabled(), f"failed for {v!r}"


def test_install_short_circuits_when_disabled():
    """install() must not import or wire up any hook when the kill switch is
    on, so a production rollout flag flip is a clean no-op."""
    os.environ["LOGOMESH_DISABLED"] = "1"
    import capture
    # Should not raise and should not modify _INSTALLED in a way that locks
    # out a later enabled install.
    capture.install()
