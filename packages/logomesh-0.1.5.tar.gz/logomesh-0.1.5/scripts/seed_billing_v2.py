"""Seed 5 realistic billing crashes into Sentry for the logomesh repro demo.

Each function in examples/fintech_billing/billing_v2.py contains a real
production bug sourced from a public GitHub issue. This script triggers
all five crashes, captures them with sentry-sdk, and prints the resulting
issue URLs.

Usage (Path 1 — real Sentry project):
    export SENTRY_DSN='https://<key>@oXXXX.ingest.sentry.io/<project>'
    uv run python scripts/seed_billing_v2.py

    Then copy any issue URL from Sentry and run:
    export SENTRY_AUTH_TOKEN=<user-auth-token-with-event:read>
    uv run logomesh repro '<issue-url>'

Usage (Path 2 — offline, no Sentry account needed):
    SENTRY_AUTH_TOKEN=stub LOGOMESH_SENTRY_FIXTURE=tests/fixtures/bv2_s2_payment_reconciliation.json \
        uv run logomesh repro 'https://sentry.io/issues/20002/'

Sources:
  S1 frappe/erpnext #37813  — TypeError float += NoneType
  S2 frappe/erpnext #42202  — TypeError NoneType + list
  S3 saleor/saleor PR#15950 — ZeroDivisionError
  S4 frappe/erpnext #28768  — TypeError NoneType not subscriptable
  S5 saleor/saleor #16273   — decimal.InvalidOperation
"""

from __future__ import annotations

import os
import sys
import traceback
from decimal import Decimal
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from examples.fintech_billing.billing_v2 import (  # noqa: E402
    get_nonreconciled_payment_entries,
    get_regional_address_details,
    parse_webhook_amount,
    propagate_order_discount_to_lines,
    set_print_format_fields,
)

SCENARIOS: list[tuple[str, str, object]] = [
    # (name, source_url, callable_that_crashes)
    (
        "S1 exchange_gain_loss (erpnext #37813)",
        "https://github.com/frappe/erpnext/issues/37813",
        lambda: set_print_format_fields([
            {
                "account_type": "Bank",
                "debit_in_account_currency": 1_066_824.37,
                "credit_in_account_currency": 0.0,
                "account": "2120-05 BILL OF EXCHANGE",
                "party": "ACME Corp",
            },
            {
                "account_type": "Bank",
                "debit_in_account_currency": None,
                "credit_in_account_currency": None,
                "account": "4200-04 GAIN (LOSS) ON EXCHANGE RATE",
                "party": None,
            },
        ]),
    ),
    (
        "S2 payment_reconciliation (erpnext #42202)",
        "https://github.com/frappe/erpnext/issues/42202",
        lambda: get_nonreconciled_payment_entries(
            party_type="Supplier",
            party="Anil Mandi",
            receivable_payable_account="2000 - Creditors - TC",
            payment_entries=None,
            journal_entries=[],
            dr_or_cr_notes=[],
        ),
    ),
    (
        "S3 order_discount_zero_subtotal (saleor PR#15950)",
        "https://github.com/saleor/saleor/pull/15950",
        lambda: propagate_order_discount_to_lines(
            order_discount_amount=Decimal("10.00"),
            lines=[
                {"line_id": "line-A", "undiscounted_total": "0.00", "quantity": 2},
                {"line_id": "line-B", "undiscounted_total": "0.00", "quantity": 1},
            ],
        ),
    ),
    (
        "S4 gstin_none_subscript (erpnext #28768)",
        "https://github.com/frappe/erpnext/issues/28768",
        lambda: get_regional_address_details(
            company_gstin=None,
            party_gstin="27AAPFU0939F1ZV",
            master_doctype="Sales Invoice",
            company="Goyal Group",
            tax_categories=["intra-state", "inter-state"],
        ),
    ),
    (
        "S5 parse_webhook_amount (Stripe webhook pattern)",
        "https://stripe.com/docs/webhooks",
        lambda: parse_webhook_amount("149.99"),
    ),
]


def _try_import_sentry() -> object | None:
    try:
        import sentry_sdk
        return sentry_sdk
    except ImportError:
        return None


def main() -> int:
    dsn = os.environ.get("SENTRY_DSN", "").strip()
    sentry = _try_import_sentry()

    if dsn and sentry:
        sentry.init(
            dsn=dsn,
            send_default_pii=True,
            include_local_variables=True,
            traces_sample_rate=0.0,
            release="billing-v2-demo",
            environment="demo",
        )
        print(f"Sentry initialised — DSN set, sending {len(SCENARIOS)} events...\n")
    else:
        if not dsn:
            print("SENTRY_DSN not set — running in dry-run mode (no events sent).")
            print("Set SENTRY_DSN to send real events to Sentry.\n")
        if not sentry:
            print("sentry-sdk not installed — pip install 'sentry-sdk>=2'\n")

    for name, source, fn in SCENARIOS:
        print(f"  [{name}]")
        print(f"   source: {source}")
        try:
            fn()
            print("   UNEXPECTED: no exception raised — bug may be fixed\n")
        except Exception as exc:
            print(f"   crashed: {type(exc).__name__}: {exc}")
            if dsn and sentry:
                sentry.capture_exception()
                print("   → sent to Sentry")
            print()

    if dsn and sentry:
        sentry.flush(timeout=10)
        print(
            "\nAll events flushed.\n"
            "Open Sentry, copy any issue URL, then run:\n"
            "  export SENTRY_AUTH_TOKEN=<token-with-event:read>\n"
            "  uv run logomesh repro '<issue-url>'\n"
        )
    else:
        print(
            "\nOffline mode — use fixture files instead:\n"
            "  SENTRY_AUTH_TOKEN=stub LOGOMESH_SENTRY_FIXTURE=tests/fixtures/bv2_s2_payment_reconciliation.json \\\n"
            "    uv run logomesh repro 'https://sentry.io/issues/20002/'\n"
        )

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
