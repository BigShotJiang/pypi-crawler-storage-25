"""End-to-end honest-hit-rate measurement.

Runs all checked-in synthetic fixtures (v3 + v4 + v5) through the
orchestrator, categorizes each by crash type, and emits a per-category
hit-rate breakdown. Used as the source of synthetic numbers in
`docs/honest_hit_rates.md`. Buyers can re-run this themselves and
audit the math.

  uv run python scripts/honest_hit_rates.py

Outputs:
  docs/run_results/honest_hit_rates_{date}.md
  docs/run_results/honest_hit_rates_{date}.json

The categorization table below is **hand-curated**: each fixture is
tagged with the bucket a real-world fintech buyer would care about.
We deliberately do not auto-infer category from exception class
(IntegrityError shows up across "external-API", "DB-consistency", and
"idempotency" depending on the call site).
"""
from __future__ import annotations

import asyncio
import json
import os
import sys
import time
from pathlib import Path

_REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(_REPO_ROOT))
sys.path.insert(0, str(_REPO_ROOT / "src"))

# Smoke isolation — orchestrator's draft-PR step would otherwise mutate
# the repo. Point repo_path at a non-git tmp dir so PR creation fails
# cleanly and the working tree stays put.
_SMOKE_DATA = Path(os.environ.get(
    "LOGOMESH_SMOKE_DATA_DIR", "/tmp/logomesh_smoke_data",
)).resolve()

OUT_DIR = _REPO_ROOT / "docs" / "run_results"
OUT_DIR.mkdir(parents=True, exist_ok=True)
DATE = time.strftime("%Y-%m-%d")
OUT_MD = OUT_DIR / f"honest_hit_rates_{DATE}.md"
OUT_JSON = OUT_DIR / f"honest_hit_rates_{DATE}.json"


# ---------------------------------------------------------------------------
# Categorization — bucket each fixture by the crash class a buyer cares about.
# ---------------------------------------------------------------------------
#
# Buckets:
#   input_validation   — ValueError/TypeError/AttributeError on primitive args.
#                        The synthesizer's sweet spot.
#   domain_exception   — Custom subclass thrown by business logic.
#                        Reproducible iff the path is pure-Python from
#                        primitive inputs.
#   external_api       — Third-party SDK fails (Stripe, Plaid, Redis).
#                        Often C-extension or network-dependent — hard.
#   db_consistency     — StaleDataError / IntegrityError / lock issues.
#                        Often depends on prior DB row state.
#   async_concurrency  — Race conditions, asyncio task graph crashes.
#                        Often non-deterministic to reproduce.
#   c_extension        — Crashes in compiled extension code; sandbox can't
#                        faithfully replay.
#
# Non-trivial choices:
#   - v3_05 stripe C-ext goes in `c_extension`, not `external_api`.
#   - v3_06 db pool exhaustion is `async_concurrency` (concurrent acquires)
#     not `db_consistency` (no row state involved).
#   - v3_08 webhook IntegrityError is `db_consistency` (real cause is
#     a DB unique-constraint violation), not external_api.
#   - v3_10 redis lock missing is `async_concurrency`, not `external_api`,
#     because the bug is the missing lock, not Redis itself failing.
#
# Buyer reading the doc should be able to challenge any of these.

CATEGORY: dict[str, str] = {
    # v3
    "v3_01_celery_refund_stale_db":   "db_consistency",
    "v3_02_balance_debit_race":       "async_concurrency",
    "v3_03_dep_version_conflict":     "input_validation",
    "v3_04_tz_naive_datetime":        "input_validation",
    "v3_05_stripe_c_ext_crash":       "c_extension",
    "v3_06_db_pool_exhaustion":       "async_concurrency",
    "v3_07_tax_rule_drift":           "domain_exception",
    "v3_08_webhook_idempotency":      "db_consistency",
    "v3_09_pii_in_locals":            "input_validation",
    "v3_10_redis_lock_missing":       "async_concurrency",
    # v4
    "v4_01_stripe_webhook_dup":       "db_consistency",
    "v4_02_stale_data_celery":        "db_consistency",
    "v4_03_async_lost_update":        "async_concurrency",
    "v4_04_tenacity_lock_wait":       "async_concurrency",
    "v4_05_pm_doesnotexist":          "async_concurrency",
    # v5
    "v5_01_rtp_payment_timeout":      "external_api",
    "v5_02_processor_ransomware":     "external_api",
    "v5_03_fraud_model_drift":        "domain_exception",
    "v5_04_stablecoin_reconciliation": "domain_exception",
    "v5_05_consent_token_expired":    "domain_exception",
    "v5_06_mobile_confirm_crash":     "input_validation",
    "v5_07_sponsor_bank_ratelimit":   "external_api",
    "v5_08_agent_authorization":      "domain_exception",
}


def _force_gpt5mini_env() -> None:
    os.environ["LOGOMESH_LLM_PROVIDER"] = "openai"
    os.environ.pop("LOGOMESH_LLM_BASE_URL", None)
    os.environ["LOGOMESH_ORCHESTRATOR_MODEL"] = "gpt-5-mini"
    os.environ["LOGOMESH_REPRO_MODEL"] = "gpt-5-mini"
    if "OPENAI_API_KEY" not in os.environ:
        try:
            from dotenv import load_dotenv
            load_dotenv(_REPO_ROOT / ".env")
        except Exception:
            pass
    if not os.environ.get("OPENAI_API_KEY", "").strip():
        print("OPENAI_API_KEY not set", file=sys.stderr)
        sys.exit(2)


def _load_indexes() -> list[dict]:
    out: list[dict] = []
    for name in ("v3_index.json", "v4_index.json", "v5_index.json"):
        p = _SMOKE_DATA / "tests" / "fixtures" / name
        if p.exists():
            out.extend(json.loads(p.read_text()))
    return out


async def _run_one(rec: dict) -> dict:
    fixture = _SMOKE_DATA / rec["fixture_path"]
    os.environ["LOGOMESH_SENTRY_FIXTURE"] = str(fixture)

    import logomesh_orchestrator as o  # type: ignore

    # Disable draft-PR creation across every callsite. This includes:
    #   - finalizer_node's direct call to o._tool_create_draft_pr
    #   - supervisor → LangGraph StructuredTool, which captured the
    #     original function by reference at module-load time
    # We patch the underlying cli.draft_pr.create_draft_pr (the lowest
    # layer) AND the orchestrator's _tool_create_draft_pr alias so neither
    # path can side-effect the active git branch in this repo. Without
    # this, every successful repro causes the orchestrator to checkout
    # a fresh `logomesh/repro-*` branch — and once that happens, the
    # next fixture lands in a worktree missing examples/, blowing up
    # source resolution for the rest of the run.
    def _no_pr_sync(*_a, **_kw):
        return ""
    async def _no_pr_async(*_a, **_kw):
        import json as _j
        return _j.dumps({"skipped": True, "reason": "honest_hit_rates: PR disabled"})
    import cli.draft_pr as _draft_mod  # type: ignore
    _draft_mod.create_draft_pr = _no_pr_sync  # type: ignore
    o._create_draft_pr = _no_pr_sync  # type: ignore  # alias inside orchestrator
    o._tool_create_draft_pr = _no_pr_async  # type: ignore

    event = {
        "id": rec["issue_id"],
        "organization": {"slug": "honest"},
        "repo_path": str(_SMOKE_DATA),
    }
    t0 = time.time()
    try:
        result = await o.handle_sentry_webhook(event)
    except Exception as e:
        return {
            "id": rec["id"], "category": CATEGORY.get(rec["id"], "uncategorized"),
            "title": rec["title"], "expected_exc": rec["exc"],
            "status": "error", "error": f"{type(e).__name__}: {e}",
            "duration_s": round(time.time() - t0, 2),
            "verified": False, "review_reason": "",
        }
    artifact = result.get("artifact") or {}
    seal = artifact.get("evidence_path_seal") or {}
    return {
        "id": rec["id"],
        "category": CATEGORY.get(rec["id"], "uncategorized"),
        "title": rec["title"],
        "expected_exc": rec["exc"],
        "status": result.get("status"),
        "verified": bool(seal.get("verified_exception_match")),
        "sandbox_exc": seal.get("sandbox_exception_type"),
        "test_sha": seal.get("test_sha256_first16"),
        "llm_in_evidence_path": seal.get("llm_in_evidence_path"),
        "duration_s": result.get("duration_s") or round(time.time() - t0, 2),
        "review_reason": (result.get("human_review_reason") or "")[:200],
        "cost_usd": (result.get("usage") or {}).get("cost_usd"),
    }


def _per_category(rows: list[dict]) -> dict[str, dict]:
    out: dict[str, dict] = {}
    for r in rows:
        cat = r["category"]
        b = out.setdefault(cat, {
            "total": 0, "verified": 0, "review": 0, "errored": 0,
            "ids": [],
        })
        b["total"] += 1
        b["ids"].append(r["id"])
        if r.get("status") == "error":
            b["errored"] += 1
        elif r.get("verified"):
            b["verified"] += 1
        else:
            b["review"] += 1
    for b in out.values():
        b["hit_rate_pct"] = round(100.0 * b["verified"] / max(b["total"], 1), 1)
    return out


def _refusal_taxonomy(rows: list[dict]) -> dict[str, int]:
    """Count how often each structured refusal reason fired."""
    counts: dict[str, int] = {}
    for r in rows:
        if r.get("verified"):
            continue
        reason = (r.get("review_reason") or r.get("error") or "uncategorized").split(":", 1)[0].strip()
        counts[reason] = counts.get(reason, 0) + 1
    return counts


async def main() -> int:
    _force_gpt5mini_env()
    records = _load_indexes()
    if not records:
        print("no fixtures found", file=sys.stderr)
        return 2

    uncategorized = [r["id"] for r in records if r["id"] not in CATEGORY]
    if uncategorized:
        print(f"warning: {len(uncategorized)} uncategorized fixtures: {uncategorized}",
              file=sys.stderr)

    print(f"honest hit-rate run: {len(records)} fixtures × gpt-5-mini\n", flush=True)

    rows: list[dict] = []
    for i, rec in enumerate(records, 1):
        category = CATEGORY.get(rec["id"], "uncategorized")
        print(f"[{i:2d}/{len(records)}] {rec['id']:42}  [{category}] ...", flush=True)
        r = await _run_one(rec)
        rows.append(r)
        mark = "✓" if r.get("verified") else ("⚠" if r.get("status") == "human_review" else "✗")
        print(f"     {mark} {r.get('status'):14} sandbox={r.get('sandbox_exc') or '—':32} "
              f"sec={r.get('duration_s')}", flush=True)

    # Aggregate
    summary = {
        "total":              len(rows),
        "verified":           sum(1 for r in rows if r.get("verified")),
        "human_review":       sum(1 for r in rows if r.get("status") == "human_review"),
        "errored":            sum(1 for r in rows if r.get("status") == "error"),
        "avg_sec":            round(sum(r.get("duration_s") or 0.0 for r in rows) / max(len(rows), 1), 2),
        "total_cost_usd":     round(sum((r.get("cost_usd") or 0.0) for r in rows), 4),
        "seal_clean":         all(r.get("llm_in_evidence_path") is False for r in rows
                                   if r.get("status") != "error"),
    }
    summary["overall_hit_rate_pct"] = round(100.0 * summary["verified"] / summary["total"], 1)
    per_cat = _per_category(rows)
    refusal_counts = _refusal_taxonomy(rows)

    # Markdown
    md = (
        f"# Honest hit-rate measurement — {DATE}\n\n"
        f"_Model: gpt-5-mini (LOGOMESH_LLM_PROVIDER=openai)_  \n"
        f"_Fixtures: v3 + v4 + v5 = {summary['total']}_  \n"
        f"_Methodology: synthetic fixtures only — see "
        f"`docs/honest_hit_rates.md` for the caveat language we publish_  \n\n"
        "## Headline\n\n"
        f"- Overall verified ship rate: **{summary['verified']}/{summary['total']} "
        f"({summary['overall_hit_rate_pct']}%)**\n"
        f"- Honest human-review: {summary['human_review']}/{summary['total']}\n"
        f"- Errored: {summary['errored']}/{summary['total']}\n"
        f"- Average wall-clock per fixture: {summary['avg_sec']}s\n"
        f"- Total LLM cost across the run: ${summary['total_cost_usd']:.4f}\n"
        f"- Seal clean (no LLM in evidence path): **{summary['seal_clean']}**\n\n"
        "## Per-category breakdown\n\n"
        "Categories are hand-curated — see `scripts/honest_hit_rates.py::CATEGORY`.\n\n"
        "| Category | Total | Verified | Hit-rate | Reviewed | Errored |\n"
        "|---|---:|---:|---:|---:|---:|\n"
    )
    for cat, b in sorted(per_cat.items(), key=lambda kv: (-kv[1]["hit_rate_pct"], kv[0])):
        md += (f"| `{cat}` | {b['total']} | {b['verified']} | "
               f"**{b['hit_rate_pct']}%** | {b['review']} | {b['errored']} |\n")

    md += "\n## Refusal taxonomy (this run)\n\n"
    if refusal_counts:
        md += "| Reason prefix | Count |\n|---|---:|\n"
        for k, v in sorted(refusal_counts.items(), key=lambda kv: -kv[1]):
            md += f"| `{k[:120]}` | {v} |\n"
    else:
        md += "_No refusals — all fixtures verified._\n"

    md += "\n## Per-fixture\n\n"
    md += "| # | id | category | expected | sandbox | result | sec |\n"
    md += "|---|---|---|---|---|---|---:|\n"
    for i, r in enumerate(rows, 1):
        result = "✓ shipped" if r.get("verified") else ("⚠ review" if r.get("status") == "human_review" else "✗ error")
        md += (f"| {i} | `{r['id']}` | `{r['category']}` | "
               f"`{r.get('expected_exc','')}` | `{r.get('sandbox_exc') or '—'}` | "
               f"{result} | {r.get('duration_s')} |\n")

    md += "\n## What this is NOT\n\n"
    md += (
        "These are **synthetic fixtures** designed to crash deterministically "
        "from primitive frame locals. They establish the synthesizer's ceiling "
        "on its sweet-spot input distribution; they do not measure real-world "
        "hit rate against arbitrary customer Sentry orgs. Per-category numbers "
        "should be read as 'how does the synthesizer perform on representative "
        "examples of this bug class' — not 'what your team's first month will "
        "look like.' Real-world numbers will be published per design partner "
        "after ≥2 weeks on their actual feed.\n"
    )

    OUT_MD.write_text(md)
    OUT_JSON.write_text(json.dumps({
        "date": DATE,
        "summary": summary,
        "per_category": per_cat,
        "refusal_counts": refusal_counts,
        "rows": rows,
    }, indent=2, default=str))
    print(f"\nwrote {OUT_MD.relative_to(_REPO_ROOT)}")
    print(f"wrote {OUT_JSON.relative_to(_REPO_ROOT)}")
    return 0 if summary["errored"] == 0 else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(main()))
