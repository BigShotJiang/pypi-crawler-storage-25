#!/usr/bin/env python3
"""Golden regression suite for fintech-payments-demo + full orchestrator.

Runs 3 hard crash cases end-to-end:
  1. integrity_race
  2. stale_race
  3. fk_violation

Flow per case:
  - trigger management command inside docker-compose web service
  - feed fixture Sentry event into full handle_sentry_webhook orchestrator
  - collect metrics and compliance checks
"""

from __future__ import annotations

import argparse
import asyncio
import json
import os
import subprocess
import sys
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Any

REPO_ROOT = Path(__file__).resolve().parents[1]
DEMO_ROOT = REPO_ROOT / "fintech-payments-demo"

# Import orchestrator from workspace root.
if str(REPO_ROOT) not in sys.path:
    sys.path.insert(0, str(REPO_ROOT))

from logomesh_orchestrator import handle_sentry_webhook  # noqa: E402


@dataclass(frozen=True)
class HardCase:
    name: str
    mgmt_case: str
    issue_id: str
    fixture: Path


HARD_CASES: tuple[HardCase, ...] = (
    HardCase(
        name="integrity_race",
        mgmt_case="integrity_race",
        issue_id="7470722069",
        fixture=DEMO_ROOT / "fixtures" / "sentry_hard_integrity_race.json",
    ),
    HardCase(
        name="stale_race",
        mgmt_case="stale_race",
        issue_id="7470722082",
        fixture=DEMO_ROOT / "fixtures" / "sentry_hard_stale_data.json",
    ),
    HardCase(
        name="fk_violation",
        mgmt_case="fk_violation",
        issue_id="7470722083",
        fixture=DEMO_ROOT / "fixtures" / "sentry_hard_fk_violation.json",
    ),
)


def sh(cmd: list[str], *, cwd: Path | None = None, env: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    return subprocess.run(cmd, cwd=str(cwd) if cwd else None, env=env, capture_output=True, text=True, check=False)


def ensure_env_file() -> None:
    env_file = DEMO_ROOT / ".env"
    if env_file.exists():
        return
    src = DEMO_ROOT / ".env.example"
    env_file.write_text(src.read_text())


def compose_up(build: bool) -> None:
    cmd = ["docker", "compose", "up", "-d", "--wait", "--wait-timeout", "120"]
    if build:
        cmd.append("--build")
    proc = sh(cmd, cwd=DEMO_ROOT)
    if proc.returncode != 0:
        raise RuntimeError(f"docker compose up failed:\n{proc.stdout}\n{proc.stderr}")


def compose_down() -> None:
    sh(["docker", "compose", "down", "-v"], cwd=DEMO_ROOT)


def trigger_case(case: HardCase) -> dict[str, Any]:
    proc = sh(
        ["docker", "compose", "exec", "-T", "web", "python", "manage.py", "trigger_hard_cases", case.mgmt_case],
        cwd=DEMO_ROOT,
    )
    return {
        "returncode": proc.returncode,
        "stdout": proc.stdout,
        "stderr": proc.stderr,
    }


def advisory_call_count(audit: dict[str, Any]) -> int:
    calls = 0
    for ev in audit.get("events", []):
        if ev.get("event") == "llm_call":
            intent = str(ev.get("intent", "")).lower()
            if any(k in intent for k in ("web_search", "rag_search", "critic", "context reconstruction", "hypothesis", "prepare_environment", "dep")):
                calls += 1
        if ev.get("event") == "dep_resolution":
            calls += 1
    return calls


def count_event_type(audit: dict[str, Any], event_type: str) -> int:
    timeline = (audit.get("timeline") or {}).get("events") or []
    return sum(1 for ev in timeline if ev.get("type") == event_type)


def compliance_ok(result: dict[str, Any]) -> tuple[bool, list[str]]:
    errors: list[str] = []
    artifact = result.get("artifact") or {}
    seal = artifact.get("evidence_path_seal") or {}

    if not artifact:
        errors.append("artifact missing")
    if not seal.get("sealed", False):
        errors.append("evidence_path_seal.sealed != true")
    if seal.get("llm_in_evidence_path", True):
        errors.append("llm_in_evidence_path is not false")
    if seal.get("verified_exception_match") is not True:
        errors.append("verified_exception_match != true")

    return (len(errors) == 0, errors)


async def run_case(case: HardCase, repo_path: str) -> dict[str, Any]:
    trigger = trigger_case(case)

    env = dict(os.environ)
    env["LOGOMESH_SENTRY_FIXTURE"] = str(case.fixture)

    t0 = time.time()
    # handle_sentry_webhook reads env vars dynamically during fetch step.
    old_fixture = os.environ.get("LOGOMESH_SENTRY_FIXTURE", "")
    os.environ["LOGOMESH_SENTRY_FIXTURE"] = str(case.fixture)
    try:
        result = await handle_sentry_webhook(
            {
                "id": case.issue_id,
                "organization": {"slug": "fintech-demo"},
                "repo_path": repo_path,
            }
        )
    finally:
        if old_fixture:
            os.environ["LOGOMESH_SENTRY_FIXTURE"] = old_fixture
        else:
            os.environ.pop("LOGOMESH_SENTRY_FIXTURE", None)

    wall = round(time.time() - t0, 2)
    audit = result.get("audit") or {}
    usage = result.get("usage") or {}

    ok, compliance_errors = compliance_ok(result)

    return {
        "case": case.name,
        "issue_id": case.issue_id,
        "trigger": trigger,
        "status": result.get("status"),
        "needs_human_review": bool(result.get("needs_human_review")),
        "human_review_reason": result.get("human_review_reason", ""),
        "advisory_tool_calls": advisory_call_count(audit),
        "self_refusal_source_resolution_fired": count_event_type(audit, "tool_stop") > 0 and any(
            ev.get("payload", {}).get("stop_reason") in {"source_not_found_retryable", "source_not_found_retry_exhausted"}
            for ev in (audit.get("timeline") or {}).get("events", [])
            if ev.get("type") == "tool_stop"
        ),
        "token_usage": usage,
        "wall_time_s": wall,
        "orchestrator_duration_s": result.get("duration_s"),
        "compliance_contract_ok": ok,
        "compliance_errors": compliance_errors,
        "verified_exception_match": ((result.get("artifact") or {}).get("evidence_path_seal") or {}).get("verified_exception_match"),
        "audit_event_count": audit.get("event_count", 0),
    }


async def main() -> int:
    parser = argparse.ArgumentParser(description="Run full orchestrator hard-case suite")
    parser.add_argument("--repo-path", default=str(DEMO_ROOT), help="Repo path passed to orchestrator")
    parser.add_argument("--skip-compose", action="store_true")
    parser.add_argument("--no-build", action="store_true")
    parser.add_argument("--keep-up", action="store_true", help="Do not teardown compose after run")
    parser.add_argument("--out", default=str(REPO_ROOT / "results" / "demo_orchestrator_suite.json"))
    args = parser.parse_args()

    out_path = Path(args.out)
    out_path.parent.mkdir(parents=True, exist_ok=True)

    ensure_env_file()

    if not args.skip_compose:
        compose_up(build=not args.no_build)

    started = time.time()
    run_rows: list[dict[str, Any]] = []
    try:
        for case in HARD_CASES:
            row = await run_case(case, repo_path=args.repo_path)
            run_rows.append(row)
            print(f"[{case.name}] status={row['status']} human_review={row['needs_human_review']} advisory_calls={row['advisory_tool_calls']} wall={row['wall_time_s']}s")
    finally:
        if not args.skip_compose and not args.keep_up:
            compose_down()

    verified = sum(1 for r in run_rows if r["status"] == "shipped" and not r["needs_human_review"])
    report = {
        "started_at": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime(started)),
        "duration_s": round(time.time() - started, 2),
        "cases": run_rows,
        "summary": {
            "total_cases": len(run_rows),
            "verified_repro_cases": verified,
            "verified_rate": round((verified / len(run_rows)) * 100, 2) if run_rows else 0.0,
            "human_review_cases": sum(1 for r in run_rows if r["needs_human_review"]),
            "compliance_failures": sum(1 for r in run_rows if not r["compliance_contract_ok"]),
        },
    }

    out_path.write_text(json.dumps(report, indent=2))
    print(f"\nWrote suite report: {out_path}")
    print(json.dumps(report["summary"], indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(asyncio.run(main()))
