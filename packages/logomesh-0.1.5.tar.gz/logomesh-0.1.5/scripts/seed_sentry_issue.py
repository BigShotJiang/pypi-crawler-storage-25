"""Seed a real Sentry issue against `apply_discount` for the repro demo.

Path 1 of the `logomesh repro` demo: send a real exception to Sentry via
`sentry-sdk`, then run `logomesh repro <issue-url>` against this repo.

Usage:
    export SENTRY_DSN='https://<key>@oXXX.ingest.sentry.io/<project>'
    uv run python scripts/seed_sentry_issue.py

Then open Sentry, copy the issue URL, and run:

    export SENTRY_AUTH_TOKEN=<user-auth-token-with-event:read>
    uv run logomesh repro '<issue-url>'

Path 2 (no Sentry account) — use the local fixture instead:

    export LOGOMESH_SENTRY_FIXTURE=tests/fixtures/sentry_negative_qty_event.json
    SENTRY_AUTH_TOKEN=stub uv run logomesh repro 'https://sentry.io/issues/9001/'
"""

from __future__ import annotations

import os
import sys
from pathlib import Path

REPO_ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(REPO_ROOT))

from examples.fintech_billing.checkout import apply_discount  # noqa: E402


def main() -> int:
    dsn = os.environ.get("SENTRY_DSN", "").strip()
    if not dsn:
        print("error: SENTRY_DSN is not set", file=sys.stderr)
        return 2

    try:
        import sentry_sdk
    except ImportError:
        print(
            "error: sentry-sdk is not installed. "
            "Run: uv pip install 'sentry-sdk>=2'",
            file=sys.stderr,
        )
        return 2

    sentry_sdk.init(
        dsn=dsn,
        send_default_pii=True,
        include_local_variables=True,
        traces_sample_rate=0.0,
    )

    try:
        apply_discount(price=49.99, qty=2, discount_pct=120.0)
    except Exception:
        sentry_sdk.capture_exception()

    sentry_sdk.flush(timeout=5)
    print(
        "issue seeded — open Sentry, copy the issue URL, and run "
        "`logomesh repro <url>`"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
