"""Internal logging shim.

Capture must never raise into the host application. When something inside a
hook fails, we want a quiet structured log line — but the SDK ships as its own
pip package, so we cannot hard-depend on ``src.logomesh_log``. This module
imports it if available, otherwise silently no-ops.
"""

from __future__ import annotations

from typing import Any

try:  # pragma: no cover - optional dependency
    from src.logomesh_log import logger as _logger  # type: ignore[attr-defined]
except Exception:  # noqa: BLE001
    _logger = None


def warn(event: str, **fields: Any) -> None:
    """Emit a warning-level event. Silent if no logger is wired up."""
    if _logger is None:
        return
    try:
        _logger.warning(event, extra=fields)  # type: ignore[union-attr]
    except Exception:  # noqa: BLE001
        pass


def safe(fn, *args, _event: str = "capture_hook_failed", **kwargs):
    """Call ``fn`` swallowing any exception, logging a structured warning."""
    try:
        return fn(*args, **kwargs)
    except Exception as exc:  # noqa: BLE001
        warn(_event, error=type(exc).__name__, message=str(exc))
        return None
