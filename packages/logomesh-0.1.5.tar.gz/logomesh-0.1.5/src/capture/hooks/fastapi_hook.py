"""FastAPI / Starlette capture middleware.

Pure ASGI middleware — does not import ``fastapi`` or ``starlette`` so the
SDK can wrap any ASGI app (both frameworks share the same protocol).

What it captures, per HTTP request:
    - method, full url (scheme://host/path?query)
    - request headers (with secret/PII redaction)
    - request body, capped at ``max_body_bytes`` (default 10 KiB), with
      truncation flag.
    - client (host, port) where available

Why an explicit middleware instead of leaning on Sentry's FastAPI
integration:
    - Sentry only captures method/url/headers by default. Bodies require
      ``send_default_pii=True``, which leaks PII globally.
    - The middleware ensures a per-request asyncio task scope, so the
      ``contextvars`` ring buffer is naturally isolated across concurrent
      requests without the host having to think about it.
    - Body capture must wrap the ASGI ``receive`` channel so that reading
      the body for capture does not break the downstream handler — chunks
      are re-emitted exactly as received.

Install path:
    1. Auto-install: ``logomesh_capture.install()`` patches
       ``starlette.applications.Starlette.build_middleware_stack`` to inject
       this middleware before the app is built.
    2. Manual: ``app.add_middleware(logomeshMiddleware)`` in app code.

Either path is idempotent.
"""

from __future__ import annotations

from typing import Any, Awaitable, Callable, Iterable

from .._log import warn
from .. import safety as _safety
from ..ring_buffer import get_buffer, record
from ..serializer import _safe_serialize, redact
from ..stripe_meta import extract_event_meta, parse_stripe_signature

try:  # pragma: no cover - import detection
    import starlette  # type: ignore  # noqa: F401

    AVAILABLE = True
except Exception:  # noqa: BLE001
    AVAILABLE = False


_DEFAULT_MAX_BODY = 10 * 1024  # 10 KiB
_INSTALLED = False
_HOOK_ID = "fastapi.middleware"


Scope = dict[str, Any]
Message = dict[str, Any]
Receive = Callable[[], Awaitable[Message]]
Send = Callable[[Message], Awaitable[None]]


class logomeshMiddleware:
    """ASGI middleware that records the inbound HTTP request to the ring
    buffer. Async-safe; never breaks the host application."""

    def __init__(
        self,
        app: Callable[[Scope, Receive, Send], Awaitable[None]],
        redact_fields: Iterable[str] | None = None,
        max_body_bytes: int = _DEFAULT_MAX_BODY,
    ) -> None:
        self.app = app
        self.redact_fields: list[str] | None = (
            list(redact_fields) if redact_fields else None
        )
        self.max_body_bytes = int(max_body_bytes)

    async def __call__(self, scope: Scope, receive: Receive, send: Send) -> None:
        if scope.get("type") != "http":
            await self.app(scope, receive, send)
            return

        # Circuit breaker / global kill switch: bypass capture entirely once
        # tripped so the request path has zero added overhead.
        if not _safety.is_hook_enabled(_HOOK_ID):
            await self.app(scope, receive, send)
            return

        # Touch the buffer so it is created in this request's asyncio task
        # context. Subsequent hooks (SQLAlchemy, httpx, redis) running within
        # this request share the same ContextVar.
        try:
            get_buffer()
        except Exception:  # noqa: BLE001
            pass

        body_chunks: list[bytes] = []
        body_size = 0
        truncated = False

        async def wrapped_receive() -> Message:
            nonlocal body_size, truncated
            message = await receive()
            try:
                if message.get("type") == "http.request":
                    chunk = message.get("body", b"") or b""
                    if isinstance(chunk, (bytes, bytearray)) and chunk:
                        remaining = self.max_body_bytes - body_size
                        if remaining > 0:
                            keep = bytes(chunk[:remaining])
                            body_chunks.append(keep)
                            body_size += len(keep)
                        if len(chunk) > remaining:
                            truncated = True
            except Exception as exc:  # noqa: BLE001
                warn("fastapi_body_capture_failed",
                     error=type(exc).__name__, message=str(exc))
            return message

        try:
            await self.app(scope, wrapped_receive, send)
        finally:
            try:
                _record_request(scope, body_chunks, truncated,
                                self.max_body_bytes, self.redact_fields)
                _safety.record_success(_HOOK_ID)
            except Exception as exc:  # noqa: BLE001
                warn("fastapi_request_record_failed",
                     error=type(exc).__name__, message=str(exc))
                _safety.record_failure(_HOOK_ID)


def _decode_headers(raw: list[tuple[bytes, bytes]] | None) -> dict[str, str]:
    """ASGI headers come as a list of (name_bytes, value_bytes) with name
    lowercased. Collapse duplicates by joining with ``, `` per RFC 7230."""
    if not raw:
        return {}
    out: dict[str, str] = {}
    for name_b, value_b in raw:
        try:
            name = name_b.decode("latin-1").lower()
            value = value_b.decode("latin-1")
        except Exception:  # noqa: BLE001
            continue
        if name in out:
            out[name] = f"{out[name]}, {value}"
        else:
            out[name] = value
    return out


def _build_url(scope: Scope) -> str:
    scheme = scope.get("scheme") or "http"
    server = scope.get("server") or (None, None)
    host_header: str | None = None
    for name_b, value_b in scope.get("headers") or []:
        if name_b == b"host":
            try:
                host_header = value_b.decode("latin-1")
            except Exception:  # noqa: BLE001
                host_header = None
            break
    if host_header:
        host = host_header
    elif server[0]:
        host = f"{server[0]}:{server[1]}" if server[1] else str(server[0])
    else:
        host = ""
    path = scope.get("path") or ""
    raw_query = scope.get("query_string") or b""
    try:
        query = raw_query.decode("latin-1") if isinstance(raw_query, (bytes, bytearray)) else str(raw_query)
    except Exception:  # noqa: BLE001
        query = ""
    suffix = f"?{query}" if query else ""
    return f"{scheme}://{host}{path}{suffix}" if host else f"{path}{suffix}"


def _record_request(
    scope: Scope,
    body_chunks: list[bytes],
    truncated: bool,
    max_body_bytes: int,
    redact_fields: list[str] | None,
) -> None:
    headers = _decode_headers(scope.get("headers"))

    body_bytes = b"".join(body_chunks)[:max_body_bytes]
    try:
        raw_body_text = body_bytes.decode("utf-8", errors="replace")
    except Exception:  # noqa: BLE001
        raw_body_text = ""

    # Pull Stripe webhook structured fields BEFORE redaction. Event id /
    # event type are not secret; they are the primary key of the webhook
    # delivery and downstream repro generation needs them as top-level
    # fields, not buried inside a redacted body blob.
    stripe_sig_raw = headers.get("stripe-signature") or ""
    sig_parsed = parse_stripe_signature(stripe_sig_raw) if stripe_sig_raw else None
    event_meta = extract_event_meta(raw_body_text) if stripe_sig_raw else {}

    # ``Stripe-Webhook-Attempt`` is set on retries; absent on the first try.
    attempt_raw = headers.get("stripe-webhook-attempt")
    try:
        attempt = int(attempt_raw) if attempt_raw is not None else None
    except (TypeError, ValueError):
        attempt = None

    safe_headers: dict[str, str] = headers
    if redact_fields:
        try:
            safe_headers = redact(headers, redact_fields)  # type: ignore[assignment]
        except Exception:  # noqa: BLE001
            pass

    body_text = raw_body_text
    # Best-effort JSON-aware redaction so leaked secrets in request bodies
    # are scrubbed in the same way as HTTP egress bodies.
    if redact_fields and body_text:
        try:
            import json
            parsed = json.loads(body_text)
            body_text = json.dumps(redact(parsed, redact_fields),
                                   ensure_ascii=False, default=str)
        except Exception:  # noqa: BLE001
            pass

    client = scope.get("client") or (None, None)

    entry: dict[str, Any] = {
        "type": "request",
        "framework": "asgi",
        "method": str(scope.get("method") or "").upper(),
        "url": _build_url(scope),
        "path": scope.get("path") or "",
        "query_string": (scope.get("query_string") or b"").decode("latin-1", errors="replace")
            if isinstance(scope.get("query_string"), (bytes, bytearray)) else "",
        "headers": _safe_serialize(safe_headers),
        "client_host": client[0],
        "client_port": client[1],
        "body": body_text,
        "body_truncated": truncated,
    }

    if stripe_sig_raw:
        # Mark this as a Stripe webhook delivery and surface the fields the
        # repro pipeline branches on (duplicate event id, replay window, etc).
        entry["is_stripe_webhook"] = True
        entry["stripe_event_id"] = event_meta.get("event_id")
        entry["stripe_event_type"] = event_meta.get("event_type")
        entry["stripe_event_object_type"] = event_meta.get("object_type")
        entry["stripe_event_object_id"] = event_meta.get("object_id")
        entry["stripe_livemode"] = event_meta.get("livemode")
        entry["stripe_api_version"] = event_meta.get("api_version")
        entry["stripe_request_idempotency_key"] = event_meta.get(
            "request_idempotency_key")
        entry["stripe_signature_t"] = sig_parsed.get("t") if sig_parsed else None
        entry["stripe_webhook_attempt"] = attempt

    record(entry)


def _patch_starlette_build(redact_fields: list[str] | None,
                           max_body_bytes: int) -> bool:
    """Auto-inject ``logomeshMiddleware`` into Starlette apps by wrapping
    ``Starlette.build_middleware_stack``. FastAPI inherits from Starlette,
    so this covers both."""
    try:
        from starlette.applications import Starlette  # type: ignore
        from starlette.middleware import Middleware  # type: ignore
    except Exception:  # noqa: BLE001
        return False

    if getattr(Starlette, "_logomesh_patched", False):
        return True

    original = Starlette.build_middleware_stack

    def patched(self: Any) -> Any:
        try:
            already = any(
                getattr(m, "cls", None) is logomeshMiddleware
                for m in getattr(self, "user_middleware", []) or []
            )
            if not already:
                # Insert as outermost (index 0) so we observe the raw request
                # before any other user middleware can mutate or short-circuit.
                self.user_middleware.insert(
                    0,
                    Middleware(
                        logomeshMiddleware,
                        redact_fields=redact_fields,
                        max_body_bytes=max_body_bytes,
                    ),
                )
        except Exception as exc:  # noqa: BLE001
            warn("fastapi_inject_middleware_failed",
                 error=type(exc).__name__, message=str(exc))
        return original(self)

    Starlette.build_middleware_stack = patched  # type: ignore[assignment]
    Starlette._logomesh_patched = True  # type: ignore[attr-defined]
    return True


def install(redact_fields: list[str] | None = None,
            max_body_bytes: int = _DEFAULT_MAX_BODY) -> None:
    """Idempotent install. If Starlette/FastAPI is importable, auto-injects
    the middleware into all ``Starlette`` apps built afterward. Apps already
    built before ``install()`` was called must mount ``logomeshMiddleware``
    explicitly via ``app.add_middleware(logomeshMiddleware)``."""
    global _INSTALLED
    if not AVAILABLE or _INSTALLED:
        return
    ok = _patch_starlette_build(redact_fields, max_body_bytes)
    _INSTALLED = ok
