"""Redis capture hook.

Strategy: monkey-patch ``redis.Redis.execute_command``. Only read commands
(GET / HGET / HGETALL / LRANGE / SMEMBERS / ZRANGE) are recorded — writes
are noise for reproduction.
"""

from __future__ import annotations

from typing import Any

from .._log import warn
from .. import safety as _safety
from ..ring_buffer import record
from ..serializer import _safe_serialize

_HOOK_ID = "redis.execute"

try:  # pragma: no cover - import detection
    import redis as _redis  # type: ignore

    AVAILABLE = True
except Exception:  # noqa: BLE001
    AVAILABLE = False
    _redis = None  # type: ignore[assignment]


_INSTALLED = False
_ORIGINAL_EXECUTE = None

_READ_COMMANDS = {
    "GET",
    "MGET",
    "HGET",
    "HGETALL",
    "HMGET",
    "LRANGE",
    "LINDEX",
    "SMEMBERS",
    "SISMEMBER",
    "ZRANGE",
    "ZRANGEBYSCORE",
    "EXISTS",
    "TYPE",
}


def _stringify_arg(arg: Any) -> Any:
    if isinstance(arg, (bytes, bytearray)):
        try:
            return bytes(arg).decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            return repr(bytes(arg))
    return arg


def install() -> None:
    """Idempotent install of the Redis capture hook."""
    global _INSTALLED, _ORIGINAL_EXECUTE
    if not AVAILABLE:
        return
    if _INSTALLED:
        return

    _ORIGINAL_EXECUTE = _redis.Redis.execute_command  # type: ignore[union-attr]

    def patched(self: Any, *args: Any, **kwargs: Any) -> Any:
        result = _ORIGINAL_EXECUTE(self, *args, **kwargs)  # type: ignore[misc]
        if not _safety.is_hook_enabled(_HOOK_ID):
            return result
        try:
            cmd_raw = args[0] if args else ""
            cmd = _stringify_arg(cmd_raw)
            cmd_str = str(cmd).upper() if cmd is not None else ""
            if cmd_str in _READ_COMMANDS:
                key_raw = args[1] if len(args) > 1 else ""
                rest = [_stringify_arg(a) for a in args[2:]]
                record({
                    "type": "redis",
                    "cmd": cmd_str,
                    "key": _stringify_arg(key_raw),
                    "args": _safe_serialize(rest),
                    "result": _safe_serialize(result),
                })
            _safety.record_success(_HOOK_ID)
        except Exception as exc:  # noqa: BLE001
            warn("redis_capture_failed", error=type(exc).__name__,
                 message=str(exc))
            _safety.record_failure(_HOOK_ID)
        return result

    _redis.Redis.execute_command = patched  # type: ignore[assignment]
    _INSTALLED = True
