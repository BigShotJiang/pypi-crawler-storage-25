"""Django ORM capture hook.

Strategy: monkey-patch ``DatabaseWrapper.create_cursor`` so the cursor
returned to Django wraps ``fetchone`` / ``fetchmany`` / ``fetchall`` and
records (sql, params, columns, rows) into the ring buffer **only** for
read statements (SELECT / WITH / SHOW / EXPLAIN). Writes (INSERT / UPDATE /
DELETE / DDL) are skipped — they are noise for crash reproduction.

All capture is best-effort and wrapped in try/except so the host app is
never affected.
"""

from __future__ import annotations

import re
from typing import Any

from .._log import warn
from ..ring_buffer import record
from ..serializer import _safe_serialize, redact_row

try:  # pragma: no cover - import detection
    import django  # type: ignore  # noqa: F401
    from django.db.backends.base.base import BaseDatabaseWrapper  # type: ignore

    AVAILABLE = True
except Exception:  # noqa: BLE001
    AVAILABLE = False
    BaseDatabaseWrapper = None  # type: ignore[assignment]


_INSTALLED = False
_ORIGINAL_CREATE_CURSOR = None
_ROW_CAP = 100

_READ_PREFIXES = ("SELECT", "WITH", "SHOW", "EXPLAIN", "PRAGMA")


def _is_read(sql: str) -> bool:
    if not sql:
        return False
    # Strip leading whitespace and comments.
    stripped = re.sub(r"^\s*(/\*.*?\*/\s*|--[^\n]*\n)*", "", sql, flags=re.DOTALL)
    token = stripped.lstrip().split(None, 1)
    if not token:
        return False
    return token[0].upper() in _READ_PREFIXES


def _columns_from(cursor: Any) -> list[str]:
    desc = getattr(cursor, "description", None)
    if not desc:
        return []
    cols: list[str] = []
    for entry in desc:
        try:
            cols.append(str(entry[0]))
        except Exception:  # noqa: BLE001
            cols.append("")
    return cols


def _make_record(sql: str, params: Any, columns: list[str], rows: list[Any],
                 truncated: bool, redact_fields: list[str] | None) -> dict[str, Any]:
    safe_rows: list[Any] = []
    for r in rows[:_ROW_CAP]:
        try:
            row_list = list(r) if not isinstance(r, list) else r
        except TypeError:
            row_list = [r]
        redacted = redact_row(columns, row_list, redact_fields)
        safe_rows.append([_safe_serialize(v) for v in redacted])
    return {
        "type": "db",
        "sql": str(sql)[:4000],
        "params": _safe_serialize(params),
        "columns": columns,
        "rows": safe_rows,
        "table_names": [],  # left for the offline parser; SDK doesn't parse SQL.
        "truncated": truncated,
    }


def _wrap_cursor(cursor: Any, redact_fields: list[str] | None) -> Any:
    """Return a thin proxy that records read results."""

    class _CapturingCursor:
        # Use composition rather than subclassing — cursor classes vary by
        # backend and some are not subclassable.
        def __init__(self, inner: Any) -> None:
            object.__setattr__(self, "_inner", inner)
            object.__setattr__(self, "_last_sql", "")
            object.__setattr__(self, "_last_params", None)

        def __getattr__(self, name: str) -> Any:
            return getattr(self._inner, name)

        def __setattr__(self, name: str, value: Any) -> None:
            setattr(self._inner, name, value)

        def __iter__(self) -> Any:
            return iter(self._inner)

        def __enter__(self) -> Any:
            self._inner.__enter__()
            return self

        def __exit__(self, exc_type: Any, exc: Any, tb: Any) -> Any:
            return self._inner.__exit__(exc_type, exc, tb)

        # ---- statement execution ----
        def execute(self, sql: str, params: Any = None) -> Any:
            object.__setattr__(self, "_last_sql", sql)
            object.__setattr__(self, "_last_params", params)
            return self._inner.execute(sql, params)

        def executemany(self, sql: str, param_list: Any) -> Any:
            object.__setattr__(self, "_last_sql", sql)
            object.__setattr__(self, "_last_params", param_list)
            return self._inner.executemany(sql, param_list)

        # ---- result fetching: capture point ----
        def fetchone(self) -> Any:
            row = self._inner.fetchone()
            self._capture([row] if row is not None else [], truncated=False)
            return row

        def fetchmany(self, size: int | None = None) -> Any:
            rows = self._inner.fetchmany(size) if size is not None else self._inner.fetchmany()
            self._capture(list(rows), truncated=False)
            return rows

        def fetchall(self) -> Any:
            rows = self._inner.fetchall()
            row_list = list(rows)
            truncated = len(row_list) > _ROW_CAP
            self._capture(row_list, truncated=truncated)
            return rows

        def _capture(self, rows: list[Any], truncated: bool) -> None:
            try:
                sql = self._last_sql or ""
                if not _is_read(sql):
                    return
                columns = _columns_from(self._inner)
                entry = _make_record(sql, self._last_params, columns,
                                     rows, truncated, redact_fields)
                record(entry)
            except Exception as exc:  # noqa: BLE001
                warn("django_capture_failed", error=type(exc).__name__,
                     message=str(exc))

    return _CapturingCursor(cursor)


def install(redact_fields: list[str] | None = None) -> None:
    """Idempotent install of the Django cursor-wrapping hook."""
    global _INSTALLED, _ORIGINAL_CREATE_CURSOR
    if not AVAILABLE:
        return
    if _INSTALLED:
        return

    _ORIGINAL_CREATE_CURSOR = BaseDatabaseWrapper.create_cursor  # type: ignore[union-attr]

    def patched_create_cursor(self: Any, name: Any = None) -> Any:
        try:
            cursor = _ORIGINAL_CREATE_CURSOR(self, name)  # type: ignore[misc]
        except TypeError:
            cursor = _ORIGINAL_CREATE_CURSOR(self)  # type: ignore[misc]
        try:
            return _wrap_cursor(cursor, redact_fields)
        except Exception as exc:  # noqa: BLE001
            warn("django_wrap_cursor_failed", error=type(exc).__name__,
                 message=str(exc))
            return cursor

    BaseDatabaseWrapper.create_cursor = patched_create_cursor  # type: ignore[assignment]
    _INSTALLED = True
