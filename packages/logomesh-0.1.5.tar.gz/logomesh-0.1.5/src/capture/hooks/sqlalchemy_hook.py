"""SQLAlchemy capture hook.

Strategy: register a ``before_cursor_execute`` event listener on the SA
``Engine``. The listener stashes the in-flight SQL/params on the cursor
object and then monkey-patches the cursor instance's ``fetchone`` /
``fetchmany`` / ``fetchall`` methods to also push captured rows into the
ring buffer.

Only read statements are recorded; writes are skipped.
"""

from __future__ import annotations

import re
from typing import Any

from .._log import warn
from .. import safety as _safety
from ..ring_buffer import record
from ..serializer import _safe_serialize, redact_row

_HOOK_ID = "sqlalchemy.cursor"

try:  # pragma: no cover - import detection
    from sqlalchemy import event  # type: ignore
    from sqlalchemy.engine import Engine  # type: ignore

    AVAILABLE = True
except Exception:  # noqa: BLE001
    AVAILABLE = False
    event = None  # type: ignore[assignment]
    Engine = None  # type: ignore[assignment]


_INSTALLED = False
_ROW_CAP = 100
_READ_PREFIXES = ("SELECT", "WITH", "SHOW", "EXPLAIN", "PRAGMA")


def _is_read(sql: str) -> bool:
    if not sql:
        return False
    stripped = re.sub(r"^\s*(/\*.*?\*/\s*|--[^\n]*\n)*", "", sql, flags=re.DOTALL)
    head = stripped.lstrip().split(None, 1)
    if not head:
        return False
    return head[0].upper() in _READ_PREFIXES


def _columns_from(cursor: Any) -> list[str]:
    desc = getattr(cursor, "description", None)
    if not desc:
        return []
    cols: list[str] = []
    for entry in desc:
        try:
            cols.append(str(entry[0]))
        except Exception:  # noqa: BLE001
            cols.append("")
    return cols


def _record_rows(cursor: Any, rows: list[Any], truncated: bool,
                 redact_fields: list[str] | None) -> None:
    sql = getattr(cursor, "_logomesh_sql", "") or ""
    if not _is_read(sql):
        return
    params = getattr(cursor, "_logomesh_params", None)
    columns = _columns_from(cursor)
    safe_rows: list[Any] = []
    for r in rows[:_ROW_CAP]:
        try:
            row_list = list(r) if not isinstance(r, list) else r
        except TypeError:
            row_list = [r]
        redacted = redact_row(columns, row_list, redact_fields)
        safe_rows.append([_safe_serialize(v) for v in redacted])
    record({
        "type": "db",
        "sql": str(sql)[:4000],
        "params": _safe_serialize(params),
        "columns": columns,
        "rows": safe_rows,
        "table_names": [],
        "truncated": truncated,
    })


def _patch_cursor_methods(cursor: Any, redact_fields: list[str] | None) -> None:
    if getattr(cursor, "_logomesh_patched", False):
        return
    try:
        original_fetchone = cursor.fetchone
        original_fetchmany = cursor.fetchmany
        original_fetchall = cursor.fetchall
    except AttributeError:
        return

    def fetchone(*args: Any, **kwargs: Any) -> Any:
        row = original_fetchone(*args, **kwargs)
        if not _safety.is_hook_enabled(_HOOK_ID):
            return row
        try:
            _record_rows(cursor, [row] if row is not None else [],
                         truncated=False, redact_fields=redact_fields)
            _safety.record_success(_HOOK_ID)
        except Exception as exc:  # noqa: BLE001
            warn("sqlalchemy_capture_failed", error=type(exc).__name__,
                 message=str(exc))
            _safety.record_failure(_HOOK_ID)
        return row

    def fetchmany(*args: Any, **kwargs: Any) -> Any:
        rows = original_fetchmany(*args, **kwargs)
        if not _safety.is_hook_enabled(_HOOK_ID):
            return rows
        try:
            _record_rows(cursor, list(rows), truncated=False,
                         redact_fields=redact_fields)
            _safety.record_success(_HOOK_ID)
        except Exception as exc:  # noqa: BLE001
            warn("sqlalchemy_capture_failed", error=type(exc).__name__,
                 message=str(exc))
            _safety.record_failure(_HOOK_ID)
        return rows

    def fetchall(*args: Any, **kwargs: Any) -> Any:
        rows = original_fetchall(*args, **kwargs)
        if not _safety.is_hook_enabled(_HOOK_ID):
            return rows
        try:
            row_list = list(rows)
            _record_rows(cursor, row_list, truncated=len(row_list) > _ROW_CAP,
                         redact_fields=redact_fields)
            _safety.record_success(_HOOK_ID)
        except Exception as exc:  # noqa: BLE001
            warn("sqlalchemy_capture_failed", error=type(exc).__name__,
                 message=str(exc))
            _safety.record_failure(_HOOK_ID)
        return rows

    try:
        cursor.fetchone = fetchone  # type: ignore[method-assign]
        cursor.fetchmany = fetchmany  # type: ignore[method-assign]
        cursor.fetchall = fetchall  # type: ignore[method-assign]
        cursor._logomesh_patched = True  # type: ignore[attr-defined]
    except Exception as exc:  # noqa: BLE001
        # Some DBAPI cursors are slot-only and reject attribute assignment;
        # fall back silently.
        warn("sqlalchemy_patch_cursor_failed", error=type(exc).__name__,
             message=str(exc))


def install(redact_fields: list[str] | None = None) -> None:
    """Idempotent install. Registers a listener on the global
    ``Engine`` class so all engines created in-process inherit it."""
    global _INSTALLED
    if not AVAILABLE:
        return
    if _INSTALLED:
        return

    def before_cursor_execute(conn: Any, cursor: Any, statement: str,
                              parameters: Any, context: Any,
                              executemany: bool) -> None:
        try:
            cursor._logomesh_sql = statement  # type: ignore[attr-defined]
            cursor._logomesh_params = parameters  # type: ignore[attr-defined]
            _patch_cursor_methods(cursor, redact_fields)
        except Exception as exc:  # noqa: BLE001
            warn("sqlalchemy_before_execute_failed", error=type(exc).__name__,
                 message=str(exc))

    event.listen(Engine, "before_cursor_execute", before_cursor_execute)  # type: ignore[union-attr]
    _INSTALLED = True
