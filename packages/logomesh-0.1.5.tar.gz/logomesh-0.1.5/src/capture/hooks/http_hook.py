"""HTTP capture hook.

Wraps:
- ``httpx.Client.send`` and ``httpx.AsyncClient.send``
- ``requests.Session.send``

Records method, url, request body (capped 5KB), status_code, response body
(capped 10KB), and response headers. Headers and JSON-decoded bodies are
walked through the redaction helper.
"""

from __future__ import annotations

import json
from typing import Any

from .._log import warn
from .. import safety as _safety
from ..ring_buffer import record
from ..serializer import _safe_serialize, redact
from ..stripe_meta import is_stripe_api_url

try:  # pragma: no cover - import detection
    import httpx  # type: ignore

    HTTPX_AVAILABLE = True
except Exception:  # noqa: BLE001
    HTTPX_AVAILABLE = False
    httpx = None  # type: ignore[assignment]

try:  # pragma: no cover - import detection
    import requests  # type: ignore

    REQUESTS_AVAILABLE = True
except Exception:  # noqa: BLE001
    REQUESTS_AVAILABLE = False
    requests = None  # type: ignore[assignment]

AVAILABLE = HTTPX_AVAILABLE or REQUESTS_AVAILABLE


_REQ_BODY_CAP = 5 * 1024  # 5KB
_RESP_BODY_CAP = 10 * 1024  # 10KB

_HTTPX_INSTALLED = False
_REQUESTS_INSTALLED = False

_HOOK_HTTPX = "httpx.send"
_HOOK_REQUESTS = "requests.send"

_ORIG_HTTPX_SYNC_SEND = None
_ORIG_HTTPX_ASYNC_SEND = None
_ORIG_REQUESTS_SEND = None


def _truncate(data: Any, cap: int) -> tuple[str, bool]:
    """Return (text, truncated). Bytes are decoded utf-8 with replacement."""
    if data is None:
        return "", False
    if isinstance(data, (bytes, bytearray, memoryview)):
        b = bytes(data)
        truncated = len(b) > cap
        return b[:cap].decode("utf-8", errors="replace"), truncated
    if isinstance(data, str):
        truncated = len(data) > cap
        return data[:cap], truncated
    try:
        s = str(data)
    except Exception:  # noqa: BLE001
        return "", False
    return s[:cap], len(s) > cap


def _maybe_redact_json_text(text: str, redact_fields: list[str] | None) -> str:
    if not redact_fields or not text:
        return text
    try:
        parsed = json.loads(text)
    except Exception:  # noqa: BLE001
        return text
    try:
        redacted = redact(parsed, redact_fields)
        return json.dumps(redacted, ensure_ascii=False, default=str)
    except Exception:  # noqa: BLE001
        return text


def _headers_to_dict(headers: Any) -> dict[str, str]:
    if headers is None:
        return {}
    try:
        if hasattr(headers, "items"):
            return {str(k): str(v) for k, v in headers.items()}
    except Exception:  # noqa: BLE001
        pass
    try:
        return {str(k): str(v) for k, v in dict(headers).items()}  # type: ignore[arg-type]
    except Exception:  # noqa: BLE001
        return {}


def _build_entry(method: str, url: str, request_headers: Any, request_body: Any,
                 status_code: int | None, response_body: Any,
                 response_headers: Any,
                 redact_fields: list[str] | None) -> dict[str, Any]:
    req_text, _ = _truncate(request_body, _REQ_BODY_CAP)
    resp_text, _ = _truncate(response_body, _RESP_BODY_CAP)
    req_text = _maybe_redact_json_text(req_text, redact_fields)
    resp_text = _maybe_redact_json_text(resp_text, redact_fields)
    req_headers_dict = _headers_to_dict(request_headers)
    resp_headers_dict = _headers_to_dict(response_headers)

    # Lift idempotency / Stripe identity headers BEFORE redaction so the
    # repro pipeline gets stable top-level fields. These header names are
    # not secret in themselves; only Authorization is. Header lookup is
    # case-insensitive: build a lowercase view.
    headers_lower = {k.lower(): v for k, v in req_headers_dict.items()}
    idempotency_key = headers_lower.get("idempotency-key")
    stripe_account = headers_lower.get("stripe-account")
    stripe_version = headers_lower.get("stripe-version")
    is_stripe = is_stripe_api_url(url)

    if redact_fields:
        try:
            req_headers_dict = redact(req_headers_dict, redact_fields)  # type: ignore[assignment]
        except Exception:  # noqa: BLE001
            pass
        try:
            resp_headers_dict = redact(resp_headers_dict, redact_fields)  # type: ignore[assignment]
        except Exception:  # noqa: BLE001
            pass
    return {
        "type": "http",
        "method": str(method or "").upper(),
        "url": str(url or ""),
        "is_stripe": is_stripe,
        "idempotency_key": idempotency_key,
        "stripe_account": stripe_account,
        "stripe_version": stripe_version,
        "request_headers": _safe_serialize(req_headers_dict),
        "request_body": req_text,
        "status_code": status_code,
        "response_body": resp_text,
        "response_headers": _safe_serialize(resp_headers_dict),
    }


# ---- httpx ------------------------------------------------------------------


def _httpx_request_body(request: Any) -> Any:
    try:
        content = getattr(request, "content", None)
        if content is not None:
            return content
    except Exception:  # noqa: BLE001
        pass
    try:
        return getattr(request, "_content", None)
    except Exception:  # noqa: BLE001
        return None


def _install_httpx(redact_fields: list[str] | None) -> None:
    global _HTTPX_INSTALLED, _ORIG_HTTPX_SYNC_SEND, _ORIG_HTTPX_ASYNC_SEND
    if not HTTPX_AVAILABLE or _HTTPX_INSTALLED:
        return

    _ORIG_HTTPX_SYNC_SEND = httpx.Client.send  # type: ignore[union-attr]
    _ORIG_HTTPX_ASYNC_SEND = httpx.AsyncClient.send  # type: ignore[union-attr]

    def sync_send(self: Any, request: Any, *args: Any, **kwargs: Any) -> Any:
        response = _ORIG_HTTPX_SYNC_SEND(self, request, *args, **kwargs)  # type: ignore[misc]
        if not _safety.is_hook_enabled(_HOOK_HTTPX):
            return response
        try:
            entry = _build_entry(
                method=getattr(request, "method", ""),
                url=str(getattr(request, "url", "")),
                request_headers=getattr(request, "headers", {}),
                request_body=_httpx_request_body(request),
                status_code=getattr(response, "status_code", None),
                response_body=getattr(response, "content", b""),
                response_headers=getattr(response, "headers", {}),
                redact_fields=redact_fields,
            )
            record(entry)
            _safety.record_success(_HOOK_HTTPX)
        except Exception as exc:  # noqa: BLE001
            warn("httpx_capture_failed", error=type(exc).__name__,
                 message=str(exc))
            _safety.record_failure(_HOOK_HTTPX)
        return response

    async def async_send(self: Any, request: Any, *args: Any, **kwargs: Any) -> Any:
        response = await _ORIG_HTTPX_ASYNC_SEND(self, request, *args, **kwargs)  # type: ignore[misc]
        if not _safety.is_hook_enabled(_HOOK_HTTPX):
            return response
        try:
            # httpx async response.content may not be loaded yet; aread() is
            # available but calling it can change application semantics.
            try:
                content = response.content  # type: ignore[attr-defined]
            except Exception:  # noqa: BLE001
                content = b""
            entry = _build_entry(
                method=getattr(request, "method", ""),
                url=str(getattr(request, "url", "")),
                request_headers=getattr(request, "headers", {}),
                request_body=_httpx_request_body(request),
                status_code=getattr(response, "status_code", None),
                response_body=content,
                response_headers=getattr(response, "headers", {}),
                redact_fields=redact_fields,
            )
            record(entry)
            _safety.record_success(_HOOK_HTTPX)
        except Exception as exc:  # noqa: BLE001
            warn("httpx_async_capture_failed", error=type(exc).__name__,
                 message=str(exc))
            _safety.record_failure(_HOOK_HTTPX)
        return response

    httpx.Client.send = sync_send  # type: ignore[assignment]
    httpx.AsyncClient.send = async_send  # type: ignore[assignment]
    _HTTPX_INSTALLED = True


# ---- requests ---------------------------------------------------------------


def _requests_request_body(prepared: Any) -> Any:
    body = getattr(prepared, "body", None)
    return body


def _install_requests(redact_fields: list[str] | None) -> None:
    global _REQUESTS_INSTALLED, _ORIG_REQUESTS_SEND
    if not REQUESTS_AVAILABLE or _REQUESTS_INSTALLED:
        return

    _ORIG_REQUESTS_SEND = requests.Session.send  # type: ignore[union-attr]

    def send(self: Any, request: Any, **kwargs: Any) -> Any:
        response = _ORIG_REQUESTS_SEND(self, request, **kwargs)  # type: ignore[misc]
        if not _safety.is_hook_enabled(_HOOK_REQUESTS):
            return response
        try:
            try:
                content = response.content
            except Exception:  # noqa: BLE001
                content = b""
            entry = _build_entry(
                method=getattr(request, "method", ""),
                url=str(getattr(request, "url", "")),
                request_headers=getattr(request, "headers", {}),
                request_body=_requests_request_body(request),
                status_code=getattr(response, "status_code", None),
                response_body=content,
                response_headers=getattr(response, "headers", {}),
                redact_fields=redact_fields,
            )
            record(entry)
            _safety.record_success(_HOOK_REQUESTS)
        except Exception as exc:  # noqa: BLE001
            _safety.record_failure(_HOOK_REQUESTS)
            warn("requests_capture_failed", error=type(exc).__name__,
                 message=str(exc))
        return response

    requests.Session.send = send  # type: ignore[assignment]
    _REQUESTS_INSTALLED = True


def install(redact_fields: list[str] | None = None) -> None:
    """Install whichever HTTP libraries are present. Idempotent."""
    if HTTPX_AVAILABLE:
        _install_httpx(redact_fields)
    if REQUESTS_AVAILABLE:
        _install_requests(redact_fields)
