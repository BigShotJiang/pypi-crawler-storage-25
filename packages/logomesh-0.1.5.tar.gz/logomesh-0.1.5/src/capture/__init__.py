"""``logomesh-capture`` — production crash-state SDK.

Single-call install. Detects which frameworks are importable in the host
process and wires up best-effort capture hooks for each. The Sentry hook
drains the captured ring buffer at error time and writes a state file
alongside the Sentry event so ``logomesh repro`` can rebuild the failing
request locally.

Usage in the host application::

    import sentry_sdk
    import logomesh_capture

    sentry_sdk.init(dsn="…")
    logomesh_capture.install()  # zero config

The SDK ships as its own pip package and must not import logomesh internals
beyond the optional ``logomesh_log`` shim.
"""

from __future__ import annotations

import importlib.util
from typing import Iterable

from . import ring_buffer as _ring_buffer
from . import safety as _safety
from ._log import warn
from .serializer import merge_redact_fields

__all__ = ["install", "logomeshMiddleware"]


def __getattr__(name: str):  # PEP 562 lazy attr
    if name == "logomeshMiddleware":
        from .hooks.fastapi_hook import logomeshMiddleware
        return logomeshMiddleware
    raise AttributeError(name)

_INSTALLED = False


def _is_importable(name: str) -> bool:
    try:
        return importlib.util.find_spec(name) is not None
    except Exception:  # noqa: BLE001
        return False


def install(
    db: bool = True,
    redis: bool = True,
    http: bool = True,
    redact_fields: Iterable[str] | None = None,
    state_dir: str = ".logomesh/crashes",
    max_events: int = 50,
) -> None:
    """Wire up capture hooks for whatever frameworks are present.

    Idempotent — calling ``install()`` twice does not double-wrap any hook.
    All capture is best-effort; failures inside a hook never surface to the
    host application.

    Args:
        db: Enable DB hooks (Django + SQLAlchemy where importable).
        redis: Enable the redis-py hook.
        http: Enable httpx + requests hooks.
        redact_fields: Field names whose values are replaced with
            ``"[REDACTED]"`` in DB rows, Redis values, and HTTP bodies.
        state_dir: Where the Sentry hook writes ``<event_id>.json``.
        max_events: Per-context ring buffer capacity.
    """
    global _INSTALLED

    if not _safety.is_globally_enabled():
        # Honour LOGOMESH_DISABLED=1 — install is a no-op so importing the
        # SDK in production behind a feature flag is safe.
        return

    redact_list = merge_redact_fields(redact_fields)

    # Configure ring-buffer capacity before any hook starts recording.
    try:
        _ring_buffer.set_max_events(int(max_events))
    except Exception as exc:  # noqa: BLE001
        warn("ring_buffer_config_failed",
             error=type(exc).__name__, message=str(exc))

    if _INSTALLED:
        # Re-running install with new redact_fields is unsupported — first
        # call wins. We still allow it to be called for ergonomics (no-op).
        return

    if db:
        if _is_importable("django"):
            try:
                from .hooks import django_hook
                django_hook.install(redact_fields=redact_list)
            except Exception as exc:  # noqa: BLE001
                warn("django_hook_install_failed",
                     error=type(exc).__name__, message=str(exc))
        if _is_importable("sqlalchemy"):
            try:
                from .hooks import sqlalchemy_hook
                sqlalchemy_hook.install(redact_fields=redact_list)
            except Exception as exc:  # noqa: BLE001
                warn("sqlalchemy_hook_install_failed",
                     error=type(exc).__name__, message=str(exc))

    if _is_importable("starlette") or _is_importable("fastapi"):
        try:
            from .hooks import fastapi_hook
            fastapi_hook.install(redact_fields=redact_list)
        except Exception as exc:  # noqa: BLE001
            warn("fastapi_hook_install_failed",
                 error=type(exc).__name__, message=str(exc))

    if redis and _is_importable("redis"):
        try:
            from .hooks import redis_hook
            redis_hook.install()
        except Exception as exc:  # noqa: BLE001
            warn("redis_hook_install_failed",
                 error=type(exc).__name__, message=str(exc))

    if http and (_is_importable("httpx") or _is_importable("requests")):
        try:
            from .hooks import http_hook
            http_hook.install(redact_fields=redact_list)
        except Exception as exc:  # noqa: BLE001
            warn("http_hook_install_failed",
                 error=type(exc).__name__, message=str(exc))

    if _is_importable("sentry_sdk"):
        try:
            from . import sentry_hook
            sentry_hook.install(state_dir=state_dir)
        except Exception as exc:  # noqa: BLE001
            warn("sentry_hook_install_failed",
                 error=type(exc).__name__, message=str(exc))

    _INSTALLED = True
