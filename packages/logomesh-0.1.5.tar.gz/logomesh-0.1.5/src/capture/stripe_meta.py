"""Stripe-specific metadata extraction.

Pure parsing — no network, no Stripe SDK dependency. The repro pipeline
downstream uses the structured fields here to:

    - identify duplicate webhook deliveries (same ``event_id`` seen twice)
    - reconstruct the exact ``Stripe-Signature`` payload at replay time
      (signature reuses the same ``t=`` timestamp and signed payload)
    - branch test generation on idempotency-key collisions vs. missing keys

Every function here is total: malformed input returns an empty/structured
default rather than raising. Capture must not break the host application.
"""

from __future__ import annotations

import json
from typing import Any


def parse_stripe_signature(header: str | None) -> dict[str, Any]:
    """Parse a ``Stripe-Signature`` header into structured pieces.

    The header format is comma-separated ``key=value`` pairs:

        ``t=1492774577,v1=5257a8...,v1=abcdef...,v0=...``

    Multiple ``v1`` / ``v0`` entries are valid (Stripe rotates secrets).

    Returns a dict with keys ``t`` (int | None), ``v1`` (list[str]),
    ``v0`` (list[str]). Empty/None input returns empty defaults.
    """
    out: dict[str, Any] = {"t": None, "v1": [], "v0": []}
    if not header:
        return out
    try:
        parts = str(header).split(",")
    except Exception:  # noqa: BLE001
        return out
    for raw in parts:
        if "=" not in raw:
            continue
        key, _, value = raw.strip().partition("=")
        key = key.strip().lower()
        value = value.strip()
        if key == "t":
            try:
                out["t"] = int(value)
            except (TypeError, ValueError):
                out["t"] = None
        elif key == "v1":
            out["v1"].append(value)
        elif key == "v0":
            out["v0"].append(value)
    return out


def extract_event_meta(body_text: str | bytes | None) -> dict[str, Any]:
    """Pull the identifying fields out of a Stripe webhook body.

    Stripe webhook payloads are JSON with a stable shape::

        {
          "id": "evt_...",
          "type": "invoice.payment_failed",
          "livemode": false,
          "api_version": "2024-06-20",
          "data": { "object": { ... } },
          "request": { "id": "req_...", "idempotency_key": "..." }
        }

    Returns whichever fields parse successfully; missing keys map to None.
    A non-JSON body returns all-None.
    """
    out: dict[str, Any] = {
        "event_id": None,
        "event_type": None,
        "livemode": None,
        "api_version": None,
        "object_type": None,
        "object_id": None,
        "request_idempotency_key": None,
    }
    if body_text is None:
        return out
    if isinstance(body_text, (bytes, bytearray)):
        try:
            body_text = bytes(body_text).decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            return out
    try:
        parsed = json.loads(body_text)
    except Exception:  # noqa: BLE001
        return out
    if not isinstance(parsed, dict):
        return out

    out["event_id"] = parsed.get("id") if isinstance(parsed.get("id"), str) else None
    out["event_type"] = parsed.get("type") if isinstance(parsed.get("type"), str) else None
    if isinstance(parsed.get("livemode"), bool):
        out["livemode"] = parsed["livemode"]
    if isinstance(parsed.get("api_version"), str):
        out["api_version"] = parsed["api_version"]

    data = parsed.get("data")
    if isinstance(data, dict):
        obj = data.get("object")
        if isinstance(obj, dict):
            ot = obj.get("object")
            if isinstance(ot, str):
                out["object_type"] = ot
            oid = obj.get("id")
            if isinstance(oid, str):
                out["object_id"] = oid

    req = parsed.get("request")
    if isinstance(req, dict):
        ik = req.get("idempotency_key")
        if isinstance(ik, str):
            out["request_idempotency_key"] = ik

    return out


def is_stripe_api_url(url: str | None) -> bool:
    """Heuristic: outbound calls to ``api.stripe.com``."""
    if not url:
        return False
    try:
        u = str(url).lower()
    except Exception:  # noqa: BLE001
        return False
    return "api.stripe.com" in u
