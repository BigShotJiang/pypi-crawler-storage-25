"""JSON-safe serialization + PII redaction for captured side-effect data.

The state file is JSON, so every value coming from a database row, Redis
response, or HTTP body must be coerced to a JSON-friendly shape. Types that
``json.dumps`` does not handle natively (Decimal, UUID, datetime, bytes) are
converted; anything else falls back to ``repr()``.
"""

from __future__ import annotations

import datetime
import decimal
import json
import uuid
from typing import Any, Iterable


_PRIMITIVE_JSON_TYPES = (str, int, float, bool, type(None))


# Baseline secret/PII field names redacted by default. Lower-cased; matched
# case-insensitively against dict keys (HTTP header names, JSON body fields,
# SQL column names). Callers can extend via ``install(redact_fields=...)`` —
# the user list is *merged* with these defaults, not used to replace them.
DEFAULT_REDACT_FIELDS: tuple[str, ...] = (
    # Auth / session
    "authorization",
    "proxy-authorization",
    "cookie",
    "set-cookie",
    "x-api-key",
    "x-auth-token",
    "x-csrf-token",
    "x-session-token",
    # Generic secrets
    "password",
    "passwd",
    "secret",
    "token",
    "access_token",
    "refresh_token",
    "id_token",
    "api_key",
    "apikey",
    "private_key",
    "client_secret",
    "session_id",
    # Card / payment
    "card_number",
    "cardnumber",
    "card",
    "cvv",
    "cvc",
    "card_cvc",
    "security_code",
    "pan",
    # Government / PII
    "ssn",
    "tax_id",
    "national_id",
    # Personal
    "email",
    "phone",
    "phone_number",
)


def merge_redact_fields(user_fields: Iterable[str] | None) -> list[str]:
    """Merge caller-supplied redact fields with the baked-in defaults.

    Case-insensitive de-dup. Used by ``install()`` so callers extend rather
    than override the safe baseline.
    """
    seen: set[str] = set()
    out: list[str] = []
    for f in DEFAULT_REDACT_FIELDS:
        key = f.lower()
        if key not in seen:
            seen.add(key)
            out.append(key)
    if user_fields:
        for f in user_fields:
            key = str(f).lower()
            if key not in seen:
                seen.add(key)
                out.append(key)
    return out


def _safe_serialize(value: Any) -> Any:
    """Coerce ``value`` into a structure that ``json.dumps`` can handle."""
    if isinstance(value, _PRIMITIVE_JSON_TYPES):
        return value
    if isinstance(value, decimal.Decimal):
        return str(value)
    if isinstance(value, uuid.UUID):
        return str(value)
    if isinstance(value, (datetime.datetime, datetime.date, datetime.time)):
        return value.isoformat()
    if isinstance(value, datetime.timedelta):
        return value.total_seconds()
    if isinstance(value, (bytes, bytearray, memoryview)):
        try:
            return bytes(value).decode("utf-8", errors="replace")
        except Exception:  # noqa: BLE001
            return repr(bytes(value))
    if isinstance(value, (list, tuple, set, frozenset)):
        return [_safe_serialize(v) for v in value]
    if isinstance(value, dict):
        return {str(k): _safe_serialize(v) for k, v in value.items()}
    # Last resort: try direct JSON serialization, otherwise repr.
    try:
        json.dumps(value)
        return value
    except (TypeError, ValueError):
        try:
            return repr(value)
        except Exception:  # noqa: BLE001
            return "<unserializable>"


def _normalize_redact_fields(fields: Iterable[str] | None) -> set[str]:
    if not fields:
        return set()
    return {str(f).lower() for f in fields}


def redact(value: Any, redact_fields: Iterable[str] | None) -> Any:
    """Walk ``value`` and replace any dict entry whose key (case-insensitive)
    matches an entry in ``redact_fields`` with the literal string
    ``"[REDACTED]"``. Returns a new structure — does not mutate input."""
    targets = _normalize_redact_fields(redact_fields)
    if not targets:
        return value
    return _redact_walk(value, targets)


def _redact_walk(value: Any, targets: set[str]) -> Any:
    if isinstance(value, dict):
        out: dict[str, Any] = {}
        for k, v in value.items():
            key_str = str(k)
            if key_str.lower() in targets:
                out[key_str] = "[REDACTED]"
            else:
                out[key_str] = _redact_walk(v, targets)
        return out
    if isinstance(value, list):
        return [_redact_walk(v, targets) for v in value]
    if isinstance(value, tuple):
        return tuple(_redact_walk(v, targets) for v in value)
    return value


def redact_row(
    columns: list[str], row: list[Any], redact_fields: Iterable[str] | None
) -> list[Any]:
    """Redact values in a positional row by matching ``columns[i]`` against
    ``redact_fields``. Used by DB hooks where the data is row-shaped, not
    dict-shaped."""
    targets = _normalize_redact_fields(redact_fields)
    if not targets:
        return row
    out: list[Any] = []
    for col, val in zip(columns, row):
        if str(col).lower() in targets:
            out.append("[REDACTED]")
        else:
            out.append(val)
    # If row is longer than columns, keep the tail untouched.
    if len(row) > len(columns):
        out.extend(row[len(columns):])
    return out
