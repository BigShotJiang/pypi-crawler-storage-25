"""Async-safe ring buffer for capturing pre-crash side effects.

Uses ``contextvars.ContextVar`` so that capture state is isolated per request /
task across both sync and async frameworks (Django sync, Django async, FastAPI,
asyncio). ``threading.local`` would silently leak state across asyncio tasks
on the same thread, so it is intentionally avoided.
"""

from __future__ import annotations

import contextvars
import os
from collections import deque
from typing import Any

from . import safety as _safety

_DEFAULT_MAX_EVENTS = 50

_buffer: contextvars.ContextVar[deque | None] = contextvars.ContextVar(
    "logomesh_buffer", default=None
)

# Module-level override set by ``install(max_events=...)``. Falls back to the
# ``LOGOMESH_MAX_EVENTS`` env var, then the default.
_max_events_override: int | None = None


def _resolve_max_events() -> int:
    if _max_events_override is not None:
        return _max_events_override
    env = os.environ.get("LOGOMESH_MAX_EVENTS")
    if env:
        try:
            return int(env)
        except ValueError:
            pass
    return _DEFAULT_MAX_EVENTS


def set_max_events(n: int) -> None:
    """Set the per-context ring-buffer capacity. Affects only buffers created
    after this call returns; existing deques keep their original maxlen."""
    global _max_events_override
    _max_events_override = int(n)


def get_buffer() -> deque:
    buf = _buffer.get()
    if buf is None:
        buf = deque(maxlen=_resolve_max_events())
        _buffer.set(buf)
    return buf


def record(entry: dict[str, Any]) -> None:
    """Append an entry to the current context's ring buffer. Best-effort —
    never raises into the calling code. Honours the global kill switch so
    ``LOGOMESH_DISABLED=1`` causes every recorder to no-op without removing
    the hooks themselves (they would have to be reinstalled otherwise)."""
    if not _safety.is_globally_enabled():
        return
    try:
        get_buffer().append(entry)
    except Exception:  # noqa: BLE001
        # Capture must never break the host application.
        pass


def drain() -> list[dict[str, Any]]:
    """Return all entries from the current context buffer and clear it."""
    buf = _buffer.get()
    if buf is None:
        return []
    items = list(buf)
    buf.clear()
    return items
