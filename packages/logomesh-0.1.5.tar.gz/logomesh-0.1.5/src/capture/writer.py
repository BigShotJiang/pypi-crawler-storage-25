"""Atomic state-file writer.

Writes ``<event_id>.json`` to ``state_dir`` using the standard
write-tmp-then-rename pattern with an explicit ``fsync`` so partially-written
state files are never visible to ``logomesh repro``.
"""

from __future__ import annotations

import json
import os
import time
import uuid
from pathlib import Path
from typing import Any


def _filename_for(state: dict[str, Any]) -> str:
    event_id = state.get("event_id")
    if event_id:
        # Sanitize: only allow filename-safe chars.
        safe = "".join(c if c.isalnum() or c in ("-", "_") else "_" for c in str(event_id))
        if safe:
            return f"{safe}.json"
    # Fallback: timestamp + short random suffix.
    return f"{int(time.time() * 1000)}_{uuid.uuid4().hex[:8]}.json"


def write_state(state: dict[str, Any], state_dir: str | os.PathLike[str]) -> Path:
    """Atomically write ``state`` as JSON into ``state_dir``.

    Returns the final path. Best-effort: if the write fails, raises — but
    callers (sentry_hook) wrap this in try/except so the host app is never
    affected.
    """
    target_dir = Path(state_dir)
    target_dir.mkdir(parents=True, exist_ok=True)

    final_path = target_dir / _filename_for(state)
    tmp_path = final_path.with_suffix(final_path.suffix + ".tmp")

    payload = json.dumps(state, ensure_ascii=False, default=str).encode("utf-8")

    fd = os.open(tmp_path, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    try:
        os.write(fd, payload)
        os.fsync(fd)
    finally:
        os.close(fd)

    os.replace(tmp_path, final_path)
    return final_path
