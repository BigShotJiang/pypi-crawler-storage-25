"""Sentry integration: drains the ring buffer at error time and writes a
state file alongside the Sentry event.

The Sentry SDK exposes ``before_send`` as a hook that fires once Sentry has
built the event payload but before it ships to the server. This is the right
place to dump captured side-effects: we are guaranteed to have the same
contextvars context that produced the crash (Sentry preserves it across
``capture_exception``).

We deliberately preserve any pre-existing ``before_send`` chain — if the host
application set its own filter, we call it first and only proceed when it
returns a non-None event.
"""

from __future__ import annotations

import datetime
import os
from typing import Any, Callable

from ._log import warn
from .ring_buffer import drain
from .serializer import _safe_serialize
from .writer import write_state

try:  # pragma: no cover - import detection
    import sentry_sdk  # type: ignore

    AVAILABLE = True
except Exception:  # noqa: BLE001
    AVAILABLE = False
    sentry_sdk = None  # type: ignore[assignment]


_INSTALLED = False


# Tight allowlist — environment vars touched by capture must not leak secrets.
_ENV_ALLOWLIST_EXACT = {
    "DJANGO_ENV",
    "ENV",
    "ENVIRONMENT",
    "DEBUG",
    "DJANGO_SETTINGS_MODULE",
}
_ENV_ALLOWLIST_PREFIXES = (
    "FEATURE_",
    "FLAG_",
    "LOGOMESH_",
)


def _capture_env() -> dict[str, str]:
    out: dict[str, str] = {}
    for k, v in os.environ.items():
        if k in _ENV_ALLOWLIST_EXACT or k.startswith(_ENV_ALLOWLIST_PREFIXES):
            out[k] = v
    return out


def _partition(entries: list[dict[str, Any]]) -> tuple[
    list[dict[str, Any]], list[dict[str, Any]], list[dict[str, Any]],
    list[dict[str, Any]],
]:
    db: list[dict[str, Any]] = []
    redis_ops: list[dict[str, Any]] = []
    http: list[dict[str, Any]] = []
    requests: list[dict[str, Any]] = []
    for e in entries:
        t = e.get("type")
        if t == "db":
            db.append(e)
        elif t == "redis":
            redis_ops.append(e)
        elif t == "http":
            http.append(e)
        elif t == "request":
            requests.append(e)
    return db, redis_ops, http, requests


def _strip_type(entries: list[dict[str, Any]]) -> list[dict[str, Any]]:
    """Drop the internal ``type`` discriminator from each entry before
    writing it to disk — the partitioning already encodes the type."""
    return [{k: v for k, v in e.items() if k != "type"} for e in entries]


def _build_state(event: dict[str, Any]) -> dict[str, Any]:
    entries = drain()
    db, redis_ops, http, requests_ = _partition(entries)
    # Per-section caps from the spec.
    db = db[-50:]
    redis_ops = redis_ops[-50:]
    http = http[-20:]

    timestamp = event.get("timestamp")
    if not timestamp:
        timestamp = datetime.datetime.utcnow().isoformat() + "Z"

    # Prefer the request our middleware captured: it has body + redacted
    # headers. Fall back to whatever Sentry attached to the event.
    if requests_:
        request_payload: Any = _strip_type(requests_)[-1]
    else:
        request_payload = _safe_serialize(event.get("request", {}))

    return {
        "schema_version": "1",
        "event_id": event.get("event_id", ""),
        "timestamp": timestamp,
        "request": request_payload,
        "db_queries": _strip_type(db),
        "redis_ops": _strip_type(redis_ops),
        "http_calls": _strip_type(http),
        "env_snapshot": _capture_env(),
    }


def _wrap_before_send(
    state_dir: str,
    previous: Callable[[dict[str, Any], dict[str, Any]], dict[str, Any] | None] | None,
) -> Callable[[dict[str, Any], dict[str, Any]], dict[str, Any] | None]:
    def before_send(event: dict[str, Any], hint: dict[str, Any]) -> dict[str, Any] | None:
        # Honor any pre-existing before_send chain.
        if previous is not None:
            try:
                event = previous(event, hint)  # type: ignore[assignment]
            except Exception as exc:  # noqa: BLE001
                warn("sentry_previous_before_send_failed",
                     error=type(exc).__name__, message=str(exc))
            if event is None:
                return None
        try:
            state = _build_state(event)
            path = write_state(state, state_dir)
            event.setdefault("extra", {})["logomesh_state_file"] = str(path)
        except Exception as exc:  # noqa: BLE001
            warn("sentry_state_write_failed",
                 error=type(exc).__name__, message=str(exc))
        return event

    # Mark our wrapper so a second install() call can detect itself.
    setattr(before_send, "_logomesh_wrapped", True)
    return before_send


def install(state_dir: str = ".logomesh/crashes") -> None:
    """Idempotent install. Wraps the active Sentry client's ``before_send``.

    If Sentry has not been initialised yet (no active client), this is a
    no-op — the host application is expected to call ``sentry_sdk.init()``
    before ``logomesh_capture.install()``.
    """
    global _INSTALLED
    if not AVAILABLE:
        return
    if _INSTALLED:
        return

    try:
        client = sentry_sdk.get_client()  # type: ignore[union-attr]
    except Exception as exc:  # noqa: BLE001
        warn("sentry_get_client_failed",
             error=type(exc).__name__, message=str(exc))
        return

    if client is None or not getattr(client, "options", None):
        # No initialised Sentry client — nothing to wrap. Mark installed
        # so we don't keep retrying on every call.
        _INSTALLED = True
        return

    options = client.options
    previous = options.get("before_send")
    if callable(previous) and getattr(previous, "_logomesh_wrapped", False):
        # Already wrapped this client.
        _INSTALLED = True
        return

    wrapped = _wrap_before_send(state_dir, previous if callable(previous) else None)

    try:
        options["before_send"] = wrapped
    except Exception as exc:  # noqa: BLE001
        warn("sentry_options_assignment_failed",
             error=type(exc).__name__, message=str(exc))
        return

    _INSTALLED = True
