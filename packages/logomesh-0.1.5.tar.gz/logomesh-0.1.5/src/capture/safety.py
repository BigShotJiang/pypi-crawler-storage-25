"""Production safety primitives for the capture SDK.

Two layers, both fail-closed (silent no-op) so the SDK can never take down
or measurably slow a billing endpoint:

    1. Global kill switch — ``LOGOMESH_DISABLED=1`` env var disables every
       hook and the install entrypoint. Honours the env var on every call so
       ops can flip it without a restart.

    2. Per-hook circuit breaker — each hook reports successes/failures
       through ``record_success`` / ``record_failure``. After
       ``DEFAULT_FAILURE_THRESHOLD`` consecutive failures the hook is marked
       disabled for the lifetime of the process. ``is_hook_enabled`` is a
       cheap dict lookup so hot paths can short-circuit without contention.

The breaker counts *consecutive* failures, not absolute failures, so an
intermittent hiccup (one bad row, one weird header) does not permanently
disable a hook. A single recorded success resets the counter.
"""

from __future__ import annotations

import os
import threading
from typing import Final

from ._log import warn

DEFAULT_FAILURE_THRESHOLD: Final[int] = 5

_lock = threading.Lock()
_failures: dict[str, int] = {}
_disabled: set[str] = set()


def _env_disabled() -> bool:
    val = os.environ.get("LOGOMESH_DISABLED", "")
    return val.strip().lower() in ("1", "true", "yes", "on")


def is_globally_enabled() -> bool:
    """Cheap top-of-hot-path check. Honoured by every public capture entry."""
    return not _env_disabled()


def is_hook_enabled(hook_id: str) -> bool:
    """Return False once a hook has tripped its circuit breaker."""
    if not is_globally_enabled():
        return False
    return hook_id not in _disabled


def record_success(hook_id: str) -> None:
    """A hook completed without raising — reset its consecutive-failure
    counter. Cheap on the hot path: only locks when there is state to clear.
    """
    if hook_id not in _failures:
        return
    with _lock:
        _failures.pop(hook_id, None)


def record_failure(hook_id: str,
                   threshold: int = DEFAULT_FAILURE_THRESHOLD) -> bool:
    """Increment the consecutive-failure counter for ``hook_id``. If the
    threshold is reached, mark the hook disabled and emit a single warning.
    Returns True if the hook is now (or remains) disabled.
    """
    with _lock:
        if hook_id in _disabled:
            return True
        n = _failures.get(hook_id, 0) + 1
        _failures[hook_id] = n
        if n >= threshold:
            _disabled.add(hook_id)
            _failures.pop(hook_id, None)
            warn("capture_hook_disabled",
                 hook=hook_id, consecutive_failures=n,
                 reason="circuit_breaker_tripped")
            return True
    return False


def reset_for_tests() -> None:
    """Test-only: clear breaker state so individual tests are isolated."""
    with _lock:
        _failures.clear()
        _disabled.clear()
