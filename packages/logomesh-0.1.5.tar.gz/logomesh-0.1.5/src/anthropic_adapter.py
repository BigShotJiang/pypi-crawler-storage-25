# backward-compat shim — implementation moved to core.anthropic_adapter
from core.anthropic_adapter import *  # noqa: F401, F403
from core.anthropic_adapter import AnthropicAdapter  # noqa: F401
