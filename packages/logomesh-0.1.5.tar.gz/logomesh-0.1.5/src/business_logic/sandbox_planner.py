"""Sandbox spec primitives — agent decides, tool executes.

This module exposes two layers:

  1. `SandboxSpec` + `BootstrapStep`  — data model only. The agent
     constructs these from its own reasoning. No heuristics live in
     the spec types; they're inert containers.

  2. `suggest_starter_spec(introspection)` — an OPTIONAL hint
     function that emits a low-confidence first draft based on
     simple regex-over-evidence rules. The agent is free to ignore
     or rewrite every field. It exists so a fresh agent can boot
     fast on familiar shapes, NOT so the planner picks the strategy.

Contract — read this before editing:
    Tools expose primitives. Tools expose evidence. Tools execute
    agent decisions. Tools do NOT decide what to do. If you find
    yourself adding a `if framework == "x"` branch here, you are
    putting the wrong code in the wrong layer. Move that decision
    into the agent's reasoning step.

Reproduction-first policy:
    The orchestrator uses these primitives during the repro retry
    loop. The hypothesis report is the fallback ONLY after the agent
    has genuinely exhausted repro attempts (different bootstraps,
    different fixture strategies) — not because the sandbox needed
    a config it couldn't get.
"""

from __future__ import annotations

import re
from dataclasses import dataclass, field
from typing import Any

from business_logic.repo_introspection import RepoIntrospection


@dataclass
class BootstrapStep:
    """One discrete action in the sandbox bootstrap.

    Inert data — the agent builds these and hands them to the
    sandbox runner. Nothing in this class makes a routing decision.
    """
    kind: str               # "set_env" | "exec_python" | "write_file" | "install_dep"
    payload: dict[str, Any] # step-specific data
    reason: str             # human-readable, agent-supplied
    evidence_refs: list[str]  # source pointers from RepoIntrospection.evidence


@dataclass
class SandboxSpec:
    """Plan the orchestrator hands to Sandbox.run().

    Inert data. Built by the agent; carried by the planner only as
    a transport type. Confidence is set by whoever populated the
    spec — the data model has no opinion.
    """
    python_version: str
    dependencies: list[str]
    env: dict[str, str]
    bootstrap_steps: list[BootstrapStep]
    notes: list[str] = field(default_factory=list)
    confidence: float = 0.0

    def to_dict(self) -> dict[str, Any]:
        return {
            "python_version": self.python_version,
            "dependencies": self.dependencies,
            "env": self.env,
            "bootstrap_steps": [
                {
                    "kind": s.kind,
                    "payload": s.payload,
                    "reason": s.reason,
                    "evidence_refs": s.evidence_refs,
                }
                for s in self.bootstrap_steps
            ],
            "notes": self.notes,
            "confidence": self.confidence,
        }


# --------------------------------------------------------------------------
# Agent-led primitive — build a spec from EXPLICIT inputs
# --------------------------------------------------------------------------

def build_sandbox_spec(
    *,
    python_version: str,
    dependencies: list[str] | None = None,
    env: dict[str, str] | None = None,
    bootstrap_steps: list[BootstrapStep] | None = None,
    notes: list[str] | None = None,
    confidence: float = 0.5,
) -> SandboxSpec:
    """Agent-led: build a SandboxSpec from values the agent supplies.

    The agent has just reasoned over `RepoIntrospection` evidence and
    decided what the sandbox needs. This is the primitive it calls to
    package that decision. No heuristics — pure assembly.

    Always sets PYTHONDONTWRITEBYTECODE + PYTHONUNBUFFERED for sanity;
    those are sandbox hygiene, not framework decisions.
    """
    e = dict(env or {})
    e.setdefault("PYTHONDONTWRITEBYTECODE", "1")
    e.setdefault("PYTHONUNBUFFERED", "1")

    return SandboxSpec(
        python_version=python_version,
        dependencies=list(dependencies or []),
        env=e,
        bootstrap_steps=list(bootstrap_steps or []),
        notes=list(notes or []),
        confidence=max(0.0, min(1.0, confidence)),
    )


def make_env_step(
    *,
    vars: dict[str, str],
    reason: str,
    evidence_refs: list[str] | None = None,
) -> BootstrapStep:
    """Primitive: build a `set_env` step from agent-supplied kwargs."""
    return BootstrapStep(
        kind="set_env",
        payload={"vars": dict(vars)},
        reason=reason,
        evidence_refs=list(evidence_refs or []),
    )


def make_conftest_step(
    *,
    content: str,
    reason: str,
    evidence_refs: list[str] | None = None,
    path: str = "conftest.py",
) -> BootstrapStep:
    """Primitive: build a `write_file` step. Content is agent-supplied."""
    return BootstrapStep(
        kind="write_file",
        payload={"path": path, "content": content},
        reason=reason,
        evidence_refs=list(evidence_refs or []),
    )


def make_exec_step(
    *,
    code: str,
    reason: str,
    evidence_refs: list[str] | None = None,
) -> BootstrapStep:
    """Primitive: build an `exec_python` step. Code is agent-supplied."""
    return BootstrapStep(
        kind="exec_python",
        payload={"code": code},
        reason=reason,
        evidence_refs=list(evidence_refs or []),
    )


def dependencies_from_manifests(introspection: RepoIntrospection) -> list[str]:
    """Pure utility — union of declared deps across manifests, deduped.

    No decisions, no filtering by framework. The agent decides which
    to actually install. Use this when you want the verbatim set of
    declared dependencies and nothing else.
    """
    deps: list[str] = []
    seen: set[str] = set()
    for m in introspection.manifests:
        for dep in m.dependencies:
            key = re.split(r"[<>=!~ ]", dep, 1)[0].lower()
            if key and key not in seen:
                seen.add(key)
                deps.append(dep)
    return deps


def python_version_from_manifests(introspection: RepoIntrospection) -> str:
    """Pure utility — return the first `requires-python` string seen."""
    for m in introspection.manifests:
        if m.requires_python:
            mm = re.search(r"(\d+\.\d+)", m.requires_python)
            if mm:
                return mm.group(1)
    return ""


# --------------------------------------------------------------------------
# OPTIONAL — low-confidence starter suggestion
# --------------------------------------------------------------------------

def suggest_starter_spec(
    *,
    introspection: RepoIntrospection,
) -> SandboxSpec:
    """OPTIONAL hint — a low-confidence first draft for fresh agents.

    The agent is free to ignore this output entirely and call
    `build_sandbox_spec(...)` with its own choices. The suggestion is
    deliberately conservative and uses ONLY the manifest deps + Python
    version as starting facts. It does NOT route on framework names.

    Returned `confidence` is intentionally low (≤ 0.4) — the agent
    should treat this as "if you have no opinion, try this." Real
    decisions belong in the agent's reasoning step.
    """
    py_version = python_version_from_manifests(introspection) or "3.12"
    deps = dependencies_from_manifests(introspection)
    return build_sandbox_spec(
        python_version=py_version,
        dependencies=deps,
        env={},
        bootstrap_steps=[],
        notes=["starter suggestion — agent should override based on the crash + introspection evidence"],
        confidence=0.3,
    )
