"""
Dependency installer for the PR-review sandbox.

Installs *declared third-party* deps only (never the PR package). Wheels-only
(`--only-binary=:all:`) so no `setup.py` / PEP-517 build hooks ever execute
on PR-author-influenced inputs. The builder runs in its own short-lived
Docker container with network; the resulting site-packages snapshot is mounted
read-only into the airgapped runtime sandbox.

Security invariants:
  - PR source files never present in the builder container.
  - Only PyPI distribution names allowed (strict PEP-508-name regex).
  - No `-e`, git+, file:, http URL, or path specs.
  - Wheels-only install; fail rather than build.
  - Time / disk / pid caps on builder.
"""

from __future__ import annotations

import hashlib
import json
import os
import pathlib
import re
import shutil
import subprocess
import sys
import tempfile
import time
import urllib.request
import urllib.error
from typing import Iterable

try:
    import tomllib
except ImportError:  # py<3.11
    import tomli as tomllib  # type: ignore

try:
    from logomesh_log import log
except ImportError:
    class _FallbackLog:
        def info(self, *a, **kw): pass
        def warn(self, *a, **kw): pass
        def error(self, *a, **kw): pass
    log = _FallbackLog()

try:
    import docker
    from docker.errors import ImageNotFound
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    docker = None

# PEP 508 distribution-name grammar. Strictly alnum + .-_ with alnum head/tail.
_NAME_RE = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._-]{0,63}(?<=[A-Za-z0-9])$")
# Extras and version specifier chars we permit after the name. Whitespace stripped.
_SPEC_TAIL_RE = re.compile(r"^(\[[A-Za-z0-9_,\s.-]+\])?([<>=!~^].+)?$")

MAX_SPECS = 50
BUILDER_IMAGE = os.getenv("LOGOMESH_DEP_BUILDER_IMAGE", "python:3.12-slim")
BUILDER_TIMEOUT = int(os.getenv("LOGOMESH_DEP_INSTALL_TIMEOUT", "90"))
BUILDER_MEM = os.getenv("LOGOMESH_DEP_INSTALL_MEM", "512m")
MAX_SNAPSHOT_BYTES = 500 * 1024 * 1024  # 500 MB
CACHE_TTL_SECONDS = 24 * 3600
CACHE_ROOT = pathlib.Path(
    os.getenv("LOGOMESH_DEP_CACHE", os.path.expanduser("~/.cache/logomesh/deps"))
)


def extract_pr_package_name(dependency_files: dict[str, str]) -> str | None:
    """
    Pull the PR's own distribution name from pyproject.toml — used for prior-pin
    install (fetch the *prior* published version from PyPI so the package's
    native bindings / siblings resolve at import time, while the PR's modified
    file is what actually executes under test as target.py).
    """
    content = (dependency_files or {}).get("pyproject.toml") or ""
    if not content:
        return None
    try:
        data = tomllib.loads(content)
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    name = (data.get("project") or {}).get("name")
    if not name:
        # poetry layout fallback
        name = (((data.get("tool") or {}).get("poetry") or {}).get("name"))
    if not isinstance(name, str):
        return None
    name = name.strip()
    if not _NAME_RE.match(name):
        return None
    return name


def fetch_latest_pypi_version(name: str, timeout: float = 6.0) -> str | None:
    """Query PyPI JSON API for the latest stable release of `name`. None on failure."""
    url = f"https://pypi.org/pypi/{name}/json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "logomesh-dep-installer"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError, OSError) as e:
        log.info("dep_installer", "pypi lookup failed", name=name, error=str(e))
        return None
    info = data.get("info") or {}
    version = info.get("version")
    if not isinstance(version, str) or not version:
        return None
    # Skip dev/rc/a/b unless that's all that exists.
    releases = data.get("releases") or {}
    stable = [v for v in releases if re.match(r"^[0-9][0-9.]*$", v)]
    if stable:
        # pick max by tuple comparison
        def _key(v: str) -> tuple[int, ...]:
            try:
                return tuple(int(p) for p in v.split("."))
            except ValueError:
                return (0,)
        version = max(stable, key=_key)
    return version


def parse_dep_specs(dependency_files: dict[str, str]) -> list[str]:
    """
    Extract installable PyPI specifiers from manifest contents.

    Only safe, name-based specs survive. URL/path/editable installs rejected.
    """
    raw: list[str] = []
    for name, content in (dependency_files or {}).items():
        if not content:
            continue
        lname = name.lower()
        if lname.endswith("pyproject.toml"):
            raw.extend(_parse_pyproject(content))
        elif lname.endswith(".txt") or lname == "pipfile":
            raw.extend(_parse_requirements_txt(content))
        # setup.py / setup.cfg / poetry.lock intentionally skipped —
        # parsing is ambiguous, and any spec we miss simply falls back to automock.

    out: list[str] = []
    seen: set[str] = set()
    for spec in raw:
        norm = _normalize_spec(spec)
        if norm is None:
            continue
        key = norm.split("[", 1)[0].split("<")[0].split(">")[0].split("=")[0].split("!")[0].split("~")[0].strip().lower()
        if key in seen:
            continue
        seen.add(key)
        out.append(norm)
        if len(out) >= MAX_SPECS:
            break
    return out


def _parse_pyproject(content: str) -> list[str]:
    try:
        data = tomllib.loads(content)
    except Exception:
        return []
    specs: list[str] = []
    project = data.get("project", {}) if isinstance(data, dict) else {}
    deps = project.get("dependencies") or []
    if isinstance(deps, list):
        specs.extend(str(d) for d in deps if isinstance(d, str))
    opt = project.get("optional-dependencies") or {}
    if isinstance(opt, dict):
        for group in opt.values():
            if isinstance(group, list):
                specs.extend(str(d) for d in group if isinstance(d, str))
    return specs


def _parse_requirements_txt(content: str) -> list[str]:
    specs: list[str] = []
    for line in content.splitlines():
        s = line.split("#", 1)[0].strip()
        if not s:
            continue
        if s.startswith("-"):  # -r, -e, -c, --index-url, etc.
            continue
        # Strip environment markers (`pkg; python_version<'3.11'`)
        s = s.split(";", 1)[0].strip()
        if not s:
            continue
        specs.append(s)
    return specs


def _normalize_spec(spec: str) -> str | None:
    s = spec.strip()
    if not s:
        return None
    low = s.lower()
    # Reject URL/path/editable specs outright.
    for bad in ("git+", "http://", "https://", "file:", "./", "../", "-e ", "/"):
        if bad in low:
            return None
    # Reject PEP 440 direct refs (`name @ url`).
    if "@" in s:
        return None
    # Split name from tail.
    m = re.match(r"^([A-Za-z0-9][A-Za-z0-9._-]{0,63})(.*)$", s)
    if not m:
        return None
    name, tail = m.group(1), m.group(2).strip()
    if not _NAME_RE.match(name):
        return None
    if tail and not _SPEC_TAIL_RE.match(tail):
        return None
    return name + tail


def _cache_key(specs: list[str]) -> str:
    payload = "\n".join(sorted(specs)) + f"|py=3.12|img={BUILDER_IMAGE}"
    return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[:16]


def _cache_path(key: str) -> pathlib.Path:
    return CACHE_ROOT / key


def _cache_valid(path: pathlib.Path) -> bool:
    marker = path / ".ok"
    if not marker.exists():
        return False
    try:
        age = time.time() - marker.stat().st_mtime
    except OSError:
        return False
    return age < CACHE_TTL_SECONDS


def prepare_snapshot(
    dependency_files: dict[str, str],
    *,
    include_prior_pin: bool = True,
    anchor_name: str | None = None,
    anchor_version: str | None = None,
) -> str | None:
    """
    Return path to a populated deps directory, or None if we couldn't install.
    Cached by spec-set hash with 24h TTL.

    When include_prior_pin is True and pyproject declares a PyPI-published
    project name, the *prior* released version of that project is added to the
    install set. This closes the receiver-runtime gap: PR code can import the
    package's native bindings / siblings (e.g. datafusion._internal) even
    though the PR's modifications to the package itself are only visible via
    the generated target.py in /workspace.
    """
    specs = parse_dep_specs(dependency_files)
    prior_name: str | None = None
    prior_version: str | None = None
    if include_prior_pin:
        prior_name = extract_pr_package_name(dependency_files)
        if prior_name:
            prior_version = fetch_latest_pypi_version(prior_name)
            if prior_version:
                pin = f"{prior_name}=={prior_version}"
                if not any(s.lower().startswith(prior_name.lower()) for s in specs):
                    specs.append(pin)
                    log.info("dep_installer", "prior pin added", spec=pin)
    # Caller-provided anchor wins over heuristic.
    effective_anchor_name = anchor_name or prior_name
    effective_anchor_version = anchor_version or prior_version
    if not specs:
        return None
    key = _cache_key(specs)
    target = _cache_path(key)
    if _cache_valid(target):
        log.info("dep_installer", "cache hit", key=key, deps=len(specs))
        return str(target)

    if not DOCKER_AVAILABLE:
        log.warn("dep_installer", "docker unavailable, skipping install")
        return None

    try:
        client = docker.from_env()
        client.ping()
    except Exception as e:
        log.warn("dep_installer", "docker not reachable", error=str(e))
        return None

    try:
        client.images.get(BUILDER_IMAGE)
    except ImageNotFound:
        log.info("dep_installer", "pulling builder image", image=BUILDER_IMAGE)
        try:
            client.images.pull(BUILDER_IMAGE)
        except Exception as e:
            log.warn("dep_installer", "pull failed", error=str(e))
            return None
    except Exception as e:
        log.warn("dep_installer", "image check failed", error=str(e))
        return None

    host_staging = pathlib.Path(tempfile.mkdtemp(prefix="logomesh_deps_", dir="/tmp"))
    os.chmod(host_staging, 0o777)
    try:
        exit_code, logs, duration = _run_install_container(
            client, _build_install_cmd(specs), host_staging
        )
        # Resolution-impossible failures often come from the prior-pin spec
        # (e.g. `hydra_zen==0.16.0` whose transitive `hydra-core>=1.2` fights
        # `antlr4-python3-runtime==4.9.*`). Drop the pin and retry once — the
        # PR's own code is still inspected via target.py; we just lose the
        # ability to import siblings of the published package.
        if exit_code != 0 and effective_anchor_name and "ResolutionImpossible" in logs:
            anchor_lower = effective_anchor_name.lower().replace("_", "-")
            fallback_specs = [
                s for s in specs
                if s.lower().replace("_", "-").split("==")[0] != anchor_lower
            ]
            if fallback_specs and len(fallback_specs) < len(specs):
                log.info("dep_installer", "retry without anchor pin",
                         anchor=effective_anchor_name, specs=len(fallback_specs))
                for child in host_staging.iterdir():
                    if child.is_dir():
                        shutil.rmtree(child, ignore_errors=True)
                    else:
                        try: child.unlink()
                        except OSError: pass
                exit_code, logs, duration = _run_install_container(
                    client, _build_install_cmd(fallback_specs), host_staging
                )
        if exit_code != 0:
            try:
                dump = pathlib.Path("/tmp/logomesh_dep_install_errors")
                dump.mkdir(exist_ok=True)
                (dump / f"{key}.log").write_text(logs)
            except Exception:
                pass
            log.warn(
                "dep_installer",
                "install failed",
                exit_code=exit_code,
                duration=round(duration, 2),
                tail=logs[-1200:],
            )
            return None

        # Size check: refuse to cache if snapshot blew past the cap.
        total = _dir_size(host_staging)
        if total > MAX_SNAPSHOT_BYTES:
            log.warn("dep_installer", "snapshot too large", bytes=total, cap=MAX_SNAPSHOT_BYTES)
            return None

        # ---- Verify + date-bounded repair ----
        top_pkgs = _list_top_packages(host_staging)
        ok, failures = _verify_snapshot(client, host_staging, top_pkgs)
        if not ok:
            failure_tail = "; ".join(f"{n}: {m[:120]}" for n, m in failures)[:600]
            log.warn("dep_installer", "verify failed (initial)",
                     failures=len(failures), detail=failure_tail)

            # Only attempt a repair if we know an anchor package + version AND
            # at least one failure matches an ABI-style pattern (otherwise a
            # date-pin is unlikely to help).
            abi_hit = any(
                any(p in msg for p in _ABI_ERROR_PATTERNS) for _, msg in failures
            )
            if abi_hit:
                # Two generic levers, applied in one retry:
                #   (a) Import-level inference: packages may ship no Requires-Dist
                #       (e.g. pyarrow-24), so scan .py imports for unresolved names
                #       and add them as specs.
                #   (b) Date-bounded constraints: if we have an anchor, pin every
                #       installed dep to its latest version released on/before the
                #       anchor's release date.
                inferred = _infer_missing_dep_specs(
                    host_staging,
                    error_hints=_extract_dep_names_from_errors(failures),
                )
                constraints = ""
                cutoff = None
                if effective_anchor_name and effective_anchor_version:
                    cutoff = _fetch_release_date(
                        effective_anchor_name, effective_anchor_version
                    )
                    if cutoff:
                        exclude = {effective_anchor_name.lower().replace("_", "-")}
                        constraints = _generate_date_constraints(
                            host_staging, cutoff, exclude
                        )

                if not inferred and not constraints:
                    log.info("dep_installer", "repair skipped — no generic levers apply",
                             anchor=effective_anchor_name)
                    return None

                repair_specs = list(specs)
                for s in inferred:
                    if not any(s == spec.split("==")[0].split("<")[0].split(">")[0].lower()
                               for spec in repair_specs):
                        repair_specs.append(s)

                log.info("dep_installer", "repair attempt",
                         anchor=effective_anchor_name, version=effective_anchor_version,
                         cutoff=cutoff, inferred=len(inferred),
                         constraint_lines=len(constraints.splitlines()) if constraints else 0)

                # Wipe staging so pip --target=/deps reinstalls cleanly.
                for child in host_staging.iterdir():
                    if child.is_dir():
                        shutil.rmtree(child, ignore_errors=True)
                    else:
                        try: child.unlink()
                        except OSError: pass
                exit_code2, logs2, dur2 = _run_install_container(
                    client,
                    _build_install_cmd(repair_specs, constraints=constraints or None),
                    host_staging,
                )
                if exit_code2 != 0:
                    log.warn(
                        "dep_installer", "repair install failed",
                        exit_code=exit_code2, duration=round(dur2, 2),
                        tail=logs2[-800:],
                    )
                    return None
                total = _dir_size(host_staging)
                if total > MAX_SNAPSHOT_BYTES:
                    log.warn("dep_installer", "repaired snapshot too large",
                             bytes=total, cap=MAX_SNAPSHOT_BYTES)
                    return None
                top_pkgs = _list_top_packages(host_staging)
                ok2, failures2 = _verify_snapshot(client, host_staging, top_pkgs)
                if not ok2:
                    log.warn(
                        "dep_installer", "verify failed after repair",
                        failures=len(failures2),
                        detail="; ".join(f"{n}: {m[:120]}" for n, m in failures2)[:600],
                    )
                    return None
                log.info("dep_installer", "repair succeeded",
                         anchor=effective_anchor_name,
                         added=len(inferred), cutoff=cutoff)
            else:
                # No ABI signal → don't cache a broken snapshot.
                return None

        CACHE_ROOT.mkdir(parents=True, exist_ok=True)
        if target.exists():
            shutil.rmtree(target, ignore_errors=True)
        shutil.move(str(host_staging), str(target))
        host_staging = None  # moved
        (target / ".ok").write_text(json.dumps({"specs": specs, "ts": time.time()}))
        log.info(
            "dep_installer",
            "snapshot ready",
            key=key,
            deps=len(specs),
            bytes=total,
            duration=round(duration, 2),
        )
        return str(target)
    except Exception as e:
        log.warn("dep_installer", "builder exception", error=str(e))
        return None
    finally:
        if host_staging is not None:
            shutil.rmtree(host_staging, ignore_errors=True)


def prepare_wheel_overlay_snapshot(
    dependency_files: dict[str, str],
    changed_sources: dict[str, str],
    *,
    pypi_version: str | None = None,
) -> str | None:
    """
    Wheel + .py overlay: install the PR's OWN package from PyPI (wheel only),
    then overlay the PR's changed .py files on top, remapped to their
    in-package paths.

    Rationale: for PRs against native-extension packages (datafusion,
    pydantic-core, lxml), building from source is slow/brittle. If the diff is
    pure-Python we can install the published wheel (native bindings + siblings
    intact) and patch only the changed .py files. Sibling imports resolve
    against PR content, not the wheel's copy.

    Returns a path suitable for passing as `deps_snapshot` to Sandbox.run, or
    None if overlay isn't possible (no package name, no wheel, no mappable
    files). Snapshot dir is a *per-call copy* — caller owns cleanup via TTL
    sweep; cache dir is not mutated.
    """
    pkg_name = extract_pr_package_name(dependency_files)
    if not pkg_name:
        return None
    if not changed_sources:
        return None

    overlay_map = _map_changed_to_package_paths(pkg_name, changed_sources)
    if not overlay_map:
        log.info("dep_installer", "overlay skipped: no mappable files", pkg=pkg_name)
        return None

    version = pypi_version or fetch_latest_pypi_version(pkg_name)
    if not version:
        log.info("dep_installer", "overlay skipped: pypi lookup failed", pkg=pkg_name)
        return None

    # Build a single-spec pin and reuse the wheel install path.
    wheel_specs = [f"{pkg_name}=={version}"]
    key = _cache_key(wheel_specs)
    wheel_cache = _cache_path(key)
    if not _cache_valid(wheel_cache):
        produced = prepare_snapshot(
            {"__wheel_only__.txt": f"{pkg_name}=={version}\n"},
            include_prior_pin=False,
            anchor_name=pkg_name,
            anchor_version=version,
        )
        if not produced:
            log.info("dep_installer", "overlay skipped: wheel install failed", pkg=pkg_name, version=version)
            return None
        wheel_cache = pathlib.Path(produced)

    overlay_hash = hashlib.sha256(
        "\n".join(f"{p}\0{hashlib.sha256(c.encode('utf-8','replace')).hexdigest()}"
                  for p, c in sorted(overlay_map.items())).encode("utf-8", "replace")
    ).hexdigest()[:12]
    overlay_dir = CACHE_ROOT / f"overlay_{key}_{overlay_hash}"
    if _cache_valid(overlay_dir):
        log.info("dep_installer", "overlay cache hit", pkg=pkg_name, version=version, files=len(overlay_map))
        return str(overlay_dir)

    staging = pathlib.Path(tempfile.mkdtemp(prefix="logomesh_overlay_", dir="/tmp")).resolve()
    try:
        shutil.copytree(str(wheel_cache), str(staging), dirs_exist_ok=True)
        applied = 0
        for pkg_rel, content in overlay_map.items():
            dest = (staging / pkg_rel).resolve()
            if not dest.is_relative_to(staging):
                log.info("dep_installer", "overlay path traversal blocked", path=pkg_rel)
                continue
            dest.parent.mkdir(parents=True, exist_ok=True)
            with open(dest, "w", encoding="utf-8", errors="backslashreplace") as f:
                f.write(content)
            applied += 1
        if applied == 0:
            shutil.rmtree(staging, ignore_errors=True)
            return None

        CACHE_ROOT.mkdir(parents=True, exist_ok=True)
        if overlay_dir.exists():
            shutil.rmtree(overlay_dir, ignore_errors=True)
        shutil.move(str(staging), str(overlay_dir))
        (overlay_dir / ".ok").write_text(
            json.dumps({"pkg": pkg_name, "version": version, "files": sorted(overlay_map.keys()), "ts": time.time()})
        )
        log.info(
            "dep_installer", "overlay snapshot ready",
            pkg=pkg_name, version=version, files=applied,
        )
        return str(overlay_dir)
    except Exception as e:
        import traceback as _tb
        log.warn("dep_installer", "overlay failed", error=str(e), tb=_tb.format_exc()[-600:])
        shutil.rmtree(staging, ignore_errors=True)
        return None


def _map_changed_to_package_paths(
    pkg_name: str, changed_sources: dict[str, str]
) -> dict[str, str]:
    """
    Map repo-relative paths to package-relative paths under /deps.

    Accepts common layouts:
      - flat:        `<pkg>/module.py`                 -> `<pkg>/module.py`
      - src-layout:  `src/<pkg>/module.py`             -> `<pkg>/module.py`
      - nested:      `python/<pkg>/module.py`          -> `<pkg>/module.py`
    Underscored/dashed PyPI names match their import name (dash→underscore).
    """
    import_name = pkg_name.replace("-", "_").lower()
    out: dict[str, str] = {}
    for repo_path, content in changed_sources.items():
        if not repo_path.endswith(".py"):
            continue
        parts = repo_path.replace("\\", "/").split("/")
        pkg_index = None
        for i, p in enumerate(parts):
            if p.lower() == import_name:
                pkg_index = i
                break
        if pkg_index is None:
            continue
        pkg_rel = "/".join(parts[pkg_index:])
        out[pkg_rel] = content
    return out


def _build_install_cmd(specs: Iterable[str], *, constraints: str | None = None) -> str:
    # Quote each spec to prevent shell injection. Names already regex-validated;
    # this is belt-and-suspenders.
    quoted = " ".join("'" + s.replace("'", "'\\''") + "'" for s in specs)
    constraint_flag = ""
    if constraints:
        # constraints contents written to /tmp/constraints.txt inside builder via heredoc
        # shell-quote the contents so embedded quotes/newlines survive
        constraint_flag = "--constraint=/tmp/constraints.txt "
    body = (
        "pip install "
        "--only-binary=:all: "
        "--no-compile "
        "--no-input "
        "--disable-pip-version-check "
        f"{constraint_flag}"
        "--target=/deps "
        f"{quoted}"
    )
    if constraints:
        # Write constraints file before invoking pip. Escape via base64 to avoid
        # shell-quoting pain with arbitrary content.
        import base64
        encoded = base64.b64encode(constraints.encode("utf-8")).decode("ascii")
        body = (
            f"echo '{encoded}' | base64 -d > /tmp/constraints.txt && " + body
        )
    return body


# --------------------------------------------------------------------------
# Post-install verification + auto-constraint re-solve
# --------------------------------------------------------------------------
# Sequence:
#   1. Install specs normally.
#   2. Smoke-import every top-level package in the snapshot inside a fresh
#      builder container. A non-ModuleNotFoundError (e.g. ABI mismatch,
#      DLL load failure) means the snapshot is broken.
#   3. If broken AND we know the "anchor" package (the overlay target, or
#      the prior-pin), fetch its PyPI release date, derive per-dep upper
#      bounds from that date, and reinstall with --constraint.
#   4. Re-verify. Broken after retry → drop the snapshot.

_ABI_ERROR_PATTERNS = (
    "ABI", "abi", "multiarray", "_ARRAY_API", "PyCapsule", "undefined symbol",
    "incompatible", "built against", "cannot import name", "DLL load failed",
)


def _list_top_packages(snapshot_path: pathlib.Path) -> list[str]:
    """Top-level importable package/module names inside a /deps-style snapshot.

    Treats:
      - directories with __init__.py as packages
      - .py files (not starting with _) as modules
    Skips *.dist-info / *.egg-info / __pycache__.
    """
    out: list[str] = []
    if not snapshot_path.is_dir():
        return out
    for entry in sorted(snapshot_path.iterdir()):
        name = entry.name
        if name.startswith("_") or name.startswith("."):
            continue
        if name.endswith(".dist-info") or name.endswith(".egg-info"):
            continue
        if entry.is_dir():
            if (entry / "__init__.py").is_file():
                out.append(name)
        elif entry.is_file() and name.endswith(".py"):
            out.append(name[:-3])
    return out


def _read_installed_versions(snapshot_path: pathlib.Path) -> dict[str, str]:
    """Map dist name -> installed version, read from *.dist-info/METADATA."""
    versions: dict[str, str] = {}
    if not snapshot_path.is_dir():
        return versions
    for entry in snapshot_path.iterdir():
        if not entry.name.endswith(".dist-info") or not entry.is_dir():
            continue
        meta = entry / "METADATA"
        if not meta.is_file():
            continue
        try:
            text = meta.read_text(encoding="utf-8", errors="replace")
        except OSError:
            continue
        name = version = None
        for line in text.splitlines():
            if line.startswith("Name:"):
                name = line.split(":", 1)[1].strip()
            elif line.startswith("Version:"):
                version = line.split(":", 1)[1].strip()
            if name and version:
                break
        if name and version:
            versions[name.lower().replace("_", "-")] = version
    return versions


def _verify_snapshot(
    client, snapshot_path: pathlib.Path, top_packages: list[str]
) -> tuple[bool, list[tuple[str, str]]]:
    """Run `python -c "import X"` for each top-level package in a builder
    container. Returns (ok, failures). `ok` is True only when every import
    succeeds; ModuleNotFoundError is treated as benign (not counted as failure)
    because it typically signals transitive-only artefacts, not ABI breakage."""
    if not top_packages:
        return True, []
    # Reproduces the runtime environment: /deps on sys.path PLUS an auto-mock
    # meta-path finder for anything missing (same policy the sandbox uses).
    # Without this, a package like pyarrow that lazy-imports numpy will pass
    # verify standalone, then crash at runtime when automock hands back a
    # MagicMock and the C-extension tries to use it.
    py = (
        "import importlib, sys\n"
        "from importlib.abc import MetaPathFinder\n"
        "from importlib.machinery import ModuleSpec\n"
        "from unittest.mock import MagicMock\n"
        f"_pkgs = {top_packages!r}\n"
        "sys.path.insert(0, '/deps')\n"
        "class _BFM(MagicMock):\n"
        "    def __mro_entries__(self, bases):\n"
        "        return (type('_MB_' + hex(id(self)), (object,), {}),)\n"
        "class _L:\n"
        "    def create_module(self, spec): return None\n"
        "    def exec_module(self, m):\n"
        "        mk = _BFM()\n"
        "        m.__dict__.update({k: getattr(mk, k) for k in dir(mk) if not k.startswith('_')})\n"
        "        m.__path__ = []; m.__all__ = []\n"
        "        m.__getattr__ = lambda n: _BFM()\n"
        "class _F(MetaPathFinder):\n"
        "    def find_spec(self, name, path, target=None):\n"
        "        if name in sys.modules: return None\n"
        "        return ModuleSpec(name, _L(), is_package=True)\n"
        "sys.meta_path.append(_F())\n"
        "_BENIGN = ('metaclass conflict', '__mro_entries__ must return a tuple', 'duplicate base class', \"has no attribute 'closesocket'\", \"module '_multiprocessing' has no attribute\", \"expected string or bytes-like object\", \"_BFM\", \"_MB_\")\n"
        "for _p in _pkgs:\n"
        "    try:\n"
        "        importlib.import_module(_p)\n"
        "    except ModuleNotFoundError:\n"
        "        continue\n"
        "    except BaseException as _e:\n"
        "        _msg = (type(_e).__name__ + ': ' + str(_e)).splitlines()[0][:400]\n"
        "        if any(b in _msg for b in _BENIGN):\n"
        "            continue\n"
        "        print('LM_IMPORT_FAIL ' + _p + ' :: ' + _msg)\n"
    )
    import base64 as _b64
    encoded = _b64.b64encode(py.encode("utf-8")).decode("ascii")
    cmd = (
        f"echo '{encoded}' | base64 -d > /tmp/verify.py && "
        "python3 /tmp/verify.py"
    )
    container = None
    try:
        container = client.containers.create(
            image=BUILDER_IMAGE,
            command=["sh", "-c", cmd],
            working_dir="/tmp",
            mem_limit=BUILDER_MEM,
            pids_limit=256,
            cap_drop=["ALL"],
            security_opt=["no-new-privileges"],
            user="nobody",
            network_mode="none",
            volumes={str(snapshot_path): {"bind": "/deps", "mode": "ro"}},
            detach=True,
            tmpfs={"/tmp": "size=64m"},
        )
        container.start()
        try:
            container.wait(timeout=BUILDER_TIMEOUT)
        except Exception:
            pass
        try:
            raw = container.logs(stdout=True, stderr=True).decode("utf-8", errors="replace")
        except Exception:
            raw = ""
    except Exception as e:
        log.warn("dep_installer", "verify container failed", error=str(e))
        return True, []  # fail-open: don't block pipeline on verify infra errors
    finally:
        if container is not None:
            try: container.stop(timeout=1)
            except Exception: pass
            try: container.remove(force=True)
            except Exception: pass

    failures: list[tuple[str, str]] = []
    for line in raw.splitlines():
        if not line.startswith("LM_IMPORT_FAIL "):
            continue
        rest = line[len("LM_IMPORT_FAIL "):]
        if " :: " in rest:
            pkg, msg = rest.split(" :: ", 1)
        else:
            pkg, msg = rest, ""
        failures.append((pkg.strip(), msg.strip()))
    return (not failures), failures


def _fetch_release_date(name: str, version: str, timeout: float = 6.0) -> str | None:
    """ISO upload timestamp of the first file of (name, version) on PyPI, or None."""
    url = f"https://pypi.org/pypi/{name}/{version}/json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "logomesh-dep-installer"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError, OSError):
        return None
    urls = data.get("urls") or []
    timestamps = [u.get("upload_time_iso_8601") or u.get("upload_time") for u in urls]
    timestamps = [t for t in timestamps if isinstance(t, str)]
    if not timestamps:
        return None
    # Earliest upload of the release
    return min(timestamps)


def _latest_version_before(name: str, cutoff_iso: str, timeout: float = 6.0) -> str | None:
    """Max PyPI version of `name` whose earliest upload timestamp <= cutoff.

    Sorts versions via PEP 440 when `packaging` is available; falls back to
    a numeric tuple sort otherwise (close enough for mainstream libraries)."""
    url = f"https://pypi.org/pypi/{name}/json"
    try:
        req = urllib.request.Request(url, headers={"User-Agent": "logomesh-dep-installer"})
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError, OSError):
        return None
    releases = data.get("releases") or {}
    candidates: list[tuple[str, str]] = []  # (version, earliest_upload)
    for ver, files in releases.items():
        if not re.match(r"^[0-9][0-9A-Za-z.\-+!]*$", ver):
            continue
        stamps = [f.get("upload_time_iso_8601") or f.get("upload_time") for f in files or []]
        stamps = [s for s in stamps if isinstance(s, str)]
        if not stamps:
            continue
        earliest = min(stamps)
        if earliest <= cutoff_iso:
            candidates.append((ver, earliest))
    if not candidates:
        return None
    try:
        from packaging.version import Version
        return max((c[0] for c in candidates), key=Version)
    except Exception:
        def _key(v: str) -> tuple:
            out: list[int] = []
            for p in re.split(r"[.\-+]", v):
                try:
                    out.append(int(p))
                except ValueError:
                    return tuple(out)
            return tuple(out)
        return max((c[0] for c in candidates), key=_key)


def _scan_imports(snapshot_path: pathlib.Path, max_files: int = 4000) -> set[str]:
    """Unconditional module-scope imports from each package's __init__.py.

    Rationale: `import <pkg>` executes `<pkg>/__init__.py` at minimum — its
    top-level imports are the hard dependencies. Submodule files (e.g.
    `pandas_compat.py`, `numba_support.py`) often reference optional peers
    that only matter if those submodules are explicitly imported; scanning
    them would force-install a runaway transitive closure. Stops at __init__
    to keep the inferred set disciplined.

    Dist-info / __pycache__ dirs skipped; soft file cap prevents pathological
    scans on oversized snapshots.
    """
    import ast
    seen: set[str] = set()
    count = 0
    if not snapshot_path.is_dir():
        return seen
    for root, dirs, files in os.walk(snapshot_path):
        dirs[:] = [
            d for d in dirs
            if not (d.endswith(".dist-info") or d.endswith(".egg-info")
                    or d == "__pycache__" or d.startswith("."))
        ]
        for f in files:
            if f != "__init__.py":
                continue
            count += 1
            if count > max_files:
                return seen
            p = pathlib.Path(root, f)
            try:
                src = p.read_text(encoding="utf-8", errors="replace")
            except OSError:
                continue
            try:
                tree = ast.parse(src)
            except SyntaxError:
                continue
            for stmt in tree.body:  # module-scope only
                if isinstance(stmt, ast.Import):
                    for alias in stmt.names:
                        if alias.name:
                            seen.add(alias.name.split(".", 1)[0])
                elif isinstance(stmt, ast.ImportFrom):
                    if stmt.level == 0 and stmt.module:
                        seen.add(stmt.module.split(".", 1)[0])
    return seen


# A short list of well-known PyPI distribution names that differ from their
# import name. Purely a data table — no package-specific branching elsewhere.
_IMPORT_TO_DIST = {
    "cv2": "opencv-python",
    "PIL": "pillow",
    "yaml": "pyyaml",
    "sklearn": "scikit-learn",
    "bs4": "beautifulsoup4",
    "skimage": "scikit-image",
    "serial": "pyserial",
    "MySQLdb": "mysqlclient",
    "OpenSSL": "pyopenssl",
    "attr": "attrs",
    "google": "google-api-core",
    "grpc": "grpcio",
}


def _extract_dep_names_from_errors(failures: list[tuple[str, str]]) -> set[str]:
    """Pull module names out of ImportError / ABI-style failure messages.

    Patterns:
      - "No module named 'X'"
      - "X._...  failed to import"       (numpy._core.multiarray failed to import)
      - "requires X version"             (Numba requires SciPy version 1.0 ...)
      - "cannot import name '...' from 'X'"
    Names are normalized to lowercase for later PyPI lookup.
    """
    out: set[str] = set()
    pats = [
        re.compile(r"No module named ['\"]([A-Za-z_][\w]*)"),
        re.compile(r"cannot import name ['\"][^'\"]+['\"] from ['\"]([A-Za-z_][\w]*)"),
        re.compile(r"([A-Za-z_][\w]*)(?:\.[\w]+)+\s+failed to import", re.IGNORECASE),
        re.compile(r"\brequires\s+([A-Za-z][\w]*)\s+version", re.IGNORECASE),
    ]
    for _pkg, msg in failures:
        for pat in pats:
            for m in pat.finditer(msg or ""):
                name = m.group(1)
                if name:
                    out.add(name)
    return out


def _infer_missing_dep_specs(
    snapshot_path: pathlib.Path,
    cap: int = 12,
    error_hints: set[str] | None = None,
) -> list[str]:
    """Build a PyPI-spec list for imports referenced by installed code but
    missing from the snapshot. Filters: stdlib names, already-installed
    packages, names that don't exist on PyPI. Capped at `cap` to bound install
    cost and to avoid pulling a PR's own subpackages.
    """
    stdlib = set(getattr(sys, "stdlib_module_names", ())) | _EXTRA_BUILTINS
    installed_names = set(_list_top_packages(snapshot_path))
    installed_dists = set(_read_installed_versions(snapshot_path).keys())
    imported = _scan_imports(snapshot_path) | (error_hints or set())

    missing = {
        name for name in imported
        if name
        and name not in stdlib
        and name not in installed_names
        and not name.startswith("_")
        and _NAME_RE.match(name)
    }
    specs: list[str] = []
    for name in sorted(missing):
        dist = _IMPORT_TO_DIST.get(name, name).lower().replace("_", "-")
        if dist in installed_dists or dist in (s.lower() for s in specs):
            continue
        # Only accept names that actually resolve on PyPI (cheap probe).
        if not fetch_latest_pypi_version(dist):
            continue
        specs.append(dist)
        if len(specs) >= cap:
            break
    return specs


# Module names that are builtins or part of CPython internals but may be
# absent from `sys.stdlib_module_names` on older releases. Additive only.
_EXTRA_BUILTINS: set[str] = {
    "__future__", "__main__", "builtins", "sys", "os", "typing",
}


def _generate_date_constraints(
    snapshot_path: pathlib.Path, anchor_date: str, exclude: set[str]
) -> str:
    """Produce a `--constraint`-style text pinning every installed dep (except
    names in `exclude`) to the max version released on/before `anchor_date`."""
    lines: list[str] = []
    for dist, _installed in _read_installed_versions(snapshot_path).items():
        if dist in exclude:
            continue
        pin = _latest_version_before(dist, anchor_date)
        if not pin:
            continue
        lines.append(f"{dist}=={pin}")
    return "\n".join(lines) + ("\n" if lines else "")


def _run_install_container(
    client, cmd: str, host_staging: pathlib.Path
) -> tuple[int, str, float]:
    """Shared builder invocation — returns (exit_code, logs, duration)."""
    container = None
    start = time.time()
    try:
        container = client.containers.create(
            image=BUILDER_IMAGE,
            command=["sh", "-c", cmd],
            working_dir="/build",
            mem_limit=BUILDER_MEM,
            pids_limit=256,
            cap_drop=["ALL"],
            security_opt=["no-new-privileges"],
            user="nobody",
            volumes={str(host_staging): {"bind": "/deps", "mode": "rw"}},
            detach=True,
            environment={
                "PIP_DISABLE_PIP_VERSION_CHECK": "1",
                "PIP_NO_CACHE_DIR": "1",
                "HOME": "/tmp",
            },
            tmpfs={"/tmp": "size=1024m", "/build": "size=16m"},
        )
        container.start()
        try:
            result = container.wait(timeout=BUILDER_TIMEOUT)
            exit_code = int(result.get("StatusCode", 1))
        except Exception as e:
            log.warn("dep_installer", "wait failed", error=str(e))
            exit_code = 1
        try:
            logs = container.logs(stdout=True, stderr=True).decode("utf-8", errors="replace")
        except Exception:
            logs = ""
    finally:
        if container is not None:
            try: container.stop(timeout=1)
            except Exception: pass
            try: container.remove(force=True)
            except Exception: pass
    return exit_code, logs, time.time() - start


def _dir_size(path: pathlib.Path) -> int:
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                continue
    return total
