"""
Sandbox for executing PR code in isolation.

Two modes:
1. Docker (secure): isolated container, resource limits, no network
2. Subprocess (fallback): local execution when Docker unavailable

For PR review, pass source files as a dict: {filename: content}.
The sandbox runs pytest against the provided test code.
"""

import json
import os
import pathlib
import sys
import tempfile
import time
import subprocess
import shutil
import re
import uuid

try:
    from logomesh_log import log
except ImportError:
    class _FallbackLog:
        def info(self, *a, **kw): pass
        def warn(self, *a, **kw): pass
        def error(self, *a, **kw): pass
        def exception(self, *a, **kw): pass
    log = _FallbackLog()

try:
    from core.pii_redactor import redact_text
except ImportError:
    # Sandbox can be exercised standalone in some test setups before the
    # core package is on sys.path. Fall back to a no-op so the sandbox
    # itself stays importable; the chokepoint is exercised from the
    # integration paths where ``core`` is always available.
    def redact_text(text):  # type: ignore[no-redef]
        return text

MAX_FILE_BYTES = int(os.getenv("SANDBOX_MAX_FILE_BYTES", "512000"))
MAX_FILES = int(os.getenv("SANDBOX_MAX_FILES", "100"))
MAX_TOTAL_BYTES = int(os.getenv("SANDBOX_MAX_TOTAL_BYTES", "5000000"))
MAX_OUTPUT_BYTES = int(os.getenv("SANDBOX_MAX_OUTPUT_BYTES", "1000000"))  # 1MB cap on raw output from container

# Time-Travel Trace: pytest hook that captures local-variable state at the
# moment a test's exception lands inside target.py. Writes a single JSON keyed
# by pytest nodeid. Snapshot is deterministic (repr + size caps), no LLM.
_TRACE_HOOK = '''\
import json as _lm_json, os as _lm_os, pytest as _lm_pytest

_LM_TRACES = {}
_LM_TRACE_FILE = _lm_os.environ.get("LOGOMESH_TRACE_FILE", "/tmp/logomesh_traces.json")
_LM_VAR_CAP = 200
_LM_TRACE_CAP = 3500

def _lm_repr(v):
    try:
        r = repr(v)
    except Exception:
        r = "<unreprable " + type(v).__name__ + ">"
    if len(r) > _LM_VAR_CAP:
        r = r[:_LM_VAR_CAP - 3] + "..."
    return r

@_lm_pytest.hookimpl(tryfirst=True)
def pytest_exception_interact(node, call, report):
    try:
        tb = getattr(call.excinfo, "tb", None)
        target_frame = None
        target_lineno = 0
        while tb is not None:
            co = tb.tb_frame.f_code
            fname = co.co_filename or ""
            if "target.py" in fname and not fname.endswith("test_target.py"):
                target_frame = tb.tb_frame
                target_lineno = tb.tb_lineno
            tb = tb.tb_next
        if target_frame is None:
            return
        locals_out = {}
        total = 0
        for k, v in list(target_frame.f_locals.items()):
            if k.startswith("__") and k.endswith("__"):
                continue
            r = _lm_repr(v)
            if total + len(r) + len(k) > _LM_TRACE_CAP:
                break
            locals_out[k] = r
            total += len(r) + len(k)
        nodeid = getattr(report, "nodeid", "") or getattr(node, "nodeid", "")
        _LM_TRACES[nodeid] = {
            "lineno": target_lineno,
            "func": target_frame.f_code.co_name,
            "locals": locals_out,
        }
    except Exception:
        pass

def pytest_sessionfinish(session, exitstatus):
    # Suffix with pid so pytest-xdist workers don't clobber each other's
    # traces (they inherit the same LOGOMESH_TRACE_FILE env var).
    try:
        with open(_LM_TRACE_FILE + "." + str(_lm_os.getpid()), "w") as _fh:
            _lm_json.dump(_LM_TRACES, _fh)
    except Exception:
        pass
'''

# Line-Reach Coverage: lightweight per-line tracer that records which lines of
# target.py were actually executed by each test. Output at /tmp/logomesh_coverage.json.
# Used by filter_findings_by_reach() to drop tests that never reached the target file.
_ENABLE_LINE_REACH_GATE = os.getenv("ENABLE_LINE_REACH_GATE", "0").lower() not in ("0", "false", "off")

# Host path to mount as persistent Hypothesis ExampleDatabase inside container.
# When set, counterexamples found by Hypothesis survive across PR runs — the
# same known-bad input is replayed first on the next run of a similar test.
_HYPOTHESIS_DB_HOST_PATH = os.getenv("LOGOMESH_HYPOTHESIS_DB", "").strip()

# Registers a Hypothesis profile that uses the mounted /hypothesis-db directory
# when it exists. Safe no-op if Hypothesis or the mount is missing.
_HYPOTHESIS_DB_HOOK = '''\
try:
    import os as _lm_hdb_os
    from hypothesis import settings as _lm_hdb_settings
    from hypothesis.database import DirectoryBasedExampleDatabase as _LMExDB
    if _lm_hdb_os.path.isdir("/hypothesis-db") and _lm_hdb_os.access("/hypothesis-db", _lm_hdb_os.W_OK):
        _lm_hdb_settings.register_profile("logomesh_persist", database=_LMExDB("/hypothesis-db"))
        _lm_hdb_settings.load_profile("logomesh_persist")
    else:
        # Without persistent DB, force deterministic seeding so the repro-gate
        # replay sees the same counterexample as the initial run.
        _lm_hdb_settings.register_profile("logomesh_derand", database=None, derandomize=True)
        _lm_hdb_settings.load_profile("logomesh_derand")
except Exception:
    pass
'''

_COVERAGE_HOOK = '''\
import sys as _lm_sys, json as _lm_json, os as _lm_os, threading as _lm_threading

_lm_coverage = {}
_lm_current_test = _lm_threading.local()
_lm_current_test.name = None

def _lm_trace(frame, event, arg):
    if event == "line":
        fname = frame.f_code.co_filename or ""
        if "target.py" in fname and not fname.endswith("test_target.py"):
            test_name = getattr(_lm_current_test, "name", None)
            if test_name:
                _lm_coverage.setdefault(test_name, set()).add(frame.f_lineno)
    return _lm_trace

def pytest_runtest_setup(item):
    _lm_current_test.name = item.nodeid
    _lm_sys.settrace(_lm_trace)

def pytest_runtest_teardown(item, nextitem):
    _lm_sys.settrace(None)
    _lm_current_test.name = None

def pytest_unconfigure(config):
    out = {}
    for k, v in _lm_coverage.items():
        out[k] = sorted(v)
    path = _lm_os.environ.get("LOGOMESH_COVERAGE_FILE", "/tmp/logomesh_coverage.json")
    # Suffix with pid so pytest-xdist workers don't clobber each other.
    try:
        with open(path + "." + str(_lm_os.getpid()), "w") as f:
            _lm_json.dump(out, f)
    except Exception:
        pass
'''

# Conftest injected into every sandbox run. Does two things:
# 1. Adds /workspace to sys.path so `from target import *` works
# 2. Installs an import hook that auto-mocks missing packages,
#    so code that does `from myproject.utils import X` won't crash
#    on ImportError — it gets a MagicMock instead.
_CONFTEST_AUTOMOCK = '''\
import sys, os
sys.path.insert(0, "/workspace")
if os.path.isdir("/deps"):
    sys.path.insert(1, "/deps")

from unittest.mock import MagicMock
from importlib.abc import MetaPathFinder
from importlib.machinery import ModuleSpec
import types

class _BaseFriendlyMock(MagicMock):
    # Lets `class X(mocked.Thing)` succeed. Returns a UNIQUE synthetic type per
    # mock so `class X(A, B)` where A and B are both mocks doesn't trip
    # "duplicate base class object".
    def __mro_entries__(self, bases):
        return (type("_MockBase_" + hex(id(self)), (object,), {}),)

class _AutoMockLoader:
    """Loader that creates MagicMock modules."""
    def create_module(self, spec):
        return None  # use default
    def exec_module(self, module):
        mock = _BaseFriendlyMock()
        # copy mock attributes onto the real module so attribute access works
        module.__dict__.update({k: getattr(mock, k) for k in dir(mock) if not k.startswith('_')})
        module.__path__ = []  # make it a package so sub-imports work
        module.__all__ = []
        # Override __getattr__ so "from pkg import SomeClass" returns a mock,
        # not a sub-module. Without this, Python tries to import pkg.SomeClass as a
        # real module and returns a module object (not callable) when used as SomeClass().
        module.__getattr__ = lambda name: _BaseFriendlyMock()

class _AutoMockFinder(MetaPathFinder):
    """Last-resort import hook: if no other finder can locate a module, mock it."""

    def find_spec(self, fullname, path, target=None):
        if fullname in sys.modules:
            return None
        # Never mock test/conftest modules — pytest-xdist workers resolve
        # these by name across worker processes. If automock beats the real
        # file resolver (possible on xdist remote imports), pytest reports
        # "import file mismatch" and collects 0 tests.
        leaf = fullname.rsplit(".", 1)[-1]
        if leaf.startswith("test_") or leaf == "conftest":
            return None
        return ModuleSpec(fullname, _AutoMockLoader(), is_package=True)

# Append (not insert) so all real finders get first crack
sys.meta_path.append(_AutoMockFinder())
''' + _HYPOTHESIS_DB_HOOK + _TRACE_HOOK + (_COVERAGE_HOOK if _ENABLE_LINE_REACH_GATE else "")

_CONFTEST_STRICT = '''\
import sys, os
sys.path.insert(0, "/workspace")
if os.path.isdir("/deps"):
    sys.path.insert(1, "/deps")
''' + _HYPOTHESIS_DB_HOOK + _TRACE_HOOK + (_COVERAGE_HOOK if _ENABLE_LINE_REACH_GATE else "")

try:
    import docker
    from docker.errors import ContainerError, ImageNotFound, APIError
    DOCKER_AVAILABLE = True
except ImportError:
    DOCKER_AVAILABLE = False
    docker = None



class Sandbox:
    """
    Executes Python code with tests in an isolated environment.

    Docker mode: creates a fresh container per run with strict resource limits.
    Subprocess mode: uses a temp directory — NOT safe for untrusted code, but
    works for local dev without Docker.

    Usage:
        sandbox = Sandbox()
        result = sandbox.run(
            files={"module.py": source_code, "test_module.py": test_code},
            test_pattern="test_*.py"
        )
        # result = {"success": bool, "output": str, "duration": float,
        #           "passed": int, "failed": int, "total": int}
    """

    DEFAULT_IMAGE = "logomesh-startup-sandbox:latest"
    FALLBACK_IMAGE = "python:3.12-slim"
    DEFAULT_TIMEOUT = int(os.getenv("SANDBOX_TIMEOUT", "15"))

    # Allowlisted minor versions for production-runtime pinning. We refuse
    # to spin up images outside this set — unbounded image pulls = attack
    # surface + slow first-run. Add a version here only after manually
    # vetting that python:<X>-slim still ships pytest cleanly.
    _ALLOWED_PYTHON_VERSIONS: frozenset[str] = frozenset({
        "3.10", "3.11", "3.12", "3.13",
    })

    @classmethod
    def image_for_python_version(cls, python_version: str) -> str | None:
        """Map '3.11' → 'python:3.11-slim'. Returns None for unsupported.

        Pure function; safe to call without Docker available. Caller
        decides whether to use the result.
        """
        v = (python_version or "").strip()
        if v in cls._ALLOWED_PYTHON_VERSIONS:
            return f"python:{v}-slim"
        return None

    def __init__(self, image: str = DEFAULT_IMAGE, timeout: int = DEFAULT_TIMEOUT):
        self.image = image
        self.timeout = timeout
        self._docker_mode = False
        self._has_pytest = False

        if DOCKER_AVAILABLE:
            try:
                self.client = docker.from_env()
                self.client.ping()
                self._docker_mode = True
                self._ensure_image()
            except Exception as e:
                log.error("sandbox", "Docker unavailable, falling back to subprocess", error=str(e))
        else:
            log.error("sandbox", "Docker not installed, falling back to subprocess")

        # Fail fast in production: subprocess mode is NOT isolated. The
        # artifact preamble advertises a sealed Docker airgap; emitting
        # `sandbox_mode: subprocess` in a customer-facing artifact is a
        # false claim. Refuse to construct the Sandbox at all instead of
        # discovering the problem mid-webhook.
        if os.getenv("LOGOMESH_ENV", "").strip().lower() == "production" \
                and not self._docker_mode:
            raise RuntimeError(
                "LOGOMESH_ENV=production requires Docker. Subprocess mode "
                "is not isolated and would emit a false `sandbox_mode: "
                "subprocess` claim in the compliance artifact. Install "
                "Docker, or unset LOGOMESH_ENV for dev/test."
            )

    @property
    def mode(self) -> str:
        return "docker" if self._docker_mode else "subprocess"

    def _ensure_image(self) -> None:
        try:
            self.client.images.get(self.image)
            self._has_pytest = True
        except ImageNotFound:
            if self.image == self.DEFAULT_IMAGE:
                hub_image = "sz01/logomesh-sandbox:latest"
                log.info("sandbox", "local image not found, pulling from Docker Hub", image=hub_image)
                try:
                    self.client.images.pull(hub_image)
                    self.client.api.tag(hub_image, "logomesh-startup-sandbox", "latest")
                    self._has_pytest = True
                except Exception:
                    log.warn("sandbox", "Docker Hub pull failed, using fallback", image=self.FALLBACK_IMAGE)
                    self.image = self.FALLBACK_IMAGE
                    self._has_pytest = False
                    try:
                        self.client.images.get(self.image)
                    except ImageNotFound:
                        log.info("sandbox", "pulling image", image=self.image)
                        self.client.images.pull(self.image)

    def run(
        self,
        files: dict,
        test_pattern: str = "test_*.py",
        *,
        import_mode: str = "automock",
        confidence: str = "medium",
        deps_snapshot: str | None = None,
        extra_env: dict[str, str] | None = None,
        python_version: str | None = None,
    ) -> dict:
        """
        Run tests against source files in isolation.

        Args:
            files: dict of {filename: content} — include both source and test files
            test_pattern: pytest pattern to match test files
            python_version: optional minor version like "3.11" to pin the
                sandbox image to (must be in `_ALLOWED_PYTHON_VERSIONS`).
                Used when Sentry's `contexts.runtime.version` doesn't
                match the default image. Falls back to the default image
                if unrecognized; the caller is responsible for surfacing
                the mismatch in the artifact's environment_prep block.

        Returns:
            {success, output, duration, passed, failed, total}
        """
        # Per-run image override. Restored in `finally` so concurrent
        # callers don't see the swapped image leak between runs.
        _saved_image: str | None = None
        _saved_has_pytest: bool = False
        if python_version:
            override = self.image_for_python_version(python_version)
            if override and override != self.image:
                _saved_image = self.image
                _saved_has_pytest = self._has_pytest
                self.image = override
                # Pinned-version images don't have pytest preinstalled —
                # the runner will inject it via deps_snapshot or pip install.
                self._has_pytest = False
        try:
            return self._run_impl(
                files=files, test_pattern=test_pattern,
                import_mode=import_mode, confidence=confidence,
                deps_snapshot=deps_snapshot, extra_env=extra_env,
            )
        finally:
            if _saved_image is not None:
                self.image = _saved_image
                self._has_pytest = _saved_has_pytest

    def _run_impl(
        self,
        files: dict,
        test_pattern: str,
        *,
        import_mode: str,
        confidence: str,
        deps_snapshot: str | None,
        extra_env: dict[str, str] | None,
    ) -> dict:
        # Payload limits: prevent storage exhaustion from huge file dicts
        if len(files) > MAX_FILES:
            return {"success": False, "output": f"too many files ({len(files)} > {MAX_FILES})",
                    "duration": 0.0, "passed": 0, "failed": 0, "total": 0}
        total_bytes = sum(
            len(c) if isinstance(c, (bytes, bytearray))
            else len(c.encode("utf-8", errors="replace"))
            for c in files.values()
        )
        if total_bytes > MAX_TOTAL_BYTES:
            return {"success": False, "output": f"payload too large ({total_bytes} > {MAX_TOTAL_BYTES})",
                    "duration": 0.0, "passed": 0, "failed": 0, "total": 0}

        # Pre-run syntax check on all .py files so we surface the precise location
        # instead of pytest's opaque "collection failed". Covers both test files and
        # the preprocessed target (make_sandbox_importable can corrupt multi-line class
        # defs with external bases).
        for fname, content in files.items():
            if not fname.endswith(".py"):
                continue
            if isinstance(content, (bytes, bytearray)):
                # Binary .py is unsupported — skip silently rather than crashing
                # the whole run.
                continue
            try:
                compile(content, fname, "exec")
            except SyntaxError as e:
                line_no = getattr(e, "lineno", 0) or 0
                msg = f"{type(e).__name__}: {e.msg} (line {line_no})"
                src_lines = (content or "").splitlines()
                ctx = ""
                if 1 <= line_no <= len(src_lines):
                    start = max(0, line_no - 4)
                    end = min(len(src_lines), line_no + 3)
                    ctx = "\n".join(f"{i+1:4d}: {src_lines[i]}" for i in range(start, end))
                # dump the offending file so we can inspect it deterministically
                try:
                    dump_dir = "/tmp/logomesh_syntax_errors"
                    os.makedirs(dump_dir, exist_ok=True)
                    dump_path = os.path.join(dump_dir, f"{uuid.uuid4().hex[:8]}_{fname.replace('/', '_')}")
                    with open(dump_path, "w", encoding="utf-8", errors="backslashreplace") as f:
                        f.write(content)
                except Exception:
                    dump_path = ""
                log.warn(
                    "sandbox",
                    "pre-run syntax error",
                    file=fname,
                    line=line_no,
                    error=str(e.msg),
                    context=ctx,
                    dump=dump_path,
                )
                kind = "test_syntax_error" if fname.startswith("test_") else "target_syntax_error"
                return {
                    "success": False,
                    "output": f"E   {type(e).__name__}: {e.msg}\n{ctx}",
                    "duration": 0.0,
                    "passed": 0,
                    "failed": 0,
                    "total": 0,
                    "report": None,
                    "collection_error_kind": kind,
                    "collection_error_message": msg,
                }

        # Always provide a conftest that adds /workspace to sys.path
        # and optionally installs an auto-mock import hook for missing dependencies.
        if "conftest.py" not in files:
            files = dict(files)
            files["conftest.py"] = _CONFTEST_STRICT if import_mode == "strict" else _CONFTEST_AUTOMOCK

        if self._docker_mode:
            out = self._run_docker(files, test_pattern, deps_snapshot=deps_snapshot, extra_env=extra_env)
            out["sandbox_mode"] = self.mode
            out["import_mode"] = import_mode
            out["confidence"] = confidence
            return out

        # Subprocess mode is NOT safe for untrusted code — refuse in production
        if os.getenv("LOGOMESH_ENV") == "production":
            log.error("sandbox", "subprocess mode refused in production")
            return {"success": False, "output": "sandbox unavailable: Docker required in production", "import_mode": import_mode, "confidence": confidence,
                    "duration": 0.0, "passed": 0, "failed": 0, "total": 0}

        log.warn("sandbox", "subprocess mode active — NOT isolated, dev only")
        out = self._run_subprocess(files, test_pattern, deps_snapshot=deps_snapshot, extra_env=extra_env)
        out["sandbox_mode"] = self.mode
        out["import_mode"] = import_mode
        out["confidence"] = confidence
        return out

    def run_dependency_aware(
        self,
        target_source: str,
        test_code: str,
        dependency_files: dict[str, str] | None = None,
        test_pattern: str = "test_*.py",
        deps_snapshot: str | None = None,
    ) -> dict:
        """
        Two-pass strategy:
        1) strict imports (no auto-mock) for higher realism
        2) fallback to auto-mock if strict pass cannot collect tests due missing deps/imports

        If deps_snapshot is provided, it's mounted read-only at /deps inside the
        sandbox and prepended to sys.path — enabling real imports of installed
        third-party packages (e.g. pandas, datafusion) without network access.
        """
        files = {"target.py": target_source, "test_target.py": test_code}
        if dependency_files:
            files.update(dependency_files)

        strict = self.run(
            files, test_pattern=test_pattern, import_mode="strict",
            confidence="high", deps_snapshot=deps_snapshot,
        )
        if strict.get("total", 0) > 0 and not _has_import_failure(strict.get("output", "")):
            strict["dependency_mode"] = "strict_with_deps" if deps_snapshot else "strict"
            return strict

        # If strict failed due to import errors and we have no dep snapshot to help,
        # don't fall back to automock — automock stubs missing deps and produces
        # findings that are artifacts of the mock, not real bugs. Return early so
        # the pipeline logs import_unavailable and skips this file.
        strict_output = strict.get("output", "") or ""
        if _has_import_failure(strict_output) and not deps_snapshot:
            return {
                "success": False,
                "output": strict_output,
                "duration": strict.get("duration", 0.0),
                "passed": 0,
                "failed": 0,
                "total": 0,
                "dependency_mode": "import_unavailable",
                "collection_error_kind": "dependency_import_error",
                "collection_error_message": "top-level import failed; deps not installed",
            }

        fallback = self.run(
            files, test_pattern=test_pattern, import_mode="automock",
            confidence="low", deps_snapshot=deps_snapshot,
        )
        fallback["dependency_mode"] = "automock_fallback"
        fallback["strict_output_tail"] = strict_output[-1200:]
        return fallback

    def _run_docker(self, files: dict, test_pattern: str, *, deps_snapshot: str | None = None, extra_env: dict[str, str] | None = None) -> dict:
        container = None
        start = time.time()
        # write files to a host temp dir, then bind-mount into the container
        # (put_archive can't write to a read_only container, even into tmpfs mounts)
        host_dir = os.path.realpath(tempfile.mkdtemp(dir="/tmp"))
        report_name = f"report_{uuid.uuid4().hex[:8]}.json"
        trace_name = f"traces_{uuid.uuid4().hex[:8]}.json"
        coverage_name = f"coverage_{uuid.uuid4().hex[:8]}.json"
        try:
            for filename, content in files.items():
                resolved = pathlib.Path(host_dir, filename).resolve()
                if not resolved.is_relative_to(host_dir):
                    log.warn("sandbox", "path traversal blocked", filename=filename)
                    continue
                is_bytes = isinstance(content, (bytes, bytearray))
                size = len(content) if is_bytes else len(content.encode("utf-8", errors="replace"))
                if size > MAX_FILE_BYTES:
                    log.warn("sandbox", "file too large, skipping", filename=filename)
                    continue
                # Allow declared-binary payloads (e.g. state.db) to bypass the
                # text-binary heuristic. The text path keeps the original guard.
                if not is_bytes and '\x00' in content[:8192]:
                    log.warn("sandbox", "binary file, skipping", filename=filename)
                    continue
                os.makedirs(os.path.dirname(resolved), exist_ok=True)
                if is_bytes:
                    with open(resolved, "wb") as f:
                        f.write(bytes(content))
                else:
                    with open(resolved, "w", encoding="utf-8", errors="backslashreplace") as f:
                        f.write(content)
            os.chmod(host_dir, 0o777)  # world-writable so nobody can write __pycache__

            if not self._has_pytest:
                return {"success": False,
                        "output": "sandbox image missing: run `docker pull sz01/logomesh-sandbox:latest && docker tag sz01/logomesh-sandbox:latest logomesh-startup-sandbox:latest`",
                        "duration": time.time() - start, "passed": 0, "failed": 0, "total": 0}

            container = self.client.containers.create(
                image=self.image,
                command=["tail", "-f", "/dev/null"],
                working_dir="/workspace",
                network_disabled=True,
                mem_limit="256m",
                cpu_period=100000,
                cpu_quota=200000,
                pids_limit=100,
                detach=True,
                # hardening
                cap_drop=["ALL"],
                user="nobody",
                read_only=True,
                security_opt=["no-new-privileges"],
                # bind-mount host dir as workspace (read-only); /tmp for pytest scratch
                volumes=_build_volumes(host_dir, deps_snapshot),
                tmpfs={"/tmp": "size=64m"},
            )
            container.start()

            # sh -c needed for glob expansion in test_pattern (test_*.py)
            # test_pattern is always hardcoded, never user-controlled
            _xdist_workers = int(os.getenv("SANDBOX_XDIST_WORKERS", "2"))
            _xdist_flag = f"-n {_xdist_workers} " if _xdist_workers > 0 else ""
            cmd = (
                f"timeout {self.timeout}s python3 -m pytest -v "
                f"-c /dev/null "
                f"-p no:cacheprovider "
                f"-p no:pydantic "
                f"-W ignore::pytest.PytestCollectionWarning "
                f"-W ignore::pytest.PytestConfigWarning "
                f"{_xdist_flag}"
                f"--json-report --json-report-file=/tmp/{report_name} "
                f"{test_pattern} 2>&1"
            )

            # Use low-level API to stream output with a size cap (prevents host OOM)
            api = self.client.api
            exec_env = {
                "LOGOMESH_TRACE_FILE": f"/tmp/{trace_name}",
                "LOGOMESH_COVERAGE_FILE": f"/tmp/{coverage_name}",
            }
            if extra_env:
                exec_env.update(extra_env)
            exec_id = api.exec_create(
                container.id, ["sh", "-c", cmd],
                workdir="/workspace",
                environment=exec_env,
            )["Id"]
            stream = api.exec_start(exec_id, stream=True)

            chunks = []
            total_read = 0
            for chunk in stream:
                total_read += len(chunk)
                if total_read <= MAX_OUTPUT_BYTES:
                    chunks.append(chunk)
            raw_output = b"".join(chunks)

            duration = time.time() - start
            output = raw_output.decode("utf-8", errors="replace")
            if total_read > MAX_OUTPUT_BYTES:
                output += f"\n... output truncated ({total_read} bytes, cap {MAX_OUTPUT_BYTES})"
            exit_code = api.exec_inspect(exec_id).get("ExitCode", 1)
            success = exit_code == 0

            # read structured JSON report from /tmp (written by pytest-json-report)
            report = None
            try:
                cat_id = api.exec_create(
                    container.id, ["cat", f"/tmp/{report_name}"]
                )["Id"]
                json_bytes = b"".join(api.exec_start(cat_id, stream=True))
                report = json.loads(json_bytes.decode("utf-8", errors="replace"))
            except Exception:
                pass

            # read time-travel traces from /tmp (written by our conftest hook)
            traces = _read_traces_from_container(api, container.id, trace_name)

            # read line-reach coverage from /tmp (written by coverage hook)
            coverage_json = ""
            if _ENABLE_LINE_REACH_GATE:
                try:
                    # Per-pid shards from xdist workers — merge covered line sets per test.
                    cov_cmd = (
                        "for f in /tmp/" + coverage_name + "*; do "
                        "if [ -f \"$f\" ]; then cat \"$f\"; printf '\\n'; fi; done"
                    )
                    cov_id = api.exec_create(container.id, ["sh", "-c", cov_cmd])["Id"]
                    cov_bytes = b"".join(api.exec_start(cov_id, stream=True))
                    cov_raw = cov_bytes.decode("utf-8", errors="replace")
                    merged_cov: dict[str, list[int]] = {}
                    for _line in cov_raw.splitlines():
                        _line = _line.strip()
                        if not _line:
                            continue
                        try:
                            shard = json.loads(_line)
                        except Exception:
                            continue
                        if not isinstance(shard, dict):
                            continue
                        for k, v in shard.items():
                            if not isinstance(v, list):
                                continue
                            merged_cov.setdefault(k, [])
                            merged_cov[k] = sorted(set(merged_cov[k]).union(v))
                    coverage_json = json.dumps(merged_cov) if merged_cov else ""
                except Exception:
                    pass

            # read behavioral-diff observations (written by tests via harness)
            obs_jsonl = ""
            try:
                obs_id = api.exec_create(
                    container.id,
                    ["sh", "-c", "test -f /tmp/lm_obs.jsonl && cat /tmp/lm_obs.jsonl"],
                )["Id"]
                obs_bytes = b"".join(api.exec_start(obs_id, stream=True))
                obs_jsonl = obs_bytes.decode("utf-8", errors="replace")
            except Exception:
                pass

            result = self._parse_result(success, output, duration, report, traces)
            result["coverage_json"] = coverage_json
            result["obs_jsonl"] = obs_jsonl
            return result

        except Exception as e:
            return {"success": False, "output": str(e), "duration": time.time() - start,
                    "passed": 0, "failed": 0, "total": 0}
        finally:
            if container:
                try: container.stop(timeout=1)
                except Exception: pass
                try: container.remove(force=True)
                except Exception: pass
            shutil.rmtree(host_dir, ignore_errors=True)

    def _run_subprocess(self, files: dict, test_pattern: str, *, deps_snapshot: str | None = None, extra_env: dict[str, str] | None = None) -> dict:
        start = time.time()
        with tempfile.TemporaryDirectory() as tmp:
            real_tmp = os.path.realpath(tmp)
            for filename, content in files.items():
                resolved = pathlib.Path(real_tmp, filename).resolve()
                if not resolved.is_relative_to(real_tmp):
                    log.warn("sandbox", "path traversal blocked", filename=filename)
                    continue
                is_bytes = isinstance(content, (bytes, bytearray))
                size = len(content) if is_bytes else len(content.encode("utf-8", errors="replace"))
                if size > MAX_FILE_BYTES:
                    log.warn("sandbox", "file too large, skipping", filename=filename)
                    continue
                if not is_bytes and '\x00' in content[:8192]:
                    log.warn("sandbox", "binary file, skipping", filename=filename)
                    continue
                os.makedirs(os.path.dirname(resolved), exist_ok=True)
                if is_bytes:
                    with open(resolved, "wb") as f:
                        f.write(bytes(content))
                else:
                    with open(resolved, "w", encoding="utf-8", errors="backslashreplace") as f:
                        f.write(content)

            # Keep caller-selected conftest mode, but rewrite workspace path for local subprocess.
            conftest_path = os.path.join(tmp, "conftest.py")
            try:
                with open(conftest_path) as f:
                    current_conftest = f.read()
            except Exception:
                current_conftest = _CONFTEST_AUTOMOCK
            rewritten = current_conftest.replace("/workspace", real_tmp)
            if deps_snapshot:
                rewritten = rewritten.replace("/deps", deps_snapshot)
            with open(conftest_path, "w") as f:
                f.write(rewritten)

            report_path = os.path.join(tmp, "report.json")
            trace_path = os.path.join(tmp, "logomesh_traces.json")
            env = os.environ.copy()
            env["LOGOMESH_TRACE_FILE"] = trace_path
            if extra_env:
                env.update(extra_env)
            expanded_patterns = sorted(
                str(pathlib.Path(p).relative_to(tmp))
                for p in pathlib.Path(tmp).glob(test_pattern)
            )
            pytest_targets = expanded_patterns or [test_pattern]
            pytest_cmd = [
                sys.executable, "-m", "pytest", "-v", "--tb=short", "-q",
                "-c", "/dev/null",
                "-p", "no:cacheprovider",
                "-p", "no:pydantic",
                "-W", "ignore::pytest.PytestCollectionWarning",
                "-W", "ignore::pytest.PytestConfigWarning",
                *pytest_targets,
            ]
            try:
                result = subprocess.run(
                    pytest_cmd,
                    cwd=tmp,
                    capture_output=True,
                    text=True,
                    timeout=self.timeout,
                    env=env,
                )
                output = result.stdout + result.stderr
                success = result.returncode == 0
            except subprocess.TimeoutExpired:
                output = f"TIMEOUT: exceeded {self.timeout}s"
                success = False
            except Exception as e:
                output = str(e)
                success = False

            report = None
            try:
                with open(report_path) as f:
                    report = json.load(f)
            except Exception:
                pass

            # Hook writes per-pid shards `<trace_path>.<pid>` (one per xdist worker).
            traces: dict = {}
            try:
                import glob as _glob
                for shard in _glob.glob(trace_path + "*"):
                    try:
                        with open(shard) as f:
                            data = json.load(f)
                    except Exception:
                        continue
                    if isinstance(data, dict):
                        traces.update(data)
            except Exception:
                pass

            duration = time.time() - start
            return self._parse_result(success, output, duration, report, traces)

    def _parse_result(self, success: bool, output: str, duration: float, report: dict | None = None, traces: dict | None = None) -> dict:
        """Extract pass/fail counts — from JSON report if available, else from stdout."""
        # Compliance chokepoint #3: scrub PII / secrets out of pytest
        # stdout+stderr before returning. Defense in depth — the test
        # inputs are already redacted at synthesis time, but the app code
        # under test can construct PII-shaped state internally and pytest
        # echoes it in tracebacks. See docs/run_results/pii_audit_2026-05-07.md.
        output = redact_text(output) if isinstance(output, str) else output
        if report is not None and isinstance(traces, dict) and traces:
            # Stash traces on the report so classify_report can attach them per-finding.
            report["_logomesh_traces"] = traces
        if report:
            summary = report.get("summary", {})
            passed = summary.get("passed", 0)
            failed = summary.get("failed", 0) + summary.get("error", 0)
            total = passed + failed
        else:
            passed = failed = total = 0
            m = re.search(r'(\d+) passed', output)
            if m: passed = int(m.group(1))
            m = re.search(r'(\d+) failed', output)
            if m: failed = int(m.group(1))
            m = re.search(r'(\d+) error', output)
            if m: failed += int(m.group(1))
            total = passed + failed

        collection_error_kind, collection_error_message = _extract_collection_error(output, report)

        return {
            "success": success,
            "output": output[-32768:],  # 32KB cap — kept for debugging
            "duration": duration,
            "passed": passed,
            "failed": failed,
            "total": total,
            "report": report,  # structured JSON from pytest-json-report, None if unavailable
            "collection_error_kind": collection_error_kind,
            "collection_error_message": collection_error_message,
        }


def _build_volumes(host_dir: str, deps_snapshot: str | None) -> dict:
    vols = {host_dir: {"bind": "/workspace", "mode": "ro"}}
    if deps_snapshot:
        try:
            resolved = os.path.realpath(deps_snapshot)
            if os.path.isdir(resolved):
                vols[resolved] = {"bind": "/deps", "mode": "ro"}
            else:
                log.warn("sandbox", "deps_snapshot missing", path=deps_snapshot)
        except Exception as e:
            log.warn("sandbox", "deps_snapshot invalid", error=str(e))
    # Persistent Hypothesis ExampleDatabase: survives across PR runs, replays
    # known-bad counterexamples first. Mounted rw so Hypothesis can append.
    if _HYPOTHESIS_DB_HOST_PATH:
        try:
            hdb_resolved = os.path.realpath(_HYPOTHESIS_DB_HOST_PATH)
            os.makedirs(hdb_resolved, exist_ok=True)
            # world-writable so the sandbox's `nobody` user can append
            try:
                os.chmod(hdb_resolved, 0o777)
            except Exception:
                pass
            vols[hdb_resolved] = {"bind": "/hypothesis-db", "mode": "rw"}
        except Exception as e:
            log.warn("sandbox", "hypothesis_db mount failed", error=str(e))
    return vols


def _read_traces_from_container(api, container_id: str, trace_name: str) -> dict:
    """Merge per-pid trace shards written by each pytest-xdist worker.

    Hook writes `<trace_name>.<pid>` per worker; we concatenate all shards
    (newline-delimited) and merge their JSON dicts.
    """
    try:
        cmd = (
            "for f in /tmp/" + trace_name + "*; do "
            "if [ -f \"$f\" ]; then cat \"$f\"; printf '\\n'; fi; done"
        )
        cat_id = api.exec_create(container_id, ["sh", "-c", cmd])["Id"]
        raw = b"".join(api.exec_start(cat_id, stream=True)).decode("utf-8", errors="replace")
        merged: dict = {}
        for line in raw.splitlines():
            line = line.strip()
            if not line:
                continue
            try:
                shard = json.loads(line)
            except Exception:
                continue
            if isinstance(shard, dict):
                merged.update(shard)
        return merged
    except Exception:
        return {}


def _has_import_failure(output: str) -> bool:
    text = (output or "").lower()
    return (
        "modulenotfounderror" in text
        or "importerror" in text
        or "cannot import name" in text
    )


def _extract_collection_error(output: str, report: dict | None) -> tuple[str, str]:
    """Return (kind, message) for pytest collection/import failures when detectable."""
    rep = report if isinstance(report, dict) else {}
    summary = rep.get("summary", {})
    total = int(summary.get("total", 0) or 0)
    collected = int(summary.get("collected", total) or total)
    collectors = rep.get("collectors", [])
    collector_failed = False
    if isinstance(collectors, list):
        for item in collectors:
            if isinstance(item, dict) and str(item.get("outcome", "")).lower() in ("failed", "error"):
                collector_failed = True
                break
    is_collection_like = total == 0 or collected == 0 or collector_failed
    text = output or ""
    lower = text.lower()

    if not is_collection_like and "error collecting" not in lower and "while importing test module" not in lower:
        return ("", "")

    # Prefer canonical import failure buckets first.
    if "modulenotfounderror" in lower:
        m = re.search(r"^E\s+ModuleNotFoundError:\s+(.+)$", text, flags=re.MULTILINE)
        return ("dependency_import_error", (m.group(1).strip() if m else "ModuleNotFoundError"))
    if "importerror" in lower or "cannot import name" in lower:
        m = re.search(r"^E\s+ImportError:\s+(.+)$", text, flags=re.MULTILINE)
        if not m:
            m = re.search(r"cannot import name[^\n]*", text, flags=re.IGNORECASE)
        return ("dependency_import_error", (m.group(0).strip() if m else "ImportError"))
    if "syntaxerror" in lower:
        m = re.search(r"^E\s+SyntaxError:\s+(.+)$", text, flags=re.MULTILINE)
        return ("test_syntax_error", (m.group(1).strip() if m else "SyntaxError"))
    if "indentationerror" in lower:
        m = re.search(r"^E\s+IndentationError:\s+(.+)$", text, flags=re.MULTILINE)
        return ("test_syntax_error", (m.group(1).strip() if m else "IndentationError"))
    if "timeout" in lower:
        return ("sandbox_timeout", "sandbox timeout")
    if "sandbox unavailable" in lower:
        return ("sandbox_unavailable", "sandbox unavailable")

    m = re.search(r"^E\s+([A-Za-z_][\w.]*):\s*(.+)$", text, flags=re.MULTILINE)
    if m:
        return ("pytest_collection_error", f"{m.group(1)}: {m.group(2).strip()}")
    m = re.search(r"ERROR collecting[^\n]*\n([^\n]+)", text, flags=re.IGNORECASE)
    if m:
        return ("pytest_collection_error", m.group(1).strip()[:240])

    # Pull longrepr from failed collectors when regex scans missed — pytest-json-report
    # stores the full traceback there even when stdout is terse.
    if isinstance(collectors, list):
        for item in collectors:
            if not isinstance(item, dict):
                continue
            if str(item.get("outcome", "")).lower() not in ("failed", "error"):
                continue
            longrepr = str(item.get("longrepr") or "").strip()
            if not longrepr:
                continue
            tail = longrepr.splitlines()[-1].strip()
            mm = re.search(r"([A-Za-z_][\w.]*(?:Error|Exception)):\s*(.+)", longrepr)
            if mm:
                return ("pytest_collection_error", f"{mm.group(1)}: {mm.group(2).strip()[:220]}")
            return ("pytest_collection_error", (tail or longrepr[:240])[:240])

    # Last-ditch scan of output for any ErrorName: message line.
    m = re.search(r"([A-Za-z_][\w.]*(?:Error|Exception)):\s*([^\n]+)", text)
    if m:
        return ("pytest_collection_error", f"{m.group(1)}: {m.group(2).strip()[:220]}")

    if "collected 0 items" in lower:
        return ("pytest_collected_zero", "collected 0 items")
    return ("zero_tests_collected", "collection failed")
