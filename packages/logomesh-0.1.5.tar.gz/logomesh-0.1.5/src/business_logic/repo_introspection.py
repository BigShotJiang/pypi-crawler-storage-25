"""Generic repo introspection — no hardcoded framework names.

Walks a Python repo and emits *evidence*: what manifests declare, what
imports appear at module top, what decorators are attached to which
functions, what classes inherit from what. The agent (or any caller)
reasons over the evidence; this module never makes a framework
decision on its own.

Contract:
    - Pure analysis: no side effects, no IO outside the repo path
    - No framework switch statements ("if 'django' in deps: ...")
    - Returns structured evidence with a confidence score + source
      pointer ("import path X in file Y at line Z")
    - Agent consumes via _tool_introspect_repo and decides routing
"""

from __future__ import annotations

import ast
import re
import sys
import tomllib
from dataclasses import asdict, dataclass, field
from pathlib import Path
from typing import Any, Iterable

_REPO_SKIP_DIRS = {
    ".git", ".venv", "venv", "env", "node_modules", "__pycache__",
    ".pytest_cache", ".mypy_cache", "dist", "build", ".tox", ".idea",
    ".vscode", "site-packages",
}

_MAX_FILES_SCANNED = 600          # bound work on huge monorepos
_MAX_FILE_BYTES = 256 * 1024      # skip generated files


# --------------------------------------------------------------------------
# Evidence types
# --------------------------------------------------------------------------

@dataclass
class EvidenceItem:
    """A single observation about the repo.

    The agent / planner reads `kind` + `value` and decides what to do.
    `source` is for explainability — every signal points at a file:line.
    """
    kind: str           # "import", "decorator", "class_base", "manifest_dep", "config_file", "entrypoint", "env_var"
    value: str          # the actual thing observed
    source: str         # "path:line" or "<manifest>" if not file-bound
    confidence: float = 1.0
    extra: dict[str, Any] = field(default_factory=dict)


@dataclass
class ClassDef:
    """A class definition found in the repo."""
    name: str
    bases: list[str]                          # raw base names as written ('models.Model', 'Base', 'BaseModel')
    fields: list[dict[str, Any]]              # [{name, raw_type, default, source_line}, ...]
    decorators: list[str]
    file: str
    lineno: int
    body_source: str                          # the class block as a string (truncated)


@dataclass
class CallableDef:
    """A function or method definition."""
    name: str
    decorators: list[str]
    args: list[str]
    is_async: bool
    file: str
    lineno: int


@dataclass
class ManifestRead:
    """Result of reading a project manifest file."""
    path: str
    requires_python: str
    dependencies: list[str]
    entry_points: dict[str, str]              # script name → module:func
    raw: dict[str, Any]


@dataclass
class RepoIntrospection:
    """Complete read-once view of a repo."""
    root: str
    files_scanned: int
    manifests: list[ManifestRead]
    evidence: list[EvidenceItem]
    classes: list[ClassDef]
    callables: list[CallableDef]
    config_files: list[str]                   # *settings*.py, *config*.py, env-shaped files
    entrypoint_modules: list[str]             # manage.py, app.py, main.py, asgi.py, wsgi.py
    imports_seen: dict[str, int]              # module → count, helps the agent route

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)

    # Convenience for the agent — never use these to gate logic. Just for prompts.
    def evidence_for(self, kind: str) -> list[EvidenceItem]:
        return [e for e in self.evidence if e.kind == kind]

    def imports_matching(self, pattern: str) -> list[str]:
        """Return imports whose full module path matches the regex pattern.

        Matches against the *full* dotted module string (e.g. 'django.db'
        matches r'^django\\.db'). The agent uses this for evidence-based
        routing — match precision matters.
        """
        rx = re.compile(pattern)
        return [imp for imp in self.imports_seen if rx.match(imp)]

    def classes_with_base(self, base_pattern: str) -> list[ClassDef]:
        rx = re.compile(base_pattern)
        return [c for c in self.classes if any(rx.search(b) for b in c.bases)]

    def callables_with_decorator(self, decorator_pattern: str) -> list[CallableDef]:
        rx = re.compile(decorator_pattern)
        return [c for c in self.callables if any(rx.search(d) for d in c.decorators)]


# --------------------------------------------------------------------------
# Scanner
# --------------------------------------------------------------------------

def scan_repo(repo_path: str | Path) -> RepoIntrospection:
    """Walk a repo and produce a `RepoIntrospection`.

    Pure-ish: only reads files, never writes. Bounded by file count
    and byte size so we don't choke on monorepos or generated code.
    """
    root = Path(repo_path).resolve()
    if not root.exists():
        raise FileNotFoundError(f"repo path does not exist: {root}")

    manifests = _read_manifests(root)
    files_scanned = 0
    evidence: list[EvidenceItem] = []
    classes: list[ClassDef] = []
    callables: list[CallableDef] = []
    config_files: list[str] = []
    entrypoint_modules: list[str] = []
    imports: dict[str, int] = {}

    for manifest in manifests:
        for dep in manifest.dependencies:
            evidence.append(EvidenceItem(
                kind="manifest_dep",
                value=dep,
                source=manifest.path,
            ))

    for py_file in _iter_python_files(root):
        if files_scanned >= _MAX_FILES_SCANNED:
            break
        try:
            text = py_file.read_text(encoding="utf-8", errors="ignore")
        except OSError:
            continue
        if len(text.encode("utf-8")) > _MAX_FILE_BYTES:
            continue
        files_scanned += 1

        rel = str(py_file.relative_to(root))
        # Treat anything called *settings*.py or *config*.py as a config candidate
        if re.search(r"(^|/)(.*settings|.*config|.*conftest)\.py$", rel):
            config_files.append(rel)
            evidence.append(EvidenceItem(
                kind="config_file",
                value=rel,
                source=rel,
            ))

        base = py_file.name
        if base in {"manage.py", "app.py", "main.py", "asgi.py", "wsgi.py", "__main__.py"}:
            entrypoint_modules.append(rel)
            evidence.append(EvidenceItem(
                kind="entrypoint",
                value=base,
                source=rel,
            ))

        try:
            tree = ast.parse(text, filename=rel)
        except SyntaxError:
            continue

        _harvest_module(
            tree=tree, rel_path=rel, text=text,
            evidence=evidence, classes=classes, callables=callables,
            imports=imports,
        )

    return RepoIntrospection(
        root=str(root),
        files_scanned=files_scanned,
        manifests=manifests,
        evidence=evidence,
        classes=classes,
        callables=callables,
        config_files=config_files,
        entrypoint_modules=entrypoint_modules,
        imports_seen=imports,
    )


# --------------------------------------------------------------------------
# Module-level AST harvest
# --------------------------------------------------------------------------

def _harvest_module(
    *,
    tree: ast.Module,
    rel_path: str,
    text: str,
    evidence: list[EvidenceItem],
    classes: list[ClassDef],
    callables: list[CallableDef],
    imports: dict[str, int],
) -> None:
    text_lines = text.splitlines()

    for node in ast.walk(tree):
        if isinstance(node, ast.Import):
            for alias in node.names:
                imports[alias.name] = imports.get(alias.name, 0) + 1
                evidence.append(EvidenceItem(
                    kind="import",
                    value=alias.name,
                    source=f"{rel_path}:{node.lineno}",
                ))
        elif isinstance(node, ast.ImportFrom):
            module = node.module or ""
            imports[module] = imports.get(module, 0) + 1
            for alias in node.names:
                evidence.append(EvidenceItem(
                    kind="import_from",
                    value=f"{module}.{alias.name}" if module else alias.name,
                    source=f"{rel_path}:{node.lineno}",
                ))

    for node in tree.body:
        if isinstance(node, ast.ClassDef):
            classes.append(_class_def_from_node(node, rel_path, text_lines))
        elif isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            callables.append(_callable_def_from_node(node, rel_path))

    # Also pick up nested class defs (one level — most ORM models are top-level
    # but methods carry @task decorators we care about, so walk too).
    for parent in tree.body:
        if isinstance(parent, ast.ClassDef):
            for item in parent.body:
                if isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)):
                    callables.append(_callable_def_from_node(item, rel_path))


def _class_def_from_node(node: ast.ClassDef, rel_path: str, text_lines: list[str]) -> ClassDef:
    bases = [_unparse(b) for b in node.bases]
    decorators = [_unparse(d) for d in node.decorator_list]
    fields_out: list[dict[str, Any]] = []

    for item in node.body:
        if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
            fields_out.append({
                "name": item.target.id,
                "raw_type": _unparse(item.annotation) if item.annotation else "",
                "default": _unparse(item.value) if item.value is not None else None,
                "lineno": item.lineno,
            })
        elif isinstance(item, ast.Assign):
            for tgt in item.targets:
                if isinstance(tgt, ast.Name):
                    fields_out.append({
                        "name": tgt.id,
                        "raw_type": "",
                        "default": _unparse(item.value),
                        "lineno": item.lineno,
                    })

    # Body source — truncated for prompt embedding
    start = node.lineno - 1
    end = min(node.end_lineno or (node.lineno + 30), start + 80)
    body_source = "\n".join(text_lines[start:end])

    return ClassDef(
        name=node.name,
        bases=bases,
        fields=fields_out,
        decorators=decorators,
        file=rel_path,
        lineno=node.lineno,
        body_source=body_source,
    )


def _callable_def_from_node(
    node: ast.FunctionDef | ast.AsyncFunctionDef,
    rel_path: str,
) -> CallableDef:
    return CallableDef(
        name=node.name,
        decorators=[_unparse(d) for d in node.decorator_list],
        args=[a.arg for a in node.args.args],
        is_async=isinstance(node, ast.AsyncFunctionDef),
        file=rel_path,
        lineno=node.lineno,
    )


def _unparse(node: ast.AST | None) -> str:
    if node is None:
        return ""
    try:
        return ast.unparse(node)
    except Exception:
        return ""


# --------------------------------------------------------------------------
# Manifest reading — generic, no framework names
# --------------------------------------------------------------------------

def _read_manifests(root: Path) -> list[ManifestRead]:
    found: list[ManifestRead] = []

    py = root / "pyproject.toml"
    if py.exists():
        try:
            data = tomllib.loads(py.read_text())
        except Exception:
            data = {}
        proj = data.get("project", {}) if isinstance(data, dict) else {}
        deps = list(proj.get("dependencies", []))
        for group in (proj.get("optional-dependencies", {}) or {}).values():
            deps.extend(group)
        entrypoints: dict[str, str] = {}
        for k, v in (proj.get("scripts", {}) or {}).items():
            entrypoints[k] = str(v)
        found.append(ManifestRead(
            path="pyproject.toml",
            requires_python=str(proj.get("requires-python", "")),
            dependencies=[str(d) for d in deps],
            entry_points=entrypoints,
            raw=data,
        ))

    for req_name in ("requirements.txt", "requirements-dev.txt", "requirements/base.txt"):
        rf = root / req_name
        if rf.exists():
            try:
                lines = rf.read_text().splitlines()
            except OSError:
                continue
            deps = [
                ln.strip() for ln in lines
                if ln.strip() and not ln.strip().startswith(("#", "-r", "-e"))
            ]
            found.append(ManifestRead(
                path=req_name,
                requires_python="",
                dependencies=deps,
                entry_points={},
                raw={},
            ))

    setup_py = root / "setup.py"
    if setup_py.exists():
        try:
            text = setup_py.read_text()
            # Best-effort install_requires extraction — don't exec the setup.py.
            m = re.search(r"install_requires\s*=\s*\[(.*?)\]", text, re.DOTALL)
            if m:
                items = re.findall(r'"([^"]+)"|\'([^\']+)\'', m.group(1))
                deps = [a or b for a, b in items if (a or b)]
                found.append(ManifestRead(
                    path="setup.py",
                    requires_python="",
                    dependencies=deps,
                    entry_points={},
                    raw={},
                ))
        except OSError:
            pass

    return found


# --------------------------------------------------------------------------
# File iteration
# --------------------------------------------------------------------------

def _iter_python_files(root: Path) -> Iterable[Path]:
    for path in sorted(root.rglob("*.py")):
        if any(part in _REPO_SKIP_DIRS for part in path.parts):
            continue
        if not path.is_file():
            continue
        yield path
