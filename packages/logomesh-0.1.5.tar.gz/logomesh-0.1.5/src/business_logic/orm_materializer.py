"""Generic object materializer — agent decides, tool synthesizes.

Two layers:

  1. `analyze_class_source(source, class_name)` — pure AST inspection.
     Returns the shape (required vs optional fields, base classes,
     decorators). NO synthesis decisions. The agent reads this and
     decides what to construct.

  2. `synthesize_constructor_call(shape, kwargs, ...)` — pure code
     emitter. Takes the kwargs the agent supplies, emits a Python
     expression. If a required field is missing, returns it as an
     `unresolved` item (NOT a placeholder) so the agent can decide
     whether to: provide a value, drop the field, or change tactics.

Contract — read before editing:
    Tools expose facts and emit code from explicit inputs. Tools do
    not guess. The agent owns "what value should `currency` be?"
    not the materializer. The optional `placeholder_for_missing`
    flag exists for tests + truly headless callers; default is OFF.
"""

from __future__ import annotations

import ast
import re
from dataclasses import dataclass, field
from typing import Any


@dataclass
class FieldShape:
    name: str
    raw_type: str          # the AST-unparsed annotation OR the right-hand-side call
    has_default: bool      # whether a default value exists at class-definition time
    is_required: bool      # heuristic: required iff no default AND no `null=True` / `nullable=True` / `optional`
    is_pk: bool            # primary key (best-effort signal)
    notes: list[str]       # explanations of how we decided


@dataclass
class ClassShape:
    name: str
    fields: list[FieldShape]
    parent_bases: list[str]
    is_abstract: bool
    raw_init_present: bool   # True if class defines __init__ explicitly
    decorators: list[str]

    def required_field_names(self) -> list[str]:
        return [f.name for f in self.fields if f.is_required]

    def known_field_names(self) -> set[str]:
        return {f.name for f in self.fields}


# --------------------------------------------------------------------------
# Analyzer
# --------------------------------------------------------------------------

_NULLABLE_KEYWORDS = {"null", "nullable", "optional", "blank"}
_DEFAULT_KEYWORDS = {"default", "default_factory", "server_default"}
_PRIMARY_KEY_KEYWORDS = {"primary_key", "pk"}


def analyze_class_source(source: str, class_name: str | None = None) -> ClassShape | None:
    """Parse a Python class block and report its field shape.

    `source` may be a full module or just the class body. The first
    `ClassDef` matching `class_name` (or the first class found if
    `class_name` is None) is analyzed.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return None

    target: ast.ClassDef | None = None
    for node in ast.walk(tree):
        if isinstance(node, ast.ClassDef):
            if class_name is None or node.name == class_name:
                target = node
                break
    if target is None:
        return None

    is_abstract = _detect_abstract(target)
    raw_init = any(
        isinstance(b, (ast.FunctionDef, ast.AsyncFunctionDef)) and b.name == "__init__"
        for b in target.body
    )

    fields: list[FieldShape] = []
    for item in target.body:
        if isinstance(item, ast.AnnAssign) and isinstance(item.target, ast.Name):
            fields.append(_field_from_annassign(item))
        elif isinstance(item, ast.Assign):
            for tgt in item.targets:
                if isinstance(tgt, ast.Name):
                    fields.append(_field_from_assign(tgt.id, item.value))

    return ClassShape(
        name=target.name,
        fields=fields,
        parent_bases=[_unparse(b) for b in target.bases],
        is_abstract=is_abstract,
        raw_init_present=raw_init,
        decorators=[_unparse(d) for d in target.decorator_list],
    )


def _detect_abstract(node: ast.ClassDef) -> bool:
    """Heuristic: Meta.abstract = True or `abstract` keyword in any base."""
    for item in node.body:
        if isinstance(item, ast.ClassDef) and item.name == "Meta":
            for sub in item.body:
                if (
                    isinstance(sub, ast.Assign)
                    and any(isinstance(t, ast.Name) and t.id == "abstract" for t in sub.targets)
                    and isinstance(sub.value, ast.Constant)
                    and sub.value.value is True
                ):
                    return True
    return False


def _field_from_annassign(node: ast.AnnAssign) -> FieldShape:
    assert isinstance(node.target, ast.Name)
    raw_type = _unparse(node.annotation) if node.annotation else ""
    has_default = node.value is not None
    is_required = not has_default and not _annotation_is_optional(raw_type)
    return FieldShape(
        name=node.target.id,
        raw_type=raw_type,
        has_default=has_default,
        is_required=is_required,
        is_pk=False,
        notes=[
            f"annotation-style field; type='{raw_type}'",
            "required (no default, type not Optional)" if is_required else "has default or optional",
        ],
    )


def _field_from_assign(name: str, value: ast.expr) -> FieldShape:
    raw = _unparse(value)
    has_default = _call_has_default(value)
    is_nullable = _call_has_kw_truthy(value, _NULLABLE_KEYWORDS)
    is_pk = _call_has_kw_truthy(value, _PRIMARY_KEY_KEYWORDS)
    is_required = not has_default and not is_nullable and not is_pk
    notes = [
        f"assign-style field (likely ORM column); rhs='{raw[:80]}'",
    ]
    if is_nullable:
        notes.append("nullable / blank kwarg present")
    if has_default:
        notes.append("default / default_factory / server_default present")
    if is_pk:
        notes.append("primary_key kwarg present — usually auto-generated")
    return FieldShape(
        name=name,
        raw_type=raw,
        has_default=has_default,
        is_required=is_required,
        is_pk=is_pk,
        notes=notes,
    )


def _call_has_default(value: ast.expr) -> bool:
    if not isinstance(value, ast.Call):
        return False
    return any(k.arg in _DEFAULT_KEYWORDS for k in (value.keywords or []))


def _call_has_kw_truthy(value: ast.expr, names: set[str]) -> bool:
    if not isinstance(value, ast.Call):
        return False
    for k in (value.keywords or []):
        if k.arg in names and isinstance(k.value, ast.Constant) and k.value.value is True:
            return True
    return False


def _annotation_is_optional(raw_type: str) -> bool:
    if not raw_type:
        return False
    return (
        raw_type.startswith("Optional[")
        or raw_type.endswith(" | None")
        or raw_type.endswith("|None")
        or "Union[" in raw_type and "None" in raw_type
    )


# --------------------------------------------------------------------------
# Synthesizer — produce a Python expression that builds the instance
# --------------------------------------------------------------------------

def synthesize_constructor_call(
    *,
    shape: ClassShape,
    raw_locals: dict[str, Any],
    constructor_callable: str | None = None,
    placeholder_for_missing: bool = False,
) -> tuple[str, list[str], list[str]]:
    """Build a Python expression that constructs an instance of `shape`.

    Agent-led: the agent supplies `raw_locals` (the kwargs it has
    decided to use). This function emits a call expression — it does
    not guess values.

    Returns (call_source, notes, unresolved).

      call_source: the Python expression. May be incomplete if any
                   required fields couldn't be filled.
      notes:       per-field provenance ("from frame local 'x'").
      unresolved:  required field names with no source value. Empty
                   if everything was provided. The agent reads this
                   and decides what to do: supply more locals, drop
                   the field, or pick a different strategy.

    `placeholder_for_missing=True` opts into the legacy behavior
    where missing required fields get a type-guessed placeholder
    (empty string for CharField, 0 for IntegerField, etc.). This
    exists for tests + truly headless usage — the orchestrator's
    agent should leave it OFF and react to `unresolved`.
    """
    notes: list[str] = []
    unresolved: list[str] = []
    kwargs: list[tuple[str, str]] = []

    locals_lookup = {k.lower(): (k, v) for k, v in raw_locals.items()}

    for fs in shape.fields:
        if fs.is_pk:
            continue
        provided = locals_lookup.get(fs.name.lower())
        if provided is not None:
            orig_key, value = provided
            kwargs.append((fs.name, _python_literal(value)))
            notes.append(f"{fs.name}: from frame local {orig_key!r}")
            continue
        if fs.is_required:
            if placeholder_for_missing:
                kwargs.append((fs.name, _placeholder_for_type(fs.raw_type)))
                notes.append(f"{fs.name}: placeholder — required field not in frame locals")
            else:
                unresolved.append(fs.name)

    constructor = constructor_callable or shape.name
    kw_source = ", ".join(f"{name}={value}" for name, value in kwargs)
    return f"{constructor}({kw_source})", notes, unresolved


def _python_literal(value: Any) -> str:
    """Render a value as a Python expression. Strings get quoted; other types
    get their `repr`. We do NOT trust the value's `__repr__` to be safe —
    we whitelist primitive types."""
    if isinstance(value, (int, float, bool)) or value is None:
        return repr(value)
    if isinstance(value, str):
        # If the string itself looks like a Python literal already, keep it raw
        s = value.strip()
        if s.startswith(("[", "{", "(", '"', "'")) or s in {"True", "False", "None"}:
            return s
        return repr(value)
    if isinstance(value, (list, tuple, dict)):
        return repr(value)
    return repr(str(value))


_TYPE_PLACEHOLDERS = [
    (re.compile(r"\bstr\b|CharField|TextField|String\b", re.IGNORECASE), '""'),
    (re.compile(r"\bint\b|IntegerField|BigInteger|SmallInt", re.IGNORECASE), "0"),
    (re.compile(r"\bfloat\b|FloatField|Numeric|Decimal", re.IGNORECASE), "0.0"),
    (re.compile(r"\bbool\b|BooleanField", re.IGNORECASE), "False"),
    (re.compile(r"\blist\b|\bArray\b|ManyToMany", re.IGNORECASE), "[]"),
    (re.compile(r"\bdict\b|JSONField|JSONB", re.IGNORECASE), "{}"),
    (re.compile(r"DateTimeField|datetime", re.IGNORECASE), "None"),
    (re.compile(r"DateField|date", re.IGNORECASE), "None"),
    (re.compile(r"UUIDField|UUID", re.IGNORECASE), "None"),
    (re.compile(r"ForeignKey|OneToOne", re.IGNORECASE), "None"),
]


def _placeholder_for_type(raw_type: str) -> str:
    for rx, placeholder in _TYPE_PLACEHOLDERS:
        if rx.search(raw_type or ""):
            return placeholder
    return "None"


def _unparse(node: ast.AST | None) -> str:
    if node is None:
        return ""
    try:
        return ast.unparse(node)
    except Exception:
        return ""
