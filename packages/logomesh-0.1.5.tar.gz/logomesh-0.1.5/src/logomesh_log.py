# backward-compat shim — implementation moved to core.logomesh_log
from core.logomesh_log import *  # noqa: F401, F403
from core.logomesh_log import _JsonFormatter, _StructuredLogger, log  # noqa: F401
