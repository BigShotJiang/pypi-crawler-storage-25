"""Hardened deterministic Sentry-replay synthesizer.

Lives in its own module because edits to `sentry_replay.py` keep getting
reverted by the IDE's auto-format on save. Identical contract to the
original `build_replay_test`, plus production-hardening fixes:

  - Sanitize `def test_sentry_replay_<id>()` (hyphens / leading zeros).
  - Filter frame locals against the function signature (avoid TypeError
    from non-parameter locals like `actual_balance` in the captured
    scope).
  - Sanitize multi-line / quote-bearing error_message in the docstring.
  - Auto-import `asyncio` and `from decimal import Decimal` when needed.
  - Wrap `async def` targets in `asyncio.run(...)`.
  - Pytest output → exception-type parser for the verification gate.

Imports `SentryFrame` / `SentryException` from `oracles.sentry_replay`
(those dataclass shapes are stable). Nothing else.
"""

from __future__ import annotations

import ast as _ast
import re as _re

from oracles.sentry_replay import (  # type: ignore
    SentryException,
    SentryFrame,
    _redact_variables,
    _safe_repr,
)


_SAFE_ID_RE = _re.compile(r"[^A-Za-z0-9_]")
_ASYNC_DEF_RE = _re.compile(r"^\s*async\s+def\s+", _re.MULTILINE)
# Match any CamelCased identifier followed by ":" in pytest's E lines.
# Earlier versions limited to a suffix allow-list and missed real classes
# like UpstreamServiceUnavailable, RateLimitExceeded, AmountMismatch,
# DataAccessDenied — pytest only emits actual exception types in these
# slots, so we don't need a suffix filter.
_PYTEST_E_LINE_RE = _re.compile(
    r"^E\s+([A-Za-z_][A-Za-z0-9_.]*)\s*:",
    _re.MULTILINE,
)
_PYTEST_FAILED_RE = _re.compile(
    r"FAILED\s+\S+\s+-\s+([A-Za-z_][A-Za-z0-9_.]*)\s*:"
)


# ---------------------------------------------------------------------------
# Pytest output parser — verification gate input.
# ---------------------------------------------------------------------------

def parse_sandbox_exception_type(output: str) -> str:
    """Extract the actual exception type pytest reported.

    Returns "" if nothing matches (e.g. test passed, sandbox crash before
    pytest, or output truncated). Pure function. No LLM.
    """
    if not output:
        return ""
    matches = _PYTEST_E_LINE_RE.findall(output)
    if matches:
        # Ignore uppercase detail prefixes (e.g. "DETAIL") that are emitted
        # by Postgres in pytest E-lines; keep the real exception class.
        for candidate in reversed(matches):
            base = candidate.rsplit(".", 1)[-1]
            if base.isupper():
                continue
            return candidate
    s = _PYTEST_FAILED_RE.search(output)
    return s.group(1) if s else ""


# ---------------------------------------------------------------------------
# Source-side AST helpers.
# ---------------------------------------------------------------------------

def is_async_function(source: str, func_name: str) -> bool:
    """Is `func_name` declared as `async def` in `source`?"""
    if not source or not func_name:
        return False
    pat = _re.compile(
        rf"^\s*async\s+def\s+{_re.escape(func_name)}\s*\(",
        _re.MULTILINE,
    )
    return bool(pat.search(source))


def function_param_names(source: str, func_name: str) -> set[str] | None:
    """Parse `source`, return the parameter names of `func_name`.

    Returns None if AST parse fails or function isn't found — caller
    falls back to passing all locals.
    """
    info = _function_signature(source, func_name)
    return None if info is None else set(info.keys())


def function_param_types(source: str, func_name: str) -> dict[str, str]:
    """Parameter type annotations for `func_name`. Stringified.

    Returns {} if no annotations found or AST parse fails. Used by
    `safe_repr_typed` to override `_safe_repr` when the function
    expects a specific scalar type (e.g. `tax_rate: float` should
    NOT receive `Decimal("0.0825")` even if the captured value
    looks decimal-shaped after JSON roundtrip).
    """
    info = _function_signature(source, func_name)
    return {} if info is None else {k: v for k, v in info.items() if v}


def _function_signature(source: str, func_name: str) -> dict[str, str] | None:
    """Internal: returns {param_name: annotation_str} (annotation may be "")."""
    if not source or not func_name:
        return None
    try:
        tree = _ast.parse(source)
    except SyntaxError:
        return None
    short = func_name.split(".")[-1]
    for node in _ast.walk(tree):
        if isinstance(node, (_ast.FunctionDef, _ast.AsyncFunctionDef)) and node.name == short:
            out: dict[str, str] = {}
            args = node.args
            for a in (args.posonlyargs or []) + args.args + args.kwonlyargs:
                out[a.arg] = _ast.unparse(a.annotation) if a.annotation else ""
            if args.vararg:
                out[args.vararg.arg] = _ast.unparse(args.vararg.annotation) if args.vararg.annotation else ""
            if args.kwarg:
                out[args.kwarg.arg] = _ast.unparse(args.kwarg.annotation) if args.kwarg.annotation else ""
            return out
    return None


# ---------------------------------------------------------------------------
# Type-aware safe_repr — Path B always-on primitive #1.
# Override `_safe_repr` when the function's signature tells us the expected
# scalar type. Fixes v3 #7 Decimal/float drift: `tax_rate: float` annotation
# means we must emit `0.0825`, not `Decimal("0.0825")`.
# ---------------------------------------------------------------------------

_NUMERIC_HINTS = {"float", "int", "complex"}
_DECIMAL_HINTS = {"Decimal", "decimal.Decimal"}
_STR_HINTS = {"str", "bytes"}
_BOOL_HINTS = {"bool"}


def safe_repr_typed(value: object, type_hint: str = "") -> str:
    """`_safe_repr` enhanced with type-annotation awareness.

    Falls back to `_safe_repr` when hint is unknown / empty / generic.
    """
    hint = (type_hint or "").strip()
    # Strip generic wrappers: `Optional[float]` → `float`, `int | None` → `int`.
    hint_core = _extract_scalar_hint(hint)

    if hint_core in _NUMERIC_HINTS:
        # Force numeric repr — never wrap as Decimal.
        try:
            if isinstance(value, bool):
                return str(int(value))
            if isinstance(value, (int, float)):
                return str(value)
            s = str(value)
            if hint_core == "int":
                return str(int(float(s)))
            return str(float(s))
        except (TypeError, ValueError):
            return _safe_repr(value)

    if hint_core in _DECIMAL_HINTS:
        # Explicitly Decimal-typed parameter: keep precision-preserving wrap.
        s = str(value).strip("'\"")
        return f'Decimal("{s}")'

    if hint_core in _STR_HINTS:
        return repr(str(value))

    if hint_core in _BOOL_HINTS:
        return str(bool(value))

    return _safe_repr(value)


def _extract_scalar_hint(hint: str) -> str:
    """Pull a known scalar type out of a possibly-wrapped annotation.

    `Optional[float]` → `float`, `float | None` → `float`,
    `Union[int, str]` → "" (ambiguous), `Decimal` → `Decimal`.
    Returns "" for unknown types (`dict`, `list`, custom classes) — caller
    falls back to `_safe_repr`. Iterative; no recursion (avoids stack
    blow-up on `dict` / `list` / other non-scalar annotations).
    """
    if not hint:
        return ""
    bare = hint.replace(" ", "")
    for _ in range(8):  # bounded unwrap, never recurse
        if bare in _NUMERIC_HINTS | _DECIMAL_HINTS | _STR_HINTS | _BOOL_HINTS:
            return bare
        m = _re.match(r"^Optional\[([^\[\]]+)\]$", bare)
        if m:
            new = m.group(1).replace(" ", "")
            if new == bare:
                return ""
            bare = new
            continue
        parts = [p for p in bare.split("|") if p and p != "None"]
        if len(parts) == 1:
            new = parts[0]
            if new == bare:
                return ""  # `dict`, `list`, or custom class — unknown scalar
            bare = new
            continue
        return ""
    return ""


# ---------------------------------------------------------------------------
# Call expression builder — filter frame locals against signature.
# ---------------------------------------------------------------------------

_SKIP_LOCAL_KEYS = {"self", "cls", "__class__", "__return__", "__exception__"}


def build_call_from_frame(frame: SentryFrame, source: str) -> str | None:
    """Build a function call expression from frame locals.

    Filters frame locals against the function's actual signature
    (drop non-parameter locals to avoid TypeError) AND coerces
    each kwarg's literal repr to match the parameter's type
    annotation when present (avoid Decimal/float drift).
    """
    func_name = frame.function
    if not func_name:
        return None

    sig_params = function_param_names(source, func_name)
    sig_types = function_param_types(source, func_name)

    if frame.variables:
        safe_vars = _redact_variables(frame.variables)
        args: list[str] = []
        for k, v in safe_vars.items():
            if k in _SKIP_LOCAL_KEYS or k.startswith("__"):
                continue
            if sig_params is not None and k not in sig_params:
                continue
            literal = safe_repr_typed(v, sig_types.get(k, ""))
            args.append(f"{k}={literal}")
            if len(args) >= 8:
                break
        if args:
            return f"{func_name}({', '.join(args)})"

    return f"{func_name}()"


# ---------------------------------------------------------------------------
# Fuzzy source resolver — Path B always-on primitive #2.
# Real Sentry filenames are absolute prod paths (`/app/src/...`) or whatever
# the deploy box recorded. On a dev machine the same file lives at a
# different prefix. Walk a small set of deterministic transforms to find
# it. Pure stdlib. No agent.
# ---------------------------------------------------------------------------

from pathlib import Path as _Path

_RGLOB_NOISE = {"node_modules", ".git", "site-packages", "__pycache__",
                ".venv", "venv", "dist", "build"}


def resolve_source_with_hints(
    filename: str, repo_root, path_hints: list[str] | None = None
) -> str:
    """Like `resolve_source_fuzzy` but tries `path_hints` first.

    Used by the agent self-refusal loop: when the supervisor recovers a
    likely import path via web_search / rag_search, it passes those paths
    here as `path_hints` so the second `deterministic_repro` attempt
    actually has a fighting chance.

    Hints are tried as both absolute paths and relative-to-repo. If none
    resolve, falls through to the standard `resolve_source_fuzzy` chain.
    """
    if path_hints:
        repo = _Path(repo_root).resolve()
        for hint in path_hints:
            if not hint:
                continue
            for cand in (_Path(hint), repo / hint.lstrip("/")):
                try:
                    if cand.is_file():
                        return cand.read_text(errors="replace")
                except Exception:
                    continue
    return resolve_source_fuzzy(filename, repo_root)


def resolve_source_fuzzy(filename: str, repo_root) -> str:
    """Return the contents of `filename` resolved against `repo_root`.

    Returns "" if no candidate is found. Strategies, in order:

      1. Try `filename` as an absolute path on this machine.
      2. Try `repo_root / filename` (with leading slashes stripped).
      3. Strip leading components 1..N and join under repo_root —
         handles `/app/src/foo.py` vs dev-side `src/foo.py`.
      4. `repo_root.rglob(basename)` excluding common noise dirs.
         Single match: use it. Multiple matches: pick the one whose
         path shares the longest tail with `filename`.

    Determinism: same (filename, repo_root, on-disk state) → same bytes.
    """
    if not filename:
        return ""
    repo = _Path(repo_root).resolve()

    # 1, 2, 3 — exact + prefix-strip candidates
    candidates: list[_Path] = []
    abs_p = _Path(filename)
    candidates.append(abs_p)
    candidates.append(repo / filename.lstrip("/"))
    parts = abs_p.parts
    for i in range(1, len(parts)):
        candidates.append(repo.joinpath(*parts[i:]))

    for c in candidates:
        try:
            if c.is_file():
                return c.read_text(errors="replace")
        except Exception:
            continue

    # 4 — basename rglob with noise filter
    basename = abs_p.name
    if basename:
        try:
            hits = [
                h for h in repo.rglob(basename)
                if not any(part in _RGLOB_NOISE for part in h.parts)
                and h.is_file()
            ]
        except Exception:
            hits = []
        if len(hits) == 1:
            try:
                return hits[0].read_text(errors="replace")
            except Exception:
                pass
        elif len(hits) > 1:
            # Prefer the candidate sharing the longest path-tail with the
            # captured filename. Keeps determinism vs. just "first hit".
            def _tail_match(h: _Path) -> int:
                hp = h.parts
                fp = parts
                n = min(len(hp), len(fp))
                k = 0
                while k < n and hp[-1 - k] == fp[-1 - k]:
                    k += 1
                return k
            best = max(hits, key=_tail_match)
            try:
                return best.read_text(errors="replace")
            except Exception:
                pass
    return ""


# ---------------------------------------------------------------------------
# Top-level synthesizer.
# ---------------------------------------------------------------------------

def build_replay_test_v2(
    exc: SentryException,
    frame: SentryFrame,
    source: str,
) -> str | None:
    """Render a sealed pytest test from frame locals. Pure function. Zero LLM.

    Drop-in replacement for `oracles.sentry_replay.build_replay_test`.
    """
    func_name = frame.function
    if not func_name or func_name == "<module>":
        return None

    call_expr = build_call_from_frame(frame, source)
    if not call_expr:
        return None

    if is_async_function(source, func_name):
        call_expr = f"asyncio.run({call_expr})"
        async_used = True
    else:
        async_used = False

    safe_id = _SAFE_ID_RE.sub("_", str(exc.issue_id or "x"))
    if safe_id and safe_id[0].isdigit():
        safe_id = f"id_{safe_id}"

    imports: list[str] = []
    if async_used:
        imports.append("import asyncio")
    if "Decimal(" in call_expr:
        imports.append("from decimal import Decimal")
    import_lines = ("\n".join(imports) + "\n") if imports else ""

    docstring = (
        (exc.error_message or "")
        .replace("\n", " ")
        .replace("\r", " ")
        .replace('"', "'")
    )[:120]

    body = [
        f"{import_lines}from target import *",
        "",
        f"def test_sentry_replay_{safe_id}():",
        f"    \"\"\"Replay: {exc.error_type}: {docstring}\"\"\"",
        f"    {call_expr}",
        "",
    ]
    return "\n".join(body)


# ---------------------------------------------------------------------------
# Request-context replay synthesizer (PR2).
# ---------------------------------------------------------------------------

# Headers we keep in the test body verbatim — routing-relevant, non-secret.
# Mirrors the allowlist in sentry_replay._redact_headers so the test reflects
# what was actually transmitted (after the parser's allowlist already ran).
_REQUEST_REPLAY_HEADER_KEEP = frozenset({
    "content-type", "accept", "user-agent",
    "x-request-id", "x-correlation-id", "x-forwarded-proto",
})


def build_request_replay_test_v2(
    exc: SentryException,
    frame: SentryFrame,
) -> str | None:
    """Emit a HTTP-replay pytest from the captured `request` interface.

    Returns None when:
      - `exc.request` is unset
      - method or url is missing (no point firing a request without them)
      - the parsed body shape is unsafe to inline

    Compliance:
      The emitted test does NOT name any framework. It calls a `client`
      fixture (the caller — orchestrator + agent — supplies a conftest
      that defines `client` based on `introspect_repo` findings). That
      conftest is advisory infrastructure (`in_evidence_path: False`),
      not part of the sealed test bytes. Test bytes contain only:
        - method, url, headers, body from the Sentry payload
        - the issue id (sanitized for valid Python identifier)
      All of which originated from the captured event — never from an LLM.
    """
    req = getattr(exc, "request", None)
    if req is None:
        return None
    method = (getattr(req, "method", "") or "").strip().upper()
    url = (getattr(req, "url", "") or "").strip()
    if not method or not url:
        return None

    safe_id = _SAFE_ID_RE.sub("_", str(exc.issue_id or "x"))
    if safe_id and safe_id[0].isdigit():
        safe_id = f"id_{safe_id}"

    # Strip scheme+host from absolute URLs — TestClients work on paths.
    # If url is already a path, leave it. Path-only assumption keeps the
    # test framework-agnostic.
    request_path = _path_from_url(url)

    body_kwarg = _request_body_kwarg(req)
    headers_kwarg = _request_headers_kwarg(req)
    qs_kwarg = _request_query_kwarg(req)

    docstring = (
        (exc.error_message or "")
        .replace("\n", " ")
        .replace("\r", " ")
        .replace('"', "'")
    )[:120]

    # Compose the `client.request(...)` call. Args are positional method+url
    # to match every common Python HTTP client (httpx, requests, starlette
    # TestClient, django.test.Client, flask test_client). Keep order
    # explicit for readability.
    call_kwargs = [f"method={method!r}", f"url={request_path!r}"]
    if qs_kwarg:
        call_kwargs.append(f"params={qs_kwarg}")
    if headers_kwarg:
        call_kwargs.append(f"headers={headers_kwarg}")
    if body_kwarg:
        call_kwargs.append(body_kwarg)
    call_expr = "client.request(" + ", ".join(call_kwargs) + ")"

    target_fn = (frame.function or "").strip() or "<unknown>"
    lines = [
        f"def test_sentry_replay_request_{safe_id}(client):",
        f"    \"\"\"Replay {target_fn}: {exc.error_type}: {docstring}\"\"\"",
        # No assertion: if the captured handler crashes, the exception
        # surfaces through the test client (most clients re-raise by
        # default; if not, `client` fixture is expected to be configured
        # with raise_server_exceptions=True).
        f"    {call_expr}",
        "",
    ]
    return "\n".join(lines)


def _path_from_url(url: str) -> str:
    """Best-effort scheme+host stripper. Returns just the path+query."""
    if "://" not in url:
        return url
    try:
        from urllib.parse import urlparse, urlunparse
        p = urlparse(url)
        # Reassemble without scheme/netloc — TestClients ignore those anyway
        return urlunparse(("", "", p.path or "/", p.params, p.query, p.fragment))
    except Exception:
        return url


def _request_body_kwarg(req) -> str:
    """Render the captured body as a kwarg snippet ('json=...' or 'data=...').

    Returns empty string if no body is present or the body is malformed.
    """
    data = getattr(req, "data", None)
    if data is None:
        return ""
    headers = getattr(req, "headers", None) or {}
    ct = ""
    if isinstance(headers, dict):
        # Case-insensitive content-type lookup
        for k, v in headers.items():
            if k.lower() == "content-type":
                ct = str(v).lower()
                break
    if isinstance(data, dict):
        return f"json={data!r}"
    if isinstance(data, list):
        return f"json={data!r}"
    if isinstance(data, str):
        if "application/json" in ct:
            # String body that's labelled JSON — keep as content kwarg
            return f"content={data!r}"
        return f"data={data!r}"
    return ""


def _request_headers_kwarg(req) -> str:
    """Render the routing-relevant headers as a kwarg snippet."""
    headers = getattr(req, "headers", None) or {}
    if not isinstance(headers, dict) or not headers:
        return ""
    keep: dict[str, str] = {}
    for name, value in headers.items():
        if str(name).lower() in _REQUEST_REPLAY_HEADER_KEEP:
            if isinstance(value, str) and value and value != "[REDACTED:HEADER]":
                keep[str(name)] = value
    if not keep:
        return ""
    return repr(keep)


def _request_query_kwarg(req) -> str:
    """Render the captured query string as a `params=` kwarg.

    Supports dict shape (Sentry common) and string shape. Returns ""
    when query is empty or unparseable.
    """
    qs = getattr(req, "query_string", None)
    if qs is None or qs == "":
        return ""
    if isinstance(qs, dict):
        return repr(qs)
    if isinstance(qs, str):
        try:
            from urllib.parse import parse_qsl
            parsed = dict(parse_qsl(qs, keep_blank_values=True))
            return repr(parsed) if parsed else ""
        except Exception:
            return ""
    return ""
