"""Known API error shapes for major providers.

Pattern-match Sentry frame locals against these shapes to synthesize
`responses` mocks without an LLM call. Stable reference data embedded
in the codebase — providers don't change error schemas without major
versioning.
"""
from __future__ import annotations

import re


# ---------------------------------------------------------------------------
# Stripe
# ---------------------------------------------------------------------------

STRIPE_ERRORS: dict[str, dict] = {
    "card_declined": {
        "error": {
            "code": "card_declined",
            "decline_code": "generic_decline",
            "type": "card_error",
            "message": "Your card was declined.",
            "param": "card",
        }
    },
    "insufficient_funds": {
        "error": {
            "code": "card_declined",
            "decline_code": "insufficient_funds",
            "type": "card_error",
            "message": "Your card has insufficient funds.",
        }
    },
    "invalid_cvc": {
        "error": {
            "code": "incorrect_cvc",
            "type": "card_error",
            "message": "Your card's security code is incorrect.",
        }
    },
    "expired_card": {
        "error": {
            "code": "expired_card",
            "type": "card_error",
            "message": "Your card has expired.",
        }
    },
    "rate_limit": {
        "error": {
            "code": "rate_limit",
            "type": "invalid_request_error",
            "message": "Too many requests made to the API too quickly.",
        }
    },
    "authentication_required": {
        "error": {
            "code": "authentication_required",
            "type": "card_error",
            "message": "This payment requires authentication.",
        }
    },
}

STRIPE_STATUS_CODES: dict[str, int] = {
    "card_declined": 402,
    "insufficient_funds": 402,
    "invalid_cvc": 402,
    "expired_card": 402,
    "rate_limit": 429,
    "authentication_required": 402,
}

STRIPE_URL_RE = re.compile(r"stripe\.com|api\.stripe", re.IGNORECASE)


# ---------------------------------------------------------------------------
# Pattern matching
# ---------------------------------------------------------------------------

def match_from_locals(frame_vars: dict) -> tuple[str, int, dict] | None:
    """Match frame locals against known Stripe error shapes.

    Returns (url_hint, status_code, body_dict) or None.
    """
    for key, val in frame_vars.items():
        if not isinstance(val, dict):
            continue

        # Stripe: {"error": {"code": "card_declined", ...}}
        err = val.get("error")
        if isinstance(err, dict):
            code = err.get("code", "") or err.get("decline_code", "")
            if code in STRIPE_ERRORS:
                return (
                    "https://api.stripe.com/v1/",
                    STRIPE_STATUS_CODES.get(code, 402),
                    STRIPE_ERRORS[code],
                )

    return None


def url_from_locals(frame_vars: dict) -> str:
    """Extract a URL hint from frame locals, preferring Stripe domain."""
    for val in frame_vars.values():
        if not isinstance(val, str):
            continue
        if val.startswith("http"):
            if STRIPE_URL_RE.search(val):
                return val[:300]
    for val in frame_vars.values():
        if isinstance(val, str) and val.startswith("http"):
            return val[:300]
    return ""
