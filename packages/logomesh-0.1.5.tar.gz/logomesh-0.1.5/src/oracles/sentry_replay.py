"""Sentry oracle — fetch production crash events and synthesize repro tests."""

from __future__ import annotations

import os
import re
import textwrap
import time
from dataclasses import dataclass, field
from typing import Any

import httpx

from core.pii_redactor import is_sensitive_key, redact_mapping, redact_text
from logomesh_log import log


_SENTRY_AUTH_TOKEN = os.getenv("SENTRY_AUTH_TOKEN", "")
_SENTRY_ORG = os.getenv("SENTRY_ORG", "")
_SENTRY_PROJECT = os.getenv("SENTRY_PROJECT", "")
_SENTRY_BASE_URL = os.getenv("SENTRY_BASE_URL", "https://sentry.io")
_MAX_ISSUES_PER_FILE = 5
_MAX_API_CALLS_PER_PR = int(os.getenv("LOGOMESH_SENTRY_MAX_CALLS", "50"))


@dataclass
class SentryFrame:
    filename: str
    function: str
    lineno: int
    context_line: str
    variables: dict


@dataclass
class SentryRequest:
    """HTTP request context captured by the Sentry SDK at crash time.

    Headers + body run through the same PII redactor as frame locals; an
    additional header allowlist (Content-Type, Accept, User-Agent, Host)
    keeps non-sensitive routing info while masking auth.
    """
    method: str = ""
    url: str = ""
    headers: dict[str, str] = field(default_factory=dict)
    query_string: Any = None      # dict or raw string depending on SDK version
    data: Any = None              # body — JSON dict or raw string
    fragment: str = ""


@dataclass
class SentryBreadcrumb:
    timestamp: str = ""
    category: str = ""
    type: str = ""
    level: str = ""
    message: str = ""
    data: dict[str, Any] = field(default_factory=dict)


@dataclass
class SentryThread:
    """Per-thread snapshot. `frames` mirrors the exception stacktrace shape."""
    id: int = 0
    name: str = ""
    crashed: bool = False
    current: bool = False
    held_locks: list[str] = field(default_factory=list)
    state: str = ""               # "RUNNABLE" | "WAITING" | "BLOCKED" | ...
    frames: list[SentryFrame] = field(default_factory=list)


@dataclass
class SentryRuntime:
    """Subset of `contexts.runtime` we actually use for repro."""
    name: str = ""                # "CPython"
    version: str = ""             # "3.12.5"
    build: str = ""


@dataclass
class SentryException:
    issue_id: str
    issue_url: str
    error_type: str
    error_message: str
    last_seen: str
    event_count: int
    frames: list[SentryFrame]
    timezone: str = ""

    # New extraction surfaces — populated when present on the Sentry payload.
    # All optional so existing callers continue to work; downstream consumers
    # opt into the richer context.
    request: SentryRequest | None = None
    modules: dict[str, str] = field(default_factory=dict)   # package → version
    breadcrumbs: list[SentryBreadcrumb] = field(default_factory=list)
    threads: list[SentryThread] = field(default_factory=list)
    runtime: SentryRuntime | None = None
    release: str = ""             # git SHA or version tag at crash time
    transaction: str = ""         # framework route / view name



# ---------------------------------------------------------------------------
# Sentry API
# ---------------------------------------------------------------------------

async def _fetch_event_unfiltered(
    client: httpx.AsyncClient,
    issue_id: str,
    headers: dict,
) -> SentryException | None:
    """Fetch the latest event for an issue and parse it into a SentryException.

    Does not filter by file. Returns None on non-200 or if the event has no
    parseable exception entry.
    """
    url = f"{_SENTRY_BASE_URL}/api/0/issues/{issue_id}/events/latest/"
    resp = await client.get(url, headers=headers)
    if resp.status_code != 200:
        return None

    event = resp.json()
    entries = event.get("entries", [])

    for entry in entries:
        if entry.get("type") != "exception":
            continue
        for value in entry.get("data", {}).get("values", []):
            error_type = value.get("type", "Exception")
            error_message = value.get("value", "")
            stacktrace = value.get("stacktrace", {})
            raw_frames = stacktrace.get("frames", [])

            frames = []
            for f in raw_frames:
                # Compliance chokepoint #1: scrub frame locals at parse
                # time so every downstream consumer (LLM prompts, generated
                # tests, audit log, registry) sees the redacted view. See
                # docs/run_results/pii_audit_2026-05-07.md.
                frames.append(SentryFrame(
                    filename=f.get("filename", ""),
                    function=f.get("function", ""),
                    lineno=f.get("lineNo", 0) or 0,
                    context_line=f.get("contextLine", ""),
                    variables=redact_mapping(f.get("vars", {}) or {}),
                ))

            issue_url = f"{_SENTRY_BASE_URL}/organizations/{_SENTRY_ORG}/issues/{issue_id}/"

            return SentryException(
                issue_id=issue_id,
                issue_url=issue_url,
                error_type=error_type,
                # error_message goes into the test docstring AND the
                # artifact's incident.message field. Scrub at parse time
                # so neither path can leak PII downstream.
                error_message=redact_text(error_message),
                last_seen=event.get("dateCreated", ""),
                event_count=int(event.get("groupID", issue_id) and 1),
                frames=frames,
                timezone=_extract_timezone_from_event(event),
            )

    return None


async def fetch_event_by_issue(
    issue_id: str,
    *,
    org: str | None = None,
    project: str | None = None,
    auth_token: str | None = None,
    base_url: str | None = None,
    timeout: float = 15.0,
) -> SentryException:
    """Fetch the latest event for a Sentry issue. Standalone version.

    Reads `SENTRY_AUTH_TOKEN` from env if `auth_token` is not provided.
    `org`/`project` are accepted but not strictly required: the events/latest
    endpoint is keyed by issue_id alone. Returns a parsed `SentryException`.

    If `LOGOMESH_SENTRY_FIXTURE` is set, the HTTP fetch is bypassed and the
    event is loaded from that JSON file instead. Used for offline demos and
    tests.

    Raises:
        RuntimeError: missing auth token, network failure, or unparseable event.
    """
    fixture_path = os.getenv("LOGOMESH_SENTRY_FIXTURE", "").strip()
    if fixture_path:
        return _load_fixture_event(fixture_path, issue_id, base_url)

    token = (auth_token or os.getenv("SENTRY_AUTH_TOKEN", "")).strip()
    if not token:
        raise RuntimeError(
            "SENTRY_AUTH_TOKEN is not set. Create a Sentry auth token with "
            "`event:read` scope and export it: "
            "`export SENTRY_AUTH_TOKEN=...`"
        )

    api_base = (base_url or os.getenv("SENTRY_BASE_URL", _SENTRY_BASE_URL)).rstrip("/")
    headers = {"Authorization": f"Bearer {token}"}

    async with httpx.AsyncClient(timeout=timeout, base_url=api_base) as client:
        try:
            resp = await client.get(
                f"/api/0/issues/{issue_id}/events/latest/", headers=headers,
            )
        except httpx.HTTPError as e:
            raise RuntimeError(f"Sentry API request failed: {e}") from e

        if resp.status_code == 401 or resp.status_code == 403:
            raise RuntimeError(
                "Sentry API rejected the auth token "
                f"(HTTP {resp.status_code}). Check SENTRY_AUTH_TOKEN scopes."
            )
        if resp.status_code == 404:
            raise RuntimeError(
                f"Sentry issue {issue_id!r} not found (HTTP 404). "
                "Check the URL and that your token has access to this org."
            )
        if resp.status_code != 200:
            raise RuntimeError(
                f"Sentry API returned HTTP {resp.status_code}: "
                f"{resp.text[:200]}"
            )

        event = resp.json()
        exc = _parse_event_to_exception(event, issue_id, api_base)
        if exc is None:
            raise RuntimeError(
                f"Sentry issue {issue_id} has no parseable exception entry "
                "(empty stack trace?)."
            )
        return exc


def _load_fixture_event(
    path: str, issue_id: str, base_url: str | None,
) -> SentryException:
    """Load a Sentry event JSON file from disk and parse it.

    Lets `logomesh repro` run offline against a checked-in fixture for demos
    and tests — no Sentry account or auth token required.
    """
    import json as _json
    from pathlib import Path

    p = Path(path).expanduser()
    if not p.is_file():
        raise RuntimeError(f"LOGOMESH_SENTRY_FIXTURE path not found: {path}")
    try:
        event = _json.loads(p.read_text())
    except Exception as e:
        raise RuntimeError(f"failed to parse fixture {path}: {e}") from e

    api_base = (base_url or _SENTRY_BASE_URL).rstrip("/")
    exc = _parse_event_to_exception(event, issue_id, api_base)
    if exc is None:
        raise RuntimeError(
            f"fixture {path} has no parseable exception entry"
        )
    return exc


def _extract_timezone_from_event(event: dict) -> str:
    """Extract the timezone tag from a Sentry event dict. Returns "" if absent."""
    tags = event.get("tags") or []
    if isinstance(tags, list):
        for tag in tags:
            if isinstance(tag, dict) and tag.get("key") == "timezone":
                return str(tag.get("value", ""))
    elif isinstance(tags, dict):
        return str(tags.get("timezone", ""))
    return ""


def _parse_event_to_exception(
    event: dict, issue_id: str, base_url: str,
) -> SentryException | None:
    """Parse a Sentry event JSON dict into a SentryException, no filtering."""
    for entry in event.get("entries", []):
        if entry.get("type") != "exception":
            continue
        for value in entry.get("data", {}).get("values", []):
            raw_frames = value.get("stacktrace", {}).get("frames", []) or []
            # Compliance chokepoint #2: scrub frame locals at parse time
            # (mirror of _fetch_event_unfiltered).
            frames = [_parse_frame(f) for f in raw_frames]
            return SentryException(
                issue_id=issue_id,
                issue_url=f"{base_url}/organizations/-/issues/{issue_id}/",
                error_type=value.get("type", "Exception"),
                # See _fetch_event_unfiltered: scrub at parse time.
                error_message=redact_text(value.get("value", "")),
                last_seen=event.get("dateCreated", ""),
                event_count=int(event.get("groupID", issue_id) and 1),
                frames=frames,
                timezone=_extract_timezone_from_event(event),
                request=_parse_request(event),
                modules=_parse_modules(event),
                breadcrumbs=_parse_breadcrumbs(event),
                threads=_parse_threads(event),
                runtime=_parse_runtime(event),
                release=str(event.get("release") or "").strip(),
                transaction=_extract_transaction(event),
            )
    return None


def _parse_frame(f: dict) -> SentryFrame:
    """Convert a Sentry frame dict to a SentryFrame, redacting locals."""
    return SentryFrame(
        filename=f.get("filename", ""),
        function=f.get("function", ""),
        lineno=f.get("lineNo", 0) or 0,
        context_line=f.get("contextLine", ""),
        variables=redact_mapping(f.get("vars", {}) or {}),
    )


# --- Headers allowlist: routing-relevant non-secret headers --------------
_HEADER_ALLOWLIST = {
    "content-type", "accept", "user-agent", "host",
    "accept-encoding", "accept-language",
    "x-request-id", "x-correlation-id", "x-forwarded-proto",
}


def _redact_headers(headers: Any) -> dict[str, str]:
    """Header dict / list-of-pairs → redacted dict.

    Non-allowlisted header values are masked. Allowlisted ones keep their
    value (useful for the agent to know it was a JSON POST to a specific
    URL pattern). Header NAMES themselves are not considered PII so we
    keep them all for debuggability.
    """
    if not headers:
        return {}
    # Sentry serializes headers as either {name: value} or [[name, value], ...]
    pairs: list[tuple[str, str]] = []
    if isinstance(headers, dict):
        pairs = [(str(k), str(v)) for k, v in headers.items()]
    elif isinstance(headers, list):
        for item in headers:
            if isinstance(item, (list, tuple)) and len(item) == 2:
                pairs.append((str(item[0]), str(item[1])))
    out: dict[str, str] = {}
    for name, value in pairs:
        if name.lower() in _HEADER_ALLOWLIST:
            out[name] = redact_text(value) if isinstance(redact_text(value), str) else value
        else:
            out[name] = "[REDACTED:HEADER]"
    return out


def _parse_request(event: dict) -> SentryRequest | None:
    """Extract `request` interface from the event payload.

    Sentry stores it under `entries[].data` with type=='request' OR as a
    top-level `request` dict on raw-store events. Try both.
    """
    raw = None
    for entry in event.get("entries", []) or []:
        if entry.get("type") == "request":
            raw = entry.get("data") or {}
            break
    if raw is None:
        raw = event.get("request") or None
    if not raw:
        return None

    body = raw.get("data")
    if isinstance(body, dict):
        body = redact_mapping(body)
    elif isinstance(body, str):
        body = redact_text(body)

    qs = raw.get("query") if "query" in raw else raw.get("queryString")
    if isinstance(qs, dict):
        qs = redact_mapping(qs)
    elif isinstance(qs, list):
        # list of [k, v] pairs — typical Sentry serialization
        qs = {
            str(p[0]): (
                "[REDACTED:FIELD]"
                if is_sensitive_key(p[0])
                else (redact_text(p[1]) if isinstance(p[1], str) else p[1])
            )
            for p in qs if isinstance(p, (list, tuple)) and len(p) == 2
        }
    elif isinstance(qs, str):
        qs = redact_text(qs)

    return SentryRequest(
        method=str(raw.get("method") or "").upper(),
        url=str(raw.get("url") or ""),
        headers=_redact_headers(raw.get("headers")),
        query_string=qs,
        data=body,
        fragment=str(raw.get("fragment") or ""),
    )


def _parse_modules(event: dict) -> dict[str, str]:
    """Sentry sends `modules` as {pkg: version} at the top level."""
    modules = event.get("modules") or {}
    if not isinstance(modules, dict):
        return {}
    return {str(k): str(v) for k, v in modules.items() if v is not None}


def _parse_breadcrumbs(event: dict) -> list[SentryBreadcrumb]:
    """Pull breadcrumbs from `entries[].data.values[]` (type='breadcrumbs')
    or from the top-level `breadcrumbs.values` shape. Each breadcrumb's
    `data` payload is scrubbed."""
    raw_list: list[dict] = []
    for entry in event.get("entries", []) or []:
        if entry.get("type") == "breadcrumbs":
            raw_list = entry.get("data", {}).get("values", []) or []
            break
    if not raw_list:
        top = event.get("breadcrumbs")
        if isinstance(top, dict):
            raw_list = top.get("values", []) or []
        elif isinstance(top, list):
            raw_list = top
    out: list[SentryBreadcrumb] = []
    for bc in raw_list:
        if not isinstance(bc, dict):
            continue
        data = bc.get("data")
        if isinstance(data, dict):
            data = redact_mapping(data)
        elif isinstance(data, str):
            data = redact_text(data)
        else:
            data = {} if data is None else data
        out.append(SentryBreadcrumb(
            timestamp=str(bc.get("timestamp") or ""),
            category=str(bc.get("category") or ""),
            type=str(bc.get("type") or ""),
            level=str(bc.get("level") or ""),
            message=str(redact_text(bc.get("message") or "")),
            data=data if isinstance(data, dict) else {"_raw": data},
        ))
    return out


def _parse_threads(event: dict) -> list[SentryThread]:
    """Pull per-thread snapshots if present.

    Useful when the crashing exception isn't the only thread mid-flight
    — held_locks + state on a non-crashed thread are key race signals.
    """
    raw_list: list[dict] = []
    for entry in event.get("entries", []) or []:
        if entry.get("type") == "threads":
            raw_list = entry.get("data", {}).get("values", []) or []
            break
    if not raw_list:
        top = event.get("threads")
        if isinstance(top, dict):
            raw_list = top.get("values", []) or []
        elif isinstance(top, list):
            raw_list = top
    out: list[SentryThread] = []
    for th in raw_list:
        if not isinstance(th, dict):
            continue
        st = th.get("stacktrace") or {}
        raw_frames = st.get("frames", []) or [] if isinstance(st, dict) else []
        held_locks = th.get("heldLocks") or th.get("held_locks") or []
        if isinstance(held_locks, dict):
            held_locks = list(held_locks.keys())
        elif not isinstance(held_locks, list):
            held_locks = [str(held_locks)]
        out.append(SentryThread(
            id=int(th.get("id") or 0),
            name=str(th.get("name") or ""),
            crashed=bool(th.get("crashed")),
            current=bool(th.get("current")),
            held_locks=[str(x) for x in held_locks],
            state=str(th.get("state") or ""),
            frames=[_parse_frame(f) for f in raw_frames],
        ))
    return out


def _extract_transaction(event: dict) -> str:
    """Sentry surfaces the framework route / view name under `transaction`
    at the top level, OR (older payloads) inside `tags`."""
    direct = event.get("transaction")
    if direct:
        return str(direct).strip()
    tags = event.get("tags")
    if isinstance(tags, dict):
        return str(tags.get("transaction") or "").strip()
    if isinstance(tags, list):
        for t in tags:
            if isinstance(t, (list, tuple)) and len(t) == 2 and t[0] == "transaction":
                return str(t[1] or "").strip()
    return ""


def _parse_runtime(event: dict) -> SentryRuntime | None:
    """Pull `contexts.runtime` if populated. Two shapes seen in the wild:
      contexts.runtime.{name, version, build}
      OR a flat top-level entry; defensive on both."""
    ctxs = event.get("contexts") or {}
    if not isinstance(ctxs, dict):
        return None
    rt = ctxs.get("runtime")
    if not isinstance(rt, dict):
        return None
    return SentryRuntime(
        name=str(rt.get("name") or ""),
        version=str(rt.get("version") or ""),
        build=str(rt.get("build") or ""),
    )


# ---------------------------------------------------------------------------
# Exception → Test translation
# ---------------------------------------------------------------------------

def _exception_to_test(
    exc: SentryException,
    source: str,
    file_path: str,
) -> str | None:
    """Translate a Sentry exception into a pytest replay test."""
    target_frame = _find_target_frame(exc, file_path)
    if not target_frame:
        return None
    return build_replay_test(exc, target_frame, source)


def build_replay_test(
    exc: SentryException,
    frame: SentryFrame,
    source: str,
) -> str | None:
    """Render a pytest test body that replays `exc` by calling `frame.function`
    with locals captured by Sentry. Returns None if the frame is unusable
    (module-level or no function name).
    """
    func_name = frame.function
    if not func_name or func_name == "<module>":
        return None

    call_expr = _build_call_from_frame(frame, source)
    if not call_expr:
        return None

    # NOTE: do NOT wrap in pytest.raises. Semantics are: prod raised, HEAD
    # should be checked for whether it still raises. If the call still raises,
    # pytest marks the test FAILED — which `repro.py` reads as "reproduced".
    # If HEAD fixed it, no exception → test PASSES → "not reproduced".
    return textwrap.dedent(f"""\
        from target import *

        def test_sentry_replay_{exc.issue_id}():
            \"\"\"Replay: {exc.error_type}: {exc.error_message[:80]}\"\"\"
            {call_expr}
    """)


def _find_target_frame(exc: SentryException, file_path: str) -> SentryFrame | None:
    """Find the stack frame closest to the target file."""
    basename = file_path.rsplit("/", 1)[-1]
    for frame in reversed(exc.frames):
        if basename in (frame.filename or ""):
            return frame
    return None


def find_innermost_app_frame(exc: SentryException) -> SentryFrame | None:
    """Pick the innermost in-app frame from a Sentry exception.

    Walks the stack from innermost outward and returns the first frame whose
    filename looks like application code (heuristic: not in site-packages, not
    a stdlib path). Falls back to the absolute innermost frame with a function.
    """
    def _looks_lib(fname: str) -> bool:
        f = (fname or "").lower()
        return (
            "site-packages" in f
            or "/dist-packages/" in f
            or f.startswith("<")
            or f.startswith("/usr/lib/python")
            or f.startswith("/usr/local/lib/python")
        )

    for frame in reversed(exc.frames):
        if not frame.function or frame.function == "<module>":
            continue
        if _looks_lib(frame.filename):
            continue
        return frame

    for frame in reversed(exc.frames):
        if frame.function and frame.function != "<module>":
            return frame
    return None


def _redact_variables(variables: dict) -> dict:
    """Strip PII/PAN from Sentry frame locals.

    Thin delegating wrapper around ``core.pii_redactor.redact_mapping``.
    Kept as a stable API because ``oracles/sentry_replay_v2.py`` imports
    it by name. Idempotent on already-redacted inputs (parse-time
    chokepoint runs first, so this becomes a no-op in the normal path).
    """
    return redact_mapping(variables or {})


def _build_call_from_frame(frame: SentryFrame, source: str) -> str | None:
    """Build a function call expression from frame locals."""
    func_name = frame.function
    if not func_name:
        return None

    if frame.variables:
        safe_vars = _redact_variables(frame.variables)
        args = []
        skip_keys = {"self", "cls", "__class__", "__return__", "__exception__"}
        for k, v in safe_vars.items():
            if k in skip_keys or k.startswith("__"):
                continue
            args.append(f"{k}={_safe_repr(v)}")
            if len(args) >= 6:
                break
        if args:
            return f"{func_name}({', '.join(args)})"

    return f"{func_name}()"


def _safe_repr(value: object) -> str:
    """Convert a Sentry variable value to a safe Python literal."""
    if value is None:
        return "None"
    # Native Python numerics pass through as-is.
    if isinstance(value, bool):
        return str(value)
    if isinstance(value, (int, float)):
        return str(value)
    s = str(value)
    if s in ("True", "False", "None"):
        return s
    # String values that look like decimal numbers: emit Decimal("49.95") so
    # the synthesized test gets the right type (fintech billing path).
    if re.match(r"^-?\d+\.\d+$", s):
        return f'Decimal("{s}")'
    if re.match(r"^-?\d+$", s):
        return s
    if s.startswith("'") or s.startswith('"'):
        return s
    return repr(s)


def _find_target_lineno(exc: SentryException, file_path: str) -> int:
    frame = _find_target_frame(exc, file_path)
    return frame.lineno if frame else 0


def _extract_replay_call(test_code: str) -> str:
    """Extract the function call from generated replay test."""
    for line in test_code.splitlines():
        stripped = line.strip()
        if stripped and not stripped.startswith(("def ", "import ", "from ", "#", '"""', "with ")):
            return stripped
    return ""


# ---------------------------------------------------------------------------
# LLM synthesis path — used by `logomesh repro` for higher-fidelity replays
# ---------------------------------------------------------------------------

def _format_all_frames(frames: list[SentryFrame]) -> str:
    """Render every frame's locals into a compact debug string for the prompt.

    Applies PII/PAN redaction before any values reach the LLM.
    """
    out = []
    for f in frames[-6:]:  # innermost ≤6 frames is enough; older ones are noise
        if not f.function or f.function == "<module>":
            continue
        safe = _redact_variables(f.variables)
        vars_repr = ", ".join(f"{k}={v!r}" for k, v in list(safe.items())[:8])
        out.append(f"- {f.function}() at {f.filename}:{f.lineno} | {vars_repr}")
    return "\n".join(out) if out else "(no frame locals captured)"


_DEFAULT_LLM_MODEL = os.getenv("LOGOMESH_REPRO_MODEL", "gpt-5-mini")


async def synthesize_test_llm(
    exc: SentryException,
    frame: SentryFrame,
    codebase_ctx: dict,
    state_bundle: object | None,
    mock_setup_code: str = "",
    *,
    model: str = "",
    max_tokens: int = 1500,
) -> str:
    """Synthesize a pytest replay using the LLM with full crash + repo context.

    Falls back to deterministic `build_replay_test()` when:
        - OPENAI_API_KEY is not set, or
        - the LLM call fails / returns empty, or
        - the synthesized code has no `def test_` function.

    Returns the test source string. Empty string only on hard fall-through.
    """
    import json as _json

    fallback = build_replay_test(exc, frame, codebase_ctx.get("function_source", ""))

    _api_key = os.getenv("LOGOMESH_LLM_API_KEY", "").strip() or os.getenv("OPENAI_API_KEY", "").strip()
    if not _api_key:
        return fallback or ""

    state_section = ""
    if state_bundle is not None:
        raw = getattr(state_bundle, "raw", {}) or {}
        redis_mock = getattr(state_bundle, "redis_mock", {}) or {}
        http_mock = getattr(state_bundle, "http_mock", {}) or {}
        request_ctx = getattr(state_bundle, "request_context", {}) or {}
        state_section = (
            f"\n## Real production state at crash time\n"
            f"DB queries captured: {len(raw.get('db_queries') or [])}\n"
            f"Redis values: {_json.dumps(redis_mock)[:400]}\n"
            f"HTTP responses: {list(http_mock.keys())[:5]}\n"
            f"Request: {request_ctx.get('method', '')} {request_ctx.get('url', '')}\n"
            f"Request body (truncated): {str(request_ctx.get('body', ''))[:500]}\n"
        )

    func_source = codebase_ctx.get("function_source", "") or ""
    imports_raw = codebase_ctx.get("imports_raw", "") or ""
    dep_defs = codebase_ctx.get("dependency_defs", "") or ""
    fixtures = codebase_ctx.get("existing_fixtures", "") or ""
    safe_locals = _redact_variables(frame.variables)
    frame_locals_str = ", ".join(
        f"{k}={v!r}" for k, v in list(safe_locals.items())[:12]
    ) or "(empty)"

    prompt = f"""Generate a pytest that reproduces this Python production crash.

## Crash
Exception: {exc.error_type}: {exc.error_message}
Function: {frame.function}() in {frame.filename}:{frame.lineno}

## Frame locals at crash (from Sentry)
{frame_locals_str}

## All frame locals (innermost stack frames)
{_format_all_frames(exc.frames)}

## Crashing function source
```python
{func_source[:3000]}
```

## Imports in that file
```python
{imports_raw[:1000]}
```

## Dependency definitions (from local imports)
```python
{dep_defs[:6000]}
```

## Existing test fixtures in this codebase
```python
{fixtures[:1500]}
```
{state_section}
## Mock setup (already available in test scope)
```python
{mock_setup_code}
```

## Rules
1. Import the function from `target` module: `from target import {frame.function}`
2. Use the mock setup names if provided (`_REDIS_MOCK`, `_HTTP_MOCK`, `_SQLITE_PATH`)
3. Use the real values from frame locals where available
4. Do NOT wrap the call in try/except or pytest.raises — the exception must propagate
5. Define exactly one function: `def test_sentry_replay_{exc.issue_id}(): ...`
6. Return ONLY the pytest source code — no markdown fences, no explanation
"""

    try:
        from openai import AsyncOpenAI  # type: ignore
    except ImportError:
        return fallback or ""

    client = AsyncOpenAI(
        api_key=_api_key,
        base_url=os.getenv("LOGOMESH_LLM_BASE_URL") or None,
        timeout=30.0,
        max_retries=1,
    )
    try:
        resp = await client.chat.completions.create(
            model=model or _DEFAULT_LLM_MODEL,
            max_tokens=max_tokens,
            temperature=0,
            messages=[{"role": "user", "content": prompt}],
        )
    except Exception as e:
        log.warn("sentry_replay", "LLM synthesis failed", error=str(e))
        return fallback or ""

    raw_text = (resp.choices[0].message.content or "").strip()
    if not raw_text:
        return fallback or ""

    cleaned = _strip_code_fences(raw_text)
    if "def test_" not in cleaned:
        return fallback or ""
    return cleaned


def _strip_code_fences(text: str) -> str:
    """Remove triple-backtick fences if the LLM wrapped its output anyway."""
    t = text.strip()
    if t.startswith("```"):
        # drop opening fence (with optional language tag)
        first_nl = t.find("\n")
        if first_nl != -1:
            t = t[first_nl + 1:]
        if t.rstrip().endswith("```"):
            t = t.rstrip()[: -3].rstrip()
    return t.strip()
