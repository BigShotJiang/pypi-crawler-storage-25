"""Structured human-review report for non-reproducible crashes.

When the orchestrator can't ship a sealed pytest (race conditions,
state-dependent crashes, framework bootstrap gaps), it still owes the
customer something useful. This module turns the agent's audit trail
and the existing `_build_human_review_evidence` payload into a
ranked, structured investigation report.

Compliance contract:
    Every field here is advisory. The report is attached to the
    artifact under `hypothesis_report` with `in_evidence_path: false`.
    Nothing in this module touches the sealed evidence path.

Phase A — schema + builder (this module + orchestrator wiring).
Phase B — better classification + race-signal extraction (extend
          `classify_crash` and `extract_race_signals`).
Phase C — fix-pattern + repro-approach lookups (`suggest_fix_pattern`
          and `suggest_repro_approach`).
"""

from __future__ import annotations

import re
from dataclasses import asdict, dataclass, field
from typing import Any, Literal

CrashClass = Literal[
    "race_condition_write_write",
    "race_condition_optimistic_lock",
    "race_condition_read_after_write",
    "deadlock",
    "fk_ordering",
    "timing_dependent",
    "external_state_required",
    "framework_bootstrap_required",
    "input_validation",
    "unknown",
]

ReproDifficulty = Literal[
    "deterministic_local",
    "needs_threads",
    "needs_real_db",
    "needs_framework_bootstrap",
    "timing_sensitive_unreproducible",
]


@dataclass
class EvidenceLine:
    source: str   # "breadcrumb" | "audit" | "frame_local" | "code_ast" | "error_message"
    text: str


@dataclass
class Invariant:
    statement: str             # "Payment.order_id should be unique"
    confidence: float          # 0.0-1.0


@dataclass
class Hypothesis:
    rank: int
    confidence: float
    description: str
    evidence_refs: list[str] = field(default_factory=list)
    repro_difficulty: ReproDifficulty = "deterministic_local"


@dataclass
class HypothesisReport:
    crash_class: CrashClass
    confidence: float
    one_line_summary: str
    hypotheses: list[Hypothesis]
    violated_invariants: list[Invariant]
    evidence: list[EvidenceLine]
    suggested_repro_approach: str
    suggested_fix_pattern: str
    related_files: list[str]
    out_of_scope_reason: str
    in_evidence_path: bool = False  # always False — advisory only

    def to_dict(self) -> dict[str, Any]:
        return asdict(self)


# --------------------------------------------------------------------------
# Phase B — classification
# --------------------------------------------------------------------------

_RACE_WORDS = ("race", "lock", "concurrent", "stale", "deadlock")
_INTEGRITY_WORDS = ("integrity", "unique", "duplicate", "already exists")
_FK_WORDS = ("foreign key", "fk", "referenced table", "violates foreign")
_TIMEOUT_WORDS = ("timeout", "timedout", "timed out", "deadline")
_FRAMEWORK_OBJECTS = ("queryset", "model instance", "<order:", "<payment:", "<user:", "<session ")


def classify_crash(
    *,
    error_type: str,
    error_message: str,
    raw_locals: dict[str, Any],
    breadcrumbs: list[dict[str, Any]] | None = None,
    threads: list[Any] | None = None,
) -> tuple[CrashClass, float]:
    """Return (crash_class, confidence) from deterministic signal-matching.

    `threads` accepts either `list[SentryThread]` or `list[dict]`. When
    structured threads carry `held_locks` AND another thread is BLOCKED,
    classify "deadlock" or boost race-class confidence. Pure dispatch
    on observable attributes; never names a framework.
    """
    et = (error_type or "").lower()
    em = (error_message or "").lower()
    bc = breadcrumbs or []
    bc_text = " ".join(_breadcrumb_message(b) for b in bc).lower()

    local_keys = {k.lower() for k in raw_locals.keys()}
    local_values_text = " ".join(str(v).lower() for v in raw_locals.values())

    # --- structured thread signals (highest-precision when present) ----------
    # Two threads BOTH holding locks AND BOTH blocked → deadlock.
    # Held locks anywhere + an integrity/lock-shaped exception → race boost.
    thread_summary = _summarize_threads(threads or [])
    if thread_summary["deadlock_likely"]:
        return ("deadlock", 0.85)

    if "staledata" in et or "optimistic" in em or "version" in em + bc_text:
        conf = 0.78
        if thread_summary["any_held_locks"]:
            conf = min(conf + 0.10, 0.95)
        return ("race_condition_optimistic_lock", conf)

    if any(w in et + em for w in _FK_WORDS):
        return ("fk_ordering", 0.72)

    if any(w in et + em for w in _INTEGRITY_WORDS):
        base = 0.74 if any(
            k in local_keys for k in ("task_id", "celery_task_id", "request_id")
        ) else 0.62
        if thread_summary["any_held_locks"]:
            base = min(base + 0.10, 0.95)
        return ("race_condition_write_write", base)

    if any(w in et for w in _RACE_WORDS) or any(w in em for w in _RACE_WORDS):
        conf = 0.66
        if thread_summary["any_held_locks"]:
            conf = min(conf + 0.10, 0.95)
        return ("race_condition_read_after_write", conf)

    if any(w in et + em for w in _TIMEOUT_WORDS):
        return ("timing_dependent", 0.58)

    if any(token in local_values_text for token in _FRAMEWORK_OBJECTS):
        return ("framework_bootstrap_required", 0.70)

    if et in {"valueerror", "typeerror", "keyerror", "attributeerror"}:
        return ("input_validation", 0.55)

    if "DoesNotExist".lower() in et or "doesnotexist" in et:
        return ("external_state_required", 0.60)

    return ("unknown", 0.30)


def _summarize_threads(threads: list[Any]) -> dict[str, Any]:
    """Reduce a list of SentryThread (or dict shaped equivalents) to flags.

    Output:
      any_held_locks: True if any thread declares heldLocks/held_locks
      deadlock_likely: True if 2+ threads each hold ≥1 lock and at
                       least one is BLOCKED (state-driven heuristic)
      lock_holders: count of threads with at least one held_lock
      blocked_threads: count of threads in BLOCKED state
    """
    lock_holders = 0
    blocked = 0
    any_locks = False
    for t in threads:
        held = _thread_attr(t, "held_locks", "heldLocks") or []
        if isinstance(held, dict):
            held = list(held.keys())
        if held:
            lock_holders += 1
            any_locks = True
        state = str(_thread_attr(t, "state") or "").upper()
        if state == "BLOCKED":
            blocked += 1
    deadlock = lock_holders >= 2 and blocked >= 1
    return {
        "any_held_locks": any_locks,
        "deadlock_likely": deadlock,
        "lock_holders": lock_holders,
        "blocked_threads": blocked,
    }


def _thread_attr(thread: Any, *names: str) -> Any:
    """Read an attribute from either a dataclass or a dict shape."""
    for name in names:
        if isinstance(thread, dict):
            if name in thread:
                return thread[name]
        else:
            if hasattr(thread, name):
                v = getattr(thread, name)
                if v not in (None, "", []):
                    return v
    return None


def _breadcrumb_message(b: Any) -> str:
    """Read .message off a SentryBreadcrumb dataclass OR a raw dict."""
    if isinstance(b, dict):
        return str(b.get("message", "") or "")
    return str(getattr(b, "message", "") or "")


def _breadcrumb_data(b: Any) -> dict[str, Any]:
    if isinstance(b, dict):
        d = b.get("data") or {}
    else:
        d = getattr(b, "data", None) or {}
    return d if isinstance(d, dict) else {}


def _breadcrumb_timestamp(b: Any) -> str:
    if isinstance(b, dict):
        return str(b.get("timestamp", "") or "")
    return str(getattr(b, "timestamp", "") or "")


def _breadcrumb_category(b: Any) -> str:
    if isinstance(b, dict):
        return str(b.get("category", "") or "")
    return str(getattr(b, "category", "") or "")


def _breadcrumb_level(b: Any) -> str:
    if isinstance(b, dict):
        return str(b.get("level", "") or "")
    return str(getattr(b, "level", "") or "")


def extract_race_signals(
    *,
    breadcrumbs: list[Any] | None,
    audit_events: list[dict[str, Any]] | None,
    raw_locals: dict[str, Any],
    threads: list[Any] | None = None,
) -> list[EvidenceLine]:
    """Pull race / concurrency evidence from the audit trail.

    Accepts breadcrumbs and threads as either dataclass instances
    (`SentryBreadcrumb`, `SentryThread`) OR plain dict shapes. The
    accessor helpers (`_breadcrumb_*`, `_thread_attr`) abstract over
    both so callers can pass whichever they have.

    Looks for:
      - state-overwrite / race-window breadcrumbs
      - distinct task ids on the same record (multi-worker)
      - optimistic-lock fields in frame locals (version / expected_version)
      - tight time clusters in breadcrumb timeline (suggests
        concurrent execution)
      - held_locks across threads with at least one BLOCKED thread
      - repeated agent repro attempts in audit (non-deterministic
        outcome)
    """
    lines: list[EvidenceLine] = []
    bc = list(breadcrumbs or [])
    events = audit_events or []
    th = list(threads or [])

    state_overwrites = [
        b for b in bc
        if "state_overwrite" in _breadcrumb_message(b).lower()
        or "overwrite" in _breadcrumb_message(b).lower()
    ]
    if state_overwrites:
        lines.append(EvidenceLine(
            "breadcrumb",
            f"{len(state_overwrites)} state-overwrite breadcrumb(s) — suggests a concurrent writer",
        ))

    race_window_markers = [
        b for b in bc
        if "race_window_open" in _breadcrumb_message(b).lower()
    ]
    if race_window_markers:
        lines.append(EvidenceLine(
            "breadcrumb",
            "explicit race_window_open breadcrumb — sleep was injected, race amplified",
        ))

    task_ids = [
        _breadcrumb_data(b).get("task_id")
        for b in bc
        if _breadcrumb_data(b).get("task_id")
    ]
    distinct_tasks = {t for t in task_ids if t}
    if len(distinct_tasks) >= 2:
        lines.append(EvidenceLine(
            "breadcrumb",
            f"{len(distinct_tasks)} distinct task ids in breadcrumbs — multiple workers touched the same record",
        ))

    if "version" in {k.lower() for k in raw_locals.keys()}:
        lines.append(EvidenceLine(
            "frame_local",
            f"optimistic-lock 'version' field present in frame locals = {raw_locals.get('version')!r}",
        ))

    expected_v = next(
        (raw_locals[k] for k in raw_locals if k.lower() == "expected_version"),
        None,
    )
    if expected_v is not None:
        lines.append(EvidenceLine(
            "frame_local",
            f"expected_version={expected_v!r} — caller pinned a version that lost the CAS",
        ))

    # --- thread signals ------------------------------------------------------
    thread_summary = _summarize_threads(th)
    if thread_summary["deadlock_likely"]:
        lines.append(EvidenceLine(
            "thread",
            (
                f"{thread_summary['lock_holders']} threads hold locks while "
                f"{thread_summary['blocked_threads']} thread(s) are BLOCKED — "
                "deadlock signature"
            ),
        ))
    elif thread_summary["any_held_locks"]:
        held_examples: list[str] = []
        for t in th[:3]:
            held = _thread_attr(t, "held_locks", "heldLocks") or []
            if isinstance(held, dict):
                held = list(held.keys())
            if held:
                held_examples.extend(str(h) for h in held[:2])
        if held_examples:
            lines.append(EvidenceLine(
                "thread",
                f"thread(s) held lock(s): {', '.join(held_examples[:4])}",
            ))
    if thread_summary["blocked_threads"] >= 1 and not thread_summary["deadlock_likely"]:
        lines.append(EvidenceLine(
            "thread",
            f"{thread_summary['blocked_threads']} thread(s) in BLOCKED state at crash time",
        ))

    # --- breadcrumb timeline analysis ---------------------------------------
    timeline = build_breadcrumb_timeline(bc)
    tight_clusters = [
        e for e in timeline
        if e.get("delta_ms") is not None and 0 < e["delta_ms"] < 50
    ]
    if len(tight_clusters) >= 2:
        lines.append(EvidenceLine(
            "breadcrumb",
            (
                f"{len(tight_clusters)} breadcrumb events fired <50ms apart — "
                "suggests concurrent execution or near-simultaneous side effects"
            ),
        ))

    repro_steps = [e for e in events if "repro" in str(e.get("event", "")).lower()]
    if len(repro_steps) >= 2:
        lines.append(EvidenceLine(
            "audit",
            f"agent attempted repro {len(repro_steps)}x — non-deterministic outcome across attempts",
        ))

    return lines


# --------------------------------------------------------------------------
# Breadcrumb timeline analysis — pure-Python primitive (no LLM)
# --------------------------------------------------------------------------

def build_breadcrumb_timeline(
    breadcrumbs: list[Any],
) -> list[dict[str, Any]]:
    """Convert a breadcrumb list into a time-deltas timeline.

    Returns ordered events with millisecond delta-since-previous. Used
    by `extract_race_signals` for tight-cluster detection and by the
    investigation report renderer for human-readable timing.

    Pure function. Empty input → empty output. Bad timestamps are
    treated as None (no delta) — never raises.
    """
    out: list[dict[str, Any]] = []
    prev_epoch: float | None = None
    for b in breadcrumbs:
        ts = _parse_iso_timestamp(_breadcrumb_timestamp(b))
        delta_ms: float | None = None
        if ts is not None and prev_epoch is not None:
            delta_ms = max(0.0, (ts - prev_epoch) * 1000.0)
        out.append({
            "timestamp": _breadcrumb_timestamp(b),
            "category": _breadcrumb_category(b),
            "level": _breadcrumb_level(b),
            "message": _breadcrumb_message(b),
            "delta_ms": delta_ms,
        })
        if ts is not None:
            prev_epoch = ts
    return out


def _parse_iso_timestamp(ts: str) -> float | None:
    """Parse ISO-8601 OR fractional epoch into a float epoch. Best-effort."""
    s = (ts or "").strip()
    if not s:
        return None
    # Sentry sometimes sends fractional epoch as a string
    try:
        return float(s)
    except (ValueError, TypeError):
        pass
    # ISO-8601 with optional trailing Z or offset
    try:
        import datetime as _dt
        normalized = s.replace("Z", "+00:00")
        return _dt.datetime.fromisoformat(normalized).timestamp()
    except (ValueError, TypeError):
        return None


def suggest_invariants(
    *,
    crash_class: CrashClass,
    error_type: str,
    error_message: str,
    raw_locals: dict[str, Any],
) -> list[Invariant]:
    """Best-guess invariants the crash implies were violated."""
    invariants: list[Invariant] = []
    em = (error_message or "").lower()

    if crash_class == "race_condition_write_write":
        match = re.search(r'constraint "([^"]+)"', em)
        if match:
            invariants.append(Invariant(
                f"{match.group(1)} should hold under concurrent writers",
                0.85,
            ))
        else:
            invariants.append(Invariant(
                "DB unique constraint should hold under concurrent writers",
                0.75,
            ))
        invariants.append(Invariant(
            "Each task should produce at most one effect per business key",
            0.65,
        ))

    elif crash_class == "race_condition_optimistic_lock":
        invariants.append(Invariant(
            "Version-pinned UPDATE should be the only writer between read and write",
            0.80,
        ))
        invariants.append(Invariant(
            "Concurrent state machines should serialize via a single transition path",
            0.70,
        ))

    elif crash_class == "deadlock":
        invariants.append(Invariant(
            "Threads should acquire shared locks in a consistent total order",
            0.85,
        ))
        invariants.append(Invariant(
            "Lock-holding code should not block on resources held by other lock-holders",
            0.75,
        ))

    elif crash_class == "fk_ordering":
        invariants.append(Invariant(
            "FK target row should exist before the FK source row is inserted",
            0.85,
        ))

    elif crash_class == "framework_bootstrap_required":
        invariants.append(Invariant(
            "Function should be callable with primitive inputs (current locals contain ORM instances)",
            0.55,
        ))

    elif crash_class == "input_validation":
        invariants.append(Invariant(
            "Function should reject malformed inputs at the boundary, not crash in the body",
            0.70,
        ))

    elif crash_class == "external_state_required":
        invariants.append(Invariant(
            "Function should handle the missing-target case explicitly (lookup failure)",
            0.70,
        ))

    elif crash_class == "timing_dependent":
        invariants.append(Invariant(
            "Function should bound external wait time and degrade gracefully on timeout",
            0.65,
        ))

    return invariants


# --------------------------------------------------------------------------
# Phase C — fix patterns + repro approaches
# --------------------------------------------------------------------------

_FIX_PATTERNS: dict[CrashClass, str] = {
    "race_condition_write_write": (
        "Wrap the read-then-write in SELECT FOR UPDATE on the parent row, "
        "or guard the write with an idempotency key (e.g. a unique partial "
        "index on (order_id, status='pending')). Postgres advisory locks "
        "work for hot-path writes that can't take a row lock."
    ),
    "race_condition_optimistic_lock": (
        "Either retry the version-pinned UPDATE on conflict (Django: "
        "select_for_update + recompute + save) or move the state transition "
        "into a single serialized task queue so two writers never read the "
        "same version."
    ),
    "race_condition_read_after_write": (
        "Move the read inside the same transaction as the write that "
        "produced the value, or use session.refresh() / Order.objects.get() "
        "after the commit to force a re-read from the master."
    ),
    "deadlock": (
        "Establish a global lock-acquisition order shared by every thread "
        "(e.g. sort lock keys lexicographically before acquiring) so cycles "
        "cannot form. If two locks must be held together, acquire them via "
        "a single helper that enforces the order. Use a deadlock-detector "
        "library or DB-level deadlock_timeout + retry to bound the impact."
    ),
    "fk_ordering": (
        "Insert the FK target before the source, OR wrap both inserts in "
        "the same transaction so the FK check is deferred to commit. "
        "If the target is computed asynchronously, use DEFERRABLE INITIALLY "
        "DEFERRED on the FK constraint."
    ),
    "timing_dependent": (
        "Add an explicit timeout to the external call (timeout=N), retry "
        "with exponential backoff on timeout, and surface a structured "
        "error to the caller rather than letting the underlying client "
        "raise. Don't rely on default timeouts; they vary by library."
    ),
    "external_state_required": (
        "Add an explicit existence check + structured 'not found' path "
        "before the operation that assumes the row exists. Don't let "
        "DoesNotExist propagate as a 500."
    ),
    "framework_bootstrap_required": (
        "Refactor the inner logic into a pure function that takes primitives "
        "(ids, dicts) instead of ORM instances. Move the ORM lookup to the "
        "boundary. This also makes the function unit-testable without a DB."
    ),
    "input_validation": (
        "Add an input contract at the function boundary (Pydantic model, "
        "explicit isinstance/assert, or guard clauses). Reject malformed "
        "inputs with a structured error before any side effect runs."
    ),
    "unknown": (
        "Insufficient signal to recommend a fix pattern. The crash needs "
        "more context (DB row state, request body, breadcrumbs) — consider "
        "instrumenting the function with logomesh-capture for the next "
        "occurrence."
    ),
}


_REPRO_APPROACHES: dict[CrashClass, str] = {
    "race_condition_write_write": (
        "Use TransactionTestCase with two threads. One thread calls the "
        "function, the other inserts the conflicting row. Inject a small "
        "time.sleep before the write to widen the race window. Assert the "
        "IntegrityError on the second thread's path."
    ),
    "race_condition_optimistic_lock": (
        "Open two DB sessions. Read the same row in both. Update + commit "
        "in session A. Then attempt the version-pinned UPDATE in session B "
        "and assert StaleDataError. No threading required for this one."
    ),
    "race_condition_read_after_write": (
        "Use threading.Barrier(2) to align two threads at the read point. "
        "Have one thread commit a write before the other reaches the read. "
        "Assert that the second thread sees stale data."
    ),
    "deadlock": (
        "Spawn two threads that each acquire the implicated locks in opposite "
        "orders (A then B vs B then A). Use threading.Barrier(2) so both reach "
        "the second-lock acquisition simultaneously. Assert the process hangs "
        "for ≥ deadlock_timeout, then verify the held_locks signature matches "
        "the production payload."
    ),
    "fk_ordering": (
        "Drop or skip the parent INSERT in a TransactionTestCase. Run the "
        "function. Assert the IntegrityError mentioning the FK constraint "
        "name. Verify the constraint name matches the production error."
    ),
    "timing_dependent": (
        "Mock the external client to raise the timeout exception directly, "
        "or use a fixture that returns after a configurable delay longer "
        "than the timeout. Verify the function's timeout-handling branch."
    ),
    "external_state_required": (
        "Run the function against an empty DB (no fixture for the missing "
        "target). Verify the exception type and message match what Sentry "
        "captured."
    ),
    "framework_bootstrap_required": (
        "Bootstrap a minimal Django/Flask app context: in-memory SQLite, "
        "the touched app's INSTALLED_APPS only, migrate, build the ORM "
        "instance via Model.objects.create() from the captured frame "
        "locals, then call the function."
    ),
    "input_validation": (
        "Call the function directly with the exact frame-locals values "
        "captured by Sentry. Should reproduce in under a second, no "
        "fixture needed."
    ),
    "unknown": (
        "Add structured breadcrumbs or logomesh-capture instrumentation "
        "around the function. On the next occurrence the agent will have "
        "enough signal to ship a sealed test."
    ),
}


def suggest_fix_pattern(crash_class: CrashClass) -> str:
    return _FIX_PATTERNS.get(crash_class, _FIX_PATTERNS["unknown"])


def suggest_repro_approach(crash_class: CrashClass) -> str:
    return _REPRO_APPROACHES.get(crash_class, _REPRO_APPROACHES["unknown"])


def _difficulty_for(crash_class: CrashClass) -> ReproDifficulty:
    if crash_class in {"race_condition_write_write", "race_condition_read_after_write"}:
        return "needs_threads"
    if crash_class == "deadlock":
        return "needs_threads"
    if crash_class == "race_condition_optimistic_lock":
        return "needs_real_db"
    if crash_class == "fk_ordering":
        return "needs_real_db"
    if crash_class == "framework_bootstrap_required":
        return "needs_framework_bootstrap"
    if crash_class == "timing_dependent":
        return "timing_sensitive_unreproducible"
    return "deterministic_local"


# --------------------------------------------------------------------------
# Phase A — main builder
# --------------------------------------------------------------------------

def build_hypothesis_report(
    *,
    evidence: dict[str, Any],
    audit_events: list[dict[str, Any]] | None = None,
    breadcrumbs: list[Any] | None = None,
    threads: list[Any] | None = None,
    related_files: list[str] | None = None,
    out_of_scope_reason: str = "",
) -> HypothesisReport:
    """Promote the existing human-review evidence dict to a structured report.

    `evidence` is the dict returned by `_build_human_review_evidence` in
    the orchestrator. It already has hypotheses (informal) + frame info.
    This function classifies the crash and fills in the structured fields.

    `breadcrumbs` and `threads` accept either structured dataclass
    instances (`SentryBreadcrumb`, `SentryThread`) or plain dicts.
    Accessors at module top handle both shapes.
    """
    error_type = str(evidence.get("error_type", "") or "")
    error_message = str(evidence.get("error_message", "") or "")
    raw_locals = evidence.get("frame_locals") or {}
    informal_hypotheses = evidence.get("hypotheses") or []

    crash_class, confidence = classify_crash(
        error_type=error_type,
        error_message=error_message,
        raw_locals=raw_locals,
        breadcrumbs=breadcrumbs,
        threads=threads,
    )

    race_evidence = extract_race_signals(
        breadcrumbs=breadcrumbs,
        audit_events=audit_events,
        raw_locals=raw_locals,
        threads=threads,
    )

    invariants = suggest_invariants(
        crash_class=crash_class,
        error_type=error_type,
        error_message=error_message,
        raw_locals=raw_locals,
    )

    difficulty = _difficulty_for(crash_class)
    hypotheses: list[Hypothesis] = []
    for h in informal_hypotheses[:3]:
        hypotheses.append(Hypothesis(
            rank=int(h.get("rank", len(hypotheses) + 1)),
            confidence=float(h.get("confidence", 0.0)),
            description=str(h.get("description", "")),
            evidence_refs=[str(h.get("evidence", ""))] if h.get("evidence") else [],
            repro_difficulty=difficulty,
        ))

    one_liner = _one_line_summary(
        crash_class=crash_class,
        error_type=error_type,
        function=str(evidence.get("function", "") or ""),
        race_signals=race_evidence,
    )

    return HypothesisReport(
        crash_class=crash_class,
        confidence=confidence,
        one_line_summary=one_liner,
        hypotheses=hypotheses,
        violated_invariants=invariants,
        evidence=race_evidence,
        suggested_repro_approach=suggest_repro_approach(crash_class),
        suggested_fix_pattern=suggest_fix_pattern(crash_class),
        related_files=related_files or [str(evidence.get("file", "") or "")],
        out_of_scope_reason=out_of_scope_reason,
    )


def _one_line_summary(
    *,
    crash_class: CrashClass,
    error_type: str,
    function: str,
    race_signals: list[EvidenceLine],
) -> str:
    fn = function or "<unknown>"
    if crash_class == "race_condition_write_write":
        return f"Multiple workers raced to write the same record in {fn} — {error_type}"
    if crash_class == "race_condition_optimistic_lock":
        return f"Optimistic-lock CAS in {fn} lost a version race — {error_type}"
    if crash_class == "race_condition_read_after_write":
        return f"Read-after-write race in {fn} returned stale data — {error_type}"
    if crash_class == "deadlock":
        return f"Deadlock detected at {fn} — multiple threads holding locks while blocked"
    if crash_class == "fk_ordering":
        return f"FK constraint failed in {fn}: target row missing at insert time — {error_type}"
    if crash_class == "framework_bootstrap_required":
        return f"Crash in {fn} requires framework bootstrap (ORM instance in frame locals) — {error_type}"
    if crash_class == "timing_dependent":
        return f"Timing-dependent failure in {fn} — {error_type}"
    if crash_class == "external_state_required":
        return f"Crash in {fn} depends on external state we don't have — {error_type}"
    if crash_class == "input_validation":
        return f"Input boundary failure in {fn} — {error_type}"
    return f"Could not classify crash in {fn} — {error_type}"
