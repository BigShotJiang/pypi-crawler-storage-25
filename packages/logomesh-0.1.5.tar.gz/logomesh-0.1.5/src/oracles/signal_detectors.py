"""Classify Sentry exception signals into bug classes and generate reproduction harnesses.

Each detector reads `exc.error_type`, `exc.error_message`, and frame locals to identify
a specific hard-to-reproduce bug class, then emits Python source code that converts the
normally-non-deterministic crash into a deterministic pytest assertion.

Bug classes covered:
  1. MemoryError / OOM        — setrlimit(RLIMIT_AS) from cgroup + tracemalloc diff
  2. FD exhaustion            — setrlimit(RLIMIT_NOFILE, 64) + loop
  3. Hash randomization       — KeyError on dict/set → PYTHONHASHSEED sweep metadata
  4. GC / reference cycle     — gc.collect() + weakref cycle proof
  5. TOCTOU / check-then-act  — threading.Barrier two-thread pattern
  6. asyncio race             — asyncio.sleep(0) yield injection + concurrent tasks
  7. Unicode / encoding       — bytes extraction from frame locals

All functions are pure (no LLM, no I/O). They return source strings or metadata dicts.
"""
from __future__ import annotations

import re
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from oracles.sentry_replay import SentryException, SentryFrame


# ---------------------------------------------------------------------------
# 1. MemoryError / OOM — setrlimit(RLIMIT_AS) + tracemalloc
# ---------------------------------------------------------------------------

def memory_error_fixture(frame: "SentryFrame", exc: "SentryException") -> str:
    """Return OOM reproduction harness for MemoryError crashes.

    Reads the cgroup memory limit and applies setrlimit(RLIMIT_AS) so the
    sandbox process raises MemoryError instead of being killed by SIGKILL.
    Also injects a tracemalloc diff assertion for memory-leak detection.

    Works under Docker `nobody` user — lowering soft limits requires no
    elevated privileges (only raising above the hard limit needs root).
    """
    error_type = getattr(exc, "error_type", "") or ""
    error_msg = getattr(exc, "error_message", "") or ""

    is_oom = (
        error_type == "MemoryError"
        or "memory" in error_type.lower()
        or "MemoryError" in error_msg
    )
    if not is_oom:
        return ""

    # Find the largest collection-typed local — the likely allocation site.
    vars_ = frame.variables or {}
    collection_hint = ""
    for k, v in vars_.items():
        if isinstance(v, (list, dict, bytes, bytearray)):
            collection_hint = f"# Suspected allocation site: {k!r} = {repr(v)[:100]}"
            break

    return f"""\
# OOM / MEMORY REPRODUCTION HARNESS
# Converts SIGKILL OOM into catchable MemoryError via setrlimit(RLIMIT_AS).
# Works under Docker nobody user — lowering soft limit needs no root.
import resource as _resource
import tracemalloc as _tracemalloc
import gc as _gc

def _apply_sandbox_memory_limit():
    \"\"\"Read cgroup memory limit and apply it as RLIMIT_AS.\"\"\"
    for path in (
        "/sys/fs/cgroup/memory/memory.limit_in_bytes",  # cgroup v1
        "/sys/fs/cgroup/memory.max",                     # cgroup v2
    ):
        try:
            val = open(path).read().strip()
            if val not in ("max", ""):
                limit = int(val)
                _resource.setrlimit(_resource.RLIMIT_AS, (limit, limit))
                return limit
        except (FileNotFoundError, ValueError, _resource.error):
            pass
    return None

_SANDBOX_MEM_LIMIT = _apply_sandbox_memory_limit()
{collection_hint}

def _assert_no_memory_leak(func, args, kwargs, n=50, leak_threshold_kib=512):
    \"\"\"Call func N times and assert heap growth stays below threshold.\"\"\"
    _tracemalloc.start(10)
    _gc.collect()
    snap_before = _tracemalloc.take_snapshot()
    for _ in range(n):
        func(*args, **kwargs)
    _gc.collect()
    snap_after = _tracemalloc.take_snapshot()
    _tracemalloc.stop()
    diff = snap_after.compare_to(snap_before, "lineno")
    leaked = sum(s.size_diff for s in diff if s.size_diff > 0) // 1024
    assert leaked < leak_threshold_kib, (
        f"Memory grew by {{leaked}} KiB over {{n}} iterations — likely leak at:\\n"
        + "\\n".join(str(s) for s in diff[:5])
    )

"""


# ---------------------------------------------------------------------------
# 2. FD exhaustion — OSError EMFILE / ENFILE
# ---------------------------------------------------------------------------

_FD_ERROR_RE = re.compile(
    r"(errno 24|too many open files|errno 23|no more file descriptors|"
    r"ResourceWarning.*unclosed|OSError.*\[Errno 2[34]\])",
    re.IGNORECASE,
)


def fd_exhaustion_fixture(frame: "SentryFrame", exc: "SentryException") -> str:
    """Return FD exhaustion reproduction harness.

    Lowers RLIMIT_NOFILE to 64 (enough to run Python + the test) then
    calls the crashing function in a loop. If it leaks FDs, it will hit
    the limit within 40-50 iterations and raise OSError deterministically.
    """
    error_type = getattr(exc, "error_type", "") or ""
    error_msg = getattr(exc, "error_message", "") or ""
    combined = error_type + " " + error_msg

    if not _FD_ERROR_RE.search(combined):
        return ""

    func_name = frame.function or "target_function"

    return f"""\
# FD EXHAUSTION REPRODUCTION HARNESS
# Lowers RLIMIT_NOFILE to 64 so FD leaks trigger OSError within ~50 iterations.
# Deterministic under Docker nobody user.
import resource as _resource
import gc as _gc

def _lower_fd_limit(soft=64):
    try:
        _, hard = _resource.getrlimit(_resource.RLIMIT_NOFILE)
        _resource.setrlimit(_resource.RLIMIT_NOFILE, (soft, hard))
    except _resource.error:
        pass  # already at or below soft limit

_lower_fd_limit(64)

def _assert_no_fd_leak(func, args, kwargs, n=80):
    \"\"\"Call func N times. If it leaks FDs, OSError: [Errno 24] will be raised.\"\"\"
    _gc.collect()
    for i in range(n):
        try:
            func(*args, **kwargs)
        except OSError as e:
            if e.errno in (24, 23):  # EMFILE / ENFILE
                raise AssertionError(
                    f"FD leak confirmed: OSError [Errno {{e.errno}}] after {{i+1}} iterations"
                ) from e
            raise

# Usage in test:
# _assert_no_fd_leak({func_name}, args=(...), kwargs={{...}})
# Or: call {func_name}() in a loop and assert the OSError arrives.

"""


# ---------------------------------------------------------------------------
# 3. Hash randomization — KeyError on dict/set → PYTHONHASHSEED metadata
# ---------------------------------------------------------------------------

_DICT_SET_TYPES = (dict, list, set, frozenset)
_KEY_ERROR_RE = re.compile(r"^KeyError$|^KeyError:", re.IGNORECASE)


def hashseed_metadata(frame: "SentryFrame", exc: "SentryException") -> dict:
    """Return metadata for PYTHONHASHSEED sweep when dict/set ordering may be the cause.

    Returns {"try_hashseeds": [0, 1, 2, ...], "reason": str} or {} if not applicable.

    Caller (repro.py) uses this to re-run the sandbox with different seeds until
    one reproduces the crash. The crashing seed becomes part of the repro evidence.
    """
    error_type = getattr(exc, "error_type", "") or ""
    if not _KEY_ERROR_RE.search(error_type):
        return {}

    vars_ = frame.variables or {}
    has_dict_local = any(
        isinstance(v, (dict, list)) or str(v).startswith("{") or str(v).startswith("[")
        for v in vars_.values()
    )
    if not has_dict_local:
        return {}

    return {
        "try_hashseeds": list(range(20)),
        "reason": (
            f"KeyError in {frame.function or '?'} with dict/set-shaped locals — "
            "may be hash-order dependent"
        ),
    }


def hashseed_preamble(seed: int) -> str:
    """Return a preamble comment for a test running under a specific PYTHONHASHSEED."""
    return f"# PYTHONHASHSEED={seed} — set in sandbox env to reproduce hash-order crash\n"


# ---------------------------------------------------------------------------
# 4. GC / reference cycle — gc.collect() + weakref proof
# ---------------------------------------------------------------------------

_GC_SIGNAL_RE = re.compile(
    r"(ResourceWarning|__del__|gc\.garbage|finaliz|reference cycle|weakref|"
    r"BufferedWriter|TextIOWrapper.*finali)",
    re.IGNORECASE,
)


def gc_cycle_fixture(frame: "SentryFrame", exc: "SentryException") -> str:
    """Return gc + weakref cycle detection fixture.

    Triggered by ResourceWarning in exc type/message, or GC-related locals.
    The fixture proves a reference cycle is keeping an object alive after `del`.
    """
    error_type = getattr(exc, "error_type", "") or ""
    error_msg = getattr(exc, "error_message", "") or ""
    combined = error_type + " " + error_msg
    vars_str = " ".join(str(k) + str(v) for k, v in (frame.variables or {}).items())

    if not _GC_SIGNAL_RE.search(combined) and not _GC_SIGNAL_RE.search(vars_str):
        return ""

    func_name = frame.function or "target_function"

    return f"""\
# GC / REFERENCE CYCLE DETECTION HARNESS
# Proves a reference cycle prevents garbage collection of the object under test.
import gc as _gc
import weakref as _weakref

def _assert_no_reference_cycle(obj_factory, *factory_args, **factory_kwargs):
    \"\"\"Create the object, delete it, and assert it's collected by gc.\"\"\"
    _gc.set_debug(_gc.DEBUG_SAVEALL)
    _gc.collect()
    _gc.garbage.clear()

    obj = obj_factory(*factory_args, **factory_kwargs)
    ref = _weakref.ref(obj)
    del obj
    _gc.collect()

    is_leaked = ref() is not None
    _gc.set_debug(0)
    _gc.garbage.clear()

    assert not is_leaked, (
        f"{{obj_factory.__name__ if hasattr(obj_factory, '__name__') else repr(obj_factory)}} "
        "not collected after del — reference cycle detected"
    )

# Also force GC before calling the crashing function to expose finalizer-order bugs:
_gc.set_threshold(1, 1, 1)  # aggressive collection
_gc.collect()

# Example: _assert_no_reference_cycle({func_name}, *args_from_locals)

"""


# ---------------------------------------------------------------------------
# 5. TOCTOU / check-then-act race — threading.Barrier two-thread test
# ---------------------------------------------------------------------------

_TOCTOU_AST_PATTERNS = [
    # Django ORM: .exists() / .filter().count() followed by .create() or .update()
    re.compile(r"\.exists\(\)|\.filter\(.*\)\.count\(\)|get_or_create\(", re.IGNORECASE),
    # Generic check-then-write
    re.compile(r"if.*not.*in.*:\s*\n.*=|if.*is None.*:\s*\n.*=", re.IGNORECASE),
    # select_for_update missing
    re.compile(r"\.objects\.(get|filter|first)\((?!.*select_for_update)", re.IGNORECASE),
]


def toctou_barrier_fixture(frame: "SentryFrame", source: str) -> str:
    """Return threading.Barrier two-thread test for TOCTOU/check-then-act races.

    Django ORM lost-update (filter().exists() → create()), double-payment,
    and cache-stampede patterns all fit this shape. The Barrier ensures both
    threads enter the check window simultaneously, making the race deterministic.

    Detection: TOCTOU AST patterns in source (filter/exists/create, get_or_create,
    select_for_update absent).
    """
    src = source or ""
    if not any(p.search(src) for p in _TOCTOU_AST_PATTERNS):
        return ""

    func_name = frame.function or "target_function"

    return f"""\
# TOCTOU / CHECK-THEN-ACT RACE HARNESS
# threading.Barrier ensures both threads enter the race window simultaneously.
# Covers: Django ORM lost-update, double-payment, cache-stampede.
# Research: Django uses threading.Event in their own race fix tests (ticket #29499).
import threading as _threading
import sys as _sys

# Force maximum thread interleaving (minimize GIL hold time per thread)
_sys.setswitchinterval(1e-9)

_RACE_BARRIER = _threading.Barrier(2)
_RACE_RESULTS = []
_RACE_ERRORS = []

def _race_worker(func, args, kwargs):
    \"\"\"Worker: waits at barrier then calls func, records result or error.\"\"\"
    try:
        _RACE_BARRIER.wait(timeout=5.0)
        result = func(*args, **kwargs)
        _RACE_RESULTS.append(result)
    except Exception as e:
        _RACE_ERRORS.append(e)

def _run_toctou_test(func, args=(), kwargs=None, n_threads=2, expect_unique=True):
    \"\"\"Launch n_threads workers that all call func simultaneously.
    If expect_unique, assert only one succeeded (i.e., the race window was closed).
    \"\"\"
    kwargs = kwargs or {{}}
    global _RACE_RESULTS, _RACE_ERRORS
    _RACE_RESULTS, _RACE_ERRORS = [], []

    threads = [
        _threading.Thread(target=_race_worker, args=(func, args, kwargs))
        for _ in range(n_threads)
    ]
    for t in threads:
        t.start()
    for t in threads:
        t.join(timeout=10.0)

    if expect_unique:
        assert len(_RACE_RESULTS) <= 1, (
            f"TOCTOU race confirmed: {{len(_RACE_RESULTS)}} threads "
            f"completed {func_name} simultaneously (expected at most 1). "
            "Missing select_for_update or atomic write."
        )

# Usage: _run_toctou_test({func_name}, args=(...), expect_unique=True)
# If this assertion fails, the race is confirmed — report as evidence.

"""


# ---------------------------------------------------------------------------
# 6. asyncio race — concurrent task injection
# ---------------------------------------------------------------------------

_ASYNC_DEF_RE = re.compile(r"async\s+def\s+|await\s+|asyncio\.", re.IGNORECASE)
_ASYNC_TOCTOU_RE = re.compile(
    r"await.*cache|if.*not.*await|async.*get_or_create|create_task",
    re.IGNORECASE,
)


def asyncio_race_fixture(frame: "SentryFrame", source: str) -> str:
    """Return asyncio concurrent task harness for async TOCTOU and cancel races.

    Detection: async def / await in source. The harness launches N concurrent
    coroutine invocations and injects asyncio.sleep(0) yield points to widen
    the scheduling window at natural await boundaries.
    """
    src = source or ""
    if not _ASYNC_DEF_RE.search(src):
        return ""

    func_name = frame.function or "target_function"
    is_toctou = bool(_ASYNC_TOCTOU_RE.search(src))

    toctou_note = (
        "# TOCTOU pattern detected: cache miss / get_or_create / create_task gap\n"
        "# asyncio.sleep(0) at the await point lets another coroutine slip through.\n"
        if is_toctou else ""
    )

    return f"""\
# ASYNCIO RACE HARNESS
# Runs N concurrent coroutines and uses asyncio.sleep(0) to widen scheduling windows.
# Covers: async TOCTOU (cache miss race), cancelled task state corruption,
#         connection pool exhaustion under concurrent cancellation.
import asyncio as _asyncio
{toctou_note}
async def _run_concurrent(coro_factory, n=10, args=(), kwargs=None):
    \"\"\"Launch n concurrent invocations of the coroutine and collect results/errors.\"\"\"
    kwargs = kwargs or {{}}
    results = []
    errors = []

    async def _worker():
        await _asyncio.sleep(0)  # yield to let other coroutines start
        try:
            results.append(await coro_factory(*args, **kwargs))
        except Exception as e:
            errors.append(e)

    await _asyncio.gather(*[_worker() for _ in range(n)], return_exceptions=True)
    return results, errors

# Usage in test:
# async def test_async_race():
#     results, errors = await _run_concurrent({func_name}, n=10)
#     # assert invariant on results — duplicates or errors indicate the race
#
# Run with: import asyncio; asyncio.run(test_async_race())

"""


# ---------------------------------------------------------------------------
# 7. Unicode / encoding bugs — bytes extraction from frame locals
# ---------------------------------------------------------------------------

_UNICODE_ERROR_RE = re.compile(
    r"UnicodeDecodeError|UnicodeEncodeError|UnicodeError|codec can't|"
    r"invalid.*byte|unexpected byte",
    re.IGNORECASE,
)
_BYTES_REPR_RE = re.compile(r"^b['\"]")


def unicode_fixture(frame: "SentryFrame", exc: "SentryException") -> str:
    """Return encoding reproduction fixture from frame locals.

    When UnicodeDecodeError is the exception, Sentry locals often contain
    the offending bytes or filename. Extract and hard-code them as the test input.
    """
    error_type = getattr(exc, "error_type", "") or ""
    error_msg = getattr(exc, "error_message", "") or ""
    combined = error_type + " " + error_msg

    if not _UNICODE_ERROR_RE.search(combined):
        return ""

    vars_ = frame.variables or {}
    bytes_locals: list[tuple[str, str]] = []
    encoding_hint = ""

    # Extract the encoding from the error message: "codec 'utf-8' can't decode..."
    enc_match = re.search(r"'([a-z0-9_-]+)'\s+codec", error_msg, re.IGNORECASE)
    if enc_match:
        encoding_hint = enc_match.group(1)

    for k, v in vars_.items():
        v_str = str(v)
        if isinstance(v, (bytes, bytearray)):
            bytes_locals.append((k, repr(v)[:300]))
        elif _BYTES_REPR_RE.match(v_str):
            bytes_locals.append((k, v_str[:300]))

    # For UnicodeEncodeError without bytes locals, still emit the error type as a hint.
    is_encode_error = "UnicodeEncodeError" in error_type
    if not bytes_locals and not encoding_hint and not is_encode_error:
        return ""

    lines = [
        "# UNICODE / ENCODING REPRODUCTION HARNESS",
        f"# Exception: {error_type}: {error_msg[:120]}",
    ]
    if encoding_hint:
        lines.append(f'_CRASH_ENCODING = "{encoding_hint}"')
    elif is_encode_error:
        lines.append('_CRASH_ENCODING = "utf-8"  # default; override with the codec from the error')
    for name, val_repr in bytes_locals[:3]:
        lines.append(f"_CRASH_BYTES_{name.upper()} = {val_repr}  # from Sentry frame locals")
    lines += [
        "# Feed these bytes into the crashing function to reproduce the encoding error.",
        "# Try: data.decode(_CRASH_ENCODING, errors='strict') to confirm the exact byte.",
        "",
    ]
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# Composite: classify and build all signal-driven harness code
# ---------------------------------------------------------------------------

def build_signal_harnesses(
    frame: "SentryFrame",
    exc: "SentryException",
    source: str,
) -> tuple[str, dict]:
    """Run all signal detectors and return (harness_code, metadata).

    `harness_code` is prepended to mock_setup_code.
    `metadata` may contain {"try_hashseeds": [...]} for the caller to act on.
    """
    parts = [
        memory_error_fixture(frame, exc),
        fd_exhaustion_fixture(frame, exc),
        gc_cycle_fixture(frame, exc),
        toctou_barrier_fixture(frame, source),
        asyncio_race_fixture(frame, source),
        unicode_fixture(frame, exc),
    ]
    code = "".join(p for p in parts if p)
    meta = hashseed_metadata(frame, exc)
    return code, meta
