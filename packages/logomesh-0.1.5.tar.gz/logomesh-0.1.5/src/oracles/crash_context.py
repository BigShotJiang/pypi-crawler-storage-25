"""Detect limitation-class patterns in Sentry frame locals / event metadata.

Generates supplementary mock/fixture code injected into the synthesized pytest
for five previously-unrepro bug classes:

  1. External API  — `responses`/`respx` mocks from locals; known Stripe/Twilio shapes
  2. Timezone      — `time-machine` (not freezegun — handles C extensions + DST correctly)
  3. DB state      — `sqlalchemy_mock_config` fixture hints from frame ID locals
  4. Dist. txn     — SQLAlchemy savepoint listener template for partial-commit sim
  5. Race condition — `slow_wrapper` delay injection + `frontrun` template

Key research findings embedded in design decisions:
- `time-machine` over `freezegun`: interprets naive datetimes as UTC (stable);
  `freezegun` uses local time (environment-dependent, DST-incorrect).
- Sentry `event["timestamp"]` is always UTC (sentry-python SDK converts before send).
- `responses` for `requests`-based clients; `respx` for `httpx`-based clients.
- SQLAlchemy `MetaData.sorted_tables` gives FK-ordered insertion for free.
- PCT (Probabilistic Concurrency Testing): `frontrun.explore_interleavings()` plus
  `slow_wrapper` covers the 80% case with zero new sandbox deps for the latter.

All functions are pure (no LLM, no I/O) except `db_fixture_hints` which does a
bounded repo walk. They return Python source strings for inclusion in mock_setup_code.
"""
from __future__ import annotations

import re
from pathlib import Path
from typing import TYPE_CHECKING

if TYPE_CHECKING:
    from oracles.sentry_replay import SentryException, SentryFrame


# ---------------------------------------------------------------------------
# 1. External API: HTTP response mock synthesis from frame locals
# ---------------------------------------------------------------------------

_RESPONSE_KEY_RE = re.compile(
    r"(response|resp|result|payload|api_response|http_response|"
    r"webhook|json_data|reply|res)\b",
    re.IGNORECASE,
)
_STATUS_KEYS = {"status_code", "status", "code", "http_status"}
_BODY_KEYS = {"body", "text", "content", "json", "data", "response_body", "message"}
_URL_KEY_RE = re.compile(r"(url|endpoint|base_url|host|uri)\b", re.IGNORECASE)
_HTTPX_CLIENT_RE = re.compile(r"httpx|AsyncClient|httpx\.Client", re.IGNORECASE)


def http_mock_from_locals(frame: "SentryFrame", source: str = "") -> str:
    """Return `responses` (or `respx` for httpx) mock setup from frame locals.

    Checks known API error shapes (Stripe/Twilio/Shopify) first — no LLM needed.
    Falls back to generic HTTP-response-shaped dict detection.
    Returns "" when nothing found.
    """
    from oracles.api_error_fixtures import match_from_locals, url_from_locals

    vars_ = frame.variables or {}
    if not vars_:
        return ""

    # Prefer httpx/respx when the source uses httpx.
    use_respx = bool(_HTTPX_CLIENT_RE.search(source or ""))
    lib = "respx" if use_respx else "responses"

    # Known provider shape first — zero LLM, deterministic.
    known = match_from_locals(vars_)
    if known:
        url_hint, status_code, body = known
        url_from_frame = url_from_locals(vars_) or url_hint
        if use_respx:
            return (
                "import respx as _respx\nimport httpx as _httpx\n\n"
                f"# Known API error shape detected from frame locals\n"
                f"_MOCK_URL = {url_from_frame!r}\n"
                f"_MOCK_BODY = {body!r}\n"
                f"_MOCK_STATUS = {status_code}\n"
                "# Decorate test with @_respx.mock and inside:\n"
                f"# _respx.post(_MOCK_URL).mock(return_value=_httpx.Response(_MOCK_STATUS, json=_MOCK_BODY))\n"
            )
        return (
            "import responses as _responses\n\n"
            f"# Known API error shape detected from frame locals\n"
            f"_MOCK_URL = {url_from_frame!r}\n"
            f"_MOCK_BODY = {body!r}\n"
            f"_MOCK_STATUS = {status_code}\n"
            "# Activate with @_responses.activate, then:\n"
            f"# _responses.add(_responses.ANY, _MOCK_URL, json=_MOCK_BODY, status=_MOCK_STATUS)\n"
        )

    # Generic detection: scan for HTTP-response-shaped locals.
    url_hint = _infer_url(vars_)
    mocks: list[dict] = []
    for key, val in vars_.items():
        if not _RESPONSE_KEY_RE.search(key):
            continue
        entry = _parse_response_local(val)
        if entry is None:
            continue
        entry["url"] = url_hint or f"https://example.com/api/{key}"
        mocks.append(entry)
        if len(mocks) >= 3:
            break

    if not mocks:
        return ""

    if use_respx:
        lines = [
            "import respx as _respx",
            "import httpx as _httpx",
            "",
            "# HTTP response shape from Sentry frame locals (use @_respx.mock):",
        ]
        for m in mocks:
            body_repr = repr(m["body"])[:400]
            lines.append(
                f"# _respx.post({m['url']!r}).mock("
                f"return_value=_httpx.Response({m['status_code']}, json={body_repr}))"
            )
    else:
        lines = [
            "import responses as _responses",
            "",
            "# HTTP response shape from Sentry frame locals (use @_responses.activate):",
        ]
        for m in mocks:
            body_repr = repr(m["body"])[:400]
            lines.append(
                f"# _responses.add(_responses.ANY, {m['url']!r}, "
                f"json={body_repr}, status={m['status_code']})"
            )

    lines.append("")
    return "\n".join(lines)


def _parse_response_local(val: object) -> dict | None:
    if isinstance(val, dict):
        status = 200
        for sk in _STATUS_KEYS:
            if sk in val:
                try:
                    status = int(val[sk])
                    break
                except (TypeError, ValueError):
                    pass
        body: object = {}
        for bk in _BODY_KEYS:
            if bk in val:
                body = val[bk]
                break
        if not body:
            body = {k: v for k, v in val.items() if k not in _STATUS_KEYS}
        return {"status_code": status, "body": body}

    if isinstance(val, str) and (val.lstrip().startswith("{") or val.lstrip().startswith("[")):
        return {"status_code": 200, "body": val[:1000]}

    return None


def _infer_url(vars_: dict) -> str:
    for k, v in vars_.items():
        if _URL_KEY_RE.search(k) and isinstance(v, str) and v.startswith("http"):
            return v[:300]
    return ""


# ---------------------------------------------------------------------------
# 2. Timezone: time-machine setup from event timestamp + TZ tag
# ---------------------------------------------------------------------------
# Research finding: use `time-machine` not `freezegun`.
# - time-machine: naive datetimes = UTC (stable across environments)
# - freezegun: naive datetimes = local time (environment-dependent, DST-broken)
# - Sentry SDK always converts event["timestamp"] to UTC before sending.

_ISO8601_RE = re.compile(r"(\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2})")

# Known DST transition UTC moments (US + EU, 2024–2026).
_DST_TRANSITIONS_UTC = [
    "2024-03-10T07:00:00",  # US spring-forward 2024
    "2024-11-03T06:00:00",  # US fall-back 2024
    "2025-03-09T07:00:00",  # US spring-forward 2025
    "2025-11-02T06:00:00",  # US fall-back 2025
    "2026-03-08T07:00:00",  # US spring-forward 2026
    "2024-03-31T01:00:00",  # EU spring-forward 2024
    "2024-10-27T01:00:00",  # EU fall-back 2024
    "2025-03-30T01:00:00",  # EU spring-forward 2025
    "2025-10-26T01:00:00",  # EU fall-back 2025
]
_DST_WINDOW_SECONDS = 3600  # ±1h around transition counts as "in window"


def freeze_time_from_event(exc: "SentryException") -> str:
    """Return time-machine setup code pinned to the Sentry event UTC timestamp.

    Returns "" when last_seen is not parseable ISO-8601.
    The returned block should be prepended to mock_setup_code so the LLM
    sees `_CRASH_TIMESTAMP` and knows to use `@_time_machine.travel(...)`.
    """
    ts = getattr(exc, "last_seen", "") or ""
    m = _ISO8601_RE.match(ts)
    if not m:
        return ""

    clean_ts = m.group(1)
    tz = getattr(exc, "timezone", "") or ""
    near_dst = _is_near_dst_transition(clean_ts)

    lines = [
        "import time_machine as _time_machine",
        "import datetime as _dt",
        f'_CRASH_TIMESTAMP = "{clean_ts}Z"  # UTC — Sentry always stores in UTC',
    ]
    if tz:
        lines.append(f'_CRASH_TZ = "{tz}"  # user timezone from Sentry tags')
        lines.append(
            "# Inject into Docker sandbox: TZ=<_CRASH_TZ> in docker run env"
        )
    if near_dst:
        lines.append("# WARNING: timestamp is near a DST transition — tick=True may be needed")
    lines += [
        "# Decorate test with @_time_machine.travel(_CRASH_TIMESTAMP) to pin time.time()",
        "# and datetime.now() including C extensions (unlike freezegun).",
        "",
    ]
    return "\n".join(lines)


def tz_for_sandbox(exc: "SentryException") -> str:
    """Return the IANA timezone string to inject as TZ env var into the sandbox.

    Returns "" when no timezone is available. The caller passes this to
    `Sandbox.run(extra_env={"TZ": tz})` so time.localtime() in the container
    uses the crash timezone — complements `time-machine` freeze.
    """
    return getattr(exc, "timezone", "") or ""


def inject_freeze_time_decorator(test_code: str, exc: "SentryException") -> str:
    """Post-process deterministic test code to prepend @time_machine.travel decorator.

    Uses time-machine instead of freezegun: stable UTC semantics, handles C extensions.
    Returns test_code unchanged when timestamp is unavailable or already decorated.
    """
    ts = getattr(exc, "last_seen", "") or ""
    m = _ISO8601_RE.match(ts)
    if not m:
        return test_code
    if "time_machine" in test_code or "freeze_time" in test_code:
        return test_code

    clean_ts = m.group(1)
    import_line = "import time_machine as _time_machine\n"
    decorator = f'@_time_machine.travel("{clean_ts}Z", tick=False)\n'

    lines = test_code.splitlines(keepends=True)
    out: list[str] = []
    import_injected = False
    for line in lines:
        if not import_injected and line.startswith("from target"):
            out.append(import_line)
            import_injected = True
        if line.lstrip().startswith("def test_"):
            out.append(decorator)
        out.append(line)
    return "".join(out)


def _is_near_dst_transition(ts_str: str) -> bool:
    """Return True if ts_str (ISO-8601, UTC) is within ±1h of a known DST transition."""
    try:
        import datetime
        ts = datetime.datetime.fromisoformat(ts_str)
        for dst_str in _DST_TRANSITIONS_UTC:
            dst = datetime.datetime.fromisoformat(dst_str)
            if abs((ts - dst).total_seconds()) <= _DST_WINDOW_SECONDS:
                return True
    except Exception:
        pass
    return False


# ---------------------------------------------------------------------------
# 3. DB state: sqlalchemy_mock_config fixture from frame ID locals
# ---------------------------------------------------------------------------

_ID_KEY_RE = re.compile(r"^(.+)_id$", re.IGNORECASE)
_MODEL_FILE_RE = re.compile(r"(model|schema|orm|entity|db)", re.IGNORECASE)


def db_fixture_hints(frame: "SentryFrame", repo_root: str | Path | None = None) -> str:
    """Emit pytest fixture code for DB state seeding from frame locals.

    Extracts `foo_id=42` style locals, resolves entity names, and emits a
    `sqlalchemy_mock_config`-compatible fixture block (pytest-sqlalchemy-mock
    library) plus INSERT comment hints for the LLM.

    Returns "" when no ID-shaped locals are found.
    """
    vars_ = frame.variables or {}
    id_locals: dict[str, object] = {}
    for k, v in vars_.items():
        m = _ID_KEY_RE.match(k)
        if m and isinstance(v, (int, str)) and str(v).isdigit():
            id_locals[m.group(1).lower()] = v

    if not id_locals:
        return ""

    model_paths = _find_model_files(repo_root) if repo_root else []

    # Build sqlalchemy_mock_config fixture block.
    config_rows: list[str] = []
    insert_comments: list[str] = []
    for entity, pk in id_locals.items():
        table = f"{entity}s"  # naive pluralization — LLM can correct
        candidates = [p for p in model_paths if entity in p.lower()]
        path_note = f"  # {candidates[0]}" if candidates else ""
        config_rows.append(f'        ("{table}", [{{"id": {pk}}}]),{path_note}')
        insert_comments.append(
            f"# INSERT INTO {table} (id, ...) VALUES ({pk}, ...)  -- add required FK fields"
        )

    rows_block = "\n".join(config_rows)
    comments = "\n".join(insert_comments)

    return f"""\
# DB FIXTURE HINTS — seed required rows before calling the crashing function.
# Uses pytest-sqlalchemy-mock (SQLite in-memory, no extra containers):
{comments}

import pytest as _pytest

@_pytest.fixture
def sqlalchemy_mock_config():
    \"\"\"Minimal rows inferred from Sentry frame locals. Add FK parent rows as needed.\"\"\"
    return [
{rows_block}
    ]

"""


def _find_model_files(repo_root: str | Path) -> list[str]:
    root = Path(repo_root)
    results: list[str] = []
    _noise = {"node_modules", ".git", "site-packages", "__pycache__", ".venv", "venv"}
    try:
        for p in root.rglob("*.py"):
            if any(part in _noise for part in p.parts):
                continue
            if _MODEL_FILE_RE.search(p.stem):
                results.append(str(p.relative_to(root)))
            if len(results) >= 20:
                break
    except Exception:
        pass
    return results


# ---------------------------------------------------------------------------
# 4. Distributed txn: SQLAlchemy savepoint listener template
# ---------------------------------------------------------------------------

_SQLA_IMPORT_RE = re.compile(r"sqlalchemy|db\.session|session\.commit|\.add\(", re.IGNORECASE)
_SESSION_LOCAL_KEYS = {"session", "db_session", "db", "sess", "s", "conn"}


def sqlalchemy_savepoint_code(frame: "SentryFrame", source: str) -> str:
    """Return savepoint listener fixture when SQLAlchemy usage is detected.

    LOGOMESH_COMMIT_LIMIT env var controls which commit ordinal triggers rollback.
    Returns "" when SQLAlchemy not detected.
    """
    vars_ = frame.variables or {}
    src = source or ""

    has_session_local = any(k.lower() in _SESSION_LOCAL_KEYS for k in vars_)
    has_sqla_in_source = bool(_SQLA_IMPORT_RE.search(src))

    if not has_session_local and not has_sqla_in_source:
        return ""

    return """\
# DISTRIBUTED TXN SIMULATION — SQLAlchemy partial-commit fault injection
# Set LOGOMESH_COMMIT_LIMIT=N to force rollback on the Nth commit.
import os as _os

_COMMIT_LIMIT = int(_os.getenv("LOGOMESH_COMMIT_LIMIT", "1"))
_commit_counter = [0]

def _savepoint_listener(session, transaction):
    _commit_counter[0] += 1
    if _commit_counter[0] >= _COMMIT_LIMIT:
        try:
            session.rollback()
        except Exception:
            pass

# Wire up before calling target:
#   from sqlalchemy import event
#   event.listen(session, "after_transaction_end", _savepoint_listener)

"""


# ---------------------------------------------------------------------------
# 5. Race condition: slow_wrapper delay injection + frontrun template
# ---------------------------------------------------------------------------
# Research finding: slow_wrapper (zero deps) handles 80% of threading races.
# `frontrun` (PyPI) handles asyncio races via AsyncTraceExecutor and does
# PCT-style schedule exploration with explore_interleavings().

_THREADING_RE = re.compile(
    r"import threading|threading\.|Thread\(|import asyncio|asyncio\.|async def|create_task|gather\(",
    re.IGNORECASE,
)
_LOCK_RE = re.compile(r"lock|mutex|semaphore|Event\(\)|Condition\(", re.IGNORECASE)


def race_wrapper_from_locals(frame: "SentryFrame", source: str) -> str:
    """Return slow_wrapper + frontrun template when concurrent code is detected.

    Detection: threading/asyncio imports in source, or lock-related locals.
    Returns "" when concurrency not detected.
    """
    src = source or ""
    vars_ = frame.variables or {}
    var_str = " ".join(str(k) + str(v) for k, v in vars_.items())

    has_concurrent = bool(_THREADING_RE.search(src))
    has_lock_locals = bool(_LOCK_RE.search(var_str))

    if not has_concurrent and not has_lock_locals:
        return ""

    func_name = frame.function or "target_function"

    return f"""\
# RACE CONDITION SIMULATION — delay injection at crash site.
# Technique 1: slow_wrapper (zero deps) — forces context switch at vulnerable point.
import time as _time
import threading as _threading

def _slow_wrap(method, delay_s=0.001):
    \"\"\"Delay before the method to force scheduler to expose the race window.\"\"\"
    def wrapped(*args, **kwargs):
        _time.sleep(delay_s)
        return method(*args, **kwargs)
    return wrapped

# Usage: patch the crashing method, then launch concurrent threads:
#   target_obj.{func_name} = _slow_wrap(target_obj.{func_name})
#   threads = [_threading.Thread(target=target_obj.{func_name}) for _ in range(4)]
#   for t in threads: t.start()
#   for t in threads: t.join()

# Technique 2: frontrun (pip install frontrun) — PCT-style schedule exploration.
# from frontrun import explore_interleavings
# explore_interleavings(target_obj.{func_name}, n_threads=4, n_iterations=200)

"""


# ---------------------------------------------------------------------------
# Composite: build all supplementary mock code for a frame + event
# ---------------------------------------------------------------------------

def build_supplementary_mock_code(
    frame: "SentryFrame",
    exc: "SentryException",
    source: str,
    repo_root: str | Path | None = None,
) -> str:
    """Run all detectors and concatenate non-empty results.

    Prepend the result to mock_setup_code before LLM synthesis so the LLM
    sees all available context for limitation-class bug reproduction.
    """
    parts = [
        http_mock_from_locals(frame, source),
        freeze_time_from_event(exc),
        db_fixture_hints(frame, repo_root),
        sqlalchemy_savepoint_code(frame, source),
        race_wrapper_from_locals(frame, source),
    ]
    return "".join(p for p in parts if p)
