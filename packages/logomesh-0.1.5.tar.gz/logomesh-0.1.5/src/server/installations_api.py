"""Wizard-facing installations API.

This is the surface the onboarding wizard talks to. The shape mirrors
the mock backend in `logomesh-website/lib/mock-backend.ts` so the
frontend can be flipped from mock → real with a single env var
(`NEXT_PUBLIC_USE_MOCK_BACKEND=0`).

Endpoints:
    POST   /api/installations                                   anonymous, creates install
    GET    /api/installations/{id}                              bearer = client_secret
    PUT    /api/installations/{id}/sentry-token                 bearer
    PUT    /api/installations/{id}/github                       bearer
    PUT    /api/installations/{id}/slack                        bearer
    POST   /api/installations/{id}/test                         bearer — fires synthetic event
    GET    /api/installations/{id}/runs                         bearer
    GET    /api/installations/{id}/runs/{run_id}/artifact       bearer

Auth model:
    `POST /api/installations` is anonymous. The response includes a
    one-time `client_secret`. Every subsequent request must present it
    as `Authorization: Bearer <client_secret>`. We compare in constant
    time against the stored, decrypted Sentry HMAC secret (the same
    secret the customer pastes into Sentry's Custom Integration form).

    The wizard never sees the secret again after the create response —
    it's expected to be saved in localStorage (or pasted manually if
    the user is rotating later).

Per-install ID format:
    UUID strings everywhere. The orchestrator + sentry_replay
    accept the str; nothing internal needs the legacy numeric form.

Admin operations (purge, audit listing) live behind a separate
`LOGOMESH_ADMIN_TOKEN` at `/api/admin/installations`.
"""
from __future__ import annotations

import asyncio
import base64
import hmac
import logging
import os
import secrets
import uuid
from typing import Any

from fastapi import APIRouter, Header, HTTPException, status
from pydantic import BaseModel, Field

log = logging.getLogger("logomesh.server.installations_api")

router = APIRouter(prefix="/api/installations", tags=["installations"])


# ---------------------------------------------------------------------------
# Per-install bearer auth
# ---------------------------------------------------------------------------

def _public_host() -> str:
    """Where Sentry should POST webhooks for this deploy.

    Defaults to the local FastAPI port for `npm run dev` flows; production
    deploys set LOGOMESH_PUBLIC_HOST=https://api.logomesh.dev (or the
    operator's tunnel) so the wizard prints a copy-pasteable URL that
    actually reaches us.
    """
    return os.environ.get("LOGOMESH_PUBLIC_HOST", "http://localhost:8080").rstrip("/")


def _generate_client_secret() -> str:
    """32-byte URL-safe token. Doubles as both the Sentry HMAC secret
    and the wizard's bearer token — same value, two uses. Customers paste
    it into Sentry's Custom Integration form; the wizard sends it back
    in the Authorization header."""
    return "lms_secret_" + base64.urlsafe_b64encode(secrets.token_bytes(32)).decode().rstrip("=")


async def _require_install_bearer(
    installation_id: str, authorization: str | None,
):
    """Resolve the install + verify bearer token. Returns the secrets
    bundle or raises HTTPException(401/404).

    The bearer must equal the stored sentry_client_secret. We compare
    it in constant time. A missing row (or one without a stored secret)
    fails closed — better 404 than letting an attacker probe live IDs.
    """
    from core import installation_secrets as ins  # type: ignore
    sec = await asyncio.to_thread(ins.fetch_installation_secrets, installation_id)
    if sec is None:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="installation not found",
        )
    if not sec.sentry_client_secret:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="installation has no client_secret on file",
        )
    presented = ""
    if authorization and authorization.lower().startswith("bearer "):
        presented = authorization[7:].strip()
    if not presented or not hmac.compare_digest(presented, sec.sentry_client_secret):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="invalid client_secret",
        )
    return sec


# ---------------------------------------------------------------------------
# Models
# ---------------------------------------------------------------------------

class CreateBody(BaseModel):
    owner: str | None = Field(default=None, max_length=128,
                              description="Optional friendly identifier (org slug, customer name)")


class SentryTokenBody(BaseModel):
    token: str = Field(..., min_length=8, max_length=2048)


class GithubBody(BaseModel):
    token: str = Field(..., min_length=8, max_length=2048)
    repo: str = Field(..., pattern=r"^[\w.-]+/[\w.-]+$",
                      description="GitHub repository in `owner/name` form")


class SlackBody(BaseModel):
    webhook_url: str = Field(..., min_length=8, max_length=512)


# ---------------------------------------------------------------------------
# POST /api/installations  — anonymous create
# ---------------------------------------------------------------------------

@router.post("", status_code=status.HTTP_201_CREATED)
async def create_installation(body: CreateBody | None = None) -> dict[str, Any]:
    from core import installation_secrets as ins  # type: ignore
    from core.supabase_client import upsert_installation  # type: ignore

    install_id = str(uuid.uuid4())
    client_secret = _generate_client_secret()
    owner = (body.owner if body else None) or "wizard"

    upsert_installation(install_id, owner=owner, account_type="organization")

    # Store the freshly-generated client_secret encrypted, so it's
    # available to /webhooks/sentry HMAC verify AND to the bearer
    # check on subsequent /api/installations/{id}/* calls.
    ok = await asyncio.to_thread(
        ins.upsert_installation_secrets,
        install_id,
        sentry_client_secret=client_secret,
    )
    if not ok:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=(
                "could not persist client_secret. "
                "Check LOGOMESH_MASTER_KEY + SUPABASE_URL (or SUPABASE_PROJECT_REF) + "
                "SUPABASE_SERVICE_KEY/SUPABASE_SERVICE_ROLE_KEY."
            ),
        )

    from datetime import datetime, timezone
    return {
        "id": install_id,
        "client_secret": client_secret,   # last-and-only-time in plaintext
        "webhook_url": f"{_public_host()}/webhooks/sentry/{install_id}",
        "created_at": datetime.now(timezone.utc).isoformat(),
    }


# ---------------------------------------------------------------------------
# GET /api/installations/{id} — summary for the dashboard
# ---------------------------------------------------------------------------

@router.get("/{installation_id}")
async def get_installation(
    installation_id: str,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    sec = await _require_install_bearer(installation_id, authorization)
    from core import runs_log  # type: ignore

    runs_count = await asyncio.to_thread(runs_log.count_runs, installation_id)
    last_event_at = await asyncio.to_thread(_last_event_at, installation_id)

    return {
        "id": installation_id,
        "created_at": _created_at(installation_id) or "",
        "sentry": {
            "configured": bool(sec.sentry_auth_token),
            "last_event_at": last_event_at,
        },
        "github": {
            "configured": bool(sec.github_token),
            "repo": sec.github_repo or None,
        },
        "slack": {
            "configured": bool(sec.slack_webhook_url),
        },
        "runs_count": runs_count,
    }


def _created_at(installation_id: str) -> str | None:
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return None
    try:
        r = client.table("installations").select("created_at").eq(
            "installation_id", installation_id,
        ).limit(1).execute()
        rows = r.data or []
        return rows[0].get("created_at") if rows else None
    except Exception:
        return None


def _last_event_at(installation_id: str) -> str | None:
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return None
    try:
        r = client.table("runs").select("created_at").eq(
            "installation_id", installation_id,
        ).order("created_at", desc=True).limit(1).execute()
        rows = r.data or []
        return rows[0].get("created_at") if rows else None
    except Exception:
        return None


# ---------------------------------------------------------------------------
# PUT /sentry-token  /github  /slack — secret rotation
# ---------------------------------------------------------------------------

@router.put("/{installation_id}/sentry-token")
async def set_sentry_token(
    installation_id: str, body: SentryTokenBody,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    """Store the customer's Sentry auth token. Validates the token
    against the Sentry API first — fails closed with 400 if Sentry
    rejects it, so the wizard surfaces 'wrong scope / wrong token'
    immediately instead of letting the customer ship a broken install
    and find out only when the first real crash silently 401s.
    """
    await _require_install_bearer(installation_id, authorization)
    from core import installation_secrets as ins  # type: ignore

    if os.environ.get("LOGOMESH_SKIP_SENTRY_TOKEN_VALIDATION", "").lower() not in ("1", "true", "yes"):
        ok, reason = await _validate_sentry_token(body.token)
        if not ok:
            raise HTTPException(
                status_code=400,
                detail=f"Sentry rejected the token: {reason}",
            )

    saved = await asyncio.to_thread(
        ins.upsert_installation_secrets,
        installation_id, sentry_auth_token=body.token,
    )
    if not saved:
        raise HTTPException(status_code=500, detail="could not store token")
    return {"configured": True}


async def _validate_sentry_token(token: str) -> tuple[bool, str]:
    """Quick liveness check against Sentry's /api/0/auth/ endpoint."""
    import httpx
    base = os.environ.get("LOGOMESH_SENTRY_HOST", "https://sentry.io").rstrip("/")
    url = f"{base}/api/0/auth/"
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.get(url, headers={"Authorization": f"Bearer {token.strip()}"})
    except httpx.HTTPError as e:
        return False, f"network error reaching Sentry ({e.__class__.__name__})"
    if r.status_code == 200:
        return True, "ok"
    if r.status_code == 401:
        return False, "401 unauthorized — token is invalid or revoked"
    if r.status_code == 403:
        return False, "403 forbidden — token lacks required scopes (need event:read on issues + comments)"
    return False, f"HTTP {r.status_code}: {r.text[:200]}"


@router.put("/{installation_id}/github")
async def set_github(
    installation_id: str, body: GithubBody,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    """Store + verify GitHub PAT and target repo. The validator
    confirms the PAT can push to the repo (required for draft PRs).
    Read-only PATs are rejected at save time."""
    await _require_install_bearer(installation_id, authorization)
    from core import installation_secrets as ins  # type: ignore

    if os.environ.get("LOGOMESH_SKIP_GITHUB_TOKEN_VALIDATION", "").lower() not in ("1", "true", "yes"):
        ok, reason = await _validate_github_token(body.token, body.repo)
        if not ok:
            raise HTTPException(
                status_code=400,
                detail=f"GitHub rejected the token / repo: {reason}",
            )

    saved = await asyncio.to_thread(
        ins.upsert_installation_secrets,
        installation_id, github_token=body.token, github_repo=body.repo,
    )
    if not saved:
        raise HTTPException(status_code=500, detail="could not store github creds")
    return {"configured": True, "repo": body.repo}


async def _validate_github_token(token: str, repo: str) -> tuple[bool, str]:
    """Two checks: PAT authenticates AND has push access to the target repo."""
    import httpx
    api = os.environ.get("LOGOMESH_GITHUB_API", "https://api.github.com").rstrip("/")
    headers = {
        "Authorization": f"Bearer {token.strip()}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            user_r = await c.get(f"{api}/user", headers=headers)
            if user_r.status_code == 401:
                return False, "401 unauthorized — PAT is invalid or revoked"
            if user_r.status_code != 200:
                return False, f"HTTP {user_r.status_code} on /user: {user_r.text[:160]}"
            repo_r = await c.get(f"{api}/repos/{repo}", headers=headers)
            if repo_r.status_code == 404:
                return False, f"repo {repo!r} not found (or PAT can't see it)"
            if repo_r.status_code == 403:
                return False, f"403 forbidden on {repo!r} — PAT lacks repo scope"
            if repo_r.status_code != 200:
                return False, f"HTTP {repo_r.status_code} on /repos/{repo}: {repo_r.text[:160]}"
            data = repo_r.json()
            perms = (data or {}).get("permissions", {}) or {}
            if not perms.get("push"):
                return False, (
                    f"PAT can read {repo!r} but cannot push — draft PRs need "
                    "push permission. Re-create the PAT with `repo` scope."
                )
    except httpx.HTTPError as e:
        return False, f"network error reaching GitHub ({e.__class__.__name__})"
    return True, "ok"


@router.put("/{installation_id}/slack")
async def set_slack(
    installation_id: str, body: SlackBody,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    """Store + verify a Slack incoming-webhook URL. Posts a real test
    message at save time so the customer sees the channel mapping work
    immediately instead of finding out at the first real crash."""
    if not body.webhook_url.startswith("https://hooks.slack.com/"):
        raise HTTPException(
            status_code=400,
            detail="Slack webhook URL must start with https://hooks.slack.com/",
        )
    await _require_install_bearer(installation_id, authorization)
    from core import installation_secrets as ins  # type: ignore

    if os.environ.get("LOGOMESH_SKIP_SLACK_VALIDATION", "").lower() not in ("1", "true", "yes"):
        ok, reason = await _validate_slack_webhook(body.webhook_url)
        if not ok:
            raise HTTPException(
                status_code=400,
                detail=f"Slack rejected the webhook: {reason}",
            )

    saved = await asyncio.to_thread(
        ins.upsert_installation_secrets,
        installation_id, slack_webhook_url=body.webhook_url,
    )
    if not saved:
        raise HTTPException(status_code=500, detail="could not store slack url")
    return {"configured": True}


async def _validate_slack_webhook(url: str) -> tuple[bool, str]:
    """Send a small test message. Returns (ok, reason)."""
    import httpx
    payload = {"text": ":white_check_mark: logomesh wizard test — channel wired up."}
    try:
        async with httpx.AsyncClient(timeout=10.0) as c:
            r = await c.post(url, json=payload)
    except httpx.HTTPError as e:
        return False, f"network error reaching Slack ({e.__class__.__name__})"
    if r.status_code == 200 and r.text.strip() == "ok":
        return True, "ok"
    if r.status_code == 404:
        return False, "404 — webhook URL is invalid or revoked"
    return False, f"HTTP {r.status_code}: {r.text[:160]}"


# ---------------------------------------------------------------------------
# POST /test  — fire a synthetic Sentry event through the orchestrator
# ---------------------------------------------------------------------------

@router.post("/{installation_id}/test", status_code=status.HTTP_202_ACCEPTED)
async def fire_test(
    installation_id: str,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    """Run the orchestrator end-to-end against a checked-in fixture so
    the wizard's "Send test event" button proves the install works.

    The fixture is the deterministic v3_02_balance_debit_race scenario
    (~30s end-to-end, well under the dispatch semaphore + sandbox
    timeouts). The run is dispatched in the background; we return a
    pre-inserted run_id immediately so the wizard can poll
    /runs to watch it transition from `in_progress` → `shipped`.
    """
    await _require_install_bearer(installation_id, authorization)
    from core import runs_log  # type: ignore

    fixture_path = _resolve_test_fixture()
    sentry_issue_id = "logomesh-wizard-test"
    run_id = await asyncio.to_thread(
        runs_log.create_pending_run, installation_id, sentry_issue_id,
    )

    asyncio.create_task(_run_wizard_test(
        installation_id=installation_id,
        run_id=run_id,
        sentry_issue_id=sentry_issue_id,
        fixture_path=fixture_path,
    ))

    return {"run_id": run_id}


def _resolve_test_fixture() -> str:
    """Pick the canonical wizard test fixture path."""
    from pathlib import Path
    explicit = os.environ.get("LOGOMESH_WIZARD_TEST_FIXTURE", "").strip()
    if explicit and Path(explicit).is_file():
        return explicit
    repo_root = Path(__file__).resolve().parent.parent.parent
    candidates = [
        Path("/tmp/logomesh_smoke_data/tests/fixtures/sentry_v3_02_balance_debit_race.json"),
        repo_root / "tests" / "fixtures" / "sentry_v3_02_balance_debit_race.json",
    ]
    for p in candidates:
        if p.is_file():
            return str(p)
    raise HTTPException(
        status_code=503,
        detail=(
            "no wizard test fixture found. Set LOGOMESH_WIZARD_TEST_FIXTURE "
            "to a Sentry event JSON file."
        ),
    )


async def _run_wizard_test(
    *, installation_id: str, run_id: str,
    sentry_issue_id: str, fixture_path: str,
) -> None:
    """Background task — fires the orchestrator and persists the run."""
    from core import runs_log  # type: ignore
    # Late import: orchestrator drag-in.
    import sys
    from pathlib import Path
    repo_root = Path(__file__).resolve().parent.parent.parent
    if str(repo_root) not in sys.path:
        sys.path.insert(0, str(repo_root))
    import logomesh_orchestrator as o  # type: ignore

    os.environ["LOGOMESH_SENTRY_FIXTURE"] = fixture_path
    event = {
        "id": sentry_issue_id,
        "organization": {"slug": "wizard"},
        "installation_id": installation_id,
        "repo_path": os.environ.get("LOGOMESH_REPO_PATH", "."),
    }
    try:
        result = await o.handle_sentry_webhook(event)
    except Exception as e:
        log.exception("wizard test dispatch failed run_id=%s", run_id)
        result = {
            "status": "error", "artifact": None, "pr_url": "",
            "needs_human_review": True,
            "human_review_reason": f"{type(e).__name__}: {e}",
            "duration_s": 0.0, "usage": {},
        }
    await asyncio.to_thread(
        runs_log.record_run_finished, run_id,
        installation_id=installation_id,
        sentry_issue_id=sentry_issue_id,
        result=result,
    )


# ---------------------------------------------------------------------------
# GET /runs  + /runs/{run_id}/artifact
# ---------------------------------------------------------------------------

@router.get("/{installation_id}/runs")
async def list_installation_runs(
    installation_id: str,
    limit: int = 20,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    await _require_install_bearer(installation_id, authorization)
    from core import runs_log  # type: ignore
    runs = await asyncio.to_thread(runs_log.list_runs, installation_id, limit=limit)
    return {"runs": runs}


@router.get("/{installation_id}/runs/{run_id}/artifact")
async def get_artifact(
    installation_id: str, run_id: str,
    authorization: str | None = Header(default=None),
) -> dict[str, Any]:
    await _require_install_bearer(installation_id, authorization)
    from core import runs_log  # type: ignore
    art = await asyncio.to_thread(
        runs_log.get_run_artifact, installation_id, run_id,
    )
    if art is None:
        raise HTTPException(status_code=404, detail="artifact not found")
    return art
