"""Post the orchestrator's verdict as a comment on a GitHub PR/issue.

GitHub uses the same comment endpoint for issues and PRs:
    POST /repos/{owner}/{repo}/issues/{number}/comments
    Auth: Bearer <token>
    Body: {"body": "<markdown>"}

Refs (verified 2026-05-07):
    https://docs.github.com/en/rest/issues/comments#create-an-issue-comment

For pilot v1 the token comes from `GITHUB_TOKEN` env. v1.1 will store
it per-installation (and migrate to a GitHub App).
"""

from __future__ import annotations

import json
import logging
import os
import re
from typing import Any

import httpx

from .sentry_comment import render_verdict_markdown

log = logging.getLogger("logomesh.server.github_comment")

_DEFAULT_HOST = "https://api.github.com"
_TIMEOUT_S = 10.0
_PR_URL_RE = re.compile(
    r"https?://(?:[^/]+/)?github\.com/(?P<owner>[^/]+)/(?P<repo>[^/]+)"
    r"/(?:pull|issues)/(?P<number>\d+)",
    re.IGNORECASE,
)


def _auth_token() -> str:
    return os.environ.get("GITHUB_TOKEN", "").strip()


def _api_host() -> str:
    return os.environ.get("LOGOMESH_GITHUB_API", _DEFAULT_HOST).rstrip("/")


def parse_pr_url(url: str) -> tuple[str, str, int] | None:
    """Extract (owner, repo, number) from a GitHub PR or issue URL."""
    m = _PR_URL_RE.search(url or "")
    if not m:
        return None
    return m.group("owner"), m.group("repo"), int(m.group("number"))


async def post_pr_comment(
    pr_url: str, body: str, *, token: str | None = None,
) -> dict[str, Any]:
    """Post a comment on a GitHub PR (or issue). Returns the API response."""
    parsed = parse_pr_url(pr_url)
    if not parsed:
        raise ValueError(f"not a GitHub PR/issue URL: {pr_url!r}")
    owner, repo, number = parsed

    bearer = (token or _auth_token()).strip()
    if not bearer:
        raise RuntimeError("GITHUB_TOKEN not set; cannot post PR comment")

    url = f"{_api_host()}/repos/{owner}/{repo}/issues/{number}/comments"
    headers = {
        "Authorization": f"Bearer {bearer}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "Content-Type": "application/json",
    }
    async with httpx.AsyncClient(timeout=_TIMEOUT_S) as client:
        resp = await client.post(url, headers=headers, content=json.dumps({"body": body}))
        resp.raise_for_status()
        return resp.json()


async def post_verdict_to_pr(
    pr_url: str, result: dict, *, token: str | None = None,
) -> None:
    """Render verdict markdown + post on the PR. Logs but never raises.

    Per-installation `token` overrides `GITHUB_TOKEN` env. Empty/None
    falls through to the env var so single-tenant + CLI flows still work.
    """
    if not pr_url:
        return
    try:
        body = render_verdict_markdown(result)
        out = await post_pr_comment(pr_url, body, token=token)
        log.info("posted PR comment pr=%s comment_id=%s", pr_url, out.get("id"))
    except Exception as e:
        log.warning("failed to post PR comment pr=%s err=%s", pr_url, e)
