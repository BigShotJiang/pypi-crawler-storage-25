"""Post the orchestrator's verdict back to the Sentry issue as a comment.

Sentry REST API:
    POST /api/0/issues/{issue_id}/comments/
    Auth: Bearer <token> (org-scoped auth token w/ event:write scope)
    Body: {"text": "<markdown>"}

Refs (verified 2026-05-07):
    https://docs.sentry.io/api/events/create-a-new-comment/
    https://docs.sentry.io/api/auth-tokens/

For pilot v1 we read the token from `LOGOMESH_SENTRY_AUTH_TOKEN`. v1.1
will look it up per-installation from the DB.
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

import httpx

log = logging.getLogger("logomesh.server.sentry_comment")

_DEFAULT_HOST = "https://sentry.io"
_TIMEOUT_S = 10.0


def _auth_token() -> str:
    return os.environ.get("LOGOMESH_SENTRY_AUTH_TOKEN", "").strip()


def _host() -> str:
    return os.environ.get("LOGOMESH_SENTRY_HOST", _DEFAULT_HOST).rstrip("/")


def render_verdict_markdown(result: dict) -> str:
    """Build the markdown body posted to the Sentry issue."""
    artifact = result.get("artifact") or {}
    seal = artifact.get("evidence_path_seal") or {}
    verified = bool(seal.get("verified_exception_match"))
    sandbox_exc = seal.get("sandbox_exception_type") or "unknown"
    expected_exc = seal.get("expected_exception_type") or "unknown"
    pr_url = result.get("pr_url") or ""
    duration = result.get("duration_s")
    needs_review = bool(result.get("needs_human_review"))
    review_reason = result.get("human_review_reason") or ""
    evidence = result.get("human_review_evidence") or {}

    dur_str = f" · {round(duration)}s" if duration is not None else ""

    if needs_review:
        fn = evidence.get("function", "")
        filename = evidence.get("file", "")
        lineno = evidence.get("lineno", 0)
        error_type = evidence.get("error_type", "")
        error_message = evidence.get("error_message", "")
        frame_locals = evidence.get("frame_locals") or {}
        hypotheses = evidence.get("hypotheses") or []

        lines = [f"⚠️ **logomesh · needs human review{dur_str}**", ""]

        if error_type or fn:
            crash_line = f"**crash:** `{error_type}`"
            if error_message:
                crash_line += f" — {error_message[:120]}"
            lines.append(crash_line)
            if fn:
                loc = f"`{fn}()`"
                if filename:
                    loc += f" · `{filename}:{lineno}`" if lineno else f" · `{filename}`"
                lines.append(f"**where:** {loc}")

        if frame_locals:
            locals_str = ", ".join(
                f"`{k}={v}`" for k, v in list(frame_locals.items())[:5]
            )
            lines.append(f"**frame locals:** {locals_str}")

        if hypotheses:
            lines.append("")
            for h in hypotheses[:3]:
                conf = int(h.get("confidence", 0) * 100)
                desc = h.get("description", "")
                ev = h.get("evidence", "")
                tip = h.get("investigation", "")
                lines.append(f"**hypothesis #{h.get('rank', 1)} ({conf}%):** {desc}")
                if ev:
                    lines.append(f"  evidence: {ev}")
                if tip:
                    lines.append(f"  → {tip}")

        # Best investigation result — surface if something reproduced
        best = evidence.get("best_investigation")
        if best and best.get("reproduced"):
            lines.append("")
            strat = best.get("strategy", "unknown")
            exc_found = best.get("sandbox_exc", "")
            env_delta = best.get("env_delta") or {}
            lines.append(f"**closest repro found · strategy: `{strat}`**")
            if exc_found:
                lines.append(f"  sandbox raised: `{exc_found}`")
            if env_delta:
                for k, v in list(env_delta.items())[:3]:
                    lines.append(f"  env: `{k}={v}`")
            snippet = (best.get("output_snippet") or "")[:300]
            if snippet:
                lines.append(f"  ```\n  {snippet.strip()}\n  ```")
            lines.append("  *(advisory — not a sealed artifact)*")

        manual_script = evidence.get("manual_repro_script", "")
        if manual_script:
            lines.append("")
            lines.append("<details><summary>manual repro script (copy-paste to run locally)</summary>")
            lines.append("")
            lines.append("```python")
            lines.append(manual_script.strip())
            lines.append("```")
            lines.append("")
            lines.append("</details>")

        lines.append("")
        lines.append(
            f"*Could not prove deterministically — `{review_reason or 'unspecified'}`.*  \n"
            "*No artifact sealed. Engineer sign-off required before any action.*"
        )

    elif verified:
        repro = artifact.get("reproduction") or {}
        fn = repro.get("function", "")
        call_expr = repro.get("call_expression", "")
        filename = repro.get("file", "")
        lineno = repro.get("lineno", 0)

        lines = [f"✅ **logomesh · reproduced{dur_str}**", ""]

        if fn or filename:
            loc = f"`{fn}()`" if fn else ""
            if filename:
                loc += f" · `{filename}:{lineno}`" if lineno else f" · `{filename}`"
            lines.append(f"**where:** {loc}")
        if call_expr:
            lines.append(f"**exact call:** `{call_expr}`")
        lines.append(f"**exception:** `{sandbox_exc}` matches captured `{expected_exc}`")
        if pr_url:
            lines.append(f"**failing test → PR:** {pr_url}")
        lines.append("")
        lines.append(
            f"*Sealed · hash `{seal.get('test_sha256_first16', '')[:12]}` · "
            "no LLM in evidence path*"
        )

    else:
        lines = [f"❌ **logomesh · repro did not verify{dur_str}**", ""]
        lines.append(
            f"Sandbox raised `{sandbox_exc}`, expected `{expected_exc}`.  \n"
            "No artifact sealed."
        )

    return "\n".join(lines)


async def post_sentry_comment(
    issue_id: str, text: str, *, token: str | None = None,
) -> dict[str, Any]:
    """POST a comment to the Sentry issue. Returns the API response.

    Raises httpx.HTTPStatusError on non-2xx. Caller decides whether to
    swallow (we're in a detached background task)."""
    bearer = (token or _auth_token()).strip()
    if not bearer:
        raise RuntimeError(
            "LOGOMESH_SENTRY_AUTH_TOKEN not set; cannot post Sentry comment"
        )
    url = f"{_host()}/api/0/issues/{issue_id}/comments/"
    headers = {
        "Authorization": f"Bearer {bearer}",
        "Content-Type": "application/json",
    }
    async with httpx.AsyncClient(timeout=_TIMEOUT_S) as client:
        resp = await client.post(url, headers=headers, content=json.dumps({"text": text}))
        resp.raise_for_status()
        return resp.json()


async def post_verdict_to_sentry(
    issue_id: str, result: dict, *, token: str | None = None,
) -> None:
    """Render + post. Logs but never raises (background task).

    `token` is optional per-installation override. Falls back to
    `LOGOMESH_SENTRY_AUTH_TOKEN` env var when None — preserves the
    pilot v1 single-tenant flow while letting the multi-tenant
    server layer pass the right secret per webhook.
    """
    try:
        body = render_verdict_markdown(result)
        out = await post_sentry_comment(issue_id, body, token=token)
        log.info(
            "posted sentry comment issue_id=%s comment_id=%s",
            issue_id, out.get("id"),
        )
    except Exception as e:
        log.warning("failed to post sentry comment issue_id=%s err=%s", issue_id, e)
