"""Sentry webhook receiver — pilot v1 trigger surface.

Three layered defenses before we accept the body:

  1. **HMAC signature.** `Sentry-Hook-Signature` must be a hex
     HMAC-SHA256 of the raw body using the integration's client
     secret, compared in constant time.
  2. **Timestamp replay protection.** `Sentry-Hook-Timestamp` (epoch
     seconds) must be within ±300s of now. Without this, a captured
     signed body can be replayed forever — and the orchestrator's
     30–60s LangGraph + Docker run is a free DoS surface.
  3. **Idempotency by `(issue_id, sha256(payload))`.** Sentry retries
     non-2xx with exponential backoff. A network blip during our 202
     ACK can cause 2–3 parallel runs for the same issue, each opening
     a draft PR. We dedupe for 24h via an in-process LRU.

A semaphore caps concurrent orchestrator dispatches to
`LOGOMESH_MAX_CONCURRENT_RUNS` (default 3). Above that, the webhook
still ACKs 202 (so Sentry doesn't retry) but the orchestrator dispatch
waits its turn — prevents a noisy alert rule from pinning the box.

Refs (verified 2026-05-07):
  - docs.sentry.io/organization/integrations/integration-platform/webhooks/
  - getsentry/sentry-docs#integration-platform/webhooks
"""

from __future__ import annotations

import asyncio
import hashlib
import hmac
import logging
import os
import time
from collections import OrderedDict
from typing import Any

from fastapi import APIRouter, Header, HTTPException, Request, status
from pydantic import BaseModel, Field

log = logging.getLogger("logomesh.server.sentry_webhook")

router = APIRouter(prefix="/webhooks/sentry", tags=["webhooks"])

# ---------------------------------------------------------------------------
# Concurrency + idempotency state (process-local; single-tenant pilot v1).
# ---------------------------------------------------------------------------

_DEFAULT_MAX_CONCURRENT_RUNS = 3
_DEFAULT_TIMESTAMP_WINDOW_S = 300         # ±5 minutes
_DEFAULT_IDEMPOTENCY_TTL_S = 24 * 60 * 60  # 24h
_IDEMPOTENCY_MAX_ENTRIES = 10000           # LRU cap

_dispatch_semaphore: asyncio.Semaphore | None = None
_idempotency_cache: "OrderedDict[str, float]" = OrderedDict()


def _get_dispatch_semaphore() -> asyncio.Semaphore:
    """Lazy-init so we read env at first use, not module import time."""
    global _dispatch_semaphore
    if _dispatch_semaphore is None:
        try:
            n = int(os.environ.get("LOGOMESH_MAX_CONCURRENT_RUNS",
                                   _DEFAULT_MAX_CONCURRENT_RUNS))
        except ValueError:
            n = _DEFAULT_MAX_CONCURRENT_RUNS
        n = max(1, min(n, 32))  # clamp
        _dispatch_semaphore = asyncio.Semaphore(n)
    return _dispatch_semaphore


def _idempotency_window_s() -> int:
    try:
        return int(os.environ.get("LOGOMESH_IDEMPOTENCY_TTL_S",
                                  _DEFAULT_IDEMPOTENCY_TTL_S))
    except ValueError:
        return _DEFAULT_IDEMPOTENCY_TTL_S


def _timestamp_window_s() -> int:
    try:
        return int(os.environ.get("LOGOMESH_TIMESTAMP_WINDOW_S",
                                  _DEFAULT_TIMESTAMP_WINDOW_S))
    except ValueError:
        return _DEFAULT_TIMESTAMP_WINDOW_S


def _idempotency_key(issue_id: str, raw_body: bytes) -> str:
    """Stable key per (issue, raw payload bytes)."""
    h = hashlib.sha256(raw_body).hexdigest()
    return f"{issue_id}:{h}"


def _is_duplicate_and_remember(key: str) -> bool:
    """Return True iff `key` was seen within the idempotency window.

    Side effects: evicts expired entries + LRU-trims, then records
    `key` with the current timestamp. Process-local; a deploy restart
    resets the cache. v1.1: replace with Redis SETNX-with-TTL.
    """
    now = time.time()
    window = _idempotency_window_s()
    expired = [k for k, ts in _idempotency_cache.items() if now - ts > window]
    for k in expired:
        _idempotency_cache.pop(k, None)
    while len(_idempotency_cache) >= _IDEMPOTENCY_MAX_ENTRIES:
        _idempotency_cache.popitem(last=False)
    if key in _idempotency_cache:
        _idempotency_cache.move_to_end(key)
        return True
    _idempotency_cache[key] = now
    return False


def _reset_state_for_tests() -> None:
    """Pytest helper — clears process-local concurrency + idempotency."""
    global _dispatch_semaphore
    _dispatch_semaphore = None
    _idempotency_cache.clear()


def verify_sentry_timestamp(timestamp_header: str | None) -> bool:
    """True iff `timestamp_header` parses to within ±window of now.

    Sentry sends Unix epoch seconds. A missing or malformed header is
    rejected (returns False). The window is configurable via
    `LOGOMESH_TIMESTAMP_WINDOW_S` (default 300).
    """
    if not timestamp_header:
        return False
    try:
        ts = float(timestamp_header.strip())
    except (TypeError, ValueError):
        return False
    return abs(time.time() - ts) <= _timestamp_window_s()


# ---------------------------------------------------------------------------
# Signature verification
# ---------------------------------------------------------------------------


def _client_secret(installation_id: int | None = None) -> str:
    """Per-installation secret used to verify Sentry's HMAC signature.

    Looks up the installation row first; falls back to the global
    `LOGOMESH_SENTRY_CLIENT_SECRET` env var so the single-tenant pilot
    path still works without a Supabase row.
    """
    if installation_id:
        try:
            from core.installation_secrets import resolve_secrets  # type: ignore
            sec = resolve_secrets(installation_id)
            if sec.sentry_client_secret:
                return sec.sentry_client_secret.strip()
        except Exception as e:
            log.warning(
                "client_secret lookup failed installation_id=%s err=%s",
                installation_id, e,
            )
    return os.environ.get("LOGOMESH_SENTRY_CLIENT_SECRET", "").strip()


def verify_sentry_signature(
    raw_body: bytes, header_sig: str, installation_id: int | None = None,
) -> bool:
    """Constant-time compare of HMAC-SHA256(client_secret, raw_body)."""
    secret = _client_secret(installation_id)
    if not secret:
        return False
    if not header_sig:
        return False
    expected = hmac.new(
        secret.encode("utf-8"), raw_body, hashlib.sha256,
    ).hexdigest()
    return hmac.compare_digest(expected, header_sig.strip())


def _extract_installation_id_str(payload: dict) -> str:
    """Pull the installation_id (UUID or numeric) from the Sentry payload.

    Returns empty string if none parseable. Used only as a legacy
    fallback when the per-install URL form isn't in play; the per-
    install URL is the canonical source.
    """
    candidates: list = [
        payload.get("installation_id"),
        (payload.get("installation") or {}).get("id"),
        (payload.get("installation") or {}).get("uuid"),
        (payload.get("data") or {}).get("installation_id"),
        ((payload.get("data") or {}).get("installation") or {}).get("id"),
    ]
    for c in candidates:
        if c is None:
            continue
        s = str(c).strip()
        if s:
            return s
    return ""


# ---------------------------------------------------------------------------
# Request shape
# ---------------------------------------------------------------------------


class SentryWebhookData(BaseModel):
    """Minimal subset of the Sentry webhook payload we actually use.

    Sentry sends a richer envelope with `action`, `actor`, `data`,
    `installation`, etc. We only require the issue-id surface; everything
    else flows through to the orchestrator unchanged.
    """

    event: dict[str, Any] = Field(default_factory=dict)
    issue: dict[str, Any] = Field(default_factory=dict)


# ---------------------------------------------------------------------------
# Endpoint
# ---------------------------------------------------------------------------


@router.post("/{installation_id}",
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        202: {"description": "Accepted; orchestrator enqueued"},
        401: {"description": "Bad signature"},
        400: {"description": "Malformed payload"},
        404: {"description": "Unknown installation_id in URL"},
    },
)
async def receive_sentry_webhook_for_install(
    installation_id: str,
    request: Request,
    sentry_hook_resource: str | None = Header(default=None),
    sentry_hook_signature: str | None = Header(default=None),
    sentry_hook_timestamp: str | None = Header(default=None),
) -> dict[str, Any]:
    """Per-installation webhook endpoint.

    Sentry's Custom Integration form gets `<host>/webhooks/sentry/<id>`
    as the webhook URL. Routing by URL path eliminates the chicken-and-
    egg of "extract install id from unsigned body to pick verifying
    key" — the URL is implicitly part of the request and carries the id.
    """
    return await _receive_impl(
        installation_id=installation_id,
        request=request,
        sentry_hook_resource=sentry_hook_resource,
        sentry_hook_signature=sentry_hook_signature,
        sentry_hook_timestamp=sentry_hook_timestamp,
    )


@router.post(
    "",
    status_code=status.HTTP_202_ACCEPTED,
    responses={
        202: {"description": "Accepted; orchestrator enqueued"},
        401: {"description": "Bad signature"},
        400: {"description": "Malformed payload"},
    },
)
async def receive_sentry_webhook(
    request: Request,
    sentry_hook_resource: str | None = Header(default=None),
    sentry_hook_signature: str | None = Header(default=None),
    sentry_hook_timestamp: str | None = Header(default=None),
) -> dict[str, Any]:
    """Legacy single-tenant webhook endpoint (env-only signing secret).

    Kept for the env-only pilot path. New installs always use the
    per-install URL above.
    """
    return await _receive_impl(
        installation_id="",
        request=request,
        sentry_hook_resource=sentry_hook_resource,
        sentry_hook_signature=sentry_hook_signature,
        sentry_hook_timestamp=sentry_hook_timestamp,
    )


async def _receive_impl(
    *, installation_id: str,
    request: Request,
    sentry_hook_resource: str | None,
    sentry_hook_signature: str | None,
    sentry_hook_timestamp: str | None,
) -> dict[str, Any]:
    """Sentry webhook entrypoint. ACKs <10s, runs orchestrator async.

    Sentry retries with exponential backoff on non-2xx, so we MUST
    respond fast. The orchestrator (which can run 30-60s) is dispatched
    via `asyncio.create_task` and detached.
    """
    raw = await request.body()

    allow_unsigned = os.environ.get("LOGOMESH_ALLOW_UNSIGNED", "").strip() in {
        "1", "true", "yes",
    }
    if not allow_unsigned:
        # Defense 1: HMAC signature. Per-install secret when the URL
        # carries an installation_id, otherwise falls back to env var
        # (legacy single-tenant deploys).
        if not verify_sentry_signature(
            raw, sentry_hook_signature or "",
            installation_id=installation_id or None,
        ):
            log.warning(
                "sentry webhook signature invalid resource=%s installation_id=%s",
                sentry_hook_resource, installation_id or "-",
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="invalid sentry signature",
            )
        # Defense 2: timestamp replay window. Skip when LOGOMESH_ALLOW_UNSIGNED
        # is set (local fixture testing has no real timestamp).
        if not verify_sentry_timestamp(sentry_hook_timestamp):
            log.warning(
                "sentry webhook timestamp out of window resource=%s ts=%s",
                sentry_hook_resource, sentry_hook_timestamp,
            )
            raise HTTPException(
                status_code=status.HTTP_401_UNAUTHORIZED,
                detail="sentry timestamp outside replay window",
            )

    try:
        payload = await request.json()
    except Exception:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="malformed JSON body",
        )

    issue_id = (payload.get("data") or {}).get("issue", {}).get("id")
    if not issue_id:
        issue_id = (payload.get("issue") or {}).get("id")
    if not issue_id:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="payload missing data.issue.id",
        )
    issue_id_str = str(issue_id)

    # Defense 3: idempotency by (issue_id, sha256(payload)). Sentry retries on
    # non-2xx and on any 2xx that took >10s; we 202 fast so retries are rare,
    # but a network blip will hit us. Dedupe within a 24h window.
    idem_key = _idempotency_key(issue_id_str, raw)
    if _is_duplicate_and_remember(idem_key):
        log.info("sentry webhook duplicate skipped issue_id=%s", issue_id_str)
        return {
            "status": "duplicate",
            "issue_id": issue_id,
            "resource": sentry_hook_resource,
        }

    # Detach into background. We do NOT await this — we ACK first.
    # Concurrency cap is enforced inside _dispatch_to_orchestrator via a
    # semaphore acquire (still 202 immediately; dispatch waits for a slot).
    # Per-install URL passes installation_id; legacy URL falls back to the
    # body-extracted form inside the dispatcher.
    asyncio.create_task(_dispatch_to_orchestrator(
        payload, issue_id_str, url_installation_id=installation_id,
    ))

    return {
        "status": "accepted",
        "issue_id": issue_id,
        "resource": sentry_hook_resource,
    }


async def _dispatch_to_orchestrator(
    payload: dict, issue_id: str, url_installation_id: str = "",
) -> None:
    """Run `handle_sentry_webhook` against the payload. Background task.

    Late import to avoid pulling LangGraph + every tool into module
    import time (fastapi reload would be painful). Logs but never raises
    — this runs detached, no caller can handle exceptions.

    The orchestrator dispatch is gated by a process-local semaphore
    (cap = `LOGOMESH_MAX_CONCURRENT_RUNS`, default 3). Excess webhooks
    queue inside the task instead of running in parallel and pinning
    the box. The webhook endpoint already ACKed 202 by this point, so
    Sentry doesn't retry while we wait.
    """
    sem = _get_dispatch_semaphore()
    async with sem:
        try:
            # Late import: orchestrator graph build is heavy.
            import sys
            from pathlib import Path
            repo_root = Path(__file__).resolve().parent.parent.parent
            if str(repo_root) not in sys.path:
                sys.path.insert(0, str(repo_root))
            import logomesh_orchestrator as o  # type: ignore

            org = (
                (payload.get("data") or {}).get("issue", {}).get("project", {}).get("slug")
                or (payload.get("installation") or {}).get("organization", {}).get("slug")
                or ""
            )
            # URL path is authoritative — it's signed implicitly via the
            # HMAC verification we already passed. Body extraction is a
            # legacy fallback for the env-only single-tenant deploy.
            installation_id = url_installation_id or _extract_installation_id_str(payload)
            event = {
                "id": issue_id,
                "organization": {"slug": org},
                "repo_path": os.environ.get("LOGOMESH_REPO_PATH", "."),
                "installation_id": installation_id,
                "raw_webhook": payload,
            }
            result = await o.handle_sentry_webhook(event)
            log.info(
                "orchestrator finished issue_id=%s status=%s verified=%s "
                "installation_id=%s",
                issue_id,
                result.get("status"),
                ((result.get("artifact") or {}).get("evidence_path_seal") or {}).get(
                    "verified_exception_match"
                ),
                installation_id or "-",
            )

            # Re-resolve secrets after orchestrator runs. We don't reuse the
            # registry-resolved bundle from inside the graph because that
            # registry is cleared in the finally-block. Re-resolution is a
            # cheap Supabase point-read.
            from core.installation_secrets import resolve_secrets  # type: ignore
            secrets = resolve_secrets(installation_id if installation_id else None)

            # Persist the run for the wizard's /runs feed. Best-effort:
            # if Supabase is offline this is a no-op.
            try:
                from core.runs_log import record_run_finished  # type: ignore
                if installation_id:
                    record_run_finished(
                        run_id=None,  # this run originated from a webhook; mint a fresh id
                        installation_id=installation_id,
                        sentry_issue_id=issue_id,
                        result=result,
                    )
            except Exception as e:
                log.warning("runs_log.record_run_finished failed: %s", e)

            # Feature 2: post the verdict back to the Sentry issue as a comment.
            # Per-installation token preferred; falls back to env in poster.
            if secrets.sentry_auth_token:
                from .sentry_comment import post_verdict_to_sentry
                await post_verdict_to_sentry(
                    issue_id, result, token=secrets.sentry_auth_token,
                )

            # Feature 3: if the orchestrator opened a draft PR, post the
            # verdict markdown as a comment so reviewers see the audit
            # summary inline. Per-install GitHub token preferred.
            pr_url = (result.get("pr_url") or "").strip()
            if pr_url and secrets.github_token:
                from .github_comment import post_verdict_to_pr
                await post_verdict_to_pr(
                    pr_url, result, token=secrets.github_token,
                )

            # Feature 4: optional Slack summary via customer-supplied
            # incoming webhook URL. Per-install URL wins over env.
            if secrets.slack_webhook_url:
                from .slack_summary import post_verdict_to_slack
                await post_verdict_to_slack(
                    result, sentry_issue_id=issue_id,
                    webhook_url=secrets.slack_webhook_url,
                )
        except Exception as e:
            log.exception("orchestrator dispatch failed issue_id=%s err=%s", issue_id, e)
