"""Optional: post the orchestrator's verdict to a customer Slack channel
via the customer's own incoming webhook URL.

This is a one-way, low-trust integration: the customer creates an
"Incoming Webhook" in their own Slack workspace, pastes the URL into
our dashboard, and we POST a summary block on every verified run.

We do NOT install a Slack app. We do NOT need OAuth. The webhook URL
itself is the only secret, and Slack treats anyone with it as
authorized to post to the configured channel.

Refs (verified 2026-05-07):
    https://api.slack.com/messaging/webhooks
    https://api.slack.com/reference/block-kit/blocks
"""

from __future__ import annotations

import json
import logging
import os
from typing import Any

import httpx

log = logging.getLogger("logomesh.server.slack_summary")

_TIMEOUT_S = 10.0


def _webhook_url() -> str:
    return os.environ.get("LOGOMESH_SLACK_WEBHOOK_URL", "").strip()


def render_verdict_blocks(result: dict, *, sentry_issue_id: str = "") -> dict:
    """Render Block Kit blocks for the Slack summary.

    Slack incoming webhooks accept either {text: "..."} or {blocks: [...]}.
    We always include a fallback `text` field for accessibility / mobile
    notifications + push-notification preview.
    """
    artifact = result.get("artifact") or {}
    seal = artifact.get("evidence_path_seal") or {}
    verified = bool(seal.get("verified_exception_match"))
    sandbox_exc = seal.get("sandbox_exception_type") or "unknown"
    expected_exc = seal.get("expected_exception_type") or "unknown"
    test_hash = seal.get("test_sha256_first16") or ""
    pr_url = result.get("pr_url") or ""
    duration = result.get("duration_s")
    needs_review = bool(result.get("needs_human_review"))
    review_reason = result.get("human_review_reason") or ""

    if needs_review:
        emoji = ":warning:"
        title = "logomesh — human review required"
        summary = f"Reason: `{review_reason or 'unspecified'}`"
    elif verified:
        emoji = ":white_check_mark:"
        title = "logomesh — crash reproduced and verified"
        summary = (
            f"Sandbox raised `{sandbox_exc}` — matches captured `{expected_exc}`."
        )
    else:
        emoji = ":x:"
        title = "logomesh — repro did NOT verify"
        summary = (
            f"Sandbox raised `{sandbox_exc}`, expected `{expected_exc}`. "
            "No sealed artifact."
        )

    fallback = f"{emoji} {title} — {summary}"

    fields = []
    if test_hash:
        fields.append({"type": "mrkdwn", "text": f"*Seal:*\n`{test_hash}`"})
    if duration is not None:
        fields.append({"type": "mrkdwn", "text": f"*Run time:*\n{duration}s"})
    if sentry_issue_id:
        fields.append({"type": "mrkdwn", "text": f"*Sentry:*\nissue {sentry_issue_id}"})
    # Cost lives in the audit envelope + dashboard only — NOT in the
    # incident channel where stakeholders see it next to a P0.

    blocks: list[dict] = [
        {
            "type": "section",
            "text": {"type": "mrkdwn", "text": f"{emoji} *{title}*\n{summary}"},
        },
    ]
    if fields:
        blocks.append({"type": "section", "fields": fields})
    if pr_url:
        blocks.append({
            "type": "actions",
            "elements": [
                {
                    "type": "button",
                    "text": {"type": "plain_text", "text": "Open draft PR"},
                    "url": pr_url,
                },
            ],
        })
    blocks.append({
        "type": "context",
        "elements": [{
            "type": "mrkdwn",
            "text": (
                "SOC2 CC7.3 + CC7.4 + PCI DSS 12.10.5 (incident response) — "
                "sealed deterministic evidence, no LLM in evidence path."
            ),
        }],
    })
    return {"text": fallback, "blocks": blocks}


async def post_slack_summary(
    payload: dict, *, webhook_url: str | None = None,
) -> None:
    """POST the Block Kit payload to Slack. Raises on non-2xx."""
    url = (webhook_url or _webhook_url()).strip()
    if not url:
        raise RuntimeError(
            "LOGOMESH_SLACK_WEBHOOK_URL not set; cannot post Slack summary"
        )
    async with httpx.AsyncClient(timeout=_TIMEOUT_S) as client:
        resp = await client.post(
            url,
            content=json.dumps(payload),
            headers={"Content-Type": "application/json"},
        )
        resp.raise_for_status()


async def post_verdict_to_slack(
    result: dict, *, sentry_issue_id: str = "",
    webhook_url: str | None = None,
) -> None:
    """Render + post. Logs but never raises (background task)."""
    target = (webhook_url or _webhook_url()).strip()
    if not target:
        return
    try:
        payload = render_verdict_blocks(result, sentry_issue_id=sentry_issue_id)
        await post_slack_summary(payload, webhook_url=target)
        log.info("posted slack summary issue_id=%s", sentry_issue_id or "?")
    except Exception as e:
        log.warning("failed to post slack summary err=%s", e)
