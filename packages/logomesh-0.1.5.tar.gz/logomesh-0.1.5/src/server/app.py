"""FastAPI app for the logomesh pilot v1 backend.

Run locally:
    uv run uvicorn src.server.app:app --reload --port 8080

Then expose via Cloudflare Tunnel for the Sentry integration to reach it:
    cloudflared tunnel --url http://localhost:8080

The endpoints we expose for v1:
    POST /webhooks/sentry            ← Sentry webhook
    GET  /health                     ← liveness probe + sandbox-mode advert
    GET  /                           ← human-readable index

Production refusal:
    LOGOMESH_ENV=production triggers a startup-time check that Docker is
    reachable. If not, the server refuses to boot rather than degrade to
    subprocess sandbox and emit a false `sandbox_mode: subprocess` claim
    in compliance artifacts.
"""

from __future__ import annotations

import logging
import os
import sys

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .installations_api import router as installations_router
from .sentry_webhook import router as sentry_webhook_router

log = logging.getLogger("logomesh.server")
logging.basicConfig(level=logging.INFO, format="%(asctime)s %(name)s %(levelname)s %(message)s")


def _verify_production_sandbox() -> None:
    """In LOGOMESH_ENV=production, refuse to boot without Docker.

    Subprocess mode is not isolated; emitting `sandbox_mode: subprocess`
    in a customer-facing compliance artifact is a false claim about the
    execution environment. Fail loud at startup, not mid-webhook.
    """
    is_production = os.environ.get("LOGOMESH_ENV", "").strip().lower() == "production"

    if is_production and os.environ.get("LOGOMESH_ALLOW_UNSIGNED", "").strip() in {"1", "true", "yes"}:
        log.critical(
            "LOGOMESH_ALLOW_UNSIGNED is set in a production environment. "
            "This disables webhook authentication. Boot refused."
        )
        sys.exit(2)

    if not is_production:
        return
    try:
        import docker  # type: ignore
        client = docker.from_env()
        client.ping()
    except Exception as e:
        log.critical(
            "LOGOMESH_ENV=production requires Docker. "
            "Subprocess sandbox mode is not isolated. Boot refused. err=%s",
            e,
        )
        sys.exit(2)


_verify_production_sandbox()

app = FastAPI(
    title="logomesh Pilot v1",
    description=(
        "Sealed deterministic crash repro for Python fintech. Evidence "
        "envelope maps to SOC2 CC7.3 (event evaluation) + CC7.4 "
        "(incident response) + PCI DSS 12.10.5 (incident response "
        "procedures)."
    ),
    version="0.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],   # tightened in v1.1 to dashboard origin
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)

app.include_router(sentry_webhook_router)
app.include_router(installations_router)


@app.get("/health")
async def health() -> dict[str, str]:
    return {"status": "ok"}


@app.get("/")
async def index() -> dict[str, str]:
    return {
        "service": "logomesh Pilot v1",
        "endpoints": (
            "POST /webhooks/sentry | "
            "POST/GET/PATCH/DELETE /api/installations | "
            "GET /health"
        ),
    }
