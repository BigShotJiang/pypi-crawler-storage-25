"""Codebase context retrieval for LLM test synthesis.

Three layers, composed by :func:`extract_codebase_context`:

* Layer 0 — AST import graph: deterministic, always runs. Pulls the crashing
  function source, its raw imports, and the named class/function definitions
  it imports from local modules.
* Layer 1 — BM25 over ``tests/``: keyword search via ``rank_bm25`` to surface
  existing fixtures matching the imported names.
* Layer 2 — Embedding similarity: only fires if a pre-built index exists at
  ``.logomesh/repo_index/`` (built by ``logomesh index --embed``). Prefers
  ``voyageai``; falls back to ``openai``.

Layer 2 is tried first; on empty result we fall back to BM25. The import-graph
layers always run.

All file reads use ``errors="replace"``. All AST parses are guarded. Any
optional-dep failure in Layers 1/2 returns ``""`` silently — never raises.
"""

from __future__ import annotations

import ast
import json
import re
from pathlib import Path

# Directories we never want to walk into.
_SKIP_PARTS = ("__pycache__", ".venv", "site-packages", ".git", "node_modules")


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------


def extract_codebase_context(
    source: str,
    func_name: str,
    repo_root: Path,
    max_dep_files: int = 3,
    max_chars_per_dep: int = 2000,
) -> dict:
    """Return a context bundle for LLM test synthesis.

    Keys returned (always present, possibly empty strings):

    * ``function_source`` — the source of ``func_name`` (capped at 3000 chars),
      or the first 3000 chars of ``source`` on parse failure.
    * ``imports_raw`` — concatenated raw ``import``/``from … import …`` lines
      from ``source`` (capped at 1000 chars).
    * ``dependency_defs`` — concatenated class/function definitions pulled from
      locally-resolvable imports, up to ``max_dep_files`` files.
    * ``existing_fixtures`` — embedding-search hit if available; otherwise BM25
      hit over ``tests/``; otherwise empty.
    """
    repo_root = Path(repo_root)

    try:
        tree = ast.parse(source)
    except SyntaxError:
        return {
            "function_source": source[:3000],
            "imports_raw": "",
            "dependency_defs": "",
            "existing_fixtures": "",
        }

    func_source = _extract_function(tree, source, func_name)

    import_nodes = [
        n for n in ast.walk(tree) if isinstance(n, (ast.Import, ast.ImportFrom))
    ]
    imports_raw = "\n".join(
        ast.get_source_segment(source, n) or "" for n in import_nodes
    )[:1000]

    dep_defs: list[str] = []
    imported_names: list[str] = []
    files_read = 0

    for node in import_nodes:
        if files_read >= max_dep_files:
            break
        if not isinstance(node, ast.ImportFrom) or not node.module:
            continue
        path = _resolve_local(node.module, repo_root)
        if not path:
            continue
        names = [a.name for a in node.names]
        imported_names.extend(names)
        try:
            dep_src = path.read_text(errors="replace")
        except OSError:
            continue
        extracted = _extract_named_defs(dep_src, names, max_chars_per_dep)
        if extracted:
            dep_defs.append(f"# from {node.module}\n{extracted}")
            files_read += 1

    # Layer 2 first; fall back to Layer 1 (BM25) if embedding layer is empty.
    existing_fixtures = _embedding_search(
        func_name, exc_message=None, repo_root=repo_root
    ) or _bm25_fixture_search(imported_names, repo_root)

    return {
        "function_source": func_source or source[:3000],
        "imports_raw": imports_raw,
        "dependency_defs": "\n\n".join(dep_defs),
        "existing_fixtures": existing_fixtures,
    }


# ---------------------------------------------------------------------------
# Layer 0 helpers — AST import graph
# ---------------------------------------------------------------------------


def _resolve_local(module: str, repo_root: Path) -> Path | None:
    """Resolve a dotted module name to a local ``.py`` file, or ``None``.

    Tries ``repo_root/<module>.py`` and ``repo_root/src/<module>.py``.
    """
    if not module:
        return None
    rel = Path(*module.split("."))
    for root in (repo_root, repo_root / "src"):
        candidate = root / rel.with_suffix(".py")
        if candidate.is_file():
            return candidate
    return None


def _extract_function(tree: ast.AST, source: str, func_name: str) -> str:
    """Return source for the (Async)FunctionDef matching ``func_name``, ≤3000 chars."""
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)):
            if node.name == func_name:
                return (ast.get_source_segment(source, node) or "")[:3000]
    return ""


def _extract_named_defs(source: str, names: list[str], max_chars: int) -> str:
    """Return concatenated source for class/fn defs whose name ∈ ``names``.

    On ``SyntaxError`` returns ``source[:max_chars]`` as a soft fallback.
    """
    try:
        tree = ast.parse(source)
    except SyntaxError:
        return source[:max_chars]

    name_set = set(names)
    chunks: list[str] = []
    for node in ast.walk(tree):
        if isinstance(
            node, (ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)
        ):
            if node.name in name_set:
                seg = ast.get_source_segment(source, node) or ""
                chunks.append(seg[:max_chars])
    return "\n\n".join(chunks)


# ---------------------------------------------------------------------------
# Layer 1 — BM25 over tests/
# ---------------------------------------------------------------------------


def _bm25_fixture_search(
    query_names: list[str],
    repo_root: Path,
    top_k: int = 3,
    max_chars: int = 1500,
) -> str:
    """BM25 keyword search over ``tests/``. Returns top hits joined by ``# ---``.

    Returns ``""`` on missing ``rank_bm25``, missing ``tests/`` dir, or no
    positive-scored hit.
    """
    try:
        from rank_bm25 import BM25Okapi  # type: ignore[import-not-found]
    except ImportError:
        return ""

    test_dir = repo_root / "tests"
    if not test_dir.exists() or not test_dir.is_dir():
        return ""
    if not query_names:
        return ""

    chunks_tokens: list[list[str]] = []
    sources: list[str] = []
    for py_file in test_dir.rglob("*.py"):
        if any(p in py_file.parts for p in _SKIP_PARTS):
            continue
        try:
            text = py_file.read_text(errors="replace")
        except OSError:
            continue
        # Split on lines that begin a new def/class/decorator.
        for chunk in re.split(r"\n(?=(?:@|\bdef |\bclass ))", text):
            stripped = chunk.strip()
            if len(stripped) > 20:
                chunks_tokens.append(chunk.lower().split())
                sources.append(chunk)

    if not chunks_tokens:
        return ""

    try:
        bm25 = BM25Okapi(chunks_tokens)
        query = " ".join(query_names).lower().split()
        if not query:
            return ""
        scores = bm25.get_scores(query)
    except Exception:
        return ""

    top = sorted(range(len(scores)), key=lambda i: scores[i], reverse=True)[
        :top_k
    ]
    results = [sources[i][:max_chars] for i in top if scores[i] > 0]
    return "\n\n# ---\n\n".join(results)


# ---------------------------------------------------------------------------
# Layer 2 — Embedding similarity (optional, requires pre-built index)
# ---------------------------------------------------------------------------


def _embedding_search(
    func_name: str,
    exc_message: str | None,
    repo_root: Path,
    top_k: int = 3,
    max_chars: int = 1500,
) -> str:
    """Cosine-similarity over a pre-built embedding index. ``""`` if unavailable.

    No-op when the index files are missing, when ``numpy`` is unavailable, or
    when neither ``voyageai`` nor ``openai`` is installed / has credentials.
    Re-extracts source segments from disk via AST (the index stores metadata,
    not source) so retrieved chunks reflect the current working tree.
    """
    index_dir = repo_root / ".logomesh" / "repo_index"
    emb_path = index_dir / "embeddings.npy"
    map_path = index_dir / "chunk_map.json"
    if not emb_path.exists() or not map_path.exists():
        return ""

    try:
        import numpy as np  # type: ignore[import-not-found]
    except ImportError:
        return ""

    try:
        vectors = np.load(emb_path)
        meta = json.loads(map_path.read_text(errors="replace"))
    except Exception:
        return ""

    if not isinstance(meta, list) or len(meta) == 0:
        return ""

    query_text = f"{func_name} {exc_message or ''}".strip()
    if not query_text:
        return ""

    # Build the query embedding. Prefer voyage-code-3; fall back to OpenAI.
    try:
        try:
            import voyageai  # type: ignore[import-not-found]

            q_vec = np.array(
                voyageai.Client()
                .embed(
                    [query_text],
                    model="voyage-code-3",
                    input_type="query",
                )
                .embeddings[0],
                dtype="float32",
            )
        except ImportError:
            import openai  # type: ignore[import-not-found]

            q_vec = np.array(
                openai.embeddings.create(
                    input=[query_text],
                    model="text-embedding-3-small",
                )
                .data[0]
                .embedding,
                dtype="float32",
            )
    except Exception:
        return ""

    try:
        denom = np.linalg.norm(vectors, axis=1) * np.linalg.norm(q_vec) + 1e-8
        scores = (vectors @ q_vec) / denom
        top_idx = scores.argsort()[::-1][:top_k]
    except Exception:
        return ""

    chunks: list[str] = []
    for i in top_idx:
        try:
            score = float(scores[i])
        except Exception:
            continue
        if score < 0.3:
            break
        try:
            entry = meta[int(i)]
            file_rel = entry.get("file")
            name = entry.get("name")
        except Exception:
            continue
        if not file_rel or not name:
            continue
        file_path = repo_root / file_rel
        try:
            src = file_path.read_text(errors="replace")
            tree = ast.parse(src)
        except (OSError, SyntaxError):
            continue
        for node in ast.walk(tree):
            if (
                isinstance(
                    node,
                    (ast.FunctionDef, ast.AsyncFunctionDef, ast.ClassDef),
                )
                and node.name == name
            ):
                seg = ast.get_source_segment(src, node) or ""
                if seg:
                    chunks.append(seg[:max_chars])
                break

    return "\n\n# ---\n\n".join(chunks)


__all__ = [
    "extract_codebase_context",
]
