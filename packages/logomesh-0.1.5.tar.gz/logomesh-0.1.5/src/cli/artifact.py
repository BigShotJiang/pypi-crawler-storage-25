"""Compliance artifact renderer.

Every `logomesh repro <url> --artifact` (or `--json`) call produces a
timestamped, control-mapped JSON envelope that ties the production
incident to the reproduced test run and the verdict on the current branch.

Control mappings (post-incident; verified against the published
control language, not inherited from CLAUDE.md):

  - SOC2 CC7.3 — "evaluate security events to determine whether they
    could or have resulted in a failure of the entity to meet its
    objectives." The deterministic repro IS that evaluation.
  - SOC2 CC7.4 — "respond to identified security incidents." The
    sealed test + draft PR + audit trail is the response evidence.
  - PCI DSS 12.10.5 — "specific incident response procedures are in
    place." The sealed envelope is the procedural artifact.

Note: PCI DSS 6.3.2 (which earlier docs referenced) covers
*pre-release* secure code review of bespoke software — i.e. before
the bug ships. This product fires *after* the bug hits prod, so 6.3.2
is the wrong control. Earlier marketing was incorrect; corrected here.

Auditors read this to satisfy "evidence that the fix actually fixes the
issue" — the missing artifact between Sentry and a passing PR check.
"""

from __future__ import annotations

import hashlib
import json
from datetime import datetime, timezone

from core.pii_redactor import redact_text


def render_artifact(
    exc,
    frame,
    result: dict,
    branch: str = "",
    commit: str = "",
    sandbox_mode: str = "docker",
    fix_diff: str = "",
    pr_url: str = "",
) -> dict:
    """Build the audit artifact dict.

    Args:
        exc: SentryException-like object (has issue_id, issue_url, error_type,
            error_message, last_seen, event_count).
        frame: SentryFrame-like object (filename, function, lineno).
        result: sandbox run result dict (success, total, failed, output...).
        branch: git branch the test ran against.
        commit: git commit SHA.
        sandbox_mode: actual execution mode, usually `docker` or `subprocess`.

    Returns:
        A dict serializable as JSON. Schema version 1.
    """
    total = int(result.get("total", 0) or 0)
    failed = int(result.get("failed", 0) or 0)

    # "Reproduced on this branch" = pytest reports failures.
    # "Fixed" = test ran and passed.
    if total == 0:
        repro_status = "could_not_run"
        verdict = "INCONCLUSIVE"
    elif failed > 0:
        repro_status = "still_reproduces"
        verdict = "NOT_FIXED"
    else:
        repro_status = "fixed"
        verdict = "FIXED"

    sandbox_desc = _describe_sandbox(sandbox_mode)

    artifact: dict = {
        "schema_version": "1",
        "generated_at": datetime.now(timezone.utc).isoformat(),
        "controls": [
            "SOC2-CC7.3",        # event evaluation
            "SOC2-CC7.4",        # incident response
            "PCI-DSS-4.0-12.10.5",  # incident response procedures
        ],
        "incident": {
            "sentry_issue_id": getattr(exc, "issue_id", ""),
            "sentry_url": getattr(exc, "issue_url", ""),
            "exception": getattr(exc, "error_type", ""),
            # error_message may contain PAN/PII — truncate and note it may be redacted
            "message": _scrub_message(getattr(exc, "error_message", "") or ""),
            "file": getattr(frame, "filename", "") or "",
            "function": getattr(frame, "function", "") or "",
            "line": int(getattr(frame, "lineno", 0) or 0),
            "last_seen": getattr(exc, "last_seen", "") or "",
            "event_count": int(getattr(exc, "event_count", 0) or 0),
        },
        "reproduction": {
            "status": repro_status,
            "sandbox": sandbox_desc,
            "branch_tested": branch,
            "commit": commit,
            "verdict": verdict,
            "tests_run": total,
            "tests_failed": failed,
        },
        "fix": {
            "pr_url": pr_url or None,
            "diff_sha256": hashlib.sha256(fix_diff.encode()).hexdigest() if fix_diff else None,
            "diff_lines": fix_diff.count("\n") if fix_diff else None,
        },
        "evidence_chain": _build_evidence_chain(exc, frame, repro_status, sandbox_desc, pr_url),
    }

    # Integrity checksum — SHA256 of the artifact content (excluding this field).
    # Auditors can verify the artifact has not been truncated or modified by
    # recomputing: sha256(json.dumps(artifact_without_hash, sort_keys=True)).
    artifact["artifact_sha256"] = hashlib.sha256(
        json.dumps(artifact, sort_keys=True, ensure_ascii=False).encode()
    ).hexdigest()

    return artifact


def _scrub_message(msg: str) -> str:
    """Scrub PAN/SSN/email/API key/JWT from the Sentry error message.

    Truncates to 500 chars first; redacted output may be slightly longer
    if placeholders are wider than the matches they replace, but the cap
    bounds total artifact size.
    """
    return redact_text(msg[:500]) if msg else ""


def _build_evidence_chain(exc, frame, status: str, sandbox_desc: str, pr_url: str = "") -> list[str]:
    err = getattr(exc, "error_type", "Exception")
    fname = getattr(frame, "filename", "") or "<unknown>"
    line = int(getattr(frame, "lineno", 0) or 0)
    count = int(getattr(exc, "event_count", 0) or 0)
    last_seen = getattr(exc, "last_seen", "") or "unknown"

    chain = [
        f"1. Production crash: {err} at {fname}:{line}",
        f"2. Occurred {count} time(s), last seen {last_seen}",
        f"3. Crash reproduced deterministically in {sandbox_desc}",
    ]
    if status == "fixed":
        chain.append("4. Fix branch tested: exception no longer raised")
        chain.append("5. Verdict: fix addresses root cause of production incident")
    elif status == "still_reproduces":
        chain.append("4. Fix branch tested: exception still raised")
        chain.append("5. Verdict: fix does NOT address root cause")
    else:
        chain.append("4. Fix branch tested: sandbox failed to collect/run the test")
        chain.append("5. Verdict: inconclusive — manual review required")
    if pr_url:
        chain.append(f"6. Fix PR: {pr_url}")
    return chain


def _describe_sandbox(mode: str) -> str:
    mode_norm = (mode or "").strip().lower()
    if mode_norm == "subprocess":
        return "Local subprocess fallback, not isolated"
    return "Docker python:3.12-slim, airgapped, nobody user"


def get_git_metadata(repo_path: str = ".") -> tuple[str, str]:
    """Return (branch, commit) for the given repo path. Best-effort, no raise."""
    import subprocess

    def _run(args: list[str]) -> str:
        try:
            r = subprocess.run(
                ["git", "-C", repo_path, *args],
                capture_output=True, text=True, timeout=5, check=False,
            )
            return r.stdout.strip() if r.returncode == 0 else ""
        except (OSError, subprocess.SubprocessError):
            return ""

    branch = _run(["rev-parse", "--abbrev-ref", "HEAD"])
    commit = _run(["rev-parse", "HEAD"])
    return branch, commit
