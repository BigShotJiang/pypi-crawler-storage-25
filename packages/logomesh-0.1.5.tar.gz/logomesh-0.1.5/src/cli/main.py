"""Top-level argparse dispatcher for the `logomesh` CLI."""

from __future__ import annotations

import argparse
import os
import sys
from pathlib import Path


def _bootstrap_path() -> None:
    """Make `business_logic`, `core`, etc. importable when run from a wheel
    install OR from a source checkout. Wheel installs put modules at the
    top level; source checkouts have them under src/."""
    here = Path(__file__).resolve()
    candidates = [here.parent.parent, here.parent.parent.parent / "src"]
    for p in candidates:
        if (p / "business_logic").exists() and str(p) not in sys.path:
            sys.path.insert(0, str(p))


_bootstrap_path()


def _load_env() -> None:
    """Load .env from CWD up to repo root if python-dotenv is installed.

    No hard dependency — if dotenv isn't present, env vars must come from
    the shell. Don't fail.
    """
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    cwd = Path.cwd()
    for p in [cwd, *cwd.parents]:
        env = p / ".env"
        if env.exists():
            load_dotenv(env, override=False)
            return
        if (p / ".git").exists():
            break  # repo root, stop walking


def main(argv: list[str] | None = None) -> int:
    _load_env()
    # Pretty logger output for interactive CLI use.
    os.environ.setdefault("LOGOMESH_LOG_PRETTY", "1")

    parser = argparse.ArgumentParser(
        prog="logomesh",
        description=(
            "Adversarial test runner for AI-generated Python code. "
            "Verifies your changes before commit."
        ),
    )
    parser.add_argument(
        "--version", action="version",
        version=_get_version(),
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    from cli.repro import add_subparser as add_repro

    add_repro(subparsers)
    # `init` previously wrote .claude/mcp.json pointing at a `logomesh
    # mcp-server` subcommand that does not exist. Removed 2026-05-08;
    # archive at logomesh_legacy/cli_legacy_init/init.py. MCP support
    # may return in v1.1+ once the host implementation lands.

    args = parser.parse_args(argv)
    return int(args.func(args) or 0)


def _get_version() -> str:
    try:
        from importlib.metadata import version
        return version("logomesh")
    except Exception:
        return "0.1.0"


if __name__ == "__main__":
    sys.exit(main())
