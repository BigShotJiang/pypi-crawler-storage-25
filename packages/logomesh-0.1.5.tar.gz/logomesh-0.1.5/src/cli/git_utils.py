"""Git helpers for the local CLI.

Pre-commit semantics: the developer just edited a file (themselves or via
Claude Code) and wants to verify the diff before `git commit`. So the
"base" is the file's content at HEAD and the "head" is the working tree.

If the file is untracked or no git repo is present, base is empty —
verify_file treats that as a brand-new file.
"""

from __future__ import annotations

import subprocess
from pathlib import Path


def get_repo_root(start: Path | None = None) -> Path | None:
    """Return the git repo root containing `start`, or None if not in a repo."""
    cwd = (start or Path.cwd()).resolve()
    try:
        out = subprocess.run(
            ["git", "-C", str(cwd), "rev-parse", "--show-toplevel"],
            capture_output=True, text=True, timeout=5,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return None
    if out.returncode != 0:
        return None
    return Path(out.stdout.strip())


def get_base_content(file_path: Path, base_ref: str = "HEAD") -> str:
    """Return the file's content at `base_ref`, or empty string if untracked.

    Raises nothing — file-not-in-revision returns "" so verify_file treats
    the change as a new file. That matches the working-tree semantics: if
    you just created the file, every line of it is "new".
    """
    repo_root = get_repo_root(file_path.parent)
    if repo_root is None:
        return ""
    try:
        rel = file_path.resolve().relative_to(repo_root)
    except ValueError:
        return ""
    try:
        out = subprocess.run(
            ["git", "-C", str(repo_root), "show", f"{base_ref}:{rel}"],
            capture_output=True, text=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return ""
    if out.returncode != 0:
        return ""
    return out.stdout


def get_repo_relative_path(file_path: Path) -> str:
    """Return file's path relative to the repo root, or its name as fallback."""
    repo_root = get_repo_root(file_path.parent)
    if repo_root is None:
        return file_path.name
    try:
        return str(file_path.resolve().relative_to(repo_root))
    except ValueError:
        return file_path.name


def get_staged_python_files() -> list[Path]:
    """Return paths of staged Python files (added/copied/modified)."""
    repo_root = get_repo_root()
    if repo_root is None:
        return []
    try:
        out = subprocess.run(
            ["git", "-C", str(repo_root), "diff", "--cached",
             "--name-only", "--diff-filter=ACM"],
            capture_output=True, text=True, timeout=10,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired):
        return []
    if out.returncode != 0:
        return []
    paths = []
    for line in out.stdout.splitlines():
        line = line.strip()
        if not line.endswith(".py"):
            continue
        full = repo_root / line
        if full.exists():
            paths.append(full)
    return paths
