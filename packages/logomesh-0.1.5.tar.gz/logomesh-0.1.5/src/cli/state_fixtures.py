"""State-file → SQLite + mocks fixture builder.

Reads a `.logomesh/crashes/<event_id>.json` written by the `logomesh-capture`
SDK on the production server, materializes it into a SQLite database and
mock dicts the sandbox can use to replay the request deterministically.

See docs/strategy/implementation_repro.md (Agent B) and the State File Schema
section for the JSON contract.
"""

from __future__ import annotations

import json
import sqlite3
import tempfile
from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class StateBundle:
    """Materialized production state at crash time, ready for sandbox replay."""

    raw: dict
    sqlite_path: Path | None = None      # seeded SQLite file or None
    redis_mock: dict = field(default_factory=dict)   # {key: value}
    http_mock: dict = field(default_factory=dict)    # {url: {status_code, body, headers}}
    request_context: dict = field(default_factory=dict)  # method/url/body/headers


def load_state_file(path: str | Path) -> StateBundle:
    """Load a state file written by logomesh-capture into a StateBundle.

    Raises:
        FileNotFoundError: state file missing.
        ValueError: malformed JSON or missing schema_version.
    """
    p = Path(path)
    if not p.is_file():
        raise FileNotFoundError(f"state file not found: {path}")
    try:
        data = json.loads(p.read_text())
    except json.JSONDecodeError as e:
        raise ValueError(f"state file is not valid JSON: {e}") from e

    if not isinstance(data, dict) or "schema_version" not in data:
        raise ValueError(
            f"state file missing 'schema_version' (got: {type(data).__name__})"
        )

    return StateBundle(
        raw=data,
        sqlite_path=_seed_sqlite(data.get("db_queries", []) or []),
        redis_mock=_build_redis_mock(data.get("redis_ops", []) or []),
        http_mock=_build_http_mock(data.get("http_calls", []) or []),
        request_context=data.get("request", {}) or {},
    )


def _seed_sqlite(queries: list[dict]) -> Path | None:
    """Build a temp SQLite DB from captured DB rows. Best-effort.

    Each captured query has columns + rows + a tables[] hint. We CREATE TABLE
    IF NOT EXISTS for each unique table seen, then INSERT OR IGNORE its rows.
    All columns typed as TEXT — the sandbox replay only needs to read them
    back; type fidelity is not the goal at v1.
    """
    if not queries:
        return None
    tmp = Path(tempfile.mktemp(suffix=".db"))
    try:
        conn = sqlite3.connect(str(tmp))
        try:
            for q in queries:
                cols = q.get("columns") or []
                rows = q.get("rows") or []
                tables = q.get("table_names") or []
                if not cols or not rows or not tables:
                    continue
                table = str(tables[0]).replace('"', "").replace(";", "").strip()
                if not table:
                    continue
                col_defs = ", ".join(f'"{c}" TEXT' for c in cols)
                conn.execute(
                    f'CREATE TABLE IF NOT EXISTS "{table}" ({col_defs})'
                )
                placeholders = ", ".join("?" * len(cols))
                # Coerce row values to strings — JSON booleans / nulls / numbers
                # all round-trip fine through TEXT.
                stringified = [
                    [None if v is None else str(v) for v in row]
                    for row in rows
                    if isinstance(row, (list, tuple)) and len(row) == len(cols)
                ]
                if stringified:
                    conn.executemany(
                        f'INSERT OR IGNORE INTO "{table}" VALUES ({placeholders})',
                        stringified,
                    )
            conn.commit()
        finally:
            conn.close()
        return tmp
    except sqlite3.Error:
        try:
            tmp.unlink(missing_ok=True)
        except OSError:
            pass
        return None


def _build_redis_mock(ops: list[dict]) -> dict:
    """Flatten captured Redis read ops into a {key: value} dict.

    Only GET/HGET round-trip cleanly into the simple key→value mock the
    rendered test uses. Other read types (HGETALL, LRANGE, etc.) are kept
    in the raw state but skipped here.
    """
    mock: dict = {}
    for op in ops or []:
        cmd = str(op.get("cmd", "")).upper()
        if cmd in ("GET", "HGET"):
            key = op.get("key")
            if key:
                mock[key] = op.get("result")
    return mock


def _build_http_mock(calls: list[dict]) -> dict:
    """Flatten captured HTTP calls into a {url: {...}} mock dict."""
    mock: dict = {}
    for call in calls or []:
        url = call.get("url")
        if not url:
            continue
        mock[url] = {
            "status_code": call.get("status_code", 200),
            "body": call.get("response_body", ""),
            "headers": call.get("response_headers", {}) or {},
        }
    return mock


def render_mock_setup(bundle: StateBundle | None) -> str:
    """Return Python source the generated test should prepend.

    The rendered code defines `_REDIS_MOCK`, `_HTTP_MOCK`, `_SQLITE_PATH`
    constants and patches `redis.Redis.get` if redis state was captured.
    The LLM is instructed (via prompt rules) to USE these names rather than
    re-import or re-define mocks.
    """
    if bundle is None:
        return ""

    lines = ["import unittest.mock as _mock", ""]

    if bundle.redis_mock:
        lines.append(f"_REDIS_MOCK = {bundle.redis_mock!r}")
        lines.append(
            "_redis_patch = _mock.patch('redis.Redis.get', "
            "side_effect=lambda key: _REDIS_MOCK.get(key))"
        )
        lines.append("")

    if bundle.http_mock:
        lines.append(f"_HTTP_MOCK = {bundle.http_mock!r}")
        lines.append("# httpx mock available via respx or unittest.mock")
        lines.append("")

    if bundle.sqlite_path is not None:
        # Sandbox copies state.db into /workspace alongside target.py.
        lines.append('_SQLITE_PATH = "state.db"')
        lines.append("# patch Django/SQLAlchemy to use SQLite state DB if needed")
        lines.append("")

    return "\n".join(lines)
