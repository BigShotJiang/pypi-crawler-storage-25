"""logomesh CLI — daily pre-commit verification for AI-generated code.

Subcommands:
  logomesh check [files...]   verify working-tree changes vs HEAD
  logomesh init               write .claude/mcp.json + setup
  logomesh mcp-server         stdio MCP server for Claude Code

Run `logomesh <command> --help` for details.
"""
