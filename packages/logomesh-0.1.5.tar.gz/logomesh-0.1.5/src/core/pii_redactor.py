"""PII / secret redaction for the logomesh repro path.

Compliance contract (data handling, distinct from the artifact's
incident-response controls): frame locals from Sentry events must be
redacted before any LLM sees them, before they appear in generated
test code, and before they're stamped into the compliance artifact.

  - PCI DSS 4.0 §3.4 — render PAN unreadable wherever it is stored,
    transmitted, or processed.
  - PCI DSS 4.0 §3.5 — protect cryptographic keys / secrets used to
    secure account data.
  - SOC2 CC6.7 — restrict transmission, movement, and removal of
    information to authorized internal/external users + processes.

(The artifact ENVELOPE itself maps to SOC2 CC7.3 + CC7.4 + PCI DSS
12.10.5 — incident response. Different control family, same
compliance package.)

This module is the single source of truth. Other modules
(``oracles/sentry_replay.py``, ``cli/artifact.py``, ``core/audit_log.py``,
``business_logic/sandbox/__init__.py``) delegate to it.

Properties:

* **Idempotent.** ``redact_text(redact_text(s)) == redact_text(s)``.
  Lets us safely call it at multiple chokepoints without double-redacting
  anything.
* **Deterministic.** Same input → same output, no random salts. Audit
  hashes over redacted bytes are reproducible across runs.
* **Typed placeholders.** ``[REDACTED:PAN]`` / ``[REDACTED:SSN]`` /
  ``[REDACTED:EMAIL]`` / ``[REDACTED:API_KEY]`` / ``[REDACTED:JWT]`` /
  ``[REDACTED:FIELD]``. Auditors can tell what was scrubbed and why.
* **Pure stdlib.** No third-party deps; safe to import from anywhere.

Field-name policy is intentionally *narrow* (exact-match plus
underscore/dash/dot token-split match) and value-side scrubbing
(Luhn-validated PAN) is the backstop. This keeps PCI-safe fields like
``card_last4`` from being over-redacted while still catching PANs hiding
in unexpected fields like ``user_card`` (caught by the Luhn-validated
regex on the value).
"""

from __future__ import annotations

import re
from typing import Any, Mapping


# ---------------------------------------------------------------------------
# Regexes
# ---------------------------------------------------------------------------

# Candidate PAN: 13–19 digits with optional space/dash separators between
# any digits. Validated with Luhn before redacting so we don't false-positive
# on long transaction ids or timestamps.
_DIGITS_PAN_CANDIDATE = re.compile(r"(?<!\d)(?:\d[ \-]?){12,18}\d(?!\d)")

_SSN = re.compile(r"\b\d{3}-\d{2}-\d{4}\b")

# RFC 5322-lite. Doesn't try to validate the full grammar — just the
# common-case ``local@domain.tld`` shape.
_EMAIL = re.compile(
    r"\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b"
)

# Known API-key prefixes seen in production fintech codebases.
# Conservative: each alternative requires the prefix AND a length floor so
# we don't false-positive on incidental tokens. Order matters only for
# performance — alternation tries left-to-right.
_API_KEY = re.compile(
    r"\b("
    r"sk_(?:test|live)_[A-Za-z0-9]{16,}"           # Stripe secret
    r"|pk_(?:test|live)_[A-Za-z0-9]{16,}"          # Stripe publishable
    r"|rk_(?:test|live)_[A-Za-z0-9]{16,}"          # Stripe restricted
    r"|whsec_[A-Za-z0-9]{16,}"                     # Stripe webhook signing
    r"|sk-[A-Za-z0-9]{20,}"                        # OpenAI / Anthropic
    r"|ghp_[A-Za-z0-9]{36,}"                       # GitHub personal token
    r"|gho_[A-Za-z0-9]{36,}"                       # GitHub OAuth
    r"|ghu_[A-Za-z0-9]{36,}"                       # GitHub user-to-server
    r"|ghs_[A-Za-z0-9]{36,}"                       # GitHub server-to-server
    r"|ghr_[A-Za-z0-9]{36,}"                       # GitHub refresh
    r"|github_pat_[A-Za-z0-9_]{22,}"               # GitHub fine-grained PAT
    r"|xox[baprs]-[A-Za-z0-9-]{20,}"               # Slack bot/user/app
    r"|AKIA[A-Z0-9]{16}"                           # AWS access key id
    r"|ASIA[A-Z0-9]{16}"                           # AWS STS access key id
    r"|AIza[A-Za-z0-9_\-]{35}"                     # Google API key
    r")\b"
)

# JWT shape: three base64url segments joined by dots; first two start with
# ``eyJ`` (the base64 of ``{"``). Conservative — won't match malformed JWTs
# but also won't false-positive on free-form text.
_JWT = re.compile(
    r"\beyJ[A-Za-z0-9_\-]+\.eyJ[A-Za-z0-9_\-]+\.[A-Za-z0-9_\-]+\b"
)

# Free-text ``key=value`` and ``key: value`` pairs. Used to scrub PII that
# arrives inside human-readable error messages — e.g.
# ``ValueError: amount invalid (partial_pan=4111111111114242)``. The PAN
# itself isn't always Luhn-valid (real production messages, fraud
# inputs, internal test data), but the field-name marker is unambiguous.
# Caller filters by ``is_sensitive_key`` so non-sensitive fields like
# ``card_last4=4242`` (PCI-allowed) are left alone.
#
# Value group has two alternatives so the regex consumes existing
# ``[REDACTED:KIND]`` placeholders whole — required for idempotency, and
# preserves more-specific type markers (a PAN already scrubbed by the
# Luhn pass shouldn't be downgraded to ``[REDACTED:FIELD]``).
_FIELD_VALUE = re.compile(
    r"\b([A-Za-z_][A-Za-z0-9_\-]*)\s*([=:])\s*"
    r"(\[REDACTED:[A-Z_]+\]|[^\s,)\];\"']+)"
)


# ---------------------------------------------------------------------------
# Field-name policy
# ---------------------------------------------------------------------------

# Names that are unconditionally sensitive. Match is case-insensitive and
# applied two ways: (1) exact match against the full key, (2) match against
# any token after splitting the key on ``_`` / ``-`` / ``.``.
#
# Deliberately *not* in this list:
#   - ``card`` alone (matches PCI-allowed ``card_last4``)
#   - ``cc`` alone (matches innocuous email "cc:" header field)
#   - ``id`` (too generic)
#
# A PAN hiding in a non-listed field is still caught by Luhn-validated
# value-side scrubbing.
_SENSITIVE_KEYS: frozenset[str] = frozenset({
    # Auth / secrets
    "password", "passwd", "pwd",
    "secret", "client_secret", "signing_secret", "webhook_secret",
    "token", "access_token", "refresh_token", "id_token", "oauth_token",
    "bearer", "auth", "authorization",
    "api_key", "apikey",
    "private_key", "ssh_key",
    "aws_access_key_id", "aws_secret_access_key",
    "stripe_secret_key", "stripe_api_key",
    # Payment card data
    "card_number", "cardnumber", "card_no", "cc_number",
    "credit_card", "debit_card", "pan", "primary_account_number",
    "cvv", "cvc", "card_cvc", "security_code",
    # PII
    "ssn", "tax_id", "national_id",
    "email", "email_address", "phone", "phone_number",
})

_FIELD_TOKEN_SPLIT = re.compile(r"[_\-.\s]+")


def is_sensitive_key(key: object) -> bool:
    """Field-name policy: exact match plus token-split match.

    ``user_email`` → tokens ``["user", "email"]`` → ``email`` matches.
    ``card_last4`` → tokens ``["card", "last4"]`` → no match (PCI allows
    last4 to be stored).
    ``billing-card_number`` → tokens ``["billing", "card", "number"]`` →
    adjacent pair ``card_number`` matches.
    """
    if not isinstance(key, str):
        return False
    k = key.strip().lower().lstrip("_")
    if not k:
        return False
    if k in _SENSITIVE_KEYS:
        return True
    tokens = [t for t in _FIELD_TOKEN_SPLIT.split(k) if t]
    for i, tok in enumerate(tokens):
        if tok in _SENSITIVE_KEYS:
            return True
        # Adjacent-pair check covers compound names like
        # ``billing-card_number`` → pair ``card_number`` is in the list,
        # while neither token alone is.
        if i + 1 < len(tokens):
            pair = f"{tok}_{tokens[i + 1]}"
            if pair in _SENSITIVE_KEYS:
                return True
    return False


# ---------------------------------------------------------------------------
# Luhn
# ---------------------------------------------------------------------------

def luhn_valid(digits: str) -> bool:
    """Standard Luhn checksum. ``digits`` must already be ASCII digit-only."""
    n = len(digits)
    if n < 13 or n > 19:
        return False
    total = 0
    parity = n % 2
    for i, ch in enumerate(digits):
        if not ch.isdigit():
            return False
        d = ord(ch) - 48
        if i % 2 == parity:
            d *= 2
            if d > 9:
                d -= 9
        total += d
    return total % 10 == 0


def _redact_pan(text: str) -> str:
    def _sub(m: re.Match) -> str:
        digits = re.sub(r"\D", "", m.group(0))
        if luhn_valid(digits):
            return "[REDACTED:PAN]"
        return m.group(0)
    return _DIGITS_PAN_CANDIDATE.sub(_sub, text)


def _redact_field_value_pairs(text: str) -> str:
    """Free-text ``sensitive_key=value`` scrubber.

    Catches PII inside human-readable error messages where the field name
    is unambiguous but the value isn't Luhn-valid (or is too short for the
    PAN regex). Idempotent: the value-group alternation matches an
    existing ``[REDACTED:KIND]`` placeholder whole, and we early-return so
    a more-specific marker (e.g. ``[REDACTED:PAN]``) survives intact.
    """
    def _sub(m: re.Match) -> str:
        key, sep, val = m.group(1), m.group(2), m.group(3)
        if val.startswith("[REDACTED:") and val.endswith("]"):
            return m.group(0)
        if is_sensitive_key(key):
            return f"{key}{sep}[REDACTED:FIELD]"
        return m.group(0)
    return _FIELD_VALUE.sub(_sub, text)


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def redact_text(s: object) -> object:
    """Scrub PII / secrets from a single string. Idempotent.

    Non-string inputs pass through unchanged so callers can use this as a
    universal scrubber on heterogeneous values.

    Order matters: API-key prefixes and JWTs get processed first to avoid
    a stray ``sk_test_…`` being clobbered by the field-value pass; PAN /
    SSN / email next; ``key=value`` field-name redaction runs last so
    everything earlier had a chance to act on the value before the
    field-name marker overwrote it.
    """
    if not isinstance(s, str) or not s:
        return s
    out = _JWT.sub("[REDACTED:JWT]", s)
    out = _API_KEY.sub("[REDACTED:API_KEY]", out)
    out = _redact_pan(out)
    out = _SSN.sub("[REDACTED:SSN]", out)
    out = _EMAIL.sub("[REDACTED:EMAIL]", out)
    out = _redact_field_value_pairs(out)
    return out


def redact_value(v: Any) -> Any:
    """Recursive value scrubber. Preserves type when no PII is found.

    * ``str`` → scrubbed string (or original if no match).
    * ``Mapping`` → ``redact_mapping`` (field-name + recursive value scrub).
    * ``list`` / ``tuple`` → recursed element-wise; type preserved.
    * Anything else: ``str(v)`` is scrubbed; if a match is found the value
      is replaced with the scrubbed string (so a ``Decimal("4111…")`` that
      Luhn-validates as a PAN can't slip through unchanged); otherwise the
      original value is returned.
    """
    if isinstance(v, str):
        return redact_text(v)
    if isinstance(v, Mapping):
        return redact_mapping(v)
    if isinstance(v, list):
        return [redact_value(x) for x in v]
    if isinstance(v, tuple):
        return tuple(redact_value(x) for x in v)
    if v is None or isinstance(v, (bool, int, float, bytes)):
        # Primitives get a stringification probe so PAN-shaped Decimals or
        # bytes-of-digits don't slip through. Return as-is when clean.
        try:
            s = str(v) if not isinstance(v, bytes) else v.decode("utf-8", "replace")
        except Exception:
            return v
        scrubbed = redact_text(s)
        return scrubbed if scrubbed != s else v
    # Fallback: stringify, scrub, return scrubbed string only on match.
    try:
        s = str(v)
    except Exception:
        return v
    scrubbed = redact_text(s)
    return scrubbed if scrubbed != s else v


def redact_mapping(data: Mapping[Any, Any]) -> dict:
    """Field-name policy + recursive value scrub."""
    if not isinstance(data, Mapping):
        return data  # type: ignore[return-value]
    out: dict = {}
    for k, v in data.items():
        if is_sensitive_key(k):
            out[k] = "[REDACTED:FIELD]"
            continue
        out[k] = redact_value(v)
    return out
