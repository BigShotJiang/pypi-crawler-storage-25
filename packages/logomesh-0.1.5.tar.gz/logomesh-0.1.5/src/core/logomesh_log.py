"""
Structured JSON logging for logomesh.

All modules import `log` from here instead of using print().
Output is newline-delimited JSON — easy to grep, easy to ship to any log aggregator.

Usage:
    from core.logomesh_log import log
    log.info("scorer", "pipeline started", repo="pallets/flask", pr=42)
    log.error("sandbox", "docker unavailable", error=str(e))
"""

import json
import logging
import os
import sys
import traceback
from datetime import datetime, timezone


def _now() -> str:
    return datetime.now(timezone.utc).isoformat()


class _StructuredLogger:
    """Wraps Python logging with a JSON-line output format."""

    def __init__(self):
        self._logger = logging.getLogger("logomesh")
        self._logger.setLevel(logging.DEBUG)

        handler = logging.StreamHandler(sys.stdout)
        handler.setFormatter(_JsonFormatter())
        self._logger.addHandler(handler)
        self._logger.propagate = False

    def _emit(self, level: str, component: str, message: str, **fields):
        record = {
            "time": _now(),
            "level": level,
            "component": component,
            "msg": message,
            **fields,
        }
        line = json.dumps(record, default=str)
        if level == "error":
            self._logger.error(line)
        elif level == "warn":
            self._logger.warning(line)
        else:
            self._logger.info(line)

    def info(self, component: str, message: str, **fields):
        self._emit("info", component, message, **fields)

    def warn(self, component: str, message: str, **fields):
        self._emit("warn", component, message, **fields)

    def error(self, component: str, message: str, **fields):
        self._emit("error", component, message, **fields)

    def exception(self, component: str, message: str, **fields):
        self._emit("error", component, message, traceback=traceback.format_exc(), **fields)


class _JsonFormatter(logging.Formatter):
    """Pass-through by default; optional human-friendly formatting for local runs."""

    def __init__(self):
        super().__init__()
        self._pretty = os.getenv("LOGOMESH_LOG_PRETTY", "0").lower() in {
            "1",
            "true",
            "yes",
            "on",
        }

    def format(self, record: logging.LogRecord) -> str:
        msg = record.getMessage()
        if not self._pretty:
            return msg
        try:
            payload = json.loads(msg)
        except Exception:
            return msg

        ts = str(payload.get("time", ""))
        if "T" in ts:
            ts = ts.split("T", 1)[1][:8]
        level = str(payload.get("level", "info")).upper()
        component = str(payload.get("component", "app"))
        text = str(payload.get("msg", ""))

        extras = []
        for key in sorted(payload.keys()):
            if key in {"time", "level", "component", "msg"}:
                continue
            value = payload[key]
            if value in (None, "", [], {}):
                continue
            extras.append(f"{key}={value}")

        suffix = f" | {' '.join(extras)}" if extras else ""
        return f"[{ts}] {level:5s} {component:<12} {text}{suffix}"


log = _StructuredLogger()
