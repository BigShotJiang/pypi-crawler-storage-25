"""Supabase client for business data (installations, usage_log).

Env vars required:
    SUPABASE_URL  — project URL, e.g. https://xyz.supabase.co
      OR SUPABASE_PROJECT_REF=xyz (auto-expands to https://xyz.supabase.co)
    SUPABASE_SERVICE_KEY or SUPABASE_SERVICE_ROLE_KEY
      — service role key (bypasses RLS)

If either env var is missing, all methods are no-ops and log a warning once.
Gated by ENABLE_SUPABASE=1 (default on).
"""
from __future__ import annotations

import os
import time
from typing import Any

try:
    from logomesh_log import log
except ImportError:
    class _FallbackLog:
        def info(self, *a, **kw): pass
        def warn(self, *a, **kw): pass
        def error(self, *a, **kw): pass
    log = _FallbackLog()

_warned = False
_client = None


def _enabled() -> bool:
    return os.getenv("ENABLE_SUPABASE", "1").lower() not in ("0", "false", "off")


def _supabase_url() -> str:
    direct = os.getenv("SUPABASE_URL", "").strip()
    if direct:
        return direct
    project_ref = os.getenv("SUPABASE_PROJECT_REF", "").strip()
    return f"https://{project_ref}.supabase.co" if project_ref else ""


def _service_key() -> str:
    return (
        os.getenv("SUPABASE_SERVICE_KEY", "").strip()
        or os.getenv("SUPABASE_SERVICE_ROLE_KEY", "").strip()
    )


def _use_memory() -> bool:
    return os.getenv("LOGOMESH_DEV_MEMORY_BACKEND", "").lower() in ("1", "true", "yes")


def _get_client():
    """Return an object exposing Supabase's `.table(name).select/upsert/...`
    chainable query API, or None when business data persistence is fully
    disabled.

    When Supabase URL/service key env vars are unset, falls back to a
    process-local in-memory shim with the same chainable shape. This
    keeps `npm run dev` + `uvicorn` working without a Supabase project
    so a developer can drive the wizard end-to-end. Production deploys
    set the real env vars; the shim is dev-only.

    To force the in-memory backend on (e.g. for tests that
    intentionally don't want Supabase), set LOGOMESH_DEV_MEMORY_BACKEND=1.
    """
    global _client, _warned
    if not _enabled():
        return None
    url, key = _supabase_url(), _service_key()
    if _use_memory() or (not url or not key):
        if not _warned and not _use_memory():
            missing: list[str] = []
            if not url:
                missing.append("SUPABASE_URL/SUPABASE_PROJECT_REF")
            if not key:
                missing.append("SUPABASE_SERVICE_KEY/SUPABASE_SERVICE_ROLE_KEY")
            missing_bits = " + ".join(missing) if missing else "supabase config"
            log.warn(
                "supabase",
                f"{missing_bits} unset — using in-memory dev backend",
            )
            _warned = True
        if _client is None or not isinstance(_client, _InMemoryClient):
            _client = _InMemoryClient()
        return _client
    if _client is None or isinstance(_client, _InMemoryClient):
        try:
            from supabase import create_client
            _client = create_client(url, key)
        except Exception as e:
            log.error("supabase", "client init failed", error=str(e))
            return None
    return _client


# ---------------------------------------------------------------------------
# In-memory shim — dev fallback when Supabase isn't configured.
# Implements the subset of the supabase-py query builder we actually use:
#   .table(name).select(...).eq(k,v).order(col, desc=).limit(n).execute()
#   .table(name).upsert(payload).execute()
#   .table(name).insert(payload).execute()
#   .table(name).update(payload).eq(...).execute()
#   .table(name).delete().eq(...).execute()
# ---------------------------------------------------------------------------

class _Result:
    def __init__(self, data, count=None):
        self.data = data
        self.count = count


class _MemoryQuery:
    def __init__(self, table_name: str, store: dict[str, list[dict[str, Any]]]):
        self._table = table_name
        self._store = store
        self._mode = None
        self._payload = None
        self._eq: list[tuple[str, Any]] = []
        self._desc = False
        self._limit_n: int | None = None
        self._count_mode = None

    # builders
    def select(self, *_a, count=None, **_kw):
        self._mode = "select"
        self._count_mode = count
        return self

    def upsert(self, payload):
        self._mode = "upsert"
        self._payload = payload
        return self

    def insert(self, payload):
        self._mode = "insert"
        self._payload = payload
        return self

    def update(self, payload):
        self._mode = "update"
        self._payload = payload
        return self

    def delete(self):
        self._mode = "delete"
        return self

    def eq(self, k, v):
        self._eq.append((k, v))
        return self

    def gte(self, *_a, **_kw):
        return self

    def order(self, _col, desc=False):
        self._desc = bool(desc)
        return self

    def limit(self, n):
        self._limit_n = int(n)
        return self

    # utils
    def _filter(self, rows: list[dict[str, Any]]) -> list[dict[str, Any]]:
        for k, v in self._eq:
            rows = [r for r in rows if r.get(k) == v]
        return rows

    def _pk_field(self, payload: dict[str, Any]) -> str:
        # We only ever insert into 4 tables — pick the right PK column.
        if self._table == "runs":
            return "run_id"
        return "installation_id"

    # terminal
    def execute(self):
        rows = self._store.setdefault(self._table, [])
        if self._mode == "upsert":
            p = self._payload
            pk = self._pk_field(p)
            existing = next((r for r in rows if r.get(pk) == p.get(pk)), None)
            if existing is not None:
                existing.update(p)
                return _Result([existing])
            rows.append(dict(p))
            return _Result([rows[-1]])
        if self._mode == "insert":
            p = self._payload
            rows.append(dict(p))
            return _Result([rows[-1]])
        if self._mode == "update":
            matched = self._filter(rows)
            for r in matched:
                r.update(self._payload)
            return _Result(matched)
        if self._mode == "delete":
            matched = self._filter(rows)
            keep = [r for r in rows if r not in matched]
            self._store[self._table] = keep
            return _Result(matched)
        if self._mode == "select":
            matched = self._filter(rows)
            matched = sorted(
                matched,
                key=lambda r: r.get("created_at", "") or "",
                reverse=self._desc,
            )
            if self._limit_n is not None:
                matched = matched[: self._limit_n]
            return _Result(matched, count=len(matched))
        raise RuntimeError(f"_MemoryQuery: unhandled mode {self._mode}")


class _InMemoryClient:
    """Process-local Supabase substitute. Lives for the lifetime of
    the python process; restart wipes data. Logs once at first use so
    operators don't ship to prod on this by accident.
    """

    def __init__(self):
        self._store: dict[str, list[dict[str, Any]]] = {}
        log.warn(
            "supabase", "using in-memory backend — DO NOT use in production",
        )

    def table(self, name: str) -> _MemoryQuery:
        return _MemoryQuery(name, self._store)


# Reset the global memory store between tests if needed.
def _reset_memory_for_tests() -> None:
    global _client
    if isinstance(_client, _InMemoryClient):
        _client._store.clear()


def upsert_installation(installation_id: str, owner: str = "", account_type: str = "organization") -> None:
    client = _get_client()
    if client is None:
        return
    try:
        row = {
            "installation_id": installation_id,
            "deleted_at": None,
        }
        if owner:
            row["owner"] = owner
        if account_type:
            row["account_type"] = account_type
        client.table("installations").upsert(row).execute()
        log.info("supabase", "installation upserted", installation_id=installation_id, owner=owner)
    except Exception as e:
        log.error("supabase", "upsert_installation failed", error=str(e))


def purge_installation(installation_id: str) -> None:
    client = _get_client()
    if client is None:
        return
    try:
        from datetime import datetime, timezone
        client.table("installations").update({
            "deleted_at": datetime.now(timezone.utc).isoformat(),
        }).eq("installation_id", installation_id).execute()
        log.info("supabase", "installation marked deleted", installation_id=installation_id)
    except Exception as e:
        log.error("supabase", "purge_installation failed", error=str(e))


def log_usage(
    installation_id: str,
    owner: str,
    repo: str,
    pull_number: int,
    file_count: int,
    findings_count: int,
    tokens_in: int,
    tokens_out: int,
    cost_usd: float,
    sandbox_mode: str = "unknown",
) -> None:
    client = _get_client()
    if client is None:
        return
    try:
        client.table("usage_log").insert({
            "installation_id": installation_id,
            "owner": owner,
            "repo": repo,
            "pull_number": pull_number,
            "file_count": file_count,
            "findings_count": findings_count,
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "cost_usd": cost_usd,
            "sandbox_mode": sandbox_mode,
        }).execute()
    except Exception as e:
        log.error("supabase", "log_usage failed", error=str(e))


def get_usage_summary(days: int = 30) -> list[dict[str, Any]]:
    """Return per-installation usage totals for the last N days."""
    client = _get_client()
    if client is None:
        return []
    try:
        from datetime import datetime, timezone, timedelta
        since = (datetime.now(timezone.utc) - timedelta(days=days)).isoformat()
        result = client.table("usage_log").select(
            "installation_id, owner, repo"
        ).gte("ran_at", since).execute()
        # Aggregate in Python (Supabase free tier has no RPC needed for this)
        agg: dict[int, dict] = {}
        for row in result.data or []:
            iid = row["installation_id"]
            if iid not in agg:
                agg[iid] = {"installation_id": iid, "owner": row["owner"], "runs": 0,
                             "files": 0, "findings": 0, "tokens_in": 0, "tokens_out": 0, "cost_usd": 0.0}
            agg[iid]["runs"] += 1
        return list(agg.values())
    except Exception as e:
        log.error("supabase", "get_usage_summary failed", error=str(e))
        return []
