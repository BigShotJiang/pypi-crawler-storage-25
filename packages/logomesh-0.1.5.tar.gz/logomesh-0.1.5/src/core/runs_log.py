"""Per-run records for the wizard dashboard.

One row in `runs` per orchestrator dispatch — feeds:
    GET /api/installations/{id}/runs              recent run history
    GET /api/installations/{id}/runs/{run_id}/artifact   sealed envelope

Aggregation (cost-per-day, etc.) lives in `usage_log`. This table is
the wizard's primary source-of-truth and the audit trail for the
dashboard's "what happened" panel.
"""
from __future__ import annotations

import uuid
from datetime import datetime, timezone
from typing import Any

try:
    from logomesh_log import log  # type: ignore
except ImportError:
    class _FallbackLog:
        def info(self, *a, **kw): pass
        def warn(self, *a, **kw): pass
        def error(self, *a, **kw): pass
    log = _FallbackLog()


def _now_iso() -> str:
    return datetime.now(timezone.utc).isoformat()


def create_pending_run(
    installation_id: str, sentry_issue_id: str,
) -> str:
    """Insert a `status='in_progress'` row up-front so the wizard's
    POST /test endpoint can return a real run_id immediately. The
    orchestrator updates it on completion via `record_run_finished`.

    Returns the new run_id (caller-generated UUID for predictable
    inserts when Supabase is offline).
    """
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    run_id = str(uuid.uuid4())
    if client is None:
        return run_id
    try:
        client.table("runs").insert({
            "run_id": run_id,
            "installation_id": installation_id,
            "sentry_issue_id": sentry_issue_id,
            "status": "in_progress",
            "created_at": _now_iso(),
        }).execute()
    except Exception as e:
        log.warn("runs_log", "create_pending_run failed", error=str(e),
                 installation_id=installation_id)
    return run_id


def record_run_finished(
    run_id: str | None,
    *,
    installation_id: str,
    sentry_issue_id: str,
    result: dict[str, Any],
) -> None:
    """Persist the orchestrator result into `runs`.

    `run_id` may be None when the run originated from an inbound Sentry
    webhook (no UI-side pre-insert) — we generate one here. The wizard's
    `/test` flow inserts a pending row first and passes that run_id.
    """
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return

    artifact = result.get("artifact") or {}
    seal = (artifact.get("evidence_path_seal") or {}) if isinstance(artifact, dict) else {}
    usage = result.get("usage") or {}
    rid = run_id or str(uuid.uuid4())

    row = {
        "run_id": rid,
        "installation_id": installation_id,
        "sentry_issue_id": sentry_issue_id,
        "status": result.get("status", "error"),
        "verified_exception_match": seal.get("verified_exception_match"),
        "sandbox_exception_type": seal.get("sandbox_exception_type"),
        "expected_exception_type": seal.get("expected_exception_type"),
        "duration_s": result.get("duration_s"),
        "pr_url": result.get("pr_url") or None,
        "sentry_comment_url": result.get("sentry_comment_url") or None,
        "test_sha256_first16": seal.get("test_sha256_first16"),
        "needs_human_review": bool(result.get("needs_human_review")),
        "human_review_reason": result.get("human_review_reason") or None,
        "cost_usd": usage.get("cost_usd"),
        "tokens_in": usage.get("tokens_in"),
        "tokens_out": usage.get("tokens_out"),
        "artifact": artifact if isinstance(artifact, dict) else None,
        "finished_at": _now_iso(),
    }
    try:
        # Upsert so the wizard's pre-inserted pending row gets updated
        # in place rather than creating a duplicate.
        client.table("runs").upsert(row).execute()
    except Exception as e:
        log.error("runs_log", "record_run_finished failed",
                  installation_id=installation_id, error=str(e))


def list_runs(installation_id: str, *, limit: int = 20) -> list[dict[str, Any]]:
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return []
    try:
        result = client.table("runs").select(
            "run_id, installation_id, sentry_issue_id, status, "
            "verified_exception_match, sandbox_exception_type, "
            "expected_exception_type, duration_s, pr_url, "
            "sentry_comment_url, test_sha256_first16, created_at"
        ).eq("installation_id", installation_id).order(
            "created_at", desc=True,
        ).limit(max(1, min(limit, 200))).execute()
    except Exception as e:
        log.error("runs_log", "list_runs failed", error=str(e))
        return []
    rows = result.data or []
    return [
        {
            "id": r.get("run_id"),
            "created_at": r.get("created_at"),
            "sentry_issue_id": r.get("sentry_issue_id"),
            "status": r.get("status"),
            "verified_exception_match": r.get("verified_exception_match"),
            "sandbox_exception_type": r.get("sandbox_exception_type"),
            "expected_exception_type": r.get("expected_exception_type"),
            "duration_s": r.get("duration_s"),
            "pr_url": r.get("pr_url"),
            "sentry_comment_url": r.get("sentry_comment_url"),
            "test_sha256_first16": r.get("test_sha256_first16"),
        }
        for r in rows
    ]


def get_run_artifact(installation_id: str, run_id: str) -> dict | None:
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return None
    try:
        result = client.table("runs").select("artifact").eq(
            "installation_id", installation_id,
        ).eq("run_id", run_id).limit(1).execute()
    except Exception as e:
        log.error("runs_log", "get_run_artifact failed", error=str(e))
        return None
    rows = result.data or []
    if not rows:
        return None
    return rows[0].get("artifact") or None


def count_runs(installation_id: str) -> int:
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return 0
    try:
        result = client.table("runs").select(
            "run_id", count="exact",
        ).eq("installation_id", installation_id).execute()
        return int(getattr(result, "count", 0) or 0)
    except Exception as e:
        log.warn("runs_log", "count_runs failed", error=str(e))
        return 0
