"""Per-repo configuration — `.logomesh.toml` at the repo root.

Lets developers tell logomesh three things it cannot guess well:

1. Which Python packages to install in the sandbox (fixes the "native
   dependency unavailable" degradation seen on the self-review PR, where
   27 of 28 findings dropped to analysis-based because openai / pydantic
   weren't in the sandbox image).
2. Which paths to focus on vs skip (CLI plumbing and legacy code should
   not be attacked by the adversarial lane; billing / pricing / auth
   modules should be).
3. Hard invariants on specific functions (bypasses LLM inference for
   contracts the developer already knows — highest-confidence signal).

Schema is TOML so we use stdlib `tomllib` (no new runtime dep).

Example `.logomesh.toml`:

    version = 1
    deps = ["openai", "pydantic", "stripe"]
    focus = ["src/billing/**", "src/pricing/**"]
    skip = ["src/legacy/**"]
    framework = "fastapi"

    [[invariants]]
    function = "apply_discount"
    returns = ">= 0"

    [[invariants]]
    function = "estimate_monthly_revenue"
    returns = "dict with 'total' key; total >= 0"

    [output]
    max_findings_per_pr = 5
    silent_on_clean = true
"""

from __future__ import annotations

import fnmatch
import os
from dataclasses import dataclass, field
from pathlib import Path

try:
    import tomllib  # Python 3.11+ stdlib
except ImportError:  # pragma: no cover - we require 3.11+
    import tomli as tomllib  # type: ignore


CONFIG_FILENAME = ".logomesh.toml"

_DEFAULT_SKIP_GLOBS = (
    "tests/**", "**/tests/**",
    "scripts/**", "**/scripts/**",
    "migrations/**", "**/migrations/**",
    "src/cli/**", "cli/**",
    "src/mcp_server/**", "mcp_server/**",
    "**/conftest.py",
    "**/__main__.py",
)


@dataclass
class Invariant:
    """A user-declared function contract. Bypasses LLM inference."""
    function: str
    returns: str = ""              # e.g. ">= 0", "non-None", "len > 0"
    args: str = ""                 # e.g. "x >= 0, y not None"
    description: str = ""          # free-form elaboration if needed


@dataclass
class LogomeshConfig:
    """Parsed `.logomesh.toml`. All fields have working defaults so a
    repo without a config file behaves the same as before."""
    version: int = 1
    deps: list[str] = field(default_factory=list)
    focus: list[str] = field(default_factory=list)
    skip: list[str] = field(default_factory=list)
    framework: str = ""
    invariants: list[Invariant] = field(default_factory=list)
    max_findings_per_pr: int = 0    # 0 = no cap
    silent_on_clean: bool = False

    @property
    def effective_skip(self) -> list[str]:
        """User skip globs merged with our defaults."""
        return list(self.skip) + list(_DEFAULT_SKIP_GLOBS)

    def should_verify(self, file_path: str) -> bool:
        """True if `file_path` should be attacked by the adversarial lane.

        - If `focus` is set, file must match at least one focus glob.
        - File must not match any skip glob (user + defaults).
        """
        normalized = file_path.replace("\\", "/")
        if self.focus and not any(
            _matches(normalized, pat) for pat in self.focus
        ):
            return False
        if any(_matches(normalized, pat) for pat in self.effective_skip):
            return False
        return True

    def invariants_for(self, func_name: str) -> list[Invariant]:
        """Hard contracts the user declared for this function."""
        return [inv for inv in self.invariants if inv.function == func_name]

    def render_invariants_prompt(self) -> str:
        """Render all invariants as a text block for the generator LLM.

        Returned string is injected into the generator's `pr_context` so
        the model treats these as hard facts, not hypotheses to infer.
        """
        if not self.invariants:
            return ""
        lines = ["The following function contracts are declared by the repo maintainer. "
                 "Treat them as hard requirements — generate adversarial inputs that "
                 "would violate them."]
        for inv in self.invariants:
            parts = [f"- `{inv.function}`"]
            if inv.args:
                parts.append(f"args: {inv.args}")
            if inv.returns:
                parts.append(f"returns: {inv.returns}")
            if inv.description:
                parts.append(inv.description)
            lines.append("  " + "; ".join(parts))
        return "\n".join(lines)


def load(repo_root: Path | str | None = None) -> LogomeshConfig:
    """Load `.logomesh.toml` from `repo_root` (or CWD if not given).

    Missing file → returns a default LogomeshConfig (no-op behavior).
    Malformed file → ValueError with a line-oriented error message.
    """
    root = Path(repo_root) if repo_root else Path.cwd()
    path = root / CONFIG_FILENAME
    if not path.exists():
        return LogomeshConfig()
    try:
        data = tomllib.loads(path.read_text(encoding="utf-8"))
    except tomllib.TOMLDecodeError as e:
        raise ValueError(f"{path}: invalid TOML — {e}") from e
    return from_dict(data)


def from_dict(data: dict) -> LogomeshConfig:
    """Build a LogomeshConfig from a plain dict.

    Kept separate from `load()` so tests can construct configs without
    writing files.  Validates types and rejects unknown top-level keys
    so typos (`dep` vs `deps`) do not silently no-op.
    """
    allowed = {"version", "deps", "focus", "skip", "framework",
               "invariants", "output"}
    unknown = set(data) - allowed
    if unknown:
        raise ValueError(
            f"unknown .logomesh.toml keys: {sorted(unknown)} "
            f"(allowed: {sorted(allowed)})"
        )

    version = int(data.get("version", 1))
    if version != 1:
        raise ValueError(f"unsupported .logomesh.toml version: {version}")

    cfg = LogomeshConfig(
        version=version,
        deps=_str_list(data.get("deps", []), "deps"),
        focus=_str_list(data.get("focus", []), "focus"),
        skip=_str_list(data.get("skip", []), "skip"),
        framework=_str(data.get("framework", ""), "framework"),
    )

    for i, raw in enumerate(data.get("invariants", [])):
        if not isinstance(raw, dict):
            raise ValueError(f"invariants[{i}]: expected table, got {type(raw).__name__}")
        func = raw.get("function", "")
        if not isinstance(func, str) or not func:
            raise ValueError(f"invariants[{i}]: 'function' is required and must be a string")
        inv = Invariant(
            function=func,
            returns=_str(raw.get("returns", ""), f"invariants[{i}].returns"),
            args=_str(raw.get("args", ""), f"invariants[{i}].args"),
            description=_str(raw.get("description", ""), f"invariants[{i}].description"),
        )
        cfg.invariants.append(inv)

    output = data.get("output", {})
    if not isinstance(output, dict):
        raise ValueError("[output] must be a table")
    cfg.max_findings_per_pr = int(output.get("max_findings_per_pr", 0))
    cfg.silent_on_clean = bool(output.get("silent_on_clean", False))
    if cfg.max_findings_per_pr < 0:
        raise ValueError("output.max_findings_per_pr must be >= 0")
    return cfg


def requirements_from_deps(deps: list[str]) -> dict[str, str]:
    """Convert `config.deps` into the dict shape `Sandbox.run_dependency_aware`
    expects — one synthetic `requirements.txt` file.

    This is the smallest-viable hook into the existing sandbox install path.
    If the repo has real dependency manifests (pyproject.toml, setup.py)
    those should be passed separately; this layer is additive.
    """
    if not deps:
        return {}
    body = "\n".join(s.strip() for s in deps if s.strip()) + "\n"
    return {"requirements.txt": body}


# ---- helpers ----

def _matches(path: str, pattern: str) -> bool:
    """Glob-match supporting `**` as a path-segment wildcard."""
    if "**" in pattern:
        # fnmatch's * doesn't cross /, but `**` should. Expand `**` → `*`
        # and use a path-aware compare.
        return fnmatch.fnmatchcase(path, pattern.replace("**", "*"))
    return fnmatch.fnmatchcase(path, pattern)


def _str_list(value, field_name: str) -> list[str]:
    if not isinstance(value, list):
        raise ValueError(f"{field_name} must be a list of strings")
    out: list[str] = []
    for i, item in enumerate(value):
        if not isinstance(item, str):
            raise ValueError(f"{field_name}[{i}] must be a string, got {type(item).__name__}")
        out.append(item)
    return out


def _str(value, field_name: str) -> str:
    if not isinstance(value, str):
        raise ValueError(f"{field_name} must be a string, got {type(value).__name__}")
    return value
