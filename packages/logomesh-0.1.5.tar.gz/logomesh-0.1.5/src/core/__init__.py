"""Local CLI orchestration. Reuses the same pipeline components as the
GitHub App webhook via `core.pipeline.verify_file`.
"""
