"""Session-level audit logging for logomesh repro.

Records every significant action in a repro run: LLM synthesis calls, sandbox
executions, file writes, and dep resolutions. PII and secrets are redacted
automatically. The rendered log can be embedded in the compliance artifact.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import time
from pathlib import Path
from typing import Any

from core.pii_redactor import redact_text

_AUDIT_LOG_DIR = Path(
    os.getenv(
        "LOGOMESH_AUDIT_LOG_DIR",
        os.path.expanduser("~/.cache/logomesh/session_audit"),
    )
)


def _scrub(text: str) -> str:
    """Delegate to the canonical redactor.

    Kept as a private wrapper so internal call sites stay readable; if a
    new redaction primitive needs adding, do it in
    ``core.pii_redactor.redact_text``, not here.
    """
    return redact_text(text) if isinstance(text, str) else text


def _hash16(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8", errors="replace")).hexdigest()[:16]


def _check_intent_alignment(intent: str, response: str) -> bool:
    """Return True if key nouns from intent appear in response.

    Heuristic: majority (>50%) of intent words longer than 4 chars must appear
    in the response. Best-effort signal — not a hard security guarantee.
    Fail-open on empty inputs.
    """
    if not intent or not response:
        return True
    words = {w.lower() for w in re.split(r"\W+", intent) if len(w) > 4}
    if not words:
        return True
    response_lower = response.lower()
    hits = sum(1 for w in words if w in response_lower)
    return hits >= max(1, (len(words) + 1) // 2)


class AuditSession:
    """Accumulates structured audit events for one repro run.

    Usage::

        session = AuditSession("repro-1234567")
        session.log_llm_call(intent="synthesize pytest", model="gpt-5-mini",
                             prompt=prompt_text, response=response_text)
        session.log_sandbox_run(intent="verify crash", files=files, result=result)
        artifact["session_audit"] = session.render()
        session.flush_to_disk()
    """

    def __init__(self, session_id: str = "") -> None:
        self._session_id = session_id or f"repro-{int(time.time())}"
        self._events: list[dict] = []
        self._start_ts = time.time()

    # ------------------------------------------------------------------
    # Logging methods
    # ------------------------------------------------------------------

    def log_llm_call(
        self,
        intent: str,
        model: str,
        prompt: str,
        response: str,
        tokens_in: int = 0,
        tokens_out: int = 0,
    ) -> None:
        aligned = _check_intent_alignment(intent, response)
        self._events.append({
            "event": "llm_call",
            "ts": time.time(),
            "intent": _scrub(intent),
            "model": model,
            "prompt_hash": _hash16(prompt),
            "response_hash": _hash16(response),
            "tokens_in": tokens_in,
            "tokens_out": tokens_out,
            "intent_aligned": aligned,
        })

    def log_file_write(self, intent: str, path: str, content: str) -> None:
        self._events.append({
            "event": "file_write",
            "ts": time.time(),
            "intent": _scrub(intent),
            "path": path,
            "content_sha256": _hash16(content),
            "bytes": len(content.encode("utf-8", errors="replace")),
        })

    def log_dep_resolution(
        self,
        intent: str,
        name: str,
        version: str,
        pypi_url: str = "",
        sha256: str = "",
    ) -> None:
        self._events.append({
            "event": "dep_resolution",
            "ts": time.time(),
            "intent": _scrub(intent),
            "name": name,
            "version": version,
            "pypi_url": pypi_url,
            "sha256": sha256,
        })

    def log_sandbox_run(
        self, intent: str, files: dict[str, Any], result: dict
    ) -> None:
        self._events.append({
            "event": "sandbox_run",
            "ts": time.time(),
            "intent": _scrub(intent),
            "files": sorted(k for k in files.keys()),
            "tests_run": result.get("total", 0),
            "tests_failed": result.get("failed", 0),
            "sandbox_mode": result.get("sandbox_mode", ""),
        })

    # ------------------------------------------------------------------
    # Output
    # ------------------------------------------------------------------

    def render(self) -> dict:
        """Return the session audit log as a dict for embedding in artifact."""
        return {
            "session_id": self._session_id,
            "start_ts": self._start_ts,
            "duration_s": round(time.time() - self._start_ts, 2),
            "event_count": len(self._events),
            "events": self._events,
        }

    def flush_to_disk(self) -> None:
        """Write session events to disk as JSONL for long-term storage."""
        try:
            _AUDIT_LOG_DIR.mkdir(parents=True, exist_ok=True)
            log_path = _AUDIT_LOG_DIR / f"{self._session_id}.jsonl"
            with open(log_path, "w", encoding="utf-8") as f:
                for event in self._events:
                    f.write(json.dumps(event) + "\n")
        except Exception as e:
            import sys
            print(f"[logomesh] audit log flush failed: {e}", file=sys.stderr)
