"""Responses API adapter exposing the subset of AsyncOpenAI the pipeline uses.

Wraps client.responses.create() so call sites keep .chat.completions.create(...)
and response.choices[0].message.content. Required for models that only support
v1/responses (e.g. gpt-5.1-codex-mini).
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Any

from openai import AsyncOpenAI

_RESPONSES_ONLY_MODELS: frozenset[str] = frozenset({
    "gpt-5.1-codex-mini",
    "codex-mini-latest",
})

_RESPONSES_ONLY_PREFIXES: tuple[str, ...] = (
    "gpt-5.1-codex",
    "codex-",
    "o1-pro",
)


def requires_responses_api(model: str) -> bool:
    if model in _RESPONSES_ONLY_MODELS:
        return True
    return any(model.startswith(p) for p in _RESPONSES_ONLY_PREFIXES)


@dataclass
class _Message:
    content: str


@dataclass
class _Choice:
    message: _Message


@dataclass
class _Response:
    choices: list[_Choice]


class _Completions:
    def __init__(self, client: AsyncOpenAI) -> None:
        self._client = client

    async def create(
        self,
        *,
        model: str,
        messages: list[dict],
        reasoning_effort: str | None = None,
        **_ignored: Any,
    ) -> _Response:
        kwargs: dict[str, Any] = {
            "model": model,
            "input": messages,
            "store": False,
        }
        if reasoning_effort:
            kwargs["reasoning"] = {"effort": reasoning_effort}

        resp = await self._client.responses.create(**kwargs)

        text: str = getattr(resp, "output_text", None) or ""
        if not text:
            for item in getattr(resp, "output", []):
                if getattr(item, "type", "") == "message":
                    for block in getattr(item, "content", []):
                        if getattr(block, "type", "") == "output_text":
                            text = block.text or ""
                            break
                if text:
                    break

        return _Response(choices=[_Choice(message=_Message(content=text))])


class _Chat:
    def __init__(self, client: AsyncOpenAI) -> None:
        self.completions = _Completions(client)


class ResponsesAPIAdapter:
    """chat.completions-shaped wrapper that routes to the Responses API endpoint."""

    def __init__(self, api_key: str, base_url: str | None = None, timeout: float = 30.0) -> None:
        self._client = AsyncOpenAI(api_key=api_key, base_url=base_url, timeout=timeout)
        self.chat = _Chat(self._client)
