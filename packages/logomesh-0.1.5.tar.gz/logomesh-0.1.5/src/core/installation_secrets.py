"""Per-installation secrets — encrypted at rest.

Why this exists:
    Pilot v0 read every secret (Sentry token, GitHub token, OpenAI key,
    Slack webhook URL) from process env vars. That works for one
    customer; it does not work the moment a second installation lands,
    because we'd need to redeploy with a new env to onboard them. Worse,
    it makes "rotate the GitHub token for installation 4242 only"
    impossible.

Encryption strategy:
    Preferred: Supabase Vault / pgcrypto column-level encryption — the
    DB never sees plaintext. As of 2026-05-08 the project's Supabase
    instance does NOT have Vault enabled, so we use a pragmatic
    fallback: app-side AES-256-GCM with a master key from env. Ciphertext
    + nonce + tag are stored as a single base64 blob; decrypt happens
    only inside this process, only when we need the secret to make an
    outbound call. The DB sees opaque bytes.

    Migrating to Vault later is a swap of `encrypt_value` /
    `decrypt_value` — the storage row layout stays the same (a string
    column per secret) so a backfill job can re-encrypt in place.

Master key:
    LOGOMESH_MASTER_KEY = base64-encoded 32 bytes (urlsafe_b64). Generate:
        python -c "import os, base64; print(base64.urlsafe_b64encode(os.urandom(32)).decode())"

    The key is required to encrypt OR decrypt. Missing key → every
    secret is treated as unset (env fallback kicks in for callers).
    Rotating the key requires re-encrypting every row; that's a
    deliberate operation, not something we paper over silently.

Secrets schema (`installation_secrets` table):
    installation_id        bigint  PRIMARY KEY (FK installations.installation_id)
    sentry_auth_token      text    nullable, encrypted
    sentry_client_secret   text    nullable, encrypted  ← HMAC verify
    github_token           text    nullable, encrypted
    openai_api_key         text    nullable, encrypted
    slack_webhook_url      text    nullable, encrypted
    repo_path              text    nullable, plaintext  ← filesystem path, not secret
    created_at             timestamptz default now()
    updated_at             timestamptz default now()
    rotated_at             timestamptz nullable

DDL kept in `migrations/0001_installation_secrets.sql` so customers
self-hosting can apply it.
"""
from __future__ import annotations

import base64
import os
import time
from dataclasses import dataclass, field
from typing import Any, Iterable

try:
    from logomesh_log import log  # type: ignore
except ImportError:
    class _FallbackLog:
        def info(self, *a, **kw): pass
        def warn(self, *a, **kw): pass
        def error(self, *a, **kw): pass
    log = _FallbackLog()


# ---------------------------------------------------------------------------
# AES-256-GCM at the column-blob layer.
# ---------------------------------------------------------------------------

# Lazy import — `cryptography` is in deps but we don't want module-import
# time to fail in environments that strip it. The actual call sites raise.
def _aesgcm():
    from cryptography.hazmat.primitives.ciphers.aead import AESGCM  # type: ignore
    return AESGCM


# Distinguishes our blob from accidentally-stored plaintext or a future
# vault-prefixed value. Versioned so we can rotate cipher / migrate.
_BLOB_PREFIX = "lmsec-v1:"
_NONCE_BYTES = 12  # GCM standard


def _master_key_bytes() -> bytes | None:
    raw = os.environ.get("LOGOMESH_MASTER_KEY", "").strip()
    if not raw:
        return None
    try:
        # accept either urlsafe-b64 or hex (operators sometimes paste hex)
        if len(raw) == 64:
            return bytes.fromhex(raw)
        return base64.urlsafe_b64decode(raw + "=" * (-len(raw) % 4))
    except Exception as e:
        log.error("installation_secrets", "bad LOGOMESH_MASTER_KEY", error=str(e))
        return None


def encrypt_value(plaintext: str) -> str:
    """Encrypt a plaintext secret. Returns a base64-encoded blob.

    Output format: `lmsec-v1:<urlsafe-b64(nonce || ciphertext || tag)>`
    where AESGCM produces ciphertext+tag concatenated. The nonce is
    randomly generated per call (never reuse with the same key).

    Raises RuntimeError if `LOGOMESH_MASTER_KEY` is not set — callers
    must decide whether to refuse the write or skip storage entirely.
    """
    if plaintext is None:
        raise ValueError("encrypt_value: plaintext is None")
    key = _master_key_bytes()
    if key is None or len(key) != 32:
        raise RuntimeError(
            "LOGOMESH_MASTER_KEY missing or wrong length (expected 32 bytes "
            "urlsafe-b64 or 64 hex chars)"
        )
    nonce = os.urandom(_NONCE_BYTES)
    ct = _aesgcm()(key).encrypt(nonce, plaintext.encode("utf-8"), associated_data=None)
    blob = nonce + ct
    return _BLOB_PREFIX + base64.urlsafe_b64encode(blob).decode("ascii")


def decrypt_value(blob: str) -> str:
    """Decrypt a blob produced by `encrypt_value`. Returns plaintext.

    Returns empty string on any failure (missing key, malformed blob,
    auth-tag mismatch). Caller falls back to env var.
    """
    if not blob or not blob.startswith(_BLOB_PREFIX):
        return ""
    key = _master_key_bytes()
    if key is None or len(key) != 32:
        return ""
    try:
        raw = base64.urlsafe_b64decode(blob[len(_BLOB_PREFIX):])
        nonce, ct = raw[:_NONCE_BYTES], raw[_NONCE_BYTES:]
        pt = _aesgcm()(key).decrypt(nonce, ct, associated_data=None)
        return pt.decode("utf-8")
    except Exception as e:
        log.warn("installation_secrets", "decrypt_value failed",
                 reason=type(e).__name__)
        return ""


def is_encrypted(value: str | None) -> bool:
    return bool(value and value.startswith(_BLOB_PREFIX))


# ---------------------------------------------------------------------------
# Storage facade.
# ---------------------------------------------------------------------------

# The set of fields treated as encrypted secrets. `repo_path` is plaintext
# (a filesystem path, not a credential) and lives in the same row for
# operational convenience.
SECRET_FIELDS: tuple[str, ...] = (
    "sentry_auth_token",
    "sentry_client_secret",
    "github_token",
    "openai_api_key",
    "slack_webhook_url",
)
PLAINTEXT_FIELDS: tuple[str, ...] = ("repo_path", "github_repo")


@dataclass
class InstallationSecrets:
    """Decrypted secret bundle for one installation.

    All fields are plaintext by the time you hold this object — never
    persist or log it. The webhook layer constructs one of these per
    incoming request, hands it down through the orchestrator state,
    and lets it fall out of scope when the run finishes.
    """
    installation_id: str
    sentry_auth_token: str = ""
    sentry_client_secret: str = ""
    github_token: str = ""
    github_repo: str = ""
    openai_api_key: str = ""
    slack_webhook_url: str = ""
    repo_path: str = ""

    def as_redacted_dict(self) -> dict[str, Any]:
        """For audit log / API responses — masks every secret value."""
        out: dict[str, Any] = {
            "installation_id": self.installation_id,
            "repo_path": self.repo_path,
            "github_repo": self.github_repo,
        }
        for f in SECRET_FIELDS:
            v = getattr(self, f, "") or ""
            out[f] = _mask(v)
        return out


def _mask(s: str) -> str:
    if not s:
        return ""
    if len(s) <= 8:
        return "***"
    return f"{s[:4]}…{s[-2:]}"


# ---------------------------------------------------------------------------
# Supabase-backed CRUD.
# ---------------------------------------------------------------------------

def upsert_installation_secrets(
    installation_id: str,
    *,
    sentry_auth_token: str | None = None,
    sentry_client_secret: str | None = None,
    github_token: str | None = None,
    github_repo: str | None = None,
    openai_api_key: str | None = None,
    slack_webhook_url: str | None = None,
    repo_path: str | None = None,
) -> bool:
    """Encrypt + write secrets for `installation_id`. Returns True on
    success.

    Only fields passed explicitly are updated — `None` means "leave
    untouched". Empty string clears the field (encrypted blob of "").
    """
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        log.warn("installation_secrets", "supabase disabled — skipping write",
                 installation_id=installation_id)
        return False

    row: dict[str, Any] = {
        "installation_id": installation_id,
        "updated_at": _now_iso(),
    }
    rotated = False
    for fname, value in [
        ("sentry_auth_token", sentry_auth_token),
        ("sentry_client_secret", sentry_client_secret),
        ("github_token", github_token),
        ("openai_api_key", openai_api_key),
        ("slack_webhook_url", slack_webhook_url),
    ]:
        if value is None:
            continue
        try:
            row[fname] = encrypt_value(value) if value else ""
            rotated = True
        except RuntimeError as e:
            log.error("installation_secrets", "encrypt failed",
                      field=fname, error=str(e))
            return False
    if repo_path is not None:
        row["repo_path"] = repo_path
    if github_repo is not None:
        row["github_repo"] = github_repo
    if rotated:
        row["rotated_at"] = _now_iso()

    try:
        client.table("installation_secrets").upsert(row).execute()
        return True
    except Exception as e:
        log.error("installation_secrets", "upsert failed",
                  installation_id=installation_id, error=str(e))
        return False


def fetch_installation_secrets(installation_id: str) -> InstallationSecrets | None:
    """Read + decrypt secrets for `installation_id`. Returns None if
    not found OR Supabase is disabled.

    Decryption failures (bad key, tampered ciphertext) yield empty
    strings for that field — callers fall back to env vars rather
    than crashing the run.
    """
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return None
    try:
        result = client.table("installation_secrets").select(
            "*"
        ).eq("installation_id", installation_id).limit(1).execute()
    except Exception as e:
        log.error("installation_secrets", "fetch failed",
                  installation_id=installation_id, error=str(e))
        return None
    rows = result.data or []
    if not rows:
        return None
    row = rows[0]
    return InstallationSecrets(
        installation_id=str(row.get("installation_id", installation_id)),
        sentry_auth_token=decrypt_value(row.get("sentry_auth_token") or ""),
        sentry_client_secret=decrypt_value(row.get("sentry_client_secret") or ""),
        github_token=decrypt_value(row.get("github_token") or ""),
        github_repo=row.get("github_repo") or "",
        openai_api_key=decrypt_value(row.get("openai_api_key") or ""),
        slack_webhook_url=decrypt_value(row.get("slack_webhook_url") or ""),
        repo_path=row.get("repo_path") or "",
    )


def delete_installation_secrets(installation_id: str) -> bool:
    """Hard-delete the secrets row. The `installations` row is preserved
    (call `purge_installation` separately for soft-delete)."""
    from core.supabase_client import _get_client  # type: ignore
    client = _get_client()
    if client is None:
        return False
    try:
        client.table("installation_secrets").delete().eq(
            "installation_id", installation_id,
        ).execute()
        return True
    except Exception as e:
        log.error("installation_secrets", "delete failed",
                  installation_id=installation_id, error=str(e))
        return False


def _now_iso() -> str:
    from datetime import datetime, timezone
    return datetime.now(timezone.utc).isoformat()


# ---------------------------------------------------------------------------
# Resolver — secrets WITH env-var fallback.
#
# Order of precedence per field:
#   1. installation_secrets row (if installation_id provided AND key set)
#   2. process env (legacy single-tenant behaviour)
#   3. empty string
#
# The webhook layer calls this once per request and threads the result
# through. The orchestrator and downstream comment-posting modules
# accept an optional `InstallationSecrets` parameter; if absent they
# fall back to env reads exactly as before. Solo-CLI usage still works.
# ---------------------------------------------------------------------------

_ENV_FALLBACK: dict[str, str] = {
    "sentry_auth_token":    "LOGOMESH_SENTRY_AUTH_TOKEN",
    "sentry_client_secret": "LOGOMESH_SENTRY_CLIENT_SECRET",
    "github_token":         "GITHUB_TOKEN",
    "openai_api_key":       "OPENAI_API_KEY",
    "slack_webhook_url":    "LOGOMESH_SLACK_WEBHOOK_URL",
    "repo_path":            "LOGOMESH_REPO_PATH",
}


def resolve_secrets(installation_id: str | None) -> InstallationSecrets:
    """Build an `InstallationSecrets` for the given installation.

    Looks up Supabase row first, fills missing fields from env. Always
    returns a struct (never None) so callers can attribute-access
    without guarding.
    """
    sec = None
    if installation_id:
        sec = fetch_installation_secrets(str(installation_id))
    if sec is None:
        sec = InstallationSecrets(installation_id=str(installation_id or ""))
    for fname, env_name in _ENV_FALLBACK.items():
        if not getattr(sec, fname, ""):
            setattr(sec, fname, os.environ.get(env_name, "").strip())
    if not sec.github_repo:
        sec.github_repo = os.environ.get("GITHUB_REPO", "").strip()
    return sec
