"""Per-pipeline LLM token accumulator + budget enforcement.

Lifecycle per orchestrator run:
    reset_usage()                         # at handle_sentry_webhook entry
    add_usage(in, out, model=...)         # called by every LLM adapter
    check_budget()                        # raises TokenBudgetExceeded if over
    tin, tout = get_usage()               # at finalizer / log_usage call
    cost = estimate_cost_usd(tin, tout, model=...)

Budgets are read from env on every check (no caching) so pilots can
tune via webhook payload without restart.

    LOGOMESH_TOKEN_BUDGET_IN     default 200_000   tokens
    LOGOMESH_TOKEN_BUDGET_OUT    default  40_000   tokens
    LOGOMESH_USD_BUDGET          default 1.00      dollars per run
"""
from __future__ import annotations

import os
from contextvars import ContextVar
from typing import Any

# CRITICAL: store a mutable dict in the ContextVar (not the ints directly).
# asyncio Tasks copy their parent's context at creation; writes in child
# tasks don't propagate back. LangGraph runs each node in a sub-task, so
# `add_usage` calls from inside the graph would never reach the parent.
# A shared mutable reference works: every task sees the same dict object
# and mutations are visible everywhere. The ContextVar still gives us
# per-pipeline isolation (each handle_sentry_webhook call binds its own).
_DEFAULT: dict[str, Any] = {"tokens_in": 0, "tokens_out": 0, "model": ""}
_ctx: ContextVar[dict[str, Any]] = ContextVar("usage_state", default=_DEFAULT)


class TokenBudgetExceeded(RuntimeError):
    """Raised when a per-run token or cost budget is exhausted.

    The orchestrator catches this and routes to human_review with a
    structured reason instead of letting the LangGraph loop spin.
    """


def reset_usage() -> None:
    """Bind a fresh mutable state dict for this pipeline run.

    Call once at the entry point (handle_sentry_webhook). All child
    tasks/nodes will see the same dict and mutate it via add_usage.
    """
    _ctx.set({"tokens_in": 0, "tokens_out": 0, "model": ""})


def add_usage(tokens_in: int, tokens_out: int, model: str = "") -> None:
    state = _ctx.get()
    state["tokens_in"] += max(0, int(tokens_in or 0))
    state["tokens_out"] += max(0, int(tokens_out or 0))
    if model:
        state["model"] = model


def get_usage() -> tuple[int, int]:
    state = _ctx.get()
    return state["tokens_in"], state["tokens_out"]


def get_last_model() -> str:
    return _ctx.get().get("model", "")


# ---------------------------------------------------------------------------
# Cost table — public list prices, per 1M tokens, USD.
# Update as providers change pricing. Unknown models fall back to a
# conservative default (Sonnet baseline) so we over-estimate, never under.
# ---------------------------------------------------------------------------
_COST_TABLE: dict[str, tuple[float, float]] = {
    # OpenAI
    "gpt-5":          (1.25, 10.00),
    "gpt-5-mini":     (0.25,  2.00),
    "gpt-5-nano":     (0.05,  0.40),
    "gpt-4o":         (2.50, 10.00),
    "gpt-4o-mini":    (0.15,  0.60),
    "o3":             (2.00,  8.00),
    "o3-mini":        (1.10,  4.40),
    # Anthropic
    "claude-opus-4-7":     (15.00, 75.00),
    "claude-opus-4-6":     (15.00, 75.00),
    "claude-sonnet-4-6":    (3.00, 15.00),
    "claude-sonnet-4-5":    (3.00, 15.00),
    "claude-haiku-4-5":     (1.00,  5.00),
    # Local / self-hosted
    "qwen-coder":           (0.0,   0.0),
    "qwen3-coder-plus":     (0.0,   0.0),
}

_DEFAULT_RATE = (3.00, 15.00)  # claude-sonnet baseline (over-estimate, never under)


def _rate_for(model: str) -> tuple[float, float]:
    if not model:
        return _DEFAULT_RATE
    m = model.strip().lower()
    if m in _COST_TABLE:
        return _COST_TABLE[m]
    # Prefix match: "gpt-5-mini-2025-09-01" → "gpt-5-mini".
    for k in sorted(_COST_TABLE, key=len, reverse=True):
        if m.startswith(k):
            return _COST_TABLE[k]
    return _DEFAULT_RATE


def estimate_cost_usd(tokens_in: int, tokens_out: int, model: str = "") -> float:
    rate_in, rate_out = _rate_for(model or get_last_model())
    return round(
        tokens_in / 1_000_000 * rate_in
        + tokens_out / 1_000_000 * rate_out,
        6,
    )


# ---------------------------------------------------------------------------
# Budget enforcement.
# ---------------------------------------------------------------------------

def _budget_in() -> int:
    return int(os.getenv("LOGOMESH_TOKEN_BUDGET_IN", "200000"))


def _budget_out() -> int:
    return int(os.getenv("LOGOMESH_TOKEN_BUDGET_OUT", "40000"))


def _budget_usd() -> float:
    return float(os.getenv("LOGOMESH_USD_BUDGET", "1.00"))


def check_budget() -> None:
    """Raise `TokenBudgetExceeded` if any of the three caps is exceeded.

    Called by LLM adapters AFTER `add_usage`. Pre-call check would
    require a token count we don't have for the prompt yet; post-call
    is the cheapest correct point — worst case we overshoot by one
    completion before the loop terminates.
    """
    tin, tout = get_usage()
    bin_, bout = _budget_in(), _budget_out()
    if tin > bin_:
        raise TokenBudgetExceeded(
            f"input tokens {tin} > budget {bin_} (set LOGOMESH_TOKEN_BUDGET_IN)"
        )
    if tout > bout:
        raise TokenBudgetExceeded(
            f"output tokens {tout} > budget {bout} (set LOGOMESH_TOKEN_BUDGET_OUT)"
        )
    cost = estimate_cost_usd(tin, tout)
    cap = _budget_usd()
    if cost > cap:
        raise TokenBudgetExceeded(
            f"estimated cost ${cost:.4f} > budget ${cap:.2f} "
            "(set LOGOMESH_USD_BUDGET)"
        )


def usage_summary(model: str = "") -> dict:
    """Snapshot for embedding in artifact / comment / Supabase row."""
    tin, tout = get_usage()
    m = model or get_last_model()
    return {
        "tokens_in": tin,
        "tokens_out": tout,
        "model": m,
        "cost_usd": estimate_cost_usd(tin, tout, m),
        "budget_in": _budget_in(),
        "budget_out": _budget_out(),
        "budget_usd": _budget_usd(),
    }
