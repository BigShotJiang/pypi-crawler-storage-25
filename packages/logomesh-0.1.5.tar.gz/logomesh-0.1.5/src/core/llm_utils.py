"""Shared LLM utilities for temperature and model configuration."""

import hashlib
import os


def get_temperature_kwargs(default: float = 0.7, model: str = "") -> dict:
    """
    Return temperature kwargs for OpenAI API calls.

    Uses LLM_TEMPERATURE env var:
    - unset or "": uses the caller's default value (preserves determinism)
    - "skip": returns {} (let model use its own default, for models like gpt-5.2)
    - A number: returns {"temperature": float(value)}

    Reasoning models (gpt-5*, o1*, o3*) don't support custom temperature.
    """
    # reasoning models reject temperature != 1
    model_lower = model.lower()
    if any(model_lower.startswith(p) for p in ("gpt-5", "o1", "o3")):
        return {}

    env_val = os.getenv("LLM_TEMPERATURE", "").strip().lower()

    # Not set — use the caller's intended default (keeps deterministic scoring)
    if env_val == "":
        return {"temperature": default}

    # Explicitly skip temperature (for models that reject it like gpt-5.2)
    if env_val in ("skip", "none", "default"):
        return {}

    try:
        return {"temperature": float(env_val)}
    except ValueError:
        return {"temperature": default}


def get_reasoning_effort_kwargs(model: str, effort: str = "") -> dict:
    """
    Return reasoning_effort kwargs only for models that support it.

    ``effort`` forces a specific level ("minimal"/"low"/"medium"/"high").
    For OpenAI reasoning models (gpt-5*, o1*, o3*) we default to "minimal"
    to keep short verdict-style outputs inside ``max_completion_tokens``.
    Gemini supports "none" to skip thinking.
    """
    m = model.lower()
    if "gemini" in m:
        return {"reasoning_effort": effort or "none"}
    if any(m.startswith(p) for p in ("gpt-5", "o1", "o3")):
        if not effort:
            effort = os.getenv("LOGOMESH_REASONING_INFERENCE", "")
        if not effort or effort.lower() in ("none", "skip", "default"):
            return {}
        # gpt-5.x supports minimal/low/medium/high; older accept minimal too
        return {"reasoning_effort": effort}
    return {}


def get_max_tokens_kwargs(model: str, n: int) -> dict:
    """
    Return the correct token-limit parameter for the model.
    gpt-5-mini and newer OpenAI models use max_completion_tokens.
    Gemini and older models use max_tokens.

    For reasoning models (which generate internal thinking tokens before the
    visible reply), n=1 would be hit before the model outputs anything.
    Callers should pass a generous n (e.g. 500) and let the prompt constrain
    the actual output.
    """
    model_lower = model.lower()
    if "gemini" in model_lower or "claude" in model_lower:
        return {"max_tokens": n}
    return {"max_completion_tokens": n}


def get_seed_kwargs(content: str = "", *, model: str = "") -> dict:
    """Return a deterministic ``seed`` kwarg derived from ``content``.

    OpenAI chat completions accept a best-effort ``seed`` to reduce variance
    across identical requests. Gemini and Claude ignore it — we omit the
    kwarg for those models to avoid API errors.

    Same prompt → same seed. This lets validator / inference responses become
    stable-ish for replay runs, which matters for the A/B testing narrative
    (run 518 vs 519 vs 520 on identical payflow-api PR gave 1/0/3 findings
    — that's what this helper is trying to reduce).

    LOGOMESH_DISABLE_SEED=1 disables this helper entirely for experiments.
    """
    if os.getenv("LOGOMESH_DISABLE_SEED", "").lower() in ("1", "true", "on"):
        return {}
    m = model.lower()
    if "gemini" in m or "claude" in m:
        return {}
    if not content:
        return {}
    digest = hashlib.sha256(content.encode("utf-8", errors="replace")).digest()
    seed = int.from_bytes(digest[:4], "big") & 0x7FFFFFFF
    return {"seed": seed}


def get_tiered_model(tier: str, default_model: str = "") -> str:
    """Return the model for a pipeline tier, falling back to the default.

    Tiers:
    - ``inference``: property inference (strongest model, high reasoning)
    - ``validation``: finding validation (cheapest viable, binary verdict)
    - ``remediation``: fix/antifix generation (medium model)
    - ``semantic``: semantic reasoning pass — pure-LLM bug detection when execution unavailable.
      Falls back to the inference model if LOGOMESH_MODEL_SEMANTIC is not set.

    Env vars: LOGOMESH_MODEL_INFERENCE, LOGOMESH_MODEL_VALIDATION,
    LOGOMESH_MODEL_REMEDIATION, LOGOMESH_MODEL_SEMANTIC.  All fall back to OPENAI_MODEL then
    ``default_model``.
    """
    env_key = f"LOGOMESH_MODEL_{tier.upper()}"
    model = os.getenv(env_key, "").strip()
    if model:
        return model
    return default_model or os.getenv("OPENAI_MODEL", "gpt-5-mini")
