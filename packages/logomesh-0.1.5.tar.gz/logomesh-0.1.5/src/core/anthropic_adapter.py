"""Anthropic adapter exposing the subset of AsyncOpenAI the pipeline uses.

Wraps AsyncAnthropic so call sites keep `.chat.completions.create(...)` and
`response.choices[0].message.content`. Activated when LLM_PROVIDER=anthropic.

Target model: claude-haiku-4-5 (only supported model for this project).
"""

from __future__ import annotations

import asyncio
import os
from dataclasses import dataclass
from typing import Any

from anthropic import AsyncAnthropic

_MAX_CONCURRENCY = int(os.getenv("ANTHROPIC_MAX_CONCURRENCY", "3"))
_MAX_RETRIES = int(os.getenv("ANTHROPIC_MAX_RETRIES", "5"))
_semaphore = asyncio.Semaphore(_MAX_CONCURRENCY)


@dataclass
class _Message:
    content: str


@dataclass
class _Choice:
    message: _Message


@dataclass
class _Usage:
    prompt_tokens: int
    completion_tokens: int
    total_tokens: int


@dataclass
class _Response:
    choices: list[_Choice]
    usage: _Usage


def _split_system(messages: list[dict]) -> tuple[str | None, list[dict]]:
    system_parts: list[str] = []
    rest: list[dict] = []
    for m in messages:
        if m.get("role") == "system":
            c = m.get("content")
            if isinstance(c, str):
                system_parts.append(c)
            elif isinstance(c, list):
                system_parts.extend(b.get("text", "") for b in c if isinstance(b, dict))
        else:
            rest.append(m)
    return ("\n\n".join(system_parts) if system_parts else None), rest


class _Completions:
    def __init__(self, client: AsyncAnthropic) -> None:
        self._client = client

    async def create(
        self,
        *,
        model: str,
        messages: list[dict],
        max_tokens: int | None = None,
        max_completion_tokens: int | None = None,
        temperature: float | None = None,
        **_ignored: Any,
    ) -> _Response:
        system, msgs = _split_system(messages)

        kwargs: dict[str, Any] = {
            "model": model,
            "messages": msgs,
            "max_tokens": max_tokens or max_completion_tokens or 4096,
        }
        if system:
            kwargs["system"] = system
        if temperature is not None:
            kwargs["temperature"] = temperature

        async with _semaphore:
            resp = await self._client.messages.create(**kwargs)

        text = "".join(b.text for b in resp.content if getattr(b, "type", None) == "text")
        u = resp.usage
        try:
            from usage_tracker import add_usage as _add_usage
            _add_usage(u.input_tokens, u.output_tokens)
        except Exception:
            pass
        return _Response(
            choices=[_Choice(message=_Message(content=text))],
            usage=_Usage(
                prompt_tokens=u.input_tokens,
                completion_tokens=u.output_tokens,
                total_tokens=u.input_tokens + u.output_tokens,
            ),
        )


class _Chat:
    def __init__(self, client: AsyncAnthropic) -> None:
        self.completions = _Completions(client)


class AnthropicAdapter:
    """AsyncOpenAI-shaped wrapper around AsyncAnthropic."""

    def __init__(self, api_key: str, timeout: float = 30.0) -> None:
        self._client = AsyncAnthropic(api_key=api_key, timeout=timeout, max_retries=_MAX_RETRIES)
        self.chat = _Chat(self._client)
