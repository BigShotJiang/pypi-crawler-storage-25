# backward-compat shim — implementation moved to core.responses_adapter
from core.responses_adapter import *  # noqa: F401, F403
from core.responses_adapter import ResponsesAPIAdapter, requires_responses_api  # noqa: F401
