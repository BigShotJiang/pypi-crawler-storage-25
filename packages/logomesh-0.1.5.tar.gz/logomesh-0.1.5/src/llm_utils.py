# backward-compat shim — implementation moved to core.llm_utils
from core.llm_utils import *  # noqa: F401, F403
