# backward-compat shim — implementation moved to core.supabase_client
from core.supabase_client import *  # noqa: F401, F403
from core.supabase_client import upsert_installation, purge_installation, log_usage, get_usage_summary  # noqa: F401
