"""logomesh autonomous repro orchestrator (v2 — battle-tested core).

A LangGraph supervisor that plans, reasons, and uses tools to reproduce a
production crash from a Sentry event. The *evidence path* is sealed:
only `deterministic_repro` (zero-LLM, frame-locals → pytest) can produce
the JSON artifact and draft PR contents. All LLM reasoning, tool calls,
critic scores, memory lookups, and strategy outcomes flow into
`AuditSession` for SOC2 CC7.3 / CC7.4 / PCI DSS 12.10.5 review
(post-incident response controls; the legacy "6.3.2" mapping was
incorrect — that control covers pre-release secure code review of
bespoke software, not post-incident response).

Compliance contract (do not weaken):
    1. Final artifact + PR contain ONLY output from `deterministic_repro`.
    2. LLM-generated tests, refinements, and reasoning are advisory and
       are recorded in the audit session; they never replace the
       deterministic test in the artifact.
    3. The artifact preamble explicitly attests:
       "Repro generated deterministically from frame locals
        (zero LLM in evidence path). Agent reasoning provided for
        human review only."

═══════════════════════════════════════════════════════════════════════════
COMPONENTS REUSED FROM THE LOGOMESH AGENTBEATS COMPETITION REPO
(UC Berkeley RDI AgentBeats 2025 — 1st place, Software Testing Agent)
═══════════════════════════════════════════════════════════════════════════
1. `ReproMemory`       — adapted from `src/memory.py::BattleMemory`.
                         SQLite cross-run learning. Lessons keyed by crash
                         signature (error_type / function / file) instead
                         of competition `task_id`. Same 4 lesson types
                         (vulnerability → repro_failure, test_failure →
                         sandbox_failure, refinement → context_recovery,
                         scoring → fidelity). Same prompt-formatter API.

2. `ReproStrategyEvolver` — adapted from `src/strategy_evolver.py`.
                            UCB1 multi-armed bandit over 5 orchestration
                            strategies (locals_only, breadcrumb_heavy,
                            dep_check_first, context_reconstruct,
                            hypothesis_assist). Drives tool order +
                            critic strictness.

3. `ScientificContextEngine` — adapted from `src/green_logic/refinement_loop.py
                               ::ScientificMethodEngine`. Observe →
                               Hypothesize → Experiment → Verify, applied
                               to *why a repro fell short* rather than
                               vulnerability triage. Emits structured
                               ContextNotes for supervisor re-planning.
                               NEVER produces test code.

4. Sandbox             — the existing `business_logic.sandbox.Sandbox`
                         already implements the competition design
                         (tar-in-memory put_archive, no-network when
                         pytest pre-installed, 128MB RAM, 50% CPU,
                         50 PIDs, 15s default timeout). We bind to it
                         directly inside `deterministic_repro`.

MCTS / Tree-of-Thoughts (RedAgentV3): NOT reused. Repro's search space is
too shallow for tree expansion to dominate the strategy evolver + critic
loop. Re-evaluate if the loop saturates at fidelity < 0.7 in production.
═══════════════════════════════════════════════════════════════════════════

Drop-in entrypoint for the FastAPI GitHub App:

    from logomesh_orchestrator import handle_sentry_webhook
    result = await handle_sentry_webhook(event)        # event = Sentry payload
    # result = {"status", "artifact", "pr_url", "audit", "needs_human_review",
    #           "critic", "memory", "strategy"}
"""

from __future__ import annotations

import asyncio
import datetime
import json
import logging
import math
import os
import random
import re
import sqlite3
import sys
import threading
import time
from collections import Counter
from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Annotated, Any, Literal, TypedDict

# --------------------------------------------------------------------------
# Path bootstrap + .env auto-load
# --------------------------------------------------------------------------
_REPO_ROOT = Path(__file__).resolve().parent
_SRC = _REPO_ROOT / "src"
if _SRC.is_dir() and str(_SRC) not in sys.path:
    sys.path.insert(0, str(_SRC))


def _load_dotenv_chain() -> None:
    """Load .env from CWD up to repo root, mirroring `cli/main.py::_load_env`.

    Soft dependency on python-dotenv. No-op if not installed. Does NOT
    override variables already present in the process environment.
    """
    try:
        from dotenv import load_dotenv
    except ImportError:
        return
    candidates = [Path.cwd(), *Path.cwd().parents, _REPO_ROOT]
    seen: set[Path] = set()
    for p in candidates:
        if p in seen:
            continue
        seen.add(p)
        env = p / ".env"
        if env.exists():
            load_dotenv(env, override=False)
            return
        if (p / ".git").exists() and p != Path.cwd():
            break


_load_dotenv_chain()

# --------------------------------------------------------------------------
# Third-party
# --------------------------------------------------------------------------
from pydantic import BaseModel, Field

try:
    from langchain_core.messages import (
        AIMessage,
        BaseMessage,
        HumanMessage,
        SystemMessage,
        ToolMessage,
    )
    from langchain_core.tools import StructuredTool
    from langgraph.checkpoint.memory import MemorySaver
    from langgraph.graph import END, START, StateGraph
    from langgraph.graph.message import add_messages
    from langgraph.prebuilt import ToolNode
except ImportError as e:  # pragma: no cover
    raise ImportError(
        "logomesh_orchestrator requires langgraph>=0.2 and langchain-core. "
        "Install with: pip install 'langgraph>=0.2' 'langchain-core>=0.3' "
        "'langchain-openai>=0.2'"
    ) from e

# --------------------------------------------------------------------------
# logomesh internals (the moat)
# --------------------------------------------------------------------------
from cli.artifact import get_git_metadata, render_artifact  # type: ignore  # noqa: E402
from cli.draft_pr import create_draft_pr as _create_draft_pr  # type: ignore  # noqa: E402
from core.audit_log import AuditSession  # type: ignore  # noqa: E402
from core.usage_tracker import (  # type: ignore  # noqa: E402
    TokenBudgetExceeded,
    add_usage,
    check_budget,
    estimate_cost_usd,
    get_last_model,
    get_usage,
    reset_usage,
    usage_summary,
)
from core.supabase_client import log_usage as _supabase_log_usage  # type: ignore  # noqa: E402
from core.installation_secrets import (  # type: ignore  # noqa: E402
    InstallationSecrets,
    resolve_secrets,
)
from oracles.sentry_replay import (  # type: ignore  # noqa: E402
    fetch_event_by_issue,
    find_innermost_app_frame,
)
# Hardened synthesizer + parser + Path B always-on primitives live in a
# sibling module so IDE auto-format can't strip them from sentry_replay.py.
from oracles.sentry_replay_v2 import (  # type: ignore  # noqa: E402
    build_replay_test_v2 as build_replay_test,
    parse_sandbox_exception_type,
    resolve_source_fuzzy,
    resolve_source_with_hints,
)
from oracles.signal_detectors import build_signal_harnesses  # type: ignore  # noqa: E402

log = logging.getLogger("logomesh.orchestrator")
if not log.handlers:
    handler = logging.StreamHandler()
    handler.setFormatter(logging.Formatter(
        "%(asctime)s [%(levelname)s] logomesh.orchestrator: %(message)s"
    ))
    log.addHandler(handler)
log.setLevel(os.getenv("LOGOMESH_LOG_LEVEL", "INFO"))


# ==========================================================================
# CONFIG
# ==========================================================================

MAX_CRITIC_ATTEMPTS = 3
MIN_FIDELITY_FOR_SHIP = 0.9

_DEFAULT_DB_DIR = Path(os.path.expanduser(
    os.getenv("LOGOMESH_DB_DIR", "~/.cache/logomesh")
))
_DEFAULT_DB_DIR.mkdir(parents=True, exist_ok=True)
_DEFAULT_MEMORY_DB = str(_DEFAULT_DB_DIR / "repro_memory.db")


# ==========================================================================
# 1. REPRO MEMORY  (REUSED FROM: src/memory.py::BattleMemory)
# ==========================================================================
# SQLite-backed cross-run learning. We kept the competition's 4-lesson-type
# schema and the prompt-formatter API verbatim — they survived 1000+
# benchmark runs and are well-tuned. The keying changed: instead of
# `task_id` (one of 20 fixed coding tasks) we use a `crash_signature`
# (sha16 of error_type + normalized function + file basename), which lets
# us cluster recurrences of the same prod bug across services.
#
# Lesson type mapping (competition → repro):
#     vulnerability    → repro_failure       (deterministic test passed when
#                                             it should have failed, etc.)
#     test_failure     → sandbox_failure
#     refinement       → context_recovery    (which context_reconstructor
#                                             reason successfully fed the
#                                             next deterministic_repro?)
#     scoring          → fidelity            (critic fidelity breakdown)
#
# Attack hints (which red-team strategies succeed per task) are reused
# directly as "context hints" — which fixture/breadcrumb strategies have
# historically resurrected non-trivial repros for similar crashes.
# ==========================================================================


def _crash_signature(error_type: str, function: str, filename: str) -> str:
    """Stable 16-hex hash of (error_type, normalized function, file basename).

    Used as the cross-run cluster key. Two crashes with the same signature
    are presumed to be recurrences of the same bug for memory purposes.
    """
    import hashlib
    base = Path(filename or "").name
    norm_fn = (function or "").split(".")[-1].strip()
    payload = f"{(error_type or '').strip()}|{norm_fn}|{base}".lower()
    return hashlib.sha256(payload.encode("utf-8", errors="replace")).hexdigest()[:16]


class ReproMemory:
    """No-op stub — original BattleMemory archived in
    logomesh_legacy/agentbeats_evolvers/ after the 2026-05-06 A/B test
    showed zero uplift on 18 fixtures × 2 passes. Kept as a stub so the
    prompt-rendering surface and the graph wiring keep compiling. If real
    customer Sentry data ever justifies cross-run learning, restore from
    the archived snapshot.
    """

    def __init__(self, db_path: str = _DEFAULT_MEMORY_DB):
        self.db_path = db_path

    def recall(self, crash_signature: str) -> dict:
        return {"has_history": False, "stats": {},
                "context_hints": [], "recent_failures": []}

    def store_run(self, **kwargs) -> None:
        return None

    def format_for_supervisor(self, memory: dict) -> str:
        return "(no prior runs for this crash signature)"


# ==========================================================================
# 2. STRATEGY EVOLVER  (REUSED FROM: src/strategy_evolver.py)
# ==========================================================================
# UCB1 multi-armed bandit. Same SQLite-backed structure, different arms:
# we evolve over orchestration strategies (tool-ordering preferences) rather
# than red-team aggressiveness. The competition repo proved this design
# converges in ~20 trials; we keep the same exploration constant.
# ==========================================================================


REPRO_DEFAULT_STRATEGY: dict = {
    "tool_order": "memory,rag,deterministic,critic",
    "fidelity_threshold": MIN_FIDELITY_FOR_SHIP,
    "max_attempts": MAX_CRITIC_ATTEMPTS,
    "proactive_context_recon": False,
    "proactive_dep_check": False,
    "use_hypothesis_assist": False,
}

REPRO_STRATEGY_VARIANTS: list[dict] = [
    {
        "name": "locals_only",
        "description": "Trust frame locals; minimal enrichment; one critic pass.",
        "overrides": {
            "tool_order": "deterministic,critic",
            "max_attempts": 1,
        },
    },
    {
        "name": "breadcrumb_heavy",
        "description": "Read breadcrumbs + trace before repro; heavy context_reconstructor use.",
        "overrides": {
            "tool_order": "memory,rag,context,deterministic,critic",
            "proactive_context_recon": True,
        },
    },
    {
        "name": "dep_check_first",
        "description": "Probe PyPI/CVE for traceback deps before any repro attempt.",
        "overrides": {
            "tool_order": "memory,web,rag,deterministic,critic",
            "proactive_dep_check": True,
        },
    },
    {
        "name": "context_reconstruct",
        "description": "Always run context_reconstructor on first failure.",
        "overrides": {
            "proactive_context_recon": True,
            "max_attempts": 3,
        },
    },
    {
        "name": "hypothesis_assist",
        "description": "Pull hypothesis property suggestions; use Scientific engine on critic loop.",
        "overrides": {
            "use_hypothesis_assist": True,
            "fidelity_threshold": 0.85,
        },
    },
]


class ReproStrategyEvolver:
    """No-op stub — original UCB1 bandit archived in
    logomesh_legacy/agentbeats_evolvers/. See ReproMemory docstring.
    """

    def __init__(self, db_path: str = _DEFAULT_MEMORY_DB):
        self.db_path = db_path

    def select(self, crash_signature: str) -> dict:
        out = dict(REPRO_DEFAULT_STRATEGY)
        out["_strategy_name"] = "default"
        return out

    def record(self, **kwargs) -> None:
        return None

    def format_for_supervisor(self, strategy: dict) -> str:
        order = strategy.get("tool_order", "")
        thr = strategy.get("fidelity_threshold", "")
        return (f"strategy: default (no learning)\n"
                f"tool_order: {order}\n"
                f"fidelity_threshold: {thr}")

# ==========================================================================
# 3. SCIENTIFIC CONTEXT ENGINE
#    (REUSED FROM: src/green_logic/refinement_loop.py::ScientificMethodEngine)
# ==========================================================================
# The competition's ScientificMethodEngine ran Observe → Hypothesize →
# Experiment → Verify on Red-Agent vulnerability findings. We adapt it to
# answer a different question:
#
#   "Why did the deterministic_repro fall short of the original crash, and
#    which environmental fact would close the gap?"
#
# The output is *never* test code — only structured ContextNotes that
# direct the supervisor toward different deterministic env state
# (fixtures, breadcrumbs replay, dep version probe). The repro test
# itself is still synthesized by `build_replay_test`.
#
# All experiments are *deterministic* probes (regex over breadcrumbs,
# RAG lookup, PyPI metadata) — no LLM in the verification path.
# ==========================================================================


class HypothesisStatus(Enum):
    PROPOSED = "proposed"
    CONFIRMED = "confirmed"
    REJECTED = "rejected"
    INCONCLUSIVE = "inconclusive"


@dataclass
class CtxObservation:
    source: str
    description: str
    evidence: str = ""


@dataclass
class CtxHypothesis:
    id: str
    statement: str          # "Crash needs DB row at id=5 before call"
    prediction: str         # "If breadcrumbs show DB INSERT id=5, hypothesis confirmed"
    probe_kind: Literal["breadcrumb", "rag", "pypi", "trace_signal"]
    status: HypothesisStatus = HypothesisStatus.PROPOSED
    evidence_for: list[str] = field(default_factory=list)
    evidence_against: list[str] = field(default_factory=list)


@dataclass
class VerifiedContextFinding:
    hypothesis: CtxHypothesis
    suggested_strategy: str  # one of the StrategyEvolver context strategies
    confidence: float
    proof: str


class ScientificContextEngine:
    """Lightweight, deterministic refinement engine for failed repros."""

    def __init__(self, memory: ReproMemory):
        self.memory = memory

    # -- 1. OBSERVE --------------------------------------------------------

    def observe(self, event_snapshot: dict, repro_result: dict) -> list[CtxObservation]:
        obs: list[CtxObservation] = []
        frame = event_snapshot.get("frame") or {}
        if not repro_result.get("reproduced"):
            obs.append(CtxObservation(
                source="sandbox",
                description="deterministic test passed; bug did not reproduce",
                evidence=(repro_result.get("sandbox_output") or "")[-500:],
            ))
        if not (frame.get("variables") or {}):
            obs.append(CtxObservation(
                source="frame",
                description="no frame locals captured by Sentry",
            ))
        breadcrumbs = (event_snapshot.get("breadcrumbs") or {}).get("values", [])
        if breadcrumbs:
            db_crumbs = [b for b in breadcrumbs if "db" in str(b).lower() or "query" in str(b).lower()]
            if db_crumbs:
                obs.append(CtxObservation(
                    source="breadcrumbs", description="DB activity in breadcrumbs",
                    evidence=str(db_crumbs[:3])[:500],
                ))
            async_crumbs = [b for b in breadcrumbs if "asyncio" in str(b).lower() or "await" in str(b).lower()]
            if async_crumbs:
                obs.append(CtxObservation(
                    source="breadcrumbs", description="async activity in breadcrumbs",
                    evidence=str(async_crumbs[:3])[:500],
                ))
        if event_snapshot.get("trace_id"):
            obs.append(CtxObservation(
                source="trace", description="distributed trace id available",
                evidence=event_snapshot.get("trace_id", ""),
            ))
        return obs

    # -- 2. HYPOTHESIZE ----------------------------------------------------

    def hypothesize(self, obs: list[CtxObservation]) -> list[CtxHypothesis]:
        hyps: list[CtxHypothesis] = []
        kinds = {o.description for o in obs}
        if any("DB activity" in k for k in kinds):
            hyps.append(CtxHypothesis(
                id="H_DB",
                statement="Bug requires pre-existing DB state mutated in breadcrumbs",
                prediction="Seeding sandbox state.db from breadcrumb DB events should reproduce",
                probe_kind="breadcrumb",
            ))
        if any("async activity" in k for k in kinds):
            hyps.append(CtxHypothesis(
                id="H_ASYNC",
                statement="Bug requires asyncio runtime / pytest.mark.asyncio",
                prediction="Wrapping replay in asyncio runner reproduces; sync path does not",
                probe_kind="trace_signal",
            ))
        if any("no frame locals" in k for k in kinds):
            hyps.append(CtxHypothesis(
                id="H_GLOBALS",
                statement="Bug depends on module-level globals not in frame locals",
                prediction="rag_search of target module reveals required global state",
                probe_kind="rag",
            ))
        if any("test passed" in k for k in kinds) and not hyps:
            hyps.append(CtxHypothesis(
                id="H_DEPS",
                statement="Bug is in a transitive dep; current branch may have upgraded past it",
                prediction="PyPI history shows the version delta",
                probe_kind="pypi",
            ))
        return hyps[:3]

    # -- 3. EXPERIMENT (deterministic probes) ------------------------------

    async def experiment(
        self, hyps: list[CtxHypothesis], event_snapshot: dict, session_id: str,
    ) -> list[CtxHypothesis]:
        breadcrumbs = (event_snapshot.get("breadcrumbs") or {}).get("values", [])
        for h in hyps:
            try:
                if h.probe_kind == "breadcrumb":
                    db_writes = [
                        str(b) for b in breadcrumbs
                        if re.search(r"\b(insert|update|delete)\b", str(b), re.I)
                    ]
                    if db_writes:
                        h.evidence_for.append(f"{len(db_writes)} DB write breadcrumbs")
                        h.status = HypothesisStatus.CONFIRMED
                    else:
                        h.evidence_against.append("no DB write breadcrumbs found")
                        h.status = HypothesisStatus.REJECTED

                elif h.probe_kind == "trace_signal":
                    async_evidence = [
                        b for b in breadcrumbs
                        if re.search(r"async|await|coroutine", str(b), re.I)
                    ]
                    if async_evidence or "asyncio" in str(event_snapshot.get("error_message", "")).lower():
                        h.evidence_for.append("async signals in breadcrumbs/error")
                        h.status = HypothesisStatus.CONFIRMED
                    else:
                        h.evidence_against.append("no async signals")
                        h.status = HypothesisStatus.INCONCLUSIVE

                elif h.probe_kind == "rag":
                    res = json.loads(await _tool_rag_search(
                        query=str(event_snapshot.get("frame", {}).get("function", "")),
                        session_id=session_id, namespace="codebase", k=3,
                    ))
                    if res.get("hits"):
                        h.evidence_for.append(f"{len(res['hits'])} codebase hits")
                        h.status = HypothesisStatus.CONFIRMED
                    else:
                        h.status = HypothesisStatus.INCONCLUSIVE

                elif h.probe_kind == "pypi":
                    err = str(event_snapshot.get("error_type", ""))
                    pkg_match = re.search(r"([a-z][a-z0-9_-]+)\.", err.lower())
                    pkg = pkg_match.group(1) if pkg_match else ""
                    if pkg:
                        res = json.loads(await _tool_web_search(
                            query=f"{pkg} {err}", session_id=session_id,
                            source="pypi", package=pkg,
                        ))
                        if res.get("hits"):
                            h.evidence_for.append(f"PyPI hits for {pkg}")
                            h.status = HypothesisStatus.CONFIRMED
                    else:
                        h.status = HypothesisStatus.INCONCLUSIVE
            except Exception as e:
                log.warning("scientific experiment failed for %s: %s", h.id, e)
                h.status = HypothesisStatus.INCONCLUSIVE
        return hyps

    # -- 4. VERIFY ---------------------------------------------------------

    def verify(self, hyps: list[CtxHypothesis]) -> list[VerifiedContextFinding]:
        out: list[VerifiedContextFinding] = []
        for h in hyps:
            if h.status != HypothesisStatus.CONFIRMED:
                continue
            strategy = {
                "H_DB": "seed_state_db_from_breadcrumbs",
                "H_ASYNC": "asyncio_replay_wrapper",
                "H_GLOBALS": "module_globals_from_rag",
                "H_DEPS": "pypi_version_pin",
            }.get(h.id, "context_reconstructor_generic")
            out.append(VerifiedContextFinding(
                hypothesis=h,
                suggested_strategy=strategy,
                confidence=min(1.0, 0.4 + 0.2 * len(h.evidence_for)),
                proof="; ".join(h.evidence_for) or "structural match",
            ))
        return out

    async def investigate(
        self, event_snapshot: dict, repro_result: dict, session_id: str,
    ) -> list[VerifiedContextFinding]:
        """Full pipeline. Cheap (<2s) and deterministic."""
        obs = self.observe(event_snapshot, repro_result)
        hyps = self.hypothesize(obs)
        hyps = await self.experiment(hyps, event_snapshot, session_id)
        return self.verify(hyps)


# ==========================================================================
# 4. STATE
# ==========================================================================

def _last_writer_wins(_old: Any, new: Any) -> Any:
    return new

def _append(old: list | None, new: list | None) -> list:
    return list(old or []) + list(new or [])


class ReproResult(BaseModel):
    """Sacred output of `deterministic_repro`. Immutable once written."""
    test_code: str
    sandbox_output: str
    sandbox_mode: str
    passed: int
    failed: int
    total: int
    duration: float
    reproduced: bool
    target_path: str
    target_lineno: int
    target_function: str
    error_type: str            # exception type from the Sentry event
    error_message: str
    sandbox_exception_type: str = ""   # parsed from pytest output (Fix 1)
    verified_exception_match: bool = False   # sandbox type == event type (Fix 3)
    sealed: bool = True


class DepAdvisory(BaseModel):
    package: str
    requested_version: str = ""
    advisory: str
    source: str
    severity: Literal["info", "warn", "block"] = "info"
    url: str = ""


class ContextNote(BaseModel):
    kind: Literal["async", "db", "globals", "c_ext", "fixture", "logs", "deps", "other"]
    summary: str
    suggested_fixture: str = ""
    hypothesis_property: str = ""
    confidence: float = 0.0
    strategy: str = ""


class CriticReport(BaseModel):
    fidelity: float = Field(ge=0.0, le=1.0)
    same_exception_type: bool
    same_function: bool
    locals_match: bool
    feedback: str
    blockers: list[str] = Field(default_factory=list)


class OrchestratorState(TypedDict, total=False):
    event_id: str
    org: str | None
    repo_path: str
    sentry_event_raw: dict[str, Any]
    crash_signature: str
    strategy_config: dict[str, Any]

    messages: Annotated[list[BaseMessage], add_messages]

    dep_advisories: Annotated[list[DepAdvisory], _append]
    context_notes: Annotated[list[ContextNote], _append]
    rag_hits: Annotated[list[dict], _append]
    web_hits: Annotated[list[dict], _append]
    hypothesis_suggestions: Annotated[list[str], _append]
    scientific_findings: Annotated[list[dict], _append]

    repro_result: Annotated[ReproResult | None, _last_writer_wins]
    critic_report: Annotated[CriticReport | None, _last_writer_wins]
    critic_attempts: Annotated[int, _last_writer_wins]
    step_count: Annotated[int, _last_writer_wins]
    max_tool_calls: Annotated[int, _last_writer_wins]
    winning_strategy: Annotated[str, _last_writer_wins]

    artifact: Annotated[dict | None, _last_writer_wins]
    pr_url: Annotated[str, _last_writer_wins]
    needs_human_review: Annotated[bool, _last_writer_wins]
    human_review_reason: Annotated[str, _last_writer_wins]
    human_review_evidence: Annotated[dict | None, _last_writer_wins]
    hypothesis_report: Annotated[dict | None, _last_writer_wins]
    error: Annotated[str, _last_writer_wins]

    environment_prep: Annotated[dict | None, _last_writer_wins]

    audit_session_id: Annotated[str, _last_writer_wins]


# ---- module-level registries (per-run; cleared in finally) ---------------
_AUDIT_REGISTRY: dict[str, AuditSession] = {}
_REPRO_REGISTRY: dict[str, ReproResult] = {}
_EVENT_REGISTRY: dict[str, dict] = {}
_ENV_REGISTRY: dict[str, dict] = {}
_RESOLVE_REGISTRY: dict[str, dict] = {}  # session_id → {"attempts": int, "tried_hints": list[str]}
_SECRETS_REGISTRY: dict[str, InstallationSecrets] = {}  # session_id → resolved per-install secrets
_MAX_RESOLVE_ATTEMPTS = 2  # original + 1 retry with supervisor-supplied hints

# ---- shared singletons ---------------------------------------------------
_MEMORY = ReproMemory()
_EVOLVER = ReproStrategyEvolver()
_SCIENCE = ScientificContextEngine(_MEMORY)


def _get_audit(session_id: str) -> AuditSession:
    audit = _AUDIT_REGISTRY.get(session_id)
    if audit is None:
        audit = AuditSession(session_id)
        _AUDIT_REGISTRY[session_id] = audit
    return audit


# ==========================================================================
# 5. TOOL IMPLEMENTATIONS
# ==========================================================================

# ---- arg schemas ---------------------------------------------------------

class FetchSentryArgs(BaseModel):
    event_id: str = Field(description="Sentry issue or event id")
    org: str | None = Field(default=None, description="Sentry org slug, optional")
    session_id: str

class DeterministicReproArgs(BaseModel):
    session_id: str
    repo_path: str = "."
    timeout_s: int = 60
    path_hints: list[str] = Field(
        default_factory=list,
        description=(
            "Optional candidate file paths to try BEFORE the default "
            "resolve_source_fuzzy chain. Use this on retry after a "
            "previous source_not_found result — pass paths recovered "
            "from web_search('github', package=<module>) or rag_search "
            "('codebase', query=<basename>)."
        ),
    )

class HypothesisSuggesterArgs(BaseModel):
    session_id: str
    function_name: str
    function_source: str = ""
    error_type: str = ""

class ContextReconstructorArgs(BaseModel):
    session_id: str
    reason: Literal["no_repro", "async_state", "db_state", "globals", "c_ext", "missing_fixture"]
    detail: str = ""

class CriticValidateArgs(BaseModel):
    session_id: str

class WebSearchArgs(BaseModel):
    query: str
    source: Literal["pypi", "github", "stackoverflow", "cve", "general"] = "general"
    session_id: str
    package: str = ""

class RagSearchArgs(BaseModel):
    query: str
    namespace: Literal["codebase", "past_runs", "docs", "memory", "all"] = "all"
    session_id: str
    k: int = 5

class BuildArtifactArgs(BaseModel):
    session_id: str
    repo_path: str = "."
    pr_url: str = ""

class CreateDraftPrArgs(BaseModel):
    session_id: str
    repo_path: str = "."

class PrepareEnvironmentArgs(BaseModel):
    """Args for prepare_environment.

    Advisory infrastructure tool: gathers PyPI specs from the repo, optionally
    augments them with packages mentioned in `sandbox_error` (ModuleNotFoundError
    / ImportError), and builds a wheel snapshot. Output is a snapshot path the
    caller passes back into `deterministic_repro` via the `deps_snapshot`
    sandbox parameter. NOT in evidence path — never mutates test_code or
    sandbox_output bytes.
    """
    session_id: str
    repo_path: str = "."
    sandbox_error: str = ""        # last sandbox output, used to extract missing modules
    consult_cve: bool = True       # advisory CVE lookup per package
    max_extra_packages: int = 8    # cap auto-added deps for safety
    module_versions: dict[str, str] = {}
    """Optional pip-freeze map from the Sentry event's `modules` field.
    When supplied, prepare_environment overrides manifest-declared
    versions with these exact prod-at-crash-time pins. Closes the
    prod/sandbox drift gap. Pass `exc.modules` here."""


class IntrospectRepoArgs(BaseModel):
    """Args for introspect_repo.

    Advisory RAG window into the repo. The agent calls this whenever it
    needs to decide *how* to bootstrap the sandbox before retrying
    `deterministic_repro`. Returns evidence (imports, decorators, class
    shapes, manifest deps, config files, entrypoints) — no framework
    decisions. The agent reasons over the evidence; this tool never
    routes on its own.

    Use this BEFORE giving up on reproduction. If the crash needs a
    framework bootstrap or an ORM instance built from the captured
    frame locals, this is how you discover what to build.
    """
    session_id: str
    repo_path: str = "."
    focus: Literal["all", "classes", "callables", "config", "imports", "manifests"] = "all"
    name_filter: str = ""  # optional regex to narrow class/callable results


# ---- 1. fetch_sentry_event -----------------------------------------------

async def _tool_fetch_sentry_event(
    event_id: str, session_id: str, org: str | None = None,
) -> str:
    audit = _get_audit(session_id)
    cached = _EVENT_REGISTRY.get(session_id)
    if cached is not None:
        return json.dumps({"cached": True, "summary": _summarize_event(cached)})

    # Per-installation auth: pull the Sentry token from the secrets
    # registry first, fall back to env (the kwarg-default branch inside
    # fetch_event_by_issue handles None as "look in env").
    secrets = _SECRETS_REGISTRY.get(session_id)
    sentry_token = (secrets.sentry_auth_token if secrets else "") or None
    exc = await fetch_event_by_issue(event_id, org=org, auth_token=sentry_token)
    frame = find_innermost_app_frame(exc)
    snapshot = {
        "issue_id": getattr(exc, "issue_id", event_id),
        "error_type": getattr(exc, "error_type", ""),
        "error_message": getattr(exc, "error_message", ""),
        "frame": None if frame is None else {
            "function": frame.function, "filename": frame.filename,
            "lineno": frame.lineno,
            "context_line": getattr(frame, "context_line", "") or "",
            "variables": dict(getattr(frame, "variables", {}) or {}),
        },
        "all_frames": [
            {"function": f.function, "filename": f.filename,
             "lineno": f.lineno, "in_app": getattr(f, "in_app", True)}
            for f in (getattr(exc, "frames", []) or [])[:20]
        ],
        "breadcrumbs": (getattr(exc, "raw_event", {}) or {}).get("breadcrumbs", {}),
        "trace_id": (getattr(exc, "raw_event", {}) or {}).get("contexts", {})
                    .get("trace", {}).get("trace_id", ""),
    }
    _EVENT_REGISTRY[session_id] = {"exc": exc, "frame": frame, "snapshot": snapshot}
    audit.log_llm_call(
        intent=f"fetch sentry event {event_id}",
        model="sentry-api", prompt=event_id, response=json.dumps(snapshot)[:4000],
    )
    return json.dumps({"cached": False, "summary": _summarize_event(_EVENT_REGISTRY[session_id])})


def _summarize_event(entry: dict) -> dict:
    snap = entry.get("snapshot", {})
    return {
        "issue_id": snap.get("issue_id"),
        "error_type": snap.get("error_type"),
        "error_message": (snap.get("error_message") or "")[:300],
        "frame_function": (snap.get("frame") or {}).get("function"),
        "frame_file": (snap.get("frame") or {}).get("filename"),
        "frame_line": (snap.get("frame") or {}).get("lineno"),
        "n_locals": len(((snap.get("frame") or {}).get("variables") or {})),
        "n_frames": len(snap.get("all_frames") or []),
        "has_trace": bool(snap.get("trace_id")),
    }


# ---- 2. deterministic_repro (SACRED — zero LLM in evidence path) ---------

async def _tool_deterministic_repro(
    session_id: str, repo_path: str = ".", timeout_s: int = 60,
    path_hints: list[str] | None = None,
) -> str:
    audit = _get_audit(session_id)
    entry = _EVENT_REGISTRY.get(session_id)
    if entry is None:
        return json.dumps({"error": "must call fetch_sentry_event first"})

    # CACHE: deterministic synthesis is a pure function of (frame, source).
    # If a sealed result is already in the registry, return it instead of
    # re-running the sandbox. The critic_node clears the registry when it
    # wants a fresh attempt, so the cache layer cannot mask retries.
    cached = _REPRO_REGISTRY.get(session_id)
    if cached is not None and cached.sealed:
        return json.dumps({
            "reproduced": cached.reproduced,
            "passed": cached.passed, "failed": cached.failed,
            "total": cached.total, "sandbox_mode": cached.sandbox_mode,
            "target": f"{cached.target_function} at {cached.target_path}:{cached.target_lineno}",
            "summary": (
                f"{'reproduced' if cached.reproduced else 'NOT reproduced'}: "
                f"{cached.error_type} in {cached.target_function}()"
            ),
            "sealed": True, "cached": True,
        })

    exc, frame = entry["exc"], entry["frame"]
    if frame is None or not frame.function or frame.function == "<module>":
        return json.dumps({"error": "no usable in-app frame", "human_review": True})

    # Fix 2: source must resolve on disk, otherwise we'd produce a test that
    # imports nothing → any failure becomes NameError → false-positive green.
    # Refuse to ship without source. The fuzzy resolver tries absolute,
    # repo-relative, leading-component-strip, and rglob-basename matches —
    # so prod paths like `/app/src/billing/x.py` find dev `src/billing/x.py`.
    #
    # Self-refusal loop (Fix 5): on first source_not_found, return retryable
    # with structured next_action telling the supervisor to web_search for
    # likely import paths and re-call us with `path_hints=[...]`. After
    # _MAX_RESOLVE_ATTEMPTS, we hard-refuse to human_review.
    state = _RESOLVE_REGISTRY.setdefault(
        session_id, {"attempts": 0, "tried_hints": []},
    )
    state["attempts"] += 1
    if path_hints:
        state["tried_hints"].extend(h for h in path_hints if h)

    source_on_disk = resolve_source_with_hints(
        frame.filename, Path(repo_path), path_hints=path_hints or [],
    )
    if not source_on_disk.strip():
        # Tease out a basename-derived module guess for the supervisor.
        basename = Path(frame.filename or "").name
        module_guess = (
            (frame.filename or "").replace("/", ".")
            .lstrip(".").rstrip(".py").rsplit(".py", 1)[0]
        )
        if state["attempts"] >= _MAX_RESOLVE_ATTEMPTS:
            return json.dumps({
                "error": "source not found after retry; cannot verify reproduction",
                "human_review": True,
                "reason": "source_not_found_retry_exhausted",
                "filename": frame.filename,
                "tried_hints": state["tried_hints"][:8],
                "hint": "pass --repo <path> or configure path mapping for prod paths",
            })
        # First failure → retryable. Supervisor should web_search/rag_search
        # then re-call deterministic_repro with `path_hints=[...]`.
        return json.dumps({
            "error": "source not found at first-pass resolution",
            "retryable": True,
            "reason": "source_not_found",
            "filename": frame.filename,
            "basename": basename,
            "module_guess": module_guess,
            "next_action": (
                "Call web_search(source='github', query=<basename>) OR "
                "rag_search(namespace='codebase', query=<basename>) to find "
                "the file's likely path in this repo, then re-invoke "
                "deterministic_repro with path_hints=[<recovered_paths>]."
            ),
            "attempts": state["attempts"],
            "max_attempts": _MAX_RESOLVE_ATTEMPTS,
        })
    source = source_on_disk

    # DETERMINISTIC: frame locals → pytest. Pure function. No LLM.
    test_code = build_replay_test(exc, frame, source)
    if not test_code:
        return json.dumps({
            "error": "deterministic synthesis failed (frame locals insufficient)",
            "human_review": True, "reason": "frame_locals_insufficient",
        })

    # Signal harnesses: supplementary fixture code injected alongside test.
    # Advisory — never touches test_code bytes that land in evidence_path_seal.
    signal_code, signal_meta = build_signal_harnesses(frame, exc, source)

    sandbox_extra_env: dict[str, str] = {}

    from business_logic.sandbox import Sandbox  # type: ignore

    sandbox_source = source.strip() or f"# Sentry frame: {getattr(frame, 'context_line', '')}\n"
    files = {"target.py": sandbox_source, "test_target.py": test_code}
    if signal_code:
        files["conftest_signal.py"] = signal_code
    sandbox = Sandbox(timeout=max(5, min(timeout_s, 120)))
    audit.log_file_write(intent="write deterministic pytest", path="test_target.py", content=test_code)

    # Pick up any deps_snapshot prepared earlier by _tool_prepare_environment.
    # NOT in evidence path: snapshot is just a wheel directory mounted r/o.
    env_state = _ENV_REGISTRY.get(session_id) or {}
    deps_snapshot = env_state.get("snapshot_path") or None

    # PR2: pin sandbox python image to the prod runtime version when the
    # Sentry payload populated it. Falls back to the default image if the
    # version is outside the allowlist. Advisory only — never enters the
    # sealed evidence bytes.
    py_version_pin: str | None = None
    runtime_ctx = getattr(exc, "runtime", None)
    if runtime_ctx is not None:
        raw_version = (getattr(runtime_ctx, "version", "") or "").strip()
        # Reduce "3.11.5" → "3.11" for image tag lookup
        match = re.match(r"^(\d+\.\d+)", raw_version)
        if match:
            candidate = match.group(1)
            if Sandbox.image_for_python_version(candidate):
                py_version_pin = candidate

    result = await asyncio.to_thread(
        sandbox.run, files, deps_snapshot=deps_snapshot,
        extra_env=sandbox_extra_env or None,
        python_version=py_version_pin,
    )
    audit.log_sandbox_run(
        intent=f"deterministic repro of {exc.error_type} in {frame.function}()",
        files=files,
        result={**result, "sandbox_mode": sandbox.mode,
                "deps_snapshot_used": bool(deps_snapshot)},
    )

    # PYTHONHASHSEED sweep: KeyError on dict/set → try seeds 0-19 to find
    # crashing seed. Advisory only — does not affect evidence_path_seal.
    hashseeds = signal_meta.get("try_hashseeds", [])
    if hashseeds and result.get("failed", 0) == 0 and result.get("total", 0) > 0:
        for seed in hashseeds:
            seed_env = dict(sandbox_extra_env)
            seed_env["PYTHONHASHSEED"] = str(seed)
            seed_result = await asyncio.to_thread(
                sandbox.run, files, deps_snapshot=deps_snapshot, extra_env=seed_env,
                python_version=py_version_pin,
            )
            if seed_result.get("failed", 0) > 0:
                result = seed_result
                sandbox_extra_env["PYTHONHASHSEED"] = str(seed)
                audit.log_sandbox_run(
                    intent=f"hashseed repro (seed={seed})",
                    files=files,
                    result={**seed_result, "sandbox_mode": sandbox.mode,
                            "PYTHONHASHSEED": seed},
                )
                break

    # Auto-prepare-and-retry on dependency import failure (one shot, capped).
    # The supervisor can also call prepare_environment explicitly; this is a
    # safety net so a missing wheel doesn't immediately surface as
    # human_review when the fix is mechanical.
    from business_logic.sandbox import _has_import_failure  # type: ignore
    raw_output = (result.get("output") or "")
    if (
        _has_import_failure(raw_output)
        and not env_state.get("auto_retry_done")
        and result.get("failed", 0) == 0  # only auto-retry on collection failure, never on a real crash
    ):
        env_state["auto_retry_done"] = True
        _ENV_REGISTRY[session_id] = env_state
        audit.log_dep_resolution(
            intent="auto prepare_environment on import failure",
            name="<auto>", version="", pypi_url="",
        )
        # PR2: pass exc.modules so prepare_environment overrides versions
        # with the exact prod pip-freeze, not the manifest's declared range.
        sentry_modules = getattr(exc, "modules", {}) or {}
        prep_raw = await _tool_prepare_environment(
            session_id=session_id, repo_path=repo_path,
            sandbox_error=raw_output,
            module_versions=sentry_modules,
        )
        try:
            prep = json.loads(prep_raw)
        except Exception:
            prep = {}
        new_snapshot = (prep or {}).get("snapshot_path")
        if new_snapshot and new_snapshot != deps_snapshot:
            result = await asyncio.to_thread(
                sandbox.run, files, deps_snapshot=new_snapshot,
                extra_env=sandbox_extra_env or None,
                python_version=py_version_pin,
            )
            audit.log_sandbox_run(
                intent="retry repro after prepare_environment",
                files=files,
                result={**result, "sandbox_mode": sandbox.mode,
                        "deps_snapshot_used": True, "retry_after_prep": True},
            )

    # Fix 1: parse pytest output for the actual exception type.
    sandbox_output_full = (result.get("output") or "")
    sandbox_exc_type = parse_sandbox_exception_type(sandbox_output_full)
    expected_exc = (getattr(exc, "error_type", "") or "")
    # Fix 3: verified iff sandbox actually raised the same type the event recorded.
    # Match either fully-qualified ("sqlalchemy.exc.IntegrityError") or basename ("IntegrityError").
    verified = bool(sandbox_exc_type) and (
        sandbox_exc_type == expected_exc
        or sandbox_exc_type.endswith("." + expected_exc)
        or expected_exc.endswith("." + sandbox_exc_type)
    )

    repro = ReproResult(
        test_code=test_code,
        sandbox_output=sandbox_output_full[:10000],
        sandbox_mode=sandbox.mode,
        passed=int(result.get("passed", 0)),
        failed=int(result.get("failed", 0)),
        total=int(result.get("total", 0)),
        duration=float(result.get("duration", 0.0)),
        reproduced=int(result.get("failed", 0)) > 0 and verified,
        target_path=frame.filename or "<unknown>",
        target_lineno=int(frame.lineno or 0),
        target_function=frame.function,
        error_type=expected_exc,
        error_message=getattr(exc, "error_message", ""),
        sandbox_exception_type=sandbox_exc_type,
        verified_exception_match=verified,
        sealed=True,
    )
    _REPRO_REGISTRY[session_id] = repro
    return json.dumps({
        "reproduced": repro.reproduced,
        "passed": repro.passed, "failed": repro.failed, "total": repro.total,
        "sandbox_mode": repro.sandbox_mode,
        "sandbox_exception_type": sandbox_exc_type,
        "verified_exception_match": verified,
        "target": f"{repro.target_function} at {repro.target_path}:{repro.target_lineno}",
        "summary": (
            f"{'verified-reproduced' if repro.reproduced else 'NOT reproduced'}: "
            f"sandbox raised {sandbox_exc_type or '<none>'} vs expected {expected_exc}"
        ),
        "sealed": True,
    })


def _read_target_source(repo: Path, filename: str) -> str:
    if not filename:
        return ""
    try:
        repo_root = Path(repo).resolve()
    except Exception:
        return ""
    candidates = [repo_root / filename, repo_root / filename.lstrip("/")]
    parts = Path(filename).parts
    for i in range(len(parts)):
        candidates.append(repo_root.joinpath(*parts[i:]))
    for c in candidates:
        try:
            if c.is_file():
                return c.read_text(errors="replace")
        except Exception:
            continue
    return ""


# ---- 3. hypothesis_invariant_suggester (advisory only) -------------------

async def _tool_hypothesis_invariant_suggester(
    session_id: str, function_name: str,
    function_source: str = "", error_type: str = "",
) -> str:
    audit = _get_audit(session_id)
    _bu, _key = _llm_endpoint()
    if not _key:
        return json.dumps({"suggestions": [], "reason": "no LLM backend configured"})
    prompt = (
        f"Function `{function_name}` raised `{error_type}`. "
        "Suggest 3 Hypothesis properties (one line each) that, if true, "
        "would have prevented this crash. Format: `@given(...) def "
        "test_property(...): assert ...`. Source:\n```python\n"
        f"{(function_source or '')[:2500]}\n```"
    )
    text = await _llm_complete(prompt, max_tokens=600)
    suggestions = [
        line.strip(" -*\t") for line in text.splitlines()
        if line.strip().startswith(("@given", "def test_", "assert "))
    ][:5]
    audit.log_llm_call(
        intent=f"hypothesis suggestions for {function_name}",
        model=os.getenv("LOGOMESH_REPRO_MODEL", "gpt-5-mini"),
        prompt=prompt, response=text,
    )
    return json.dumps({"suggestions": suggestions, "advisory_only": True})


# ---- 4. context_reconstructor --------------------------------------------

async def _tool_context_reconstructor(
    session_id: str, reason: str, detail: str = "",
) -> str:
    audit = _get_audit(session_id)
    entry = _EVENT_REGISTRY.get(session_id)
    if entry is None:
        return json.dumps({"error": "no event fetched"})

    snap = entry["snapshot"]
    breadcrumbs = (snap.get("breadcrumbs") or {}).get("values", [])[-12:]
    base = {
        "kind": reason, "trace_id": snap.get("trace_id"),
        "breadcrumbs_n": len(breadcrumbs),
        "frames_n": len(snap.get("all_frames", [])),
    }
    suggestion, hypothesis = "", ""
    if reason == "db_state":
        suggestion = ("seed sandbox state.db from breadcrumb DB events "
                      "(parse INSERT/UPDATE/DELETE rows leading up to crash)")
        hypothesis = "@given(rows=st.lists(...)) — invariant: total >= 0 after every commit"
    elif reason == "async_state":
        suggestion = "wrap target call in @pytest.mark.asyncio; reconstruct task graph from trace timeline"
    elif reason == "globals":
        suggestion = "monkeypatch module globals reconstructed from breadcrumbs"
    elif reason == "c_ext":
        suggestion = "C-extension state cannot be replayed from locals; flag for human review"
    elif reason == "missing_fixture":
        suggestion = "auto-generate fixture stub from deepest in-app frame's required objects"
    elif reason == "no_repro":
        suggestion = ("frame locals alone insufficient; inspect breadcrumbs for missing "
                      "preconditions; if still ambiguous mark human_review=True")
    note = ContextNote(
        kind=(reason if reason in {"async", "db", "globals", "c_ext", "fixture", "logs"}
              else ("db" if "db" in reason else "other")),
        summary=detail or suggestion,
        suggested_fixture=suggestion,
        hypothesis_property=hypothesis,
        confidence=0.6 if reason in {"db_state", "async_state"} else 0.35,
        strategy=reason,
    )
    audit.log_llm_call(
        intent=f"context reconstruction: {reason}", model="rule-based",
        prompt=detail, response=note.model_dump_json(),
    )
    return json.dumps({**base, **note.model_dump()})


# ---- 5. critic_validate --------------------------------------------------

async def _tool_critic_validate(session_id: str) -> str:
    audit = _get_audit(session_id)
    repro = _REPRO_REGISTRY.get(session_id)
    entry = _EVENT_REGISTRY.get(session_id)
    if repro is None or entry is None:
        return json.dumps({"error": "missing repro or event"})
    exc, frame = entry["exc"], entry["frame"]
    expected = (getattr(exc, "error_type", "") or "")
    # Fix 3: same_exception_type = sandbox's actual raised type matches event.
    # Was previously a tautology comparing two copies of the event field.
    same_exc = repro.verified_exception_match
    same_fn = (repro.target_function or "") == (frame.function if frame else "")
    locals_match = _locals_overlap(repro.test_code, getattr(frame, "variables", {}) or {})
    base = (0.4 if same_exc else 0.0) + (0.25 if same_fn else 0.0) \
         + (0.15 if locals_match else 0.0) + (0.20 if repro.reproduced else 0.0)
    fidelity = round(min(1.0, base), 3)
    blockers: list[str] = []
    if not repro.reproduced:
        if repro.failed > 0 and not repro.verified_exception_match:
            blockers.append(
                f"sandbox raised {repro.sandbox_exception_type or '<unknown>'} "
                f"but Sentry event was {expected} — repro is misclassifying"
            )
        else:
            blockers.append("test passed in sandbox; does not reproduce the crash")
    if not same_exc:
        blockers.append(f"exception mismatch: sandbox={repro.sandbox_exception_type or '<none>'} expected={expected}")
    if not same_fn:
        blockers.append("function-under-test differs from innermost in-app frame")
    feedback = ("high fidelity" if fidelity >= MIN_FIDELITY_FOR_SHIP
                else "repro insufficient: " + "; ".join(blockers or ["weak signal overlap"]))
    report = CriticReport(
        fidelity=fidelity, same_exception_type=same_exc, same_function=same_fn,
        locals_match=locals_match, feedback=feedback, blockers=blockers,
    )
    audit.log_llm_call(
        intent="critic fidelity score", model="deterministic-critic",
        prompt=f"sandbox={repro.sandbox_exception_type} expected={expected}",
        response=report.model_dump_json(),
    )
    return report.model_dump_json()


def _locals_overlap(test_code: str, variables: dict) -> bool:
    if not test_code or not variables:
        return False
    keys = [k for k in variables.keys() if isinstance(k, str)]
    return any(k in test_code for k in keys[:20])


# ---- 6. web_search -------------------------------------------------------

async def _tool_web_search(
    query: str, session_id: str,
    source: str = "general", package: str = "",
) -> str:
    audit = _get_audit(session_id)
    hits = await _web_search_backend(query, source=source, package=package)
    audit.log_dep_resolution(
        intent=f"web_search[{source}]: {query[:120]}",
        name=package or query[:64], version="", pypi_url="",
    )
    return json.dumps({"hits": hits[:8], "source": source, "advisory_only": True})


async def _web_search_backend(query: str, source: str, package: str) -> list[dict]:
    tavily_key = os.getenv("TAVILY_API_KEY", "").strip()
    if tavily_key:
        try:
            import httpx  # type: ignore
            async with httpx.AsyncClient(timeout=10) as client:
                resp = await client.post(
                    "https://api.tavily.com/search",
                    json={"api_key": tavily_key, "query": query,
                          "search_depth": "basic",
                          "include_domains": _domains_for_source(source),
                          "max_results": 8},
                )
                if resp.status_code == 200:
                    data = resp.json()
                    return [
                        {"title": r.get("title", ""), "url": r.get("url", ""),
                         "snippet": (r.get("content") or "")[:500]}
                        for r in data.get("results", [])
                    ]
        except Exception as e:
            log.warning("tavily search failed: %s", e)
    if source == "pypi" and package:
        try:
            import httpx  # type: ignore
            async with httpx.AsyncClient(timeout=8) as client:
                resp = await client.get(f"https://pypi.org/pypi/{package}/json")
                if resp.status_code == 200:
                    data = resp.json()
                    info = data.get("info", {})
                    releases = sorted((data.get("releases") or {}).keys(), reverse=True)[:10]
                    return [{
                        "title": f"{package} {info.get('version', '')}",
                        "url": info.get("project_url", "")
                            or f"https://pypi.org/project/{package}/",
                        "snippet": (info.get("summary") or "") + f" | recent: {releases}",
                    }]
        except Exception as e:
            log.warning("pypi probe failed: %s", e)
    hook = os.getenv("LOGOMESH_WEB_HOOK", "").strip()
    if hook and ":" in hook:
        try:
            mod, attr = hook.split(":", 1)
            import importlib
            fn = getattr(importlib.import_module(mod), attr)
            res = fn(query=query, source=source, package=package)
            if asyncio.iscoroutine(res):
                res = await res
            if isinstance(res, list):
                return res
        except Exception as e:
            log.warning("LOGOMESH_WEB_HOOK failed: %s", e)
    return [{"title": "(offline)", "url": "",
             "snippet": "no web backend configured; set TAVILY_API_KEY or LOGOMESH_WEB_HOOK"}]


def _domains_for_source(source: str) -> list[str]:
    return {
        "pypi": ["pypi.org"], "github": ["github.com"],
        "stackoverflow": ["stackoverflow.com"],
        "cve": ["nvd.nist.gov", "github.com/advisories", "osv.dev"],
        "general": [],
    }.get(source, [])


# ---- 7. rag_search -------------------------------------------------------

async def _tool_rag_search(
    query: str, session_id: str, namespace: str = "all", k: int = 5,
) -> str:
    audit = _get_audit(session_id)
    hits: list[dict] = []

    # `namespace='memory'` was a ReproMemory hook; learning layer cut
    # 2026-05-06 (zero uplift in A/B test). Left as a no-op fall-through.

    ruflo_hook = os.getenv("LOGOMESH_RUFLO_RAG_HOOK", "").strip()
    if ruflo_hook and ":" in ruflo_hook and not hits:
        try:
            mod, attr = ruflo_hook.split(":", 1)
            import importlib
            fn = getattr(importlib.import_module(mod), attr)
            res = fn(query=query, namespace=namespace, k=k)
            if asyncio.iscoroutine(res):
                res = await res
            if isinstance(res, list):
                hits.extend(res)
        except Exception as e:
            log.warning("ruflo RAG hook failed: %s", e)

    if not hits or namespace in {"codebase", "docs"}:
        index_path = os.getenv("LOGOMESH_RAG_INDEX", "").strip()
        if index_path and Path(index_path).exists():
            try:
                hits.extend(await asyncio.to_thread(_local_index_query, index_path, query, k))
            except Exception as e:
                log.warning("local RAG index failed: %s", e)

    if not hits:
        hits = await asyncio.to_thread(_grep_fallback, query, namespace, k)

    audit.log_llm_call(
        intent=f"rag_search[{namespace}]: {query[:120]}",
        model="rag-adapter", prompt=query, response=json.dumps(hits)[:4000],
    )
    return json.dumps({"hits": hits[:k], "namespace": namespace, "advisory_only": True})


def _crash_signature_from_session(session_id: str) -> str:
    entry = _EVENT_REGISTRY.get(session_id)
    if not entry:
        return ""
    snap = entry["snapshot"]
    fr = snap.get("frame") or {}
    return _crash_signature(snap.get("error_type", ""), fr.get("function", ""), fr.get("filename", ""))


def _local_index_query(index_path: str, query: str, k: int) -> list[dict]:
    try:
        from langchain_community.vectorstores import FAISS  # type: ignore
        from langchain_openai import OpenAIEmbeddings  # type: ignore
    except ImportError:
        return []
    emb = OpenAIEmbeddings(model="text-embedding-3-small")
    store = FAISS.load_local(index_path, emb, allow_dangerous_deserialization=True)
    docs = store.similarity_search(query, k=k)
    return [{"title": d.metadata.get("source", ""), "snippet": d.page_content[:600],
             "url": d.metadata.get("source", "")} for d in docs]


def _grep_fallback(query: str, namespace: str, k: int) -> list[dict]:
    import subprocess
    roots: list[Path] = []
    if namespace in {"codebase", "all"}:
        roots.append(_REPO_ROOT / "src")
    if namespace in {"past_runs", "all"}:
        roots.append(Path(os.path.expanduser("~/.cache/logomesh/session_audit")))
    if namespace in {"docs", "all"}:
        roots.append(_REPO_ROOT / "docs")
    hits: list[dict] = []
    needle = query.split()[0] if query else ""
    if not needle:
        return hits
    for root in roots:
        if not root.exists():
            continue
        try:
            out = subprocess.run(
                ["grep", "-r", "-n", "-l", "--", needle, str(root)],
                capture_output=True, text=True, timeout=4,
            )
            for line in (out.stdout or "").splitlines()[:k]:
                p = Path(line.strip())
                if p.is_file():
                    hits.append({
                        "title": (str(p.relative_to(_REPO_ROOT))
                                  if str(p).startswith(str(_REPO_ROOT)) else str(p)),
                        "url": "", "snippet": p.read_text(errors="replace")[:400],
                    })
        except Exception:
            continue
    return hits[:k]


# ---- 8. recall_memory tool — REMOVED 2026-05-06 --------------------------
# A/B test (scripts/ab_test_learning_layer.py) on 18 fixtures × 2 passes
# showed zero uplift from cross-run learning. Tool removed; ReproMemory class
# replaced with no-op stub. Snapshot in
# logomesh_legacy/agentbeats_evolvers/_extracted_classes.py.txt.


# ---- 9. build_artifact (reads sacred state ONLY) -------------------------

async def _tool_build_artifact(
    session_id: str, repo_path: str = ".", pr_url: str = "",
) -> str:
    audit = _get_audit(session_id)
    repro = _REPRO_REGISTRY.get(session_id)
    entry = _EVENT_REGISTRY.get(session_id)
    if repro is None or entry is None:
        return json.dumps({"error": "no sealed repro available"})
    if not repro.sealed:
        return json.dumps({"error": "repro not sealed; refuse to build artifact"})

    branch, commit = await asyncio.to_thread(get_git_metadata, str(repo_path))
    artifact = await asyncio.to_thread(
        render_artifact,
        entry["exc"], entry["frame"],
        {"success": True, "passed": repro.passed, "failed": repro.failed,
         "total": repro.total, "duration": repro.duration,
         "output": repro.sandbox_output, "sandbox_mode": repro.sandbox_mode},
        branch, commit, repro.sandbox_mode, "", pr_url,
    )
    # Attach session audit log to the artifact for compliance review
    # (cli.artifact.render_artifact no longer accepts an audit_log kwarg).
    artifact["session_audit"] = audit.render()
    artifact["attestation"] = (
        "Repro generated deterministically from frame locals "
        "(zero LLM in evidence path). Agent reasoning provided for "
        "human review only."
    )
    artifact["evidence_path_seal"] = {
        "sealed": True,
        "test_sha256_first16": _hash16(repro.test_code),
        "synthesizer": "frame-locals → pytest (deterministic)",
        "llm_in_evidence_path": False,
        "sandbox_exception_type": repro.sandbox_exception_type,
        "expected_exception_type": repro.error_type,
        "verified_exception_match": repro.verified_exception_match,
    }
    # Advisory infra block — NOT inside evidence_path_seal. Records what the
    # agent did to make the sandbox runnable (deps added, CVE advisories) so
    # the audit trail explains WHY the repro could execute, without claiming
    # this content is part of the sealed evidence.
    env_state = _ENV_REGISTRY.get(session_id) or {}
    if env_state.get("snapshot_path") or env_state.get("added"):
        artifact["environment_prep"] = {
            "snapshot_path": env_state.get("snapshot_path", ""),
            "deps_added": list(env_state.get("added") or []),
            "base_specs_count": len(env_state.get("base_specs") or []),
            "in_evidence_path": False,
            "note": "advisory infrastructure; sealed test bytes are unchanged",
        }
    return json.dumps(artifact)


def _hash16(s: str) -> str:
    import hashlib
    return hashlib.sha256(s.encode("utf-8", errors="replace")).hexdigest()[:16]


# ---- 9b. prepare_environment (advisory infra; NOT evidence path) ---------

# Map of well-known import name → canonical PyPI distribution name. Reduces
# round-trips to PyPI for the common cases. Anything not here falls through to
# a name == module assumption (validated by the PyPI probe in web_search).
_IMPORT_TO_PYPI = {
    "PIL": "Pillow", "cv2": "opencv-python", "yaml": "PyYAML",
    "sklearn": "scikit-learn", "bs4": "beautifulsoup4",
    "psycopg2": "psycopg2-binary", "MySQLdb": "mysqlclient",
    "google": "google-api-core", "Crypto": "pycryptodome",
    "magic": "python-magic", "dotenv": "python-dotenv",
    "jose": "python-jose", "dateutil": "python-dateutil",
    "OpenSSL": "pyOpenSSL", "concurrent": "futures",  # py2 holdovers
    "redis": "redis", "celery": "celery", "stripe": "stripe",
    "httpx": "httpx", "requests": "requests",
    "sqlalchemy": "SQLAlchemy", "fastapi": "fastapi",
    "pydantic": "pydantic", "django": "Django", "flask": "Flask",
}


def _gather_repo_dependency_files(repo_path: str) -> dict[str, str]:
    """Collect manifest contents from the repo for dep_installer.parse_dep_specs.

    Reads (when present): pyproject.toml, requirements.txt, requirements/*.txt,
    Pipfile. Bounded read size per file to keep memory predictable.
    """
    out: dict[str, str] = {}
    root = Path(repo_path).resolve()
    if not root.is_dir():
        return out
    candidates: list[Path] = []
    for name in ("pyproject.toml", "requirements.txt", "Pipfile"):
        p = root / name
        if p.is_file():
            candidates.append(p)
    req_dir = root / "requirements"
    if req_dir.is_dir():
        candidates.extend(sorted(p for p in req_dir.glob("*.txt") if p.is_file()))
    for p in candidates[:8]:  # cap manifests
        try:
            out[p.name] = p.read_text(errors="replace")[:128_000]
        except Exception:
            continue
    return out


def _missing_modules_from_error(text: str) -> list[str]:
    """Extract import names from sandbox stderr/stdout. Best-effort regex."""
    names: list[str] = []
    if not text:
        return names
    for pat in (
        r"No module named ['\"]([A-Za-z_][\w]*)",
        r"ModuleNotFoundError:\s+No module named ['\"]([A-Za-z_][\w]*)",
        r"ImportError:\s+cannot import name ['\"][^'\"]+['\"] from ['\"]([A-Za-z_][\w.]*)['\"]",
    ):
        for m in re.findall(pat, text):
            base = m.split(".", 1)[0]
            if base and base not in names:
                names.append(base)
    return names


def _module_to_pypi(name: str) -> str:
    return _IMPORT_TO_PYPI.get(name, name)


async def _tool_introspect_repo(
    session_id: str,
    repo_path: str = ".",
    focus: str = "all",
    name_filter: str = "",
) -> str:
    """ADVISORY RAG TOOL — returns a JSON window into the repo.

    Reproduction-first policy: the agent should call this BEFORE
    declaring a crash unreproducible. The output is evidence —
    imports, manifest deps, config files, entrypoints, class shapes,
    callable signatures + decorators. No framework decisions are
    made here; the agent reasons over the evidence and (if useful)
    calls `plan_sandbox` / `materialize_object` / re-runs
    `deterministic_repro` with a richer bootstrap.
    """
    import json as _json
    import re as _re
    from business_logic.repo_introspection import scan_repo

    try:
        intro = scan_repo(repo_path)
    except Exception as e:
        return _json.dumps({"error": str(e), "type": type(e).__name__})

    out: dict[str, Any] = {
        "root": intro.root,
        "files_scanned": intro.files_scanned,
    }

    pattern = _re.compile(name_filter) if name_filter else None

    if focus in {"all", "manifests"}:
        out["manifests"] = [
            {
                "path": m.path,
                "requires_python": m.requires_python,
                "dependencies": m.dependencies[:40],
                "entry_points": m.entry_points,
            }
            for m in intro.manifests
        ]

    if focus in {"all", "imports"}:
        top = sorted(intro.imports_seen.items(), key=lambda kv: -kv[1])[:40]
        out["top_imports"] = [{"module": m, "count": c} for m, c in top]

    if focus in {"all", "config"}:
        out["config_files"] = intro.config_files[:20]
        out["entrypoint_modules"] = intro.entrypoint_modules[:20]

    if focus in {"all", "classes"}:
        classes = intro.classes
        if pattern:
            classes = [c for c in classes if pattern.search(c.name)]
        out["classes"] = [
            {
                "name": c.name,
                "bases": c.bases,
                "decorators": c.decorators,
                "file": c.file,
                "lineno": c.lineno,
                "field_count": len(c.fields),
                "fields_preview": c.fields[:8],
            }
            for c in classes[:40]
        ]

    if focus in {"all", "callables"}:
        callables = intro.callables
        if pattern:
            callables = [c for c in callables if pattern.search(c.name)]
        out["callables"] = [
            {
                "name": c.name,
                "decorators": c.decorators,
                "args": c.args,
                "is_async": c.is_async,
                "file": c.file,
                "lineno": c.lineno,
            }
            for c in callables[:40]
        ]

    if focus == "all":
        out["evidence_summary"] = {
            "manifest_deps": len(intro.evidence_for("manifest_dep")),
            "imports": len(intro.evidence_for("import")) + len(intro.evidence_for("import_from")),
            "config_files": len(intro.evidence_for("config_file")),
            "entrypoints": len(intro.evidence_for("entrypoint")),
        }

    return _json.dumps(out, default=str)[:18000]  # bound prompt size


async def _tool_prepare_environment(
    session_id: str,
    repo_path: str = ".",
    sandbox_error: str = "",
    max_extra_packages: int = 8,
    module_versions: dict[str, str] | None = None,
) -> str:
    """Build a wheel snapshot the sandbox can mount r/o at /deps.

    Pipeline:
      1. parse manifests in repo → base specs
      2. extract missing-module names from `sandbox_error`
      3. map each → PyPI dist name via dep_installer
      4. **Override versions from `module_versions` when supplied** —
         this is `exc.modules` from the Sentry payload (pip freeze at
         crash time). Pins to prod versions, not manifest versions.
      5. dep_installer.prepare_snapshot(specs) → snapshot path

    NOT in evidence path. Output is wheel files only; never test code.
    """
    audit = _get_audit(session_id)

    try:
        from business_logic.sandbox import dep_installer  # type: ignore
    except Exception as e:
        return json.dumps({
            "error": f"dep_installer unavailable: {e}",
            "advisory_only": True,
        })

    dep_files = await asyncio.to_thread(_gather_repo_dependency_files, repo_path)
    base_specs = dep_installer.parse_dep_specs(dep_files)

    # Override manifest-declared versions with the exact prod pin (modules
    # dict from Sentry payload). Closes the prod-vs-dev drift gap that
    # otherwise makes sandbox repros pass while prod still crashes.
    pins_lookup = {
        k.lower(): str(v).strip()
        for k, v in (module_versions or {}).items()
        if v and str(v).strip()
    }
    pinned_count = 0
    if pins_lookup:
        rewritten: list[str] = []
        for spec in base_specs:
            head = (
                spec.lower().split("[", 1)[0].split("=", 1)[0]
                .split("<", 1)[0].split(">", 1)[0].split("~", 1)[0]
                .split("!", 1)[0].strip()
            )
            if head in pins_lookup:
                rewritten.append(f"{head}=={pins_lookup[head]}")
                pinned_count += 1
            else:
                rewritten.append(spec)
        base_specs = rewritten

    missing_modules = _missing_modules_from_error(sandbox_error)[:max_extra_packages]
    extra_specs: list[str] = []
    for mod in missing_modules:
        pkg = _module_to_pypi(mod)
        # Skip if the manifest already declares it (case-insensitive prefix).
        already = any(
            (s.lower().split("[", 1)[0].split("=", 1)[0]
             .split("<", 1)[0].split(">", 1)[0].strip()
             == pkg.lower())
            for s in base_specs
        )
        if already:
            continue
        # Prefer the prod-pinned version (from exc.modules) when present.
        pinned = pins_lookup.get(pkg.lower())
        if pinned:
            extra_specs.append(f"{pkg}=={pinned}")
            pinned_count += 1
            continue
        version = await asyncio.to_thread(dep_installer.fetch_latest_pypi_version, pkg)
        spec = f"{pkg}=={version}" if version else pkg
        extra_specs.append(spec)

    all_specs = list(base_specs) + extra_specs
    # Cache probe via prepare_snapshot's own _cache_key; if nothing to install
    # we still return success so the caller can re-run sandbox without snapshot.
    if not all_specs:
        result = {
            "snapshot_path": "",
            "base_specs": [], "added": [],
            "advisory_only": True,
            "note": "no dependencies declared in repo and no missing modules detected",
        }
        _ENV_REGISTRY[session_id] = {
            "snapshot_path": "", "added": [],
            "auto_retry_done": _ENV_REGISTRY.get(session_id, {}).get("auto_retry_done", False),
        }
        return json.dumps(result)

    # Construct a fake "pyproject.toml" so dep_installer treats `all_specs` as
    # the install set (its public API takes manifests, not raw specs).
    synthesized = (
        '[project]\nname = "logomesh-prep"\nversion = "0.0.0"\n'
        + "dependencies = [\n"
        + "".join(f'  "{s}",\n' for s in all_specs)
        + "]\n"
    )
    snapshot_path = await asyncio.to_thread(
        dep_installer.prepare_snapshot,
        {"pyproject.toml": synthesized},
        include_prior_pin=False,  # never anchor to logomesh's own pkg name
    )
    if not snapshot_path:
        result = {
            "snapshot_path": "",
            "base_specs": list(base_specs), "added": extra_specs,
            "advisory_only": True,
            "error": "snapshot build failed (docker unavailable, "
                     "resolution conflict, or transient PyPI failure)",
        }
        _ENV_REGISTRY[session_id] = {"snapshot_path": "", "added": extra_specs}
        return json.dumps(result)

    audit.log_dep_resolution(
        intent="prepare_environment snapshot built",
        name=",".join(extra_specs)[:200] or "<base only>",
        version="", pypi_url="",
    )
    _ENV_REGISTRY[session_id] = {
        "snapshot_path": snapshot_path,
        "added": extra_specs,
        "base_specs": list(base_specs),
        "pinned_from_sentry_modules": pinned_count,
        "auto_retry_done": _ENV_REGISTRY.get(session_id, {}).get("auto_retry_done", False),
    }
    return json.dumps({
        "snapshot_path": snapshot_path,
        "base_specs": list(base_specs),
        "added": extra_specs,
        "pinned_from_sentry_modules": pinned_count,
        "advisory_only": True,
    })


# ---- 10. create_draft_pr -------------------------------------------------

async def _tool_create_draft_pr(session_id: str, repo_path: str = ".") -> str:
    repro = _REPRO_REGISTRY.get(session_id)
    entry = _EVENT_REGISTRY.get(session_id)
    if repro is None or entry is None:
        return json.dumps({"error": "no sealed repro available"})
    if not repro.reproduced:
        return json.dumps({"skipped": True, "reason": "did not reproduce; no PR opened"})
    secrets = _SECRETS_REGISTRY.get(session_id)
    gh_token = (secrets.github_token if secrets else "") or None
    gh_repo = (secrets.github_repo if secrets else "") or os.getenv("GITHUB_REPO", "") or None
    try:
        url = await asyncio.to_thread(
            _create_draft_pr,
            Path(repo_path), entry["snapshot"]["issue_id"],
            repro.test_code, entry["exc"], entry["frame"],
            {"success": True, "passed": repro.passed, "failed": repro.failed,
             "total": repro.total, "duration": repro.duration,
             "output": repro.sandbox_output, "sandbox_mode": repro.sandbox_mode},
            None,  # artifact (positional)
            github_token=gh_token,
            github_repo=gh_repo,
        )
        return json.dumps({"pr_url": url})
    except Exception as e:
        return json.dumps({"error": f"draft PR failed: {e}"})


# ==========================================================================
# 6. STRUCTURED TOOL OBJECTS
# ==========================================================================

def _build_tools() -> list[StructuredTool]:
    return [
        StructuredTool.from_function(
            coroutine=_tool_fetch_sentry_event, name="fetch_sentry_event",
            description=(
                "Fetch a Sentry issue's full stacktrace, frame locals, "
                "breadcrumbs, and trace id. Always call this first."
            ),
            args_schema=FetchSentryArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_deterministic_repro, name="deterministic_repro",
            description=(
                "SACRED: synthesize a pytest from frame locals (zero LLM) and "
                "run it in the Docker sandbox. The ONLY tool whose output "
                "reaches the artifact and PR. Call after fetch_sentry_event "
                "and after any RAG/web/memory enrichment your strategy dictates."
            ),
            args_schema=DeterministicReproArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_hypothesis_invariant_suggester,
            name="hypothesis_invariant_suggester",
            description=(
                "ADVISORY ONLY: ask the LLM for Hypothesis property tests "
                "that would have caught this crash. Recorded for human "
                "review. NEVER affects the artifact."
            ),
            args_schema=HypothesisSuggesterArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_context_reconstructor, name="context_reconstructor",
            description=(
                "Use when frame locals alone are insufficient (async tasks, "
                "DB state, globals, C-extensions, missing fixtures). Inspects "
                "full Sentry trace + breadcrumbs and proposes a fixture "
                "strategy. Advisory; flag human_review when stuck."
            ),
            args_schema=ContextReconstructorArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_critic_validate, name="critic_validate",
            description=(
                "Score fidelity (0..1) between the sealed deterministic repro "
                "and the original Sentry event. Returns same_exception, "
                "same_function, locals_match, blockers."
            ),
            args_schema=CriticValidateArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_web_search, name="web_search",
            description=(
                "Search the open web (PyPI, GitHub issues, StackOverflow, CVE "
                "feeds) for known issues with the dependencies and the "
                "exception type. USE THIS BEFORE deterministic_repro if your "
                "evolved strategy is `dep_check_first` or any dep version "
                "looks suspicious or recent."
            ),
            args_schema=WebSearchArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_rag_search, name="rag_search",
            description=(
                "Search internal knowledge: codebase, past repro audit logs, "
                "ReproMemory (namespace='memory'), project docs."
            ),
            args_schema=RagSearchArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_build_artifact, name="build_artifact",
            description=(
                "Build the SOC2/PCI compliance artifact from the SEALED "
                "deterministic repro. Refuses if no sealed repro exists."
            ),
            args_schema=BuildArtifactArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_create_draft_pr, name="create_draft_pr",
            description=(
                "Open a draft GitHub PR with the deterministic test and the "
                "artifact attached. Skipped if the repro did not reproduce."
            ),
            args_schema=CreateDraftPrArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_prepare_environment, name="prepare_environment",
            description=(
                "ADVISORY INFRA — NOT in evidence path. Build a wheel snapshot "
                "the sandbox can mount r/o at /deps. Pulls deps from repo "
                "manifests (pyproject.toml / requirements.txt), and if "
                "`sandbox_error` contains ModuleNotFoundError / ImportError, "
                "auto-adds those packages too (latest PyPI version, optional "
                "CVE advisory). Call this when deterministic_repro returns an "
                "import-failure output, or proactively when a target file "
                "imports unusual dependencies. The deterministic_repro tool "
                "auto-invokes this once on import failure as a safety net."
            ),
            args_schema=PrepareEnvironmentArgs,
        ),
        StructuredTool.from_function(
            coroutine=_tool_introspect_repo, name="introspect_repo",
            description=(
                "ADVISORY RAG — NOT in evidence path. Returns raw repo "
                "evidence: imports, manifest deps, config files, entrypoints, "
                "class shapes, callable decorators. This tool does NOT make "
                "decisions or suggest routing — it reports facts and you "
                "decide what to do with them. Call it when you need to "
                "understand the repo before retrying deterministic_repro."
            ),
            args_schema=IntrospectRepoArgs,
        ),
    ]


TOOLS = _build_tools()
TOOLS_BY_NAME = {t.name: t for t in TOOLS}


# ==========================================================================
# 7. PROMPTS
# ==========================================================================

SUPERVISOR_SYSTEM_PROMPT_TEMPLATE = """\
You are logomeshOrchestrator — an autonomous agent that reproduces production
Python crashes from Sentry events. You operate under a hard compliance contract:

═══════════════════════════════════════════════════════════════════════════
COMPLIANCE CONTRACT (do not violate, ever)
═══════════════════════════════════════════════════════════════════════════
1. The final artifact and draft PR contain ONLY output from the
   `deterministic_repro` tool. You do NOT write tests. You do NOT modify
   the test the deterministic synthesizer produces. You do NOT pass
   LLM-generated code through `build_artifact` or `create_draft_pr`.
2. Your reasoning, tool calls, and suggestions are recorded in the audit
   session for human review. They are advisory only.
3. The artifact must end up with the attestation:
   "Repro generated deterministically from frame locals
    (zero LLM in evidence path). Agent reasoning provided for human
    review only."
═══════════════════════════════════════════════════════════════════════════

{strategy_block}

{memory_block}

WORKFLOW (follow the evolved tool_order; default below):

  1. fetch_sentry_event — pull the full event.
  2. ENRICHMENT (interleave per strategy):
     - rag_search(namespace='codebase'|'docs')
     - web_search(source='pypi'|'github'|'stackoverflow'|'cve') for any
       traceback dependency, especially if `proactive_dep_check` is True.
     - context_reconstructor when locals look insufficient (async / DB /
       globals / C-ext / missing fixture). If `proactive_context_recon` is
       True, call this BEFORE the first deterministic_repro.
     - hypothesis_invariant_suggester (advisory only).
  3. deterministic_repro — sacred zero-LLM tool.
     • If output contains ModuleNotFoundError / ImportError, the tool
       auto-invokes `prepare_environment` once. You may also call
       `prepare_environment` proactively (e.g. when the target imports
       `stripe`, `redis`, `celery`, etc.) BEFORE the first repro to
       avoid the auto-retry round-trip.
     • `prepare_environment` is ADVISORY INFRA — it builds a wheel
       snapshot mounted r/o at /deps. Output is wheel files only, never
       test code; it does NOT touch `evidence_path_seal`.
     • If output contains `"reason": "source_not_found"` and
       `"retryable": true`, DO NOT flag human_review yet. Recovery loop:
         (a) read the response's `basename` and `module_guess`.
         (b) call rag_search(namespace='codebase', query=<basename>) AND
             web_search(source='github', query="<basename> <module_guess>
             python") to recover candidate paths.
         (c) re-invoke deterministic_repro with `path_hints=[paths…]`.
       After one retry exhausts (`source_not_found_retry_exhausted`),
       THEN flag human_review.
  5. critic_validate    — fidelity score. The graph routes you back if
                          fidelity < threshold and attempts remain. Use the
                          critic's blockers + any new ContextNotes from the
                          internal Scientific engine to choose your next
                          enrichment step. You may NOT modify the test.
  6. build_artifact, then create_draft_pr (only if repro succeeded).

HARD PRIORITY RULES:
  • If a deterministic_repro result exists, your NEXT call must be
    `critic_validate`. Do not gather more context first.
  • After critic feedback, only gather the specific missing context named
    in blockers; then run deterministic_repro again.
  • Avoid loops. Move to critic/finalizer decisively.

AGENT-FIRST, TOOLS-SECOND (read this carefully):
  The tools expose facts and execute decisions. YOU decide. No tool
  in this graph routes the strategy for you — they return evidence
  and primitives. `introspect_repo` returns raw imports, class shapes,
  manifest deps; it does NOT tell you which framework you're seeing.
  `prepare_environment` builds a wheel snapshot from explicit inputs;
  it does NOT decide whether the snapshot is needed.

  Your reasoning IS the strategy. Read the evidence. Form a hypothesis
  about what kind of repo this is and what the crash needs. Pick tool
  calls that test that hypothesis. Update the hypothesis when the
  evidence contradicts it.

REPRODUCTION-FIRST POLICY:
  Reproducing the crash is the goal. The hypothesis report shipped on
  human_review is a LAST-RESORT fallback. Before routing to human_review,
  you MUST have:
    (a) called `introspect_repo` to gather evidence (imports, classes,
        decorators, manifest deps, config files)
    (b) reasoned about what bootstrap the sandbox actually needs given
        that evidence (don't pattern-match — explain it to yourself
        in the audit log)
    (c) called `deterministic_repro` AT LEAST ONCE on each meaningfully
        different bootstrap your reasoning suggests
    (d) on `frame_locals_insufficient`, asked `introspect_repo` for the
        relevant class definition, decided what kwargs to construct
        with, and retried.

WHEN TO FLAG human_review_needed (only after exhausting the above):
  • deterministic_repro returns `frame_locals_insufficient` AND
    context_reconstructor cannot find a tractable fixture strategy AND
    you have consulted `introspect_repo` for the relevant class shape.
  • C-extension or hardware state is involved (genuinely opaque).
  • Critic fidelity stays below 0.5 after max attempts.
  • Genuine race condition (multi-thread / multi-process) that needs
    threading.Barrier or two DB sessions to expose — you cannot
    synthesize that automatically today.

DO NOT flag human_review for:
  • Missing dependencies (call prepare_environment instead)
  • Unknown framework (call introspect_repo, reason, then bootstrap)
  • Source file not found (use the self-refusal retry with path_hints)
  • ORM instance in frame locals (introspect_repo → class shape →
    decide on kwargs → retry)

DEPENDENCY HANDLING:
  Always check pyproject.toml / requirements via rag_search BEFORE
  deterministic_repro if the traceback references third-party packages.
  If the dep is recent (<14 days) or has an open CVE, surface it.

DB / ASYNC / STATEFUL CRASHES:
  Frame locals are insufficient when the bug depends on global state
  (DB rows, Redis keys, FastAPI request context, asyncio task graph,
  module-level caches). In those cases:
    - Use breadcrumbs to reconstruct the lead-up (call sequence, DB ops).
    - Call context_reconstructor with `reason=db_state` / `async_state` /
      `globals` and propose a fixture in your plan.
    - Still call deterministic_repro — if it succeeds with the existing
      replay, great. If not, the Scientific engine will produce
      ContextNotes the critic loop can use.

You always think before acting. Use short, structured plans. Prefer
parallel tool calls when independent. Be decisive about when to stop
gathering context and run deterministic_repro.
"""


CRITIC_SYSTEM_PROMPT = """\
You are the logomesh Critic. Your job is narrow and rigorous: given the
sealed `repro_result` and the original Sentry event, return a fidelity
score in [0.0, 1.0] plus structured blockers.

Hard rules:
  • You DO NOT propose test code. You DO NOT propose fixes.
  • You ONLY return: {fidelity, same_exception_type, same_function,
    locals_match, feedback, blockers}.
  • Fidelity ≥ 0.9 means the deterministic test reproduces the same
    exception type at the same function with overlapping locals.
  • Fidelity < 0.9 means the supervisor must gather more context
    (NOT modify the test) and re-invoke deterministic_repro. Your
    `feedback` should tell them precisely what context is missing.
  • Be terse. Auditor-readable.
"""


def _render_supervisor_prompt(strategy: dict, memory: dict) -> str:
    return SUPERVISOR_SYSTEM_PROMPT_TEMPLATE.format(
        strategy_block=_EVOLVER.format_for_supervisor(strategy),
        memory_block=_MEMORY.format_for_supervisor(memory),
    )


def _max_supervisor_steps(state: OrchestratorState) -> int:
    configured = int(state.get("max_tool_calls", 0) or 0)
    if configured > 0:
        return configured
    # Safety rail default. Override with LOGOMESH_MAX_SUPERVISOR_STEPS or
    # per-run state.max_tool_calls.
    return max(1, int(os.getenv("LOGOMESH_MAX_SUPERVISOR_STEPS", "10")))


# ==========================================================================
# 8. LLM HELPERS
# ==========================================================================

# --------------------------------------------------------------------------
# LLM backend — self-hosted vLLM (Qwen Coder) by default.
#
# vLLM exposes an OpenAI-compatible HTTP API, so we drive it through
# `ChatOpenAI` / `AsyncOpenAI` with a custom base_url. To enable tool
# Default provider for the pilot is hosted OpenAI (gpt-5-mini). A fresh
# install reaches the production LLM with `OPENAI_API_KEY` alone — no
# vLLM, no GPU, no local server. vLLM remains supported via env opt-in
# for cost-sensitive deployments after first paying customer.
#
# To run with self-hosted vLLM Qwen-Coder instead:
#
#   vllm serve Qwen/Qwen2.5-Coder-32B-Instruct \
#       --enable-auto-tool-choice \
#       --tool-call-parser hermes \
#       --served-model-name qwen-coder \
#       --port 8000
#
#   LOGOMESH_LLM_PROVIDER=vllm
#   LOGOMESH_LLM_BASE_URL=http://localhost:8000/v1
#   LOGOMESH_LLM_API_KEY=EMPTY
#   LOGOMESH_ORCHESTRATOR_MODEL=qwen-coder
#   LOGOMESH_REPRO_MODEL=qwen-coder
#
# Or with Alibaba DashScope (Singapore region, qwen3-coder-plus):
#
#   LOGOMESH_LLM_PROVIDER=openai
#   LOGOMESH_LLM_BASE_URL=https://dashscope-intl.aliyuncs.com/compatible-mode/v1
#   LOGOMESH_LLM_API_KEY=<dashscope-key>
#   LOGOMESH_ORCHESTRATOR_MODEL=qwen3-coder-plus
#   LOGOMESH_REPRO_MODEL=qwen3-coder-plus
# --------------------------------------------------------------------------

def _llm_endpoint() -> tuple[str, str]:
    """Return (base_url, api_key) honoring the OpenAI-first default."""
    provider = os.getenv("LOGOMESH_LLM_PROVIDER", "openai").lower()
    base_url = os.getenv("LOGOMESH_LLM_BASE_URL", "").strip()
    api_key = os.getenv("LOGOMESH_LLM_API_KEY", "").strip()
    if provider == "vllm":
        if not base_url:
            base_url = "http://localhost:8000/v1"
        if not api_key:
            # vLLM accepts any non-empty token unless launched with --api-key.
            api_key = "EMPTY"
    else:
        # openai / dashscope / azure / any-OpenAI-compatible — fall through
        # to the canonical OPENAI_API_KEY when an explicit one is not set.
        api_key = api_key or os.getenv("OPENAI_API_KEY", "")
        # base_url stays empty → SDK uses default api.openai.com endpoint
        # unless the caller sets LOGOMESH_LLM_BASE_URL explicitly (DashScope,
        # Azure OpenAI, etc.).
    return base_url, api_key


def _default_model() -> str:
    return os.getenv("LOGOMESH_ORCHESTRATOR_MODEL", "gpt-5-mini")


def _advisory_model() -> str:
    return os.getenv("LOGOMESH_REPRO_MODEL", _default_model())


def _get_chat_model():
    """Bind TOOLS to whatever OpenAI-compatible chat backend is configured."""
    try:
        from langchain_openai import ChatOpenAI  # type: ignore
    except ImportError as e:
        raise ImportError(
            "langchain-openai required. pip install 'langchain-openai>=0.2'"
        ) from e
    base_url, api_key = _llm_endpoint()
    model_name = _default_model()
    # gpt-5-* / o-* reject any non-default temperature with HTTP 400.
    # Other models accept temperature=0 → keep determinism where possible.
    locked_temp = model_name.startswith("gpt-5") or model_name.startswith("o")
    kwargs: dict[str, Any] = {
        "model": model_name,
        "timeout": int(os.getenv("LOGOMESH_LLM_TIMEOUT", "60")),
        "max_retries": 1,
    }
    if not locked_temp:
        kwargs["temperature"] = 0
    if base_url:
        kwargs["base_url"] = base_url
    if api_key:
        kwargs["api_key"] = api_key
    return ChatOpenAI(**kwargs).bind_tools(TOOLS)


async def _llm_complete(prompt: str, max_tokens: int = 800) -> str:
    """One-shot completion against the configured backend (vLLM by default)."""
    try:
        from openai import AsyncOpenAI  # type: ignore
    except ImportError:
        return ""
    base_url, api_key = _llm_endpoint()
    if not api_key:
        return ""
    client_kwargs: dict[str, Any] = {"timeout": 30.0, "max_retries": 1, "api_key": api_key}
    if base_url:
        client_kwargs["base_url"] = base_url
    client = AsyncOpenAI(**client_kwargs)
    # gpt-5-* family rejected `max_tokens` and requires `max_completion_tokens`.
    # Try the new param first; fall back to the legacy one for older models.
    model_name = _advisory_model()
    is_gpt5 = model_name.startswith("gpt-5") or model_name.startswith("o")
    create_kwargs: dict[str, Any] = {
        "model": model_name,
        "messages": [{"role": "user", "content": prompt}],
    }
    # gpt-5-* / o-* reject `temperature` parameter (only default 1 allowed).
    if not is_gpt5:
        create_kwargs["temperature"] = 0
    create_kwargs["max_completion_tokens" if is_gpt5 else "max_tokens"] = max_tokens
    try:
        resp = await client.chat.completions.create(**create_kwargs)
        u = getattr(resp, "usage", None)
        if u is not None:
            add_usage(
                getattr(u, "prompt_tokens", 0) or 0,
                getattr(u, "completion_tokens", 0) or 0,
                model=model_name,
            )
            check_budget()
        return (resp.choices[0].message.content or "").strip()
    except TokenBudgetExceeded:
        # Bubble up — handle_sentry_webhook converts this to human_review.
        raise
    except Exception as e:
        log.warning("llm_complete failed: %s", e)
        return ""


# ==========================================================================
# 9. GRAPH NODES
# ==========================================================================

async def supervisor_node(state: OrchestratorState) -> dict:
    """LLM-driven planner. Pure (no side effect on sacred state)."""
    sid = state.get("audit_session_id", "")
    strategy = state.get("strategy_config") or REPRO_DEFAULT_STRATEGY
    sig = _crash_signature_from_session(sid)
    memory_snapshot: dict = {"has_history": False}  # learning layer cut 2026-05-06

    sys_msg = SystemMessage(content=_render_supervisor_prompt(strategy, memory_snapshot))
    history = state.get("messages", [])
    if not history:
        evt = state.get("event_id", "")
        org = state.get("org") or ""
        history = [HumanMessage(content=(
            f"Reproduce Sentry event_id={evt} org={org!r}. "
            f"session_id={sid!r}. repo_path={state.get('repo_path', '.')!r}. "
            "Begin with fetch_sentry_event, then follow the default "
            "tool_order (rag/web enrichment as needed, then "
            "deterministic_repro, then critic_validate)."
        ))]
    response = await _get_chat_model().ainvoke([sys_msg, *history])

    # Token accounting + budget enforcement. ChatOpenAI exposes
    # `usage_metadata` on AIMessage with keys input_tokens / output_tokens.
    # Some providers omit it; treat absence as zero rather than failing.
    usage_meta = getattr(response, "usage_metadata", None) or {}
    if usage_meta:
        add_usage(
            int(usage_meta.get("input_tokens", 0) or 0),
            int(usage_meta.get("output_tokens", 0) or 0),
            model=_default_model(),
        )
        check_budget()

    step_count = int(state.get("step_count", 0)) + 1
    out: dict[str, Any] = {"messages": [response], "step_count": step_count}

    # On first supervisor pass, auto-seed strategy_config in state.
    if "strategy_config" not in state and sig:
        out["strategy_config"] = REPRO_DEFAULT_STRATEGY
        out["crash_signature"] = sig
    if step_count >= _max_supervisor_steps(state):
        out["needs_human_review"] = True
        out["human_review_reason"] = "orchestrator_max_steps_exceeded"
    return out


def supervisor_router(state: OrchestratorState) -> Literal["tools", "critic_gate", "finalizer"]:
    if int(state.get("step_count", 0)) >= _max_supervisor_steps(state):
        sid = state.get("audit_session_id", "")
        if sid in _REPRO_REGISTRY and state.get("critic_report") is None:
            return "critic_gate"
        return "finalizer"

    msgs = state.get("messages", [])
    if not msgs:
        return "finalizer"
    last = msgs[-1]
    tool_calls = getattr(last, "tool_calls", None) or []
    if tool_calls:
        return "tools"
    sid = state.get("audit_session_id", "")
    if sid in _REPRO_REGISTRY and state.get("critic_report") is None:
        return "critic_gate"
    if state.get("critic_report") is not None:
        return "finalizer"
    return "finalizer"


async def critic_node(state: OrchestratorState) -> dict:
    """Run deterministic critic. If fidelity low, invoke ScientificContextEngine
    to produce structured ContextNotes for the supervisor's next attempt.

    REUSED: Scientific Method engine pattern — Observe→Hypothesize→
            Experiment→Verify, but adapted to refine the *environment*
            of a deterministic repro rather than a vulnerability claim.
    """
    sid = state.get("audit_session_id", "")
    raw = await _tool_critic_validate(session_id=sid)
    try:
        report = CriticReport.model_validate_json(raw)
    except Exception as e:
        log.warning("critic parse failed: %s; raw=%s", e, raw[:200])
        report = CriticReport(
            fidelity=0.0, same_exception_type=False, same_function=False,
            locals_match=False, feedback=f"critic parse error: {e}",
            blockers=["critic_parse_error"],
        )
    attempts = int(state.get("critic_attempts", 0)) + 1
    strategy = state.get("strategy_config") or REPRO_DEFAULT_STRATEGY
    threshold = float(strategy.get("fidelity_threshold", MIN_FIDELITY_FOR_SHIP))
    max_attempts = int(strategy.get("max_attempts", MAX_CRITIC_ATTEMPTS))

    out: dict[str, Any] = {"critic_report": report, "critic_attempts": attempts}

    if report.fidelity < threshold and attempts < max_attempts:
        # Invoke Scientific engine for structured re-plan guidance.
        new_notes: list[ContextNote] = []
        new_findings: list[dict] = []
        entry = _EVENT_REGISTRY.get(sid)
        repro = _REPRO_REGISTRY.get(sid)
        if entry and repro:
            try:
                findings = await _SCIENCE.investigate(
                    entry["snapshot"], repro.model_dump(), sid,
                )
                for f in findings:
                    new_findings.append({
                        "hypothesis_id": f.hypothesis.id,
                        "statement": f.hypothesis.statement,
                        "strategy": f.suggested_strategy,
                        "confidence": f.confidence,
                        "proof": f.proof,
                    })
                    kind_map = {
                        "H_DB": "db", "H_ASYNC": "async",
                        "H_GLOBALS": "globals", "H_DEPS": "deps",
                    }
                    new_notes.append(ContextNote(
                        kind=kind_map.get(f.hypothesis.id, "other"),
                        summary=f.hypothesis.statement,
                        suggested_fixture=f.suggested_strategy,
                        confidence=f.confidence,
                        strategy=f.suggested_strategy,
                    ))
            except Exception as e:
                log.warning("ScientificContextEngine failed: %s", e)

        feedback_lines = [
            f"[Critic] fidelity={report.fidelity:.2f} "
            f"(attempt {attempts}/{max_attempts}). Blockers: {report.blockers}.",
            f"Feedback: {report.feedback}",
        ]
        if new_findings:
            feedback_lines.append("Scientific engine confirmed:")
            for f in new_findings:
                feedback_lines.append(
                    f"  • {f['hypothesis_id']}: {f['statement']} "
                    f"→ try strategy `{f['strategy']}` (conf={f['confidence']:.2f})"
                )
        feedback_lines.append(
            "Gather more context (rag_search/web_search/context_reconstructor "
            "with the suggested strategies), then call deterministic_repro again. "
            "Do NOT modify the test code yourself."
        )
        out["messages"] = [HumanMessage(content="\n".join(feedback_lines))]
        out["context_notes"] = new_notes
        out["scientific_findings"] = new_findings
        # Wipe sealed repro so the supervisor must re-run it.
        if sid in _REPRO_REGISTRY:
            del _REPRO_REGISTRY[sid]
    else:
        if report.fidelity >= threshold:
            # Capture which strategy "won" for memory persistence.
            notes = state.get("context_notes") or []
            winning = next((n.strategy for n in reversed(notes) if n.strategy), "")
            if not winning:
                winning = (state.get("strategy_config") or {}).get("_strategy_name", "")
            out["winning_strategy"] = winning
    return out


def critic_router(state: OrchestratorState) -> Literal["supervisor", "finalizer"]:
    report = state.get("critic_report")
    attempts = int(state.get("critic_attempts", 0))
    strategy = state.get("strategy_config") or REPRO_DEFAULT_STRATEGY
    threshold = float(strategy.get("fidelity_threshold", MIN_FIDELITY_FOR_SHIP))
    max_attempts = int(strategy.get("max_attempts", MAX_CRITIC_ATTEMPTS))
    if report is None:
        return "finalizer"
    if report.fidelity >= threshold:
        return "finalizer"
    if attempts >= max_attempts:
        return "finalizer"
    return "supervisor"


def _diagnose_no_repro_reason(state: OrchestratorState) -> str:
    """Decide *why* `_REPRO_REGISTRY[sid]` is empty.

    Three real cases (was being conflated as "frame locals insufficient"):
      a) supervisor never emitted a `deterministic_repro` tool call
      b) tool ran and returned a structured refusal (frame_locals_insufficient,
         source_not_found_retry_exhausted, no usable in-app frame)
      c) tool was called but every attempt errored
    """
    msgs = state.get("messages", []) or []
    attempted = False
    last_tool_reason: str = ""
    last_tool_error: str = ""

    for m in msgs:
        if isinstance(m, AIMessage):
            for tc in (getattr(m, "tool_calls", None) or []):
                if (tc.get("name") or "") == "deterministic_repro":
                    attempted = True
        elif isinstance(m, ToolMessage):
            if (getattr(m, "name", "") or "") != "deterministic_repro":
                continue
            content = m.content if isinstance(m.content, str) else str(m.content)
            try:
                payload = json.loads(content)
            except Exception:
                continue
            if isinstance(payload, dict):
                r = payload.get("reason") or ""
                e = payload.get("error") or ""
                if r:
                    last_tool_reason = r
                if e:
                    last_tool_error = e

    if not attempted:
        return (
            "supervisor exited without invoking deterministic_repro — "
            "LLM produced a text-only response instead of a tool call"
        )
    if last_tool_reason == "frame_locals_insufficient":
        return (
            "deterministic synthesis bailed: frame locals insufficient to "
            "build a call expression (likely empty/missing function name)"
        )
    if last_tool_reason == "source_not_found_retry_exhausted":
        return (
            "source file from Sentry frame did not resolve on disk after "
            "retry — pass --repo or configure path mapping for prod paths"
        )
    if last_tool_reason:
        return f"deterministic_repro refused: {last_tool_reason}"
    if last_tool_error:
        return f"deterministic_repro errored: {last_tool_error[:120]}"
    return "deterministic_repro invoked but never produced a sealed result"


async def _build_human_review_evidence(sid: str, reason: str) -> dict:
    """Build a structured evidence block for non-deterministic cases.

    Deterministic signal extraction (no LLM) for hypotheses.
    LLM call only for the manual repro script — stays advisory, never
    enters the sealed evidence path.
    """
    entry = _EVENT_REGISTRY.get(sid)
    if entry is None:
        return {"reason": reason}

    exc = entry.get("exc")
    frame = entry.get("frame")
    if exc is None or frame is None:
        return {"reason": reason}

    error_type = getattr(exc, "error_type", "") or ""
    error_message = getattr(exc, "error_message", "") or ""
    fn = getattr(frame, "function", "") or "<unknown>"
    filename = getattr(frame, "filename", "") or ""
    lineno = getattr(frame, "lineno", 0) or 0
    raw_locals = getattr(frame, "variables", {}) or {}

    locals_preview = {k: v for k, v in list(raw_locals.items())[:8]}

    hypotheses: list[dict] = _generate_hypotheses(error_type, error_message, raw_locals)

    manual_script = await _build_manual_repro_script_llm(
        fn=fn, filename=filename, lineno=lineno,
        error_type=error_type, raw_locals=raw_locals,
        hypotheses=hypotheses,
    )

    return {
        "function": fn,
        "file": filename,
        "lineno": lineno,
        "error_type": error_type,
        "error_message": error_message,
        "frame_locals": locals_preview,
        "hypotheses": hypotheses,
        "manual_repro_script": manual_script,
        "refusal_reason": reason,
    }


def _generate_hypotheses(error_type: str, error_message: str, raw_locals: dict) -> list[dict]:
    """Pure deterministic hypothesis scoring from exception + frame locals."""
    hypotheses: list[dict] = []
    et = error_type.lower()
    em = error_message.lower()
    local_keys = set(raw_locals.keys())

    if any(w in et for w in ("race", "lock", "concurrent", "stale", "deadlock")):
        hypotheses.append({
            "rank": 1, "confidence": 0.75,
            "description": "Concurrency / race condition",
            "evidence": "Exception type indicates concurrent state mutation",
            "investigation": "Add threading.Barrier(2) around the write site and retry with 2 threads",
        })
    if any(w in et + em for w in ("integrity", "unique", "duplicate", "already exists")):
        hypotheses.append({
            "rank": len(hypotheses) + 1, "confidence": 0.70,
            "description": "DB unique-constraint violation — likely duplicate write under concurrency",
            "evidence": f"IntegrityError pattern in {error_type}",
            "investigation": "Check if the caller holds a transaction lock before the insert",
        })
    if "keyerror" in et:
        hypotheses.append({
            "rank": len(hypotheses) + 1, "confidence": 0.65,
            "description": "Hash-randomization KeyError — dict key present in one run, absent in another",
            "evidence": "KeyError; PYTHONHASHSEED affects dict iteration order",
            "investigation": "Retry with PYTHONHASHSEED=0 to isolate",
        })
    if any(w in et + em for w in ("timeout", "timedout", "timed out", "deadline")):
        hypotheses.append({
            "rank": len(hypotheses) + 1, "confidence": 0.60,
            "description": "External service or DB timeout",
            "evidence": "Timeout pattern in exception; depends on network state not capturable from frame",
            "investigation": "Check upstream latency at the crash timestamp in your APM",
        })
    if any(w in et for w in ("staledata", "stale")):
        hypotheses.append({
            "rank": len(hypotheses) + 1, "confidence": 0.70,
            "description": "Stale ORM object — read before transaction committed",
            "evidence": "StaleDataError: Celery task re-read an object after a concurrent update",
            "investigation": "Add session.refresh() before the read, or move it inside the transaction",
        })
    if any(k in local_keys for k in ("task_id", "celery_task_id", "request_id")):
        hypotheses.append({
            "rank": len(hypotheses) + 1, "confidence": 0.55,
            "description": "Celery task retry without idempotency guard",
            "evidence": f"task_id in frame locals: {local_keys & {'task_id','celery_task_id','request_id'}}",
            "investigation": "Add DB lock or unique constraint on the task key",
        })
    if not hypotheses:
        hypotheses.append({
            "rank": 1, "confidence": 0.40,
            "description": f"{error_type} — insufficient frame context for deterministic repro",
            "evidence": f"Frame locals captured: {list(local_keys)[:6]}",
            "investigation": "Add more context to Sentry (DB row state, request body)",
        })
    return hypotheses


async def _build_manual_repro_script_llm(
    fn: str, filename: str, lineno: int,
    error_type: str, raw_locals: dict,
    hypotheses: list[dict],
) -> str:
    """LLM-generated copy-paste investigation script for the engineer.

    Advisory only. Falls back to a minimal direct-replay script if the
    LLM call fails or returns unusable output.
    """
    top = hypotheses[0] if hypotheses else {}
    safe_locals = {k: repr(v) for k, v in list(raw_locals.items())[:6]}
    prompt = (
        f"Write a standalone Python investigation script for a production crash.\n\n"
        f"Crash details:\n"
        f"  function: {fn}()\n"
        f"  file: {filename}:{lineno}\n"
        f"  exception: {error_type}\n"
        f"  top hypothesis: {top.get('description', '')}\n"
        f"  investigation tip: {top.get('investigation', '')}\n"
        f"  frame locals: {safe_locals}\n\n"
        "Requirements:\n"
        "- Output ONLY valid Python, no markdown fences, no prose\n"
        "- Start with #!/usr/bin/env python3\n"
        "- Include a block comment at top explaining what to run and why\n"
        "- Import the function from its module (not 'target')\n"
        "- Use the frame locals exactly as captured\n"
        "- Match the hypothesis strategy: if race condition, use threading.Barrier(2); "
        "if KeyError, sweep PYTHONHASHSEED; if timeout, mock the external call; "
        "otherwise direct replay\n"
        "- Print REPRODUCED or NOT REPRODUCED at the end\n"
        "- Keep it under 50 lines\n"
    )
    raw = await _llm_complete(prompt, max_tokens=700)

    # Strip accidental markdown fences if model wraps output
    code = raw.strip()
    if code.startswith("```"):
        code = "\n".join(
            line for line in code.splitlines()
            if not line.startswith("```")
        ).strip()

    if len(code) > 100 and "def " in code or "import " in code or code.startswith("#"):
        return code

    # Fallback: minimal direct replay — never blocks the evidence block
    args = ", ".join(f"{k}={repr(v)}" for k, v in list(raw_locals.items())[:4])
    module = _module_guess(filename)
    return (
        f"#!/usr/bin/env python3\n"
        f"# logomesh fallback repro — {error_type} in {fn}() at {filename}:{lineno}\n"
        f"# Hypothesis: {top.get('description', 'unknown')}\n\n"
        f"from {module} import {fn}\n"
        f"result = {fn}({args})\n"
        f"print('result:', result)\n"
    )


def _module_guess(filename: str) -> str:
    """Convert a file path to a best-guess importable module name."""
    import re
    path = filename or "target"
    path = re.sub(r"^.*?(?:src/|app/|lib/)", "", path)
    path = path.rstrip("/").removesuffix(".py")
    return path.replace("/", ".")


# ---------------------------------------------------------------------------
# Parallel investigator — fires when deterministic repro fails.
# Spawns N concurrent sandbox experiments, one per hypothesis strategy.
# Results are ADVISORY ONLY — never touch evidence_path_seal.
# ---------------------------------------------------------------------------

def _investigation_test_direct(fn: str, raw_locals: dict) -> str:
    """Baseline: call the function with exactly the frame locals."""
    args = ", ".join(f"{k}={repr(v)}" for k, v in list(raw_locals.items())[:6])
    return f"""\
def test_direct_replay():
    import sys
    sys.setswitchinterval(1e-9)
    from target import {fn}
    {fn}({args})
"""


def _investigation_test_race(fn: str, raw_locals: dict) -> str:
    """Race strategy: two threads hit the function simultaneously via Barrier."""
    args = ", ".join(f"{k}={repr(v)}" for k, v in list(raw_locals.items())[:6])
    return f"""\
import threading, sys

def test_race_condition():
    sys.setswitchinterval(1e-9)
    errors = []
    barrier = threading.Barrier(2)

    def _worker():
        barrier.wait()
        try:
            from target import {fn}
            {fn}({args})
        except Exception as e:
            errors.append(e)

    threads = [threading.Thread(target=_worker) for _ in range(2)]
    for t in threads: t.start()
    for t in threads: t.join()

    if errors:
        raise errors[0]
"""


async def _propose_llm_experiment(
    fn: str, source: str, error_type: str,
    raw_locals: dict, top_hypothesis: dict,
) -> tuple[str, dict]:
    """Ask the LLM to generate a hypothesis-specific pytest + env vars.

    This is the dynamic slot in the parallel investigator: instead of picking
    from a static strategy list, the LLM writes the test that most directly
    exercises the top hypothesis. Returns (test_code, extra_env).
    """
    safe_locals = {k: repr(v) for k, v in list(raw_locals.items())[:6]}
    source_snippet = source[:1200]
    prompt = (
        f"You are generating a pytest test to investigate a production crash.\n\n"
        f"Function source:\n```python\n{source_snippet}\n```\n\n"
        f"Crash: {error_type} in {fn}()\n"
        f"Frame locals: {safe_locals}\n"
        f"Hypothesis: {top_hypothesis.get('description', '')}\n"
        f"Investigation tip: {top_hypothesis.get('investigation', '')}\n\n"
        "Write ONE pytest test function named test_llm_hypothesis.\n"
        "Rules:\n"
        "- Import the function as: from target import {fn}\n"
        "- Use the exact frame locals shown above\n"
        "- Target the hypothesis directly (race → threading.Barrier, "
        "KeyError → PYTHONHASHSEED=0 env, timeout → mock, etc.)\n"
        "- No try/except wrapping — let the exception propagate so pytest catches it\n"
        "- Output ONLY valid Python, no markdown, no prose\n"
        "- If you need env vars, output them on the last line as a comment: "
        "# ENV: KEY=value KEY2=value2\n"
    ).replace("{fn}", fn)

    raw = await _llm_complete(prompt, max_tokens=500)
    if not raw or len(raw) < 30:
        return "", {}

    # Strip markdown fences
    code = raw.strip()
    if code.startswith("```"):
        code = "\n".join(l for l in code.splitlines() if not l.startswith("```")).strip()

    # Parse optional ENV comment from last line
    extra_env: dict = {}
    lines = code.splitlines()
    if lines and lines[-1].startswith("# ENV:"):
        env_line = lines[-1][6:].strip()
        for pair in env_line.split():
            if "=" in pair:
                k, v = pair.split("=", 1)
                extra_env[k.strip()] = v.strip()
        code = "\n".join(lines[:-1]).strip()

    if "def test_" not in code:
        return "", {}

    return code, extra_env


async def _run_parallel_investigations(
    sid: str,
    source: str,
    sandbox_extra_env: dict,
    deps_snapshot: str | None,
    timeout_s: int = 30,
) -> list[dict]:
    """Spawn concurrent sandbox experiments when deterministic repro fails.

    Three slots:
      1. direct_replay   — baseline, always fires
      2. race_barrier    — fires if error type suggests concurrency
      3. llm_experiment  — LLM generates a hypothesis-specific test, always fires

    Results are ADVISORY ONLY — never enter evidence_path_seal.
    """
    from business_logic.sandbox import Sandbox  # type: ignore

    entry = _EVENT_REGISTRY.get(sid)
    if entry is None:
        return []
    exc = entry.get("exc")
    frame = entry.get("frame")
    if exc is None or frame is None:
        return []

    fn = getattr(frame, "function", "") or ""
    raw_locals = getattr(frame, "variables", {}) or {}
    error_type = getattr(exc, "error_type", "") or ""
    error_message = (getattr(exc, "error_message", "") or "").lower()
    et = error_type.lower()
    if not fn or not source.strip():
        return []

    sandbox = Sandbox(timeout=max(5, min(timeout_s, 25)))
    sandbox_source = source.strip()

    # Build (label, test_code, extra_env) triples — start with static slots
    tasks: list[tuple[str, str, dict]] = [
        ("direct_replay", _investigation_test_direct(fn, raw_locals), dict(sandbox_extra_env)),
    ]

    # Race slot: fire when error name or message hints at concurrency
    if any(w in et + error_message for w in ("race", "lock", "stale", "concurrent", "integrity", "deadlock", "duplicate")):
        tasks.append(("race_barrier", _investigation_test_race(fn, raw_locals), dict(sandbox_extra_env)))

    # LLM slot: generate hypothesis-specific test
    hypotheses = _generate_hypotheses(error_type, error_message, raw_locals)
    top_hyp = hypotheses[0] if hypotheses else {}
    llm_code, llm_env = await _propose_llm_experiment(fn, sandbox_source, error_type, raw_locals, top_hyp)
    if llm_code:
        merged_env = {**sandbox_extra_env, **llm_env}
        tasks.append(("llm_experiment", llm_code, merged_env))

    audit = _get_audit(sid)

    async def _run_one(label: str, test_code: str, env: dict) -> dict:
        files = {"target.py": sandbox_source, "test_target.py": test_code}
        try:
            result = await asyncio.to_thread(
                sandbox.run, files, deps_snapshot=deps_snapshot, extra_env=env or None,
            )
            reproduced = result.get("failed", 0) > 0
            sandbox_exc = parse_sandbox_exception_type(result.get("output") or "")
            audit.log_sandbox_run(
                intent=f"parallel investigation: {label}",
                files=files,
                result={**result, "strategy": label},
            )
            return {
                "strategy": label,
                "reproduced": reproduced,
                "sandbox_exc": sandbox_exc,
                "output_snippet": (result.get("output") or "")[:400],
                "env_delta": {k: v for k, v in env.items() if sandbox_extra_env.get(k) != v},
            }
        except Exception as e:
            return {"strategy": label, "reproduced": False, "error": str(e)[:200]}

    raw_results = await asyncio.gather(*[_run_one(lb, tc, env) for lb, tc, env in tasks])

    expected_base = error_type.split(".")[-1].lower()

    def _rank(r: dict) -> int:
        if not r.get("reproduced"):
            return 0
        if expected_base and expected_base in (r.get("sandbox_exc") or "").lower():
            return 2
        return 1

    return sorted(raw_results, key=_rank, reverse=True)


async def finalizer_node(state: OrchestratorState) -> dict:
    """Build artifact + draft PR if appropriate. Persist to ReproMemory +
    StrategyEvolver for cross-run learning. Set human_review flag.
    """
    sid = state.get("audit_session_id", "")
    repo_path = state.get("repo_path", ".")
    audit = _get_audit(sid)
    repro = _REPRO_REGISTRY.get(sid)
    report = state.get("critic_report")
    strategy = state.get("strategy_config") or REPRO_DEFAULT_STRATEGY
    sig = state.get("crash_signature") or _crash_signature_from_session(sid)

    needs_human, reason = False, ""
    artifact: dict | None = None
    pr_url = ""

    if bool(state.get("needs_human_review")):
        needs_human = True
        reason = str(state.get("human_review_reason") or "orchestrator_max_steps_exceeded")

    if not needs_human:
        if repro is None:
            needs_human = True
            reason = _diagnose_no_repro_reason(state)
        elif not repro.reproduced:
            needs_human = True
            reason = (
                "deterministic test passed in sandbox; the bug did not reproduce "
                "on the current branch (already fixed, OR locals insufficient — "
                "see context_notes for fixture suggestions)"
            )
        elif report is not None and report.fidelity < 0.5:
            needs_human = True
            reason = (
                f"critic fidelity {report.fidelity:.2f} too low after "
                f"{state.get('critic_attempts', 0)} attempts"
            )

    if repro is not None and repro.reproduced and not needs_human:
        try:
            raw = await _tool_create_draft_pr(session_id=sid, repo_path=repo_path)
            data = json.loads(raw)
            pr_url = data.get("pr_url", "")
        except Exception as e:
            log.warning("draft PR step failed: %s", e)
        try:
            raw = await _tool_build_artifact(
                session_id=sid, repo_path=repo_path, pr_url=pr_url,
            )
            artifact = json.loads(raw)
        except Exception as e:
            log.error("artifact build failed: %s", e)

    # Cross-run persistence removed 2026-05-06; A/B test showed zero uplift.
    # Snapshot in logomesh_legacy/agentbeats_evolvers/.

    human_review_evidence: dict | None = None
    if needs_human:
        human_review_evidence = await _build_human_review_evidence(sid, reason)

        # Parallel investigations: fire N sandbox experiments concurrently.
        # Each targets a specific hypothesis (race, hashseed, fd, memory).
        # Results are advisory only — never touch evidence_path_seal.
        entry = _EVENT_REGISTRY.get(sid)
        source_for_inv = ""
        deps_snap_for_inv = (_ENV_REGISTRY.get(sid) or {}).get("snapshot_path") or None
        sandbox_env_for_inv: dict = {}
        if entry:
            frame_inv = entry.get("frame")
            if frame_inv:
                source_for_inv = resolve_source_with_hints(
                    getattr(frame_inv, "filename", ""), Path(repo_path), path_hints=[],
                ) or ""

        if source_for_inv.strip():
            try:
                inv_results = await _run_parallel_investigations(
                    sid=sid,
                    source=source_for_inv,
                    sandbox_extra_env=sandbox_env_for_inv,
                    deps_snapshot=deps_snap_for_inv,
                    timeout_s=30,
                )
                if human_review_evidence is not None:
                    human_review_evidence["investigations"] = inv_results
                    # Surface best result prominently
                    best = inv_results[0] if inv_results else None
                    if best and best.get("reproduced"):
                        human_review_evidence["best_investigation"] = best
            except Exception as e:
                log.warning("parallel investigations failed: %s", e)

    # Structured hypothesis report for non-reproducible cases.
    # Advisory only — never enters the sealed evidence path.
    hypothesis_report: dict | None = None
    if needs_human and human_review_evidence is not None:
        try:
            from oracles.hypothesis_report import build_hypothesis_report
            entry = _EVENT_REGISTRY.get(sid) or {}
            raw_event = entry.get("raw") or {}
            # Prefer structured SentryBreadcrumb / SentryThread when the
            # parser populated them; fall back to raw event dict shape.
            exc_obj = entry.get("exc")
            structured_breadcrumbs = (
                getattr(exc_obj, "breadcrumbs", None) if exc_obj else None
            )
            structured_threads = (
                getattr(exc_obj, "threads", None) if exc_obj else None
            )
            breadcrumbs = structured_breadcrumbs or (
                ((raw_event.get("breadcrumbs") or {}).get("values"))
                or raw_event.get("breadcrumbs")
                or []
            )
            threads = structured_threads or (
                ((raw_event.get("threads") or {}).get("values"))
                or raw_event.get("threads")
                or []
            )
            try:
                audit_events = audit.render().get("events", []) or []
            except Exception:
                audit_events = []
            related = [str(human_review_evidence.get("file", "") or "")]
            report = build_hypothesis_report(
                evidence=human_review_evidence,
                audit_events=audit_events,
                breadcrumbs=breadcrumbs if isinstance(breadcrumbs, list) else [],
                threads=threads if isinstance(threads, list) else [],
                related_files=[f for f in related if f],
                out_of_scope_reason=reason,
            )
            hypothesis_report = report.to_dict()
            human_review_evidence["report"] = hypothesis_report
        except Exception as e:
            log.warning("hypothesis report build failed: %s", e)

    # Attach to artifact for verified-repro paths that still benefit from
    # an investigation report (rare but possible — e.g. partial races).
    if isinstance(artifact, dict) and hypothesis_report is not None:
        artifact["hypothesis_report"] = hypothesis_report

    audit.flush_to_disk()
    return {
        "artifact": artifact, "pr_url": pr_url,
        "needs_human_review": needs_human,
        "human_review_reason": reason,
        "human_review_evidence": human_review_evidence,
        "hypothesis_report": hypothesis_report,
    }


# ==========================================================================
# 10. GRAPH WIRING
# ==========================================================================

def build_graph(checkpointer: MemorySaver | None = None):
    """Construct the logomesh orchestrator graph.

    Flow:
        START → supervisor ⇄ tools
                supervisor → critic_gate → critic
                critic →(low fidelity & attempts left)→ supervisor
                critic →(ship)→ finalizer → END

    The supervisor's first pass auto-selects a strategy via UCB1 once the
    crash signature is known (after fetch_sentry_event). Memory + strategy
    are persisted in finalizer for cross-run learning.
    """
    sg = StateGraph(OrchestratorState)
    sg.add_node("supervisor", supervisor_node)
    sg.add_node("tools", ToolNode(TOOLS))
    sg.add_node("critic_gate", lambda s: {})  # anchor
    sg.add_node("critic", critic_node)
    sg.add_node("finalizer", finalizer_node)

    sg.add_edge(START, "supervisor")
    sg.add_conditional_edges(
        "supervisor", supervisor_router,
        {"tools": "tools", "critic_gate": "critic_gate", "finalizer": "finalizer"},
    )
    sg.add_edge("tools", "supervisor")
    sg.add_edge("critic_gate", "critic")
    sg.add_conditional_edges(
        "critic", critic_router,
        {"supervisor": "supervisor", "finalizer": "finalizer"},
    )
    sg.add_edge("finalizer", END)

    cp = checkpointer or MemorySaver()
    return sg.compile(checkpointer=cp)


# ==========================================================================
# 11. PUBLIC ENTRYPOINT
# ==========================================================================

async def handle_sentry_webhook(event: dict[str, Any]) -> dict[str, Any]:
    """FastAPI GitHub App entrypoint.

    Returns:
        {
          "status": "shipped" | "human_review" | "error",
          "artifact": dict | None,
          "pr_url": str,
          "audit": dict,
          "needs_human_review": bool,
          "human_review_reason": str,
          "critic": dict | None,
          "duration_s": float,
        }

    Note: earlier versions returned "memory" and "strategy" keys.
    Those came from BattleMemory + UCB1 strategy evolver, both cut
    2026-05-06 after an A/B test showed zero uplift. Removed from the
    envelope; the no-op stubs in the orchestrator preserve the
    internal API surface for prompts but no longer leak into result.
    """
    t0 = time.time()
    issue_id, org = _extract_issue_and_org(event)
    if not issue_id:
        return {
            "status": "error", "artifact": None, "pr_url": "", "audit": {},
            "needs_human_review": True,
            "human_review_reason": "no issue id in webhook payload",
            "critic": None, "duration_s": 0.0,
        }
    # Per-installation secret resolution. Looks up the Supabase
    # installation_secrets row first, fills missing fields from env so
    # the single-tenant pilot path keeps working unchanged.
    inst_id_raw = event.get("installation_id") or ""
    inst_id_str: str = str(inst_id_raw).strip()
    secrets = resolve_secrets(inst_id_str if inst_id_str else None)

    # repo_path precedence: explicit event override → installation row →
    # process env → "." (working dir). Lets a multi-tenant deploy keep
    # per-customer source trees on disk without env juggling.
    repo_path = (
        event.get("repo_path")
        or secrets.repo_path
        or os.getenv("LOGOMESH_REPO_PATH", ".")
    )
    session_id = f"repro-{issue_id}-{int(t0)}"
    audit = AuditSession(session_id)
    _AUDIT_REGISTRY[session_id] = audit
    _SECRETS_REGISTRY[session_id] = secrets

    # Per-run token / cost accounting. ContextVar — safe under concurrency
    # because each asyncio task gets its own context; the semaphore in app.py
    # bounds in-flight runs anyway. Reset before any LLM call can fire.
    reset_usage()

    initial: OrchestratorState = {
        "event_id": str(issue_id), "org": org,
        "repo_path": str(repo_path), "sentry_event_raw": event,
        "messages": [], "audit_session_id": session_id,
        "critic_attempts": 0, "needs_human_review": False,
        "step_count": 0, "max_tool_calls": 0,
    }
    graph = build_graph()
    config = {"configurable": {"thread_id": session_id},
              "recursion_limit": int(os.getenv("LOGOMESH_RECURSION_LIMIT", "40"))}

    budget_exceeded_reason = ""
    partial_artifact: dict | None = None
    try:
        final = await graph.ainvoke(initial, config=config)
    except TokenBudgetExceeded as e:
        # Hard cap hit mid-graph. Preserve any partial sealed repro the
        # registry already holds — the customer paid for the tokens, ship
        # them what we have. Mark needs_human_review so the buyer
        # discovers the cap before trusting the partial result.
        log.warning("token budget exceeded: %s", e)
        budget_exceeded_reason = f"token_budget_exceeded: {e}"
        if _REPRO_REGISTRY.get(session_id) is not None:
            try:
                raw = await _tool_build_artifact(
                    session_id=session_id, repo_path=str(repo_path), pr_url="",
                )
                partial_artifact = json.loads(raw)
                if "error" in partial_artifact:
                    partial_artifact = None
            except Exception as art_e:
                log.warning("partial artifact build failed: %s", art_e)
                partial_artifact = None
        final = {}
    except Exception as e:
        log.exception("orchestrator failed")
        tin, tout = get_usage()
        return {
            "status": "error", "artifact": None, "pr_url": "",
            "audit": audit.render(), "needs_human_review": True,
            "human_review_reason": f"{type(e).__name__}: {e}",
            "critic": None, "memory": None, "strategy": None,
            "duration_s": round(time.time() - t0, 2),
            "usage": usage_summary(),
        }
    finally:
        _REPRO_REGISTRY.pop(session_id, None)
        _EVENT_REGISTRY.pop(session_id, None)
        _ENV_REGISTRY.pop(session_id, None)
        _RESOLVE_REGISTRY.pop(session_id, None)
        _SECRETS_REGISTRY.pop(session_id, None)

    # Budget-exceeded path: keep any sealed partial artifact (the customer
    # paid for those tokens), but force human_review so they see the cap.
    if budget_exceeded_reason:
        needs_human = True
        status = "human_review"
        artifact = partial_artifact
        pr_url = ""
        review_reason = budget_exceeded_reason
        critic_report = None
        human_review_evidence = None
    else:
        needs_human = bool(final.get("needs_human_review"))
        status = ("human_review" if needs_human
                  else ("shipped" if final.get("artifact") else "human_review"))
        artifact = final.get("artifact")
        pr_url = final.get("pr_url", "")
        review_reason = final.get("human_review_reason", "")
        critic_report = final.get("critic_report")
        human_review_evidence = final.get("human_review_evidence")

    usage = usage_summary()

    # Attach usage to the artifact too, so audit-grade evidence carries
    # the cost line. Keep `in_evidence_path: false` — token counts are
    # advisory metadata, not part of the sealed deterministic repro.
    if isinstance(artifact, dict):
        artifact["usage"] = {**usage, "in_evidence_path": False}

    # Persist per-run usage to Supabase. Best-effort — never block the
    # response on a downstream DB hiccup. installation_id / owner are
    # populated by the webhook layer (Item 4); for solo CLI we log "" / "-".
    inst_id = inst_id_str
    owner = str(event.get("owner") or org or "-")
    repo = str(event.get("repo") or "-")
    pull_number = int(event.get("pull_number") or 0)
    findings = 1 if status == "shipped" else 0
    sandbox_mode = "unknown"
    if isinstance(artifact, dict):
        sandbox_mode = (artifact.get("reproduction") or {}).get("sandbox", "unknown")
    try:
        _supabase_log_usage(
            installation_id=inst_id, owner=owner, repo=repo,
            pull_number=pull_number, file_count=1, findings_count=findings,
            tokens_in=usage["tokens_in"], tokens_out=usage["tokens_out"],
            cost_usd=usage["cost_usd"], sandbox_mode=sandbox_mode,
        )
    except Exception as e:
        log.warning("supabase log_usage failed: %s", e)

    hypothesis_report = (
        final.get("hypothesis_report")
        if isinstance(final, dict) else None
    )
    return {
        "status": status,
        "artifact": artifact,
        "pr_url": pr_url,
        "audit": audit.render(),
        "needs_human_review": needs_human,
        "human_review_reason": review_reason,
        "human_review_evidence": human_review_evidence if needs_human else None,
        "hypothesis_report": hypothesis_report,
        "critic": critic_report.model_dump() if critic_report else None,
        "duration_s": round(time.time() - t0, 2),
        "usage": usage,
        "installation_id": inst_id,
    }


def _extract_issue_and_org(event: dict) -> tuple[str, str | None]:
    issue_id = (
        event.get("id")
        or (event.get("data", {}).get("issue") or {}).get("id")
        or (event.get("issue") or {}).get("id")
        or event.get("issue_id")
    )
    org = (event.get("organization") or {}).get("slug") or event.get("org")
    return (str(issue_id) if issue_id else "", org)


# ==========================================================================
# 12. TEST HARNESS
# ==========================================================================

async def _main() -> int:
    """Manual test harness.

        python logomesh_orchestrator.py <issue_id> [org] [--repo PATH]
    """
    if len(sys.argv) < 2:
        print(
            "usage: python logomesh_orchestrator.py <issue_id> [org] [--repo PATH]",
            file=sys.stderr,
        )
        return 2
    issue_id = sys.argv[1]
    org = (sys.argv[2] if len(sys.argv) > 2 and not sys.argv[2].startswith("--")
           else None)
    repo_path = "."
    if "--repo" in sys.argv:
        repo_path = sys.argv[sys.argv.index("--repo") + 1]

    event = {"id": issue_id, "organization": {"slug": org or ""}, "repo_path": repo_path}
    result = await handle_sentry_webhook(event)
    print(json.dumps({
        "status": result["status"],
        "needs_human_review": result["needs_human_review"],
        "human_review_reason": result["human_review_reason"],
        "pr_url": result["pr_url"],
        "critic": result["critic"],
        "strategy": result["strategy"],
        "memory_has_history": bool((result.get("memory") or {}).get("has_history")),
        "duration_s": result["duration_s"],
        "artifact_attestation": (result.get("artifact") or {}).get("attestation"),
        "audit_event_count": (result.get("audit") or {}).get("event_count"),
    }, indent=2))
    return 0 if result["status"] == "shipped" else 1


if __name__ == "__main__":
    sys.exit(asyncio.run(_main()))
