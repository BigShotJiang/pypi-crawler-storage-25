"""Session persistence with SQLite - save/load/resume conversations and traces."""

import json
import sqlite3
import time
from dataclasses import dataclass
from pathlib import Path

from vicode.providers import CONFIG_DIR


DB_PATH = CONFIG_DIR / "sessions.db"


@dataclass
class SessionInfo:
    id: int
    title: str
    cwd: str
    model: str
    message_count: int
    tokens: int
    created_at: float
    updated_at: float
    trace_count: int = 0


class SessionDB:
    """SQLite-backed session and trace storage."""

    _SESSION_SELECT = """
        SELECT
            s.id,
            s.title,
            s.cwd,
            s.model,
            s.message_count,
            s.tokens,
            s.created_at,
            s.updated_at,
            COALESCE(t.trace_count, 0) AS trace_count
        FROM sessions s
        LEFT JOIN (
            SELECT session_id, COUNT(*) AS trace_count
            FROM session_traces
            GROUP BY session_id
        ) t ON t.session_id = s.id
    """

    def __init__(self, db_path: str | Path | None = None):
        import threading
        self._db_path = Path(db_path) if db_path is not None else DB_PATH
        self._db_path.parent.mkdir(parents=True, exist_ok=True)
        self._conn = sqlite3.connect(str(self._db_path), check_same_thread=False)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")
        # WAL mode allows concurrent readers + 1 writer with much less locking
        # contention than the default rollback journal. Combined with the
        # explicit lock below, this stops orchestrate worker threads from
        # crashing with "bad parameter or other API misuse" / "database is
        # locked" when several writes overlap.
        self._conn.execute("PRAGMA journal_mode = WAL")
        self._conn.execute("PRAGMA synchronous = NORMAL")
        # All writes go through this lock so we serialise INSERT/UPDATE from
        # arbitrary threads. SQLite tolerates concurrent reads, but pysqlite's
        # internal state machine is not safe under concurrent execute() calls
        # on the same connection — even with check_same_thread=False.
        self._lock = threading.Lock()
        self._init_schema()

    def _init_schema(self):
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS sessions (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                title TEXT NOT NULL DEFAULT '',
                cwd TEXT NOT NULL DEFAULT '',
                model TEXT NOT NULL DEFAULT '',
                message_count INTEGER NOT NULL DEFAULT 0,
                tokens INTEGER NOT NULL DEFAULT 0,
                created_at REAL NOT NULL,
                updated_at REAL NOT NULL
            );
            CREATE TABLE IF NOT EXISTS messages (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                role TEXT NOT NULL,
                content TEXT,
                tool_calls TEXT,
                tool_call_id TEXT,
                created_at REAL NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            );
            CREATE TABLE IF NOT EXISTS session_traces (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                session_id INTEGER NOT NULL,
                event_type TEXT NOT NULL,
                payload_json TEXT NOT NULL,
                created_at REAL NOT NULL,
                FOREIGN KEY (session_id) REFERENCES sessions(id) ON DELETE CASCADE
            );
            CREATE INDEX IF NOT EXISTS idx_messages_session ON messages(session_id);
            CREATE INDEX IF NOT EXISTS idx_session_traces_session ON session_traces(session_id);
        """)
        self._conn.commit()

    def create_session(self, cwd: str, model: str, title: str = "") -> int:
        now = time.time()
        with self._lock:
            cur = self._conn.execute(
                "INSERT INTO sessions (title, cwd, model, created_at, updated_at) VALUES (?, ?, ?, ?, ?)",
                (title, cwd, model, now, now),
            )
            self._conn.commit()
            return cur.lastrowid

    def save_messages(self, session_id: int, messages: list[dict]):
        """Replace all messages for a session."""
        now = time.time()
        with self._lock:
            self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
            for msg in messages:
                role = msg.get("role", "")
                content = msg.get("content")
                tool_calls = json.dumps(msg["tool_calls"]) if msg.get("tool_calls") else None
                tool_call_id = msg.get("tool_call_id")
                self._conn.execute(
                    "INSERT INTO messages (session_id, role, content, tool_calls, tool_call_id, created_at) VALUES (?, ?, ?, ?, ?, ?)",
                    (session_id, role, content, tool_calls, tool_call_id, now),
                )
            count = len(messages)
            total_chars = sum(len(str(m.get("content", ""))) for m in messages)
            tokens = int(total_chars / 3.5)
            self._conn.execute(
                "UPDATE sessions SET message_count = ?, tokens = ?, updated_at = ? WHERE id = ?",
                (count, tokens, now, session_id),
            )
            self._conn.commit()

    def add_trace_event(self, session_id: int, event_type: str, payload: dict):
        now = time.time()
        # Serialize writes — pysqlite raises InterfaceError("bad parameter
        # or other API misuse") when the same connection is hit by multiple
        # threads concurrently (which happens with orchestrate workers).
        with self._lock:
            self._conn.execute(
                "INSERT INTO session_traces (session_id, event_type, payload_json, created_at) VALUES (?, ?, ?, ?)",
                (session_id, event_type, json.dumps(payload, ensure_ascii=False), now),
            )
            self._conn.execute(
                "UPDATE sessions SET updated_at = ? WHERE id = ?",
                (now, session_id),
            )
            self._conn.commit()

    def update_title(self, session_id: int, title: str):
        with self._lock:
            self._conn.execute("UPDATE sessions SET title = ? WHERE id = ?", (title, session_id))
            self._conn.commit()

    def load_messages(self, session_id: int) -> list[dict]:
        """Load all messages for a session."""
        rows = self._conn.execute(
            "SELECT role, content, tool_calls, tool_call_id FROM messages WHERE session_id = ? ORDER BY id",
            (session_id,),
        ).fetchall()
        messages = []
        for row in rows:
            msg = {"role": row["role"]}
            if row["content"] is not None:
                msg["content"] = row["content"]
            if row["tool_calls"]:
                msg["tool_calls"] = json.loads(row["tool_calls"])
            if row["tool_call_id"]:
                msg["tool_call_id"] = row["tool_call_id"]
            messages.append(msg)
        return messages

    def load_trace(self, session_id: int, limit: int | None = None) -> list[dict]:
        """Load trace events for a session in chronological order."""
        if limit is None:
            rows = self._conn.execute(
                "SELECT id, event_type, payload_json, created_at FROM session_traces WHERE session_id = ? ORDER BY id",
                (session_id,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT id, event_type, payload_json, created_at FROM session_traces WHERE session_id = ? ORDER BY id DESC LIMIT ?",
                (session_id, limit),
            ).fetchall()
            rows = list(reversed(rows))

        return [
            {
                "id": row["id"],
                "type": row["event_type"],
                "payload": json.loads(row["payload_json"]),
                "created_at": row["created_at"],
            }
            for row in rows
        ]

    def list_sessions(self, cwd: str | None = None, limit: int = 20) -> list[SessionInfo]:
        """List recent sessions, optionally filtered by cwd."""
        query = self._SESSION_SELECT
        params: list[object] = []
        if cwd:
            query += " WHERE s.cwd = ?"
            params.append(cwd)
        query += " ORDER BY s.updated_at DESC LIMIT ?"
        params.append(limit)
        rows = self._conn.execute(query, params).fetchall()
        return [SessionInfo(**dict(r)) for r in rows]

    def get_session(self, session_id: int) -> SessionInfo | None:
        row = self._conn.execute(
            self._SESSION_SELECT + " WHERE s.id = ?",
            (session_id,),
        ).fetchone()
        return SessionInfo(**dict(row)) if row else None

    def delete_session(self, session_id: int):
        self._conn.execute("DELETE FROM session_traces WHERE session_id = ?", (session_id,))
        self._conn.execute("DELETE FROM messages WHERE session_id = ?", (session_id,))
        self._conn.execute("DELETE FROM sessions WHERE id = ?", (session_id,))
        self._conn.commit()

    def close(self):
        self._conn.close()
