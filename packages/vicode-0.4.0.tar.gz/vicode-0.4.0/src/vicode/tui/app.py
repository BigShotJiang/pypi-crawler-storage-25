"""Main Textual TUI application."""

import time
from pathlib import Path

from textual import events
from textual.app import App, ComposeResult
from textual.containers import Vertical
from textual.widgets import Static
from textual.worker import Worker

from vicode.config import Config
from vicode.agent.learning import (
    derive_learning_candidates,
    run_memory_consolidation,
    store_learning_candidates,
)
from vicode.agent.loop import AgentLoop
from vicode.agent.tracing import TraceRecorder, format_trace_entry
from vicode.agent.translator import TranslatorAgent
from vicode.agent.summarizer import SummarizerAgent
from vicode.llm.client import LLMClient
from vicode.tools.registry import create_default_registry
from vicode.commands.builtins import create_command_registry
from vicode.supervisor.base import SupervisorChain
from vicode.supervisor.safety import SafetyGuardian
from vicode.supervisor.memory_guardian import MemoryGuardian
from vicode.supervisor.task_tracker import TaskTracker
from vicode.db.sessions import SessionDB
from vicode.tui.chat import ChatDisplay, HIGHLIGHT_COLOR
from vicode.tui.command_palette import CommandPalette
from vicode.tui.input import UserInput
from vicode.tui.task_panel import TaskPanel
from vicode.tui.orchestrator_panel import OrchestratorPanel


DOUBLE_CTRLC_WINDOW = 1.5

# Known context window sizes by model pattern
MODEL_CONTEXT = {
    "gpt-5": 1_000_000,
    "gpt-4o": 128_000,
    "gpt-4": 128_000,
    "claude": 200_000,
    "sonnet": 200_000,
    "opus": 200_000,
    "haiku": 200_000,
    "llama": 128_000,
    "qwen": 131_072,
    "codex": 1_000_000,
}


def _model_context_limit(model: str) -> int:
    """Estimate context window size from model name."""
    m = model.lower()
    for pattern, limit in MODEL_CONTEXT.items():
        if pattern in m:
            return limit
    return 131_072  # safe default


class VicodeApp(App):
    TITLE = "Vicode"

    CSS = """
    Screen { layout: vertical; background: $background; layers: default overlay; }
    #chat-container { height: 1fr; }
    #chat-log { height: 1fr; scrollbar-size: 1 1; padding: 0 1; background: $background; }
    .separator { height: 1; color: $text-disabled; padding: 0; margin: 0; }
    #user-input {
        height: auto; min-height: 1; max-height: 8;
        margin: 0;
        border: none; padding: 0 1;
        background: $background;
    }
    #user-input:focus { border: none; background: $background; }
    #status-bar { height: 1; color: $text-disabled; padding: 0 1; background: $background; }
    .preview { height: 1; padding: 0 2; color: $text-muted; background: $surface-darken-1; }
    """

    BINDINGS = [
        ("ctrl+c", "cancel_or_quit", "Cancel/Quit"),
        ("ctrl+l", "clear_chat", "Clear"),
        ("escape", "dismiss_popup", "Dismiss"),
    ]

    def __init__(self, config: Config, resume_session_id: int | None = None):
        super().__init__()
        self.config = config
        self._agent: AgentLoop | None = None
        self._busy = False
        self._current_worker: Worker | None = None
        self._last_ctrlc: float = 0.0
        self._commands = create_command_registry(config.cwd)
        self._activity_start: float = 0.0
        self._activity_tokens_start: int = 0
        self._activity_label: str = ""
        self._status_timer = None
        self._first_prompt = True
        self._session_db = SessionDB()
        self._session_id: int | None = None
        self._resume_session_id = resume_session_id
        self._orchestrator_timer = None
        self._input_queue: list[str] = []
        self._input_queue_shown: list[
            str
        ] = []  # messages already rendered in chat while queued
        self._streaming_tokens: int = 0
        self._translator = TranslatorAgent()
        self._summarizer = SummarizerAgent()

    def compose(self) -> ComposeResult:
        yield Vertical(
            ChatDisplay(),
            id="chat-container",
        )
        yield TaskPanel(id="task-panel")
        yield OrchestratorPanel(id="orchestrator-panel")
        # Rule auto-fills to the actual terminal width (rebuilds on resize),
        # the previous Static("─" * 200) was either truncated or short.
        yield Static("─" * 500, classes="separator", markup=False)
        yield CommandPalette(id="command-palette")
        yield UserInput()
        yield Static("─" * 500, classes="separator", markup=False)
        yield Static(" ", id="status-bar", markup=True)

    def on_mount(self):
        chat = self.query_one(ChatDisplay)
        # Big "vicode" banner — block-letter ASCII so it scales nicely in any
        # mono terminal. Centered horizontally by add_banner.
        banner_lines = [
            "██╗   ██╗██╗ ██████╗ ██████╗ ██████╗ ███████╗",
            "██║   ██║██║██╔════╝██╔═══██╗██╔══██╗██╔════╝",
            "██║   ██║██║██║     ██║   ██║██║  ██║█████╗  ",
            "╚██╗ ██╔╝██║██║     ██║   ██║██║  ██║██╔══╝  ",
            " ╚████╔╝ ██║╚██████╗╚██████╔╝██████╔╝███████╗",
            "  ╚═══╝  ╚═╝ ╚═════╝ ╚═════╝ ╚═════╝ ╚══════╝",
        ]
        chat.add_banner(banner_lines, style=f"bold {HIGHLIGHT_COLOR}")
        chat.add_system("─" * 80)
        chat.add_system(f"  cwd: {self.config.cwd}")
        chat.add_system(f"  /help · Ctrl+C cancel · 2×Ctrl+C quit")

        # Loaded tools — grouped so the list isn't a wall of names.
        try:
            from vicode.tools.registry import create_default_registry
            tool_groups: dict[str, list[str]] = {
                "files": ["file_read", "file_write", "file_edit", "ls", "glob", "grep", "undo"],
                "shell": ["bash", "kill"],
                "agents": ["explore", "plan", "orchestrate", "document", "ask_user", "load_skill"],
                "memory": ["memory", "docs_index", "docs_query", "docs_sync"],
                "web": ["web_search", "web_fetch"],
            }
            available = {
                t["function"]["name"]
                for t in create_default_registry(self.config).to_openai_tools()
            }
            chat.add_system("  tools:")
            for group, names in tool_groups.items():
                present = [n for n in names if n in available]
                if not present:
                    continue
                chat.add_system(f"    · {group}: {', '.join(present)}")
        except Exception:
            pass

        # Discovered Skills (Claude Code-compatible) — split by scope so the
        # user can tell which come from the repo (`<cwd>/.claude/skills/`)
        # and which from their home (`~/.claude/skills/`). Skills are also
        # registered as slash commands and exposed in the system prompt's
        # <available_skills> block; the model loads bodies via load_skill().
        try:
            from vicode.skills import discover_skills
            found = discover_skills(self.config.cwd)
            user_skills = [s for s in found if s.scope == "user"]
            proj_skills = [s for s in found if s.scope == "project"]

            def _fmt(skills_list):
                if not skills_list:
                    return "0"
                names = ", ".join(s.name for s in skills_list[:8])
                more = f" (+{len(skills_list) - 8} more)" if len(skills_list) > 8 else ""
                return f"{len(skills_list)} — {names}{more}"

            chat.add_system(f"  skills (user):    {_fmt(user_skills)}")
            chat.add_system(f"  skills (project): {_fmt(proj_skills)}")
        except Exception:
            chat.add_system("  skills: (discovery failed)")

        self._update_status("Connecting...")
        self.query_one(UserInput).focus()
        self.run_worker(self._connect, thread=True, exclusive=True)
        # Enable the ask_user tool now that we have a TUI to render forms in.
        from vicode.tools.ask_user import AskUserTool
        AskUserTool.tui_available = True
        AskUserTool.on_request = self._on_ask_user_request
        # Poll for ask_user requests every 200ms (cheap; only shows form when one
        # arrives). The on_request callback also nudges, but polling is the
        # safety net in case it gets dropped.
        self.set_interval(0.2, self._check_pending_ask_user)

    def _connect(self):
        server_advertised_context = False
        if self.config.model == "auto":
            # Try to detect model from server (won't work with OAuth tokens).
            # For llama-server, also pick up the actual context window.
            client = LLMClient(self.config)
            info = client.detect_model_info()
            if info:
                self.config.model = info["id"]
                ctx = info.get("context_size")
                if isinstance(ctx, int) and ctx > 0:
                    self.config.context_limit = ctx
                    server_advertised_context = True
            else:
                # Fallback to sensible default per provider
                from vicode.providers import load_config, PROVIDERS

                pcfg = load_config()
                provider_key = pcfg.provider if pcfg else "local"
                default = PROVIDERS.get(provider_key, {}).get("default_model", "gpt-4o")
                self.config.model = default
        # Only fall back to the per-model heuristic when the server didn't
        # advertise its actual context window (e.g. OpenAI, Anthropic).
        if not server_advertised_context:
            self.config.context_limit = _model_context_limit(self.config.model)

        # Load persisted auto-compact settings into runtime config
        from vicode.providers import load_config as _load_provider_config

        _pcfg = _load_provider_config()
        if _pcfg:
            self.config.auto_compact_every = _pcfg.auto_compact_every
            self.config.auto_compact_keep_last = _pcfg.auto_compact_keep_last

        registry = create_default_registry(self.config)

        # Create supervisor chain
        supervisor = SupervisorChain(
            [
                SafetyGuardian(self.config),
                MemoryGuardian(cwd=self.config.cwd),
                TaskTracker(self.config),
            ]
        )

        self._agent = AgentLoop(
            config=self.config,
            tools=registry,
            supervisor=supervisor,
            translator=self._translator,
        )

        # Resume session if requested
        if self._resume_session_id:
            session = self._session_db.get_session(self._resume_session_id)
            if session:
                msgs = self._session_db.load_messages(self._resume_session_id)
                if msgs:
                    from vicode.agent.messages import MessageHistory

                    self._agent.history = MessageHistory()
                    self._agent.history.messages = msgs
                    self._session_id = self._resume_session_id
                    self._first_prompt = False

        # Create new session if not resuming
        if not self._session_id:
            self._session_id = self._session_db.create_session(
                cwd=self.config.cwd, model=self.config.model
            )

        if self._session_id:
            self._agent.set_trace_recorder(
                TraceRecorder(self._session_db, self._session_id)
            )

        self.call_from_thread(self._on_connected)

    def _on_connected(self):
        chat = self.query_one(ChatDisplay)
        if self._resume_session_id:
            session = self._session_db.get_session(self._resume_session_id)
            if session and session.title:
                chat.add_system(f"  Resumed: {session.title}")
            chat.add_system(
                f"  Model: {self.config.model} ({self._agent.history.estimate_tokens()} tokens)"
            )
        else:
            chat.add_system(f"  Model: {self.config.model}")
        self._update_status()

    def on_user_input_submitted(self, event: UserInput.Submitted):
        text = event.text.strip()
        if not text:
            return

        # Slash command
        if text.startswith("/"):
            self._handle_command(text)
            return

        # Normal message to agent
        if self._busy:
            # Queue input — the agent picks it up at the next iteration
            # boundary (before the next LLM call), so mid-flight steering
            # works without waiting for the current turn to finish.
            if self._agent:
                self._agent.queue_input(text)
                count = len(self._agent._input_queue)
                chat = self.query_one(ChatDisplay)
                chat.add_user_message(text)
                self._input_queue_shown.append(text)
                suffix = f" ({count} queued)" if count > 1 else ""
                chat.add_system(f"  ↵ will be injected before next tool call{suffix}")
            return
        if self._agent is None:
            return
        self._run_agent(text)

    def on_text_area_changed(self, event) -> None:
        """Update command palette as user types /commands."""
        if event.text_area.id != "user-input":
            return
        self._update_command_palette(event.text_area.text)

    def _update_command_palette(self, text: str) -> None:
        try:
            palette = self.query_one(CommandPalette)
        except Exception:
            return
        # Show only while typing the command name (before any space or after submit)
        if text.startswith("/") and " " not in text:
            prefix = text[1:]
            matches = self._commands.match(prefix)
            palette.show_commands(matches, prefix)
        else:
            palette.hide()

    # --- Slash commands ---

    def _handle_command(self, text: str):
        """Parse and execute a slash command."""
        parts = text[1:].split(None, 1)
        cmd_name = parts[0].lower() if parts else ""
        args = parts[1] if len(parts) > 1 else ""
        chat = self.query_one(ChatDisplay)

        cmd = self._commands.get(cmd_name)
        if not cmd:
            # Fuzzy match suggestion
            matches = self._commands.match(cmd_name)
            if matches:
                names = ", ".join(f"/{c.name}" for c in matches[:5])
                chat.add_system(f"  Unknown command /{cmd_name}. Did you mean: {names}")
            else:
                chat.add_system(f"  Unknown command /{cmd_name}. Type /help for list.")
            return

        # Built-in handlers
        match cmd_name:
            case "help":
                self._cmd_help()
            case "clear":
                self._cmd_clear()
            case "compact":
                self._cmd_compact()
            case "init":
                self._cmd_init()
            case "undo":
                self._cmd_undo()
            case "model":
                self._cmd_model(args)
            case "provider":
                self._cmd_provider()
            case "status":
                self._cmd_status()
            case "memory":
                self._cmd_memory()
            case "resume":
                self._cmd_resume(args)
            case "sessions":
                self._cmd_sessions()
            case "usage":
                self._cmd_usage()
            case "trace":
                self._cmd_trace(args)
            case "learn":
                self._cmd_learn(args)
            case "consolidate":
                self._cmd_consolidate_memory()
            case "review":
                self._cmd_review(args)
            case "autocompact":
                self._cmd_autocompact(args)
            case "reindex":
                self._cmd_reindex()
            case "exit":
                self._save_session()
                self.exit()
            case _:
                # Custom command - expand template and send to agent
                if cmd.prompt_template:
                    prompt = cmd.prompt_template.replace("$ARGUMENTS", args).replace(
                        "$1", args
                    )
                    chat.add_user_message(f"/{cmd_name} {args}".strip())
                    if self._agent and not self._busy:
                        self._run_agent(prompt)
                else:
                    chat.add_system(f"  Command /{cmd_name} has no handler.")

    def _cmd_help(self):
        chat = self.query_one(ChatDisplay)
        chat._blank()
        chat.add_system("  Commands:")
        for cmd in self._commands.list_all():
            source = f" [{cmd.source}]" if cmd.source != "built-in" else ""
            chat.add_system(f"    /{cmd.name:<12} {cmd.description}{source}")
        chat._blank()

    def _cmd_clear(self):
        chat = self.query_one(ChatDisplay)
        chat.clear()
        if self._agent:
            from vicode.agent.messages import MessageHistory
            from vicode.agent.prompt import build_system_prompt

            self._agent.history = MessageHistory()
            self._agent.history.set_system(build_system_prompt(self.config))
        self._update_status()

    def _cmd_compact(self):
        if not self._agent or self._busy:
            return
        chat = self.query_one(ChatDisplay)
        before = self._agent.history.estimate_tokens()
        chat.add_system(f"  Compacting... ({before} tokens)")
        self._busy = True
        self._update_status("compacting...")
        self._current_worker = self.run_worker(
            lambda: self._compact_thread(),
            thread=True,
        )

    def _compact_thread(self):
        """Ask the model to summarize the conversation."""
        history = self._agent.history
        msgs = history.get_messages()
        if len(msgs) <= 2:
            self.call_from_thread(
                lambda: self.query_one(ChatDisplay).add_system("  Nothing to compact.")
            )
            self.call_from_thread(self._ui_done)
            return

        # Keep system prompt, ask model to summarize the rest
        summary_prompt = (
            "Summarize our conversation so far in a concise paragraph. "
            "Include key decisions, files modified, and current state."
        )
        result_parts = []
        for event in self._agent.run(summary_prompt, _internal=True):
            if event.get("type") == "content_delta":
                result_parts.append(event["text"])

        summary = "".join(result_parts).strip()
        if summary:
            from vicode.agent.messages import MessageHistory
            from vicode.agent.prompt import build_system_prompt

            new_history = MessageHistory()
            new_history.set_system(build_system_prompt(self.config))
            new_history.add_user("Summary of previous conversation:")
            new_history.add_assistant(content=summary)
            self._agent.history = new_history

        after = self._agent.history.estimate_tokens()
        self.call_from_thread(
            lambda: self.query_one(ChatDisplay).add_system(
                f"  Compacted to {after} tokens"
            )
        )
        self.call_from_thread(self._ui_done)

    def _cmd_init(self):
        chat = self.query_one(ChatDisplay)
        vicode_md = Path(self.config.cwd) / "VICODE.md"
        if vicode_md.exists():
            chat.add_system(f"  VICODE.md already exists at {vicode_md}")
        else:
            vicode_md.write_text(
                "# Project Instructions\n\n"
                "<!-- Add project-specific instructions for vicode here -->\n"
                "<!-- These will be included in the system prompt -->\n\n"
                "- \n",
                encoding="utf-8",
            )
            chat.add_system(f"  Created {vicode_md}")

        docs_dir = Path(self.config.cwd) / ".vicode" / "docs"
        if docs_dir.exists():
            chat.add_system(f"  .vicode/docs/ already exists")
        else:
            docs_dir.mkdir(parents=True, exist_ok=True)
            readme = docs_dir / "README.md"
            readme.write_text(
                "# Project Docs\n\n"
                "<!-- Indexed documentation -->\n\n"
                "Run `/reindex` to index the project.\n",
                encoding="utf-8",
            )
            chat.add_system(f"  Created {docs_dir}")

        # Phase 2: Automatic project documentation and indexing
        if self._agent and not self._busy:
            chat.add_system("  Launching documentation agent...")
            self._busy = True
            self._update_status("documenting...")
            self._current_worker = self.run_worker(
                lambda: self._init_doc_thread(),
                thread=True,
            )

    def _init_doc_thread(self):
        """Run documentation agent as part of init."""
        result_parts = []
        for event in self._agent.run(
            "Use the document tool with scope='full' to research this project, "
            "write documentation to .vicode/docs/, and trigger a reindex.",
            _internal=True,
        ):
            if event.get("type") == "content_delta":
                result_parts.append(event["text"])

        summary = "".join(result_parts).strip()
        msg = summary or "Documentation complete."
        self.call_from_thread(
            lambda: self.query_one(ChatDisplay).add_system(f"  {msg}")
        )
        self.call_from_thread(self._ui_done)

    def _cmd_undo(self):
        chat = self.query_one(ChatDisplay)
        from vicode.tools.file_history import get_file_history

        history = get_file_history()
        if not history.get_history():
            chat.add_system("  Nothing to undo.")
            return
        path, ok = history.undo_last()
        if ok:
            remaining = len(history.get_history())
            chat.add_system(f"  Undone: {path} ({remaining} remaining)")
        else:
            chat.add_system(f"  Failed to undo: {path}")

    def _cmd_model(self, args: str):
        chat = self.query_one(ChatDisplay)
        if args:
            self.config.model = args.strip()
            if self._agent:
                self._agent.client.config.model = self.config.model
            # Persist
            from vicode.providers import load_config, save_config

            pcfg = load_config()
            if pcfg:
                pcfg.model = self.config.model
                save_config(pcfg)
            chat.add_system(f"  Model set to: {self.config.model} (saved)")
            self._update_status()
        else:
            chat.add_system(f"  Current model: {self.config.model}")
            from vicode.providers import PROVIDERS

            provider_info = PROVIDERS.get(self.config.provider, {})
            models = provider_info.get("models", [])
            if models:
                chat.add_system(f"  Available: {', '.join(models)}")
            chat.add_system(f"  Usage: /model <name>")

    def _cmd_resume(self, args: str):
        chat = self.query_one(ChatDisplay)
        if args:
            # Resume specific session by ID
            try:
                sid = int(args.strip())
            except ValueError:
                chat.add_system(f"  Invalid session ID: {args}")
                return
            session = self._session_db.get_session(sid)
            if not session:
                chat.add_system(f"  Session {sid} not found")
                return
            # Reload session
            msgs = self._session_db.load_messages(sid)
            if msgs and self._agent:
                from vicode.agent.messages import MessageHistory

                self._agent.history = MessageHistory()
                self._agent.history.messages = msgs
                self._session_id = sid
                self._agent.set_trace_recorder(TraceRecorder(self._session_db, sid))
                self._first_prompt = False
                chat.clear()
                chat.add_system(f"  Resumed: {session.title or f'Session #{sid}'}")
                chat.add_system(
                    f"  {session.message_count} messages, ~{session.tokens} tokens"
                )
                self._update_status()
        else:
            # Show most recent session to resume
            sessions = self._session_db.list_sessions(cwd=self.config.cwd, limit=5)
            sessions = [s for s in sessions if s.id != self._session_id]
            if not sessions:
                chat.add_system("  No previous sessions found")
                return
            chat._blank()
            chat.add_system("  Recent sessions:")
            for s in sessions:
                import datetime

                dt = datetime.datetime.fromtimestamp(s.updated_at).strftime(
                    "%m/%d %H:%M"
                )
                title = s.title or "(untitled)"
                chat.add_system(
                    f"    #{s.id}  {dt}  {title[:50]}  ({s.message_count} msgs)"
                )
            chat.add_system(f"  Usage: /resume <id>")
            chat._blank()

    def _cmd_sessions(self):
        chat = self.query_one(ChatDisplay)
        sessions = self._session_db.list_sessions(limit=15)
        if not sessions:
            chat.add_system("  No sessions found")
            return
        chat._blank()
        chat.add_system("  Sessions:")
        for s in sessions:
            import datetime

            dt = datetime.datetime.fromtimestamp(s.updated_at).strftime("%m/%d %H:%M")
            title = s.title or "(untitled)"
            current = " *" if s.id == self._session_id else ""
            cwd_short = Path(s.cwd).name
            chat.add_system(
                f"    #{s.id}  {dt}  [{cwd_short}]  {title[:40]}{current}  ({s.trace_count} traces)"
            )
        chat._blank()

    def _resolve_session_id(self, args: str) -> int | None:
        if args:
            try:
                return int(args.strip())
            except ValueError:
                return -1
        return self._session_id

    def _cmd_trace(self, args: str):
        chat = self.query_one(ChatDisplay)
        sid = self._resolve_session_id(args)

        if sid == -1:
            chat.add_system(f"  Invalid session ID: {args}")
            return
        if not sid:
            chat.add_system("  No active session")
            return

        session = self._session_db.get_session(sid)
        if not session:
            chat.add_system(f"  Session {sid} not found")
            return

        trace = self._session_db.load_trace(sid, limit=30)
        if not trace:
            chat.add_system(f"  Session #{sid} has no saved trace events yet")
            return

        chat._blank()
        chat.add_system(f"  Trace for session #{sid} · {session.title or '(untitled)'}")
        for entry in trace:
            import datetime

            dt = datetime.datetime.fromtimestamp(entry["created_at"]).strftime(
                "%H:%M:%S"
            )
            chat.add_system(f"    {dt}  {format_trace_entry(entry)[:140]}")
        chat.add_system("  Tip: /trace <id> to inspect another session")
        chat._blank()

    def _cmd_learn(self, args: str):
        chat = self.query_one(ChatDisplay)
        sid = self._resolve_session_id(args)

        if sid == -1:
            chat.add_system(f"  Invalid session ID: {args}")
            return
        if not sid:
            chat.add_system("  No active session")
            return

        session = self._session_db.get_session(sid)
        if not session:
            chat.add_system(f"  Session {sid} not found")
            return

        trace = self._session_db.load_trace(sid)
        if not trace:
            chat.add_system(f"  Session #{sid} has no trace to learn from")
            return

        candidates = derive_learning_candidates(trace)
        if not candidates:
            chat.add_system(f"  Session #{sid} did not produce reusable learnings")
            return

        try:
            from engram import Memory
            from vicode.tools.memory import _get_namespace

            mem = Memory()
            namespace = _get_namespace(session.cwd)

            def store_fn(content: str, mem_type: str, importance: int):
                mem.store(
                    content, type=mem_type, importance=importance, namespace=namespace
                )

            stored = store_learning_candidates(candidates, store_fn)
        except Exception as e:
            chat.add_system(f"  Learn error: {e}")
            return

        chat._blank()
        chat.add_system(f"  Learned from session #{sid} · stored {stored} memories")
        for candidate in candidates[:stored]:
            chat.add_system(f"    [{candidate['type']}] {candidate['content'][:140]}")
        chat.add_system("  Tip: /memory to inspect stored memories")
        chat._blank()

    def _cmd_consolidate_memory(self):
        chat = self.query_one(ChatDisplay)
        try:
            from engram import Memory

            result = run_memory_consolidation(
                self._session_db, Memory(), cwd=self.config.cwd
            )
        except Exception as e:
            chat.add_system(f"  Consolidation error: {e}")
            return

        chat._blank()
        chat.add_system(
            f"  Memory consolidation complete · namespace {result['namespace']}"
        )
        chat.add_system(
            f"    successful sessions considered: {result['sessions_considered']}"
        )
        chat.add_system(
            f"    deleted noisy/redundant memories: {result['deleted_count']}"
        )
        chat.add_system(f"    stored new learnings: {result['stored_count']}")
        for candidate in result["added_candidates"][:8]:
            chat.add_system(f"    [{candidate['type']}] {candidate['content'][:140]}")
        chat._blank()

    def _cmd_review(self, args: str):
        chat = self.query_one(ChatDisplay)
        sid = self._resolve_session_id(args)

        if sid == -1:
            chat.add_system(f"  Invalid session ID: {args}")
            return
        if not sid:
            chat.add_system("  No active session. Usage: /review or /review <id>")
            return

        session = self._session_db.get_session(sid)
        if not session:
            chat.add_system(f"  Session {sid} not found")
            return

        trace = self._session_db.load_trace(sid)
        if not trace:
            chat.add_system(f"  Session #{sid} has no trace data")
            return

        from vicode.agent.session_review import analyze_session, format_review

        review = analyze_session(trace)
        for line in format_review(session, review):
            chat.add_system(line)

    def _cmd_autocompact(self, args: str):
        chat = self.query_one(ChatDisplay)
        parts = args.strip().lower().split() if args.strip() else []
        
        if not parts:
            every = self.config.auto_compact_every
            keep = self.config.auto_compact_keep_last
            status = f"every {every} turns (keep last {keep})" if every > 0 else "off"
            chat._blank()
            chat.add_system(f"  Auto-compact: {status}")
            if self._agent:
                tc = self._agent._turn_count
                if every > 0 and tc > 0:
                    remainder = tc % every
                    next_at = tc + (every - remainder) if remainder else tc + every
                    chat.add_system(
                        f"  Current turn: {tc}  Next compaction: turn {next_at}"
                    )
            chat.add_system(f"  Usage:")
            chat.add_system(
                f"    /autocompact on              (enable, default: every=10 keep=5)"
            )
            chat.add_system(f"    /autocompact off             (disable)")
            chat.add_system(f"    /autocompact every N keep M  (set values and enable)")
            chat._blank()
            return

        if parts[0] == "off":
            self.config.auto_compact_every = 0
            chat.add_system("  Auto-compact disabled.")
        elif parts[0] == "on":
            if self.config.auto_compact_every == 0:
                self.config.auto_compact_every = 10
            chat.add_system(
                f"  Auto-compact enabled: every {self.config.auto_compact_every} turns, "
                f"keep last {self.config.auto_compact_keep_last}."
            )
        elif parts[0] == "every" and len(parts) >= 2:
            try:
                n = int(parts[1])
                if n < 2:
                    chat.add_system("  compact_every must be at least 2.")
                    return
                self.config.auto_compact_every = n
                if len(parts) >= 4 and parts[2] == "keep":
                    k = int(parts[3])
                    if k < 1:
                        chat.add_system("  keep_last must be at least 1.")
                        return
                    self.config.auto_compact_keep_last = k
                chat.add_system(
                    f"  Auto-compact set: every {self.config.auto_compact_every} turns, "
                    f"keep last {self.config.auto_compact_keep_last}."
                )
            except ValueError:
                chat.add_system(
                    "  Invalid arguments. Usage: /autocompact every N keep M"
                )
                return
        else:
            chat.add_system(
                "  Unknown sub-command. Usage: /autocompact [on|off|every N keep M]"
            )
            return

        # Persist
        from vicode.providers import load_config, save_config

        pcfg = load_config()
        if pcfg:
            pcfg.auto_compact_every = self.config.auto_compact_every
            pcfg.auto_compact_keep_last = self.config.auto_compact_keep_last
            save_config(pcfg)
            chat.add_system("  Settings saved.")

    def _cmd_reindex(self):
        chat = self.query_one(ChatDisplay)
        chat.add_system("  Reindexing documentation...")
        self._busy = True
        self._update_status("reindexing...")
        self.run_worker(self._reindex_thread, thread=True)

    def _reindex_thread(self):
        try:
            from vicode.tools.docs_index import DocsIndexTool
            tool = DocsIndexTool(cwd=self.config.cwd)
            result = tool.run(action="rebuild", force=True)
            if result.is_error:
                self.call_from_thread(self.query_one(ChatDisplay).add_system, f"  [ERROR] {result.content}")
            else:
                self.call_from_thread(self.query_one(ChatDisplay).add_system, f"  [OK] {result.content}")
        except Exception as e:
            self.call_from_thread(self.query_one(ChatDisplay).add_system, f"  [ERROR] {str(e)}")
        finally:
            self.call_from_thread(self._ui_done)

    def _cmd_usage(self):
        chat = self.query_one(ChatDisplay)
        if self.config.provider != "openai-login":
            chat.add_system("  /usage only available for OpenAI Codex provider.")
            chat.add_system(f"  Current provider: {self.config.provider}")
            return
        chat.add_system("  Fetching usage...")
        self.run_worker(self._fetch_usage, thread=True)

    def _fetch_usage(self):
        from vicode.llm.codex_usage import get_codex_usage, format_usage

        usage = get_codex_usage(self.config)
        text = format_usage(usage)
        self.call_from_thread(self.query_one(ChatDisplay).add_system, text)

    def _cmd_provider(self):
        """Re-run provider setup. Exit TUI, run wizard, then relaunch."""
        self._save_session()
        from vicode.providers import CONFIG_FILE

        CONFIG_FILE.unlink(missing_ok=True)
        self.exit(result="setup")

    def _cmd_status(self):
        chat = self.query_one(ChatDisplay)
        tokens = self._agent.history.estimate_tokens() if self._agent else 0
        tools = self._agent.tools.tool_names if self._agent else []
        chat._blank()
        chat.add_system(f"  Model:  {self.config.model}")
        chat.add_system(f"  Server: {self.config.server_url}")
        chat.add_system(f"  CWD:    {self.config.cwd}")
        chat.add_system(f"  Tokens: ~{tokens} / {self.config.context_limit}")
        chat.add_system(f"  Tools:  {', '.join(tools)}")
        every = self.config.auto_compact_every
        ac = (
            f"every {every} turns (keep {self.config.auto_compact_keep_last})"
            if every
            else "off"
        )
        chat.add_system(f"  AutoCompact: {ac}")

        # Show loaded project files
        from vicode.agent.prompt import PROJECT_FILES

        loaded = [f for f in PROJECT_FILES if (Path(self.config.cwd) / f).is_file()]
        if loaded:
            chat.add_system(f"  Config: {', '.join(loaded)}")

        # Show custom commands
        custom = [c for c in self._commands.list_all() if c.source != "built-in"]
        if custom:
            chat.add_system(f"  Custom: {', '.join('/' + c.name for c in custom)}")
        chat._blank()

    def _cmd_memory(self):
        chat = self.query_one(ChatDisplay)
        try:
            from engram import Memory

            mem = Memory()
            results = mem.recall(limit=10)
            if not results:
                chat.add_system("  No memories stored.")
                return
            chat._blank()
            chat.add_system("  Memories:")
            for m in results:
                chat.add_system(f"    [{m.memory_type.value}] {m.content}")
            chat._blank()
        except Exception as e:
            chat.add_system(f"  Memory error: {e}")

    # --- Agent execution ---

    def _run_agent(self, user_input: str):
        self._busy = True
        self._streaming_tokens = 0
        self._update_status("Thinking...")
        chat = self.query_one(ChatDisplay)
        if not user_input.startswith("/"):
            if user_input in self._input_queue_shown:
                self._input_queue_shown.remove(user_input)  # already shown when queued
            else:
                chat.add_user_message(user_input)

        self._current_worker = self.run_worker(
            lambda: self._agent_thread(user_input),
            thread=True,
            exclusive=True,
        )

    def _recall_memories(self, user_input: str):
        """On first prompt, search memory for relevant context and inject it."""
        try:
            from engram import Memory
            from vicode.tools.memory import _get_namespace

            mem = Memory()
            ns = _get_namespace(self.config.cwd)

            # Search project-specific memories first, then global
            memories = []
            results = mem.search(user_input, namespace=ns)
            for r in (results or [])[:4]:
                memories.append(f"- [{r.memory.memory_type.value}] {r.memory.content}")

            # Add high-importance project memories
            if len(memories) < 5:
                recent = mem.recall(limit=5, namespace=ns)
                for m in recent or []:
                    line = f"- [{m.memory_type.value}] {m.content}"
                    if line not in memories:
                        memories.append(line)
                        if len(memories) >= 6:
                            break

            if memories:
                context = "[MEMORY CONTEXT]\n" + "\n".join(memories)
                self._agent.history.add_user(context)
                self._agent.history.add_assistant(content="Noted.")
                self.call_from_thread(
                    self.query_one(ChatDisplay).add_system,
                    f"  Recalled {len(memories)} memories",
                )
        except Exception:
            pass

    def _agent_thread(self, user_input: str):
        # On first prompt, recall relevant memories
        if self._first_prompt:
            self._first_prompt = False
            self.call_from_thread(self._ui_update_status, "Recalling...")
            self._recall_memories(user_input)
            self.call_from_thread(self._ui_update_status, "Thinking...")

        streaming_started = False
        thinking_started = False
        for event in self._agent.run(user_input):
            match event:
                case {"type": "content_delta", "text": text}:
                    if thinking_started:
                        self.call_from_thread(self._ui_thinking_flush)
                        thinking_started = False
                    if not streaming_started:
                        streaming_started = True
                        self.call_from_thread(self._ui_stream_start)
                    self.call_from_thread(self._ui_stream_append, text)
                case {"type": "thinking_delta", "text": text}:
                    if streaming_started:
                        self.call_from_thread(self._ui_stream_flush)
                        streaming_started = False
                    if not thinking_started:
                        thinking_started = True
                        self.call_from_thread(self._ui_thinking_start)
                    self.call_from_thread(self._ui_thinking_append, text)
                case {"type": "content_done"}:
                    if thinking_started:
                        self.call_from_thread(self._ui_thinking_flush)
                        thinking_started = False
                    if streaming_started:
                        self.call_from_thread(self._ui_stream_flush)
                        streaming_started = False
                case {"type": "tool_early", "name": name}:
                    self.call_from_thread(
                        self._ui_update_status, f"↓ {name.replace('_', ' ')}..."
                    )
                case {"type": "tool_start", "name": name}:
                    if thinking_started:
                        self.call_from_thread(self._ui_thinking_flush)
                        thinking_started = False
                    if streaming_started:
                        self.call_from_thread(self._ui_stream_flush)
                        streaming_started = False
                case {"type": "tool_executing", "name": name, "args": args}:
                    self.call_from_thread(self._ui_tool_start, name, args)
                    if name == "orchestrate":
                        self.call_from_thread(self._start_orchestrator_polling)
                case {
                    "type": "tool_result",
                    "name": name,
                    "content": content,
                    "is_error": err,
                }:
                    if name == "orchestrate":
                        self.call_from_thread(self._stop_orchestrator_polling)
                    self.call_from_thread(self._ui_tool_result, name, content, err)
                    self.call_from_thread(self._ui_update_status, "Thinking...")
                case {"type": "token_count", "count": count}:
                    self.call_from_thread(self._update_token_counter, count)
                case {"type": "error", "message": msg}:
                    self.call_from_thread(self._ui_error, msg)
                case {"type": "supervisor_checking", "tool": tool}:
                    self.call_from_thread(
                        self._ui_update_status, f"checking {tool.replace('_', ' ')}..."
                    )
                case {"type": "supervisor_warn", "message": msg}:
                    self.call_from_thread(self._ui_supervisor_warn, msg)
                case {"type": "tasks_updated", "tasks": tasks}:
                    self.call_from_thread(self._ui_update_tasks, tasks)
                case {"type": "memory_stored", "content": content}:
                    self.call_from_thread(self._ui_memory_stored, content)
                case {"type": "queued_input_available", "count": count}:
                    self.call_from_thread(self._ui_show_queued_input, count)
                case {"type": "queued_input_consumed", "text": text}:
                    # Mid-flight steering: input the user typed while the
                    # agent was working has just been injected into history.
                    self.call_from_thread(self._ui_queued_consumed, text)

        # Post-turn review: check if plan tasks remain incomplete
        self._review_plan_completion()
        self.call_from_thread(self._ui_done)

    def _review_plan_completion(self):
        """After agent turn, loop until all tasks are done or max supervisor rounds reached."""
        if not self._agent or not self._agent.supervisor:
            return
        tracker = None
        for sup in self._agent.supervisor.supervisors:
            if hasattr(sup, "review_completion"):
                tracker = sup
                break
        if not tracker:
            return

        MAX_SUPERVISOR_ROUNDS = 4

        for round_num in range(MAX_SUPERVISOR_ROUNDS):
            self.call_from_thread(self._ui_update_status, "Reviewing tasks...")
            history = self._agent.history.get_messages()
            pending = tracker.review_completion(history)

            if tracker.plan_state:
                self.call_from_thread(self._ui_update_tasks, tracker.plan_state.tasks)

            if not pending:
                break  # All tasks done

            # Build actionable feedback hint from LLM review
            feedback = getattr(tracker, "last_review_feedback", "").strip()
            hint_lines = [
                f"[SUPERVISOR] Round {round_num + 1}: {len(pending)} task(s) are not yet complete:",
            ]
            hint_lines.extend(pending)
            if feedback and "all tasks complete" not in feedback.lower():
                hint_lines.append(f"\nReviewer feedback: {feedback}")
            hint_lines.append(
                "\nDo not stop until every task above is done. "
                "Run tests or verification steps as needed to confirm completion."
            )
            hint = "\n".join(hint_lines)

            # Run continuation — full event handling matching the main agent loop
            streaming = False
            thinking = False
            for event in self._agent.run(hint, _internal=True):
                match event:
                    case {"type": "content_delta", "text": text}:
                        if thinking:
                            self.call_from_thread(self._ui_thinking_flush)
                            thinking = False
                        if not streaming:
                            streaming = True
                            self.call_from_thread(self._ui_stream_start)
                        self.call_from_thread(self._ui_stream_append, text)
                    case {"type": "thinking_delta", "text": text}:
                        if streaming:
                            self.call_from_thread(self._ui_stream_flush)
                            streaming = False
                        if not thinking:
                            thinking = True
                            self.call_from_thread(self._ui_thinking_start)
                        self.call_from_thread(self._ui_thinking_append, text)
                    case {"type": "content_done"}:
                        if thinking:
                            self.call_from_thread(self._ui_thinking_flush)
                            thinking = False
                        if streaming:
                            self.call_from_thread(self._ui_stream_flush)
                            streaming = False
                    case {"type": "tool_early", "name": name}:
                        self.call_from_thread(
                            self._ui_update_status, f"↓ {name.replace('_', ' ')}..."
                        )
                    case {"type": "tool_start", "name": name}:
                        if thinking:
                            self.call_from_thread(self._ui_thinking_flush)
                            thinking = False
                        if streaming:
                            self.call_from_thread(self._ui_stream_flush)
                            streaming = False
                    case {"type": "tool_executing", "name": name, "args": args}:
                        self.call_from_thread(self._ui_tool_start, name, args)
                    case {
                        "type": "tool_result",
                        "name": name,
                        "content": content,
                        "is_error": err,
                    }:
                        self.call_from_thread(self._ui_tool_result, name, content, err)
                        self.call_from_thread(self._ui_update_status, "Thinking...")
                    case {"type": "token_count", "count": count}:
                        self.call_from_thread(self._update_token_counter, count)
                    case {"type": "error", "message": msg}:
                        self.call_from_thread(self._ui_error, msg)
                    case {"type": "supervisor_checking", "tool": tool}:
                        self.call_from_thread(
                            self._ui_update_status,
                            f"checking {tool.replace('_', ' ')}...",
                        )
                    case {"type": "supervisor_warn", "message": msg}:
                        self.call_from_thread(self._ui_supervisor_warn, msg)
                    case {"type": "tasks_updated", "tasks": tasks}:
                        self.call_from_thread(self._ui_update_tasks, tasks)
                    case {"type": "memory_stored", "content": content}:
                        self.call_from_thread(self._ui_memory_stored, content)
                    case _:
                        pass

            if tracker.plan_state:
                self.call_from_thread(self._ui_update_tasks, tracker.plan_state.tasks)

    # --- UI updates ---

    def _ui_stream_start(self):
        self.query_one(ChatDisplay).start_stream()
        self._update_status("Streaming...")

    def _ui_stream_append(self, text: str):
        self.query_one(ChatDisplay).append_stream(text)

    def _ui_stream_flush(self):
        self.query_one(ChatDisplay).flush_stream()

    def _ui_thinking_start(self):
        self.query_one(ChatDisplay).start_thinking_stream()
        self._update_status("Thinking...")

    def _ui_thinking_append(self, text: str):
        self.query_one(ChatDisplay).append_thinking_stream(text)

    def _ui_thinking_flush(self):
        self.query_one(ChatDisplay).flush_thinking_stream()

    def _ui_tool_start(self, name: str, args: dict | None = None):
        self._update_status(f"▶ {name.replace('_', ' ')}...")
        self.query_one(ChatDisplay).add_tool_start(name, args)

    def _ui_tool_result(self, name: str, content: str, is_error: bool):
        self.query_one(ChatDisplay).add_tool_result(name, content, is_error)

    def _ui_error(self, message: str):
        self.query_one(ChatDisplay).add_error(message)

    def _ui_done(self):
        self._busy = False
        self._streaming_tokens = 0

        if self._check_session_complete():
            self._show_summary()
            return

        self._update_status()
        self.query_one(UserInput).focus()
        self._save_session()
        self._process_input_queue()

    def _check_session_complete(self) -> bool:
        """Check if the session is complete using combined conditions."""
        if not self._agent or not self._agent.supervisor:
            return False

        tracker = None
        for sup in self._agent.supervisor.supervisors:
            if hasattr(sup, "is_session_complete"):
                tracker = sup
                break

        if not tracker:
            return False

        history = self._agent.history.get_messages()
        return tracker.is_session_complete(history)

    def _show_summary(self):
        """Show summary at end of successful session."""
        self._summarizer.user_language = self._translator.get_user_language()
        history = self._agent.history.get_messages()

        summary = self._summarizer.summarize(history)

        user_lang = self._translator.get_user_language()
        lang_label = {
            "es": "Español",
            "en": "English",
            "fr": "Français",
            "de": "Deutsch",
        }.get(user_lang, user_lang)

        chat = self.query_one(ChatDisplay)
        chat.add_system(f"  ──── Session Complete ────")
        chat.add_system(f"  Resumen en {lang_label}:")
        chat.add_system(f"  {summary}")

        self._save_session()
        self._update_status()
        self.query_one(UserInput).focus()
        self._process_input_queue()

    def _process_input_queue(self):
        """Process queued inputs if any."""
        if self._agent and not self._busy:
            # Try to get from agent's queue first
            text = self._agent.get_queued_input()
            if text:
                self._run_agent(text)
                return
        # Fallback to app-level queue
        if self._input_queue and not self._busy:
            text = self._input_queue.pop(0)
            self._run_agent(text)

    def _ui_show_queued_input(self, count: int):
        """Show notification that inputs are queued."""
        self._update_status(f"Queued {count} message(s)")

    def _ui_queued_consumed(self, text: str):
        """Notify the user that their queued input is now being processed."""
        chat = self.query_one(ChatDisplay)
        snippet = text[:60] + "…" if len(text) > 60 else text
        chat.add_system(f"  ↳ injected: {snippet}")

    # --- ask_user integration ----------------------------------------------

    def _on_ask_user_request(self):
        """Called from the agent worker thread when a request lands in the
        inbox. Schedule a UI-thread check immediately."""
        try:
            self.call_from_thread(self._check_pending_ask_user)
        except Exception:
            pass

    def _check_pending_ask_user(self):
        from vicode.tools.ask_user import has_pending_request, take_pending_request
        if not has_pending_request():
            return
        # Don't stack multiple forms.
        if getattr(self, "_ask_user_screen_open", False):
            return
        req = take_pending_request()
        if req is None:
            return
        self._ask_user_screen_open = True
        from vicode.tui.ask_form import AskUserScreen

        def on_done(answers):
            self._ask_user_screen_open = False
            req.answers = answers
            req.cancelled = answers is None
            req.event.set()

        self.push_screen(AskUserScreen(req.questions, on_done))

    def _start_orchestrator_polling(self):
        """Start polling orchestrator events every 500ms."""
        self._update_status("Orchestrating...")
        if self._orchestrator_timer is None:
            self._orchestrator_timer = self.set_interval(0.5, self._poll_orchestrator)

    def _stop_orchestrator_polling(self):
        """Stop orchestrator polling and hide panel."""
        if self._orchestrator_timer is not None:
            self._orchestrator_timer.stop()
            self._orchestrator_timer = None
        # Do one final poll to catch remaining events
        self._poll_orchestrator()
        self.query_one(OrchestratorPanel).clear_agents()

    def _poll_orchestrator(self):
        """Read events from orchestrator queue and update panel."""
        from vicode.tools.orchestrator import orchestrator_events
        from queue import Empty

        panel = self.query_one(OrchestratorPanel)
        while True:
            try:
                event = orchestrator_events.get_nowait()
            except Empty:
                break
            etype = event.get("type", "")
            aid = event.get("agent_id", 0)
            if etype == "agent_start":
                panel.agent_start(aid, event.get("name", ""))
            elif etype == "agent_tool":
                panel.agent_tool(aid, event.get("tool", ""))
            elif etype == "agent_done":
                panel.agent_done(aid)
            elif etype == "agent_error":
                panel.agent_error(aid)
            elif etype == "orchestrator_done":
                break

    def _save_session(self):
        """Auto-save current session to SQLite."""
        if not self._agent or not self._session_id:
            return
        try:
            msgs = self._agent.history.get_messages()
            self._session_db.save_messages(self._session_id, msgs)
            # Auto-title from first user message if no title yet
            session = self._session_db.get_session(self._session_id)
            if session and not session.title:
                for m in msgs:
                    if m.get("role") == "user" and m.get("content"):
                        title = m["content"][:60].replace("\n", " ")
                        self._session_db.update_title(self._session_id, title)
                        break
        except Exception:
            pass

    def _ui_update_status(self, msg: str):
        self._update_status(msg)

    def _ui_supervisor_warn(self, msg: str):
        self.query_one(ChatDisplay).add_system(f"  ⚠ {msg}")

    def _ui_update_tasks(self, tasks):
        self.query_one(TaskPanel).update_tasks(tasks)

    def _ui_memory_stored(self, content: str):
        self.query_one(ChatDisplay).add_memory_note(content)

    def _update_status(self, activity: str = ""):
        if activity:
            self._activity_label = activity
            if self._activity_start == 0:
                self._activity_start = time.monotonic()
                self._activity_tokens_start = (
                    self._agent.history.estimate_tokens() if self._agent else 0
                )
            # Start tick timer if not running
            if self._status_timer is None:
                self._status_timer = self.set_interval(1.0, self._tick_status)
        else:
            self._activity_label = ""
            self._activity_start = 0.0
            self._activity_tokens_start = 0
            if self._status_timer is not None:
                self._status_timer.stop()
                self._status_timer = None

        self._render_status_bar()

    def _update_token_counter(self, count: int):
        """Update streaming token counter."""
        self._streaming_tokens = count
        self._render_status_bar()

    def _tick_status(self):
        """Called every second to update elapsed time in status bar."""
        self._render_status_bar()

    def _render_status_bar(self):
        bar = self.query_one("#status-bar", Static)
        tokens = self._agent.history.estimate_tokens() if self._agent else 0
        # Include sub-agent tokens if one is running
        from vicode.tools.subagents import subagent_tokens

        tokens += subagent_tokens
        limit = self.config.context_limit
        pct = min(tokens / limit, 1.0) if limit else 0

        bar_width = 20
        filled = int(pct * bar_width)
        empty = bar_width - filled
        if pct < 0.6:
            color = "green"
        elif pct < 0.8:
            color = "yellow"
        else:
            color = "red"
        ctx_bar = f"[{color}]{'█' * filled}[/]{'░' * empty} {tokens // 1000}K/{limit // 1000}K"

        # Add streaming token counter if active
        stream_info = (
            f" +{self._streaming_tokens} streaming"
            if self._streaming_tokens > 0
            else ""
        )

        if self._activity_label:
            elapsed = time.monotonic() - self._activity_start
            delta_tokens = max(0, tokens - self._activity_tokens_start)
            if elapsed >= 60:
                time_str = f"{int(elapsed // 60)}m {int(elapsed % 60)}s"
            else:
                time_str = f"{int(elapsed)}s"
            act = f"{self._activity_label} ({time_str} & {delta_tokens // 1000}K tks){stream_info}"
        else:
            act = f"Ready{stream_info}"

        bar.update(f"{self.config.model} │ {ctx_bar} │ {act}")

    def action_dismiss_popup(self):
        self.query_one(ChatDisplay)._dismiss_popup()

    # --- Context menu events (bubbles up from popup) ---

    def on_context_menu_item_selected(self, event):
        """Handle context menu actions."""
        chat = self.query_one(ChatDisplay)
        chat._dismiss_popup()

        action = event.action
        if action == "copy_block" and chat._click_block_text:
            self.copy_to_clipboard(chat._click_block_text)
            self.notify("Copied block", timeout=1)
        elif action == "copy_last":
            text = chat._get_last_response()
            if text:
                self.copy_to_clipboard(text)
                self.notify("Copied last response", timeout=1)
        elif action == "copy_all":
            text = chat.get_all_text()
            if text:
                self.copy_to_clipboard(text)
                self.notify("Copied all", timeout=1)

        self.query_one(UserInput).focus()

    # --- Paste & Quit ---

    def _on_paste(self, event: events.Paste) -> None:
        event.stop()
        event.prevent_default()
        inp = self.query_one(UserInput)
        inp.focus()
        inp.handle_paste(event.text)

    def action_cancel_or_quit(self):
        now = time.monotonic()

        # If busy: cancel the operation, do NOT count as quit-tap
        if self._busy and self._current_worker:
            self._current_worker.cancel()
            self._busy = False
            self._last_ctrlc = 0.0  # reset so next tap starts fresh
            self._update_status("Cancelled")
            self.query_one(ChatDisplay).add_system("[cancelled]")
            self.query_one(UserInput).focus()
            return

        # Idle: two taps within 2s to quit
        if (now - self._last_ctrlc) < 2.0:
            self._save_session()
            self.exit()
        else:
            self._last_ctrlc = now
            self._update_status("press Ctrl+C again to quit")

    def action_clear_chat(self):
        self._cmd_clear()
