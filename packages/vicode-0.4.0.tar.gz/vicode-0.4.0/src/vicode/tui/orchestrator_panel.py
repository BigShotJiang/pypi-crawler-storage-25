"""Orchestrator panel - shows parallel agents and their tool activity."""

from textual.widgets import Static


class OrchestratorPanel(Static):
    """Live view of parallel sub-agents during orchestration."""

    DEFAULT_CSS = """
    OrchestratorPanel {
        height: auto; max-height: 20;
        padding: 0 1;
        color: $text-muted;
        display: none;
    }
    OrchestratorPanel.-active { display: block; }
    """

    def __init__(self, **kwargs):
        # Pass a non-empty string — Static("") makes Textual's render path
        # crash with `'NoneType' object has no attribute 'render_strips'`
        # when the widget is asked to render before any update().
        super().__init__(" ", **kwargs)
        self._agents: dict[int, dict] = {}  # agent_id -> {name, tools, status}

    def agent_start(self, agent_id: int, name: str):
        self._agents[agent_id] = {"name": name, "tools": [], "status": "running"}
        self.add_class("-active")
        self._refresh_panel()

    def agent_tool(self, agent_id: int, tool_label: str):
        if agent_id in self._agents:
            self._agents[agent_id]["tools"].append(tool_label)
            # Keep only last 5
            self._agents[agent_id]["tools"] = self._agents[agent_id]["tools"][-5:]
            self._refresh_panel()

    def agent_done(self, agent_id: int):
        if agent_id in self._agents:
            self._agents[agent_id]["status"] = "done"
            self._refresh_panel()

    def agent_error(self, agent_id: int):
        if agent_id in self._agents:
            self._agents[agent_id]["status"] = "error"
            self._refresh_panel()

    def clear_agents(self):
        self._agents.clear()
        self.remove_class("-active")
        self.update("")

    def _refresh_panel(self):
        # NOTE: never call this `_render` — Textual reserves that name for the
        # widget's own visual-render hook. Overriding it with a method that
        # returns None makes the entire app crash with
        # `'NoneType' object has no attribute 'render_strips'` on render.
        lines = []
        for aid in sorted(self._agents.keys()):
            state = self._agents[aid]
            icon = {"running": "->", "done": "OK", "error": "!!"}[state["status"]]
            lines.append(f"  [{icon}] Agent {aid + 1}: {state['name']}")
            for tool in state["tools"]:
                lines.append(f"       {tool}")
            if not state["tools"] and state["status"] == "running":
                lines.append(f"       Starting...")
        self.update("\n".join(lines))
