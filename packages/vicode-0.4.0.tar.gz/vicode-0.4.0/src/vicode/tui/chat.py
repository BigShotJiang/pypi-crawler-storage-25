"""Chat display widget - streaming-aware RichLog with block tracking."""

import re
from dataclasses import dataclass
from textual import events
from textual.geometry import Size
from textual.widgets import RichLog
from rich.text import Text
from rich.markdown import Markdown

HIGHLIGHT_COLOR = "#9580ff"  # soft blue-purple


def _tool_hint(name: str, args: dict) -> str:
    """Extract a short contextual hint from tool args for display."""
    if name in ("file_read", "file_write", "file_edit"):
        fp = args.get("file_path", "")
        # Show relative-looking path
        parts = fp.replace("\\", "/").split("/")
        return "/".join(parts[-3:]) if len(parts) > 3 else fp
    elif name == "bash":
        cmd = args.get("command", "")
        return cmd[:70] + "..." if len(cmd) > 70 else cmd
    elif name == "grep":
        return f'"{args.get("pattern", "")}"'
    elif name == "glob":
        return args.get("pattern", "")
    elif name == "ls":
        return args.get("path", ".") or "."
    elif name in ("explore", "plan"):
        q = args.get("question", args.get("task", ""))
        return q[:60] + "..." if len(q) > 60 else q
    elif name == "web_search":
        return args.get("query", "")[:60]
    elif name == "web_fetch":
        return args.get("url", "")[:60]
    elif name == "memory":
        action = args.get("action", "")
        content = args.get("content", "")[:40]
        return f'{action}: {content}' if content else action
    return ""


def _styled_text(line: str, base_style: str = "") -> Text:
    """Convert a line with **bold** markers into a Rich Text with highlights."""
    parts = re.split(r"(\*\*.*?\*\*)", line)
    if len(parts) == 1:
        return Text(line, style=base_style) if base_style else Text(line)
    text = Text(style=base_style)
    for part in parts:
        if part.startswith("**") and part.endswith("**"):
            text.append(part[2:-2], style=f"bold {HIGHLIGHT_COLOR}")
        else:
            text.append(part)
    return text


@dataclass
class Block:
    """A logical block in the chat (message, tool result, system info)."""
    kind: str          # "user", "assistant", "tool", "system", "error"
    start_line: int    # index into _text_lines
    text: str = ""     # plain text content


class ChatDisplay(RichLog):
    """Scrollable chat log. Right-click for copy menu."""

    can_focus = False

    def __init__(self, **kwargs):
        super().__init__(
            highlight=False,
            markup=False,
            wrap=True,
            auto_scroll=True,
            id="chat-log",
            **kwargs,
        )
        self._streaming_buffer = ""
        self._stream_line_count = 0
        self._stream_start_idx = 0
        self._text_lines: list[str] = []
        self._blocks: list[Block] = []
        self._click_block_text: str = ""  # text of block under last right-click

    # --- Block tracking ---

    def _start_block(self, kind: str):
        self._blocks.append(Block(kind=kind, start_line=len(self.lines)))

    def _finish_block(self, text: str):
        if self._blocks:
            self._blocks[-1].text = text

    def _get_block_at_line(self, line_idx: int) -> Block | None:
        """Find which block contains the given render line index."""
        result = None
        for b in self._blocks:
            if b.start_line <= line_idx:
                result = b
            else:
                break
        return result

    # --- Text tracking for copy ---

    def _track_text(self, text: str):
        self._text_lines.extend(text.splitlines())

    def write(self, content, width=None, expand=False, shrink=True, scroll_end=None, animate=False):
        if self._size_known:
            if isinstance(content, Text):
                self._track_text(content.plain)
            elif isinstance(content, str):
                self._track_text(content)
            else:
                self._track_text(str(content))
        return super().write(content, width=width, expand=expand, shrink=shrink, scroll_end=scroll_end, animate=animate)

    def clear(self):
        self._text_lines.clear()
        self._blocks.clear()
        return super().clear()

    def get_all_text(self) -> str:
        return "\n".join(self._text_lines)

    # --- Right-click context menu ---

    _popup = None

    def _dismiss_popup(self):
        if self._popup and self._popup.parent:
            self._popup.remove()
        self._popup = None

    def _on_mouse_down(self, event: events.MouseDown):
        # Any click dismisses existing popup
        self._dismiss_popup()

        if event.button == 3:
            event.stop()
            event.prevent_default()

            # Find which block was clicked
            click_y = int(event.y) + int(self.scroll_y)
            block = self._get_block_at_line(click_y)
            self._click_block_text = block.text if block else ""

            from vicode.tui.context_menu import ContextMenuPopup, ContextMenuItem
            popup = ContextMenuPopup(
                x=min(event.screen_x, self.app.size.width - 30),
                y=min(event.screen_y, self.app.size.height - 6),
                block_preview=self._click_block_text,
            )
            self._popup = popup
            self.app.screen.mount(popup)

    def _get_last_response(self) -> str:
        for b in reversed(self._blocks):
            if b.kind == "assistant" and b.text:
                return b.text
        return ""

    # --- Helpers ---

    def _blank(self):
        # Avoid double blank lines
        if self._text_lines and self._text_lines[-1] == "":
            return
        self.write(Text(""))

    # --- Messages ---

    def add_user_message(self, text: str):
        self._blank()
        self._start_block("user")
        self.write(Text(f"> {text}", style="bold"))
        self._finish_block(text)
        self._blank()

    def start_stream(self):
        self._blank()
        self._start_block("assistant")
        self._stream_first_line = True
        self._streaming_buffer = ""
        self._stream_line_count = 0
        self._stream_start_idx = len(self.lines)

    def append_stream(self, text: str):
        self._streaming_buffer += text
        lines = self._streaming_buffer.split("\n")
        complete = len(lines) - 1
        while self._stream_line_count < complete:
            line = lines[self._stream_line_count]
            if self._stream_first_line and line.strip():
                # First line gets the white circle prefix
                t = Text("  ● ", style="white")
                styled = _styled_text(line)
                t.append_text(styled)
                self.write(t)
                self._stream_first_line = False
            else:
                self.write(_styled_text(line))
            self._stream_line_count += 1

    def _replace_stream_lines(self, renderable):
        idx = self._stream_start_idx
        n = len(self.lines) - idx
        self.lines[idx:] = []
        self.virtual_size = Size(self._widest_line_width, len(self.lines))
        self._line_cache.clear()
        if n > 0 and n <= len(self._text_lines):
            self._text_lines[-n:] = []
        self.write(renderable)
        self.refresh()

    def flush_stream(self):
        if not self._streaming_buffer.strip():
            self._streaming_buffer = ""
            return

        buf = self._streaming_buffer
        self._finish_block(buf)

        has_md = any(marker in buf for marker in ("|---", "```", "## "))
        if has_md:
            self._replace_stream_lines(Markdown(buf))
        else:
            lines = buf.split("\n")
            for line in lines[self._stream_line_count:]:
                if line.strip():
                    self.write(_styled_text(line))

        self._streaming_buffer = ""
        self._stream_line_count = 0
        self._blank()

    # --- Thinking stream (model reasoning, shown dim/italic) ---

    _THINKING_STYLE = "dim italic"

    def start_thinking_stream(self):
        # Don't pre-pad — the previous block already left a separator and
        # we want the thinking section flush against it (less wasted space).
        self._start_block("thinking")
        t = Text("  ▸ thinking", style=f"{self._THINKING_STYLE} {HIGHLIGHT_COLOR}")
        self.write(t)
        self._thinking_buffer = ""
        self._thinking_line_count = 0

    def append_thinking_stream(self, text: str):
        self._thinking_buffer += text
        lines = self._thinking_buffer.split("\n")
        complete = len(lines) - 1
        while self._thinking_line_count < complete:
            line = lines[self._thinking_line_count].strip()
            if line:
                self.write(Text(f"    {line}", style=self._THINKING_STYLE))
            self._thinking_line_count += 1

    def flush_thinking_stream(self):
        buf = getattr(self, "_thinking_buffer", "")
        if buf:
            # Flush any trailing partial line (last fragment with no newline)
            remaining = buf.split("\n")[self._thinking_line_count:]
            for line in remaining:
                line = line.strip()
                if line:
                    self.write(Text(f"    {line}", style=self._THINKING_STYLE))
            self._finish_block(buf)
        self._thinking_buffer = ""
        self._thinking_line_count = 0

    def add_tool_start(self, name: str, args: dict | None = None):
        display = name.replace("_", " ").title().replace(" ", "_")
        hint = _tool_hint(name, args or {})
        t = Text("  ● ", style="white")
        t.append(display, style="white")
        if hint:
            t.append(f"({hint})", style="dim")
        self._start_block("tool")
        self.write(t)

    def _render_diff(self, diff_text: str):
        for line in diff_text.splitlines():
            if line.startswith("+++") or line.startswith("---"):
                self.write(Text(f"    {line}", style="bold"))
            elif line.startswith("@@"):
                self.write(Text(f"    {line}", style="cyan"))
            elif line.startswith("+"):
                self.write(Text(f"    {line}", style="green"))
            elif line.startswith("-"):
                self.write(Text(f"    {line}", style="red"))
            else:
                self.write(Text(f"    {line}", style="dim"))

    def _truncate_content(self, content: str, max_lines: int = 12) -> str:
        lines = content.splitlines()
        if len(lines) <= max_lines:
            return content
        half = max_lines // 2
        kept = lines[:half] + [f"  ... ({len(lines) - max_lines} lines hidden)"] + lines[-half:]
        return "\n".join(kept)

    def _result_line(self, dot_color: str, text: str):
        """Write a result line: colored dot + dim text."""
        t = Text("  ● ", style=dot_color)
        t.append(text, style="dim")
        self.write(t)

    def _result_lines(self, dot_color: str, content: str, max_lines: int = 12):
        """Write multi-line result: first line gets dot, rest indented dim."""
        truncated = self._truncate_content(content, max_lines=max_lines)
        lines = truncated.splitlines()
        if lines:
            self._result_line(dot_color, lines[0])
            for line in lines[1:]:
                self.write(Text(f"    {line}", style="dim"))

    def add_tool_result(self, name: str, content: str, is_error: bool):
        self._finish_block(content)
        if is_error:
            self._result_lines("red", content, max_lines=8)
        elif name == "file_edit" and "\n---" in content and "\n+++" in content:
            _, _, diff = content.partition("\n---")
            self._render_diff("---" + diff)
        elif name == "file_write":
            first_line = content.splitlines()[0] if content else ""
            if "Created" in first_line or "Updated" in first_line:
                parts = first_line.split("(")
                size_info = "(" + parts[-1] if len(parts) > 1 else ""
                action = "Created" if "Created" in first_line else "Updated"
                self._result_line("green", f"{action} {size_info}")
            else:
                self._result_line("green", content[:100])
        else:
            self._result_lines("green", content)

    def add_error(self, message: str):
        self._start_block("error")
        self.write(Text(f"  ✗ {message}", style="red"))
        self._finish_block(message)

    def add_system(self, message: str):
        self._start_block("system")
        self.write(Text(message, style="dim italic"))
        self._finish_block(message)

    def add_banner(self, lines: list[str], style: str = "bold"):
        """Render an ASCII-art banner centered horizontally."""
        # Use the widget's current rendered width if available; fall back to
        # the longest banner line so the centering stays sane on first paint.
        try:
            width = max(self.size.width, 1)
        except Exception:
            width = max((len(l) for l in lines), default=0)
        self._start_block("banner")
        for line in lines:
            pad = max(0, (width - len(line)) // 2)
            self.write(Text(" " * pad + line, style=style))
        self._finish_block("\n".join(lines))

    def add_memory_note(self, message: str):
        self.write(Text(f"    memorized: {message}", style="dim"))
