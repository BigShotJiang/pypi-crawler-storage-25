"""Lightweight context menu - no ModalScreen, no overlay."""

from textual import events
from textual.app import ComposeResult
from textual.containers import Vertical
from textual.widgets import Static
from textual.message import Message


class ContextMenuItem(Static):
    """A clickable menu item."""

    DEFAULT_CSS = """
    ContextMenuItem {
        width: auto; height: 1; padding: 0 2;
        background: $surface; color: $text;
    }
    ContextMenuItem:hover { background: $accent; color: $text; }
    ContextMenuItem.-disabled { color: $text-disabled; }
    """

    class Selected(Message):
        def __init__(self, action: str):
            super().__init__()
            self.action = action

    def __init__(self, label: str, action: str, disabled: bool = False, **kwargs):
        super().__init__(label, **kwargs)
        self.action_name = action
        self._disabled = disabled
        if disabled:
            self.add_class("-disabled")

    async def _on_click(self, event: events.Click):
        event.stop()
        if not self._disabled:
            self.post_message(self.Selected(self.action_name))


class ContextMenuPopup(Vertical):
    """Floating context menu that sits on top of the chat."""

    DEFAULT_CSS = """
    ContextMenuPopup {
        layer: overlay;
        width: auto; height: auto; max-width: 90;
        border: solid $primary-background;
        background: $surface;
        padding: 0;
    }
    """

    def __init__(self, x: int, y: int, block_preview: str = "", **kwargs):
        super().__init__(**kwargs)
        self._x = x
        self._y = y
        self._block_preview = block_preview

    def compose(self) -> ComposeResult:
        if self._block_preview:
            preview = self._block_preview[:80].replace("\n", " ")
            if len(self._block_preview) > 80:
                preview += "..."
            yield Static(f" {preview}", classes="preview")
            yield ContextMenuItem("Copy block", "copy_block")
        yield ContextMenuItem("Copy last response", "copy_last")
        yield ContextMenuItem("Copy all", "copy_all")

    def on_mount(self):
        self.styles.offset = (self._x, self._y)
