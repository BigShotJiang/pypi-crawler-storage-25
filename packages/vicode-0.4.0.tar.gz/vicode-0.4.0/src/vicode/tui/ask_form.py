"""Modal questionnaire for the ask_user tool.

Renders a sequence of questions one at a time:
- Up/Down: navigate options
- Space: toggle (in multi-select questions)
- Tab: switch focus between options list and free-text input
- Enter: confirm current question and advance to the next
- Right arrow: go forward (same as Enter)
- Left arrow: go back to the previous question
- Esc: cancel the entire questionnaire

Each option may carry a `description` and an `image` (markdown / image path)
that show when the option is highlighted. The result is a list of dicts, one
per question, each containing `selected` (list of values) and `free_text`.
"""

from __future__ import annotations

from typing import Callable

from rich.markdown import Markdown
from rich.panel import Panel
from rich.text import Text
from textual.app import ComposeResult
from textual.binding import Binding
from textual.containers import Vertical
from textual.screen import ModalScreen
from textual.widgets import Input, Static


class AskUserScreen(ModalScreen):
    """Modal screen that presents a guided questionnaire to the user."""

    BINDINGS = [
        Binding("up", "move_up", show=False),
        Binding("down", "move_down", show=False),
        Binding("space", "toggle", show=False),
        Binding("enter", "advance", show=False),
        Binding("right", "advance", show=False),
        Binding("left", "go_back", show=False),
        Binding("escape", "cancel", show=False),
        Binding("tab", "switch_focus", show=False),
    ]

    DEFAULT_CSS = """
    AskUserScreen {
        align: center middle;
        background: rgba(0, 0, 0, 0.5);
    }
    AskUserScreen > Vertical {
        width: 80%;
        max-width: 100;
        height: auto;
        max-height: 80%;
        background: $surface;
        border: thick $primary;
        padding: 1 2;
    }
    AskUserScreen #question {
        text-style: bold;
        color: $text;
        margin-bottom: 1;
    }
    AskUserScreen #options {
        height: auto;
        max-height: 14;
        margin-bottom: 1;
    }
    AskUserScreen #detail {
        height: auto;
        max-height: 12;
        margin-bottom: 1;
        color: $text-muted;
    }
    AskUserScreen #free_input {
        margin-bottom: 1;
    }
    AskUserScreen #footer {
        color: $text-muted;
        text-align: center;
    }
    """

    def __init__(
        self,
        questions: list[dict],
        on_done: Callable[[list[dict] | None], None],
    ):
        super().__init__()
        self.questions = questions
        self.on_done = on_done
        # State per question: {"highlight": int, "selected": set[int], "free_text": str}
        self.state: list[dict] = []
        for _ in questions:
            self.state.append({
                "highlight": 0,
                "selected": set(),
                "free_text": "",
            })
        self.idx: int = 0
        self.focus_target: str = "options"  # "options" | "free"

    def compose(self) -> ComposeResult:
        # Static widgets need a non-None renderable for `to_strips` to work,
        # passing "" used to crash on Textual's render path with
        # AttributeError: 'NoneType' object has no attribute 'render_strips'.
        # Initialise with Text(" ") so they're valid renderables.
        yield Vertical(
            Static(Text(" "), id="header"),
            Static(Text(" "), id="question"),
            Static(Text(" "), id="options"),
            Static(Text(" "), id="detail"),
            Static(Text(" "), id="free_label"),
            Input(
                placeholder="Type a custom answer here, then press Enter…",
                id="free_input",
            ),
            Static(Text(" "), id="footer"),
        )

    # --- Handle Enter while the free-text Input has focus ------------------
    # The Input widget consumes the Enter keypress for its own Submitted
    # message, so the screen-level `enter` binding never fires. We forward
    # the submission to action_advance ourselves.
    def on_input_submitted(self, event) -> None:
        event.stop()
        self.action_advance()

    def on_mount(self) -> None:
        self._redraw()

    # --- Rendering ---------------------------------------------------------

    def _current_question(self) -> dict:
        return self.questions[self.idx]

    def _current_state(self) -> dict:
        return self.state[self.idx]

    def _redraw(self) -> None:
        # Don't name this `_render` — Textual's widget base class uses that
        # name for its visual-render hook; overriding it with a None-return
        # function crashes the whole app at first paint.
        q = self._current_question()
        s = self._current_state()
        self.query_one("#header", Static).update(
            Text(f"Question {self.idx + 1} of {len(self.questions)}", style="dim")
        )
        self.query_one("#question", Static).update(
            Text(q.get("text", ""), style="bold")
        )

        # Options list
        opts = q.get("options", []) or []
        multi = q.get("multi_select", False)
        lines = []
        for i, opt in enumerate(opts):
            cursor = "▶" if i == s["highlight"] else " "
            if multi:
                box = "[x]" if i in s["selected"] else "[ ]"
            else:
                box = "(•)" if i in s["selected"] else "( )"
            label = opt.get("label", opt.get("value", "?"))
            style = "bold" if i == s["highlight"] else ""
            lines.append(Text(f"{cursor} {box} {label}", style=style))
        if not opts:
            lines.append(Text("(no options — use the free-text field below)", style="dim"))
        # Combine into one renderable
        from rich.console import Group
        self.query_one("#options", Static).update(Group(*lines))

        # Detail panel: shows description + image of the highlighted option.
        detail_renderable = Text(" ")
        if opts and 0 <= s["highlight"] < len(opts):
            opt = opts[s["highlight"]]
            desc = opt.get("description", "")
            image = opt.get("image", "")
            chunks = []
            if desc:
                chunks.append(str(desc))
            if image:
                # If it looks like a path, wrap as markdown image; otherwise
                # assume the model already provided markdown.
                img_str = str(image)
                if img_str.startswith(("http://", "https://", "./", "/")) or (
                    "." in img_str and not img_str.startswith("![")
                ):
                    chunks.append(f"![option]({img_str})")
                else:
                    chunks.append(img_str)
            if chunks:
                try:
                    detail_renderable = Panel(
                        Markdown("\n\n".join(chunks)),
                        border_style="dim",
                        title="details",
                    )
                except Exception:
                    detail_renderable = Text("\n\n".join(chunks), style="dim")
        self.query_one("#detail", Static).update(detail_renderable)

        # Free-text label — make the purpose explicit and dim it when the
        # focus is on the options panel (then highlight when active).
        allow_free = q.get("allow_free_text", True)
        if allow_free:
            label_style = "bold" if self.focus_target == "free" else "dim"
            label_text = Text(
                "  ─ or write your own answer if none of the above fits ─",
                style=label_style,
            )
        else:
            label_text = Text("")
        self.query_one("#free_label", Static).update(label_text)

        # Free input — restore the saved text and toggle disabled state
        free = self.query_one("#free_input", Input)
        # Avoid redundant changed events
        if free.value != s["free_text"]:
            free.value = s["free_text"]
        free.disabled = not allow_free

        # Footer hints
        nav = "↑↓ choose · enter/→ next · ← prev"
        if multi:
            nav += " · space toggle"
        nav += " · tab → free text · esc cancel"
        self.query_one("#footer", Static).update(Text(nav, style="dim"))

        # Focus
        if self.focus_target == "free" and not free.disabled:
            free.focus()
        else:
            # Steal focus away from the Input so arrow keys reach the screen
            self.set_focus(None)

    # --- Actions -----------------------------------------------------------

    def action_move_up(self) -> None:
        opts = self._current_question().get("options", []) or []
        if not opts or self.focus_target == "free":
            return
        s = self._current_state()
        s["highlight"] = (s["highlight"] - 1) % len(opts)
        self._redraw()

    def action_move_down(self) -> None:
        opts = self._current_question().get("options", []) or []
        if not opts or self.focus_target == "free":
            return
        s = self._current_state()
        s["highlight"] = (s["highlight"] + 1) % len(opts)
        self._redraw()

    def action_toggle(self) -> None:
        if self.focus_target == "free":
            return
        q = self._current_question()
        opts = q.get("options", []) or []
        if not opts:
            return
        s = self._current_state()
        idx = s["highlight"]
        if q.get("multi_select"):
            if idx in s["selected"]:
                s["selected"].remove(idx)
            else:
                s["selected"].add(idx)
        else:
            s["selected"] = {idx}
        self._redraw()

    def action_advance(self) -> None:
        # Capture the free-text value first.
        free = self.query_one("#free_input", Input)
        self._current_state()["free_text"] = free.value
        s = self._current_state()
        q = self._current_question()
        opts = q.get("options") or []
        free_provided = bool(free.value.strip())
        # If the user typed a free answer, that's their choice — don't also
        # auto-select an option. Otherwise (focus on options panel and
        # nothing selected), the highlighted option becomes the answer.
        if not free_provided and not s["selected"] and opts and self.focus_target == "options":
            s["selected"] = {s["highlight"]}
        # Advance / submit
        if self.idx < len(self.questions) - 1:
            self.idx += 1
            self.focus_target = "options"
            self._redraw()
        else:
            self._submit()

    def action_go_back(self) -> None:
        if self.idx > 0:
            # Save current free-text before stepping back.
            free = self.query_one("#free_input", Input)
            self._current_state()["free_text"] = free.value
            self.idx -= 1
            self.focus_target = "options"
            self._redraw()

    def action_switch_focus(self) -> None:
        if self.focus_target == "options":
            self.focus_target = "free"
        else:
            self.focus_target = "options"
        self._redraw()

    def action_cancel(self) -> None:
        self.on_done(None)
        self.dismiss()

    # --- Submission --------------------------------------------------------

    def _submit(self) -> None:
        results: list[dict] = []
        for q, s in zip(self.questions, self.state):
            opts = q.get("options", []) or []
            selected_values = []
            selected_labels = []
            for i in sorted(s["selected"]):
                if 0 <= i < len(opts):
                    selected_labels.append(opts[i].get("label", ""))
                    selected_values.append(
                        opts[i].get("value", opts[i].get("label", ""))
                    )
            results.append({
                "question": q.get("text", ""),
                "selected_values": selected_values,
                "selected_labels": selected_labels,
                "free_text": s["free_text"].strip(),
            })
        self.on_done(results)
        self.dismiss()
