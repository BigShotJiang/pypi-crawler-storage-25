"""Input area widget with smart paste, slash command autocomplete, and input history."""

import json
import re
from pathlib import Path
from textual import events
from textual.widgets import TextArea
from textual.message import Message

from vicode.providers import CONFIG_DIR


PASTE_COLLAPSE_THRESHOLD = 200
HISTORY_FILE = CONFIG_DIR / "input_history.json"
MAX_HISTORY = 200


class InputHistory:
    """Persistent input history with arrow key navigation."""

    def __init__(self):
        self._entries: list[str] = []
        self._index: int = -1  # -1 = not navigating
        self._draft: str = ""  # what user was typing before navigating
        self._load()

    def _load(self):
        try:
            if HISTORY_FILE.exists():
                data = json.loads(HISTORY_FILE.read_text(encoding="utf-8"))
                self._entries = data[-MAX_HISTORY:]
        except Exception:
            self._entries = []

    def _save(self):
        try:
            CONFIG_DIR.mkdir(parents=True, exist_ok=True)
            HISTORY_FILE.write_text(
                json.dumps(self._entries[-MAX_HISTORY:]),
                encoding="utf-8",
            )
        except Exception:
            pass

    def add(self, text: str):
        text = text.strip()
        if not text:
            return
        # Don't duplicate consecutive entries
        if self._entries and self._entries[-1] == text:
            return
        self._entries.append(text)
        self._save()
        self.reset()

    def reset(self):
        self._index = -1
        self._draft = ""

    def up(self, current_text: str) -> str | None:
        """Navigate up (older). Returns entry or None if at top."""
        if not self._entries:
            return None
        if self._index == -1:
            self._draft = current_text
            self._index = len(self._entries) - 1
        elif self._index > 0:
            self._index -= 1
        else:
            return None  # already at oldest
        return self._entries[self._index]

    def down(self, current_text: str) -> str | None:
        """Navigate down (newer). Returns entry or draft."""
        if self._index == -1:
            return None
        if self._index < len(self._entries) - 1:
            self._index += 1
            return self._entries[self._index]
        else:
            # Back to draft
            self._index = -1
            return self._draft


class UserInput(TextArea):
    """Multi-line input with Enter to submit, Shift+Enter for newline,
    Tab autocomplete, and Up/Down history navigation."""

    class Submitted(Message):
        def __init__(self, text: str):
            super().__init__()
            self.text = text

    def __init__(self, **kwargs):
        super().__init__(
            id="user-input",
            language=None,
            soft_wrap=True,
            show_line_numbers=False,
            tab_behavior="indent",
            **kwargs,
        )
        self._paste_store: dict[int, str] = {}
        self._paste_counter = 0
        self._history = InputHistory()

    def _store_paste(self, text: str) -> str:
        self._paste_counter += 1
        tag = self._paste_counter
        self._paste_store[tag] = text
        lines = text.count("\n") + 1
        return f"[Paste #{tag} +{lines} lines]"

    def _expand_pastes(self, text: str) -> str:
        def replacer(m):
            tag = int(m.group(1))
            return self._paste_store.pop(tag, m.group(0))
        return re.sub(r"\[Paste #(\d+) \+\d+ lines\]", replacer, text)

    def handle_paste(self, text: str) -> None:
        if len(text) > PASTE_COLLAPSE_THRESHOLD:
            text = self._store_paste(text)
        if result := self._replace_via_keyboard(text, *self.selection):
            self.move_cursor(result.end_location)

    async def _on_paste(self, event: events.Paste) -> None:
        event.prevent_default()
        event.stop()
        self.handle_paste(event.text)

    async def _on_mouse_down(self, event: events.MouseDown) -> None:
        """Handle right-click to paste clipboard content."""
        if event.button == 2:  # Right mouse button
            event.prevent_default()
            event.stop()
            try:
                import pyperclip
                clipboard_content = pyperclip.paste()
                if clipboard_content:
                    self.handle_paste(clipboard_content)
            except Exception:
                pass

    def _set_text(self, text: str):
        """Replace all text in the input."""
        self.clear()
        if text and (result := self._replace_via_keyboard(text, *self.selection)):
            self.move_cursor(result.end_location)

    async def _on_key(self, event: events.Key):
        if event.key == "enter":
            event.prevent_default()
            event.stop()
            text = self.text.strip()
            if text:
                self._history.add(text)
                expanded = self._expand_pastes(text)
                self.post_message(self.Submitted(expanded))
                self.clear()
        elif event.key == "shift+enter":
            pass
        elif event.key == "up":
            # Only navigate history if on first line
            if self.cursor_location[0] == 0:
                event.prevent_default()
                event.stop()
                entry = self._history.up(self.text)
                if entry is not None:
                    self._set_text(entry)
        elif event.key == "down":
            # Only navigate history if on last line
            lines = self.text.count("\n")
            if self.cursor_location[0] >= lines:
                event.prevent_default()
                event.stop()
                entry = self._history.down(self.text)
                if entry is not None:
                    self._set_text(entry)
        elif event.key == "tab":
            text = self.text
            if text.startswith("/") and " " not in text:
                event.prevent_default()
                event.stop()
                self._autocomplete_command(text[1:])

    def _autocomplete_command(self, prefix: str):
        try:
            app = self.app
            commands = app._commands
            matches = commands.match(prefix)
            if len(matches) == 1:
                self.clear()
                if result := self._replace_via_keyboard(f"/{matches[0].name} ", *self.selection):
                    self.move_cursor(result.end_location)
            # Multiple matches are shown in the command palette; nothing extra needed here
        except Exception:
            pass
