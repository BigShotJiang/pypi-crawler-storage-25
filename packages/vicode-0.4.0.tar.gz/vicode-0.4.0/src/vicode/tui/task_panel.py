"""Task panel widget - shows plan tasks and their progress."""

from textual.widgets import Static


class TaskPanel(Static):
    """Compact task list, visible only when a plan is active."""

    def __init__(self, **kwargs):
        # Initialise with a non-empty placeholder — Static("") triggers
        # `'NoneType' object has no attribute 'render_strips'` on render
        # in some Textual versions. We hide via display:none until tasks
        # are added, but the renderable still needs to be valid.
        super().__init__(" ", **kwargs)

    DEFAULT_CSS = """
    TaskPanel {
        height: auto; max-height: 8;
        padding: 0 1;
        color: $text-muted;
        display: none;
    }
    TaskPanel.-visible { display: block; }
    """

    def update_tasks(self, tasks):
        """Update the task list from PlanTask objects."""
        if not tasks:
            self.remove_class("-visible")
            return

        self.add_class("-visible")
        done = sum(1 for t in tasks if t.status == "done")
        total = len(tasks)
        bar_w = 10
        filled = int(done / total * bar_w) if total else 0

        lines = [f"  Tasks [{done}/{total}] {'█' * filled}{'░' * (bar_w - filled)}"]
        for t in tasks:
            icon = {"done": "✓", "in_progress": "→", "pending": "○"}.get(t.status, "○")
            desc = t.description[:65]
            lines.append(f"    {icon} {desc}")

        self.update("\n".join(lines))
