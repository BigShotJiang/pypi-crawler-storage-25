"""Command palette shown above the input while typing /commands."""

from textual.widgets import Static
from rich.text import Text


_NAME_COL = 16   # chars reserved for the /name column (longest: /consolidate = 13)
_DESC_MAX = 58   # max description chars before truncation


class CommandPalette(Static):
    """Filtered command list rendered above the input while typing /commands.

    Hidden by default (display: none). Call show_commands() / hide() to toggle.
    """

    DEFAULT_CSS = """
    CommandPalette {
        height: auto;
        display: none;
        background: $panel;
        padding: 0 1;
        border-bottom: solid $primary-darken-3;
    }
    """

    def __init__(self, **kwargs):
        super().__init__(" ", markup=False, **kwargs)

    def show_commands(self, commands: list, prefix: str = "") -> None:
        """Render up to 10 filtered commands; hide when list is empty."""
        if not commands:
            self.display = False
            return

        visible = commands[:10]
        overflow = len(commands) - len(visible)

        content = Text()
        for i, cmd in enumerate(visible):
            if i > 0:
                content.append("\n")
            # Name column — highlight matched prefix
            full_name = f"/{cmd.name}"
            padded = f"{full_name:<{_NAME_COL}}"
            if prefix and cmd.name.lower().startswith(prefix.lower()):
                # Bold the matched part, dim the rest
                matched_len = len(prefix) + 1  # +1 for the /
                content.append(padded[:matched_len], style="bold cyan")
                content.append(padded[matched_len:], style="cyan")
            else:
                content.append(padded, style="cyan")

            # Description column
            desc = cmd.description
            if len(desc) > _DESC_MAX:
                desc = desc[:_DESC_MAX - 1] + "…"
            content.append(desc, style="dim")

        if overflow:
            content.append(f"\n  … and {overflow} more", style="dim italic")

        self.update(content)
        self.display = True

    def hide(self) -> None:
        self.display = False
        self.update("")
