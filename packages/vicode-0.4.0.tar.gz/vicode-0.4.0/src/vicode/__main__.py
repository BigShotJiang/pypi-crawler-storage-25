import argparse
import os
import sys
import time

from vicode.config import Config
from vicode.db.sessions import SessionDB
from vicode.providers import get_or_setup_config, run_setup_wizard

try:
    from importlib.metadata import version

    __VERSION__ = version("vicode")
except Exception:
    __VERSION__ = "0.3"


def parse_args():
    p = argparse.ArgumentParser(description="Vicode - Local LLM coding agent")
    p.add_argument("-v", "--version", action="store_true", help="Show version")
    p.add_argument(
        "--port",
        type=int,
        default=None,
        help="llama-server port (overrides saved config)",
    )
    p.add_argument(
        "--host", default=None, help="llama-server host (overrides saved config)"
    )
    p.add_argument("--model", default=None, help="Model name (overrides saved config)")
    p.add_argument("--no-tui", action="store_true", help="Run in plain CLI mode")
    p.add_argument("--cwd", default=None, help="Working directory")
    p.add_argument("--setup", action="store_true", help="Re-run provider setup wizard")
    p.add_argument(
        "--provider",
        default=None,
        help="Override provider (local, openai-login, claude-code, anthropic-raw, etc.)",
    )
    p.add_argument("--api-key", default=None, help="API key for the LLM endpoint")
    p.add_argument(
        "-p",
        "--prompt",
        default=None,
        help="Run a single prompt non-interactively and exit",
    )
    p.add_argument(
        "--agent", default=None, help="Path to agent persona/system prompt .md file"
    )
    p.add_argument(
        "--consolidate-memory", action="store_true", help="Consolidate project memory"
    )
    p.add_argument(
        "--reindex", action="store_true", help="Rebuild the documentation index"
    )
    p.add_argument(
        "--json-output",
        action="store_true",
        help="In -p mode, emit a single JSON report to stdout (suppresses streaming)",
    )
    p.add_argument(
        "--quiet",
        action="store_true",
        help="In -p mode, suppress per-tool stderr markers; keep the final analysis",
    )
    p.add_argument(
        "--debug",
        action="store_true",
        help="Print tracebacks instead of swallowing analysis/reporting errors",
    )
    return p.parse_args()


def build_config(args) -> Config:
    """Build Config from saved provider config + CLI overrides."""
    if args.setup:
        pcfg = run_setup_wizard()
    else:
        pcfg = get_or_setup_config()

    # CLI args override saved config
    if args.host or args.port:
        host = args.host or "localhost"
        if host.startswith("http://") or host.startswith("https://"):
            # Full URL provided — use as-is, append /v1 if missing
            server_url = host.rstrip("/")
            if not server_url.endswith("/v1"):
                server_url += "/v1"
        else:
            port = args.port or 8080
            server_url = f"http://{host}:{port}/v1"
    else:
        server_url = pcfg.base_url

    provider = args.provider or pcfg.provider

    skip_ssl = pcfg.skip_ssl_verify if hasattr(pcfg, "skip_ssl_verify") else False
    if args.host and args.host.startswith("https://"):
        skip_ssl = True

    return Config(
        provider=provider,
        server_url=server_url,
        model=args.model or pcfg.model,
        api_key=args.api_key or pcfg.api_key,
        skip_ssl_verify=skip_ssl,
        cwd=args.cwd or os.getcwd(),
        agent_file=args.agent or "",
    )


def save_session_snapshot(session_db: SessionDB, session_id: int, agent):
    msgs = agent.history.get_messages()
    session_db.save_messages(session_id, msgs)
    session = session_db.get_session(session_id)
    if session and not session.title:
        for msg in msgs:
            if msg.get("role") == "user" and msg.get("content"):
                session_db.update_title(
                    session_id, msg["content"][:60].replace("\n", " ")
                )
                break


def cli_loop(agent, session_db: SessionDB, session_id: int):
    print(f"Vicode - type 'exit' to quit, 2x Ctrl+C to force quit")
    print(f"Server: {agent.config.server_url}")
    print(f"Model: {agent.config.model}")
    print(f"CWD: {agent.config.cwd}")
    print(f"Session: #{session_id}")
    print("-" * 50)

    last_ctrlc = 0.0
    while True:
        try:
            user_input = input("\n> ")
            last_ctrlc = 0.0
        except (EOFError, KeyboardInterrupt):
            now = time.monotonic()
            if (now - last_ctrlc) < 2.0:
                save_session_snapshot(session_db, session_id, agent)
                print("\nBye.")
                break
            last_ctrlc = now
            print("\nPress Ctrl+C again to quit.")
            continue

        if user_input.strip().lower() in ("exit", "quit"):
            save_session_snapshot(session_db, session_id, agent)
            break
        if not user_input.strip():
            continue

        for event in agent.run(user_input):
            match event:
                case {"type": "content_delta", "text": text}:
                    print(text, end="", flush=True)
                case {"type": "content_done"}:
                    print()
                case {"type": "tool_start", "name": name}:
                    print(f"\n[tool:{name}] ", end="", flush=True)
                case {"type": "tool_args_delta", "text": text}:
                    pass
                case {
                    "type": "tool_result",
                    "name": name,
                    "content": content,
                    "is_error": err,
                }:
                    prefix = "ERROR" if err else "OK"
                    display = (
                        content
                        if len(content) < 500
                        else content[:250] + "\n...\n" + content[-250:]
                    )
                    print(f"[{prefix}] {display}")
                case {"type": "error", "message": msg}:
                    print(f"\n[ERROR] {msg}", file=sys.stderr)
                case {"type": "done"}:
                    pass
        save_session_snapshot(session_db, session_id, agent)


_EDIT_BLOCK_RE = None
_APPLY_N_RE = None
_CREATE_FILE_RE = None


def _parse_expected_counts(prompt: str) -> tuple[int | None, int | None]:
    """Heuristically parse how many edits/file creations the user asked for.

    Returns (expected_edits, expected_creates). Either can be None if not detected.
    Recognized patterns (Spanish or English):
      - "APLICA N edits" / "APPLY N edits" / "N edits"  -> expected edits
      - Lines starting with "EDIT N -" or "EDIT N —"    -> expected edits (count lines)
      - "CREA EL ARCHIVO:" / "CREATE THE FILE:"          -> expected creates (count occurrences)
    """
    import re

    global _EDIT_BLOCK_RE, _APPLY_N_RE, _CREATE_FILE_RE
    if _EDIT_BLOCK_RE is None:
        _EDIT_BLOCK_RE = re.compile(r"(?mi)^\s*EDIT\s+\d+\s*[-\u2013\u2014]")
        _APPLY_N_RE = re.compile(
            r"(?i)\b(?:APLICA|APPLY)\s+(\d+)\s+edit", re.UNICODE
        )
        _CREATE_FILE_RE = re.compile(
            r"(?i)\b(?:CREA\s+EL\s+ARCHIVO|CREATE\s+THE\s+FILE)\s*:"
        )

    edits: int | None = None
    m = _APPLY_N_RE.search(prompt)
    if m:
        edits = int(m.group(1))
    else:
        blocks = _EDIT_BLOCK_RE.findall(prompt)
        if blocks:
            edits = len(blocks)

    creates: int | None = None
    files = _CREATE_FILE_RE.findall(prompt)
    if files:
        creates = len(files)

    return edits, creates


def _extract_tool_stats(trace_events: list) -> tuple[dict, list]:
    """Return (tool_breakdown, files_touched) from trace events."""
    tool_breakdown: dict[str, int] = {}
    files_touched: list[str] = []
    for event in trace_events or []:
        if event.get("type") != "tool_execution":
            continue
        payload = event.get("payload", {}) or {}
        name = payload.get("tool_name", "") or ""
        tool_breakdown[name] = tool_breakdown.get(name, 0) + 1
        if name in ("file_write", "file_edit"):
            args = payload.get("args", {}) or {}
            fp = args.get("file_path")
            if fp and fp not in files_touched:
                files_touched.append(fp)
    return tool_breakdown, files_touched


def run_single_prompt(
    agent,
    session_db: SessionDB,
    session_id: int,
    prompt: str,
    json_output: bool = False,
    quiet: bool = False,
    debug: bool = False,
) -> int:
    """Run a single prompt non-interactively. Returns exit code."""
    import io

    sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding="utf-8", errors="replace")
    sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding="utf-8", errors="replace")
    output_parts: list[str] = []
    error_messages: list[str] = []
    had_error = False
    start_time = time.monotonic()
    in_thinking = False
    for event in agent.run(prompt):
        match event:
            case {"type": "content_delta", "text": text}:
                if in_thinking and not json_output:
                    # Close thinking styling before regular content
                    print("\x1b[0m", end="", flush=True)
                    in_thinking = False
                if not json_output:
                    print(text, end="", flush=True)
                output_parts.append(text)
            case {"type": "thinking_delta", "text": text}:
                if not json_output:
                    if not in_thinking:
                        # Dim italic gray for thinking
                        print("\x1b[2;3;90m", end="", flush=True)
                        in_thinking = True
                    print(text, end="", flush=True)
            case {"type": "content_done"}:
                if in_thinking and not json_output:
                    print("\x1b[0m", end="", flush=True)
                    in_thinking = False
                if not json_output:
                    print()
            case {"type": "tool_start", "name": _name}:
                if in_thinking and not json_output:
                    print("\x1b[0m", end="", flush=True)
                    in_thinking = False
            case {"type": "tool_executing", "name": name, "args": _args}:
                if in_thinking and not json_output:
                    print("\x1b[0m", end="", flush=True)
                    in_thinking = False
                if not json_output and not quiet:
                    print(f"[{name}]", end=" ", flush=True, file=sys.stderr)
            case {"type": "tool_result", "name": _name, "is_error": err}:
                if err:
                    had_error = True
            case {"type": "error", "message": msg}:
                if not json_output:
                    print(f"ERROR: {msg}", file=sys.stderr)
                had_error = True
                error_messages.append(str(msg))

    save_session_snapshot(session_db, session_id, agent)

    duration = time.monotonic() - start_time
    trace_events = session_db.load_trace(session_id) or []
    tool_breakdown, files_touched = _extract_tool_stats(trace_events)

    expected_edits, expected_creates = _parse_expected_counts(prompt)
    actual_edits = tool_breakdown.get("file_edit", 0)
    actual_creates = tool_breakdown.get("file_write", 0)
    warnings: list[str] = []
    if expected_edits is not None and actual_edits < expected_edits:
        warnings.append(
            f"Requested {expected_edits} edits but only {actual_edits} file_edit calls "
            f"were made — slice likely incomplete."
        )
    if expected_creates is not None and actual_creates < expected_creates:
        warnings.append(
            f"Requested {expected_creates} file creations but only {actual_creates} "
            f"file_write calls were made."
        )

    exit_code = 1 if had_error and not output_parts else 0

    if json_output:
        import json

        report = {
            "session_id": session_id,
            "exit_code": exit_code,
            "had_error": had_error,
            "errors": error_messages,
            "duration_seconds": round(duration, 2),
            "total_tools": sum(tool_breakdown.values()),
            "tool_breakdown": tool_breakdown,
            "files_touched": files_touched,
            "expected_edits": expected_edits,
            "expected_creates": expected_creates,
            "warnings": warnings,
            "content": "".join(output_parts),
        }
        print(json.dumps(report, indent=2))
        return exit_code

    if trace_events:
        try:
            from vicode.agent.session_analysis import analyze_session, format_analysis

            analysis = analyze_session(session_id, trace_events)
            analysis.duration_seconds = duration
            print(file=sys.stderr)
            print("=" * 40, file=sys.stderr)
            print(format_analysis(analysis), file=sys.stderr)
        except Exception as e:
            if debug:
                import traceback

                traceback.print_exc(file=sys.stderr)
            else:
                print(
                    f"(session analysis skipped: {type(e).__name__}: {e})",
                    file=sys.stderr,
                )

    for w in warnings:
        print(f"WARNING: {w}", file=sys.stderr)

    return exit_code


def run_consolidate_memory(config: Config) -> int:
    from engram import Memory
    from vicode.agent.learning import run_memory_consolidation

    session_db = SessionDB()
    try:
        result = run_memory_consolidation(session_db, Memory(), cwd=config.cwd)
    finally:
        session_db.close()

    print(f"Memory namespace: {result['namespace']}")
    print(f"Successful sessions considered: {result['sessions_considered']}")
    print(f"Deleted noisy/redundant memories: {result['deleted_count']}")
    print(f"Stored new learnings: {result['stored_count']}")
    for candidate in result["added_candidates"][:10]:
        print(f"- [{candidate['type']}] {candidate['content'][:160]}")
    return 0


def main():
    args = parse_args()

    if args.version:
        print(f"vicode {__VERSION__}")
        sys.exit(0)

    config = build_config(args)

    if args.reindex:
        from vicode.tools.docs_index import DocsIndexTool
        print("Reindexing documentation...")
        tool = DocsIndexTool(cwd=config.cwd)
        result = tool.run(action="rebuild", force=True)
        if result.is_error:
            print(f"Error: {result.content}", file=sys.stderr)
            sys.exit(1)
        else:
            print(result.content)
            sys.exit(0)

    if args.consolidate_memory:
        try:
            exit_code = run_consolidate_memory(config)
        except Exception as e:
            if args.debug:
                import traceback

                traceback.print_exc(file=sys.stderr)
            else:
                print(f"Consolidation failed: {type(e).__name__}: {e}", file=sys.stderr)
            sys.exit(1)
        sys.exit(exit_code)

    # Single prompt mode: -p "do something"
    if args.prompt:
        from vicode.agent.loop import AgentLoop
        from vicode.agent.tracing import TraceRecorder
        from vicode.llm.client import LLMClient
        from vicode.tools.registry import create_default_registry

        if config.model == "auto":
            client = LLMClient(config)
            detected = client.detect_and_apply(config)
            if not detected:
                print("Could not connect. Run 'vicode --setup'.", file=sys.stderr)
                sys.exit(1)

        session_db = SessionDB()
        session_id = session_db.create_session(
            cwd=config.cwd, model=config.model, title=args.prompt[:60]
        )
        registry = create_default_registry(config)
        agent = AgentLoop(
            config=config,
            tools=registry,
            trace_recorder=TraceRecorder(session_db, session_id),
        )
        exit_code = run_single_prompt(
            agent,
            session_db,
            session_id,
            args.prompt,
            json_output=args.json_output,
            quiet=args.quiet,
            debug=args.debug,
        )
        session_db.close()
        sys.exit(exit_code)

    if not args.no_tui:
        from vicode.tui.app import VicodeApp

        app = VicodeApp(config)
        result = app.run()
        if result == "setup":
            pcfg = run_setup_wizard()
            config.server_url = pcfg.base_url
            config.api_key = pcfg.api_key
            config.model = pcfg.model
            VicodeApp(config).run()
        return

    # CLI interactive mode
    from vicode.agent.loop import AgentLoop
    from vicode.agent.tracing import TraceRecorder
    from vicode.llm.client import LLMClient
    from vicode.tools.registry import create_default_registry

    if config.model == "auto":
        client = LLMClient(config)
        detected = client.detect_and_apply(config)
        if not detected:
            print("Could not connect. Run 'vicode --setup'.", file=sys.stderr)
            sys.exit(1)

    session_db = SessionDB()
    session_id = session_db.create_session(cwd=config.cwd, model=config.model)
    registry = create_default_registry(config)
    agent = AgentLoop(
        config=config,
        tools=registry,
        trace_recorder=TraceRecorder(session_db, session_id),
    )
    cli_loop(agent, session_db, session_id)
    session_db.close()


if __name__ == "__main__":
    main()
