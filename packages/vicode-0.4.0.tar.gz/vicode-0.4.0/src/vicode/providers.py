"""Provider configuration - auto-detection, setup wizard, OAuth, persistent config."""

import hashlib
import json
import os
import secrets
import base64
import time
import webbrowser
from dataclasses import dataclass
from http.server import HTTPServer, BaseHTTPRequestHandler
from pathlib import Path
from threading import Thread
from urllib.parse import urlencode, urlparse, parse_qs

import httpx


CONFIG_DIR = Path.home() / ".vicode"
CONFIG_FILE = CONFIG_DIR / "config.json"
AUTH_FILE = CONFIG_DIR / "auth.json"

# OpenAI OAuth - uses Codex CLI public client (PKCE, no secret)
OPENAI_OAUTH = {
    "client_id": "app_EMoamEEZ73f0CkXaXp7hrann",
    "authorize_url": "https://auth.openai.com/oauth/authorize",
    "token_url": "https://auth.openai.com/oauth/token",
    "scopes": "openid profile email offline_access",
    "redirect_port": 1455,
}

# Paths where Codex CLI stores its auth tokens
CODEX_AUTH_PATHS = [
    Path.home() / ".codex" / "auth.json",
    Path.home() / ".local" / "share" / "codex" / "auth.json",
    Path.home() / ".local" / "share" / "opencode" / "auth.json",
]

CODEX_MODELS = [
    "gpt-5.1-codex",
    "gpt-5.1-codex-mini",
    "gpt-5.1-codex-max",
    "gpt-5.2-codex",
    "gpt-5.2",
    "gpt-5.1",
]

PROVIDERS = {
    "local": {
        "name": "Local (llama-server / Ollama)",
        "base_url": "http://localhost:8080/v1",
        "needs_key": False,
    },
    "openai-login": {
        "name": "OpenAI (browser login - ChatGPT Plus/Pro)",
        "base_url": "https://chatgpt.com/backend-api",
        "needs_key": False,
        "default_model": "gpt-5.1-codex",
        "oauth": True,
        "models": CODEX_MODELS,
    },
    "openai": {
        "name": "OpenAI (API key)",
        "base_url": "https://api.openai.com/v1",
        "needs_key": True,
        "default_model": "gpt-4o",
        "key_url": "https://platform.openai.com/api-keys",
    },
    "claude-code": {
        "name": "Claude Code (Claude executes tools)",
        "base_url": "claude-cli",
        "needs_key": False,
        "default_model": "sonnet",
        "models": ["sonnet", "opus", "haiku"],
    },
    "anthropic-raw": {
        "name": "Anthropic Raw (vicode controls tools via Claude CLI)",
        "base_url": "claude-cli",
        "needs_key": False,
        "default_model": "opus",
        "models": ["opus", "sonnet", "haiku"],
    },
    "anthropic": {
        "name": "Anthropic (API key)",
        "base_url": "https://api.anthropic.com/v1",
        "needs_key": True,
        "default_model": "claude-sonnet-4-5-20250514",
        "key_url": "https://console.anthropic.com/settings/keys",
    },
    "openrouter": {
        "name": "OpenRouter (200+ models)",
        "base_url": "https://openrouter.ai/api/v1",
        "needs_key": True,
        "default_model": "anthropic/claude-sonnet-4-5",
        "key_url": "https://openrouter.ai/keys",
    },
    "groq": {
        "name": "Groq (fast inference)",
        "base_url": "https://api.groq.com/openai/v1",
        "needs_key": True,
        "default_model": "llama-3.3-70b-versatile",
        "key_url": "https://console.groq.com/keys",
    },
    "ia-dungeon": {
        "name": "IA Dungeon (remote llama-server proxy)",
        "base_url": "https://n8n-endikavi.ddns.net/api/llm-proxy/v1",
        "needs_key": True,
        "default_model": "auto",
        "skip_ssl_verify": True,
    },
    "custom": {
        "name": "Custom (any OpenAI-compatible endpoint)",
        "base_url": "",
        "needs_key": False,
        "default_model": "auto",
    },
}

LOCAL_ENDPOINTS = [
    ("http://localhost:8080/v1", "llama-server"),
    ("http://localhost:11434/v1", "ollama"),
    ("http://localhost:1234/v1", "lm-studio"),
]


@dataclass
class ProviderConfig:
    provider: str
    base_url: str
    api_key: str
    model: str
    skip_ssl_verify: bool = False
    auto_compact_every: int = 0      # 0 = disabled
    auto_compact_keep_last: int = 5

    def to_dict(self) -> dict:
        d = {"provider": self.provider, "base_url": self.base_url, "model": self.model}
        if self.api_key:
            d["api_key"] = self.api_key
        if self.skip_ssl_verify:
            d["skip_ssl_verify"] = True
        if self.auto_compact_every:
            d["auto_compact_every"] = self.auto_compact_every
        if self.auto_compact_keep_last != 5:
            d["auto_compact_keep_last"] = self.auto_compact_keep_last
        return d

    @classmethod
    def from_dict(cls, d: dict) -> "ProviderConfig":
        return cls(
            provider=d.get("provider", "local"),
            base_url=d.get("base_url", "http://localhost:8080/v1"),
            api_key=d.get("api_key", ""),
            model=d.get("model", "auto"),
            skip_ssl_verify=d.get("skip_ssl_verify", False),
            auto_compact_every=d.get("auto_compact_every", 0),
            auto_compact_keep_last=d.get("auto_compact_keep_last", 5),
        )


# --- OAuth PKCE flow for OpenAI ---

def _generate_pkce() -> tuple[str, str]:
    """Generate PKCE code_verifier and code_challenge (S256)."""
    verifier = secrets.token_urlsafe(32)
    digest = hashlib.sha256(verifier.encode("ascii")).digest()
    challenge = base64.urlsafe_b64encode(digest).rstrip(b"=").decode("ascii")
    return verifier, challenge


class _OAuthCallbackHandler(BaseHTTPRequestHandler):
    """HTTP handler that captures the OAuth callback."""
    auth_code = None
    state = None

    def do_GET(self):
        parsed = urlparse(self.path)
        params = parse_qs(parsed.query)
        _OAuthCallbackHandler.auth_code = params.get("code", [None])[0]
        _OAuthCallbackHandler.state = params.get("state", [None])[0]
        self.send_response(200)
        self.send_header("Content-Type", "text/html")
        self.end_headers()
        self.wfile.write(b"<html><body><h2>Authenticated! You can close this tab.</h2></body></html>")

    def log_message(self, *args):
        pass  # silence logs


def _save_oauth_tokens(tokens: dict):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    tokens["saved_at"] = time.time()
    AUTH_FILE.write_text(json.dumps(tokens, indent=2), encoding="utf-8")


def _load_oauth_tokens() -> dict | None:
    if not AUTH_FILE.exists():
        return None
    try:
        tokens = json.loads(AUTH_FILE.read_text(encoding="utf-8"))
        return tokens if tokens.get("access_token") else None
    except Exception:
        return None


def _refresh_oauth_token(refresh_token: str) -> dict | None:
    """Refresh an expired OAuth token."""
    try:
        resp = httpx.post(
            OPENAI_OAUTH["token_url"],
            data={
                "grant_type": "refresh_token",
                "client_id": OPENAI_OAUTH["client_id"],
                "refresh_token": refresh_token,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            tokens = resp.json()
            _save_oauth_tokens(tokens)
            return tokens
    except Exception:
        pass
    return None


def get_openai_oauth_token() -> str | None:
    """Get a valid OAuth token, refreshing if needed."""
    tokens = _load_oauth_tokens()
    if not tokens:
        return None

    # Check if expired (with 5min buffer)
    expires_in = tokens.get("expires_in", 3600)
    saved_at = tokens.get("saved_at", 0)
    if time.time() > saved_at + expires_in - 300:
        # Try refresh
        refresh = tokens.get("refresh_token")
        if refresh:
            refreshed = _refresh_oauth_token(refresh)
            if refreshed:
                return refreshed["access_token"]
        return None

    return tokens.get("access_token")


def _find_codex_tokens() -> dict | None:
    """Check if Codex CLI or OpenCode already has valid tokens."""
    for path in CODEX_AUTH_PATHS:
        if path.exists():
            try:
                data = json.loads(path.read_text(encoding="utf-8"))
                # Codex CLI nests tokens under "tokens" key
                tokens = data.get("tokens", data)
                if tokens.get("access_token"):
                    return tokens
            except Exception:
                continue
    return None


def run_openai_oauth() -> str | None:
    """Authenticate with OpenAI. Tries: existing Codex tokens, then browser OAuth."""

    # 1. Check for existing Codex CLI / OpenCode tokens
    existing = _find_codex_tokens()
    if existing:
        print("  Found existing OpenAI auth from Codex/OpenCode!")
        token = existing.get("access_token")
        _save_oauth_tokens(existing)
        # Try to validate
        try:
            resp = httpx.get(
                "https://api.openai.com/v1/models",
                headers={"Authorization": f"Bearer {token}"},
                timeout=10,
            )
            if resp.status_code == 200:
                print("  Token is valid!")
                return token
            else:
                # Try refresh
                refresh = existing.get("refresh_token")
                if refresh:
                    refreshed = _refresh_oauth_token(refresh)
                    if refreshed:
                        print("  Token refreshed!")
                        return refreshed["access_token"]
        except Exception:
            pass
        print("  Existing token expired, trying browser login...")

    # 2. Browser OAuth PKCE flow
    verifier, challenge = _generate_pkce()
    state = secrets.token_urlsafe(16)
    port = OPENAI_OAUTH["redirect_port"]
    redirect_uri = f"http://localhost:{port}/auth/callback"

    auth_params = urlencode({
        "client_id": OPENAI_OAUTH["client_id"],
        "redirect_uri": redirect_uri,
        "response_type": "code",
        "scope": OPENAI_OAUTH["scopes"],
        "code_challenge": challenge,
        "code_challenge_method": "S256",
        "state": state,
        "codex_cli_simplified_flow": "true",
        "originator": "codex_cli_rs",
    })
    auth_url = f"{OPENAI_OAUTH['authorize_url']}?{auth_params}"

    _OAuthCallbackHandler.auth_code = None
    _OAuthCallbackHandler.state = None
    try:
        server = HTTPServer(("127.0.0.1", port), _OAuthCallbackHandler)
    except OSError:
        print(f"  Port {port} in use. Is Codex CLI running?")
        return None
    server.timeout = 120

    print("  Opening browser for OpenAI login...")
    webbrowser.open(auth_url)
    print("  Waiting for authentication (2 min timeout)...")

    while _OAuthCallbackHandler.auth_code is None:
        server.handle_request()

    server.server_close()
    code = _OAuthCallbackHandler.auth_code

    if not code or _OAuthCallbackHandler.state != state:
        print("  Authentication failed.")
        return None

    # Exchange code for tokens
    print("  Exchanging code for token...")
    try:
        resp = httpx.post(
            OPENAI_OAUTH["token_url"],
            data={
                "grant_type": "authorization_code",
                "client_id": OPENAI_OAUTH["client_id"],
                "code": code,
                "redirect_uri": redirect_uri,
                "code_verifier": verifier,
            },
            timeout=15,
        )
        if resp.status_code == 200:
            tokens = resp.json()
            _save_oauth_tokens(tokens)
            print("  Authenticated!")
            return tokens.get("access_token")
        else:
            print(f"  Failed: {resp.status_code}")
            return None
    except Exception as e:
        print(f"  Error: {e}")
        return None


# --- Detection & Config ---

def detect_local_server() -> tuple[str, str] | None:
    for url, name in LOCAL_ENDPOINTS:
        try:
            resp = httpx.get(f"{url}/models", timeout=2)
            if resp.status_code == 200:
                data = resp.json()
                models = data.get("data", data.get("models", []))
                model_name = "auto"
                if models:
                    first = models[0]
                    model_name = first.get("id", first.get("name", "auto"))
                return url, model_name
        except Exception:
            continue
    return None


def load_config() -> ProviderConfig | None:
    if not CONFIG_FILE.exists():
        return None
    try:
        data = json.loads(CONFIG_FILE.read_text(encoding="utf-8"))
        cfg = ProviderConfig.from_dict(data)
        # If OAuth provider, refresh token if needed
        if cfg.provider == "openai-login":
            token = get_openai_oauth_token()
            if token:
                cfg.api_key = token
            else:
                return None  # token expired, force re-auth
        return cfg
    except Exception:
        return None


def save_config(config: ProviderConfig):
    CONFIG_DIR.mkdir(parents=True, exist_ok=True)
    CONFIG_FILE.write_text(json.dumps(config.to_dict(), indent=2), encoding="utf-8")


def run_setup_wizard() -> ProviderConfig:
    print("\n  Vicode - Provider Setup")
    print("  " + "-" * 40)

    # Try local first
    print("\n  Checking for local LLM servers...")
    local = detect_local_server()
    if local:
        url, model = local
        print(f"  Found: {model} at {url}")
        answer = input("  Use this? [Y/n] ").strip().lower()
        if answer in ("", "y", "yes", "s", "si"):
            cfg = ProviderConfig(provider="local", base_url=url, api_key="not-needed", model=model)
            save_config(cfg)
            print(f"  Saved!")
            return cfg

    # Show provider options
    print("\n  Select a provider:\n")
    provider_list = list(PROVIDERS.items())
    for i, (key, info) in enumerate(provider_list, 1):
        print(f"    {i}. {info['name']}")
    print()

    while True:
        try:
            choice = input("  Enter number: ").strip()
            idx = int(choice) - 1
            if 0 <= idx < len(provider_list):
                break
        except (ValueError, EOFError):
            pass
        print("  Invalid choice.")

    provider_key, provider_info = provider_list[idx]
    base_url = provider_info["base_url"]

    if provider_key == "local":
        custom = input(f"  Server URL [{base_url}]: ").strip()
        if custom:
            base_url = custom if custom.endswith("/v1") else custom.rstrip("/") + "/v1"
        cfg = ProviderConfig(provider="local", base_url=base_url, api_key="not-needed", model="auto")

    elif provider_info.get("oauth"):
        # OAuth flow
        token = run_openai_oauth()
        if not token:
            print("  OAuth failed. Falling back to API key.")
            print(f"  Get your API key at: {PROVIDERS['openai'].get('key_url', '')}")
            token = input("  API key: ").strip()
            if not token:
                raise SystemExit(1)
            provider_key = "openai"
        model = provider_info.get("default_model", "gpt-4o")
        custom_model = input(f"  Model [{model}]: ").strip()
        if custom_model:
            model = custom_model
        cfg = ProviderConfig(provider=provider_key, base_url=base_url, api_key=token, model=model)

    elif provider_key == "custom":
        # Custom OpenAI-compatible endpoint
        print("\n  Enter the base URL of your OpenAI-compatible server.")
        print("  Examples: http://192.168.1.50:8080/v1, https://my-server.com/v1")
        base_url = input("  Base URL: ").strip()
        if not base_url:
            print("  No URL provided. Aborting.")
            raise SystemExit(1)
        if not base_url.endswith("/v1"):
            base_url = base_url.rstrip("/") + "/v1"
        api_key = input("  API key (leave empty if not needed): ").strip() or "not-needed"
        # Try to detect model
        model = "auto"
        try:
            resp = httpx.get(f"{base_url}/models", timeout=5,
                             headers={"Authorization": f"Bearer {api_key}"} if api_key != "not-needed" else {})
            if resp.status_code == 200:
                data = resp.json()
                models = data.get("data", data.get("models", []))
                if models:
                    model = models[0].get("id", models[0].get("name", "auto"))
                    print(f"  Detected model: {model}")
        except Exception:
            pass
        custom_model = input(f"  Model [{model}]: ").strip()
        if custom_model:
            model = custom_model
        cfg = ProviderConfig(provider="custom", base_url=base_url, api_key=api_key, model=model)

    elif provider_key == "ia-dungeon":
        # IA Dungeon remote proxy (self-signed cert)
        api_key = input("  API key: ").strip()
        if not api_key:
            print("  No API key provided. Aborting.")
            raise SystemExit(1)
        model = "auto"
        try:
            resp = httpx.get(
                f"{base_url}/models", timeout=5, verify=False,
                headers={"Authorization": f"Bearer {api_key}"},
            )
            if resp.status_code == 200:
                data = resp.json()
                models = data.get("data", data.get("models", []))
                if models:
                    model = models[0].get("id", models[0].get("name", "auto"))
                    print(f"  Detected model: {model}")
        except Exception:
            print("  Could not reach server (model auto-detect skipped)")
        custom_model = input(f"  Model [{model}]: ").strip()
        if custom_model:
            model = custom_model
        cfg = ProviderConfig(
            provider="ia-dungeon", base_url=base_url, api_key=api_key,
            model=model, skip_ssl_verify=True,
        )

    elif not provider_info.get("needs_key"):
        # No key needed (claude-code, anthropic-raw, etc.)
        model = provider_info.get("default_model", "auto")
        custom_model = input(f"  Model [{model}]: ").strip()
        if custom_model:
            model = custom_model
        cfg = ProviderConfig(provider=provider_key, base_url=base_url, api_key="not-needed", model=model)

    else:
        print(f"\n  Get your API key at: {provider_info.get('key_url', '')}")
        api_key = input("  API key: ").strip()
        if not api_key:
            print("  No API key provided. Aborting.")
            raise SystemExit(1)
        model = provider_info.get("default_model", "auto")
        custom_model = input(f"  Model [{model}]: ").strip()
        if custom_model:
            model = custom_model
        cfg = ProviderConfig(provider=provider_key, base_url=base_url, api_key=api_key, model=model)

    save_config(cfg)
    print(f"\n  Saved!")
    return cfg


def get_or_setup_config() -> ProviderConfig:
    cfg = load_config()
    if cfg:
        return cfg

    local = detect_local_server()
    if local:
        url, model = local
        cfg = ProviderConfig(provider="local", base_url=url, api_key="not-needed", model=model)
        save_config(cfg)
        return cfg

    return run_setup_wizard()
