"""Claude Code CLI client - uses claude as a subprocess for LLM + tool execution.

Unlike other providers where vicode controls tool execution, Claude Code
handles everything internally (LLM calls + tool execution). Vicode just
passes the prompt and streams the output.
"""

import json
import subprocess
from typing import Generator

from vicode.config import Config


def _build_claude_cmd(config: Config, system_prompt: str = "") -> list[str]:
    """Build the claude CLI command."""
    cmd = [
        "claude",
        "-p",  # print mode (non-interactive)
        "--output-format", "stream-json",
        "--verbose",
        "--no-session-persistence",
        "--dangerously-skip-permissions",
    ]
    if config.model and config.model != "auto":
        cmd.extend(["--model", config.model])
    if system_prompt:
        cmd.extend(["--system-prompt", system_prompt])
    return cmd


def _format_history_as_prompt(messages: list[dict]) -> str:
    """Convert message history into a single prompt string for claude CLI.

    Since claude -p takes a single prompt, we format the conversation
    history as context + the latest user message.
    """
    system = ""
    history_lines = []
    last_user = ""

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""

        if role == "system":
            system = content
        elif role == "user":
            last_user = content
        elif role == "assistant" and content:
            history_lines.append(f"[Previous assistant response]: {content[:500]}")
        elif role == "tool":
            history_lines.append(f"[Previous tool result]: {content[:300]}")

    # Build the full prompt
    parts = []
    if history_lines:
        parts.append("Context from earlier in this conversation:")
        parts.extend(history_lines[-10:])  # Last 10 history items
        parts.append("")
        parts.append("Current request:")
    parts.append(last_user)

    return "\n".join(parts)


class ClaudeClient:
    """Client that uses Claude Code CLI as a backend."""

    def __init__(self, config: Config):
        self.config = config

    def detect_model(self) -> str | None:
        """Check if claude CLI is available and return model."""
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                model = self.config.model
                if model == "auto":
                    return "sonnet"
                return model
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return None

    def stream(self, messages: list[dict], tools: list[dict] | None = None) -> Generator[dict, None, None]:
        """Run claude CLI and yield iter_stream-compatible events."""
        # Extract system prompt and format history
        system = ""
        for msg in messages:
            if msg.get("role") == "system":
                system = msg.get("content", "")
                break

        prompt = _format_history_as_prompt(messages)
        cmd = _build_claude_cmd(self.config, system)

        # Run claude as subprocess with prompt on stdin
        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            cwd=self.config.cwd,
        )

        # Send prompt and close stdin
        proc.stdin.write(prompt)
        proc.stdin.close()

        # Parse streaming JSON output
        tool_index = 0
        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue

            yield from self._parse_event(data, tool_index)
            # Track tool index for tool_call events
            if data.get("type") == "assistant":
                for c in data.get("message", {}).get("content", []):
                    if c.get("type") == "tool_use":
                        tool_index += 1

        proc.wait()

    def _parse_event(self, data: dict, tool_index: int) -> Generator[dict, None, None]:
        """Convert claude stream-json event to iter_stream events."""
        event_type = data.get("type", "")

        if event_type == "assistant":
            msg = data.get("message", {})
            for content in msg.get("content", []):
                ct = content.get("type", "")

                if ct == "text":
                    text = content.get("text", "")
                    if text:
                        yield {"type": "content_delta", "text": text}
                        yield {"type": "content_done"}

                elif ct == "tool_use":
                    name = content.get("name", "")
                    args = json.dumps(content.get("input", {}))
                    call_id = content.get("id", f"call_{tool_index}")
                    # Emit early tool detection
                    yield {
                        "type": "tool_early",
                        "index": tool_index,
                        "id": call_id,
                        "name": name,
                    }
                    yield {
                        "type": "tool_call_delta",
                        "index": tool_index,
                        "id": call_id,
                        "name": name,
                        "arguments": args,
                    }
                    yield {
                        "type": "tool_call_done",
                        "index": tool_index,
                        "id": call_id,
                        "name": name,
                        "arguments": args,
                    }

        elif event_type == "tool":
            # Tool execution result from Claude
            msg = data.get("message", {})
            content = msg.get("content", "")
            if isinstance(content, list):
                for c in content:
                    if isinstance(c, dict) and c.get("type") == "text":
                        text = c.get("text", "")[:200]
                        yield {"type": "content_delta", "text": f"\n  [tool output: {text}]\n"}
                        yield {"type": "content_done"}

        elif event_type == "result":
            usage = data.get("usage", {})
            yield {
                "type": "finish",
                "reason": data.get("stop_reason", "stop"),
                "usage": {
                    "prompt_tokens": usage.get("input_tokens", 0) + usage.get("cache_read_input_tokens", 0),
                    "completion_tokens": usage.get("output_tokens", 0),
                    "total_tokens": (
                        usage.get("input_tokens", 0)
                        + usage.get("cache_read_input_tokens", 0)
                        + usage.get("output_tokens", 0)
                    ),
                },
            }

    def health_check(self) -> bool:
        return self.detect_model() is not None
