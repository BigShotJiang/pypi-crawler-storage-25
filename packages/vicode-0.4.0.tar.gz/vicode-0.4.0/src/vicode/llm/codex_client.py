"""Codex Responses API client for ChatGPT Plus/Pro OAuth tokens.

Converts Chat Completions format (messages + tools) to Responses API format
(input items + tools) and parses SSE responses back to the same event types
that iter_stream produces, so AgentLoop needs no changes.
"""

import json
import base64
import threading
import time
from typing import Generator

import httpx

from vicode.config import Config

CODEX_URL = "https://chatgpt.com/backend-api/codex/responses"

# Global mutex to serialize Codex API calls (Cloudflare blocks parallel requests)
_codex_lock = threading.Lock()
_codex_last_call = 0.0
_CODEX_MIN_INTERVAL = 2.0  # minimum seconds between API calls


def _extract_account_id(token: str) -> str | None:
    """Extract chatgpt_account_id from JWT access token."""
    try:
        payload = token.split(".")[1]
        payload += "=" * (4 - len(payload) % 4)
        data = json.loads(base64.b64decode(payload))
        auth = data.get("https://api.openai.com/auth", {})
        return auth.get("chatgpt_account_id")
    except Exception:
        return None


def _messages_to_input(messages: list[dict]) -> tuple[str, list[dict]]:
    """Convert Chat Completions messages to Responses API input items.

    Returns (system_instructions, input_items).
    """
    instructions = ""
    items = []

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""

        if role == "system":
            instructions = content
            continue

        if role == "user":
            items.append({
                "type": "message",
                "role": "user",
                "content": [{"type": "input_text", "text": content}],
            })

        elif role == "assistant":
            if content:
                items.append({
                    "type": "message",
                    "role": "assistant",
                    "content": [{"type": "output_text", "text": content}],
                })
            for tc in msg.get("tool_calls", []):
                fn = tc.get("function", {})
                name = fn.get("name", "")
                if not name:
                    continue  # Skip tool calls with empty name
                items.append({
                    "type": "function_call",
                    "name": name,
                    "arguments": fn.get("arguments", ""),
                    "call_id": tc.get("id", ""),
                })

        elif role == "tool":
            # Only include output if there's a matching function_call with a name
            call_id = msg.get("tool_call_id", "")
            # Check if we have a corresponding function_call in items
            has_call = any(
                i.get("type") == "function_call" and i.get("call_id") == call_id
                for i in items
            )
            if has_call:
                items.append({
                    "type": "function_call_output",
                    "call_id": call_id,
                    "output": content,
                })

    return instructions, items


def _tools_to_responses_format(tools: list[dict]) -> list[dict]:
    """Convert OpenAI function tools to Responses API format."""
    result = []
    for tool in tools:
        if tool.get("type") == "function":
            fn = tool["function"]
            result.append({
                "type": "function",
                "name": fn["name"],
                "description": fn.get("description", ""),
                "parameters": fn.get("parameters", {}),
            })
    return result


def _parse_sse_events(response: httpx.Response) -> Generator[dict, None, None]:
    """Parse SSE stream from Responses API into iter_stream-compatible events.

    Converts Responses API events to the same format as iter_stream:
    - content_delta, content_done
    - tool_call_delta, tool_call_done
    - finish
    """
    # Key insight: output_item.added uses item.id AND item.call_id
    # argument deltas reference item_id (which is item.id, NOT call_id)
    # We key by item_id since that's what deltas use
    tool_calls: dict[str, dict] = {}  # item_id -> {name, arguments, index, call_id}
    tool_index = 0
    had_content = False

    for line in response.iter_lines():
        if not line.startswith("data:"):
            continue
        data_str = line[5:].strip()
        if not data_str or data_str == "[DONE]":
            continue

        try:
            data = json.loads(data_str)
        except json.JSONDecodeError:
            continue

        event_type = data.get("type", "")

        # Text output
        if event_type == "response.output_text.delta":
            had_content = True
            yield {"type": "content_delta", "text": data.get("delta", "")}

        elif event_type == "response.output_text.done":
            if had_content:
                yield {"type": "content_done"}
                had_content = False

        # Output item added - arrives FIRST, has item.id + item.call_id + item.name
        elif event_type == "response.output_item.added":
            item = data.get("item", {})
            if item.get("type") == "function_call":
                item_id = item.get("id", "")
                call_id = item.get("call_id", item_id)
                name = item.get("name", "")
                if item_id and item_id not in tool_calls:
                    tool_calls[item_id] = {
                        "name": name,
                        "arguments": "",
                        "index": tool_index,
                        "call_id": call_id,
                    }
                    tool_index += 1
                    # Emit early tool detection as soon as we know the name
                    yield {
                        "type": "tool_early",
                        "index": tool_index - 1,
                        "id": call_id,
                        "name": name,
                    }

        # Argument deltas - keyed by item_id
        elif event_type == "response.function_call_arguments.delta":
            item_id = data.get("item_id", "")
            if item_id not in tool_calls:
                tool_calls[item_id] = {
                    "name": "",
                    "arguments": "",
                    "index": tool_index,
                    "call_id": item_id,
                }
                tool_index += 1
            tc = tool_calls[item_id]
            delta = data.get("delta", "")
            tc["arguments"] += delta
            yield {
                "type": "tool_call_delta",
                "index": tc["index"],
                "id": tc["call_id"],
                "name": tc["name"],
                "arguments": delta,
            }

        # Arguments done
        elif event_type == "response.function_call_arguments.done":
            item_id = data.get("item_id", "")
            if item_id in tool_calls:
                tc = tool_calls[item_id]
                full_args = data.get("arguments")
                if full_args:
                    tc["arguments"] = full_args
                yield {
                    "type": "tool_call_done",
                    "index": tc["index"],
                    "id": tc["call_id"],
                    "name": tc["name"],
                    "arguments": tc["arguments"],
                }

        # Output item done - final confirmation of name
        elif event_type == "response.output_item.done":
            item = data.get("item", {})
            if item.get("type") == "function_call":
                item_id = item.get("id", "")
                if item_id in tool_calls:
                    name = item.get("name", "")
                    call_id = item.get("call_id", "")
                    if name:
                        tool_calls[item_id]["name"] = name
                    if call_id:
                        tool_calls[item_id]["call_id"] = call_id

        # Response completed
        elif event_type in ("response.completed", "response.done"):
            usage = None
            resp = data.get("response", data)
            if resp.get("usage"):
                u = resp["usage"]
                usage = {
                    "prompt_tokens": u.get("input_tokens", 0),
                    "completion_tokens": u.get("output_tokens", 0),
                    "total_tokens": u.get("total_tokens", 0),
                }
            yield {"type": "finish", "reason": "stop", "usage": usage}


class CodexClient:
    """Client for ChatGPT Plus/Pro via Codex Responses API."""

    def __init__(self, config: Config):
        self.config = config
        self._account_id: str | None = None

    def _get_account_id(self) -> str:
        if not self._account_id:
            self._account_id = _extract_account_id(self.config.api_key) or ""
        return self._account_id

    def detect_model(self) -> str | None:
        """Codex doesn't support model listing. Return default."""
        return self.config.model if self.config.model != "auto" else "gpt-5.1-codex"

    def stream(self, messages: list[dict], tools: list[dict] | None = None) -> Generator[dict, None, None]:
        """Send request to Codex Responses API and yield iter_stream events."""
        instructions, input_items = _messages_to_input(messages)

        # Final sanitization: remove any function_call with empty name and orphaned outputs
        clean_items = []
        valid_call_ids = set()
        for item in input_items:
            if item.get("type") == "function_call":
                if item.get("name"):
                    valid_call_ids.add(item.get("call_id", ""))
                    clean_items.append(item)
                # Skip items with empty name
            elif item.get("type") == "function_call_output":
                if item.get("call_id", "") in valid_call_ids:
                    clean_items.append(item)
                # Skip orphaned outputs
            else:
                clean_items.append(item)

        body: dict = {
            "model": self.config.model,
            "instructions": instructions,
            "input": clean_items,
            "stream": True,
            "store": False,
            "reasoning": {"effort": "medium", "summary": "auto"},
            "include": ["reasoning.encrypted_content"],
        }

        if tools:
            body["tools"] = _tools_to_responses_format(tools)

        headers = {
            "Authorization": f"Bearer {self.config.api_key}",
            "chatgpt-account-id": self._get_account_id(),
            "OpenAI-Beta": "responses=experimental",
            "originator": "codex_cli_rs",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }

        # Serialize Codex API calls to avoid Cloudflare blocking parallel requests
        global _codex_last_call
        with _codex_lock:
            elapsed = time.monotonic() - _codex_last_call
            if elapsed < _CODEX_MIN_INTERVAL:
                time.sleep(_CODEX_MIN_INTERVAL - elapsed)
            _codex_last_call = time.monotonic()

        with httpx.stream(
            "POST",
            CODEX_URL,
            json=body,
            headers=headers,
            timeout=self.config.timeout,
        ) as response:
            if response.status_code != 200:
                error_body = response.read().decode(errors="replace")[:300]
                raise Exception(f"Codex API error {response.status_code}: {error_body}")
            yield from _parse_sse_events(response)

    def health_check(self) -> bool:
        return bool(self.config.api_key and self.config.api_key != "not-needed")
