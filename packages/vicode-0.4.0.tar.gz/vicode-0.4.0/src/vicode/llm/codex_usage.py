"""Query Codex API usage/rate limit info from response headers."""

import json
import time
import httpx

from vicode.config import Config
from vicode.llm.codex_client import _extract_account_id, _messages_to_input, CODEX_URL


def get_codex_usage(config: Config) -> dict | None:
    """Make a minimal API call and capture rate limit headers."""
    try:
        aid = _extract_account_id(config.api_key)
        if not aid:
            return None

        msgs = [{"role": "system", "content": "."}, {"role": "user", "content": "."}]
        instr, items = _messages_to_input(msgs)
        body = {
            "model": config.model,
            "instructions": instr,
            "input": items,
            "stream": True,
            "store": False,
            "max_output_tokens": 1,
            "reasoning": {"effort": "low", "summary": "auto"},
            "include": ["reasoning.encrypted_content"],
        }
        headers = {
            "Authorization": f"Bearer {config.api_key}",
            "chatgpt-account-id": aid,
            "OpenAI-Beta": "responses=experimental",
            "originator": "codex_cli_rs",
            "Content-Type": "application/json",
            "Accept": "text/event-stream",
        }

        with httpx.stream("POST", CODEX_URL, json=body, headers=headers, timeout=15) as r:
            # Extract usage headers
            usage = {}
            for k, v in r.headers.items():
                if k.startswith("x-codex-"):
                    key = k.replace("x-codex-", "").replace("-", "_")
                    usage[key] = v
            # Consume stream to avoid connection issues
            for _ in r.iter_lines():
                pass
            return usage

    except Exception:
        return None


def format_usage(usage: dict) -> str:
    """Format usage dict into readable lines."""
    if not usage:
        return "  Could not fetch usage info."

    plan = usage.get("plan_type", "unknown")
    primary_pct = usage.get("primary_used_percent", "?")
    secondary_pct = usage.get("secondary_used_percent", "?")
    primary_window = int(usage.get("primary_window_minutes", 0))
    secondary_window = int(usage.get("secondary_window_minutes", 0))
    primary_reset = int(usage.get("primary_reset_after_seconds", 0))
    secondary_reset = int(usage.get("secondary_reset_after_seconds", 0))
    has_credits = usage.get("credits_has_credits", "False")
    balance = usage.get("credits_balance", "")
    unlimited = usage.get("credits_unlimited", "False")

    lines = [f"  Plan: ChatGPT {plan.title()}"]

    # Primary limit (short window, e.g. 5 hours)
    primary_h = primary_window // 60
    primary_reset_m = primary_reset // 60
    lines.append(f"  Short window ({primary_h}h): {primary_pct}% used, resets in {primary_reset_m}m")

    # Secondary limit (long window, e.g. 7 days)
    secondary_d = secondary_window // 1440
    secondary_reset_h = secondary_reset // 3600
    lines.append(f"  Long window ({secondary_d}d): {secondary_pct}% used, resets in {secondary_reset_h}h")

    # Credits
    if unlimited == "True":
        lines.append("  Credits: Unlimited")
    elif has_credits == "True" and balance:
        lines.append(f"  Credits: {balance}")
    else:
        lines.append("  Credits: None")

    return "\n".join(lines)
