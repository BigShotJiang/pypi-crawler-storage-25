"""Process streaming responses into typed events.

Handles both:
- OpenAI SDK ChatCompletionChunk objects (local/API key providers)
- Pre-parsed dict events from CodexClient (ChatGPT OAuth)
"""


class _ThinkSplitter:
    """Split incoming content text into (thinking, content) segments.

    Different model families wrap their reasoning in different tags:
      - Qwen 3.x, DeepSeek-R1, …: <think>…</think>
      - Gemma 3/4 finetunes:      <thought>…</thought>
      - Some Hermes-style models: <reasoning>…</reasoning>
    We accept all of them, since they're functionally identical: a span of
    text that should be styled distinctly and not stored in history.

    Tags may be split across chunks — the splitter buffers partial matches.
    """

    # Open/close pairs we recognise. Order does not matter — whichever opens
    # first wins. Lowercase comparison is done on the buffer.
    PAIRS = (
        ("<think>", "</think>"),
        ("<thought>", "</thought>"),
        ("<reasoning>", "</reasoning>"),
    )

    def __init__(self):
        self.in_think = False
        self.pending = ""
        self._closing_tag = ""  # which closing tag we expect, set on open

    def _all_open_tags(self):
        return [open_tag for open_tag, _ in self.PAIRS]

    def _find_first(self, buf, tags):
        """Return (idx, matched_tag) for the earliest occurrence of any tag,
        or (-1, "") if none."""
        best = -1
        best_tag = ""
        lower = buf.lower()
        for t in tags:
            i = lower.find(t.lower())
            if i != -1 and (best == -1 or i < best):
                best = i
                best_tag = t
        return best, best_tag

    def _partial_suffix(self, buf, tags):
        """Largest suffix of `buf` that matches a prefix of any candidate tag.
        Lets us hold back a half-open `<thi` until the next chunk arrives."""
        keep = 0
        lower = buf.lower()
        for t in tags:
            tlow = t.lower()
            for k in range(min(len(t) - 1, len(buf)), 0, -1):
                if lower[-k:] == tlow[:k]:
                    if k > keep:
                        keep = k
                    break
        return keep

    def feed(self, text):
        """Yield (kind, chunk) pairs. kind is 'thinking' or 'content'."""
        buf = self.pending + text
        self.pending = ""
        while buf:
            if self.in_think:
                tags = [self._closing_tag] if self._closing_tag else [
                    close for _, close in self.PAIRS
                ]
            else:
                tags = self._all_open_tags()
            idx, matched = self._find_first(buf, tags)
            if idx == -1:
                # No full tag present. Buffer a partial-tag suffix.
                keep = self._partial_suffix(buf, tags)
                if keep:
                    self.pending = buf[-keep:]
                    buf = buf[:-keep]
                if buf:
                    yield ("thinking" if self.in_think else "content", buf)
                return
            if idx > 0:
                yield ("thinking" if self.in_think else "content", buf[:idx])
            buf = buf[idx + len(matched):]
            if self.in_think:
                self.in_think = False
                self._closing_tag = ""
            else:
                self.in_think = True
                # Pair the matched open tag with its close tag.
                for o, c in self.PAIRS:
                    if o.lower() == matched.lower():
                        self._closing_tag = c
                        break

    def flush(self):
        if self.pending:
            yield ("thinking" if self.in_think else "content", self.pending)
            self.pending = ""


def iter_stream(stream):
    """Yields typed events from a streaming response.

    Events:
    - {"type": "content_delta", "text": str}
    - {"type": "thinking_delta", "text": str}  (model reasoning, shown styled)
    - {"type": "content_done"}
    - {"type": "tool_call_delta", "index": int, "id": str, "name": str, "arguments": str}
    - {"type": "tool_call_done", "index": int, "id": str, "name": str, "arguments": str}
    - {"type": "finish", "reason": str, "usage": dict|None}
    """
    # Peek at first item to detect stream type
    first = None
    for item in stream:
        first = item
        break
    if first is None:
        return

    if isinstance(first, dict):
        # CodexClient already produces our event format
        yield first
        yield from stream
    else:
        # OpenAI SDK ChatCompletionChunk objects
        yield from _iter_openai_chunks(first, stream)


class _DegenerateLoopGuard:
    """Detect when a model is stuck repeating roughly the same phrase.

    Some quantised / mis-templated models (Gemma 4 Q3) loop emitting the
    same idea over and over. We detect both:
      a) exact repetition of a short snippet (the original cheap check), and
      b) line-level repetition where >X% of recent lines normalise to the
         same string — catches loops where each iteration has tiny variance
         (whitespace, punctuation, the occasional swapped word).
    """

    WINDOW = 4000         # chars to keep in the tail
    MIN_REPEAT_LEN = 6
    MAX_REPEATS = 12      # threshold for exact repetition
    MIN_LINES_FOR_RATIO = 8
    DUPLICATE_LINE_THRESHOLD = 0.65  # >65% of lines identical → loop

    def __init__(self):
        self.tail = ""
        self._last_check_len = 0

    def _normalise(self, line: str) -> str:
        # Lowercase + collapse whitespace + drop trailing punctuation.
        s = " ".join(line.lower().split())
        return s.rstrip(".,;:!?…")

    def feed(self, text: str):
        if not text:
            return
        self.tail = (self.tail + text)[-self.WINDOW:]

        # Check (a): exact short-snippet repetition — fast.
        snippet = self.tail[-30:].strip()
        if len(snippet) >= self.MIN_REPEAT_LEN:
            count = self.tail.count(snippet)
            if count >= self.MAX_REPEATS:
                raise RuntimeError(
                    f"Stream aborted: degenerate loop detected — "
                    f"{count}× repetition of '{snippet[:50]}'"
                )

        # Check (b): only run every ~400 chars to keep cost low.
        if len(self.tail) - self._last_check_len < 400:
            return
        self._last_check_len = len(self.tail)

        lines = [self._normalise(l) for l in self.tail.split("\n") if l.strip()]
        if len(lines) < self.MIN_LINES_FOR_RATIO:
            return
        # Pick the most common normalised line.
        from collections import Counter
        counter = Counter(lines)
        top, top_n = counter.most_common(1)[0]
        if len(top) < self.MIN_REPEAT_LEN:
            return
        if top_n / len(lines) >= self.DUPLICATE_LINE_THRESHOLD:
            raise RuntimeError(
                f"Stream aborted: degenerate loop detected — line "
                f"'{top[:60]}' repeats in {top_n}/{len(lines)} non-empty lines"
            )


def _iter_openai_chunks(first_chunk, rest):
    """Process OpenAI SDK ChatCompletionChunk stream."""
    tool_calls: dict[int, dict] = {}
    had_content = False
    last_token_count = 0   # highest token count emitted so far
    chars_received = 0     # total chars seen (content + tool args) for estimation
    last_emitted_chars = 0  # chars at last estimated token_count emission
    splitter = _ThinkSplitter()
    loop_guard = _DegenerateLoopGuard()

    def process(chunk):
        nonlocal had_content, last_token_count, chars_received, last_emitted_chars
        if not chunk.choices:
            return

        choice = chunk.choices[0]
        delta = choice.delta

        # Some servers (llama.cpp with Qwen 3.6 thinking, DeepSeek-R1, etc.)
        # emit model reasoning in a non-standard `reasoning_content` field that
        # the OpenAI SDK ignores. Surface it as thinking so the UI can style
        # it distinctly from regular content.
        reasoning = getattr(delta, "reasoning_content", None) if delta else None
        if reasoning:
            had_content = True
            chars_received += len(reasoning)
            loop_guard.feed(reasoning)
            yield {"type": "thinking_delta", "text": reasoning}

        if delta and delta.content:
            had_content = True
            chars_received += len(delta.content)
            loop_guard.feed(delta.content)
            for kind, piece in splitter.feed(delta.content):
                yield {"type": f"{kind}_delta", "text": piece}

        if delta and delta.tool_calls:
            for tc_delta in delta.tool_calls:
                idx = tc_delta.index
                if idx not in tool_calls:
                    tool_calls[idx] = {"id": "", "name": "", "arguments": ""}

                if tc_delta.id:
                    tool_calls[idx]["id"] = tc_delta.id
                if tc_delta.function and tc_delta.function.name:
                    tool_calls[idx]["name"] = tc_delta.function.name
                    # Emit early tool detection as soon as we know the name
                    yield {
                        "type": "tool_early",
                        "index": idx,
                        "id": tool_calls[idx]["id"],
                        "name": tc_delta.function.name,
                    }
                if tc_delta.function and tc_delta.function.arguments:
                    chars_received += len(tc_delta.function.arguments)
                    tool_calls[idx]["arguments"] += tc_delta.function.arguments
                    yield {
                        "type": "tool_call_delta",
                        "index": idx,
                        "id": tool_calls[idx]["id"],
                        "name": tool_calls[idx]["name"],
                        "arguments": tc_delta.function.arguments,
                    }

        # Emit estimated token count every ~100 chars (~25 tokens) for ascending counter.
        # Works for providers that don't send usage on intermediate chunks (llama-server, etc.)
        if chars_received - last_emitted_chars >= 100:
            estimated = chars_received // 4
            if estimated > last_token_count:
                yield {"type": "token_count", "count": estimated}
                last_token_count = estimated
            last_emitted_chars = chars_received

        # Use actual completion tokens from API when available (overrides estimate)
        if hasattr(chunk, "usage") and chunk.usage and chunk.usage.completion_tokens:
            actual = chunk.usage.completion_tokens
            if actual > last_token_count:
                yield {"type": "token_count", "count": actual}
                last_token_count = actual

        if choice.finish_reason:
            # Flush any buffered partial <think> tag before emitting done.
            for kind, piece in splitter.flush():
                yield {"type": f"{kind}_delta", "text": piece}
            if had_content:
                yield {"type": "content_done"}
            for idx, tc in sorted(tool_calls.items()):
                yield {
                    "type": "tool_call_done",
                    "index": idx,
                    "id": tc["id"],
                    "name": tc["name"],
                    "arguments": tc["arguments"],
                }
            usage = None
            if hasattr(chunk, "usage") and chunk.usage:
                usage = {
                    "prompt_tokens": chunk.usage.prompt_tokens,
                    "completion_tokens": chunk.usage.completion_tokens,
                    "total_tokens": chunk.usage.total_tokens,
                }
                # OpenAI 2024 spec: prompt_tokens_details.cached_tokens
                details = getattr(chunk.usage, "prompt_tokens_details", None)
                cached = getattr(details, "cached_tokens", None) if details else None
                if cached is not None:
                    usage["cached_tokens"] = cached
            # llama.cpp also exposes cache reuse in `timings.cache_n` /
            # `timings.prompt_n` on the final chunk — surface those raw
            # since they're more reliable than the OpenAI shim.
            timings = getattr(chunk, "timings", None) or (
                chunk.model_extra or {}
            ).get("timings") if hasattr(chunk, "model_extra") else None
            if timings:
                cache_n = (
                    timings.get("cache_n") if isinstance(timings, dict)
                    else getattr(timings, "cache_n", None)
                )
                prompt_n = (
                    timings.get("prompt_n") if isinstance(timings, dict)
                    else getattr(timings, "prompt_n", None)
                )
                if cache_n is not None or prompt_n is not None:
                    usage = usage or {}
                    if cache_n is not None:
                        usage["cache_n"] = cache_n
                    if prompt_n is not None:
                        usage["prompt_n"] = prompt_n
            yield {"type": "finish", "reason": choice.finish_reason, "usage": usage}

    yield from process(first_chunk)
    for chunk in rest:
        yield from process(chunk)
