"""Claude Raw Client - uses Claude CLI as a dumb LLM proxy.

Vicode controls all tool execution. Claude just decides what to call.
The model sees tool definitions in the system prompt and responds with
structured JSON tool calls that vicode parses and executes.

This lets you benchmark Opus 4.6 / Sonnet with vicode's tools
independently of Claude Code's own tool implementation.
"""

import json
import subprocess
from typing import Generator

from vicode.config import Config


TOOL_CALL_MARKER = "<tool_call>"
TOOL_CALL_END = "</tool_call>"


def _tools_to_prompt(tools: list[dict]) -> str:
    """Format vicode's tool definitions for the system prompt."""
    lines = ["## IMPORTANT: External Tool System"]
    lines.append("")
    lines.append("You have an EXTERNAL tool system. Output ONE tool call per response like this:")
    lines.append("")
    lines.append(f"{TOOL_CALL_MARKER}")
    lines.append('{"name": "bash", "arguments": {"command": "ls -la"}}')
    lines.append(f"{TOOL_CALL_END}")
    lines.append("")
    lines.append("RULES:")
    lines.append("- ONE tool call per response. NEVER multiple tool calls.")
    lines.append("- STOP after the tool call. Do NOT predict the result.")
    lines.append("- The system executes the tool and returns results in <tool_result> tags.")
    lines.append("- Read the tool result, then decide your next action.")
    lines.append("- NEVER show code for the user to copy. Always use file_write or bash.")
    lines.append("- NEVER edit a file you haven't read first.")
    lines.append("- When you are COMPLETELY done with the task, end your response with <done/>.")
    lines.append("- If you still have work to do, make a tool call. Do NOT just describe what you plan to do.")
    lines.append("")
    lines.append("Available tools:\n")

    for tool in tools:
        fn = tool.get("function", tool)
        name = fn.get("name", "")
        desc = fn.get("description", "")
        params = fn.get("parameters", {})
        props = params.get("properties", {})
        required = params.get("required", [])

        lines.append(f"### {name}")
        lines.append(f"{desc}")
        if props:
            lines.append("Parameters:")
            for pname, pinfo in props.items():
                req = " (required)" if pname in required else ""
                lines.append(f"  - {pname}: {pinfo.get('type', 'string')} - {pinfo.get('description', '')}{req}")
        lines.append("")

    return "\n".join(lines)


def _format_messages(messages: list[dict], tools: list[dict] | None = None) -> tuple[str, str]:
    """Convert message history to system prompt + user prompt for claude CLI.

    Returns (system_prompt, user_prompt).
    """
    system_parts = []
    history = []
    last_user = ""

    for msg in messages:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""

        if role == "system":
            system_parts.append(content)
        elif role == "user":
            last_user = content
        elif role == "assistant":
            if content:
                history.append(f"[You said]: {content[:500]}")
            for tc in msg.get("tool_calls", []):
                fn = tc.get("function", {})
                name = fn.get("name", "")
                args_str = fn.get("arguments", "")
                try:
                    args_obj = json.loads(args_str) if args_str else {}
                except json.JSONDecodeError:
                    args_obj = {"_raw": args_str[:200]}
                history.append(f"[You called tool]: {TOOL_CALL_MARKER}\n{json.dumps({'name': name, 'arguments': args_obj})}\n{TOOL_CALL_END}")
        elif role == "tool":
            # Tool results are critical - show them clearly and with enough content
            tc_content = content[:2000]
            history.append(f"<tool_result>\n{tc_content}\n</tool_result>")

    # Add tool definitions to system prompt
    if tools:
        system_parts.append(_tools_to_prompt(tools))

    system = "\n\n".join(system_parts)

    # Build conversation prompt with clear structure
    prompt_parts = []
    if history:
        prompt_parts.append("=== Conversation so far ===")
        prompt_parts.extend(history[-20:])
        prompt_parts.append("=== End of conversation ===")
        prompt_parts.append("")
        prompt_parts.append("Continue from where you left off. If you received tool results above, use them to proceed. If a tool was executed successfully, build on its output.")
        prompt_parts.append("")
    prompt_parts.append(last_user)

    return system, "\n".join(prompt_parts)


def _parse_tool_calls(text: str) -> tuple[str, list[dict]]:
    """Extract the FIRST tool call from model response text.

    Only returns one tool call max - forces turn-by-turn execution.
    Returns (clean_text, tool_calls).
    """
    if TOOL_CALL_MARKER not in text:
        return text.strip(), []

    before, _, after = text.partition(TOOL_CALL_MARKER)
    clean_text = before.strip()

    if TOOL_CALL_END not in after:
        return clean_text, []

    tc_json, _, _ = after.partition(TOOL_CALL_END)
    tc_json = tc_json.strip()

    try:
        tc = json.loads(tc_json)
        tool_calls = [{
            "id": "call_0",
            "name": tc.get("name", ""),
            "arguments": json.dumps(tc.get("arguments", {})),
        }]
    except json.JSONDecodeError:
        return clean_text, []

    # Strip hallucinated outputs from text before the tool call
    if clean_text:
        import re
        clean_text = re.sub(r"<tool_response>.*?</tool_response>", "", clean_text, flags=re.DOTALL)
        clean_text = re.sub(r"<tool_result>.*?</tool_result>", "", clean_text, flags=re.DOTALL)
        clean_text = clean_text.strip()

    return clean_text, tool_calls


class ClaudeRawClient:
    """Uses Claude CLI as a raw LLM - vicode controls all tool execution."""

    def __init__(self, config: Config):
        self.config = config

    def detect_model(self) -> str | None:
        try:
            result = subprocess.run(
                ["claude", "--version"],
                capture_output=True, text=True, timeout=5,
            )
            if result.returncode == 0:
                return self.config.model if self.config.model != "auto" else "opus"
        except (FileNotFoundError, subprocess.TimeoutExpired):
            pass
        return None

    def stream(self, messages: list[dict], tools: list[dict] | None = None) -> Generator[dict, None, None]:
        """Send to Claude CLI with streaming JSON output."""
        system, prompt = _format_messages(messages, tools)

        cmd = [
            "claude",
            "-p",
            "--output-format", "stream-json",
            "--verbose",
            "--model", self.config.model or "opus",
            "--tools", "",
            "--strict-mcp-config",
            "--mcp-config", '{"mcpServers":{}}',
            "--no-session-persistence",
            "--dangerously-skip-permissions",
        ]
        if system:
            cmd.extend(["--system-prompt", system])

        proc = subprocess.Popen(
            cmd,
            stdin=subprocess.PIPE,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            text=True,
            encoding="utf-8",
            errors="replace",
            cwd=self.config.cwd,
        )

        proc.stdin.write(prompt)
        proc.stdin.close()

        # Stream line by line. Kill process as soon as we see </tool_call>
        # to prevent the model from hallucinating tool results.
        full_text = ""
        usage_data = {}
        found_tool_call = False
        streamed_before_tc = False

        for line in proc.stdout:
            line = line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                continue

            event_type = data.get("type", "")

            if event_type == "assistant":
                msg = data.get("message", {})
                for content in msg.get("content", []):
                    ct = content.get("type", "")
                    if ct == "text":
                        text = content.get("text", "")
                        full_text += text

                        # Check if we have a complete tool call
                        if TOOL_CALL_MARKER in full_text and TOOL_CALL_END in full_text:
                            found_tool_call = True
                            # Emit any text before the tool call marker
                            before_tc = full_text.split(TOOL_CALL_MARKER)[0].strip()
                            if before_tc and not streamed_before_tc:
                                yield {"type": "content_delta", "text": before_tc}
                                yield {"type": "content_done"}
                                streamed_before_tc = True
                            proc.kill()
                            break

                        # Stream text that's before any tool_call marker
                        if TOOL_CALL_MARKER not in full_text:
                            if text.strip():
                                yield {"type": "content_delta", "text": text}
                                streamed_before_tc = True

                if found_tool_call:
                    break

            elif event_type == "result":
                usage_data = data.get("usage", {})

        # Clean up process
        try:
            proc.kill()
        except Exception:
            pass
        proc.wait()

        # Parse tool calls from accumulated text
        clean_text, tool_calls = _parse_tool_calls(full_text)

        # Check if model signaled completion
        is_done = "<done/>" in full_text
        if is_done:
            clean_text = clean_text.replace("<done/>", "").strip()

        # If no tool call and text wasn't streamed yet, emit it now
        if not tool_calls and clean_text and not streamed_before_tc:
            yield {"type": "content_delta", "text": clean_text}
            yield {"type": "content_done"}
        elif not tool_calls and streamed_before_tc:
            yield {"type": "content_done"}

        # If no tool call and no <done/>, model wants to continue but forgot to call a tool
        # Force a "continue" by emitting a fake tool call that the loop will handle
        if not tool_calls and not is_done and clean_text:
            # The model described what it wants to do but didn't call a tool
            # We inject a hint back via a special finish reason
            yield {"type": "finish", "reason": "needs_continue", "usage": {
                "prompt_tokens": usage_data.get("input_tokens", 0),
                "completion_tokens": usage_data.get("output_tokens", 0),
                "total_tokens": usage_data.get("input_tokens", 0) + usage_data.get("output_tokens", 0),
            }}
            return

        for i, tc in enumerate(tool_calls):
            # Emit early tool detection
            yield {
                "type": "tool_early",
                "index": i,
                "id": tc["id"],
                "name": tc["name"],
            }
            yield {
                "type": "tool_call_delta",
                "index": i,
                "id": tc["id"],
                "name": tc["name"],
                "arguments": tc["arguments"],
            }
            yield {
                "type": "tool_call_done",
                "index": i,
                "id": tc["id"],
                "name": tc["name"],
                "arguments": tc["arguments"],
            }

        yield {
            "type": "finish",
            "reason": "tool_calls" if tool_calls else "stop",
            "usage": {
                "prompt_tokens": usage_data.get("input_tokens", 0) + usage_data.get("cache_read_input_tokens", 0),
                "completion_tokens": usage_data.get("output_tokens", 0),
                "total_tokens": (
                    usage_data.get("input_tokens", 0)
                    + usage_data.get("cache_read_input_tokens", 0)
                    + usage_data.get("output_tokens", 0)
                ),
            },
        }

    def health_check(self) -> bool:
        return self.detect_model() is not None
