"""Parse tool calls that models emit as text instead of structured tool_calls.

Some models (Qwen 3.x variants with non-standard chat templates, certain
fine-tunes) emit tool calls as XML-like text in the content stream instead of
through the OpenAI-structured `tool_calls` field. This module detects and
extracts those calls so the agent loop can execute them.

Supported formats:
  1. Qwen-style XML:
     <tool_call>
     <function=ls>
     <parameter=path>
     js/Game
     </parameter>
     </function>
     </tool_call>

  2. JSON inside tool_call tags:
     <tool_call>{"name": "ls", "arguments": {"path": "js/Game"}}</tool_call>
"""

from __future__ import annotations

import json
import re
import secrets


_TOOL_CALL_BLOCK_RE = re.compile(
    r"<tool_call>(.*?)</tool_call>", re.DOTALL | re.IGNORECASE
)
_FUNCTION_BLOCK_RE = re.compile(
    r"<function=([^>]+)>(.*?)</function>", re.DOTALL | re.IGNORECASE
)
_PARAMETER_BLOCK_RE = re.compile(
    r"<parameter=([^>]+)>(.*?)</parameter>", re.DOTALL | re.IGNORECASE
)

# Set by AgentLoop before each turn so we know which tag names should be
# treated as Gemma-style tool calls (vs. just XML-ish text).
_KNOWN_TOOL_NAMES: set[str] = set()


def set_known_tool_names(names) -> None:
    """Register the current set of tool names so the Gemma-style parser can
    distinguish actual tool calls (`<file_read>...</file_read>`) from random
    XML-ish content the model might emit."""
    global _KNOWN_TOOL_NAMES
    _KNOWN_TOOL_NAMES = {n for n in (names or []) if n}


def has_embedded_tool_calls(content: str | None) -> bool:
    """Quick check: does content contain embedded tool call markup?"""
    if not content:
        return False
    low = content.lower()
    if "<tool_call>" in low or "<function=" in low:
        return True
    # Gemma 4-style: <tool_name> ... </tool_name>
    for n in _KNOWN_TOOL_NAMES:
        if f"<{n.lower()}>" in low and f"</{n.lower()}>" in low:
            return True
    return False


def parse_embedded_tool_calls(content: str | None) -> list[dict]:
    """Extract tool calls from text content.

    Returns a list of dicts shaped like OpenAI's tool_calls:
        {"id": "...", "name": "...", "arguments": "<json-string>"}

    Returns empty list if nothing was found.
    """
    if not content:
        return []

    results: list[dict] = []
    for block_match in _TOOL_CALL_BLOCK_RE.finditer(content):
        block = block_match.group(1).strip()
        parsed = _parse_single_block(block)
        if parsed:
            results.append(parsed)

    if not results and "<function=" in content:
        # Some templates omit the outer <tool_call> wrapper.
        for func_match in _FUNCTION_BLOCK_RE.finditer(content):
            parsed = _parse_function_form(func_match.group(1), func_match.group(2))
            if parsed:
                results.append(parsed)

    # Gemma 4-style: <tool_name> body </tool_name> with YAML-ish key:value
    # body. Only matches tags whose name we registered as a real tool.
    if not results and _KNOWN_TOOL_NAMES:
        for name in _KNOWN_TOOL_NAMES:
            pattern = re.compile(
                rf"<{re.escape(name)}>(.*?)</{re.escape(name)}>",
                re.DOTALL | re.IGNORECASE,
            )
            for m in pattern.finditer(content):
                parsed = _parse_yaml_args(name, m.group(1))
                if parsed:
                    results.append(parsed)

    return results


def _parse_yaml_args(name: str, body: str) -> dict | None:
    """Parse a Gemma 4-style tool body of the shape:
        file_path: "js/Game/Object/Entity.js"
        limit: 100
    Returns a structured tool_call dict or None.
    """
    args: dict = {}
    for raw in body.splitlines():
        line = raw.strip()
        if not line or line.startswith("#") or ":" not in line:
            continue
        key, _, value = line.partition(":")
        key = key.strip()
        value = value.strip().rstrip(",")
        # Strip matching outer quotes.
        if len(value) >= 2 and value[0] == value[-1] and value[0] in ("'", '"'):
            value = value[1:-1]
        else:
            # Try to coerce numeric / boolean primitives.
            if value.lower() in ("true", "false"):
                value = value.lower() == "true"
            else:
                try:
                    if "." in value:
                        value = float(value)
                    else:
                        value = int(value)
                except ValueError:
                    pass
        if key:
            args[key] = value
    if not args:
        return None
    return _build_call(name, json.dumps(args, ensure_ascii=False))


def strip_tool_call_blocks(content: str | None) -> str:
    """Remove <tool_call>...</tool_call> blocks from content.

    Useful to keep the assistant's prose but drop the embedded call markup
    (which we've already extracted into structured tool_calls).
    """
    if not content:
        return ""
    stripped = _TOOL_CALL_BLOCK_RE.sub("", content)
    if "<function=" in stripped:
        stripped = _FUNCTION_BLOCK_RE.sub("", stripped)
    # Strip Gemma 4-style <tool_name>…</tool_name> blocks too.
    for name in _KNOWN_TOOL_NAMES:
        pattern = re.compile(
            rf"<{re.escape(name)}>.*?</{re.escape(name)}>",
            re.DOTALL | re.IGNORECASE,
        )
        stripped = pattern.sub("", stripped)
    return stripped.strip()


def _parse_single_block(block: str) -> dict | None:
    """Parse the inside of one <tool_call>...</tool_call>."""
    block = block.strip()
    if not block:
        return None

    # Form A: JSON body
    if block.startswith("{"):
        try:
            data = json.loads(block)
        except json.JSONDecodeError:
            pass
        else:
            name = data.get("name")
            args = data.get("arguments", {})
            if isinstance(name, str) and name:
                return _build_call(
                    name, args if isinstance(args, str) else json.dumps(args)
                )

    # Form B: <function=name>...<parameter=k>v</parameter>...</function>
    func_match = _FUNCTION_BLOCK_RE.search(block)
    if func_match:
        return _parse_function_form(func_match.group(1), func_match.group(2))

    return None


def _parse_function_form(name: str, body: str) -> dict | None:
    name = name.strip()
    if not name:
        return None
    args: dict[str, str] = {}
    for param_match in _PARAMETER_BLOCK_RE.finditer(body):
        key = param_match.group(1).strip()
        value = param_match.group(2).strip()
        if key:
            args[key] = value
    return _build_call(name, json.dumps(args))


def _build_call(name: str, arguments_json: str) -> dict:
    return {
        "id": f"call_{secrets.token_urlsafe(16)}",
        "name": name,
        "arguments": arguments_json,
    }
