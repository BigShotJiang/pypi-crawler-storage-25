"""LLM Client factory - routes to OpenAI SDK or Codex backend based on provider."""

import sys
import time
from typing import Generator

from vicode.config import Config


# HTTP status codes that indicate a transient server-side issue worth retrying.
#   503: llama-server returns this while loading/switching a model
#   502: reverse-proxy gateway flapping (Cloudflare, nginx)
#   504: upstream read timeout
#   408: client-request timeout (should resend)
#   429: rate limited — also appropriate for exponential-style backoff
_RETRYABLE_STATUS = {408, 429, 502, 503, 504}
_RETRY_MAX_ATTEMPTS = 10
_RETRY_DELAY_SEC = 10


class LLMClient:
    """Unified LLM client. Delegates to OpenAI SDK or Codex client."""

    def __init__(self, config: Config):
        self.config = config
        if config.provider == "openai-login":
            from vicode.llm.codex_client import CodexClient
            self._impl = CodexClient(config)
        elif config.provider == "claude-code":
            from vicode.llm.claude_client import ClaudeClient
            self._impl = ClaudeClient(config)
        elif config.provider == "anthropic-raw":
            from vicode.llm.claude_raw_client import ClaudeRawClient
            self._impl = ClaudeRawClient(config)
        else:
            self._impl = _OpenAISDKClient(config)

    def detect_model(self) -> str | None:
        return self._impl.detect_model()

    def detect_model_info(self) -> dict | None:
        """Return model info: {id, context_size, is_llama_server} or None."""
        fn = getattr(self._impl, "detect_model_info", None)
        return fn() if callable(fn) else None

    def detect_and_apply(self, config: Config) -> str | None:
        """Detect model + context size and update config in-place.

        Returns the detected model id, or None if detection failed.
        Auto-applies `context_size` to config.context_limit when the server
        advertises it (llama-server). Leaves context_limit untouched for
        providers that don't report it.
        """
        info = self.detect_model_info()
        if not info:
            return self.detect_model()
        config.model = info["id"]
        ctx = info.get("context_size")
        if isinstance(ctx, int) and ctx > 0:
            # Reserve ~2k tokens as output/thinking headroom; compactor
            # triggers at 85% of context_limit so this is the "usable" size.
            config.context_limit = ctx
        return info["id"]

    def stream(self, messages: list[dict], tools: list[dict] | None = None) -> Generator:
        return self._impl.stream(messages, tools)

    def on_degenerate_loop(self) -> float | None:
        """Tell the underlying client a degenerate loop was just detected.

        Returns the new repeat_penalty applied (or None if not supported).
        """
        fn = getattr(self._impl, "on_degenerate_loop", None)
        return fn() if callable(fn) else None

    def on_clean_completion(self) -> None:
        """Tell the underlying client a stream finished cleanly.
        Lets the adaptive penalty decay back toward its floor."""
        fn = getattr(self._impl, "on_clean_completion", None)
        if callable(fn):
            fn()

    def health_check(self) -> bool:
        return self._impl.health_check()


class _OpenAISDKClient:
    """Standard OpenAI SDK client for local servers, API key providers, etc."""

    def __init__(self, config: Config):
        from openai import OpenAI
        import httpx
        self.config = config
        # Adaptive repeat-penalty: starts at config value, ramps up after
        # degenerate loops, decays back when streams complete cleanly.
        # Keeps well-behaved models at the configured value while giving
        # broken models (Gemma 4 Q3 etc.) extra anti-repetition pressure.
        self._adaptive_repeat_penalty = float(getattr(config, "repeat_penalty", 1.1))
        self._repeat_penalty_floor = self._adaptive_repeat_penalty
        self._repeat_penalty_ceiling = 1.5
        # Explicit per-phase timeouts so streaming requests can't hang forever
        # if the server stops sending tokens mid-response without closing the
        # connection (seen with llama-server under concurrent load). The `read`
        # timeout is the inter-chunk gap — if no bytes arrive within this
        # window the SDK raises ReadTimeout, which our retry wrapper catches.
        timeout = httpx.Timeout(
            connect=15.0,
            read=getattr(config, "stream_read_timeout", 90.0),
            write=30.0,
            pool=15.0,
        )
        kwargs = dict(
            base_url=config.server_url,
            api_key=config.api_key or "not-needed",
            timeout=timeout,
        )
        if config.skip_ssl_verify:
            kwargs["http_client"] = httpx.Client(verify=False, timeout=timeout)
        self.client = OpenAI(**kwargs)

    def detect_model(self) -> str | None:
        info = self.detect_model_info()
        return info["id"] if info else None

    def detect_model_info(self) -> dict | None:
        """Probe /v1/models for model id + (llama.cpp) context size.

        llama-server exposes `meta.n_ctx_train` in the models list. Other
        OpenAI-compatible servers don't, in which case `context_size` is None
        and callers should fall back to the existing config.context_limit.
        """
        try:
            response = self.client.models.list()
        except Exception:
            return None

        data = getattr(response, "data", None) or []
        if not data:
            return None

        first = data[0]
        model_id = getattr(first, "id", None)
        if not model_id:
            return None

        context_size = None
        is_llama_server = False
        # openai SDK discards unknown fields, but exposes them via
        # `model_extra` on pydantic objects.
        extra = getattr(first, "model_extra", None) or {}
        meta = extra.get("meta") if isinstance(extra, dict) else None
        if isinstance(meta, dict):
            n_ctx = meta.get("n_ctx_train") or meta.get("n_ctx")
            if isinstance(n_ctx, int) and n_ctx > 0:
                context_size = n_ctx
        # llama.cpp also sets owned_by="llamacpp"
        owned_by = extra.get("owned_by") if isinstance(extra, dict) else None
        if owned_by == "llamacpp" or meta is not None:
            is_llama_server = True

        return {
            "id": model_id,
            "context_size": context_size,
            "is_llama_server": is_llama_server,
        }

    def stream(self, messages: list[dict], tools: list[dict] | None = None):
        kwargs = dict(
            model=self.config.model,
            messages=messages,
            stream=True,
            temperature=self.config.temperature,
            max_tokens=self.config.max_tokens,
            top_p=getattr(self.config, "top_p", 1.0),
            presence_penalty=getattr(self.config, "presence_penalty", 0.0),
        )
        extra_body: dict = {}
        top_k = getattr(self.config, "top_k", None)
        if top_k:
            extra_body["top_k"] = top_k
        # llama.cpp accepts repeat_penalty via extra_body; OpenAI ignores it.
        extra_body["repeat_penalty"] = self._adaptive_repeat_penalty

        # chat_template_kwargs differ between model families. Pick what each
        # one understands so we don't ship a Qwen-only kwarg to Gemma (which
        # has its own thinking/tool-call control via different tokens).
        model_id = (self.config.model or "").lower()
        if "gemma" in model_id or "ornstein-26b" in model_id:
            # Gemma 4 uses `<|think|>` / `<|channel>thought<channel|>`.
            # Tool calling in llama.cpp Gemma 4 is fragile; the safest combo
            # for agent loops is to disable the reasoning channel so tool
            # calls don't leak into the thought stream and get dropped.
            # Source: llama.cpp PRs #21326 / #21343 + asf0/gemma4_jinja notes.
            extra_body["chat_template_kwargs"] = {"enable_thinking": False}
        else:
            # Qwen 3.6 (and most other thinking models with compatible
            # templates) drop prior-turn <think> blocks by default, which
            # causes the "empty args tool call" loop after 2-3 turns.
            # preserve_thinking keeps reasoning context across turns —
            # unknown to non-llama.cpp providers, they simply ignore
            # unrecognized chat_template_kwargs.
            extra_body["chat_template_kwargs"] = {"preserve_thinking": True}

        if extra_body:
            kwargs["extra_body"] = extra_body
        if tools:
            kwargs["tools"] = tools
            kwargs["tool_choice"] = "auto"

        # Retry transient errors (llama-server 503 while loading a model,
        # gateway flaps, brief concurrency saturation). Only the initial
        # connect/headers phase is retried — once the stream starts yielding
        # chunks we let caller-side logic handle mid-stream failures.
        return _open_stream_with_retry(self.client, kwargs)

    def health_check(self) -> bool:
        try:
            self.client.models.list()
            return True
        except Exception:
            return False

    # ---- Adaptive repeat-penalty hooks (called from the agent loop) ----

    def on_degenerate_loop(self) -> float:
        """Bump the repeat_penalty by 0.1 (capped). Returns the new value."""
        old = self._adaptive_repeat_penalty
        self._adaptive_repeat_penalty = min(
            old + 0.1, self._repeat_penalty_ceiling
        )
        import sys
        print(
            f"[adaptive] repeat_penalty {old:.2f} → "
            f"{self._adaptive_repeat_penalty:.2f} after degenerate loop",
            file=sys.stderr, flush=True,
        )
        return self._adaptive_repeat_penalty

    def on_clean_completion(self) -> None:
        """Decay the repeat_penalty toward the configured floor (0.02 step)."""
        if self._adaptive_repeat_penalty > self._repeat_penalty_floor:
            self._adaptive_repeat_penalty = max(
                self._adaptive_repeat_penalty - 0.02,
                self._repeat_penalty_floor,
            )


def _is_retryable_error(err: Exception) -> bool:
    """Return True if this error is likely transient and worth retrying."""
    # openai SDK wraps HTTP errors; check status_code when available.
    status = getattr(err, "status_code", None)
    if status is None:
        response = getattr(err, "response", None)
        status = getattr(response, "status_code", None) if response else None
    if status in _RETRYABLE_STATUS:
        return True
    # Connection-level failures (server down mid-request, DNS, reset).
    try:
        from openai import APIConnectionError, APITimeoutError
    except ImportError:
        APIConnectionError = APITimeoutError = ()  # type: ignore
    if isinstance(err, (APIConnectionError, APITimeoutError)):
        return True
    return False


def _open_stream_with_retry(client, kwargs):
    """Call chat.completions.create with retry on transient failures.

    Waits _RETRY_DELAY_SEC between attempts, up to _RETRY_MAX_ATTEMPTS.
    Non-retryable errors (4xx other than 408/429) surface immediately.
    """
    last_err: Exception | None = None
    for attempt in range(1, _RETRY_MAX_ATTEMPTS + 1):
        try:
            return client.chat.completions.create(**kwargs)
        except Exception as err:
            if not _is_retryable_error(err):
                raise
            last_err = err
            if attempt >= _RETRY_MAX_ATTEMPTS:
                break
            status = getattr(err, "status_code", None) or "connection"
            print(
                f"[retry] LLM request failed ({status}); "
                f"attempt {attempt}/{_RETRY_MAX_ATTEMPTS}, "
                f"retrying in {_RETRY_DELAY_SEC}s...",
                file=sys.stderr,
                flush=True,
            )
            time.sleep(_RETRY_DELAY_SEC)
    assert last_err is not None
    raise last_err
