"""File history tracker and undo tool."""

import shutil
import tempfile
from dataclasses import dataclass, field
from pathlib import Path
from vicode.tools.base import Tool, ToolResult


@dataclass
class FileSnapshot:
    path: str
    backup: str  # path to temp backup file
    existed: bool


class FileHistory:
    """Tracks file changes and supports undo."""

    def __init__(self):
        self._history: list[FileSnapshot] = []
        self._tmp_dir = Path(tempfile.mkdtemp(prefix="vicode_undo_"))

    def save_snapshot(self, file_path: str):
        """Save current state of a file before modifying it."""
        path = Path(file_path)
        backup_name = f"{len(self._history)}_{path.name}"
        backup_path = self._tmp_dir / backup_name

        if path.exists():
            shutil.copy2(path, backup_path)
            self._history.append(FileSnapshot(
                path=str(path),
                backup=str(backup_path),
                existed=True,
            ))
        else:
            self._history.append(FileSnapshot(
                path=str(path),
                backup="",
                existed=False,
            ))

    def undo_last(self) -> tuple[str, bool]:
        """Undo the last file change. Returns (file_path, success)."""
        if not self._history:
            return "", False

        snap = self._history.pop()
        path = Path(snap.path)

        if not snap.existed:
            # File didn't exist before - delete it
            if path.exists():
                path.unlink()
            return snap.path, True
        else:
            # Restore from backup
            backup = Path(snap.backup)
            if backup.exists():
                shutil.copy2(backup, path)
                backup.unlink()
                return snap.path, True
            return snap.path, False

    def get_history(self) -> list[str]:
        """Return list of modified file paths (most recent last)."""
        return [s.path for s in self._history]

    def cleanup(self):
        """Remove all temp files."""
        shutil.rmtree(self._tmp_dir, ignore_errors=True)


# Singleton instance shared by file tools
_history = FileHistory()


def get_file_history() -> FileHistory:
    return _history


class UndoTool(Tool):
    @property
    def name(self) -> str:
        return "undo"

    @property
    def description(self) -> str:
        return "Undo the last file change (write or edit). Can be called multiple times to undo further back."

    @property
    def parameters(self) -> dict:
        return {"type": "object", "properties": {}}

    def run(self, **kwargs) -> ToolResult:
        history = get_file_history()
        if not history.get_history():
            return ToolResult(content="Nothing to undo.", is_error=True)

        path, ok = history.undo_last()
        if ok:
            remaining = len(history.get_history())
            return ToolResult(content=f"Undone: {path} ({remaining} changes remaining)")
        else:
            return ToolResult(content=f"Failed to undo: {path}", is_error=True)
