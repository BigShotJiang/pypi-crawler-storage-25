"""File search tool using glob patterns."""

import os
from pathlib import Path
from vicode.tools.base import Tool, ToolResult
from vicode.config import Config


MAX_RESULTS = 200
SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".mypy_cache", "dist", "build"}


class GlobTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "glob"

    @property
    def description(self) -> str:
        return "Find files matching a glob pattern. Returns file paths sorted by modification time."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Glob pattern (e.g. '**/*.py', 'src/**/*.ts', '*.json')",
                },
                "path": {
                    "type": "string",
                    "description": "Directory to search in (default: working directory)",
                },
            },
            "required": ["pattern"],
        }

    def run(self, pattern: str, path: str | None = None) -> ToolResult:
        search_path = Path(path) if path else Path(self.config.cwd)
        if not search_path.is_absolute():
            search_path = Path(self.config.cwd) / search_path

        if not search_path.exists():
            return ToolResult(content=f"Path not found: {search_path}", is_error=True)

        try:
            matches = []
            for p in search_path.glob(pattern):
                if any(skip in p.parts for skip in SKIP_DIRS):
                    continue
                if p.is_file():
                    matches.append(p)
        except Exception as e:
            return ToolResult(content=f"Glob error: {e}", is_error=True)

        # Sort by modification time (newest first)
        matches.sort(key=lambda p: p.stat().st_mtime, reverse=True)

        if not matches:
            return ToolResult(content=f"No files matching: {pattern}")

        truncated = len(matches) > MAX_RESULTS
        matches = matches[:MAX_RESULTS]

        lines = []
        for p in matches:
            try:
                rel = p.relative_to(self.config.cwd)
            except ValueError:
                rel = p
            lines.append(str(rel))

        header = f"Found {len(lines)} files"
        if truncated:
            header += f" (showing first {MAX_RESULTS})"

        return ToolResult(content=header + "\n" + "\n".join(lines))
