"""Create the default tool registry with all available tools."""

from vicode.config import Config
from vicode.tools.base import ToolRegistry
from vicode.tools.bash import BashTool, KillTool
from vicode.tools.file_read import FileReadTool
from vicode.tools.file_write import FileWriteTool
from vicode.tools.file_edit import FileEditTool
from vicode.tools.file_history import UndoTool
from vicode.tools.grep import GrepTool
from vicode.tools.glob_search import GlobTool
from vicode.tools.ls import LsTool
from vicode.tools.web_search import WebSearchTool
from vicode.tools.web_fetch import WebFetchTool
from vicode.tools.memory import MemoryTool
from vicode.tools.subagents import ExploreTool, PlanTool, DocumentTool
from vicode.tools.orchestrator import OrchestratorTool
from vicode.tools.docs_index import DocsIndexTool
from vicode.tools.docs_query import DocsQueryTool
from vicode.tools.docs_sync import DocsSyncTool
from vicode.tools.ask_user import AskUserTool
from vicode.tools.load_skill import LoadSkillTool


def create_default_registry(config: Config) -> ToolRegistry:
    registry = ToolRegistry()
    registry.register(BashTool(config))
    registry.register(KillTool())
    registry.register(FileReadTool(config))
    registry.register(FileWriteTool(config))
    registry.register(FileEditTool(config))
    registry.register(UndoTool())
    registry.register(GrepTool(config))
    registry.register(GlobTool(config))
    registry.register(LsTool(config))
    registry.register(WebSearchTool())
    registry.register(WebFetchTool())
    registry.register(MemoryTool(cwd=config.cwd))
    registry.register(ExploreTool(config))
    registry.register(PlanTool(config))
    registry.register(DocumentTool(config))
    registry.register(OrchestratorTool(config))
    registry.register(DocsIndexTool(cwd=config.cwd))
    registry.register(DocsQueryTool(cwd=config.cwd))
    registry.register(DocsSyncTool(cwd=config.cwd))
    registry.register(AskUserTool())
    registry.register(LoadSkillTool(config))
    return registry
