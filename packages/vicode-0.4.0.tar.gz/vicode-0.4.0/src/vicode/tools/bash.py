"""Bash/shell command execution tool with interactive command blocklist and background support."""

import shlex
import subprocess
from vicode.tools.base import Tool, ToolResult
from vicode.config import Config


MAX_OUTPUT = 30000

BLOCKED_COMMANDS = {
    "vim", "vi", "nvim", "nano", "emacs", "pico", "ed",
    "python", "python3", "ipython", "node", "irb", "lua",
    "gdb", "lldb", "pdb",
    "ssh", "telnet", "ftp",
    "less", "more", "man",
    "top", "htop", "watch",
    "nohup",
}

# Global registry of background processes
_bg_processes: dict[int, dict] = {}  # pid -> {command, process}


def is_blocked(command: str) -> str | None:
    stripped = command.strip()
    for part in stripped.split("|"):
        part = part.strip().split("&&")[0].strip().split(";")[0].strip()
        if not part:
            continue
        try:
            first_word = shlex.split(part)[0]
        except ValueError:
            first_word = part.split()[0] if part.split() else ""
        binary = first_word.rsplit("/", 1)[-1].rsplit("\\", 1)[-1]
        if binary in BLOCKED_COMMANDS:
            tokens = part.split()
            if binary in ("python", "python3", "node", "ipython") and len(tokens) > 1:
                if tokens[1].startswith("-") or tokens[1].endswith(".py") or tokens[1].endswith(".js"):
                    continue
            return binary
    return None


class BashTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "bash"

    @property
    def description(self) -> str:
        return (
            "Execute a shell command. Use background=true for long-running processes "
            "(servers, watchers). Do not use interactive commands (vim, python REPL)."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "command": {
                    "type": "string",
                    "description": "The shell command to execute",
                },
                "cwd": {
                    "type": "string",
                    "description": "Working directory to run in (default: project root)",
                },
                "timeout": {
                    "type": "integer",
                    "description": "Timeout in seconds (default 120, max 600)",
                },
                "background": {
                    "type": "boolean",
                    "description": "Run in background. Returns PID immediately. Use for servers, watchers, etc.",
                },
            },
            "required": ["command"],
        }

    def run(self, command: str, cwd: str | None = None, timeout: int = 120, background: bool = False) -> ToolResult:
        blocked = is_blocked(command)
        if blocked and not background:
            return ToolResult(
                content=f"Blocked: '{blocked}' is interactive. Use background=true for servers/long processes.",
                is_error=True,
            )

        run_cwd = cwd or self.config.cwd
        if background:
            return self._run_background(command, run_cwd)

        timeout = min(timeout, 600)
        env = {**__import__("os").environ, "TERM": "dumb", "NO_COLOR": "1"}
        try:
            result = subprocess.run(
                command,
                shell=True,
                capture_output=True,
                text=True,
                # Force UTF-8 decoding with replacement for invalid bytes.
                # On Windows the default is the ANSI codepage (cp1252 in ES-ES,
                # etc.) which crashes with UnicodeDecodeError whenever a tool
                # emits UTF-8 or other non-ANSI bytes (e.g. Playwright output,
                # emoji, grep matches with non-ASCII, npm logs). 'replace'
                # substitutes invalid bytes with U+FFFD so output is always
                # usable even if imperfect.
                encoding="utf-8",
                errors="replace",
                timeout=timeout,
                cwd=run_cwd,
                stdin=subprocess.DEVNULL,
                env=env,
            )
            output = ""
            if result.stdout:
                output += result.stdout
            if result.stderr:
                if output:
                    output += "\n"
                output += result.stderr

            if not output:
                output = "(no output)"

            if len(output) > MAX_OUTPUT:
                half = MAX_OUTPUT // 2
                output = output[:half] + f"\n\n... ({len(output) - MAX_OUTPUT} chars truncated) ...\n\n" + output[-half:]

            if result.returncode != 0:
                output = f"Exit code: {result.returncode}\n{output}"

            return ToolResult(content=output, is_error=result.returncode != 0)

        except subprocess.TimeoutExpired:
            return ToolResult(content=f"Command timed out after {timeout}s", is_error=True)
        except Exception as e:
            return ToolResult(content=f"Failed to execute: {e}", is_error=True)

    def _run_background(self, command: str, run_cwd: str = "") -> ToolResult:
        try:
            proc = subprocess.Popen(
                command,
                shell=True,
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                stdin=subprocess.DEVNULL,
                cwd=run_cwd or self.config.cwd,
            )
            pid = proc.pid
            _bg_processes[pid] = {"command": command[:80], "process": proc}
            return ToolResult(content=f"Started in background. PID: {pid}\nCommand: {command[:80]}")
        except Exception as e:
            return ToolResult(content=f"Failed to start background process: {e}", is_error=True)


class KillTool(Tool):
    """Kill or list background processes."""

    @property
    def name(self) -> str:
        return "kill"

    @property
    def description(self) -> str:
        return "Kill a background process by PID, or list all running background processes if no PID given."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "pid": {
                    "type": "integer",
                    "description": "Process ID to kill. Omit to list all background processes.",
                },
            },
        }

    def run(self, pid: int | None = None) -> ToolResult:
        if pid is None:
            return self._list_processes()
        return self._kill_process(pid)

    def _list_processes(self) -> ToolResult:
        if not _bg_processes:
            return ToolResult(content="No background processes running.")

        # Check which are still alive
        lines = ["Background processes:"]
        dead = []
        for p, info in _bg_processes.items():
            proc = info["process"]
            if proc.poll() is None:
                lines.append(f"  PID {p} (running): {info['command']}")
            else:
                lines.append(f"  PID {p} (exited: {proc.returncode}): {info['command']}")
                dead.append(p)

        # Clean up dead processes
        for p in dead:
            del _bg_processes[p]

        return ToolResult(content="\n".join(lines))

    def _kill_process(self, pid: int) -> ToolResult:
        if pid not in _bg_processes:
            return ToolResult(content=f"PID {pid} not found in background processes.", is_error=True)

        info = _bg_processes[pid]
        proc = info["process"]
        try:
            proc.terminate()
            try:
                proc.wait(timeout=5)
            except subprocess.TimeoutExpired:
                proc.kill()
            del _bg_processes[pid]
            return ToolResult(content=f"Killed PID {pid}: {info['command']}")
        except Exception as e:
            return ToolResult(content=f"Failed to kill PID {pid}: {e}", is_error=True)
