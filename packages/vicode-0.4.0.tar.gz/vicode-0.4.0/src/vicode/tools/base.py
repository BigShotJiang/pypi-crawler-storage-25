"""Tool interface and registry."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field


@dataclass
class ToolResult:
    content: str
    is_error: bool = False


class Tool(ABC):
    @property
    @abstractmethod
    def name(self) -> str: ...

    @property
    @abstractmethod
    def description(self) -> str: ...

    @property
    @abstractmethod
    def parameters(self) -> dict:
        """JSON Schema for the tool parameters."""
        ...

    @abstractmethod
    def run(self, **kwargs) -> ToolResult: ...

    def to_openai_tool(self) -> dict:
        return {
            "type": "function",
            "function": {
                "name": self.name,
                "description": self.description,
                "parameters": self.parameters,
            },
        }


@dataclass
class ToolRegistry:
    _tools: dict[str, Tool] = field(default_factory=dict)
    # Optional: set by the parent AgentLoop so sub-agent tools (explore, plan,
    # orchestrate, document) can record their inner loop into the same DB
    # session under a `subagent` tag — makes hangs/loops debuggable.
    _trace_recorder: object | None = None

    def register(self, tool: Tool):
        self._tools[tool.name] = tool

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def set_trace_recorder(self, recorder):
        """Attach a TraceRecorder so sub-agent tools can spawn child recorders."""
        self._trace_recorder = recorder

    def execute(self, name: str, arguments: dict) -> ToolResult:
        tool = self._tools.get(name)
        if not tool:
            return ToolResult(content=f"Unknown tool: {name}", is_error=True)
        # Inject the parent recorder so sub-agent tools (explore/plan/etc.)
        # can spawn child recorders and persist their inner loop in the same
        # session. Cleared after run to avoid leaks across calls.
        if self._trace_recorder is not None:
            try:
                tool._parent_recorder = self._trace_recorder
            except Exception:
                pass
        try:
            return tool.run(**arguments)
        except Exception as e:
            return ToolResult(content=f"Tool error: {type(e).__name__}: {e}", is_error=True)
        finally:
            try:
                tool._parent_recorder = None
            except Exception:
                pass

    def to_openai_tools(self) -> list[dict]:
        return [t.to_openai_tool() for t in self._tools.values()]

    @property
    def tool_names(self) -> list[str]:
        return list(self._tools.keys())
