"""Web page fetching tool - fetches URL and extracts text content."""

import re
from html.parser import HTMLParser
from vicode.tools.base import Tool, ToolResult


MAX_CONTENT = 15000  # chars to return


def html_to_text(html: str) -> str:
    """Convert HTML to plain text using regex. Simple and robust."""
    # Remove script/style blocks
    text = re.sub(r"<script[^>]*>.*?</script>", "", html, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<style[^>]*>.*?</style>", "", text, flags=re.DOTALL | re.IGNORECASE)
    text = re.sub(r"<noscript[^>]*>.*?</noscript>", "", text, flags=re.DOTALL | re.IGNORECASE)
    # Block elements -> newlines
    text = re.sub(r"<(?:br|p|div|h[1-6]|li|tr|blockquote|hr)[^>]*>", "\n", text, flags=re.IGNORECASE)
    # Strip all remaining tags
    text = re.sub(r"<[^>]+>", "", text)
    # Decode common entities
    text = text.replace("&amp;", "&").replace("&lt;", "<").replace("&gt;", ">")
    text = text.replace("&nbsp;", " ").replace("&quot;", '"').replace("&#39;", "'")
    # Collapse whitespace
    text = re.sub(r"[ \t]+", " ", text)
    text = re.sub(r"\n[ \t]+", "\n", text)
    text = re.sub(r"\n{3,}", "\n\n", text)
    return text.strip()


class WebFetchTool(Tool):
    @property
    def name(self) -> str:
        return "web_fetch"

    @property
    def description(self) -> str:
        return "Fetch a web page URL and extract its text content. Use after web_search to read a specific page."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "url": {
                    "type": "string",
                    "description": "URL to fetch",
                },
            },
            "required": ["url"],
        }

    def run(self, url: str) -> ToolResult:
        try:
            import httpx
            resp = httpx.get(
                url,
                follow_redirects=True,
                timeout=15,
                verify=False,
                headers={"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"},
            )
            resp.raise_for_status()
        except Exception as e:
            return ToolResult(content=f"Fetch failed: {e}", is_error=True)

        content_type = resp.headers.get("content-type", "")

        if "text/html" in content_type:
            text = html_to_text(resp.text)
        elif "text/" in content_type or "json" in content_type or "xml" in content_type:
            text = resp.text
        else:
            return ToolResult(content=f"Binary content ({content_type}), cannot extract text.")

        if len(text) > MAX_CONTENT:
            text = text[:MAX_CONTENT] + f"\n\n... (truncated, {len(resp.text)} total chars)"

        return ToolResult(content=f"URL: {url}\n\n{text}")
