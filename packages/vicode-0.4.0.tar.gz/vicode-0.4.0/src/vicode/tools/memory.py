"""Persistent memory tool using engram-core with namespace isolation."""

import os
from pathlib import Path
from vicode.tools.base import Tool, ToolResult


VALID_TYPES = {"fact", "preference", "decision", "error_fix", "pattern", "workflow", "summary", "custom"}


def _get_namespace(cwd: str = "") -> str:
    """Derive namespace from project directory for memory isolation."""
    path = cwd or os.getcwd()
    return Path(path).name.lower().replace(" ", "_")


class MemoryTool(Tool):
    def __init__(self, cwd: str = ""):
        self._mem = None
        self._namespace = _get_namespace(cwd)

    def _get_mem(self):
        if self._mem is None:
            from engram import Memory
            self._mem = Memory()
        return self._mem

    @property
    def name(self) -> str:
        return "memory"

    @property
    def description(self) -> str:
        return (
            "Persistent memory across sessions. Use to store and recall facts, preferences, "
            "decisions, error fixes, patterns, and workflows. "
            "Actions: store, search, recall, delete, list."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "One of: store, search, recall, delete, list",
                },
                "content": {
                    "type": "string",
                    "description": "For store: text to remember. For search: query. For delete: memory ID.",
                },
                "type": {
                    "type": "string",
                    "description": f"Memory type for store: {', '.join(sorted(VALID_TYPES))}",
                },
                "importance": {
                    "type": "integer",
                    "description": "Importance 1-10 for store (default 5)",
                },
            },
            "required": ["action"],
        }

    def run(self, action: str, content: str = "", type: str = "fact", importance: int = 5, **kwargs) -> ToolResult:
        mem = self._get_mem()
        ns = self._namespace

        if action == "store":
            if not content:
                return ToolResult(content="'content' required", is_error=True)
            if type not in VALID_TYPES:
                type = "custom"
            importance = max(1, min(10, importance))
            try:
                mem.store(content, type=type, importance=importance, namespace=ns)
                return ToolResult(content=f"Stored ({type}, importance={importance}): {content}")
            except Exception as e:
                return ToolResult(content=f"Failed: {e}", is_error=True)

        elif action == "search":
            if not content:
                return ToolResult(content="'content' required for search", is_error=True)
            try:
                results = mem.search(content, namespace=ns)
                if not results:
                    # Fallback: search global namespace
                    results = mem.search(content)
                if not results:
                    return ToolResult(content=f"No memories matching: {content}")
                lines = []
                for r in results[:10]:
                    m = r.memory
                    lines.append(f"- [id={m.id}] [{m.memory_type.value}] (importance={m.importance}) {m.content}")
                return ToolResult(content=f"Found {len(results)} memories:\n" + "\n".join(lines))
            except Exception as e:
                return ToolResult(content=f"Search failed: {e}", is_error=True)

        elif action == "recall":
            try:
                results = mem.recall(limit=10, namespace=ns)
                if not results:
                    results = mem.recall(limit=10)
                if not results:
                    return ToolResult(content="No memories stored yet.")
                lines = []
                for m in results:
                    lines.append(f"- [id={m.id}] [{m.memory_type.value}] (importance={m.importance}) {m.content}")
                return ToolResult(content=f"{len(results)} memories:\n" + "\n".join(lines))
            except Exception as e:
                return ToolResult(content=f"Recall failed: {e}", is_error=True)

        elif action == "delete":
            if not content:
                return ToolResult(content="'content' required (memory ID)", is_error=True)
            try:
                mem.delete(int(content))
                return ToolResult(content=f"Deleted memory {content}")
            except Exception as e:
                return ToolResult(content=f"Delete failed: {e}", is_error=True)

        elif action == "list":
            try:
                results = mem.list(namespace=ns, limit=20)
                if not results:
                    return ToolResult(content="No memories in this project.")
                lines = []
                for m in results:
                    lines.append(f"- [id={m.id}] [{m.memory_type.value}] {m.content[:80]}")
                return ToolResult(content=f"{len(results)} memories:\n" + "\n".join(lines))
            except Exception as e:
                return ToolResult(content=f"List failed: {e}", is_error=True)

        return ToolResult(content=f"Unknown action: {action}. Use store, search, recall, delete, list.", is_error=True)
