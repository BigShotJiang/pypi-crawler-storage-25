"""ask_user tool — pause the agent and request structured input from the user.

Inspired by Claude Code's AskUserQuestion. The agent assembles a small
"questionnaire" (one or more questions, each with multiple-choice options
and an optional free-text fallback). The TUI displays it as a guided form,
the user navigates with Enter (next) and Right-arrow (previous). A queued
threading.Event handshake blocks the agent worker until the user submits.

In non-TUI runs (e.g. `vicode -p`) the tool refuses to run rather than
hanging the prompt forever.
"""

from __future__ import annotations

import threading
from dataclasses import dataclass, field
from typing import Optional

from vicode.tools.base import Tool, ToolResult


# --- Shared inbox between the agent worker thread and the TUI thread -------

@dataclass
class AskRequest:
    """A pending questionnaire awaiting user input."""

    questions: list[dict]
    event: threading.Event = field(default_factory=threading.Event)
    answers: list[dict] | None = None
    cancelled: bool = False


# Module-level inbox: when the tool runs it stores the current request here
# and the TUI polls / picks it up. Only one request can be active at a time
# (the agent worker is blocked on the same event), so a single slot is
# enough.
_pending_lock = threading.Lock()
_pending: Optional[AskRequest] = None


def take_pending_request() -> Optional[AskRequest]:
    """TUI calls this to acquire the current pending request, if any.

    Returns the request and clears the slot so the same form isn't shown
    twice. The caller is responsible for completing it (set answers + event).
    """
    global _pending
    with _pending_lock:
        req, _pending = _pending, None
        return req


def has_pending_request() -> bool:
    with _pending_lock:
        return _pending is not None


def _publish(req: AskRequest) -> bool:
    """Place a request in the inbox. Returns False if another is already there."""
    global _pending
    with _pending_lock:
        if _pending is not None:
            return False
        _pending = req
        return True


# --- The tool itself --------------------------------------------------------

class AskUserTool(Tool):
    """Show a structured questionnaire to the user (TUI only)."""

    # Set by VicodeApp on startup so the tool knows it can prompt.
    tui_available: bool = False
    # Optional callback so the TUI can react immediately when a request lands
    # (otherwise the TUI relies on its event polling). Signature: callback().
    on_request: Optional[callable] = None

    @property
    def name(self) -> str:
        return "ask_user"

    @property
    def description(self) -> str:
        return (
            "Pause and ask the user a structured questionnaire. "
            "Use this when YOU need a decision from the user — when proposing "
            "options, when the request is ambiguous, or before a destructive "
            "or irreversible action. Each question can list multiple choice "
            "options (single- or multi-select) and the user always has a "
            "free-text fallback. The tool blocks until the user answers, then "
            "returns the answers as JSON. Prefer this over guessing."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "questions": {
                    "type": "array",
                    "minItems": 1,
                    "items": {
                        "type": "object",
                        "properties": {
                            "text": {
                                "type": "string",
                                "description": "Question shown to the user",
                            },
                            "multi_select": {
                                "type": "boolean",
                                "default": False,
                                "description": "Allow selecting multiple options",
                            },
                            "allow_free_text": {
                                "type": "boolean",
                                "default": True,
                                "description": "Whether the user can type a free-form answer",
                            },
                            "options": {
                                "type": "array",
                                "items": {
                                    "type": "object",
                                    "properties": {
                                        "label": {
                                            "type": "string",
                                            "description": "Short label shown in the list",
                                        },
                                        "value": {
                                            "type": "string",
                                            "description": "Optional machine value (defaults to label)",
                                        },
                                        "description": {
                                            "type": "string",
                                            "description": "Longer explanation shown when this option is highlighted",
                                        },
                                        "image": {
                                            "type": "string",
                                            "description": "Optional markdown (or an image path) shown when highlighted",
                                        },
                                    },
                                    "required": ["label"],
                                },
                            },
                        },
                        "required": ["text", "options"],
                    },
                },
            },
            "required": ["questions"],
        }

    def run(self, questions: list[dict]) -> ToolResult:
        if not questions:
            return ToolResult(
                content="ask_user requires at least one question.", is_error=True
            )

        if not type(self).tui_available:
            return ToolResult(
                content=(
                    "ask_user is only available in TUI mode. "
                    "Make a reasonable assumption and proceed instead."
                ),
                is_error=True,
            )

        req = AskRequest(questions=questions)
        if not _publish(req):
            return ToolResult(
                content="Another ask_user request is already pending.",
                is_error=True,
            )

        # Notify TUI immediately if a callback is wired up (saves polling lag).
        cb = type(self).on_request
        if callable(cb):
            try:
                cb()
            except Exception:
                pass

        # Block the agent worker until the user submits or cancels.
        # 1 hour cap so a forgotten form can't hang the agent forever.
        if not req.event.wait(timeout=3600):
            # Timeout — clear the slot so the next attempt can succeed.
            take_pending_request()
            return ToolResult(
                content="ask_user timed out (no response in 1h). Continuing.",
                is_error=True,
            )

        if req.cancelled:
            return ToolResult(
                content="User cancelled the questionnaire. Make a reasonable "
                "assumption and proceed.",
                is_error=False,
            )

        import json
        return ToolResult(
            content=json.dumps({"answers": req.answers or []}, ensure_ascii=False),
        )
