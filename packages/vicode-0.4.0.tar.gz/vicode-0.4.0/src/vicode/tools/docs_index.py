"""Docs indexing tool - creates searchable documentation from project."""

import json
import os
import re
from dataclasses import dataclass, field
from pathlib import Path

from vicode.tools.base import Tool, ToolResult


IGNORE_DIRS = {
    ".git",
    ".venv",
    "node_modules",
    "__pycache__",
    ".pytest_cache",
    "dist",
    "build",
    ".eggs",
    "*.egg-info",
}

IGNORE_EXTS = {
    ".pyc",
    ".pyo",
    ".so",
    ".exe",
    ".dll",
    ".bin",
    ".lock",
}


@dataclass
class DocChunk:
    """A chunk of documentation from a source file."""

    file: str
    line_start: int
    line_end: int
    content: str
    symbols: list[str] = field(default_factory=list)
    summary: str = ""


SYMBOL_PATTERNS = [
    r"^class (\w+)",
    r"^def (\w+)\s*\(",
    r"^async def (\w+)\s*\(",
    r"^(\w+)\s*=\s*(class|def|async def)",
    r"^(\w+)\s*:\s*.*#.*\b(constant|config|var)\b",
]


def extract_symbols(content: str) -> list[str]:
    """Extract class/function/constant names from content."""
    symbols = []
    lines = content.split("\n")
    for i, line in enumerate(lines[:10]):
        for pattern in SYMBOL_PATTERNS:
            match = re.match(pattern, line.strip())
            if match:
                symbols.append(match.group(1))
    return symbols


def find_code_files(cwd: str, extensions: set) -> list[Path]:
    """Find all code files in project."""
    files = []
    cwd_path = Path(cwd)

    for root, dirs, filenames in os.walk(cwd_path):
        root_path = Path(root)

        dirs[:] = [d for d in dirs if d not in IGNORE_DIRS and not d.startswith(".")]

        for filename in filenames:
            if filename.startswith("."):
                continue
            ext = Path(filename).suffix
            if ext in IGNORE_EXTS:
                continue
            if ext in extensions or not ext:
                filepath = root_path / filename
                files.append(filepath)

    return files


def chunk_file(filepath: Path, max_lines: int = 50) -> list[DocChunk]:
    """Split a file into chunks by symbols and line limits."""
    try:
        content = filepath.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    lines = content.split("\n")
    if len(lines) < 3:
        return []

    chunks = []
    current_chunk_lines = []
    current_symbols = []
    start_line = 1

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        is_symbol_line = False
        for pattern in SYMBOL_PATTERNS:
            if re.match(pattern, stripped):
                is_symbol_line = True
                break

        if is_symbol_line and current_chunk_lines:
            symbols = extract_symbols("\n".join(current_chunk_lines))
            current_symbols = list(set(symbols)) if symbols else current_symbols

        current_chunk_lines.append(line)

        if len(current_chunk_lines) >= max_lines or i == len(lines):
            if current_chunk_lines:
                chunk_content = "\n".join(current_chunk_lines).strip()
                symbols = extract_symbols(chunk_content)

                chunks.append(
                    DocChunk(
                        file=str(filepath),
                        line_start=start_line,
                        line_end=i,
                        content=chunk_content,
                        symbols=list(set(symbols)),
                    )
                )

            current_chunk_lines = []
            start_line = i + 1

    return chunks


def chunk_by_symbols(filepath: Path) -> list[DocChunk]:
    """Split a file by symbol boundaries."""
    try:
        content = filepath.read_text(encoding="utf-8", errors="ignore")
    except Exception:
        return []

    lines = content.split("\n")
    if len(lines) < 3:
        return []

    chunks = []
    chunk_lines = []
    chunk_start = 1
    current_symbols = []

    for i, line in enumerate(lines, 1):
        stripped = line.strip()

        for pattern in SYMBOL_PATTERNS:
            match = re.match(pattern, stripped)
            if match:
                if chunk_lines:
                    symbols = extract_symbols("\n".join(chunk_lines[:5]))
                    chunk_content = "\n".join(chunk_lines).strip()

                    chunks.append(
                        DocChunk(
                            file=str(filepath),
                            line_start=chunk_start,
                            line_end=i - 1,
                            content=chunk_content,
                            symbols=list(set(symbols)),
                        )
                    )

                    chunk_lines = []
                    chunk_start = i
                break

        chunk_lines.append(line)

    if chunk_lines:
        symbols = extract_symbols("\n".join(chunk_lines[:5]))
        chunks.append(
            DocChunk(
                file=str(filepath),
                line_start=chunk_start,
                line_end=len(lines),
                content="\n".join(chunk_lines).strip(),
                symbols=list(set(symbols)),
            )
        )

    return chunks


class DocsIndexTool(Tool):
    """Index project source files into searchable documentation."""

    def __init__(self, cwd: str = ""):
        self._cwd = cwd
        self._docs_dir = None

    @property
    def name(self) -> str:
        return "docs_index"

    @property
    def description(self) -> str:
        return (
            "Index project source files into .vicode/docs/ for semantic search. "
            "Creates chunks, summaries, and embeddings. "
            "Use docs_query to search indexed content."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "One of: index, status, rebuild",
                },
                "pattern": {
                    "type": "string",
                    "description": "File pattern to index (default: **/*.py)",
                },
                "force": {
                    "type": "boolean",
                    "description": "Force rebuild even if index exists",
                },
            },
            "required": ["action"],
        }

    def _get_docs_dir(self) -> Path:
        if self._docs_dir is None:
            self._docs_dir = Path(self._cwd) / ".vicode" / "docs"
        return self._docs_dir

    def _get_chunks_dir(self) -> Path:
        return self._get_docs_dir() / "chunks"

    def _merge_chunks(
        self, filepath: Path, symbol_chunks: list[DocChunk], line_chunks: list[DocChunk]
    ) -> list[DocChunk]:
        """Merge symbol-based and line-based chunks."""
        if not symbol_chunks:
            return line_chunks

        if not line_chunks:
            return symbol_chunks

        merged = []
        for schunk in symbol_chunks:
            for lchunk in line_chunks:
                if schunk.line_start == lchunk.line_start:
                    merged.append(
                        DocChunk(
                            file=schunk.file,
                            line_start=schunk.line_start,
                            line_end=max(schunk.line_end, lchunk.line_end),
                            content=schunk.content,
                            symbols=list(set(schunk.symbols + lchunk.symbols)),
                        )
                    )
                    break
            else:
                merged.append(schunk)

        return merged if merged else line_chunks

    def run(
        self, action: str, pattern: str = "**/*.py", force: bool = False, **kwargs
    ) -> ToolResult:
        docs_dir = self._get_docs_dir()
        chunks_dir = self._get_chunks_dir()

        if action == "status":
            if not docs_dir.exists():
                return ToolResult(
                    content="No documentation index found. Run docs_index(action='index')."
                )

            index_file = docs_dir / "index.json"
            if not index_file.exists():
                return ToolResult(
                    content="Index is empty. Run docs_index(action='index')."
                )

            try:
                index_data = json.loads(index_file.read_text(encoding="utf-8"))
                return ToolResult(
                    content=f"Index status:\n"
                    f"- Version: {index_data.get('version', 'unknown')}\n"
                    f"- Files: {index_data.get('file_count', 0)}\n"
                    f"- Chunks: {index_data.get('chunk_count', 0)}\n"
                    f"- Created: {index_data.get('created_at', 'unknown')}"
                )
            except Exception as e:
                return ToolResult(content=f"Index read error: {e}", is_error=True)

        if action == "index" or action == "rebuild":
            if not force and docs_dir.exists() and (chunks_dir / "index.json").exists():
                return ToolResult(
                    content="Index already exists. Use force=true to rebuild.",
                    is_error=True,
                )

            docs_dir.mkdir(parents=True, exist_ok=True)
            chunks_dir.mkdir(parents=True, exist_ok=True)

            extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".md", ".txt"}
            code_files = find_code_files(self._cwd, extensions)

            all_chunks = []
            indexed_files = set()

            for filepath in code_files:
                if filepath.suffix not in extensions:
                    continue

                rel_path = str(filepath.relative_to(self._cwd))

                symbol_chunks = chunk_by_symbols(filepath)
                line_chunks = chunk_file(filepath, max_lines=50)

                merged_chunks = self._merge_chunks(filepath, symbol_chunks, line_chunks)

                for i, chunk in enumerate(merged_chunks):
                    chunk_path = chunks_dir / f"{rel_path}_{i}.vdoc"
                    chunk_path.parent.mkdir(parents=True, exist_ok=True)

                    doc_data = {
                        "file": chunk.file,
                        "line_start": chunk.line_start,
                        "line_end": chunk.line_end,
                        "content": chunk.content[:2000],
                        "symbols": chunk.symbols,
                    }

                    chunk_path.write_text(
                        json.dumps(doc_data, ensure_ascii=False), encoding="utf-8"
                    )

                    all_chunks.append(doc_data)
                    indexed_files.add(rel_path)

            index_data = {
                "version": "1.0",
                "created_at": str(Path(docs_dir).stat().st_mtime),
                "file_count": len(indexed_files),
                "chunk_count": len(all_chunks),
                "files": sorted(indexed_files),
            }

            index_file = docs_dir / "index.json"
            index_file.write_text(json.dumps(index_data, indent=2), encoding="utf-8")

            return ToolResult(
                content=f"Indexed {len(indexed_files)} files, {len(all_chunks)} chunks"
            )

        return ToolResult(
            content=f"Unknown action: {action}. Use index, status, or rebuild.",
            is_error=True,
        )
