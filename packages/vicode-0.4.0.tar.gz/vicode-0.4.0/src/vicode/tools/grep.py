"""Content search tool using regex."""

import os
import re
from fnmatch import fnmatch
from pathlib import Path
from vicode.tools.base import Tool, ToolResult
from vicode.config import Config


MAX_RESULTS = 100
MAX_LINE_LEN = 500

# Directories to always skip
SKIP_DIRS = {".git", ".venv", "venv", "node_modules", "__pycache__", ".mypy_cache", ".tox", "dist", "build", ".egg-info"}


class GrepTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "grep"

    @property
    def description(self) -> str:
        return "Search file contents using regex. Returns matching lines grouped by file."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "pattern": {
                    "type": "string",
                    "description": "Regex pattern to search for",
                },
                "path": {
                    "type": "string",
                    "description": "Directory or file to search in (default: working directory)",
                },
                "include": {
                    "type": "string",
                    "description": "Glob pattern to filter files (e.g. '*.py', '*.ts')",
                },
            },
            "required": ["pattern"],
        }

    def run(self, pattern: str, path: str | None = None, include: str | None = None) -> ToolResult:
        search_path = Path(path) if path else Path(self.config.cwd)
        if not search_path.is_absolute():
            search_path = Path(self.config.cwd) / search_path

        if not search_path.exists():
            return ToolResult(content=f"Path not found: {search_path}", is_error=True)

        try:
            regex = re.compile(pattern)
        except re.error as e:
            return ToolResult(content=f"Invalid regex: {e}", is_error=True)

        results: dict[str, list[str]] = {}
        total = 0

        if search_path.is_file():
            files = [search_path]
        else:
            files = self._walk_files(search_path, include)

        for fpath in files:
            if total >= MAX_RESULTS:
                break
            try:
                rel = str(fpath.relative_to(self.config.cwd)) if str(fpath).startswith(self.config.cwd) else str(fpath)
                with open(fpath, encoding="utf-8", errors="replace") as f:
                    for i, line in enumerate(f, 1):
                        if total >= MAX_RESULTS:
                            break
                        line = line.rstrip("\n\r")
                        if regex.search(line):
                            if rel not in results:
                                results[rel] = []
                            display_line = line if len(line) <= MAX_LINE_LEN else line[:MAX_LINE_LEN] + "..."
                            results[rel].append(f"  {i}: {display_line}")
                            total += 1
            except (OSError, PermissionError):
                continue

        if not results:
            return ToolResult(content=f"No matches for pattern: {pattern}")

        output_parts = []
        for fname, lines in results.items():
            output_parts.append(f"{fname}")
            output_parts.extend(lines)

        header = f"Found {total} matches in {len(results)} files"
        if total >= MAX_RESULTS:
            header += f" (limited to {MAX_RESULTS})"

        return ToolResult(content=header + "\n\n" + "\n".join(output_parts))

    def _walk_files(self, root: Path, include: str | None) -> list[Path]:
        files = []
        for dirpath, dirnames, filenames in os.walk(root):
            dirnames[:] = [d for d in dirnames if d not in SKIP_DIRS]
            for fname in filenames:
                if include and not fnmatch(fname, include):
                    continue
                fpath = Path(dirpath) / fname
                # Skip binary-looking files
                if fpath.suffix in {".pyc", ".pyo", ".so", ".dll", ".exe", ".bin", ".gz", ".zip", ".tar", ".jpg", ".png", ".gif", ".ico", ".woff", ".ttf", ".gguf"}:
                    continue
                files.append(fpath)
        return files
