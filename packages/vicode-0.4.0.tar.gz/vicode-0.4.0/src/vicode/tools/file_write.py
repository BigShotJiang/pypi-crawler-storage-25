"""File writing tool."""

from pathlib import Path
from vicode.tools.base import Tool, ToolResult
from vicode.tools.file_history import get_file_history
from vicode.config import Config


class FileWriteTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "file_write"

    @property
    def description(self) -> str:
        return "Create or overwrite a file with the given content. Creates parent directories if needed."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file (absolute or relative to working directory)",
                },
                "content": {
                    "type": "string",
                    "description": "The content to write to the file",
                },
            },
            "required": ["file_path", "content"],
        }

    def run(self, file_path: str, content: str) -> ToolResult:
        path = Path(file_path)
        if not path.is_absolute():
            path = Path(self.config.cwd) / path

        try:
            path.parent.mkdir(parents=True, exist_ok=True)
            get_file_history().save_snapshot(str(path))
            existed = path.exists()
            path.write_text(content, encoding="utf-8")
            lines = content.count("\n") + (1 if content and not content.endswith("\n") else 0)
            action = "Updated" if existed else "Created"
            return ToolResult(content=f"{action} {path} ({lines} lines, {len(content)} bytes)")
        except Exception as e:
            return ToolResult(content=f"Error writing file: {e}", is_error=True)
