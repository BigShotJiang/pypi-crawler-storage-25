"""Web search tool using DuckDuckGo."""

from vicode.tools.base import Tool, ToolResult


MAX_RESULTS = 8


class WebSearchTool(Tool):
    def __init__(self):
        self._ddgs = None

    def _get_ddgs(self):
        if self._ddgs is None:
            from ddgs import DDGS
            self._ddgs = DDGS()
        return self._ddgs

    @property
    def name(self) -> str:
        return "web_search"

    @property
    def description(self) -> str:
        return "Search the web using DuckDuckGo. Returns titles, URLs and snippets."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query",
                },
                "max_results": {
                    "type": "integer",
                    "description": f"Number of results (default {MAX_RESULTS})",
                },
            },
            "required": ["query"],
        }

    def run(self, query: str, max_results: int = MAX_RESULTS) -> ToolResult:
        max_results = min(max_results, 20)
        try:
            results = self._get_ddgs().text(query, max_results=max_results)
        except Exception as e:
            return ToolResult(content=f"Search failed: {e}", is_error=True)

        if not results:
            return ToolResult(content=f"No results for: {query}")

        lines = []
        for i, r in enumerate(results, 1):
            title = r.get("title", "")
            url = r.get("href", "")
            snippet = r.get("body", "")
            lines.append(f"{i}. {title}")
            lines.append(f"   {url}")
            if snippet:
                lines.append(f"   {snippet}")
            lines.append("")

        return ToolResult(content=f"Results for: {query}\n\n" + "\n".join(lines))
