"""load_skill — fetch the full body of a Claude Code-compatible skill.

The system prompt advertises available skills with name + description only.
When the model decides a skill matches the user's request, it calls this
tool to receive the skill's full markdown body (the actual instructions).
"""

from __future__ import annotations

from vicode.config import Config
from vicode.skills import discover_skills
from vicode.tools.base import Tool, ToolResult


class LoadSkillTool(Tool):
    """Load the full instructions of a discovered skill by name."""

    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "load_skill"

    @property
    def description(self) -> str:
        return (
            "Load a skill's full instructions by name. The available_skills "
            "list in the system prompt only shows name + description; call "
            "this tool to fetch the actual body when a skill is relevant. "
            "After loading, follow the skill's instructions for the rest of "
            "the task. The skill body may reference helper scripts in its "
            "folder (path is returned for reference)."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "name": {
                    "type": "string",
                    "description": "Exact skill name as listed in <available_skills>",
                },
            },
            "required": ["name"],
        }

    def run(self, name: str) -> ToolResult:
        if not name or not isinstance(name, str):
            return ToolResult(
                content="load_skill requires a non-empty `name`.", is_error=True
            )
        target = name.strip()
        skills = discover_skills(self.config.cwd)
        match = next((s for s in skills if s.name == target), None)
        if match is None:
            available = ", ".join(s.name for s in skills) or "(none)"
            return ToolResult(
                content=(
                    f"Skill '{target}' not found. Available: {available}. "
                    f"Use one of those exact names."
                ),
                is_error=True,
            )
        body = (match.body or "").strip()
        if not body:
            return ToolResult(
                content=(
                    f"Skill '{match.name}' has no body — only metadata. "
                    f"Description: {match.description or '(none)'}."
                ),
                is_error=False,
            )
        header = (
            f"# Skill: {match.name} [{match.scope}]\n"
            f"# Path: {match.path}\n"
            f"# Description: {match.description or '(none)'}\n"
        )
        if match.allowed_tools:
            header += f"# Allowed tools (per skill): {', '.join(match.allowed_tools)}\n"
        return ToolResult(content=header + "\n" + body)
