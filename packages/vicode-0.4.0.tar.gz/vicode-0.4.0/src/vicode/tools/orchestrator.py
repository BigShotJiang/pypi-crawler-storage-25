"""Parallel agent orchestrator - runs multiple sub-agents on plan tasks concurrently."""

import json
import datetime
from queue import Queue, Empty
from threading import Thread
from typing import Any

from vicode.config import Config
from vicode.agent.loop import AgentLoop
from vicode.tools.base import Tool, ToolResult, ToolRegistry
from vicode.tools.bash import BashTool
from vicode.tools.file_read import FileReadTool
from vicode.tools.file_write import FileWriteTool
from vicode.tools.file_edit import FileEditTool
from vicode.tools.grep import GrepTool
from vicode.tools.glob_search import GlobTool
from vicode.tools.ls import LsTool
from vicode.tools.web_search import WebSearchTool
from vicode.tools.web_fetch import WebFetchTool


# Global event queue - polled by UI timer
orchestrator_events: Queue = Queue()
orchestrator_active = False


def _make_agent_tools(config: Config) -> ToolRegistry:
    """Full tool set for each parallel agent (read + write)."""
    registry = ToolRegistry()
    registry.register(BashTool(config))
    registry.register(FileReadTool(config))
    registry.register(FileWriteTool(config))
    registry.register(FileEditTool(config))
    registry.register(GrepTool(config))
    registry.register(GlobTool(config))
    registry.register(LsTool(config))
    registry.register(WebSearchTool())
    registry.register(WebFetchTool())
    return registry


def _agent_worker(agent_id: int, task_desc: str, config: Config, event_queue: Queue, parent_recorder=None):
    """Runs a single sub-agent in its own thread with isolated supervisor.

    `parent_recorder` is the main session's TraceRecorder; we derive a child
    recorder per worker so each orchestrate sub-agent's loop is persisted in
    the same DB session under a unique `subagent` tag (e.g. "orchestrate#3").
    """
    tools = _make_agent_tools(config)
    sub_recorder = None
    if parent_recorder is not None and hasattr(parent_recorder, "child"):
        sub_recorder = parent_recorder.child(f"orchestrate#{agent_id}")
    sub_config = Config(
        provider=config.provider,
        server_url=config.server_url,
        model=config.model,
        api_key=config.api_key,
        max_tokens=config.max_tokens,
        context_limit=config.context_limit,
        max_iterations=15,
        temperature=config.temperature,
        timeout=config.timeout,
        cwd=config.cwd,
    )

    # Each sub-agent gets its own isolated supervisor
    from vicode.supervisor.base import SupervisorChain
    from vicode.supervisor.safety import SafetyGuardian
    from vicode.supervisor.memory_guardian import MemoryGuardian
    supervisor = SupervisorChain([
        SafetyGuardian(sub_config),
        MemoryGuardian(cwd=config.cwd),
    ])
    prompt = f"""You are a focused coding agent working on one specific task. Complete it fully.

## Rules
- Implement the task completely. Write all necessary code.
- Verify your work when possible.
- Be efficient - don't explore unnecessarily.

## Environment
- Working directory: {config.cwd}
- Date: {datetime.date.today().isoformat()}"""

    final_content: list[str] = []
    worker_error: str | None = None

    # Wrap EVERYTHING in try/except — including AgentLoop construction and the
    # initial LLM call. Previously a crash before the first yield (e.g. model
    # detection failure, httpx setup error, llama-server slot saturation on
    # the very first request) left the worker silent: the thread died with no
    # agent_error and no agent_done, the orchestrator counted "done" via thread
    # join, but the task itself was lost without trace. Now the parent
    # recorder also captures the failure, so it's debuggable post-mortem.
    try:
        agent = AgentLoop(
            config=sub_config,
            tools=tools,
            system_prompt=prompt,
            supervisor=supervisor,
            trace_recorder=sub_recorder,
        )
        event_queue.put({"agent_id": agent_id, "type": "agent_tool", "tool": "Thinking..."})
        for event in agent.run(task_desc):
            etype = event.get("type", "")
            if etype == "tool_executing":
                name = event.get("name", "")
                args = event.get("args", {})
                from vicode.tui.chat import _tool_hint
                hint = _tool_hint(name, args)
                display = name.replace("_", " ").title().replace(" ", "_")
                label = f"{display}({hint})" if hint else display
                event_queue.put({"agent_id": agent_id, "type": "agent_tool", "tool": label})
            elif etype == "tool_result":
                s = "OK" if not event.get("is_error") else "ERR"
                event_queue.put({"agent_id": agent_id, "type": "agent_tool", "tool": f"[{s}]"})
            elif etype == "content_delta":
                final_content.append(event.get("text", ""))
            elif etype == "error":
                event_queue.put({"agent_id": agent_id, "type": "agent_tool", "tool": f"Error: {event.get('message', '')[:50]}"})
    except Exception as e:
        worker_error = f"{type(e).__name__}: {e}"
        event_queue.put({
            "agent_id": agent_id,
            "type": "agent_error",
            "error": worker_error[:100],
        })
        # Also persist to the parent session so it shows in trace analysis
        if sub_recorder is not None:
            try:
                sub_recorder.on_error(worker_error, phase="worker_crash")
            except Exception:
                pass

    if worker_error and not final_content:
        result = f"[Worker crashed before producing output: {worker_error}]"
    else:
        result = "".join(final_content).strip() or "(no text output)"
    event_queue.put({
        "agent_id": agent_id,
        "type": "agent_done",
        "result": result,
    })


class OrchestratorTool(Tool):
    """Runs multiple sub-agents in parallel on plan tasks."""

    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "orchestrate"

    @property
    def description(self) -> str:
        return (
            "Run multiple sub-agents in parallel to implement a plan. "
            "Each agent works on a separate task independently. "
            "Use when a plan has 3+ tasks that can be done in parallel."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "tasks": {
                    "type": "array",
                    "description": "List of task objects with description and files",
                    "items": {
                        "type": "object",
                        "properties": {
                            "description": {"type": "string"},
                            "files": {
                                "type": "array",
                                "items": {"type": "string"},
                                "description": "Files this task will create/modify",
                            },
                        },
                        "required": ["description"],
                    },
                },
            },
            "required": ["tasks"],
        }

    def run(self, tasks: list) -> ToolResult:
        global orchestrator_active

        if not tasks or len(tasks) < 2:
            return ToolResult(content="Need at least 2 tasks to orchestrate.", is_error=True)

        # Inherit the parent session's trace recorder (set by ToolRegistry.execute)
        # so each orchestrated worker writes its own loop into the same DB.
        parent_recorder = getattr(self, "_parent_recorder", None)

        # Signal UI that orchestration is active
        orchestrator_active = True
        event_queue = orchestrator_events

        # Initialize agent state for UI
        for i, task in enumerate(tasks):
            desc = task.get("description", f"Task {i+1}")[:60]
            event_queue.put({
                "agent_id": i,
                "type": "agent_start",
                "name": desc,
            })

        # Launch threads - stagger start for Codex provider to avoid Cloudflare
        is_codex = self.config.provider == "openai-login"
        threads = []
        for i, task in enumerate(tasks):
            desc = task.get("description", f"Task {i+1}")
            files = task.get("files", [])
            full_desc = desc
            if files:
                full_desc += f"\n\nFiles to create/modify: {', '.join(files)}"

            t = Thread(
                target=_agent_worker,
                args=(i, full_desc, self.config, event_queue, parent_recorder),
                daemon=True,
            )
            threads.append(t)
            t.start()
            # Stagger thread starts for Codex to avoid rate limiting
            if is_codex and i < len(tasks) - 1:
                import time
                time.sleep(3)

        # Wait for all to finish.
        # Each worker emits at most one `agent_error` (on crash) followed by
        # exactly one `agent_done` — so we ONLY count agent_done as a "done"
        # signal, otherwise a crashed worker would count twice and the
        # orchestrator would return before the other workers finished.
        done_count = 0
        results = {}
        errors: dict[int, str] = {}
        # Hard timeout: if no event arrives in this window, assume the workers
        # are stuck and bail out so the main loop isn't blocked forever.
        STALL_TIMEOUT_S = 300
        import time as _time
        last_event_t = _time.time()
        while done_count < len(threads):
            try:
                event = event_queue.get(timeout=1)
                last_event_t = _time.time()
            except Empty:
                if _time.time() - last_event_t > STALL_TIMEOUT_S:
                    # Mark remaining workers as stalled
                    for i in range(len(threads)):
                        if i not in results:
                            results[i] = (
                                f"ERROR: Worker stalled — no event received in "
                                f"{STALL_TIMEOUT_S}s. Thread alive="
                                f"{threads[i].is_alive()}"
                            )
                            done_count += 1
                    break
                continue
            if event.get("type") == "agent_done":
                done_count += 1
                aid = event["agent_id"]
                if aid in errors:
                    results[aid] = f"ERROR: {errors[aid]}"
                else:
                    results[aid] = event.get("result", "")
            elif event.get("type") == "agent_error":
                # Don't increment done_count — agent_done will follow.
                errors[event["agent_id"]] = event.get("error", "")

        orchestrator_active = False
        event_queue.put({"type": "orchestrator_done"})

        # Combine results
        lines = [f"Completed {len(results)} parallel tasks:\n"]
        for i in range(len(tasks)):
            desc = tasks[i].get("description", f"Task {i+1}")[:60]
            result = results.get(i, "(no result)")
            lines.append(f"## Agent {i+1}: {desc}")
            lines.append(result[:500])
            lines.append("")

        return ToolResult(content="\n".join(lines))
