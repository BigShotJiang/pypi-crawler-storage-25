"""Directory listing tool."""

import os
from datetime import datetime
from pathlib import Path
from vicode.tools.base import Tool, ToolResult
from vicode.config import Config


class LsTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "ls"

    @property
    def description(self) -> str:
        return "List directory contents with file sizes and modification dates."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "path": {
                    "type": "string",
                    "description": "Directory to list (default: working directory)",
                },
            },
        }

    def run(self, path: str | None = None) -> ToolResult:
        target = Path(path) if path else Path(self.config.cwd)
        if not target.is_absolute():
            target = Path(self.config.cwd) / target

        if not target.exists():
            return ToolResult(content=f"Path not found: {target}", is_error=True)
        if not target.is_dir():
            return ToolResult(content=f"Not a directory: {target}", is_error=True)

        try:
            entries = sorted(target.iterdir(), key=lambda p: (not p.is_dir(), p.name.lower()))
        except PermissionError:
            return ToolResult(content=f"Permission denied: {target}", is_error=True)

        lines = []
        for entry in entries:
            try:
                stat = entry.stat()
                mtime = datetime.fromtimestamp(stat.st_mtime).strftime("%Y-%m-%d %H:%M")
                if entry.is_dir():
                    lines.append(f"  {mtime}  {'<DIR>':>10}  {entry.name}/")
                else:
                    size = _format_size(stat.st_size)
                    lines.append(f"  {mtime}  {size:>10}  {entry.name}")
            except (OSError, PermissionError):
                lines.append(f"  {'?':>16}  {'?':>10}  {entry.name}")

        header = f"Directory: {target} ({len(entries)} entries)"
        return ToolResult(content=header + "\n" + "\n".join(lines))


def _format_size(size: int) -> str:
    for unit in ("B", "KB", "MB", "GB"):
        if size < 1024:
            return f"{size:.0f}{unit}" if unit == "B" else f"{size:.1f}{unit}"
        size /= 1024
    return f"{size:.1f}TB"
