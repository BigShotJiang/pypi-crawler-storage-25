"""File reading tool."""

import os
from pathlib import Path
from vicode.tools.base import Tool, ToolResult
from vicode.config import Config


MAX_FILE_SIZE = 256 * 1024  # 256KB
DEFAULT_LIMIT = 2000


class FileReadTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "file_read"

    @property
    def description(self) -> str:
        return "Read a file's contents with optional line range. Returns content with line numbers."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file (absolute or relative to working directory)",
                },
                "offset": {
                    "type": "integer",
                    "description": "Starting line number (0-based, default 0)",
                },
                "limit": {
                    "type": "integer",
                    "description": f"Number of lines to read (default {DEFAULT_LIMIT})",
                },
            },
            "required": ["file_path"],
        }

    def run(self, file_path: str, offset: int = 0, limit: int = DEFAULT_LIMIT) -> ToolResult:
        path = Path(file_path)
        if not path.is_absolute():
            path = Path(self.config.cwd) / path

        if not path.exists():
            return ToolResult(content=f"File not found: {path}", is_error=True)
        if not path.is_file():
            return ToolResult(content=f"Not a file: {path}", is_error=True)
        if path.stat().st_size > MAX_FILE_SIZE:
            return ToolResult(
                content=f"File too large ({path.stat().st_size} bytes, max {MAX_FILE_SIZE}). Use offset/limit.",
                is_error=True,
            )

        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as e:
            return ToolResult(content=f"Error reading file: {e}", is_error=True)

        lines = text.splitlines()
        total = len(lines)
        selected = lines[offset : offset + limit]

        numbered = []
        for i, line in enumerate(selected, start=offset + 1):
            numbered.append(f"{i:>6}\t{line}")

        header = f"File: {path} ({total} lines)"
        if offset > 0 or len(selected) < total:
            header += f" [showing lines {offset + 1}-{offset + len(selected)}]"

        return ToolResult(content=header + "\n" + "\n".join(numbered))
