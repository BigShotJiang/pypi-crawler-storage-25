"""Sub-agent tools - explore and plan with isolated context.

Sub-agents have their own conversation history so they don't pollute the
main agent's context window. Only the final summary is returned.
"""

import datetime
from vicode.config import Config
from vicode.agent.loop import AgentLoop
from vicode.tools.base import Tool, ToolResult, ToolRegistry
from vicode.tools.file_read import FileReadTool
from vicode.tools.file_write import FileWriteTool
from vicode.tools.grep import GrepTool
from vicode.tools.glob_search import GlobTool
from vicode.tools.ls import LsTool
from vicode.tools.bash import BashTool
from vicode.tools.web_search import WebSearchTool
from vicode.tools.web_fetch import WebFetchTool
from vicode.tools.docs_query import DocsQueryTool
from vicode.tools.docs_index import DocsIndexTool
from vicode.tools.docs_sync import DocsSyncTool
from vicode.tools.memory import MemoryTool


def _make_readonly_tools(config: Config) -> ToolRegistry:
    """Tools for sub-agents: strictly read-only. No bash, no file writes.

    Search order for efficiency:
    1. docs_query - semantic search in indexed docs (lowest tokens)
    2. grep - keyword search in source
    3. file_read - read specific files
    4. memory - recall from past sessions
    """
    tools = ToolRegistry()
    tools.register(DocsQueryTool(cwd=config.cwd))
    tools.register(GrepTool(config))
    tools.register(FileReadTool(config))
    tools.register(GlobTool(config))
    tools.register(LsTool(config))
    tools.register(MemoryTool(cwd=config.cwd))
    tools.register(WebSearchTool())
    tools.register(WebFetchTool())
    return tools


def _make_doc_agent_tools(config: Config) -> ToolRegistry:
    """Tools for documentation agent: read + write + indexing.

    Allows research, documentation, and reindexing in one pass.
    """
    tools = ToolRegistry()
    tools.register(FileReadTool(config))
    tools.register(FileWriteTool(config))
    tools.register(GrepTool(config))
    tools.register(GlobTool(config))
    tools.register(LsTool(config))
    tools.register(DocsIndexTool(cwd=config.cwd))
    tools.register(DocsSyncTool(cwd=config.cwd))
    tools.register(MemoryTool(cwd=config.cwd))
    return tools


# Global token counter for sub-agents (read by status bar)
subagent_tokens = 0


def _run_subagent(
    config: Config,
    tools: ToolRegistry,
    system_prompt: str,
    task: str,
    trace_recorder=None,
) -> str:
    """Run a sub-agent to completion and return its final text response.

    If `trace_recorder` is provided, the sub-agent's inner loop is persisted
    to the same session under that (child) recorder, so hangs/loops inside a
    sub-agent are visible in the same DB stream as the main loop.
    """
    global subagent_tokens
    sub_config = Config(
        provider=config.provider,
        server_url=config.server_url,
        model=config.model,
        api_key=config.api_key,
        max_tokens=config.max_tokens,
        context_limit=config.context_limit,
        max_iterations=15,
        temperature=config.temperature,
        timeout=config.timeout,
        cwd=config.cwd,
    )
    agent = AgentLoop(
        config=sub_config,
        tools=tools,
        system_prompt=system_prompt,
        trace_recorder=trace_recorder,
    )

    final_content = []
    tool_log = []

    for event in agent.run(task):
        # Update global token count so status bar can read it
        subagent_tokens = agent.history.estimate_tokens()
        match event:
            case {"type": "content_delta", "text": text}:
                final_content.append(text)
            case {"type": "tool_result", "name": name, "is_error": err}:
                status = "ERR" if err else "OK"
                tool_log.append(f"  {status}: {name}")
            case {"type": "error", "message": msg}:
                tool_log.append(f"  ERROR: {msg}")

    response = "".join(final_content).strip()
    if not response and tool_log:
        response = "Sub-agent completed but produced no text.\nActions:\n" + "\n".join(
            tool_log
        )

    subagent_tokens = 0  # reset when done
    return response


class ExploreTool(Tool):
    """Sub-agent that explores the codebase and/or web, returns a summary."""

    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "explore"

    @property
    def description(self) -> str:
        return (
            "Launch a sub-agent to explore and research a question. "
            "It can search files, read code, grep, and search the web. "
            "Returns a summary without polluting the main conversation context. "
            "Use for: understanding code, finding implementations, researching solutions."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "question": {
                    "type": "string",
                    "description": "What to explore or research",
                },
            },
            "required": ["question"],
        }

    def run(self, question: str) -> ToolResult:
        tools = _make_readonly_tools(self.config)
        sub_recorder = None
        parent = getattr(self, "_parent_recorder", None)
        if parent is not None and hasattr(parent, "child"):
            sub_recorder = parent.child("explore")

        # Minimal prompt following Qwen 3.5 best practices:
        # - No ReAct, no tool format instructions
        # - Short, behavioral rules only
        # - Let native tool calling handle the rest
        prompt = f"""You are a research assistant. Explore and gather information, then summarize your findings.

## Search Order (for efficiency)
## Search Order (for efficiency - always follow this order)
1. docs_query → 2. grep → 3. file_read → 4. memory
This order saves tokens and context.

First use docs_query to search indexed documentation (lowest tokens).
If not found, use grep to search source code.
Then use file_read to read specific files.
Finally, use memory to recall past sessions and patterns.

## Rules
- ALWAYS follow the search order above: docs_query → grep → file_read → memory
- Use docs_query first for any code-related questions
- Use memory recall when user asks about past work, preferences, or patterns
- Be thorough but focused
- End with a concise summary. Include file paths and line numbers when relevant

## Environment
- Working directory: {self.config.cwd}
- Date: {datetime.date.today().isoformat()}"""

        try:
            return ToolResult(
                content=_run_subagent(
                    self.config, tools, prompt, question,
                    trace_recorder=sub_recorder,
                )
            )
        except Exception as e:
            return ToolResult(content=f"Explore failed: {e}", is_error=True)


class PlanTool(Tool):
    """Sub-agent that creates an implementation plan."""

    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "plan"

    @property
    def description(self) -> str:
        return (
            "Launch a sub-agent to analyze a task and create an implementation plan. "
            "It explores the codebase to understand context, then returns a step-by-step plan. "
            "Use before starting complex tasks to avoid mistakes."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "task": {
                    "type": "string",
                    "description": "The task to plan for",
                },
            },
            "required": ["task"],
        }

    def run(self, task: str) -> ToolResult:
        tools = _make_readonly_tools(self.config)
        sub_recorder = None
        parent = getattr(self, "_parent_recorder", None)
        if parent is not None and hasattr(parent, "child"):
            sub_recorder = parent.child("plan")

        prompt = f"""You are a software architect. Explore the codebase and create an implementation plan optimized for local LLMs.

## Rules
- Explore the codebase to understand current structure before planning.
- Be specific. Reference actual file paths and function names found in the code.
- Include a goal, list of files to modify, numbered steps, and potential risks.
- Keep it actionable. Each step should be directly executable by a coding agent.
- Do not modify any files.

## Plan format rules (optimized for Qwen 3.5 and local models)
- Each step must be self-contained: include the file path, what to change, and why.
- Never reference other steps ("as in step 2"). Each step is independent.
- For file edits: include the exact function/class name and what to add/change/remove.
- For new files: describe the complete structure (imports, classes, functions).
- Prefer search-and-replace edits over full file rewrites.
- Keep steps small: one file per step, one change per step.
- Use concrete examples: "add parameter `timeout: int = 30` to `def connect()`" not "update the connect function".
- Avoid abstract instructions like "refactor", "improve", "clean up". Say exactly what to do.

## Environment
- Working directory: {self.config.cwd}
- Date: {datetime.date.today().isoformat()}"""

        try:
            return ToolResult(content=_run_subagent(
                self.config, tools, prompt, task,
                trace_recorder=sub_recorder,
            ))
        except Exception as e:
            return ToolResult(content=f"Plan failed: {e}", is_error=True)


class DocumentTool(Tool):
    """Sub-agent specialized in project documentation and indexing."""

    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "document"

    @property
    def description(self) -> str:
        return (
            "Launch a documentation sub-agent that researches the project, writes "
            "structured documentation to .vicode/docs/, and reindexes when done. "
            "Use when: initializing a new project, or after significant code changes. "
            "scope: 'full' for complete research, 'update' for incremental refresh."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "scope": {
                    "type": "string",
                    "description": "full | update",
                },
                "focus": {
                    "type": "string",
                    "description": "Optional: specific area to focus on (e.g. 'auth module')",
                },
            },
            "required": ["scope"],
        }

    def run(self, scope: str = "full", focus: str = "") -> ToolResult:
        tools = _make_doc_agent_tools(self.config)
        sub_recorder = None
        parent = getattr(self, "_parent_recorder", None)
        if parent is not None and hasattr(parent, "child"):
            sub_recorder = parent.child("document")

        focus_note = f"\nFocus area: {focus}" if focus else ""

        prompt = f"""You are a documentation agent. Your job is to research this project and write
structured documentation to .vicode/docs/, then trigger a reindex.{focus_note}

## Phase 1: Research
Use file_read, glob, ls, grep to explore the project structure:
- List top-level directories and key files
- Read README, pyproject.toml, setup.py, package.json, or equivalent
- Identify main modules/packages and their purpose
- Find entry points (main, __main__, index, app, etc.)
- Note key dependencies

## Phase 2: Write documentation
Write these files to .vicode/docs/:
- project_overview.md: project purpose, tech stack, entry points
- architecture.md: modules, their responsibilities, how they connect
- key_files.md: most important files with 1-line descriptions

For 'update' scope, only update files that have changed; for 'full' scope, recreate all docs.

## Phase 3: Reindex
After writing documentation, call:
  docs_index(action="rebuild", force=True)
Report how many files and chunks were indexed.

## Rules
- Be concise. Each doc file should be under 200 lines.
- Use real file paths found in the project, not placeholders.
- After docs_index succeeds, finish with a 3-line summary of what was documented.
- Do not modify any source code files, only .vicode/docs/ files.

## Environment
- Working directory: {self.config.cwd}
- Date: {datetime.date.today().isoformat()}
- Scope: {scope}"""

        try:
            task = f"Begin Phase 1 now. Research this project thoroughly and complete all three phases."
            return ToolResult(content=_run_subagent(
                self.config, tools, prompt, task,
                trace_recorder=sub_recorder,
            ))
        except Exception as e:
            return ToolResult(content=f"Documentation failed: {e}", is_error=True)
