"""File editing tool - search and replace."""

import difflib
from pathlib import Path
from vicode.tools.base import Tool, ToolResult
from vicode.tools.file_history import get_file_history
from vicode.config import Config


class FileEditTool(Tool):
    def __init__(self, config: Config):
        self.config = config

    @property
    def name(self) -> str:
        return "file_edit"

    @property
    def description(self) -> str:
        return "Edit a file by replacing an exact string match with new content. The old_string must match exactly one location in the file. Include enough context to make the match unique."

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "file_path": {
                    "type": "string",
                    "description": "Path to the file to edit",
                },
                "old_string": {
                    "type": "string",
                    "description": "The exact text to find and replace (must be unique in the file)",
                },
                "new_string": {
                    "type": "string",
                    "description": "The replacement text",
                },
            },
            "required": ["file_path", "old_string", "new_string"],
        }

    def run(self, file_path: str, old_string: str, new_string: str) -> ToolResult:
        path = Path(file_path)
        if not path.is_absolute():
            path = Path(self.config.cwd) / path

        if not path.exists():
            return ToolResult(content=f"File not found: {path}", is_error=True)
        if not path.is_file():
            return ToolResult(content=f"Not a file: {path}", is_error=True)

        try:
            content = path.read_text(encoding="utf-8")
        except Exception as e:
            return ToolResult(content=f"Error reading file: {e}", is_error=True)

        count = content.count(old_string)
        if count == 0:
            return ToolResult(content="old_string not found in file. Check for exact match including whitespace.", is_error=True)
        if count > 1:
            return ToolResult(content=f"old_string found {count} times. Include more context to make it unique.", is_error=True)

        get_file_history().save_snapshot(str(path))
        new_content = content.replace(old_string, new_string, 1)

        try:
            path.write_text(new_content, encoding="utf-8")
        except Exception as e:
            return ToolResult(content=f"Error writing file: {e}", is_error=True)

        # Generate compact diff
        old_lines = content.splitlines()
        new_lines = new_content.splitlines()
        diff = difflib.unified_diff(old_lines, new_lines, fromfile=str(path), tofile=str(path), lineterm="")
        diff_text = "\n".join(diff)

        if len(diff_text) > 2000:
            diff_text = diff_text[:2000] + "\n... (diff truncated)"

        return ToolResult(content=f"Edited {path}\n{diff_text}")
