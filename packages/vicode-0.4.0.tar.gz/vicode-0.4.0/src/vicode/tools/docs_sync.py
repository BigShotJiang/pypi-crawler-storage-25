"""Docs sync tool - incrementally sync documentation changes."""

import json
import os
from pathlib import Path

from vicode.tools.base import Tool, ToolResult


class DocsSyncTool(Tool):
    """Incrementally sync documentation index."""

    def __init__(self, cwd: str = ""):
        self._cwd = cwd
        self._docs_dir = None

    @property
    def name(self) -> str:
        return "docs_sync"

    @property
    def description(self) -> str:
        return (
            "Incrementally sync documentation index. "
            "Updates changed files without full rebuild."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "action": {
                    "type": "string",
                    "description": "One of: sync, check, clean",
                },
            },
            "required": ["action"],
        }

    def _get_docs_dir(self) -> Path:
        if self._docs_dir is None:
            self._docs_dir = Path(self._cwd) / ".vicode" / "docs"
        return self._docs_dir

    def _get_chunks_dir(self) -> Path:
        return self._get_docs_dir() / "chunks"

    def run(self, action: str, **kwargs) -> ToolResult:
        docs_dir = self._get_docs_dir()
        chunks_dir = self._get_chunks_dir()

        if action == "check":
            if not docs_dir.exists():
                return ToolResult(content="No documentation index found.")

            index_file = docs_dir / "index.json"
            if not index_file.exists():
                return ToolResult(content="Index is empty.", is_error=True)

            try:
                index_data = json.loads(index_file.read_text(encoding="utf-8"))
                files = index_data.get("files", [])

                missing = []
                for file_path in files:
                    if not Path(file_path).exists():
                        missing.append(file_path)

                if missing:
                    return ToolResult(
                        content=f"Missing files: {len(missing)}\n" + "\n".join(missing)
                    )
                else:
                    return ToolResult(content="All indexed files exist.")
            except Exception as e:
                return ToolResult(content=f"Check error: {e}", is_error=True)

        if action == "sync":
            if not docs_dir.exists():
                return ToolResult(
                    content="No index found. Run docs_index(action='index') first.",
                    is_error=True,
                )

            from vicode.tools.docs_index import find_code_files

            extensions = {".py", ".js", ".ts", ".jsx", ".tsx", ".md", ".txt"}
            current_files = set(
                str(f.relative_to(self._cwd))
                for f in find_code_files(self._cwd, extensions)
            )

            index_file = docs_dir / "index.json"
            try:
                index_data = json.loads(index_file.read_text(encoding="utf-8"))
                indexed_files = set(index_data.get("files", []))
            except Exception:
                indexed_files = set()

            new_files = current_files - indexed_files
            deleted_files = indexed_files - current_files

            if not new_files and not deleted_files:
                return ToolResult(content="No changes detected.")

            lines = []
            if new_files:
                lines.append(f"New files: {len(new_files)}")
                for f in sorted(new_files)[:5]:
                    lines.append(f"  + {f}")
            if deleted_files:
                lines.append(f"Deleted files: {len(deleted_files)}")
                for f in sorted(deleted_files)[:5]:
                    lines.append(f"  - {f}")

            return ToolResult(content="\n".join(lines))

        if action == "clean":
            if not docs_dir.exists():
                return ToolResult(content="No docs directory to clean.")

            removed = 0
            for vdoc_file in chunks_dir.glob("*.vdoc"):
                vdoc_file.unlink()
                removed += 1

            if index_file := docs_dir / "index.json":
                if index_file.exists():
                    index_file.unlink()

            return ToolResult(content=f"Cleaned {removed} chunks.")

        return ToolResult(
            content=f"Unknown action: {action}. Use check, sync, or clean.",
            is_error=True,
        )
