"""Docs query tool - semantic search in indexed documentation."""

import json
import os
from pathlib import Path
from typing import Optional

from vicode.tools.base import Tool, ToolResult


def normalize_text(text: str) -> str:
    """Normalize text for comparison."""
    return " ".join(text.lower().split())


def simple_score(query: str, content: str, symbols: list[str]) -> float:
    """Simple keyword-based scoring."""
    query_norm = normalize_text(query)
    content_norm = normalize_text(content)

    score = 0.0

    query_words = set(query_norm.split())
    content_words = set(content_norm.split())

    for word in query_words:
        if word in content_words:
            score += 1.0

    for symbol in symbols:
        if normalize_text(symbol) in query_norm:
            score += 5.0

    return score


def fuzzy_score(query: str, content: str, symbols: list[str]) -> float:
    """Score with fuzzy matching."""
    query_norm = normalize_text(query)
    content_norm = normalize_text(content)

    score = simple_score(query, content, symbols)

    query_parts = query_norm.split()
    for part in query_parts:
        if len(part) < 3:
            continue
        if part in content_norm:
            score += 0.5

    for symbol in symbols:
        symbol_norm = normalize_text(symbol)
        if symbol_norm in query_norm or query_norm in symbol_norm:
            score += 3.0

    return score


class DocsQueryTool(Tool):
    """Query indexed documentation with semantic search."""

    def __init__(self, cwd: str = ""):
        self._cwd = cwd
        self._docs_dir: Optional[Path] = None
        self._index_cache = None

    @property
    def name(self) -> str:
        return "docs_query"

    @property
    def description(self) -> str:
        return (
            "Search indexed documentation. Use after docs_index. "
            "Returns relevant code chunks with context."
        )

    @property
    def parameters(self) -> dict:
        return {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "Search query",
                },
                "top_k": {
                    "type": "integer",
                    "description": "Number of results (default: 5)",
                },
                "file_filter": {
                    "type": "string",
                    "description": "Filter by file pattern",
                },
            },
            "required": ["query"],
        }

    def _get_docs_dir(self) -> Path:
        if self._docs_dir is None:
            self._docs_dir = Path(self._cwd) / ".vicode" / "docs"
        return self._docs_dir

    def _get_chunks_dir(self) -> Path:
        return self._get_docs_dir() / "chunks"

    def _load_index(self) -> dict:
        if self._index_cache is not None:
            return self._index_cache

        index_file = self._get_docs_dir() / "index.json"
        if not index_file.exists():
            return {}

        try:
            self._index_cache = json.loads(index_file.read_text(encoding="utf-8"))
        except Exception:
            self._index_cache = {}

        return self._index_cache

    def _load_chunks(self) -> list[dict]:
        chunks_dir = self._get_chunks_dir()
        if not chunks_dir.exists():
            return []

        chunks = []
        for vdoc_file in sorted(chunks_dir.glob("*.vdoc")):
            try:
                chunk_data = json.loads(vdoc_file.read_text(encoding="utf-8"))
                chunk_data["_file"] = str(vdoc_file)
                chunks.append(chunk_data)
            except Exception:
                continue

        return chunks

    def run(
        self, query: str, top_k: int = 5, file_filter: str = "", **kwargs
    ) -> ToolResult:
        docs_dir = self._get_docs_dir()

        if not docs_dir.exists():
            return ToolResult(
                content="No documentation index found. Run docs_index(action='index') first.",
                is_error=True,
            )

        index = self._load_index()
        if not index:
            return ToolResult(
                content="Index is empty. Run docs_index(action='index').", is_error=True
            )

        chunks = self._load_chunks()
        if not chunks:
            return ToolResult(
                content="No chunks found. Run docs_index(action='index').",
                is_error=True,
            )

        if file_filter:
            file_filter = file_filter.lower().replace("*", "").replace("?", "")
            chunks = [c for c in chunks if file_filter in c.get("file", "").lower()]

        if not chunks:
            return ToolResult(content="No chunks match the filter.", is_error=True)

        scored_results = []
        for chunk in chunks:
            content = chunk.get("content", "")
            symbols = chunk.get("symbols", [])

            score = fuzzy_score(query, content, symbols)

            if score > 0:
                scored_results.append((score, chunk))

        scored_results.sort(key=lambda x: x[0], reverse=True)

        top_results = scored_results[:top_k]

        if not top_results:
            return ToolResult(content=f"No results found for: {query}")

        lines = [f"Results for '{query}' (top {len(top_results)}):\n"]

        for score, chunk in top_results:
            file_path = chunk.get("file", "")
            line_start = chunk.get("line_start", 0)
            line_end = chunk.get("line_end", 0)
            symbols = chunk.get("symbols", [])
            content_preview = chunk.get("content", "")[:300]

            file_name = Path(file_path).name

            result = [
                f"\n--- Score: {score:.1f} ---",
                f"File: {file_name}:{line_start}-{line_end}",
            ]

            if symbols:
                result.append(f"Symbols: {', '.join(symbols[:5])}")

            result.append(f"Content:\n{content_preview}")

            lines.append("\n".join(result))

        return ToolResult(content="\n".join(lines))
