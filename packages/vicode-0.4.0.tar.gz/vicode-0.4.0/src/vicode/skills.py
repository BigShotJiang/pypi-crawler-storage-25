"""Discover Skills (Claude Code-compatible) for vicode.

A skill is a folder containing a `SKILL.md` file with YAML frontmatter:

    .claude/skills/<skill-name>/SKILL.md

Vicode looks in two places:
  1. `<cwd>/.claude/skills/`              — project-scoped skills (committed)
  2. `~/.claude/skills/`                  — user-scoped (personal)

The format mirrors Anthropic's spec: only `name` and `description` are
mandatory; the body is markdown with instructions Claude follows when the
skill is active. We support `disable-model-invocation` and `allowed-tools`
fields too, but for now we only expose discovery — the full invocation
plumbing lives in the agent loop and will read these records.

Sources:
  - https://code.claude.com/docs/en/skills
  - https://github.com/anthropics/skills
"""

from __future__ import annotations

from dataclasses import dataclass, field
from pathlib import Path


@dataclass
class Skill:
    name: str
    description: str
    path: Path                       # path to the skill folder
    body: str = ""                   # markdown after the frontmatter
    allowed_tools: list[str] = field(default_factory=list)
    disable_model_invocation: bool = False
    scope: str = "user"              # "project" or "user"

    def header_summary(self) -> str:
        return f"{self.name}: {self.description}"


def _parse_skill_md(path: Path, scope: str) -> Skill | None:
    """Parse a SKILL.md file. Returns None if invalid."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
    except Exception:
        return None

    name = path.parent.name
    description = ""
    body = text
    allowed_tools: list[str] = []
    disable_model_invocation = False

    # Pull out --- ... --- frontmatter if present.
    if text.startswith("---"):
        end = text.find("\n---", 3)
        if end != -1:
            fm = text[3:end].strip()
            body = text[end + 4:].lstrip("\n")
            for raw_line in fm.splitlines():
                line = raw_line.strip()
                if not line or line.startswith("#"):
                    continue
                if ":" not in line:
                    continue
                key, _, value = line.partition(":")
                key = key.strip().lower()
                value = value.strip().strip('"').strip("'")
                if key == "name" and value:
                    name = value
                elif key == "description" and value:
                    description = value
                elif key == "disable-model-invocation":
                    disable_model_invocation = value.lower() in ("true", "yes", "1")
                elif key == "allowed-tools":
                    # Accept "tool1, tool2" or YAML inline list "[a, b]"
                    cleaned = value.strip("[]")
                    allowed_tools = [
                        t.strip().strip('"').strip("'")
                        for t in cleaned.split(",")
                        if t.strip()
                    ]

    if not name:
        return None
    return Skill(
        name=name,
        description=description,
        path=path.parent,
        body=body,
        allowed_tools=allowed_tools,
        disable_model_invocation=disable_model_invocation,
        scope=scope,
    )


def _scan_dir(root: Path, scope: str) -> list[Skill]:
    if not root.is_dir():
        return []
    out: list[Skill] = []
    # Each direct child folder must contain a SKILL.md (don't recurse deeper —
    # that's the most common installation mistake).
    for child in sorted(root.iterdir()):
        if not child.is_dir():
            continue
        skill_md = child / "SKILL.md"
        if not skill_md.is_file():
            continue
        s = _parse_skill_md(skill_md, scope)
        if s:
            out.append(s)
    return out


def discover_skills(cwd: str | Path | None = None) -> list[Skill]:
    """Discover all Claude Code-compatible skills.

    Project skills (in `<cwd>/.claude/skills/`) take precedence over user
    skills with the same name.
    """
    skills: dict[str, Skill] = {}
    # User skills first, project overrides.
    home = Path.home() / ".claude" / "skills"
    for s in _scan_dir(home, scope="user"):
        skills[s.name] = s
    if cwd is not None:
        # Resolve to absolute so relative cwds (".") still find the skills.
        proj = (Path(cwd).resolve()) / ".claude" / "skills"
        for s in _scan_dir(proj, scope="project"):
            skills[s.name] = s
    return list(skills.values())
