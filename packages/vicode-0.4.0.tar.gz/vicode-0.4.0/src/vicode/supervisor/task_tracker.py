"""Task Tracker - uses a lightweight reviewer sub-agent to update task status."""

from vicode.config import Config
from vicode.supervisor.base import Supervisor, SupervisorVerdict
from vicode.supervisor.plan_state import PlanState, PlanTask
from vicode.tools.base import Tool, ToolResult, ToolRegistry


class TaskTracker(Supervisor):
    """Tracks plan tasks. Uses a mini sub-agent to review after file edits and at turn end."""

    def __init__(self, config: Config | None = None):
        self.plan_state: PlanState | None = None
        self.config = config
        self._review_counter = 0
        self.plan_just_created = False  # True until first tool call after plan
        self.last_review_feedback: str = (
            ""  # feedback from last LLM review for continuation hint
        )

    def post_execute(
        self, name: str, args: dict, result: ToolResult, plan_state, history: list[dict]
    ) -> SupervisorVerdict:
        events = []

        # Plan tool -> parse tasks
        if name == "plan" and not result.is_error:
            self.plan_state = PlanState.from_plan_output(result.content)
            self.plan_just_created = True
            self.last_review_feedback = ""
            if self.plan_state.tasks:
                events.append({"type": "tasks_updated", "tasks": self.plan_state.tasks})
        elif self.plan_just_created:
            # Reset on ANY tool executed after the plan — agent has started working
            self.plan_just_created = False

        # File write/edit -> mark task progress immediately
        if (
            name in ("file_write", "file_edit")
            and self.plan_state
            and not result.is_error
        ):
            file_path = args.get("file_path", "")
            if file_path:
                self.plan_state.mark_file_touched(file_path)
                events.append({"type": "tasks_updated", "tasks": self.plan_state.tasks})

        return SupervisorVerdict(events=events)

    def review_completion(self, history: list[dict] | None = None) -> list[str]:
        """Final review at end of agent turn. Returns pending task descriptions."""
        if not self.plan_state:
            return []
        if self.plan_just_created:
            return []
        self._run_review_final(history)
        pending = [
            f"  {t.index}. {t.description}"
            for t in self.plan_state.tasks
            if t.status != "done"
        ]
        return pending

    def is_session_complete(self, history: list[dict]) -> bool:
        """Check if the session is complete based on combined conditions."""
        if not self.plan_state:
            return False

        pending = [t for t in self.plan_state.tasks if t.status != "done"]
        if pending:
            return False

        if not history:
            return False

        has_recent_tool_call = False
        for msg in reversed(history[-5:]):
            if msg.get("tool_calls"):
                has_recent_tool_call = True
                break

        if has_recent_tool_call:
            return False

        return True

    def _run_review(self, history: list[dict]) -> bool:
        """Quick review: look at recent tool results to update tasks."""
        if not self.plan_state:
            return False
        changed = False
        # Scan recent history for file operations
        recent_files = set()
        for msg in reversed(history[-20:]):
            if msg.get("role") == "tool":
                content = msg.get("content", "")
                # Extract file paths from tool results like "Created /path/file.js"
                for word in content.split():
                    if "." in word and "/" in word or "\\" in word:
                        recent_files.add(word.strip("'\"()"))
            tc = msg.get("tool_calls", [])
            for t in tc:
                fn = t.get("function", {})
                if fn.get("name") in ("file_write", "file_edit"):
                    import json

                    try:
                        a = json.loads(fn.get("arguments", "{}"))
                        fp = a.get("file_path", "")
                        if fp:
                            recent_files.add(fp)
                    except Exception:
                        pass

        # Match recent files against tasks
        for fp in recent_files:
            self.plan_state.mark_file_touched(fp)
            changed = True
        return changed

    def _run_review_final(self, history: list[dict] | None = None):
        """At turn end, use LLM to judge which tasks are done and generate feedback."""
        if not self.plan_state or not self.config:
            return
        pending = [t for t in self.plan_state.tasks if t.status != "done"]
        if not pending:
            return

        work_summary = self._extract_work_summary(history or [])

        try:
            from openai import OpenAI

            client = OpenAI(
                base_url=self.config.server_url,
                api_key=self.config.api_key or "not-needed",
            )
            tasks_text = "\n".join(
                f"{t.index}. [{t.status}] {t.description}"
                for t in self.plan_state.tasks
            )
            system = (
                "You are a strict task completion reviewer.\n"
                "Given a task list and a summary of work done, determine which tasks are fully complete.\n\n"
                "Reply with EXACTLY these two lines and nothing else:\n"
                "DONE: <comma-separated task indices that are complete, or ALL, or NONE>\n"
                "FEEDBACK: <one concise sentence of actionable guidance for any incomplete tasks, "
                "e.g. 'Task 2 needs tests run to verify. Task 4: config file was not written.'>\n\n"
                "Be strict: only mark DONE if the work summary clearly shows completion."
            )
            response = client.chat.completions.create(
                model=self.config.model,
                messages=[
                    {"role": "system", "content": system},
                    {
                        "role": "user",
                        "content": (
                            f"Tasks:\n{tasks_text}\n\nWork done:\n{work_summary}"
                        ),
                    },
                ],
                max_tokens=120,
                temperature=0.0,
                stream=False,
            )
            raw = response.choices[0].message.content.strip()
            done_line = ""
            feedback_line = ""
            for line in raw.splitlines():
                if line.upper().startswith("DONE:"):
                    done_line = line.split(":", 1)[1].strip().upper()
                elif line.upper().startswith("FEEDBACK:"):
                    feedback_line = line.split(":", 1)[1].strip()

            self.last_review_feedback = feedback_line

            if done_line == "ALL":
                for t in self.plan_state.tasks:
                    t.status = "done"
            elif done_line and done_line != "NONE":
                for part in done_line.replace(" ", "").split(","):
                    try:
                        self.plan_state.mark_task_done(int(part))
                    except (ValueError, TypeError):
                        pass
        except Exception:
            pass

    def _extract_work_summary(self, history: list[dict]) -> str:
        """Extract compact summary of work done, including tool results."""
        import json

        actions = []
        # Track last tool call name to pair with its result
        last_tool_name = ""

        for msg in history[-40:]:
            role = msg.get("role", "")

            # Tool calls made by the agent
            if role == "assistant":
                for tc in msg.get("tool_calls", []):
                    fn = tc.get("function", {})
                    name = fn.get("name", "")
                    last_tool_name = name
                    try:
                        args = json.loads(fn.get("arguments", "{}"))
                    except Exception:
                        args = {}
                    if name in ("file_write", "file_edit", "file_delete"):
                        actions.append(f"{name}: {args.get('file_path', '?')}")
                    elif name == "bash":
                        cmd = args.get("command", "")[:80]
                        actions.append(f"bash: {cmd}")
                    elif name in ("file_read", "grep", "glob_search"):
                        pass  # read-only, skip
                if msg.get("content"):
                    text = msg["content"][-150:]
                    actions.append(f"agent: {text}")

            # Tool results — include compact output so reviewer knows if it succeeded
            elif role == "tool":
                content = (msg.get("content") or "").strip()
                if content:
                    # First and last line to capture both header and summary
                    lines = [l for l in content.splitlines() if l.strip()]
                    if len(lines) <= 3:
                        summary = content[:200]
                    else:
                        summary = lines[0][:100]
                        if lines[-1] != lines[0]:
                            summary += f" … {lines[-1][:80]}"
                    actions.append(f"  result: {summary}")

        return "\n".join(actions[-20:]) if actions else "No actions recorded"
