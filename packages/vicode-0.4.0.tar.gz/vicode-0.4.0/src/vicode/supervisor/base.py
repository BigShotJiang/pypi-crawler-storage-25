"""Supervisor framework - base classes for pre/post tool execution hooks."""

from abc import ABC, abstractmethod
from dataclasses import dataclass, field

from vicode.tools.base import ToolResult


@dataclass
class SupervisorVerdict:
    approved: bool = True
    message: str | None = None   # injected into tool result if set
    events: list[dict] = field(default_factory=list)  # UI events to yield


class Supervisor(ABC):
    """Base class for supervisors. Override pre/post_execute."""

    def pre_execute(self, name: str, args: dict, plan_state, history: list[dict]) -> SupervisorVerdict:
        return SupervisorVerdict()

    def post_execute(self, name: str, args: dict, result: ToolResult, plan_state, history: list[dict]) -> SupervisorVerdict:
        return SupervisorVerdict()


class SupervisorChain:
    """Runs multiple supervisors. Pre: short-circuits on block. Post: runs all."""

    def __init__(self, supervisors: list[Supervisor]):
        self.supervisors = supervisors

    def pre_execute(self, name: str, args: dict, plan_state, history: list[dict]) -> SupervisorVerdict:
        merged_events = []
        for sup in self.supervisors:
            verdict = sup.pre_execute(name, args, plan_state, history)
            merged_events.extend(verdict.events)
            if not verdict.approved:
                return SupervisorVerdict(
                    approved=False,
                    message=verdict.message,
                    events=merged_events,
                )
            if verdict.message:
                # First warning wins as the message
                return SupervisorVerdict(
                    approved=True,
                    message=verdict.message,
                    events=merged_events,
                )
        return SupervisorVerdict(approved=True, events=merged_events)

    def post_execute(self, name: str, args: dict, result: ToolResult, plan_state, history: list[dict]) -> SupervisorVerdict:
        merged_events = []
        merged_message = None
        for sup in self.supervisors:
            verdict = sup.post_execute(name, args, result, plan_state, history)
            merged_events.extend(verdict.events)
            if verdict.message and not merged_message:
                merged_message = verdict.message
        return SupervisorVerdict(approved=True, message=merged_message, events=merged_events)
