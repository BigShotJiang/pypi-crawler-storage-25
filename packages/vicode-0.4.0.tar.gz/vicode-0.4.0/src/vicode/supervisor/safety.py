"""Safety Guardian - validates tool calls against the active plan."""

import re
from vicode.config import Config
from vicode.supervisor.base import Supervisor, SupervisorVerdict
from vicode.supervisor.plan_state import PlanState
from vicode.tools.base import ToolResult


WRITE_TOOLS = {"file_write", "file_edit", "bash"}

# Bash commands that are clearly read-only
READ_ONLY_BASH = re.compile(
    r"^\s*(ls|dir|cat|head|tail|find|grep|rg|ag|fd|"
    r"git\s+(status|log|diff|show|branch|remote|tag)|"
    r"echo|pwd|which|type|file|wc|sort|uniq|tee|"
    r"python\s+-c|python3?\s+\S+\.py|node\s+\S+\.js|"
    r"pip\s+(list|show|freeze)|npm\s+(list|ls)|"
    r"curl\s|wget\s|test\s|stat\s|du\s|df\s|env|printenv)",
    re.IGNORECASE,
)


class SafetyGuardian(Supervisor):
    """Pre-execute check: validates write tools against active plan.

    Fast-path (0ms): rule-based approval for ~80% of calls.
    Slow-path (~1-2s): LLM check for ambiguous cases.
    """

    def __init__(self, config: Config):
        self.config = config
        self._client = None

    def pre_execute(self, name: str, args: dict, plan_state: PlanState | None, history: list[dict]) -> SupervisorVerdict:
        # Fast path 1: not a write tool
        if name not in WRITE_TOOLS:
            return SupervisorVerdict()

        # Fast path 2: no active plan
        if plan_state is None or not plan_state.tasks:
            return SupervisorVerdict()

        # Fast path 3: bash but read-only
        if name == "bash":
            cmd = args.get("command", "")
            if READ_ONLY_BASH.match(cmd):
                return SupervisorVerdict()

        # Fast path 4: file target is in the plan
        if name in ("file_write", "file_edit"):
            file_path = args.get("file_path", "")
            if plan_state.is_file_in_plan(file_path):
                return SupervisorVerdict()

        # Slow path: ask LLM
        return self._llm_check(name, args, plan_state)

    def _llm_check(self, name: str, args: dict, plan_state: PlanState) -> SupervisorVerdict:
        """Ask the LLM if this action aligns with the plan."""
        system = (
            "You are a safety checker. Given a plan and an action, reply with EXACTLY one of:\n"
            "OK - if the action aligns with or supports the plan\n"
            "WARN: <reason in 10 words> - if it seems off-track but not dangerous\n"
            "BLOCK: <reason in 10 words> - if it clearly contradicts the plan or is dangerous"
        )
        args_summary = self._summarize_args(name, args)
        user = f"Plan:\n{plan_state.summary_for_llm()}\n\nAction: {name}({args_summary})"

        try:
            client = self._get_client()
            response = client.chat.completions.create(
                model=self.config.model,
                messages=[
                    {"role": "system", "content": system},
                    {"role": "user", "content": user},
                ],
                max_tokens=64,
                temperature=0.0,
                stream=False,
            )
            text = response.choices[0].message.content.strip()
            return self._parse_response(text)
        except Exception:
            # On failure, approve silently
            return SupervisorVerdict()

    def _get_client(self):
        if self._client is None:
            from openai import OpenAI
            self._client = OpenAI(
                base_url=self.config.server_url,
                api_key=self.config.api_key or "not-needed",
            )
        return self._client

    def _parse_response(self, text: str) -> SupervisorVerdict:
        upper = text.upper().strip()
        if upper.startswith("OK"):
            return SupervisorVerdict()
        elif upper.startswith("BLOCK"):
            reason = text.split(":", 1)[1].strip() if ":" in text else "Action blocked by supervisor"
            return SupervisorVerdict(
                approved=False,
                message=f"[SUPERVISOR BLOCKED] {reason}",
                events=[{"type": "supervisor_warn", "message": f"BLOCKED: {reason}"}],
            )
        elif upper.startswith("WARN"):
            reason = text.split(":", 1)[1].strip() if ":" in text else "Possible deviation from plan"
            return SupervisorVerdict(
                approved=True,
                message=f"[SUPERVISOR WARNING] {reason}",
                events=[{"type": "supervisor_warn", "message": reason}],
            )
        # Unrecognized response, approve
        return SupervisorVerdict()

    def _summarize_args(self, name: str, args: dict) -> str:
        """Compact arg representation for LLM prompt."""
        parts = []
        for k, v in args.items():
            v_str = str(v)
            if len(v_str) > 80:
                v_str = v_str[:80] + "..."
            parts.append(f"{k}={v_str}")
        return ", ".join(parts)
