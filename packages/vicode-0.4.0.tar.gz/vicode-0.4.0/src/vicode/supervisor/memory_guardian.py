"""Memory Guardian - automatically stores interesting events in engram."""

from vicode.supervisor.base import Supervisor, SupervisorVerdict
from vicode.tools.base import ToolResult
from vicode.tools.memory import _get_namespace


class MemoryGuardian(Supervisor):
    """Post-execute observer. 100% rule-based, no LLM calls.

    Detects patterns and stores them in persistent memory:
    - Errors that were later corrected
    - Plans created
    - Key exploration findings
    - Files frequently modified together
    """

    def __init__(self, cwd: str = ""):
        self._mem = None
        self._namespace = _get_namespace(cwd)
        self._last_errors: dict[str, str] = {}
        self._files_modified: list[str] = []

    def post_execute(self, name: str, args: dict, result: ToolResult, plan_state, history: list[dict]) -> SupervisorVerdict:
        events = []

        # Pattern 1: Error followed by correction
        if result.is_error:
            self._last_errors[name] = result.content[:200]
        elif name in self._last_errors:
            prev_error = self._last_errors.pop(name)
            note = f"Error fixed in {name}: {prev_error[:100]}"
            self._store(note, type="error_fix", importance=7)
            events.append({"type": "memory_stored", "content": note[:60]})

        # Pattern 2: Plan created
        if name == "plan" and not result.is_error:
            summary = result.content[:200].replace("\n", " ")
            self._store(f"Plan: {summary}", type="workflow", importance=5)
            events.append({"type": "memory_stored", "content": "plan saved"})

        # Pattern 3: Explore found something
        if name == "explore" and not result.is_error and len(result.content) > 50:
            summary = result.content[:200].replace("\n", " ")
            self._store(f"Research: {summary}", type="fact", importance=4)
            events.append({"type": "memory_stored", "content": "research saved"})

        # Pattern 4: Track file modification patterns
        if name in ("file_write", "file_edit") and not result.is_error:
            fp = args.get("file_path", "")
            if fp:
                self._files_modified.append(fp.split("/")[-1].split("\\")[-1])
                # After 5 files, store the pattern
                if len(self._files_modified) >= 5:
                    pattern = ", ".join(self._files_modified[-5:])
                    self._store(f"Files modified together: {pattern}", type="pattern", importance=3)
                    self._files_modified.clear()

        return SupervisorVerdict(events=events)

    def _store(self, content: str, type: str = "fact", importance: int = 5):
        try:
            if self._mem is None:
                from engram import Memory
                self._mem = Memory()
            self._mem.store(content, type=type, importance=importance, namespace=self._namespace)
        except Exception:
            pass
