"""Plan state tracking - parses plan output and tracks task progress."""

import re
from dataclasses import dataclass, field
from pathlib import PurePosixPath, PureWindowsPath


@dataclass
class PlanTask:
    index: int
    description: str
    files: list[str] = field(default_factory=list)
    status: str = "pending"  # "pending" | "in_progress" | "done"


class PlanState:
    """Parsed plan with task tracking."""

    def __init__(self, tasks: list[PlanTask], target_files: set[str], raw_plan: str = ""):
        self.tasks = tasks
        self.target_files = target_files
        self.raw_plan = raw_plan

    @classmethod
    def from_plan_output(cls, text: str) -> "PlanState":
        """Parse a plan tool output into structured tasks."""
        tasks = []
        target_files: set[str] = set()

        # Extract files from "Files to modify:" section
        files_section = re.search(
            r"(?:files?\s+to\s+(?:modify|change|create|edit))[\s:]*\n((?:[-*]\s+.+\n?)+)",
            text, re.IGNORECASE,
        )
        if files_section:
            for m in re.finditer(r"[-*]\s+`?([^\s`*]+)`?", files_section.group(1)):
                target_files.add(_normalize_path(m.group(1)))

        # Extract numbered steps
        step_pattern = re.compile(r"^\s*(\d+)[.)]\s+(.+?)$", re.MULTILINE)
        for match in step_pattern.finditer(text):
            idx = int(match.group(1))
            desc = match.group(2).strip()
            # Extract file paths mentioned in this step
            step_files = _extract_paths(desc)
            target_files.update(step_files)
            tasks.append(PlanTask(index=idx, description=desc, files=step_files))

        # If no numbered steps, try bullet points after "Steps:" header
        if not tasks:
            steps_section = re.search(
                r"(?:steps?)[\s:]*\n((?:[-*]\s+.+\n?)+)",
                text, re.IGNORECASE,
            )
            if steps_section:
                for i, m in enumerate(re.finditer(r"[-*]\s+(.+)", steps_section.group(1)), 1):
                    desc = m.group(1).strip()
                    step_files = _extract_paths(desc)
                    target_files.update(step_files)
                    tasks.append(PlanTask(index=i, description=desc, files=step_files))

        return cls(tasks=tasks, target_files=target_files, raw_plan=text)

    def is_file_in_plan(self, file_path: str) -> bool:
        """Check if a file path is mentioned anywhere in the plan."""
        normalized = _normalize_path(file_path)
        for target in self.target_files:
            if normalized.endswith(target) or target.endswith(normalized):
                return True
            # Also check just filename
            if PurePosixPath(normalized).name == PurePosixPath(target).name:
                return True
        return False

    def mark_file_touched(self, file_path: str):
        """Mark tasks related to this file as in_progress or done."""
        normalized = _normalize_path(file_path)
        filename = PurePosixPath(normalized).name
        for task in self.tasks:
            if task.status == "done":
                continue
            # Match against extracted file paths
            matched = any(
                normalized.endswith(tf) or tf.endswith(normalized) or
                PurePosixPath(tf).name == filename
                for tf in task.files
            )
            # Also match filename mentioned anywhere in the task description
            if not matched and filename in task.description.lower():
                matched = True
            if matched:
                if task.status == "in_progress":
                    task.status = "done"  # touched again -> done
                else:
                    task.status = "in_progress"

    def mark_task_done(self, index: int):
        """Mark a specific task as done by index."""
        for task in self.tasks:
            if task.index == index:
                task.status = "done"

    def summary_for_llm(self) -> str:
        """Ultra-compact plan summary for safety LLM check (~200 tokens max)."""
        lines = []
        if self.target_files:
            lines.append(f"Files: {', '.join(sorted(self.target_files)[:10])}")
        for t in self.tasks[:10]:
            status = {"pending": "[ ]", "in_progress": "[>]", "done": "[x]"}[t.status]
            lines.append(f"{status} {t.index}. {t.description[:80]}")
        return "\n".join(lines)


def _normalize_path(path: str) -> str:
    """Normalize path for comparison: forward slashes, no leading ./ or drive."""
    p = path.replace("\\", "/").strip()
    # Remove drive letter (C:/)
    if len(p) > 2 and p[1] == ":":
        p = p[2:]
    # Remove leading ./
    if p.startswith("./"):
        p = p[2:]
    # Remove leading /
    p = p.lstrip("/")
    return p.lower()


def _extract_paths(text: str) -> list[str]:
    """Extract file-like paths from text."""
    paths = []
    # Match: `path.ext`, (path.ext), path/file.ext, file.ext
    for m in re.finditer(
        r"`([^`]+\.\w+)`"                          # backtick quoted
        r"|\(([^)]+\.\w+)\)"                        # parenthesized
        r"|(?:^|\s)((?:[\w./\\-]+/)?[\w-]+\.\w+)",  # bare path
        text,
    ):
        path = m.group(1) or m.group(2) or m.group(3)
        if path and "." in path:
            # Split on + or , for combined paths like "index.html + styles.css"
            for part in re.split(r"\s*[+,]\s*", path):
                part = part.strip()
                if "." in part:
                    paths.append(_normalize_path(part))
    return paths
