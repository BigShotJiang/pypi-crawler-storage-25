"""Summarizer agent for session wrap-up."""

from dataclasses import dataclass


SYSTEM_PROMPT = """You are a session summarizer. Your job is to create a concise summary of what was accomplished in the conversation.

## Rules
- Summarize in the user's language (provided as parameter)
- Keep it brief: 2-4 sentences
- Focus on actionable outcomes
- Use **bold** for file names and key terms

## Output Format
Provide a summary that covers:
1. What was done
2. Files modified (if any)
3. Any errors or warnings encountered"""

LANGUAGE_NAMES = {
    "es": "Spanish",
    "en": "English",
    "fr": "French",
    "de": "German",
    "pt": "Portuguese",
    "zh": "Chinese",
    "ja": "Japanese",
}


def format_summary(history: list[dict], user_language: str = "en") -> str:
    """Generate a summary from conversation history."""
    if not history:
        return "No conversation to summarize."

    actions = []
    files_modified = []
    errors = []

    for msg in history:
        role = msg.get("role", "")
        content = msg.get("content", "") or ""
        tool_calls = msg.get("tool_calls", [])

        if role == "assistant" and content:
            if any(
                kw in content.lower()
                for kw in ["created", "modified", "updated", "wrote", "edited", "added"]
            ):
                actions.append(content[:150])

        for tc in tool_calls:
            fn = tc.get("function", {})
            name = fn.get("name", "")
            args = fn.get("arguments", "")

            if name in ("file_write", "file_edit"):
                if args:
                    try:
                        import json

                        parsed = json.loads(args)
                        fp = parsed.get("file_path", "")
                        if fp:
                            files_modified.append(fp)
                    except:
                        pass

            if name and name != "file_read" and name != "bash":
                actions.append(f"[{name}]")

        if "error" in content.lower() or "failed" in content.lower():
            errors.append(content[:100])

    summary_parts = []

    if actions:
        summary_parts.append("Completed actions: " + "; ".join(actions[:3]))
    else:
        summary_parts.append("Reviewed and discussed code")

    if files_modified:
        files = ", ".join(files_modified[:5])
        summary_parts.append(f"Files: **{files}**")

    if errors:
        summary_parts.append(f"Warnings: {len(errors)} issue(s) noted")

    return (
        " | ".join(summary_parts)
        if summary_parts
        else "Session completed successfully."
    )


@dataclass
class SummarizerAgent:
    """Agent for summarizing sessions."""

    user_language: str = "en"

    def get_system_prompt(self) -> str:
        """Get system prompt for summarizer."""
        lang_name = LANGUAGE_NAMES.get(self.user_language, "English")
        return f"{SYSTEM_PROMPT}\n\nUser language: {lang_name}"

    def summarize(self, history: list[dict]) -> str:
        """Generate summary for the conversation."""
        return format_summary(history, self.user_language)

    def build_user_message(self, history: list[dict]) -> str:
        """Build user message for summarization prompt."""
        summary = self.summarize(history)

        lang_name = LANGUAGE_NAMES.get(self.user_language, "English")

        return f"""Please provide a final summary in {lang_name}.

Recent conversation:
{summary}

Focus on:
- What was accomplished
- Files modified
- Any errors encountered

Provide a concise 2-3 sentence summary."""
