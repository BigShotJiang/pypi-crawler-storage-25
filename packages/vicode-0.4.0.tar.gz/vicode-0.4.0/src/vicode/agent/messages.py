"""Conversation message management."""

from dataclasses import dataclass, field


@dataclass
class MessageHistory:
    messages: list[dict] = field(default_factory=list)

    def set_system(self, content: str):
        if self.messages and self.messages[0]["role"] == "system":
            self.messages[0]["content"] = content
        else:
            self.messages.insert(0, {"role": "system", "content": content})

    def add_user(self, content: str):
        self.messages.append({"role": "user", "content": content})

    def add_assistant(self, content: str | None = None, tool_calls: list | None = None):
        msg = {"role": "assistant"}
        if content:
            msg["content"] = content
        if tool_calls:
            msg["tool_calls"] = tool_calls
        self.messages.append(msg)

    def add_tool_result(self, tool_call_id: str, content: str):
        self.messages.append({
            "role": "tool",
            "tool_call_id": tool_call_id,
            "content": content,
        })

    def get_messages(self) -> list[dict]:
        return self.messages

    def estimate_tokens(self) -> int:
        """Rough token estimate: ~3.5 chars per token for English/code."""
        total_chars = 0
        for m in self.messages:
            total_chars += len(str(m.get("content", "")))
            # Count tool call arguments too
            for tc in m.get("tool_calls", []):
                fn = tc.get("function", {})
                total_chars += len(fn.get("name", "")) + len(fn.get("arguments", ""))
        return int(total_chars / 3.5)
