"""Derive reusable learnings from saved session traces and consolidate memory."""

from __future__ import annotations

from dataclasses import dataclass
from typing import Callable

from vicode.tools.memory import _get_namespace


@dataclass
class SessionLearningSummary:
    session_id: int
    candidates: list[dict]


def _truncate(text: str, limit: int = 180) -> str:
    text = " ".join((text or "").split())
    if len(text) <= limit:
        return text
    return text[: limit - 3].rstrip() + "..."


def _normalize_text(text: str) -> str:
    return " ".join((text or "").strip().lower().split())


def _compress_tool_sequence(tool_sequence: list[str]) -> list[str]:
    compressed: list[str] = []
    for tool_name in tool_sequence:
        if not compressed or compressed[-1] != tool_name:
            compressed.append(tool_name)
    return compressed


def _final_assistant_content(trace: list[dict]) -> str:
    for entry in reversed(trace):
        if entry.get("type") != "assistant_message":
            continue
        content = (entry.get("payload", {}) or {}).get("content") or ""
        if content.strip():
            return content.strip()
    return ""


def _trace_has_successful_outcome(trace: list[dict]) -> bool:
    final_content = _final_assistant_content(trace)
    if not final_content:
        return False

    norm = _normalize_text(final_content)
    weak_phrases = (
        "i'll ",
        "i will ",
        "i'm going to",
        "trying to",
        "let me ",
        "cannot complete",
        "could not",
        "failed to",
        "not sure",
    )
    if any(phrase in norm for phrase in weak_phrases):
        return False

    tool_results = [
        entry.get("payload", {})
        for entry in trace
        if entry.get("type") == "tool_result"
    ]
    success_count = sum(1 for payload in tool_results if not payload.get("is_error"))
    error_count = sum(1 for payload in tool_results if payload.get("is_error"))

    if tool_results and success_count < error_count:
        return False

    return True


def _is_useful_workflow(tool_sequence: list[str]) -> bool:
    compressed = _compress_tool_sequence(tool_sequence)
    return len(compressed) >= 2 and len(set(compressed)) >= 2


def _is_useful_candidate(candidate: dict) -> bool:
    content = (candidate.get("content") or "").strip()
    if len(content) < 24:
        return False

    norm = _normalize_text(content)
    if "[system:" in norm:
        return False

    if candidate.get("type") == "summary":
        weak_phrases = ("outcome: i'll", "outcome: i will", "outcome: trying", "outcome: let me")
        if any(phrase in norm for phrase in weak_phrases):
            return False

    if candidate.get("type") == "workflow":
        workflow = content.split(":", 1)[-1].strip()
        tool_sequence = [part.strip() for part in workflow.split("->") if part.strip()]
        if not _is_useful_workflow(tool_sequence):
            return False

    return True


def _candidate_key(candidate: dict) -> tuple[str, str]:
    return candidate.get("type", "fact"), _normalize_text(candidate.get("content", ""))


def derive_learning_candidates(trace: list[dict], max_items: int = 5) -> list[dict]:
    if not _trace_has_successful_outcome(trace):
        return []

    candidates: list[dict] = []
    seen: set[tuple[str, str]] = set()

    user_inputs = [entry["payload"].get("text", "") for entry in trace if entry.get("type") == "user_input"]
    final_assistant = _final_assistant_content(trace)
    tool_sequence = [
        entry["payload"].get("tool_name", "")
        for entry in trace
        if entry.get("type") == "tool_execution" and entry["payload"].get("tool_name")
    ]

    if user_inputs and final_assistant:
        summary = {
            "content": (
                f"Session summary: user asked '{_truncate(user_inputs[0], 90)}'; "
                f"outcome: {_truncate(final_assistant, 120)}"
            ),
            "type": "summary",
            "importance": 6,
        }
        if _is_useful_candidate(summary):
            candidates.append(summary)
            seen.add(_candidate_key(summary))

    compressed_tools = _compress_tool_sequence(tool_sequence)
    workflow = {
        "content": f"Workflow used successfully: {' -> '.join(compressed_tools[:6])}",
        "type": "workflow",
        "importance": 5,
    }
    if compressed_tools and _is_useful_candidate(workflow):
        key = _candidate_key(workflow)
        if key not in seen:
            candidates.append(workflow)
            seen.add(key)

    last_error_by_tool: dict[str, str] = {}
    saw_success_after_error = False
    for entry in trace:
        if entry.get("type") != "tool_result":
            continue
        payload = entry.get("payload", {})
        tool_name = payload.get("tool_name", "tool")
        result_text = _truncate(payload.get("content", ""), 100)
        if payload.get("is_error"):
            last_error_by_tool[tool_name] = result_text
            continue
        if last_error_by_tool:
            saw_success_after_error = True
        if tool_name in last_error_by_tool:
            candidate = {
                "content": f"Recovered from {tool_name} failure after error: {last_error_by_tool.pop(tool_name)}",
                "type": "error_fix",
                "importance": 7,
            }
            key = _candidate_key(candidate)
            if key not in seen and _is_useful_candidate(candidate):
                candidates.append(candidate)
                seen.add(key)

    if saw_success_after_error:
        for tool_name, result_text in list(last_error_by_tool.items()):
            candidate = {
                "content": f"Recovered after {tool_name} error by changing approach: {result_text}",
                "type": "error_fix",
                "importance": 6,
            }
            key = _candidate_key(candidate)
            if key not in seen and _is_useful_candidate(candidate):
                candidates.append(candidate)
                seen.add(key)

    return candidates[:max_items]


def store_learning_candidates(
    candidates: list[dict],
    store_fn: Callable[[str, str, int], None],
) -> int:
    stored = 0
    for candidate in candidates:
        content = candidate.get("content", "").strip()
        if not content or not _is_useful_candidate(candidate):
            continue
        store_fn(content, candidate.get("type", "fact"), int(candidate.get("importance", 5)))
        stored += 1
    return stored


def consolidate_memory_entries(existing_entries: list[dict], new_candidates: list[dict]) -> dict:
    delete_ids: list[int] = []
    kept_by_key: dict[tuple[str, str], dict] = {}

    for entry in existing_entries:
        candidate_like = {
            "content": entry.get("content", ""),
            "type": entry.get("type", "fact"),
            "importance": int(entry.get("importance", 5)),
        }
        if not _is_useful_candidate(candidate_like):
            if entry.get("id") is not None:
                delete_ids.append(entry["id"])
            continue

        key = _candidate_key(candidate_like)
        current = kept_by_key.get(key)
        if current is None:
            kept_by_key[key] = entry
            continue

        current_importance = int(current.get("importance", 5))
        entry_importance = int(entry.get("importance", 5))
        current_id = current.get("id", 10**12)
        entry_id = entry.get("id", 10**12)

        if entry_importance > current_importance or (entry_importance == current_importance and entry_id < current_id):
            if current.get("id") is not None:
                delete_ids.append(current["id"])
            kept_by_key[key] = entry
        elif entry.get("id") is not None:
            delete_ids.append(entry["id"])

    add_candidates: list[dict] = []
    for candidate in new_candidates:
        if not _is_useful_candidate(candidate):
            continue
        key = _candidate_key(candidate)
        if key in kept_by_key:
            continue
        if any(_candidate_key(existing) == key for existing in add_candidates):
            continue
        add_candidates.append(candidate)

    return {
        "delete_ids": sorted(set(delete_ids)),
        "add_candidates": add_candidates,
    }


def collect_session_learning_candidates(session_db, cwd: str, session_limit: int = 50) -> list[SessionLearningSummary]:
    summaries: list[SessionLearningSummary] = []
    for session in session_db.list_sessions(cwd=cwd, limit=session_limit):
        if getattr(session, "trace_count", 0) <= 0:
            continue
        trace = session_db.load_trace(session.id)
        candidates = derive_learning_candidates(trace)
        if candidates:
            summaries.append(SessionLearningSummary(session_id=session.id, candidates=candidates))
    return summaries


def list_memory_entries(memory_backend, namespace: str, limit: int = 200) -> list[dict]:
    entries = []
    for item in memory_backend.list(namespace=namespace, limit=limit) or []:
        entries.append(
            {
                "id": item.id,
                "content": item.content,
                "type": item.memory_type.value,
                "importance": item.importance,
            }
        )
    return entries


def run_memory_consolidation(session_db, memory_backend, cwd: str, session_limit: int = 50, memory_limit: int = 200) -> dict:
    namespace = _get_namespace(cwd)
    existing_entries = list_memory_entries(memory_backend, namespace=namespace, limit=memory_limit)
    session_summaries = collect_session_learning_candidates(session_db, cwd=cwd, session_limit=session_limit)
    new_candidates = [candidate for summary in session_summaries for candidate in summary.candidates]
    plan = consolidate_memory_entries(existing_entries, new_candidates)

    for memory_id in plan["delete_ids"]:
        memory_backend.delete(memory_id)

    stored_count = store_learning_candidates(
        plan["add_candidates"],
        lambda content, mem_type, importance: memory_backend.store(
            content,
            type=mem_type,
            importance=importance,
            namespace=namespace,
        ),
    )

    return {
        "namespace": namespace,
        "sessions_considered": len(session_summaries),
        "deleted_count": len(plan["delete_ids"]),
        "stored_count": stored_count,
        "added_candidates": plan["add_candidates"],
    }
