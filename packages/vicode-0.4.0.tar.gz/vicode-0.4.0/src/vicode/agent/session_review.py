"""Session friction analysis for /review command.

Goal: surface points where the agent struggled — bad tool usage, unclear
reasoning, error loops — so tool prompts and harness behavior can be improved.
"""

from __future__ import annotations

import datetime
from dataclasses import dataclass, field


# ---------------------------------------------------------------------------
# Hedge language detection
# ---------------------------------------------------------------------------

_HEDGE_PHRASES = (
    "let me try", "i'll try", "i will try", "let me attempt",
    "i'll attempt", "maybe i should", "maybe i'll", "perhaps i should",
    "not sure", "i'm not sure", "unclear", "it seems", "it might",
    "alternatively", "or perhaps", "or maybe", "i could also",
    "i'll start with", "let me first", "i'll check", "let me check",
    "let me see", "i'm going to try", "let me look",
)

_CONFUSION_PHRASES = (
    "i don't know", "i cannot determine", "i'm unable",
    "i couldn't find", "failed to", "couldn't", "not found",
    "doesn't exist", "no such file", "permission denied",
)

def _hedge_score(text: str) -> float:
    """0.0–1.0 indicating how much hedging/uncertainty is in the text."""
    if not text:
        return 0.0
    norm = " ".join(text.lower().split())
    hits = sum(1 for p in _HEDGE_PHRASES if p in norm)
    confusion = sum(1 for p in _CONFUSION_PHRASES if p in norm)
    return min(1.0, (hits * 0.25 + confusion * 0.4))


# ---------------------------------------------------------------------------
# Data structures
# ---------------------------------------------------------------------------

@dataclass
class ToolCall:
    name: str
    args: dict
    start_ts: float
    end_ts: float
    duration: float
    is_error: bool
    content: str          # full result/error content
    iteration: int | None
    tool_call_id: str | None


@dataclass
class AgentStep:
    """One iteration of the agent loop within a turn."""
    iteration: int
    reasoning: str        # assistant content before tool calls (may be empty)
    hedge_score: float    # 0–1, how uncertain the reasoning sounds
    tool_calls: list[ToolCall] = field(default_factory=list)


@dataclass
class Turn:
    turn_num: int
    user_text: str
    start_ts: float
    steps: list[AgentStep] = field(default_factory=list)

    @property
    def all_tool_calls(self) -> list[ToolCall]:
        return [tc for step in self.steps for tc in step.tool_calls]


@dataclass
class FrictionPoint:
    severity: str    # "high" | "medium" | "low"
    category: str    # "tool_error" | "loop" | "bad_args" | "confusion" | "slow" | "stream" | "subagent"
    summary: str
    detail: str
    ts: float
    turn_num: int | None = None


@dataclass
class ToolStat:
    name: str
    calls: int = 0
    errors: int = 0
    total_s: float = 0.0
    max_s: float = 0.0

    @property
    def avg_s(self) -> float:
        return self.total_s / self.calls if self.calls else 0.0


@dataclass
class SessionReview:
    total_duration_s: float
    turns: list[Turn]
    tool_stats: dict[str, ToolStat]
    friction: list[FrictionPoint]
    outcome: str           # "success" | "probable success" | "incomplete" | "problematic" | "unknown"
    files_touched: list[str]
    total_tool_calls: int
    total_errors: int


# ---------------------------------------------------------------------------
# Core analysis
# ---------------------------------------------------------------------------

def analyze_session(trace_events: list[dict]) -> SessionReview:
    """
    Parse raw trace events into a structured SessionReview with friction points.
    """
    if not trace_events:
        return SessionReview(0, [], {}, [], "unknown", [], 0, 0)

    # --- Pass 1: pair tool_execution with tool_result by tool_call_id ---
    pending: dict[str, dict] = {}    # tool_call_id -> exec event
    paired: dict[str, ToolCall] = {} # tool_call_id -> ToolCall

    for event in trace_events:
        etype = event["type"]
        p = event["payload"]
        ts = event["created_at"]

        if etype == "tool_execution":
            tcid = p.get("tool_call_id") or f"_anon_{len(pending)}"
            pending[tcid] = {"payload": p, "ts": ts}

        elif etype == "tool_result":
            tcid = p.get("tool_call_id")
            exec_info = pending.pop(tcid, None)
            if exec_info is None:
                # Fallback: match by tool name (FIFO)
                for k, v in list(pending.items()):
                    if v["payload"]["tool_name"] == p["tool_name"]:
                        exec_info = v
                        pending.pop(k)
                        break

            duration = (ts - exec_info["ts"]) if exec_info else 0.0
            exec_p = exec_info["payload"] if exec_info else {}
            start_ts = exec_info["ts"] if exec_info else ts

            paired[tcid or f"_r_{len(paired)}"] = ToolCall(
                name=p["tool_name"],
                args=exec_p.get("args", {}),
                start_ts=start_ts,
                end_ts=ts,
                duration=duration,
                is_error=p.get("is_error", False),
                content=p.get("content", ""),
                iteration=p.get("iteration"),
                tool_call_id=tcid,
            )

    # --- Pass 2: group events into turns and steps ---
    turns: list[Turn] = []
    current_turn: Turn | None = None
    # Map iteration -> step within current turn
    current_steps: dict[int, AgentStep] = {}

    # We need to consume paired tool calls in order — use a list ordered by start_ts
    paired_ordered = sorted(paired.values(), key=lambda tc: tc.start_ts)
    paired_iter = iter(paired_ordered)
    next_tool = next(paired_iter, None)

    for event in trace_events:
        etype = event["type"]
        p = event["payload"]
        ts = event["created_at"]

        if etype == "user_input":
            current_turn = Turn(
                turn_num=len(turns) + 1,
                user_text=p.get("text", ""),
                start_ts=ts,
            )
            turns.append(current_turn)
            current_steps = {}

        elif etype == "assistant_message" and current_turn is not None:
            iteration = p.get("iteration", len(current_steps))
            content = p.get("content") or ""
            step = AgentStep(
                iteration=iteration,
                reasoning=content,
                hedge_score=_hedge_score(content),
            )
            current_steps[iteration] = step
            current_turn.steps.append(step)

        elif etype == "tool_execution" and current_turn is not None:
            # Consume matching paired tool call
            iteration = p.get("iteration", 0)
            tcid = p.get("tool_call_id")
            tc = paired.get(tcid) if tcid else None
            if tc is None and next_tool is not None:
                tc = next_tool
                next_tool = next(paired_iter, None)
            if tc is not None:
                step = current_steps.get(iteration)
                if step is None:
                    step = AgentStep(iteration=iteration, reasoning="", hedge_score=0.0)
                    current_steps[iteration] = step
                    if current_turn:
                        current_turn.steps.append(step)
                step.tool_calls.append(tc)

    # --- Pass 3: build tool stats ---
    tool_stats: dict[str, ToolStat] = {}
    for turn in turns:
        for tc in turn.all_tool_calls:
            if tc.name not in tool_stats:
                tool_stats[tc.name] = ToolStat(name=tc.name)
            s = tool_stats[tc.name]
            s.calls += 1
            s.total_s += tc.duration
            s.max_s = max(s.max_s, tc.duration)
            if tc.is_error:
                s.errors += 1

    total_tool_calls = sum(s.calls for s in tool_stats.values())
    total_errors = sum(s.errors for s in tool_stats.values())

    # --- Pass 4: detect friction ---
    friction: list[FrictionPoint] = []
    all_tools: list[tuple[int, ToolCall]] = [
        (turn.turn_num, tc)
        for turn in turns
        for tc in turn.all_tool_calls
    ]

    # 4a. Tool errors
    for turn_num, tc in all_tools:
        if tc.is_error:
            detail = tc.content[:250].strip()
            friction.append(FrictionPoint(
                severity="medium",
                category="tool_error",
                summary=f"{tc.name} returned an error",
                detail=detail,
                ts=tc.end_ts,
                turn_num=turn_num,
            ))

    # 4b. Error-then-retry loops (same tool, error then success/error again)
    for i in range(len(all_tools) - 1):
        tn_a, tc_a = all_tools[i]
        tn_b, tc_b = all_tools[i + 1]
        if tc_a.is_error and tc_b.name == tc_a.name:
            recovery_s = tc_b.end_ts - tc_a.end_ts
            recovered = "recovered" if not tc_b.is_error else "failed again"
            friction.append(FrictionPoint(
                severity="medium" if not tc_b.is_error else "high",
                category="loop",
                summary=f"{tc_a.name} failed → retried ({_fmt_s(recovery_s)} later, {recovered})",
                detail=tc_a.content[:200].strip(),
                ts=tc_a.end_ts,
                turn_num=tn_a,
            ))

    # 4c. Repeated identical call (same tool + same key arg, consecutive, no error between)
    for i in range(len(all_tools) - 1):
        _, tc_a = all_tools[i]
        _, tc_b = all_tools[i + 1]
        if tc_a.name == tc_b.name and not tc_a.is_error:
            key_a = _key_arg(tc_a.name, tc_a.args)
            key_b = _key_arg(tc_b.name, tc_b.args)
            if key_a and key_a == key_b:
                friction.append(FrictionPoint(
                    severity="high",
                    category="loop",
                    summary=f"{tc_a.name} called twice with the same args — possible loop",
                    detail=f"arg: {key_a}",
                    ts=tc_b.start_ts,
                    turn_num=None,
                ))

    # 4d. Write immediately followed by edit on same file (bad planning)
    for i in range(len(all_tools) - 1):
        _, tc_a = all_tools[i]
        _, tc_b = all_tools[i + 1]
        if tc_a.name == "file_write" and tc_b.name == "file_edit":
            path_a = tc_a.args.get("file_path", "")
            path_b = tc_b.args.get("file_path", "")
            if path_a and path_a == path_b:
                friction.append(FrictionPoint(
                    severity="medium",
                    category="bad_args",
                    summary=f"file_write then immediate file_edit on same file — agent didn't plan content upfront",
                    detail=f"file: {path_a}",
                    ts=tc_b.start_ts,
                    turn_num=None,
                ))

    # 4e. Multiple reads of the same file (redundant reads)
    read_counts: dict[str, int] = {}
    for _, tc in all_tools:
        if tc.name == "file_read":
            path = tc.args.get("file_path", "")
            if path:
                read_counts[path] = read_counts.get(path, 0) + 1
    for path, count in read_counts.items():
        if count >= 3:
            friction.append(FrictionPoint(
                severity="medium",
                category="loop",
                summary=f"file_read called {count}× on the same file — agent may not be retaining context",
                detail=f"file: {path}",
                ts=0,
                turn_num=None,
            ))

    # 4f. Slow tools (>15s)
    for turn_num, tc in all_tools:
        if tc.duration > 15 and not tc.is_error:
            size_hint = f"~{len(tc.content) // 4} tokens" if tc.content else ""
            friction.append(FrictionPoint(
                severity="low",
                category="slow",
                summary=f"{tc.name} took {tc.duration:.0f}s {size_hint}",
                detail=_args_preview(tc.name, tc.args),
                ts=tc.end_ts,
                turn_num=turn_num,
            ))

    # 4g. Confused/hedging reasoning before tool call
    for turn in turns:
        for step in turn.steps:
            if step.hedge_score >= 0.5 and step.tool_calls:
                tool_names = ", ".join(tc.name for tc in step.tool_calls)
                excerpt = step.reasoning[:200].replace("\n", " ").strip()
                friction.append(FrictionPoint(
                    severity="medium",
                    category="confusion",
                    summary=f"Agent expressed uncertainty before calling {tool_names}",
                    detail=f'"{excerpt}"',
                    ts=step.tool_calls[0].start_ts,
                    turn_num=turn.turn_num,
                ))

    # 4h. Long reasoning with NO tool call (over-explaining, stalling)
    for turn in turns:
        for step in turn.steps:
            if not step.tool_calls and len(step.reasoning) > 400:
                excerpt = step.reasoning[:180].replace("\n", " ").strip()
                friction.append(FrictionPoint(
                    severity="low",
                    category="confusion",
                    summary=f"Agent wrote {len(step.reasoning)} chars without calling any tool",
                    detail=f'"{excerpt}…"',
                    ts=turn.start_ts,
                    turn_num=turn.turn_num,
                ))

    # 4i. JSON/arg repair events
    for event in trace_events:
        if event["type"] == "error":
            msg = event["payload"].get("message", "")
            if "repaired" in msg.lower() or "malformed" in msg.lower():
                friction.append(FrictionPoint(
                    severity="high",
                    category="bad_args",
                    summary="Tool call JSON was malformed and needed repair",
                    detail=msg,
                    ts=event["created_at"],
                    turn_num=None,
                ))
            elif event["payload"].get("phase") == "stream":
                friction.append(FrictionPoint(
                    severity="high",
                    category="stream",
                    summary="LLM stream was interrupted",
                    detail=msg[:200],
                    ts=event["created_at"],
                    turn_num=None,
                ))
            elif "max iterations" in msg.lower():
                friction.append(FrictionPoint(
                    severity="high",
                    category="loop",
                    summary="Hit max iterations limit — task was not completed",
                    detail=msg,
                    ts=event["created_at"],
                    turn_num=None,
                ))

    # 4j. Subagent failures (orchestrate tool error results)
    for _, tc in all_tools:
        if tc.name == "orchestrate" and tc.is_error:
            friction.append(FrictionPoint(
                severity="high",
                category="subagent",
                summary="Subagent orchestration failed",
                detail=tc.content[:250],
                ts=tc.end_ts,
                turn_num=None,
            ))

    # --- Outcome ---
    outcome = _infer_outcome(trace_events, total_errors, total_tool_calls, friction)

    # --- Files touched ---
    files_seen: list[str] = []
    file_tools = {"file_write", "file_edit", "file_read", "file_delete"}
    for _, tc in all_tools:
        if tc.name in file_tools:
            path = tc.args.get("file_path", "")
            if path and path not in files_seen:
                files_seen.append(path)

    total_duration = trace_events[-1]["created_at"] - trace_events[0]["created_at"]

    # Sort friction by timestamp (zeros last)
    friction.sort(key=lambda f: (f.ts == 0, f.ts))

    return SessionReview(
        total_duration_s=total_duration,
        turns=turns,
        tool_stats=tool_stats,
        friction=friction,
        outcome=outcome,
        files_touched=files_seen,
        total_tool_calls=total_tool_calls,
        total_errors=total_errors,
    )


def _infer_outcome(trace_events, total_errors, total_tool_calls, friction) -> str:
    has_max_iter = any(fp.category == "loop" and "max iterations" in fp.summary for fp in friction)
    if has_max_iter:
        return "incomplete"

    # Check final assistant message
    final_content = ""
    for ev in reversed(trace_events):
        if ev["type"] == "assistant_message":
            final_content = (ev["payload"].get("content") or "").lower().strip()
            if final_content:
                break

    fail_phrases = ("failed to", "couldn't", "not able to", "unable to", "i cannot", "doesn't work")
    success_phrases = ("done", "complete", "finished", "created", "updated", "written", "fixed", "added")

    if any(p in final_content for p in fail_phrases):
        return "failure"
    if total_errors == 0 and total_tool_calls > 0:
        return "success"
    if any(p in final_content for p in success_phrases):
        return "probable success"
    if total_errors > total_tool_calls // 2 and total_tool_calls > 0:
        return "problematic"
    return "unknown"


def _key_arg(tool_name: str, args: dict) -> str | None:
    """Return the main identifying arg for a tool (for loop detection)."""
    for key in ("file_path", "command", "query", "pattern", "path", "url"):
        if key in args:
            return str(args[key])[:120]
    return None


def _args_preview(tool_name: str, args: dict) -> str:
    """Short human-readable summary of tool args."""
    if tool_name in ("file_read", "file_write", "file_edit", "file_delete"):
        return args.get("file_path", "")
    if tool_name == "bash":
        cmd = args.get("command", "")
        return cmd[:80] + ("…" if len(cmd) > 80 else "")
    if tool_name in ("grep", "glob_search"):
        return args.get("pattern", args.get("query", ""))[:60]
    if tool_name == "web_search":
        return args.get("query", "")[:60]
    # Generic: first string value
    for v in args.values():
        if isinstance(v, str):
            return v[:60]
    return str(args)[:60]


def _fmt_s(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    return f"{int(seconds // 60)}m {int(seconds % 60)}s"


def _fmt_duration(seconds: float) -> str:
    if seconds < 60:
        return f"{seconds:.0f}s"
    m = int(seconds // 60)
    s = int(seconds % 60)
    return f"{m}m {s}s"


# ---------------------------------------------------------------------------
# Formatter for TUI display
# ---------------------------------------------------------------------------

_SEV_ICON = {"high": "✖", "medium": "▲", "low": "·"}
_CAT_LABEL = {
    "tool_error": "tool error",
    "loop":       "loop/retry",
    "bad_args":   "bad args",
    "confusion":  "uncertainty",
    "slow":       "slow",
    "stream":     "stream error",
    "subagent":   "subagent",
}


def format_review(session_info, review: SessionReview) -> list[str]:
    """Return lines to print via chat.add_system()."""
    lines: list[str] = []
    push = lines.append

    # ── Header ──────────────────────────────────────────────────────────────
    import datetime
    created = datetime.datetime.fromtimestamp(session_info.created_at).strftime("%Y-%m-%d %H:%M")
    push("")
    push(f"  Session #{session_info.id} · {session_info.title or '(untitled)'}")
    push(f"  {created}  ·  {_fmt_duration(review.total_duration_s)}  ·  {session_info.model}")
    push(f"  {len(review.turns)} turn(s)  ·  {review.total_tool_calls} tool calls  ·  {review.total_errors} error(s)  ·  {review.outcome}")
    if review.files_touched:
        push(f"  Files: {', '.join(review.files_touched[:8])}")

    # ── Timeline ─────────────────────────────────────────────────────────────
    push("")
    push("  ── Timeline ──────────────────────────────────────")
    origin_ts = review.turns[0].start_ts if review.turns else 0

    for turn in review.turns:
        elapsed = _fmt_s(turn.start_ts - origin_ts)
        user_snippet = turn.user_text[:80].replace("\n", " ")
        push(f"  [{elapsed:>6}] Turn {turn.turn_num}: {user_snippet}")

        for step in turn.steps:
            # Show reasoning hedge if notable
            if step.reasoning and step.hedge_score >= 0.4:
                snippet = step.reasoning[:100].replace("\n", " ")
                push(f"           ? {snippet}…")

            for tc in step.tool_calls:
                icon = "✗" if tc.is_error else "✓"
                dur = f"  {tc.duration:.1f}s" if tc.duration >= 0.3 else ""
                arg = _args_preview(tc.name, tc.args)
                push(f"           {icon} {tc.name:<16} {arg[:35]:<35}{dur}")
                if tc.is_error:
                    err = tc.content[:120].replace("\n", " ")
                    push(f"             ↳ {err}")

    # ── Friction ─────────────────────────────────────────────────────────────
    if review.friction:
        push("")
        push("  ── Friction points ───────────────────────────────")
        for fp in review.friction:
            icon = _SEV_ICON.get(fp.severity, "·")
            label = _CAT_LABEL.get(fp.category, fp.category)
            turn_hint = f"  [turn {fp.turn_num}]" if fp.turn_num else ""
            push(f"  {icon} [{label}]{turn_hint}  {fp.summary}")
            if fp.detail:
                detail = fp.detail[:140].replace("\n", " ")
                push(f"    ↳ {detail}")
    else:
        push("")
        push("  ── No friction detected ──────────────────────────")

    # ── Tool stats ───────────────────────────────────────────────────────────
    push("")
    push("  ── Tool stats ────────────────────────────────────")
    for stat in sorted(review.tool_stats.values(), key=lambda s: -s.calls):
        err_str = f"  {stat.errors}✗" if stat.errors else "    "
        avg_str = f"  avg {stat.avg_s:.1f}s" if stat.avg_s >= 0.3 else ""
        max_str = f"  max {stat.max_s:.1f}s" if stat.max_s >= 1.0 else ""
        push(f"    {stat.name:<18} ×{stat.calls}{err_str}{avg_str}{max_str}")

    push("")
    return lines
