"""Auto-compaction - summarizes middle history when approaching context limit.

Strategy: keep system + first 5 user turns + summary + last 5 turns.
Uses a dedicated sub-agent to generate the summary.
"""

from vicode.config import Config
from vicode.llm.client import LLMClient

# Threshold: compact when estimated tokens exceed this fraction of context_limit
COMPACT_THRESHOLD = 0.85

# Turns to preserve at start and end
KEEP_START = 5  # first N user/assistant turns after system prompt
KEEP_END = 5    # last N user/assistant turns


def _count_turns(messages: list[dict]) -> list[int]:
    """Return indices where user messages start (user-turn boundaries)."""
    turns = []
    for i, m in enumerate(messages):
        if m.get("role") == "user":
            turns.append(i)
    return turns


def _count_groups(messages: list[dict]) -> list[int]:
    """Return indices of "general turn" boundaries.

    A general turn starts at every `user` OR `assistant` message. `tool`
    messages belong to the preceding assistant group (not a boundary), so an
    assistant with tool_calls + its tool results stay together when we slice.
    This matches user intuition better than counting only user messages —
    a single user request can spawn dozens of assistant/tool iterations, and
    those iterations should be compactable individually.
    """
    boundaries = []
    for i, m in enumerate(messages):
        role = m.get("role")
        if role == "user" or role == "assistant":
            boundaries.append(i)
    return boundaries


def needs_compaction(messages: list[dict], context_limit: int) -> bool:
    """Check if the history needs compaction."""
    total_chars = 0
    for m in messages:
        total_chars += len(str(m.get("content", "")))
        for tc in m.get("tool_calls", []):
            fn = tc.get("function", {})
            total_chars += len(fn.get("name", "")) + len(fn.get("arguments", ""))
    estimated_tokens = int(total_chars / 3.5)
    return estimated_tokens > (context_limit * COMPACT_THRESHOLD)


def compact_history(messages: list[dict], config: Config) -> list[dict] | None:
    """Compact the message history by summarizing the middle section.

    Uses "general turns" (user OR assistant boundaries) so a single user
    request that spawned many assistant/tool iterations can still be
    compacted by slicing between those iterations.

    Returns new messages list, or None if compaction not possible/needed.
    Structure: [system, first_5_groups..., summary_turn, last_5_groups...]
    """
    # Find general-turn boundaries (user or assistant starts; tool results
    # stay with their preceding assistant message).
    turn_starts = _count_groups(messages)
    if len(turn_starts) <= KEEP_START + KEEP_END + 1:
        return None  # Not enough turns to compact

    # Find message index boundaries
    # System prompt is messages[0]
    system = messages[0] if messages and messages[0].get("role") == "system" else None
    after_system = 1 if system else 0

    # First KEEP_START groups: from after system to start of group KEEP_START+1
    if len(turn_starts) <= KEEP_START:
        return None
    keep_start_end = turn_starts[KEEP_START]

    # Last KEEP_END groups
    if len(turn_starts) <= KEEP_END:
        return None
    keep_end_start = turn_starts[-KEEP_END]

    # Middle section to summarize
    middle = messages[keep_start_end:keep_end_start]
    if not middle:
        return None

    # Generate summary using a lightweight LLM call
    summary_text = _generate_summary(middle, config)
    if not summary_text:
        return None

    # Build new history
    new_messages = []
    if system:
        new_messages.append(system)
    # First turns
    new_messages.extend(messages[after_system:keep_start_end])
    # Summary as a user+assistant pair
    new_messages.append({
        "role": "user",
        "content": "[CONTEXT SUMMARY - The following is a summary of the conversation between these turns]",
    })
    new_messages.append({
        "role": "assistant",
        "content": summary_text,
    })
    # Last turns
    new_messages.extend(messages[keep_end_start:])

    return new_messages


_RICH_SUMMARY_SYSTEM = (
    "You are a technical context summarizer for an AI coding agent. Your summary replaces "
    "the original messages in working memory — preserve everything needed to continue working.\n\n"
    "Produce this exact markdown structure:\n\n"
    "## Task & Goal\n"
    "What the user asked and the overall objective.\n\n"
    "## Files Modified or Created\n"
    "Full path + one-line description per file. Format: `path/to/file.py` — description.\n\n"
    "## Files Read (key content recovered)\n"
    "Path + important class/function/constant names recovered. "
    "Format: `path/to/file.py` — Foo, bar, BAZ.\n\n"
    "## Functions and Classes Created or Modified\n"
    "`ClassName.method` in `path/to/file.py`. List every definition touched.\n\n"
    "## Tool Calls Summary\n"
    "Significant tool calls (bash, file ops, errors). Omit trivial reads. Format: tool: outcome.\n\n"
    "## Key Decisions and Reasoning\n"
    "Bullet list of architectural choices, approaches tried/rejected, explicit decisions.\n\n"
    "## Errors and Recoveries\n"
    "Errors encountered and resolution. Mark unresolved ones clearly.\n\n"
    "## State at End of Segment\n"
    "One paragraph: what is done, what remains, is the code in a working state.\n\n"
    "Be precise. Use actual names, paths, error messages — never vague descriptions."
)


def _generate_rich_summary(middle_messages: list[dict], config: Config) -> str | None:
    """Generate a rich structured summary for turn-based compaction."""
    import re as _re
    lines = []
    for m in middle_messages:
        role = m.get("role", "")
        if role == "user":
            content = str(m.get("content", ""))
            lines.append(f"[USER]\n{content[:500]}\n")
        elif role == "assistant":
            content = m.get("content", "")
            if content:
                lines.append(f"[ASSISTANT REASONING]\n{content[:400]}\n")
            for tc in m.get("tool_calls", []):
                fn = tc.get("function", {})
                name = fn.get("name", "")
                args = fn.get("arguments", "")
                if name in ("file_write", "file_edit", "file_read", "file_delete"):
                    fp_match = _re.search(r'"file_path"\s*:\s*"([^"]+)"', args)
                    fp = fp_match.group(1) if fp_match else args[:60]
                    lines.append(f"[TOOL CALL] {name}({fp})\n")
                else:
                    lines.append(f"[TOOL CALL] {name}({args[:150]})\n")
        elif role == "tool":
            content = str(m.get("content", ""))
            lines.append(f"[TOOL RESULT]\n{content[:400]}\n")

    conversation_text = "\n".join(lines)
    if len(conversation_text) > 8000:
        conversation_text = (
            conversation_text[:4000]
            + "\n\n[... truncated ...]\n\n"
            + conversation_text[-4000:]
        )

    try:
        client = LLMClient(config)
        msgs = [
            {"role": "system", "content": _RICH_SUMMARY_SYSTEM},
            {"role": "user", "content": conversation_text},
        ]
        if hasattr(client._impl, "client"):
            response = client._impl.client.chat.completions.create(
                model=config.model,
                messages=msgs,
                max_tokens=2000,
                # Use the project temperature — hardcoded 0.0 deadlocks
                # thinking-mode models (Qwen 3.6 etc.) which need >= 0.6.
                temperature=getattr(config, "temperature", 0.6) or 0.6,
                stream=False,
            )
            return response.choices[0].message.content.strip()
        else:
            parts = []
            for event in client.stream(msgs):
                if event.get("type") == "content_delta":
                    parts.append(event["text"])
            return "".join(parts).strip()
    except Exception as e:
        # Surface so iter_compact_skipped trace shows the real reason instead
        # of swallowing the failure as just "summary_generation_failed".
        import sys
        print(
            f"[compactor] rich summary failed: {type(e).__name__}: {e}",
            file=sys.stderr,
            flush=True,
        )
        return None


def compact_history_by_turns(
    messages: list[dict],
    config: Config,
    keep_last: int = 5,
) -> list[dict] | None:
    """Compact history proactively based on general-turn count.

    Structure: [system] + [first general turn] + [rich summary of middle groups] + [last `keep_last` groups]
    Returns new messages list, or None if not enough groups to compact.
    """
    turn_starts = _count_groups(messages)
    # Need: turn1 + at least 1 middle turn + keep_last turns
    min_turns = 1 + 1 + keep_last
    if len(turn_starts) <= min_turns:
        return None

    system = messages[0] if messages and messages[0].get("role") == "system" else None

    turn1_start = turn_starts[0]
    turn1_end = turn_starts[1]
    last_start = turn_starts[-keep_last]

    turn1_messages = messages[turn1_start:turn1_end]
    middle = messages[turn1_end:last_start]
    last_messages = messages[last_start:]

    if not middle:
        return None

    summary_text = _generate_rich_summary(middle, config)
    if not summary_text:
        return None

    new_messages = []
    if system:
        new_messages.append(system)
    new_messages.extend(turn1_messages)
    new_messages.append({
        "role": "user",
        "content": "[AUTO-COMPACT SUMMARY — middle turns summarized to preserve context window]",
    })
    new_messages.append({
        "role": "assistant",
        "content": summary_text,
    })
    new_messages.extend(last_messages)
    return new_messages


def _last_keep_split_index(messages: list[dict], keep_last_msgs: int) -> int:
    """Return index i such that messages[i:] are the last messages to keep,
    adjusted backwards so we don't split an assistant(tool_calls)+tool(results)
    group. Never leaves a bare `tool` message at the head of last_messages.
    """
    i = max(1, len(messages) - keep_last_msgs)
    # Walk backward while messages[i] is a tool result — it must stay paired
    # with the assistant message that issued the tool_call.
    while i > 1 and messages[i].get("role") == "tool":
        i -= 1
    return i


def compact_history_halves(
    messages: list[dict],
    config: Config,
    keep_last_msgs: int = 8,
) -> list[dict] | None:
    """Aggressive fallback used when a single summary still exceeds the
    context window or when everything is one long user-turn with many
    assistant/tool iterations.

    Splits the middle block of messages (after system + first user, before
    the last `keep_last_msgs` messages) in two halves, summarizes each
    independently (each summary call sees ~half the tokens), then stitches:

        [system]
        [first user message, verbatim]
        [user: marker] [assistant: summary of first half]
        [user: marker] [assistant: summary of second half]
        [last `keep_last_msgs` messages, verbatim]

    Operates on raw messages (not user-turn boundaries) so it also works when
    a single user request produces dozens of assistant/tool iterations.
    Returns None if there aren't enough messages to split meaningfully.
    """
    if not messages:
        return None

    system = messages[0] if messages[0].get("role") == "system" else None
    start = 1 if system else 0

    # Find first user message
    first_user_idx = None
    for i in range(start, len(messages)):
        if messages[i].get("role") == "user":
            first_user_idx = i
            break
    if first_user_idx is None:
        return None

    # Block to consider for splitting: everything after the first user message
    body_start = first_user_idx + 1
    body = messages[body_start:]
    # Need at least keep_last_msgs + 4 to have a non-trivial middle to halve.
    if len(body) < keep_last_msgs + 4:
        return None

    # Separate the tail we keep verbatim (don't break assistant/tool pairs).
    last_cut = _last_keep_split_index(messages, keep_last_msgs)
    if last_cut <= body_start:
        return None
    last_messages = messages[last_cut:]

    middle = messages[body_start:last_cut]
    if len(middle) < 4:
        return None

    # Pick a midpoint that does not split an assistant(tool_calls)+tool group.
    mid = len(middle) // 2
    while 0 < mid < len(middle) and middle[mid].get("role") == "tool":
        mid -= 1
    if mid <= 0 or mid >= len(middle):
        return None
    first_half = middle[:mid]
    second_half = middle[mid:]
    if not first_half or not second_half:
        return None

    summary_1 = _generate_rich_summary(first_half, config)
    if not summary_1:
        return None
    summary_2 = _generate_rich_summary(second_half, config)
    if not summary_2:
        return None

    new_messages: list[dict] = []
    if system:
        new_messages.append(system)
    new_messages.append(messages[first_user_idx])
    new_messages.append({
        "role": "user",
        "content": "[AUTO-COMPACT SUMMARY — first half of intermediate work]",
    })
    new_messages.append({"role": "assistant", "content": summary_1})
    new_messages.append({
        "role": "user",
        "content": "[AUTO-COMPACT SUMMARY — second half of intermediate work]",
    })
    new_messages.append({"role": "assistant", "content": summary_2})
    new_messages.extend(last_messages)
    return new_messages


def _generate_summary(middle_messages: list[dict], config: Config) -> str | None:
    """Use the LLM to summarize the middle section of conversation."""
    # Build a compact representation of what happened
    lines = []
    for m in middle_messages:
        role = m.get("role", "")
        if role == "user":
            content = m.get("content", "")[:200]
            lines.append(f"User: {content}")
        elif role == "assistant":
            content = m.get("content", "")
            if content:
                lines.append(f"Assistant: {content[:200]}")
            for tc in m.get("tool_calls", []):
                fn = tc.get("function", {})
                lines.append(f"Tool call: {fn.get('name', '')}({fn.get('arguments', '')[:100]})")
        elif role == "tool":
            content = m.get("content", "")[:150]
            lines.append(f"Tool result: {content}")

    conversation_text = "\n".join(lines)
    # Cap at ~4000 chars to avoid huge summary prompts
    if len(conversation_text) > 4000:
        conversation_text = conversation_text[:2000] + "\n...\n" + conversation_text[-2000:]

    try:
        client = LLMClient(config)
        # Use non-streaming for speed
        if hasattr(client._impl, 'client'):
            # OpenAI SDK client
            response = client._impl.client.chat.completions.create(
                model=config.model,
                messages=[
                    {"role": "system", "content": (
                        "Summarize this conversation excerpt in structured markdown. "
                        "Include: what was asked, what files were modified, what tools were used, "
                        "key decisions made, and current state. Be concise but complete."
                    )},
                    {"role": "user", "content": conversation_text},
                ],
                max_tokens=1024,
                temperature=getattr(config, "temperature", 0.6) or 0.6,
                stream=False,
            )
            return response.choices[0].message.content.strip()
        else:
            # Codex client - use streaming and collect
            summary_parts = []
            msgs = [
                {"role": "system", "content": (
                    "Summarize this conversation excerpt in structured markdown. "
                    "Include: what was asked, what files were modified, what tools were used, "
                    "key decisions made, and current state. Be concise but complete."
                )},
                {"role": "user", "content": conversation_text},
            ]
            for event in client.stream(msgs):
                if event.get("type") == "content_delta":
                    summary_parts.append(event["text"])
            return "".join(summary_parts).strip()
    except Exception as e:
        import sys
        print(
            f"[compactor] basic summary failed: {type(e).__name__}: {e}",
            file=sys.stderr,
            flush=True,
        )
        return None
