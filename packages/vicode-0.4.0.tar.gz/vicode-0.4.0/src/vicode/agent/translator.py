"""Translator agent for language detection and translation."""

import re
from dataclasses import dataclass, field


LANGUAGE_PATTERNS = {
    "es": [
        r"\b(el|la|los|las|un|una|unos|unas|de|que|en|con|por|para|como|esta|este|esto|estoy|tengo|hacer|cuando|cual|donde|quien|porque|pero|como esta)\b",
        r"[áéíóúñü]+",
    ],
    "en": [
        r"\b(the|a|an|is|are|was|were|have|has|had|do|does|did|will|would|could|should|may|might|must|can|this|that|these|those|i|you|he|she|it|we|they|what|where|when|who|why|how)\b",
    ],
    "fr": [
        r"\b(le|la|les|un|une|des|de|du|au|est|sont|etait|etaient|avoir|etre|faire|vous|je|tu|il|elle|nous|ils|elles|qui|que|ou|comme|pour|donc)\b",
        r"[àèéêëîïôùûüç]+",
    ],
    "de": [
        r"\b(der|die|das|ein|eine|ist|sind|war|waren|haben|sein|werden|kann|koennte|muss|musste|soll|ich|du|er|sie|es|wir|ihr|was|wer|wie|wo|warum)\b",
        r"[äöüß]+",
    ],
    "pt": [
        r"\b(o|a|os|as|um|uma|de|que|em|com|por|para|como|esta|este|eu|voce|ele|ela|nos|eles|elas|fazer|tem|sao)\b",
        r"[ãõç]+",
    ],
}


def detect_language(text: str) -> str:
    """Detect language from text using simple heuristics."""
    if not text or len(text.strip()) < 3:
        return "en"

    text_lower = text.lower()
    scores = {}

    for lang, patterns in LANGUAGE_PATTERNS.items():
        score = 0
        for pattern in patterns:
            matches = len(re.findall(pattern, text_lower, re.IGNORECASE))
            score += matches
        if score > 0:
            scores[lang] = score

    if not scores:
        return "en"

    detected = max(scores, key=scores.get)
    return detected if scores[detected] >= 2 else "en"


def translate_to_english(text: str, source_lang: str) -> str:
    """Simple translation to English.

    For now, this is a pass-through. In production, you'd integrate
    with a translation LLM or API. The formatting is the key value here.
    """
    if source_lang == "en":
        return text

    return f"[Translated from {source_lang}]: {text}"


@dataclass
class TranslatorAgent:
    """Agent for detecting and translating user messages."""

    user_language: str = "en"
    _context_hints: list[str] = field(default_factory=list)
    _conversation_state: dict = field(default_factory=dict)

    def detect_and_translate(self, user_input: str) -> str:
        """Main entry point: detect language and translate user message."""
        detected = detect_language(user_input)

        if detected != self.user_language and detected != "en":
            self.user_language = detected

        translated = translate_to_english(user_input, self.user_language)

        return self._format_message(
            original=user_input,
            detected_lang=detected,
            translated=translated,
        )

    def _format_message(
        self, original: str, detected_lang: str, translated: str
    ) -> str:
        """Format message following Qwen prompting guide (XML tags)."""
        intent = self._extract_intent(original)

        context_block = ""
        if self._context_hints:
            context_block = f"""<context_hints>
{chr(10).join(f"- {hint}" for hint in self._context_hints[-3:])}
</context_hints>"""

        return f"""<user_message>
<original_language>{detected_lang}</original_language>
<detected_intent>{intent}</detected_intent>
<translated_content>
{translated}
</translated_content>
{context_block}
</user_message>"""

    def _extract_intent(self, text: str) -> str:
        """Extract simple intent from user text."""
        text_lower = text.lower()

        intents = [
            ("create", ["crear", "new", "añadir", "add", "crear"]),
            ("edit", ["editar", "modificar", "cambiar", "change", "modify"]),
            ("read", ["leer", "read", "ver", "show", "buscar", "search"]),
            ("delete", ["borrar", "eliminar", "delete", "remove"]),
            ("run", ["ejecutar", "run", "ejecutar", "ejecuta"]),
            ("explain", ["explicar", "explain", "qué", "what", "cómo", "how"]),
            ("help", ["ayuda", "help", "ayudarme"]),
        ]

        for intent, keywords in intents:
            for kw in keywords:
                if kw in text_lower:
                    return intent

        return "general"

    def set_language(self, lang: str):
        """Manually set user language."""
        if lang in LANGUAGE_PATTERNS:
            self.user_language = lang

    def add_context_hint(self, hint: str):
        """Add a context hint for future translations."""
        self._context_hints.append(hint)
        if len(self._context_hints) > 10:
            self._context_hints = self._context_hints[-10:]

    def get_user_language(self) -> str:
        """Get current user language."""
        return self.user_language

    def build_summary_prompt(self, history: list[dict], summary_lang: str) -> str:
        """Build prompt for summarizer in user's language."""
        return f"""Summarize the conversation in {summary_lang}. Focus on:
- What was accomplished
- Files modified
- Any errors or issues

Conversation:
{self._format_history_for_summary(history)}

Provide a concise summary (2-3 sentences)."""

    def _format_history_for_summary(self, history: list[dict]) -> str:
        """Format history for summarizer."""
        lines = []
        for msg in history[-20:]:
            role = msg.get("role", "unknown")
            content = msg.get("content", "")
            if content:
                lines.append(f"{role}: {content[:200]}")
            tool_calls = msg.get("tool_calls", [])
            for tc in tool_calls:
                fn = tc.get("function", {})
                name = fn.get("name", "unknown")
                lines.append(f"{role}: [tool call] {name}")
        return "\n".join(lines)
