"""Session analysis for detecting issues and improvement areas."""

from dataclasses import dataclass, field


@dataclass
class SessionIssue:
    """A detected issue in the session."""

    severity: str  # "high", "medium", "low"
    category: str  # "loop", "uncertainty", "error", "timeout", "retry"
    description: str
    detail: str
    turn: int | None = None


@dataclass
class SessionAnalysis:
    """Analysis of a session."""

    session_id: int
    total_turns: int
    total_tool_calls: int
    total_errors: int
    issues: list[SessionIssue] = field(default_factory=list)
    tool_breakdown: dict[str, int] = field(default_factory=dict)
    duration_seconds: float | None = None

    @property
    def quality_score(self) -> float:
        """Calculate quality score 0-100."""
        if self.total_tool_calls == 0:
            return 50.0

        error_rate = self.total_errors / self.total_tool_calls
        loop_count = sum(1 for i in self.issues if i.category == "loop")
        uncertainty_count = sum(1 for i in self.issues if i.category == "uncertainty")

        score = 100.0
        score -= error_rate * 30
        score -= loop_count * 10
        score -= uncertainty_count * 5
        return max(0.0, min(100.0, score))


_UNCERTAINTY_PHRASES = (
    "let me try",
    "i'll try",
    "i will try",
    "maybe",
    "perhaps",
    "not sure",
    "unclear",
    "it seems",
    "i don't know",
    "i cannot",
)


def analyze_session(session_id: int, trace_events: list[dict]) -> SessionAnalysis:
    """Analyze a session for issues."""
    if not trace_events:
        return SessionAnalysis(session_id, 0, 0, 0, [])

    turns = 0
    tool_calls = 0
    errors = 0
    issues = []
    tool_breakdown: dict[str, int] = {}

    tool_history: list[tuple[str, str]] = []
    last_tool = None

    for event in trace_events:
        etype = event.get("type", "")
        payload = event.get("payload", {})

        if etype == "user_input":
            turns += 1

        elif etype == "tool_execution":
            tool_calls += 1
            name = payload.get("tool_name", "")
            tool_breakdown[name] = tool_breakdown.get(name, 0) + 1
            args = str(payload.get("args", {}))

            if last_tool == (name, args):
                issues.append(
                    SessionIssue(
                        severity="medium",
                        category="loop",
                        description=f"Repeated tool call: {name}",
                        detail=f"Same args: {args[:50]}",
                        turn=turns,
                    )
                )
            tool_history.append((name, args))
            last_tool = (name, args)

        elif etype == "tool_result":
            is_error = payload.get("is_error", False)
            if is_error:
                errors += 1
                issues.append(
                    SessionIssue(
                        severity="medium",
                        category="error",
                        description=f"Tool error: {payload.get('tool_name', 'unknown')}",
                        detail=(payload.get("content") or "")[:100],
                        turn=turns,
                    )
                )

        elif etype == "assistant_message":
            content = payload.get("content") or ""
            if any(phrase in content.lower() for phrase in _UNCERTAINTY_PHRASES):
                issues.append(
                    SessionIssue(
                        severity="low",
                        category="uncertainty",
                        description="Uncertain reasoning detected",
                        detail=content[:80],
                        turn=turns,
                    )
                )

    return SessionAnalysis(
        session_id=session_id,
        total_turns=turns,
        total_tool_calls=tool_calls,
        total_errors=errors,
        issues=issues,
        tool_breakdown=tool_breakdown,
    )


def format_analysis(analysis: SessionAnalysis) -> str:
    """Format analysis for display."""
    header = f"Turns: {analysis.total_turns} | Tools: {analysis.total_tool_calls} | Errors: {analysis.total_errors}"
    if analysis.duration_seconds is not None:
        header += f" | Duration: {analysis.duration_seconds:.1f}s"

    lines = [
        f"Session Analysis #{analysis.session_id}",
        header,
        f"Quality Score: {analysis.quality_score:.0f}/100",
    ]

    if analysis.tool_breakdown:
        items = sorted(analysis.tool_breakdown.items(), key=lambda x: -x[1])
        breakdown = ", ".join(f"{name}={count}" for name, count in items)
        lines.append(f"Tools used: {breakdown}")

    if analysis.issues:
        lines.append("\nIssues detected:")
        for issue in analysis.issues[:10]:
            icon = {"high": "✖", "medium": "▲", "low": "·"}[issue.severity]
            lines.append(f"  {icon} [{issue.category}] {issue.description}")
            if issue.turn:
                lines.append(f"      Turn {issue.turn}")

    return "\n".join(lines)
