"""Core agent loop - the brain of Vicode."""

import json
import re
from typing import Generator

from vicode.config import Config
from vicode.llm.client import LLMClient
from vicode.llm.streaming import iter_stream
from vicode.agent.messages import MessageHistory
from vicode.agent.prompt import build_system_prompt
from vicode.agent.translator import TranslatorAgent
from vicode.tools.base import ToolRegistry, ToolResult


def try_repair_json(raw: str, tool_name: str) -> dict | None:
    """Attempt to extract arguments from malformed JSON tool calls.

    Common failure: the model generates a huge 'content' string that gets
    truncated, leaving the JSON without a closing quote/brace.
    """
    if tool_name == "file_write":
        # Try to extract file_path and content from broken JSON
        fp_match = re.search(r'"file_path"\s*:\s*"((?:[^"\\]|\\.)*)"', raw)
        ct_match = re.search(r'"content"\s*:\s*"((?:[^"\\]|\\.)*)', raw)
        if fp_match and ct_match:
            file_path = fp_match.group(1)
            # Content may be truncated - take whatever we got
            content = ct_match.group(1)
            # Unescape JSON string escapes
            try:
                content = json.loads(f'"{content}"')
            except json.JSONDecodeError:
                content = (
                    content.replace("\\n", "\n")
                    .replace("\\t", "\t")
                    .replace('\\"', '"')
                    .replace("\\\\", "\\")
                )
            return {"file_path": file_path, "content": content}

    elif tool_name == "file_edit":
        fp_match = re.search(r'"file_path"\s*:\s*"((?:[^"\\]|\\.)*)"', raw)
        old_match = re.search(r'"old_string"\s*:\s*"((?:[^"\\]|\\.)*)"', raw)
        new_match = re.search(r'"new_string"\s*:\s*"((?:[^"\\]|\\.)*)', raw)
        if fp_match and old_match and new_match:
            try:
                return {
                    "file_path": json.loads(f'"{fp_match.group(1)}"'),
                    "old_string": json.loads(f'"{old_match.group(1)}"'),
                    "new_string": json.loads(f'"{new_match.group(1)}"'),
                }
            except json.JSONDecodeError:
                pass

    elif tool_name == "bash":
        cmd_match = re.search(r'"command"\s*:\s*"((?:[^"\\]|\\.)*)', raw)
        if cmd_match:
            try:
                return {"command": json.loads(f'"{cmd_match.group(1)}"')}
            except json.JSONDecodeError:
                cmd = (
                    cmd_match.group(1)
                    .replace("\\n", "\n")
                    .replace('\\"', '"')
                    .replace("\\\\", "\\")
                )
                return {"command": cmd}

    return None


class AgentLoop:
    def __init__(
        self,
        config: Config,
        tools: ToolRegistry,
        system_prompt: str | None = None,
        supervisor=None,
        trace_recorder=None,
        translator: TranslatorAgent | None = None,
    ):
        self.config = config
        self.client = LLMClient(config)
        self.tools = tools
        self.supervisor = supervisor  # SupervisorChain or None
        self.trace_recorder = trace_recorder
        # Expose recorder to tools so sub-agent tools can spawn child recorders
        # and persist their inner loops under the same session.
        if trace_recorder is not None and hasattr(tools, "set_trace_recorder"):
            tools.set_trace_recorder(trace_recorder)
        self.translator = translator or TranslatorAgent()
        self.history = MessageHistory()
        self.history.set_system(system_prompt or build_system_prompt(config))
        self._input_queue: list[str] = []  # Queue for inputs while agent is busy
        self._turn_count: int = 0  # User turn counter (excludes internal calls)

    def set_trace_recorder(self, trace_recorder):
        self.trace_recorder = trace_recorder

    def queue_input(self, text: str) -> bool:
        """Add input to queue if agent is busy. Returns True if queued."""
        self._input_queue.append(text)
        return True

    def get_queued_input(self) -> str | None:
        """Get next queued input if available."""
        if self._input_queue:
            return self._input_queue.pop(0)
        return None

    def _get_plan_state(self):
        """Get plan state from task tracker supervisor if available."""
        if self.supervisor:
            for sup in getattr(self.supervisor, "supervisors", []):
                if hasattr(sup, "plan_state"):
                    return sup.plan_state
        return None

    def run(
        self, user_input: str, _internal: bool = False
    ) -> Generator[dict, None, None]:
        """Run agent loop for a user message. Yields events.

        _internal=True skips turn counting and auto-compaction (used for supervisor
        continuation rounds and manual /compact calls).
        """
        if not _internal:
            translated = self.translator.detect_and_translate(user_input)
            self.history.add_user(translated)
        else:
            self.history.add_user(user_input)

        if self.trace_recorder and not _internal:
            self.trace_recorder.on_user_input(user_input)

        if not _internal:
            self._turn_count += 1
            # Turn-based auto-compact
            if (
                self.config.auto_compact_every > 0
                and self._turn_count > 1
                and self._turn_count % self.config.auto_compact_every == 0
            ):
                from vicode.agent.compactor import compact_history_by_turns

                yield {"type": "supervisor_checking", "tool": "auto-compacting history"}
                compacted = compact_history_by_turns(
                    self.history.get_messages(),
                    self.config,
                    keep_last=self.config.auto_compact_keep_last,
                )
                if compacted:
                    self.history.messages = compacted
                    if self.trace_recorder:
                        self.trace_recorder.on_system_event(
                            "turn_compact",
                            {
                                "turn": self._turn_count,
                                "tokens": self.history.estimate_tokens(),
                            },
                        )
                    yield {
                        "type": "error",
                        "message": f"Auto-compacted at turn {self._turn_count} (~{self.history.estimate_tokens()} tokens)",
                    }

        consecutive_errors = 0
        MAX_CONSECUTIVE_ERRORS = 3
        consecutive_unproductive = 0
        MAX_CONSECUTIVE_UNPRODUCTIVE = 3
        consecutive_parse_errors = 0
        MAX_CONSECUTIVE_PARSE_ERRORS = 4

        # Track token count for incremental updates
        last_token_count = 0

        for iteration in range(self.config.max_iterations):
            # "Pastoreo" — drain any user inputs that arrived while the agent
            # was working. Inject them as new user messages so the next LLM
            # round sees the clarification/redirection before deciding the
            # next tool call. This is what makes mid-flight steering feel
            # like Claude Code: the agent doesn't pause to wait for the user
            # but does pick up new instructions at the next turn boundary.
            while self._input_queue:
                queued = self._input_queue.pop(0)
                self.history.add_user(queued)
                if self.trace_recorder:
                    self.trace_recorder.on_user_input(queued)
                yield {"type": "queued_input_consumed", "text": queued}

            # Iteration-based proactive compaction.
            # `_turn_count` only counts external user inputs (1 in -p mode), so
            # the original turn-based compactor never triggered in single-prompt
            # runs. This iteration counter ensures we compact periodically even
            # within a single user request, which is when the agent loop runs
            # the most aggressively (dozens of model round-trips).
            if (
                self.config.auto_compact_every > 0
                and iteration > 0
                and iteration % self.config.auto_compact_every == 0
            ):
                from vicode.agent.compactor import (
                    compact_history_by_turns,
                    _count_groups,
                )

                msgs = self.history.get_messages()
                before = self.history.estimate_tokens()
                groups = len(_count_groups(msgs))
                compacted = compact_history_by_turns(
                    msgs,
                    self.config,
                    keep_last=self.config.auto_compact_keep_last,
                )
                if compacted:
                    self.history.messages = compacted
                    after = self.history.estimate_tokens()
                    if self.trace_recorder:
                        self.trace_recorder.on_system_event(
                            "iter_compact",
                            {
                                "iteration": iteration,
                                "tokens_before": before,
                                "tokens_after": after,
                            },
                        )
                    yield {
                        "type": "error",
                        "message": (
                            f"Auto-compacted at iter {iteration}: "
                            f"{before} → {after} tokens"
                        ),
                    }
                else:
                    # Diagnostic: compaction was due but didn't happen.
                    # Common causes:
                    #   - too few groups to keep + summarise (need >7)
                    #   - rich_summary LLM call failed silently
                    if self.trace_recorder:
                        self.trace_recorder.on_system_event(
                            "iter_compact_skipped",
                            {
                                "iteration": iteration,
                                "tokens": before,
                                "groups": groups,
                                "reason": (
                                    "not_enough_groups"
                                    if groups <= 1 + 1 + self.config.auto_compact_keep_last
                                    else "summary_generation_failed"
                                ),
                            },
                        )

            # Auto-compact if approaching context limit
            from vicode.agent.compactor import needs_compaction, compact_history

            if needs_compaction(self.history.get_messages(), self.config.context_limit):
                yield {"type": "supervisor_checking", "tool": "compacting context"}
                compacted = compact_history(self.history.get_messages(), self.config)
                if compacted:
                    self.history.messages = compacted
                    if self.trace_recorder:
                        self.trace_recorder.on_system_event(
                            "context_compacted",
                            {
                                "tokens": self.history.estimate_tokens(),
                                "iteration": iteration,
                            },
                        )
                    yield {
                        "type": "error",
                        "message": f"Context compacted to ~{self.history.estimate_tokens()} tokens",
                    }

            tool_defs = self.tools.to_openai_tools()
            # Register tool names with the embedded-call parser so it can
            # recognise Gemma 4-style `<tool_name>...</tool_name>` blocks
            # when the chat template doesn't surface them as structured
            # tool_calls. Cheap to set every iteration.
            try:
                from vicode.llm.tool_call_parser import set_known_tool_names
                set_known_tool_names(t["function"]["name"] for t in tool_defs)
            except Exception:
                pass

            try:
                stream = self.client.stream(self.history.get_messages(), tool_defs)
                # Successful request setup — reset parse-error counter so a
                # single good response breaks any prior bad streak.
                consecutive_parse_errors = 0
            except Exception as e:
                err_msg = str(e)
                err_lower = err_msg.lower()
                if "parse" in err_lower and (
                    "json" in err_lower or "tool" in err_lower
                ):
                    consecutive_parse_errors += 1
                    # Bail out if the model keeps producing malformed tool
                    # calls — continuing the loop just burns tokens and time.
                    if consecutive_parse_errors >= MAX_CONSECUTIVE_PARSE_ERRORS:
                        final_msg = (
                            f"Aborting: {consecutive_parse_errors} consecutive "
                            f"malformed tool calls. The model cannot produce "
                            f"valid JSON — try a different model, simpler prompt, "
                            f"or shorter context."
                        )
                        if self.trace_recorder:
                            self.trace_recorder.on_error(
                                final_msg, phase="request", iteration=iteration
                            )
                        yield {"type": "error", "message": final_msg}
                        return
                    if self.trace_recorder:
                        self.trace_recorder.on_error(
                            "Server failed to parse tool call. Retrying...",
                            phase="request",
                            iteration=iteration,
                        )
                    yield {
                        "type": "error",
                        "message": (
                            f"Server failed to parse tool call "
                            f"({consecutive_parse_errors}/{MAX_CONSECUTIVE_PARSE_ERRORS}). "
                            f"Retrying..."
                        ),
                    }
                    self.history.add_assistant(
                        content="Tool call failed due to JSON parsing error."
                    )
                    self.history.add_user(
                        "The previous tool call JSON was malformed. "
                        "Please try again. If writing a large file, split it into smaller parts "
                        "or write a shorter version first."
                    )
                    continue
                # Context window exceeded — llama-server returns
                # "exceed_context_size_error" / "exceeds the available context
                # size". Try the halves-fallback compactor (each half is
                # summarized separately so the summary prompt itself fits),
                # then retry the stream. Only try this once per request.
                if "context" in err_lower and (
                    "exceed" in err_lower or "too many tokens" in err_lower
                ):
                    from vicode.agent.compactor import compact_history_halves

                    yield {
                        "type": "supervisor_checking",
                        "tool": "hierarchical context compaction",
                    }
                    compacted = compact_history_halves(
                        self.history.get_messages(), self.config
                    )
                    if compacted:
                        self.history.messages = compacted
                        if self.trace_recorder:
                            self.trace_recorder.on_system_event(
                                "context_compacted_halves",
                                {
                                    "tokens": self.history.estimate_tokens(),
                                    "iteration": iteration,
                                },
                            )
                        yield {
                            "type": "error",
                            "message": (
                                f"Context exceeded — compacted to ~"
                                f"{self.history.estimate_tokens()} tokens via halves fallback"
                            ),
                        }
                        continue
                    # If fallback couldn't compact, fall through to error.
                if self.trace_recorder:
                    self.trace_recorder.on_error(
                        f"LLM request failed: {e}", phase="request", iteration=iteration
                    )
                yield {"type": "error", "message": f"LLM request failed: {e}"}
                return

            # Collect response
            content_parts = []
            thinking_buffer: list[str] = []
            tool_calls_complete = []
            tool_calls_seen = set()
            finish_reason = None
            had_real_content = False  # content_delta (not just thinking)

            def _flush_thinking():
                """Wrap accumulated thinking in <think> tags and append to history.

                Qwen 3.6 (and similar) require prior-turn reasoning to be kept
                inside <think>...</think> blocks so the chat template can
                re-serialize them on the next turn when preserve_thinking=true.
                Without this, multi-turn conversations degrade (empty tool
                call args, loss of plan continuity).
                """
                if thinking_buffer:
                    content_parts.append(
                        "<think>" + "".join(thinking_buffer) + "</think>"
                    )
                    thinking_buffer.clear()

            try:
                for event in iter_stream(stream):
                    match event["type"]:
                        case "content_delta":
                            # Close any open thinking block before real content
                            _flush_thinking()
                            content_parts.append(event["text"])
                            had_real_content = True
                            yield event
                        case "thinking_delta":
                            # Buffer for history (will be wrapped in <think>);
                            # emit to UI for styled rendering.
                            thinking_buffer.append(event["text"])
                            yield event
                        case "content_done":
                            _flush_thinking()
                            yield event
                        case "tool_early":
                            # Early detection of tool call before arguments are complete
                            yield {
                                "type": "tool_early",
                                "name": event["name"],
                            }
                        case "tool_call_delta":
                            idx = event["index"]
                            if idx not in tool_calls_seen and event["name"]:
                                tool_calls_seen.add(idx)
                                yield {
                                    "type": "tool_start",
                                    "name": event["name"],
                                    "id": event["id"],
                                }
                            yield {
                                "type": "tool_args_delta",
                                "text": event["arguments"],
                            }
                        case "tool_call_done":
                            tool_calls_complete.append(event)
                        case "token_count":
                            yield event
                        case "finish":
                            # Flush any thinking that didn't get a trailing
                            # content block (e.g. stream ended while still
                            # inside <think> or reasoning_content).
                            _flush_thinking()
                            finish_reason = event["reason"]
                            # Stream finished cleanly → let the adaptive
                            # repeat-penalty decay back toward its floor.
                            try:
                                self.client.on_clean_completion()
                            except Exception:
                                pass
                            # Persist KV-cache reuse stats so we can analyse
                            # prefix-cache hit rate across the session.
                            usage = event.get("usage") or {}
                            if usage and self.trace_recorder:
                                cache_n = usage.get("cache_n")
                                prompt_n = usage.get("prompt_n")
                                cached_tokens = usage.get("cached_tokens")
                                # Either source is fine; record whatever we got.
                                if cache_n is not None or cached_tokens is not None:
                                    self.trace_recorder.on_system_event(
                                        "cache_stats",
                                        {
                                            "iteration": iteration,
                                            "cache_n": cache_n,
                                            "prompt_n": prompt_n,
                                            "cached_tokens": cached_tokens,
                                            "prompt_tokens": usage.get("prompt_tokens"),
                                        },
                                    )
            except Exception as stream_err:
                err_msg = str(stream_err)
                # If the stream was killed by our degenerate-loop guard, ramp
                # up the adaptive repeat_penalty so the next call has a
                # better chance. Other errors leave the penalty alone.
                if "degenerate loop" in err_msg.lower():
                    try:
                        new_pen = self.client.on_degenerate_loop()
                        if new_pen is not None and self.trace_recorder:
                            self.trace_recorder.on_system_event(
                                "repeat_penalty_bumped",
                                {"new_value": new_pen, "iteration": iteration},
                            )
                    except Exception:
                        pass
                # Server-side parse error (e.g. llama-server grammar constraint failure)
                # Preserve any partial thinking so the history is well-formed
                _flush_thinking()
                # Treat any partial content as the response and continue
                if content_parts:
                    if self.trace_recorder:
                        self.trace_recorder.on_error(
                            f"Stream interrupted: {err_msg}",
                            phase="stream",
                            iteration=iteration,
                        )
                    yield {"type": "error", "message": f"Stream interrupted: {err_msg}"}
                    yield {"type": "content_done"}
                else:
                    if self.trace_recorder:
                        self.trace_recorder.on_error(
                            f"Stream failed: {err_msg}",
                            phase="stream",
                            iteration=iteration,
                        )
                    yield {"type": "error", "message": f"Stream failed: {err_msg}"}
                    self.history.add_assistant(content=f"[Stream error: {err_msg}]")
                    self.history.add_user(
                        "The server returned a parse error. This usually means the output "
                        "didn't match the expected tool-call format. Please respond with plain "
                        "text only (no tool calls) and try a simpler approach."
                    )
                    continue

            # Build assistant message for history
            assistant_content = "".join(content_parts) if content_parts else None
            assistant_tool_calls = None

            # Some non-standard chat templates (certain Qwen 3.x builds, etc.)
            # emit tool calls as <tool_call>/<function=...> markup inside the
            # content stream instead of the OpenAI-structured tool_calls field.
            # Rescue those so the agent can still execute them.
            if not tool_calls_complete and assistant_content:
                from vicode.llm.tool_call_parser import (
                    has_embedded_tool_calls,
                    parse_embedded_tool_calls,
                    strip_tool_call_blocks,
                )

                if has_embedded_tool_calls(assistant_content):
                    embedded = parse_embedded_tool_calls(assistant_content)
                    if embedded:
                        tool_calls_complete = embedded
                        remaining = strip_tool_call_blocks(assistant_content)
                        assistant_content = remaining or None

            if tool_calls_complete:
                assistant_tool_calls = []
                for tc in tool_calls_complete:
                    assistant_tool_calls.append(
                        {
                            "id": tc["id"],
                            "type": "function",
                            "function": {
                                "name": tc["name"],
                                "arguments": tc["arguments"],
                            },
                        }
                    )

            self.history.add_assistant(
                content=assistant_content,
                tool_calls=assistant_tool_calls,
            )
            if self.trace_recorder:
                self.trace_recorder.on_assistant_message(
                    content=assistant_content,
                    tool_calls=assistant_tool_calls,
                    finish_reason=finish_reason,
                    iteration=iteration,
                )

            # If no tool calls, check if model needs to continue
            if not tool_calls_complete:
                if finish_reason == "needs_continue":
                    # Model described intent but didn't call a tool - nudge it
                    self.history.add_user(
                        "Continue. Use a tool call to do what you described. Do not explain, just act."
                    )
                    continue
                # Thinking models (Qwen 3.6, DeepSeek-R1, etc.) can get "stuck":
                #   - finish_reason=stop with only reasoning (no real content)
                #   - finish_reason=length hit mid-reasoning (needs continuation)
                #   - after a tool result, producing only thinking without acting
                # These are unproductive turns. Allow up to
                # MAX_CONSECUTIVE_UNPRODUCTIVE nudges before giving up, so we
                # don't loop forever on genuinely completed tasks.
                is_unproductive = (
                    not had_real_content
                    or finish_reason == "length"
                )
                if is_unproductive and consecutive_unproductive < MAX_CONSECUTIVE_UNPRODUCTIVE:
                    consecutive_unproductive += 1
                    if finish_reason == "length":
                        nudge = (
                            "Your previous response was cut off. Continue from where "
                            "you left off. Make the next tool call to progress the task."
                        )
                    else:
                        nudge = (
                            "Continue working on the task. If more exploration is needed, "
                            "call a read tool. If you have enough context, start making the "
                            "required edits with file_write/file_edit. Do not stop until the "
                            "task is complete."
                        )
                    self.history.add_user(nudge)
                    continue
                if self.trace_recorder:
                    self.trace_recorder.on_run_completed(iterations=iteration + 1)
                yield {"type": "done"}
                return
            # Reset counter when model produces tool calls
            consecutive_unproductive = 0

            # Execute tool calls and add results
            for tc in tool_calls_complete:
                name = tc["name"]
                raw_args = tc["arguments"] or ""

                # Parse arguments - try repair if malformed
                try:
                    args = json.loads(raw_args) if raw_args else {}
                except json.JSONDecodeError:
                    repaired = try_repair_json(raw_args, name)
                    if repaired:
                        args = repaired
                        yield {
                            "type": "error",
                            "message": f"Repaired truncated {name} call",
                        }
                    else:
                        error_msg = (
                            f"Tool call JSON was malformed and could not be repaired. "
                            f"Please try again with shorter content."
                        )
                        self.history.add_tool_result(tc["id"], error_msg)
                        if self.trace_recorder:
                            self.trace_recorder.on_error(
                                error_msg, phase="tool_args", iteration=iteration
                            )
                            self.trace_recorder.on_tool_result(
                                name,
                                error_msg,
                                is_error=True,
                                tool_call_id=tc["id"],
                                iteration=iteration,
                            )
                        yield {
                            "type": "tool_result",
                            "name": name,
                            "content": error_msg,
                            "is_error": True,
                        }
                        continue

                if self.trace_recorder:
                    self.trace_recorder.on_tool_execution(
                        name, args, tool_call_id=tc.get("id"), iteration=iteration
                    )
                yield {"type": "tool_executing", "name": name, "args": args}

                # Supervisor pre-execute check
                if self.supervisor:
                    plan_state = self._get_plan_state()
                    yield {"type": "supervisor_checking", "tool": name}
                    verdict = self.supervisor.pre_execute(
                        name, args, plan_state, self.history.get_messages()
                    )
                    for ev in verdict.events:
                        yield ev
                    if not verdict.approved:
                        msg = verdict.message or "Blocked by supervisor"
                        self.history.add_tool_result(tc["id"], msg)
                        if self.trace_recorder:
                            self.trace_recorder.on_tool_result(
                                name,
                                msg,
                                is_error=True,
                                tool_call_id=tc["id"],
                                iteration=iteration,
                            )
                        yield {
                            "type": "tool_result",
                            "name": name,
                            "content": msg,
                            "is_error": True,
                        }
                        continue

                result = self.tools.execute(name, args)

                # Supervisor post-execute
                if self.supervisor:
                    plan_state = self._get_plan_state()
                    post = self.supervisor.post_execute(
                        name, args, result, plan_state, self.history.get_messages()
                    )
                    for ev in post.events:
                        yield ev
                    if post.message:
                        result = ToolResult(
                            content=f"{post.message}\n\n{result.content}",
                            is_error=result.is_error,
                        )

                # Track consecutive errors to prevent infinite loops
                if result.is_error:
                    consecutive_errors += 1
                    if consecutive_errors >= MAX_CONSECUTIVE_ERRORS:
                        result = ToolResult(
                            content=f"{result.content}\n\n[SYSTEM: {consecutive_errors} consecutive errors. STOP repeating the same command. Try a completely different approach or ask the user for help.]",
                            is_error=True,
                        )
                else:
                    consecutive_errors = 0

                self.history.add_tool_result(tc["id"], result.content)
                if self.trace_recorder:
                    self.trace_recorder.on_tool_result(
                        name,
                        result.content,
                        is_error=result.is_error,
                        tool_call_id=tc["id"],
                        iteration=iteration,
                    )

                yield {
                    "type": "tool_result",
                    "name": name,
                    "content": result.content,
                    "is_error": result.is_error,
                }

                # Queued inputs are drained at the top of the next iteration
                # — see "Pastoreo" comment above.

        if self.trace_recorder:
            self.trace_recorder.on_error(
                f"Max iterations ({self.config.max_iterations}) reached",
                phase="run",
                iteration=self.config.max_iterations,
            )
            self.trace_recorder.on_run_completed(iterations=self.config.max_iterations)
        yield {
            "type": "error",
            "message": f"Max iterations ({self.config.max_iterations}) reached",
        }
        yield {"type": "done"}
