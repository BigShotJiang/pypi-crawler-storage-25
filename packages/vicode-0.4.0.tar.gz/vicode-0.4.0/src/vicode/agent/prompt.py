"""System prompt builder optimized for local LLMs."""

import datetime
import platform
from pathlib import Path
from vicode.config import Config


PROJECT_FILES = ["CLAUDE.md", "AGENT.md", "VICODE.md"]


def _load_project_instructions(cwd: str) -> str:
    """Load project instruction files from the working directory."""
    parts = []
    for name in PROJECT_FILES:
        path = Path(cwd) / name
        if path.is_file():
            try:
                content = path.read_text(encoding="utf-8", errors="replace").strip()
                if content:
                    parts.append(f"## {name}\n{content}")
            except OSError:
                pass
    return "\n\n".join(parts)


def _load_agent_file(agent_file: str) -> str:
    """Load agent persona/system prompt from --agent flag path."""
    if not agent_file:
        return ""
    path = Path(agent_file)
    if not path.is_file():
        return ""
    try:
        return path.read_text(encoding="utf-8", errors="replace").strip()
    except OSError:
        return ""


def build_system_prompt(config: Config) -> str:
    """Build the system prompt.

    Sections are ordered most-stable → least-stable to maximise llama-server's
    prefix KV-cache reuse. Anything that changes per-day (date), per-project
    (cwd, project files, skills) goes near the bottom so the long stable
    header stays cached across turns.
    """
    is_windows = platform.system() == "Windows"
    os_name = "Windows" if is_windows else "Linux/Mac"

    # ---- 1) Stable header (rules + workflow + code quality + tool behavior).
    # This block has no per-day or per-project values, so its tokens stay
    # identical between turns and across sessions → high cache hit rate.
    base = """You are a coding assistant. Use tools to explore and modify code.

## Critical rules
- Use relative paths for files. Never use hardcoded absolute paths like /testbed, /workspace, /home, etc.
- Bash commands run in the working directory. To run in a subdirectory, use bash(command="cd subdir && command").
- If a command fails, read the error and try a DIFFERENT approach. Never repeat the same failing command.
- After writing or editing code, verify it works (e.g. syntax check, run tests, lint).

## File-editing tools — prefer them over bash
- Use `file_read`, `file_write`, `file_edit` for ALL file work. They're safer, faster, and produce clean diffs.
- Do NOT use `bash` with `cat`, `sed`, `awk`, `echo > file`, `printf >> file`, etc. to read or modify files. Even one-liners that "look like a quick fix" cause:
  - encoding bugs (BOMs, CRLF on Windows)
  - silent partial writes when the shell quoting is off
  - retry loops because the model can't see what it actually wrote
- Reserve `bash` for: running tests, build commands, package managers, git, network calls, anything that produces output you need to read.
- If `file_edit` says `old_string not found`, re-read the file first instead of switching to `sed`.

## Workflow
- Read before editing. Understand existing code first.
- Make minimal, focused changes.
- Verify your work after each change.
- Keep responses concise. Show what you did, not what you plan to do.
- Use **bold** to highlight key terms and file names.

## Code quality
- Write clean, production-quality code. No placeholders, no hardcoded dummy values.
- Think through the logic before writing. Get it right the first time instead of iterating with trial-and-error.
- Tests should be isolated: each test sets up and tears down its own state.
- When tests fail, read the error carefully and fix the root cause.

## Memory
- If the user references context not in this conversation, check memory(action="search").
- Store useful learnings with memory(action="store") for future sessions.

## Tool Call Behavior
- Before a meaningful tool call, send one concise sentence describing the immediate action.
- Always do this before edits and verification commands.
- Skip it for routine reads, obvious follow-up searches, and repetitive low-signal tool calls.
- When you preface a tool call, make that tool call in the same turn.

## Act, don't ask (with one exception)
- Execute the task directly. Do NOT ask the user via plain text for confirmation, clarification, or approval.
- Never end a turn with only an explanation of what you plan to do. Plans must be followed by tool calls in the same turn.
- Never finish by asking "Would you like me to..." or "Should I..." in chat — just call a tool.

## When YOU genuinely need a decision: use `ask_user`
- If the request is ambiguous in a way that a wrong assumption would waste real work, OR you want to propose 2+ valid alternatives, OR you're about to do something destructive/irreversible — call the `ask_user` tool. It opens a structured form in the TUI with options the user can pick.
- Build the questionnaire with concrete choices. Each option can include a `description` and an optional `image` (markdown) to help the user decide. Always allow free-text unless the choice is strict.
- Do NOT use `ask_user` for trivial confirmations or yes/no decisions you can answer yourself with a sane default. It interrupts the user. Use it sparingly, only when an answer materially changes the plan."""

    # ---- 2) Available skills (changes only when user adds/removes skills).
    # Sorted alphabetically so the same skill set always renders identically.
    try:
        from vicode.skills import discover_skills
        skills = sorted(discover_skills(config.cwd), key=lambda s: s.name)
    except Exception:
        skills = []
    if skills:
        lines = ["", "## Available skills",
                 "These are task-specific instruction packs you can load on demand. "
                 "Each has a name + description. When a user request matches a skill's "
                 "purpose, call `load_skill(name=\"...\")` to fetch the full instructions "
                 "before acting. Do NOT guess at the body — load it.",
                 "<available_skills>"]
        for s in skills:
            scope = "project" if s.scope == "project" else "user"
            desc = s.description or "(no description)"
            lines.append(f"  - {s.name} [{scope}]: {desc}")
        lines.append("</available_skills>")
        base += "\n" + "\n".join(lines)

    # ---- 3) Project instructions (only changes when the user edits CLAUDE.md
    # /VICODE.md /AGENT.md). Stable for most of a session.
    project = _load_project_instructions(config.cwd)
    if project:
        base += f"\n\n{project}"

    # ---- 4) Volatile values last (cwd, OS, date). These rotate per-day or
    # per-project, so anything past this point is the cache "tail" — keep it
    # short and at the end so the long head above can keep being reused.
    base += f"""

## Environment
- Platform: {os_name}
- Working directory: {config.cwd}
- Bash hint: if "python" doesn't work, try "python3" or "py".
- Date: {datetime.date.today().isoformat()}"""

    agent = _load_agent_file(config.agent_file)
    if agent:
        base = agent + "\n\n---\n\n" + base

    return base
