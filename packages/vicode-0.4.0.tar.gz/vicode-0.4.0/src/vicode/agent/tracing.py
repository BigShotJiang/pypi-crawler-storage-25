"""Structured trace recording for agent sessions."""

from __future__ import annotations

from typing import Any

from vicode.db.sessions import SessionDB


class TraceRecorder:
    """Persist structured runtime traces for a session.

    Sub-agents (explore, plan, orchestrate sub-tasks) reuse the parent
    session_id but receive a `child(name)` recorder that tags every event
    with `subagent` so its inner loop is fully visible/debuggable in the
    same DB row stream as the parent. Events without `subagent` belong to
    the main loop.
    """

    def __init__(self, db: SessionDB, session_id: int, subagent: str | None = None):
        self.db = db
        self.session_id = session_id
        self.subagent = subagent

    def child(self, subagent: str) -> "TraceRecorder":
        """Return a recorder that tags events as belonging to a sub-agent."""
        # Allow nested sub-agents by chaining names: e.g. "orchestrate>explore".
        chained = f"{self.subagent}>{subagent}" if self.subagent else subagent
        return TraceRecorder(self.db, self.session_id, subagent=chained)

    def _record(self, event_type: str, payload: dict[str, Any]):
        if self.subagent:
            payload = {**payload, "subagent": self.subagent}
        self.db.add_trace_event(self.session_id, event_type, payload)

    def on_user_input(self, text: str):
        self._record("user_input", {"text": text})

    def on_assistant_message(
        self,
        *,
        content: str | None,
        tool_calls: list[dict] | None,
        finish_reason: str | None,
        iteration: int,
    ):
        self._record(
            "assistant_message",
            {
                "content": content,
                "tool_calls": tool_calls or [],
                "finish_reason": finish_reason,
                "iteration": iteration,
            },
        )

    def on_tool_execution(self, tool_name: str, args: dict, *, tool_call_id: str | None = None, iteration: int | None = None):
        self._record(
            "tool_execution",
            {
                "tool_name": tool_name,
                "args": args,
                "tool_call_id": tool_call_id,
                "iteration": iteration,
            },
        )

    def on_tool_result(
        self,
        tool_name: str,
        content: str,
        *,
        is_error: bool,
        tool_call_id: str | None = None,
        iteration: int | None = None,
    ):
        self._record(
            "tool_result",
            {
                "tool_name": tool_name,
                "content": content,
                "is_error": is_error,
                "tool_call_id": tool_call_id,
                "iteration": iteration,
            },
        )

    def on_error(self, message: str, *, phase: str | None = None, iteration: int | None = None):
        self._record(
            "error",
            {
                "message": message,
                "phase": phase,
                "iteration": iteration,
            },
        )

    def on_system_event(self, event_type: str, payload: dict[str, Any] | None = None):
        self._record(event_type, payload or {})

    def on_run_completed(self, *, iterations: int):
        self._record("run_completed", {"iterations": iterations})


def format_trace_entry(entry: dict) -> str:
    payload = entry.get("payload", {})
    etype = entry.get("type", "event")

    if etype == "user_input":
        return f"user: {payload.get('text', '')}"
    if etype == "assistant_message":
        content = payload.get("content") or ""
        tool_calls = payload.get("tool_calls") or []
        if tool_calls:
            names = ", ".join(tc.get("function", {}).get("name", "?") for tc in tool_calls)
            return f"assistant -> tools: {names}"
        return f"assistant: {content}"
    if etype == "tool_execution":
        return f"tool start: {payload.get('tool_name', '?')} {payload.get('args', {})}"
    if etype == "tool_result":
        status = "error" if payload.get("is_error") else "ok"
        return f"tool result [{status}]: {payload.get('tool_name', '?')}"
    if etype == "error":
        return f"error: {payload.get('message', '')}"
    if etype == "run_completed":
        return f"run completed ({payload.get('iterations', 0)} iterations)"
    return f"{etype}: {payload}"
