from dataclasses import dataclass, field
import os


@dataclass
class Config:
    provider: str = "local"
    server_url: str = "http://localhost:8080/v1"
    model: str = "auto"
    api_key: str = "not-needed"
    max_tokens: int = 81920
    context_limit: int = 131072
    max_iterations: int = 500
    temperature: float = 0.6
    top_p: float = 0.95
    top_k: int = 20
    presence_penalty: float = 0.0
    # llama.cpp's repeat_penalty: > 1.0 discourages token-level repetition.
    # Helps with degenerate-loop models (Gemma 4 Q3 etc.) without changing
    # behaviour for well-behaved ones at this conservative value.
    repeat_penalty: float = 1.1
    timeout: int = 300
    stream_read_timeout: float = 90.0
    skip_ssl_verify: bool = False
    cwd: str = field(default_factory=os.getcwd)
    agent_file: str = ""  # Path to agent persona/system prompt .md file (--agent flag)
    auto_compact_every: int = 20     # compact after every N user/general turns; 0 = disabled
    auto_compact_keep_last: int = 5  # number of recent turns to preserve after compaction
