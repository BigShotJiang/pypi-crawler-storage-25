"""Slash command system - built-in and custom commands."""

from dataclasses import dataclass
from pathlib import Path
from typing import Callable


@dataclass
class Command:
    name: str
    description: str
    handler: Callable | None = None  # None for prompt-based commands
    prompt_template: str = ""        # Template with $ARGUMENTS for custom commands
    source: str = "built-in"         # built-in, project, user


class CommandRegistry:
    """Registry of slash commands with discovery and autocomplete."""

    def __init__(self):
        self._commands: dict[str, Command] = {}

    def register(self, cmd: Command):
        self._commands[cmd.name] = cmd

    def get(self, name: str) -> Command | None:
        return self._commands.get(name)

    def match(self, prefix: str) -> list[Command]:
        """Fuzzy match commands for autocomplete."""
        if not prefix:
            return list(self._commands.values())
        prefix = prefix.lower()
        return [c for c in self._commands.values() if prefix in c.name.lower()]

    def list_all(self) -> list[Command]:
        return sorted(self._commands.values(), key=lambda c: c.name)

    def load_custom_commands(self, *dirs: str):
        """Load custom .md command files from directories."""
        for dir_path in dirs:
            path = Path(dir_path)
            if not path.is_dir():
                continue
            for md_file in sorted(path.glob("*.md")):
                cmd = _parse_command_file(md_file)
                if cmd:
                    self._commands[cmd.name] = cmd


def _parse_frontmatter(text: str) -> tuple[dict, str]:
    """Parse simple YAML-like frontmatter (key: value pairs)."""
    if not text.startswith("---"):
        return {}, text

    parts = text.split("---", 2)
    if len(parts) < 3:
        return {}, text

    meta = {}
    for line in parts[1].strip().splitlines():
        if ":" in line:
            key, _, val = line.partition(":")
            meta[key.strip()] = val.strip()

    return meta, parts[2].strip()


def _parse_command_file(path: Path) -> Command | None:
    """Parse a command .md file with optional frontmatter."""
    try:
        text = path.read_text(encoding="utf-8")
    except OSError:
        return None

    meta, body = _parse_frontmatter(text)

    return Command(
        name=path.stem,
        description=meta.get("description", path.stem.replace("-", " ").replace("_", " ")),
        prompt_template=body,
        source=str(path.parent),
    )
