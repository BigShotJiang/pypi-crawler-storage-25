"""Built-in slash commands."""

from pathlib import Path
from vicode.commands.base import Command, CommandRegistry


def register_builtins(registry: CommandRegistry):
    """Register all built-in commands."""

    registry.register(Command(
        name="help",
        description="Show available commands",
    ))

    registry.register(Command(
        name="clear",
        description="Clear chat history",
    ))

    registry.register(Command(
        name="compact",
        description="Compress conversation to save context",
    ))

    registry.register(Command(
        name="init",
        description="Create a VICODE.md project config in current directory",
    ))

    registry.register(Command(
        name="undo",
        description="Undo last file change",
    ))

    registry.register(Command(
        name="model",
        description="Show or change the current model (/model gpt-4o)",
    ))

    registry.register(Command(
        name="provider",
        description="Re-configure LLM provider (runs setup wizard)",
    ))

    registry.register(Command(
        name="status",
        description="Show session info: model, tokens, tools, cwd",
    ))

    registry.register(Command(
        name="memory",
        description="Show stored memories",
    ))

    registry.register(Command(
        name="resume",
        description="Resume a previous session (/resume or /resume <id>)",
    ))

    registry.register(Command(
        name="sessions",
        description="List recent sessions",
    ))

    registry.register(Command(
        name="usage",
        description="Show API usage and rate limits (Codex/OpenAI)",
    ))

    registry.register(Command(
        name="trace",
        description="Show saved trace events for the current or a previous session (/trace or /trace <id>)",
    ))

    registry.register(Command(
        name="learn",
        description="Extract learnings from a session trace and store them in memory (/learn or /learn <id>)",
    ))

    registry.register(Command(
        name="consolidate",
        description="Consolidate project memory: remove redundant/noisy items and ingest useful learnings from recent sessions",
    ))

    registry.register(Command(
        name="review",
        description="Friction analysis of a session: tool errors, loops, unclear reasoning (/review or /review <id>)",
    ))

    registry.register(Command(
        name="autocompact",
        description="Turn-based auto-compaction (/autocompact [on|off|every N keep M])",
    ))

    registry.register(Command(
        name="exit",
        description="Exit vicode",
    ))


def create_command_registry(cwd: str) -> CommandRegistry:
    """Create registry with builtins + custom commands + skills as commands."""
    registry = CommandRegistry()
    register_builtins(registry)

    # Load custom commands: project-local then user-global
    project_cmds = Path(cwd) / ".vicode" / "commands"
    user_cmds = Path.home() / ".vicode" / "commands"
    registry.load_custom_commands(str(project_cmds), str(user_cmds))

    # Skills become slash commands too. `/<skill-name>` injects the full
    # skill body; `/<skill-name> some extra text` appends that text after
    # the body so the user can add an inline instruction in the same turn.
    try:
        from vicode.skills import discover_skills
        for s in discover_skills(cwd):
            template = s.body or ""
            # Append user args (if any) after the skill body so the model
            # sees both. The Command system fills `$ARGUMENTS` for us.
            template_with_args = (
                f"{template}\n\n[User instruction]\n$ARGUMENTS" if template
                else "$ARGUMENTS"
            )
            registry.register(Command(
                name=s.name,
                description=(s.description or f"Skill: {s.name}")[:140],
                prompt_template=template_with_args,
                source=f"skill:{s.scope}",
            ))
    except Exception:
        pass

    return registry
