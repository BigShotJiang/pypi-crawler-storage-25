"""Tests for core modules: config, messages, compactor, sessions, commands, streaming."""

import json
import os
import tempfile
from pathlib import Path

from vicode.config import Config
from vicode.agent.messages import MessageHistory
from vicode.agent.prompt import build_system_prompt, _load_project_instructions
from vicode.agent.compactor import needs_compaction, _count_turns, COMPACT_THRESHOLD
from vicode.db.sessions import SessionDB
from vicode.agent.tracing import TraceRecorder
from vicode.agent.learning import derive_learning_candidates, consolidate_memory_entries, run_memory_consolidation
from vicode.commands.base import CommandRegistry, Command, _parse_frontmatter
from vicode.commands.builtins import create_command_registry
from vicode.llm.streaming import iter_stream


# --- Config ---

def test_config_defaults():
    c = Config()
    assert c.provider == "local"
    assert c.model == "auto"
    assert c.temperature == 0.0
    assert c.max_iterations == 500


def test_config_override():
    c = Config(provider="openai", model="gpt-4o", api_key="sk-test")
    assert c.provider == "openai"
    assert c.model == "gpt-4o"
    assert c.api_key == "sk-test"


# --- MessageHistory ---

def test_history_system_prompt():
    h = MessageHistory()
    h.set_system("test prompt")
    assert h.messages[0]["role"] == "system"
    assert h.messages[0]["content"] == "test prompt"
    h.set_system("updated")
    assert h.messages[0]["content"] == "updated"
    assert len(h.messages) == 1


def test_history_add_messages():
    h = MessageHistory()
    h.set_system("sys")
    h.add_user("hello")
    h.add_assistant(content="hi")
    h.add_assistant(tool_calls=[{"id": "1", "type": "function", "function": {"name": "bash", "arguments": "{}"}}])
    h.add_tool_result("1", "output")
    assert len(h.messages) == 5
    assert h.messages[1]["role"] == "user"
    assert h.messages[3]["tool_calls"][0]["function"]["name"] == "bash"
    assert h.messages[4]["role"] == "tool"


def test_history_estimate_tokens():
    h = MessageHistory()
    h.set_system("x" * 350)  # ~100 tokens
    tokens = h.estimate_tokens()
    assert 90 < tokens < 110


def test_history_estimate_includes_tool_calls():
    h = MessageHistory()
    h.add_assistant(tool_calls=[{"id": "1", "type": "function", "function": {"name": "bash", "arguments": '{"command":"ls"}'}}])
    tokens = h.estimate_tokens()
    assert tokens > 0


# --- Prompt ---

def test_build_system_prompt():
    c = Config(cwd="/test")
    prompt = build_system_prompt(c)
    assert "coding assistant" in prompt
    assert "/test" in prompt


def test_load_project_instructions():
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "VICODE.md").write_text("Use tabs not spaces")
        result = _load_project_instructions(tmp)
        assert "Use tabs not spaces" in result
        assert "VICODE.md" in result


def test_load_project_instructions_missing():
    with tempfile.TemporaryDirectory() as tmp:
        result = _load_project_instructions(tmp)
        assert result == ""


# --- Compactor ---

def test_needs_compaction():
    msgs = [{"role": "user", "content": "x" * 1000}]
    assert needs_compaction(msgs, 100)  # tiny limit
    assert not needs_compaction(msgs, 999999)  # huge limit


def test_count_turns():
    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "1"},
        {"role": "assistant", "content": "a"},
        {"role": "user", "content": "2"},
        {"role": "assistant", "content": "b"},
    ]
    turns = _count_turns(msgs)
    assert turns == [1, 3]  # indices of user messages


def test_compaction_not_needed_few_turns():
    from vicode.agent.compactor import compact_history
    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "hello"},
        {"role": "assistant", "content": "hi"},
    ]
    result = compact_history(msgs, Config())
    assert result is None  # not enough turns


# --- Sessions ---

def test_session_create_and_load():
    db = SessionDB()
    sid = db.create_session(cwd="/test", model="test-model", title="Test")
    assert sid > 0

    msgs = [
        {"role": "system", "content": "sys"},
        {"role": "user", "content": "hello"},
    ]
    db.save_messages(sid, msgs)
    loaded = db.load_messages(sid)
    assert len(loaded) == 2
    assert loaded[1]["content"] == "hello"

    db.delete_session(sid)
    assert db.get_session(sid) is None


def test_session_list():
    db = SessionDB()
    sid = db.create_session(cwd="/a", model="m")
    db.update_title(sid, "My Session")
    sessions = db.list_sessions()
    found = [s for s in sessions if s.id == sid]
    assert len(found) == 1
    assert found[0].title == "My Session"
    db.delete_session(sid)


def test_session_list_by_cwd():
    db = SessionDB()
    s1 = db.create_session(cwd="/project_a", model="m")
    s2 = db.create_session(cwd="/project_b", model="m")
    sessions_a = db.list_sessions(cwd="/project_a")
    assert all(s.cwd == "/project_a" for s in sessions_a)
    db.delete_session(s1)
    db.delete_session(s2)


def test_session_tool_calls_persistence():
    db = SessionDB()
    sid = db.create_session(cwd="/test", model="m")
    msgs = [
        {"role": "assistant", "tool_calls": [{"id": "1", "type": "function", "function": {"name": "bash", "arguments": "{}"}}]},
        {"role": "tool", "tool_call_id": "1", "content": "output"},
    ]
    db.save_messages(sid, msgs)
    loaded = db.load_messages(sid)
    assert loaded[0]["tool_calls"][0]["function"]["name"] == "bash"
    assert loaded[1]["tool_call_id"] == "1"
    db.delete_session(sid)


def test_session_trace_persistence_and_counts(tmp_path):
    db = SessionDB(db_path=tmp_path / "sessions.db")
    sid = db.create_session(cwd="/trace-project", model="trace-model")
    recorder = TraceRecorder(db, sid)

    recorder.on_user_input("inspect the repo")
    recorder.on_assistant_message(
        content="I will inspect it.",
        tool_calls=[{"id": "call_1", "type": "function", "function": {"name": "ls", "arguments": "{}"}}],
        finish_reason="tool_calls",
        iteration=0,
    )
    recorder.on_tool_execution("ls", {"path": "."}, tool_call_id="call_1", iteration=0)
    recorder.on_tool_result("ls", "src\ntests", is_error=False, tool_call_id="call_1", iteration=0)
    recorder.on_run_completed(iterations=1)

    trace = db.load_trace(sid)
    assert [entry["type"] for entry in trace] == [
        "user_input",
        "assistant_message",
        "tool_execution",
        "tool_result",
        "run_completed",
    ]
    assert trace[1]["payload"]["finish_reason"] == "tool_calls"
    assert trace[2]["payload"]["tool_name"] == "ls"
    assert trace[3]["payload"]["content"] == "src\ntests"
    assert trace[3]["payload"]["is_error"] is False

    session = db.get_session(sid)
    assert session is not None
    assert session.trace_count == 5
    assert any(s.id == sid and s.trace_count == 5 for s in db.list_sessions())

    db.delete_session(sid)
    db.close()


def test_derive_learning_candidates_from_trace():
    trace = [
        {"type": "user_input", "payload": {"text": "Find why parser crashes on empty files"}},
        {"type": "tool_execution", "payload": {"tool_name": "grep", "args": {"pattern": "parse"}}},
        {"type": "tool_result", "payload": {"tool_name": "grep", "content": "no matches", "is_error": True}},
        {"type": "tool_execution", "payload": {"tool_name": "file_read", "args": {"file_path": "parser.py"}}},
        {"type": "tool_result", "payload": {"tool_name": "file_read", "content": "def parse(data): ...", "is_error": False}},
        {"type": "tool_execution", "payload": {"tool_name": "file_edit", "args": {"file_path": "parser.py"}}},
        {"type": "tool_result", "payload": {"tool_name": "file_edit", "content": "updated parser.py", "is_error": False}},
        {"type": "assistant_message", "payload": {"content": "I fixed the empty-file parser crash by guarding against blank input.", "tool_calls": [], "finish_reason": "stop", "iteration": 1}},
        {"type": "run_completed", "payload": {"iterations": 2}},
    ]

    candidates = derive_learning_candidates(trace)
    assert any(c["type"] == "workflow" and "grep -> file_read -> file_edit" in c["content"] for c in candidates)
    assert any(c["type"] == "summary" and "empty-file parser crash" in c["content"] for c in candidates)
    assert any(c["type"] == "error_fix" and "grep" in c["content"] for c in candidates)


def test_failed_trace_produces_no_learning_candidates():
    trace = [
        {"type": "user_input", "payload": {"text": "Create files and run tests"}},
        {"type": "tool_execution", "payload": {"tool_name": "file_write", "args": {}}},
        {"type": "tool_result", "payload": {"tool_name": "file_write", "content": "created", "is_error": False}},
        {"type": "tool_execution", "payload": {"tool_name": "bash", "args": {"command": "python -m pytest"}}},
        {"type": "tool_result", "payload": {"tool_name": "bash", "content": "No module named pytest", "is_error": True}},
        {"type": "assistant_message", "payload": {"content": None, "tool_calls": [], "finish_reason": "stop", "iteration": 2}},
        {"type": "run_completed", "payload": {"iterations": 3}},
    ]

    assert derive_learning_candidates(trace) == []


def test_consolidate_memory_entries_removes_noise_and_duplicates():
    existing_entries = [
        {"id": 1, "content": "Workflow used successfully: grep -> file_read -> file_edit", "type": "workflow", "importance": 5},
        {"id": 2, "content": "Workflow used successfully: grep -> file_read -> file_edit", "type": "workflow", "importance": 3},
        {"id": 3, "content": "Session summary: user asked 'x'; outcome: I'll try to inspect it.", "type": "summary", "importance": 6},
        {"id": 4, "content": "Recovered from grep failure after error: no matches", "type": "error_fix", "importance": 7},
    ]
    new_candidates = [
        {"content": "Workflow used successfully: grep -> file_read -> file_edit", "type": "workflow", "importance": 5},
        {"content": "Recovered from grep failure after error: no matches", "type": "error_fix", "importance": 7},
        {"content": "Workflow used successfully: ls -> grep -> file_read", "type": "workflow", "importance": 6},
    ]

    plan = consolidate_memory_entries(existing_entries, new_candidates)
    assert sorted(plan["delete_ids"]) == [2, 3]
    assert len(plan["add_candidates"]) == 1
    assert plan["add_candidates"][0]["content"] == "Workflow used successfully: ls -> grep -> file_read"


def test_run_memory_consolidation_only_uses_successful_sessions():
    class FakeSession:
        def __init__(self, sid, cwd, trace_count):
            self.id = sid
            self.cwd = cwd
            self.trace_count = trace_count

    success_trace = [
        {"type": "user_input", "payload": {"text": "Fix parser crash"}},
        {"type": "tool_execution", "payload": {"tool_name": "grep", "args": {}}},
        {"type": "tool_result", "payload": {"tool_name": "grep", "content": "match found", "is_error": False}},
        {"type": "assistant_message", "payload": {"content": "I fixed the parser crash by handling empty input.", "tool_calls": [], "finish_reason": "stop", "iteration": 1}},
        {"type": "run_completed", "payload": {"iterations": 2}},
    ]
    failed_trace = [
        {"type": "user_input", "payload": {"text": "Run tests"}},
        {"type": "tool_execution", "payload": {"tool_name": "bash", "args": {}}},
        {"type": "tool_result", "payload": {"tool_name": "bash", "content": "No module named pytest", "is_error": True}},
        {"type": "assistant_message", "payload": {"content": None, "tool_calls": [], "finish_reason": "stop", "iteration": 1}},
        {"type": "run_completed", "payload": {"iterations": 2}},
    ]

    class FakeSessionDB:
        def list_sessions(self, cwd=None, limit=20):
            return [FakeSession(1, "/project", 5), FakeSession(2, "/project", 5)]

        def load_trace(self, session_id):
            return success_trace if session_id == 1 else failed_trace

    class FakeMemoryItem:
        def __init__(self, mid, content, mtype, importance):
            self.id = mid
            self.content = content
            self.importance = importance
            self.memory_type = type("MemoryType", (), {"value": mtype})()

    class FakeMemoryBackend:
        def __init__(self):
            self.deleted = []
            self.stored = []

        def list(self, namespace=None, limit=200):
            return [
                FakeMemoryItem(10, "Session summary: user asked 'x'; outcome: I'll try to inspect it.", "summary", 6),
                FakeMemoryItem(11, "Workflow used successfully: grep -> file_read", "workflow", 5),
            ]

        def delete(self, memory_id):
            self.deleted.append(memory_id)

        def store(self, content, type="fact", importance=5, namespace=None):
            self.stored.append({"content": content, "type": type, "importance": importance, "namespace": namespace})

    memory_backend = FakeMemoryBackend()
    result = run_memory_consolidation(FakeSessionDB(), memory_backend, cwd="/project")
    assert result["sessions_considered"] == 1
    assert result["deleted_count"] == 1
    assert memory_backend.deleted == [10]
    assert any(entry["type"] == "summary" for entry in memory_backend.stored)
    assert all(entry["namespace"] == "project" for entry in memory_backend.stored)


# --- Commands ---

def test_command_registry():
    reg = CommandRegistry()
    reg.register(Command(name="test", description="A test command"))
    assert reg.get("test") is not None
    assert reg.get("nonexistent") is None


def test_command_match():
    reg = CommandRegistry()
    reg.register(Command(name="help", description="Help"))
    reg.register(Command(name="hello", description="Hello"))
    reg.register(Command(name="clear", description="Clear"))
    matches = reg.match("hel")
    assert len(matches) == 2
    assert all("hel" in c.name for c in matches)


def test_builtins_registered():
    reg = create_command_registry(".")
    names = [c.name for c in reg.list_all()]
    assert "help" in names
    assert "clear" in names
    assert "resume" in names
    assert "sessions" in names
    assert "trace" in names
    assert "learn" in names
    assert "consolidate" in names
    assert "model" in names
    assert "provider" in names


def test_parse_frontmatter():
    text = """---
description: My command
---
Do something with $ARGUMENTS"""
    meta, body = _parse_frontmatter(text)
    assert meta["description"] == "My command"
    assert "$ARGUMENTS" in body


def test_parse_frontmatter_missing():
    meta, body = _parse_frontmatter("Just plain text")
    assert meta == {}
    assert body == "Just plain text"


def test_custom_command_loading():
    with tempfile.TemporaryDirectory() as tmp:
        cmd_dir = Path(tmp) / "commands"
        cmd_dir.mkdir()
        (cmd_dir / "deploy.md").write_text("---\ndescription: Deploy app\n---\nRun deploy script $1")
        reg = CommandRegistry()
        reg.load_custom_commands(str(cmd_dir))
        cmd = reg.get("deploy")
        assert cmd is not None
        assert cmd.description == "Deploy app"
        assert "$1" in cmd.prompt_template


# --- Streaming ---

def test_iter_stream_dict_passthrough():
    """CodexClient yields dicts directly - iter_stream should pass them through."""
    events = [
        {"type": "content_delta", "text": "hello"},
        {"type": "content_done"},
        {"type": "finish", "reason": "stop", "usage": None},
    ]
    result = list(iter_stream(iter(events)))
    assert len(result) == 3
    assert result[0]["type"] == "content_delta"


# --- Background bash ---

def test_bash_background():
    from vicode.tools.bash import BashTool, KillTool, _bg_processes
    bt = BashTool(Config())
    kt = KillTool()

    res = bt.run("ping localhost -n 100", background=True)
    assert not res.is_error
    assert "PID" in res.content

    # List
    res2 = kt.run()
    assert "running" in res2.content

    # Kill
    import re
    pid = int(re.search(r"PID: (\d+)", res.content).group(1))
    res3 = kt.run(pid=pid)
    assert "Killed" in res3.content


def test_kill_nonexistent():
    from vicode.tools.bash import KillTool
    kt = KillTool()
    res = kt.run(pid=99999)
    assert res.is_error


if __name__ == "__main__":
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"  FAIL  {t.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed, {passed + failed} total")
