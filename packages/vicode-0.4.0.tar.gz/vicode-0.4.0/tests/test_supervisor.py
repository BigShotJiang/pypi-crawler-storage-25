"""Tests for supervisor system: safety, memory guardian, task tracker, plan state."""

from vicode.config import Config
from vicode.tools.base import ToolResult
from vicode.supervisor.base import Supervisor, SupervisorChain, SupervisorVerdict
from vicode.supervisor.safety import SafetyGuardian, READ_ONLY_BASH
from vicode.supervisor.memory_guardian import MemoryGuardian
from vicode.supervisor.task_tracker import TaskTracker
from vicode.supervisor.plan_state import PlanState, PlanTask, _extract_paths, _normalize_path


# --- PlanState ---

def test_plan_parse_numbered_steps():
    text = """Goal: Fix bug
Files to modify:
- src/main.py
- tests/test_main.py

Steps:
1. Edit src/main.py to fix null check
2. Add test in tests/test_main.py
3. Run tests
"""
    ps = PlanState.from_plan_output(text)
    assert len(ps.tasks) == 3
    assert ps.tasks[0].description.startswith("Edit src/main.py")
    assert "src/main.py" in ps.target_files
    assert "tests/test_main.py" in ps.target_files


def test_plan_parse_bullet_steps():
    text = """Goal: Refactor
Steps:
- Extract helper function
- Update imports
- Run linter
"""
    ps = PlanState.from_plan_output(text)
    assert len(ps.tasks) == 3


def test_plan_is_file_in_plan():
    ps = PlanState(tasks=[], target_files={"src/main.py", "lib/utils.py"}, raw_plan="")
    assert ps.is_file_in_plan("src/main.py")
    assert ps.is_file_in_plan("C:/project/src/main.py")
    assert ps.is_file_in_plan("main.py")  # filename match
    assert not ps.is_file_in_plan("other.py")


def test_plan_mark_file_touched():
    ps = PlanState.from_plan_output("Steps:\n1. Edit main.py\n2. Edit utils.py")
    ps.mark_file_touched("main.py")
    assert ps.tasks[0].status == "in_progress"
    ps.mark_file_touched("main.py")
    assert ps.tasks[0].status == "done"


def test_plan_summary_for_llm():
    ps = PlanState.from_plan_output("Steps:\n1. First step\n2. Second step")
    summary = ps.summary_for_llm()
    assert "1." in summary
    assert "2." in summary


def test_extract_paths():
    assert _extract_paths("`src/main.py`") == ["src/main.py"]
    assert _extract_paths("(index.html + styles.css)") == ["index.html", "styles.css"]
    assert _extract_paths("Edit game.js file") == ["game.js"]
    assert _extract_paths("no paths here") == []


def test_normalize_path():
    assert _normalize_path("C:\\Users\\foo\\main.py") == "users/foo/main.py"
    assert _normalize_path("./src/main.py") == "src/main.py"
    assert _normalize_path("src/main.py") == "src/main.py"


# --- SafetyGuardian ---

def test_safety_approves_read_tools():
    sg = SafetyGuardian(None)
    plan = PlanState(tasks=[PlanTask(1, "test")], target_files={"x.py"})
    v = sg.pre_execute("file_read", {"file_path": "x.py"}, plan, [])
    assert v.approved


def test_safety_approves_without_plan():
    sg = SafetyGuardian(None)
    v = sg.pre_execute("file_write", {"file_path": "x.py"}, None, [])
    assert v.approved


def test_safety_approves_file_in_plan():
    sg = SafetyGuardian(None)
    plan = PlanState(tasks=[PlanTask(1, "edit x.py", files=["x.py"])], target_files={"x.py"})
    v = sg.pre_execute("file_write", {"file_path": "x.py"}, plan, [])
    assert v.approved


def test_safety_approves_readonly_bash():
    sg = SafetyGuardian(None)
    plan = PlanState(tasks=[PlanTask(1, "test")], target_files={"x.py"})
    v = sg.pre_execute("bash", {"command": "ls -la"}, plan, [])
    assert v.approved
    v2 = sg.pre_execute("bash", {"command": "git status"}, plan, [])
    assert v2.approved


def test_readonly_bash_regex():
    assert READ_ONLY_BASH.match("ls -la")
    assert READ_ONLY_BASH.match("git status")
    assert READ_ONLY_BASH.match("grep foo bar.txt")
    assert READ_ONLY_BASH.match("cat file.txt")
    assert not READ_ONLY_BASH.match("rm -rf /")
    assert not READ_ONLY_BASH.match("chmod 777 file")


# --- MemoryGuardian ---

def test_memory_guardian_detects_error_fix():
    mg = MemoryGuardian()
    # First call errors
    v1 = mg.post_execute("bash", {"command": "test"}, ToolResult("error", is_error=True), None, [])
    assert not v1.events
    # Second call succeeds -> should detect error fix
    v2 = mg.post_execute("bash", {"command": "test"}, ToolResult("ok"), None, [])
    mem_events = [e for e in v2.events if e["type"] == "memory_stored"]
    assert len(mem_events) == 1


def test_memory_guardian_stores_plan():
    mg = MemoryGuardian()
    v = mg.post_execute("plan", {}, ToolResult("Plan: do something"), None, [])
    mem_events = [e for e in v.events if e["type"] == "memory_stored"]
    assert len(mem_events) == 1
    assert "plan" in mem_events[0]["content"]


# --- TaskTracker ---

def test_task_tracker_parses_plan():
    tt = TaskTracker()
    result = ToolResult("Steps:\n1. Create file\n2. Edit file\n3. Test")
    v = tt.post_execute("plan", {}, result, None, [])
    assert tt.plan_state is not None
    assert len(tt.plan_state.tasks) == 3
    assert any(e["type"] == "tasks_updated" for e in v.events)


def test_task_tracker_marks_progress():
    tt = TaskTracker()
    tt.post_execute("plan", {}, ToolResult("Steps:\n1. Create `main.py` file\n2. Run tests"), None, [])
    v = tt.post_execute("file_write", {"file_path": "main.py"}, ToolResult("ok"), None, [])
    # Should find main.py either in task.files or in task description
    assert tt.plan_state.tasks[0].status in ("in_progress", "done")
    assert any(e["type"] == "tasks_updated" for e in v.events)


def test_task_tracker_plan_just_created():
    tt = TaskTracker()
    tt.post_execute("plan", {}, ToolResult("Steps:\n1. Step one"), None, [])
    assert tt.plan_just_created
    pending = tt.review_completion()
    assert pending == []  # should not force continuation right after plan


# --- SupervisorChain ---

def test_chain_approves_all():
    chain = SupervisorChain([SafetyGuardian(None), MemoryGuardian(), TaskTracker()])
    v = chain.pre_execute("ls", {}, None, [])
    assert v.approved


def test_chain_merges_post_events():
    chain = SupervisorChain([MemoryGuardian(), TaskTracker()])
    plan_result = ToolResult("Steps:\n1. Fix bug")
    v = chain.post_execute("plan", {}, plan_result, None, [])
    event_types = [e["type"] for e in v.events]
    assert "memory_stored" in event_types
    assert "tasks_updated" in event_types


if __name__ == "__main__":
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"  FAIL  {t.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed, {passed + failed} total")
