"""Tests for docs indexing and query tools."""

import json
from pathlib import Path

import pytest


CWD = Path(__file__).parent.parent


class TestDocsIndex:
    """Tests for docs_index tool."""

    def _create_test_files(self, tmp_path):
        """Create test Python files with enough content to be chunked."""
        src_dir = tmp_path / "src"
        src_dir.mkdir(parents=True, exist_ok=True)

        (src_dir / "main.py").write_text(
            """
class Main:
    def run(self):
        pass

def main():
    return Main()

def helper_function():
    return "helper"
""",
            encoding="utf-8",
        )

        (src_dir / "helper.py").write_text(
            """
def helper():
    pass

def another_helper():
    return True
""",
            encoding="utf-8",
        )

        (src_dir / "utils.txt").write_text(
            """
This is a text file for testing.
It should be indexed as well.
Line 3
Line 4
Line 5
""",
            encoding="utf-8",
        )

    def test_docs_index_creates_structure(self, tmp_path):
        """Test that docs_index creates .vicode/docs/ directory."""
        from vicode.tools.docs_index import DocsIndexTool

        self._create_test_files(tmp_path)

        docs_dir = tmp_path / ".vicode" / "docs"
        assert not docs_dir.exists()

        tool = DocsIndexTool(cwd=str(tmp_path))
        result = tool.run(action="index")

        assert not result.is_error
        assert docs_dir.exists()
        assert (docs_dir / "chunks").exists()

    def test_docs_index_chunks_exist(self, tmp_path):
        """Test that indexing creates chunks."""
        from vicode.tools.docs_index import DocsIndexTool

        self._create_test_files(tmp_path)

        tool = DocsIndexTool(cwd=str(tmp_path))
        tool.run(action="index")

        chunks_dir = tmp_path / ".vicode" / "docs" / "chunks"
        vdoc_files = list(chunks_dir.glob("*.vdoc"))

        assert len(vdoc_files) > 0

    def test_docs_index_has_valid_json(self, tmp_path):
        """Test that all chunks are valid JSON with required fields."""
        from vicode.tools.docs_index import DocsIndexTool

        self._create_test_files(tmp_path)

        tool = DocsIndexTool(cwd=str(tmp_path))
        tool.run(action="index")

        chunks_dir = tmp_path / ".vicode" / "docs" / "chunks"
        # Use recursive glob to find all .vdoc files in subdirectories
        vdoc_files = list(chunks_dir.rglob("*.vdoc"))

        assert len(vdoc_files) > 0, "No chunk files were created"

        for vdoc_file in vdoc_files:
            data = json.loads(vdoc_file.read_text(encoding="utf-8"))
            assert "file" in data, f"Missing 'file' field in {vdoc_file.name}"
            assert "line_start" in data, f"Missing 'line_start' field in {vdoc_file.name}"
            assert "content" in data, f"Missing 'content' field in {vdoc_file.name}"
            assert isinstance(data["content"], str), f"Content should be string in {vdoc_file.name}"
            assert isinstance(data["line_start"], int), f"line_start should be int in {vdoc_file.name}"

    def test_docs_index_contains_loop(self, tmp_path):
        """Test that main.py gets indexed."""
        from vicode.tools.docs_index import DocsIndexTool

        self._create_test_files(tmp_path)

        tool = DocsIndexTool(cwd=str(tmp_path))
        result = tool.run(action="index")

        chunks_dir = tmp_path / ".vicode" / "docs" / "chunks"
        main_chunks = list(chunks_dir.glob("*main*.vdoc"))

        assert len(main_chunks) > 0

    def test_docs_index_status(self, tmp_path):
        """Test that status action works."""
        from vicode.tools.docs_index import DocsIndexTool

        self._create_test_files(tmp_path)

        tool = DocsIndexTool(cwd=str(tmp_path))
        tool.run(action="index")

        result = tool.run(action="status")

        assert not result.is_error
        assert (
            "file_count" in result.content.lower() or "files:" in result.content.lower()
        )


class TestDocsQuery:
    """Tests for docs_query tool."""

    def _create_test_files(self, tmp_path):
        """Create test Python files."""
        src_dir = tmp_path / "src"
        src_dir.mkdir(parents=True, exist_ok=True)

        (src_dir / "main.py").write_text(
            """
class Main:
    def run(self):
        pass

def main():
    return Main()
""",
            encoding="utf-8",
        )

    def test_docs_query_finds_class(self, tmp_path):
        """Test finding Main class."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        self._create_test_files(tmp_path)

        index_tool = DocsIndexTool(cwd=str(tmp_path))
        index_tool.run(action="index")

        query_tool = DocsQueryTool(cwd=str(tmp_path))
        result = query_tool.run(query="Main")

        assert not result.is_error
        assert "main" in result.content.lower()

    def test_docs_query_finds_function(self, tmp_path):
        """Test finding helper function."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        self._create_test_files(tmp_path)

        index_tool = DocsIndexTool(cwd=str(tmp_path))
        index_tool.run(action="index")

        query_tool = DocsQueryTool(cwd=str(tmp_path))
        result = query_tool.run(query="run")

        assert not result.is_error

    def test_docs_query_no_index_error(self, tmp_path):
        """Test error when no index exists."""
        from vicode.tools.docs_query import DocsQueryTool

        query_tool = DocsQueryTool(cwd=str(tmp_path))
        result = query_tool.run(query="test")

        assert result.is_error
        assert "No documentation index found" in result.content

    def test_docs_query_top_k(self, tmp_path):
        """Test top_k parameter."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        self._create_test_files(tmp_path)

        index_tool = DocsIndexTool(cwd=str(tmp_path))
        index_tool.run(action="index")

        query_tool = DocsQueryTool(cwd=str(tmp_path))
        result = query_tool.run(query="class", top_k=3)

        assert not result.is_error


class TestDocsSync:
    """Tests for docs_sync tool."""

    def _create_test_files(self, tmp_path):
        """Create test Python files."""
        src_dir = tmp_path / "src"
        src_dir.mkdir(parents=True, exist_ok=True)

        (src_dir / "main.py").write_text("def main(): pass", encoding="utf-8")

    def test_docs_sync_check(self, tmp_path):
        """Test sync check."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_sync import DocsSyncTool

        self._create_test_files(tmp_path)

        index_tool = DocsIndexTool(cwd=str(tmp_path))
        index_tool.run(action="index")

        sync_tool = DocsSyncTool(cwd=str(tmp_path))
        result = sync_tool.run(action="check")

        assert not result.is_error

    def test_docs_sync_clean(self, tmp_path):
        """Test sync clean."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_sync import DocsSyncTool

        self._create_test_files(tmp_path)

        index_tool = DocsIndexTool(cwd=str(tmp_path))
        index_tool.run(action="index")

        sync_tool = DocsSyncTool(cwd=str(tmp_path))
        result = sync_tool.run(action="clean")

        assert not result.is_error


class TestDocsIntegrationReal:
    """Integration tests using the real vicode repo."""

    def test_index_finds_agent_loop_class(self):
        """Query should find AgentLoop class in real codebase."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        cwd = str(CWD)

        index_tool = DocsIndexTool(cwd=cwd)
        index_tool.run(action="index", force=True)

        query_tool = DocsQueryTool(cwd=cwd)
        result = query_tool.run(query="class AgentLoop", top_k=3)

        assert not result.is_error
        content_lower = result.content.lower()
        assert "loop" in content_lower

    def test_query_finds_tool_methods(self):
        """Query should find tool-related functions."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        cwd = str(CWD)

        index_tool = DocsIndexTool(cwd=cwd)
        index_tool.run(action="index", force=True)

        query_tool = DocsQueryTool(cwd=cwd)
        result = query_tool.run(query="FileReadTool", top_k=3)

        assert not result.is_error
        content_lower = result.content.lower()
        assert "file" in content_lower or "read" in content_lower

    def test_query_finds_supervisor(self):
        """Query should find supervisor-related code."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        cwd = str(CWD)

        index_tool = DocsIndexTool(cwd=cwd)
        index_tool.run(action="index", force=True)

        query_tool = DocsQueryTool(cwd=cwd)
        result = query_tool.run(query="Supervisor", top_k=3)

        assert not result.is_error

    def test_query_returns_useful_context(self):
        """Query should return chunks with line numbers and content."""
        from vicode.tools.docs_index import DocsIndexTool
        from vicode.tools.docs_query import DocsQueryTool

        cwd = str(CWD)

        index_tool = DocsIndexTool(cwd=cwd)
        index_tool.run(action="index", force=True)

        query_tool = DocsQueryTool(cwd=cwd)
        result = query_tool.run(query="run() method", top_k=2)

        assert not result.is_error
        assert "line" in result.content.lower() or ":" in result.content


def test_index_has_symbols(self):
    """Index should have metadata with file count."""
    cwd = str(CWD)
    chunks_dir = Path(cwd) / ".vicode" / "docs" / "chunks"

    vdoc_files = list(chunks_dir.glob("*.vdoc"))
    assert len(vdoc_files) > 0

    index_file = Path(cwd) / ".vicode" / "docs" / "index.json"
    index = json.loads(index_file.read_text(encoding="utf-8"))

    assert index.get("file_count", 0) > 0
    assert index.get("chunk_count", 0) > 0
