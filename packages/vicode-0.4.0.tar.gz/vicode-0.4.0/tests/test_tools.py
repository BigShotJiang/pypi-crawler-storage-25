"""Unit tests for all tools - no LLM needed."""
import os
import tempfile
from pathlib import Path

from vicode.config import Config
from vicode.tools.registry import create_default_registry
from vicode.tools.bash import is_blocked
from vicode.tools.file_history import FileHistory
from vicode.tools.web_fetch import html_to_text


def get_config(tmp_dir: str) -> Config:
    return Config(cwd=tmp_dir, server_url="http://localhost:8080/v1", model="test")


# --- Bash blocklist ---

def test_blocklist_blocks_interactive():
    assert is_blocked("vim file.txt") == "vim"
    assert is_blocked("nano") == "nano"
    assert is_blocked("python") == "python"
    assert is_blocked("gdb ./a.out") == "gdb"
    assert is_blocked("ssh user@host") == "ssh"
    assert is_blocked("  less file") == "less"


def test_blocklist_allows_scripts():
    assert is_blocked("python -c 'print(1)'") is None
    assert is_blocked("python script.py") is None
    assert is_blocked("python3 -m pytest") is None
    assert is_blocked("node -e 'console.log(1)'") is None
    assert is_blocked("ls -la") is None
    assert is_blocked("echo hello | cat") is None
    assert is_blocked("grep foo bar.txt") is None


# --- File tools ---

def test_file_write_and_read():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("file_write", {"file_path": f"{tmp}/test.txt", "content": "hello\nworld"})
        assert not res.is_error
        assert "Created" in res.content

        res = reg.execute("file_read", {"file_path": f"{tmp}/test.txt"})
        assert not res.is_error
        assert "hello" in res.content
        assert "world" in res.content


def test_file_edit():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        reg.execute("file_write", {"file_path": f"{tmp}/edit.txt", "content": "foo bar baz"})
        res = reg.execute("file_edit", {
            "file_path": f"{tmp}/edit.txt",
            "old_string": "bar",
            "new_string": "REPLACED",
        })
        assert not res.is_error
        content = Path(f"{tmp}/edit.txt").read_text()
        assert "foo REPLACED baz" == content


def test_file_edit_unique_match():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        reg.execute("file_write", {"file_path": f"{tmp}/dup.txt", "content": "aaa\naaa\naaa"})
        res = reg.execute("file_edit", {
            "file_path": f"{tmp}/dup.txt",
            "old_string": "aaa",
            "new_string": "bbb",
        })
        assert res.is_error
        assert "3 times" in res.content


# --- File history / undo ---

def test_undo_write():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        path = f"{tmp}/undo_test.txt"
        reg.execute("file_write", {"file_path": path, "content": "original"})
        reg.execute("file_write", {"file_path": path, "content": "modified"})
        assert Path(path).read_text() == "modified"

        res = reg.execute("undo", {})
        assert not res.is_error
        assert Path(path).read_text() == "original"


def test_undo_new_file():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        path = f"{tmp}/new_file.txt"
        reg.execute("file_write", {"file_path": path, "content": "created"})
        assert Path(path).exists()

        reg.execute("undo", {})
        assert not Path(path).exists()


# --- Grep ---

def test_grep():
    with tempfile.TemporaryDirectory() as tmp:
        Path(f"{tmp}/a.py").write_text("def hello():\n    pass\n")
        Path(f"{tmp}/b.py").write_text("def world():\n    pass\n")
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("grep", {"pattern": "def.*hello", "path": tmp})
        assert not res.is_error
        assert "a.py" in res.content
        assert "b.py" not in res.content


# --- Glob ---

def test_glob():
    with tempfile.TemporaryDirectory() as tmp:
        Path(f"{tmp}/a.py").write_text("")
        Path(f"{tmp}/b.txt").write_text("")
        Path(f"{tmp}/c.py").write_text("")
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("glob", {"pattern": "*.py", "path": tmp})
        assert not res.is_error
        assert "a.py" in res.content
        assert "c.py" in res.content
        assert "b.txt" not in res.content


# --- Ls ---

def test_ls():
    with tempfile.TemporaryDirectory() as tmp:
        Path(f"{tmp}/file1.txt").write_text("hi")
        os.makedirs(f"{tmp}/subdir")
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("ls", {"path": tmp})
        assert not res.is_error
        assert "file1.txt" in res.content
        assert "subdir/" in res.content


# --- HTML to text ---

def test_html_to_text():
    html = "<html><head><style>body{}</style></head><body><h1>Title</h1><p>Hello <b>world</b></p><script>alert(1)</script></body></html>"
    text = html_to_text(html)
    assert "Title" in text
    assert "Hello world" in text
    assert "alert" not in text
    assert "body{}" not in text


def test_html_to_text_empty():
    assert html_to_text("") == ""
    assert html_to_text("<script>var x=1;</script>") == ""


# --- Memory ---

def test_memory_store_and_search():
    reg = create_default_registry(get_config("."))
    res = reg.execute("memory", {"action": "store", "content": "vicode_test_unique_12345", "type": "fact"})
    assert not res.is_error
    assert "Stored" in res.content

    res = reg.execute("memory", {"action": "search", "content": "vicode_test_unique_12345"})
    assert not res.is_error
    assert "vicode_test_unique_12345" in res.content


def test_memory_recall():
    reg = create_default_registry(get_config("."))
    res = reg.execute("memory", {"action": "recall"})
    assert not res.is_error


# --- Bash execution ---

def test_bash_echo():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("bash", {"command": "echo hello_test"})
        assert not res.is_error
        assert "hello_test" in res.content


def test_bash_blocked():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("bash", {"command": "vim"})
        assert res.is_error
        assert "Blocked" in res.content


def test_bash_timeout():
    with tempfile.TemporaryDirectory() as tmp:
        reg = create_default_registry(get_config(tmp))
        res = reg.execute("bash", {"command": "sleep 10", "timeout": 2})
        assert res.is_error
        assert "timed out" in res.content


if __name__ == "__main__":
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for t in tests:
        try:
            t()
            print(f"  PASS  {t.__name__}")
            passed += 1
        except Exception as e:
            print(f"  FAIL  {t.__name__}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed, {passed + failed} total")
