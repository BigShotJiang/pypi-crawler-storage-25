"""Integration tests that require llama-server running on localhost:8080."""
import os
import tempfile

from vicode.config import Config
from vicode.agent.loop import AgentLoop
from vicode.llm.client import LLMClient
from vicode.tools.registry import create_default_registry


SERVER = "http://localhost:8080/v1"


def get_model() -> str:
    client = LLMClient(Config(server_url=SERVER))
    model = client.detect_model()
    assert model, "llama-server not running or no model loaded"
    return model


def collect_events(agent: AgentLoop, msg: str) -> dict:
    """Run agent and collect results."""
    content = []
    tools_used = []
    errors = []
    for event in agent.run(msg):
        match event:
            case {"type": "content_delta", "text": text}:
                content.append(text)
            case {"type": "tool_result", "name": name, "is_error": err}:
                tools_used.append({"name": name, "error": err})
            case {"type": "error", "message": msg}:
                errors.append(msg)
    return {
        "content": "".join(content),
        "tools": tools_used,
        "errors": errors,
    }


# --- LLM connectivity ---

def test_model_detection():
    model = get_model()
    print(f"    Model: {model}")
    assert "gguf" in model.lower() or "qwen" in model.lower() or len(model) > 3


# --- Simple chat (no tools) ---

def test_simple_chat():
    model = get_model()
    with tempfile.TemporaryDirectory() as tmp:
        config = Config(server_url=SERVER, model=model, cwd=tmp)
        reg = create_default_registry(config)
        agent = AgentLoop(config=config, tools=reg)
        result = collect_events(agent, "What is 2+2? Answer with just the number.")
        assert "4" in result["content"], f"Expected '4' in: {result['content'][:200]}"
        assert not result["errors"]


# --- Tool usage ---

def test_ls_tool_usage():
    model = get_model()
    with tempfile.TemporaryDirectory() as tmp:
        # Create some files for the agent to find
        open(f"{tmp}/hello.py", "w").write("print('hello')")
        open(f"{tmp}/readme.md", "w").write("# Test")
        config = Config(server_url=SERVER, model=model, cwd=tmp)
        reg = create_default_registry(config)
        agent = AgentLoop(config=config, tools=reg)
        result = collect_events(agent, "List the files in the current directory.")
        tool_names = [t["name"] for t in result["tools"]]
        assert any(n in tool_names for n in ("ls", "bash", "glob")), f"Expected file listing tool, got: {tool_names}"
        assert "hello.py" in result["content"] or any("hello.py" in str(t) for t in result["tools"])


def test_file_write_and_read():
    model = get_model()
    with tempfile.TemporaryDirectory() as tmp:
        config = Config(server_url=SERVER, model=model, cwd=tmp)
        reg = create_default_registry(config)
        agent = AgentLoop(config=config, tools=reg)
        result = collect_events(agent, "Create a file called test.txt with the content 'hello world', then read it back.")
        tool_names = [t["name"] for t in result["tools"]]
        assert "file_write" in tool_names, f"Expected file_write, got: {tool_names}"
        # Verify file was actually created
        test_path = os.path.join(tmp, "test.txt")
        assert os.path.exists(test_path), "test.txt was not created"
        content = open(test_path).read()
        assert "hello" in content.lower()


def test_grep_tool_usage():
    model = get_model()
    with tempfile.TemporaryDirectory() as tmp:
        open(f"{tmp}/code.py", "w").write("def calculate_sum(a, b):\n    return a + b\n")
        open(f"{tmp}/other.py", "w").write("def say_hello():\n    print('hi')\n")
        config = Config(server_url=SERVER, model=model, cwd=tmp)
        reg = create_default_registry(config)
        agent = AgentLoop(config=config, tools=reg)
        result = collect_events(agent, "Find which file contains the function 'calculate_sum'.")
        assert "code.py" in result["content"]


def test_file_edit_tool():
    model = get_model()
    with tempfile.TemporaryDirectory() as tmp:
        open(f"{tmp}/fix.txt", "w").write("The color is red.")
        config = Config(server_url=SERVER, model=model, cwd=tmp)
        reg = create_default_registry(config)
        agent = AgentLoop(config=config, tools=reg)
        result = collect_events(agent, "Edit fix.txt and change 'red' to 'blue'.")
        content = open(f"{tmp}/fix.txt").read()
        assert "blue" in content, f"Expected 'blue' in: {content}"


# --- Sub-agents ---

def test_explore_subagent():
    model = get_model()
    with tempfile.TemporaryDirectory() as tmp:
        open(f"{tmp}/main.py", "w").write("from utils import helper\n\ndef main():\n    helper()\n")
        open(f"{tmp}/utils.py", "w").write("def helper():\n    return 42\n")
        config = Config(server_url=SERVER, model=model, cwd=tmp)
        reg = create_default_registry(config)
        agent = AgentLoop(config=config, tools=reg)
        result = collect_events(agent, "Use the explore tool to find out what the helper function does.")
        tool_names = [t["name"] for t in result["tools"]]
        assert "explore" in tool_names, f"Expected explore tool, got: {tool_names}"
        # The response should mention 42 or the helper function
        combined = result["content"].lower()
        assert "42" in combined or "helper" in combined


if __name__ == "__main__":
    tests = [v for k, v in globals().items() if k.startswith("test_") and callable(v)]
    passed = 0
    failed = 0
    for t in tests:
        name = t.__name__
        print(f"  RUN   {name}...", end="", flush=True)
        try:
            t()
            print(f"\r  PASS  {name}")
            passed += 1
        except Exception as e:
            print(f"\r  FAIL  {name}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed, {passed + failed} total")
