"""End-to-end tests using vicode -p for non-interactive execution.

Requires a running LLM server (llama-server on 8080 or configured provider).
Tests run vicode as a subprocess and verify output + file system changes.
"""

import json
import os
import subprocess
import sys
import tempfile
from pathlib import Path

# Use the venv python to run vicode
PYTHON = sys.executable
VICODE = [PYTHON, "-m", "vicode", "--no-tui"]
TIMEOUT = 180  # seconds per test


def run_vicode(prompt: str, cwd: str = None, timeout: int = TIMEOUT) -> dict:
    """Run vicode -p "prompt" and return {stdout, stderr, returncode}."""
    cmd = VICODE + ["-p", prompt]
    if cwd:
        cmd.extend(["--cwd", cwd])
    result = subprocess.run(
        cmd,
        capture_output=True,
        text=True,
        timeout=timeout,
        cwd=cwd,
    )
    return {
        "stdout": result.stdout,
        "stderr": result.stderr,
        "returncode": result.returncode,
    }


# --- Basic functionality ---

def test_simple_question():
    """Agent should answer a simple question without tools."""
    r = run_vicode("What is 2+2? Answer with just the number.")
    assert "4" in r["stdout"], f"Expected '4' in output: {r['stdout'][:200]}"
    assert r["returncode"] == 0


def test_list_files():
    """Agent should use a tool to list files."""
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "hello.txt").write_text("world")
        Path(tmp, "test.py").write_text("print('hi')")
        r = run_vicode("List the files in this directory. Just list the filenames.", cwd=tmp)
        assert "hello.txt" in r["stdout"] or "hello.txt" in r["stderr"]


def test_read_file():
    """Agent should read a file's contents."""
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "data.txt").write_text("secret_value_42")
        r = run_vicode("Read the file data.txt and tell me what it contains.", cwd=tmp)
        combined = r["stdout"] + r["stderr"]
        assert "secret_value_42" in combined or "42" in combined


def test_write_file():
    """Agent should create a new file."""
    with tempfile.TemporaryDirectory() as tmp:
        r = run_vicode(
            'Create a file called output.txt with the content "hello from vicode"',
            cwd=tmp,
        )
        output_file = Path(tmp, "output.txt")
        assert output_file.exists(), f"output.txt not created. stderr: {r['stderr'][:200]}"
        content = output_file.read_text()
        assert "hello" in content.lower()


def test_edit_file():
    """Agent should edit an existing file."""
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "fix.txt").write_text("The color is red.")
        r = run_vicode("Edit fix.txt and change 'red' to 'blue'.", cwd=tmp)
        content = Path(tmp, "fix.txt").read_text()
        assert "blue" in content, f"Expected 'blue' in: {content}"


def test_grep():
    """Agent should find text in files."""
    with tempfile.TemporaryDirectory() as tmp:
        Path(tmp, "a.py").write_text("def calculate_sum(a, b):\n    return a + b\n")
        Path(tmp, "b.py").write_text("def say_hello():\n    print('hi')\n")
        r = run_vicode("Which file contains the function 'calculate_sum'?", cwd=tmp)
        assert "a.py" in r["stdout"]


def test_multi_step():
    """Agent should chain multiple tool calls."""
    with tempfile.TemporaryDirectory() as tmp:
        r = run_vicode(
            "Create a file called hello.py that prints 'hello world', then run it with python.",
            cwd=tmp,
        )
        hello = Path(tmp, "hello.py")
        assert hello.exists(), "hello.py not created"
        combined = r["stdout"] + r["stderr"]
        assert "hello" in combined.lower()


def test_error_recovery():
    """Agent should handle errors gracefully."""
    with tempfile.TemporaryDirectory() as tmp:
        r = run_vicode("Read the file nonexistent_file_xyz.txt", cwd=tmp)
        # Should not crash, should mention file not found
        combined = r["stdout"] + r["stderr"]
        assert "not found" in combined.lower() or "error" in combined.lower() or "exist" in combined.lower()


if __name__ == "__main__":
    tests = [v for k, v in sorted(globals().items()) if k.startswith("test_") and callable(v)]
    passed = failed = 0
    for t in tests:
        name = t.__name__
        print(f"  RUN   {name}...", end="", flush=True)
        try:
            t()
            print(f"\r  PASS  {name}")
            passed += 1
        except subprocess.TimeoutExpired:
            print(f"\r  TIMEOUT  {name}")
            failed += 1
        except Exception as e:
            print(f"\r  FAIL  {name}: {e}")
            failed += 1
    print(f"\n{passed} passed, {failed} failed, {passed + failed} total")
