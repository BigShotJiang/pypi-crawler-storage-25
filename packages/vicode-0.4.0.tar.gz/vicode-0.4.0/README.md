# vicode

TUI coding agent for local LLMs. Like Claude Code but runs on your own hardware.

## Install

```bash
pip install vicode
```

## Quick Start

```bash
# Start llama-server with your model
llama-server -m model.gguf -p 8080 --jinja

# Launch vicode in any project directory
cd my-project
vicode
```

On first run, vicode auto-detects your local LLM server. If none is found, an interactive setup wizard configures your provider (OpenAI, Anthropic, OpenRouter, Groq, or custom endpoint).

## Features

- **13 tools**: bash, file read/write/edit, grep, glob, ls, web search/fetch, memory, undo, explore, plan
- **Supervisor system**: Safety guardian validates actions against plans, memory guardian auto-stores learnings, task tracker shows progress
- **Persistent memory**: Remembers preferences, error fixes, and patterns across sessions (powered by engram)
- **Persistent session traces**: Stores structured traces for every TUI, CLI, and one-shot prompt session so you can inspect and improve agent behavior later
- **Memory consolidation**: Learns only from successful sessions, prunes noisy/redundant memories, and can be run as a daily maintenance task
- **Sub-agents**: Explore and Plan run with isolated context to avoid polluting the main conversation
- **Slash commands**: `/help`, `/clear`, `/compact`, `/init`, `/undo`, `/model`, `/provider`, `/status`, `/memory`, `/sessions`, `/resume`, `/trace`, `/learn`, `/consolidate`
- **Custom commands**: Drop `.md` files in `.vicode/commands/` for project-specific shortcuts
- **Provider support**: Local (llama-server, Ollama, LM Studio), OpenAI, Anthropic, OpenRouter, Groq

## Configuration

- `VICODE.md` / `CLAUDE.md` / `AGENT.md` in project root are loaded into the system prompt
- `~/.vicode/config.json` stores provider settings
- `vicode --setup` to reconfigure provider
- `vicode --consolidate-memory --cwd <project>` runs daily-style memory cleanup + learning consolidation for one project namespace

## Requirements

- Python 3.11+
- A running LLM server (llama-server, Ollama) or API key for a cloud provider
