try:
    import redis.asyncio as redis
except ImportError as exc:
    raise ImportError(
        'The "redis" package is required for the OpenAI Redis rate limiter backend. '
        'Install it with: pip install "token-throttle[redis]"'
    ) from exc

from token_throttle._factories._openai._model_family import openai_model_family_getter
from token_throttle._factories._openai._token_counter import OpenAIUsageCounter
from token_throttle._interfaces._callbacks import (
    RateLimiterCallbacks,
    _merge_rate_limiter_callbacks,
    create_logging_callbacks,
)
from token_throttle._interfaces._interfaces import PerModelConfig
from token_throttle._interfaces._models import Quota, SecondsIn, UsageQuotas
from token_throttle._limiter_backends._redis._backend import RedisBackendBuilder
from token_throttle._limiter_backends._redis._keys import (
    DEFAULT_REFUND_DEDUP_TTL_SECONDS,
)
from token_throttle._limiter_backends._redis._ttl import DEFAULT_BUCKET_TTL_SECONDS
from token_throttle._rate_limiter import RateLimiter


def create_openai_redis_rate_limiter(  # noqa: PLR0913
    redis_client: redis.Redis,
    *,
    key_prefix: str,
    rpm: int,
    tpm: int,
    bucket_ttl_seconds: int = DEFAULT_BUCKET_TTL_SECONDS,
    max_reservation_lifetime_seconds: float | None = None,
    refund_dedup_ttl_seconds: int | None = None,
    callbacks: RateLimiterCallbacks | None = None,
) -> RateLimiter:
    """
    Build an async OpenAI rate limiter backed by Redis.

    ``redis_client`` must be a ``redis.asyncio.Redis`` instance. ``key_prefix``
    is a required deployment-scoped Redis namespace; all Redis keys use
    ``{key_prefix}:rate_limiting:...`` so unrelated deployments sharing Redis
    do not collide. ``rpm`` and ``tpm`` are per-minute limits for requests and
    tokens, grouped by ``openai_model_family_getter`` so dated model variants
    share a family. User-provided callbacks merge slot-by-slot with the factory
    defaults: non-None user callbacks win, while None slots inherit the default
    INFO logger for missing consumption data. ``bucket_ttl_seconds`` controls
    the required expiry refreshed on Redis bucket-state keys.
    ``max_reservation_lifetime_seconds`` bounds how long an acquired
    reservation can remain refundable; None lets the Redis backend derive the
    library default from Redis TTLs. ``refund_dedup_ttl_seconds`` controls how
    long successful refund ids are retained for cross-process idempotency; None
    preserves the library default.

    The helper is intentionally minute-window-only. For hourly/daily windows,
    custom metrics, or non-OpenAI usage shapes, construct ``RateLimiter`` with
    explicit ``Quota`` objects instead.
    """
    if not isinstance(redis_client, redis.Redis):
        raise TypeError(
            f"redis_client must be a redis.asyncio.Redis (async) instance "
            f"(got {type(redis_client).__name__}). For a sync client, use "
            f"create_openai_redis_sync_rate_limiter instead."
        )
    if isinstance(rpm, bool) or not isinstance(rpm, int):
        raise TypeError(f"rpm must be an int (got {type(rpm).__name__})")
    if isinstance(tpm, bool) or not isinstance(tpm, int):
        raise TypeError(f"tpm must be an int (got {type(tpm).__name__})")
    if callbacks is not None and type(callbacks) is not RateLimiterCallbacks:
        raise TypeError(
            f"callbacks must be a RateLimiterCallbacks instance or None "
            f"(got {type(callbacks).__name__})"
        )
    Quota(metric="requests", limit=rpm, per_seconds=SecondsIn.MINUTE)
    Quota(metric="tokens", limit=tpm, per_seconds=SecondsIn.MINUTE)

    default_callbacks = create_logging_callbacks(
        wait_start=None,
        wait_end_consumption=None,
        capacity_consumed=None,
        capacity_refunded=None,
        missing_consumption_data="INFO",
    )

    return RateLimiter(
        lambda model_name: PerModelConfig(
            quotas=UsageQuotas(
                [
                    Quota(metric="requests", limit=rpm, per_seconds=SecondsIn.MINUTE),
                    Quota(metric="tokens", limit=tpm, per_seconds=SecondsIn.MINUTE),
                ],
            ),
            usage_counter=OpenAIUsageCounter(),
            model_family=openai_model_family_getter(model_name),
        ),
        backend=RedisBackendBuilder(
            redis_client,
            key_prefix=key_prefix,
            bucket_ttl_seconds=bucket_ttl_seconds,
            refund_dedup_ttl_seconds=(
                DEFAULT_REFUND_DEDUP_TTL_SECONDS
                if refund_dedup_ttl_seconds is None
                else refund_dedup_ttl_seconds
            ),
        ),
        callbacks=_merge_rate_limiter_callbacks(callbacks, default_callbacks),
        max_reservation_lifetime_seconds=max_reservation_lifetime_seconds,
    )
