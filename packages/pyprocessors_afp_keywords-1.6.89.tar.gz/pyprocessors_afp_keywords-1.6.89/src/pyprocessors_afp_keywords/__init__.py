"""Processor based on Huggingface transformers zero-shot classification pipeline"""

__version__ = "1.6.89"
