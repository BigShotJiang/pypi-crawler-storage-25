# `Setup`

::: agents.tracing.setup
