# `Model`

::: agents.realtime.model
