"""Access control module: RBAC + bubblewrap sandbox integration.

Manages roles, users, and permission checks.  All data lives in the same
SQLite database as the task queue (.mtbridge_tasks.db).
"""

import json
import logging
import sqlite3
import time
from dataclasses import dataclass, field
from pathlib import Path

logger = logging.getLogger(__name__)


# ── Data classes ─────────────────────────────────────────────────────

@dataclass
class RoleRecord:
    name: str
    allowed_models: list[str]     # ["opus", "sonnet", "haiku"]
    can_bash: bool
    can_write: bool
    can_push: bool
    can_creds: bool
    budget_limit: float           # 0 = unlimited
    created_at: float = 0.0


@dataclass
class UserRecord:
    telegram_id: int
    username: str
    display_name: str
    role_name: str
    allowed_projects: list[str]   # ["*"] = all, or ["telephony", "mtbridge"]
    is_active: bool = True
    created_at: float = 0.0
    updated_at: float = 0.0


@dataclass
class SandboxMount:
    src: str          # host path
    dst: str          # path inside sandbox
    mode: str = "ro"  # "ro" or "rw"


@dataclass
class AccessResult:
    allowed: bool
    reason: str = ""
    role: RoleRecord | None = None
    user: UserRecord | None = None
    effective_model: str | None = None
    sandbox_mounts: list[SandboxMount] = field(default_factory=list)
    hidden_paths: list[str] = field(default_factory=list)  # absolute paths to hide with tmpfs


# ── Default roles (seeded on first run) ─────────────────────────────

DEFAULT_ROLES = [
    RoleRecord(
        name="admin",
        allowed_models=["opus", "sonnet", "haiku"],
        can_bash=True, can_write=True, can_push=True, can_creds=True,
        budget_limit=0.0,
    ),
    RoleRecord(
        name="engineer",
        allowed_models=["sonnet", "haiku"],
        can_bash=True, can_write=True, can_push=False, can_creds=False,
        budget_limit=2.0,
    ),
    RoleRecord(
        name="viewer",
        allowed_models=["haiku"],
        can_bash=False, can_write=False, can_push=False, can_creds=False,
        budget_limit=0.50,
    ),
]


# ── AccessManager ────────────────────────────────────────────────────

class AccessManager:
    """RBAC + sandbox mount builder.

    Uses the same SQLite connection pattern as TaskQueue — synchronous ops,
    WAL mode, thread-safe enough for our async code.
    """

    def __init__(self, conn: sqlite3.Connection, projects_dir: str = "/home/claude/projects"):
        self._conn = conn
        self._projects_dir = projects_dir
        self._create_tables()
        self._seed_roles()

    # ── Schema ───────────────────────────────────────────────────────

    def _create_tables(self) -> None:
        self._conn.executescript("""
            CREATE TABLE IF NOT EXISTS roles (
                name TEXT PRIMARY KEY,
                allowed_models TEXT NOT NULL DEFAULT 'haiku',
                can_bash INTEGER NOT NULL DEFAULT 0,
                can_write INTEGER NOT NULL DEFAULT 0,
                can_push INTEGER NOT NULL DEFAULT 0,
                can_creds INTEGER NOT NULL DEFAULT 0,
                budget_limit REAL NOT NULL DEFAULT 0.0,
                created_at REAL NOT NULL DEFAULT 0.0
            );

            CREATE TABLE IF NOT EXISTS users (
                telegram_id INTEGER PRIMARY KEY,
                username TEXT NOT NULL DEFAULT '',
                display_name TEXT NOT NULL DEFAULT '',
                role_name TEXT NOT NULL DEFAULT 'viewer',
                allowed_projects TEXT NOT NULL DEFAULT '*',
                is_active INTEGER NOT NULL DEFAULT 1,
                created_at REAL NOT NULL DEFAULT 0.0,
                updated_at REAL NOT NULL DEFAULT 0.0
            );

            CREATE TABLE IF NOT EXISTS chat_projects (
                chat_id INTEGER PRIMARY KEY,
                project_name TEXT NOT NULL,
                created_at REAL NOT NULL DEFAULT 0.0,
                updated_at REAL NOT NULL DEFAULT 0.0
            );

            CREATE TABLE IF NOT EXISTS project_hidden_paths (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                project_name TEXT NOT NULL,
                path TEXT NOT NULL,
                require_flag TEXT NOT NULL DEFAULT 'can_creds',
                UNIQUE(project_name, path)
            );
        """)
        self._conn.commit()

    def _seed_roles(self) -> None:
        """Insert default roles if the table is empty."""
        count = self._conn.execute("SELECT COUNT(*) FROM roles").fetchone()[0]
        if count > 0:
            return
        now = time.time()
        for r in DEFAULT_ROLES:
            self._conn.execute(
                "INSERT INTO roles (name, allowed_models, can_bash, can_write, can_push, can_creds, budget_limit, created_at) "
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                (r.name, ",".join(r.allowed_models),
                 int(r.can_bash), int(r.can_write), int(r.can_push), int(r.can_creds),
                 r.budget_limit, now),
            )
        self._conn.commit()
        logger.info("Seeded %d default roles", len(DEFAULT_ROLES))

    # ── Core: permission check ───────────────────────────────────────

    def check_access(
        self,
        telegram_id: int,
        project: str | None = None,
        model: str | None = None,
    ) -> AccessResult:
        """Check if a user can run a task.  Returns AccessResult."""
        user = self.get_user(telegram_id)
        if not user:
            return AccessResult(allowed=False, reason="Нет доступа. Обратитесь к администратору.")
        if not user.is_active:
            return AccessResult(allowed=False, reason="Аккаунт деактивирован.", user=user)

        role = self.get_role(user.role_name)
        if not role:
            return AccessResult(allowed=False, reason=f"Роль '{user.role_name}' не найдена.", user=user)

        # Project access
        if project and "*" not in user.allowed_projects:
            if project not in user.allowed_projects:
                return AccessResult(
                    allowed=False,
                    reason=f"Нет доступа к проекту '{project}'.",
                    user=user, role=role,
                )

        # Model access — downgrade if needed
        effective_model = model
        if model and model not in role.allowed_models:
            # Try to downgrade
            for fallback in ["sonnet", "haiku"]:
                if fallback in role.allowed_models:
                    effective_model = fallback
                    break
            else:
                return AccessResult(
                    allowed=False,
                    reason=f"Модель '{model}' не доступна для роли '{role.name}'.",
                    user=user, role=role,
                )

        # Build sandbox mounts (only the specific project) + hidden paths
        mounts, hidden = self._build_mounts(role, project)

        return AccessResult(
            allowed=True,
            role=role,
            user=user,
            effective_model=effective_model,
            sandbox_mounts=mounts,
            hidden_paths=hidden,
        )

    # ── Sandbox mounts ───────────────────────────────────────────────

    def _build_mounts(
        self, role: RoleRecord, project: str | None
    ) -> tuple[list[SandboxMount], list[str]]:
        """Build mounts and hidden paths for bwrap.

        Returns (mounts, hidden_paths):
        - mounts: project directory with rw/ro based on role
        - hidden_paths: absolute paths to overlay with tmpfs (role lacks required flag)
        """
        if not project:
            return [], []
        mode = "rw" if role.can_write else "ro"
        # If project name matches workspace dir name, use workspace directly
        workspace_name = self._projects_dir.rstrip("/").split("/")[-1]
        if project == workspace_name:
            proj_path = self._projects_dir
        else:
            proj_path = f"{self._projects_dir}/{project}"
        mounts = [SandboxMount(src=proj_path, dst=proj_path, mode=mode)]

        # Compute hidden paths: paths the role is not allowed to see
        hidden = []
        rows = self._conn.execute(
            "SELECT path, require_flag FROM project_hidden_paths WHERE project_name = ?",
            (project,),
        ).fetchall()
        for row in rows:
            flag = row["require_flag"]
            # Check if role has the required flag
            if not getattr(role, flag, False):
                hidden.append(f"{proj_path}/{row['path']}")

        return mounts, hidden

    # ── Role prompt (Layer 3) ────────────────────────────────────────

    def build_role_prompt(self, telegram_id: int, project: str | None = None) -> str:
        """Build system prompt section describing user's role and limits."""
        user = self.get_user(telegram_id)
        if not user:
            return ""
        role = self.get_role(user.role_name)
        if not role:
            return ""

        projects = project or ("все" if "*" in user.allowed_projects else ", ".join(user.allowed_projects))
        models = ", ".join(role.allowed_models)
        budget = f"${role.budget_limit:.2f} за запрос" if role.budget_limit > 0 else "без лимита"

        lines = [
            "# User Access Context",
            f"User: {user.display_name} (@{user.username})",
            f"Role: {role.name}",
            f"Allowed projects: {projects}",
            f"Allowed models: {models}",
            f"Permissions: bash {'yes' if role.can_bash else 'NO'}, "
            f"file write {'yes' if role.can_write else 'NO'}, "
            f"git push {'yes' if role.can_push else 'NO'}, "
            f"credentials {'yes' if role.can_creds else 'NO'}",
            f"Budget: {budget}",
            "",
        ]

        restrictions = []
        if not role.can_bash:
            restrictions.append("Do NOT run bash commands or use the terminal.")
        if not role.can_write:
            restrictions.append("Do NOT write or edit files. Read-only mode.")
        if not role.can_push:
            restrictions.append("Do NOT run git push or modify remote repositories.")
        if not role.can_creds:
            restrictions.append("Do NOT read or show credentials, API keys, tokens, or secrets.")

        if restrictions:
            lines.append("RESTRICTIONS (enforce strictly):")
            for r in restrictions:
                lines.append(f"- {r}")
            lines.append("")
            lines.append("If the user asks for something outside their permissions, explain what access they need.")

        return "\n".join(lines)

    # ── CRUD: Users ──────────────────────────────────────────────────

    def get_user(self, telegram_id: int) -> UserRecord | None:
        row = self._conn.execute(
            "SELECT * FROM users WHERE telegram_id = ?", (telegram_id,)
        ).fetchone()
        return self._row_to_user(row) if row else None

    def list_users(self) -> list[UserRecord]:
        rows = self._conn.execute("SELECT * FROM users ORDER BY display_name").fetchall()
        return [self._row_to_user(r) for r in rows]

    def add_user(
        self, telegram_id: int, username: str, display_name: str,
        role_name: str, allowed_projects: str = "*",
    ) -> None:
        now = time.time()
        self._conn.execute(
            "INSERT OR REPLACE INTO users "
            "(telegram_id, username, display_name, role_name, allowed_projects, is_active, created_at, updated_at) "
            "VALUES (?, ?, ?, ?, ?, 1, ?, ?)",
            (telegram_id, username, display_name, role_name, allowed_projects, now, now),
        )
        self._conn.commit()
        logger.info("User added/updated: %s (%d) role=%s", username, telegram_id, role_name)

    def update_user(self, telegram_id: int, **kwargs) -> bool:
        user = self.get_user(telegram_id)
        if not user:
            return False
        allowed = {"username", "display_name", "role_name", "allowed_projects", "is_active"}
        updates = {k: v for k, v in kwargs.items() if k in allowed}
        if not updates:
            return False
        updates["updated_at"] = time.time()
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [telegram_id]
        self._conn.execute(f"UPDATE users SET {set_clause} WHERE telegram_id = ?", values)
        self._conn.commit()
        return True

    def delete_user(self, telegram_id: int) -> bool:
        cur = self._conn.execute("DELETE FROM users WHERE telegram_id = ?", (telegram_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # ── CRUD: Roles ──────────────────────────────────────────────────

    def get_role(self, name: str) -> RoleRecord | None:
        row = self._conn.execute("SELECT * FROM roles WHERE name = ?", (name,)).fetchone()
        return self._row_to_role(row) if row else None

    def list_roles(self) -> list[RoleRecord]:
        rows = self._conn.execute("SELECT * FROM roles ORDER BY name").fetchall()
        return [self._row_to_role(r) for r in rows]

    def add_role(
        self, name: str, allowed_models: str = "haiku",
        can_bash: bool = False, can_write: bool = False,
        can_push: bool = False, can_creds: bool = False,
        budget_limit: float = 0.0,
    ) -> None:
        now = time.time()
        self._conn.execute(
            "INSERT OR REPLACE INTO roles "
            "(name, allowed_models, can_bash, can_write, can_push, can_creds, budget_limit, created_at) "
            "VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
            (name, allowed_models, int(can_bash), int(can_write), int(can_push),
             int(can_creds), budget_limit, now),
        )
        self._conn.commit()
        logger.info("Role added/updated: %s", name)

    def update_role(self, name: str, **kwargs) -> bool:
        role = self.get_role(name)
        if not role:
            return False
        allowed = {"allowed_models", "can_bash", "can_write", "can_push", "can_creds", "budget_limit"}
        updates = {}
        for k, v in kwargs.items():
            if k in allowed:
                if k.startswith("can_"):
                    v = int(v)
                updates[k] = v
        if not updates:
            return False
        set_clause = ", ".join(f"{k} = ?" for k in updates)
        values = list(updates.values()) + [name]
        self._conn.execute(f"UPDATE roles SET {set_clause} WHERE name = ?", values)
        self._conn.commit()
        return True

    def delete_role(self, name: str) -> tuple[bool, str]:
        """Delete a role.  Fails if users are still assigned to it."""
        count = self._conn.execute(
            "SELECT COUNT(*) FROM users WHERE role_name = ?", (name,)
        ).fetchone()[0]
        if count > 0:
            return False, f"Нельзя удалить: {count} пользователей с этой ролью"
        cur = self._conn.execute("DELETE FROM roles WHERE name = ?", (name,))
        self._conn.commit()
        return cur.rowcount > 0, ""

    # ── CRUD: Project Hidden Paths ──────────────────────────────────

    def list_hidden_paths(self, project_name: str | None = None) -> list[dict]:
        """List hidden path rules, optionally filtered by project."""
        if project_name:
            rows = self._conn.execute(
                "SELECT id, project_name, path, require_flag FROM project_hidden_paths WHERE project_name = ? ORDER BY path",
                (project_name,),
            ).fetchall()
        else:
            rows = self._conn.execute(
                "SELECT id, project_name, path, require_flag FROM project_hidden_paths ORDER BY project_name, path"
            ).fetchall()
        return [{"id": r["id"], "project_name": r["project_name"], "path": r["path"], "require_flag": r["require_flag"]} for r in rows]

    def add_hidden_path(self, project_name: str, path: str, require_flag: str = "can_creds") -> None:
        """Add a hidden path rule for a project."""
        valid_flags = {"can_creds", "can_push", "can_bash", "can_write"}
        if require_flag not in valid_flags:
            raise ValueError(f"Invalid flag '{require_flag}'. Must be one of: {valid_flags}")
        self._conn.execute(
            "INSERT OR REPLACE INTO project_hidden_paths (project_name, path, require_flag) VALUES (?, ?, ?)",
            (project_name, path, require_flag),
        )
        self._conn.commit()
        logger.info("Hidden path added: %s/%s (require: %s)", project_name, path, require_flag)

    def remove_hidden_path(self, rule_id: int) -> bool:
        """Remove a hidden path rule by ID."""
        cur = self._conn.execute("DELETE FROM project_hidden_paths WHERE id = ?", (rule_id,))
        self._conn.commit()
        return cur.rowcount > 0

    # ── CRUD: Chat-Project Bindings ─────────────────────────────────

    def get_chat_project(self, chat_id: int) -> str | None:
        """Get the project bound to a chat. Returns project_name or None."""
        row = self._conn.execute(
            "SELECT project_name FROM chat_projects WHERE chat_id = ?", (chat_id,)
        ).fetchone()
        return row["project_name"] if row else None

    def set_chat_project(self, chat_id: int, project_name: str) -> None:
        """Bind a chat to a project."""
        now = time.time()
        self._conn.execute(
            "INSERT INTO chat_projects (chat_id, project_name, created_at, updated_at) "
            "VALUES (?, ?, ?, ?) "
            "ON CONFLICT(chat_id) DO UPDATE SET project_name = ?, updated_at = ?",
            (chat_id, project_name, now, now, project_name, now),
        )
        self._conn.commit()
        logger.info("Chat %d bound to project '%s'", chat_id, project_name)

    def remove_chat_project(self, chat_id: int) -> bool:
        """Unbind a project from a chat."""
        cur = self._conn.execute(
            "DELETE FROM chat_projects WHERE chat_id = ?", (chat_id,)
        )
        self._conn.commit()
        return cur.rowcount > 0

    def list_chat_projects(self) -> list[tuple[int, str]]:
        """List all chat-project bindings."""
        rows = self._conn.execute(
            "SELECT chat_id, project_name FROM chat_projects ORDER BY chat_id"
        ).fetchall()
        return [(r["chat_id"], r["project_name"]) for r in rows]

    # ── Helpers ──────────────────────────────────────────────────────

    @staticmethod
    def _row_to_role(row: sqlite3.Row) -> RoleRecord:
        return RoleRecord(
            name=row["name"],
            allowed_models=[m.strip() for m in row["allowed_models"].split(",") if m.strip()],
            can_bash=bool(row["can_bash"]),
            can_write=bool(row["can_write"]),
            can_push=bool(row["can_push"]),
            can_creds=bool(row["can_creds"]),
            budget_limit=row["budget_limit"],
            created_at=row["created_at"],
        )

    @staticmethod
    def _row_to_user(row: sqlite3.Row) -> UserRecord:
        projects_raw = row["allowed_projects"]
        projects = [p.strip() for p in projects_raw.split(",") if p.strip()]
        return UserRecord(
            telegram_id=row["telegram_id"],
            username=row["username"],
            display_name=row["display_name"],
            role_name=row["role_name"],
            allowed_projects=projects,
            is_active=bool(row["is_active"]),
            created_at=row["created_at"],
            updated_at=row["updated_at"],
        )
