"""Claude Agent SDK runner — replaces CLI subprocess management.

Uses the official claude-agent-sdk to interact with Claude Code,
providing typed messages, session management, and real-time progress.

Dynamically reads MEMORY.md and appends it to the system prompt
on every invocation so Claude always has up-to-date memory context.
"""

import asyncio
import json
import logging
import os
import time
from dataclasses import dataclass, field
from pathlib import Path
from typing import Callable, Awaitable

from claude_agent_sdk import (
    ClaudeAgentOptions,
    HookMatcher,
    query as sdk_query,
    AssistantMessage,
    ResultMessage,
    SystemMessage,
    TextBlock,
    ToolUseBlock,
)

from .task_queue import TaskQueue
from .prompt_router import load_prompt
from .mcp_config import build_mcp_servers_dict


def _find_claude_pid(work_dir: str) -> int | None:
    """Find the PID of a Claude CLI subprocess working in the given directory.

    Scans /proc for processes whose cmdline contains 'claude' and the work_dir.
    Returns the PID or None if not found.
    """
    our_pid = os.getpid()
    proc_path = Path("/proc")
    try:
        for entry in proc_path.iterdir():
            if not entry.name.isdigit():
                continue
            pid = int(entry.name)
            if pid == our_pid:
                continue
            try:
                cmdline = (entry / "cmdline").read_bytes().decode(errors="replace")
                if "claude" in cmdline and work_dir in cmdline:
                    return pid
            except (PermissionError, FileNotFoundError, ProcessLookupError):
                continue
    except Exception:
        pass
    return None

logger = logging.getLogger(__name__)

# Path to the main MEMORY.md file that describes the memory system
MEMORY_MD_PATH = Path("/home/claude/.claude/projects/-home-claude-projects/memory/MEMORY.md")


@dataclass
class TaskResult:
    """Result of a Claude Code execution."""

    success: bool
    output: str
    duration: float
    session_id: str = ""
    return_code: int | None = None
    error: str = ""
    was_timeout: bool = False
    cost_usd: float = 0.0
    model: str = ""


@dataclass
class ProgressEvent:
    """A meaningful progress event extracted from SDK messages."""
    tool_name: str = ""
    tool_input: dict = field(default_factory=dict)
    text_chunk: str = ""
    event_type: str = ""  # "tool_use", "text", "result"

    @property
    def description(self) -> str:
        """Human-readable description of what's happening."""
        if self.event_type == "text" and self.text_chunk:
            t = self.text_chunk.strip()
            if len(t) > 200:
                t = t[:200] + "..."
            return t

        if self.event_type == "tool_use":
            return _describe_tool_call(self.tool_name, self.tool_input)

        return ""


def _describe_tool_call(name: str, inp: dict) -> str:
    """Generate a short human-readable description of a tool call."""
    match name:
        case "Read":
            path = inp.get("file_path", "?")
            return f"📄 Reading {_short_path(path)}"
        case "Edit":
            path = inp.get("file_path", "?")
            return f"✏️ Editing {_short_path(path)}"
        case "Write":
            path = inp.get("file_path", "?")
            return f"📝 Writing {_short_path(path)}"
        case "Bash":
            cmd = inp.get("command", "")
            desc = inp.get("description", "")
            if desc:
                return f"⚡ {desc}"
            if len(cmd) > 80:
                cmd = cmd[:80] + "..."
            return f"⚡ $ {cmd}"
        case "Grep":
            pattern = inp.get("pattern", "?")
            path = inp.get("path", ".")
            return f"🔍 Grep '{pattern}' in {_short_path(path)}"
        case "Glob":
            pattern = inp.get("pattern", "?")
            return f"📂 Glob {pattern}"
        case "WebFetch":
            url = inp.get("url", "?")
            return f"🌐 Fetching {url[:60]}"
        case "WebSearch":
            query = inp.get("query", "?")
            return f"🔎 Searching: {query[:60]}"
        case "Task":
            desc = inp.get("description", "sub-task")
            return f"🤖 Agent: {desc}"
        case "TodoWrite":
            return "📋 Updating task list"
        case "NotebookEdit":
            path = inp.get("notebook_path", "?")
            return f"📓 Editing notebook {_short_path(path)}"
        case _:
            if name.startswith("mcp__"):
                short = name.split("__")[-1]
                return f"🔌 MCP: {short}"
            return f"🔧 {name}"


def _truncate_for_log(data: dict, max_val_len: int = 2000) -> dict:
    """Truncate large values in a dict for event logging."""
    result = {}
    for k, v in data.items():
        if isinstance(v, str) and len(v) > max_val_len:
            result[k] = v[:max_val_len] + f"... ({len(v)} chars)"
        else:
            result[k] = v
    return result


def _short_path(path: str) -> str:
    """Shorten a file path for display."""
    if len(path) <= 50:
        return path
    parts = path.split("/")
    if len(parts) <= 3:
        return path
    return "/".join(parts[:2]) + "/.../" + parts[-1]


class PlanApprovalManager:
    """Intercepts Claude's native ExitPlanMode tool call for Telegram approval.

    Uses PreToolUse hook on ExitPlanMode — when Claude finishes writing a plan
    and wants approval, the hook fires, sends the plan via Telegram bot buttons,
    and waits for the user to approve or reject.
    """

    def __init__(
        self,
        task: "RunningTask",
        send_plan_callback: Callable,
    ):
        self.task = task
        self._send_plan = send_plan_callback

    async def pre_tool_use_hook(
        self,
        hook_input: dict,
        tool_use_id: str | None,
        context: dict,
    ) -> dict:
        """PreToolUse hook: intercepts ExitPlanMode to get Telegram approval."""
        tool_name = hook_input.get("tool_name", "")
        logger.debug("PreToolUse hook: tool=%s task=#%d", tool_name, self.task.task_id)

        if tool_name != "ExitPlanMode":
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "allow",
                }
            }

        # ExitPlanMode called — Claude has a plan ready
        try:
            plan_text = self._read_plan_file(hook_input, self.task.work_dir) or self.task.current_text[-3000:]
            logger.info("Plan approval hook for task #%d (plan: %d chars)", self.task.task_id, len(plan_text))

            future = await self._send_plan(self.task, plan_text)

            try:
                approved = await asyncio.wait_for(future, timeout=300)
            except asyncio.TimeoutError:
                approved = True
                logger.info("Plan approval timed out, auto-approving task #%d", self.task.task_id)

            logger.info("Plan %s for task #%d", "approved" if approved else "rejected", self.task.task_id)

        except Exception:
            logger.exception("Plan approval failed, auto-approving task #%d", self.task.task_id)
            approved = True

        if approved:
            return {
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "allow",
                }
            }
        else:
            return {
                "continue_": False,
                "stopReason": "Plan rejected by user",
                "hookSpecificOutput": {
                    "hookEventName": "PreToolUse",
                    "permissionDecision": "deny",
                    "permissionDecisionReason": "Plan rejected by user",
                },
            }

    @staticmethod
    def _read_plan_file(hook_input: dict, work_dir: Path | None = None) -> str:
        """Try to read the plan file from Claude's plan mode.

        Checks multiple locations: hook_input cwd, task work_dir, home dir.
        """
        # Collect candidate directories
        candidates = []
        cwd = hook_input.get("cwd", "")
        if cwd:
            candidates.append(Path(cwd))
        if work_dir:
            candidates.append(work_dir)
        candidates.append(Path.home())

        for base in candidates:
            plans_dir = base / ".claude" / "plans"
            if not plans_dir.exists():
                continue
            try:
                plan_files = sorted(
                    plans_dir.glob("*.md"),
                    key=lambda p: p.stat().st_mtime,
                    reverse=True,
                )
                if plan_files:
                    content = plan_files[0].read_text(errors="replace")[:3000]
                    logger.debug("Read plan from %s", plan_files[0])
                    return content
            except Exception:
                continue
        return ""


@dataclass
class RunningTask:
    """Represents a currently running Claude task."""

    task_id: int  # SQLite task ID
    chat_id: int
    message_id: int
    prompt: str
    work_dir: Path
    started_at: float = field(default_factory=time.time)
    last_progress_at: float = field(default_factory=time.time)
    cancelled: bool = False
    # Progress tracking
    recent_events: list[str] = field(default_factory=list)
    current_text: str = ""
    turn_count: int = 0
    last_text_at: float = 0.0  # last time intermediate text was sent to chat
    # Agent teams tracking
    team: bool = False
    team_agents: int = 0  # spawned agents count

    @property
    def elapsed(self) -> float:
        return time.time() - self.started_at

    def add_event(self, description: str) -> None:
        """Add a progress event, keeping last 5."""
        if description:
            self.recent_events.append(description)
            if len(self.recent_events) > 5:
                self.recent_events = self.recent_events[-5:]


def _read_memory_md() -> str:
    """Read the main MEMORY.md file for appending to system prompt.

    Returns empty string if file doesn't exist or can't be read.
    """
    try:
        if MEMORY_MD_PATH.exists():
            content = MEMORY_MD_PATH.read_text(encoding="utf-8").strip()
            if content:
                return content
    except Exception:
        logger.warning("Could not read MEMORY.md from %s", MEMORY_MD_PATH, exc_info=True)
    return ""


class SDKRunner:
    """Manages Claude Code via the official Agent SDK.

    Drop-in replacement for ClaudeRunner with the same public API.
    Uses claude-agent-sdk instead of raw subprocess management.
    """

    def __init__(
        self,
        claude_cli: str,
        work_dir: Path,
        task_queue: TaskQueue,
        max_execution_time: int = 1800,
        progress_interval: int = 30,
        system_prompt: str = "",
        max_budget_usd: float = 0,
        default_model: str = "haiku",
        sandbox_enabled: bool = False,
        sandbox_script: str = "",
        access_mgr: "AccessManager | None" = None,
    ):
        self.claude_cli = claude_cli
        self.work_dir = work_dir
        self.task_queue = task_queue
        self.max_execution_time = max_execution_time
        self.progress_interval = progress_interval
        self.system_prompt = system_prompt
        self.max_budget_usd = max_budget_usd
        self.default_model = default_model
        self.sandbox_enabled = sandbox_enabled
        self.sandbox_script = sandbox_script
        self.access_mgr = access_mgr
        # OpenRouter fallback config (for Kimi as last-resort model)
        self.openrouter_api_key = os.getenv("OPENROUTER_API_KEY", "")
        self.openrouter_model = os.getenv("OPENROUTER_MODEL", "moonshotai/kimi-k2.5")
        self._active_tasks: dict[int, RunningTask] = {}  # task_id -> RunningTask

        # SDK stream close timeout: must be >= max_execution_time so hooks
        # (plan approval, etc.) can work for the entire task duration.
        # The SDK reads this from os.environ on each query.
        os.environ["CLAUDE_CODE_STREAM_CLOSE_TIMEOUT"] = str(max_execution_time * 1000)

    @property
    def active_task_count(self) -> int:
        return len(self._active_tasks)

    def get_running_tasks_for_chat(self, chat_id: int) -> list[RunningTask]:
        """Get all currently running in-memory tasks for a chat."""
        return [t for t in self._active_tasks.values() if t.chat_id == chat_id]

    def get_active_task_by_id(self, task_id: int) -> RunningTask | None:
        return self._active_tasks.get(task_id)

    def clear_session(self, chat_id: int) -> bool:
        """Clear conversation history for a chat."""
        return self.task_queue.clear_session(chat_id)

    async def cancel_task_by_id(self, task_id: int) -> bool:
        """Cancel a specific running task by its ID."""
        task = self._active_tasks.get(task_id)
        if not task:
            return False
        task.cancelled = True
        self._active_tasks.pop(task_id, None)
        self.task_queue.cancel(task_id)
        return True

    async def cancel_all_for_chat(self, chat_id: int) -> int:
        """Cancel all running + pending tasks for a chat. Returns total cancelled."""
        cancelled = 0

        # Cancel running tasks (in memory)
        running = self.get_running_tasks_for_chat(chat_id)
        for task in running:
            task.cancelled = True
            self._active_tasks.pop(task.task_id, None)
            self.task_queue.cancel(task.task_id)
            cancelled += 1

        # Cancel pending tasks (in DB)
        cancelled += self.task_queue.cancel_pending_for_chat(chat_id)

        return cancelled

    def _build_sandbox_env(self, access: "AccessResult") -> dict[str, str]:
        """Build environment variables for the sandbox wrapper script.

        Instead of building a full command string (which breaks cli_path),
        we pass mounts and the real Claude CLI path via env vars.
        The sandbox script reads SANDBOX_MOUNTS_JSON and SANDBOX_CLAUDE_CLI,
        wraps $@ (SDK arguments) inside bwrap, and forwards them to the real Claude.
        """
        mounts_data = [
            {"src": m.src, "dst": m.dst, "mode": m.mode}
            for m in access.sandbox_mounts
        ]
        logger.info("Sandbox: %d mounts for role=%s", len(mounts_data),
                     access.role.name if access.role else "?")
        env = {
            "SANDBOX_MOUNTS_JSON": json.dumps(mounts_data),
            "SANDBOX_CLAUDE_CLI": self.claude_cli,
        }
        if access.hidden_paths:
            env["SANDBOX_HIDDEN_PATHS"] = json.dumps(access.hidden_paths)
            logger.info("Sandbox: %d hidden paths", len(access.hidden_paths))
        return env

    def _build_system_prompt(
        self, task_type: str | None = None, team: bool = False,
        access: "AccessResult | None" = None,
        project: str | None = None,
    ) -> str:
        """Build the full system prompt with dynamic MEMORY.md and magic prompt."""
        parts = []

        if self.system_prompt:
            parts.append(self.system_prompt)

        # Dynamic MEMORY.md append
        memory_content = _read_memory_md()
        if memory_content:
            parts.append(memory_content)

        # Role context (Layer 3 — access control instructions)
        if access and access.user and self.access_mgr:
            role_prompt = self.access_mgr.build_role_prompt(access.user.telegram_id, project=project)
            if role_prompt:
                parts.append(role_prompt)

        # Magic prompt for task specialization
        if task_type:
            magic = load_prompt(task_type)
            if magic:
                parts.append(f"# Task specialization: {task_type}\n\n{magic}")
                logger.info("Applied magic prompt: %s", task_type)

        # Agent teams mode
        if team:
            parts.append(
                "# Режим команды (Agent Teams)\n\n"
                "Создай команду агентов для параллельной работы над задачей.\n"
                "Разбей задачу на подзадачи, назначь каждому агенту свою часть.\n"
                "Синтезируй результаты в итоговый ответ."
            )

        return "\n\n".join(parts)

    def _build_options(
        self,
        task: RunningTask,
        model: str | None = None,
        thinking: bool = False,
        task_type: str | None = None,
        team: bool = False,
        fork_session: bool = False,
        hooks: dict | None = None,
        access: "AccessResult | None" = None,
        project: str | None = None,
    ) -> ClaudeAgentOptions:
        """Build SDK options for a task."""
        existing_session = self.task_queue.get_session(task.chat_id)

        # Use append mode to add our prompt to Claude Code's default system prompt
        # (not replace it). SDK sends --append-system-prompt when system_prompt
        # is {"type": "preset", "append": "..."}.
        full_prompt = self._build_system_prompt(task_type=task_type, team=team, access=access, project=project)
        system_prompt_config = {"type": "preset", "append": full_prompt} if full_prompt else None

        # Dynamic MCP servers from config (re-read every call for hot-reload)
        mcp_servers = build_mcp_servers_dict()

        # Determine CLI path — sandbox wrapper or direct
        cli_path = self.claude_cli
        sandbox_env: dict[str, str] = {}
        if self.sandbox_enabled and self.sandbox_script and access and access.sandbox_mounts:
            cli_path = self.sandbox_script
            sandbox_env = self._build_sandbox_env(access)

        opts = ClaudeAgentOptions(
            system_prompt=system_prompt_config,
            permission_mode="bypassPermissions",
            cwd=str(task.work_dir),
            cli_path=cli_path,
            mcp_servers=mcp_servers if mcp_servers else {},
            env=sandbox_env,
        )

        if mcp_servers:
            logger.debug("MCP servers: %s", list(mcp_servers.keys()))

        # Model selection: explicit modifier > default_model
        effective_model = model or self.default_model

        # Kimi mode: redirect to OpenRouter instead of Anthropic
        if effective_model == "kimi" and self.openrouter_api_key:
            opts.env = {**opts.env, **{
                "ANTHROPIC_BASE_URL": "https://openrouter.ai/api",
                "ANTHROPIC_AUTH_TOKEN": self.openrouter_api_key,
                "ANTHROPIC_API_KEY": "",
                "ANTHROPIC_DEFAULT_SONNET_MODEL": self.openrouter_model,
            }}
            opts.model = "sonnet"  # CLI accepts this, OpenRouter maps to Kimi
            # Don't resume Anthropic sessions with Kimi (different provider)
            existing_session = None
            logger.info("Kimi mode via OpenRouter for task #%d", task.task_id)
        elif effective_model:
            opts.model = effective_model
            if model:
                logger.info("Model override: %s for task #%d", model, task.task_id)
            else:
                logger.debug("Default model: %s for task #%d", effective_model, task.task_id)

        # Extended thinking
        if thinking:
            opts.thinking = {"type": "enabled", "budget_tokens": 32000}
            logger.info("Extended thinking enabled for task #%d", task.task_id)

        if self.max_budget_usd > 0:
            opts.max_budget_usd = self.max_budget_usd

        # Agent teams mode
        if team:
            opts.env = {**opts.env, "CLAUDE_CODE_EXPERIMENTAL_AGENT_TEAMS": "1"}
            opts.settings = json.dumps({"teammateMode": "in-process"})
            existing_session = None  # team always starts fresh
            logger.info("Team mode enabled for task #%d", task.task_id)

        if existing_session:
            opts.resume = existing_session
            if fork_session:
                opts.fork_session = True
                logger.info(
                    "Forking session %s for task #%d (chat %s) in %s",
                    existing_session[:12], task.task_id, task.chat_id, task.work_dir,
                )
            else:
                logger.info(
                    "Resuming session %s for task #%d (chat %s) in %s",
                    existing_session[:12], task.task_id, task.chat_id, task.work_dir,
                )
        else:
            logger.info(
                "New session for task #%d (chat %s) in %s",
                task.task_id, task.chat_id, task.work_dir,
            )

        if hooks:
            opts.hooks = hooks

        return opts

    async def run(
        self,
        task_id: int,
        chat_id: int,
        message_id: int,
        prompt: str,
        on_progress: Callable[[RunningTask, str], Awaitable[None]] | None = None,
        on_text: Callable[[RunningTask, str], Awaitable[None]] | None = None,
        project_dir: str | None = None,
        model: str | None = None,
        thinking: bool = False,
        task_type: str | None = None,
        team: bool = False,
        fork_session: bool = False,
        on_plan: Callable | None = None,
        access: "AccessResult | None" = None,
    ) -> TaskResult:
        """Run Claude via SDK and report progress."""
        # If project_dir matches workspace dir name, use workspace directly
        if project_dir and project_dir == self.work_dir.name:
            cwd = self.work_dir
        elif project_dir:
            cwd = self.work_dir / project_dir
        else:
            cwd = self.work_dir
        if not cwd.exists():
            cwd.mkdir(parents=True, exist_ok=True)

        task = RunningTask(
            task_id=task_id,
            chat_id=chat_id,
            message_id=message_id,
            prompt=prompt,
            work_dir=cwd,
            team=team,
        )
        self._active_tasks[task_id] = task

        start_time = time.time()
        try:
            result = await self._execute(
                task, on_progress, on_text, model, thinking, task_type, team,
                fork_session=fork_session, on_plan=on_plan, access=access,
                project=project_dir,
            )
            if result.session_id:
                self.task_queue.set_session(chat_id, result.session_id)
            return result
        except Exception as e:
            logger.exception("Unexpected error running Claude for task #%d", task_id)
            return TaskResult(
                success=False,
                output="",
                duration=time.time() - start_time,
                error=str(e),
            )
        finally:
            self._active_tasks.pop(task_id, None)

    async def _execute(
        self,
        task: RunningTask,
        on_progress: Callable[[RunningTask, str], Awaitable[None]] | None,
        on_text: Callable[[RunningTask, str], Awaitable[None]] | None = None,
        model: str | None = None,
        thinking: bool = False,
        task_type: str | None = None,
        team: bool = False,
        fork_session: bool = False,
        on_plan: Callable | None = None,
        access: "AccessResult | None" = None,
        project: str | None = None,
    ) -> TaskResult:
        """Execute Claude via SDK with message parsing for progress.

        Supports rate-limit fallback: opus → sonnet → haiku → kimi.
        """
        # Fallback chain for rate limits: expensive → cheaper
        FALLBACK_CHAIN = {
            "opus": "sonnet",
            "sonnet": "haiku",
            "haiku": "kimi",  # last resort — Kimi via OpenRouter
        }
        RATE_LIMIT_WAIT = 15  # seconds to wait before retry/fallback

        current_model = model or self.default_model
        max_retries = 3  # up to 3 retries: retry same → fallback

        # Log system prompt and model info once (before first attempt)
        full_system_prompt = self._build_system_prompt(task_type=task_type, team=team, access=access, project=project)
        if full_system_prompt:
            self.task_queue.log_event(task.task_id, "system_prompt", full_system_prompt)
        existing_session = self.task_queue.get_session(task.chat_id)
        self.task_queue.log_event(task.task_id, "model_info", json.dumps({
            "model": current_model or self.default_model,
            "thinking": thinking,
            "task_type": task_type,
            "team": team,
            "session_resumed": bool(existing_session),
        }, ensure_ascii=False))

        # Plan approval: hook ExitPlanMode to get Telegram approval
        plan_manager = None
        sdk_hooks = None
        if on_plan:
            plan_manager = PlanApprovalManager(
                task=task,
                send_plan_callback=on_plan,
            )
            sdk_hooks = {
                "PreToolUse": [
                    HookMatcher(
                        matcher="ExitPlanMode",
                        hooks=[plan_manager.pre_tool_use_hook],
                        timeout=360,
                    ),
                ],
            }

        for attempt in range(max_retries + 1):
            options = self._build_options(
                task, model=current_model, thinking=thinking,
                task_type=task_type, team=team,
                fork_session=fork_session, hooks=sdk_hooks,
                access=access, project=project,
            )

            session_id = ""
            result_text = ""
            cost_usd = 0.0
            is_error = False
            rate_limited = False

            try:
                async def _run_query():
                    nonlocal session_id, result_text, cost_usd, is_error, rate_limited

                    async for message in sdk_query(prompt=task.prompt, options=options):
                        if task.cancelled:
                            break

                        if isinstance(message, AssistantMessage):
                            # Extract tool_use and text blocks for progress
                            for block in message.content:
                                if isinstance(block, ToolUseBlock):
                                    desc = _describe_tool_call(block.name, block.input)
                                    task.add_event(desc)
                                    task.turn_count += 1
                                    logger.debug("Tool call: %s", desc)

                                    # Log tool_use event
                                    self.task_queue.log_event(task.task_id, "tool_use", json.dumps({
                                        "name": block.name,
                                        "input": _truncate_for_log(block.input),
                                    }, ensure_ascii=False, default=str))

                                    # Persist progress to DB
                                    self._persist_progress(task)

                                    # Send progress if enough time passed
                                    if on_progress and self._should_send_progress(task):
                                        task.last_progress_at = time.time()
                                        await on_progress(task, self._make_progress_text(task))

                                elif isinstance(block, TextBlock):
                                    task.current_text += block.text
                                    # Log text event
                                    self.task_queue.log_event(task.task_id, "text", block.text)

                                    # Send intermediate text to chat (with 5s debounce)
                                    text_stripped = block.text.strip()
                                    if on_text and len(text_stripped) > 20:
                                        now = time.time()
                                        if now - task.last_text_at >= 5:
                                            task.last_text_at = now
                                            await on_text(task, text_stripped)

                                    # Send progress on text blocks too (intermediate results)
                                    if on_progress and self._should_send_progress(task):
                                        task.last_progress_at = time.time()
                                        await on_progress(task, self._make_progress_text(task))

                            # Check for API errors (rate limit detection)
                            if message.error:
                                err_type = ""
                                if isinstance(message.error, dict):
                                    err_type = message.error.get("type", "")
                                else:
                                    err_type = getattr(message.error, "type", "")
                                if err_type == "rate_limit":
                                    rate_limited = True
                                    logger.warning("Rate limited on model %s", current_model or "default")
                                    self.task_queue.log_event(task.task_id, "rate_limit", json.dumps({
                                        "model": current_model or "default",
                                    }, ensure_ascii=False))
                                else:
                                    is_error = True
                                    logger.warning("Claude API error: %s", err_type)
                                    self.task_queue.log_event(task.task_id, "error", str(message.error))

                        elif isinstance(message, ResultMessage):
                            session_id = message.session_id or ""
                            result_text = message.result or ""
                            cost_usd = message.total_cost_usd or 0.0
                            is_error = message.is_error
                            # Log result event
                            self.task_queue.log_event(task.task_id, "result", json.dumps({
                                "cost_usd": cost_usd,
                                "is_error": is_error,
                                "model": current_model or self.default_model,
                            }, ensure_ascii=False))

                        elif isinstance(message, SystemMessage):
                            if message.subtype == "init":
                                init_session = message.data.get("session_id", "")
                                if init_session:
                                    session_id = init_session
                                    self.task_queue.set_session(task.chat_id, init_session)
                                    logger.debug("Session init: %s", session_id[:12])
                                # Try to find and save the Claude CLI PID for recovery
                                cli_pid = _find_claude_pid(str(task.work_dir))
                                if cli_pid:
                                    self.task_queue.set_pid(task.task_id, cli_pid)
                                    logger.debug("Saved Claude CLI PID %d for task #%d", cli_pid, task.task_id)
                            elif message.subtype == "rate_limit_event":
                                # CLI handles rate limits internally (wait + retry)
                                # Just log and let it continue
                                logger.info("Rate limit event (CLI will retry): task #%d", task.task_id)
                            elif message.subtype in ("subagent_start", "SubagentStart"):
                                task.team_agents += 1
                                logger.info("Team agent spawned (#%d total) for task #%d",
                                            task.team_agents, task.task_id)
                            elif message.subtype in ("subagent_stop", "SubagentStop"):
                                logger.info("Team agent stopped for task #%d", task.task_id)
                            else:
                                logger.debug("System message: %s", message.subtype)

                await asyncio.wait_for(_run_query(), timeout=self.max_execution_time)

            except asyncio.TimeoutError:
                logger.warning("Task #%d timed out after %ds", task.task_id, self.max_execution_time)
                return TaskResult(
                    success=False,
                    output=task.current_text or "",
                    duration=task.elapsed,
                    error=f"Timeout after {self.max_execution_time}s",
                    was_timeout=True,
                    model=current_model or "",
                )
            except Exception as e:
                error_msg = str(e)
                # SDK 0.1.37 doesn't know rate_limit_event type from CLI 2.1.45+
                # It throws MessageParseError("Unknown message type: rate_limit_event")
                if "rate" in error_msg.lower() and "limit" in error_msg.lower():
                    rate_limited = True
                    logger.warning("Rate limit on model %s: %s", current_model or "default", error_msg)
                    self.task_queue.log_event(task.task_id, "rate_limit", json.dumps({
                        "model": current_model or "default",
                        "error": error_msg[:500],
                    }, ensure_ascii=False))
                else:
                    logger.error("SDK error for task #%d: %s", task.task_id, error_msg)
                    if self.task_queue.get_session(task.chat_id):
                        logger.info("Clearing stale session for task #%d (chat %s)", task.task_id, task.chat_id)
                        self.task_queue.clear_session(task.chat_id)
                    return TaskResult(
                        success=False,
                        output=result_text or task.current_text,
                        duration=task.elapsed,
                        error=error_msg[:500],
                        model=current_model or "",
                    )

            # Rate limit handling: wait, then fallback to cheaper model
            if rate_limited:
                # First attempt with same model: just wait and retry
                if attempt == 0:
                    logger.info("Rate limit — waiting %ds before retry (task #%d)", RATE_LIMIT_WAIT, task.task_id)
                    if on_progress:
                        await on_progress(task, f"⏳ Rate limit, жду {RATE_LIMIT_WAIT}с...")
                    await asyncio.sleep(RATE_LIMIT_WAIT)
                    continue

                # Subsequent attempts: fallback to cheaper model
                if current_model in FALLBACK_CHAIN:
                    fallback = FALLBACK_CHAIN[current_model]
                    # Skip kimi fallback if no OpenRouter key configured
                    if fallback == "kimi" and not self.openrouter_api_key:
                        logger.warning("Kimi fallback unavailable (no OPENROUTER_API_KEY)")
                    else:
                        logger.info("Rate limit fallback: %s → %s for task #%d", current_model or "default", fallback, task.task_id)
                        self.task_queue.log_event(task.task_id, "rate_limit", json.dumps({
                            "model": current_model or "default",
                            "fallback": fallback,
                        }, ensure_ascii=False))
                        if fallback == "kimi":
                            if on_progress:
                                await on_progress(task, "⚠️ Все модели Claude заняты, переключаюсь на Kimi...")
                            # Clear session — can't resume Anthropic session with different provider
                            self.task_queue.clear_session(task.chat_id)
                            # Team mode can't work with Kimi
                            if team:
                                team = False
                                task.team = False
                        elif on_progress:
                            await on_progress(task, f"⚠️ Rate limit на {current_model or 'opus'}, переключаюсь на {fallback}...")
                        current_model = fallback
                        task.current_text = ""
                        await asyncio.sleep(5)  # Brief pause before fallback
                        continue

                # No more fallbacks available
                logger.warning("Rate limited, no fallback for %s (task #%d)", current_model, task.task_id)
                return TaskResult(
                    success=False,
                    output=result_text or task.current_text,
                    duration=task.elapsed,
                    error=f"Rate limited on {current_model or 'default'}, no fallback available",
                    model=current_model or "",
                )

            # Success or non-retryable error
            return TaskResult(
                success=not is_error,
                output=result_text or task.current_text,
                duration=task.elapsed,
                return_code=0,
                session_id=session_id,
                cost_usd=cost_usd,
                model=current_model or self.default_model or "",
            )

        # Exhausted all retries
        return TaskResult(
            success=False,
            output=result_text or task.current_text,
            duration=task.elapsed,
            error=f"Rate limited on all models after {max_retries + 1} attempts (last: {current_model})",
            model=current_model or "",
        )

    def _persist_progress(self, task: RunningTask) -> None:
        """Write current progress to DB so the admin panel can read it.

        Also checks if the task was cancelled externally (e.g. via admin panel).
        """
        try:
            progress_text = self._make_progress_text(task)
            self.task_queue.update_progress(task.task_id, progress_text)
            # Check if cancelled externally (admin panel sets status=cancelled in DB)
            if not task.cancelled and self.task_queue.is_cancelled(task.task_id):
                logger.info("Task #%d cancelled externally (admin panel)", task.task_id)
                task.cancelled = True
                self.task_queue.log_event(task.task_id, "error", "Cancelled by admin")
        except Exception:
            logger.debug("Failed to persist progress for task #%d", task.task_id, exc_info=True)

    def _should_send_progress(self, task: RunningTask) -> bool:
        return (time.time() - task.last_progress_at) >= self.progress_interval

    # ── Recovery ──────────────────────────────────────────────────────

    async def recover_task(
        self,
        task_id: int,
        chat_id: int,
        message_id: int,
        pid: int | None,
        project_dir: str | None,
        on_progress: Callable[[RunningTask, str], Awaitable[None]] | None = None,
    ) -> TaskResult:
        """Recover a task interrupted by mtbridge restart.

        If the old Claude CLI process is still alive (orphan), wait for it.
        Otherwise resume the session with a recovery prompt.
        """
        pid_alive = False
        if pid:
            try:
                os.kill(pid, 0)
                # Verify it's actually a claude process (PID reuse protection)
                cmdline = Path(f"/proc/{pid}/cmdline").read_bytes().decode(errors="replace")
                pid_alive = "claude" in cmdline
            except (ProcessLookupError, PermissionError, FileNotFoundError):
                pass

        if pid_alive:
            return await self._wait_for_orphan(task_id, chat_id, pid)
        else:
            return await self._resume_with_recovery(
                task_id, chat_id, message_id, project_dir, on_progress,
            )

    async def _wait_for_orphan(self, task_id: int, chat_id: int, pid: int) -> TaskResult:
        """Wait for an orphaned Claude CLI process to finish."""
        start = time.time()
        logger.info("Waiting for orphan PID %d (task #%d)...", pid, task_id)

        while True:
            try:
                os.kill(pid, 0)
            except ProcessLookupError:
                elapsed = time.time() - start
                logger.info("Orphan PID %d finished after %.1fs", pid, elapsed)
                return TaskResult(
                    success=True,
                    output=(
                        "Задача завершена после перезапуска сервиса. "
                        "Вывод недоступен (pipe утрачен), но сессия сохранена. "
                        "Спроси «что ты только что сделал?» для отчёта."
                    ),
                    duration=elapsed,
                )
            except PermissionError:
                break

            if time.time() - start > self.max_execution_time:
                try:
                    os.kill(pid, 9)
                except ProcessLookupError:
                    pass
                return TaskResult(
                    success=False,
                    output="",
                    duration=time.time() - start,
                    error=f"Orphan process timed out after {self.max_execution_time}s",
                    was_timeout=True,
                )

            await asyncio.sleep(5)

        return TaskResult(
            success=False, output="", duration=time.time() - start,
            error="Could not track orphan process",
        )

    async def _resume_with_recovery(
        self,
        task_id: int,
        chat_id: int,
        message_id: int,
        project_dir: str | None,
        on_progress: Callable[[RunningTask, str], Awaitable[None]] | None,
    ) -> TaskResult:
        """Resume a dead task's session with a recovery prompt."""
        session_id = self.task_queue.get_session(chat_id)
        if not session_id:
            return TaskResult(
                success=False, output="", duration=0,
                error="Нет сессии для восстановления — задача потеряна. Попробуй ещё раз.",
            )

        recovery_prompt = (
            "[RECOVERY] Предыдущая сессия была прервана рестартом сервиса. "
            "Проверь: 1) git status / git diff — незакоммиченные изменения, "
            "2) Целостность файлов которые ты редактировал, "
            "3) Что было сделано, что нет. "
            "Доложи пользователю кратко. Если задача почти готова — доделай."
        )

        return await self.run(
            task_id=task_id,
            chat_id=chat_id,
            message_id=message_id,
            prompt=recovery_prompt,
            on_progress=on_progress,
            project_dir=project_dir,
        )

    def _make_progress_text(self, task: RunningTask) -> str:
        """Build a progress update from recent tool events."""
        elapsed = int(task.elapsed)
        minutes = elapsed // 60
        seconds = elapsed % 60

        if minutes > 0:
            time_str = f"{minutes}m {seconds}s"
        else:
            time_str = f"{seconds}s"

        parts = [f"⏳ Task #{task.task_id} — {time_str}, step {task.turn_count}"]

        # Team mode progress
        if task.team and task.team_agents > 0:
            parts.append(f"🤖 Команда: {task.team_agents} агентов")

        if task.recent_events:
            parts.append("")
            for evt in task.recent_events:
                parts.append(evt)

        # Show last snippet of Claude's text output (intermediate result)
        if task.current_text:
            snippet = task.current_text.strip()
            # Take last 300 chars to show what Claude is working on
            if len(snippet) > 300:
                snippet = "..." + snippet[-300:]
            parts.append("")
            parts.append(f"💬 {snippet}")

        return "\n".join(parts)
