#!/bin/bash
# sandbox-claude.sh — bubblewrap wrapper for Claude CLI
#
# Usage: sandbox-claude.sh --mounts-json '<JSON>' -- claude-args...
#
# Mounts JSON format: [{"src":"/host/path","dst":"/sandbox/path","mode":"ro|rw"}, ...]
# Everything after -- is passed to the Claude CLI.

set -euo pipefail

MOUNTS_JSON=""
CLAUDE_ARGS=()

# ── Mode detection ───────────────────────────────────────────────
# Mode 1 (SDK): env vars SANDBOX_MOUNTS_JSON + SANDBOX_CLAUDE_CLI are set.
#   The SDK sets cli_path=this script and passes its own args as $@.
#   We forward $@ to the real Claude CLI inside bwrap.
#
# Mode 2 (CLI): --mounts-json '<JSON>' -- /path/to/claude [claude-args...]
#   Standalone usage for testing.

if [[ -n "${SANDBOX_MOUNTS_JSON:-}" && -n "${SANDBOX_CLAUDE_CLI:-}" ]]; then
    # SDK mode: mounts from env, all $@ goes to the real Claude CLI
    MOUNTS_JSON="$SANDBOX_MOUNTS_JSON"
    CLAUDE_ARGS=("$SANDBOX_CLAUDE_CLI" "$@")
else
    # CLI mode: parse arguments
    while [[ $# -gt 0 ]]; do
        case "$1" in
            --mounts-json)
                MOUNTS_JSON="$2"
                shift 2
                ;;
            --)
                shift
                CLAUDE_ARGS=("$@")
                break
                ;;
            *)
                echo "Unknown argument: $1" >&2
                exit 1
                ;;
        esac
    done

    if [[ -z "$MOUNTS_JSON" ]]; then
        echo "Error: --mounts-json is required (or set SANDBOX_MOUNTS_JSON env var)" >&2
        exit 1
    fi

    if [[ ${#CLAUDE_ARGS[@]} -eq 0 ]]; then
        echo "Error: no Claude CLI command after -- (or set SANDBOX_CLAUDE_CLI env var)" >&2
        exit 1
    fi
fi

# ── Build bwrap arguments ─────────────────────────────────────────

BWRAP_ARGS=(
    --die-with-parent
    --unshare-uts
    --share-net                              # Claude needs internet for API calls
    --ro-bind /usr /usr                      # system libraries
    --ro-bind /lib /lib                      # shared libs
    --ro-bind /bin /bin                      # basic binaries
    --ro-bind /sbin /sbin                    # system binaries
    --ro-bind /etc/resolv.conf /etc/resolv.conf  # DNS resolution
    --ro-bind /etc/ssl /etc/ssl              # TLS certificates
    --ro-bind /etc/hosts /etc/hosts          # hosts file
    --ro-bind /etc/passwd /etc/passwd        # user info (needed by some tools)
    --ro-bind /etc/group /etc/group          # group info
    --ro-bind /proc /proc                    # Docker-compatible (no --unshare-pid)
    --dev-bind /dev /dev                     # Docker-compatible
    --tmpfs /tmp
)

# /lib64 may not exist on all systems
[[ -d /lib64 ]] && BWRAP_ARGS+=(--ro-bind /lib64 /lib64)

# CA certificates (path varies by distro)
[[ -d /etc/ca-certificates ]] && BWRAP_ARGS+=(--ro-bind /etc/ca-certificates /etc/ca-certificates)

# Node.js and Claude CLI (always needed)
CLAUDE_HOME="$(dirname "$(dirname "$(realpath "${CLAUDE_ARGS[0]}")")")"
BWRAP_ARGS+=(--ro-bind "$CLAUDE_HOME" "$CLAUDE_HOME")

# User home essentials — Claude Code needs these
HOME_DIR="$HOME"
BWRAP_ARGS+=(
    --bind "$HOME_DIR/.claude" "$HOME_DIR/.claude"           # Claude config, sessions
    --ro-bind "$HOME_DIR/.local" "$HOME_DIR/.local"          # Claude CLI, npm, etc.
)
# Claude config file in home root
[[ -f "$HOME_DIR/.claude.json" ]] && BWRAP_ARGS+=(--bind "$HOME_DIR/.claude.json" "$HOME_DIR/.claude.json")
[[ -f "$HOME_DIR/.claude.json.template" ]] && BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.claude.json.template" "$HOME_DIR/.claude.json.template")
# Bun runtime
[[ -d "$HOME_DIR/.bun" ]] && BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.bun" "$HOME_DIR/.bun")
# npm/node cache
[[ -d "$HOME_DIR/.npm" ]] && BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.npm" "$HOME_DIR/.npm")
[[ -d "$HOME_DIR/.cache" ]] && BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.cache" "$HOME_DIR/.cache")

# .config may not exist on all systems
[[ -d "$HOME_DIR/.config" ]] && BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.config" "$HOME_DIR/.config")

# Node.js runtime (often in /usr/local or /home/user/.nvm)
if [[ -d "$HOME_DIR/.nvm" ]]; then
    BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.nvm" "$HOME_DIR/.nvm")
fi

# Git config (read-only)
[[ -f "$HOME_DIR/.gitconfig" ]] && BWRAP_ARGS+=(--ro-bind "$HOME_DIR/.gitconfig" "$HOME_DIR/.gitconfig")

# SSH (only if mount includes creds-allowed paths)
# This is controlled by the access module — SSH keys are only mounted for admin roles

# ── Parse and add user mounts ─────────────────────────────────────

# Parse JSON mounts using Python (always available)
while IFS='|' read -r src dst mode; do
    [[ -z "$src" ]] && continue
    if [[ "$mode" == "rw" ]]; then
        # Ensure directory exists for writable mounts
        mkdir -p "$dst" 2>/dev/null || true
        BWRAP_ARGS+=(--bind "$src" "$dst")
    else
        BWRAP_ARGS+=(--ro-bind "$src" "$dst")
    fi
done < <(python3 -c "
import json, sys
mounts = json.loads(sys.argv[1])
for m in mounts:
    print(f\"{m['src']}|{m['dst']}|{m.get('mode','ro')}\")
" "$MOUNTS_JSON")

# ── Hidden paths (tmpfs overlay) ──────────────────────────────────

# SANDBOX_HIDDEN_PATHS is a JSON array of absolute paths to hide.
# We overlay them with --tmpfs so they appear as empty directories.
if [[ -n "${SANDBOX_HIDDEN_PATHS:-}" ]]; then
    while IFS= read -r hidden_path; do
        [[ -z "$hidden_path" ]] && continue
        BWRAP_ARGS+=(--tmpfs "$hidden_path")
    done < <(python3 -c "
import json, sys
for p in json.loads(sys.argv[1]):
    print(p)
" "$SANDBOX_HIDDEN_PATHS")
fi

# ── Environment ───────────────────────────────────────────────────

# Pass through essential environment variables
BWRAP_ARGS+=(
    --setenv HOME "$HOME_DIR"
    --setenv PATH "$PATH"
    --setenv LANG "${LANG:-C.UTF-8}"
    --setenv TERM "${TERM:-xterm-256color}"
    --setenv NODE_PATH "${NODE_PATH:-}"
)

# Pass through Claude-related env vars
for var in ANTHROPIC_API_KEY CLAUDE_CODE_STREAM_CLOSE_TIMEOUT OPENROUTER_API_KEY; do
    [[ -n "${!var:-}" ]] && BWRAP_ARGS+=(--setenv "$var" "${!var}")
done

# ── Launch ────────────────────────────────────────────────────────

exec bwrap "${BWRAP_ARGS[@]}" -- "${CLAUDE_ARGS[@]}"
