"""SQLite database operations with FTS5 search."""

import json
import re
import sqlite3
from datetime import datetime, timedelta, timezone
from typing import List, Optional

from .config import Config
from .models import (
    PersonaTag, Project, SearchResult, Session, SessionLink, SkillUsage
)


class SessionLimitReachedError(Exception):
    """Raised when the free-tier session limit is reached.

    The BSL 1.1 Additional Use Grant allows personal/non-commercial use
    up to 50 sessions. Exceeding this requires a Pro license.
    """
    pass

SCHEMA_SQL = """
CREATE TABLE IF NOT EXISTS sessions (
    id              TEXT PRIMARY KEY NOT NULL,
    title           TEXT NOT NULL,
    surface         TEXT NOT NULL,
    project         TEXT,
    start_date      TEXT NOT NULL,
    end_date        TEXT,
    summary         TEXT,
    decisions       TEXT,
    artifacts       TEXT,
    open_questions  TEXT,
    tags            TEXT,
    created_at      TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS session_skills (
    session_id       TEXT NOT NULL REFERENCES sessions(id),
    skill_name       TEXT NOT NULL,
    skill_source     TEXT,
    invocation_count INTEGER DEFAULT 1,
    PRIMARY KEY (session_id, skill_name)
);

CREATE TABLE IF NOT EXISTS projects (
    name            TEXT PRIMARY KEY,
    description     TEXT,
    expected_skills TEXT,
    default_persona TEXT,
    created_at      TEXT DEFAULT (strftime('%Y-%m-%dT%H:%M:%SZ', 'now'))
);

CREATE TABLE IF NOT EXISTS persona_sessions (
    persona_name    TEXT NOT NULL,
    session_id      TEXT NOT NULL REFERENCES sessions(id),
    relevance_note  TEXT,
    PRIMARY KEY (persona_name, session_id)
);

CREATE TABLE IF NOT EXISTS session_links (
    from_session_id TEXT NOT NULL REFERENCES sessions(id),
    to_session_id   TEXT NOT NULL REFERENCES sessions(id),
    link_type       TEXT DEFAULT 'continues',
    PRIMARY KEY (from_session_id, to_session_id)
);

CREATE INDEX IF NOT EXISTS idx_sessions_start_date ON sessions(start_date);
CREATE INDEX IF NOT EXISTS idx_sessions_project ON sessions(project);
CREATE INDEX IF NOT EXISTS idx_persona_sessions_name ON persona_sessions(persona_name);
"""

FTS_SQL = """
CREATE VIRTUAL TABLE IF NOT EXISTS sessions_fts USING fts5(
    title, summary, decisions, tags, open_questions,
    content=sessions, content_rowid=rowid
);
"""

FTS_TRIGGERS = """
CREATE TRIGGER IF NOT EXISTS sessions_ai AFTER INSERT ON sessions BEGIN
    INSERT INTO sessions_fts(rowid, title, summary, decisions, tags, open_questions)
    VALUES (new.rowid, new.title, new.summary, new.decisions, new.tags, new.open_questions);
END;

CREATE TRIGGER IF NOT EXISTS sessions_au AFTER UPDATE ON sessions BEGIN
    UPDATE sessions_fts SET title = new.title, summary = new.summary,
        decisions = new.decisions, tags = new.tags,
        open_questions = new.open_questions WHERE rowid = old.rowid;
END;

CREATE TRIGGER IF NOT EXISTS sessions_ad AFTER DELETE ON sessions BEGIN
    DELETE FROM sessions_fts WHERE rowid = old.rowid;
END;
"""


class SessionDatabase:
    def __init__(self, config: Optional[Config] = None):
        self.config = config or Config()
        self.config.ensure_db_dir()
        self.conn = sqlite3.connect(self.config.db_path)
        self.conn.row_factory = sqlite3.Row
        self.conn.execute("PRAGMA journal_mode=WAL")
        self.conn.execute("PRAGMA foreign_keys=ON")
        self._init_schema()

    def _init_schema(self):
        self.conn.executescript(SCHEMA_SQL)
        self._migrate_fts_v2()
        self.conn.commit()
        # Migration: clean up any rows with NULL id (bug where raw SQL
        # inserts bypassed the Session dataclass UUID generation).
        null_rows = self.conn.execute(
            "SELECT rowid, title FROM sessions WHERE id IS NULL"
        ).fetchall()
        if null_rows:
            import uuid
            for row in null_rows:
                new_id = str(uuid.uuid4())
                self.conn.execute(
                    "UPDATE sessions SET id = ? WHERE rowid = ?",
                    (new_id, row['rowid'])
                )
            self.conn.commit()

    def _migrate_fts_v2(self):
        """Migrate FTS5 index to v2: add tags and open_questions columns.

        The original FTS5 table indexed only (title, summary, decisions).
        v2 adds (tags, open_questions) so searches match tag keywords and
        unresolved questions. This runs on every startup but only rebuilds
        once -- after that the IF NOT EXISTS in FTS_SQL is a no-op.
        """
        needs_rebuild = False
        try:
            cursor = self.conn.execute("SELECT * FROM sessions_fts LIMIT 0")
            col_names = [desc[0] for desc in cursor.description]
            if 'tags' not in col_names:
                needs_rebuild = True
        except sqlite3.OperationalError:
            # FTS table does not exist yet -- fresh install, just create it
            needs_rebuild = False
            self.conn.executescript(FTS_SQL)
            self.conn.executescript(FTS_TRIGGERS)
            return

        if not needs_rebuild:
            # Already on v2 schema -- ensure triggers exist (idempotent)
            self.conn.executescript(FTS_SQL)
            self.conn.executescript(FTS_TRIGGERS)
            return

        # --- Rebuild: drop old FTS table and triggers, recreate with v2 schema ---
        self.conn.executescript("""
            DROP TRIGGER IF EXISTS sessions_ai;
            DROP TRIGGER IF EXISTS sessions_au;
            DROP TRIGGER IF EXISTS sessions_ad;
            DROP TABLE IF EXISTS sessions_fts;
        """)

        # Create the new FTS5 table with expanded columns
        self.conn.executescript(FTS_SQL)

        # Repopulate from existing sessions
        self.conn.execute("""
            INSERT INTO sessions_fts(rowid, title, summary, decisions, tags, open_questions)
            SELECT rowid, title, summary, decisions, tags, open_questions
            FROM sessions
        """)

        # Recreate triggers for the new column set
        self.conn.executescript(FTS_TRIGGERS)

    def close(self):
        self.conn.close()

    # -- Session CRUD --

    def save_session(self, session: Session) -> str:
        if not session.id:
            raise ValueError(
                "Session id must not be None or empty. "
                "Use the Session dataclass (which auto-generates a UUID) "
                "instead of raw SQL inserts."
            )
        # Enforce BSL 1.1 free-tier session limit.
        # Pro mode (valid LORECONVO_PRO license key) bypasses this check.
        if not self.config.is_pro:
            current_count = self.session_count()
            if current_count >= self.config.max_free_sessions:
                raise SessionLimitReachedError(
                    f"Free tier limit reached: {current_count} of "
                    f"{self.config.max_free_sessions} sessions stored. "
                    "Set your LORECONVO_PRO license key to unlock unlimited sessions, "
                    "or contact info@labyrinthanalyticsconsulting.com to upgrade."
                )
        self.conn.execute(
            """INSERT OR REPLACE INTO sessions
               (id, title, surface, project, start_date, end_date, summary,
                decisions, artifacts, open_questions, tags, created_at)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (
                session.id, session.title, session.surface, session.project,
                session.start_date, session.end_date, session.summary,
                json.dumps(session.decisions), json.dumps(session.artifacts),
                json.dumps(session.open_questions), json.dumps(session.tags),
                session.created_at
            )
        )
        for skill_name in session.skills_used:
            self.conn.execute(
                """INSERT OR REPLACE INTO session_skills
                   (session_id, skill_name, invocation_count)
                   VALUES (?, ?, 1)""",
                (session.id, skill_name)
            )
        self.conn.commit()
        return session.id

    def get_session(self, session_id: str) -> Optional[Session]:
        row = self.conn.execute(
            "SELECT * FROM sessions WHERE id = ?", (session_id,)
        ).fetchone()
        if not row:
            return None
        session = self._row_to_session(row)
        skills = self.conn.execute(
            "SELECT skill_name FROM session_skills WHERE session_id = ?",
            (session_id,)
        ).fetchall()
        session.skills_used = [s["skill_name"] for s in skills]
        return session

    def get_recent_sessions(
        self, limit: int = 10, days_back: int = 30,
        project: Optional[str] = None, skill: Optional[str] = None
    ) -> List[Session]:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days_back)).isoformat().replace('+00:00', 'Z')
        query = "SELECT * FROM sessions WHERE start_date >= ?"
        params = [cutoff]

        if project:
            query += " AND project = ?"
            params.append(project)

        if skill:
            query += " AND id IN (SELECT session_id FROM session_skills WHERE skill_name = ?)"
            params.append(skill)

        query += " ORDER BY start_date DESC LIMIT ?"
        params.append(limit)

        rows = self.conn.execute(query, params).fetchall()
        return [self._row_to_session(r) for r in rows]

    @staticmethod
    def _expand_compound_token(token: str) -> List[str]:
        """Split a compound token (camelCase, PascalCase, snake_case) into parts.

        Returns the original token plus its constituent parts so FTS5 matches
        both the compound form and individual words.

        Only expands tokens that are purely alphanumeric (plus underscores).
        Tokens with hyphens, colons, or other special chars are left as-is
        since those are not compound identifiers.

        Examples:
            "autoSave"      -> ["autoSave", "auto", "Save"]
            "PreCompact"    -> ["PreCompact", "Pre", "Compact"]
            "snake_case"    -> ["snake_case", "snake", "case"]
            "simple"        -> ["simple"]
            "agent:ron"     -> ["agent:ron"]  (colon = not a compound)
            "K-1"           -> ["K-1"]        (hyphen = not a compound)
        """
        # Only attempt expansion on tokens that look like identifiers
        # (alphanumeric + underscores only)
        if not re.match(r'^[A-Za-z0-9_]+$', token):
            return [token]

        parts = []
        # snake_case / SCREAMING_SNAKE: split on underscores
        if '_' in token:
            parts = [p for p in token.split('_') if p]
        else:
            # camelCase / PascalCase: split on case transitions
            # "autoSave" -> ["auto", "Save"], "HTMLParser" -> ["HTML", "Parser"]
            camel_parts = re.findall(r'[A-Z]+(?=[A-Z][a-z])|[A-Z]?[a-z]+|[A-Z]+|[0-9]+', token)
            if len(camel_parts) > 1:
                parts = camel_parts

        if not parts:
            return [token]
        # Return original token first (for exact match), then expanded parts
        return [token] + parts

    @staticmethod
    def _sanitize_fts_query(query: str) -> str:
        """Sanitize and preprocess user input for FTS5 MATCH.

        Processing steps:
        1. Split on whitespace into raw tokens.
        2. Expand compound tokens (camelCase, snake_case) into parts.
        3. Apply prefix matching (trailing *) for short alpha tokens (<=7 chars)
           so partial terms like "precomp" match "PreCompact".
        4. Quote each token to escape FTS5 operators (hyphens, colons).
        5. Implicit AND across all tokens (FTS5 default).

        Examples:
            "stripe billing"     -> '"stripe" "billing"'
            "autoSave"           -> '"autoSave" OR "auto" OR "Save"'
            "snake_case"         -> '"snake_case" OR "snake" OR "case"'
            "precomp"            -> '"precomp"*'
            "fts-migration"      -> '"fts-migration"'
            "agent:ron"          -> '"agent:ron"'
            "K-1 parser waiting" -> '"K-1" "parser" "waiting"'
        """
        safe = query.strip()
        if not safe:
            return '""'

        raw_tokens = safe.split()
        fts_groups = []
        has_or_group = False

        for token in raw_tokens:
            clean = token.replace('"', '')
            if not clean:
                continue

            expanded = SessionDatabase._expand_compound_token(clean)

            if len(expanded) > 1:
                # Compound token: OR the original with its parts
                parts = ['"' + p + '"' for p in expanded]
                fts_groups.append('(' + ' OR '.join(parts) + ')')
                has_or_group = True
            else:
                # Single token: apply prefix matching for short terms
                # Tokens <= 7 chars that are purely alphabetic are likely
                # abbreviations or partial words (e.g., "precomp" -> PreCompact)
                t = expanded[0]
                if len(t) <= 7 and t.isalpha():
                    # Short alphabetic token -- prefix match
                    fts_groups.append('"' + t + '"*')
                else:
                    fts_groups.append('"' + t + '"')

        if not fts_groups:
            return '""'

        # FTS5 requires explicit AND when combining parenthesized OR-groups
        # with other terms. Implicit AND only works between simple tokens.
        joiner = ' AND ' if has_or_group else ' '
        return joiner.join(fts_groups)

    def search_sessions(
        self, query: str, persona: Optional[str] = None,
        tags: Optional[List[str]] = None, skills: Optional[List[str]] = None,
        project: Optional[str] = None, limit: int = 10
    ) -> List[SearchResult]:
        fts_query = self._sanitize_fts_query(query)
        sql = """
            SELECT s.*, sessions_fts.rank
            FROM sessions s
            JOIN sessions_fts ON s.rowid = sessions_fts.rowid
            WHERE sessions_fts MATCH ?
        """
        params = [fts_query]

        if persona:
            sql += " AND s.id IN (SELECT session_id FROM persona_sessions WHERE persona_name LIKE ?)"
            params.append(persona + "%")

        if project:
            sql += " AND s.project = ?"
            params.append(project)

        if skills:
            placeholders = ",".join("?" * len(skills))
            sql += f" AND s.id IN (SELECT session_id FROM session_skills WHERE skill_name IN ({placeholders}))"
            params.extend(skills)

        sql += " ORDER BY sessions_fts.rank LIMIT ?"
        params.append(limit)

        rows = self.conn.execute(sql, params).fetchall()
        results = []
        for row in rows:
            session = self._row_to_session(row)
            results.append(SearchResult(
                session=session,
                match_score=abs(row["rank"]) if row["rank"] else 0.0
            ))

        if tags:
            results = [
                r for r in results
                if any(t in r.session.tags for t in tags)
            ]

        return results

    def get_context_for(self, topic: str, max_results: int = 5) -> List[SearchResult]:
        return self.search_sessions(query=topic, limit=max_results)

    def list_all_skills(self) -> List[dict]:
        """Return all distinct skill names with session counts, sorted by use count desc."""
        rows = self.conn.execute(
            """SELECT skill_name, COUNT(*) as session_count
               FROM session_skills
               GROUP BY skill_name
               ORDER BY session_count DESC, skill_name ASC"""
        ).fetchall()
        return [{"skill_name": r["skill_name"], "session_count": r["session_count"]} for r in rows]

    def get_skill_history(
        self, skill_name: str, days_back: int = 90
    ) -> List[Session]:
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days_back)).isoformat().replace('+00:00', 'Z')
        rows = self.conn.execute(
            """SELECT s.* FROM sessions s
               JOIN session_skills sk ON s.id = sk.session_id
               WHERE sk.skill_name = ? AND s.start_date >= ?
               ORDER BY s.start_date DESC""",
            (skill_name, cutoff)
        ).fetchall()
        return [self._row_to_session(r) for r in rows]

    # -- Persona operations --

    def tag_session(
        self, session_id: str, persona_name: str,
        relevance_note: Optional[str] = None
    ):
        self.conn.execute(
            """INSERT OR REPLACE INTO persona_sessions
               (persona_name, session_id, relevance_note)
               VALUES (?, ?, ?)""",
            (persona_name, session_id, relevance_note)
        )
        self.conn.commit()

    def get_persona_sessions(
        self, persona_name: str, limit: int = 20
    ) -> List[Session]:
        rows = self.conn.execute(
            """SELECT s.* FROM sessions s
               JOIN persona_sessions ps ON s.id = ps.session_id
               WHERE ps.persona_name LIKE ?
               ORDER BY s.start_date DESC LIMIT ?""",
            (persona_name + "%", limit)
        ).fetchall()
        return [self._row_to_session(r) for r in rows]

    # -- Session linking --

    def link_sessions(
        self, from_id: str, to_id: str, link_type: str = "continues"
    ):
        self.conn.execute(
            """INSERT OR REPLACE INTO session_links
               (from_session_id, to_session_id, link_type)
               VALUES (?, ?, ?)""",
            (from_id, to_id, link_type)
        )
        self.conn.commit()

    def get_session_chain(self, session_id: str) -> List[Session]:
        chain_ids = set()
        to_visit = [session_id]
        while to_visit:
            current = to_visit.pop(0)
            if current in chain_ids:
                continue
            chain_ids.add(current)
            links = self.conn.execute(
                """SELECT to_session_id FROM session_links WHERE from_session_id = ?
                   UNION
                   SELECT from_session_id FROM session_links WHERE to_session_id = ?""",
                (current, current)
            ).fetchall()
            for link in links:
                to_visit.append(link[0])

        sessions = []
        for sid in chain_ids:
            s = self.get_session(sid)
            if s:
                sessions.append(s)
        sessions.sort(key=lambda s: s.start_date)
        return sessions

    # -- Project operations --

    def create_project(
        self, name: str, description: str = "",
        expected_skills: Optional[List[str]] = None,
        default_persona: Optional[str] = None
    ):
        self.conn.execute(
            """INSERT OR REPLACE INTO projects
               (name, description, expected_skills, default_persona)
               VALUES (?, ?, ?, ?)""",
            (name, description, json.dumps(expected_skills or []), default_persona)
        )
        self.conn.commit()

    def get_project(self, project_name: str) -> Optional[dict]:
        row = self.conn.execute(
            "SELECT * FROM projects WHERE name = ?", (project_name,)
        ).fetchone()
        if not row:
            return None

        sessions = self.get_recent_sessions(
            limit=20, days_back=365, project=project_name
        )

        skill_counts = {}
        for s in sessions:
            skill_rows = self.conn.execute(
                "SELECT skill_name, invocation_count FROM session_skills WHERE session_id = ?",
                (s.id,)
            ).fetchall()
            for sr in skill_rows:
                skill_counts[sr["skill_name"]] = skill_counts.get(sr["skill_name"], 0) + sr["invocation_count"]

        return {
            "name": row["name"],
            "description": row["description"],
            "expected_skills": json.loads(row["expected_skills"] or "[]"),
            "default_persona": row["default_persona"],
            "session_count": len(sessions),
            "recent_sessions": [
                {"id": s.id, "title": s.title, "date": s.start_date}
                for s in sessions[:10]
            ],
            "skill_usage": dict(sorted(skill_counts.items(), key=lambda x: -x[1]))
        }

    def list_projects(self) -> List[dict]:
        rows = self.conn.execute("""
            SELECT p.name, p.description,
                   COUNT(s.id) AS session_count
            FROM projects p
            LEFT JOIN sessions s ON s.project = p.name
            GROUP BY p.name, p.description
            ORDER BY p.name
        """).fetchall()
        return [
            {
                "name": row["name"],
                "description": row["description"],
                "session_count": row["session_count"]
            }
            for row in rows
        ]

    # -- Suggestions --

    def get_suggestions(
        self, project: Optional[str] = None,
        persona: Optional[str] = None,
        days_back: int = 14, limit: int = 5
    ) -> dict:
        """Generate proactive context suggestions.

        Finds sessions worth revisiting based on:
        - Unresolved open questions
        - Recent decisions that may need follow-up
        - Skill gaps (expected by project but not used recently)
        """
        cutoff = (datetime.now(timezone.utc) - timedelta(days=days_back)).isoformat().replace('+00:00', 'Z')
        suggestions = []

        # 1. Sessions with open questions (highest priority)
        oq_sql = """
            SELECT * FROM sessions
            WHERE start_date >= ?
              AND open_questions IS NOT NULL
              AND open_questions != '[]'
        """
        oq_params: list = [cutoff]
        if project:
            oq_sql += " AND project = ?"
            oq_params.append(project)
        if persona:
            oq_sql += " AND id IN (SELECT session_id FROM persona_sessions WHERE persona_name LIKE ?)"
            oq_params.append(persona + "%")
        oq_sql += " ORDER BY start_date DESC"

        rows = self.conn.execute(oq_sql, oq_params).fetchall()
        for row in rows:
            session = self._row_to_session(row)
            if session.open_questions:
                suggestions.append({
                    "session_id": session.id,
                    "title": session.title,
                    "date": session.start_date,
                    "reason": "Has %d unresolved open question(s)" % len(session.open_questions),
                    "type": "open_questions",
                    "priority": 1,
                    "open_questions": session.open_questions,
                    "summary_preview": session.summary[:300] + "..." if len(session.summary) > 300 else session.summary,
                })

        # 2. Sessions with decisions worth reviewing
        dec_sql = """
            SELECT * FROM sessions
            WHERE start_date >= ?
              AND decisions IS NOT NULL
              AND decisions != '[]'
        """
        dec_params: list = [cutoff]
        if project:
            dec_sql += " AND project = ?"
            dec_params.append(project)
        if persona:
            dec_sql += " AND id IN (SELECT session_id FROM persona_sessions WHERE persona_name LIKE ?)"
            dec_params.append(persona + "%")
        dec_sql += " ORDER BY start_date DESC"

        seen_ids = {s["session_id"] for s in suggestions}
        rows = self.conn.execute(dec_sql, dec_params).fetchall()
        for row in rows:
            session = self._row_to_session(row)
            if session.id not in seen_ids and len(session.decisions) >= 2:
                suggestions.append({
                    "session_id": session.id,
                    "title": session.title,
                    "date": session.start_date,
                    "reason": "Contains %d key decisions worth reviewing" % len(session.decisions),
                    "type": "decisions",
                    "priority": 2,
                    "decisions": session.decisions,
                    "summary_preview": session.summary[:300] + "..." if len(session.summary) > 300 else session.summary,
                })
                seen_ids.add(session.id)

        # 3. Skill gaps (project expected_skills not used recently)
        skill_gaps = []
        if project:
            proj_row = self.conn.execute(
                "SELECT expected_skills FROM projects WHERE name = ?",
                (project,)
            ).fetchone()
            if proj_row:
                expected = json.loads(proj_row["expected_skills"] or "[]")
                if expected:
                    recent_skills = self.conn.execute(
                        """SELECT DISTINCT sk.skill_name
                           FROM session_skills sk
                           JOIN sessions s ON sk.session_id = s.id
                           WHERE s.start_date >= ? AND s.project = ?""",
                        (cutoff, project)
                    ).fetchall()
                    used = {r["skill_name"] for r in recent_skills}
                    for skill in expected:
                        if skill not in used:
                            # Find last time this skill was used
                            last = self.conn.execute(
                                """SELECT s.start_date FROM sessions s
                                   JOIN session_skills sk ON s.id = sk.session_id
                                   WHERE sk.skill_name = ?
                                   ORDER BY s.start_date DESC LIMIT 1""",
                                (skill,)
                            ).fetchone()
                            skill_gaps.append({
                                "skill": skill,
                                "last_used": last["start_date"] if last else None,
                                "reason": "Expected in project '%s' but not used in last %d days" % (project, days_back),
                            })

        # Sort by priority, then recency
        suggestions.sort(key=lambda s: (s["priority"], s["date"]))
        # Remove priority field from output, take top N
        for s in suggestions:
            del s["priority"]
        suggestions = suggestions[:limit]

        total_scanned = self.conn.execute(
            "SELECT COUNT(*) as c FROM sessions WHERE start_date >= ?",
            (cutoff,)
        ).fetchone()["c"]

        return {
            "suggestions": suggestions,
            "skill_gaps": skill_gaps,
            "metadata": {
                "total_sessions_scanned": total_scanned,
                "days_back": days_back,
                "suggestions_returned": len(suggestions),
                "project_filter": project,
                "persona_filter": persona,
            }
        }

    # -- Helpers --

    @staticmethod
    def _parse_json_field(value, default="[]"):
        """Parse a JSON field that may contain a raw string instead of a JSON array.

        Handles three storage formats found in the database:
        1. JSON array (current format):  '["tag1", "tag2"]'
        2. Comma-separated string (legacy tags): 'tag1,tag2,tag3'
        3. Plain text blob (Gina architecture proposals in decisions field)

        Always returns a list so callers never need to handle multiple types.
        """
        raw = value or default
        try:
            result = json.loads(raw)
            if not isinstance(result, list):
                return [str(result)]
            return result
        except (json.JSONDecodeError, ValueError):
            if not raw or raw == default:
                return []
            # Legacy comma-separated tags (e.g. 'security,supply-chain,audit')
            # Detect by checking whether the string looks like a CSV tag list:
            # short tokens, no spaces, commas present.
            stripped = raw.strip().rstrip(',')
            tokens = [t.strip() for t in stripped.split(',') if t.strip()]
            all_short = all(len(t) <= 60 and ' ' not in t for t in tokens)
            if len(tokens) > 1 and all_short:
                return tokens
            # Plain text blob (architecture proposals, free-form text) -- keep as one item
            return [raw]

    def _row_to_session(self, row) -> Session:
        return Session(
            id=row["id"],
            title=row["title"],
            surface=row["surface"],
            project=row["project"],
            start_date=row["start_date"],
            end_date=row["end_date"],
            summary=row["summary"] or "",
            decisions=self._parse_json_field(row["decisions"]),
            artifacts=self._parse_json_field(row["artifacts"]),
            open_questions=self._parse_json_field(row["open_questions"]),
            tags=self._parse_json_field(row["tags"]),
            created_at=row["created_at"] or ""
        )

    def session_count(self) -> int:
        row = self.conn.execute("SELECT COUNT(*) as c FROM sessions").fetchone()
        return row["c"]
