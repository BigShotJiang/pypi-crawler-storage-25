"""Wrapper around HubQuantumClient for SDK-side cross-cutting concerns.

Applies two behaviours to every sub-client method call:

- Retry on 503 (Service Unavailable) and connection errors for up to
  15 minutes with exponential backoff.
- Translate any surviving ``ApiError`` (status != 204) into
  ``HubApiError`` so SDK users see a clean ``detail`` message instead of
  the Fern client's raw header / body / stacktrace dump. ``ApiError(204)``
  passes through unchanged because SDK code uses it as a sentinel for
  "success with no body".

Exposes the same interface as HubQuantumClient (backends, jobs, sessions)
so it can be used as a drop-in replacement.
"""

import logging
import time
from functools import wraps

import httpx
from qhub.api.quantum import HubQuantumClient
from qhub.api.quantum.core.api_error import ApiError
from qhub.quantum.sdk.exceptions import translate_api_errors

logger = logging.getLogger(__name__)

RETRY_DURATION_SECONDS = 15 * 60
INITIAL_DELAY_SECONDS = 5.0
MAX_DELAY_SECONDS = 60.0


def _is_service_unavailable(error):
    return isinstance(error, ApiError) and error.status_code == 503


def _is_connection_error(error):
    return isinstance(error, (httpx.ConnectError, httpx.ConnectTimeout))


def _with_service_retry(func):
    @wraps(func)
    def wrapper(*args, **kwargs):
        deadline = time.monotonic() + RETRY_DURATION_SECONDS
        delay = INITIAL_DELAY_SECONDS
        attempt = 0

        while True:
            try:
                return func(*args, **kwargs)
            except Exception as e:
                if not (_is_service_unavailable(e) or _is_connection_error(e)):
                    raise

                remaining = deadline - time.monotonic()
                if remaining <= 0:
                    logger.error(
                        "Hub API unavailable for %ds, giving up.",
                        RETRY_DURATION_SECONDS,
                    )
                    raise

                wait = min(delay, remaining)
                attempt += 1
                logger.warning(
                    "Hub API unavailable (attempt %d), retrying in %.0fs (%.0fs remaining): %s",
                    attempt,
                    wait,
                    remaining,
                    e,
                )
                time.sleep(wait)
                delay = min(delay * 2, MAX_DELAY_SECONDS)

    return wrapper


class _SubClientProxy:
    """Proxy around one HubQuantumClient sub-client (``backends`` / ``jobs`` / ``sessions``).

    Every callable accessed on the proxy is returned wrapped with
    ``_with_service_retry`` (innermost) and ``translate_api_errors``
    (outermost). Non-callable attributes pass through unchanged.
    """

    def __init__(self, sub_client):
        self._sub_client = sub_client

    def __getattr__(self, name):
        if name.startswith("_"):
            raise AttributeError(name)
        attr = getattr(self._sub_client, name)
        if callable(attr):
            return translate_api_errors(_with_service_retry(attr))
        return attr


class HubClientProxy:
    """HubQuantumClient wrapper that applies SDK-side behaviours.

    Retry: 503 (Service Unavailable) and connection errors are retried
    for up to 15 minutes with exponential backoff (5s, 10s, 20s, 40s,
    60s, 60s, ...). All other errors use Fern's default retry behaviour
    (2 attempts).

    Error translation: any ``ApiError`` that surfaces after retries
    is converted to :class:`HubApiError`, which renders the server's
    ``detail`` message cleanly. ``ApiError(status_code=204)`` passes
    through unchanged.

    This class exposes the same interface as HubQuantumClient (backends,
    jobs, sessions) so it can be used as a drop-in replacement.
    """

    def __init__(self, client: HubQuantumClient):
        self._client = client
        self._backends = _SubClientProxy(client.backends)
        self._jobs = _SubClientProxy(client.jobs)
        self._sessions = _SubClientProxy(client.sessions)

    @property
    def backends(self):
        return self._backends

    @property
    def jobs(self):
        return self._jobs

    @property
    def sessions(self):
        return self._sessions


def ensure_wrapped(client):
    """Return *client* wrapped in :class:`HubClientProxy`, unless already wrapped."""
    return client if isinstance(client, HubClientProxy) else HubClientProxy(client)
