from qhub.quantum.sdk.qiskit.provider import HubQiskitProvider
from qhub.quantum.sdk.qiskit.providers.aws.aws_backend import HubAwsBackend


@HubQiskitProvider.register_backend("aws.rigetti.cepheus")
class HubAwsRigettiCepheusBackend(HubAwsBackend):
    def __init__(self, **kwargs):
        super().__init__(**kwargs)
