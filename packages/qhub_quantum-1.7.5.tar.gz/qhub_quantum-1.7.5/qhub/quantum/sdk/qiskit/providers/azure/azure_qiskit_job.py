from qhub.api.quantum import HubQuantumClient
from qhub.api.quantum import Job as JobModel
from qhub.quantum.sdk.job import JobRequest
from qhub.quantum.sdk.qiskit.backend import HubQiskitBackend
from qhub.quantum.sdk.qiskit.job import HubQiskitJob
from qhub.quantum.sdk.qiskit.providers.azure.result.ionq_result_formatter import IonqResultFormatter
from qiskit.result.models import ExperimentResult


class HubAzureQiskitJob(HubQiskitJob):
    def __init__(
        self,
        backend: HubQiskitBackend | None,
        job_id: str | None = None,
        job_details: JobModel | JobRequest | None = None,
        hub_client: HubQuantumClient | None = None,
    ):

        super().__init__(backend, job_id, job_details, hub_client)

    def _create_experiment_result(self, provider_result: dict) -> ExperimentResult:
        backend: HubQiskitBackend = self.backend()
        hw_provider = backend.backend_info.hardware_provider

        if hw_provider == "IONQ":
            formatter = IonqResultFormatter(provider_result, self)
        else:
            raise NotImplementedError(f"Hardware provider {hw_provider} not supported")

        return formatter.format_result()
