from uuid import UUID

from qhub.api.quantum import Backend as BackendModel
from qhub.api.quantum import HubQuantumClient
from qhub.quantum.sdk.qiskit.backend import HubQiskitBackend
from qhub.quantum.sdk.qiskit.provider import HubQiskitProvider
from qhub.quantum.sdk.qiskit.providers.iqm.hub_iqm_client import _HubIqmClient
from qhub.quantum.sdk.qiskit.providers.iqm.iqm_client_sdk.iqm_client.models import CircuitCompilationOptions
from qhub.quantum.sdk.qiskit.providers.iqm.iqm_client_sdk.qiskit_iqm.iqm_provider import IQMBackend
from qiskit import QuantumCircuit
from qiskit.providers import Options
from qiskit.transpiler import Target

_COMPILATION_OPTION_FIELDS: tuple[str, ...] = (
    "max_circuit_duration_over_t2",
    "heralding_mode",
    "move_gate_validation",
    "move_gate_frame_tracking",
    "active_reset_cycles",
    "dd_mode",
    "dd_strategy",
)


@HubQiskitProvider.register_backend("iqm.qpu.emerald")
@HubQiskitProvider.register_backend("iqm.qpu.garnet")
class HubIqmBackend(HubQiskitBackend):
    """Kipu Quantum Hub wrapper backend for IQM Resonance QPUs (Emerald, Garnet, …).

    Acts as an adapter that wraps the native IQMBackend from the IQM SDK,
    routing Kipu Quantum Hub requests through _HubIqmClient to the underlying
    IQM backend implementation while maintaining Kipu Quantum Hub integration.
    """

    def __init__(self, hub_client: HubQuantumClient, backend_info: BackendModel):
        backend_id = backend_info.id
        self._backend = backend_info
        self._hub_iqm_client = _HubIqmClient(hub_client, backend_id)
        self._iqm_backend = self._get_backend(name=backend_id)
        super().__init__(hub_client, backend_info)

    def _acceptable_run_kwargs(self) -> set[str]:
        # Feature parity with upstream `iqm.qiskit_iqm.IQMBackend`, which deliberately keeps
        # `_default_options` empty and accepts IQM-specific kwargs through `run(**options)`
        # directly so they remain discoverable in the docstring. Declaring them as Qiskit
        # Options here would break the e2e parity check against the upstream SDK.
        return {"calibration_set_id", *_COMPILATION_OPTION_FIELDS}

    def _get_backend(self, name: str | None = None, calibration_set_id: UUID | None = None) -> IQMBackend:
        """Creates and returns the wrapped IQM backend instance using _HubIqmClient as adapter."""

        if name and name.startswith("facade_"):
            raise NotImplementedError(
                "Access to facade backends is not yet implemented. "
                " Please contact Kipu Quantum Hub support if you require this functionality."
            )

        return IQMBackend(self._hub_iqm_client, calibration_set_id=calibration_set_id)

    def _hub_backend_to_target(self) -> Target:
        """Returns target from wrapped IQM backend, delegating to native IQM implementation."""
        return self._iqm_backend.target

    def _initialize_backend_components(self):
        """Initialize backend using wrapped IQM backend's target.

        IQM backend delegates target management to the vendored IQM SDK's
        IQMBackend, which constructs the target from IQM's dynamic quantum
        architecture (DQA). This overrides the parent's initialization to
        prevent calling abstract methods that aren't needed for IQM.
        """
        # Use pre-built target from wrapped IQM backend
        self._target = self._iqm_backend.target
        # IQM doesn't use QasmBackendConfiguration
        self._configuration = None

    def _to_gate(self, name: str):
        """Not implemented - gate conversion handled by wrapped IQMBackend.

        This method is required by parent class but not called due to
        _initialize_backend_components override.
        """
        pass

    def _get_single_qubit_gate_properties(self, instr_name: str | None) -> dict:
        """Not implemented - gate properties provided by wrapped IQMBackend target.

        This abstract method is required by parent class but not called due to
        _initialize_backend_components override.
        """
        pass

    def _get_multi_qubit_gate_properties(self):
        """Not implemented - gate properties provided by wrapped IQMBackend target.

        This abstract method is required by parent class but not called due to
        _initialize_backend_components override.
        """
        pass

    @property
    def architecture(self):
        return self._iqm_backend.architecture

    @property
    def target_with_resonators(self) -> Target:
        """Return the target with MOVE gates and resonators included.

        Raises:
            ValueError: The backend does not have resonators.

        """
        return self._iqm_backend.target_with_resonators

    @property
    def backend_info(self) -> BackendModel:
        return self._backend_info

    @property
    def backend_provider(self) -> str:
        return "IQM"

    @property
    def coupling_map(self):
        return self._iqm_backend.coupling_map

    @property
    def dt(self):
        return self._iqm_backend.dt

    @property
    def instruction_schedule_map(self):
        raise NotImplementedError("Instruction schedule not supported.")

    @property
    def max_circuits(self):
        return self._iqm_backend.max_circuits

    @property
    def physical_qubits(self):
        return self._iqm_backend.physical_qubits

    def _convert_to_job_input(self, job_input: QuantumCircuit, options: Options = None) -> dict:
        run_request = self._create_run_request(job_input, options)

        return {"circuits": run_request["circuits"]}

    def _convert_to_job_params(self, job_input: QuantumCircuit = None, options=None) -> dict:
        run_request = self._create_run_request(job_input, options)

        run_request.pop("circuits", None)
        run_request.pop("shots", None)

        return run_request

    def _create_run_request(self, job_input, options) -> dict:
        """Create a run request for IQM backend using the wrapped IQM SDK.

        Args:
            job_input: Quantum circuit to execute
            options: Job execution options including shots and calibration_set_id

        Returns:
            Run request dictionary for IQM execution
        """
        shots = options.get("shots")
        if shots is None:
            shots = self.backend_info.configuration.shots_range.min

        # Calset lives on the IQMBackend instance, not on create_run_request — swap on override.
        calibration_set_id = options.get("calibration_set_id")
        iqm_backend = (
            self._get_backend(calibration_set_id=calibration_set_id)
            if calibration_set_id is not None
            else self._iqm_backend
        )

        run_request = iqm_backend.create_run_request(
            run_input=[job_input],
            shots=shots,
            qubit_index_to_name=None,
            circuit_compilation_options=self._build_compilation_options(options),
        )

        return run_request.model_dump(mode="json")

    @staticmethod
    def _build_compilation_options(options) -> CircuitCompilationOptions | None:
        """Forward only explicitly-set compilation fields; ``None`` lets the SDK apply defaults."""
        fields = {key: options.get(key) for key in _COMPILATION_OPTION_FIELDS if options.get(key) is not None}
        return CircuitCompilationOptions(**fields) if fields else None

    def _get_job_input_format(self) -> str:
        return "IQM_JOB_INPUT_V1"

    def has_resonators(self) -> bool:
        """True iff the backend QPU has computational resonators."""
        return self._iqm_backend.has_resonators()

    def get_real_target(self) -> Target:
        """Return the real physical target of the backend without fictional CZ gates."""
        return self._iqm_backend.get_real_target()

    def qubit_name_to_index(self, name: str) -> int:
        """Given an IQM-style qubit name, return the corresponding index in the register.

        Args:
            name: IQM-style qubit name ('QB1', 'QB2', etc.)

        Returns:
            Index of the given qubit in the quantum register.

        Raises:
            ValueError: Qubit name cannot be found on the backend.

        """
        return self._iqm_backend.qubit_name_to_index(name)

    def index_to_qubit_name(self, index: int) -> str:
        """Given a quantum register index, return the corresponding IQM-style qubit name.

        Args:
            index: Qubit index in the quantum register.

        Returns:
            Corresponding IQM-style qubit name ('QB1', 'QB2', etc.).

        Raises:
            ValueError: Qubit index cannot be found on the backend.

        """
        return self._iqm_backend.index_to_qubit_name(index)

    def get_scheduling_stage_plugin(self) -> str:
        """Return the plugin that should be used for scheduling the circuits on this backend."""
        return self._iqm_backend.get_scheduling_stage_plugin()
