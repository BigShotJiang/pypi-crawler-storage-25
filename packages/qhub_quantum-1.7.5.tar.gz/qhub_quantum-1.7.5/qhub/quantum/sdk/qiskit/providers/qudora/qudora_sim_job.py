from qhub.api.quantum import HubQuantumClient
from qhub.api.quantum import Job as JobModel
from qhub.quantum.sdk.job import JobRequest
from qhub.quantum.sdk.qiskit.job import HubQiskitJob
from qiskit.providers import Backend


class HubQudoraQiskitJob(HubQiskitJob):
    def __init__(
        self,
        backend: Backend | None,
        job_id: str | None = None,
        job_details: JobModel | JobRequest | None = None,
        hub_client: HubQuantumClient | None = None,
    ):

        super().__init__(backend, job_id, job_details, hub_client)
