from abc import ABC, abstractmethod
from typing import Any

from qhub.quantum.sdk.qiskit.job import HubQiskitJob


class ResultFormatter(ABC):
    def __init__(self, results: any, job: HubQiskitJob):
        self.results = results
        self.job = job

    @abstractmethod
    def format_result(self) -> list[dict[str, Any]]:
        pass
