from qhub.quantum.sdk.qiskit.backend import HubQiskitBackend
from qhub.quantum.sdk.qiskit.options import OptionsV2
from qhub.quantum.sdk.qiskit.provider import HubQiskitProvider
from qiskit import QuantumCircuit, qasm2
from qiskit.circuit import Measure
from qiskit.circuit.library import get_standard_gate_name_mapping
from qiskit.transpiler import InstructionProperties, Target


@HubQiskitProvider.register_backend("kipu.sim.qsim")
class HubKipuQsimBackend(HubQiskitBackend):
    """Kipu Quantum Hub Qiskit backend for the in-house qsim state-vector simulator.

    Three simulation modes are exposed via run options:

    - ``mode="sample"`` (default): returns measurement counts under
      ``result.data().counts``. Requires ``shots``.
    - ``mode="statevector"``: returns the full final state vector under
      ``result.data().statevector`` as a Qiskit :class:`Statevector`.
    - ``mode="amplitudes"``: returns amplitudes for the bitstrings listed in
      ``bitstrings``. Conceptually a *subset* of the statevector, so it lands
      in the same ``result.data().statevector`` field — only the requested
      indices are populated, all other entries are ``0+0j``.

    qsim-specific tuning (``cpu_threads``, ``max_fused_gate_size``) is also
    exposed as run options. Refer to the qsim documentation for their effect.
    """

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

    @classmethod
    def _default_options(cls):
        options = OptionsV2(
            shots=100,
            mode="sample",
            bitstrings=None,
            cpu_threads=None,
            max_fused_gate_size=None,
        )
        options.set_validator("shots", (1, 100000))
        options.set_validator("mode", ["sample", "statevector", "amplitudes"])
        return options

    def _to_gate(self, name: str):
        # qsim accepts ccx/cswap/cu3 in OpenQASM 2 directly, but exposing them
        # in the Qiskit Target alongside per-pair coupling_map is rejected by
        # Qiskit's transpiler ("3-qubit gates incompatible with custom
        # coupling_map"). Qiskit auto-decomposes them to 1q/2q primitives —
        # equivalent for a noiseless simulator. Raw-QASM users keep full
        # 3-qubit gate fidelity via the qhub-api client path.
        gate = get_standard_gate_name_mapping().get(name.lower())
        if gate is not None and gate.num_qubits > 2:
            return None
        return gate

    def _get_single_qubit_gate_properties(self, instr_name: str | None = None) -> dict:
        return {(i,): InstructionProperties(duration=1e-9, error=0.0) for i in range(self._num_qubits())}

    def _get_multi_qubit_gate_properties(self):
        return {
            (i, j): InstructionProperties(duration=1e-9, error=0.0)
            for i in range(self._num_qubits())
            for j in range(self._num_qubits())
            if i != j
        }

    # Override the parent's target builder to dispatch properties by arity.
    # The parent passes one `multi_qubit_props` dict to all multi-qubit gates,
    # which fails for 3-qubit gates (ccx, cswap, cu3) when the dict is keyed
    # by 2-qubit pairs. Splitting 2-qubit vs 3+-qubit lets us populate the
    # full all-to-all coupling map (so `backend.coupling_map` is non-None,
    # matching the codebase convention for fully-connected backends) while
    # still supporting 3-qubit gates globally with `{None: None}`.
    def _hub_backend_to_target(self) -> Target:
        configuration = self.backend_info.configuration
        self._contiguous_connectivity = self._make_contiguous_connectivity(configuration.connectivity)

        n = self._num_qubits()
        target = Target(description=f"Target for Kipu Quantum Hub backend {self.name}", num_qubits=n)

        single_props = self._get_single_qubit_gate_properties()
        two_qubit_props = self._get_multi_qubit_gate_properties()

        gates_names = self._get_gate_names_for_target(configuration)
        for gate_name in gates_names:
            gate = self._to_gate(gate_name)
            if gate is None:
                continue
            if gate.num_qubits == 1:
                target.add_instruction(gate, properties=single_props)
            elif gate.num_qubits == 2:
                target.add_instruction(gate, properties=two_qubit_props)
            else:
                target.add_instruction(gate, properties={None: None})

        target.add_instruction(Measure(), single_props)

        non_gate_instructions = set(configuration.instructions or []).difference(gates_names).difference({"measure"})
        for instr_name in non_gate_instructions:
            instr = self._to_non_gate_instruction(instr_name)
            if instr is not None:
                target.add_instruction(instr, single_props)

        return target

    def _convert_to_job_input(self, job_input: QuantumCircuit, options=None) -> str:
        if isinstance(job_input, QuantumCircuit):
            return qasm2.dumps(job_input)
        raise TypeError(f"Cannot convert object of type {type(job_input)} to QuantumCircuit")

    def _convert_to_job_params(self, job_input: QuantumCircuit = None, options=None) -> dict:
        params = {}
        if not options:
            return params
        for key in ("mode", "bitstrings", "cpu_threads", "max_fused_gate_size"):
            value = getattr(options, key, None)
            if value is not None:
                params[key] = value
        return params

    def _get_job_input_format(self) -> str:
        return "OPEN_QASM_V2"
