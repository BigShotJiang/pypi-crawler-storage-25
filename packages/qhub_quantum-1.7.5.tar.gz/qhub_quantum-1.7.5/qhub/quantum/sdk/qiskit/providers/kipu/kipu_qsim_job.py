import numpy as np
from qhub.api.quantum import HubQuantumClient
from qhub.api.quantum import Job as JobModel
from qhub.quantum.sdk.job import JobRequest
from qhub.quantum.sdk.qiskit.job import HubQiskitJob
from qiskit.providers import Backend, JobStatus
from qiskit.quantum_info import Statevector
from qiskit.result.models import ExperimentResult, ExperimentResultData


class HubKipuQsimJob(HubQiskitJob):
    """Result-aware Qiskit job for kipu.sim.qsim.

    qsim returns three different result shapes depending on the requested mode.
    All three are mapped onto Qiskit-native fields on ``ExperimentResultData``:

    - ``{"counts": {...}}``      → ``data.counts``       (sample mode)
    - ``{"statevector": [...]}`` → ``data.statevector``  (statevector mode)
    - ``{"amplitudes": {...}}``  → ``data.statevector``  (amplitudes mode, sparse)

    Bitstring endianness is converted from qsim's big-endian convention to
    Qiskit's little-endian convention.
    """

    def __init__(
        self,
        backend: Backend | None,
        job_id: str | None = None,
        job_details: JobModel | JobRequest | None = None,
        hub_client: HubQuantumClient | None = None,
    ):
        super().__init__(backend, job_id, job_details, hub_client)

    def _create_experiment_result(self, provider_result: dict) -> ExperimentResult:
        data = self._build_result_data(provider_result)
        return ExperimentResult(
            shots=self.shots,
            success=True,
            status=JobStatus.DONE.name,
            data=data,
            metadata=provider_result.get("metadata") or {},
        )

    def _build_result_data(self, provider_result: dict) -> ExperimentResultData:
        if "counts" in provider_result:
            counts = {k[::-1]: v for k, v in provider_result["counts"].items()}
            memory = provider_result.get("memory", [])
            return ExperimentResultData(counts=counts, memory=memory)

        if "statevector" in provider_result:
            sv = np.array([complex(r, i) for r, i in provider_result["statevector"]], dtype=complex)
            return ExperimentResultData(statevector=Statevector(sv).reverse_qargs().data)

        if "amplitudes" in provider_result:
            num_qubits = self._resolve_num_qubits(provider_result)
            sv = np.zeros(2**num_qubits, dtype=complex)
            for bitstring, (r, i) in provider_result["amplitudes"].items():
                sv[int(bitstring, 2)] = complex(r, i)
            return ExperimentResultData(statevector=Statevector(sv).reverse_qargs().data)

        raise ValueError(f"Unrecognized qsim result shape: keys={list(provider_result.keys())}")

    def _resolve_num_qubits(self, provider_result: dict) -> int:
        metadata = provider_result.get("metadata") or {}
        from_metadata = metadata.get("num_qubits")
        if from_metadata is not None:
            return int(from_metadata)
        return self._backend.num_qubits
