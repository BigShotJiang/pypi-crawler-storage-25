from qhub.api.quantum import HubQuantumClient
from qhub.api.quantum import Job as JobModel
from qhub.quantum.sdk.job import JOB_FINAL_STATES, JobRequest
from qhub.quantum.sdk.qiskit.job import HubQiskitJob
from qhub.quantum.sdk.qiskit.providers.iqm.hub_iqm_client import _HubIqmClient
from qiskit.providers import Backend
from qiskit.result import Counts, Result
from qiskit.result.models import ExperimentResult, ExperimentResultData


class HubIqmQiskitJob(HubQiskitJob):
    def __init__(
        self,
        backend: Backend | None,
        job_id: str | None = None,
        job_details: JobModel | JobRequest | None = None,
        hub_client: HubQuantumClient | _HubIqmClient | None = None,
    ):
        super().__init__(backend, job_id, job_details, hub_client)

    def _result_states(self) -> set[str]:
        return JOB_FINAL_STATES

    def _create_experiment_result(self, provider_result: dict) -> ExperimentResult:
        """Transform IQM measurement results to Qiskit ExperimentResult format."""
        result = self.iqm_to_experiment_result(provider_result.get("measurement_counts") or [])
        if result.results:
            return result.results[0]
        else:
            return ExperimentResult(shots=0, success=True, data=ExperimentResultData(counts={}))

    def iqm_to_experiment_result(
        self,
        iqm_meas_results: list[dict[str, list[str] | dict[str, int]]],
    ) -> Result:
        """Convert IQM-style measurement results into a Qiskit Result."""
        if not iqm_meas_results:
            return Result(
                backend_name=self._backend.name if self._backend else "unknown",
                backend_version="1.0",
                job_id=self._job_id,
                qobj_id=0,
                success=True,
                results=[],
                status="COMPLETED",
                date=None,
            )

        experiment_results = []
        for measurement_batch in iqm_meas_results:
            counts_dict = measurement_batch.get("counts", {})
            experiment_result = {
                "shots": sum(counts_dict.values()),
                "success": True,
                "data": {
                    "memory": measurement_batch.get("memory", []),
                    "counts": Counts(counts_dict),
                },
                "status": "DONE",
            }
            experiment_results.append(experiment_result)

        result_dict = {
            "backend_name": self._backend.name if self._backend else "unknown",
            "backend_version": "1.0",
            "qobj_id": 0,
            "job_id": self._job_id,
            "success": True,
            "results": experiment_results,
            "date": None,
        }
        return Result.from_dict(result_dict)
