"""
Kipu Quantum Hub Qiskit Runtime Service V2 Implementation

This class is adapted from the IBM Qiskit Runtime's QiskitRuntimeService class
(qiskit_ibm_runtime.qiskit_runtime_service.QiskitRuntimeService) to provide compatibility
with IBM's runtime service patterns while integrating with the Kipu Quantum Hub SDK.

0Original IBM implementation:
https://github.com/Qiskit/qiskit-ibm-runtime/blob/main/qiskit_ibm_runtime/qiskit_runtime_service.py
"""

import json
import warnings
from collections.abc import Callable, Sequence
from datetime import datetime
from typing import TYPE_CHECKING, Any, ClassVar

from qhub.quantum.sdk.job import JobRequest
from qhub.quantum.sdk.qiskit.hub_qiskit_runtime_job import HubRuntimeJobV2
from qhub.quantum.sdk.qiskit.provider import HubQiskitProvider
from qhub.quantum.sdk.qiskit.providers.ibm.runtime_session_client_adapter import RuntimeSessionClientAdapter
from qiskit.providers import QiskitBackendNotFoundError
from qiskit_ibm_runtime import QiskitRuntimeService, RuntimeEncoder, RuntimeOptions, ibm_backend
from qiskit_ibm_runtime.accounts import ChannelType
from qiskit_ibm_runtime.runtime_job_v2 import RuntimeJobV2
from qiskit_ibm_runtime.utils.result_decoder import ResultDecoder

if TYPE_CHECKING:
    from qhub.quantum.sdk.qiskit.providers.ibm.ibm_backend import HubIbmQiskitBackend


class HubQiskitRuntimeService(HubQiskitProvider, QiskitRuntimeService):
    """Kipu Quantum Hub Runtime Service V2 with full IBM QiskitRuntimeService API compatibility."""

    # Channel constant for Kipu Quantum Hub
    _CHANNEL = "Kipu Quantum Hub"

    # Backend mapping for registered IBM backends
    _backend_mapping: ClassVar[dict[str, type["HubIbmQiskitBackend"]]] = {}

    @classmethod
    def register_backend(cls, backend_id: str):
        """For internal use only. Binds a backend class to a Kipu Quantum Hub IBM backend id."""

        def decorator(backend_cls: type["HubIbmQiskitBackend"]):
            cls._backend_mapping[backend_id] = backend_cls
            return backend_cls

        return decorator

    def _get_backend_class(self, backend_id: str) -> type["HubIbmQiskitBackend"]:
        return self._backend_mapping.get(backend_id)

    def _instantiate_backend(self, backend_class, backend_info) -> "HubIbmQiskitBackend":
        return backend_class(
            service=self,
            hub_client=self._client,
            backend_info=backend_info,
        )

    def __init__(self, access_token: str | None = None, organization_id: str | None = None, _client=None) -> None:
        """HubQiskitRuntimeServiceV2 constructor."""
        super().__init__(access_token=access_token, organization_id=organization_id, _client=_client)

    def _api_client(self) -> RuntimeSessionClientAdapter:
        """API client for IBM Session compatibility."""
        return self._get_api_client()

    def _get_api_client(self, instance: str | None = None) -> RuntimeSessionClientAdapter:
        """Return the API client for session operations."""
        return RuntimeSessionClientAdapter(self._client)

    def active_account(self) -> dict[str, str] | None:
        """Return the account currently in use for the session."""
        if not self._client:
            return None

        account_info = {
            "channel": self._CHANNEL,
        }

        return account_info

    def backend(
        self,
        name: str,
        instance: str | None = None,
        use_fractional_gates: bool | None = False,
    ) -> "HubIbmQiskitBackend":
        """Return a single backend matching the Kipu Quantum Hub backend id."""
        backend_model = self._client.backends.get_backend(name)

        if backend_model.provider != "IBM":
            raise QiskitBackendNotFoundError(
                f"Backend '{name}' is not from IBM. Qiskit Runtime only supports IBM backends."
            )

        backend_class = self._get_backend_class(name)
        if backend_class:
            return backend_class(
                service=self,
                hub_client=self._client,
                backend_info=backend_model,
                use_fractional_gates=use_fractional_gates,
            )
        else:
            raise QiskitBackendNotFoundError(f"IBM backend '{name}' is not registered with HubQiskitRuntimeService.")

    def backends(self, provider: str | None = None) -> list[str]:
        """Return all IBM backends accessible via this service that are registered."""
        all_ibm_backend_ids = super().backends(provider="IBM")

        registered_backend_ids = [
            backend_id for backend_id in all_ibm_backend_ids if backend_id in self._backend_mapping
        ]

        return registered_backend_ids

    def check_pending_jobs(self) -> None:
        raise NotImplementedError("check_pending_jobs method not yet implemented")

    @staticmethod
    def delete_account(
        filename: str | None = None,
        name: str | None = None,
        channel: ChannelType | None = None,
    ) -> bool:
        raise NotImplementedError("delete_account method not supported. Use Kipu Quantum Hub CLI: qhub logout")

    def delete_job(self, job_id: str) -> None:
        raise NotImplementedError("delete_job method not yet implemented")

    def instances(self) -> list[str]:
        raise NotImplementedError(
            "instances method not implemented. Instance management is handled by Kipu Quantum Hub"
        )

    @classmethod
    def _get_shots(cls, inputs: dict, backend) -> int:
        """Retrieve shots from inputs with fallback logic."""
        default_shots = (
            backend.options.get("shots", backend.min_shots) if hasattr(backend, "options") else backend.min_shots
        )
        options = inputs.get("options", {})
        if "default_shots" in options:
            default_shots = options["default_shots"]

        shots = default_shots

        pubs = inputs.get("pubs", [])
        if pubs and len(pubs) > 0:
            first_pub = pubs[0]
            if hasattr(first_pub, "shots") and first_pub.shots is not None:
                shots = first_pub.shots

        if shots == default_shots:
            run_options = inputs.get("run_options")
            if run_options is not None:
                shots = run_options.get("shots", default_shots)

        return shots

    def _run(
        self,
        program_id: str,
        inputs: dict,
        options: RuntimeOptions | dict | None = None,
        callback: Callable | None = None,
        result_decoder: type[ResultDecoder] | Sequence[type[ResultDecoder]] | None = None,
        session_id: str | None = None,
        start_session: bool | None = False,
        calibration_id: str | None = None,
    ) -> HubRuntimeJobV2:
        """Execute the runtime program."""

        if calibration_id is not None:
            warnings.warn(
                "The 'calibration_id' parameter is currently not supported by Kipu Quantum Hub and will be ignored.",
                UserWarning,
                stacklevel=2,
            )

        qrt_options: RuntimeOptions = options
        if options is None:
            qrt_options = RuntimeOptions()
        elif isinstance(options, dict):
            qrt_options = RuntimeOptions(**options)

        qrt_options.validate(channel=self.channel)

        backend = qrt_options.backend
        if isinstance(backend, str):
            backend = self.backend(name=qrt_options.get_backend_name())

        status = backend.status()
        if status.operational is True and status.status_msg != "active":
            warnings.warn(f"The backend {backend.name} currently has a status of {status.status_msg}.", stacklevel=2)

        version = inputs.get("version", 1) if inputs else 1

        input_params = {
            "program_id": program_id,
            "backend_name": qrt_options.get_backend_name(),
            "image": qrt_options.image,
            "log_level": qrt_options.log_level,
            "job_tags": qrt_options.job_tags,
            "max_execution_time": qrt_options.max_execution_time,
            "start_session": start_session,
            "session_time": qrt_options.session_time,
            "version": version,
            "private": qrt_options.private,
        }

        backend_id = backend.name
        shots = self._get_shots(inputs, backend)

        # Encode inputs with RuntimeEncoder for Qiskit serialization, then parse back to dict
        encoded_input_json = json.dumps(inputs, cls=RuntimeEncoder)
        parsed_inputs = json.loads(encoded_input_json)

        job_request = JobRequest(
            backend_id=backend_id,
            shots=shots,
            input=parsed_inputs,
            input_format="QISKIT_QPY",
            input_params=input_params,
            sdk_provider="QISKIT",
            session_id=session_id,
        )

        return HubRuntimeJobV2(
            backend=backend,
            job_details=job_request,
            result_decoder=result_decoder,
            hub_client=self._client,
            provider=self,
        )

    def job(self, job_id: str) -> RuntimeJobV2:
        """Retrieve a runtime job."""
        return self.retrieve_job(job_id)

    def jobs(
        self,
        limit: int | None = 10,
        skip: int = 0,
        backend_name: str | None = None,
        pending: bool | None = None,
        program_id: str | None = None,
        instance: str | None = None,
        job_tags: list[str] | None = None,
        session_id: str | None = None,
        created_after: datetime | None = None,
        created_before: datetime | None = None,
        descending: bool = True,
    ) -> list[RuntimeJobV2]:
        raise NotImplementedError("jobs method not yet implemented")

    def least_busy(
        self,
        min_num_qubits: int | None = None,
        instance: str | None = None,
        filters: Callable[["ibm_backend.IBMBackend"], bool] | None = None,
        **kwargs: Any,
    ) -> "HubIbmQiskitBackend":
        """Return the least busy registered IBM backend.

        Calls the Kipu Quantum Hub middleware (`GET /backends/least-busy?provider=IBM[&minQubits=N]`)
        rather than scanning backends client-side.

        Args:
            min_num_qubits: Optional lower bound on the backend's qubit count.
                Mirrors the `min_num_qubits` parameter of IBM's `QiskitRuntimeService.least_busy()`.
            instance: Not supported. Instance / CRN selection is handled by the Hub.
                Passing a non-None value raises NotImplementedError.
            filters: Not supported. The Hub's selection happens server-side and cannot
                apply an arbitrary Python callable. Passing a non-None value raises
                NotImplementedError. Use `min_num_qubits` for qubit-count filtering,
                or fall back to `backends()` and pick manually.
            **kwargs: Accepted for forward compatibility with future IBM Runtime
                parameters; currently ignored.

        Returns:
            The registered HubIbmQiskitBackend wrapping the selected backend.

        Raises:
            NotImplementedError: If `instance` or `filters` is non-None.
            QiskitBackendNotFoundError: If the chosen backend is not registered with this service.
        """
        if filters is not None:
            raise NotImplementedError(
                "least_busy(filters=...) is not supported by HubQiskitRuntimeService. "
                "Use min_num_qubits to filter by qubit count, or fall back to backends() and pick manually."
            )
        if instance is not None:
            raise NotImplementedError(
                "least_busy(instance=...) is not supported by HubQiskitRuntimeService. "
                "Instance selection is handled by Kipu Quantum Hub."
            )

        backend_model = self._client.backends.get_least_busy_backend(
            provider="IBM",
            min_qubits=min_num_qubits,
        )

        backend_class = self._get_backend_class(backend_model.id)
        if backend_class is None:
            raise QiskitBackendNotFoundError(
                f"IBM backend '{backend_model.id}' is not registered with HubQiskitRuntimeService."
            )
        return backend_class(
            service=self,
            hub_client=self._client,
            backend_info=backend_model,
            use_fractional_gates=False,
        )

    @staticmethod
    def save_account(
        token: str | None = None,
        url: str | None = None,
        instance: str | None = None,
        channel: ChannelType | None = None,
        filename: str | None = None,
        name: str | None = None,
        proxies: dict | None = None,
        verify: bool | None = None,
        overwrite: bool | None = False,
        set_as_default: bool | None = None,
        private_endpoint: bool | None = False,
        region: str | None = None,
        plans_preference: str | None = None,
        tags: list[str] | None = None,
    ) -> None:
        raise NotImplementedError("save_account method not supported. Use Kipu Quantum Hub CLI: qhub login")

    @staticmethod
    def saved_accounts(
        default: bool | None = None,
        channel: ChannelType | None = None,
        filename: str | None = None,
        name: str | None = None,
    ) -> dict:
        raise NotImplementedError("saved_accounts method not supported. Use Kipu Quantum Hub CLI: qhub get-context")

    def usage(self) -> dict[str, Any]:
        raise NotImplementedError("usage method not yet implemented")

    @property
    def channel(self) -> str:
        return self._CHANNEL

    def active_instance(self) -> str:
        raise NotImplementedError(
            "active_instance method not supported. Instance management is handled by Kipu Quantum Hub."
        )
