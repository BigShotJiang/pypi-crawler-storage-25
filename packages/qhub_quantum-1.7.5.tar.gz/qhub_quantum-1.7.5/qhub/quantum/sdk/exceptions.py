import functools
import json

from qhub.api.quantum.core import ApiError


class HubError(Exception):
    def __init__(self, *message):
        super().__init__(" ".join(message))
        self.message = " ".join(message)

    def __str__(self):
        return repr(self.message)


class BackendNotSupportedError(HubError):
    pass


# Kept for backward compatibility with braket providers (will be removed after braket migration)
class CredentialUnavailableError(HubError):
    pass


class InvalidAccessTokenError(HubError):
    def __init__(self, value="Invalid personal access token"):
        self.value = value
        super().__init__(self.value)


class HubClientError(Exception):
    """Compatibility shim for braket providers."""

    def __init__(self, response=None):
        super().__init__(response)
        self.response = response

    def __str__(self):
        if self.response and hasattr(self.response, "text") and self.response.text:
            error_json = json.loads(self.response.text)
            error_msg = error_json.get("error_message", error_json.get("detail", None))
            status = error_json.get("status", None)
            return f"{error_msg} (HTTP error: {status})"
        elif self.response and hasattr(self.response, "status_code"):
            return f"HTTP error code: {self.response.status_code}"
        return str(self.response)


class HubApiError(HubError):
    """SDK-side wrapper for any Fern ApiError raised by the Hub API client.

    Renders the server's ``detail`` (or ``title``) as the message and exposes
    the underlying body and status code as attributes. The original
    ``ApiError`` is available on ``__cause__`` for callers that need raw access
    to headers or the full response body.
    """

    def __init__(self, api_error: ApiError):
        self.status_code: int | None = api_error.status_code
        self.body = api_error.body
        self.detail: str = self._extract_detail(api_error.body, api_error.status_code)
        super().__init__(self.detail)

    @staticmethod
    def _extract_detail(body: object, status_code: int | None) -> str:
        if isinstance(body, dict):
            detail = body.get("detail") or body.get("title")
            if detail:
                return str(detail)
            return json.dumps(body)
        if body in (None, ""):
            return f"HTTP {status_code}" if status_code is not None else "Hub API error"
        return str(body)

    def __str__(self) -> str:
        return self.detail


def translate_api_errors(func):
    """Translate Fern ``ApiError`` raised inside ``func`` into :class:`HubApiError`.

    Skips ``status_code == 204``: Fern raises ``ApiError(204)`` to signal
    "request succeeded but no body to parse"; SDK code converts that to
    ``None`` via in-method handlers, so we let the raw ``ApiError`` through.

    Every other status produces a ``HubApiError``. The original ``ApiError`` is
    preserved on ``__cause__``.
    """

    @functools.wraps(func)
    def wrapper(*args, **kwargs):
        try:
            return func(*args, **kwargs)
        except ApiError as exc:
            if exc.status_code == 204:
                raise
            raise HubApiError(exc) from exc

    return wrapper
