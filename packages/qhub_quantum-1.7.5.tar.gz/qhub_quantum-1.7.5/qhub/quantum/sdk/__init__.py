"""Kipu Quantum Hub SDK module providing unified access to quantum providers."""

import sys
from typing import TYPE_CHECKING

from ._version import __version__

if sys.version_info < (3, 11):  # noqa: UP036
    raise RuntimeError(
        f"Kipu Quantum Hub SDK requires Python 3.11 or higher; "
        f"you are running {sys.version_info.major}.{sys.version_info.minor}."
    )

if TYPE_CHECKING:
    from .braket.braket_provider import HubBraketProvider
    from .exceptions import HubApiError
    from .qiskit.hub_qiskit_runtime_service import HubQiskitRuntimeService
    from .qiskit.provider import HubQiskitProvider

__all__ = [
    "HubApiError",
    "HubBraketProvider",
    "HubQiskitProvider",
    "HubQiskitRuntimeService",
    "__version__",
    "braket",
    "qiskit",
]


def __getattr__(name: str):
    current_module = sys.modules[__name__]

    if name == "HubApiError":
        from .exceptions import HubApiError

        setattr(current_module, name, HubApiError)
        return HubApiError
    elif name == "HubBraketProvider":
        from .braket.braket_provider import HubBraketProvider

        setattr(current_module, name, HubBraketProvider)
        return HubBraketProvider
    elif name == "HubQiskitProvider":
        from .qiskit.provider import HubQiskitProvider

        setattr(current_module, name, HubQiskitProvider)
        return HubQiskitProvider
    elif name == "HubQiskitRuntimeService":
        from qhub.quantum.sdk.qiskit.hub_qiskit_runtime_service import HubQiskitRuntimeService

        setattr(current_module, name, HubQiskitRuntimeService)
        return HubQiskitRuntimeService
    elif name == "braket":
        from . import braket

        setattr(current_module, name, braket)
        return braket
    elif name == "qiskit":
        from . import qiskit

        setattr(current_module, name, qiskit)
        return qiskit
    raise AttributeError(f"module '{__name__}' has no attribute '{name}'")
