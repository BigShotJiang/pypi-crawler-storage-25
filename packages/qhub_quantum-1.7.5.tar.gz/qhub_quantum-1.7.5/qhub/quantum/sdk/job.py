import logging
import time
from abc import ABC
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Optional

from qhub.api.quantum import HubQuantumClient
from qhub.api.quantum import Job as JobModel
from qhub.api.quantum.core import ApiError
from qhub.quantum.sdk.exceptions import HubError
from qhub.quantum.sdk.hub_client_proxy import ensure_wrapped

logger = logging.getLogger(__name__)


def _parse_utc(value: str | None) -> datetime | str | None:
    if value is None:
        return None
    try:
        return datetime.fromisoformat(value).replace(tzinfo=UTC)
    except (ValueError, TypeError):
        return value


JOB_FINAL_STATES = {"ABORTED", "COMPLETED", "CANCELLED", "FAILED"}


@dataclass
class JobRequest:
    """Data class for job submission parameters."""

    backend_id: str
    shots: int
    input: Any = None
    input_format: str | None = None
    input_params: Any | None = None
    sdk_provider: str | None = None
    session_id: str | None = None
    name: str | None = None
    tags: list | None = None


class HubBaseJob(ABC):  # noqa: B024
    def __init__(
        self,
        backend: Optional,
        job_id: str | None = None,
        job_details: JobModel | JobRequest | None = None,
        hub_client: HubQuantumClient | None = None,
    ):
        if hub_client is None:
            raise RuntimeError("hub_client must not be None")
        self._client = ensure_wrapped(hub_client)

        if job_id is None and job_details is None:
            raise ValueError("Either 'job_id', 'job_details' or both must be provided.")

        self._result = None
        self._backend = backend
        self._job_details = None
        self._job_request = None
        self._status = None

        if isinstance(job_details, JobRequest):
            self._job_request = job_details
            self._submit()
        elif isinstance(job_details, JobModel):
            self._job_details = job_details
        elif job_id is not None and job_details is None:
            self._refresh(job_id)
        else:
            self._job_details = job_details

    def _submit(self):
        """
        Submits the job for execution.
        """
        if self._job_request is None:
            raise RuntimeError("Cannot submit job as no job request is set.")

        req = self._job_request
        self._job_details = self._client.jobs.create_job(
            backend_id=req.backend_id,
            shots=req.shots,
            input=req.input,
            input_format=req.input_format,
            input_params=req.input_params,
            session_id=req.session_id,
            name=req.name,
            tags=req.tags,
            sdk_provider=req.sdk_provider,
        )

    def _result_states(self) -> set[str]:
        """Returns the set of job states that are considered final for result retrieval."""
        return {"COMPLETED"}

    def _result(self) -> any:
        """Polls for the job result until the job has completed successfully and returns the result.

        Returns:
            The job result if the job completed successfully. The result format is backend specific.

        Raises:
            An error if the job did reach another end state as `COMPLETED`
        """
        if self._result is not None:
            return self._result

        status = self._update_state()
        if status not in JOB_FINAL_STATES:
            status = self._wait_for_final_state()

        if status in self._result_states():
            self._result = self._client.jobs.get_job_result(self.id)
            return self._result

        if status == "FAILED":
            error_result_data = self._client.jobs.get_job_result(self.id)
            msg = f"Cannot retrieve results because the job execution failed with status '{status}'."
            if error_result_data:
                msg += f" Reason: {error_result_data}."
            raise RuntimeError(msg)

        raise RuntimeError(f"Cannot retrieve results as job execution has not completed (status: {self._status}).")

    def _wait_for_final_state(self, timeout: float | None = None, wait: float = 5) -> str:
        """Poll the job status until it progresses to a final state such as ``DONE`` or ``ERROR``.

        Args:
            timeout: Seconds to wait for the job. If ``None``, wait indefinitely.
            wait: Seconds between queries.

        Raises:
            HubError: If the job does not reach a final state before the specified timeout.
        """
        start_time = time.time()
        status = self._update_state()
        while status not in JOB_FINAL_STATES:
            logger.debug(
                "Waiting for job %s to complete for retrieving its result. Current job status %s",
                self.id,
                status,
            )
            elapsed_time = time.time() - start_time
            if timeout is not None and elapsed_time >= timeout:
                raise HubError(f"Timeout while waiting for job {self.id}.")
            time.sleep(wait)
            status = self._update_state()
        return status

    def _update_state(self, use_cached_value: bool = False) -> str:
        """
        Return the status of the job.

        Args:
            use_cached_value (bool): If `True`, uses the value most recently retrieved from Kipu Quantum Hub.
        """
        if not use_cached_value and self._status not in JOB_FINAL_STATES:
            response = self._client.jobs.get_job_status(self.id)
            self._status = response.status

        return self._status

    @property
    def id(self) -> str:
        """
        This job's id.
        """
        return self._job_details.id if self._job_details is not None else None

    def job_id(self) -> str:
        """
        This job's id.
        """
        return self.id

    @property
    def shots(self) -> int:
        return self._job_details.shots

    @property
    def created_at(self) -> datetime | str | None:
        self._refresh()
        return _parse_utc(self._job_details.created_at)

    @property
    def started_at(self) -> datetime | str | None:
        self._refresh()
        return _parse_utc(self._job_details.started_at)

    @property
    def ended_at(self) -> datetime | str | None:
        self._refresh()
        return _parse_utc(self._job_details.ended_at)

    def cancel(self):
        """
        Attempt to cancel the job.
        """
        self._client.jobs.cancel_job(self.id)

    def _refresh(self, job_id: str | None = None):
        """
        Refreshes the job details from the server.
        """
        if job_id is None and self.id is None:
            raise ValueError("Job id is not set.")

        job_id = job_id if job_id is not None else self.id
        self._job_details = self._client.jobs.get_job(job_id)
        self._update_state()

    def calibration(self) -> dict[str, Any] | None:
        """
        Retrieve the backend calibration that was effective when the job execution started.

        Note:
            The backend calibration data is unavailable if the job was executed on a simulator
            or if the job has not been executed yet.

        Returns:
            Optional[Dict[str, Any]]: Backend calibration data or None if no calibration data is available.
            The data format is backend specific.
        """
        try:
            response = self._client.jobs.get_job_calibration(self.id)
            return response.calibration if response else None
        except ApiError as e:
            if e.status_code == 204:
                return None
            raise
