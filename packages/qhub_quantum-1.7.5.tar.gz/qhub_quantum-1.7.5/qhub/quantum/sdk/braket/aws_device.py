import json
import warnings
from abc import ABC
from typing import Any

from braket.annealing import Problem
from braket.aws import AwsDevice, AwsSession
from braket.aws.queue_information import QueueDepthInfo, QueueType
from braket.circuits import Circuit, GateCalibrations
from braket.device_schema import DeviceCapabilities
from braket.device_schema.pulse.frame_v1 import Frame
from braket.pulse import Port
from networkx import DiGraph
from qhub.quantum.sdk.backend import HubBackend
from qhub.quantum.sdk.braket.hub_quantum_task import HubAwsQuantumTask
from qhub.quantum.sdk.decorators import not_implemented, not_supported
from qhub.quantum.sdk.job import HubBaseJob, JobRequest


class HubAwsDevice(HubBackend, AwsDevice, ABC):
    def __init__(self, **kwargs):
        self._backend_config = None
        super().__init__(**kwargs)

    @property
    def arn(self) -> str:
        warnings.warn(
            "Kipu Quantum Hub AWS devices are identified by their id instead of the ARN.",
            UserWarning,
            stacklevel=2,
        )
        return self.backend_info.internal_id

    @property
    @not_supported
    def aws_session(self) -> AwsSession:
        # Aws session is not supported for Kipu Quantum Hub AWS devices
        pass

    def refresh_metadata(self) -> None:
        """Refresh the `HubAwsDevice` object with the most recent Device metadata."""
        self._backend_info = self._hub_client.backends.get_backend(self.backend_info.id)
        self._get_backend_config(refresh=True)

    @property
    def name(self) -> str:
        return self.backend_info.name if self.backend_info.name is not None else self.backend_info.id

    @property
    def type(self) -> str:
        """str: Return the device type"""
        return "SIMULATOR" if self.backend_info.type == "SIMULATOR" else "QPU"

    @property
    def backend_provider(self) -> str:
        return "AWS"

    @property
    def provider_name(self) -> str:
        """str: Return the provider name"""
        return self.backend_info.hardware_provider

    @property
    @not_implemented
    def ports(self) -> dict[str, Port]:
        """Returns a dict mapping port ids to the port objects for predefined ports
        for this device.
        """
        pass

    @property
    def gate_calibrations(self) -> GateCalibrations | None:
        """Calibration data for a QPU. Calibration data is shown for gates on particular gubits.
        If a QPU does not expose these calibrations, None is returned.

        Returns:
            Optional[GateCalibrations]: The calibration object. Returns `None` if the data
            is not present.
        """
        return None

    @property
    def is_available(self) -> bool:
        """Returns true if the device is currently available.

        Returns:
            bool: Return if the device is currently available.
        """
        hub_status: str = self._get_backend_state().status
        return True if hub_status == "ONLINE" else False

    @property
    def status(self) -> str:
        hub_status: str = self._get_backend_state().status
        return "ONLINE" if hub_status == "PAUSED" else hub_status

    @property
    def properties(self) -> DeviceCapabilities:
        """DeviceCapabilities: Return the device properties

        Please see `braket.device_schema` in amazon-braket-schemas-python_

        .. _amazon-braket-schemas-python: https://github.com/aws/amazon-braket-schemas-python
        """
        config = self._get_backend_config()
        return DeviceCapabilities.parse_raw(json.dumps(config))

    def _run_job(self, job_request: JobRequest) -> HubBaseJob:
        job_request.sdk_provider = "BRAKET"
        return HubAwsQuantumTask(_backend=self, _job_details=job_request, _hub_client=self._hub_client)

    def run_batch(
        self,
        task_specifications: Circuit | Problem | list[Circuit | Problem],
        shots: int | None,
        max_parallel: int | None,
        inputs: dict[str, float] | list[dict[str, float]] | None,
        *args: Any,
        **kwargs: Any,
    ):
        raise NotImplementedError(
            "This function is not implemented yet. "
            "Please contact Kipu Quantum Hub support if you require this functionality."
        )

    @property
    def topology_graph(self) -> DiGraph:
        """DiGraph: topology of device as a networkx `DiGraph` object.

        Examples:
            >>> import networkx as nx
            >>> device = AwsDevice("arn1")
            >>> nx.draw_kamada_kawai(device.topology_graph, with_labels=True, font_weight="bold")

            >>> topology_subgraph = device.topology_graph.subgraph(range(8))
            >>> nx.draw_kamada_kawai(topology_subgraph, with_labels=True, font_weight="bold")

            >>> print(device.topology_graph.edges)

        Returns:
            DiGraph: topology of QPU as a networkx `DiGraph` object. `None` if the topology
            is not available for the device.
        """
        return super()._construct_topology_graph()

    @property
    @not_implemented
    def frames(self) -> dict[str, Frame]:
        """Returns a dict mapping frame ids to the frame objects for predefined frames
        for this device.
        """
        pass

    def queue_depth(self) -> QueueDepthInfo:
        """Return queue depth for this device.

        Returns a ``QueueDepthInfo`` populated from the Kipu Quantum Hub
        backend state. Only the ``NORMAL`` quantum-tasks queue is populated
        (the middleware reads only that queue from
        ``DeviceQueueInfo``). ``PRIORITY`` and ``jobs`` are reported as
        ``"unknown"``.
        """
        state = self._get_backend_state()
        queue_size = str(state.queue_size) if state.queue_size is not None else "unknown"
        return QueueDepthInfo(
            quantum_tasks={QueueType.NORMAL: queue_size},
            jobs="unknown",
        )

    @not_implemented
    def refresh_gate_calibrations(self) -> GateCalibrations | None:
        """Refreshes the gate calibration data upon request.

        If the device does not have calibration data, None is returned.

        Raises:
            URLError: If the URL provided returns a non 2xx response.

        Returns:
            Optional[GateCalibrations]: the calibration data for the device. None
            is returned if the device does not have a gate calibrations URL associated.
        """
        pass
