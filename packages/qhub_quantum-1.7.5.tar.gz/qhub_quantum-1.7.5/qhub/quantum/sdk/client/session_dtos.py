"""
Compatibility shim — re-exports old session DTO types.
Will be removed once braket migration is complete.
"""

from enum import Enum

from pydantic import BaseModel


class SessionMode(Enum):
    BATCH = "batch"
    DEDICATED = "dedicated"


class SessionStatus(Enum):
    UNKNOWN = "UNKNOWN"
    ABORTED = "ABORTED"
    OPEN = "OPEN"
    ACTIVE = "ACTIVE"
    INACTIVE = "INACTIVE"
    DRAINING = "DRAINING"
    CLOSED = "CLOSED"


class SessionResponse(BaseModel):
    id: str
    backend_id: str = ""
    provider: str = "UNKNOWN"
    status: SessionStatus = SessionStatus.UNKNOWN
    mode: SessionMode = SessionMode.DEDICATED
    created_at: str | None = None
    started_at: str | None = None
    closed_at: str | None = None
    expires_at: str | None = None
    usage_time_millis: int | None = None
    provider_id: str | None = None
    metadata: dict | None = None
    sdk_provider: str | None = None
