//! Shared broker types: positions, accounts, orders, quotes.

use std::fmt::Write;
use std::time::SystemTime;

use nanobook::{Price, Symbol};
use sha2::{Digest, Sha256};

use crate::error::BrokerError;

/// Convert an `f64` value to a fixed-point `i64` at the given `scale`,
/// rejecting `NaN`, `±Inf`, and values whose scaled magnitude does not
/// fit in `i64`.
///
/// `field` is baked into the error message so callers can grep logs
/// for the specific upstream field that misbehaved.
///
/// Rounding follows `f64::round` (half-away-from-zero), matching the
/// convention used elsewhere for dollar→cents conversion. Truncation
/// (the default behavior of `as i64`) produces a systematic downward
/// bias for positive money and is avoided intentionally.
///
/// # Errors
///
/// - [`BrokerError::NonFiniteValue`] if `value` is `NaN` or `±Inf`.
/// - [`BrokerError::ValueOutOfRange`] if `value * scale` falls outside
///   the closed interval `[i64::MIN, i64::MAX]`.
pub fn f64_to_fixed_checked(
    value: f64,
    scale: f64,
    field: &'static str,
) -> Result<i64, BrokerError> {
    if !value.is_finite() {
        return Err(BrokerError::NonFiniteValue { field, value });
    }
    let rounded = (value * scale).round();
    // `i64::MAX as f64` rounds UP to `2^63`, which is one past the
    // maximum `i64`. Use half-open `[i64::MIN, 2^63)` to both include
    // `i64::MIN` (exactly representable) and exclude the unrepresentable
    // positive bound. Checking the ROUNDED value avoids a corner case
    // where `scaled < 2^63` but `scaled.round() == 2^63` in floating
    // point — which would otherwise let `as i64` saturate silently.
    const MAX_EXCLUSIVE: f64 = i64::MAX as f64;
    const MIN_INCLUSIVE: f64 = i64::MIN as f64;
    if !(MIN_INCLUSIVE..MAX_EXCLUSIVE).contains(&rounded) {
        return Err(BrokerError::ValueOutOfRange { field, value });
    }
    Ok(rounded as i64)
}

/// Shorthand for [`f64_to_fixed_checked(value, 100.0, field)`]. Use
/// for dollar / USDT / fiat amounts scaled to cents.
#[inline]
pub fn f64_cents_checked(value: f64, field: &'static str) -> Result<i64, BrokerError> {
    f64_to_fixed_checked(value, 100.0, field)
}

/// Broker-level position (the real-world counterpart, not the LOB position).
#[derive(Debug, Clone)]
pub struct Position {
    pub symbol: Symbol,
    /// Positive = long, negative = short.
    pub quantity: i64,
    pub avg_cost_cents: i64,
    pub market_value_cents: i64,
    pub unrealized_pnl_cents: i64,
}

/// Account summary from the broker.
#[derive(Debug, Clone)]
pub struct Account {
    pub equity_cents: i64,
    pub buying_power_cents: i64,
    pub cash_cents: i64,
    pub gross_position_value_cents: i64,
}

/// Order to submit to a broker.
#[derive(Debug, Clone)]
pub struct BrokerOrder {
    pub symbol: Symbol,
    pub side: BrokerSide,
    pub quantity: u64,
    pub order_type: BrokerOrderType,
    pub client_order_id: Option<ClientOrderId>,
}

/// Buy or sell.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum BrokerSide {
    Buy,
    Sell,
}

/// Deterministic client-side order identifier.
///
/// The derived form is SHA-256 of a canonical `(scope, symbol, side, qty)`
/// tuple, hex-encoded and truncated to 32 chars. This fits Binance's
/// 36-character `newClientOrderId` limit and IBKR's 40-character `orderRef`.
#[derive(Debug, Clone, PartialEq, Eq, Hash)]
pub struct ClientOrderId(String);

impl ClientOrderId {
    pub fn derive(scope: &str, symbol: &str, side: BrokerSide, qty: u64) -> Self {
        let mut h = Sha256::new();
        h.update(scope.as_bytes());
        h.update(b"\0");
        h.update(symbol.as_bytes());
        h.update(b"\0");
        h.update(match side {
            BrokerSide::Buy => b"B",
            BrokerSide::Sell => b"S",
        });
        h.update(b"\0");
        h.update(qty.to_le_bytes());

        let digest = h.finalize();
        let mut hex = String::with_capacity(32);
        for b in &digest[..16] {
            write!(&mut hex, "{b:02x}").expect("writing to String cannot fail");
        }
        Self(hex)
    }

    pub fn new(value: impl Into<String>) -> Result<Self, BrokerError> {
        let value = value.into();
        if value.is_empty() || value.len() > 36 {
            return Err(BrokerError::Order(
                "client_order_id must be 1..=36 ASCII-safe characters".into(),
            ));
        }
        if !value
            .bytes()
            .all(|b| b.is_ascii_alphanumeric() || b == b'_' || b == b'.' || b == b'-')
        {
            return Err(BrokerError::Order(
                "client_order_id contains unsafe query characters".into(),
            ));
        }
        Ok(Self(value))
    }

    pub fn as_str(&self) -> &str {
        &self.0
    }
}

/// Market or limit order.
#[derive(Debug, Clone, Copy)]
pub enum BrokerOrderType {
    Market,
    Limit(Price),
}

/// Live quote from the broker.
#[derive(Debug, Clone)]
pub struct Quote {
    pub symbol: Symbol,
    pub bid_cents: i64,
    pub ask_cents: i64,
    pub last_cents: i64,
    pub volume: u64,
    /// Timestamp when this quote was received from the broker.
    /// Used for staleness detection to prevent trading on outdated prices.
    pub timestamp: SystemTime,
}

impl Quote {
    /// Check if this quote is stale based on the given threshold.
    ///
    /// Returns true if the time elapsed since the quote was received
    /// exceeds the threshold in seconds.
    ///
    /// # Arguments
    /// * `threshold_sec` - Maximum age of the quote in seconds before it's considered stale
    ///
    /// # Returns
    /// * `true` if the quote is stale (age > threshold)
    /// * `false` if the quote is fresh (age <= threshold)
    pub fn is_stale(&self, threshold_sec: u64) -> bool {
        match self.timestamp.elapsed() {
            Ok(elapsed) => elapsed.as_secs() > threshold_sec,
            Err(_) => {
                // If the timestamp is in the future (clock skew), treat as stale
                true
            }
        }
    }
}

/// Last-seen bid/ask quote used to bound market-order fallbacks.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub struct BestQuote {
    pub bid_cents: i64,
    pub ask_cents: i64,
}

/// Opaque order ID returned by the broker.
#[derive(Debug, Clone, Copy, PartialEq, Eq, Hash)]
pub struct OrderId(pub u64);

/// Status of a submitted order.
#[derive(Debug, Clone)]
pub struct BrokerOrderStatus {
    pub id: OrderId,
    pub status: OrderState,
    pub filled_quantity: u64,
    pub remaining_quantity: u64,
    pub avg_fill_price_cents: i64,
}

/// Lifecycle state of an order.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum OrderState {
    Pending,
    Submitted,
    PartiallyFilled,
    Filled,
    Cancelled,
    Rejected,
}

#[cfg(test)]
mod tests {
    use super::*;
    use std::time::Duration;

    #[test]
    fn test_fresh_quote() {
        let quote = Quote {
            symbol: Symbol::new("AAPL"),
            bid_cents: 15000,
            ask_cents: 15050,
            last_cents: 15025,
            volume: 1000,
            timestamp: SystemTime::now(),
        };
        assert!(!quote.is_stale(30));
        assert!(!quote.is_stale(60));
    }

    #[test]
    fn test_stale_quote() {
        let quote = Quote {
            symbol: Symbol::new("AAPL"),
            bid_cents: 15000,
            ask_cents: 15050,
            last_cents: 15025,
            volume: 1000,
            timestamp: SystemTime::now() - Duration::from_secs(35),
        };
        assert!(quote.is_stale(30));
        assert!(!quote.is_stale(60));
    }

    #[test]
    fn test_exactly_threshold() {
        let quote = Quote {
            symbol: Symbol::new("AAPL"),
            bid_cents: 15000,
            ask_cents: 15050,
            last_cents: 15025,
            volume: 1000,
            timestamp: SystemTime::now() - Duration::from_secs(30),
        };
        // Exactly at threshold is NOT stale (age > threshold, not >=)
        assert!(!quote.is_stale(30));
    }

    #[test]
    fn test_future_timestamp() {
        let quote = Quote {
            symbol: Symbol::new("AAPL"),
            bid_cents: 15000,
            ask_cents: 15050,
            last_cents: 15025,
            volume: 1000,
            timestamp: SystemTime::now() + Duration::from_secs(10),
        };
        // Future timestamp (clock skew) is treated as stale
        assert!(quote.is_stale(30));
    }
}
