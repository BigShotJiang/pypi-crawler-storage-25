<!-- This file is auto-generated -->

# Ellf CLI

Before using Ellf CLI you need to have an **Ellf** account. You also need a deployed cluster and Python 3.6+. To see all available commands or subcommands, you can use the `--help` flag, e.g. `ptc --help`.

## `ptc`

Ellf Command Line Interface.

### `ptc actions`

Interact with actions on the cluster

#### `ptc actions create`

Create a new action. The available action recipes are fetched from your cluster and are added as dynamic subcommands. You can see more details and available arguments by calling the subcommand with --help, e.g. create [name] --help

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--no-start` | `bool` | Don't start {noun} after creation | `False` |
| `--no-wait` | `bool` | Don't wait for the action to be ready after starting | `False` |
| `--help`, `-h` | `bool` | Show help message | `False` |
| `_extra` | `str` |  | `[]` |

#### `ptc actions list`

List the actions on the cluster. By default, this includes their ID, name and current state, e.g. created or completed

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'stats', 'state'] | `['id', 'name', 'state', 'project_name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc actions info`

Print information about an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the action |  |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'stats', 'recipe_name', 'recipe_title', 'evaluation', 'project_name', 'error', 'executions', 'last_execution_id', 'url_logs', 'url', 'related_tasks', 'created_by_user'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc actions logs`

Get logs for an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the action (or the last action if not set) | `None` |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--errors` | `bool` | Show structured error information instead of full logs | `False` |
| `--query` | `str` | Filter log lines matching this text (requires Loki) | `None` |

#### `ptc actions start`

Start an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the action (or the last action if not set) | `None` |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--worker-class` | `str` | Worker class to launch the action on. Generally one of: ['medium', 'large', 'gpu'] | `None` |
| `--no-wait` | `bool` | Don't wait for the action to be ready after starting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc actions stop`

Stop an action on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the action (or the last action if not set) | `None` |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc actions delete`

Delete an Action by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the action |  |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc coding-tasks`

Manage coding tasks for handoff between web assistant and local Claude Code

#### `ptc coding-tasks list`

List coding tasks

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'conversation_id', 'creator_id', 'assigned_to', 'description', 'context_summary', 'resolution', 'status'] | `['id', 'project_id', 'status', 'description']` |
| `--project` | `UUID` | Filter by project | `None` |
| `--status` | `str` | Filter by status | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks info`

Get detailed info for an coding task

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the coding task |  |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'conversation_id', 'creator_id', 'assigned_to', 'description', 'context_summary', 'resolution', 'status'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks pull`

Pull planned coding tasks and mark them as in-progress

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--project` | `UUID` | Filter by project | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks create`

Create a new coding task

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--project` | `UUID` | ID of coding task's project (or the last project if not set) |  |
| `--description` | `str` | Description of the coding task |  |
| `--context` | `str` | Context summary for the coding task | `None` |
| `--conversation` | `UUID` | Conversation ID to associate with the coding task | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks latest`

Get the most recently updated non-done coding task.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks context`

Fetch conversation messages for a task's linked conversation.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the coding task |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks update`

Update a coding task

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the coding task |  |
| `--status` | `str` | New status (planned, in_progress, done, cancelled) | `None` |
| `--description` | `str` | New description for the coding task | `None` |
| `--resolution` | `str` | What was done (or why nothing was done). Set when closing a task. | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc coding-tasks delete`

Delete a coding task

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `id` | `UUID` | ID of the coding task |  |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc agents`

Interact with agents on the cluster

#### `ptc agents create`

Create a new agent. The available agent recipes are fetched from your cluster and are added as dynamic subcommands. You can see more details and available arguments by calling the subcommand with --help, e.g. create [name] --help

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--no-start` | `bool` | Don't start {noun} after creation | `False` |
| `--no-wait` | `bool` | Don't wait for the agent to be ready after starting | `False` |
| `--help`, `-h` | `bool` | Show help message | `False` |
| `_extra` | `str` |  | `[]` |

#### `ptc agents assign`

Assign an agent to a task as an annotator

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `--task` | `Union[str, UUID]` | Task name or ID to assign the agent to |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc agents list`

List the agents on the cluster. By default, this includes their ID, name and current state, e.g. created or completed

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'state'] | `['id', 'name', 'state', 'project_name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc agents info`

Print information about an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'project_id', 'job_type', 'plan', 'cli_command', 'recipe_name', 'recipe_title', 'project_name', 'error', 'last_execution_id', 'related_tasks', 'created_by_user'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc agents logs`

Get logs for an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the agent (or the last agent if not set) | `None` |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--errors` | `bool` | Show structured error information instead of full logs | `False` |
| `--query` | `str` | Filter log lines matching this text (requires Loki) | `None` |

#### `ptc agents start`

Start an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the agent (or the last agent if not set) | `None` |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--worker-class` | `str` | Worker class to launch the agent on. Generally one of: ['medium', 'large', 'gpu'] | `None` |
| `--no-wait` | `bool` | Don't wait for the agent to be ready after starting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc agents stop`

Stop an agent on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the agent (or the last agent if not set) | `None` |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc agents delete`

Delete an agent by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the agent |  |
| `project_id` | `UUID` | ID of agent's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for agent name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc assets`

View and manage assets on the cluster

#### `ptc assets list`

List all assets on the cluster registered with Ellf

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'version', 'kind', 'path', 'meta'] | `['id', 'name', 'kind']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc assets info`

Get detailed info for an asset uploaded to the cluster and registered with Ellf

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the asset |  |
| `project_id` | `UUID` | ID of asset's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for asset name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'version', 'kind', 'path', 'meta', 'tasks', 'actions'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc assets create`

Create an asset on the cluster and register it with Ellf. Assets point to files or directories you control. The Ellf server only has a reference to them. This command doesn't transfer any data. See `ptc files` for utilities to transfer files to and from your cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the asset |  |
| `--kind` | `str` | Kind of the asset. Generally one of: ['Input', 'Model', 'Patterns] |  |
| `path` | `str` | Path of the asset |  |
| `--version` | `str` | Version of the asset | `'0.0.0'` |
| `--meta` | `str` | Asset meta, formatted as a JSON string | `'{}'` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc assets delete`

Delete an asset registered with Ellf

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the asset |  |
| `project_id` | `UUID` | ID of asset's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for asset name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc clusters`

Interact with clusters

#### `ptc clusters list`

List resources on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'address', 'state'] | `['id', 'name', 'status', 'address']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc clusters info`

Get detailed info for a cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the cluster |  |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'address', 'state', 'cloud'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc clusters update`

Update the cluster info

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the cluster |  |
| `--new-name` | `str` | New name of the cluster | `None` |
| `--address` | `str` | New address of the cluster | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc clusters delete`

Delete a cluster from PAM. This only removes PAM's record of it. The cluster itself will continue to exist - you need to shut it down separately.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the cluster |  |

#### `ptc clusters check`

Check the health of a cluster deployment. Runs CLI-side connectivity checks against the broker and PAM. Use --deep to also trigger broker-side deployment checks (K8s API, NFS, database, etc.).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--s3-bucket` | `str` | Run checks involving the S3 storage | `None` |
| `--nfs-path` | `str` | Run checks involving the NFS storage | `None` |
| `--recipe` | `str` | Run checks that need to operate over a recipe. This argument only makes sense when used with --recipe-args | `None` |
| `--recipe-args` | `str` | Run checks that need to operate over a recipe. This argument only makes sense when used with --recipe | `None` |
| `--deep` | `bool` | Run broker-side deployment checks (K8s, NFS, DB) | `False` |

#### `ptc clusters nodes`

List cluster nodes with capacity and utilization.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['name', 'status', 'cpu', 'memory', 'gpu', 'pod_count'] | `['name', 'status', 'cpu', 'memory', 'gpu', 'pod_count']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc clusters rotate-key`

Rotate the broker RSA keypair. Generates a new keypair, updates the broker record in PAM with the new public key, patches the K8s secret with the new private key, and restarts the broker deployment.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--infra-secret` | `str` | Name of the K8s secret holding PRODIGY_TEAMS_PRIVATE_KEY | `'prodigy-teams-infra'` |
| `--namespace` | `str` | K8s namespace | `'prodigy-teams'` |

#### `ptc clusters settings`

Show cluster settings (auto-update, cleanup, target versions).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc clusters settings-update`

Update cluster settings.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--cluster` | `str` | Name or ID of the cluster | `None` |
| `--auto-update-broker` | `bool` | Enable/disable auto-update for broker | `False` |
| `--auto-update-cpl` | `bool` | Enable/disable auto-update for CPL | `False` |
| `--auto-update-recipes` | `bool` | Enable/disable auto-update for recipes | `False` |
| `--cleanup-orphaned-jobs` | `bool` | Enable/disable cleanup of orphaned jobs | `False` |
| `--target-broker-version` | `str` | Set target broker version to install | `None` |
| `--target-cpl-version` | `str` | Set target CPL version to install | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc clusters releases`

List available releases.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc config`

Configure the CLI

#### `ptc config reset`

Reset all caching and configuration.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc config project`

Set the default project.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc config task`

Set the default task.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the task |  |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc config action`

Set the default action.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the action |  |
| `project_id` | `UUID` | ID of action's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for action name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc config set-cluster-host`

Set the broker cluster host.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `host` | `str` | Host or URL of the cluster |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc config set-pam-host`

Set the PAM host.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `host` | `str` | Host or URL of the Prodigy Annotation Manager (PAM) app |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc config set-recipes-file`

Set or clear a local recipes file for PAM-free recipe discovery.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `path` | `str` | Path to a local recipes YAML file | `None` |
| `--clear` | `bool` | Clear the recipes file setting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc datasets`

View and manage Prodigy datasets on the cluster

#### `ptc datasets list`

List all Datasets

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'broker_id', 'kind'] | `['id', 'name', 'kind']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc datasets info`

Get detailed info for a Dataset

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the dataset |  |
| `cluster_id` | `UUID` | ID of the cluster to search for dataset name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'broker_id', 'kind', 'tasks', 'actions'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc datasets create`

Create a new dataset

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the dataset |  |
| `--kind` | `str` | Kind of the dataset, used to filter in recipes to only allow specific types |  |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc datasets delete`

Delete a dataset

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the dataset |  |
| `cluster_id` | `UUID` | ID of the cluster to search for dataset name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc datasets export`

Export all the examples from a dataset and save it in the designated file as JSONL (newline-delimited JSON).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the dataset |  |
| `--output`, `-o` | `str` | JSON output path for data | `'-'` |

### `ptc files`

Manage files on the cluster. Your files are only ever sent to servers or buckets you control. They are never sent to our servers.

#### `ptc files cp`

Copy files to and from the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `str` | Remote or local path of the source |  |
| `dest` | `str` | Remote or local path of the destination |  |
| `--recurse`, `-r` | `bool` | Copy whole directory recursively | `False` |
| `--make-dirs` | `bool` | Create parent directories if they don't exist | `False` |
| `--overwrite` | `bool` | Overwrite if exists | `False` |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc files ls`

List the files under `remote`

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `remote` | `str` | Remote location path |  |
| `--recurse`, `-r` | `bool` | List files recursively | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--expand-path-aliases` | `bool` | Expand path aliases when displaying remote paths | `False` |

#### `ptc files rm`

Remove files from the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `remote_path` | `str` | Remote location path |  |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--missing-ok` | `bool` | If missing, don't raise an error | `False` |
| `--recurse`, `-r` | `bool` | Delete the whole directory recursively | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc files rsync`

Rsync files to and from the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `str` | Remote or local path of the source |  |
| `dest` | `str` | Remote or local path of the destination |  |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc files stats`

Get the stats for a file located in `remote_path`

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `remote_path` | `str` | Remote location path |  |
| `--cluster-host` | `str` | Name of the cluster (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc gcp`

Configure, deploy and monitor cloud resources under your Google Cloud account

### `ptc jobs`

Run jobs directly on the cluster

#### `ptc jobs run`

Run a job directly on the broker from a YAML spec file, bypassing PAM.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `spec_path` | `str` | Path to a YAML job spec file |  |

### `ptc packages`

View and manage Python packages on the cluster

#### `ptc packages list`

List all packages

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'version', 'container', 'recipe_count'] | `['id', 'name', 'version', 'recipe_count', 'num_used_by']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc packages info`

Get detailed info for a package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the package |  |
| `cluster_id` | `UUID` | ID of the cluster to search for package name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'version', 'container', 'recipe_count', 'org_id', 'broker_id', 'filename', 'meta', 'tasks', 'actions', 'author'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc packages create`

Create a new package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the package |  |
| `--kind` | `str` | Kind of the package, used to filter in recipes to only allow specific types |  |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc packages delete`

Delete a package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the package |  |
| `cluster_id` | `UUID` | ID of the cluster to search for package name (or the last cluster if not set) | `None` |
| `--force` | `bool` | Delete related actions or tasks as well | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc paths`

View and manage path aliases on the cluster

#### `ptc paths list`

List all cluster path aliases

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'path'] | `['created', 'id', 'name', 'path']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc paths info`

Get detailed info for a path alias

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the path |  |
| `cluster_id` | `UUID` | ID of the cluster to search for path name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'broker_id', 'name', 'path'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc paths create`

Create a new path alias

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the path |  |
| `path` | `str` | Path of the cluster directory |  |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc paths delete`

Delete a path alias

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the path |  |
| `cluster_id` | `UUID` | ID of the cluster to search for path name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc projects`

View and manage Ellf projects

#### `ptc projects list`

List all projects

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'description', 'default_job_name_template'] | `['id', 'name']` |
| `--name` | `str` | Filter by name | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc projects info`

Get detailed info for a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'name', 'description', 'default_job_name_template'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc projects create`

Create a new project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the project |  |
| `description` | `str` | Description of the project |  |
| `--default-job-name-template` | `str` | Default name template for new jobs (e.g. '{recipe}_{date}') | `None` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc projects update`

Update a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--name` | `str` | New name for the project | `None` |
| `--description` | `str` | New description for the project | `None` |
| `--default-job-name-template` | `str` | Default name template for new jobs (e.g. '{recipe}_{date}') | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc projects delete`

Delete a project

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the project |  |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc recipes`

View and manage annotation recipe packages on the cluster

#### `ptc recipes list`

List all recipes

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'package_id', 'name', 'title', 'description', 'job_type', 'is_action', 'is_latest', 'entry_point'] | `['id', 'name', 'package']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc recipes export`

Export recipes from the cluster to a local YAML file.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `output_path` | `str` | Output path for the recipes YAML file |  |

#### `ptc recipes info`

Show info about a recipe

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the recipe |  |
| `cluster_id` | `UUID` | ID of the cluster to search for recipe name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'org_id', 'package_id', 'name', 'title', 'description', 'job_type', 'is_action', 'is_latest', 'entry_point', 'form_schema', 'cli_schema', 'meta', 'tasks', 'actions', 'package'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc recipes init`

Generate a new recipes Python package

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `output_dir` | `Path` | Output directory for the recipe package |  |
| `--name` | `str` | Name of the package (e.g. custom_recipes) | `None` |
| `--version` | `str` | Version of the package | `'0.1.0'` |
| `--description` | `str` | Description of the package | `''` |
| `--author` | `str` | Name of the package author | `''` |
| `--email` | `str` | Email of the package author | `''` |
| `--url` | `str` | URL of the package | `''` |
| `--license` | `str` | License of the package | `''` |

### `ptc secrets`

View and manage named pointers to secrets on the cluster

#### `ptc secrets list`

List all named pointers to secrets on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'path', 'broker_id'] | `['created', 'id', 'name', 'path']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc secrets info`

Show info about a secret on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the secret |  |
| `cluster_id` | `UUID` | ID of the cluster to search for secret name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'name', 'path', 'broker_id'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc secrets create`

Create a named pointer to a secret on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name` | `str` | Name of the secret |  |
| `--secrets-path` | `str` | / separated key prefix to save secrets to | `'/'` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `_extra` | `str` |  |  |

#### `ptc secrets delete`

Delete a secret by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the secret |  |
| `cluster_id` | `UUID` | ID of the cluster to search for secret name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc tasks`

Interact with annotation tasks on the cluster

#### `ptc tasks create`

Create a new task. The available task recipes are fetched from your cluster and are added as dynamic subcommands. You can see more details and available arguments by calling the subcommand with --help, e.g. create [name] --help

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |
| `--no-start` | `bool` | Don't start {noun} after creation | `False` |
| `--no-wait` | `bool` | Don't wait for the task to be ready after starting | `False` |
| `--help`, `-h` | `bool` | Show help message | `False` |
| `_extra` | `str` |  | `[]` |

#### `ptc tasks list`

List the tasks on the cluster. By default, this includes their ID, name and current state, e.g. created or completed

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'broker_id', 'name', 'recipe_name', 'recipe_title', 'project_name', 'error', 'plan', 'job_type', 'cli_command', 'state'] | `['id', 'name', 'state', 'project_name']` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc tasks info`

Print information about a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the task |  |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--select` | `list[str]` | Comma-separated fields to select and show in output. Available: ['id', 'created', 'updated', 'project_id', 'broker_id', 'name', 'recipe_name', 'recipe_title', 'project_name', 'error', 'plan', 'job_type', 'cli_command', 'last_execution_id', 'related_actions', 'url_logs', 'url', 'created_by_user'] | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc tasks logs`

Get logs for a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the task (or the last task if not set) | `None` |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |
| `--errors` | `bool` | Show structured error information instead of full logs | `False` |
| `--query` | `str` | Filter log lines matching this text (requires Loki) | `None` |

#### `ptc tasks start`

Start a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the task (or the last task if not set) | `None` |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--worker-class` | `str` | Worker class to launch the task on. Generally one of: ['medium', 'large', 'gpu'] | `None` |
| `--no-wait` | `bool` | Don't wait for the task to be ready after starting | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc tasks stop`

Stop a task on the cluster

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `str` | Name or ID of the task (or the last task if not set) | `None` |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc tasks delete`

Delete a task by name or ID

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_id` | `Union[str, UUID]` | Name or ID of the task |  |
| `project_id` | `UUID` | ID of task's project (or the last project if not set) | `None` |
| `cluster_id` | `UUID` | ID of the cluster to search for task name (or the last cluster if not set) | `None` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc publish`

Publish

#### `ptc publish code`

Upload and advertise a recipes package from your Python environment.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `name_or_path` | `str` | Path or name of importable module with the recipes |  |
| `--is-module`, `-m` | `bool` | Code to publish is an importable module | `False` |
| `--is-path`, `-p` | `bool` | Code to publish is a path | `False` |
| `--package-version` | `str` | Version identifier for the package | `None` |

#### `ptc publish data`

Transfer data to the cluster, and advertise it to Prodigy Teams. These steps can also be done separately. See `ptc files` to transfer data to the cluster without creating an Asset record for it, and `ptc assets create` to create an Asset without transfer.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | File or directory to publish |  |
| `dest` | `str` | Destination path to copy the data to | `None` |
| `--name` | `str` | Name of the asset | `None` |
| `--version` | `str` | Version of the asset | `None` |
| `--kind` | `str` | Kind of the asset. Generally one of: ['Input', 'Model', 'Patterns] |  |
| `--loader` | `str` | Loader to convert data for Prodigy | `None` |
| `--meta` | `str` | Asset meta, formatted as a JSON string | `'{}'` |
| `--exists-ok` | `bool` | Don't raise an error if it exists | `False` |

### `ptc login`

Log in to your Prodigy Teams account. You normally don't need to call this manually. It will automatically authenticate when needed.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--no-cluster` | `bool` | Don't use a cluster | `False` |
| `--no-browser` | `bool` | Don't open a browser, just print the login URL | `False` |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc info`

Print information about the CLI

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `field` | `str` | Field to select and show in output | `None` |

### `ptc get-auth-token`

Return an auth token for the current user

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `token_type` | `str` | The token type | `None` |

### `ptc version`

Show version info for the CLI and running services.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--json` | `bool` | Output the result as JSON | `False` |

### `ptc export`

Save the state of the current app JSON file. If an assets directory is provided, assets will be downloaded and referenced in the JSON accordingly.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `output` | `Path` | JSON output path for data |  |
| `assets_dir` | `Path` | Local directory to download assets to | `None` |
| `--include` | `str` | Comma-separated items to include | `['tasks', 'actions', 'assets', 'datasets', 'paths']` |

### `ptc import`

Populate Ellf with data for projects, tasks, actions, assets and paths.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `data` | `Path` | JSON file to import |  |
| `--strict`, `-S` | `bool` | Error if items already exist and don't skip or overwrite anything | `False` |

### `ptc infra`

#### `ptc infra deploy`

Deploy or upgrade the Ellf Helm chart. Creates the namespace, image pull secret, broker keypair secret, then runs helm upgrade --install with the provided values.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--values` | `Path` | Path to values.yaml for Helm deployment |  |
| `--chart` | `Path` | Path to local chart directory (default: OCI chart from registry) | `None` |
| `--latest` | `bool` | Fetch and use the latest image tags before deploying | `False` |
| `--namespace` | `str` | Kubernetes namespace | `'prodigy-teams'` |
| `--wait` | `bool` | Wait for pods to be ready after deploying | `False` |

#### `ptc infra init-values`

Generate a values.yaml for Helm deployment from credentials and provider defaults.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--creds` | `Path` | Path to cluster-creds.json from 'infra register' |  |
| `--cloud-provider` | `str` | Cloud provider: gcp, k3s, aws |  |
| `--domain` | `str` | Public FQDN of the cluster |  |
| `--out` | `Path` | Output path for generated values.yaml | `'values.yaml'` |
| `--acme-email` | `str` | Email for Let's Encrypt certificates | `None` |

#### `ptc infra provision`

Provision NFS wheelhouse on a cluster (runs provision hook).

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | Path to cluster definition files | `'.'` |
| `config_path` | `Path` | Path to config yaml | `None` |
| `--config-key` | `str` | Top-level key for the cluster config. | `None` |

#### `ptc infra register`

Register a new cluster with PAM and write credentials to cluster-creds.json.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--name` | `str` | Human-readable name for the cluster |  |
| `--domain` | `str` | Public FQDN of the cluster (e.g. cluster.example.com) |  |
| `--cloud-provider` | `str` | Cloud provider: gcp, k3s, aws |  |
| `--json` | `bool` | Output the result as JSON | `False` |

#### `ptc infra setup`

Install cluster infrastructure prerequisites (Traefik, cert-manager). These operations are idempotent and safe to re-run.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--traefik` | `bool` | Install Traefik ingress controller | `False` |
| `--cert-manager` | `bool` | Install cert-manager with Let's Encrypt | `False` |
| `--acme-email` | `str` | Email for ACME/Let's Encrypt certificate registration | `None` |
| `--public-ip` | `str` | Static IP for the Traefik load balancer | `None` |

#### `ptc infra start`

Start a cluster on infrastructure configured under your own cloud account.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | Path to cluster definition files | `'.'` |
| `config_path` | `Path` | Path to config yaml | `None` |
| `--config-key` | `str` | Top-level key for the cluster config. | `None` |
| `--offline` | `Path` | Path to a credentials JSON file. Deploys without connecting to PAM. | `None` |

#### `ptc infra get-terraform`

Download terraform files for cluster infrastructure.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `--dest` | `Path` | Directory to save terraform files to | `'.'` |
| `--cloud-provider` | `str` | Cloud provider: gcp, k3s, aws | `'gcp'` |

#### `ptc infra terraform`

Apply terraform to create or update cluster infrastructure.

| Argument | Type | Description | Default |
| --- | --- | --- | --- |
| `src` | `Path` | Path to cluster definition files | `'.'` |
| `config_path` | `Path` | Path to config yaml | `None` |
| `--config-key` | `str` | Top-level key for the cluster config. | `None` |
| `--tf-init` | `bool` | Force run 'terraform init' | `False` |
| `--tf-apply` | `bool` | Apply the terraform changes | `False` |
| `--tf-auto-accept` | `bool` | Accept the terraform changes without interaction | `False` |