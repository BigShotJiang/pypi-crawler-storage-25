"""Tests for prodigy_teams.commands.files.cp — helper functions."""

from __future__ import annotations

from prodigy_teams.commands.files.cp import _infer_remote_source_base


class TestInferRemoteSourceBase:
    def test_absolute_path_returned_as_is(self):
        result = _infer_remote_source_base(
            "/absolute/path",
            ["/absolute/path/file1", "/absolute/path/file2"],
        )
        assert result == "/absolute/path"

    def test_builtin_alias(self):
        result = _infer_remote_source_base(
            "{__data__}/agent-workflow-tests/model",
            [
                "/mnt/nfs/data/agent-workflow-tests/model/model-best/config.cfg",
                "/mnt/nfs/data/agent-workflow-tests/model/model-best/meta.json",
            ],
        )
        assert result == "/mnt/nfs/data/agent-workflow-tests/model"

    def test_nfs_alias(self):
        result = _infer_remote_source_base(
            "{__nfs__}/data/sub",
            ["/mnt/nfs/data/sub/file1.txt", "/mnt/nfs/data/sub/file2.txt"],
        )
        assert result == "/mnt/nfs/data/sub"

    def test_empty_paths(self):
        result = _infer_remote_source_base("{__data__}/sub", [])
        assert result == "{__data__}/sub"

    def test_alias_no_suffix(self):
        result = _infer_remote_source_base(
            "{__data__}",
            ["/mnt/nfs/data/file.txt"],
        )
        # With no suffix after the alias, commonpath is the result
        assert result == "/mnt/nfs/data/file.txt"

    def test_alias_with_trailing_slash(self):
        result = _infer_remote_source_base(
            "{__data__}/sub/",
            ["/mnt/nfs/data/sub/file1.txt"],
        )
        assert result == "/mnt/nfs/data/sub"
