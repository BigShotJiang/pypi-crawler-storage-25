"""Tests for prodigy_teams.ty — BrokerStatusCheck enum."""

from __future__ import annotations

from prodigy_teams.ty import BrokerStatusCheck


class TestBrokerStatusCheck:
    def test_values(self):
        assert BrokerStatusCheck.CREATING == "creating"
        assert BrokerStatusCheck.RUNNING == "running"
        assert BrokerStatusCheck.NOT_FOUND == "not_found"
        assert BrokerStatusCheck.INVALID_ADDRESS == "invalid_address"
        assert BrokerStatusCheck.REQUEST_ERROR == "request_error"
        assert BrokerStatusCheck.RESPONSE_ERROR == "response_error"
        assert BrokerStatusCheck.ISSUES == "issues"

    def test_str(self):
        assert str(BrokerStatusCheck.RUNNING) == "running"
        assert str(BrokerStatusCheck.CREATING) == "creating"

    def test_from_value(self):
        assert BrokerStatusCheck("running") == BrokerStatusCheck.RUNNING
