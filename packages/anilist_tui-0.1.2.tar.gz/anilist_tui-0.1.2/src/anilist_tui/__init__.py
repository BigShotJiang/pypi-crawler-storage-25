"""AniList TUI package."""
