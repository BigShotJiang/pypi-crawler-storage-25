from dsn_tools import DSNParser
from dsn_tools.dsn_types import DSNMessage


def test_answer():
    parser = DSNParser("src/dsn_tools/dsn.lark")
    message = parser.parse_file("tests/test_example")

    assert type(message) is DSNMessage

    adhesions = message.declarations[0].entreprise.etablissement.adhesion_prevoyance
    assert type(adhesions) is list

    assert len(adhesions) == 2
