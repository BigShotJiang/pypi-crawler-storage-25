"""
Générateur de parser DSN utilisant Lark.

Génère le module Python de parsing avec grammaire Lark.
"""

import dsn_utils

sanitize_class_name = dsn_utils.sanitize_class_name
sanitize_field_name = dsn_utils.sanitize_field_name


def prepare_parser_context(rubriques_data, blocks_data):
    """Prépare le contexte pour le template du parser."""
    # Génère le mapping complet des rubriques pour tous les blocs
    rubrique_mapping = {}
    for block_id, rubriques in rubriques_data.items():
        mapping = {}
        for rub in rubriques:
            field_name = sanitize_field_name(rub["name"])
            mapping[rub["id"]] = field_name
        if mapping:
            rubrique_mapping[block_id] = mapping

    # Génère la hiérarchie des blocs (enfant -> parent)
    block_hierarchy = {}
    for block_id, block_info in blocks_data.items():
        parent_id = block_info.get("parent_id")
        if parent_id:
            block_hierarchy[block_id] = parent_id

    return {
        "rubrique_mapping": rubrique_mapping,
        "block_hierarchy": block_hierarchy,
    }
