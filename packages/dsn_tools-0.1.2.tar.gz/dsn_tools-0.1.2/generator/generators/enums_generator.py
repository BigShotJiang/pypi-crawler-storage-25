"""
Enum generator for DSN types.

Generates Python Enum classes from Excel specification data.
"""

import re
import unicodedata


def to_enum_class_name(type_id: str) -> str:
    """
    Convert a type ID to a valid Python class name.

    Examples:
        "N4DS_Essai" -> "N4DS_Essai"
        "DSN_IndividuAgircArrco.StatutRetraiteComplementaire" -> "DSN_IndividuAgircArrco_StatutRetraiteComplementaire"
        "Nombre_1_6_regex_0.00" -> "Nombre_1_6_regex_0_00"
    """
    # Replace dots and other invalid characters with underscores
    sanitized = re.sub(r"[^a-zA-Z0-9_]", "_", type_id)

    # Ensure it starts with a letter
    if sanitized and not sanitized[0].isalpha():
        sanitized = "Enum_" + sanitized

    # Remove consecutive underscores
    sanitized = re.sub(r"_+", "_", sanitized)

    # Remove trailing underscore
    sanitized = sanitized.rstrip("_")

    return sanitized if sanitized else "UnknownEnum"


def to_enum_member_name(description: str) -> str:
    """
    Convert a description to a valid Python enum member name in UPPER_SNAKE_CASE.

    Examples:
        "envoi fichier test" -> "ENVOI_FICHIER_TEST"
        "Barème mensuel métropole" -> "BAREME_MENSUEL_METROPOLE"
        "Indu relatif à un exercice antérieur" -> "INDU_RELATIF_A_UN_EXERCICE_ANTERIEUR"
    """
    # Normalize unicode (remove accents)
    normalized = unicodedata.normalize("NFKD", description)
    ascii_text = "".join(c for c in normalized if not unicodedata.combining(c))

    # Replace special characters with spaces
    # Keep alphanumeric and spaces only
    cleaned = re.sub(r"[^a-zA-Z0-9\s]", " ", ascii_text)

    # Split into words and convert to uppercase
    words = cleaned.split()
    words = [w.upper() for w in words if w]

    # Join with underscores
    name = "_".join(words)

    # Ensure it starts with a letter (Python requirement)
    if name and not name[0].isalpha():
        name = "CODE_" + name

    return name if name else "UNKNOWN"


def parse_enum_values(values_str: str) -> list[dict]:
    """
    Parse the Values column string into a list of enum members.

    Format: "01=envoi fichier test;02=envoi fichier réel"

    Returns:
        List of dicts with keys: name, value, description
    """
    if not values_str:
        return []

    members = []
    seen_names = set()

    # Split by semicolon
    pairs = values_str.split(";")

    for pair in pairs:
        pair = pair.strip()
        if not pair:
            continue

        # Split by first equals sign
        if "=" not in pair:
            continue

        code, description = pair.split("=", 1)
        code = code.strip()
        description = description.strip()

        if not code or not description:
            continue

        # Generate member name from description
        name = to_enum_member_name(description)

        # Handle duplicates by adding suffix
        original_name = name
        counter = 1
        while name in seen_names:
            name = f"{original_name}_{counter}"
            counter += 1

        seen_names.add(name)

        members.append({"name": name, "value": code, "description": description})

    return members


def prepare_enums_context(types_data: dict) -> dict:
    """
    Prepare the context dictionary for the enums template.

    Args:
        types_data: Dictionary from read_excel_data containing type definitions

    Returns:
        Dictionary with 'enums' key containing list of enum definitions
    """
    enums = []

    for type_id, type_info in types_data.items():
        nature = type_info.get("nature", "").lower()

        # Check if this is an enumeration type
        if "enum" not in nature:
            continue

        # Get the values string
        values_str = type_info.get("values", "")  # Column 8 (Values) contains enum values
        if not values_str or values_str == "-":
            continue

        # Parse the values
        members = parse_enum_values(str(values_str))

        if not members:
            continue

        # Generate docstring - just the description, not the values
        # (values are already shown as comments on each member)
        doc_lines = [type_info.get("description", type_id)]

        enums.append(
            {
                "class_name": to_enum_class_name(type_id),
                "original_name": type_id,
                "docstring": "\n".join(doc_lines),
                "members": members,
            }
        )

    return {"enums": enums}


def get_enum_types(types_data: dict) -> set:
    """
    Get a set of all type IDs that are enumerations.

    Returns:
        Set of type IDs that are enum types
    """
    enum_types = set()

    for type_id, type_info in types_data.items():
        nature = type_info.get("nature", "").lower()
        if "enum" in nature:
            values_str = type_info.get("values", "")
            if values_str and values_str != "-":
                enum_types.add(type_id)

    return enum_types
