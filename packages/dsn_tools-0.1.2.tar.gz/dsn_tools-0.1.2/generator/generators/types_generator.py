"""
Types generator for DSN dataclasses.

Generates Python dataclass definitions from Excel specification data.
"""

import dsn_utils

from generators.enums_generator import get_enum_types, to_enum_class_name

sanitize_class_name = dsn_utils.sanitize_class_name
sanitize_field_name = dsn_utils.sanitize_field_name


def build_block_hierarchy(blocks_data: dict) -> dict[str, list[dict]]:
    """
    Construit la hiérarchie des blocs à partir de blocks_data.

    Returns:
        Dict mapping parent_block_id -> list of child block info
        Each child info contains: block_id, lower_bound, upper_bound, name
    """
    hierarchy: dict = {}

    for block_id, block_info in blocks_data.items():
        parent_id = block_info.get("parent_id")
        if parent_id:
            if parent_id not in hierarchy:
                hierarchy[parent_id] = []
            # Utilise le nom du bloc pour le nom du champ au lieu de l'ID du bloc
            block_name = block_info.get("name", block_id)
            field_name = sanitize_field_name(block_name)
            hierarchy[parent_id].append(
                {
                    "block_id": block_id,
                    "class_name": sanitize_class_name(block_id),
                    "field_name": field_name,
                    "lower_bound": block_info.get("lower_bound", "1"),
                    "upper_bound": block_info.get("upper_bound", "1"),
                    "name": block_name,
                }
            )

    return hierarchy


def prepare_types_context(
    types_data: dict, blocks_data: dict, rubriques_data: dict
) -> dict[str, any]:
    """Prépare le contexte pour le template Jinja2."""
    # Get set of enum types for quick lookup
    enum_types = get_enum_types(types_data)

    # Construit la hiérarchie des blocs
    hierarchy = build_block_hierarchy(blocks_data)

    # Génération des classes pour chaque bloc dans blocks_data
    block_classes = []

    def prepare_block_class(block_id: str, block_name: str = ""):
        """Prepare a block class definition for the template."""
        class_name = sanitize_class_name(block_id)
        rubriques = rubriques_data.get(block_id, [])

        # Champs
        fields = []
        validation_rules = []
        for rub in rubriques:
            field_name = sanitize_field_name(rub["name"])
            datatype_id = rub["datatype_id"]
            type_info = types_data.get(datatype_id, {})

            # Détermine le type Python
            # Check if this datatype is an enum
            if datatype_id in enum_types:
                python_type = to_enum_class_name(datatype_id)  # Use sanitized enum class name
            else:
                python_type = "str"  # Default to string

            # Détermine si le champ est requis selon la description
            # Dans la spec DSN, les champs marqués "obligatoire" dans la description sont requis
            description = rub.get("description", "")
            is_required = "obligatoire" in description.lower()

            fields.append(
                {
                    "name": field_name,
                    "type": python_type,
                    "rubrique_id": rub["id"],
                    "rubrique_name": rub["name"],
                    "datatype_id": datatype_id,
                    "is_required": is_required,
                }
            )

            # Ajoute la règle de validation si on a une regex
            regexp = type_info.get("regexp", "")
            if regexp and regexp != "-":
                # Convertit la regex Python en pattern compatible
                import re as re_module

                try:
                    re_module.compile(regexp)
                    desc = type_info.get("description", datatype_id)
                    validation_rules.append(
                        {
                            "field_name": field_name,
                            "pattern": regexp,
                            "description": desc,
                        }
                    )
                except re_module.error:
                    pass

        # Trie les champs: les champs requis doivent venir avant les champs optionnels
        # C'est une requirement des dataclasses Python
        fields.sort(key=lambda f: (not f["is_required"], f["name"]))

        # Blocs enfants
        children = []
        for child in hierarchy.get(block_id, []):
            is_list = child["upper_bound"] == "*" or (
                child["upper_bound"].isdigit() and int(child["upper_bound"]) > 1
            )
            children.append(
                {
                    "field_name": child["field_name"],
                    "class_name": child["class_name"],
                    "is_list": is_list,
                    "name": child["name"],
                    "block_id": child["block_id"],
                    "lower_bound": child["lower_bound"],
                    "upper_bound": child["upper_bound"],
                }
            )

        return {
            "class_name": class_name,
            "block_id": block_id,
            "block_name": block_name if block_name else block_id,
            "fields": fields,
            "validation_rules": validation_rules,
            "children": children,
        }

    for block_id, block_info in blocks_data.items():
        block_classes.append(prepare_block_class(block_id, block_info["name"]))

    # Génération des blocs spéciaux (même s'ils ne sont pas dans blocks_data)
    special_blocks = ["S10.G00.00", "S20.G00.05", "S90.G00.90"]
    for block_id in special_blocks:
        if block_id not in blocks_data:
            block_classes.append(prepare_block_class(block_id))

    return {
        "block_classes": block_classes,
    }
