"""
Générateur CLI pour le parser DSN.

Génère les scripts d'interface en ligne de commande.
"""


def prepare_cli_context():
    """Prépare le contexte pour le template CLI."""
    return {}


def prepare_test_example_context(rubriques_data):
    """Prépare le contexte pour le template de l'exemple de test."""
    lines = []

    # Header - format: S10.G00.00.001,VALEUR_001
    if "S10.G00.00" in rubriques_data:
        for rub in rubriques_data["S10.G00.00"]:
            # Valeur d'exemple basée sur le type
            if "siren" in rub["name"].lower():
                value = "123456789"
            elif "nic" in rub["name"].lower():
                value = "00001"
            elif "version" in rub["name"].lower():
                value = "P26V01"
            elif "type" in rub["name"].lower():
                value = "01"
            else:
                value = f"VALEUR_{rub['id']}"
            lines.append(
                {
                    "block_id": "S10.G00.00",
                    "rubrique_id": rub["id"],
                    "value": value,
                }
            )

    # Déclaration minimale
    if "S20.G00.05" in rubriques_data:
        for rub in rubriques_data["S20.G00.05"][:5]:  # Juste les 5 premières
            lines.append(
                {
                    "block_id": "S20.G00.05",
                    "rubrique_id": rub["id"],
                    "value": f"VALEUR_{rub['id']}",
                }
            )

    # Footer
    if "S90.G00.90" in rubriques_data:
        for rub in rubriques_data["S90.G00.90"]:
            lines.append(
                {
                    "block_id": "S90.G00.90",
                    "rubrique_id": rub["id"],
                    "value": "1",
                }
            )

    return {"lines": lines}


def prepare_pyproject_context():
    """
    Prepare the context dictionary for the pyproject template.

    Returns:
        Dictionary containing all data needed by the Jinja2 template
    """
    return {}


def prepare_init_context(blocks_data):
    """Prépare le contexte pour le template __init__.py."""
    import dsn_utils

    block_classes = []
    for block_id in blocks_data.keys():
        class_name = dsn_utils.sanitize_class_name(block_id)
        block_classes.append(
            {
                "class_name": class_name,
                "block_id": block_id,
            }
        )

    # Ajoute les blocs spéciaux
    special_blocks = ["S10_G00_00", "S20_G00_05", "S90_G00_90"]
    for class_name in special_blocks:
        if not any(bc["class_name"] == class_name for bc in block_classes):
            block_id = class_name.replace("_", ".")
            block_classes.append(
                {
                    "class_name": class_name,
                    "block_id": block_id,
                }
            )

    return {
        "block_classes": sorted(block_classes, key=lambda x: x["class_name"]),
    }
