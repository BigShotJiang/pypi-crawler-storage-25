"""
Lecteur de données Excel pour les fichiers de spécification DSN.

Lit et parse le fichier de spécification DSN Excel pour extraire
les types de données, la hiérarchie des blocs et les définitions des rubriques.
"""

import sys


def read_excel_data(excel_path: str) -> tuple[dict, dict, dict]:
    """Lit le fichier Excel et extrait les données des 3 feuilles importantes."""
    try:
        import openpyxl
    except ImportError:
        print("Erreur: openpyxl non installé. Exécutez: uv pip install openpyxl")
        sys.exit(1)

    wb = openpyxl.load_workbook(excel_path, data_only=True)

    # Feuille 3: Types de données (Id, Name, Description, Nature, Regexp, Lg Min, Lg Max, Values)
    types_data: dict = {}
    ws_types = wb.worksheets[2]  # Feuille 3
    for row in ws_types.iter_rows(min_row=2, values_only=True):
        if row[0]:
            type_id = str(row[0]).strip()
            types_data[type_id] = {
                "name": str(row[1]) if row[1] else type_id,
                "description": str(row[2]) if row[2] else "",
                "nature": str(row[3]) if row[3] else "",
                "regexp": str(row[4]) if row[4] else "",
                "min_len": row[5] if row[5] else None,
                "max_len": row[6] if row[6] else None,
                "values": str(row[7]) if row[7] else "",
            }

    # Feuille 4: Hiérarchie des blocs (Id, Name, Description, ParentId, lowerBound, upperBound)
    blocks_data: dict = {}
    ws_blocks = wb.worksheets[3]  # Feuille 4
    for row in ws_blocks.iter_rows(min_row=2, values_only=True):
        if row[0]:
            block_id = str(row[0]).strip()
            blocks_data[block_id] = {
                "name": str(row[1]) if row[1] else block_id,
                "description": str(row[2]) if row[2] else "",
                "parent_id": str(row[3]).strip() if row[3] else None,
                "lower_bound": str(row[4]) if row[4] is not None else "1",
                "upper_bound": str(row[5]) if row[5] is not None else "1",
            }

    # Feuille 5: Rubriques (Block Id, Id, Name, Description, DataType Id, Comment)
    rubriques_data: dict = {}
    ws_rubriques = wb.worksheets[4]  # Feuille 5
    for row in ws_rubriques.iter_rows(min_row=2, values_only=True):
        if row[0] and row[1]:
            block_id = str(row[0]).strip()
            rubrique_id = str(row[1]).strip()

            if block_id not in rubriques_data:
                rubriques_data[block_id] = []

            rubriques_data[block_id].append(
                {
                    "id": rubrique_id,
                    "name": str(row[2]) if row[2] else f"rubrique_{rubrique_id}",
                    "description": str(row[3]) if row[3] else "",
                    "datatype_id": str(row[4]).strip() if row[4] else "Type_Alphanumeric_1_100",
                    "comment": str(row[5]) if row[5] else "",
                }
            )

    return types_data, blocks_data, rubriques_data
