"""
Générateur de parser DSN (Données Sociales Nominatives) à partir du fichier Excel de spécifications.

Usage:
    ./generate_dsn_parser.py dsn-datatypes-CT2026.xlsx --output-dir ./generated

Options:
    --output-dir      Répertoire de sortie pour les fichiers générés
    --generate-test   Génère un fichier test_example.dsn
    --with-validation Active la validation stricte dans les classes
"""

import argparse
import shutil
import sys
from pathlib import Path

from generators.cli_generator import prepare_test_example_context
from generators.enums_generator import prepare_enums_context

# Import from modular generators
from generators.excel_reader import read_excel_data
from generators.grammar import generate_lark_grammar, generate_pest_grammar
from generators.parser_generator import prepare_parser_context
from generators.types_generator import prepare_types_context
from jinja2 import Environment, FileSystemLoader


def get_template_env() -> Environment:
    """Create and return a Jinja2 template environment."""
    template_dir = Path(__file__).parent / "templates"
    return Environment(
        loader=FileSystemLoader(template_dir),
        trim_blocks=True,
        lstrip_blocks=True,
    )


def main():
    parser = argparse.ArgumentParser(
        description="Génère un parser DSN depuis le fichier Excel de spécifications"
    )
    parser.add_argument("excel_file", help="Chemin vers dsn-datatypes-CT2026.xlsx")
    parser.add_argument(
        "--output-dir",
        "-o",
        default="../src/dsn_tools",
        help="Répertoire de sortie (défaut: ../src/dsn_tools)",
    )
    parser.add_argument(
        "--generate-test",
        action="store_true",
        help="Génère un fichier test_example.dsn",
    )
    parser.add_argument(
        "--verbose",
        "-v",
        action="store_true",
        help="Affiche les détails de la génération",
    )

    args = parser.parse_args()

    # Vérifie le fichier Excel
    excel_path = Path(args.excel_file)
    if not excel_path.exists():
        print(f"Erreur: Fichier non trouvé: {excel_path}")
        sys.exit(1)

    # Crée le répertoire de sortie
    output_dir = Path(args.output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)

    print(f"Lecture de {excel_path}...")
    types_data, blocks_data, rubriques_data = read_excel_data(str(excel_path))

    print(f"  Types trouvés: {len(types_data)}")
    print(f"  Blocs trouvés: {len(blocks_data)}")
    print(f"  Rubriques trouvées: {sum(len(r) for r in rubriques_data.values())}")

    # Initialize Jinja2 template environment
    env = get_template_env()

    # Génère les fichiers
    print(f"\nGénération des fichiers dans {output_dir}...")

    # dsn.pest (pour Rust)
    pest_content = generate_pest_grammar(types_data, blocks_data, rubriques_data)
    (output_dir / "dsn.pest").write_text(pest_content, encoding="utf-8")
    print("  ✓ dsn.pest (pour Rust)")

    # dsn.lark (pour Python)
    lark_content = generate_lark_grammar(types_data, blocks_data, rubriques_data)
    (output_dir / "dsn.lark").write_text(lark_content, encoding="utf-8")
    print("  ✓ dsn.lark (pour Python/Lark)")

    # enums.py (using Jinja2 template)
    enums_context = prepare_enums_context(types_data)
    enums_template = env.get_template("enums.py.j2")
    enums_content = enums_template.render(**enums_context)
    (output_dir / "enums.py").write_text(enums_content, encoding="utf-8")
    print("  ✓ enums.py")

    # dsn_types.py (using Jinja2 template)
    types_context = prepare_types_context(types_data, blocks_data, rubriques_data)
    types_template = env.get_template("dsn_types.py.j2")
    types_content = types_template.render(**types_context)
    (output_dir / "dsn_types.py").write_text(types_content, encoding="utf-8")
    print("  ✓ dsn_types.py")

    # dsn_parser.py (using Jinja2 template)
    parser_context = prepare_parser_context(rubriques_data, blocks_data)
    parser_template = env.get_template("dsn_parser.py.j2")
    parser_content = parser_template.render(**parser_context)
    (output_dir / "dsn_parser.py").write_text(parser_content, encoding="utf-8")
    print("  ✓ dsn_parser.py")

    # test_example.dsn (using Jinja2 template)
    if args.generate_test:
        test_context = prepare_test_example_context(rubriques_data)
        test_template = env.get_template("test_example.dsn.j2")
        test_content = test_template.render(**test_context)
        (output_dir / "test_example.dsn").write_text(test_content, encoding="utf-8")
        print("  ✓ test_example.dsn")

    # Copy dsn_utils.py to output directory (A4)
    utils_src = Path(__file__).parent / "dsn_utils.py"
    utils_dst = output_dir / "dsn_utils.py"
    shutil.copy2(utils_src, utils_dst)
    print("  ✓ dsn_utils.py")

    print("\n✨ Génération terminée!")

    print("\n📋 Résumé:")
    print("  • Grammaire PEST (Rust): dsn.pest")
    print("  • Grammaire Lark (Python): dsn.lark")
    print(f"  • Classes Python: {len(blocks_data)} blocs DSN")
    print("  • Parser: compatible Python avec Lark")

    print("\n🚀 Utilisation rapide:")
    print("  just test-all")
    print("  # ou manuellement:")
    print("  uv run python parse_dsn.py tests/test_example.dsn")
    print("  uv run python parse_dsn.py tests/test_example.dsn --json")

    if args.verbose:
        print("\nDétails:")
        print(f"  - Blocs générés: {', '.join(blocks_data.keys())}")


if __name__ == "__main__":
    main()
