"""
Utility functions for DSN parsing.

This module provides shared utility functions used by both the code generator
and the generated parser to avoid code duplication.

Functions:
    sanitize_class_name: Convert block ID to Python class name
    sanitize_field_name: Convert field name to valid Python identifier
    block_id_to_field_name: Convert block ID to field name
"""

import re
import unicodedata


def sanitize_class_name(block_id: str) -> str:
    """
    Convertit un ID de bloc en nom de classe Python valide.

    Args:
        block_id: Block identifier (e.g., "S10.G00.00", "S21.G00.06")

    Returns:
        Valid Python class name (e.g., "S10_G00_00", "S21_G00_06")

    Examples:
        >>> sanitize_class_name("S10.G00.00")
        'S10_G00_00'
        >>> sanitize_class_name("S21.G00.06")
        'S21_G00_06'
    """
    return block_id.replace(".", "_").replace("-", "_")


def block_id_to_field_name(block_id: str) -> str:
    """
    Convertit un ID de bloc en nom de champ Python.
    Utilisé pour les champs qui référencent des blocs enfants.

    Args:
        block_id: Block identifier (e.g., "S10.G00.01", "S21.G00.06")

    Returns:
        Field name (e.g., "s10g0001", "s21g0006")

    Examples:
        >>> block_id_to_field_name("S10.G00.01")
        's10g0001'
        >>> block_id_to_field_name("S21.G00.06")
        's21g0006'
    """
    return block_id.replace(".", "").lower()


def sanitize_field_name(name: str) -> str:
    """
    Convertit un nom de rubrique en nom de champ Python valide.

    Args:
        name: Field name from Excel (e.g., "Nom du logiciel utilisé", "SIREN")

    Returns:
        Valid Python field name (e.g., "nom_du_logiciel_utilisé", "siren")

    Examples:
        >>> sanitize_field_name("Nom du logiciel utilisé")
        'nom_du_logiciel_utilisé'
        >>> sanitize_field_name("SIREN")
        'siren'
        >>> sanitize_field_name("Date d'effet")
        'date_d_effet'

    The sanitization process:
    1. Convert to lowercase
    2. Replace spaces, hyphens, slashes, dots with underscores
    3. Remove parentheses and quotes
    4. Remove accents (é→e, è→e, etc.)
    5. Remove non-alphanumeric characters except underscores
    6. Collapse multiple underscores
    7. Add 'rubrique_' prefix if starts with digit or is empty
    """
    # Remplace les caractères spéciaux
    field = name.lower()
    field = field.replace(" ", "_")
    field = field.replace("'", "")
    field = field.replace("/", "_")
    field = field.replace("-", "_")
    field = field.replace(".", "_")
    field = field.replace("(", "")
    field = field.replace(")", "")
    field = field.replace("–", "_")
    field = field.replace("'", "_")
    field = field.replace("'", "_")

    # Supprime les accents
    field = "".join(
        c for c in unicodedata.normalize("NFD", field) if unicodedata.category(c) != "Mn"
    )

    # Supprime les caractères non alphanumériques
    field = re.sub(r"[^a-z0-9_]", "_", field)

    # Supprime les underscores multiples
    field = re.sub(r"_+", "_", field)

    # Supprime les underscores de début et fin
    field = field.strip("_")

    # Si le nom est vide ou commence par un chiffre
    if not field or field[0].isdigit():
        field = "rubrique_" + field

    return field
