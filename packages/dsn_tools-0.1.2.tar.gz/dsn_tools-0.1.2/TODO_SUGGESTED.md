# TODOs suggerees - Evaluation du code disan

---

## Architecture et maintenabilite

### A4. `dsn_utils.py` est copie manuellement dans `generated/`
**Fichier:** `dsn_utils.py` et `generated/dsn_utils.py`
**Probleme:** Le fichier utilitaire est duplique. Si on modifie l'un, il faut
penser a regenerer l'autre. Le generateur ne copie pas automatiquement ce fichier.
**Suggestion:** Ajouter une etape dans `main()` qui copie automatiquement
`dsn_utils.py` dans le repertoire de sortie, ou l'inclure dans le code genere.

---

## Tests

### T1. Absence totale de tests automatises
**Probleme:** Il n'y a aucun test unitaire ni test d'integration. Le seul moyen
de verifier que le code fonctionne est de lancer manuellement le parser sur un
fichier exemple.
**Suggestion:**
  - Tests unitaires pour `dsn_utils.py` (sanitize_class_name, sanitize_field_name)
  - Tests unitaires pour `read_excel_data()` (avec un fichier Excel minimal de test)
  - Tests d'integration: generer le parser, parser `test_example`, verifier
    que les valeurs extraites sont correctes
  - Tests de regression avec le fichier JSON existant dans `tristram_junk/dsn.json`
  - Ajouter une CI (GitHub Actions) qui execute les tests

### T2. Le fichier `test_example` n'a pas d'extension
**Fichier:** `test_example`
**Probleme:** Contrairement au fichier genere `test_example.dsn`, le fichier
test a la racine n'a pas d'extension `.dsn`, ce qui est inconsistant.
**Suggestion:** Renommer en `test_example.dsn`.

### T3. Pas de validation du code genere
**Probleme:** Apres generation, on ne verifie pas que le code genere est
syntaxiquement correct (compile sans erreur).
**Suggestion:** Ajouter une etape post-generation qui fait `py_compile.compile()`
sur chaque fichier `.py` genere, ou au minimum `import` le module.

---

## Robustesse et gestion d'erreurs

### R1. Pas de gestion d'encodage robuste pour les fichiers DSN
**Fichier:** `generate_dsn_parser.py:712` (genere dans `dsn_parser.py`)
**Probleme:** `Path(path).read_text(encoding="utf-8")` echouera si le fichier
DSN est encode en ISO-8859-1 ou Windows-1252 (courant dans le monde de la paie
francaise).
**Suggestion:** Detecter l'encodage automatiquement (avec `chardet` ou essai
UTF-8 puis fallback Latin-1), ou ajouter un parametre `encoding` a `parse_file()`.

### R2. Erreurs silencieuses lors de la compilation des regex
**Fichier:** `generate_dsn_parser.py:360-361` (genere dans `dsn_types.py:27-28`)
**Probleme:** Les erreurs de compilation de regex sont silencieusement ignorees
(`except re.error: pass`). On ne sait jamais si une regle de validation est
invalide.
**Suggestion:** Logger un avertissement quand une regex ne compile pas.

### R3. `_parse_line` ne gere pas les valeurs vides
**Fichier:** `generate_dsn_parser.py:956-968` (genere dans `dsn_parser.py`)
**Probleme:** Si une ligne DSN a une valeur vide (`S10.G00.00.001,`), la grammaire
Lark peut ne pas la capturer correctement car `UNQUOTED_STRING` requiert au
moins un caractere (`/[^\r\n,]+/`). Le `+` devrait etre `*`.
**Suggestion:** Modifier la grammaire pour autoriser les valeurs vides avec
`UNQUOTED_STRING: /[^\r\n,]*/` ou ajouter une regle explicite pour les
valeurs vides.

### R4. Pas de gestion des lignes vides ou commentaires
**Fichier:** Grammaire Lark (`dsn.lark`)
**Probleme:** Les fichiers DSN reels peuvent contenir des lignes vides ou des
lignes de commentaire. La grammaire actuelle rejettera ces fichiers.
**Suggestion:** Ajouter une regle pour ignorer les lignes vides et optionnellement
les commentaires.

### R5. `DSNParseError.line_num` n'est pas le vrai numero de ligne du fichier
**Fichier:** `generate_dsn_parser.py:722-726` (genere dans `dsn_parser.py`)
**Probleme:** `line_num` est incremente pour chaque noeud `dsn_line` dans l'arbre
Lark, mais ne correspond pas forcement au numero de ligne reel du fichier
(si des lignes vides existent, par exemple).
**Suggestion:** Utiliser les informations de position de Lark (`tree.meta.line`)
pour reporter le vrai numero de ligne.

---

## Performance

### P1. Le parser Lark est recree a chaque appel de `parse_dsn()`
**Fichier:** `generate_dsn_parser.py:1006-1008` (genere dans `dsn_parser.py`)
**Probleme:** La fonction utilitaire `parse_dsn()` cree un nouveau `DSNParser`
(qui lit et compile la grammaire) a chaque appel. C'est couteux si on parse
plusieurs fichiers.
**Suggestion:** Utiliser un singleton ou un cache pour le parser, ou documenter
clairement que `DSNParser` devrait etre reutilise.

### P2. L'introspection `getattr(dsn_types, class_name)` a chaque bloc
**Fichier:** `generate_dsn_parser.py:856-857` (genere dans `dsn_parser.py`)
**Probleme:** `_create_child_block` fait de l'introspection module a chaque
creation de bloc. Pour un fichier avec des milliers de blocs, c'est lent.
**Suggestion:** Pre-construire un dictionnaire `{block_id: class}` pour tous
les blocs au demarrage, pas seulement les 3 blocs principaux.

### P3. `_attach_child_to_parent` itere sur tous les champs a chaque appel
**Fichier:** `generate_dsn_parser.py:883-897` (genere dans `dsn_parser.py`)
**Probleme:** La methode itere sur `__dataclass_fields__` et fait du matching
de chaine sur `field_type_str` pour chaque attachement enfant-parent.
**Suggestion:** Pre-construire un mapping `{parent_class + child_class: field_name}`
au demarrage.

---

## Fonctionnalites manquantes

### F1. Pas de support pour les enums DSN
**Probleme:** De nombreuses rubriques DSN ont des valeurs enumerees (par exemple,
code sexe = "01"/"02", type envoi = "01"/"02"/...). Ces enums sont potentiellement
dans l'Excel mais ne sont pas extraits ni generes.
**Suggestion:** Extraire les enums de l'Excel et generer des `Enum` Python ou
au moins des constantes avec descriptions.

### F2. Pas de serialisation inverse (Python -> DSN)
**Probleme:** On peut parser un fichier DSN en objets Python, mais pas l'inverse.
**Suggestion:** Ajouter une methode `to_dsn()` sur `DSNMessage` et `DSNBlock`
pour regenerer un fichier DSN valide.

### F3. Pas de support pour le streaming / fichiers volumineux
**Probleme:** Tout le fichier est lu en memoire puis parse. Les fichiers DSN
de grandes entreprises peuvent etre volumineux (dizaines de Mo).
**Suggestion:** Implementer un parser ligne-par-ligne qui n'utilise pas l'arbre
Lark complet, mais parse chaque ligne individuellement.

### F4. Pas de mecanisme de diff entre deux fichiers DSN
**Probleme:** Un cas d'usage courant est de comparer deux DSN (par ex.
declaration normale vs annule-et-remplace).
**Suggestion:** Ajouter une fonction `diff_dsn()` qui compare deux `DSNMessage`.

### F5. Les types Python sont tous `str`
**Fichier:** `generate_dsn_parser.py:451`
**Probleme:** `python_type = "str"` est hardcode. Les dates, montants, et
compteurs restent des chaines.
**Suggestion:** Mapper les types DSN vers des types Python natifs:
  - Types numeriques -> `int` ou `Decimal`
  - Types dates (`JJMMAAAA`) -> `datetime.date`
  - Types montants -> `Decimal`
  - Garder `str` pour les alphanumeriques

### F6. Pas de documentation des champs dans le code genere
**Probleme:** Les champs des dataclasses ont un commentaire inline mais pas de
docstring exploitable par les IDE. Le type `Optional[str]` ne donne aucune
information semantique.
**Suggestion:** Utiliser `Annotated[Optional[str], Field(description="...")]`
ou generer des docstrings de classe plus riches.

### F7. La validation recursive ne descend pas dans les blocs enfants
**Fichier:** `generate_dsn_parser.py:362-386` (genere dans `dsn_types.py:30-53`)
**Probleme:** `DSNBlock.validate()` ne valide que ses propres champs, pas ses
blocs enfants. Seul `DSNMessage.validate()` descend dans les declarations,
mais pas dans les blocs sous-jacents.
**Suggestion:** Modifier `DSNBlock.validate()` pour valider recursivement tous
les sous-blocs (listes et champs simples de type DSNBlock).

---

## Qualite du code

### Q1. Mixing francais et anglais dans le code
**Probleme:** Les commentaires, docstrings, et messages sont en francais dans
certains endroits et en anglais dans d'autres. Les noms de methodes sont en
anglais, les descriptions en francais.
**Suggestion:** Choisir une langue et s'y tenir. Pour un projet open-source,
l'anglais est preferable. Pour un projet interne francais, le francais est
acceptable, mais il faut etre consistant.

### Q2. Annotations de type incompletes dans le generateur
**Fichier:** `generate_dsn_parser.py`
**Probleme:** Les fonctions de generation retournent `str` mais les types des
parametres utilisent `Dict` sans parametres generiques (par ex. `Dict` au lieu
de `Dict[str, Any]`).
**Suggestion:** Utiliser des types plus precis, par exemple:
  - `types_data: Dict[str, Dict[str, Any]]`
  - `blocks_data: Dict[str, Dict[str, Any]]`
  - `rubriques_data: Dict[str, List[Dict[str, str]]]`

### Q3. Les fonctions de conversion regex ne sont jamais appelees
**Fichier:** `generate_dsn_parser.py:106-150` (`convert_regex_to_pest`)
et `generate_dsn_parser.py:183-228` (`convert_regex_to_lark`)
**Probleme:** Ces fonctions sont definies mais jamais utilisees. Les grammaires
generees n'utilisent pas les types de donnees individuels -- elles ont un
format generique `dsn_value`.
**Suggestion:** Supprimer le code mort, ou implementer la validation au niveau
de la grammaire si c'est prevu.

### Q4. `generate_block_class` est une closure avec effets de bord
**Fichier:** `generate_dsn_parser.py:428`
**Probleme:** `generate_block_class` est une fonction interne qui modifie la
liste `lines` de la fonction englobante. C'est un pattern fragile.
**Suggestion:** En faire une methode ou fonction standalone qui retourne les
lignes generees au lieu de modifier une liste externe.

---

## Securite et bonnes pratiques

### S1. Pas de nettoyage des donnees Excel avant generation de code
**Probleme:** Les valeurs lues de l'Excel sont utilisees pour generer du code
Python (noms de classes, regex). Une valeur malveillante dans l'Excel pourrait
injecter du code arbitraire dans les fichiers generes.
**Suggestion:** Valider et assainir toutes les valeurs provenant de l'Excel avant
de les inserer dans le code genere. Verifier que les noms de classes et champs
ne contiennent que des caracteres alphanumeriques et underscores.

### S2. Pas de `.python-version` ou contrainte precise de Python
**Probleme:** Le `pyproject.toml` dit `requires-python = ">=3.9"` mais il n'y a
pas de fichier `.python-version` pour les outils comme `uv`.
**Suggestion:** Ajouter un fichier `.python-version` a la racine.
