Python version is 3.12.

Type annotations must use the modern syntax: `foo: str | None`, not `foo: Optional[str]`.
Do not include `from __future__ import annotations` because the minimum python version does not require it.

Docstrings, comments, keys and block names are in French (not in English, not ids such as `S10.G00.00.001`).
