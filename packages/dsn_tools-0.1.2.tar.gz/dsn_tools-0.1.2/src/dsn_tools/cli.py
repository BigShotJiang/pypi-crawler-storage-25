"""CLI pour dsn-tools."""

import argparse
import json
import sys
from pathlib import Path

try:
    from dsn_tools.dsn_parser import parse_dsn
    import dsn_tools

    GRAMMAR_PATH = Path(dsn_tools.__file__).parent / "dsn.lark"
except ImportError as e:
    print(
        f"Erreur: Impossible d'importer dsn_tools: {e}",
        file=sys.stderr,
    )
    sys.exit(1)


def main() -> None:
    """Point d'entrée CLI."""
    parser = argparse.ArgumentParser(
        description="Parse un fichier DSN (Données Sociales Nominatives)",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Exemples:
  %(prog)s fichier.dsn                      # Parse simple
  %(prog)s fichier.dsn --validate           # Parse avec validation
  %(prog)s fichier.dsn --json               # Sortie en JSON
  %(prog)s fichier.dsn --verbose            # Affiche les détails
        """,
    )

    parser.add_argument("fichier", help="Chemin vers le fichier DSN à parser")

    parser.add_argument(
        "--grammar",
        "-g",
        default=None,
        help="Chemin vers la grammaire Lark (défaut: grammaire intégrée dans le package)",
    )

    parser.add_argument(
        "--validate",
        "-v",
        action="store_true",
        help="Valide les données après parsing (peut lever des erreurs)",
    )

    parser.add_argument("--json", "-j", action="store_true", help="Sortie au format JSON")

    parser.add_argument(
        "--strict",
        action="store_true",
        help="En mode validation, arrête sur la première erreur",
    )

    parser.add_argument(
        "--quiet",
        "-q",
        action="store_true",
        help="Mode silencieux (seulement les erreurs)",
    )

    args = parser.parse_args()

    # Vérifie que le fichier existe
    fichier_path = Path(args.fichier)
    if not fichier_path.exists():
        print(f"Erreur: Fichier non trouvé: {fichier_path}", file=sys.stderr)
        sys.exit(1)

    # Parse le fichier
    try:
        if not args.quiet:
            print(f"Parsing de {fichier_path}...")

        message = parse_dsn(
            fichier_path.read_text(encoding="utf-8"),
            grammar_path=args.grammar or str(GRAMMAR_PATH),
            validate=args.validate,
        )

        if args.validate and not args.quiet:
            print("✓ Validation réussie")

        # Affiche le résultat
        if args.json:
            # Sortie JSON
            output = {
                "header": message.header.to_dict(),
                "declarations": [d.to_dict() for d in message.declarations],
                "footer": message.footer.to_dict() if message.footer else None,
            }
            print(json.dumps(output, indent=2, ensure_ascii=False))
        else:
            # Sortie texte
            if not args.quiet:
                print("\n✓ Parsing réussi!")
                print("\nRésumé:")
                print(f"  Header: {type(message.header).__name__}")
                print(f"  Déclarations: {len(message.declarations)}")
                if message.footer:
                    print(f"  Footer: {type(message.footer).__name__}")

                # Affiche les infos du header de manière dynamique
                print("\nInformations header:")
                for field_name in sorted(dir(message.header)):
                    if field_name.startswith("_") or field_name == "block_id":
                        continue
                    value = getattr(message.header, field_name, None)
                    if value is not None and not callable(value):
                        print(f"  {field_name}: {value}")

                # Affiche les erreurs de validation si présentes
                if not args.validate:
                    errors = message.validate(strict=False)
                    if errors:
                        print(f"\n⚠ Attention: {len(errors)} erreur(s) de validation")
                        for err in errors[:5]:
                            print(f"    - {err}")
                        if len(errors) > 5:
                            print(f"    ... et {len(errors) - 5} autres")

    except Exception as e:
        print(f"Erreur: {e}", file=sys.stderr)
        sys.exit(1)


if __name__ == "__main__":
    main()
