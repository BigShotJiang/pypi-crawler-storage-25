"""
Types DSN (Données Sociales Nominatives)
Généré automatiquement depuis dsn-datatypes-CT2026.xlsx
"""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, field, fields
from typing import Any, ClassVar

from dsn_tools.enums import *  # noqa: F403


class DSNBlock:
    """Classe de base pour tous les blocs DSN."""

    block_id: ClassVar[str] = ""
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {}

    def __post_init__(self) -> None:
        """Compile les regex si pas déjà fait pour cette classe."""
        cls = self.__class__
        compiled_attr = f"_compiled_patterns_{cls.__name__}"
        if not hasattr(cls, compiled_attr) and cls._VALIDATION_RULES:
            patterns: dict[str, re.Pattern[str]] = {}
            for field_name, (pattern, _) in cls._VALIDATION_RULES.items():
                try:
                    patterns[field_name] = re.compile(pattern)
                except re.error:
                    pass
            setattr(cls, compiled_attr, patterns)

    def _get_compiled_patterns(self) -> dict[str, re.Pattern[str]]:
        """Retourne les regex compilées pour cette classe."""
        cls = self.__class__
        compiled_attr = f"_compiled_patterns_{cls.__name__}"
        return getattr(cls, compiled_attr, {})

    def validate(self, strict: bool = False) -> list[str]:
        """
        Valide les champs selon les règles définies.

        Args:
            strict: Si True, lève une exception en cas d'erreur.

        Returns:
            Liste des messages d'erreur.
        """
        errors: list[str] = []
        self.__post_init__()
        cls = self.__class__

        # Regex validation
        compiled_patterns = self._get_compiled_patterns()
        for field_name, pattern in compiled_patterns.items():
            value = getattr(self, field_name, None)
            if value and not pattern.fullmatch(str(value)):
                _, description = cls._VALIDATION_RULES.get(field_name, ("", field_name))
                msg = f"{cls.__name__}.{field_name}: '{value}' ne respecte pas {description}"
                errors.append(msg)

        # Enum validation
        import types
        from enum import Enum
        from typing import get_args, get_origin, get_type_hints

        # Get resolved type hints with proper namespace (includes imported enums)
        import dsn_tools.enums as enums_module

        try:
            localns = {
                name: getattr(enums_module, name)
                for name in dir(enums_module)
                if not name.startswith("_")
            }
            type_hints = get_type_hints(cls, localns=localns)
        except Exception:
            type_hints = {}

        for field_name, field_info in cls.__dataclass_fields__.items():
            if field_name.startswith("_") or field_name == "block_id":
                continue

            # Get the field type from resolved hints or raw type
            field_type = type_hints.get(field_name, field_info.type)

            # Handle Union types (e.g., N4DS_Essai | None)
            actual_type = field_type
            origin = get_origin(field_type)
            if origin is types.UnionType:
                # Python 3.10+ union syntax (X | Y)
                args = get_args(field_type)
                non_none_types = [arg for arg in args if arg is not type(None)]
                if len(non_none_types) == 1:
                    actual_type = non_none_types[0]
            elif isinstance(field_type, str):
                # Handle string annotations - skip
                continue

            # Check if it's an enum type
            if isinstance(actual_type, type) and issubclass(actual_type, Enum):
                value = getattr(self, field_name, None)
                if value is not None and not isinstance(value, actual_type):
                    try:
                        # Try to create enum instance - will raise ValueError if invalid
                        actual_type(value)
                    except ValueError:
                        valid_values = [m.value for m in actual_type]
                        msg = f"{cls.__name__}.{field_name}: '{value}' n'est pas une valeur valide pour {actual_type.__name__}. Valeurs attendues: {', '.join(valid_values)}"
                        errors.append(msg)

        if strict and errors:
            raise ValueError("\n".join(errors))

        return errors

    def to_dict(self, enum_mode: str = "label") -> dict[str, Any]:
        """
        Convertit le bloc en dictionnaire.

        Args:
            enum_mode: Mode de sérialisation des enums
                - "label": utilise la description lisible (ex: "envoi fichier test")
                - "code": utilise le code (ex: "01")
        """
        result: dict[str, Any] = {}
        for k, v in self.__dict__.items():
            if k.startswith("_"):
                continue
            if isinstance(v, list):
                result[k] = [
                    item.to_dict(enum_mode=enum_mode)
                    if hasattr(item, "to_dict")
                    else self._serialize_value(item, enum_mode)
                    for item in v
                ]
            elif hasattr(v, "to_dict"):
                result[k] = v.to_dict(enum_mode=enum_mode)
            else:
                result[k] = self._serialize_value(v, enum_mode)
        return result

    def _serialize_value(self, value: Any, enum_mode: str = "label") -> Any:
        """Sérialise une valeur, en convertissant les enums si nécessaire."""
        from enum import Enum

        if isinstance(value, Enum) and enum_mode == "label":
            return value.get_description()
        return value

    def to_json(self, indent: int = 2, ensure_ascii: bool = False) -> str:
        """Convertit le bloc en chaîne JSON."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii)

    def validate_required(self) -> list[str]:
        """
        Valide que les champs requis sont présents.
        Les champs avec une cardinalité obligatoire doivent être non-null.

        Returns:
            Liste des messages d'erreur.
        """
        errors: list[str] = []
        for f in fields(self):  # type: ignore[arg-type]
            if f.name.startswith("_") or f.name == "block_id":
                continue
            value = getattr(self, f.name, None)
            field_type = str(f.type)
            if "None" not in field_type and value is None:
                errors.append(f"{self.__class__.__name__}.{f.name}: champ requis mais absent")
            elif isinstance(value, list) and len(value) == 0 and "list[" in field_type.lower():
                errors.append(f"{self.__class__.__name__}.{f.name}: liste vide")
        return errors


@dataclass(init=False)
class S10_G00_01(DSNBlock):
    """Emetteur (S10.G00.01)"""

    block_id: ClassVar[str] = "S10.G00.01"

    code_de_distribution_a_letranger: str | None = (
        None  # 008: Code de distribution à l'étranger (N4DS_Adresse)
    )
    code_pays: str | None = None  # 007: Code pays (ISO_3166-1-A2_Pays)
    code_postal: str | None = None  # 005: Code postal (La_Poste_Hexaposte)
    complement_de_la_localisation_de_la_construction: str | None = (
        None  # 009: Complément de la localisation de la construction (N4DS_Adresse)
    )
    localite: str | None = None  # 006: Localité (N4DS_Adresse_Localite)
    nic_de_lemetteur_de_lenvoi: str | None = (
        None  # 002: Nic de l'émetteur de l'envoi (Identifiant_Nic_strict2)
    )
    nom_ou_raison_sociale_de_lemetteur: str | None = (
        None  # 003: Nom ou raison sociale de l'émetteur (Type_Alphanumeric_1-60)
    )
    numero_extension_nature_et_libelle_de_la_voie: str | None = (
        None  # 004: Numéro, extension, nature et libellé de la voie (N4DS_Adresse)
    )
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 010: Service de distribution, complément de localisation de la voie (N4DS_Adresse)
    )
    siren_de_lemetteur_de_lenvoi: str | None = (
        None  # 001: Siren de l'émetteur de l'envoi (Identifiant_Siren_strict)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "siren_de_lemetteur_de_lenvoi": (r"[0-9]*[1-9][0-9]*", ""),
        "nic_de_lemetteur_de_lenvoi": (
            r"[0-9]*[1-9][0-9]*",
            "Table OES - Organismes Emetteurs d'une DSN de Substitution",
        ),
        "localite": (r"[A-Za-z0-9\\s]+", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_distribution_a_letranger = None
        self.code_pays = None
        self.code_postal = None
        self.complement_de_la_localisation_de_la_construction = None
        self.localite = None
        self.nic_de_lemetteur_de_lenvoi = None
        self.nom_ou_raison_sociale_de_lemetteur = None
        self.numero_extension_nature_et_libelle_de_la_voie = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None
        self.siren_de_lemetteur_de_lenvoi = None


@dataclass(init=False)
class S10_G00_02(DSNBlock):
    """Contact Emetteur (S10.G00.02)"""

    block_id: ClassVar[str] = "S10.G00.02"

    adresse_fax: str | None = None  # 006: Adresse fax (Telephone)
    adresse_mel_du_contact_emetteur: str | None = (
        None  # 004: Adresse mél du contact émetteur (N4DS_Email_6-100)
    )
    adresse_telephonique: str | None = None  # 005: Adresse téléphonique (Telephone)
    code_civilite: Civilite | None = None  # 001: Code civilité (Civilite)
    nom_et_prenom_de_la_personne_a_contacter: str | None = (
        None  # 002: Nom et prénom de la personne à contacter (Identite_Base_1-80_regex)
    )

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.adresse_fax = None
        self.adresse_mel_du_contact_emetteur = None
        self.adresse_telephonique = None
        self.code_civilite = None
        self.nom_et_prenom_de_la_personne_a_contacter = None


@dataclass(init=False)
class S20_G00_07(DSNBlock):
    """Contact chez le déclaré (S20.G00.07)"""

    block_id: ClassVar[str] = "S20.G00.07"

    adresse_mel_du_contact: str | None = None  # 003: Adresse mél du contact (N4DS_Email_6-100)
    adresse_telephonique: str | None = None  # 002: Adresse téléphonique (Telephone)
    nom_et_prenom_du_contact: str | None = (
        None  # 001: Nom et prénom du contact (Identite_Base_1-80)
    )
    type: DSN_ContactDeclare_type | None = None  # 004: Type (DSN_ContactDeclare_type)

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.adresse_mel_du_contact = None
        self.adresse_telephonique = None
        self.nom_et_prenom_du_contact = None
        self.type = None


@dataclass(init=False)
class S20_G00_08(DSNBlock):
    """Identifiant de l’organisme destinataire de la déclaration « Absence de rattachement pour le mois principal déclaré » (S20.G00.08)"""

    block_id: ClassVar[str] = "S20.G00.08"

    code_caisse: str | None = None  # 001: Code caisse (DSN_Code_Caisse)

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_caisse = None


@dataclass(init=False)
class S21_G00_06(DSNBlock):
    """Entreprise (S21.G00.06)"""

    block_id: ClassVar[str] = "S21.G00.06"

    siren: str  # 001: SIREN (Identifiant_Siren_strict) [REQUIRED]
    code_apen: str | None = None  # 003: Code APEN (Insee_Naf_2008_4)
    code_convention_collective_applicable: str | None = (
        None  # 015: Code convention collective applicable (REF_IDCC)
    )
    code_de_distribution_a_letranger: str | None = (
        None  # 011: Code de distribution à l'étranger (Type_Alphanumeric_1-50)
    )
    code_pays: str | None = None  # 010: Code pays (ISO_3166-1-A2_Pays)
    code_postal: str | None = None  # 005: Code postal (La_Poste_Hexaposte)
    complement_de_la_localisation_de_la_construction: str | None = (
        None  # 007: Complément de la localisation de la construction (Type_Alphanumeric_1-50)
    )
    implantation_de_lentreprise: DSN_Implantation_Entreprise | None = (
        None  # 012: Implantation de l'entreprise (DSN_Implantation_Entreprise)
    )
    localite: str | None = None  # 006: Localité (N4DS_Adresse_Localite)
    nic_du_siege: str | None = None  # 002: NIC du siège (Identifiant_Nic_strict)
    numero_extension_nature_et_libelle_de_la_voie: str | None = (
        None  # 004: Numéro, extension, nature et libellé de la voie (N4DS_Adresse)
    )
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 008: Service de distribution, complément de localisation de la voie (N4DS_Adresse)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "siren": (r"[0-9]*[1-9][0-9]*", ""),
        "nic_du_siege": (r"[0-9]*[1-9][0-9]*", ""),
        "localite": (r"[A-Za-z0-9\\s]+", ""),
    }
    # Blocs enfants
    complement_oeth: list["S21_G00_13"] = field(
        default_factory=list
    )  # Complément OETH (S21.G00.13) [0..*]
    etablissement: "S21_G00_11" | None = None  # Etablissement (S21.G00.11) [1..1]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.siren = None
        self.code_apen = None
        self.code_convention_collective_applicable = None
        self.code_de_distribution_a_letranger = None
        self.code_pays = None
        self.code_postal = None
        self.complement_de_la_localisation_de_la_construction = None
        self.implantation_de_lentreprise = None
        self.localite = None
        self.nic_du_siege = None
        self.numero_extension_nature_et_libelle_de_la_voie = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None
        self.complement_oeth = []
        self.etablissement = None


@dataclass(init=False)
class S21_G00_13(DSNBlock):
    """Complément OETH (S21.G00.13)"""

    block_id: ClassVar[str] = "S21.G00.13"

    accord_agree_oeth: str | None = None  # 001: Accord agréé OETH (OethAccord)
    millesime_de_rattachement: str | None = None  # 004: Millésime de rattachement (Annee_2000)
    nombre_boeth_externe: str | None = None  # 003: Nombre BOETH externe (Montant_ZNS_4_8_2)
    type_boeth_externe: TypeBoeth | None = None  # 002: Type BOETH externe (TypeBoeth)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nombre_boeth_externe": (r"\\d{1,5}\\.\\d{2}", ""),
        "millesime_de_rattachement": (r"2([0-9]{3})", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.accord_agree_oeth = None
        self.millesime_de_rattachement = None
        self.nombre_boeth_externe = None
        self.type_boeth_externe = None


@dataclass(init=False)
class S21_G00_11(DSNBlock):
    """Etablissement (S21.G00.11)"""

    block_id: ClassVar[str] = "S21.G00.11"

    code_apet: str | None = None  # 002: Code APET (Insee_Naf_2008_4)
    code_convention_collective_principale: str | None = (
        None  # 022: Code convention collective principale (REF_IDCC)
    )
    code_de_distribution_a_letranger: str | None = (
        None  # 016: Code de distribution à l'étranger (Type_Alphanumeric_1-50)
    )
    code_pays: str | None = None  # 015: Code pays (ISO_3166-1-A2_Pays)
    code_postal: str | None = None  # 004: Code postal (La_Poste_Hexaposte)
    complement_de_la_localisation_de_la_construction: str | None = (
        None  # 006: Complément de la localisation de la construction (N4DS_Adresse)
    )
    date_deffet_de_la_sortie_du_dispositif_tese_cea: str | None = (
        None  # 020: Date d'effet de la sortie du dispositif TESE/CEA (Date_JJMMAAAA_sans_regex)
    )
    date_deffet_de_ladhesion_au_dispositif_tese_cea: str | None = (
        None  # 019: Date d'effet de l'adhésion au dispositif TESE/CEA (Date_JJMMAAAA_sans_regex)
    )
    demande_de_sortie_de_la_dsn: Sortie_DSN | None = (
        None  # 024: Demande de sortie de la DSN (Sortie_DSN)
    )
    identifiant_du_service_de_prevention_et_de_sante_au_travail_spst: str | None = (
        None  # 025: Identifiant du Service de Prévention et de Santé au Travail (SPST)  (Type_Alphanumeric_1_14)
    )
    localite: str | None = None  # 005: Localité (N4DS_Adresse_Localite)
    nature_juridique_de_lemployeur: DSN_Etablissement_Nature_Juridique | None = (
        None  # 017: Nature juridique de l'employeur (DSN_Etablissement_Nature_Juridique)
    )
    nic: str | None = None  # 001: NIC (Identifiant_Nic_strict)
    numero_extension_nature_et_libelle_de_la_voie: str | None = (
        None  # 003: Numéro, extension, nature et libellé de la voie (N4DS_Adresse)
    )
    operateur_de_competences_opco: str | None = None  # 023: Opérateur de compétences (OPCO) (OPCO)
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 007: Service de distribution, complément de localisation de la voie (N4DS_Adresse)
    )
    type_de_remuneration_soumise_a_contributions_dassurance_chomage_pour_expatries: (
        DSN_Renum_AC | None
    ) = None  # 009: Type de rémunération soumise à contributions d'Assurance chômage pour expatriés (DSN_Renum_AC)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nic": (r"[0-9]*[1-9][0-9]*", ""),
        "localite": (r"[A-Za-z0-9\\s]+", ""),
        "date_deffet_de_ladhesion_au_dispositif_tese_cea": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "date_deffet_de_la_sortie_du_dispositif_tese_cea": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
    }
    # Blocs enfants
    coordonnees_bancaires_specifiques: list["S21_G00_12"] = field(
        default_factory=list
    )  # Coordonnées bancaires spécifiques (S21.G00.12) [0..*]
    adhesion_prevoyance: list["S21_G00_15"] = field(
        default_factory=list
    )  # Adhésion Prévoyance (S21.G00.15) [0..*]
    cotisation_etablissement: list["S21_G00_82"] = field(
        default_factory=list
    )  # Cotisation établissement (S21.G00.82) [0..*]
    versement_organisme_de_protection_sociale: list["S21_G00_20"] = field(
        default_factory=list
    )  # Versement organisme de protection sociale (S21.G00.20) [0..*]
    bordereau_de_cotisation_due: list["S21_G00_22"] = field(
        default_factory=list
    )  # Bordereau de cotisation due (S21.G00.22) [0..*]
    assujettissement_fiscal: list["S21_G00_44"] = field(
        default_factory=list
    )  # Assujettissement fiscal (S21.G00.44) [0..*]
    individu: list["S21_G00_30"] = field(default_factory=list)  # Individu (S21.G00.30) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_apet = None
        self.code_convention_collective_principale = None
        self.code_de_distribution_a_letranger = None
        self.code_pays = None
        self.code_postal = None
        self.complement_de_la_localisation_de_la_construction = None
        self.date_deffet_de_la_sortie_du_dispositif_tese_cea = None
        self.date_deffet_de_ladhesion_au_dispositif_tese_cea = None
        self.demande_de_sortie_de_la_dsn = None
        self.identifiant_du_service_de_prevention_et_de_sante_au_travail_spst = None
        self.localite = None
        self.nature_juridique_de_lemployeur = None
        self.nic = None
        self.numero_extension_nature_et_libelle_de_la_voie = None
        self.operateur_de_competences_opco = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None
        self.type_de_remuneration_soumise_a_contributions_dassurance_chomage_pour_expatries = None
        self.coordonnees_bancaires_specifiques = []
        self.adhesion_prevoyance = []
        self.cotisation_etablissement = []
        self.versement_organisme_de_protection_sociale = []
        self.bordereau_de_cotisation_due = []
        self.assujettissement_fiscal = []
        self.individu = []


@dataclass(init=False)
class S21_G00_12(DSNBlock):
    """Coordonnées bancaires spécifiques (S21.G00.12)"""

    block_id: ClassVar[str] = "S21.G00.12"

    bic: str | None = None  # 002: BIC (Banque_BicRegexp)
    iban: str | None = None  # 003: IBAN (Banque_IbanRegexp)
    type_dusage: Type_Usage | None = None  # 001: Type d'usage (Type_Usage)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "bic": (r"([A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3}))|([A-Z]{4}[A-Z]{2}[A-Z0-9]{2})", ""),
        "iban": (r"[A-Z0-9]+", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.bic = None
        self.iban = None
        self.type_dusage = None


@dataclass(init=False)
class S21_G00_15(DSNBlock):
    """Adhésion Prévoyance (S21.G00.15)"""

    block_id: ClassVar[str] = "S21.G00.15"

    code_delegataire_de_gestion: str | None = (
        None  # 003: Code délégataire de gestion (DSN_Code_Deleg_Gestion)
    )
    code_organisme_de_prevoyance: str | None = (
        None  # 002: Code organisme de Prévoyance (DSN_Ref_Ops_4_5)
    )
    identifiant_technique_adhesion: str | None = (
        None  # 005: Identifiant technique Adhésion (DSN_Identifiant_Technique_Adhesion)
    )
    personnel_couvert: DSN_Personnel_Couvert | None = (
        None  # 004: Personnel couvert (DSN_Personnel_Couvert)
    )
    reference_du_contrat_de_prevoyance: str | None = (
        None  # 001: Référence du contrat de Prévoyance (Type_Alphanumeric_1-30)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "identifiant_technique_adhesion": (r"[1-9][0-9]*", ""),
    }
    # Blocs enfants
    changements_destinataire_adhesion_prevoyance: list["S21_G00_16"] = field(
        default_factory=list
    )  # Changements destinataire Adhésion Prévoyance (S21.G00.16) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_delegataire_de_gestion = None
        self.code_organisme_de_prevoyance = None
        self.identifiant_technique_adhesion = None
        self.personnel_couvert = None
        self.reference_du_contrat_de_prevoyance = None
        self.changements_destinataire_adhesion_prevoyance = []


@dataclass(init=False)
class S21_G00_16(DSNBlock):
    """Changements destinataire Adhésion Prévoyance (S21.G00.16)"""

    block_id: ClassVar[str] = "S21.G00.16"

    ancien_code_delegataire_de_gestion: str | None = (
        None  # 003: Ancien Code délégataire de gestion (DSN_Code_Deleg_Gestion)
    )
    ancien_code_organisme_de_prevoyance: str | None = (
        None  # 002: Ancien Code organisme de Prévoyance (DSN_Ref_Ops_4_5)
    )
    date_de_la_modification: str | None = None  # 001: Date de la modification (Date_JJMMAAAA_20)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_la_modification": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.ancien_code_delegataire_de_gestion = None
        self.ancien_code_organisme_de_prevoyance = None
        self.date_de_la_modification = None


@dataclass(init=False)
class S21_G00_82(DSNBlock):
    """Cotisation établissement (S21.G00.82)"""

    block_id: ClassVar[str] = "S21.G00.82"

    code_de_cotisation: DSN_Code_Cotisation | None = (
        None  # 002: Code de cotisation (DSN_Code_Cotisation)
    )
    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 003: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 004: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 006: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    reference_reglementaire_ou_contractuelle: str | None = (
        None  # 005: Référence réglementaire ou contractuelle (DSN_Reference_Reglementaire_Contractuelle)
    )
    valeur: str | None = None  # 001: Valeur (Montant_ZNS_4_18_3_N_Z)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "valeur": (r"-?[0-9]*\\.[0-9]{2}", ""),
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_cotisation = None
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.reference_reglementaire_ou_contractuelle = None
        self.valeur = None


@dataclass(init=False)
class S21_G00_20(DSNBlock):
    """Versement organisme de protection sociale (S21.G00.20)"""

    block_id: ClassVar[str] = "S21.G00.20"

    montant_du_versement: str  # 005: Montant du versement (Montant_ZNS_4_18_2) [REQUIRED]
    bic: str | None = None  # 003: BIC (Type_Alphanumeric_8-11_regex)
    code_delegataire_de_gestion: str | None = (
        None  # 008: Code délégataire de gestion (DSN_Code_Deleg_Gestion)
    )
    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 006: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 007: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_paiement: str | None = None  # 011: Date de paiement (Date_JJMMAAAA_20)
    entite_daffectation_des_operations: str | None = (
        None  # 002: Entité d'affectation des opérations (Type_Alphanumeric_2-14)
    )
    iban: str | None = None  # 004: IBAN (Type_Alphanumeric_15-34)
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 013: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    identifiant_du_versement: str | None = (
        None  # 014: Identifiant du versement (Type_Alphanumeric_1_40)
    )
    identifiant_organisme_de_protection_sociale: str | None = (
        None  # 001: Identifiant Organisme de Protection Sociale (DSN_IdOPS_2_14)
    )
    mode_de_paiement: DSN_Mode_Paiement | None = None  # 010: Mode de paiement (DSN_Mode_Paiement)
    siret_payeur: str | None = None  # 012: SIRET Payeur (DSN_SIRET_Payeur)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "bic": (r"([A-Z]{4}[A-Z]{2}[A-Z0-9]{2}([A-Z0-9]{3}))|([A-Z]{4}[A-Z]{2}[A-Z0-9]{2})", ""),
        "iban": (r"[A-Z0-9]+", ""),
        "montant_du_versement": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_paiement": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "siret_payeur": (r"[0-9]*[1-9][0-9]*", ""),
    }
    # Blocs enfants
    composant_de_versement: list["S21_G00_55"] = field(
        default_factory=list
    )  # Composant de versement (S21.G00.55) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.montant_du_versement = None
        self.bic = None
        self.code_delegataire_de_gestion = None
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.date_de_paiement = None
        self.entite_daffectation_des_operations = None
        self.iban = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.identifiant_du_versement = None
        self.identifiant_organisme_de_protection_sociale = None
        self.mode_de_paiement = None
        self.siret_payeur = None
        self.composant_de_versement = []


@dataclass(init=False)
class S21_G00_55(DSNBlock):
    """Composant de versement (S21.G00.55)"""

    block_id: ClassVar[str] = "S21.G00.55"

    code_daffectation: str | None = None  # 003: Code d'affectation (Type_Alphanumeric_1-30)
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 005: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    montant_verse: str | None = None  # 001: Montant versé (Montant_ZNS_4_18_N_Z)
    periode_daffectation: str | None = None  # 004: Période d'affectation (Type_Alphanumeric_7-7)
    type_de_population: str | None = None  # 002: Type de population (Type_Alphanumeric_1-30)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_verse": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "periode_daffectation": (
            r"[2][0][1-9][0-9](M01|M02|M03|M04|M05|M06|M07|M08|M09|M10|M11|M12|T01|T02|T03|T04|S01|S02|A00|E00)",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_daffectation = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.montant_verse = None
        self.periode_daffectation = None
        self.type_de_population = None


@dataclass(init=False)
class S21_G00_22(DSNBlock):
    """Bordereau de cotisation due (S21.G00.22)"""

    block_id: ClassVar[str] = "S21.G00.22"

    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 003: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 004: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    entite_daffectation_des_operations: str | None = (
        None  # 002: Entité d'affectation des opérations (Type_Alphanumeric_2-14)
    )
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 006: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    identifiant_organisme_de_protection_sociale: str | None = (
        None  # 001: Identifiant Organisme de Protection Sociale (DSN_IdOPS_5_14)
    )
    montant_total_de_cotisations: str | None = (
        None  # 005: Montant total de cotisations (Montant_ZNS_4_18_2_N_Z)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "montant_total_de_cotisations": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }
    # Blocs enfants
    cotisation_agregee: list["S21_G00_23"] = field(
        default_factory=list
    )  # Cotisation agrégée (S21.G00.23) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.entite_daffectation_des_operations = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.identifiant_organisme_de_protection_sociale = None
        self.montant_total_de_cotisations = None
        self.cotisation_agregee = []


@dataclass(init=False)
class S21_G00_23(DSNBlock):
    """Cotisation agrégée (S21.G00.23)"""

    block_id: ClassVar[str] = "S21.G00.23"

    code_de_cotisation: str | None = None  # 001: Code de cotisation (DSN_CodeCotis)
    code_insee_commune: str | None = None  # 006: Code INSEE commune (DSN_CodeINSEECommune_Postal)
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 007: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    montant_dassiette: str | None = None  # 004: Montant d'assiette (Montant_ZNS_4_18_2_N_Z)
    montant_de_cotisation: str | None = None  # 005: Montant de cotisation (Montant_ZNS_4_18_2_N_Z)
    qualifiant_dassiette: DSN_Qualifiant_Assiette | None = (
        None  # 002: Qualifiant d'assiette (DSN_Qualifiant_Assiette)
    )
    taux_de_cotisation: str | None = None  # 003: Taux de cotisation (TauxCotisation)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "taux_de_cotisation": (r"[0]?([0-9]{1,2}\\.[0-9]{2}|100\\.00)", ""),
        "montant_dassiette": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_de_cotisation": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_cotisation = None
        self.code_insee_commune = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.montant_dassiette = None
        self.montant_de_cotisation = None
        self.qualifiant_dassiette = None
        self.taux_de_cotisation = None


@dataclass(init=False)
class S21_G00_44(DSNBlock):
    """Assujettissement fiscal (S21.G00.44)"""

    block_id: ClassVar[str] = "S21.G00.44"

    code_taxe: DSN_Code_Taxe | None = None  # 001: Code taxe (DSN_Code_Taxe)
    millesime_de_rattachement: str | None = (
        None  # 003: Millésime de rattachement (Annee_21Siecle_plus)
    )
    montant: str | None = None  # 002: Montant (Montant_ZNS_4_16_N_12_Max)
    motif_de_non_assujettissement_a_la_taxe_dapprentissage: str | None = (
        None  # 004: Motif de non assujettissement à la taxe d'apprentissage (MNATA)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant": (r"-?(([0-9]){1,12})\\.[0-9]{2}", ""),
        "millesime_de_rattachement": (r"2([0-9]{3})", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_taxe = None
        self.millesime_de_rattachement = None
        self.montant = None
        self.motif_de_non_assujettissement_a_la_taxe_dapprentissage = None


@dataclass(init=False)
class S21_G00_30(DSNBlock):
    """Individu (S21.G00.30)"""

    block_id: ClassVar[str] = "S21.G00.30"

    date_de_naissance: str  # 006: Date de naissance (N4DS_DDN) [REQUIRED]
    lieu_de_naissance: str  # 007: Lieu de naissance (Commune) [REQUIRED]
    numero_dinscription_au_repertoire: (
        str  # 001: Numéro d'inscription au répertoire (Identifiant_Nir_13) [REQUIRED]
    )
    numero_technique_temporaire: (
        str  # 020: Numéro technique temporaire (Type_Alphanumeric_11_40) [REQUIRED]
    )
    adresse_mel: str | None = None  # 018: Adresse mél (N4DS_Email_6-100)
    code_de_distribution_a_letranger: str | None = (
        None  # 012: Code de distribution à l'étranger (N4DS_Adresse)
    )
    code_departement_de_naissance: str | None = (
        None  # 014: Code département de naissance (Departement)
    )
    code_pays: str | None = None  # 011: Code pays (ISO_3166-1-A2_Pays)
    code_pays_de_naissance: str | None = (
        None  # 015: Code pays de naissance (ISO_3166-1-A2_Pays_All)
    )
    code_postal: str | None = None  # 009: Code postal (La_Poste_Hexaposte)
    codification_ue: DSN_Codification_UE | None = None  # 013: Codification UE (DSN_Codification_UE)
    complement_de_la_localisation_de_la_construction: str | None = (
        None  # 016: Complément de la localisation de la construction (N4DS_Adresse)
    )
    cumul_emploi_retraite: DSN_Nouvelle_Embauche | None = (
        None  # 023: Cumul emploi retraite (DSN_Nouvelle_Embauche)
    )
    identifiant_du_service_de_prevention_et_de_sante_au_travail_spst: str | None = (
        None  # 030: Identifiant du Service de Prévention et de Santé au Travail (SPST) (Type_Alphanumeric_1_14)
    )
    libelle_du_pays_de_naissance: str | None = (
        None  # 029: Libellé du pays de naissance (Type_Alphanumeric_1_30)
    )
    localite: str | None = None  # 010: Localité (N4DS_Adresse_Localite)
    matricule_de_lindividu_dans_lentreprise: str | None = (
        None  # 019: Matricule de l'individu dans l'entreprise (Type_Alphanumeric_1-30)
    )
    niveau_de_diplome_prepare_par_lindividu: NiveauDiplomePrepare | None = (
        None  # 025: Niveau de diplôme préparé par l'individu (NiveauDiplomePrepare)
    )
    niveau_de_formation_le_plus_eleve_obtenu_par_lindividu: (
        DSN_NiveauFormationPlusEleveIndividu | None
    ) = None  # 024: Niveau de formation le plus élevé obtenu par l'individu (DSN_NiveauFormationPlusEleveIndividu)
    nom_de_famille: str | None = None  # 002: Nom de famille (Identite_Base_1-80_regex)
    nom_dusage: str | None = None  # 003: Nom d'usage (Identite_Base_1-80_regex)
    numero_extension_nature_et_libelle_de_la_voie: str | None = (
        None  # 008: Numéro, extension, nature et libellé de la voie (N4DS_Adresse)
    )
    prenoms: str | None = None  # 004: Prénoms (Identite_Base_1-80_regex)
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 017: Service de distribution, complément de localisation de la voie (N4DS_Adresse)
    )
    sexe: DSN_Sexe | None = None  # 005: Sexe (DSN_Sexe)
    statut_a_letranger_au_sens_fiscal: DSN_Statut_Etranger | None = (
        None  # 022: Statut à l'étranger au sens fiscal (DSN_Statut_Etranger)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "numero_dinscription_au_repertoire": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
        "date_de_naissance": (
            r"(0[0-9]|[1-2][0-9]|3[0-1]|99)(0[0-9]|1[0-2]|99)(18|19|20)[0-9]{2}",
            "",
        ),
        "localite": (r"[A-Za-z0-9\\s]+", ""),
        "code_departement_de_naissance": (r"(0[1-9]|[1-9][0-9])|2A|2B", ""),
    }
    # Blocs enfants
    changements_individu: list["S21_G00_31"] = field(
        default_factory=list
    )  # Changements Individu (S21.G00.31) [0..*]
    compte_professionnel_de_prevention_ex_penibilite: list["S21_G00_34"] = field(
        default_factory=list
    )  # Compte Professionnel de Prévention (Ex-Pénibilité) (S21.G00.34) [0..*]
    contrat_contrat_de_travail_convention_mandat: list["S21_G00_40"] = field(
        default_factory=list
    )  # Contrat (contrat de travail, convention, mandat) (S21.G00.40) [1..*]
    versement_individu: list["S21_G00_50"] = field(
        default_factory=list
    )  # Versement individu (S21.G00.50) [1..*]
    anciennete: list["S21_G00_86"] = field(default_factory=list)  # Ancienneté (S21.G00.86) [0..*]
    saisie_administrative_a_tiers_detenteur: list["S21_G00_98"] = field(
        default_factory=list
    )  # Saisie administrative à tiers détenteur (S21.G00.98) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_naissance = None
        self.lieu_de_naissance = None
        self.numero_dinscription_au_repertoire = None
        self.numero_technique_temporaire = None
        self.adresse_mel = None
        self.code_de_distribution_a_letranger = None
        self.code_departement_de_naissance = None
        self.code_pays = None
        self.code_pays_de_naissance = None
        self.code_postal = None
        self.codification_ue = None
        self.complement_de_la_localisation_de_la_construction = None
        self.cumul_emploi_retraite = None
        self.identifiant_du_service_de_prevention_et_de_sante_au_travail_spst = None
        self.libelle_du_pays_de_naissance = None
        self.localite = None
        self.matricule_de_lindividu_dans_lentreprise = None
        self.niveau_de_diplome_prepare_par_lindividu = None
        self.niveau_de_formation_le_plus_eleve_obtenu_par_lindividu = None
        self.nom_de_famille = None
        self.nom_dusage = None
        self.numero_extension_nature_et_libelle_de_la_voie = None
        self.prenoms = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None
        self.sexe = None
        self.statut_a_letranger_au_sens_fiscal = None
        self.changements_individu = []
        self.compte_professionnel_de_prevention_ex_penibilite = []
        self.contrat_contrat_de_travail_convention_mandat = []
        self.versement_individu = []
        self.anciennete = []
        self.saisie_administrative_a_tiers_detenteur = []


@dataclass(init=False)
class S21_G00_31(DSNBlock):
    """Changements Individu (S21.G00.31)"""

    block_id: ClassVar[str] = "S21.G00.31"

    ancien_nir: str  # 008: Ancien NIR (Identifiant_Nir_13) [REQUIRED]
    ancienne_date_de_naissance: str  # 011: Ancienne date de naissance (N4DS_DDN) [REQUIRED]
    ancien_nom_de_famille: str | None = None  # 009: Ancien nom de famille (Identite_Base_1-80)
    anciens_prenoms: str | None = None  # 010: Anciens prénoms (Identite_Base_1-80)
    date_de_la_modification: str | None = None  # 001: Date de la modification (Date_JJMMAAAA)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_la_modification": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "ancien_nir": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
        "ancienne_date_de_naissance": (
            r"(0[0-9]|[1-2][0-9]|3[0-1]|99)(0[0-9]|1[0-2]|99)(18|19|20)[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.ancien_nir = None
        self.ancienne_date_de_naissance = None
        self.ancien_nom_de_famille = None
        self.anciens_prenoms = None
        self.date_de_la_modification = None


@dataclass(init=False)
class S21_G00_34(DSNBlock):
    """Compte Professionnel de Prévention (Ex-Pénibilité) (S21.G00.34)"""

    block_id: ClassVar[str] = "S21.G00.34"

    annee_de_rattachement: str | None = None  # 003: Année de rattachement (Annee_2000)
    facteur_dexposition: DSN_Penibilite_Facteur_Exposition | None = (
        None  # 001: Facteur d'exposition (DSN_Penibilite_Facteur_Exposition)
    )
    numero_du_contrat: str | None = None  # 002: Numéro du contrat (Type_Alphanumeric_5-20)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "annee_de_rattachement": (r"2([0-9]{3})", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.annee_de_rattachement = None
        self.facteur_dexposition = None
        self.numero_du_contrat = None


@dataclass(init=False)
class S21_G00_40(DSNBlock):
    """Contrat (contrat de travail, convention, mandat) (S21.G00.40)"""

    block_id: ClassVar[str] = "S21.G00.40"

    complement_de_base_au_regime_obligatoire: (
        ROB_Extension  # 016: Complément de base au régime obligatoire (ROB_Extension) [REQUIRED]
    )
    dispositif_de_politique_publique_et_conventionnel: DSN_Dispos_PubEmpFormPro_2  # 008: Dispositif de politique publique et conventionnel (DSN_Dispos_PubEmpFormPro_2) [REQUIRED]
    fp_indice_brut_d_origine_sapeur_pompier_professionnel_spp: str  # 064: [FP] Indice brut d’origine sapeur-pompier professionnel (SPP) (FPIndiceAlpha) [REQUIRED]
    numero_de_licence_entrepreneur_spectacle: (
        str  # 049: Numéro de licence entrepreneur spectacle (Type_Alphanumeric_1-100) [REQUIRED]
    )
    taux_de_cotisation_accident_du_travail: (
        str  # 043: Taux de cotisation accident du travail (Nombre_4_6_regexp) [REQUIRED]
    )
    cas_de_mise_a_disposition_externe_dun_individu_de_letablissement: (
        DSN_CasMiseDispositionExterneIndividuEtablissement | None
    ) = None  # 074: Cas de mise à disposition externe d'un individu de l'établissement (DSN_CasMiseDispositionExterneIndividuEtablissement)
    categorie_de_classement_finale: str | None = (
        None  # 075: Catégorie de classement finale (DSN_CategorieClassementFinale)
    )
    code_affectation_assurance_chomage: str | None = (
        None  # 027: Code affectation Assurance chômage (Type_Alphanumeric_6_6)
    )
    code_caisse_professionnelle_de_conges_payes: str | None = (
        None  # 022: Code caisse professionnelle de congés payés (DSN_Code_Caisse_Professionnel)
    )
    code_categorie_de_service: FPCodeCategorieService | None = (
        None  # 056: Code catégorie de service (FPCodeCategorieService)
    )
    code_complement_pcs_ese_pour_la_fonction_publique_referentiels_neh_net_et_grade_de_la_nne: (
        str | None
    ) = None  # 005: Code complément PCS-ESE (pour la fonction publique : référentiels NEH, NET et grade de la NNE) (PCS-ESE_Complement_DSN_phase_3)
    code_convention_collective_applicable: str | None = (
        None  # 017: Code convention collective applicable (CCN)
    )
    code_delegataire_du_risque_maladie: DSN_Code_Delegataire_Risque_Maladie | None = (
        None  # 035: Code délégataire du risque maladie (DSN_Code_Delegataire_Risque_Maladie)
    )
    code_emplois_multiples: DSN_Code_Emplois_Multiples | None = (
        None  # 036: Code emplois multiples (DSN_Code_Emplois_Multiples)
    )
    code_employeurs_multiples: DSN_Code_Employeur_Multiples | None = (
        None  # 037: Code employeurs multiples (DSN_Code_Employeur_Multiples)
    )
    code_profession_et_categorie_socioprofessionnelle_pcs_ese: str | None = (
        None  # 004: Code profession et catégorie socioprofessionnelle (PCS-ESE) (Insee_PCS-ESE)
    )
    code_regime_de_base_risque_accident_du_travail: DSN_Code_regime_risques | None = (
        None  # 039: Code régime de base risque accident du travail (DSN_Code_regime_risques)
    )
    code_regime_de_base_risque_maladie: CodeRegime | None = (
        None  # 018: Code régime de base risque maladie (CodeRegime)
    )
    code_regime_de_base_risque_vieillesse: DSN_Code_Regime_Base_risque_vieillesse | None = (
        None  # 020: Code régime de base risque vieillesse (DSN_Code_Regime_Base_risque_vieillesse)
    )
    code_risque_accident_du_travail: str | None = (
        None  # 040: Code risque accident du travail (DSN_Code_Risque_ATMP)
    )
    code_statut_categoriel_apecita: DSN_Code_Statut_Categoriel_APECITA | None = (
        None  # 042: Code statut catégoriel APECITA (DSN_Code_Statut_Categoriel_APECITA)
    )
    code_statut_categoriel_retraite_complementaire_obligatoire: AA_Categorie | None = (
        None  # 003: Code statut catégoriel Retraite Complémentaire obligatoire (AA_Categorie)
    )
    coefficient_hierarchique: str | None = None  # 071: Coefficient hiérarchique (CoefHierarchique)
    college_cnieg: DSN_CollegeCNIEG | None = None  # 077: Collège (CNIEG) (DSN_CollegeCNIEG)
    complement_de_dispositif_de_politique_publique: DSN_ComplementDispositifPublic | None = (
        None  # 073: Complément de dispositif de politique publique (DSN_ComplementDispositifPublic)
    )
    date_d_effet_de_la_convention_de_gestion: str | None = (
        None  # 032: Date d’effet de la convention de gestion (Date_JJMMAAAA)
    )
    date_dadhesion: str | None = None  # 030: Date d'adhésion (Date_JJMMAAAA)
    date_de_debut_du_contrat: str | None = None  # 001: Date de début du contrat (Date_JJMMAAAA)
    date_de_denonciation: str | None = None  # 031: Date de dénonciation (Date_JJMMAAAA)
    date_de_fin_previsionnelle_du_contrat: str | None = (
        None  # 010: Date de fin prévisionnelle du contrat (Date_JJMMAAAA_20)
    )
    echelon: str | None = None  # 070: Echelon (Echelon)
    finess_geographique: str | None = None  # 081: FINESS géographique (Type_Alphanumeric_9_9)
    forme_damenagement_du_temps_de_travail_dans_le_cadre_de_lactivite_partielle: (
        DSN_FormeAmenagementTempsTravailActivitePartielle | None
    ) = None  # 078: Forme d'aménagement du temps de travail dans le cadre de l'activité partielle (DSN_FormeAmenagementTempsTravailActivitePartielle)
    fp_ancien_employeur_public: FPAncienEmployeurPublic | None = (
        None  # 062: [FP] Ancien employeur public (FPAncienEmployeurPublic)
    )
    fp_code_complement_pcs_ese_pour_la_fonction_publique_detat_emploi_de_la_nne: str | None = (
        None  # 052: [FP] Code complément PCS-ESE pour la fonction publique d'Etat (emploi de la NNE) (NNE)
    )
    fp_indice_brut: str | None = None  # 057: [FP] Indice brut (FPIndiceBrut)
    fp_indice_brut_d_origine_ancien_salarie_employeur_public: str | None = (
        None  # 063: [FP] Indice brut d’origine ancien salarié employeur public (FPIndiceAlpha)
    )
    fp_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15: str | None = (
        None  # 061: [FP] Indice brut de cotisation dans un emploi supérieur (article 15) (FPIndiceAlpha)
    )
    fp_indice_brut_dorigine: str | None = None  # 060: [FP] Indice brut d'origine (FPIndiceAlpha)
    fp_indice_complement_de_traitement_indiciaire_cti: str | None = (
        None  # 080: [FP] Indice complément de traitement indiciaire (CTI) (Numeric_1_998_SansDecimale)
    )
    fp_indice_majore: str | None = None  # 058: [FP] Indice majoré (Num_100_to_2500)
    fp_maintien_du_traitement_dorigine_dun_contractuel_titulaire: str | None = (
        None  # 065: [FP] Maintien du traitement d'origine d'un contractuel titulaire (FPIndiceAlpha)
    )
    fp_nouvelle_bonification_indiciaire_nbi: str | None = (
        None  # 059: [FP] Nouvelle bonification indiciaire (NBI) (Nombre_1_6_regex)
    )
    fp_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet: (
        str | None
    ) = None  # 054: [FP] Quotité de travail de référence de l'entreprise pour la catégorie de salarié dans l’hypothèse d’un poste à temps complet (Nombre_4_5)
    fp_type_de_detachement: FPTypeDetachement | None = (
        None  # 066: [FP] Type de détachement (FPTypeDetachement)
    )
    genre_de_navigation: Genre_Navigation | None = (
        None  # 067: Genre de navigation (Genre_Navigation)
    )
    grade: str | None = None  # 079: Grade (Type_Alphanumeric_1_5)
    heure_previsible_dembauche: str | None = (
        None  # 083: Heure prévisible d'embauche (HeureMinutes4-4)
    )
    identifiant_de_l_etablissement_utilisateur: str | None = (
        None  # 046: Identifiant de l’établissement utilisateur  (Type_Alphanumeric_2-14)
    )
    identifiant_du_contrat_dengagement_maritime: str | None = (
        None  # 076: Identifiant du contrat d'engagement maritime (Type_Alphanumeric_5-20)
    )
    identifiant_du_lieu_de_travail: str | None = (
        None  # 019: Identifiant du lieu de travail (DSN_Identifiant_Lieu_Travail)
    )
    libelle_de_lemploi: str | None = None  # 006: Libellé de l'emploi (Emploi_Nature)
    modalite_dexercice_du_temps_de_travail: Travail_Modalite | None = (
        None  # 014: Modalité d'exercice du temps de travail (Travail_Modalite)
    )
    motif_de_recours: DSN_Motifs_Recours | None = None  # 021: Motif de recours (DSN_Motifs_Recours)
    motif_dexclusion_dsn: DSN_Motif_Exclusion | None = (
        None  # 025: Motif d'exclusion DSN (DSN_Motif_Exclusion)
    )
    nature_du_contrat: DSN_NatureContrat | None = None  # 007: Nature du contrat (DSN_NatureContrat)
    nature_du_poste: NaturePoste | None = None  # 053: Nature du poste (NaturePoste)
    niveau_de_remuneration: str | None = None  # 069: Niveau de rémunération (Type_Alphanumeric_2-3)
    nombre_de_jours_de_periode_d_essai: str | None = (
        None  # 082: Nombre de jours de période d’essai (Numeric_1_3_regex)
    )
    numero_de_convention_de_gestion: str | None = (
        None  # 033: Numéro de convention de gestion (Type_Alphanumeric_4_10)
    )
    numero_de_label_prestataire_de_services_du_spectacle_vivant: str | None = (
        None  # 048: Numéro de label « Prestataire de services du spectacle vivant » (Type_Alphanumeric_1-100)
    )
    numero_du_contrat: str | None = None  # 009: Numéro du contrat (Type_Alphanumeric_5-20)
    numero_interne_employeur_public: str | None = (
        None  # 028: Numéro interne employeur public (Type_Alphanumeric_1-20)
    )
    numero_objet_spectacle: str | None = (
        None  # 050: Numéro objet spectacle (Type_Alphanumeric_12_12)
    )
    positionnement_dans_la_convention_collective: str | None = (
        None  # 041: Positionnement dans la convention collective (Type_Alphanumeric_1-100)
    )
    quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie: str | None = (
        None  # 012: Quotité de travail de référence de l'entreprise pour la catégorie de salarié (Quantite_ZNS_4_7_2_Z)
    )
    quotite_de_travail_du_contrat: str | None = (
        None  # 013: Quotité de travail du contrat (Quantite_ZNS_4_7_2_Z)
    )
    remuneration_au_pourboire: DSN_Remuneration_Pourboire | None = (
        None  # 045: Rémunération au pourboire (DSN_Remuneration_Pourboire)
    )
    salarie_a_temps_partiel_cotisant_a_temps_plein: DSN_Salarie_temps_partiel | None = (
        None  # 044: Salarié à temps partiel cotisant à temps plein (DSN_Salarie_temps_partiel)
    )
    statut_boeth: DSN_StatutBOETH | None = None  # 072: Statut BOETH (DSN_StatutBOETH)
    statut_demploi_du_salarie: DSN_Statut_Emplois | None = (
        None  # 026: Statut d'emploi du salarié (DSN_Statut_Emplois)
    )
    statut_du_salarie_conventionnel: CCN_Categorie | None = (
        None  # 002: Statut du salarié (conventionnel) (CCN_Categorie)
    )
    statut_organisateur_spectacle: StatutOrganisateurSpectacle | None = (
        None  # 051: Statut organisateur spectacle (StatutOrganisateurSpectacle)
    )
    taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels: str | None = (
        None  # 023: Taux de déduction forfaitaire spécifique pour frais professionnels (Taux_ZNS_4_6_2)
    )
    taux_de_service_actif: str | None = None  # 068: Taux de service actif (Taux_ZNS_4_6_2_Z)
    taux_de_travail_a_temps_partiel: str | None = (
        None  # 055: Taux de travail à temps partiel (Nombre_5_5)
    )
    travailleur_a_letranger_au_sens_du_code_de_la_securite_sociale: (
        DSN_Travailleur_Etranger | None
    ) = None  # 024: Travailleur à l'étranger au sens du code de la Sécurité Sociale (DSN_Travailleur_Etranger)
    type_de_gestion_de_l_assurance_chomage: DSN_Type_Gestion_Assu_Chomage | None = (
        None  # 029: Type de gestion de l’Assurance chômage (DSN_Type_Gestion_Assu_Chomage)
    )
    unite_de_mesure_de_la_quotite_de_travail: DSN_TypeUniteMesure | None = (
        None  # 011: Unité de mesure de la quotité de travail (DSN_TypeUniteMesure)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_du_contrat": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "date_de_fin_previsionnelle_du_contrat": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})",
            "",
        ),
        "quotite_de_travail_du_contrat": (r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})", ""),
        "taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "date_dadhesion": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "date_de_denonciation": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "date_d_effet_de_la_convention_de_gestion": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "taux_de_cotisation_accident_du_travail": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "fp_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "taux_de_travail_a_temps_partiel": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "fp_indice_brut": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_indice_majore": (r"1[0-9]{3}|2[0-4][0-9]{2}|25[0]{2}|[1-9][0-9]{2}", ""),
        "fp_nouvelle_bonification_indiciaire_nbi": (
            r"(^(0\\.(([1-9][0-9])|([0-9][1-9])|[1-9])|[1-9]\\d?(?:\\.[0-9]{1,2})?|[1-7]\\d\\d(?:\\.[0-9]{1,2})?|800(?:\\.0{1,2})?)$)",
            "",
        ),
        "fp_indice_brut_dorigine": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_indice_brut_d_origine_ancien_salarie_employeur_public": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_indice_brut_d_origine_sapeur_pompier_professionnel_spp": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_maintien_du_traitement_dorigine_dun_contractuel_titulaire": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "taux_de_service_actif": (r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})", ""),
        "echelon": (r"(0[1-9])|(1[0-2])", ""),
        "coefficient_hierarchique": (
            r"([0-9]{1,3})|(([0-9]|[a-z]|[A-Z]){1,5}\\.([0-9]|[a-z]|[A-Z]){2})",
            "",
        ),
        "categorie_de_classement_finale": (r"0[1-9]|1[0-9]|20", ""),
        "fp_indice_complement_de_traitement_indiciaire_cti": (
            r"[9][9][0-8]|[1-8][0-9]?[0-9]?|[9][0-8]?[0-9]?",
            "",
        ),
        "nombre_de_jours_de_periode_d_essai": (r"[0-9]{1,3}", ""),
        "heure_previsible_dembauche": (r"(?:[01][0-9]|2[0-3])[0-5][0-9]", ""),
    }
    # Blocs enfants
    changements_contrat: list["S21_G00_41"] = field(
        default_factory=list
    )  # Changements Contrat (S21.G00.41) [0..*]
    donnees_precedemment_declarees: "S21_G00_45" | None = (
        None  # Données précédemment déclarées (S21.G00.45) [0..1]
    )
    arret_de_travail: list["S21_G00_60"] = field(
        default_factory=list
    )  # Arrêt de travail (S21.G00.60) [0..*]
    fin_du_contrat: "S21_G00_62" | None = None  # Fin du contrat (S21.G00.62) [0..1]
    autre_suspension_de_lexecution_du_contrat: list["S21_G00_65"] = field(
        default_factory=list
    )  # Autre suspension de l'exécution du contrat (S21.G00.65) [0..*]
    affiliation_prevoyance: list["S21_G00_70"] = field(
        default_factory=list
    )  # Affiliation Prévoyance (S21.G00.70) [0..*]
    retraite_complementaire: list["S21_G00_71"] = field(
        default_factory=list
    )  # Retraite complémentaire (S21.G00.71) [1..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.complement_de_base_au_regime_obligatoire = None
        self.dispositif_de_politique_publique_et_conventionnel = None
        self.fp_indice_brut_d_origine_sapeur_pompier_professionnel_spp = None
        self.numero_de_licence_entrepreneur_spectacle = None
        self.taux_de_cotisation_accident_du_travail = None
        self.cas_de_mise_a_disposition_externe_dun_individu_de_letablissement = None
        self.categorie_de_classement_finale = None
        self.code_affectation_assurance_chomage = None
        self.code_caisse_professionnelle_de_conges_payes = None
        self.code_categorie_de_service = None
        self.code_complement_pcs_ese_pour_la_fonction_publique_referentiels_neh_net_et_grade_de_la_nne = None
        self.code_convention_collective_applicable = None
        self.code_delegataire_du_risque_maladie = None
        self.code_emplois_multiples = None
        self.code_employeurs_multiples = None
        self.code_profession_et_categorie_socioprofessionnelle_pcs_ese = None
        self.code_regime_de_base_risque_accident_du_travail = None
        self.code_regime_de_base_risque_maladie = None
        self.code_regime_de_base_risque_vieillesse = None
        self.code_risque_accident_du_travail = None
        self.code_statut_categoriel_apecita = None
        self.code_statut_categoriel_retraite_complementaire_obligatoire = None
        self.coefficient_hierarchique = None
        self.college_cnieg = None
        self.complement_de_dispositif_de_politique_publique = None
        self.date_d_effet_de_la_convention_de_gestion = None
        self.date_dadhesion = None
        self.date_de_debut_du_contrat = None
        self.date_de_denonciation = None
        self.date_de_fin_previsionnelle_du_contrat = None
        self.echelon = None
        self.finess_geographique = None
        self.forme_damenagement_du_temps_de_travail_dans_le_cadre_de_lactivite_partielle = None
        self.fp_ancien_employeur_public = None
        self.fp_code_complement_pcs_ese_pour_la_fonction_publique_detat_emploi_de_la_nne = None
        self.fp_indice_brut = None
        self.fp_indice_brut_d_origine_ancien_salarie_employeur_public = None
        self.fp_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15 = None
        self.fp_indice_brut_dorigine = None
        self.fp_indice_complement_de_traitement_indiciaire_cti = None
        self.fp_indice_majore = None
        self.fp_maintien_du_traitement_dorigine_dun_contractuel_titulaire = None
        self.fp_nouvelle_bonification_indiciaire_nbi = None
        self.fp_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet = None
        self.fp_type_de_detachement = None
        self.genre_de_navigation = None
        self.grade = None
        self.heure_previsible_dembauche = None
        self.identifiant_de_l_etablissement_utilisateur = None
        self.identifiant_du_contrat_dengagement_maritime = None
        self.identifiant_du_lieu_de_travail = None
        self.libelle_de_lemploi = None
        self.modalite_dexercice_du_temps_de_travail = None
        self.motif_de_recours = None
        self.motif_dexclusion_dsn = None
        self.nature_du_contrat = None
        self.nature_du_poste = None
        self.niveau_de_remuneration = None
        self.nombre_de_jours_de_periode_d_essai = None
        self.numero_de_convention_de_gestion = None
        self.numero_de_label_prestataire_de_services_du_spectacle_vivant = None
        self.numero_du_contrat = None
        self.numero_interne_employeur_public = None
        self.numero_objet_spectacle = None
        self.positionnement_dans_la_convention_collective = None
        self.quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie = None
        self.quotite_de_travail_du_contrat = None
        self.remuneration_au_pourboire = None
        self.salarie_a_temps_partiel_cotisant_a_temps_plein = None
        self.statut_boeth = None
        self.statut_demploi_du_salarie = None
        self.statut_du_salarie_conventionnel = None
        self.statut_organisateur_spectacle = None
        self.taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels = None
        self.taux_de_service_actif = None
        self.taux_de_travail_a_temps_partiel = None
        self.travailleur_a_letranger_au_sens_du_code_de_la_securite_sociale = None
        self.type_de_gestion_de_l_assurance_chomage = None
        self.unite_de_mesure_de_la_quotite_de_travail = None
        self.changements_contrat = []
        self.donnees_precedemment_declarees = None
        self.arret_de_travail = []
        self.fin_du_contrat = None
        self.autre_suspension_de_lexecution_du_contrat = []
        self.affiliation_prevoyance = []
        self.retraite_complementaire = []


@dataclass(init=False)
class S21_G00_41(DSNBlock):
    """Changements Contrat (S21.G00.41)"""

    block_id: ClassVar[str] = "S21.G00.41"

    ancien_dispositif_de_politique_publique_et_conventionnel: DSN_Dispos_PubEmpFormPro_2  # 005: Ancien dispositif de politique publique et conventionnel (DSN_Dispos_PubEmpFormPro_2) [REQUIRED]
    fp_ancien_indice_brut_d_origine_sapeur_pompier_professionnel_spp: str  # 041: [FP] Ancien indice brut d’origine sapeur-pompier professionnel (SPP) (FPIndiceAlpha) [REQUIRED]
    ancien_cas_de_mise_a_disposition_externe_dun_individu_de_letablissement: (
        DSN_CasMiseDispositionExterneIndividuEtablissementAncien | None
    ) = None  # 050: Ancien cas de mise à disposition externe d'un individu de l'établissement (DSN_CasMiseDispositionExterneIndividuEtablissementAncien)
    ancien_code_caisse_professionnelle_de_conges_payes: str | None = (
        None  # 023: Ancien code caisse professionnelle de congés payés  (DSN_Code_Caisse_Professionnel)
    )
    ancien_code_categorie_de_service: FPCodeCategorieServiceAncien | None = (
        None  # 033: Ancien code catégorie de service (FPCodeCategorieServiceAncien)
    )
    ancien_code_complement_pcs_ese_pour_la_fonction_publique_referentiels_neh_net_et_grade_de_la_nne: (
        str | None
    ) = None  # 020: Ancien code complément PCS-ESE (pour la fonction publique : référentiels NEH, NET et grade de la NNE) (PCS-ESE_Complement_DSN_phase_3)
    ancien_code_convention_collective_applicable: str | None = (
        None  # 011: Ancien code convention collective applicable (CCN)
    )
    ancien_code_emplois_multiples: Type_ancien_code_emplois_multiples | None = (
        None  # 061: Ancien code emplois multiples (Type_ancien_code_emplois_multiples)
    )
    ancien_code_employeurs_multiples: Type_ancien_code_emplois_multiples_2 | None = (
        None  # 062: Ancien code employeurs multiples (Type_ancien_code_emplois_multiples_2)
    )
    ancien_code_profession_et_categorie_socioprofessionnelle_pcs_ese: str | None = (
        None  # 019: Ancien code profession et catégorie socioprofessionnelle (PCS-ESE)  (DSN_PCS-ESE)
    )
    ancien_code_regime_de_base_risque_accident_du_travail: AncienCodeRegime | None = (
        None  # 059: Ancien code régime de base risque accident du travail (AncienCodeRegime)
    )
    ancien_code_regime_de_base_risque_maladie: CodeRegime | None = (
        None  # 052: Ancien code régime de base risque maladie (CodeRegime)
    )
    ancien_code_regime_de_base_risque_vieillesse: DSN_Code_Regime_Base_risque_vieillesse | None = (
        None  # 053: Ancien code régime de base risque vieillesse (DSN_Code_Regime_Base_risque_vieillesse)
    )
    ancien_code_risque_accident_du_travail: str | None = (
        None  # 024: Ancien code risque accident du travail (DSN_Code_Risque_ATMP)
    )
    ancien_code_statut_categoriel_apecita: DSN_CodeStatutCategorielAPECITA | None = (
        None  # 025: Ancien code statut catégoriel APECITA (DSN_CodeStatutCategorielAPECITA)
    )
    ancien_code_statut_categoriel_retraite_complementaire_obligatoire: AA_Categorie | None = (
        None  # 003: Ancien code statut catégoriel Retraite Complémentaire obligatoire (AA_Categorie)
    )
    ancien_coefficient_hierarchique: str | None = (
        None  # 046: Ancien coefficient hiérarchique (CoefHierarchique)
    )
    ancien_college_cnieg: DSN_CollegeCNIEGAncien | None = (
        None  # 055: Ancien collège (CNIEG) (DSN_CollegeCNIEGAncien)
    )
    ancien_complement_de_base_au_regime_obligatoire: ROB_Extension | None = (
        None  # 010: Ancien complément de base au régime obligatoire (ROB_Extension)
    )
    ancien_complement_de_dispositif_de_politique_publique: (
        DSN_AncienComplementDispositifPublic | None
    ) = None  # 049: Ancien complément de dispositif de politique publique (DSN_AncienComplementDispositifPublic)
    ancien_echelon: str | None = None  # 045: Ancien échelon  (Echelon_00)
    ancien_finess_geographique: str | None = (
        None  # 065: Ancien FINESS géographique (Type_Alphanumeric_9_9)
    )
    ancien_genre_de_navigation: Genre_NavigationAncien | None = (
        None  # 047: Ancien genre de navigation (Genre_NavigationAncien)
    )
    ancien_grade: str | None = None  # 063: Ancien grade (Type_Alphanumeric_1_5)
    ancien_identifiant_du_contrat_dengagement_maritime: str | None = (
        None  # 054: Ancien identifiant du contrat d'engagement maritime (Type_Alphanumeric_5-20)
    )
    ancien_identifiant_du_lieu_de_travail: str | None = (
        None  # 013: Ancien identifiant du lieu de travail (DSN_Identifiant_Lieu_Travail)
    )
    ancien_motif_de_recours: DSN_Ancien_Motifs_Recours | None = (
        None  # 016: Ancien motif de recours (DSN_Ancien_Motifs_Recours)
    )
    ancien_niveau_de_remuneration: str | None = (
        None  # 044: Ancien niveau de rémunération (Type_Alphanumeric_2-3)
    )
    ancien_numero_du_contrat: str | None = (
        None  # 014: Ancien numéro du contrat (Type_Alphanumeric_5-20)
    )
    ancien_positionnement_dans_la_convention_collective: str | None = (
        None  # 058: Ancien positionnement dans la convention collective (Type_Alphanumeric_1-100)
    )
    ancien_salarie_a_temps_partiel_cotisant_a_temps_plein: (
        DSN_Ancien_Salarie_temps_partiel | None
    ) = None  # 027: Ancien salarié à temps partiel cotisant à temps plein (DSN_Ancien_Salarie_temps_partiel)
    ancien_statut_boeth: DSN_StatutBOETHAncien | None = (
        None  # 048: Ancien statut BOETH (DSN_StatutBOETHAncien)
    )
    ancien_statut_demploi_du_salarie: AncientStatutEmploiSalarie | None = (
        None  # 060: Ancien statut d'emploi du salarié (AncientStatutEmploiSalarie)
    )
    ancien_statut_du_salarie_conventionnel: CCN_Categorie | None = (
        None  # 002: Ancien statut du salarié (conventionnel) (CCN_Categorie)
    )
    ancien_taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels: str | None = (
        None  # 017: Ancien taux de déduction forfaitaire spécifique pour frais professionnels (Ancien_Taux_ZNS_4_6_2)
    )
    ancien_taux_de_service_actif: str | None = (
        None  # 043: Ancien taux de service actif  (Taux_ZNS_4_6_2_Z)
    )
    ancien_taux_de_travail_a_temps_partiel: str | None = (
        None  # 032: Ancien taux de travail à temps partiel (Nombre_4_5_0.00)
    )
    ancien_travailleur_a_letranger_au_sens_du_code_de_la_securite_sociale: (
        DSN_TravailleurEtranger | None
    ) = None  # 018: Ancien travailleur à l'étranger au sens du code de la Sécurité Sociale (DSN_TravailleurEtranger)
    ancienne_categorie_de_classement_finale: str | None = (
        None  # 051: Ancienne catégorie de classement finale (DSN_AncienneCategorieClassementFinale)
    )
    ancienne_date_de_debut_du_contrat: str | None = (
        None  # 021: Ancienne date de début du contrat (Date_JJMMAAAA)
    )
    ancienne_forme_damenagement_du_temps_de_travail_dans_le_cadre_de_lactivite_partielle: (
        DSN_FormeAmenagementTempsTravailActivitePartielleAncien | None
    ) = None  # 056: Ancienne forme d'aménagement du temps de travail dans le cadre de l'activité partielle (DSN_FormeAmenagementTempsTravailActivitePartielleAncien)
    ancienne_modalite_dexercice_du_temps_de_travail: Travail_Modalite | None = (
        None  # 008: Ancienne modalité d'exercice du temps de travail (Travail_Modalite)
    )
    ancienne_nature_du_contrat: DSN_NatureContrat | None = (
        None  # 004: Ancienne nature du contrat (DSN_NatureContrat)
    )
    ancienne_nature_du_poste: AncienNaturePoste | None = (
        None  # 030: Ancienne nature du poste (AncienNaturePoste)
    )
    ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie: (
        str | None
    ) = None  # 022: Ancienne quotité de travail de référence de l'entreprise pour la catégorie de salarié (Quantite_ZNS_4_7_2_Z)
    ancienne_quotite_de_travail_du_contrat: str | None = (
        None  # 007: Ancienne quotité de travail du contrat (Quantite_ZNS_4_7_2_Z)
    )
    ancienne_unite_de_mesure_de_la_quotite_de_travail: DSN_TypeUniteMesure | None = (
        None  # 006: Ancienne unité de mesure de la quotité de travail (DSN_TypeUniteMesure)
    )
    date_de_la_modification: str | None = None  # 001: Date de la modification (Date_JJMMAAAA_20)
    fp_ancien_ancien_employeur_public: FPAncienEmployeurPublicAncien | None = (
        None  # 039: [FP] Ancien ancien employeur public (FPAncienEmployeurPublicAncien)
    )
    fp_ancien_code_complement_pcs_ese_pour_la_fonction_publique_detat_emploi_de_la_nne: (
        str | None
    ) = None  # 029: [FP] Ancien code complément PCS-ESE pour la fonction publique d'Etat (emploi de la NNE) (NNE)
    fp_ancien_indice_brut: str | None = None  # 034: [FP] Ancien indice brut (FPIndiceBrut)
    fp_ancien_indice_brut_d_origine_ancien_salarie_employeur_public: str | None = (
        None  # 040: [FP] Ancien indice brut d’origine ancien salarié employeur public (FPIndiceAlpha)
    )
    fp_ancien_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15: str | None = (
        None  # 038: [FP] Ancien indice brut de cotisation dans un emploi supérieur (article 15) (FPIndiceAlpha)
    )
    fp_ancien_indice_brut_dorigine: str | None = (
        None  # 037: [FP] Ancien indice brut d'origine (FPIndiceAlpha)
    )
    fp_ancien_indice_complement_de_traitement_indiciaire_cti: str | None = (
        None  # 064: [FP] Ancien indice complément de traitement indiciaire (CTI) (Numeric_1_999_SansDecimale)
    )
    fp_ancien_indice_majore: str | None = (
        None  # 035: [FP] Ancien indice majoré (Num_100_to_2500_000)
    )
    fp_ancien_maintien_du_traitement_dorigine_dun_contractuel_titulaire: str | None = (
        None  # 042: [FP] Ancien maintien du traitement d'origine d'un contractuel titulaire (FPIndiceAlpha)
    )
    fp_ancien_type_de_detachement: FPTypeDetachementAncien | None = (
        None  # 057: [FP] Ancien type de détachement (FPTypeDetachementAncien)
    )
    fp_ancienne_nouvelle_bonification_indiciaire_nbi: str | None = (
        None  # 036: [FP] Ancienne nouvelle bonification indiciaire (NBI) (Nombre_1_6_regex_0.00)
    )
    fp_ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet: (
        str | None
    ) = None  # 031: [FP] Ancienne quotité de travail de référence de l'entreprise pour la catégorie de salarié dans l’hypothèse d’un poste à temps complet (Nombre_4_5_0.00)
    profondeur_de_recalcul_de_la_paie: str | None = (
        None  # 028: Profondeur de recalcul de la paie (Date_JJMMAAAA_20_21)
    )
    siret_ancien_etablissement_daffectation: str | None = (
        None  # 012: SIRET ancien établissement d'affectation (Identifiant_Siret)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_la_modification": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "ancienne_quotite_de_travail_du_contrat": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})",
            "",
        ),
        "siret_ancien_etablissement_daffectation": (r"[0-9]*[1-9][0-9]*", ""),
        "ancien_taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels": (
            r"[0-9]{1,3}\\.[0-9]{2}",
            "",
        ),
        "ancienne_date_de_debut_du_contrat": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})",
            "",
        ),
        "profondeur_de_recalcul_de_la_paie": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "fp_ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet": (
            r"([0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9])))|[0][.][0][0]",
            "",
        ),
        "ancien_taux_de_travail_a_temps_partiel": (
            r"([0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9])))|[0][.][0][0]",
            "",
        ),
        "fp_ancien_indice_brut": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_ancien_indice_majore": (
            r"1[0-9]{3}|2[0-4][0-9]{2}|25[0]{2}|[1-9][0-9]{2}|[0]{1,3}",
            "",
        ),
        "fp_ancienne_nouvelle_bonification_indiciaire_nbi": (
            r"(^(0\\.(([1-9][0-9])|([0-9][1-9])|[1-9])|[1-9]\\d?(?:\\.[0-9]{1,2})?|[1-7]\\d\\d(?:\\.[0-9]{1,2})?|800(?:\\.0{1,2})?)$)|[0][\\.][0][0]",
            "",
        ),
        "fp_ancien_indice_brut_dorigine": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_ancien_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_ancien_indice_brut_d_origine_ancien_salarie_employeur_public": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_ancien_indice_brut_d_origine_sapeur_pompier_professionnel_spp": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "fp_ancien_maintien_du_traitement_dorigine_dun_contractuel_titulaire": (
            r"1[0-9]{3}|0?1[0-9]{2,2}|2(([0-4][0-9]{2})|(5(0){2}))|0?2([0-9]{2})|0?[3-9][0-9]{2}|[A-Za-z]{1,2}[0-9]",
            "",
        ),
        "ancien_taux_de_service_actif": (r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})", ""),
        "ancien_echelon": (r"(0[0-9])|(1[0-2])", ""),
        "ancien_coefficient_hierarchique": (
            r"([0-9]{1,3})|(([0-9]|[a-z]|[A-Z]){1,5}\\.([0-9]|[a-z]|[A-Z]){2})",
            "",
        ),
        "ancienne_categorie_de_classement_finale": (r"0[0-9]|1[0-9]|20", ""),
        "fp_ancien_indice_complement_de_traitement_indiciaire_cti": (
            r"[9][9][0-9]|[1-8][0-9]?[0-9]?|[9][0-8]?[0-9]?",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.ancien_dispositif_de_politique_publique_et_conventionnel = None
        self.fp_ancien_indice_brut_d_origine_sapeur_pompier_professionnel_spp = None
        self.ancien_cas_de_mise_a_disposition_externe_dun_individu_de_letablissement = None
        self.ancien_code_caisse_professionnelle_de_conges_payes = None
        self.ancien_code_categorie_de_service = None
        self.ancien_code_complement_pcs_ese_pour_la_fonction_publique_referentiels_neh_net_et_grade_de_la_nne = None
        self.ancien_code_convention_collective_applicable = None
        self.ancien_code_emplois_multiples = None
        self.ancien_code_employeurs_multiples = None
        self.ancien_code_profession_et_categorie_socioprofessionnelle_pcs_ese = None
        self.ancien_code_regime_de_base_risque_accident_du_travail = None
        self.ancien_code_regime_de_base_risque_maladie = None
        self.ancien_code_regime_de_base_risque_vieillesse = None
        self.ancien_code_risque_accident_du_travail = None
        self.ancien_code_statut_categoriel_apecita = None
        self.ancien_code_statut_categoriel_retraite_complementaire_obligatoire = None
        self.ancien_coefficient_hierarchique = None
        self.ancien_college_cnieg = None
        self.ancien_complement_de_base_au_regime_obligatoire = None
        self.ancien_complement_de_dispositif_de_politique_publique = None
        self.ancien_echelon = None
        self.ancien_finess_geographique = None
        self.ancien_genre_de_navigation = None
        self.ancien_grade = None
        self.ancien_identifiant_du_contrat_dengagement_maritime = None
        self.ancien_identifiant_du_lieu_de_travail = None
        self.ancien_motif_de_recours = None
        self.ancien_niveau_de_remuneration = None
        self.ancien_numero_du_contrat = None
        self.ancien_positionnement_dans_la_convention_collective = None
        self.ancien_salarie_a_temps_partiel_cotisant_a_temps_plein = None
        self.ancien_statut_boeth = None
        self.ancien_statut_demploi_du_salarie = None
        self.ancien_statut_du_salarie_conventionnel = None
        self.ancien_taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels = None
        self.ancien_taux_de_service_actif = None
        self.ancien_taux_de_travail_a_temps_partiel = None
        self.ancien_travailleur_a_letranger_au_sens_du_code_de_la_securite_sociale = None
        self.ancienne_categorie_de_classement_finale = None
        self.ancienne_date_de_debut_du_contrat = None
        self.ancienne_forme_damenagement_du_temps_de_travail_dans_le_cadre_de_lactivite_partielle = None
        self.ancienne_modalite_dexercice_du_temps_de_travail = None
        self.ancienne_nature_du_contrat = None
        self.ancienne_nature_du_poste = None
        self.ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie = None
        self.ancienne_quotite_de_travail_du_contrat = None
        self.ancienne_unite_de_mesure_de_la_quotite_de_travail = None
        self.date_de_la_modification = None
        self.fp_ancien_ancien_employeur_public = None
        self.fp_ancien_code_complement_pcs_ese_pour_la_fonction_publique_detat_emploi_de_la_nne = (
            None
        )
        self.fp_ancien_indice_brut = None
        self.fp_ancien_indice_brut_d_origine_ancien_salarie_employeur_public = None
        self.fp_ancien_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15 = None
        self.fp_ancien_indice_brut_dorigine = None
        self.fp_ancien_indice_complement_de_traitement_indiciaire_cti = None
        self.fp_ancien_indice_majore = None
        self.fp_ancien_maintien_du_traitement_dorigine_dun_contractuel_titulaire = None
        self.fp_ancien_type_de_detachement = None
        self.fp_ancienne_nouvelle_bonification_indiciaire_nbi = None
        self.fp_ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet = None
        self.profondeur_de_recalcul_de_la_paie = None
        self.siret_ancien_etablissement_daffectation = None


@dataclass(init=False)
class S21_G00_45(DSNBlock):
    """Données précédemment déclarées (S21.G00.45)"""

    block_id: ClassVar[str] = "S21.G00.45"

    numero_du_contrat_declare_precedemment: str | None = (
        None  # 002: Numéro du contrat déclaré précédemment (Type_Alphanumeric_5-20)
    )
    siret_declarant_le_contrat_precedemment: str | None = (
        None  # 001: SIRET déclarant le contrat précédemment (Identifiant_Siret)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "siret_declarant_le_contrat_precedemment": (r"[0-9]*[1-9][0-9]*", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.numero_du_contrat_declare_precedemment = None
        self.siret_declarant_le_contrat_precedemment = None


@dataclass(init=False)
class S21_G00_60(DSNBlock):
    """Arrêt de travail (S21.G00.60)"""

    block_id: ClassVar[str] = "S21.G00.60"

    bic: str | None = None  # 008: BIC (Banque_Bic)
    date_de_debut_de_subrogation: str | None = (
        None  # 005: Date de début de subrogation (Date_JJMMAAAA_20)
    )
    date_de_fin_de_subrogation: str | None = (
        None  # 006: Date de fin de subrogation (Date_JJMMAAAA_20)
    )
    date_de_fin_previsionnelle: str | None = (
        None  # 003: Date de fin prévisionnelle (Date_JJMMAAAA_20)
    )
    date_de_la_reprise: str | None = None  # 010: Date de la reprise (Date_JJMMAAAA_20)
    date_de_laccident_ou_de_la_premiere_constatation: str | None = (
        None  # 012: Date de l'accident ou de la première constatation (Date_JJMMAAAA)
    )
    date_du_dernier_jour_travaille: str | None = (
        None  # 002: Date du dernier jour travaillé (Date_JJMMAAAA_20)
    )
    iban: str | None = None  # 007: IBAN (Banque_Iban)
    motif_de_la_reprise: Motif_reprise_DSN_phase_1 | None = (
        None  # 011: Motif de la reprise (Motif_reprise_DSN_phase_1)
    )
    motif_de_larret: Arret_Motif_DSN_phase_1 | None = (
        None  # 001: Motif de l'arrêt (Arret_Motif_DSN_phase_1)
    )
    siret_centralisateur: str | None = None  # 600: SIRET Centralisateur (DSN_SiretCentralisateur)
    subrogation: N4DS_O_N | None = None  # 004: Subrogation (N4DS_O_N)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_du_dernier_jour_travaille": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_previsionnelle": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_debut_de_subrogation": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_subrogation": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_la_reprise": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "date_de_laccident_ou_de_la_premiere_constatation": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "siret_centralisateur": (r"[0-9]*[1-9][0-9]*", ""),
    }
    # Blocs enfants
    temps_partiel_therapeutique: list["S21_G00_66"] = field(
        default_factory=list
    )  # Temps partiel Thérapeutique (S21.G00.66) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.bic = None
        self.date_de_debut_de_subrogation = None
        self.date_de_fin_de_subrogation = None
        self.date_de_fin_previsionnelle = None
        self.date_de_la_reprise = None
        self.date_de_laccident_ou_de_la_premiere_constatation = None
        self.date_du_dernier_jour_travaille = None
        self.iban = None
        self.motif_de_la_reprise = None
        self.motif_de_larret = None
        self.siret_centralisateur = None
        self.subrogation = None
        self.temps_partiel_therapeutique = []


@dataclass(init=False)
class S21_G00_66(DSNBlock):
    """Temps partiel Thérapeutique (S21.G00.66)"""

    block_id: ClassVar[str] = "S21.G00.66"

    date_de_debut: str | None = None  # 001: Date de début (Date_JJMMAAAA_sans_regex)
    date_de_fin: str | None = None  # 002: Date de fin (Date_JJMMAAAA_sans_regex)
    montant: str | None = None  # 003: Montant (Montant_ZNS_4_12_2_N_Z)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "date_de_fin": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "montant": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut = None
        self.date_de_fin = None
        self.montant = None


@dataclass(init=False)
class S21_G00_62(DSNBlock):
    """Fin du contrat (S21.G00.62)"""

    block_id: ClassVar[str] = "S21.G00.62"

    date_de_fin_du_contrat: str | None = None  # 001: Date de fin du contrat (Date_JJMMAAAA_20)
    date_de_notification_de_la_rupture_de_contrat: str | None = (
        None  # 003: Date de notification de la rupture de contrat (Date_JJMMAAAA_20)
    )
    date_de_signature_de_la_convention_de_rupture: str | None = (
        None  # 004: Date de signature de la convention de rupture (Date_JJMMAAAA_20)
    )
    date_dengagement_de_la_procedure_de_licenciement: str | None = (
        None  # 005: Date d'engagement de la procédure de licenciement (Date_JJMMAAAA_20)
    )
    dernier_jour_travaille_et_paye_au_salaire_habituel: str | None = (
        None  # 006: Dernier jour travaillé et payé au salaire habituel (Date_JJMMAAAA_20)
    )
    maintien_de_l_affiliation_du_salarie_au_contrat_collectif: DSN_Remuneration_Pourboire | None = (
        None  # 016: Maintien de l’affiliation du salarié au contrat collectif (DSN_Remuneration_Pourboire)
    )
    modalite_de_declaration_de_la_fin_du_contrat_dusage: Modatite_FC | None = (
        None  # 017: Modalité de déclaration de la fin du contrat d'usage (Modatite_FC)
    )
    mois_de_la_dsn_mensuelle_portant_les_derniers_elements_declares_dans_le_fctu: str | None = (
        None  # 020: Mois de la DSN mensuelle portant les derniers éléments déclarés dans le FCTU (Date_JJMMAAAA_Mois_Declare)
    )
    montant_de_lindemnite_de_preavis_qui_aurait_ete_versee: str | None = (
        None  # 013: Montant de l'indemnité de préavis qui aurait été versée (Montant_ZNS_4_12_2)
    )
    motif_de_la_rupture_du_contrat: RAC_Rupture_Motif_DSN_phase_1 | None = (
        None  # 002: Motif de la rupture du contrat (RAC_Rupture_Motif_DSN_phase_1)
    )
    nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_csp: str | None = (
        None  # 011: Nombre de mois de préavis utilisés dans le cadre du calcul CSP (Taux_ZNS_4_4_2)
    )
    nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_pap: str | None = (
        None  # 018: Nombre de mois de préavis utilisés dans le cadre du calcul PAP (Numeric_4_5_Regex)
    )
    refus_de_la_proposition_dun_cdi_suite_a_cdd_ou_contrat_de_mission: DSN_Refus_CDI | None = (
        None  # 021: Refus de la proposition d'un CDI suite à CDD ou contrat de mission (DSN_Refus_CDI)
    )
    solde_de_conges_acquis_et_non_pris_enim: str | None = (
        None  # 019: Solde de congés acquis et non pris (ENIM) (Numeric_4_6_Regex)
    )
    statut_particulier_du_salarie: RAC_StatutParticulier_DSN_phase_1 | None = (
        None  # 014: Statut particulier du salarié (RAC_StatutParticulier_DSN_phase_1)
    )
    transaction_en_cours: N4DS_O_N | None = None  # 008: Transaction en cours (N4DS_O_N)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_fin_du_contrat": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "date_de_notification_de_la_rupture_de_contrat": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_signature_de_la_convention_de_rupture": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_dengagement_de_la_procedure_de_licenciement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "dernier_jour_travaille_et_paye_au_salaire_habituel": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_csp": (
            r"[0-9]{1}\\.[0-9]{2}",
            "",
        ),
        "montant_de_lindemnite_de_preavis_qui_aurait_ete_versee": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[0-9]|[1-9][0-9]))",
            "",
        ),
        "nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_pap": (
            r"[0-9]{1,2}\\.[0-9]{2}",
            "",
        ),
        "solde_de_conges_acquis_et_non_pris_enim": (r"[0-9]{1,3}\\.[0-9]{2}", "	"),
        "mois_de_la_dsn_mensuelle_portant_les_derniers_elements_declares_dans_le_fctu": (
            r"(01)(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }
    # Blocs enfants
    preavis_de_fin_de_contrat: list["S21_G00_63"] = field(
        default_factory=list
    )  # Préavis de fin de contrat (S21.G00.63) [1..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_fin_du_contrat = None
        self.date_de_notification_de_la_rupture_de_contrat = None
        self.date_de_signature_de_la_convention_de_rupture = None
        self.date_dengagement_de_la_procedure_de_licenciement = None
        self.dernier_jour_travaille_et_paye_au_salaire_habituel = None
        self.maintien_de_l_affiliation_du_salarie_au_contrat_collectif = None
        self.modalite_de_declaration_de_la_fin_du_contrat_dusage = None
        self.mois_de_la_dsn_mensuelle_portant_les_derniers_elements_declares_dans_le_fctu = None
        self.montant_de_lindemnite_de_preavis_qui_aurait_ete_versee = None
        self.motif_de_la_rupture_du_contrat = None
        self.nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_csp = None
        self.nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_pap = None
        self.refus_de_la_proposition_dun_cdi_suite_a_cdd_ou_contrat_de_mission = None
        self.solde_de_conges_acquis_et_non_pris_enim = None
        self.statut_particulier_du_salarie = None
        self.transaction_en_cours = None
        self.preavis_de_fin_de_contrat = []


@dataclass(init=False)
class S21_G00_63(DSNBlock):
    """Préavis de fin de contrat (S21.G00.63)"""

    block_id: ClassVar[str] = "S21.G00.63"

    date_de_debut_de_preavis: str | None = None  # 002: Date de début de préavis (Date_JJMMAAAA_20)
    date_de_fin_de_preavis: str | None = None  # 003: Date de fin de préavis (Date_JJMMAAAA_20)
    type_realisation_et_paiement_du_preavis: RAC_Preavis | None = (
        None  # 001: Type réalisation et paiement du préavis (RAC_Preavis)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_preavis": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "date_de_fin_de_preavis": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_preavis = None
        self.date_de_fin_de_preavis = None
        self.type_realisation_et_paiement_du_preavis = None


@dataclass(init=False)
class S21_G00_65(DSNBlock):
    """Autre suspension de l'exécution du contrat (S21.G00.65)"""

    block_id: ClassVar[str] = "S21.G00.65"

    date_de_debut_de_la_suspension: str | None = (
        None  # 002: Date de début de la suspension (Date_JJMMAAAA_20)
    )
    date_de_fin_de_la_suspension: str | None = (
        None  # 003: Date de fin de la suspension (Date_JJMMAAAA_20)
    )
    fp_position_de_detachement: str | None = (
        None  # 004: [FP] Position de détachement (FPPositionStatutaireHorsActivite)
    )
    motif_de_suspension: Motif_suspension | None = (
        None  # 001: Motif de suspension (Motif_suspension)
    )
    nombre_de_jours_ouvres_de_suspension: str | None = (
        None  # 005: Nombre de jours ouvrés de suspension (NumDec_0.50-99.50_Mult_0.50)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_la_suspension": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_la_suspension": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "nombre_de_jours_ouvres_de_suspension": (
            r"(0\\.50)|[1-9]\\.(00|50)|[1-9][0-9]\\.(00|50)",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_la_suspension = None
        self.date_de_fin_de_la_suspension = None
        self.fp_position_de_detachement = None
        self.motif_de_suspension = None
        self.nombre_de_jours_ouvres_de_suspension = None


@dataclass(init=False)
class S21_G00_70(DSNBlock):
    """Affiliation Prévoyance (S21.G00.70)"""

    block_id: ClassVar[str] = "S21.G00.70"

    code_option_retenue_par_le_salarie: str | None = (
        None  # 004: Code option retenue par le salarié (Type_Alphanumeric_1-30)
    )
    code_population_de_rattachement: str | None = (
        None  # 005: Code population de rattachement (Type_Alphanumeric_1-30)
    )
    date_de_debut_de_l_affiliation: str | None = (
        None  # 014: Date de début de l’affiliation (Date_JJMMAAAA_21)
    )
    date_de_fin_de_l_affiliation: str | None = (
        None  # 015: Date de fin de l’affiliation (Date_JJMMAAAA_21)
    )
    identifiant_technique_adhesion: str | None = (
        None  # 013: Identifiant technique Adhésion (Identifiant_Technique_Adhesion)
    )
    identifiant_technique_affiliation: str | None = (
        None  # 012: Identifiant technique Affiliation (Type_Alphanumeric_5-5_regex)
    )
    nombre_d_enfants_a_charge: str | None = (
        None  # 007: Nombre d’enfants à charge (DSN_Nombre_Enfants_Charge_Prevoyance)
    )
    nombre_dayants_droit_attaches_au_salarie_pour_le_contrat_prevoyance_mentionne: str | None = (
        None  # 009: Nombre d'ayants-droit attachés au salarié pour le contrat Prévoyance mentionné (DSN_Nombre_Ayant_Droit)
    )
    nombre_dayants_droit_autres_ascendants_collateraux: str | None = (
        None  # 010: Nombre d'ayants-droit autres (ascendants, collatéraux...) (Nombre_1_2)
    )
    nombre_dayants_droit_conjoint_concubin: str | None = (
        None  # 008: Nombre d'ayants-droit conjoint / concubin (Nombre_1_2)
    )
    nombre_denfants_ayants_droit: str | None = (
        None  # 011: Nombre d'enfants ayants-droit (Nombre_1_2)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nombre_d_enfants_a_charge": (r"[0]*(0|[1-9][0-9]*)", ""),
        "nombre_dayants_droit_conjoint_concubin": (r"[0]*(0|[1-9][0-9]*)", ""),
        "nombre_dayants_droit_attaches_au_salarie_pour_le_contrat_prevoyance_mentionne": (
            r"[0]*(0|[1-9][0-9]*)",
            "",
        ),
        "nombre_dayants_droit_autres_ascendants_collateraux": (r"[0]*(0|[1-9][0-9]*)", ""),
        "nombre_denfants_ayants_droit": (r"[0]*(0|[1-9][0-9]*)", ""),
        "identifiant_technique_affiliation": (r"[1-9][0-9]*", ""),
        "identifiant_technique_adhesion": (r"[1-9][0-9]*", ""),
        "date_de_debut_de_l_affiliation": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_l_affiliation": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }
    # Blocs enfants
    ayant_droit: list["S21_G00_73"] = field(default_factory=list)  # Ayant-droit (S21.G00.73) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_option_retenue_par_le_salarie = None
        self.code_population_de_rattachement = None
        self.date_de_debut_de_l_affiliation = None
        self.date_de_fin_de_l_affiliation = None
        self.identifiant_technique_adhesion = None
        self.identifiant_technique_affiliation = None
        self.nombre_d_enfants_a_charge = None
        self.nombre_dayants_droit_attaches_au_salarie_pour_le_contrat_prevoyance_mentionne = None
        self.nombre_dayants_droit_autres_ascendants_collateraux = None
        self.nombre_dayants_droit_conjoint_concubin = None
        self.nombre_denfants_ayants_droit = None
        self.ayant_droit = []


@dataclass(init=False)
class S21_G00_73(DSNBlock):
    """Ayant-droit (S21.G00.73)"""

    block_id: ClassVar[str] = "S21.G00.73"

    nir_ouvrant_droit_regime_de_base_maladie: (
        str  # 008: NIR ouvrant-droit régime de base maladie (DSN_NIR) [REQUIRED]
    )
    numero_dinscription_au_repertoire: (
        str  # 007: Numéro d'inscription au répertoire (DSN_NIR) [REQUIRED]
    )
    code_option: str | None = None  # 002: Code option (Type_Alphanumeric_1-30)
    code_organisme_daffiliation_a_lassurance_maladie: str | None = (
        None  # 010: Code organisme d'affiliation à l'assurance maladie (Type_Alphanumeric_1-30)
    )
    date_de_debut_de_rattachement_a_louvrant_droit: str | None = (
        None  # 004: Date de début de rattachement à l'ouvrant-droit (Date_JJMMAAAA)
    )
    date_de_fin_de_rattachement_a_louvrant_droit: str | None = (
        None  # 011: Date de fin de rattachement à l'ouvrant-droit (Date_JJMMAAAA_20)
    )
    date_de_naissance: str | None = None  # 005: Date de naissance (Date_JJMMAAAA)
    nom_de_famille: str | None = None  # 006: Nom de famille (Type_Alphanumeric_1-80)
    prenoms: str | None = None  # 009: Prénoms (Type_Alphanumeric_1-80)
    regime_local_alsace_moselle: DSN_Alsace_Moselle | None = (
        None  # 001: Régime local Alsace-Moselle (DSN_Alsace_Moselle)
    )
    type: DSN_Ayant_Droit_Type | None = None  # 003: Type (DSN_Ayant_Droit_Type)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_rattachement_a_louvrant_droit": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "date_de_naissance": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "numero_dinscription_au_repertoire": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
        "nir_ouvrant_droit_regime_de_base_maladie": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
        "date_de_fin_de_rattachement_a_louvrant_droit": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.nir_ouvrant_droit_regime_de_base_maladie = None
        self.numero_dinscription_au_repertoire = None
        self.code_option = None
        self.code_organisme_daffiliation_a_lassurance_maladie = None
        self.date_de_debut_de_rattachement_a_louvrant_droit = None
        self.date_de_fin_de_rattachement_a_louvrant_droit = None
        self.date_de_naissance = None
        self.nom_de_famille = None
        self.prenoms = None
        self.regime_local_alsace_moselle = None
        self.type = None


@dataclass(init=False)
class S21_G00_71(DSNBlock):
    """Retraite complémentaire (S21.G00.71)"""

    block_id: ClassVar[str] = "S21.G00.71"

    code_regime_retraite_complementaire: DSN_Code_Reg_Retraite_Comp | None = (
        None  # 002: Code régime Retraite Complémentaire (DSN_Code_Reg_Retraite_Comp)
    )
    # Blocs enfants
    affiliation_a_tort_a_un_regime_de_retraite_complementaire: list["S21_G00_72"] = field(
        default_factory=list
    )  # Affiliation à tort à un régime de retraite complémentaire (S21.G00.72) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_regime_retraite_complementaire = None
        self.affiliation_a_tort_a_un_regime_de_retraite_complementaire = []


@dataclass(init=False)
class S21_G00_72(DSNBlock):
    """Affiliation à tort à un régime de retraite complémentaire (S21.G00.72)"""

    block_id: ClassVar[str] = "S21.G00.72"

    code_regime_retraite_complementaire_declare_a_tort: DSN_Code_Reg_Retraite_Comp | None = (
        None  # 001: Code régime Retraite Complémentaire déclaré à tort (DSN_Code_Reg_Retraite_Comp)
    )

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_regime_retraite_complementaire_declare_a_tort = None


@dataclass(init=False)
class S21_G00_50(DSNBlock):
    """Versement individu (S21.G00.50)"""

    block_id: ClassVar[str] = "S21.G00.50"

    montant_net_verse: str  # 004: Montant net versé (Montant_ZNS_4_12_2_N_Z) [REQUIRED]
    remuneration_nette_fiscale: (
        str  # 002: Rémunération nette fiscale (Montant_ZNS_4_12_2_N_Z) [REQUIRED]
    )
    date_de_versement: str | None = None  # 001: Date de versement (Date_JJMMAAAA_20)
    identifiant_du_taux_de_prelevement_a_la_source: str | None = (
        None  # 008: Identifiant du taux de prélèvement à la source (Nombre_1_18)
    )
    mois_de_la_dsn_mensuelle_de_rattachement_des_elements_declares_dans_le_fctu: (
        DSN_VersementIndividu_MDsnMRFCTU | None
    ) = None  # 020: Mois de la DSN mensuelle de rattachement des éléments déclarés dans le FCTU (DSN_VersementIndividu_MDsnMRFCTU)
    montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale: (
        str | None
    ) = None  # 012: Montant de l’abattement sur la base fiscale (non déduit de la  rémunération nette fiscale) (Montant_ZNS_4_12_2_N_Z)
    montant_de_la_part_non_imposable_du_revenu: str | None = (
        None  # 011: Montant de la part non imposable du revenu (Montant_ZNS_4_12_2_N_Z)
    )
    montant_de_prelevement_a_la_source: str | None = (
        None  # 009: Montant de prélèvement à la source  (Montant_ZNS_4_12_2_Z)
    )
    montant_soumis_au_pas: str | None = None  # 013: Montant soumis au PAS (Montant_ZNS_4_12_2_Z)
    numero_de_versement: str | None = None  # 003: Numéro de versement (Nombre_ZNS_2_2)
    taux_de_prelevement_a_la_source: str | None = (
        None  # 006: Taux de prélèvement à la source (Taux_4_5)
    )
    type_du_taux_de_prelevement_a_la_source: Taux_Prelevement_Source | None = (
        None  # 007: Type du taux de prélèvement à la source (Taux_Prelevement_Source)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_versement": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "remuneration_nette_fiscale": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "numero_de_versement": (r"[0]*[1-9][0-9]*", ""),
        "montant_net_verse": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "taux_de_prelevement_a_la_source": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
        "identifiant_du_taux_de_prelevement_a_la_source": (r"-1|0|[1-9][0-9]{0,17}", ""),
        "montant_de_prelevement_a_la_source": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_de_la_part_non_imposable_du_revenu": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "montant_soumis_au_pas": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }
    # Blocs enfants
    remuneration: list["S21_G00_51"] = field(
        default_factory=list
    )  # Rémunération (S21.G00.51) [1..*]
    prime_gratification_et_indemnite: list["S21_G00_52"] = field(
        default_factory=list
    )  # Prime, gratification et indemnité (S21.G00.52) [0..*]
    autre_element_de_revenu_brut: list["S21_G00_54"] = field(
        default_factory=list
    )  # Autre élément de revenu brut (S21.G00.54) [0..*]
    regularisation_de_prelevement_a_la_source: list["S21_G00_56"] = field(
        default_factory=list
    )  # Régularisation de prélèvement à la source (S21.G00.56) [0..*]
    element_de_revenu_calcule_en_net: list["S21_G00_58"] = field(
        default_factory=list
    )  # Elément de revenu calculé en net (S21.G00.58) [0..*]
    base_assujettie: list["S21_G00_78"] = field(
        default_factory=list
    )  # Base assujettie (S21.G00.78) [0..*]
    periode_daffiliation_a_tort_a_un_regime_de_retraite_complementaire: list["S21_G00_83"] = field(
        default_factory=list
    )  # Période d'affiliation à tort à un régime de retraite complémentaire (S21.G00.83) [0..*]
    base_assujettie_declaree_a_tort_pour_un_regime_de_base_risque_maladie_at_mp_ou_vieillesse: list[
        "S21_G00_95"
    ] = field(
        default_factory=list
    )  # Base assujettie déclarée à tort pour un régime de base risque maladie, AT/MP ou vieillesse (S21.G00.95) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.montant_net_verse = None
        self.remuneration_nette_fiscale = None
        self.date_de_versement = None
        self.identifiant_du_taux_de_prelevement_a_la_source = None
        self.mois_de_la_dsn_mensuelle_de_rattachement_des_elements_declares_dans_le_fctu = None
        self.montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale = None
        self.montant_de_la_part_non_imposable_du_revenu = None
        self.montant_de_prelevement_a_la_source = None
        self.montant_soumis_au_pas = None
        self.numero_de_versement = None
        self.taux_de_prelevement_a_la_source = None
        self.type_du_taux_de_prelevement_a_la_source = None
        self.remuneration = []
        self.prime_gratification_et_indemnite = []
        self.autre_element_de_revenu_brut = []
        self.regularisation_de_prelevement_a_la_source = []
        self.element_de_revenu_calcule_en_net = []
        self.base_assujettie = []
        self.periode_daffiliation_a_tort_a_un_regime_de_retraite_complementaire = []
        self.base_assujettie_declaree_a_tort_pour_un_regime_de_base_risque_maladie_at_mp_ou_vieillesse = []


@dataclass(init=False)
class S21_G00_51(DSNBlock):
    """Rémunération (S21.G00.51)"""

    block_id: ClassVar[str] = "S21.G00.51"

    date_de_debut_de_periode_de_paie: str | None = (
        None  # 001: Date de début de période de paie (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_paie: str | None = (
        None  # 002: Date de fin de période de paie (Date_JJMMAAAA_20)
    )
    fp_taux_de_remuneration_de_la_situation_administrative: str | None = (
        None  # 014: [FP] Taux de rémunération de la situation administrative (Taux_4_6_100)
    )
    montant: str | None = None  # 013: Montant (Montant_ZNS_4_11_2_N_Z)
    nombre_dheures: str | None = None  # 012: Nombre d'heures (Quantite_ZNS_4_7_2_N_Z)
    numero_du_contrat: str | None = None  # 010: Numéro du contrat (Type_Alphanumeric_5-20)
    taux_de_conduite_centrale_nucleaire: str | None = (
        None  # 015: Taux de conduite centrale nucléaire (Taux_ZNS10max_4_5_2_Z)
    )
    taux_de_majoration: str | None = None  # 016: Taux de majoration (Taux_4_5)
    taux_de_majoration_ex_apprenti_ex_eleve: str | None = (
        None  # 020: Taux de majoration ex-apprenti/ex-élève (Numeric_4_5_Regex)
    )
    taux_de_remuneration_cotisee: str | None = (
        None  # 019: Taux de rémunération cotisée (Nombre_Regex_4-6)
    )
    type: DSN_Renumeration_Type | None = None  # 011: Type (DSN_Renumeration_Type)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_de_paie": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_paie": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "nombre_dheures": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "fp_taux_de_remuneration_de_la_situation_administrative": (
            r"[0-9]{1,2}\\.[0-9]{2}|100\\.00",
            "",
        ),
        "taux_de_conduite_centrale_nucleaire": (r"([0-9]{1}\\.[0-9]{2})|(10\\.00)", ""),
        "taux_de_majoration": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
        "taux_de_remuneration_cotisee": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "taux_de_majoration_ex_apprenti_ex_eleve": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
    }
    # Blocs enfants
    activite: list["S21_G00_53"] = field(default_factory=list)  # Activité (S21.G00.53) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_periode_de_paie = None
        self.date_de_fin_de_periode_de_paie = None
        self.fp_taux_de_remuneration_de_la_situation_administrative = None
        self.montant = None
        self.nombre_dheures = None
        self.numero_du_contrat = None
        self.taux_de_conduite_centrale_nucleaire = None
        self.taux_de_majoration = None
        self.taux_de_majoration_ex_apprenti_ex_eleve = None
        self.taux_de_remuneration_cotisee = None
        self.type = None
        self.activite = []


@dataclass(init=False)
class S21_G00_53(DSNBlock):
    """Activité (S21.G00.53)"""

    block_id: ClassVar[str] = "S21.G00.53"

    mesure: str | None = None  # 002: Mesure (Quantite_ZNS_4_8_2_N_Z)
    type: DSN_Type_Activite | None = None  # 001: Type (DSN_Type_Activite)
    unite_de_mesure: DSN_Unite_Mesure | None = None  # 003: Unité de mesure (DSN_Unite_Mesure)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "mesure": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.mesure = None
        self.type = None
        self.unite_de_mesure = None


@dataclass(init=False)
class S21_G00_52(DSNBlock):
    """Prime, gratification et indemnité (S21.G00.52)"""

    block_id: ClassVar[str] = "S21.G00.52"

    date_de_debut_de_la_periode_de_rattachement: str | None = (
        None  # 003: Date de début de la période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_la_periode_de_rattachement: str | None = (
        None  # 004: Date de fin de la période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_versement_dorigine: str | None = (
        None  # 007: Date de versement d'origine (Date_JJMMAAAA_20)
    )
    montant: str | None = None  # 002: Montant (Montant_ZNS_4_12_2_N)
    numero_du_contrat: str | None = None  # 006: Numéro du contrat (Type_Alphanumeric_5-20)
    type: Prime_DSN_phase_1 | None = None  # 001: Type (Prime_DSN_phase_1)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant": (r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))", ""),
        "date_de_debut_de_la_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_la_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_versement_dorigine": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_la_periode_de_rattachement = None
        self.date_de_fin_de_la_periode_de_rattachement = None
        self.date_de_versement_dorigine = None
        self.montant = None
        self.numero_du_contrat = None
        self.type = None


@dataclass(init=False)
class S21_G00_54(DSNBlock):
    """Autre élément de revenu brut (S21.G00.54)"""

    block_id: ClassVar[str] = "S21.G00.54"

    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 003: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 004: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    montant: str | None = None  # 002: Montant (Montant_ZNS_4_14_2_N)
    numero_de_contrat: str | None = None  # 005: Numéro de contrat (Type_Alphanumeric_5-20)
    type: DSN_Autre_Element_Revenu_Type | None = None  # 001: Type (DSN_Autre_Element_Revenu_Type)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant": (r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))", ""),
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.montant = None
        self.numero_de_contrat = None
        self.type = None


@dataclass(init=False)
class S21_G00_56(DSNBlock):
    """Régularisation de prélèvement à la source (S21.G00.56)"""

    block_id: ClassVar[str] = "S21.G00.56"

    mois_de_l_erreur: str | None = None  # 001: Mois de l’erreur (Date_MMAAAA)
    montant_de_la_regularisation_du_prelevement_a_la_source: str | None = (
        None  # 007: Montant de la régularisation du prélèvement à la source (Montant_ZNS_4_12_2_N_Z)
    )
    montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur: str | None = (
        None  # 015: Montant soumis au prélèvement à la source déclaré le mois de l'erreur (Montant_ZNS_4_12_2_N_Z_quepositif)
    )
    regularisation_de_la_remuneration_nette_fiscale: str | None = (
        None  # 003: Régularisation de la rémunération nette fiscale (Montant_ZNS_4_12_2_N_Z)
    )
    regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale: (
        str | None
    ) = None  # 009: Régularisation du montant de l’abattement sur la base fiscale (non déduit de la  rémunération nette fiscale) (Montant_ZNS_4_12_2_N_Z)
    regularisation_du_montant_de_la_part_non_imposable_du_revenu: str | None = (
        None  # 008: Régularisation du montant de la part non imposable du revenu (Montant_ZNS_4_12_2_N_Z)
    )
    regularisation_du_montant_soumis_au_pas: str | None = (
        None  # 010: Régularisation du montant soumis au PAS (Montant_ZNS_4_12_2_N_Z)
    )
    regularisation_du_taux_de_prelevement_a_la_source: str | None = (
        None  # 005: Régularisation du taux de prélèvement à la source (Taux_pos_neg_4_6)
    )
    remuneration_nette_fiscale_declaree_le_mois_de_l_erreur: str | None = (
        None  # 004: Rémunération nette fiscale déclarée le mois de l’erreur (Montant_ZNS_4_12_2_N_Z)
    )
    taux_declare_le_mois_de_l_erreur: str | None = (
        None  # 006: Taux déclaré le mois de l’erreur (Taux_4_5)
    )
    type_d_erreur: Type_erreurs_Regul_PAS | None = (
        None  # 002: Type d’erreur (Type_erreurs_Regul_PAS)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "mois_de_l_erreur": (r"(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "regularisation_de_la_remuneration_nette_fiscale": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "remuneration_nette_fiscale_declaree_le_mois_de_l_erreur": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_taux_de_prelevement_a_la_source": (
            r"-?(([0-9]{1,2}\\.[1-9][0-9])|([0-9]{1,2}\\.[0-9][1-9])|([0-9][1-9]\\.[0-9]{2})|([1-9][0-9]\\.[0-9]{2})|([0-9]\\.[1-9][0-9])|([0-9]\\.[0-9][1-9])|([1-9]\\.[0-9]{2}))",
            "",
        ),
        "taux_declare_le_mois_de_l_erreur": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
        "montant_de_la_regularisation_du_prelevement_a_la_source": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_montant_de_la_part_non_imposable_du_revenu": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_montant_soumis_au_pas": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur": (
            r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.mois_de_l_erreur = None
        self.montant_de_la_regularisation_du_prelevement_a_la_source = None
        self.montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur = None
        self.regularisation_de_la_remuneration_nette_fiscale = None
        self.regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale = None
        self.regularisation_du_montant_de_la_part_non_imposable_du_revenu = None
        self.regularisation_du_montant_soumis_au_pas = None
        self.regularisation_du_taux_de_prelevement_a_la_source = None
        self.remuneration_nette_fiscale_declaree_le_mois_de_l_erreur = None
        self.taux_declare_le_mois_de_l_erreur = None
        self.type_d_erreur = None


@dataclass(init=False)
class S21_G00_58(DSNBlock):
    """Elément de revenu calculé en net (S21.G00.58)"""

    block_id: ClassVar[str] = "S21.G00.58"

    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 001: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 002: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    montant: str | None = None  # 004: Montant (Numeric_4_12)
    type: NewEnumeration299 | None = None  # 003: Type (NewEnumeration299)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "montant": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.montant = None
        self.type = None


@dataclass(init=False)
class S21_G00_78(DSNBlock):
    """Base assujettie (S21.G00.78)"""

    block_id: ClassVar[str] = "S21.G00.78"

    code_de_base_assujettie: DSN_Code_Base_Assujettie | None = (
        None  # 001: Code de base assujettie (DSN_Code_Base_Assujettie)
    )
    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 002: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 003: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 007: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    identifiant_technique_affiliation: str | None = (
        None  # 005: Identifiant technique Affiliation (Type_Alphanumeric_1_3_regex)
    )
    montant: str | None = None  # 004: Montant (Montant_ZNS_4_11_2_N_Z)
    numero_du_contrat: str | None = None  # 006: Numéro du contrat (Type_Alphanumeric_5-20)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "montant": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "identifiant_technique_affiliation": (r"[1-9][0-9]*", ""),
    }
    # Blocs enfants
    composant_de_base_assujettie: list["S21_G00_79"] = field(
        default_factory=list
    )  # Composant de base assujettie (S21.G00.79) [0..*]
    cotisation_individuelle: list["S21_G00_81"] = field(
        default_factory=list
    )  # Cotisation individuelle (S21.G00.81) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_base_assujettie = None
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.identifiant_technique_affiliation = None
        self.montant = None
        self.numero_du_contrat = None
        self.composant_de_base_assujettie = []
        self.cotisation_individuelle = []


@dataclass(init=False)
class S21_G00_79(DSNBlock):
    """Composant de base assujettie (S21.G00.79)"""

    block_id: ClassVar[str] = "S21.G00.79"

    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 005: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    montant_de_composant_de_base_assujettie: str | None = (
        None  # 004: Montant de composant de base assujettie (Montant_ZNS_4_14_N_Z)
    )
    type_de_composant_de_base_assujettie: DSN_Enum_Complement_Base_Assujettie_2_2 | None = (
        None  # 001: Type de composant de base assujettie (DSN_Enum_Complement_Base_Assujettie_2_2)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_de_composant_de_base_assujettie": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.montant_de_composant_de_base_assujettie = None
        self.type_de_composant_de_base_assujettie = None


@dataclass(init=False)
class S21_G00_81(DSNBlock):
    """Cotisation individuelle (S21.G00.81)"""

    block_id: ClassVar[str] = "S21.G00.81"

    code_de_cotisation: DSN_Ref_Code_Cotis | None = (
        None  # 001: Code de cotisation (DSN_Ref_Code_Cotis)
    )
    code_insee_commune: str | None = None  # 005: Code INSEE commune (DSN_CodeINSEECommune_Postal)
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 006: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    identifiant_organisme_de_protection_sociale: str | None = (
        None  # 002: Identifiant Organisme de Protection Sociale (DSN_IdOPS_bis_2_14)
    )
    montant_dassiette: str | None = None  # 003: Montant d'assiette (Montant_ZNS_4_14_2_N_Z)
    montant_de_cotisation: str | None = None  # 004: Montant de cotisation (Montant_ZNS_4_14_N_Z)
    taux_de_cotisation: str | None = None  # 007: Taux de cotisation (NumDec_0.000-100.000)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_dassiette": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_de_cotisation": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "taux_de_cotisation": (r"[0]?([0-9]{1,2}\\.[0-9]{2,3}|100\\.000|100\\.00)", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_cotisation = None
        self.code_insee_commune = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.identifiant_organisme_de_protection_sociale = None
        self.montant_dassiette = None
        self.montant_de_cotisation = None
        self.taux_de_cotisation = None


@dataclass(init=False)
class S21_G00_83(DSNBlock):
    """Période d'affiliation à tort à un régime de retraite complémentaire (S21.G00.83)"""

    block_id: ClassVar[str] = "S21.G00.83"

    date_de_debut_de_periode_declaree_a_tort: str | None = (
        None  # 001: Date de début de période déclarée à tort (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_declaree_a_tort: str | None = (
        None  # 002: Date de fin de période déclarée à tort (Date_JJMMAAAA_20)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_declaree_a_tort": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_declaree_a_tort": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
    }
    # Blocs enfants
    base_assujettie_declaree_a_tort_pour_un_regime_de_retraite_complementaire: list[
        "S21_G00_84"
    ] = field(
        default_factory=list
    )  # Base assujettie déclarée à tort pour un régime de retraite complémentaire (S21.G00.84) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_debut_de_periode_declaree_a_tort = None
        self.date_de_fin_de_periode_declaree_a_tort = None
        self.base_assujettie_declaree_a_tort_pour_un_regime_de_retraite_complementaire = []


@dataclass(init=False)
class S21_G00_84(DSNBlock):
    """Base assujettie déclarée à tort pour un régime de retraite complémentaire (S21.G00.84)"""

    block_id: ClassVar[str] = "S21.G00.84"

    code_de_base_assujettie_declaree_a_tort: DSN_Code_Base_Assujettie_Declare_Tort_2 | None = (
        None  # 001: Code de base assujettie déclarée à tort (DSN_Code_Base_Assujettie_Declare_Tort_2)
    )
    date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort: str | None = (
        None  # 002: Date de début de période de rattachement de la base déclarée à tort (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort: str | None = (
        None  # 003: Date de fin de période de rattachement de la base déclarée à tort (Date_JJMMAAAA_20)
    )
    montant_declare_a_tort: str | None = None  # 004: Montant déclaré à tort (Montant_4_11)
    numero_du_contrat_rattache_a_la_base_assujettie_declaree_a_tort: str | None = (
        None  # 005: Numéro du contrat rattaché à la base assujettie déclarée à tort (Type_Alphanumeric_5-20)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "montant_declare_a_tort": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_base_assujettie_declaree_a_tort = None
        self.date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort = None
        self.date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort = None
        self.montant_declare_a_tort = None
        self.numero_du_contrat_rattache_a_la_base_assujettie_declaree_a_tort = None


@dataclass(init=False)
class S21_G00_95(DSNBlock):
    """Base assujettie déclarée à tort pour un régime de base risque maladie, AT/MP ou vieillesse (S21.G00.95)"""

    block_id: ClassVar[str] = "S21.G00.95"

    code_de_base_assujettie_declaree_a_tort: DSN_Code_Base_Assujettie_Declare_Tort_1 | None = (
        None  # 001: Code de base assujettie déclarée à tort (DSN_Code_Base_Assujettie_Declare_Tort_1)
    )
    date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort: str | None = (
        None  # 002: Date de début de période de rattachement de la base déclarée à tort (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort: str | None = (
        None  # 003: Date de fin de période de rattachement de la base déclarée à tort (Date_JJMMAAAA_20)
    )
    montant_declare_a_tort: str | None = None  # 004: Montant déclaré à tort (Montant_4_11)
    numero_du_contrat_rattache_a_la_base_assujettie_declaree_a_tort: str | None = (
        None  # 005: Numéro du contrat rattaché à la base assujettie déclarée à tort (Type_Alphanumeric_5-20)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "montant_declare_a_tort": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_base_assujettie_declaree_a_tort = None
        self.date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort = None
        self.date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort = None
        self.montant_declare_a_tort = None
        self.numero_du_contrat_rattache_a_la_base_assujettie_declaree_a_tort = None


@dataclass(init=False)
class S21_G00_86(DSNBlock):
    """Ancienneté (S21.G00.86)"""

    block_id: ClassVar[str] = "S21.G00.86"

    numero_du_contrat: str | None = None  # 005: Numéro du contrat (Type_Alphanumeric_5-20)
    type: DSN_Anciennete_Type | None = None  # 001: Type (DSN_Anciennete_Type)
    unite_de_mesure: DSN_Anciennete_Unite_Mesure | None = (
        None  # 002: Unité de mesure (DSN_Anciennete_Unite_Mesure)
    )
    valeur: str | None = None  # 003: Valeur (Nombre_1_5)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "valeur": (r"[0-9]*", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.numero_du_contrat = None
        self.type = None
        self.unite_de_mesure = None
        self.valeur = None


@dataclass(init=False)
class S21_G00_98(DSNBlock):
    """Saisie administrative à tiers détenteur (S21.G00.98)"""

    block_id: ClassVar[str] = "S21.G00.98"

    etat_de_prise_en_compte_de_la_satd: DSN_SaisieAdmin_Etat_SATD | None = (
        None  # 002: Etat de prise en compte de la SATD (DSN_SaisieAdmin_Etat_SATD)
    )
    identifiant_de_la_satd: str | None = (
        None  # 001: Identifiant de la SATD (Type_Alphanumeric_1-40)
    )
    mois_de_l_erreur: str | None = None  # 004: Mois de l’erreur (Date_MMAAAA)
    montant: str | None = None  # 003: Montant (Montant_ZNS_1_8_2_0autorise)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "mois_de_l_erreur": (r"(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.etat_de_prise_en_compte_de_la_satd = None
        self.identifiant_de_la_satd = None
        self.mois_de_l_erreur = None
        self.montant = None


@dataclass(init=False)
class S21_G00_85(DSNBlock):
    """Lieu de travail ou établissement utilisateur (S21.G00.85)"""

    block_id: ClassVar[str] = "S21.G00.85"

    code_pays: str  # 006: Code Pays (ISO_3166-1-A2_Pays) [REQUIRED]
    code_apet: str | None = None  # 002: Code APET (Insee_Naf_2008_4)
    code_de_distribution_a_letranger: str | None = (
        None  # 007: Code de distribution à l'étranger (N4DS_Adresse)
    )
    code_insee_commune: str | None = None  # 011: Code INSEE commune (DSN_CodeINSEECommune)
    code_postal: str | None = None  # 004: Code postal (La_Poste_Hexaposte)
    complement_de_la_localisation_de_la_construction: str | None = (
        None  # 008: Complément de la localisation de la construction (N4DS_Adresse)
    )
    identifiant_du_lieu_de_travail_ou_de_letablissement_utilisateur: str | None = (
        None  # 001: Identifiant du lieu de travail ou de l'établissement utilisateur (DSN_Identifiant_Lieu_Travail)
    )
    localite: str | None = None  # 005: Localité (N4DS_Adresse_Localite)
    nature_juridique: DSN_Nature_Juridique | None = (
        None  # 010: Nature juridique (DSN_Nature_Juridique)
    )
    numero_extension_nature_libelle_de_voie: str | None = (
        None  # 003: Numéro, extension, nature, libellé de voie (N4DS_Adresse)
    )
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 009: Service de distribution, complément de localisation de la voie (N4DS_Adresse)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "localite": (r"[A-Za-z0-9\\s]+", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_pays = None
        self.code_apet = None
        self.code_de_distribution_a_letranger = None
        self.code_insee_commune = None
        self.code_postal = None
        self.complement_de_la_localisation_de_la_construction = None
        self.identifiant_du_lieu_de_travail_ou_de_letablissement_utilisateur = None
        self.localite = None
        self.nature_juridique = None
        self.numero_extension_nature_libelle_de_voie = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None


@dataclass(init=False)
class S89_G00_32(DSNBlock):
    """Bénéficiaire des honoraires (S89.G00.32)"""

    block_id: ClassVar[str] = "S89.G00.32"

    nom_du_beneficiaire_des_honoraires: (
        str  # 002: Nom du bénéficiaire des honoraires (Type_Alphanumeric_1-80) [REQUIRED]
    )
    prenom_du_beneficiaire_des_honoraires: (
        str  # 003: Prénom du bénéficiaire des honoraires (Type_Alphanumeric_1-40) [REQUIRED]
    )
    raison_sociale_du_beneficiaire_des_honoraires: str  # 006: Raison sociale du bénéficiaire des honoraires (Type_Alphanumeric_1-60) [REQUIRED]
    code_de_distribution_a_letranger: str | None = (
        None  # 014: Code de distribution à l'étranger (Type_Alphanumeric_1-50)
    )
    code_insee_de_la_commune: str | None = (
        None  # 009: Code INSEE de la commune (DSN_CodeINSEECommune_Postal)
    )
    code_pays: str | None = None  # 013: Code pays (ISO_3166-1-A2_Pays)
    code_postal: str | None = None  # 011: Code postal (La_Poste_Hexaposte)
    code_taux_reduit_ou_dispense_de_retenue_a_la_source: (
        DSN_VehiculeTechnique_Code_Taux_Reduit_Dispense | None
    ) = None  # 015: Code taux réduit ou dispense de retenue à la source (DSN_VehiculeTechnique_Code_Taux_Reduit_Dispense)
    complement_de_localisation_de_la_construction: str | None = (
        None  # 007: Complément de localisation de la construction (Type_Alphanumeric_1-50)
    )
    localite: str | None = None  # 012: Localité (N4DS_Adresse_Localite)
    millesime_de_rattachement: str | None = (
        None  # 017: Millésime de rattachement (Annee_21Siecle_plus)
    )
    montant_tva_droits_dauteurs: str | None = (
        None  # 016: Montant TVA droits d'auteurs (Nombre_4_12_regex2)
    )
    nic_du_beneficiaire_des_honoraires: str | None = (
        None  # 005: Nic du bénéficiaire des honoraires (Type_Alphanumeric_5-5_regex2)
    )
    numero_extension_nature_et_libelle_de_la_voie: str | None = (
        None  # 008: Numéro, extension, nature et libellé de la voie (Type_Alphanumeric_1-50)
    )
    profession_ou_qualite: str | None = None  # 001: Profession ou qualité (Type_Alphanumeric_1-40)
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 010: Service de distribution, complément de localisation de la voie (Type_Alphanumeric_1-50)
    )
    siren_du_beneficiaire_des_honoraires: str | None = (
        None  # 004: Siren du bénéficiaire des honoraires (Type_Alphanumeric_9-9_regex)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "siren_du_beneficiaire_des_honoraires": (r"[0-9]*[1-9][0-9]*", ""),
        "nic_du_beneficiaire_des_honoraires": (r"[0-9]*[1-9][0-9]*", ""),
        "localite": (r"[A-Za-z0-9\\s]+", ""),
        "montant_tva_droits_dauteurs": (
            r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "millesime_de_rattachement": (r"2([0-9]{3})", ""),
    }
    # Blocs enfants
    avantages_en_nature: list["S89_G00_33"] = field(
        default_factory=list
    )  # Avantages en nature (S89.G00.33) [0..*]
    prise_en_charge_des_indemnites: list["S89_G00_35"] = field(
        default_factory=list
    )  # Prise en charge des indemnités (S89.G00.35) [0..*]
    remunerations: list["S89_G00_43"] = field(
        default_factory=list
    )  # Rémunérations (S89.G00.43) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.nom_du_beneficiaire_des_honoraires = None
        self.prenom_du_beneficiaire_des_honoraires = None
        self.raison_sociale_du_beneficiaire_des_honoraires = None
        self.code_de_distribution_a_letranger = None
        self.code_insee_de_la_commune = None
        self.code_pays = None
        self.code_postal = None
        self.code_taux_reduit_ou_dispense_de_retenue_a_la_source = None
        self.complement_de_localisation_de_la_construction = None
        self.localite = None
        self.millesime_de_rattachement = None
        self.montant_tva_droits_dauteurs = None
        self.nic_du_beneficiaire_des_honoraires = None
        self.numero_extension_nature_et_libelle_de_la_voie = None
        self.profession_ou_qualite = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None
        self.siren_du_beneficiaire_des_honoraires = None
        self.avantages_en_nature = []
        self.prise_en_charge_des_indemnites = []
        self.remunerations = []


@dataclass(init=False)
class S89_G00_33(DSNBlock):
    """Avantages en nature (S89.G00.33)"""

    block_id: ClassVar[str] = "S89.G00.33"

    code_type_avantage_en_nature: DSN_VehiculeTechnique_Code_Type_Avantage_Nature | None = (
        None  # 001: Code type avantage en nature (DSN_VehiculeTechnique_Code_Type_Avantage_Nature)
    )
    montant_avantage_en_nature: str | None = (
        None  # 002: Montant avantage en nature (Nombre_4_12_regex2)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_avantage_en_nature": (
            r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_type_avantage_en_nature = None
        self.montant_avantage_en_nature = None


@dataclass(init=False)
class S89_G00_35(DSNBlock):
    """Prise en charge des indemnités (S89.G00.35)"""

    block_id: ClassVar[str] = "S89.G00.35"

    code_modalite_de_prise_en_charge_des_indemnites: (
        DSN_VehiculeTechnique_Code_Modalite_Indemnite | None
    ) = None  # 001: Code modalité de prise en charge des indemnités (DSN_VehiculeTechnique_Code_Modalite_Indemnite)
    montant_de_lindemnite: str | None = None  # 002: Montant de l'indemnité (Nombre_4_12_regex2)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_de_lindemnite": (r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_modalite_de_prise_en_charge_des_indemnites = None
        self.montant_de_lindemnite = None


@dataclass(init=False)
class S89_G00_43(DSNBlock):
    """Rémunérations (S89.G00.43)"""

    block_id: ClassVar[str] = "S89.G00.43"

    code_type_de_la_remuneration: DSN_Code | None = (
        None  # 001: Code type de la rémunération (DSN_Code)
    )
    montant_de_la_remuneration: str | None = (
        None  # 002: Montant de la rémunération (Nombre_4_12_regex2)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_de_la_remuneration": (
            r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_type_de_la_remuneration = None
        self.montant_de_la_remuneration = None


@dataclass(init=False)
class S89_G00_67(DSNBlock):
    """Droit supplémentaire acquis au titre des régimes de retraite supplémentaire à prestations définies (S89.G00.67)"""

    block_id: ClassVar[str] = "S89.G00.67"

    nir: str  # 001: NIR (Identifiant_Nir_13) [REQUIRED]
    numero_technique_temporaire: (
        str  # 002: Numéro technique temporaire (Type_Alphanumeric_11_40) [REQUIRED]
    )
    millesime_de_rattachement: str | None = (
        None  # 005: Millésime de rattachement (Annee_21Siecle_plus)
    )
    montant_de_droit_supplementaire_acquis: str | None = (
        None  # 003: Montant de droit supplémentaire acquis (Montant_4_11)
    )
    pourcentage_de_droit_supplementaire_acquis: str | None = (
        None  # 004: Pourcentage de droit supplémentaire acquis (Numeric_4_5_Regex)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nir": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
        "montant_de_droit_supplementaire_acquis": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "pourcentage_de_droit_supplementaire_acquis": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
        "millesime_de_rattachement": (r"2([0-9]{3})", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.nir = None
        self.numero_technique_temporaire = None
        self.millesime_de_rattachement = None
        self.montant_de_droit_supplementaire_acquis = None
        self.pourcentage_de_droit_supplementaire_acquis = None


@dataclass(init=False)
class S89_G00_87(DSNBlock):
    """Actions gratuites (S89.G00.87)"""

    block_id: ClassVar[str] = "S89.G00.87"

    numero_dinscription_au_repertoire: (
        str  # 007: Numéro d'inscription au répertoire (Identifiant_Nir_13) [REQUIRED]
    )
    numero_technique_temporaire: (
        str  # 008: Numéro technique temporaire (Type_Alphanumeric_11_40) [REQUIRED]
    )
    code_contexte: DSN_ActionsGratuites_Code_Contexte | None = (
        None  # 001: Code contexte (DSN_ActionsGratuites_Code_Contexte)
    )
    date_dacquisition_definitive: str | None = (
        None  # 006: Date d'acquisition définitive (Date_JJMMAAAA_20)
    )
    date_dattribution: str | None = None  # 005: Date d'attribution (Date_JJMMAAAA)
    fraction_du_gain_dacquisition_de_source_francaise: str | None = (
        None  # 004: Fraction du gain d'acquisition de source française (Nombre_4_6_regexp2)
    )
    nombre_dactions: str | None = None  # 002: Nombre d'actions (Nombre_1_8_regex)
    valeur_unitaire_de_laction: str | None = (
        None  # 003: Valeur unitaire de l'action (Nombre_4_12_regex)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nombre_dactions": (r"-?[0]*(0|[1-9][0-9]*)", ""),
        "valeur_unitaire_de_laction": (r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))", ""),
        "fraction_du_gain_dacquisition_de_source_francaise": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})",
            "",
        ),
        "date_dattribution": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "date_dacquisition_definitive": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "numero_dinscription_au_repertoire": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.numero_dinscription_au_repertoire = None
        self.numero_technique_temporaire = None
        self.code_contexte = None
        self.date_dacquisition_definitive = None
        self.date_dattribution = None
        self.fraction_du_gain_dacquisition_de_source_francaise = None
        self.nombre_dactions = None
        self.valeur_unitaire_de_laction = None


@dataclass(init=False)
class S89_G00_88(DSNBlock):
    """Options sur titres (stock options) (S89.G00.88)"""

    block_id: ClassVar[str] = "S89.G00.88"

    numero_dinscription_au_repertoire: (
        str  # 008: Numéro d'inscription au répertoire (Identifiant_Nir_13) [REQUIRED]
    )
    numero_technique_temporaire: (
        str  # 009: Numéro technique temporaire (Type_Alphanumeric_11_40) [REQUIRED]
    )
    code_contexte: DSN_Code_Contexte | None = None  # 001: Code contexte (DSN_Code_Contexte)
    date_dattribution: str | None = None  # 006: Date d'attribution (Date_JJMMAAAA)
    date_de_levee_de_loption: str | None = None  # 007: Date de levée de l'option (Date_JJMMAAAA)
    fraction_du_gain_de_levee_doption_de_source_francaise: str | None = (
        None  # 005: Fraction du gain de levée d'option de source française (Nombre_4_6_regexp)
    )
    nombre_doptions: str | None = None  # 002: Nombre d'options (Nombre_1_8_regex)
    prix_de_souscription_de_laction: str | None = (
        None  # 004: Prix de souscription de l'action (Nombre_4_12_regex2)
    )
    valeur_unitaire_de_laction: str | None = (
        None  # 003: Valeur unitaire de l'action (Nombre_4_12_regex)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nombre_doptions": (r"-?[0]*(0|[1-9][0-9]*)", ""),
        "valeur_unitaire_de_laction": (r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))", ""),
        "prix_de_souscription_de_laction": (
            r"-?[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "fraction_du_gain_de_levee_doption_de_source_francaise": (
            r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "date_dattribution": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "date_de_levee_de_loption": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}",
            "",
        ),
        "numero_dinscription_au_repertoire": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.numero_dinscription_au_repertoire = None
        self.numero_technique_temporaire = None
        self.code_contexte = None
        self.date_dattribution = None
        self.date_de_levee_de_loption = None
        self.fraction_du_gain_de_levee_doption_de_source_francaise = None
        self.nombre_doptions = None
        self.prix_de_souscription_de_laction = None
        self.valeur_unitaire_de_laction = None


@dataclass(init=False)
class S89_G00_89(DSNBlock):
    """Bons de souscription de parts de créateur d'entreprise (BSPCE) (S89.G00.89)"""

    block_id: ClassVar[str] = "S89.G00.89"

    numero_dinscription_au_repertoire: (
        str  # 007: Numéro d'inscription au répertoire (Identifiant_Nir_13) [REQUIRED]
    )
    numero_technique_temporaire: (
        str  # 008: Numéro technique temporaire (Type_Alphanumeric_11_40) [REQUIRED]
    )
    date_dacquisition_des_titres: str | None = (
        None  # 005: Date d'acquisition des titres (Date_JJMMAAAA_20)
    )
    duree_dexercice_de_lactivite_du_beneficiaire_dans_lentreprise: str | None = (
        None  # 006: Durée d'exercice de l'activité du bénéficiaire dans l'entreprise (Nombre_1_3_regex)
    )
    fraction_du_gain_de_source_francaise: str | None = (
        None  # 004: Fraction du gain de source française (Nombre_4_6_regexp2)
    )
    nombre_de_titres: str | None = None  # 001: Nombre de titres (Nombre_1_8_regex)
    prix_dacquisition_des_titres: str | None = (
        None  # 002: Prix d'acquisition des titres (Nombre_4_12_regex)
    )
    valeur_unitaire_des_titres_au_jour_de_lexercice_des_bons: str | None = (
        None  # 003: Valeur unitaire des titres au jour de l'exercice des bons (Nombre_4_12_regex)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nombre_de_titres": (r"-?[0]*(0|[1-9][0-9]*)", ""),
        "prix_dacquisition_des_titres": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "valeur_unitaire_des_titres_au_jour_de_lexercice_des_bons": (
            r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.(0[1-9]|[1-9][0-9]))",
            "",
        ),
        "fraction_du_gain_de_source_francaise": (r"[0]*([1-9][0-9]*\\.[0-9]{2}|0\\.[0-9]{2})", ""),
        "date_dacquisition_des_titres": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "duree_dexercice_de_lactivite_du_beneficiaire_dans_lentreprise": (r"[0]*[1-9][0-9]*", ""),
        "numero_dinscription_au_repertoire": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})|([1-2][9]{12})",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.numero_dinscription_au_repertoire = None
        self.numero_technique_temporaire = None
        self.date_dacquisition_des_titres = None
        self.duree_dexercice_de_lactivite_du_beneficiaire_dans_lentreprise = None
        self.fraction_du_gain_de_source_francaise = None
        self.nombre_de_titres = None
        self.prix_dacquisition_des_titres = None
        self.valeur_unitaire_des_titres_au_jour_de_lexercice_des_bons = None


@dataclass(init=False)
class S89_G00_91(DSNBlock):
    """Individu non salarié (S89.G00.91)"""

    block_id: ClassVar[str] = "S89.G00.91"

    date_de_naissance: str  # 006: Date de naissance (N4DS_DDN) [REQUIRED]
    lieu_de_naissance: str  # 007: Lieu de naissance (Type_Alphanumeric_1-30) [REQUIRED]
    numero_technique_temporaire: (
        str  # 021: Numéro technique temporaire (Type_Alphanumeric_11_40) [REQUIRED]
    )
    adresse_mel: str | None = None  # 015: Adresse mél (N4DS_Email_6-100)
    code_de_distribution_a_letranger: str | None = (
        None  # 012: Code de distribution à l'étranger (Type_Alphanumeric_1-50)
    )
    code_departement_de_naissance: str | None = (
        None  # 019: Code département de naissance (Departement)
    )
    code_pays: str | None = None  # 011: Code Pays (ISO_3166-1-A2_Pays)
    code_pays_de_naissance: str | None = (
        None  # 020: Code pays de naissance (ISO_3166-1-A2_Pays_All)
    )
    code_postal: str | None = None  # 009: Code postal (La_Poste_Hexaposte)
    code_statut_categoriel_retraite_complementaire_obligatoire: (
        DSN_IndividuAgircArrco_StatutRetraiteComplementaire | None
    ) = None  # 018: Code statut catégoriel Retraite Complémentaire obligatoire (DSN_IndividuAgircArrco.StatutRetraiteComplementaire)
    complement_de_la_localisation_de_la_construction: str | None = (
        None  # 013: Complément de la localisation de la construction (Type_Alphanumeric_1-50)
    )
    localite: str | None = None  # 010: Localité (N4DS_Adresse_Localite)
    matricule_de_lindividu_dans_lentreprise: str | None = (
        None  # 016: Matricule de l'individu dans l'entreprise (Type_Alphanumeric_1-30)
    )
    nom_de_famille: str | None = None  # 002: Nom de famille (Type_Alphanumeric_1-80)
    nom_dusage: str | None = None  # 003: Nom d'usage (Type_Alphanumeric_1-80)
    numero_dinscription_au_repertoire: str | None = (
        None  # 001: Numéro d'inscription au répertoire (Type_Alphanumeric_13-13)
    )
    numero_extension_nature_et_libelle_de_la_voie: str | None = (
        None  # 008: Numéro, extension, nature et libellé de la voie (Type_Alphanumeric_1-50)
    )
    prenoms: str | None = None  # 004: Prénoms (Type_Alphanumeric_1-80)
    service_de_distribution_complement_de_localisation_de_la_voie: str | None = (
        None  # 014: Service de distribution, complément de localisation de la voie (Type_Alphanumeric_1-50)
    )
    sexe: DSN_Sexe | None = None  # 005: Sexe (DSN_Sexe)
    statut_du_salarie_conventionnel: DSN_IndividuAgircArrco_StatutConventionnel | None = (
        None  # 017: Statut du salarié (conventionnel) (DSN_IndividuAgircArrco_StatutConventionnel)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "numero_dinscription_au_repertoire": (
            r"[1-2][0-9]{2}(0[1-9]|1[0-2]|20|3[0-9]|4[0-2]|[5-9][0-9])(0[1-9]|[1-9][0-9]|2A|2B)([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})([0]{2}[1-9]|0[1-9][0-9]|[1-9][0-9]{2})",
            "",
        ),
        "date_de_naissance": (
            r"(0[0-9]|[1-2][0-9]|3[0-1]|99)(0[0-9]|1[0-2]|99)(18|19|20)[0-9]{2}",
            "",
        ),
        "localite": (r"[A-Za-z0-9\\s]+", ""),
        "code_departement_de_naissance": (r"(0[1-9]|[1-9][0-9])|2A|2B", ""),
    }
    # Blocs enfants
    bases_specifiques_individu_non_salarie: list["S89_G00_92"] = field(
        default_factory=list
    )  # Bases spécifiques individu non salarié (S89.G00.92) [1..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.date_de_naissance = None
        self.lieu_de_naissance = None
        self.numero_technique_temporaire = None
        self.adresse_mel = None
        self.code_de_distribution_a_letranger = None
        self.code_departement_de_naissance = None
        self.code_pays = None
        self.code_pays_de_naissance = None
        self.code_postal = None
        self.code_statut_categoriel_retraite_complementaire_obligatoire = None
        self.complement_de_la_localisation_de_la_construction = None
        self.localite = None
        self.matricule_de_lindividu_dans_lentreprise = None
        self.nom_de_famille = None
        self.nom_dusage = None
        self.numero_dinscription_au_repertoire = None
        self.numero_extension_nature_et_libelle_de_la_voie = None
        self.prenoms = None
        self.service_de_distribution_complement_de_localisation_de_la_voie = None
        self.sexe = None
        self.statut_du_salarie_conventionnel = None
        self.bases_specifiques_individu_non_salarie = []


@dataclass(init=False)
class S89_G00_92(DSNBlock):
    """Bases spécifiques individu non salarié (S89.G00.92)"""

    block_id: ClassVar[str] = "S89.G00.92"

    code_de_base_specifique: DSN_BasesSpecifiqueAgircArrco_CodeBaseSpecifique  # 002: Code de base spécifique (DSN_BasesSpecifiqueAgircArrco_CodeBaseSpecifique) [REQUIRED]
    montant_net_verse: str  # 016: Montant net versé (Montant_ZNS_4_12_2_N_Z) [REQUIRED]
    date_de_debut_de_periode_de_rattachement: str | None = (
        None  # 004: Date de début de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_fin_de_periode_de_rattachement: str | None = (
        None  # 005: Date de fin de période de rattachement (Date_JJMMAAAA_20)
    )
    date_de_versement: str | None = None  # 011: Date de versement (Date_JJMMAAAA_21)
    identifiant_du_crm_a_lorigine_de_la_regularisation: str | None = (
        None  # 015: Identifiant du CRM à l'origine de la régularisation (Type_Alphanumeric_1-18)
    )
    identifiant_du_taux_de_prelevement_a_la_source: str | None = (
        None  # 009: Identifiant du taux de prélèvement à la source (Nombre_1_18)
    )
    montant: str | None = None  # 003: Montant (Montant_4_11)
    montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse: (
        str | None
    ) = None  # 014: Montant de l’abattement sur la base fiscale (non déduit du montant net fiscal du revenu versé) (Montant_ZNS_4_12_2_N_Z)
    montant_de_la_part_non_imposable_du_revenu: str | None = (
        None  # 012: Montant de la part non imposable du revenu (Montant_ZNS_4_12_2_N_Z)
    )
    montant_de_la_retenue_a_la_source_sur_les_revenus_verses_aux_non_residents_fiscaux: (
        str | None
    ) = None  # 018: Montant de la retenue à la source sur les revenus versés aux non-résidents fiscaux (Numeric_4_12)
    montant_de_prelevement_a_la_source: str | None = (
        None  # 010: Montant de prélèvement à la source (Montant_ZNS_4_12_2_Z)
    )
    montant_net_fiscal_du_revenu_verse: str | None = (
        None  # 006: Montant net fiscal du revenu versé (Montant_ZNS_4_12_2_N_Z)
    )
    montant_net_social: str | None = None  # 017: Montant net social (Numeric_4_12)
    montant_soumis_au_pas: str | None = None  # 013: Montant soumis au PAS (Montant_ZNS_4_12_2_Z)
    taux_de_prelevement_a_la_source: str | None = (
        None  # 007: Taux de prélèvement à la source (Taux_4_5)
    )
    type: DSN_BasesSpecifiqueAgircArrco_Type | None = (
        None  # 001: Type (DSN_BasesSpecifiqueAgircArrco_Type)
    )
    type_du_taux_de_prelevement_a_la_source: Taux_Prelevement_Source | None = (
        None  # 008: Type du taux de prélèvement à la source (Taux_Prelevement_Source)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "date_de_debut_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "date_de_fin_de_periode_de_rattachement": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "montant_net_fiscal_du_revenu_verse": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "taux_de_prelevement_a_la_source": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
        "identifiant_du_taux_de_prelevement_a_la_source": (r"-1|0|[1-9][0-9]{0,17}", ""),
        "montant_de_prelevement_a_la_source": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "date_de_versement": (r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "montant_de_la_part_non_imposable_du_revenu": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_soumis_au_pas": (r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "montant_net_verse": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_net_social": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "montant_de_la_retenue_a_la_source_sur_les_revenus_verses_aux_non_residents_fiscaux": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
    }
    # Blocs enfants
    regularisation_de_prelevement_a_la_source: list["S89_G00_93"] = field(
        default_factory=list
    )  # Régularisation de prélèvement à la source (S89.G00.93) [0..*]
    cotisation_individu_non_salarie: list["S89_G00_94"] = field(
        default_factory=list
    )  # Cotisation Individu non salarié (S89.G00.94) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_base_specifique = None
        self.montant_net_verse = None
        self.date_de_debut_de_periode_de_rattachement = None
        self.date_de_fin_de_periode_de_rattachement = None
        self.date_de_versement = None
        self.identifiant_du_crm_a_lorigine_de_la_regularisation = None
        self.identifiant_du_taux_de_prelevement_a_la_source = None
        self.montant = None
        self.montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse = None
        self.montant_de_la_part_non_imposable_du_revenu = None
        self.montant_de_la_retenue_a_la_source_sur_les_revenus_verses_aux_non_residents_fiscaux = (
            None
        )
        self.montant_de_prelevement_a_la_source = None
        self.montant_net_fiscal_du_revenu_verse = None
        self.montant_net_social = None
        self.montant_soumis_au_pas = None
        self.taux_de_prelevement_a_la_source = None
        self.type = None
        self.type_du_taux_de_prelevement_a_la_source = None
        self.regularisation_de_prelevement_a_la_source = []
        self.cotisation_individu_non_salarie = []


@dataclass(init=False)
class S89_G00_93(DSNBlock):
    """Régularisation de prélèvement à la source (S89.G00.93)"""

    block_id: ClassVar[str] = "S89.G00.93"

    mois_de_l_erreur: str | None = None  # 001: Mois de l’erreur (Date_MMAAAA)
    montant_de_la_regularisation_du_prelevement_a_la_source: str | None = (
        None  # 007: Montant de la régularisation du prélèvement à la source (Montant_ZNS_4_12_2_N_Z)
    )
    montant_net_fiscal_du_revenu_verse_le_mois_de_l_erreur: str | None = (
        None  # 004: Montant net fiscal du revenu versé le mois de l’erreur (Nombre_4_12_regex3)
    )
    montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur: str | None = (
        None  # 013: Montant soumis au prélèvement à la source déclaré le mois de l'erreur (Montant_ZNS_4_12_2_N_Z_quepositif)
    )
    regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse: (
        str | None
    ) = None  # 010: Régularisation du montant de l’abattement sur la base fiscale (non déduit du montant net fiscal du revenu versé) (Montant_ZNS_4_12_2_N_Z)
    regularisation_du_montant_de_la_part_non_imposable_du_revenu: str | None = (
        None  # 008: Régularisation du montant de la part non imposable du revenu (Montant_ZNS_4_12_2_N_Z)
    )
    regularisation_du_montant_net_fiscal_du_revenu_verse: str | None = (
        None  # 003: Régularisation du montant net fiscal du revenu versé (Nombre_4_12_regex3)
    )
    regularisation_du_montant_soumis_au_pas: str | None = (
        None  # 009: Régularisation du montant soumis au PAS (Montant_ZNS_4_12_2_N_Z)
    )
    regularisation_du_taux_de_prelevement_a_la_source: str | None = (
        None  # 005: Régularisation du taux de prélèvement à la source (Taux_pos_neg_4_6)
    )
    taux_declare_le_mois_de_l_erreur: str | None = (
        None  # 006: Taux déclaré le mois de l’erreur (Taux_4_5)
    )
    type_d_erreur: Type_erreurs_PAS | None = None  # 002: Type d’erreur  (Type_erreurs_PAS)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "mois_de_l_erreur": (r"(0[1-9]|1[0-2])(19|20)[0-9]{2}", ""),
        "regularisation_du_montant_net_fiscal_du_revenu_verse": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "montant_net_fiscal_du_revenu_verse_le_mois_de_l_erreur": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_taux_de_prelevement_a_la_source": (
            r"-?(([0-9]{1,2}\\.[1-9][0-9])|([0-9]{1,2}\\.[0-9][1-9])|([0-9][1-9]\\.[0-9]{2})|([1-9][0-9]\\.[0-9]{2})|([0-9]\\.[1-9][0-9])|([0-9]\\.[0-9][1-9])|([1-9]\\.[0-9]{2}))",
            "",
        ),
        "taux_declare_le_mois_de_l_erreur": (r"[0-9]{1,2}\\.[0-9]{2}", ""),
        "montant_de_la_regularisation_du_prelevement_a_la_source": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_montant_de_la_part_non_imposable_du_revenu": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "regularisation_du_montant_soumis_au_pas": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
        "regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse": (
            r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
        "montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur": (
            r"[0]*(0|[1-9][0-9]*)\\.[0-9]{2}",
            "",
        ),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.mois_de_l_erreur = None
        self.montant_de_la_regularisation_du_prelevement_a_la_source = None
        self.montant_net_fiscal_du_revenu_verse_le_mois_de_l_erreur = None
        self.montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur = None
        self.regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse = None
        self.regularisation_du_montant_de_la_part_non_imposable_du_revenu = None
        self.regularisation_du_montant_net_fiscal_du_revenu_verse = None
        self.regularisation_du_montant_soumis_au_pas = None
        self.regularisation_du_taux_de_prelevement_a_la_source = None
        self.taux_declare_le_mois_de_l_erreur = None
        self.type_d_erreur = None


@dataclass(init=False)
class S89_G00_94(DSNBlock):
    """Cotisation Individu non salarié (S89.G00.94)"""

    block_id: ClassVar[str] = "S89.G00.94"

    code_de_cotisation: DSN_CotisationIndividuNonSalarie_CodeCotisation | None = (
        None  # 001: Code de cotisation (DSN_CotisationIndividuNonSalarie_CodeCotisation)
    )
    montant_de_cotisation: str | None = None  # 002: Montant de cotisation (Nombre_4_12_regex3)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "montant_de_cotisation": (r"-?[0]*(0|[1-9][0-9]*)\\.[0-9]{2}", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.code_de_cotisation = None
        self.montant_de_cotisation = None


@dataclass(init=False)
class S10_G00_00(DSNBlock):
    """S10.G00.00 (S10.G00.00)"""

    block_id: ClassVar[str] = "S10.G00.00"

    nom_du_logiciel_utilise: str  # 001: Nom du logiciel utilisé (Type_Alphanumeric_1-20) [REQUIRED]
    code_de_conformite_en_pre_controle: str | None = (
        None  # 004: Code de conformité en pré-contrôle (Type_Alphanumeric_1-50)
    )
    code_envoi_du_fichier_dessai_ou_reel: N4DS_Essai | None = (
        None  # 005: Code envoi du fichier d'essai ou réel (N4DS_Essai)
    )
    nom_de_lediteur: str | None = None  # 002: Nom de l'éditeur (Type_Alphanumeric_1-20)
    numero_de_version_de_la_norme_utilisee: DSN_Version | None = (
        None  # 006: Numéro de version de la norme utilisée (DSN_Version)
    )
    numero_de_version_du_logiciel_utilise: str | None = (
        None  # 003: Numéro de version du logiciel utilisé (Type_Alphanumeric_1-10)
    )
    point_de_depot: Point_Depot | None = None  # 007: Point de dépôt (Point_Depot)
    type_de_lenvoi: DSN_Envoi_Type | None = None  # 008: Type de l'envoi (DSN_Envoi_Type)
    # Blocs enfants
    emetteur: "S10_G00_01" | None = None  # Emetteur (S10.G00.01) [1..1]
    contact_emetteur: "S10_G00_02" | None = None  # Contact Emetteur (S10.G00.02) [1..1]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.nom_du_logiciel_utilise = None
        self.code_de_conformite_en_pre_controle = None
        self.code_envoi_du_fichier_dessai_ou_reel = None
        self.nom_de_lediteur = None
        self.numero_de_version_de_la_norme_utilisee = None
        self.numero_de_version_du_logiciel_utilise = None
        self.point_de_depot = None
        self.type_de_lenvoi = None
        self.emetteur = None
        self.contact_emetteur = None


@dataclass(init=False)
class S20_G00_05(DSNBlock):
    """S20.G00.05 (S20.G00.05)"""

    block_id: ClassVar[str] = "S20.G00.05"

    champ_de_la_declaration: Declaration_Champ | None = (
        None  # 008: Champ de la déclaration (Declaration_Champ)
    )
    date_de_constitution_du_fichier: str | None = (
        None  # 007: Date de constitution du fichier (Date_JJMMAAAA_20)
    )
    date_du_mois_principal_declare: str | None = (
        None  # 005: Date du mois principal déclaré (Date_JJMMAAAA_Mois_Declare)
    )
    dernier_siret_connu_pour_ancien_numero_de_contrat: str | None = (
        None  # 012: Dernier SIRET connu pour ancien numéro de contrat (Identifiant_Siret)
    )
    devise_de_la_declaration: DSN_Devise_Paiement | None = (
        None  # 010: Devise de la déclaration (DSN_Devise_Paiement)
    )
    identifiant_de_la_declaration_annulee_ou_remplacee: str | None = (
        None  # 006: Identifiant de la déclaration annulée ou remplacée (Identifiant_33)
    )
    identifiant_metier: str | None = None  # 009: Identifiant métier (Type_Alphanumeric_1-15)
    nature_de_l_evenement_declencheur_du_signalement: (
        DSN_NatureEvenementDeclencheurSignalement | None
    ) = None  # 011: Nature de l’événement déclencheur du signalement (DSN_NatureEvenementDeclencheurSignalement)
    nature_de_la_declaration: DSN_Declaration_Nature | None = (
        None  # 001: Nature de la déclaration (DSN_Declaration_Nature)
    )
    numero_de_fraction_de_declaration: str | None = (
        None  # 003: Numéro de fraction de déclaration (Declaration_Fraction)
    )
    numero_dordre_de_la_declaration: str | None = (
        None  # 004: Numéro d'ordre de la déclaration (Declaration_Ordre)
    )
    type_de_la_declaration: DSN_Declaration_Type | None = (
        None  # 002: Type de la déclaration (DSN_Declaration_Type)
    )
    type_de_nature_de_la_dsn_de_substitution: DSN_Substitution_Nature | None = (
        None  # 013: Type de nature de la DSN de substitution (DSN_Substitution_Nature)
    )
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "numero_de_fraction_de_declaration": (r"[1-9]{2}", ""),
        "numero_dordre_de_la_declaration": (r"0|[1-9][0-9]*", ""),
        "date_du_mois_principal_declare": (r"(01)(0[1-9]|1[0-2])(20)[0-9]{2}", ""),
        "identifiant_de_la_declaration_annulee_ou_remplacee": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(19|20)[0-9]{2}(0|[1-9][0-9]*)",
            "",
        ),
        "date_de_constitution_du_fichier": (
            r"(0[1-9]|[1-2][0-9]|3[0-1])(0[1-9]|1[0-2])(20)[0-9]{2}",
            "",
        ),
        "dernier_siret_connu_pour_ancien_numero_de_contrat": (r"[0-9]*[1-9][0-9]*", ""),
    }
    # Blocs enfants
    contact_chez_le_declare: list["S20_G00_07"] = field(
        default_factory=list
    )  # Contact chez le déclaré (S20.G00.07) [0..*]
    identifiant_de_l_organisme_destinataire_de_la_declaration_absence_de_rattachement_pour_le_mois_principal_declare: list[
        "S20_G00_08"
    ] = field(
        default_factory=list
    )  # Identifiant de l’organisme destinataire de la déclaration « Absence de rattachement pour le mois principal déclaré » (S20.G00.08) [0..*]
    entreprise: "S21_G00_06" | None = None  # Entreprise (S21.G00.06) [1..1]
    lieu_de_travail_ou_etablissement_utilisateur: list["S21_G00_85"] = field(
        default_factory=list
    )  # Lieu de travail ou établissement utilisateur (S21.G00.85) [0..*]
    beneficiaire_des_honoraires: list["S89_G00_32"] = field(
        default_factory=list
    )  # Bénéficiaire des honoraires (S89.G00.32) [0..*]
    droit_supplementaire_acquis_au_titre_des_regimes_de_retraite_supplementaire_a_prestations_definies: list[
        "S89_G00_67"
    ] = field(
        default_factory=list
    )  # Droit supplémentaire acquis au titre des régimes de retraite supplémentaire à prestations définies (S89.G00.67) [0..*]
    actions_gratuites: list["S89_G00_87"] = field(
        default_factory=list
    )  # Actions gratuites (S89.G00.87) [0..*]
    options_sur_titres_stock_options: list["S89_G00_88"] = field(
        default_factory=list
    )  # Options sur titres (stock options) (S89.G00.88) [0..*]
    bons_de_souscription_de_parts_de_createur_dentreprise_bspce: list["S89_G00_89"] = field(
        default_factory=list
    )  # Bons de souscription de parts de créateur d'entreprise (BSPCE) (S89.G00.89) [0..*]
    individu_non_salarie: list["S89_G00_91"] = field(
        default_factory=list
    )  # Individu non salarié (S89.G00.91) [0..*]

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.champ_de_la_declaration = None
        self.date_de_constitution_du_fichier = None
        self.date_du_mois_principal_declare = None
        self.dernier_siret_connu_pour_ancien_numero_de_contrat = None
        self.devise_de_la_declaration = None
        self.identifiant_de_la_declaration_annulee_ou_remplacee = None
        self.identifiant_metier = None
        self.nature_de_l_evenement_declencheur_du_signalement = None
        self.nature_de_la_declaration = None
        self.numero_de_fraction_de_declaration = None
        self.numero_dordre_de_la_declaration = None
        self.type_de_la_declaration = None
        self.type_de_nature_de_la_dsn_de_substitution = None
        self.contact_chez_le_declare = []
        self.identifiant_de_l_organisme_destinataire_de_la_declaration_absence_de_rattachement_pour_le_mois_principal_declare = []
        self.entreprise = None
        self.lieu_de_travail_ou_etablissement_utilisateur = []
        self.beneficiaire_des_honoraires = []
        self.droit_supplementaire_acquis_au_titre_des_regimes_de_retraite_supplementaire_a_prestations_definies = []
        self.actions_gratuites = []
        self.options_sur_titres_stock_options = []
        self.bons_de_souscription_de_parts_de_createur_dentreprise_bspce = []
        self.individu_non_salarie = []


@dataclass(init=False)
class S90_G00_90(DSNBlock):
    """S90.G00.90 (S90.G00.90)"""

    block_id: ClassVar[str] = "S90.G00.90"

    nombre_de_dsn: str | None = None  # 002: Nombre de DSN (Nombre_ZNS_1_5)
    nombre_total_de_rubriques: str | None = None  # 001: Nombre total de rubriques (Nombre_ZNS_1_12)
    _VALIDATION_RULES: ClassVar[dict[str, tuple[str, str]]] = {
        "nombre_total_de_rubriques": (r"[0]*[1-9][0-9]*", ""),
        "nombre_de_dsn": (r"[0]*[1-9][0-9]*", ""),
    }

    def __init__(self) -> None:
        """Initialize all fields to None."""
        self.nombre_de_dsn = None
        self.nombre_total_de_rubriques = None


@dataclass
class DSNMessage:
    """Message DSN complet."""

    header: S10_G00_00
    declarations: list[S20_G00_05] = field(default_factory=list)
    footer: S90_G00_90 | None = None

    def validate(self, strict: bool = False) -> list[str]:
        """Valide récursivement tous les blocs."""
        errors: list[str] = []
        errors.extend(self.header.validate(strict=False))
        for decl in self.declarations:
            errors.extend(decl.validate(strict=False))
        if self.footer:
            errors.extend(self.footer.validate(strict=False))

        if strict and errors:
            raise ValueError("Validation errors:\n" + "\n".join(errors))

        return errors

    def to_dict(self) -> dict[str, Any]:
        """Convertit le message en dictionnaire."""
        return {
            "header": self.header.to_dict(),
            "declarations": [d.to_dict() for d in self.declarations],
            "footer": self.footer.to_dict() if self.footer else None,
        }

    def to_json(self, indent: int = 2, ensure_ascii: bool = False) -> str:
        """Convertit le message en chaîne JSON."""
        return json.dumps(self.to_dict(), indent=indent, ensure_ascii=ensure_ascii)
