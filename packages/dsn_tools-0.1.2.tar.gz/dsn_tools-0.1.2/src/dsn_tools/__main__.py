"""Point d'entrée pour `python -m dsn_tools`."""

from dsn_tools.cli import main

if __name__ == "__main__":
    main()
