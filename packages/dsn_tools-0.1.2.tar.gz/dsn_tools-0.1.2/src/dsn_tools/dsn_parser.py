"""
Parser DSN utilisant Lark.
Format: SXX.GXX.XX.XXX,VALEUR (ligne par ligne)
"""

from pathlib import Path
from typing import Any

from lark import Lark, Token, Tree

from dsn_tools.dsn_types import DSNBlock, DSNMessage, S10_G00_00, S20_G00_05, S90_G00_90
from dsn_tools.dsn_utils import sanitize_class_name


# Mapping des blocs principaux
BLOCK_CLASSES: dict[str, Any] = {
    "S10.G00.00": S10_G00_00,
    "S20.G00.05": S20_G00_05,
    "S90.G00.90": S90_G00_90,
}

# Mapping des rubriques vers noms de champs (généré automatiquement)
RUBRIQUE_MAPPING: dict[str, dict[str, str]] = {
    "S10.G00.00": {
        "001": "nom_du_logiciel_utilise",
        "002": "nom_de_lediteur",
        "003": "numero_de_version_du_logiciel_utilise",
        "004": "code_de_conformite_en_pre_controle",
        "005": "code_envoi_du_fichier_dessai_ou_reel",
        "006": "numero_de_version_de_la_norme_utilisee",
        "007": "point_de_depot",
        "008": "type_de_lenvoi",
    },
    "S10.G00.01": {
        "001": "siren_de_lemetteur_de_lenvoi",
        "002": "nic_de_lemetteur_de_lenvoi",
        "003": "nom_ou_raison_sociale_de_lemetteur",
        "004": "numero_extension_nature_et_libelle_de_la_voie",
        "005": "code_postal",
        "006": "localite",
        "007": "code_pays",
        "008": "code_de_distribution_a_letranger",
        "009": "complement_de_la_localisation_de_la_construction",
        "010": "service_de_distribution_complement_de_localisation_de_la_voie",
    },
    "S10.G00.02": {
        "001": "code_civilite",
        "002": "nom_et_prenom_de_la_personne_a_contacter",
        "004": "adresse_mel_du_contact_emetteur",
        "005": "adresse_telephonique",
        "006": "adresse_fax",
    },
    "S20.G00.05": {
        "001": "nature_de_la_declaration",
        "002": "type_de_la_declaration",
        "003": "numero_de_fraction_de_declaration",
        "004": "numero_dordre_de_la_declaration",
        "005": "date_du_mois_principal_declare",
        "006": "identifiant_de_la_declaration_annulee_ou_remplacee",
        "007": "date_de_constitution_du_fichier",
        "008": "champ_de_la_declaration",
        "009": "identifiant_metier",
        "010": "devise_de_la_declaration",
        "011": "nature_de_l_evenement_declencheur_du_signalement",
        "012": "dernier_siret_connu_pour_ancien_numero_de_contrat",
        "013": "type_de_nature_de_la_dsn_de_substitution",
    },
    "S20.G00.07": {
        "001": "nom_et_prenom_du_contact",
        "002": "adresse_telephonique",
        "003": "adresse_mel_du_contact",
        "004": "type",
    },
    "S20.G00.08": {
        "001": "code_caisse",
    },
    "S21.G00.06": {
        "001": "siren",
        "002": "nic_du_siege",
        "003": "code_apen",
        "004": "numero_extension_nature_et_libelle_de_la_voie",
        "005": "code_postal",
        "006": "localite",
        "007": "complement_de_la_localisation_de_la_construction",
        "008": "service_de_distribution_complement_de_localisation_de_la_voie",
        "010": "code_pays",
        "011": "code_de_distribution_a_letranger",
        "012": "implantation_de_lentreprise",
        "015": "code_convention_collective_applicable",
    },
    "S21.G00.13": {
        "001": "accord_agree_oeth",
        "002": "type_boeth_externe",
        "003": "nombre_boeth_externe",
        "004": "millesime_de_rattachement",
    },
    "S21.G00.11": {
        "001": "nic",
        "002": "code_apet",
        "003": "numero_extension_nature_et_libelle_de_la_voie",
        "004": "code_postal",
        "005": "localite",
        "006": "complement_de_la_localisation_de_la_construction",
        "007": "service_de_distribution_complement_de_localisation_de_la_voie",
        "009": "type_de_remuneration_soumise_a_contributions_dassurance_chomage_pour_expatries",
        "015": "code_pays",
        "016": "code_de_distribution_a_letranger",
        "017": "nature_juridique_de_lemployeur",
        "019": "date_deffet_de_ladhesion_au_dispositif_tese_cea",
        "020": "date_deffet_de_la_sortie_du_dispositif_tese_cea",
        "022": "code_convention_collective_principale",
        "023": "operateur_de_competences_opco",
        "024": "demande_de_sortie_de_la_dsn",
        "025": "identifiant_du_service_de_prevention_et_de_sante_au_travail_spst",
    },
    "S21.G00.12": {
        "001": "type_dusage",
        "002": "bic",
        "003": "iban",
    },
    "S21.G00.15": {
        "001": "reference_du_contrat_de_prevoyance",
        "002": "code_organisme_de_prevoyance",
        "003": "code_delegataire_de_gestion",
        "004": "personnel_couvert",
        "005": "identifiant_technique_adhesion",
    },
    "S21.G00.16": {
        "001": "date_de_la_modification",
        "002": "ancien_code_organisme_de_prevoyance",
        "003": "ancien_code_delegataire_de_gestion",
    },
    "S21.G00.82": {
        "001": "valeur",
        "002": "code_de_cotisation",
        "003": "date_de_debut_de_periode_de_rattachement",
        "004": "date_de_fin_de_periode_de_rattachement",
        "005": "reference_reglementaire_ou_contractuelle",
        "006": "identifiant_du_crm_a_lorigine_de_la_regularisation",
    },
    "S21.G00.20": {
        "001": "identifiant_organisme_de_protection_sociale",
        "002": "entite_daffectation_des_operations",
        "003": "bic",
        "004": "iban",
        "005": "montant_du_versement",
        "006": "date_de_debut_de_periode_de_rattachement",
        "007": "date_de_fin_de_periode_de_rattachement",
        "008": "code_delegataire_de_gestion",
        "010": "mode_de_paiement",
        "011": "date_de_paiement",
        "012": "siret_payeur",
        "013": "identifiant_du_crm_a_lorigine_de_la_regularisation",
        "014": "identifiant_du_versement",
    },
    "S21.G00.55": {
        "001": "montant_verse",
        "002": "type_de_population",
        "003": "code_daffectation",
        "004": "periode_daffectation",
        "005": "identifiant_du_crm_a_lorigine_de_la_regularisation",
    },
    "S21.G00.22": {
        "001": "identifiant_organisme_de_protection_sociale",
        "002": "entite_daffectation_des_operations",
        "003": "date_de_debut_de_periode_de_rattachement",
        "004": "date_de_fin_de_periode_de_rattachement",
        "005": "montant_total_de_cotisations",
        "006": "identifiant_du_crm_a_lorigine_de_la_regularisation",
    },
    "S21.G00.23": {
        "001": "code_de_cotisation",
        "002": "qualifiant_dassiette",
        "003": "taux_de_cotisation",
        "004": "montant_dassiette",
        "005": "montant_de_cotisation",
        "006": "code_insee_commune",
        "007": "identifiant_du_crm_a_lorigine_de_la_regularisation",
    },
    "S21.G00.44": {
        "001": "code_taxe",
        "002": "montant",
        "003": "millesime_de_rattachement",
        "004": "motif_de_non_assujettissement_a_la_taxe_dapprentissage",
    },
    "S21.G00.30": {
        "001": "numero_dinscription_au_repertoire",
        "002": "nom_de_famille",
        "003": "nom_dusage",
        "004": "prenoms",
        "005": "sexe",
        "006": "date_de_naissance",
        "007": "lieu_de_naissance",
        "008": "numero_extension_nature_et_libelle_de_la_voie",
        "009": "code_postal",
        "010": "localite",
        "011": "code_pays",
        "012": "code_de_distribution_a_letranger",
        "013": "codification_ue",
        "014": "code_departement_de_naissance",
        "015": "code_pays_de_naissance",
        "016": "complement_de_la_localisation_de_la_construction",
        "017": "service_de_distribution_complement_de_localisation_de_la_voie",
        "018": "adresse_mel",
        "019": "matricule_de_lindividu_dans_lentreprise",
        "020": "numero_technique_temporaire",
        "022": "statut_a_letranger_au_sens_fiscal",
        "023": "cumul_emploi_retraite",
        "024": "niveau_de_formation_le_plus_eleve_obtenu_par_lindividu",
        "025": "niveau_de_diplome_prepare_par_lindividu",
        "029": "libelle_du_pays_de_naissance",
        "030": "identifiant_du_service_de_prevention_et_de_sante_au_travail_spst",
    },
    "S21.G00.31": {
        "001": "date_de_la_modification",
        "008": "ancien_nir",
        "009": "ancien_nom_de_famille",
        "010": "anciens_prenoms",
        "011": "ancienne_date_de_naissance",
    },
    "S21.G00.34": {
        "001": "facteur_dexposition",
        "002": "numero_du_contrat",
        "003": "annee_de_rattachement",
    },
    "S21.G00.40": {
        "001": "date_de_debut_du_contrat",
        "002": "statut_du_salarie_conventionnel",
        "003": "code_statut_categoriel_retraite_complementaire_obligatoire",
        "004": "code_profession_et_categorie_socioprofessionnelle_pcs_ese",
        "005": "code_complement_pcs_ese_pour_la_fonction_publique_referentiels_neh_net_et_grade_de_la_nne",
        "006": "libelle_de_lemploi",
        "007": "nature_du_contrat",
        "008": "dispositif_de_politique_publique_et_conventionnel",
        "009": "numero_du_contrat",
        "010": "date_de_fin_previsionnelle_du_contrat",
        "011": "unite_de_mesure_de_la_quotite_de_travail",
        "012": "quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie",
        "013": "quotite_de_travail_du_contrat",
        "014": "modalite_dexercice_du_temps_de_travail",
        "016": "complement_de_base_au_regime_obligatoire",
        "017": "code_convention_collective_applicable",
        "018": "code_regime_de_base_risque_maladie",
        "019": "identifiant_du_lieu_de_travail",
        "020": "code_regime_de_base_risque_vieillesse",
        "021": "motif_de_recours",
        "022": "code_caisse_professionnelle_de_conges_payes",
        "023": "taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels",
        "024": "travailleur_a_letranger_au_sens_du_code_de_la_securite_sociale",
        "025": "motif_dexclusion_dsn",
        "026": "statut_demploi_du_salarie",
        "027": "code_affectation_assurance_chomage",
        "028": "numero_interne_employeur_public",
        "029": "type_de_gestion_de_l_assurance_chomage",
        "030": "date_dadhesion",
        "031": "date_de_denonciation",
        "032": "date_d_effet_de_la_convention_de_gestion",
        "033": "numero_de_convention_de_gestion",
        "035": "code_delegataire_du_risque_maladie",
        "036": "code_emplois_multiples",
        "037": "code_employeurs_multiples",
        "039": "code_regime_de_base_risque_accident_du_travail",
        "040": "code_risque_accident_du_travail",
        "041": "positionnement_dans_la_convention_collective",
        "042": "code_statut_categoriel_apecita",
        "043": "taux_de_cotisation_accident_du_travail",
        "044": "salarie_a_temps_partiel_cotisant_a_temps_plein",
        "045": "remuneration_au_pourboire",
        "046": "identifiant_de_l_etablissement_utilisateur",
        "048": "numero_de_label_prestataire_de_services_du_spectacle_vivant",
        "049": "numero_de_licence_entrepreneur_spectacle",
        "050": "numero_objet_spectacle",
        "051": "statut_organisateur_spectacle",
        "052": "fp_code_complement_pcs_ese_pour_la_fonction_publique_detat_emploi_de_la_nne",
        "053": "nature_du_poste",
        "054": "fp_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet",
        "055": "taux_de_travail_a_temps_partiel",
        "056": "code_categorie_de_service",
        "057": "fp_indice_brut",
        "058": "fp_indice_majore",
        "059": "fp_nouvelle_bonification_indiciaire_nbi",
        "060": "fp_indice_brut_dorigine",
        "061": "fp_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15",
        "062": "fp_ancien_employeur_public",
        "063": "fp_indice_brut_d_origine_ancien_salarie_employeur_public",
        "064": "fp_indice_brut_d_origine_sapeur_pompier_professionnel_spp",
        "065": "fp_maintien_du_traitement_dorigine_dun_contractuel_titulaire",
        "066": "fp_type_de_detachement",
        "067": "genre_de_navigation",
        "068": "taux_de_service_actif",
        "069": "niveau_de_remuneration",
        "070": "echelon",
        "071": "coefficient_hierarchique",
        "072": "statut_boeth",
        "073": "complement_de_dispositif_de_politique_publique",
        "074": "cas_de_mise_a_disposition_externe_dun_individu_de_letablissement",
        "075": "categorie_de_classement_finale",
        "076": "identifiant_du_contrat_dengagement_maritime",
        "077": "college_cnieg",
        "078": "forme_damenagement_du_temps_de_travail_dans_le_cadre_de_lactivite_partielle",
        "079": "grade",
        "080": "fp_indice_complement_de_traitement_indiciaire_cti",
        "081": "finess_geographique",
        "082": "nombre_de_jours_de_periode_d_essai",
        "083": "heure_previsible_dembauche",
    },
    "S21.G00.41": {
        "001": "date_de_la_modification",
        "002": "ancien_statut_du_salarie_conventionnel",
        "003": "ancien_code_statut_categoriel_retraite_complementaire_obligatoire",
        "004": "ancienne_nature_du_contrat",
        "005": "ancien_dispositif_de_politique_publique_et_conventionnel",
        "006": "ancienne_unite_de_mesure_de_la_quotite_de_travail",
        "007": "ancienne_quotite_de_travail_du_contrat",
        "008": "ancienne_modalite_dexercice_du_temps_de_travail",
        "010": "ancien_complement_de_base_au_regime_obligatoire",
        "011": "ancien_code_convention_collective_applicable",
        "012": "siret_ancien_etablissement_daffectation",
        "013": "ancien_identifiant_du_lieu_de_travail",
        "014": "ancien_numero_du_contrat",
        "016": "ancien_motif_de_recours",
        "017": "ancien_taux_de_deduction_forfaitaire_specifique_pour_frais_professionnels",
        "018": "ancien_travailleur_a_letranger_au_sens_du_code_de_la_securite_sociale",
        "019": "ancien_code_profession_et_categorie_socioprofessionnelle_pcs_ese",
        "020": "ancien_code_complement_pcs_ese_pour_la_fonction_publique_referentiels_neh_net_et_grade_de_la_nne",
        "021": "ancienne_date_de_debut_du_contrat",
        "022": "ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie",
        "023": "ancien_code_caisse_professionnelle_de_conges_payes",
        "024": "ancien_code_risque_accident_du_travail",
        "025": "ancien_code_statut_categoriel_apecita",
        "027": "ancien_salarie_a_temps_partiel_cotisant_a_temps_plein",
        "028": "profondeur_de_recalcul_de_la_paie",
        "029": "fp_ancien_code_complement_pcs_ese_pour_la_fonction_publique_detat_emploi_de_la_nne",
        "030": "ancienne_nature_du_poste",
        "031": "fp_ancienne_quotite_de_travail_de_reference_de_lentreprise_pour_la_categorie_de_salarie_dans_l_hypothese_d_un_poste_a_temps_complet",
        "032": "ancien_taux_de_travail_a_temps_partiel",
        "033": "ancien_code_categorie_de_service",
        "034": "fp_ancien_indice_brut",
        "035": "fp_ancien_indice_majore",
        "036": "fp_ancienne_nouvelle_bonification_indiciaire_nbi",
        "037": "fp_ancien_indice_brut_dorigine",
        "038": "fp_ancien_indice_brut_de_cotisation_dans_un_emploi_superieur_article_15",
        "039": "fp_ancien_ancien_employeur_public",
        "040": "fp_ancien_indice_brut_d_origine_ancien_salarie_employeur_public",
        "041": "fp_ancien_indice_brut_d_origine_sapeur_pompier_professionnel_spp",
        "042": "fp_ancien_maintien_du_traitement_dorigine_dun_contractuel_titulaire",
        "043": "ancien_taux_de_service_actif",
        "044": "ancien_niveau_de_remuneration",
        "045": "ancien_echelon",
        "046": "ancien_coefficient_hierarchique",
        "047": "ancien_genre_de_navigation",
        "048": "ancien_statut_boeth",
        "049": "ancien_complement_de_dispositif_de_politique_publique",
        "050": "ancien_cas_de_mise_a_disposition_externe_dun_individu_de_letablissement",
        "051": "ancienne_categorie_de_classement_finale",
        "052": "ancien_code_regime_de_base_risque_maladie",
        "053": "ancien_code_regime_de_base_risque_vieillesse",
        "054": "ancien_identifiant_du_contrat_dengagement_maritime",
        "055": "ancien_college_cnieg",
        "056": "ancienne_forme_damenagement_du_temps_de_travail_dans_le_cadre_de_lactivite_partielle",
        "057": "fp_ancien_type_de_detachement",
        "058": "ancien_positionnement_dans_la_convention_collective",
        "059": "ancien_code_regime_de_base_risque_accident_du_travail",
        "060": "ancien_statut_demploi_du_salarie",
        "061": "ancien_code_emplois_multiples",
        "062": "ancien_code_employeurs_multiples",
        "063": "ancien_grade",
        "064": "fp_ancien_indice_complement_de_traitement_indiciaire_cti",
        "065": "ancien_finess_geographique",
    },
    "S21.G00.45": {
        "001": "siret_declarant_le_contrat_precedemment",
        "002": "numero_du_contrat_declare_precedemment",
    },
    "S21.G00.60": {
        "001": "motif_de_larret",
        "002": "date_du_dernier_jour_travaille",
        "003": "date_de_fin_previsionnelle",
        "004": "subrogation",
        "005": "date_de_debut_de_subrogation",
        "006": "date_de_fin_de_subrogation",
        "007": "iban",
        "008": "bic",
        "010": "date_de_la_reprise",
        "011": "motif_de_la_reprise",
        "012": "date_de_laccident_ou_de_la_premiere_constatation",
        "600": "siret_centralisateur",
    },
    "S21.G00.66": {
        "001": "date_de_debut",
        "002": "date_de_fin",
        "003": "montant",
    },
    "S21.G00.62": {
        "001": "date_de_fin_du_contrat",
        "002": "motif_de_la_rupture_du_contrat",
        "003": "date_de_notification_de_la_rupture_de_contrat",
        "004": "date_de_signature_de_la_convention_de_rupture",
        "005": "date_dengagement_de_la_procedure_de_licenciement",
        "006": "dernier_jour_travaille_et_paye_au_salaire_habituel",
        "008": "transaction_en_cours",
        "011": "nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_csp",
        "013": "montant_de_lindemnite_de_preavis_qui_aurait_ete_versee",
        "014": "statut_particulier_du_salarie",
        "016": "maintien_de_l_affiliation_du_salarie_au_contrat_collectif",
        "017": "modalite_de_declaration_de_la_fin_du_contrat_dusage",
        "018": "nombre_de_mois_de_preavis_utilises_dans_le_cadre_du_calcul_pap",
        "019": "solde_de_conges_acquis_et_non_pris_enim",
        "020": "mois_de_la_dsn_mensuelle_portant_les_derniers_elements_declares_dans_le_fctu",
        "021": "refus_de_la_proposition_dun_cdi_suite_a_cdd_ou_contrat_de_mission",
    },
    "S21.G00.63": {
        "001": "type_realisation_et_paiement_du_preavis",
        "002": "date_de_debut_de_preavis",
        "003": "date_de_fin_de_preavis",
    },
    "S21.G00.65": {
        "001": "motif_de_suspension",
        "002": "date_de_debut_de_la_suspension",
        "003": "date_de_fin_de_la_suspension",
        "004": "fp_position_de_detachement",
        "005": "nombre_de_jours_ouvres_de_suspension",
    },
    "S21.G00.70": {
        "004": "code_option_retenue_par_le_salarie",
        "005": "code_population_de_rattachement",
        "007": "nombre_d_enfants_a_charge",
        "008": "nombre_dayants_droit_conjoint_concubin",
        "009": "nombre_dayants_droit_attaches_au_salarie_pour_le_contrat_prevoyance_mentionne",
        "010": "nombre_dayants_droit_autres_ascendants_collateraux",
        "011": "nombre_denfants_ayants_droit",
        "012": "identifiant_technique_affiliation",
        "013": "identifiant_technique_adhesion",
        "014": "date_de_debut_de_l_affiliation",
        "015": "date_de_fin_de_l_affiliation",
    },
    "S21.G00.73": {
        "001": "regime_local_alsace_moselle",
        "002": "code_option",
        "003": "type",
        "004": "date_de_debut_de_rattachement_a_louvrant_droit",
        "005": "date_de_naissance",
        "006": "nom_de_famille",
        "007": "numero_dinscription_au_repertoire",
        "008": "nir_ouvrant_droit_regime_de_base_maladie",
        "009": "prenoms",
        "010": "code_organisme_daffiliation_a_lassurance_maladie",
        "011": "date_de_fin_de_rattachement_a_louvrant_droit",
    },
    "S21.G00.71": {
        "002": "code_regime_retraite_complementaire",
    },
    "S21.G00.72": {
        "001": "code_regime_retraite_complementaire_declare_a_tort",
    },
    "S21.G00.50": {
        "001": "date_de_versement",
        "002": "remuneration_nette_fiscale",
        "003": "numero_de_versement",
        "004": "montant_net_verse",
        "006": "taux_de_prelevement_a_la_source",
        "007": "type_du_taux_de_prelevement_a_la_source",
        "008": "identifiant_du_taux_de_prelevement_a_la_source",
        "009": "montant_de_prelevement_a_la_source",
        "011": "montant_de_la_part_non_imposable_du_revenu",
        "012": "montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale",
        "013": "montant_soumis_au_pas",
        "020": "mois_de_la_dsn_mensuelle_de_rattachement_des_elements_declares_dans_le_fctu",
    },
    "S21.G00.51": {
        "001": "date_de_debut_de_periode_de_paie",
        "002": "date_de_fin_de_periode_de_paie",
        "010": "numero_du_contrat",
        "011": "type",
        "012": "nombre_dheures",
        "013": "montant",
        "014": "fp_taux_de_remuneration_de_la_situation_administrative",
        "015": "taux_de_conduite_centrale_nucleaire",
        "016": "taux_de_majoration",
        "019": "taux_de_remuneration_cotisee",
        "020": "taux_de_majoration_ex_apprenti_ex_eleve",
    },
    "S21.G00.53": {
        "001": "type",
        "002": "mesure",
        "003": "unite_de_mesure",
    },
    "S21.G00.52": {
        "001": "type",
        "002": "montant",
        "003": "date_de_debut_de_la_periode_de_rattachement",
        "004": "date_de_fin_de_la_periode_de_rattachement",
        "006": "numero_du_contrat",
        "007": "date_de_versement_dorigine",
    },
    "S21.G00.54": {
        "001": "type",
        "002": "montant",
        "003": "date_de_debut_de_periode_de_rattachement",
        "004": "date_de_fin_de_periode_de_rattachement",
        "005": "numero_de_contrat",
    },
    "S21.G00.56": {
        "001": "mois_de_l_erreur",
        "002": "type_d_erreur",
        "003": "regularisation_de_la_remuneration_nette_fiscale",
        "004": "remuneration_nette_fiscale_declaree_le_mois_de_l_erreur",
        "005": "regularisation_du_taux_de_prelevement_a_la_source",
        "006": "taux_declare_le_mois_de_l_erreur",
        "007": "montant_de_la_regularisation_du_prelevement_a_la_source",
        "008": "regularisation_du_montant_de_la_part_non_imposable_du_revenu",
        "009": "regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_de_la_remuneration_nette_fiscale",
        "010": "regularisation_du_montant_soumis_au_pas",
        "015": "montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur",
    },
    "S21.G00.58": {
        "001": "date_de_debut_de_periode_de_rattachement",
        "002": "date_de_fin_de_periode_de_rattachement",
        "003": "type",
        "004": "montant",
    },
    "S21.G00.78": {
        "001": "code_de_base_assujettie",
        "002": "date_de_debut_de_periode_de_rattachement",
        "003": "date_de_fin_de_periode_de_rattachement",
        "004": "montant",
        "005": "identifiant_technique_affiliation",
        "006": "numero_du_contrat",
        "007": "identifiant_du_crm_a_lorigine_de_la_regularisation",
    },
    "S21.G00.79": {
        "001": "type_de_composant_de_base_assujettie",
        "004": "montant_de_composant_de_base_assujettie",
        "005": "identifiant_du_crm_a_lorigine_de_la_regularisation",
    },
    "S21.G00.81": {
        "001": "code_de_cotisation",
        "002": "identifiant_organisme_de_protection_sociale",
        "003": "montant_dassiette",
        "004": "montant_de_cotisation",
        "005": "code_insee_commune",
        "006": "identifiant_du_crm_a_lorigine_de_la_regularisation",
        "007": "taux_de_cotisation",
    },
    "S21.G00.83": {
        "001": "date_de_debut_de_periode_declaree_a_tort",
        "002": "date_de_fin_de_periode_declaree_a_tort",
    },
    "S21.G00.84": {
        "001": "code_de_base_assujettie_declaree_a_tort",
        "002": "date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort",
        "003": "date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort",
        "004": "montant_declare_a_tort",
        "005": "numero_du_contrat_rattache_a_la_base_assujettie_declaree_a_tort",
    },
    "S21.G00.95": {
        "001": "code_de_base_assujettie_declaree_a_tort",
        "002": "date_de_debut_de_periode_de_rattachement_de_la_base_declaree_a_tort",
        "003": "date_de_fin_de_periode_de_rattachement_de_la_base_declaree_a_tort",
        "004": "montant_declare_a_tort",
        "005": "numero_du_contrat_rattache_a_la_base_assujettie_declaree_a_tort",
    },
    "S21.G00.86": {
        "001": "type",
        "002": "unite_de_mesure",
        "003": "valeur",
        "005": "numero_du_contrat",
    },
    "S21.G00.98": {
        "001": "identifiant_de_la_satd",
        "002": "etat_de_prise_en_compte_de_la_satd",
        "003": "montant",
        "004": "mois_de_l_erreur",
    },
    "S21.G00.85": {
        "001": "identifiant_du_lieu_de_travail_ou_de_letablissement_utilisateur",
        "002": "code_apet",
        "003": "numero_extension_nature_libelle_de_voie",
        "004": "code_postal",
        "005": "localite",
        "006": "code_pays",
        "007": "code_de_distribution_a_letranger",
        "008": "complement_de_la_localisation_de_la_construction",
        "009": "service_de_distribution_complement_de_localisation_de_la_voie",
        "010": "nature_juridique",
        "011": "code_insee_commune",
    },
    "S89.G00.32": {
        "001": "profession_ou_qualite",
        "002": "nom_du_beneficiaire_des_honoraires",
        "003": "prenom_du_beneficiaire_des_honoraires",
        "004": "siren_du_beneficiaire_des_honoraires",
        "005": "nic_du_beneficiaire_des_honoraires",
        "006": "raison_sociale_du_beneficiaire_des_honoraires",
        "007": "complement_de_localisation_de_la_construction",
        "008": "numero_extension_nature_et_libelle_de_la_voie",
        "009": "code_insee_de_la_commune",
        "010": "service_de_distribution_complement_de_localisation_de_la_voie",
        "011": "code_postal",
        "012": "localite",
        "013": "code_pays",
        "014": "code_de_distribution_a_letranger",
        "015": "code_taux_reduit_ou_dispense_de_retenue_a_la_source",
        "016": "montant_tva_droits_dauteurs",
        "017": "millesime_de_rattachement",
    },
    "S89.G00.33": {
        "001": "code_type_avantage_en_nature",
        "002": "montant_avantage_en_nature",
    },
    "S89.G00.35": {
        "001": "code_modalite_de_prise_en_charge_des_indemnites",
        "002": "montant_de_lindemnite",
    },
    "S89.G00.43": {
        "001": "code_type_de_la_remuneration",
        "002": "montant_de_la_remuneration",
    },
    "S89.G00.67": {
        "001": "nir",
        "002": "numero_technique_temporaire",
        "003": "montant_de_droit_supplementaire_acquis",
        "004": "pourcentage_de_droit_supplementaire_acquis",
        "005": "millesime_de_rattachement",
    },
    "S89.G00.87": {
        "001": "code_contexte",
        "002": "nombre_dactions",
        "003": "valeur_unitaire_de_laction",
        "004": "fraction_du_gain_dacquisition_de_source_francaise",
        "005": "date_dattribution",
        "006": "date_dacquisition_definitive",
        "007": "numero_dinscription_au_repertoire",
        "008": "numero_technique_temporaire",
    },
    "S89.G00.88": {
        "001": "code_contexte",
        "002": "nombre_doptions",
        "003": "valeur_unitaire_de_laction",
        "004": "prix_de_souscription_de_laction",
        "005": "fraction_du_gain_de_levee_doption_de_source_francaise",
        "006": "date_dattribution",
        "007": "date_de_levee_de_loption",
        "008": "numero_dinscription_au_repertoire",
        "009": "numero_technique_temporaire",
    },
    "S89.G00.89": {
        "001": "nombre_de_titres",
        "002": "prix_dacquisition_des_titres",
        "003": "valeur_unitaire_des_titres_au_jour_de_lexercice_des_bons",
        "004": "fraction_du_gain_de_source_francaise",
        "005": "date_dacquisition_des_titres",
        "006": "duree_dexercice_de_lactivite_du_beneficiaire_dans_lentreprise",
        "007": "numero_dinscription_au_repertoire",
        "008": "numero_technique_temporaire",
    },
    "S89.G00.91": {
        "001": "numero_dinscription_au_repertoire",
        "002": "nom_de_famille",
        "003": "nom_dusage",
        "004": "prenoms",
        "005": "sexe",
        "006": "date_de_naissance",
        "007": "lieu_de_naissance",
        "008": "numero_extension_nature_et_libelle_de_la_voie",
        "009": "code_postal",
        "010": "localite",
        "011": "code_pays",
        "012": "code_de_distribution_a_letranger",
        "013": "complement_de_la_localisation_de_la_construction",
        "014": "service_de_distribution_complement_de_localisation_de_la_voie",
        "015": "adresse_mel",
        "016": "matricule_de_lindividu_dans_lentreprise",
        "017": "statut_du_salarie_conventionnel",
        "018": "code_statut_categoriel_retraite_complementaire_obligatoire",
        "019": "code_departement_de_naissance",
        "020": "code_pays_de_naissance",
        "021": "numero_technique_temporaire",
    },
    "S89.G00.92": {
        "001": "type",
        "002": "code_de_base_specifique",
        "003": "montant",
        "004": "date_de_debut_de_periode_de_rattachement",
        "005": "date_de_fin_de_periode_de_rattachement",
        "006": "montant_net_fiscal_du_revenu_verse",
        "007": "taux_de_prelevement_a_la_source",
        "008": "type_du_taux_de_prelevement_a_la_source",
        "009": "identifiant_du_taux_de_prelevement_a_la_source",
        "010": "montant_de_prelevement_a_la_source",
        "011": "date_de_versement",
        "012": "montant_de_la_part_non_imposable_du_revenu",
        "013": "montant_soumis_au_pas",
        "014": "montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse",
        "015": "identifiant_du_crm_a_lorigine_de_la_regularisation",
        "016": "montant_net_verse",
        "017": "montant_net_social",
        "018": "montant_de_la_retenue_a_la_source_sur_les_revenus_verses_aux_non_residents_fiscaux",
    },
    "S89.G00.93": {
        "001": "mois_de_l_erreur",
        "002": "type_d_erreur",
        "003": "regularisation_du_montant_net_fiscal_du_revenu_verse",
        "004": "montant_net_fiscal_du_revenu_verse_le_mois_de_l_erreur",
        "005": "regularisation_du_taux_de_prelevement_a_la_source",
        "006": "taux_declare_le_mois_de_l_erreur",
        "007": "montant_de_la_regularisation_du_prelevement_a_la_source",
        "008": "regularisation_du_montant_de_la_part_non_imposable_du_revenu",
        "009": "regularisation_du_montant_soumis_au_pas",
        "010": "regularisation_du_montant_de_l_abattement_sur_la_base_fiscale_non_deduit_du_montant_net_fiscal_du_revenu_verse",
        "013": "montant_soumis_au_prelevement_a_la_source_declare_le_mois_de_lerreur",
    },
    "S89.G00.94": {
        "001": "code_de_cotisation",
        "002": "montant_de_cotisation",
    },
    "S90.G00.90": {
        "001": "nombre_total_de_rubriques",
        "002": "nombre_de_dsn",
    },
}

# Hiérarchie des blocs (enfant -> parent) générée automatiquement
BLOCK_HIERARCHY: dict[str, str] = {
    "S10.G00.01": "S10.G00.00",
    "S10.G00.02": "S10.G00.00",
    "S20.G00.07": "S20.G00.05",
    "S20.G00.08": "S20.G00.05",
    "S21.G00.06": "S20.G00.05",
    "S21.G00.13": "S21.G00.06",
    "S21.G00.11": "S21.G00.06",
    "S21.G00.12": "S21.G00.11",
    "S21.G00.15": "S21.G00.11",
    "S21.G00.16": "S21.G00.15",
    "S21.G00.82": "S21.G00.11",
    "S21.G00.20": "S21.G00.11",
    "S21.G00.55": "S21.G00.20",
    "S21.G00.22": "S21.G00.11",
    "S21.G00.23": "S21.G00.22",
    "S21.G00.44": "S21.G00.11",
    "S21.G00.30": "S21.G00.11",
    "S21.G00.31": "S21.G00.30",
    "S21.G00.34": "S21.G00.30",
    "S21.G00.40": "S21.G00.30",
    "S21.G00.41": "S21.G00.40",
    "S21.G00.45": "S21.G00.40",
    "S21.G00.60": "S21.G00.40",
    "S21.G00.66": "S21.G00.60",
    "S21.G00.62": "S21.G00.40",
    "S21.G00.63": "S21.G00.62",
    "S21.G00.65": "S21.G00.40",
    "S21.G00.70": "S21.G00.40",
    "S21.G00.73": "S21.G00.70",
    "S21.G00.71": "S21.G00.40",
    "S21.G00.72": "S21.G00.71",
    "S21.G00.50": "S21.G00.30",
    "S21.G00.51": "S21.G00.50",
    "S21.G00.53": "S21.G00.51",
    "S21.G00.52": "S21.G00.50",
    "S21.G00.54": "S21.G00.50",
    "S21.G00.56": "S21.G00.50",
    "S21.G00.58": "S21.G00.50",
    "S21.G00.78": "S21.G00.50",
    "S21.G00.79": "S21.G00.78",
    "S21.G00.81": "S21.G00.78",
    "S21.G00.83": "S21.G00.50",
    "S21.G00.84": "S21.G00.83",
    "S21.G00.95": "S21.G00.50",
    "S21.G00.86": "S21.G00.30",
    "S21.G00.98": "S21.G00.30",
    "S21.G00.85": "S20.G00.05",
    "S89.G00.32": "S20.G00.05",
    "S89.G00.33": "S89.G00.32",
    "S89.G00.35": "S89.G00.32",
    "S89.G00.43": "S89.G00.32",
    "S89.G00.67": "S20.G00.05",
    "S89.G00.87": "S20.G00.05",
    "S89.G00.88": "S20.G00.05",
    "S89.G00.89": "S20.G00.05",
    "S89.G00.91": "S20.G00.05",
    "S89.G00.92": "S89.G00.91",
    "S89.G00.93": "S89.G00.92",
    "S89.G00.94": "S89.G00.92",
}


class DSNParseError(Exception):
    """
    Exception levée lors d'une erreur de parsing DSN.
    Inclut le contexte: ligne, bloc, rubrique.
    """

    def __init__(
        self,
        message: str,
        line_num: int | None = None,
        block_id: str | None = None,
        rubrique_id: str | None = None,
    ):
        self.line_num = line_num
        self.block_id = block_id
        self.rubrique_id = rubrique_id

        context_parts = []
        if line_num is not None:
            context_parts.append(f"ligne {line_num}")
        if block_id is not None:
            context_parts.append(f"bloc {block_id}")
        if rubrique_id is not None:
            context_parts.append(f"rubrique {rubrique_id}")

        if context_parts:
            message = f"{' '.join(context_parts)}: {message}"

        super().__init__(message)


class DSNParser:
    """
    Parser pour les fichiers DSN au format ligne par ligne.
    Format: SXX.GXX.XX.XXX,VALEUR

    Usage:
        parser = DSNParser("dsn.lark")
        message = parser.parse_file("mon_fichier.dsn")
        print(message.header.nom_logiciel)
    """

    def __init__(self, grammar_path: str | Path = "dsn.lark"):
        """
        Initialise le parser avec la grammaire Lark.

        Args:
            grammar_path: Chemin vers le fichier .lark
        """
        self.grammar_path = Path(grammar_path)
        if not self.grammar_path.exists():
            raise FileNotFoundError(f"Grammaire non trouvée: {self.grammar_path}")

        grammar = self.grammar_path.read_text(encoding="utf-8")
        self.parser = Lark(grammar, start="dsn_file", parser="lalr")

    def parse(self, content: str, validate: bool = False) -> DSNMessage:
        """
        Parse une chaîne DSN.

        Args:
            content: Contenu du fichier DSN
            validate: Si True, valide les données après parsing

        Returns:
            DSNMessage parsé
        """
        tree = self.parser.parse(content)
        message = self._tree_to_message(tree)

        if validate:
            message.validate(strict=True)

        return message

    def parse_file(self, path: str | Path, validate: bool = False) -> DSNMessage:
        """
        Parse un fichier DSN.

        Args:
            path: Chemin vers le fichier
            validate: Si True, valide les données après parsing

        Returns:
            DSNMessage parsé
        """
        content = Path(path).read_text(encoding="utf-8")
        return self.parse(content, validate=validate)

    def _tree_to_message(self, tree: Tree) -> DSNMessage:
        """
        Convertit l'arbre de parsing Lark en DSNMessage.
        Format ligne par ligne: regroupe les rubriques par bloc et construit la hiérarchie.
        """
        # Parse toutes les lignes en gardant l'ordre et le numéro de ligne
        parsed_lines = []
        line_num = 0
        for child in tree.children:
            if isinstance(child, Tree) and child.data == "dsn_line":
                line_num += 1
                try:
                    block_id, rubrique_id, value = self._parse_line(child, line_num)
                    if block_id and rubrique_id:
                        parsed_lines.append((block_id, rubrique_id, value))
                except DSNParseError:
                    # Add context and re-raise
                    raise

        # Groupe les lignes par instance de bloc (en séquence)
        block_instances = self._group_lines_into_blocks(parsed_lines)

        # Construit la hiérarchie
        header, declarations, footer = self._build_hierarchy(block_instances)

        if header is None:
            raise DSNParseError(
                "Header S10.G00.00 non trouvé - le fichier DSN doit commencer par un bloc S10.G00.00"
            )

        return DSNMessage(header=header, declarations=declarations, footer=footer)

    def _group_lines_into_blocks(self, parsed_lines: list[tuple]) -> list[dict]:
        """
        Groupe les lignes parsées en instances de blocs.
        Retourne une liste de dicts: {block_id, rubriques: {id: value}}
        """
        if not parsed_lines:
            return []

        instances = []
        current_block_id = None
        current_rubriques = {}

        for block_id, rubrique_id, value in parsed_lines:
            if block_id != current_block_id or rubrique_id in current_rubriques:
                # Nouveau bloc - sauvegarde l'ancien s'il existe
                if current_block_id is not None:
                    instances.append(
                        {
                            "block_id": current_block_id,
                            "rubriques": current_rubriques.copy(),
                        }
                    )
                current_block_id = block_id
                current_rubriques = {}

            current_rubriques[rubrique_id] = value

        # Sauvegarde le dernier bloc
        if current_block_id is not None:
            instances.append({"block_id": current_block_id, "rubriques": current_rubriques.copy()})

        return instances

    def _build_hierarchy(self, block_instances: list[dict]) -> tuple:
        """
        Construit la hiérarchie des blocs avec support multi-niveaux.
        Retourne: (header, declarations, footer)
        """
        header = None
        footer = None
        declarations = []

        # Stack to track nesting: each element is (block_id, block_instance)
        stack = []

        for instance in block_instances:
            block_id = instance["block_id"]
            rubriques = instance["rubriques"]

            # Cas spéciaux pour les blocs de niveau supérieur
            if block_id == "S10.G00.00":
                header = self._create_block("S10.G00.00", rubriques)
                stack = [("S10.G00.00", header)]
                continue
            elif block_id == "S90.G00.90":
                footer = self._create_block("S90.G00.90", rubriques)
                stack = []  # Reset stack after footer
                continue
            elif block_id == "S20.G00.05":
                decl = self._create_block("S20.G00.05", rubriques)
                if decl:
                    declarations.append(decl)
                    # Pop until we find a suitable parent or empty stack
                    while stack and not self._can_be_child_of(stack[-1][0], "S20.G00.05"):
                        stack.pop()
                    if stack:
                        self._attach_child_to_parent(stack[-1][1], "S20.G00.05", decl)
                    stack.append(("S20.G00.05", decl))
                continue

            # Pour les autres blocs, trouver le parent approprié
            block = self._create_child_block(block_id, rubriques)
            if not block:
                continue

            # Remonter la pile jusqu'à trouver un parent qui accepte ce bloc
            while stack and not self._can_be_child_of(stack[-1][0], block_id):
                stack.pop()

            if stack:
                self._attach_child_to_parent(stack[-1][1], block_id, block)
                stack.append((block_id, block))
            elif not header:
                # Si pas de header et pas de parent, c'est un bloc orphelin
                pass

        return header, declarations, footer

    def _can_be_child_of(self, parent_id: str, child_id: str) -> bool:
        """
        Vérifie si un bloc peut être enfant d'un parent donné.
        Utilise la hiérarchie définie dans BLOCK_HIERARCHY (générée depuis Excel).
        """
        # Vérifie si child_id a parent_id comme parent dans la hiérarchie
        if child_id in BLOCK_HIERARCHY:
            return BLOCK_HIERARCHY[child_id] == parent_id

        return False

    def _create_block(self, block_id: str, rubriques: dict[str, str]) -> DSNBlock | None:
        """
        Crée un objet bloc à partir des rubriques.
        Essaie d'abord BLOCK_CLASSES, puis tombe sur l'introspection.
        """
        import dsn_tools.dsn_types as dsn_types
        from dsn_tools.dsn_types import DSNBlock

        block_class = BLOCK_CLASSES.get(block_id)
        if block_class is None:
            class_name = sanitize_class_name(block_id)
            block_class = getattr(dsn_types, class_name, None)

        if block_class is None or not issubclass(block_class, DSNBlock):
            return None

        instance = block_class()
        mapping = RUBRIQUE_MAPPING.get(block_id, {})

        for rubrique_id, value in rubriques.items():
            field_name = mapping.get(rubrique_id)
            if field_name and hasattr(instance, field_name):
                # Convert string to enum if field type is an enum
                converted_value = self._convert_to_enum(instance, field_name, value)
                setattr(instance, field_name, converted_value)

        return instance

    def _convert_to_enum(self, instance: DSNBlock, field_name: str, value: str) -> Any:
        """Convertit une valeur string en enum si le type du champ est un enum."""
        from enum import Enum

        import dsn_tools.enums as enums_module

        # Récupère l'annotation de type du champ
        field_info = instance.__dataclass_fields__.get(field_name)
        if field_info is None:
            return value

        field_type = str(field_info.type)

        # Cherche le nom de classe enum dans le type
        # Formats possibles: "N4DS_Essai", "N4DS_Essai | None", "Optional[N4DS_Essai]"
        for enum_name in dir(enums_module):
            if enum_name.startswith("_") or enum_name == "Enum":
                continue
            enum_class = getattr(enums_module, enum_name)
            if isinstance(enum_class, type) and issubclass(enum_class, Enum):
                if enum_name in field_type:
                    try:
                        return enum_class(value)
                    except ValueError:
                        # Valeur invalide pour cet enum, retourne la chaîne
                        return value

        return value

    def _create_child_block(self, block_id: str, rubriques: dict[str, str]) -> DSNBlock | None:
        """
        Crée un bloc enfant à partir des rubriques.
        Alias pour _create_block pour la compatibilité.
        """
        return self._create_block(block_id, rubriques)

    def _attach_child_to_parent(self, parent: DSNBlock, child_block_id: str, child_block: DSNBlock):
        """
        Attache un bloc enfant à son parent en cherchant le champ par type.
        """
        child_class_name = child_block.__class__.__name__

        # Cherche le champ qui correspond au type du bloc enfant
        for field_name, field_info in parent.__dataclass_fields__.items():
            if field_name.startswith("_"):
                continue

            # Vérifie si le type du champ correspond à la classe de l'enfant
            field_type_str = str(field_info.type)
            if child_class_name in field_type_str:
                field_value = getattr(parent, field_name)
                # Vérifie si c'est une liste ou un champ simple
                if isinstance(field_value, list):
                    field_value.append(child_block)
                    return
                elif field_value is None:
                    setattr(parent, field_name, child_block)
                    return

    def _parse_line(self, tree: Tree, line_num: int | None = None) -> tuple:
        """
        Parse une ligne DSN et retourne (block_id, rubrique_id, value).
        Format: SXX.GXX.XX.XXX,VALEUR
        Nouveau format grammaire avec composants séparés.

        Raises:
            DSNParseError: Si la ligne est malformée
        """
        if not hasattr(tree, "children") or len(tree.children) < 3:
            raise DSNParseError(
                "Ligne malformée: format attendu 'SXX.GXX.XX.XXX,VALEUR'", line_num=line_num
            )

        # tree.children = [block_id_tree, rubrique_id_tree, dsn_value_tree, ...]
        block_id_tree = tree.children[0]
        rubrique_id_tree = tree.children[1]
        dsn_value_tree = tree.children[2]

        # Construit le block_id: S + XX + .G + XX + . + XX
        # block_id children: "S", DIGIT, DIGIT, ".G", DIGIT, DIGIT, ".", DIGIT, DIGIT
        # Mais seuls les DIGIT sont capturés comme tokens
        digits = []
        if isinstance(block_id_tree, Tree) and block_id_tree.data == "block_id":
            for child in block_id_tree.children:
                if isinstance(child, Token) and child.type == "DIGIT":
                    digits.append(str(child))

        if len(digits) >= 6:
            block_id = f"S{digits[0]}{digits[1]}.G{digits[2]}{digits[3]}.{digits[4]}{digits[5]}"
        else:
            raise DSNParseError(
                f"Block ID invalide: attendu format 'SXX.GXX.XX.XXX', reçu {len(digits)} chiffres",
                line_num=line_num,
            )

        # Construit le rubrique_id: XXX
        rubrique_digits = []
        if isinstance(rubrique_id_tree, Tree) and rubrique_id_tree.data == "rubrique_id":
            for child in rubrique_id_tree.children:
                if isinstance(child, Token) and child.type == "DIGIT":
                    rubrique_digits.append(str(child))

        if len(rubrique_digits) >= 3:
            rubrique_id = "".join(rubrique_digits[:3])
        else:
            raise DSNParseError(
                f"Rubrique ID invalide: attendu 3 chiffres, reçu {len(rubrique_digits)}",
                line_num=line_num,
                block_id=block_id,
            )

        # Extrait la valeur (peut être QUOTED_STRING ou UNQUOTED_STRING)
        value = ""
        if isinstance(dsn_value_tree, Tree) and dsn_value_tree.data == "dsn_value":
            if dsn_value_tree.children:
                token = dsn_value_tree.children[0]
                if isinstance(token, Token):
                    value = str(token)
                    # Supprime les guillemets si c'est un QUOTED_STRING
                    if (
                        token.type == "QUOTED_STRING"
                        and value.startswith("'")
                        and value.endswith("'")
                    ):
                        value = value[1:-1]

        return block_id, rubrique_id, value


def parse_dsn(content: str, grammar_path: str = "dsn.lark", validate: bool = False) -> DSNMessage:
    """
    Fonction utilitaire pour parser du contenu DSN.

    Args:
        content: Contenu DSN à parser
        grammar_path: Chemin vers la grammaire Lark
        validate: Valider les données

    Returns:
        DSNMessage parsé
    """
    parser = DSNParser(grammar_path)
    return parser.parse(content, validate=validate)
