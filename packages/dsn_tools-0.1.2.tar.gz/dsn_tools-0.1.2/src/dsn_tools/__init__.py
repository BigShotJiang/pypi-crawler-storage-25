"""
dsn-tools - Parseur et types pour fichiers DSN (Données Sociales Nominatives).

Usage:
    >>> from dsn_tools import DSNParser, DSNMessage
    >>> parser = DSNParser()
    >>> message = parser.parse_file("declaration.dsn")
"""

from dsn_tools.dsn_parser import DSNParseError, DSNParser, parse_dsn
from dsn_tools.dsn_types import DSNBlock, DSNMessage

__version__ = "0.1.0"
__all__ = [
    "DSNBlock",
    "DSNMessage",
    "DSNParseError",
    "DSNParser",
    "parse_dsn",
]
