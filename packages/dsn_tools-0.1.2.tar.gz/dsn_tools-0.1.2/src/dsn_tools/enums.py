"""
Types d'énumération DSN
Généré automatiquement depuis dsn-datatypes-CT2026.xlsx

Ce module contient toutes les énumérations DSN (Données Sociales Nominatives).
Chaque énumération est une classe héritant de str et Enum, permettant :
- La validation de type à l'affectation
- L'autocomplétion IDE
- L'accès aux valeurs et descriptions
"""

from enum import Enum


class Taux_Prelevement_Source(str, Enum):
    TAUX_TRANSMIS_PAR_LA_DGFIP = "01"  # Taux transmis par la DGFIP
    BAREME_MENSUEL_METROPOLE = "13"  # Barème mensuel métropole
    BAREME_MATHEMATIQUE_SUR_BASE_MENSUELLE_METROPOLE = (
        "17"  # Barème mathématique sur base mensuelle métropole
    )
    BAREME_MENSUEL_GUADELOUPE_REUNION_ET_MARTINIQUE = (
        "23"  # Barème mensuel Guadeloupe, Réunion et Martinique
    )
    BAREME_MATHEMATIQUE_SUR_BASE_MENSUELLE_GUADELOUPE_REUNION_ET_MARTINIQUE = (
        "27"  # Barème mathématique sur base mensuelle Guadeloupe, Réunion et Martinique
    )
    BAREME_MENSUEL_GUYANE_ET_MAYOTTE = "33"  # Barème mensuel Guyane et Mayotte
    BAREME_MATHEMATIQUE_SUR_BASE_MENSUELLE_GUYANE_ET_MAYOTTE = (
        "37"  # Barème mathématique sur base mensuelle Guyane et Mayotte
    )
    INDU_RELATIF_A_UN_EXERCICE_ANTERIEUR_PAS_DE_TAUX_DE_PAS = (
        "99"  # Indu relatif à un exercice antérieur – pas de taux de PAS
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Taux transmis par la DGFIP",
        "13": "Bar\u00e8me mensuel m\u00e9tropole",
        "17": "Bar\u00e8me math\u00e9matique sur base mensuelle m\u00e9tropole",
        "23": "Bar\u00e8me mensuel Guadeloupe, R\u00e9union et Martinique",
        "27": "Bar\u00e8me math\u00e9matique sur base mensuelle Guadeloupe, R\u00e9union et Martinique",
        "33": "Bar\u00e8me mensuel Guyane et Mayotte",
        "37": "Bar\u00e8me math\u00e9matique sur base mensuelle Guyane et Mayotte",
        "99": "Indu relatif \u00e0 un exercice ant\u00e9rieur \u2013 pas de taux de PAS",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class N4DS_Essai(str, Enum):
    ENVOI_FICHIER_TEST = "01"  # envoi fichier test
    ENVOI_FICHIER_REEL = "02"  # envoi fichier réel

    __DESCRIPTIONS: dict[str, str] = {
        "01": "envoi fichier test",
        "02": "envoi fichier r\u00e9el",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Unite_Mesure(str, Enum):
    HEURE = "10"  # heure
    JOURNEE = "12"  # journée
    FORFAIT_JOUR = "20"  # forfait jour
    FORFAIT_HEURE = "21"  # forfait heure
    A_LA_PIGE = "31"  # à la pige
    A_LA_VACATION = "32"  # à la vacation
    A_LA_TACHE = "33"  # à la tâche
    HEURES_INTERMITTENTS_DU_SPECTACLE = "35"  # heures intermittents du spectacle
    CACHETS_GROUPES = "36"  # cachets groupés
    CACHETS_ISOLES = "37"  # cachets isolés
    JOUR_CRPNPAC = "38"  # jour CRPNPAC
    CACHET = "39"  # cachet
    JOURS_CALENDAIRES_DE_LA_PERIODE_D_EMPLOI_PRIS_EN_COMPTE_DANS_LE_CALCUL_DU_PLAFOND_DE_SECURITE_SOCIALE = "40"  # jours calendaires de la période d’emploi pris en compte dans le calcul du plafond de Sécurité Sociale
    HEURE_TRAVAILLEE_LE_DIMANCHE_OU_LE_PREMIER_MAI_ESAT = (
        "41"  # heure travaillée le dimanche ou le premier mai (ESAT)
    )

    __DESCRIPTIONS: dict[str, str] = {
        "10": "heure",
        "12": "journ\u00e9e",
        "20": "forfait jour",
        "21": "forfait heure",
        "31": "\u00e0 la pige",
        "32": "\u00e0 la vacation",
        "33": "\u00e0 la t\u00e2che",
        "35": "heures intermittents du spectacle",
        "36": "cachets group\u00e9s",
        "37": "cachets isol\u00e9s",
        "38": "jour CRPNPAC",
        "39": "cachet",
        "40": "jours calendaires de la p\u00e9riode d\u2019emploi pris en compte dans le calcul du plafond de S\u00e9curit\u00e9 Sociale",
        "41": "heure travaill\u00e9e le dimanche ou le premier mai (ESAT)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class ROB_Extension(str, Enum):
    REGIME_LOCAL_ALSACE_MOSELLE = "01"  # régime local Alsace Moselle
    COMPLEMENTAIRE_CAMIEG = "02"  # complémentaire CAMIEG
    REGIME_ALSACE_MOSELLE_ET_COMPLEMENTAIRE_CAMIEG = (
        "03"  # régime Alsace-Moselle et Complémentaire CAMIEG
    )
    NON_APPLICABLE = "99"  # non applicable

    __DESCRIPTIONS: dict[str, str] = {
        "01": "r\u00e9gime local Alsace Moselle",
        "02": "compl\u00e9mentaire CAMIEG",
        "03": "r\u00e9gime Alsace-Moselle et Compl\u00e9mentaire CAMIEG",
        "99": "non applicable",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Qualifiant_Assiette(str, Enum):
    AUTRE_ASSIETTE = "920"  # Autre assiette
    ASSIETTE_PLAFONNEE = "921"  # Assiette plafonnée

    __DESCRIPTIONS: dict[str, str] = {
        "920": "Autre assiette",
        "921": "Assiette plafonn\u00e9e",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Civilite(str, Enum):
    MONSIEUR = "01"  # monsieur
    MADAME = "02"  # madame

    __DESCRIPTIONS: dict[str, str] = {
        "01": "monsieur",
        "02": "madame",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Dispos_PubEmpFormPro_2(str, Enum):
    CUI_CONTRAT_INITIATIVE_EMPLOI = "21"  # CUI - Contrat Initiative Emploi
    PARCOURS_EMPLOI_COMPETENCES_CUI_CAE = "41"  # Parcours Emploi Compétences / CUI - CAE
    CUI_CONTRAT_D_ACCES_A_L_EMPLOI_DOM = "42"  # CUI - Contrat d'accès à l'emploi - DOM
    CONTRAT_DE_PROFESSIONNALISATION = "61"  # Contrat de Professionnalisation
    CONTRAT_D_APPRENTISSAGE_ENTREPRISES_ARTISANALES_OU_DE_MOINS_DE_11_SALARIES_LOI_DU_3_JANVIER_1979 = "64"  # Contrat d'apprentissage entreprises artisanales ou de moins de 11 salariés (loi du 3 janvier 1979)
    CONTRAT_D_APPRENTISSAGE_ENTREPRISES_NON_INSCRITES_AU_REPERTOIRE_DES_METIERS_D_AU_MOINS_11_SALARIES_LOI_DE_1987 = "65"  # Contrat d’apprentissage entreprises non inscrites au répertoire des métiers d’au moins 11 salariés (loi de 1987)
    CONVENTION_INDUSTRIELLE_DE_FORMATION_PAR_LA_RECHERCHE_EN_ENTREPRISE_CIFRE = (
        "66"  # Convention industrielle de formation par la recherche en entreprise (CIFRE)
    )
    CONTRAT_A_DUREE_DETERMINEE_POUR_LES_SENIORS = (
        "70"  # Contrat à durée déterminée pour les séniors
    )
    CONTRAT_A_DUREE_DETERMINEE_D_INSERTION = "71"  # Contrat à durée déterminée d’insertion
    CONTRAT_DE_GENERATION = "80"  # Contrat de génération
    CONTRAT_D_APPRENTISSAGE_SECTEUR_PUBLIC_LOI_DE_1992 = (
        "81"  # Contrat d'apprentissage secteur public (Loi de 1992)
    )
    CONTRAT_DE_VALORISATION_DE_L_EXPERIENCE = "83"  # Contrat de valorisation de l’expérience
    STAGE_DE_LA_FORMATION_PROFESSIONNELLE = "92"  # Stage de la formation professionnelle
    PERIODE_DE_MISE_EN_SITUATION_EN_MILIEU_PROFESSIONNEL = (
        "93"  # Période de mise en situation en milieu professionnel
    )
    CONTRAT_ADULTE_RELAIS = "94"  # Contrat adulte relais
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "21": "CUI - Contrat Initiative Emploi",
        "41": "Parcours Emploi Comp\u00e9tences / CUI - CAE",
        "42": "CUI - Contrat d\u0027acc\u00e8s \u00e0 l\u0027emploi - DOM",
        "61": "Contrat de Professionnalisation",
        "64": "Contrat d\u0027apprentissage entreprises artisanales ou de moins de 11 salari\u00e9s (loi du 3 janvier 1979)",
        "65": "Contrat d\u2019apprentissage entreprises non inscrites au r\u00e9pertoire des m\u00e9tiers d\u2019au moins 11 salari\u00e9s (loi de 1987)",
        "66": "Convention industrielle de formation par la recherche en entreprise (CIFRE)",
        "70": "Contrat \u00e0 dur\u00e9e d\u00e9termin\u00e9e pour les s\u00e9niors",
        "71": "Contrat \u00e0 dur\u00e9e d\u00e9termin\u00e9e d\u2019insertion",
        "80": "Contrat de g\u00e9n\u00e9ration",
        "81": "Contrat d\u0027apprentissage secteur public (Loi de 1992)",
        "83": "Contrat de valorisation de l\u2019exp\u00e9rience",
        "92": "Stage de la formation professionnelle",
        "93": "P\u00e9riode de mise en situation en milieu professionnel",
        "94": "Contrat adulte relais",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Prime_DSN_phase_1(str, Enum):
    INDEMNITE_SPECIFIQUE_DE_RUPTURE_CONVENTIONNELLE = (
        "001"  # Indemnité spécifique de rupture conventionnelle
    )
    INDEMNITE_VERSEE_A_L_OCCASION_DE_LA_CESSATION_FORCEE_DES_FONCTIONS_DES_MANDATAIRES_SOCIAUX = "002"  # Indemnité versée à l'occasion de la cessation forcée des fonctions des mandataires sociaux
    INDEMNITE_LEGALE_DE_MISE_A_LA_RETRAITE_PAR_L_EMPLOYEUR = (
        "003"  # Indemnité légale de mise à la retraite par l'employeur
    )
    INDEMNITE_CONVENTIONNELLE_DE_MISE_A_LA_RETRAITE_PAR_L_EMPLOYEUR = (
        "004"  # Indemnité conventionnelle de mise à la retraite par l'employeur
    )
    INDEMNITE_LEGALE_DE_DEPART_A_LA_RETRAITE_DU_SALARIE = (
        "005"  # Indemnité légale de départ à la retraite du salarié
    )
    INDEMNITE_CONVENTIONNELLE_DE_DEPART_A_LA_RETRAITE_DU_SALARIE = (
        "006"  # Indemnité conventionnelle de départ à la retraite du salarié
    )
    INDEMNITE_LEGALE_DE_LICENCIEMENT = "007"  # Indemnité légale de licenciement
    INDEMNITE_LEGALE_SUPPLEMENTAIRE_DE_LICENCIEMENT = (
        "008"  # Indemnité légale supplémentaire de licenciement
    )
    INDEMNITE_LEGALE_SPECIALE_DE_LICENCIEMENT = "009"  # Indemnité légale spéciale de licenciement
    INDEMNITE_LEGALE_SPECIFIQUE_DE_LICENCIEMENT = (
        "010"  # Indemnité légale spécifique de licenciement
    )
    INDEMNITE_LEGALE_DE_FIN_DE_CDD = "011"  # Indemnité légale de fin de CDD
    INDEMNITE_LEGALE_DE_FIN_DE_MISSION = "012"  # Indemnité légale de fin de mission
    INDEMNITE_LEGALE_DUE_AUX_JOURNALISTES = "013"  # Indemnité légale due aux journalistes
    INDEMNITE_LEGALE_DE_CLIENTELE = "014"  # Indemnité légale de clientèle
    INDEMNITE_LEGALE_DUE_AU_PERSONNEL_NAVIGUANT_DE_L_AVIATION_CIVILE = (
        "015"  # Indemnité légale due au personnel naviguant de l'aviation civile
    )
    INDEMNITE_LEGALE_VERSEE_A_L_APPRENTI = "016"  # Indemnité légale versée à l'apprenti
    DOMMAGES_ET_INTERETS_DUS_A_LA_NON_REMISE_DU_CONTRAT_OU_DUS_A_UN_CDD_OU_A_UNE_RUPTURE_DE_PERIODE_D_ESSAI_DELAI_DE_PREVENANCE = "017"  # Dommages et intérêts dus à la non remise du contrat ou dus à un CDD ou à une rupture de période d’essai (délai de prévenance)
    INDEMNITE_DUE_EN_RAISON_D_UN_SINISTRE = "018"  # Indemnité due en raison d'un sinistre
    INDEMNITE_SUITE_A_CLAUSE_DE_NON_CONCURRENCE = (
        "019"  # Indemnité suite à clause de non concurrence
    )
    INDEMNITE_COMPENSATRICE_DE_CONGES_PAYES = "020"  # Indemnité compensatrice de congés payés
    INDEMNITE_CONVENTIONNELLE_SUPPLEMENTAIRE_AUX_INDEMNITES_LEGALES = (
        "021"  # Indemnité conventionnelle (supplémentaire aux indemnités légales)
    )
    INDEMNITE_TRANSACTIONNELLE = "022"  # Indemnité transactionnelle
    INDEMNITE_COMPENSATRICE_DE_PREAVIS_PAYE_NON_EFFECTUE = (
        "023"  # Indemnité compensatrice de préavis payé non effectué
    )
    INDEMNITE_COMPENSATRICE_DES_DROITS_ACQUIS_DANS_LE_CADRE_D_UN_COMPTE_EPARGNE_TEMPS = (
        "025"  # Indemnité compensatrice des droits acquis dans le cadre d’un compte épargne temps
    )
    PRIME_EXCEPTIONNELLE_LIEE_A_L_ACTIVITE_AVEC_PERIODE_DE_RATTACHEMENT_SPECIFIQUE = (
        "026"  # Prime exceptionnelle liée à l'activité avec période de rattachement spécifique
    )
    PRIME_LIEE_A_L_ACTIVITE_AVEC_PERIODE_DE_RATTACHEMENT_SPECIFIQUE = (
        "027"  # Prime liée à l'activité avec période de rattachement spécifique
    )
    PRIME_NON_LIEE_A_L_ACTIVITE = "028"  # Prime non liée à l'activité
    PRIME_LIEE_AU_REPOS_COMPENSATEUR_OU_AU_RACHAT_DES_JOURS_DE_RTT_AVEC_PERIODE_DE_RATTACHEMENT_SPECIFIQUE = "029"  # Prime liée au repos compensateur ou au rachat des jours de RTT avec période de rattachement spécifique
    PRIME_RACHAT_CET = "030"  # Prime rachat CET
    INDEMNITE_COMPENSATRICE_DE_PREAVIS_POUR_INAPTITUDE_SUITE_AT_OU_MALADIE_PROFESSIONNELLE = "032"  # Indemnité compensatrice de préavis pour inaptitude suite AT ou Maladie Professionnelle
    INDEMNITE_FORFAITAIRE_DE_CONCILIATION_PRUD_HOMALE = (
        "033"  # Indemnité forfaitaire de conciliation prud’homale
    )
    INDEMNITE_DE_CONGES_PAYES_ART_D_3141_32_ET_D_3141_33_DU_CODE_DU_TRAVAIL = (
        "034"  # Indemnité de congés payés (art. D. 3141-32 et D. 3141-33 du Code du travail)
    )
    COMPLEMENT_DE_REMUNERATION_A_LA_CHARGE_DE_L_ETAT = (
        "039"  # Complément de rémunération à la charge de l'Etat
    )
    FP_INDEMNITE_MENSUELLE_DE_TECHNICITE = "040"  # [FP] Indemnité mensuelle de technicité
    FP_INDEMNITE_DE_SUJETIONS_SPECIALES = "041"  # [FP] Indemnité de sujétions spéciales
    FP_INDEMNITE_DE_RISQUE = "042"  # [FP] Indemnité de risque
    FP_PRIME_DE_SUJETIONS_SPECIALES = "043"  # [FP] Prime de sujétions spéciales
    FP_INDEMNITE_DE_SUJETION_SPECIFIQUE = "044"  # [FP] Indemnité de sujétion spécifique
    DOMMAGES_ET_INTERETS_A_LA_NON_REMISE_DU_CONTRAT_DE_MISSION = (
        "045"  # Dommages et intérêts à la non remise du contrat de mission
    )
    INDEMNITE_DE_CONGES_PAYES_ART_L_3141_24_DU_CODE_DU_TRAVAIL = (
        "046"  # Indemnité de congés payés (art. L. 3141-24 du Code du travail)
    )
    FP_GIPA_GARANTIE_INDIVIDUELLE_DU_POUVOIR_D_ACHAT = (
        "047"  # [FP] GIPA - Garantie individuelle du pouvoir d'achat
    )
    INDEMNITE_DE_RESIDENCE = "048"  # Indemnité de résidence
    FP_SUPPLEMENT_FAMILIAL_DE_TRAITEMENT = "049"  # [FP] Supplément familial de traitement
    FP_RIFSEEP_IFSE = "050"  # [FP] RIFSEEP IFSE
    FP_RIFSEEP_CIA = "051"  # [FP] RIFSEEP CIA
    SUPPLEMENT_DE_REMUNERATION_DES_AGENTS_CLASSE_4_NIVEAU_2_POSITION_DE_REMUNERATION_19 = (
        "052"  # Supplément de rémunération des agents classe 4 niveau 2 position de rémunération 19
    )
    SUPPLEMENT_DE_REMUNERATION_DES_AGENTS_CLASSE_1_A_3_ET_5_A_8 = (
        "053"  # Supplément de rémunération des agents classe 1 à 3 et 5 à 8
    )
    SUPPLEMENT_DE_REMUNERATION_AGENTS_ET_EX_AGENTS_DE_CONDUITE = (
        "054"  # Supplément de rémunération agents et ex-agents de conduite
    )
    INDEMNITE_TRANSACTIONNELLE_EXONEREE_FISCALEMENT = (
        "055"  # Indemnité transactionnelle exonérée fiscalement
    )
    INDEMNITE_D_EXPATRIATION = "900"  # Indemnité d'expatriation
    INDEMNITE_D_IMPATRIATION = "901"  # Indemnité d'impatriation
    POTENTIEL_NOUVEAU_TYPE_DE_PRIME_EXCEPTIONNELLE_DE_POUVOIR_D_ACHAT_PEPA = (
        "902"  # Potentiel nouveau type de prime exceptionnelle de pouvoir d'achat (PEPA)
    )
    AUTRE_PRIME_EXONEREE_DE_COTISATION_CONTRIBUTION_SOCIALE_ET_IMPOT_SUR_LE_REVENU = (
        "903"  # Autre prime exonérée de cotisation, contribution sociale et impôt sur le revenu
    )
    PRIME_DE_PARTAGE_DE_LA_VALEUR_EXONEREE_SOCIALEMENT_ET_NON_IMPOSABLE = (
        "904"  # Prime de partage de la valeur exonérée socialement et non imposable
    )
    PRIME_DE_PARTAGE_DE_LA_VALEUR_EXONEREE_SOCIALEMENT_ET_IMPOSABLE = (
        "905"  # Prime de partage de la valeur exonérée socialement et imposable
    )
    PRIME_DE_PARTAGE_DE_LA_VALEUR_SOUMISE_A_LA_CSG_CRDS_ET_EXONEREE_SOCIALEMENT_ET_NON_IMPOSABLE = "906"  # Prime de partage de la valeur soumise à la CSG-CRDS et exonérée socialement et non imposable
    POTENTIEL_NOUVEAU_TYPE_DE_PRIME_B = "907"  # Potentiel nouveau type de prime B
    POTENTIEL_NOUVEAU_TYPE_DE_PRIME_C = "908"  # Potentiel nouveau type de prime C
    POTENTIEL_NOUVEAU_TYPE_DE_PRIME_D = "909"  # Potentiel nouveau type de prime D
    POTENTIEL_NOUVEAU_TYPE_DE_PRIME_E = "910"  # Potentiel nouveau type de prime E
    POTENTIEL_NOUVEAU_TYPE_DE_PRIME_A = "911"  # Potentiel nouveau type de prime A

    __DESCRIPTIONS: dict[str, str] = {
        "001": "Indemnit\u00e9 sp\u00e9cifique de rupture conventionnelle",
        "002": "Indemnit\u00e9 vers\u00e9e \u00e0 l\u0027occasion de la cessation forc\u00e9e des fonctions des mandataires sociaux",
        "003": "Indemnit\u00e9 l\u00e9gale de mise \u00e0 la retraite par l\u0027employeur",
        "004": "Indemnit\u00e9 conventionnelle de mise \u00e0 la retraite par l\u0027employeur",
        "005": "Indemnit\u00e9 l\u00e9gale de d\u00e9part \u00e0 la retraite du salari\u00e9",
        "006": "Indemnit\u00e9 conventionnelle de d\u00e9part \u00e0 la retraite du salari\u00e9",
        "007": "Indemnit\u00e9 l\u00e9gale de licenciement",
        "008": "Indemnit\u00e9 l\u00e9gale suppl\u00e9mentaire de licenciement",
        "009": "Indemnit\u00e9 l\u00e9gale sp\u00e9ciale de licenciement",
        "010": "Indemnit\u00e9 l\u00e9gale sp\u00e9cifique de licenciement",
        "011": "Indemnit\u00e9 l\u00e9gale de fin de CDD",
        "012": "Indemnit\u00e9 l\u00e9gale de fin de mission",
        "013": "Indemnit\u00e9 l\u00e9gale due aux journalistes",
        "014": "Indemnit\u00e9 l\u00e9gale de client\u00e8le",
        "015": "Indemnit\u00e9 l\u00e9gale due au personnel naviguant de l\u0027aviation civile",
        "016": "Indemnit\u00e9 l\u00e9gale vers\u00e9e \u00e0 l\u0027apprenti",
        "017": "Dommages et int\u00e9r\u00eats dus \u00e0 la non remise du contrat ou dus \u00e0 un CDD ou \u00e0 une rupture de p\u00e9riode d\u2019essai (d\u00e9lai de pr\u00e9venance)",
        "018": "Indemnit\u00e9 due en raison d\u0027un sinistre",
        "019": "Indemnit\u00e9 suite \u00e0 clause de non concurrence",
        "020": "Indemnit\u00e9 compensatrice de cong\u00e9s pay\u00e9s",
        "021": "Indemnit\u00e9 conventionnelle (suppl\u00e9mentaire aux indemnit\u00e9s l\u00e9gales)",
        "022": "Indemnit\u00e9 transactionnelle",
        "023": "Indemnit\u00e9 compensatrice de pr\u00e9avis pay\u00e9 non effectu\u00e9",
        "025": "Indemnit\u00e9 compensatrice des droits acquis dans le cadre d\u2019un compte \u00e9pargne temps",
        "026": "Prime exceptionnelle li\u00e9e \u00e0 l\u0027activit\u00e9 avec p\u00e9riode de rattachement sp\u00e9cifique",
        "027": "Prime li\u00e9e \u00e0 l\u0027activit\u00e9 avec p\u00e9riode de rattachement sp\u00e9cifique",
        "028": "Prime non li\u00e9e \u00e0 l\u0027activit\u00e9",
        "029": "Prime li\u00e9e au repos compensateur ou au rachat des jours de RTT avec p\u00e9riode de rattachement sp\u00e9cifique",
        "030": "Prime rachat CET",
        "032": "Indemnit\u00e9 compensatrice de pr\u00e9avis pour inaptitude suite AT ou Maladie Professionnelle",
        "033": "Indemnit\u00e9 forfaitaire de conciliation prud\u2019homale",
        "034": "Indemnit\u00e9 de cong\u00e9s pay\u00e9s (art. D. 3141-32 et D. 3141-33 du Code du travail)",
        "039": "Compl\u00e9ment de r\u00e9mun\u00e9ration \u00e0 la charge de l\u0027Etat",
        "040": "[FP] Indemnit\u00e9 mensuelle de technicit\u00e9",
        "041": "[FP] Indemnit\u00e9 de suj\u00e9tions sp\u00e9ciales",
        "042": "[FP] Indemnit\u00e9 de risque",
        "043": "[FP] Prime de suj\u00e9tions sp\u00e9ciales",
        "044": "[FP] Indemnit\u00e9 de suj\u00e9tion sp\u00e9cifique",
        "045": "Dommages et int\u00e9r\u00eats \u00e0 la non remise du contrat de mission",
        "046": "Indemnit\u00e9 de cong\u00e9s pay\u00e9s (art. L. 3141-24 du Code du travail)",
        "047": "[FP] GIPA - Garantie individuelle du pouvoir d\u0027achat",
        "048": "Indemnit\u00e9 de r\u00e9sidence",
        "049": "[FP] Suppl\u00e9ment familial de traitement",
        "050": "[FP] RIFSEEP IFSE",
        "051": "[FP] RIFSEEP CIA",
        "052": "Suppl\u00e9ment de r\u00e9mun\u00e9ration des agents classe 4 niveau 2 position de r\u00e9mun\u00e9ration 19",
        "053": "Suppl\u00e9ment de r\u00e9mun\u00e9ration des agents classe 1 \u00e0 3 et 5 \u00e0 8",
        "054": "Suppl\u00e9ment de r\u00e9mun\u00e9ration agents et ex-agents de conduite",
        "055": "Indemnit\u00e9 transactionnelle exon\u00e9r\u00e9e fiscalement",
        "900": "Indemnit\u00e9 d\u0027expatriation",
        "901": "Indemnit\u00e9 d\u0027impatriation",
        "902": "Potentiel nouveau type de prime exceptionnelle de pouvoir d\u0027achat (PEPA)",
        "903": "Autre prime exon\u00e9r\u00e9e de cotisation, contribution sociale et imp\u00f4t sur le revenu",
        "904": "Prime de partage de la valeur exon\u00e9r\u00e9e socialement et non imposable",
        "905": "Prime de partage de la valeur exon\u00e9r\u00e9e socialement et imposable",
        "906": "Prime de partage de la valeur soumise \u00e0 la CSG-CRDS et exon\u00e9r\u00e9e socialement et non imposable",
        "907": "Potentiel nouveau type de prime B",
        "908": "Potentiel nouveau type de prime C",
        "909": "Potentiel nouveau type de prime D",
        "910": "Potentiel nouveau type de prime E",
        "911": "Potentiel nouveau type de prime A",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Arret_Motif_DSN_phase_1(str, Enum):
    MALADIE = "01"  # maladie
    MATERNITE = "02"  # maternité
    PATERNITE_ACCUEIL_DE_L_ENFANT = "03"  # paternité / accueil de l’enfant
    CONGE_SUITE_A_UN_ACCIDENT_DE_TRAJET = "04"  # congé suite à un accident de trajet
    CONGE_SUITE_A_MALADIE_PROFESSIONNELLE = "05"  # congé suite à maladie professionnelle
    CONGE_SUITE_A_ACCIDENT_DE_TRAVAIL_OU_DE_SERVICE = (
        "06"  # congé suite à accident de travail ou de service
    )
    FEMME_ENCEINTE_DISPENSEE_DE_TRAVAIL = "07"  # femme enceinte dispensée de travail
    ADOPTION = "09"  # adoption
    FP_CONGE_SUITE_A_UNE_MALADIE_IMPUTABLE_AU_SERVICE = (
        "10"  # [FP] Congé suite à une maladie imputable au service
    )
    FP_CONGE_DE_MALADIE_DES_VICTIMES_OU_REFORMES_DE_GUERRE_ART_41 = (
        "11"  # [FP] Congé de maladie des victimes ou réformés de guerre (art 41)
    )
    FP_CONGE_DE_LONGUE_DUREE = "12"  # [FP] Congé de longue durée
    FP_CONGE_DE_LONGUE_MALADIE = "13"  # [FP] Congé de longue maladie
    FP_CONGE_POUR_INVALIDITE_TEMPORAIRE_IMPUTABLE_AU_SERVICE = (
        "14"  # [FP] Congé pour invalidité temporaire imputable au service
    )
    TEMPS_PARTIEL_THERAPEUTIQUE_RISQUE_MALADIE = (
        "15"  # temps partiel thérapeutique (risque maladie)
    )
    TEMPS_PARTIEL_THERAPEUTIQUE_RISQUE_ACCIDENT_DE_TRAVAIL = (
        "16"  # temps partiel thérapeutique (risque accident de travail)
    )
    TEMPS_PARTIEL_THERAPEUTIQUE_RISQUE_ACCIDENT_DE_TRAJET = (
        "17"  # temps partiel thérapeutique (risque accident de trajet)
    )
    TEMPS_PARTIEL_THERAPEUTIQUE_RISQUE_MALADIE_PROFESSIONNELLE = (
        "18"  # temps partiel thérapeutique (risque maladie professionnelle)
    )
    DEUIL_D_ENFANT = "19"  # Deuil d'enfant
    POTENTIEL_NOUVEAU_MOTIF_D_ARRET_A = "20"  # Potentiel nouveau motif d’arrêt A
    POTENTIEL_NOUVEAU_MOTIF_D_ARRET_B = "21"  # Potentiel nouveau motif d’arrêt B
    POTENTIEL_NOUVEAU_MOTIF_D_ARRET_C = "22"  # Potentiel nouveau motif d’arrêt C
    POTENTIEL_NOUVEAU_MOTIF_D_ARRET_D = "23"  # Potentiel nouveau motif d’arrêt D
    POTENTIEL_NOUVEAU_MOTIF_D_ARRET_E = "24"  # Potentiel nouveau motif d’arrêt E
    ANNULATION = "99"  # annulation

    __DESCRIPTIONS: dict[str, str] = {
        "01": "maladie",
        "02": "maternit\u00e9",
        "03": "paternit\u00e9 / accueil de l\u2019enfant",
        "04": "cong\u00e9 suite \u00e0 un accident de trajet",
        "05": "cong\u00e9 suite \u00e0 maladie professionnelle",
        "06": "cong\u00e9 suite \u00e0 accident de travail ou de service",
        "07": "femme enceinte dispens\u00e9e de travail",
        "09": "adoption",
        "10": "[FP] Cong\u00e9 suite \u00e0 une maladie imputable au service",
        "11": "[FP] Cong\u00e9 de maladie des victimes ou r\u00e9form\u00e9s de guerre (art 41)",
        "12": "[FP] Cong\u00e9 de longue dur\u00e9e",
        "13": "[FP] Cong\u00e9 de longue maladie",
        "14": "[FP] Cong\u00e9 pour invalidit\u00e9 temporaire imputable au service",
        "15": "temps partiel th\u00e9rapeutique (risque maladie)",
        "16": "temps partiel th\u00e9rapeutique (risque accident de travail)",
        "17": "temps partiel th\u00e9rapeutique (risque accident de trajet)",
        "18": "temps partiel th\u00e9rapeutique (risque maladie professionnelle)",
        "19": "Deuil d\u0027enfant",
        "20": "Potentiel nouveau motif d\u2019arr\u00eat A",
        "21": "Potentiel nouveau motif d\u2019arr\u00eat B",
        "22": "Potentiel nouveau motif d\u2019arr\u00eat C",
        "23": "Potentiel nouveau motif d\u2019arr\u00eat D",
        "24": "Potentiel nouveau motif d\u2019arr\u00eat E",
        "99": "annulation",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Type_Activite(str, Enum):
    TRAVAIL_REMUNERE = "01"  # Travail rémunéré
    DUREE_D_ABSENCE_PARTIELLEMENT_OU_PAS_DU_TOUT_REMUNEREE = (
        "02"  # Durée d'absence partiellement ou pas du tout rémunérée
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Travail r\u00e9mun\u00e9r\u00e9",
        "02": "Dur\u00e9e d\u0027absence partiellement ou pas du tout r\u00e9mun\u00e9r\u00e9e",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Ref_Code_Cotis(str, Enum):
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_APPRENTI_LOI_DE_1979 = (
        "001"  # Exonération de cotisations au titre de l'emploi d'un apprenti (loi de 1979)
    )
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_APPRENTI_LOI_DE_1987 = (
        "002"  # Exonération de cotisations au titre de l'emploi d'un apprenti (loi de 1987)
    )
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_APPRENTI_LOI_DE_1992 = (
        "003"  # Exonération de cotisations au titre de l'emploi d'un apprenti (loi de 1992)
    )
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_SALARIE_EN_CONTRAT_D_ACCES_A_L_EMPLOI = "004"  # Exonération de cotisations au titre de l'emploi d'un salarié en contrat d'accès à l'emploi
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_SALARIE_EN_CONTRAT_D_ACCOMPAGNEMENT_DANS_L_EMPLOI = "006"  # Exonération de cotisations au titre de l'emploi d'un salarié en contrat d'accompagnement dans l'emploi
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_SALARIE_EN_CONTRAT_DE_PROFESSIONNALISATION = "008"  # Exonération de cotisations au titre de l'emploi d'un salarié en contrat de professionnalisation
    EXONERATION_DE_COTISATIONS_APPLICABLE_AUX_ASSOCIATIONS_INTERMEDIAIRES = (
        "009"  # Exonération de cotisations applicable aux associations intermédiaires
    )
    EXONERATION_DE_COTISATIONS_APPLICABLE_AUX_ENTREPRISES_DES_BASSINS_D_EMPLOI_A_REDYNAMISER = "010"  # Exonération de cotisations applicable aux entreprises des bassins d'emploi à redynamiser
    EXONERATION_DE_COTISATIONS_APPLICABLE_AU_CREATEUR_OU_REPRENEUR_D_ENTREPRISE = (
        "011"  # Exonération de cotisations applicable au créateur ou repreneur d'entreprise
    )
    EXONERATION_DE_COTISATIONS_APPLICABLE_DANS_LES_DOM = (
        "012"  # Exonération de cotisations applicable dans les DOM
    )
    EXONERATION_DE_COTISATIONS_APPLICABLE_AUX_ENTREPRISES_ET_ASSOCIATIONS_D_AIDE_A_DOMICILE = "013"  # Exonération de cotisations applicable aux entreprises et associations d'aide à domicile
    EXONERATIONS_DE_COTISATIONS_APPLICABLE_AUX_ENTREPRISES_INNOVANTES_UNIVERSITAIRES_OU_DE_CROISSANCE = "014"  # Exonérations de cotisations applicable aux entreprises innovantes, universitaires ou de croissance
    EXONERATION_DE_COTISATIONS_APPLICABLE_AUX_ENTREPRISES_EN_ZONES_FRANCHES_URBAINES = (
        "015"  # Exonération de cotisations applicable aux entreprises en zones franches urbaines
    )
    EXONERATION_DE_COTISATIONS_APPLICABLE_AUX_ORGANISMES_D_INTERET_GENERAL_EN_ZONES_DE_REVITALISATION_RURALE = "016"  # Exonération de cotisations applicable aux organismes d'intérêt général en zones de revitalisation rurale
    EXONERATION_DE_COTISATIONS_APPLICABLE_AUX_STRUCTURES_AGREEES_DE_L_AIDE_SOCIALE = (
        "017"  # Exonération de cotisations applicable aux structures agréées de l'aide sociale
    )
    REDUCTION_GENERALE_DES_COTISATIONS_PATRONALES_DE_SECURITE_SOCIALE_ET_D_ASSURANCE_CHOMAGE = "018"  # Réduction générale des cotisations patronales de sécurité sociale et d'assurance chômage
    REDUCTION_DE_COTISATIONS_APPLICABLE_AUX_ENTREPRISES_DES_ZONES_DE_RESTRUCTURATION_DE_LA_DEFENSE = "019"  # Réduction de cotisations applicable aux entreprises des zones de restructuration de la défense
    REDUCTION_DE_COTISATIONS_AU_TITRE_DE_L_EMBAUCHE_DU_1ER_AU_50EME_SALARIE_EN_ZONES_DE_REVITALISATION_RURALE = "020"  # Réduction de cotisations au titre de l'embauche du 1er au 50ème salarié en zones de revitalisation rurale
    DEDUCTION_PATRONALE_AU_TITRE_DES_HEURES_SUPPLEMENTAIRES = (
        "021"  # Déduction patronale au titre des heures supplémentaires
    )
    EXONERATION_DE_COTISATIONS_APPLICABLE_A_UNE_GRATIFICATION_DE_STAGE = (
        "022"  # Exonération de cotisations applicable à une gratification de stage
    )
    EXONERATION_DE_COTISATION_DES_SOMMES_PROVENANT_D_UN_CET_ET_REAFFECTEES_A_UN_PLAN_D_EPARGNE_RETRAITE_PERCO_PERECO_PEREO_OU_A_UN_REGIME_DE_RETRAITE_SUPPLEMENTAIRE = "023"  # Exonération de cotisation des sommes provenant d'un CET et réaffectées à un plan d'épargne retraite (PERCO, PERECO, PEREO) ou à un régime de retraite supplémentaire
    EXONERATION_DE_COTISATIONS_AU_TITRE_DE_L_EMPLOI_D_UN_SALARIE_EN_CHANTIER_ET_ATELIER_D_INSERTION = "025"  # Exonération de cotisations au titre de l’emploi d’un salarié en chantier et atelier d'insertion
    EXONERATION_PERSONNEL_TECHNIQUE_CUMA_HORS_ATELIERS = (
        "027"  # Exonération Personnel technique CUMA, hors ateliers
    )
    REDUCTION_TRAVAILLEUR_OCCASIONNEL = "028"  # Réduction Travailleur Occasionnel
    REDUCTION_EMPLOYEURS_PETIT_POOL_IEG = "029"  # Réduction employeurs petit pool IEG
    COTISATION_EMPLOYEURS_REGIME_SPECIAL_MALADIE_IEG_COMPLEMENTAIRE = (
        "030"  # Cotisation employeurs régime spécial maladie IEG Complémentaire
    )
    COTISATION_SALARIES_REGIME_SPECIAL_MALADIE_IEG_COMPLEMENTAIRE = (
        "031"  # Cotisation salariés régime spécial maladie IEG Complémentaire
    )
    COTISATION_SALARIES_REGIME_MALADIE_IEG_SPECIAL_SOLIDARITE = (
        "032"  # Cotisation salariés régime maladie IEG spécial Solidarité
    )
    COTISATION_EMPLOYEURS_COMPLEMENT_D_INVALIDITE_IEG = (
        "033"  # Cotisation employeurs complément d'invalidité IEG
    )
    COTISATION_EMPLOYEURS_REGIME_DE_DROIT_COMMUN_IEG_POPULATION_ADOSSEE = (
        "034"  # Cotisation employeurs régime de droit commun IEG (population adossée)
    )
    COTISATION_EMPLOYEURS_REGIME_SPECIAL_IEG_POPULATION_ADOSSEE = (
        "035"  # Cotisation employeurs régime spécial IEG (population adossée)
    )
    COTISATION_EMPLOYEURS_REGIME_SPECIAL_IEG_POPULATION_NON_ADOSSEE = (
        "036"  # Cotisation employeurs régime spécial IEG (population non adossée)
    )
    COTISATION_SALARIES_REGIME_DE_DROIT_COMMUN_IEG_POPULATION_ADOSSEE = (
        "037"  # Cotisation salariés régime de droit commun IEG (population adossée)
    )
    COTISATION_SALARIES_REGIME_SPECIAL_IEG_POPULATION_NON_ADOSSEE = (
        "038"  # Cotisation salariés régime spécial IEG (population non adossée)
    )
    COTISATIONS_EMPLOYEURS_PETIT_POOL_IEG = "039"  # Cotisations employeurs petit pool IEG
    COTISATION_AC_ASSURANCE_CHOMAGE_SUR_REMUNERATIONS_BRUTES_APRES_DEDUCTION = (
        "040"  # Cotisation AC : assurance chômage sur rémunérations brutes après déduction
    )
    COTISATION_AC_MAJOREE_1_APPLICATION_D_UNE_MAJORATION_AC_0_5_SUR_LES_CONTRATS_D_USAGE_INFERIEURS_OU_EGAUX_A_3_MOIS = "041"  # Cotisation AC majorée 1 : application d’une majoration AC + 0,5% sur les contrats d’usage inférieurs ou égaux à 3 mois
    COTISATION_AC_MAJOREE_2_APPLICATION_D_UNE_MAJORATION_AC_3_SUR_LES_CONTRATS_D_ACCROISSEMENT_TEMPORAIRE_D_ACTIVITE_INFERIEURS_OU_EGAUX_A_1_MOIS = "042"  # Cotisation AC majorée 2 : application d’une majoration AC + 3% sur les contrats d’accroissement temporaire d’activité inférieurs ou égaux à 1 mois
    COTISATION_AC_MAJOREE_3_APPLICATION_D_UNE_MAJORATION_AC_1_5_SUR_LES_CONTRATS_D_ACCROISSEMENT_TEMPORAIRE_D_ACTIVITE_SUPERIEURS_A_1_MOIS_MAIS_INFERIEURS_OU_EGAUX_A_3_MOIS = "043"  # Cotisation AC majorée 3 : application d’une majoration AC + 1,5% sur les contrats d’accroissement temporaire d’activité supérieurs à 1 mois mais inférieurs ou égaux à 3 mois
    EXONERATION_DE_COTISATION_CHOMAGE_POUR_LES_MOINS_DE_26_ANS = (
        "044"  # Exonération de cotisation chômage pour les moins de 26 ans
    )
    COTISATION_ACCIDENT_DU_TRAVAIL = "045"  # Cotisation Accident du travail
    COTISATION_AEF_BOURSE_DE_L_EMPLOI = "046"  # Cotisation AEF Bourse de l'emploi
    COTISATION_AEF_CESA = "047"  # Cotisation AEF CESA
    COTISATION_AGS_ASSURANCE_GARANTIE_DES_SALAIRES_SUR_REMUNERATIONS_BRUTES_APRES_DEDUCTION = "048"  # Cotisation AGS : assurance garantie des salaires sur rémunérations brutes après déduction
    COTISATION_ALLOCATION_DE_LOGEMENT_FNAL = "049"  # Cotisation Allocation de logement (FNAL)
    COTISATION_FORMATION_PROFESSIONNELLE_ADEFA = "051"  # Cotisation Formation professionnelle ADEFA
    COTISATION_FORMATION_PROFESSIONNELLE_ADDITIONNELLE_FAFSEA = (
        "053"  # Cotisation Formation professionnelle additionnelle FAFSEA
    )
    COTISATION_FORMATION_PROFESSIONNELLE_AREFA = "054"  # Cotisation Formation professionnelle AREFA
    COTISATION_FORMATION_PROFESSIONNELLE_FAFSEA = (
        "056"  # Cotisation Formation professionnelle FAFSEA
    )
    COTISATION_FORMATION_PROFESSIONNELLE_FAFSEA_CDD = (
        "057"  # Cotisation Formation professionnelle FAFSEA CDD
    )
    COTISATION_FORMATION_PROFESSIONNELLE_FAFSEA_DES_COMMUNES_FORESTIERES = (
        "058"  # Cotisation Formation professionnelle FAFSEA des communes forestières
    )
    COTISATION_INDIVIDUELLE_PREVOYANCE_ASSURANCE_MUTUELLE_POUR_LA_PERIODE_ET_L_AFFILIATION_CONCERNEES = "059"  # Cotisation individuelle Prévoyance-Assurance-Mutuelle pour la période et l'affiliation concernées
    COTISATION_IRCANTEC_TRANCHE_A = "060"  # Cotisation IRCANTEC Tranche A
    COTISATION_IRCANTEC_TRANCHE_B = "061"  # Cotisation IRCANTEC Tranche B
    COTISATION_CRPCEN = "065"  # Cotisation CRPCEN
    COTISATION_CAISSE_DE_CONGES_SPECTACLES = "066"  # Cotisation caisse de congés spectacles
    CONTRIBUTION_SOLIDARITE_AUTONOMIE = "068"  # Contribution solidarité autonomie
    CONTRIBUTION_SUR_AVANTAGE_DE_PRE_RETRAITE_ENTREPRISE_A_DATER_DU_11_10_2007_CAPE = (
        "069"  # Contribution sur avantage de pré-retraite entreprise à dater du 11/10/2007 (CAPE)
    )
    CONTRIBUTION_SUR_AVANTAGE_DE_PRE_RETRAITE_ENTREPRISE_AUX_TAUX_NORMAL_CAPE = (
        "070"  # Contribution sur avantage de pré-retraite entreprise aux taux normal (CAPE)
    )
    CONTRIBUTION_FORFAIT_SOCIAL = "071"  # Contribution forfait social
    CONTRIBUTION_SOCIALE_GENERALISEE_SALAIRES_PARTIELLEMENT_DEDUCTIBLES = (
        "072"  # Contribution sociale généralisée/salaires partiellement déductibles
    )
    CSG_CRDS_SUR_PARTICIPATION_INTERESSEMENT_EPARGNE_SALARIALE = (
        "073"  # CSG/CRDS sur participation intéressement épargne salariale
    )
    COTISATION_ALLOCATION_FAMILIALE_TAUX_NORMAL = (
        "074"  # Cotisation Allocation familiale - taux normal
    )
    COTISATION_ASSURANCE_MALADIE = "075"  # Cotisation Assurance Maladie
    COTISATION_ASSURANCE_VIEILLESSE = "076"  # Cotisation Assurance Vieillesse
    MONTANT_DE_LA_RETENUE_A_LA_SOURCE_EFFECTUEE_SUR_LES_SALAIRES_VERSES_AUX_PERSONNES_DOMICILIEES_HORS_DE_FRANCE = "077"  # Montant de la retenue à la source effectuée sur les salaires versés aux personnes domiciliées hors de France
    PENALITE_DE_1_EMPLOI_SENIOR = "078"  # Pénalité de 1% emploi sénior
    REMBOURSEMENT_DE_LA_DETTE_SOCIALE = "079"  # Remboursement de la dette sociale
    VERSEMENT_MOBILITE = "081"  # Versement mobilité
    VERSEMENT_MOBILITE_ADDITIONNEL = "082"  # Versement mobilité additionnel
    EXONERATION_VERSEMENT_MOBILITE = "088"  # Exonération versement mobilité
    EXONERATION_CONTRAT_INITIATIVE_EMPLOI = "089"  # Exonération Contrat Initiative Emploi
    EXONERATION_ACCUEILLANTS_FAMILIAUX = "090"  # Exonération accueillants familiaux
    COTISATION_SERVICE_DE_SANTE_AU_TRAVAIL = "091"  # Cotisation Service de santé au travail
    COTISATION_ASSOCIATION_POUR_L_EMPLOI_DES_CADRES_INGENIEURS_ET_TECHNICIENS_DE_L_AGRICULTURE_APECITA = "092"  # Cotisation Association pour l'emploi des cadres ingénieurs et techniciens de l'agriculture (APECITA)
    CONTRIBUTION_SUR_INDEMNITES_DE_MISE_A_LA_RETRAITE_OU_DE_RUPTURE_CONVENTIONNELLE_INDIVIDUELLE = "093"  # Contribution sur indemnités de mise à la retraite ou de rupture conventionnelle individuelle
    EXONERATION_COTISATIONS_ALLOCATIONS_FAMILIALES_SICAE = (
        "094"  # Exonération cotisations Allocations familiales (SICAE)
    )
    COTISATION_CRPNPAC_AU_FONDS_DE_RETRAITE = "096"  # Cotisation CRPNPAC au fonds de retraite
    COTISATION_CRPNPAC_AU_FONDS_D_ASSURANCE = "097"  # Cotisation CRPNPAC au fonds d'assurance
    COTISATION_CRPNPAC_AU_FONDS_DE_MAJORATION = "098"  # Cotisation CRPNPAC au fonds de majoration
    CONTRIBUTION_STOCK_OPTIONS = "099"  # Contribution stock options
    CONTRIBUTION_AU_FINANCEMENT_DU_DIALOGUE_SOCIAL = (
        "100"  # Contribution au financement du dialogue social
    )
    ASSOCIATION_MUTUALISATION_DU_COUT_INAPTITUDE = (
        "101"  # Association Mutualisation du Coût Inaptitude
    )
    COMPLEMENT_DE_COTISATION_ALLOCATION_FAMILIALE = (
        "102"  # Complément de cotisation Allocation Familiale
    )
    CONTRIBUTION_ACTIONS_GRATUITES = "103"  # Contribution actions gratuites
    PENIBILITE_COTISATION_DE_BASE = "104"  # Pénibilité Cotisation de base
    MONTANT_DE_COTISATION_REGIME_UNIFIE_AGIRC_ARRCO_Y_COMPRIS_APEC = (
        "105"  # Montant de cotisation Régime Unifié Agirc-Arrco, y compris Apec
    )
    REDUCTION_GENERALE_DES_COTISATIONS_PATRONALES_DE_RETRAITE_COMPLEMENTAIRE = (
        "106"  # Réduction générale des cotisations patronales de retraite complémentaire
    )
    FORFAIT_MARIN = "107"  # Forfait marin
    DEMI_ROLE_MARIN = "108"  # Demi-rôle marin
    EXONERATION_DE_COTISATIONS_SALARIALES_DE_RETRAITE_COMPLEMENTAIRE_AU_TITRE_DE_L_EMPLOI_D_UN_APPRENTI = "109"  # Exonération de cotisations salariales de retraite complémentaire au titre de l'emploi d'un apprenti
    EXONERATION_DE_COTISATIONS_PATRONALES_DE_RETRAITE_COMPLEMENTAIRE_APPLICABLE_DANS_LES_DOM_LODEOM_SMIC_130_A_220 = "110"  # Exonération de cotisations patronales de retraite complémentaire applicable dans les DOM (LODEOM) SMIC 130% à 220%
    EXONERATION_DE_COTISATIONS_DE_RETRAITE_COMPLEMENTAIRE_APPLICABLE_AUX_ENTREPRISES_ET_ASSOCIATIONS_D_AIDE_A_DOMICILE = "111"  # Exonération de cotisations de retraite complémentaire applicable aux entreprises et associations d'aide à domicile
    EXONERATION_DE_COTISATIONS_PATRONALES_DE_RETRAITE_COMPLEMENTAIRE_APPLICABLE_DANS_LES_DOM_LODEOM_SMIC_170_A_270 = "112"  # Exonération de cotisations patronales de retraite complémentaire applicable dans les DOM (LODEOM) SMIC 170% à 270%
    EXONERATION_DE_COTISATIONS_PATRONALES_DE_RETRAITE_COMPLEMENTAIRE_APPLICABLE_DANS_LES_DOM_LODEOM_SMIC_170_A_350 = "113"  # Exonération de cotisations patronales de retraite complémentaire applicable dans les DOM (LODEOM) SMIC 170% à 350%
    MONTANT_DE_REDUCTION_DES_HEURES_SUPPLEMENTAIRES_COMPLEMENTAIRES = (
        "114"  # Montant de réduction des heures supplémentaires/complémentaires
    )
    COTISATION_ASSURANCE_MALADIE_POUR_LE_REGIME_LOCAL_ALSACE_MOSELLE = (
        "115"  # Cotisation Assurance Maladie pour le Régime Local Alsace Moselle
    )
    COTISATION_ABSENTE_DE_LA_NORME_EN_CAS_DE_REGULARISATION_PRUD_HOMALE = (
        "116"  # Cotisation absente de la norme en cas de régularisation prud'homale
    )
    CONTRIBUTION_A_LA_FORMATION_PROFESSIONNELLE_CFP = (
        "128"  # Contribution à la formation professionnelle (CFP)
    )
    CONTRIBUTION_DEDIEE_AU_FINANCEMENT_DU_COMPTE_PERSONNEL_DE_FORMATION_POUR_LES_TITULAIRES_DE_CDD_CPF_CDD = "129"  # Contribution dédiée au financement du Compte Personnel de Formation pour les titulaires de CDD (CPF-CDD)
    PART_PRINCIPALE_DE_LA_TAXE_D_APPRENTISSAGE = "130"  # Part principale de la taxe d'apprentissage
    COTISATION_REGIME_UNIFIE_AGIRC_ARRCO = "131"  # Cotisation régime unifié Agirc-Arrco
    COTISATION_APEC = "132"  # Cotisation Apec
    CONTRIBUTION_MALADIE_SPECIFIQUE_MAYOTTE = "133"  # Contribution maladie spécifique Mayotte
    CONTRIBUTION_CONVENTIONNELLE_AU_FINANCEMENT_DU_DIALOGUE_SOCIAL = (
        "140"  # Contribution conventionnelle au financement du dialogue social
    )
    CONTRIBUTION_CONVENTIONNELLE_A_LA_FORMATION_PROFESSIONNELLE = (
        "141"  # Contribution conventionnelle à la formation professionnelle
    )
    COTISATION_REGIME_UNIFIE_AGIRC_ARRCO_PART_PATRONALE_TRANCHE_T1 = (
        "142"  # Cotisation régime unifié Agirc-Arrco (part patronale tranche T1)
    )
    CONTRIBUTION_AU_COMPTE_PROFESSIONNEL_DE_PREVENTION_C2P = (
        "143"  # Contribution au compte professionnel de prévention (C2P)
    )
    COTISATION_CAVEC_CLASSE_C = "144"  # Cotisation CAVEC - classe C
    COTISATION_CAVEC_CLASSE_D = "145"  # Cotisation CAVEC - classe D
    COTISATION_REGIME_UNIFIE_AGIRC_ARRCO_PART_PATRONALE_TRANCHE_T2 = (
        "146"  # Cotisation régime unifié Agirc-Arrco (part patronale tranche T2)
    )
    FP_COTISATIONS_NORMALES_PART_SALARIALE = "300"  # [FP] Cotisations normales (part salariale)
    FP_COTISATIONS_NORMALES_PART_PATRONALE = "301"  # [FP] Cotisations normales (part patronale)
    FP_SURCOTISATION_HUIT_TRIMESTRES_PART_SALARIALE = (
        "302"  # [FP] Surcotisation huit trimestres (part salariale)
    )
    FP_VALIDATION_DE_SERVICES_PART_SALARIALE = "303"  # [FP] Validation de services (part salariale)
    FP_COTISATIONS_NOUVELLE_BONIFICATION_INDICIAIRE_PART_SALARIALE = (
        "304"  # [FP] Cotisations Nouvelle Bonification Indiciaire (part salariale)
    )
    FP_COTISATIONS_NOUVELLE_BONIFICATION_INDICIAIRE_PART_PATRONALE = (
        "305"  # [FP] Cotisations Nouvelle Bonification Indiciaire (part patronale)
    )
    FP_COTISATIONS_SUR_INDEMNITE_DE_FEU_PART_SALARIALE = (
        "306"  # [FP] Cotisations sur indemnité de feu (part salariale)
    )
    FP_COTISATIONS_SUR_INDEMNITE_DE_FEU_PART_PATRONALE = (
        "307"  # [FP] Cotisations sur indemnité de feu (part patronale)
    )
    FP_COTISATION_SUR_BONIFICATION_SAPEUR_POMPIER_PART_SALARIALE = (
        "308"  # [FP] Cotisation sur bonification sapeur pompier (part salariale)
    )
    FP_COTISATION_SUR_PRIME_SUR_SUJETION_DES_AIDES_SOIGNANTES_PART_SALARIALE = (
        "309"  # [FP] Cotisation sur prime sur sujetion des aides soignantes (part salariale)
    )
    FP_COTISATION_SUR_PRIME_SUR_SUJETION_DES_AIDES_SOIGNANTES_PART_PATRONALE = (
        "310"  # [FP] Cotisation sur prime sur sujetion des aides soignantes (part patronale)
    )
    FP_COTISATION_RAFP_PART_SALARIALE = "311"  # [FP] Cotisation RAFP (part salariale)
    FP_COTISATION_RAFP_PART_PATRONALE = "312"  # [FP] Cotisation RAFP (part patronale)
    FP_COTISATIONS_POUR_PENSION_SUR_ISS_OU_PSS_PART_SALARIALE = (
        "313"  # [FP] Cotisations pour pension sur ISS ou PSS (part salariale)
    )
    FP_COTISATIONS_POUR_PENSION_SUR_ISS_OU_PSS_PART_PATRONALE = (
        "314"  # [FP] Cotisations pour pension sur ISS ou PSS (part patronale)
    )
    FP_COTISATIONS_POUR_PENSION_SUR_IR_PART_SALARIALE = (
        "315"  # [FP] Cotisations pour pension sur IR (part salariale)
    )
    FP_COTISATIONS_POUR_PENSION_SUR_IR_PART_PATRONALE = (
        "316"  # [FP] Cotisations pour pension sur IR (part patronale)
    )
    FP_COTISATIONS_POUR_PENSION_SUR_IMT_PART_SALARIALE = (
        "317"  # [FP] Cotisations pour pension sur IMT (part salariale)
    )
    FP_COTISATIONS_POUR_PENSION_SUR_IMT_PART_PATRONALE = (
        "318"  # [FP] Cotisations pour pension sur IMT (part patronale)
    )
    FP_COTISATIONS_POUR_L_ALLOCATION_TEMPORAIRE_D_INVALIDITE_PART_PATRONALE = (
        "319"  # [FP] Cotisations pour l'allocation temporaire d'invalidité (part patronale)
    )
    FP_SURCOTISATION_PART_SALARIALE = "320"  # [FP] Surcotisation (part salariale)
    FP_RACHAT_DES_ANNEES_D_ETUDES_PART_SALARIALE = (
        "321"  # [FP] Rachat des années d'études (part salariale)
    )
    FP_EXONERATION_DE_COTISATION_POUR_HEURES_D_AIDE_A_DOMICILE_PART_PATRONALE = (
        "322"  # [FP] Exonération de cotisation pour heures d’aide à domicile (part patronale)
    )
    FP_COTISATION_RAEP_PART_PATRONALE = "323"  # [FP] Cotisation RAEP (part patronale)
    FP_COTISATION_RAEP_PART_SALARIALE = "324"  # [FP] Cotisation RAEP (part salariale)
    FP_VALIDATION_DE_SERVICES_PART_PATRONALE = "325"  # [FP] Validation de services (part patronale)
    FP_REGULARISATION_DE_SERVICE_PART_SALARIALE = (
        "326"  # [FP] Régularisation de service (part salariale)
    )
    FP_REGULARISATION_DE_SERVICE_PART_PATRONALE = (
        "327"  # [FP] Régularisation de service (part patronale)
    )
    REGIME_DE_BASE_FORFAITAIRE_CNBF = "330"  # Régime de base forfaitaire CNBF
    REGIME_DE_BASE_PROPORTIONNELLE_CNBF = "331"  # Régime de base proportionnelle CNBF
    REGIME_COMPLEMENTAIRE_CNBF = "332"  # Régime complémentaire CNBF
    COTISATION_CONTRAT_D_EMPLOI_PENITENTIAIRE_1 = (
        "333"  # Cotisation contrat d’emploi pénitentiaire 1
    )
    COTISATION_CONTRAT_D_EMPLOI_PENITENTIAIRE_2 = (
        "334"  # Cotisation contrat d’emploi pénitentiaire 2
    )
    COTISATION_EPARGNE_RETRAITE = "901"  # Cotisation épargne retraite
    CONTRIBUTION_A_LA_FORMATION_PROFESSIONNELLE_DES_ARTISANS_ASSIMILES_SALARIES = (
        "902"  # Contribution à la formation professionnelle des Artisans assimilés salariés
    )
    COTISATION_AFNCA = "903"  # Cotisation AFNCA
    COTISATION_ANEFA = "904"  # Cotisation ANEFA
    COTISATION_ASCPA = "905"  # Cotisation ASCPA
    COTISATION_PROVEA = "906"  # Cotisation PROVEA
    COMPLEMENT_DE_COTISATION_ASSURANCE_MALADIE = "907"  # Complément de cotisation Assurance Maladie
    TAXE_FORFAITAIRE_CDDU_ASSURANCE_CHOMAGE = "908"  # Taxe forfaitaire CDDU Assurance Chômage
    COTISATION_AU_TITRE_DU_FINANCEMENT_DES_REGIMES_DE_RETRAITES_SUPPLEMENTAIRES_A_PRESTATION_DEFINIES = "909"  # Cotisation au titre du financement des régimes de retraites supplémentaires à prestation définies
    EXONERATION_DE_COTISATIONS_PATRONALES_POUR_LES_ENTREPRISES_AFFECTEES_PAR_LA_CRISE_SANITAIRE = "910"  # Exonération de cotisations patronales pour les entreprises affectées par la crise sanitaire
    REDUCTION_DE_COTISATIONS_PATRONALES_POUR_LES_ENTREPRISES_DU_SECTEUR_DE_LA_VIGNE_AFFECTEES_PAR_LA_CRISE_SANITAIRE = "911"  # Réduction de cotisations patronales pour les entreprises du secteur de la vigne affectées par la crise sanitaire
    EXONERATION_DU_FORFAIT_SOCIAL_A_10 = "912"  # Exonération du forfait social à 10%
    INDEMNITE_INFLATION = "913"  # Indemnité inflation
    REDUCTION_SAPEURS_POMPIERS_VOLONTAIRES_SUR_LES_CONTRIBUTIONS_RECOUVREES_PAR_LA_MSA_L_URSSAF_OU_FRANCE_TRAVAIL = "914"  # Réduction sapeurs-pompiers volontaires sur les contributions recouvrées par la MSA, l’Urssaf ou France Travail
    REDUCTION_SAPEURS_POMPIERS_VOLONTAIRES_SUR_LES_COTISATIONS_ET_CONTRIBUTIONS_RECOUVREES_PAR_L_AGIRC_ARRCO = "915"  # Réduction sapeurs-pompiers volontaires sur les cotisations et contributions recouvrées par l’Agirc-Arrco
    EXONERATION_DE_COTISATIONS_APPLICABLE_EN_ZONES_FRANCE_RURALITES_REVITALISATION_ZFRR = "916"  # Exonération de cotisations applicable en Zones France Ruralités Revitalisation (ZFRR)
    POTENTIELLE_NOUVELLE_COTISATION_D = "917"  # Potentielle nouvelle cotisation D
    VERSEMENT_MOBILITE_REGIONAL_ET_RURAL = "918"  # Versement mobilité régional et rural
    POTENTIELLE_NOUVELLE_COTISATION_A = "919"  # Potentielle nouvelle cotisation A
    POTENTIELLE_NOUVELLE_COTISATION_B = "920"  # Potentielle nouvelle cotisation B
    POTENTIELLE_NOUVELLE_COTISATION_C = "921"  # Potentielle nouvelle cotisation C

    __DESCRIPTIONS: dict[str, str] = {
        "001": "Exon\u00e9ration de cotisations au titre de l\u0027emploi d\u0027un apprenti (loi de 1979)",
        "002": "Exon\u00e9ration de cotisations au titre de l\u0027emploi d\u0027un apprenti (loi de 1987)",
        "003": "Exon\u00e9ration de cotisations au titre de l\u0027emploi d\u0027un apprenti (loi de 1992)",
        "004": "Exon\u00e9ration de cotisations au titre de l\u0027emploi d\u0027un salari\u00e9 en contrat d\u0027acc\u00e8s \u00e0 l\u0027emploi",
        "006": "Exon\u00e9ration de cotisations au titre de l\u0027emploi d\u0027un salari\u00e9 en contrat d\u0027accompagnement dans l\u0027emploi",
        "008": "Exon\u00e9ration de cotisations au titre de l\u0027emploi d\u0027un salari\u00e9 en contrat de professionnalisation",
        "009": "Exon\u00e9ration de cotisations applicable aux associations interm\u00e9diaires",
        "010": "Exon\u00e9ration de cotisations applicable aux entreprises des bassins d\u0027emploi \u00e0 redynamiser",
        "011": "Exon\u00e9ration de cotisations applicable au cr\u00e9ateur ou repreneur d\u0027entreprise",
        "012": "Exon\u00e9ration de cotisations applicable dans les DOM",
        "013": "Exon\u00e9ration de cotisations applicable aux entreprises et associations d\u0027aide \u00e0 domicile",
        "014": "Exon\u00e9rations de cotisations applicable aux entreprises innovantes, universitaires ou de croissance",
        "015": "Exon\u00e9ration de cotisations applicable aux entreprises en zones franches urbaines",
        "016": "Exon\u00e9ration de cotisations applicable aux organismes d\u0027int\u00e9r\u00eat g\u00e9n\u00e9ral en zones de revitalisation rurale",
        "017": "Exon\u00e9ration de cotisations applicable aux structures agr\u00e9\u00e9es de l\u0027aide sociale",
        "018": "R\u00e9duction g\u00e9n\u00e9rale des cotisations patronales de s\u00e9curit\u00e9 sociale et d\u0027assurance ch\u00f4mage",
        "019": "R\u00e9duction de cotisations applicable aux entreprises des zones de restructuration de la d\u00e9fense",
        "020": "R\u00e9duction de cotisations au titre de l\u0027embauche du 1er au 50\u00e8me salari\u00e9 en zones de revitalisation rurale",
        "021": "D\u00e9duction patronale au titre des heures suppl\u00e9mentaires",
        "022": "Exon\u00e9ration de cotisations applicable \u00e0 une gratification de stage",
        "023": "Exon\u00e9ration de cotisation des sommes provenant d\u0027un CET et r\u00e9affect\u00e9es \u00e0 un plan d\u0027\u00e9pargne retraite (PERCO, PERECO, PEREO) ou \u00e0 un r\u00e9gime de retraite suppl\u00e9mentaire",
        "025": "Exon\u00e9ration de cotisations au titre de l\u2019emploi d\u2019un salari\u00e9 en chantier et atelier d\u0027insertion",
        "027": "Exon\u00e9ration Personnel technique CUMA, hors ateliers",
        "028": "R\u00e9duction Travailleur Occasionnel",
        "029": "R\u00e9duction employeurs petit pool IEG",
        "030": "Cotisation employeurs r\u00e9gime sp\u00e9cial maladie IEG Compl\u00e9mentaire",
        "031": "Cotisation salari\u00e9s r\u00e9gime sp\u00e9cial maladie IEG Compl\u00e9mentaire",
        "032": "Cotisation salari\u00e9s r\u00e9gime maladie IEG sp\u00e9cial Solidarit\u00e9",
        "033": "Cotisation employeurs compl\u00e9ment d\u0027invalidit\u00e9 IEG",
        "034": "Cotisation employeurs r\u00e9gime de droit commun IEG (population adoss\u00e9e)",
        "035": "Cotisation employeurs r\u00e9gime sp\u00e9cial IEG (population adoss\u00e9e)",
        "036": "Cotisation employeurs r\u00e9gime sp\u00e9cial IEG (population non adoss\u00e9e)",
        "037": "Cotisation salari\u00e9s r\u00e9gime de droit commun IEG (population adoss\u00e9e)",
        "038": "Cotisation salari\u00e9s r\u00e9gime sp\u00e9cial IEG (population non adoss\u00e9e)",
        "039": "Cotisations employeurs petit pool IEG",
        "040": "Cotisation AC : assurance ch\u00f4mage sur r\u00e9mun\u00e9rations brutes apr\u00e8s d\u00e9duction",
        "041": "Cotisation AC major\u00e9e 1 : application d\u2019une majoration AC + 0,5% sur les contrats d\u2019usage inf\u00e9rieurs ou \u00e9gaux \u00e0 3 mois",
        "042": "Cotisation AC major\u00e9e 2 : application d\u2019une majoration AC + 3% sur les contrats d\u2019accroissement temporaire d\u2019activit\u00e9 inf\u00e9rieurs ou \u00e9gaux \u00e0 1 mois",
        "043": "Cotisation AC major\u00e9e 3 : application d\u2019une majoration AC + 1,5% sur les contrats d\u2019accroissement temporaire d\u2019activit\u00e9 sup\u00e9rieurs \u00e0 1 mois mais inf\u00e9rieurs ou \u00e9gaux \u00e0 3 mois",
        "044": "Exon\u00e9ration de cotisation ch\u00f4mage pour les moins de 26 ans",
        "045": "Cotisation Accident du travail",
        "046": "Cotisation AEF Bourse de l\u0027emploi",
        "047": "Cotisation AEF CESA",
        "048": "Cotisation AGS : assurance garantie des salaires sur r\u00e9mun\u00e9rations brutes apr\u00e8s d\u00e9duction",
        "049": "Cotisation Allocation de logement (FNAL)",
        "051": "Cotisation Formation professionnelle ADEFA",
        "053": "Cotisation Formation professionnelle additionnelle FAFSEA",
        "054": "Cotisation Formation professionnelle AREFA",
        "056": "Cotisation Formation professionnelle FAFSEA",
        "057": "Cotisation Formation professionnelle FAFSEA CDD",
        "058": "Cotisation Formation professionnelle FAFSEA des communes foresti\u00e8res",
        "059": "Cotisation individuelle Pr\u00e9voyance-Assurance-Mutuelle pour la p\u00e9riode et l\u0027affiliation concern\u00e9es",
        "060": "Cotisation IRCANTEC Tranche A",
        "061": "Cotisation IRCANTEC Tranche B",
        "065": "Cotisation CRPCEN",
        "066": "Cotisation caisse de cong\u00e9s spectacles",
        "068": "Contribution solidarit\u00e9 autonomie",
        "069": "Contribution sur avantage de pr\u00e9-retraite entreprise \u00e0 dater du 11/10/2007 (CAPE)",
        "070": "Contribution sur avantage de pr\u00e9-retraite entreprise aux taux normal (CAPE)",
        "071": "Contribution forfait social",
        "072": "Contribution sociale g\u00e9n\u00e9ralis\u00e9e/salaires partiellement d\u00e9ductibles",
        "073": "CSG/CRDS sur participation int\u00e9ressement \u00e9pargne salariale",
        "074": "Cotisation Allocation familiale - taux normal",
        "075": "Cotisation Assurance Maladie",
        "076": "Cotisation Assurance Vieillesse",
        "077": "Montant de la retenue \u00e0 la source effectu\u00e9e sur les salaires vers\u00e9s aux personnes domicili\u00e9es hors de France",
        "078": "P\u00e9nalit\u00e9 de 1% emploi s\u00e9nior",
        "079": "Remboursement de la dette sociale",
        "081": "Versement mobilit\u00e9",
        "082": "Versement mobilit\u00e9 additionnel",
        "088": "Exon\u00e9ration versement mobilit\u00e9",
        "089": "Exon\u00e9ration Contrat Initiative Emploi",
        "090": "Exon\u00e9ration accueillants familiaux",
        "091": "Cotisation Service de sant\u00e9 au travail",
        "092": "Cotisation Association pour l\u0027emploi des cadres ing\u00e9nieurs et techniciens de l\u0027agriculture (APECITA)",
        "093": "Contribution sur indemnit\u00e9s de mise \u00e0 la retraite ou de rupture conventionnelle individuelle",
        "094": "Exon\u00e9ration cotisations Allocations familiales (SICAE)",
        "096": "Cotisation CRPNPAC au fonds de retraite",
        "097": "Cotisation CRPNPAC au fonds d\u0027assurance",
        "098": "Cotisation CRPNPAC au fonds de majoration",
        "099": "Contribution stock options",
        "100": "Contribution au financement du dialogue social",
        "101": "Association Mutualisation du Co\u00fbt Inaptitude",
        "102": "Compl\u00e9ment de cotisation Allocation Familiale",
        "103": "Contribution actions gratuites",
        "104": "P\u00e9nibilit\u00e9 Cotisation de base",
        "105": "Montant de cotisation R\u00e9gime Unifi\u00e9 Agirc-Arrco, y compris Apec",
        "106": "R\u00e9duction g\u00e9n\u00e9rale des cotisations patronales de retraite compl\u00e9mentaire",
        "107": "Forfait marin",
        "108": "Demi-r\u00f4le marin",
        "109": "Exon\u00e9ration de cotisations salariales de retraite compl\u00e9mentaire au titre de l\u0027emploi d\u0027un apprenti",
        "110": "Exon\u00e9ration de cotisations patronales de retraite compl\u00e9mentaire applicable dans les DOM (LODEOM) SMIC 130% \u00e0 220%",
        "111": "Exon\u00e9ration de cotisations de retraite compl\u00e9mentaire applicable aux entreprises et associations d\u0027aide \u00e0 domicile",
        "112": "Exon\u00e9ration de cotisations patronales de retraite compl\u00e9mentaire applicable dans les DOM (LODEOM) SMIC 170% \u00e0 270%",
        "113": "Exon\u00e9ration de cotisations patronales de retraite compl\u00e9mentaire applicable dans les DOM (LODEOM) SMIC 170% \u00e0 350%",
        "114": "Montant de r\u00e9duction des heures suppl\u00e9mentaires/compl\u00e9mentaires",
        "115": "Cotisation Assurance Maladie pour le R\u00e9gime Local Alsace Moselle",
        "116": "Cotisation absente de la norme en cas de r\u00e9gularisation prud\u0027homale",
        "128": "Contribution \u00e0 la formation professionnelle (CFP)",
        "129": "Contribution d\u00e9di\u00e9e au financement du Compte Personnel de Formation pour les titulaires de CDD (CPF-CDD)",
        "130": "Part principale de la taxe d\u0027apprentissage",
        "131": "Cotisation r\u00e9gime unifi\u00e9 Agirc-Arrco",
        "132": "Cotisation Apec",
        "133": "Contribution maladie sp\u00e9cifique Mayotte",
        "140": "Contribution conventionnelle au financement du dialogue social",
        "141": "Contribution conventionnelle \u00e0 la formation professionnelle",
        "142": "Cotisation r\u00e9gime unifi\u00e9 Agirc-Arrco (part patronale tranche T1)",
        "143": "Contribution au compte professionnel de pr\u00e9vention (C2P)",
        "144": "Cotisation CAVEC - classe C",
        "145": "Cotisation CAVEC - classe D",
        "146": "Cotisation r\u00e9gime unifi\u00e9 Agirc-Arrco (part patronale tranche T2)",
        "300": "[FP] Cotisations normales (part salariale)",
        "301": "[FP] Cotisations normales (part patronale)",
        "302": "[FP] Surcotisation huit trimestres (part salariale)",
        "303": "[FP] Validation de services (part salariale)",
        "304": "[FP] Cotisations Nouvelle Bonification Indiciaire (part salariale)",
        "305": "[FP] Cotisations Nouvelle Bonification Indiciaire (part patronale)",
        "306": "[FP] Cotisations sur indemnit\u00e9 de feu (part salariale)",
        "307": "[FP] Cotisations sur indemnit\u00e9 de feu (part patronale)",
        "308": "[FP] Cotisation sur bonification sapeur pompier (part salariale)",
        "309": "[FP] Cotisation sur prime sur sujetion des aides soignantes (part salariale)",
        "310": "[FP] Cotisation sur prime sur sujetion des aides soignantes (part patronale)",
        "311": "[FP] Cotisation RAFP (part salariale)",
        "312": "[FP] Cotisation RAFP (part patronale)",
        "313": "[FP] Cotisations pour pension sur ISS ou PSS (part salariale)",
        "314": "[FP] Cotisations pour pension sur ISS ou PSS (part patronale)",
        "315": "[FP] Cotisations pour pension sur IR (part salariale)",
        "316": "[FP] Cotisations pour pension sur IR (part patronale)",
        "317": "[FP] Cotisations pour pension sur IMT (part salariale)",
        "318": "[FP] Cotisations pour pension sur IMT (part patronale)",
        "319": "[FP] Cotisations pour l\u0027allocation temporaire d\u0027invalidit\u00e9 (part patronale)",
        "320": "[FP] Surcotisation (part salariale)",
        "321": "[FP] Rachat des ann\u00e9es d\u0027\u00e9tudes (part salariale)",
        "322": "[FP] Exon\u00e9ration de cotisation pour heures d\u2019aide \u00e0 domicile (part patronale)",
        "323": "[FP] Cotisation RAEP (part patronale)",
        "324": "[FP] Cotisation RAEP (part salariale)",
        "325": "[FP] Validation de services (part patronale)",
        "326": "[FP] R\u00e9gularisation de service (part salariale)",
        "327": "[FP] R\u00e9gularisation de service (part patronale)",
        "330": "R\u00e9gime de base forfaitaire CNBF",
        "331": "R\u00e9gime de base proportionnelle CNBF",
        "332": "R\u00e9gime compl\u00e9mentaire CNBF",
        "333": "Cotisation contrat d\u2019emploi p\u00e9nitentiaire 1",
        "334": "Cotisation contrat d\u2019emploi p\u00e9nitentiaire 2",
        "901": "Cotisation \u00e9pargne retraite",
        "902": "Contribution \u00e0 la formation professionnelle des Artisans assimil\u00e9s salari\u00e9s",
        "903": "Cotisation AFNCA",
        "904": "Cotisation ANEFA",
        "905": "Cotisation ASCPA",
        "906": "Cotisation PROVEA",
        "907": "Compl\u00e9ment de cotisation Assurance Maladie",
        "908": "Taxe forfaitaire CDDU Assurance Ch\u00f4mage",
        "909": "Cotisation au titre du financement des r\u00e9gimes de retraites suppl\u00e9mentaires \u00e0 prestation d\u00e9finies",
        "910": "Exon\u00e9ration de cotisations patronales pour les entreprises affect\u00e9es par la crise sanitaire",
        "911": "R\u00e9duction de cotisations patronales pour les entreprises du secteur de la vigne affect\u00e9es par la crise sanitaire",
        "912": "Exon\u00e9ration du forfait social \u00e0 10%",
        "913": "Indemnit\u00e9 inflation",
        "914": "R\u00e9duction sapeurs-pompiers volontaires sur les contributions recouvr\u00e9es par la MSA, l\u2019Urssaf ou France Travail",
        "915": "R\u00e9duction sapeurs-pompiers volontaires sur les cotisations et contributions recouvr\u00e9es par l\u2019Agirc-Arrco",
        "916": "Exon\u00e9ration de cotisations applicable en Zones France Ruralit\u00e9s Revitalisation (ZFRR)",
        "917": "Potentielle nouvelle cotisation D",
        "918": "Versement mobilit\u00e9 r\u00e9gional et rural",
        "919": "Potentielle nouvelle cotisation A",
        "920": "Potentielle nouvelle cotisation B",
        "921": "Potentielle nouvelle cotisation C",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_NatureContrat(str, Enum):
    CONTRAT_DE_TRAVAIL_A_DUREE_INDETERMINEE_DE_DROIT_PRIVE = (
        "01"  # Contrat de travail à durée indéterminée de droit privé
    )
    CONTRAT_DE_TRAVAIL_A_DUREE_DETERMINEE_DE_DROIT_PRIVE = (
        "02"  # Contrat de travail à durée déterminée de droit privé
    )
    CONTRAT_DE_MISSION_CONTRAT_DE_TRAVAIL_TEMPORAIRE = (
        "03"  # Contrat  de mission (contrat de travail temporaire)
    )
    CONTRAT_A_DUREE_INDETERMINEE_INTERMITTENT = "07"  # Contrat à durée indéterminée intermittent
    CONTRAT_A_DUREE_INDETERMINEE_INTERIMAIRE = "08"  # Contrat à durée indéterminée intérimaire
    CONTRAT_DE_TRAVAIL_A_DUREE_INDETERMINEE_DE_DROIT_PUBLIC = (
        "09"  # Contrat de travail à durée indéterminée de droit public
    )
    CONTRAT_DE_TRAVAIL_A_DUREE_DETERMINEE_DE_DROIT_PUBLIC = (
        "10"  # Contrat de travail à durée déterminée de droit public
    )
    FP_DETACHEMENT_D_UN_AGENT_D_UNE_FONCTION_PUBLIQUE_DONNANT_LIEU_A_PENSION_ECP = (
        "20"  # [FP] Détachement d’un agent d’une Fonction Publique donnant lieu à pension (ECP)
    )
    FP_DETACHEMENT_D_UN_AGENT_D_UNE_FONCTION_PUBLIQUE_NE_DONNANT_PAS_LIEU_A_PENSION_ENCP = "21"  # [FP] Détachement d’un agent d’une Fonction Publique ne donnant pas lieu à pension (ENCP)
    CONVENTION_DE_STAGE_HORS_FORMATION_PROFESSIONNELLE = (
        "29"  # Convention de stage (hors formation professionnelle)
    )
    CONTRAT_D_APPUI_AU_PROJET_D_ENTREPRISE = "32"  # Contrat d’appui au projet d’entreprise
    NOMINATION_DANS_LA_FONCTION_PUBLIQUE_PAR_ARRETE_PAR_DECISION = (
        "50"  # Nomination dans la fonction publique (par arrêté, par décision,…)
    )
    CONTRAT_DE_MISSION_D_UN_COLLABORATEUR_OCCASIONNEL_DU_SERVICE_PUBLIC_COSP_OU_ASSIMILE = "51"  # Contrat de mission d’un collaborateur occasionnel du service public (COSP) ou assimilé
    FP_CUMUL_D_ACTIVITE_A_TITRE_ACCESSOIRE = "52"  # [FP] Cumul d’activité à titre accessoire
    CONTRAT_D_EMPLOI_PENITENTIAIRE = "53"  # Contrat d'emploi pénitentiaire
    CONTRAT_D_EMPLOI_PENITENTIAIRE_EN_APPRENTISSAGE = (
        "54"  # Contrat d'emploi pénitentiaire en apprentissage
    )
    CONTRAT_D_ENGAGEMENT_EDUCATIF = "60"  # Contrat d'engagement éducatif
    CONTRAT_DE_SOUTIEN_ET_D_AIDE_PAR_LE_TRAVAIL = (
        "70"  # Contrat de soutien et d'aide par le travail
    )
    MANDAT_SOCIAL = "80"  # Mandat social
    MANDAT_D_ELU = "81"  # Mandat d'élu
    CONTRAT_DE_TRAVAIL_A_DUREE_INDETERMINEE_DE_CHANTIER_OU_D_OPERATION = (
        "82"  # Contrat de travail à durée indéterminée de Chantier ou d'opération
    )
    VOLONTARIAT_DE_SERVICE_CIVIQUE = "89"  # Volontariat de service civique
    AUTRE_NATURE_DE_CONTRAT_CONVENTION_MANDAT_HORS_MANDAT_SOCIAL = (
        "90"  # Autre nature de contrat, convention, mandat (hors mandat social)
    )
    CONTRAT_D_ENGAGEMENT_MARITIME_A_DUREE_INDETERMINEE = (
        "91"  # Contrat d'engagement maritime à durée indéterminée
    )
    CONTRAT_D_ENGAGEMENT_MARITIME_A_DUREE_DETERMINEE = (
        "92"  # Contrat d'engagement maritime à durée déterminée
    )
    LIGNE_DE_SERVICE = "93"  # Ligne de service

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Contrat de travail \u00e0 dur\u00e9e ind\u00e9termin\u00e9e de droit priv\u00e9",
        "02": "Contrat de travail \u00e0 dur\u00e9e d\u00e9termin\u00e9e de droit priv\u00e9",
        "03": "Contrat  de mission (contrat de travail temporaire)",
        "07": "Contrat \u00e0 dur\u00e9e ind\u00e9termin\u00e9e intermittent",
        "08": "Contrat \u00e0 dur\u00e9e ind\u00e9termin\u00e9e int\u00e9rimaire",
        "09": "Contrat de travail \u00e0 dur\u00e9e ind\u00e9termin\u00e9e de droit public",
        "10": "Contrat de travail \u00e0 dur\u00e9e d\u00e9termin\u00e9e de droit public",
        "20": "[FP] D\u00e9tachement d\u2019un agent d\u2019une Fonction Publique donnant lieu \u00e0 pension (ECP)",
        "21": "[FP] D\u00e9tachement d\u2019un agent d\u2019une Fonction Publique ne donnant pas lieu \u00e0 pension (ENCP)",
        "29": "Convention de stage (hors formation professionnelle)",
        "32": "Contrat d\u2019appui au projet d\u2019entreprise",
        "50": "Nomination dans la fonction publique (par arr\u00eat\u00e9, par d\u00e9cision,\u2026)",
        "51": "Contrat de mission d\u2019un collaborateur occasionnel du service public (COSP) ou assimil\u00e9",
        "52": "[FP] Cumul d\u2019activit\u00e9 \u00e0 titre accessoire",
        "53": "Contrat d\u0027emploi p\u00e9nitentiaire",
        "54": "Contrat d\u0027emploi p\u00e9nitentiaire en apprentissage",
        "60": "Contrat d\u0027engagement \u00e9ducatif",
        "70": "Contrat de soutien et d\u0027aide par le travail",
        "80": "Mandat social",
        "81": "Mandat d\u0027\u00e9lu",
        "82": "Contrat de travail \u00e0 dur\u00e9e ind\u00e9termin\u00e9e de Chantier ou d\u0027op\u00e9ration",
        "89": "Volontariat de service civique",
        "90": "Autre nature de contrat, convention, mandat (hors mandat social)",
        "91": "Contrat d\u0027engagement maritime \u00e0 dur\u00e9e ind\u00e9termin\u00e9e",
        "92": "Contrat d\u0027engagement maritime \u00e0 dur\u00e9e d\u00e9termin\u00e9e",
        "93": "Ligne de service",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_NiveauFormationPlusEleveIndividu(str, Enum):
    FORMATION_N_ALLANT_PAS_AU_DELA_DE_LA_SCOLARITE_OBLIGATOIRE_16_ANS = (
        "01"  # Formation n'allant pas au-delà de la scolarité obligatoire (16 ans)
    )
    FORMATION_D_UNE_DUREE_MAXIMALE_D_UN_AN_APRES_LE_COLLEGE = (
        "02"  # Formation d'une durée maximale d'un an après le collège
    )
    NIVEAU_DE_FORMATION_EQUIVALENT_AU_CAP_CERTIFICAT_D_APTITUDE_PROFESSIONNELLE_OU_AU_BEP_BREVET_D_ETUDES_PROFESSIONNELLES = "03"  # Niveau de formation équivalent au CAP (certificat d'aptitude professionnelle) ou au BEP (brevet d'études professionnelles)
    FORMATION_DE_NIVEAU_DU_BAC_GENERAL_TECHNOLOGIQUE_OU_PROFESSIONNEL_DU_BREVET_DE_TECHNICIEN_BT_OU_DU_BREVET_PROFESSIONNEL = "04"  # Formation de niveau du bac (général, technologique ou professionnel), du brevet de technicien (BT) ou du brevet professionnel
    FORMATION_DE_NIVEAU_BAC_2_LICENCE_2_BTS_BREVET_DE_TECHNICIEN_SUPERIEUR_DUT_DIPLOME_UNIVERSITAIRE_DE_TECHNOLOGIE_ETC = "05"  # Formation de niveau bac+2 : licence 2, BTS (brevet de technicien supérieur), DUT (diplôme universitaire de technologie), etc.
    FORMATION_DE_NIVEAU_BAC_3_ET_BAC_4_LICENCE_3_LICENCE_PROFESSIONNELLE_MASTER_1_ETC = "06"  # Formation de niveau bac+3 et bac+4 : licence 3, licence professionnelle, master 1, etc.
    FORMATION_DE_NIVEAU_BAC_5_MASTER_2_DIPLOME_D_ETUDES_APPROFONDIES_DIPLOME_D_ETUDES_SUPERIEURES_SPECIALISEES_DIPLOME_D_INGENIEUR_ETC = "07"  # Formation de niveau bac+5 : master 2, diplôme d'études approfondies, diplôme d'études supérieures spécialisées, diplôme d'ingénieur, etc.
    FORMATION_DE_NIVEAU_BAC_8_DOCTORAT_HABILITATION_A_DIRIGER_DES_RECHERCHES_ETC = (
        "08"  # Formation de niveau bac+8 : doctorat, habilitation à diriger des recherches, etc.
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Formation n\u0027allant pas au-del\u00e0 de la scolarit\u00e9 obligatoire (16 ans)",
        "02": "Formation d\u0027une dur\u00e9e maximale d\u0027un an apr\u00e8s le coll\u00e8ge",
        "03": "Niveau de formation \u00e9quivalent au CAP (certificat d\u0027aptitude professionnelle) ou au BEP (brevet d\u0027\u00e9tudes professionnelles)",
        "04": "Formation de niveau du bac (g\u00e9n\u00e9ral, technologique ou professionnel), du brevet de technicien (BT) ou du brevet professionnel",
        "05": "Formation de niveau bac+2 : licence 2, BTS (brevet de technicien sup\u00e9rieur), DUT (dipl\u00f4me universitaire de technologie), etc.",
        "06": "Formation de niveau bac+3 et bac+4 : licence 3, licence professionnelle, master 1, etc.",
        "07": "Formation de niveau bac+5 : master 2, dipl\u00f4me d\u0027\u00e9tudes approfondies, dipl\u00f4me d\u0027\u00e9tudes sup\u00e9rieures sp\u00e9cialis\u00e9es, dipl\u00f4me d\u0027ing\u00e9nieur, etc.",
        "08": "Formation de niveau bac+8 : doctorat, habilitation \u00e0 diriger des recherches, etc.",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Enum_Complement_Base_Assujettie_2_2(str, Enum):
    MONTANT_DU_SMIC_RETENU_POUR_LE_CALCUL_DE_LA_REDUCTION_GENERALE_DES_COTISATIONS_PATRONALES_DE_SECURITE_SOCIALE_DE_RETRAITE_COMPLEMENTAIRE_ET_D_ASSURANCE_CHOMAGE = "01"  # Montant du SMIC retenu pour le calcul de la Réduction générale des cotisations patronales de sécurité sociale, de retraite complémentaire et d'assurance chômage
    MONTANT_DU_SMIC_RETENU_POUR_LE_CALCUL_DU_CREDIT_D_IMPOT_COMPETITIVITE_EMPLOI = (
        "02"  # Montant du SMIC retenu pour le calcul du crédit d'impôt compétitivité-emploi
    )
    CONTRIBUTIONS_PATRONALES_A_DES_REGIMES_COMPLEMENTAIRES_DE_RETRAITE = (
        "03"  # Contributions patronales à des régimes complémentaires de retraite
    )
    CONTRIBUTIONS_PATRONALES_DESTINEES_AU_FINANCEMENT_DES_PRESTATIONS_DE_PREVOYANCE_COMPLEMENTAIRE = "04"  # Contributions patronales destinées au financement des prestations de prévoyance complémentaire
    CONTRIBUTIONS_PATRONALES_DESTINEES_AU_FINANCEMENT_DES_PRESTATIONS_DE_RETRAITE_SUPPLEMENTAIRE = "05"  # Contributions patronales destinées au financement des prestations de retraite supplémentaire
    PLAFOND_CALCULE_POUR_SALARIE_POLY_EMPLOYEURS = (
        "06"  # Plafond calculé pour salarié poly-employeurs
    )
    PLAFOND_DE_SECURITE_SOCIALE_APPLIQUE = "07"  # Plafond de Sécurité Sociale appliqué
    SALAIRE_BRUT_PREVOYANCE = "10"  # Salaire brut Prévoyance
    TRANCHE_A_PREVOYANCE = "11"  # Tranche A Prévoyance
    TRANCHE_2_PREVOYANCE = "12"  # Tranche 2 Prévoyance
    TRANCHE_B_PREVOYANCE = "13"  # Tranche B Prévoyance
    TRANCHE_C_PREVOYANCE = "14"  # Tranche C Prévoyance
    TRANCHE_D_PREVOYANCE = "15"  # Tranche D Prévoyance
    TRANCHE_D1_PREVOYANCE = "16"  # Tranche D1 Prévoyance
    BASE_SPECIFIQUE_PREVOYANCE = "17"  # Base spécifique Prévoyance
    BASE_FORFAITAIRE_PREVOYANCE = "18"  # Base forfaitaire Prévoyance
    BASE_FICTIVE_PREVOYANCE_RECONSTITUEE = "19"  # Base fictive Prévoyance reconstituée
    MONTANT_FORFAITAIRE_PREVOYANCE = "20"  # Montant forfaitaire Prévoyance
    MONTANT_PREVOYANCE_LIBRE_OU_EXCEPTIONNEL = "21"  # Montant Prévoyance libre ou exceptionnel
    MONTANT_DES_INDEMNITES_JOURNALIERES_CRPCEN = "22"  # Montant des indemnités journalières CRPCEN
    SANS_COMPOSANT_DE_BASE_ASSUJETTIE_EN_PAIE = "23"  # Sans composant de base assujettie en paie
    TRANCHE_2_UNIFIEE_PREVOYANCE = "24"  # Tranche 2 Unifiée Prévoyance
    POTENTIEL_NOUVEAU_TYPE_DE_COMPOSANT_DE_BASE_ASSUJETTIE_A = (
        "25"  # Potentiel nouveau type de composant de base assujettie A
    )
    POTENTIEL_NOUVEAU_TYPE_DE_COMPOSANT_DE_BASE_ASSUJETTIE_B = (
        "26"  # Potentiel nouveau type de composant de base assujettie B
    )
    POTENTIEL_NOUVEAU_TYPE_DE_COMPOSANT_DE_BASE_ASSUJETTIE_C = (
        "27"  # Potentiel nouveau type de composant de base assujettie C
    )
    POTENTIEL_NOUVEAU_TYPE_DE_COMPOSANT_DE_BASE_ASSUJETTIE_D = (
        "28"  # Potentiel nouveau type de composant de base assujettie D
    )
    POTENTIEL_NOUVEAU_TYPE_DE_COMPOSANT_DE_BASE_ASSUJETTIE_E = (
        "29"  # Potentiel nouveau type de composant de base assujettie E
    )
    RETENUE_SUR_SALAIRE = "90"  # Retenue sur salaire
    BASE_DE_TAXE_SUR_LES_SALAIRES_AU_TAUX_NORMAL = (
        "91"  # Base de taxe sur les salaires au taux normal
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Montant du SMIC retenu pour le calcul de la R\u00e9duction g\u00e9n\u00e9rale des cotisations patronales de s\u00e9curit\u00e9 sociale, de retraite compl\u00e9mentaire et d\u0027assurance ch\u00f4mage",
        "02": "Montant du SMIC retenu pour le calcul du cr\u00e9dit d\u0027imp\u00f4t comp\u00e9titivit\u00e9-emploi",
        "03": "Contributions patronales \u00e0 des r\u00e9gimes compl\u00e9mentaires de retraite",
        "04": "Contributions patronales destin\u00e9es au financement des prestations de pr\u00e9voyance compl\u00e9mentaire",
        "05": "Contributions patronales destin\u00e9es au financement des prestations de retraite suppl\u00e9mentaire",
        "06": "Plafond calcul\u00e9 pour salari\u00e9 poly-employeurs",
        "07": "Plafond de S\u00e9curit\u00e9 Sociale appliqu\u00e9",
        "10": "Salaire brut Pr\u00e9voyance",
        "11": "Tranche A Pr\u00e9voyance",
        "12": "Tranche 2 Pr\u00e9voyance",
        "13": "Tranche B Pr\u00e9voyance",
        "14": "Tranche C Pr\u00e9voyance",
        "15": "Tranche D Pr\u00e9voyance",
        "16": "Tranche D1 Pr\u00e9voyance",
        "17": "Base sp\u00e9cifique Pr\u00e9voyance",
        "18": "Base forfaitaire Pr\u00e9voyance",
        "19": "Base fictive Pr\u00e9voyance reconstitu\u00e9e",
        "20": "Montant forfaitaire Pr\u00e9voyance",
        "21": "Montant Pr\u00e9voyance libre ou exceptionnel",
        "22": "Montant des indemnit\u00e9s journali\u00e8res CRPCEN",
        "23": "Sans composant de base assujettie en paie",
        "24": "Tranche 2 Unifi\u00e9e Pr\u00e9voyance",
        "25": "Potentiel nouveau type de composant de base assujettie A",
        "26": "Potentiel nouveau type de composant de base assujettie B",
        "27": "Potentiel nouveau type de composant de base assujettie C",
        "28": "Potentiel nouveau type de composant de base assujettie D",
        "29": "Potentiel nouveau type de composant de base assujettie E",
        "90": "Retenue sur salaire",
        "91": "Base de taxe sur les salaires au taux normal",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Ancien_Motifs_Recours(str, Enum):
    REMPLACEMENT_D_UN_SALARIE = "01"  # Remplacement d'un salarié
    ACCROISSEMENT_TEMPORAIRE_DE_L_ACTIVITE_DE_L_ENTREPRISE = (
        "02"  # Accroissement temporaire de l'activité de l'entreprise
    )
    EMPLOIS_A_CARACTERE_SAISONNIER = "03"  # Emplois à caractère saisonnier
    CONTRAT_VENDANGES = "04"  # Contrat vendanges
    CONTRAT_D_USAGE = "05"  # Contrat d’usage
    CONTRAT_A_DUREE_DETERMINEE_A_OBJET_DEFINI = "06"  # Contrat à durée déterminée à objet défini
    REMPLACEMENT_D_UN_CHEF_D_ENTREPRISE_ARTISANALE_INDUSTRIELLE_OU_COMMERCIALE_D_UNE_PERSONNE_EXERCANT_UNE_PROFESSION_LIBERALE_DE_SON_CONJOINT_PARTICIPANT_EFFECTIVEMENT_A_L_ACTIVITE_DE_L_ENTREPRISE_A_TITRE_PROFESSIONNEL_ET_HABITUEL_OU_D_UN_ASSOCIE_NON_SALARIE_D_UNE_SOCIETE_CIVILE_PROFESSIONNELLE_D_UNE_SOCIETE_CIVILE_DE_MOYENS_OU_D_UNE_SOCIETE_D_EXERCICE_LIBERAL = "07"  # Remplacement d'un chef d'entreprise (« artisanale, industrielle ou commerciale, d'une personne exerçant une profession libérale, de son conjoint participant effectivement à l'activité de l'entreprise à titre professionnel et habituel ou d'un associé non salarié d'une société civile professionnelle, d'une société civile de moyens ou d'une société d'exercice libéral »)
    REMPLACEMENT_DU_CHEF_D_UNE_EXPLOITATION_AGRICOLE_OU_D_UNE_ENTREPRISE_MENTIONNEE_AUX_1_A_4_DE_L_ARTICLE_L_722_1_DU_CODE_RURAL_ET_DE_LA_PECHE_MARITIME_D_UN_AIDE_FAMILIAL_D_UN_ASSOCIE_D_EXPLOITATION_OU_DE_LEUR_CONJOINT_MENTIONNE_A_L_ARTICLE_L_722_10_DU_MEME_CODE_DES_LORS_QU_IL_PARTICIPE_EFFECTIVEMENT_A_L_ACTIVITE_DE_L_EXPLOITATION_AGRICOLE_OU_DE_L_ENTREPRISE = "08"  # Remplacement du chef d'une exploitation agricole (« ou d'une entreprise mentionnée aux 1° à 4° de l'article L. 722-1 du code rural et de la pêche maritime, d'un aide familial, d'un associé d'exploitation, ou de leur conjoint mentionné à l'article L. 722-10 du même code dès lors qu'il participe effectivement à l'activité de l'exploitation agricole ou de l'entreprise »)
    RECRUTEMENT_DE_PERSONNES_SANS_EMPLOI_RENCONTRANT_DES_DIFFICULTES_SOCIALES_ET_PROFESSIONNELLES_PARTICULIERES = "09"  # Recrutement de personnes sans emploi rencontrant des difficultés sociales et professionnelles particulières
    COMPLEMENT_DE_FORMATION_PROFESSIONNELLE_AU_SALARIE = (
        "10"  # Complément de formation professionnelle au salarié
    )
    FORMATION_PROFESSIONNELLE_AU_SALARIE_PAR_LA_VOIE_DE_L_APPRENTISSAGE_EN_VUE_DE_L_OBTENTION_D_UNE_QUALIFICATION_PROFESSIONNELLE_SANCTIONNEE_PAR_UN_DIPLOME_OU_UN_TITRE_A_FINALITE_PROFESSIONNELLE_ENREGISTRE_AU_REPERTOIRE_NATIONAL_DES_CERTIFICATIONS_PROFESSIONNELLES = "11"  # Formation professionnelle au salarié par la voie de l'apprentissage, en vue de l'obtention d'une qualification professionnelle sanctionnée par un diplôme ou un titre à finalité professionnelle enregistré au répertoire national des certifications professionnelles
    REMPLACEMENT_D_UN_SALARIE_PASSE_PROVISOIREMENT_A_TEMPS_PARTIEL = (
        "12"  # Remplacement d’un salarié passé provisoirement à temps partiel
    )
    ATTENTE_DE_LA_SUPPRESSION_DEFINITIVE_DU_POSTE_DU_SALARIE_AYANT_QUITTE_DEFINITIVEMENT_L_ENTREPRISE = "13"  # Attente de la suppression définitive du poste du salarié ayant quitté définitivement l’entreprise
    CONTRAT_DE_VOYAGE = "14"  # Contrat de voyage
    RECRUTEMENT_D_UN_INTERIMAIRE_EN_SA_QUALITE_DE_BOETH = (
        "15"  # Recrutement d'un intérimaire en sa qualité de BOETH
    )
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Remplacement d\u0027un salari\u00e9",
        "02": "Accroissement temporaire de l\u0027activit\u00e9 de l\u0027entreprise",
        "03": "Emplois \u00e0 caract\u00e8re saisonnier",
        "04": "Contrat vendanges",
        "05": "Contrat d\u2019usage",
        "06": "Contrat \u00e0 dur\u00e9e d\u00e9termin\u00e9e \u00e0 objet d\u00e9fini",
        "07": "Remplacement d\u0027un chef d\u0027entreprise (\u00ab artisanale, industrielle ou commerciale, d\u0027une personne exer\u00e7ant une profession lib\u00e9rale, de son conjoint participant effectivement \u00e0 l\u0027activit\u00e9 de l\u0027entreprise \u00e0 titre professionnel et habituel ou d\u0027un associ\u00e9 non salari\u00e9 d\u0027une soci\u00e9t\u00e9 civile professionnelle, d\u0027une soci\u00e9t\u00e9 civile de moyens ou d\u0027une soci\u00e9t\u00e9 d\u0027exercice lib\u00e9ral \u00bb)",
        "08": "Remplacement du chef d\u0027une exploitation agricole (\u00ab ou d\u0027une entreprise mentionn\u00e9e aux 1\u00b0 \u00e0 4\u00b0 de l\u0027article L. 722-1 du code rural et de la p\u00eache maritime, d\u0027un aide familial, d\u0027un associ\u00e9 d\u0027exploitation, ou de leur conjoint mentionn\u00e9 \u00e0 l\u0027article L. 722-10 du m\u00eame code d\u00e8s lors qu\u0027il participe effectivement \u00e0 l\u0027activit\u00e9 de l\u0027exploitation agricole ou de l\u0027entreprise \u00bb)",
        "09": "Recrutement de personnes sans emploi rencontrant des difficult\u00e9s sociales et professionnelles particuli\u00e8res",
        "10": "Compl\u00e9ment de formation professionnelle au salari\u00e9",
        "11": "Formation professionnelle au salari\u00e9 par la voie de l\u0027apprentissage, en vue de l\u0027obtention d\u0027une qualification professionnelle sanctionn\u00e9e par un dipl\u00f4me ou un titre \u00e0 finalit\u00e9 professionnelle enregistr\u00e9 au r\u00e9pertoire national des certifications professionnelles",
        "12": "Remplacement d\u2019un salari\u00e9 pass\u00e9 provisoirement \u00e0 temps partiel",
        "13": "Attente de la suppression d\u00e9finitive du poste du salari\u00e9 ayant quitt\u00e9 d\u00e9finitivement l\u2019entreprise",
        "14": "Contrat de voyage",
        "15": "Recrutement d\u0027un int\u00e9rimaire en sa qualit\u00e9 de BOETH",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Motif_Exclusion(str, Enum):
    FONCTIONNAIRES_DE_L_UNE_DES_TROIS_FONCTIONS_PUBLIQUES_ETAT_TERRITORIALE_HOSPITALIERE_SAUF_ADMISSION_SPECIFIQUE = "01"  # Fonctionnaires de l’une des trois fonctions publiques (Etat, Territoriale, Hospitalière) sauf admission spécifique
    PERSONNELS_NAVIGANTS_DE_LA_MARINE_MARCHANDE = (
        "02"  # Personnels navigants de la marine marchande
    )
    MARINS_PECHEURS = "03"  # Marins-pêcheurs
    CONTRAT_DE_TRAVAIL_FAISANT_L_OBJET_D_UNE_ATTESTATION_EMPLOYEUR_MENSUELLE_AEM_POUR_UN_OUVRIER_OU_TECHNICIEN_DE_L_EDITION_D_ENREGISTREMENT_SONORE_DE_LA_PRODUCTION_CINEMATOGRAPHIQUE_ET_AUDIOVISUELLE_DE_LA_RADIO_DE_LA_DIFFUSION_ET_DU_SPECTACLE = "05"  # Contrat de travail faisant l'objet d’une attestation employeur mensuelle (AEM) pour un ouvrier ou technicien de l'édition d'enregistrement sonore, de la production cinématographique et audiovisuelle, de la radio, de la diffusion et du spectacle
    CONTRAT_DE_TRAVAIL_FAISANT_L_OBJET_D_UNE_ATTESTATION_EMPLOYEUR_MENSUELLE_AEM_POUR_UN_ARTISTE_DU_SPECTACLE = "06"  # Contrat de travail faisant l'objet d'une attestation employeur mensuelle (AEM) pour un artiste du spectacle
    DOCKERS_CARTE_G = "13"  # Dockers carte G

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Fonctionnaires de l\u2019une des trois fonctions publiques (Etat, Territoriale, Hospitali\u00e8re) sauf admission sp\u00e9cifique",
        "02": "Personnels navigants de la marine marchande",
        "03": "Marins-p\u00eacheurs",
        "05": "Contrat de travail faisant l\u0027objet d\u2019une attestation employeur mensuelle (AEM) pour un ouvrier ou technicien de l\u0027\u00e9dition d\u0027enregistrement sonore, de la production cin\u00e9matographique et audiovisuelle, de la radio, de la diffusion et du spectacle",
        "06": "Contrat de travail faisant l\u0027objet d\u0027une attestation employeur mensuelle (AEM) pour un artiste du spectacle",
        "13": "Dockers carte G",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Motif_suspension(str, Enum):
    INVALIDITE_CATEGORIE_1 = "112"  # Invalidité catégorie 1
    INVALIDITE_CATEGORIE_2 = "114"  # Invalidité catégorie 2
    INVALIDITE_CATEGORIE_3 = "116"  # Invalidité catégorie 3
    COP_CONGES_PAYES = "200"  # COP (Congés payés)
    CONGE_DE_FORMATION_PROFESSIONNELLE = "301"  # Congé de Formation Professionnelle
    CONGE_DIVERS_NON_REMUNERE = "501"  # Congé divers non rémunéré
    CHOMAGE_INTEMPERIES = "507"  # Chômage intempéries
    MOBILITE_VOLONTAIRE_SECURISEE_INTERNATIONALE_DES_ALTERNANTS = (
        "601"  # Mobilité (volontaire sécurisée, internationale des alternants, …)
    )
    CHOMAGE_SANS_RUPTURE_DE_CONTRAT = "602"  # Chômage sans rupture de contrat
    DETENTION_PROVISOIRE = "603"  # Détention provisoire
    CONGE_STATUTAIRE = "605"  # Congé statutaire
    DETACHEMENT_D_UN_SALARIE_IEG_EN_FRANCE = "606"  # Détachement d'un salarié IEG en France
    CONGE_DE_PRESENCE_PARENTALE = "607"  # Congé de présence parentale
    CASA_CATS_CESSATION_D_ACTIVITE_DES_TRAVAILLEURS_SALARIES = (
        "608"  # CASA-CATS (Cessation d'Activité des Travailleurs Salariés)
    )
    CIF_CONGE_INDIVIDUEL_DE_FORMATION = "609"  # CIF (Congé Individuel de Formation)
    PROJET_DE_TRANSITION_PROFESSIONNELLE_PTP_OU_CONGE_DE_RECONVERSION_PROFESSIONNELLE_CRP = "610"  # Projet de Transition Professionnelle (PTP) ou Congé de Reconversion Professionnelle (CRP)
    CONGE_DE_BILAN_DE_COMPETENCES = "611"  # Congé de bilan de compétences
    CONGE_DE_CANDIDAT_PARLEMENTAIRE_OU_ELU_A_UN_MANDAT_LOCAL = (
        "612"  # Congé de candidat parlementaire ou élu à un mandat local
    )
    CONGE_DE_FORMATION_DE_CADRES_ET_D_ANIMATEURS_POUR_LA_JEUNESSE = (
        "615"  # Congé de formation de cadres et d'animateurs pour la jeunesse
    )
    CONGE_DE_FORMATION_POUR_LES_SALARIES_DE_MOINS_DE_25_ANS = (
        "617"  # Congé de formation pour les salariés de moins de 25 ans
    )
    CONGE_DE_FORMATION_ECONOMIQUE_SOCIALE_ET_SYNDICALE = (
        "618"  # Congé de formation économique, sociale et syndicale
    )
    CONGE_DE_MOBILITE = "620"  # Congé de mobilité
    CONGE_DE_PARTICIPATION_AUX_INSTANCES_D_EMPLOI_OU_DE_FORMATION_PROFESSIONNELLE = (
        "621"  # Congé de participation aux instances d'emploi ou de formation professionnelle
    )
    CONGE_DE_RECLASSEMENT = "625"  # Congé de reclassement
    CONGE_DE_REPRESENTATION = "626"  # Congé de représentation
    CONGE_DE_SOLIDARITE_FAMILIALE = "627"  # Congé de solidarité familiale
    CONGE_DE_SOLIDARITE_INTERNATIONALE = "628"  # Congé de solidarité internationale
    CONGE_D_ENSEIGNEMENT_OU_DE_RECHERCHE = "630"  # Congé d'enseignement ou de recherche
    CONGE_MUTUALISTE_DE_FORMATION = "631"  # Congé mutualiste de formation
    CONGE_PARENTAL_D_EDUCATION = "632"  # Congé parental d'éducation
    CONGE_POUR_ACQUISITION_DE_LA_NATIONALITE = "633"  # Congé pour acquisition de la nationalité
    CONGE_POUR_CATASTROPHE_NATURELLE = "634"  # Congé pour catastrophe naturelle
    CONGE_POUR_CREATION_OU_REPRISE_D_ENTREPRISE = (
        "635"  # Congé pour création ou reprise d'entreprise
    )
    CONGE_POUR_ENFANT_MALADE = "636"  # Congé pour enfant malade
    CONGE_POUR_EVENEMENT_FAMILIAL = "637"  # Congé pour évènement familial
    CONGE_POUR_VALIDATION_DES_ACQUIS_DE_L_EXPERIENCE = (
        "638"  # Congé pour validation des acquis de l'expérience
    )
    CONGE_SABBATIQUE = "639"  # Congé sabbatique
    CONVENTION_FNE_D_AIDE_AU_PASSAGE_A_TEMPS_PARTIEL = (
        "642"  # Convention FNE d'aide au passage à temps partiel
    )
    CONGE_DE_CONVERSION_AVEC_PRISE_EN_CHARGE_PAR_L_ETAT = (
        "643"  # Congé de conversion avec prise en charge par l'Etat
    )
    CONGE_DE_CONVERSION_SANS_PRISE_EN_CHARGE_PAR_L_ETAT = (
        "644"  # Congé de conversion sans prise en charge par l'Etat
    )
    PRERETRAITE_PROGRESSIVE = "645"  # Préretraite progressive
    PRERETRAITE_D_ENTREPRISE_SANS_RUPTURE_DE_CONTRAT_DE_TRAVAIL = (
        "646"  # Préretraite d'entreprise sans rupture de contrat de travail
    )
    REDUCTION_TEMPS_D_EMPLOI = "647"  # Réduction temps d'emploi
    CONVENTIONS_D_ALLOCATIONS_SPECIALES_DU_FNE_ASFNE = (
        "648"  # Conventions d'Allocations Spéciales du FNE (ASFNE)
    )
    CONGE_DE_PROCHE_AIDANT = "650"  # Congé de proche aidant
    CONGE_POUR_MANDAT_PARLEMENTAIRE = "651"  # Congé pour mandat parlementaire
    INAPTITUDE_TEMPORAIRE_LIEE_A_LA_GROSSESSE = "652"  # Inaptitude temporaire liée à la grossesse
    MAINTIEN_DE_SALAIRE_PERSONNEL_NAVIGANT_DE_L_AERONAUTIQUE_CIVILE = (
        "653"  # Maintien de salaire – personnel navigant de l’aéronautique civile
    )
    INACTIVITE_TEMPS_ALTERNE_PERSONNEL_NAVIGANT_DE_L_AERONAUTIQUE_CIVILE = (
        "654"  # Inactivité temps alterné – personnel navigant de l’aéronautique civile
    )
    FP_DETACHEMENT_CONDUISANT_A_PENSION_ECP = "655"  # [FP] Détachement conduisant à pension (ECP)
    FP_CONGE_POUR_CESSATION_ANTICIPEE_D_ACTIVITE_DU_FAIT_D_UNE_MALADIE_PROFESSIONNELLE_PROVOQUEE_PAR_L_AMIANTE = "656"  # [FP] Congé pour cessation anticipée d’activité du fait d’une maladie professionnelle provoquée par l’amiante
    FP_ABSENCE_CONCERTEE_DE_TRAVAIL = "657"  # [FP] Absence concertée de travail
    FP_CONGE_SPECIAL = "658"  # [FP] Congé spécial
    FP_PERIODE_D_INSTRUCTION_MILITAIRE_OU_RESERVE_OPERATIONNELLE = (
        "659"  # [FP] Période d'instruction militaire ou réserve opérationnelle
    )
    FP_CONGE_AVEC_TRAITEMENT_PERIODE_D_INSTRUCTION_MILITAIRE_OBLIGATOIRE = (
        "660"  # [FP] Congé avec traitement période d'instruction militaire obligatoire
    )
    FP_CONGE_ORGANISATIONS_DE_JEUNESSE = "661"  # [FP] Congé organisations de jeunesse
    FP_CONGE_POUR_SIEGER_AUPRES_D_UNE_ASSOCIATION_D_UNE_MUTUELLE_D_UNE_INSTANCE_DE_L_ETAT_OU_D_UNE_COLLECTIVITE_TERRITORIALE = "662"  # [FP] Congé pour siéger auprès d’une association, d’une mutuelle, d’une instance de l’Etat ou d’une collectivité territoriale
    FP_CONGE_NON_REMUNERE_DE_18_JOURS_POUR_MANDATS_MUNICIPAUX_OU_DEPARTEMENTAUX_OU_REGIONAUX = "663"  # [FP] Congé non rémunéré de 18 jours pour mandats municipaux ou départementaux ou régionaux
    FP_CONGE_AVEC_TRAITEMENT_POUR_PERIODE_D_ACTIVITE_DANS_LA_RESERVE_DE_SECURITE_CIVILE = "664"  # [FP] Congé avec traitement pour période d'activité dans la réserve de sécurité civile
    FP_CONGE_POUR_PERIODE_D_ACTIVITE_DANS_LA_RESERVE_SANITAIRE = (
        "665"  # [FP] Congé pour période d'activité dans la réserve sanitaire
    )
    FP_CONGE_POUR_RECHERCHES_OU_CONVERSIONS_THEMATIQUES = (
        "666"  # [FP] Congé pour recherches ou conversions thématiques
    )
    FP_CONGE_POUR_RAISONS_OPERATIONNELLES_ET_ACTIVITES_PRIVEES_DES_SAPEURS_POMPIERS_PROFESSIONNELS = "667"  # [FP] Congé pour raisons opérationnelles et activités privées des sapeurs-pompiers professionnels
    FP_CONGE_POUR_RAISONS_OPERATIONNELLES_COTISE_DES_SAPEURS_POMPIERS_PROFESSIONNELS = (
        "668"  # [FP] Congé pour raisons opérationnelles cotisé des sapeurs-pompiers professionnels
    )
    FP_CONGE_POUR_DIFFICULTES_OPERATIONNELLES_DES_SAPEURS_POMPIERS_PROFESSIONNELS = (
        "669"  # [FP] Congé pour difficultés opérationnelles des sapeurs-pompiers professionnels
    )
    FP_CONGE_POUR_PERIODE_D_ACTIVITE_DANS_LA_RESERVE_CIVILE_DE_LA_POLICE = (
        "670"  # [FP] Congé pour période d'activité dans la réserve civile de la police
    )
    FP_EXCLUSION_TEMPORAIRE_DE_FONCTIONS = "671"  # [FP] Exclusion temporaire de fonctions
    FP_SUSPENSION = "672"  # [FP] Suspension
    FP_ABSENCES_IRREGULIERES_SERVICE_NON_FAIT = (
        "673"  # [FP] Absences irrégulières (service non fait)
    )
    FP_DETACHEMENT_NE_CONDUISANT_PAS_A_PENSION_ENCP = (
        "674"  # [FP] Détachement ne conduisant pas à pension (ENCP)
    )
    FP_DISPONIBILITE = "675"  # [FP] Disponibilité
    FP_DISPONIBILITE_POUR_MALADIE = "676"  # [FP] Disponibilité pour maladie
    DISPONIBILITE_POUR_ELEVER_UN_ENFANT_AGE_DE_MOINS_DE_12_ANS_DE_MOINS_DE_8_ANS_POUR_LA_RATP = "677"  # Disponibilité pour élever un enfant âgé de moins de 12 ans (de moins de 8 ans pour la RATP)
    FP_POSITION_HORS_CADRES = "678"  # [FP] Position hors cadres
    CONGE_SANS_SOLDE_COTISE = "680"  # Congé sans solde cotisé
    DETACHEMENT_HORS_IEG = "681"  # Détachement hors IEG
    POTENTIEL_NOUVEAU_MOTIF_DE_SUSPENSION_A = "683"  # Potentiel nouveau motif de suspension A
    POTENTIEL_NOUVEAU_MOTIF_DE_SUSPENSION_B = "684"  # Potentiel nouveau motif de suspension B
    POTENTIEL_NOUVEAU_MOTIF_DE_SUSPENSION_C = "685"  # Potentiel nouveau motif de suspension C
    CONTRAT_SUSPENDU_POUR_EXPATRIATION = "686"  # Contrat suspendu pour expatriation
    POTENTIEL_NOUVEAU_MOTIF_DE_SUSPENSION_D = "687"  # Potentiel nouveau motif de suspension D
    POTENTIEL_NOUVEAU_MOTIF_DE_SUSPENSION_E = "688"  # Potentiel nouveau motif de suspension E
    ANNULATION = "998"  # Annulation

    __DESCRIPTIONS: dict[str, str] = {
        "112": "Invalidit\u00e9 cat\u00e9gorie 1",
        "114": "Invalidit\u00e9 cat\u00e9gorie 2",
        "116": "Invalidit\u00e9 cat\u00e9gorie 3",
        "200": "COP (Cong\u00e9s pay\u00e9s)",
        "301": "Cong\u00e9 de Formation Professionnelle",
        "501": "Cong\u00e9 divers non r\u00e9mun\u00e9r\u00e9",
        "507": "Ch\u00f4mage intemp\u00e9ries",
        "601": "Mobilit\u00e9 (volontaire s\u00e9curis\u00e9e, internationale des alternants, \u2026)",
        "602": "Ch\u00f4mage sans rupture de contrat",
        "603": "D\u00e9tention provisoire",
        "605": "Cong\u00e9 statutaire",
        "606": "D\u00e9tachement d\u0027un salari\u00e9 IEG en France",
        "607": "Cong\u00e9 de pr\u00e9sence parentale",
        "608": "CASA-CATS (Cessation d\u0027Activit\u00e9 des Travailleurs Salari\u00e9s)",
        "609": "CIF (Cong\u00e9 Individuel de Formation)",
        "610": "Projet de Transition Professionnelle (PTP) ou Cong\u00e9 de Reconversion Professionnelle (CRP)",
        "611": "Cong\u00e9 de bilan de comp\u00e9tences",
        "612": "Cong\u00e9 de candidat parlementaire ou \u00e9lu \u00e0 un mandat local",
        "615": "Cong\u00e9 de formation de cadres et d\u0027animateurs pour la jeunesse",
        "617": "Cong\u00e9 de formation pour les salari\u00e9s de moins de 25 ans",
        "618": "Cong\u00e9 de formation \u00e9conomique, sociale et syndicale",
        "620": "Cong\u00e9 de mobilit\u00e9",
        "621": "Cong\u00e9 de participation aux instances d\u0027emploi ou de formation professionnelle",
        "625": "Cong\u00e9 de reclassement",
        "626": "Cong\u00e9 de repr\u00e9sentation",
        "627": "Cong\u00e9 de solidarit\u00e9 familiale",
        "628": "Cong\u00e9 de solidarit\u00e9 internationale",
        "630": "Cong\u00e9 d\u0027enseignement ou de recherche",
        "631": "Cong\u00e9 mutualiste de formation",
        "632": "Cong\u00e9 parental d\u0027\u00e9ducation",
        "633": "Cong\u00e9 pour acquisition de la nationalit\u00e9",
        "634": "Cong\u00e9 pour catastrophe naturelle",
        "635": "Cong\u00e9 pour cr\u00e9ation ou reprise d\u0027entreprise",
        "636": "Cong\u00e9 pour enfant malade",
        "637": "Cong\u00e9 pour \u00e9v\u00e8nement familial",
        "638": "Cong\u00e9 pour validation des acquis de l\u0027exp\u00e9rience",
        "639": "Cong\u00e9 sabbatique",
        "642": "Convention FNE d\u0027aide au passage \u00e0 temps partiel",
        "643": "Cong\u00e9 de conversion avec prise en charge par l\u0027Etat",
        "644": "Cong\u00e9 de conversion sans prise en charge par l\u0027Etat",
        "645": "Pr\u00e9retraite progressive",
        "646": "Pr\u00e9retraite d\u0027entreprise sans rupture de contrat de travail",
        "647": "R\u00e9duction temps d\u0027emploi",
        "648": "Conventions d\u0027Allocations Sp\u00e9ciales du FNE (ASFNE)",
        "650": "Cong\u00e9 de proche aidant",
        "651": "Cong\u00e9 pour mandat parlementaire",
        "652": "Inaptitude temporaire li\u00e9e \u00e0 la grossesse",
        "653": "Maintien de salaire \u2013 personnel navigant de l\u2019a\u00e9ronautique civile",
        "654": "Inactivit\u00e9 temps altern\u00e9 \u2013 personnel navigant de l\u2019a\u00e9ronautique civile",
        "655": "[FP] D\u00e9tachement conduisant \u00e0 pension (ECP)",
        "656": "[FP] Cong\u00e9 pour cessation anticip\u00e9e d\u2019activit\u00e9 du fait d\u2019une maladie professionnelle provoqu\u00e9e par l\u2019amiante",
        "657": "[FP] Absence concert\u00e9e de travail",
        "658": "[FP] Cong\u00e9 sp\u00e9cial",
        "659": "[FP] P\u00e9riode d\u0027instruction militaire ou r\u00e9serve op\u00e9rationnelle",
        "660": "[FP] Cong\u00e9 avec traitement p\u00e9riode d\u0027instruction militaire obligatoire",
        "661": "[FP] Cong\u00e9 organisations de jeunesse",
        "662": "[FP] Cong\u00e9 pour si\u00e9ger aupr\u00e8s d\u2019une association, d\u2019une mutuelle, d\u2019une instance de l\u2019Etat ou d\u2019une collectivit\u00e9 territoriale",
        "663": "[FP] Cong\u00e9 non r\u00e9mun\u00e9r\u00e9 de 18 jours pour mandats municipaux ou d\u00e9partementaux ou r\u00e9gionaux",
        "664": "[FP] Cong\u00e9 avec traitement pour p\u00e9riode d\u0027activit\u00e9 dans la r\u00e9serve de s\u00e9curit\u00e9 civile",
        "665": "[FP] Cong\u00e9 pour p\u00e9riode d\u0027activit\u00e9 dans la r\u00e9serve sanitaire",
        "666": "[FP] Cong\u00e9 pour recherches ou conversions th\u00e9matiques",
        "667": "[FP] Cong\u00e9 pour raisons op\u00e9rationnelles et activit\u00e9s priv\u00e9es des sapeurs-pompiers professionnels",
        "668": "[FP] Cong\u00e9 pour raisons op\u00e9rationnelles cotis\u00e9 des sapeurs-pompiers professionnels",
        "669": "[FP] Cong\u00e9 pour difficult\u00e9s op\u00e9rationnelles des sapeurs-pompiers professionnels",
        "670": "[FP] Cong\u00e9 pour p\u00e9riode d\u0027activit\u00e9 dans la r\u00e9serve civile de la police",
        "671": "[FP] Exclusion temporaire de fonctions",
        "672": "[FP] Suspension",
        "673": "[FP] Absences irr\u00e9guli\u00e8res (service non fait)",
        "674": "[FP] D\u00e9tachement ne conduisant pas \u00e0 pension (ENCP)",
        "675": "[FP] Disponibilit\u00e9",
        "676": "[FP] Disponibilit\u00e9 pour maladie",
        "677": "Disponibilit\u00e9 pour \u00e9lever un enfant \u00e2g\u00e9 de moins de 12 ans (de moins de 8 ans pour la RATP)",
        "678": "[FP] Position hors cadres",
        "680": "Cong\u00e9 sans solde cotis\u00e9",
        "681": "D\u00e9tachement hors IEG",
        "683": "Potentiel nouveau motif de suspension A",
        "684": "Potentiel nouveau motif de suspension B",
        "685": "Potentiel nouveau motif de suspension C",
        "686": "Contrat suspendu pour expatriation",
        "687": "Potentiel nouveau motif de suspension D",
        "688": "Potentiel nouveau motif de suspension E",
        "998": "Annulation",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Renumeration_Type(str, Enum):
    REMUNERATION_BRUTE_NON_PLAFONNEE = "001"  # Rémunération brute non plafonnée
    SALAIRE_BRUT_SERVANT_AUX_CALCULS_DES_DROITS_DE_L_ASSURANCE_CHOMAGE = (
        "002"  # Salaire brut servant aux calculs des droits de l'Assurance chômage
    )
    SALAIRE_RETABLI_RECONSTITUE = "003"  # Salaire rétabli – reconstitué
    SALAIRE_DE_BASE = "010"  # Salaire de base
    HEURES_D_EQUIVALENCE = "012"  # Heures d’équivalence
    HEURES_D_HABILLAGE_DESHABILLAGE_PAUSE = "013"  # Heures d’habillage, déshabillage, pause
    FP_HEURES_AFFECTEES_A_UN_TRAVAIL_D_AIDE_A_DOMICILE = (
        "016"  # [FP] Heures affectées à un travail d’aide à domicile
    )
    HEURES_SUPPLEMENTAIRES_OU_COMPLEMENTAIRES_ALEATOIRES = (
        "017"  # Heures supplémentaires ou complémentaires aléatoires
    )
    HEURES_SUPPLEMENTAIRES_STRUCTURELLES = "018"  # Heures supplémentaires structurelles
    HEURES_D_ACTIVITE_PARTIELLE = "019"  # Heures d'activité partielle
    HEURES_AFFECTEES_A_UN_TRAVAIL_D_AIDE_A_DOMICILE_DE_PUBLICS_FRAGILES = (
        "020"  # Heures affectées à un travail d’aide à domicile de publics fragiles
    )
    FP_TAUX_DE_REMUNERATION_DE_LA_SITUATION_ADMINISTRATIVE = (
        "021"  # [FP] Taux de rémunération de la situation administrative
    )
    FP_COMPLEMENT_DE_TRAITEMENT_INDICIAIRE_CTI = (
        "022"  # [FP] Complément de traitement indiciaire (CTI)
    )
    JOURS_DE_RTT_MONETISES = "023"  # Jours de RTT monétisés
    HEURES_CORRESPONDANT_A_DU_CHOMAGE_INTEMPERIES = (
        "025"  # Heures correspondant à du chômage intempéries
    )
    REMUNERATION_PERCUE_HORS_ELEMENTS_NON_AFFECTES_PAR_L_ABSENCE = (
        "028"  # Rémunération perçue hors éléments non affectés par l’absence
    )
    REMUNERATION_HABITUELLE_MOIS_COMPLET_HORS_ELEMENTS_NON_AFFECTES_PAR_L_ABSENCE = (
        "029"  # Rémunération habituelle mois complet hors éléments non affectés par l’absence
    )
    POTENTIEL_NOUVEAU_TYPE_DE_REMUNERATION_A = "030"  # Potentiel nouveau type de rémunération A
    POTENTIEL_NOUVEAU_TYPE_DE_REMUNERATION_D = "031"  # Potentiel nouveau type de rémunération D
    POTENTIEL_NOUVEAU_TYPE_DE_REMUNERATION_E = "032"  # Potentiel nouveau type de rémunération E
    POTENTIEL_NOUVEAU_TYPE_DE_REMUNERATION_B = "034"  # Potentiel nouveau type de rémunération B
    POTENTIEL_NOUVEAU_TYPE_DE_REMUNERATION_C = "035"  # Potentiel nouveau type de rémunération C

    __DESCRIPTIONS: dict[str, str] = {
        "001": "R\u00e9mun\u00e9ration brute non plafonn\u00e9e",
        "002": "Salaire brut servant aux calculs des droits de l\u0027Assurance ch\u00f4mage",
        "003": "Salaire r\u00e9tabli \u2013 reconstitu\u00e9",
        "010": "Salaire de base",
        "012": "Heures d\u2019\u00e9quivalence",
        "013": "Heures d\u2019habillage, d\u00e9shabillage, pause",
        "016": "[FP] Heures affect\u00e9es \u00e0 un travail d\u2019aide \u00e0 domicile",
        "017": "Heures suppl\u00e9mentaires ou compl\u00e9mentaires al\u00e9atoires",
        "018": "Heures suppl\u00e9mentaires structurelles",
        "019": "Heures d\u0027activit\u00e9 partielle",
        "020": "Heures affect\u00e9es \u00e0 un travail d\u2019aide \u00e0 domicile de publics fragiles",
        "021": "[FP] Taux de r\u00e9mun\u00e9ration de la situation administrative",
        "022": "[FP] Compl\u00e9ment de traitement indiciaire (CTI)",
        "023": "Jours de RTT mon\u00e9tis\u00e9s",
        "025": "Heures correspondant \u00e0 du ch\u00f4mage intemp\u00e9ries",
        "028": "R\u00e9mun\u00e9ration per\u00e7ue hors \u00e9l\u00e9ments non affect\u00e9s par l\u2019absence",
        "029": "R\u00e9mun\u00e9ration habituelle mois complet hors \u00e9l\u00e9ments non affect\u00e9s par l\u2019absence",
        "030": "Potentiel nouveau type de r\u00e9mun\u00e9ration A",
        "031": "Potentiel nouveau type de r\u00e9mun\u00e9ration D",
        "032": "Potentiel nouveau type de r\u00e9mun\u00e9ration E",
        "034": "Potentiel nouveau type de r\u00e9mun\u00e9ration B",
        "035": "Potentiel nouveau type de r\u00e9mun\u00e9ration C",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class CCN_Categorie(str, Enum):
    AGRICULTEUR_SALARIE_DE_SON_EXPLOITATION = "01"  # agriculteur salarié de son exploitation
    ARTISAN_OU_COMMERCANT_SALARIE_DE_SON_ENTREPRISE = (
        "02"  # artisan ou commerçant salarié de son entreprise
    )
    CADRE_DIRIGEANT_VOTANT_AU_COLLEGE_EMPLOYEUR_DES_ELECTIONS_PRUD_HOMALES = (
        "03"  # cadre dirigeant (votant au collège employeur des élections prud'homales)
    )
    AUTRES_CADRES_AU_SENS_DE_LA_CONVENTION_COLLECTIVE_OU_DU_STATUT_POUR_LES_REGIMES_SPECIAUX = "04"  # autres cadres au sens de la convention collective (ou du statut pour les régimes spéciaux)
    PROFESSION_INTERMEDIAIRE_TECHNICIEN_CONTREMAITRE_AGENT_DE_MAITRISE_CLERGE = (
        "05"  # profession intermédiaire (technicien, contremaître, agent de maîtrise, clergé)
    )
    EMPLOYE_ADMINISTRATIF_D_ENTREPRISE_DE_COMMERCE_AGENT_DE_SERVICE = (
        "06"  # employé administratif d'entreprise, de commerce, agent de service
    )
    OUVRIERS_QUALIFIES_ET_NON_QUALIFIES_Y_COMPRIS_OUVRIERS_AGRICOLES = (
        "07"  # ouvriers qualifiés et non qualifiés y compris ouvriers agricoles
    )
    AGENT_DE_LA_FONCTION_PUBLIQUE_D_ETAT = "08"  # agent de la fonction publique d'Etat
    AGENT_DE_LA_FONCTION_PUBLIQUE_HOSPITALIERE = "09"  # agent de la fonction publique hospitalière
    AGENT_DE_LA_FONCTION_PUBLIQUE_TERRITORIALE = "10"  # agent de la fonction publique territoriale

    __DESCRIPTIONS: dict[str, str] = {
        "01": "agriculteur salari\u00e9 de son exploitation",
        "02": "artisan ou commer\u00e7ant salari\u00e9 de son entreprise",
        "03": "cadre dirigeant (votant au coll\u00e8ge employeur des \u00e9lections prud\u0027homales)",
        "04": "autres cadres au sens de la convention collective (ou du statut pour les r\u00e9gimes sp\u00e9ciaux)",
        "05": "profession interm\u00e9diaire (technicien, contrema\u00eetre, agent de ma\u00eetrise, clerg\u00e9)",
        "06": "employ\u00e9 administratif d\u0027entreprise, de commerce, agent de service",
        "07": "ouvriers qualifi\u00e9s et non qualifi\u00e9s y compris ouvriers agricoles",
        "08": "agent de la fonction publique d\u0027Etat",
        "09": "agent de la fonction publique hospitali\u00e8re",
        "10": "agent de la fonction publique territoriale",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Renum_AC(str, Enum):
    SALAIRE_REEL = "01"  # Salaire réel
    SALAIRE_DE_COMPARAISON = "02"  # Salaire de comparaison

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Salaire r\u00e9el",
        "02": "Salaire de comparaison",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Type_erreurs_Regul_PAS(str, Enum):
    RECTIFICATION_SUR_REMUNERATION_NETTE_FISCALE = (
        "01"  # Rectification sur rémunération nette fiscale
    )
    RECTIFICATION_SUR_TAUX = "02"  # Rectification sur taux
    CAS_D_INDU_AVEC_REMUNERATION_NETTE_FISCALE_DU_MOIS_COURANT_NEGATIVE = (
        "03"  # Cas d’indu avec rémunération nette fiscale du mois courant négative
    )
    RECTIFICATION_SUR_REMUNERATION_NETTE_FISCALE_SANS_PAS = (
        "04"  # Rectification sur rémunération nette fiscale sans PAS
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Rectification sur r\u00e9mun\u00e9ration nette fiscale",
        "02": "Rectification sur taux",
        "03": "Cas d\u2019indu avec r\u00e9mun\u00e9ration nette fiscale du mois courant n\u00e9gative",
        "04": "Rectification sur r\u00e9mun\u00e9ration nette fiscale sans PAS",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Type_erreurs_PAS(str, Enum):
    RECTIFICATION_SUR_MONTANT_NET_FISCAL_DU_REVENU_VERSE = (
        "01"  # Rectification sur montant net fiscal du revenu versé
    )
    RECTIFICATION_SUR_TAUX = "02"  # Rectification sur taux
    CAS_D_INDU_AVEC_MONTANT_NET_FISCAL_DU_MOIS_COURANT_NEGATIF = (
        "03"  # Cas d’indu avec montant net fiscal du mois courant négatif
    )
    RECTIFICATION_SUR_MONTANT_NET_FISCAL_DU_REVENU_VERSE_SANS_PAS = (
        "04"  # Rectification sur montant net fiscal du revenu versé sans PAS
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Rectification sur montant net fiscal du revenu vers\u00e9",
        "02": "Rectification sur taux",
        "03": "Cas d\u2019indu avec montant net fiscal du mois courant n\u00e9gatif",
        "04": "Rectification sur montant net fiscal du revenu vers\u00e9 sans PAS",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Regime_Base_risque_vieillesse(str, Enum):
    RETRAITE_DES_AGENTS_DES_COLLECTIVITES_LOCALES_CNRACL = (
        "120"  # retraite des agents des collectivités locales (CNRACL)
    )
    PENSIONS_DES_OUVRIERS_DES_ETABLISSEMENTS_INDUSTRIELS_DE_L_ETAT_FSPOEIE = (
        "121"  # pensions des ouvriers des établissements industriels de l'Etat (FSPOEIE)
    )
    PENSIONS_CIVILES_ET_MILITAIRES_DE_RETRAITE_DE_L_ETAT_SRE = (
        "122"  # pensions civiles et militaires de retraite de l'Etat (SRE)
    )
    REGIME_SPECIAL_DE_LA_BRANCHE_FERROVIAIRE = "134"  # régime spécial de la branche ferroviaire
    REGIME_SPECIAL_DE_LA_RATP = "135"  # régime spécial de la RATP
    ETABLISSEMENT_DES_INVALIDES_DE_LA_MARINE_ENIM = (
        "136"  # établissement des invalides de la marine (ENIM)
    )
    MINEURS_OU_ASSIMILES_FONDS_CAISSE_DES_DEPOTS = (
        "137"  # mineurs ou assimilés (fonds Caisse des Dépôts)
    )
    BANQUE_DE_FRANCE = "139"  # Banque de France
    CLERCS_ET_EMPLOYES_DE_NOTAIRES_CRPCEN = "140"  # clercs et employés de notaires (CRPCEN)
    CHAMBRE_DE_COMMERCE_ET_D_INDUSTRIE_DE_PARIS = (
        "141"  # chambre de commerce et d'industrie de Paris
    )
    ASSEMBLEE_NATIONALE = "144"  # Assemblée Nationale
    SENAT = "145"  # Sénat
    REGIME_SPECIAL_DES_INDUSTRIES_ELECTRIQUES_ET_GAZIERES_CNIEG = (
        "147"  # régime spécial des industries électriques et gazières (CNIEG)
    )
    REGIME_DES_CULTES_CAVIMAC = "149"  # régime des cultes (CAVIMAC)
    REGIME_DE_RETRAITE_DES_AVOCATS_CNBF = "157"  # régime de retraite des avocats (CNBF)
    SEITA = "158"  # SEITA
    COMEDIE_FRANCAISE = "159"  # Comédie Française
    OPERA_DE_PARIS = "160"  # Opéra de Paris
    REGIME_GENERAL_CNAV = "200"  # régime général (CNAV)
    REGIME_AGRICOLE_MSA = "300"  # régime agricole (MSA)
    AUTRE_REGIME_RESERVE_POLYNESIE_FRANCAISE_NOUVELLE_CALEDONIE = (
        "900"  # autre régime (réservé Polynésie Française, Nouvelle Calédonie)
    )
    PRINCIPAUTE_DE_MONACO = "904"  # principauté de Monaco
    REGIME_GENERAL_POUR_LA_DECLARATION_DES_INDIVIDUS_DE_MAYOTTE_AFFILIES_A_LA_CSSM = (
        "905"  # Régime général pour la déclaration des individus de Mayotte affiliés à la CSSM
    )
    TRAVAILLEUR_NON_ASSUJETTI_A_UN_REGIME_DE_BASE_RISQUE_VIEILLESSE_EN_FRANCE = (
        "909"  # travailleur non assujetti à un régime de base risque vieillesse en France
    )
    ABSENCE_D_AFFILIATION_POUR_LE_PERSONNEL_MEDICAL_HOSPITALIER_UNIVERSITAIRE = (
        "994"  # absence d'affiliation pour le personnel médical hospitalier universitaire
    )
    ABSENCE_D_AFFILIATION_POUR_UN_FONCTIONNAIRE_EN_CUMUL_D_ACTIVITE_A_TITRE_ACCESSOIRE = (
        "995"  # absence d’affiliation pour un fonctionnaire en cumul d’activité à titre accessoire
    )
    ABSENCE_D_AFFILIATION_POUR_UN_EXPATRIE = "996"  # absence d’affiliation pour un expatrié
    ABSENCE_D_AFFILIATION_POUR_UN_STAGIAIRE_HORS_FORMATION_PROFESSIONNELLE = (
        "997"  # absence d’affiliation pour un stagiaire hors formation professionnelle
    )
    ABSENCE_D_AFFILIATION_POUR_UN_ELU = "998"  # absence d’affiliation pour un élu

    __DESCRIPTIONS: dict[str, str] = {
        "120": "retraite des agents des collectivit\u00e9s locales (CNRACL)",
        "121": "pensions des ouvriers des \u00e9tablissements industriels de l\u0027Etat (FSPOEIE)",
        "122": "pensions civiles et militaires de retraite de l\u0027Etat (SRE)",
        "134": "r\u00e9gime sp\u00e9cial de la branche ferroviaire",
        "135": "r\u00e9gime sp\u00e9cial de la RATP",
        "136": "\u00e9tablissement des invalides de la marine (ENIM)",
        "137": "mineurs ou assimil\u00e9s (fonds Caisse des D\u00e9p\u00f4ts)",
        "139": "Banque de France",
        "140": "clercs et employ\u00e9s de notaires (CRPCEN)",
        "141": "chambre de commerce et d\u0027industrie de Paris",
        "144": "Assembl\u00e9e Nationale",
        "145": "S\u00e9nat",
        "147": "r\u00e9gime sp\u00e9cial des industries \u00e9lectriques et gazi\u00e8res (CNIEG)",
        "149": "r\u00e9gime des cultes (CAVIMAC)",
        "157": "r\u00e9gime de retraite des avocats (CNBF)",
        "158": "SEITA",
        "159": "Com\u00e9die Fran\u00e7aise",
        "160": "Op\u00e9ra de Paris",
        "200": "r\u00e9gime g\u00e9n\u00e9ral (CNAV)",
        "300": "r\u00e9gime agricole (MSA)",
        "900": "autre r\u00e9gime (r\u00e9serv\u00e9 Polyn\u00e9sie Fran\u00e7aise, Nouvelle Cal\u00e9donie)",
        "904": "principaut\u00e9 de Monaco",
        "905": "R\u00e9gime g\u00e9n\u00e9ral pour la d\u00e9claration des individus de Mayotte affili\u00e9s \u00e0 la CSSM",
        "909": "travailleur non assujetti \u00e0 un r\u00e9gime de base risque vieillesse en France",
        "994": "absence d\u0027affiliation pour le personnel m\u00e9dical hospitalier universitaire",
        "995": "absence d\u2019affiliation pour un fonctionnaire en cumul d\u2019activit\u00e9 \u00e0 titre accessoire",
        "996": "absence d\u2019affiliation pour un expatri\u00e9",
        "997": "absence d\u2019affiliation pour un stagiaire hors formation professionnelle",
        "998": "absence d\u2019affiliation pour un \u00e9lu",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class AA_Categorie(str, Enum):
    CADRE_ARTICLE_4_ET_4BIS = "01"  # cadre (article 4 et 4bis)
    EXTENSION_CADRE_POUR_RETRAITE_COMPLEMENTAIRE = (
        "02"  # extension cadre pour retraite complémentaire
    )
    NON_CADRE = "04"  # non cadre
    RETRAITE_COMPLEMENTAIRE_NE_DEFINISSANT_PAS_DE_STATUT_CADRE_OU_NON_CADRE = (
        "98"  # retraite complémentaire ne définissant pas de statut cadre ou non-cadre
    )
    PAS_DE_RETRAITE_COMPLEMENTAIRE = "99"  # pas de retraite complémentaire

    __DESCRIPTIONS: dict[str, str] = {
        "01": "cadre (article 4 et 4bis)",
        "02": "extension cadre pour retraite compl\u00e9mentaire",
        "04": "non cadre",
        "98": "retraite compl\u00e9mentaire ne d\u00e9finissant pas de statut cadre ou non-cadre",
        "99": "pas de retraite compl\u00e9mentaire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_StatutBOETH(str, Enum):
    TRAVAILLEUR_RECONNU_HANDICAPE_PAR_LA_COMMISSION_DES_DROITS_ET_DE_L_AUTONOMIE_DES_PERSONNES_HANDICAPEES = "01"  # Travailleur reconnu handicapé par la commission des droits et de l'autonomie des personnes handicapées
    VICTIME_D_ACCIDENT_DU_TRAVAIL_OU_DE_MALADIE_PROFESSIONNELLE_AYANT_ENTRAINE_UNE_INCAPACITE_PERMANENTE_AU_MOINS_EGALE_A_10_ET_TITULAIRE_D_UNE_RENTE = "02"  # Victime d'accident du travail ou de maladie professionnelle ayant entraîné une incapacité permanente au moins égale à 10 % et titulaire d'une rente
    TITULAIRE_D_UNE_PENSION_D_INVALIDITE_A_CONDITION_QUE_L_INVALIDITE_REDUISE_AU_MOINS_DES_DEUX_TIERS_SA_CAPACITE_DE_TRAVAIL = "03"  # Titulaire d'une pension d'invalidité à condition que l'invalidité réduise au moins des deux tiers sa capacité de travail
    BENEFICIAIRE_MENTIONNE_A_L_ARTICLE_L_241_2_DU_CODE_DES_PENSIONS_MILITAIRES_D_INVALIDITE_ET_DES_VICTIMES_DE_LA_GUERRE = "04"  # Bénéficiaire mentionné à l'article L.241-2 du Code des pensions militaires d'invalidité et des victimes de la guerre
    BENEFICIAIRE_MENTIONNE_AUX_ARTICLES_L_241_3_ET_L_241_4_DU_CODE_DES_PENSIONS_MILITAIRES_D_INVALIDITE_ET_DES_VICTIMES_DE_LA_GUERRE = "05"  # Bénéficiaire mentionné aux articles L.241-3 et L.241-4 du Code des pensions militaires d'invalidité et des victimes de la guerre
    TITULAIRE_D_UNE_ALLOCATION_OU_D_UNE_RENTE_D_INVALIDITE_DANS_LES_CONDITIONS_DEFINIES_PAR_LA_LOI_N_91_1389_DU_31_DECEMBRE_1991 = "06"  # Titulaire d'une allocation ou d'une rente d'invalidité dans les conditions définies par la Loi n°91-1389 du 31 décembre 1991
    TITULAIRE_DE_LA_CARTE_MOBILITE_INCLUSION_PORTANT_LA_MENTION_INVALIDITE_L_241_3_DU_CODE_DE_L_ACTION_SOCIALE_ET_DES_FAMILLES = "07"  # Titulaire de la carte "mobilité inclusion" portant la mention "invalidité" (L. 241-3 du Code de l'action sociale et des familles)
    TITULAIRE_DE_L_ALLOCATION_AUX_ADULTES_HANDICAPES = (
        "08"  # Titulaire de l'allocation aux adultes handicapés
    )
    BENEFICIAIRE_MENTIONNE_AUX_ARTICLES_L_241_5_ET_L_241_6_DU_CODE_DES_PENSIONS_MILITAIRES_D_INVALIDITE_ET_DES_VICTIMES_DE_GUERRE = "09"  # Bénéficiaire mentionné aux articles L.241-5 et L.241-6 du Code des pensions militaires d'invalidité et des victimes de guerre
    AGENT_PUBLIC_RECLASSE_3EME_ALINEA_DE_L_ARTICLE_L_323_5_DU_CODE_DU_TRAVAIL = (
        "10"  # Agent public reclassé (3ème alinéa de l'article L.323-5 du Code du travail)
    )
    AGENT_PUBLIC_BENEFICIAIRE_D_UNE_ALLOCATION_TEMPORAIRE_D_INVALIDITE_4EME_ALINEA_DE_L_ARTICLE_L_323_5_DU_CODE_DU_TRAVAIL = "11"  # Agent public bénéficiaire d'une allocation temporaire d'invalidité (4ème alinéa de l'article L.323-5 du Code du travail)
    AYANT_DROIT_A_LA_PRESTATION_DE_COMPENSATION_DU_HANDICAP_A_L_ALLOCATION_COMPENSATRICE_POUR_TIERCE_PERSONNE_OU_A_L_ALLOCATION_D_EDUCATION_DE_L_ENFANT_HANDICAPE_BENEFICIANT_D_UN_STAGE_L_5212_7_DU_CODE_DU_TRAVAIL = "12"  # Ayant droit à la prestation de compensation du handicap, à l'allocation compensatrice pour tierce personne ou à l'allocation d'éducation de l'enfant handicapé bénéficiant d'un stage (L.5212-7 du Code du travail)

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Travailleur reconnu handicap\u00e9 par la commission des droits et de l\u0027autonomie des personnes handicap\u00e9es",
        "02": "Victime d\u0027accident du travail ou de maladie professionnelle ayant entra\u00een\u00e9 une incapacit\u00e9 permanente au moins \u00e9gale \u00e0 10 % et titulaire d\u0027une rente",
        "03": "Titulaire d\u0027une pension d\u0027invalidit\u00e9 \u00e0 condition que l\u0027invalidit\u00e9 r\u00e9duise au moins des deux tiers sa capacit\u00e9 de travail",
        "04": "B\u00e9n\u00e9ficiaire mentionn\u00e9 \u00e0 l\u0027article L.241-2 du Code des pensions militaires d\u0027invalidit\u00e9 et des victimes de la guerre",
        "05": "B\u00e9n\u00e9ficiaire mentionn\u00e9 aux articles L.241-3 et L.241-4 du Code des pensions militaires d\u0027invalidit\u00e9 et des victimes de la guerre",
        "06": "Titulaire d\u0027une allocation ou d\u0027une rente d\u0027invalidit\u00e9 dans les conditions d\u00e9finies par la Loi n\u00b091-1389 du 31 d\u00e9cembre 1991",
        "07": 'Titulaire de la carte "mobilit\u00e9 inclusion" portant la mention "invalidit\u00e9" (L. 241-3 du Code de l\u0027action sociale et des familles)',
        "08": "Titulaire de l\u0027allocation aux adultes handicap\u00e9s",
        "09": "B\u00e9n\u00e9ficiaire mentionn\u00e9 aux articles L.241-5 et L.241-6 du Code des pensions militaires d\u0027invalidit\u00e9 et des victimes de guerre",
        "10": "Agent public reclass\u00e9 (3\u00e8me alin\u00e9a de l\u0027article L.323-5 du Code du travail)",
        "11": "Agent public b\u00e9n\u00e9ficiaire d\u0027une allocation temporaire d\u0027invalidit\u00e9 (4\u00e8me alin\u00e9a de l\u0027article L.323-5 du Code du travail)",
        "12": "Ayant droit \u00e0 la prestation de compensation du handicap, \u00e0 l\u0027allocation compensatrice pour tierce personne ou \u00e0 l\u0027allocation d\u0027\u00e9ducation de l\u0027enfant handicap\u00e9 b\u00e9n\u00e9ficiant d\u0027un stage (L.5212-7 du Code du travail)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_CasMiseDispositionExterneIndividuEtablissement(str, Enum):
    INDIVIDU_EN_PORTAGE_SALARIAL = "01"  # Individu en portage salarial
    INDIVIDU_MIS_A_DISPOSITION_DANS_UN_ETABLISSEMENT_ADHERENT_DU_GROUPEMENT_D_EMPLOYEURS = (
        "02"  # Individu mis à disposition dans un établissement adhérent du groupement d'employeurs
    )
    INDIVIDU_D_UNE_ENTREPRISE_ADAPTEE_MIS_A_DISPOSITION = (
        "03"  # Individu d'une entreprise adaptée mis à disposition
    )
    INDIVIDU_D_UNE_AGENCE_DE_MANNEQUIN_MIS_A_DISPOSITION = (
        "04"  # Individu d’une agence de mannequin mis à disposition
    )
    INDIVIDU_D_UNE_ENTREPRISE_DE_TRAVAIL_A_TEMPS_PARTAGE_ETTP_OU_ETT_MIS_A_DISPOSITION_EN_CDI_EMPLOYABILITE = "05"  # Individu d’une entreprise de travail à temps partagé (ETTP ou ETT) mis à disposition en CDI employabilité
    INDIVIDU_D_UNE_ASSOCIATION_INTERMEDIAIRE_MIS_A_DISPOSITION = (
        "06"  # Individu d’une association intermédiaire mis à disposition
    )
    INDIVIDU_D_UNE_ENTREPRISE_DE_TRAVAIL_A_TEMPS_PARTAGE_ETTP_MIS_A_DISPOSITION_HORS_CDI_EMPLOYABILITE = "07"  # Individu d'une entreprise de travail à temps partagé (ETTP) mis à disposition hors CDI employabilité

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Individu en portage salarial",
        "02": "Individu mis \u00e0 disposition dans un \u00e9tablissement adh\u00e9rent du groupement d\u0027employeurs",
        "03": "Individu d\u0027une entreprise adapt\u00e9e mis \u00e0 disposition",
        "04": "Individu d\u2019une agence de mannequin mis \u00e0 disposition",
        "05": "Individu d\u2019une entreprise de travail \u00e0 temps partag\u00e9 (ETTP ou ETT) mis \u00e0 disposition en CDI employabilit\u00e9",
        "06": "Individu d\u2019une association interm\u00e9diaire mis \u00e0 disposition",
        "07": "Individu d\u0027une entreprise de travail \u00e0 temps partag\u00e9 (ETTP) mis \u00e0 disposition hors CDI employabilit\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Envoi_Type(str, Enum):
    ENVOI_NORMAL = "01"  # envoi normal
    ENVOI_NEANT = "02"  # envoi néant

    __DESCRIPTIONS: dict[str, str] = {
        "01": "envoi normal",
        "02": "envoi n\u00e9ant",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Travail_Modalite(str, Enum):
    TEMPS_PLEIN = "10"  # Temps plein
    TEMPS_PARTIEL = "20"  # Temps partiel
    TEMPS_ALTERNE_PERSONNEL_NAVIGANT_DE_L_AERONAUTIQUE_CIVILE = (
        "30"  # Temps alterné - personnel navigant de l'aéronautique civile
    )
    CPA_2004 = "40"  # CPA 2004
    TEMPS_PARTIEL_DE_DROIT = "41"  # Temps partiel de droit
    TEMPS_PARTIEL_DE_DROIT_POUR_ENFANT = "42"  # Temps partiel de droit pour enfant
    SALARIE_NON_CONCERNE = "99"  # Salarié non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "10": "Temps plein",
        "20": "Temps partiel",
        "30": "Temps altern\u00e9 - personnel navigant de l\u0027a\u00e9ronautique civile",
        "40": "CPA 2004",
        "41": "Temps partiel de droit",
        "42": "Temps partiel de droit pour enfant",
        "99": "Salari\u00e9 non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Sexe(str, Enum):
    MASCULIN = "01"  # masculin
    FEMININ = "02"  # féminin

    __DESCRIPTIONS: dict[str, str] = {
        "01": "masculin",
        "02": "f\u00e9minin",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Version(str, Enum):
    ANNEE_2026_VERSION_1 = "P26V01"  # Année 2026 Version 1

    __DESCRIPTIONS: dict[str, str] = {
        "P26V01": "Ann\u00e9e 2026 Version 1",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Point_Depot(str, Enum):
    NET_ENTREPRISES = "01"  # Net-entreprises
    MSA = "02"  # MSA

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Net-entreprises",
        "02": "MSA",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Declaration_Nature(str, Enum):
    DSN_MENSUELLE = "01"  # DSN Mensuelle
    SIGNALEMENT_ARRET_DE_TRAVAIL = "04"  # Signalement Arrêt de travail
    SIGNALEMENT_REPRISE_SUITE_A_ARRET_DE_TRAVAIL = (
        "05"  # Signalement Reprise suite à arrêt de travail
    )
    SIGNALEMENT_FIN_DU_CONTRAT_DE_TRAVAIL_UNIQUE = (
        "07"  # Signalement Fin du contrat de travail Unique
    )
    SIGNALEMENT_AMORCAGE_DES_DONNEES_VARIABLES = "08"  # Signalement Amorçage des données variables
    DSN_DE_SUBSTITUTION = "09"  # DSN de substitution
    SIGNALEMENT_DECLARATION_PREALABLE_A_L_EMBAUCHE = (
        "10"  # Signalement Déclaration préalable à l'embauche
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "DSN Mensuelle",
        "04": "Signalement Arr\u00eat de travail",
        "05": "Signalement Reprise suite \u00e0 arr\u00eat de travail",
        "07": "Signalement Fin du contrat de travail Unique",
        "08": "Signalement Amor\u00e7age des donn\u00e9es variables",
        "09": "DSN de substitution",
        "10": "Signalement D\u00e9claration pr\u00e9alable \u00e0 l\u0027embauche",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Reg_Retraite_Comp(str, Enum):
    RETRAITE_COMPLEMENTAIRE_ARRCO = "RETA"  # Retraite complémentaire ARRCO
    RETRAITE_COMPLEMENTAIRE_ARRCO_ET_AGIRC = "RETC"  # Retraite complémentaire ARRCO et AGIRC
    REGIME_UNIFIE_AGIRC_ARRCO = "RUAA"  # Régime unifié AGIRC-ARRCO
    CAISSE_D_ASSURANCE_VIEILLESSE_DES_EXPERTS_COMPTABLES_ET_DES_COMMISSAIRES_AUX_COMPTES = "CAVEC"  # Caisse d'assurance vieillesse des experts-comptables et des commissaires aux comptes
    CAISSE_NATIONALE_DES_BARREAUX_FRANCAIS = "CNBF"  # Caisse nationale des Barreaux Français
    CLERCS_ET_EMPLOYES_DE_NOTAIRE = "CRPCEN"  # Clercs et employés de notaire
    CAISSE_DE_RETRAITE_DU_PERSONNEL_NAVIGANT_PROFESSIONNEL_DE_L_AERONAUTIQUE_CIVILE = (
        "CRPNPAC"  # Caisse de Retraite du Personnel Navigant Professionnel de l'Aéronautique Civile
    )
    INSTITUTION_DE_RETRAITE_COMPLEMENTAIRE_DES_AGENTS_NON_TITULAIRES_DE_L_ETAT_ET_DES_COLLECTIVITES_PUBLIQUES = "IRCANTEC"  # Institution de retraite complémentaire des agents non titulaires de l’État et des collectivités publiques
    PAS_DE_REGIME_COMPLEMENTAIRE = "90000"  # pas de régime complémentaire

    __DESCRIPTIONS: dict[str, str] = {
        "RETA": "Retraite compl\u00e9mentaire ARRCO",
        "RETC": "Retraite compl\u00e9mentaire ARRCO et AGIRC",
        "RUAA": "R\u00e9gime unifi\u00e9 AGIRC-ARRCO",
        "CAVEC": "Caisse d\u0027assurance vieillesse des experts-comptables et des commissaires aux comptes",
        "CNBF": "Caisse nationale des Barreaux Fran\u00e7ais",
        "CRPCEN": "Clercs et employ\u00e9s de notaire",
        "CRPNPAC": "Caisse de Retraite du Personnel Navigant Professionnel de l\u0027A\u00e9ronautique Civile",
        "IRCANTEC": "Institution de retraite compl\u00e9mentaire des agents non titulaires de l\u2019\u00c9tat et des collectivit\u00e9s publiques",
        "90000": "pas de r\u00e9gime compl\u00e9mentaire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Declaration_Type(str, Enum):
    DECLARATION_NORMALE = "01"  # déclaration normale
    DECLARATION_NORMALE_SANS_INDIVIDU = "02"  # déclaration normale sans individu
    DECLARATION_ANNULE_ET_REMPLACE_INTEGRAL = "03"  # déclaration annule et remplace intégral
    DECLARATION_ANNULE = "04"  # déclaration annule
    ANNULE_ET_REMPLACE_SANS_INDIVIDU = "05"  # annule et remplace sans individu

    __DESCRIPTIONS: dict[str, str] = {
        "01": "d\u00e9claration normale",
        "02": "d\u00e9claration normale sans individu",
        "03": "d\u00e9claration annule et remplace int\u00e9gral",
        "04": "d\u00e9claration annule",
        "05": "annule et remplace sans individu",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Base_Assujettie(str, Enum):
    ASSIETTE_BRUTE_PLAFONNEE = "02"  # Assiette  brute plafonnée
    ASSIETTE_BRUTE_DEPLAFONNEE = "03"  # Assiette brute déplafonnée
    ASSIETTE_DE_LA_CONTRIBUTION_SOCIALE_GENERALISEE = (
        "04"  # Assiette de la contribution sociale généralisée
    )
    ASSIETTE_DU_FORFAIT_SOCIAL = "05"  # Assiette du forfait social
    ASSIETTE_DES_CONTRIBUTIONS_D_ASSURANCE_CHOMAGE = (
        "07"  # Assiette des contributions d'Assurance Chômage
    )
    ASSIETTE_RETRAITE_CPRPF = "08"  # Assiette retraite CPRPF
    ASSIETTE_DE_COMPENSATION_BILATERALE_MALADIE_CPRPF = (
        "09"  # Assiette de compensation bilatérale maladie CPRPF
    )
    BASE_BRUTE_FISCALE = "10"  # Base brute fiscale
    BASE_FORFAITAIRE_SOUMISE_AUX_COTISATIONS_DE_SECURITE_SOCIALE = (
        "11"  # Base forfaitaire soumise aux cotisations de Sécurité Sociale
    )
    ASSIETTE_DU_CREDIT_D_IMPOT_COMPETITIVITE_EMPLOI = (
        "12"  # Assiette du crédit d'impôt compétitivité-emploi
    )
    ASSIETTE_DU_FORFAIT_SOCIAL_A_8 = "13"  # Assiette du forfait social à 8%
    ASSIETTE_DU_FORFAIT_SOCIAL_A_20 = "14"  # Assiette du forfait social à 20%
    ASSIETTE_BRUTE_DU_REGIME_SPECIAL_IEG = "15"  # Assiette brute du régime spécial IEG
    ASSIETTE_BRUTE_DU_COMPLEMENT_INVALIDITE_IEG = (
        "16"  # Assiette brute du complément invalidité IEG
    )
    ASSIETTE_BRUTE_DU_PETIT_POOL_IEG = "17"  # Assiette brute du petit pool IEG
    ASSIETTE_BRUTE_PLAFONNEE_REGIME_MALADIE_IEG = (
        "18"  # Assiette brute plafonnée régime maladie IEG
    )
    ASSIETTE_CRPCEN = "19"  # Assiette CRPCEN
    CAISSES_DE_CONGES_PAYES_CIBTP_TRANSPORT_MANUTENTION_PORTUAIRE_BASE_BRUTE_DE_COTISATIONS_CONGES_PAYES = "20"  # Caisses de congés payés (CIBTP, Transport, Manutention portuaire) - Base brute de cotisations congés payés
    CIBTP_BASE_BRUTE_DE_COTISATIONS_OPPBTP_PERMANENTS = (
        "21"  # CIBTP - Base brute de cotisations OPPBTP permanents
    )
    BASE_BRUTE_SPECIFIQUE = "22"  # Base brute spécifique
    BASE_EXCEPTIONNELLE_AGIRC_ARRCO = "23"  # Base exceptionnelle (Agirc Arrco)
    BASE_PLAFONNEE_SPECIFIQUE = "24"  # Base plafonnée spécifique
    ASSIETTE_DE_CONTRIBUTION_LIBERATOIRE = "25"  # Assiette de contribution libératoire
    ASSIETTE_CAISSE_DE_CONGES_SPECTACLES = "27"  # Assiette Caisse de congés spectacles
    BASE_IRCANTEC_COTISEE = "28"  # Base IRCANTEC cotisée
    ELEMENTS_DE_COTISATION_PREVOYANCE_SANTE_RETRAITE_SUPPLEMENTAIRE = (
        "31"  # Eléments de cotisation Prévoyance, Santé, retraite supplémentaire
    )
    ASSIETTE_CONTRIBUTION_SUR_LES_AVANTAGES_DE_PRERETRAITE_ENTREPRISE = (
        "33"  # Assiette Contribution sur les avantages de préretraite entreprise
    )
    CIBTP_BASE_PLAFONNEE_DE_COTISATIONS_INTEMPERIES_GROS_OEUVRE_TRAVAUX_PUBLICS = (
        "34"  # CIBTP - Base plafonnée de cotisations intempéries gros oeuvre travaux publics
    )
    CIBTP_BASE_PLAFONNEE_DE_COTISATIONS_INTEMPERIES_SECOND_OEUVRE = (
        "35"  # CIBTP - Base plafonnée de cotisations intempéries second oeuvre
    )
    CIBTP_BASE_DE_COTISATIONS_DEROGATOIRE_BATIMENT = (
        "36"  # CIBTP - Base de cotisations dérogatoire Bâtiment
    )
    REMUNERATION_POUR_LE_CALCUL_DE_LA_REDUCTION_TRAVAILLEUR_OCCASIONNEL = (
        "38"  # Rémunération pour le calcul de la réduction Travailleur Occasionnel
    )
    CIBTP_BASE_DE_COTISATIONS_DEROGATOIRE_TRAVAUX_PUBLICS = (
        "39"  # CIBTP - Base de cotisations dérogatoire Travaux Publics
    )
    CIBTP_BASE_DE_COTISATIONS_DEROGATOIRE_PARTENAIRES_BATIMENT = (
        "40"  # CIBTP - Base de cotisations dérogatoire Partenaires Bâtiment
    )
    CRPNPAC_ASSIETTE_SOUMISE_AU_TAUX_NORMAL_NON_PLAFONNEE = (
        "41"  # CRPNPAC-Assiette soumise au taux normal (non-plafonnée)
    )
    CRPNPAC_ASSIETTE_SOUMISE_AU_TAUX_MAJORE_NON_PLAFONNEE = (
        "42"  # CRPNPAC-Assiette soumise au taux majoré (non-plafonnée)
    )
    BASE_PLAFONNEE_EXCEPTIONNELLE_AGIRC_ARRCO = "43"  # Base plafonnée exceptionnelle Agirc Arrco
    ASSIETTE_DU_FORFAIT_SOCIAL_A_16 = "44"  # Assiette du forfait social à 16%
    BASE_PLAFONNEE_ICP_AGIRC_ARRCO = "45"  # Base plafonnée ICP Agirc-Arrco
    FP_SRE_BASE_BRUTE_PENSION_CIVILE_ET_MILITAIRE = (
        "46"  # [FP] SRE – Base brute pension civile et militaire
    )
    FP_SRE_BASE_BRUTE_ACCESSOIRES_PENSION_CIVILE_ET_MILITAIRE = (
        "47"  # [FP] SRE – Base brute accessoires pension civile et militaire
    )
    FP_CNRACL_BASE_BRUTE_AVANT_ABATTEMENT = "48"  # [FP] CNRACL – Base brute avant abattement
    FP_RAFP_BASE_BRUTE_AVANT_ABATTEMENT = "49"  # [FP] RAFP – Base brute avant abattement
    FP_FSPOEIE_BASE_BRUTE_AVANT_ABATTEMENT = "50"  # [FP] FSPOEIE - Base brute avant abattement
    ASSIETTE_SPECIFIQUE_TRANCHE_2_REGIME_SPECIAL_RATP = (
        "52"  # Assiette spécifique Tranche 2 régime spécial RATP
    )
    ASSIETTE_SPECIFIQUE_REGIME_SPECIAL_RATP = "53"  # Assiette spécifique régime spécial RATP
    ASSIETTE_DU_FORFAIT_SOCIAL_A_10 = "54"  # Assiette du forfait social à 10%
    ASSIETTE_DE_PENIBILITE_CONVENTIONNELLE_DE_LA_MANUTENTION_PORTUAIRE = (
        "55"  # Assiette de pénibilité conventionnelle de la Manutention portuaire
    )
    POTENTIELLE_NOUVELLE_BASE_ASSUJETTIE_A = "56"  # Potentielle nouvelle base assujettie A
    ASSIETTE_DU_VERSEMENT_MOBILITE = "57"  # Assiette du versement mobilité
    BASE_CONTRAT_D_EMPLOI_PENITENTIAIRE_1 = "59"  # Base contrat d’emploi pénitentiaire 1
    BASE_CONTRAT_D_EMPLOI_PENITENTIAIRE_2 = "60"  # Base contrat d’emploi pénitentiaire 2
    POTENTIELLE_NOUVELLE_BASE_ASSUJETTIE_D = "61"  # Potentielle nouvelle base assujettie D
    POTENTIELLE_NOUVELLE_BASE_ASSUJETTIE_E = "62"  # Potentielle nouvelle base assujettie E

    __DESCRIPTIONS: dict[str, str] = {
        "02": "Assiette  brute plafonn\u00e9e",
        "03": "Assiette brute d\u00e9plafonn\u00e9e",
        "04": "Assiette de la contribution sociale g\u00e9n\u00e9ralis\u00e9e",
        "05": "Assiette du forfait social",
        "07": "Assiette des contributions d\u0027Assurance Ch\u00f4mage",
        "08": "Assiette retraite CPRPF",
        "09": "Assiette de compensation bilat\u00e9rale maladie CPRPF",
        "10": "Base brute fiscale",
        "11": "Base forfaitaire soumise aux cotisations de S\u00e9curit\u00e9 Sociale",
        "12": "Assiette du cr\u00e9dit d\u0027imp\u00f4t comp\u00e9titivit\u00e9-emploi",
        "13": "Assiette du forfait social \u00e0 8%",
        "14": "Assiette du forfait social \u00e0 20%",
        "15": "Assiette brute du r\u00e9gime sp\u00e9cial IEG",
        "16": "Assiette brute du compl\u00e9ment invalidit\u00e9 IEG",
        "17": "Assiette brute du petit pool IEG",
        "18": "Assiette brute plafonn\u00e9e r\u00e9gime maladie IEG",
        "19": "Assiette CRPCEN",
        "20": "Caisses de cong\u00e9s pay\u00e9s (CIBTP, Transport, Manutention portuaire) - Base brute de cotisations cong\u00e9s pay\u00e9s",
        "21": "CIBTP - Base brute de cotisations OPPBTP permanents",
        "22": "Base brute sp\u00e9cifique",
        "23": "Base exceptionnelle (Agirc Arrco)",
        "24": "Base plafonn\u00e9e sp\u00e9cifique",
        "25": "Assiette de contribution lib\u00e9ratoire",
        "27": "Assiette Caisse de cong\u00e9s spectacles",
        "28": "Base IRCANTEC cotis\u00e9e",
        "31": "El\u00e9ments de cotisation Pr\u00e9voyance, Sant\u00e9, retraite suppl\u00e9mentaire",
        "33": "Assiette Contribution sur les avantages de pr\u00e9retraite entreprise",
        "34": "CIBTP - Base plafonn\u00e9e de cotisations intemp\u00e9ries gros oeuvre travaux publics",
        "35": "CIBTP - Base plafonn\u00e9e de cotisations intemp\u00e9ries second oeuvre",
        "36": "CIBTP - Base de cotisations d\u00e9rogatoire B\u00e2timent",
        "38": "R\u00e9mun\u00e9ration pour le calcul de la r\u00e9duction Travailleur Occasionnel",
        "39": "CIBTP - Base de cotisations d\u00e9rogatoire Travaux Publics",
        "40": "CIBTP - Base de cotisations d\u00e9rogatoire Partenaires B\u00e2timent",
        "41": "CRPNPAC-Assiette soumise au taux normal (non-plafonn\u00e9e)",
        "42": "CRPNPAC-Assiette soumise au taux major\u00e9 (non-plafonn\u00e9e)",
        "43": "Base plafonn\u00e9e exceptionnelle Agirc Arrco",
        "44": "Assiette du forfait social \u00e0 16%",
        "45": "Base plafonn\u00e9e ICP Agirc-Arrco",
        "46": "[FP] SRE \u2013 Base brute pension civile et militaire",
        "47": "[FP] SRE \u2013 Base brute accessoires pension civile et militaire",
        "48": "[FP] CNRACL \u2013 Base brute avant abattement",
        "49": "[FP] RAFP \u2013 Base brute avant abattement",
        "50": "[FP] FSPOEIE - Base brute avant abattement",
        "52": "Assiette sp\u00e9cifique Tranche 2 r\u00e9gime sp\u00e9cial RATP",
        "53": "Assiette sp\u00e9cifique r\u00e9gime sp\u00e9cial RATP",
        "54": "Assiette du forfait social \u00e0 10%",
        "55": "Assiette de p\u00e9nibilit\u00e9 conventionnelle de la Manutention portuaire",
        "56": "Potentielle nouvelle base assujettie A",
        "57": "Assiette du versement mobilit\u00e9",
        "59": "Base contrat d\u2019emploi p\u00e9nitentiaire 1",
        "60": "Base contrat d\u2019emploi p\u00e9nitentiaire 2",
        "61": "Potentielle nouvelle base assujettie D",
        "62": "Potentielle nouvelle base assujettie E",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Base_Assujettie_Declare_Tort_1(str, Enum):
    ASSIETTE_BRUTE_PLAFONNEE = "02"  # Assiette brute plafonnée
    ASSIETTE_BRUTE_DEPLAFONNEE = "03"  # Assiette brute déplafonnée
    BASE_FORFAITAIRE_SOUMISE_AUX_COTISATIONS_DE_SECURITE_SOCIALE = (
        "11"  # Base forfaitaire soumise aux cotisations de Sécurité Sociale
    )

    __DESCRIPTIONS: dict[str, str] = {
        "02": "Assiette brute plafonn\u00e9e",
        "03": "Assiette brute d\u00e9plafonn\u00e9e",
        "11": "Base forfaitaire soumise aux cotisations de S\u00e9curit\u00e9 Sociale",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class RAC_Preavis(str, Enum):
    PREAVIS_EFFECTUE_ET_PAYE = "01"  # préavis effectué et payé
    PREAVIS_NON_EFFECTUE_ET_PAYE = "02"  # préavis non effectué et payé
    PREAVIS_NON_EFFECTUE_ET_NON_PAYE = "03"  # préavis non effectué et non payé
    PREAVIS_NON_EFFECTUE_NON_PAYE_DANS_LE_CADRE_D_UN_CONTRAT_DE_SECURISATION_PROFESSIONNELLE_CSP = "10"  # préavis non effectué non payé dans le cadre d’un contrat de sécurisation professionnelle (CSP)
    PREAVIS_NON_EFFECTUE_ET_PAYE_DANS_LE_CADRE_D_UN_CONGE_DE_RECLASSEMENT = (
        "50"  # préavis non effectué et payé dans le cadre d’un congé de reclassement
    )
    PREAVIS_NON_EFFECTUE_ET_PAYE_DANS_LE_CADRE_D_UN_CONGE_DE_MOBILITE = (
        "51"  # préavis non effectué et payé dans le cadre d’un congé de mobilité
    )
    DELAI_DE_PREVENANCE = "60"  # Délai de prévenance
    PREAVIS_NON_EFFECTUE_ET_NON_PAYE_DANS_LE_CADRE_DU_PARCOURS_D_ACCOMPAGNEMENT_PERSONNALISE_PAP = "61"  # préavis non effectué et non payé dans le cadre du parcours d’accompagnement personnalisé (PAP)
    PAS_DE_CLAUSE_DE_PREAVIS_APPLICABLE = "90"  # pas de clause de préavis applicable

    __DESCRIPTIONS: dict[str, str] = {
        "01": "pr\u00e9avis effectu\u00e9 et pay\u00e9",
        "02": "pr\u00e9avis non effectu\u00e9 et pay\u00e9",
        "03": "pr\u00e9avis non effectu\u00e9 et non pay\u00e9",
        "10": "pr\u00e9avis non effectu\u00e9 non pay\u00e9 dans le cadre d\u2019un contrat de s\u00e9curisation professionnelle (CSP)",
        "50": "pr\u00e9avis non effectu\u00e9 et pay\u00e9 dans le cadre d\u2019un cong\u00e9 de reclassement",
        "51": "pr\u00e9avis non effectu\u00e9 et pay\u00e9 dans le cadre d\u2019un cong\u00e9 de mobilit\u00e9",
        "60": "D\u00e9lai de pr\u00e9venance",
        "61": "pr\u00e9avis non effectu\u00e9 et non pay\u00e9 dans le cadre du parcours d\u2019accompagnement personnalis\u00e9 (PAP)",
        "90": "pas de clause de pr\u00e9avis applicable",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class N4DS_O_N(str, Enum):
    OUI = "01"  # oui
    NON = "02"  # non

    __DESCRIPTIONS: dict[str, str] = {
        "01": "oui",
        "02": "non",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class RAC_Rupture_Motif_DSN_phase_1(str, Enum):
    LICENCIEMENT_SUITE_A_LIQUIDATION_JUDICIAIRE_OU_A_REDRESSEMENT_JUDICIAIRE = (
        "011"  # licenciement suite à liquidation judiciaire ou à redressement judiciaire
    )
    LICENCIEMENT_SUITE_A_FERMETURE_DEFINITIVE_DE_L_ETABLISSEMENT = (
        "012"  # licenciement suite à fermeture définitive de l'établissement
    )
    LICENCIEMENT_POUR_MOTIF_ECONOMIQUE = "014"  # licenciement pour motif économique
    LICENCIEMENT_POUR_FIN_DE_CHANTIER_OU_D_OPERATION = (
        "015"  # licenciement pour fin de chantier ou d'opération
    )
    LICENCIEMENT_POUR_AUTRE_MOTIF = "020"  # licenciement pour autre motif
    AUTRE_FIN_DE_CONTRAT_POUR_MOTIF_ECONOMIQUE = "025"  # autre fin de contrat pour motif économique
    RUPTURE_POUR_MOTIF_ECONOMIQUE_SUITE_A_L_ACCEPTATION_D_UN_CONTRAT_DE_SECURISATION_PROFESSIONNELLE = "026"  # rupture pour motif économique suite à l'acceptation d’un contrat de sécurisation professionnelle
    FIN_DE_CONTRAT_A_DUREE_DETERMINEE_OU_FIN_D_ACCUEIL_OCCASIONNEL = (
        "031"  # fin de contrat à durée déterminée ou fin d'accueil occasionnel
    )
    FIN_DE_MISSION_D_INTERIM = "032"  # fin de mission d'intérim
    RUPTURE_ANTICIPEE_D_UN_CDD_OU_D_UN_CONTRAT_DE_MISSION_EN_CAS_D_INAPTITUDE_PHYSIQUE_CONSTATEE_PAR_LE_MEDECIN_DU_TRAVAIL = "033"  # rupture anticipée d’un CDD ou d’un contrat de mission en cas d’inaptitude physique constatée par le médecin du travail
    FIN_DE_PERIODE_D_ESSAI_A_L_INITIATIVE_DE_L_EMPLOYEUR = (
        "034"  # fin de période d'essai à l'initiative de l'employeur
    )
    FIN_DE_PERIODE_D_ESSAI_A_L_INITIATIVE_DU_SALARIE = (
        "035"  # fin de période d'essai à l'initiative du salarié
    )
    RUPTURE_ANTICIPEE_D_UN_CDD_D_UN_CONTRAT_DE_PROFESSIONNALISATION_D_UN_CONTRAT_D_APPRENTISSAGE_OU_D_UN_CONTRAT_DE_MISSION_A_L_INITIATIVE_DE_L_EMPLOYEUR = "036"  # rupture anticipée d'un CDD, d’un contrat de professionnalisation, d'un contrat d'apprentissage ou d’un contrat de mission à l'initiative de l'employeur
    RUPTURE_ANTICIPEE_D_UN_CDD_D_UN_CONTRAT_DE_PROFESSIONNALISATION_D_UN_CONTRAT_D_APPRENTISSAGE_OU_D_UN_CONTRAT_DE_MISSION_A_L_INITIATIVE_DU_SALARIE = "037"  # rupture anticipée d'un CDD, d’un contrat de professionnalisation, d'un contrat d'apprentissage ou d’un contrat de mission à l'initiative du salarié
    MISE_A_LA_RETRAITE_PAR_L_EMPLOYEUR = "038"  # mise à la retraite par l'employeur
    DEPART_A_LA_RETRAITE_A_L_INITIATIVE_DU_SALARIE = (
        "039"  # départ à la retraite à l'initiative du salarié
    )
    RUPTURE_CONVENTIONNELLE = "043"  # rupture conventionnelle
    PRISE_D_ACTE_DE_LA_RUPTURE_DE_CONTRAT_DE_TRAVAIL = (
        "058"  # prise d'acte de la rupture de contrat de travail
    )
    DEMISSION = "059"  # démission
    DECES_DE_L_EMPLOYEUR_OU_INTERNEMENT_CONDUIT_A_UN_LICENCIEMENT_AUTRE_MOTIF = (
        "065"  # décès de l'employeur ou internement / conduit à un licenciement autre motif
    )
    DECES_DE_L_INDIVIDU = "066"  # décès de l’individu
    FP_REVOCATION_SUITE_A_ABANDON_DE_POSTE = "070"  # [FP] Révocation suite à abandon de poste
    FP_REVOCATION_SUITE_A_SANCTION_PENALE = "071"  # [FP] Révocation suite à sanction pénale
    FIN_DE_CONTRAT_D_APPRENTISSAGE = "081"  # fin de contrat d'apprentissage
    RESILIATION_JUDICIAIRE_DU_CONTRAT_DE_TRAVAIL = (
        "082"  # résiliation judiciaire du contrat de travail
    )
    RUPTURE_DE_CONTRAT_DE_TRAVAIL_OU_D_UN_CONTRAT_DE_MISSION_POUR_FORCE_MAJEURE_OU_FAIT_DU_PRINCE = "083"  # rupture de contrat de travail ou d’un contrat de mission pour force majeure ou fait du prince
    RUPTURE_D_UN_COMMUN_ACCORD_DU_CDD_D_UN_CONTRAT_DE_PROFESSIONNALISATION_DU_CONTRAT_D_APPRENTISSAGE_OU_D_UN_CONTRAT_DE_MISSION = "084"  # rupture d'un commun accord du CDD, d’un contrat de professionnalisation, du contrat d'apprentissage ou d’un contrat de mission
    FIN_DE_MANDAT = "085"  # fin de mandat
    LICENCIEMENT_CONVENTION_CATS = "086"  # licenciement convention CATS
    LICENCIEMENT_POUR_FAUTE_GRAVE = "087"  # licenciement pour faute grave
    LICENCIEMENT_POUR_FAUTE_LOURDE = "088"  # licenciement pour faute lourde
    LICENCIEMENT_POUR_FORCE_MAJEURE = "089"  # licenciement pour force majeure
    LICENCIEMENT_POUR_INAPTITUDE_PHYSIQUE_D_ORIGINE_NON_PROFESSIONNELLE = (
        "091"  # licenciement pour inaptitude physique d'origine non professionnelle
    )
    LICENCIEMENT_POUR_INAPTITUDE_PHYSIQUE_D_ORIGINE_PROFESSIONNELLE = (
        "092"  # licenciement pour inaptitude physique d'origine  professionnelle
    )
    LICENCIEMENT_SUITE_A_DECISION_D_UNE_AUTORITE_ADMINISTRATIVE = (
        "093"  # licenciement suite à décision d'une autorité administrative
    )
    RUPTURE_ANTICIPEE_DU_CONTRAT_DE_TRAVAIL_POUR_ARRET_DE_TOURNAGE = (
        "094"  # rupture anticipée du contrat de travail pour arrêt de tournage
    )
    RUPTURE_ANTICIPEE_DU_CONTRAT_DE_TRAVAIL_OU_D_UN_CONTRAT_DE_MISSION_POUR_FAUTE_GRAVE = (
        "095"  # rupture anticipée du contrat de travail ou d’un contrat de mission pour faute grave
    )
    RUPTURE_ANTICIPEE_DU_CONTRAT_DE_TRAVAIL_OU_D_UN_CONTRAT_DE_MISSION_POUR_FAUTE_LOURDE = "096"  # rupture anticipée du contrat de travail ou d’un contrat de mission pour faute lourde
    RUPTURE_ANTICIPEE_D_UN_CONTRAT_DE_TRAVAIL_OU_D_UN_CONTRAT_DE_MISSION_SUITE_A_FERMETURE_DE_L_ETABLISSEMENT = "097"  # rupture anticipée d’un contrat de travail ou d’un contrat de mission suite à fermeture de l'établissement
    RETRAIT_D_ENFANT = "098"  # retrait d'enfant
    ANNULATION = "099"  # Annulation
    MUTATION_AU_SEIN_DU_MEME_GROUPE_OU_EXTERIEURE_AU_GROUPE_POUR_LES_SECTEURS_D_ACTIVITE_AUTORISES_GARDIENNAGE_MENAGE_RESTAURATION_ETC_SANS_RUPTURE_DU_CONTRAT = "100"  # Mutation au sein du même groupe ou extérieure au groupe pour les secteurs d’activité autorisés (gardiennage, ménage, restauration, etc.) sans rupture du contrat
    RUPTURE_CONVENTIONNELLE_COLLECTIVE = "110"  # Rupture conventionnelle collective
    RUPTURE_AMIABLE_DANS_LE_CADRE_D_UN_CONGE_DE_MOBILITE = (
        "111"  # Rupture amiable dans le cadre d’un congé de mobilité
    )
    RUPTURE_DANS_LE_CADRE_D_UN_ACCORD_DE_PERFORMANCE_COLLECTIVE = (
        "112"  # Rupture dans le cadre d'un accord de performance collective
    )
    LICENCIEMENT_POUR_MOTIF_SPECIFIQUE_ARTICLE_L_2254_2_DU_CODE_DU_TRAVAIL = (
        "113"  # Licenciement pour motif spécifique (Article L. 2254-2 du Code du Travail)
    )
    RUPTURE_D_UN_COMMUN_ACCORD_POUR_ENTREE_EN_PAP = (
        "114"  # Rupture d’un commun accord pour entrée en PAP
    )
    LICENCIEMENT_AU_TITRE_DES_ARTICLES_18_ET_19_DE_LA_LOI_N_2017_1339_DU_15_SEPTEMBRE_2017 = "115"  # Licenciement au titre des articles 18 et 19 de la loi n° 2017-1339 du 15 septembre 2017
    FIN_DE_LIGNE_DE_SERVICE = "116"  # Fin de ligne de service
    LICENCIEMENT_POUR_MOTIF_ECONOMIQUE_SUITE_AU_REFUS_D_UN_CONTRAT_DE_SECURISATION_PROFESSIONNELLE = "117"  # licenciement pour motif économique suite au refus d’un contrat de sécurisation professionnelle
    FIN_DE_CONTRAT_D_APPUI_AU_PROJET_D_ENTREPRISE = (
        "118"  # Fin de contrat d’appui au projet d’entreprise
    )
    FIN_D_AFFECTATION = "119"  # Fin d'affectation
    TRANSFERT_DU_CONTRAT_DE_TRAVAIL_SANS_RUPTURE_DU_CONTRAT_VERS_UN_AUTRE_ETABLISSEMENT_PAS_RENTRE_DANS_LA_DSN = "998"  # transfert du contrat de travail sans rupture du contrat vers un autre établissement pas rentré dans la DSN
    FIN_DE_RELATION_AVEC_L_EMPLOYEUR_AUTRES_QUE_CONTRAT_DE_TRAVAIL_CONVENTION_OU_MANDAT = "999"  # fin de relation avec l’employeur (autres que contrat de travail, convention ou mandat)

    __DESCRIPTIONS: dict[str, str] = {
        "011": "licenciement suite \u00e0 liquidation judiciaire ou \u00e0 redressement judiciaire",
        "012": "licenciement suite \u00e0 fermeture d\u00e9finitive de l\u0027\u00e9tablissement",
        "014": "licenciement pour motif \u00e9conomique",
        "015": "licenciement pour fin de chantier ou d\u0027op\u00e9ration",
        "020": "licenciement pour autre motif",
        "025": "autre fin de contrat pour motif \u00e9conomique",
        "026": "rupture pour motif \u00e9conomique suite \u00e0 l\u0027acceptation d\u2019un contrat de s\u00e9curisation professionnelle",
        "031": "fin de contrat \u00e0 dur\u00e9e d\u00e9termin\u00e9e ou fin d\u0027accueil occasionnel",
        "032": "fin de mission d\u0027int\u00e9rim",
        "033": "rupture anticip\u00e9e d\u2019un CDD ou d\u2019un contrat de mission en cas d\u2019inaptitude physique constat\u00e9e par le m\u00e9decin du travail",
        "034": "fin de p\u00e9riode d\u0027essai \u00e0 l\u0027initiative de l\u0027employeur",
        "035": "fin de p\u00e9riode d\u0027essai \u00e0 l\u0027initiative du salari\u00e9",
        "036": "rupture anticip\u00e9e d\u0027un CDD, d\u2019un contrat de professionnalisation, d\u0027un contrat d\u0027apprentissage ou d\u2019un contrat de mission \u00e0 l\u0027initiative de l\u0027employeur",
        "037": "rupture anticip\u00e9e d\u0027un CDD, d\u2019un contrat de professionnalisation, d\u0027un contrat d\u0027apprentissage ou d\u2019un contrat de mission \u00e0 l\u0027initiative du salari\u00e9",
        "038": "mise \u00e0 la retraite par l\u0027employeur",
        "039": "d\u00e9part \u00e0 la retraite \u00e0 l\u0027initiative du salari\u00e9",
        "043": "rupture conventionnelle",
        "058": "prise d\u0027acte de la rupture de contrat de travail",
        "059": "d\u00e9mission",
        "065": "d\u00e9c\u00e8s de l\u0027employeur ou internement / conduit \u00e0 un licenciement autre motif",
        "066": "d\u00e9c\u00e8s de l\u2019individu",
        "070": "[FP] R\u00e9vocation suite \u00e0 abandon de poste",
        "071": "[FP] R\u00e9vocation suite \u00e0 sanction p\u00e9nale",
        "081": "fin de contrat d\u0027apprentissage",
        "082": "r\u00e9siliation judiciaire du contrat de travail",
        "083": "rupture de contrat de travail ou d\u2019un contrat de mission pour force majeure ou fait du prince",
        "084": "rupture d\u0027un commun accord du CDD, d\u2019un contrat de professionnalisation, du contrat d\u0027apprentissage ou d\u2019un contrat de mission",
        "085": "fin de mandat",
        "086": "licenciement convention CATS",
        "087": "licenciement pour faute grave",
        "088": "licenciement pour faute lourde",
        "089": "licenciement pour force majeure",
        "091": "licenciement pour inaptitude physique d\u0027origine non professionnelle",
        "092": "licenciement pour inaptitude physique d\u0027origine  professionnelle",
        "093": "licenciement suite \u00e0 d\u00e9cision d\u0027une autorit\u00e9 administrative",
        "094": "rupture anticip\u00e9e du contrat de travail pour arr\u00eat de tournage",
        "095": "rupture anticip\u00e9e du contrat de travail ou d\u2019un contrat de mission pour faute grave",
        "096": "rupture anticip\u00e9e du contrat de travail ou d\u2019un contrat de mission pour faute lourde",
        "097": "rupture anticip\u00e9e d\u2019un contrat de travail ou d\u2019un contrat de mission suite \u00e0 fermeture de l\u0027\u00e9tablissement",
        "098": "retrait d\u0027enfant",
        "099": "Annulation",
        "100": "Mutation au sein du m\u00eame groupe ou ext\u00e9rieure au groupe pour les secteurs d\u2019activit\u00e9 autoris\u00e9s (gardiennage, m\u00e9nage, restauration, etc.) sans rupture du contrat",
        "110": "Rupture conventionnelle collective",
        "111": "Rupture amiable dans le cadre d\u2019un cong\u00e9 de mobilit\u00e9",
        "112": "Rupture dans le cadre d\u0027un accord de performance collective",
        "113": "Licenciement pour motif sp\u00e9cifique (Article L. 2254-2 du Code du Travail)",
        "114": "Rupture d\u2019un commun accord pour entr\u00e9e en PAP",
        "115": "Licenciement au titre des articles 18 et 19 de la loi n\u00b0 2017-1339 du 15 septembre 2017",
        "116": "Fin de ligne de service",
        "117": "licenciement pour motif \u00e9conomique suite au refus d\u2019un contrat de s\u00e9curisation professionnelle",
        "118": "Fin de contrat d\u2019appui au projet d\u2019entreprise",
        "119": "Fin d\u0027affectation",
        "998": "transfert du contrat de travail sans rupture du contrat vers un autre \u00e9tablissement pas rentr\u00e9 dans la DSN",
        "999": "fin de relation avec l\u2019employeur (autres que contrat de travail, convention ou mandat)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_TypeUniteMesure(str, Enum):
    HEURE = "10"  # heure
    JOURNEE = "12"  # journée
    FORFAIT_JOUR = "20"  # forfait jour
    FORFAIT_HEURE = "21"  # forfait heure
    A_LA_PIGE = "31"  # à la pige
    A_LA_VACATION = "32"  # à la vacation
    A_LA_TACHE = "33"  # à la tâche
    AU_SMIC = "34"  # au SMIC
    A_LA_PART = "35"  # à la part
    SALARIE_NON_CONCERNE = "99"  # salarié non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "10": "heure",
        "12": "journ\u00e9e",
        "20": "forfait jour",
        "21": "forfait heure",
        "31": "\u00e0 la pige",
        "32": "\u00e0 la vacation",
        "33": "\u00e0 la t\u00e2che",
        "34": "au SMIC",
        "35": "\u00e0 la part",
        "99": "salari\u00e9 non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Nature_Juridique(str, Enum):
    ETABLISSEMENT = "01"  # Etablissement
    AUTRE = "02"  # Autre
    A_DOMICILE = "03"  # A domicile

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Etablissement",
        "02": "Autre",
        "03": "A domicile",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Declaration_Champ(str, Enum):
    DECLARATION_TOTALE = "01"  # déclaration totale
    DECLARATION_PARTIELLE_REGIME_AGRICOLE = "02"  # déclaration partielle régime agricole
    DECLARATION_PARTIELLE_REGIME_GENERAL = "03"  # déclaration partielle régime général

    __DESCRIPTIONS: dict[str, str] = {
        "01": "d\u00e9claration totale",
        "02": "d\u00e9claration partielle r\u00e9gime agricole",
        "03": "d\u00e9claration partielle r\u00e9gime g\u00e9n\u00e9ral",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Motif_reprise_DSN_phase_1(str, Enum):
    REPRISE_NORMALE = "01"  # reprise normale
    REPRISE_TEMPS_PARTIEL_THERAPEUTIQUE = "02"  # reprise temps partiel thérapeutique
    REPRISE_TEMPS_PARTIEL_RAISON_PERSONNELLE = "03"  # reprise temps partiel raison personnelle

    __DESCRIPTIONS: dict[str, str] = {
        "01": "reprise normale",
        "02": "reprise temps partiel th\u00e9rapeutique",
        "03": "reprise temps partiel raison personnelle",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class CodeRegime(str, Enum):
    REGIME_SPECIAL_DE_LA_SNCF = "134"  # régime spécial de la SNCF
    REGIME_SPECIAL_DE_LA_RATP = "135"  # régime spécial de la RATP
    ETABLISSEMENT_DES_INVALIDES_DE_LA_MARINE_ENIM = (
        "136"  # établissement des invalides de la marine (ENIM)
    )
    MINEURS_OU_ASSIMILES_CANSSM = "137"  # mineurs ou assimilés (CANSSM)
    MILITAIRES_DE_CARRIERE_CNMSS = "138"  # militaires de carrière (CNMSS)
    CLERCS_ET_EMPLOYES_DE_NOTAIRES_CRPCEN = "140"  # clercs et employés de notaires (CRPCEN)
    CHAMBRE_DE_COMMERCE_ET_D_INDUSTRIE_DE_PARIS = (
        "141"  # chambre de commerce et d'industrie de Paris
    )
    ASSEMBLEE_NATIONALE = "144"  # Assemblée Nationale
    SENAT = "145"  # Sénat
    PORT_AUTONOME_DE_BORDEAUX = "146"  # port autonome de Bordeaux
    REGIME_SPECIAL_DES_INDUSTRIES_ELECTRIQUES_ET_GAZIERES_CAMIEG = (
        "147"  # régime spécial des industries électriques et gazières (CAMIEG)
    )
    REGIMES_DES_CULTES_CAVIMAC = "149"  # régimes des cultes (CAVIMAC)
    REGIME_GENERAL_CNAM = "200"  # régime général (CNAM)
    REGIME_AGRICOLE_MSA = "300"  # régime agricole (MSA)
    REGIME_SPECIAL_BANQUE_DE_FRANCE = "400"  # régime spécial Banque de France
    AUTRE_REGIME_RESERVE_POLYNESIE_FRANCAISE_NOUVELLE_CALEDONIE = (
        "900"  # autre régime (réservé Polynésie Française, Nouvelle Calédonie)
    )
    TRAVAILLEUR_ETRANGER_NON_ASSUJETTI_A_UN_REGIME_DE_BASE_RISQUE_MALADIE_EN_FRANCE = (
        "909"  # travailleur étranger non assujetti à un régime de base risque maladie en France
    )
    SANS_REGIME_OBLIGATOIRE = "999"  # sans régime obligatoire

    __DESCRIPTIONS: dict[str, str] = {
        "134": "r\u00e9gime sp\u00e9cial de la SNCF",
        "135": "r\u00e9gime sp\u00e9cial de la RATP",
        "136": "\u00e9tablissement des invalides de la marine (ENIM)",
        "137": "mineurs ou assimil\u00e9s (CANSSM)",
        "138": "militaires de carri\u00e8re (CNMSS)",
        "140": "clercs et employ\u00e9s de notaires (CRPCEN)",
        "141": "chambre de commerce et d\u0027industrie de Paris",
        "144": "Assembl\u00e9e Nationale",
        "145": "S\u00e9nat",
        "146": "port autonome de Bordeaux",
        "147": "r\u00e9gime sp\u00e9cial des industries \u00e9lectriques et gazi\u00e8res (CAMIEG)",
        "149": "r\u00e9gimes des cultes (CAVIMAC)",
        "200": "r\u00e9gime g\u00e9n\u00e9ral (CNAM)",
        "300": "r\u00e9gime agricole (MSA)",
        "400": "r\u00e9gime sp\u00e9cial Banque de France",
        "900": "autre r\u00e9gime (r\u00e9serv\u00e9 Polyn\u00e9sie Fran\u00e7aise, Nouvelle Cal\u00e9donie)",
        "909": "travailleur \u00e9tranger non assujetti \u00e0 un r\u00e9gime de base risque maladie en France",
        "999": "sans r\u00e9gime obligatoire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Autre_Element_Revenu_Type(str, Enum):
    SOMME_VERSEE_PAR_UN_TIERS = "01"  # Somme versée par un tiers
    AVANTAGE_EN_NATURE_REPAS = "02"  # Avantage en nature : repas
    AVANTAGE_EN_NATURE_LOGEMENT = "03"  # Avantage en nature : logement
    AVANTAGE_EN_NATURE_VEHICULE = "04"  # Avantage en nature : véhicule
    AVANTAGE_EN_NATURE_NTIC = "05"  # Avantage en nature : NTIC
    AVANTAGE_EN_NATURE_AUTRES = "06"  # Avantage en nature : autres
    FRAIS_PROFESSIONNELS_REMBOURSES_AU_FORFAIT = "07"  # Frais professionnels remboursés au forfait
    FRAIS_PROFESSIONNELS_PRIS_EN_CHARGE_PAR_L_EMPLOYEUR = (
        "08"  # Frais professionnels pris en charge par l'employeur
    )
    FRAIS_PROFESSIONNELS_REMBOURSES_AU_REEL = "09"  # Frais professionnels remboursés au réel
    DEDUCTION_FORFAITAIRE_SPECIFIQUE = "10"  # Déduction forfaitaire spécifique
    PARTICIPATION_Y_COMPRIS_SUPPLEMENT = "11"  # Participation y compris supplément
    INTERESSEMENT_Y_COMPRIS_SUPPLEMENT = "12"  # Intéressement y compris supplément
    ABONDEMENT_AU_PLAN_D_EPARGNE_ENTREPRISE_PEE = (
        "14"  # Abondement au plan d'épargne entreprise (PEE)
    )
    ABONDEMENT_AU_PLAN_D_EPARGNE_INTERENTREPRISES_PEI = (
        "15"  # Abondement au plan d'épargne interentreprises (PEI)
    )
    ABONDEMENT_A_UN_PLAN_D_EPARGNE_POUR_LA_RETRAITE_COLLECTIF_PERCO_PERECO = (
        "16"  # Abondement à un plan d'épargne pour la retraite collectif (PERCO, PERECO)
    )
    PARTICIPATION_PATRONALE_AU_FINANCEMENT_DES_TITRES_RESTAURANT = (
        "17"  # Participation patronale au financement des titres-restaurant
    )
    PARTICIPATION_PATRONALE_AUX_FRAIS_DE_TRANSPORTS_PUBLICS = (
        "18"  # Participation patronale aux frais de transports publics
    )
    PARTICIPATION_PATRONALE_AUX_FRAIS_DE_TRANSPORTS_PERSONNELS = (
        "19"  # Participation patronale aux frais de transports personnels
    )
    DROIT_D_AUTEUR = "25"  # Droit d'auteur
    DROIT_DE_DOUBLAGE = "26"  # Droit de doublage
    DROIT_DE_REDIFFUSION = "27"  # Droit de rediffusion
    AVANTAGES_DE_PRERETRAITE_VERSES_PAR_L_EMPLOYEUR = (
        "31"  # Avantages de préretraite versés par l’employeur
    )
    SOMMES_PROVENANT_D_UN_CET_ET_REAFFECTEES_A_UN_PLAN_D_EPARGNE_RETRAITE_PERCO_PERECO_PEREO_OU_A_UN_REGIME_DE_RETRAITE_SUPPLEMENTAIRE = "33"  # Sommes provenant d'un CET et réaffectées à un plan d'épargne retraite (PERCO, PERECO, PEREO) ou à un régime de retraite supplémentaire
    FP_PRESTATIONS_FAMILIALES = "34"  # [FP] Prestations familiales
    PARTS_DES_FRAIS_PROFESSIONNELS_REINTEGREES_DANS_L_ASSIETTE_DE_CONTRIBUTION_DU_FAIT_DE_L_APPLICATION_D_UNE_DFS = "35"  # Parts des frais professionnels réintégrées dans l'assiette de contribution du fait de l'application d'une DFS
    SOMMES_PROVENANT_D_UN_CET_ET_CONVERTIES_EN_POINTS_RETRAITE_RAFP = (
        "36"  # Sommes provenant d'un CET et converties en points retraite RAFP
    )
    PARTICIPATION_ET_INTERESSEMENT_VERSES_IMMEDIATEMENT_ET_DIRECTEMENT_PAR_L_EMPLOYEUR = (
        "37"  # Participation et intéressement versés immédiatement et directement par l'employeur
    )
    POTENTIEL_NOUVEAU_TYPE_D_AUTRE_ELEMENT_DE_REVENU_BRUT_A = (
        "50"  # Potentiel nouveau type d'autre élément de revenu brut A
    )
    POTENTIEL_NOUVEAU_TYPE_D_AUTRE_ELEMENT_DE_REVENU_BRUT_B = (
        "51"  # Potentiel nouveau type d'autre élément de revenu brut B
    )
    PARTICIPATION_AU_FINANCEMENT_DES_SERVICES_A_LA_PERSONNE = (
        "90"  # Participation au financement des services à la personne
    )
    MONTANT_DE_LA_PARTICIPATION_DE_L_EMPLOYEUR_AUX_CHEQUES_VACANCES = (
        "91"  # Montant de la participation de l'employeur aux chèques vacances
    )
    COTISATION_PATRONALE_FRAIS_DE_SANTE = "92"  # Cotisation patronale frais de santé
    COTISATION_PREVOYANCE_ET_RETRAITE_SUPPLEMENTAIRE = (
        "93"  # Cotisation prévoyance et retraite supplémentaire
    )
    POTENTIEL_NOUVEAU_TYPE_D_AUTRE_ELEMENT_DE_REVENU_BRUT_C = (
        "94"  # Potentiel nouveau type d'autre élément de revenu brut C
    )
    POTENTIEL_NOUVEAU_TYPE_D_AUTRE_ELEMENT_DE_REVENU_BRUT_D = (
        "95"  # Potentiel nouveau type d'autre élément de revenu brut D
    )
    POTENTIEL_NOUVEAU_TYPE_D_AUTRE_ELEMENT_DE_REVENU_BRUT_E = (
        "96"  # Potentiel nouveau type d'autre élément de revenu brut E
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Somme vers\u00e9e par un tiers",
        "02": "Avantage en nature : repas",
        "03": "Avantage en nature : logement",
        "04": "Avantage en nature : v\u00e9hicule",
        "05": "Avantage en nature : NTIC",
        "06": "Avantage en nature : autres",
        "07": "Frais professionnels rembours\u00e9s au forfait",
        "08": "Frais professionnels pris en charge par l\u0027employeur",
        "09": "Frais professionnels rembours\u00e9s au r\u00e9el",
        "10": "D\u00e9duction forfaitaire sp\u00e9cifique",
        "11": "Participation y compris suppl\u00e9ment",
        "12": "Int\u00e9ressement y compris suppl\u00e9ment",
        "14": "Abondement au plan d\u0027\u00e9pargne entreprise (PEE)",
        "15": "Abondement au plan d\u0027\u00e9pargne interentreprises (PEI)",
        "16": "Abondement \u00e0 un plan d\u0027\u00e9pargne pour la retraite collectif (PERCO, PERECO)",
        "17": "Participation patronale au financement des titres-restaurant",
        "18": "Participation patronale aux frais de transports publics",
        "19": "Participation patronale aux frais de transports personnels",
        "25": "Droit d\u0027auteur",
        "26": "Droit de doublage",
        "27": "Droit de rediffusion",
        "31": "Avantages de pr\u00e9retraite vers\u00e9s par l\u2019employeur",
        "33": "Sommes provenant d\u0027un CET et r\u00e9affect\u00e9es \u00e0 un plan d\u0027\u00e9pargne retraite (PERCO, PERECO, PEREO) ou \u00e0 un r\u00e9gime de retraite suppl\u00e9mentaire",
        "34": "[FP] Prestations familiales",
        "35": "Parts des frais professionnels r\u00e9int\u00e9gr\u00e9es dans l\u0027assiette de contribution du fait de l\u0027application d\u0027une DFS",
        "36": "Sommes provenant d\u0027un CET et converties en points retraite RAFP",
        "37": "Participation et int\u00e9ressement vers\u00e9s imm\u00e9diatement et directement par l\u0027employeur",
        "50": "Potentiel nouveau type d\u0027autre \u00e9l\u00e9ment de revenu brut A",
        "51": "Potentiel nouveau type d\u0027autre \u00e9l\u00e9ment de revenu brut B",
        "90": "Participation au financement des services \u00e0 la personne",
        "91": "Montant de la participation de l\u0027employeur aux ch\u00e8ques vacances",
        "92": "Cotisation patronale frais de sant\u00e9",
        "93": "Cotisation pr\u00e9voyance et retraite suppl\u00e9mentaire",
        "94": "Potentiel nouveau type d\u0027autre \u00e9l\u00e9ment de revenu brut C",
        "95": "Potentiel nouveau type d\u0027autre \u00e9l\u00e9ment de revenu brut D",
        "96": "Potentiel nouveau type d\u0027autre \u00e9l\u00e9ment de revenu brut E",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Statut_Emplois(str, Enum):
    FP_FONCTIONNAIRE = "01"  # [FP] Fonctionnaire
    FP_CONTRACTUEL_DE_LA_FONCTION_PUBLIQUE = "02"  # [FP] Contractuel de la Fonction publique
    STATUTAIRE = "03"  # Statutaire
    NON_STATUTAIRE = "04"  # Non statutaire
    PERSONNEL_MEDICAL_HOSPITALIER = "06"  # Personnel médical hospitalier
    MEDECIN_SANS_STATUT_HOSPITALIER = "07"  # Médecin sans statut hospitalier
    FP_FONCTIONNAIRE_STAGIAIRE = "08"  # [FP] Fonctionnaire stagiaire
    FP_OUVRIER_D_ETAT = "09"  # [FP] Ouvrier d'Etat
    FP_MILITAIRE = "10"  # [FP] Militaire
    FP_PARCOURS_D_ACCES_AUX_CARRIERES_PACTE = "11"  # [FP] Parcours d'accès aux carrières (Pacte)
    FP_MILITAIRE_DE_RESERVE = "12"  # [FP] Militaire de réserve
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] Fonctionnaire",
        "02": "[FP] Contractuel de la Fonction publique",
        "03": "Statutaire",
        "04": "Non statutaire",
        "06": "Personnel m\u00e9dical hospitalier",
        "07": "M\u00e9decin sans statut hospitalier",
        "08": "[FP] Fonctionnaire stagiaire",
        "09": "[FP] Ouvrier d\u0027Etat",
        "10": "[FP] Militaire",
        "11": "[FP] Parcours d\u0027acc\u00e8s aux carri\u00e8res (Pacte)",
        "12": "[FP] Militaire de r\u00e9serve",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class RAC_StatutParticulier_DSN_phase_1(str, Enum):
    GERANT_OU_COLLEGE_DE_GERANCE = "01"  # Gérant ou collège de gérance
    ADMINISTRATEUR = "02"  # Administrateur
    DIRECTEUR_GENERAL = "03"  # Directeur Général
    PRESIDENT_DIRECTEUR_GENERAL = "04"  # Président Directeur Général
    MEMBRE_DU_DIRECTOIRE = "05"  # Membre du Directoire
    PRESIDENT_DU_DIRECTOIRE = "06"  # Président du Directoire
    MEMBRE_DU_CONSEIL_DE_SURVEILLANCE = "07"  # Membre du Conseil de surveillance
    PRESIDENT_ADMINISTRATEUR_SECRETAIRE_OU_TRESORIER_D_UNE_ASSOCIATION = (
        "08"  # Président, administrateur, secrétaire ou trésorier d'une association
    )
    CONTROLEUR_DE_GESTION_MEMBRE_OU_ADMINISTRATEUR_MEMBRE_D_UN_GIE = (
        "09"  # Contrôleur de gestion, membre ou administrateur membre d'un GIE
    )
    ASSOCIE_ACTIONNAIRE = "10"  # Associé, actionnaire
    SALARIE_EN_PORTAGE_SALARIAL = "11"  # Salarié en portage salarial

    __DESCRIPTIONS: dict[str, str] = {
        "01": "G\u00e9rant ou coll\u00e8ge de g\u00e9rance",
        "02": "Administrateur",
        "03": "Directeur G\u00e9n\u00e9ral",
        "04": "Pr\u00e9sident Directeur G\u00e9n\u00e9ral",
        "05": "Membre du Directoire",
        "06": "Pr\u00e9sident du Directoire",
        "07": "Membre du Conseil de surveillance",
        "08": "Pr\u00e9sident, administrateur, secr\u00e9taire ou tr\u00e9sorier d\u0027une association",
        "09": "Contr\u00f4leur de gestion, membre ou administrateur membre d\u0027un GIE",
        "10": "Associ\u00e9, actionnaire",
        "11": "Salari\u00e9 en portage salarial",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Mode_Paiement(str, Enum):
    CHEQUE = "01"  # chèque
    VIREMENT = "02"  # virement
    TITRE_INTER_BANCAIRE_DE_PAIEMENT = "04"  # titre inter-bancaire de paiement
    PRELEVEMENT_SEPA = "05"  # prélèvement SEPA
    VERSEMENT_REALISE_PAR_UN_AUTRE_ETABLISSEMENT = (
        "06"  # versement réalisé par un autre établissement
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "ch\u00e8que",
        "02": "virement",
        "04": "titre inter-bancaire de paiement",
        "05": "pr\u00e9l\u00e8vement SEPA",
        "06": "versement r\u00e9alis\u00e9 par un autre \u00e9tablissement",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Personnel_Couvert(str, Enum):
    OUI_CONCERNE_AU_MOINS_UN_SALARIE_DE_L_ETABLISSEMENT_D_AFFECTATION = (
        "01"  # Oui, concerne au moins un salarié de l'établissement d'affectation
    )
    NON_NE_CONCERNE_AUCUN_SALARIE_DE_L_ETABLISSEMENT_D_AFFECTATION = (
        "02"  # Non, ne concerne aucun salarié de l'établissement d'affectation
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Oui, concerne au moins un salari\u00e9 de l\u0027\u00e9tablissement d\u0027affectation",
        "02": "Non, ne concerne aucun salari\u00e9 de l\u0027\u00e9tablissement d\u0027affectation",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Statut_Etranger(str, Enum):
    TRAVAIL_FRONTALIER = "01"  # travail frontalier
    TRAVAIL_A_L_ETRANGER = "02"  # travail à l’étranger

    __DESCRIPTIONS: dict[str, str] = {
        "01": "travail frontalier",
        "02": "travail \u00e0 l\u2019\u00e9tranger",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Nouvelle_Embauche(str, Enum):
    NON = "01"  # Non
    OUI = "03"  # Oui

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Non",
        "03": "Oui",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Travailleur_Etranger(str, Enum):
    DETACHE = "01"  # Détaché
    EXPATRIE = "02"  # Expatrié
    FRONTALIER = "03"  # Frontalier
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "D\u00e9tach\u00e9",
        "02": "Expatri\u00e9",
        "03": "Frontalier",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_regime_risques(str, Enum):
    REGIME_SPECIAL_DE_LA_SNCF = "134"  # régime spécial de la SNCF
    REGIME_SPECIAL_DE_LA_RATP = "135"  # régime spécial de la RATP
    ETABLISSEMENT_DES_INVALIDES_DE_LA_MARINE_ENIM = (
        "136"  # établissement des invalides de la marine (ENIM)
    )
    MINEURS_OU_ASSIMILES_CANSSM = "137"  # mineurs ou assimilés (CANSSM)
    REGIME_SPECIAL_DES_INDUSTRIES_ELECTRIQUES_ET_GAZIERES = (
        "147"  # régime spécial des industries électriques et gazières
    )
    REGIME_GENERAL_CNAM = "200"  # régime général (CNAM)
    REGIME_AGRICOLE_CCMSA_OU_C3A = "300"  # régime agricole (CCMSA ou C3A)
    RISQUE_AT_MP_PRIS_EN_CHARGE_TOTALEMENT_PAR_L_EMPLOYEUR_HORS_PERIMETRE_ETAT = (
        "401"  # risque AT/MP pris en charge totalement par l'employeur (hors périmètre Etat)
    )
    RISQUE_AT_MP_PRIS_EN_CHARGE_PARTIELLEMENT_PAR_L_EMPLOYEUR_HORS_PERIMETRE_ETAT = (
        "402"  # risque AT/MP pris en charge partiellement par l'employeur (hors périmètre Etat)
    )
    AUTRE_REGIME = "900"  # autre régime
    SANS_REGIME_OBLIGATOIRE_FONCTIONNAIRE_DES_TROIS_FONCTIONS_PUBLIQUES_ET_CONTRACTUELS_DONT_LE_RISQUE_AT_EST_COUVERT_PAR_L_ETAT = "999"  # sans régime obligatoire (fonctionnaire des trois fonctions publiques et contractuels dont le risque AT est couvert par l'Etat)

    __DESCRIPTIONS: dict[str, str] = {
        "134": "r\u00e9gime sp\u00e9cial de la SNCF",
        "135": "r\u00e9gime sp\u00e9cial de la RATP",
        "136": "\u00e9tablissement des invalides de la marine (ENIM)",
        "137": "mineurs ou assimil\u00e9s (CANSSM)",
        "147": "r\u00e9gime sp\u00e9cial des industries \u00e9lectriques et gazi\u00e8res",
        "200": "r\u00e9gime g\u00e9n\u00e9ral (CNAM)",
        "300": "r\u00e9gime agricole (CCMSA ou C3A)",
        "401": "risque AT/MP pris en charge totalement par l\u0027employeur (hors p\u00e9rim\u00e8tre Etat)",
        "402": "risque AT/MP pris en charge partiellement par l\u0027employeur (hors p\u00e9rim\u00e8tre Etat)",
        "900": "autre r\u00e9gime",
        "999": "sans r\u00e9gime obligatoire (fonctionnaire des trois fonctions publiques et contractuels dont le risque AT est couvert par l\u0027Etat)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code(str, Enum):
    HONORAIRES_VACATIONS = "01"  # honoraires, vacations
    COMMISSIONS = "02"  # commissions
    COURTAGES = "03"  # courtages
    RISTOURNES = "04"  # ristournes
    JETONS_DE_PRESENCE = "05"  # jetons de présence
    DROITS_D_AUTEUR = "06"  # droits d'auteur
    DROITS_D_INVENTEUR = "07"  # droits d'inventeur
    AUTRES_REMUNERATIONS = "08"  # autres rémunérations
    RETENUE_IMPOT_SUR_LE_REVENU = "11"  # retenue impôt sur le revenu

    __DESCRIPTIONS: dict[str, str] = {
        "01": "honoraires, vacations",
        "02": "commissions",
        "03": "courtages",
        "04": "ristournes",
        "05": "jetons de pr\u00e9sence",
        "06": "droits d\u0027auteur",
        "07": "droits d\u0027inventeur",
        "08": "autres r\u00e9mun\u00e9rations",
        "11": "retenue imp\u00f4t sur le revenu",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Taxe(str, Enum):
    ASSUJETTISSEMENT_A_LA_TAXE_A_L_APPRENTISSAGE = (
        "001"  # Assujettissement à la taxe à l'apprentissage
    )
    NON_ASSUJETTISSEMENT_A_LA_TAXE_A_L_APPRENTISSAGE = (
        "002"  # Non assujettissement à la taxe à l'apprentissage
    )
    ASSUJETTISSEMENT_A_LA_CONTRIBUTION_SUPPLEMENTAIRE_A_L_APPRENTISSAGE = (
        "003"  # Assujettissement à la contribution supplémentaire à l’apprentissage
    )
    NON_ASSUJETTISSEMENT_A_LA_CONTRIBUTION_SUPPLEMENTAIRE_A_L_APPRENTISSAGE = (
        "004"  # Non assujettissement à la contribution supplémentaire à l’apprentissage
    )
    ASSUJETTISSEMENT_A_LA_PARTICIPATION_DES_EMPLOYEURS_A_L_EFFORT_DE_CONSTRUCTION_PEEC = "005"  # Assujettissement à la participation des employeurs à l'effort de construction (PEEC)
    NON_ASSUJETTISSEMENT_A_LA_PARTICIPATION_DES_EMPLOYEURS_A_L_EFFORT_DE_CONSTRUCTION_PEEC = "006"  # Non assujettissement à la participation des employeurs à l'effort de construction (PEEC)
    ASSUJETTISSEMENT_A_LA_CONTRIBUTION_A_LA_FORMATION_PROFESSIONNELLE_CFP = (
        "007"  # Assujettissement à la contribution à la formation professionnelle (CFP)
    )
    NON_ASSUJETTISSEMENT_A_LA_CONTRIBUTION_A_LA_FORMATION_PROFESSIONNELLE_CFP = (
        "008"  # Non assujettissement à la contribution à la formation professionnelle (CFP)
    )
    ASSUJETTISSEMENT_A_LA_TAXE_SUR_LES_SALAIRES = (
        "009"  # Assujettissement à la taxe sur les salaires
    )
    NON_ASSUJETTISSEMENT_A_LA_TAXE_SUR_LES_SALAIRES = (
        "010"  # Non assujettissement à la taxe sur les salaires
    )
    ASSUJETTISSEMENT_A_LA_CONTRIBUTION_DEDIEE_AU_FINANCEMENT_DU_COMPTE_PERSONNEL_DE_FORMATION_POUR_LES_TITULAIRES_DE_CDD_CPF_CDD = "013"  # Assujettissement à la contribution dédiée au financement du Compte Personnel de Formation pour les titulaires de CDD (CPF-CDD)
    NON_ASSUJETTISSEMENT_A_LA_CONTRIBUTION_DEDIEE_AU_FINANCEMENT_DU_COMPTE_PERSONNEL_DE_FORMATION_POUR_LES_TITULAIRES_DE_CDD_CPF_CDD = "014"  # Non assujettissement à la contribution dédiée au financement du Compte Personnel de Formation pour les titulaires de CDD (CPF-CDD)
    ASSIETTE_DE_LA_TAXE_SUR_LES_SALAIRES_AU_PREMIER_TAUX = (
        "015"  # Assiette de la taxe sur les salaires au premier taux
    )
    ASSIETTE_DE_LA_TAXE_SUR_LES_SALAIRES_AU_DEUXIEME_TAUX = (
        "016"  # Assiette de la taxe sur les salaires au deuxième taux
    )

    __DESCRIPTIONS: dict[str, str] = {
        "001": "Assujettissement \u00e0 la taxe \u00e0 l\u0027apprentissage",
        "002": "Non assujettissement \u00e0 la taxe \u00e0 l\u0027apprentissage",
        "003": "Assujettissement \u00e0 la contribution suppl\u00e9mentaire \u00e0 l\u2019apprentissage",
        "004": "Non assujettissement \u00e0 la contribution suppl\u00e9mentaire \u00e0 l\u2019apprentissage",
        "005": "Assujettissement \u00e0 la participation des employeurs \u00e0 l\u0027effort de construction (PEEC)",
        "006": "Non assujettissement \u00e0 la participation des employeurs \u00e0 l\u0027effort de construction (PEEC)",
        "007": "Assujettissement \u00e0 la contribution \u00e0 la formation professionnelle (CFP)",
        "008": "Non assujettissement \u00e0 la contribution \u00e0 la formation professionnelle (CFP)",
        "009": "Assujettissement \u00e0 la taxe sur les salaires",
        "010": "Non assujettissement \u00e0 la taxe sur les salaires",
        "013": "Assujettissement \u00e0 la contribution d\u00e9di\u00e9e au financement du Compte Personnel de Formation pour les titulaires de CDD (CPF-CDD)",
        "014": "Non assujettissement \u00e0 la contribution d\u00e9di\u00e9e au financement du Compte Personnel de Formation pour les titulaires de CDD (CPF-CDD)",
        "015": "Assiette de la taxe sur les salaires au premier taux",
        "016": "Assiette de la taxe sur les salaires au deuxi\u00e8me taux",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Cotisation(str, Enum):
    COTISATION_ADPFA_ASSOCIATION_POUR_LE_DEVELOPPEMENT_DU_PARITARISME_DES_FLEURISTES_ET_ANIMALIERS = "001"  # Cotisation ADPFA (Association pour le Développement du Paritarisme des Fleuristes et Animaliers)
    COTISATION_APNAB_ASSOCIATION_PARITAIRE_NATIONALE_POUR_LE_DEVELOPPEMENT_DE_LA_NEGOCIATION_COLLECTIVE_DANS_L_ARTISANAT_DU_BATIMENT = "002"  # Cotisation APNAB (Association Paritaire Nationale pour le développement de la négociation collective dans l'Artisanat du Bâtiment)
    COTISATION_SUR_ASSIETTE_AVEC_CONGES_PAYES_CCCA_BTP_COMITE_DE_CONCERTATION_ET_DE_COORDINATION_DE_L_APPRENTISSAGE_DU_BATIMENT_ET_DES_TRAVAUX_PUBLICS = "003"  # Cotisation sur assiette avec congés payés CCCA-BTP (Comité de Concertation et de Coordination de l'apprentissage du Bâtiment et des Travaux Publics)
    COTISATION_CPPNTT_COMMISSION_PARITAIRE_PROFESSIONNELLE_NATIONALE_DU_TRAVAIL_TEMPORAIRE = "004"  # Cotisation CPPNTT (Commission Paritaire Professionnelle Nationale du Travail Temporaire)
    COTISATION_DEVELOPPEMENT_DU_PARITARISME = "005"  # Cotisation Développement du paritarisme
    COTISATION_DIALOGUE_SOCIAL = "006"  # Cotisation Dialogue social
    COTISATION_FAF_FONDS_D_ASSURANCE_FORMATION = (
        "007"  # Cotisation FAF (Fonds d'Assurance formation)
    )
    COTISATION_FAPS_FONDS_D_ACTION_PROFESSIONNELLE_ET_SOCIALE = (
        "009"  # Cotisation FAPS (Fonds d'action professionnelle et sociale)
    )
    COTISATION_FASTT_FONDS_D_ACTION_SOCIALE_DU_TRAVAIL_TEMPORAIRE = (
        "010"  # Cotisation FASTT (Fonds d'Action Sociale du Travail Temporaire)
    )
    COTISATION_FONDS_DE_PEREQUATION = "011"  # Cotisation Fonds de péréquation
    COTISATION_IFC_INDEMNITES_DE_FIN_DE_CARRIERE = (
        "012"  # Cotisation IFC (Indemnités de fin de carrière)
    )
    COTISATION_ORGA_ORGANISATIONS_SYNDICALES_DU_TRAVAIL_TEMPORAIRE = (
        "017"  # Cotisation ORGA (Organisations Syndicales  du Travail Temporaire)
    )
    COTISATION_PROMOTION_ET_RECRUTEMENT = "018"  # Cotisation Promotion et recrutement
    COTISATIONS_ATTACHEES_A_UNE_POPULATION_DE_NON_SALARIES_AYANTS_DROIT = (
        "019"  # Cotisations attachées à une population de non salariés ayants-droit
    )
    COTISATIONS_ATTACHEES_A_UNE_POPULATION_DE_NON_SALARIES_RETRAITES = (
        "020"  # Cotisations attachées à une population de non salariés retraités
    )
    COTISATIONS_FMSE_FOND_NATIONAL_AGRICOLE_DE_MUTUALISATION_DES_RISQUES_SANITAIRES_ET_ENVIRONNEMENTAUX = "021"  # Cotisations FMSE (Fond national agricole de mutualisation des risques sanitaires et environnementaux)
    COTISATIONS_VAL_HOR_ASSOCIATION_FRANCAISE_POUR_LA_VALORISATION_DES_PRODUITS_ET_METIERS_DE_L_HORTICULTURE_ET_DU_PAYSAGE = "022"  # Cotisations VAL'HOR (association française pour la valorisation des produits et métiers de l'horticulture et du paysage)
    ACTIVATION_DU_BENEFICE_DE_L_AIDE_AU_PAIEMENT_DES_COTISATIONS = (
        "023"  # Activation du bénéfice de l'aide au paiement des cotisations
    )
    COTISATION_ASSISE_SUR_LE_NOMBRE_D_HEURES_D_INTERIM = (
        "024"  # Cotisation assise sur le nombre d'heures d'intérim
    )
    CONTRIBUTION_AUX_REGIMES_SUPPLEMENTAIRES_DE_RETRAITE_A_PRESTATIONS_DEFINIES_RENTE = (
        "025"  # Contribution aux régimes supplémentaires de retraite à prestations définies - Rente
    )
    CONTRIBUTION_AUX_REGIMES_SUPPLEMENTAIRES_DE_RETRAITE_A_PRESTATIONS_DEFINIES_PRIME = (
        "026"  # Contribution aux régimes supplémentaires de retraite à prestations définies - Prime
    )
    CONTRIBUTION_AUX_REGIMES_SUPPLEMENTAIRES_DE_RETRAITE_A_PRESTATIONS_DEFINIES_DOTATIONS = "027"  # Contribution aux régimes supplémentaires de retraite à prestations définies - Dotations
    CONTRIBUTION_ADDITIONNELLE_SUR_LES_RENTES_LIQUIDEES = (
        "028"  # Contribution additionnelle sur les rentes liquidées
    )
    CONTRIBUTION_AUX_REGIMES_SUPPLEMENTAIRES_DE_RETRAITE_A_PRESTATIONS_DEFINIES_RENTE_A_TAUX_7 = "029"  # Contribution aux régimes supplémentaires de retraite à prestations définies. Rente à taux 7%
    CONTRIBUTION_AUX_REGIMES_SUPPLEMENTAIRES_DE_RETRAITE_A_PRESTATIONS_DEFINIES_RENTE_A_TAUX_14 = "030"  # Contribution aux régimes supplémentaires de retraite à prestations définies. Rente à taux 14%
    CONTRIBUTION_ADDITIONNELLE_DE_SOLIDARITE_POUR_L_AUTONOMIE = (
        "031"  # Contribution additionnelle de solidarité pour l'autonomie
    )
    CONTRIBUTION_SOCIALE_GENERALISEE_AU_TAUX_DE_3_80_RDS_SUR_REVENU_DE_REMPLACEMENT = (
        "032"  # Contribution Sociale généralisée au taux de 3,80% + RDS sur revenu de remplacement
    )
    CONTRIBUTION_SOCIALE_GENERALISEE_AU_TAUX_DE_6_20_RDS_SUR_REVENU_DE_REMPLACEMENT = (
        "033"  # Contribution Sociale généralisée au taux de 6,20% + RDS sur revenu de remplacement
    )
    CONTRIBUTION_SOCIALE_GENERALISEE_AU_TAUX_DE_6_60_RDS_SUR_REVENU_DE_REMPLACEMENT = (
        "034"  # Contribution Sociale généralisée au taux de 6,60% + RDS sur revenu de remplacement
    )
    CONTRIBUTION_SOCIALE_GENERALISEE_AU_TAUX_DE_7_50_RDS_SUR_REVENU_DE_REMPLACEMENT = (
        "035"  # Contribution Sociale généralisée au taux de 7,50% + RDS sur revenu de remplacement
    )
    COTISATION_TTC_SUR_ASSIETTE_CDD_AVEC_CONGES_PAYES_POUR_LE_SECTEUR_DU_BTP_CONSTRUCTYS_ORGANISME_PARITAIRE_COLLECTEUR_AGREE_POUR_LE_BTP = "036"  # Cotisation TTC sur assiette CDD avec congés payés pour le secteur du BTP (Constructys Organisme Paritaire Collecteur Agréé pour le BTP)
    COTISATION_TTC_SUR_ASSIETTE_AVEC_CONGES_PAYES_POUR_LE_SECTEUR_DU_BTP_CONSTRUCTYS_ORGANISME_PARITAIRE_COLLECTEUR_AGREE_POUR_LE_BTP = "037"  # Cotisation TTC sur assiette avec congés payés pour le secteur du BTP (Constructys Organisme Paritaire Collecteur Agréé pour le BTP)
    COTISATION_TTC_SUR_ASSIETTE_SANS_CONGES_PAYES_CONSTRUCTYS_ORGANISME_PARITAIRE_COLLECTEUR_AGREE_POUR_LE_BTP = "038"  # Cotisation TTC  sur assiette sans  congés payés (Constructys Organisme Paritaire Collecteur Agréé pour le BTP)
    COTISATION_TTC_SUR_ASSIETTE_AVEC_CONGES_PAYES_POUR_LES_SALARIES_NON_SOUMIS_A_LA_COTISATION_CCCA_BTP_CONSTRUCTYS_ORGANISME_PARITAIRE_COLLECTEUR_AGREE_POUR_LE_BTP = "039"  # Cotisation TTC  sur assiette avec congés payés pour les salariés non soumis à la cotisation CCCA-BTP (Constructys Organisme Paritaire Collecteur Agréé pour le BTP)
    COTISATION_TTC_SUR_ASSIETTE_HORS_CONGES_PAYES_POUR_LES_SALARIES_NON_SOUMIS_A_LA_COTISATION_CCCA_BTP_CONSTRUCTYS_ORGANISME_PARITAIRE_COLLECTEUR_AGREE_POUR_LE_BTP = "040"  # Cotisation TTC  sur assiette hors congés payés pour les salariés non soumis à la cotisation CCCA-BTP (Constructys Organisme Paritaire Collecteur Agréé pour le BTP)
    COTISATION_MALADIE_SUR_LES_AVANTAGES_DE_PRERETRAITE = (
        "041"  # Cotisation maladie sur les avantages de préretraite
    )
    COTISATION_MALADIE_SUR_LES_AVANTAGES_DE_RETRAITE = (
        "042"  # Cotisation maladie sur les avantages de retraite
    )
    COTISATION_MALADIE_ALSACE_MOSELLE_SUR_LES_AVANTAGES_DE_RETRAITE = (
        "043"  # Cotisation maladie Alsace-Moselle sur les avantages de retraite
    )
    COTISATION_FORFAIT_SOCIAL_A_8 = "044"  # Cotisation forfait social à 8%
    COTISATION_FORFAIT_SOCIAL_A_20 = "045"  # Cotisation forfait social à 20%
    COTISATIONS_ORGANISMES_OU_SYNDICATS_PROFESSIONNELS_RECOUVREES_PAR_AUDIENS_CULTURE_COMMUNICATION_MEDIAS = "046"  # Cotisations organismes ou syndicats professionnels recouvrées par Audiens (Culture Communication Médias)
    COTISATION_FORFAIT_SOCIAL_A_16 = "047"  # Cotisation forfait social à 16%
    COTISATION_FORFAIT_SOCIAL_A_10 = "048"  # Cotisation forfait social à 10%
    CSG_AU_TAUX_DE_8_30_RDS_SUR_REVENUS_DE_REMPLACEMENT = (
        "049"  # CSG au taux de 8.30% + RDS sur revenus de remplacement
    )
    CSG_AU_TAUX_DE_9_20_RDS_SUR_REVENUS_DE_REMPLACEMENT = (
        "050"  # CSG au taux de 9.20% + RDS sur revenus de remplacement
    )
    COTISATION_ASSISE_SUR_LE_CHIFFRE_D_AFFAIRES = (
        "054"  # Cotisation assise sur le chiffre d'affaires
    )
    DEDUCTION_ECAP = "060"  # Déduction ECAP
    DEDUCTION_DE_SOUS_TRAITANCE_EA_ESAT_TIH_PORTAGE_SALARIAL = (
        "061"  # Déduction de sous-traitance (EA, ESAT, TIH, portage salarial)
    )
    DEPENSE_DEDUCTIBLE_LIEE_AUX_TRAVAUX_D_ACCESSIBILITE = (
        "062"  # Dépense déductible liée aux travaux d’accessibilité
    )
    DEPENSE_DEDUCTIBLE_LIEE_AU_MAINTIEN_ET_A_LA_RECONVERSION_PROFESSIONNELLE = (
        "063"  # Dépense déductible liée au maintien et à la reconversion professionnelle
    )
    DEPENSE_DEDUCTIBLE_LIEE_AUX_PRESTATIONS_D_ACCOMPAGNEMENT_ET_DE_SENSIBILISATION = (
        "064"  # Dépense déductible liée aux prestations d’accompagnement et de sensibilisation
    )
    CONTRIBUTION_OETH_BRUTE_AVANT_DEDUCTIONS = "065"  # Contribution OETH brute avant déductions
    CONTRIBUTION_OETH_NETTE = "066"  # Contribution OETH nette
    CONTRIBUTION_OETH_NETTE_APRES_ECRETEMENT_POUR_LES_MILLESIMES_STRICTEMENT_ANTERIEURS_A_2025 = "067"  # Contribution OETH nette après écrêtement (pour les millésimes strictement antérieurs à 2025)
    CONTRIBUTION_OETH_REELLE_DUE = "068"  # Contribution OETH réelle due
    DEPENSES_OETH_PREVUES_PAR_L_ACCORD_ET_NON_REALISEES = (
        "069"  # Dépenses OETH prévues par l’accord et non réalisées
    )
    DEPENSE_DEDUCTIBLE_LIEE_A_LA_PARTICIPATION_A_DES_EVENEMENTS = (
        "071"  # Dépense déductible liée à la participation à des événements
    )
    DEPENSE_DEDUCTIBLE_LIEE_AUX_PARTENARIATS_AVEC_DES_ASSOCIATIONS = (
        "072"  # Dépense déductible liée aux partenariats avec des associations
    )
    DEPENSES_DEDUCTIBLES_LIEES_AUX_ACTIONS_CONCOURANT_A_LA_PROFESSIONNALISATION_ET_AUX_ACHATS_AUPRES_DES_EA_ESAT_TIH = "073"  # Dépenses déductibles liées aux actions concourant à la professionnalisation et aux achats auprès des EA, ESAT, TIH
    EXONERATION_TAXE_D_APPRENTISSAGE_POUR_UN_EMPLOYEUR_D_APPRENTI_S_DONT_LA_MASSE_SALARIALE_EST_INFERIEURE_A_6_SMICS = "074"  # Exonération Taxe d’apprentissage pour un employeur d’apprenti(s), dont la masse salariale est inférieure à 6 SMICs
    DEDUCTIONS_RELATIVES_AUX_CFA_D_ENTREPRISE_ET_OU_AU_FINANCEMENT_DES_OFFRES_NOUVELLES_DE_FORMATION_PAR_APPRENTISSAGE_ART_L6241_2_CODE_DU_TRAVAIL = "075"  # Déductions relatives aux CFA d’entreprise et/ou au financement des offres nouvelles de formation par apprentissage (Art. L6241-2 code du travail)
    SOLDE_DE_LA_TAXE_D_APPRENTISSAGE_VERSE_EN_NUMERAIRE = (
        "076"  # Solde de la taxe d'apprentissage versé en numéraire
    )
    REDUCTION_DU_SOLDE_DE_LA_TAXE_D_APPRENTISSAGE_LIEE_A_DES_SUBVENTIONS_AUX_CFA_ART_L6241_4_DU_CODE_DU_TRAVAIL_VERSE_EN_NATURE = "077"  # Réduction du solde de la taxe d’apprentissage liée à des subventions aux CFA (Art. L6241-4 du code du travail) versé en nature
    REDUCTION_DU_SOLDE_DE_LA_TAXE_D_APPRENTISSAGE_LIEE_A_DES_CREANCES_ALTERNANTS_ART_L6241_4_DU_CODE_DU_TRAVAIL = "078"  # Réduction du solde de la taxe d’apprentissage liée à des créances alternants (Art. L6241-4 du code du travail)
    CONTRIBUTION_SUPPLEMENTAIRE_A_L_APPRENTISSAGE_CSA = (
        "079"  # Contribution supplémentaire à l’apprentissage (CSA)
    )
    EXONERATION_DE_LA_CONTRIBUTION_SUPPLEMENTAIRE_A_L_APPRENTISSAGE_CSA = (
        "080"  # Exonération de la contribution supplémentaire à l’apprentissage (CSA)
    )
    COTISATION_SPECIFIQUE_PREVOYANCE = "090"  # Cotisation spécifique Prévoyance
    COTISATION_RELATIVE_AUX_DROITS_SPECIFIQUES_PASSES_DES_ACTIVITES_NON_REGULEES_DSPNR = "091"  # Cotisation relative aux droits spécifiques passés des activités non régulées (DSPNR)
    POTENTIELLE_NOUVELLE_COTISATION_ETABLISSEMENT_B = (
        "092"  # Potentielle nouvelle cotisation établissement B
    )
    POTENTIELLE_NOUVELLE_COTISATION_ETABLISSEMENT_C = (
        "093"  # Potentielle nouvelle cotisation établissement C
    )
    POTENTIELLE_NOUVELLE_COTISATION_ETABLISSEMENT_A = (
        "094"  # Potentielle nouvelle cotisation établissement A
    )
    POTENTIELLE_NOUVELLE_COTISATION_ETABLISSEMENT_D = (
        "095"  # Potentielle nouvelle cotisation établissement D
    )
    POTENTIELLE_NOUVELLE_COTISATION_ETABLISSEMENT_E = (
        "096"  # Potentielle nouvelle cotisation établissement E
    )

    __DESCRIPTIONS: dict[str, str] = {
        "001": "Cotisation ADPFA (Association pour le D\u00e9veloppement du Paritarisme des Fleuristes et Animaliers)",
        "002": "Cotisation APNAB (Association Paritaire Nationale pour le d\u00e9veloppement de la n\u00e9gociation collective dans l\u0027Artisanat du B\u00e2timent)",
        "003": "Cotisation sur assiette avec cong\u00e9s pay\u00e9s CCCA-BTP (Comit\u00e9 de Concertation et de Coordination de l\u0027apprentissage du B\u00e2timent et des Travaux Publics)",
        "004": "Cotisation CPPNTT (Commission Paritaire Professionnelle Nationale du Travail Temporaire)",
        "005": "Cotisation D\u00e9veloppement du paritarisme",
        "006": "Cotisation Dialogue social",
        "007": "Cotisation FAF (Fonds d\u0027Assurance formation)",
        "009": "Cotisation FAPS (Fonds d\u0027action professionnelle et sociale)",
        "010": "Cotisation FASTT (Fonds d\u0027Action Sociale du Travail Temporaire)",
        "011": "Cotisation Fonds de p\u00e9r\u00e9quation",
        "012": "Cotisation IFC (Indemnit\u00e9s de fin de carri\u00e8re)",
        "017": "Cotisation ORGA (Organisations Syndicales  du Travail Temporaire)",
        "018": "Cotisation Promotion et recrutement",
        "019": "Cotisations attach\u00e9es \u00e0 une population de non salari\u00e9s ayants-droit",
        "020": "Cotisations attach\u00e9es \u00e0 une population de non salari\u00e9s retrait\u00e9s",
        "021": "Cotisations FMSE (Fond national agricole de mutualisation des risques sanitaires et environnementaux)",
        "022": "Cotisations VAL\u0027HOR (association fran\u00e7aise pour la valorisation des produits et m\u00e9tiers de l\u0027horticulture et du paysage)",
        "023": "Activation du b\u00e9n\u00e9fice de l\u0027aide au paiement des cotisations",
        "024": "Cotisation assise sur le nombre d\u0027heures d\u0027int\u00e9rim",
        "025": "Contribution aux r\u00e9gimes suppl\u00e9mentaires de retraite \u00e0 prestations d\u00e9finies - Rente",
        "026": "Contribution aux r\u00e9gimes suppl\u00e9mentaires de retraite \u00e0 prestations d\u00e9finies - Prime",
        "027": "Contribution aux r\u00e9gimes suppl\u00e9mentaires de retraite \u00e0 prestations d\u00e9finies - Dotations",
        "028": "Contribution additionnelle sur les rentes liquid\u00e9es",
        "029": "Contribution aux r\u00e9gimes suppl\u00e9mentaires de retraite \u00e0 prestations d\u00e9finies. Rente \u00e0 taux 7%",
        "030": "Contribution aux r\u00e9gimes suppl\u00e9mentaires de retraite \u00e0 prestations d\u00e9finies. Rente \u00e0 taux 14%",
        "031": "Contribution additionnelle de solidarit\u00e9 pour l\u0027autonomie",
        "032": "Contribution Sociale g\u00e9n\u00e9ralis\u00e9e au taux de 3,80% + RDS sur revenu de remplacement",
        "033": "Contribution Sociale g\u00e9n\u00e9ralis\u00e9e au taux de 6,20% + RDS sur revenu de remplacement",
        "034": "Contribution Sociale g\u00e9n\u00e9ralis\u00e9e au taux de 6,60% + RDS sur revenu de remplacement",
        "035": "Contribution Sociale g\u00e9n\u00e9ralis\u00e9e au taux de 7,50% + RDS sur revenu de remplacement",
        "036": "Cotisation TTC sur assiette CDD avec cong\u00e9s pay\u00e9s pour le secteur du BTP (Constructys Organisme Paritaire Collecteur Agr\u00e9\u00e9 pour le BTP)",
        "037": "Cotisation TTC sur assiette avec cong\u00e9s pay\u00e9s pour le secteur du BTP (Constructys Organisme Paritaire Collecteur Agr\u00e9\u00e9 pour le BTP)",
        "038": "Cotisation TTC  sur assiette sans  cong\u00e9s pay\u00e9s (Constructys Organisme Paritaire Collecteur Agr\u00e9\u00e9 pour le BTP)",
        "039": "Cotisation TTC  sur assiette avec cong\u00e9s pay\u00e9s pour les salari\u00e9s non soumis \u00e0 la cotisation CCCA-BTP (Constructys Organisme Paritaire Collecteur Agr\u00e9\u00e9 pour le BTP)",
        "040": "Cotisation TTC  sur assiette hors cong\u00e9s pay\u00e9s pour les salari\u00e9s non soumis \u00e0 la cotisation CCCA-BTP (Constructys Organisme Paritaire Collecteur Agr\u00e9\u00e9 pour le BTP)",
        "041": "Cotisation maladie sur les avantages de pr\u00e9retraite",
        "042": "Cotisation maladie sur les avantages de retraite",
        "043": "Cotisation maladie Alsace-Moselle sur les avantages de retraite",
        "044": "Cotisation forfait social \u00e0 8%",
        "045": "Cotisation forfait social \u00e0 20%",
        "046": "Cotisations organismes ou syndicats professionnels recouvr\u00e9es par Audiens (Culture Communication M\u00e9dias)",
        "047": "Cotisation forfait social \u00e0 16%",
        "048": "Cotisation forfait social \u00e0 10%",
        "049": "CSG au taux de 8.30% + RDS sur revenus de remplacement",
        "050": "CSG au taux de 9.20% + RDS sur revenus de remplacement",
        "054": "Cotisation assise sur le chiffre d\u0027affaires",
        "060": "D\u00e9duction ECAP",
        "061": "D\u00e9duction de sous-traitance (EA, ESAT, TIH, portage salarial)",
        "062": "D\u00e9pense d\u00e9ductible li\u00e9e aux travaux d\u2019accessibilit\u00e9",
        "063": "D\u00e9pense d\u00e9ductible li\u00e9e au maintien et \u00e0 la reconversion professionnelle",
        "064": "D\u00e9pense d\u00e9ductible li\u00e9e aux prestations d\u2019accompagnement et de sensibilisation",
        "065": "Contribution OETH brute avant d\u00e9ductions",
        "066": "Contribution OETH nette",
        "067": "Contribution OETH nette apr\u00e8s \u00e9cr\u00eatement (pour les mill\u00e9simes strictement ant\u00e9rieurs \u00e0 2025)",
        "068": "Contribution OETH r\u00e9elle due",
        "069": "D\u00e9penses OETH pr\u00e9vues par l\u2019accord et non r\u00e9alis\u00e9es",
        "071": "D\u00e9pense d\u00e9ductible li\u00e9e \u00e0 la participation \u00e0 des \u00e9v\u00e9nements",
        "072": "D\u00e9pense d\u00e9ductible li\u00e9e aux partenariats avec des associations",
        "073": "D\u00e9penses d\u00e9ductibles li\u00e9es aux actions concourant \u00e0 la professionnalisation et aux achats aupr\u00e8s des EA, ESAT, TIH",
        "074": "Exon\u00e9ration Taxe d\u2019apprentissage pour un employeur d\u2019apprenti(s), dont la masse salariale est inf\u00e9rieure \u00e0 6 SMICs",
        "075": "D\u00e9ductions relatives aux CFA d\u2019entreprise et/ou au financement des offres nouvelles de formation par apprentissage (Art. L6241-2 code du travail)",
        "076": "Solde de la taxe d\u0027apprentissage vers\u00e9 en num\u00e9raire",
        "077": "R\u00e9duction du solde de la taxe d\u2019apprentissage li\u00e9e \u00e0 des subventions aux CFA (Art. L6241-4 du code du travail) vers\u00e9 en nature",
        "078": "R\u00e9duction du solde de la taxe d\u2019apprentissage li\u00e9e \u00e0 des cr\u00e9ances alternants (Art. L6241-4 du code du travail)",
        "079": "Contribution suppl\u00e9mentaire \u00e0 l\u2019apprentissage (CSA)",
        "080": "Exon\u00e9ration de la contribution suppl\u00e9mentaire \u00e0 l\u2019apprentissage (CSA)",
        "090": "Cotisation sp\u00e9cifique Pr\u00e9voyance",
        "091": "Cotisation relative aux droits sp\u00e9cifiques pass\u00e9s des activit\u00e9s non r\u00e9gul\u00e9es (DSPNR)",
        "092": "Potentielle nouvelle cotisation \u00e9tablissement B",
        "093": "Potentielle nouvelle cotisation \u00e9tablissement C",
        "094": "Potentielle nouvelle cotisation \u00e9tablissement A",
        "095": "Potentielle nouvelle cotisation \u00e9tablissement D",
        "096": "Potentielle nouvelle cotisation \u00e9tablissement E",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Anciennete_Type(str, Enum):
    ANCIENNETE_DANS_LA_BRANCHE_PROFESSIONNELLE_OU_LE_SECTEUR_D_ACTIVITE = (
        "02"  # Ancienneté dans la branche professionnelle ou le secteur d'activité
    )
    ANCIENNETE_DANS_LE_COLLEGE_OU_LA_CATEGORIE_PROFESSIONNELLE = (
        "03"  # Ancienneté dans le collège ou la catégorie professionnelle
    )
    ANCIENNETE_DANS_LE_POSTE = "04"  # Ancienneté dans le poste
    ANCIENNETE_DANS_LE_GROUPE = "06"  # Ancienneté dans le groupe
    ANCIENNETE_DANS_L_ENTREPRISE = "07"  # Ancienneté dans l'entreprise

    __DESCRIPTIONS: dict[str, str] = {
        "02": "Anciennet\u00e9 dans la branche professionnelle ou le secteur d\u0027activit\u00e9",
        "03": "Anciennet\u00e9 dans le coll\u00e8ge ou la cat\u00e9gorie professionnelle",
        "04": "Anciennet\u00e9 dans le poste",
        "06": "Anciennet\u00e9 dans le groupe",
        "07": "Anciennet\u00e9 dans l\u0027entreprise",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Anciennete_Unite_Mesure(str, Enum):
    JOURS = "01"  # Jours
    MOIS = "02"  # Mois
    ANNEES = "03"  # Années

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Jours",
        "02": "Mois",
        "03": "Ann\u00e9es",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Salarie_temps_partiel(str, Enum):
    POUR_LA_VIEILLESSE_REGIME_DE_BASE = "01"  # pour la vieillesse régime de base
    POUR_LA_VIEILLESSE_REGIME_DE_BASE_ET_LA_RETRAITE_COMPLEMENTAIRE = (
        "02"  # pour la vieillesse régime de base et la retraite complémentaire
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "pour la vieillesse r\u00e9gime de base",
        "02": "pour la vieillesse r\u00e9gime de base et la retraite compl\u00e9mentaire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Remuneration_Pourboire(str, Enum):
    OUI = "01"  # oui

    __DESCRIPTIONS: dict[str, str] = {
        "01": "oui",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Emplois_Multiples(str, Enum):
    EMPLOI_UNIQUE = "01"  # emploi unique
    EMPLOIS_MULTIPLES = "02"  # emplois multiples
    SITUATION_NON_CONNUE = "03"  # situation non connue

    __DESCRIPTIONS: dict[str, str] = {
        "01": "emploi unique",
        "02": "emplois multiples",
        "03": "situation non connue",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Employeur_Multiples(str, Enum):
    EMPLOYEUR_UNIQUE = "01"  # employeur unique
    EMPLOYEURS_MULTIPLES = "02"  # employeurs multiples
    SITUATION_NON_CONNUE = "03"  # situation non connue

    __DESCRIPTIONS: dict[str, str] = {
        "01": "employeur unique",
        "02": "employeurs multiples",
        "03": "situation non connue",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Statut_Categoriel_APECITA(str, Enum):
    SALARIE_CADRE = "01"  # salarié cadre
    SALARIE_NON_CADRE = "02"  # salarié non cadre

    __DESCRIPTIONS: dict[str, str] = {
        "01": "salari\u00e9 cadre",
        "02": "salari\u00e9 non cadre",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Devise_Paiement(str, Enum):
    EURO = "01"  # euro
    FRANC_PACIFIQUE = "02"  # franc Pacifique

    __DESCRIPTIONS: dict[str, str] = {
        "01": "euro",
        "02": "franc Pacifique",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_NatureEvenementDeclencheurSignalement(str, Enum):
    EMBAUCHE_EFFECTIVE_DE_L_INDIVIDU = "01"  # Embauche effective de l'individu
    MUTATION_DE_L_INDIVIDU_SANS_RUPTURE_DU_CONTRAT_DE_TRAVAIL = (
        "02"  # Mutation de l'individu sans rupture du contrat de travail
    )
    FIN_DE_DISPENSE_D_AFFILIATION = "03"  # Fin de dispense d’affiliation
    CHANGEMENT_DES_PARAMETRES_SALARIE_DU_CONTRAT_COLLECTIF_PREVOYANCE_SANTE_COMPLEMENTAIRE_RETRAITE_SUPPLEMENTAIRE = "04"  # Changement des paramètres salarié du contrat collectif prévoyance, santé complémentaire, retraite supplémentaire
    TRANSMISSION_DE_L_ENSEMBLE_D_UNE_POPULATION_A_AFFILIER_A_UN_NOUVEAU_CONTRAT_INDIVIDU_FAISANT_PARTIE_D_UNE_POPULATION_A_AFFILIER_A_UN_NOUVEAU_CONTRAT = "05"  # Transmission de l’ensemble d’une population à affilier à un nouveau contrat (individu faisant partie d’une population à affilier à un nouveau contrat)
    APPEL_DE_TAUX_DE_PAS_POUR_UN_INDIVIDU_NON_SALARIE = (
        "06"  # Appel de taux de PAS pour un individu non salarié
    )
    CHANGEMENT_DE_TIERS_DECLARANT_OU_CHANGEMENT_DE_LOGICIEL_DECLARATIF = (
        "07"  # Changement de tiers déclarant ou changement de logiciel déclaratif
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Embauche effective de l\u0027individu",
        "02": "Mutation de l\u0027individu sans rupture du contrat de travail",
        "03": "Fin de dispense d\u2019affiliation",
        "04": "Changement des param\u00e8tres salari\u00e9 du contrat collectif pr\u00e9voyance, sant\u00e9 compl\u00e9mentaire, retraite suppl\u00e9mentaire",
        "05": "Transmission de l\u2019ensemble d\u2019une population \u00e0 affilier \u00e0 un nouveau contrat (individu faisant partie d\u2019une population \u00e0 affilier \u00e0 un nouveau contrat)",
        "06": "Appel de taux de PAS pour un individu non salari\u00e9",
        "07": "Changement de tiers d\u00e9clarant ou changement de logiciel d\u00e9claratif",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Implantation_Entreprise(str, Enum):
    ENTREPRISE_ETRANGERE_AVEC_ETABLISSEMENT_EN_FRANCE = (
        "01"  # Entreprise étrangère avec établissement en France
    )
    ENTREPRISE_ETRANGERE_HORS_UE_SANS_ETABLISSEMENT_EN_FRANCE = (
        "02"  # Entreprise étrangère hors UE sans établissement en France
    )
    ENTREPRISE_ETRANGERE_DANS_L_UE_SANS_ETABLISSEMENT_EN_FRANCE = (
        "03"  # Entreprise étrangère dans l’UE sans établissement en France
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Entreprise \u00e9trang\u00e8re avec \u00e9tablissement en France",
        "02": "Entreprise \u00e9trang\u00e8re hors UE sans \u00e9tablissement en France",
        "03": "Entreprise \u00e9trang\u00e8re dans l\u2019UE sans \u00e9tablissement en France",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Type_Gestion_Assu_Chomage(str, Enum):
    EMPLOYEUR_EN_AUTO_ASSURANCE = "01"  # employeur en auto-assurance
    EMPLOYEUR_AYANT_CONCLU_UNE_CONVENTION_DE_GESTION = (
        "02"  # employeur ayant conclu une convention de gestion
    )
    EMPLOYEUR_AYANT_ADHERE_AU_REGIME_D_ASSURANCE_CHOMAGE_ADHESION_REVOCABLE = (
        "03"  # employeur ayant adhéré au régime d'Assurance chômage (adhésion révocable)
    )
    EMPLOYEUR_AYANT_ADHERE_AU_REGIME_D_ASSURANCE_CHOMAGE_ADHESION_NON_REVOCABLE = (
        "04"  # employeur ayant adhéré au régime d'Assurance chômage (adhésion non révocable)
    )
    ADHESION_AU_REGIME_PARTICULIER_POUR_LES_APPRENTIS_DU_SECTEUR_PUBLIC = (
        "05"  # adhésion au régime particulier pour les apprentis du secteur public
    )
    AFFILIATION_AU_REGIME_D_ASSURANCE_CHOMAGE_POUR_UN_CONTRAT_D_EMPLOI_PENITENTIAIRE = (
        "06"  # affiliation au régime d’Assurance chômage pour un contrat d’emploi pénitentiaire
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "employeur en auto-assurance",
        "02": "employeur ayant conclu une convention de gestion",
        "03": "employeur ayant adh\u00e9r\u00e9 au r\u00e9gime d\u0027Assurance ch\u00f4mage (adh\u00e9sion r\u00e9vocable)",
        "04": "employeur ayant adh\u00e9r\u00e9 au r\u00e9gime d\u0027Assurance ch\u00f4mage (adh\u00e9sion non r\u00e9vocable)",
        "05": "adh\u00e9sion au r\u00e9gime particulier pour les apprentis du secteur public",
        "06": "affiliation au r\u00e9gime d\u2019Assurance ch\u00f4mage pour un contrat d\u2019emploi p\u00e9nitentiaire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Alsace_Moselle(str, Enum):
    OUI = "01"  # Oui

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Oui",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Ayant_Droit_Type(str, Enum):
    ADULTE_CONJOINT_CONCUBIN_PACS = "01"  # adulte (conjoint, concubin, pacs)
    ENFANT = "02"  # enfant
    AUTRE_ASCENDANT_COLLATERAUX = "03"  # autre (ascendant, collatéraux, …)

    __DESCRIPTIONS: dict[str, str] = {
        "01": "adulte (conjoint, concubin, pacs)",
        "02": "enfant",
        "03": "autre (ascendant, collat\u00e9raux, \u2026)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Penibilite_Facteur_Exposition(str, Enum):
    LES_ACTIVITES_EXERCEES_EN_MILIEU_HYPERBARE = "05"  # les activités exercées en milieu hyperbare
    LES_TEMPERATURES_EXTREMES = "06"  # les températures extrêmes
    LE_BRUIT = "07"  # le bruit
    LE_TRAVAIL_DE_NUIT = "08"  # le travail de nuit
    LE_TRAVAIL_EN_EQUIPES_SUCCESSIVES_ALTERNANTES = (
        "09"  # le travail en équipes successives alternantes
    )
    LE_TRAVAIL_REPETITIF_REPETITION_D_UN_MEME_GESTE_A_UNE_CADENCE_CONTRAINTE_AVEC_UN_TEMPS_DE_CYCLE_DEFINI = "10"  # le travail répétitif (répétition d'un même geste, à une cadence contrainte avec un temps de cycle défini)
    ANNULATION = "99"  # annulation

    __DESCRIPTIONS: dict[str, str] = {
        "05": "les activit\u00e9s exerc\u00e9es en milieu hyperbare",
        "06": "les temp\u00e9ratures extr\u00eames",
        "07": "le bruit",
        "08": "le travail de nuit",
        "09": "le travail en \u00e9quipes successives alternantes",
        "10": "le travail r\u00e9p\u00e9titif (r\u00e9p\u00e9tition d\u0027un m\u00eame geste, \u00e0 une cadence contrainte avec un temps de cycle d\u00e9fini)",
        "99": "annulation",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Contexte(str, Enum):
    OUI = "01"  # oui
    NON = "02"  # non

    __DESCRIPTIONS: dict[str, str] = {
        "01": "oui",
        "02": "non",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Etablissement_Nature_Juridique(str, Enum):
    PRIVEE = "01"  # Privée
    PUBLIQUE = "02"  # Publique
    ETABLISSEMENT_PRIVE_A_CAPITAUX_MAJORITAIRES_PUBLICS = (
        "03"  # Etablissement privé à capitaux majoritaires publics
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Priv\u00e9e",
        "02": "Publique",
        "03": "Etablissement priv\u00e9 \u00e0 capitaux majoritaires publics",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Delegataire_Risque_Maladie(str, Enum):
    MGEN_SECTION_EXTRA_METROPOLITAINE = "501"  # MGEN - Section Extra-Métropolitaine
    MAGE_CPAM75_MUTUELLE_AUTONOME_GENERALE_DE_L_EDUCATION = (
        "505"  # MAGE - CPAM75 - Mutuelle autonome générale de l'éducation
    )
    MGEN = "506"  # MGEN
    MG_MUTUELLE_GENERALE = "512"  # MG - Mutuelle Générale
    MNAM_MUTUELLE_NATIONALE_AVIATION_MARINE = "516"  # MNAM - Mutuelle Nationale Aviation Marine
    MCF_MUTUELLE_CENTRALE_DES_FINANCES = "523"  # MCF - Mutuelle Centrale des Finances
    MUTUELLE_DES_RELATIONS_EXTERIEURES_MAE = "533"  # Mutuelle des Relations Extérieures (MAE)
    MGP_MUTUELLE_GENERALE_DE_LA_POLICE = "537"  # MGP - Mutuelle Générale de la Police
    SMPPN_SOCIETE_MUTUALISTE_DU_PERSONNEL_DE_LA_POLICE_NATIONALE = (
        "555"  # SMPPN - Société Mutualiste du Personnel de la Police Nationale
    )
    MFP_MUTUELLE_DE_LA_FONCTION_PUBLIQUE_ET_MGAS_MUTUELLE_GENERALE_DES_AFFAIRES_SOCIALES = "599"  # MFP - Mutuelle de la fonction publique et MGAS - Mutuelle Générale des Affaires Sociales
    LMDE_LA_MUTUELLE_DES_ETUDIANTS = "601"  # LMDE - La Mutuelle des Étudiants
    MCVPAP_MUTUELLE_COMPLEMENTAIRE_DE_LA_VILLE_DE_PARIS_DE_L_ASSISTANCE_PUBLIQUE_ET_DES_ADMINISTRATIONS_ANNEXES = "602"  # MCVPAP - Mutuelle Complémentaire de la Ville de Paris. de l'Assistance Publique et des Administrations Annexes
    MMI_MUTUELLE_DU_MINISTERE_DE_L_INTERIEUR_ET_MPN_MUTUELLE_DE_LA_POLICE_NATIONALE_DE_STRASBOURG = "604"  # MMI - Mutuelle du Ministère de l'Intérieur et MPN- Mutuelle de la Police Nationale de Strasbourg
    MNFCT_MUTUELLE_NATIONALE_DES_FONCTIONNAIRES_DES_COLLECTIVITES_TERRITORIALES = (
        "606"  # MNFCT - Mutuelle Nationale des fonctionnaires des collectivités territoriales
    )
    SLTC_TRANSPORTS_EN_COMMUN_DE_LYON = "607"  # SLTC -Transports en Commun de Lyon
    MNT_MUTUELLE_NATIONALE_TERRITORIALE = "609"  # MNT- Mutuelle Nationale Territoriale
    HCL_HOSPICES_CIVILS_DE_LYON = "610"  # HCL - Hospices Civils de Lyon
    UPBTP_BATIMENTS_ET_TRAVAUX_PUBLICS_DE_LYON_ET_MUTUELLE_BOISSIERE_DU_BATIMENT_DIEPPE_ET_ROUEN = "612"  # UPBTP - Bâtiments et Travaux Publics de Lyon et Mutuelle Boissière du Bâtiment (Dieppe et Rouen)
    MGAT_CHARTRES_ET_MUTAME_NANTES_MUTUELLE_DES_PERSONNELS_MUNICIPAUX = (
        "613"  # MGAT Chartres et MUTAME Nantes - Mutuelle des Personnels municipaux
    )
    MICILS_UMIGA_SOGIREL_UPES_MUTUELLE_INTERPROFESSIONNELLE_DES_CADRES_INGENIEURS_DE_LA_REGION_LYONNAISE_ET_STEPHANOISE = "614"  # MICILS - UMIGA SOGIREL. UPES - Mutuelle Interprofessionnelle des Cadres. Ingénieurs de la région Lyonnaise et stéphanoise
    MUTUELLE_DE_MUNICIPAUX_DE_MARSEILLE = "616"  # Mutuelle de municipaux de Marseille
    SOCIETES_D_ETUDIANTS_MUTUALISTES_SMEBA_SMERRA_SMESO_SMENO_MEP_MGEL_SMEREB_SMECO_SMEREP_SMERE = "617"  # Sociétés d'Étudiants Mutualistes (SMEBA - SMERRA - SMESO - SMENO - MEP - MGEL – SMEREB - SMECO - SMEREP - SMERE)
    VITTAVI_POUR_DOM = "618"  # VITTAVI pour DOM
    MNH_MUTUELLE_NATIONALE_DES_HOSPITALIER_Y_COMPRIS_CERTAINES_MUTUELLES_DES_PERSONNELS_MUNICIPAUX = "619"  # MNH - Mutuelle Nationale des Hospitalier, y compris certaines mutuelles des personnels municipaux
    MUTUELLE_DES_PERSONNELS_MUNICIPAUX_ET_HOSPITALIERS_DE_TOURS_MULHOUSE_POITIERS = (
        "651"  # Mutuelle des Personnels Municipaux et Hospitaliers de Tours. Mulhouse. Poitiers
    )
    COVIMUT_POITIERS_TRANSPORTS_EN_COMMUN = "652"  # COVIMUT - Poitiers (Transports en commun)
    MUTUELLE_DE_LA_MAIRIE_DE_TOULOUSE_CGFTE_BORDEAUX_TRANSPORTS_EN_COMMUN = (
        "654"  # Mutuelle de la Mairie de Toulouse CGFTE - Bordeaux (Transports en commun)
    )
    MUTUELLE_DE_L_EST_SECTION_DE_STRASBOURG = "689"  # Mutuelle de l'Est - Section de Strasbourg
    CAISSE_DE_BRANCHE_FERROVIAIRE = "908"  # Caisse de branche ferroviaire

    __DESCRIPTIONS: dict[str, str] = {
        "501": "MGEN - Section Extra-M\u00e9tropolitaine",
        "505": "MAGE - CPAM75 - Mutuelle autonome g\u00e9n\u00e9rale de l\u0027\u00e9ducation",
        "506": "MGEN",
        "512": "MG - Mutuelle G\u00e9n\u00e9rale",
        "516": "MNAM - Mutuelle Nationale Aviation Marine",
        "523": "MCF - Mutuelle Centrale des Finances",
        "533": "Mutuelle des Relations Ext\u00e9rieures (MAE)",
        "537": "MGP - Mutuelle G\u00e9n\u00e9rale de la Police",
        "555": "SMPPN - Soci\u00e9t\u00e9 Mutualiste du Personnel de la Police Nationale",
        "599": "MFP - Mutuelle de la fonction publique et MGAS - Mutuelle G\u00e9n\u00e9rale des Affaires Sociales",
        "601": "LMDE - La Mutuelle des \u00c9tudiants",
        "602": "MCVPAP - Mutuelle Compl\u00e9mentaire de la Ville de Paris. de l\u0027Assistance Publique et des Administrations Annexes",
        "604": "MMI - Mutuelle du Minist\u00e8re de l\u0027Int\u00e9rieur et MPN- Mutuelle de la Police Nationale de Strasbourg",
        "606": "MNFCT - Mutuelle Nationale des fonctionnaires des collectivit\u00e9s territoriales",
        "607": "SLTC -Transports en Commun de Lyon",
        "609": "MNT- Mutuelle Nationale Territoriale",
        "610": "HCL - Hospices Civils de Lyon",
        "612": "UPBTP - B\u00e2timents et Travaux Publics de Lyon et Mutuelle Boissi\u00e8re du B\u00e2timent (Dieppe et Rouen)",
        "613": "MGAT Chartres et MUTAME Nantes - Mutuelle des Personnels municipaux",
        "614": "MICILS - UMIGA SOGIREL. UPES - Mutuelle Interprofessionnelle des Cadres. Ing\u00e9nieurs de la r\u00e9gion Lyonnaise et st\u00e9phanoise",
        "616": "Mutuelle de municipaux de Marseille",
        "617": "Soci\u00e9t\u00e9s d\u0027\u00c9tudiants Mutualistes (SMEBA - SMERRA - SMESO - SMENO - MEP - MGEL \u2013 SMEREB - SMECO - SMEREP - SMERE)",
        "618": "VITTAVI pour DOM",
        "619": "MNH - Mutuelle Nationale des Hospitalier, y compris certaines mutuelles des personnels municipaux",
        "651": "Mutuelle des Personnels Municipaux et Hospitaliers de Tours. Mulhouse. Poitiers",
        "652": "COVIMUT - Poitiers (Transports en commun)",
        "654": "Mutuelle de la Mairie de Toulouse CGFTE - Bordeaux (Transports en commun)",
        "689": "Mutuelle de l\u0027Est - Section de Strasbourg",
        "908": "Caisse de branche ferroviaire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Codification_UE(str, Enum):
    FRANCE = "01"  # France
    UE = "02"  # UE
    EEE = "03"  # EEE
    RESTE_DU_MONDE = "04"  # Reste du Monde

    __DESCRIPTIONS: dict[str, str] = {
        "01": "France",
        "02": "UE",
        "03": "EEE",
        "04": "Reste du Monde",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_ActionsGratuites_Code_Contexte(str, Enum):
    OUI = "01"  # oui
    NON = "02"  # non

    __DESCRIPTIONS: dict[str, str] = {
        "01": "oui",
        "02": "non",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_VehiculeTechnique_Code_Modalite_Indemnite(str, Enum):
    ALLOCATIONS_FORFAITAIRES = "01"  # allocations forfaitaires
    REMBOURSEMENT = "02"  # remboursement
    PRISE_EN_CHARGE_PAR_L_EMPLOYEUR = "03"  # prise en charge par l'employeur

    __DESCRIPTIONS: dict[str, str] = {
        "01": "allocations forfaitaires",
        "02": "remboursement",
        "03": "prise en charge par l\u0027employeur",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_VehiculeTechnique_Code_Type_Avantage_Nature(str, Enum):
    NOURRITURE = "01"  # nourriture
    LOGEMENT = "02"  # logement
    VOITURE = "03"  # voiture
    NOUVELLES_TECHNOLOGIES_DE_L_INFORMATIQUE_ET_DE_LA_COMMUNICATION = (
        "04"  # nouvelles technologies de l'Informatique et de la Communication
    )
    AUTRE_AVANTAGE = "09"  # autre avantage

    __DESCRIPTIONS: dict[str, str] = {
        "01": "nourriture",
        "02": "logement",
        "03": "voiture",
        "04": "nouvelles technologies de l\u0027Informatique et de la Communication",
        "09": "autre avantage",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_VehiculeTechnique_Code_Taux_Reduit_Dispense(str, Enum):
    DISPENSE_DE_RETENUE_A_LA_SOURCE = "D"  # dispense de retenue à la source
    TAUX_REDUIT_DE_RETENUE_A_LA_SOURCE = "R"  # taux réduit de retenue à la source

    __DESCRIPTIONS: dict[str, str] = {
        "D": "dispense de retenue \u00e0 la source",
        "R": "taux r\u00e9duit de retenue \u00e0 la source",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_CodeStatutCategorielAPECITA(str, Enum):
    SALARIE_CADRE = "01"  # salarié cadre
    SALARIE_NON_CADRE = "02"  # salarié non cadre
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "salari\u00e9 cadre",
        "02": "salari\u00e9 non cadre",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_TravailleurEtranger(str, Enum):
    DETACHE = "01"  # Détaché
    EXPATRIE = "02"  # Expatrié
    FRONTALIER = "03"  # Frontalier
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "D\u00e9tach\u00e9",
        "02": "Expatri\u00e9",
        "03": "Frontalier",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_ContactDeclare_type(str, Enum):
    CONTACT_CHEZ_LE_DECLARE_POUR_LES_IJ = "01"  # Contact chez le déclaré pour les IJ
    CONTACT_CHEZ_LE_DECLARE_POUR_LES_FINS_DE_CONTRATS_DE_TRAVAIL_FRANCE_TRAVAIL = (
        "02"  # Contact chez le déclaré pour les fins de contrats de travail (France Travail)
    )
    CONTACT_CHEZ_LE_DECLARE_POUR_LES_ACTEURS_STATISTIQUES_DARES_INSEE_ETC = (
        "03"  # Contact chez le déclaré pour les acteurs statistiques (DARES, INSEE, etc …)
    )
    CONTACT_CHEZ_LE_DECLARE_RECOUVRANT_ENTRE_AUTRES_DES_COTISATIONS_DE_SECURITE_SOCIALE_URSSAF_CN_MSA_ET_CONTRIBUTIONS_ASSURANCE_CHOMAGE_ET_COTISATIONS_AGS_FRANCE_TRAVAIL = "04"  # Contact chez le déclaré recouvrant, entre autres, des cotisations de Sécurité Sociale (Urssaf CN, MSA) et contributions assurance chômage et cotisations AGS (France Travail)
    CONTACT_CHEZ_LE_DECLARE_POUR_LE_RECOUVREMENT_DES_COTISATIONS_RETRAITE_COMPLEMENTAIRE_ET_AUTRES = "05"  # Contact chez le déclaré pour le recouvrement des cotisations (retraite complémentaire et autres)
    CONTACT_SUR_L_IDENTIFICATION_DES_SALARIES_NIR = (
        "06"  # Contact sur l’identification des salariés (NIR)
    )
    CONTACT_SUR_L_IDENTIFICATION_DE_L_ETABLISSEMENT_SIRET = (
        "07"  # Contact sur l’identification de l’établissement (SIRET)
    )
    CONTEXTUALISABLE_A_L_ENSEMBLE_DES_ORGANISMES_HORS_TYPOLOGIES_1_A_7_ET_9 = (
        "08"  # Contextualisable à l’ensemble des organismes, hors typologies 1 à 7, et 9
    )
    CONTACT_CHEZ_L_ETABLISSEMENT_CENTRALISATEUR_POUR_LES_IJ = (
        "09"  # Contact chez l'établissement centralisateur pour les IJ
    )
    CONTACT_CHEZ_LE_DECLARE_POUR_LES_AIDES_VERSEES_PAR_L_ASP = (
        "13"  # Contact chez le déclaré pour les aides versées par l'ASP
    )
    CONTACT_CHEZ_LE_DECLARE_POUR_LE_SUIVI_DES_TRAVAILLEURS_HANDICAPES = (
        "14"  # Contact chez le déclaré pour le suivi des travailleurs handicapés
    )
    CONTACT_POUR_LES_CONGES_PAYES_CIBTP_TRANSPORT_MANUTENTION_PORTUAIRE = (
        "15"  # Contact pour les congés payés (CIBTP, Transport, Manutention portuaire)
    )
    CONTACT_CHEZ_LE_DECLARE_POUR_LA_FORMATION_PROFESSIONNELLE = (
        "16"  # Contact chez le déclaré pour la formation professionnelle
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Contact chez le d\u00e9clar\u00e9 pour les IJ",
        "02": "Contact chez le d\u00e9clar\u00e9 pour les fins de contrats de travail (France Travail)",
        "03": "Contact chez le d\u00e9clar\u00e9 pour les acteurs statistiques (DARES, INSEE, etc \u2026)",
        "04": "Contact chez le d\u00e9clar\u00e9 recouvrant, entre autres, des cotisations de S\u00e9curit\u00e9 Sociale (Urssaf CN, MSA) et contributions assurance ch\u00f4mage et cotisations AGS (France Travail)",
        "05": "Contact chez le d\u00e9clar\u00e9 pour le recouvrement des cotisations (retraite compl\u00e9mentaire et autres)",
        "06": "Contact sur l\u2019identification des salari\u00e9s (NIR)",
        "07": "Contact sur l\u2019identification de l\u2019\u00e9tablissement (SIRET)",
        "08": "Contextualisable \u00e0 l\u2019ensemble des organismes, hors typologies 1 \u00e0 7, et 9",
        "09": "Contact chez l\u0027\u00e9tablissement centralisateur pour les IJ",
        "13": "Contact chez le d\u00e9clar\u00e9 pour les aides vers\u00e9es par l\u0027ASP",
        "14": "Contact chez le d\u00e9clar\u00e9 pour le suivi des travailleurs handicap\u00e9s",
        "15": "Contact pour les cong\u00e9s pay\u00e9s (CIBTP, Transport, Manutention portuaire)",
        "16": "Contact chez le d\u00e9clar\u00e9 pour la formation professionnelle",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_IndividuAgircArrco_StatutConventionnel(str, Enum):
    CADRE_DIRIGEANT_VOTANT_AU_COLLEGE_EMPLOYEUR_DES_ELECTIONS_PRUD_HOMALES = (
        "03"  # cadre dirigeant (votant au collège employeur des élections prud'homales)
    )
    AUTRES_CADRES_AU_SENS_DE_LA_CONVENTION_COLLECTIVE_OU_DU_STATUT_POUR_LES_REGIMES_SPECIAUX = "04"  # autres cadres au sens de la convention collective (ou du statut pour les régimes spéciaux)
    PROFESSION_INTERMEDIAIRE_TECHNICIEN_CONTREMAITRE_AGENT_DE_MAITRISE_CLERGE = (
        "05"  # profession intermédiaire (technicien, contremaître, agent de maîtrise, clergé)
    )
    EMPLOYE_ADMINISTRATIF_D_ENTREPRISE_DE_COMMERCE_AGENT_DE_SERVICE = (
        "06"  # employé administratif d'entreprise, de commerce, agent de service
    )
    OUVRIERS_QUALIFIES_ET_NON_QUALIFIES_Y_COMPRIS_OUVRIERS_AGRICOLES = (
        "07"  # ouvriers qualifiés et non qualifiés y compris ouvriers agricoles
    )
    AGENT_DE_LA_FONCTION_PUBLIQUE_D_ETAT = "08"  # agent de la fonction publique d'Etat
    INDIVIDU_NON_CONCERNE = "99"  # individu non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "03": "cadre dirigeant (votant au coll\u00e8ge employeur des \u00e9lections prud\u0027homales)",
        "04": "autres cadres au sens de la convention collective (ou du statut pour les r\u00e9gimes sp\u00e9ciaux)",
        "05": "profession interm\u00e9diaire (technicien, contrema\u00eetre, agent de ma\u00eetrise, clerg\u00e9)",
        "06": "employ\u00e9 administratif d\u0027entreprise, de commerce, agent de service",
        "07": "ouvriers qualifi\u00e9s et non qualifi\u00e9s y compris ouvriers agricoles",
        "08": "agent de la fonction publique d\u0027Etat",
        "99": "individu non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_IndividuAgircArrco_StatutRetraiteComplementaire(str, Enum):
    CADRE_ARTICLE_4_ET_4BIS = "01"  # cadre (article 4 et 4bis)
    EXTENSION_CADRE_POUR_RETRAITE_COMPLEMENTAIRE = (
        "02"  # extension cadre pour retraite complémentaire
    )
    NON_CADRE = "04"  # non cadre
    SANS_STATUT_CATEGORIEL = "10"  # sans statut catégoriel

    __DESCRIPTIONS: dict[str, str] = {
        "01": "cadre (article 4 et 4bis)",
        "02": "extension cadre pour retraite compl\u00e9mentaire",
        "04": "non cadre",
        "10": "sans statut cat\u00e9goriel",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_BasesSpecifiqueAgircArrco_Type(str, Enum):
    ALLOCATION_DE_CHOMAGE_POUR_LES_ENTREPRISES_EN_AUTO_ASSURANCE_CHOMAGE = (
        "01"  # Allocation de chômage pour les entreprises en auto-assurance chômage
    )
    ALLOCATION_DE_CESSATION_ANTICIPEE_D_ACTIVITE_AMIANTE = (
        "02"  # Allocation de cessation anticipée d'activité Amiante
    )
    ALLOCATION_DE_PRE_RETRAITE_SUITE_A_RUPTURE_DU_CONTRAT = (
        "03"  # Allocation de pré-retraite suite à rupture du contrat
    )
    SOMME_VERSEE_A_UN_TIERS = "05"  # Somme versée à un tiers
    MONTANT_VERSE_A_UN_BENEFICIAIRE_NE_RELEVANT_PAS_DES_REGLES_DE_SECURITE_SOCIALE_EN_FRANCE_MAIS_QUI_EST_IMPOSABLE = "06"  # Montant versé à un bénéficiaire ne relevant pas des règles de sécurité sociale en France mais qui est imposable
    ALLOCATION_DE_PRE_RETRAITE_SANS_RUPTURE_DE_CONTRAT = (
        "07"  # Allocation de pré-retraite sans rupture de contrat
    )
    MONTANT_DE_RETRAITE_VERSEE_PAR_L_EMPLOYEUR = "08"  # Montant de retraite versée par l'employeur
    PENSIONS_D_INVALIDITE = "09"  # Pensions d'invalidité

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Allocation de ch\u00f4mage pour les entreprises en auto-assurance ch\u00f4mage",
        "02": "Allocation de cessation anticip\u00e9e d\u0027activit\u00e9 Amiante",
        "03": "Allocation de pr\u00e9-retraite suite \u00e0 rupture du contrat",
        "05": "Somme vers\u00e9e \u00e0 un tiers",
        "06": "Montant vers\u00e9 \u00e0 un b\u00e9n\u00e9ficiaire ne relevant pas des r\u00e8gles de s\u00e9curit\u00e9 sociale en France mais qui est imposable",
        "07": "Allocation de pr\u00e9-retraite sans rupture de contrat",
        "08": "Montant de retraite vers\u00e9e par l\u0027employeur",
        "09": "Pensions d\u0027invalidit\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_BasesSpecifiqueAgircArrco_CodeBaseSpecifique(str, Enum):
    BASE_EXCEPTIONNELLE_AGIRC_ARRCO = "23"  # Base exceptionnelle Agirc Arrco
    BASE_PLAFONNEE_EXCEPTIONNELLE_AGIRC_ARRCO = "43"  # Base plafonnée exceptionnelle Agirc Arrco
    ASSIETTE_BRUTE_DEPLAFONNEE = "50"  # Assiette brute déplafonnée
    ASSIETTE_BRUTE_PLAFONNEE = "51"  # Assiette brute plafonnée
    ASSIETTE_DE_LA_CONTRIBUTION_LIBERATOIRE = "52"  # Assiette de la contribution libératoire
    ASSIETTE_DE_LA_CONTRIBUTION_SOCIALE_GENERALISEE = (
        "53"  # Assiette de la contribution sociale généralisée
    )

    __DESCRIPTIONS: dict[str, str] = {
        "23": "Base exceptionnelle Agirc Arrco",
        "43": "Base plafonn\u00e9e exceptionnelle Agirc Arrco",
        "50": "Assiette brute d\u00e9plafonn\u00e9e",
        "51": "Assiette brute plafonn\u00e9e",
        "52": "Assiette de la contribution lib\u00e9ratoire",
        "53": "Assiette de la contribution sociale g\u00e9n\u00e9ralis\u00e9e",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Modatite_FC(str, Enum):
    APPLICATION_DU_CIRCUIT_DEROGATOIRE = "01"  # Application du circuit dérogatoire
    NON_APPLICATION_DU_CIRCUIT_DEROGATOIRE = "02"  # Non application du circuit dérogatoire

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Application du circuit d\u00e9rogatoire",
        "02": "Non application du circuit d\u00e9rogatoire",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class AncienNaturePoste(str, Enum):
    FP_TEMPS_COMPLET = "01"  # [FP] Temps complet
    FP_TEMPS_NON_COMPLET = "02"  # [FP] Temps non complet
    REGIME_VSDL_WEEK_ENDISTE = "03"  # Régime VSDL (Week-endiste)
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] Temps complet",
        "02": "[FP] Temps non complet",
        "03": "R\u00e9gime VSDL (Week-endiste)",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class FPTypeDetachement(str, Enum):
    FP_DETACHEMENT_AUPRES_D_UN_PARLEMENTAIRE = "01"  # [FP] Détachement auprès d'un parlementaire
    FP_DETACHEMENT_SUR_UN_EMPLOI_DE_COLLABORATEUR_CABINET = (
        "02"  # [FP] Détachement sur un emploi de collaborateur cabinet
    )
    FP_DETACHEMENT_AU_TITRE_DE_LA_COOPERATION_TECHNIQUE = (
        "03"  # [FP] Détachement au titre de la coopération technique
    )
    FP_DETACHEMENT_SUR_UN_EMPLOI_FONCTIONNEL = "05"  # [FP] Détachement sur un emploi fonctionnel
    FP_DETACHEMENT_POUR_FONCTION_ELECTIVE_OU_MANDAT_SYNDICAL = (
        "06"  # [FP] Détachement pour fonction élective ou mandat syndical
    )
    FP_DETACHEMENT_POUR_EXERCER_UN_MANDAT_DE_DEPUTE = (
        "07"  # [FP] Détachement pour exercer un mandat de député
    )
    FP_DETACHEMENT_POUR_EXERCER_UN_MANDAT_DE_SENATEUR = (
        "08"  # [FP] Détachement pour exercer un mandat de sénateur
    )
    FP_DETACHEMENT_RECLASSEMENT_POUR_DIFFICULTES_OPERATIONNELLES = (
        "09"  # [FP] Détachement (reclassement) pour difficultés opérationnelles
    )
    FP_DETACHEMENT_RECLASSEMENT_POUR_RAISON_OPERATIONNELLE = (
        "10"  # [FP] Détachement (reclassement) pour raison opérationnelle
    )
    FP_DETACHEMENT_AUPRES_D_UN_ORGANISME_DE_DROIT_PRIVE_D_UN_EPIC_OU_D_UN_GIP = (
        "11"  # [FP] Détachement auprès d'un organisme de droit privé, d'un EPIC ou d'un GIP
    )
    FP_DETACHEMENT_AUPRES_D_UN_ETABLISSEMENT_PUBLIC_NATIONAL = (
        "12"  # [FP] Détachement auprès d'un établissement public national
    )
    FP_DETACHEMENT_AUPRES_D_UNE_COLLECTIVITE_OU_D_UN_ETABLISSEMENT_PUBLIC_TERRITORIAL_OU_HOSPITALIER = "13"  # [FP] Détachement auprès d'une collectivité ou d’un établissement public territorial ou hospitalier
    FP_DETACHEMENT_AUPRES_DE_L_ETAT = "15"  # [FP] Détachement auprès de l’Etat

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] D\u00e9tachement aupr\u00e8s d\u0027un parlementaire",
        "02": "[FP] D\u00e9tachement sur un emploi de collaborateur cabinet",
        "03": "[FP] D\u00e9tachement au titre de la coop\u00e9ration technique",
        "05": "[FP] D\u00e9tachement sur un emploi fonctionnel",
        "06": "[FP] D\u00e9tachement pour fonction \u00e9lective ou mandat syndical",
        "07": "[FP] D\u00e9tachement pour exercer un mandat de d\u00e9put\u00e9",
        "08": "[FP] D\u00e9tachement pour exercer un mandat de s\u00e9nateur",
        "09": "[FP] D\u00e9tachement (reclassement) pour difficult\u00e9s op\u00e9rationnelles",
        "10": "[FP] D\u00e9tachement (reclassement) pour raison op\u00e9rationnelle",
        "11": "[FP] D\u00e9tachement aupr\u00e8s d\u0027un organisme de droit priv\u00e9, d\u0027un EPIC ou d\u0027un GIP",
        "12": "[FP] D\u00e9tachement aupr\u00e8s d\u0027un \u00e9tablissement public national",
        "13": "[FP] D\u00e9tachement aupr\u00e8s d\u0027une collectivit\u00e9 ou d\u2019un \u00e9tablissement public territorial ou hospitalier",
        "15": "[FP] D\u00e9tachement aupr\u00e8s de l\u2019Etat",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class FPCodeCategorieService(str, Enum):
    FP_EMPLOI_SERVICE_SEDENTAIRE = "01"  # [FP] Emploi service sédentaire
    FP_EMPLOI_SERVICE_ACTIF = "02"  # [FP] Emploi service actif
    FP_EMPLOI_A_PLUS_DE_800_HEURES_ANNUELLES_DANS_LES_RESEAUX_SOUTERRAINS_ET_LES_OUVRAGES_ANNEXES_HOMOLOGUES = "03"  # [FP] Emploi à plus de 800 heures annuelles dans les réseaux souterrains et les ouvrages annexes homologués
    FP_EMPLOI_DANS_LE_CORPS_DES_IDENTIFICATEURS_DE_LA_PREFECTURE_DE_POLICE_DE_PARIS = (
        "04"  # [FP] Emploi dans le corps des identificateurs de la Préfecture de Police de Paris
    )
    FP_EMPLOI_ENTRE_400_ET_529_HEURES_ANNUELLES_DANS_LES_RESEAUX_SOUTERRAINS_ET_LES_OUVRAGES_ANNEXES_HOMOLOGUES = "05"  # [FP] Emploi entre 400 et 529 heures annuelles dans les réseaux souterrains et les ouvrages annexes homologués
    FP_EMPLOI_ENTRE_530_ET_799_HEURES_ANNUELLES_DANS_LES_RESEAUX_SOUTERRAINS_ET_LES_OUVRAGES_ANNEXES_HOMOLOGUES = "06"  # [FP] Emploi entre 530 et 799 heures annuelles dans les réseaux souterrains et les ouvrages annexes homologués
    FP_EMPLOI_ENTRE_400_ET_529_HEURES_ANNUELLES_EN_RESEAUX_SOUTERRAINS_OU_OUVRAGES_ANNEXES_HOMOLOGUES_ET_COMPLEMENT_EN_SERVICE_ACTIF = "07"  # [FP] Emploi entre 400 et 529 heures annuelles en réseaux souterrains ou ouvrages annexes homologués et complément en service actif
    FP_EMPLOI_ENTRE_530_ET_799_HEURES_ANNUELLES_EN_RESEAUX_SOUTERRAINS_OU_OUVRAGES_ANNEXES_HOMOLOGUES_ET_COMPLEMENT_EN_SERVICE_ACTIF = "08"  # [FP] Emploi entre 530 et 799 heures annuelles en réseaux souterrains ou ouvrages annexes homologués et complément en service actif
    FONCTION_CAPITAINE = "10"  # Fonction Capitaine
    FONCTION_SECOND_CAPITAINE = "11"  # Fonction Second capitaine
    FONCTION_CHEF_MECANICIEN = "12"  # Fonction Chef mécanicien
    FONCTION_SECOND_MECANICIEN = "13"  # Fonction Second mécanicien
    FONCTION_OFFICIER_CHARGE_DU_QUART_A_LA_PASSERELLE = (
        "14"  # Fonction Officier chargé du quart à la passerelle
    )
    FONCTION_OFFICIER_CHARGE_DU_QUART_A_LA_MACHINE = (
        "15"  # Fonction Officier chargé du quart à la machine
    )
    FONCTION_OFFICIER_ELECTROTECHNICIEN_ELECTRICIEN = (
        "16"  # Fonction Officier électrotechnicien / électricien
    )
    MARIN_QUALIFIE_PONT = "17"  # Marin qualifié Pont
    FONCTION_MATELOT_DANS_UNE_EQUIPE_DE_QUART = "18"  # Fonction Matelot dans une équipe de quart
    FONCTION_MATELOT_SANS_TACHE_SPECIALISEE = "19"  # Fonction Matelot sans tâche spécialisée
    MARIN_QUALIFIE_MACHINE = "20"  # Marin qualifié Machine
    FONCTION_MECANICIEN_DANS_UNE_EQUIPE_DE_QUART = (
        "21"  # Fonction Mécanicien dans une équipe de quart
    )
    FONCTION_MECANICIEN_SANS_TACHE_SPECIALISEE = "22"  # Fonction Mécanicien sans tâche spécialisée
    FONCTION_MATELOT_ELECTROTECHNICIEN_ELECTRICIEN = (
        "23"  # Fonction Matelot électrotechnicien / électricien
    )
    FONCTION_OPERATEUR_DES_RADIOCOMMUNICATIONS_A_BORD_D_UN_NAVIRE_EXPLOITE_DANS_LE_CADRE_DU_SYSTEME_MONDIAL_DE_DETRESSE_ET_DE_SECURITE_EN_MER_SMDSM = "24"  # Fonction Opérateur des radiocommunications à bord d’un navire exploité dans le cadre du Système Mondial de Détresse et de Sécurité en Mer (SMDSM)
    FONCTION_CUISINIER_DE_NAVIRE = "25"  # Fonction Cuisinier de navire
    FONCTION_ELEVE_MACHINE = "26"  # Fonction élève machine
    FONCTION_ELEVE_PONT = "27"  # Fonction élève pont
    FONCTION_PERSONNEL_DE_PREPARATION_OU_SERVICE_DES_REPAS_POUR_LES_GENS_DE_MER = (
        "28"  # Fonction Personnel de préparation ou service des repas pour les gens de mer
    )
    FONCTION_PERSONNEL_D_HOTELLERIE = "29"  # Fonction Personnel d’hôtellerie
    FONCTION_PERSONNEL_DE_PROPRETE = "30"  # Fonction Personnel de propreté
    FONCTION_PERSONNEL_DE_RESTAURATION = "31"  # Fonction Personnel de restauration
    FONCTION_PERSONNEL_DE_VENTE = "32"  # Fonction Personnel de vente
    FONCTION_PERSONNEL_POUR_L_ACCUEIL_DES_PASSAGERS = (
        "33"  # Fonction Personnel pour l’accueil des passagers
    )
    FONCTION_ECRIVAIN_DE_BORD = "34"  # Fonction Écrivain de bord
    FONCTION_MEDECIN = "35"  # Fonction Médecin
    FONCTION_INFIRMIER = "36"  # Fonction Infirmier
    FONCTION_HYDROGRAPHE = "37"  # Fonction Hydrographe
    FONCTION_PILOTE_MARITIME = "38"  # Fonction Pilote maritime
    FONCTION_CAPITAINE_POLYVALENT = "39"  # Fonction Capitaine Polyvalent
    FONCTION_SECOND_POLYVALENT = "40"  # Fonction Second Polyvalent
    FONCTION_OFFICIER_POLYVALENT = "41"  # Fonction Officier Polyvalent
    FONCTION_MARIN_QUALIFIE_POLYVALENT = "42"  # Fonction Marin qualifié Polyvalent
    FONCTION_MATELOT_POLYVALENT = "43"  # Fonction Matelot Polyvalent
    FONCTION_COMMISSAIRE = "44"  # Fonction Commissaire
    FONCTION_OFFICIER_ELECTRONICIEN = "45"  # Fonction Officier électronicien
    FONCTION_ELEVE_AUTRE = "46"  # Fonction élève autre
    FONCTION_ELEVE_POLYVALENT = "47"  # Fonction élève polyvalent
    FONCTION_NAVIGANT_CULTURES_MARINES = "48"  # Fonction Navigant cultures marines
    FONCTION_PERSONNEL_USINE_NAVIRE_PECHE = "49"  # Fonction Personnel usine navire pêche
    TRAVAUX_ACTIFS_A_100_ACTIFS_A_100 = "50"  # Travaux actifs à 100% [Actifs à 100%]
    TRAVAUX_MIXTES_NON_CADRE_ACTIFS_MIXTES_NON_CADRE = (
        "51"  # Travaux mixtes non cadre [Actifs Mixtes non cadre]
    )
    TRAVAUX_ACTIFS_EN_PARTIE_CADRE_ACTIFS_MIXTES_CADRE = (
        "52"  # Travaux actifs en partie cadre [Actifs Mixtes cadre]
    )
    TRAVAUX_ACTIFS_INTERMITTENTS_NON_CADRE_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "53"  # Travaux actifs intermittents non cadre [Actifs Intermittents non cadre]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_A_100 = (
        "54"  # CSS fonction politique (si actif précédemment) [Actifs à 100%]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_NON_CADRE = (
        "55"  # CSS fonction politique (si actif précédemment) [Actifs Mixtes non cadre]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_CADRE = (
        "56"  # CSS fonction politique (si actif précédemment) [Actifs Mixtes cadre]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "57"  # CSS fonction politique (si actif précédemment) [Actifs Intermittents non cadre]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_A_100 = (
        "58"  # CSS fonction syndicale (si actif précédemment) [Actifs à 100%]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_NON_CADRE = (
        "59"  # CSS fonction syndicale (si actif précédemment) [Actifs Mixtes non cadre]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_CADRE = (
        "60"  # CSS fonction syndicale (si actif précédemment) [Actifs Mixtes cadre]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "61"  # CSS fonction syndicale (si actif précédemment) [Actifs Intermittents non cadre]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_A_100 = (
        "62"  # Elu CAS SLV (si actif précédemment) [Actifs à 100%]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_NON_CADRE = (
        "63"  # Elu CAS SLV (si actif précédemment) [Actifs Mixtes non cadre]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_CADRE = (
        "64"  # Elu CAS SLV (si actif précédemment) [Actifs Mixtes cadre]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "65"  # Elu CAS SLV (si actif précédemment) [Actifs Intermittents non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_A_100 = (
        "66"  # Sédentaire (si actif avant A.T.) [Actifs à 100%]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_MIXTES_NON_CADRE = (
        "67"  # Sédentaire (si actif avant A.T.) [Actifs Mixtes non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_MIXTES_CADRE = (
        "68"  # Sédentaire (si actif avant A.T.) [Actifs Mixtes cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "69"  # Sédentaire (si actif avant A.T.) [Actifs Intermittents non cadre]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_A_100 = (
        "70"  # A disposition CCAS encadrement [Actifs à 100%]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_MIXTES_NON_CADRE = (
        "71"  # A disposition CCAS encadrement [Actifs Mixtes non cadre]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_MIXTES_CADRE = (
        "72"  # A disposition CCAS encadrement [Actifs Mixtes cadre]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "73"  # A disposition CCAS encadrement [Actifs Intermittents non cadre]
    )
    SERVICES_ACTIFS_ACCORD_2010_ACTIFS_SANS_PREPONDERANCE = (
        "74"  # Services actifs accord 2010 [Actifs sans Prépondérance]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_A_100 = (
        "75"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs à 100%]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_MIXTES_NON_CADRE = (
        "76"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_MIXTES_CADRE = (
        "77"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "78"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs Intermittents non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_SANS_PREPONDERANCE = (
        "79"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs sans Prépondérance]
    )
    FONCTION_LAMANAGE = "80"  # Fonction Lamanage
    FONCTION_PECHEUR_A_PIED = "81"  # Fonction Pêcheur à pied
    FONCTION_AUTRE_NAVIGANT = "82"  # Fonction Autre navigant
    PENIBILITE_P0 = "83"  # Pénibilité P0
    PENIBILITE_P1 = "84"  # Pénibilité P1
    PENIBILITE_P2 = "85"  # Pénibilité P2
    PENIBILITE_P3 = "86"  # Pénibilité P3

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] Emploi service s\u00e9dentaire",
        "02": "[FP] Emploi service actif",
        "03": "[FP] Emploi \u00e0 plus de 800 heures annuelles dans les r\u00e9seaux souterrains et les ouvrages annexes homologu\u00e9s",
        "04": "[FP] Emploi dans le corps des identificateurs de la Pr\u00e9fecture de Police de Paris",
        "05": "[FP] Emploi entre 400 et 529 heures annuelles dans les r\u00e9seaux souterrains et les ouvrages annexes homologu\u00e9s",
        "06": "[FP] Emploi entre 530 et 799 heures annuelles dans les r\u00e9seaux souterrains et les ouvrages annexes homologu\u00e9s",
        "07": "[FP] Emploi entre 400 et 529 heures annuelles en r\u00e9seaux souterrains ou ouvrages annexes homologu\u00e9s et compl\u00e9ment en service actif",
        "08": "[FP] Emploi entre 530 et 799 heures annuelles en r\u00e9seaux souterrains ou ouvrages annexes homologu\u00e9s et compl\u00e9ment en service actif",
        "10": "Fonction Capitaine",
        "11": "Fonction Second capitaine",
        "12": "Fonction Chef m\u00e9canicien",
        "13": "Fonction Second m\u00e9canicien",
        "14": "Fonction Officier charg\u00e9 du quart \u00e0 la passerelle",
        "15": "Fonction Officier charg\u00e9 du quart \u00e0 la machine",
        "16": "Fonction Officier \u00e9lectrotechnicien / \u00e9lectricien",
        "17": "Marin qualifi\u00e9 Pont",
        "18": "Fonction Matelot dans une \u00e9quipe de quart",
        "19": "Fonction Matelot sans t\u00e2che sp\u00e9cialis\u00e9e",
        "20": "Marin qualifi\u00e9 Machine",
        "21": "Fonction M\u00e9canicien dans une \u00e9quipe de quart",
        "22": "Fonction M\u00e9canicien sans t\u00e2che sp\u00e9cialis\u00e9e",
        "23": "Fonction Matelot \u00e9lectrotechnicien / \u00e9lectricien",
        "24": "Fonction Op\u00e9rateur des radiocommunications \u00e0 bord d\u2019un navire exploit\u00e9 dans le cadre du Syst\u00e8me Mondial de D\u00e9tresse et de S\u00e9curit\u00e9 en Mer (SMDSM)",
        "25": "Fonction Cuisinier de navire",
        "26": "Fonction \u00e9l\u00e8ve machine",
        "27": "Fonction \u00e9l\u00e8ve pont",
        "28": "Fonction Personnel de pr\u00e9paration ou service des repas pour les gens de mer",
        "29": "Fonction Personnel d\u2019h\u00f4tellerie",
        "30": "Fonction Personnel de propret\u00e9",
        "31": "Fonction Personnel de restauration",
        "32": "Fonction Personnel de vente",
        "33": "Fonction Personnel pour l\u2019accueil des passagers",
        "34": "Fonction \u00c9crivain de bord",
        "35": "Fonction M\u00e9decin",
        "36": "Fonction Infirmier",
        "37": "Fonction Hydrographe",
        "38": "Fonction Pilote maritime",
        "39": "Fonction Capitaine Polyvalent",
        "40": "Fonction Second Polyvalent",
        "41": "Fonction Officier Polyvalent",
        "42": "Fonction Marin qualifi\u00e9 Polyvalent",
        "43": "Fonction Matelot Polyvalent",
        "44": "Fonction Commissaire",
        "45": "Fonction Officier \u00e9lectronicien",
        "46": "Fonction \u00e9l\u00e8ve autre",
        "47": "Fonction \u00e9l\u00e8ve polyvalent",
        "48": "Fonction Navigant cultures marines",
        "49": "Fonction Personnel usine navire p\u00eache",
        "50": "Travaux actifs \u00e0 100% [Actifs \u00e0 100%]",
        "51": "Travaux mixtes non cadre [Actifs Mixtes non cadre]",
        "52": "Travaux actifs en partie cadre [Actifs Mixtes cadre]",
        "53": "Travaux actifs intermittents non cadre [Actifs Intermittents non cadre]",
        "54": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs \u00e0 100%]",
        "55": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes non cadre]",
        "56": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes cadre]",
        "57": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs Intermittents non cadre]",
        "58": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs \u00e0 100%]",
        "59": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes non cadre]",
        "60": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes cadre]",
        "61": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs Intermittents non cadre]",
        "62": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs \u00e0 100%]",
        "63": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes non cadre]",
        "64": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes cadre]",
        "65": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs Intermittents non cadre]",
        "66": "S\u00e9dentaire (si actif avant A.T.) [Actifs \u00e0 100%]",
        "67": "S\u00e9dentaire (si actif avant A.T.) [Actifs Mixtes non cadre]",
        "68": "S\u00e9dentaire (si actif avant A.T.) [Actifs Mixtes cadre]",
        "69": "S\u00e9dentaire (si actif avant A.T.) [Actifs Intermittents non cadre]",
        "70": "A disposition CCAS encadrement [Actifs \u00e0 100%]",
        "71": "A disposition CCAS encadrement [Actifs Mixtes non cadre]",
        "72": "A disposition CCAS encadrement [Actifs Mixtes cadre]",
        "73": "A disposition CCAS encadrement [Actifs Intermittents non cadre]",
        "74": "Services actifs accord 2010 [Actifs sans Pr\u00e9pond\u00e9rance]",
        "75": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs \u00e0 100%]",
        "76": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes non cadre]",
        "77": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes cadre]",
        "78": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs Intermittents non cadre]",
        "79": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs sans Pr\u00e9pond\u00e9rance]",
        "80": "Fonction Lamanage",
        "81": "Fonction P\u00eacheur \u00e0 pied",
        "82": "Fonction Autre navigant",
        "83": "P\u00e9nibilit\u00e9 P0",
        "84": "P\u00e9nibilit\u00e9 P1",
        "85": "P\u00e9nibilit\u00e9 P2",
        "86": "P\u00e9nibilit\u00e9 P3",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_CotisationIndividuNonSalarie_CodeCotisation(str, Enum):
    MONTANT_DE_COTISATION_REGIME_UNIFIE_AGIRC_ARRCO = (
        "001"  # Montant de cotisation Régime Unifié Agirc-Arrco
    )

    __DESCRIPTIONS: dict[str, str] = {
        "001": "Montant de cotisation R\u00e9gime Unifi\u00e9 Agirc-Arrco",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Ancien_Salarie_temps_partiel(str, Enum):
    POUR_LA_VIEILLESSE_REGIME_DE_BASE = "01"  # pour la vieillesse régime de base
    POUR_LA_VIEILLESSE_REGIME_DE_BASE_ET_LA_RETRAITE_COMPLEMENTAIRE = (
        "02"  # pour la vieillesse régime de base et la retraite complémentaire
    )
    TEMPS_PLEIN_OU_TEMPS_PARTIEL_NE_COTISANT_PAS_SUR_LA_BASE_D_UN_TEMPS_PLEIN = (
        "03"  # temps plein ou temps partiel ne cotisant pas sur la base d’un temps plein
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "pour la vieillesse r\u00e9gime de base",
        "02": "pour la vieillesse r\u00e9gime de base et la retraite compl\u00e9mentaire",
        "03": "temps plein ou temps partiel ne cotisant pas sur la base d\u2019un temps plein",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class FPAncienEmployeurPublic(str, Enum):
    ORANGE = "01"  # Orange
    LA_POSTE = "02"  # La poste

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Orange",
        "02": "La poste",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Genre_Navigation(str, Enum):
    CABOTAGE_INTERNATIONAL = "01"  # Cabotage international
    CABOTAGE_NATIONAL = "02"  # Cabotage national
    CONCHYLICULTURE_PETITE_PECHE = "03"  # Conchyliculture petite pêche
    CULTURE_MARINE = "04"  # Culture marine
    CULTURE_MARINE_PETITE_PECHE = "05"  # Culture marine petite pêche
    GRANDE_PECHE = "06"  # Grande pêche
    LAMANAGE_NAVIGATION_COTIERE = "07"  # Lamanage navigation côtière
    LONG_COURS = "08"  # Long cours
    NAVIGATION_COTIERE = "09"  # Navigation côtière
    PECHE_AU_LARGE = "10"  # Pêche au large
    PECHE_COTIERE = "11"  # Pêche côtière
    PETITE_PECHE = "12"  # Petite pêche
    PILOTAGE = "13"  # Pilotage
    REMORQUAGE_CABOTAGE_INTERNATIONAL = "14"  # Remorquage cabotage international
    REMORQUAGE_CABOTAGE_NATIONAL = "15"  # Remorquage cabotage national
    REMORQUAGE_LONG_COURS = "16"  # Remorquage long cours
    REMORQUAGE_NAVIGATION_COTIERE = "17"  # Remorquage navigation côtière
    YACHTING_CABOTAGE_INTERNATIONAL = "18"  # Yachting cabotage international
    YACHTING_CABOTAGE_NATIONAL = "19"  # Yachting cabotage national
    YACHTING_LONG_COURS = "20"  # Yachting long cours
    YACHTING_NAVIGATION_COTIERE = "21"  # Yachting navigation côtière

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Cabotage international",
        "02": "Cabotage national",
        "03": "Conchyliculture petite p\u00eache",
        "04": "Culture marine",
        "05": "Culture marine petite p\u00eache",
        "06": "Grande p\u00eache",
        "07": "Lamanage navigation c\u00f4ti\u00e8re",
        "08": "Long cours",
        "09": "Navigation c\u00f4ti\u00e8re",
        "10": "P\u00eache au large",
        "11": "P\u00eache c\u00f4ti\u00e8re",
        "12": "Petite p\u00eache",
        "13": "Pilotage",
        "14": "Remorquage cabotage international",
        "15": "Remorquage cabotage national",
        "16": "Remorquage long cours",
        "17": "Remorquage navigation c\u00f4ti\u00e8re",
        "18": "Yachting cabotage international",
        "19": "Yachting cabotage national",
        "20": "Yachting long cours",
        "21": "Yachting navigation c\u00f4ti\u00e8re",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class StatutOrganisateurSpectacle(str, Enum):
    ORGANISATEUR_OCCASIONNEL_DE_SPECTACLES_VIVANTS_MAXIMUM_6_SPECTACLES_VIVANTS_ANNUELS = "01"  # Organisateur occasionnel de spectacles vivants (maximum 6 spectacles vivants annuels)
    ENTREPRENEUR_DE_SPECTACLES_VIVANTS_PROFESSIONNEL_PLUS_DE_6_SPECTACLES_VIVANTS_ANNUELS = "02"  # Entrepreneur de spectacles vivants professionnel (plus de 6 spectacles vivants annuels)

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Organisateur occasionnel de spectacles vivants (maximum 6 spectacles vivants annuels)",
        "02": "Entrepreneur de spectacles vivants professionnel (plus de 6 spectacles vivants annuels)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_ComplementDispositifPublic(str, Enum):
    POSTE_ELIGIBLE_A_L_AIDE_EN_ENTREPRISE_ADAPTEE = (
        "01"  # Poste éligible à l'aide en entreprise adaptée
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_ACI_ACI_DC = (
        "02"  # Poste éligible à l'aide en structure d’IAE : ACI (ACI_DC)
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_AI_AI_DC = (
        "03"  # Poste éligible à l'aide en structure d’IAE : AI (AI_DC)
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_EI_EI_DC = (
        "04"  # Poste éligible à l'aide en structure d’IAE : EI (EI_DC)
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_ETTI_ETTI_DC = (
        "05"  # Poste éligible à l'aide en structure d’IAE : ETTI (ETTI_DC)
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Poste \u00e9ligible \u00e0 l\u0027aide en entreprise adapt\u00e9e",
        "02": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : ACI (ACI_DC)",
        "03": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : AI (AI_DC)",
        "04": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : EI (EI_DC)",
        "05": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : ETTI (ETTI_DC)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_AncienComplementDispositifPublic(str, Enum):
    POSTE_ELIGIBLE_A_L_AIDE_EN_ENTREPRISE_ADAPTEE = (
        "01"  # Poste éligible à l'aide en entreprise adaptée
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_ACI_ACI_DC = (
        "02"  # Poste éligible à l'aide en structure d’IAE : ACI (ACI_DC)
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_AI_AI_DC = (
        "03"  # Poste éligible à l'aide en structure d’IAE : AI (AI_DC)
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_EI_EI_DC = (
        "04"  # Poste éligible à l'aide en structure d’IAE : EI (EI_DC)
    )
    POSTE_ELIGIBLE_A_L_AIDE_EN_STRUCTURE_D_IAE_ETTI_ETTI_DC = (
        "05"  # Poste éligible à l'aide en structure d’IAE : ETTI (ETTI_DC)
    )
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Poste \u00e9ligible \u00e0 l\u0027aide en entreprise adapt\u00e9e",
        "02": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : ACI (ACI_DC)",
        "03": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : AI (AI_DC)",
        "04": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : EI (EI_DC)",
        "05": "Poste \u00e9ligible \u00e0 l\u0027aide en structure d\u2019IAE : ETTI (ETTI_DC)",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Base_Assujettie_Declare_Tort_2(str, Enum):
    ASSIETTE_BRUTE_PLAFONNEE = "02"  # Assiette  brute plafonnée
    ASSIETTE_BRUTE_DEPLAFONNEE = "03"  # Assiette brute déplafonnée
    BASE_FORFAITAIRE_SOUMISE_AUX_COTISATIONS_DE_SECURITE_SOCIALE = (
        "11"  # Base forfaitaire soumise aux cotisations de Sécurité Sociale
    )
    ASSIETTE_CRPCEN = "19"  # Assiette CRPCEN
    BASE_BRUTE_SPECIFIQUE = "22"  # Base brute spécifique
    BASE_EXCEPTIONNELLE_AGIRC_ARRCO = "23"  # Base exceptionnelle (Agirc Arrco)
    BASE_PLAFONNEE_SPECIFIQUE = "24"  # Base plafonnée spécifique
    ASSIETTE_DE_CONTRIBUTION_LIBERATOIRE = "25"  # Assiette de contribution libératoire
    BASE_IRCANTEC_COTISEE = "28"  # Base IRCANTEC cotisée
    CRPNPAC_ASSIETTE_SOUMISE_AU_TAUX_NORMAL_NON_PLAFONNEE = (
        "41"  # CRPNPAC-Assiette soumise au taux normal (non-plafonnée)
    )
    CRPNPAC_ASSIETTE_SOUMISE_AU_TAUX_MAJORE_NON_PLAFONNEE = (
        "42"  # CRPNPAC-Assiette soumise au taux majoré (non-plafonnée)
    )
    BASE_PLAFONNEE_EXCEPTIONNELLE_AGIRC_ARRCO = "43"  # Base plafonnée exceptionnelle Agirc Arrco
    BASE_PLAFONNEE_ICP_AGIRC_ARRCO = "45"  # Base plafonnée ICP Agirc-Arrco

    __DESCRIPTIONS: dict[str, str] = {
        "02": "Assiette  brute plafonn\u00e9e",
        "03": "Assiette brute d\u00e9plafonn\u00e9e",
        "11": "Base forfaitaire soumise aux cotisations de S\u00e9curit\u00e9 Sociale",
        "19": "Assiette CRPCEN",
        "22": "Base brute sp\u00e9cifique",
        "23": "Base exceptionnelle (Agirc Arrco)",
        "24": "Base plafonn\u00e9e sp\u00e9cifique",
        "25": "Assiette de contribution lib\u00e9ratoire",
        "28": "Base IRCANTEC cotis\u00e9e",
        "41": "CRPNPAC-Assiette soumise au taux normal (non-plafonn\u00e9e)",
        "42": "CRPNPAC-Assiette soumise au taux major\u00e9 (non-plafonn\u00e9e)",
        "43": "Base plafonn\u00e9e exceptionnelle Agirc Arrco",
        "45": "Base plafonn\u00e9e ICP Agirc-Arrco",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_CollegeCNIEG(str, Enum):
    COLLEGE_EXECUTION = "01"  # Collège Exécution
    COLLEGE_MAITRISE = "02"  # Collège Maîtrise
    COLLEGE_CADRE = "03"  # Collège Cadre

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Coll\u00e8ge Ex\u00e9cution",
        "02": "Coll\u00e8ge Ma\u00eetrise",
        "03": "Coll\u00e8ge Cadre",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_FormeAmenagementTempsTravailActivitePartielle(str, Enum):
    FORFAIT_HEBDOMADAIRE = "01"  # Forfait hebdomadaire
    AUTRE_TEMPS_DE_TRAVAIL_HEBDOMADAIRE = "02"  # Autre temps de travail hebdomadaire
    EQUIVALENT_A_35H_39H_MAYOTTE = "03"  # Equivalent à 35h - 39h (Mayotte)
    FORFAIT_MENSUEL = "04"  # Forfait mensuel
    FORFAIT_ANNUEL_EN_JOUR = "05"  # Forfait annuel en jour
    FORFAIT_ANNUEL_EN_HEURES = "06"  # Forfait annuel en heures
    CYCLE = "07"  # Cycle
    MODULATION = "08"  # Modulation
    AMENAGEMENT_DU_TEMPS_DE_TRAVAIL_LOI_DU_20_AOUT_2008 = (
        "09"  # Aménagement du temps de travail (Loi du 20 août 2008)
    )
    PERSONNEL_NAVIGANT_OU_AUTRES = "10"  # Personnel navigant ou autres

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Forfait hebdomadaire",
        "02": "Autre temps de travail hebdomadaire",
        "03": "Equivalent \u00e0 35h - 39h (Mayotte)",
        "04": "Forfait mensuel",
        "05": "Forfait annuel en jour",
        "06": "Forfait annuel en heures",
        "07": "Cycle",
        "08": "Modulation",
        "09": "Am\u00e9nagement du temps de travail (Loi du 20 ao\u00fbt 2008)",
        "10": "Personnel navigant ou autres",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class FPTypeDetachementAncien(str, Enum):
    FP_DETACHEMENT_AUPRES_D_UN_PARLEMENTAIRE = "01"  # [FP] Détachement auprès d'un parlementaire
    FP_DETACHEMENT_SUR_UN_EMPLOI_DE_COLLABORATEUR_CABINET = (
        "02"  # [FP] Détachement sur un emploi de collaborateur cabinet
    )
    FP_DETACHEMENT_AU_TITRE_DE_LA_COOPERATION_TECHNIQUE = (
        "03"  # [FP] Détachement au titre de la coopération technique
    )
    FP_DETACHEMENT_SUR_UN_EMPLOI_FONCTIONNEL = "05"  # [FP] Détachement sur un emploi fonctionnel
    FP_DETACHEMENT_POUR_FONCTION_ELECTIVE_OU_MANDAT_SYNDICAL = (
        "06"  # [FP] Détachement pour fonction élective ou mandat syndical
    )
    FP_DETACHEMENT_POUR_EXERCER_UN_MANDAT_DE_DEPUTE = (
        "07"  # [FP] Détachement pour exercer un mandat de député
    )
    FP_DETACHEMENT_POUR_EXERCER_UN_MANDAT_DE_SENATEUR = (
        "08"  # [FP] Détachement pour exercer un mandat de sénateur
    )
    FP_DETACHEMENT_RECLASSEMENT_POUR_DIFFICULTES_OPERATIONNELLES = (
        "09"  # [FP] Détachement (reclassement) pour difficultés opérationnelles
    )
    FP_DETACHEMENT_RECLASSEMENT_POUR_RAISON_OPERATIONNELLE = (
        "10"  # [FP] Détachement (reclassement) pour raison opérationnelle
    )
    FP_DETACHEMENT_AUPRES_D_UN_ORGANISME_DE_DROIT_PRIVE_D_UN_EPIC_OU_D_UN_GIP = (
        "11"  # [FP] Détachement auprès d'un organisme de droit privé, d'un EPIC ou d'un GIP
    )
    FP_DETACHEMENT_AUPRES_D_UN_ETABLISSEMENT_PUBLIC_NATIONAL = (
        "12"  # [FP] Détachement auprès d'un établissement public national
    )
    FP_DETACHEMENT_AUPRES_D_UNE_COLLECTIVITE_OU_D_UN_ETABLISSEMENT_PUBLIC_TERRITORIAL_OU_HOSPITALIER = "13"  # [FP] Détachement auprès d'une collectivité ou d’un établissement public territorial ou hospitalier
    FP_DETACHEMENT_AUPRES_DE_L_ETAT = "15"  # [FP] Détachement auprès de l’Etat
    FP_ABSENCE_DE_DETACHEMENT = "16"  # [FP] Absence de détachement
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] D\u00e9tachement aupr\u00e8s d\u0027un parlementaire",
        "02": "[FP] D\u00e9tachement sur un emploi de collaborateur cabinet",
        "03": "[FP] D\u00e9tachement au titre de la coop\u00e9ration technique",
        "05": "[FP] D\u00e9tachement sur un emploi fonctionnel",
        "06": "[FP] D\u00e9tachement pour fonction \u00e9lective ou mandat syndical",
        "07": "[FP] D\u00e9tachement pour exercer un mandat de d\u00e9put\u00e9",
        "08": "[FP] D\u00e9tachement pour exercer un mandat de s\u00e9nateur",
        "09": "[FP] D\u00e9tachement (reclassement) pour difficult\u00e9s op\u00e9rationnelles",
        "10": "[FP] D\u00e9tachement (reclassement) pour raison op\u00e9rationnelle",
        "11": "[FP] D\u00e9tachement aupr\u00e8s d\u0027un organisme de droit priv\u00e9, d\u0027un EPIC ou d\u0027un GIP",
        "12": "[FP] D\u00e9tachement aupr\u00e8s d\u0027un \u00e9tablissement public national",
        "13": "[FP] D\u00e9tachement aupr\u00e8s d\u0027une collectivit\u00e9 ou d\u2019un \u00e9tablissement public territorial ou hospitalier",
        "15": "[FP] D\u00e9tachement aupr\u00e8s de l\u2019Etat",
        "16": "[FP] Absence de d\u00e9tachement",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_CollegeCNIEGAncien(str, Enum):
    COLLEGE_EXECUTION = "01"  # Collège Exécution
    COLLEGE_MAITRISE = "02"  # Collège Maîtrise
    COLLEGE_CADRE = "03"  # Collège Cadre
    PAS_DE_COLLEGE = "99"  # Pas de collège

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Coll\u00e8ge Ex\u00e9cution",
        "02": "Coll\u00e8ge Ma\u00eetrise",
        "03": "Coll\u00e8ge Cadre",
        "99": "Pas de coll\u00e8ge",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class FPCodeCategorieServiceAncien(str, Enum):
    FP_EMPLOI_SERVICE_SEDENTAIRE = "01"  # [FP] Emploi service sédentaire
    FP_EMPLOI_SERVICE_ACTIF = "02"  # [FP] Emploi service actif
    FP_EMPLOI_A_PLUS_DE_800_HEURES_ANNUELLES_DANS_LES_RESEAUX_SOUTERRAINS_ET_LES_OUVRAGES_ANNEXES_HOMOLOGUES = "03"  # [FP] Emploi à plus de 800 heures annuelles dans les réseaux souterrains et les ouvrages annexes homologués
    FP_EMPLOI_DANS_LE_CORPS_DES_IDENTIFICATEURS_DE_LA_PREFECTURE_DE_POLICE_DE_PARIS = (
        "04"  # [FP] Emploi dans le corps des identificateurs de la Préfecture de Police de Paris
    )
    FP_EMPLOI_ENTRE_400_ET_529_HEURES_ANNUELLES_DANS_LES_RESEAUX_SOUTERRAINS_ET_LES_OUVRAGES_ANNEXES_HOMOLOGUES = "05"  # [FP] Emploi entre 400 et 529 heures annuelles dans les réseaux souterrains et les ouvrages annexes homologués
    FP_EMPLOI_ENTRE_530_ET_799_HEURES_ANNUELLES_DANS_LES_RESEAUX_SOUTERRAINS_ET_LES_OUVRAGES_ANNEXES_HOMOLOGUES = "06"  # [FP] Emploi entre 530 et 799 heures annuelles dans les réseaux souterrains et les ouvrages annexes homologués
    FP_EMPLOI_ENTRE_400_ET_529_HEURES_ANNUELLES_EN_RESEAUX_SOUTERRAINS_OU_OUVRAGES_ANNEXES_HOMOLOGUES_ET_COMPLEMENT_EN_SERVICE_ACTIF = "07"  # [FP] Emploi entre 400 et 529 heures annuelles en réseaux souterrains ou ouvrages annexes homologués et complément en service actif
    FP_EMPLOI_ENTRE_530_ET_799_HEURES_ANNUELLES_EN_RESEAUX_SOUTERRAINS_OU_OUVRAGES_ANNEXES_HOMOLOGUES_ET_COMPLEMENT_EN_SERVICE_ACTIF = "08"  # [FP] Emploi entre 530 et 799 heures annuelles en réseaux souterrains ou ouvrages annexes homologués et complément en service actif
    FONCTION_CAPITAINE = "10"  # Fonction Capitaine
    FONCTION_SECOND_CAPITAINE = "11"  # Fonction Second capitaine
    FONCTION_CHEF_MECANICIEN = "12"  # Fonction Chef mécanicien
    FONCTION_SECOND_MECANICIEN = "13"  # Fonction Second mécanicien
    FONCTION_OFFICIER_CHARGE_DU_QUART_A_LA_PASSERELLE = (
        "14"  # Fonction Officier chargé du quart à la passerelle
    )
    FONCTION_OFFICIER_CHARGE_DU_QUART_A_LA_MACHINE = (
        "15"  # Fonction Officier chargé du quart à la machine
    )
    FONCTION_OFFICIER_ELECTROTECHNICIEN_ELECTRICIEN = (
        "16"  # Fonction Officier électrotechnicien / électricien
    )
    MARIN_QUALIFIE_PONT = "17"  # Marin qualifié Pont
    FONCTION_MATELOT_DANS_UNE_EQUIPE_DE_QUART = "18"  # Fonction Matelot dans une équipe de quart
    FONCTION_MATELOT_SANS_TACHE_SPECIALISEE = "19"  # Fonction Matelot sans tâche spécialisée
    MARIN_QUALIFIE_MACHINE = "20"  # Marin qualifié Machine
    FONCTION_MECANICIEN_DANS_UNE_EQUIPE_DE_QUART = (
        "21"  # Fonction Mécanicien dans une équipe de quart
    )
    FONCTION_MECANICIEN_SANS_TACHE_SPECIALISEE = "22"  # Fonction Mécanicien sans tâche spécialisée
    FONCTION_MATELOT_ELECTROTECHNICIEN_ELECTRICIEN = (
        "23"  # Fonction Matelot électrotechnicien / électricien
    )
    FONCTION_OPERATEUR_DES_RADIOCOMMUNICATIONS_A_BORD_D_UN_NAVIRE_EXPLOITE_DANS_LE_CADRE_DU_SYSTEME_MONDIAL_DE_DETRESSE_ET_DE_SECURITE_EN_MER_SMDSM = "24"  # Fonction Opérateur des radiocommunications à bord d’un navire exploité dans le cadre du Système Mondial de Détresse et de Sécurité en Mer (SMDSM)
    FONCTION_CUISINIER_DE_NAVIRE = "25"  # Fonction Cuisinier de navire
    FONCTION_ELEVE_MACHINE = "26"  # Fonction élève machine
    FONCTION_ELEVE_PONT = "27"  # Fonction élève pont
    FONCTION_PERSONNEL_DE_PREPARATION_OU_SERVICE_DES_REPAS_POUR_LES_GENS_DE_MER = (
        "28"  # Fonction Personnel de préparation ou service des repas pour les gens de mer
    )
    FONCTION_PERSONNEL_D_HOTELLERIE = "29"  # Fonction Personnel d’hôtellerie
    FONCTION_PERSONNEL_DE_PROPRETE = "30"  # Fonction Personnel de propreté
    FONCTION_PERSONNEL_DE_RESTAURATION = "31"  # Fonction Personnel de restauration
    FONCTION_PERSONNEL_DE_VENTE = "32"  # Fonction Personnel de vente
    FONCTION_PERSONNEL_POUR_L_ACCUEIL_DES_PASSAGERS = (
        "33"  # Fonction Personnel pour l’accueil des passagers
    )
    FONCTION_ECRIVAIN_DE_BORD = "34"  # Fonction Écrivain de bord
    FONCTION_MEDECIN = "35"  # Fonction Médecin
    FONCTION_INFIRMIER = "36"  # Fonction Infirmier
    FONCTION_HYDROGRAPHE = "37"  # Fonction Hydrographe
    FONCTION_PILOTE_MARITIME = "38"  # Fonction Pilote maritime
    FONCTION_CAPITAINE_POLYVALENT = "39"  # Fonction Capitaine Polyvalent
    FONCTION_SECOND_POLYVALENT = "40"  # Fonction Second Polyvalent
    FONCTION_OFFICIER_POLYVALENT = "41"  # Fonction Officier Polyvalent
    FONCTION_MARIN_QUALIFIE_POLYVALENT = "42"  # Fonction Marin qualifié Polyvalent
    FONCTION_MATELOT_POLYVALENT = "43"  # Fonction Matelot Polyvalent
    FONCTION_COMMISSAIRE = "44"  # Fonction Commissaire
    FONCTION_OFFICIER_ELECTRONICIEN = "45"  # Fonction Officier électronicien
    FONCTION_ELEVE_AUTRE = "46"  # Fonction élève autre
    FONCTION_ELEVE_POLYVALENT = "47"  # Fonction élève polyvalent
    FONCTION_NAVIGANT_CULTURES_MARINES = "48"  # Fonction Navigant cultures marines
    FONCTION_PERSONNEL_USINE_NAVIRE_PECHE = "49"  # Fonction Personnel usine navire pêche
    TRAVAUX_ACTIFS_A_100_ACTIFS_A_100 = "50"  # Travaux actifs à 100% [Actifs à 100%]
    TRAVAUX_MIXTES_NON_CADRE_ACTIFS_MIXTES_NON_CADRE = (
        "51"  # Travaux mixtes non cadre [Actifs Mixtes non cadre]
    )
    TRAVAUX_ACTIFS_EN_PARTIE_CADRE_ACTIFS_MIXTES_CADRE = (
        "52"  # Travaux actifs en partie cadre [Actifs Mixtes cadre]
    )
    TRAVAUX_ACTIFS_INTERMITTENTS_NON_CADRE_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "53"  # Travaux actifs intermittents non cadre [Actifs Intermittents non cadre]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_A_100 = (
        "54"  # CSS fonction politique (si actif précédemment) [Actifs à 100%]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_NON_CADRE = (
        "55"  # CSS fonction politique (si actif précédemment) [Actifs Mixtes non cadre]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_CADRE = (
        "56"  # CSS fonction politique (si actif précédemment) [Actifs Mixtes cadre]
    )
    CSS_FONCTION_POLITIQUE_SI_ACTIF_PRECEDEMMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "57"  # CSS fonction politique (si actif précédemment) [Actifs Intermittents non cadre]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_A_100 = (
        "58"  # CSS fonction syndicale (si actif précédemment) [Actifs à 100%]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_NON_CADRE = (
        "59"  # CSS fonction syndicale (si actif précédemment) [Actifs Mixtes non cadre]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_CADRE = (
        "60"  # CSS fonction syndicale (si actif précédemment) [Actifs Mixtes cadre]
    )
    CSS_FONCTION_SYNDICALE_SI_ACTIF_PRECEDEMMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "61"  # CSS fonction syndicale (si actif précédemment) [Actifs Intermittents non cadre]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_A_100 = (
        "62"  # Elu CAS SLV (si actif précédemment) [Actifs à 100%]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_NON_CADRE = (
        "63"  # Elu CAS SLV (si actif précédemment) [Actifs Mixtes non cadre]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_MIXTES_CADRE = (
        "64"  # Elu CAS SLV (si actif précédemment) [Actifs Mixtes cadre]
    )
    ELU_CAS_SLV_SI_ACTIF_PRECEDEMMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "65"  # Elu CAS SLV (si actif précédemment) [Actifs Intermittents non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_A_100 = (
        "66"  # Sédentaire (si actif avant A.T.) [Actifs à 100%]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_MIXTES_NON_CADRE = (
        "67"  # Sédentaire (si actif avant A.T.) [Actifs Mixtes non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_MIXTES_CADRE = (
        "68"  # Sédentaire (si actif avant A.T.) [Actifs Mixtes cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "69"  # Sédentaire (si actif avant A.T.) [Actifs Intermittents non cadre]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_A_100 = (
        "70"  # A disposition CCAS encadrement [Actifs à 100%]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_MIXTES_NON_CADRE = (
        "71"  # A disposition CCAS encadrement [Actifs Mixtes non cadre]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_MIXTES_CADRE = (
        "72"  # A disposition CCAS encadrement [Actifs Mixtes cadre]
    )
    A_DISPOSITION_CCAS_ENCADREMENT_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "73"  # A disposition CCAS encadrement [Actifs Intermittents non cadre]
    )
    SERVICES_ACTIFS_ACCORD_2010_ACTIFS_SANS_PREPONDERANCE = (
        "74"  # Services actifs accord 2010 [Actifs sans Prépondérance]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_A_100 = (
        "75"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs à 100%]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_MIXTES_NON_CADRE = (
        "76"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_MIXTES_CADRE = (
        "77"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_INTERMITTENTS_NON_CADRE = (
        "78"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs Intermittents non cadre]
    )
    SEDENTAIRE_SI_ACTIF_AVANT_A_T_ACCORD_2010_ACTIFS_SANS_PREPONDERANCE = (
        "79"  # Sédentaire (si actif avant A.T.) accord 2010 [Actifs sans Prépondérance]
    )
    FONCTION_LAMANAGE = "80"  # Fonction Lamanage
    FONCTION_PECHEUR_A_PIED = "81"  # Fonction Pêcheur à pied
    FONCTION_AUTRE_NAVIGANT = "82"  # Fonction Autre navigant
    PENIBILITE_P0 = "83"  # Pénibilité P0
    PENIBILITE_P1 = "84"  # Pénibilité P1
    PENIBILITE_P2 = "85"  # Pénibilité P2
    PENIBILITE_P3 = "86"  # Pénibilité P3
    PAS_DE_CATEGORIE_DE_SERVICE = "99"  # Pas de catégorie de service

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] Emploi service s\u00e9dentaire",
        "02": "[FP] Emploi service actif",
        "03": "[FP] Emploi \u00e0 plus de 800 heures annuelles dans les r\u00e9seaux souterrains et les ouvrages annexes homologu\u00e9s",
        "04": "[FP] Emploi dans le corps des identificateurs de la Pr\u00e9fecture de Police de Paris",
        "05": "[FP] Emploi entre 400 et 529 heures annuelles dans les r\u00e9seaux souterrains et les ouvrages annexes homologu\u00e9s",
        "06": "[FP] Emploi entre 530 et 799 heures annuelles dans les r\u00e9seaux souterrains et les ouvrages annexes homologu\u00e9s",
        "07": "[FP] Emploi entre 400 et 529 heures annuelles en r\u00e9seaux souterrains ou ouvrages annexes homologu\u00e9s et compl\u00e9ment en service actif",
        "08": "[FP] Emploi entre 530 et 799 heures annuelles en r\u00e9seaux souterrains ou ouvrages annexes homologu\u00e9s et compl\u00e9ment en service actif",
        "10": "Fonction Capitaine",
        "11": "Fonction Second capitaine",
        "12": "Fonction Chef m\u00e9canicien",
        "13": "Fonction Second m\u00e9canicien",
        "14": "Fonction Officier charg\u00e9 du quart \u00e0 la passerelle",
        "15": "Fonction Officier charg\u00e9 du quart \u00e0 la machine",
        "16": "Fonction Officier \u00e9lectrotechnicien / \u00e9lectricien",
        "17": "Marin qualifi\u00e9 Pont",
        "18": "Fonction Matelot dans une \u00e9quipe de quart",
        "19": "Fonction Matelot sans t\u00e2che sp\u00e9cialis\u00e9e",
        "20": "Marin qualifi\u00e9 Machine",
        "21": "Fonction M\u00e9canicien dans une \u00e9quipe de quart",
        "22": "Fonction M\u00e9canicien sans t\u00e2che sp\u00e9cialis\u00e9e",
        "23": "Fonction Matelot \u00e9lectrotechnicien / \u00e9lectricien",
        "24": "Fonction Op\u00e9rateur des radiocommunications \u00e0 bord d\u2019un navire exploit\u00e9 dans le cadre du Syst\u00e8me Mondial de D\u00e9tresse et de S\u00e9curit\u00e9 en Mer (SMDSM)",
        "25": "Fonction Cuisinier de navire",
        "26": "Fonction \u00e9l\u00e8ve machine",
        "27": "Fonction \u00e9l\u00e8ve pont",
        "28": "Fonction Personnel de pr\u00e9paration ou service des repas pour les gens de mer",
        "29": "Fonction Personnel d\u2019h\u00f4tellerie",
        "30": "Fonction Personnel de propret\u00e9",
        "31": "Fonction Personnel de restauration",
        "32": "Fonction Personnel de vente",
        "33": "Fonction Personnel pour l\u2019accueil des passagers",
        "34": "Fonction \u00c9crivain de bord",
        "35": "Fonction M\u00e9decin",
        "36": "Fonction Infirmier",
        "37": "Fonction Hydrographe",
        "38": "Fonction Pilote maritime",
        "39": "Fonction Capitaine Polyvalent",
        "40": "Fonction Second Polyvalent",
        "41": "Fonction Officier Polyvalent",
        "42": "Fonction Marin qualifi\u00e9 Polyvalent",
        "43": "Fonction Matelot Polyvalent",
        "44": "Fonction Commissaire",
        "45": "Fonction Officier \u00e9lectronicien",
        "46": "Fonction \u00e9l\u00e8ve autre",
        "47": "Fonction \u00e9l\u00e8ve polyvalent",
        "48": "Fonction Navigant cultures marines",
        "49": "Fonction Personnel usine navire p\u00eache",
        "50": "Travaux actifs \u00e0 100% [Actifs \u00e0 100%]",
        "51": "Travaux mixtes non cadre [Actifs Mixtes non cadre]",
        "52": "Travaux actifs en partie cadre [Actifs Mixtes cadre]",
        "53": "Travaux actifs intermittents non cadre [Actifs Intermittents non cadre]",
        "54": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs \u00e0 100%]",
        "55": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes non cadre]",
        "56": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes cadre]",
        "57": "CSS fonction politique (si actif pr\u00e9c\u00e9demment) [Actifs Intermittents non cadre]",
        "58": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs \u00e0 100%]",
        "59": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes non cadre]",
        "60": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes cadre]",
        "61": "CSS fonction syndicale (si actif pr\u00e9c\u00e9demment) [Actifs Intermittents non cadre]",
        "62": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs \u00e0 100%]",
        "63": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes non cadre]",
        "64": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs Mixtes cadre]",
        "65": "Elu CAS SLV (si actif pr\u00e9c\u00e9demment) [Actifs Intermittents non cadre]",
        "66": "S\u00e9dentaire (si actif avant A.T.) [Actifs \u00e0 100%]",
        "67": "S\u00e9dentaire (si actif avant A.T.) [Actifs Mixtes non cadre]",
        "68": "S\u00e9dentaire (si actif avant A.T.) [Actifs Mixtes cadre]",
        "69": "S\u00e9dentaire (si actif avant A.T.) [Actifs Intermittents non cadre]",
        "70": "A disposition CCAS encadrement [Actifs \u00e0 100%]",
        "71": "A disposition CCAS encadrement [Actifs Mixtes non cadre]",
        "72": "A disposition CCAS encadrement [Actifs Mixtes cadre]",
        "73": "A disposition CCAS encadrement [Actifs Intermittents non cadre]",
        "74": "Services actifs accord 2010 [Actifs sans Pr\u00e9pond\u00e9rance]",
        "75": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs \u00e0 100%]",
        "76": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes non cadre]",
        "77": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs Mixtes cadre]",
        "78": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs Intermittents non cadre]",
        "79": "S\u00e9dentaire (si actif avant A.T.) accord 2010 [Actifs sans Pr\u00e9pond\u00e9rance]",
        "80": "Fonction Lamanage",
        "81": "Fonction P\u00eacheur \u00e0 pied",
        "82": "Fonction Autre navigant",
        "83": "P\u00e9nibilit\u00e9 P0",
        "84": "P\u00e9nibilit\u00e9 P1",
        "85": "P\u00e9nibilit\u00e9 P2",
        "86": "P\u00e9nibilit\u00e9 P3",
        "99": "Pas de cat\u00e9gorie de service",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class FPAncienEmployeurPublicAncien(str, Enum):
    ORANGE = "01"  # Orange
    LA_POSTE = "02"  # La poste
    PAS_D_ANCIEN_EMPLOYEUR_PUBLIC = "99"  # Pas d'ancien employeur public

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Orange",
        "02": "La poste",
        "99": "Pas d\u0027ancien employeur public",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Genre_NavigationAncien(str, Enum):
    CABOTAGE_INTERNATIONAL = "01"  # Cabotage international
    CABOTAGE_NATIONAL = "02"  # Cabotage national
    CONCHYLICULTURE_PETITE_PECHE = "03"  # Conchyliculture petite pêche
    CULTURE_MARINE = "04"  # Culture marine
    CULTURE_MARINE_PETITE_PECHE = "05"  # Culture marine petite pêche
    GRANDE_PECHE = "06"  # Grande pêche
    LAMANAGE_NAVIGATION_COTIERE = "07"  # Lamanage navigation côtière
    LONG_COURS = "08"  # Long cours
    NAVIGATION_COTIERE = "09"  # Navigation côtière
    PECHE_AU_LARGE = "10"  # Pêche au large
    PECHE_COTIERE = "11"  # Pêche côtière
    PETITE_PECHE = "12"  # Petite pêche
    PILOTAGE = "13"  # Pilotage
    REMORQUAGE_CABOTAGE_INTERNATIONAL = "14"  # Remorquage cabotage international
    REMORQUAGE_CABOTAGE_NATIONAL = "15"  # Remorquage cabotage national
    REMORQUAGE_LONG_COURS = "16"  # Remorquage long cours
    REMORQUAGE_NAVIGATION_COTIERE = "17"  # Remorquage navigation côtière
    YACHTING_CABOTAGE_INTERNATIONAL = "18"  # Yachting cabotage international
    YACHTING_CABOTAGE_NATIONAL = "19"  # Yachting cabotage national
    YACHTING_LONG_COURS = "20"  # Yachting long cours
    YACHTING_NAVIGATION_COTIERE = "21"  # Yachting navigation côtière
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Cabotage international",
        "02": "Cabotage national",
        "03": "Conchyliculture petite p\u00eache",
        "04": "Culture marine",
        "05": "Culture marine petite p\u00eache",
        "06": "Grande p\u00eache",
        "07": "Lamanage navigation c\u00f4ti\u00e8re",
        "08": "Long cours",
        "09": "Navigation c\u00f4ti\u00e8re",
        "10": "P\u00eache au large",
        "11": "P\u00eache c\u00f4ti\u00e8re",
        "12": "Petite p\u00eache",
        "13": "Pilotage",
        "14": "Remorquage cabotage international",
        "15": "Remorquage cabotage national",
        "16": "Remorquage long cours",
        "17": "Remorquage navigation c\u00f4ti\u00e8re",
        "18": "Yachting cabotage international",
        "19": "Yachting cabotage national",
        "20": "Yachting long cours",
        "21": "Yachting navigation c\u00f4ti\u00e8re",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_StatutBOETHAncien(str, Enum):
    TRAVAILLEUR_RECONNU_HANDICAPE_PAR_LA_COMMISSION_DES_DROITS_ET_DE_L_AUTONOMIE_DES_PERSONNES_HANDICAPEES = "01"  # Travailleur reconnu handicapé par la commission des droits et de l'autonomie des personnes handicapées
    VICTIME_D_ACCIDENT_DU_TRAVAIL_OU_DE_MALADIE_PROFESSIONNELLE_AYANT_ENTRAINE_UNE_INCAPACITE_PERMANENTE_AU_MOINS_EGALE_A_10_ET_TITULAIRE_D_UNE_RENTE = "02"  # Victime d'accident du travail ou de maladie professionnelle ayant entraîné une incapacité permanente au moins égale à 10 % et titulaire d'une rente
    TITULAIRE_D_UNE_PENSION_D_INVALIDITE_A_CONDITION_QUE_L_INVALIDITE_REDUISE_AU_MOINS_DES_DEUX_TIERS_SA_CAPACITE_DE_TRAVAIL = "03"  # Titulaire d'une pension d'invalidité à condition que l'invalidité réduise au moins des deux tiers sa capacité de travail
    BENEFICIAIRE_MENTIONNE_A_L_ARTICLE_L_241_2_DU_CODE_DES_PENSIONS_MILITAIRES_D_INVALIDITE_ET_DES_VICTIMES_DE_LA_GUERRE = "04"  # Bénéficiaire mentionné à l'article L.241-2 du Code des pensions militaires d'invalidité et des victimes de la guerre
    BENEFICIAIRE_MENTIONNE_AUX_ARTICLES_L_241_3_ET_L_241_4_DU_CODE_DES_PENSIONS_MILITAIRES_D_INVALIDITE_ET_DES_VICTIMES_DE_LA_GUERRE = "05"  # Bénéficiaire mentionné aux articles L.241-3 et L.241-4 du Code des pensions militaires d'invalidité et des victimes de la guerre
    TITULAIRE_D_UNE_ALLOCATION_OU_D_UNE_RENTE_D_INVALIDITE_DANS_LES_CONDITIONS_DEFINIES_PAR_LA_LOI_N_91_1389_DU_31_DECEMBRE_1991 = "06"  # Titulaire d'une allocation ou d'une rente d'invalidité dans les conditions définies par la Loi n°91-1389 du 31 décembre 1991
    TITULAIRE_DE_LA_CARTE_MOBILITE_INCLUSION_PORTANT_LA_MENTION_INVALIDITE_L_241_3_DU_CODE_DE_L_ACTION_SOCIALE_ET_DES_FAMILLES = "07"  # Titulaire de la carte "mobilité inclusion" portant la mention "invalidité" (L. 241-3 du Code de l'action sociale et des familles)
    TITULAIRE_DE_L_ALLOCATION_AUX_ADULTES_HANDICAPES = (
        "08"  # Titulaire de l'allocation aux adultes handicapés
    )
    BENEFICIAIRE_MENTIONNE_AUX_ARTICLES_L_241_5_ET_L_241_6_DU_CODE_DES_PENSIONS_MILITAIRES_D_INVALIDITE_ET_DES_VICTIMES_DE_GUERRE = "09"  # Bénéficiaire mentionné aux articles L.241-5 et L.241-6 du Code des pensions militaires d'invalidité et des victimes de guerre
    AGENT_PUBLIC_RECLASSE_3EME_ALINEA_DE_L_ARTICLE_L_323_5_DU_CODE_DU_TRAVAIL = (
        "10"  # Agent public reclassé (3ème alinéa de l'article L.323-5 du Code du travail)
    )
    AGENT_PUBLIC_BENEFICIAIRE_D_UNE_ALLOCATION_TEMPORAIRE_D_INVALIDITE_4EME_ALINEA_DE_L_ARTICLE_L_323_5_DU_CODE_DU_TRAVAIL = "11"  # Agent public bénéficiaire d'une allocation temporaire d'invalidité (4ème alinéa de l'article L.323-5 du Code du travail)
    AYANT_DROIT_A_LA_PRESTATION_DE_COMPENSATION_DU_HANDICAP_A_L_ALLOCATION_COMPENSATRICE_POUR_TIERCE_PERSONNE_OU_A_L_ALLOCATION_D_EDUCATION_DE_L_ENFANT_HANDICAPE_BENEFICIANT_D_UN_STAGE_L_5212_7_DU_CODE_DU_TRAVAIL = "12"  # Ayant droit à la prestation de compensation du handicap, à l'allocation compensatrice pour tierce personne ou à l'allocation d'éducation de l'enfant handicapé bénéficiant d'un stage (L.5212-7 du Code du travail)
    ABSENCE_DE_STATUT_BOETH = "99"  # Absence de statut BOETH

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Travailleur reconnu handicap\u00e9 par la commission des droits et de l\u0027autonomie des personnes handicap\u00e9es",
        "02": "Victime d\u0027accident du travail ou de maladie professionnelle ayant entra\u00een\u00e9 une incapacit\u00e9 permanente au moins \u00e9gale \u00e0 10 % et titulaire d\u0027une rente",
        "03": "Titulaire d\u0027une pension d\u0027invalidit\u00e9 \u00e0 condition que l\u0027invalidit\u00e9 r\u00e9duise au moins des deux tiers sa capacit\u00e9 de travail",
        "04": "B\u00e9n\u00e9ficiaire mentionn\u00e9 \u00e0 l\u0027article L.241-2 du Code des pensions militaires d\u0027invalidit\u00e9 et des victimes de la guerre",
        "05": "B\u00e9n\u00e9ficiaire mentionn\u00e9 aux articles L.241-3 et L.241-4 du Code des pensions militaires d\u0027invalidit\u00e9 et des victimes de la guerre",
        "06": "Titulaire d\u0027une allocation ou d\u0027une rente d\u0027invalidit\u00e9 dans les conditions d\u00e9finies par la Loi n\u00b091-1389 du 31 d\u00e9cembre 1991",
        "07": 'Titulaire de la carte "mobilit\u00e9 inclusion" portant la mention "invalidit\u00e9" (L. 241-3 du Code de l\u0027action sociale et des familles)',
        "08": "Titulaire de l\u0027allocation aux adultes handicap\u00e9s",
        "09": "B\u00e9n\u00e9ficiaire mentionn\u00e9 aux articles L.241-5 et L.241-6 du Code des pensions militaires d\u0027invalidit\u00e9 et des victimes de guerre",
        "10": "Agent public reclass\u00e9 (3\u00e8me alin\u00e9a de l\u0027article L.323-5 du Code du travail)",
        "11": "Agent public b\u00e9n\u00e9ficiaire d\u0027une allocation temporaire d\u0027invalidit\u00e9 (4\u00e8me alin\u00e9a de l\u0027article L.323-5 du Code du travail)",
        "12": "Ayant droit \u00e0 la prestation de compensation du handicap, \u00e0 l\u0027allocation compensatrice pour tierce personne ou \u00e0 l\u0027allocation d\u0027\u00e9ducation de l\u0027enfant handicap\u00e9 b\u00e9n\u00e9ficiant d\u0027un stage (L.5212-7 du Code du travail)",
        "99": "Absence de statut BOETH",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_CasMiseDispositionExterneIndividuEtablissementAncien(str, Enum):
    INDIVIDU_EN_PORTAGE_SALARIAL = "01"  # Individu en portage salarial
    INDIVIDU_MIS_A_DISPOSITION_DANS_UN_ETABLISSEMENT_ADHERENT_DU_GROUPEMENT_D_EMPLOYEURS = (
        "02"  # Individu mis à disposition dans un établissement adhérent du groupement d'employeurs
    )
    INDIVIDU_D_UNE_ENTREPRISE_ADAPTEE_MIS_A_DISPOSITION = (
        "03"  # Individu d'une entreprise adaptée mis à disposition
    )
    INDIVIDU_D_UNE_AGENCE_DE_MANNEQUIN_MIS_A_DISPOSITION = (
        "04"  # Individu d’une agence de mannequin mis à disposition
    )
    INDIVIDU_D_UNE_ENTREPRISE_DE_TRAVAIL_A_TEMPS_PARTAGE_ETTP_OU_ETT_MIS_A_DISPOSITION_EN_CDI_EMPLOYABILITE = "05"  # Individu d’une entreprise de travail à temps partagé (ETTP ou ETT) mis à disposition en CDI employabilité
    INDIVIDU_D_UNE_ASSOCIATION_INTERMEDIAIRE_MIS_A_DISPOSITION = (
        "06"  # Individu d’une association intermédiaire mis à disposition
    )
    INDIVIDU_D_UNE_ENTREPRISE_DE_TRAVAIL_A_TEMPS_PARTAGE_ETTP_MIS_A_DISPOSITION_HORS_CDI_EMPLOYABILITE = "07"  # Individu d'une entreprise de travail à temps partagé (ETTP) mis à disposition hors CDI employabilité
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Individu en portage salarial",
        "02": "Individu mis \u00e0 disposition dans un \u00e9tablissement adh\u00e9rent du groupement d\u0027employeurs",
        "03": "Individu d\u0027une entreprise adapt\u00e9e mis \u00e0 disposition",
        "04": "Individu d\u2019une agence de mannequin mis \u00e0 disposition",
        "05": "Individu d\u2019une entreprise de travail \u00e0 temps partag\u00e9 (ETTP ou ETT) mis \u00e0 disposition en CDI employabilit\u00e9",
        "06": "Individu d\u2019une association interm\u00e9diaire mis \u00e0 disposition",
        "07": "Individu d\u0027une entreprise de travail \u00e0 temps partag\u00e9 (ETTP) mis \u00e0 disposition hors CDI employabilit\u00e9",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_FormeAmenagementTempsTravailActivitePartielleAncien(str, Enum):
    FORFAIT_HEBDOMADAIRE = "01"  # Forfait hebdomadaire
    AUTRE_TEMPS_DE_TRAVAIL_HEBDOMADAIRE = "02"  # Autre temps de travail hebdomadaire
    EQUIVALENT_A_35H_39H_MAYOTTE = "03"  # Equivalent à 35h - 39h (Mayotte)
    FORFAIT_MENSUEL = "04"  # Forfait mensuel
    FORFAIT_ANNUEL_EN_JOUR = "05"  # Forfait annuel en jour
    FORFAIT_ANNUEL_EN_HEURES = "06"  # Forfait annuel en heures
    CYCLE = "07"  # Cycle
    MODULATION = "08"  # Modulation
    AMENAGEMENT_DU_TEMPS_DE_TRAVAIL_LOI_DU_20_AOUT_2008 = (
        "09"  # Aménagement du temps de travail (Loi du 20 août 2008)
    )
    PERSONNEL_NAVIGANT_OU_AUTRES = "10"  # Personnel navigant ou autres
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Forfait hebdomadaire",
        "02": "Autre temps de travail hebdomadaire",
        "03": "Equivalent \u00e0 35h - 39h (Mayotte)",
        "04": "Forfait mensuel",
        "05": "Forfait annuel en jour",
        "06": "Forfait annuel en heures",
        "07": "Cycle",
        "08": "Modulation",
        "09": "Am\u00e9nagement du temps de travail (Loi du 20 ao\u00fbt 2008)",
        "10": "Personnel navigant ou autres",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class NiveauDiplomePrepare(str, Enum):
    NIVEAU_DE_FORMATION_EQUIVALENT_AU_CAP_CERTIFICAT_D_APTITUDE_PROFESSIONNELLE_OU_AU_BEP_BREVET_D_ETUDES_PROFESSIONNELLES = "03"  # Niveau de formation équivalent au CAP (certificat d'aptitude professionnelle) ou au BEP (brevet d'études professionnelles)
    FORMATION_DE_NIVEAU_DU_BAC_GENERAL_TECHNOLOGIQUE_OU_PROFESSIONNEL_DU_BREVET_DE_TECHNICIEN_BT_OU_DU_BREVET_PROFESSIONNEL = "04"  # Formation de niveau du bac (général, technologique ou professionnel), du brevet de technicien (BT) ou du brevet professionnel
    FORMATION_DE_NIVEAU_BAC_2_LICENCE_2_BTS_BREVET_DE_TECHNICIEN_SUPERIEUR_DUT_DIPLOME_UNIVERSITAIRE_DE_TECHNOLOGIE_ETC = "05"  # Formation de niveau bac+2 : licence 2, BTS (brevet de technicien supérieur), DUT (diplôme universitaire de technologie), etc.
    FORMATION_DE_NIVEAU_BAC_3_ET_BAC_4_LICENCE_3_LICENCE_PROFESSIONNELLE_MASTER_1_ETC = "06"  # Formation de niveau bac+3 et bac+4 : licence 3, licence professionnelle, master 1, etc.
    FORMATION_DE_NIVEAU_BAC_5_MASTER_2_DIPLOME_D_ETUDES_APPROFONDIES_DIPLOME_D_ETUDES_SUPERIEURES_SPECIALISEES_DIPLOME_D_INGENIEUR_ETC = "07"  # Formation de niveau bac+5 : master 2, diplôme d'études approfondies, diplôme d'études supérieures spécialisées, diplôme d'ingénieur, etc.
    FORMATION_DE_NIVEAU_BAC_8_DOCTORAT_HABILITATION_A_DIRIGER_DES_RECHERCHES_ETC = (
        "08"  # Formation de niveau bac+8 : doctorat, habilitation à diriger des recherches, etc.
    )

    __DESCRIPTIONS: dict[str, str] = {
        "03": "Niveau de formation \u00e9quivalent au CAP (certificat d\u0027aptitude professionnelle) ou au BEP (brevet d\u0027\u00e9tudes professionnelles)",
        "04": "Formation de niveau du bac (g\u00e9n\u00e9ral, technologique ou professionnel), du brevet de technicien (BT) ou du brevet professionnel",
        "05": "Formation de niveau bac+2 : licence 2, BTS (brevet de technicien sup\u00e9rieur), DUT (dipl\u00f4me universitaire de technologie), etc.",
        "06": "Formation de niveau bac+3 et bac+4 : licence 3, licence professionnelle, master 1, etc.",
        "07": "Formation de niveau bac+5 : master 2, dipl\u00f4me d\u0027\u00e9tudes approfondies, dipl\u00f4me d\u0027\u00e9tudes sup\u00e9rieures sp\u00e9cialis\u00e9es, dipl\u00f4me d\u0027ing\u00e9nieur, etc.",
        "08": "Formation de niveau bac+8 : doctorat, habilitation \u00e0 diriger des recherches, etc.",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class AncienCodeRegime(str, Enum):
    REGIME_SPECIAL_DE_LA_SNCF = "134"  # régime spécial de la SNCF
    REGIME_SPECIAL_DE_LA_RATP = "135"  # régime spécial de la RATP
    ETABLISSEMENT_DES_INVALIDES_DE_LA_MARINE_ENIM = (
        "136"  # établissement des invalides de la marine (ENIM)
    )
    MINEURS_OU_ASSIMILES_CANSSM = "137"  # mineurs ou assimilés (CANSSM)
    REGIME_SPECIAL_DES_INDUSTRIES_ELECTRIQUES_ET_GAZIERES = (
        "147"  # régime spécial des industries électriques et gazières
    )
    REGIME_GENERAL_CNAM = "200"  # régime général (CNAM)
    REGIME_AGRICOLE_CCMSA_OU_C3A = "300"  # régime agricole (CCMSA ou C3A)
    RISQUE_AT_MP_PRIS_EN_CHARGE_TOTALEMENT_PAR_L_EMPLOYEUR_HORS_PERIMETRE_ETAT = (
        "401"  # risque AT/MP pris en charge totalement par l'employeur (hors périmètre Etat)
    )
    RISQUE_AT_MP_PRIS_EN_CHARGE_PARTIELLEMENT_PAR_L_EMPLOYEUR_HORS_PERIMETRE_ETAT = (
        "402"  # risque AT/MP pris en charge partiellement par l'employeur (hors périmètre Etat)
    )
    AUTRE_REGIME = "900"  # autre régime
    SANS_REGIME_OBLIGATOIRE_FONCTIONNAIRE_DES_TROIS_FONCTIONS_PUBLIQUES_ET_CONTRACTUELS_DONT_LE_RISQUE_AT_EST_COUVERT_PAR_L_ETAT = "999"  # sans régime obligatoire (fonctionnaire des trois fonctions publiques et contractuels dont le risque AT est couvert par l'Etat)

    __DESCRIPTIONS: dict[str, str] = {
        "134": "r\u00e9gime sp\u00e9cial de la SNCF",
        "135": "r\u00e9gime sp\u00e9cial de la RATP",
        "136": "\u00e9tablissement des invalides de la marine (ENIM)",
        "137": "mineurs ou assimil\u00e9s (CANSSM)",
        "147": "r\u00e9gime sp\u00e9cial des industries \u00e9lectriques et gazi\u00e8res",
        "200": "r\u00e9gime g\u00e9n\u00e9ral (CNAM)",
        "300": "r\u00e9gime agricole (CCMSA ou C3A)",
        "401": "risque AT/MP pris en charge totalement par l\u0027employeur (hors p\u00e9rim\u00e8tre Etat)",
        "402": "risque AT/MP pris en charge partiellement par l\u0027employeur (hors p\u00e9rim\u00e8tre Etat)",
        "900": "autre r\u00e9gime",
        "999": "sans r\u00e9gime obligatoire (fonctionnaire des trois fonctions publiques et contractuels dont le risque AT est couvert par l\u0027Etat)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Type_Usage(str, Enum):
    PAIEMENT_AIDE_ASP = "01"  # Paiement aide ASP

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Paiement aide ASP",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class TypeBoeth(str, Enum):
    BOETH_INTERIMAIRES = "01"  # BOETH intérimaires
    BOETH_SALARIES_D_UN_GROUPEMENT_D_EMPLOYEURS_MIS_A_DISPOSITION = (
        "02"  # BOETH salariés d'un groupement d'employeurs mis à disposition
    )
    BOETH_STAGIAIRES_N_AYANT_PAS_FAIT_L_OBJET_D_UNE_DECLARATION_NOMINATIVE_AU_PREALABLE = (
        "03"  # BOETH stagiaires n’ayant pas fait l’objet d’une déclaration nominative au préalable
    )
    BOETH_SALARIES_D_UNE_ASSOCIATION_INTERMEDIAIRE_MIS_A_DISPOSITION = (
        "04"  # BOETH salariés d’une association intermédiaire mis à disposition
    )
    BOETH_SALARIES_D_UNE_AGENCE_DE_MANNEQUIN_MIS_A_DISPOSITION = (
        "05"  # BOETH salariés d’une agence de mannequin mis à disposition
    )
    BOETH_SALARIES_D_UNE_ENTREPRISE_DE_TRAVAIL_A_TEMPS_PARTAGE_ETTP_MIS_A_DISPOSITION = (
        "06"  # BOETH salariés d’une entreprise de travail à temps partagé (ETTP) mis à disposition
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "BOETH int\u00e9rimaires",
        "02": "BOETH salari\u00e9s d\u0027un groupement d\u0027employeurs mis \u00e0 disposition",
        "03": "BOETH stagiaires n\u2019ayant pas fait l\u2019objet d\u2019une d\u00e9claration nominative au pr\u00e9alable",
        "04": "BOETH salari\u00e9s d\u2019une association interm\u00e9diaire mis \u00e0 disposition",
        "05": "BOETH salari\u00e9s d\u2019une agence de mannequin mis \u00e0 disposition",
        "06": "BOETH salari\u00e9s d\u2019une entreprise de travail \u00e0 temps partag\u00e9 (ETTP) mis \u00e0 disposition",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class AncientStatutEmploiSalarie(str, Enum):
    FP_FONCTIONNAIRE = "01"  # [FP] Fonctionnaire
    FP_CONTRACTUEL_DE_LA_FONCTION_PUBLIQUE = "02"  # [FP] Contractuel de la Fonction publique
    STATUTAIRE = "03"  # Statutaire
    NON_STATUTAIRE = "04"  # Non statutaire
    PERSONNEL_MEDICAL_HOSPITALIER = "06"  # Personnel médical hospitalier
    MEDECIN_SANS_STATUT_HOSPITALIER = "07"  # Médecin sans statut hospitalier
    FP_FONCTIONNAIRE_STAGIAIRE = "08"  # [FP] Fonctionnaire stagiaire
    FP_OUVRIER_D_ETAT = "09"  # [FP] Ouvrier d'Etat
    FP_MILITAIRE = "10"  # [FP] Militaire
    FP_PARCOURS_D_ACCES_AUX_CARRIERES_PACTE = "11"  # [FP] Parcours d'accès aux carrières (Pacte)
    FP_MILITAIRE_DE_RESERVE = "12"  # [FP] Militaire de réserve
    NON_CONCERNE = "99"  # Non concerné

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] Fonctionnaire",
        "02": "[FP] Contractuel de la Fonction publique",
        "03": "Statutaire",
        "04": "Non statutaire",
        "06": "Personnel m\u00e9dical hospitalier",
        "07": "M\u00e9decin sans statut hospitalier",
        "08": "[FP] Fonctionnaire stagiaire",
        "09": "[FP] Ouvrier d\u0027Etat",
        "10": "[FP] Militaire",
        "11": "[FP] Parcours d\u0027acc\u00e8s aux carri\u00e8res (Pacte)",
        "12": "[FP] Militaire de r\u00e9serve",
        "99": "Non concern\u00e9",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Type_ancien_code_emplois_multiples(str, Enum):
    EMPLOI_UNIQUE = "01"  # emploi unique
    EMPLOIS_MULTIPLES = "02"  # emplois multiples
    SITUATION_NON_CONNUE = "03"  # situation non connue

    __DESCRIPTIONS: dict[str, str] = {
        "01": "emploi unique",
        "02": "emplois multiples",
        "03": "situation non connue",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Type_ancien_code_emplois_multiples_2(str, Enum):
    EMPLOYEUR_UNIQUE = "01"  # employeur unique
    EMPLOYEURS_MULTIPLES = "02"  # employeurs multiples
    SITUATION_NON_CONNUE = "03"  # situation non connue

    __DESCRIPTIONS: dict[str, str] = {
        "01": "employeur unique",
        "02": "employeurs multiples",
        "03": "situation non connue",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class NaturePoste(str, Enum):
    FP_TEMPS_COMPLET = "01"  # [FP] Temps complet
    FP_TEMPS_NON_COMPLET = "02"  # [FP] Temps non complet
    REGIME_VSDL_WEEK_ENDISTE = "03"  # Régime VSDL (Week-endiste)

    __DESCRIPTIONS: dict[str, str] = {
        "01": "[FP] Temps complet",
        "02": "[FP] Temps non complet",
        "03": "R\u00e9gime VSDL (Week-endiste)",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Motifs_Recours(str, Enum):
    REMPLACEMENT_D_UN_SALARIE = "01"  # Remplacement d'un salarié
    ACCROISSEMENT_TEMPORAIRE_DE_L_ACTIVITE_DE_L_ENTREPRISE = (
        "02"  # Accroissement temporaire de l'activité de l'entreprise
    )
    EMPLOIS_A_CARACTERE_SAISONNIER = "03"  # Emplois à caractère saisonnier
    CONTRAT_VENDANGES = "04"  # Contrat vendanges
    CONTRAT_D_USAGE = "05"  # Contrat d’usage
    CONTRAT_A_DUREE_DETERMINEE_A_OBJET_DEFINI = "06"  # Contrat à durée déterminée à objet défini
    REMPLACEMENT_D_UN_CHEF_D_ENTREPRISE_ARTISANALE_INDUSTRIELLE_OU_COMMERCIALE_D_UNE_PERSONNE_EXERCANT_UNE_PROFESSION_LIBERALE_DE_SON_CONJOINT_PARTICIPANT_EFFECTIVEMENT_A_L_ACTIVITE_DE_L_ENTREPRISE_A_TITRE_PROFESSIONNEL_ET_HABITUEL_OU_D_UN_ASSOCIE_NON_SALARIE_D_UNE_SOCIETE_CIVILE_PROFESSIONNELLE_D_UNE_SOCIETE_CIVILE_DE_MOYENS_OU_D_UNE_SOCIETE_D_EXERCICE_LIBERAL = "07"  # Remplacement d'un chef d'entreprise (« artisanale, industrielle ou commerciale, d'une personne exerçant une profession libérale, de son conjoint participant effectivement à l'activité de l'entreprise à titre professionnel et habituel ou d'un associé non salarié d'une société civile professionnelle, d'une société civile de moyens ou d'une société d'exercice libéral »)
    REMPLACEMENT_DU_CHEF_D_UNE_EXPLOITATION_AGRICOLE_OU_D_UNE_ENTREPRISE_MENTIONNEE_AUX_1_A_4_DE_L_ARTICLE_L_722_1_DU_CODE_RURAL_ET_DE_LA_PECHE_MARITIME_D_UN_AIDE_FAMILIAL_D_UN_ASSOCIE_D_EXPLOITATION_OU_DE_LEUR_CONJOINT_MENTIONNE_A_L_ARTICLE_L_722_10_DU_MEME_CODE_DES_LORS_QU_IL_PARTICIPE_EFFECTIVEMENT_A_L_ACTIVITE_DE_L_EXPLOITATION_AGRICOLE_OU_DE_L_ENTREPRISE = "08"  # Remplacement du chef d'une exploitation agricole (« ou d'une entreprise mentionnée aux 1° à 4° de l'article L. 722-1 du code rural et de la pêche maritime, d'un aide familial, d'un associé d'exploitation, ou de leur conjoint mentionné à l'article L. 722-10 du même code dès lors qu'il participe effectivement à l'activité de l'exploitation agricole ou de l'entreprise »)
    RECRUTEMENT_DE_PERSONNES_SANS_EMPLOI_RENCONTRANT_DES_DIFFICULTES_SOCIALES_ET_PROFESSIONNELLES_PARTICULIERES = "09"  # Recrutement de personnes sans emploi rencontrant des difficultés sociales et professionnelles particulières
    COMPLEMENT_DE_FORMATION_PROFESSIONNELLE_AU_SALARIE = (
        "10"  # Complément de formation professionnelle au salarié
    )
    FORMATION_PROFESSIONNELLE_AU_SALARIE_PAR_LA_VOIE_DE_L_APPRENTISSAGE_EN_VUE_DE_L_OBTENTION_D_UNE_QUALIFICATION_PROFESSIONNELLE_SANCTIONNEE_PAR_UN_DIPLOME_OU_UN_TITRE_A_FINALITE_PROFESSIONNELLE_ENREGISTRE_AU_REPERTOIRE_NATIONAL_DES_CERTIFICATIONS_PROFESSIONNELLES = "11"  # Formation professionnelle au salarié par la voie de l'apprentissage, en vue de l'obtention d'une qualification professionnelle sanctionnée par un diplôme ou un titre à finalité professionnelle enregistré au répertoire national des certifications professionnelles
    REMPLACEMENT_D_UN_SALARIE_PASSE_PROVISOIREMENT_A_TEMPS_PARTIEL = (
        "12"  # Remplacement d’un salarié passé provisoirement à temps partiel
    )
    ATTENTE_DE_LA_SUPPRESSION_DEFINITIVE_DU_POSTE_DU_SALARIE_AYANT_QUITTE_DEFINITIVEMENT_L_ENTREPRISE = "13"  # Attente de la suppression définitive du poste du salarié ayant quitté définitivement l’entreprise
    CONTRAT_DE_VOYAGE = "14"  # Contrat de voyage
    RECRUTEMENT_D_UN_INTERIMAIRE_EN_SA_QUALITE_DE_BOETH = (
        "15"  # Recrutement d'un intérimaire en sa qualité de BOETH
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Remplacement d\u0027un salari\u00e9",
        "02": "Accroissement temporaire de l\u0027activit\u00e9 de l\u0027entreprise",
        "03": "Emplois \u00e0 caract\u00e8re saisonnier",
        "04": "Contrat vendanges",
        "05": "Contrat d\u2019usage",
        "06": "Contrat \u00e0 dur\u00e9e d\u00e9termin\u00e9e \u00e0 objet d\u00e9fini",
        "07": "Remplacement d\u0027un chef d\u0027entreprise (\u00ab artisanale, industrielle ou commerciale, d\u0027une personne exer\u00e7ant une profession lib\u00e9rale, de son conjoint participant effectivement \u00e0 l\u0027activit\u00e9 de l\u0027entreprise \u00e0 titre professionnel et habituel ou d\u0027un associ\u00e9 non salari\u00e9 d\u0027une soci\u00e9t\u00e9 civile professionnelle, d\u0027une soci\u00e9t\u00e9 civile de moyens ou d\u0027une soci\u00e9t\u00e9 d\u0027exercice lib\u00e9ral \u00bb)",
        "08": "Remplacement du chef d\u0027une exploitation agricole (\u00ab ou d\u0027une entreprise mentionn\u00e9e aux 1\u00b0 \u00e0 4\u00b0 de l\u0027article L. 722-1 du code rural et de la p\u00eache maritime, d\u0027un aide familial, d\u0027un associ\u00e9 d\u0027exploitation, ou de leur conjoint mentionn\u00e9 \u00e0 l\u0027article L. 722-10 du m\u00eame code d\u00e8s lors qu\u0027il participe effectivement \u00e0 l\u0027activit\u00e9 de l\u0027exploitation agricole ou de l\u0027entreprise \u00bb)",
        "09": "Recrutement de personnes sans emploi rencontrant des difficult\u00e9s sociales et professionnelles particuli\u00e8res",
        "10": "Compl\u00e9ment de formation professionnelle au salari\u00e9",
        "11": "Formation professionnelle au salari\u00e9 par la voie de l\u0027apprentissage, en vue de l\u0027obtention d\u0027une qualification professionnelle sanctionn\u00e9e par un dipl\u00f4me ou un titre \u00e0 finalit\u00e9 professionnelle enregistr\u00e9 au r\u00e9pertoire national des certifications professionnelles",
        "12": "Remplacement d\u2019un salari\u00e9 pass\u00e9 provisoirement \u00e0 temps partiel",
        "13": "Attente de la suppression d\u00e9finitive du poste du salari\u00e9 ayant quitt\u00e9 d\u00e9finitivement l\u2019entreprise",
        "14": "Contrat de voyage",
        "15": "Recrutement d\u0027un int\u00e9rimaire en sa qualit\u00e9 de BOETH",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class CodeResultatRNIAM(str, Enum):
    LE_SALARIE_EST_RATTACHE_AU_RNIAM = "00"  # le salarié est rattaché au RNIAM
    LE_SALARIE_EST_CONNU_AU_SNGI_MAIS_INCONNU_AU_RNIAM = (
        "10"  # le salarié est connu au SNGI mais inconnu au RNIAM
    )
    LE_SALARIE_EST_INCONNU_AU_SNGI = "20"  # le salarié est inconnu au SNGI

    __DESCRIPTIONS: dict[str, str] = {
        "00": "le salari\u00e9 est rattach\u00e9 au RNIAM",
        "10": "le salari\u00e9 est connu au SNGI mais inconnu au RNIAM",
        "20": "le salari\u00e9 est inconnu au SNGI",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class Sortie_DSN(str, Enum):
    DEMANDE_DE_SORTIE_DE_LA_DSN = "01"  # Demande de sortie de la DSN

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Demande de sortie de la DSN",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_SaisieAdmin_Etat_SATD(str, Enum):
    FIN_OU_SANS_DROITS = "01"  # Fin ou sans droits
    POSITIF_SANS_REGLEMENT = "02"  # Positif sans règlement
    POSITIF_AVEC_REGLEMENT_PARTIEL_AVEC_CONCURRENCE = (
        "03"  # Positif avec règlement partiel avec concurrence
    )
    POSITIF_AVEC_REGLEMENT_PARTIEL_SANS_CONCURRENCE = (
        "04"  # Positif avec règlement partiel sans concurrence
    )
    POSITIF_AVEC_REGLEMENT_TOTAL_AVEC_CONCURRENCE = (
        "05"  # Positif avec règlement total avec concurrence
    )
    POSITIF_AVEC_REGLEMENT_TOTAL_SANS_CONCURRENCE = (
        "06"  # Positif avec règlement total sans concurrence
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Fin ou sans droits",
        "02": "Positif sans r\u00e8glement",
        "03": "Positif avec r\u00e8glement partiel avec concurrence",
        "04": "Positif avec r\u00e8glement partiel sans concurrence",
        "05": "Positif avec r\u00e8glement total avec concurrence",
        "06": "Positif avec r\u00e8glement total sans concurrence",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_VersementIndividu_MDsnMRFCTU(str, Enum):
    ELEMENTS_DE_LA_DSN_MENSUELLE_PORTANT_LES_DERNIERS_ELEMENTS_DECLARES_DANS_LE_FCTU = (
        "01"  # Eléments de la DSN mensuelle portant les derniers éléments déclarés dans le FCTU
    )
    ELEMENTS_DE_LA_DECLARATION_PRECEDANT_LA_DSN_MENSUELLE_PORTANT_LES_DERNIERS_ELEMENTS_DECLARES_DANS_LE_FCTU = "02"  # Eléments de la déclaration précédant la DSN mensuelle portant les derniers éléments déclarés dans le FCTU

    __DESCRIPTIONS: dict[str, str] = {
        "01": "El\u00e9ments de la DSN mensuelle portant les derniers \u00e9l\u00e9ments d\u00e9clar\u00e9s dans le FCTU",
        "02": "El\u00e9ments de la d\u00e9claration pr\u00e9c\u00e9dant la DSN mensuelle portant les derniers \u00e9l\u00e9ments d\u00e9clar\u00e9s dans le FCTU",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class NewEnumeration299(str, Enum):
    HEURE_S_COMPLEMENTAIRE_S_OU_SUPPLEMENTAIRE_S_EXONEREE_S_FISCALEMENT_Y_COMPRIS_JOURNEES_DE_RTT_MONETISEES = "01"  # Heure(s) complémentaire(s) ou supplémentaire(s) exonérée(s) fiscalement (y compris journées de RTT monétisées)
    MONTANT_NET_SOCIAL = "03"  # Montant net social
    POTENTIEL_NOUVEAU_TYPE_D_ELEMENT_DE_REVENU_CALCULE_EN_NET_A = (
        "04"  # Potentiel nouveau type d'élément de revenu calculé en net A
    )
    POTENTIEL_NOUVEAU_TYPE_D_ELEMENT_DE_REVENU_CALCULE_EN_NET_B = (
        "05"  # Potentiel nouveau type d'élément de revenu calculé en net B
    )
    POTENTIEL_NOUVEAU_TYPE_D_ELEMENT_DE_REVENU_CALCULE_EN_NET_C = (
        "06"  # Potentiel nouveau type d'élément de revenu calculé en net C
    )
    POTENTIEL_NOUVEAU_TYPE_D_ELEMENT_DE_REVENU_CALCULE_EN_NET_D = (
        "07"  # Potentiel nouveau type d'élément de revenu calculé en net D
    )
    POTENTIEL_NOUVEAU_TYPE_D_ELEMENT_DE_REVENU_CALCULE_EN_NET_E = (
        "08"  # Potentiel nouveau type d'élément de revenu calculé en net E
    )
    IJSS_SUBROGEES_PRISES_EN_COMPTE_DANS_LE_CALCUL_DU_MNS = (
        "10"  # IJSS subrogées prises en compte dans le calcul du MNS
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Heure(s) compl\u00e9mentaire(s) ou suppl\u00e9mentaire(s) exon\u00e9r\u00e9e(s) fiscalement (y compris journ\u00e9es de RTT mon\u00e9tis\u00e9es)",
        "03": "Montant net social",
        "04": "Potentiel nouveau type d\u0027\u00e9l\u00e9ment de revenu\u00a0calcul\u00e9 en net A",
        "05": "Potentiel nouveau type d\u0027\u00e9l\u00e9ment\u00a0de\u00a0revenu\u00a0calcul\u00e9\u00a0en\u00a0net B",
        "06": "Potentiel nouveau type d\u0027\u00e9l\u00e9ment\u00a0de\u00a0revenu\u00a0calcul\u00e9\u00a0en\u00a0net C",
        "07": "Potentiel nouveau type d\u0027\u00e9l\u00e9ment\u00a0de\u00a0revenu\u00a0calcul\u00e9\u00a0en\u00a0net D",
        "08": "Potentiel nouveau type d\u0027\u00e9l\u00e9ment\u00a0de\u00a0revenu\u00a0calcul\u00e9\u00a0en\u00a0net E",
        "10": "IJSS subrog\u00e9es prises en compte dans le calcul du MNS",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Code_Civilite(str, Enum):
    MONSIEUR = "01"  # Monsieur
    MADAME = "02"  # Madame

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Monsieur",
        "02": "Madame",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Substitution_Nature(str, Enum):
    DSN_DE_SUBSTITUTION_SUITE_A_CONTROLE_COMPTABLE_D_ASSIETTE = (
        "01"  # DSN de substitution suite à contrôle (comptable d’assiette)
    )
    DSN_DE_SUBSTITUTION_SUITE_A_FIABILISATION_CRM = (
        "02"  # DSN de substitution suite à fiabilisation (CRM)
    )
    DSN_DE_SUBSTITUTION_SUITE_A_REDRESSEMENT_LCTI = (
        "03"  # DSN de substitution suite à redressement LCTI
    )

    __DESCRIPTIONS: dict[str, str] = {
        "01": "DSN de substitution suite \u00e0 contr\u00f4le (comptable d\u2019assiette)",
        "02": "DSN de substitution suite \u00e0 fiabilisation (CRM)",
        "03": "DSN de substitution suite \u00e0 redressement LCTI",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


class DSN_Refus_CDI(str, Enum):
    PROPOSITION_REFUSEE = "01"  # Proposition refusée

    __DESCRIPTIONS: dict[str, str] = {
        "01": "Proposition refus\u00e9e",
    }

    def get_description(self) -> str:
        """Retourne la description lisible de la valeur."""
        return type(self).__DESCRIPTIONS.get(self.value, self.value)


def get_enum_description(enum_class: type[Enum], value: str) -> str | None:
    """
    Retourne la description pour une valeur d'enum.

    Args:
        enum_class: La classe enum
        value: La valeur de l'enum (code)

    Returns:
        La description lisible ou None si non trouvée
    """
    try:
        member = enum_class(value)
        return member.get_description()
    except ValueError:
        return None
