# dsn-tools

Parseur et types Python pour fichiers DSN (Données Sociales Nominatives).

## Installation

```bash
pip install dsn-tools
# ou avec uv
uv add dsn-tools
```

## Utilisation rapide

### En ligne de commande

```bash
# Parser un fichier DSN
dsn-tools declaration.dsn

# Sortie JSON
dsn-tools declaration.dsn --json

# Avec validation
dsn-tools declaration.dsn --validate

# Sans installer (avec uv)
uvx dsn-tools declaration.dsn --json
```

### En Python

```python
from dsn_tools import DSNParser

parser = DSNParser()
message = parser.parse_file("declaration.dsn")

# Accès aux données
print(message.header.nom_du_logiciel_utilise)
print(message.header.code_envoi_du_fichier_dessai_ou_reel)

# Export JSON
json_output = message.to_json()

# Conversion en dictionnaire
data = message.to_dict()
```

## Caractéristiques

- ✅ **59 blocs DSN** supportés (CT2026)
- ✅ **Types Python** fortement typés avec dataclasses
- ✅ **Validation** des données avec regex
- ✅ **Export JSON** natif
- ✅ **Enums** avec descriptions lisibles (pas seulement les codes)
- ✅ **CLI** simple et rapide

## Exemple de sortie JSON

```json
{
  "header": {
    "nom_du_logiciel_utilise": "MonLogiciel",
    "code_envoi_du_fichier_dessai_ou_reel": "envoi fichier réel",
    "type_de_lenvoi": "envoi normal"
  },
  "declarations": [...],
  "footer": {...}
}
```

## Licence

WTFPL - Do What The Fuck You Want To Public License
