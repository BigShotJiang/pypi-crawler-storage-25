def _list_all_apis(module, apis=None, seen_modules=None):
    import inspect

    apis = apis or set()
    seen_modules = seen_modules or set()
    mname = module.__name__
    top_level = mname.split(".")[0]

    for kind in ["class_or_fun", "mod"]:
        for name in dir(module):
            full_name = f"{mname}.{name}"

            if name.startswith("_") or full_name == "jax_galsim.core":
                continue

            obj = getattr(module, name)

            if kind == "mod" and inspect.ismodule(obj):
                if (
                    full_name not in seen_modules
                    and (not inspect.isbuiltin(obj))
                    and hasattr(obj, "__file__")
                    and top_level in obj.__file__.split("/")
                ):
                    seen_modules.add(full_name)
                    _list_all_apis(obj, apis=apis, seen_modules=seen_modules)
            elif kind == "class_or_fun" and (
                inspect.isclass(obj)
                or inspect.isfunction(obj)
                or inspect.isroutine(obj)
            ):
                if not any(api.endswith(f".{name}") for api in apis):
                    apis.add(full_name)

    return apis


def _write_to_docs(missing_apis, jax_galsim_apis, cov_frac):
    with open("api-coverage.rst", "r") as f:
        lines = f.readlines()

    start = lines.index("Supported APIs\n") + 1

    middle_lines = ["\n"]
    for api in sorted(jax_galsim_apis):
        middle_lines.append(f"- ``{api}``\n")
    middle_lines.append("\n")

    with open("api-coverage.rst", "w") as f:
        f.writelines(lines[: start + 1])
        f.writelines(middle_lines)
        f.writelines(lines[start + 1 :])


def update_api_coverage():
    import galsim

    import jax_galsim

    galsim_apis = _list_all_apis(galsim)
    assert all(api.startswith("galsim.") for api in galsim_apis)

    jax_galsim_apis = _list_all_apis(jax_galsim)
    assert all(api.startswith("jax_galsim.") for api in jax_galsim_apis)

    # make the import prefix match and subset to what is in both
    jax_galsim_apis = {"galsim" + api[len("jax_galsim") :] for api in jax_galsim_apis}
    jax_galsim_apis = galsim_apis & jax_galsim_apis

    missing_apis = galsim_apis - jax_galsim_apis
    assert len(missing_apis) + len(jax_galsim_apis) == len(galsim_apis)

    cov_frac = 1.0 - len(missing_apis) / len(galsim_apis)

    _write_to_docs(missing_apis, jax_galsim_apis, cov_frac)
