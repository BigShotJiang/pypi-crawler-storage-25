"""IR builder (DESIGN §6 slice 3) — (OpenAPI doc + Stainless config) -> API.

This is the moat. By the time it returns:

  * every `components/schemas/<name>` is a named `Model`;
  * every `$ref` to a component is a `ModelRef` — never followed, which makes
    type construction finite and recursion-safe (DESIGN §3: ModelRef is the
    cycle-breaker; real recursion only ever goes through named refs);
  * `allOf` envelopes are merged (delegated to the resolver);
  * cardinality is 3-valued — required, optional, nullable are independent;
  * resources/methods/auth/pagination/streaming are the config's idiomatic
    overlay applied on top of the flat spec.

No fallbacks: a config endpoint absent from the spec is a loud IRBuildError.
"""

from __future__ import annotations

from stainful.config.model import Config, MethodConfig, ResourceConfig
from stainful.errors import IRBuildError, SourceLoc
from stainful.ir.model import (
    API,
    BodyShape,
    ContentType,
    HTTPVerb,
    Method,
    PaginationIntent,
    PaginationStyle,
    Resource,
    SecurityScheme,
    StreamingIntent,
    StreamingTransport,
)
from stainful.ir.types import (
    AnyType,
    ArrayType,
    Discriminator,
    EnumMember,
    EnumType,
    MapType,
    Model,
    ModelRef,
    NullType,
    ObjectType,
    PrimitiveKind,
    PrimitiveType,
    Property,
    Type,
    UnionType,
)
from stainful.openapi.loader import OpenAPIDocument
from stainful.openapi.resolver import flatten_allof, resolve_ref

_SCHEMA_PREFIX = "#/components/schemas/"


def _strip_ref(s: str) -> str:
    """Both `Reference` and `#/components/schemas/Reference` are valid
    shared-model values in real configs — normalize to the bare name."""
    return s[len(_SCHEMA_PREFIX):] if s.startswith(_SCHEMA_PREFIX) else s

# OpenAPI (type, format) -> IR primitive.
_STRING_FORMATS = {
    "date": PrimitiveKind.DATE,
    "date-time": PrimitiveKind.DATETIME,
    "uuid": PrimitiveKind.UUID,
    "byte": PrimitiveKind.BYTES,
    "binary": PrimitiveKind.BYTES,
}
_CONTENT_TYPES = {
    "application/json": ContentType.JSON,
    "multipart/form-data": ContentType.MULTIPART,
    "application/x-www-form-urlencoded": ContentType.FORM,
    "application/octet-stream": ContentType.BINARY,
}


class _Builder:
    def __init__(self, doc: OpenAPIDocument, config: Config) -> None:
        self.doc = doc
        self.config = config
        self.loc = SourceLoc(doc.source)
        self.ops = {(o.verb, o.path): o for o in doc.operations()}
        # component schemas declared shared via config `$shared.models`
        self._shared_components = {
            mc.openapi_ref for mc in config.shared_models.values() if mc.openapi_ref
        }

    # --- type construction (the core) -------------------------------------
    def _is_nullable(self, schema: dict) -> bool:
        # 3.0 `nullable: true`; 3.1 `type: [..., "null"]`.
        if schema.get("nullable") is True:
            return True
        t = schema.get("type")
        return isinstance(t, list) and "null" in t

    def _primitive(self, schema: dict) -> Type:
        t = schema.get("type")
        if isinstance(t, list):  # 3.1 type arrays — drop the "null" sentinel
            non_null = [x for x in t if x != "null"]
            t = non_null[0] if non_null else None
        fmt = schema.get("format")
        if t == "string":
            return PrimitiveType(_STRING_FORMATS.get(fmt, PrimitiveKind.STRING), fmt)
        if t == "integer":
            return PrimitiveType(PrimitiveKind.INTEGER, fmt)
        if t == "number":
            kind = PrimitiveKind.DECIMAL if fmt == "decimal" else PrimitiveKind.NUMBER
            return PrimitiveType(kind, fmt)
        if t == "boolean":
            return PrimitiveType(PrimitiveKind.BOOLEAN, fmt)
        if t == "null":
            return NullType()
        return AnyType()

    def _discriminator(self, schema: dict) -> Discriminator | None:
        d = schema.get("discriminator")
        if not isinstance(d, dict) or "propertyName" not in d:
            return None
        mapping = {}
        for tag, ref in (d.get("mapping", {}) or {}).items():
            name = ref[len(_SCHEMA_PREFIX):] if ref.startswith(_SCHEMA_PREFIX) else ref
            mapping[tag] = name
        return Discriminator(property_name=d["propertyName"], mapping=mapping)

    def _object(self, schema: dict) -> Type:
        required = set(schema.get("required", []) or [])
        props: list[Property] = []
        for pname, pschema in (schema.get("properties", {}) or {}).items():
            props.append(
                Property(
                    name=pname,
                    type=self._type(pschema),
                    required=pname in required,
                    nullable=self._is_nullable(pschema),
                    docs=pschema.get("description") if isinstance(pschema, dict) else None,
                    deprecated=bool(
                        isinstance(pschema, dict) and pschema.get("deprecated")
                    ),
                    default=pschema.get("default") if isinstance(pschema, dict) else None,
                )
            )
        extra: Type | None = None
        ap = schema.get("additionalProperties")
        if isinstance(ap, dict):
            extra = self._type(ap)
        elif ap is True:
            extra = AnyType()
        if not props and extra is not None:
            return MapType(value=extra)
        return ObjectType(properties=tuple(props), extra=extra)

    def _type(self, schema: object) -> Type:
        """OpenAPI schema -> IR Type. Component $ref => ModelRef (never followed)."""
        if not isinstance(schema, dict) or not schema:
            return AnyType()

        if "$ref" in schema:
            ref = schema["$ref"]
            if ref.startswith(_SCHEMA_PREFIX):
                return ModelRef(name=ref[len(_SCHEMA_PREFIX):])  # cycle-break
            # non-component internal ref: resolve one hop and build inline
            return self._type(resolve_ref(self.doc, ref).target)

        if "allOf" in schema:
            # Split shared-$ref members into base classes (Stainless emits
            # `class XResponse(ResponseWrapper): ...`); merge only the rest.
            members = schema["allOf"]
            bases: list[ModelRef] = []
            rest = []
            for m in members:
                ref = isinstance(m, dict) and m.get("$ref")
                if ref and ref.startswith(_SCHEMA_PREFIX) and (
                    ref[len(_SCHEMA_PREFIX):] in self._shared_components
                ):
                    bases.append(ModelRef(name=ref[len(_SCHEMA_PREFIX):]))
                else:
                    rest.append(m)
            merged = flatten_allof(
                self.doc, {**{k: v for k, v in schema.items() if k != "allOf"},
                           "allOf": rest} if rest else
                {k: v for k, v in schema.items() if k != "allOf"}
            )
            obj = self._object(merged)
            if bases and isinstance(obj, ObjectType):
                return ObjectType(
                    properties=obj.properties, extra=obj.extra,
                    bases=tuple(bases),
                )
            return obj

        for key in ("oneOf", "anyOf"):
            if key in schema:
                variants = tuple(self._type(v) for v in schema[key])
                return UnionType(
                    variants=variants, discriminator=self._discriminator(schema)
                )

        if "enum" in schema:
            base = self._primitive(schema)
            if not isinstance(base, PrimitiveType):
                base = PrimitiveType(PrimitiveKind.STRING)
            members = tuple(
                EnumMember(name=str(v), value=v) for v in schema["enum"]
            )
            return EnumType(name="", base=base, members=members)

        t = schema.get("type")
        tl = t if isinstance(t, list) else [t]
        if "array" in tl:
            return ArrayType(item=self._type(schema.get("items", {})))
        if "object" in tl or "properties" in schema or "additionalProperties" in schema:
            return self._object(schema)
        return self._primitive(schema)

    # --- models ------------------------------------------------------------
    def _models(self) -> dict[str, Model]:
        models: dict[str, Model] = {}
        for name, schema in self.doc.schemas.items():
            ir_type = self._type(schema)
            # name anonymous enums after their owning model
            if isinstance(ir_type, EnumType) and not ir_type.name:
                ir_type = EnumType(name=name, base=ir_type.base, members=ir_type.members)
            models[name] = Model(
                name=name,
                type=ir_type,
                docs=schema.get("description") if isinstance(schema, dict) else None,
            )
        return models

    # --- params / body / responses ----------------------------------------
    def _param(self, p: dict) -> Property:
        sch = p.get("schema", {}) or {}
        return Property(
            name=p["name"],
            type=self._type(sch),
            required=bool(p.get("required", False)),
            nullable=self._is_nullable(sch),
            docs=p.get("description"),
        )

    def _body(self, request_body: dict | None) -> BodyShape | None:
        if not request_body:
            return None
        content = request_body.get("content", {}) or {}
        # Multi-content detection: spec declares 2+ content shapes AND one
        # of them is multipart. The emitter handles this with one method
        # whose runtime extracts file-like values from the body — if
        # present, send multipart; else send the primary (JSON) shape.
        # Oracle: openai-python's `skills.create` / `containers.files.create`.
        json_media = "application/json"
        multipart_media = "multipart/form-data"
        is_multi = (
            len([m for m in content if m in _CONTENT_TYPES]) > 1
            and multipart_media in content
        )
        if is_multi and json_media in content:
            # Multipart shape is the superset (JSON's fields are typically
            # a subset; multipart adds `files`/etc.) — use it as the IR
            # type so the method signature exposes file params. The
            # runtime auto-detects at call time: if file-like values are
            # actually present, send multipart; else send JSON without
            # the file fields. Oracle: openai-python's `skills.create`
            # signature is the multipart shape.
            multipart_schema = (
                content[multipart_media].get("schema") or {}
            )
            file_paths = self._collect_file_paths(multipart_schema)
            return BodyShape(
                content_type=ContentType.JSON,           # primary wire = JSON
                type=self._type(multipart_schema),       # signature = multipart
                required=bool(request_body.get("required", False)),
                multi_content=True,
                file_paths=tuple(tuple(p) for p in file_paths),
            )
        for media, ct in _CONTENT_TYPES.items():
            if media in content:
                schema = content[media].get("schema", {}) or {}
                return BodyShape(
                    content_type=ct,
                    type=self._type(schema),
                    required=bool(request_body.get("required", False)),
                )
        return None

    def _collect_file_paths(self, schema: dict) -> list[list[str]]:
        """Walk a multipart schema; return paths to binary/file properties.

        `<array>` segment represents a List[FileTypes]-style field — the
        runtime's `extract_files` recognizes it as a wildcard index.
        Oracle: openai-python's `skills.create` paths
        (e.g., `[["files", "<array>"], ["files"]]`).
        """
        if not isinstance(schema, dict):
            return []
        # Resolve $ref one hop.
        if "$ref" in schema:
            ref = schema["$ref"]
            if isinstance(ref, str) and ref.startswith(_SCHEMA_PREFIX):
                name = ref[len(_SCHEMA_PREFIX):]
                schema = self.doc.schemas.get(name, {})

        def _walk(s: dict, prefix: list[str]) -> list[list[str]]:
            if not isinstance(s, dict):
                return []
            out: list[list[str]] = []
            # `string + format:binary` is a single file
            if s.get("type") == "string" and s.get("format") == "binary":
                out.append(prefix[:])
                return out
            # `array of files`
            if s.get("type") == "array":
                items = s.get("items") or {}
                if isinstance(items, dict):
                    if items.get("type") == "string" and items.get("format") == "binary":
                        out.append(prefix + ["<array>"])
                        # Also emit the bare path — openai-python's
                        # `extract_files` accepts either shape for users
                        # who pass a single file as the value.
                        out.append(prefix[:])
                    out.extend(_walk(items, prefix + ["<array>"]))
                return out
            # object properties — recurse
            props = s.get("properties") or {}
            for k, v in props.items():
                out.extend(_walk(v, prefix + [k]))
            return out

        return _walk(schema, [])

    def _responses(self, responses: dict) -> dict[str, Type]:
        out: dict[str, Type] = {}
        for status, resp in responses.items():
            if not isinstance(resp, dict):
                continue
            content = resp.get("content", {}) or {}
            schema = content.get("application/json", {}).get("schema")
            if schema is None:
                # Non-JSON body (octet-stream, audio/*, image/*, …) → binary
                # download. Returning bytes is correct; JSON-parsing it isn't.
                if content:
                    out[str(status)] = PrimitiveType(PrimitiveKind.BYTES)
                continue
            # Do NOT pre-flatten: _type's allOf branch splits shared bases
            # into inheritance (Stainless envelope shape). Pre-flattening here
            # would merge the shared base away before _type sees it.
            out[str(status)] = self._type(schema)
        return out

    # --- methods / resources ----------------------------------------------
    # Request keys that carry page *size*, not the cursor itself — used to
    # pick the cursor param out of the `request:` block.
    _SIZE_PARAMS = frozenset({
        "limit", "per_page", "page_size", "max_results", "max_items",
    })
    # Response keys that aren't cursor carriers.
    _NON_CURSOR_RESPONSE_KEYS = frozenset({
        "data", "items", "results", "has_more", "object", "total",
    })

    def _pagination(self, mc: MethodConfig) -> PaginationIntent | None:
        if not mc.paginated or not self.config.pagination:
            return None
        p = self.config.pagination[0]
        req = p.request or {}
        resp = p.response or {"data": None}
        cursor_param = next(
            (k for k in req if k not in self._SIZE_PARAMS), None
        )
        cursor_response_field = next(
            (k for k in resp if k not in self._NON_CURSOR_RESPONSE_KEYS), None
        )
        # Bi-directional detection (anthropic shape): `request:` has both
        # a `before_*` and an `after_*` cursor param; `response:` has both
        # a `first_*` and a `last_*` field. When matched, the runtime
        # picks direction from the *initial* request.
        before_param = next(
            (k for k in req if k.startswith("before") and k not in self._SIZE_PARAMS),
            None,
        )
        after_param = next(
            (k for k in req if k.startswith("after") and k not in self._SIZE_PARAMS),
            None,
        )
        first_field = next(
            (k for k in resp if k.startswith("first")), None
        )
        last_field = next(
            (k for k in resp if k.startswith("last")), None
        )
        bidirectional = bool(
            before_param and after_param and first_field and last_field
        )
        return PaginationIntent(
            style=PaginationStyle(p.type),
            name=p.name,
            request_params={k: k for k in req},
            data_path=next(iter(resp), "data"),
            continue_on_empty_items=p.continue_on_empty_items,
            cursor_param=cursor_param,
            cursor_response_field=cursor_response_field,
            bidirectional=bidirectional,
            bi_before_param=before_param if bidirectional else None,
            bi_after_param=after_param if bidirectional else None,
            bi_first_field=first_field if bidirectional else None,
            bi_last_field=last_field if bidirectional else None,
        )

    def _streaming(self, mc: MethodConfig) -> StreamingIntent | None:
        if not mc.streaming:
            return None
        s = mc.streaming
        # `stream_event_model` names a component schema (possibly
        # `$resource.Name`); the suffix is the schema -> a ModelRef.
        ev = s.get("stream_event_model")
        event_type: Type = AnyType()
        if isinstance(ev, str) and ev:
            name = ev.split(".")[-1]
            event_type = ModelRef(name) if name in self.doc.schemas else AnyType()
        return StreamingIntent(
            transport=StreamingTransport(s.get("type", "sse")),
            event_type=event_type,
            discriminator=s.get("param_discriminator"),
        )

    def _method(self, mc: MethodConfig) -> Method:
        if mc.endpoint is None:
            # webhook_unwrap etc. — no HTTP op; carry config through emit_hints.
            hints: dict = {"type": mc.method_type, **mc.extra}
            # For `type: webhook_unwrap`: resolve `event_types` $refs into
            # ModelRefs so the emitter can render a typed discriminated union
            # (matches openai-python's `UnwrapWebhookEvent`).
            if mc.method_type == "webhook_unwrap":
                raw = mc.extra.get("event_types") or {}
                refs: dict[str, ModelRef] = {}
                for name, schema in raw.items():
                    ref = (schema or {}).get("$ref") if isinstance(schema, dict) else None
                    if not isinstance(ref, str) or not ref.startswith("#/components/schemas/"):
                        continue
                    comp = ref.rsplit("/", 1)[-1]
                    if comp in self.doc.schemas:
                        refs[name] = ModelRef(comp)
                hints["event_types"] = refs
                hints["discriminator"] = mc.extra.get("discriminator") or "type"
            return Method(
                name=mc.name,
                http_verb=HTTPVerb.POST,
                path="",
                emit_hints=hints,
                docs=None,
            )
        key = (mc.endpoint.verb, mc.endpoint.path)
        op = self.ops.get(key)
        if op is None:
            raise IRBuildError(
                f"config method {mc.name!r} -> {mc.endpoint.raw!r} has no matching "
                f"operation in the OpenAPI spec",
                self.loc,
            )
        by_loc: dict[str, list[Property]] = {"path": [], "query": [], "header": []}
        for p in op.parameters:
            loc = p.get("in")
            if loc in by_loc:
                by_loc[loc].append(self._param(p))
        verb = HTTPVerb(mc.endpoint.verb)
        # Prefer the operation's `description` (long-form) but fall back
        # to `summary` if only that is set. Used by the docs emitter to
        # show what each method actually does.
        op_docs = op.raw.get("description") or op.raw.get("summary")
        return Method(
            name=mc.name,
            http_verb=verb,
            path=mc.endpoint.path,
            path_params=tuple(by_loc["path"]),
            query_params=tuple(by_loc["query"]),
            header_params=tuple(by_loc["header"]),
            body=self._body(op.request_body),
            responses=self._responses(op.responses),
            unwrap=mc.unwrap_response,
            pagination=self._pagination(mc),
            streaming=self._streaming(mc),
            idempotent=verb in (HTTPVerb.GET, HTTPVerb.PUT, HTTPVerb.DELETE),
            docs=op_docs.strip() if isinstance(op_docs, str) else None,
            emit_hints={
                k: v
                for k, v in {
                    "positional_params": mc.positional_params,
                    "body_param_name": mc.body_param_name,
                    "skip_test_reason": mc.skip_test_reason,
                    **mc.extra,
                }.items()
                if v
            },
        )

    def _resource(self, name: str, rc: ResourceConfig) -> Resource:
        return Resource(
            name=name,
            methods=[self._method(m) for m in rc.methods.values()],
            subresources=[
                self._resource(sn, sc) for sn, sc in rc.subresources.items()
            ],
        )

    # --- auth / environments ----------------------------------------------
    def _auth(self) -> list[SecurityScheme]:
        schemes: list[SecurityScheme] = []
        spec_schemes = self.doc.security_schemes
        cfg_schemes = self.config.security_schemes
        for opt in self.config.client_settings.opts.values():
            sname = opt.auth.get("security_scheme")
            spec = spec_schemes.get(sname, {}) or cfg_schemes.get(sname, {}) or {}
            kind = spec.get("type", "apiKey")
            if opt.send_as_query_param:
                location, param = "query", opt.send_as_query_param
            elif kind == "apiKey":
                location, param = spec.get("in", "header"), spec.get("name")
            else:  # http bearer/basic
                location, param = "header", "Authorization"
                kind = f"http-{spec.get('scheme', 'bearer')}"
            schemes.append(
                SecurityScheme(
                    name=opt.name,
                    kind=kind,
                    location=location,
                    param_name=param,
                    read_env=opt.read_env,
                )
            )
        return schemes

    def _environments(self) -> dict[str, str]:
        if self.config.environments:
            return dict(self.config.environments)
        servers = self.doc.servers
        return {"production": servers[0]["url"]} if servers else {}

    # --- entry -------------------------------------------------------------
    def build(self) -> API:
        info = self.doc.info
        root = Resource(
            name="$client",
            methods=[self._method(m) for m in self.config.client_methods.values()],
            subresources=[
                self._resource(n, rc) for n, rc in self.config.resources.items()
            ],
        )
        # Normalize user-declared shared models. Configs use either the
        # bare component name (`references: Reference`) or the full $ref
        # string (`acme_widget_id_string: "#/components/schemas/..."`) —
        # both are valid Stainless surface and produce the same shape
        # downstream.
        shared = {
            _strip_ref(mc.openapi_ref): key
            for key, mc in self.config.shared_models.items()
            if mc.openapi_ref
        }
        # Auto-promote the most-frequently-referenced 4XX error schema to
        # the `error_object` shared model — matches Stainless's convention
        # (oracle: openai-python emits `openai.types.shared.ErrorObject`
        # auto-derived from the spec's error schema). Skipped if the user
        # explicitly declared one.
        if "error_object" not in shared.values():
            err = self._auto_detect_error_schema(root)
            if err is not None and err not in shared:
                shared[err] = "error_object"
        return API(
            name=self.config.organization.name or info.get("title", "api"),
            version=str(info.get("version", "0.0.0")),
            environments=self._environments(),
            auth=self._auth(),
            models=self._models(),
            shared_models=shared,
            custom_casings=dict(self.config.custom_casings),
            python_package_name=(
                self.config.targets.get("python").package_name
                if self.config.targets.get("python") is not None
                else None
            ),
            root=root,
        )

    def _auto_detect_error_schema(self, root: Resource) -> str | None:
        """Pick the schema most often referenced from 4XX/default
        responses in the OpenAPI spec. We scan the spec directly (not
        the IR) so the detection is independent of which subset of ops
        the user happens to configure.

        Heuristics:
          1. Require ≥2 references — a one-off error isn't a "common" type.
          2. If a candidate is a single-field wrapper (`{error: $ref X}`),
             unwrap to X. Real openai spec has `ErrorResponse = {error:
             $ref Error}`; user wants `Error`, not the wrapper.
          3. Among candidates, prefer ones with an error-like shape
             (`message` field plus at least one of `code` / `type` /
             `param`). Falls back to most-referenced if none match.

        Stainless's convention is to expose this as `<pkg>.types.shared
        .ErrorObject`. We promote into `shared_models` with key
        `error_object`; the existing emitter machinery handles the rest.
        """
        counts: dict[str, int] = {}
        prefix = "#/components/schemas/"
        for _path, item in (self.doc.raw.get("paths") or {}).items():
            if not isinstance(item, dict):
                continue
            for verb in ("get", "post", "put", "patch", "delete"):
                op = item.get(verb)
                if not isinstance(op, dict):
                    continue
                for status, resp in (op.get("responses") or {}).items():
                    s = str(status)
                    if not (s.startswith("4") or s == "default"):
                        continue
                    if not isinstance(resp, dict):
                        continue
                    schema = (
                        (resp.get("content") or {})
                        .get("application/json", {})
                        .get("schema")
                    ) or {}
                    ref = schema.get("$ref") if isinstance(schema, dict) else None
                    if isinstance(ref, str) and ref.startswith(prefix):
                        name = ref[len(prefix):]
                        counts[name] = counts.get(name, 0) + 1
        if not counts:
            return None
        schemas = self.doc.schemas
        # Order by frequency desc, then name. Unwrap single-field
        # wrappers; among ≥2-ref candidates prefer ones whose shape
        # looks like an error.
        ordered = sorted(counts.items(), key=lambda kv: (-kv[1], kv[0]))
        # First pass: candidates with the error-like shape (after unwrap).
        for name, count in ordered:
            if count < 2:
                break
            inner = self._unwrap_error_wrapper(name, schemas)
            if self._is_error_shape(inner, schemas):
                return inner
        # Fallback: the most-referenced ≥2 candidate (unwrapped if a wrapper).
        for name, count in ordered:
            if count < 2:
                break
            return self._unwrap_error_wrapper(name, schemas)
        return None

    @staticmethod
    def _unwrap_error_wrapper(name: str, schemas: dict) -> str:
        """`{error: $ref Inner}` → `Inner`; otherwise unchanged."""
        prefix = "#/components/schemas/"
        s = schemas.get(name) or {}
        props = (s.get("properties") if isinstance(s, dict) else None) or {}
        if len(props) == 1 and "error" in props:
            inner = props["error"]
            ref = inner.get("$ref") if isinstance(inner, dict) else None
            if isinstance(ref, str) and ref.startswith(prefix):
                return ref[len(prefix):]
        return name

    @staticmethod
    def _is_error_shape(name: str, schemas: dict) -> bool:
        s = schemas.get(name) or {}
        props = (s.get("properties") if isinstance(s, dict) else None) or {}
        return (
            "message" in props
            and any(k in props for k in ("code", "type", "param"))
        )


def build_ir(spec: OpenAPIDocument, config: Config) -> API:
    if not isinstance(spec, OpenAPIDocument):
        raise IRBuildError("build_ir expects a loaded OpenAPIDocument")
    return _Builder(spec, config).build()
