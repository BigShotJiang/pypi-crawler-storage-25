"""The IR API model (DESIGN.md §4) — language-agnostic semantic model.

Built by ir.builder from (OpenAPI spec + Stainless config). Consumed read-only by
emitters. This is the single contract between spec-understanding and code-generation.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum

from stainful.ir.types import Model, Property, Type


class HTTPVerb(str, Enum):
    GET = "get"
    POST = "post"
    PUT = "put"
    PATCH = "patch"
    DELETE = "delete"


class PaginationStyle(str, Enum):
    CURSOR = "cursor"
    CURSOR_ID = "cursor_id"
    OFFSET = "offset"
    PAGE_NUMBER = "page_number"


class StreamingTransport(str, Enum):
    SSE = "sse"
    JSONL = "jsonl"


class ContentType(str, Enum):
    JSON = "application/json"
    MULTIPART = "multipart/form-data"
    FORM = "application/x-www-form-urlencoded"
    BINARY = "binary"


@dataclass(frozen=True)
class SecurityScheme:
    name: str
    # apiKey | http-bearer | http-basic
    kind: str
    # where the credential goes: header | query
    location: str | None = None
    param_name: str | None = None
    read_env: str | None = None


@dataclass(frozen=True)
class PaginationIntent:
    style: PaginationStyle
    # `pagination[].name` from stainless.yml (e.g. `cursor_page`,
    # `next_cursor_page`, `token_page`). Drives the emitted page class
    # name (`Sync<Pascal>Page` / `Async<Pascal>Page`) so user imports
    # like `from openai.pagination import SyncNextCursorPage` resolve.
    # `None` → fall back to a generic name derived from `style`.
    name: str | None = None
    # True for anthropic-style bi-directional pagination (request has
    # both `before_*` and `after_*` params; response has `first_*` and
    # `last_*` fields). The runtime picks direction from the initial
    # request — see `_BiDirectionalPage`.
    bidirectional: bool = False
    # Bi-directional wire params/fields (only set when `bidirectional`):
    bi_before_param: str | None = None     # `before_id`-style request param
    bi_after_param: str | None = None      # `after_id`-style request param
    bi_first_field: str | None = None      # `first_id`-style response field
    bi_last_field: str | None = None       # `last_id`-style response field
    # request-side param names and response-side data/next paths.
    request_params: dict[str, str] = field(default_factory=dict)
    data_path: str = "data"
    next_path: str | None = None
    continue_on_empty_items: bool = False
    # Wire param name carrying the cursor on next-page requests (e.g. `after`,
    # `cursor`, `page_token`). Derived from config `request:` keys (the first
    # non-size key). `None` → runtime default ("after", matching openai/
    # anthropic convention). RESEARCH §4 #1 — was hard-coded to "cursor",
    # silently broken against any API expecting "after".
    cursor_param: str | None = None
    # Response field holding the next cursor (e.g. `next_cursor`, `last_id`,
    # `next`, `next_page`). Derived from config `response:` keys. `None` →
    # runtime falls back to `next_cursor`, then last-item `.id`.
    cursor_response_field: str | None = None


@dataclass(frozen=True)
class StreamingIntent:
    transport: StreamingTransport
    event_type: Type
    discriminator: str | None = None


@dataclass(frozen=True)
class BodyShape:
    content_type: ContentType
    type: Type
    required: bool = True
    # True for endpoints that declare multiple `requestBody.content` types
    # (typically JSON + multipart/form-data). The emitter generates one
    # method whose runtime dispatch picks the wire shape from the
    # arguments — if file-like values are present in `file_paths`, send
    # multipart; else JSON. Oracle: openai-python's `skills.create` etc.
    multi_content: bool = False
    # Paths into the body where binary/file-like values live (used by
    # the runtime's `extract_files` to know what to lift out as multipart
    # parts vs. keep in the JSON body). `<array>` is a wildcard index
    # segment for List[FileTypes] fields. Empty for non-multi-content
    # bodies. Example: `[["files", "<array>"], ["files"]]`.
    file_paths: tuple[tuple[str, ...], ...] = ()


@dataclass(frozen=True)
class Method:
    name: str                       # idiomatic verb from config (list/create/retrieve…)
    http_verb: HTTPVerb
    path: str
    path_params: tuple[Property, ...] = ()
    query_params: tuple[Property, ...] = ()
    header_params: tuple[Property, ...] = ()
    body: BodyShape | None = None
    # per-status response types: "200","2XX","4XX","default" -> Type.
    # Multi-valued so the typed error hierarchy can be generated (RESEARCH §4 #4).
    responses: dict[str, Type] = field(default_factory=dict)
    unwrap: str | None = None       # config unwrap_response (e.g. "data")
    pagination: PaginationIntent | None = None
    streaming: StreamingIntent | None = None
    idempotent: bool = False
    # explicit escape hatch for emitter-only, non-semantic config hints:
    # positional_params, body_param_name, skip_test_reason, per-language skip.
    emit_hints: dict = field(default_factory=dict)
    docs: str | None = None
    deprecated: bool = False


@dataclass
class Resource:
    name: str
    docs: str | None = None
    methods: list[Method] = field(default_factory=list)
    subresources: list["Resource"] = field(default_factory=list)


@dataclass
class API:
    name: str
    version: str
    environments: dict[str, str] = field(default_factory=dict)
    auth: list[SecurityScheme] = field(default_factory=list)
    models: dict[str, Model] = field(default_factory=dict)
    # component-schema-name -> raw `$shared.models` key (Stainless emits these
    # once as shared classes named after the key, e.g. Reference -> "references"
    # -> class `References`). Everything else is operation-local.
    shared_models: dict[str, str] = field(default_factory=dict)
    # User-declared name overrides from `custom_casings:` in stainless.yml.
    # `{snake: PascalCase}`. Used by the emitter's casing helpers to spell
    # out compound names the heuristics can't infer.
    custom_casings: dict[str, str] = field(default_factory=dict)
    # `targets.python.package_name` from stainless.yml — when set, overrides
    # the package directory name (otherwise derived from `organization.name`).
    python_package_name: str | None = None
    # config `$client:` methods live on root (no parent resource).
    root: Resource = field(default_factory=lambda: Resource(name="$client"))
