from . import gen

def main():
    print("🚀 Tool Running...")
    gen.main_menu()