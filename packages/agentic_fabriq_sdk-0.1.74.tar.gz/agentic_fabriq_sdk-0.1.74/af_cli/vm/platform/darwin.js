"use strict";

const { execSync, execFileSync } = require("child_process");
const fs = require("fs");
const os = require("os");
const path = require("path");
const { PlatformProvider } = require("./interface");

// ---------------------------------------------------------------------------
// Constants
// ---------------------------------------------------------------------------

const HOMEBREW_PREFIXES = ["/opt/homebrew", "/usr/local"];
const QEMU_BINARY_NAME = "qemu-system-aarch64";
const FIRMWARE_CODE = "share/qemu/edk2-aarch64-code.fd";
const FIRMWARE_VARS = "share/qemu/edk2-arm-vars.fd";

// Grace period (ms) before escalating SIGTERM → SIGKILL
const SIGTERM_TIMEOUT_MS = 8000;
// Poll interval (ms) when waiting for a process to exit
const POLL_INTERVAL_MS = 200;

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

/**
 * Run `which <cmd>` and return the trimmed path, or null if not found.
 * @param {string} cmd
 * @returns {string|null}
 */
function which(cmd) {
  try {
    return execFileSync("which", [cmd], { encoding: "utf8" }).trim();
  } catch {
    return null;
  }
}

/**
 * Check whether a process with the given PID is still alive.
 * @param {number} pid
 * @returns {boolean}
 */
function isAlive(pid) {
  try {
    process.kill(pid, 0);
    return true;
  } catch {
    return false;
  }
}

/**
 * Sleep for `ms` milliseconds.
 * @param {number} ms
 * @returns {Promise<void>}
 */
function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

// ---------------------------------------------------------------------------
// DarwinProvider
// ---------------------------------------------------------------------------

class DarwinProvider extends PlatformProvider {
  // -------------------------------------------------------------------------
  // checkPrerequisites
  // -------------------------------------------------------------------------

  /**
   * Verify that QEMU and the UEFI firmware files are available.
   *
   * @returns {{ qemu: boolean, firmware: boolean, errors: string[] }}
   */
  checkPrerequisites() {
    const errors = [];

    // --- QEMU binary ---
    const qemuPath = which(QEMU_BINARY_NAME);
    const qemu = qemuPath !== null;
    if (!qemu) {
      errors.push(
        `${QEMU_BINARY_NAME} not found. Install it with: brew install qemu`
      );
    }

    // --- Firmware ---
    let firmware = false;
    try {
      const fw = this.getFirmwarePaths();
      if (fs.existsSync(fw.code) && fs.existsSync(fw.varsTemplate)) {
        firmware = true;
      } else {
        if (!fs.existsSync(fw.code)) {
          errors.push(`UEFI firmware code file not found: ${fw.code}`);
        }
        if (!fs.existsSync(fw.varsTemplate)) {
          errors.push(`UEFI firmware vars template not found: ${fw.varsTemplate}`);
        }
      }
    } catch (err) {
      errors.push(`Could not locate firmware: ${err.message}`);
    }

    return { qemu, firmware, errors };
  }

  // -------------------------------------------------------------------------
  // getQemuBinary
  // -------------------------------------------------------------------------

  /**
   * Return the path to the QEMU binary, preferring the one found via `which`.
   *
   * @returns {string}
   */
  getQemuBinary() {
    return (
      which(QEMU_BINARY_NAME) ||
      `/opt/homebrew/bin/${QEMU_BINARY_NAME}`
    );
  }

  // -------------------------------------------------------------------------
  // getQemuBaseArgs
  // -------------------------------------------------------------------------

  /**
   * Return the base QEMU arguments for Apple Silicon Macs (aarch64 + HVF).
   *
   * @param {{ memoryGB: number, cpuCount: number }} config
   * @returns {string[]}
   */
  getQemuBaseArgs({ memoryGB, cpuCount }) {
    return [
      "-M", "virt,highmem=on",
      "-cpu", "host",
      "-accel", "hvf",
      "-m", String(memoryGB * 1024),
      "-smp", String(cpuCount),
    ];
  }

  // -------------------------------------------------------------------------
  // getFirmwarePaths
  // -------------------------------------------------------------------------

  /**
   * Locate the UEFI firmware files under the active Homebrew prefix.
   * Checks /opt/homebrew first (Apple Silicon), then /usr/local (Intel).
   *
   * @returns {{ code: string, varsTemplate: string }}
   * @throws {Error} When no firmware is found in any known prefix.
   */
  getFirmwarePaths() {
    for (const prefix of HOMEBREW_PREFIXES) {
      const code = path.join(prefix, FIRMWARE_CODE);
      const varsTemplate = path.join(prefix, FIRMWARE_VARS);
      if (fs.existsSync(code)) {
        // Return even if varsTemplate doesn't exist yet; caller validates.
        return { code, varsTemplate };
      }
    }

    // Return the Apple Silicon default so callers can surface a useful error.
    const defaultPrefix = HOMEBREW_PREFIXES[0];
    return {
      code: path.join(defaultPrefix, FIRMWARE_CODE),
      varsTemplate: path.join(defaultPrefix, FIRMWARE_VARS),
    };
  }

  // -------------------------------------------------------------------------
  // createSeedISO
  // -------------------------------------------------------------------------

  /**
   * Build a cloud-init seed ISO on macOS using hdiutil + dd.
   *
   * Steps:
   *  1. Create a temp directory.
   *  2. Write user-data and meta-data files into it.
   *  3. Use `hdiutil create` to create an HFS+ image labelled "cidata".
   *  4. Attach the image.
   *  5. Copy the cloud-init files onto the mounted volume.
   *  6. Detach the image.
   *  7. Use `dd` to convert the image to a raw ISO and place it at destPath.
   *  8. Remove the temp directory.
   *
   * @param {{ userDataContent: string, metaDataContent: string, destPath: string }} opts
   * @returns {Promise<string>} Resolves to destPath.
   */
  async createSeedISO({ userDataContent, metaDataContent, destPath }) {
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), "af-seed-"));

    try {
      // --- Write cloud-init payload files ---
      const userDataFile = path.join(tmpDir, "user-data");
      const metaDataFile = path.join(tmpDir, "meta-data");
      fs.writeFileSync(userDataFile, userDataContent, "utf8");
      fs.writeFileSync(metaDataFile, metaDataContent, "utf8");

      // --- Create ISO 9660 image labeled "cidata" for cloud-init ---
      // mkisofs/genisoimage creates a proper ISO that cloud-init recognizes.
      // On macOS, hdiutil with -fs HFS+ does NOT work for cloud-init —
      // cloud-init requires ISO 9660 with volume label "cidata".
      const mkisofs = which("mkisofs") || which("genisoimage");
      if (mkisofs) {
        execFileSync(mkisofs, [
          "-output", destPath,
          "-volid", "cidata",
          "-joliet",
          "-rock",
          userDataFile,
          metaDataFile,
        ]);
      } else {
        // Fallback: use hdiutil makehybrid to create a proper ISO 9660
        // Use a separate source directory with only cloud-init files
        // to avoid including the output ISO in the source
        const srcDir = path.join(tmpDir, "src");
        fs.mkdirSync(srcDir);
        fs.copyFileSync(userDataFile, path.join(srcDir, "user-data"));
        fs.copyFileSync(metaDataFile, path.join(srcDir, "meta-data"));

        // hdiutil appends .iso to the -o path
        const outBase = path.join(tmpDir, "seed");
        execFileSync("hdiutil", [
          "makehybrid",
          "-o", outBase,
          "-iso",
          "-joliet",
          "-default-volume-name", "cidata",
          srcDir,
        ]);
        fs.renameSync(outBase + ".iso", destPath);
      }

      return destPath;
    } finally {
      // --- Clean up temp directory ---
      fs.rmSync(tmpDir, { recursive: true, force: true });
    }
  }

  // -------------------------------------------------------------------------
  // getFileShareArgs
  // -------------------------------------------------------------------------

  /**
   * Return QEMU -virtfs arguments to expose host directories to the guest.
   *
   * @param {Array<{ hostPath: string, guestTag: string }>} folders
   * @returns {string[]}
   */
  getFileShareArgs(folders) {
    const args = [];
    for (const { hostPath, guestTag } of folders) {
      args.push(
        "-virtfs",
        `local,path=${hostPath},mount_tag=${guestTag},security_model=mapped-xattr`
      );
    }
    return args;
  }

  // -------------------------------------------------------------------------
  // getGuestMountCommands
  // -------------------------------------------------------------------------

  /**
   * Return fstab lines that mount the virtio-9p shares inside the guest.
   *
   * @param {Array<{ hostPath: string, guestTag: string }>} folders
   * @returns {string[]}
   */
  getGuestMountCommands(folders) {
    return folders.map(({ guestTag }) => {
      // Derive a stable guest mount point from the tag.
      const mountPoint = `/mnt/${guestTag}`;
      return (
        `${guestTag} ${mountPoint} 9p ` +
        `trans=virtio,version=9p2000.L,msize=104857600 0 0`
      );
    });
  }

  // -------------------------------------------------------------------------
  // killProcess
  // -------------------------------------------------------------------------

  /**
   * Send SIGTERM to a process, then escalate to SIGKILL after 8 seconds if
   * it has not exited.
   *
   * @param {number} pid
   * @returns {Promise<void>}
   */
  async killProcess(pid) {
    if (!isAlive(pid)) {
      return;
    }

    // First attempt: graceful shutdown.
    try {
      process.kill(pid, "SIGTERM");
    } catch {
      // Process may have already exited — that is fine.
      return;
    }

    // Wait up to SIGTERM_TIMEOUT_MS for the process to exit.
    const deadline = Date.now() + SIGTERM_TIMEOUT_MS;
    while (Date.now() < deadline) {
      if (!isAlive(pid)) {
        return;
      }
      await sleep(POLL_INTERVAL_MS);
    }

    // Escalate to SIGKILL if the process is still alive.
    if (isAlive(pid)) {
      try {
        process.kill(pid, "SIGKILL");
      } catch {
        // Already dead — ignore.
      }
    }
  }

  // -------------------------------------------------------------------------
  // getGuestArch
  // -------------------------------------------------------------------------

  /**
   * This macOS provider targets Apple Silicon (aarch64).
   *
   * @returns {"aarch64"}
   */
  getGuestArch() {
    return "aarch64";
  }
}

module.exports = { DarwinProvider };
