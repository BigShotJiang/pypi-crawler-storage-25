"use strict";

const WebSocket = require("ws");
const http = require("http");

const RELAY_URLS = [
  "wss://dashboard.agenticfabriq.com/api/v1/vm/relay",
  "wss://staging.agenticfabriq.com/api/v1/vm/relay",
];

const RECONNECT_BASE_MS = 1000;
const RECONNECT_MAX_MS = 30000;
const PING_INTERVAL_MS = 30000;

/**
 * Connect to the gateway relay and forward commands to the local Express server.
 *
 * @param {string} token - JWT auth token
 * @param {number} localPort - Port the Express server is listening on
 */
function startRelay(token, localPort) {
  const relayUrl = RELAY_URLS[0]; // Production by default
  let reconnectDelay = RECONNECT_BASE_MS;
  let ws = null;
  let pingTimer = null;
  let stopped = false;

  function connect() {
    if (stopped) return;

    ws = new WebSocket(relayUrl);

    ws.on("open", () => {
      console.log("[relay] Connected to gateway, authenticating...");
      ws.send(JSON.stringify({ type: "auth", token }));
    });

    ws.on("message", (data) => {
      let msg;
      try {
        msg = JSON.parse(data.toString());
      } catch {
        return;
      }

      if (msg.type === "auth_ok") {
        console.log("[relay] Authenticated — dashboard integration active");
        reconnectDelay = RECONNECT_BASE_MS;
        startPing();
        return;
      }

      if (msg.type === "auth_error") {
        console.error(`[relay] Auth failed: ${msg.message}`);
        ws.close();
        return;
      }

      // Command from gateway — forward to local Express server
      if (msg.id && msg.method && msg.path) {
        handleCommand(msg);
      }
    });

    ws.on("close", (code) => {
      clearPing();
      if (stopped) return;

      if (code === 4003) {
        // Auth failed — don't reconnect, token is invalid
        console.error("[relay] Token rejected. Run 'afctl auth login' to re-authenticate.");
        return;
      }

      console.log(
        `[relay] Disconnected (code=${code}), reconnecting in ${Math.round(reconnectDelay / 1000)}s...`
      );
      setTimeout(connect, reconnectDelay);
      reconnectDelay = Math.min(reconnectDelay * 2, RECONNECT_MAX_MS);
    });

    ws.on("error", (err) => {
      // Suppress ECONNREFUSED noise during reconnect
      if (err.code !== "ECONNREFUSED") {
        console.error(`[relay] WebSocket error: ${err.message}`);
      }
    });
  }

  function startPing() {
    clearPing();
    pingTimer = setInterval(() => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.ping();
      }
    }, PING_INTERVAL_MS);
  }

  function clearPing() {
    if (pingTimer) {
      clearInterval(pingTimer);
      pingTimer = null;
    }
  }

  /**
   * Forward a command from the gateway to the local Express server
   * and send the response back through the WebSocket.
   */
  function handleCommand(cmd) {
    const { id, method, path, body } = cmd;
    const postData = body ? JSON.stringify(body) : null;

    const options = {
      hostname: "127.0.0.1",
      port: localPort,
      path,
      method,
      headers: { "Content-Type": "application/json" },
    };

    const req = http.request(options, (res) => {
      let chunks = [];
      res.on("data", (chunk) => chunks.push(chunk));
      res.on("end", () => {
        let responseBody;
        try {
          responseBody = JSON.parse(Buffer.concat(chunks).toString());
        } catch {
          responseBody = { raw: Buffer.concat(chunks).toString() };
        }

        if (ws && ws.readyState === WebSocket.OPEN) {
          ws.send(JSON.stringify({ id, status: res.statusCode, body: responseBody }));
        }
      });
    });

    req.on("error", (err) => {
      if (ws && ws.readyState === WebSocket.OPEN) {
        ws.send(
          JSON.stringify({
            id,
            status: 502,
            body: { error: `Local server error: ${err.message}` },
          })
        );
      }
    });

    if (postData) {
      req.write(postData);
    }
    req.end();
  }

  function stop() {
    stopped = true;
    clearPing();
    if (ws) {
      ws.close();
    }
  }

  connect();
  return { stop };
}

module.exports = { startRelay };
