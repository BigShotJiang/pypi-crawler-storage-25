"""afctl vm — local VM management commands."""
import os
import subprocess
from pathlib import Path

import typer

app = typer.Typer(help="Manage local VMs for computer use agents")


def _get_auth_token() -> str | None:
    """Read the stored auth token from the CLI's token storage."""
    try:
        from af_cli.core.token_storage import TokenStorage

        storage = TokenStorage()
        token_data = storage.load()
        if token_data and token_data.access_token:
            return token_data.access_token
    except Exception:
        pass
    return None


@app.command()
def serve(
    port: int = typer.Option(7865, "--port", "-p", help="Port for the VM management server"),
):
    """Start the local VM management server."""
    vm_dir = Path(__file__).resolve().parent.parent / "vm"
    server_js = vm_dir / "server.js"
    node_modules = vm_dir / "node_modules"

    if not server_js.exists():
        typer.echo(f"Error: server.js not found at {server_js}", err=True)
        raise typer.Exit(1)

    # Auto-install node dependencies if missing or outdated
    pkg_json = vm_dir / "package.json"
    needs_install = not node_modules.exists()
    if not needs_install and pkg_json.exists() and node_modules.exists():
        # Re-run npm install if package.json is newer than node_modules
        if pkg_json.stat().st_mtime > node_modules.stat().st_mtime:
            needs_install = True
    if needs_install:
        typer.echo("Installing VM server dependencies...")
        subprocess.run(["npm", "install"], cwd=str(vm_dir), check=True)

    # Pass auth token to Node process for relay connection
    env = {**os.environ, "AF_VM_PORT": str(port)}
    token = _get_auth_token()
    if token:
        env["AF_AUTH_TOKEN"] = token
        typer.echo("Auth token found — relay connection will be enabled.")
    else:
        typer.echo("No auth token found. Run 'afctl auth login' to enable dashboard integration.")

    typer.echo(f"Starting VM management server on port {port}...")
    try:
        proc = subprocess.run(
            ["node", str(server_js)],
            env=env,
            cwd=str(vm_dir),
        )
        raise typer.Exit(proc.returncode)
    except KeyboardInterrupt:
        typer.echo("\nServer stopped.")
