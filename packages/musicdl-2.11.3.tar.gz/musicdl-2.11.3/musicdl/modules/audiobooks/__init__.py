'''initialize'''
from .lrts import LRTSMusicClient
from .lizhi import LizhiMusicClient
from .itunes import ITunesMusicClient
from .ximalaya import XimalayaMusicClient
from .qingting import QingtingMusicClient