"""Channel transport declarations.

Each channel declares HOW messages reach the app.  Credential fields
accept either a plain string (for quick local dev) or a
``cpsl.Secret`` reference (for production).

Usage::

    @app.cls(
        channels=[
            cpsl.Chat(),
            # hardcoded / env var
            cpsl.Telegram(bot_token=os.environ["TELEGRAM_BOT_TOKEN"]),
            # or from platform-stored secret
            cpsl.Telegram(bot_token=cpsl.Secret.from_name("telegram-bot-token")),
        ],
    )
"""

from __future__ import annotations

from dataclasses import dataclass, fields
from typing import Union

from .secret import Secret

CredentialValue = Union[str, Secret, None]


def _serialize_credential(v: CredentialValue) -> str | dict | None:
    if v is None or v == "":
        return None
    if isinstance(v, Secret):
        return v.to_dict()
    return v


@dataclass
class Channel:
    """Base channel transport. Subclass per platform."""

    type: str = ""

    def to_dict(self) -> dict:
        d: dict = {"type": self.type}
        for f in fields(self):
            if f.name == "type":
                continue
            v = getattr(self, f.name)
            serialized = _serialize_credential(v)
            if serialized is not None:
                d[f.name] = serialized
        return d


@dataclass
class Chat(Channel):
    """Built-in web chat. Always connected — no credentials needed."""

    type: str = "chat"


@dataclass
class Telegram(Channel):
    """Telegram Bot API."""

    type: str = "telegram"
    bot_token: CredentialValue = None


@dataclass
class Slack(Channel):
    """Slack Events API."""

    type: str = "slack"
    bot_token: CredentialValue = None
    signing_secret: CredentialValue = None


@dataclass
class WhatsApp(Channel):
    """WhatsApp Cloud API."""

    type: str = "whatsapp"
    access_token: CredentialValue = None
    phone_number_id: CredentialValue = None
    verify_token: CredentialValue = None


@dataclass
class API(Channel):
    """REST API transport. Synchronous request/response."""

    type: str = "api"
