from __future__ import annotations

from dataclasses import fields as dc_fields
from typing import Any, Callable, TypeVar

from .channels import Channel
from .filesystem import FileSystem
from .image import Image
from .secret import Secret

T = TypeVar("T")

_REGISTERED_CLASSES: list[dict[str, Any]] = []


def _collect_channel_secrets(channels: list[Channel]) -> list[str]:
    """Extract secret names from channel credential fields."""
    names: list[str] = []
    for ch in channels:
        for f in dc_fields(ch):
            v = getattr(ch, f.name)
            if isinstance(v, Secret) and v.name:
                names.append(v.name)
    return names


class App:
    """Lightweight deployment namespace. All deploy config lives on the decorator."""

    def __init__(self, name: str) -> None:
        self.name = name

    def cls(
        self,
        *,
        image: Image,
        price: int = 0,
        channels: list[Channel] | None = None,
        keep_warm_seconds: int = 0,
        secrets: list[str] | None = None,
        filesystems: dict[str, FileSystem] | None = None,
    ) -> Callable[[type[T]], type[T]]:
        """Decorator for class-based apps. Captures deploy config."""
        app_name = self.name
        all_channels = channels or []
        all_secrets = list(secrets or [])
        for name in _collect_channel_secrets(all_channels):
            if name not in all_secrets:
                all_secrets.append(name)

        fs_map: dict[str, str] = {}
        if filesystems:
            for mount_path, fs_obj in filesystems.items():
                fs_map[mount_path] = fs_obj.name

        def decorator(klass: type[T]) -> type[T]:
            config = {
                "app_name": app_name,
                "image": image.to_dict(),
                "price": price,
                "channels": [c.to_dict() for c in all_channels],
                "keep_warm_seconds": keep_warm_seconds,
                "secrets": all_secrets,
                "filesystems": fs_map,
                "module": klass.__module__,
                "class_name": klass.__qualname__,
            }
            klass._cpsl_config = config  # type: ignore[attr-defined]
            _REGISTERED_CLASSES.append(config)
            return klass

        return decorator

    def _serialize(self) -> dict[str, Any] | None:
        """Return the deploy spec for the class registered under this app."""
        for cfg in _REGISTERED_CLASSES:
            if cfg["app_name"] == self.name:
                return cfg
        return None
