"""Capsule runner — connects to the gateway, dispatches messages and tasks.

Not a public API. Invoked inside the runtime:

    python -m cpsl.runner module:ClassName
"""

from __future__ import annotations

import asyncio
import contextvars
import importlib
import io
import json
import os
import signal
import subprocess
import sys
import threading
import time
import uuid
from typing import Any, Type

from aiohttp import web

from .channel import Channel as GrpcChannel
from .channels import Channel
from .clients.capsule import (
    ClaimTaskRequest,
    CompleteTaskRequest,
    DataServiceStub,
    GetSecretRequest,
    GetSessionRequest,
    HeartbeatRequest,
    InboundMessage,
    KeepAliveRequest,
    RecvRequest,
    RegisterRequest,
    RunnerServiceStub,
    SaveSessionDataRequest,
    SecretServiceStub,
    SessionServiceStub,
    SubmitResultRequest,
    TaskDelivery,
    TaskHeartbeatRequest,
    TaskServiceStub,
    TaskStatus,
)
from .db import DatabaseProxy
from .decorators import (
    _BOOT_ATTR,
    _SHUTDOWN_ATTR,
    _ENTER_ATTR,
    _EXIT_ATTR,
    _MESSAGE_ATTR,
    _SCHEDULE_ATTR,
    _ENDPOINT_ATTR,
    _ASGI_ATTR,
)
from .msg import Message
from .session import Session, UserInfo
from .task_types import TaskDescriptor, GlobalTaskQuery

_PORT = 8080
_HEARTBEAT_INTERVAL = 10
_MAX_BACKOFF = 5
_GRPC_RETRY_TRIES = 4
_GRPC_RETRY_DELAY = 2

_current_task_id: contextvars.ContextVar[str] = contextvars.ContextVar("_current_task_id", default="")


class StdoutJsonInterceptor(io.TextIOBase):
    """Intercepts stdout/stderr and writes structured JSON lines to the original stream.

    The Go side (serve controller) tails the process output, parses JSON lines,
    and routes them to S2. Modeled after Beta9's logging.StdoutJsonInterceptor.
    """

    def __init__(self, stream=sys.__stdout__):
        self._stream = stream

    def write(self, buf: str) -> int:
        if not buf:
            return 0
        try:
            task_id = _current_task_id.get("")
            for line in buf.splitlines():
                if not line:
                    continue
                record = {"message": line, "stream": "stdout"}
                if task_id:
                    record["task_id"] = task_id
                self._stream.write(json.dumps(record) + "\n")
            self._stream.flush()
        except Exception:
            self._stream.write(buf)
            self._stream.flush()
        return len(buf)

    def flush(self) -> None:
        self._stream.flush()

    def fileno(self) -> int:
        try:
            return self._stream.fileno()
        except (AttributeError, io.UnsupportedOperation):
            return -1

    def isatty(self) -> bool:
        return False

    def writable(self) -> bool:
        return True


def _log(msg: str) -> None:
    print(f"[cpsl] {msg}", flush=True)


def _find_hook(instance: object, attr: str):
    for name in dir(instance):
        fn = getattr(instance, name, None)
        if callable(fn) and getattr(fn, attr, False):
            return fn
    return None


async def _maybe_await(result):
    if asyncio.iscoroutine(result):
        return await result
    return result


def _retry_on_errors(retry_for: list[Type[Exception]], exc: BaseException) -> bool:
    if not retry_for:
        return False
    return any(type(exc) is err for err in retry_for)


class Runner:
    def __init__(self, module_path: str, class_name: str) -> None:
        self.module_path = module_path
        self.class_name = class_name
        self._cls = getattr(importlib.import_module(module_path), class_name)
        self._instance: Any = None
        self._hooks: dict[str, Any] = {}
        self._tasks: dict[str, TaskDescriptor] = {}
        self._sessions: dict[str, Session] = {}

        self._runner_stub: RunnerServiceStub | None = None
        self._session_stub: SessionServiceStub | None = None
        self._task_stub: TaskServiceStub | None = None
        self._data_stub: DataServiceStub | None = None
        self._channel: GrpcChannel | None = None

        self._app_id: str = ""
        self._version_id: str = ""
        self._retries: int = 0
        self._loop: asyncio.AbstractEventLoop | None = None
        self._stop_event: asyncio.Event | None = None
        self._thread_stop: threading.Event | None = None
        self._signal_stop_requested: bool = False

        self._keep_warm: int = int(os.environ.get("CAPSULE_KEEP_WARM_SECONDS", "0"))
        self._last_activity: float = time.time()
        self._active_count: int = 0
        self._active_lock = asyncio.Lock()

    async def boot(self) -> None:
        self._instance = self._cls()
        for key in (_BOOT_ATTR, _SHUTDOWN_ATTR, _ENTER_ATTR, _EXIT_ATTR, _MESSAGE_ATTR):
            self._hooks[key] = _find_hook(self._instance, key)

        for name in dir(self._instance):
            attr = getattr(self._instance, name, None)
            if isinstance(attr, TaskDescriptor):
                attr._bind(self._instance, self)
                self._tasks[name] = attr

        self._rebind_services()

        if self._hooks[_BOOT_ATTR]:
            await _maybe_await(self._hooks[_BOOT_ATTR]())
        self._last_activity = time.time()

    def _rebind_services(self) -> None:
        if self._instance is None:
            return
        if self._data_stub:
            self._instance.db = DatabaseProxy(self._data_stub, self._app_id)
        if self._task_stub:
            self._instance.tasks = GlobalTaskQuery(self)
            for desc in self._tasks.values():
                desc._runner = self

    async def shutdown(self) -> None:
        if self._hooks.get(_SHUTDOWN_ATTR):
            await _maybe_await(self._hooks[_SHUTDOWN_ATTR]())

    async def _track_start(self) -> None:
        async with self._active_lock:
            self._active_count += 1
            self._last_activity = time.time()

    async def _track_end(self) -> None:
        async with self._active_lock:
            self._active_count = max(0, self._active_count - 1)
            self._last_activity = time.time()

    def _keepalive_ttl(self) -> int:
        if self._active_count > 0:
            return max(self._keep_warm, _HEARTBEAT_INTERVAL) + 10
        idle = time.time() - self._last_activity
        if self._keep_warm > 0 and idle < self._keep_warm:
            return self._keep_warm + 10
        return 0

    async def _get_session(self, msg: InboundMessage) -> tuple[Session, bool]:
        if msg.session_id in self._sessions:
            return self._sessions[msg.session_id], False

        user = UserInfo(id=msg.user_id, email=msg.user_email or None)
        channel_type = msg.channel_type or "chat"
        history: list[Message] = []
        data: dict[str, Any] = {}

        if self._session_stub:
            try:
                resp = await asyncio.get_running_loop().run_in_executor(
                    None,
                    self._session_stub.get_session,
                    GetSessionRequest(session_id=msg.session_id, history_count=50),
                )
                if resp.user_id:
                    user = UserInfo(id=resp.user_id, email=resp.user_email or None)
                if resp.channel_type:
                    channel_type = resp.channel_type
                if resp.data_json:
                    data = json.loads(resp.data_json)
                history = [
                    Message(text=e.text, sender=e.sender, channel_type=e.channel_type)
                    for e in resp.history
                ]
            except Exception as exc:
                _log(f"get_session failed: {exc}")

        session = Session(
            id=msg.session_id,
            user=user,
            channel=Channel(type=channel_type),
            history=history,
            data=data,
        )
        self._sessions[msg.session_id] = session
        return session, True

    async def _persist(self, session: Session) -> None:
        if not self._session_stub:
            return
        try:
            await asyncio.get_running_loop().run_in_executor(
                None,
                self._session_stub.save_session_data,
                SaveSessionDataRequest(
                    session_id=session.id,
                    data_json=json.dumps(session.data),
                ),
            )
        except Exception as exc:
            _log(f"save_session failed: {exc}")

    async def _handle(self, item: InboundMessage) -> None:
        await self._track_start()
        rid = item.request_id
        sid = item.session_id
        streamed = False
        session: Session | None = None

        try:
            session, is_new = await self._get_session(item)

            if is_new and self._hooks.get(_ENTER_ATTR):
                await _maybe_await(self._hooks[_ENTER_ATTR](session))

            user_msg = Message(text=item.text, sender="user", channel_type=session.channel.type)
            session.history.append(user_msg)

            pending_text: list[str] = []

            async def _reply(m):
                pending_text.append(m.text)

            async def _stream(chunks):
                nonlocal streamed
                streamed = True
                await self._stream_chunks(rid, chunks, session_id=sid)

            session._reply_callback = _reply
            session._stream_callback = _stream

            handler = self._hooks.get(_MESSAGE_ATTR)
            if handler:
                await _maybe_await(handler(session, user_msg))

            if not streamed:
                self._submit(rid, "".join(pending_text), done=True, session_id=sid)
        except Exception as exc:
            _log(f"handle error request_id={rid}: {exc}")
            if not streamed and rid:
                self._submit(rid, f"Runner error: {exc}", done=True, session_id=sid)
        finally:
            await self._track_end()
            if session is not None:
                asyncio.ensure_future(self._persist(session))

    async def _get_task_session(self, session_id: str) -> Session:
        """Build a fully wired Session for use inside a task.

        Loads history/data from the session service (same as _get_session for
        messages) and installs a _reply_callback that persists each reply to S2
        via SubmitResult.
        """
        if session_id in self._sessions:
            session = self._sessions[session_id]
        else:
            user = UserInfo(id="", email=None)
            channel_type = "chat"
            history: list[Message] = []
            data: dict[str, Any] = {}

            if self._session_stub:
                try:
                    resp = await asyncio.get_running_loop().run_in_executor(
                        None,
                        self._session_stub.get_session,
                        GetSessionRequest(session_id=session_id, history_count=50),
                    )
                    if resp.user_id:
                        user = UserInfo(id=resp.user_id, email=resp.user_email or None)
                    if resp.channel_type:
                        channel_type = resp.channel_type
                    if resp.data_json:
                        data = json.loads(resp.data_json)
                    history = [
                        Message(text=e.text, sender=e.sender, channel_type=e.channel_type)
                        for e in resp.history
                    ]
                except Exception as exc:
                    _log(f"get_session (task) failed: {exc}")

            session = Session(
                id=session_id,
                user=user,
                channel=Channel(type=channel_type),
                history=history,
                data=data,
            )
            self._sessions[session_id] = session

        async def _task_reply(msg: Message) -> None:
            rid = str(uuid.uuid4())
            self._submit(rid, msg.text, done=True, session_id=session_id)

        session._reply_callback = _task_reply
        return session

    async def _handle_task(self, delivery: TaskDelivery) -> None:
        await self._track_start()
        task_id = delivery.task_id
        task_name = delivery.task_name
        started = time.time()
        token = _current_task_id.set(task_id)
        session = None

        try:
            await self._claim_task(task_id)

            desc = self._tasks.get(task_name)
            if desc is None:
                _log(f"unknown task: {task_name}")
                await self._complete_task(task_id, TaskStatus.FAILED, f"unknown task: {task_name}")
                return

            kwargs = json.loads(delivery.kwargs_json) if delivery.kwargs_json else {}
            timeout = delivery.timeout or desc._timeout or 0
            hb = asyncio.ensure_future(self._task_heartbeat_loop(task_id))

            try:
                session = None
                if delivery.session_id:
                    session = await self._get_task_session(delivery.session_id)

                coro = desc(session, **kwargs) if session else desc(**kwargs)
                if timeout > 0:
                    await asyncio.wait_for(coro, timeout=timeout)
                else:
                    await coro

                elapsed = time.time() - started
                await self._complete_task(task_id, TaskStatus.COMPLETED, duration=elapsed)
                if desc._callback_url:
                    self._fire_callback(desc._callback_url, task_id, "completed", elapsed)

            except asyncio.TimeoutError:
                elapsed = time.time() - started
                _log(f"task {task_name} timed out after {timeout}s")
                await self._complete_task(task_id, TaskStatus.TIMEOUT, "timeout", elapsed)
                if desc._callback_url:
                    self._fire_callback(desc._callback_url, task_id, "timeout", elapsed, "timeout")

            except BaseException as exc:
                elapsed = time.time() - started
                error_msg = f"{type(exc).__name__}: {exc}"
                _log(f"task {task_name} failed: {error_msg}")

                if _retry_on_errors(desc._retry_for, exc):
                    await self._complete_task(task_id, TaskStatus.RETRY, error_msg, elapsed)
                elif desc._retry_for:
                    await self._complete_task(task_id, TaskStatus.FAILED, error_msg, elapsed)
                else:
                    await self._complete_task(task_id, TaskStatus.RETRY, error_msg, elapsed)

                if desc._callback_url:
                    self._fire_callback(desc._callback_url, task_id, "failed", elapsed, error_msg)
            finally:
                hb.cancel()

        except Exception as exc:
            _log(f"task dispatch error task_id={task_id}: {exc}")
            await self._complete_task(task_id, TaskStatus.FAILED, f"dispatch error: {exc}")
        finally:
            _current_task_id.reset(token)
            await self._track_end()
            if session is not None:
                asyncio.ensure_future(self._persist(session))

    def _fire_callback(
        self, url: str, task_id: str, status: str, duration: float, error: str = ""
    ) -> None:
        try:
            import urllib.request
            payload = json.dumps(
                {"task_id": task_id, "status": status, "duration": duration, "error": error}
            ).encode()
            req = urllib.request.Request(
                url, data=payload, headers={"Content-Type": "application/json"}, method="POST",
            )
            urllib.request.urlopen(req, timeout=10)
        except Exception as exc:
            _log(f"callback {url} failed: {exc}")

    async def _claim_task(self, task_id: str) -> None:
        if not self._task_stub:
            return
        try:
            await asyncio.get_running_loop().run_in_executor(
                None, self._task_stub.claim_task,
                ClaimTaskRequest(task_id=task_id, runner_id=self._app_id),
            )
        except Exception as exc:
            _log(f"claim_task failed: {exc}")

    async def _complete_task(
        self, task_id: str, status: TaskStatus, error: str = "", duration: float = 0
    ) -> None:
        if not self._task_stub:
            return
        for attempt in range(_GRPC_RETRY_TRIES):
            try:
                await asyncio.get_running_loop().run_in_executor(
                    None, self._task_stub.complete_task,
                    CompleteTaskRequest(
                        task_id=task_id, status=status,
                        error=error, duration_seconds=duration,
                    ),
                )
                return
            except Exception as exc:
                if attempt < _GRPC_RETRY_TRIES - 1:
                    await asyncio.sleep(_GRPC_RETRY_DELAY * (2 ** attempt))
                else:
                    _log(f"complete_task failed after {_GRPC_RETRY_TRIES} attempts: {exc}")

    async def _task_heartbeat_loop(self, task_id: str) -> None:
        while True:
            await asyncio.sleep(10)
            try:
                await asyncio.get_running_loop().run_in_executor(
                    None, self._task_stub.task_heartbeat,
                    TaskHeartbeatRequest(task_id=task_id),
                )
            except asyncio.CancelledError:
                return
            except Exception as exc:
                _log(f"task heartbeat failed: {task_id}: {exc}")

    def _submit(self, request_id: str, text: str, done: bool = False, session_id: str = "") -> None:
        if not self._runner_stub:
            return
        try:
            self._runner_stub.submit_result(
                SubmitResultRequest(request_id=request_id, text=text, done=done, session_id=session_id)
            )
        except Exception as exc:
            _log(f"submit_result failed: {exc}")

    async def _stream_chunks(self, request_id: str, chunks, session_id: str = "") -> None:
        last = ""
        async for text in chunks:
            if last:
                self._submit(request_id, last, session_id=session_id)
            last = text
        self._submit(request_id, last, done=True, session_id=session_id)
        self._last_activity = time.time()

    def _connect(self, gw: str, token: str | None) -> None:
        ch = GrpcChannel(addr=gw, token=token)
        self._channel = ch
        self._runner_stub = RunnerServiceStub(ch)
        self._session_stub = SessionServiceStub(ch)
        self._task_stub = TaskServiceStub(ch)
        self._data_stub = DataServiceStub(ch)

        from .secret import _set_resolver
        _set_resolver(self._fetch_secret)

    def _fetch_secret(self, name: str) -> str:
        stub = SecretServiceStub(self._channel)
        resp = stub.get_secret(GetSecretRequest(name=name))
        if not resp.ok:
            raise ValueError(f"secret '{name}' not found: {resp.err_msg}")
        return resp.value

    def _disconnect(self) -> None:
        ch = self._channel
        self._channel = None
        if ch:
            try:
                ch.close()
            except Exception:
                pass

    def _request_stop(self, sig: signal.Signals | None = None) -> None:
        if sig is not None:
            _log(f"received {sig.name}, shutting down")
            self._signal_stop_requested = True
            threading.Thread(target=self._hard_exit, daemon=True).start()
        if self._thread_stop:
            self._thread_stop.set()
        self._disconnect()
        if self._stop_event and not self._stop_event.is_set():
            self._stop_event.set()

    @staticmethod
    def _hard_exit(timeout: float = 3.0) -> None:
        time.sleep(timeout)
        os._exit(0)

    def _register(self) -> None:
        self._runner_stub.register(
            RegisterRequest(app_id=self._app_id, version_id=self._version_id)
        )

    def _heartbeat_loop(self, stop: threading.Event) -> None:
        while not stop.is_set():
            try:
                resp = self._runner_stub.heartbeat(HeartbeatRequest(app_id=self._app_id))
                if resp.update and resp.update.sdk_version:
                    self._do_update(resp.update.sdk_version)
                if resp.keep_warm_seconds > 0:
                    self._keep_warm = resp.keep_warm_seconds

                ttl = self._keepalive_ttl()
                if ttl > 0:
                    try:
                        self._runner_stub.keep_alive(
                            KeepAliveRequest(app_id=self._app_id, ttl_seconds=ttl)
                        )
                    except Exception as exc:
                        _log(f"keepalive failed: {exc}")
            except Exception as exc:
                _log(f"heartbeat failed: {exc}")
                return
            stop.wait(_HEARTBEAT_INTERVAL)

    def _recv_loop(self, stop: threading.Event) -> None:
        import betterproto

        while not stop.is_set():
            try:
                for resp in self._runner_stub.recv(RecvRequest(app_id=self._app_id)):
                    if stop.is_set():
                        return

                    field_name, value = betterproto.which_one_of(resp, "payload")

                    if field_name == "message" and value and value.request_id and self._loop:
                        asyncio.run_coroutine_threadsafe(self._handle(value), self._loop)
                    elif field_name == "task" and value and value.task_id and self._loop:
                        asyncio.run_coroutine_threadsafe(self._handle_task(value), self._loop)
            except Exception as exc:
                if not stop.is_set():
                    _log(f"recv stream error: {exc}")
                return

    def _do_update(self, version: str) -> None:
        _log(f"updating SDK → {version}")
        try:
            subprocess.check_call(
                [sys.executable, "-m", "pip", "install", f"cpsl=={version}"],
                stdout=sys.stderr, stderr=sys.stderr,
            )
            _log("SDK updated, takes effect on next reconnect")
        except Exception as exc:
            _log(f"update failed: {exc}")

    def _collect_meta(self) -> dict:
        from .task_types import _TASK_ATTR
        endpoints: list[dict] = []
        tasks: list[dict] = []
        schedules: list[dict] = []
        channels: list[dict] = []

        if self._instance is not None:
            for name in dir(self._instance):
                attr = getattr(self._instance, name, None)
                if attr is None:
                    continue
                ep = getattr(attr, _ENDPOINT_ATTR, None)
                if ep:
                    endpoints.append({
                        "method": ep["method"].upper(),
                        "path": ep["path"],
                        "name": name,
                        "authorized": ep.get("authorized", True),
                    })
                if getattr(attr, _TASK_ATTR, False):
                    info: dict = {"name": name}
                    if isinstance(attr, TaskDescriptor):
                        info["retries"] = attr._retries
                        info["timeout"] = attr._timeout
                    tasks.append(info)
                cron = getattr(attr, _SCHEDULE_ATTR, None)
                if cron and isinstance(cron, str):
                    schedules.append({"name": name, "cron": cron})

        from .app import _REGISTERED_CLASSES
        for reg in _REGISTERED_CLASSES:
            for ch in reg.get("channels", []):
                channels.append(ch if isinstance(ch, dict) else {"type": str(ch)})

        return {"endpoints": endpoints, "tasks": tasks, "schedules": schedules, "channels": channels}

    def _mount_endpoints(self, app: web.Application) -> None:
        meta = self._collect_meta()
        app.router.add_get("/_meta", lambda _: web.json_response(meta))

        if self._instance is None:
            return

        for name in dir(self._instance):
            attr = getattr(self._instance, name, None)
            if attr is None:
                continue

            ep = getattr(attr, _ENDPOINT_ATTR, None)
            if ep:
                method = ep["method"].upper()
                path = ep["path"]
                auth = ep.get("authorized", True)
                app.router.add_route(method, path, self._wrap_endpoint(attr, authorized=auth))
                _log(f"endpoint mounted: {method} {path} → {name} (authorized={auth})")

            asgi = getattr(attr, _ASGI_ATTR, None)
            if asgi:
                prefix = asgi["path"].rstrip("/")
                self._mount_asgi(app, prefix, attr(), name)

    def _wrap_endpoint(self, fn, *, authorized: bool = True):
        async def handler(request: web.Request) -> web.Response:
            if authorized and request.headers.get("X-Capsule-Authenticated") != "true":
                return web.json_response({"error": "unauthorized"}, status=401)
            try:
                result = await _maybe_await(fn(request))
                if isinstance(result, web.Response):
                    return result
                if isinstance(result, dict):
                    return web.json_response(result)
                return web.Response(text=str(result))
            except Exception as exc:
                _log(f"endpoint error: {exc}")
                return web.json_response({"error": str(exc)}, status=500)
        return handler

    def _mount_asgi(self, app: web.Application, prefix: str, asgi_app, name: str) -> None:
        try:
            from aiohttp_asgi import ASGIApplicationServer
            subapp = ASGIApplicationServer(asgi_app).make_aiohttp_app()
            app.add_subapp(prefix, subapp)
            _log(f"asgi mounted: {prefix}/* → {name}")
        except ImportError:
            async def handler(request: web.Request) -> web.Response:
                try:
                    scope = {
                        "type": "http",
                        "asgi": {"version": "3.0"},
                        "http_version": "1.1",
                        "method": request.method,
                        "path": request.path[len(prefix):] or "/",
                        "query_string": request.query_string.encode(),
                        "headers": [
                            (k.lower().encode(), v.encode()) for k, v in request.headers.items()
                        ],
                    }
                    body = await request.read()
                    status_code = 200
                    resp_headers: list[tuple[str, str]] = []
                    resp_body = bytearray()

                    async def receive():
                        return {"type": "http.request", "body": body}

                    async def send(message):
                        nonlocal status_code, resp_headers
                        if message["type"] == "http.response.start":
                            status_code = message["status"]
                            resp_headers = [
                                (k.decode(), v.decode()) for k, v in message.get("headers", [])
                            ]
                        elif message["type"] == "http.response.body":
                            resp_body.extend(message.get("body", b""))

                    await asgi_app(scope, receive, send)
                    resp = web.Response(body=bytes(resp_body), status=status_code)
                    for k, v in resp_headers:
                        resp.headers[k] = v
                    return resp
                except Exception as exc:
                    _log(f"asgi error: {exc}")
                    return web.json_response({"error": str(exc)}, status=500)

            app.router.add_route("*", prefix + "/{path:.*}", handler)
            app.router.add_route("*", prefix, handler)
            _log(f"asgi mounted (fallback): {prefix}/* → {name}")

    async def serve(self) -> None:
        gw = os.environ.get("CAPSULE_GATEWAY_HOST", "localhost:1980")
        self._app_id = os.environ.get("CAPSULE_APP_ID", "")
        self._version_id = os.environ.get("CAPSULE_VERSION_ID", "")
        token = os.environ.get("CAPSULE_RUNNER_TOKEN") or None
        self._loop = asyncio.get_running_loop()

        _log(f"connecting → {gw} (keep_warm={self._keep_warm}s)")

        http_app = web.Application()
        http_app.router.add_get("/health", lambda _: web.json_response({"ok": True}))
        self._mount_endpoints(http_app)
        http_runner = web.AppRunner(http_app)
        await http_runner.setup()
        try:
            await web.TCPSite(http_runner, "0.0.0.0", _PORT, reuse_address=True).start()
        except OSError:
            _log(f"port {_PORT} in use, skipping http")

        stop = asyncio.Event()
        self._stop_event = stop
        for sig in (signal.SIGTERM, signal.SIGINT):
            self._loop.add_signal_handler(sig, lambda s=sig: self._request_stop(s))

        while not stop.is_set():
            self._disconnect()
            self._connect(gw, token)

            try:
                self._register()
                self._retries = 0
                _log(f"connected app_id={self._app_id}")

                self._rebind_services()

                thread_stop = threading.Event()
                self._thread_stop = thread_stop
                hb_thread = threading.Thread(
                    target=self._heartbeat_loop, args=(thread_stop,), daemon=True
                )
                rx_thread = threading.Thread(
                    target=self._recv_loop, args=(thread_stop,), daemon=True
                )
                hb_thread.start()
                rx_thread.start()

                while not stop.is_set() and hb_thread.is_alive() and rx_thread.is_alive():
                    await asyncio.sleep(1)

                thread_stop.set()
                self._disconnect()
                join_timeout = 0.5 if stop.is_set() else 2
                hb_thread.join(timeout=join_timeout)
                rx_thread.join(timeout=join_timeout)
                self._thread_stop = None

                if stop.is_set():
                    break

            except Exception as exc:
                _log(f"connection error: {exc}")

            backoff = min(2 ** self._retries, _MAX_BACKOFF)
            self._retries += 1
            _log(f"reconnecting in {backoff}s (attempt {self._retries})")
            try:
                await asyncio.wait_for(stop.wait(), timeout=backoff)
                break
            except asyncio.TimeoutError:
                pass

        self._disconnect()
        self._thread_stop = None
        self._stop_event = None

        try:
            await asyncio.wait_for(self.shutdown(), timeout=5)
        except asyncio.TimeoutError:
            _log("shutdown hook timed out")

        try:
            await asyncio.wait_for(http_runner.cleanup(), timeout=3)
        except asyncio.TimeoutError:
            _log("http cleanup timed out")

        if self._signal_stop_requested:
            os._exit(0)


def main() -> None:
    if len(sys.argv) != 2 or ":" not in sys.argv[1]:
        print("Usage: python -m cpsl.runner <module>:<Class>", file=sys.stderr)
        sys.exit(1)

    mod, cls = sys.argv[1].rsplit(":", 1)

    sys.stdout = StdoutJsonInterceptor(sys.__stdout__)
    sys.stderr = StdoutJsonInterceptor(sys.__stdout__)

    async def _run():
        r = Runner(mod, cls)
        await r.boot()
        await r.serve()

    asyncio.run(_run())


if __name__ == "__main__":
    main()
