"""Shared utilities for CLI commands (deploy, serve)."""

import importlib
import json
import os
import sys
import tempfile
import zipfile
from pathlib import Path

from . import terminal

IGNORE_PATTERNS = {
    ".git",
    ".venv",
    "venv",
    "__pycache__",
    ".pytest_cache",
    ".ruff_cache",
    "node_modules",
    ".DS_Store",
    ".idea",
    ".vscode",
    ".env.local",
    ".envrc",
    ".next",
    ".capsuleignore",
}

IGNORE_EXTENSIONS = {".pyc"}


def resolve_entry_point(entry_point: str) -> dict:
    """Import the entry point module, resolve the decorated class, and return
    its ``_cpsl_config`` dict.

    Accepts formats like ``app:DietCoach`` or ``examples/diet_coach/app.py:DietCoach``.
    When a file path is given, the working directory is changed to the file's
    parent so relative imports and source collection work correctly.
    """
    if ":" not in entry_point:
        terminal.error(
            "Invalid entry point. Expected format: capsule <command> [file.py]:[ClassName]"
        )

    module_path, class_name = entry_point.rsplit(":", 1)
    if not class_name:
        terminal.error(
            "Invalid entry point. Expected format: capsule <command> [file.py]:[ClassName]"
        )

    file_path = Path(module_path)
    if file_path.parent != Path("."):
        os.chdir(file_path.parent)
        module_name = file_path.stem
    else:
        module_name = module_path.replace(".py", "")

    cwd = os.getcwd()
    if cwd not in sys.path:
        sys.path.insert(0, cwd)

    try:
        mod = importlib.import_module(module_name)
    except ImportError as e:
        terminal.error(f"Cannot import '{module_path}': {e}")

    klass = getattr(mod, class_name, None)
    if klass is None:
        terminal.error(f"Class '{class_name}' not found in module '{module_path}'")

    config = getattr(klass, "_cpsl_config", None)
    if config is None:
        terminal.error(f"Class '{class_name}' is not decorated with @app.cls")

    return config


def should_ignore(name: str) -> bool:
    """Return True if *name* matches an ignore pattern or extension."""
    if name in IGNORE_PATTERNS:
        return True
    return any(name.endswith(ext) for ext in IGNORE_EXTENSIONS)


def collect_source_archive() -> bytes:
    """ZIP the current working directory, respecting ignore patterns."""
    root = Path.cwd()
    tmp = tempfile.NamedTemporaryFile(delete=False, suffix=".zip")
    tmp.close()
    file_count = 0

    try:
        with zipfile.ZipFile(tmp.name, "w", zipfile.ZIP_DEFLATED) as zf:
            for dirpath, dirnames, filenames in os.walk(root):
                dirnames[:] = [d for d in dirnames if not should_ignore(d)]
                for fname in filenames:
                    if should_ignore(fname):
                        continue
                    full = os.path.join(dirpath, fname)
                    rel = os.path.relpath(full, root)
                    zf.write(full, rel)
                    terminal.detail(f"  + {rel}")
                    file_count += 1

        data = Path(tmp.name).read_bytes()
        terminal.detail(
            f"  {file_count} file{'' if file_count == 1 else 's'}, "
            f"{terminal.humanize_memory(len(data), base=10)}"
        )
        return data
    finally:
        os.unlink(tmp.name)


def build_image_spec(image: dict):
    """Build a gRPC ``ImageSpec`` from the config dict."""
    from .clients.capsule import ImageSpec

    return ImageSpec(
        python_packages=image.get("python_packages", []),
        apt_packages=image.get("apt_packages", []),
        commands=image.get("commands", []),
    )


def build_channel_specs(channels: list[dict]):
    """Build a list of gRPC ``ChannelSpec`` from channel config dicts."""
    from .clients.capsule import ChannelSpec

    return [
        ChannelSpec(
            type=ch["type"],
            config={
                k: (json.dumps(v) if isinstance(v, dict) else str(v))
                for k, v in ch.items()
                if k != "type"
            },
        )
        for ch in channels
    ]
