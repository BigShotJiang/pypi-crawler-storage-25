"""Document collection interface — self.db.{collection}.

Provides Mongo-style operations (find, insert_one, update_one, etc.)
proxied through the DataService gRPC.
"""

from __future__ import annotations

import asyncio
import json
from typing import Any, TYPE_CHECKING

if TYPE_CHECKING:
    from .clients.capsule import DataServiceStub


class Collection:
    """Proxy for a single document collection."""

    __slots__ = ("_stub", "_app_id", "_name")

    def __init__(self, stub: DataServiceStub, app_id: str, name: str) -> None:
        self._stub = stub
        self._app_id = app_id
        self._name = name

    async def insert_one(self, document: dict) -> dict:
        from .clients.capsule import InsertOneRequest
        doc_json = json.dumps(document).encode()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.insert_one,
            InsertOneRequest(app_id=self._app_id, collection=self._name, document_json=doc_json),
        )
        result = dict(document)
        result["_id"] = resp.id
        return result

    async def insert_many(self, documents: list[dict]) -> list[dict]:
        from .clients.capsule import InsertManyRequest
        docs_json = [json.dumps(d).encode() for d in documents]
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.insert_many,
            InsertManyRequest(app_id=self._app_id, collection=self._name, documents_json=docs_json),
        )
        results = []
        for doc, id_ in zip(documents, resp.ids):
            r = dict(doc)
            r["_id"] = id_
            results.append(r)
        return results

    async def find_one(self, filter: dict | None = None) -> dict | None:
        from .clients.capsule import FindOneRequest
        filter_json = json.dumps(filter or {}).encode()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.find_one,
            FindOneRequest(app_id=self._app_id, collection=self._name, filter_json=filter_json),
        )
        if not resp.document_json:
            return None
        return json.loads(resp.document_json)

    async def find(self, filter: dict | None = None, limit: int = 0, skip: int = 0,
                   sort: dict | None = None) -> list[dict]:
        from .clients.capsule import FindRequest
        filter_json = json.dumps(filter or {}).encode()
        sort_json = json.dumps(sort or {}).encode() if sort else b''
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.find,
            FindRequest(
                app_id=self._app_id,
                collection=self._name,
                filter_json=filter_json,
                limit=limit,
                skip=skip,
                sort_json=sort_json,
            ),
        )
        return [json.loads(d) for d in resp.documents_json]

    async def update_one(self, filter: dict, update: dict) -> dict:
        from .clients.capsule import UpdateOneRequest
        filter_json = json.dumps(filter).encode()
        update_json = json.dumps(update).encode()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.update_one,
            UpdateOneRequest(
                app_id=self._app_id,
                collection=self._name,
                filter_json=filter_json,
                update_json=update_json,
            ),
        )
        return {"matched": resp.matched, "modified": resp.modified}

    async def delete_one(self, filter: dict) -> dict:
        from .clients.capsule import DeleteOneRequest
        filter_json = json.dumps(filter).encode()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.delete_one,
            DeleteOneRequest(app_id=self._app_id, collection=self._name, filter_json=filter_json),
        )
        return {"deleted": resp.deleted}

    async def count(self, filter: dict | None = None) -> int:
        from .clients.capsule import CountRequest
        filter_json = json.dumps(filter or {}).encode()
        resp = await asyncio.get_running_loop().run_in_executor(
            None, self._stub.count,
            CountRequest(app_id=self._app_id, collection=self._name, filter_json=filter_json),
        )
        return resp.count


class DatabaseProxy:
    """Attribute-based collection access: self.db.prospects → Collection('prospects')."""

    def __init__(self, stub: DataServiceStub, app_id: str) -> None:
        self._stub = stub
        self._app_id = app_id
        self._collections: dict[str, Collection] = {}

    def __getattr__(self, name: str) -> Collection:
        if name.startswith("_"):
            raise AttributeError(name)
        if name not in self._collections:
            self._collections[name] = Collection(self._stub, self._app_id, name)
        return self._collections[name]
