import os
import signal
import time
from queue import Empty, Queue
from threading import Event

import click
import grpc

from .. import terminal
from ..channel import ServiceClient, pass_service_client
from ..clients.capsule import (
    ListAppsRequest,
    ListAppsResponse,
    ServeAttachRequest,
    ServeStreamMessage,
    ServeSyncRequest,
    StartServeRequest,
    StartServeResponse,
)
from ..utils import (
    resolve_entry_point,
    collect_source_archive,
    build_image_spec,
    build_channel_specs,
)

SYNC_INTERVAL = 0.1
HEARTBEAT_INTERVAL = 5.0
GATEWAY_READY_TIMEOUT = 5.0
START_SERVE_TIMEOUT = 180.0


@click.command("serve")
@click.argument("entry_point")
@pass_service_client
def serve(client: ServiceClient, entry_point: str):
    """Serve an app with hot-reload.

    ENTRY_POINT is <module>:<ClassName>, e.g. app:DietCoach
    """
    from watchdog.events import FileSystemEventHandler
    from watchdog.observers import Observer

    shutdown = Event()

    def _handle_signal(signum, frame):
        shutdown.set()

    signal.signal(signal.SIGTERM, _handle_signal)
    signal.signal(signal.SIGINT, _handle_signal)

    class _SyncHandler(FileSystemEventHandler):
        def __init__(self, queue: Queue):
            super().__init__()
            self.queue = queue

        def on_created(self, event):
            if event.is_directory or not event.src_path.endswith(".py"):
                return
            try:
                with open(event.src_path, "rb") as f:
                    self.queue.put((event.src_path, f.read(), False))
            except OSError:
                pass

        def on_modified(self, event):
            self.on_created(event)

        def on_deleted(self, event):
            if event.is_directory or not event.src_path.endswith(".py"):
                return
            self.queue.put((event.src_path, b"", True))

    config = resolve_entry_point(entry_point)

    image = config["image"]
    channels = config.get("channels", [])
    secrets = config.get("secrets", [])
    keep_warm = config.get("keep_warm_seconds", 0)
    filesystems = config.get("filesystems", {})

    terminal.header("Serving", f"[bold]{config['app_name']}[/bold]")
    terminal.detail(f"  entry:     {config['module']}:{config['class_name']}")

    if secrets:
        terminal.detail(f"  secrets:   {', '.join(secrets)}")
    if keep_warm > 0:
        terminal.detail(f"  keep_warm: {keep_warm}s")
    if image.get("python_packages"):
        terminal.detail(f"  pip:       {', '.join(image['python_packages'])}")
    if image.get("apt_packages"):
        terminal.detail(f"  apt:       {', '.join(image['apt_packages'])}")
    if image.get("commands"):
        terminal.detail(f"  commands:  {len(image['commands'])}")

    terminal.header("Syncing files")
    archive = collect_source_archive()

    req = StartServeRequest(
        app_name=config["app_name"],
        image=build_image_spec(image),
        channels=build_channel_specs(channels),
        entry_point=f"{config['module']}:{config['class_name']}",
        source_archive=archive,
        keep_warm_seconds=keep_warm,
        secrets=secrets,
        filesystems=filesystems,
    )

    with terminal.progress("Starting machine..."):
        t0 = time.monotonic()
        list_apps = client.channel.unary_unary(
            "/capsule.CapsuleService/ListApps",
            ListAppsRequest.SerializeToString,
            ListAppsResponse.FromString,
        )
        try:
            list_apps(ListAppsRequest(), timeout=GATEWAY_READY_TIMEOUT)
        except grpc.RpcError as err:
            if err.code() in (grpc.StatusCode.DEADLINE_EXCEEDED, grpc.StatusCode.UNAVAILABLE):
                terminal.error(
                    "Gateway gRPC tunnel is not responding. "
                    "If you're using local dev, restart `make start`."
                )
                raise SystemExit(1)
            raise

        start_serve = client.channel.unary_unary(
            "/capsule.CapsuleService/StartServe",
            StartServeRequest.SerializeToString,
            StartServeResponse.FromString,
        )
        try:
            res = start_serve(req, timeout=START_SERVE_TIMEOUT)
        except grpc.RpcError as err:
            if err.code() == grpc.StatusCode.DEADLINE_EXCEEDED:
                terminal.error(
                    "Timed out waiting for StartServe. "
                    "If you're using local dev, restart `make start`."
                )
                raise SystemExit(1)
            raise
        elapsed = time.monotonic() - t0

    if not res.ok:
        terminal.error(f"Serve failed: {res.err_msg}")
        raise SystemExit(1)

    app_id = res.app_id
    instance_ref = res.instance_ref

    terminal.success(f"Ready in {elapsed:.1f}s")
    terminal.header(f"Serving {config['app_name']}")
    terminal.info(f"  [bold #4CCACC]https://{res.hostname}.capsule.new[/bold #4CCACC]")
    terminal.detail(f"  console: http://{res.hostname}.localhost:5174")
    terminal.detail(f"  instance: {instance_ref}")

    sync_dir = os.getcwd()

    def _stop_remote_serve():
        def _stop_generator():
            yield ServeStreamMessage(
                attach=ServeAttachRequest(app_id=app_id, instance_ref=instance_ref)
            )
            yield ServeStreamMessage(
                sync=ServeSyncRequest(path="", data=b"", is_delete=True)
            )

        try:
            stream = client.capsule.serve_stream(_stop_generator())
            for _ in stream:
                break
        except grpc.RpcError:
            pass

    def _stream_generator():
        yield ServeStreamMessage(
            attach=ServeAttachRequest(app_id=app_id, instance_ref=instance_ref)
        )
        yield from _sync_dir(sync_dir)

    def _sync_dir(dir: str):
        queue: Queue = Queue()
        handler = _SyncHandler(queue)
        observer = Observer()
        observer.schedule(handler, dir, recursive=True)
        observer.start()
        last_heartbeat = time.monotonic()

        terminal.header("Watching for changes...")
        try:
            while True:
                if shutdown.is_set():
                    yield ServeStreamMessage(
                        sync=ServeSyncRequest(path="", data=b"", is_delete=True)
                    )
                    return
                try:
                    path, data, is_delete = queue.get_nowait()
                    rel = os.path.relpath(path, start=dir)
                    if is_delete:
                        terminal.warn(f"Deleted '{rel}'. Reloading...")
                    else:
                        terminal.warn(f"Changed '{rel}'. Reloading...")
                    yield ServeStreamMessage(
                        sync=ServeSyncRequest(
                            path=rel,
                            data=data,
                            is_delete=is_delete,
                        )
                    )
                    queue.task_done()
                    last_heartbeat = time.monotonic()
                except Empty:
                    now = time.monotonic()
                    if now-last_heartbeat >= HEARTBEAT_INTERVAL:
                        yield ServeStreamMessage(
                            sync=ServeSyncRequest(path="", data=b"", is_delete=False)
                        )
                        last_heartbeat = now
                    else:
                        time.sleep(SYNC_INTERVAL)
        finally:
            observer.stop()
            observer.join(timeout=1)

    try:
        stream = client.capsule.serve_stream(_stream_generator())
        for resp in stream:
            if shutdown.is_set():
                break
            if resp.output:
                terminal.detail(resp.output, dim=False, end="")
            if resp.done:
                break
    except KeyboardInterrupt:
        shutdown.set()
    except grpc.RpcError as err:
        if not shutdown.is_set() and err.code() != grpc.StatusCode.CANCELLED:
            raise

    terminal.header("Stopping serve")
    shutdown.set()
    _stop_remote_serve()
    client.close()
