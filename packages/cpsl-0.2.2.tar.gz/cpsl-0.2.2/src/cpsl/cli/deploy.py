import click

from .. import terminal
from ..channel import pass_service_client, ServiceClient
from ..utils import (
    resolve_entry_point,
    collect_source_archive,
    build_image_spec,
    build_channel_specs,
)


@click.command("deploy")
@click.argument("entry_point")
@pass_service_client
def deploy(client: ServiceClient, entry_point: str):
    """Deploy an app.

    ENTRY_POINT is <module>:<ClassName>, e.g. myapp:OutreachAgent
    """
    config = resolve_entry_point(entry_point)

    image = config["image"]
    channels = config.get("channels", [])
    secrets = config.get("secrets", [])
    keep_warm = config.get("keep_warm_seconds", 0)
    filesystems = config.get("filesystems", {})

    terminal.header("Deploying", f"[bold]{config['app_name']}[/bold]")
    terminal.detail(f"  entry:    {config['module']}:{config['class_name']}")
    terminal.detail(f"  price:    {config['price']}¢")
    terminal.detail(f"  channels: {len(channels)}")

    if secrets:
        terminal.detail(f"  secrets:  {', '.join(secrets)}")

    if keep_warm > 0:
        terminal.detail(f"  keep_warm: {keep_warm}s")

    if filesystems:
        for mount, name in filesystems.items():
            terminal.detail(f"  fs:       {mount} -> {name}")

    if image.get("python_packages"):
        terminal.detail(f"  pip:      {', '.join(image['python_packages'])}")
    if image.get("apt_packages"):
        terminal.detail(f"  apt:      {', '.join(image['apt_packages'])}")

    terminal.header("Syncing files")
    archive = collect_source_archive()

    terminal.header("Pushing")

    from ..clients.capsule import DeployRequest

    req = DeployRequest(
        app_name=config["app_name"],
        image=build_image_spec(image),
        channels=build_channel_specs(channels),
        entry_point=f"{config['module']}:{config['class_name']}",
        price_in_cents=config["price"],
        source_archive=archive,
        keep_warm_seconds=keep_warm,
        secrets=secrets,
        filesystems=filesystems,
    )

    with terminal.progress("Provisioning machine..."):
        res = client.capsule.deploy(req)

    if not res.ok:
        terminal.error(f"Deploy failed: {res.err_msg}")

    terminal.header(f"Deployed {config['app_name']} v{res.version} 🎉")
    terminal.info(f"  https://{res.hostname}.capsule.new")
    terminal.detail(f"  console: http://{res.hostname}.localhost:5174")
