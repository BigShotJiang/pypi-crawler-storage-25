"""Convert PPTX to text using [python-pptx]"""

__version__ = "1.8.61"
