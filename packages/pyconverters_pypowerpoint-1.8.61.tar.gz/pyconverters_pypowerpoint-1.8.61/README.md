# pyconverters_pypowerpoint

[![license](https://img.shields.io/github/license/oterrier/pyconverters_pypowerpoint)](https://github.com/oterrier/pyconverters_pypowerpoint/blob/master/LICENSE)
[![tests](https://github.com/oterrier/pyconverters_pypowerpoint/workflows/tests/badge.svg)](https://github.com/oterrier/pyconverters_pypowerpoint/actions?query=workflow%3Atests)
[![codecov](https://img.shields.io/codecov/c/github/oterrier/pyconverters_pypowerpoint)](https://codecov.io/gh/oterrier/pyconverters_pypowerpoint)
[![docs](https://img.shields.io/readthedocs/pyconverters_pypowerpoint)](https://pyconverters_pypowerpoint.readthedocs.io)
[![version](https://img.shields.io/pypi/v/pyconverters_pypowerpoint)](https://pypi.org/project/pyconverters_pypowerpoint/)
[![PyPI - Python Version](https://img.shields.io/pypi/pyversions/pyconverters_pypowerpoint)](https://pypi.org/project/pyconverters_pypowerpoint/)

Convert PPTX presentations to Markdown using [python-pptx](https://github.com/scanny/python-pptx).

## Features

- Converts PowerPoint slides to Markdown text (headings, lists, paragraphs, tables)
- Optionally segments the output by slide (one `Sentence` span per page)
- Optionally extracts embedded images as base64 data URIs, either as Markdown links or as `AltText` objects attached to the document
- Registers as a `pyconverters` plugin under the entry point `pypowerpoint`

## Requirements

- Python ≥ 3.12

## Installation

```
pip install pyconverters_pypowerpoint
```

## Parameters

| Parameter | Type | Default | Description |
|-----------|------|---------|-------------|
| `one_segment_per_powerpoint_page` | `bool` | `False` | Add one `Sentence` span per slide in the output document |
| `include_image_base64_as_links` | `bool` | `False` | Embed images as `![name](data:image/...;base64,...)` links in the Markdown text |
| `include_image_base64_as_altTexts` | `bool` | `False` | Attach images as `AltText` objects on the document (with `mime-type` property) |

## Developing

### Pre-requisites

Install [uv](https://docs.astral.sh/uv/):

```
pip install uv
```

Clone the repository:

```
git clone https://github.com/oterrier/pyconverters_pypowerpoint
cd pyconverters_pypowerpoint
```

Install the package with test dependencies:

```
uv sync --extra test
```

### Running the test suite

```
uv run pytest
```

### Linting

```
uv run ruff check .
uv run ruff format --check .
```

### Building the documentation

```
uv run --extra docs sphinx-build docs docs/_build
```

The built documentation is available at `docs/_build/index.html`.

## SBOM & vulnerability check

Install the SBOM dependencies:

```
uv sync --extra sbom
```

Generate a CycloneDX SBOM from the current environment:

```
uv run cyclonedx-py environment -o sbom.cdx.json --output-format json
```

Audit dependencies for known vulnerabilities:

```
uv run pip-audit --format json --output audit-report.json
```

To fail on any known vulnerability (useful in CI):

```
uv run pip-audit --strict
```
