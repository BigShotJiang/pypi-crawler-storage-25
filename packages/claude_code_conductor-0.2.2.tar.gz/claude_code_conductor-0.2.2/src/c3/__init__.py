"""Claude Code Conductor (C3) - multi-agent orchestration framework for Claude Code."""

__version__ = "0.2.2"
