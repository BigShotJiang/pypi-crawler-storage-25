"""Office document handling implementations."""
