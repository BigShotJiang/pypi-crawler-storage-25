"""Workspace environment implementations."""
