"""Finder implementations."""
