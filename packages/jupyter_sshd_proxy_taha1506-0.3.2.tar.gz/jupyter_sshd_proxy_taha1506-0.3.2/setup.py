import setuptools
from os import path

HERE = path.abspath(path.dirname(__file__))
with open(path.join(HERE, 'README.md'), encoding='utf-8') as f:
    long_description = f.read()

setuptools.setup(
    name="jupyter-sshd-proxy-taha1506",
    version='0.3.2',
    url="https://github.com/Taha1506/jupyter-sshd-proxy",
    author="Taha Akbari Alvanagh",
    author_email="tahaakbarialvanagh@gmail.com",
    description="Run sshd under jupyter",
    long_description=long_description,
    long_description_content_type='text/markdown',
    packages=setuptools.find_packages(),
    classifiers=['Framework :: Jupyter'],
    install_requires=[
        'jupyter-server-proxy>=4.3.0'
    ],
    entry_points={
        'jupyter_serverproxy_servers': [
            'sshd = jupyter_sshd_proxy:setup_sshd',
        ]
    }
)
