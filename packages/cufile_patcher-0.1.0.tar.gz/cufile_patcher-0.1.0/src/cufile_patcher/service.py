from __future__ import annotations


class HelloWorldPlugin:
    name = "hello_world"

    def message(self) -> str:
        return "Hello, world!"


class PluginService:
    def __init__(self) -> None:
        self._plugins: dict[str, HelloWorldPlugin] = {}

    def register(self, plugin: HelloWorldPlugin) -> None:
        self._plugins[plugin.name] = plugin

    def hello_world(self) -> str:
        return self._plugins["hello_world"].message()


def create_default_service() -> PluginService:
    service = PluginService()
    service.register(HelloWorldPlugin())
    return service
