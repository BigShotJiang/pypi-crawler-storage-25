from __future__ import annotations

from collections.abc import Callable

from .plugins import CuFileBackend, SystemCuFileBackend


class BackendRegistry:
    def __init__(self) -> None:
        self._factories: dict[str, Callable[[], CuFileBackend]] = {}
        self._instances: dict[str, CuFileBackend] = {}
        self._default_name = "system"

    def register(self, name: str, factory: Callable[[], CuFileBackend]) -> None:
        if not name:
            raise ValueError("backend name must not be empty")
        self._factories[name] = factory
        self._instances.pop(name, None)

    def set_default(self, name: str) -> None:
        if name not in self._factories:
            raise KeyError(f"backend '{name}' is not registered")
        self._default_name = name

    def get_default(self) -> CuFileBackend:
        return self.get(self._default_name)

    def get(self, name: str) -> CuFileBackend:
        if name in self._instances:
            return self._instances[name]
        try:
            factory = self._factories[name]
        except KeyError as exc:
            raise KeyError(f"backend '{name}' is not registered") from exc
        backend = factory()
        self._instances[name] = backend
        return backend


_registry = BackendRegistry()
_registry.register("system", SystemCuFileBackend)


def register_backend(name: str, factory: Callable[[], CuFileBackend]) -> None:
    _registry.register(name, factory)


def set_default_backend(name: str) -> None:
    _registry.set_default(name)


def get_default_backend() -> CuFileBackend:
    return _registry.get_default()
