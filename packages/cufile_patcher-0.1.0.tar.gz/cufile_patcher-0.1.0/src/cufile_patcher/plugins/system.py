from __future__ import annotations

import ctypes

from ..cufile_types import CUfileDescr, CUfileError, CUfileHandle_t, DescrUnion
from .base import CuFileBackend


class SystemCuFileBackend(CuFileBackend):
    """Backend that calls the system-installed libcufile via ctypes."""

    def __init__(self, library_name: str = "libcufile.so") -> None:
        try:
            self._lib = ctypes.CDLL(library_name)
        except OSError as exc:
            raise RuntimeError(
                "unable to load libcufile.so; ensure cuFile is installed"
            ) from exc
        self._configure_signatures()

    def _configure_signatures(self) -> None:
        self._lib.cuFileDriverOpen.restype = CUfileError
        self._lib.cuFileDriverClose.restype = CUfileError
        self._lib.cuFileHandleRegister.restype = CUfileError
        self._lib.cuFileHandleDeregister.restype = CUfileError
        self._lib.cuFileRead.restype = ctypes.c_size_t
        self._lib.cuFileWrite.restype = ctypes.c_size_t

        self._lib.cuFileHandleRegister.argtypes = [
            ctypes.POINTER(CUfileHandle_t),
            ctypes.POINTER(CUfileDescr),
        ]
        self._lib.cuFileHandleDeregister.argtypes = [CUfileHandle_t]
        self._lib.cuFileRead.argtypes = [
            CUfileHandle_t,
            ctypes.c_void_p,
            ctypes.c_size_t,
            ctypes.c_longlong,
            ctypes.c_longlong,
        ]
        self._lib.cuFileWrite.argtypes = [
            CUfileHandle_t,
            ctypes.c_void_p,
            ctypes.c_size_t,
            ctypes.c_longlong,
            ctypes.c_longlong,
        ]

    @staticmethod
    def _check_status(status: CUfileError, name: str) -> None:
        if status.err != 0:
            raise RuntimeError(
                f"{name} failed (cuFile err={status.err}, cuda_err={status.cu_err})"
            )

    def driver_open(self) -> None:
        self._check_status(self._lib.cuFileDriverOpen(), "cuFileDriverOpen")

    def driver_close(self) -> None:
        self._check_status(self._lib.cuFileDriverClose(), "cuFileDriverClose")

    def handle_register(self, fd: int) -> CUfileHandle_t:
        descr = CUfileDescr(type=1, handle=DescrUnion(fd=fd), fs_ops=None)
        handle = CUfileHandle_t()
        status = self._lib.cuFileHandleRegister(ctypes.byref(handle), ctypes.byref(descr))
        self._check_status(status, "cuFileHandleRegister")
        return handle

    def handle_deregister(self, handle: CUfileHandle_t) -> None:
        self._check_status(
            self._lib.cuFileHandleDeregister(handle), "cuFileHandleDeregister"
        )

    def read(
        self,
        handle: CUfileHandle_t,
        buf: ctypes.c_void_p,
        size: int,
        file_offset: int,
        dev_offset: int,
    ) -> int:
        return int(self._lib.cuFileRead(handle, buf, size, file_offset, dev_offset))

    def write(
        self,
        handle: CUfileHandle_t,
        buf: ctypes.c_void_p,
        size: int,
        file_offset: int,
        dev_offset: int,
    ) -> int:
        return int(self._lib.cuFileWrite(handle, buf, size, file_offset, dev_offset))
