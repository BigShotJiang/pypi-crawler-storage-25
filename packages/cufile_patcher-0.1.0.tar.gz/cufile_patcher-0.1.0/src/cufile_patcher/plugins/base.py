from __future__ import annotations

import ctypes
from abc import ABC, abstractmethod

from ..cufile_types import CUfileHandle_t


class CuFileBackend(ABC):
    """Interface for pluggable cuFile backend implementations."""

    @abstractmethod
    def driver_open(self) -> None:
        ...

    @abstractmethod
    def driver_close(self) -> None:
        ...

    @abstractmethod
    def handle_register(self, fd: int) -> CUfileHandle_t:
        ...

    @abstractmethod
    def handle_deregister(self, handle: CUfileHandle_t) -> None:
        ...

    @abstractmethod
    def read(
        self,
        handle: CUfileHandle_t,
        buf: ctypes.c_void_p,
        size: int,
        file_offset: int,
        dev_offset: int,
    ) -> int:
        ...

    @abstractmethod
    def write(
        self,
        handle: CUfileHandle_t,
        buf: ctypes.c_void_p,
        size: int,
        file_offset: int,
        dev_offset: int,
    ) -> int:
        ...
