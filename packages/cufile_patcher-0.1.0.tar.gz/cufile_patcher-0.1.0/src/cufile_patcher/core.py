from .service import create_default_service

_DEFAULT_SERVICE = create_default_service()


def hello_world() -> str:
    return _DEFAULT_SERVICE.hello_world()
