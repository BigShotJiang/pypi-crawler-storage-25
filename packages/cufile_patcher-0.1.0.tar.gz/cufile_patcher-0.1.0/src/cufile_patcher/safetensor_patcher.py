from __future__ import annotations

import ctypes
import os
from abc import ABC, abstractmethod
from pathlib import Path
from tempfile import TemporaryDirectory
from types import ModuleType
from typing import Any

from .cufile import CuFile


class SafeTensorStreamReader(ABC):
    """Plugin contract for reading safetensor files in chunks."""

    @abstractmethod
    def iter_chunks(self, file_path: str, chunk_size: int):
        """Yield file bytes in chunk-sized pieces."""


class PythonSafeTensorStreamReader(SafeTensorStreamReader):
    """Portable chunk reader that works without GPU dependencies."""

    def iter_chunks(self, file_path: str, chunk_size: int):
        with open(file_path, "rb") as fp:
            while True:
                chunk = fp.read(chunk_size)
                if not chunk:
                    break
                yield chunk


class CuFileSafeTensorStreamReader(SafeTensorStreamReader):
    """Chunk reader that pulls data through the CuFile wrapper."""

    def iter_chunks(self, file_path: str, chunk_size: int):
        file_size = os.path.getsize(file_path)
        offset = 0

        with CuFile(file_path, "r") as cu_file:
            while offset < file_size:
                to_read = min(chunk_size, file_size - offset)
                staging = ctypes.create_string_buffer(to_read)
                read_n = cu_file.read(
                    ctypes.cast(staging, ctypes.c_void_p),
                    to_read,
                    file_offset=offset,
                )
                if read_n <= 0:
                    break
                offset += read_n
                yield staging.raw[:read_n]


class SafeTensorCuFilePatcher:
    """
    Monkey-patch safetensors.torch.load_file for chunked streaming of large files.

    Large path-based loads are streamed into a temporary safetensor path before
    invoking the original loader. Small files keep original behavior.
    """

    def __init__(
        self,
        safetensors_torch_module: ModuleType,
        *,
        min_file_size_mb: int = 64,
        chunk_size_mb: int = 16,
        stream_reader: SafeTensorStreamReader | None = None,
        use_cufile: bool = False,
        fallback_to_original: bool = True,
    ) -> None:
        self._st = safetensors_torch_module
        self._min_file_size = max(1, min_file_size_mb) * 1024 * 1024
        self._chunk_size = max(1, chunk_size_mb) * 1024 * 1024
        self._reader = stream_reader or (
            CuFileSafeTensorStreamReader() if use_cufile else PythonSafeTensorStreamReader()
        )
        self._fallback_to_original = fallback_to_original
        self._original_load_file = None

    @property
    def installed(self) -> bool:
        return self._original_load_file is not None

    def install(self) -> None:
        if self.installed:
            return
        self._original_load_file = self._st.load_file
        self._st.load_file = self._patched_load_file

    def uninstall(self) -> None:
        if not self.installed:
            return
        self._st.load_file = self._original_load_file
        self._original_load_file = None

    def _should_stream(self, source: Any) -> bool:
        if not isinstance(source, (str, os.PathLike, Path)):
            return False
        source_path = os.fspath(source)
        if not os.path.isfile(source_path):
            return False
        return os.path.getsize(source_path) >= self._min_file_size

    def _patched_load_file(self, source: Any, *args: Any, **kwargs: Any):
        if not self._should_stream(source):
            return self._original_load_file(source, *args, **kwargs)

        source_path = os.fspath(source)
        try:
            return self._streaming_load_file(source_path, *args, **kwargs)
        except Exception:
            if not self._fallback_to_original:
                raise
            return self._original_load_file(source, *args, **kwargs)

    def _streaming_load_file(self, file_path: str, *args: Any, **kwargs: Any):
        with TemporaryDirectory() as temp_dir:
            temp_path = os.path.join(temp_dir, "streamed.safetensors")
            with open(temp_path, "wb") as out_file:
                for chunk in self._reader.iter_chunks(file_path, self._chunk_size):
                    out_file.write(chunk)
            return self._original_load_file(temp_path, *args, **kwargs)


def patch_safetensor_load_file(
    safetensors_torch_module: ModuleType,
    *,
    min_file_size_mb: int = 64,
    chunk_size_mb: int = 16,
    stream_reader: SafeTensorStreamReader | None = None,
    use_cufile: bool = False,
    fallback_to_original: bool = True,
) -> SafeTensorCuFilePatcher:
    patcher = SafeTensorCuFilePatcher(
        safetensors_torch_module,
        min_file_size_mb=min_file_size_mb,
        chunk_size_mb=chunk_size_mb,
        stream_reader=stream_reader,
        use_cufile=use_cufile,
        fallback_to_original=fallback_to_original,
    )
    patcher.install()
    return patcher
