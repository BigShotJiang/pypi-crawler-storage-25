"""cufile-patcher: plugin-oriented cuFile wrapper and extension scaffold."""

from .auto_patch import AutoPatchContext, auto_patch
from .bindings import (
	cuFileDriverClose,
	cuFileDriverOpen,
	cuFileHandleDeregister,
	cuFileHandleRegister,
	cuFileRead,
	cuFileWrite,
	get_default_backend,
	register_backend,
	set_default_backend,
)
from .core import hello_world
from .cufile import CuFile, CuFileDriver
from .safetensor_patcher import (
	CuFileSafeTensorStreamReader,
	PythonSafeTensorStreamReader,
	SafeTensorCuFilePatcher,
	SafeTensorStreamReader,
	patch_safetensor_load_file,
)
from .tensorflow_patcher import (
	CuFileTFStreamReader,
	PythonTFStreamReader,
	TensorFlowCuFilePatcher,
	TensorFlowStreamReader,
	patch_tensorflow_load_model,
)
from .torch_patcher import (
	CuFileStreamReader,
	PythonStreamReader,
	TorchCuFilePatcher,
	TorchStreamReader,
	patch_torch_load,
)

__all__ = [
	"CuFile",
	"CuFileDriver",
	"AutoPatchContext",
	"auto_patch",
	"cuFileDriverClose",
	"cuFileDriverOpen",
	"cuFileHandleDeregister",
	"cuFileHandleRegister",
	"cuFileRead",
	"cuFileWrite",
	"get_default_backend",
	"hello_world",
	"register_backend",
	"set_default_backend",
	"PythonStreamReader",
	"CuFileStreamReader",
	"TorchCuFilePatcher",
	"TorchStreamReader",
	"patch_torch_load",
	"CuFileSafeTensorStreamReader",
	"PythonSafeTensorStreamReader",
	"SafeTensorCuFilePatcher",
	"SafeTensorStreamReader",
	"patch_safetensor_load_file",
	"CuFileTFStreamReader",
	"PythonTFStreamReader",
	"TensorFlowCuFilePatcher",
	"TensorFlowStreamReader",
	"patch_tensorflow_load_model",
]
