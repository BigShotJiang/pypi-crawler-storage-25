from __future__ import annotations

import importlib
from contextlib import AbstractContextManager
from dataclasses import dataclass
from types import ModuleType
from typing import Any

from .safetensor_patcher import patch_safetensor_load_file
from .tensorflow_patcher import patch_tensorflow_load_model
from .torch_patcher import patch_torch_load


@dataclass(frozen=True)
class _FrameworkSpec:
    name: str
    import_name: str
    enabled: bool | None


def _normalize_flag(flag: bool | None) -> bool | None:
    if flag in (True, False, None):
        return flag
    raise TypeError("framework flags must be True, False, or None")


class AutoPatchContext(AbstractContextManager["AutoPatchContext"]):
    """Context manager that installs and removes framework patchers automatically."""

    def __init__(
        self,
        *,
        torch: bool | None = None,
        tensorflow: bool | None = None,
        safetensors: bool | None = None,
        strict: bool = False,
        min_file_size_mb: int = 64,
        chunk_size_mb: int = 16,
        use_cufile: bool = False,
        fallback_to_original: bool = True,
    ) -> None:
        self._strict = strict
        self._min_file_size_mb = min_file_size_mb
        self._chunk_size_mb = chunk_size_mb
        self._use_cufile = use_cufile
        self._fallback_to_original = fallback_to_original
        self._specs = [
            _FrameworkSpec("torch", "torch", _normalize_flag(torch)),
            _FrameworkSpec("tensorflow", "tensorflow", _normalize_flag(tensorflow)),
            _FrameworkSpec("safetensors", "safetensors.torch", _normalize_flag(safetensors)),
        ]
        self._patchers: list[Any] = []

    def __enter__(self) -> AutoPatchContext:
        self._patchers = []
        for spec in self._specs:
            module = self._resolve_module(spec)
            if module is None:
                continue
            patcher = self._build_patcher(spec.name, module)
            patcher.install()
            self._patchers.append(patcher)
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        while self._patchers:
            patcher = self._patchers.pop()
            patcher.uninstall()
        return None

    def _resolve_module(self, spec: _FrameworkSpec) -> ModuleType | None:
        if spec.enabled is False:
            return None
        try:
            return importlib.import_module(spec.import_name)
        except ModuleNotFoundError:
            if self._strict or spec.enabled is True:
                raise RuntimeError(f"requested framework is not available: {spec.name}") from None
            return None

    def _build_patcher(self, framework: str, module: ModuleType):
        kwargs = {
            "min_file_size_mb": self._min_file_size_mb,
            "chunk_size_mb": self._chunk_size_mb,
            "use_cufile": self._use_cufile,
            "fallback_to_original": self._fallback_to_original,
        }
        if framework == "torch":
            return patch_torch_load(module, **kwargs)
        if framework == "tensorflow":
            return patch_tensorflow_load_model(module, **kwargs)
        if framework == "safetensors":
            return patch_safetensor_load_file(module, **kwargs)
        raise ValueError(f"unsupported framework: {framework}")


def auto_patch(
    *,
    torch: bool | None = None,
    tensorflow: bool | None = None,
    safetensors: bool | None = None,
    strict: bool = False,
    min_file_size_mb: int = 64,
    chunk_size_mb: int = 16,
    use_cufile: bool = False,
    fallback_to_original: bool = True,
) -> AutoPatchContext:
    """
    Return a context manager that installs available framework patchers.

    By default, framework flags are auto-detected (`None`): if import succeeds,
    the corresponding patcher is installed.
    """
    return AutoPatchContext(
        torch=torch,
        tensorflow=tensorflow,
        safetensors=safetensors,
        strict=strict,
        min_file_size_mb=min_file_size_mb,
        chunk_size_mb=chunk_size_mb,
        use_cufile=use_cufile,
        fallback_to_original=fallback_to_original,
    )
