from __future__ import annotations

import ctypes


class CUfileError(ctypes.Structure):
    _fields_ = [("err", ctypes.c_int), ("cu_err", ctypes.c_int)]


CUfileHandle_t = ctypes.c_void_p


class DescrUnion(ctypes.Union):
    _fields_ = [("fd", ctypes.c_int), ("handle", ctypes.c_void_p)]


class CUfileDescr(ctypes.Structure):
    _fields_ = [
        ("type", ctypes.c_int),
        ("handle", DescrUnion),
        ("fs_ops", ctypes.c_void_p),
    ]
