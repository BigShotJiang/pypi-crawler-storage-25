from __future__ import annotations

import ctypes
import os

from .bindings import (
    cuFileDriverClose,
    cuFileDriverOpen,
    cuFileHandleDeregister,
    cuFileHandleRegister,
    cuFileRead,
    cuFileWrite,
)


class CuFileDriver:
    _instance: CuFileDriver | None = None

    def __new__(cls) -> CuFileDriver:
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._initialized = False
        return cls._instance

    def __init__(self) -> None:
        if self._initialized:
            return
        cuFileDriverOpen()
        self._initialized = True

    def close(self) -> None:
        if self._initialized:
            cuFileDriverClose()
            self._initialized = False

    def __del__(self) -> None:
        self.close()

    @classmethod
    def _reset_for_tests(cls) -> None:
        if cls._instance is not None:
            cls._instance.close()
        cls._instance = None


def _os_mode(mode: str) -> int:
    modes = {
        "r": os.O_RDONLY,
        "r+": os.O_RDWR,
        "w": os.O_CREAT | os.O_WRONLY | os.O_TRUNC,
        "w+": os.O_CREAT | os.O_RDWR | os.O_TRUNC,
        "a": os.O_CREAT | os.O_WRONLY | os.O_APPEND,
        "a+": os.O_CREAT | os.O_RDWR | os.O_APPEND,
    }
    try:
        return modes[mode]
    except KeyError as exc:
        raise ValueError(f"unsupported mode: {mode}") from exc


class CuFile:
    def __init__(self, path: str, mode: str = "r", use_direct_io: bool = False):
        self._driver = CuFileDriver()
        self._path = path
        self._mode = mode
        self._os_mode = _os_mode(mode)
        if use_direct_io and hasattr(os, "O_DIRECT"):
            self._os_mode |= os.O_DIRECT

        self._handle: int | None = None
        self._cu_file_handle = None

    @property
    def is_open(self) -> bool:
        return self._handle is not None

    def open(self) -> None:
        if self.is_open:
            return
        self._handle = os.open(self._path, self._os_mode)
        self._cu_file_handle = cuFileHandleRegister(self._handle)

    def close(self) -> None:
        if not self.is_open:
            return
        cuFileHandleDeregister(self._cu_file_handle)
        os.close(self._handle)
        self._handle = None
        self._cu_file_handle = None

    def __enter__(self) -> CuFile:
        self.open()
        return self

    def __exit__(self, exc_type, exc_val, exc_tb) -> None:
        self.close()

    def __del__(self) -> None:
        self.close()

    def read(
        self,
        dest: ctypes.c_void_p,
        size: int,
        file_offset: int = 0,
        dev_offset: int = 0,
    ) -> int:
        if not self.is_open:
            raise OSError("File is not open.")
        return cuFileRead(self._cu_file_handle, dest, size, file_offset, dev_offset)

    def write(
        self,
        src: ctypes.c_void_p,
        size: int,
        file_offset: int = 0,
        dev_offset: int = 0,
    ) -> int:
        if not self.is_open:
            raise OSError("File is not open.")
        return cuFileWrite(self._cu_file_handle, src, size, file_offset, dev_offset)

    def get_handle(self) -> int | None:
        return self._handle
