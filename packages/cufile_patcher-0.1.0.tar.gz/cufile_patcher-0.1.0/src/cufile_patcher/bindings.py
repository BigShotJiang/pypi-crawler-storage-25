from __future__ import annotations

import ctypes

from .cufile_types import CUfileDescr, CUfileError, CUfileHandle_t, DescrUnion
from .plugins import CuFileBackend
from .registry import get_default_backend, register_backend, set_default_backend


def _backend() -> CuFileBackend:
    return get_default_backend()


def cuFileDriverOpen() -> None:
    _backend().driver_open()


def cuFileDriverClose() -> None:
    _backend().driver_close()


def cuFileHandleRegister(fd: int) -> CUfileHandle_t:
    return _backend().handle_register(fd)


def cuFileHandleDeregister(handle: CUfileHandle_t) -> None:
    _backend().handle_deregister(handle)


def cuFileRead(
    handle: CUfileHandle_t,
    buf: ctypes.c_void_p,
    size: int,
    file_offset: int,
    dev_offset: int,
) -> int:
    return _backend().read(handle, buf, size, file_offset, dev_offset)


def cuFileWrite(
    handle: CUfileHandle_t,
    buf: ctypes.c_void_p,
    size: int,
    file_offset: int,
    dev_offset: int,
) -> int:
    return _backend().write(handle, buf, size, file_offset, dev_offset)


__all__ = [
    "CUfileDescr",
    "CUfileError",
    "CUfileHandle_t",
    "DescrUnion",
    "cuFileDriverClose",
    "cuFileDriverOpen",
    "cuFileHandleDeregister",
    "cuFileHandleRegister",
    "cuFileRead",
    "cuFileWrite",
    "get_default_backend",
    "register_backend",
    "set_default_backend",
]
