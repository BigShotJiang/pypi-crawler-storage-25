from __future__ import annotations

import ctypes
import os
from pathlib import Path

import pytest

import cufile_patcher.torch_patcher as torch_mod
from cufile_patcher.torch_patcher import patch_torch_load


class FakeTorch:
    """
    Simulate torch.load behavior that fails on large path-based loads.

    - Loading from path does a single large read and fails above threshold.
    - Loading from file-like object works (stream-safe path).
    """

    def __init__(self, fail_threshold_bytes: int) -> None:
        self._threshold = fail_threshold_bytes
        self.path_calls = 0
        self.file_like_calls = 0

    def load(self, source, *args, **kwargs):
        if isinstance(source, (str, os.PathLike)):
            self.path_calls += 1
            with open(source, "rb") as fp:
                data = fp.read()
            if len(data) > self._threshold:
                raise MemoryError("large non-streaming load failed")
            return {"mode": "path", "bytes": len(data)}

        self.file_like_calls += 1
        data = source.read()
        return {"mode": "file_like", "bytes": len(data)}


def _write_blob(path: Path, size_bytes: int) -> None:
    path.write_bytes(b"x" * size_bytes)


def test_large_file_fails_without_patcher(tmp_path: Path) -> None:
    fake_torch = FakeTorch(fail_threshold_bytes=256 * 1024)
    model_path = tmp_path / "large_model.pt"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    with pytest.raises(MemoryError, match="non-streaming"):
        fake_torch.load(str(model_path))

    assert fake_torch.path_calls == 1
    assert fake_torch.file_like_calls == 0


def test_large_file_passes_with_patcher(tmp_path: Path) -> None:
    fake_torch = FakeTorch(fail_threshold_bytes=256 * 1024)
    model_path = tmp_path / "large_model.pt"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    patcher = patch_torch_load(
        fake_torch,
        min_file_size_mb=1,
        chunk_size_mb=1,
        fallback_to_original=False,
    )
    try:
        result = fake_torch.load(str(model_path))
    finally:
        patcher.uninstall()

    assert result["mode"] == "file_like"
    assert result["bytes"] == 2 * 1024 * 1024
    assert fake_torch.file_like_calls == 1


def test_small_file_keeps_original_path(tmp_path: Path) -> None:
    fake_torch = FakeTorch(fail_threshold_bytes=256 * 1024)
    model_path = tmp_path / "small_model.pt"
    _write_blob(model_path, size_bytes=64 * 1024)

    patcher = patch_torch_load(fake_torch, min_file_size_mb=1, chunk_size_mb=1)
    try:
        result = fake_torch.load(str(model_path))
    finally:
        patcher.uninstall()

    assert result["mode"] == "path"
    assert fake_torch.path_calls == 1


class _FakeCuFile:
    def __init__(self, file_path: str, _mode: str) -> None:
        self._blob = Path(file_path).read_bytes()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def read(self, dest, size: int, file_offset: int = 0, dev_offset: int = 0) -> int:
        del dev_offset
        chunk = self._blob[file_offset : file_offset + size]
        ctypes.memmove(dest, chunk, len(chunk))
        return len(chunk)


class _ZeroReadCuFile(_FakeCuFile):
    def read(self, dest, size: int, file_offset: int = 0, dev_offset: int = 0) -> int:
        del dest, size, file_offset, dev_offset
        return 0


class _FailingReader:
    def iter_chunks(self, file_path: str, chunk_size: int):
        del file_path, chunk_size
        raise RuntimeError("boom")
        yield b""  # pragma: no cover


def test_torch_cufile_stream_reader_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    path = tmp_path / "blob.bin"
    _write_blob(path, 13)
    monkeypatch.setattr(torch_mod, "CuFile", _FakeCuFile)
    assert b"".join(torch_mod.CuFileStreamReader().iter_chunks(str(path), 5)) == b"x" * 13


def test_torch_cufile_stream_reader_break_on_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "blob.bin"
    _write_blob(path, 13)
    monkeypatch.setattr(torch_mod, "CuFile", _ZeroReadCuFile)
    assert list(torch_mod.CuFileStreamReader().iter_chunks(str(path), 5)) == []


def test_torch_patcher_fallback_and_idempotent_paths(tmp_path: Path) -> None:
    path = tmp_path / "m.bin"
    _write_blob(path, 2 * 1024 * 1024)

    fake_torch = FakeTorch(fail_threshold_bytes=10 * 1024 * 1024)
    patcher = torch_mod.TorchCuFilePatcher(
        fake_torch,
        min_file_size_mb=1,
        stream_reader=_FailingReader(),
        fallback_to_original=True,
    )

    patcher.install()
    patcher.install()

    # Fallback path should call original loader.
    result = fake_torch.load(str(path))
    assert result["mode"] == "path"

    # _should_stream defensive branches.
    assert patcher._should_stream(object()) is False
    assert patcher._should_stream(str(tmp_path / "missing.bin")) is False

    patcher.uninstall()
    patcher.uninstall()


def test_torch_patcher_no_fallback_raises(tmp_path: Path) -> None:
    path = tmp_path / "m.bin"
    _write_blob(path, 2 * 1024 * 1024)

    fake_torch = FakeTorch(fail_threshold_bytes=256 * 1024)
    patcher = torch_mod.patch_torch_load(
        fake_torch,
        min_file_size_mb=1,
        stream_reader=_FailingReader(),
        fallback_to_original=False,
    )

    try:
        with pytest.raises(RuntimeError, match="boom"):
            fake_torch.load(str(path))
    finally:
        patcher.uninstall()
