from __future__ import annotations

import ctypes

import pytest

import cufile_patcher.cufile as cufile_mod
import cufile_patcher.registry as registry_mod
from cufile_patcher.cufile_types import CUfileError, CUfileHandle_t
from cufile_patcher.plugins.system import SystemCuFileBackend


def test_cufile_driver_singleton_init_once(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []
    cufile_mod.CuFileDriver._reset_for_tests()
    monkeypatch.setattr(cufile_mod, "cuFileDriverOpen", lambda: calls.append("open"))
    monkeypatch.setattr(cufile_mod, "cuFileDriverClose", lambda: calls.append("close"))

    _ = cufile_mod.CuFileDriver()
    _ = cufile_mod.CuFileDriver()

    assert calls.count("open") == 1
    cufile_mod.CuFileDriver._reset_for_tests()


def test_cufile_invalid_mode_raises() -> None:
    with pytest.raises(ValueError, match="unsupported mode"):
        cufile_mod._os_mode("invalid")


def test_cufile_use_direct_io_and_misc_paths(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cufile_mod, "CuFileDriver", lambda: object())

    cf = cufile_mod.CuFile("/tmp/fake.bin", "r", use_direct_io=True)
    if hasattr(cufile_mod.os, "O_DIRECT"):
        assert cf._os_mode & cufile_mod.os.O_DIRECT

    cf.close()

    with pytest.raises(OSError, match="File is not open"):
        cf.write(ctypes.c_void_p(0x1000), 4)

    assert cf.get_handle() is None


def test_cufile_open_idempotent(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(cufile_mod, "CuFileDriver", lambda: object())

    calls = {"open": 0}

    def _open(_path, _mode):
        calls["open"] += 1
        return 77

    monkeypatch.setattr(cufile_mod.os, "open", _open)
    monkeypatch.setattr(cufile_mod.os, "close", lambda _fd: None)
    monkeypatch.setattr(cufile_mod, "cuFileHandleRegister", lambda _fd: ctypes.c_void_p(1))
    monkeypatch.setattr(cufile_mod, "cuFileHandleDeregister", lambda _h: None)

    cf = cufile_mod.CuFile("/tmp/any.bin", "r")
    cf.open()
    cf.open()
    cf.close()

    assert calls["open"] == 1


def test_registry_error_branches() -> None:
    reg = registry_mod.BackendRegistry()

    with pytest.raises(ValueError, match="must not be empty"):
        reg.register("", lambda: object())

    with pytest.raises(KeyError, match="not registered"):
        reg.set_default("missing")

    with pytest.raises(KeyError, match="not registered"):
        reg.get("missing")


class _FakeFn:
    def __init__(self, ret) -> None:
        self._ret = ret
        self.restype = None
        self.argtypes = None

    def __call__(self, *args):
        if callable(self._ret):
            return self._ret(*args)
        return self._ret


class _FakeLib:
    def __init__(self) -> None:
        self.cuFileDriverOpen = _FakeFn(CUfileError(err=0, cu_err=0))
        self.cuFileDriverClose = _FakeFn(CUfileError(err=0, cu_err=0))

        def _register(handle_ptr, _descr_ptr):
            casted = ctypes.cast(handle_ptr, ctypes.POINTER(CUfileHandle_t))
            casted.contents.value = 1234
            return CUfileError(err=0, cu_err=0)

        self.cuFileHandleRegister = _FakeFn(_register)
        self.cuFileHandleDeregister = _FakeFn(CUfileError(err=0, cu_err=0))
        self.cuFileRead = _FakeFn(8)
        self.cuFileWrite = _FakeFn(9)


def test_system_backend_happy_path(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(ctypes, "CDLL", lambda _name: _FakeLib())
    backend = SystemCuFileBackend("libcufile.so")

    backend.driver_open()
    backend.driver_close()
    handle = backend.handle_register(42)
    assert int(handle.value) == 1234
    backend.handle_deregister(handle)
    assert backend.read(handle, ctypes.c_void_p(0), 8, 0, 0) == 8
    assert backend.write(handle, ctypes.c_void_p(0), 9, 0, 0) == 9


def test_system_backend_error_paths(monkeypatch: pytest.MonkeyPatch) -> None:
    def _raise(_name):
        raise OSError("missing")

    monkeypatch.setattr(ctypes, "CDLL", _raise)
    with pytest.raises(RuntimeError, match="unable to load"):
        SystemCuFileBackend("libcufile.so")

    with pytest.raises(RuntimeError, match="failed"):
        SystemCuFileBackend._check_status(CUfileError(err=1, cu_err=2), "x")
