from __future__ import annotations

import importlib
from types import SimpleNamespace

import pytest

from cufile_patcher.auto_patch import auto_patch

auto_patch_mod = importlib.import_module("cufile_patcher.auto_patch")


class _FakePatch:
    def __init__(self, name: str, calls: list[str]) -> None:
        self._name = name
        self._calls = calls

    def install(self) -> None:
        self._calls.append(f"install:{self._name}")

    def uninstall(self) -> None:
        self._calls.append(f"uninstall:{self._name}")


def test_auto_patch_installs_detected_frameworks(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []

    def _import(name: str):
        if name in {"torch", "tensorflow", "safetensors.torch"}:
            return SimpleNamespace(__name__=name)
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(auto_patch_mod.importlib, "import_module", _import)
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_torch_load",
        lambda _m, **_k: _FakePatch("torch", calls),
    )
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_tensorflow_load_model",
        lambda _m, **_k: _FakePatch("tensorflow", calls),
    )
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_safetensor_load_file",
        lambda _m, **_k: _FakePatch("safetensors", calls),
    )

    with auto_patch():
        pass

    assert calls == [
        "install:torch",
        "install:tensorflow",
        "install:safetensors",
        "uninstall:safetensors",
        "uninstall:tensorflow",
        "uninstall:torch",
    ]


def test_auto_patch_selective_framework_flags(monkeypatch: pytest.MonkeyPatch) -> None:
    imported: list[str] = []
    calls: list[str] = []

    def _import(name: str):
        imported.append(name)
        return SimpleNamespace(__name__=name)

    monkeypatch.setattr(auto_patch_mod.importlib, "import_module", _import)
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_torch_load",
        lambda _m, **_k: _FakePatch("torch", calls),
    )
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_tensorflow_load_model",
        lambda _m, **_k: _FakePatch("tensorflow", calls),
    )
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_safetensor_load_file",
        lambda _m, **_k: _FakePatch("safetensors", calls),
    )

    with auto_patch(torch=True, tensorflow=False, safetensors=False):
        pass

    assert imported == ["torch"]
    assert calls == ["install:torch", "uninstall:torch"]


def test_auto_patch_strict_raises_when_requested_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(
        auto_patch_mod.importlib,
        "import_module",
        lambda _name: (_ for _ in ()).throw(ModuleNotFoundError("missing")),
    )

    with pytest.raises(RuntimeError, match="requested framework is not available: torch"):
        with auto_patch(torch=True):
            pass


def test_auto_patch_strict_mode_raises_on_any_missing(monkeypatch: pytest.MonkeyPatch) -> None:
    def _import(name: str):
        if name == "torch":
            return SimpleNamespace(__name__=name)
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(auto_patch_mod.importlib, "import_module", _import)
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_torch_load",
        lambda _m, **_k: _FakePatch("torch", []),
    )

    with pytest.raises(RuntimeError, match="requested framework is not available: tensorflow"):
        with auto_patch(strict=True):
            pass


def test_auto_patch_uninstalls_on_exception(monkeypatch: pytest.MonkeyPatch) -> None:
    calls: list[str] = []

    def _import(name: str):
        if name == "torch":
            return SimpleNamespace(__name__=name)
        raise ModuleNotFoundError(name)

    monkeypatch.setattr(auto_patch_mod.importlib, "import_module", _import)
    monkeypatch.setattr(
        auto_patch_mod,
        "patch_torch_load",
        lambda _m, **_k: _FakePatch("torch", calls),
    )

    with pytest.raises(ValueError, match="boom"):
        with auto_patch(torch=True):
            raise ValueError("boom")

    assert calls == ["install:torch", "uninstall:torch"]


def test_auto_patch_invalid_flag_type_raises() -> None:
    with pytest.raises(TypeError, match="framework flags"):
        auto_patch(torch="yes")  # type: ignore[arg-type]


def test_auto_patch_build_patcher_rejects_unknown_framework() -> None:
    ctx = auto_patch()
    with pytest.raises(ValueError, match="unsupported framework"):
        ctx._build_patcher("unknown", SimpleNamespace())
