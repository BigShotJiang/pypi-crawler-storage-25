import ctypes
import os

import pytest

from cufile_patcher import CuFile, CuFileDriver, hello_world
from cufile_patcher.registry import register_backend, set_default_backend


class FakeBackend:
    def __init__(self) -> None:
        self.driver_open_calls = 0
        self.driver_close_calls = 0
        self.register_calls = 0
        self.deregister_calls = 0
        self.read_calls = 0
        self.write_calls = 0

    def driver_open(self) -> None:
        self.driver_open_calls += 1

    def driver_close(self) -> None:
        self.driver_close_calls += 1

    def handle_register(self, fd: int):
        self.register_calls += 1
        return ctypes.c_void_p(fd + 1000)

    def handle_deregister(self, handle) -> None:
        self.deregister_calls += 1

    def read(self, handle, buf, size: int, file_offset: int, dev_offset: int) -> int:
        self.read_calls += 1
        return size

    def write(self, handle, buf, size: int, file_offset: int, dev_offset: int) -> int:
        self.write_calls += 1
        return size


@pytest.fixture(autouse=True)
def use_fake_backend() -> None:
    register_backend("fake", FakeBackend)
    set_default_backend("fake")
    CuFileDriver._reset_for_tests()
    yield
    set_default_backend("fake")
    CuFileDriver._reset_for_tests()


def test_hello_world() -> None:
    assert hello_world() == "Hello, world!"


def test_cufile_context_manager(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(os, "open", lambda *args, **kwargs: 42)
    monkeypatch.setattr(os, "close", lambda *_args, **_kwargs: None)

    with CuFile("/tmp/test.bin", "w") as cf:
        assert cf.is_open

    assert not cf.is_open


def test_read_write_lifecycle(monkeypatch: pytest.MonkeyPatch) -> None:
    monkeypatch.setattr(os, "open", lambda *args, **kwargs: 7)
    monkeypatch.setattr(os, "close", lambda *_args, **_kwargs: None)

    cu_file = CuFile("/tmp/test.bin", "w")
    cu_file.open()

    buf = ctypes.c_void_p(0x1000)
    assert cu_file.write(buf, 128) == 128
    assert cu_file.read(buf, 128) == 128

    cu_file.close()


def test_read_without_open_raises() -> None:
    cu_file = CuFile("/tmp/test.bin", "r")
    with pytest.raises(OSError, match="File is not open"):
        cu_file.read(ctypes.c_void_p(0x1000), 64)
