from __future__ import annotations

import ctypes
import os
from pathlib import Path

import pytest

import cufile_patcher.tensorflow_patcher as tf_mod
from cufile_patcher.tensorflow_patcher import patch_tensorflow_load_model


class _FakeModels:
    def __init__(self, fail_threshold_bytes: int) -> None:
        self._threshold = fail_threshold_bytes
        self.path_calls = 0
        self.file_like_calls = 0

    def load_model(self, source, *args, **kwargs):
        if isinstance(source, (str, os.PathLike)):
            self.path_calls += 1
            with open(source, "rb") as fp:
                data = fp.read()
            if len(data) > self._threshold:
                raise MemoryError("large non-streaming tf load failed")
            return {"mode": "path", "bytes": len(data)}

        self.file_like_calls += 1
        data = source.read()
        return {"mode": "file_like", "bytes": len(data)}


class _FakeKeras:
    def __init__(self, fail_threshold_bytes: int) -> None:
        self.models = _FakeModels(fail_threshold_bytes)


class FakeTensorFlow:
    def __init__(self, fail_threshold_bytes: int) -> None:
        self.keras = _FakeKeras(fail_threshold_bytes)


def _write_blob(path: Path, size_bytes: int) -> None:
    path.write_bytes(b"x" * size_bytes)


def test_large_tf_file_fails_without_patcher(tmp_path: Path) -> None:
    fake_tf = FakeTensorFlow(fail_threshold_bytes=256 * 1024)
    model_path = tmp_path / "large_model.keras"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    with pytest.raises(MemoryError, match="non-streaming"):
        fake_tf.keras.models.load_model(str(model_path))

    assert fake_tf.keras.models.path_calls == 1
    assert fake_tf.keras.models.file_like_calls == 0


def test_large_tf_file_passes_with_patcher(tmp_path: Path) -> None:
    fake_tf = FakeTensorFlow(fail_threshold_bytes=256 * 1024)
    model_path = tmp_path / "large_model.keras"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    patcher = patch_tensorflow_load_model(
        fake_tf,
        min_file_size_mb=1,
        chunk_size_mb=1,
        fallback_to_original=False,
    )
    try:
        result = fake_tf.keras.models.load_model(str(model_path))
    finally:
        patcher.uninstall()

    assert result["mode"] == "file_like"
    assert result["bytes"] == 2 * 1024 * 1024
    assert fake_tf.keras.models.file_like_calls == 1


def test_small_tf_file_keeps_original_path(tmp_path: Path) -> None:
    fake_tf = FakeTensorFlow(fail_threshold_bytes=256 * 1024)
    model_path = tmp_path / "small_model.keras"
    _write_blob(model_path, size_bytes=64 * 1024)

    patcher = patch_tensorflow_load_model(fake_tf, min_file_size_mb=1, chunk_size_mb=1)
    try:
        result = fake_tf.keras.models.load_model(str(model_path))
    finally:
        patcher.uninstall()

    assert result["mode"] == "path"
    assert fake_tf.keras.models.path_calls == 1


class _FakeCuFile:
    def __init__(self, file_path: str, _mode: str) -> None:
        self._blob = Path(file_path).read_bytes()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def read(self, dest, size: int, file_offset: int = 0, dev_offset: int = 0) -> int:
        del dev_offset
        chunk = self._blob[file_offset : file_offset + size]
        ctypes.memmove(dest, chunk, len(chunk))
        return len(chunk)


class _ZeroReadCuFile(_FakeCuFile):
    def read(self, dest, size: int, file_offset: int = 0, dev_offset: int = 0) -> int:
        del dest, size, file_offset, dev_offset
        return 0


class _FailingReader:
    def iter_chunks(self, file_path: str, chunk_size: int):
        del file_path, chunk_size
        raise RuntimeError("boom")
        yield b""  # pragma: no cover


def test_tf_cufile_stream_reader_paths(tmp_path: Path, monkeypatch: pytest.MonkeyPatch) -> None:
    path = tmp_path / "blob.bin"
    _write_blob(path, 13)
    monkeypatch.setattr(tf_mod, "CuFile", _FakeCuFile)
    assert b"".join(tf_mod.CuFileTFStreamReader().iter_chunks(str(path), 5)) == b"x" * 13


def test_tf_cufile_stream_reader_break_on_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "blob.bin"
    _write_blob(path, 13)
    monkeypatch.setattr(tf_mod, "CuFile", _ZeroReadCuFile)
    assert list(tf_mod.CuFileTFStreamReader().iter_chunks(str(path), 5)) == []


def test_tf_patcher_fallback_and_idempotent_paths(tmp_path: Path) -> None:
    path = tmp_path / "m.bin"
    _write_blob(path, 2 * 1024 * 1024)

    fake_tf = FakeTensorFlow(fail_threshold_bytes=10 * 1024 * 1024)
    patcher = tf_mod.TensorFlowCuFilePatcher(
        fake_tf,
        min_file_size_mb=1,
        stream_reader=_FailingReader(),
        fallback_to_original=True,
    )

    patcher.install()
    patcher.install()

    result = fake_tf.keras.models.load_model(str(path))
    assert result["mode"] == "path"

    assert patcher._should_stream(object()) is False
    assert patcher._should_stream(str(tmp_path / "missing.bin")) is False

    patcher.uninstall()
    patcher.uninstall()


def test_tf_patcher_no_fallback_raises(tmp_path: Path) -> None:
    path = tmp_path / "m.bin"
    _write_blob(path, 2 * 1024 * 1024)

    fake_tf = FakeTensorFlow(fail_threshold_bytes=256 * 1024)
    patcher = tf_mod.patch_tensorflow_load_model(
        fake_tf,
        min_file_size_mb=1,
        stream_reader=_FailingReader(),
        fallback_to_original=False,
    )

    try:
        with pytest.raises(RuntimeError, match="boom"):
            fake_tf.keras.models.load_model(str(path))
    finally:
        patcher.uninstall()
