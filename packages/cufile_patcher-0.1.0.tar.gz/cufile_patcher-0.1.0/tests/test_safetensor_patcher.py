from __future__ import annotations

import ctypes
import os
from pathlib import Path

import pytest

import cufile_patcher.safetensor_patcher as st_mod
from cufile_patcher.safetensor_patcher import patch_safetensor_load_file


class FakeSafeTensorsTorch:
    """Simulated safetensors.torch module for deterministic patcher testing."""

    def __init__(self, fail_threshold_bytes: int, fail_paths: set[str] | None = None) -> None:
        self._threshold = fail_threshold_bytes
        self._fail_paths = fail_paths or set()
        self.path_calls = 0

    def load_file(self, source, *args, **kwargs):
        path = os.fspath(source)
        self.path_calls += 1
        data = Path(path).read_bytes()
        if len(data) > self._threshold and path in self._fail_paths:
            raise MemoryError("large non-streaming safetensor load failed")
        return {"path": path, "bytes": len(data)}


def _write_blob(path: Path, size_bytes: int) -> None:
    path.write_bytes(b"x" * size_bytes)


def test_large_safetensor_fails_without_patcher(tmp_path: Path) -> None:
    model_path = tmp_path / "large_model.safetensors"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    fake_st = FakeSafeTensorsTorch(
        fail_threshold_bytes=256 * 1024,
        fail_paths={str(model_path)},
    )

    with pytest.raises(MemoryError, match="non-streaming"):
        fake_st.load_file(str(model_path))


def test_large_safetensor_passes_with_patcher(tmp_path: Path) -> None:
    model_path = tmp_path / "large_model.safetensors"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    fake_st = FakeSafeTensorsTorch(
        fail_threshold_bytes=256 * 1024,
        fail_paths={str(model_path)},
    )

    patcher = patch_safetensor_load_file(
        fake_st,
        min_file_size_mb=1,
        chunk_size_mb=1,
        fallback_to_original=False,
    )
    try:
        result = fake_st.load_file(str(model_path))
    finally:
        patcher.uninstall()

    assert result["bytes"] == 2 * 1024 * 1024
    assert result["path"] != str(model_path)


def test_small_safetensor_keeps_original_path(tmp_path: Path) -> None:
    model_path = tmp_path / "small_model.safetensors"
    _write_blob(model_path, size_bytes=64 * 1024)

    fake_st = FakeSafeTensorsTorch(fail_threshold_bytes=256 * 1024)

    patcher = patch_safetensor_load_file(fake_st, min_file_size_mb=1, chunk_size_mb=1)
    try:
        result = fake_st.load_file(str(model_path))
    finally:
        patcher.uninstall()

    assert result["path"] == str(model_path)


class _FakeCuFile:
    def __init__(self, file_path: str, _mode: str) -> None:
        self._blob = Path(file_path).read_bytes()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc, tb) -> None:
        return None

    def read(self, dest, size: int, file_offset: int = 0, dev_offset: int = 0) -> int:
        del dev_offset
        chunk = self._blob[file_offset : file_offset + size]
        ctypes.memmove(dest, chunk, len(chunk))
        return len(chunk)


class _ZeroReadCuFile(_FakeCuFile):
    def read(self, dest, size: int, file_offset: int = 0, dev_offset: int = 0) -> int:
        del dest, size, file_offset, dev_offset
        return 0


class _FailingReader:
    def iter_chunks(self, file_path: str, chunk_size: int):
        del file_path, chunk_size
        raise RuntimeError("boom")
        yield b""  # pragma: no cover


def test_safetensor_cufile_stream_reader_paths(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "blob.bin"
    _write_blob(path, 13)
    monkeypatch.setattr(st_mod, "CuFile", _FakeCuFile)
    assert b"".join(st_mod.CuFileSafeTensorStreamReader().iter_chunks(str(path), 5)) == b"x" * 13


def test_safetensor_cufile_stream_reader_break_on_zero(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    path = tmp_path / "blob.bin"
    _write_blob(path, 13)
    monkeypatch.setattr(st_mod, "CuFile", _ZeroReadCuFile)
    assert list(st_mod.CuFileSafeTensorStreamReader().iter_chunks(str(path), 5)) == []


def test_safetensor_patcher_fallback_and_idempotent_paths(tmp_path: Path) -> None:
    model_path = tmp_path / "large_model.safetensors"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    fake_st = FakeSafeTensorsTorch(fail_threshold_bytes=10 * 1024 * 1024)
    patcher = st_mod.SafeTensorCuFilePatcher(
        fake_st,
        min_file_size_mb=1,
        stream_reader=_FailingReader(),
        fallback_to_original=True,
    )

    patcher.install()
    patcher.install()

    result = fake_st.load_file(str(model_path))
    assert result["path"] == str(model_path)

    assert patcher._should_stream(object()) is False
    assert patcher._should_stream(str(tmp_path / "missing.safetensors")) is False

    patcher.uninstall()
    patcher.uninstall()


def test_safetensor_patcher_no_fallback_raises(tmp_path: Path) -> None:
    model_path = tmp_path / "large_model.safetensors"
    _write_blob(model_path, size_bytes=2 * 1024 * 1024)

    fake_st = FakeSafeTensorsTorch(
        fail_threshold_bytes=256 * 1024,
        fail_paths={str(model_path)},
    )
    patcher = st_mod.patch_safetensor_load_file(
        fake_st,
        min_file_size_mb=1,
        stream_reader=_FailingReader(),
        fallback_to_original=False,
    )

    try:
        with pytest.raises(RuntimeError, match="boom"):
            fake_st.load_file(str(model_path))
    finally:
        patcher.uninstall()
